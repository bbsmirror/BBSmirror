:
# NAME:
#      mkpatch - make a patch file
#
# SYNOPSIS:
#      mkpatch [-Pa][-b base_dir][-p patch_id][-e ext][-E ext] \\
#              [-f patch_file] file [...]
#
# DESCRIPTION:
#      For each file, compare the version found under "base_dir"
#      with the current version.  If they differ, then
#      generate a context diff to add to a patchfile that
#      follows the format of the C-News patches.
#
#      Options:
#
#      -P      update PATCHDATES
#      -a      append.  Do not generate a header.
#      -b "base_dir"
#              Compare each file with the version found under
#              "base_dir".
#      -p "patch_id"
#              Identify the patch as "patch_id".
#      -e "ext" (~)
#              If no "base_dir" look for files with an
#              extention of "ext" to compare against.
#      -E "Ext" (.old)
#              When writing out the diffs, use "Ext" instead of
#              "ext".
#      -f "patch_file"
#              Identify the name for the patch file.
#
#      The context diff is passed through a sed script to clean
#      out unwanted directory names.  Thus:
#.nf
#
#      mkpatch -b /tmp/pdksh sh/edit.c
#
#      might produce output like:
#
#      *** sh/edit.c~  Tue May 28 16:50:19 1991
#      \--- sh/edit.c  Thu May 23 16:00:44 1991
#      ***************
#      *** 19,32 ****
#        #include \"sh.h\"
#        #include \"lex.h\"
#        #include \"tty.h\"
#
#      Instead of:
#
#      *** /tmp/pdksh/sh/edit.c    Tue May 28 16:50:19 1991
#      \--- sh/edit.c  Thu May 23 16:00:44 1991
#      ***************
#      *** 19,32 ****
#        #include \"sh.h\"
#        #include \"lex.h\"
#        #include \"tty.h\"
#
#.fi
# SEE ALSO:
#      diff(1), patch(1L)
#
# AUTHOR:
#      Simon J. Gerraty <sjg@zen.void.oz.au>
#

# RCSid:
#      $Id: mkpatch.sh,v 1.2 1994/01/11 12:27:12 sjg Exp $
#
# SCCSID:
#      @(#)mkpatch.sh 2.4 91/12/07 19:08:44 (sjg)
#
#
#      @(#)Copyright 1991,1994 Simon J. Gerraty
#
#      This file is provided in the hope that it will
#      be of use.  There is absolutely NO WARRANTY.
#      Permission to copy, redistribute or otherwise
#      use this file is hereby granted provided that
#      the above copyright notice and this notice are
#      left intact.
#
#      Please send copies of changes and bug-fixes to:
#      sjg@zen.void.oz.au
#

set -- `getopt "Pab:p:E:e:f:" $*`
for i in $*
do
  case $i in
  -P)  UPD_PATCH=yes; shift;;
  -a)  APPEND=yes; shift;;
  -e)  e=$2; shift 2;;
  -E)  EXT=$2; shift 2;;
  -p)  PATCH_ID=$2; shift 2;;
  -b)  BASE=$2; shift 2;;
  -f)  PATCH_FILE=$2; shift 2;;
  --)  shift; break;;
  esac
done

# ./filename looks ugly...
FILES="`echo $* | sed 's;\./;;g'`"

set -- `date '+%d %h %y'`
DAY=$1
MON=$2
YR=$3

EXT=${EXT:-.old}
e=${e:-~}
BASE=${BASE:-.}
PATCH_ID=${PATCH_ID:-"$DAY-$MON-19$YR"}
PATCH_FILE=${PATCH_FILE:-"pch$DAY$MON$YR"}
UPD_PATCHD=${UPD_PATCH:-no}
APPEND=${APPEND:-no}

dopatch ()
{
  file=$1

  if [ "$BASE" = . ]; then
    oldfile=${file}$e
    if [ ! -f $oldfile ]; then
      oldfile=""
    fi
  else
    e=""
    oldfile=$BASE/$file
    if [ ! -f $oldfile ]; then
      oldfile=/dev/null                # assume a new file!
    fi
  fi
  if [ -f $file -a "$oldfile" ]; then
    if cmp -s $oldfile $file ; then
       : # skip it
    else
       diff -c $oldfile $file | \
       sed -e "s;^\*\*\* $BASE/\.*/*\([^       ][^     ]*\)$e\(.*\);*** \1$EXT\
 2;"
    fi
  fi
}

if [ "$APPEND" != yes ]; then
  # First create the header for the patch file
  cat <<!EOM
start of patch $PATCH_ID
(suggested archive name: ${PATCH_FILE}.Z)
It should be applied by changing directory to the root
of the source tree and using the command:
       patch -p0 < this_file

!EOM

if [ -s PATCHDATES ]; then
    cat << !EOM
The following is a complete list of patches to date.

!EOM
    sed 's/^\([^#]\)/Prereq: \1/' PATCHDATES
  fi
fi
if [ "$UPD_PATCH" = yes ]; then
  mv PATCHDATES PATCHDATES.old
  cp PATCHDATES.old PATCHDATES
  # add this patch to the list
  echo "$PATCH_ID" >>PATCHDATES
  diff -c PATCHDATES.old PATCHDATES
else
  # just treat it like a normal file
  dopatch PATCHDATES
fi

# now get the diffs...
for file in $FILES
do
  # skip PATCHDATES if listed.
  if [ "$file" != PATCHDATES -a "$file" != ./PATCHDATES ]; then
    dopatch $file
  fi
done
exit 0
