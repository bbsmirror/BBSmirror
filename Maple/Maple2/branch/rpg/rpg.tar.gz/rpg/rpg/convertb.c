#include "bbs.h"
#include "struct.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define _BOARDS_PATH "/home/bbs/boards"
#define _DIS_PATH    "/home/bbs/boards"

struct fileheader header;

main(int argc ,char *argv[])
{
  char buf[128];
  char month[12];  
  char *post;
  char *ch;
  
  FILE *fp_all;
  FILE *fp;
  FILE *temp;
  
  int i,j,check,diff;
  
  
  header.filemode = FILE_LOCAL;
  header.savemode = 'S';
  
  sprintf(buf,"/bin/ls -al %s/%s > %s",_BOARDS_PATH,argv[1],"post.all");
  system(buf);
  printf("post.all building...\n");

  sprintf(buf,"cp %s/%s/.DIR %s/%s/.DIR.bak",_DIS_PATH,argv[1],_DIS_PATH,argv[1]);
  system(buf);  
  printf(".DIR.bak is backup");
  
  sprintf(buf,"echo \'\' >  %s/%s/.DIR",_DIS_PATH,argv[1]);
  system(buf);
  printf("cleaned and created .DIR");
  

  temp=fopen("tmp.dir","w");
  fp_all=fopen("post.all","r");
  
  printf("goto loop...\n"); 
  
  while(fgets(buf,128,fp_all))  /*�Ҧ��ɮת��^��*/
  {
    check=0;
    if(post=strstr(buf,"M."))
    {
      ch=strstr(buf,".A");
      strcpy(ch+2,"\0");
      sprintf(header.filename,"%s",post);
      sprintf(buf,"%s/%s/%s",_BOARDS_PATH,argv[1],header.filename);
      printf("Decoding %s file...",header.filename);
      check++;
      
      fp=fopen(buf,"r");
      for(j=0;j<3;j++)     /*��@���ɮ�search*/
      {
        fgets(buf,128,fp);
        printf("%s",buf);
        if(strstr(buf,"Posted By") || strstr(buf,"Post By") || strstr(buf,"�o�H�H") || strstr(buf,"�@��"))
        {
          if(strstr(buf,"Posted By"))
            diff=1;
          else
            diff=0;
            
          ch=strchr(buf,':');
          ch+=2;
          check++;
          
          for(i=0;i<128;i++)
          {
            if(*ch >= 'A' && *ch <= 'Z')
                header.owner[i]=*ch;
            else if(*ch >= 'a' && *ch <= 'z')
                header.owner[i]=*ch;
            else if(*ch >= '0' && *ch <= '9')
                header.owner[i]=*ch;
            else
            {
              header.owner[i]='\0';
              printf("owner ok...");
              break;
            }
            ch++;
          }
        }
        else if(strstr(buf,"Title") || strstr(buf,"��  �D") || strstr(buf,"���D"))
        {
          ch=strchr(buf,':');
          if(diff)
             ch+=6;
          else
             ch+=2;
          check++;        
          strcpy(header.title,ch);
          ch=strchr(header.title,'\n');
          strcpy(ch,"\0");
          printf("title ok...");
        }
        else if(strstr(buf,"Date") || strstr(buf,"�o�H��") || strstr(buf,"�ɶ�"))
        {
          if(ch=strstr(buf,"Jan"))
            strcpy(header.date," 1/");
          else if(ch=strstr(buf,"Feb"))
            strcpy(header.date," 2/");
          else if(ch=strstr(buf,"Mar"))
            strcpy(header.date," 3/");
          else if(ch=strstr(buf,"Apr"))
            strcpy(header.date," 4/");
          else if(ch=strstr(buf,"May"))
            strcpy(header.date," 5/");
          else if(ch=strstr(buf,"Jun"))
            strcpy(header.date," 6/");
          else if(ch=strstr(buf,"Jul"))
            strcpy(header.date," 7/");
          else if(ch=strstr(buf,"Aug"))
            strcpy(header.date," 8/");
          else if(ch=strstr(buf,"Sep"))
            strcpy(header.date," 9/");
          else if(ch=strstr(buf,"Oct"))
            strcpy(header.date,"10/");
          else if(ch=strstr(buf,"Nov"))
            strcpy(header.date,"11/");
          else if(ch=strstr(buf,"Dec")) 
            strcpy(header.date,"12/");
          else 
            strcpy(header.date,"??/");
          while((*ch++ < '0') || (*ch > '9'));
          strncpy(&header.date[3],ch+1,2);
          check++;
          printf("%s date ok...",header.date);
        }
        else
        {
          printf("bad file...");
          break;
        }
      }              
    fclose(fp); 
    }
    if(check==4)
    {
       fwrite(&header,sizeof(header),1,temp);
       printf("write ok...\n");
    }
    else
      printf("not secret lover's code...\n");
    
  }
  
  printf("\nok all.....\n");
  fclose(fp_all);
  fclose(temp);
  sprintf(buf,"cp tmp.dir %s/%s/.DIR",_DIS_PATH,argv[1]);
  system(buf);
  system("rm -f tmp.dir");
}
