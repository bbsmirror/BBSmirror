/*-------------------------------------------------------*/
/* global.h	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : global definitions & variables		 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#ifndef	_GLOBAL_H_
#define	_GLOBAL_H_


/* ----------------------------------------------------- */
/* GLOBAL DEFINITION					 */
/* ----------------------------------------------------- */


/* �ɦW�]�w */


#define	FN_PASSWD	".PASSWDS"	/* User records */
#define FN_BOARD	".BOARDS"	/* board list */
#define	FN_USIES	"usies"		/* BBS log */


#define	DEFAULT_BOARD	str_sysop


/* ��L�]�w */

#ifndef EXTEND_KEY
#define EXTEND_KEY
#define KEY_TAB		9
#define KEY_ESC		27
#define KEY_UP		0x0101
#define KEY_DOWN	0x0102
#define KEY_RIGHT	0x0103
#define KEY_LEFT	0x0104
#define KEY_HOME	0x0201
#define KEY_INS		0x0202
#define KEY_DEL		0x0203
#define KEY_END		0x0204
#define KEY_PGUP	0x0205
#define KEY_PGDN	0x0206
#endif

#define Ctrl(c)		( c & 037 )

#ifdef SYSV
#undef CTRL			/* SVR4 CTRL macro is hokey */
#define CTRL(c) ('c'&037)	/* This gives ESIX a warning...ignore it! */
#endif


#define chartoupper(c)  ((c >= 'a' && c <= 'z') ? c+'A'-'a' : c)
#define char_lower(c)  ((c >= 'A' && c <= 'Z') ? c|32 : c)


/* ----------------------------------------------------- */
/* External function declarations			 */
/* ----------------------------------------------------- */

char *subject();
void pressanykey();
void showtitle();
void show_help();
void showplans();
void user_display();
void log_usies();
void talkreply();
void uinfo_query();
void touch_boards();
void namecomplete();
void usercomplete();
void stampfile();

#define	TRACE	log_usies

/* #define	setutmpmode(x)	(currutmp->mode = (x)) */


/* ----------------------------------------------------- */
/* �T���r��G�W�ߥX�ӡA�H�Q�䴩�U�ػy��			 */
/* ----------------------------------------------------- */


#define STR_CURSOR	"��"
#define STR_UNCUR	"  "

#define	STR_AUTHOR1	"�@��:"
#define	STR_AUTHOR2	"�o�H�H:"
#define	STR_POST1	"�ݪO:"
#define	STR_POST2	"����:"

#define	LEN_AUTHOR1	5
#define	LEN_AUTHOR2	7

#define	STR_GUEST	"guest"


#define	MSG_SEPERATOR	"\
�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w"

#define	MSG_CLOAKED	"�����I�����ΰ_�ӤF"
#define	MSG_UNCLOAK	"�ڭn���{����F...."

#define	MSG_WORKING	"�B�z���A�еy��..."


#define	MSG_CANCEL	"�����C"
#define	MSG_USR_LEFT	"User �w�g���}�F"
#define	MSG_NOBODY	"�ثe�L�H�W�u"

#define	MSG_DEL_OK	"�R������"
#define	MSG_DEL_CANCEL	"�����R��"
#define	MSG_DEL_ERROR	"�R�����~"
#define	MSG_DEL_NY	"�нT�w�R��(Y/N)?[N] "

#define	MSG_FWD_OK	"�峹��H����!"
#define	MSG_FWD_ERR1	"��H���~: system error"
#define	MSG_FWD_ERR2	"��H���~: address error"

#define	MSG_SURE_NY	"�бz�T�w(Y/N)�H[N] "
#define	MSG_SURE_YN	"�бz�T�w(Y/N)�H[Y] "

#define	MSG_BID		"�п�J�ݪO�W�١G"
#define	MSG_UID		"�п�J�ϥΪ̥N���G"
#define	MSG_PASSWD	"�п�J�z���K�X: "

#define	ERR_BOARD_OPEN	".BOARD �}�ҿ��~"
#define	ERR_BOARD_UPDATE	".BOARD ��s���~"
#define	ERR_PASSWD_OPEN	".PASSWDS �}�ҿ��~"

#define	ERR_BID	"���~���ݪO�W��"
#define	ERR_UID	"���~���ϥΪ̥N��"
#define	ERR_PASSWD	"�K�X��J���~"
#define	ERR_FILENAME	"�ɦW���X�k!"


#define	MSG_SELECT_BOARD	\
	"[7m�i ��ܬݪO �j[0m\n�п�J�ݪO�W��(���ť���۰ʷj�M)�G"

#define	MSG_POSTER	\
"[34;42m �峹��Ū [31;47m (y)[30m�^�H [31m(=[]<>)[30m�����D�D [31m(/?)[30m�j�M���D [31m(aA)[30m�j�M�@�� [31m(x)[30m��� [31m(V)[30m�벼 [0m"

#define	MSG_MAILER	\
"[34;42m  �E������  [31;47m  (R)[30m�^�H  [31m(x)[30m��F  [31m(^x)[30m��K  [31m(y)[30m�s�զ^�H  [31m(D)[30m�R��  [31m[G][30m�~�� ? [0m"

#define	MSG_SHORTULIST	"[7m\
 �ϥΪ̥N��    �ثe���A  �x �ϥΪ̥N��    �ثe���A  �x �ϥΪ̥N��    �ثe���A [0m"


#ifdef	_MAIN_C_

/* ----------------------------------------------------- */
/* GLOBAL VARIABLE					 */
/* ----------------------------------------------------- */

usint talk_mode;			/*bobule add*/
usint io_off;				/*bobule add*/
usint in_rpg;
int usernum;
pid_t currpid;			/* current process ID */
usint currstat;
int currmode = 0;
int curredit = 0;
int showansi = 1;
time_t login_start_time;
userec cuser;			/* current user structure */
userec xuser;			/* lookup user structure */
struct rpgrec mine_rpg;
struct rpgrec other_rpg;


char genbuf[1024];
char quote_file[80] = "\0";
char quote_user[80] = "\0";
char currtitle[40] = "\0";
char currfile[FNLEN];		/* current file name @ bbs.c mail.c */
char currboard[IDLEN + 2];
char currBM[IDLEN * 3 + 10];
char reset_color[11] = "[0;37;40m";


/* global string variables */


/* filename */

char *fn_passwd		= FN_PASSWD;
char *fn_board		= FN_BOARD;
char *fn_note_ans	= "note.ans";
char *fn_register	= "register.new";
char *fn_plans		= "plans";
char *fn_write		= "write";
char *fn_overrides	= "overrides";
char *fn_reject		= "reject";
char *fn_notes		= "notes";
char *fn_mandex		= "/.Names";


/* message */

char *msg_seperator	= MSG_SEPERATOR;
char *msg_mailer	= MSG_MAILER;
char *msg_shortulist	= MSG_SHORTULIST;

char *msg_cancel	= MSG_CANCEL;
char *msg_usr_left	= MSG_USR_LEFT;
char *msg_nobody	= MSG_NOBODY;

char *msg_sure_ny	= MSG_SURE_NY;
char *msg_sure_yn	= MSG_SURE_YN;

char *msg_bid		= MSG_BID;
char *msg_uid		= MSG_UID;

char *msg_del_ok	= MSG_DEL_OK;
char *msg_del_ny	= MSG_DEL_NY;

char *msg_fwd_ok	= MSG_FWD_OK;
char *msg_fwd_err1	= MSG_FWD_ERR1;
char *msg_fwd_err2	= MSG_FWD_ERR2;

char *err_board_update	= ERR_BOARD_UPDATE;
char *err_bid		= ERR_BID;
char *err_uid		= ERR_UID;
char *err_filename	= ERR_FILENAME;

char *str_mail_address	= ".bbs@" MYHOSTNAME;
char *str_new		= "new";
char *str_reply		= "Re: ";
char *str_space		= " \t\n\r";
char *str_sysop		= "sysop";
char *str_author1	= STR_AUTHOR1;
char *str_author2	= STR_AUTHOR2;
char *str_post1		= STR_POST1;
char *str_post2		= STR_POST2;
char *BoardName		= BOARDNAME;

#else				/* _MAIN_C_ */


/* ----------------------------------------------------- */
/* GLOBAL VARIABLE					 */
/* ----------------------------------------------------- */

extern usint talk_mode;		/*bobule add*/
extern usint io_off;		/*bobule*/
extern usint in_rpg;
extern int usernum;
extern pid_t currpid;
extern usint currstat;
extern int currmode;
extern int curredit;
extern int showansi;
extern int talkrequest;
extern time_t login_start_time;

extern userec cuser;		/* current user structure */
extern userec xuser;		/* lookup user structure */
extern struct rpgrec mine_rpg;
extern struct rpgrec other_rpg;


extern char genbuf[1024];
extern char quote_file[80];
extern char quote_user[80];
extern char currtitle[44];
extern char currfile[FNLEN];

extern char currboard[];	/* name of currently selected board */
extern char currBM[];		/* BM of currently selected board */
extern char reset_color[];


/* global string variable */

/* filename */

extern char *fn_passwd;
extern char *fn_board;
extern char *fn_note_ans;
extern char *fn_register;
extern char *fn_plans;
extern char *fn_write;
extern char *fn_overrides;
extern char *fn_reject;
extern char *fn_notes;
extern char *fn_mandex;

/* message */

extern char *msg_seperator;
extern char *msg_mailer;
extern char *msg_shortulist;

extern char *msg_cancel;
extern char *msg_usr_left;
extern char *msg_nobody;

extern char *msg_sure_ny;
extern char *msg_sure_yn;

extern char *msg_bid;
extern char *msg_uid;

extern char *msg_del_ok;
extern char *msg_del_ny;

extern char *msg_fwd_ok;
extern char *msg_fwd_err1;
extern char *msg_fwd_err2;

extern char *err_board_update;
extern char *err_bid;
extern char *err_uid;
extern char *err_filename;

extern char *str_mail_address;
extern char *str_new;
extern char *str_reply;
extern char *str_space;
extern char *str_sysop;
extern char *str_author1;
extern char *str_author2;
extern char *str_post1;
extern char *str_post2;
extern char *BoardName;


#ifdef XINU
extern int errno;

#endif

#endif				/* _MAIN_C_ */


extern int errno;
extern jmp_buf byebye;		/* for exception condition like I/O error */

extern user_info *currutmp;

extern int dumb_term;
extern int t_lines, t_columns;	/* Screen size / width */
extern int b_lines;		/* Screen bottom line number: t_lines-1 */
extern int p_lines;		/* a Page of Screen line numbers: tlines-4 */

extern char fromhost[];
extern char save_title[];	/* used by editor when inserting */

#endif				/* _GLOBAL_H_ */


int check_post_chars;
extern int check_post_chars;
int this_add_exp;
extern int this_add_exp;
int tran_io;
extern int tran_io;
int if_anonymous;
extern if_anonymous;

