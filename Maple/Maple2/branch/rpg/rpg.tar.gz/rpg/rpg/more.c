/*-------------------------------------------------------*/
/* more.c	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : simple & beautiful ANSI/Chinese browser	 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#include "bbs.h"


static char *more_help[] = {
  "\0�\\Ū�峹�\\����ϥλ���",
  "\01��в��ʥ\\����",
  "(��)(Enter)         �U���@��",
  "(^B)(PgUp)          �W���@��",
  "(��)(PgDn)(Space)   �U���@��",
  "(0) (Home)          �ɮ׶}�Y",
  "($) (End)           �ɮ׵���",
  "\01��L�\\����",
  "(Q)(��)             ����",
  "(h)(H)(?)           ���U�����e��",
NULL};


static int
readln(fp, buf)
  FILE *fp;
  char *buf;
{
  register int ch, i, len, bytes, in_ansi;

  len = bytes = in_ansi = i = 0;
  while (len < 80 && i < ANSILINELEN && (ch = getc(fp)) != EOF)
  {
    bytes++;
    if (ch == '\n')
    {
      break;
    }
    else if (ch == '\t')
    {
      do
      {
	buf[i++] = ' ';
      } while ((++len & 7) && len < 80);
    }
    else if (ch == '\033')
    {
      if (showansi)
	buf[i++] = ch;
      in_ansi = 1;
    }
    else if (in_ansi)
    {
      if (showansi)
	buf[i++] = ch;
      if (!strchr("[0123456789;,", ch))
	in_ansi = 0;
    }
    else if (isprint2(ch))
    {
      len++;
      buf[i++] = ch;
    }
    else if (ch==1 || ch==2 || ch == 3)
    {
      len++;
      buf[i++] = ch;
    }   
  }
  buf[i] = '\0';
  return bytes;
}


int
more(fpath, promptend)
  char *fpath;
  int promptend;
{
  static char *head[3] = {"�@��", "���D", "�ɶ�"};
  char *ptr, *word, buf[256];
  static char s_string[61]="";
  struct stat st;
  FILE *fp;
  usint pagebreak[MAXPAGES], pageno, lino;
  int line, ch, viewed, pos, numbytes;
  register int if_search=0,s_line=1;

  if (!(fp = fopen(fpath, "r")))
    return -1;

  if (fstat(fileno(fp), &st))
    return -1;

  pagebreak[0] = pageno = viewed = line = pos = 0;
  clear();

  while ((numbytes = readln(fp, buf)) || (line == t_lines))
  {
    if (numbytes)		/* �@���ƳB�z */
    {
      if (!viewed)		/* begin of file */
      {
	if (showansi)		/* header processing */
	{
	  if (!strncmp(buf, str_author1, LEN_AUTHOR1))
	  {
	    line = 3;
	    word = buf + LEN_AUTHOR1;
	  }
	  else if (!strncmp(buf, str_author2, LEN_AUTHOR2))
	  {
	    line = 4;
	    word = buf + LEN_AUTHOR2;
	  }

	  while (pos < line)
	  {
	    if (!pos && ((ptr = strstr(word, str_post1)) ||
		(ptr = strstr(word, str_post2))))
	    {
	      ptr[-1] = '\0';
	      prints("[47;34m %s [44;37m%-53.53s[47;34m %.4s [44;37m%-13s[0m\n", head[0], word, ptr, ptr + 5);
	    }
	    else if (pos < 3)
	      prints("[47;34m %s [44;37m%-72.72s[0m\n", head[pos], word);

	    viewed += numbytes;
	    numbytes = readln(fp, buf);
	    pos++;
	  }
	  if (pos)
	  {
	    prints("[36m%s[0m\n", msg_seperator);
	    line = pos = 4;
	  }
	}
	lino = pos;
	word = NULL;
      }

      /* ���B�z�ޥΪ� & �ި� */

      if ((buf[1] == ' ') && (buf[0] == ':' || buf[0] == '>'))
	word = "[36m";
      else if ((buf[0] == '�' && buf[1] == '�') || !strncmp(buf, "==>", 3))
	word = "[32m";

      if (word)
      {
	outs(word);
	outs(buf);
	outs("[0m");
	word = NULL;
      }
      else
      {
	outs(buf);
      }
      outch('\n');

      if (line < b_lines)	/* �@����Ū�� */
	line++;
      if (pos == b_lines)	/* ���ʿù� */
	scroll();
      else
	pos++;

      if (++lino >= b_lines && pageno < MAXPAGES - 1)
      {
	pagebreak[++pageno] = viewed;
	lino = 1;
      }
      viewed += numbytes;	/* �֭pŪ�L��� */
    }
    else
      line = b_lines;		/* end of END */

bobule_search:
    if(if_search)
    {
      if(s_line > 1){
         for(;s_line < b_lines;s_line++)
         {
           if(s_tag(s_line,s_string)){
             continue;
           }
           else{
            if_search = 0;
            s_line++;
            break;  
           }
         }
      }
      else if(s_tag(s_line,s_string))
        continue;
      else
        if_search=0;
    }
    if (line == b_lines && !if_search)
    {
      prints("[0;34;42m �s�� P.%d(%d%%) [31;47m[h][30m�D�U [31m����[PgUp][PgDn][Home][End][30m��в��� [31m[/][30m�j�M [31m��[q][30m���� [0m", pageno, (viewed * 100) / st.st_size);

      while (line == b_lines)
      {
	switch (ch = egetch())
	{
	case 'q':
	case KEY_LEFT:
	  fclose(fp);
	  return 0;

	case ' ':
	case KEY_PGDN:
	case KEY_RIGHT:
	  line = 1;
	  break;

	case '\r':
	case '\n':
	case KEY_DOWN:
	  line = t_lines - 2;
	  break;

	case '$':
	case KEY_END:
	  line = t_lines;
	  break;

	case '0':
	case KEY_HOME:
	  pageno = line = 0;
	  break;

	case '/':
	  if_search = 60-(int)strlen(s_string);
	  sprintf(genbuf,"�j�M�r��(%s): ",s_string);
	  if(getdata(b_lines,0,genbuf,buf,if_search,DOECHO))
	    strcpy(s_string,buf);
	  if(if_search = strlen(s_string) ? 1 : 0)
            line=t_lines-2;
          break;

	case 'h':
	case 'H':
	case '?':
	  show_help(more_help);
	  pageno--;
	  line = 0;
	  break;

	case KEY_PGUP:
	case KEY_UP:
	case Ctrl('B'):
	  if (pageno > 1)
	  {
	    pageno -= 2;
	    line = 0;
	  }
	}
      }

      if (line)
      {
	move(b_lines, 0);
	clrtoeol();
	refresh();
      }
      else
      {
	pos = 0;
	fseek(fp, viewed = pagebreak[pageno], SEEK_SET);
	clear();
      }
    }
  }

  fclose(fp);
  if((s_line == 1) && if_search){
    s_line = 2;
    goto bobule_search;
  }
  
  if (promptend)
  {
    pressanykey();
    clear();
  }
  else
    outs(reset_color);
  if(if_search)
  {
    outmsg("[7mPattern not found  (press RETURN) [m");
    egetch();
  }  
  return 0;
}
