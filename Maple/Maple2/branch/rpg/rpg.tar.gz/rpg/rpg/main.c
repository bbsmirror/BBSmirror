/*-------------------------------------------------------*/
/* main.c	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* author : opus.bbs@bbs.cs.nthu.edu.tw		 	 */
/* target : BBS main/login/top-menu routines	 	 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#define	_MAIN_C_
#define LINELEN (256)   /*bobule add*/

#include "bbs.h"

jmp_buf byebye;

int talkrequest = NA;

static uschar enter_uflag;

#ifdef SHOW_IDLE_TIME
char fromhost[STRLEN - 20] = "\0";
char tty_name[20] = "\0";
#else
char fromhost[STRLEN] = "\0";
#endif

void check_register();
void pickup_user();

/* ----------------------------------------------------- */
/* ���} BBS �{��					 */
/* ----------------------------------------------------- */

void
log_usies(mode, mesg)
  char *mode, *mesg;
{
  FILE *fp;

  if (fp = fopen(FN_USIES, "a"))
  {
    time_t now = time(0);

    if (!mesg)
    {
      sprintf(genbuf, "Stay: %d (%s)",
	(now - login_start_time) / 60, cuser.username);
      mesg = genbuf;
    }

    fprintf(fp, cuser.userid[0] ? "%s %s %-12s %s\n" : "%s %s %s%s\n",
      Cdate(&now), mode, cuser.userid, mesg);
    fclose(fp);
  }
}


static void
setflags(mask, value)
  int mask, value;
{
  if (value)
    cuser.uflag |= mask;
  else
    cuser.uflag &= ~mask;
}


void
u_exit(mode)
  char *mode;
{
  extern void auto_backup();	/* �s�边�۰ʳƥ� */

  auto_backup();

  setflags( PAGER_FLAG, !(currutmp->pager & (PAGER_FLAG >>2)));
  setflags( WRITE_FLAG, !(currutmp->pager & (WRITE_FLAG >>2)));
  if (HAS_PERM(PERM_LOGINCLOAK))
    setflags(CLOAK_FLAG, currutmp->invisible);
  purge_utmp(currutmp);

  if ((cuser.uflag != enter_uflag) || (currmode & MODE_DIRTY))
    substitute_record(fn_passwd, &cuser, sizeof(userec), usernum);
  log_usies(mode, NULL);
}


void
system_abort()
{
  if (currmode)
    u_exit("ABORT");

  clear();
  refresh();
  printf("���¥��{, �O�o�`�ӳ� !\n");
  sleep(1);
  exit(0);
}


void
abort_bbs()
{
  if (currmode)
    u_exit("AXXED");
  exit(0);
}


/* ----------------------------------------------------- */
/* �n�� BBS �{��					 */
/* ----------------------------------------------------- */


int
dosearchuser(userid)
  char *userid;
{
  if (usernum = getuser(userid))
    memcpy(&cuser, &xuser, sizeof(cuser));
  else
    memset(&cuser, 0, sizeof(cuser));    
   
  rpg_read(userid);
  if(in_rpg){
    memcpy(&mine_rpg,&other_rpg,sizeof(mine_rpg));
  }
  else{
    memset(&mine_rpg,0,sizeof(mine_rpg));
    strcpy(mine_rpg.userid,userid);
    mine_rpg.role = -1;  /*����*/
  }
  return usernum;
}


static void
talk_request()
{

#ifdef	LINUX
  /*
   * Linux �U�s�� page ���⦸�N�i�H�����X�h�G �o�O�ѩ�Y�Ǩt�Τ@ nal
   * �i�ӴN�|�N signal handler �]�w�����w�� handler, �������O default �O�N�{
   * erminate. �ѨM��k�O�C�� signal �i�ӴN���] signal handler
   */

  signal(SIGUSR1, talk_request);
#endif

  talkrequest = YEA;
  bell();
  sleep(1);
  bell();
  bell();
}



extern int cmpuids();
extern int i_mode;
int if_called;     /*�p�G�Qcallin,�h�ʺA�i�ܪO���ɶ�refresh����*/
int if_reset;
struct msgrec lastmsg = { "", 0 ,"[1;37;45m                         �ثe�S�����u Call-In�C                     [0m"};

#define	MAX_BACK	5
void
back_msg(todo)  /*0:���W 1:���U: 2:���g */
int todo;
{
  static struct msgrec app_msg[MAX_BACK];
  static int i = 0;
  int j,x,y;
  
  if(todo != 2)  
    getyx(&x,&y);  
  
  switch(todo)
  {
    case 2:
      for(j=MAX_BACK -1;j>0;j--)
        memcpy(&app_msg[j],&app_msg[j-1],sizeof(struct msgrec));
      memcpy(&app_msg[0],&lastmsg,sizeof(struct msgrec));
      return;
    case 0:
      
      if(if_reset)
        i = -1;
      if(!strlen(app_msg[i+1].msg)){
        bell();
        break;
      }
      if( i < (MAX_BACK -1))
        i++;
      else if(i>=(MAX_BACK -1)){
         bell();
         break;
      }
      memcpy(&lastmsg,&app_msg[i],sizeof(struct msgrec));
      if_reset =0;
      if_called = 1;
      break;
    case 1:
      if(!if_reset)
        if(i>0){
         i--;
         memcpy(&lastmsg,&app_msg[i],sizeof(struct msgrec));
         if_called = 1;
         break;
        }
       bell();
  }
  outmsg(lastmsg.msg);
  move(x,y);
  refresh();
} 



static void
write_request()
{
  FILE *fpr;
  char buf[64];
  int x,y;
  
#ifdef	LINUX
  signal(SIGUSR2, write_request);
#endif
  if_called = i_mode;  /*check if idle ,�ϰʵe���|�\��write*/
  setuserfile(buf, fn_write);
  if (fpr = fopen(buf, "r"))
  {
    getyx(&x,&y);
    fscanf(fpr,"%s %d ",lastmsg.userid,&lastmsg.pid);
    fgets(lastmsg.msg, 120, fpr);
    fclose(fpr);
    if(currutmp->mode != CHATING)
      outmsg(lastmsg.msg);
    else
      outtop(lastmsg.msg);
    bell();
    move(x,y);
    refresh();
    back_msg(2);
    if_reset=1;
  }
}


int if_writing; /*�g�T����,�ϰʵe���_��*/

void
write_reply()
{
  FILE *fpr;
  char w_buf[120],tmp0[LINELEN];
  int len,x,y,local_io;
  pid_t piding = lastmsg.pid;  /*�H�K�g�T����,�S�Qwrite,�hlast_pid���ܨo..*/
  char useriding[IDLEN+1];  /*�z�ѦP�W*/
  
  if(currutmp->mode == PAGE) /*page�O�H�ɤ���^�e�T��*/
    return;
  else if(talk_mode)
  {
    if(!io_off){     /*debug ��*/
      io_off = YEA;
      local_io = YEA;
      add_io(0,0);
    }
    else
      local_io = NA;
  }
  r_save(0,tmp0);
  getyx(&x,&y);
  
  if(currutmp->mode != CHATING)
    outmsg(lastmsg.msg);
  else
    outtop(lastmsg.msg);
  if(!lastmsg.pid){
    r_save(1,tmp0);
    move(x,y); 
    refresh();
    if_writing = 0;
    return;
  }
  if_writing=1;
  if_reset  =1;
  strcpy(useriding,lastmsg.userid);
  len=strlen(useriding)>strlen(cuser.userid)?strlen(useriding)+10:strlen(cuser.userid)+10;
 
  sprintf(w_buf,"�^��%s�G",useriding);
  if (getdata(b_lines-1, 0, w_buf, w_buf, 80-len, DOECHO))
  {
      char fpath[80];
      char fpathl[80];
      FILE *fp;
      FILE *wlog;
      struct tm *ptime;
      time_t now;
              
      sethomefile(fpath, useriding, fn_write);
      sethomefile(fpathl, useriding, "write.log");      
      if((fp = fopen(fpath, "w")) && (wlog=fopen(fpathl,"a")))
      {
        time(&now);
        ptime = localtime(&now);    
        sprintf(fpath, "��%s(%2d:%02d)",cuser.userid,ptime->tm_hour,ptime->tm_min);
        fpath[len] = '\0';
        flock(fileno(fp),LOCK_EX);
        flock(fileno(wlog),LOCK_EX);
        fprintf(fp,"%s %d ",cuser.userid,currpid);
        fprintf(fp, "[1;33;46m%s [37;45m%s[0m", fpath, w_buf);
        fprintf(wlog,"[1;33;46m%s [37;45m%s[0m\n", fpath, w_buf);
        flock(fileno(fp),LOCK_UN);
        fclose(fp);
        flock(fileno(wlog),LOCK_UN);
        fclose(wlog);
        if(kill(piding, SIGUSR2) == -1)
        {
          outs(msg_usr_left);
          clrtoeol();
          refresh();
          sleep(1);
        }
      }
  }          
  if_writing=0;
  r_save(1,tmp0);
  move(x,y); 

  if(talk_mode)
    if(local_io){
      io_off = NA;
      add_io(tran_io,0);
    }
  refresh();
}

static void
multi_user_check()
{
  register user_info *ui;
  register pid_t pid;
  int cmpuids();

  if (HAS_PERM(PERM_SYSOP))
    return;			/* don't check sysops */

  if (cuser.userlevel)
  {
    if (!(ui = (user_info *) search_ulist(cmpuids, usernum)))
      return;			/* user isn't logged in */

    pid = ui->pid;
    if (!pid || (kill(pid, 0) == -1))
      return;			/* stale entry in utmp file */

    getdata(0, 0, "�z�Q�R����L���ƪ� login (Y/N)�ܡH[Y] ", genbuf, 3, LCECHO);

    if (genbuf[0] != 'n')
    {
      kill(pid, SIGHUP);
      log_usies("KICK ", cuser.username);
    }
    else
    {
      if (count_multi() >= 2)
	system_abort();		/* Goodbye(); */
    }
  }
  else
  {
    /* allow multiple guest user */
    if (count_multi() > 16)
    {
      outs("��p�A�ثe�w���Ӧh guest, �еy��A�աC");
      pressanykey();
      oflush();
      exit(1);
    }
  }
}

/* --------- */
/* bad login */
/* --------- */

static char str_badlogin[] = "logins.bad";


static void
logattempt(uid, frm)
  char *uid, *frm;
{
  char fname[40];
  int fd, len;

  sprintf(genbuf, "%-12.12s[%s]%s\n", uid, Cdate(&login_start_time), frm);
  len = strlen(genbuf);
  if ((fd = open(str_badlogin, O_WRONLY | O_CREAT | O_APPEND, 0644)) > 0)
  {
    write(fd, genbuf, len);
    close(fd);
  }

  sethomefile(fname, uid, str_badlogin);
  if ((fd = open(fname, O_WRONLY | O_CREAT | O_APPEND, 0644)) > 0)
  {
    write(fd, genbuf, len);
    close(fd);
  }
}


static void
login_query()
{
  char uid[IDLEN + 1], passbuf[PASSLEN],dirbuf[STRLEN+1];
  int attempts;
  int  max_fct;
  FILE *fct_fp;


  resolve_utmp();
  attempts = count_ulist();
  
  if(fct_fp=fopen("etc/fct.max","rb")){
    if(fgets(genbuf,256,fct_fp)){
      fclose(fct_fp);
      sprintf(dirbuf,"man/Announce/%03d",(rand() % atoi(genbuf)) +1);
      if(fct_fp=fopen(dirbuf,"r")){
        if(fgets(dirbuf,ANSILINELEN,fct_fp))
          outs(dirbuf);
        fclose(fct_fp);
    }
    else
      fclose(fct_fp);
    }
  }
   
  prints("�w����{�i[1;37;45m %s [0m�j(�ثe�`�@�� %d �H�W�u)\n", BoardName, attempts);

  if (attempts >= MAXACTIVE)
  {
    outs("�ѩ�H�ƤӦh�A�бz�y��A�ӡC\n");
    oflush();
    sleep(1);
    exit(1);
  }

  attempts = 0;
  while (1)
  {
    if (attempts++ >= LOGINATTEMPTS)
    {
      more("etc/goodbye", NA);
      oflush();
      sleep(1);
      exit(1);
    }

    getdata(0, 0, "\n�п�J�N���A�ΥH[guest]���[�A�H[new]���U�G",
      uid, IDLEN + 1, DOECHO);
    if (ci_strcmp(uid, str_new) == 0)
    {

#ifdef LOGINASNEW
      new_register();
      break;
#else
      outs("���t�Υثe�L�k�H new ���U, �Х� guest �i�J\n");
      continue;
#endif
    }
    else if (uid[0] == '\0' || !dosearchuser(uid))
    {
      outs(err_uid);
    }
    else if (strcmp(uid, STR_GUEST))
    {
      getdata(0, 0, MSG_PASSWD, passbuf, PASSLEN, NOECHO);
      passbuf[8] = '\0';

      if (!checkpasswd(cuser.passwd, passbuf))
      {
	logattempt(cuser.userid, fromhost);
	outs(ERR_PASSWD);
      }
      else
      {
	/* SYSOP gets all permission bits */

	if (!ci_strcmp(cuser.userid, str_sysop))
	  cuser.userlevel = ~0;
	break;
      }
    }
    else
    {				/* guest */
      cuser.userlevel = 0;
      cuser.uflag = COLOR_FLAG | PAGER_FLAG | BRDSORT_FLAG | MOVIE_FLAG | WRITE_FLAG;
      mine_rpg.role = 0;
      break;
    }
  }

  multi_user_check();
  if (!term_init(cuser.termtype))
  {
    outs("�׺ݾ����A���~�I�w�]�� [vt100]\n");
    term_init("vt100");
  }

  sethomepath(genbuf, cuser.userid);
  mkdir(genbuf, 0755);
}


void
setup_utmp(mode)
  int mode;
{
  user_info uinfo;

  memset(&uinfo, 0, sizeof(uinfo));
  uinfo.pid = currpid = getpid();
  uinfo.uid = usernum;
  uinfo.mode = currstat = mode;
  uinfo.role = mine_rpg.role;
  uinfo.exp = mine_rpg.exp;
  uinfo.level = mine_rpg.level;
  uinfo.hp = mine_rpg.hp;
  uinfo.mp = mine_rpg.mp;
  uinfo.fp = mine_rpg.fp;
  uinfo.money = mine_rpg.money;
  this_add_exp = mine_rpg.exp;

  strcpy(uinfo.userid, cuser.userid);
  strcpy(uinfo.realname, cuser.realname);
  strcpy(uinfo.username, cuser.username);
  strncpy(uinfo.from, fromhost, 28);
  

#ifdef SHOW_IDLE_TIME
  strcpy(uinfo.tty, tty_name);
#endif

  if (enter_uflag & CLOAK_FLAG)
  {
    if (HAS_PERM(PERM_LOGINCLOAK))
      uinfo.invisible = YEA;
    else
      cuser.uflag ^= CLOAK_FLAG;
  }
  uinfo.pager = ((~enter_uflag) & (PAGER_FLAG | WRITE_FLAG)) >> 2;
  getnewutmpent(&uinfo);
  friend_load();
}


static void
user_login()
{
  char ans[4];
  extern friendcount;

  log_usies("ENTER", fromhost);

  /* ------------------------ */
  /* ��l�� uinfo�Bflag�Bmode */
  /* ------------------------ */

  enter_uflag = cuser.uflag;

#ifdef	INITIAL_SETUP
  if (!getbnum(DEFAULT_BOARD))
  {
    strcpy(currboard, "�|����w");
  }
  else
#endif

  {
    brc_initial(DEFAULT_BOARD);
    set_board();
  }

  setup_utmp(LOGIN);
  currmode = MODE_STARTED;

  /* ------------ */
  /* �e���B�z�}�l */
  /* ------------ */

  initscr();
/*  more("Welcome", NA); bobule delete*/

/*  more(fn_note_ans, YEA);*/
  login_note();
  more("etc/day",NA);
  
  cuser.lastlogin = login_start_time;

  if (cuser.userlevel)		/* not guest */
  {
    move(t_lines - 2, 0);
    prints("  �z�� [1;33m%d[0;37m �׫��X�A\
�W���� [1;33m%s[0;37m\
�q [1;33m%s[0;37m �W���C",
      ++cuser.numlogins, Cdate(&cuser.lastlogin),cuser.lasthost);
    pressanykey();

    setuserfile(genbuf, str_badlogin);
    if (more(genbuf, NA) != -1)
    {
      getdata(b_lines, 0, "�z�n�R���H�W���~���ժ��O����(Y/N)?[Y]",
	ans, 3, LCECHO);
      if (*ans != 'n')
	unlink(genbuf);
    }
    check_register();
    strncpy(cuser.lasthost, fromhost, 16);
    cuser.lasthost[15] = '\0';

    restore_backup();
    
  }
  else
    pressanykey();
  substitute_record(fn_passwd, &cuser, sizeof(cuser), usernum);

}


void
main(argc, argv)
  int argc;
  char **argv;
{
  int getin;

  extern struct commands cmdlist[];
  extern friendcount;

  /* ----------- */
  /* system init */
  /* ----------- */

  currmode = 0;
  srand(login_start_time = time(0));

  if (argc > 1)
  {
    strncpy(fromhost, argv[1], 60);

#ifdef SHOW_IDLE_TIME
    if (argc > 2)
      strcpy(tty_name, argv[2]);
#endif
  }

  signal(SIGHUP, abort_bbs);
  signal(SIGBUS, abort_bbs);
  signal(SIGSEGV, abort_bbs);
  signal(SIGSYS, abort_bbs);

  signal(SIGINT, SIG_IGN);
  signal(SIGQUIT, SIG_IGN);
  signal(SIGPIPE, SIG_IGN);
  signal(SIGTERM, SIG_IGN);

  signal(SIGURG, SIG_IGN);
  signal(SIGTSTP, SIG_IGN);
  signal(SIGTTIN, SIG_IGN);
  signal(SIGTTOU, SIG_IGN);

  signal(SIGUSR1, talk_request);
  signal(SIGUSR2, write_request);

  if (setjmp(byebye))
    abort_bbs();
  init_tty();
  login_query();
  user_login();

  m_init();

#ifdef	SIMPLE_VOTE
  if (HAVE_PERM(PERM_SYSOP))
#else
  if (HAVE_PERM(PERM_SYSOP | PERM_BM))
#endif

    b_closepolls();

  if (!(cuser.uflag & COLOR_FLAG))
    showansi = 0;

#ifdef DOTIMEOUT
  init_alarm();
#else
  signal(SIGALRM, SIG_IGN);
#endif
    
    if(!(cuser.uflag & CLOAK_FLAG))
      do_assign();
    if (friendcount)
    {
      setutmpmode(FRIEND);
      pickup_user();
    }
  domenu(MMENU, "�D�\\���", (chkmail(0) ? 'M' : 'C'), cmdlist);
}
