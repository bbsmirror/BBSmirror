/*-------------------------------------------------------*/
/* xyz.c	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : system toolbox routines		 	 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#include "bbs.h"

#ifdef	HAVE_GAME
#define	MAX_SCORE	20 
struct wormrec          /*����ιC��*//*robot�C��*/
{
  char userid[IDLEN + 1];
  time_t playtime;
  char lasthost[16];
  int u_score;
};
typedef struct wormrec wormrec;

struct tetrisrec          /*�Xù�����*/
{
  char userid[IDLEN + 1];
  time_t playtime;
  char lasthost[16];
  int u_score;
  int u_level;
  int u_rkill;
};
typedef struct tetrisrec tetrisrec;


#endif

/* ----------------------------------------------------- */
/* �U�زέp�ά�����T�C��				 */
/* ----------------------------------------------------- */


int
x_user()
{
  more("etc/topusr", YEA);
  return 0;
}


int
x_note()
{
  more(fn_note_ans, YEA);
  return 0;
}


int
x_issue()
{
  more("etc/day", YEA);
  return 0;
}


int
x_week()
{
  more("etc/week", YEA);
  return 0;
}


int
x_today()
{
  more("etc/today", YEA);
  return 0;
}


int
x_yesterday()
{
  more("etc/yesterday", YEA);
  return 0;
}


#ifdef HAVE_INFO
x_program()
{
  more("Version", YEA);
  return 0;
}
#endif


#ifdef HAVE_License
x_gpl()
{
  more("GPL", YEA);
  return 0;
}
#endif


int
Welcome()
{
  more("Welcome", YEA);
  return 0;
}


/* ----------------------------------------------------- */
/* ���} BBS ��						 */
/* ----------------------------------------------------- */


static void
note()
{
  static char *fn_note_tmp = "note.tmp";
  static char *fn_note_dat = "note.dat";
  int total, i, collect, len;
  struct stat st;
  char buf[256], buf2[80], *p;
  int fd, fx;
  FILE *fp, *foo;

  struct notedata
  {
    time_t date;
    char userid[IDLEN + 1];
    char username[19];
    char buf[3][80];
  };
  struct notedata myitem;

  do
  {
    myitem.buf[0][0] = myitem.buf[1][0] = myitem.buf[2][0] = '\0';
    move(12, 0);
    clrtobot();
    outs("\n�Яd�� (�ܦh�T��)�A��[Enter]����");
    for (i = 0; (i < 3) &&
      getdata(16 + i, 0, "�G", myitem.buf[i], 78, DOECHO); i++);
    getdata(b_lines, 0, "(S)�x�s (E)���s�ӹL (Q)�����H[S] ", buf, 3, LCECHO);
    if (buf[0] == 'q' || i == 0)
      return;
  } while (buf[0] == 'e');

  strcpy(myitem.userid, cuser.userid);
  strncpy(myitem.username, cuser.username, 18);
  myitem.username[18] = '\0';
  time(&(myitem.date));

  /* begin load file */

  if ((foo = fopen(".note", "a")) == NULL)
    return;

  if ((fp = fopen(fn_note_ans, "w")) == NULL)
    return;

  if ((fx = open(fn_note_tmp, O_WRONLY | O_CREAT, 0644)) <= 0)
    return;

  if ((fd = open(fn_note_dat, O_RDONLY)) == -1)
  {
    total = 1;
  }
  else if (fstat(fd, &st) != -1)
  {
    total = st.st_size / sizeof(struct notedata) + 1;
    if (total > MAX_NOTE)
      total = MAX_NOTE;
  }

  fputs("\t\t\t[37;45m �� �� �� �W �� �d �� �O �� \n\n", fp);
  collect = 1;

  while (total)
  {
    sprintf(buf, "[1;37;46m�W[47;34m %s [33m(%s)",
      myitem.userid, myitem.username);
    len = strlen(buf);
    strcat(buf, " [30;46m" + (len & 1));

    for (i = len >> 1; i < 41; i++)
      strcat(buf, "�e");
    sprintf(buf2, "[47;34m %.14s [37;46m�W[0m\n",
      Cdate(&(myitem.date)));
    strcat(buf, buf2);
    fputs(buf, fp);

    if (collect)
      fputs(buf, foo);

    sprintf(buf, "%s\n%s\n%s\n", myitem.buf[0], myitem.buf[1], myitem.buf[2]);
    fputs(buf, fp);

    if (collect)
    {
      fputs(buf, foo);
      fclose(foo);
      collect = 0;
    }

    write(fx, &myitem, sizeof(myitem));

    if (--total)
      read(fd, (char *) &myitem, sizeof(myitem));
  }
  fclose(fp);
  close(fd);
  close(fx);
  rename(fn_note_tmp, fn_note_dat);
  more(fn_note_ans, NA);
}

void 
login_note()
{
  static char *fn_note_dat = "note.dat";
  static char *fn_note_tmp = "note.tmp";
  int fd;
  FILE *fp,*foo;
  char buf[256],fpath[80];
  
  struct notedata
  {
    time_t date;
    char userid[IDLEN + 1];
    char username[19];
    char buf[3][80];
  };
  struct notedata myitem;
  
  
  if ((fd = open(fn_note_dat, O_RDONLY)) != -1)
  {
    if((read(fd, (char *) &myitem, sizeof(myitem))==sizeof(myitem)) && (myitem.date > cuser.lastlogin))
    {
      if(fp=fopen(fn_note_ans,"r"))
      {
        sethomefile(fpath,cuser.userid,fn_note_tmp);
        if(foo=fopen(fpath,"w"))
        {
          int i;
          if(fgets(buf,256,fp));
            fputs(buf,foo);
          if(fgets(buf,256,fp));
            fputs(buf,foo);
          do
          {
            for(i=0;i<4;i++){
              if(!fgets(buf,256,fp))
                break;
              fputs(buf,foo);
            }
          }
          while((read(fd, (char *) &myitem, sizeof(myitem))==sizeof(myitem)) && (myitem.date > cuser.lastlogin));
          fclose(foo);
        }
        fclose(fp);
        more(fpath,YEA);
      }
    }
    close(fd);
  }
}


static void
mail_sysop()
{
  FILE *fp;

  if (fp = fopen("etc/sysop", "r"))
  {
    int i, j;
    char *ptr;

    struct SYSOPLIST
    {
      char userid[IDLEN + 1];
      char duty[40];
    }         sysoplist[9];

    j = 0;
    while (fgets(genbuf, 128, fp))
    {
      if (ptr = strchr(genbuf, '\n'))
      {
	*ptr = '\0';
	if (ptr = strchr(genbuf, ':'))
	{
	  *ptr = '\0';
	  do
	  {
	    i = *++ptr;
	  } while (i == ' ' || i == '\t');
	  if (i)
	  {
	    strcpy(sysoplist[j].userid, genbuf);
	    strcpy(sysoplist[j++].duty, ptr);
	  }
	}
      }
    }

    move(12, 0);
    clrtobot();
    prints("%16s   %-18s�v�d����\n%s\n", "�s��", "���� ID", msg_seperator);

    for (i = 0; i < j; i++)
    {
      prints("%15d.   [1;%dm%-16s%s[0m\n",
	i + 1, 31 + i % 7, sysoplist[i].userid, sysoplist[i].duty);
    }
    prints("%-14s0.   [1;%dm���}[0m", "", 31 + j % 7);
    getdata(b_lines, 0, "�п�J�N�X[0]�G", genbuf, 4, DOECHO);
    i = genbuf[0] - '0' - 1;
    if (i >= 0 && i < j)
    {
      clear();
      do_send(sysoplist[i].userid, NULL);
    }
  }
}


int
Goodbye()
{
  extern void movie();

  getdata(b_lines, 0, "�z�T�w�n���}�i " BOARDNAME " �j��(Y/N)�H[N] ",
    genbuf, 3, LCECHO);

  if (*genbuf != 'y')
    return (XEASY + 1);

  movie(999);
  if (cuser.userlevel)
  {
    getdata(b_lines, 0, "(R)�����F�աA���٭n�� (G)�A�O�j��] (M)���i�j��] (N)��]�d���O�H[G] ",
      genbuf, 3, LCECHO);
    if (genbuf[0] == 'm')
      mail_sysop();
    else if (genbuf[0] == 'n')
      note();
    else if(genbuf[0] == 'r' )
    {
      movie(1);
      return (XEASY + 1);
    }
  }

  clear();
  prints("[1;36m�˷R�� [33m%s(%s)[36m�A�O�ѤF�A�ץ��{[45;33m"
    " %s [40;36m�I\n�H�U�O�z�b���������U���:[0m\n",
    cuser.userid, cuser.username, BoardName);
  user_display(&cuser, 0);
  
  setuserfile(genbuf, "write.log");
  unlink(genbuf);
      

  if (currmode)
    u_exit("EXIT ");

  pressanykey();
  sleep(1);
  reset_tty();
  exit(0);
}


/* ----------------------------------------------------- */
/* �䴩�~���{�� : tin�Bgopher�Bwww�Bbbsnet�Bgame�Bcsh	 */
/* ----------------------------------------------------- */


#ifdef HAVE_EXTERNAL
#define LOOKFIRST	(0)
#define LOOKLAST	(1)
#define QUOTEMODE	(2)
#define MAXPATHLEN      (128)
#define MAXCOMSZ	(1024)
#define MAXARGS		(40)
#define MAXENVS		(20)
#define BINDIR		"bin/"

char *bbsenv[MAXENVS];
int numbbsenvs = 0;


int
bbssetenv(env, val)
  char *env, *val;
{
  register int i, len;
  extern char *malloc();

  if (numbbsenvs == 0)
    bbsenv[0] = NULL;
  len = strlen(env);
  for (i = 0; bbsenv[i]; i++)
    if (!ci_strncmp(env, bbsenv[i], len))
      break;
  if (i >= MAXENVS)
    return -1;
  if (bbsenv[i])
    free(bbsenv[i]);
  else
    bbsenv[++numbbsenvs] = NULL;
  bbsenv[i] = malloc(strlen(env) + strlen(val) + 2);
  strcpy(bbsenv[i], env);
  strcat(bbsenv[i], "=");
  strcat(bbsenv[i], val);
}


int
do_exec(com, wd)
  char *com, *wd;
{
  char path[MAXPATHLEN];
  char pcom[MAXCOMSZ];
  char *arglist[MAXARGS];
  char *tz;
  register int i, len;
  register int argptr;
  register char *lparse;
  int status, w;
  pid_t pid;
  int pmode;
  void (*isig) (), (*qsig) ();

  strncpy(path, BINDIR, MAXPATHLEN);
  strncpy(pcom, com, MAXCOMSZ);
  len = MIN(strlen(com) + 1, MAXCOMSZ);
  pmode = LOOKFIRST;
  for (i = 0, argptr = 0; i < len; i++)
  {
    if (pcom[i] == '\0')
      break;
    if (pmode == QUOTEMODE)
    {
      if (pcom[i] == '\001')
      {
	pmode = LOOKFIRST;
	pcom[i] = '\0';
	continue;
      }
      continue;
    }
    if (pcom[i] == '\001')
    {
      pmode = QUOTEMODE;
      arglist[argptr++] = &pcom[i + 1];
      if (argptr + 1 == MAXARGS)
	break;
      continue;
    }
    if (pmode == LOOKFIRST)
      if (pcom[i] != ' ')
      {
	arglist[argptr++] = &pcom[i];
	if (argptr + 1 == MAXARGS)
	  break;
	pmode = LOOKLAST;
      }
      else
	continue;
    if (pcom[i] == ' ')
    {
      pmode = LOOKFIRST;
      pcom[i] = '\0';
    }
  }
  arglist[argptr] = NULL;
  if (argptr == 0)
    return -1;
  if (*arglist[0] == '/')
    strncpy(path, arglist[0], MAXPATHLEN);
  else
    strncat(path, arglist[0], MAXPATHLEN);
  reset_tty();
  alarm(0);
  if ((pid = vfork()) == 0)
  {
    if (wd)
      if (chdir(wd))
      {
	fprintf(stderr, "Unable to chdir to '%s'\n", wd);
	exit(-1);
      }
    bbssetenv("PATH", "/bin:.");
    bbssetenv("TERM", cuser.termtype);
    bbssetenv("USER", cuser.userid);
    bbssetenv("USERNAME", cuser.username);
    /* added for tin's HOME and EDITOR */
    sprintf(genbuf, "/home/%s", cuser.userid);
    bbssetenv("HOME", genbuf);
    bbssetenv("EDITOR", "/bin/ve");
    /* end */
    /* added for tin's reply to */
    bbssetenv("REPLYTO", cuser.email);
    bbssetenv("FROMHOST", fromhost);
    /* end of insertion */
    if ((tz =(char *)getenv("TZ")) != NULL)
      bbssetenv("TZ", tz);
    if (numbbsenvs == 0)
      bbsenv[0] = NULL;
    execve(path, arglist, bbsenv);
    fprintf(stderr, "EXECV FAILED... path = '%s'\n", path);
    exit(-1);
  }
  isig = signal(SIGINT, SIG_IGN);
  qsig = signal(SIGQUIT, SIG_IGN);
  while ((w = wait(&status)) != pid && w != 1)
     /* NULL STATEMENT */ ;
  signal(SIGINT, isig);
  signal(SIGQUIT, qsig);
  restore_tty();

#ifdef DOTIMEOUT
  alarm(IDLE_TIMEOUT);
#endif

  return ((w == -1) ? w : status);
}


int
exec_cmd(umode, pager, cmdfile, mesg)
  char *cmdfile, *mesg;
{
  char buf[64];
  int save_pager;

  if (!dashf(cmdfile))
  {
    move(2, 0);
    prints("�ܩ�p, ���������� %s (%s) �\\��.", mesg, cmdfile);
    return 0;
  }
  save_pager = currutmp->pager;
  if (pager == NA)
  {
    currutmp->pager = pager;
  }
  setutmpmode(umode);
  sprintf(buf, "/bin/sh %s", cmdfile);
  reset_tty();
  do_exec(buf, NULL);
  restore_tty();
  currutmp->pager = save_pager;
  clear();
  return 0;
}


#ifdef HAVE_TIN
x_tin()
{
  return exec_cmd(XMODE, YEA, "bin/tin.sh", "TIN");
}
#endif


#ifdef HAVE_GOPHER
x_gopher()
{
  return exec_cmd(XMODE, YEA, "bin/gopher.sh", "GOPHER");
}
#endif


#ifdef HAVE_WWW
x_www()
{
  return exec_cmd(XMODE, NA, "bin/www.sh", "WWW");
}
#endif				/* HAVE_WWW */


#ifdef HAVE_IRC
x_irc()
{
  return exec_cmd(XMODE, NA, "bin/irc.sh", "IRC");
}
#endif				/* HAVE_IRC */


#ifdef	HAVE_ADM_SHELL
x_csh()
{
  int save_pager;

  clear();
  refresh();
  reset_tty();
  save_pager = currutmp->pager;
  currutmp->pager = NA;

#ifdef	HAVE_REPORT
  report("shell out");
#endif

#ifdef SYSV
  do_exec("sh", NULL);
#else
  do_exec("csh", NULL);
#endif

  restore_tty();
  currutmp->pager = save_pager;
  clear();
  return 0;
}
#endif				/* NO_ADM_SHELL */


#ifdef HAVE_BBSDOORS
int
x_bbsnet()			/* Bill Schwartz */
{
/*  int save_pager = currutmp->pager;*/

/*  currutmp->pager = NA;*/

  setutmpmode(BBSNET);
  /* bbsnet.sh is a shell script that can be customized without */
  /* having to recompile anything.  If you edit it while someone */
  /* is in bbsnet they will be sent back to the xyz menu when they */
  /* leave the system they are currently in. */

  reset_tty();
  do_exec("bbsnet.sh", NULL);
  restore_tty();
/*  currutmp->pager = save_pager;*/
  clear();
  return 0;
}

x_big2()
{

  setutmpmode(BIG2);
  reset_tty();
  do_exec("big2.sh", NULL);
  restore_tty();
  clear();
  refresh();
  return 0;
}


x_qkmj()
{

  setutmpmode(QKMJ);
  reset_tty();
  do_exec("qkmj.sh", NULL);
  restore_tty();
  clear();
  refresh();
  return 0;
}

x_good()
{

  setutmpmode(GOOD);
  reset_tty();
  do_exec("main.sh", NULL);
  restore_tty();
  clear();
  refresh();
  return 0;
}


#endif

#ifdef HAVE_GAME

x_worm()
{
  setutmpmode(WORM);
  reset_tty();
  do_exec("worm.sh", NULL);
  restore_tty();
  clear();
  refresh();
  game_score(0);  /*0: show worm score*/
  return 0;
}

x_robot()
{
  setutmpmode(ROBOT);
  reset_tty();
  do_exec("robot.sh", NULL);
  restore_tty();
  clear();
  refresh();
  game_score(1);  /*1: show robot score*/
  return 0;
}


x_tetris()
{
  setutmpmode(TETRIS);
  reset_tty();
  do_exec("tetris.sh", NULL);
  restore_tty();
  clear();
  refresh();
  game_score(2);  /*1: show robot score*/
  return 0;
}



int
score_cmp(b, a)
struct wormrec *a, *b;
{
  return (a->u_score - b->u_score);
}  

int
tetris_cmp(b, a)
struct tetrisrec *a, *b;
{
  return (a->u_score - b->u_score);
}  





game_score(swi)
int swi;
{

  FILE *fp;
  int score=0,level=0,rkill=0;
  int i,j;
  struct wormrec allman[MAX_SCORE+1];
  struct tetrisrec alltetris[MAX_SCORE+1];

  switch(swi){
     
     case 0:
       if(fp=fopen("etc/worm.tmp","r"))
       {
          fread(&score,sizeof(int),1,fp);
          fclose(fp);
       }
       unlink("etc/worm.tmp");
       
       break;
       
    case 1:
       if(fp=fopen("etc/robot.tmp","r"))
       {
          fread(&score,sizeof(int),1,fp);
          fclose(fp);
       }
       unlink("etc/robot.tmp");
       break;
       
    case 2:
       if(fp=fopen("etc/tetris.tmp","r"))
       {
          fscanf(fp,"%d %d %d ",&score,&level,&rkill);
          fclose(fp);
       }    
       unlink("etc/tetris.tmp");
       break;
  }
    
  
  switch(swi){
     case 0:
             if((fp=fopen("etc/worm.score","r+")) == NULL)
               fp=fopen("etc/worm.score","w");
             for(i=0;i<MAX_SCORE;i++)
               if(fread(&allman[i],sizeof(struct wormrec),1,fp) == NULL)
                 break;

             strcpy(allman[i].userid, cuser.userid);
             allman[i].playtime = time(0);
             strcpy(allman[i].lasthost, cuser.lasthost);
             allman[i].u_score = score;   
             	   
             qsort(allman, i+1, sizeof(struct wormrec), score_cmp);
             rewind(fp);
             for(j=0;j<i+1 && j<MAX_SCORE;j++)             
               fwrite(&allman[j],sizeof(struct wormrec),1,fp);
             fclose(fp);
             clear();
             prints("yours final score is: %d\n",score);
             prints("%-12s%-15.10s%-17.16s%s\n","    �ϥΪ�","    Score","    from","    �ɶ�");
             for(j=0;j<i+1 && j<MAX_SCORE;j++)
             {
               sprintf(genbuf,"%-12s%-15.10d%-17.16s%s",allman[j].userid,
               allman[j].u_score,allman[j].lasthost,ctime(&allman[j].playtime));
               prints("%02d. %s",j+1,genbuf);
             }
             pressanykey(); 
             break;
             
     case 1:
             if((fp=fopen("etc/robot.score","r+"))==NULL)
               fp=fopen("etc/robot.score","w");
             for(i=0;i<MAX_SCORE;i++)
             	 if(fread(&allman[i],sizeof(struct wormrec),1,fp) == NULL)
             	    break;

             strcpy(allman[i].userid, cuser.userid);
             allman[i].playtime = time(0);
             strcpy(allman[i].lasthost, cuser.lasthost);
             allman[i].u_score = score;   
             	   
             qsort(allman, i+1, sizeof(struct wormrec), score_cmp);
             rewind(fp);
             for(j=0;j<i+1 && j<MAX_SCORE;j++)
             	 fwrite(&allman[j],sizeof(struct wormrec),1,fp);
            fclose(fp);
            clear();
            prints("yours final score is: %d\n",score);
            prints("%-12s%-15.10s%-17.16s%s\n","    �ϥΪ�","    Score","    from","    �ɶ�");
            for(j=0;j<i+1 && j<MAX_SCORE;j++)
            {
              sprintf(genbuf,"%-12s%-15.10d%-17.16s%s",allman[j].userid,
              allman[j].u_score,allman[j].lasthost,ctime(&allman[j].playtime));
              prints("%02d. %s",j+1,genbuf);
            }
            pressanykey(); 
            break;


     case 2:
             if((fp=fopen("etc/tetris.score","r+")) == NULL )
               fp=fopen("etc/tetris.score","w");
             for(i=0;i<MAX_SCORE;i++)
             	if(fread(&alltetris[i],sizeof(struct tetrisrec),1,fp) == NULL)
             	    break;

             strcpy(alltetris[i].userid, cuser.userid);
             alltetris[i].playtime = time(0);
             strcpy(alltetris[i].lasthost, cuser.lasthost);
             alltetris[i].u_score = score;  
             alltetris[i].u_level = level;
             alltetris[i].u_rkill = rkill;
             	   
             qsort(alltetris, i+1, sizeof(struct tetrisrec), tetris_cmp);
             rewind(fp);
             for(j=0;j<i+1 && j<MAX_SCORE;j++)
               fwrite(&alltetris[j],sizeof(struct tetrisrec),1,fp);
             fclose(fp);
             clear();
             prints("yours final score: %d  level: %d  row: %d\n",score,level,rkill);
             prints("%-12s%-9.9s %-10.10s %-5.5s%-17.16s%s\n",
             "    �ϥΪ�","    Score","    level","row","from","�ɶ�");
            for(j=0;j<i+1 && j<MAX_SCORE;j++)
             {
               sprintf(genbuf,"%-12s%-9.9d %-3.3d    %-4.4d %-17.16s%s",alltetris[j].userid,
               alltetris[j].u_score,alltetris[j].u_level,alltetris[j].u_rkill,
               alltetris[j].lasthost,ctime(&alltetris[j].playtime));
               prints("%02d. %s",j+1,genbuf);
             }
             pressanykey(); 
             break;
             
             
             
             
  }
  return 0;
}



#endif


#ifdef HAVE_EXAMPLE
x_game()
{
  int save_pager = currutmp->pager;

  currutmp->pager = NA;

  setutmpmode(BBSNET);
  /* bbsnet.sh is a shell script that can be customized without */
  /* having to recompile anything.  If you edit it while someone */
  /* is in bbsnet they will be sent back to the xyz menu when they */
  /* leave the system they are currently in. */

  reset_tty();
  do_exec("game.sh", NULL);
  restore_tty();
  currutmp->pager = save_pager;
  clear();
  return 0;
}
#endif				/* HAVE_GAME */

#endif				/* HAVE_EXTERNAL */
