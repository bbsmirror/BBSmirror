
/* talk.c	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : talk/quety/friend routines		 	 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/

#define	_MODES_C_


#include "bbs.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/ipc.h>
#include <sys/shm.h>


#ifdef lint
#include <sys/uio.h>
#endif


#define M_INT 15		/* monitor mode update interval */
#define P_INT 20		/* interval to check for page req. in
				 * talk/chat */

#define	FRIEND_OVERRIDE	0
#define	FRIEND_REJECT	1
#define FRIEND_ASSIGN   2


struct talk_win
{
  int curcol, curln;
  int sline, eline;
};


typedef struct
{
  user_info *ui;
  time_t idle;
  usint friend;
}      pickup;


extern int bind( /* int,struct sockaddr *, int */ );
extern struct UTMPFILE *utmpshm;


/* -------------------------- */
/* �O�� friend �� user number */
/* -------------------------- */

#define PICKUP_WAYS	4
int pickup_way = 0;
int friendcount;
int friends_number;
int override_number;
char *fcolor[4] = {"", "[1;32m", "[1;33m", "[1;37m"};


char *talk_uent_buf;
char save_page_requestor[40];
char page_requestor[40];


void friend_load();


char *
modestring(uentp, simple)
  user_info *uentp;
  int simple;
{
  static char modestr[40];
  register int mode = uentp->mode;
  register char *word;

  word = ModeTypeTable[mode];
  if (simple)
    return (word);

  if (uentp->in_chat)
    sprintf(modestr, "%s (%s)", word, uentp->chatid);
  else if (mode != TALK && mode != PAGE && mode != QUERY)
    return (word);
  else if (mode != QUERY && !HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
    return (word);
  else
    sprintf(modestr, "%s [%s]", word, getuserid(uentp->destuid));

  return (modestr);
}


int
cmpuids(uid, urec)
  int uid;
  user_info *urec;
{
  return (uid == urec->uid);
}


static int
cmpunums(unum, up)
  int unum;
  user_info *up;
{
  if (up->pid)
    return (unum == up->destuid);
  return 0;
}


/* ------------------------------------- */
/* routines for Talk->Friend		 */
/* ------------------------------------- */


static int
can_override(userid, whoasks)
  char *userid;
  char *whoasks;
{
  char buf[STRLEN];

  sethomefile(buf, userid, fn_overrides);
  return belong(buf, whoasks);
}


static int
is_friend(ui)
  user_info *ui;
{
  register ushort unum, hit, *myfriends;

  /* �P�_���O�_���ڪ��B�� ? */

  unum = ui->uid;
  myfriends = currutmp->friend;
  while (hit = *myfriends++)
  {
    if (unum == hit)
    {
      hit = 1;
      friends_number++;
      break;
    }
  }

  /* �P�_�ڬO�_����誺�B�� ? */

  myfriends = ui->friend;
  while (unum = *myfriends++)
  {
    if (unum == usernum)
    {
      override_number++;
      hit |= 2;
      break;
    }
  }
  return hit;
}


static int
is_rejected(userid)
  char *userid;
{
  char buf[STRLEN];

  sethomefile(buf, userid, fn_reject);
  return belong(buf, cuser.userid);
}


/* ------------------------------------- */
/* �u��ʧ@				 */
/* ------------------------------------- */


static char *friend_file[3];
static char *friend_desc[3] = {"�ͽ˴y�z�G", "�c�δc���G","�Ƨѿ��G"};
static char *friend_list[3] = {"�n�ͦW��", "�¦W��","�W���q���W��"};

static void
assign_add(uident)
  char *uident;
{
  char fpath[80];

  setuserfile(fpath,"my_assign");

  if ((uident[0] > ' ') && !belong(fpath, uident))
  {
    FILE *fp;
    char buf[40];
    char t_uident[IDLEN + 1];
    strcpy(t_uident, uident);	/* Thor: avoid uident run away when get data */

    getdata(2, 0, friend_desc[2], buf, 40, DOECHO);
    if (fp = fopen(fpath, "a"))
    {
      flock(fileno(fp), LOCK_EX);
      fprintf(fp, "%-13s%s\n", t_uident, buf);
      flock(fileno(fp), LOCK_UN);
      fclose(fp);
    }
    sethomefile(fpath,t_uident,"to_assign");
    if (fp = fopen(fpath, "a"))
    {
      flock(fileno(fp), LOCK_EX);
      fprintf(fp, "%-13s\n", cuser.userid);
      flock(fileno(fp), LOCK_UN);
      fclose(fp);
    }
  }
}

static void
friend_add(uident, type)
  char *uident;
  int type;
{
  char fpath[80];

  setuserfile(fpath, friend_file[type]);

  if ((uident[0] > ' ') && !belong(fpath, uident))
  {
    FILE *fp;
    char buf[40];
    char t_uident[IDLEN + 1];
    strcpy(t_uident, uident);	/* Thor: avoid uident run away when get data */

    getdata(2, 0, friend_desc[type], buf, 40, DOECHO);
    if (fp = fopen(fpath, "a"))
    {
      flock(fileno(fp), LOCK_EX);
      fprintf(fp, "%-13s%s\n", t_uident, buf);
      flock(fileno(fp), LOCK_UN);
      fclose(fp);
    }
  }
}

static void
assign_delete(uident)
  char *uident;
{
  FILE *fp, *nfp;
  char fn[80], fnnew[80];

  setuserfile(fn, "my_assign");
  sprintf(fnnew, "%s-", fn);
  if ((fp = fopen(fn, "r")) && (nfp = fopen(fnnew, "w")))
  {
    int length = strlen(uident);

    while (fgets(genbuf, STRLEN, fp))
    {
      if ((genbuf[0] > ' ') && strncmp(genbuf, uident, length))
	fputs(genbuf, nfp);
    }
    fclose(fp);
    fclose(nfp);
    rename(fnnew, fn);
  }
  sethomefile(fn,uident,"to_assign");
  sprintf(fnnew, "%s-", fn);
  if ((fp = fopen(fn, "r")) && (nfp = fopen(fnnew, "w")))
  {
    int length = strlen(cuser.userid);

    while (fgets(genbuf, STRLEN, fp))
    {
      if ((genbuf[0] > ' ') && strncmp(genbuf, cuser.userid, length))
	fputs(genbuf, nfp);
    }
    fclose(fp);
    fclose(nfp);
    rename(fnnew, fn);
  }  
}


static void
friend_delete(uident, type)
  char *uident;
  int type;
{
  FILE *fp, *nfp;
  char fn[80], fnnew[80];

  setuserfile(fn, friend_file[type]);
  sprintf(fnnew, "%s-", fn);
  if ((fp = fopen(fn, "r")) && (nfp = fopen(fnnew, "w")))
  {
    int length = strlen(uident);

    while (fgets(genbuf, STRLEN, fp))
    {
      if ((genbuf[0] > ' ') && strncmp(genbuf, uident, length))
	fputs(genbuf, nfp);
    }
    fclose(fp);
    fclose(nfp);
    rename(fnnew, fn);
  }
}


static void
friend_query(uident, type)
  char *uident;
  int type;
{
  char fpath[80], name[IDLEN + 2], *desc, *ptr;
  int len;
  FILE *fp;

  setuserfile(fpath, friend_file[type]);
  if (fp = fopen(fpath, "r"))
  {
    sprintf(name, "%s ", uident);
    len = strlen(name);
    desc = genbuf + 13;

    while (fgets(genbuf, STRLEN, fp))
    {
      if (!memcmp(genbuf, name, len))
      {
	if (ptr = strchr(desc, '\n'))
	  ptr[0] = '\0';
	if (desc)
	  prints("�A%s%s", friend_desc[type], desc);
	break;
      }
    }
    fclose(fp);
  }
}



/* ----------------------------------------------------- */


static void
my_kick(uentp)
  user_info *uentp;
{
  getdata(1, 0, msg_sure_ny, genbuf, 4, LCECHO);
  clrtoeol();
  if (genbuf[0] == 'y')
  {
    sprintf(genbuf, "%s (%s)", uentp->userid, uentp->username);
    log_usies("KICK ", genbuf);
    if ((kill(uentp->pid, SIGHUP) == -1) && (errno == ESRCH))
      memset(uentp, 0, sizeof(user_info));
    /* purge_utmp(uentp); */
    outs("��X�h�o");
  }
  else
    outs(msg_cancel);
  pressanykey();
}


static void
my_query(uident)
  char *uident;
{
  extern char currmaildir[];
  char fpath[80];
  int tuid;
  user_info *uentp;

  if (tuid = getuser(uident))
  {
    setutmpmode(QUERY);
    currutmp->destuid = tuid;

    prints("%s(%s) �@�W�� %d ���A�o���L %d �g�峹\n",
      xuser.userid, xuser.username, xuser.numlogins, xuser.numposts);

    prints("�̪�(%s)�q[%s]�W��", Cdate(&xuser.lastlogin),
      (xuser.lasthost[0] ? xuser.lasthost : "(����)"));

    /* Query �ɥi�P�ɬݨ�ͽ˴y�z�δc�� */

    friend_query(uident, FRIEND_OVERRIDE);
    friend_query(uident, FRIEND_REJECT);

#if defined(REALINFO) && defined(QUERY_REALNAMES)
    if (HAS_PERM(PERM_BASIC))
      prints("�u��m�W: %s\n", xuser.realname);
#endif

#if 0
    prints("�q�l�l��H�c�a�}: %s \n", xuser.email);
#endif

    uentp = (user_info *) search_ulist(cmpuids, tuid);
    prints("\n[1;33;46m[�ثe�ʺA�G%s][0m  ",
      uentp ? modestring(uentp, 1) : "���b���W");

    sethomedir(currmaildir, xuser.userid);
    outs(chkmail(1) ? "[35;1m���s�H���٨S��[m\n" : "�Ҧ��H�󳣬ݹL�F\n");
    sethomedir(currmaildir, cuser.userid);
    chkmail(1);
    rpg_read(uident);
    if(in_rpg)
      prints("¾�~:[33;1m%s[m ����:[36;1m%d[m �����g���:[36;1m%d[m �i�θg���:[36;1m%d[m \n��O:[32;1m%d[m �]�k:[32;1m%d[m �Z�O:[32;1m%d[m ���`����:[32;1m%d[m\n",
             get_job(other_rpg.role,other_rpg.level),other_rpg.level,
             other_rpg.exp,other_rpg.exp-other_rpg.used,other_rpg.hp,
             other_rpg.mp,other_rpg.fp,other_rpg.dead);
    showplans(uident);
  }
  else
    outs(err_uid);

  pressanykey();
  /* currutmp->destuid = 0; */
}


static void
my_write(uin)
  user_info *uin;
{
  int len;
  char buf[24];
  
  if (!HAS_PERM(PERM_SYSOP) && (is_rejected(uin->userid) ||
      (!(uin->pager & (WRITE_FLAG>>2)) && !can_override(uin->userid, cuser.userid))))
  {
    outs("��������T���I�s���F");
    pressanykey(); 
    return;
  } 
  
  
  sprintf(buf,"�e��%s:",uin->userid);
  len=strlen(uin->userid)>strlen(cuser.userid)?strlen(uin->userid)+10:strlen(cuser.userid)+10;
 
  
/*  if(currutmp->mode == LUSERS)*/
    getdata(0, 0, buf, genbuf, 80-len, DOECHO);
/*  else 
   getdata(b_lines, 0, buf, genbuf, 80-len, DOECHO);*/
  if(strlen(genbuf))
  {
    char fpath[80];
    char fpathl[80];
    FILE *fp;
    FILE *wlog;
    pid_t pid = uin->pid;
    struct tm *ptime;
    time_t now;
    
    move(b_lines,0);
    clrtoeol();
    getdata(b_lines, 0, "�T�w�n�e�X��?[Y/N]:[Y]", buf, 4, DOECHO);
    if(*buf == 'n' || *buf == 'N')
      return;
      
    sethomefile(fpath, uin->userid, fn_write);
    sethomefile(fpathl, uin->userid, "write.log");
    if((fp = fopen(fpath, "w")) && (wlog=fopen(fpathl,"a")))
    {
      time(&now);
      ptime = localtime(&now);    
      sprintf(fpath, "��%s(%2d:%02d)",cuser.userid,ptime->tm_hour,ptime->tm_min);
      fpath[len] = '\0';
      flock(fileno(fp),LOCK_EX);
      flock(fileno(wlog),LOCK_EX);      
      fprintf(fp,"%s %d ",cuser.userid,currpid);
      fprintf(fp, "[1;33;46m%s [37;45m%s[0m", fpath, genbuf);
      fprintf(wlog,"[1;33;46m%s [37;45m%s[0m\n", fpath, genbuf);
      flock(fileno(fp),LOCK_UN);
      fclose(fp);
      flock(fileno(wlog),LOCK_UN);      
      fclose(wlog);
      move(b_lines,0);
      clrtoeol();      
      if(kill(pid, SIGUSR2) == -1)
        outs(msg_usr_left);
      else
        prints("�j��]���z�e�T���F"); 
      refresh();
      sleep(1);
    }
  }
}


/* Thor: for ask last call-in message */

int
t_display_call_in()
{
  extern struct msgrec lastmsg;
  setutmpmode(DISPLAY);
  setuserfile(genbuf,"write.log");
  if (more(genbuf, YEA) != -1)
       return 0;
  else
  {
     outmsg(lastmsg.msg);
     clrtoeol();
     igetch();
     return (XEASY + 1);
  }  
}


/* ----------------------------------------------------- */


static int
dotalkuent(uentp)
  user_info *uentp;
{
  char buf[STRLEN];
  char mch;

  if (HAS_PERM(PERM_SEECLOAK) || !uentp->invisible)
  {
    switch (uentp->mode)
    {
    case CLASS:
      mch = 'G';
      break;
    case TALK:
      mch = 'T';
      break;
    case CHATING:
      mch = 'C';
      break;
    case READNEW:
    case READING:
      mch = 'R';
      break;
    case POSTING:
      mch = 'P';
      break;
    case SMAIL:
    case RMAIL:
    case MAIL:
      mch = 'M';
      break;
    default:
      mch = '-';
    }
    sprintf(buf, "%s%s(%c), ",
      uentp->invisible ? "*" : "", uentp->userid, mch);
    strcpy(talk_uent_buf, buf);
    talk_uent_buf += strlen(buf);
  }
  return 0;
}


static void
do_talk_nextline(twin)
  struct talk_win *twin;
{
  int curln;

  curln = twin->curln + 1;
  if (curln > twin->eline)
    curln = twin->sline;
  if (curln != twin->eline)
  {
    move(curln + 1, 0);
    clrtoeol();
  }
  move(curln, 0);
  clrtoeol();
  twin->curcol = 0;
  twin->curln = curln;
}


static void
do_talk_char(twin, ch)
  struct talk_win *twin;
  int ch;
{
  extern int dumb_term;

  if (isprint2(ch))
  {
    if (twin->curcol < 79)
      move(twin->curln, twin->curcol);
    else
      do_talk_nextline(twin);
    outc(ch);
    (twin->curcol)++;
    return;
  }

  switch (ch)
  {
  case Ctrl('H'):
  case '\177':
    if (dumb_term)
      ochar(Ctrl('H'));
    if (twin->curcol == 0)
    {
      return;
    }
    (twin->curcol)--;
    move(twin->curln, twin->curcol);
    if (!dumb_term)
      outc(' ');
    move(twin->curln, twin->curcol);
    return;

  case Ctrl('M'):
  case Ctrl('J'):
    if (dumb_term)
      outc('\n');
    do_talk_nextline(twin);
    return;

  case Ctrl('G'):
    bell();
  }
}


static void
do_talk_string(twin, str)
  struct talk_win *twin;
  char *str;
{
  while (*str)
  {
    do_talk_char(twin, *str++);
  }
}


static void
dotalkuserlist(twin)
  struct talk_win *twin;
{
  char bigbuf[MAXACTIVE * 20];
  int savecolumns;

  do_talk_string(twin, "\n*** �W�u���� ***\n");
  savecolumns = (t_columns > STRLEN ? t_columns : 0);
  talk_uent_buf = bigbuf;
  if (apply_ulist(dotalkuent) == -1)
  {
    strcpy(bigbuf, "�S������ϥΪ̤W�u\n");
  }
  strcpy(talk_uent_buf, "\n");
  do_talk_string(twin, bigbuf);
  if (savecolumns)
    t_columns = savecolumns;
}

static
do_talk(fd)
  int fd;
{
  struct talk_win mywin, itswin;
  char mid_line[128], data[80],buf[40];
  int page_pending = NA;
  int i , ch, datac;

  tran_io = fd;
  setutmpmode(TALK);
  talk_mode = YEA;

  strcpy(genbuf,save_page_requestor);
  strcpy(buf,strtok(genbuf," "));
  rpg_read(buf);

  sprintf(genbuf, "%s (%s)", cuser.userid, cuser.username);
  i = 58 - strlen(genbuf) - strlen(save_page_requestor) - strlen((char *)get_job(mine_rpg.role,mine_rpg.level)) - strlen((char *)get_job(other_rpg.role,other_rpg.level));
  if (i >= 0){
     i = i/2;
     ch = YEA;
  }
  else{
     i = (i+ strlen((char *)get_job(mine_rpg.role,mine_rpg.level)) + strlen((char *)get_job(other_rpg.role,other_rpg.level)))/2;
     ch = NA;
  }
     
  memset(data, ' ', i);
  data[i] = '\0';
  if(ch)
    sprintf(mid_line, "[46m      [44;36m%s%s %s  v.s.  %s %s%s[46m      [m",
      data,genbuf,get_job(mine_rpg.role,mine_rpg.level),
      save_page_requestor,get_job(other_rpg.role,other_rpg.level),data); 
  else
    sprintf(mid_line, "[46m      [44;36m%s%s  v.s.  %s%s[46m      [m",
      data,genbuf,save_page_requestor,data); 
    
  memset(&mywin, 0, sizeof(mywin));
  memset(&itswin, 0, sizeof(itswin));

  i = b_lines >> 1;
  mywin.eline = i - 1;
  itswin.curln = itswin.sline = i + 1;
  itswin.eline = b_lines - 1;

  clear();
  move(i, 0);
  outs(mid_line);
  move(0, 0);

  add_io(fd, 0);

  while (1)
  {
    ch = igetch();

    if (talkrequest)
      page_pending = YEA;
    if (page_pending)
    {
      page_pending = servicepage(b_lines, mid_line);
      move(mywin.curln, mywin.curcol);
    }

    if (ch == '')
    {
      igetch();
      igetch();
      continue;
    }

    if (ch == I_OTHERDATA)
    {
      datac = recv(fd, data, 80, 0);
      if (datac <= 0)
	break;
      for (i = 0; i < datac; i++)
	do_talk_char(&itswin, data[i]);
    }
    else
    {
      if (ch == Ctrl('D') || ch == Ctrl('C'))
	break;

      if (isprint2(ch) || ch == Ctrl('H') || ch == '\177'
	|| ch == Ctrl('G') || ch == Ctrl('M') || ch == Ctrl('J'))
      {
	data[0] = (char) ch;
	if (send(fd, data, 1, 0) != 1)
	  break;
	do_talk_char(&mywin, ch);
      }
      else if (ch == Ctrl('U'))
      {
	dotalkuserlist(&mywin);
      }
      else if (ch == Ctrl('P') && HAS_PERM(PERM_BASIC))
      {
        currutmp->pager ^= (PAGER_FLAG>>2);
	do_talk_string(&mywin, (currutmp->pager & (PAGER_FLAG>>2)) ?
	  "�� ���}TALK�I�s��\n" : "�� ����TALK�I�s��\n");
      }
      else if (ch == Ctrl('W') && HAS_PERM(PERM_BASIC))
      {
        currutmp->pager ^= (WRITE_FLAG>>2);
	do_talk_string(&mywin, (currutmp->pager & (WRITE_FLAG>>2)) ?
	  "�� ���}�T���I�s��\n" : "�� �����T���I�s��\n");
      }
    }
  }
  add_io(0, 0);
  setutmpmode(XINFO);
  talk_mode = NA;
}


static void
my_talk(uin)
  user_info *uin;
{
  int sock, msgsock, length, ch;
  struct sockaddr_in server;
  pid_t pid;
  char c;
  
  ch = uin->mode;

  if(talk_mode)
  {
     outs("�z�w�g�bTALK���A�F");
  }
  else if (ch == POSTING || ch == SMAIL || ch == TALK)
  {
    outs("���L�v���");
  }
  else if (!HAS_PERM(PERM_SYSOP) && (is_rejected(uin->userid) ||
      (!(uin->pager & (PAGER_FLAG>>2)) && !can_override(uin->userid, cuser.userid))))
  {
    outs("���TALK�����I�s���F");
  }
  else if (!(pid = uin->pid) || (kill(pid, 0) == -1))
  {
    outs(msg_usr_left);
  }
  else
  {
    showplans(uin->userid);
    getdata(2, 0, "�T�w�n�M�L/�o�ͤѶ�(Y/N)?[N] ", genbuf, 4, LCECHO);
    if (*genbuf != 'y')
      return;

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0)
    {
      perror("sock err");
      return;
    }
    server.sin_family = PF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = 0;
    if (bind(sock, (struct sockaddr *) & server, sizeof server) < 0)
    {
      close(sock);
      perror("bind err");
      return;
    }
    length = sizeof server;
    if (getsockname(sock, (struct sockaddr *) & server, &length) < 0)
    {
      close(sock);
      perror("sock name err");
      return;
    }
    if(uin->mode != CHATING)
    {
       char fpath[80];
       char fpathl[80];
       FILE *fp;
       FILE *wlog;
       struct tm *ptime;
       time_t now;   
       
       sethomefile(fpath, uin->userid, fn_write);
       sethomefile(fpathl, uin->userid, "write.log");
       if((fp = fopen(fpath, "w")) && (wlog=fopen(fpathl,"a")))
       {
         time(&now);
         ptime = localtime(&now);
         sprintf(fpath, "[1;33;46m��%s(%2d:%02d) ���b�I�s�z�I[m",cuser.userid,ptime->tm_hour,ptime->tm_min);
         flock(fileno(fp),LOCK_EX);
         flock(fileno(wlog),LOCK_EX);
         fprintf(fp,"%s %d ",cuser.userid,currpid);
         fprintf(fp, "%s", fpath);
         fprintf(wlog,"%s\n", fpath);
         flock(fileno(fp),LOCK_UN);
         fclose(fp);
         flock(fileno(wlog),LOCK_UN);
         fclose(wlog);
         kill(pid, SIGUSR2);
       }
    }
    currutmp->sockactive = YEA;
    currutmp->sockaddr = server.sin_port;
    currutmp->destuid = uin->uid;
    setutmpmode(PAGE);
    kill(pid, SIGUSR1);
    clear();
    prints("���I�s %s.....\n��J Ctrl-D ����....", uin->userid);

    listen(sock, 1);
    add_io(sock, 20);
    while (1)
    {
      ch = igetch();
      if (ch == I_TIMEOUT)
      {

#ifdef LINUX
	add_io(sock, 20);	/* added 4 linux... achen */
#endif

	move(0, 0);
	outs("�A");
	bell();

	if (kill(pid, SIGUSR1) == -1)
	{

#ifdef LINUX
	  add_io(sock, 20);	/* added 4 linux... achen */
#endif

	  move(0, 0);
	  outs(msg_usr_left);
	  pressanykey();
	  return;
	}
	continue;
      }

      if (ch == I_OTHERDATA)
	break;

      if (ch == '\004')
      {
	add_io(0, 0);
	close(sock);
	currutmp->sockactive = currutmp->destuid = 0;
	return;
      }
    }

    msgsock = accept(sock, (struct sockaddr *) 0, (int *) 0);
    if (msgsock == -1)
    {
      perror("accept");
      return;
    }
    add_io(0, 0);
    close(sock);
    currutmp->sockactive = NA;
    /* currutmp->destuid = 0 ; */
    read(msgsock, &c, sizeof c);

    if (c == 'y')
    {
      sprintf(save_page_requestor, "%s (%s)", uin->userid, uin->username);
      do_talk(msgsock);
    }
    else
    {
      move(9, 9);
      outs("�i�^���j ");
      switch (c)
      {
      case 'a':
	outs("�ڲ{�b�ܦ��A�е��@�|��A call �ڡA�n�ܡH");
	break;
      case 'b':
	outs("�藍�_�A�ڦ��Ʊ������A talk....");
	break;
      case 'd':
	outs("�A�u���ܷСA�ڹ�b���Q��A talk....");
	break;
      case 'c':
	outs("�Ф��n�n�ڦn�ܡH");
	break;
      default:
	outs("�ڲ{�b���Q talk ��.....:)");
      }
    }
    close(msgsock);
    currutmp->destuid = 0;
  }
  pressanykey();
}


/* ------------------------------------- */
/* ��榡��Ѥ���			 */
/* ------------------------------------- */


#define	US_PICKUP	1234
#define	US_RESORT	1233
#define	US_ACTION	1232
#define	US_REDRAW	1231


static int
pickup_cmp(i, j)
  pickup *i, *j;
{
  switch (pickup_way)
  {
  case 0:
    {
      register int friend;

      if (friend = j->friend - i->friend)
	return friend;
    }
  case 1:
    return strcasecmp(i->ui->userid, j->ui->userid);
  case 2:
    return (i->ui->mode - j->ui->mode);
  case 3:
    return (i->idle - j->idle);
  }
}


/*static*/ void
pickup_user()
{
  static int real_name = 0;
  static int num = 0;
  static int rpg_list = 0;

  register user_info *uentp;
  register int state = US_PICKUP, ch;
  register int actor, head, foot;
  int savemode = currstat;
  time_t diff, freshtime;
  int wflag;
  pickup pklist[USHM_SIZE];

  struct stat ttystat;
  char buf[20];
  char pagerchar[8] = "*poow o ";
  char *msg_pickup_way[PICKUP_WAYS] =
  {"�١I�B��",
    "���ͥN��",
    "���ͰʺA",
    "�o�b�ɶ�"
  };

  while (1)
  {
    if (state == US_PICKUP)
    {
      freshtime = 0;
    }

    if (utmpshm->uptime > freshtime)
    {
      time(&freshtime);
      friends_number = override_number = actor = ch = 0;
      while (ch < USHM_SIZE)
      {
	uentp = &(utmpshm->uinfo[ch++]);
	if (uentp->pid)
	{
	  if (!HAS_PERM(PERM_SEECLOAK) && (uentp->invisible
	       /* || is_rejected(uentp->userid) */ ))
	    continue;		/* Thor: can't see anyone who rejects you. */

	  head = is_friend(uentp);
	  if (savemode == FRIEND && !head)
	    continue;

#ifdef SHOW_IDLE_TIME
	  strcpy(buf, uentp->tty);

	  if (stat(buf, &ttystat))
	  {
	    diff = 0;
	  }
	  else
	  {
	    diff = freshtime - ttystat.st_atime;

#ifdef DOTIMEOUT
	    /* prevent fault /dev mount from kicking out users */
	if(!HAS_PERM(PERM_SYSOP))
	    if ((diff > IDLE_TIMEOUT) && (diff < 60 * 60 * 24 * 5))
	    {
	      if ((kill(uentp->pid, SIGHUP) == -1) && (errno == ESRCH))
		memset(uentp, 0, sizeof(user_info));
	      continue;
	    }
#endif
	  }
	  pklist[actor].idle = diff;
#endif

	  pklist[actor].friend = head;
	  pklist[actor].ui = uentp;
	  actor++;
	}
      }
      if (!actor)
	return;
      state = US_PICKUP;
    }

    if (state >= US_RESORT)
    {
      qsort(pklist, actor, sizeof(pickup), pickup_cmp);
    }

    if (state >= US_ACTION)
    {
     showtitle("���ղ��", BoardName);
     if(!rpg_list){
      prints("  �ƧǤ覡�G[%s]  �W���H�ơG%-6d[1;32m�ڪ��B�͡G%-5d[33m�P�ڬ��͡G%-5d[0m\n"
	"[7m No. %cP �N��         %-17s%-17s%-13s%-10s[0m\n",
	msg_pickup_way[pickup_way], actor, friends_number, override_number,
	HAS_PERM(PERM_SEECLOAK) ? 'C' : ' ',

#ifdef REALINFO
	real_name ? "�m�W" :
#endif

	"�ʺ�", "�G�m", "�ʺA",

#ifdef SHOW_IDLE_TIME
	"�o�b ��:��"
#else
	""
#endif

	);
     }
     else{
      prints("  �ƧǤ覡�G[%s]  �W���H�ơG%-6d[1;32m�ڪ��B�͡G%-5d[33m�P�ڬ��͡G%-5d[0m\n"
	"[7m No. %cP �N��         %-10s%-7s%-5s%-5s%-5s%-5s%-10s%-10s[0m\n",
	msg_pickup_way[pickup_way], actor, friends_number, override_number,
	HAS_PERM(PERM_SEECLOAK) ? 'C' : ' ',"¾�~","�g���","����","��O",
	"�]�k","�ԤO","����",
#ifdef SHOW_IDLE_TIME
	"�o�b ��:��"
#else
	""
#endif
	);
     }
     
    }
    else
    {
      move(3, 0);
      clrtobot();
    }

    if (num < 0)
      num = 0;
    else if (num >= actor)
      num = actor - 1;

    head = (num / p_lines) * p_lines;
    foot = head + p_lines;
    if (foot > actor)
      foot = actor;

    for (ch = head; ch < foot; ch++)
    {
      uentp = pklist[ch].ui;

      if (!uentp->pid)
      {
	state = US_PICKUP;
	break;
      }

#ifdef SHOW_IDLE_TIME
      diff = pklist[ch].idle;
      if (diff > 0)
	sprintf(buf, "%3d:%02d", diff / 60, diff % 60);
      else
	buf[0] = '\0';
#else
      buf[0] = '\0';
#endif

      state = pklist[ch].friend;
      diff = (uentp->pager & (PAGER_FLAG>>2));
      wflag= (uentp->pager & (WRITE_FLAG>>2));
     if(!rpg_list)
     {
      prints("%5d%c%c %s%-13s%-17.16s%s%-17.16s%-17.17s%s\n",
	ch + 1, (uentp->invisible ? ')' : ' '),
	pagerchar[(state & 2) | diff | wflag],
	fcolor[state], uentp->userid,

#ifdef REALINFO
	real_name ? uentp->realname :
#endif

	uentp->username, state ? "[0m" : "",
	(diff || HAS_PERM(PERM_SYSOP)) ? uentp->from : "*",
	modestring(uentp, 0), buf);
     }
     else
     {
      sprintf(genbuf,"%5d%c%c %s%-13.12s%s%-10s%-7d%-5d%-5d%-5d%-5d%-10d%-10s\n",
	ch + 1, (uentp->invisible ? ')' : ' '),
	pagerchar[(state & 2) | diff | wflag],
	fcolor[state], uentp->userid, state ? "[0m" : "",
	get_job(uentp->role,uentp->level),uentp->exp,uentp->level,
	uentp->hp,uentp->mp,uentp->fp,uentp->money, buf);
      prints("%s",genbuf);
     }
    }
    if (state == US_PICKUP)
      continue;

    move(b_lines, 0);
    outs("[34;42m �I�B�ަ� [31;47m (��)[30m���� [31m(T)[30m��� [31m(A/D/F)[30m��� [31m(Q)[30m�d�� [31m(W)[30m���� [31m(M)[30m�H�H [31m(����)[30m���� [0m");

    state = 0;
    while (!state)
    {
      ch = cursor_key(num + 3 - head, 0);
      if (ch == KEY_RIGHT || ch == '\n' || ch == '\r')
	ch = 't';

      switch (ch)
      {
      case KEY_LEFT:
      case 'e':
      case 'E':
	return;

      case 'l':
      case 'L':
	if (++pickup_way >= PICKUP_WAYS)
	  pickup_way = 0;
	state = US_RESORT;
	num = 0;
	break;

      case KEY_DOWN:
      case 'n':
	if (++num < actor)
	{
	  if (num >= foot)
	    state = US_REDRAW;
	  break;
	}

      case '0':
      case KEY_HOME:
	num = 0;
	if (head)
	  state = US_REDRAW;
	break;

      case KEY_TAB:
         rpg_list=!rpg_list;
         state = US_PICKUP;
         break;

      case ' ':
      case KEY_PGDN:
      case Ctrl('F'):
      case 'N':
	if (foot < actor)
	{
	  num += p_lines;
	  state = US_REDRAW;
	}
	else if (head)
	{
	  num = 0;
	  state = US_REDRAW;
	}
	break;

      case KEY_UP:
      case 'p':
	if (--num < head)
	{
	  if (num < 0)
	  {
	    num = actor - 1;
	    if (actor == foot)
	      break;
	  }
	  state = US_REDRAW;
	}
	break;

      case KEY_PGUP:
      case Ctrl('B'):
      case 'P':
	if (head)
	{
	  num -= p_lines;
	  state = US_REDRAW;
	  break;
	}

      case KEY_END:
      case '$':
	num = actor - 1;
	if (foot < actor)
	  state = US_REDRAW;
	break;

#ifdef	REALINFO
      case 'r':		/* ��ܯu��m�W */
      case 'R':
	if (HAS_PERM(PERM_SYSOP))
	{
	  real_name ^= 1;
	  state = US_REDRAW;
	}
	break;
#endif

      case 'k':		/* ���a�J��X�h */
      case 'K':
	if (!HAS_PERM(PERM_SYSOP))
	  continue;

      case 't':
      case 'w':
      case 'T':
      case 'W':
	if (!(cuser.userlevel & PERM_PAGE))
	  continue;

      case 'A':
      case 'D':
      case 'F':
      case 'M':
      case 'Q':
	ch |= 32;

      case 'x':		/* Xshadow : for read mail hot key */

      case 'a':
      case 'd':
      case 'f':
      case 'm':
	if (!cuser.userlevel)	/* guest �u�� query */
	  break;

      case 'q':
	uentp = pklist[num].ui;
	state = US_ACTION;
	break;

      case 's':		/* refresh user state */
	state = US_PICKUP;
      }
    }

    if (state != US_ACTION)
      continue;

    if (ch == 'w')
    {
      if ((uentp->uid != usernum) && (HAS_PERM(PERM_SYSOP) ||
	  (!is_rejected(uentp->userid) &&
	    ((uentp->pager & (WRITE_FLAG>>2)) || can_override(uentp->userid, cuser.userid)))))
      {
	cursor_show(num + 3 - head, 0);
	my_write(uentp);
      }
      else
	state = 0;
    }
    else
    {
      move(1, 0);
      clrtobot();
      move(2, 0);

      switch (ch)
      {
      case 'x':
	m_read();
	break;

      case 'a':
	friend_add(uentp->userid, FRIEND_OVERRIDE);
	friend_load();
	state = US_PICKUP;
	break;

      case 'd':
	friend_delete(uentp->userid, FRIEND_OVERRIDE);
	friend_load();
	state = US_PICKUP;
	break;

      case 'f':
	t_override();
	state = US_PICKUP;
	break;

      case 'k':
	if (uentp->pid && (kill(uentp->pid, 0) != -1))
	{
	  my_kick(uentp);
	  state = US_PICKUP;
	}
	break;

      case 'm':
	stand_title("�H  �H");
	prints("���H�H�G%s", uentp->userid);
	my_send(uentp->userid);
	break;

      case 'q':
	my_query(uentp->userid);
	break;

      case 't':
	if (uentp->uid != usernum)
	{
	  move(3, 0);
	  my_talk(uentp);
	  state = US_PICKUP;
	}
      }
    }
    setutmpmode(savemode);
  }
}


static int
listcuent(uentp)
  user_info *uentp;
{
  if ((uentp->uid != usernum) && (!uentp->invisible || HAS_PERM(PERM_SEECLOAK)))
    AddNameList(uentp->userid);
  return 0;
}


static void
creat_list()
{
  CreateNameList();
  apply_ulist(listcuent);
}


int
t_users()
{
  setutmpmode(LUSERS);
  pickup_user();
  return 0;
}

/*
int
t_pager()
{
  currutmp->pager ^= 1;
  return 0;
}
*//*bobule mark*/

int
t_query()
{
  char uident[STRLEN];

  stand_title("�d�ߺ���");
  usercomplete(msg_uid, uident);
  if (uident[0])
    my_query(uident);
  return 0;
}


int
t_talk()
{
  char uident[16];
  int tuid, unum, ucount;
  user_info *uentp;
  
  if (count_ulist() <= 1)
  {
    outs("�ثe�u�W�u���z�@�H�A���ܽЪB�ͨӥ��{�i" BOARDNAME "�j�a�I");
    return XEASY;
  }
  stand_title("���}�ܧX�l");
  creat_list();
  namecomplete(msg_uid, uident);
  if (uident[0] == '\0')
    return 0;

  move(3, 0);
  if (!(tuid = searchuser(uident)) || tuid == usernum)
  {
    outs(err_uid);
    pressanykey();
    return 0;
  }

  /* ----------------- */
  /* multi-login check */
  /* ----------------- */

  unum = 1;
  while ((ucount = count_logins(cmpuids, tuid, 0)) > 1)
  {
    outs("(0) ���Q talk �F...\n");
    count_logins(cmpuids, tuid, 1);
    getdata(1, 33, "�п�ܤ@�Ӳ�ѹ�H [0]�G", genbuf, 4, DOECHO);
    unum = atoi(genbuf);
    if (unum == 0)
      return 0;
    move(3, 0);
    clrtobot();
    if (unum > 0 && unum <= ucount)
      break;
  }

  if (uentp = (user_info *) search_ulistn(cmpuids, tuid, unum))
    my_talk(uentp);

  return 0;
}


/* ------------------------------------- */
/* ���H�Ӧ���l�F�A�^���I�s��		 */
/* ------------------------------------- */


user_info *uip;


static int
setpagerequest()
{
  uip = (user_info *) search_ulist(cmpunums, usernum);
  if (uip && uip->sockactive)
  {
    if (currstat != TALK)
      currutmp->destuid = uip->uid;
    sprintf(page_requestor, "%s (%s)", uip->userid, uip->username);
    return 0;
  }
  return 1;
}


int
servicepage(line, msg)
  int line;
  char *msg;
{
  static time_t last_check;
  time_t now;
  char buf[STRLEN];

  uip = (user_info *) search_ulist(cmpunums, usernum);
  if (!uip || !uip->sockactive)
    talkrequest = NA;
  if (!talkrequest)
  {
    if (page_requestor[0])
    {
      if (currstat == TALK)
      {
	move(line, 0);
	clrtoeol();
	outs(msg);
      }
      else
      {				/* a chat mode */
	sprintf(buf, "�� %s �w����I�s", page_requestor);
	printchatline(buf);
      }
      memset(page_requestor, 0, sizeof(page_requestor));
      last_check = 0;
    }
    return NA;
  }
  else
  {
    now = time(0);
    if (now - last_check > P_INT)
    {
      last_check = now;
      if (!page_requestor[0] && setpagerequest())
	return NA;
      else
      {
	sprintf(buf, "�� %s ���b�I�s�z", page_requestor);
	if (currstat == TALK)
	{
	  move(line, 0);
	  clrtoeol();
	  outs(buf);
	}
	else			/* chat */
	  printchatline(buf);
      }
    }
  }
  return YEA;
}


void
talkreply()
{
  int a;
  struct hostent *h;
  char hostname[STRLEN], buf[4];
  struct sockaddr_in sin;
  int i;

  talkrequest = NA;
  if (setpagerequest())
    return;

  currstat = XMODE;		/* �קK�X�{�ʵe */

  clear();
  outs("\n\n\
       (Y) ���ڭ� talk �a�I     (A) �ڲ{�b�ܦ��A�е��@�|��A call ��\n\
       (N) �ڲ{�b���Q talk      (B) �藍�_�A�ڦ��Ʊ������A talk\n\
       (C) �Ф��n�n�ڦn�ܡH     (D) �A�u���ܷСA�ڹ�b���Q��A talk\n\n");

  getuser(uip->userid);
  prints("���Ӧ� [%s]�A�@�W�� %d ���A�峹 %d �g\n",
    uip->from, xuser.numlogins, xuser.numposts);
  showplans(uip->userid);
  sprintf(genbuf, "�A�Q�� %s ���ѶܡH�п��(Y/N/A/B/C/D)[Y] ", page_requestor);
  getdata(0, 0, genbuf, buf, 4, LCECHO);

  strcpy(save_page_requestor, page_requestor);
  memset(page_requestor, 0, sizeof(page_requestor));
  gethostname(hostname, STRLEN);

  if (!(h = gethostbyname(hostname)))
  {
    perror("gethostbyname");
    return;
  }
  memset(&sin, 0, sizeof sin);
  sin.sin_family = h->h_addrtype;
  memcpy(&sin.sin_addr, h->h_addr, h->h_length);
  sin.sin_port = uip->sockaddr;
  a = socket(sin.sin_family, SOCK_STREAM, 0);
  if ((connect(a, (struct sockaddr *) & sin, sizeof sin)))
  {
    perror("connect err");
    return;
  }
  if (!buf[0] || !strchr("abcdn", buf[0]))
    buf[0] = 'y';
  write(a, buf, 1);
  if (buf[0] == 'y')
  {
    do_talk(a);
  }

#ifdef LINUX
  else
  {
    talkrequest = NA;		/* added 4 linux by achen.... */
  }
#endif

  close(a);
  clear();
}


/* ------------------------------------- */
/* ���ͰʺA²��				 */
/* ------------------------------------- */


int
shortulist(uentp)
  user_info *uentp;
{
  static int lineno, fullactive, linecnt;
  static int moreactive, page, num;
  char uentry[50];
  int state;

  if (!lineno)
  {
    lineno = 3;
    page = moreactive ? (page + p_lines * 3) : 0;
    linecnt = num = moreactive = 0;
    move(1, 70);
    prints("Page: %d", page / (p_lines) / 3 + 1);
    move(lineno, 0);
  }
  if (uentp == NULL)
  {
    int finaltally;

    clrtoeol();
    move(++lineno, 0);
    clrtobot();
    finaltally = fullactive;
    lineno = fullactive = 0;
    return finaltally;
  }
  if (!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
  {
    if (lineno >= b_lines)
      return 0;
    if (num++ < page)
      return 0;
    memset(uentry, ' ', 25);
    uentry[25] = '\0';
  }
  else
  {
    fullactive++;
    if (lineno >= b_lines)
    {
      moreactive = 1;
      return 0;
    }
    if (num++ < page)
      return 0;

    state = is_friend(uentp);

    sprintf(uentry, "%s %-13s%c%-10s%s", fcolor[state],
      uentp->userid, uentp->invisible ? '#' : ' ',
      modestring(uentp, 1), state ? "[0m" : "");
  }
  if (++linecnt < 3)
  {
    strcat(uentry, "�x");
    outs(uentry);
  }
  else
  {
    outs(uentry);
    linecnt = 0;
    clrtoeol();
    move(++lineno, 0);
  }
  return 0;
}


static void
do_list(modestr)
  char *modestr;
{
  int count;

  showtitle(modestr, BoardName);
  if (currstat == MONITOR)
    prints("�C�j %d ����s�@���A�Ы�[Ctrl-C]��[Ctrl-D]���}", M_INT);

  outc('\n');
  outs(msg_shortulist);

  friends_number = override_number = 0;
  if (apply_ulist(shortulist) == -1)
  {
    outs(msg_nobody);
  }
  else
  {
    time_t thetime = time(NULL);

    count = shortulist(NULL);
    move(b_lines, 0);
    prints("[1;37;45m  �W���`�H�ơG%-7d[32m�ڪ��B�͡G%-6d"
      "[33m�P�ڬ��͡G%-8d[30m%-23s[37;40;0m",
      count, friends_number, override_number, Cdate(&thetime));
    refresh();
  }
}


int
t_list()
{
  setutmpmode(LUSERS);
  do_list("�ϥΪ̪��A");
  igetch();
  return 0;
}


/* ------------------------------------- */
/* �ʬݨϥα���				 */
/* ------------------------------------- */

int idle_monitor_time;

static void
sig_catcher()
{
  if (currstat != MONITOR)
  {

#ifdef DOTIMEOUT
    init_alarm();
#else
    signal(SIGALRM, SIG_IGN);
#endif

    return;
  }
  if (signal(SIGALRM, sig_catcher) == SIG_ERR)
  {
    perror("signal");
    exit(1);
  }

#ifdef DOTIMEOUT
  idle_monitor_time += M_INT;
   if (idle_monitor_time > MONITOR_TIMEOUT && !HAS_PERM(PERM_SYSOP))
   {
     clear();
     fprintf(stderr, "timeout\n");
     abort_bbs();
   }
#endif

  do_list("�l�ܯ���");
  alarm(M_INT);
}


int
t_monitor()
{
  char c;
  int i;

  setutmpmode(MONITOR);
  alarm(0);
  signal(SIGALRM, sig_catcher);
  idle_monitor_time = 0;

  do_list("�l�ܯ���");
  alarm(M_INT);
  while (YEA)
  {
    i = read(0, &c, 1);
    if (!i || c == Ctrl('D') || c == Ctrl('C'))
      break;
    else if (i == -1)
    {
      if (errno != EINTR)
      {
	perror("read");
	exit(1);
      }
    }
    else
      idle_monitor_time = 0;
  }
  return 0;
}

/*bobule add ���w�W���q��*/
void
do_assign()
{
  FILE *fpr;
  int assigncount=0;
  register user_info *uentp;
  
  setuserfile(genbuf,"to_assign");
  if (fpr = fopen(genbuf, "r"))
  {
    int  tuid,ucount,i;
    char buf[80];
    char fpath[80];
    char fpathl[80];
    FILE *fp;
    FILE *wlog;
    struct tm *ptime;
    time_t now;
    
    time(&now);
    ptime = localtime(&now);    
    sprintf(buf, "��%s �� %2d:%02d �q %s �W���F\0",cuser.userid,ptime->tm_hour,ptime->tm_min,cuser.lasthost);
    while (fgets(genbuf, STRLEN, fpr) && assigncount < (MAX_FRIEND/2))
    {
     if (strtok(genbuf, str_space))
      if (tuid = searchuser(genbuf))
       if(uentp = (user_info *) search_ulist(cmpuids, tuid))
       {
         sethomefile(fpath, genbuf, fn_write);
         sethomefile(fpathl, genbuf, "write.log");
         if((fp = fopen(fpath, "w")) && (wlog=fopen(fpathl,"a")))
         {
           flock(fileno(fp),LOCK_EX);
           flock(fileno(wlog),LOCK_EX);
           fprintf(fp,"%s %d ",cuser.userid,currpid);
           fprintf(fp, "[1;33;46m%s[0m",buf);
           fprintf(wlog,"[1;33;46m%s[0m\n",buf);
           flock(fileno(fp),LOCK_UN);
           fclose(fp);
           flock(fileno(wlog),LOCK_UN);
           fclose(wlog);
           ucount = count_logins(cmpuids, tuid, 0);
           for(i=1;i<=ucount;i++)
           {
             uentp = (user_info *) search_ulistn(cmpuids, tuid,i);
             kill(uentp->pid, SIGUSR2);
           }
         }
       }
    }
    fclose(fpr);
  }
}



/* ------------------------------------- */
/* �n�ͦW��B�¦W��			 */
/* ------------------------------------- */


void
friend_load()
{
  FILE *fp;
  ushort myfriends[MAX_FRIEND];

  friend_file[0] = fn_overrides;
  friend_file[1] = fn_reject;
  memset(myfriends, 0, sizeof(myfriends));
  friendcount = 0;
  setuserfile(genbuf, fn_overrides);
  if (fp = fopen(genbuf, "r"))
  {
    ushort unum;

    while (fgets(genbuf, STRLEN, fp) && friendcount < MAX_FRIEND - 2)
    {
      if (strtok(genbuf, str_space))
      {
	if (unum = searchuser(genbuf))
	{
	  myfriends[friendcount++] = (ushort) unum;
	}
      }
    }
    fclose(fp);
  }
  memcpy(currutmp->friend, myfriends, sizeof(myfriends));
}


void
friend_edit(type)
  int type;
{
  char fpath[80], line[80], uident[20], *msg;
  int count, column, dirty;
  FILE *fp;

  setuserfile(fpath, friend_file[type]);
  msg = friend_list[type];

  dirty = 0;
  while (1)
  {
    stand_title(msg);

    count = 0;
    CreateNameList();

    if (fp = fopen(fpath, "r"))
    {
      move(3, 0);
      column = 0;
      while (fgets(genbuf, STRLEN, fp))
      {
	if (genbuf[0] <= ' ')
	  continue;
	strtok(genbuf, str_space);
	AddNameList(genbuf);
	prints("%-13s", genbuf);
	count++;
	if (++column > 5)
	{
	  column = 0;
	  outc('\n');
	}
      }
      fclose(fp);
    }
    getdata(1, 0, (count ? "(A)�W�[ (D)�R�� (L)�ԲӦC�X (Q)�����H[Q] " :
	"(A)�W�[ (Q)�����H[Q] "), uident, 4, LCECHO);
    if (*uident == 'a')
    {
      move(1, 0);
      usercomplete(msg_uid, uident);
      if (uident[0] && searchuser(uident) && !InNameList(uident))
      {
        if(type == FRIEND_ASSIGN)
          assign_add(uident);
        else
	  friend_add(uident, type);
	dirty = 1;
      }
    }
    else if ((*uident == 'd') && count)
    {
      move(1, 0);
      namecomplete(msg_uid, uident);
      if (uident[0] && InNameList(uident))
      {
        if(type == FRIEND_ASSIGN)
          assign_delete(uident);
        else
	  friend_delete(uident, type);
	dirty = 1;
      }
    }
    else if ((*uident == 'l') && count)
    {
      more(fpath, YEA);
    }
    else
      break;
  }
  if (dirty && (type!=FRIEND_ASSIGN))
    friend_load();
}


int
t_override()
{
  friend_edit(FRIEND_OVERRIDE);
  return 0;
}

int
t_reject()
{
  friend_edit(FRIEND_REJECT);
  return 0;
}

int
u_assign()
{
  setutmpmode(ASSIGN);
  friend_file[2]="my_assign";
  friend_edit(FRIEND_ASSIGN);
  return 0;
}

int
t_friends()
{
  if (friendcount)
  {
    setutmpmode(FRIEND);

    pickup_user();

    if (!(friends_number || override_number))
    {
      outs("�A���@�U�a�A�]�\\�L�̫ݷ|��N�W�u�F�C");
      return XEASY;
    }
    return 0;
  }
  else
  {
    outs("�ثe�٨S�]�w�n�ͦW��");
    return XEASY;
  }
}

void
anywhere_user()
{
  extern screenline *big_picture;
  screenline *screen0;
  int last_mode,local_io;
  int x,y;
  
  if(currutmp->mode == PAGE || currutmp->mode == LOGIN || currutmp->mode ==LUSERS)
    return;
  else if(talk_mode)
    if(!io_off){
      add_io(0,0);
      local_io=YEA;
      io_off = YEA;
    }
    else
      local_io=NA;
  
  last_mode = currutmp->mode;
  getyx(&x,&y);
  screen0 = (screenline *)calloc(t_lines,sizeof(screenline));
  memcpy(screen0, big_picture,t_lines*sizeof(screenline));
  t_users();
  memcpy(big_picture, screen0,t_lines*sizeof(screenline));
  free(screen0);
  move(x,y);
  redoscr();
  
/*  currutmp->mode = last_mode;*/
  setutmpmode(last_mode);
  if(talk_mode)
    if(local_io){
     io_off=NA;
     add_io(tran_io, 0); 
     refresh();
  }
}

int
t_wall()
{
  int ch=0;
  register user_info *uentp;
  char buf[STRLEN];
  if(getdata(b_lines-1,0,"�s�����e:",genbuf,65,DOECHO))
  {
    getdata(b_lines, 0, "�T�w�n�e�X��?[Y/N]:[Y]", buf, 4, DOECHO);
    if(*buf == 'n' || *buf == 'N')
        return;
    else
    {
      struct tm *ptime;
      time_t now;
                
      time(&now);
      ptime = localtime(&now);
      sprintf(buf, "�������s��(%2d:%02d)",ptime->tm_hour,ptime->tm_min);

      while(ch < USHM_SIZE)
      {
        uentp = &(utmpshm->uinfo[ch++]);
        if (uentp->pid)
        {
          char fpath[80];
          char fpathl[80];
          FILE *fp;
          FILE *wlog; 
          sethomefile(fpath, uentp->userid, fn_write);
          sethomefile(fpathl, uentp->userid, "write.log");
          if((fp = fopen(fpath, "w")) && (wlog=fopen(fpathl,"a")))
          {
            flock(fileno(fp),LOCK_EX);
            flock(fileno(wlog),LOCK_EX);
            fprintf(fp,"%s %d ",cuser.userid,currpid);
            fprintf(fp, "[1;33;46m%s: [37;45m%s[m",buf,genbuf);
            fprintf(wlog,"[1;33;46m%s: [37;45m%s[m\n",buf,genbuf);
            flock(fileno(fp),LOCK_UN);
            fclose(fp);
            flock(fileno(wlog),LOCK_UN);
            fclose(wlog);
            kill(uentp->pid, SIGUSR2);
          }
        }
      }
    }
  }
}
