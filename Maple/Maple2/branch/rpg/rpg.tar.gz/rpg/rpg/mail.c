/*-------------------------------------------------------*/
/* mail.c	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : local/internet mail routines	 	 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#include "bbs.h"


extern int del_range();

char currmaildir[32];
static char msg_cc[] = "[32m[�s�զW��][0m\n";
static char listfile[] = "list.0";


#ifdef INTERNET_EMAIL
#include <netdb.h>
#include <pwd.h>
#include <time.h>


static int
invalidaddr(addr)
  char *addr;
{
  if (*addr == '\0')
    return 1;			/* blank */
  while (*addr)
  {
    if (not_alnum(*addr) && !strchr("[].%!@:-_", *addr))
      return 1;
    addr++;
  }
  return 0;
}



#ifdef INTERNET_PRIVATE_EMAIL
int
m_internet()
{
  char receiver[60];

  getdata(20, 0, "���H�H�G", receiver, 60, DOECHO);
  if (strchr(receiver, '@') &&!invalidaddr(receiver) &&
    getdata(21, 0, "�D  �D�G", save_title, TTLEN, DOECHO))
  {
    do_send(receiver, save_title);
  }
  else
  {
    move(22, 0);
    outs("���H�H�ΥD�D�����T, �Э��s������O");
    pressanykey();
  }
  return 0;
}
#endif


void
m_init()
{
  sethomedir(currmaildir, cuser.userid);
}


int
chkmailbox(void)
{
  if (!HAVE_PERM(PERM_SYSOP) && !HAVE_PERM(PERM_MAILLIMIT))
  {
    int keep;

    m_init();
    if (keep = get_num_records(currmaildir, sizeof(fileheader)) > MAXKEEPMAIL)
    {
      move(b_lines, 0);
      clrtoeol();
      bell();
      prints("�z�O�s�H��ƥ� %d �W�X�W�� %d, �о�z�H��", keep, MAXKEEPMAIL);
      bell();
      refresh();
      igetch();
      return keep;
    }
  }
  return 0;
}


static void
hold_mail(fpath, receiver)
  char *fpath;
  char *receiver;
{
  char buf[80], title[128];

  getdata(b_lines - 1, 0, "�H��w���Q�H�X�A�O�_�ۦs���Z(Y/N)�H[N] ",
    buf, 4, LCECHO);
  if (buf[0] == 'y')
  {
    fileheader mymail;

    sethomepath(buf, cuser.userid);
    stampfile(buf, &mymail);

    mymail.savemode = 'H';	/* hold-mail flag */
    mymail.filemode = FILE_READ;
    strcpy(mymail.owner, "[��.��.��]");
    if (receiver)
    {
      sprintf(title, "(%s) %s", receiver, save_title);
      strncpy(mymail.title, title, TTLEN);
    }
    else
      strcpy(mymail.title, save_title);

    sethomedir(title, cuser.userid);
    if (append_record(title, &mymail, sizeof(mymail)) != -1)
    {
      unlink(buf);
      link(fpath, buf);
    }
  }
}


int
do_send(userid, title)
  char *userid, *title;
{
  fileheader mhdr;
  struct stat st;
  char fpath[STRLEN], buf[80], *ip;
  int fp;

#ifdef INTERNET_PRIVATE_EMAIL
  int internet_mail;

  if (strchr(userid, '@'))
  {
    internet_mail = 1;
  }
  else
  {
    internet_mail = 0;
#endif

    if (!getuser(userid))
      return -1;
    if (!(xuser.userlevel & PERM_READMAIL))
      return -3;

    if (!title)
      getdata(2, 0, "�D�D�G", save_title, TTLEN, DOECHO);
    curredit |= EDIT_MAIL;

#ifdef INTERNET_PRIVATE_EMAIL
  }
#endif

  setutmpmode(SMAIL);

  fpath[0] = '\0';

#ifdef INTERNET_PRIVATE_EMAIL
  if (internet_mail)
  {
    int res, ch;

    if (vedit(fpath, NA) == -1)
    {
      unlink(fpath);
      clear();
      return -2;
    }
    clear();
    prints("�H��Y�N�H�� %s\n���D���G%s\n�T�w�n�H�X��? (Y/N) [Y]",
      userid, title);
    ch = igetch();
    switch (ch)
    {
    case 'N':
    case 'n':
      outs("N\n�H��w����");
      res = -2;
      break;

    default:
      outs("Y\n�еy��, �H��ǻ���...\n");
      res = bbs_sendmail(fpath, title, userid);
      hold_mail(fpath, userid);
    }
    unlink(fpath);
    return res;
  }
  else
  {
#endif

    if (vedit(fpath, YEA) == -1)
    {
      unlink(fpath);
      clear();
      return -2;
    }
    clear();

    sethomepath(genbuf, userid);
    stampfile(genbuf, &mhdr);
    rename(fpath, genbuf);
    strcpy(mhdr.owner, cuser.userid);
    strncpy(mhdr.title, save_title, TTLEN);
    mhdr.savemode = '\0';
    sethomedir(fpath, userid);
    if (append_record(fpath, &mhdr, sizeof(mhdr)) == -1)
      return -1;

    hold_mail(genbuf, userid);
    return 0;

#ifdef INTERNET_PRIVATE_EMAIL
  }
#endif
}


void
my_send(uident)
  char *uident;
{
  switch (do_send(uident, NULL))
  {
  case -1:
    outs(err_uid);
    break;
  case -2:
    outs(msg_cancel);
    break;
  case -3:
    prints("�ϥΪ� [%s] �L�k���H", uident);
    break;
  }
  pressanykey();
}


int
m_send()
{
  char uident[40];

  stand_title("�E������");
  usercomplete(msg_uid, uident);
  if (uident[0])
    my_send(uident);
  return 0;
}


/* ------------------------------------------------------------ */
/* �s�ձH�H�B�^�H : multi_send, multi_reply			 */
/* ------------------------------------------------------------ */

extern struct word *toplev;


static void
multi_list(reciper)
  int *reciper;
{
  char uid[16];

  while (1)
  {
    getdata(1, 0, "�s�� (A)�W�[ (D)�R�� (I/3/2/1)�ޤJ�n�ͦW�� (M)�w�� (Q)�����H[M] ",
      genbuf, 4, LCECHO);
    switch (genbuf[0])
    {
    case 'a':
      while (1)
      {
	move(1, 0);
	usercomplete("�п�J�n�W�[���N��(�u�� ENTER �����s�W): ", uid);
	if (uid[0] == '\0')
	  break;

	move(2, 0);
	clrtoeol();

	if (!searchuser(uid))
	  outs(err_uid);
	else if (!InNameList(uid))
	{
	  AddNameList(uid);
	  (*reciper)++;
	}
	ShowNameList(3, 0, msg_cc);
      }
      break;

    case 'd':
      while (*reciper)
      {
	move(1, 0);
	namecomplete("�п�J�n�R�����N��(�u�� ENTER �����R��): ", uid);
	if (uid[0] == '\0')
	  break;
	if (RemoveNameList(uid))
	{
	  (*reciper)--;
	}
	ShowNameList(3, 0, msg_cc);
      }
      break;

    case '1':
    case '2':
    case '3':
      listfile[5] = genbuf[0];
      genbuf[0] = '1';

    case 'i':
      setuserfile(genbuf, genbuf[0] == '1' ? listfile : fn_overrides);
      LoadNameList(reciper, genbuf, msg_cc);
      break;

    case 'q':
      *reciper = 0;
    default:
      return;
    }
  }
}


static int
multi_send(title)
  char *title;
{
  FILE *fp;
  struct word *p;
  fileheader mymail;
  char fpath[TTLEN], *ptr;
  int reciper, listing;

  CreateNameList();

  listing = reciper = 0;

  if (*quote_file)
  {
    AddNameList(quote_user);
    reciper = 1;
    fp = fopen(quote_file, "r");
    while (fgets(genbuf, 256, fp))
    {
      if (strncmp(genbuf, "�� ", 3))
      {
	if (listing)
	  break;
      }
      else
      {
	if (listing)
	{
	  strtok(ptr = genbuf + 3, " \n\r");
	  do
	  {
	    if (searchuser(ptr) && !InNameList(ptr) && strcmp(cuser.userid, ptr))
	    {
	      AddNameList(ptr);
	      reciper++;
	    }
	  } while (ptr = (char *) strtok(NULL, " \n\r"));
	}
	else if (!strncmp(genbuf + 3, "[�q�i]", 6))
	  listing = 1;
      }
    }
    ShowNameList(3, 0, msg_cc);
  }

  multi_list(&reciper);
  move(1, 0);
  clrtobot();

  if (reciper)
  {
    setutmpmode(SMAIL);

    if (title)
    {
      do_reply_title(2, title);
    }
    else
    {
      getdata(2, 0, "�D�D�G", fpath, 64, DOECHO);
      sprintf(save_title, "[�q�i] %s", fpath);
    }

    setuserfile(fpath, fn_notes);

    if (fp = fopen(fpath, "w"))
    {
      fprintf(fp, "�� [�q�i] �@ %d �H����", reciper);
      listing = 80;

      for (p = toplev; p; p = p->next)
      {
	reciper = strlen(p->word) + 1;
	if (listing + reciper > 75)
	{
	  listing = reciper;
	  fprintf(fp, "\n��");
	}
	else
	  listing += reciper;

	fprintf(fp, " %s", p->word);
      }
      memset(genbuf, '-', 75);
      genbuf[75] = '\0';
      fprintf(fp, "\n%s\n\n", genbuf);
      fclose(fp);
    }

    curredit |= EDIT_LIST;

    if (vedit(fpath, YEA) == -1)
    {
      unlink(fpath);
      curredit = 0;
      outs(msg_cancel);
      pressanykey();
      return;
    }

    stand_title("�H�H��...");

    listing = 80;

    for (p = toplev; p; p = p->next)
    {
      reciper = strlen(p->word) + 1;
      if (listing + reciper > 75)
      {
	listing = reciper;
	outc('\n');
      }
      else
      {
	listing += reciper;
	outc(' ');
      }
      outs(p->word);

      sethomepath(genbuf, p->word);
      stampfile(genbuf, &mymail);
      unlink(genbuf);
      link(fpath, genbuf);

      strcpy(mymail.owner, cuser.userid);
      strcpy(mymail.title, save_title);
      mymail.savemode = 'M';	/* multi-send flag */
      sethomedir(genbuf, p->word);
      if (append_record(genbuf, &mymail, sizeof(mymail)) == -1)
	outs(err_uid);
    }
    hold_mail(fpath, NULL);
    unlink(fpath);
    curredit = 0;
  }
  else
  {
    outs(msg_cancel);
  }
  pressanykey();
}


static int
multi_reply(ent, fhdr, direct)
  int ent;
  fileheader *fhdr;
  char *direct;
{
  if (fhdr->savemode != 'M')
    return mail_reply(ent, fhdr, direct);

  stand_title("�s�զ^�H");
  strcpy(quote_user, fhdr->owner);
  setuserfile(quote_file, fhdr->filename);
  multi_send(fhdr->title);
  return 0;
}


int
mail_list()
{
  stand_title("�s�ձH�H");
  multi_send(NULL);
  return 0;
}


int
m_list()
{
  int aborted;

  getdata(b_lines, 0, "�W���� (E)�s�� (D)�R�� (Q)�����H[Q] ",
    genbuf, 4, LCECHO);

  if (genbuf[0] == 'd')
    aborted = 1;
  else if (genbuf[0] == 'e')
    aborted = 2;
  else
    aborted = 0;

  if (aborted)
  {
    char listpath[64], ans[4];

    getdata(b_lines, 0, "�п�ܦW�� (1/2/3)�H[1] ", ans, 3, DOECHO);

    if (ans[0] == '\0')
      ans[0] = '1';
    if (ans[0] >= '1' && ans[0] <= '3')
    {
      listfile[5] = ans[0];
      setuserfile(listpath, listfile);
      if (aborted == 1)
      {
	unlink(listpath);
	outmsg(msg_del_ok);
      }
      else
      {
	int reciper;

	stand_title("�s��W��");
	reciper = 0;
	CreateNameList();
	LoadNameList(&reciper, listpath, msg_cc);
	multi_list(&reciper);
	SaveNameList(listpath);

	pressanykey();
	return 0;
      }
    }
  }
  return XEASY;
}


static int
m_forward(ent, fhdr, direct)
  int ent;
  fileheader *fhdr;
  char *direct;
{
  char uid[STRLEN];
  char *t;
  FILE *fp;

  stand_title("��F�H��");
  usercomplete(msg_uid, uid);
  if (uid[0] == '\0')
  {
    return FULLUPDATE;
  }

  strcpy(quote_user, fhdr->owner);
  setuserfile(quote_file, fhdr->filename);
  sprintf(save_title, "%.64s (fwd)", fhdr->title);
  move(1, 0);
  clrtobot();
  prints("��H��: %s\n��  �D: %s\n", uid, save_title);

  switch (do_send(uid, save_title))
  {
  case -1:
    outs(err_uid);
    break;
  case -2:
    outs(msg_cancel);
    break;
  case -3:
    prints("�ϥΪ� [%s] �L�k���H", uid);
    break;
  }
  pressanykey();
  return FULLUPDATE;
}


/* JhLin: At most 128 mail */

int delmsgs[128];
int delcnt;
int mrd;


static int
read_new_mail(fptr)
  fileheader *fptr;
{
  static int idc;
  char done = NA, delete_it;
  char fname[256];

  if (fptr == NULL)
  {
    delcnt = 0;
    idc = 0;
    return 0;
  }
  idc++;
  if (fptr->filemode)
    return 0;
  prints("�z�nŪ�Ӧ�[%s]���T��(%s)�ܡH", fptr->owner, fptr->title);
  getdata(1, 0, msg_sure_yn, genbuf, 2, LCECHO);
  if (genbuf[0] == 'n')
    return 0;

  setuserfile(fname, fptr->filename);
  fptr->filemode |= FILE_READ;
  if (substitute_record(currmaildir, fptr, sizeof(*fptr), idc))
    return -1;

  mrd = 1;
  delete_it = NA;
  while (!done)
  {
    more(fname, NA);
    move(b_lines, 0);
    outs(msg_mailer);
    clrtoeol();
    refresh();

    switch (egetch())
    {
    case 'r':
    case 'R':
      mail_reply(idc, fptr, currmaildir);
      break;
    case 'x':
      m_forward(idc, fptr, currmaildir);
      break;
    case 'y':
      multi_reply(idc, fptr, currmaildir);
      break;
    case Ctrl('X'):
      mail_post(idc, fptr, currmaildir);
      break;
    case 'd':
    case 'D':
      delete_it = YEA;
    default:
      done = YEA;
    }
  }
  if (delete_it)
  {
    clear();
    prints("�R���H��m%s�n", fptr->title);
    getdata(1, 0, msg_sure_ny, genbuf, 2, LCECHO);
    if (genbuf[0] == 'y')
    {
      unlink(fname);
      delmsgs[delcnt++] = idc;
    }
  }
  clear();
  return 0;
}


int
m_new()
{
  clear();
  mrd = 0;
  setutmpmode(RMAIL);
  read_new_mail(NULL);
  clear();
  curredit |= EDIT_MAIL;
  if (apply_record(currmaildir, read_new_mail, sizeof(fileheader)) == -1)
  {
    outs("�S���s�H��F");
    pressanykey();
    return -1;
  }
  curredit = 0;
  if (delcnt)
  {
    while (delcnt--)
      delete_record(currmaildir, sizeof(fileheader), delmsgs[delcnt]);
  }
  outs(mrd ? "�H�w�\\��" : "�S���s�H��F");
  pressanykey();
  return -1;
}


static void
mailtitle()
{
  showtitle("\0�l����", BoardName);
  outs("\
[��]���}  [��,��]���  [��,r]�\\Ū�H��  [R]�^�H   [x]��F  [y]�s�զ^�H  �D�U[h]\n[7m\
 �s��   �� ��  �@ ��          �H  ��  ��  �D                                  [0m");
}


static void
maildoent(num, ent)
  fileheader *ent;
{
  char *title, *mark, color, type = "+ Mm"[ent->filemode];

  title = subject(mark = ent->title);
  if (title == mark)
  {
    color = '1';
    mark = "��";
  }
  else
  {
    color = '3';
    mark = "R:";
  }

  if (strncmp(currtitle, title, 40))
    prints("%5d %c %-7s%-15.14s%s %.46s\n", num, type,
      ent->date, ent->owner, mark, title);
  else
    prints("%5d %c %-7s%-15.14s[1;3%cm%s %.46s[0m\n", num, type,
      ent->date, ent->owner, color, mark, title);
}


#ifdef POSTBUG
extern int bug_possible;
#endif


static int
mail_del(ent, fhdr, direct)
  int ent;
  fileheader *fhdr;
  char *direct;
{
  if (fhdr->filemode & FILE_MARKED)
    return DONOTHING;

  getdata(b_lines, 0, msg_del_ny, genbuf, 3, LCECHO);
  if (genbuf[0] == 'y')
  {
    char buf[STRLEN];
    char *t;
    extern int cmpfilename();

    strcpy(currfile, fhdr->filename);
    if (!delete_file(direct, sizeof(*fhdr), ent, cmpfilename))
    {

      setdirpath(genbuf, direct, fhdr->filename);
      unlink(genbuf);

      if( currmode & MODE_SELECT ){
         int now;
         sethomedir(genbuf,cuser.userid);
         now=getindex(genbuf,fhdr->filename,sizeof(fileheader));
         delete_file (genbuf, sizeof(fileheader),now,cmpfilename);
      }       
      return DIRCHANGED;
    }
  }
  return READ_REDRAW;
}


static int
mail_read(ent, fhdr, direct)
  int ent;
  fileheader *fhdr;
  char *direct;
{
  char buf[64];
  char *t;
  char done, delete_it, replied;

  clear();
  setdirpath(buf, direct, fhdr->filename);
  strncpy(currtitle, subject(fhdr->title), 40);
  done = delete_it = replied = NA;
  while (!done)
  {
    more(buf, NA);
    move(b_lines, 0);
    clrtoeol();
    refresh();
    outs(msg_mailer);

    switch (egetch())
    {
    case 'r':
    case 'R':
      replied = YEA;
      mail_reply(ent, fhdr, direct);
      break;
    case 'x':
      m_forward(ent, fhdr, direct);
      break;
    case 'y':
      multi_reply(ent, fhdr, direct);
      break;
    case Ctrl('X'):
      mail_post(ent, fhdr, direct);
      break;
    case 'd':
      delete_it = YEA;
    default:
      done = YEA;
    }
  }
  if (delete_it)
    mail_del(ent, fhdr, direct);
  else
  {
    fhdr->filemode |= FILE_READ;

#ifdef POSTBUG
    if (replied)
      bug_possible = YEA;
#endif

    substitute_record(currmaildir, fhdr, sizeof(*fhdr), ent);

#ifdef POSTBUG
    bug_possible = NA;
#endif
  }
  return FULLUPDATE;
}


/* ---------------------------------------------- */
/* in boards/mail �^�H����@�̡A��H����i	  */
/* ---------------------------------------------- */

int
mail_reply(ent, fhdr, direct)
  int ent;
  fileheader *fhdr;
  char *direct;
{
  char uid[STRLEN];
  char *t,*tt;
  FILE *fp;

  stand_title("�^  �H");

  /* �P�_�O boards �� mail */

  if (curredit & EDIT_MAIL)
    setuserfile(quote_file, fhdr->filename);
  else
    setbfile(quote_file, currboard, fhdr->filename);

  /* find the author */

  strcpy(quote_user, fhdr->owner);

  if (strchr(quote_user, '.'))
  {
    genbuf[0] = '\0';
    if (fp = fopen(quote_file, "r"))
    {
      fgets(genbuf, 512, fp);
      fclose(fp);
    }

    t = strtok(genbuf, str_space);
    if (!strcmp(t, str_author1) || !strcmp(t, str_author2))
    {
      strcpy(uid, strtok(NULL, str_space));
      if(!strchr(uid,'@'))
      {
        t = strtok(NULL,">)");
        if( (tt=strchr(t,'<')) || (tt=strchr(t,'(')) )
          strcpy(uid,tt+1); 
      } 
    }
    else
    {
      outs("���~: �䤣��@�̡C");
      pressanykey();
      return FULLUPDATE;
    }
  }
  else
    strcpy(uid, quote_user);

  /* make the title */

  do_reply_title(3, fhdr->title);
  prints("\n���H�H: %s\n��  �D: %s\n", uid, save_title);

  /* edit, then send the mail */

  ent = curredit;
  switch (do_send(uid, save_title))
  {
  case -1:
    outs(err_uid);
    break;
  case -2:
    outs(msg_cancel);
    break;
  case -3:
    prints("�ϥΪ� [%s] �L�k���H", uid);
    break;
  }
  curredit = ent;
  pressanykey();
  return FULLUPDATE;
}


static int
mail_mark(ent, fhdr, direct)
  int ent;
  fileheader *fhdr;
  char *direct;
{
  fhdr->filemode ^= FILE_MARKED;
  substitute_record(currmaildir, fhdr, sizeof(*fhdr), ent);
  return (PART_REDRAW);
}


/* help for mail reading */

static char *mail_help[] =
{
  "\0�q�l�H�c�ާ@����",
  "\01�򥻩R�O",
  "(p)(��)    �e�@�g�峹",
  "(n)(��)    �U�@�g�峹",
  "(P)(PgUp)  �e�@��",
  "(N)(PgDn)  �U�@��",
  "(##)(cr)   ����� ## ��",
  "($)        ����̫�@��",
  "\01�i���R�O",
  "(r)(��)    Ū�H",
  "(R)        �^�H",
  "(x)        ��F�H��",
  "(y)        �s�զ^�H",
  "(^x)       ����H��ܬݪO"

#ifdef INTERNET_EMAIL
  "(F)        �N�H�ǰe�^�z���q�l�H�c",
#endif

  "(d)        �������H",
  "(D)        �������w�d�򪺫H",
  "(m)        �N�H�аO�A�H���Q�M��",
  NULL
};


static int
m_help()
{
  show_help(mail_help);
  return FULLUPDATE;
}



int
mail_post(ent, fhdr, direct)
  int ent;
  fileheader *fhdr;
  char *direct;
{
  char bname[20];
  char bpath[80];
  char fname[80];
  struct stat st;
  fileheader xfile;
  FILE *xptr;
  
  move(0, 0);
  clrtoeol();
  make_blist();
  
  namecomplete("������峹��ݪO�G", bname);
  if (*bname == '\0' || !haspostperm(bname))
    return FULLUPDATE;

  sprintf(genbuf, "�ĥέ���D�m%.60s�n��?[Y] ", fhdr->title);
  getdata(1, 0, genbuf, genbuf + 512, 3, LCECHO);
  if (genbuf[512] == 'n')
  {
    if (getdata(1, 0, "���D�G", genbuf, TTLEN, DOECHO))
      strcpy(save_title, genbuf);
  }
  else
    strcpy(save_title, fhdr->title);
  
  getdata(2, 0, "(S)�s�� (L)���� (Q)�����H[Q] ", genbuf, 3, LCECHO);
  if (genbuf[0] == 'l' || genbuf[0] == 's')
  {
    setbpath(bpath, bname);
    stampfile(bpath, &xfile);
    strcpy(xfile.owner, cuser.userid);
    strcpy(xfile.title, save_title);
    if (genbuf[0] == 'l')
    {
      xfile.savemode = 'L';
      xfile.filemode = FILE_LOCAL;
    }
    else
      xfile.savemode = 'S';
      
    sethomefile(fname,cuser.userid, fhdr->filename);  /*fname=user�H�c�̪��ɮ�*/
    xptr = fopen(bpath, "w");
    strcpy(bpath, currboard);	/*��currboard�Ȧs�_��*/
    strcpy(currboard, bname);	/*bname:�npost���O,write_header()�|��currboard�]�wheader���O�W*/
    write_header(xptr);	
    strcpy(currboard, bpath);	/*�Ncurrboard��_*/

    fprintf(xptr, "�� [��������� %s ���H�c]\n\n", cuser.userid);
    b_suckinfile(xptr, fname);	/*�N�H�c�̪��H�g��post�h*/
    addsignature(xptr);
    fclose(xptr);
    
    setbdir(fname, bname);	/*�Nheader�g�i.DIR*/
    append_record(fname, (char *) &xfile, sizeof(xfile));
    if (!xfile.filemode)
      outgo_post(&xfile, bname);
    cuser.numposts++;
    outs("�峹�������");
    pressanykey();
  }
  return FULLUPDATE;
}


static struct one_key mail_comms[] = {
  'd', mail_del,
  'D', del_range,
  'r', mail_read,
  'R', mail_reply,
  'm', mail_mark,
  'x', m_forward,
  'y', multi_reply,
  Ctrl('X'),mail_post,

  'h', m_help,
  '\0', NULL
};


int
m_read()
{
  if (get_num_records(currmaildir, sizeof(fileheader)))
  {
    curredit = EDIT_MAIL;
    i_read(RMAIL, currmaildir, mailtitle, maildoent, mail_comms);
    curredit = 0;
    return 0;
  }
  else
  {
    outs("�z�S���ӫH");
    return XEASY;
  }
}



/* �H�H�浹 sendmail�A�U�C�i�H�ٲ� */

#if 0
#define BBSMAILDIR "/usr/spool/mqueue"


static void
spacestozeros(s)
  char *s;
{
  while (*s)
  {
    if (*s == ' ')
      *s = '0';
    s++;
  }
}


static int
getqsuffix(s)
  char *s;
{
  struct stat stbuf;
  char qbuf[STRLEN], dbuf[STRLEN];
  char c1 = 'A', c2 = 'A';
  int pos = strlen(BBSMAILDIR) + 3;

  sprintf(dbuf, "%s/dfAA%5d", BBSMAILDIR, currpid);
  sprintf(qbuf, "%s/qfAA%5d", BBSMAILDIR, currpid);
  spacestozeros(dbuf);
  spacestozeros(qbuf);
  while (1)
  {
    if (stat(dbuf, &stbuf) && stat(qbuf, &stbuf))
      break;
    if (c2 == 'Z')
    {
      c2 = 'A';
      if (c1 == 'Z')
	return -1;
      else
	c1++;
      dbuf[pos] = c1;
      qbuf[pos] = c1;
    }
    else
      c2++;
    dbuf[pos + 1] = c2;
    qbuf[pos + 1] = c2;
  }
  strcpy(s, &(qbuf[pos]));
  return 0;
}


static void
convert_tz(local, gmt, buf)
  int gmt, local;
  char *buf;
{
  local -= gmt;
  if (local < -11)
    local += 24;
  else if (local > 12)
    local -= 24;
  sprintf(buf, " %4d", abs(local * 100));
  spacestozeros(buf);
  if (local < 0)
    buf[0] = '-';
  else if (local > 0)
    buf[0] = '+';
  else
    buf[0] = '\0';
}


static int
createqf(title, qsuffix)
  char *title, *qsuffix;
{
  static int configured = 0;
  static char myhostname[STRLEN];
  static char myusername[20];
  char mytime[STRLEN];
  char idtime[STRLEN];
  char qfname[STRLEN];
  char t_offset[6];
  FILE *qfp;
  time_t timenow;
  int savehour;
  struct tm *gtime, *ltime;
  struct hostent *hbuf;
  struct passwd *pbuf;

  if (!configured)
  {
    /* get host name */
    gethostname(myhostname, STRLEN);
    hbuf = gethostbyname(myhostname);
    if (hbuf)
      strncpy(myhostname, hbuf->h_name, STRLEN);

    /* get bbs uident */
    pbuf = getpwuid(getuid());
    if (pbuf)
      strncpy(myusername, pbuf->pw_name, 20);
    if (hbuf && pbuf)
      configured = 1;
    else
      return -1;
  }

  /* get file name */
  sprintf(qfname, "%s/qf%s", BBSMAILDIR, qsuffix);
  if ((qfp = fopen(qfname, "w")) == NULL)
    return -1;

  /* get time */
  time(&timenow);
  ltime = localtime(&timenow);

#ifdef SYSV
  ascftime(mytime, "%a, %d %b %Y %T ", ltime);
#else
  strftime(mytime, sizeof(mytime), "%a, %d %b %Y %T ", ltime);
#endif

  savehour = ltime->tm_hour;
  gtime = gmtime(&timenow);
  strftime(idtime, sizeof(idtime), "%Y%m%d%y%H%M", gtime);
  convert_tz(savehour, gtime->tm_hour, t_offset);
  strcat(mytime, t_offset);
  fprintf(qfp, "P1000\nT%lu\nDdf%s\nS%s\nR%s\n", timenow, qsuffix,
    myusername, cuser.email);

  /* do those headers! */
  fprintf(qfp, "HReceived: by %s (" MYVERSION ")\n\tid %s; %s\n",
    myhostname, qsuffix, mytime);
  fprintf(qfp, "HReturn-Path: <%s@%s>\n", myusername, myhostname);
  fprintf(qfp, "HDate: %s\n", mytime);
  fprintf(qfp, "HMessage-Id: <%s.%s@%s>\n", idtime, qsuffix,
    myhostname);
  fprintf(qfp, "HFrom: %s@%s (%s in NTHU CS BBS)\n", myusername, myhostname, cuser.userid);
  fprintf(qfp, "HSubject: %s (fwd)\n", title);
  fprintf(qfp, "HTo: %s\n", cuser.email);
  fprintf(qfp, "HX-Forwarded-By: %s (%s)\n", cuser.userid,

#ifdef REALNAME
    cuser.realname);
#else
    cuser.username);
#endif

  fprintf(qfp, "HX-Disclaimer: %s �糧�H���e�����t�d�C\n", BoardName);
  fclose(qfp);
  return 0;
}
#endif


int
bbs_sendmail(fpath, title, receiver)
  char *fpath, *title, *receiver;
{
  static int configured = 0;
  static char myhostname[STRLEN];
  static char myusername[20];
  struct hostent *hbuf;
  struct passwd *pbuf;
  char *ptr;

  FILE *fin, *fout;

  /* ���~�d�I */

  if (ptr = strstr(receiver, str_mail_address))
  {
    fileheader mymail;
    char hacker[20];
    int len;

    len = ptr - receiver;
    memcpy(hacker, receiver, len);
    hacker[len] = '\0';
    if (!searchuser(hacker))
    {
      return -2;
    }
    sethomepath(genbuf, hacker);
    stampfile(genbuf, &mymail);
    if (!strcmp(hacker, cuser.userid))
    {
      strcpy(mymail.owner, "[��.��.��]");
      mymail.filemode = FILE_READ;
    }
    else
      strcpy(mymail.owner, cuser.userid);
    strncpy(mymail.title, title, TTLEN);
    unlink(genbuf);
    link(fpath, genbuf);
    sethomedir(genbuf, hacker);
    return append_record(genbuf, &mymail, sizeof(mymail));
  }

  /* setup the hostname and username */
  if (!configured)
  {
    /* get host name */
    gethostname(myhostname, STRLEN);
    hbuf = gethostbyname(myhostname);
    if (hbuf)
      strncpy(myhostname, hbuf->h_name, STRLEN);

    /* get bbs uident */
    pbuf = getpwuid(getuid());
    if (pbuf)
      strncpy(myusername, pbuf->pw_name, 20);
    if (hbuf && pbuf)
      configured = 1;
    else
      return -1;
  }

  /* Running the sendmail */

#ifdef	INTERNET_PRIVATE_EMAIL
  if (fpath == NULL)
  {
    sprintf(genbuf, "/usr/sbin/sendmail %s ", receiver);
    fin = fopen("etc/confirm", "r");
  }
  else
  {
    sprintf(genbuf, "/usr/sbin/sendmail -f %s%s %s ", cuser.userid, str_mail_address, receiver);
    fin = fopen(fpath, "r");
  }
  fout = popen(genbuf, "w");
  if (fin == NULL || fout == NULL)
    return -1;

  if (fpath)
    fprintf(fout, "Reply-To: %s%s\nFrom: %s%s\n",
      cuser.userid, str_mail_address, cuser.userid, str_mail_address);
#else
  sprintf(genbuf, "/usr/sbin/sendmail %s ", receiver);
  fout = popen(genbuf, "w");
  fin = fopen(fpath ? fpath : "etc/confirm", "r");
  if (fin == NULL || fout == NULL)
    return -1;

  if (fpath)
    fprintf(fout, "From: %s@%s (%s)\n",
      myusername, myhostname, BBSNAME);
#endif

  fprintf(fout, "To: %s\nSubject: %s\n", receiver, title);
  fprintf(fout, "X-Disclaimer: " BOARDNAME
    "�糧�H���e�����t�d�C\n\n");

  while (fgets(genbuf, 255, fin))
  {
    if (genbuf[0] == '.' && genbuf[1] == '\n')
      fputs(". \n", fout);
    else
      fputs(genbuf, fout);
  }
  fclose(fin);
  fprintf(fout, ".\n");
  pclose(fout);
  return 0;
}


int
doforward(direct, fh, mode)
  char *direct;
  fileheader *fh;
  int mode;			/* �O�_ uuencode */
{
  static char address[60];
  char fname[STRLEN];
  int return_no;

  clear();
  if (address[0] == '\0')
  {
    strcpy(address, cuser.email);
  }
  prints("�Ъ����� Enter �ĥιw�]�a�} [%s]\n", address);
  getdata(1, 0, "�Ϊ̿�J��L�a�}�G", fname, 60, DOECHO);
  if (fname[0])
    strcpy(address, fname);
  else
  {
    sprintf(genbuf, "�T�w�N�峹�H�� %s ��(Y/N)�H[Y] ", address);
    getdata(2, 0, genbuf, fname, 3, LCECHO);
    if (fname[0] == 'n')
    {
      outs("������H");
      return 1;
    }
  }

  if (invalidaddr(address))
    return -2;

  prints("����H�H�� %s, �еy��...\n", address);

  if (mode)
  {
    char tmp_buf[128];

    sprintf(fname, "/tmp/bbs.uu%05d", currpid);
    sprintf(tmp_buf, "uuencode %s/%s uu.%05d > %s",
      direct, fh->filename, currpid, fname);
    system(tmp_buf);
  }
  else
    sprintf(fname, "%s/%s", direct, fh->filename);

  return_no = bbs_sendmail(fname, fh->title, address);

  if (mode)
    unlink(fname);

  return (return_no);
}
#endif


int
chkmail(rechk)
  int rechk;
{
  static time_t lasttime = 0;
  static int ismail = 0;
  struct stat st;
  fileheader fh;
  int fd;
  register numfiles;
  unsigned char ch;

  if (!HAS_PERM(PERM_BASIC))
    return 0;

  if (stat(currmaildir, &st) < 0)
    return (ismail = 0);

  if ((lasttime >= st.st_mtime) && !rechk)
    return ismail;

  lasttime = st.st_mtime;
  numfiles = st.st_size / sizeof(fileheader);
  if (numfiles <= 0)
    return (ismail = 0);

  /* ------------------------------------------------ */
  /* �ݬݦ��S���H���٨SŪ�L�H�q�ɧ��^�Y�ˬd�A�Ĳv���� */
  /* ------------------------------------------------ */

  if ((fd = open(currmaildir, O_RDONLY)) > 0)
  {
    lseek(fd,(off_t)( st.st_size - 1), SEEK_SET);
    while (numfiles--)
    {
      read(fd, &ch, 1);
      if (!(ch & FILE_READ))
      {
	close(fd);
	return (ismail = 1);
      }
      lseek(fd, (off_t)(-sizeof(fileheader)) - 1, SEEK_CUR);
    }
    close(fd);
  }
  return (ismail = 0);
}


#ifdef	EMAIL_JUSTIFY
void
mail_justify()
{
  more("etc/justify", NA);
  if (valid_ident(cuser.email) && !invalidaddr(cuser.email))
  {
    char title[80], *ptr;
    ushort checksum;		/* 16-bit is enough */
    char ch;

    checksum = usernum;
    ptr = cuser.email;
    while (ch = *ptr++)
    {
      if (ch <= ' ')
	break;
      if (ch >= 'A' && ch <= 'Z')
	ch |= 0x20;
      checksum = (checksum << 1) ^ ch;
    }

    sprintf(title, "[MapleBBS]To %s(%d:%d) [User Justify]",
      cuser.userid, usernum + MAGIC_KEY, checksum);
    if (bbs_sendmail(NULL, title, cuser.email) < 0)
      outs("[1mE-mail address�L�k�{�ҡA�бz��g�u�� E-mail address[0m");
    else
      /*prints("\n%s(%s)�z�n�A�ѩ�z��s E-mail address ���]�w�A\n"
	"�бz���֨� [44m%s[m �Ҧb���u�@���^�Сy�����{�ҫH��z�C",
	cuser.userid, cuser.username, cuser.email);*/
      
      prints("\n%s(%s)�z�n�AE-mail address�{�ҫH��w�g�H�X�C",
	cuser.userid, cuser.username);
     
  }
  else
  {
    prints("\n%s(%s)�z�n�A�ѩ�z�S���u�� E-mail address�A\n"
      "�N�|�l�������\\��A�бz�� [1;42m (U)ser��(R)egister [0m ��g���U����C",
      cuser.userid, cuser.username);
  }
  pressanykey();
}
#endif				/* EMAIL_JUSTIFY */

static char m_fpath[STRLEN];
static char m_title[TTLEN];

#ifdef INTERNET_PRIVATE_EMAIL 
static int
get_mail_addr(urec)
  userec *urec;
{
  if(invalidaddr(urec->email) || strstr(urec->email,"bbs@"))
    return -1;
  bbs_sendmail(m_fpath, m_title, urec->email);
}
#endif

static int
get_mail_user(urec)
  userec *urec;
{
  char buf[128];
  fileheader mhdr;
  if (!getuser(urec->userid))
    return -1;
  if (!(xuser.userlevel & PERM_READMAIL))
    return -3;
  sethomepath(genbuf, urec->userid);
  stampfile(genbuf, &mhdr);
  sprintf(buf,"/bin/cp %s %s",m_fpath, genbuf);
  system(buf);
  strcpy(mhdr.owner, cuser.userid);
  strncpy(mhdr.title, m_title, TTLEN);
  mhdr.savemode = '\0';
  sethomedir(buf, urec->userid);
  if (append_record(buf, &mhdr, sizeof(mhdr)) == -1)
   return -1;
}

static int
m_all(todo)
  int todo;
{
  char buf[TTLEN];
  setutmpmode(SMAIL);
  if(getdata(b_lines-2, 0, "�D�D�G", buf, TTLEN-strlen(BoardName)-4, DOECHO))
  {
     int ch;
     curredit |= EDIT_MAIL;
     sprintf(m_title,"[%s�q�i] %s",BoardName,buf);
     strncpy(save_title,m_title,TTLEN);
     if (vedit(m_fpath, todo) == -1)
     {
       unlink(m_fpath);
       clear();
       return -2;
     }

     clear();
     if(todo)
       prints("�H��Y�N�H��Ҧ�����user���H�c\n���D��:%s\n�T�w�n�H�X��? (Y/N) [Y]",
         m_title);
#ifdef INTERNET_PRIVATE_EMAIL
     else
       prints("�H��Y�N�H��Ҧ�user��e-mail�H�c\n���D���G%s\n�T�w�n�H�X��? (Y/N) [Y]",
         m_title);
#endif
     ch = igetch();
     switch (ch)
     {
       case 'N':
       case 'n':
         outs("N\n�H��w����");
         break;
       default:
         outs("Y\n�еy��, �H��ǻ���...\n");
         if(todo){
           if (apply_record(fn_passwd, get_mail_user, sizeof(userec)) == -1)
             outs(ERR_PASSWD_OPEN);
         }
#ifdef INTERNET_PRIVATE_EMAIL
         else{
           if (apply_record(fn_passwd, get_mail_addr, sizeof(userec)) == -1)
             outs(ERR_PASSWD_OPEN);
         }
#endif
          hold_mail(m_fpath,NULL);
          break;
     }
     unlink(m_fpath);
     return 0; 
  }
}

int
m_to_all()
{
  m_all(1);
}

int
m_internet_all()
{
  m_all(0);
}

