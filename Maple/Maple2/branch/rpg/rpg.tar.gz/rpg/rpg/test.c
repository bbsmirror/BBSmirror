#include <time.h>
#include <stdio.h>

main()
{
  time_t now;
  int test;
  now = time(0);
  test =now;
  printf(".%d\n",test);
}
