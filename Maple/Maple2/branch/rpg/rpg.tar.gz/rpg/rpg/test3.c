#include <stdlib.h>
#include <stdio.h>
#include <time.h>

main()
{
  ran();
}

ran()
{
  while(1)
  {
    srand(time(0));
    printf("%d\n",rand()%21+20);
  }
}