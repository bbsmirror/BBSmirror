#include <sys/time.h>
#include <stdio.h>


main()
{
  struct itimerval value;
  struct itimerval ovalue;
  
/*  value.it_interval=1;
  value.it_value=10000;*/
  
/*  setitimer(ITIMER_, &value, &ovalue);*/
printf("%d\n",getitimer(ITIMER_REAL,&value));
}