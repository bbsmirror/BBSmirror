/*-------------------------------------------------------*/
/* util/topmail.c	( NTHU CS MapleBBS Ver 2.36 )	 */
/*-------------------------------------------------------*/
/* target : �ϥΪ� �H��ƥ� �Ʀ�]			 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#define REAL_INFO
#include "bbs.h"

char genbuf[1024];
char *str_home_file = "home/%s/%s";
char *str_dotdir = ".DIR";

long
get_num_records(fpath, size)
  char *fpath;
{
  struct stat st;
  if (stat(fpath, &st) == -1)
    return 0;
  return (st.st_size / size);
}

void
sethomedir(buf, userid)
  char *buf, *userid;
{
  sprintf(buf, str_home_file, userid, str_dotdir);
}

struct manrec
{
  char userid[IDLEN+1];
  char username[23];
  long nummails;
};
typedef struct manrec manrec;
struct manrec allman[MAXUSERS];

userec aman;
int num;
FILE *fp;

#define	TYPE_MAIL	0


int
mail_cmp(b, a)
  struct manrec *a, *b;
{
  return (a->nummails - b->nummails);
}

void
top(type)
{
  static char *str_type[] = {"�H���"};
  int i, j, rows = (num + 1) / 2;
  char buf1[80], buf2[80];

  if (type)
    fprintf(fp, "\n\n");

  fprintf(fp, "\t\t\
[1;33m===========[%dm    %s�ƱƦ�]    [40m============[m\n\n\
[1;36m �W�� �N��       �ʺ�            �ƥ�    �W�� �N��       �ʺ�            �ƥ�[m\n\
�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w  �w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w\
", type + 44, str_type[type]);

  for (i = 0; i < rows; i++)
  {
    sprintf(buf1, "[%2d] %-11.11s%-16.16s%4d",
      i + 1, allman[i].userid, allman[i].username,
      allman[i].nummails);
    j = i + rows;
    sprintf(buf2, "[%2d] %-11.11s%-16.16s%d",
      j + 1, allman[j].userid, allman[j].username,
      allman[j].nummails);
    if (i < 3)
      fprintf(fp, "\n [1;%dm%-40s[0;37m%s", 31 + i, buf1, buf2);
    else
      fprintf(fp, "\n %-40s%s", buf1, buf2);
  }
}

main(argc, argv)
  int argc;
  char **argv;
{
  FILE *inf;
  int i;

  if (argc < 2)
  {
    printf("Usage: %s num_top\n", argv[0]);
    exit(1);
  }

  num = atoi(argv[1]);
  if (num == 0)
    num = 30;

  inf = fopen(".PASSWDS", "rb");

  if (inf == NULL)
  {
    printf("Sorry, the data is not ready.\n");
    exit(0);
  }

  for (i = 0; fread(&aman, sizeof(userec), 1, inf); i++)
  {
    strcpy(allman[i].userid, aman.userid);
    strncpy(allman[i].username, aman.username,23);
    sethomedir(genbuf, aman.userid);
    allman[i].nummails = get_num_records(genbuf, sizeof(fileheader));
  }

  if ((fp = fopen("etc/topmail", "w")) == NULL)
  {
    printf("cann't open topmail\n");
    return 0;
  }

  qsort(allman, i, sizeof(manrec), mail_cmp);
  top(TYPE_MAIL);

  fclose(fp);
}
