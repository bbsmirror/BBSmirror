
#include <stdio.h>
#include "config.h"

static char     edit_name[50];
static char     flag;

char           *
Edit(void)
{
	extern char     Editor[35];

	char            command[80];

	umask(077);
	ansi_print("1;32", "\n���s�誺�ɮצW�� (�� [Enter] ���p���ɮצW��) : ");
	ansi_flush();
	fgets(edit_name, 49, stdin);
	flag = 'N';
	if (edit_name[0] == '\n') {
		sprintf(edit_name, "/tmp/.bbs.edit.%d", getpid());
		flag = 'Y';
	} else
		edit_name[strlen(edit_name) - 1] = '\0';
	/* Edit */
	sprintf(command, "%s %s", Editor, edit_name);
	system(command);

	return (edit_name);
}

void
Delete(void)
{
	if (flag == 'Y')
		unlink(edit_name);
}
