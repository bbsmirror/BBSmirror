/*-------------------------------------------------------*/
/* announce.c	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : ��ذϾ\Ū�B�s��				 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#include "bbs.h"
#include <time.h>

#define MAXITEMS	160	/* �@�h�ؿ����̦h���X���H */
#define PATHLEN		128

#define ADDITEM		0
#define	ADDGROUP	1


enum
{
  NOBODY, MANAGER, SYSOP
};


typedef struct
{
  char title[63];
  char fdate[9];		/* [mm/dd/yy] */
  char fname[32];
}      ITEM;


typedef struct
{
  ITEM *item[MAXITEMS];
  char mtitle[STRLEN];
  char *path;
  int num, page, now, level;
}      MENU;


static int a_fmode = 0;
static ITEM copybuf;
static char copyfile[PATHLEN];
static char *mytitle = BOARDNAME "�G�i��";
static char *err_dup_fn = "�t�Τ��w���P�W�ɮצs�b�F�I";


static void
a_timestamp(buf, time)
  char *buf;
  time_t *time;
{
  struct tm *pt = localtime(time);
  sprintf(buf, "%02d/%02d/%02d", pt->tm_mon + 1, pt->tm_mday, pt->tm_year);
}


static void
a_additem(pm, myitem)
  MENU *pm;
  ITEM *myitem;
{
  if (pm->num < MAXITEMS)
  {
    ITEM *newitem = (ITEM *) malloc(sizeof(ITEM));
    memcpy(newitem, myitem, sizeof(ITEM));
    pm->item[(pm->num)++] = newitem;
  }
}


static void
a_savenames(pm)
  MENU *pm;
{
  FILE *fn;
  ITEM *item;
  char fpath[PATHLEN];
  int n;

  sprintf(fpath, "%s%s", pm->path, fn_mandex);
  if (fn = fopen(fpath, "w"))
  {
    fprintf(fn, "# Title=%s\n\n", pm->mtitle);
    n = 0;
    while (n < pm->num)
    {
      item = pm->item[n++];
      fprintf(fn, "Name=%s\nDate=%s\nPath=%s\nNumb=%d\n\n",
	item->title, item->fdate, item->fname, n);
    }
    fclose(fn);
    chmod(fpath, 0644);
  }
}


static void
a_loadnames(pm)
  MENU *pm;
{
  FILE *fn;
  char buf[256], *ptr;
  ITEM item;
  int dirty;

  pm->num = 0;
  sprintf(buf, "%s%s", pm->path, fn_mandex);
  if (fn = fopen(buf, "r"))
  {
    dirty = item.fdate[0] = 0;

    while (fgets(buf, 255, fn))
    {
      if (ptr = strchr(buf, '\n'))
	*ptr = '\0';
      ptr = buf + 5;
      if (!strncmp(buf, "Name=", 5))
      {
	strcpy(item.title, ptr);
      }
      else if (!strncmp(buf, "Date=", 5))
      {
	strcpy(item.fdate, ptr);
      }
      else if (!strncmp(buf, "Path=", 5))
      {
	strcpy(item.fname, ptr);
	if (item.fdate[0] == '\0')
	{
	  struct stat st;

	  sprintf(buf, "%s/%s", pm->path, item.fname);
	  if (stat(buf, &st) == 0)
	  {
	    a_timestamp(item.fdate, &st.st_mtime);
	    dirty = 2;
	  }
	}
	a_additem(pm, &item);
	item.fdate[0] = '\0';
      }
      else if (!strncmp(buf, "# Title=", 8))
      {
	strcpy(pm->mtitle, buf + 8);
	dirty++;
      }
    }
    fclose(fn);

    if (pm->mtitle[0] == '\0')
      strcpy(pm->mtitle, mytitle);
    if (dirty >= 2)
      a_savenames(pm);
  }
}


static void
a_showmenu(pm)
  MENU *pm;
{
  static char *mytype[] = {"��    ��", "�ɮצW��"};
  char *title;
  int n, max;
  ITEM *item;

  showtitle("��ؤ峹", pm->mtitle);
  prints("  [1;36m�s��    ��      �D%56s[0m", mytype[a_fmode]);

  if (pm->num)
  {
    n = pm->page;
    max = n + p_lines;
    if (max > pm->num)
      max = pm->num;
    while (n < max)
    {
      item = pm->item[n++];
      title = item->title;
      if (a_fmode)
      {
	prints("\n%5d. %-52.51s%s", n, title, item->fname);
	if (title[1] == (char) 0xbb)
	  outc('/');
      }
      else
      {

#ifdef	INFO_COLOR
	if (title[1] == (char) 0xbb)	/* JhLin: directory */
	  prints("\n%5d. [1;33m%s[0m", n, title);
	else
#endif

	  prints("\n%5d. %-60s[%s]", n, title, item->fdate);
      }
    }
  }
  else
  {
    outs("\n  �m��ذϡn�|�b�l���Ѧa��������� :)");
  }

  move(b_lines, 1);
  outs(pm->level ?
    "[34;45m �i�O  �D�j [31;47m  (h)[30m����  [31m(q/��)[30m���}  [31m(a)[30m�s�W�峹  [31m(g)[30m�s�W�ؿ�  [31m(e)[30m�s���ɮ�  [0m" :
    "[34;45m �i�\\����j [31;47m  (h)[30m����  [31m(q/��)[30m���}  [31m(k��j��)[30m���ʴ��  [31m(enter/��)[30mŪ�����  [0m");
}


static void
a_showhelp(level)
  int level;
{
  clear();
  outs("[36m�i " BOARDNAME "���G��ϥλ��� �j[m\n\n\
[��][q]         ���}��W�@�h�ؿ�\n\
[��][k]         �W�@�ӿﶵ\n\
[��][j]         �U�@�ӿﶵ\n\
[��][r][enter]  �i�J�ؿ���Ū���峹\n\
[^B][PgUp]      �W�����\n\
[^F][PgDn][Spc] �U�����\n\
[##]            ����ӿﶵ\n\n\
[F]             �N�峹�H�^ Internet �l�c\n\
[U]             �N�峹 uuencode ��H�^�l�c\n");

  if (level >= MANAGER)
  {
    outs("\n[36m�i �O�D�M���� �j[m\n\
[a/g]           ������ؤ峹/�}�P�ؿ�\n\
[m/d]           ����/�R���峹\n\
[t/e]           �ק�峹���D/���e\n\
[f/n]           �d��/����ɦW\n\
[c/p]           ����/�߶K�峹\n");
  }

  if (level >= SYSOP)
  {
    outs("\n[36m�i �����M���� �j[m\n\
[v]             �s�� .Name\n");
  }
  pressanykey();
}


static void
a_newitem(pm, mode)
  MENU *pm;
{
  static char *mesg[2] = {
    "[�s�W�峹] �п�J�ɮצW�١G",	/* ADDITEM */
  "[�s�W�ؿ�] �п�J�ؿ��W�١G"};	/* ADDGROUP */

  char fpath[PATHLEN];
  ITEM item;
  time_t dtime;

  pm->page = 9999;
  if (!getdata(t_lines - 2, 1, mesg[mode], item.fname, 32, DOECHO))
    return;
  if (invalid_fname(item.fname))
  {
    outs(err_filename);
    igetch();
  }
  else
  {
    sprintf(fpath, "%s/%s", pm->path, item.fname);
    if (dashf(fpath) || dashd(fpath))
    {
      outs(err_dup_fn);
      igetch();
    }
    else
    {
      strcpy(item.title, "�� ");/* A1BA/BB �� */
      if (!getdata(b_lines, 1, "�п�J���D�G", &item.title[3], 60, DOECHO))
	return;
      if (mode)
      {				/* ADDGROUP */
	mkdir(fpath, 0755);
	item.title[1] = 0xbb;
      }
      else
      {				/* ADDITEM */
	vedit(fpath, 0);
	chmod(fpath, 0644);
      }
      time(&dtime);
      a_timestamp(item.fdate, &dtime);
      a_additem(pm, &item);
      a_savenames(pm);
    }
  }
}


static void
a_moveitem(pm)
  MENU *pm;
{
  ITEM *tmp;
  char newnum[4];
  int num, n;

  sprintf(genbuf, "�п�J�� %d �ﶵ���s���ǡG", pm->now + 1);
  if (!getdata(b_lines - 1, 1, genbuf, newnum, 4, DOECHO))
    return;
  num = (newnum[0] == '$') ? 9999 : atoi(newnum) - 1;
  if (num >= pm->num)
    num = pm->num - 1;
  else if (num < 0)
    num = 0;
  tmp = pm->item[pm->now];
  if (num > pm->now)
  {
    for (n = pm->now; n < num; n++)
      pm->item[n] = pm->item[n + 1];
  }
  else
  {
    for (n = pm->now; n > num; n--)
      pm->item[n] = pm->item[n - 1];
  }
  pm->item[num] = tmp;
  pm->now = num;
  a_savenames(pm);
}


static void
a_delete(pm)
  MENU *pm;
{
  ITEM *item;
  char fpath[PATHLEN];
  char ans[4];
  int n;

  item = pm->item[pm->now];
  sprintf(fpath, "%s/%s", pm->path, item->fname);

  if (dashf(fpath))
  {
    getdata(b_lines, 1, "�z�T�w�n�R�����ɮ׶�(Y/N)�H[N] ", ans, 3, LCECHO);
    if (ans[0] != 'y')
      return;
    unlink(fpath);
  }
  else if (dashd(fpath))
  {
    getdata(b_lines, 1, "�z�T�w�n�R����ӥؿ���(Y/N)�H[N] ", ans, 3, LCECHO);
    if (ans[0] != 'y')
      return;
    sprintf(genbuf, "/bin/rm -rf %s", fpath);
    system(genbuf);
  }

  free(item);
  (pm->num)--;
  for (n = pm->now; n < pm->num; n++)
    pm->item[n] = pm->item[n + 1];
  a_savenames(pm);
}


static void
a_newname(pm)
  MENU *pm;
{
  ITEM *item;
  char fname[32];
  char fpath[PATHLEN];
  char *mesg;

  item = pm->item[pm->now];
  if (!getdata(b_lines - 1, 1, "�s�ɦW�G", fname, 32, DOECHO))
    return;
  if (invalid_fname(fname))
  {
    mesg = err_filename;
  }
  else
  {
    sprintf(fpath, "%s/%s", pm->path, fname);
    if (dashf(fname) || dashd(fname))
    {
      mesg = err_dup_fn;
    }
    else
    {
      sprintf(genbuf, "%s/%s", pm->path, item->fname);
      if (!rename(genbuf, fpath))
      {
	strcpy(item->fname, fname);
	a_savenames(pm);
	return;
      }
      mesg = "�ɦW��異�ѡI";
    }
  }
  outs(mesg);
  igetch();
}


static void
a_copyitem(pm)
  MENU *pm;
{
  ITEM *item;

  item = pm->item[pm->now];
  memcpy(&copybuf, item, sizeof(ITEM));
  sprintf(copyfile, "%s/%s", pm->path, copybuf.fname);
  outmsg("�ɮ׼аO�����C[�`�N] ������~��R�����!");
  igetch();
}


static void
a_pasteitem(pm)
  MENU *pm;
{
  char newpath[PATHLEN];
  char ans[2];

  move(b_lines, 1);
  if (copyfile[0])
  {
    sprintf(newpath, "%s/%s", pm->path, copybuf.fname);
    if (dashf(newpath) || dashd(newpath))
    {
      prints("�ɮ�/�ؿ��p�P�G%s", copybuf.fname);
    }
    else if (strstr(newpath, copyfile))
    {
      outs("�N�ؿ����i�ۤv���l�ؿ����A�|�y���L�a�j��I");
    }
    else
    {
      sprintf(genbuf, "�T�w�n����[%s]��(Y/N)�H[N] ", copybuf.title);
      getdata(b_lines - 1, 1, genbuf, ans, 3, LCECHO);
      if (ans[0] == 'y')
      {
	if (copybuf.title[1] == (char) 0xbb)
	{
	  sprintf(genbuf, "/bin/cp -r %s %s", copyfile, newpath);
	  system(genbuf);
	}
	else
	  link(copyfile, newpath);
	a_additem(pm, &copybuf);
	a_savenames(pm);
      }
      return;
    }
  }
  else
  {
    outs("�Х����� copy �R�O��A paste");
  }
  igetch();
}


static void
a_forward(path, pitem, mode)
  char *path;
  ITEM *pitem;
  int mode;
{
  fileheader fhdr;

  strcpy(fhdr.filename, pitem->fname);
  strcpy(fhdr.title, pitem->title);
  switch (doforward(path, &fhdr, mode))
  {
  case 0:
    outs(msg_fwd_ok);
    break;
  case -1:
    outs(msg_fwd_err1);
    break;
  case -2:
    outs(msg_fwd_err2);
    break;
  }
}


void
a_menu(maintitle, path, lastlevel)
  char *maintitle;
  char *path;
  int lastlevel;
{
  MENU me;
  char fname[PATHLEN];
  int ch;

  setutmpmode(ANNOUNCE);

  me.path = path;
  strcpy(me.mtitle, maintitle);
  a_loadnames(&me);

  /* ��ذ�-tree ���������c�ݩ� cuser ==> BM */

  if (!(me.level = lastlevel))
  {
    char *ptr;

    a_fmode = 0;
    if (ptr = strrchr(me.mtitle, '['))
      me.level = is_BM(ptr + 1);
  }

  me.page = 9999;
  me.now = 0;
  for (;;)
  {
    if (me.now >= me.num && me.num > 0)
      me.now = me.num - 1;
    else if (me.now < 0)
      me.now = 0;

    if (me.now < me.page || me.now >= me.page + p_lines)
    {
      me.page = me.now - (me.now % p_lines);
      a_showmenu(&me);
    }

    ch = cursor_key(2 + me.now - me.page, 0);

    if (ch == 'q' || ch == 'Q' || ch == KEY_LEFT)
      break;

    if (ch >= '0' && ch <= '9')
    {
      if ((ch = search_num(ch, me.num)) != -1)
	me.now = ch;
      me.page = 9999;
      continue;
    }

    switch (ch)
    {
    case KEY_UP:
    case 'k':
      if (--me.now < 0)
	me.now = me.num - 1;
      break;

    case KEY_DOWN:
    case 'j':
      if (++me.now >= me.num)
	me.now = 0;
      break;

    case KEY_PGUP:
    case Ctrl('B'):
      if (me.now >= p_lines)
	me.now -= p_lines;
      else if (me.now > 0)
	me.now = 0;
      else
	me.now = me.num - 1;
      break;

    case ' ':
    case KEY_PGDN:
    case Ctrl('F'):
      if (me.now < me.num - p_lines)
	me.now += p_lines;
      else if (me.now < me.num - 1)
	me.now = me.num - 1;
      else
	me.now = 0;
      break;

    case 'h':
    case '?':
      a_showhelp(me.level);
      me.page = 9999;
      break;

    case '\n':
    case '\r':
    case KEY_RIGHT:
    case 'r':
      if (me.now < me.num)
      {
	sprintf(fname, "%s/%s", path, me.item[me.now]->fname);
	if (dashf(fname))
	  more(fname, YEA);
	else if (dashd(fname))
	  a_menu(me.item[me.now]->title, fname, me.level);
	me.page = 9999;
      }
      break;

    case 'F':
    case 'U':
    case 'Z':
      sprintf(fname, "%s/%s", path, me.item[me.now]->fname);
      if (me.now < me.num && HAS_PERM(PERM_BASIC) && dashf(fname))
      {
	if (ch == 'Z')
	  z_download(fname);
	else
	  a_forward(path, me.item[me.now], ch == 'U');
      }
      else
      {
	move(b_lines - 1, 0);
	outs("�L�k��H������");
      }
      me.page = 9999;
      pressanykey();
    }

    if (me.level >= MANAGER)
    {
      switch (ch)
      {
      case 'a':
	a_newitem(&me, ADDITEM);
	break;
      case 'g':
	a_newitem(&me, ADDGROUP);
	break;
      case 'p':
	a_pasteitem(&me);
	me.page = 9999;
      }

      if (me.num)
	switch (ch)
	{
	case 'm':
	  a_moveitem(&me);
	  me.page = 9999;
	  break;

	case 'D':
	  me.page = -1;
	case 'd':
	  a_delete(&me);
	  me.page = 9999;
	  break;

	case 't':
	  if (getdata(b_lines - 1, 1, "�s���D�G", genbuf, 60, DOECHO))
	  {
	    ITEM *item = me.item[me.now];
	    char *p = item->title;

	    strcpy(p + 3, genbuf);
	    a_savenames(&me);
	    if (p[1] == (char) 0xbb)
	    {
	      FILE *fn;

	      sprintf(fname, "%s/%s%s", path, item->fname, fn_mandex);
	      if (fn = fopen(fname, "a+"))
	      {
		fprintf(fn, "\n# Title=%s\n", p);
		fclose(fn);
	      }
	    }
	  }
	  me.page = 9999;
	  break;

	case 'e':
	case 'E':
	  sprintf(fname, "%s/%s", path, me.item[me.now]->fname);
	  if (dashf(fname))
	  {
	    vedit(fname, 0);
	    me.page = 9999;
	  }
	  break;

	case 'f':
	  a_fmode ^= 1;
	  me.page = 9999;
	  break;

	case 'n':
	  a_newname(&me);
	  me.page = 9999;
	  break;

	case 'c':
	  a_copyitem(&me);
	  me.page = 9999;
	  break;
	}
    }

    if ((me.level == SYSOP) && (ch == 'v'))
    {
      sprintf(fname, "%s%s", path, fn_mandex);
      vedit(fname, 0);
      me.page = 9999;
    }
  }
  for (ch = 0; ch < me.num; ch++)
    free(me.item[ch]);
}


int
Announce()
{
  a_fmode = 0;
  a_menu(mytitle, "man", (HAS_PERM(PERM_SYSOP) ? SYSOP : NOBODY));
  return 0;
}
