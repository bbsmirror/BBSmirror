/*-------------------------------------------------------*/
/* util/bbsmail.c	( NTHU CS MapleBBS Ver 2.36 )    */
/*-------------------------------------------------------*/
/* target : �� Internet �H�H�� BBS �����ϥΪ�            */
/* create : 95/03/29                                     */
/* update : 95/12/15                                     */
/*-------------------------------------------------------*/


#include <stdio.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <fcntl.h>
#include <time.h>
#include <sysexits.h>

#include "bbs.h"


char *fn_passwd = BBSHOME "/.PASSWDS";


#define _BBS_UTIL_C_
#include "cache.c"
#include "record.c"


#define	LOG_FILE	(BBSHOME "/etc/mailog")

void
mailog(msg)
  char *msg;
{
  FILE *fp;

  if (fp = fopen(LOG_FILE, "a"))
  {
    time_t now;
    struct tm *p;

    time(&now);
    p = localtime(&now);
    fprintf(fp, "%02d/%02d/%02d %02d:%02d:%02d <bbsmail> %s\n",
	p->tm_year, p->tm_mon+1, p->tm_mday, p->tm_hour, p->tm_min, p->tm_sec,
	msg);
    fclose(fp);
  }
}


int
mail2bbs(userid)
  char *userid;
{
  fileheader mymail;
  char genbuf[256], title[80], sender[80], *ip, *ptr;
  time_t tmp_time;
  struct stat st;
  FILE *fout;

  /* check if the userid is in our bbs now */
  if (!searchuser(userid))
  {
    sprintf(genbuf, "BBS user <%s> not existed", userid);
    puts(genbuf);
    mailog(genbuf);
    return EX_NOUSER;
  }

  sprintf(genbuf, BBSHOME "/home/%s", userid);

  if (stat(genbuf, &st) == -1)
  {
    if (mkdir(genbuf, 0755) == -1)
    {
      printf("mail box create error %s \n", genbuf);
      return -1;
    }
  }
  else if (!(st.st_mode & S_IFDIR))
  {
    printf("mail box error\n");
    return -1;
  }

  printf("dir: %s\n", genbuf);

  /* allocate a file for the new mail */

  stampfile(genbuf, &mymail);
  printf("file: %s\n", genbuf);

  /* copy the stdin to the specified file */

  if ((fout = fopen(genbuf, "w")) == NULL)
  {
    printf("Cannot open %s\n", genbuf);
    return -1;
  }

  /* parse header */

  while (fgets(genbuf, 255, stdin))
  {
    if (!strncmp(genbuf, "From", 4))
    {
      if ((ip = strchr(genbuf, '<')) && (ptr = strrchr(ip, '>')))
      {
	*ptr = '\0';
	if (ip[-1] == ' ')
	  ip[-1] = '\0';
	ptr = (char *) strchr(genbuf, ' ');
	while (*++ptr == ' ');
	sprintf(sender, "%s (%s)", ip + 1, ptr);
      }
      else
      {
	strtok(genbuf, " \t\n\r");
	strcpy(sender, (char *) strtok(NULL, " \t\n\r"));
      }
      continue;
    }
    if (!strncmp(genbuf, "Subject: ", 9))
    {
      strcpy(title, genbuf + 9);
      continue;
    }
    if (genbuf[0] == '\n')
      break;
  }

  if (ptr = strchr(sender, '\n'))
    *ptr = '\0';

  if (ptr = strchr(title, '\n'))
    *ptr = '\0';

  if (strchr(sender, '@') == NULL)	/* �� local host �H�H */
  {
    strcat(sender, "@" MYHOSTNAME);
  }

  time(&tmp_time);

  if (!title[0])
    sprintf(title, "�Ӧ� %.64s", sender);

  fprintf(fout, "�@��: %s\n���D: %s\n�ɶ�: %s\n",
    sender, title, ctime(&tmp_time));

  while (fgets(genbuf, 255, stdin))
    fputs(genbuf, fout);

  fclose(fout);

  sprintf(genbuf, "%s => %s", sender, userid);
  mailog(genbuf);

  /* append the record to the MAIL control file */

  strncpy(mymail.title, title, 72);

  if (strtok(sender, " .@\t\n\r"))
    strcat(sender, ".");
  sender[IDLEN + 1] = '\0';
  strcpy(mymail.owner, sender);

  sprintf(genbuf, BBSHOME "/home/%s/.DIR", userid);
  return append_record(genbuf, &mymail, sizeof(mymail));
}


void
main(argc, argv)
  int argc;
  char *argv[];
{
  char receiver[256];

  /* argv[1] is userid in bbs   */

  if (argc < 2)
  {
    printf("Usage:\t%s <bbs_uid>\n", argv[0]);
    exit(-1);
  }

  strcpy(receiver, argv[1]);

  if (mail2bbs(receiver))
  {
    /* eat mail queue */
    while (fgets(receiver, sizeof(receiver), stdin));
  }

  exit(0);
}
