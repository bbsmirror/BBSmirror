/*-------------------------------------------------------*/
/* tran/chkdir.c	( NTHU CS MapleBBS Ver 2.36 )	 */
/*-------------------------------------------------------*/
/* target : Maple/Phoenix/Secret_Lover .DIR �ഫ�B���@	 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#include <sys/file.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <string.h>
#include "config.h"
#include "struct.h"


struct oldfh
{
  char filename[80];		/* the DIR files */
  char owner[80];
  char title[80];
  unsigned level;
  unsigned char accessed[12];	/* struct size = 256 bytes */
};


/*
 * usage:	chkdir path [t]
 * 
 * compile:	gcc -o chkdir chkdir.c
 */

main(argc, argv)
  int argc;
  char *argv[];
{
  static char gauge[4] = "-\\|/";
  static char *str_op[2] = {"check", "trans"};
  char buf[24] = "M.";

  char t_dir[30];

  DIR *dirp;
  struct dirent *dp;

  int fin, fout;
  struct stat st;

  char table[5000][20];
  int i, total;
  int insize, outsize;
  char *iptr, *key, *hit;
  struct oldfh fh0;
  struct fileheader fh1;

  time_t filetime;
  struct tm *ptime;

  if (argc < 2 || argc > 3)
  {
    printf("Usage:\t%s path [t]\n", argv[0]);
    exit(-1);
  }
  argc -= 2;


  getcwd(t_dir, 29);
  chdir(argv[1]);

  /* build filename table & sort */

  dirp = opendir(".");
  for (dp = readdir(dirp), i = 0; dp ; dp = readdir(dirp))
    if (!strncmp(dp->d_name, "M.", 2))
    {
      strcpy(table[i], dp->d_name + 2);
      i++;
    }
  closedir(dirp);
  total = i;

  qsort(table, total, 20, strcmp);

  /* judge transform or not */

  outsize = sizeof(struct fileheader);

  if (argc)
  {
    insize = sizeof(struct oldfh);
    iptr = (char *) &fh0;
    key = &(fh0.filename[2]);
  }
  else
  {
    insize = outsize;
    iptr = (char *) &fh1;
    key = &(fh1.filename[2]);
  }

  if ((fin = open(".DIR", O_RDONLY)) == -1)
  {
    printf(".DIR open error\n");
    exit(-1);
  }

  if ((fout = open(".dir", O_WRONLY | O_CREAT | O_TRUNC, 0644)) == -1)
  {
    printf(".dir open error\n");
    exit(-1);
  }

  fstat(fin, &st);
  printf("Total: %d files, %d records\n\n%s: ",
    total, st.st_size / insize, str_op[argc]);

  /* read original .DIR */

  i = 0;

  while (read(fin, iptr, insize) == insize)
  {
    /* binary search : check consistency */

    if (hit = (char *)bsearch(key, table, total, 20, strcmp))
    {
      hit[19] = 'z';

      if (argc)
      {
	strcpy(fh1.filename, fh0.filename);
	fh1.savemode = fh0.filename[STRLEN - 1];
	strncpy(fh1.owner, fh0.owner, IDLEN+1);
        if (strtok(fh1.owner, " .@\t\n\r"))
          strcat(fh1.owner, ".");

	filetime = atoi(fh0.filename + 2);
	if (filetime > 740000000)
	{
	  ptime = localtime(&filetime);
	  sprintf(fh1.date, "%2d/%02d", ptime->tm_mon + 1, ptime->tm_mday);
	}
	else
	{
	  strcpy(fh1.date, "     ");
	}
	strcpy(fh1.title, fh0.title);
	fh1.filemode = (uschar) fh0.accessed[0] & 1;
	fh1.filemode |= ((uschar) fh0.accessed[0] >> 2) & 2;
	if (fh0.filename[STRLEN - 2] == 'L')
	  fh1.filemode |= 1;
      }

      write(fout, &fh1, outsize);

      printf("%c\b", gauge[(++i) & 3]);
    }
  }
  close(fin);
  close(fout);

  printf("%d records\nprune: ", i);

  /* prune dummy file */

  for (i = outsize = 0; outsize < total; outsize++)
  {
    if (table[outsize][19] != 'z')
    {
      strcpy(buf + 2, table[outsize]);
      unlink(buf);
      printf("%c\b", gauge[(++i) & 3]);
    }
  }
  printf("%d files\n\nCompleted.\n", i);

  rename(".DIR", ".DIR-");
  rename(".dir", ".DIR");

  chdir(t_dir);
}
