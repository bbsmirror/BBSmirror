/*-------------------------------------------------------*/
/* tran/tranboard.c	( NTHU CS MapleBBS Ver 2.36 )	 */
/*-------------------------------------------------------*/
/* target : .BOARDS �榡�ഫ (for Phoenix/Secret_Lover)	 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/
/* Usage: tranboard .BOARDS				 */
/*-------------------------------------------------------*/


#include "bbs.h"

#define	ORIG_MAXU	12	/* ��Ӥ� MAXUSERS */
#define	LINUX_TO_SUN

#define	BM_LEN		60
#define	STRLEN		80


struct oldbh
{
  char filename[STRLEN];
  char owner[STRLEN - BM_LEN];
  char BM[BM_LEN];
  char title[STRLEN];
  unsigned level;
  unsigned char accessed[ORIG_MAXU];
};
typedef struct oldbh oldbh;


boardheader allbrd[MAXBOARD];


unsigned int
indian(char *s)
{
  char t[4];
  unsigned int *i;

#ifdef	LINUX_TO_SUN
  t[0] = s[3];
  t[1] = s[2];
  t[2] = s[1];
  t[3] = s[0];
#else
  t[0] = s[0];
  t[1] = s[1];
  t[2] = s[2];
  t[3] = s[3];
#endif

  i = (unsigned int *) t;
  return (*i);
}


int
board_cmp(a, b)
  boardheader *a, *b;
{
  return (strcasecmp(a->brdname, b->brdname));
}


main(argc, argv)
  int argc;
  char *argv[];
{
  FILE *fd;
  int inf, outf, i, count;
  char buf[256];
  oldbh mybh;

  if (argc < 2)
  {
    printf("Usage:\t%s .BOARDS\n", argv[0]);
    exit(1);
  }


  inf = open(argv[1], O_RDONLY);
  sprintf(buf, "%s.new", argv[1]);
  outf = open(buf, O_WRONLY | O_CREAT | O_TRUNC, 0644);
  if (inf == -1 || outf == -1)
  {
    printf("error open file\n");
    exit(1);
  }

  /* read in all boards */

  i = 0;
  memset(allbrd, 0, MAXBOARD * sizeof(boardheader));
  while (read(inf, &mybh, sizeof(oldbh)) == sizeof(oldbh))
  {
    if (mybh.filename[0])
    {
      strncpy(allbrd[i].brdname, mybh.filename, IDLEN);
      strncpy(allbrd[i].BM, mybh.BM, IDLEN + 1);
      strncpy(allbrd[i].title, mybh.title, BTLEN);
      allbrd[i].level = indian((char *)&mybh.level);

      sprintf(buf, "boards/%s/control", mybh.filename);
      if (fd = fopen(buf, "r"))
      {
	fgets(buf, 80, fd);
	fclose(fd);
	allbrd[i].vtime = (time_t) atol(buf);
	allbrd[i].bvote = 1;
      }
      i++;
    }
  }
  close(inf);

  /* sort them by name */

  count = i;
  qsort(allbrd, count, sizeof(boardheader), board_cmp);

  /* write out the target file */

  printf(
    "�ݪO�W��     �O�D                     ���O   ����ԭz\n"
    "----------------------------------------------------------------------\n");
  for (i = 0; i < count; i++)
  {
    write(outf, &allbrd[i], sizeof(boardheader));
    printf("%-13s%-25.25s%s\n", allbrd[i].brdname, allbrd[i].BM, allbrd[i].title);
  }

  close(outf);
  exit(0);
}
