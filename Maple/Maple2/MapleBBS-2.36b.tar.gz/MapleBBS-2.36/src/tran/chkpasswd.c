/*-------------------------------------------------------*/
/* tran/chkpasswd.c	( NTHU CS MapleBBS Ver 2.36 )	 */
/*-------------------------------------------------------*/
/* target : Phoenix/Secret_Lover .PASSWDS ����ഫ�B���@ */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/

#define	LINUX_TO_SUN
#define MAXUSER 9996

#include <sys/file.h>
#include <sys/stat.h>
#include <string.h>
#include "config.h"
#include "perm.h"
#include "struct.h"
#include <dirent.h>


struct olduserec
{
  char userid[IDLEN + 2];
  char fill[30];
  time_t firstlogin;
  char lasthost[16];
  unsigned int numlogins;
  unsigned int numposts;
  char flags[2];
  char passwd[PASSLEN];
  char username[NAMELEN];
  char ident[NAMELEN];
  char termtype[STRLEN];
  unsigned userlevel;
  time_t lastlogin;
  time_t unused_time;
  char realname[NAMELEN];
  char address[STRLEN];
  char email[STRLEN];
};
typedef struct olduserec olduserec;

/*
 * usage:	chkpasswd [t]
 * 
 * compile:	gcc -o chkpasswd chkpasswd.c
 */


unsigned int
indian(char *s)
{
  char t[4];
  unsigned int *i;

#ifdef	LINUX_TO_SUN
  t[0] = s[3];
  t[1] = s[2];
  t[2] = s[1];
  t[3] = s[0];
#else
  t[0] = s[0];
  t[1] = s[1];
  t[2] = s[2];
  t[3] = s[3];
#endif

  i = (unsigned int *) t;
  return (*i);
}

main(argc, argv)
  int argc;
  char *argv[];
{
  static char gauge[4] = "-\\|/";
  static char *str_op[2] = {"check", "trans"};
  static char cmd[40] = "/bin/rm -fr ";

  DIR *dirp;
  struct dirent *dp;

  int fin, fout;
  struct stat st;

  int i, total;
  int insize, outsize;
  char *iptr, *key, *hit;

  olduserec fh0;
  userec fh1;

  if (argc < 1 || argc > 2)
  {
    printf("Usage:\t%s [t]\n", argv[0]);
    exit(-1);
  }
  argc--;

  if ((fin = open(".PASSWDS", O_RDONLY)) == -1)
  {
    printf("OLD open error\n");
    exit(-1);
  }

  if ((fout = open(".PASSWDS.new", O_WRONLY | O_CREAT | O_TRUNC, 0644)) == -1)
  {
    printf("NEW open error\n");
    exit(-1);
  }

  /* judge transform or not */

  outsize = sizeof(userec);

  if (argc)
  {
    insize = sizeof(olduserec);
    iptr = (char *) &fh0;
  }
  else
  {
    insize = outsize;
    iptr = (char *) &fh1;
  }

  fstat(fin, &st);
  printf("Total: %d records\n\n%s: ",
    st.st_size / insize, str_op[argc]);

  /* read original .PASSWDS */

  i = 0;

  while (read(fin, iptr, insize) == insize)
  {
    /* binary search : check consistency */

    if (iptr[0] && isalpha(iptr[0]) && strcmp(iptr, "new"))
    {

      if (argc)
      {
	memset(&fh1, 0, sizeof(userec));

	strncpy(fh1.userid, fh0.userid, IDLEN + 1);
	strncpy(fh1.realname, fh0.realname, 19);
	strncpy(fh1.username, fh0.username, 23);
	strncpy(fh1.passwd, fh0.passwd, PASSLEN);
	strncpy(fh1.termtype, "vt100  ", 7);
	strncpy(fh1.termtype, fh0.termtype, 7);
	strncpy(fh1.lasthost, fh0.lasthost, 15);
	strncpy(fh1.email, fh0.email, 49);
	strncpy(fh1.justify, fh0.termtype + 16, 43);
	strncpy(fh1.address, fh0.address, 49);
	fh1.firstlogin = indian((char *) &fh0.firstlogin);
	fh1.lastlogin = indian((char *) &fh0.lastlogin);
	fh1.numlogins = (ushort) indian((char *) &fh0.numlogins);
	fh1.numposts = (ushort) indian((char *) &fh0.numposts);

#ifdef	DEBUG
	printf("\n%s : %d [%d]\n",
	  fh0.userid, fh0.numposts, indian((char *) &fh0.numposts));
#endif

	fh1.uflag = ((fh0.flags[0] & 0x3) << 2) |
	  (fh0.flags[0] & (0x80 | 0x20)) | (fh0.flags[1] & 0x3);

	fh1.userlevel = indian((char *) &fh0.userlevel);
	if (fh1.userlevel & 0x10000)	/* PERM_BM */
	  fh1.userlevel |= 0x0400;
	fh1.userlevel &= 0xffef;/* PERM_LOGINOK */
	if (fh1.justify[0])
	  fh1.userlevel |= PERM_LOGINOK;	/* PERM_LOGINOK */
      }

      write(fout, &fh1, outsize);

      printf("%c\b", gauge[(++i) & 3]);
    }
  }
  close(fin);
  close(fout);
}
