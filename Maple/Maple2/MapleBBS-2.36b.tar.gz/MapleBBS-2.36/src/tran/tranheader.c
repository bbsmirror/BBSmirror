/*-------------------------------------------------------*/
/* tran/tranheader.c	( NTHU CS MapleBBS Ver 2.36 )	 */
/*-------------------------------------------------------*/
/* target : �ഫ board post/mail header �榡		 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/

#include <stdio.h>
#include <dirent.h>

main(argc, argv)
  int argc;
  char *argv[];
{
  char buf[256], t_dir[30], *fname;

  DIR *dirp;
  struct dirent *dp;
  FILE *fin, *foo;
  char *ptr, *tail;

  if (argc != 2)
  {
    printf("Usage:\t%s path\n", argv[0]);
    exit(-1);
  }

  getcwd(t_dir, 29);
  chdir(argv[1]);

  dirp = opendir(".");
  for (dp = readdir(dirp); dp; dp = readdir(dirp))
    if (!strncmp(fname = dp->d_name, "M.", 2) || !strncmp(fname, "g.", 2))
    {
      if (fin = fopen(fname, "r"))
      {
	fgets(buf, 256, fin);
	if (!strncmp(buf, "Posted By: ", 11) ||
	  !strncmp(buf, "From:      ", 11))
	{
	  foo = fopen("zzz", "w");
          if(ptr = (char *)strstr(buf + 11, "�H��:"))
	    memcpy(ptr, "�ݪO", 4);
	  if(ptr = (char *)strstr(buf + 11, " on board"))
	  {
	    if(tail = (char *)strrchr(ptr + 10, '\''))
	      memcpy(tail, "\n", 2);
	    memcpy(ptr, ", ����: ", 8);
	    strcpy(ptr + 8, ptr + 11);
	  }
	
	  fprintf(foo, "�@��: %s", buf + 11);

	  fgets(buf, 256, fin);
	  if (!strncmp(buf, "Title:     ", 11))
	    fprintf(foo, "���D: %s", buf + 11);
	  else
	    fputs(buf, foo);

	  fgets(buf, 256, fin);
	  if (!strncmp(buf, "Date:      ", 11))
	    fprintf(foo, "�ɶ�: %s", buf + 11);
	  else
	    fputs(buf, foo);

	  while (fgets(buf, 256, fin))
	    fputs(buf, foo);
	  fclose(fin);
	  fclose(foo);
	  rename("zzz", fname);
	}
	else if (!strncmp(buf, "�o�H�H: ", 8))
        {
	  foo = fopen("zzz", "w");

          if(ptr = (char *)strstr(buf + 11, "�H��:"))
	    memcpy(ptr, "�ݪO", 4);
	  fputs(buf, foo);

	  while (fgets(buf, 256, fin))
	    fputs(buf, foo);
	  fclose(fin);
	  fclose(foo);
	  rename("zzz", fname);
        }
	else
	  fclose(fin);
      }
    }
  closedir(dirp);
}
