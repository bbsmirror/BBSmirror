#!/bin/sh 
#
# Last updated date: Apr.03,1995
#
TERM=vt100
export TERM
PAGER=/home/bin/cless
export PAGER
LC_CTYPE=iso_8859_1
export LC_CTYPE
LOCALDOMAIN=.
export LOCALDOMAIN
stty pass8 -istrip
exec /usr/local/bin/gopher -s 140.123.1.3 70
