/*-------------------------------------------------------*/
/* perm.h	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : permission levels of user & board		 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#ifndef	_PERM_H_
#define	_PERM_H_


/* ----------------------------------------------------- */
/* These are the 16 basic permission bits.		 */
/* ----------------------------------------------------- */

#define	PERM_BASIC	000001
#define PERM_CHAT	000002
#define	PERM_PAGE	000004
#define PERM_POST	000010
#define	PERM_LOGINOK 	000020
#define PERM_MAILLIMIT	000040
#define PERM_CLOAK	000100
#define PERM_SEECLOAK	000200
#define PERM_XEMPT 	000400
#define PERM_DENYPOST	001000
#define PERM_BM		002000
#define PERM_ACCOUNTS	004000
#define PERM_CHATROOM	010000
#define	PERM_BOARD	020000
#define PERM_SYSOP	040000
#define PERM_POSTMASK  0100000	/* means the rest is a post mask */


/* ----------------------------------------------------- */
/* These permissions are bitwise ORs of the basic bits.	 */
/* ----------------------------------------------------- */


/* This is the default permission granted to all new accounts. */
#define PERM_DEFAULT 	(PERM_BASIC | PERM_CHAT | PERM_PAGE | PERM_POST)

#define PERM_ADMIN	(PERM_ACCOUNTS | PERM_SYSOP)
#define PERM_ALLBOARD	(PERM_SYSOP | PERM_BOARD)
#define PERM_LOGINCLOAK	(PERM_SYSOP | PERM_ACCOUNTS)
#define PERM_SEEULEVELS	PERM_SYSOP
#define PERM_SEEBLEVELS	(PERM_SYSOP | PERM_BM)
#define PERM_NOTIMEOUT	PERM_SYSOP

#define PERM_READMAIL	PERM_BASIC
#define PERM_FORWARD	PERM_BASIC	/* to do the forwarding */


#define HAS_PERM(x)	((x)?cuser.userlevel&(x):1)
#define HAVE_PERM(x)	(cuser.userlevel&(x))


/* ----------------------------------------------------- */
/* �U���v��������N�q					 */
/* ----------------------------------------------------- */


#ifndef _ADMIN_C_
extern char *permstrings[];

#else

#define	NUMPERMS	15

char *permstrings[] = {
  "���v�O",			/* PERM_BASIC */
  "�i�J��ѫ�",			/* PERM_CHAT */
  "��H���",			/* PERM_PAGE */
  "�o���峹",			/* PERM_POST */
  "���U�{�ǻ{��",		/* PERM_LOGINOK */
  "�H��L�W��",			/* PERM_MAILLIMIT */
  "�����N",			/* PERM_CLOAK */
  "�ݨ��Ԫ�",			/* PERM_SEECLOAK */
  "�ä[�O�d�b��",		/* PERM_XEMPT */
  "�T��o���峹",		/* PERM_DENYPOST */
  "�O�D",			/* PERM_BM */
  "�b���`��",			/* PERM_ACCOUNTS */
  "��ѫ��`��",			/* PERM_CHATCLOAK */
  "�ݪO�`��",			/* PERM_BOARD */
  "����"			/* PERM_SYSOP */
  /* "Read/Post ����"	/* PERM_POSTMASK */
};

#endif

#endif				/* _PERM_H_ */
