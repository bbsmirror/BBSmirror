/*-------------------------------------------------------*/
/* read.c	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : board/mail interactive reading routines 	 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#include "bbs.h"


struct keeploc
{
  char *key;
  int top_ln;
  int crs_ln;
  struct keeploc *next;
};
typedef struct keeploc keeploc;


char currdirect[64];
static fileheader *headers = NULL;
static int last_line;
static int hit_thread;


extern int search_num();


/* ----------------------------------------------------- */
/* cursor & reading record position control		 */
/* ----------------------------------------------------- */

keeploc *
getkeep(s, def_topline, def_cursline)
  char *s;
{
  static struct keeploc *keeplist = NULL;
  struct keeploc *p;
  void *malloc();

  for (p = keeplist; p; p = p->next)
  {
    if (!strcmp(s, p->key))
    {
      if (p->crs_ln < 1)
	p->crs_ln = 1;
      return p;
    }
  }
  p = (keeploc *) malloc(sizeof(keeploc));
  p->key = (char *) malloc(strlen(s) + 1);
  strcpy(p->key, s);
  p->top_ln = def_topline;
  p->crs_ln = def_cursline;
  p->next = keeplist;
  return (keeplist = p);
}


void
fixkeep(s, first)
  char *s;
  int first;
{
  keeploc *k;

  k = getkeep(s, 1, 1);
  if (k->crs_ln >= first)
  {
    k->crs_ln = (first == 1 ? 1 : first - 1);
    k->top_ln = (first < 11 ? 1 : first - 10);
  }
}


/* calc cursor pos and show cursor correctly */

static int
cursor_pos(locmem, val, from_top)
  struct keeploc *locmem;
  int val;
  int from_top;
{
  int top;

  if (val > last_line)
  {
    bell();
    val = last_line;
  }
  if (val <= 0)
  {
    bell();
    val = 1;
  }

  top = locmem->top_ln;
  if (val >= top && val < top + p_lines)
  {
    cursor_clear(3 + locmem->crs_ln - top, 0);
    locmem->crs_ln = val;
    cursor_show(3 + val - top, 0);
    return DONOTHING;
  }
  locmem->top_ln = val - from_top;
  if (locmem->top_ln <= 0)
    locmem->top_ln = 1;
  locmem->crs_ln = val;
  return PARTUPDATE;
}


static int
move_cursor_line(locmem, mode)
  keeploc *locmem;
  int mode;
{
  int top, crs;
  int reload = 0;

  top = locmem->top_ln;
  crs = locmem->crs_ln;
  if (mode == READ_PREV)
  {
    if (crs <= top)
    {
      top -= p_lines - 1;
      if (top < 1)
	top = 1;
      reload = 1;
    }
    if (--crs < 1)
    {
      crs = 1;
      reload = -1;
    }
  }
  else if (mode == READ_NEXT)
  {
    if (crs >= top + p_lines - 1)
    {
      top += p_lines - 1;
      reload = 1;
    }
    if (++crs > last_line)
    {
      crs = last_line;
      reload = -1;
    }
  }
  locmem->top_ln = top;
  locmem->crs_ln = crs;
  return reload;
}


static int
thread(locmem, stype)
  keeploc *locmem;
  int stype;
{
  static char a_ans[32], t_ans[32];
  char ans[32], s_pmt[64];
  register char *tag, *query;
  register int now, pos, match, near;
  fileheader fh;

  match = hit_thread = 0;
  now = pos = locmem->crs_ln;

  if (stype & RS_RELATED)
  {
    tag = headers[pos - locmem->top_ln].title;
    if (stype & RS_CURRENT)
    {
      if (stype & RS_FIRST)
      {
	if (!strncmp(currtitle, tag, 40))
	  return DONOTHING;
	near = 0;
      }
      query = currtitle;
    }
    else
    {
      query = subject(tag);
      if (stype & RS_FIRST)
      {
	if (query == tag)
	  return DONOTHING;
	near = 0;
      }
    }
  }
  else if (!(stype & RS_THREAD))
  {
    query = (stype & RS_TITLE) ? t_ans : a_ans;
    sprintf(s_pmt, "�j�M%s [%s] ", (stype & RS_TITLE) ? "���D" : "�@��", query);
    getdata(b_lines, 0, s_pmt, ans, 30, DOECHO);
    if (*ans)
    {
      strcpy(query, ans);
    }
    else
    {
      if (*query == '\0')
	return DONOTHING;
    }
    str_lower(s_pmt, query);
    query = s_pmt;
  }

  tag = fh.owner;

  do
  {
    if (stype & RS_RELATED)
    {
      if (stype & RS_FORWARD)
      {
	if (++now > last_line)
	  return DONOTHING;
      }
      else
      {
	if (--now <= 0)
	{
	  if ((stype & RS_FIRST) && (near))
	  {
	    hit_thread = 1;
	    return cursor_pos(locmem, near, 10);
	  }
	  return DONOTHING;
	}
      }
    }
    else
    {
      if (stype & RS_FORWARD)
      {
	if (++now > last_line)
	  now = 1;
      }
      else
      {
	if (--now <= 0)
	  now = last_line;
      }
    }

    get_record(currdirect, &fh, sizeof(fileheader), now);

    if (fh.owner[0] == '-')
      continue;

    if (stype & RS_THREAD)
    {
      if (strncasecmp(fh.title, str_reply, 3))
      {
	hit_thread = 1;
	return cursor_pos(locmem, now, 10);
      }
      continue;
    }

    if (stype & RS_TITLE)
      tag = subject(fh.title);

    if (((stype & RS_RELATED) && !strncmp(tag, query, 40)) ||
      (!(stype & RS_RELATED) && strstr_lower(tag, query)))
    {
      if (stype & RS_FIRST)
      {
	if (tag != fh.title)
	{
	  near = now;
	  continue;
	}
      }
      hit_thread = 1;
      match = cursor_pos(locmem, now, 10);
      if ((!(stype & RS_CURRENT)) && (stype & RS_RELATED) &&
	strncmp(currtitle, query, 40))
      {
	strncpy(currtitle, query, 40);
	match = PARTUPDATE;
      }
      break;
    }
  }
  while (now != pos);

  return match;
}


/* ------------------ */
/* �ɮ׶ǿ�u��Ƶ{�� */
/* ------------------ */


void
z_download(fpath)
  char *fpath;
{
  getdata(b_lines, 0, "�аݭn�ϥ� Z-Modem �ǰe�ɮ׶�(Y/N)�H[N] ",
    genbuf, 4, LCECHO);
  if (genbuf[0] == 'y')
  {
    sprintf(genbuf, "bin/sz -a tmp/%.8s.bbs", cuser.userid);
    unlink(&genbuf[10]);
    link(fpath, &genbuf[10]);
    system(genbuf);
    unlink(&genbuf[10]);
  }
}


#ifdef INTERNET_EMAIL
void
mail_forward(fhdr, direct, mode)
  fileheader *fhdr;
  char *direct;
  int mode;
{
  char buf[STRLEN];
  char *p;

  strncpy(buf, direct, sizeof(buf));
  if (p = strrchr(buf, '/'))
    *p = '\0';
  switch (doforward(buf, fhdr, mode))
  {
  case 0:
    outs(msg_fwd_ok);
    break;
  case -1:
    outs(msg_fwd_err1);
    break;
  case -2:
    outs(msg_fwd_err2);
  }
  pressanykey();
}
#endif


static int
i_read_key(rcmdlist, locmem, ch)
  struct one_key *rcmdlist;
  struct keeploc *locmem;
  int ch;
{
  int i, mode = DONOTHING;

  switch (ch)
  {
  case 'q':
  case 'e':
  case KEY_LEFT:
    return (currmode & MODE_DIGEST) ? board_digest() : DOQUIT;

  case Ctrl('L'):
    redoscr();
    break;

  case 'a':
    if (thread(locmem, RS_FORWARD))
      return PARTUPDATE;
    return READ_REDRAW;

  case 'A':
    if (thread(locmem, 0))
      return PARTUPDATE;
    return READ_REDRAW;

  case '/':
    if (thread(locmem, RS_TITLE | RS_FORWARD))
      return PARTUPDATE;
    return READ_REDRAW;

  case '?':
    if (thread(locmem, RS_TITLE))
      return PARTUPDATE;
    return READ_REDRAW;

    /* quick search title first */
  case '=':
    return thread(locmem, RELATE_FIRST);

  case '\\':
    return thread(locmem, CURSOR_FIRST);

    /* quick search title forword */
  case ']':
    return thread(locmem, RELATE_NEXT);

  case '+':
    return thread(locmem, CURSOR_NEXT);

    /* quick search title backword */
  case '[':
    return thread(locmem, RELATE_PREV);

  case '-':
    return thread(locmem, CURSOR_PREV);

  case '<':
  case ',':
    return thread(locmem, THREAD_PREV);

  case '.':
  case '>':
    return thread(locmem, THREAD_NEXT);

  case 'p':
  case 'k':
  case KEY_UP:
    return cursor_pos(locmem, locmem->crs_ln - 1, p_lines - 2);

  case 'n':
  case 'j':
  case KEY_DOWN:
    return cursor_pos(locmem, locmem->crs_ln + 1, 1);

  case ' ':
  case KEY_PGDN:
  case 'N':
  case Ctrl('F'):
    if (last_line >= locmem->top_ln + p_lines)
    {
      if (last_line > locmem->top_ln + p_lines)
        locmem->top_ln += p_lines;
      else
        locmem->top_ln += p_lines - 1;
      locmem->crs_ln = locmem->top_ln;
      return PARTUPDATE;
    }
    cursor_clear(3 + locmem->crs_ln - locmem->top_ln, 0);
    locmem->crs_ln = last_line;
    cursor_show(3 + locmem->crs_ln - locmem->top_ln, 0);
    break;

  case KEY_PGUP:
  case Ctrl('B'):
  case 'P':
    if (locmem->top_ln > 1)
    {
      locmem->top_ln -= p_lines;
      if (locmem->top_ln <= 0)
	locmem->top_ln = 1;
      locmem->crs_ln = locmem->top_ln;
      return PARTUPDATE;
    }
    break;

  case KEY_END:
  case '$':
    if (last_line >= locmem->top_ln + p_lines)
    {
      locmem->top_ln = last_line - p_lines + 1;
      if (locmem->top_ln <= 0)
	locmem->top_ln = 1;
      locmem->crs_ln = last_line;
      return PARTUPDATE;
    }
    cursor_clear(3 + locmem->crs_ln - locmem->top_ln, 0);
    locmem->crs_ln = last_line;
    cursor_show(3 + locmem->crs_ln - locmem->top_ln, 0);
    break;

  case 'F':
  case 'U':
    if (HAS_PERM(PERM_FORWARD))
    {
      mail_forward(&headers[locmem->crs_ln - locmem->top_ln],
	currdirect, ch == 'U');
      return FULLUPDATE;
    }
    break;

  case 'Z':
    if (HAS_PERM(PERM_FORWARD))
    {
      char fname[80];

      setdirpath(fname, currdirect, &headers[locmem->crs_ln - locmem->top_ln]);
      z_download(fname);
      return PART_REDRAW;
    }
    break;

  case '\n':
  case '\r':
  case 'l':
  case KEY_RIGHT:
    ch = 'r';

  default:
    for (i = 0; rcmdlist[i].fptr; i++)
    {
      if (rcmdlist[i].key == ch)
      {
	mode = (*(rcmdlist[i].fptr)) (locmem->crs_ln,
	  &headers[locmem->crs_ln - locmem->top_ln], currdirect);
	break;
      }
      if (rcmdlist[i].key == 'h')
      {
	if (currmode & MODE_DIGEST)
	  return DONOTHING;
      }
    }
  }
  return mode;
}


void
i_read(cmdmode, direct, dotitle, doentry, rcmdlist)
  char *direct;
  void (*dotitle) ();
void *(*doentry) ();
struct one_key *rcmdlist;
{
  keeploc *locmem;
  char lbuf[11];
  int recbase, mode, ch;
  int num, entries;
  int i;

#define	FHSZ	sizeof(fileheader)

  if (!headers)
    headers = (fileheader *) calloc(p_lines, FHSZ);
  strcpy(currdirect, direct);
  mode = NEWDIRECT;

  do
  {
    /* -------------------------------------------------------- */
    /* �̾� mode ��� fileheader				 */
    /* -------------------------------------------------------- */

    setutmpmode(cmdmode);

    switch (mode)
    {
    case NEWDIRECT:		/* �Ĥ@�����J���ؿ� */
    case DIRCHANGED:

      last_line = get_num_records(currdirect, FHSZ);

      if (mode == NEWDIRECT)
      {
	if (last_line == 0)
	{
	  if (curredit & EDIT_MAIL)
	  {
	    outs("�S���ӫH");
	    igetch();
	  }
	  else
	  {
	    getdata(b_lines, 0, "�ݪO�s���� (P)�o���峹 (Q)���}�H[Q] ",
	      genbuf, 4, LCECHO);
	    if (genbuf[0] == 'p')
	      do_post();
	  }
	  return;
	}
	num = last_line - p_lines + 1;
	locmem = getkeep(currdirect, num < 1 ? 1 : num, last_line);
      }
      recbase = -1;

    case FULLUPDATE:
      (*dotitle) ();

    case PARTUPDATE:
      if (last_line < locmem->top_ln + p_lines)
      {
	num = get_num_records(currdirect, FHSZ);
	if (last_line != num)
	{
	  last_line = num;
	  recbase = -1;
	}
      }

      if (last_line == 0)
      {
	return;
      }
      else if (recbase != locmem->top_ln)
      {
	recbase = locmem->top_ln;
	if (recbase > last_line)
	{
	  recbase = last_line - p_lines >> 1;
	  if (recbase < 1)
	    recbase = 1;
	  locmem->top_ln = recbase;
	}
	entries = get_records(currdirect, headers, FHSZ, recbase, p_lines);
      }
      if (locmem->crs_ln > last_line)
	locmem->crs_ln = last_line;

      move(3, 0);
      clrtobot();

    case PART_REDRAW:

      move(3, 0);
      for (i = 0; i < entries; i++)
	(*doentry) (locmem->top_ln + i, &headers[i]);

    case READ_REDRAW:
      outmsg(curredit & EDIT_MAIL ? msg_mailer : MSG_POSTER);
    }

    /* -------------------------------------------------------- */
    /* Ū����L�A�[�H�B�z�A�]�w mode 				 */
    /* -------------------------------------------------------- */

    cursor_show(3 + locmem->crs_ln - locmem->top_ln, 0);
    ch = egetch();
    mode = DONOTHING;

    if (talkrequest)
    {
      talkreply();
      mode = FULLUPDATE;
    }
    else if (ch >= '0' && ch <= '9')
    {
      if ((i = search_num(ch, last_line)) != -1)
	mode = cursor_pos(locmem, i + 1, 10);
    }
    else
    {
      mode = i_read_key(rcmdlist, locmem, ch);

      while (mode == READ_NEXT || mode == READ_PREV ||
	mode == RELATE_FIRST || mode == RELATE_NEXT || mode == RELATE_PREV ||
	mode == THREAD_NEXT || mode == THREAD_PREV)
      {
	int reload;

	if (mode == READ_NEXT || mode == READ_PREV)
	{
	  reload = move_cursor_line(locmem, mode);
	}
	else
	{
	  reload = thread(locmem, mode);
	  if (!hit_thread)
	  {
	    mode = FULLUPDATE;
	    break;
	  }
	}

	if (reload == -1)
	{
	  mode = FULLUPDATE;
	  break;
	}
	else if (reload)
	{
	  recbase = locmem->top_ln;
	  entries = get_records(currdirect, headers, FHSZ, recbase, p_lines);
	  if (entries <= 0)
	  {
	    last_line = -1;
	    break;
	  }
	}
	num = locmem->crs_ln - locmem->top_ln;
	if (headers[num].owner[0] != '-')
	  mode = i_read_key(rcmdlist, locmem, ch);
      }
    }
  } while (mode != DOQUIT);

#undef	FHSZ
}
