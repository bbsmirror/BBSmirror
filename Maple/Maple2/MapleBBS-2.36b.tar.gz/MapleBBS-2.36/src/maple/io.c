/*-------------------------------------------------------*/
/* io.c		( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : basic console/screen/keyboard I/O routines 	 */
/* create : 95/02/28				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/

#include "bbs.h"

#ifdef AIX
#include <sys/select.h>
#endif

#ifdef	Linux
#define OBUFSIZE  (2048)
#define IBUFSIZE  (128)
#else
#define OBUFSIZE  (4096)
#define IBUFSIZE  (256)
#endif

#define INPUT_ACTIVE	0
#define INPUT_IDLE	1

static char outbuf[OBUFSIZE];
static int obufsize = 0;

static char inbuf[IBUFSIZE];
static int ibufsize = 0;
static int icurrchar = 0;

static int i_mode = INPUT_ACTIVE;

extern int dumb_term;


/* ----------------------------------------------------- */
/* �w����ܰʺA�ݪO					 */
/* ----------------------------------------------------- */


#ifdef	HAVE_MOVIE
extern void movie();

static void
hit_alarm_clock()
{
  static int idle_time = 0;

  if (currutmp->pid != currpid)
  {
    setup_utmp(XMODE);		/* ���s�t�m shm */
  }

  if ((i_mode == INPUT_IDLE) && (!HAS_PERM(PERM_NOTIMEOUT)))
  {
    idle_time += MOVIE_INT;
    if (idle_time > IDLE_TIMEOUT)
    {
      clear();
      fprintf(stderr, "�W�L���m�ɶ��IBooting...\n");
      abort_bbs();
    }
  }
  else
  {
    idle_time = 0;
    i_mode = INPUT_IDLE;
  }

  if (currstat && currstat < CLASS)
    movie(0);
  alarm(MOVIE_INT);
}


void
init_alarm()
{
  alarm(0);
  signal(SIGALRM, hit_alarm_clock);
  alarm(MOVIE_INT);
}

#else				/* HAVE_MOVIE */

static void
hit_alarm_clock()
{
  if (HAS_PERM(PERM_NOTIMEOUT))
    return;
  if (i_mode == INPUT_IDLE)
  {
    clear();
    fprintf(stderr, "�W�L���m�ɶ��IBooting...\n");
    kill(currpid, SIGHUP);
  }
  i_mode = INPUT_IDLE;
  alarm(IDLE_TIMEOUT);
}


void
init_alarm()
{
  signal(SIGALRM, hit_alarm_clock);
  alarm(IDLE_TIMEOUT);
}
#endif				/* HAVE_MOVIE */


/* ----------------------------------------------------- */
/* output routines					 */
/* ----------------------------------------------------- */


void
oflush()
{
  if (obufsize)
  {
    write(1, outbuf, obufsize);
    obufsize = 0;
  }
}


void
output(s, len)
  char *s;
{
  /* Invalid if len >= OBUFSIZE */

  if (obufsize + len > OBUFSIZE)
  {
    write(1, outbuf, obufsize);
    obufsize = 0;
  }
  memcpy(outbuf + obufsize, s, len);
  obufsize += len;
}


void
ochar(c)
{
  if (obufsize > OBUFSIZE - 1)
  {
    write(1, outbuf, obufsize);
    obufsize = 0;
  }
  outbuf[obufsize++] = c;
}


/* ----------------------------------------------------- */
/* input routines					 */
/* ----------------------------------------------------- */


static int i_newfd = 0;
static struct timeval i_to, *i_top = NULL;
static int (*flushf) () = NULL;


void
add_io(fd, timeout)
  int fd;
  int timeout;
{
  i_newfd = fd;
  if (timeout)
  {
    i_to.tv_sec = timeout;
    i_to.tv_usec = 0;
    i_top = &i_to;
  }
  else
    i_top = NULL;
}


void
add_flush(flushfunc)
  int (*flushfunc) ();
{
  flushf = flushfunc;
}


int
num_in_buf()
{
  return icurrchar - ibufsize;
}


int
igetch()
{
  int ch;

  for (;;)
  {
    if (ibufsize == icurrchar)
    {
      fd_set readfds;
      struct timeval to;

      to.tv_sec = to.tv_usec = 0;
      FD_ZERO(&readfds);
      FD_SET(0, &readfds);
      if (i_newfd)
	FD_SET(i_newfd, &readfds);
      if ((ch = select(FD_SETSIZE, &readfds, NULL, NULL, &to)) <= 0)
      {
	if (flushf)
	  (*flushf) ();

	if (dumb_term)
	  oflush();
	else
	  refresh();

	FD_ZERO(&readfds);
	FD_SET(0, &readfds);
	if (i_newfd)
	  FD_SET(i_newfd, &readfds);

	while ((ch = select(FD_SETSIZE, &readfds, NULL, NULL, i_top)) < 0)
	{
	  if (errno == EINTR)
	    continue;
	  else
	  {
	    perror("select");
	    return -1;
	  }
	}
	if (ch == 0)
	  return I_TIMEOUT;
      }
      if (i_newfd && FD_ISSET(i_newfd, &readfds))
	return I_OTHERDATA;

      while ((ibufsize = read(0, inbuf, IBUFSIZE)) <= 0)
      {
	if (ibufsize == 0)
	  longjmp(byebye, -1);
	if (ibufsize < 0 && errno != EINTR)
	  longjmp(byebye, -1);
      }
      icurrchar = 0;
    }

    i_mode = INPUT_ACTIVE;
    ch = inbuf[icurrchar++];
    if (ch != Ctrl('L'))
      return (ch);

    redoscr();
  }
}


int
getdata(line, col, prompt, buf, len, echo)
  int line, col;
  char *prompt, *buf;
  int len, echo;
{
  register int ch;
  int clen;
  int x, y;
  extern unsigned char scr_cols;

  if (prompt)
  {
    move(line, col);
    clrtoeol();
    outs(prompt);
  }
  else
    clrtoeol();

  if (dumb_term)
  {
    len--;
    clen = 0;
    while ((ch = igetch()) != '\r')
    {
      if (ch == '\n')
	break;
      if (ch == '\177' || ch == Ctrl('H'))
      {
	if (!clen)
	{
	  bell();
	  continue;
	}
	clen--;
	if (echo)
	{
	  ochar(Ctrl('H'));
	  ochar(' ');
	  ochar(Ctrl('H'));
	}
	continue;
      }

#ifdef BIT8
      if (!isprint2(ch))
#else
      if (!isprint(ch))
#endif

      {
	if (echo)
	  bell();
	continue;
      }
      if (clen >= len)
      {
	if (echo)
	  bell();
	continue;
      }
      buf[clen++] = ch;
      if (echo)
	ochar(ch);
    }
    buf[clen] = '\0';
    outc('\n');
    oflush();
  }
  else
  {
    getyx(&y, &x);
    standout();
    for (clen = len--; clen; clen--)
      outc(' ');
    standend();
    move(y, x);

    while ((ch = igetch()) != '\r')
    {
      if (ch == '\n')
	break;
      if (ch == '\177' || ch == Ctrl('H'))
      {
	if (clen)
	{
	  clen--;
	  move(y, x + clen);
	  outc(' ');
	  move(y, x + clen);
	}
	continue;
      }

#ifdef BIT8
      if (!isprint2(ch))
#else
      if (!isprint(ch))
#endif

      {
	continue;
      }
      if (clen >= len || x + clen >= scr_cols)
      {
	continue;
      }
      buf[clen++] = ch;
      outc(echo ? ch : '*');
    }
    buf[clen] = '\0';
    if (echo)
      outc('\n');
    refresh();
  }
  if ((echo == LCECHO) && ((ch = buf[0]) >= 'A') && (ch <= 'Z'))
    buf[0] = ch | 32;
  return clen;
}


#ifdef	TRAP_ESC
int KEY_ESC_arg;

int
igetkey()
{
  int mode;
  int ch, last;

  mode = last = 0;
  while (1)
  {
    ch = igetch();
    if (mode == 0)
    {
      if (ch == KEY_ESC)
	mode = 1;
      else
	return ch;		/* Normal Key */
    }
    else if (mode == 1)
    {				/* Escape sequence */
      if (ch == '[' || ch == 'O')
	mode = 2;
      else if (ch == '1' || ch == '4')
	mode = 3;
      else
      {
	KEY_ESC_arg = ch;
	return KEY_ESC;
      }
    }
    else if (mode == 2)
    {				/* Cursor key */
      if (ch >= 'A' && ch <= 'D')
	return KEY_UP + (ch - 'A');
      else if (ch >= '1' && ch <= '6')
	mode = 3;
      else
	return ch;
    }
    else if (mode == 3)
    {				/* Ins Del Home End PgUp PgDn */
      if (ch == '~')
	return KEY_HOME + (last - '1');
      else
	return ch;
    }
    last = ch;
  }
}

#else				/* TRAP_ESC */

int
igetkey(void)
{
  int mode;
  int ch, last;

  mode = last = 0;
  while (1)
  {
    ch = igetch();
    if (ch == KEY_ESC)
      mode = 1;
    else if (mode == 0)		/* Normal Key */
      return ch;
    else if (mode == 1)
    {				/* Escape sequence */
      if (ch == '[' || ch == 'O')
	mode = 2;
      else if (ch == '1' || ch == '4')
	mode = 3;
      else
	return ch;
    }
    else if (mode == 2)
    {				/* Cursor key */
      if (ch >= 'A' && ch <= 'D')
	return KEY_UP + (ch - 'A');
      else if (ch >= '1' && ch <= '6')
	mode = 3;
      else
	return ch;
    }
    else if (mode == 3)
    {				/* Ins Del Home End PgUp PgDn */
      if (ch == '~')
	return KEY_HOME + (last - '1');
      else
	return ch;
    }
    last = ch;
  }
}
#endif				/* TRAP_ESC */
