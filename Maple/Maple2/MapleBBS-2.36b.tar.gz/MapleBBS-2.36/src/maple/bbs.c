/*-------------------------------------------------------*/
/* bbs.c	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : bulletin boards' routines		 	 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/

#include "bbs.h"

extern int mail_reply();
extern char currdirect[64];

time_t board_note_time;
time_t board_visit_time;

static char *brd_title;
static int continue_flag;
int local_article;

#define	UPDATE_USEREC	(currmode |= MODE_DIRTY)
/* substitute_record(fn_passwd, &cuser, sizeof(userec), usernum) */


static int
g_board_names(fhdr)
  boardheader *fhdr;
{
  AddNameList(fhdr->brdname);
  return 0;
}


void
make_blist()
{
  CreateNameList();
  apply_boards(g_board_names);
}


void
set_board()
{
  boardheader *bp;
  boardheader *getbcache();

  bp = getbcache(currboard);
  board_note_time = bp->bupdate;
  brd_title = bp->BM;
  if (brd_title[0] <= ' ')
    brd_title = "�x�D��";
  sprintf(currBM, "�O�D�G%s", brd_title);
  brd_title = (bp->bvote == 1 ? "���ݪO�i��벼��" : bp->title + 7);

  currmode = (currmode & MODE_DIRTY) | MODE_STARTED;
  if (HAS_PERM(PERM_ALLBOARD) ||
    (HAS_PERM(PERM_BM) && is_BM(currBM + 6)))
  {
    currmode |= (MODE_BOARD | MODE_POST);
  }
  else if (haspostperm(currboard))
    currmode |= MODE_POST;
}


static void
readtitle()
{
  showtitle(currBM, brd_title);
  outs("\
[��]���} [��]�\\Ū [^P]�o���峹 [b]�Ƨѿ� [d]�R�� [z]��ذ� [TAB]��K [h]elp\n\
[7m  �s��   �� ��  �@  ��       ��  ��  ��  �D                                   [0m");
}


static void
readdoent(num, ent)
  int num;
  fileheader *ent;
{
  int type;
  char *mark, *title, color;

  type = brc_unread(ent->filename) ? '+' : ' ';

  if ((currmode & MODE_BOARD) && (ent->filemode & FILE_DIGEST))
    type = (type == ' ') ? '*' : '#';
  else if (ent->filemode & FILE_MARKED)
    type = (type == ' ') ? 'm' : 'M';

  title = subject(mark = ent->title);
  if (title == mark)
  {
    color = '1';
    mark = "��";
  }
  else
  {
    color = '3';
    mark = "R:";
  }

  if (title[47])
    strcpy(title + 44, " �K");	/* ��h�l�� string �屼 */

  if (strncmp(currtitle, title, 40))
    prints("%6d %c %-7s%-13.12s%s %s\n", num, type,
      ent->date, ent->owner, mark, title);
  else
    prints("%6d %c %-7s%-13.12s[1;3%cm%s %s[0m\n", num, type,
      ent->date, ent->owner, color, mark, title);
}


int
cmpbnames(bname, brec)
  char *bname;
  boardheader *brec;
{
  return (!ci_strncmp(bname, brec->brdname, sizeof(brec->brdname)));
}


int
cmpfilename(fhdr)
  fileheader *fhdr;
{
  return (!strcmp(fhdr->filename, currfile));
}


static int
do_select(ent, fhdr, direct)
  int ent;
  fileheader *fhdr;
  char *direct;
{
  char bname[20];
  char bpath[60];
  struct stat st;

  move(0, 0);
  clrtoeol();
  make_blist();
  namecomplete(MSG_SELECT_BOARD, bname);

  setbpath(bpath, bname);
  if ((*bname == '\0') || (stat(bpath, &st) == -1))
  {
    move(2, 0);
    clrtoeol();
    outs(err_bid);
    pressanykey();
    return FULLUPDATE;
  }

  board_visit_time = 0x7fffffff;
  brc_initial(bname);
  set_board();
  setbdir(direct, currboard);

  move(1, 0);
  clrtoeol();
  return NEWDIRECT;
}


/* ----------------------------------------------------- */
/* ��} innbbsd ��X�H��B�s�u��H���B�z�{��		 */
/* ----------------------------------------------------- */


static void
outgo_post(fh, board)
  fileheader *fh;
  char *board;
{
  FILE *foo;

  if (foo = fopen("innd/out.bntp", "a"))
  {
    fprintf(foo, "%s\t%s\t%s\t%s\t%s\n", board,
      fh->filename, cuser.userid, cuser.username, save_title);
    fclose(foo);
  }
}


static void
cancelpost(fh, by_BM)
  fileheader *fh;
  int by_BM;
{
  FILE *fin, *fout;
  char *ptr, *brd;
  fileheader postfile;
  char nick[STRLEN], fn1[STRLEN], fn2[STRLEN];

  setbfile(fn1, currboard, fh->filename);
  if (fin = fopen(fn1, "r"))
  {
    brd = by_BM ? "deleted" : "junk";

    setbpath(fn2, brd);
    stampfile(fn2, &postfile);
    memcpy(postfile.owner, fh->owner, IDLEN + TTLEN + 10);
    postfile.savemode = 'D';

    if (fh->savemode == 'S')
    {
      nick[0] = '\0';
      while (fgets(genbuf, sizeof(genbuf), fin))
      {
	if (!strncmp(genbuf, str_author1, LEN_AUTHOR1) ||
	  !strncmp(genbuf, str_author2, LEN_AUTHOR2))
	{
	  if (ptr = strrchr(genbuf, ')'))
	    *ptr = '\0';
	  if (ptr = (char *) strchr(genbuf, '('))
	    strcpy(nick, ptr + 1);
	  break;
	}
      }

      if (fout = fopen("innd/cancel.bntp", "a"))
      {
	fprintf(fout, "%s\t%s\t%s\t%s\t%s\n",
	  currboard, fh->filename, cuser.userid, nick, fh->title);
	fclose(fout);
      }
    }

    fclose(fin);
    rename(fn1, fn2);
    setbdir(genbuf, brd);
    append_record(genbuf, &postfile, sizeof(postfile));
  }
}


/* ----------------------------------------------------- */
/* �o���B�^���B�s��B����峹				 */
/* ----------------------------------------------------- */


void
do_reply_title(row, title)
  int row;
  char *title;
{
  if (ci_strncmp(title, str_reply, 4))
    sprintf(save_title, "Re: %s", title);
  else
    strcpy(save_title, title);
  save_title[TTLEN - 1] = '\0';
  sprintf(genbuf, "�ĥέ���D�m%.60s�n��?[Y] ", save_title);
  getdata(row, 0, genbuf, genbuf + 512, 3, LCECHO);
  if (genbuf[512] == 'n')
    getdata(++row, 0, "���D�G", save_title, TTLEN, DOECHO);
}


static void
do_reply(fhdr)
  fileheader *fhdr;
{
  getdata(b_lines, 0, "�� �^���� (F)�ݪO (M)�@�̫H�c (B)�G�̬ҬO (Q)�����H[F] ", genbuf, 3, LCECHO);
  switch (genbuf[0])
  {
  case 'm':
    mail_reply(0, fhdr, 0);
  case 'q':
    break;

  case 'b':
    curredit = EDIT_BOTH;
  default:
    strcpy(genbuf, fhdr->title);
    strcpy(quote_user, fhdr->owner);
    quote_file[79] = fhdr->savemode;
    do_post();
  }
}


int
do_post()
{
  fileheader postfile;
  char fpath[80], buf[80];
  int aborted;

  clear();
  if (!(currmode & MODE_POST))
  {
    move(5, 10);
    outs("�藍�_�A���ݪO�O��Ū��");
    pressanykey();
    return FULLUPDATE;
  }

  more("etc/post.note", NA);
  prints("�o���峹��i %s �j�ݪO\n\n", currboard);

  if (quote_file[0])
    do_reply_title(20, genbuf);
  else
    getdata(21, 0, "���D�G", save_title, TTLEN, DOECHO);

  if (save_title[0] == '\0')
    return FULLUPDATE;

  curredit &= ~EDIT_MAIL;
  setutmpmode(POSTING);

  buf[0] = local_article = 0;

  aborted = vedit(buf, YEA);
  if (aborted == -1)
  {
    unlink(buf);
    pressanykey();
    return FULLUPDATE;
  }

  /* build filename */

  setbpath(fpath, currboard);
  stampfile(fpath, &postfile);
  rename(buf, fpath);
  strcpy(postfile.owner, cuser.userid);
  strcpy(postfile.title, save_title);
  if (aborted == 1)		/* local save */
  {
    postfile.savemode = 'L';
    postfile.filemode = FILE_LOCAL;
  }
  else
    postfile.savemode = 'S';

  setbdir(buf, currboard);
  if (append_record(buf, &postfile, sizeof(postfile)) != -1)
  {
    if (aborted != 1)
      outgo_post(&postfile, currboard);

    brc_addlist(postfile.filename);
    outs("���Q�K�X�G�i�A");

    if (strcmp(currboard, "test"))
    {
      prints("�o�O�z���� %d �g�峹�C", ++cuser.numposts);
      UPDATE_USEREC;
    }
    else
      outs("���իH�󤣦C�J�����A�q�Х]�[�C");

    /* �^�����@�̫H�c */

    if (curredit & EDIT_BOTH)
    {
      char *str, *msg = "�^���ܧ@�̫H�c";

      if (str = strchr(quote_user, '.'))
      {
	if (bbs_sendmail(fpath, save_title, str + 1) < 0)
	  msg = "�@�̵L�k���H";
      }
      else
      {
	sethomepath(genbuf, quote_user);
	stampfile(genbuf, &postfile);
	unlink(genbuf);
	link(fpath, genbuf);

	strcpy(postfile.owner, cuser.userid);
	strcpy(postfile.title, save_title);
	postfile.savemode = 'B';/* both-reply flag */
	sethomedir(genbuf, quote_user);
	if (append_record(genbuf, &postfile, sizeof(postfile)) == -1)
	  msg = err_uid;
      }
      outs(msg);
      curredit ^= EDIT_BOTH;
    }
  }
  pressanykey();
  return FULLUPDATE;
}


static int
reply_post(ent, fhdr, direct)
  int ent;
  fileheader *fhdr;
  char *direct;
{
  if (!(currmode & MODE_POST))
    return DONOTHING;

  setdirpath(quote_file, direct, fhdr->filename);
  do_reply(fhdr);
  return FULLUPDATE;
}


static int
edit_post(ent, fhdr, direct)
  int ent;
  fileheader *fhdr;
  char *direct;
{
  if (!HAS_PERM(PERM_SYSOP) && strcmp(fhdr->owner, cuser.userid))
    return DONOTHING;

  setdirpath(genbuf, direct, fhdr->filename);
  local_article = fhdr->filemode & FILE_LOCAL;
  vedit(genbuf, NA);
  return FULLUPDATE;
}


static int
cross_post(ent, fhdr, direct)
  int ent;
  fileheader *fhdr;
  char *direct;
{
  char xboard[20], fname[80], xfpath[80], xtitle[80];
  fileheader xfile;
  FILE *xptr;

  make_blist();
  move(2, 0);
  clrtoeol();
  move(3, 0);
  clrtoeol();
  move(1, 0);
  namecomplete("������峹��ݪO�G", xboard);
  if (*xboard == '\0' || !haspostperm(xboard))
    return FULLUPDATE;

  ent = 1;
  if (HAS_PERM(PERM_SYSOP) || !strcmp(fhdr->owner, cuser.userid))
  {
    getdata(2, 0, "(1)������ (2)������榡�H[1] ",
      genbuf, 3, DOECHO);
    if (genbuf[0] != '2')
      ent = 0;
  }

  if (ent)
    sprintf(xtitle, "[���]%.66s", fhdr->title);
  else
    strcpy(xtitle, fhdr->title);

  sprintf(genbuf, "�ĥέ���D�m%.60s�n��?[Y] ", xtitle);
  getdata(2, 0, genbuf, genbuf + 512, 3, LCECHO);
  if (genbuf[512] == 'n')
  {
    if (getdata(2, 0, "���D�G", genbuf, TTLEN, DOECHO))
      strcpy(xtitle, genbuf);
  }

  getdata(2, 0, "(S)�s�� (L)���� (Q)�����H[Q] ", genbuf, 3, LCECHO);
  if (genbuf[0] == 'l' || genbuf[0] == 's')
  {
    setbpath(xfpath, xboard);
    stampfile(xfpath, &xfile);
    strcpy(xfile.owner, cuser.userid);
    strcpy(xfile.title, xtitle);
    if (genbuf[0] == 'l')
    {
      xfile.savemode = 'L';
      xfile.filemode = FILE_LOCAL;
    }
    else
      xfile.savemode = 'S';

    setbfile(fname, currboard, fhdr->filename);
    if (ent)
    {
      xptr = fopen(xfpath, "w");

      strcpy(save_title, xfile.title);
      strcpy(xfpath, currboard);
      strcpy(currboard, xboard);
      write_header(xptr);
      strcpy(currboard, xfpath);

      fprintf(xptr, "�� [��������� %s �ݪO]\n\n", currboard);

      b_suckinfile(xptr, fname);
      addsignature(xptr);
      fclose(xptr);
    }
    else
    {
      unlink(xfpath);
      link(fname, xfpath);
    }

    setbdir(fname, xboard);
    append_record(fname, (char *) &xfile, sizeof(xfile));
    if (!xfile.filemode)
      outgo_post(&xfile, xboard);
    cuser.numposts++;
    UPDATE_USEREC;
    outs("�峹�������");
    pressanykey();
  }
  return FULLUPDATE;
}


static int
read_post(ent, fhdr, direct)
  int ent;
  fileheader *fhdr;
  char *direct;
{
  if (fhdr->owner[0] == '-')
    return DONOTHING;

  setdirpath(genbuf, direct, fhdr->filename);

  if (more(genbuf, NA))
    return DONOTHING;

  brc_addlist(fhdr->filename);
  strncpy(currtitle, subject(fhdr->title), 40);

  outmsg("[34;46m  �\\Ū�峹  [31;47m  (R/Y)[30m�^�H [31m"
    "(=[]<>)[30m�����D�D [31m(����)[30m�W�U�� [31m(��)[30m���}  [0m");

  switch (egetch())
  {
  case 'q':
  case 'Q':
  case KEY_LEFT:
    break;

  case ' ':
  case KEY_RIGHT:
  case KEY_DOWN:
  case KEY_PGDN:
    return READ_NEXT;

  case KEY_UP:
  case 'p':
  case KEY_PGUP:
    return READ_PREV;

  case '=':
    return RELATE_FIRST;

  case ']':
    return RELATE_NEXT;

  case '[':
    return RELATE_PREV;

  case '.':
  case '>':
    return THREAD_NEXT;

  case ',':
  case '<':
    return THREAD_PREV;

  case 'y':
  case 'r':
  case 'R':
  case 'Y':
    if (currmode & MODE_POST)
    {
      strcpy(quote_file, genbuf);
      do_reply(fhdr);
    }
  }
  return FULLUPDATE;
}


/* ----------------------------------------------------- */
/* �Ķ���ذ�						 */
/* ----------------------------------------------------- */


static int
cite_post(ent, fhdr, direct)
  int ent;
  fileheader *fhdr;
  char *direct;
{
  if (currmode & MODE_BOARD)
  {
    char *fname, fpath[60], ans[4], buf[256], title[80] = "�� ";
    FILE *fp, *fin;
    int existed;

    /* fpath �i�H�]�t�ؿ����| */

    if (!getdata(b_lines, 0, "�п�J�ɦW�G", fpath, 60, DOECHO))
      return READ_REDRAW;

    if (fname = strrchr(fpath, '/'))
      fname++;
    else
      fname = fpath;
    fname[30] = '\0';
    sprintf(genbuf, "man/%s/%s", currboard, fpath);
    if (invalid_fname(fpath) || dashd(genbuf))
    {
      outmsg(err_filename);
      igetch();
      return READ_REDRAW;
    }

    if (existed = dashf(genbuf))
    {
      getdata(b_lines, 0, "�ۦP�ɦW�w�g�s�b�A�O�_���[�i�h(Y/N)�H[Y] ",
	ans, 3, LCECHO);
      if (ans[0] == 'n')
	return READ_REDRAW;
    }
    else
    {
      /* �۰ʳ] title */
      if (!getdata(b_lines, 0, "�п�J���D�G", title + 3, 60, DOECHO))
	strcpy(title + 3, fhdr->title);
    }

    if ((fp = fopen(genbuf, "a+")) == NULL)
      return READ_REDRAW;

    setbfile(buf, currboard, fhdr->filename);
    if (fin = fopen(buf, "r"))
    {
      if (existed)
      {
	memset(buf, '-', 74);
	buf[74] = '\0';
	fprintf(fp, "\n> %s <\n\n", buf);
      }

      ent = 1;
      getdata(b_lines, 0, "�O�_����ñ�W�ɳ���(Y/N)�H[N] ", ans, 3, LCECHO);
      if (ans[0] == 'y')
	ent = 0;

      while (fgets(buf, sizeof(buf), fin))
      {
	if (ent)
	{
	  if (!strcmp(buf, "--\n"))
	    break;
	}
	fputs(buf, fp);
      }
      fclose(fin);
    }

    fclose(fp);

    if (!existed)
    {
      direct = strrchr(genbuf, '/');
      strcpy(direct, fn_mandex);
      if (fp = fopen(genbuf, "a+"))
      {
	fprintf(fp, "Name=%s\nPath=%s\n", title, fname);
	fclose(fp);
      }
    }
    return READ_REDRAW;
  }
  return DONOTHING;
}


static int
edit_title(ent, fhdr, direct)
  int ent;
  fileheader *fhdr;
  char *direct;
{
  if (HAS_PERM(PERM_SYSOP) /* || !strcmp(fhdr->owner, cuser.userid) */ )
  {
    int dirty = 0;

    if (getdata(b_lines, 0, "���D�G", genbuf, TTLEN, DOECHO))
    {
      strcpy(fhdr->title, genbuf);
      dirty++;
    }

    if (getdata(b_lines, 0, "�@�̡G", genbuf, IDLEN + 2, DOECHO))
    {
      strcpy(fhdr->owner, genbuf);
      dirty++;
    }

    if (getdata(b_lines, 0, "����G", genbuf, 6, DOECHO))
    {
      sprintf(fhdr->date, "%+5s", genbuf);
      dirty++;
    }

    if (dirty)
      substitute_record(direct, fhdr, sizeof(*fhdr), ent);
    return PART_REDRAW;
  }
  return DONOTHING;
}


static int
mark_post(ent, fhdr, direct)
  int ent;
  fileheader *fhdr;
  char *direct;
{
  if (currmode & MODE_BOARD)
  {
    fhdr->filemode ^= FILE_MARKED;
    substitute_record(direct, fhdr, sizeof(*fhdr), ent);
    return PART_REDRAW;
  }
  return DONOTHING;
}


int
del_range(ent, fhdr, direct)
  int ent;
  fileheader *fhdr;
  char *direct;
{
  char num1[8], num2[8];
  int inum1, inum2;

  if ((currstat != READING) || (currmode & MODE_BOARD))
  {
    getdata(b_lines, 0, "[�]�w�R���d��] �_�I�G", num1, 5, DOECHO);
    inum1 = atoi(num1);
    if (inum1 <= 0)
    {
      outmsg("�_�I���~");
      igetch();
      return READ_REDRAW;
    }
    getdata(b_lines, 28, "���I�G", num2, 5, DOECHO);
    inum2 = atoi(num2);
    if (inum2 < inum1)
    {
      outmsg("���I���~");
      igetch();
      return READ_REDRAW;
    }
    getdata(b_lines, 48, msg_sure_ny, num1, 3, LCECHO);
    if (*num1 == 'y')
    {
      delete_range(direct, inum1, inum2);
      fixkeep(direct, inum1);
      return DIRCHANGED;
    }
    return READ_REDRAW;
  }
  return DONOTHING;
}


static void
lazy_delete(fhdr)
  fileheader *fhdr;
{
  char buf[20];

  sprintf(buf, "-%s", fhdr->owner);
  strncpy(fhdr->owner, buf, IDLEN + 1);
  strcpy(fhdr->title, "<< article deleted >>");
  fhdr->savemode = 'L';
}


static int
del_post(ent, fhdr, direct)
  int ent;
  fileheader *fhdr;
  char *direct;
{
  char buf[80];
  char *t;
  int not_owned;

  if ((fhdr->filemode & FILE_MARKED) || (fhdr->owner[0] == '-'))
    return DONOTHING;

  not_owned = strcmp(fhdr->owner, cuser.userid);
  if (!(currmode & MODE_BOARD) && not_owned)
    return DONOTHING;

  getdata(b_lines, 0, msg_del_ny, genbuf, 3, LCECHO);
  if (genbuf[0] == 'y')
  {
    strcpy(currfile, fhdr->filename);

    if (!update_file(direct, sizeof(fileheader), ent, cmpfilename, lazy_delete))
    {
      cancelpost(fhdr, not_owned);
      if (!not_owned && strcmp(currboard, "test"))
      {
	if (cuser.numposts)
	  cuser.numposts--;
	UPDATE_USEREC;
	move(b_lines, 0);
	clrtoeol();
	prints("%s�A�z���峹� %d �g", msg_del_ok, cuser.numposts);
	refresh();
	sleep(1);
      }
      lazy_delete(fhdr);
      return PART_REDRAW;
    }
  }
  return READ_REDRAW;
}


/* ----------------------------------------------------- */
/* �̧�Ū�s�峹						 */
/* ----------------------------------------------------- */

static int sequent_ent;


static int
sequent_messages(fptr)
  fileheader *fptr;
{
  static int idc;
  char ans[6];

  if (fptr == NULL)
    return (idc = 0);

  if (++idc < sequent_ent)
    return 0;

  if (!brc_unread(fptr->filename))
    return 0;

  if (continue_flag)
  {
    genbuf[0] = 'y';
  }
  else
  {
    prints("Ū���峹��G[%s] �@�̡G[%s]\n���D�G[%s]",
      currboard, fptr->owner, fptr->title);
    getdata(3, 0, "(Y/N/Quit) [Y]: ", genbuf, 3, LCECHO);
  }

  if (genbuf[0] != 'y' && genbuf[0])
  {
    clear();
    return (genbuf[0] == 'q' ? QUIT : 0);
  }

  setbfile(genbuf, currboard, fptr->filename);
  brc_addlist(fptr->filename);

  more(genbuf, NA);
  outmsg("[31;47m  [31m(R)[30m�^�H  [31m(��,n)[30m�U�@��  [31m(��,q)[30m���}  [0m");
  continue_flag = 0;

  switch (egetch())
  {
  case KEY_LEFT:
  case 'e':
  case 'q':
  case 'Q':
    break;

  case 'y':
  case 'r':
  case 'Y':
  case 'R':
    if (currmode & MODE_POST)
    {
      strcpy(quote_file, genbuf);
      do_reply(fptr);
    }
    break;

  case ' ':
  case KEY_DOWN:
  case '\n':
  case 'n':
    continue_flag = 1;
  }

  clear();
  return 0;
}


static int
sequential_read(ent, fhdr, direct)
  int ent;
  fileheader *fhdr;
  char *direct;
{
  char buf[40];

  clear();
  sequent_messages((fileheader *) NULL);
  sequent_ent = ent;
  continue_flag = 0;
  setbdir(buf, currboard);
  apply_record(buf, sequent_messages, sizeof(fileheader));
  return FULLUPDATE;
}


/* ----------------------------------------------------- */
/* �ݪO�Ƨѿ��B��K�B��ذ�				 */
/* ----------------------------------------------------- */


static int
b_notes_edit()
{
  if (currmode & MODE_BOARD)
  {
    struct stat st;
    char buf[64];
    int aborted;

    setbfile(buf, currboard, fn_notes);
    aborted = vedit(buf, NA);
    if (aborted)
    {
      clear();
      outs(msg_cancel);
      pressanykey();
    }
    else
    {
      boardheader fh;
      int pos;

      getdata(3, 0, "�г]�w���Ĵ���(0 - 9999)�ѡH", buf, 5, DOECHO);
      aborted = atol(buf);
      pos = search_record(fn_board, &fh, sizeof(fh), cmpbnames, currboard);
      fh.bupdate = aborted ? time(0) + aborted * 86400 : 0;
      substitute_record(fn_board, &fh, sizeof(fh), pos);
      touch_boards();
    }
    return FULLUPDATE;
  }
  return 0;
}


static int
b_notes()
{
  char buf[64];

  setbfile(buf, currboard, fn_notes);
  if (more(buf, NA) == -1)
  {
    clear();
    move(4, 20);
    outs("���ݪO�|�L�u�Ƨѿ��v�C");
  }
  pressanykey();
  return FULLUPDATE;
}


static int
b_man()
{
  char buf[64];

  setapath(buf, currboard);
  a_menu(currboard, buf, HAS_PERM(PERM_ALLBOARD) ? 2 :
    (currmode & MODE_BOARD ? 1 : 0));
  return FULLUPDATE;
}


int
board_digest()
{
  currmode ^= MODE_DIGEST;
  if (currmode & MODE_DIGEST)
    currmode &= ~MODE_POST;
  else if (haspostperm(currboard))
    currmode |= MODE_POST;

  setbdir(currdirect, currboard);
  return NEWDIRECT;
}


static int
good_post(ent, fhdr, direct)
  int ent;
  fileheader *fhdr;
  char *direct;
{
  if ((currmode & MODE_DIGEST) || !(currmode & MODE_BOARD))
    return DONOTHING;

  if (fhdr->filemode & FILE_DIGEST)
  {
    fhdr->filemode = (fhdr->filemode & ~FILE_DIGEST);
  }
  else
  {
    fileheader digest;
    char *ptr, buf[64];

    memcpy(&digest, fhdr, sizeof(digest));
    digest.filename[0] = 'G';
    strcpy(buf, direct);
    ptr = strrchr(buf, '/') + 1;
    ptr[0] = '\0';
    sprintf(genbuf, "%s%s", buf, digest.filename);
    if (dashf(genbuf))
      return DONOTHING;
    digest.savemode = digest.filemode = 0;
    sprintf(&genbuf[512], "%s%s", buf, fhdr->filename);
    link(&genbuf[512], genbuf);
    strcpy(ptr, fn_mandex);
    append_record(buf, &digest, sizeof(digest));

    fhdr->filemode = (fhdr->filemode & ~FILE_MARKED) | FILE_DIGEST;
  }
  substitute_record(direct, fhdr, sizeof(*fhdr), ent);
  return PART_REDRAW;
}


/* help for board reading */

static char *board_help[] =
{
  "\0���\\��ݪO�ާ@����",
  "\01�򥻩R�O",
  "(p)(��)   �W���@�g�峹          (^P)     �o���峹",
  "(n)(��)   �U���@�g�峹          (d)      �R���峹",
  "(P)(PgUp) �W���@��              (S)      �`�Ǿ\\Ū�s�峹",
  "(N)(PgDn) �U���@��              (##)     ���� ## ���峹",
  "(r)(��)   �\\Ū���g�峹          ($)      ����̫�@�g�峹",
  "\01�i���R�O",
  "(tab)/z   ��K�Ҧ�/��ذ�       (a)(A)   ��M�@��",
  "(b)       �iŪ�Ƨѿ�            (?)(/)   ��M���D",
  "(V,R)     �벼/�d�ߧ벼���G     (=)      ��M���g�峹",
  "(x)       ����峹���L�ݪO    ([]<>-+) �D�D���\\Ū",

#ifdef INTERNET_EMAIL
  "(F)       �N�峹�H�^ Internet �l�c",
  "(U)       �N�峹 uuencode ��H�^�l�c",
#endif

  "(Z)       Z-modem ����",

  "\01�O�D�R�O",
  "(m)       �O�d���g�峹          (W)     �s��Ƨѿ�",
  "(M)       �|��벼              (c/g)   ������/��K",
  "(D)       �R���@�q�d�򪺤峹    (E/T)   ���s�峹/���D",

  NULL
};


static int
b_help()
{
  show_help(board_help);
  return FULLUPDATE;
}


/* ----------------------------------------------------- */
/* �ݪO�\���						 */
/* ----------------------------------------------------- */


extern int b_vote();
extern int b_results();
extern int b_vote_maintain();

struct one_key read_comms[] = {
  KEY_TAB, board_digest,
  'b', b_notes,
  'c', cite_post,
  'r', read_post,
  'z', b_man,
  'D', del_range,
  'S', sequential_read,
  'E', edit_post,
  'T', edit_title,
  's', do_select,
  'R', b_results,
  'V', b_vote,
  'M', b_vote_maintain,
  'W', b_notes_edit,
  'h', b_help,

  'g', good_post,
  'x', cross_post,
  'y', reply_post,
  'd', del_post,
  'm', mark_post,
  Ctrl('P'), do_post,

  '\0', NULL
};


int
Read()
{
  char buf[40];

  set_board();
  if (board_visit_time < board_note_time)
  {
    setbfile(buf, currboard, fn_notes);
    more(buf, YEA);
  }

  setbdir(buf, currboard);
  curredit &= ~EDIT_MAIL;
  i_read(READING, buf, readtitle, readdoent, read_comms);
  brc_update();
  return 0;
}


int
Select()
{
  setutmpmode(SELECT);
  do_select(0, NULL, genbuf);
  return 0;
}


int
Post()
{
  do_post();
  return 0;
}
