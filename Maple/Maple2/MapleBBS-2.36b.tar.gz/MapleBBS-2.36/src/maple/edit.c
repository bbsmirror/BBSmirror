/*-------------------------------------------------------*/
/* edit.c	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : simple ANSI/Chinese editor			 */
/* create : 95/03/29					 */
/* update : 95/12/15					 */
/*-------------------------------------------------------*/


#include "bbs.h"


#define KEEP_EDITING	-2
#define	SCR_WIDTH	80
#define	BACKUP_LIMIT	100

textline *firstline = NULL;
textline *lastline = NULL;
textline *currline = NULL;
textline *top_of_win = NULL;

extern int local_article;

int currpnt, currln, totaln;
int curr_window_line;
int redraw_everything;
int insert_character;
int my_ansimode;
int edit_margin;

char fp_bak[] = "bak";
char *my_edit_mode[2] =
{"���N", "���J"};

char save_title[STRLEN];


/* ----------------------------------------------------- */
/* �O����޲z�P�s��B�z					 */
/* ----------------------------------------------------- */

static void
indigestion(i)
{
  fprintf(stderr, "�Y������ %d\n", i);
}


static textline *
back_line(pos, num)
  register textline *pos;
  int num;
{
  while (num-- > 0)
  {
    register textline *item;

    if (pos && (item = pos->prev))
    {
      pos = item;
      currln--;
    }
  }
  return pos;
}


static textline *
forward_line(pos, num)
  register textline *pos;
  int num;
{
  while (num-- > 0)
  {
    register textline *item;

    if (pos && (item = pos->next))
    {
      pos = item;
      currln++;
    }
  }
  return pos;
}


static int
getlineno()
{
  int cnt = 0;
  textline *p = currline;

  while (p && (p != top_of_win))
  {
    cnt++;
    p = p->prev;
  }
  return cnt;
}


static char *
killsp(s)
  char *s;
{
  while (*s == ' ')
    s++;
  return s;
}


static textline *
alloc_line()
{
  extern void *malloc();
  register textline *p;

  if (p = (textline *) malloc(sizeof(textline)))
  {
    memset(p, 0, sizeof(textline));
    return p;
  }

  indigestion(13);
  abort_bbs();
}


/* ----------------------------------------------------- */
/* append p after line in list. keeps up with last line	 */
/* ----------------------------------------------------- */

static void
append(p, line)
  register textline *p, *line;
{
  register textline *n;

  if (p->next = n = line->next)
    n->prev = p;
  else
    lastline = p;
  line->next = p;
  p->prev = line;
}


/* ----------------------------------------------------- */
/* delete_line deletes 'line' from the list,		 */
/* and maintains the lastline, and firstline pointers.	 */
/* ----------------------------------------------------- */

static void
delete_line(line)
  register textline *line;
{
  register textline *p = line->prev;
  register textline *n = line->next;

  if (!p && !n)
  {
    line->data[0] = line->len = 0;
    return;
  }
  if (n)
    n->prev = p;
  else
    lastline = p;
  if (p)
    p->next = n;
  else
    firstline = n;
  free(line);
  totaln--;
}


/* ----------------------------------------------------- */
/* split 'line' right before the character pos		 */
/* ----------------------------------------------------- */

static void
split(line, pos)
  register textline *line;
  register int pos;
{
  if (pos <= line->len)
  {
    register textline *p = alloc_line();
    register char *ptr;

    totaln++;

    p->len = line->len - pos;
    line->len = pos;
    strcpy(p->data, (ptr = line->data + pos));
    ptr[0] = '\0';
    append(p, line);
    if (line == currline && pos <= currpnt)
    {
      currline = p;
      currpnt -= pos;
      curr_window_line++;
      currln++;
    }
    redraw_everything = YEA;
  }
}


/* ----------------------------------------------------- */
/* 1) lines were joined and one was deleted		 */
/* 2) lines could not be joined		 		 */
/* 3) next line is empty				 */
/* returns false if:					 */
/* 1) Some of the joined line wrapped			 */
/* ----------------------------------------------------- */

static int
join(line)
  register textline *line;
{
  register textline *n;
  register int ovfl;

  if (!(n = line->next))
    return YEA;
  if (!*killsp(n->data))
    return YEA;

  ovfl = line->len + n->len - WRAPMARGIN;
  if (ovfl < 0)
  {
    strcat(line->data, n->data);
    line->len += n->len;
    delete_line(n);
    return YEA;
  }
  else
  {
    register char *s;

    s = n->data + n->len - ovfl - 1;
    while (s != n->data && *s == ' ')
      s--;
    while (s != n->data && *s != ' ')
      s--;
    if (s == n->data)
      return YEA;
    split(n, (s - n->data) + 1);
    if (line->len + n->len >= WRAPMARGIN)
    {
      indigestion(0);
      return YEA;
    }
    join(line);
    n = line->next;
    ovfl = n->len - 1;
    if (ovfl >= 0 && ovfl < WRAPMARGIN - 2)
    {
      s = &(n->data[ovfl]);
      if (*s != ' ')
      {
	strcpy(s, " ");
	n->len++;
      }
    }
    return NA;
  }
}


static void
insert_char(ch)
  register int ch;
{
  register textline *p = currline;
  register int i = p->len;
  register char *s;
  int wordwrap = YEA;

  if (currpnt > i)
  {
    indigestion(1);
    return;
  }
  if (currpnt < i && !insert_character)
  {
    p->data[currpnt++] = ch;
  }
  else
  {
    while (i >= currpnt)
    {
      p->data[i + 1] = p->data[i];
      i--;
    }
    p->data[currpnt++] = ch;
    i = ++(p->len);
  }
  if (i < WRAPMARGIN)
    return;
  s = p->data + (i - 1);
  while (s != p->data && *s == ' ')
    s--;
  while (s != p->data && *s != ' ')
    s--;
  if (s == p->data)
  {
    wordwrap = NA;
    s = p->data + (i - 2);
  }
  split(p, (s - p->data) + 1);
  p = p->next;
  i = p->len;
  if (wordwrap && i >= 1)
  {
    if (p->data[i - 1] != ' ')
    {
      p->data[i] = ' ';
      p->data[i + 1] = '\0';
      p->len++;
    }
  }
}


static void
insert_string(str)
  char *str;
{
  int ch;

  while (ch = *str++)
  {

#ifdef BIT8
    if (isprint2(ch) || ch == '')
#else
    if (isprint(ch))
#endif

    {
      insert_char(ch);
    }
    else if (ch == '\t')
    {
      do
      {
	insert_char(' ');
      } while (currpnt & 0x7);
    }
    else if (ch == '\n')
      split(currline, currpnt);
  }
}


static void
delete_char()
{
  register int len;

  if (len = currline->len)
  {
    register int i;
    register char *s;

    if (currpnt >= len)
    {
      indigestion(1);
      return;
    }
    for (i = currpnt, s = currline->data + i; i != len; i++, s++)
      s[0] = s[1];
    currline->len--;
  }
}


static void
load_file(fp)
  FILE *fp;
{
  char buf[256];

  while (fgets(buf, 256, fp))
  {
    insert_string(buf);
  }
  fclose(fp);
}


/* ----------------------------------------------------- */
/* �Ȧs��						 */
/* ----------------------------------------------------- */

static char *
ask_tmpbuf()
{
  static char fp_buf[] = "buf.0";
  static char msg[] = "�п�ܼȦs�� (0-9)[0]: ";

  msg[19] = fp_buf[4];
  do
  {
    if (!getdata(3, 0, msg, fp_buf + 4, 2, DOECHO))
      fp_buf[4] = msg[19];
  } while (fp_buf[4] < '0' || fp_buf[4] > '9');
  return fp_buf;
}


static void
read_tmpbuf()
{
  FILE *fp;
  char fp_tmpbuf[80];

  setuserfile(fp_tmpbuf, ask_tmpbuf());

  if (fp = fopen(fp_tmpbuf, "r"))
  {
    load_file(fp);
    while (curr_window_line >= b_lines)
    {
      curr_window_line--;
      top_of_win = top_of_win->next;
    }
  }
}


static void
write_tmpbuf()
{
  FILE *fp;
  char fp_tmpbuf[80], ans[4];
  textline *p;

  setuserfile(fp_tmpbuf, ask_tmpbuf());
  if (dashf(fp_tmpbuf))
  {
    getdata(3, 0, "�Ȧs�ɤw����� (A)���[ (W)�мg (Q)�����H[A] ",
      ans, 4, LCECHO);

    if (ans[0] == 'q')
      return;
  }

  fp = fopen(fp_tmpbuf, (ans[0] == 'w' ? "w" : "a+"));
  for (p = firstline; p; p = p->next)
  {
    if (p->next || p->data[0])
      fprintf(fp, "%s\n", p->data);
  }
  fclose(fp);
}


static void
erase_tmpbuf()
{
  char fp_tmpbuf[80];

  setuserfile(fp_tmpbuf, ask_tmpbuf());
  unlink(fp_tmpbuf);
}


/* ----------------------------------------------------- */
/* �s�边�۰ʳƥ�					 */
/* ----------------------------------------------------- */


void
auto_backup()
{
  if (currline)
  {
    FILE *fp;
    textline *p, *v;
    char bakfile[64];

    setuserfile(bakfile, fp_bak);
    if (fp = fopen(bakfile, "w"))
    {
      for (p = firstline; p; p = v)
      {
	v = p->next;
	fprintf(fp, "%s\n", p->data);
	free(p);
      }
      fclose(fp);
    }
    currline = NULL;
  }
}


void
restore_backup()
{
  char bakfile[80], buf[80];

  setuserfile(bakfile, fp_bak);
  if (dashf(bakfile))
  {
    stand_title("�s�边�۰ʴ_��");
    getdata(1, 0, "�z���@�g�峹�|�������A(S)�g�J�Ȧs�� (Q)��F�H[S] ",
      buf, 3, LCECHO);
    if (buf[0] != 'q')
    {
      setuserfile(buf, ask_tmpbuf());
      rename(bakfile, buf);
    }
    else
      unlink(bakfile);
  }
}


/* ----------------------------------------------------- */
/* �ޥΤ峹						 */
/* ----------------------------------------------------- */


static int
garbage_line(str)		/* quote deletion */
  char *str;
{
  int qlevel = 0;

  while (*str == ':' || *str == '>')
  {
    if (*(++str) == ' ')
      str++;
    if (qlevel++ >= 1)
      return 1;
  }
  while (*str == ' ' || *str == '\t')
    str++;
  if (qlevel >= 1)
  {
    if (!strncmp(str, "�� ", 3) || !strncmp(str, "==>", 3) ||
      strstr(str, ") ����:\n"))
      return 1;
  }
  return (*str == '\n');
}


static void
do_quote()
{
  int op;
  char buf[256], word[256];

  getdata(b_lines, 0, "�аݭn�ޥέ���(Y/N/All/Repost)�H[Y] ", buf, 3, LCECHO);
  op = buf[0];

  if (op != 'n')
  {
    FILE *inf;

    if (inf = fopen(quote_file, "r"))
    {
      char *ptr;

      fgets(buf, 256, inf);
      if (ptr = strrchr(buf, ')'))
	ptr[1] = '\0';
      else if (ptr = strrchr(buf, '\n'))
	ptr[0] = '\0';

      if (ptr = strchr(buf, ':'))
      {
	char *str;

	while (*(++ptr) == ' ');

	/* ����o�ϡA���o author's address */
	if ((curredit & EDIT_BOTH) && (str = strchr(quote_user, '.')))
	{
	  strcpy(++str, ptr);
	  str = strchr(str, ' ');
	  str[0] = '\0';
	}
      }
      else
	ptr = quote_user;

      insert_string("�� �ޭz�m");
      insert_string(ptr);
      insert_string("�n���ʨ��G\n");

      if (op != 'a')		/* �h�� header */
      {
	while (fgets(buf, 256, inf) && buf[0] != '\n');
      }

      if (op == 'a')
      {
	while (fgets(buf, 256, inf))
	{
	  insert_char(':');
	  insert_char(' ');
	  insert_string(buf);
	}
      }
      else if (op == 'r')
      {
	while (fgets(buf, 256, inf))
	  insert_string(buf);
      }
      else
      {
	if (curredit & EDIT_LIST)	/* �h�� mail list �� header */
	{
	  while (fgets(buf, 256, inf) && (!strncmp(buf, "�� ", 3)));
	}

	while (fgets(buf, 256, inf))
	{
	  if (!strcmp(buf, "--\n"))
	    break;
	  if (!garbage_line(buf))
	  {
	    insert_char(':');
	    insert_char(' ');
	    insert_string(buf);
	  }
	}
      }
      fclose(inf);
    }
  }
}


/* ----------------------------------------------------- */
/* �f�d user �ި����ϥ�					 */
/* ----------------------------------------------------- */


static int
check_quote()
{
  register textline *p = firstline;
  register char *str;
  int post_line;
  int included_line;

  post_line = included_line = 0;
  while (p)
  {
    if (!strcmp(str = p->data, "--"))
      break;
    if (str[1] == ' ' && ((str[0] == ':') || (str[0] == '>')))
    {
      included_line++;
    }
    else
    {
      while (*str == ' ' || *str == '\t')
	str++;
      if (*str)
	post_line++;
    }
    p = p->next;
  }

  if ((included_line >> 2) > post_line)
  {
    move(4, 0);

    outs("\
        ���g�峹���ި���ҶW�L 80%�A�бz���ǷL���ץ��G\n\n\
         [1;33m1) �W�[�@�Ǥ峹 ��  2) �R�������n���ި�[0m");

    if (HAS_PERM(PERM_SYSOP))
    {
      char ans[4];
      getdata(12, 12, "(E)�~��s�� (W)�j��g�J�H[E] ", ans, 4, LCECHO);
      if (ans[0] == 'w')
	return 0;
    }
    else
	pressanykey();
    return 1;
  }
  return 0;
}


/* ----------------------------------------------------- */
/* �ɮ׳B�z�GŪ�ɡB�s�ɡB���D�Bñ�W��			 */
/* ----------------------------------------------------- */


static void
read_file(fpath)
  char *fpath;
{
  FILE *fp;

  if ((fp = fopen(fpath, "r+")) == NULL)
  {
    if (fp = fopen(fpath, "w+"))
    {
      fclose(fp);
      return;
    }
    indigestion(4);
    abort_bbs();
  }
  load_file(fp);
}


#ifndef VEDITOR
void
write_header(fp)
  FILE *fp;
{
  time_t now = time(0);

  if (curredit & EDIT_MAIL)
  {
    fprintf(fp, "%s %s (%s)\n", str_author1, cuser.userid,

#if defined(REALINFO) && defined(MAIL_REALNAMES)
      cuser.realname);
#else
      cuser.username);
#endif
  }
  else
  {
    char *ptr;

    /* ���Ͳέp��� */

    struct
    {
      char author[IDLEN + 1];
      char board[IDLEN + 1];
      char title[66];
      time_t date;		/* last post's date */
      int number;		/* post number */
    }      postlog;

    strcpy(postlog.author, cuser.userid);
    strcpy(postlog.board, currboard);
    ptr = save_title;
    if (!strncmp(ptr, str_reply, 4))
      ptr += 4;
    strncpy(postlog.title, ptr, 65);
    postlog.date = now;
    postlog.number = 1;
    append_record(".post", &postlog, sizeof(postlog));

    fprintf(fp, "%s %s (%s) %s %s\n", str_author1, cuser.userid,

#if defined(REALINFO) && defined(POSTS_REALNAMES)
      cuser.realname
#else
      cuser.username
#endif

      ,local_article ? str_post2 : str_post1, currboard);
  }
  save_title[72] = '\0';
  fprintf(fp, "���D: %s\n�ɶ�: %s\n", save_title, ctime(&now));
}


void
addsignature(fp)
  FILE *fp;
{
  FILE *fs;
  int i;
  char buf[WRAPMARGIN + 1];
  char fpath[STRLEN];

  static char msg[] = "�п��ñ�W�� (1/2/3, 0=���[)[0]: ";
  char ch;

  i = showsignature(fpath);
  msg[29] = ch = '0' | (cuser.uflag & SIG_FLAG);
  getdata(0, 0, msg, buf, 4, DOECHO);

  if (ch != buf[0] && buf[0] >= '0' && buf[0] <= '3')
  {
    ch = buf[0];
    cuser.uflag = (cuser.uflag & ~SIG_FLAG) | (ch & SIG_FLAG);
  }

  if (ch == '0')
    return;

  fpath[i] = ch;
  if (fs = fopen(fpath, "r"))
  {
    fputs("\n--\n", fp);
    for (i = 0; i < MAXSIGLINES && fgets(buf, sizeof(buf), fs); i++)
      fputs(buf, fp);
    fclose(fs);
  }

#ifdef	HAVE_ORIGIN
  fprintf(fp, "\n--\n�� Origin: %s �� From: %s\n", BoardName, fromhost);
#endif
}
#endif


static int
write_file(fpath, saveheader)
  char *fpath;
  int saveheader;
{
  FILE *fp;
  textline *p, *v;
  char ans[TTLEN], *msg;
  int aborted = 0;

  stand_title("�ɮ׳B�z");

#ifndef VEDITOR
  {
    if (currstat == SMAIL)
      msg = "[S]�x�s (A)��� (T)����D (E)�~�� (R/W/D)Ū�g�R�Ȧs�ɡH";
    else if (local_article)
      msg = "[L]�����H�� (S)�x�s (A)��� (T)����D (E)�~�� (R/W/D)Ū�g�R�Ȧs�ɡH";
    else
      msg = "[S]�x�s (L)�����H�� (A)��� (T)����D (E)�~�� (R/W/D)Ū�g�R�Ȧs�ɡH";
    getdata(1, 0, msg, ans, 3, LCECHO);
  }
#else
  ans[0] = 's';
#endif

  switch (ans[0])
  {
  case 'a':
    outs("�峹[1m �S�� [0m�s�J");
    sleep(1);
    aborted = -1;
    break;

  case 'r':
    read_tmpbuf();

  case 'e':
    return KEEP_EDITING;

  case 'w':
    write_tmpbuf();
    return KEEP_EDITING;

  case 'd':
    erase_tmpbuf();
    return KEEP_EDITING;

  case 't':
    move(3, 0);
    prints("�¼��D�G%s", save_title);
    if (getdata(4, 0, "�s���D�G", ans, TTLEN, DOECHO))
      strcpy(save_title, ans);
    return KEEP_EDITING;

  case 's':
    local_article = 0;
    break;

  case 'l':
    local_article = 1;
  }

  if (!aborted)
  {
    if (saveheader && !(curredit & EDIT_MAIL) && check_quote())
      return KEEP_EDITING;

    if (!*fpath)
    {
      setuserfile(fpath, fn_notes);
    }

    if ((fp = fopen(fpath, "w")) == NULL)
    {
      indigestion(5);
      abort_bbs();
    }

#ifndef VEDITOR
    if (saveheader)
      write_header(fp);
#endif
  }

  for (p = firstline; p; p = v)
  {
    v = p->next;
    if (!aborted)
    {
      msg = p->data;
      if (v || msg[0])
      {
	trim(msg);
	fprintf(fp, "%s\n", msg);
      }
    }
    free(p);
  }
  currline = NULL;

  if (!aborted)
  {

#ifndef	VEDITOR
    if (currstat == POSTING || currstat == SMAIL)
      addsignature(fp);
#endif

    fclose(fp);

#ifndef VEDITOR
    if (local_article && (currstat == POSTING))
      return 1;
#endif
  }

  return aborted;
}


/* ----------------------------------------------------- */
/* �ù��B�z�G���U�T���B��ܽs�褺�e			 */
/* ----------------------------------------------------- */

static void
edit_msg(void)
{
  move(b_lines, 0);
  clrtoeol();
  prints("[34;46m  �s��峹  [31;47m  (Ctrl-Z)[30m �u�W���U����   [31m(^W,^X)[30m �ɮ׳B�z     �� %s �� %3d:%3d  [0m",
    my_edit_mode[insert_character], currln + 1, currpnt + 1);
}


static void
edit_outs(text)
  char *text;
{
  register int column = 0;
  register char ch;

  while ((ch = *text++) && (++column < SCR_WIDTH))
  {
    outch(ch == 27 ? '*' : ch);
  }
}


static void
display_buffer()
{
  register textline *p;
  register int i;

  for (p = top_of_win, i = 0; i < b_lines; i++)
  {
    move(i, 0);
    clrtoeol();
    if (p)
    {
      if (my_ansimode)
	edit_outs(&p->data[edit_margin]);
      else
	outs(p->data);
      p = p->next;
    }
    else
      outch('~');
  }
  edit_msg();
}


static char *vedithelp[] =
{
  "\0�s�边���U�e��",
  "\01�@����O",
  "^w,^x    �ɮ׳B�z               ^G,^L    ���s��ܵe��",
  "^V       ���� ANSI �w���Ҧ�     ^Z       ��ܥ��D�U�e��",
  "\01��в��ʫ��O",
  "��,^R    ���Ჾ�ʤ@��           ^A,Home  ���즹��}�Y",
  "��       ���e���ʤ@��           ^E,End   ���즹�浲��",
  "��,^P    ���W���ʤ@��           ^S,^]    �����ɮ׶}�Y",
  "��,^N    ���U���ʤ@��           ^T       �����ɮ׵���",
  "^B,PgUp  ���W���ʤ@��           ^F,PgDn  ���U���ʤ@��",
  "\01�R�����J���O",
  "^O,Ins   ���ܼҦ��� insert/overwrite",
  "^H,BS    �R���e�@�Ӧr��",
  "^D,DEL   �R���ثe���r��         ANSI�x�¬�����ŵ��Q��",
  "^K       �R����Ф���ܦ��     �e���x[47;30;1m30[31m31[32m32[33m33[34m34[35m35[36m36[37m37[0m",
  "^Y       �R���ثe�o��           �I���x[40;33;1m40[41m41[42m42[43m43[44m44[45m45[46m46[47m47[0m",
  "\01�S�����O",
  "^U       ��J ESC �X(�H * ����)    ^C    �٭� ANSI ��m",
NULL};


void
show_help(helptext)
  char *helptext[];
{
  char *str;
  int i;

  clear();
  for (i = 0; (str = helptext[i]); i++)
  {
    if (*str == '\0')
      prints("[1m�i %s �j[0m\n", str + 1);
    else if (*str == '\01')
      prints("\n[36m�i %s �j[m\n", str + 1);
    else
      prints("        %s\n", str);
  }
  pressanykey();
}


/* ----------------------------------------------------- */
/* �s��B�z�G�D�{���B��L�B�z				 */
/* ----------------------------------------------------- */

int
vedit(fpath, saveheader)
  char *fpath;
  int saveheader;
{
  int ch, foo;
  int lastindent = -1;
  int last_margin;

  insert_character = my_ansimode = redraw_everything = 1;

  currpnt = totaln = 0;
  if (currline == NULL)
    currline = top_of_win = firstline = lastline = alloc_line();

  if (*fpath)
  {
    read_file(fpath);
  }

  if (*quote_file)
  {
    do_quote();
    *quote_file = '\0';
    if (quote_file[79] == 'L')
      local_article = 1;
  }

  currline = firstline;
  currpnt = currln = curr_window_line = edit_margin = last_margin = 0;

  while (1)
  {
    if (redraw_everything)
    {
      display_buffer();
      redraw_everything = NA;
    }
    move(curr_window_line, currpnt - edit_margin);
    ch = igetkey();

#ifdef BIT8
    if (ch < 0x100 && isprint2(ch))
#else
    if (ch < 0x100 && isprint(ch))
#endif

    {
      insert_char(ch);
      lastindent = -1;
    }
    else
    {
      if (ch == Ctrl('P') || ch == KEY_UP ||
	ch == Ctrl('N') || ch == KEY_DOWN)
      {
	if (lastindent == -1)
	  lastindent = currpnt;
      }
      else
	lastindent = -1;

      switch (ch)
      {
      case Ctrl('X'):		/* Save and exit */
      case Ctrl('W'):
	foo = write_file(fpath, saveheader);
	if (foo != KEEP_EDITING)
	{
	  return foo;
	}
	redraw_everything = YEA;
	break;

#ifdef VEDITOR
      case Ctrl('Q'):		/* Quit without saving */
	ch = ask("���������x�s (Y/N)? [N]: ");
	if (ch == 'y' || ch == 'Y')
	{
	  ch = ask("�~��s��� (Y/N)? [Y]: ");
	  if (ch == 'n' || ch == 'N')
	  {
	    clear();
	    return 0;
	  }
	}
	redraw_everything = YEA;
	break;
#endif

      case Ctrl('C'):
	ch = insert_character;
	insert_character = 1;
#define	ptr redraw_everything
	for (ptr = 0; ptr < 10; ptr++)
	  insert_char(reset_color[ptr]);
#undef	ptr
	insert_character = ch;
	break;

      case Ctrl('U'):
	insert_char('');
	break;

      case Ctrl('I'):
	do
	{
	  insert_char(' ');
	}
	while (currpnt & 0x7);
	break;

      case '\r':
      case '\n':
	split(currline, currpnt);
	break;

      case Ctrl('Z'):
	show_help(vedithelp);
	redraw_everything = YEA;
	break;

      case Ctrl('V'):		/* Toggle ANSI color */
	my_ansimode ^= 1;

      case Ctrl('G'):
	clear();
	redraw_everything = YEA;
	break;

      case KEY_LEFT:
      case Ctrl('R'):
	if (currpnt)
	  currpnt--;
	else if (currline->prev)
	{
	  curr_window_line--;
	  currln--;
	  currline = currline->prev;
	  currpnt = currline->len;
	}
	break;

      case KEY_RIGHT:
	if (currline->len != currpnt)
	  currpnt++;
	else if (currline->next)
	{
	  currpnt = 0;
	  curr_window_line++;
	  currln++;
	  currline = currline->next;
	}
	break;

      case KEY_UP:
      case Ctrl('P'):
	if (currline->prev)
	{
	  curr_window_line--;
	  currln--;
	  currline = currline->prev;
	  currpnt = (currline->len > lastindent) ? lastindent : currline->len;
	}
	break;

      case KEY_DOWN:
      case Ctrl('N'):
	if (currline->next)
	{
	  currline = currline->next;
	  curr_window_line++;
	  currln++;
	  currpnt = (currline->len > lastindent) ? lastindent : currline->len;
	}
	break;

      case KEY_PGUP:
      case Ctrl('B'):
	redraw_everything = currln;
	top_of_win = back_line(top_of_win, 22);
	currln = redraw_everything;
	currline = back_line(currline, 22);
	curr_window_line = getlineno();
	if (currpnt > currline->len)
	  currpnt = currline->len;
	redraw_everything = YEA;
	break;

      case KEY_PGDN:
      case Ctrl('F'):
	redraw_everything = currln;
	top_of_win = forward_line(top_of_win, 22);
	currln = redraw_everything;
	currline = forward_line(currline, 22);
	curr_window_line = getlineno();
	if (currpnt > currline->len)
	  currpnt = currline->len;
	redraw_everything = YEA;
	break;

      case KEY_END:
      case Ctrl('E'):
	currpnt = currline->len;
	break;

      case Ctrl('S'):		/* start of file */
      case Ctrl(']'):
	currline = top_of_win = firstline;
	currpnt = currln = curr_window_line = 0;
	redraw_everything = YEA;
	break;

      case Ctrl('T'):		/* tail of file */
	top_of_win = back_line(lastline, 23);
	currline = lastline;
	curr_window_line = getlineno();
	currln = totaln;
	redraw_everything = YEA;

      case KEY_HOME:
      case Ctrl('A'):
	currpnt = 0;
	break;

      case KEY_INS:		/* Toggle insert/overwrite */
      case Ctrl('O'):
	insert_character ^= 1;
	/* edit_msg(); */
	break;

      case Ctrl('H'):
      case '\177':		/* backspace */
	if (currpnt == 0)
	{
	  textline *p;

	  if (!currline->prev)
	  {
	    break;
	  }
	  curr_window_line--;
	  currln--;
	  currline = currline->prev;
	  currpnt = currline->len;
	  redraw_everything = YEA;
	  if (*killsp(currline->next->data) == '\0')
	  {
	    delete_line(currline->next);
	    break;
	  }
	  p = currline;
	  while (!join(p))
	  {
	    p = p->next;
	    if (p == NULL)
	    {
	      indigestion(2);
	      abort_bbs();
	    }
	  }
	  break;
	}
	currpnt--;
	delete_char();
	break;

      case Ctrl('D'):
      case KEY_DEL:		/* delete current character */
	if (currline->len == currpnt)
	{
	  textline *p = currline;

	  while (!join(p))
	  {
	    p = p->next;
	    if (p == NULL)
	    {
	      indigestion(2);
	      abort_bbs();
	    }
	  }
	  redraw_everything = YEA;
	  break;
	}
	delete_char();
	break;

      case Ctrl('Y'):		/* delete current line */
	currline->len = currpnt = 0;

      case Ctrl('K'):		/* delete to end of line */
	if (currline->len == 0)
	{
	  textline *p = currline->next;

	  if (!p)
	  {
	    p = currline->prev;
	    if (!p)
	    {
	      break;
	    }
	    if (curr_window_line > 0)
	    {
	      curr_window_line--;
	      currln--;
	    }
	  }
	  if (currline == top_of_win)
	    top_of_win = p;
	  delete_line(currline);
	  currline = p;
	  redraw_everything = YEA;
	  break;
	}

	if (currline->len == currpnt)
	{
	  textline *p = currline;

	  while (!join(p))
	  {
	    p = p->next;
	    if (p == NULL)
	    {
	      indigestion(2);
	      abort_bbs();
	    }
	  }
	  redraw_everything = YEA;
	  break;
	}
	currline->len = currpnt;
	currline->data[currpnt] = '\0';
      }

      if (currln < 0)
	currln = 0;
      if (curr_window_line < 0)
      {
	curr_window_line = 0;
	if (!top_of_win->prev)
	{
	  indigestion(6);
	}
	else
	{
	  top_of_win = top_of_win->prev;
	  rscroll();
	}
      }
      if (curr_window_line == b_lines)
      {
	curr_window_line = t_lines - 2;
	if (!top_of_win->next)
	{
	  indigestion(7);
	}
	else
	{
	  top_of_win = top_of_win->next;
	  move(b_lines, 0);
	  clrtoeol();
	  scroll();
	}
      }
    }
    edit_margin = currpnt < SCR_WIDTH - 1 ? 0 : currpnt / 72 * 72;

    if (!redraw_everything)
    {
      if (edit_margin != last_margin)
      {
	last_margin = edit_margin;
	redraw_everything = YEA;
      }
      else
      {
	move(curr_window_line, 0);
	clrtoeol();
	edit_outs(&currline->data[edit_margin]);
	edit_msg();
      }
    }
  }
}
