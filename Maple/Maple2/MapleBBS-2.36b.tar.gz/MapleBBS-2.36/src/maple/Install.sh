#! /bin/sh

BBS_HOME=/home/bbs

echo "This script will install the whole BBS to ${BBS_HOME}..."
echo -n "Press <Enter> to continue ..."
read ans

echo "Setup bbs directory tree ....."
( cd ../../sample/bbs; tar cf - .??* * ) | ( cd ${BBS_HOME}; tar xf - )
