
#include <stdio.h>
#include <string.h>

#include "config.h"

char            _ANSI_BUF[400];
char            ANSI_BUF[4000];
int             ANSI_IDX = 0;

void
ansi_buf(int count)
{
	if ((count + ANSI_IDX) >= 4000) {
		ansi_flush();
	}
	strcpy(&ANSI_BUF[ANSI_IDX], _ANSI_BUF);
	ANSI_IDX += count;
}

void
ansi_flush(void)
{
	if (ANSI_IDX != 0) {
		printf("%s\033[37;40;0m", ANSI_BUF);
		ANSI_BUF[0] = '\0';
		ANSI_IDX = 0;
	}
	fflush(stdout);
}
