
#include <stdio.h>
#include <stdlib.h>

#include "config.h"

void
Welcome(void)
{

	char            buffer[80];
	int             i;
	extern FILE    *fp;
	extern long     connect_time, idle_time, now_time;

	ansi_clear;

	ansi_print_xy(0, 0, "1;37", Header1);
	idle_time += time(NULL) - now_time;

	ansi_print_xy(0, 54, "34;1", "�z�w�w�w�w�w�w�w�w�w�w�{");
	ansi_print_xy(1, 54, "34;1", "�x�o�b�ɶ��G     ���� �x");
	ansi_print_xy(2, 54, "34;1", "�x�s�u�ɶ��G     ���� �x");
	ansi_print_xy(3, 54, "34;1", "�|�w�w�w�w�w�w�w�w�w�w�}");
	sprintf(buffer, "%3d", idle_time / 60);
	ansi_print_xy(1, 67, "31;1", buffer);
	sprintf(buffer, "%3d", connect_time / 60);
	ansi_print_xy(2, 67, "31;1", buffer);

	i = 1;
	fseek(fp, 0L, SEEK_SET);
	while (fgets(buffer, Rec_Len, fp) != NULL) {
		buffer[strlen(buffer) - 1] = '\0';
		if ((buffer[0] == '*') && (!strncmp(&buffer[3], "Banner", 6)))
			ansi_print_xy(++i, 0, "1;32", &buffer[11]);
	}

	ansi_gotoxy(i + 2, 0);

	ansi_flush();
	fclose(fp);

	exit(0);
}

void
Bye(void)
{
	alarm(0);
	clear();
	refresh();
	endwin();
	Welcome();
}
