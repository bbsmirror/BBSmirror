
#include <signal.h>

#if defined(ULTRIX_ver) || defined(FreeBSD_ver_current)
#include <sys/types.h>
#endif

#include <sys/stat.h>
#include <time.h>

#include "config.h"


void
Saver(void)
{

	extern char     mailbox[35];
	extern int      mailbox_size;
	struct stat     now_status;

	long int        now;
	struct tm      *tmstruct;
	static char     buffer[25];
	static char     mailmsg[25];
	static          show;

	show = 0;
	nodelay(stdscr, TRUE);
	while (getch() == ERR) {
		time(&now);
		tmstruct = localtime(&now);

		sprintf(buffer, "  [19%.2d/%02d/%02d %.2d:%.2d]", tmstruct->tm_year,
			tmstruct->tm_mon + 1, tmstruct->tm_mday,
			tmstruct->tm_hour, tmstruct->tm_min);

		if (tmstruct->tm_sec == 0) {
			ansi_clear;
			if (tmstruct->tm_min == 0)
				printf("\007");
			if ((show != 1) && (stat(mailbox, &now_status) >= 0)
			    && (mailbox_size < now_status.st_size)) {
				sprintf(mailmsg, "  [%.2d:%.2d] �z���s�H��", tmstruct->tm_hour, tmstruct->tm_min);
				show = 1;
			}
			if ((show == 1) && (!(tmstruct->tm_min % MAILCHK)))
				printf("\007");
		}
		ansi_print_xy((tmstruct->tm_min + 1) % (LINES - 1), tmstruct->tm_sec, "1;32", buffer);
		if (show == 1)
			ansi_print_xy((tmstruct->tm_min) % (LINES - 1), tmstruct->tm_sec, "1;31", mailmsg);

		ansi_flush();
		sleep(1);
	}
	nodelay(stdscr, FALSE);
}
