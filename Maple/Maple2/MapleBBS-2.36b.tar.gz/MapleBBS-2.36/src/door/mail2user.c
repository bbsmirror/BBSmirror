
#include <stdio.h>
#include "config.h"

void
Mail2user(char c)
{
	extern struct BBS bbs[BBS_Max];
	extern char     Mailer[35];

	char            buffer[30];
	char            command[80];
	char            subject[60];
	char           *edit_name;

	umask(077);

	ansi_clear;

	sprintf(command, "�`�N: �ϥΥ��\\��e�Х��T�w %s BBS ���䴩 Internet Mail to User\n\n", bbs[c].name);
	ansi_print("1;31", command);

	sprintf(command, "\n�п�J�z�n�H�� %s BBS �������@��ϥΪ�\n", bbs[c].name);
	ansi_print("1;32", command);

	do {
		ansi_print("1;36", "\nMail to: ");
		ansi_flush();
		fgets(buffer, 20, stdin);
		buffer[strlen(buffer) - 1] = '\0';
		ansi_print("1;33", "\n�T�w�H�� ");
		ansi_print("1;35", buffer);
		ansi_print("1;33", " ��? [Y] ");
		ansi_flush();
		fgets(command, 20, stdin);

	} while ((command[0] != '\n') && (command[0] != 'y')
		 && (command[0] != 'Y'));

	ansi_print("1;37", "\n�H�󪺼��D�O: ");
	ansi_flush();
	fgets(subject, 59, stdin);
	subject[strlen(subject) - 1] = '\0';
	edit_name = Edit();

	/* Mail post */
	if (!isdigit(bbs[c].hostname[0]))
		sprintf(command, "%s -s \"%s\" %s.bbs@%s < %s", Mailer, subject, buffer, bbs[c].hostname, edit_name);
	else
		sprintf(command, "%s -s \"%s\" %s.bbs@[%s]. < %s", Mailer, subject, buffer, bbs[c].hostname, edit_name);

	system(command);

	Delete();
}
