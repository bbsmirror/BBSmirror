
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>
#include <time.h>
#include <pwd.h>

#include "config.h"

struct BBS      bbs[BBS_Max];
int             hosttype;
unsigned char   x[BBS_Max];
unsigned char   y[BBS_Max];
int             H, n;
char            Username[15];
char            mailbox[35];
struct stat     mailbox_status;
int             mailbox_size;
char            Editor[35];
char            Mailer[35];
char            Gopher[35];
char            Ftp[35];
char            Browser[35];
char            Telnet[40];
char            cport[6];
char            label[3];
char            symbol[54];
char            Title[10][20];
char            command[120];
FILE           *fp;
long            now;
long            now_time;
long            idle_time;
long            connect_time;
long            last_key_time;

void            Clock(int);

void
Info(int c)
{

	if ((hosttype == Host_GOPHER) && (Gopher[0] != '\0'))
		strcpy(command, Gopher);
	else if ((hosttype == Host_WWW) && (Browser[0] != '\0'))
		strcpy(command, Browser);
	else if (hosttype == Host_FTP) {
		strcpy(command, Ftp);
	} else
		strcpy(command, Telnet);

	strcat(command, " ");
	strcat(command, bbs[c].hostname);

	sprintf(cport, "%-4d", bbs[c].port);

	if (bbs[c].port != 23) {
		strcat(command, " ");
		strcat(command, cport);
	}
}


void
VerErr(void)
{
	printf(Header1 "\n");
	printf("�����귽�{������ɤ��s�b, �{���������!\n");
	printf("�г]�k�b�A���t�Φw�ˤ@�Ӹ����, ���{���j�M����ɪ����Ǭ�:\n\n");
	printf("  -  ~/." CFGFILE "\n");
	printf("  -  /usr/local/etc/" CFGFILE "\n");
#if defined(BBSDATA)
	printf("  -  " BBSDATA "\n");
#endif
	printf("\n���d�߸���ɮ榡, �а��� \"bbs -f\"\n\n");
}

void
Init(void)
{
	doupdate();
	Clock(0);
}

void
Leave(void)
{
	ansi_clear;
	ansi_flush();
	alarm(0);
	wnoutrefresh(stdscr);
	endwin();
}

int             s, secs;

char            helpbar1[] = "[Ctrl-D] ����  [Enter] �s�u  [Space] ��L�ؿ�  [?] �D�U";
char            helpbar2[] = "[Enter] �s�u   BBS- [Tab] Mailpost  [Ctrl-U] �H�H";
char            helpbar3[] = "[?] �D�U  [/] ��ø�ù�  [1-9] �䥦�ؿ�  [Ctrl-A] �H�H���@��";
int             showbar = 2;
char           *helpbar[] = {helpbar1, helpbar2, helpbar3};

char            divide_line[] = "�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w";
void
Redraw(void)
{

	ansi_clear;
	DrawBox2(0, 1, COLS - 1, LINES - 2);
	ansi_print_xy(LINES - 5, 2, "0;37", divide_line);
	MainMenu(s, secs);
	PutTitle(s, secs);
	/* HelpBar(36, helpbar[showbar]); */
	Clock(0);
	Menu();
	ansi_flush();
}

int
Ask(char *msg)
{
	char            filename[25];
	FILE           *fp;

	if (!strncmp(Username, "bbs", 3)) {
		HelpBar("1;31", "[!] BBS �ϥΪ̵L�k�ϥΦ����\\��, �Ъ��� mail ���@��");
		return (0);
	} else {
		sprintf(filename, "/tmp/.bbs.ask.%d", getpid());

		if ((fp = fopen(filename, "w")) == NULL)
			return;
		fprintf(fp, "BBS " BBSvers "  " BBSdate "  Request: %s\n", msg);

		fclose(fp);
		sprintf(command, "%s -s \"Request %s\" cdsheen@csie.nctu.edu.tw < %s", Mailer, msg, filename);
		system(command);
		unlink(filename);
		return (1);
	}
}

void
Saver(void)
{

	struct stat     now_status;

	long int        now;
	struct tm      *tmstruct;
	static char     buffer[25];
	static char     mailmsg[25];
	static          show;

	show = 0;
	nodelay(stdscr, TRUE);
	while (getch() == ERR) {
		time(&now);
		tmstruct = localtime(&now);

		sprintf(buffer, "  [19%.2d/%02d/%02d %.2d:%.2d]", tmstruct->tm_year,
			tmstruct->tm_mon + 1, tmstruct->tm_mday,
			tmstruct->tm_hour, tmstruct->tm_min);

		if (tmstruct->tm_sec == 0) {
			ansi_clear;
			if (tmstruct->tm_min == 0)
				printf("\007");
			if ((show != 1) && (stat(mailbox, &now_status) >= 0)
			    && (mailbox_size < now_status.st_size)) {
				sprintf(mailmsg, "  [%.2d:%.2d] �z���s�H��", tmstruct->tm_hour, tmstruct->tm_min);
				show = 1;
			}
			if ((show == 1) && (!(tmstruct->tm_min % MAILCHK)))
				printf("\007");
		}
		ansi_print_xy((tmstruct->tm_min + 1) % (LINES - 1), tmstruct->tm_sec, "1;32", buffer);
		if (show == 1)
			ansi_print_xy((tmstruct->tm_min) % (LINES - 1), tmstruct->tm_sec, "1;31", mailmsg);

		ansi_flush();
		sleep(1);
	}
	nodelay(stdscr, FALSE);
	time(&last_key_time);
}


void
Clock(int ignore)
{
	struct stat     now_status;
	long int        now;
	struct tm      *tmstruct;
	char            buffer[25];

	time(&now);


	tmstruct = localtime(&now);

	if ((stat(mailbox, &now_status) >= 0)
	    && (mailbox_size < now_status.st_size))
		ansi_print_xy(LINES - 1, 69, "1;31", "\033[5m\007�z���s�H��");

	sprintf(buffer, "19%02d/%02d/%02d  %.2d:%.2d",
		tmstruct->tm_year, tmstruct->tm_mon + 1, tmstruct->tm_mday, tmstruct->tm_hour, tmstruct->tm_min);

	ansi_print_xy(0, COLS - strlen(buffer), "1;33", buffer);

	if ((tmstruct->tm_min == 0) && (tmstruct->tm_sec < 15))
		ansi_print_xy(LINES - 1, 69, "1;31", "\033[5m\007  ���I����");
	else if (tmstruct->tm_min == 1)
		ansi_print_xy(LINES - 1, 69, "1;31", "          ");

	HelpBar("1;36", helpbar[showbar = (++showbar) % 3]);

	signal(SIGALRM, Clock);
	alarm(10);

}


int
main(int argc, char *argv[])
{

	int             c;
	int             i, j, key, callkey;
#if defined(X_BUTTON)
	int             xmouse, xcol, xrow;
#endif
	char            buffer[Rec_Len + 1];
	long            loc[11];

	struct passwd  *pws;
	char           *ptr;

	now_time = time(NULL);
	idle_time = connect_time = 0;

	strcpy(label, "?.");
	strcpy(symbol, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");

	if ((pws = getpwuid(getuid())) == NULL) {
		strcpy(command, (char *) getenv("HOME"));
		strcpy(Username, (char *) getenv("USER"));
	} else {
		strcpy(command, pws->pw_dir);
		strcpy(Username, pws->pw_name);
	}

	sprintf(mailbox, MAILBOX1 "%s", Username);

	if (stat(mailbox, &mailbox_status) >= 0)
		mailbox_size = mailbox_status.st_size;
	else {
		sprintf(mailbox, MAILBOX2 "%s", Username);
		if (stat(mailbox, &mailbox_status) >= 0)
			mailbox_size = mailbox_status.st_size;
		else
			mailbox_size = 0;
	}

	if ((ptr = (char *) getenv("EDITOR")) != NULL)
		strcpy(Editor, ptr);
	else
		Editor[0] = '\0';

	Gopher[0] = '\0';

	strcat(command, "/.");
	strcat(command, CFGFILE);

	if ((fp = fopen(command, "r")) == NULL)
		if ((fp = fopen(DEF_SYS_BBSDATA, "r")) == NULL)
#if defined(BBSDATA)
			fp = fopen(BBSDATA, "r");
#else
			;
#endif

	if (fp == NULL) {
		VerErr();
		exit(2);
	}
	i = secs = 0;
	j = 1;
	Gopher[0] = Browser[0] = Ftp[0] = '\0';
	while (fgets(buffer, Rec_Len, fp) != NULL) {
		switch (buffer[0]) {
		case '*':
			buffer[strlen(buffer) - 1] = '\0';
			if ((!strncmp(&buffer[3], "Editor", 6))
			    && (Editor[0] == '\0'))
				sscanf(buffer, "* [Editor] %s", Editor);
			else if (!strncmp(&buffer[3], "Telnet", 6))
				sscanf(buffer, "* [Telnet] %s", Telnet);
			else if (!strncmp(&buffer[3], "Mailer", 6))
				sscanf(buffer, "* [Mailer] %s", Mailer);
			else if (!strncmp(&buffer[3], "Gopher", 6))
				sscanf(buffer, "* [Gopher] %s", Gopher);
			else if (!strncmp(&buffer[3], "FTP", 3))
				sscanf(buffer, "* [FTP] %s", Ftp);
			else if (!strncmp(&buffer[3], "Browser", 7))
				sscanf(buffer, "* [Browser] %s", Browser);
			else if (!strncmp(&buffer[3], "Title", 5))
				strcpy(Title[j - 1], &buffer[10]);
			else if (!strncmp(&buffer[3], "Section", 7))
				loc[j++] = loc[0];
			/*
			 * else if (!strncmp(&buffer[3], "End", 3)) {
			 * loc[j++] = ftell(fp); s = 1; }
			 */
			break;
		}
		loc[0] = ftell(fp);
	}

	if ((Editor[0] == '/') && (stat(Editor, &mailbox_status) < 0)) {
		printf("�ˬd�ҨϥΪ� editor : %s\n"
		       "���~: �䤣�� editor - �Ч��]�w�ɤ� [Editor] �@��\n"
		       "      �Ϊ̭ק�A�� EDITOR �����ܼ�\n", Editor);
		exit(1);
	}
	if (stat(Mailer, &mailbox_status) < 0) {
		printf("���~: �䤣�� `mail' - �Ч��]�w�ɤ� [Mailer] �@��\n");
		exit(1);
	}
	if (stat(Telnet, &mailbox_status) < 0) {
		printf("���~: �䤣�� `telnet' - �Ч��]�w�ɤ� [Telnet] �@��\n");
		exit(1);
	}
	if ((Ftp[0] != '\0') && (stat(Ftp, &mailbox_status) < 0)) {
		printf("���~: �䤣�� `ftp' - �Ч��]�w�ɤ� [FTP] �@��\n");
		exit(1);
	}
	if (secs == 0)
		secs = j - 1;

	callkey = 0;
	s = 1;
	if (argc > 1) {

		if (argv[1][0] == '-') {
			if (argv[1][1] == 'f') {
				Ask("Format");
				printf("\n�z�N�b�@�������������ɮ榡�˥�, ���ˬd�z���H�c\n\n");
			} else if (argv[1][1] == 's') {
				Ask("Source");
				printf("\n�z�N�b�@�����������l�{��, ���ˬd�z���H�c\n\n");
			} else if (argv[1][1] == 'z') {
				callkey = 1;
				key = '!';
			} else {
				printf(Header1 "\n\n");
				if (argv[1][1] != 'h')
					printf("[���~] �{�����{�Ѫ��Ѽ�:  `%s'\n\n", argv[1]);
				printf("Usage: bbs [-f] [-s] [-h] [-z] [1-9[a-Z]]\n\n");
			}
			if (!callkey)
				exit(1);
		} else if (isdigit(argv[1][0])) {
			s = argv[1][0] - '0';
			if (s > secs)
				s = 1;
			n = read_section(loc[s]);
			if (argv[1][1] == '\0')
				goto quickmenu;
			else if (argv[1][1] >= 'a')
				c = argv[1][1] - 'a';
			else if ((argv[1][1] <= 'Z') && (argv[1][1] >= 'A'))
				c = 26 + argv[1][1] - 'A';
			else
				c = 0;

			if (c >= n)
				c = 0;

			Info(c);

			ansi_clear;
			ansi_print_xy(0, 0, "1;37", Header1 "\n\n");
			sprintf(buffer, "o �s��: %s (%s)\n", bbs[c].name, bbs[c].hostname);
			ansi_print("1;32", buffer);
			ansi_print("1;32", "o �s���W��, �Ы� Ctrl-C ���}\n\n");
			ansi_flush();
			idle_time += time(NULL) - now_time;
			now_time = time(NULL);
			system(command);
			connect_time += time(NULL) - now_time;
			now_time = time(NULL);
			Welcome();
		}
	}
quickmenu:

	n = read_section(loc[s]);

	time(&last_key_time);

	initscr();
	cbreak();
	nonl();
	noecho();
	keypad(stdscr, TRUE);
	refresh();

	signal(SIGQUIT, Bye);	/* Ctrl-\ */
	signal(SIGINT, Bye);	/* Ctrl-C */
	signal(SIGTERM, Bye);	/* Terminate */
	signal(SIGTSTP, SIG_IGN);	/* Ctrl-Z */
	signal(SIGALRM, Clock);

	Clock(0);

	DrawBox2(0, 1, COLS - 1, LINES - 2);
	ansi_print_xy(LINES - 5, 2, "0;37", divide_line);
	MainMenu(s, secs);
	PutTitle(s, secs);
	/* HelpBar(36, helpbar[showbar]); */

	H = LINES - 7;
	Menu();

	c = 0;
	do {
		ansi_print_xy(LINES - 4, 2, "1;37",
			"���:                 ���W:                     ");
		ansi_print_xy(LINES - 3, 2, "1;37",
			      "�s��:                                                                      ");
		/* ansi_print_xy(x[c], y[c] + 2, "3;33;44", bbs[c].name); */
		ansi_print_xy(x[c], y[c] + 2, "1;3;33;44", bbs[c].name);

		ansi_print_xy(LINES - 4, 8, "1;33", bbs[c].name);
		ansi_print_xy(LINES - 4, 30, "1;33", bbs[c].alias);

		ansi_print_xy(LINES - 3, 8, "1;33", bbs[c].hostname);
		if (bbs[c].port != 23) {
			sprintf(command, " %d", bbs[c].port);
			ansi_print("1;35", command);
		}
		Info(c);

		ansi_flush();
		if (callkey == 0)
			key = getch();
		callkey = 0;
		if (key != ERR)
			time(&last_key_time);
		else {
			time(&now);
			if (now - last_key_time >= SAVER_ACT_TIME) {
				key = '!';
			}
		}

		ansi_print_xy(x[c], y[c] + 2, "0;37", bbs[c].name);
		ansi_flush();
		switch (key) {
		case 27:
			HelpBar("1;35", "�A���F [Esc] ��, �Y�n���}�ЦA���@�� ..");
			ansi_flush();
			key = getch();
			if ((key == 'O') || (key == '['))
				key = getch();
			callkey = 1;
			if (key != 27) {
				switch (key) {
				case 'A':	/* Up */
				case 'i':
					key = KEY_UP;
					break;
				case 'B':	/* Down */
					key = KEY_DOWN;
					break;
				case 'C':	/* Right */
					key = KEY_RIGHT;
					break;
				case 'D':	/* Left */
					key = KEY_LEFT;
					break;
				case 'I':	/* ansi  PgUp */
					/* case 'V':	 at386 PgUp */
					/* case 'S':	 97801 PgUp */
					/* case 'v':	 emacs style */
					key = 32;
					break;
				case 'G':	/* ansi  PgDn */
					/* case 'U':	 at386 PgDn */
					/* case 'T':	 97801 PgDn */
					key = 127;
					break;
				case 'H':	/* at386  Home */
					key = '^';
					break;
				case 'w':
				case 'F':	/* ansi   End */
					/* case 'Y':	 at386  End */
					key = '$';
					break;
				case '5':	/* vt200 PgUp */
					key = 127;
					getch();
					break;
				case '6':	/* vt200 PgDn */
					key = 32;
					getch();
					break;
				case '1':	/* vt200 Home */
					key = '^';
					getch();
					break;
				case '4':	/* vt200 End */
					key = '$';
					getch();
					break;
#if defined(X_BUTTON)
				case 'M':	/* xterminal button press */
					xmouse = getch() - ' ';	/* button */
					xcol = getch() - '!';	/* column */
					xrow = getch() - '!';	/* row */
					break;
#endif
				default:
					callkey = 0;
				}

			} else {
				key = 4;	/* One more Esc to QUIT */
			}
			HelpBar("1;36", helpbar[showbar]);
			break;
		case KEY_LEFT:
			c -= H;
			if (c < 0)
				c = c + H * (int) ((n - 1) / H + 1);
			if (c >= n)
				c -= H;
			break;
		case KEY_UP:
			if (c > 0)
				c--;
			else
				c = n - 1;
			break;
		case KEY_RIGHT:
			c += H;
			if (c >= n)
				c = c % H;
			break;
		case KEY_DOWN:
			c = (c + 1) % n;
			break;
		case '^':
			c = 0;
			break;
		case '$':
		case 273:
			c = n - 1;
			break;
		case 32:	/* Space */
		case 338:	/* xterm PgDn */
			s = (s % secs) + 1;

			n = read_section(loc[s]);
			if (c >= n)
				c = n - 1;
			Redraw();
			break;
		case 127:	/* Backspace */
		case 339:	/* xterm PgDn */
			if (s-- == 1)
				s = secs;

			n = read_section(loc[s]);
			if (c >= n)
				c = n - 1;
			Redraw();
			break;
		case '?':
			alarm(60);
			Help();
			alarm(30);
		case '/':
			Redraw();
			break;
		case '!':
			alarm(0);
#if defined(SWITCH_OFF_INPUT_LINE)
			printf("\033iM;");
#endif
			ansi_clear;
			ansi_flush();
			Saver();
#if defined(SWITCH_OFF_INPUT_LINE)
			printf("\033iMim;");
#endif
			Redraw();
			break;
		case '\r':
		case 1943:	/* IBM AIX */
			Leave();
			ansi_print_xy(0, 0, "1;37", Header1 "\n\n");
			sprintf(buffer, "o �s��: %s (%s)\n", bbs[c].name, bbs[c].hostname);
			ansi_print("1;32", buffer);
			ansi_print("1;32", "o �s���W��, �Ы� Ctrl-C ���}\n\n");

			ansi_flush();
			idle_time += time(NULL) - now_time;
			now_time = time(NULL);
			system(command);
			connect_time += time(NULL) - now_time;
			now_time = time(NULL);
			Init();
			Redraw();
			break;
		case '\t':
		case 16:	/* Ctrl-P */
			if (hosttype == Host_BBS) {
				Leave();
				MailPost(c);
				Init();
				Redraw();
				HelpBar("1;31", "Mailpost - �H��w�g�H�X");
			}
			break;
		case 21:	/* Ctrl-U */
			if (hosttype == Host_BBS) {
				Leave();
				Mail2user(c);
				Init();
				Redraw();
				HelpBar("1;31", "�H��w�g�H�X�����������ϥΪ�");
			}
			break;
		case 22:	/* Ctrl-V */
			HelpBar("1;31", "�� �쪩: " BBSfirst "  ����: " BBSdate " (" BBSvers ") ��");
			break;
		case 2:	/* Ctrl-B */
			if (Ask("Source"))
				HelpBar("1;31", "[���o��l�{��] �Ƥ������z�N���짹�㪺��l�{��");
			break;
		case 6:	/* Ctrl-F */
			if (Ask("Format"))
				HelpBar("1;31", "[�d�߸���ɮ榡] �Ƥ������z�N���짹�㪺����ɮ榡");
			break;
		case 1:	/* Ctrl-A */
			Leave();
			Mail2author();
			Init();
			Redraw();
			HelpBar("1;31", "�H��w�g�e�X���@��");
			break;
		}
		if ((key <= '9') && (key >= '1') && (s != (key - '0'))) {
			s = key - '0';
			if (s > secs)
				s = 1;
			n = read_section(loc[s]);
			if (c >= n)
				c = n - 1;
			Redraw();
		}
		if ((key <= 'z') && (key >= 'A')) {
			if (key >= 'a')
				c = key - 'a';
			else if ((key <= 'Z') && (key >= 'A'))
				c = 26 + key - 'A';
			if (c >= n)
				c = 0;
		}
	} while (key != 4);


	Leave();

	Welcome();
}


/* End of `bbs.c' - cdsheen@csie.nctu.edu.tw */
