#include "bbs.h"
#include "visio.h"
#include <stdlib.h>
#define LINE_ALLOC	0x01

typedef struct viewer_rec {
    char **headers;
    short *headerlen;
    char *lines[MAXPAGES*25];
    short linelen[MAXPAGES*25];
    char linemask[MAXPAGES*25];
    int nlines;
} viewer_t;

int static
viewer_out(viewer_t *v, int curline)
{
    int i;
    char buf[ANSILINELEN];
    for(i=0;i<b_lines && curline+i<v->nlines;++i) {
	if (v->linelen[curline+i] > ANSILINELEN - 2)
	    v->linelen[curline+i] = ANSILINELEN - 2;
	str_ncpy(buf, v->lines[curline+i], v->linelen[curline+i]+1);
	strcpy(buf+v->linelen[curline+i], "\n");
	outx(buf);
    }
    return i;
}

int
viewer(viewer_t *v)
{
    int curline = 0, key, exit_flag = 0, draw_flag = 1, last_show = 0;
    char hunt[32], lunt[32], buf[ANSILINELEN];
    hunt[0] = lunt[0] = 0;
    do {
	if(draw_flag) {
	    clear();
	    last_show = viewer_out(v, curline);
	    draw_flag = 0;
	}
	if(curline + last_show == v->nlines) {
	    key = 0;
	    break;
	}
	move(b_lines, 0);
	prints("\033[0;34;46m �s�� P.%d(%d%%) \033[31;47m (h)\033[30m�D�U \033[31m[PgUp][PgDn][0][$]\033[30m���� \033[31m(/n)\033[30m�j�M \033[31m(C)\033[30m�Ȧs \033[31m��(q)\033[30m���� \033[m", 0, ((curline+last_show) * 100) / v->nlines);
	switch(key = vkey()) {
	case ' ':
	case '\n':
	case KEY_PGDN:
	case KEY_RIGHT:
	case Ctrl('F'):
	    curline = BMAX(0,BMIN(curline+last_show, v->nlines-b_lines));
	    prints("total lines %d, curline = %d\n", v->nlines, curline);
	    draw_flag = 1;
	    break;
	case KEY_PGUP:
	case KEY_UP:
	case Ctrl('B'):
	    if (curline == 0)
		break;
	    curline = BMAX(0, curline-b_lines);
	    draw_flag = 1;
	    break;
	case KEY_DOWN:
	    scroll();
	    move(b_lines-1, 0);
	    clrtoeol();
	    str_ncpy(buf, v->lines[curline+b_lines], v->linelen[curline+b_lines]+1);
	    strcpy(buf+v->linelen[curline+b_lines], "\n");
	    outx(buf);
	    ++curline;
	    break;
	case KEY_END:
	case '$':
	    curline = BMAX(0, v->nlines - b_lines);
	    draw_flag = 1;
	    break;
	case KEY_HOME:
	case '0':
	    curline = 0, draw_flag = 1;
	    break;
	case 'h':
	case '?':
	    film_out(FILM_MORE, -1);
	    draw_flag = 1;
	    break;
	case '/':
	    if (vget(b_lines, 0, "�j�M�G", hunt, sizeof(hunt), GCARRY))
		str_lower(lunt, hunt);
	case 'n':
	    if (hunt[0]) {
		break;
	    }
	    break;
	case 'C':
/* FIXME: we need to have fpath here */
#if 0
	{
	    int bno;
	    
	    if ((bno = brd_bno(currboard)) >= 0) {
		BRD *brd;
		brd = bshm->bcache + bno;
		
		if (HAS_PERM(PERM_SYSOP) || (!(brd->battr & BRD_NOFORWARD))) {
		    FILE *fp;
		    if ((fp = tbf_open())) {
			f_suck(fp, fpath);
			fclose(fp);
		    }
		}
	    }
	}
#endif
	break;

	case KEY_LEFT:
	case 'q':
	    move(b_lines, 0);
	    clrtoeol();
	    exit_flag = 1;
	    key = 0;
	    break;
	}
    }
    while(!exit_flag);
    return key;
}

static void
viewer_destroy(viewer_t *v)
{
    int i;
    for(i=0;i<v->nlines;++i)
	if(v->linemask[i] & LINE_ALLOC)
	    free(v->lines[i]);
    free(v->headers);
    free(v->headerlen);
}

static char *
header_get(viewer_t *v, int nheaders, char *header)
{
    static char buf[ANSILINELEN];
    int i, len = strlen(header);
    for (i=0;i<nheaders;++i) {
	if (!strncmp(v->headers[i], header, len)) {
	    str_ncpy(buf, v->headers[i]+len+2, v->headerlen[i]-len-2+1);
	    return buf;
	}
    }
    return NULL;
}

static void
header_filter(viewer_t *v)
{
    int nheaders, i, n;
    char *buf;
    static char *required[] = {"Subject", "Date", "From", NULL};
    static char *head[] = {"Subject", "Date"};
    static char *chead[] = {"���D", "�ɶ�"};
    for(nheaders=0;nheaders < v->nlines && *v->lines[nheaders] != '\n'; ++nheaders)
	if (!strchr(v->lines[nheaders], ':'))
	    return;
    v->headers = (char **)malloc(sizeof(char *)*nheaders);
    v->headerlen = (short *)malloc(sizeof(short)*nheaders);
    for(i=0;i<nheaders;++i)
	v->headers[i] = v->lines[i], v->headerlen[i] = v->linelen[i];

    for(i=0;required[i];++i)
	if (!header_get(v, nheaders, required[i]))
	    return;
    buf = (char *)malloc(ANSILINELEN);
    n = sprintf(buf, "\033[47;34m %s \033[44;37m %-52.52s\033[47;34m %s \033[44;37m ", "�@��", header_get(v, nheaders, "From"), "�ݪO");
    v->linelen[0] = n + sprintf(buf+n, "%-12s\033[m", header_get(v, nheaders, "Board"));
    v->lines[0] = buf;
    v->linemask[0] |= LINE_ALLOC;
    /* XXX: beware the gapgapbird! */
    if (nheaders < 3) {
	int offset = v->nlines - nheaders - 1;
	memmove(&v->lines[4], &v->lines[nheaders+1], offset*sizeof(char *));
	memmove(&v->linelen[4], &v->linelen[nheaders+1], offset*sizeof(short));
	memmove(&v->linemask[4], &v->linemask[nheaders+1], offset*sizeof(char));
	for(i=nheaders;i<4;++i) {
	    v->lines[i] = 0;
	}
	v->nlines += 3 - nheaders;
    }
    for (i=0;i < 2;++i) {
	buf = (char *)malloc(ANSILINELEN);
	v->linelen[i+1] = sprintf(buf, "\033[47;34m %s \033[44;37m %-71.71s\033[m", chead[i], header_get(v, nheaders, head[i]));
	v->lines[i+1] = buf;
	v->linemask[i+1] |= LINE_ALLOC;
    }
    v->linelen[3] = sizeof(MSG_SEPERATOR) - 1;
    v->lines[3] = strdup(msg_seperator);
    v->linemask[3] |= LINE_ALLOC;
    if(nheaders > 3) {
	int offset = v->nlines - nheaders - 1;
	memmove(&v->lines[4], &v->lines[nheaders+1], offset*sizeof(char *));
	memmove(&v->linelen[4], &v->linelen[nheaders+1], offset*sizeof(short));
	memmove(&v->linemask[4], &v->linemask[nheaders+1], offset*sizeof(char));
	for (i=0;i<nheaders - 3;++i) {
	    v->lines[--v->nlines] = 0;
	}
    }
    for (i=0;i<v->nlines;++i) {
        if (v->lines[i][0] == '>' && v->lines[i][1] == ' ') {
	    buf = (char *)malloc(v->linelen[i]+10);
            memcpy(buf, "[36m", 5);
	    memcpy(buf+5, v->lines[i], v->linelen[i]);
	    memcpy(buf+5+v->linelen[i], "[0m", 4);
	}
        else if (!memcmp(v->lines[i], "��", 2)) {
	    buf = (char *)malloc(v->linelen[i]+10);
            memcpy(buf, "[32m", 5);
	    memcpy(buf+5, v->lines[i], v->linelen[i]);
	    memcpy(buf+5+v->linelen[i], "[0m", 4);
	}
	else
	    continue;
	v->lines[i] = buf;
	v->linelen[i] += 9;
	v->linemask[i] |= LINE_ALLOC;
    }
}

/* for compatibility */
int
more(char *fpath, char *footer)
{
    static char *head[] = {"�@��", "���D", "�ɶ�", "���|", "�ӷ�"};
    int sz, cmd;
    viewer_t v;
    char *data = f_map(fpath, &sz), *ptr = data, *end = ptr + sz;
    if(ptr == (char *)-1) {
	prints("%s: %s\n", fpath, strerror(errno));
	return -1;
    }
    memset(&v, 0, sizeof(v));
    while(ptr < end && *ptr) {
	char *s = strchr(ptr, '\n');
	int len = ((s)?(int)s:(int)end)-(int)ptr;
	v.linelen[v.nlines] = len;
	v.lines[v.nlines++] = ptr;
	if(!s) break;
	ptr += len+1;
    }
    /* KLUDGE: compat for old style article body */
    if (!strncmp(data, "�@��:", 5)) {
	int i = 0, line = 0;
	char *buf, *ptr, word[ANSILINELEN];
	if (!memcmp(data, str_author1, LEN_AUTHOR1)) {
	    line = 3;
	    str_ncpy(word, v.lines[0] + LEN_AUTHOR1, v.linelen[0]-LEN_AUTHOR1+1);
	}
	else if (!memcmp(data, str_author2, LEN_AUTHOR2)) {
	    line = 6;
	    str_ncpy(word, v.lines[0] + LEN_AUTHOR2, v.linelen[0]-LEN_AUTHOR2+1);
	}
	buf = (char *)malloc(ANSILINELEN);

	if ((ptr = strstr(word, str_post1)) || 
	    (ptr = strstr(word, str_post2))) {
	    ptr[-1] = ptr[4] = '\0';
	    v.linelen[0] = sprintf(buf, "\033[47;34m %s \033[44;37m%-53.53s\033[47;34m %s \033[44;37m%-13s\033[m", head[0], word, ptr, ptr+5);
	}
	else {
	    v.linelen[0] = sprintf(buf, "\033[47;34m %s \033[44;37m%-53.53s                   \033[m", head[0], word);

	}
	v.lines[0] = buf;
	v.linemask[0] |= LINE_ALLOC;
	for (i=1;i<line && !memcmp(v.lines[i], head[i], 4);++i) {
	    str_ncpy(word, v.lines[i] + 5, v.linelen[i] - 5+1);
	    buf = (char *)malloc(ANSILINELEN);
	    v.linelen[i] = sprintf(buf, "\033[47;34m %s \033[44;37m%-72.72s\033[m", head[i], word);
	    v.linemask[i] |= LINE_ALLOC;
	    v.lines[i] = buf;
	}
	v.linemask[i] |= LINE_ALLOC;
	v.linelen[i] = sizeof(MSG_SEPERATOR) - 1;
	v.lines[i] = strdup(msg_seperator);
    } else if ((ptr = strchr(data, ':')) && ptr < strchr(data, '\n') && ptr[1] == ' '){
	header_filter(&v);
    }
    cmd = viewer(&v);
    viewer_destroy(&v);
    if (footer) {
	if (footer != (char *) -1)
	    outz(footer);
	else
	    outs(str_ransi);
    }
    else {
	move(b_lines, 0);
	clrtoeol();

	vmsg(NULL);
	clear();

    }
    munmap(data, sz);
    return cmd;
}
