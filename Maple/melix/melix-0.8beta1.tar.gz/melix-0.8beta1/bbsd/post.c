/*-------------------------------------------------------*/
/* post.c       ( NTHU CS MapleBBS Ver 2.39 )            */
/*-------------------------------------------------------*/
/* target : bulletin boards' routines		 	 */
/* create : 95/03/29				 	 */
/* update : 96/04/05				 	 */
/*-------------------------------------------------------*/


#define xlog(x)		f_cat("/tmp/b.log", x)


#include "bbs.h"
#include "brh.h"
#include "visio.h"
#include "xover.h"
#include <stdlib.h>

extern BCACHE *bshm;
extern XZ xz[];


extern int cmpchrono();
extern int xo_delete();
extern int xo_uquery();
extern int xo_usetup();
extern int xo_fpath();		/* lkchu.981201 */

#if 1
/* Thor.990220: ��ĥ~�� */
extern int vote_result();
extern int XoVote();
#endif


extern int TagNum;
extern char xo_pool[];
extern char brd_bits[];

/* Thor.990113: imports for anonymous log */
extern char rusername[];

#if 0				/* Thor.990113: �������? */
char *brd_title;
#endif


int
cmpchrono(hdr)
    HDR *hdr;
{
    return hdr->chrono == currchrono;
}


/* ----------------------------------------------------- */
/* ��} innbbsd ��X�H��B�s�u��H���B�z�{��		 */
/* ----------------------------------------------------- */


static void
outgo_post(hdr, board)
    HDR *hdr;
    char *board;
{
    char *fpath, buf[256];

    if (board) {
	fpath = "innd/out.bntp";
    }
    else {
	board = currboard;
	fpath = "innd/cancel.bntp";
    }

    sprintf(buf, "%s\t%s\t%s\t%s\t%s\n",
	    board, hdr->xname, hdr->owner, hdr->nick, hdr->title);
    f_cat(fpath, buf);
}


void
cancel_post(hdr)
    HDR *hdr;
{
    if ((hdr->xmode & POST_OUTGO) &&	/* �~��H�� */
	(hdr->chrono > ap_start - 7 * 86400)) {	/* 7 �Ѥ������� */
	outgo_post(hdr, NULL);
    }
}


static inline void
move_post(hdr, board, by_bm)	/* �N hdr �q currboard �h�� board */
    HDR *hdr;
    char *board;
    int by_bm;
{
    HDR post;
    char folder[80], fpath[80];

    brd_fpath(folder, currboard, fn_dir);
    hdr_fpath(fpath, folder, hdr);

    brd_fpath(folder, board, fn_dir);
    hdr_stamp(folder, HDR_LINK | 'A', &post, fpath);
    unlink(fpath);

    /* �����ƻs trailing data */

    memcpy(post.owner, hdr->owner, TTLEN + 140);

    if (by_bm)
	sprintf(post.title, "%-13s%.59s", cuser.userid, hdr->title);

    rec_add(folder, &post, sizeof(post));
    cancel_post(hdr);
}


/* ----------------------------------------------------- */
/* �o���B�^���B�s��B����峹				 */
/* ----------------------------------------------------- */

#ifdef HAVE_ANONYMOUS
/* Thor.980727: lkchu patch: log anonymous post */
/* Thor.980909: gc patch: log anonymous post filename */
void
log_anonymous(fname)
    char *fname;
{
    char buf[512];
    time_t now = time(0);
    /* Thor.990113: �[�W rusername �M fromhost����Ժ� */
    sprintf(buf, "%s %-13s(%s@%s) %s %s %s\n", Etime(&now), cuser.userid, rusername, fromhost, currboard, ve_title, fname);
    f_cat(FN_ANONYMOUS_LOG, buf);
}
#endif

static int
do_post(title)
    char *title;
{
    /* Thor.1105: �i�J�e�ݳ]�n curredit */
    HDR post;
    char fpath[80], folder[80], *nick, *rcpt;
    int mode;

    if (!(bbstate & STAT_POST)) {
	vmsg("�藍�_�A���ݪO�O��Ū��");
	return XO_FOOT;
    }

    film_out(FILM_POST, 0);

    prints("�o���峹��i %s �j�ݪO", currboard);

    if (!ve_subject(21, title, NULL))
	return XO_HEAD;

    /* ����� Internet �v���̡A�u��b�����o���峹 */
    /* Thor.990111: �S��H�X�h���ݪ�, �]�u��b�����o���峹 */

    if (!HAS_PERM(PERM_INTERNET) || (bbstate & BRD_NOTRAN))
	curredit &= ~EDIT_OUTGO;

#ifdef HAVE_ANONYMOUS
    /* Thor.980727: lkchu�s�W��[²�檺��ܩʰΦW�\��] */
    /* Thor.980909: gc patch: edit �ɰΦW����ñ�W�� */
    if ((bbstate & BRD_ANONYMOUS)
	&& (vans("�A(�p)�Q�n�ʦW��(Y/N)?[Y]") != 'n'))
	curredit |= EDIT_ANONYMOUS;
#endif

    utmp_mode(M_POST);
    fpath[0] = 0;
    if (vedit(fpath, YEA) < 0) {
	unlink(fpath);
	vmsg("����");
	return XO_HEAD;
    }

    /* build filename */

    brd_fpath(folder, currboard, fn_dir);
    hdr_stamp(folder, HDR_LINK | 'A', &post, fpath);

    /* set owner to anonymous for anonymous board */

    rcpt = cuser.userid;
    nick = cuser.username;
    mode = curredit & POST_OUTGO;
    title = ve_title;

#ifdef HAVE_ANONYMOUS
    /* Thor.980727: lkchu�s�W��[²�檺��ܩʰΦW�\��] */
    if (curredit & EDIT_ANONYMOUS) {
	/* nick = rcpt; *//* lkchu: nick ���ର  userid */
	nick = "�q�q�ڬO�� ? ^o^";
	/* Thor.990113: �ȻP�{�sid�V�c */
	/* rcpt = "anonymous"; */
	rcpt = "[���i�D�A]";
	mode = 0;

/* Thor.980727: lkchu patch: log anonymous post */
/* Thor.980909: gc patch: log anonymous post filename */
	log_anonymous(post.xname);

    }
#endif

    post.xmode = mode;
    strcpy(post.owner, rcpt);
    strcpy(post.nick, nick);
    strcpy(post.title, title);

    if (!rec_add(folder, &post, sizeof(HDR))) {
	/* if ((mode) && (!(bbstate & BRD_NOTRAN))) */
	/* Thor.990111: �w�� edit.c ���Τ@check */
	if (mode)
	    outgo_post(&post, currboard);

#if 0000
	mode = post.chrono;
	brh_add(mode - 1, mode, mode + 1);
#endif

	clear();
	outs("���Q�K�X�G�i�A");

	if (bbstate & BRD_NOCOUNT) {
	    outs("�峹���C�J�����A�q�Х]�[�C");
	}
	else {
	    prints("�o�O�z���� %d �g�峹�C", ++cuser.numposts);
	}

	/* �^�����@�̫H�c */

	if (curredit & EDIT_BOTH) {
	    char *msg = "�@�̵L�k���H";
#define	_MSG_OK_	"�^���ܧ@�̫H�c"

	    rcpt = quote_user;
	    if (strchr(rcpt, '@')) {
		if (bsmtp(fpath, title, rcpt, 0) >= 0)
		    msg = _MSG_OK_;
	    }
	    else {
		usr_fpath(folder, rcpt, fn_dir);
		if (hdr_stamp(folder, HDR_LINK, &post, fpath) == 0) {
		    strcpy(post.owner, cuser.userid);
		    strcpy(post.title, title);
		    if (!rec_add(folder, &post, sizeof(post)))
			msg = _MSG_OK_;
		}
	    }
	    outs(msg);
	}
    }
    unlink(fpath);

    vmsg(NULL);

    return XO_INIT;
}


static int
do_reply(hdr)
    HDR *hdr;
{
    curredit = 0;

    switch (vans("�� �^���� (F)�ݪO (M)�@�̫H�c (B)�G�̬ҬO (Q)�����H[F] ")) {
    case 'm':
	mail_reply(hdr);
	*quote_file = '\0';
	return XO_HEAD;

    case 'q':
	/*
	 * Thor: �ѨM Gao �o�{�� bug.. ������ reply�峹�A�o�� Q�����A �M��h
	 * Admin/Xfile�U�H�K��@�ӽs��A �A�N�|�o�{�]�X reply�峹�ɪ��ﶵ�F�C
	 */
	*quote_file = '\0';
	return XO_FOOT;

    case 'b':
	curredit = EDIT_BOTH;
	break;
    }

    /*
     * Thor.1105: ���׬O��i��, �άO�n��X��, ���O�O���i�ݨ쪺,
     * �ҥH�^�H�]��������X
     */
    if (hdr->xmode & (POST_INCOME | POST_OUTGO))
	curredit |= POST_OUTGO;

    strcpy(quote_user, hdr->owner);
    strcpy(quote_nick, hdr->nick);
    return do_post(hdr->title);
}


static int
post_reply(xo)
    XO *xo;
{
    if (bbstate & STAT_POST) {
	HDR *hdr;

	hdr = (HDR *) xo_pool + (xo->pos - xo->top);
	if (!(hdr->xmode & (POST_CANCEL | POST_DELETE))) {
	    hdr_fpath(quote_file, xo->dir, hdr);
	    return do_reply(hdr);
	}
    }
    return XO_NONE;
}


/* ----------------------------------------------------- */
/* �ݪO�\���						 */
/* ----------------------------------------------------- */

#ifdef HAVE_MODERATED_BOARD
extern int XoBM();
#endif


/* ----------------------------------------------------- */


static int post_add();
static int post_body();
static int post_head();		/* Thor: �]�� XoBM �n�� */


#ifdef XZ_XPOST
static int XoXpost();		/* Thor: for XoXpost */
#endif


static int
post_init(xo)
    XO *xo;
{
    xo_load(xo, sizeof(HDR));
    return post_head(xo);
}


static int
post_load(xo)
    XO *xo;
{
    xo_load(xo, sizeof(HDR));
    return post_body(xo);
}


static int
post_attr(fhdr)
    HDR *fhdr;
{
    int mode, attr;

    mode = fhdr->xmode;

    if (mode & POST_CANCEL)
	return 'c';

    if (mode & POST_DELETE)
	return 'd';

    attr = brh_unread(fhdr->chrono) ? 0 : 0x20;
    mode &= (bbstate & STAT_BOARD) ? ~0 : ~POST_GEM;	/* Thor:�@��user�ݤ���G */
    if (mode &= (POST_MARKED | POST_GEM))
	attr |= (mode == POST_MARKED ? 'M' : (mode == POST_GEM ? 'G' : 'B'));
    else if (!attr)
	attr = '+';

    return attr;
}


static void
post_item(num, hdr)
    int num;
    HDR *hdr;
{

#ifdef	HAVE_DECORATE
    prints(hdr->xmode & POST_MARKED ? "%6d \033[1;36m%c\033[m" : "%6d %c", num, post_attr(hdr));
#else
    prints("%6d %c", num, post_attr(hdr));
#endif

    /*
     * Thor.990418: HYL.bbs@Rouge.Dorm10.NCTU.edu.tw patch ���M�btitle >
     * 46�Ӧr�ɵe���|�ñ�...
     */
    hdr_outs(hdr, 47);
    /* hdr_outs(hdr, 46); */
}


static int
post_body(xo)
    XO *xo;
{
    HDR *fhdr;
    int num, max, tail;

    max = xo->max;
    if (max <= 0) {
	if (bbstate & STAT_POST) {
	    if (vans("�n�s�W��ƶܡH(Y/N) [N] ") == 'y')
		return post_add(xo);
	}
	else {
	    vmsg("���ݪO�|�L�峹");
	}
	return XO_QUIT;
    }

    fhdr = (HDR *) xo_pool;
    num = xo->top;
    tail = num + XO_TALL;
    if (max > tail)
	max = tail;

    move(3, 0);
    do {
	post_item(++num, fhdr++);
    } while (num < max);

    clrtobot();
    return XO_NONE;
}


static int			/* Thor: �]�� XoBM �n�� */
post_head(xo)
    XO *xo;
{
    vs_head(currBM, xo->xyz);
    outs("\
[��]���} [��]�\\Ū [^P]�o�� [b]�Ƨѿ� [d]�R�� [V]�벼 [TAB]��ذ� [h]elp\n\
\033[44m  �s��   �� ��  �@  ��       ��  ��  ��  �D                                   \033[m");
    return post_body(xo);
}


static int
post_visit(xo)
    XO *xo;
{
    int ans, row, max;
    HDR *fhdr;

    ans = vans("�]�w�Ҧ��峹 (U)��Ū (V)�wŪ (W)�e�wŪ�᥼Ū (Q)�����H [Q] ");
    if (ans == 'v' || ans == 'u' || ans == 'w') {
	brh_visit(ans = ans == 'u');

	row = xo->top;
	max = xo->max - xo->top + 3;
	if (max > b_lines)
	    max = b_lines;

	fhdr = (HDR *) xo_pool;
	row = 3;
	/* Thor.990430: �s�W �e�wŪ�᥼Ū */
	brh_visit(ans == 'w' ? fhdr[xo->pos - xo->top].chrono : ans == 'u');

	do {
	    move(row, 7);
	    outc(post_attr(fhdr++));
	} while (++row < max);
    }
    return XO_FOOT;
}


int
getsubject(row, reply)
    int row;
    int reply;
{
    char *title;

    title = ve_title;

    if (reply) {
	char *str;

	str = currtitle;
	if (STR4(str) == STR4(STR_REPLY))	/* Thor.980914: ��������I��? */
#if 0
	    if (str[0] == 'R' && str[1] == 'e' && str[2] == ':' && str[3] == ' ')
#endif
	    {
		strcpy(title, str);
	    }
	    else {
		sprintf(title, STR_REPLY "%s", str);
		title[TTLEN] = '\0';
	    }
    }
    else {
	*title = '\0';
    }

    return vget(row, 0, "���D�G", title, TTLEN + 1, GCARRY);
}


static int
post_add(xo)
    XO *xo;
{
    int cmd;

    curredit = EDIT_OUTGO;
    cmd = do_post(NULL);
    return cmd;
}


int
post_cross(xo)
    XO *xo;
{
    char xboard[20], fpath[80], xfolder[80], xtitle[80], buf[80], *dir;
    HDR *hdr, xpost, xhdr;
    int method, rc, tag, locus, battr;
    FILE *xfp;

    if (!cuser.userlevel)
	return XO_NONE;

    /* lkchu.990428: mat patch ���ݪO�|����w�ɡA�ץ�cross post�|�_�u�����D */
    if (bbsmode == M_READA) {
	battr = (bshm->bcache + brd_bno(currboard))->battr;
	if (!HAS_PERM(PERM_SYSOP) && (battr & BRD_NOFORWARD)) {
	    outz("�� ���O�峹���i��K");
	    return -1;
	}
    }

    /* lkchu.981201: �����K */
    tag = AskTag("��K");
    if (tag < 0)
	return XO_FOOT;

    if (ask_board(xboard, BRD_W_BIT,
		  "\n\n[1;33m�ЬD��A�����ݪO�A������K�W�L�T�O�C[m\n\n")
	&& (*xboard || xo->dir[0] == 'u')) {	/* �H�c���i�H��K��currboard */
	if (*xboard == 0)
	    strcpy(xboard, currboard);

	hdr = tag ? &xhdr : (HDR *) xo_pool + (xo->pos - xo->top);
	/* lkchu.981201: �����K */

	method = 1;
	if ((HAS_PERM(PERM_ALLBOARD) || !strcmp(hdr->owner, cuser.userid)) &&
	    (vget(2, 0, "(1)������ (2)����峹�H[1] ", buf, 3, DOECHO) != '2')) {
	    method = 0;
	}

	if (!tag) {		/* lkchu.981201: �������N���n�@�@�߰� */
	    if (method)
		sprintf(xtitle, "[���]%.66s", hdr->title);
	    else
		strcpy(xtitle, hdr->title);

	    if (!vget(2, 0, "���D�G", xtitle, TTLEN + 1, GCARRY))
		return XO_HEAD;
	}

	rc = vget(2, 0, "(S)�s�� (L)���� (Q)�����H[Q] ", buf, 3, LCECHO);
	if (rc != 'l' && rc != 's')
	    return XO_HEAD;

	locus = 0;
	dir = xo->dir;

	battr = (bshm->bcache + brd_bno(xboard))->battr;

	do {			/* lkchu.981201: �����K */
	    if (tag) {
		EnumTagHdr(hdr, dir, locus++);

		if (method)
		    sprintf(xtitle, "[���]%.66s", hdr->title);
		else
		    strcpy(xtitle, hdr->title);
	    }

	    /* if (rc == 'l' || rc == 's') */
	    /* lkchu.981201: ������o���� rc �� 's' or 'l' */
	    {
		/* hdr_fpath(fpath, xo->dir, hdr); */
		xo_fpath(fpath, dir, hdr);	/* lkchu.981201 */
		brd_fpath(xfolder, xboard, fn_dir);

		if (method) {
		    method = hdr_stamp(xfolder, 'A', &xpost, buf);
		    xfp = fdopen(method, "w");

		    strcpy(ve_title, xtitle);
		    strcpy(buf, currboard);
		    strcpy(currboard, xboard);

		    ve_header(xfp);

		    strcpy(currboard, buf);

		    if (hdr->xname[0] == '@')
			sprintf(buf, "%s] �H�c", cuser.userid);
		    else
			strcat(buf, "] �ݪO");
		    fprintf(xfp, "�� ��������� [%s\n\n", buf);

		    f_suck(xfp, fpath);
		    /* ve_sign(xfp); */
		    fclose(xfp);
		    close(method);

		    strcpy(xpost.owner, cuser.userid);
		    /* if (rc == 's') */
		    strcpy(xpost.nick, cuser.username);
		}
		else {
		    hdr_stamp(xfolder, HDR_LINK | 'A', &xpost, fpath);
		    memcpy(xpost.owner, hdr->owner,
			   sizeof(xpost.owner) + sizeof(xpost.nick));
		    memcpy(xpost.date, hdr->date, sizeof(xpost.date));
		    /* lkchu.981201: �������O�d���� */
		}

		/* Thor.981205: �ɥ� method �s��ݪ��ݩ� */
		/* method = (bshm->bcache + brd_bno(xboard))->battr; */

		/* Thor.990111: �b�i�H��X�e, �ncheck user���S����X���v�O? */
		if (!HAS_PERM(PERM_INTERNET) || ( /* method */ battr & BRD_NOTRAN))
		    rc = 'l';

		strcpy(xpost.title, xtitle);

		if (rc == 's' && (!(battr & BRD_NOTRAN)))
		    xpost.xmode = POST_OUTGO;

		rec_add(xfolder, &xpost, sizeof(xpost));

		if (rc == 's' && (!(battr & BRD_NOTRAN)))
		    outgo_post(&xpost, xboard);
	    }
	} while (locus < tag);

	/* Thor.981205: check �Q�઺�����S���C�J����? */
	if ( /* method */ battr & BRD_NOCOUNT) {
	    outs("��������A�峹���C�J�����A�q�Х]�[�C");
	}
	else {
	    /* cuser.numposts++; */
	    cuser.numposts += (tag == 0) ? 1 : tag;	/* lkchu.981201: �n
							 *  */
	    vmsg("�������");
	}
    }
    return XO_HEAD;
}


/* ----------------------------------------------------- */
/* ��Ƥ��s���Gedit / title				 */
/* ----------------------------------------------------- */


static void
post_history(xo, fhdr)
    XO *xo;
    HDR *fhdr;
{
    int prev, chrono, next, pos, top;
    char *dir;
    HDR buf;

    chrono = fhdr->chrono;
    if (!brh_unread(chrono))
	return;

    dir = xo->dir;
    pos = xo->pos;
    top = xo->top;

    if (--pos >= top) {
	prev = fhdr[-1].chrono;
    }
    else {
	if (!rec_get(dir, &buf, sizeof(HDR), pos))
	    prev = buf.chrono;
	else
	    prev = chrono;
    }

    pos += 2;
    if (pos < top + XO_TALL)
	next = fhdr[1].chrono;
    else {
	if (!rec_get(dir, &buf, sizeof(HDR), pos))
	    next = buf.chrono;
	else
	    next = chrono;
    }

    brh_add(prev, fhdr->chrono, next);
}


static int
post_browse(xo)
    XO *xo;
{
    HDR *hdr;
    int cmd, xmode, pos;
    char *dir, fpath[64];

    int key;

    dir = xo->dir;
    cmd = XO_NONE;

    for (;;) {

	pos = xo->pos;
	hdr = (HDR *) xo_pool + (pos - xo->top);
	xmode = hdr->xmode;
	if (xmode & (POST_CANCEL | POST_DELETE))
	    break;

	hdr_fpath(fpath, dir, hdr);

	/* Thor.990204: ���Ҽ{more �Ǧ^�� */
	if ((key = more(fpath, MSG_POST)) < 0)
	    break;

	cmd = XO_HEAD;
	post_history(xo, hdr);
	strcpy(currtitle, str_ttl(hdr->title));

	switch (xo_getch(xo, key)) {
	case XO_BODY:
	    continue;

	case 'y':
	case 'r':
	    if (bbstate & STAT_POST) {
		strcpy(quote_file, fpath);
		if (do_reply(hdr) == XO_INIT)	/* �����\�a post �X�h�F */
		    return post_init(xo);
	    }
	    break;

	case 'm':
	    if ((bbstate & STAT_BOARD) && !(xmode & POST_MARKED)) {
		hdr->xmode = xmode | POST_MARKED;
		rec_put(dir, hdr, sizeof(HDR), pos);
	    }
	    break;
	}
	break;
    }

    return cmd;
}


/* ----------------------------------------------------- */
/* ��ذ�						 */
/* ----------------------------------------------------- */


static int
post_gem(xo)
    XO *xo;
{
    char fpath[32];

    strcpy(fpath, "gem/");
    strcpy(fpath + 4, xo->dir);

    /* Thor.990118: �ݪ��`�ޤ��� GEM_SYSOP */
    XoGem(fpath, "", HAS_PERM(PERM_SYSOP) ? GEM_SYSOP :
	  (bbstate & STAT_BOARD ? GEM_MANAGER : GEM_USER));

    return post_init(xo);
}


/* ----------------------------------------------------- */
/* �ݪO�Ƨѿ�						 */
/* ----------------------------------------------------- */


static int
post_memo(xo)
    XO *xo;
{
    char fpath[64];

    brd_fpath(fpath, currboard, fn_note);
    /* Thor.990204: ���Ҽ{more �Ǧ^�� */
    if (more(fpath, NULL) < 0) {
	vmsg("���ݪO�|�L�u�Ƨѿ��v");
	return XO_FOOT;
    }

    return post_head(xo);
}


static int
post_memo_edit(xo)
    XO *xo;
{
    int mode;
    char fpath[64];

    if (!(bbstate & STAT_BOARD))
	return XO_NONE;

    mode = vans("�Ƨѿ� (D)�R�� (E)�ק� (Q)�����H[E] ");
    if (mode != 'q') {
	brd_fpath(fpath, currboard, fn_note);
	if (mode == 'd') {
	    unlink(fpath);
	}
	else {
	    if (vedit(fpath, NA))	/* Thor.981020: �`�N�Qtalk�����D */
		vmsg(msg_cancel);
	    return post_head(xo);
	}
    }
    return XO_FOOT;
}


static int
post_switch(xo)
    XO *xo;
{
    int bno;
    BRD *brd;
    char bname[16];

    if ((brd = ask_board(bname, BRD_R_BIT, NULL))) {
	if (*bname && ((bno = brd - bshm->bcache) >= 0)) {
	    XoPost(bno);
	    return XZ_POST;
	}
    }
    else {
	vmsg(err_bid);
    }
    return post_head(xo);
}


/* ----------------------------------------------------- */
/* �\��Gtag / copy / forward / download		 */
/* ----------------------------------------------------- */


static int
post_tag(xo)
    XO *xo;
{
    HDR *hdr;
    int tag, pos, cur;

    pos = xo->pos;
    cur = pos - xo->top;
    hdr = (HDR *) xo_pool + cur;

#ifdef XZ_XPOST
    if (xo->key == XZ_XPOST)
	pos = hdr->xid;
#endif

    if ((tag = Tagger(hdr->chrono, pos, TAG_TOGGLE))) {
	move(3 + cur, 8);
	outc(tag > 0 ? '*' : ' ');
    }

    /* return XO_NONE; */
    return xo->pos + 1 + XO_MOVE;	/* lkchu.981201: ���ܤU�@�� */
}


/* ----------------------------------------------------- */
/* �O�D�\��Gmark / delete				 */
/* ----------------------------------------------------- */


static int
post_mark(xo)
    XO *xo;
{
    if (bbstate & STAT_BOARD) {
	HDR *hdr;
	int pos, cur;

	pos = xo->pos;
	cur = pos - xo->top;
	hdr = (HDR *) xo_pool + cur;
	hdr->xmode ^= POST_MARKED;
	/*
	 * rec_put(xo->dir, hdr, sizeof(HDR), xo->key == XZ_POST ? pos :
	 * hdr->xid);
	 */
	/* Thor.000104: ��¤� */
#ifdef XZ_XPOST
	rec_put(xo->dir, hdr, sizeof(HDR), xo->key == XZ_XPOST ? hdr->xid : pos);
#else
	rec_put(xo->dir, hdr, sizeof(HDR), pos);
#endif

	move(3 + cur, 7);
	outc(post_attr(hdr));
    }
    return XO_NONE;
}


static int
lazy_delete(hdr)
    HDR *hdr;
{
    sprintf(hdr->title, "<< ���峹�g %s �R�� >>", cuser.userid);
    hdr->xmode |= POST_DELETE;
    return 0;
}


static int
post_delete(xo)
    XO *xo;
{
    int pos, cur, by_BM;
    HDR *fhdr;
    char buf[80];

#define BN_DELETED	"deleted"
#define BN_JUNK		"junk"

    if (!cuser.userlevel ||
	!strcmp(currboard, BN_DELETED) ||
	!strcmp(currboard, BN_JUNK))
	return XO_NONE;

    pos = xo->pos;
    cur = pos - xo->top;
    fhdr = (HDR *) xo_pool + cur;

    if (fhdr->xmode & (POST_MARKED | POST_CANCEL | POST_DELETE))
	return XO_NONE;

    by_BM = strcmp(fhdr->owner, cuser.userid);
    if (!(bbstate & STAT_BOARD) && by_BM)
	return XO_NONE;

    if (vans(msg_del_ny) == 'y') {
	currchrono = fhdr->chrono;

	/* Thor.980911: for ���D��峹 in �걵 */
	/*
	 * if (!rec_del(xo->dir, sizeof(HDR), xo->pos, cmpchrono,
	 * lazy_delete))
	 */
	/* Thor.000104: ��¤� */
	/*
	 * if (!rec_del(xo->dir, sizeof(HDR), xo->key == XZ_POST ? pos :
	 * fhdr->xid, cmpchrono, lazy_delete))
	 */
#ifdef XZ_XPOST
	if (!rec_del(xo->dir, sizeof(HDR), xo->key == XZ_XPOST ? fhdr->xid : pos, cmpchrono, lazy_delete))
#else
	if (!rec_del(xo->dir, sizeof(HDR), pos, cmpchrono, lazy_delete))
#endif
	{
	    move_post(fhdr, by_BM ? BN_DELETED : BN_JUNK, by_BM);
	    if (!by_BM && !(bbstate & BRD_NOCOUNT)) {
		if (cuser.numposts > 0)
		    cuser.numposts--;
		sprintf(buf, "%s�A�z���峹� %d �g", MSG_DEL_OK, cuser.numposts);
		vmsg(buf);
	    }
	    lazy_delete(fhdr);	/* Thor.980911: ����: �ק� xo_pool */
	    move(3 + cur, 0);
	    post_item(++pos, fhdr);
	}
    }
    return XO_FOOT;

#undef	BN_DELETED
#undef	BN_JUNK
}


/* ----------------------------------------------------- */
/* �����\��Gedit / title				 */
/* ----------------------------------------------------- */


static int
post_edit(xo)
    XO *xo;
{
    HDR *hdr;
    char fpath[80];

    if (cuser.userlevel & PERM_ALLBOARD) {
	hdr = (HDR *) xo_pool + (xo->pos - xo->top);
	hdr_fpath(fpath, xo->dir, hdr);
	vedit(fpath, NA);	/* Thor.981020: �`�N�Qtalk�����D */
	post_head(xo);
    }
    return XO_NONE;
}


static int
post_title(xo)
    XO *xo;
{
    HDR *fhdr, mhdr;
    int pos, cur;

    if (!HAS_PERM(PERM_ALLBOARD))
	return XO_NONE;

    pos = xo->pos;
    cur = pos - xo->top;
    fhdr = (HDR *) xo_pool + cur;
    mhdr = *fhdr;

    vget(b_lines, 0, "���D�G", mhdr.title, sizeof(mhdr.title), GCARRY);
    vget(b_lines, 0, "�@�̡G", mhdr.owner, 74 /* sizeof(mhdr.owner) */ , GCARRY);
    /* Thor.980727:lkchu patch: sizeof(mhdr.owner) = 80�|�W�L�@�� */
    vget(b_lines, 0, "����G", mhdr.date, sizeof(mhdr.date), GCARRY);
    if (vans(msg_sure_ny) == 'y' &&
	memcmp(fhdr, &mhdr, sizeof(HDR))) {
	*fhdr = mhdr;
	rec_put(xo->dir, fhdr, sizeof(HDR), pos);
	move(3 + cur, 0);
	post_item(++pos, fhdr);
    }
    return XO_FOOT;
}


#ifdef HAVE_TERMINATOR
/* Thor.990603: �p�e�[�W Author */
static int
post_cross_terminator(xo)	/* Thor.0521: �׷��峹�j�k */
    XO *xo;
{
    char *title, buf[100];

    if (!HAS_PERM(PERM_ALLBOARD))
	return XO_NONE;

    title = currtitle;
    if (!*title)
	return XO_NONE;

    sprintf(buf, "�m�تḨ���١n���D�G%.40s�A�T�w�ܡHY/[N]", title);
    if (vans(buf) == 'y') {
	BRD *bhdr, *head, *tail;

	/* Thor.0616: �O�U currboard, �H�K�_�� */
	strcpy(buf, currboard);

	head = bhdr = bshm->bcache;
	tail = bhdr + bshm->number;
	do {			/* �ܤ֦�sysop�@�� */
	    int fdr, fsize, xmode;
	    FILE *fpw;
	    char fpath[80];
	    char fnew[80], fold[80];
	    HDR *hdr;

	    /* Thor.0616:���currboard,�Hcancel post */

	    strcpy(currboard, head->brdname);

	    sprintf(fpath, "�m�تḨ���١n�ݪ��G%s \033[5m...\033[m", currboard);
	    outz(fpath);
	    refresh();

	    brd_fpath(fpath, currboard, fn_dir);

	    if ((fdr = open(fpath, O_RDONLY)) < 0)
		continue;

	    if (!(fpw = f_new(fpath, fnew))) {
		close(fdr);
		continue;
	    }

	    fsize = 0;
	    mgets(-1);
	    while ((hdr = mread(fdr, sizeof(HDR)))) {
		xmode = hdr->xmode;
		if (xmode & (POST_CANCEL | POST_DELETE))
		    continue;

		if ((xmode & POST_MARKED) || strcmp(title, str_ttl(hdr->title))) {
		    if ((fwrite(hdr, sizeof(HDR), 1, fpw) != 1)) {
			fclose(fpw);
			unlink(fnew);
			close(fdr);
			goto contWhileOuter;
		    }
		    fsize++;
		}
		else {
		    /* �Y���ݪO�N�s�u��H */

		    cancel_post(hdr);
		    hdr_fpath(fold, fpath, hdr);
		    unlink(fold);
		}
	    }
	    close(fdr);
	    fclose(fpw);

	    sprintf(fold, "%s.o", fpath);
	    rename(fpath, fold);
	    if (fsize)
		rename(fnew, fpath);
	    else
		unlink(fnew);

    contWhileOuter:

	} while (++head < tail);

	strcpy(currboard, buf);
	post_load(xo);
    }

    return XO_FOOT;
}
#endif


static int
post_help(xo)
    XO *xo;
{
    film_out(FILM_BOARD, -1);
    return XO_HEAD;		/* post_head(xo); *//* Thor.990621: �P
				 * xpost_help�@�� */
}


KeyFunc post_cb[] =
{
    { XO_INIT, post_init },
    { XO_LOAD, post_load },
    { XO_HEAD, post_head },
    { XO_BODY, post_body },

    { 'r', post_browse },
    { 's', post_switch },
    { KEY_TAB, post_gem },
    { 'z', post_gem },

    { 'y', post_reply },
    { 'd', post_delete },
    { 'v', post_visit },

    { Ctrl('P'), post_add },
    { Ctrl('X'), post_cross },
    { Ctrl('Q'), xo_uquery },
    { Ctrl('U'), xo_usetup },

#if 1				/* Thor.981120: �Ȯɨ���, ���~�� */
    /* lkchu.981201: �S�� 'D' �ܤ��ߺD :p */
    { 'D', xo_delete },
#endif

#ifdef HAVE_TERMINATOR
    { 'X', post_cross_terminator },
#endif

    { 't', post_tag },

    { 'E', post_edit },
    { 'T', post_title },
    { 'm', post_mark },

#if 1
    { 'R', vote_result },
    { 'V', XoVote },
#endif
#if 0
    /* Thor.990220: ��ĥ~�� */
    { 'R' | XO_DL, "bin/vote.so:vote_result" },
    { 'V' | XO_DL, "bin/vote.so:XoVote" },
#endif

    { 'b', post_memo },
    { 'W', post_memo_edit },

#ifdef HAVE_MODERATED_BOARD
    { Ctrl('G'), XoBM },
#endif

#ifdef XZ_XPOST
    { '~', XoXpost } ,		/* Thor: for XoXpost */
#endif

    { 'h', post_help }
};


#ifdef XZ_XPOST
/*------------------------------------------------------------------------
  Thor.0509: �s�� �峹�j�M�Ҧ�
             �i���w�@keyword, �C�X�Ҧ�keyword�������峹�C��

  �b tmp/ �U�} xpost.{pid} �@�� folder, �t�ؤ@map�}�C, �Χ@�P��post�@map
  �O���Ӥ峹�O�b��post����B, �p���i�@ mark,gem,edit,title���\��,
  �B�����}�ɦ^�ܹ����峹�B
  <�H�W�Q�k obsolete...>

  Thor.0510:
  �إߤ峹�Q�צ�, like tin, �N�峹�� index ��J memory��,
  ���ϥ� thread, �]�� thread�n�� folder��...

  �������Mode, Title & post list

  ���Ҽ{����²�ƪ� �W�U�䲾��..

  O->O->O->...
  |  |  |
  o  o  o
  |  |  |

  index�tfield {next,text} ����int, �t�m�]�� int
  �Ĥ@�h sorted by title, ���J�ɥ� binary search
  �B MMAP only , �Ĥ@�h��� # and +

  �����ѥ���R���ʧ@, �קK�V��

  Thor.980911: �Ҽ{���ѧR�����O, ��K���D
-------------------------------------------------------------------------*/
#if 0
extern XO *xpost_xo;		/* Thor: dynamic programmin for variable dir
				 * name */
extern XO *ypost_xo;
#endif


#define	MSG_XYPOST	"[�걵�Ҧ�]���D����r:"
#define	MSG_XY_NONE	"�ŵL�@��"


typedef struct {
    char *subject;
    int first;
    int last;
    time_t chrono;
}      Chain;			/* Thor: negative is end */



static int
chain_cmp(a, b)
    Chain *a;
    Chain *b;
{
    return a->chrono - b->chrono;
}


static int *xypostI;


/* Thor: first ypost pos in ypost_xo.key */

static int comebackPos;

/* Thor: first xpost pos in xpost_xo.key */

static char xypostKeyword[30];


/* -1 to find length, otherwise return index */


static int
XoXpost(xo)			/* Thor: call from post_cb */
    XO *xo;
{
    int *plist, *xlist, fsize, max, locus, sum, i, m, n;
    Chain *chain;
    char *fimage, *key, author[30], buf[30];
    HDR *head, *tail;
    int filter_author;
    XO *xt;

    if ((max = xo->max) <= 0)	/* Thor.980911: ����: �H���U�@ */
	return XO_FOOT;

    /* input condition */

    key = xypostKeyword;
    vget(b_lines, 0, MSG_XYPOST, key, sizeof(xypostKeyword), GCARRY);
    str_lower(buf, key);
    key = buf;

    if ((filter_author = vget(b_lines, 0, "[�걵�Ҧ�]�@�̡G", author, 30, DOECHO))) {
	filter_author = strlen(author);
	str_lower(author, author);
    }

    /* build index according to input condition */

    fimage = f_map(xo->dir, &fsize);

    if (fimage == (char *) -1) {
	vmsg("�ثe�L�k�}�ү�����");
	return XO_FOOT;
    }

    if ((xlist = xypostI))	/* Thor.980911: ����: �ȭ��жi�J��, ���O�O���� */
	free(xlist);

    /* allocate index memory, remember free first */

    /* Thor.990113: �Ȱ�title,author�������S���Hpost */
    max = fsize / sizeof(HDR);

    plist = (int *) malloc(sizeof(int) * max);
    chain = (Chain *) malloc(sizeof(Chain) * max);

    max = sum = 0;

    head = (HDR *) fimage;
    tail = (HDR *) (fimage + fsize);

    locus = -1;
    do {
	int left, right, mid;
	char *title;

	locus++;
	if (head->xmode & (POST_CANCEL | POST_DELETE))
	    continue;		/* Thor.0701: ���L�ݤ��쪺�峹 */

	/* check author */

	/*
	 * Thor.981109: �S�O�`�N, author�O�q�Ymatch, ���Osubstr match,
	 * �����Cload
	 */
	if (filter_author && str_ncmp(head->owner, author, filter_author))
	    continue;

	/* check condition */

	title = head->title;

	if (STR4(title) == STR4(STR_REPLY))	/* Thor.980911: ���� Re: ���~ */
	    title += 4;

	if (*key && !str_str(title, key))
	    continue;

#if 0
	if (STR4(title) == STR4(STR_REPLY))
	    title += 4;
#endif

	sum++;

	/* check if in table, binary check */

	left = 0;
	right = max - 1;
	for (;;) {
	    int cmp;
	    Chain *cptr;

	    if (left > right) {
		for (i = max; i > left; i--)
		    chain[i] = chain[i - 1];

		cptr = &chain[left];
		cptr->subject = title;
		cptr->first = cptr->last = locus;
		cptr->chrono = head->chrono;
		max++;
		break;
	    }

	    mid = (left + right) >> 1;
	    cptr = &chain[mid];
	    cmp = strcmp(title, cptr->subject);

	    if (!cmp) {
		plist[cptr->last] = locus;
		cptr->last = locus;
		break;
	    }

	    if (cmp < 0)
		right = mid - 1;
	    else
		left = mid + 1;
	}
    } while (++head < tail);
    munmap(fimage, fsize);

    if (max <= 0) {
	free(chain);
	free(plist);
	vmsg(MSG_XY_NONE);
	return XO_FOOT;
    }

    if (max > 1)
	qsort(chain, max, sizeof(Chain), chain_cmp);

    xypostI = xlist = (int *) malloc(sizeof(int) * sum);

    i = locus = 0;
    do {
	xlist[locus++] = n = chain[i].first;
	m = chain[i].last;

	while (n != m) {
	    xlist[locus++] = n = plist[n];
	}

    } while (++i < max);

    free(chain);
    free(plist);

    /* build XO for xpost_xo */

    if ((xt = xz[XZ_XPOST - XO_ZONE].xo))
	free(xt);

    comebackPos = xo->pos;	/* Thor: record pos, future use */
    xz[XZ_XPOST - XO_ZONE].xo = xt = xo_new(xo->dir);
    xt->pos = 0;
    xt->max = sum;
    xt->xyz = xo->xyz;
    xt->key = XZ_XPOST;

    xover(XZ_XPOST);

    /* set xo->pos for new location */

    xo->pos = comebackPos;

    /* free xpost_xo */

    if ((xt = xz[XZ_XPOST - XO_ZONE].xo)) {
	free(xt);
	xz[XZ_XPOST - XO_ZONE].xo = NULL;
    }

    /* free index memory, remember check free pointer */

    if ((xlist = xypostI)) {
	free(xlist);
	xypostI = NULL;
    }

    return XO_INIT;
}


#if 0
/* Thor.980911: �@�� post_body() �Y�i*/
static int
xpost_body(xo)
    XO *xo;
{
    HDR *fhdr;
    int num, max, tail;

    max = xo->max;
#if 0
    if (max <= 0) {		/* Thor.980911: ����: �H���U�@�� */
	vmsg(MSG_XY_NONE);
	return XO_QUIT;
    }
#endif

    fhdr = (HDR *) xo_pool;
    num = xo->top;
    tail = num + XO_TALL;
    if (max > tail)
	max = tail;

    move(3, 0);
    do {
	post_item(++num, fhdr++);
    } while (num < max);

    clrtobot();
    return XO_NONE;
}

#endif

static int
xpost_head(xo)
    XO *xo;
{
    vs_head("�D�D��C" /* currBM */ , xo->xyz);
    outs(MSG_XYPOST);
    if (*xypostKeyword)
	outs(xypostKeyword);

    outs("\n\
\033[44m  �s��   �� ��  �@  ��       ��  ��  ��  �D                                   \033[m");

    /* return xpost_body(xo); */
    return post_body(xo);	/* Thor.980911: �@�ΧY�i */
}


static void
xypost_pick(xo)
    XO *xo;
{
    int *xyp, fsize, pos, max, top;
    HDR *fimage, *hdr;

    fimage = (HDR *) f_map(xo->dir, &fsize);
    if (fimage == (HDR *) - 1)
	return;

    hdr = (HDR *) xo_pool;
    xyp = xypostI;

    pos = xo->pos;
    xo->top = top = (pos / XO_TALL) * XO_TALL;
    max = xo->max;
    pos = top + XO_TALL;
    if (max > pos)
	max = pos;

    do {
	pos = xyp[top++];
	*hdr = fimage[pos];
	hdr->xid = pos;
	hdr++;
    } while (top < max);

    munmap((void *) fimage, fsize);
}


static int
xpost_init(xo)
    XO *xo;
{
    /* load into pool */

    xypost_pick(xo);

    return xpost_head(xo);
}


static int
xpost_load(xo)
    XO *xo;
{
    /* load into pool */

    xypost_pick(xo);

    /* return xpost_body(xo); */
    return post_body(xo);	/* Thor.980911: �@�ΧY�i */
}


static int
xpost_help(xo)
    XO *xo;
{
    film_out(FILM_BOARD, -1);
    /* mat.000210: �n�^��head�e�� */
    return xpost_head(xo);
}


/* Thor.0509: �n�Q��k�T�� ctrl('D') */


static int
xpost_browse(xo)
    XO *xo;
{
    HDR *hdr;
    int cmd, chrono, xmode;
    char *dir, fpath[64];

    int key;

    cmd = XO_NONE;
    dir = xo->dir;

    for (;;) {
	hdr = (HDR *) xo_pool + (xo->pos - xo->top);
	xmode = hdr->xmode;
	if (xmode & (POST_CANCEL | POST_DELETE))
	    break;

	hdr_fpath(fpath, dir, hdr);

	/* Thor.990204: ���Ҽ{more �Ǧ^�� */
	if ((key = more(fpath, MSG_POST)) < 0)
	    break;

	comebackPos = hdr->xid;
	/* Thor.980911: �q�걵�Ҧ��^�Ӯɭn�^��ݹL�����g�峹��m */

	cmd = XO_HEAD;

	chrono = hdr->chrono;
	if (brh_unread(chrono)) {
	    int prev, next, pos;
	    char *dir;
	    HDR buf;

	    dir = xo->dir;
	    pos = hdr->xid;

	    if (!rec_get(dir, &buf, sizeof(HDR), pos - 1))
		prev = buf.chrono;
	    else
		prev = chrono;

	    if (!rec_get(dir, &buf, sizeof(HDR), pos + 1))
		next = buf.chrono;
	    else
		next = chrono;

	    brh_add(prev, hdr->chrono, next);
	}

	strcpy(currtitle, str_ttl(hdr->title));

	/* Thor.990204: ���Ҽ{more �Ǧ^�� */
	if (!key)
	    key = vkey();

	switch (key) {
	case ']':		/* Thor.990204: ���ɷQ��]�ݫ᭱���峹 */
	case 'j':		/* Thor.990204: ���ɷQ��j�ݫ᭱���峹 */
	case ' ':
	    {
		int pos = xo->pos + 1;

		/* Thor.980727: �ץ��ݹL�Y��bug */

		if (pos >= xo->max)
		    return cmd;

		xo->pos = pos;

		if (pos >= xo->top + XO_TALL)
		    xypost_pick(xo);

		continue;
	    }

	case 'y':
	case 'r':
	    if (bbstate & STAT_POST) {
		strcpy(quote_file, fpath);
		if (do_reply(hdr) == XO_INIT)	/* �����\�a post �X�h�F */
		    return xpost_init(xo);
	    }
	    break;

	case 'm':
	    if ((bbstate & STAT_BOARD) && !(xmode & POST_MARKED)) {
		hdr->xmode = xmode | POST_MARKED;
		rec_put(dir, hdr, sizeof(HDR), hdr->xid);
	    }
	    break;

	}
	break;
    }

    return cmd;
}


KeyFunc xpost_cb[] =
{
    { XO_INIT, xpost_init },
    { XO_LOAD, xpost_load },
    { XO_HEAD, xpost_head },
#if 0
    { XO_BODY, xpost_body },
#endif
    { XO_BODY, post_body },		/* Thor.980911: �@�ΧY�i */

    { 'r', xpost_browse },
    { 'y', post_reply },
    { 't', post_tag },
    { 'm', post_mark },

    { 'd', post_delete} ,		/* Thor.980911: ��K���D */

    { Ctrl('P'), post_add },
    { Ctrl('Q'), xo_uquery },
    { Ctrl('U'), xo_usetup },
    { Ctrl('X'), post_cross },

    { 'h', xpost_help }
};
#endif
