#include "bbs.h"
#include "brh.h"
#include <stdlib.h>

extern BCACHE *bshm;

typedef struct BoardReadingHistory {
/* XXX: should use board id to identify and bstamp to verify! */
    time_t bstamp;		/* �إ߬ݪO���ɶ�, unique *//* Thor.brh_tail */
    time_t bvisit;		/* �W���\Ū�ɶ� *//* Thor.980902:�S�Ψ�? */
    /* Thor.980904:��Ū�ɩ�W��Ū���ɶ�, ��Ū�ɩ� bhno */
    int bcount;			/* Thor.980902:�S�Ψ�? */
    /* Thor.980902:���ۤv�ݪ� */
    /* --------------------------------------------------- */
    /* time_t {final, begin} / {final | BRH_SIGN}		 */
    /* --------------------------------------------------- */
    /* Thor.980904:����: BRH_SIGN�N��final begin �ۦP */
    /* Thor.980904:����: �Ѥj��p�ƦC,�s��wŪinterval */
}                   BRH;


#define	BRH_EXPIRE	180	/* Thor.980902:����:�O�d�h�֤� */
#define BRH_MAX      	200	/* Thor.980902:����:�C���̦h���X�Ӽ��� */
#define BRH_PAGE	2048	/* Thor.980902:����:�C���h�t�q, �Τ���F */
#define	BRH_MASK	0x7fffffff	/* Thor.980902:����:�̤j�q��2038�~1�뤤 */
#define	BRH_SIGN	0x80000000	/* Thor.980902:����:zap����final�M�� */
#define	BRH_WINDOW	(sizeof(BRH) + sizeof(time_t) * BRH_MAX * 2)

char brd_bits[MAXBOARD];
time_t brd_visit[MAXBOARD];
static int *brh_base;
static int *brh_curr;		/* current board brh record pointer */
static int brh_size;		/* allocated memory size */
static time_t brh_expire;

extern int Ben_Perm(BRD *bhdr, usint ulevel);

/* ensures we have extra space of <size> after <tail>, returns new <tail> */
static int *
brh_alloc(int *tail, int size)
{
    int *base, n;

    base = brh_base;
    n = (char *) tail - (char *) base;
    size += n;
    if (size > brh_size) {
	/* size = (size & -BRH_PAGE) + BRH_PAGE; */
	size += n >> 4;		/* �h�w���@�ǰO���� */
	base = (int *) realloc((char *) base, size);

	if (base == NULL)
	    abort_bbs(0);

	brh_base = base;
	brh_size = size;
	tail = (int *) ((char *) base + n);
    }

    return tail;
}

static void
brh_put()
{
    int *list;

    /* compact the history list */

    list = brh_curr;

    if (*list) {
	int *head, *tail, n, item, chrono;

	n = *++list;		/* Thor.980904: ��Ū�ɬObhno */
	brd_bits[n] |= BRD_H_BIT;
	time((time_t *) list);	/* Thor.980904: ����: bvisit time */

	item = *++list;
	head = ++list;
	tail = head + item;

	while (head < tail) {
	    chrono = *head++;
	    n = *head++;
	    if (n == chrono) {	/* Thor.980904: ����: �ۦP���ɭ����_�� */
		n |= BRH_SIGN;
		item--;
	    }
	    else {
		*list++ = chrono;
	    }
	    *list++ = n;
	}

	list[-item - 1] = item;
	*list = 0;
	brh_curr = list;	/* Thor.980904:�s����brh */
    }
}


void
brh_get(time_t bstamp, int bhno)
{
    int *head, *tail;
    int size, bcnt, item;
    char buf[BRH_WINDOW];

    if (bstamp == *brh_curr)	/* Thor.980904:����:�Ӫ��w�b brh_curr�W */
	return;

    brh_put();

    bcnt = 0;
    tail = brh_curr;

    if (brd_bits[bhno] & BRD_H_BIT) {
	head = brh_base;
	while (head < tail) {
	    item = head[2];
	    size = item * sizeof(time_t) + sizeof(BRH);

	    if (bstamp == *head) {
		bcnt = item;
		memcpy(buf, head + 3, size);
		tail = (int *) ((char *) tail - size);
		if ((item = (char *) tail - (char *) head))
		    memcpy(head, (char *) head + size, item);
		break;
	    }
	    head = (int *) ((char *) head + size);
	}
    }

    brh_curr = tail = brh_alloc(tail, BRH_WINDOW);

    *tail++ = bstamp;
    *tail++ = bhno;

    if (bcnt) {			/* expand history list */
	int *list;

	size = bcnt;
	list = tail;
	head = (int *) buf;

	do {
	    item = *head++;
	    if (item & BRH_SIGN) {
		item ^= BRH_SIGN;
		*++list = item;
		bcnt++;
	    }
	    *++list = item;
	} while (--size);
    }

    *tail = bcnt;
}

/* return true if the article is unread */
int
brh_unread(time_t chrono)
{
    int *head, *tail, item;

    if (chrono <= brh_expire)
	return 0;

    head = brh_curr + 2;
    if ((item = *head) > 0) {
	/* check {final, begin} history list */

	head++;
	tail = head + item;
	do {
	    if (chrono > *head)
		return 1;

	    head++;
	    if (chrono >= *head)
		return 0;

	} while (++head < tail);
    }
    return 1;
}


void
brh_visit(mode)
    int mode;			/* 0 : visit, 1: un-visit */
{				/* Thor.990430: �άO�ǤJchrono, �N��Ū�ܭ� */
    int *list;

    list = (int *) brh_curr + 2;
    *list++ = 2;
    if (mode) {
	*list = mode;
    }
    else {
	time((time_t *) list);
    }
    /* *++list = mode; */
    *++list = 0;		/* Thor.990430: �j�w�� 0, for ���� visit */
}


void
brh_add(time_t prev, time_t chrono, time_t next)
{
    int *base, *head, *tail, item, final, begin;

    head = base = brh_curr + 2;
    item = *head++;
    tail = head + item;

    begin = BRH_MASK;

    while (head < tail) {
	final = *head;
	if (chrono > final) {
	    if (prev <= final) {
		if (next < begin)	/* increase */
		    *head = chrono;
		else {		/* merge */
		    *base = item - 2;
		    base = head - 1;
		    do {
			*base++ = *++head;
		    } while (head < tail);
		}
		return;
	    }

	    if (next >= begin) {
		head[-1] = chrono;
		return;
	    }

	    break;
	}

	begin = *++head;
	head++;
    }

    /* insert or append */

    /* [21, 22, 23] ==> [32, 30] [15, 10] */

    if (item < BRH_MAX) {
	/* [32, 30] [22, 22] [15, 10] */

	*base = item + 2;
	tail += 2;
    }
    else {
	/* [32, 30] [22, 10] *//* Thor.980923: how about [6, 7, 8] ? [15,7]? */

	tail--;
    }

    prev = chrono;
    for (;;) {
	final = *head;
	*head++ = chrono;

	if (head >= tail)
	    return;

	begin = *head;
	*head++ = prev;

	if (head >= tail)
	    return;

	chrono = final;
	prev = begin;
    }
}

void
brh_load()
{
    BRD *brdp, *bend;
    usint ulevel;
    int n, cbno;
    char *bits;

    int size, *base;
    time_t expire, *bstp;
    char fpath[64];

    ulevel = cuser.userlevel;
    n = (ulevel & PERM_ALLBOARD) ? (BRD_R_BIT | BRD_W_BIT | BRD_X_BIT) : 0;
    memset(bits = brd_bits, n, sizeof(brd_bits));
    memset(bstp = brd_visit, 0, sizeof(brd_visit));

    if (n == 0) {
	brdp = bshm->bcache;
	bend = brdp + bshm->number;

	do {
	    *bits++ = Ben_Perm(brdp, ulevel);
	} while (++brdp < bend);
    }

    /* --------------------------------------------------- */
    /* �N .BRH ���J memory				 */
    /* --------------------------------------------------- */

    size = 0;
    cbno = -1;
    brh_expire = expire = time(0) - BRH_EXPIRE * 86400;

    if (ulevel) {
	struct stat st;

	usr_fpath(fpath, cuser.userid, FN_BRH);
	if (!stat(fpath, &st))
	    size = st.st_size;
    }

    /* --------------------------------------------------- */
    /* �h�O�d BRH_WINDOW ���B�@�Ŷ�			 */
    /* --------------------------------------------------- */

    /* brh_size = n = ((size + BRH_WINDOW) & -BRH_PAGE) + BRH_PAGE; */
    brh_size = n = size + BRH_WINDOW;
    brh_base = base = (int *) malloc(n);

    if (size && ((n = open(fpath, O_RDONLY)) >= 0)) {
	int *head, *tail, *list, bstamp, bhno;

	size = read(n, base, size);
	close(n);


	/* compact reading history : remove dummy/expired record */

	head = base;
	tail = (int *) ((char *) base + size);
	bits = brd_bits;
	while (head < tail) {
	    bstamp = *head;

	    if (bstamp & BRH_SIGN) {	/* zap */
		bstamp ^= BRH_SIGN;
		bhno = bstamp2bno(bstamp);
		if (bhno >= 0) {
#if 1				/* Thor.991121: NOZAP��, ���|�X�{ */
		    brdp = bshm->bcache + bhno;
		    if (!(brdp->battr & BRD_NOZAP))
#endif
			bits[bhno] |= BRD_Z_BIT;
		}
		head++;
		continue;
	    }

	    bhno = bstamp2bno(bstamp);
	    list = head + 2; /* actually count */
	    n = *list;
	    size = n + 3;

	    /* �o�ӬݪO�s�b�B�S���Q zap ���B�i�H read */

	    if (bhno >= 0 && (bits[bhno] & BRD_R_BIT)) {
		bits[bhno] |= BRD_H_BIT;	/* �w���\Ū�O�� */
		bstp[bhno] = head[1];	/* �W���\Ū�ɶ� */
		cbno = bhno;

		if (n > 0) {

#if 0
		    if (n > BRH_MAX)
			n = BRH_MAX;
#endif

		    list += n;	/* Thor.980904: ����: �̫�@��tag */

		    do {
			bhno = *list;
			if ((bhno & BRH_MASK) > expire)
			    break;

			if (!(bhno & BRH_SIGN)) {
			    if (*--list > expire)
				break;
			    n--;
			}

			list--;
			n--;
		    } while (n > 0);

		    head[2] = n;
		}

		n = n * sizeof(time_t) + sizeof(BRH);
		if (base != head)
		    memcpy(base, head, n);
		base = (int *) ((char *) base + n);
	    }
	    head += size;
	}
    }

    *base = 0;
    brh_curr = base;

    /* --------------------------------------------------- */
    /* �]�w default board					 */
    /* --------------------------------------------------- */

    strcpy(currboard, "�|����w");
}

void
brh_save()
{
    int *base, *head, *tail, bhno, size;
    BRD *bhdr, *bend;
    char *bits;

    /* Thor.980830: lkchu patch:  �٨S load �N���� save */
    if (!(base = brh_base))
	return;

#if 0
    base = brh_base;
#endif

    brh_put();

    /* save history of un-zapped boards */

    bits = brd_bits;
    head = base;
    tail = brh_curr;
    while (head < tail) {
	bhno = bstamp2bno(*head);
	size = head[2] * sizeof(time_t) + sizeof(BRH);
	if (bhno >= 0 && !(bits[bhno] & BRD_Z_BIT)) {
	    if (base != head)
		memcpy(base, head, size);
	    base = (int *) ((char *) base + size);
	}
	head = (int *) ((char *) head + size);
    }

    /* save zap record */

    tail = brh_alloc(base, sizeof(time_t) * MAXBOARD);

    bhdr = bshm->bcache;
    bend = bhdr + bshm->number;
    do {
	if (*bits++ & BRD_Z_BIT) {
	    *tail++ = bhdr->bstamp | BRH_SIGN;
	}
    } while (++bhdr < bend);

    /* OK, save it */

    base = brh_base;
    if ((size = (char *) tail - (char *) base) > 0) {
	char fpath[64];
	int fd;

	usr_fpath(fpath, cuser.userid, FN_BRH);
	if ((fd = open(fpath, O_WRONLY | O_CREAT | O_TRUNC, 0600)) >= 0) {
	    write(fd, base, size);
	    close(fd);
	}
    }
}

