#include "bbs.h"
#include "brh.h"
#include "visio.h"
#include "xover.h"
#include <stdlib.h>

extern BCACHE *bshm;
extern XZ xz[];
static XO *board_xo;

/* ----------------------------------------------------- */
/* board permission check				 */
/* ----------------------------------------------------- */

static int
is_bm(char *bmlist)
{
    int cc, len;
    char *userid;

    len = strlen(userid = cuser.userid);
    do {
	cc = bmlist[len];
	if ((!cc || cc == '/') && !str_ncmp(bmlist, userid, len)) {
	    return 1;
	}
	while ((cc = *bmlist++)) {
	    if (cc == '/')
		break;
	}
    } while (cc);

    return 0;
}

int
Ben_Perm(BRD *bhdr, usint ulevel)
{
    usint readlevel, postlevel, bits;
    char *blist, *bname;

    bname = bhdr->brdname;
    if (!*bname)
	return 0;

    if (!str_cmp(bname, DEFAULT_BOARD))
	return (BRD_R_BIT | BRD_W_BIT);

    bits = 0;

    readlevel = bhdr->readlevel;
    if (!readlevel || (readlevel & ulevel)) {
	bits = BRD_R_BIT;

	if (ulevel & PERM_POST) {
	    postlevel = bhdr->postlevel;
	    if (!postlevel || (postlevel & ulevel))
		bits |= BRD_W_BIT;
	}
    }

#ifdef HAVE_MODERATED_BOARD
    /* check pal list of this board */
    if (readlevel == PERM_SYSOP) {
	extern int bm_belong();
	bits = bm_belong(bname);
    }
#endif
    /* bm has complete access */
    blist = bhdr->BM;
    if ((ulevel & PERM_BM) && blist[0] > ' ' && is_bm(blist))
	return (BRD_R_BIT | BRD_W_BIT | BRD_X_BIT);

    return bits;
}

/* translate bstamp to bno */
int
bstamp2bno(time_t stamp)
{
    BRD *brd;
    int bno, max;

    bno = 0;
    brd = bshm->bcache;
    max = bshm->number;
    for (;;) {
	if (stamp == brd->bstamp)
	    return bno;
	if (++bno >= max)
	    return -1;
	brd++;
    }
}

#ifdef LOG_BRD_USIES
void
brd_usies(void)
{
    char buf[256];

    sprintf(buf, "%s %s (%s)\n", currboard, cuser.userid, Now());
    f_cat(FN_BRD_USIES, buf);
}
#endif

void
XoPost(int bno)
{
    XO *xo;
    BRD *brd;
    int bits;
    char *str, fpath[64];

    brd = bshm->bcache + bno;
    strcpy(currboard, brd->brdname);
    brh_get(brd->bstamp, bno);

    bbstate = /* (bbstate & STAT_DIRTY) | */ STAT_STARTED | brd->battr;

    str = &brd_bits[bno];
    bits = *str;
    if (bits & BRD_X_BIT)
	bbstate |= (STAT_BOARD | STAT_POST);
    else if (bits & BRD_W_BIT)
	bbstate |= STAT_POST;

#ifdef  HAVE_MODERATED_BOARD
    if (brd->readlevel == PERM_SYSOP)
	bbstate |= STAT_MODERATED;
#endif

    if (!(bits & BRD_V_BIT) && (cuser.ufo & UFO_BNOTE)) {
	*str = bits | BRD_V_BIT;
	brd_fpath(fpath, currboard, fn_note);
	more(fpath, NULL);
    }

    brd_fpath(fpath, currboard, fn_dir);
    xz[XZ_POST - XO_ZONE].xo = xo = xo_get(fpath);
    xo->key = XZ_POST;
    xo->xyz = brd->bvote > 0 ? "���ݪO�i��벼��" : brd->title + 3;
    str = brd->BM;
    if (*str <= ' ')
	str = "�x�D��";
    sprintf(currBM, "�O�D�G%s", str);

#ifdef LOG_BRD_USIES
    /* lkchu.981201: �\Ū�ݪ��O�� */
    brd_usies();
#endif
    /*
     * Thor.000101: ����: ���ߤ@�T��global -- currBM, currboard, bbstate,
     * security hole����]
     */
}


/* ----------------------------------------------------- */
/* Class [�����s��]					 */
/* ----------------------------------------------------- */

static int class_flag;

#define	BFO_YANK	0x01
#define	BFO_FAVORITE	0x02

static int class_add(XO *xo);
typedef int SORT_CMP(const void *, const void *);

static int
sort_brd(HDR *a, HDR *b)
{
    return strcasecmp(a->xname, b->xname);
}

#ifdef	HAVE_ALLBOARDS
static int
load_all_boards(XO *xo)
{
    HDR *head;
    BRD *brd, *btail;
    int max, i;
    int zap = class_flag & BFO_YANK? 0: BRD_Z_BIT;
    static int lastzap;

    if (xo->xyz && lastzap == zap)
	return xo->max;
    brd = bshm->bcache;
    max = bshm->number;
    btail = brd + max;
    head = (HDR *)xo->xyz = malloc(sizeof(HDR) * max);
    i = 0;
    xo->max = 0;
    while (brd < btail) {
	int val = brd_bits[i++];
	if(!(val & BRD_R_BIT) || (val & zap) || !(brd->brdname[0])) {
	    ++brd;
	    continue;
	}
	brd2gem(brd, head);
	/* cache bno in xid */
	head->xid = i-1;
	++head, ++brd, ++xo->max;
    }
    qsort(xo->xyz, xo->max, sizeof(HDR), (SORT_CMP *)sort_brd);
    if(xo->pos >= xo->max)
	xo->pos = xo->top;
    lastzap = zap;
    return max;
}
#endif

static int
class_load(XO *xo)
{
    HDR *head, *tail, *curr;
    int fsize, max, zap, pos, xmode, chn;
    char *bits, val;
    BRD *brd, *bcache;
    bshm_init();
#ifdef	HAVE_ALLBOARDS
    if (!*xo->dir) {
	return load_all_boards(xo);
    }
#endif
    /* free before reload */
    if(xo->xyz)		
	free(xo->xyz);

    xo->xyz = (char *) f_img(xo->dir, &fsize);
    if(!fsize || !(xo->xyz)) {
	xo->xyz = NULL;
	return xo->max=0;
    }
    
    head = curr = (HDR *) xo -> xyz;
    tail = head + (fsize / sizeof(HDR));

    max = 0;
    zap = class_flag & BFO_YANK? 0: BRD_Z_BIT;
    bits = brd_bits;
    bcache = bshm->bcache;

    pos = 0;

    while(head < tail) {
	head->xid = pos++;
	xmode = head->xmode;
	if(xmode & GEM_BOARD) {
	    /* cache bno in xid */
	    chn = head->xid = brd_bno(head->xname);
	    brd = bcache + chn;
	    val = (chn >= 0) ? bits[chn]: 0;
	    
#ifdef _MANIAC_FIX_
	    if(val & BRD_N_BIT) {
		val &= ~BRD_N_BIT;
		val |= Ben_Perm(brd, cuser.userlevel);
		bits[chn] = val;
	    }
#endif
	    if(!(val & BRD_R_BIT) || (val & zap) || !(brd->brdname[0])) {
		head++;
		continue;
	    }
	} else if(xmode & GEM_FOLDER) {
	    char dirpath[256];
	    hdr_fpath(dirpath, xo->dir, head);
	}
	if(head != curr)
	    memcpy(curr, head, sizeof(HDR));
	head++; max++; curr++;
    }

    if(!max) {
	free(xo -> xyz);
	xo->xyz = NULL;
	if(zap) {
	    class_flag |= BFO_YANK;
	    return class_load(xo);
	}
    }

    xo -> max = max;
    if(xo->pos >= max)
	xo->pos = xo->top;
    return max;
}

static int
XoClass(char *fpath, int op)
{
    XO *xo, *xt;

    /*
     * Thor.980727: �ѨM XO xo�����T�w��, class_load�����| initial xo.max,
     * ��L���T�w
     */
    xo = xo_new(fpath);
    xo->pos = xo->top = 0;

    xo->key = op;
    xo->xyz = NULL;
    xt = xz[XZ_CLASS - XO_ZONE].xo;
    xz[XZ_CLASS - XO_ZONE].xo = xo;
    class_load(xo);
    xover(XZ_CLASS);
    if(xo->xyz)
	free(xo->xyz);
    xz[XZ_CLASS - XO_ZONE].xo = xt;

    return XO_BODY;
}


/* ----------------------------------------------------- */
/* �ˬd BRD �@���X�g post�A�γ̫�@�g post ���ɶ�	 */
/* ----------------------------------------------------- */

void
bcheck(brd)
    BRD *brd;
{
    char folder[64];
    struct stat st;
    int fd, size;

    brd_fpath(folder, brd->brdname, fn_dir);

    if (!(class_flag & UFO_BRDNEW)) {
	if (!stat(folder, &st)) {
	    brd->bpost = st.st_size / sizeof(HDR);
	    brd->blast = st.st_mtime;
	}
	return;
    }
    fd = open(folder, O_RDONLY);
    if (fd < 0)
	return;

    fstat(fd, &st);

    if (st.st_mtime > brd->btime) {
	brd->btime = time(0) + 45;	/* 45 �������������ˬd */
	if ((size = st.st_size) >= sizeof(HDR)) {
	    brd->bpost = size / sizeof(HDR);
	    lseek(fd, size - sizeof(HDR), SEEK_SET);
	    read(fd, &brd->blast, sizeof(time_t));
	}
	else {
	    brd->blast = brd->bpost = 0;
	}
    }

    close(fd);
}

static int
class_body(XO *xo)
{
    HDR *hdr;
    char *bits;
    BRD *bcache;
    int pos, max, brdnew, col;

    max = xo->max;
    if(max <= 0) {
	if(xo->key >= GEM_MANAGER) {
	    move(5, 5);
	    outs("�ثe���ؿ��U�|�L���e�A �A�i�H�[�J�G");
	    move(7, 5);
	    outs("F. ��Ƨ� (Folder)  -  ���� Windows ����Ƨ��A �i�s���L��Ƨ��α��|");
	    move(9, 5);
	    outs("B. �ݪO���| (Board Shortcut) - �W�s����Y���x�U���Y�ݪO");
	    if(class_add(xo) == XO_INIT)
		return XO_INIT;
	} else {
/*	    if(in_search_mode) {
		outs("\n\n�䤣��ŦX��");
		vmsg(NULL);
	    }
	    else */{
		move(15, 0);
		outs("\n\n�L���e");
		vmsg(NULL);
	    }

	}
	return XO_QUIT;
    }
    
    hdr = (HDR *) xo->xyz;
    hdr += (pos = xo->top);
    bcache = bshm->bcache;
    brdnew = class_flag & UFO_BRDNEW;
    bits = brd_bits;

    col = 3;

    do {
	move(col++, 0);
	clrtobot();
	++pos;
	if(hdr -> xmode & GEM_BOARD) {
	    /* from xid cache */
	    char *str;
	    BRD *brd = bcache + hdr->xid;
	    bcheck(brd);
	    str = brd->blast > brd_visit[hdr->xid] ? "\033[1;32m�E\033[m" : "�C";
	    prints("%6d%s%c%-13s%-42s%c %.13s", brdnew ? brd->bpost : pos, 
		   str, bits[hdr->xid] & BRD_Z_BIT ? '-' : ' ',
		   brd->brdname, brd->title, brd->bvote ? 'V' : ' ', brd->BM);
	}
	else {
	    prints("%6d   %s", pos, hdr->title);
	}
	clrtoeol();
	++hdr;
    } while (col < b_lines && pos < max);

    return XO_NONE;
}


static int
class_neck(XO *xo)
{
    move(1, 0);
    prints("[��]���} [��]�\\Ū [����]��� [c]�g�� [y]���J [/]�j�M [s]�ݪO [^p] �s�W [h]����\n"
	   "[44m  %-7s��  �O       %-38s�벼 �O    �D     [m",
	   class_flag & UFO_BRDNEW ? "�`��" : "�s��", "��   ��   ��   �z");

    return class_body(xo);
}


static int
class_head(XO *xo)
{
    vs_head("�ݪO�C��", str_site);
    return class_neck(xo);
}


static int
class_init(XO *xo)			/* re-init */
{
    class_load(xo);
    return class_head(xo);
}


static int
class_newmode(XO *xo)
{
    cuser.ufo ^= UFO_BRDNEW;
    class_flag ^= UFO_BRDNEW;
    return class_neck(xo);
}


static int
class_help(XO *xo)
{
    film_out(FILM_CLASS, -1);
    return class_head(xo);
}


static int
class_search(XO *xo)
{
    HDR *hdr;
    int num, pos, max;
    char *ptr;
    char buf[IDLEN + 1];

    ptr = buf;
    pos = vget(b_lines, 0, "�п�J�ݪO�W�١G", ptr, IDLEN + 1, DOECHO);
    move(b_lines, 0);
    clrtoeol();

    if (pos) {
	str_lower(ptr, ptr);
	pos = num = xo->pos;
	max = xo->max;
	hdr = (HDR *) xo->xyz;

	do {
	    if (++pos >= max)
		pos = 0;
	    if (str_str(hdr[pos].xname, ptr) || str_str(hdr[pos].title, ptr))
		return pos + XO_MOVE;
	} while (pos != num);
    }

    return XO_NONE;
}


static int
class_yank(XO *xo)
{
    class_flag ^= BFO_YANK;
    return class_init(xo);
}


static int
class_zap(XO *xo)
{
    HDR *hdr;
    BRD *brd;
    int num, chn;

    num = xo->pos;
    hdr = (HDR *) xo->xyz;
    hdr += num;
    if (hdr->xmode & GEM_BOARD) {
	chn = hdr->xid;
	brd = bshm->bcache + chn;
	if (!(brd->battr & BRD_NOZAP)) {
	    move(3 + num - xo->top, 8);
	    num = brd_bits[chn] ^= BRD_Z_BIT;
	    outc(num & BRD_Z_BIT ? '-' : ' ');
	}
    }
    return XO_NONE;
}


static int
class_edit(XO *xo)
{
    /* if (HAS_PERM(PERM_ALLBOARD)) */
    /* Thor.990119: �u�������i�H�ק� */
    if (HAS_PERM(PERM_SYSOP)) {
	HDR *hdr;
	int chn;

	hdr = (HDR *) xo->xyz;
	hdr += xo->pos;
	chn = hdr->xid;
	if (hdr->xmode & GEM_BOARD) {
	    brd_edit(chn);
	    return class_init(xo);
	}
    }
    return XO_NONE;
}


static int
class_browse(XO *xo)
{
    HDR *hdr;

    hdr = (HDR *)xo->xyz;
    hdr += xo->pos;

    if (hdr->xmode & GEM_BOARD) {
	XoPost(hdr->xid);
	xover(XZ_POST);
	time(&brd_visit[hdr->xid]);
    }
    else {
	char fpath[80];
	hdr_fpath(fpath, xo->dir, hdr);
	if (XoClass(fpath, xo->key) == XO_NONE)
	    return XO_NONE;
    }

    return class_head(xo);	/* Thor.0701: �L�k�M�֤@�I, �]�� XoPost */
}


int
Select()
{
    int bno;
    BRD *brd;
    char bname[16];

    if ((brd = ask_board(bname, BRD_R_BIT, NULL))) {
	bno = brd - bshm->bcache;
	if (*bname) {
	    XoPost(bno);
	}
	xover(XZ_POST);
	time(&brd_visit[bno]);
    }
    else {
	vmsg(err_bid);
    }

    return 0;
}


static int
class_switch(XO *xo)
{
    Select();
    return class_head(xo);
}

static int
class_add(XO *xo)
{
    int level = xo->key;
    int pos, gtype;
    char fpath[80], title[80];
    HDR hdr;
    BRD *brd;

    if(level < GEM_MANAGER)
	return XO_NONE;

    switch(gtype = tolower(vans("�W�[ (F)��Ƨ� (B)�ݪO [Q]���}: "))) {
    case 'b':
	if(level < GEM_MANAGER)
	    return XO_FOOT;
	if(!(brd = ask_board(fpath, BRD_R_BIT, NULL)))
	    return XO_HEAD;
	
	brd2gem(brd, &hdr);
	break;
    case 'f':
	if(!vget(b_lines, 0, "���D: ", title, TTLEN + 1, DOECHO))
	    return XO_FOOT;

	if(class_flag & BFO_FAVORITE) {
	    /* add folder in Favorite */
	    int fd;
	    char fpath[80];

	    usr_fpath(fpath, cuser.userid, "temp");
	    if((fd = open(fpath, O_CREAT, 0600)) >= 0) {
		hdr_stamp(xo->dir, HDR_LINK, &hdr, fpath);
		unlink(fpath);
	    } else
		return XO_FOOT;
	    strcpy(hdr.title, title);
	} else {
	    /* add class */
	    if (!vget(b_lines, 0, "�ɦW�G", fpath, IDLEN + 1, DOECHO))
		return XO_FOOT;
	    if (strchr(fpath, '/')) {
		zmsg("���X�k���ɮצW��");
		return XO_NONE;
	    }

	    time(&hdr.chrono);
	    sprintf(hdr.xname, "@%s", fpath);
	    strcat(fpath, "/");
	    sprintf(hdr.title, "%-13s�i %s �j", fpath, title);
	}
	hdr.xmode = GEM_FOLDER; //GEM_FOLDER
	break;

    default:
	return XO_FOOT;
    }
    pos = xo -> pos;

    switch(vans("�s���m [A]���[�b�̫� (I)�b�ثe��m���J: ")) {
    case 'n': case 'N':
	pos++;
    case 'i': case 'I':
	rec_ins(xo->dir, &hdr, sizeof(HDR), pos, 1);
	break;
    default:
    case 'a': case 'A':
	rec_add(xo->dir, &hdr, sizeof(HDR));
    };

    class_load(xo);
    if (gtype == 'b')
	class_head(xo);
    return class_body(xo);
}


static int
class_move(XO *xo)
{
    HDR *ghdr;
    char *dir, buf[80];
    int pos, newOrder;
    int level = xo->key;

    if(level < GEM_MANAGER)
	return XO_NONE;

    ghdr = (HDR *)xo->xyz;
    ghdr += xo->pos;

    pos = xo->pos;
    sprintf(buf + 5, "�п�J�� %d �ﶵ���s��m�G", pos + 1);
    if (!vget(b_lines, 0, buf + 5, buf, 5, DOECHO))
	return XO_FOOT;

    newOrder = atoi(buf) - 1;
    if (newOrder < 0)
	newOrder = 0;
    else if (newOrder >= xo->max)
	newOrder = xo->max - 1;

    if (newOrder != pos) {
	dir = xo->dir;
	if (!rec_del(dir, sizeof(HDR), pos, NULL, NULL)) {
	    rec_ins(dir, ghdr, sizeof(HDR), newOrder, 1);
	    xo->pos = newOrder;
	    class_load(xo);
	    return class_body(xo);
	}
    }
    return XO_FOOT;
}

/* FIXME: unlink hdr->xname if it is folder, deal with folders inside, 
   watchout recursion */
static int
class_delete(XO *xo)
{
    HDR *ghdr;

    if(xo->key < GEM_MANAGER)
	return XO_NONE;

    ghdr = (HDR *)xo->xyz;
    ghdr += xo->pos;

    if (vans("�T�w�n�R���H[N] ") != 'y')
	return XO_FOOT;

    currchrono = ghdr->chrono;
    rec_del(xo->dir, sizeof(HDR), xo->pos, cmpchrono, NULL);
    class_load(xo);
    return class_body(xo);
}

/* fixme: use new xo->xyz */
#ifdef XXX0/* AUTHOR_EXTRACTION*/

static int
XoAuthor(XO *xo)
{
    int chn, len, max, tag;
    short *chp, *chead, *ctail;
    BRD *brd;
    char author[IDLEN + 1];
    XO xo_a, *xoTmp;

    if (!vget(b_lines, 0, "�п�J�@�̡G", author, IDLEN + 1, DOECHO))
	return XO_FOOT;

    str_lower(author, author);
    len = strlen(author);

    chead = (short *) xo->xyz;
    max = xo->max;
    ctail = chead + max;

    tag = 0;
    chp = (short *) malloc(max * sizeof(short));
    brd = bshm->bcache;

    do {
	if ((chn = *chead++) >= 0) {	/* Thor.0818: ���� group */
	    /* Thor.0701: �M����w�@�̤峹, ���h����m, �é�J */

	    int fsize;
	    char *fimage, folder[80];
	    HDR *head, *tail;

	    sprintf(folder, "�m�M����w�@�̡n�ݪ��G%s \033[5m...\033[m",
		    brd[chn].brdname);
	    outz(folder);
	    refresh();
	    brd_fpath(folder, brd[chn].brdname, fn_dir);

#ifdef HAVE_MMAP
	    fimage = f_map(folder, &fsize);

	    if (fimage == (char *) -1)
		continue;

	    head = (HDR *) fimage;
	    tail = (HDR *) (fimage + fsize);

	    while (head <= --tail) {
		if (tail->xmode & (POST_CANCEL | POST_DELETE))
		    continue;

		/* if(str_str(temp,author)) *//* Thor.0818:�Ʊ����� */

		if (!str_ncmp(tail->owner, author, len)) {
		    xo_get(folder)->pos = tail - head;
		    chp[tag++] = chn;
		    break;
		}
	    }

	    munmap(fimage, fsize);

#else
	    xo_t = xo_new(folder);
	    xo_t->pos = XO_TAIL;/* �Ĥ@���i�J�ɡA�N��Щ�b�̫᭱ */
	    xo_load(xo_t, sizeof(HDR));
	    if (xo_t->max <= 0)
		continue;
	    head = (HDR *) xo_pool;
	    tail = (HDR *) xo_pool + (xo_t->pos - xo_t->top);
	    for (;;) {
		if (!(tail->xmode & (POST_CANCEL | POST_DELETE))) {
		    /* check condition */
		    if (!str_ncmp(tail->owner, author, len)) {	/* Thor.0818:�Ʊ����� */
			xo_get(folder)->pos = tail - head;
			chp[tag++] = chn;
			break;
		    }
		}
		tail--;
		if (tail < head) {
		    if (xo_t->top <= 0)
			break;
		    xo_t->pos -= XO_TALL;
		    xo_load(xo_t, sizeof(HDR));
		    tail = (HDR *) xo_pool + XO_TALL - 1;
		}
	    }

	    free(xo_t);
#endif

	}
    } while (chead < ctail);

    if (!tag) {
	free(chp);
	vmsg("�ŵL�@��");
	return XO_FOOT;
    }

    xo_a.pos = xo_a.top = 0;
    xo_a.max = tag;
    xo_a.key = 1;		/* all boards */
    /*
     * Thor.990621: �Ҧ���class,board�C���U, key < 0, �H 1 �P
     *  XO_INIT(�ح���class_load), �p class_yank,
     * ���F�����X���@�̬ݪ��C������, �]����H
     */
    xo_a.xyz = (char *) chp;

    xoTmp = xz[XZ_CLASS - XO_ZONE].xo;	/* Thor.0701: �O�U��Ӫ�class_xo */

    xz[XZ_CLASS - XO_ZONE].xo = &xo_a;
    xover(XZ_CLASS);

    free(chp);

    xz[XZ_CLASS - XO_ZONE].xo = xoTmp;	/* Thor.0701: �٭� class_xo */

    return class_body(xo);
}
#endif


static KeyFunc class_cb[] =
{
    { XO_INIT, class_head },
    { XO_LOAD, class_body },
    { XO_HEAD, class_head },
    { XO_BODY, class_body },

    { Ctrl('P'), class_add },
    { 'M', class_move },
    { 'd', class_delete },

    { 'r', class_browse },
    { '/', class_search },
    { 'c', class_newmode },
    { 's', class_switch },

    { 'y', class_yank },
    { 'z', class_zap },
    { 'E', class_edit },

#ifdef XXX0 /*AUTHOR_EXTRACTION*/
    { 'A', XoAuthor },
#endif

    { 'h', class_help}
};


int
Class()
{
    XoClass("gem/@/@" CLASS_INIFILE, 
	    cuser.userlevel & PERM_BOARD ? GEM_SYSOP : 0);
    return 0;
}


int
Favorite()
{
    char fpath[80];
    if (!(cuser.userlevel & PERM_VALID)) {
	return 0;
    }
    class_flag |= BFO_FAVORITE;
    usr_fpath(fpath, cuser.userid, ".FAVOR");
    XoClass(fpath, GEM_MANAGER);
    class_flag ^= BFO_FAVORITE;
    return 0;
}

void
board_main()
{
    /* XXX: XZ_CLASS board_xo is not working for listing all boards */
    brh_load();

    if (!cuser.userlevel)
	class_flag = BFO_YANK;
    else
	class_flag = cuser.ufo & UFO_BRDNEW;
    board_xo = xo_new("");
    board_xo->pos = board_xo->top = 0;
    board_xo->key = 0;
    board_xo->xyz = 0;
    class_load(board_xo);

    xz[XZ_CLASS - XO_ZONE].xo = board_xo;
    xz[XZ_CLASS - XO_ZONE].cb = class_cb;

}

#ifdef	HAVE_ALLBOARDS
int
Boards()
{
  xover(XZ_CLASS);
  return 0;
}
#endif
