#ifndef	_BRH_H_
#define	_BRH_H_

/**
 * @file brh.h
 * @brief Board Reading History routines
 */

extern char brd_bits[MAXBOARD];
extern time_t brd_visit[MAXBOARD];

/**
 * Initiate brh
 */
void brh_load();

/**
 * Save brh for user
 */
void brh_save();

/**
 * Set current brh handler.
 * @param bstamp Board stamp
 * @param bhno Board number
 * @warning bstamp and bhno must match a certain board, or else a new
 * brh entry will be created 
 */
void brh_get(time_t bstamp, int bhno);

/**
 * Add a brh entry for current board handled.
 */
void brh_add(time_t prev, time_t chrono, time_t next);

/**
 * Test if an article is unread
 * @param chrono article id to be tested
 * @return true if the article is unread
 */
int brh_unread(time_t chrono);

/**
 * set flags for articles in current board
 * @param mode one of:
 * 0: read
 * 1: unread
 * chrono: read until chrono
 */
void brh_visit(int mode);

#endif	/* _BRH_H_ */
