#ifndef	_XOVER_H_
#define	_XOVER_H_

/**
 * @file xover.h
 * @brief Cross Over routines
 *
 * XO is a abstracted layer for manupilating listed items, in other
 * words, for building interactive menus.
 */

/**
 * @struct CrossOver xover.h
 * @brief XO entry
 * @warning Since xo->dir is char[0], xo with path must be allocated
 * by xo_new 
 * @see xo_new xover xo_get
 */
struct CrossOver {
    /** @brief Current position. */
    int pos;
    int top;
    int max;
    /** @brief Index key. Sometimes used to indicate permissions. */
    int key;
    /** @brief User allocated data. */
    char *xyz;
    struct CrossOver *nxt;
    /** @brief data path. */
    char dir[0];
};

/** @var typedef struct OverView XO */
typedef struct CrossOver XO;

typedef struct {
    int key;
    int (*func) ();
} KeyFunc;

typedef struct {
    XO *xo;
    KeyFunc *cb;
    int mode;
} XZ;

typedef struct {
    time_t chrono;
    int recno;
} TagItem;

#ifdef MODE_STAT
typedef struct {
    time_t logtime;
    time_t used_time[30];
} UMODELOG;

typedef struct {
    time_t logtime;
    time_t used_time[30];
    int count[30];
    int usercount;
} MODELOG;
#endif

/**
 * Allocate xo that has path
 */
XO *xo_new(char *path);

/**
 * @return The xo with specified \a path, or xo_new(\a path) if not found
 */
XO *xo_get(char *path);


void xo_load(XO *xo, int recsiz);
int xo_delete(XO *xo);
int Tagger(time_t chrono, int recno, int op);
void EnumTagHdr(HDR *hdr, char *dir, int locus);
int AskTag(char *msg);
int xo_uquery(XO *xo);
int xo_usetup(XO *xo);
int xo_getch(XO *xo, int ch);
void xover(int cmd);
void every_Z(void);

#endif	/* _XOVER_H_ */
