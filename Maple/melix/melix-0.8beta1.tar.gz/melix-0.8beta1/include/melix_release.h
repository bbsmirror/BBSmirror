#ifndef	_MELIX_RELEASE_H_
#define	_MELIX_RELEASE_H_

#define	MELIX_VERSION	"Melix / 0.8-beta1"

#endif
