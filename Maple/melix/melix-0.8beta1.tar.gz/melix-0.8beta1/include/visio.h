#ifndef	_VISIO_H_
#define	_VISIO_H_

/**
 * @file visio.h
 * @brief Virutal Screen I/O routines
 */

/**
 * Output data in printf format
 * @param fmt The format string
 * @param ... The argumets to use to fill out the format string
 */
void prints(const char *, ...);

/**
 * Generate bell
 */
void bell(void);

/**
 * move cursor
 * @param y or row
 * @param x or column
 */
void move(int y, int x);

/**
 * Retrieve cursor position
 * @param y Address to store y, or row
 * @param x Address to store x, or column
 */
void getyx(int *y, int *x);

/**
 * Refresh output buffer
 */
void refresh(void);


void clear(void);
void clrtoeol(void);
void clrtobot(void);
void outc(int ch);
void outs(char *str);
void outx(char *str);
void outz(char *msg);
void scroll(void);
void rscroll(void);
void cursor_save(void);
void cursor_restore(void);
void save_foot(screenline *slp);
void restore_foot(screenline *slp);
void vs_save(screenline *slp);
void vs_restore(screenline *slp);
int vmsg(char *msg);
void zmsg(char *msg);
void vs_bar(char *title);
void add_io(int fd, int timeout);
int igetch(void);

/**
 * Interactively ask a board from user (with auto-complete)
 * @param board Buffer to hold entered board name
 * @param perm Get only boards that user has the permission
 * @param msg Prompt message
 */
BRD *ask_board(char *board, int perm, char *msg);
int vget(int line, int col, char *prompt, char *data, int max, int echo);
int vans(char *prompt);
int vkey(void);

#endif	/* _VISIO_H_ */
