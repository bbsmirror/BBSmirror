/**
 * @file config.h
 * @brief system configuration
 */

#ifndef	_CONFIG_H_
#define	_CONFIG_H_

/**
 * @defgroup site_info Site information
 * @{
 */

/** @brief Site name */
#define BOARDNAME	"My Elixir BBS"

/** @brief Internet address */
#define MYHOSTNAME	"localhost"

/** @brief Home directory */
#define BBSHOME		"/home/melix"

/** @brief uid for running */
#define BBSUID		9997

/** @brief gid for running */
#define BBSGID		999

/** @brief default file permission mask */
#define	UMASK		007

/** @brief Mail authentication token */
#define TAG_VALID	"[melix]To "

/** @} end of site information */

/**
 * @defgroup system_prarm System parameters
 * @{
 */

#define	HAVE_MMAP		
#define	HAVE_SEM
#define BRDSHM_KEY	2997
#define UTMPSHM_KEY	1998
#define FILMSHM_KEY	2999
/** @brief Semaphore key */
#define	BSEM_KEY	2000
/** @brief Semaphore mode */
#define	BSEM_FLG	0600
#define BSEM_ENTER      -1
#define BSEM_LEAVE      1
#define BSEM_RESET	0

/** @} end of system parameters */

/**
 * @defgroup feature_set Features set
 * @{
 */

/** @brief Send email to registered user */
#undef	EMAIL_JUSTIFY

/** @brief Three-day access limits for new users */
#undef	NEWUSER_LIMIT

/** @brief Generate coredump
 * @note Remember to sysctl -w kern.sugid_coredump=1 on BSD */
#define	HAVE_COREDUMP		

/** @brief List all boards */
#define	HAVE_ALLBOARDS

/** @brief Enable anonymous board */
#define HAVE_ANONYMOUS

/** @brief Enable display user from info */
#define	HAVE_ORIGIN

/** @brief Enable sign outgoing mails */
#define HAVE_SIGNED_MAIL
#ifdef HAVE_SIGNED_MAIL
/** @brief Days for key regeneration */
#define PRIVATE_KEY_PERIOD 0
#endif

#undef SHOW_USER_IN_TEXT

#ifndef	SHOW_USER_IN_TEXT
#define outx	outs
#endif

/** Boards that bm could decide read list (set PERM_SYSOP in that board) */
#define	HAVE_MODERATED_BOARD

/** @brief Enable killing all articles with the same title */
#define	HAVE_TERMINATOR

#undef	LOGIN_NOTIFY

/** @brief Enable find all articles by a given user */
#define	AUTHOR_EXTRACTION

/** @brief Enable quick swtich ctrl-z everywhere */
#define EVERY_Z

#define EVERY_BIFF

/** @brief Log user mode statistic */
#undef	MODE_STAT

/** @brief Use color to emphasize some titles */
#define	HAVE_DECLARE

/** @brief Enable online notification */
#define HAVE_ALOHA

/** @brief Add color to article marks */
#define HAVE_DECORATE

/** @brief Enable group email */
#define MULTI_MAIL

/** @brief Enable register form */
#undef	HAVE_REGISTER_FORM

/** @brief Justify user periodically */
#undef	JUSTIFY_PERIODICAL

/** @brief Log permission alter */
#define	LOG_ADMIN

/** @brief Log user messages */
#define LOG_BMW

/** @brief Log user talk */
#define	LOG_TALK

/** @brief Log board usage */
#define	LOG_BRD_USIES

/** @brief Log group mails */
#define LOG_MULTIMAIL

/** @brief Max login attempts */
#define LOGINATTEMPTS	(3)

/** @brief Enable using `new' to register new user */
#define LOGINASNEW

/** @brief Enable change from temporarily with ^F */
#define HAVE_CHANGE_FROM

#undef COLOR_HEADER

#undef EMAIL_PAGE

/**
 * @bug clkao: broken! */
#undef	FRIEND_FIRST

/** @} end of feature set */

/**
 * @defgroup bbs_param BBS parameters
 * @{
 */

/** @brief Max boards */
#define MAXBOARD	(350)

/** @brief Max concurrent users */
#define MAXACTIVE	(300)

/** @brief Max messages (global) */
#define	BMW_MAX		128

/** @brief Max messages (per user) */
#define	BMW_PER_USER	9

#define	BMW_EXPIRE	(60)

/** @brief Mail quota */
#define	MAX_BBSMAIL	(3000)

#define	MAX_VALIDMAIL	(1000)

#define	MAX_NOVALIDMAIL	(100)

/** @brief Article expire */
#define MARK_DUE        1200
#define MAIL_DUE        600
#define FILE_DUE        300

/** @brief Max concurrent guest numbers
    @note Not implemented */
#define	MAXGUEST	(64)

/** @brief Max lines for signatures*/
#define MAXSIGLINES	(6)

/** @brief Max lines for user plan files */
#define MAXQUERYLINES	(17)

/** @brief Max items for poll */
#define	MAX_CHOICES	(32)

/** @brief Max tagged articles*/
#define	TAG_MAX		(256)

/** @brief Max pages for viewer (lines/22) */
#define	MAXPAGES	(256)

/** @brief Line edit input buffer */
#define MAXLASTCMD	(8)

/** @brief Max movie */
#define	MOVIE_MAX	(180)

/** @brief Movie cache size */
#define	MOVIE_SIZE	(108*1024)

/** @brief Max lines for movie */
#define MOVIE_LINES	(10)

#define	CHECK_PERIOD	(86400 * 20)

#define	VALID_PERIOD	(86400 * 180)

/** @brief Max user idle time */
#define IDLE_TIMEOUT	(60 * 24 * 7)

/** @brief Max real time news */
#define CNA_MAX         20

/** @} end of bbs parameters */

/**
 * for chat.c & xchatd.c
 */

#define CHAT_PORT	3838
#define CHAT_SECURE

#define EXIT_LOGOUT     0
#define EXIT_LOSTCONN   -1
#define EXIT_CLIERROR   -2
#define EXIT_TIMEDOUT   -3
#define EXIT_KICK       -4

#define CHAT_LOGIN_OK       "OK"
#define CHAT_LOGIN_EXISTS   "EX"
#define CHAT_LOGIN_INVALID  "IN"
#define CHAT_LOGIN_BOGUS    "BG"

/**
 * user real info
 */

#define REALINFO
#ifdef	REALINFO
/* post with real name */
#undef	POST_REALNAMES
/* mail with real name */
#undef	MAIL_REALNAMES
/* query with real name */
#undef	QUERY_REALNAMES
#endif

#endif	/* _CONFIG_H_ */
