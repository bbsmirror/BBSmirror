#ifndef	_ACCT_H_
#define	_ACCT_H_

/**
 * @file acct.h
 * @brief User account routines.
 */

/**
 * @strcut User account
 * @param userno Primary key, unique positive integer.
 * @param staytime Total stay time.
 * @param vtime validate time
 */

typedef struct {
    int userno;
    char userid[IDLEN + 1];
    char passwd[PASSLEN];
    uschar signature;
    char realname[20];
    char username[24];
    usint userlevel;
    int numlogins;
    int numposts;
    usint ufo;
    time_t firstlogin;
    time_t lastlogin;
    time_t staytime;
    time_t tcheck;		/* time to check mbox/pal */
    char lasthost[32];
    int numemail;		/* �H�o Inetrnet E-mail ���� */
    time_t tvalid;		/* �q�L�{�ҡB��� mail address ���ɶ� */
    char email[60];
    char address[60];
    char justify[60];		/* FROM of replied justify mail */
    char vmail[60];		/* �q�L�{�Ҥ� email */
    char ident[140 - 20];
    time_t vtime;
}      ACCT;

int acct_load(ACCT *acct, char *userid);
int acct_userno(char *userid);
int acct_get(char *msg, ACCT *acct);
int m_xfile(void);
usint bitset(usint pbits, int count, int maxon, char *msg, char *perms[]);
void acct_show(ACCT *u, int adm);
void acct_setup(ACCT *u, int adm);
int u_info(void);
int m_user(void);
int u_addr(void);
int u_setup(void);
int u_lock(void);
int u_xfile(void);
int m_newbrd(void);
void brd_edit(int bno);

#endif	/* _ACCT_H_ */
