#ifndef	_DAOMASK_H_
#define	_DAOMASK_H_
#include <sys/stat.h>

#define DAO_FILE_MODE	(~dao_umask & 0666)
#define	DAO_DIR_MODE	(~dao_umask & 0777)

extern mode_t dao_umask;
mode_t dao_set_umask(mode_t numask);

#endif
