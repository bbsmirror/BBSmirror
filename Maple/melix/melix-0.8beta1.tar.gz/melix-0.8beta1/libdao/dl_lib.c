/* ----------------------------------------------------- */
/* author : thor.bbs@bbs.cs.nthu.edu.tw                  */
/* target : dynamic link modules library for maple bbs   */
/* create : 99/02/14                                     */
/* update :   /  /                                       */
/* ----------------------------------------------------- */

#include <dlfcn.h>
#include <stdarg.h>
#include <strings.h>
#include <stdlib.h>

#ifndef RTLD_NOW
#define RTLD_NOW 1
#endif

typedef struct {
    char *path;
    void *handle;
} DL_list;

static DL_list *dl_pool;
static int dl_size, dl_head;

#define DL_ALLOC_MIN	5

#if 0
extern void blog(char *, char *);

#define TRACE blog
#endif

/* format: "Xmodule_path:Xname" */
void *
DL_get(char *name)
{
    char buf[512], *t;
    DL_list *p, *tail;

    strcpy(buf, name);
    if (!(t = strchr(buf, ':')))
	return NULL;

    *t++ = 0;

    if (!dl_pool) {
	/* Initialize DL entries */
	dl_size = DL_ALLOC_MIN;
	/* dl_head = 0 */
	dl_pool = (DL_list *) malloc(dl_size * sizeof(DL_list));
	if (!dl_pool)
	    exit(1);		/* Thor.991121: out of space */
    }

    p = dl_pool;
    tail = p + dl_head;
    while (p < tail) {
	if (!strcmp(buf, p->path))
	    break;
	p++;
    }

    if (p >= tail) {		/* not found */
	if (dl_head >= dl_size) {	/* not enough space */
	    dl_size += DL_ALLOC_MIN;
	    dl_pool = (DL_list *) realloc(dl_pool, dl_size * sizeof(DL_list));
	    if (!dl_pool)
		exit(1);	/* Thor.991121: out of space */
	    p = dl_pool + dl_head;	/* Thor.991121: to a new place */
	}
	p->handle = dlopen(p->path = strdup(buf), RTLD_NOW);
	dl_head++;
    }

    if (!p->handle)
	return NULL;

    return dlsym(p->handle, t);
}

int
DL_func(char *name, ...)
{
    va_list args;
    int (*f) (), ret;

    va_start(args, name);

    if (!(f = DL_get(name))) {	/* not get func */
	return -1;
    }

    ret = (*f) (args);
    va_end(args);

    return ret;
}
