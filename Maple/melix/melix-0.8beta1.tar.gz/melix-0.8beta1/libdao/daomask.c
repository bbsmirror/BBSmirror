#include "daomask.h"

mode_t dao_umask = 0012;

mode_t
dao_set_umask(mode_t numask)
{
    mode_t old = dao_umask;
    dao_umask = numask;
    return old;
}
