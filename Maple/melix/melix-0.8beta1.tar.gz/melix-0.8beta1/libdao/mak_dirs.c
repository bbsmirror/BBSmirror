/* ----------------------------------------------------- */
/* make directory hierarchy [0-9A-V] : 32-way interleave */
/* ----------------------------------------------------- */


#include <sys/stat.h>
#include "daomask.h"

void
mak_dirs(fpath)
    char *fpath;
{
    char *fname;
    int ch;

    if (mkdir(fpath, DAO_DIR_MODE))
	return;

    fname = fpath;
    while (*++fname);
    *fname++ = '/';
    fname[1] = '\0';

    ch = '0';
    for (;;) {
	*fname = ch++;
	mkdir(fpath, DAO_DIR_MODE);
	if (ch == 'W')
	    break;
	if (ch == '9' + 1)
	    ch = '@';		/* @ : for special purpose */
    }

    fname[-1] = '\0';
}
