#include <fcntl.h>
#include <unistd.h>
#include "daomask.h"

void
f_cat(fpath, msg)
    char *fpath;
    char *msg;
{
    int fd;

    if ((fd = open(fpath, O_WRONLY | O_CREAT | O_APPEND, DAO_FILE_MODE)) >= 0) {
	write(fd, msg, strlen(msg));
	close(fd);
    }
}
