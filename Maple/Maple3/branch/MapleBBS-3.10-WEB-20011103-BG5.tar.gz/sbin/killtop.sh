#!/bin/sh
kill -9 `top | grep bbsd |grep RUN | awk '{print $1}'`
