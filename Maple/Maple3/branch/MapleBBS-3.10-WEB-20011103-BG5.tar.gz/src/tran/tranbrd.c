/*----------------------------------------------------------*/
/*  tran/tranbrd.c			                    */
/*----------------------------------------------------------*/
/* �@��: hightman@263.net                                   */
/* �γ~: firebird 3.0 �� Maple 3.x ��������ഫ             */
/*          [boards] => brd/			            */
/* ���: 00/11/22                                           */
/*----------------------------------------------------------*/
/* syntax : tranbrd                                         */
/*----------------------------------------------------------*/ 

#include "tran.h"

struct fileheader {             /* FireBird���峹.DIR����Ƶ��c */
        char filename[STRLEN]; 
        char owner[STRLEN];
        char title[STRLEN];
        unsigned level;
        unsigned char accessed[ 12 ];   /* struct size = 256 bytes */
} ;
typedef struct fileheader oldheader;

void
bdir(board)
  char *board;
{
  char pnew[256], pold[256];

  char *ptr, *owner, *left, *right, buf[128];
  oldheader xold;
  HDR xnew;
  int fdr, fdw, fdx, chrono;
  int cold, cnew;
  struct tm *ptime;
  struct stat st;

  printf("\n%s\n", board);	/* report */

  sprintf(pold, "%s/boards/%s/.DIR",FB, board);
  fdr = open(pold, O_RDONLY);
  if (fdr < 0)
  {
    printf("\tError : %s\n", pold);
    return;
  }

  sprintf(pnew, "brd/%s", board);
  mkdir(pnew, 0700);
  fdw = '0';
  for (;;)
  {
    sprintf(pnew, "brd/%s/%c", board, fdw);
    mkdir(pnew, 0700);
    if (fdw == '9')
      fdw = '@';
    else
    {
      if (++fdw == 'W')
	break;
    }
  }

  sprintf(pnew, "brd/%s/.DIR", board);
  fdw = open(pnew, O_WRONLY | O_CREAT | O_TRUNC, 0600);
  if (fdw < 0)
  {
    close(fdr);
    printf("\tError : %s\n", pnew);
    return;
  }

  cold = cnew = 0;
  chrono = 0x100000;

  while (read(fdr, &xold, sizeof(xold)) == sizeof(xold))
  {
    cold++;
    memset(&xnew, 0, sizeof(xnew));
    chrono++;
    /*chrono = xold.chrono;
    */
    archiv32m(chrono, xnew.xname);

    sprintf(pold, "%s/boards/%s/%s", FB, board, xold.filename);
    stat(pold, &st);
    sprintf(pnew, "brd/%s/%c/%s", board, xnew.xname[7], xnew.xname);

    if (link(pold, pnew))
    {
      fdx = open(pnew, O_RDONLY);
      if (fdx < 0)
      {
	printf("\tFile : %s\n", pnew);
	continue;
      }

      read(fdx, buf, sizeof(buf));
      close(fdx);

      if (ptr = strchr(buf, '\n'))
        *ptr = 0;

      owner = xold.owner;
      if (strchr(owner, '.'))	/* inn ==> bbs */
      {
        xnew.xmode = (xold.accessed[0]/4) | POST_INCOME;
	
        xnew.xid = 0;

 	if (*owner != '.' && buf[6] == ':')
	{
	  owner = buf + 8;

	  ptr = strchr(owner, ' ');
	  *ptr++ = '\0';

	  if (left = strchr(ptr, '('))
	  {
	    if (right = strrchr(++left, ')'))
	    {
	      *right = 0;
	      strcpy(xnew.nick, left);
	    }
	  }

	}
      }
      else
      {
        xnew.xmode = (xold.accessed[0])/4;
	xnew.xid = 0x80000000;

 	if (buf[4] == ':')
	{
	  owner = buf + 6;

	  ptr = strchr(owner, ' ');
	  *ptr++ = '\0';

	  if (left = strchr(ptr, '('))
	  {
	    if (right = strrchr(++left, ')'))
	    {
	      *right = 0;
	      strcpy(xnew.nick, left);
	    }
	  }
	}
      }

      strcpy(xnew.owner, owner);

      xnew.chrono = chrono;

      strcpy(xnew.owner, owner);

      strcpy(xnew.title, xold.title);

	ptime = localtime(&st.st_mtime);
	sprintf(xnew.date, "%02d/%02d/%02d",
	  ptime->tm_year%100, ptime->tm_mon + 1, ptime->tm_mday);

      write(fdw, &xnew, sizeof(xnew));
      cnew++;
    }
  }

  close(fdr);
  close(fdw);
  printf("\tTran : %d ==> %d\n", cold, cnew);

  sprintf(pold, "%s/boards/%s/notes", FB, board);
  sprintf(pnew, "brd/%s/note", board);
  link(pold, pnew);

  sprintf(pold, "%s/boards/%s/results", FB, board);
  sprintf(pnew, "brd/%s/@/@vote", board);
  link(pold, pnew);
}


int
main(argc, argv)
  int argc;
  char *argv[];
{
  DIR *dirp;
  struct dirent *de;
  char *fname;
  char buf[128];

  mkdir("brd", 0700); 
  sprintf(buf,"%s/boards",FB);  
 
  if (argc > 1)
  {
    bdir(argv[1]);
    exit(0);
  }

  if (!(dirp = opendir(buf)))
  {
    printf("## unable to enter [boards]\n");
    exit(-1);
  }

  while (de = readdir(dirp))
  {
    fname = de->d_name;
    if (*fname != '.')
    {
      bdir(fname);
    }
  }

  closedir(dirp);
  exit(0);
}
