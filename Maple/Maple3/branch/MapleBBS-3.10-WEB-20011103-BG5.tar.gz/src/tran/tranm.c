/*----------------------------------------------------------*/
/*  tran/tranm.c			                    */
/*----------------------------------------------------------*/
/* �@��: hightman@263.net                                   */
/* �γ~: firebird 3.0 �� Maple 3.x ��ذϡA�����ݪO�ഫ     */
/*          0Announce => gem/ @Clas�����ݪO                 */
/* ���: 00/11/22                                           */
/* �Ѧ�: util/tranman.c         ernie@micro8.ee.nthu.edu.tw */
/*----------------------------------------------------------*/
/* syntax : tranm                                           */
/*----------------------------------------------------------*/ 
#include "tran.h"

/* �@���ܶq */
int ndir;
int nfile;
int ngopher;
time_t chrono;
int level;
char gpath[1024];
char tmp_name[128];

int mandex(char *board, char *fpath, int deep);
int Names_class(char *fpath) ;

/* ------------------------------------------------------------- */
/* �W�[gem/.DIR	����gem/@/@Class������ 				 */
/* ------------------------------------------------------------- */
int new_class()   /* �W�[Class�`��� */
{
 HDR ghdr;
 char title[30];
 int fd;

 fd = -1;
 memset(&ghdr, 0, sizeof(HDR));

 sprintf(title, "�����U�j�ݪO���");  /* ���D�W�r */
 sprintf(ghdr.owner, SYSOP);
 sprintf(ghdr.nick, OPNICK);
 sprintf(ghdr.date, DATE);

 time(&ghdr.chrono);
 sprintf(ghdr.xname, "@Class");

 sprintf(ghdr.title, "%-13s�i %s �j", "Class/", title);
 ghdr.xmode = GEM_FOLDER;
 
 if ((fd = open("gem/.DIR", O_WRONLY | O_CREAT | O_APPEND, 0600)) < 0)
  return -1;
   write(fd, &ghdr, sizeof(HDR));
   close(fd);
 printf("Done! New Class..!\n");
 return 0;
}


/* ------------------------------------------------------------- */
/* Tran_Group				 			 */
/* ------------------------------------------------------------- */

int tran_group(title, fname, flag)
char title[73];  /* ���D */
char fname[32];  /* �ɦW GROUP_X */
int flag;
{
HDR ghdr;
int fd;
char buf[1024];

if (!flag) return;   /* flag��0,���ഫ */
fd = -1;
memset(&ghdr, 0, sizeof(HDR));

sprintf(ghdr.owner, SYSOP);
sprintf(ghdr.nick, OPNICK);
sprintf(ghdr.date, DATE);

time(&ghdr.chrono);

if(flag == 1)
 {
      strcpy(tmp_name, fname);   /* �]��fname �n�[ / */
      sprintf(ghdr.xname, "@%s", fname);
      strcat(fname, "/");
      sprintf(ghdr.title, "%-13s�i %s �j", fname, title);
      ghdr.xmode = GEM_FOLDER;
     if ((fd = open("gem/@/@Class", O_WRONLY | O_CREAT | O_APPEND, 0600)) < 0)
     {
       printf("\t#Cant not open %s!","gem/@/@Class");
       return -1;
      }
      write(fd, &ghdr, sizeof(HDR));
      close(fd);
      printf("\t#Tran  %s...Done!\n",title);
      sprintf(buf,"%s/0Announce/groups/%s%s",FB, tmp_name, fn_names);
      Names_class(buf);
}

else if(flag == 2)   /* �઩�� */
  {
   strcpy(ghdr.xname, fname);   /* ���W �psysop */
   sprintf(ghdr.title, "%-16s%s", fname,title); /* ����y�z �p �����u�@�� */
   ghdr.xmode = GEM_BOARD | GEM_FOLDER;
   sprintf(buf,"gem/@/@%s",tmp_name);

     if ((fd = open(buf, O_WRONLY | O_CREAT | O_APPEND, 0600)) < 0)
     {
       printf("\t\t#Cant not open %s!",buf);
       return -1;
      }
      write(fd, &ghdr, sizeof(HDR));
      close(fd);
      printf("\t\t#Tranbrd  %s...Done!\n",fname);

      sprintf(buf,"%s/0Announce/groups/%s/%s%s", FB, tmp_name, fname, fn_names);
      mandex(fname, buf, 0);
 }
return 0;
}

/* ------------------------------------------------------------- */
/* Ū��.Names ����Names Path ...	 			 */
/* ------------------------------------------------------------- */
int Names_class(char *fpath)  /* Ū��.Names ����Names Path ... */
{

 FILE *fn;
 char buf[256]; /* �@��@�檺Ū */
 char *str,*ptr;
 char title[73],fname[32];

 int flag;   /* do tran? */

 fn = fopen(fpath, "r");

 while (fgets(buf, sizeof(buf), fn))
   {

    flag = 0;
    ptr = buf + 5;  /* ���� Name= Path= �p5�Ӧr�� */

      if (str = strchr(ptr, '\n'))
           *str = '\0';

    if (!memcmp(buf, "Name=", 5))
      {
        if (!memcmp(ptr, "�� ", 3) ||
                 !memcmp(ptr, "�� ", 3) || !memcmp(ptr, "�� ", 3))
            {
              ptr += 3;
             }
        if(*ptr == '\0')
           strcpy(title, "�٨S�W�r�O");
        else
        str_ncpy(title,ptr,sizeof(title));
      }

    else if(!memcmp(buf,"Path=",5))  /* ���| */

       {
          ptr += 2;
          if(!memcmp(ptr,"../",3) || (*ptr == '/') || !strcmp(ptr, ".index")
                   || (*ptr == '\0'))
           {
             printf("\t#skip: %s, %s\n", fpath, ptr);
            continue;
           }
         str_ncpy(fname, ptr, sizeof(fname));
         if(strstr(fname,"GROUP")) /* �OClass���Oboard */
            flag = 1;
         else 
           flag = 2;
      }

   tran_group(title,fname,flag);

    }
 fclose(fn);
 return;
 }


/* ------------------------------------------------------------- */
/* ��GROUP_X�������Q�װ�					 */
/* ------------------------------------------------------------- */

int group_class ()

 {
  char fpath[1024];
  sprintf(fpath, "%s/0Announce/groups/%s", FB, fn_names);
  Names_class(fpath);
  return;
}


/* ------------------------------------------------------------- */
/* ���0Announce/�U�Dgroups�ɮ�					 */
/* ------------------------------------------------------------- */

int
mandex(board, fpath, deep)
  char *board;
  char *fpath;
  int deep;
{
  FILE *fgem, *fxx;
  char *fname, *gname, *ptr, *str, buf[256], site[64];
  struct stat st;
  int cc, xmode, gport;
  HDR ghdr;

  if (board)
  {
      level = 0;
    if (strcmp(board,NOBOARD))    /* �����ݪO����ذ� */
      { 
      printf("\n%s\n", board);
      sprintf(gpath, "gem/brd/%s", board);
      mkdir(gpath, 0700);
     }
    cc = '0';
    for (;;)
      {
        if (!strcmp(board,NOBOARD))  /* �D�����ݪO����ذ� */
          sprintf(gpath, "gem/%c",  cc);
        else
          sprintf(gpath, "gem/brd/%s/%c", board, cc);

      mkdir(gpath, 0700);
      if (cc == '9')
        cc = '@';
      else
      {
        if (++cc == 'W')
          break;
      }
    }
    
     if (!strcmp(board,NOBOARD))  /* �D�����ݪO����ذ� */
        sprintf(gpath, "gem/.DIR"); 
     else
        sprintf(gpath, "gem/brd/%s/.DIR", board);

    ndir = nfile = ngopher = 0;
    chrono = GEM_INIT;
  }

  gname = strrchr(gpath, '/');

  if (!gname)
    return -1;
 if (gname[1] == '.')
    gname++;
  else
    gname--;

  fxx = fopen(gpath, "a");
  if (!fxx)
  {
    printf("\topen: %s\n", gpath);
    return -1;
  }

  fgem = fopen(fpath, "r");
  if (fgem == NULL)
  {
    printf("\tfopen: %s\n", fpath);

    fclose(fxx);
    return -1;
  }
  if (deep > level)
    level = deep;

  gport = -1;
  fname = strrchr(fpath, '.');

  while (fgets(buf, sizeof(buf), fgem))
  {
    if (gport < 0)
    {
      *fname = xmode = gport = 0;
      memset(&ghdr, 0, sizeof(HDR));
    }

    ptr = buf + 5;
    if (str = strchr(buf, '\n'))
      *str = '\0';

    if (!memcmp(buf, "Name=", 5))
    {
     if (!memcmp(ptr, "�� ", 3) || !memcmp(ptr, "�� ", 3) || !memcmp(ptr, "�� ", 3) || !memcmp(ptr, "�� ", 3) || !memcmp(ptr, "�� ", 3))
     {
        ptr += 3;
      }
      else if (!memcmp(ptr, "�� ", 3) || !memcmp(ptr, "�� ", 3))
      {
        ptr += 3;
        gport = 70;
      }

      if (*ptr == '#')
      {
        if (*++ptr == ' ')
          ptr++;
        xmode = GEM_RESTRICT;
      }

      strcpy(ghdr.title, ptr);
    }
    else if (!memcmp(buf, "Edit=", 5))  /* server */
    {
     if (gport)
      {
        str = site;
        do
        {
          cc = *ptr++;
          if (cc >= 'A' && cc <= 'Z')
            cc |= 0x20;
          *str++ = cc;
        } while (cc);
      }
      else
      {
        strcpy(ghdr.owner, ptr);
      }
    }
    else if (!memcmp(buf, "Date=", 5))  /* port */
    {
      if (gport)
        gport = atoi(ptr);
      else if (ptr[2] != '/' || ptr[5] != '/')
        strcpy(ghdr.date, ptr);
    }
    else if (!memcmp(buf, "Path=", 5))
    {
      ptr += 2; /* ���L ~/ */

      if (!memcmp(ptr, "../", 3) || (*ptr == '/') || !strcmp(ptr, ".index"))
      {
        printf("\tskip: %s, %s\n", fpath, ptr);  /* ����s�u�� */
        gport = -1;
        continue;
      }
     if(!memcmp(ptr,"groups", 6) && deep == 0)
       {
         printf("GROUPS!�S���B�z! wait...\n");
         group_class();
         gport = -1;
         continue;
      }
      ghdr.chrono = ++chrono;

      if (gport)
      {
        ghdr.xid = gport;
        xmode = GEM_GOPHER;
        if (*ptr == '1')
          xmode |= GEM_FOLDER;
        sprintf(ghdr.xname, "%s/%s", site, ptr);
        ngopher++;
      }
      else
      {
        strcpy(fname, ptr);

        if (stat(fpath, &st))
        {
          printf("\tstat: %s\n", fpath);
          gport = -1;
          continue;
        }

        archiv32(chrono, gname + 3);
        *gname = gname[9];
        gname[1] = '/';

        str = ghdr.date;
        if (!*str)
        {
          struct tm *p = localtime(&st.st_mtime);
          sprintf(str, "%02d/%02d/%02d", p->tm_year%100, p->tm_mon + 1, p->tm_mday);
        }

        if (S_ISREG(st.st_mode))        /* file */
        {
          gname[2] = 'A';
          strcpy(ghdr.xname, gname + 2);
          link(fpath, gpath);
          nfile++;
        }
        else if (S_ISDIR(st.st_mode))   /* dir */
        {
          gname[2] = 'F';
          strcpy(ghdr.xname, gname + 2);
          strcat(fpath, fn_names);
          if (mandex(NULL, fpath, deep+1))
          {
            gport = -1;
            continue;

          }
          xmode |= GEM_FOLDER;
          ndir++;
        }
        else
        {
          gport = -1;
          continue;
        }
      }

      ghdr.xmode = xmode;

      fwrite(&ghdr, sizeof(HDR), 1, fxx);
      gport = -1;
    }
  }

  fclose(fxx);
  fclose(fgem);

  if (board)                    /* report */
  printf("\td: %d\tf: %d\tg: %d (%d)\n", ndir, nfile, ngopher, level);

  return; 
}

int
main()
{
   char fpath[1024];
   mkdir("gem", 0700);
   mkdir("gem/@", 0700);  
   mkdir("gem/brd", 0700);
   new_class();  /* �Ы�@Class */
   sprintf(fpath, "%s/0Announce%s", FB, fn_names);
   mandex(NOBOARD, fpath, 0);
   return;
}
