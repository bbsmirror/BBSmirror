/*----------------------------------------------------------*/
/*  tran/trandotbrd.c			                    */
/*----------------------------------------------------------*/
/* �@��: hightman@263.net                                   */
/* �γ~: firebird 3.0 �� Maple 3.x �ݪO���c                 */
/*          .BOARDS => .BRD  �t�H��Añ�W��                 */
/* ���: 00/11/22                                           */
/*----------------------------------------------------------*/
/* syntax : trandotbrd                                      */
/*----------------------------------------------------------*/ 
#include "tran.h"

BRD allbrd[MAXBOARD];

typedef struct boardheader {        /* This structure is used to hold data in */
        char filename[STRLEN];   /* the BOARDS files */
        char owner[STRLEN - BM_LEN];
        char BM[ BM_LEN - 1];
        char flag;
        char title[STRLEN ];
        unsigned level;
        unsigned char accessed[ 12 ];
} boardheader;

typedef struct _PERM
{
  int old;
  int new;
} PERM;

static PERM flag[] =
{
  { 0x2,BRD_NOZAP },
  { 0x8,BRD_ANONYMOUS },
  { 0x4,BRD_NOTRAN }
 };



static PERM perm[] =
{
  {0x00000001, PERM_BASIC},             /* BASIC */
  {0x00000002, PERM_CHAT},              /* CHAT */
  {0x00000004, PERM_PAGE},              /* PAGE */
  {0x00000008, PERM_POST},              /* POST */
  {0x00000010, PERM_VALID},             /* LOGIN */
  {0x00000020, PERM_DENYPOST},          /* DENYPOST */
  {0x00000040, PERM_CLOAK},             /* CLOAK */
  {0x00000080, PERM_SEECLOAK},          /* SEECLOAK */
  {0x00000100, PERM_XEMPT},             /* XEMPT */
  {0x00000400, PERM_BM},                /* BM */
  {0x00000800, PERM_ACCOUNTS},          /* ACCOUNTS */
  {0x00001000, PERM_CHATROOM},          /* CHATROOM */
  {0x00002000, PERM_BOARD},             /* BOARD */
  {0x00004000, PERM_SYSOP}              /* SYSOP */
};


int
board_cmp(a, b)
  BRD *a, *b;
{
  return (strcasecmp(a->brdname, b->brdname));
}


main()
{
  int inf, outf, i, count;
  int j;
  char buf[256], *str;
  char *bm;
  boardheader mybh;
  PERM *p;

  sprintf(buf, "%s/.BOARDS", FB);

  inf = open(buf, O_RDONLY);

  sprintf(buf, ".BRD");
  outf = open(buf, O_WRONLY | O_CREAT | O_TRUNC, 0644);
  if (inf == -1 || outf == -1)
  {
    printf("error open file\n");
    exit(1);
  }

  /* read in all boards */
  i = 0;
  memset(allbrd, 0, MAXBOARD * sizeof(BRD));
  while (read(inf, &mybh, sizeof(mybh)) == sizeof(mybh))
  {
    str = mybh.title;
    if (mybh.filename[0])
    {
      allbrd[i].bstamp = i + 0x100;		/* �ݪO�إ߮ɶ� */

      strcpy(allbrd[i].brdname, mybh.filename);	/* �O�W(ENGLISH) */

      str += 10;
      if (mybh.flag |= 0x4 ) 
         sprintf(allbrd[i].title,"%s%s","��", str);             /* �O�O���D */
      else
          sprintf(allbrd[i].title,"%s%s","��", str);             /* �O�O���D */

      if (mybh.BM[0] > ' ')		/*���O�D*/
       { 
         bm = mybh.BM;   /* hightman: �ഫ , -> / */
         for (j=0; bm[j] != '\0'; j++)
          if(bm[j] == ',') bm[j] = '/';
           strcpy(allbrd[i].BM,bm);		/* �O�D */
        }
       for(p=flag;p->old;p++)   /* �ݪ��ݩ� */
      {
       if(mybh.flag & p->old)
       allbrd[i].battr |= p->new;
       }

      if(!strcmp(mybh.filename, "Test")||!strcmp(mybh.filename, "test"))
        allbrd[i].battr |= BRD_NOCOUNT;/*���p�峹��*/
      
      allbrd[i].readlevel = 0;	/* Ū�v */
     for(p=perm;p->old;p++)
   {
     if(mybh.level & p->old)
       allbrd[i].readlevel |= p->new;
   }      

      allbrd[i].postlevel = allbrd[i].readlevel;	/* �g�v */

      i++;
    }
  }
  close(inf);

  /* sort them by name */

  count = i;
  qsort(allbrd, count, sizeof(BRD), board_cmp);

  /* write out the target file */

  printf(
    "�ݪO�W��     �O�D                     ����ԭz\n"
    "----------------------------------------------------------------------\n");
  for (i = 0; i < count; i++)
  {
  write(outf, &allbrd[i], sizeof(BRD));
  printf("%-13s%-25.25s%s\n", allbrd[i].brdname, allbrd[i].BM, allbrd[i].title);
  }

  close(outf);
  exit(0);
}
