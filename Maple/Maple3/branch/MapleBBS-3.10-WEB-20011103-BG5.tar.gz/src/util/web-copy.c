/*-------------------------------------------------------*/
/* util/web-copy.c                                       */
/*-------------------------------------------------------*/
/* author : hightman.bbs@bbs.dot66.net         		 */
/* target : �۰ʧ��Nju��WebBBS�W���峹	                 */
/* create : 2001/07/08                                   */
/* update :                                              */
/*-------------------------------------------------------*/
/* syntax : web-copy	                                 */
/*-------------------------------------------------------*/

#include "bbs.h"

char *iconf[]={
	/* url  ���g(�Ĥ@��) ��i�� */			 
	"http://bbs.nju.edu.cn/cgi-bin/bbs/	bbsdoc?board=BBSDev	BBS_plan",
	"http://bbs.nju.edu.cn/cgi-bin/bbs/	bbsdoc?board=WWW		WebWW",
	"http://bbs.nju.edu.cn/cgi-bin/bbs/	bbsdoc?board=ASCIIArt	Asciiart",
	"http://bbs.nju.edu.cn/cgi-bin/bbs/	bbsdoc?board=Feeling	Netfeeling",
	"http://bbs.nju.edu.cn/cgi-bin/bbs/	bbsdoc?board=GreatTurn	Riddle",
	"http://bbs.nju.edu.cn/cgi-bin/bbs/	bbsdoc?board=Love	HowLove",
	"http://bbs.nju.edu.cn/cgi-bin/bbs/	bbsdoc?board=Single	yzh",
	"http://bbs.nju.edu.cn/cgi-bin/bbs/	bbsdoc?board=Riddle	Riddle",
	"http://bbs.nju.edu.cn/cgi-bin/bbs/	bbsdoc?board=Joke	Humor",
	NULL
};
char tmppath[] = "tmp/tmp0.txt";
/*
  tmp/boardname.ini
  http://bbs.nju.edu.cn/cgi-bin/bbs/a/bbscon?BBSDev/M.989929762.A=3596
*/

void
archiv32m(chrono, fname)
  register time_t chrono;       /* 32 bits */
  register char *fname;         /* 7 chars */
{
  register char *str;
  register int n;

  str = fname + 8;
  *str = '\0';
  *fname = 'A';
  while (--str > fname)
  {
    n = chrono & 31;
    n += '0';
    if (n > '9')
      n += 'A' - '9' - 1;
    *str = n;
    chrono >>= 5;
  }
}


char *rstrstr(char *s, char *s2) {
	int i, len1=strlen(s), len2=strlen(s2);
	for(i=len1-len2; i>0; i--)
		if(!strncmp(s+i, s2, len2)) return s+i;
	return 0;
}

char *h2ansi(char *s) {
	static char buf[512];
	char *t, *kl, *kr;
	bzero(buf, 500);
	while(1) {
		t=strstr(s, "&lt;");
		if(t==0) break;
		memcpy(t, " �q  ", 4);
	}
	while(1) {
		t=strstr(s, "&gt;");
		if(t==0) break;
		memcpy(t, " �r  ", 4);
	}
	while(1) {
		kl=strstr(s, "<");
		if(kl==0) {
			strcat(buf, s);
			return buf;
		}
		kr=strstr(s, ">");
		if(kr==0) {
			strcat(buf, s);
			return buf;
		}
		kl[0]=0;
		strcat(buf, s);
		s=kr+1;
		if(strlen(buf)>256) return buf;
	}
}

int main() {
	int i, r;
	char path[80], oboard[80], iboard[80];
	chdir(BBSHOME);
	for(i=0; iconf[i]!=0; i++) {
		r=sscanf(iconf[i], "%s %s %s", path, oboard, iboard);
		if(r<3) continue;
		get_mail(path, oboard, iboard, time(0));
	}
}

int get_mail(char *path, char *oboard, char *iboard, int last) {
	FILE *fp;
	int i, size;
	char *s, *s2, buf[256], buf2[1000000], host[256];
	sprintf(buf, "wget -q %s%s -O tmp/tmp1.txt", path, oboard);
	system(buf);
	fp=fopen("tmp/tmp1.txt", "r");
	bzero(buf2, 20000);
	size=fread(buf2, 1, 20000, fp);
	fclose(fp);
	s=rstrstr(buf2, "bbscon");
	if(s==0) return;
	s2=strtok(s, "\"<>' ");
	sprintf(buf, "%s%s", path, s2);
	printf("[%s]\n", buf);
	get_mail2(path, s2, iboard, last);
	return;
}

int get_mail2(char *path, char *url, char *iboard, int last) {
	FILE *fp, *fp2;
	HDR x;
	char *s, *s2, buf[512], buf2[256], userid[100]="unknown", title[100]="unknown";
	char folder[128],fpath[128];
	printf("getmail2:%s\n", url);
	s=strstr(url, "M.");
	if(s==0) return;
	if(atoi(s+2)>=last) return;
	last=atoi(s+2);
	if(last<time(0)-86400) return;
	if(!good_url(url)) return;
	bzero(&x, sizeof(x));
	printf("Start getting...\n");
	sprintf(buf, "wget -q '%s%s' -O tmp/tmp1.txt", path, url);
	system(buf);
	printf("Get End...\n");
	fp=fopen("tmp/tmp1.txt", "r");
	fp2=fopen(tmppath, "w");
	if(fp==0) return;
	while(1) {
		bzero(buf, 501);
		if(fgets(buf, 500, fp)==0) break;
		if(strstr(buf, "<pre>")) break;
	}
	if(fgets(buf, 100, fp)) {
		buf[100]=0;
		sscanf(buf, "�o�H�H: %s", userid);
		strcat(userid, ".");
		fprintf(fp2, "%s", buf);
	}
	if(fgets(buf, 100, fp)) {
		buf[100]=0;
		if(s=strstr(buf, "��  �D: ")) strcpy(title, s+8);
		//sscanf(buf, "��  �D: %s\n", title);
		fprintf(fp2, "%s", buf);
	}
	while(1) {
		bzero(buf, 501);
		if(fgets(buf, 500, fp)==0) break;
		if(strstr(buf, "</pre>")) break;
		fprintf(fp2, "%s", h2ansi(buf));
	}
	fclose(fp2);

	x.chrono = last;
	x.xmode = 0;
    archiv32m(x.chrono, x.xname);
    sprintf(fpath, "brd/%s/%c/%s", iboard, x.xname[7], x.xname);
	f_mv(tmppath, fpath);
	str_stamp(&x.date, &x.chrono);
	brd_fpath(folder, iboard, FN_DIR);

	sleep(1);
	while(1) {
		bzero(buf, 501);
		s=fgets(buf, 500, fp);
		if(s==0) {
			fclose(fp);
			break;
		}
		s=strstr(buf, ">�W�@�g<");
		if(s) {
			fclose(fp);
			s=strstr(buf, "bbscon");
			if(s) {
				s2=strtok(s, "\"<>' ");
				get_mail2(path, s2, iboard, last);
			}
			break;
		}
	}
	strncpy(x.owner, userid, 55);
	strncpy(x.title, title, 60);
	chkstr(x.owner);
	chkstr(x.title);
	rec_add(folder, &x, sizeof(HDR));
}

int f_exist(char *file) {
	struct stat buf;
	if(stat(file, &buf)==-1) return 0;
	return 1;
}

int good_url(char *s) {
	int i, c;
	for(i=0; s[i]; i++) {
		c=s[i];
		if(c>='A' && c<='Z') continue;
		if(c>='a' && c<='z') continue;
		if(c=='=' || c=='.' || c=='_' || c=='/' || c=='?') continue;
		if(c>='0' && c<='9') continue;
		printf("bad!\n");
		return 0;
	}
	return 1;
}

int chkstr(unsigned char *s) {
	int i;
	for(i=0; s[i]; i++)
		if(s[i]<32 || s[i]==255) s[i]=32;
}
