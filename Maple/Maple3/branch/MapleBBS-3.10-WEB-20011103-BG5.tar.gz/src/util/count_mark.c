/* 2001.10.25
 * write by hightman
 * for �έp�X��m�峹�ƨåBpost��ݪO�M��ذ�
 */

#include <sys/ipc.h>
#include "bbs.h"

static BCACHE *bshm;
          
static void
attach_err(shmkey, name)
  int shmkey;
  char *name;
{ 
  fprintf(stderr, "[%s error] key = %x\n", name, shmkey);
  exit(1); 
} 


static void *
attach_shm(shmkey, shmsize)
  register int shmkey, shmsize;
{
  register void *shmptr;
  register int shmid;

  shmid = shmget(shmkey, shmsize, 0);
  if (shmid < 0)
  {
    shmid = shmget(shmkey, shmsize, IPC_CREAT | 0600);
    if (shmid < 0)
      attach_err(shmkey, "shmget");
  }
  else
  {
    shmsize = 0;
  }

  shmptr = (void *) shmat(shmid, NULL, 0);
  if (shmptr == (void *) -1)
    attach_err(shmkey, "shmat");

  if (shmsize)
    memset(shmptr, 0, shmsize);

  return shmptr;
}


/* static */
void
bshm_init()
{
  register BCACHE *xshm;
  register time_t *uptime;
  register int n, turn;

  turn = 0;
  xshm = bshm;
  if (xshm == NULL)
  {
    bshm = xshm = attach_shm(BRDSHM_KEY, sizeof(BCACHE));
  }

  uptime = &(xshm->uptime);

  for (;;)
  {
    n = *uptime;
    if (n > 0)
      return;

    if (n < 0)
    {
      if (++turn < 30)
      {
        sleep(2);
        continue;
      }
    }
    *uptime = -1;
  
    if ((n = open(FN_BRD, O_RDONLY)) >= 0)
    {
      xshm->number =
        read(n, xshm->bcache, MAXBOARD * sizeof(BRD)) / sizeof(BRD);
      close(n);
    }

    /* ���Ҧ� boards ��Ƨ�s��A�]�w uptime */
  
    time(uptime);
    fprintf(stderr, "[FAINT]\tCACHE\tload bcache");
      
#if 0
    blog("CACHE", "reload bcache");
#endif
      
    return;
  }     
}

          

typedef struct 
{
  char author[IDLEN + 1]; // author
  int mark; //mark num
}	BMP;


static int
int_cmp(a, b)
  BMP *a;
  BMP *b;
{
  return b->mark - a->mark;
}

void
keeplog(fnlog, board, title, mode)
  char *fnlog;
  char *board;
  char *title;
  int mode;             /* 0:load 1: rename  2:unlink */
{
  HDR hdr;
  char folder[128], fpath[128];
  int fd;
  FILE *fp;

  if (!board)
    board = "Bulletin";

  sprintf(folder, "brd/%s/.DIR", board);
  fd = hdr_stamp(folder, 'A', &hdr, fpath);
  if (fd < 0)
    return;

  if (mode == 1)
  {
    close(fd);
    /* rename(fnlog, fpath); */
    f_mv(fnlog, fpath); /* Thor.990409:�i��partition */
  }
  else
  {
    fp = fdopen(fd, "w");
    fprintf(fp, "�@��: SYSOP (����Ϫ�)\n���D: %s\n�ɶ�: %s\n",
      title, ctime(&hdr.chrono));
    f_suck(fp, fnlog);
    fclose(fp);
    close(fd);
    if (mode)
      unlink(fnlog);
  }

  strcpy(hdr.title, title);
  strcpy(hdr.owner, "SYSOP");
  strcpy(hdr.nick, "����Ϫ�");
  fd = open(folder, O_WRONLY | O_CREAT | O_APPEND, 0600);
  if (fd < 0)
  {
    unlink(fpath);
    return;
  }
  write(fd, &hdr, sizeof(HDR));
  close(fd);
}

int	
mark_count_board(brd) //�έp�Ӫ�����m�ƶq, ���@�̤���, ���ƶq�Ƨ�
 BRD *brd;
{
 BMP bmp_pool[10000];
 int i, max, fsize, flag;
 char fpath[64],*fimage;
 HDR *head, *tail;
  
 brd_fpath(fpath, brd->brdname, ".DIR");
 
 fimage = f_map(fpath, &fsize);
 fprintf(stderr, "mmap setup ");
  
 if (fimage == (char *) -1) return -1; /* the same as up */
  
 head = (HDR *) fimage;
 tail = (HDR *) (fimage + fsize); 
 
 max = 0;
 memset(bmp_pool, 0, sizeof(BMP) * 10000);
 fprintf(stderr, "mem setup ");
 do
  {
    //�B�z��...
    char buf[80];

    if(!(head->xmode & POST_MARKED)) continue;
    if(head->xmode & (POST_CANCEL | POST_DELETE)) continue;
    usr_fpath(buf, head->owner, NULL);
    if(access(buf, 0)) continue; /* ���s�b���@�� */
    
    flag = 0;
    for(i=0; i<=max;i++)
    {
    	if (!str_ncmp(bmp_pool[i].author, head->owner, IDLEN+1))
    	{
    	  bmp_pool[i].mark++;
    	  flag = 1;
    	  break;	
    	}    	
    }
    if(!flag) 
    {
    	str_ncpy(bmp_pool[max].author, head->owner, IDLEN+1);
    	bmp_pool[max++].mark = 1;
    }
 
    if(max > 9999)
    {
        fprintf(stderr, "Pause: %s���峹�L�h�A�S�έp��!\n", brd->brdname);
        return;
    }
  
  } while (++head < tail);  
  munmap(fimage, fsize);   
  
  if (max > 1) /* �u����max */
    xsort(bmp_pool, max, sizeof(BMP), int_cmp);
  
   {
    FILE *fp;
    char folder[64];
    time_t now;
    HDR ghdr;
    int fd;

    time(&now);
   
    sprintf(folder, "gem/brd/%s/@/@mark", brd->brdname); 
    if (fp = fopen(folder, "w"))    
    {
      //fprintf(fp, "�@��: SYSOP (�t�κ޲z��)\n���D: �ݪO��m�峹���R\n�ɶ�: %s\n",
        //Ctime(&now));

      fprintf(fp, "  �ݪO��m�峹���R: [%s] %s\n\n", brd->brdname, brd->title);
      for(i=0; i<max; i++)
      {
      	fprintf(fp, "%3d.%-14s [%4d]\n", 
      		i, bmp_pool[i].author, bmp_pool[i].mark);
      }
      fclose(fp);
    }	
 
    sprintf(fpath, "gem/brd/%s/.DIR", brd->brdname);  
    if(fd = open(fpath,  O_RDWR) < 0) 
    {
      fprintf(stderr, "Error: Cant not open %s", fpath);
      return; 
    }
    lseek(fd, (off_t) -sizeof(HDR), SEEK_END);
    memset(&ghdr, 0, sizeof(HDR));
    if(read(fd, &ghdr, sizeof(HDR)) == sizeof(HDR) && !str_ncmp(ghdr.xname, "@mark", 5))
    {
      strcpy(ghdr.title, "������m�峹�έp���R");
      ghdr.xmode = 0;
      str_stamp(ghdr.date, &now);
      lseek(fd, (off_t) -sizeof(HDR), SEEK_END);
      write(fd, &ghdr, sizeof(HDR));    
      close(fd); 
    } else {
    
      lseek(fd, (off_t) 0, SEEK_END);
      memset(&ghdr, 0, sizeof(HDR));
      ghdr.chrono = now;
      strcpy(ghdr.title, "������m�峹�έp���R");
      strcpy(ghdr.owner, "SYSOP");
      ghdr.xmode = 0;
      strcpy(ghdr.nick, "�t�κ޲z��");
      strcpy(ghdr.xname, "@mark");
      str_stamp(ghdr.date, &now);
      write(fd, &ghdr, sizeof(HDR));
      close(fd);
    }
    sprintf(folder, "��m�峹�έp(%s)", ghdr.date);
    sprintf(fpath, "gem/brd/%s/@/@mark", brd->brdname);

    keeplog(fpath, brd->brdname, folder, 0); 

  }   
  return 1; 
}

int
main()
{ 
  BRD *brdp, *bend;
  int cnt;
  
  setgid(BBSGID);
  setuid(BBSUID);
  chdir(BBSHOME);

  fprintf(stderr, "�}�l�έp������m�峹��...\n\n");  
  
  bshm_init();	
  
  
  brdp = bshm->bcache;
  bend = brdp + bshm->number;

  cnt = 0;
  do
    {
      if(brdp->battr & BRD_NOCOUNT) continue;
      fprintf(stderr, "���b�B�z����: %s ...", brdp->brdname);
      mark_count_board(brdp);
      fprintf(stderr, "OK, DONE!\n");
      fflush(stderr);
      cnt++;
    }
  while (++brdp < bend);
  
  fprintf(stderr, "�����B�z�����A�@������: %d��\n", cnt);
  return 0;
}
