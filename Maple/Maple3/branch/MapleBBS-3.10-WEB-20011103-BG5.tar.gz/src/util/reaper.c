/*-------------------------------------------------------*/
/* util/reaper.c	( NTHU CS MapleBBS Ver 3.00 )	 */
/*-------------------------------------------------------*/
/* target : �ϥΪ̱b���w���M�z				 */
/* create : 95/03/29				 	 */
/* update : 97/03/29				 	 */
/*-------------------------------------------------------*/
/* syntax : reaper					 */
/*-------------------------------------------------------*/
/* notice : ~bbs/usr/@/     - expired users's data	 */
/*          run/reaper.log  - list of expired users	 */
/*          run/manager.log - list of managers		 */
/*          run/lazybm.log - list of lazy bm		 */
/*          run/emailaddr.log - list of same email addr  */
/*          run/emailall.log - list of all email addr    */
/*-------------------------------------------------------*/


#include <stdio.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <dirent.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>

#include "config.h"
#include "struct.h"
#include "perm.h"

#define CHECK_LAZYBM
#undef EADDR_GROUPING  /* Thor.980930: �Y�����ɥ� undef�Y�i */
#undef EADDR_ALL       /* Thor.991112: �C�X�Ҧ��{��address, �H�K�@�¥զW��έp */

#ifdef CHECK_LAZYBM
#define DAY_LAZYBM	7
#endif

#ifdef EADDR_GROUPING
                         	
/* Thor.980930: 3�ӥH�Waccount�P�@email�Y�`�N */
#define EMAIL_REG_LIMIT 	3

#endif

#define DAY_NEWUSR	14	/* 14 login ���W�L 3 �� */
#define DAY_FORFUN	30	/* 30 �����������{��     */
#define DAY_OCCUPY	120	/* 120 �w���������{��    */


static time_t due_newusr;
static time_t due_forfun;
static time_t due_occupy;


static int visit;
static int prune;
static int manager;
static int invalid;


static FILE *flog;
static FILE *flst;

#ifdef CHECK_LAZYBM
static time_t due_lazybm;
static int lazybm;
static FILE *fbm;
#endif

#ifdef EADDR_ALL
static FILE *fall;
#endif

#ifdef EADDR_GROUPING
static FILE *faddr;
#endif

/* ----------------------------------------------------- */
/* ----------------------------------------------------- */


static int funo;
static int max_uno;
static SCHEMA schema;


static void
userno_free(uno)
  int uno;
{
  off_t off;
  int fd;

  fd = funo;

  /* flock(fd, LOCK_EX); */
  /* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
  f_exlock(fd);

  time(&schema.uptime);
  off = (uno - 1) * sizeof(schema);
  if (lseek(fd, off, SEEK_SET) < 0)
    exit(2);
  if (write(fd, &schema, sizeof(schema)) != sizeof(schema))
    exit(2);

  /* flock(fd, LOCK_UN); */
  /* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
  f_unlock(fd);
}


/* ----------------------------------------------------- */
/* ----------------------------------------------------- */


static void
levelmsg(str, level)
  char *str;
  int level;
{
  static char perm[] = "bctpjm#x--------PTC---L*B#--ACBS";
  int len = 32;
  char *p = perm;

  do
  {
    *str = (level & 1) ? *p : '-';
    p++;
    str++;
    level >>= 1;
  } while (--len);
  *str = '\0';
}


static void
datemsg(str, chrono)
  char *str;
  time_t *chrono;
{
  struct tm *t;

  t = localtime(chrono);
  /* Thor.990329: y2k */
  sprintf(str, "%2d/%02d/%02d%3d:%02d:%02d ",
    t->tm_year % 100, t->tm_mon + 1, t->tm_mday,
    t->tm_hour, t->tm_min, t->tm_sec);
}


/* ----------------------------------------------------- */
/* ----------------------------------------------------- */

#ifdef EADDR_GROUPING
/* Thor.980930: �N�P�@email addr��account, �����_�ӨæC��
      �u�@��z: 1.���� str_hash() �N email addr �ƭȤ�
                2.��binary search, ���happend userno, �䤣��h insert �sentry
                3.�N userno list ��z�C�X

      ��Ƶ��c: chain: int hash, int link_userno
                plist: int next_userno

      �Ȯɹw��email addr�`�Ƥ��W�L100000, 
      �Ȯɹw��user�`�Ƥ��W�L 100000

*/

typedef struct {
  int hash;
  int link;
} Chain;

static Chain *chain;
static int *plist;
static int numC;
   
static void
eaddr_group(userno, eaddr)
  int userno;
  char *eaddr;
{
  int left, right, mid, i;
  int hash = str_hash(eaddr,0);

  left = 0;
  right = numC - 1;
  for (;;)
  {
    int cmp;
    Chain *cptr;

    if (left > right)  /* Thor.980930: ��S */
    {
      for (i = numC; i > left; i--)
        chain[i] = chain[i - 1];

      cptr = &chain[left];
      cptr->hash = hash;
      cptr->link = userno;
      plist[userno] = 0; /* Thor: tail */
      numC++;
      break;
    }

    mid = (left + right) >> 1;
    cptr = &chain[mid];
    cmp = hash - cptr->hash;

    if (!cmp)
    {
      plist[userno] = cptr->link;
      cptr->link = userno;
      break;
    }

    if (cmp < 0)
      right = mid - 1;
    else
      left = mid + 1;
  }
}

static void
report_eaddr_group()
{
  int i, j, cnt;
  off_t off;
  int fd;

  SCHEMA s;
  /* funo */

  fprintf(faddr, "Email registration over %d times list\n\n", EMAIL_REG_LIMIT);

  for(i = 0; i < numC; i++)
  {
    for(cnt = 0, j = chain[i].link; j; cnt++, j = plist[j]);
    if (cnt > EMAIL_REG_LIMIT)
    {
      fprintf(faddr, "\n> %d\n", chain[i].hash);
      for(j = chain[i].link; j; j = plist[j])
      {
        off = (j - 1) * sizeof(schema);
        if (lseek(funo, off, SEEK_SET) < 0)
        {
          fprintf(faddr,"==> %d) can't lseek\n", j);
          continue;
        }
        if (read(funo, &s, sizeof(schema)) != sizeof(schema))
        {
          fprintf(faddr,"==> %d) can't read\n", j);
          continue;
        }
        else
        {
  	  ACCT acct;
          char buf[256];
          if (s.userid[0]<=' ') 
          {
            fprintf(faddr,"==> %d) has been reapered\n", j);
	    continue;
          }
	  usr_fpath(buf, s.userid, ".ACCT");
  	  fd = open(buf, O_RDONLY, 0);
  	  if (fd < 0)
          {
            fprintf(faddr,"==> %d)%-13s can't open\n", j, s.userid);
	    continue;
          }
          if (read(fd, &acct, sizeof(acct)) != sizeof(acct)) 
          {
            fprintf(faddr,"==> %d)%-13s can't read\n", j, s.userid);
            continue;
          }
          close(fd);

    	  datemsg(buf, &acct.lastlogin);
          fprintf(faddr,"%5d) %-13s%s[%d]\t%s\n", acct.userno, acct.userid, buf, acct.numlogins, acct.email);
        }
      }
    }
  }
}

#endif

static void
reaper(fpath, lowid)
  char *fpath;
  char *lowid;
{
  int fd, login;
  usint ulevel;
  time_t life;
  char buf[256], data[40];
  ACCT acct;

  sprintf(buf, "%s/.ACCT", fpath);
  fd = open(buf, O_RDONLY, 0);
  if (fd < 0)
  { /* Thor.981001: �[�� log */
    fprintf(flog, "acct can't open %-13s ==> %s\n", lowid, buf);
    return;
  }

  if(read(fd, &acct, sizeof(acct))!=sizeof(acct))
  {
    fprintf(flog, "acct can't read %-13s ==> %s\n", lowid, buf);
    close(fd);
    return;
  }
  close(fd);

  fd = acct.userno;

  if ((fd <= 0) || (fd > max_uno))
  {
    fprintf(flog, "%5d) %-13s ==> %s\n", fd, acct.userid, buf);
    return;
  }

  ulevel = acct.userlevel;
  life = acct.lastlogin;
  login = acct.numlogins;

#ifdef EADDR_GROUPING
  if (ulevel & PERM_VALID) /* Thor.980930: �u�ݳq�L�{���� email, ���� */
    eaddr_group(fd, acct.email);
#endif

#ifdef EADDR_ALL
  if (ulevel & PERM_VALID) /* Thor.991112: �u�ݳq�L�{���� email, ���� */
  {
    fprintf(fall, "%s # %s (%s)\n", acct.email, acct.userid, Btime(&acct.tvalid));
  }
#endif

#if 1  
  if (ulevel & (/* PERM_DENYLOGIN | */ /* Thor.981214: �T��login��O�d,�K�ͪK�` */  PERM_XEMPT | PERM_BM | PERM_ACCOUNTS | PERM_CHATROOM | PERM_BOARD | PERM_SYSOP))
#endif
  {
    datemsg(buf, &acct.lastlogin);
    levelmsg(data, ulevel);
    fprintf(flst, "%5d) %-13s%s[%s] %d\n", fd, acct.userid, buf, data, login);
    manager++;

#ifdef CHECK_LAZYBM
    if((ulevel & PERM_BM) && life < due_lazybm)
    {
      fprintf(fbm, "%5d) %-13s%s %d\n", fd, acct.userid, buf, login);
      lazybm++;
    }
#endif

  }
  else if (ulevel)		/* guest.ulevel == 0, �û��O�d */
  {
    if (login <= 3 && life < due_newusr)
      life = 0;

    if (ulevel & PERM_PURGE)    /* lkchu.990221: �u�M���b���v */
    {
      life = 0;
    }
    else if (ulevel & PERM_VALID)
    {
      if (life < due_occupy)
	life = 0;
    }
    else
    {
      if (life < due_forfun)
	life = 0;
      else
	invalid++;
    }

    if (!life)
    {
      sprintf(buf, "usr/@/%s", lowid);

      while (rename(fpath, buf))
      {
	  extern int errno;

	  fprintf(flog, "rename %s ==> %s : %d\n", fpath, buf, errno);
	  sprintf(buf, "usr/@/%s.%d", lowid, ++life);
      }

      userno_free(fd);
      datemsg(buf, &acct.lastlogin);
      fprintf(flog, "%5d) %-13s%s%d\n", fd, acct.userid, buf, login);
      prune++;
    }
  }

  visit++;
}


static void
traverse(fpath)
  char *fpath;
{
  DIR *dirp;
  struct dirent *de;
  char *fname, *str;

  /* visit the second hierarchy */

  if (!(dirp = opendir(fpath)))
  {
    fprintf(flog, "## unable to enter hierarchy [%s]\n", fpath);
    return;
  }

  for (str = fpath; *str; str++);
  *str++ = '/';

  while (de = readdir(dirp))
  {
    fname = de->d_name;
    if (fname[0] > ' ' && fname[0] != '.')
    {
      strcpy(str, fname);
      reaper(fpath, fname);
    }
  }
  closedir(dirp);
}


main()
{
  int ch;
  time_t start, end;
  struct stat st;
  char *fname, fpath[256];

  setuid(BBSUID);
  setgid(BBSGID);
  chdir(BBSHOME);

  flog = fopen("run/reaper.log", "w");
  if (flog == NULL)
    exit(1);

  flst = fopen("run/manager.log", "w");
  if (flst == NULL)
    exit(1);

#ifdef CHECK_LAZYBM
  fbm = fopen("run/lazybm.log", "w");
  if (fbm == NULL)
    exit(1);
#endif

#ifdef EADDR_GROUPING
  faddr = fopen("run/emailaddr.log", "w");
  if (faddr == NULL)
    exit(1);
#endif

#ifdef EADDR_GROUPING
  funo = open(".USR", O_RDWR | O_CREAT, 0600); /* Thor.980930: for read name */
#else
  funo = open(".USR", O_WRONLY | O_CREAT, 0600);
#endif
  if (funo < 0)
    exit(1);

#ifdef EADDR_ALL
  fall = fopen("run/emailall.log", "w");
  if (fall == NULL)
    exit(1);
#endif

  /* ���]�M���b�������A�s���U�H�Ƥ��|�W�L 300 �H */

  fstat(funo, &st);
  max_uno = st.st_size / sizeof(SCHEMA) + 300;

  time(&start);

  due_newusr = start - DAY_NEWUSR * 86400;
  due_forfun = start - DAY_FORFUN * 86400;
  due_occupy = start - DAY_OCCUPY * 86400;

#ifdef CHECK_LAZYBM
  due_lazybm = start - DAY_LAZYBM * 86400;
#endif

#ifdef EADDR_GROUPING
  chain = (Chain *) malloc(max_uno * sizeof(Chain));
  plist = (int *) malloc((max_uno + 1) * sizeof(int));
  if (!chain || !plist) 
  {
    fprintf(faddr,"out of memory....\n");
    exit(1);
  }
#endif

  strcpy(fname = fpath, "usr/@");
  mkdir(fname, 0700);
  fname = (char *) strchr(fname, '@');

  /* visit the first hierarchy */

  for (ch = 'a'; ch <= 'z'; ch++)
  {
    fname[0] = ch;
    fname[1] = '\0';
    traverse(fpath);
  }

#ifdef EADDR_GROUPING
  report_eaddr_group(); /* Thor.980930: before close funo */
#endif

  close(funo);

  fprintf(flst, "\nManager: %d\n", manager);
  fclose(flst);

  time(&end);
  fprintf(flog, "\n\n# start: %s", ctime(&start));
  fprintf(flog, "\n# end  : %s", ctime(&end));
  end -= start;
  start = end % 60;
  end /= 60;
  fprintf(flog, "# time : %d:%d:%d\n", end / 60, end % 60, start);
  fprintf(flog, "# Visit: %d\n", visit);
  fprintf(flog, "# Prune: %d\n", prune);
  fprintf(flog, "# Valid: %d\n", invalid);
  fclose(flog);

#ifdef CHECK_LAZYBM
  fprintf(fbm, "\nLazy BM for %d days: %d\n", DAY_LAZYBM, lazybm);
  fclose(fbm);
#endif

#ifdef EADDR_GROUPING
  free(chain);
  free(plist);
  fclose(faddr);
#endif

#ifdef EADDR_ALL
  fclose(fall);
#endif  

  exit(0);
}
