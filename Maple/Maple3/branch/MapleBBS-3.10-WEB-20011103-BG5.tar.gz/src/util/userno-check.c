/*-------------------------------------------------------*/
/* util/userno-check.c         (MapleBBS Ver 3.00 )      */
/*-------------------------------------------------------*/
/* author : hightman.bbs@bbs.dot66.net		         */
/* refer  : visor.bbs@bbs.yzu.edu.tw  <util/userno.c>	 */
/* target : �ˬd���W�Τ�userno�����_���p                 */
/* create : 2001/07/29                                   */
/*-------------------------------------------------------*/
/* syntax : topuser                                      */
/*-------------------------------------------------------*/

#include "bbs.h"
typedef struct
{
  char userid[IDLEN+1];
}	MAP;
MAP map[30000];
int total1 = 0,total2 = 0;

static void
reaper(fpath, lowid)
  char *fpath;
  char *lowid;
{
  int fd;
 
  char buf[256];
  ACCT acct;

  sprintf(buf, "%s/.ACCT", fpath);
  fd = open(buf, O_RDONLY, 0);
  if (fd < 0)
     return;
 
  if(read(fd, &acct, sizeof(acct))!=sizeof(acct))
  {
     close(fd);
     return;
  }

 if(map[acct.userno].userid[0] > ' ')
  {
   printf("\033[1;31mUserno�o�{%-14s�M%-14s��Userno����%d !\033[m\n",
                  map[acct.userno].userid, acct.userid, acct.userno);
   total2++;
  }
  else
  {
   strcpy(map[acct.userno].userid,acct.userid);
   total1++;
   printf("%-14s : %d  OK!\n",acct.userid,acct.userno);
  }
  close(fd);
}


static void
traverse(fpath)
  char *fpath;
{
  DIR *dirp;
  struct dirent *de;
  char *fname, *str;

  if (!(dirp = opendir(fpath)))
  {
    return;
  }
  for (str = fpath; *str; str++);
  *str++ = '/';

  while (de = readdir(dirp))
  {
    fname = de->d_name;
    if (fname[0] > ' ' && fname[0] != '.')
    {
      strcpy(str, fname);
      reaper(fpath, fname);
    }
  }
  closedir(dirp);
}

int
main(void)
{
  int ch,mode;
  char *fname, fpath[256];

  setgid(BBSGID);
  setuid(BBSUID);
  chdir(BBSHOME);

  memset(map,0,sizeof(MAP)*30000);

  strcpy(fname = fpath, "usr/@");
  fname = (char *) strchr(fname, '@');
  for (ch = 'a'; ch <= 'z'; ch++)
  {
    fname[0] = ch;
    fname[1] = '\0';
    traverse(fpath,mode);
  }
  for (ch = '0'; ch <= '9'; ch++)
  {
    fname[0] = ch;
    fname[1] = '\0';
    traverse(fpath);
  }
 printf("�ˬd�����I�@���X�k���U�b��%-4d��, ���_userno��%-4d��\n\n", 
                                                        total1, total2);
  return 0;
}
