/*----------------------------------------------------------*/
/*  util/re-dotbrd.c			                    */
/*----------------------------------------------------------*/
/* �@��: hightman@263.net                                   */
/* �γ~: Maple3.x �ݪO���c.BRD����                          */
/* ���: 01/03/26                                           */
/*----------------------------------------------------------*/
/* syntax : re-dotbrd                                       */
/*----------------------------------------------------------*/ 

#include "bbs.h"

BRD allbrd[MAXBOARD];

int board_cmp(a, b)
  BRD *a,*b;
 {
  return (strcasecmp(a->brdname, b->brdname));
 }

main()
{
  int inf, outf, i, count;
  char buf[256], buf2[256];
  BRD mybh;

  setgid(BBSGID);
  setuid(BBSUID);
  chdir(BBSHOME);

  sprintf(buf, "%s",FN_BRD);

  inf = open(buf, O_RDONLY);

  sprintf(buf, "%s.new",FN_BRD);

  outf = open(buf, O_WRONLY | O_CREAT | O_TRUNC, 0644);
  if (inf == -1 || outf == -1)
  {
    printf("Error open file\n");
    exit(1);
  }

  /* read in all boards */
  i = 0;
  memset(allbrd, 0, MAXBOARD * sizeof(BRD));
  while (read(inf, &mybh, sizeof(mybh)) == sizeof(mybh))
  {
     //strcpy(buf2, mybh->brdname);
     if(!mybh.brdname[0])
     { printf("���L�w�g�R���Φ��~��%s\n",mybh.title);
       continue;
      }

      strcpy(allbrd[i].brdname, mybh.brdname);	/* �O�W(ENGLISH) */
      strcpy(allbrd[i].title, mybh.title);
      strcpy(allbrd[i].BM, mybh.BM);
      allbrd[i].bvote = mybh.bvote;
      allbrd[i].bstamp = mybh.bstamp;
      allbrd[i].readlevel = mybh.readlevel;
      allbrd[i].postlevel = mybh.postlevel;
      allbrd[i].battr = mybh.battr;
      allbrd[i].btime = mybh.btime;
      allbrd[i].bpost = mybh.bpost;
      allbrd[i].blast = mybh.blast;
      i++;
  }
  close(inf);

  /* sort them by name */
  count = i;
  qsort(allbrd, count, sizeof(BRD), board_cmp);
  /* write out the target file */
  printf(
    "�ݪO�W��     �O�D                     ����ԭz\n"
    "----------------------------------------------------------------------\n");
  for (i = 0; i < count; i++)
  {
  write(outf, &allbrd[i], sizeof(BRD));
  printf("%-13s%-25.25s%s\n", allbrd[i].brdname, allbrd[i].BM, allbrd[i].title);
  }

  close(outf);
  exit(0);
}
