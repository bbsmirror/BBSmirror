/*-------------------------------------------------------*/
/* ifsigned.c   (NTHU CS MapleBBS Ver 3.10 )		 */
/*-------------------------------------------------------*/
/* author : thor.bbs@bbs.cs.nthu.edu.tw			 */
/* target : verify signature of outgoing mail	 	 */
/* create : 99/04/09				 	 */
/* update :   /  /  				 	 */
/*-------------------------------------------------------*/

#include "bbs.h"

int
main(argc, argv)
  int argc;
  char *argv[];
{
  FILE *fp;
  time_t chrono;
  char buf[512];
  char *str, from[80], rcpt[80], subject[80];
  char sign[80];
  char prikey[9];
  unsigned int hash, hash2;
  long body; 
  long tail; 
  union{
    char str[9];
    struct {
      unsigned int hash,  hash2;
    } val;
  } s;

  *prikey = prikey[8] = s.str[8] = '\0';

  if(argc != 2)
  {
    printf("\nUsage: %s filename\n\n", argv[0]);
    return 0;
  }
  if(!(fp=fopen(argv[1],"r")))
  {
    puts("\nOpen error\n");
    return 0;
  }
  
  /* seek for "X-Signed:", "From:", "To:", "Subject:" , and begin of body */
  body = -1;
  *from = *rcpt = *subject = *sign = 0;
  while(fgets(buf, sizeof buf, fp))
  {
    if(body < 0)
    {
      if(!memcmp(buf,"\n",1))
      {
        body = ftell(fp);
        continue;
      }
      if(!memcmp(buf,"From:",5))
      {
        strcpy(from, buf + 6);
        continue;
      }
      if(!memcmp(buf,"�@��:",5))
      {
        strcpy(from, buf + 6);
        continue;
      }
      if(!memcmp(buf,"To:",3))
      {
        strcpy(rcpt, buf + 4);
        continue;
      }
      if(!memcmp(buf,"Subject:",8))
      {
        strcpy(subject, buf + 9);
        continue;
      }
      if(!memcmp(buf,"���D:",5))
      {
        strcpy(subject, buf + 6);
        continue;
      }
    }

    if((!memcmp(buf,"�� X-Signed:",12)) && strlen(buf) >= 12 + 8 + 13)
    {
      tail = ftell(fp);
      str_ncpy(sign, buf + 12, 9);
      chrono = chrono32(sign); /* prefix 1 char */
      printf("\nTimestamp:%s\n",sign);
      strcpy(sign, buf + 13 + 7);
      continue;
    }
  }
   
  if(body < 0)
  {
    fclose(fp);
    puts("\nNo body ! \n");
    return 0;
  }
   
  chdir(BBSHOME);
  if(rec_get(PRIVATE_KEY, prikey, 8, 0) || !*prikey)
  {
    fclose(fp);
    puts("\nNo private key\n");
    return 0;
  }

  if(str = strstr(from,"\n"))
  {
    *str = 0;
  }
  printf("From: %s\n", from);
  if(str = strstr(rcpt,"\n"))
  {
    *str = 0;
  }
  printf("To: %s\n", rcpt);
  if(str = strstr(subject,"\n"))
  {
    *str = 0;
  }
  printf("Subject: %s\n", subject);
  if(str = strstr(sign,"\n"))
  {
    *str = 0;
  }
  printf("Signed: %s\n", sign);
  if(!*sign)
  {
    puts("\nNo Signed!\n");
    return 0;
  }

  hash = str_hash(from, chrono);
  hash2 = str_hash2(from, hash);

  hash = str_hash(rcpt, hash2);
  hash2 = str_hash2(rcpt, hash);

  hash = str_hash(subject, hash2);
  hash2 = str_hash2(subject, hash);
  
  fseek(fp, body, SEEK_SET);

  while (fgets(buf, sizeof(buf), fp))
  {
    /* printf("%s",buf); */
    /* if(!memcmp(buf,"�� X-Signed:",12)) */
    if(tail == ftell(fp))
    {
      /* body = -1; */
      break;
    }
    hash = str_hash(buf,hash2);
    hash2 = str_hash2(buf,hash);
  }
  fclose(fp);
#if 0
  if(body >= 0)
  {
    puts("\nNo X-Signed!\n");
    return 0;
  }
#endif

  s.val.hash = hash;
  s.val.hash2 = hash2;
  str_xor(s.str, prikey);
  if(!chkpasswd(sign,s.str))
  {
    printf("\nGotcha! that's [%s] outgoing mail\n",MYHOSTNAME);
    printf("\n�S��, �o�O[%s]�o�X���H��\n\n",BOARDNAME);
  }
  else
  {
    puts("\nTigerBlue! that's fake mail");
    puts("\n�F�H, �o�O���H\n");
  }
  return 0;
}
