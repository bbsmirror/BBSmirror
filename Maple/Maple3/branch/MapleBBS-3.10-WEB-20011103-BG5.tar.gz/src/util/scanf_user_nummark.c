/*-------------------------------------------------------*/
/* util/scanf_user_nummark.c                             */
/*-------------------------------------------------------*/
/* author : hightman.bbs@bbs.dot66.net         		 */
/* target : �۰ʲέp�Τ᪺��M�峹��	                 */
/* create : 2001/10/28                                   */
/* update :                                              */
/*-------------------------------------------------------*/
/* syntax : scanf_user_nummark                           */
/* NOTICE : �Τ_�}�ҤFHAVE_COUNT_MARK�F�����x          	 */
/*          [�����έp�X�Τ᪺��M�峹OVT ]                */
/*-------------------------------------------------------*/

#include <sys/ipc.h>
#include "bbs.h"

static BCACHE *bshm;
          
static void
attach_err(shmkey, name)
  int shmkey;
  char *name;
{ 
  fprintf(stderr, "[%s error] key = %x\n", name, shmkey);
  exit(1); 
} 


static void *
attach_shm(shmkey, shmsize)
  register int shmkey, shmsize;
{
  register void *shmptr;
  register int shmid;

  shmid = shmget(shmkey, shmsize, 0);
  if (shmid < 0)
  {
    shmid = shmget(shmkey, shmsize, IPC_CREAT | 0600);
    if (shmid < 0)
      attach_err(shmkey, "shmget");
  }
  else
  {
    shmsize = 0;
  }

  shmptr = (void *) shmat(shmid, NULL, 0);
  if (shmptr == (void *) -1)
    attach_err(shmkey, "shmat");

  if (shmsize)
    memset(shmptr, 0, shmsize);

  return shmptr;
}


/* static */
void
bshm_init()
{
  register BCACHE *xshm;
  register time_t *uptime;
  register int n, turn;

  turn = 0;
  xshm = bshm;
  if (xshm == NULL)
  {
    bshm = xshm = attach_shm(BRDSHM_KEY, sizeof(BCACHE));
  }

  uptime = &(xshm->uptime);

  for (;;)
  {
    n = *uptime;
    if (n > 0)
      return;

    if (n < 0)
    {
      if (++turn < 30)
      {
        sleep(2);
        continue;
      }
    }
    *uptime = -1;
  
    if ((n = open(FN_BRD, O_RDONLY)) >= 0)
    {
      xshm->number =
        read(n, xshm->bcache, MAXBOARD * sizeof(BRD)) / sizeof(BRD);
      close(n);
    }

    /* ���Ҧ� boards ��Ƨ�s��A�]�w uptime */
  
    time(uptime);
    fprintf(stderr, "[FAINT]\tCACHE\tload bcache");
      
#if 0
    blog("CACHE", "reload bcache");
#endif
      
    return;
  }     
}

          

typedef struct 
{
  char author[IDLEN + 1]; // author
  int mark; //mark num
}	BMP;

int	
mark_count_board(brd) //�έp�Ӫ�����m�ƶq, ���@�̤���, ���ƶq�Ƨ�
 BRD *brd;
{
 BMP bmp_pool[10000]; //���]���W�]�t�쪺�@�̭ӼƤ��j�_1�U
 int i, max, fsize, flag;
 char fpath[64],*fimage;
 HDR *head, *tail;
  
 brd_fpath(fpath, brd->brdname, ".DIR");
 
 fimage = f_map(fpath, &fsize);
 fprintf(stderr, "mmap setup ");
  
 if (fimage == (char *) -1) return -1; /* the same as up */
  
 head = (HDR *) fimage;
 tail = (HDR *) (fimage + fsize); 
 
 max = 0;
 memset(bmp_pool, 0, sizeof(BMP) * 10000);
 fprintf(stderr, "mem setup ");
 do
  {
    //�B�z��...
    char buf[80];

    if(!(head->xmode & POST_MARKED)) continue;
    if(head->xmode & (POST_CANCEL | POST_DELETE)) continue;
    usr_fpath(buf, head->owner, NULL);
    if(access(buf, 0)) continue; /* ���s�b���@�� */
    
    flag = 0;
    for(i=0; i<=max;i++)
    {
    	if (!str_ncmp(bmp_pool[i].author, head->owner, IDLEN+1))
    	{
    	  bmp_pool[i].mark++;
    	  flag = 1;
    	  break;	
    	}    	
    }
    if(!flag) 
    {
    	str_ncpy(bmp_pool[max].author, head->owner, IDLEN+1);
    	bmp_pool[max++].mark = 1;
    }
 
    if(max > 9999)
    {
        fprintf(stderr, "Pause: %s���峹�L�h�A�S�έp���A�Х[�jbmp_pool��size!\n", brd->brdname);
        return;
    }
  
  } while (++head < tail);  
  munmap(fimage, fsize);   
  
  for(i=0; i<max; i++)
  {
   ACCT acct;
   int fd;
   char folder[64];
   
   usr_fpath(folder, bmp_pool[i].author, FN_ACCT);
   fd = open(folder, O_RDWR);
   if(fd>=0 && read(fd, &acct, sizeof(ACCT)) == sizeof(ACCT)) {
   	acct.nummark += bmp_pool[i].mark;
   	if(acct.nummark > acct.numposts) acct.nummark = acct.numposts;
   	lseek(fd, (off_t) 0, SEEK_SET);
   	write(fd, &acct, sizeof(ACCT));
   	close(fd);
   }
  }	
  return 1; 
}

int
main()
{ 
  BRD *brdp, *bend;
  int cnt;
  
  setgid(BBSGID);
  setuid(BBSUID);
  chdir(BBSHOME);

  fprintf(stderr, "�}�l�έp�����ӤH��m�峹��...\n\n");  
  
  bshm_init();	
  
  
  brdp = bshm->bcache;
  bend = brdp + bshm->number;

  cnt = 0;
  do
    {
      if(brdp->battr & BRD_NOCOUNT) continue;
      fprintf(stderr, "���b�B�z����: %s ...", brdp->brdname);
      mark_count_board(brdp);
      fprintf(stderr, "OK, DONE!\n");
      fflush(stderr);
      cnt++;
    }
  while (++brdp < bend);
  
  fprintf(stderr, "�����B�z�����A�@������: %d��\n", cnt);
  return 0;
}
