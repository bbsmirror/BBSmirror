/*-------------------------------------------------------*/
/* talk.c       ( NTHU CS MapleBBS Ver 3.00 )            */
/*-------------------------------------------------------*/
/* target : talk/query/friend(pal) routines              */
/* create : 95/03/29                                     */
/* update : 97/03/29                                     */
/*-------------------------------------------------------*/


#define _MODES_C_
#define PAL_MAX		200     /* �n�ͦW��W�� */
#define FN_FIMAGE	"fimage"
#define	FN_PAL_LOG	"run/pal"

#include "bbs.h"

extern UCACHE *ushm;

#define BMW_LOCAL_MAX   8
static BMW bmw_lslot[BMW_LOCAL_MAX];
static int bmw_locus;

typedef UTMP *pickup;
static int iStart;

static int pal_count;
static int *pal_pool;


char *
bmode(up, simple)
  UTMP *up;
  int simple;
{
  static char modestr[32];
  
  int mode;
  char *word;
  word = ModeTypeTable[mode = up->mode];

  if (simple)
    return (word);

  if (mode < M_TALK || mode > M_CHESS)
    return (word);  /* hightman.001206: ���α���H */

  if (mode != M_QUERY && !HAS_PERM(PERM_SEECLOAK) && (up->ufo & UFO_CLOAK))
    return (word); /* Thor.980805: ����: �������H���|�Q���D���talk */

  sprintf(modestr, "%s [%s]", word, up->mateid);
  return (modestr);
}



/* ----------------------------------------------------- */
/* �n�ͦW��G�s�W�B�R���B�ק�B���J�B�P�B		 */
/* ----------------------------------------------------- */

static int
is_friend(up)
  UTMP *up;
{
  int self, found, fd;
  char fpath[64];
  PAL *pal;

  found = 1;
  /* 1 : ���`  0 : �n��  2 : �l�� */

  usr_fpath(fpath, up->userid, FN_PAL);
  if ((fd = open(fpath, O_RDONLY)) >= 0)
  {
    self = cuser.userno;

    mgets(-1);
    while (pal = mread(fd, sizeof(PAL)))
    {
      if (self == pal->userno)
      {
        found = pal->ftype;
        break;
      }
    }
    close(fd);
  }

  return found;
}


int
is_pal(userno)
  int userno;
{
  int count, *cache, datum, mid;

  if (cache = pal_pool)
  {
    for (count = pal_count; count > 0;)
    {
      datum = cache[mid = count >> 1];
      if (userno == datum)
	return 1;
      if (userno > datum)
      {
	cache += (++mid);
	count -= mid;
      }
      else
      {
	count = mid;
      }
    }
  }
  return 0;
}

static int
int_cmp(a, b)
  int *a;
  int *b;
{
  return *a - *b;
}

static void
pal_cache()
{
  int count, fsize, ufo ,fd;
  int *plist, *cache;
  PAL *phead, *ptail;
  char *fimage, fpath[64];
  UTMP *up;

  up = cutmp;
  cutmp->userno = cuser.userno;

  if (cache = pal_pool)
   free(cache);

  cache = NULL;
  count = 0;
  ufo = cuser.ufo & ~(UFO_REJECT | UFO_FCACHE);

  fsize = 0;
  usr_fpath(fpath, cuser.userid, FN_PAL);
  fimage = f_img(fpath, &fsize);

  if((fsize > (PAL_MAX * sizeof(PAL))) && (fd = open(fpath,O_RDWR)))
  {
    ftruncate(fd, PAL_MAX * sizeof(PAL));
    close(fd);
  }

  if (fimage != NULL)
  {
    if (fsize > (PAL_MAX * sizeof(PAL)))
    {
      sprintf(fpath, "%-13s%d > %d * %d\n", cuser.userid, fsize, PAL_MAX, sizeof(PAL));
      f_cat(FN_PAL_LOG, fpath);
      fsize = PAL_MAX * sizeof(PAL);
    }

    count = fsize / sizeof(PAL);
    if (count)
    {
      cache = plist = (int *) malloc(count * sizeof(int));
      phead = (PAL *) fimage;
      ptail = (PAL *) (fimage + fsize);
      do
      {
		if (phead->ftype & PAL_BAD)
		{
          		ufo |= UFO_REJECT;
         		count--;
		}
		else
		{
		  *plist++ = phead->userno;
		}
      } while (++phead < ptail);

      if (count > 0)
      {
		ufo |= UFO_FCACHE;
		if (count > 1)
		xsort(cache, count, sizeof(int), int_cmp);
	  }
	  else
	  {
	    free(cache);
		cache = NULL;
	  }      
	}
  }

  pal_pool = cache;
  pal_count = count;
  if (cutmp)
  {
    ufo = (ufo & ~UFO_UTMP_MASK) | (cutmp->ufo & UFO_UTMP_MASK);
    cutmp->ufo = ufo;
  }
  
  if(fimage) free(fimage);
  cuser.ufo = ufo;
}

/*-------------------------------------------------------*/
/* BBS MESSAGE WRITE (bmw)				 */
/*-------------------------------------------------------*/

void
bmw_rqst()
{

  int i, j, userno, locus;
  BMW bmw[BMW_PER_USER], *mptr, **mslot;
  struct tm *ptime;
  char timebuf[5];

  /* download BMW slot first */

  i = j = 0;
  userno = cuser.userno;
  mslot = cutmp->mslot;

  while (mptr = mslot[i])
  {
    mslot[i] = NULL;
    if (mptr->recver == userno)
    {
      bmw[j++] = *mptr;
    }
    mptr->btime = 0;

    if (++i >= BMW_PER_USER)
      break;
  }

  /* process the request */

  if (j)
  {
    char buf[128];

    locus = bmw_locus;
    i = locus + j - BMW_LOCAL_MAX;

    /* if (i >= 0) */
    if (i > 0) /* �ѨM�s����T��H Logic.bbs@bbs.ncku.edu.tw */
    {
      locus -= i;
      if (locus > 0)  /* �ѨM�s����T��H Logic.bbs@bbs.ncku.edu.tw */
       memcpy(bmw_lslot, bmw_lslot + i, locus * sizeof(BMW));
    }

    i = 0;
    do
    {
      mptr = &bmw[i];

      /* lkchu.981230: �Q�� xover ��X bmw */
      usr_fpath(buf, cuser.userid, FN_BMW);
      rec_add(buf, &bmw[i], sizeof(BMW)); 
      if (locus >= 0)   /* �ѨM�s����T��H Logic.bbs@bbs.ncku.edu.tw */
        bmw_lslot[locus] = *mptr;
      locus++;
      /* bmw_lslot[locus++] = *mptr; */
    } while (++i < j);

    bmw_locus = locus;
     
    utmp_mode(M_BMW);
    
    ptime = localtime(&mptr->btime);
    sprintf(timebuf, "%02d:%02d", ptime->tm_hour, ptime->tm_min);
            
    www_printf("<script>bmw_rqst(%d, '��%s(%s): %s');</script>\n", 
    	mptr->sender, mptr->userid, timebuf, mptr->msg);
                                  
  }

}

static int
can_write(up)
 UTMP *up;
{
  int self, ufo, can, fd;
  char fpath[64];
  PAL *pal;

#if 0
  if (!HAS_PERM(PERM_VALID))	/* �X�k�b��? �o�˴N�S�k�^�F. :p */
    return NA;
#endif    
  
  if (up->userno == (self = cuser.userno))
    return NA;

  if (HAS_PERM(PERM_SYSOP | PERM_ACCOUNTS))	/* �����B�b���޲z�� */
    return YEA;

  ufo = up->ufo;

  if (ufo & (UFO_QUIET | UFO_EXEC))		/* �������� */
    return NA;   
    
  if(!(ufo & (UFO_MESSAGE | UFO_REJECT))) 
    return YEA;					/* �I�s��/�T�����S�����A��L�l�� */     

  if ((ufo & UFO_MESSAGE) && !(ufo & UFO_FCACHE))
    return NA;

  can = 1;			/* �䤣�쬰 normal */

  usr_fpath(fpath, up->userid, FN_PAL);
  if ((fd = open(fpath, O_RDONLY)) >= 0)
  {
    mgets(-1);
    while (pal = mread(fd, sizeof(PAL)))
    {
      if (self == pal->userno)
      {
	can = pal->ftype;
	break;
      }
    }
    close(fd);
  }

  return (ufo & UFO_MESSAGE)
    ? can == 0	/* �u���n�ͥi�H */
    : can < 2	/* �u�n���O�l�� */ ;    
}

void
bmw_send()
{
 char *ptr, *msg, fpath[80];
 UTMP *callee;
 BMW bmw, *mpool, *mhead, *mtail, **mslot;
 pid_t pid, mypid;
 int userno, i;
 time_t texpire;
 
 ptr = myWRC.query;
 mypid = atoi(nextword(&ptr));
 
 cutmp = utmp_find_by_pid(mypid);
 
 if(!cutmp) 
  msg_quit("�Y�����ˡG�z���b���W�����I");
 
 userno = atoi(nextword(&ptr));
 callee = utmp_find(userno);
 
 if(callee->userno != userno || (pid = callee->pid) <= 0)
  msg_quit("�P�R���~�G���n���w�g���u�I");
  
 acct_load(&cuser, cutmp->userid);
 pal_cache();
 
 if(!can_write(callee)) msg_quit("�藍�_, �����L�k�e�F!");
  
 memset(&bmw, 0, sizeof(BMW));
 bmw.recver = userno;
 bmw.caller = cutmp;
 bmw.sender = cutmp->userno;
 strcpy(bmw.userid, cutmp->userid);
  
 msg = nextword(&ptr);
 strcpy(bmw.msg, msg);
 
 time(&bmw.btime);
 usr_fpath(fpath, cutmp->userid, FN_BMW);
 rec_add(fpath, &bmw, sizeof(BMW));
 
 /* �}�l�o�F�a */

  mslot = callee->mslot;
  i = 0;

  for (;;)
  {
    if (mslot[i] == NULL)
      break;

    if (++i >= BMW_PER_USER)
    {
      msg_quit("���T���q�Ӧh�A�񤣤U�F. :-p");
    }
  }

  /* find available BMW slot in pool */

  texpire = time(&bmw.btime) - BMW_EXPIRE;

  mpool = ushm->mpool;
  mhead = ushm->mbase;
  if (mhead < mpool)
    mhead = mpool;
  mtail = mpool + BMW_MAX;

  do
  {
    if (++mhead >= mtail)
      mhead = mpool;
  } while (mhead->btime > texpire);

  *mhead = bmw;
  ushm->mbase = mslot[i] = mhead;

  kill(pid, SIGUSR2);
  
  sprintf(fpath, "result=OK&msg=���\\�e�X�T����%s�F!", callee->userid);
  msg_quit(fpath);

}



#ifdef LOG_BMW
void
bmw_save()
{
  int fd;
  char fpath[64];
  
  usr_fpath(fpath, cuser.userid, FN_BMW);
  fd = f_open(fpath);   /* lkchu.990428: �Y size �� 0 �|�Q unlink �� */

  if (fd >= 0)
  {
    if (!(cuser.ufo & UFO_NWLOG))
    {
      FILE *fout;
      char buf[80], folder[80];
      HDR fhdr;
      
      usr_fpath(folder, cuser.userid, fn_dir);
      if (fout = fdopen(hdr_stamp(folder, 0, &fhdr, buf), "w"))
      {        
        BMW bmw;
        
        while (read(fd, &bmw, sizeof(BMW)) == sizeof(BMW)) 
        {
          struct tm *ptime = localtime(&bmw.btime);
          
          fprintf(fout, "%s%s(%02d:%02d)�G%s\033[m\n", 
            bmw.sender == cuser.userno ? "��" : "\033[32m��",
            bmw.userid, ptime->tm_hour, ptime->tm_min, bmw.msg);
        }
        fclose(fout);
      }
      
      fhdr.xmode = MAIL_READ | MAIL_NOREPLY;
      strcpy(fhdr.title, "[�� �� ��] ���T����");
      strcpy(fhdr.owner, cuser.userid);
      rec_add(folder, &fhdr, sizeof(fhdr));
    }  
    
    close(fd);
    unlink(fpath);

  }
}
#endif
/*-------------------------------------------------------*/
/* ��榡��Ѥ���					 */
/*-------------------------------------------------------*/


static pickup ulist_pool[MAXACTIVE];
static int ulist_max;

static int
ulist_body()
{
  pickup *pp;
  UTMP *up;
  int top, cnt, ufo, self, userno, sysop, diff, diff2, fcolor;
  char buf[8];

  cnt = iStart;
  top = cnt + XO_TALL;
  if(top > ulist_max) top = ulist_max;
  
  pp = &ulist_pool[cnt];
  self = cuser.userno;
  sysop = HAS_PERM(PERM_SYSOP | PERM_ACCOUNTS);

  while (cnt++ < top)
  {
    up = *pp++;
    if (userno = up->userno)
     {
       /* if (diff = up->idle_time)
         sprintf(buf, "%2d", diff);
       else
       */ /* hightman: Web��idle�l�׬� 0 */
          buf[0] = '\0';

       fcolor = 30;
       if (userno == self){
          fcolor = 33;
       }
       if (is_pal(userno)){
          fcolor = 32;
       }

       ufo = up->ufo;
       diff2 = diff = ' ';
       
       if (ufo & UFO_EXEC)      /* hightman.001114: �~����� @ ���H�a */
       { 
         diff2 = diff = '@';
       }
       else if (ufo & UFO_QUIET)
       {
         diff2 = diff = '-';
       }
       else 
       {
         if (ufo & UFO_PAGER)
         {
           diff = (is_friend(up) == 0) ? 'O' : '*';
         }

         if (ufo & UFO_MESSAGE) 
         { 
            diff2 = (is_friend(up) ==0) ? 'O' : '*';  
         }
       }
              
       www_printf("userno=%d&no=%d&color=%d&userid=%s&username=%s&from=%s&pager=%c&msg=%c&cloak=%d&mode=%s&idle=%s\n",
                userno, cnt, fcolor, up->userid, up->username, (diff == '-' && !sysop) ? "-" : up->from, 
                diff, diff2, (ufo & UFO_CLOAK ? 1 : 0), bmode(up, 0), buf);
     }
     else
     {
      www_printf("userno=0&msg=������ͥ������}\n");
     }
  }

  return 1;
}

static int
ulist_cmp_userid(i, j)
  UTMP **i, **j;
{
  return str_cmp((*i)->userid, (*j)->userid);
}


static int
ulist_cmp_host(i, j)
  UTMP **i, **j;
{
   /* fuse.990526: �ݱo����ip�Ƨ� */
   struct in_addr a, b;
   u_long a1, b1;
   char ip1[20], ip2[20];

   a1 = (*i)->in_addr;
   b1 = (*j)->in_addr;

   memcpy(&a, &a1, sizeof(a));
   memcpy(&b, &b1, sizeof(b));
   strcpy(ip1, inet_ntoa(a));
   strcpy(ip2, inet_ntoa(b));
   return str_cmp(ip1, ip2);

}


static int
ulist_cmp_mode(i, j)
  UTMP **i, **j;
{
  return (*i)->mode - (*j)->mode;
}


static int (*ulist_cmp[]) () =
{
  ulist_cmp_userid,
  ulist_cmp_host,
  ulist_cmp_mode
};


static int
ulist_pickup(way)
   int way;
{
    int max, i, fnum;
    UTMP *p1, *p2;
    UTMP *up;
    pickup *pp;

    if (way == 0) {
      /* Firebird ���C�� */
      max = ulist_max;
      if (max <= 1)
          return 0;

      i = 0; fnum = 0;

      while (i<max) {
        up = ulist_pool[i];
        if (is_pal(up->userno)) {
          p1 = ulist_pool[i];
          p2 = ulist_pool[fnum];
          ulist_pool[i] = p2;
          ulist_pool[fnum] = p1;
          fnum++;
        }
        i ++;
      }

      xsort(ulist_pool, fnum, sizeof(pickup), ulist_cmp[0]);
      pp = &ulist_pool[fnum];
      xsort(pp, max-fnum, sizeof(pickup), ulist_cmp[0]);
      
      return 1;

    }
  /* fuse990416: �䥦�ƧǪk: �Τ�W, �ӷ�IP, �ʺA */

  max = ulist_max;

  if (max <= 1)
      return 0;

  xsort(ulist_pool, max, sizeof(pickup), ulist_cmp[way - 1]);

  return 1;
}

static int
ulist_init()
{
  UTMP *up, *uceil;
  pickup *pp;
  int max, filter, seecloak, userno, self, way, friend_num;

  pp = ulist_pool;
  self = cutmp->userno;
    
  filter = cuser.ufo & UFO_PAL;

  seecloak = HAS_PERM(PERM_SEECLOAK);

  up = ushm->uslot;
  uceil = (void *) up + ushm->offset;

  friend_num = max = 0;

  do
  {
    userno = up->userno;
    if (userno <= 0)
      continue;
    
    if((seecloak || !(up->ufo & UFO_CLOAK)) && is_pal(userno))
      friend_num ++;

    if ((userno == self) || ((seecloak || !(up->ufo & UFO_CLOAK)) && (!filter || is_pal(userno))))
    {
      *pp++ = up;
    }
  } while (++up <= uceil);

  ulist_max = max = pp - ulist_pool;
  
  if(max <= 0)  /* �X�G���i�઺�� */
   msg_quit("�{�b���W���@�ӤH�]�S���C...");
  
  if(iStart > max) iStart = 0;  

  way = 0;
  if(cutmp->sockport > 0) way = cutmp->sockport-1; 
  /* �ɥΪ�sockport�s��ƦC�Ҧ� */
    
  if (max > 1)
    ulist_pickup(way);

  www_printf("result=OK&way=%d&pal=%s&max=%d&fnum=%d\n", way, filter ? "�n�ͼҦ�" : "�@��Ҧ�", max, friend_num);
  
  return ulist_body();
}



int user_list() /* pid page way pal */
{
 pid_t pid;
 int way, page, chg_pal;
 char *ptr;
 
 ptr = myWRC.query;
 
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 if(!cutmp) msg_quit("�P�R���~�Apid�L��!");
 
 if(acct_load(&cuser, cutmp->userid) < 0) 
   msg_quit("�P�R���~, �b������l�I");
 
 page = atoi(nextword(&ptr));		/* �ĴX��? */
 if(!page) page = 1;
 
 iStart = (page - 1) * XO_TALL;	/* �}�l��ܪ����ӤH���Ǹ� */
 
 way = atoi(nextword(&ptr));		/* 0) �W���� 1)FBBS 2)�N�� 3)�ӷ� 4)�ʺA */
 
 if(way) cutmp->sockport = way;	/* �ɥ�sockport, �ϥ��Τ��� */
 
 chg_pal = atoi(nextword(&ptr));	/* �O�_���n�ͼҦ� 0:�W���Ҧ�, 1: �����Ҧ� */
 if(chg_pal && str_cmp(cutmp->userid, STR_GUEST)) 
 {
  cuser.ufo ^= UFO_PAL; /* Guest�]����� */  
  acct_save(&cuser);
 }
 
 utmp_mode(M_LUSERS);
 pal_cache(); /* pal cache */
 
 return ulist_init();
 
}

/*-------------------------------------------------------*/
/* ���ͬd��						 */
/*-------------------------------------------------------*/

static void
showplans(userid)
  char *userid;
{
  int i;
  FILE *fp;
  char buf[256];

  usr_fpath(buf, userid, fn_plans);
  if (fp = fopen(buf, "r"))
  {
    i = MAXQUERYLINES;
    www_cache_init();
    while (i-- && fgets(buf, sizeof(buf), fp))
    {
      www_cache_write(buf, strlen(buf));
    }
    fclose(fp);
    www_cache_refresh();
  }
}

static char *
cexp(exp)
int exp;
{
        int expbase=0;

        if(exp==-9999)
                return "�S����";
        if(exp<=100+expbase)
                return "�s��W��";
        if(exp>100+expbase&&exp<=450+expbase)
                return "�@�미��";
        if(exp>450+expbase&&exp<=850+expbase)
                return "���ů���";
        if(exp>850+expbase&&exp<=1500+expbase)
                return "���ů���";
        if(exp>1500+expbase&&exp<=2500+expbase)
                return "�ѯ���";
        if(exp>2500+expbase&&exp<=3000+expbase)
                return "���ѯ�";
        if(exp>3000+expbase&&exp<=5000+expbase)
                return "��������";
        if(exp>5000+expbase)
                return "�}��j��";

}

static char *
cperf(perf)
int perf;
{

        if(perf==-9999)
                return "�S����";
        if(perf<=5)
                return "���֥[�o";
        if(perf>5&&perf<=12)
                return "�V�O��";
        if(perf>12&&perf<=35)
                return "�٤���";
        if(perf>35&&perf<=50)
                return "�ܦn";
        if(perf>50&&perf<=90)
                return "�u����";
        if(perf>90&&perf<=140)
                return "���u�q�F";
        if(perf>140&&perf<=200)
                return "������W";
        if(perf>200)
                return "�����";

}

static int
countexp(udata)
  ACCT *udata;
{
   int exp;

   if(!str_cmp(udata->userid, STR_GUEST))
        return -9999;
   exp=udata->numposts+udata->numlogins/5+(time(0)-udata->firstlogin)/86400+udata->staytime/3600;
   return exp>0?exp:0;
}

static int
countperf(udata)
  ACCT *udata;
{
   int perf;
   int reg_days;

   if(!str_cmp(udata->userid, STR_GUEST))
        return -9999;
   reg_days=(time(0)-udata->firstlogin)/86400+1;
   perf=((float)(udata->numposts)/(float)udata->numlogins+
        (float)udata->numlogins/(float)reg_days)*10;
   return perf>0?perf:0;
}

static int
compute_user_value( urec )
  ACCT *urec;
{
    float value;

    if((urec->userlevel & PERM_XEMPT)||str_cmp(urec->userid, STR_GUEST)==0)
        return 999;
    value = (time(0) - urec->lastlogin) / 60.0;    /* min */
        /* new user should register in 30 mins */
    if( str_cmp( urec->userid, "new" ) == 0 ) {
        return (30 - value) * 60;
    }
    if( urec->numlogins <= 3 )
        return (15 * 1440.0 - value)/1440.0;
    if( !(urec->userlevel & PERM_VALID) )
        return (30 * 1440.0 - value)/1440.0;
    return (120 * 1440.0 - value)/1440.0;
}


static int
do_query(acct)
  ACCT *acct;
{
  UTMP *up;
  int userno;
  char *userid;
  int exp, perf;
  
  exp = perf =0;

  utmp_mode(M_QUERY);
  userno = acct->userno;
  userid = acct->userid;
  strcpy(cutmp->mateid, userid);

  exp = countexp(acct);
  perf = countperf(acct);

  up = utmp_find(userno);

  www_printf("result=OK&uno=%d&id=%s&nick=%s&numlogin=%d&numpost=%d&valid=%d\n", 
  	acct->userno, userid, acct->username, acct->numlogins,
  	acct->numposts, acct->userlevel & PERM_VALID ? 1 : 0);

  www_printf("&lastlogin=%s&lastfrom=%s\n", Ctime(&acct->lastlogin),  acct->lasthost);

  www_printf("&exp=%d&cexp=%s&perf=%d&cperf=%s&live=%d\n",
  	exp, cexp(exp), perf, cperf(perf), compute_user_value(acct));
  	
#ifdef HAVE_MONEY_SIM
  www_printf("&money=%d", acct->money);
#endif

#ifdef HAVE_COUNT_MARK
  www_printf("&nummark=%d", acct->nummark);
#endif      	

  /* ���]�W�� login �w�L 6 �p�ɡA�K���b���W�A��� utmp_find */
#ifndef HAVE_SUPER_CLOAK	/* hightman.010722: �������W������ */
  www_printf("&mode=%s", up && (HAS_PERM(PERM_SEECLOAK) || !(up->ufo & UFO_CLOAK))? bmode(up, 1) : "���b���W");
  /* Thor.981108: ������ cigar �����������n�D, ���L�� finger�٬O�i�H�ݨ�:p */
#else
  www_printf("&mode=%s", up && (HAS_PERM(PERM_SEECLOAK) || !(up->ufo & UFO_CLOAK)) &&
          (HAS_PERM(PERM_SYSOP) || !(up->ufo & UFO_SUPERCLOAK)) ? bmode(up, 1) : "���b���W");
  /* hightman.010722: �W�[�W�������\�� */
#endif

  www_printf("&mail=%d\n", m_query(userid) ? 1 : 0);
  www_printf("<--Start-Plan-->\n"); /* �W���}�l�аO */
  showplans(userid);
}

int user_query() /* pid, userid */
{
 pid_t pid;
 ACCT acct;
 char *userid, *ptr;
 
 ptr = myWRC.query;
 
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 if(!cutmp) msg_quit("�P�R���~�Apid�L��!");
 
 if(acct_load(&cuser, cutmp->userid) < 0) 
   msg_quit("�P�R���~, �b������l�I");
 
 userid = nextword(&ptr);
 if(acct_load(&acct, userid) < 0)
   msg_quit("���~���ϥΪ̥N��!");

 return do_query(&acct);    
}


/* ---------------------------------- */
/* Friend List                        */
/* ---------------------------------- */
extern char xo_pool[];
static int pal_body();

static int
pal_init(xo)
  SXO *xo;
{
  xo_load(xo, sizeof(PAL));
  return pal_body(xo);
}

static void
pal_item(num, pal)
  int num;
  PAL *pal;
{
  www_printf("num=%d&ftype=%d&userid=%s&ship=%s\n", num, pal->ftype & PAL_BAD ? 1 : 0,
    pal->userid, pal->ship);
}


static int
pal_body(xo)
  SXO *xo;
{
  PAL *pal;
  int num, max, tail;

  max = xo->max;

  www_printf("result=OK&max=%d&page=%d\n", xo->max, xo->page);

  if(max > 0) 
  {
    pal = (PAL *) xo_pool;
    num = xo->top;
    tail = num + XO_TALL;
    if (max > tail)
      max = tail;

    do
    {
      pal_item(++num, pal++);
    } while (num < max);
  }
  return XO_NONE;
}


int pal_list()
{
 char *ptr;
 pid_t pid;
 char fpath[80];
 int page;
 SXO *xo;
 
 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("�P�R���~�A�z��pid�L��!");
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("�Y������, �z���s�b!");
 
 if(!(cuser.userlevel & PERM_BASIC)) 
  msg_quit("�z�S���v��!");
  
 utmp_mode(M_PAL);
 
 page = atoi(nextword(&ptr));
 
 usr_fpath(fpath, cuser.userid, FN_PAL);
 xo = xo_new(fpath);
 xo->page = page;
 
 /* pal_cache(); */
 pal_init(xo);

 free(xo); 
 return 1;  
}

/* ------------------------------------------ */
/* ����B��                                   */
/* ------------------------------------------ */

int pal_add_rqst()
{
 char *ptr;
 pid_t pid;
 char fpath[80];
 struct stat st;
 
 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("�P�R���~�A�z��pid�L��!");
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("�Y������, �z���s�b!");
 
 if(!(cuser.userlevel & PERM_BASIC)) 
  msg_quit("�z�S���v��!");
  
 /* �ˬd�@�U */
 usr_fpath(fpath, cuser.userid, FN_PAL);
 if(!stat(fpath, &st) && ((st.st_size / sizeof(PAL)) > PAL_MAX))
  msg_quit("�z���n�ͦW��Ӧh�A�еy�[��z!");
   
 {
  char *xuserid;
  ACCT acct;
  int userno; 	

  xuserid = nextword(&ptr);
  if(acct_load(&acct, xuserid) < 0)
    msg_quit("���s�b�ӨϥΪ�");
    
  userno = acct.userno;
  pal_cache();
  if(userno == cuser.userno)
   msg_quit("�ۤv���ݭn�[�J�n�ͦW�椤!");
 
  else if(is_pal(userno))
   msg_quit("�n�ͦW�椤�w�g�������!");
 }
 www_printf("OK\n");
 return 1;
}


int pal_add()	/* �u���K�[ */
{
 char *ptr;
 pid_t pid;
 char fpath[80];
 struct stat st;
 
 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("�P�R���~�A�z��pid�L��!");
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("�Y������, �z���s�b!");
 
 if(!(cuser.userlevel & PERM_BASIC)) 
  msg_quit("�z�S���v��!");
  
 /* ������Y�Ϭ����N�X�]�O�L���i���A�����A�ˬd�@�U */
 usr_fpath(fpath, cuser.userid, FN_PAL);
 if(!stat(fpath, &st) && ((st.st_size / sizeof(PAL)) > PAL_MAX))
  msg_quit("�z���n�ͦW��Ӧh�A�еy�[��z!");
   
 {
  char *xuserid;
  ACCT acct;
  int userno; 	

  xuserid = nextword(&ptr);
  if(acct_load(&acct, xuserid) < 0)
    msg_quit("���s�b�ӨϥΪ�");
    
  userno = acct.userno;
  pal_cache();
  
  /*
  if(userno == cuser.userno)
   msg_quit("�ۤv���ݭn�[�J�n�ͦW�椤!");

 
  else    */
  if(is_pal(userno))
   msg_quit("�n�ͦW�椤�w�g�������!");
   
  /* �H�W���_rqst, �u!!! */   

  if (userno > 0)
  {
    PAL pal;
    char *ship;
    int ftype;	/* 0: �n�� 1:�l�� */

    ship = nextword(&ptr);
    ftype = atoi(nextword(&ptr));
    
    strcpy(pal.ship, ship);
    pal.ftype = (ftype ? PAL_BAD : 0);
    strcpy(pal.userid, acct.userid);
    pal.userno = userno;
    rec_add(fpath, &pal, sizeof(PAL));
#ifdef  HAVE_ALOHA
    if ((pal.userno != cuser.userno) && !(pal.ftype & PAL_BAD))
    {
      char folder[64];
      BMW bmw;

      bmw.recver = cuser.userno;
      strcpy(bmw.userid, cuser.userid);
      usr_fpath(folder, pal.userid, FN_FRIEND_BENZ);
      rec_add(folder, &bmw, sizeof(BMW));
    }
#endif  
  }
  www_printf("result=OK&msg=���\\���N%s�[��n�ͦW��̤F!", xuserid); 
 }
 return 1;
}

/* ----------------------------------- */
/* �R���n��                            */
/* ----------------------------------- */

#ifdef HAVE_ALOHA
int
cmpbmw(benz)
  BMW *benz;
{
    return benz->recver == cuser.userno;
}
#endif


int
pal_delete()
{
 char *ptr;
 pid_t pid;
 char fpath[80];
 int pos;
 
 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("�P�R���~�A�z��pid�L��!");
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("�Y������, �z���s�b!");
 
 if(!(cuser.userlevel & PERM_BASIC)) 
  msg_quit("�z�S���v��!");
  
 pos = atoi(nextword(&ptr));
 pos = pos - 1;
 usr_fpath(fpath, cuser.userid, FN_PAL);
 
#ifdef HAVE_ALOHA
 {
   PAL pal;

   if(!rec_get(fpath, &pal, sizeof(PAL), pos))
   {
    if (!(pal.ftype & PAL_BAD))
    {
      char folder[64];      

      usr_fpath(folder, pal.userid, FN_FRIEND_BENZ);
      rec_del(folder, sizeof(BMW), 0, cmpbmw, NULL);
    }
   }
 }
#endif

 if (!rec_del(fpath, sizeof(PAL), pos, NULL, NULL))
   www_printf("result=OK&msg=�R�����\\!");
 else 
   www_printf("result=OK&msg=�R������!");   
 
 return 1;
}

/* --------------------------------------------- */
/* �n�ͦW��ק�                                  */
/* --------------------------------------------- */
int pal_edit()
{
 char *ptr;
 pid_t pid;
 char fpath[80], *xuserid;
 int pos;
 
 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("�P�R���~�A�z��pid�L��!");
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("�Y������, �z���s�b!");
 
 if(!(cuser.userlevel & PERM_BASIC)) 
  msg_quit("�z�S���v��!");
  
 xuserid = nextword(&ptr);
   
 pos = atoi(nextword(&ptr));
 pos = pos - 1;
 usr_fpath(fpath, cuser.userid, FN_PAL);

 {
   PAL pal;
   
   if(!rec_get(fpath, &pal, sizeof(PAL), pos) && !str_cmp(pal.userid, xuserid))
   				/* �ֹ�@�U�W�� */
   {
     char *ship;
     int ftype;
     
     ship = nextword(&ptr);
     ftype = atoi(nextword(&ptr));
     
     strcpy(pal.ship, ship);
     pal.ftype = (ftype == 1 ? PAL_BAD : 0);
     rec_put(fpath, &pal, sizeof(PAL), pos);
     
     www_printf("result=OK&msg=�ק令�\\!");
   }
   else 
     www_printf("result=OK&msg=�ק異��!");
 
 }

 return 1;	
}

/* --------------------------------------------- */
/* �n�ͦW���z                                  */
/* --------------------------------------------- */

void
pal_sync()
{
  int fd, size;
  struct stat st;
  char fpath[64];


  usr_fpath(fpath, cuser.userid, FN_PAL);

  if ((fd = open(fpath, O_RDWR, 0600)) < 0)
    return;

  if (!fstat(fd, &st) && (size = st.st_size) > 0)
  {
    PAL *pbase, *phead, *ptail;
    int userno;

    pbase = phead = (PAL *) malloc(size);
    size = read(fd, pbase, size);
    if (size >= sizeof(PAL))
    {
      ptail = (PAL *) ((char *) pbase + size);
      while (phead < ptail)
      {
        userno = phead->userno;
        if (userno > 0 && userno == acct_userno(phead->userid))
        {
          phead++;
          continue;
        }

        ptail--;
        if (phead >= ptail)
          break;
        memcpy(phead, ptail, sizeof(PAL));
      }

      size = (char *) ptail - (char *) pbase;
      if (size > 0)
      {
        if (size > sizeof(PAL))
        {
          xsort(pbase, size / sizeof(PAL), sizeof(PAL), str_cmp);
        }

        lseek(fd, 0, SEEK_SET);
        write(fd, pbase, size);
        ftruncate(fd, size);
      }
    }
    free(pbase);
  }
  close(fd);

  if (size <= 0)
    unlink(fpath);
}



int pal_sort()
{
 char *ptr;
 pid_t pid;
 
 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("�P�R���~�A�z��pid�L��!");
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("�Y������, �z���s�b!");
 
 if(!(cuser.userlevel & PERM_BASIC)) 
  msg_quit("�z�S���v��!");
  
 pal_sync();	
 
 www_printf("result=OK&msg=��z����!");
 return 1;
}

/* ---------------------------------------------------------- */
/* xchat room                                                 */
/* ---------------------------------------------------------- */
int t_chat()
{		/* G_CMD, pid, chatid , passbuf, */
 char *ptr, *chatid, fpath[64];
 pid_t pid;
 WebReqCmd wrc; 
 
#ifdef CHAT_SECURE
  char *passwd;
#endif
 
 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("�P�R���~�A�z��pid�L��!");
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("�Y������, �z���s�b!");
 
 chatid = nextword(&ptr); 
 if(!chatid) memcpy(chatid, cuser.userid, IDLEN+1);

#ifdef CHAT_SECURE 
 passwd = nextword(&ptr);
#endif 	

 memset(&wrc, 0, sizeof(WebReqCmd));
 wrc.group = G_CMD;
 strcpy(wrc.funckey, "enterchat");
 str_ncpy(wrc.query, cuser.userid, sizeof(cuser.userid));
#ifdef CHAT_SECURE 
 str_ncpy(wrc.query+50, passwd, PASSLEN); 
#endif 	 
 usr_fpath(fpath, cutmp->userid, FN_WEBCMD);/* �@�w�����cuser.userid, ��b�ѱb���W */
 if(access(fpath, 0)) unlink(fpath); 
 if(rec_add(fpath, &wrc, sizeof(WebReqCmd)) < 0) msg_quit("�t�Τ���, �}�ɥX��!"); 	
 
 cutmp->sockport = 0; /* ���è� */
 kill(cutmp->pid, SIGUSR1); /* ���i�৹�������Ȼ�? */
 
 www_printf("OK\n");
 return 1;
}

int s_chat()
{
 char *ptr, *msg, fpath[64];
 pid_t pid;
 
 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("�P�R���~�A�z��pid�L��!");
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("�Y������, �z���s�b!");
 
 /* hightman: �o�˧P�_�s�b���X�z��!
 if(cutmp->mode != M_CHAT)
  msg_quit("�z���b��ѫǤ�!");
  */
  
 msg = nextword(&ptr);

 usr_fpath(fpath, cutmp->userid, FN_WEBCMD);/* �@�w�����cuser.userid, ��b�ѱb���W */
 if(access(fpath, 0)) unlink(fpath); 
 if(rec_add(fpath, msg, strlen(msg)) < 0) msg_quit("�t�Τ���, �}�ɥX��!");

 cutmp->sockport = -1; /* flag */
 
 www_printf("OK\n");
 return 1;	
}

WebKeyFunc talk_cb[] =
{
  {"ulist",	user_list},
  {"sendmsg",	bmw_send},
  {"doquery",	user_query},
  {"flist",	pal_list},
  {"faddrqst",	pal_add_rqst},  
  {"fadd",	pal_add},
  {"fdelete",	pal_delete},
  {"fedit",	pal_edit},
  {"fsort",	pal_sort},
  {"saychat",	s_chat},
  {"chatroom",	t_chat},
  {NULL,	NULL}
};

/* _TALK_C_ */
