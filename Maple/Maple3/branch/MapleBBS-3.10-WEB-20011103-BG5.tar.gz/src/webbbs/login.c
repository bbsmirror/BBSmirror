/*-------------------------------------------------------*/
/* login.c       ( Z�� Shanty MapleBBS Ver 3.10 )        */
/*-------------------------------------------------------*/
/* target : Login Porgram for WebBBS			 */
/* author : hightman.bbs@bbs.dot66.net			 */
/* create : 2001/09/20                                   */
/* update :                                              */
/*-------------------------------------------------------*/

/* _LOGIN_C_ */
#undef _MODES_C_

#include "bbs.h"

extern UCACHE *ushm;
extern u_long tn_addr;

void
login_abort(msg)
  char *msg;
{
  www_printf(msg);
  blog("LOGIN", currtitle);
  exit(0);
} 

void
vt_utmp_setup(mode)
  int mode;
{
  UTMP utmp;
    
#ifdef UNVALID_RAND_NICK  /* hightman.011028: ���{�����H��nickname */
  char *guestname[GUESTNAME]={GUEST_NAMES};
#endif

  memset(&utmp, 0, sizeof(utmp));
  utmp.pid = currpid;
  utmp.userno = cuser.userno;
  utmp.mode = bbsmode = mode;
  utmp.ufo = cuser.ufo;
  utmp.in_addr = tn_addr;
  utmp.idle_time = -1;
  strcpy(utmp.userid, cuser.userid);

#ifdef UNVALID_RAND_NICK
  srand(time(0));
  strcpy(utmp.username, guestname[rand()%GUESTNAME]);
#else
  strcpy(utmp.username, cuser.username);
#endif

  str_ncpy(utmp.from, fromhost, sizeof(utmp.from));

  if (!utmp_new(&utmp))
  {
    login_abort("<html>�z���諸��l�w�g�Q�H�������n�F�A�ФU���A�ӡ�</html>\n");       
  }
  
  /* pal_cache(); */
}

int
vt_login()	/* �����n�� */
{
 char *ptr, *host;
 u_long in_addr;
 
 ptr = myWRC.query;
 host = nextword(&ptr);
 if(*host)
  sprintf(fromhost, "!%s", host);
 
 in_addr = atol(nextword(&ptr));
 if(in_addr)
  tn_addr = in_addr;
 
 currpid = getpid();
 
 /* �򥻿�X */
 www_printf("
 <html>
 <head>
 <!--base href='%s' -->
 <title>%s</title>
 <meta http-equiv='Content-Type' content='text/html; charset=%s'>
 </head>\n", BASEURL, BBSTITLE, BBSCHARSET);
 
 www_printf("
 <script language='JavaScript'>
 <!--hide
 
  var pid = %d;
  
  function bmw_send(uno, msg)
  {
  	if(msg == '' || msg == null) return false;
  	document.sendmsg.uno.value = uno;
  	document.sendmsg.msg.value= msg;
  	document.sendmsg.submit();
  	return true;
  }\n", currpid);
  
 www_printf("
  function bmw_rqst(uno, msg)
  {
  	// :) �g��C��
  	top.bmwFrame.addOne(uno, msg); 
  		
  	var prom = msg+'\\n�^�_: (���^�_���^�Y�i)';
	var xx=prompt(prom,'');
	if(xx=='' || xx==null) return false;
	return bmw_send(uno, xx);
  }
 //-->
 </script>
 <body>\n");
  
 www_printf("
 <form name='sendmsg' target='hideFrame' action='sendmsg.php'>
 <input type='hidden' name='pid' value='%d'>
 <input type='hidden' name='uno'>
 <input type='hidden' name='msg'>
 </form>\n", currpid);
 
 acct_load(&cuser, STR_GUEST);
 
 /* �W���᪺�B�z */
 cuser.lastlogin = ap_start;
 str_ncpy(cuser.lasthost, fromhost, sizeof(cuser.lasthost));
 acct_save(&cuser);
 
 vt_utmp_setup(M_LOGIN);
 bbstate = STAT_STARTED;

 www_printf("<!-- �ڬO�B�z�T���Ϊ�,�ڪ�pid�O: %d -->\n", currpid);
 sleep(2);
 www_printf("<script>if(top.bottomFrame.update_online) top.bottomFrame.update_online('%d', '%d');</script>\n", 
 		ushm->count, get_web_online());
 www_printf("<!--LOGIN-END-->\n");
 
 /* alarm(30);*/
 while(1) { 
   sleep(30); 
   anti_idle();
 }
 
 return 1;
}


int login_logout() /* �����h�X�εn���A����userid */
{
 char *ptr, *userid, *passwd;
 pid_t pid, opid;
 char fpath[80];
 WebReqCmd wrc;
 usint level;
 
 ptr = myWRC.query;
 
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("�P�R���~�Apid�L��!");
 
 userid = nextword(&ptr);
 
 if(!str_cmp(userid, cutmp->userid)) 
 {
   sprintf(fpath, "�z���ӴN�O%s��!", userid);
   msg_quit(fpath);
 }
 
 if(acct_load(&cuser, userid) < 0) msg_quit("�Ϊk�����D, ID����l�I");
 
 passwd = nextword(&ptr);
 
 if(str_cmp(cuser.userid, STR_GUEST) && chkpasswd(cuser.passwd, passwd)) msg_quit("�K�X���~!"); 
 
 /* �]�w���O */
 memset(&wrc, 0, sizeof(WebReqCmd));
 wrc.group = G_CMD;
 strcpy(wrc.funckey, "chgusr");
 str_ncpy(wrc.query, cuser.userid, sizeof(cuser.userid));
 usr_fpath(fpath, cutmp->userid, FN_WEBCMD);/* �@�w�����cuser.userid, ��b�ѱb���W */
 if(access(fpath, 0)) unlink(fpath);
 if(rec_add(fpath, &wrc, sizeof(WebReqCmd)) < 0) msg_quit("�t�Τ���, �}�ɥX��!"); 	
 
 kill(cutmp->pid, SIGUSR1); /* ���i�৹�������Ȼ�? */
 
 /* �B�z�@�U�ѪF�� */
 opid = atoi(nextword(&ptr));
 if(opid >0 && utmp_find_by_pid(opid)) kill(opid, SIGTERM);
 
 level = cuser.userlevel;
 if (level)			/* not guest */
 {
    /* ------------------------------------------------- */
    /* �ֹ� user level					 */
    /* ------------------------------------------------- */
    if (level & PERM_SYSOP)	/* hightman.011028: �������o�Ҧ��v */
      level = ~0 ^ (PERM_DENYMAIL | PERM_DENYTALK | PERM_DENYCHAT | PERM_DENYPOST);
      
#ifdef JUSTIFY_PERIODICAL
    if ((level & PERM_VALID) && !(level & PERM_SYSOP))
    {  /* Thor.980819: �������@�w�������{��, ex. SysOp  */
      if (cuser.tvalid + VALID_PERIOD < ap_start)
      {
	level ^= PERM_VALID;
      }
    }
#endif

    if (!(level & PERM_SYSOP))
    {
#ifdef NEWUSER_LIMIT
      /* Thor.980825: lkchu patch: �J�M�� NEWUSER_LIMIT, �٬O�[�@�U�n�F,
      if (start - cuser.firstlogin < 3 * 86400)
      {
        /* if (!(level & PERM_VALID)) */
        level &= ~PERM_POST;    /* �Y�Ϥw�g�q�L�{���A�٬O�n���ߤT�� */
      } else
#endif
      if(level & PERM_VALID) /* �q�L�{���F, �B���T�ѤF�A�N�֦��o���v�Q */
      {
      	level |= (PERM_DEFAULT | PERM_VALID );      	
      }

      /* Thor.980629: ���g�����{��, �T�� chat/talk/write */
      if(!(level & PERM_VALID))
      {
        level &= ~(PERM_CHAT | PERM_PAGE);
      }

      if (level & PERM_DENYPOST)
	level &= ~PERM_POST;

      if (level & PERM_DENYTALK)
	level &= ~PERM_PAGE;

      if (level & PERM_DENYCHAT)
	level &= ~PERM_CHAT;

      if ((cuser.numemail >> 4) > (cuser.numlogins + cuser.numposts))
	level |= PERM_DENYMAIL;
    }
 }                              
 /* ok �^�Ǥ@�ǪF�� */
 www_printf("result=OK&pid=%d&userno=%d&level=%d",cutmp->pid, cuser.userno, level);
 return 1;
 
}


WebKeyFunc login_cb[] =
{
  {"login",	vt_login},
  {"chgusr",	login_logout},
  {NULL,	NULL}
}; 

/* _LOGIN_C_ */

