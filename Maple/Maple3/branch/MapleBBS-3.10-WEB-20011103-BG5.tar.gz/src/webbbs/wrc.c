/*-------------------------------------------------------*/
/* wrc.c       ( ZJU Shanty MapleBBS Ver 3.10 )          */
/*-------------------------------------------------------*/
/* target : Web Request Command				 */
/* author : hightman.bbs@bbs.dot66.net			 */
/* create : 2001/09/20                                   */
/* update :                                              */
/*-------------------------------------------------------*/


/* _WRC_C_ */

#include "bbs.h"


extern WebKeyFunc login_cb[];
extern WebKeyFunc cmd_cb[];
extern WebKeyFunc talk_cb[];
extern WebKeyFunc mail_cb[];
extern WebKeyFunc board_cb[];
extern WebKeyFunc gem_cb[];
extern WebKeyFunc acct_cb[];

WebCmdGrp WG[] = 
{
  {G_LOGIN,	login_cb},
  {G_CMD,	cmd_cb},
  {G_TALK,	talk_cb},
  {G_MAIL,	mail_cb},
  {G_BOARD,	board_cb},
  {G_GEM,	gem_cb},
  {G_ACCT,	acct_cb},
  {G_OTHER,	NULL},
  {NULL,	NULL}
};

extern void *
wrc_func_get(wrc)
  WebReqCmd *wrc;
{
  int group;
  char *funckey;
  WebKeyFunc *cb;
  WebCmdGrp *ptr;

  group = wrc->group;		/* ����X�b����Group */
  cb = WG[group].cb;
  if(WG[group].group != group)	/* �U�@���F, �q�Y��_ */
  {
   for(ptr = WG;ptr->group;ptr++)
   {
     if(group == ptr->group)
       cb = ptr->cb;
   }
  }
  
  if(!cb)			/* �٨S���H�X���F! */
    return NULL;  
    
  funckey =wrc->funckey;    
  for(;cb->funckey;cb++)
  {
    if(!strcmp(funckey,cb->funckey))
    {
      return cb->func;
    }
  }
  
  return NULL;          	
}
/* _WRC_C_ */
