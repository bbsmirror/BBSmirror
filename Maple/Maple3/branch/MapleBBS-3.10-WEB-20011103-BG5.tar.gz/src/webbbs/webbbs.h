/*-------------------------------------------------------*/
/* webBBS.h      ( NTHU CS MapleBBS Ver 3.00 )           */
/*-------------------------------------------------------*/
/* target : definitions that webBBS dameon used		 */
/* author : hightman.bbs@bbs.dot66.net			 */
/* create : 2001/09/20                                   */
/* update :                                              */
/*-------------------------------------------------------*/

#ifndef	_WEBBBS_H_
#define	_WEBBBS_H_

/* ----------------------------------------------------- */
/* Basic Setup                                           */
/* ----------------------------------------------------- */

#define	DEBUG			/* �{���������� */

#define	PID_FILE	"run/webbbsd.pid"
#define	LOG_FILE	"run/webbbsd.log"

#define	FN_WEBCMD	".WWWCMD"

#define	WEB_PORT	7000	/* �q�{���ݤf�� */
#define	QLEN		3

#define	MAX_BUF_SIZE	4096
#define	MAX_CACHE_SIZE	2048

#define	WWW_READ_TIMEOUT	1800	/* 30 mins */
#define	WWW_WRITE_TIMEOUT	300	/* 5 mins */

#define	BBSTITLE	"������aBBS"
#define	BBSCHARSET	"gb2312"
#define	BASEURL		"/~maple/webbbs/"

/* ----------------------------------------------------- */
/* Web Request Command Struct Data                       */
/* ----------------------------------------------------- */

typedef struct
{
	int	group;		/* �[�t�� :-p */
	char	funckey[24];	/* function's key */
	char	query[100];	/* query string: pid&userid&passwd.....*/
}	WebReqCmd;

typedef struct
{
	char	*funckey;
	int	(*func) ();
}	WebKeyFunc; 

typedef struct
{
	int		group;
	WebKeyFunc	*cb;
}	WebCmdGrp;

WebReqCmd myWRC;	/* �����ܶq�A�ڪ�wrc */

/* xover.c ���B�Ϊ����c�A��XO²��� */
typedef struct SimpleOverView
{
  int top;                      /* top First num */
  int max;                      /* max, all */
  int page;			/* now the page? */  
  int key;                      /* key reserved */  
  char dir[0];                  /* data path */
}	SXO;


#ifdef  _MAIN_C_
#define	VAR
#define	INI(x)		= x
#else
#define	VAR		extern
#define	INI(x)
#endif 

#define	G_LOGIN		(0)
#define	G_CMD		(1)
#define	G_TALK		(2)
#define	G_MAIL		(3)
#define	G_BOARD		(4)
#define	G_GEM		(5)
#define	G_ACCT		(6)
#define	G_OTHER		(7)
#define	G_MAX		G_OTHER


#endif                          /* _WEBBBS_H_ */
