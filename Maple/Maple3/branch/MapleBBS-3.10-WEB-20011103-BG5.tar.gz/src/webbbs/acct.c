/*-------------------------------------------------------*/
/* acct.c      ( NTHU CS MapleBBS Ver 3.00 )             */
/*-------------------------------------------------------*/
/* target : Some Functions About Account		 */
/* author : hightman.bbs@bbs.dot66.net			 */
/* create : 2001/09/20                                   */
/* update :                                              */
/*-------------------------------------------------------*/

/* _ACCT_C_ */

#undef _ADMIN_C_

#include "bbs.h"

/* ----------------------------------------------------- */
/* (.ACCT) �ϥΪ̱b�� (account) subroutines              */
/* ----------------------------------------------------- */


int
acct_load(acct, userid)
  ACCT *acct;
  char *userid;
{
  int fd;

  usr_fpath((char *) acct, userid, FN_ACCT);
  fd = open((char *) acct, O_RDONLY);
  if (fd >= 0)
  {
    /* Thor.990416: �S�O�`�N, ���� .ACCT�����׷|�O0 */
    read(fd, acct, sizeof(ACCT));
    close(fd);
  }
  return fd;
}

void
acct_save(acct)
  ACCT *acct;
{
  int fd;
  char fpath[80];

  usr_fpath(fpath, acct->userid, fn_acct);
  fd = open(fpath, O_WRONLY, 0600);     /* fpath �����w�g�s�b */
  if (fd >= 0)
  {
    write(fd, acct, sizeof(ACCT));
    close(fd);
  }
}


int
acct_userno(userid)
  char *userid;
{
  int fd;
  int userno;
  char fpath[80];

  usr_fpath(fpath, userid, fn_acct);
  fd = open(fpath, O_RDONLY);
  if (fd >= 0)
  {
    read(fd, &userno, sizeof(userno));
    close(fd);
    return userno;
  }
  return 0;
}


/* ----------------------------------------------------- */
/* �ˬd�ϥΪ̱b���O�_�s�b		                 */
/* ----------------------------------------------------- */
static int
belong(flist, key)
  char *flist;
  char *key;
{
  int fd, rc;

  rc = 0;
  fd = open(flist, O_RDONLY);
  if (fd >= 0)
  {
    mgets(-1);

    while (flist = mgets(fd))
    {
      str_lower(flist, flist);
      if (str_str(key, flist))
      {
        rc = 1;
        break;
      }
    }

    close(fd);
  }
  return rc;
}


static int
is_badid(userid)
  char *userid;
{
  int ch;
  char *str;

  if (strlen(userid) < 2)
    return 1;

  if (!is_alpha(*userid))
    return 1;

  if (!str_cmp(userid, "new"))
    return 1;

  str = userid;
  while (ch = *(++str))
  {
    if (!is_alnum(ch))
      return 1;
  }
  return (belong("etc/badid", userid));
}


static int
is_fitid(userid)
 char *userid;
{
 char buf[80];
 
 if(is_badid(userid))
   msg_quit("�L�k�����o�ӥN���A�Шϥέ^��r���A�åB���n�]�t�Ů�");
 
 usr_fpath(buf, userid, NULL);
 if (dashd(buf))
   msg_quit("���N���w�g���H�ϥ�");

 www_printf("OK\n");   
 return 1; 	
}

int chk_userid()	/* �ˬd�@�U�O�_���s�b���b�� */
{
 char *ptr, *userid;
 
#ifndef LOGINASNEW 
 msg_quit("��p�I�����Ȯɰ���s�Τ���U�I");
#endif

 ptr = myWRC.query;
 userid = nextword(&ptr);
 
 return is_fitid(userid);
}


/* ----------------------------------------------------- */
/* �s���U�ϥΪ̱b��			                 */
/* ----------------------------------------------------- */

static int
uniq_userno(fd)
  int fd;
{
  char buf[4096];
  int userno, size;
  SCHEMA *sp;                   /* record length 16 �i�㰣 4096 */

  userno = 1;

  while ((size = read(fd, buf, sizeof(buf))) > 0)
  {
    sp = (SCHEMA *) buf;
    do
    {
      if (sp->userid[0] == '\0')
      {
        lseek(fd, -size, SEEK_CUR);
        return userno;
      }
      userno++;
      size -= sizeof(SCHEMA);
      sp++;
    } while (size);
  }

  return userno;
}


int acct_apply()
{
 char *ptr, *userid;

 ptr = myWRC.query;
 userid = nextword(&ptr);
 
 is_fitid(userid);	/* �A���ˬd */
 
 /* �U���}�lŪ�J���U��� */
 /* PASS: ******	�K�X
  * NAME: abcdef	�O��
  * RNME: realname	�u�W
  * ADDR: address	�a�}
  */
 {
  char buf[80], *str;
  SCHEMA slot;
  int fd;
  
  memset(&cuser, 0, sizeof(cuser));
  memcpy(cuser.userid, userid, IDLEN);
  
  while(www_gets(buf, 128) > 0) /* ����Ŧ�N���� */
  {
    str = buf + 6;
    if(!str_ncmp(buf, "PASS", 4)) 
     str_ncpy(cuser.passwd, genpasswd(str), PASSLEN);
    else if(!str_ncmp(buf, "NAME", 4))
     str_ncpy(cuser.username, str, 19);
    else if(!str_ncmp(buf, "RNME", 4))
     str_ncpy(cuser.realname, str, 23);
    else if(!str_ncmp(buf, "ADDR", 4))
     str_ncpy(cuser.address, str, 59);         	
  }   

  cuser.userlevel = PERM_BASIC;
  cuser.ufo = UFO_COLOR | UFO_MOVIE | UFO_BNOTE;
  cuser.numlogins = 1;
#ifdef HAVE_MONEY_ISM
  cuser.money=1000; /* �s���U����1000 */
#endif
#ifdef HAVE_COUNT_MARK
  cuser.nummark=0;
#endif  

  cuser.firstlogin = cuser.lastlogin = cuser.tcheck = slot.uptime = ap_start;
  memcpy(slot.userid, userid, IDLEN);

  fd = open(FN_SCHEMA, O_RDWR | O_CREAT, 0600);
  {
    f_exlock(fd);
    cuser.userno = uniq_userno(fd);
    write(fd, &slot, sizeof(slot));
    f_unlock(fd);
  }
  close(fd);

  /* create directory */
  usr_fpath(buf, userid, NULL);
  mkdir(buf, 0755);
  strcat(buf, "/@");
  mkdir(buf, 0755);

  usr_fpath(buf, userid, fn_acct);
  fd = open(buf, O_WRONLY | O_CREAT, 0600);
  write(fd, &cuser, sizeof(cuser));
  close(fd);
  /* Thor.990416: �`�N: ���|�� .ACCT���׬O0��, �ӥB�u�� @�ؿ�, �����[� */

  sprintf(buf, "%d", cuser.userno);
  blog("APPLY", buf);   	
 }
 www_printf("result=OK&msg=���U���\\<%s>\n", userid);
 return 1;	
}
/* ----------------------------------------------------- */
/* �s�Τ�Բ�g���U��			                 */
/* ----------------------------------------------------- */
int register_rqst()
{
  pid_t pid;
  char *ptr;
  FILE *fn;
  RFORM rform;  

  ptr = myWRC.query;
 
  pid = atoi(nextword(&ptr));
  cutmp = utmp_find_by_pid(pid);
 
  if (!cutmp) msg_quit("�P�R���~�Apid�L��!");

  utmp_mode(M_UMENU); 
  if (acct_load(&cuser, cutmp->userid) < 0) msg_quit("�Ϊk�����D, ID����l�I");
  
  if ((cuser.userlevel & PERM_VALID) || !cuser.userlevel)
    msg_quit("�z�������T�{�w�g�����A���ݶ�g�ӽЪ�");  
  
  if (fn = fopen(fn_rform, "rb"))
  {
    while (fread(&rform, sizeof(RFORM), 1, fn))
    {
      if ((rform.userno == cuser.userno) &&
        !str_cmp(rform.userid, cuser.userid))
      {
        fclose(fn);
        msg_quit("�z�����U�ӽг�|�b�B�z���A�Э@�ߵ���");
      }
    }
    fclose(fn);
  }
    
  www_printf("result=OK&address=%s&realname=%s\n", cuser.address, cuser.realname);
  return 1;	
}

int
u_register()
{
  FILE *fn;
  RFORM rform;
  pid_t pid;
  char *ptr;
 
  ptr = myWRC.query;
 
  pid = atoi(nextword(&ptr));
  cutmp = utmp_find_by_pid(pid);
 
  if (!cutmp) msg_quit("�P�R���~�Apid�L��!");
 
  if (acct_load(&cuser, cutmp->userid) < 0) msg_quit("�Ϊk�����D, ID����l�I");  

  if ((cuser.userlevel & PERM_VALID) || !cuser.userlevel)
    msg_quit("�z�������T�{�w�g�����A���ݶ�g�ӽЪ�");

  if (fn = fopen(fn_rform, "rb"))
  {
    while (fread(&rform, sizeof(RFORM), 1, fn))
    {
      if ((rform.userno == cuser.userno) &&
        !str_cmp(rform.userid, cuser.userid))
      {
        fclose(fn);
        msg_quit("�z�����U�ӽг�|�b�B�z���A�Э@�ߵ���");
      }
    }
    fclose(fn);
  }

 /* �U���}�lŪ�J���U��� */
 /* RNME: realname	�u�W
  * CARE: abcdef	���
  * ADDR: address	�a�}
  * PHON: phone		�q��
  */
 {
  char buf[80], *str;
    
  memset(&rform, 0, sizeof(RFORM));
  strcpy(rform.realname, cuser.realname);
  strcpy(rform.address, cuser.address);
  rform.career[0] = rform.phone[0] = '\0';  
  
  www_printf("OK\n");  
  while(www_gets(buf, 128) > 0) /* ����Ŧ�N���� */
  {
    str = buf + 6;
    if(!str_ncmp(buf, "RNME", 4)) 
     str_ncpy(rform.realname, str, 23);
    else if(!str_ncmp(buf, "CARE", 4))
     str_ncpy(rform.career, str, 49);
    else if(!str_ncmp(buf, "ADDR", 4))
     str_ncpy(rform.address, str, 59);
    else if(!str_ncmp(buf, "PHON", 4))
     str_ncpy(rform.phone, str, 19);         	
  } 

  strcpy(cuser.realname, rform.realname);
  strcpy(cuser.address, rform.address);

  rform.userno = cuser.userno;
  strcpy(rform.userid, cuser.userid);
  (void) time(&rform.rtime);
  rec_add(fn_rform, &rform, sizeof(RFORM));
  acct_save(&cuser);
 }
  www_printf("result=OK&msg=���U��w�g�H�X~�Э@�ߵ��ԯ������f��!\n");
  return 1;
}


/* ----------------------------------------------------- */
/* �Τ�ק���U���			                 */
/* ----------------------------------------------------- */

int update_rqst() /* �ШD�ק�A��^�즳��� */
{
  pid_t pid;
  char *ptr;

  ptr = myWRC.query;
 
  pid = atoi(nextword(&ptr));
  cutmp = utmp_find_by_pid(pid);
 
  if (!cutmp) msg_quit("�P�R���~�Apid�L��!");

  utmp_mode(M_UMENU); 
  if (acct_load(&cuser, cutmp->userid) < 0) msg_quit("�Ϊk�����D, ID����l�I");
  
  www_printf("result=OK&nickname=%s&address=%s&realname=%s", cuser.username, cuser.address, cuser.realname);
  www_printf("&numlogins=%d&numposts=%d&staytime=%d&firstlogin=%s",
  				cuser.numlogins, cuser.numposts, cuser.staytime/3600, Ctime(&cuser.firstlogin));
  www_printf("&lastlogin=%s&lasthost=%s\n", Ctime(&cuser.lastlogin), cuser.lasthost);
  
  return 1;
}	

int u_update()	/* �� �K�X:�u�W:�a�} */
{
  pid_t pid;
  char *ptr, *passwd;

  ptr = myWRC.query;
 
  pid = atoi(nextword(&ptr));
  cutmp = utmp_find_by_pid(pid);
 
  if (!cutmp) msg_quit("�P�R���~�Apid�L��!");
 
  if (acct_load(&cuser, cutmp->userid) < 0) msg_quit("�Ϊk�����D, ID����l�I");
  
  passwd = nextword(&ptr);
  if(chkpasswd(cuser.passwd, passwd)) msg_quit("�K�X���~!");
  
  /* �H�W���򥻻{�� Auth */
  {
   char buf[80], *str;  

   www_printf("OK\n");  
   while(www_gets(buf, 128) > 0) /* ����Ŧ�N���� */
   {
     str = buf + 6;
     if(!str_ncmp(buf, "PASS", 4)) 
      str_ncpy(cuser.passwd, genpasswd(str), PASSLEN);
     else if(!str_ncmp(buf, "NAME", 4))
      str_ncpy(cuser.username, str, 19);
     else if(!str_ncmp(buf, "RNME", 4))
      str_ncpy(cuser.realname, str, 23);
     else if(!str_ncmp(buf, "ADDR", 4))
      str_ncpy(cuser.address, str, 59);  	
   }  
   strcpy(cutmp->username, cuser.username);
   acct_save(&cuser);
   www_printf("result=OK&msg=�ק令�\\!\n");
   sprintf(buf, "%s@%s", cuser.userid, cutmp->from);
   blog("UPDATE", buf);
  }
  return 1;
}

/* ----------------------------------------------------- */
/* �Τ�ק�p�H�ɮ�			                 */
/* ----------------------------------------------------- */
int ufile_rqst() /* �ШD�ק�Apid, filename */
{
  pid_t pid;
  char *ptr, *filename;

  ptr = myWRC.query;
 
  pid = atoi(nextword(&ptr));
  cutmp = utmp_find_by_pid(pid);
 
  if (!cutmp) msg_quit("�P�R���~�Apid�L��!");

  if (acct_load(&cuser, cutmp->userid) < 0) msg_quit("�Ϊk�����D, ID����l�I");
  
  filename = nextword(&ptr);
  
  if(*filename)
  {
   char fpath[80];
   
   utmp_mode(M_UFILES);    
   usr_fpath(fpath, cuser.userid, filename);    
   www_printf("result=OK&msg=�i�H�ק�F�A�ɮצp�U: \n\n");
   article_show(fpath);   
  }
  else
   www_printf("���~�A�D�k���X�ݤ覡!\n");
  
  return 1;
}

int u_file()
{
  pid_t pid;
  char *ptr, *filename;

  ptr = myWRC.query;
 
  pid = atoi(nextword(&ptr));
  cutmp = utmp_find_by_pid(pid);
 
  if (!cutmp) msg_quit("�P�R���~�Apid�L��!");

  if (acct_load(&cuser, cutmp->userid) < 0) msg_quit("�Ϊk�����D, ID����l�I");
  
  filename = nextword(&ptr);
  
  if(*filename)
  {
   char fpath[80], ftmp[80];
   
   file_edit();   
   usr_fpath(fpath, cuser.userid, filename);    
   usr_fpath(ftmp, cuser.userid, ".tmp");
   f_mv(ftmp, fpath);
   unlink(ftmp);
   www_printf("result=OK&msg=�ק令�\\!!&file=%s\n", filename); 
  }
  else
   www_printf("���~�A�D�k���X�ݤ覡!\n");
  
  return 1;
}


int u_setup()
{
  pid_t pid;
  char *ptr;
  int ufo, ufo2;

  ptr = myWRC.query;
 
  pid = atoi(nextword(&ptr));
  cutmp = utmp_find_by_pid(pid);
 
  if (!cutmp) msg_quit("�P�R���~�Apid�L��!");

  if (acct_load(&cuser, cutmp->userid) < 0) msg_quit("�Ϊk�����D, ID����l�I");
  
  ufo = atoi(nextword(&ptr)); /* �� -1 ����rqst */
  if(ufo < 0) 
  {
    www_printf("result=OK&ufo=%d&ufo2=%d&msg=�^��ufo�F", cuser.ufo, cutmp->ufo); /* �Hcuser.ufo���� */
  }
  else 
  {
    ufo2 = atoi(nextword(&ptr));
    cuser.ufo = ufo;
    cutmp->ufo = ufo2;
    acct_save(&cuser);
    www_printf("result=OK&msg=�ק令�\\!!\n"); 
  }
  return 1;
}

/* ----------------------------------------------------- */
/* �]�w E-mail address					 */
/* ----------------------------------------------------- */

#if 1
static int
ban_addr(addr)
  char *addr;
{
  int i;
  char *host, *str;
  char foo[64]; /* SoC: ��m���ˬd�� email address */

  static char *invalid[] =
  { "root@", "gopher@",/* "bbs@", "@bbs", */
    "guest@", "@ppp", "@slip", "@dial", "unknown@", "@anon.penet.fi",
    "193.64.202.3", NULL
  };

  /* SoC: �O���� email ���j�p�g */
  str_lower(foo, addr);

  for (i = 0; str = invalid[i]; i++)
  {
    if (strstr(foo, str))
      return 1;
  }

  /* check for mail.acl (lower case filter) */

  host = (char *) strchr(foo, '@');
  *host = '\0';
  /* i = acl_has(MAIL_ACLFILE, foo, host + 1); */
  /* Thor.981223: �Nbbsreg�ڵ��������} */
  i = acl_has(UNTRUST_ACLFILE, foo, host + 1);
  /* *host = '@'; */
  if(i < 0)
    TRACE("NOACL",host);
  return i > 0;
}

#endif

int mail_justify()	/* hightman.011028: �q�l�l����U */
{
  pid_t pid;
  char *ptr, *email, *msg;

  ptr = myWRC.query;
 
  pid = atoi(nextword(&ptr));
  cutmp = utmp_find_by_pid(pid);
 
  if (!cutmp) msg_quit("�P�R���~�Apid�L��!");

  if (acct_load(&cuser, cutmp->userid) < 0) msg_quit("�Ϊk�����D, ID����l�I");
  
  email = nextword(&ptr);
  
  msg = "E-Mail �a�}��s";

  if (not_addr(email) || ban_addr(email))
  {
    msg = "���X�檺 E-mail address";
  }  
  else  
  {
    int vtime;

#ifndef EMAIL_JUSTIFY	/* hightman.011028: ����email�{���N���εo�F�a? :) */
    www_printf("result=OK&msg=%s", msg);
    return 0;
#endif

#ifndef USE_SENDMAIL
    vtime = bsmtp(NULL, NULL, email, MQ_JUSTIFY);
#else	  
    vtime = bbs_sendmail(NULL, NULL, email, MQ_JUSTIFY);
#endif        

    if (vtime < 0)
    {
	www_printf("result=OK&msg=�����{���H��L�k�H�X�A�Х��T��g E-mail address");
	return 0;
    }
    else
    {
      cuser.userlevel &= ~(PERM_VALID  | PERM_POST | PERM_PAGE  );
      cuser.vtime = vtime;
      strcpy(cuser.email, email);
      acct_save(&cuser);
      
      www_printf("result=OK&msg=%s(%s)�z�n�A�ѩ�z��s E-mail address ���]�w�A�бz�ɧ֨� [%s] �Ҧb���u�@���^�Сy�����{���H��z�C", cuser.userid, cuser.username, email);
      return 1;
     }
   }
  return 1;
}


WebKeyFunc acct_cb[] =
{
  {"chkuserid",	chk_userid},
  {"newuser",	acct_apply},
  {"regrqst",	register_rqst},
  {"regform",	u_register},
  {"modrqst",	update_rqst},
  {"modinfo",	u_update},
  {"ufilerqst",	ufile_rqst},
  {"modufile",	u_file},
  {"ufosetup",	u_setup},  
  {"mjustify",	mail_justify},
  {NULL,	NULL}
}; 
/* _ACCT_C_ */
