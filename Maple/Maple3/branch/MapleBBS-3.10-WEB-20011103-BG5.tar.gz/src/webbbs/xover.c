/*-------------------------------------------------------*/
/* xover.c      ( NTHU CS MapleBBS Ver 2.36 )            */
/*-------------------------------------------------------*/
/* target : board/mail interactive reading routines      */
/* create : 95/03/29                                     */
/* update : 95/12/15                                     */
/*-------------------------------------------------------*/

#include "bbs.h"

SXO *
xo_new(path)
  char *path;
{
  SXO *xo;
  int len;

  len = strlen(path) + 1;

  xo = (SXO *) malloc(sizeof(SXO) + len);

  memcpy(xo->dir, path, len);

  return (xo);
}


/* ----------------------------------------------------- */
/* interactive menu routines			 	 */
/* ----------------------------------------------------- */

char xo_pool[XO_TALL * XO_RSIZ];


void
xo_load(xo, recsiz)
  SXO *xo;
  int recsiz;
{
  int fd, max;

  max = 0;
  if ((fd = open(xo->dir, O_RDONLY)) >= 0)
  {
    int page, top;
    struct stat st;

    fstat(fd, &st);
    max = st.st_size / recsiz;
    if (max > 0)
    {
      page = xo->page;
      	
      top = max / XO_TALL;		/* top = TOtalPage? */
      if((top * XO_TALL) != max) top = top+1;
      
      if(page > top || page < 1) page = top;
      
      top = (page-1) * XO_TALL;		/* �u����top */
            
      xo->top = top;
      xo->page = page;

      lseek(fd, (off_t) (recsiz * top), SEEK_SET);
      read(fd, xo_pool, recsiz * XO_TALL);
     }
    close(fd);
  }
  xo->max = max;
}
