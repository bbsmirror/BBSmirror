/*-------------------------------------------------------*/
/* edit.c       ( NTHU CS MapleBBS Ver 2.36 )            */
/*-------------------------------------------------------*/
/* target : simple ANSI/Chinese editor                   */
/* create : 95/03/29                                     */
/* update : 95/12/15                                     */
/*-------------------------------------------------------*/


#include "bbs.h"

/* ------------------------------------------------ */
/* �ި��B�z					    */
/* ------------------------------------------------ */

#define	QUOTE_CHAR	'>'

static int
is_quoted(str)
  char *str;                    /* "--\n", "-- \n", "--", "-- " */
{
  if (*str == '-')
  {
    if (*++str == '-')
    {
      if (*++str == ' ')
        str++;
      if (*str == '\n')
        str++;
      if (!*str)
        return 1;
    }
  }
  return 0;
}


static int
quote_line(str, qlimit)
  char *str;
  int qlimit;                   /* ���\�X�h�ި��H */
{
  int qlevel = 0;
  int ch;

  while ((ch = *str) == QUOTE_CHAR || ch == ':')
  {
    if (*(++str) == ' ')
      str++;
    if (qlevel++ >= qlimit)
      return 0;
  }
  while ((ch = *str) == ' ' || ch == '\t')
    str++;
  if (qlevel >= qlimit)
  {
    if (!memcmp(str, "�� ", 3) || !memcmp(str, "==>", 3) ||
      strstr(str, ") ����:\n"))
      return 0;
  }
  return (*str != '\n');
}


/* �q�X�峹 */
int
article_show(fpath)
 char *fpath;
{
 int fd, nbyte;
 char buf[1024];

 if((fd = open(fpath,O_RDONLY)) >= 0)
 {
  www_cache_init();
  while((nbyte = read(fd, buf, 1023)) > 0)
  {
   buf[nbyte] = '\0';
   www_cache_write(buf, nbyte);
  }
  close(fd);
  www_cache_refresh();
 }
 return fd;
}


/* �����峹�s�� */
void
article_edit()
{
  char fpath[80], buf[128], *str;
  FILE *fp;
  time_t now;
  int sign, fd;
  
  time(&now);  
  
  www_printf("OK\n"); /* �}�l�������e */
  if(www_gets(ve_title, 80) < 7) msg_quit("�t�Τ���, �������D�ɵo�Ϳ��~!");
  
  usr_fpath(fpath, cuser.userid, ".tmp"); 
  if((fp = fopen(fpath, "w")) == NULL) msg_quit("�t�Τ���, �}�ɿ��~!");  

#ifdef HAVE_ANONYMOUS  
  if ((bbstate & BRD_ANONYMOUS) && (curredit & EDIT_ANONYMOUS))
    fprintf(fp, "�@��: %s (%s)\n���D: %s\n�ɶ�: %s\n\n", "[�ڤ��i�D�A]", "�q�q�ڬO�� ^o^", ve_title + 7, Ctime(&now));
  else
#endif  
    fprintf(fp, "�@��: %s (%s)\n���D: %s\n�ɶ�: %s\n\n", cuser.userid, cuser.username, ve_title + 7, Ctime(&now));
  
  while(www_gets(buf, 128) >= 0)
  {
    if(!str_ncmp(buf, "<--POST-END-->", 14)) break;
    fprintf(fp, "%s\n", buf);	
  }  


#ifdef HAVE_ANONYMOUS  
  if ((bbstate & BRD_ANONYMOUS) && (curredit & EDIT_ANONYMOUS))
    fprintf(fp, "--\n\033[1;32m�� Origin: \033[33m%s \033[37m<%s> \033[m\n\033[1;31m�� From: \033[36m%s\033[m\n",
          str_site, MYHOSTNAME, "�ΦW�ѨϪ��a");  
  else
#endif
  {
    /* ñ�W�ɳB�z */
    sign = cuser.numemail;
    if(sign > 0 && sign < 4)
    {
      usr_fpath(buf, cuser.userid, "sign");
      fd = open(buf, O_RDONLY);
      if (fd >= 0)
      {
        sign = (sign - 1) * MAXSIGLINES;
        mgets(-1);
        while (str = mgets(fd))
        {
          if (--sign >= 0)
            continue;

          if (sign == -1)
          {
            fprintf(fp, "--\n");
          }

	  fprintf(fp, "%s\n", str);
          if (sign <= -MAXSIGLINES)
            break;
         }
         close(fd);
       }
     }
     
    fprintf(fp, "--\n\033[1;32m�� Origin: \033[33m%s \033[37m<%s> \033[m\n\033[1;31m�� From: \033[36m%s\033[m\n",
          str_site, MYHOSTNAME, cutmp->from);  
  }
  fclose(fp); 
  
  /* �έp�Q�j�� */
  
   if (!(bbstate & BRD_NOSTAT))/* �ݪO���ǤJ�έp */
    {
      /* ���Ͳέp��� */
  
      struct
      {
        char author[IDLEN + 1];
        char board[IDLEN + 1];
        char title[66];
        time_t date;            /* last post's date */
        int number;             /* post number */
      }      postlog;

      char *title;
      
#ifdef HAVE_ANONYMOUS
      if ((bbstate & BRD_ANONYMOUS) && (curredit & EDIT_ANONYMOUS))
        strcpy(postlog.author, "[���i�D�A]");
      else
#endif  
        strcpy(postlog.author, cuser.userid);

      strcpy(postlog.board, currboard);

      title = ve_title + 7;
      str_ncpy(postlog.title, str_ttl(title), sizeof(postlog.title));
      postlog.date = now;
      postlog.number = 1;

      rec_add("run/post", &postlog, sizeof(postlog));
    }
}

/* �ޥΤ��s�� */
void
quote_edit(fpath, hdr)
 char *fpath;
 HDR *hdr;
{
  char folder[80];
  FILE *fp;
  
  hdr_fpath(folder, fpath, hdr);
  
  if (fp = fopen(folder, "r"))
   {
      char *str, buf[256], buf2[256];
      
      str = buf;
      if (hdr->nick[0])
        sprintf(buf + 128, " (%s)", hdr->nick);
      else
        buf[128] = '\0';
        
      www_cache_init();

      sprintf(buf2,"�� �ޭz�m%s%s�n���ʨ��G\n", hdr->owner, buf + 128);
      www_cache_write(buf2, strlen(buf2));
                        
      while (fgets(str, 256, fp) && *str != '\n');
      /* while (fgets(str, 256, fp) && (!memcmp(str, "�� ", 3))); */ /* �h���� �s�զW�� */
            
      *str++ = QUOTE_CHAR;
      *str++ = ' ';
      
      while (fgets(str, 254, fp))
      {
       if(!memcmp(str, "�� ", 3)) continue;/* �h���� �s�զW�� */
       
       if (is_quoted(str)) /* "--\n" */
           break;
       if (quote_line(str, 1))
       	   www_cache_write(buf, strlen(buf));
      } 
       fclose(fp);      
       www_cache_refresh();
    }
   else
    msg_quit("���~�A�}���ɮ׿��~!");
}

/* �p��r�� */
int
xfile_size(fpath, hdr)
 char *fpath;
 HDR *hdr;
{
  char folder[80];
  FILE *fp;
  int fsize;
  
  hdr_fpath(folder, fpath, hdr);
  
  fsize = 0;
  if (fp = fopen(folder, "r"))
   {
      char *str, buf[256], buf2[3];
      
      str = buf;
                        
      while (fgets(str, 256, fp) && *str != '\n');
      sprintf(buf2, "%c ", QUOTE_CHAR);
                  
      while (fgets(str, 255, fp))
      {
       if(!memcmp(str, "�� ", 3)) continue;/* �h���� �s�զW�� */
       if(!memcmp(str, buf2, 2)) continue; /* �ި��]���p�J */
       if (is_quoted(str)) /* "--\n" */
           break;                  
	fsize += strlen(buf);
      } 
       fclose(fp);
    }
    
  return fsize;
}


/* �����ɮ׽s�� */
void
file_edit()
{
  char fpath[80], buf[128];
  FILE *fp;
  time_t now;
  
  time(&now);  
  
  www_printf("OK\n"); /* �}�l�������e */
  
  usr_fpath(fpath, cuser.userid, ".tmp"); 
  if((fp = fopen(fpath, "w")) == NULL) msg_quit("�t�Τ���, �}�ɿ��~!");  

  while(www_gets(buf, 128) >= 0)
  {
    if(!str_ncmp(buf, "<--FILE-END-->", 14)) break;
    fprintf(fp, "%s\n", buf);	
  }
  fclose(fp); 
}
/* _EDIT_C_ */
