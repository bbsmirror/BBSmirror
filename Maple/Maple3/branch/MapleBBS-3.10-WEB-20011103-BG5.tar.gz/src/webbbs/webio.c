/*-------------------------------------------------------*/
/* webIO.c      ( NTHU CS MapleBBS Ver 3.00 )            */
/*-------------------------------------------------------*/
/* target : Basic input/output Function for WebBBS	 */
/* author : hightman.bbs@bbs.dot66.net			 */
/* create : 2001/09/20                                   */
/* update :                                              */
/*-------------------------------------------------------*/

/* _WEBIO_C_ */

#include <varargs.h>

#include "bbs.h"

char www_cache[MAX_CACHE_SIZE];
int www_cache_count;

int
www_write(buf, nbyte)
char *buf;
int nbyte;
{
	int count, relwrite;

	count = 0;
	while (count < nbyte)	/* ���Τ@�`�@�`���g�a */
	{
		relwrite = write(1, &buf[count], nbyte - count);
		if (relwrite < 0 && errno != EINTR) /* �D���_���~*/		
			abort_bbs();
		else
			count += relwrite;
	}
	
	return count;
}

int
www_read(buf, nbyte)
char *buf;
int nbyte;
{	
	int count, relread;
	count = 0;
 	while(count < nbyte)
 	{
   		relread = read(0, &buf[count], nbyte - count);
   		if(relread<0 && errno != EINTR)
   			abort_bbs();
		else
			count += relread;
	}   			
	
	return count;
}


int
www_gets(buf, maxlen)
char *buf;
int maxlen;
{
	int i, j;
	char c;
	
	i = 0;
	maxlen--;
	while (i < maxlen)
	{
		
		j = read(0, &c, 1);
		if (j < 0)
			return -2;        
		else if (c == '\n')
			break;
		else if (c != '\r')
			buf[i++] = c;
	}
	buf[i] = '\0';
	return i;
}


int
sock_gets(buf, maxlen, socket)
char *buf;
int maxlen;
int socket;
{
	int i, j;
	char c;

	i = 0;
	maxlen--;
	while (i < maxlen)
	{
		j = read(socket, &c, 1);
		if (j < 0)
			return -2;
		else if (c == '\n')
			break;
		else if (c != '\r')
			buf[i++] = c;
	}
	buf[i] = '\0';
	return i;
}

int
www_printf(va_alist)
va_dcl
{
	va_list args;
	char *format;
	int len;
	int ret = 0;
	char printstr[MAX_BUF_SIZE];	

	va_start(args);
	format = va_arg(args, char *);
	vsprintf(printstr, format, args);
	va_end(args);

	len = strlen(printstr);
	if (len > 0)
		ret = www_write(printstr, len);
	return ret;
}


void
www_cache_init()
{
	www_cache_count = 0;
	memset(www_cache, 0, MAX_CACHE_SIZE);
}

int
www_cache_write(char *buf, int buflen)
{
	if (MAX_CACHE_SIZE - www_cache_count < buflen)
		www_cache_refresh();

	if (buflen > MAX_CACHE_SIZE)
		return -1;

	memcpy(&www_cache[www_cache_count], buf, buflen);
	www_cache_count += buflen;
}

void
www_cache_refresh()
{
	if (www_cache_count == 0)
		return;
	www_write(www_cache, www_cache_count);
	www_cache_count = 0;
}
/* _WEBIO_C_ */
