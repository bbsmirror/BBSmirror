/*
 * BBS implementation dependendent part
 * 
 * The only two interfaces you must provide
 * 
 * #include "inntobbs.h" int receive_article(); 0 success not 0 fail
 * 
 * if (storeDB(HEADER[MID_H], hispaths) < 0) { .... fail }
 * 
 * int cancel_article_front( char *msgid );	     0 success not 0 fail
 * 
 * char *ptr = (char*)DBfetch(msgid);
 * 
 * ���줧�峹���e (body)�b char *BODY, ���Y (header)�b char *HEADER[] SUBJECT_H,
 * FROM_H, DATE_H, MID_H, NEWSGROUPS_H, NNTPPOSTINGHOST_H, NNTPHOST_H,
 * CONTROL_H, PATH_H, ORGANIZATION_H
 */

/*
 * Sample Implementation
 * 
 * receive_article()         --> post_article()   --> bbspost_write_post();
 * cacnel_article_front(mid) --> cancel_article() --> bbspost_write_cancel();
 */


#define	storeDB	HERwrite


#ifndef PowerBBS
#include "innbbsconf.h"
#include "daemon.h"
#include "bbslib.h"
#include "inntobbs.h"
#include "lang.h"

extern int Junkhistory;


#ifdef	MapleBBS
#define storeDB	HERwrite
static char myfrom[256], mysubject[128];

#else

static char *post_article ARG((char *, char *, char *, char *));
static int cancel_article ARG((char *, char *));


report()
{
  /* Function called from record.o */
  /* Please leave this function empty */
}
#endif


#if defined(PalmBBS)

#ifndef PATH
#define PATH XPATH
#endif

#ifndef HEADER
#define HEADER XHEADER
#endif

#endif

#define XLOG	bbslog

static void
stripn_ansi(buf, str, len)
  char *buf, *str;
  int len;
{
  register int ch, ansi;

  /* chuan: check null */

  if (str != NULL)
  {
    for (ansi = 0; ch = *str; str++)
    {
      if (ch == '\n')
      {
	break;
      }
      else if (ch == 27)
      {
	ansi = 1;
      }
      else if (ansi)
      {
	if (!strchr("[01234567;", ch))
	  ansi = 0;
      }
      else
      {
	*buf++ = ch;
	if (--len <= 0)
	  break;
      }
    }
  }
  *buf = '\0';
}


/* process post write */


static int
bbspost_write_post(fh, board)
  int fh;
  char *board;
{
  register FILE *fhfd = fdopen(fh, "w");
  register char *fptr, *ptr;
  register int mode, ch;
  char buf[128];

  if (fhfd == NULL)
  {
    close(fh);
    bbslog("can't fdopen, maybe disk full\n");
    return -1;
  }

#if 0
  stripn_ansi(buf, FROM, 57);
#endif

  fprintf(fhfd, "�o�H�H: %.57s, �ݪO: %s\n", FROM, board);

#if 0
  str_decode(SUBJECT);

  stripn_ansi(buf, SUBJECT, 128);
  str_decode(buf);
  str_ncpy(SUBJECT = mysubject, buf, 70);
  stripn_ansi(SUBJECT, SUBJECT, 70);
#endif

  fprintf(fhfd, "��  �D: %s\n", SUBJECT);

  stripn_ansi(buf, SITE, 43);
  fprintf(fhfd, "�o�H��: %s (%s)\n", buf, DATE);

  fprintf(fhfd, "��H��: %s\n", PATH);

  if (POSTHOST != NULL)
  {
    fprintf(fhfd, "Origin: %.70s\n", POSTHOST);
  }

  fprintf(fhfd, "\n%s", BODY);	/* chuan: header �� body �n�Ŧ��} */
  fclose(fhfd);
  close(fh);
  return 0;
}


#ifdef	KEEP_NETWORK_CANCEL
/* process cancel write */
bbspost_write_cancel(fh, board, filename)
  int fh;
  char *board, *filename;
{
  char *fptr, *ptr;

  FILE *fhfd = fdopen(fh, "w"), *fp;
  FILE *fhfd;

  char buffer[256];

  if (fhfd == NULL)
  {
    bbslog("can't fdopen, maybe disk full\n");
    return -1;
  }

//  fprintf(fhfd, "�o�H�H: %s, �H��: %s\n", FROM, board);
//  fprintf(fhfd, "��  �D: %s\n", SUBJECT);
//  fprintf(fhfd, "�o�H��: %.43s (%s)\n", SITE, DATE);
//  fprintf(fhfd, "��H��: %.70s\n", PATH);
    fprintf(fhfd,"%s%s, %s%s\n",FromTxt, FROM, BoardTxt, board);
    fprintf(fhfd,"%s%s\n", SubjectTxt, SUBJECT);
    fprintf(fhfd,"%s%.43s (%s)\n",OrganizationTxt,SITE,DATE);
    fprintf(fhfd,"%s%s\n",PathTxt, PATH);

  if (HEADER[CONTROL_H] != NULL)
  {
    fprintf(fhfd, "Control: %s\n", HEADER[CONTROL_H]);
  }
  if (POSTHOST != NULL)
  {
   fprintf(fhfd, "Origin: %s\n", POSTHOST);
  }
  fprintf(fhfd, "\n");
  for (fptr = BODY, ptr = strchr(fptr, '\r'); ptr != NULL && *ptr != '\0'; fptr = ptr + 1, ptr = strchr(fptr, '\r'))
  {
    int ch = *ptr;

    *ptr = '\0';
    fputs(fptr, fhfd);
    *ptr = ch;
  }
  fputs(fptr, fhfd);
  if (POSTHOST != NULL)
  {
    fprintf(fhfd, "\n * Origin: �� %.26s �� From: %.40s\n", SITE, POSTHOST);
  }
  fprintf(fhfd, "\n---------------------\n");
  fp = fopen(filename, "r");
  if (fp == NULL)
  {
    bbslog("can't open %s\n", filename);
    return -1;
  }
  while (fgets(buffer, sizeof buffer, fp) != NULL)
  {
    fputs(buffer, fhfd);
  }
  fclose(fp);
  fflush(fhfd);
  fclose(fhfd);

  {
    fp = fopen(filename, "w");
    if (fp == NULL)
    {
      bbslog("can't write %s\n", filename);
      return -1;
    }
    //fprintf(fp, "�o�H�H: %s, �H��: %s\n", FROM, board);
    //fprintf(fp, "��  �D: %.70s\n", SUBJECT);
    //fprintf(fp, "�o�H��: %.43s (%s)\n", SITE, DATE);
    //fprintf(fp, "��H��: %.70s\n", PATH);
    fprintf(fp,"%s%s, %s%s\n",FromTxt, FROM, BoardTxt, board);
    fprintf(fp,"%s%s\n", SubjectTxt, SUBJECT);
    fprintf(fp,"%s%.43s (%s)\n",OrganizationTxt,SITE,DATE);
    fprintf(fp,"%s%s\n",PathTxt, PATH);

    if (POSTHOST != NULL)
    {
      fprintf(fhfd, "Origin: %s\n", POSTHOST);
    }
    if (HEADER[CONTROL_H] != NULL)
    {
      fprintf(fhfd, "Control: %s\n", HEADER[CONTROL_H]);
    }
    fprintf(fp, "\n");
    for (fptr = BODY, ptr = strchr(fptr, '\r'); ptr != NULL && *ptr != '\0'; fptr = ptr + 1, ptr = strchr(fptr, '\r'))
    {
      *ptr = '\0';
      fputs(fptr, fp);
    }
    fputs(fptr, fp);
    if (POSTHOST != NULL)
    {
      fprintf(fp, "\n * Origin: �� %.26s �� From: %.40s\n", SITE, POSTHOST);
    }
    fclose(fp);
  }
  return 0;
}
#endif				/* KEEP_NETWORK_CANCEL */


#ifndef	MapleBBS
bbspost_write_control(fh, board, filename)
  int fh;
  char *board;
  char *filename;
{
  char *fptr, *ptr;
  FILE *fhfd = fdopen(fh, "w");

  if (fhfd == NULL)
  {
    bbslog("can't fdopen, maybe disk full\n");
    return -1;
  }

  fprintf(fhfd, "Path: %s!%s\n", MYBBSID, HEADER[PATH_H]);
  fprintf(fhfd, "From: %s\n", FROM);
  fprintf(fhfd, "Newsgroups: %s\n", GROUPS);
  fprintf(fhfd, "Subject: %s\n", SUBJECT);
  fprintf(fhfd, "Date: %s\n", DATE);
  fprintf(fhfd, "Organization: %s\n", SITE);
  if (POSTHOST != NULL)
  {
    fprintf(fhfd, "NNTP-Posting-Host: %.70s\n", POSTHOST);
  }
  if (HEADER[CONTROL_H] != NULL)
  {
    fprintf(fhfd, "Control: %s\n", HEADER[CONTROL_H]);
  }
  if (HEADER[APPROVED_H] != NULL)
  {
    fprintf(fhfd, "Approved: %s\n", HEADER[APPROVED_H]);
  }
  if (HEADER[DISTRIBUTION_H] != NULL)
  {
    fprintf(fhfd, "Distribution: %s\n", HEADER[DISTRIBUTION_H]);
  }
  fprintf(fhfd, "\n");
  for (fptr = BODY, ptr = strchr(fptr, '\r'); ptr != NULL && *ptr != '\0'; fptr = ptr + 1, ptr = strchr(fptr, '\r'))
  {
    int ch = *ptr;

    *ptr = '\0';
    fputs(fptr, fhfd);
    *ptr = ch;
  }
  fputs(fptr, fhfd);


  fflush(fhfd);
  fclose(fhfd);
  return 0;
}
#endif				/* MapleBBS */


time_t datevalue;


#if defined(PhoenixBBS) || defined(SecretBBS) || defined(PivotBBS) || defined(MapleBBS)
/* for PhoenixBBS's post article and cancel article */
#ifdef MapleBBS
/* Thor.990318: ���LHEADER���w�q, ���M HEADER���w�q�|�R�� */
#define _DNS_H_ 
#endif
#include "bbs.h"


/* ----------------------------------------------------- */
/* chrono ==> file name (32-based)			 */
/* 0123456789ABCDEFGHIJKLMNOPQRSTUV			 */
/* ----------------------------------------------------- */


char radix32[32] = {
  '0', '1', '2', '3', '4', '5', '6', '7',
  '8', '9', 'A', 'B', 'C', 'D', 'E', 'F',
  'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
  'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
};


void
archiv32(chrono, fname)
  register time_t chrono;	/* 32 bits */
  register char *fname;		/* 7 chars */
{
  register char *str;

  str = fname + 7;
  *str = '\0';
  for (;;)
  {
    *(--str) = radix32[chrono & 31];
    if (str == fname)
      return;
    chrono >>= 5;
  }
}


static time_t
chrono32(str)
  register char *str;		/* 0123456 */
{
  register time_t chrono;
  register int ch;

  chrono = 0;
  while (ch = *str++)
  {
    ch -= '0';
    if (ch >= 10)
      ch -= 'A' - '0' - 10;
    chrono = (chrono << 5) + ch;
  }
  return chrono;
}


static char *
post_article(board, userid, usernick, firstpath)
  char *board, *userid, *usernick;
  char *firstpath;
{
  static char name[8];
  char *fname, fpath[128];
  HDR header;
  time_t now;
  int fh, linkflag;

  sprintf(fpath, "brd/%s/@/A", board);
  fname = strrchr(fpath, 'A') + 1;

  now = time(NULL);
  while (1)
  {
    archiv32(now, fname);
    fname[-3] = fname[6];

    fh = open(fpath, O_CREAT | O_EXCL | O_WRONLY, 0644);
    if (fh >= 0)
      break;

    if (errno != EEXIST)
    {
      bbslog(" Err: can't write or other errors\n");
      return NULL;
    }
    now++;
  }

  strcpy(name, fname);

  linkflag = 1;

  if (firstpath && *firstpath)
  {
    close(fh);
    unlink(fpath);

#ifdef DEBUGLINK
    bbslog("try to link %s to %s", firstpath, fpath);
#endif

    linkflag = link(firstpath, fpath);
    if (linkflag)
    {
      fh = open(fpath, O_CREAT | O_EXCL | O_WRONLY, 0644);
    }
  }
  if (linkflag)
  {
    if (bbspost_write_post(fh, board) < 0)
      return NULL;

    if (firstpath)
      strcpy(firstpath, fpath);	/* opus : write back */
  }

  bzero((void *) &header, sizeof(header));
  header.chrono = now;
  header.xmode = POST_INCOME;
  strcpy(header.xname, --fname);
#if 0
  strcpy(header.owner, userid);
  strcpy(header.nick, usernick);
#endif
  /* Thor.980825: ����r��Ӫ��\�L�Y */
  strncpy(header.owner, userid, sizeof(header.owner)-1);
  strncpy(header.nick, usernick, sizeof(header.nick)-1);

  {
    struct tm *ptime;

    ptime = localtime(&datevalue);
    /* Thor.990329: y2k */
    sprintf(header.date, "%02d/%02d/%02d",
      ptime->tm_year % 100, ptime->tm_mon + 1, ptime->tm_mday);
  }
  /* Thor.980825: ����r��Ӫ��\�L�Y */
#if 0
  strcpy(header.title, SUBJECT);
#endif
  strncpy(header.title, SUBJECT, sizeof(header.title)-1);

  strcpy(fname - 2, ".DIR");
  /* Thor.980825: �S�O�`�N fpath�O�_�|�g�J bbs home */
  if ((fh = open(fpath, O_WRONLY | O_CREAT | O_APPEND, 0644)) < 0)
  {
    return NULL;
  }

  write(fh, &header, sizeof(header));
  close(fh);

  return name;
}


static int
cancel_article(board, time)
  char *board;
  register time_t time;
{
  HDR header;
  struct stat state;
  register long size;
  register int fd, ent;
  char buf[128];

  /* XLOG("cancel [%s] %d\n", board, time); */

  sprintf(buf, "brd/%s/.DIR", board);
  if ((fd = open(buf, O_RDWR)) == -1)
    return 0;

  /* XLOG("cancel folder [%s]\n", buf); */

  /* flock(fd, LOCK_EX); */
  /* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
  f_exlock(fd);

  fstat(fd, &state);
  size = sizeof(header);
  ent = ((long) state.st_size) / size;
  while (1)
  {
    ent -= 16;
    if (ent <= 0)
      break;
    lseek(fd, size * ent, SEEK_SET);
    if (read(fd, &header, size) != size)
      break;

    if (header.chrono <= time)
    {
      /* XLOG("cancel 1: %s\n", header.xname); */

      do
      {
	if (header.chrono == time)
	 if (header.chrono == time && !(header.xmode & POST_MARKED)) 
	{ /* Thor.980824: �T�� mark���峹�Qcancel */
          /* Thor.981014: �Q�Q��F, cancel�Ncancel�a... */
	  /* hightman.001119: �[�W,��deardragon */
	  header.xmode |= POST_CANCEL;
	  if (POSTHOST)
	  {
	    sprintf(board = buf, "cancel by: %s", POSTHOST);
	    board[TTLEN] = '\0';
	  }
	  else
	  {
	    board = "<< article canceled >>";
	  }
	  strcpy(header.title, board);
	  lseek(fd, (off_t) - size, SEEK_CUR);
	  write(fd, &header, size);
	  break;
	}
	if (header.chrono > time)
	  break;
      } while (read(fd, &header, size) == size);
      break;
    }
  }

  /* flock(fd, LOCK_UN); */
  /* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
  f_unlock(fd);

  close(fd);
  return 0;
}


#elif defined(PalmBBS)
#undef PATH XPATH
#undef HEADER XHEADER
#include "server.h"


char *
post_article(homepath, userid, board, writebody, pathname, firstpath)
  char *homepath;
  char *userid, *board;
  int (*writebody) ();
char *pathname, *firstpath;

{
  PATH msgdir, msgfile;
  static PATH name;

  READINFO readinfo;
  SHORT fileid;
  char buf[MAXPATHLEN];
  struct stat stbuf;
  int fh;

  strcpy(msgdir, homepath);
  if (stat(msgdir, &stbuf) == -1 || !S_ISDIR(stbuf.st_mode))
  {
    /* A directory is missing! */
    bbslog(":Err: Unable to post in %s.\n", msgdir);
    return NULL;
  }
  get_filelist_ids(msgdir, &readinfo);

  for (fileid = 1; fileid <= BBS_MAX_FILES; fileid++)
  {
    int oumask;

    if (test_readbit(&readinfo, fileid))
      continue;
    fileid_to_fname(msgdir, fileid, msgfile);
    sprintf(name, "%04x", fileid);

#ifdef DEBUG
    printf("post to %s\n", msgfile);
#endif

    if (firstpath && *firstpath)
    {

#ifdef DEBUGLINK
      bbslog("try to link %s to %s", firstpath, msgfile);
#endif

      if (link(firstpath, msgfile) == 0)
	break;
    }
    oumask = umask(0);
    fh = open(msgfile, O_CREAT | O_EXCL | O_WRONLY, 0664);
    umask(oumask);
    if (writebody)
    {
      if ((*writebody) (fh, board, pathname) < 0)
	return NULL;
    }
    else
    {
      if (bbspost_write_post(fh, board, pathname) < 0)
	return NULL;
    }
    close(fh);
    break;
  }

#ifdef CACHED_OPENBOARD
  {
    char *bname;

    bname = strrchr(msgdir, '/');
    if (bname)
      notify_new_post(++bname, 1, fileid, stbuf.st_mtime);
  }
#endif

  return name;
}

cancel_article(homepath, board, file)
  char *homepath;
  char *board, *file;
{
  PATH fname;

#ifdef  CACHED_OPENBOARD
  PATH bdir;
  struct stat stbuf;

  sprintf(bdir, "%s/boards/%s", homepath, board);
  stat(bdir, &stbuf);
#endif

  sprintf(fname, "%s/boards/%s/%s", homepath, board, file);
  unlink(fname);
  /* kill it now! the function is far small then original..  :) */
  /* because it won't make system load heavy like before */

#ifdef CACHED_OPENBOARD
  notify_new_post(board, -1, hex2SHORT(file), stbuf.st_mtime);
#endif
}

#else
error("You should choose one of the systems: PhoenixBBS, PowerBBS, or PalmBBS")
#endif

#else

receive_article()
{
}

cancel_article_front(msgid)
  char *msgid;
{
}
#endif


/* process cancel write */


/* opus : a lot of modification here */


#if 0
static void
unify_from(addr, userid, usernick)
  register char *addr, *userid, *usernick;
{
  register char *ptr, *lesssym;

  *usernick = 0;

  ptr = (char *) strchr(addr, '@');
  if (ptr == NULL)
  {
    sprintf(userid, "err@%s", addr);
    return;
  }

  lesssym = (char *) strchr(addr, '<');
  if (lesssym == NULL || (*addr != '"' && lesssym >= ptr))
  {
    /* mail_addr (name) */
    /* mail_addr */

    if (ptr = strchr(addr, '('))
    {
      ptr[-1] = 0;
      if (lesssym = strrchr(++ptr, ')'))
      {
	*lesssym = 0;
	strcpy(usernick, ptr);
	str_decode(usernick);
      }
    }
    strcpy(userid, addr);
  }
  else
  {
    /* name <mail_addr> */

    ptr = lesssym - 2;
    if (*addr == '"')
    {
      addr++;
      if (*ptr == '"')
	ptr--;
    }
    if (*addr == '(')
    {
      addr++;
      if (*ptr == ')')
	ptr--;
    }
    ptr[1] = '\0';
    strcpy(usernick, addr);
    str_decode(usernick);

    if (ptr = strchr(++lesssym, '>'))
      *ptr = '\0';
    strcpy(userid, lesssym);
  }
}
#endif


#ifdef	_ANTI_SPAM_
/* ---------------------------------------------------- */
/* anti-spam						 */
/* ---------------------------------------------------- */


#define SPAM_HASH_SIZE  2048


typedef struct SpamHeader
{
  unsigned int zauthor;
  unsigned int ztitle;
  unsigned int zbody;

  char *author;
  char *title;
  newsfeeds_t *nf;		/* �Ĥ@���X�{�b���� newsfeeds */

  int count;			/* ���X�g�w�o�{ */
  int cspam;			/* ���X�g�Q�d�I */
  time_t uptime;		/* �̪�X�{�ɶ� */

  struct SpamHeader *next;
}          SpamHeader;


static SpamHeader *SpamBucket[SPAM_HASH_SIZE];


static unsigned int
str_zcode(str, len)
  unsigned char *str;
  int len;
{
  unsigned int code, cc;

  code = 32713;
  while (cc = *str++)
  {
    code = (code << 3) ^ cc ^ len;
    if (--len <= 0)
      break;
  }

  return code;
}


static SpamHeader *
spam_find(spam)
  SpamHeader *spam;
{
  SpamHeader *hash;
  unsigned int zauthor, ztitle, zbody;
  char *author, *title;

  zauthor = spam->zauthor;

  if (hash = SpamBucket[zauthor & (SPAM_HASH_SIZE - 1)])
  {
    ztitle = spam->ztitle;
    zbody = spam->zbody;
    author = spam->author;
    title = spam->title;

    do
    {
      if (zbody == spam->zbody && zauthor == hash->zauthor &&
	ztitle == hash->ztitle && !strcmp(hash->author, author) &&
	!strcmp(hash->title, title))
	break;
    } while (hash = hash->next);
  }

  return hash;
}


static void
spam_add(spam)
  SpamHeader *spam;
{
  SpamHeader *hash;
  int zcode;

  zcode = spam->zauthor & (SPAM_HASH_SIZE - 1);
  spam->author = strdup(spam->author);
  spam->title = strdup(spam->title);

  hash = (SpamHeader *) malloc(sizeof(SpamHeader));
  memcpy(hash, spam, sizeof(SpamHeader));

  time(&hash->uptime);
  hash->next = SpamBucket[zcode];
  SpamBucket[zcode] = hash;
}


void
spam_expire()
{
  time_t now, due;
  int i;
  SpamHeader *spam, **prev, *next;
  FILE *fp;

  due = time(&now) - 60 * 60;
  fp = fopen("innd/spam.log", "a");
  fprintf(fp, "[%d] %s\n", now, ctime(&now));

  for (i = 0; i < SPAM_HASH_SIZE; i++)
  {
    if (spam = SpamBucket[i])
    {
      prev = &SpamBucket[i];
      do
      {
	next = spam->next;
	fprintf(fp, "[%d] %d %d\n  %s\n  %s\n",
	  spam->uptime, spam->count, spam->cspam,
	  spam->author, spam->title);

	if (spam->uptime < due)
	{
	  free(spam->author);
	  free(spam->title);
	  free(spam);
	  *prev = next;
	}
	else
	{
	  prev = &(spam->next);
	}
      } while (spam = next);
    }
  }

  fclose(fp);
}
#endif				/* _ANTI_SPAM_ */


/* ---------------------------------------------------- */


static int
receive_article()
{
  register char *ngptr, *nngptr, *pathptr;
  register char **splitptr;
  register char *fname;
  register newsfeeds_t *nf;
  char xdate[32];
  char xpath[180];
  char hispaths[2048];
  char firstpath[128], *firstpathbase;
  register int hislen;
  char boardhome[80];
  char myaddr[128], mynick[128];

  /* Thor.980825:
        gc patch:
            ��]
             a.lib/str_decode �u�౵�� decode �� strlen < 256 ...
             b.�ɶq���ק� lib , �ӥB�Ӫ��� from �M subject ���G�S����N�q. */
 
#if 0
  stripn_ansi(hispaths, FROM, 512);
#endif
  stripn_ansi(hispaths, FROM, 255);


  str_decode(hispaths);
  str_ncpy(myfrom, hispaths, sizeof(myfrom));
  FROM = myfrom;

#if 0
  stripn_ansi(hispaths, SUBJECT, 512);
#endif
  stripn_ansi(hispaths, SUBJECT, 255);


  str_decode(hispaths);
  str_ncpy(mysubject, hispaths, 70);
  SUBJECT = mysubject;

#ifdef _ANTI_SPAM_
  SpamHeader zart, *spam;
#endif

#if 0
  strcpy(hispaths, FROM);
  str_from(hispaths, myaddr, mynick);
#endif

#ifdef _ANTI_SPAM_
  memset(&zart, 0, sizeof(zart));
  zart.zauthor = str_zcode(zart.author = myaddr, 256);
  zart.ztitle = str_zcode(zart.title = str_ttl(SUBJECT), 128);
  zart.zbody = str_zcode(BODY, 512);

  if (spam = spam_find(&zart))
  {
    time(&spam->uptime);
    if ((++spam->count > 6) || spam->cspam)
    {
      ++spam->cspam;
      return 0;
    }
  }
#endif

#if 0
  if (FROM == NULL)
  {
    bbslog(":Err: article without usrid %s\n", MSGID);
    return 0;
  }
#endif

  firstpath[0] = *hispaths = hislen = 0;
  firstpathbase = firstpath;

  /* try to split newsgroups into separate group and check if any duplicated */

  splitptr = (char **) BNGsplit(GROUPS);

  /* try to use hardlink */

  /*
   * for ( ngptr = GROUPS, nngptr = (char*) strchr(ngptr,','); ngptr != NULL
   * && *ngptr != '\0'; nngptr = (char*)strchr(ngptr,',')) {
   */

  /* for (ngptr = *splitptr; ngptr; ngptr = *(++splitptr)) /* opus */
  while (ngptr = *splitptr++)
  {
    char *boardptr, *nboardptr;

    /* if (nngptr != NULL) { nngptr = '\0'; } */

    if (!*ngptr)
      continue;

    nf = (newsfeeds_t *) search_group(ngptr);
    if (nf == NULL)
    {
      /* bbslog( "unwanted \'%s\'\n", ngptr ); */
      /* if( strstr( ngptr, "tw.bbs" ) != NULL ) { } */
      continue;
    }

#ifdef	_ANTI_SPAM_
    if (spam)
    {
      if (spam->nf == nf)	/* �P�@�� newsgroup ���_ post ==> �c�ʭ��j */
      {
	spam->count++;
	spam->cspam++;
	break;
      }
    }
    else
    {
      zart.count++;

      if (!zart.nf)
	zart.nf = nf;
    }
#endif

    if (!(boardptr = nf->board) || !*boardptr)
      continue;
    if (nf->path == NULL || !*nf->path)
      continue;

    for (nboardptr = (char *) strchr(boardptr, ','); boardptr && *boardptr; nboardptr = (char *) strchr(boardptr, ','))
    {
      if (nboardptr)
      {
	*nboardptr = '\0';
      }
      if (*boardptr != '\t')
      {

#ifndef	MapleBBS
	boardhome = (char *) fileglue("%s/boards/%s", BBSHOME, boardptr);

	if (!isdir(boardhome))
	{
	  bbslog(":Err: unable to write %s\n", boardhome);
	  continue;
	}
#endif

	if (!hislen)		/* opus : �Ĥ@�� */
	{
	  char poolx[256];

	  str_ncpy(poolx, FROM, 255);
	  str_from(poolx, myaddr, mynick);

#if 000
	  if (mynick[0])
	  {
	    sprintf(FROM = myfrom, "%s (%s)", myaddr, mynick);
	  }
#endif

	  datevalue = parsedate(DATE, NULL);

	  if (datevalue > 0)
	  {
	    memcpy(xdate, ctime(&datevalue), 24);
	    xdate[24] = '\0';
	    DATE = xdate;
	  }

#ifndef	MapleBBS
	  if (SITE && strcasecmp("Computer Science & Information Engineering NCTU", SITE) == 0)
	  {
	    //SITE = "��j��u News Server";
	    SITE = NCTUCSIETxt;
	  }
	  else if (SITE && strcasecmp("Dep. Computer Sci. & Information Eng., Chiao Tung Univ., Taiwan, R.O.C", SITE) == 0)
	  {
	    //SITE = "��j��u News Server";
	    SITE = NCTUCSIETxt;
	  }
	  else if (SITE == NULL || *SITE == '\0')
	  {
	    if (nameptrleft != NULL && nameptrright != NULL)
	    {
	      static char sitebuf[80];
	      char savech = *nameptrright;

	      *nameptrright = '\0';
	      strncpy(sitebuf, nameptrleft, sizeof sitebuf);
	      *nameptrright = savech;
	      SITE = sitebuf;
	    }
	    else
	      /* SITE = "(Unknown)"; */
	      SITE = "";
	  }
	  if (strlen(MYBBSID) > 70)
	  {
	    bbslog(" :Err: your bbsid %s too long\n", MYBBSID);
	    return 0;
	  }
#endif

	  sprintf(xpath, "%s!%.*s", MYBBSID, sizeof(xpath) - strlen(MYBBSID) - 2, PATH);
	  for (pathptr = PATH = xpath; pathptr = strstr(pathptr, ".edu.tw");)
	  {
	    strcpy(pathptr, pathptr + 7);
	  }
	  xpath[71] = '\0';

#ifndef	MapleBBS
	  echomaillog();
#endif
	}

	/*
	 * if ( !isdir( boardhome )) { bbslog( ":Err: unable to write
	 * %s\n",boardhome); testandmkdir(boardhome); }
	 */

	if (fname = (char *) post_article(boardptr, myaddr, mynick, firstpath))
	{
	  register int flen;

	  sprintf(xpath, "%s/%s", boardptr, fname);
	  flen = strlen(fname = xpath);

#ifndef	MapleBBS
	  if (firstpath[0] == '\0')
	  {
	    sprintf(firstpath, "%s/boards/%s", BBSHOME, fname);
	    firstpathbase = firstpath + strlen(BBSHOME) + strlen("/boards/");
	  }
#endif

	  if (flen + hislen < sizeof(hispaths) - 2)
	  {
	    if (hislen)
	    {
	      hispaths[hislen++] = ' ';
	    }

	    strcpy(hispaths + hislen, fname);
	    hislen += flen;

#if 000
	    strcpy(hispaths + hislen, fname);
	    hislen += flen;
	    strcpy(hispaths + hislen - 1, " ");
#endif
	  }
	}
	else
	{
	  bbslog(":Err: board %s\n", boardptr);
	  return 0;		/* opus : -1 */
	}
      }

      /* boardcont: */

      if (nboardptr)
      {
	*nboardptr = ',';
	boardptr = nboardptr + 1;
      }
      else
	break;

    }				/* for board1,board2,... */
    /* if (nngptr != NULL) ngptr = nngptr + 1; else break; */

#ifndef	MapleBBS
    if (*firstpathbase)
      feedfplog(nf, firstpathbase, 'P');
#endif
  }

#ifndef	MapleBBS
  if (*hispaths)
    bbsfeedslog(hispaths, 'P');
#endif

  if (hislen || Junkhistory)
  {
    if (storeDB(HEADER[MID_H], hispaths) < 0)
    {
      bbslog("store DB fail\n");
      /* I suspect here will introduce duplicated articles */
      /* return -1; */
    }
  }

#ifdef	_ANTI_SPAM_
  if (!spam)
  {
    spam_add(&zart);
  }
#endif

  return 0;
}


#ifndef	MapleBBS
receive_control()
{
  char *boardhome, *fname;
  char firstpath[MAXPATHLEN], *firstpathbase;
  char **splitptr, *ngptr;
  newsfeeds_t *nf;

  bbslog("control post %s\n", HEADER[CONTROL_H]);
  boardhome = (char *) fileglue("%s/boards/control", BBSHOME);
  testandmkdir(boardhome);
  *firstpath = '\0';
  if (isdir(boardhome))
  {
    fname = (char *) post_article(boardhome, FROM, "control", bbspost_write_control, NULL, firstpath);
    if (fname != NULL)
    {
      if (firstpath[0] == '\0')
	sprintf(firstpath, "%s/boards/control/%s", BBSHOME, fname);
      if (storeDB(HEADER[MID_H], (char *) fileglue("control/%s", fname)) < 0)
      {
      }
      bbsfeedslog(fileglue("control/%s", fname), 'C');
      firstpathbase = firstpath + strlen(BBSHOME) + strlen("/boards/");
      splitptr = (char **) BNGsplit(GROUPS);
      for (ngptr = *splitptr; ngptr != NULL; ngptr = *(++splitptr))
      {
	if (*ngptr == '\0')
	  continue;
	nf = (newsfeeds_t *) search_group(ngptr);
	if (nf == NULL)
	  continue;
	if (nf->board == NULL)
	  continue;
	if (nf->path == NULL)
	  continue;
	feedfplog(nf, firstpathbase, 'C');
      }
    }
  }
  return 0;
}
#endif				/* MapleBBS */


#define XLOG	bbslog


static int
cancel_article_front(msgid)
  char *msgid;
{
  register char *ptr = (char *) DBfetch(msgid);
  register char *filelist;
  char histent[1024], filename[80], myfrom[128];
  char buffer[256];
  register char *token;

#ifndef	MapleBBS
  char firstpath[MAXPATHLEN], *firstpathbase;
#endif

  /* XLOG("cancel %s <%s>\n", HEADER[FROM_H], msgid);  */

  if (ptr == NULL)
    return 0;

  str_from(HEADER[FROM_H], myfrom, buffer);

  /* XLOG("cancel %s (%s)\n", myfrom, buffer); */

  str_ncpy(filelist = histent, ptr, sizeof histent);

#if 000
  if (filelist = strchr(filelist, '\t'))
  {
    filelist++;
  }

  XLOG("cancel list (%s)\n", filelist);
#endif

  for (ptr = filelist; ptr && *ptr;)
  {
    register char *file;
    register int fd;

    for (; *ptr && isspace(*ptr); ptr++);
    if (*ptr == '\0')
      break;
    file = ptr;

    /* XLOG("cancel file (%s)\n", file); */

    for (ptr++; *ptr && !isspace(*ptr); ptr++);
    if (*ptr != '\0')
    {
      *ptr++ = '\0';
    }

    /* XLOG("cancel file-2 (%s)\n", file);  */

    token = strchr(file, '/');
    if (!token)
      return 0;

    /* XLOG("cancel token (%s)\n", token);  */

    *token++ = '\0';
    sprintf(filename, "brd/%s/%c/A%s", file, token[6], token);

    /* XLOG("cancel path (%s)\n", filename);  */

#ifdef	MapleBBS
    if ((fd = open(filename, O_RDONLY)) >= 0)
    {
      register char *xfrom;
      register int len;


      len = read(fd, buffer, 128);
      close(fd);

#if 0
      if ((len < 8) || memcmp(buffer, "�o�H�H: ", 8))
	return 0;
#endif

      /* SoC: get local artilce headers for cancel back */

      //if ((len > 8) && (memcmp(buffer, "�o�H�H: ", 8) == 0))
	if ((len > 8) && (memcmp(buffer, FromTxt, 8) == 0))
      {
        /* Thor.981221: �`��: �~�Ӥ峹 */
	char *str;

	buffer[len] = '\0';
	xfrom = buffer + 8;
	if (str = strchr(xfrom, '\n'))
	  *str = '\0';
	if (str = strrchr(xfrom, ','))
	  *str = '\0';

	if (strstr(xfrom, myfrom))
	  fd = -1;
      }
//�@�ӥ������F�� -- by hightman  �@�̤G�r�S�w�q :p
      else if ((len > 6) && (memcmp(buffer, "�@��: ", 6) == 0))
      {
	char XFROM[128];
        buffer[len] = '\0';
         if (xfrom = strchr(buffer + 6, ' '))
          *xfrom = '\0';
        sprintf(XFROM, "%s.bbs@%s", buffer + 6, BBSADDR);
        xfrom = XFROM;
        buffer[len] = '\0';
        if (xfrom = strchr(buffer + 6, ' '))
          *xfrom = '\0';
        sprintf(XFROM, "%s.bbs@%s", buffer + 6, BBSADDR);
        xfrom = XFROM;   /* manaic */ 
        /* Thor.981221: �`��: ���� CS-cancel ��local�峹 */

	/* The cancel msg will cancel back bbs article */
	if (!strstr(PATH, "cs-cancel"))
	{
          /* Thor.981221: xfrom �٨S�]�X��:P */
	  /* bbslog("Fake cancel %s, %s/%s, path: %s\n", xfrom, file, token, PATH); */
	  bbslog("Fake cancel %s/%s, sender: %s, path: %s\n", file, token, FROM, PATH);
	  return 0;
	}
        /* Thor.981221: xfrom �٨S�]�X��:P */
	/* bbslog("CS-cancel %s, %s/%s, path: %s\n", xfrom, file, token, PATH); */
        

	bbslog("CS-cancel %s, %s/%s, path: %s\n", xfrom, file, token, PATH);

	if (!strncmp(myfrom, xfrom, 80))
	  fd = -1;
      }

      if (fd >= 0)
      {
	bbslog("Invalid cancel %s, sender: %s, path: %s\n", xfrom, FROM, PATH);
	return 0;
      }

      /* SoC - */

#else

    if (fp = fopen(filename, "r"))
    {
      register char *xfrom;

      while (fgets(buffer, sizeof buffer, fp))
      {
	//if (strncmp(buffer, "�o�H�H: ", 8) == 0)
	if (strncmp(buffer, FromTxt, 8) == 0)
	{
	  if (xfrom = strchr(boardhome, ' '))
	    *xfrom = '\0';
	  xfrom = boardhome;
	  break;
	}
	if (buffer[0] == '\n')
	  break;
	if (xfrom = strchr(buffer, '\n'))
	  *xfrom = '\0';
      }
      fclose(fp);
#endif

#ifdef	KEEP_NETWORK_CANCEL
      *firstpath = '\0';
      bbslog("cancel post %s\n", filename);
      boardhome = (char *) fileglue("%s/brd/deleted", BBSHOME);
      testandmkdir(boardhome);
      if (isdir(boardhome))
      {
	char subject[1024];
	char *fname;

	if (POSTHOST)
	{
	  sprintf(subject, "cancel by: %.1000s", POSTHOST);
	}
	else
	{
	  char *body, *body2;

	  body = strchr(BODY, '\r');
	  if (body != NULL)
	    *body = '\0';
	  body2 = strchr(BODY, '\n');
	  if (body2 != NULL)
	    *body = '\0';
	  sprintf(subject, "%.1000s", BODY);
	  if (body != NULL)
	    *body = '\r';
	  if (body2 != NULL)
	    *body = '\n';
	}
	if (*subject)
	  SUBJECT = subject;
	fname = (char *) post_article(boardhome, FROM, "deleted", bbspost_write_cancel, filename, firstpath);
	if (fname != NULL)
	{
	  if (firstpath[0] == '\0')
	  {
	    sprintf(firstpath, "%s/boards/deleted/%s", BBSHOME, fname);
	    firstpathbase = firstpath + strlen(BBSHOME) + strlen("/boards/");
	  }
	  if (storeDB(HEADER[MID_H], (char *) fileglue("deleted/%s", fname)) < 0)
	  {
	    /* should do something */
	    bbslog("store DB fail\n");
	    /* return -1; */
	  }
	  bbsfeedslog(fileglue("deleted/%s", fname), 'D');

#ifdef OLDDISPATCH
	  {
	    char board[256];
	    newsfeeds_t *nf;
	    char *filebase = filename + strlen(BBSHOME) + strlen("/boards/");
	    char *filetail = strrchr(filename, '/');

	    if (filetail != NULL)
	    {
	      strncpy(board, filebase, filetail - filebase);
	      nf = (newsfeeds_t *) search_board(board);
	      if (nf != NULL && nf->board && nf->path)
	      {
		feedfplog(nf, firstpathbase, 'D');
	      }
	    }
	  }
#endif
	}
	else
	{
	  bbslog(" fname is null %s %s\n", boardhome, filename);
	  return -1;
	}
      }
#else
      /* bbslog("**** %s should be removed\n", filename); */

      unlink(filename);
      /* Thor.981014: unlink ���O�i�H���Υ[��, �]�� cancel_article
                      �|�Х� POST_CANCEL, �� expire �|unlink 
                      �Y�n�O�dmark�峹���Q��, �h������commented */
#endif

      cancel_article(file, chrono32(token));

    }
  }

#ifndef	MapleBBS
  if (*firstpath)
  {
    char **splitptr, *ngptr;
    newsfeeds_t *nf;

    splitptr = (char **) BNGsplit(GROUPS);
    for (ngptr = *splitptr; ngptr != NULL; ngptr = *(++splitptr))
    {
      if (*ngptr == '\0')
	continue;
      nf = (newsfeeds_t *) search_group(ngptr);
      if (nf == NULL)
	continue;
      if (nf->board == NULL)
	continue;
      if (nf->path == NULL)
	continue;
      feedfplog(nf, firstpathbase, 'D');
    }
  }
#endif

  return 0;
}


static inline int
is_loopback(path, token, len)
  char *path, *token;
  int len;
{
  int cc;

  for (;;)
  {
    cc = path[len];
    if ((!cc || cc == '!') && !memcmp(path, token, len))
      return 1;

    for (;;)
    {
      cc = *path;
      if (!cc)
	return 0;
      path++;
      if (cc == '!')
	break;
    }
  }
}


int
my_recv(client)
  ClientType *client;
{
  char *data;
  FILE *out;
  int rel;

  out = client->Argv.out;
  rel = 0;

  readlines(client);

#if 0
  if (HEADER[SUBJECT_H] && HEADER[FROM_H] && HEADER[DATE_H] &&
    HEADER[MID_H] && HEADER[NEWSGROUPS_H])
#endif
  /* Thor.980825: 
        gc patch: ��]
          a.null path (���פ��e�O�����]) ��P�_ is_lookback �ɷ|����.
          b.�᭱�٦��@�q�O�B�z null path ��(1596), �p�������X�z. */
  if (HEADER[SUBJECT_H] && HEADER[FROM_H] && HEADER[DATE_H] &&
    HEADER[MID_H] && HEADER[NEWSGROUPS_H] && HEADER[PATH_H])
  {
    if (data = HEADER[CONTROL_H])
    {
      /* chuan: the information seems useless */
      /* bbslog("Control: %s\n", HEADER[CONTROL_H]); */

      if (strncasecmp(data, "cancel ", 7) == 0)
      {
	rel = cancel_article_front(data + 7);
      }

#ifndef	MapleBBS
      else
      {
	rel = receive_control();
      }
#endif
    }

#ifndef	MapleBBS
    else if (FROM == NULL)	/* it should have */
    {
      bbslog(":Err: article without usrid %s\n", MSGID);
    }
#endif

    else
    {
#define	BBS_TOKEN	"Rouge"	/* opus : custom */

      data = HEADER[PATH_H];
      /* if (is_loopback(data, BBS_TOKEN, sizeof(BBS_TOKEN) - 1)) */
      /* Thor.990318: �����H MYBBSID ���N, �һݭק����� */
      if (is_loopback(data, MYBBSID, strlen(MYBBSID)) && HEADER[PATH_H])
                                              /* lkchu:981201: patch by gc */
      {
	bbslog(":Warn: Loop back article: %s\n", data);
      }
      else
      {

#if 1
	/* opus : anti-spam */
	int cc;

	data = GROUPS;
	for (;;)
	{
	  cc = *data++;
	  if (cc == 0)
	  {
	    rel = receive_article();
	    break;
	  }
	  if (cc == ',')
	  {
	    if (++rel > 10)	/* �W�L 10 �� news groups */
	    {
	      rel = 0;
	      break;
	    }
	  }
	}

#else

	rel = receive_article();
#endif

      }
    }

    if (rel == -1)
    {
      fprintf(out, "400 server side failed\r\n");
      fflush(out);
      fclose(out);
      verboselog("Ihave Put: 400\n");
      clearfdset(client->fd);
      fclose(client->Argv.in);
      close(client->fd);
      client->fd = -1;
      client->mode = 0;
      client->ihavefail++;
      return -1;
    }
    else
    {
      fprintf(out, "235\r\n");
      /* verboselog("Ihave Put: 235\n"); */
    }
    /* fflush(out); */
  }
  else if (!HEADER[PATH_H])
  {
   /* Thor.981224: lkchu patch: 
         ����p�b Solaris ���o��, �ר�O���W�C news server �D�ʳޫH��, innbbsd
          ���������p��`�o��.

          �b HEADER[PATH_H] �� null path ��, �u�n�h access HEADER[MID_H] ����,
          innbbsd �N���F :(   */

#if 0
    fprintf(out, "437 No Path in \"ihave %s\" header\r\n", HEADER[MID_H]);
    /* fflush(out); */
    verboselog("Put: 437 No Path in \"ihave %s\" header\n", HEADER[MID_H]);
#endif

   fputs("437\r\n",out);  /* maniac: ���߲� print status code ����, �����Է��᲻֪�������
������Ѷ�����пɡ�, ����������... */
    client->ihavefail++;
  }
  else
  {
#if 0
    fprintf(out, "437 No colon-space in \"ihave %s\" header\r\n", HEADER[MID_H]);
    /* fflush(out); */
    verboselog("Ihave Put: 437 No colon-space in \"ihave %s\" header\n", HEADER[MID_H]);
#endif
    fputs("437\r\n",out);
    client->ihavefail++;
  }

  fflush(out);

  return 0;
}
