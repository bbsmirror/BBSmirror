#ifndef INNBBSD_H
#define INNBBSD_H
#include "daemon.h"

#define	HAVE_FILTER_SUPPORT
				/* hightman: �����X */
#ifndef ADMINUSER
# define ADMINUSER "hightman@263.net"
#endif

#endif
