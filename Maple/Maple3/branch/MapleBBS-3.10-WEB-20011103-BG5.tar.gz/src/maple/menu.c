/*-------------------------------------------------------*/
/* menu.c	( NTHU CS MapleBBS Ver 3.00 )		 */
/*-------------------------------------------------------*/
/* target : menu/help/movie routines		 	 */
/* create : 95/03/29				 	 */
/* update : 97/03/29				 	 */
/*-------------------------------------------------------*/


#include "bbs.h"


extern UCACHE *ushm;
extern BCACHE *bshm;		/* �s���i */

static int
top ()
{
  system ("/usr/bin/top > etc/top");
  more ("etc/top", 0);
  return 0;
}

static int
welcome ()
{
  film_out (FILM_WELCOME, -1);

  return 0;
}

/* ----------------------------------------------------- */
/* ���} BBS ��						 */
/* ----------------------------------------------------- */


#define	FN_NOTE_PAD	"run/note.pad"
#define	FN_NOTE_TMP	"run/note.tmp"
#define	NOTE_MAX	100
#define	NOTE_DUE	48


typedef struct
{
  time_t tpad;
  char msg[356];
}
Pad;


int
pad_view ()
{
  int fd, count;
  Pad *pad;

  if ((fd = open (FN_NOTE_PAD, O_RDONLY)) < 0)
    return XEASY;

  clear ();
  move (0, 23);
  outs ("\033[1;32m�i �� �� �W �� �d �� �O �j\033[m\n\n");
  count = 0;

  mgets (-1);

  for (;;)
    {
      pad = mread (fd, sizeof (Pad));
      if (!pad)
	{
	  vmsg (NULL);
	  break;
	}

      outs (pad->msg);
      if (++count == 5)
	{
	  move (b_lines, 0);
	  outs ("�Ы� [SPACE] �~���[��A�Ϋ���L�䵲���G");
	  if (vkey () != ' ')
	    break;

	  count = 0;
	  move (2, 0);
	  clrtobot ();
	}
    }

  close (fd);
  return 0;
}


static void
pad_draw ()
{
  int i, cc, len, fdr;
  FILE *fpw;
  Pad pad;
  char *str, str2[300], buf[3][80];

  do
    {
      buf[0][0] = buf[1][0] = buf[2][0] = '\0';
      move (12, 0);
      clrtobot ();
      outs ("\n�Яd�� (�ܦh�T��)�A��[Enter]����");
      for (i = 0; (i < 3) && vget (16 + i, 0, "�G", buf[i], 78, DOECHO); i++);
      cc = vans ("(S)�s���[�� (E)���s�ӹL (Q)��F�H[S] ");
      if (cc == 'q' || i == 0)
	return;
    }
  while (cc == 'e');

  time (&(pad.tpad));

  str = pad.msg;

  sprintf (str, "\033[1;37;46m�W\033[34;47m %s \033[33m(%s)", cuser.userid,
	   cuser.username);
  len = strlen (str);
  strcat (str, " \033[30;46m" + (len & 1));

  for (i = len >> 1; i < 41; i++)
    strcat (str, "��");
  sprintf (str2,
	   "\033[34;47m %.14s \033[37;46m�W\033[m\n%-70.70s\n%-70.70s\n%-70.70s\n",
	   Etime (&(pad.tpad)), buf[0], buf[1], buf[2]);
  strcat (str, str2);

  f_cat (FN_NOTE_ALL, str);

  if (!(fpw = fopen (FN_NOTE_TMP, "w")))
    return;

  fwrite (&pad, sizeof (pad), 1, fpw);

  if ((fdr = open (FN_NOTE_PAD, O_RDONLY)) >= 0)
    {
      Pad *pp;

      i = 0;
      cc = pad.tpad - NOTE_DUE * 60 * 60;
      mgets (-1);
      while (pp = mread (fdr, sizeof (Pad)))
	{
	  fwrite (pp, sizeof (Pad), 1, fpw);
	  if ((++i > NOTE_MAX) || (pp->tpad < cc))
	    break;
	}
      close (fdr);
    }

  fclose (fpw);

  rename (FN_NOTE_TMP, FN_NOTE_PAD);
  pad_view ();
}


static int
goodbye ()
{
  switch (vans ("G)�A�O" NICKNAME " M)���i���� N)�d���O Q)�����H[G] "))
    {
    case 'g':
    case 'y':
      break;

    case 'm':
      mail_sysop ();
      break;

    case 'n':
      /* if (cuser.userlevel) */
      if (HAS_PERM (PERM_POST))	/* Thor.990118: �n��post�~��d��, �������e */
	pad_draw ();
      break;

    case 'q':
      return XEASY;
    default:
      break;
    }

#ifdef  LOG_BMW
  bmw_save ();			/* lkchu.981201: ���T�O���B�z */
#endif

  clear ();

#if 0
				/* hightman.011028: �Ȫn�K */
  prints("�˷R�� \033[32m%s(%s)\033[m�A�O�ѤF�A�ץ��{�i %s �j\n"
    "�H�U�O�z�b���������U���:\n",
    cuser.userid, cuser.username, str_site);
  acct_show(&cuser, 0);
  vmsg(NULL);
#endif

  more ("etc/goodbye", NULL);
  u_exit ("EXIT ");
  exit (0);
}


/* ----------------------------------------------------- */
/* help & menu processring				 */
/* ----------------------------------------------------- */


void
vs_head (title, mid)
     char *title, *mid;
{
  char buf[40], ttl[60];
  int spc;
  usint ufo;
#ifdef  COLOR_HEADER
  int color = (time (0) % 7) + 41;	/* lkchu.981201: random color */
#endif

  if (mid == NULL)
    {
      move (0, 0);
      clrtoeol ();
      mid = str_site;
    }
  else
    {
      clear ();
    }

  spc = strlen (mid);
  ufo = cutmp->ufo;

  if (!*title)
    {
      title++;

      if (ufo & UFO_BIFF)
	cutmp->ufo = ufo ^ UFO_BIFF;	/* �ݹL�N�� */
    }
  else
    {
      if (ufo & UFO_BIFF)
	{
	  mid = "\033[41;37;5m �Ť����ӤF�e�H�F \033[0;1;33;44m";
	  spc = 15;
	}
      else if (spc > 46)
	{
	  spc = 44;
	  memcpy (ttl, mid, spc);
	  mid = ttl;
	  mid[spc] = '\0';
	}
    }

  spc = 67 - strlen (title) - spc - strlen (currboard);

  if (spc < 0)
    spc = 0;

  ufo = 1 - spc & 1;
  memset (buf, ' ', spc >>= 1);
  buf[spc] = '\0';

#ifdef	COLOR_HEADER
  prints
    ("\033[1;%2d;37m�i%s�j%s\033[33m%s\033[1;%2d;37m%s\033[37m�ݪO��%s��\033[m\n",
     color, title, buf, mid, color, buf + ufo, currboard);
#else
  prints ("\033[1;44;37m�i%s�j%s\033[33m%s%s\033[37m�ݪO��%s��\033[m\n",
	  title, buf, mid, buf + ufo, currboard);
#endif
}


/* ------------------------------------- */
/* �ʵe�B�z				 */
/* ------------------------------------- */


static char footer[160];

void
update_foot ()			/* ��s���A�� */
{
  static int orig_flag = -1;
  static time_t uptime = -1;
  static char flagmsg[16];
  static char datemsg[16];

  int ufo;
  time_t now;

  ufo = cuser.ufo;

  /* Thor: �P�� ��� �I�s�� �n�ͤW�� ���� */
  ufo &= UFO_PAGER | UFO_ALOHA | UFO_CLOAK | UFO_QUIET;
  if (orig_flag != ufo)
    {
      orig_flag = ufo;
      sprintf (flagmsg,
	       "%s %s%s%s",
	       (ufo & UFO_PAGER) ? "��" : "�}",
	       (ufo & UFO_ALOHA) ? "�� " : "",
	       (ufo & UFO_QUIET) ? "�R " : "",
	       (ufo & UFO_CLOAK) ? "�� " : "");
    }
  time (&now);
  if (now > uptime)
    {
      struct tm *ptime;

      ptime = localtime(&now);

      sprintf (datemsg, "[%d/%d �P��%.2s ",
	       ptime->tm_mon + 1, ptime->tm_mday,
	       "�Ѥ@�G�T�|����" + (ptime->tm_wday << 1));

      uptime = now + 86400 - ptime->tm_hour * 3600 -
	ptime->tm_min * 60 - ptime->tm_sec;
    }
  ufo = (now - (uptime - 86400)) / 60;
  /* Thor.980913: ����: �̱`���I�s movie()���ɾ��O�C����s film, �b 60���H�W,
     �G���ݰw�� xx:yy �ӯS�O�@�@�r���x�s�H�[�t */

  sprintf (footer,
	   "\033[0;34;46m%s%d:%02d] \033[30;47m  �W�u�H��: [\033[31m%d\033[30m] �Τ�: \033[31m%-8s\033[30m  �I�s���A: \033[31m%s\033[30m              \033[m",
	   datemsg, ufo / 60, ufo % 60, ushm->count, cuser.userid, flagmsg);
  outz (footer);
}

void
movie ()
{
  int ufo;
  time_t now;

  ufo = cuser.ufo;
  time (&now);

  /* Thor: it is depend on which state */

  if ((bbsmode < M_CLASS) && (ufo & UFO_MOVIE))
    {
      static int tag = FILM_MOVIE;

      tag = film_out (tag, 2);
    }

  update_foot ();

}

static int
x_sysload ()
{
  float load[2];
  char buf[80];

  getloadavg (load, 3);
  sprintf (buf, "�t�έt�� %.2f %.2f %.2f", load[0], load[1], load[2]);
  vmsg (buf);
  return XEASY;
}


typedef struct
{
  void *func;
  /* int (*func) (); */
  usint level;
  int umode;
  char *desc;
}
MENU;


#define	MENU_XPOS	18
#define	MENU_YPOS	14
#define	MENU_LOAD	1
#define	MENU_DRAW	2
#define	MENU_FILM	4

#define	PERM_MENU	PERM_PURGE


static MENU menu_main[];
static MENU menu_game[];
static MENU menu_tool[];
static MENU menu_talk[];


/* ----------------------------------------------------- */
/* administrator's maintain menu			 */
/* ----------------------------------------------------- */


static MENU menu_admin[] = {
  m_user, PERM_ACCOUNTS, M_SYSTEM,
  "User       �ϥΪ̸��",

  m_newbrd, PERM_SYSOP, M_SYSTEM,
  "Board      �}�@�s�ݪO",

  x_sysload, PERM_SYSOP, M_SYSTEM,
  "Load       �t�έt��",

#ifdef HAVE_REGISTER_FORM
  m_register, PERM_ACCOUNTS, M_SYSTEM,
  "Register   �f�ֵ��U����",
#endif

  top, PERM_SYSOP, M_XFILES,
  "Top        �u�W LOAD",

  m_xfile, PERM_ADMIN4, M_XFILES,
  "Xfile      �s��t���ɮ�",

#ifdef	HAVE_ADM_SHELL
  x_csh, PERM_SYSOP, M_SYSTEM,
  "Shell      ����t�� Shell",
#endif

#ifdef	HAVE_REPORT
  m_trace, PERM_SYSOP, M_SYSTEM,
  "Trace      �]�w�O�_�O��������T",
#endif

  menu_main, PERM_MENU + 'U', M_ADMIN,
  "�t�κ��@"
};


#ifdef HAVE_AUTO_ORDERSONG
/* ----------------------------------------------------- */
/* order song's menu					 */
/* ----------------------------------------------------- */

static MENU menu_song[] = {
  "bin/song.so:XoSongMain", PERM_VALID, -M_SONG,
  "Request       ���a�I�q��",

  "bin/song.so:XoSongLog", 0, -M_XMODE,
  "OrderSongs    �I�q����",

  "bin/song.so:XoSongSub", PERM_VALID, -M_XMODE,
  "Submit        ��Z�M��",

  menu_game, PERM_MENU + 'O', M_GMENU,
  "�����I�q"
};

#endif

/* ----------------------------------------------------- */
/* mail menu						 */
/* ----------------------------------------------------- */

static int
XoMbox ()
{
  xover (XZ_MBOX);
  return 0;
}

#ifdef HAVE_SIGNED_MAIL
int m_verify ();
#endif

static MENU menu_mail[] = {
  XoMbox, PERM_READMAIL, M_RMAIL,
  "Read       �\\Ū�H��",

  m_send, PERM_BASIC, M_SMAIL,
  "Send       �����H�H",

#ifdef MULTI_MAIL		/* Thor.981009: ����R�����B�H */
  mail_list, PERM_BASIC, M_SMAIL,
  "List       �s�ձH�H",
#endif

  m_internet, PERM_INTERNET, M_SMAIL,
  "Internet   �H�H�� Internet",

#ifdef HAVE_SIGNED_MAIL
  m_verify, 0, M_XMODE,
  "Verify     ����H��q�lñ��",
#endif

  mail_sysop, PERM_BASIC, M_SMAIL,
  "Yes Sir!   �H�H������",

#ifdef HAVE_BROAD_MAIL
  "bin/mailall.so:mail_to_bm", PERM_SYSOP, -M_XMODE,
  "ToBM       �O�D�q�i",

  "bin/mailall.so:mail_to_all", PERM_SYSOP, -M_XMODE,
  "Alluser    �t�γq�i",
#endif  

#ifndef HAVE_SIGNED_MAIL
  menu_main, PERM_MENU + 'R', M_MAIL,
  "�q�l�l��"
#else
  menu_main, PERM_MENU + Ctrl ('B'), M_MAIL,	/* Thor.990413: ��guest�S�ﶵ */
  "�q�l�l��"
#endif    
};


/* ----------------------------------------------------- */
/* Talk menu						 */
/* ----------------------------------------------------- */


static int
XoUlist ()
{
  xover (XZ_ULIST);
  return 0;
}

/* ----------------------------------------------------- */
/* game menu                                             */
/* ----------------------------------------------------- */

static MENU menu_bet[] = {
  "bin/guessnum.so:guessNum", 0, -M_XMODE,
  "GuessNum   �̥ʲq�Ʀr",

  "bin/guessnum.so:fightNum", 0, -M_XMODE,
  "FightNum   �q�Ʀr�j��",

#ifdef HAVE_MONEY_ISM	/* �����C�� */

  "bin/game.so:BlackJack", PERM_VALID, -M_XMODE,
  "BlackJack  21�I�³ǧJ",

  "bin/game.so:gagb", PERM_VALID, -M_XMODE,
  "2Gagb      �XA�XB�C��",

  "bin/game.so:x_dice", PERM_VALID, -M_XMODE,
  "Xdice      ��������",

  "bin/game.so:p_gp", PERM_VALID, -M_XMODE,
  "Pgp        �����J����",

  "bin/game.so:p_nine", PERM_VALID, -M_XMODE,
  "Nine       �Ѧa�E�E",

  "bin/game.so:bingo", PERM_VALID, -M_XMODE,
  "3Bingo     ���G���G",
#endif  

  menu_tool, PERM_MENU + 'G', M_GMENU,
  "�@�ͦn��"
};


/* Thor.990224: �}��~���ɭ� */
static MENU menu_tool[] = {
	
  menu_bet, 0, M_GMENU,
  "Betting    [1;33m�@��n�A���~[m",

#ifdef HAVE_MONEY_ISM
  "bin/bank.so:x_found", PERM_VALID, -M_BANK,
  "Foundation ���������|",

  "bin/lovepaper.so:lovepaper", PERM_VALID, -M_LOVE,
  "LovePager  \033[1;35m���Ѳ��;�\033[m",

#ifdef HAVE_CHICKEN
  "bin/pip.so:p_pipple", PERM_VALID, -M_CHICKEN,
  "YangJi     \033[1;33m���a�i����\033[m",
#endif  

#endif

#ifdef HAVE_TTY_GAME
  "bin/tetr.so:tetris", PERM_VALID, -M_TETRIS,
  "Tetris     \033[1;35m�Xù�����\033[m",
  
  "bin/pushbox.so:pushbox", PERM_VALID, -M_PUSH,
  "2PushBox   ���c�l�C��",  
#endif  

  "bin/puzzle.so:NumPad", PERM_VALID, -M_PUZZLE,
  "Puzzle     �]����ϹC��",

#ifdef HAVE_MONEY_ISM
#if 0
/* hightman.001106: �Ȯ��������s������ :Q */
  "bin/steal.so:p_steal", PERM_DEFAULT, -M_STEAL,
  "1Steal     \033[1;35m���s������\033[m",
#endif
#endif

  "bin/mine.so:Mine", PERM_VALID, -M_WINMINE,
  "Mine       \033[1;32m�l�ɽ�a�p\033[m",

#ifdef HAVE_SEC_HAND
  "bin/sec_hand.so:sec_hand", PERM_VALID, -M_2NDHAND,
  "SecHand    �G����D����",
#endif  

  menu_game, PERM_MENU + 'B', M_GMENU,
  "�C���j�U"
};

static MENU menu_game[] = {
		
#ifdef HAVE_AUTO_ORDERSONG	
  menu_song, 0, M_TMENU,
  "Song        \033[1;32m�����I�q�x\033[m",
#endif  

  menu_tool, 0, M_TMENU,
  "Game        \033[1;33mBBS�C���Ѧa\033[m",

#ifdef HAVE_BBSNET
  "bin/bbsnet.so:x_bbsnet", PERM_VALID, -M_BBSNET,
  "Bbsnet      �Ȫe���",
#endif  

  menu_talk, PERM_MENU + 'G', M_GMENU,
  "���뤭����"
};

/* ---------------------------------------------- */
/* Talk Menu                                      */
/* ---------------------------------------------- */

static MENU menu_talk[] = {
  XoUlist, 0, M_LUSERS,
  "Users      ���U�|��",

  /* Thor.990220: ��ĥ~�� */
  "bin/chat.so:t_chat", PERM_CHAT, -M_CHAT,
  "Chat       ��Ѽs��",

  t_query, 0, M_QUERY,
  "Query      ����t�X",

  t_pal, PERM_BASIC, M_PAL,
  "Friend     �s��n�ͦW��",

  t_pager, PERM_BASIC, M_XMODE,
  "Pager      �����I�s��",

  t_message, PERM_BASIC, M_XMODE,
  "Message    �����T����",

  t_recall, PERM_BASIC, M_XMODE,
  "Write      �^�U�T���O��",

#ifdef LOGIN_NOTIFY
  t_loginNotify, PERM_PAGE, M_XMODE,
  "Notify     �]�w�t�κ��ͨ�M",
#endif

  menu_game, 0, M_GMENU,
  "Xyz        \033[1;33m���뤭����\033[m",

#if 0
  t_talk, PERM_PAGE, M_PAGE,
  "Talk       ��H���",
#endif

  menu_main, PERM_MENU + 'U', M_TMENU,
  "�T�ֲ��"
};


/* ----------------------------------------------------- */
/* User menu						 */
/* ----------------------------------------------------- */

static MENU menu_user[] = {

#ifdef  HAVE_REGISTER_FORM
  u_register, PERM_BASIC, M_UFILES,
  "Register   ��g�m���U�ӽг�n",
#endif

  u_info, PERM_BASIC, M_XMODE,
  "Info       �]�w�ӤH��ƻP�K�X",

  u_addr, PERM_BASIC, M_XMODE,
  "Address    �]�w E-mail Address",

  u_lock, PERM_BASIC, M_XMODE,
  "Lock       ��w�ù�",

  u_xfile, PERM_BASIC, M_UFILES,
  "Xfile      �s��ӤH�ɮ�",

  u_setup, 0, M_UFILES,
  "Setup      �]�w�ާ@�Ҧ�",

  pad_view, 0, M_READA,
  "Note       �[�ݤ߱��d���O",

  welcome, 0, M_READA,
  "Welcome    �[���w��e��",

#ifdef HAVE_KILL_SELF
  "bin/kill.so:u_kill", PERM_DEFAULT, -M_KILL,
  "KillSelf   �۱� [�Ϥ��^��!!]",
#endif  

  menu_main, PERM_MENU + 'S', M_UMENU,
  "�ӤH�]�w"
};



/* ----------------------------------------------------- */
/* main menu						 */
/* ----------------------------------------------------- */


static int
Gem ()
{
  XoGem ("gem/.DIR", "", (HAS_PERM (PERM_SYSOP) ? GEM_SYSOP : GEM_USER));
  return 0;
}


static MENU menu_main[] = {
  menu_admin, PERM_ADMIN, M_ADMIN,
  "0Admin    �i �t�κ��@�� �j",

  Gem, 0, M_GEM,
  "Announce  �i ��ؤ����� �j",

  Boards, 0, M_BOARD,
  "Boards    �i �����Q�װ� �j",

  Class, 0, M_CLASS,
  "Class     �i �����Q�װ� �j",

#ifdef HAVE_GROUP_FUNC
  "bin/group.so:XoGroupMain", PERM_BASIC, -M_GROUP,
  "DGroup    �i \033[1;33m�s�ե\���\033[m �j",
#endif  

#ifdef HAVE_SIGNED_MAIL
  menu_mail, 0, M_MAIL,		/* Thor.990413: �Y����m_verify, guest�N�S����椺�eù */
  "Mail      �i �H��u��� �j",
#else
  menu_mail, PERM_BASIC, M_MAIL,
  "Mail      �i �p�H�H��� �j",
#endif
  menu_talk, 0, M_TMENU,
  "TalkPlay  �i �𶢲�Ѱ� �j",

  menu_user, 0, M_UMENU,
  "User      �i �ӤH�u��� �j",

#if 0
  menu_xyz, 0, M_UMENU,
  "Xyz       �i �t�θ�T�� �j",
/* lkchu.990428: ���n����b�ӤH�u��� */
/* hightman.011028: ��U�F�C... :-p */
#endif  

#ifndef HAVE_GROUP_FUNC
  Select, 0, M_BOARD,
  "Select     �ֳt��ܬݪO",
#endif  

#if 0
  welcome, 0, M_READA,
  "Welcome    �[���w��e��",
#endif
  goodbye, 0, M_XMODE,
  "Goodbye    ���n����ڭn���F���",

  NULL, PERM_MENU + 'C', M_MMENU,
  "�D�ؿ�"
};


void
menu ()
{
  MENU *menu, *mptr, *table[12];
  usint level, mode;
  int cc, cx;			/* current / previous cursor position */
  int max, mmx;			/* current / previous menu max */
  int cmd, depth;
  char *str;

  mode = MENU_LOAD | MENU_DRAW | MENU_FILM;
  menu = menu_main;
  level = cuser.userlevel;
  depth = mmx = 0;

  for (;;)
    {
      if (mode & MENU_LOAD)
	{
	  for (max = -1;; menu++)
	    {
	      cc = menu->level;
	      if (cc & PERM_MENU)
		{

#ifdef	MENU_VERBOSE
		  if (max < 0)	/* �䤣��A�X�v�����\��A�^�W�@�h�\��� */
		    {
		      menu = (MENU *) menu->func;
		      continue;
		    }
#endif

		  break;
		}
	      if (cc && !(cc & level))
		continue;

	      table[++max] = menu;
	    }

	  if (mmx < max)
	    mmx = max;

	  if ((depth == 0) && (cutmp->ufo & UFO_BIFF))
	    cmd = 'M';
	  else
	    cmd = cc ^ PERM_MENU;	/* default command */
	  utmp_mode (menu->umode);
	}

      if (mode & MENU_DRAW)
	{
	  if (mode & MENU_FILM)
	    {
	      clear ();
	      movie ();
	      cx = -1;
	    }
	  vs_head (menu->desc, NULL);
	  mode = 0;
	  do
	    {
	      move (MENU_YPOS + mode, MENU_XPOS + 2);
	      if (mode <= max)
		{
		  mptr = table[mode];
		  str = mptr->desc;
		  outs ("(\033[1;36m");
		  outc (*str++);
		  outs ("\033[m)");
		  outs (str);
		}
	      clrtoeol ();

	    }
	  while (++mode <= mmx);

	  mmx = max;
	  mode = 0;
	}

      switch (cmd)
	{
	case KEY_DOWN:
	  if (++cc <= max)
	    break;

	case Ctrl ('B'):	/* Thor.990413: �A�@�U�� */
	case KEY_HOME:
	  cc = 0;
	  break;

	case KEY_UP:
	  if (--cc >= 0)
	    break;

	case KEY_END:
	  cc = max;
	  break;

	case '\n':
	case KEY_RIGHT:
	  mptr = table[cc];
	  cmd = mptr->umode;
#if 1
	  /* Thor.990212: dynamic load , with negative umode */
	  if (cmd < 0)
	    {
	      void *p = DL_get (mptr->func);
	      if (!p)
		break;
	      mptr->func = p;
	      cmd = -cmd;
	      mptr->umode = cmd;
	    }
#endif
	  utmp_mode (cmd /* = mptr->umode */ );

	  if (cmd <= M_XMENU)
	    {
	      menu->level = PERM_MENU + mptr->desc[0];
	      menu = (MENU *) mptr->func;
	      mode = MENU_LOAD | MENU_DRAW;
	      depth++;
	      continue;
	    }

	  {
	    int (*func) ();

	    func = mptr->func;
	    mode = (*func) ();
	  }

	  utmp_mode (menu->umode);

	  if (mode == XEASY)
	    {
#if 1
	      /* Thor.980826: �� outz �N���� move + clrtoeol�F */
	      outz (footer);
#endif

	      mode = 0;
	    }
	  else
	    {
	      mode = MENU_DRAW | MENU_FILM;
	    }

	  cmd = mptr->desc[0];
	  continue;

#ifdef EVERY_Z
	case Ctrl ('Z'):
	  every_Z ();		/* Thor: ctrl-Z everywhere */
	  goto menu_key;
#endif

	case KEY_LEFT:
	case 'e':
	  if (depth > 0)
	    {
	      menu->level = PERM_MENU + table[cc]->desc[0];
	      menu = (MENU *) menu->func;
	      mode = MENU_LOAD | MENU_DRAW | MENU_FILM;
	      depth--;
	      continue;
	    }

	  cmd = 'G';

	default:

	  if (cmd >= 'a' && cmd <= 'z')
	    cmd -= 0x20;

	  cc = 0;
	  for (;;)
	    {
	      if (table[cc]->desc[0] == cmd)
		break;
	      if (++cc > max)
		{
		  cc = cx;
		  goto menu_key;
		}
	    }
	}

      if (cc != cx)
	{
	  if (cx >= 0)
	    {
	      move (MENU_YPOS + cx, MENU_XPOS);
	      outc (' ');
	    }
	  move (MENU_YPOS + cc, MENU_XPOS);
	  outc ('>');
	  cx = cc;
	}
      else
	{
	  move (MENU_YPOS + cc, MENU_XPOS + 1);
	}

    menu_key:

      cmd = vkey ();
    }

}
