/*-------------------------------------------------------*/
/* so/bbsnet.c         (MapleBBS Ver 3.00 )           	 */
/*-------------------------------------------------------*/
/* author : hightman.bbs@bbs.dot66.net		         */
/* target : ���Wbbsnet��		 	         */
/* create : 2000/10/06                                   */
/* NOTICE : ���ե��xLinux (Redhat 6.x, 7.x)		 */
/*	    �ĥΦۤw�w�q��telnet��ĳ			 */
/*-------------------------------------------------------*/

#include "bbs.h"
#include <termio.h>

#ifdef HAVE_BBSNET

unsigned char buf[2048];
struct timeval tv;
fd_set readfds;
int result, readnum;
int cfd;  /* �����w�q... */

static void break_check() {
	int i;
        tv.tv_sec = 0;
	tv.tv_usec = 0;
	FD_ZERO(&readfds) ;
	FD_SET(0, &readfds);
	result = select(1, &readfds, NULL, NULL, &tv);
	if (FD_ISSET(0, &readfds)) {
		readnum = read(0, buf, 80);
		for(i=0; i<readnum; i++) 
			if(buf[i]==3 || buf[i]==4) {
				close(cfd);
			}
	}
	alarm(1);
}

int telnet(char *server, int port) {
	int tmplen;
	struct sockaddr_in blah;
	struct hostent *he;
	tmplen=0;
        signal(SIGALRM, break_check);
        alarm(1);
	bzero((char *)&blah, sizeof(blah));
	blah.sin_family=AF_INET;
	blah.sin_addr.s_addr=inet_addr(server);
	blah.sin_port=htons(port);
	printf("Trying %s... \r\n", server); 
	fflush(stdout);
	cfd=socket(AF_INET, SOCK_STREAM, IPPROTO_TCP); 
	if((he=gethostbyname(server))!=NULL)
		bcopy(he->h_addr, (char *)&blah.sin_addr, he->h_length);
	else
		if((blah.sin_addr.s_addr=inet_addr(server))<0) return;
	if(connect(cfd, (struct sockaddr *)&blah, 16) < 0) return; 
	signal(SIGALRM, SIG_IGN);
        fflush(stdout);
	printf("Connected to %s.\r\n", server);
	printf("Escape character is '^['\r\n"); 
	fflush(stdout);
	while(1) {
		tv.tv_sec = 2400;
		tv.tv_usec = 0;
		FD_ZERO(&readfds) ;
		FD_SET(cfd, &readfds);
		FD_SET(0, &readfds);
		result=select(cfd+1, &readfds, NULL, NULL, &tv);
		if(result<=0) break;
                if(FD_ISSET(0, &readfds)) {
			readnum=read(0, buf, 2048);
			if(readnum<=0) break;
			if(buf[0]==29) return;
			if(buf[0]==13 && readnum==1) {
				buf[1]=10;
				readnum++;
			}
			write(cfd, buf, readnum);
		} else {
			readnum=read(cfd, buf, 2048);
			if (readnum<=0) break;
			if(strchr(buf, 255)) 
				telnetopt(cfd, buf, readnum);
			else
				write(0, buf, readnum);
		}
	}
}

int telnetopt(int fd, unsigned char *buf, int max) {
	unsigned char c2, c3;
	int i;
	unsigned char tmp[30];
	for(i=0; i<max; i++) {
		if(buf[i]!=255) {
			write(0, &buf[i], 1);
			continue;
		}
		c2=buf[i+1];
		c3=buf[i+2];
		i+=2;
		if(c2==253 && (c3==3 || c3==24)) {
			sprintf(tmp, "%c%c%c", 255, 251, c3);
			write(fd, tmp, 3); 
			continue;
		}
		if((c2==251 || c2==252) && (c3==1 || c3==3 || c3==24)) {
			sprintf(tmp, "%c%c%c", 255, 253, c3); 
			write(fd, tmp, 3);
			continue;
		}
		if(c2==251 || c2==252) {
			sprintf(tmp, "%c%c%c", 255, 254, c3);
			write(fd, tmp, 3);
			continue;
		}
		if(c2==253 || c2==254) {
			sprintf(tmp, "%c%c%c", 255, 252, c3);
			write(fd, tmp, 3);
			continue;
		}
		if(c2==250) {
			while(c3!=240 && i<max) {
				c3=buf[i];
				i++;
			}
			sprintf(tmp, "%c%c%c%c%c%c%c%c%c%c", 255, 250, 24, 0, 65, 78, 83, 73, 255, 240);
			write(fd, tmp, 10);
		}
	}
	fflush(stdout);
}

/* main */

int x_bbsnet()
{
  int i,j;
  char ans[10];
  int fdd;
  int mode;
  /* int bbsnet,login; */

struct CONNLIST
{
  char host[40];
  int port;
  char name[20];
  int mode;
}  connlist[20];

#ifdef HAVE_MONEY_ISM
 if(cuser.money < 100)
  {
   vmsg("�z����������..");
   return;
  }
#endif

  utmp_mode(M_BBSNET);

  vs_bar("�Ȫe���");

  if ((fdd = open("etc/connlist", O_RDONLY)) >= 0)
  {
    char *ptr, *str, *qtr;

    j = 0;
    mgets(-1);
    while (str = mgets(fdd))
    {
	if(*str == '#') continue;	/* �`�� */

	if(*str == '!') { mode = 1; str++; }	/* �q�Lmode�Ӽ��Ѯդ��~ */
	else mode = 0;

        if (ptr = strchr(str, ':'))
        {
          *ptr = '\0';
          do
          {
            i = *++ptr;
          } while (i == ' ' || i == '\t');
          
          if(qtr = strchr(ptr, ':'))
            { *qtr = '\0';
              do
               {
                 i = *++qtr;
                } while (i == ' ' || i == '\t');

          if (i)
          {
            strcpy(connlist[j].host, str);
            connlist[j].port = atoi(ptr);
            strcpy(connlist[j].name,qtr);
	    connlist[j++].mode = mode;
          }
        }
      }
    }
    close(fdd);
  }
   move(2, 0);
   clrtobot();
   prints("\033[1;44;37m     %-20s         %-44s\n%s\033[m\n",
          "���x�W��","���x�W��",msg_seperator);

    i = 0;
    while(i < j - 1)
    {
       prints("%3d. \033[1;37m%-20s    %3d. %-20s\033[m\n",
        i + 1, connlist[i].name, i + 2, connlist[i+1].name);
        i= i + 2;
    }
 
   if(i < j)  /* hightman: �ץ��_�ư��D */
       prints("%3d. \033[1;37m%-20s\n", i+1, connlist[i].name);

    prints("  0. \033[1;36m���}���x���\033[m");

    vget(22, 2, "�п�ܤ@�ӳs�u���x [0]�G", ans, 3, DOECHO);
    i = atoi(ans);
    if (i-1 < 0 || i-1 > j)
    {
      vmsg("����..");
      return;
     }

  if(vans("����@���ᱼ����100,�z�Q�n�F?[Y/n]") == 'n')
   {
    vmsg("�[�ް�,�������...");
    return; 
   }

#ifdef HAVE_MONEY_ISM
  cuser.money -= 100;
  acct_save(&cuser);
#endif  

/* �ܬ��w�R�Ҧ�,����o�������_ */

  if(!(cutmp->ufo & UFO_EXEC))
  {
   cutmp->ufo ^= UFO_EXEC;
  }
   clear();
   move(0,0);
   prints("�s�� \033[1;33;41m%s\033[m �s���W30����۰��_�}�Υ�^C ^D����.\n",connlist[i-1].name);
   refresh();

#if 0
   if(connlist[i-1].mode == 1)
   {
     char buf[128];
     int handdle;

     if((handdle = dup(0)) < 0) { 
       vmsg("�t�άG��, ������!");
       return;
     }

     sprintf(buf, "/bin/bash sbin/runsocks telnet %s %d", connlist[i-1].host, connlist[i-1].port);
     system(buf);
     close(handdle);
   }
   else
#endif
   telnet(connlist[i-1].host,connlist[i-1].port);
   cutmp->ufo ^= UFO_EXEC;
   return;
}
#endif	/* _HAVE_BBSNET */
