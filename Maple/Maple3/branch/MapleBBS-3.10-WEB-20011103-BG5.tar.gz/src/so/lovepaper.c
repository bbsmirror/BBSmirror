#include "bbs.h"

#ifdef HAVE_MONEY_ISM

#define         LOVE_PAPER      FN_ETC_LOVEPAPER
#define		P_BEGIN		"@begin"
#define		L_BEGIN		(3)
#define		P_MID1		"@mid1"
#define		L_MID1		(2)
#define		P_MID2		"@mid2"
#define		L_MID2		(2)
#define		P_MID3		"@mid3"
#define		L_MID3		(2)
#define		P_END		"@end"
#define		L_END		(3)
#define		P_POEM		"@poem"

int 
lovepaper()
{
  FILE *fp,*fd;
  int line,page,mode,rpage,cpage,style;
  char buf[300];
  char *header[] = {P_BEGIN,P_MID1,P_MID2,P_MID3,P_END,P_POEM};
  int  h_line[] = {L_BEGIN,L_MID1,L_MID2,L_MID3,L_END};
  char fpath[128], folder[128];
  HDR	mhdr;
  int	rc;
  char userid[14];
  ACCT	xacct;
  
  if(cuser.money<100) { vmsg("�z�{���٤���100�A������F�A��!");
                           return 0; }

  if(vans("������ʱN��h�{��100,�z�T�w��? [Y/n]") == 'n')
     { 
        vmsg("�n�[�޳�A�����F...");
        return 0;
        }
  utmp_mode(M_LOVE);
  clear(); 
  vs_bar("���ѥͦ���");
 
  if((acct_get("�n�g���֡G",&xacct)<1))
// if (!vget(1, 0, "�g����?(���ť���C�X���W�ϥΪ�)�G", userid, IDLEN + 1, GET_USER))
   {
    vmsg(err_uid);
    return 0;
  }

  strcpy(userid,xacct.userid);
 
 vget(2, 0, "���D:", ve_title, 60, 1);
 if(!ve_title) 
  strcpy(ve_title, "I Love You...");
  
  usr_fpath(fpath, cuser.userid, "lovepaper");
  unlink(fpath);
  if (!(fd = fopen(fpath, "w")))
    {vmsg("���ѥ���!"); return 0;}
  
  
  srand(time(0));
  if(fp = fopen(LOVE_PAPER,"r+"))
  {
    //clear();
    mode = 0;
    style = 0;
    while(fgets(buf,sizeof(buf),fp))
    {
      if(strstr(buf,"#"))
        continue;
      switch(mode)
      {
        case 0:
          if(strstr(buf,header[style]))
          {
            if(strstr(buf,P_POEM))
            {
              mode++;
              break;
            }
            fgets(buf,sizeof(buf),fp);
            page = atoi(buf);
            rpage = rand() % page;
          }
          else
            break;
          line = 0;
          for(cpage = 0;cpage < page;)
          {
            if(!fgets(buf,sizeof(buf),fp))
              break;
            if(cpage == rpage)
             { //prints("%s",buf);
              fprintf(fd,"%s",buf);
             }
            line++;
            if(line >= h_line[style])
            {
              cpage++;
              line = 0;
            }
          }
          style++;
          break;
        case 1:
          //prints("--\n");
          fprintf(fd,"--\n");
          page = atoi(buf);
          rpage = rand() % page;
          line = 0;
          for(cpage = 0;cpage < page;)
          {
            if(!fgets(buf,sizeof(buf),fp))
              break;
            if(strstr(buf,"$"))
            {
              line = 1;
            }
            else if(cpage == rpage)
              {//prints("%s",buf);
              fprintf(fd,"%s",buf);}
            if(line)
            {
              cpage++;
              line = 0;
            }
          }
          break;
      }
    }
    fclose(fp);
  }
    fclose(fd);
  curredit = EDIT_MAIL;         /* Thor.1105: �������w�g�H */
  if (vedit(fpath, YEA) == -1)
  {
    unlink(fpath);
    clear();
    return -2;
  }
    clear();
    prints("���ѧY�N�H�� %s\n���D���G%s\n�T�w�n�H�X��? (Y/N) [Y]",
    userid, ve_title);
    switch (vkey())
    {
    case 'n':
    case 'N':
      outs("N\n�H��w����");
      refresh();
      rc = -2;
      break;

    default:
      outs("Y\n�еy��, �H��ǻ���...\n");
      refresh();
      break;
 } 
      usr_fpath(folder, userid, fn_dir);
      hdr_stamp(folder, HDR_LINK, &mhdr, fpath);
      strcpy(mhdr.owner, cuser.userid);
      strcpy(mhdr.nick, cuser.username);        /* :chuan: �[�J nick */
      strcpy(mhdr.title, ve_title);
      rc = rec_add(folder, &mhdr, sizeof(mhdr));
      unlink(fpath);
      vmsg("���ѱH�X�h�ơI");
      m_biff(xacct.userno);

      acct_load(&cuser,cuser.userid);
      cuser.money -= 100;
      acct_save(&cuser);

  return 0;  
}
#endif	/* _HAVE_MONEY_ISM_ */
