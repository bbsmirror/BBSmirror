/* hightman: �D�s������C�C�C������ :P */

#include "bbs.h"

#ifdef HAVE_MONEY_ISM
/* hightman: ���� log */
static void
keeplog(fnlog, board, title, mode)
  char *fnlog;
  char *board;
  char *title;
  int mode;             /* 0:load 1: rename  2:unlink */
{
  HDR hdr;
  char folder[128], fpath[128];
  int fd;
  FILE *fp;

  if (!board)
    board = BRD_ACCOUNT;	/* "Bulletin"; */

  sprintf(folder, "brd/%s/.DIR", board);
  fd = hdr_stamp(folder, 'A', &hdr, fpath);
  if (fd < 0)
    return;

  if (mode == 1)
  {
    close(fd);
    /* rename(fnlog, fpath); */
    f_mv(fnlog, fpath); /* Thor.990409:�i��partition */
  }
  else
  {
    fp = fdopen(fd, "w");
    fprintf(fp, "�@��: SYSOP (����Ϫ�)\n���D: %s\n�ɶ�: %s\n",
      title, ctime(&hdr.chrono));
    f_suck(fp, fnlog);
    fclose(fp);
    close(fd);
    if (mode)
      unlink(fnlog);
  }

  strcpy(hdr.title, title);
  strcpy(hdr.owner, "SYSOP");
  strcpy(hdr.nick, "����Ϫ�");
  fd = open(folder, O_WRONLY | O_CREAT | O_APPEND, 0600);
  if (fd < 0)
  {
    unlink(fpath);
    return;
  }
  write(fd, &hdr, sizeof(HDR));
  close(fd);
}

/* hightman: �ˬd���� */

int check()
{
   char msg[256];
   int today, date, times_today;
   time_t now = time(NULL);
   struct tm *t;
   FILE *fp;   

   t = localtime(&now);
   date = times_today = 0;
   today = (t->tm_mon + 1) * 100 + t->tm_mday;  /* �� 1122 �N�� Nov. 22th */
   usr_fpath(msg, cuser.userid, "steal");

   /* �ˬd�O�_�W�L�I�q�@�Ѧ��� */
   if(fp = fopen(msg, "r"))
   {
     fscanf(fp, "%4d %2d", &date, &times_today);
     fclose(fp);

     if(times_today >= 3 && today == date)
     {
       vmsg("�z�w�g���L3���F�A�O�ӳg�߭�I");
       return 0;
     }
     else if(fp = fopen(msg, "w"))
         {
             if(date == today)
              times_today++;
             else
              times_today = 1;
             fprintf(fp, "%4d %2d", today, times_today);
          }
            fclose(fp);
            return 1;
    }
    else
     {
     if(fp = fopen(msg, "w"))
         {
             if(date == today)
              times_today++;
             else
              times_today = 1;
             fprintf(fp, "%4d %2d", today, times_today);
          }  
            fclose(fp); 
            return 1;
      }
}

/* main program */

int p_steal()
{
  char userid [IDLEN + 1];
  ACCT acct;
  int num,mode;
  FILE *fn;
  char filename[128];
  char buf[256];

  clear();
  utmp_mode(M_STEAL);
 
  if(!check()) 
    return;

  vs_bar("���s������");
  move(2,0);
  clrtobot();
 if (!vget(1, 0, "�n���֪�?", userid, IDLEN + 1, GET_USER))
  {
    vmsg(err_uid);
    return 0;
  }

 acct_save(&cuser);
 acct_load(&acct,userid);
 srandom(time(NULL));
 if(acct.money>0)
  {
   if(cuser.money - acct.money > 5000)
    num=acct.money/5+ (rand() % cuser.numposts);
   else if(cuser.money - acct.money > 2000)
    num=acct.money/8 + (rand()% acct.numposts);
   else if(cuser.money - acct.money >=0 )
    num=acct.money/12+ (rand()% cuser.numposts);
   else num = rand() % (cuser.numposts+acct.numposts);
  
   if(cuser.numposts<=acct.numposts)  num /= 2;
   else num *= 1.5;
  
   if(num>acct.money) num = acct.money;
    mode = random() % 10; 
  }
   else mode =2;

   if(mode > 4)
   { 
    acct.money -= num;
    cuser.money += num;
 
    acct_save(&acct);
    acct_save(&cuser);
   
    prints("\n�A���\���q%s���W���o%d��\n",acct.userid,num); 
   
    sprintf(filename,"tmp/report.%s", cuser.userid);
    sprintf(buf,"����,%s�Q�������C%d�C",acct.userid,num);
                    if ((fn=fopen(filename,"w")) != NULL)
                {
                        fprintf(fn,"���Ѫ�--%s\n",cuser.userid);
                        fclose(fn);
                        keeplog(filename, "Game_report", buf,2);
                        unlink(filename);
                }
#if 0
/* hightman: ���O����syslog�F...:P */
    sprintf(filename,"tmp/sys.%s", cuser.userid);
    sprintf(buf,"[���i] %s��%s�������C%d�C",cuser.userid,acct.userid,num);
                    if ((fn=fopen(filename,"w")) != NULL)
                {
                        fprintf(fn,"�p�D�C�Фް_�`�N!.\n");
                        fclose(fn);
                        keeplog(filename, "syslog", buf,2);
                        unlink(filename);
                }
#endif

    }
    else if(mode==2 || mode==3)
   {
     clear();
     prints("\n�A�������ѡA�P���q���Ϫ̮i�}�j�ԡA�ॢ�Ҧ��{���C");
     cuser.money = 0;
     acct_save(&cuser);
   } else
   {
     clear();
     prints("\n�A�������ѡA�ܬӪ��k���{���C");
   }
   vmsg(NULL);
   return;
}

#endif	/* _HAVE_MONEY_ISM_ */
