#include "bbs.h"

#ifdef HAVE_AUTO_ORDERSONG

#define FN_SONG_LOG     "run/ordersongs.log"    /* �I�q���� */
#define BRD_ORDERSONGS  "note"
#define BRD_REQUEST     "justforu"

extern BCACHE *bshm;
extern XZ xz[];
extern char xo_pool[];

static void XoSong(char *folder,char *title,int level);
static int song_order();

#define GEM_READ        1       /* readable */
#define GEM_WRITE       2       /* writable */
#define GEM_FILE        4       /* �w���O�ɮ� */

#define	SONG_SRC	"<~Src~>"
#define SONG_DES	"<~Des~>"
#define SONG_SAY	"<~Say~>"
#define SONG_END	"<~End~>"
#define	SONG_BOT	"\033[0;30;46m[������a�I�q��] \033[0;31;47m  h \033[30m���U\033[31m m \033[30m�I�q��H�c\033[31m o\033[30m �I�q��ݪO \033[31m ^q\033[30m �d�߳ѧE����       \033[m"
static void
log_song(msg)
  char *msg;
{
  char buf[512];
  time_t now = time(0);
  sprintf(buf, "%s %-20s %s\n", Ctime(&now), cuser.userid, msg);
  f_cat(FN_SONG_LOG, buf);
}


static int
song_swap(str,src,des)
  char *str;
  char *src;
  char *des;
{
  char *ptr,*tmp;
  char buf[300];
  ptr = strstr(str,src);
  if(ptr)
  {
    *ptr = '\0';
    tmp = ptr + strlen(src);
    sprintf(buf,"%s%s%s",str,des,tmp);
    strcpy(str,buf);
    return 1;
  }
  else
    return 0;
}


static HDR *
song_check(xo, fpath)
  XO *xo;
  char *fpath;
{
  HDR *ghdr;
  int gtype, level;
  char *folder;

  level = xo->key;

  ghdr = (HDR *) xo_pool + (xo->pos - xo->top);
  gtype = ghdr->xmode;

  if ((gtype & GEM_RESTRICT) && (level <= GEM_USER))
    return NULL;
/*
  if ((gtype & GEM_LOCK) && (!HAS_PERM(PERM_SYSOP)))
    return NULL;
*/
  if (fpath)
  {
    if (gtype & GEM_BOARD)
    {
      sprintf(fpath, "gem/brd/%s/.DIR", ghdr->xname);
    }
    else
    {
      folder = xo->dir;
      if (gtype & GEM_GOPHER)
      {
        return NULL;
      }
      else
      {
        hdr_fpath(fpath, folder, ghdr);
      }
    }
  }
  return ghdr;
}

static HDR *
song_get(xo, fpath)
  XO *xo;
  char *fpath;
{
  HDR *ghdr;
  int gtype, level;
  char *folder;

  level = xo->key;

  ghdr = (HDR *) xo_pool + (xo->pos - xo->top);
  gtype = ghdr->xmode;

  if ((gtype & GEM_RESTRICT) && (level <= GEM_USER))
    return NULL;
/*
  if ((gtype & GEM_LOCK) && (!HAS_PERM(PERM_SYSOP)))
    return NULL;
*/
  if (fpath)
  {
      folder = xo->dir;
      if (gtype & (GEM_GOPHER|GEM_FOLDER|GEM_RESERVED))
      {
        return NULL;
      }
      else
      {
        hdr_fpath(fpath, folder, ghdr);
      }
  }
  return ghdr;
}

static void
song_item(num, ghdr)
  int num;
  HDR *ghdr;
{
  int xmode, gtype;

  xmode = ghdr->xmode;
  gtype = (char) 0xf3;
  if (xmode & GEM_FOLDER)
    gtype += 1;
  if (xmode & GEM_GOPHER)
    gtype += 2;
  prints("%6d%c \241%c ", num, (xmode & GEM_RESTRICT) ? ')' :  ' ',gtype);

  gtype = 0;
/* hightman.001105: nouse...
  if (!HAS_PERM(PERM_SYSOP)&&(xmode & (GEM_RESTRICT|GEM_LOCK)))
    prints("\033[1;33m��ƫO�K�I\033[m\n");
  else
*/
   if ((gtype == 0) || (xmode & GEM_GOPHER))
    prints("%-.64s\n", ghdr->title);
   else
      prints("%-46.45s%-13s%s\n",ghdr->title,
        (gtype == 1? ghdr->xname:ghdr->owner),ghdr->date);
}


static int
song_body(xo)
  XO *xo;
{
  HDR *ghdr;
  int num, max, tail;

  max = xo->max;
  if (max <= 0)
  {
    outs("\n\n�m�q���n�|�b�l���Ѧa��������� :)");
    vmsg(NULL);
    return XO_QUIT;
  }

  ghdr = (HDR *) xo_pool;
  num = xo->top;
  tail = num + XO_TALL;
  if (max > tail)
    max = tail;

  move(3, 0);
  do
  {
    song_item(++num, ghdr++);
  } while (num < max);
  clrtobot();
 move(b_lines,0);
 outz(SONG_BOT);
 clrtobot();
  return XO_NONE;
}


static int
song_head(xo)
  XO *xo;
{

  vs_head("�I�q�x--�q��", xo->xyz);

  outs("\
[��]���} [��]�s�� [o]�I�q [m]�H�H [^q]�d�߳ѧE���� [Enter]�s�� [h]����  \n");
  outs("\033[44m\
  �s��     �D              �D                            [�s      ��] [��  ��]\033[m");
  return song_body(xo);
}


static int
song_init(xo)
  XO *xo;
{
  xo_load(xo, sizeof(HDR));
  return song_head(xo);
}


static int
song_load(xo)
  XO *xo;
{
  xo_load(xo, sizeof(HDR));
  return song_body(xo);
}


/* ----------------------------------------------------- */
/* ��Ƥ��s�W�Gappend / insert				 */
/* ----------------------------------------------------- */


static int
song_browse(xo)
  XO *xo;
{
  HDR *ghdr;
  int xmode,op;
  char fpath[80], title[TTLEN + 1];

  do
  {
    ghdr = song_check(xo, fpath);
    if (ghdr == NULL)
      break;

    xmode = ghdr->xmode;

    /* browse folder */

    if (xmode & GEM_FOLDER)
    {
      op = xo->key;
      if (xmode & GEM_BOARD)
      {
        op = brd_bno(ghdr->xname);
        if (HAS_PERM(PERM_SYSOP)) 
          op = GEM_SYSOP;
	else
	  op = GEM_USER;
      }
      else if (xmode & HDR_URL)
      {
	return XO_NONE;
      }

      strcpy(title, ghdr->title);
      XoSong(fpath, title, op);
      return song_init(xo);
    }

    /* browse article */

    /* Thor.990204: ���Ҽ{more �Ǧ^�� */   
    if ((xmode = more(fpath, MSG_GEM)) == -2)
      return XO_INIT;
    if(xmode == -1)
      break;

    op = GEM_READ | GEM_FILE;

    xmode = xo_getch(xo, xmode);

  } while (xmode == XO_BODY);

  if (op != GEM_READ)
    song_head(xo);
  return XO_NONE;
}

#if 1
static int
song_order(xo)
  XO *xo;
{
  char xboard[20], fpath[80], xfolder[80], xtitle[80], *dir,buf[256];
  char tmp[256],idwho[20],want_say[50];
  HDR *hdr, xpost;
  int method, battr, flag, flag2 = 0;
  FILE *xfp,*fp,*gfp;
  ACCT acct;
  time_t token; //,now;
  char folder[80],gfpath[80];

  /* hightman: �@�ѳ̦h�I�T�� */
   char msg[256];
   int today, date, order_times_today;
   time_t now = time(NULL);
   struct tm *t;

  acct_load(&acct,cuser.userid);

   t = localtime(&now);
   date = order_times_today = 0;
   today = (t->tm_mon + 1) * 100 + t->tm_mday;  /* �� 1122 �N�� Nov. 22th */
   usr_fpath(msg, cuser.userid, "song");

   /* �ˬd�O�_�W�L�I�q�@�Ѧ��� */
   if(fp = fopen(msg, "r"))
   {
     fscanf(fp, "%4d %2d", &date, &order_times_today);
     fclose(fp);

     if(order_times_today >= 3 && today == date)
     {
       vmsg("�z���Ѥw�I�L�T���q��ݪO�F�A�O�ӳg�߭�I");
       return XO_NONE;
     }
   }


  hdr = song_get(xo, fpath);
  if (hdr == NULL)
    return XO_NONE;

  if (!cuser.userlevel)
    return XO_NONE;
    
#ifdef HAVE_MONEY_ISM    
  if(acct.money<100)
  {
    vmsg("�A�����������F!");
    return XO_NONE;
  }
#endif

  if(!vget(b_lines, 0, "�Q��q�I����(���@�w�n ID)�H", idwho, sizeof(idwho), DOECHO))
    strcpy(idwho,"�j�a");
  if(!vget(b_lines, 0, "�g�U�A�������e�y�a�G", want_say, sizeof(want_say), DOECHO))
    strcpy(want_say,".........");

  if(vans("�n�ΦW�� [y/N]�G") == 'y')
    flag = 1;
  else
    flag = 0;

  if(vans("�T�w�I�q�� [Y/n]�G") == 'n')
    return XO_HEAD;

  strcpy(xboard, BRD_ORDERSONGS);


  method = 0;

  dir = xo->dir;
  battr = (bshm->bcache + brd_bno(xboard))->battr;
  strcpy(xtitle, hdr->title);
  xo_fpath(fpath, dir, hdr);
  brd_fpath(xfolder, xboard, fn_dir);

  method = hdr_stamp(xfolder,'A', &xpost, buf);
  xfp = fdopen(method, "w");

  sprintf(folder, "gem/brd/note/.DIR");
  hdr_stamp(folder, 'A', &xpost, gfpath);

  gfp = fopen(gfpath, "w");


  memcpy(xpost.owner, cuser.userid,sizeof(xpost.owner) + sizeof(xpost.nick));
  token = time(0);
  if(flag)
    strcpy(xpost.owner,"[���i�D�A]");

  str_stamp(xpost.date, &token);
  sprintf(xpost.title, "[�I�q] %s �I�� %s",xpost.owner,idwho);

  log_song(xpost.title);
  fp = fopen(fpath,"r+");
   
  while(fgets(tmp,256,fp))
  {
    if(strstr(tmp,SONG_END))
      break; 

    while(song_swap(tmp,SONG_SRC,flag ? "�Y�H" : cuser.userid)) { flag2=1; }
    while(song_swap(tmp,SONG_DES,idwho));
    while(song_swap(tmp,SONG_SAY,want_say));
    fputs(tmp,xfp);
    fputs(tmp,gfp);
  }
if (!flag2)
{
 sprintf(buf,"\033[1;33m%s\033[m �Q�� \033[1;33m%s\033[m ��: \033[1;32m%s\
\033[m\n",flag ? "�Y�H":cuser.userid,idwho,want_say);
  fputs(buf,xfp);
  fputs(buf,gfp);
}

 
  fclose(fp);
  fclose(gfp);
  fclose(xfp);
  close(method);

#ifdef HAVE_MONEY_ISM  
  acct.money -= 100;
  cuser.money = acct.money;
  sprintf(buf,"�I�q�����I�]�w��b justforu �O��Z�q���~ �ѧE�����G%d ��",
             acct.money);             
  vmsg(buf);
  acct_save(&acct);
#else
  vmsg("�I�q�����I�]�w��b justforu �O��Z�q���~");
#endif  

  rec_add(xfolder, &xpost, sizeof(xpost));
  rec_add("gem/brd/note/@/@note", &xpost, sizeof(xpost));  /* �e�쬡�ʬݪO */	

  usr_fpath(msg, cuser.userid, "song");		  /* �O���I�q���� */

   if(fp = fopen(msg, "w"))
   {
    if(date == today)
      order_times_today++;
    else
       order_times_today = 1;

    fprintf(fp, "%4d %2d", today, order_times_today);
   fclose(fp);
   }

  return XO_HEAD;
}
#endif

#ifdef HAVE_MONEY_ISM
static int
song_query(xo)
  XO *xo;
{
  char buf[80];

  sprintf(buf,"�ѧE�����ơG%d",cuser.money);
  vmsg(buf);
  return XO_HEAD;
}
#endif

static int
song_send(xo)
  XO *xo;
{
  char fpath[128], folder[128], *dir, title[80],buf[256],want_say[50],date[9];
  char tmp[300];
  HDR *hdr, xhdr;
  ACCT acct,cacct;
  int method,flag2=0;
  FILE *xfp,*fp;
  time_t now;

  now = time(0);

  str_stamp(date, &now);
  acct_load(&cacct,cuser.userid);
  hdr = song_get(xo, fpath);

 if (hdr == NULL)
  return XO_NONE;

  if (!cuser.userlevel)
    return XO_NONE;

#ifdef HAVE_MONEY_ISM
  if(cacct.money<100)
  {
    vmsg("�u�r,�ڪ��������F!");
    return XO_NONE;
  }
#endif
  
  method = 0;
  if (acct_get("�Q��q�I���֡G",&acct)<1)
    return XO_HEAD;

  dir = xo->dir;
  strcpy(title,hdr->title);

  usr_fpath(folder, acct.userid, fn_dir);
  method = hdr_stamp(folder, 0 , &xhdr, buf);

  xfp = fdopen(method, "w");

  strcpy(xhdr.owner, cuser.userid);
  strcpy(xhdr.nick, cuser.username);
  sprintf(xhdr.title, "%s �I�q���z",cuser.userid);
  strcpy(xhdr.date, date);
  
  sprintf(tmp,"%s �I�q�� %s",cuser.userid,acct.userid);
  log_song(tmp);

  if(!vget(b_lines, 0, "�g�U�A�������e�y�a�G", want_say, sizeof(want_say), DOECHO))
    strcpy(want_say,".........");
  
  fp = fopen(fpath,"r+");

  while(fgets(tmp,256,fp))
  {
   if(strstr(tmp,SONG_END))
      break;
   
    while(song_swap(tmp,SONG_SRC,cuser.userid)){flag2=1;}
    while(song_swap(tmp,SONG_DES,acct.userid));
    while(song_swap(tmp,SONG_SAY,want_say));

    fputs(tmp,xfp);
  }

if(!flag2) {
  sprintf(buf,"\033[1;33m%s\033[m �Q�� \033[1;33m�z\033[m ��: \033[1;32m%s\033[m\n",cuser.userid,want_say);
  fputs(buf,xfp);
}
  fclose(fp);

  rec_add(folder, &xhdr, sizeof(HDR));

  fclose(xfp);
  close(method);

#ifdef HAVE_MONEY_ISM  
  cacct.money -= 100;
  if(cacct.money <= 0) cacct.money = 0;
  cuser.money = cacct.money;
  sprintf(buf,"�ѧE�����ơG%d ��",cacct.money);
  vmsg(buf);
  acct_save(&cacct);
#else
  vmsg("�I�q����!");  
#endif
  
  m_biff(acct.userno);
  return XO_INIT;
}

static int
song_edit(xo)
  XO *xo;
{
  char fpath[80];
  HDR *hdr;

  if (!HAS_PERM(PERM_KTV))
    return XO_NONE;
  hdr = song_get(xo, fpath);
  if(hdr)
    vedit(fpath, NA);
  return song_head(xo);
}

static int
song_title(xo)
  XO *xo;
{
  HDR *ghdr, xhdr;
  int num;
  char *dir;
  char fpath[128];

  ghdr = song_get(xo, fpath);
  if (ghdr == NULL)
    return XO_NONE;

  xhdr = *ghdr;
  vget(b_lines, 0, "���D�G", xhdr.title, TTLEN + 1, GCARRY);

  dir = xo->dir;
  if (cuser.userlevel & (PERM_SYSOP|PERM_KTV))
  {
    vget(b_lines, 0, "�s�̡G", xhdr.owner, IDLEN + 2, GCARRY);
    vget(b_lines, 0, "�ɶ��G", xhdr.date, 9, GCARRY);
  }

  if (memcmp(ghdr, &xhdr, sizeof(HDR)) &&
    vans("�T�w�n�ק��(Y/N)�H[N]") == 'y')
  {
    *ghdr = xhdr;
    num = xo->pos;
    rec_put(dir, ghdr, sizeof(HDR), num);
    num++;
    move(num - xo->top + 2, 0);
    song_item(num, ghdr);

  }
  return XO_FOOT;
}

static int
song_help(xo)
  XO *xo;
{
  clear();
  more("gem/@/@song.hlp",0);
  return song_head(xo);
}

static KeyFunc song_cb[] =
{
  XO_INIT, song_init,
  XO_LOAD, song_load,
  XO_HEAD, song_head,
  XO_BODY, song_body,

  'r', song_browse,
  'o', song_order,
  'E', song_edit,
  'T', song_title,
  
#ifdef HAVE_MONEY_ISM  
  Ctrl('Q'), song_query,
#endif  

  'm', song_send,
  'h', song_help
};


static void
XoSong(folder, title, level)
  char *folder;
  char *title;
  int level;
{
  XO *xo, *last;
  char *str;

  last = xz[XZ_XOTHER - XO_ZONE].xo;	/* record */

  xz[XZ_XOTHER - XO_ZONE].xo = xo = xo_new(folder);
  xz[XZ_XOTHER - XO_ZONE].cb = song_cb;
  xo->pos = 0;
  xo->key = XZ_XOTHER;

  xo->xyz = "�I�q�t��";
  str = "�t�κ޲z��";
  sprintf(currBM, "�O�D�G%s", str);

  xz[XZ_XOTHER - XO_ZONE].mode = M_SONG;  /* hightman: ���A */
  xover(XZ_XOTHER);

  free(xo);

  xz[XZ_XOTHER - XO_ZONE].xo = last;	/* restore */
}

int
XoSongMain(void)
{
  char fpath[64];

#ifdef HAVE_MONEY_ISM  
  if(cuser.money<100)
    { 
       vmsg("�藍�_,�z���{���٤���100,�t�Τ����A�I�F! ");  
       return 0;
   }
#endif

  strcpy(currboard, BRD_REQUEST);

  bbstate = STAT_STARTED;

  utmp_mode(M_SONG);
  more("etc/song",0);
  sprintf(fpath,"gem/brd/%s/@/@SongBook",currboard);
  XoSong(fpath, "�I�q�t��", XZ_XOTHER);
  return 0;
}

int
XoSongSub(void)
{
  int chn;
  chn = brd_bno(BRD_REQUEST);
  XoPost(chn);
  xover(XZ_POST);
  return 0;  
}

int
XoSongLog(void)
{
  int chn;
  chn = brd_bno(BRD_ORDERSONGS);
  XoPost(chn);
  xover(XZ_POST);
  return 0;
}
#endif	/* _HAVE_AUTO_ORDERSONG_ */
