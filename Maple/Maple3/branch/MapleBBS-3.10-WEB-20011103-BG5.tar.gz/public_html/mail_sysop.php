<?php
//sendmail.php �l��o�e title, receiver, content ...

unset($cuser);
session_start();
$pid = $cuser[pid];

if(!$pid) {
	echo "<html>�z�w�g�_�}�s��! �Ы�F5��s����!</html>";
	exit; 
}

?>

<html>
<head>
<title>SendMail to Sysop</title>
<link rel="stylesheet" type="text/css" href="style.css">
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>
<body bgcolor="#ffffff" leftmargin="3" topmargin="0" marginwidth="3" marginheight="0">
<table width="609" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="80"><img src="images/mail_top.gif" width="474" height="80" usemap="#Map" border="0"></td>
  </tr>
  <tr> 
    <td width="100%" align="center"><hr size="2" noshade width="95%" color="#b751af"></td>
  </tr>
  <tr> 
    <td width="100%" align="center">

<?php

//�֤߳���
require_once('config.php');
require_once('webbbs.class.php');

$sysopFile = "etc/sysop";
$ws = new server_class;

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

function getSYSOP() {
	global $sysopFile;
	global $ws;
	
	$sysops = array();
	$ws->connect();
	$cmd = $ws->set_cmd("getfile", G_CMD, $sysopFile);
	$ws->query($cmd);

	$list = split("\n", $ws->data);
	$len = count($list);
	if($len < 1) 
		array_push($sysops, DEFAULT_BOARD, "�t���`����");
	else {
		$i = 0;
		for($i=0; $i<$len; $i++) {
			$tmp = $list[$i];
			$tmp = str_replace(" ", "", $tmp);
			$tmp = str_replace("\t", "", $tmp);
			$tmps = explode(":", $tmp);
			if($tmp[1] != "")
				array_push($sysops, $tmps[0], $tmps[1]);
		}
	}
	return $sysops;
}

$sysops = getSYSOP();

if($title == '' || $content == '' || !in_array($receiver, $sysops)) { /* ������, ���X���� */

	$sysopStr = "<option> ��ܤ@�ӯ���! </option>\n";
	for($i=0; $sysops[$i]; $i++) {
		if($sysops[$i] != $receiver) {
			$sysopStr .= "<option value='".$sysops[$i]."'>".$sysops[$i]." = ".$sysops[++$i]."</option>\n";
		} else {
			$sysopStr .= "<option value='".$sysops[$i]."' selected>".$sysops[$i]." = ".$sysops[++$i]."</option>\n";
		}
	}

	if($title == '') $title = "�Ӧ�".$cuser[userid]."����ĳ";
	print "<table width=95% align=center bgcolor=f0f0f0 border=1 bordercolor=efefef>";
	if($submit) {
		print "<tr><td>".alertMsg("�ж�g����A������\"����\"��")."</td></tr>\n";
	}
	print "
	 <form action='".$PHP_SELF."' method=POST>
	 <tr><td>�H����D: <input type=text name=title value='".$title."' size=40 maxlength=60> �o�H�H: $cuser[userid] </td></tr>
	 <tr><td>���H�H&nbsp;&nbsp;: <select name=receiver size=1>
		".$sysopStr."
		</select>
		�ϥ�ñ�W�� <input type=radio name=sign value=1 checked>1 <input type=radio name=sign value=2>2
		<input type=radio name=sign value=3>3 <input type=radio name=sign value=0>0 
		�ƥ��H��<input type=checkbox value=1 name=sign>
	 </td></tr>
     <tr><td><textarea name=content wrap=hard cols=77 rows=18>".$content."</textarea></td></tr>
	 <tr><td align=center>
	  <input type=submit name=submit value=' �o �e '>
	  <input type=button onclick='top.window.history.go(-1)' value=' �� �^ '>
	 </td></tr>
	 </form>
	</table>
	 ";
} else {
	print "<tr><td align=center>";
	
	$ws->connect();
	if(!$sign) $sign = 0;
	if(!$mailhold) $mailhold = 0;
	$cmd = $ws->set_cmd("sendmail", G_MAIL, $pid, $receiver, $sign, $mailhold);
	$ws->send($cmd);
	$data = $ws->recv(8);
	$check = substr($data, 0, 2);
	if($check == 'OK') {
		$ws->send("TITLE: ".$title."\n");	/* title */
		$ws->send($content."\n");			/* content */
		$ws->send("<--POST-END-->\n");		/* tell end */
		$data = $ws->recv(128);
		$ws->close();						/* �[�Wclose�� */
		$check = $ws->parse($data);
		if($check[result] == 'OK') {
			echo alertMsg($check[msg]);
			echo "<br><br> <a href=main.php>��^�D��</a> <a href=javascript:window.history.back()>��^�W��</a>";
		} else {
			$ws->alert($data);
		}
	} else {
		$ws->alert($data);
	}
}	

	?>
	</td>
  </tr>
  <tr> 
    <td width="100%" align="center"><hr size="2" noshade width="95%" color="#c0c0c0"></td>
  </tr>
</table>
<map name="Map"> 
  <area shape="rect" coords="93,62,172,77" href="maillist.php" alt="�\Ū�l��" title="�\Ū�l��">
  <area shape="rect" coords="179,62,256,77" href="sendmail.php" alt="�g�ʶl��" title="�g�ʶl��">
  <area shape="rect" coords="266,62,369,77" href="mail_internet.php" alt="�H�H��Internet" title="�H�H��Internet">
  <area shape="rect" coords="378,63,467,77" href="mail_sysop.php" alt="�g�H������" title="�g�H������">
  <area shape="rect" coords="467,73,469,80" href="#">
</map>
</body>
</html>
<? 
 exit; 
?>