<?php
//Gem List

require_once('config.php');

unset($cuser);
session_start();

$pid = $cuser[pid];
if(!$pid) {
	echo "<html>�z�w�g�_�}�s��! �Ы�F5��s����!</html>";
	exit; 
}

if($page < 1) $page = 1;

if(isset($board)) $fpath = "gem/brd/".$board."/.DIR";

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

?>
<html>
<head>
<title>Gem List</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #0000a0}
A:visited {color: #0000a0}
</style>
</head>
<body leftmargin="3" topmargin="0" marginwidth="3" marginheight="0" bgcolor="#FFFFFF">
<table width="617" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td colspan="3"><img src="images/gem/gem_top.jpg" width="617" height="51" usemap="#Map" border="0"></td>
  </tr>
  <tr> 
    <td width="20" background="images/gem/gem_left_bg.jpg">&nbsp;</td>
    <td height="100%" width="585">

		<?php

		if(!$fpath) {
			$fpath = "gem/.DIR";
		}
		if(!$method) {
			$method = "gemmain";
		}

		require_once('webbbs.class.php');
		
		$ws = new server_class;
		$ws->connect();

		if($method == 'gembrowse') {
			if($num < 1) $num = 1;
			$cmd = $ws->set_cmd($method, G_GEM, $pid, $fpath, $num, $page);
		} else {
			$cmd = $ws->set_cmd($method, G_GEM, $pid, $fpath, $page);
		}

		$ws->query($cmd);
		$list = split("\n", $ws->data);
		$ret = $ws->parse($list[0]);

		if($ret[result] != 'OK') {
			echo "<br><br>";
			echo alertMsg($ws->data);
			echo "<br><br><a href='javascript:window.history.back()'>[������^]</a>";
			exit;
		}	

		$totalpage = intval($ret[max]/XO_TALL);  /* 20�OXo_TALL���� */
		if($ret[max] % XO_TALL) $totalpage ++;
		
		$prv = $page-1;
		$nxt = $page+1;
		
		/* �]�mGoTo Page */
		$gotoString  = "��ؾ\Ū�G �� <font color=a00000>".$page."</font> / ".$totalpage." ��";
		if($prv > 0)
			$gotoString .= " | <a href=\"".$PHP_SELF."?method=".$method."&fpath=".$fpath."&page=".$prv."&num=".$num."\">�W�@��</a>";

		if($nxt <= $totalpage)
			$gotoString .= " | <a href=\"".$PHP_SELF."?method=".$method."&fpath=".$fpath."&page=".$nxt."&num=".$num."\">�U�@��</a>";

		if($totalpage > 1) {

			$gotoString .= " | �䥦�U��: ";

			for($i=1; $i<=$totalpage; $i++) {

				if($i == $page)
					$gotoString .= $i." ";
				else
					$gotoString .= "<a href=\"".$PHP_SELF."?method=".$method."&fpath=".$fpath."&page=".$i."&num=".$num."\">$i</a> ";
			}
		}

		if(isset($board)) {
			$gotoString .= " | <a href='postlist.php?board=$board'>��^����</a>";
		}

		$gotoString  .= " | <a href='#' onclick='window.history.back()'>��^�W�h</a>";

        print "
			<table width='550' border='0' cellspacing='1' cellpadding='0' bgcolor='#ffffff'>
			<tr bgcolor='#dddddd' height='20'> 
	          <td colspan='3' align='center'> $ret[title] </td>
	          <td colspan='2' align='right'> $ret[BM] </td>
		    </tr>
			<tr bgcolor='#dddddd' height='20'> 
	          <td width='40'>�s��</td><td width='40'>���O</td><td width='310'>���D</td><td width='100'>�s��</td><td width='60'>���</td>
		    </tr>
		";

		for($i=1; $i<= XO_TALL; $i++) {
			if($i%2)
				$bgcolor = "#fefefe";
			else
				$bgcolor = "#efefef";

			$tmp = $ws->parse($list[$i]);
			if($tmp[num] <= 0) 
				break;
			
			/* �B�zgtype�@�U */
			$tmp[gtype] = intval($tmp[gtype]);
			if($tmp[gtype]) {
				$tmp[gtype] = "<img src='images/folder.gif'>";
				$submitUrl = "gem.php";
			} else {
				$tmp[gtype] = "<img src='images/file.gif'>";
				$submitUrl = "gem_browse.php";
			}

			/* �B�zstrict */
			$tmp[strict] = intval($tmp[strict]);
			if($tmp[strict]) {
				$tmp[strict] = ")";
			} else {
				$tmp[strict] = "";
			}

			$tmp[title] = str_replace(" ", "&nbsp;", $tmp[title]);

			$submitUrl .= "?method=gembrowse&fpath=$ret[fpath]&num=$tmp[num]";

			/* show the title */
			
			print "
				<tr bgcolor='$bgcolor'>
				<td> $tmp[num]$tmp[strict] </td>
				<td> $tmp[gtype] </td>
				<td> <a href='$submitUrl'>$tmp[title]</a> </td>
				<td> <a href='query.php?userid=$tmp[owner]'>$tmp[owner]</a> </td>
				<td> $tmp[date] </td>
				</tr>
				";
		}
		print "
		<tr bgcolor='#dddddd' height='20'><td colspan='5'>
		 $gotoString	
		</td></tr>
		";
		?>

      </table>	
	</td>
    <td background="images/gem/gem_right_bg.jpg" width="20">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="3" height="2"><img src="images/gem/gem_bottom.jpg" width="617" height="26"></td>
  </tr>
</table>
<map name="Map"> 
  <area shape="rect" coords="48,16,118,36" href="services.php" alt="���ȪA�Ȱ�" title="���ȪA�Ȱ�">
  <area shape="rect" coords="127,17,198,35" href="board.php" alt="�����U�j�Q�װ�" title="�����U�j�Q�װ�">
  <area shape="rect" coords="336,17,408,35" href="personal.php" alt="�ڪ��ӤH�p�v" title="�ڪ��ӤH�p�v">
  <area shape="rect" coords="417,17,487,36" href="talk.php" alt="�𶢲�Ѱ�" title="�𶢲�Ѱ�">
  <area shape="rect" coords="497,17,567,36" href="group.php" alt="�s�ե\���" title="�s�ե\���">
</map>
</body>
</html>