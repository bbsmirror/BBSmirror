<?php
//chat_main
unset($cuser);

require_once('config.php');
require_once('webbbs.class.php');

session_start();

if(isset($cuser[level]) && !($cuser[level] & PERM_CHAT)) {
	echo "<html>�z�S���v�� [<a href=main.php>back</a>]</html>";
	exit;
}

if(!$pid) $pid = $cuser[pid];
if(!$passwd) $passwd = $cuser[passwd];
if(!$chatid) $chatid = $cuser[userid];

$ws = new server_class;
$ws->connect();

$cmd = $ws->set_cmd("chatroom", G_TALK, $pid, $chatid, $passwd);
$ws->query($cmd);
$check = substr($ws->data, 0, 2);
if($check != "OK") {
	echo "<html>".$ws->data." [<a href=main.php>back</a>]</html>";
	exit;
}

?>
 
<html>
<head>
<title>MapleBBS-3.x-��ѫ�Web��</title>
<script language="Javascript">
<!--
 var autoScrollOn = 1;
 var forceLeave = 1;

 function chat_nick(nick) { //��nickname
 	if(this.chatTalk.chatid)
		this.chatTalk.chatid.innerText = nick;
 }

 function chat_func(func) { //��\��
 	if(this.chatTitle.chatfunc)
		this.chatTitle.chatfunc.innerText = func;
 }

 function chat_room(roomname) { //��room
  	if(this.chatTitle.roomname)
		this.chatTitle.roomname.innerText = roomname;
 }

 function chat_topic(topic) { //��topic
 	if(this.chatTitle.topic)
		this.chatTitle.topic.innerText = topic;
 }

 function chat_msg(msg) { //�g��chatbody
	if(this.chatBody.document)
		this.chatBody.document.writeln(msg);
 }

 function chat_err(errmsg) { //�g��chatbody
	this.document.location = "chat_err.php?errmsg="+errmsg;	
 }

 function chat_clear() { // �M��
	this.chatBody.document.close();
	chatBody_init();
 }

 function scrollWindow() { //�u��
	if(autoScrollOn == 1) {
	 	if(this.chatBody)
			this.chatBody.scroll(0, 99999);
		setTimeout('scrollWindow()',300);
	}
 }

 function chatBody_init() { //body init
	if(this.chatBody.document==null) return;
	this.chatBody.document.open();
	this.chatBody.document.writeln("<html><head>");
	this.chatBody.document.writeln("<link href=\"style.css\" rel=\"stylesheet\">");
	this.chatBody.document.writeln("<style type=text/css>");
	this.chatBody.document.writeln("<!--");
	this.chatBody.document.writeln(".body {  font-family: ����; font-size: 12pt; line-height: 14pt }");
	this.chatBody.document.writeln("-->");
	this.chatBody.document.writeln("</style></head><body topmargin=0 marginwidth=3 marginheight=3>");
	this.chatBody.document.writeln("<font style='font-family: ����, Fixedsys; font-size: 10.5pt'; line-height: 14pt>");
	this.chatTalk.document.inputform.msg.focus();
 }

 function scrollit(){
	if(!this.chatTalk.document.inputform.as.checked) {
		autoScrollOn=0;
		return true;
	}else {
		autoScrollOn=1;
		scrollWindow();
		return true;
	}
 }


 function start() { // ��ѫǪ�l�� init...
	clearTimeout(null);
	scrollWindow();
	chatBody_init();
 }

 function bye() { // ���}��ѫ�
	if(forceLeave == 1)
		top.hideFrame.document.location='chat_doTalk.php';
 }

//-->
</script>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<frameset rows="23,*,58, 0" border="0" framespacing="0" onLoad="start()" onUnLoad="bye()">
  <frame src="chat_title.php" name="chatTitle" frameborder="NO" noresize scrolling="no" marginwidth="0" marginheight="0" framespacing="0">
  <frame src="about:blank" name="chatBody" frameborder="NO" noresize>
  <frame src="chat_talk.php?chatid=<?echo $chatid;?>" name="chatTalk" frameborder="NO" noresize scrolling="no" marginwidth="0" marginheight="0" framespacing="0">
  <frame src="about:blank" name="chatHidden">
 </frameset>
<noframes><body bgcolor="#FFFFFF">
�z���s������������V�I�I�I
</body></noframes>
</html>