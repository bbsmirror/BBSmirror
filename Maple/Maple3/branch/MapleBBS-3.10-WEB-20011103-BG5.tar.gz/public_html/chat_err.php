<?php
	echo "<html>".$errmsg." [<a href=talk.php>��^</a>]</html>";
?>