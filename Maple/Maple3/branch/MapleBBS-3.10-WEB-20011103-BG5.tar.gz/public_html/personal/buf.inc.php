<?php
//modify ufile: buf

require_once('config.php');

unset($cuser);
session_start();

$pid = $cuser[pid];
$level = $cuser[level];
if(!$pid || !($level & PERM_BASIC)) {
	echo "<html>�Х��n��! <a href='personal.php'> [������^] </a></html>";
	exit; 
}

if($bufno < 1) $bufno = 1;
if($bufno > 3) $bufno = 3;

$file = "buf.".$bufno;

$otherstr = "";
for($i=1; $i<4; $i++) {
	if($i != $bufno) {
		$otherstr .= " <a href='$PHP_SELF?action=buf&bufno=$i' style='color: f0f0f0'><b>$i</b></a> ";
	}
}

?>
<html>
<head>
<title>ModifyBuf</title>
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #000080}
A:visited {color: #444480}
PRE {color: #c0c0c0}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="649" border="0" cellspacing="0" cellpadding="0" align="left">
<tr width="100%"><td align="left" valign="top">
<br>
<h3><font color='00a000'> �� �ڪ��p�H�ɮ� </font></h3>
<br>
<?php

//���ǤJdo���ȳ�: submit: ����  preview: �w�� ...�䥦���O�ШD�d�� 
function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

require_once('webbbs.class.php');
require_once('ansi2web.inc.php');

if($do == "update") {

	$ws = new server_class;
	$ws->connect();
	$cmd = $ws->set_cmd("modufile", G_ACCT, $pid, $file);
	$ws->send($cmd);
	$data = $ws->recv(8);
	$check = substr($data, 0, 2);
	if($check == 'OK') {
		$ws->send($buf."\n");				/* content */
		$ws->send("<--FILE-END-->\n");		/* tell end */
		$data = $ws->recv(128);
		$ws->close();						/* �[�Wclose�� */
		$check = $ws->parse($data);
		if($check[result] == 'OK') {
			echo "<br><br>";
			echo alertMsg($check[msg]);
			echo "<br><br><a href='$PHP_SELF?action=buf&bufno=$bufno'>�����i�H�ֳt��^...</a>";
		} else {
			$ws->alert($data);
		}
	}

} else if($do == "modify") {

	if(!($cuser[level] & PERM_BASIC)) {
		echo "<br><br>";
		echo alertMsg("Fatal Error: �z�S���v���ק�Ȧs��~");
		echo "<br><br><a href='$PHP_SELF?action=buf&bufno=$bufno'>�����i�H�ֳt��^...</a>";
		exit;
	}

	$ws = new server_class;
	$ws->connect();
	$cmd = $ws->set_cmd("ufilerqst", G_ACCT, $pid, $file);
	$ws->query($cmd);
	
	$data = split("\n\n", $ws->data, 2);
	$ret = $ws->parse($data[0]);
	
	if($ret[result] != "OK") {
		$ws->alert($ws->data);
		exit;
	}

	//start to show
	print "
	  <table width='600' border='0' cellspacing='0' cellpadding='0' align='center'>
	  <tr bgcolor='#663300'> 
	    <td colspan='3' height='25'>
		<font color='#FFFFFF'>�� �ڪ��� $bufno �ӼȦs�� - $cuser[userid] ��</font> &nbsp;&nbsp;&nbsp;&nbsp;
		<font color='#d0d0d0'>�i���b�ק��~ �䥦: $othterstr �j</font>
		</td>
	  </tr>
	  <tr> 
		<td rowspan='5' width='13' bgcolor='#CCCCCC'>&nbsp;</td>
	    <td width='572' height='13' bgcolor='#CCCCCC'>&nbsp;</td>
		<td rowspan='5' width='13' bgcolor='#CCCCCC'>&nbsp;</td>
	  </tr>
	  <tr> 
		<form action='$PHP_SELF' method='post'>
	    <td width='572' height='80' bgcolor='#f0f0f0' align='center'>
		<textarea name='buf' cols='77' rows='23' wrap='hard'>".$data[1]."</textarea>
		<input type='hidden' name='action' value='buf'>
		<input type='hidden' name='bufno' value='$bufno'>
		<input type='hidden' name='do' value='update'>
		<input type='submit' value='�T�w�ק�'>
		<input type='reset' value='�٭쭫�g'>
		</td>
		</form>
	  </tr>
	  <tr> 
	    <td width='572' bgcolor='#CCCCCC' height='13'>&nbsp;</td>
	  </tr>
	  </table>
	";

} else {

	$ws = new server_class;
	$ws->connect();
	$cmd = $ws->set_cmd("ufilerqst", G_ACCT, $pid, $file);
	$ws->query($cmd);
	
	$data = split("\n\n", $ws->data, 2);
	$ret = $ws->parse($data[0]);
	
	if($ret[result] != "OK") {
		$ws->alert($ws->data);
		exit;
	}

	if($data[1] == ''){
		$data[1] = "�ȮɨS�����e��~!";
	}

	//start to show
	print "
	  <table width='600' border='0' cellspacing='0' cellpadding='0' align='center'>
	  <tr bgcolor='#663300'> 
	    <td colspan='3' height='25'>
		<font color='#FFFFFF'>�� �ڪ��� $bufno �ӼȦs�� - $cuser[userid] ��</font> &nbsp;&nbsp;&nbsp;&nbsp;
		<a href='$PHP_SELF?action=buf&bufno=$bufno&do=modify' style='color: d0d0d0'><font color='#d0d0d0'>�i�I���o�̥i�H�ק��~�j</font></a>
		�䥦�Ȧs��: $otherstr </td>
	  </tr>
	  <tr> 
		<td rowspan='5' width='13' bgcolor='#CCCCCC'>&nbsp;</td>
	    <td width='572' height='13' bgcolor='#CCCCCC'>&nbsp;</td>
		<td rowspan='5' width='13' bgcolor='#CCCCCC'>&nbsp;</td>
	  </tr>
	  <tr> 
	    <td width='572' height='160' valign='top' bgcolor='#000000'>
		 <pre>".ansi2web($data[1])."</pre>
		</td>
	  </tr>
	  <tr> 
	    <td width='572' bgcolor='#CCCCCC' height='13'>&nbsp;</td>
	  </tr>
	  </table>
	";
}

?>

 </td>
</tr>
</table>
</body>
</html>

<?php
  exit();
?>