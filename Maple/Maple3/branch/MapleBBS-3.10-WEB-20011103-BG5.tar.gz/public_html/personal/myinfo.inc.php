<?php
//modify ufile: myInfo

require_once('config.php');

unset($cuser);
session_start();

$pid = $cuser[pid];
$level = $cuser[level];
if(!$pid || !($level & PERM_BASIC)) {
	echo "<html>�Х��n��! <a href='personal.php'> [������^] </a></html>";
	exit; 
}

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

?>

<html>
<head>
<title>Modify My Info</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body bgcolor="#ffffff">
<table width="609" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="100%" align="center"><img src="images/myinfo.gif" border="0"></td>
  </tr>
  <tr> 
    <td width="100%" align="center"><hr size="2" noshade width="76%" color="#b751af"></td>
  </tr>

  <?php
  require_once('webbbs.class.php');

  
  $ws = new server_class;
  $ws->connect();
 
  if($submit && $realname && $passwd) {
	  
	  $cmd = $ws->set_cmd("modinfo", G_ACCT, $pid, $passwd);
	  $ws->send($cmd);
	  $data = $ws->recv(32);
	  $check = substr($data, 0, 2);
	  if($check == 'OK') {
		  $ws->send("NAME: $nickname\n");		/* nickname */
		  $ws->send("RNME: $realname\n");		/* realname */
		  $ws->send("ADDR: $address\n");		/* address	*/
		  $ws->send("\n");						/* tell end */
		  
		  $data = $ws->recv(128);				/* recv end */
		  $ws->close();							/* �[�Wclose�� */
		  
		  $check = $ws->parse($data);

		  print "
			  <tr><td align='center'> ".alertMsg($check[msg])."
			  <br><br><a href='$PHP_SELF?action=myinfo'>�����i�H�ֳt��^...</a>
			  </td></tr>
			  ";

	  } else {
		  print "
			  <tr><td align='center'> ".alertMsg($data)."
			  <br><br><a href='$PHP_SELF?action=myinfo'>�����i�H�ֳt��^...</a>
			  </td></tr>
			  ";
	  }
  } else {
	  //else
	  $cmd = $ws->set_cmd("modrqst", G_ACCT, $pid);
	  $ws->query($cmd);

	  $ret = $ws->parse();
	  if($ret[result] != "OK") {
		  $ws->alert($ws->data);
		  exit;
	  }

	  if(!$realname || $realname == '' ) $realname = $ret[realname];
	  if(!$nickname || $nickname == '' ) $nickname = $ret[nickname];
	  if(!$address || $address == '' ) $address = $ret[address];

	  if($submit) $alertMsg = "<font color=red><b>ĵ�i: ��g�����A����!</b></font>";
	  else $alertMsg = "";

	  print "
		  <tr> 
		   <form action='$PHP_SELF' method='post'>
		   <td width='100%' align='center'>
			<table width='76%' border='0' bgcolor='#f0f0f0' align='center' height='260'>
			 <tr><td> $alertMsg </td></tr>
			 <tr><td>�z���b��: $cuser[userid] </td></tr>
		     <tr><td>�z���ʺ�: <input type='text' size='18' name='nickname' value='$nickname'></td></tr>
		     <tr><td>�o���j�@: $ret[numposts] �g</td></tr>
		     <tr><td>�W������: $ret[numlogins] �� </td></tr>
		     <tr><td>���d�ɶ�: $ret[staytime] �p�� </td></tr>
		     <tr><td>�u��m�W: <input type='text' size='18' name='realname' value='$realname'> </td></tr>
		     <tr><td>�~���a�}: <input type='text' size='42' name='address' value='$address'> </td></tr>
		     <tr><td>�b���إ�: $ret[firstlogin] </td></tr>
		     <tr><td>�̪���{: $ret[lastlogin] </td></tr>
		     <tr><td>�W���ӷ�: $ret[lasthost] </td></tr>
		     <tr><td>�T�{�K�X: <input type='password' size='18' name='passwd'> </td></tr>
		    </table>
		   </td>
		  </tr>
		  <tr> 
		   <td width='100%' align='center'>
		   <input type='hidden' name='action' value='myinfo'>
		   <input type='submit' name='submit' value='�T�w�ק�'>
		   <input type='reset' name='reset' value='��_�ƾ�'>
		   </td>
		   </form>
		  </tr>
		  ";
  }
  ?>

  <tr> 
    <td width="100%" align="center"><hr size="2" noshade width="76%" color="#c0c0c0"></td>
  </tr>
</table>
</body>
</html>