<?php
//xchat.php ��ѫǤJ�f
require('config.php');

unset($cuser);
session_start();

?>
 
<html>
<head>
<title>XchatRoom</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<script language="JavaScript">
<!--
 function dosub()
 {
	 /*
	 var url = 'xchat/index.php?chatid='+document.xchat.chatid.value;	 
	 var prop = "toolbar=0,directories=0,scrollbars=1,location=0,status=0,menubar=0,top=0,left=0,resizable=1,width=760,height=550";
	 var chatwin = window.open(url, 'xchat', 'width=760, height=550');
	 chatwin.focus();
	 document.location = 'talk.php';
	 return false;
	 */
	 return true;
 }
//-->
</script>
</head>
<body bgcolor="#ffffff">
<table width="609" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="100%" align="center"><h3>WebBBS ��Ѽs���J�f</h3></td>
  </tr>
  <tr> 
    <td width="100%" align="center"><hr size="2" noshade width="76%" color="#b751af"></td>
  </tr>
  <tr> 
    <td width="100%" align="center">
	<?php
	
	$level = $cuser[level];
	if(!($level & PERM_CHAT)) {	/* �S����Ѫ��v���� */
		print "<b><font class='col131'>�z�S���i��ѫǪ��v��!</font></b><br>
			   �i��O�z�٨S���n�����٨S���q�L��������A�аѦ����U��������I
			  ";
	}
	else {
		print "
	<form action='chat_main.php' method='post' name='xchat' onsubmit='return dosub()'>
	�п�J��ѥN��: <input type='text' size='15' maxlength='15' name='chatid' value='$cuser[userid]'>
	<input type='submit' value='�}�l���'>
	</form>
			";
	}
	?>
	</td>
  </tr>
  <tr> 
    <td width="100%" align="center"><hr size="2" noshade width="76%" color="#c0c0c0"></td>
  </tr>
</table>
</body>
</html>