<?php
//�����o����J�ءI
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<script language=javascript>
<!--
var dx ='';
var max=10;
var sdx=new Array(max+1);
var whamsg=new Array(20+1);
var base=1;
var saybase=1;
var j,i=0;
var p=1;
var sayp=0;

for (j=1;j<=max+1;j++)sdx[j]='';sdx[0]="�Ҧ��H";
for (j=0;j<=max+1;j++)
  whamsg[j]='';
  
function addOne(what){
if (what ==''){
	return false;
}
  if (saybase<max+1) {
   whamsg[saybase]=what;
    saybase++;
  } else {
   for (i=0;i<max;i++)
    whamsg[i]=whamsg[i+1];
   whamsg[i]=what;
  }
  sayp=saybase;
 }

 function goPrev(theForm){
  if (sayp>0) sayp--;
   theForm.msg.value=whamsg[sayp];
  theForm.msg.focus();
 }
 function goNext(theForm){
  if (sayp<saybase) sayp++;
   theForm.msg.value=whamsg[sayp];
  theForm.msg.focus(); 
 }

function checksay( ){

	var check;

	if(document.inputform.msg.value==''){
		alert('�o�����e����');
		document.inputform.msg.focus();
		return false;
	}

	check = document.inputform.msg.value.substring(0, 2);
	if(check == '/b')
		parent.forceLeave = 0;
	document.inputform.message.value = document.inputform.msg.value;
	addOne(document.inputform.msg.value);
	document.inputform.msg.value ='';
	document.inputform.msg.focus();
	return(true);
}

/* do func */

function do_cmd(cmd)
{
	inputform.message.value='/'+cmd;
	inputform.onSubmit='return true';
	inputform.submit();
	inputform.msg.focus();
	return true;
}

function do_cmd2(cmd, prom)
{
	var xx=prompt(prom,'');
	if(cmd == 'b') parent.forceLeave = 0;
	if(xx=='' || xx==null && cmd != 'b') return;
	inputform.message.value='/'+cmd+' '+xx
	inputform.onSubmit='return true';
	inputform.submit();
	inputform.msg.focus();
	return true;
}

function do_cmd3(cmd, prom1, prom2)
{
	var xx=prompt(prom1,'');
	if(xx=='' || xx==null) return;
	var yy=prompt(prom2,'');
	if(yy=='' || xx==null) return;
	inputform.message.value='/'+cmd+' '+xx+' '+yy;
	inputform.onSubmit='return true';
	inputform.submit();
	inputform.msg.focus();
	return true;
}

function do_func(n) {
	if(n==0) return;
	if(n==1) return do_cmd('c');
	if(n==2) return do_cmd2('j', '�п�J�]�[�W�G');
	if(n==3) return do_cmd('w');
	if(n==4) return do_cmd('l');
	if(n==5) return do_cmd('r');
	if(n==6) return do_cmd3('m', '��ֻ�������?', '�����򤺮e?');
	if(n==7) return do_cmd2('n', '�n�令����W�r?');
	if(n==8) return do_cmd2('i', '�n�ܽн֨�?');
	if(n==9) return do_cmd2('a', '�n������ʧ@?');
	if(n==10) return do_cmd('/help');
	if(n==11) return do_cmd3('to', '�n��ֻ�?', '�����򤺮e?');
	if(n==12) return do_cmd2('ignore', '�n�L�o��?');
	if(n==13) return do_cmd2('unignore', '�n�����֪��L�o?');
	if(n==14) return do_cmd('t');
	if(n==15) return do_cmd2('q', '�n�d�ְ߽�?');
	if(n==16) return do_cmd('p');
	if(n==17) return do_cmd('h');
	if(n==18) return do_cmd2('b', '������d����?');

}
				
//-->
</script>
</head>
<body bgcolor="#ffffff" text="#0c0c0c" topmargin="0" marginwidth="0" marginheight="0">
 <table width="640" border="0" cellspacing="0" cellpadding="0" align="left" bgcolor="#efefef">
  <tr> 
  <form method="post" name="inputform" action="chat_doTalk.php" target="chatHidden" onsubmit="return(checksay());">
	<input type="hidden" name="message" value="">
    <td height="4"></td>
  </tr>
  <tr> 
    <td height="1"  bgcolor="#000000"></td>
  </tr>
    <tr>
  <tr> 
    <td width="100%" height="4"></td>
  </tr>
  <tr>
    <td>
	<span id="chatid"><?echo $chatid;?></span>: <input type="text" name="msg" maxlength="150" size="45">
		<input type="submit" name="Submit" value="�o�e" class="chatinput">
		<input type="button" value="&lt;&lt;" name="pre" class="chatinput" onclick="goPrev(document.inputform);">
		<input type="button" value="&gt;&gt;" name="nxt" class="chatinput" onclick="goNext(document.inputform);">
		<br> &nbsp;
	<input type='checkbox' name='as' checked=true onclick='top.mainFrame.scrollit();'>�۰ʺu��
	<select onChange='do_func(this.selectedIndex);this.selectedIndex=0;'>
		<option selected>��ѫǥ\��</option>
		<option>�M�ū̹�</option>
		<option>�إߩΥ[�J�]�[</option>
		<option>���]�[����</option>
		<option>�ݩҦ��ϥΪ�</option>
		<option>�C�X�@��]�[</option>
		<option>��������</option>
		<option>���ѥN��</option>
		<option>�ܽШϥΪ�</option>
		<option>���@�Ӱʧ@</option>
		<option>MUD-like�ʧ@</option>
		<option>��Y�H��</option>
		<option>�����ϥΪ�</option>
		<option>��������</option>
		<option>�}��������</option>
		<option>�d�ߺ���</option>
		<option>�����I�s��</option>
		<option>�ݬݩҦ����U</option>
		<option>�i�O��ѫ�</option>
		</select>
	<a href="talk.php" target="_parent">���}</a>
    </td>
 </tr>
</table>
</form>
</body>
</html>
