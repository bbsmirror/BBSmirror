<html>
<head>
<title>QueryForm</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body bgcolor="#ffffff">
<table width="609" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="100%" align="center"><img src="images/query.gif" border="0"></td>
  </tr>
  <tr> 
    <td width="100%" align="center"><hr size="1" noshade width="76%" color="#b751af"></td>
  </tr>
  <tr> 
    <td width="100%" align="center">
	<form action="query.php" method="post">
	�п�J�Τ�N��: <input type="text" size="15" maxlength="15" name="userid">
	<input type="submit" value="�T�w�d��">
	</form>
	</td>
  </tr>
  <tr> 
    <td width="100%" align="center"><hr size="1" noshade width="76%" color="#c0c0c0"></td>
  </tr>
</table>
</body>
</html>