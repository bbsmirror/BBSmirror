<html>
<head>
<title>Board List</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #00a000}
A:visited {color: #00a000}
</style>
</head>
<body leftmargin="3" topmargin="0" marginwidth="3" marginheight="0" bgcolor="#FFFFFF">
<table width="617" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td colspan="3"><img src="images/grp/grp_top.jpg" width="617" height="53" usemap="#Map" border="0"></td>
  </tr>
  <tr> 
    <td width="22" background="images/grp/grp_left_bg.jpg">&nbsp;</td>
    <td height="100%" width="577"><a href=xchat/xchatServer.php target=_blank>�س]��</a></td>
    <td background="images/grp/grp_right_bg.jpg" width="22">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="3" height="2"><img src="images/grp/grp_bottom.jpg" width="617" height="23"></td>
  </tr>
</table>
<map name="Map"> 
  <area shape="rect" coords="49,18,120,37" href="services.php" alt="���ȪA�Ȱ�" title="���ȪA�Ȱ�">
  <area shape="rect" coords="129,18,198,37" href="board.php" alt="�����U�j�Q�װ�" title="�����U�j�Q�װ�">
  <area shape="rect" coords="207,18,278,38" href="gem.php" alt="������ذ�" title="������ذ�">
  <area shape="rect" coords="286,19,358,37" href="personal.php" alt="�ڪ��ӤH�p�v" title="�ڪ��ӤH�p�v">
  <area shape="rect" coords="366,19,438,37" href="personal.php" alt="�ڪ��ӤH�p�v" title="�ڪ��ӤH�p�v">
</map>
</body>
</html>
