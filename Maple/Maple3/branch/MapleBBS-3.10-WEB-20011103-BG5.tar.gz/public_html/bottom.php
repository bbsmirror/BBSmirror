<html>
<head>
<script language="javascript">
<!--hide

var timerID = null;
var timerRunning = false;
function stopclock (){
  if(timerRunning)
    clearTimeout(timerID);
  timerRunning = false;
}

function showtime () {
  var now = new Date();
  var dates = now.getDate();
  var months = now.getMonth();
  var hours = now.getHours();
  var minutes = now.getMinutes();
  var seconds = now.getSeconds();
  var timeValue = " " + months + "��" + dates + "�� ";
  timeValue += hours; //" " + ((hours >12) ? hours -12 :hours);
  timeValue += ((minutes < 10) ? ":0" : ":") + minutes;
  timeValue += ((seconds < 10) ? ":0" : ":") + seconds;
  //timeValue += (hours >= 12) ? " �U�� " : " �W�� ";
  document.bottom.clock.value = timeValue;
  timerID = setTimeout("showtime()",1000);
  timerRunning = true;
}

function startclock () {
  stopclock();
  showtime();
}

function update_online(total, www)
{
	document.bottom.wwwCnt.value = www + "�H";
	document.bottom.totalCnt.value = total + "�H";
}

function update_userid(value)
{
	document.bottom.userid.value = value;
}

function new_mail(flag) // 1: new 0: none 
{
	if(flag)
		document.all.mail.innerHTML = "<a href='maillist.php' target='mainFrame'><font style='color: ffffff; background: aa0000; text-decoration: blink'>�l�t�ӤF!</font></a>";
	else
		document.all.mail.innerHTML = "";
}
//-->
</script>
<title>BottomFrame</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body onLoad="startclock()" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table border="0" width="649" cellspacing="0" cellpadding="0" bgcolor="#9CA4C8" align="left" height="21">
<tr><form name="bottom"><td align="left">
�ɶ�: <input type="text" size="18" name="clock"  align="center" value="" readonly="true" class="noboder">
�ڬO�G<input type="text" size="12" name="userid" align="center" value="guest" readonly="true" class="noboder">
WWW�b�u�G<input type="text" size="5" name="wwwCnt" align="center" value="128" readonly="true" class="noboder">
�`�b�u�G<input type="text" size="7" name="totalCnt" align="center" value="514" readonly="true" class="noboder">
<span id="mail"></span>
</td></form></tr>
</table>
</body>
</html>