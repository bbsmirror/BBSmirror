<?php
//UserSetup

require_once('config.php');

unset($cuser);
session_start();

$pid = $cuser[pid];
$level = $cuser[level];
if(!$pid || !($level & PERM_BASIC)) {
	echo "<html>�Х��n��! <a href='main.php'> [������^] </a></html>";
	exit; 
}

if(!$page) $page = 0;

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

function bflag($flag) {
	return (1 << $flag);
}

/* �]�w�Ҧ� */
$ufos = array(
     /* COLOR */ "�m��Ҧ�",
     /* MOVIE */ "�ʵe���",
     /* BRDNEW */ "�s�峹",
     /* BNOTE */ "��ܶi�O�e��",
     /* VEDIT */ "²�ƽs�边",

     /* PAGER */ "�����I�s��",
     /* QUITE */ "��������",
     /* PAL */ "�u��ܦn��",
     /* ALOHA */ "�n�ͤW���q��",

     /* MOTD */ "²�ƶi���e��",

     /* MPAGER */ "�q�l�l��ǩI",
     /* NWLOG */  "���x�s���T����",
     /* NTLOG */  "���x�s��Ѭ���",
     /* BROADCAST */  "�ڦ��s��",
     /* MESSAGE */"�����T����",
     /* HIDENFROM */ "���èӷ�",
     /* 16 */ "�O�d",
     /* 17 */ "�O�d",
     /* 18 */ "�O�d",
     /* CLOAK */ "�����N",
     /* ACL */ "ACL",
     /* SUPERCLOADK */ "�W������"
	 );

$level = $cuser[level];
if($level & PERM_SYSOP) $len = 22;
else if($level & PERM_ADMIN) $len = 21;
else if($level & PERM_CLOAK) $len = 20;
else $len = 16;

?>
 
<html>
<head>
<title>My Ufo Setup</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<script language="JavaScript">
<!--
//-->
</script>
</head>
<body bgcolor="#ffffff" leftmargin="3" topmargin="0" marginwidth="3" marginheight="0">
<table width="635" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="55" align="center"> ������a WebBBS �ӤH�ѼƳ]�w!  �Τ�: <?echo $cuser[userid];?> </td>
  </tr>
  <tr>
    <td valign="top" align="center">
	<hr size="2" color="green" noshade width="95%">
	<?php
	//maillist
	require_once('webbbs.class.php');
	
	$ws = new server_class;	
	$ws->connect();
	if(!isset($submit)) {
		$cmd = $ws->set_cmd("ufosetup", G_ACCT, $pid, -1);
		$ws->query($cmd);
		$ret = $ws->parse();
		if($ret[result] != 'OK') {
			echo "<br><br>";
			echo alertMsg($ws->data);
			echo "<br><br><a href='personal.php'>[������^]</a>";
			exit;
		}

		print "
			<table border='0' width='95%'>
			<tr><form action='$PHP_SELF' method='post'>
			<td colspan='2'>
				<font size='3' color='green'>�� �ӤH�ѼƳ]�w </font>(�o�ǮĪG�j���btelnet�U�~����)
			</td></tr>
			";
		for($i=0; $i<$len; $i++) {
			$check1 = $check2 = "";
			$name1 = $name2 = "";
			$bit1 = $bit2 = 0;
			$string1 = $string2 = "";

			$name1 = "u".$i;
			$bit1 = bflag($i);
			$string1 = $ufos[$i];

			$i++;
			$name2 = "u".$i;
			$bit2 = bflag($i);
			$string2 = $ufos[$i];

			if($ret[ufo] & $bit1) $check1 = " checked";
			if($ret[ufo] & $bit2) $check2 = " checked";

			print "
				<tr>
				<td><input type='checkbox' name='$name1' value='1'".$check1."> ".$string1." </td>
				<td><input type='checkbox' name='".$name2."' value='1'".$check2."> ".$string2." </td>
				</tr>
				";
		}
		print "
			<tr><td colspan='2' align='center'>
			<input type='hidden' name='ufo' value='$ret[ufo]'>
			<input type='hidden' name='ufo1' value='$ret[ufo1]'>
			<input type='submit' name='submit' value='�T�w�ק�'>
			<input type='reset' name='reset' value='��_���]'>
			</td></tr>
			</form>
			</table>
			";

	} else {
		// �B�z��...
		for($i=0; $i<$len; $i++) {
			$name = "u".$i;
			$bit = bflag($i);

			if(intval($$name) == 1) {
				$ufo |= $bit;
				$ufo1 |= $bit;
			} else {
				$ufo &= ~$bit;
				$ufo1 &= ~$bit;
			}
		}
		// ��!!!
		$cmd = $ws->set_cmd("ufosetup", G_ACCT, $pid, $ufo, $ufo1);
		$ws->query($cmd);
		$ret = $ws->parse();
		if($ret[result] != 'OK')
			$data = $ws->data;
		else
			$data = $ret[msg];
		
		echo "<br><br>";
		echo alertMsg($data);
		echo "<br><br><a href='personal.php'>[������^]</a>";
		exit;
	}
	?>
	<hr size="2" color="c0c0c0" noshade width="95%">
	</td>
  </tr>
</table>
</body>
</html>