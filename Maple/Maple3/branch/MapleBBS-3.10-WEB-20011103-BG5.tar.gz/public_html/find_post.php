<?php
//�d��Q�װ�
if(!$pid) {
	unset($cuser);
	session_start();
	$pid = $cuser[pid];
}

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

for($i = 1; $i <= 300; $i++ ) print (" ");
//important
?>

<html>
<head>
<title>FindPost</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #000088}
A:visited {color: #000099}
</style>
</head>
<body bgcolor="#ffffff">
<table width="609" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="100%" align="center"><img src="images/find_post.gif" alt="�峹�d��" width="289" height="55" border="0"></td>
  </tr>
  <tr> 
    <td width="100%" align="center"><hr size="1" noshade width="95%" color="#b751af"></td>
  </tr>
  <tr> 
    <td width="100%" align="center">
	<?php
	if($title == "" && $author == "") {

		if(isset($submit))
			echo "<br><br>".alertMSG("���D/�@�̦ܤ֭n��@��!")."<br>";
		print "
			<table width=70% border=0>
			<form action=".$PHP_SELF." method=post>
			";
		if(!isset($day)) $day = 7;
		if($board == "NULL") unset($board);

		if(!isset($board))
			print "<input type=hidden name=board value='NULL'>\n";
		else
			print "<tr><td>�Ҧb�ݪO: </td><td><input size=18 type=text value='$board' name=board readonly></td></tr>\n";
		print "
			<tr><td>�峹�@��: </td><td><input maxlength=12 size=12 type=text name=author value='".$author."'> (����d��Ҧ��@��)</td></tr>
			<tr><td>���D�t��: </td><td><input maxlength=30 size=20 type=text name=title value='".$title."'> AND <input maxlength=60 size=20 type=text name=title2 value='".$title2."'></td></tr>
			<tr><td>���D���t: </td><td><input maxlength=30 size=20 type=text name=title3 value='".$title3."'></td></tr>
			<tr><td>�d��̪�: </td><td><input maxlength=5 size=5 type=text name=day value='".$day."'> �ѥH�����峹</td></tr>
			<tr><td colspan=2 align=center> <input type=hidden name=pid value=".$pid.">
			<input type=submit name=submit value=�T�w�d��>
			</form></td></tr>
			</table>
			";
	} else {
		require_once("webbbs.class.php");
		require_once("config.php");
		require_once("ansi2web.inc.php");

		$ws = new server_class;
		$ws->connect();
		if($day <=0) $day =7;
		if($author == "") $author = "NULL";
		if($title == "") $title = "NULL";
		if($title2 == "") $title2 = "NULL";
		if($title3 == "") $title3 = "NULL";

		$cmd = $ws->set_cmd("searchpost", G_BOARD, $pid, $board, $day, $author, $title, $title2, $title3);
		$ws->send($cmd);

		$data = $ws->recv(128);
		$ret = $ws->parse($data);

		if($ret[result] != 'OK') {
			echo "<br><br>\n";
			echo alertMsg($data);
			echo "<br><br>\n";
		} else {

			if($ret[board] == "NULL") $ret[board] = "�Ҧ��ݪO";

			print "
				<table border=0 width=95% align=center>
				<tr><td colspan=5 align=left>
				  ���D�t�� <font color=red>".$ret[title]."</font> AND <font color=red>".$ret[title2]."</font>
				  ���t <font color=red>".$ret[title3]."</font><br>
				  �Ҧb�ݪO <font color=red>".$ret[board]."</font>
				  �峹�@�� <font color=red>".$ret[author]."</font>
				  �ɶ����� <font color=red>".$ret[day]."</font> �� <br><br>
				</td></tr>
				";
			print "
				<tr bgcolor=#efefef height=20> 
				<td width=40> �s�� </td><td width=10> </td><td width=40> ��� </td>
				<td width=70> �@�� </td><td width=340> ���D </td>
				</tr>
				";
			
			flush();
			$currboard = $board;
			$no = 1;

			while($data = $ws->recv(256)) {
				if(intval($data) == -1)
					break;

				$tmp = $ws->parse($data);
				if(intval($tmp[num]) == -1) {
					$currboard = $tmp[brd];
					continue;
				}

				else if($tmp[num] <= 0) {
					print "
						<tr><td colspan=5 bgcolor=#efefef height=20><font size=2> $data </font></td></tr>
					";
					flush();
					continue;
				} else {
					if(strlen($tmp[title]) > 42) {
						$tmp[title] = substr($tmp[title], 0, 39);
						$tmp[title] .= "...";
					}
					
					$tmp[title] = str_replace(" ", "&nbsp;", $tmp[title]);

					$tmp[size] = intval($tmp[size] / 2);
					$tmp[size] = "<font size=1 color=#008080>(".$tmp[size]."�r)</font>";

					$tmp[attr] = ansi2web($tmp[attr]);
					$submitUrl = "find_result_read.php?board=$currboard&num=$tmp[num]";
					print "
						<tr>
						<td align=center> $tmp[num] </td>
						<td> $tmp[attr] </td>
						<td> $tmp[date]</td>
						<td> <a href='query.php?userid=$tmp[author]'>$tmp[author]</a> </td>
						<td> <a href='$submitUrl'>$tmp[type] $tmp[title]</a> </td>
						</tr>
					";
					flush();
					//$no++;
				}
			}

			print "</table>\n";
		}
	}
	?>
	</td>
  </tr>
  <tr> 
    <td width="100%" align="center"><hr size="1" noshade width="95%" color="#c0c0c0"></td>
  </tr>
</table>
</body>
</html>