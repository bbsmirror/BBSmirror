<?php
//Read Pal List

require_once('config.php');

unset($cuser);
session_start();

$pid = $cuser[pid];
$level = $cuser[level];
if(!$pid || !($level & PERM_BASIC)) {
	echo "<html>�Х��n��! <a href='main.php'> [������^] </a></html>";
	exit; 
}

if(!$page) $page = 0;

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

?>
 
<html>
<head>
<title>MyPalList</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<script language="JavaScript">
<!--
function goto(page){
	var pid = "<?echo $pid;?>";
	var check = "<?echo $page;?>";
	if(check != page)
	document.location = "pal_list.php?page="+page;
}
//-->
</script>
</head>
<body bgcolor="#ffffff" leftmargin="3" topmargin="0" marginwidth="3" marginheight="0">
<table width="635" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="55" align="center"><img src="images/pal.gif" width="289" height="55" border="0"></td>
  </tr>
  <tr>
    <td valign="top" align="center">
	<hr size="2" color="green" noshade width="95%">
	<?php
	//maillist
	require_once('webbbs.class.php');
	
	$ws = new server_class;
	$ws->connect();

	$cmd = $ws->set_cmd("flist", G_TALK, $pid, $page);
	$ws->query($cmd);

	$list = split("\n", $ws->data); /* ���ӪŮ�@�j�} */
	$ret = $ws->parse($list[0]);
	if($ret[result] != 'OK') {
		echo "<br><br>";
		echo alertMsg($ws->data);
		echo "<br><br><a href='talk.php'>[������^]</a>";
		exit;
	}
	
	$totalpage = intval($ret[max]/XO_TALL);  /* 20�OXo_TALL���� */
	if($ret[max] % XO_TALL) $totalpage ++;
	
	$page = intval($ret[page]);
	if($page > $totalpage) $page = $totalpage;
	
	$gotoString .= "�n�ͦW��: �@ $ret[max] �� �� <font color='a00000'>$page</font> / $totalpage ��";
	$gotoString .= " | �����<select onchange='goto(this.options[this.selectedIndex].value)' style='font-size: 9pt; height: 16'>";
	
	for($i=1; $i<=$totalpage; $i++) {
		$gotoString .= "<option value='$i'";
		if($i == $page) $gotoString .= " selected";
		$gotoString .= ">".$i."</option>\n";
	}
	
	$gotoString .= " </select>��";
	
	if($page > 1) {
		$prev = $page-1;
		$gotoString .= " | <a href=\"$PHP_SELF?page=$prev\">�W�@��</a>";
	}

	if($totalpage - $page > 0) {
		$next = $page+1;
		$gotoString .= " | <a href=\"$PHP_SELF?page=$next\">�U�@��</a>";
	}

	$gotoString .= " | <a href='pal_sort.php'>�W���z</a>";
	$gotoString .= " | <a href='pal_add.php'>�W�[�n��</a>";

	//start to show
	print "<table width='95%' border='0' cellspacing='0' cellpadding='0' align='center'>\n";
	print "
		<tr bgcolor='#dddddd'>
		<td colspan=5>
		 $gotoString
        </td></tr>
		";
		
	print "
		<tr height=20>
		<td width=40>�Ǹ�</td>
		<td width=12></td>
		<td width=90>�N��</td>
		<td width=400>�ͽ˴y�z</td>
		<td width=90>�\��ﶵ</td>
		</tr>
		";
		
	for($i=1; $i<= XO_TALL; $i++) {
	//for($i=XO_TALL; $i>0; $i--) {
		if($i%2)
			$bgcolor = "#efefef";
		else
			$bgcolor = "#fefefe";
		
		$tmp = $ws->parse($list[$i]);
		
		if($tmp[num] <= 0) 
			break;
		
		if(intval($tmp[ftype]) == 1) {
			$ftype = "X";
		} else {
			$ftype = "";
		}

		$otherstr  = "<a href='pal_edit.php?num=$tmp[num]&userid=$tmp[userid]'>�ק�</a>";
		$otherstr .= "|<a href='pal_delete.php?num=$tmp[num]'>�R��</a>";

		print "
		   <tr bgcolor=$bgcolor height=20>
			<td> $tmp[num] </td>
			<td> $ftype </td>
			<td> <a href='query.php?userid=$tmp[userid]'>$tmp[userid]</a> </td>
			<td> $tmp[ship] </td>
			<td> $otherstr </td>
		   </tr>
			";
	}
	
	print "
		<tr bgcolor='#dddddd'>
		<td colspan=5>
		 $gotoString
        </td></tr>
		";

	echo "</table>\n";

	?>
	<hr size="2" color="c0c0c0" noshade width="95%">
	</td>
  </tr>
</table>
</body>
</html>