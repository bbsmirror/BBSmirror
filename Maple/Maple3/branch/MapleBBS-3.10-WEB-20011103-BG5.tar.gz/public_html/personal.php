<?php

/* �Y���ʧ@ */
if($action) {
	@include_once('personal/'.$action.'.inc.php');
	exit;
}

?>
<html>
<head>
<title>TalkPage</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #1565ab}
A:visited {color: #1565ab}
</style>
</head>
<body leftmargin="3" topmargin="0" marginwidth="3" marginheight="0" bgcolor="#FFFFFF">
<table width="614" border="0" cellspacing="0" cellpadding="0" align="left">
  <tr> 
    <td colspan="3"><img src="images/personal/personal_top.jpg" width="614" height="50" usemap="#Map" border="0"></td>
  </tr>
  <tr> 
    <td width="14" background="images/personal/personal_left_bg.jpg">&nbsp;</td>
    <td height="300" width="586">
      <table width="76%" border="0" cellspacing="0" cellpadding="0" height="250">
        <tr> 
          <td rowspan="8" align="center" width="11%">&nbsp;</td>
          <td width="25%"><b><a href="personal.php?action=plans" style="font-size: 12pt">�ڪ��W��</a></b></td>
          <td width="64%"><font size="2" color="#666666">�d�ߡA�s�קڦۤv���W����� </font></td>
        </tr>
        <tr> 
          <td width="25%"><b><a href="personal.php?action=myinfo" style="font-size: 12pt">�ڪ����</a></b></td>
          <td width="64%"><font size="2" color="#666666"> �ڪ��ӤH�p�ɮ�...:D </font></td>
        </tr>
        <tr> 
          <td width="25%"><b><a href="personal.php?action=sign" style="font-size: 12pt">�ڪ�ñ�W</a></b></td>
          <td width="64%"><font size="2" color="#666666">�}�}�G�G��ñ�W��... </font></td>
        </tr>
        <tr> 
          <td width="25%"><b><a href="personal.php?action=passwd" style="font-size: 12pt">�ڪ��K�X</a></b></td>
          <td width="64%"><font size="2" color="#666666">�ڪ��i���K�X... </font></td>
        </tr>
        <tr> 
          <td width="25%"><b><a href="maillist.php" style="font-size: 12pt">�ڪ�BBS�H�c</a></b></td>
          <td width="64%"><font size="2" color="#666666">�ڪ�BBS�W���p�H�H��.... </font></td>
        </tr>
        <tr> 
          <td width="25%"><b><a href="personal.php?action=buf" style="font-size: 12pt">�ڪ��ɮ�</a></b></td>
          <td width="64%"><font size="2" color="#666666">�ڪ��T�ӼȦs�ɮ��d�� </font></td>
        </tr>
        <tr> 
          <td width="25%"><b><a href="usetup.php" style="font-size: 12pt">�ڪ��ӤH�w��</a></b></td>
          <td width="64%"><font size="2" color="#666666">���Ǧۤv�����n�]�w�� </font></td>
        </tr>
        <tr> 
          <td width="25%"><b><a href="#personal.php?action=homepage" style="font-size: 12pt">�ڪ��D��</a></b></td>
          <td width="64%"><font size="2" color="#666666">�ڪ�homepage��.... </font></td>
        </tr>
      </table>		
	</td>
    <td background="images/personal/personal_right_bg.jpg" width="18">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="3" height="2"><img src="images/personal/personal_bottom.jpg" width="614" height="24"></td>
  </tr>
</table>
<map name="Map"> 
  <area shape="rect" coords="47,16,117,36" href="services.php" alt="���Ȩt�ΪA�Ȱ�" title="���Ȩt�ΪA�Ȱ�">
  <area shape="rect" coords="126,17,196,37" href="board.php" alt="�����U�j�ݪO" title="�����U�j�ݪO">
  <area shape="rect" coords="205,16,275,36" href="gem.php" alt="������ؤ�����" title="������ؤ�����">
  <area shape="rect" coords="416,18,487,37" href="talk.php" alt="�𶢲�Ѱ�" title="�𶢲�Ѱ�">
  <area shape="rect" coords="496,17,566,36" href="group.php" alt="�ڪ��s�ե\��" title="�ڪ��s�ե\��">
</map>
</body>
</html>