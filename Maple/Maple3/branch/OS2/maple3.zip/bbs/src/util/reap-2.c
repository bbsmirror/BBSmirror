/*-------------------------------------------------------*/
/* util/reaper.c	( NTHU CS MapleBBS Ver 3.00 )	 */
/*-------------------------------------------------------*/
/* target : �ϥΪ̱b���w���M�z				 */
/* create : 95/03/29				 	 */
/* update : 97/03/29				 	 */
/*-------------------------------------------------------*/
/* syntax : reaper					 */
/*-------------------------------------------------------*/
/* notice : ~bbs/usr/@/     - expired users's data	 */
/*	    run/reaper.log  - list of expired users	 */
/*	    run/manager.log - list of managers		 */
/*-------------------------------------------------------*/


#include <stdio.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <dirent.h>
#include <errno.h>
#include <string.h>

#include "config.h"
#include "struct.h"
#include "perm.h"


#define	VACATION


#define DAY_NEWUSR	10	/* login ���W�L 3 �� */
#define DAY_FORFUN	80	/* �����������{�� */
#define DAY_OCCUPY	90	/* �w���������{�� */


static time_t due_newusr;
static time_t due_forfun;
static time_t due_occupy;


static int visit;
static int prune;
static int manager;
static int invalid;


static FILE *flog;
static FILE *flst;


/* ----------------------------------------------------- */
/* ----------------------------------------------------- */


static int funo;
static int max_uno;
static SCHEMA schema;


static void
userno_free(uno)
  int uno;
{
  off_t off;
  int fd;

  fd = funo;
  flock(fd, LOCK_EX);
  time(&schema.uptime);
  off = (uno - 1) * sizeof(schema);
  if (lseek(fd, off, SEEK_SET) < 0)
    exit(2);
  if (write(fd, &schema, sizeof(schema)) != sizeof(schema))
    exit(2);
  flock(fd, LOCK_UN);
}


/* ----------------------------------------------------- */
/* ----------------------------------------------------- */


static void
levelmsg(str, level)
  char *str;
  int level;
{
  static char perm[] = "bctpjm#x--------PTC---L*B#--ACBS";
  int len = 32;
  char *p = perm;

  do
  {
    *str = (level & 1) ? *p : '-';
    p++;
    str++;
    level >>= 1;
  } while (--len);
  *str = '\0';
}


static void
datemsg(str, chrono)
  char *str;
  time_t *chrono;
{
  struct tm *t;

  t = localtime(chrono);
  sprintf(str, "%2d/%02d/%02d%3d:%02d:%02d ",
    t->tm_year, t->tm_mon + 1, t->tm_mday,
    t->tm_hour, t->tm_min, t->tm_sec);
}


/* ----------------------------------------------------- */
/* ----------------------------------------------------- */


static void
reaper(fpath, lowid)
  char *fpath;
  char *lowid;
{
  int fd, login;
  usint ulevel;
  time_t life;
  char buf[256], data[40];
  ACCT acct;

  sprintf(buf, "%s/.ACCT", fpath);
  fd = open(buf, O_RDONLY, 0);
  if (fd < 0)
    return;

  read(fd, &acct, sizeof(acct));
  close(fd);

  fd = acct.userno;

  if ((fd <= 0) || (fd > max_uno))
  {
    fprintf(flog, "%5d) %-13s ==> %s\n", fd, acct.userid, buf);
    return;
  }

  ulevel = acct.userlevel;
  life = acct.lastlogin;
  login = acct.numlogins;

  if (ulevel & (PERM_XEMPT | PERM_BM | PERM_ACCOUNTS | PERM_CHATROOM | PERM_BOARD | PERM_SYSOP))
  {
    datemsg(buf, &acct.lastlogin);
    levelmsg(data, ulevel);
    fprintf(flst, "%5d) %-13s%s[%s] %d\n", fd, acct.userid, buf, data, login);
    manager++;
  }
  else if (ulevel)	/* guest.ulevel == 0, �û��O�d */
  {
    if (login <= 3 && life < due_newusr)
      life = 0;

#ifdef	VACATION
    if (life < due_occupy)
      life = 0;
#else
    if (ulevel & PERM_VALID)
    {
      if (life < due_occupy)
	life = 0;
    }
    else
    {
      if (life < due_forfun)
	life = 0;
      else
	invalid++;
    }
#endif

    if (!life)
    {
      sprintf(buf, "usr/@/%s", lowid);
      if (rename(fpath, buf))
      {
	extern int errno;

	fprintf(flog, "rename %s ==> %s : %d\n", fpath, buf, errno);
	fclose(flog);
	exit(1);
      }
      userno_free(fd);
      datemsg(buf, &acct.lastlogin);
      fprintf(flog, "%5d) %-13s%s%d\n", fd, acct.userid, buf, login);
      prune++;
    }
  }

  visit++;
}


static void
traverse(fpath)
  char *fpath;
{
  DIR *dirp;
  struct dirent *de;
  char *fname, *str;

  /* visit the second hierarchy */

  if (!(dirp = opendir(fpath)))
  {
    fprintf(flog, "## unable to enter hierarchy [%s]\n", fpath);
    return;
  }

  for (str = fpath; *str; str++);
  *str++ = '/';

  while (de = readdir(dirp))
  {
    fname = de->d_name;
    if (fname[0] > ' ' && fname[0] != '.')
    {
      strcpy(str, fname);
      reaper(fpath, fname);
    }
  }
  closedir(dirp);
}


main()
{
  int ch;
  time_t start, end;
  struct stat st;
  char *fname, fpath[256];

  setuid(BBSUID);
  setgid(BBSGID);
  chdir(BBSHOME);

  flog = fopen("run/reaper.log", "w");
  if (flog == NULL)
    exit(1);

  flst = fopen("run/manager.log", "w");
  if (flst == NULL)
    exit(1);

  funo = open(".USR", O_WRONLY | O_CREAT, 0600);
  if (funo < 0)
    exit(1);

  /* ���]�M���b�������A�s���U�H�Ƥ��|�W�L 300 �H */

  fstat(funo, &st);
  max_uno = st.st_size / sizeof(SCHEMA) + 300;

  time(&start);

  due_newusr = start - DAY_NEWUSR * 86400;
  due_forfun = start - DAY_FORFUN * 86400;
  due_occupy = start - DAY_OCCUPY * 86400;

  strcpy(fname = fpath, "usr/@");
  mkdir(fname, 0700);
  fname = (char *) strchr(fname, '@');

  /* visit the first hierarchy */

  for (ch = 'a'; ch <= 'z'; ch++)
  {
    fname[0] = ch;
    fname[1] = '\0';
    traverse(fpath);
  }

  close(funo);

  fprintf(flst, "\nManager: %d\n", manager);
  fclose(flst);

  time(&end);
  fprintf(flog, "\n\n# start: %s", ctime(&start));
  fprintf(flog, "\n# end  : %s", ctime(&end));
  end -= start;
  start = end % 60;
  end /= 60;
  fprintf(flog, "# time : %d:%d:%d\n", end / 60, end % 60, start);
  fprintf(flog, "# Visit: %d\n", visit);
  fprintf(flog, "# Prune: %d\n", prune);
  fprintf(flog, "# Valid: %d\n", invalid);
  fclose(flog);
  exit(0);
}
