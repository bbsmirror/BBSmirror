/*-------------------------------------------------------*/
/* util/authd.c	( NTHU CS MapleBBS Ver 3.00 )		 */
/*-------------------------------------------------------*/
/* target : RFC931 Authentication Daemon		 */
/* create : 98/01/01				 	 */
/* update : 98/01/01				 	 */
/*-------------------------------------------------------*/
/* syntax : authd					 */
/*-------------------------------------------------------*/


#include <stdio.h>
#include <ctype.h>
#include <fcntl.h>
#include <malloc.h>
#include <nlist.h>
#include <pwd.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/user.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/socketvar.h>


#define KERNEL
#define KERNEL_FEATURES
#include <sys/file.h>
#undef KERNEL
#undef KERNEL_FEATURES


#include <net/if.h>
#include <net/route.h>
#include <netinet/in.h>
#include <netinet/in_pcb.h>
#include <netinet/ip_var.h>
#include <netinet/tcp.h>
#include <netinet/tcp_timer.h>
#include <netinet/tcp_var.h>


#define VMUNIX  "/vmunix"
#define KMEM    "/dev/kmem"
#define N_FILE 0
#define N_NFILE 1
#define N_TCB 2


#define AUTH_PORT	113
#define AUTH_HOME	"/home/bbs"
#define	AUTH_PIDFILE	"run/auth.pid"


/* ----------------------------------------------------- */
/* authentication routines				 */
/* ----------------------------------------------------- */


static struct nlist nl[] = {

#ifdef SYS5_KERNEL
  {"file"},
  {"v"},
  {"tcb"},
#else
  {"_file"},
  {"_nfile"},
  {"_tcb"},
#endif
  {0}
};


static void
auth(fk, ans, faddr, fport, lport)
  int fk;
  char *ans;
  unsigned long faddr;
  int fport, lport;
{
  struct inpcb tcb;
  struct ucred ucb;
  struct file *fptr;
  struct socket *sockp;
  int i, val, head;

  sprintf(ans, "%d, %d: ERROR: NO-USER\r\n", lport, fport);

  /* TCP PCB list */

#define	k_get(addr, buf, len)	\
  if ((lseek(fk, addr, 0) == -1) || (read(fk, buf, len) < len))	\
    return;

  head = nl[N_TCB].n_value;
  k_get(head, &tcb, sizeof(tcb));
  tcb.inp_prev = (struct inpcb *) head;

  for (;;)
  {
    int next;

    if (tcb.inp_faddr.s_addr == faddr && tcb.inp_fport == fport &&
      tcb.inp_lport == lport)
      break;

    if ((next = (int) tcb.inp_next) == head)
      return;

    k_get(next, &tcb, sizeof(tcb));
  }

  /* file descriptor table */

  k_get(nl[N_NFILE].n_value, &val, sizeof(val));
  i = val;
  if (!(fptr = malloc(head = sizeof(struct file) * i)))
    return;

  k_get(nl[N_FILE].n_value, &val, sizeof(val));
  k_get(val, fptr, head);

  /* Locate the file descriptor that has the socket in question */

  sockp = tcb.inp_socket;

  for (; --i >= 0; fptr++)
  {
    if (fptr->f_count && fptr->f_type == DTYPE_SOCKET &&
      ((struct socket *) fptr->f_data == sockp))
    {
      struct passwd *pwp;

      k_get(fptr->f_cred, &ucb, sizeof(ucb));

      if (pwp = getpwuid(ucb.cr_ruid))
      {
      sprintf(ans, "%d, %d: USERID: UNIX: %s\r\n",
	lport, fport, pwp->pw_name);
      }

	break;
    }
  }

#undef	k_get(addr, buf, len)
}


int
main()
{
  int sock, val, fd, fk;
  struct sockaddr_in sin;
  char *str, buf[256];
  struct linger ld;

  /* --------------------------------------------------- */
  /* detatch & daemonize				 */
  /* --------------------------------------------------- */

  close(2);
  close(1);
  close(0);

  if (fork())
    exit(0);

  setsid();

  if (fork())
    exit(0);

  /* --------------------------------------------------- */
  /* bind socket to the server port			 */
  /* --------------------------------------------------- */

  sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if (sock != 0)
    dup2(sock, 0);

  val = 1;
  setsockopt(0, SOL_SOCKET, SO_REUSEADDR, (char *) &val, sizeof(val));

  setsockopt(0, SOL_SOCKET, SO_KEEPALIVE, (char *) &val, sizeof(val));

  ld.l_onoff = ld.l_linger = 0;
  setsockopt(0, SOL_SOCKET, SO_LINGER, (char *) &ld, sizeof(ld));

  sin.sin_family = AF_INET;
  sin.sin_port = htons(AUTH_PORT);
  sin.sin_addr.s_addr = htonl(INADDR_ANY);
  memset(sin.sin_zero, 0, sizeof(sin.sin_zero));

  if (bind(0, &sin, sizeof(sin)) || listen(0, 3))
    exit(1);

  if (nlist(VMUNIX, nl) || ((fk = open(KMEM, O_RDONLY)) == -1))
    exit(1);

  sigblock(sigmask(SIGPIPE) | sigmask(SIGURG));

  /* --------------------------------------------------- */
  /* give up priviledge					 */
  /* --------------------------------------------------- */

  str = buf;
  chdir(AUTH_HOME);

#if 0
#include "config.h"

  setgid(BBSGID);
  setuid(BBSUID);
#endif

  fd = open(AUTH_PIDFILE, O_WRONLY | O_CREAT | O_TRUNC, 0600);
  if (fd >= 0)
  {
    sprintf(str, "%d\n", getpid());
    write(fd, str, strlen(str));
    close(fd);
  }

  /* --------------------------------------------------- */
  /* server loop					 */
  /* --------------------------------------------------- */

  for (;;)
  {
    /* reaper child process */

    if (waitpid(-1, NULL, WNOHANG | WUNTRACED) > 0)
      continue;

    /* accept the request */

    val = sizeof(sin);
    sock = accept(0, &sin, &val);
    if (sock < 0)
      continue;

    if (!fork())
    {
      int lport, rport;

      close(0);

      val = 1;
      setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, (char *) &val, sizeof(val));

      if ((recv(sock, str, sizeof(buf), 0) > 0) &&
       (sscanf(str, "%d,%d", &lport, &rport) == 2) &&
	lport > 0 && lport < 65536 && rport > 0 && rport < 65536)
      {
        auth(fk, str, sin.sin_addr.s_addr, htons(rport), htons(lport));
        send(sock, str, strlen(str), 0);
      }
      shutdown(sock, 2);
      close(sock);
      exit(0);
    }
    else
    {
      close(sock);
    }

    /* tail of main loop */
  }
}
