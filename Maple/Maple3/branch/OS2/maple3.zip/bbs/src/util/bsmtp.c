/*-------------------------------------------------------*/
/* util/bsmtp.c		( NTHU CS MapleBBS Ver 3.00 )	 */
/*-------------------------------------------------------*/
/* target : deliver mail to smtp host for bbs	 	 */
/* create : 95/03/29				 	 */
/* update : 97/03/29				 	 */
/*-------------------------------------------------------*/
/* syntax : bdeliver [smtp_host]			 */
/*-------------------------------------------------------*/


#include "bbs.h"


#include <sys/wait.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <netdb.h>


#define SMTP_PORT	25
#define	SMTP_HOST	"mbox.cs.nthu.edu.tw"


#define	DEBUG


#define	TCP_BUFSIZ	2048	/* 4096 */
#define	TCP_LINSIZ	256


#define	TCP_READ	0
#define	TCP_WRITE	1


#define	MAIL_XMIT	"run/.MX"
#define	MAIL_UUFILE	"run/.Mu"
#define	MAIL_LOGFILE	"run/bsmtp.old"
#define	MAIL_POOLSIZE	65536


static int msize, mleng;
static char *mpool;


/* ----------------------------------------------------- */
/* operation log and debug information			 */
/* ----------------------------------------------------- */


static int flog;		/* log file descriptor */


static void
logit(msg)
  char *msg;
{
  time_t now;
  struct tm *p;
  char buf[256];

  time(&now);
  p = localtime(&now);
  sprintf(buf, "%02d/%02d %02d:%02d:%02d %s\n",
    p->tm_mon + 1, p->tm_mday,
    p->tm_hour, p->tm_min, p->tm_sec, msg);
  write(flog, buf, strlen(buf));
}


static void
log_init()
{
  flog = open(MAIL_LOGFILE, O_WRONLY | O_CREAT | O_APPEND, 0644);

#ifdef	DEBUG
  logit("START");
#endif
}


static void
log_close()
{
  close(flog);
}


/* ----------------------------------------------------- */
/* buffered TCP I/O routines				 */
/* ----------------------------------------------------- */


static int tcp_pos;
static char tcp_pool[TCP_BUFSIZ];


static int
tcp_wait(sock, mode)
  int sock;
  int mode;
{
  fd_set fset, xset, *rptr, *wptr;
  struct timeval tv;

  FD_ZERO(&fset);
  FD_ZERO(&xset);
  FD_SET(sock, &fset);
  FD_SET(sock, &xset);
  tv.tv_sec = 240;
  tv.tv_usec = 0;

  if (mode == TCP_WRITE)
  {
    rptr = NULL;
    wptr = &fset;
  }
  else
  {
    wptr = NULL;
    rptr = &fset;
  }

  if (select(sock + 1, rptr, wptr, &xset, &tv) <= 0)
  {
    logit("timeout: " SMTP_HOST);
    return -1;
  }

  if (FD_ISSET(sock, &xset))
  {
    logit("except: " SMTP_HOST);
    return -1;
  }

  return 0;
}


static int			/* return 0 for success */
xwrite(fd, data, size)
  int fd;
  char *data;
  int size;
{
  int len, try;

  if (tcp_wait(fd, TCP_WRITE))
    return -1;

  try = 0;
  while (size > 0)
  {
    len = write(fd, data, size);
    if (len <= 0)
    {
      sleep(5);			/* retry 12 turns & 60 sec. */
      if (++try < 12)
	continue;
      break;
    }
    data += len;
    size -= len;
  }
  return size;
}


static int
tcp_command(sock, cmd, code)
  register int sock;
  register char *cmd;
  register int code;		/* expected return value, 3-letter "220" */
{
  register int len, ret;
  char buf[1024];

  if (cmd != NULL)
  {
    len = strlen(cmd);
    if (tcp_wait(sock, TCP_WRITE))
      return -1;

    ret = write(sock, cmd, len);
    if (ret < len)
    {
      logit("Error in write() to SMTP host");
      return -1;
    }
  }

  if (tcp_wait(sock, TCP_READ))
    return -1;

  cmd = buf;
  len = read(sock, cmd, sizeof(buf));

  if (len < 3)
  {
    logit("Error in read() from SMTP host");
    return -1;
  }

  cmd[len-2] = '\0';
  if (code == atoi(cmd))
    return 0;

  logit(cmd);

  return -1;
}


static int
tcp_puts(sock, msg, len)
  int sock;
  char *msg;
  int len;
{
  int pos;
  char *head, *tail;

  pos = tcp_pos;

  head = tcp_pool;
  tail = head + pos;
  memcpy(tail, msg, len);
  memcpy(tail + len, "\r\n", 2);
  pos += (len + 2);
  len = 0;

  if (pos >= TCP_BUFSIZ - TCP_LINSIZ)
  {
    len = xwrite(sock, head, pos);
    pos = 0;
  }

  tcp_pos = pos;
  return len;
}


static int
tcp_flush(sock)
  int sock;
{
  int pos;
  char *head, *tail;

  pos = tcp_pos;
  head = tcp_pool;
  tail = head + pos;
  memcpy(tail, "\r\n.\r\n", 5);
  return xwrite(sock, head, pos + 5);
}


/* ----------------------------------------------------- */
/* SMTP routines					 */
/* ----------------------------------------------------- */


static void
smtp_close(sock)
  int sock;
{
  tcp_command(sock, "QUIT\r\n", 221);
  shutdown(sock, 2);
  close(sock);
}


static int
smtp_open()
{
  int sock;
  struct sockaddr_in sin;
  struct hostent *host;
  char buf[256];

  sock = socket(AF_INET, SOCK_STREAM, 0);

  if (sock < 0)
    return -1;

  memset((char *) &sin, 0, sizeof(sin));
  sin.sin_family = AF_INET;
  sin.sin_port = htons(SMTP_PORT);

  host = gethostbyname(SMTP_HOST);
  if (host == NULL)
    sin.sin_addr.s_addr = inet_addr(SMTP_HOST);
  else
    memcpy(&sin.sin_addr.s_addr, host->h_addr, host->h_length);

  if (connect(sock, (struct sockaddr *) & sin, sizeof(sin)) < 0)
    return -1;

  tcp_command(sock, NULL, 220);

  sprintf(buf, "HELO %s\r\n", MYHOSTNAME);
  if (!tcp_command(sock, buf, 250))
    return sock;

  smtp_close(sock);
  return -1;
}


/* ----------------------------------------------------- */
/* chrono ==> file name (32-based)			 */
/* 0123456789ABCDEFGHIJKLMNOPQRSTUV			 */
/* ----------------------------------------------------- */


static char radix32[32] = {
  '0', '1', '2', '3', '4', '5', '6', '7',
  '8', '9', 'A', 'B', 'C', 'D', 'E', 'F',
  'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
  'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
};


static void
archiv32(chrono, fname)
  register time_t chrono;	/* 32 bits */
  register char *fname;		/* 7 chars */
{
  register char *str;

  str = fname + 7;
  *str = '\0';
  for (;;)
  {
    *(--str) = radix32[chrono & 31];
    if (str == fname)
      return;
    chrono >>= 5;
  }
}


static void
str_stamp(str, chrono)
  char *str;
  time_t *chrono;
{
  register struct tm *ptime;

  ptime = localtime(chrono);
  sprintf(str, "%02d/%02d/%02d",
    ptime->tm_year, ptime->tm_mon + 1, ptime->tm_mday);
}


/* ----------------------------------------------------- */
/* drawback to user					 */
/* ----------------------------------------------------- */


static void
str_lower(dst, src)
  char *dst, *src;
{
  register int ch;

  do
  {
    ch = *src++;
    if (ch >= 'A' && ch <= 'Z')
      ch |= 0x20;
    *dst++ = ch;
  } while (ch);
}


static char *
Ctime(clock)
  time_t *clock;
{
  static char datemsg[32];
  struct tm *t = localtime(clock);
  static char week[] = "��@�G�T�|����";

  sprintf(datemsg, "%d�~%2d��%2d��%3d:%02d:%02d �P��%.2s",
    t->tm_year - 11, t->tm_mon + 1, t->tm_mday,
    t->tm_hour, t->tm_min, t->tm_sec, &week[t->tm_wday << 1]);
  return (datemsg);
}


static int
draw_back(mqueue)
  MailQueue *mqueue;
{
  HDR mhdr;
  char buf[512], *ptr, userid[IDLEN + 1];
  int fd, fx;
  time_t chrono;
  FILE *fp;

  /* check if the userid is in our bbs now */

  str_lower(userid, mqueue->sender);
  sprintf(buf, "usr/%c/%s/.DIR", *userid, userid);
  fx = open(buf, O_WRONLY | O_CREAT | O_APPEND, 0600);
  if (fx < 0)
  {
    sprintf(buf, "BBS user <%s> not existed", userid);
    logit(buf);
    return -1;
  }

#ifdef	DEBUG
  logit(buf);
#endif

  /* allocate a file for the new mail */

  ptr = strchr(buf, '.');
  *ptr++ = '@';
  *ptr++ = '/';
  *ptr++ = '@';
  chrono = time(NULL);

  for (;;)
  {
    archiv32(chrono, ptr);
    fd = open(buf, O_WRONLY | O_CREAT | O_EXCL, 0600);
    if (fd >= 0)
      break;

    if (errno != EEXIST)
    {
      close(fx);
      sprintf(buf, "ERR create user <%s> file", userid);
      logit(buf);
      return -1;
    }

    chrono++;
  }

  /* copy the queue-file to the specified file */

  if ((fp = fdopen(fd, "w")) == NULL)
  {
    logit("Err fdopen()");
    close(fx);
    close(fd);
    return -1;
  }

#ifdef	DEBUG
  logit(buf);			/* file name */
#endif

  memset(&mhdr, 0, sizeof(HDR));
  mhdr.chrono = chrono;
  mhdr.xmode = MAIL_INCOME;
  strcpy(mhdr.xname, ptr - 1);
  strcpy(mhdr.owner, "SYSOP");
  strcpy(mhdr.nick, "�����l�t");
  str_stamp(mhdr.date, &mhdr.chrono);
  sprintf(mhdr.title, "�h�H�q���G%.60s", mqueue->subject);

  fprintf(fp, "�@��: SYSOP (�����l�t)\n���D: %s\n�ɶ�: %s\n",
    mhdr.title, ctime(&mhdr.chrono));

  fprintf(fp, "%s (%s) �z�n�G\n", mqueue->sender, mqueue->username);
  fprintf(fp, "�x�ݦb %s �H�X���H��A���D�O�G\n  %s�A\n���H�H�O�G<%s>\n"
    "�L�k���Q�H�F�C�i�ध�`����]�O E-mail address �����A�άO\n"
    "�����ö�B�������L�k���H���C�S�N��H�h�^�p�U�A�ƽЬd�ӡC\n--\n\n",
    Ctime(&mqueue->mailtime), mqueue->subject, mqueue->rcpt);

  fwrite(mpool, mleng, 1, fp);
  fclose(fp);

  /* append the record to the MAIL control file */

  write(fx, &mhdr, sizeof(HDR));
  close(fx);
  sprintf(buf, "back: [%s] <%s> %s",
    mqueue->sender, mqueue->rcpt, mqueue->subject);
  logit(buf);
  return 0;
}


static int
str_hash(str, seed)
  char *str;
  int seed;
{
  int cc;

  while (cc = *str++)
  {
    seed = (seed << 5) - seed + cc;     /* 31 * seed + cc */
  }
  return (seed & 0x7fffffff);
}


/* ----------------------------------------------------- */
/* SMTP deliver						 */
/* ----------------------------------------------------- */
/* > 0 : sucess						 */
/* = 0 : ignore it					 */
/* -1 : SMTP host error, try it later			 */
/* -2 : withdraw back to user				 */
/* ----------------------------------------------------- */


static int
deliver(sock, mqueue)
  int sock;
  MailQueue *mqueue;
{
  int fd, fsize, method, ch, len;
  char *fpath, *data, *ptr, *body, buf[512];
  struct stat st;

  data = mpool;

#if 0
  strcpy(data, "<<�H�󤺮e�O�Ū��A�άO�ɮ׿��~�A�G�L�k�H�X�C>>\n");
  mleng = strlen(data);
#endif

  method = mqueue->method;
  fpath = mqueue->filepath;

  /* --------------------------------------------------- */
  /* �����{�ҫH��					 */
  /* --------------------------------------------------- */

  if (method == MQ_JUSTIFY)
  {
    fpath = "etc/valid";

    archiv32(str_hash(mqueue->rcpt, mqueue->mailtime), buf);
    sprintf(mqueue->subject, "[MapleBBS]To %s(%s) [VALID]",
      mqueue->sender, buf);
  }

  /* --------------------------------------------------- */
  /* �ˬd mail file					 */
  /* --------------------------------------------------- */

  fd = open(fpath, O_RDONLY);
  if (fd < 0)
  {
    if (method != MQ_JUSTIFY)
      unlink(fpath);
    return 0;
  }

  if (fstat(fd, &st) || !S_ISREG(st.st_mode) || (fsize = st.st_size) <= 0)
  {
    close(fd);
    if (method != MQ_JUSTIFY)
      unlink(fpath);
    return 0;
  }

  ptr = buf;

  if (method & MQ_UUENCODE)
  {
    unlink(MAIL_UUFILE);
    sprintf(ptr, "/bin/uuencode %s %s.uu > %s",
      fpath, mqueue->sender, MAIL_UUFILE);
    system(ptr);

    close(fd);
      unlink(fpath);

    fpath = MAIL_UUFILE;
  fd = open(fpath, O_RDONLY);
  if (fd < 0)
  {
      unlink(fpath);
    return 0;
  }

    if (fstat(fd, &st) || !S_ISREG(st.st_mode) || (fsize = st.st_size) <= 0)
    {
	close(fd);
      unlink(fpath);
      return 0;
    }

    method = 0;
  }

  body = mpool;
  if (msize <= fsize)
  {
    msize = fsize + (fsize >> 2);
    body = (char *) realloc(body, msize);


    if (body == NULL)
    {
      fprintf(stderr, "realloc: %d, fail\n", msize);
      return -1;
    }
    fprintf(stderr, "realloc: %d\n", msize);
    mpool = body;
  }

  fsize = read(fd, body, fsize);
  close(fd);
  if (fsize <= 0)
  {
    if (method != MQ_JUSTIFY)
      unlink(fpath);

    return 0;
  }

  mleng = fsize;
  body[fsize] = '\0';

  /* --------------------------------------------------- */
  /* setup "From "					 */
  /* --------------------------------------------------- */

  if (method & MQ_JUSTIFY)	/* �����{�ҫH�� */
  {
    sprintf(ptr, "bbs@%s", MYHOSTNAME);
  }
  else
  {
    sprintf(ptr, "%s.bbs@%s", mqueue->sender, MYHOSTNAME);
  }

  /* --------------------------------------------------- */
  /* negotiation with mail server			 */
  /* --------------------------------------------------- */

  data = tcp_pool;

  sprintf(data, "MAIL FROM:<%s>\r\n", ptr);
  if (tcp_command(sock, data, 250))
    return -1;

  sprintf(data, "RCPT TO:<%s>\r\n", mqueue->rcpt);
  if (tcp_command(sock, data, 250))
  {
    tcp_command(sock, "RSET\r\n", 250);	/* reset SMTP host */

    sprintf(buf, "Error in RCPT: <%s> by <%s> [%s]",
      mqueue->rcpt, mqueue->sender, fpath);
    logit(buf);

#if 0
    if (method & MQ_EXPUNGE)
      unlink(fpath);
#endif

    return -2;
  }

  strcpy(data, "DATA\r\n");
  if (tcp_command(sock, data, 354))
  {
    tcp_command(sock, "RSET\r\n", 250);	/* reset SMTP host */

    return -2;			/* or to return 0 ? */
  }

  /* --------------------------------------------------- */
  /* begin of mail header				 */
  /* --------------------------------------------------- */

  sprintf(data, "From: %s\r\nTo: %s\r\nSubject: %s\r\nX-Forwarded-By: %s (%s)\r\nX-Disclaimer: [%s] �糧�H���e�����t�d\r\n\r\n",
    mqueue->sender, mqueue->rcpt, mqueue->subject, mqueue->sender, mqueue->username, BOARDNAME);
  tcp_pos = strlen(data);

  if (method & MQ_JUSTIFY)	/* �����{�ҫH�� */
  {
    ptr = data + tcp_pos;
    sprintf(ptr, " ID: %s (%s)  E-mail: %s\r\n\r\n",
      mqueue->sender, mqueue->username, mqueue->rcpt);
    tcp_pos += strlen(ptr);
  }

  /* --------------------------------------------------- */
  /* begin of mail body					 */
  /* --------------------------------------------------- */

  ptr = body;
  for (;;)
  {
    ch = *ptr;
    if (ch == '\n' || ch == '\r' || ch == '\0')
    {
      len = ptr - body;
      if (ch == '\0' && len == 0)
	break;

      if (*body == '.' && len == 1)
	len = tcp_puts(sock, "..", 2);
      else
	len = tcp_puts(sock, body, len);

      if (len < 0)			/* server down or busy */
      {
	return -1;
      }

      if (ch == '\0')
	break;

      ptr++;
      if (*ptr == '\n' && ch == '\r')
	ptr++;

      body = ptr;
    }
    else
    {
      ptr++;
    }
  }
  tcp_flush(sock);

  tcp_command(sock, NULL, 250);

  if (method & MQ_JUSTIFY == 0)
    unlink(fpath);

  /* chuan �O���H�H */

  sprintf(buf, "%-13s%c> %s", mqueue->sender,
    (method & MQ_JUSTIFY ? '=' : '-'), mqueue->rcpt);
  logit(buf);

  return fsize;
}


/* ----------------------------------------------------- */
/* main routines					 */
/* ----------------------------------------------------- */


main()
{
  int mfile, qfile, msock;
  int count, bytes, xmit, back;
  time_t now, queue_time;
  MailQueue mqueue;
  struct stat st;
  char buf[256];

  setgid(BBSGID);
  setuid(BBSUID);
  chdir(BBSHOME);

  now = time(0);

  if (stat(MAIL_XMIT, &st) < 0)
  {
    if (rename(MAIL_QUEUE, MAIL_XMIT))	/* no job, bye-bye */
      exit(0);
  }

#if 0
  else
  {
    if (st.st_mtime > now - 60 * 60)	/* sending */
      exit(0);
  }
#endif

  mfile = open(MAIL_XMIT, O_RDONLY);
  if (mfile < 0)
    exit(0);

  if (flock(mfile, LOCK_EX | LOCK_NB))
  {
    close(mfile);		/* sending */
    exit(0);
  }

  log_init();

  msock = smtp_open();
  if (msock < 0)
  {
    flock(mfile, LOCK_UN);
    close(mfile);

    logit("Error: smtp_open");
    log_close();
    exit(0);
  }

  back = count = bytes = qfile = 0;
  mpool = (char *) malloc(msize = MAIL_POOLSIZE);
  queue_time = now - 2 * 60 * 60;

  while (read(mfile, &mqueue, sizeof(mqueue)) == sizeof(mqueue))
  {
    fprintf(stderr, "%s\n", mqueue.sender);
    fflush(stderr);

    if (!strcmp(mqueue.sender, "ayck"))
      continue;

#ifdef	DEBUG
    logit(mqueue.subject);
#endif

    /* sleep(3);			/* �� SMTP_HOST �𮧤@�U */
    xmit = deliver(msock, &mqueue);

#ifdef	DEBUG
    logit(mqueue.filepath);
#endif

    if (xmit > 0)
    {
      bytes += xmit;
      count++;
    }
    else if (xmit == -2)	/* user side error, draw back */
    {
      if (mqueue.mailtime < queue_time)
      {
        draw_back(&mqueue);
        back++;
      }
      else			/* try it later */
      {
	if (!qfile)
	  qfile = open(MAIL_QUEUE, O_WRONLY | O_CREAT | O_APPEND, 0600);
        write(qfile, &mqueue, sizeof(mqueue));
      }
    }
    else if (xmit == -1)	/* server side error, try it later */
    {
      smtp_close(msock);
	if (!qfile)
	  qfile = open(MAIL_QUEUE, O_WRONLY | O_CREAT | O_APPEND, 0600);
      if (qfile > 0)
      {
	do
	{
	  write(qfile, &mqueue, sizeof(mqueue));
	} while (read(mfile, &mqueue, sizeof(mqueue)) == sizeof(mqueue));
	close(qfile);

	flock(mfile, LOCK_UN);
	close(mfile);
	unlink(MAIL_XMIT);

	/* Qsend : back to .MQ */

	now = time(0) - now;
	sprintf(buf, "Qsend: %d, byte: %d, time:%d, back:%d",
	  count, bytes, now, back);
	logit(buf);
	log_close();

	exit(0);
      }

      flock(mfile, LOCK_UN);
      close(mfile);

      /* Xsend : Error in back to .MQ */

      now = time(0) - now;
      sprintf(buf, "Xsend: %d, byte: %d, time:%d, back:%d",
	count, bytes, now, back);
      logit(buf);
      log_close();

      exit(1);
    }
  }

  smtp_close(msock);

  flock(mfile, LOCK_UN);
  close(mfile);
  unlink(MAIL_XMIT);

  if (qfile)
    close(qfile);

  now = time(0) - now;
  sprintf(buf, "send: %d, byte: %d, time:%d, back:%d",
    count, bytes, now, back);
  logit(buf);
  log_close();
  free(mpool);

  exit(0);
}
