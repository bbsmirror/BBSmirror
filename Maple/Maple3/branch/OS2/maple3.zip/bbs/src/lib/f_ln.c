/* ----------------------------------------------------- */
/* f_ln() : link() cross partition / disk		 */
/* ----------------------------------------------------- */


#include <fcntl.h>
#include <errno.h>


int
f_ln(src, dst)
  char *src, *dst;
{
  int ret;

#ifndef OS2
  if (ret = link(src, dst))
  {
#else
  if (ret = cp(src, dst))
  {
#endif
    if (errno != EEXIST)
      ret = f_cp(src, dst, O_EXCL);
  }
  return ret;
}
