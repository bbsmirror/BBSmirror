int
is_alpha(ch)
  int ch;
{
  return ((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z'));
}
