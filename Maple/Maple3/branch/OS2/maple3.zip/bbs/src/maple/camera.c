/*-------------------------------------------------------*/
/* util/camera.c	( NTHU CS MapleBBS Ver 3.00 )	 */
/*-------------------------------------------------------*/
/* target : �إ� [�ʺA�ݪO] cache			 */
/* create : 95/03/29				 	 */
/* update : 97/03/29				 	 */
/*-------------------------------------------------------*/


#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <strings.h>


#include "bbs.h"
#include "dao.h"

extern FCACHE *fshm;

static char *list[] = {
  "welcome",
  "bye",
  "apply",
  "tryout",
  "post",
  "gem.hlp",
  "board.hlp",
  "class.hlp",
  "friend.hlp",
  "mbox.hlp",
  "ulist.hlp",
  "vote.hlp",
  "more.hlp",
  "edit.hlp",
  NULL
};


#define MAX_LINE	10


static FCACHE image;
static int number;
static int tail;


static void
mirror(fpath)
  char *fpath;
{
  int fd, size;
  char *ptr;

  fd = open(fpath, O_RDONLY);
  if (fd >= 0)
  {
    ptr = image.film + tail;
    size = read(fd, ptr, FILM_SIZ);
    close(fd);

    if (size <= 0)
      return;

    ptr[size] = '\0';
    size = str_rle(ptr);

    if (size > 0 && size < FILM_SIZ)
    {
      ptr[size++] = '\0';
      image.shot[++number] = (tail += size);
    }
  }
}


static int
play(data)
  char *data;
{
  int line, ch;
  char *head;

  if (++number > MOVIE_MAX)
    return 1;

  str_rle(data);

  head = data;
  line = 0;
  while (ch = *data)		/* at most 10 lines */
  {
    data++;
    if (ch == '\n')
    {
      if (++line >= MAX_LINE)
	break;
    }
  }

  *data++ = 27;
  *data++ = '[';
  *data++ = 'm';

  while (line < MAX_LINE)	/* at lease 10 lines */
  {
    *data++ = '\n';
    line++;
  }

  *data++ = '\0';		/* mark for end of movie */
  ch = data - head;		/* length */

  line = tail + ch;
  if (line >= MOVIE_SIZE)
    return 1;			/* overflow */

  data = image.film + tail;
  memcpy(data, head, ch);
  image.shot[number] = tail = line;
  return 0;
}


camera()
{
  int i, fd, size;
  char *str, *fname, fpath[80], buf[FILM_SIZ + 1];
  FILE *fp;
  HDR hdr;

  /* --------------------------------------------------- */
  /* mirror pictures					 */
  /* --------------------------------------------------- */


  strcpy(fpath, "gem/@/@");
  fname = fpath + 7;
  
  for (i = 0; str = list[i]; i++)
  {
    strcpy(fname, str);
    mirror(fpath);
  }

  /* --------------------------------------------------- */
  /* visit all films					 */
  /* --------------------------------------------------- */

  strcpy(fpath, "gem/brd/note/@/@note");
  
  if (fp = fopen(fpath, "r"))
  {
    i = FILM_MOVIE;
    str = strchr(fpath, '@');
    while (fread(&hdr, sizeof hdr, 1, fp) == 1)
    {
      *str = hdr.xname[7];
      strcpy(str + 2, hdr.xname);
      if ((fd = open(fpath, O_RDONLY)) >= 0)
      {
	/* Ū�J�ɮ� */

	size = read(fd, buf, FILM_SIZ);
	close(fd);

	if (size >= FILM_SIZ || size <= 0)
	  continue;

	  buf[size] = '\0';
	  if (play(buf))	/* overflow */
	    break;
	  if (++i >= MOVIE_MAX)
	    break;
      }
    }
    fclose(fp);
  }

#if 0
  mirror("etc/weather.realtime");	/* Thor: �Y�ɮ�H */
  mirror("etc/weather.realtime");	/* Thor: �Y�ɮ�H */
  mirror("etc/weather.realtime");	/* Thor: �Y�ɮ�H */
  mirror("etc/news.realtime");	/* Thor: �Y�ɷs�D */
  mirror("etc/news.realtime.1");/* Thor: �Y�ɷs�D,�W�[���v */
  mirror("etc/news.realtime.2");/* Thor: �Y�ɷs�D,�W�[���v */
  mirror("etc/history.realtime");	/* Thor: ���v�W������ */
  mirror("etc/history.realtime");	/* Thor: ���v�W������ */
#endif

  i = number;	/* �`�@���X�� ? */

  /* --------------------------------------------------- */
  /* resolve shared memory				 */
  /* --------------------------------------------------- */

  memcpy(fshm, &image, sizeof(image.shot) + tail);
                       /* Thor.980805: �A�[�W shot������ */
  image.shot[0] = fshm->shot[0] = i;	/* �`�@���X�� ? */

#if 0
  fd = open("run/camera.img", O_WRONLY | O_CREAT | O_TRUNC, 0600);
  if (fd >= 0)
  {
    write(fd, &image, tail);
    close(fd);
  }
#endif

  if (fp = fopen("run/camera.log", "a"))
  {
    fprintf(fp, "%d/%d films, %d/%d bytes\n", i, MOVIE_MAX, tail, MOVIE_SIZE);
    fclose(fp);
  }
}
