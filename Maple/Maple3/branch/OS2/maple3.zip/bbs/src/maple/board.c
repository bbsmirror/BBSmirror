/*-------------------------------------------------------*/
/* board.c	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : �ݪO�B�s�ե\��	 			 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#include "bbs.h"


extern BCACHE *bshm;
extern XZ xz[];


char brd_bits[MAXBOARD];
static time_t brd_visit[MAXBOARD];	/* �̪��s���ɶ� */
static char *class_img;
static XO board_xo;
BRD *xbrd;


/* ----------------------------------------------------- */
/* �ݪO�\Ū�O�� .BRH (Board Reading History)		 */
/* ----------------------------------------------------- */


typedef struct BoardReadingHistory
{
  time_t bstamp;		/* �إ߬ݪO���ɶ�, unique */
  time_t bvisit;		/* �W���\Ū�ɶ� */
  int bcount;

  /* --------------------------------------------------- */
  /* time_t {final, begin} / {final | BRH_SIGN}		 */
  /* --------------------------------------------------- */

}                   BRH;


#define	BRH_EXPIRE	180
#define BRH_MAX      	200
#define BRH_PAGE	2048
#define	BRH_MASK	0x7fffffff
#define	BRH_SIGN	0x80000000
#define	BRH_WINDOW	(sizeof(BRH) + sizeof(time_t) * BRH_MAX * 2)


static int *brh_base;		/* allocated memory */
static int *brh_tail;		/* allocated memory */
static int brh_size;		/* allocated memory size */
static time_t brh_expire;


static int *
brh_alloc(tail, size)
  int *tail;
  int size;
{
  int *base, n;

  base = brh_base;
  n = (char *) tail - (char *) base;
  size += n;
  if (size > brh_size)
  {
    /* size = (size & -BRH_PAGE) + BRH_PAGE; */
    size += n >> 4;		/* �h�w���@�ǰO���� */
    base = (int *) realloc((char *) base, size);

    if (base == NULL)
      abort_bbs();

    brh_base = base;
    brh_size = size;
    tail = (int *) ((char *) base + n);
  }

  return tail;
}


static void
brh_put()
{
  int *list;

  /* compact the history list */

  list = brh_tail;

  if (*list)
  {
    int *head, *tail, n, item, chrono;

    n = *++list;
    brd_bits[n] |= BRD_H_BIT;
    time((time_t *)list);

    item = *++list;
    head = ++list;
    tail = head + item;

    while (head < tail)
    {
      chrono = *head++;
      n = *head++;
      if (n == chrono)
      {
	n |= BRH_SIGN;
	item--;
      }
      else
      {
	*list++ = chrono;
      }
      *list++ = n;
    }

    list[-item - 1] = item;
    *list = 0;
    brh_tail = list;
  }
}


static void
brh_get(bstamp, bhno)
  time_t bstamp;		/* board stamp */
  int bhno;
{
  int *head, *tail;
  int size, bcnt, item;
  char buf[BRH_WINDOW];

  if (bstamp == *brh_tail)
    return;

  brh_put();

  bcnt = 0;
  tail = brh_tail;

  if (brd_bits[bhno] & BRD_H_BIT)
  {
    head = brh_base;
    while (head < tail)
    {
      item = head[2];
      size = item * sizeof(time_t) + sizeof(BRH);

      if (bstamp == *head)
      {
	bcnt = item;
	memcpy(buf, head + 3, size);
	tail = (int *) ((char *) tail - size);
	if (item = (char *) tail - (char *) head)
	  memcpy(head, (char *) head + size, item);
	break;
      }
      head = (int *) ((char *) head + size);
    }
  }

  brh_tail = tail = brh_alloc(tail, BRH_WINDOW);

  *tail++ = bstamp;
  *tail++ = bhno;

  if (bcnt)			/* expand history list */
  {
    int *list;

    size = bcnt;
    list = tail;
    head = (int *) buf;

    do
    {
      item = *head++;
      if (item & BRH_SIGN)
      {
	item ^= BRH_SIGN;
	*++list = item;
	bcnt++;
      }
      *++list = item;
    } while (--size);
  }

  *tail = bcnt;
}


int
brh_unread(chrono)
  time_t chrono;
{
  int *head, *tail, item;

  if (chrono <= brh_expire)
    return 0;

  head = brh_tail + 2;
  if ((item = *head) > 0)
  {
    /* check {final, begin} history list */

    head++;
    tail = head + item;
    do
    {
      if (chrono > *head)
	return 1;

      head++;
      if (chrono >= *head)
	return 0;

    } while (++head < tail);
  }
  return 1;
}


void
brh_visit(mode)
  int mode;			/* 0 : visit, 1: un-visit */
{
  int *list;

  list = (int *) brh_tail + 2;
  *list++ = 2;
  if (mode)
  {
    *list = mode;
  }
  else
  {
    time((time_t *)list);
  }
  *++list = mode;
}


int
brh_add(prev, chrono, next)
  time_t prev, chrono, next;
{
  int *base, *head, *tail, item, final, begin;

  head = base = brh_tail + 2;
  item = *head++;
  tail = head + item;

  begin = BRH_MASK;

  while (head < tail)
  {
    final = *head;
    if (chrono > final)
    {
      if (prev <= final)
      {
	if (next < begin)	/* increase */
	  *head = chrono;
	else
	{			/* merge */
	  *base = item - 2;
	  base = head - 1;
	  do
	  {
	    *base++ = *++head;
	  } while (head < tail);
	}
	return;
      }

      if (next >= begin)
      {
	head[-1] = chrono;
	return;
      }

      break;
    }

    begin = *++head;
    head++;
  }

  /* insert or append */

  /* [21, 22, 23] ==> [32, 30] [15, 10] */

  if (item < BRH_MAX)
  {
    /* [32, 30] [22, 22] [15, 10] */

    *base = item + 2;
    tail += 2;
  }
  else
  {
    /* [32, 30] [22, 10] */

    tail--;
  }

  prev = chrono;
  for (;;)
  {
    final = *head;
    *head++ = chrono;

    if (head >= tail)
      return;

    begin = *head;
    *head++ = prev;

    if (head >= tail)
      return;

    chrono = final;
    prev = begin;
  }
}


/* ----------------------------------------------------- */
/* board permission check				 */
/* ----------------------------------------------------- */


static inline int
is_bm(list)
  char *list;			/* �O�D�GBM list */
{
  int cc, len;
  char *userid;

  len = strlen(userid = cuser.userid);
  do
  {
    cc = list[len];
    if ((!cc || cc == '/') && !str_ncmp(list, userid, len))
    {
      return 1;
    }
    while (cc = *list++)
    {
      if (cc == '/')
	break;
    }
  } while (cc);

  return 0;
}


static inline int
Ben_Perm(bhdr, ulevel)
  BRD *bhdr;
  usint ulevel;
{
  usint readlevel, postlevel, bits;
  char *blist, *bname;

  bname = bhdr->brdname;
  if (!*bname)
    return 0;

  if (!str_cmp(bname, DEFAULT_BOARD))
    return (BRD_R_BIT | BRD_W_BIT);

  bits = 0;

  readlevel = bhdr->readlevel;
  if (!readlevel || (readlevel & ulevel))
  {
    bits = BRD_R_BIT;

    if (ulevel & PERM_POST)
    {
      postlevel = bhdr->postlevel;
      if (!postlevel || (postlevel & ulevel))
	bits |= BRD_W_BIT;
    }
  }

  blist = bhdr->BM;
  if (blist[0] <= ' ')
    return bits;

  if ((ulevel & PERM_BM) && is_bm(blist))
    return (BRD_R_BIT | BRD_W_BIT | BRD_X_BIT);

  /* (moderated) ���K�ݪO�G�ֹ�ݪO���n�ͦW�� */

#ifdef HAVE_MODERATED_BOARD
  if (readlevel == PERM_SYSOP)
  {
    extern int bm_belong();
    return (bm_belong(bname));
  }
#endif

  return bits;
}


/* ----------------------------------------------------- */
/* ���J currboard �i��Y�z�]�w				 */
/* ----------------------------------------------------- */


int
bstamp2bno(stamp)
  time_t stamp;
{
  BRD *brd;
  int bno, max;

  bno = 0;
  brd = bshm->bcache;
  max = bshm->number;
  for (;;)
  {
    if (stamp == brd->bstamp)
      return bno;
    if (++bno >= max)
      return -1;
    brd++;
  }
}


static inline void
brh_load()
{
  BRD *brdp, *bend;
  usint ulevel;
  int n, cbno;
  char *bits;

  int size, *base;
  time_t expire, *bstp;
  char fpath[64];

  ulevel = cuser.userlevel;
  n = (ulevel & PERM_ALLBOARD) ? (BRD_R_BIT | BRD_W_BIT | BRD_X_BIT) : 0;
  memset(bits = brd_bits, n, sizeof(brd_bits));
  memset(bstp = brd_visit, 0, sizeof(brd_visit));

  if (n == 0)
  {
    brdp = bshm->bcache;
    bend = brdp + bshm->number;

    do
    {
      *bits++ = Ben_Perm(brdp, ulevel);
    } while (++brdp < bend);
  }

  /* --------------------------------------------------- */
  /* �N .BRH ���J memory				 */
  /* --------------------------------------------------- */

  size = 0;
  cbno = -1;
  brh_expire = expire = time(0) - BRH_EXPIRE * 86400;

  if (ulevel)
  {
    struct stat st;

    usr_fpath(fpath, cuser.userid, FN_BRH);
    if (!stat(fpath, &st))
      size = st.st_size;
  }

  /* --------------------------------------------------- */
  /* �h�O�d BRH_WINDOW ���B�@�Ŷ�			 */
  /* --------------------------------------------------- */

  /* brh_size = n = ((size + BRH_WINDOW) & -BRH_PAGE) + BRH_PAGE; */
  brh_size = n = size + BRH_WINDOW;
  brh_base = base = (int *) malloc(n);

  if (size && ((n = open(fpath, O_RDONLY)) >= 0))
  {
    int *head, *tail, *list, bstamp, bhno;

    size = read(n, base, size);
    close(n);

    /* compact reading history : remove dummy/expired record */

    head = base;
    tail = (int *) ((char *) base + size);
    bits = brd_bits;
    while (head < tail)
    {
      bstamp = *head;

      if (bstamp & BRH_SIGN)	/* zap */
      {
	bstamp ^= BRH_SIGN;
	bhno = bstamp2bno(bstamp);
	if (bhno >= 0)
	{
	  bits[bhno] |= BRD_Z_BIT;
	}
	head++;
	continue;
      }

      bhno = bstamp2bno(bstamp);
      list = head + 2;
      n = *list;
      size = n + 3;

      /* �o�ӬݪO�s�b�B�S���Q zap ���B�i�H read */

      if (bhno >= 0 && (bits[bhno] & BRD_R_BIT))
      {
	bits[bhno] |= BRD_H_BIT;/* �w���\Ū�O�� */
	bstp[bhno] = head[1];	/* �W���\Ū�ɶ� */
	cbno = bhno;

	if (n > 0)
	{

#if 0
	  if (n > BRH_MAX)
	    n = BRH_MAX;
#endif

	  list += n;

	  do
	  {
	    bhno = *list;
	    if ((bhno & BRH_MASK) > expire)
	      break;

	    if (!(bhno & BRH_SIGN))
	    {
	      if (*--list > expire)
		break;
	      n--;
	    }

	    list--;
	    n--;
	  } while (n > 0);

	  head[2] = n;
	}

	n = n * sizeof(time_t) + sizeof(BRH);
	if (base != head)
	  memcpy(base, head, n);
	base = (int *) ((char *) base + n);
      }
      head += size;
    }
  }

  *base = 0;
  brh_tail = base;

  /* --------------------------------------------------- */
  /* �]�w default board					 */
  /* --------------------------------------------------- */

  strcpy(currboard, "�|����w");

#if 0
  if (cbno >= 0)
  {
    board_setup(cbno);		/* ���J�W�������ɪ��ݪO */
    return;
  }

#ifdef	INITIAL_SETUP
  if (brd_bno(DEFAULT_BOARD) < 0)
    strcpy(currboard, "�|����w");
  else
#endif

    board_fetch(DEFAULT_BOARD);
#endif
}


void
brh_save()
{
  int *base, *head, *tail, bhno, size;
  BRD *bhdr, *bend;
  char *bits;

  base = brh_base;

  brh_put();

  /* save history of un-zapped boards */

  bits = brd_bits;
  head = base;
  tail = brh_tail;
  while (head < tail)
  {
    bhno = bstamp2bno(*head);
    size = head[2] * sizeof(time_t) + sizeof(BRH);
    if (bhno >= 0 && !(bits[bhno] & BRD_Z_BIT))
    {
      if (base != head)
	memcpy(base, head, size);
      base = (int *) ((char *) base + size);
    }
    head = (int *) ((char *) head + size);
  }

  /* save zap record */

  tail = brh_alloc(base, sizeof(time_t) * MAXBOARD);

  bhdr = bshm->bcache;
  bend = bhdr + bshm->number;
  do
  {
    if (*bits++ & BRD_Z_BIT)
    {
      *tail++ = bhdr->bstamp | BRH_SIGN;
    }
  } while (++bhdr < bend);

  /* OK, save it */

  base = brh_base;
  if ((size = (char *) tail - (char *) base) > 0)
  {
    char fpath[64];
    int fd;

    usr_fpath(fpath, cuser.userid, FN_BRH);
    if ((fd = open(fpath, O_WRONLY | O_CREAT | O_TRUNC, 0600)) >= 0)
    {
      write(fd, base, size);
      close(fd);
    }
  }
}


/*-------------------------------------------------------*/


void
XoPost(bno)
  int bno;
{
  XO *xo;
  BRD *brd;
  int bits;
  char *str, fpath[64];

  brd = bshm->bcache + bno;
  strcpy(currboard, brd->brdname);
  brh_get(brd->bstamp, bno);

  bbstate = /* (bbstate & STAT_DIRTY) | */ STAT_STARTED | brd->battr;

  str = &brd_bits[bno];
  bits = *str;
  if (bits & BRD_X_BIT)
    bbstate |= (STAT_BOARD | STAT_POST);
  else if (bits & BRD_W_BIT)
    bbstate |= STAT_POST;

#ifdef  HAVE_MODERATED_BOARD
  if (brd->readlevel == PERM_SYSOP)
    bbstate |= STAT_MODERATED;
#endif

  if (!(bits & BRD_V_BIT) && (cuser.ufo & UFO_BNOTE))
  {
    *str = bits | BRD_V_BIT;
    brd_fpath(fpath, currboard, fn_note);
    more(fpath, NULL);
  }

  brd_fpath(fpath, currboard, fn_dir);
  xz[XZ_POST - XO_ZONE].xo = xo = xo_get(fpath);
  xo->key = XZ_POST;
  xo->xyz = brd->bvote > 0 ? "���ݪO�i��벼��" : brd->title + 3;
  str = brd->BM;
  if (*str <= ' ')
    str = "�x�D��";
  sprintf(currBM, "�O�D�G%s", str);
}


/* ----------------------------------------------------- */
/* Class [�����s��]					 */
/* ----------------------------------------------------- */


static int class_flag;


#define	BFO_YANK	0x01


static int
class_load(xo)
  XO *xo;
{
  short *cbase, *chead, *ctail;
  int chn;			/* ClassHeader number */
  int pos, max, val, zap;
  BRD *brd;
  char *bits;

  chn = CH_END - xo->key;

  cbase = (short *) class_img;
  chead = cbase + chn;
  pos = chead[0] + CH_TTLEN;
  max = chead[1];

  chead = (short *) ((char *) cbase + pos);
  ctail = (short *) ((char *) cbase + max);

  max -= pos;

  if (cbase = (short *) xo->xyz)
    cbase = (short *) realloc(cbase, max);
  else
    cbase = (short *) malloc(max);
  xo->xyz = (char *) cbase;

  max = 0;
  brd = bshm->bcache;

  bits = brd_bits;
  zap = (class_flag & BFO_YANK) ? 0 : BRD_Z_BIT;

  do
  {
    chn = *chead++;
    if (chn >= 0)
    {
      val = bits[chn];
      if (!(val & BRD_R_BIT) || (val & zap) || !(brd[chn].brdname[0]))
	continue;
    }

    max++;
    *cbase++ = chn;
  } while (chead < ctail);

  xo->max = max;
  if (xo->pos >= max)
    xo->pos = xo->top = 0;

  return max;
}


static int
XoClass(chn)
  int chn;
{
  XO xo, *xt;
  /* Thor.980727: �ѨM XO xo�����T�w��,
                    class_load�����| initial xo.max, ��L���T�w */
  xo.pos = xo.top = 0;
  
  xo.key = chn;
  xo.xyz = NULL;
  if (!class_load(&xo))
  {
    free(xo.xyz);
    return XO_NONE;
  }

  xt = xz[XZ_CLASS - XO_ZONE].xo;
  xz[XZ_CLASS - XO_ZONE].xo = &xo;
  xover(XZ_CLASS);
  free(xo.xyz);
  xz[XZ_CLASS - XO_ZONE].xo = xt;

  return XO_BODY;
}


#if 0
/* ----------------------------------------------------- */
/* �ˬd BRD �@���X�g post�A�γ̫�@�g post ���ɶ�	 */
/* ----------------------------------------------------- */


void
bcheck(brd)
  BRD *brd;
{
  char folder[64];
  struct stat st;
  int fd, size;

  brd_fpath(folder, brd->brdname, fn_dir);

#if 1
  if (!stat(folder, &st))
  {
    brd->bpost = st.st_size / sizeof(HDR);
    brd->blast = st.st_mtime;
  }
#else
  fd = open(folder, O_RDONLY);
  if (fd < 0)
    return;

  fstat(fd, &st);

  if (st.st_mtime > brd->btime)
  {
    brd->btime = time(0) + 45;	/* 45 �������������ˬd */
    if ((size = st.st_size) >= sizeof(HDR))
    {
      brd->bpost = size / sizeof(HDR);
      lseek(fd, size - sizeof(HDR), SEEK_SET);
      read(fd, &brd->blast, sizeof(time_t));
    }
    else
    {
      brd->blast = brd->bpost = 0;
    }
  }

  close(fd);
#endif
}
#endif


static int
class_body(xo)
  XO *xo;
{
  char *img, *bits;
  short *chp;
  BRD *bcache;
  int n, cnt, max, brdnew;

  img = class_img;

  bcache = bshm->bcache;
  brdnew = class_flag & UFO_BRDNEW;
  bits = brd_bits;

  max = xo->max;
  cnt = xo->top;
  chp = (short *) xo->xyz + cnt;
  n = 3;
  do
  {
    move(n, 0);
    if (cnt < max)
    {
      int chn;
      char *str;

      cnt++;
      chn = *chp++;
      if (chn >= 0)
      {
	BRD *brd;
	int num;

	brd = bcache + chn;

	if (brdnew)
	{
	  int fd, fsize;
	  char folder[64];
	  struct stat st;

	  brd_fpath(folder, brd->brdname, fn_dir);
	  if ((fd = open(folder, O_RDONLY)) >= 0)
	  {
	    fstat(fd, &st);

	    if (st.st_mtime > brd->btime)
	    {
	      brd->btime = time(0) + 45;	/* 45 �������������ˬd */
	      if ((fsize = st.st_size) >= sizeof(HDR))
	      {
		brd->bpost = fsize / sizeof(HDR);
		lseek(fd, fsize - sizeof(HDR), SEEK_SET);
		read(fd, &brd->blast, sizeof(time_t));
	      }
	      else
	      {
		brd->blast = brd->bpost = 0;
	      }
	    }

	    close(fd);
	  }
	  num = brd->bpost;
	  str = brd->blast > brd_visit[chn] ? "\033[1;32m�E\033[m" : "�C";
	}
	else
	{
	  num = cnt;
	  str = "  ";
	}

	prints("%6d%s%c%-13s%-42s%c %.13s", num, str,
	  bits[chn] & BRD_Z_BIT ? '-' : ' ',
	  brd->brdname, brd->title, brd->bvote ? 'V' : ' ', brd->BM);
      }
      else
      {
	short *chx;

	chx = (short *) img + (CH_END - chn);
	prints("%6d   %s", cnt, img + *chx);
      }
    }
    clrtoeol();
  } while (++n < b_lines);

  return XO_NONE;
}


static int
class_neck(xo)
  XO *xo;
{
  move(1, 0);
  prints("[��]�D��� [��]�\\Ū [����]��� [c]�g�� [y]���J [/]�j�M [s]�ݪO [h]����\n"
    "[44m  %-7s��  �O       %-38s�벼 �O    �D     [m",
    class_flag & UFO_BRDNEW ? "�`��" : "�s��", "��   ��   ��   �z");

  return class_body(xo);
}


static int
class_head(xo)
  XO *xo;
{
  vs_head("�ݪO�C��", str_site);
  return class_neck(xo);
}


static int
class_init(xo)			/* re-init */
  XO *xo;
{
  class_load(xo);
  return class_head(xo);
}


static int
class_newmode(xo)
  XO *xo;
{
  cuser.ufo ^= UFO_BRDNEW;
  class_flag ^= UFO_BRDNEW;
  return class_neck(xo);
}


static int
class_help(xo)
  XO *xo;
{
  film_out(FILM_CLASS, -1);
  return class_head(xo);
}


static int
class_search(xo)
  XO *xo;
{
  int num, pos, max;
  char *ptr;
  char buf[IDLEN + 1];

  ptr = buf;
  pos = vget(b_lines, 0, "�п�J�ݪO�W�١G", ptr, IDLEN + 1, DOECHO);
  move(b_lines, 0);
  clrtoeol();

  if (pos)
  {
    short *chp, chn;
    BRD *bcache, *brd;

    bcache = bshm->bcache;

    str_lower(ptr, ptr);
    pos = num = xo->pos;
    max = xo->max;
    chp = (short *) xo->xyz;
    do
    {
      if (++pos >= max)
	pos = 0;
      chn = chp[pos];
      if (chn >= 0)
      {
	brd = bcache + chn;
	if (str_str(brd->brdname, ptr) || str_str(brd->title, ptr))
	  return pos + XO_MOVE;
      }
    } while (pos != num);
  }

  return XO_NONE;
}


static int
class_yank(xo)
  XO *xo;
{
  class_flag ^= BFO_YANK;
  return class_init(xo);
}


static int
class_zap(xo)
  XO *xo;
{
  BRD *brd;
  short *chp;
  int num, chn;

  num = xo->pos;
  chp = (short *) xo->xyz + num;
  chn = *chp;
  if (chn >= 0)
  {
    brd = bshm->bcache + chn;
    if (!(brd->battr & BRD_NOZAP))
    {
      move(3 + num - xo->top, 8);
      num = brd_bits[chn] ^= BRD_Z_BIT;
      outc(num & BRD_Z_BIT ? '-' : ' ');
    }
  }

  return XO_NONE;
}


static int
class_edit(xo)
  XO *xo;
{
  if (HAS_PERM(PERM_ALLBOARD))
  {
    short *chp;
    int chn;

    chp = (short *) xo->xyz + xo->pos;
    chn = *chp;
    if (chn >= 0)
    {
      brd_edit(chn);
      return class_init(xo);
    }
  }
  return XO_NONE;
}


static int
class_browse(xo)
  XO *xo;
{
  short *chp;
  int chn;

  chp = (short *) xo->xyz + xo->pos;
  chn = *chp;
  if (chn < 0)
  {
    if (XoClass(chn) == XO_NONE)
      return XO_NONE;
  }
  else
  {
    XoPost(chn);
    xover(XZ_POST);
    time(&brd_visit[chn]);
  }

  return class_head(xo);	/* Thor.0701: �L�k�M�֤@�I, �]�� XoPost */
}


int
Select()
{
  int bno;
  BRD *brd;
  char bname[16];

  if (brd = ask_board(bname, BRD_R_BIT, NULL))
  {
    bno = brd - bshm->bcache;
    if (*bname)
    {
      XoPost(bno);
    }
    xover(XZ_POST);
    time(&brd_visit[bno]);
  }
  else
  {
    vmsg(err_bid);
  }

  return 0;
}


static int
class_switch(xo)
  XO *xo;
{
  Select();
  return class_head(xo);
}


#ifdef AUTHOR_EXTRACTION
/* Thor.0818: �Q�令�H�ثe���ݪ��C���Τ����ӧ�, ���n����� */


/* opus.1127 : �p�e���g, �i extract author/title */


static int
XoAuthor(xo)
  XO *xo;
{
  int chn, len, max, tag;
  short *chp, *chead, *ctail;
  BRD *brd;
  char author[IDLEN + 1];
  XO xo_a, *xoTmp;

  if (!vget(b_lines, 0, "�п�J�@�̡G", author, IDLEN + 1, DOECHO))
    return XO_FOOT;

  str_lower(author, author);
  len = strlen(author);

  chead = (short *) xo->xyz;
  max = xo->max;
  ctail = chead + max;

  tag = 0;
  chp = (short *) malloc(max * sizeof(short));
  brd = bshm->bcache;

  do
  {
    if ((chn = *chead++) >= 0)	/* Thor.0818: ���� group */
    {
      /* Thor.0701: �M����w�@�̤峹, ���h����m, �é�J */

      int fsize;
      char *fimage, folder[80];
      HDR *head, *tail;

      sprintf(folder, "�m�M����w�@�̡n�ݪ��G%s \033[5m...\033[m",
	brd[chn].brdname);
      outz(folder);
      refresh();
      brd_fpath(folder, brd[chn].brdname, fn_dir);

#ifdef HAVE_MMAP
      fimage = f_map(folder, &fsize);

      if (fimage == (char *) -1)
	continue;

      head = (HDR *) fimage;
      tail = (HDR *) (fimage + fsize);

      while (head <= --tail)
      {
	if (tail->xmode & (POST_CANCEL | POST_DELETE))
	  continue;

	/* if(str_str(temp,author)) *//* Thor.0818:�Ʊ����� */

	if (!str_ncmp(tail->owner, author, len))
	{
	  xo_get(folder)->pos = tail - head;
	  chp[tag++] = chn;
	  break;
	}
      }

      munmap(fimage, fsize);

#else
      xo_t = xo_new(folder);
      xo_t->pos = XO_TAIL;	/* �Ĥ@���i�J�ɡA�N��Щ�b�̫᭱ */
      xo_load(xo_t, sizeof(HDR));
      if (xo_t->max <= 0)
	continue;
      head = (HDR *) xo_pool;
      tail = (HDR *) xo_pool + (xo_t->pos - xo_t->top);
      for (;;)
      {
	if (!(tail->xmode & (POST_CANCEL | POST_DELETE)))
	{
	  /* check condition */
	  if (!str_ncmp(tail->owner, author, len))	/* Thor.0818:�Ʊ����� */
	  {
	    xo_get(folder)->pos = tail - head;
	    chp[tag++] = chn;
	    break;
	  }
	}
	tail--;
	if (tail < head)
	{
	  if (xo_t->top <= 0)
	    break;
	  xo_t->pos -= XO_TALL;
	  xo_load(xo_t, sizeof(HDR));
	  tail = (HDR *) xo_pool + XO_TALL - 1;
	}
      }

      free(xo_t);
#endif

    }
  } while (chead < ctail);

  if (!tag)
  {
    free(chp);
    vmsg("�ŵL�@��");
    return XO_FOOT;
  }

  xo_a.pos = xo_a.top = 0;
  xo_a.max = tag;
  xo_a.key = 1;			/* all boards */
  xo_a.xyz = (char *) chp;

  xoTmp = xz[XZ_CLASS - XO_ZONE].xo;	/* Thor.0701: �O�U��Ӫ�class_xo */

  xz[XZ_CLASS - XO_ZONE].xo = &xo_a;
  xover(XZ_CLASS);

  free(chp);

  xz[XZ_CLASS - XO_ZONE].xo = xoTmp;		/* Thor.0701: �٭� class_xo */

  return class_body(xo);
}
#endif


static KeyFunc class_cb[] =
{
  XO_INIT, class_head,
  XO_LOAD, class_body,
  XO_HEAD, class_head,
  XO_BODY, class_body,

  'r', class_browse,
  '/', class_search,
  'c', class_newmode,

  's', class_switch,

  'y', class_yank,
  'z', class_zap,
  'E', class_edit,

#ifdef AUTHOR_EXTRACTION
  'A', XoAuthor,
#endif

  'h', class_help
};


int
Class()
{
  XoClass(CH_END - 1);
  return 0;
}


void
board_main()
{
  int fsize;
  bshm_init(); /*rexchen*/
  brh_load();

  class_img = f_img(CLASS_IMGFILE, &fsize);
  if (class_img == NULL)
  {
    blog("CACHE", "class.img");
  }

  if (!cuser.userlevel)		/* guest yank all boards */
  {
    class_flag = BFO_YANK;
  }
  else
  {

#if 0
    class_flag = 0;		/* to speed up */
#endif

    class_flag = cuser.ufo & UFO_BRDNEW;
  }

  board_xo.key = CH_END;
  class_load(&board_xo);

  xz[XZ_CLASS - XO_ZONE].xo = &board_xo;	/* Thor: default class_xo */
  xz[XZ_CLASS - XO_ZONE].cb = class_cb;	/* Thor: default class_xo */
}


int
Boards()
{
  /* class_xo = &board_xo; *//* Thor: �w�� default, ���ݧ@�� */
  xover(XZ_CLASS);
  return 0;
}
