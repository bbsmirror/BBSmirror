#include "bbs.h"

main()
{
  FILE *fp;
  char *str, buf[128], fpath[128];
  int fd;
  ACCT acct;

  if (fp = fopen("/tmp/new", "r"))
  {
    while (fgets(buf, sizeof buf, fp))
    {
      fprintf(stderr, buf);

      str = strchr(buf + 1, ' ');
      *str = '\0';

      usr_fpath(fpath, buf + 1, ".ACCT");
      fd = open(fpath, O_RDWR);

      if (fd >= 0)
      {
	if (read(fd, &acct, sizeof(ACCT)) == sizeof(ACCT))
	{
	  if (acct.userlevel & PERM_VALID)
	    acct.userlevel = PERM_DEFAULT | PERM_VALID;
	  else
	    acct.userlevel = PERM_DEFAULT;
	  acct.ufo = UFO_COLOR | UFO_MOVIE | UFO_BNOTE;
	  lseek(fd, (off_t) 0, SEEK_SET);
	  write(fd, &acct, sizeof(ACCT));
	}
	close(fd);
      }
    }
    fclose(fp);
  }
}
