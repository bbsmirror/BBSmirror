/*-------------------------------------------------------*/
/* util/m3tom2_brd.c          (SOB 0.22 ATS Verion 1.32) */
/*-------------------------------------------------------*/
/* target : �N Maple3 BRD �ഫ�� Maple2 boardheader      */
/* create : 03/07/19 by Dopin                            */
/* update :   /  /                                       */
/*-------------------------------------------------------*/

#include "bbs.h"

#define TRANSED BBSHOME "/BOARDS.M3"

#define MSTRLEN   80             /* Length of most string data */
#define MBTLEN    42             /* Length of board title */
#define MBMLEN    36             /* Length of board managers */
#define MTTLEN    72             /* Length of title */
#define MFNLEN    28             /* Length of filename  */
#define MIDLEN    12             /* Length of board / user id */
#define MPASSLEN  14             /* Length of encrypted passwd field */

typedef struct BoardHeader {
  char brdname[MIDLEN + 1];      /* board ID */
  char title[MBTLEN + 1];
  char color;
  char class[5];
  char BM[MBMLEN + 1];           /* BMs' uid, token '/' */

  uschar bvote;                 /* �@���X���벼�|�椤 */

  time_t bstamp;                /* �إ߬ݪO���ɶ�, unique */
  usint readlevel;              /* �\Ū�峹���v�� */
  usint postlevel;              /* �o���峹���v�� */
  usint battr;                  /* �ݪO�ݩ� */
  time_t btime;                 /* .DIR �� st_mtime */
  int bpost;                    /* �@���X�g post */
  time_t blast;                 /* �̫�@�g post ���ɶ� */
} BRD;

int main(int argc, char *argv[]) {
  char buf[MAXPATHLEN];
  BRD brd;
  boardheader bh;
  FILE *fs, *ft;

  if(argc != 2) {
    puts("Usage : m3tom2_brd <OLD BBS HOME>\n");

    puts("Translation M3 .BRD -> M2 .BOARDS");
    puts("Copyright(C) Atlantis BBS Ver 1.32  July 2003 (by Dopin)");
    return -1;
  }

  sprintf(buf, "%s/.BRD", argv[1]);
  if((fs = fopen(buf, "rb")) == NULL) return -1;
  if((ft = fopen(TRANSED, "wb+")) == NULL) {
    fclose(fs);
    return -2;
  }

  while(fread(&brd, sizeof(brd), 1, fs)) {
    memset(&bh, 0, sizeof(bh));

    strcpy(bh.brdname, brd.brdname);
    strcpy(bh.station, DEFAULTST);
    strncpy(bh.BM, brd.BM, IDLEN*3+2);

    /* ���������]�\�i�H����n���ഫ�覡 */
    sprintf(bh.title, "%s%c%c %s", *brd.class ? brd.class : "�w�]",
            brd.title[0], brd.title[1], &brd.title[2]);

    /* �o��S��k�����ഫ �@�ߥH�o���v������ ���K�O�ݭ��s�]�w */
    bh.level = brd.postlevel | PERM_POSTMASK;

    fwrite(&bh, sizeof(bh), 1, ft);
    printf("%s\n", bh.brdname);
  }
  fclose(fs), fclose(ft);

  return 0;
}
