/*-------------------------------------------------------*/
/* util/m3tom2_acct.c         (SOB 0.22 ATS Verion 1.32) */
/*-------------------------------------------------------*/
/* target : �N Maple3 ACCT �ഫ�� Maple2 userec          */
/* create : 03/07/14 by Dopin                            */
/* update :   /  /                                       */
/* source : �ؿ��j�M���� : �� expire.c �ק�              */
/*-------------------------------------------------------*/

#include        "bbs.h"

#define TRANSED BBSHOME "/PASSWDS.M3"

#define MSTRLEN   80             /* Length of most string data */
#define MBTLEN    42             /* Length of board title */
#define MBMLEN    36             /* Length of board managers */
#define MTTLEN    72             /* Length of title */
#define MFNLEN    28             /* Length of filename  */
#define MIDLEN    12             /* Length of board / user id */
#define MPASSLEN  14             /* Length of encrypted passwd field */

typedef int (*FPTR)(const void*, const void*);

typedef struct {
  time_t chrono;                /* timestamp */
  int xmode;

  int xid;                      /* reserved �O�d*/

  char xname[32];               /* �ɮצW�� */
  char owner[60];               /* �@�� (E-mail address) */
  char reserve[16];             /* �O�d */
  int  recommend;               /* ���ˤ峹 */
  char nick[50];                /* �ʺ� */

  char date[9];                 /* [96/12/01] */
  /* Thor.990329: �S�O�`�N, date �u����ܥ�, ���@���, �H�קK y2k ���D,
                  �w�q 2000 �� 00, 2001 �� 01 */

  char title[73];               /* �D�D (TTLEN + 1) */
} HDR;

typedef struct {
  int userno;                   /* unique positive code */
  char userid[MIDLEN + 1];       /* userid */
  char passwd[MPASSLEN];         /* user password crypt by DES */
  uschar signature;             /* user signature number */
  char realname[20];            /* user realname */
  char username[24];            /* user nickname */
  usint userlevel;              /* user perm */
  int numlogins;                /* user login times */
  int numposts;                 /* user post times */
  usint ufo;                    /* user basic flags */
  time_t firstlogin;            /* user first login time */
  time_t lastlogin;             /* user last login time */
  time_t staytime;              /* user total stay time */
  time_t tcheck;                /* time to check mbox/pal */
  char lasthost[32];            /* user last login remote host */
  int numemail;                 /* �H�o Inetrnet E-mail ���� */
  time_t tvalid;                /* �q�L�{�ҡB��� mail address ���ɶ� */
  char email[60];               /* user email */
  char address[60];             /* user address */
  char justify[60];             /* FROM of replied justify mail */
  char vmail[60];               /* �q�L�{�Ҥ� email */
  time_t deny;                  /* user violatelaw time */
  int request;                  /* �I�q�t�� */
  usint ufo2;                   /* �������ӤH�]�w */
  char ident[108];              /* user remote host ident */
  time_t vtime;                 /* validate time */
} ACCT;

struct life {
  char bname[16];               /* board ID */
  int days;                     /* expired days */
  int maxp;                     /* max post */
  int minp;                     /* min post */
};
typedef struct life life;

int dashd(char *fname) {
  struct stat st;
  return (stat(fname, &st) == 0 && S_ISDIR(st.st_mode));
}

int dashf(char *fname) {
  struct stat st;
  return (stat(fname, &st) == 0 && S_ISREG(st.st_mode));
}

int trans_acct(char *fpath) {
  ACCT acct;
  userec user;
  FILE *fs, *ft;

  if((fs = fopen(fpath, "rb")) == NULL) return -1;
  fread(&acct, sizeof(acct), 1, fs);
  fclose(fs);

  if((ft = fopen(TRANSED, "ab+")) == NULL) return -2;
  memset(&user, 0, sizeof(user));

  strcpy(user.userid, acct.userid);
  strcpy(user.realname, acct.realname);
  strcpy(user.username, acct.username);
  strncpy(user.lasthost, acct.lasthost, 32);
  strncpy(user.email, acct.email, 50);
  strncpy(user.address, acct.address, 60);
  strncpy(user.justify, acct.justify, REGLEN+1 > 60 ? 60 : REGLEN+1);

  strcpy(user.passwd, acct.passwd);

  user.userlevel  = acct.userlevel;   // �ݤ�ʭץ������a��
  user.numlogins  = acct.numlogins;
  user.numlogins  = acct.numlogins;
  user.firstlogin = acct.firstlogin;
  user.lastlogin  = acct.lastlogin;

  user.uflag = MOVIE_FLAG | COLOR_FLAG;

  /* Dopin: �p�G���Ʊ�A�[�� �Цۦ��� �ΧQ�� ATSVersion �Q�פ� */
  fwrite(&user, sizeof(user), 1, ft);
  fclose(ft);

  return 0;
}

int find_acct(char *direct) {
  char *ptr;
  int count, number;
  DIR *dirp;
  life db, table[MAXUSERS], *key;
  struct dirent *de;

  count = 0;
  if(direct && *direct) {
    ptr = (char *)strtok(NULL, " \t\r\n");

    if(ptr && (number = atoi(ptr)) > 0) {
      key = &(table[count++]);
      strcpy(key->bname, direct);
      key->days = number;
      key->maxp = db.maxp;
      key->minp = db.minp;

      ptr = (char *)strtok(NULL, " \t\r\n");
      if(ptr && (number = atoi(ptr)) > 0) {
        key->maxp = number;

        ptr = (char *)strtok(NULL, " \t\r\n");
        if(ptr && (number = atoi(ptr)) > 0)  key->minp = number;
      }
    }
  }

  if(!(dirp = opendir(direct))) {
    printf("DIR %s open Error\n", direct);
    return 1;
  }

  while (de = readdir(dirp)) {
    ptr = de->d_name;

    if(ptr[0] > ' ' && ptr[0] != '.') {
      char fpath[MAXPATHLEN];

      if(count) key = (life *)bsearch(ptr, table, count, sizeof(life),
                                      (FPTR)strcasecmp);
      else      key = NULL;

      if(!key) key = &db;

      strcpy(key->bname, ptr);
      sprintf(fpath, "%s/%s/.ACCT", direct, key->bname);
      if(dashf(fpath)) {
        printf("%s\n", fpath);
        trans_acct(fpath);
      }
    }
  }
  closedir(dirp);

  return 0;
}

int main(int argc, char *argv[]) {
  char ch, fpath[MAXPATHLEN];

  if(argc != 3) {
     puts("Usage : m3tom2_acct <OLD BBS usr home> <New BBS HOME>\n");

     puts("Translation M3 .ACCT -> M2 .PASSWDS");
     puts("Copyright(C) Atlantis BBS Ver 1.32  July 2003 (by Dopin)");
     return -1;
  }

  if(dashf(TRANSED)) unlink(TRANSED);

  for(ch = 'a' ; ch <= 'z' ; ch++) {
    sprintf(fpath, "%s/%c", argv[1], ch);
    find_acct(fpath);
  }

  return 0;
}
