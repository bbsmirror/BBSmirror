/*
 * Copyright (c) 1988, 1993, 1994
 *      The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by the University of
 *      California, Berkeley and its contributors.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 *      $Id: killall.c,v 1.3 1995/03/05 21:52:41 jkh Exp $
 */

#ifndef lint
static char copyright[] =
"@(#) Copyright (c) 1988, 1993, 1994\n\
        The Regents of the University of California.  All rights reserved.\n";
#endif /* not lint */

#ifndef lint
static char sccsid[] = "@(#)killall.c      8.3 (Berkeley) 12/1/96";
#endif /* not lint */

#include <ctype.h>
#include <err.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <kvm.h>
#include <nlist.h>
#include <paths.h>
#include <unistd.h>


#include <sys/param.h>
#include <sys/user.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/proc.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/sysctl.h>


void nosig __P((char *));
void printsig __P((FILE *));
void usage __P((void));

int
main(argc, argv)
        int argc;
        char *argv[];
{
        const char *const *p;
        int errors, numsig;
        char *ep;
        kvm_t *kd;
        char errbuf[256];
        struct kinfo_proc *kp;
        int i, nentries;
        char* cmd;
        pid_t pid, currpid;
        uid_t uid;
        int killed;
        double cpu;

/*
        if (argc < 2)
                usage();

        if (!strcmp(*++argv, "-l")) {
                printsig(stdout);
                exit(0);
        }
*/

        numsig = SIGTERM;
        if (**argv == '-') {
                ++*argv;
                if (isalpha(**argv)) {
                        if (!strncasecmp(*argv, "sig", 3))
                                *argv += 3;
                        for (numsig = NSIG, p = sys_signame + 1; --numsig; ++p)
                                if (!strcasecmp(*p, *argv)) {
                                        numsig = p - sys_signame;
                                        break;
                                }
                        if (!numsig)
                                nosig(*argv);
                } else if (isdigit(**argv)) {
                        numsig = strtol(*argv, &ep, 10);
                        if (!*argv || *ep)
                                errx(1, "illegal signal number: %s", *argv);
                        if (numsig < 0 || numsig > NSIG)
                                nosig(*argv);
                } else
                        nosig(*argv);
                ++argv;
        }

        if (!*argv)
                usage();

        uid = getuid();
        currpid = getpid();
        kd = kvm_openfiles(0, 0, 0, O_RDONLY, errbuf);
        if (kd == 0)
            printf("%s\n", errbuf);
        killed = 0;
        if ((kp = kvm_getprocs(kd, KERN_PROC_ALL, 0, &nentries)) == 0)
            printf("%s\n", kvm_geterr(kd));

        errors = 0;
/*
        while (*argv) {
*/
           for (i = 0; i < nentries; i++) {
              cmd = kp[i].kp_proc.p_comm;
              pid = kp[i].kp_proc.p_pid;
              cpu = (double)kp[i].kp_proc.p_pctcpu / FSCALE * 100;
              if (inlist(cmd) && cpu > 5) {
                 kill(pid, 9);
                 printf("%-15s%8d%8.2f\n", cmd, pid, cpu);
                 ++killed;
              }
/*
              if (pid != currpid && !strcmp(*argv, cmd))
                 if (kill(pid, numsig) == -1) {
                    printf("warn: kill %s(%d) failed\n", *argv, pid);
                    ++errors;
                  }
               else {
                  printf("kill(%d): %s(%d) succeeded\n", numsig, *argv, pid);
                  ++killed;
               }
*/
           }
/*
           if (!killed) {
              ++errors;
              printf("warn: no \"%s\" killed\n", *argv, killed);
           }
           ++argv;
        }
*/
        exit(errors);
}

void
nosig(name)
        char *name;
{

        warnx("unknown signal %s; valid signals:", name);
        printsig(stderr);
        exit(1);
}

void
printsig(fp)
        FILE *fp;
{
        const char *const *p;
        int cnt;

        for (cnt = NSIG, p = sys_signame + 1; --cnt; ++p) {
                (void)fprintf(fp, "%s ", *p);
                if (cnt == NSIG / 2)
                        (void)fprintf(fp, "\n");
        }
        (void)fprintf(fp, "\n");
}

void
usage()
{

        (void)fprintf(stderr, "usage: killall [-l] [-sig] pname ...\n");
        exit(1);
}

inlist(char* cmd)
{
   if (!strcmp("bbs", cmd))
      return 1;
   if (!strcmp("bpop3d", cmd))
      return 1;
   return 0;
}
