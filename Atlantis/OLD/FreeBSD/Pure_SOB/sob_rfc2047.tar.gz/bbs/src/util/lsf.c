/*
  lsf: Line String Filter
  Usage: lsf <column> <string>
*/

#include <stdio.h>

main(int argc, char** argv)
{
   FILE* fp = stdin;
   char buffer[501];
   int column = 0;

   if (argc < 3 || !sscanf(argv[1], "%d", &column)
       || column < 1 || column > 500) {
      puts("Usage: lsf <column:1-500> <string>");
      exit(1);
   }

   while (fgets(buffer, 501, fp))
      if (column <= strlen(buffer)
          && !strncmp(buffer + column - 1, argv[2], strlen(argv[2])))
         printf(buffer);
}


