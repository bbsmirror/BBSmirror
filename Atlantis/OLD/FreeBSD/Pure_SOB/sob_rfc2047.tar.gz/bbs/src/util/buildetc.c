/*-------------------------------------------------------*/
/* util/buildir.c       ( NTHU CS MapleBBS Ver 2.36 )    */
/*-------------------------------------------------------*/
/* target : Maple/Phoenix/Secret_Lover .ETC ����         */
/* create : 95/03/29                                     */
/* update : 95/12/15                                     */
/*-------------------------------------------------------*/


#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/dir.h>
#include <fcntl.h>
#include <time.h>
#include <string.h>
#include "config.h"
#include "struct.h"

char* bdir;


filt(fileheader* fhdr)
{
   char src[100], dst[100];

   if (fhdr->owner[strlen(fhdr->owner) - 1] == '.')
      return 0;
   sprintf(src, "%s/%s", bdir, fhdr->filename);
   *fhdr->filename = 'E';
   sprintf(dst, "%s/%s", bdir, fhdr->filename);
   link(src, dst);
   return 1;
}

int alphasort();


int
dirselect(dir)
  struct direct *dir;
{
  register char *name = dir->d_name;
  return (name[0] == 'M' && name[1] == '.');
}


main(argc, argv)
  int argc;
  char **argv;
{
  int fdir, i, j, wrong;
  struct stat st;
  char genbuf[512], path[256], *ptr, *name;
  FILE *fp;
  int total, count;
  fileheader fhdr;
  struct direct **dirlist;
  time_t filetime;
  struct tm *ptime;

  if (argc != 2)
  {
    printf("Usage:\t%s <path>\n", argv[0]);
    exit(-1);
  }

  bdir = ptr = argv[1];
  sprintf(path, "%s/.ETC", ptr);
  fdir = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
  if (fdir == -1)
  {
    printf("%s create error\n", path);
    exit(-1);
  }
  sprintf(genbuf, "rm %s/E.*", bdir);
  system(genbuf);


  total = scandir(ptr, &dirlist, dirselect, alphasort);
  ptr = strrchr(path, '.');

  for (count = 0; count < total; count++)
  {
    name = dirlist[count]->d_name;
    strcpy(ptr, name);
    wrong = 0;
    if (!stat(path, &st))
    {
      wrong = 1;

      if (st.st_size && (fp = fopen(path, "r")))
      {
        fgets(genbuf, 256, fp);
        if (!strncmp(genbuf, "�@��: ", 6) ||
          !strncmp(genbuf, "�o�H�H: ", 8))
        {
          bzero(&fhdr, sizeof(fhdr));
          i = 5;
          while (genbuf[i] != ' ')
            i++;

          while (genbuf[i] == ' ')
            i++;

          j = i + 1;
          while (genbuf[j] != ' ')
            j++;

          strcpy(fhdr.filename, name);
          filetime = atoi(name + 2);
          j -= i;
          if(j > IDLEN +1)
           j = IDLEN+1;
          strncpy(fhdr.owner, &genbuf[i], j);
          strtok(fhdr.owner, " .@\t\n\r");
          if (strtok(NULL, " .@\t\n\r") || !strncmp(genbuf, "�o�H�H: ", 8))
            strcat(fhdr.owner, ".");

          while (fgets(genbuf, 256, fp))
          {
            if (!strncmp(genbuf, "���D: ", 6) ||
              !strncmp(genbuf, "��  �D: ", 8))
            {
              i = 5;
              while (genbuf[i] != ' ')
                i++;

              while (genbuf[i] == ' ')
                i++;

              if (name = strchr(genbuf + i, '\n'))
                name[0] = '\0';
              strncpy(fhdr.title, genbuf + i, TTLEN);

              if (filetime > 740000000)
              {
                ptime = localtime(&filetime);
                sprintf(fhdr.date, "%2d/%02d", ptime->tm_mon + 1, ptime->tm_mday);
              }
              else
              {
                strcpy(fhdr.date, "     ");
              }
              if (filt(&fhdr))
                 write(fdir, &fhdr, sizeof(fhdr));
              wrong = 0;
              break;
            }
          }
        }
        fclose(fp);
      }
    }

    if (wrong)
    {
      printf("rm %s", path);
      /* unlink(path); */
    }
  }
  close(fdir);
}
