#include <stdio.h>
#include "bbs.h"

#define DOTPASSWDS "/home/bbs/.PASSWDS"
#define PASSWDSBAK "/home/bbs/PASSWDS"
#define TMPFILE    "/home/bbs/tmpfile"

struct userec cuser;

main()
{
    FILE *foo1, *foo2;
    int cnum,i,match;

    if( ((foo1=fopen(DOTPASSWDS, "r")) == NULL)
                || ((foo2=fopen(TMPFILE,"w"))== NULL) ){
        puts("file opening error");
        exit(1);
    }

    while( (cnum=fread( &cuser, sizeof(cuser), 1, foo1))>0 ) {
       if (cuser.sex > 7)
          cuser.sex = 7;
       fwrite( &cuser, sizeof(cuser), 1, foo2);
    }
    fclose(foo1);
    fclose(foo2);

    if(rename(DOTPASSWDS,PASSWDSBAK)==-1){
        puts("replace fails");
        exit(1);
    }
    unlink(DOTPASSWDS);
    rename(TMPFILE,DOTPASSWDS);
    unlink("tmpfile");

    exit(0);
}
