/*-------------------------------------------------------*/
/* util/pn2sobman.c      ( MapleBBS Ver 2.36.sob)        */
/*-------------------------------------------------------*/
/* target : Maple.sob ��ذ��ഫ�{�� (.Names -> .DIR)    */
/* Maple 2.39 .Names -> .DIR; <dir name>/ -> sobman/     */
/* create : 96/12/28                                     */
/* update : 97/06/29                                     */
/*-------------------------------------------------------*/
/* syntax : maple2sobman <dir name>                      */
/*-------------------------------------------------------*/


#include <sys/file.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include "config.h"
#include "struct.h"


#define MAXITEMS        160     /* �@�h�ؿ����̦h���X���H */


typedef struct {
  char name[256];
  char fdate[9];                /* [mm/dd/yy] */
  char title[TTLEN+1];
  char owner[IDLEN + 1];
} ITEM;


int
dashf(fname)
  char *fname;
{
  struct stat st;

  return (stat(fname, &st) == 0 && S_ISREG(st.st_mode));
}


int
dashd(fname)
  char *fname;
{
  struct stat st;

  return (stat(fname, &st) == 0 && S_ISDIR(st.st_mode));
}


int
dashl(fname)
  char *fname;
{
  struct stat st;

  return (lstat(fname, &st) == 0 && S_ISLNK(st.st_mode));
}


stamp(char *fpath, fileheader* fh, ITEM item, int type)
{
   register char *ip = fpath;
   time_t dtime;
   struct tm *ptime;
   int fp;
   char Type[] = "MDS";

   if (access(fpath, X_OK | R_OK | W_OK))
      mkdir(fpath, 0755);

   time(&dtime);
   ptime = localtime(&dtime);
   if (sscanf(item.fdate, "%d/%d/%d",
              &ptime->tm_mon, &ptime->tm_mday, &ptime->tm_year) == 3) {
      --ptime->tm_mon;
      dtime = mktime(ptime);
   }
   while (*(++ip));
   *ip++ = '/';
   while (1) {
      sprintf(ip, "%c.%d.A", Type[type], ++dtime);
      if (type == 0)
         if  ((fp = open(fpath, O_CREAT | O_EXCL | O_WRONLY, 0644)) != -1) {
            close(fp);
            break;
         }
         else
            continue;
      if (type == 1)
         if (mkdir(fpath, 0755) != -1)
            break;
         else
            continue;
      if (symlink("temp", fpath) != -1)
         break;
   }
   memset(fh, 0, sizeof(fileheader));
   strcpy(fh->filename, ip);
   *fh->owner = 0;
   ptime = localtime(&dtime);
   sprintf(fh->date, "%2d/%02d", ptime->tm_mon + 1, ptime->tm_mday);
}



static int loaditems(path, items)
  char *path;
  ITEM *items;
{
  char buf[256], *ptr;
  FILE *fn;
  int num;

  sprintf(buf, "%s/.Names", path);
  num = 0;
  if (fn = fopen(buf, "r")) {
    while (fgets(buf, 255, fn)) {
      if (ptr = strchr(buf, '\n'))
        *ptr = '\0';
      ptr = buf + 5;
      if (!strncmp(buf, "Name=", 5))
        strncpy(items[num].title, ptr + 3, TTLEN - 3);
/*
        strncpy(items[num].title, ptr, TTLEN);
*/
      else if (!strncmp(buf, "Edit=", 5))
        strncpy(items[num].owner, ptr, IDLEN);
      else if (!strncmp(buf, "Date=", 5))
        strcpy(items[num].fdate, ptr);
      else if (!strncmp(buf, "Path=", 5)) {
        strcpy(items[num].name, ptr);
        if (ptr = strchr(items[num++].name, '/'))
          *ptr = '\0';
        if (num == MAXITEMS)
          break;
        items[num].title[0] = '\0';
      }
    }
    fclose(fn);
  }

  return num;
}


static void transfer(old, new)
  char *old;
  char *new;
{
  ITEM items[MAXITEMS];
  fileheader item;
  char fpath[256], buf[256];
  FILE *fn;
  int num, i;


  memset(items, 0, sizeof(items));
  printf("transfer: %s\n", old);
  sprintf(buf, "%s/.DIR", new);
  if (fn = fopen(buf, "w")) {
    num = loaditems(old, items);
    for (i = 0; i < num; i++) {
      strcpy(fpath, new);
      sprintf(buf, "%s/%s", old, items[i].name);

      if (dashl(buf)) {
        printf("detect a symbolic link: %s\n", buf);
        continue;
      }

      else if (dashf(buf)) {
        stamp(fpath, &item, items[i], 0);
        sprintf(buf, "cp %s/%s %s", old, items[i].name, fpath);
        system(buf);
        sprintf(item.title, "�� %s", items[i].title);
      }

      else if (dashd(buf)) {
        stamp(fpath, &item, items[i], 1);
        transfer(buf, fpath);
        sprintf(item.title, "�� %s", items[i].title);
      }
      else
        continue;
      strcpy(item.owner, items[i].owner);
      fwrite(&item, sizeof item, 1, fn);
    }
    fclose(fn);
  }
}


void main(int argc, char** argv) {
  char fpath[MAXPATHLEN], buf[MAXPATHLEN];

  if (argc < 2 || !dashd(argv[1])) {
     puts("Transform: Maple 2.39 .Names -> sob .DIR");
     puts("Usage: maple2sobman <dir name>");
     exit(1);
  }
  if (mkdir(strcpy(fpath, "sobman"), 0755)) {
     puts("ERROR: can't mkdir sobman");
     exit (1);
  }
  strcpy(buf, argv[1]);
  transfer(buf, fpath);
  puts("\nFinished");
}
