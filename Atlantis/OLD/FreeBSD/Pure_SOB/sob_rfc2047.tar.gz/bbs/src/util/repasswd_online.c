/*
�N�Ҧ� bad_user_id �M���C

�i�b bbs �B�@�ɰ���C

�Y�n�^�_��ק�e�����A:
cp ~bbs/PASSWDS ~bbs/.PASSWDS

*/

#include <stdio.h>
#include "bbs.h"

#define DOTPASSWDS "/home/bbs/.PASSWDS"
#define PASSWDSBAK "/home/bbs/PASSWDS"
#define TMPFILE    "/home/bbs/tmpfile"


struct userec cuser;

main()
{
    FILE *foo1, *foo2;
    int cnum,i,match;

    setgid(BBSGID);
    setuid(BBSUID);
    if( ((foo1=fopen(DOTPASSWDS, "r")) == NULL)
                || ((foo2=fopen(TMPFILE,"w"))== NULL) ){
        puts("file opening error");
        exit(1);
    }

    while( (cnum=fread( &cuser, sizeof(cuser), 1, foo1))>0 ) {
       if (bad_user_id(cuser.userid))
          memset(&cuser, 0, sizeof(cuser));
       fwrite( &cuser, sizeof(cuser), 1, foo2);
    }
    fclose(foo1);
    fclose(foo2);

    if(rename(DOTPASSWDS,PASSWDSBAK)==-1){
        puts("replace fails");
        exit(1);
    }
    unlink(DOTPASSWDS);
    rename(TMPFILE,DOTPASSWDS);
    unlink("tmpfile");

    return 0;
}


bad_user_id(userid)
  char *userid;
{
  register char ch;

  if (strlen(userid) < 2)
    return 1;

  if (!isalpha(*userid))
    return 1;

  if (!strcasecmp(userid, "new"))
    return 1;

  while (ch = *(++userid))
  {
    if (!isalnum(ch))
      return 1;
  }
  return 0;
}
