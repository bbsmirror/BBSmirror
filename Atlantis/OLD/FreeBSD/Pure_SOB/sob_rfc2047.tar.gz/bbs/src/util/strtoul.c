#ifdef SunOS
unsigned long strtoul(char* str, char** ptr, int base)
{
   return strtol(str, ptr, base);
}
#endif
