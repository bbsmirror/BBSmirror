/*-------------------------------------------------------*/
/* util/transman.c      ( MapleBBS Ver 2.36.sob)         */
/*-------------------------------------------------------*/
/* target : Maple.sob ��ذ��ഫ�{�� (.Names -> .DIR)    */
/* create : 96/09/11                                     */
/* update : 96/09/11                                     */
/*-------------------------------------------------------*/
/* syntax : transman                                     */
/*-------------------------------------------------------*/


#include <sys/file.h>
#include <sys/stat.h>
#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include "config.h"
#include "struct.h"


#define MAXITEMS        160     /* �@�h�ؿ����̦h���X���H */


typedef struct {
  char name[256];
  char fdate[9];                /* [mm/dd/yy] */
  char title[TTLEN+1];
} ITEM;


int
dashf(fname)
  char *fname;
{
  struct stat st;

  return (stat(fname, &st) == 0 && S_ISREG(st.st_mode));
}


int
dashd(fname)
  char *fname;
{
  struct stat st;

  return (stat(fname, &st) == 0 && S_ISDIR(st.st_mode));
}


int
dashl(fname)
  char *fname;
{
  struct stat st;

  return (lstat(fname, &st) == 0 && S_ISLNK(st.st_mode));
}


stamp(char *fpath, fileheader* fh, ITEM item, int type)
{
   register char *ip = fpath;
   time_t dtime;
   struct tm *ptime;
   int fp;
   char Type[] = "MDS";

   if (access(fpath, X_OK | R_OK | W_OK))
      mkdir(fpath, 0755);

   time(&dtime);
   ptime = localtime(&dtime);
   if (sscanf(item.fdate, "%d/%d/%d",
              &ptime->tm_mon, &ptime->tm_mday, &ptime->tm_year) == 3) {
      --ptime->tm_mon;
      dtime = mktime(ptime);
   }
   while (*(++ip));
   *ip++ = '/';
   while (1) {
      sprintf(ip, "%c.%d.A", Type[type], ++dtime);
      if (type == 0)
         if  ((fp = open(fpath, O_CREAT | O_EXCL | O_WRONLY, 0644)) != -1) {
            close(fp);
            break;
         }
         else
            continue;
      if (type == 1)
         if (mkdir(fpath, 0755) != -1)
            break;
         else
            continue;
      if (symlink("temp", fpath) != -1)
         break;
   }
   memset(fh, 0, sizeof(fileheader));
   strcpy(fh->filename, ip);
   *fh->owner = 0;
   ptime = localtime(&dtime);
   sprintf(fh->date, "%2d/%02d", ptime->tm_mon + 1, ptime->tm_mday);
}



static int loaditems(path, items)
  char *path;
  ITEM *items;
{
  char buf[256], *ptr;
  FILE *fn;
  int num;

  sprintf(buf, "%s/.Names", path);
  num = 0;
  if (fn = fopen(buf, "r")) {
    while (fgets(buf, 255, fn)) {
      if (ptr = strchr(buf, '\n'))
        *ptr = '\0';
      ptr = buf + 5;
      if (!strncmp(buf, "Name=", 5))
        strncpy(items[num].title, ptr, TTLEN);
      else if (!strncmp(buf, "Date=", 5))
        strcpy(items[num].fdate, ptr);
      else if (!strncmp(buf, "Path=", 5)) {
        strcpy(items[num].name, ptr);
        if (ptr = strchr(items[num++].name, '/'))
          *ptr = '\0';
        if (num == MAXITEMS)
          break;
        items[num].title[0] = '\0';
      }
    }
    fclose(fn);
  }

  return num;
}


static void transfer(old, new)
  char *old;
  char *new;
{
  ITEM items[MAXITEMS];
  fileheader item;
  char fpath[256], buf[256];
  FILE *fn;
  int num, i;


  printf("transfer: %s\n", old);
  sprintf(buf, "%s/.DIR", new);
  if (fn = fopen(buf, "w")) {
    num = loaditems(old, items);
    for (i = 0; i < num; i++) {
      strcpy(fpath, new);
      sprintf(buf, "%s/%s", old, items[i].name);

      if (dashl(buf)) {
        printf("detect a symbolic link: %s\n", buf);
        continue;
      }

      else if (dashf(buf)) {
        stamp(fpath, &item, items[i], 0);
        sprintf(buf, "cp %s/%s %s", old, items[i].name, fpath);
        system(buf);
      }

      else if (dashd(buf)) {
        stamp(fpath, &item, items[i], 1);
        transfer(buf, fpath);
      }

      else
        continue;

      strcpy(item.title, items[i].title);
      fwrite(&item, sizeof item, 1, fn);
    }
    fclose(fn);
  }
}


static int loadboards(boards)
  ITEM *boards;
{
  FILE *fn;
  boardheader item;
  int num, i;

  num = 0;
  if (fn = fopen(".BOARDS", "r")) {
    while (fread(&item, sizeof item, 1, fn)) {
      strcpy(boards[num].name, item.brdname);
      if (boards[num].name[0]) {
        for (i = 0; i < num; i++)
          if (!strcmp(boards[num].name, boards[i].name))
            break;
        if (i == num)
          num++;
      }
    }
    fclose(fn);
  }

  return num;
}


void main(void) {
  ITEM boards[MAXBOARD];
  ITEM items[MAXITEMS];
  fileheader item;
  char fpath[256], buf[256];
  FILE *fn;
  int bnum, num, i, j;

  chdir(BBSHOME);
  mkdir("man/boards", 0755);
  memset(boards, 0, sizeof(boards));

  bnum = loadboards(boards);
  for (i = 0; i < bnum; i++) {
    sprintf(fpath, "man/boards/%s", boards[i].name);
    mkdir(fpath, 0755);
    sprintf(buf, "man/%s", boards[i].name);
    transfer(buf, fpath);
  }

  if (fn = fopen("man/.DIR", "w")) {
    num = loaditems("man", items);
    for (i = 0; i < num; i++) {
      strcpy(fpath, "man");
      sprintf(buf, "man/%s", items[i].name);
      printf("main loop: %s\n", buf);
      for (j = 0; j < bnum; j++)
        if (!strcmp(boards[j].name, items[i].name))
          break;

      if (j < bnum) {
        stamp(fpath, &item, boards[j], 2);
        unlink(fpath);
        sprintf(buf, "%s/man/boards/%s", BBSHOME, boards[j].name);
        if (symlink(buf, fpath) == -1)
          continue;
      }

      else if (dashl(buf)) {
        printf("detect a symbolic link: %s\n", buf);
        continue;
      }

      else if (dashf(buf)) {
        stamp(fpath, &item, items[i], 0);
        sprintf(buf, "cp man/%s %s", items[i].name, fpath);
        system(buf);
      }

      else if (dashd(buf)) {
        stamp(fpath, &item, items[i], 1);
        transfer(buf, fpath);
      }

      else
        continue;

      strcpy(item.title, items[i].title);
      fwrite(&item, sizeof item, 1, fn);
    }
    fclose(fn);
  }
  puts("\nFinished");
}
