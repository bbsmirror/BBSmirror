/*
 *   MAXLOAD �w�q�C�� process �̤j���\�� load �C
 *   inlist() �Цۦ�ק�A�i�H���� killbbs ���� PROCESS NAME
 *   killbbs      �i�C�X�ثe�{�����A�C
 *   killbbs list �i�C�X�ثe load �L�j���{���C
 *   killbbs kill �i�屼 load �L�j���{���C
 *   ���{���u�A�Ω� Solaris 2.x �����C
 *   �sĶ�覡: gcc -o killbbs killbbs.c
 */ 

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <signal.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/procfs.h>
#include <pwd.h>

#define  MAXLOAD   5

prpsinfo_t  proc_ps;

inlist(cmd)
char *cmd;
{
   if (!strcmp("/home/bbs/bin/mbbsd.d 23", cmd))
      return 1;
   if (!strcmp("bpop3d", cmd))
      return 1;
   return 0;
}

main(argc,argv)
int  argc;
char *argv[];
{
    char  fname[BUFSIZ];
    register int i;
    int   p_fd;
    int   killd = 0 ;
    DIR   *dirfd;
    float pscpu;
    struct dirent *dir;
    struct passwd *upwd;

    if ( argc <= 1 )
        killd = 0 ; 
    else
    {
       if ( argc > 2 ) {
          printf("./killbbs or ./killbbs list or ./killbbs kill\n");
          exit(0);
       }
       if ( !strcmp ( "kill" , argv[1] ) )
          killd = 1 ;
       else if ( !strcmp ( "list" , argv[1] ) )
          killd = 2 ;
       else
          killd = 0 ;
    }

     dirfd =  opendir("/proc");

     while ( dir = ( struct dirent * ) readdir(dirfd) )
     {


       if ( strcmp( dir->d_name , "." ) == 0 || strcmp ( dir->d_name , "..") == 0 ) 
       continue ;

       sprintf( fname , "/proc/%s" , dir->d_name );
       p_fd = open( fname , O_RDONLY ) ;
       ioctl( p_fd , PIOCPSINFO , &proc_ps ) ;
       upwd = ( struct passwd * ) getpwuid(proc_ps.pr_uid);
       if ( !upwd )
       {
                fprintf( stderr , "Can't find uid %u\n",proc_ps.pr_uid );
                continue ;
       }
       pscpu =  ( ( float ) proc_ps.pr_pctcpu / FSCALE ) ;
       if ( killd == 0 )
           printf("%6d %6d  %2.2f  %-10s %s \n",proc_ps.pr_pid , proc_ps.pr_ppid , pscpu , upwd->pw_name , proc_ps.pr_psargs );
       if ( killd == 2 &&  pscpu >= MAXLOAD && inlist(proc_ps.pr_psargs) )
           printf("%6d %6d  %2.2f  %-10s %s \n",proc_ps.pr_pid , proc_ps.pr_ppid , pscpu , upwd->pw_name , proc_ps.pr_psargs );
       if ( killd == 1 &&  pscpu >= MAXLOAD && inlist(proc_ps.pr_psargs) ) {
          if ( sigsend(P_PID, proc_ps.pr_pid ,SIGKILL) != -1 )
              printf("Success to kill pid = %6d %s \n",proc_ps.pr_pid , proc_ps.pr_psargs  );
          else
              printf("Fail to kill pid = %6d %s \n",proc_ps.pr_pid , proc_ps.pr_psargs  );

       }
       close ( p_fd ) ;
     }

     closedir(dirfd);
}
