
#include        "bbs.h" 

userec record;


main()
{

  FILE *fp, *fp1;
  char dir[1000][30];
  char account[1000][30];
  char genbuf[30];
  int i,j,k,l,pass;

  i = 1;
  j = 0;

  system("cd /home/bbs/home;ls >/home/bbs/test");

  if (fp1 = fopen ("/home/bbs/test","r"))
  {
     while(fscanf(fp1, "%s", genbuf) != EOF)
     {
       i++;
       strncpy(dir[i], genbuf, strlen(genbuf)-1);
     }
     fclose(fp1);
     system("rm -f /home/bbs/test");
  }

  if (fp = fopen("/home/bbs/.PASSWDS", "rb"))
  {
     while (fread(&record, sizeof(record), 1, fp))
     {
        j++;
        strcpy(account[j],record.userid); 
     }

  fclose(fp);
  }

  for(k = 1; k < i; k++)
  { 
    pass = 0;
    for(l = 1; l <= j; l++)
    {
      if(!strcmp(dir[k], account[l]))
      {
          pass = 1;
          break; 
      }
    }

    if(!pass)
    { 
      char buf[256];
      printf("%s\n", dir[k]);
      sprintf(buf, "mv /home/bbs/home/%s /home/bbs/tmp1", dir[k]);
      system(buf);
    }
  } 
}
