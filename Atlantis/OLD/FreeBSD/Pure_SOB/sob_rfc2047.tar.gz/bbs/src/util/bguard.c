/*-------------------------------------------------------*/
/* util/bguard.c        ( NTHU CS MapleBBS Ver 3.00 )    */
/*-------------------------------------------------------*/
/* target : BBS finger daemon �C�X�����ϥΪ̸��         */
/* create : 95/03/29                                     */
/* update : 96/11/15                                     */
/*-------------------------------------------------------*/
/* syntax : bguard                                       */
/*-------------------------------------------------------*/
/* notice : utmpshm (utmp shared memory) synchronize     */
/*-------------------------------------------------------*/


#define _MODES_C_
#undef  DEBUG

#include "bbs.h"

#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/mman.h>

#include <sys/wait.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <netdb.h>
#include <syslog.h>


#define GUARD_LOGFILE   BBSHOME "/run/bguard.log"
#define GUARD_PIDFILE   BBSHOME "/run/bguard.pid"


#define GUARD_INTERVAL  66      /* check system load */
#define GUARD_SYNC      7       /* synchronize shared memory */
#define GUARD_FREEDOM   2


#define FINGER_PORT     79
#define FINGER_TIMEOUT  (60 * 2)


#define TCP_QLEN        5
#define TCP_BUFSIZ      4096
#define TCP_LINSIZ      256
#define TCP_RCVSIZ      128


/* ----------------------------------------------------- */
/* client connection structure                           */
/* ----------------------------------------------------- */


struct Client
{
  struct Client *next;
  int state;
  int sock;
  time_t uptime;                /* �إ� connection ���ɶ� */

  int count;                    /* �u�W�@���h�֤H�H */
  user_info *uentp;

  char pool[TCP_BUFSIZ];        /* buffered I/O pool */
  int locus;
};
typedef struct Client Client;

char *fn_passwd = BBSHOME "/.PASSWDS";
FILE* fp_asswd;
int usernumber;
time_t start_time;

Client *cnlist;


/* ----------------------------------------------------- */
/* connection state                                      */
/* ----------------------------------------------------- */


#define CS_FREE         0x00
#define CS_READING      0x01
#define CS_WRITING      0x02


/* ----------------------------------------------------- */
/* operation log and debug information                   */
/* ----------------------------------------------------- */


int flog;                       /* log file descriptor */


#ifndef BSD44
extern char *sys_errlist[];
#endif
extern int errno;


void
logit(key, msg)
  char *key;
  char *msg;
{
  time_t now;
  struct tm *p;
  char buf[256];

  time(&now);
  p = localtime(&now);
  sprintf(buf, "%02d/%02d/%02d %02d:%02d:%02d %-8s%s\n",
    p->tm_year, p->tm_mon + 1, p->tm_mday,
    p->tm_hour, p->tm_min, p->tm_sec, key, msg);
  write(flog, buf, strlen(buf));
}


void
log_init()
{
  flog = open(GUARD_LOGFILE, O_WRONLY | O_CREAT | O_APPEND, 0644);
  logit("START", "guard (finger) daemon");
}


void
log_close()
{
  close(flog);
}


/*-------------------------------------------------------*/
/* .UTMP cache                                           */
/*-------------------------------------------------------*/


struct UTMPFILE *utmpshm;
user_info *ushm_head, *ushm_tail;


static void
attach_err(shmkey, name)
  int shmkey;
  char *name;
{
  char buf[80];

  sprintf(buf, "error, key = %x", shmkey);
  logit(name, buf);
  syslog(LOG_NOTICE, "attach err, exit\n");
  exit(1);
}


static void *
attach_shm(shmkey, shmsize)
  int shmkey, shmsize;
{
  void *shmptr;
  int shmid;

  shmid = shmget(shmkey, shmsize, 0);
  if (shmid < 0)
  {
    shmid = shmget(shmkey, shmsize, IPC_CREAT | 0600);
    if (shmid < 0)
      attach_err(shmkey, "shmget");
    shmptr = (void *) shmat(shmid, NULL, 0);
    if (shmptr == (void *) -1)
      attach_err(shmkey, "shmat");
    memset(shmptr, 0, shmsize);
  }
  else
  {
    shmptr = (void *) shmat(shmid, NULL, 0);
    if (shmptr == (void *) -1)
      attach_err(shmkey, "shmat");
  }
  return shmptr;
}


void
resolve_utmp()
{
  if (utmpshm == NULL)
  {
    register struct UTMPFILE *ushm;
    register user_info *uentp;

    utmpshm = ushm = attach_shm(UTMPSHM_KEY, sizeof(*utmpshm));

    /* only added in bguard.c */

    ushm_head = uentp = ushm->uinfo;
    ushm_tail = uentp + USHM_SIZE;
  }
}


void
ushm_guard()
{
  register int count, *busy;
  register time_t timeout;
  register user_info *uentp, *utail;
  register int sig;
  register pid_t pid;

  count = 0;
  uentp = ushm_head;
  utail = ushm_tail;
  busy = &utmpshm->busystate;
  while (*busy)
  {
    if (++count > 10)
      return;
    sleep(3);
  }

  *busy = 1;

  /* ------------------------------------ */
  /* for ���F�ǻ�: �C SYNC_INT ����s�@�� */
  /* ------------------------------------ */

  count = 0;
  timeout = time(NULL) - IDLE_TIMEOUT - 60;

  do
  {
    if (pid = uentp->pid)
    {
      errno = sig = 0;

      if (!(PERM_HIDE(uentp) || uentp->mode == MAILALL)
          && uentp->uptime < timeout)
        sig = SIGHUP;           /* SIGHUP / SIGBUS ... */

      if ((kill(pid, sig) < 0) && (errno == ESRCH))
      {
        (void) memset(uentp, 0, sizeof(user_info));
      }
      else
      {
        if (!sig)
          count++;
      }
    }
  } while (++uentp < utail);

  utmpshm->number = count;

  *busy = 0;

#ifdef  DEBUG
  {
    static int loop = 0;
    char buf[80];

    sprintf(buf, "%d", ++loop);
    logit("USHM", buf);
  }
#endif
}

struct UCACHE *uidshm;

/*-------------------------------------------------------*/
/* .PASSWDS cache                                        */
/*-------------------------------------------------------*/


#ifndef HAVE_MMAP
static int
fillucache(uentp)
  userec *uentp;
{
  if (usernumber < MAXUSERS)
  {
    strncpy(uidshm->userid[usernumber], uentp->userid, IDLEN + 1);
    uidshm->userid[usernumber++][IDLEN] = '\0';
  }
  return 0;
}
#endif


/* -------------------------------------- */
/* (1) �t�αҰʫ�A�Ĥ@�� BBS user ��i�� */
/* (2) .PASSWDS ��s��                    */
/* -------------------------------------- */

/*
woju
*/
#define BUFSIZE 256

int
apply_record(fpath, fptr, size)
  char *fpath;
  int (*fptr) ();
int size;
{
  char abuf[BUFSIZE];
  FILE* fp;

  if (!(fp = fopen(fpath, "r")))
    return -1;

  while (fread(abuf, 1, size, fp) == size)
     if ((*fptr) (abuf) == QUIT) {
        fclose(fp);
        return QUIT;
     }
  fclose(fp);
  return 0;
}



reload_ucache()
{
   if (uidshm->busystate)
   {
     /* ------------------------------------------ */
     /* ��L user ���b flushing ucache ==> CSMA/CD */
     /* ------------------------------------------ */

     if (uidshm->touchtime - uidshm->uptime > 30)
     {
       uidshm->busystate = 0;  /* leave busy state */

#if !defined(_BBS_UTIL_C_)
       log_usies("CACHE", "refork token");
#endif
     }
     else
       sleep(1);
   }
   else
   {
     uidshm->busystate = 1;    /* enter busy state */

#ifdef  HAVE_MMAP
     {
       register int fd, usernumber;

       usernumber = 0;

       if ((fd = open(fn_passwd, O_RDONLY)) > 0)
       {
         caddr_t fimage, mimage;
         struct stat stbuf;

         fstat(fd, &stbuf);
         fimage = mmap(NULL, stbuf.st_size, PROT_READ, MAP_SHARED, fd, 0);
         if (fimage == (char *) -1) {
           logit("EXIT", "MMAP");
           syslog(LOG_NOTICE, "mmap err, exit\n");
           exit(-1);
         }
         close(fd);
         fd = stbuf.st_size / sizeof(userec);
         if (fd > MAXUSERS)
           fd = MAXUSERS;
         for (mimage = fimage; usernumber < fd; mimage += sizeof(userec))
         {
           memcpy(uidshm->userid[usernumber++], mimage, IDLEN);
         }
         munmap(fimage, stbuf.st_size);
       }
       uidshm->number = usernumber;
     }
#else
     usernumber = 0;
     apply_record(fn_passwd, fillucache, sizeof(userec));
     uidshm->number = usernumber;
#endif

     /* �� user ��Ƨ�s��A�]�w uptime */
     uidshm->uptime = uidshm->touchtime;

#if !defined(_BBS_UTIL_C_)
     log_usies("CACHE", "reload ucache");
#endif

     uidshm->busystate = 0;    /* leave busy state */
   }
}


void
resolve_ucache()
{
  if (uidshm == NULL)
  {
    uidshm = attach_shm(UIDSHM_KEY, sizeof(*uidshm));
    if (uidshm->touchtime == 0)
      uidshm->touchtime = 1;
  }

  while (uidshm->uptime < uidshm->touchtime)
     reload_ucache();
}



/*-------------------------------------------------------*/
/* check system / memory / CPU loading                   */
/*-------------------------------------------------------*/

char maple[64];

int
chkload(limit)
  int limit;
{
  double cpu_load[3];
  register int i;
  long avenrun[3];

#if defined(LINUX)
  FILE *fp;

  fp = fopen("/proc/loadavg", "r");
  if (!fp)
    cpu_load[0] = cpu_load[1] = cpu_load[2] = 0;
  else
  {
    float av[3];

    fscanf(fp, "%g %g %g", av, av + 1, av + 2);
    fclose(fp);
    cpu_load[0] = av[0];
    cpu_load[1] = av[1];
    cpu_load[2] = av[2];
  }
#elif defined(BSD44)
  getloadavg(cpu_load, 3);
#else

#include <nlist.h>
#define VMUNIX  "/vmunix"
#define KMEM    "/dev/kmem"

  static struct nlist nlst[] = {
    {"_avenrun"},
    {0}
  };
  static long offset = -1;

  int kmem;

  if ((kmem = open(KMEM, O_RDONLY)) == -1)
    return (1);

  if (offset < 0)
  {
    (void) nlist(VMUNIX, nlst);
    if (nlst[0].n_type == 0)
      return (1);
    offset = (long) nlst[0].n_value;
  }
  if (lseek(kmem, offset, L_SET) == -1)
  {
    close(kmem);
    return (1);
  }
  if (read(kmem, (char *) avenrun, sizeof(avenrun)) == -1)
  {
    close(kmem);
    return (1);
  }
  close(kmem);
#define loaddouble(la) ((double)(la) / (1 << 8))

  for (i = 0; i < 3; i++)
    cpu_load[i] = loaddouble(avenrun[i]);
#endif

  i = cpu_load[0];
  if (i < limit)
    i = 0;
  sprintf(maple, "�t�έt�� %.2f %.2f %.2f%s",
    cpu_load[0], cpu_load[1], cpu_load[2],
    (i ? "�A�еy��A��\n" : ""));

  return i;
}

/* ----------------------------------------------------- */
/* server side stuff                                     */
/* ----------------------------------------------------- */


void
date_string(str, date)
  char *str;
  time_t *date;
{
  struct tm *t = localtime(date);
  static char week[] = "��@�G�T�|����";

  sprintf(str, "%d�~%2d��%2d��%3d:%02d:%02d �P��%.2s",
    t->tm_year - 11, t->tm_mon + 1, t->tm_mday,
    t->tm_hour, t->tm_min, t->tm_sec, &week[t->tm_wday << 1]);
}

char*
mail_string(char* currmaildir)
{
  struct stat st;
  fileheader fh;
  int fd;
  register numfiles;
  unsigned char ch;
  static char* answer[] = {"���ݹL�F", "���s�H��"};

  if (stat(currmaildir, &st) < 0)
    return answer[0];
  numfiles = st.st_size / sizeof(fileheader);
  if (numfiles <= 0)
    return answer[0];

  /* ------------------------------------------------ */
  /* �ݬݦ��S���H���٨SŪ�L�H�q�ɧ��^�Y�ˬd�A�Ĳv���� */
  /* ------------------------------------------------ */

  if ((fd = open(currmaildir, O_RDONLY)) > 0)
  {
    lseek(fd, st.st_size - sizeof(fh) + ((char*)&fh.filemode -(char*)&fh), SEEK_SET);
    while (numfiles--)
    {
      read(fd, &ch, 1);
      if (!(ch & FILE_READ))
      {
        close(fd);
        return answer[1];
      }
      lseek(fd, -(off_t)(sizeof(fileheader) + 1), SEEK_CUR);
    }
    close(fd);
  }
  return answer[0];
}



#if 0
woju
char *
mail_string(fpath)
  char *fpath;
{
  char *answer;
  int fd, size;
  struct stat st;

  answer = "���ݹL�F";
  if ((fd = open(fpath, O_RDONLY, 0)) >= 0)
  {
    if (!fstat(fd, &st) && (size = st.st_size) > 0)
    {
      caddr_t fimage, tail;

      fimage = mmap(NULL, size, PROT_READ, MAP_SHARED, fd, 0);
      (void) close(fd);
      if (fimage != (char *) -1)
      {
        fileheader *fhdr;

        fhdr = (fileheader *) (fimage + size);
        while (--fhdr >= (fileheader *) fimage)
        {
          if (fhdr->filemode & FILE_READ == 0)
          {
            answer = "���s�H��";
            break;
          }
        }
      }
      (void) munmap(fimage, size);
    }
  }

  return answer;
}
#endif

typedef struct userec ACCT;


int
searchuser(userid)
  char *userid;
{
  register char *ptr;
  register int i, j;

  resolve_ucache();
  i = 0;
  j = uidshm->number;
  while (i < j)
  {
    ptr = uidshm->userid[i++];
    if (!strcasecmp(ptr, userid))
    {
      strcpy(userid, ptr);
      return i;
    }
  }
  return 0;
}



void
serve_finger(cn)
  Client *cn;
{
  char *base, *head, fpath[128];
  ACCT acct;
  user_info *uentp, *utail;
  int userid;
  FILE* fp;
  int fd;

  base = head = cn->pool;

#ifdef  DEBUG
  logit("FINGER", base);
#endif

  if (userid = searchuser(head))
  {
    char *str, *mailstr, *modestr, datestr[40];
    user_info *uentp;
    int len, bytes;

    --userid;
    sprintf(fpath, "home/%s",  head);
    /* �O�_���s�H���٨S�ݡH */

    strcat(fpath, "/.DIR");
    str = strrchr(fpath, '.');
    mailstr = mail_string(fpath);

    /* �O�_�b�u�W�H */

    uentp = ushm_head;
    utail = ushm_tail;
    modestr = "���b���W";
    do
    {
      if (!strcmp(head, uentp->userid))
      {

        if (!PERM_HIDE(uentp))
           modestr = ModeTypeTable[uentp->mode];
        break;
      }
    } while (++uentp <= utail);

    fseek(fp_asswd, userid * sizeof(acct), 0);
    fread(&acct, sizeof(acct), 1, fp_asswd);

    date_string(datestr, &acct.lastlogin);


    sprintf(head, "%s(%s) �@�W�� %d ���A�o���峹 %d �g�C\n"
      "�̪�(%s)�Ӧ�(%s)\n%s�q�L�����{�� [�ʺA] %s [�H�c] %s\n",
      acct.userid, acct.username, acct.numlogins, acct.numposts,
      datestr, acct.lasthost,
      acct.userlevel & PERM_LOGINOK ? "�w�g" : "�|��",
      modestr, mailstr);

    len = strlen(head);
    head += len;

    /* ��� [�W��/�p�e��] */

    strcpy(str, "plans");
    if ((fd = open(fpath, O_RDONLY, 0)) >= 0)
    {
      strcpy(head, "[�p�e]\n");
      len = strlen(head);
      head += len;

      /* ���] buffer ��靈�l�A���Ʊ�²�� */

      len = TCP_BUFSIZ - len - 10;
      bytes = read(fd, head, len);
      close(fd);

      head += bytes;

      strcpy(head, "\033[m");
      head += strlen(head);

      if (bytes >= len)
        *++head = '\n';
    }
  }
  else
  {
    strcat(head, " ==> not exist here.\n");
    head += strlen(head);
  }

  cn->locus = head - base;
  cn->count = -1;       /* �N�� end of transmission */
}


void
serve_userlist(cn)
  Client *cn;
{
  int count;
  user_info *uentp, *utail;
  char *base, *head, *tail;

  count = cn->count;
  uentp = cn->uentp;
  utail = ushm_tail;

  base = cn->pool;
  head = base + cn->locus;
  tail = base + TCP_BUFSIZ - TCP_LINSIZ;

  for (;;)
  {
    if (uentp->pid && !PERM_HIDE(uentp))
    {
      sprintf(head, "%-13s%-25s%-23s%s\n",
        uentp->userid, uentp->username, uentp->from,
        ModeTypeTable[uentp->mode]);
      count++;
      head += strlen(head);
      if (head > tail)
      {
        break;
      }
    }

    if (++uentp >= utail)
    {
      sprintf(head, "\
============ ======================== ====================== ==========\n"
        "�i" BOARDNAME "�j Total users = %d\n", count);
      head += strlen(head);
      count = -1;
      break;
    }
  }

  cn->uentp = uentp;
  cn->count = count;
  cn->locus = head - base;
}


/* ----------------------------------------------------- */
/* client's service dispatcher                           */
/* ----------------------------------------------------- */


void
client_serve(cn)
  Client *cn;
{
  char *cmd, *str;
  int ch;
  char *arg1 = 0;

  cmd = str = cn->pool;
  cn->state = CS_WRITING;

#ifdef  DEBUG
  logit("REQUEST", cmd);
#endif

/*
woju
finger -l woju@localhost => /W woju
*/
  if (*cmd == '/') {
     arg1 = strtok(cmd, " /\t\n");
     str = strtok(0, " \t\r");
     if (str)
        strcpy(cmd, str);
     str = cmd;
  }

  while (ch = *str)
  {
    if (ch != ' ' && ch != '\t')
    {
      if (ch >= 'A' && ch <= 'Z')
        ch |= 0x20;
      else if (ch == '.' || ch == '@')
      {
        *cmd = '\0';
        break;
      }
      *cmd++ = ch;
    }
    str++;
  }

  str = cn->pool;
  if (str == cmd)
  {
    strcpy(str, "\
ID              Nick                    From                    Mode\n\
============ ======================== ====================== ==========\n");
    cn->locus = strlen(str);
    cn->uentp = utmpshm->uinfo;
    cn->state = CS_WRITING;
    serve_userlist(cn);
  }
  else
  {
    serve_finger(cn);
  }
}


/* ----------------------------------------------------- */
/* send output to client                                 */
/* ----------------------------------------------------- */


void
client_write(cn)
  Client *cn;
{
  int csock, len, bytes;
  char *msg;

  len = cn->locus;
  msg = cn->pool;
  csock = cn->sock;
  bytes = write(csock, msg, len);
  if (bytes <= 0)
  {
    logit("write", sys_errlist[errno]);
    (void) close(csock);
    cn->state = CS_FREE;
    return;
  }

  len -= bytes;
  cn->locus = len;
  if (len)
  {
    (void) memcpy(msg, msg + bytes, len);
    return;
  }

  if (cn->count >= 0)
  {
    serve_userlist(cn);
  }
  else
  {
    (void) close(csock);
    cn->state = CS_FREE;
  }
}


/* ----------------------------------------------------- */
/* receive request from client                           */
/* ----------------------------------------------------- */


void
client_read(cn)
  Client *cn;
{
  int pos, bytes, csock;
  char *ip;

  pos = cn->locus;
  ip = &cn->pool[pos];
  csock = cn->sock;
  bytes = read(csock, ip, TCP_RCVSIZ);
  if (bytes <= 0)
  {
    logit("read", sys_errlist[errno]);
    (void) close(csock);
    cn->state = CS_FREE;
  }
  else
  {
    ip[bytes] = '\0';

    while (csock = *ip)
    {
      if (csock == '\r' || csock == '\n')
      {
        *ip = '\0';
        client_serve(cn);
        return;
      }
      ip++;
    }

    cn->locus = pos + bytes;
    /* cn->state = CS_READING;  /* keep on reading command */
  }
}


/* ----------------------------------------------------- */
/* release idle/timeout connections                      */
/* ----------------------------------------------------- */


void
client_free()
{
  Client *cn, *prev, *next;
  int state, freedom;
  time_t timeout;

  freedom = 0;
  timeout = time(NULL) - FINGER_TIMEOUT;

  for (cn = cnlist; cn; cn = next)
  {
    if (state = cn->state)
    {
      if (cn->uptime < timeout)
      {
        (void) close(cn->sock);
        cn->state = state = CS_FREE;
      }
    }

    /* release free client */

    next = cn->next;

    if (state == CS_FREE)
    {
      if (++freedom >= GUARD_FREEDOM)
      {
        prev->next = next;
        (void) free(cn);
        continue;
      }
    }

    prev = cn;
  }

#ifdef  DEBUG
  {
    static int loop = 0;
    char buf[80];

    sprintf(buf, "%d (%d)", ++loop, freedom);
    logit("FREE", buf);
  }
#endif
}


/* ----------------------------------------------------- */
/* accept a new connection                               */
/* ----------------------------------------------------- */


void
client_accept(n)
  int n;
{
  register Client *cn;
  register int csock;
  int value;

  for (;;)
  {
    csock = accept(n, NULL, NULL);
    if (csock >= 0)
      break;
    csock = errno;
    if (csock != EINTR)
    {
      logit("accept", sys_errlist[csock]);
      return;
    }
  }

  /* allocate client's data structure */

  for (cn = cnlist; cn; cn = cn->next)
  {
    if (cn->state == CS_FREE)
    {
      break;
    }
  }

  if (cn == NULL)
  {
    cn = (Client *) malloc(sizeof(Client));
    cn->next = cnlist;
    cnlist = cn;
  }

  /* variable initialization */

  cn->sock = csock;
  cn->state = CS_READING;
  cn->uptime = time(NULL);
  cn->locus = 0;
}


/* ---------------------------------------------------- */
/* server core routines                                 */
/* ---------------------------------------------------- */


int
start_daemon()
{
  int fd, value;
  char buf[80];
  struct sockaddr_in fsin;

  /*
   * More idiot speed-hacking --- the first time conversion makes the C
   * library open the files containing the locale definition and time zone.
   * If this hasn't happened in the parent process, it happens in the
   * children, once per connection --- and it does add up.
   */

  time_t dummy = time(NULL);
  struct tm *dummy_time = localtime(&dummy);
  struct tm *other_dummy_time = gmtime(&dummy);
  strftime(buf, 80, "%d/%b/%Y:%H:%M:%S", dummy_time);

  fd = getdtablesize();

  if (fork())
    exit(0);

  while (fd)
    (void) close(--fd);

  fd = open(GUARD_PIDFILE, O_WRONLY | O_CREAT | O_TRUNC, 0644);
  if (fd >= 0)
  {
    sprintf(buf, "%5d\n", getpid());
    write(fd, buf, 6);
    close(fd);
  }

  if ((fd = open("/dev/tty", O_RDWR)) > 0)
  {
    ioctl(fd, TIOCNOTTY, 0);
    close(fd);
  }

  for (fd = 1; fd < NSIG; fd++)
    (void) signal(fd, SIG_IGN);

  fd = socket(AF_INET, SOCK_STREAM, 0);
  /* fcntl(fd, F_SETFL, O_NDELAY); */

  value = 1;
  setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (char *) &value, sizeof(value));
  setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, (char *) &value, sizeof(value));

  memset((char *) &fsin, 0, sizeof(fsin));
  fsin.sin_family = AF_INET;
  fsin.sin_addr.s_addr = htonl(INADDR_ANY);
  fsin.sin_port = htons(FINGER_PORT);

  if (bind(fd, (struct sockaddr *) & fsin, sizeof(fsin)) < 0) {
    logit("EXIT", "bind error");
    syslog(LOG_NOTICE, "bind error\n");
    exit(1);
  }

  openlog("bguard", LOG_PID, LOG_AUTH);
  syslog(LOG_NOTICE, "start\n");
  return fd;
}


void
abort_server()
{
  if (time(0) - start_time < 60) {
     syslog(LOG_NOTICE, "Got SIGHUP at first 60 secs, ignore");
     return;
  }
  syslog(LOG_NOTICE, "abort");
  log_close();
  fclose(fp_asswd);
  exit(1);
}


void
main()
{
  register int msock, csock, nfds, guard;
  register Client *cn;
  fd_set rset, wset;
  struct timeval tv;

  start_time = time(0);
  msock = start_daemon();

  (void) setgid(BBSGID);
  (void) setuid(BBSUID);
  (void) chdir(BBSHOME);


  log_init();
  if (!(fp_asswd = fopen(fn_passwd, "r"))) {
     logit("EXIT", ".PASSWDS opened error");
     syslog(LOG_NOTICE, ".PASSWDS opened error, exit\n");
     exit(1);
  }



  (void) listen(msock, TCP_QLEN);
  resolve_utmp();
  (void) signal(SIGHUP, abort_server);

  tv.tv_usec = guard = 0;

  for (;;)
  {
    /* Set up the fdsets. */

    FD_ZERO(&rset);
    FD_ZERO(&wset);

    FD_SET(msock, &rset);
    nfds = msock;

    for (cn = cnlist; cn; cn = cn->next)
    {
      csock = cn->sock;

      switch (cn->state)
      {
      case CS_WRITING:
        FD_SET(csock, &wset);
        break;

      case CS_READING:
        FD_SET(csock, &rset);
        break;

      default:
        continue;
      }
      if (nfds < csock)
        nfds = csock;
    }

    tv.tv_sec = GUARD_INTERVAL;
    nfds = select(nfds + 1, &rset, &wset, NULL, &tv);

#ifdef  DEBUG
    {
      static int loop = 0;
      char buf[80];

      sprintf(buf, "%d ==> %d", ++loop, nfds);
      logit("LOOP", buf);

      if (nfds)
      {
        for (csock = 0; csock < 64 ; csock++)
        {
          if (FD_ISSET(csock, &rset))
          {
            sprintf(buf, "%d", csock);
            logit("RSET ", buf);
          }

          if (FD_ISSET(csock, &wset))
          {
            sprintf(buf, "%d", csock);
            logit("WSET ", buf);
          }
        }
      }
    }
#endif

    if (nfds == 0)
    {
      /* system guard / resource and garbage collection */

      chkload();

      guard++;

      if ((guard & 7) == 0)
      {
        ushm_guard();
      }
      else if ((guard & 15) == 0)
      {
        client_free();
      }
      continue;
    }
    else if (nfds < 0)
    {
      csock = errno;
      if (csock != EINTR)
      {
        logit("select", sys_errlist[csock]);
      }
      continue;
    }

    /* serve new connection first */

    if (FD_ISSET(msock, &rset))
    {
      client_accept(msock);
      if (--nfds <= 0)
        continue;
    }

    /* serve active clients */

    for (cn = cnlist; cn; cn = cn->next)
    {
      if (cn->state)
      {
        csock = cn->sock;

        if (FD_ISSET(csock, &wset))
        {
          client_write(cn);
          nfds--;
        }
        else if (FD_ISSET(csock, &rset))
        {
          client_read(cn);
          nfds--;
        }
        if (nfds <= 0)
          break;
      }
    }

    /* tail of main loop */
  }
}
