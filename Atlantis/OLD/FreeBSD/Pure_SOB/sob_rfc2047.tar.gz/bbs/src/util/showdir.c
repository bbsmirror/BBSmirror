/*
Show .DIR contents
*/

#include <stdio.h>
#include "bbs.h"

char*
mono(char* s)
{
   int i, j;
   static char ans[200];

   for (i = j = 0; s[i] && j < 199; i++)
      if (s[i] == KEY_ESC)
         while (s[++i] && s[i] != 'm')
            ;
      else
         ans[j++] = s[i];
   ans[j] = 0;

   return ans;
}


main(int argc, char** argv)
{
   FILE* fp;
   char* fname;

   fname = (argc > 1) ? argv[1] : ".DIR";
   if (fp = fopen(fname, "r")) {
      fileheader fhdr;
      int n = 0;
      char type;

      while (fread(&fhdr, sizeof(fhdr), 1, fp) == 1) {
         fhdr.title[50] = 0;

         if (fhdr.filemode > 3)
            type = '*';
         else
            type = "+ Mm"[fhdr.filemode];
         if (fhdr.filemode & FILE_TAGED)
            type = 'D';
         printf("%3d %c %-51.50s%15s %c\n",
            ++n, type, mono(fhdr.title), fhdr.filename, fhdr.savemode);
      }
      fclose(fp);
   }
   else
      fprintf(stderr, "`%s` opened error (for read)\n", fname);
}
