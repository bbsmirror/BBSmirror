/*-------------------------------------------------------*/
/* kaede.c       ( SunOfBeach SOB BBS Ver 0.00 )         */
/*-------------------------------------------------------*/
/* target : Kaede's functions's header file              */
/* create : 96/03/23                                     */
/* update : 96/03/23                                     */
/*-------------------------------------------------------*/


#ifndef _KAEDE_H_
#define _KAEDE_H_


char *kaede_prints(char *str);
int Rename(char* src, char* dst);
int Link(char* src, char* dst);


#endif				/* _KAEDE_H_ */

