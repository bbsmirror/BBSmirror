/*-------------------------------------------------------*/
/* util/ma2html.c              ( Atlantis BBS Ver 1.32 ) */
/*-------------------------------------------------------*/
/* target : �N M.*.A �榡���ɮ� �ন .html �榡���ɮ�    */
/* create : 96/11/22 (wcf@CCCA.NCTU.edu.tw)              */
/* update : 96/11/27 (woju@freebsd.ee.ntu.edu.tw)        */
/* modify : 03/06/28 (dopin@dns.ats.idv.tw)              */
/*-------------------------------------------------------*/
/* syntex : ma2html <Filename> (as bbsrsadm)             */
/*-------------------------------------------------------*/

/*  Dopin �� bbs2html.c �������ŧi

             bbs2html v1.2        by wcf@CCCA.NCTU.edu.tw

From: wcf@CCCA.NCTU.edu.tw (Wei Chang feng)
Subject: BBS ��ذ� -> WWW html
Date: 22 Nov 1996 09:11:44 GMT

    �ڼg�F�@�ӥi�H�� BBS ��ذϪ����e (~bbs/0Announce) �ন html ���{��,
  �|�� BBS ��ذϪ��峹�@�H�U���ƪ�:

    1. �[ background, title, icons
    2. �� ANSI color code �ন html <font color=???>
    3. �� ANSI �{�{����X�ন <blink>..
    4. ��夤�Ҧ��䪺�쪺 URL �ন hyper link..
    5. �u��s BBS ��ذϸ̧�s�L���ɮ�.

    �ഫ�X�Ӫ� html �|���ɶ��� serial number, ��惡 serial number �P
  ���ذϪ��ɮ״N�i���D�O�_��s�L.

    SOURCE ��b ftp://hsnu.csie.nctu.edu.tw/BBS2HTML.C
    �ڦb Linux �� FreeBSD �W���L ok.
    �ڤ]�b Phoenix �� Maple �W�չL. SOB �h�S�չL..
    (sob-version patched by woju.bbs@sob.org)

    ��ӹ���~�b http://hsnu.csie.nctu.edu.tw/hsnubbs/
                 http://www.ccca.nctu.edu.tw/~wcf/

    SOURCE code �̦��@���ܼƥi�H��K�j�a�ק�:

    index:
        INDEX_TITLE      title �e���� mark
        INDEX_BACKGROUND �I��
        INDEX_HEAD_ICON  head �W�� icon
        INDEX_COLOR      page ���C��
        INDEX_END        WWW �����[�� link..

    article:
        ART_TITLE      title �e���� mark
        ART_BACKGROUND �I��
        ART_HEAD_ICON  head �W�� icon
        ART_COLOR      page ���C��
        ART_END        WWW �����[�� link..

--
Wei Chang-feng (�Q����) , wcf@CCCA.NCTU.edu.tw
Consultant of Campus Computer Communication Association
Rm 101, Computer Center, National Chiao Tung University, Hsinchu, Taiwan
TEL : (035)712121 Ext 52833

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>

#define MAX_WORDS 1000

int ansi_on, ansi_blink;

char *INDEX_TITLE = "[sob-man main]";
char *INDEX_BACKGROUND;
char *INDEX_HEAD_ICON;
char INDEX_COLOR[]="bgcolor=#ddddaa text=#000088 vlink=#8040ff link=#8800ff";
char INDEX_END[]="</BODY></HTML>";

char *ART_TITLE = "[sob-man]";
char *ART_BACKGROUND;
char *ART_HEAD_ICON;
char ART_COLOR[]="bgcolor=#000000 text=#ddffdd vlink=#ffff00 link=#ffff11";
char ART_END[]="</BODY></HTML>";

// stuff.c
int dashf(char *fname) {
  struct stat st;
  return (stat(fname, &st) == 0 && S_ISREG(st.st_mode));
}

void cut_cr( char *l ) {
  char *i;

  for(i = l ; *i != 0 ; i++);
  if(*(i-1) != 0) *(i-1) = 0;
}

void add_href(char *l) {
  char tag[MAX_WORDS], url[MAX_WORDS];
  char *ap, *tp, *u;
  int found;

  ap = l; tp = tag;

  while(*ap != 0) {
    found = 0;

    strncpy(url, ap, 7); url[7] = 0;
    if(!strcmp(url, "http://") || !strcmp(url, "HTTP://")) found = 1;

    strncpy(url, ap, 6); url[6] = 0;
    if(!strcmp(url, "ftp://") || !strcmp(url, "FTP://")) found = 1;

    strncpy(url, ap, 7); url[7] = 0;
    if(!strcmp(url, "file://") || !strcmp(url, "FILE://")) found = 1;

    strncpy( url, ap, 9 ); url[9] = 0;
    if(!strcmp(url, "gopher://") || !strcmp(url," GOPHER://")) found = 1;

    strncpy(url, ap, 9); url[9] = 0;
    if(!strcmp(url, "telnet://") || !strcmp(url, "TELNET://")) found = 1;

    strncpy(url, ap, 7); url[7] = 0;
    if(!strcmp(url, "mailto:") || !strcmp(url, "MAILTO:")) found = 1;

    if(found) {
      for(u = url ; *ap!=0 ; *u++ = *ap++) {
        if(*ap == ' ') break;
        if(*ap == '\"') break;
        if(*ap == '&') break;
        if((unsigned char)*ap >= 127) break;
      }
      *u = 0;

      sprintf(tp, "<A HREF=\"%s\">%s</A>", url, url);
      tp += strlen(tp);
     }
     else *tp++=*ap++; /* Not URL */
   }

   *tp = 0;
   strcpy( l, tag );
}

void tag8859_1(char **tag, char c) {
  switch(c) {
    case '\"': strcpy(*tag, "&quot"); *tag += 5; break;
    case '<':  strcpy(*tag, "&lt");   *tag += 3; break;
    case '>':  strcpy(*tag, "&gt");   *tag += 3; break;
    case '&':  strcpy(*tag, "&amp");  *tag += 4; break;

    default:   **tag = c; (*tag)++;
  }
}

void tagcolor(char **tag, int attr) {
  switch(attr) { /* === filter no-used ansi control === */
    case 0:
    case 5:
    case 30:
    case 31:
    case 32:
    case 33:
    case 34:
    case 35:
    case 36:
    case 37:
      break;

    default:
      return;
  }

  if(attr==5) {
    if(ansi_blink==0 ) {
      ansi_blink = 1;
      strcpy(*tag, "<blink>");
      *tag += 7;
    }

    return;
  }

  if(ansi_blink) {
    strcpy(*tag, "</blink>");
    *tag += 8;
  }

  if(ansi_on) {
    strcpy(*tag, "</FONT>");
    *tag += 7;
    ansi_on=0;
  }


  switch(attr) {
    case 0:  ansi_blink=0; return;

    case 30: strcpy(*tag, "<FONT color=gray>");    *tag += 17; break;
    case 31: strcpy(*tag, "<FONT color=red>");     *tag += 16; break;
    case 32: strcpy(*tag, "<FONT color=green>");   *tag += 18; break;
    case 33: strcpy(*tag, "<FONT color=yellow>");  *tag += 19; break;
    case 34: strcpy(*tag, "<FONT color=blue>");    *tag += 17; break;
    case 35: strcpy(*tag, "<FONT color=fuchsia>"); *tag += 20; break;
    case 36: strcpy(*tag, "<FONT color=aqua>");    *tag += 17; break;
    case 37: strcpy(*tag, "<FONT color=white>");   *tag += 18; break;

    default:
      if(ansi_blink) { strcpy(*tag, "<blink>"); *tag += 7; }
      return;
  }

  if(ansi_blink) { strcpy(*tag, "<blink>"); *tag += 7; }
  ansi_on = 1;
}

int getansi(char **ap, int *attr, char *cmd) {
  char cattr[100], *cap;

  cap = cattr; *cap=0;
  if(**ap == 0) return EOF;

  while(**ap >= '0' && **ap <= '9') {
    *cap = **ap;
    cap++;
    (*ap)++;
  }
  if(cap == cattr) return 0;

  *cap=0;
  sscanf(cattr, "%d", attr);
  if(**ap == 0) return 1;

  *cmd = **ap; (*ap)++;
  if(**ap == 0) return 2;

  return 3;
}

void ansi2tag(char *l) {
  char tag[MAX_WORDS], esc[3];
  char *ap, *tp, cmd;
  int  attr, num, nextansi;

  esc[2] = 0; nextansi = 0;
  ap = l; tp = tag;

  while(*ap != 0) {
    esc[0] = ap[0];
    esc[1] = ap[1];

    if(!strcmp(esc, "[") || nextansi) {
      if(nextansi) nextansi = 0;
      else         ap += 2;

      num = getansi(&ap, &attr, &cmd);
      if(num == EOF)    break;                             /* end-of-string */
      else if(num == 0) ap++;              /* ANSI + no int ? eat the word  */
      else if(num == 1) break;             /* ANSI + int + EOL go next line */
      else if(num == 2) { /* ANSI + attr + cmd + EOL set color go next line */
        if(cmd=='m') tagcolor(&tp, attr);
        break;
      }
      else if(num == 3) {           /* ANSI + attr + cmd + str set color... */
        tagcolor(&tp, attr);
        if(cmd == ';') nextansi = 1;
      }
    }
    else { /* Not ANSI cntrol */
      tag8859_1(&tp, *ap);
      ap++;
    }
  }

  *tp = 0;
  strcpy(l, tag);
}

int ann2html(char *bbsfile, char *htmlfile, char *tit) {
  char l1[MAX_WORDS], title[MAX_WORDS];
  FILE *fi, *fo;
  struct stat st;
  time_t htmltime;

  if((fi = fopen(bbsfile, "r")) == NULL) {
    printf("ann2html: No input file: %s\n", bbsfile);
    return 1;
  }
  lstat(bbsfile, &st);

  printf("file %s -> %s\n", bbsfile, htmlfile);

  if((fo = fopen(htmlfile, "w")) == NULL) {
    printf("ann2html: Can't write html file: %s\n", htmlfile);
    fclose( fi );
    return 1;
  }

  ansi_on = 0;
  ansi_blink = 0;
  strcpy(title, tit); ansi2tag(title);
  /* woju */
  ART_TITLE = title;

  /* ========== html headers ============= */
  fprintf(fo, "<!-- BBS2HTML[%lu] Areicle by wcf@CCCA.NCTU.edu.tw  -->\n"
              "<HTML><HEAD><TITLE>%s</TITLE></HEAD>\n"
              "<BODY background=\"%s\" %s>\n<table><tr><td><pre>",
              st.st_mtime, title, ART_BACKGROUND, ART_COLOR);


  /* ========== text body ============= */
  while(fgets(l1, MAX_WORDS, fi) != NULL) {
    cut_cr(l1);
    ansi2tag(l1);
    add_href(l1);

    fprintf(fo, "%s\n", l1);
  }

  /* ========== end html ============= */
  if(ansi_blink) fprintf(fo, "</blink>");
  if(ansi_on)    fprintf(fo, "</FONT>");
  fprintf(fo, "</pre></td></tr></table>%s", ART_END);
  fclose(fi); fclose(fo);

  return 0;
}

int bbs2html(char *spath, char *hpath, char *title) {
  if(dashf(spath)) { /* === Entry is a file === */
    sprintf(hpath, "%s.html", spath);
    ann2html(spath, hpath, title);
  }

  return 0;
}

int main(int argc, char *argv[]) {
   char htmldir[1024], title[128];

   if(argc < 2) {
     puts("usage: bbs2html <Input Filname>" );
     return 1;
   }

   if(strlen(argv[1]) > 116) {
     puts("filename too long ... must less then 116 !");
     return 1;
   }

   sprintf(title, "ma2html [%s]", argv[1]);
   bbs2html(argv[1], htmldir, title);

   return 0;
}
