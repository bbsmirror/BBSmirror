/*-------------------------------------------------------*/
/* so/fete.c                  (SOB 0.22 ATS Verion 1.32) */
/*-------------------------------------------------------*/
/* target : �O�D/���� �]�w�ݪO�`��M�Ψ禡               */
/* create : 03/07/07 by Dopin                            */
/* update :   /  /                                       */
/*-------------------------------------------------------*/

#include "bbs.h"
#include "fete.h"

char buf[MAXPATHLEN];

// src/maple/stuff.c
void setbfile(char *buf, char *boardname, char *fname) {
  sprintf(buf, "boards/%s/%s", boardname, fname);
}

// src/maple/stuff.c
int dashf(char *fname) {
  struct stat st;
  return (stat(fname, &st) == 0 && S_ISREG(st.st_mode));
}

// src/maple/dopin.c
void get_tm_time(int *year, char *month, char *day, char *hour, char *min) {
  time_t now = time(NULL);
  struct tm *ptime;

  ptime = localtime(&now);

  if(year)  *year  = (int)ptime->tm_year+1900;
  if(month) *month = (char)ptime->tm_mon+1;
  if(day)   *day   = (char)ptime->tm_mday;
  if(hour)  *hour  = (char)ptime->tm_hour;
  if(min)   *min   = (char)ptime->tm_min;
}

int save_fetelist(char *fpath, char mode) {
  FILE *fp;
  int i;

  if((fp = fopen(fpath, "wb+")) == NULL) return -1;
  if(mode == 'I') memset(fete, 0, sizeof(fete));

  fwrite(fete, sizeof(fete), 1, fp);
  fclose(fp);

  return 0;
}

int load_fetelist(char *fpath) {
  FILE *fp;

  if((fp = fopen(fpath, "rb")) == NULL) return -1;
  fread(fete, sizeof(fete), 1, fp);
  fclose(fp);

  return 0;
}

int main_fete(void) {
  char m, d, mbuf, dbuf, change = 1, genbuf[32];
  int i;

  get_tm_time(NULL, &m, &d, NULL, NULL);

  setbfile(buf, currboard, "fetelist");
  if(!dashf(buf)) {
    getdata(b_lines, 0, "�L�`��C���� �O�_�إ� (Yes/Quit) [Q] ? ", genbuf,
            2, LCECHO, 0);
    if(genbuf[0] != 'y') return 0;
    else {
      save_fetelist(buf, 'I');  /* �إߪŪ��C���� (�Ѽ� 'I') */
      change = 0;
    }
  }

  if(change) {
    load_fetelist(buf);
    change = 0;
  }

Fete_Main:
  clear();

  out2line(0, 2, "  �ثe��ܦs��������� ");
  prints("%2d �� %2d ��", m, d);

  i = what_day(m, d);
  move(3, 0);
  prints("  �`�鬰 %s", i && fete[i-1].fete[0] ? fete[i-1].fete : "�L���");

  getdata(5, 0, "  ��� (1)�ܧ��� (2)�ܧ�`�� [Q] ", genbuf, 2, DOECHO, 0);
  if(!*genbuf || *genbuf < '1' || *genbuf > '2') return 0;

  if(*genbuf == '1') {
    getdata(7, 0, "  �� ? ", genbuf, 3, DOECHO, 0);
    mbuf = atoi(genbuf);
    getdata(7, 0, "  �� ? ", genbuf, 3, DOECHO, 0);
    dbuf = atoi(genbuf);

    if(what_day(mbuf, dbuf)) {
      m = mbuf;
      d = dbuf;
    }
    else pressanykey("�L�����(�t�|�~)");
  }
  else {
    getdata(7, 0, "  �п�J�`�� ", genbuf, 17, DOECHO, 0);
    if(*genbuf) {
      getdata(8, 0, "  �бz�T�w y/N ? ", &genbuf[20], 2, LCECHO, 0);
      if(genbuf[20] == 'y') {
        fete[i-1].month = m;
        fete[i-1].day   = d;
        strcpy(fete[i-1].fete, genbuf);
        save_fetelist(buf, 0);
      }
    }
  }

  goto Fete_Main;
}
