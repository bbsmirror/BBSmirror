/* ----------------------------------------------------- */
/* ��H Message-ID/In-Reply-To �ഫ  Atlantis BBS 1.32-R */
/* ----------------------------------------------------- */

#define MSGID_FILE ".msgid"

struct msgid_tb {
  char filename[32];
  char msgid[220];
  char reply[256];
  time_t time;
};
typedef struct msgid_tb msgid_tb;
