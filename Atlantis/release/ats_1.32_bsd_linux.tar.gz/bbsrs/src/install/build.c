#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#undef DEBUG

#define BBSHOME "/home/bbsrs"
#define CURRENT BBSHOME "/src/install"

/* src/maple/dopin.c */
void get_tm_time(int *year, char *month, char *day, char *hour, char *min) {
  time_t now = time(NULL);
  struct tm *ptime;

  ptime = localtime(&now);

  if(year)  *year  = (int)ptime->tm_year+1900;
  if(month) *month = (char)ptime->tm_mon+1;
  if(day)   *day   = (char)ptime->tm_mday;
  if(hour)  *hour  = (char)ptime->tm_hour;
  if(min)   *min   = (char)ptime->tm_min;
}

int auto_cvsup(int os) {
  char buf[256], y[5], m[3];
  int year, month, yy;
  FILE *fp;

  chdir(BBSHOME "/src/cvsup");

  system("make clean ; make update");

  if((fp = fopen(BBSHOME "/CVS/Version", "r")) == NULL) {
    puts(BBSHOME "/CVS/Version Open Error ! can't Auto CVSup ...");
    return -1;
  }
  fgets(buf, 64, fp);
  fclose(fp);

  strncpy(y, &buf[17], 4);
  strncpy(m, &buf[21], 2);
  y[4] = m[2] = 0;
  year = atoi(y);
  month = atoi(m);

  if(!year || ! month) {
    puts("CVS Code in ~/CVS/Version is not right ! can't Auto CVSup ...");
    return -2;
  }

  get_tm_time(&yy, NULL, NULL, NULL, NULL);
  if(year < yy) {
    printf("dated of Year %d ! please Download Newer BBS Version !", year);
    return -3;
  }

  sprintf(buf, "./cvsup update%c id:99999 date:%s/%s", os ? '!' : ' ', y, m);
  printf("\nRunning %s\n\n", buf);
#ifndef DEBUG
  system(buf);
#endif

  return 0;
}

int main(int argc, char *argv[]) {
  int i, ch;
  char *os[] = { "bsd","linux" };
  char *direct[] = { "maple", "util", "so" };
  char buf[256];
  FILE *fp;

  puts("\nWelcome to Use Atlantis BBS.\n");
  printf("Please Enter You OS type (1)BSD (2)Linux for insatll ? ");

  ch = getchar();
  if(ch != '1' && ch != '2') {
    puts("abort... goodbye !");
    return 0;
  }
  else ch = ch - '1';

  unlink(BBSHOME "/src/util/hn_index");
  sprintf(buf, "cp -f %s/src/install/hn_index.%s %s/src/util/hn_index",
          BBSHOME, os[ch], BBSHOME);

#ifdef DEBUG
  puts(buf);
#else
  system(buf);
#endif

  for(i = 0 ; i < 3 ; i++) {
    sprintf(buf, "%s/src/%s/Makefile", BBSHOME, direct[i]);
#ifdef DEBUG
    puts(buf);
#else
    unlink(buf);
#endif

    sprintf(buf, "cp -f Makefile_%s.%s %s/src/%s/Makefile", direct[i], os[ch],
            BBSHOME, direct[i]);
#ifdef DEBUG
    puts(buf);
#else
    system(buf);
#endif
  }

  puts("\nTry to Run Auto CVSup ...\n");
  auto_cvsup(ch);
  chdir(CURRENT);

  if(argc > 1 && !strcmp(argv[1], "nocompile")) {
    puts("\nSkkipping Compile Files ...");
    return 0;
  }

  puts("\nStart Compile with maple/ util/ so/ innbbsd/ ...\n");

  for(i = 0 ; i < 3 ; i++) {
    sprintf(buf, "%s/src/%s", BBSHOME, direct[i]);
#ifdef DEBUG
    puts(buf);
#else
    chdir(buf);
#endif

    sprintf(buf, "make clean update", direct[i]);
#ifdef DEBUG
    puts(buf);
#else
    system(buf);
#endif

    chdir(CURRENT);
  }

#ifndef DEBUG
  chdir(BBSHOME "/src/innbbsd");
  system("make clean");
  system("make bbslink2");
#endif

  sprintf(buf, "make %s install", ch ? "linux" : "freebsd");
#ifdef DEBUG
  puts(buf);
#else
  system(buf);
#endif

  chdir(CURRENT);
  puts("\nCompile all done ...");
  return 0;
}
