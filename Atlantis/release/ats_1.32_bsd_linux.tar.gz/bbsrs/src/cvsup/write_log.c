/*-------------------------------------------------------*/
/* cvsup/write_log.c          (SOB 0.22 ATS Verion 1.32) */
/*-------------------------------------------------------*/
/* target : CVS/SUP �T���O���{��                         */
/* create : 03/03/28 by Dopin                            */
/* update : 03/08/17                                     */
/*-------------------------------------------------------*/

#include <stdio.h>
#include "cvsup.h"

void write_log(char *str) {
  char buf[256];
  FILE *fp;
  time_t now = time(NULL);

  sprintf(buf, "%-56.56s %s", str, Cdate(&now));
  if((fp = fopen(CVS_LOG, "a+")) == NULL) return;
  fprintf(fp, "%s\n", buf);
  fclose(fp);

  printf("%s\n", buf);
}
