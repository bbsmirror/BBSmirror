#include "bbs.h"
#include "fete.h"

void show_syntex(void) {
  puts("Usage: trans_fete <BoardName> <Source Filename>");
  puts("                         Atlantis BBS Ver. 1.32");
}

int main(int argc, char *argv[]) {
  char m, d, buf[128];
  int i, j = 0;
  FILE *fp;

  if(argc != 3) {
    show_syntex();
    return 0;
  }

  /* �����ɿ�J �k�s�`�ذO�� */
  memset(fete, 0, sizeof(fete));

  if((fp = fopen(argv[2], "r")) == NULL) {
    puts("Source Filename Open Error ...");
    return -1;
  }

  while(fgets(buf, 128, fp) && j < 366) {
    if(buf[0] == '#') break;   /* �� # �r�����@Ū������ */

    for(i = 0 ; i < 128 && (uschar)buf[i] >= ' ' ; i++)
      if(buf[i] == ' ') buf[i] = 0;
    buf[i] = 0;

    /* �榡�� mm dd fete --> 02 14 ���H�` */
    m = atoi(buf);
    d = atoi(&buf[3]);

    if((i = what_day(m, d)) > 0) {
      fete[i-1].month = m;
      fete[i-1].day   = d;
      strcpy(fete[i-1].fete, &buf[6]);

      j++;
    }
  }
  fclose(fp);

  sprintf(buf, "%s/boards/%s/fetelist", BBSHOME, argv[1]);
  if((fp = fopen(buf, "wb+")) == NULL) {
    puts("BoardName Error or Diectory truncate/damage");
    return -1;
  }
  fwrite(fete, sizeof(fete), 1, fp);
  fclose(fp);

  puts("Trans Complete...");
  return 0;
}
