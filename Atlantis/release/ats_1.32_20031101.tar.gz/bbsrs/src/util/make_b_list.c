/*-------------------------------------------------------*/
/* util/make_b_list.c         (SOB 0.22 ATS Verion 1.32) */
/*-------------------------------------------------------*/
/* target : �N�ݪO�U��r��ƪ��W���ഫ���G�i����       */
/* create : 03/10/05 by Dopin                            */
/* update :   /  /                                       */
/*-------------------------------------------------------*/

#include "bbs.h"
#include "record_util.c"

#define bbs_board  BBSHOME "/.BOARDS"
#define bbs_passwd BBSHOME "/.PASSWDS"

#undef debug

int cmpuname(char *userid, userec *u) {
  return !strcasecmp(userid, u->userid);
}

// src/maple/record.c
int search_record(fpath, rptr, size, fptr, farg)
  char *fpath;
  char *rptr;
  int size;
  int (*fptr)();
  int farg;
{
  int fd, id = 1;

  if((fd = open(fpath, O_RDONLY, 0)) == -1) return 0;

  while(read(fd, rptr, size) == size) {
    if((*fptr)(farg, rptr)) {
      close(fd);
      return id;
    }

    id++;
  }

  close(fd);

  return 0;
}

int main(void) {
#ifdef SHM_BOARD_NAME_LIST
  char *list[] = { "permlist", "rejectlist", "water" };
  char buf[256];
  SBNL s;
  int count, rec, *listnum[3] = { &s.welcome_number, &s.reject_number,
                                  &s.waters_number };
  usint *idnum[3] = { s.welcome, s.reject, s.waters };
  boardheader bh;
  userec u;
  FILE *fp, *fs, *ft;

  if((fp = fopen(bbs_board, "rb")) == NULL) {
    puts("File open Error");
    return -1;
  }

  while(fread(&bh, sizeof(bh), 1, fp)) {
    memset(&s, 0, sizeof(s));

    printf("Process %s\n", bh.brdname);

    sprintf(buf, "%s/boards/%s/dumplist", BBSHOME, bh.brdname);
    if((ft = fopen(buf, "wb+")) == NULL) continue;

    for(count = 0 ; count < 3 ; count++) {
      sprintf(buf, "%s/boards/%s/%s", BBSHOME, bh.brdname, list[count]);

      rec = 0;

      if((fs = fopen(buf, "r")) != NULL) {
        int i;

        while(fgets(buf, 256, fs)) {
          if(rec >= (count ? MIDNAMELIST - 1 : MAXNAMELIST - 1)) break;
          else strtok(buf, " \t\n\r");

#ifdef DEBUG
          puts(buf);
#endif
          i = strlen(buf);

          if(i > 1 && i < 13)
            if((i = search_record(bbs_passwd, (char *)&u, sizeof(userec),
                                  cmpuname, (userec *)buf)))
              idnum[count][rec++] = i;
        }

        fclose(fs);
      }

      *listnum[count] = rec;
    }

    fwrite(&s, sizeof(s), 1, ft);
    fclose(ft);

    printf("Records: %3d/%3d/%3d\n", *listnum[0], *listnum[1], *listnum[2]);
  }

  fclose(fp);
#endif

  return 0;
}
