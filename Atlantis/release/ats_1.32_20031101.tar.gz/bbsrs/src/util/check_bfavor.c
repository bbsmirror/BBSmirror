/*-------------------------------------------------------*/
/* util/check_bfavor.c        (SOB 0.22 ATS Verion 1.32) */
/*-------------------------------------------------------*/
/* target : �ˬd�ϥΪ� �ڪ��̷R�C���ɤ� ���s�b���ݪO     */
/* create : 03/07/15 by Dopin                            */
/* update :   /  /                                       */
/*-------------------------------------------------------*/

#include "bbs.h"
#include "bcache.c"

#define FN_PASSWDS BBSHOME "/.PASSWDS"
#undef  DEBUG

// kaede.c
int Rename(char* src, char* dst) {
  char cmd[200];

  if(rename(src, dst) == 0) return 0;

  sprintf(cmd, "/bin/mv %s %s", src, dst);
  return system(cmd);
}

// stuff.c
int dashf(char *fname) {
  struct stat st;

  return (stat(fname, &st) == 0 && S_ISREG(st.st_mode));
}

void show_syntex() {
  puts("Usage: check_bfavor [UserID]");
}

int check_bfavor(char *userid, char *src, char *tar, FILE *fs, FILE *ft) {
  char buf[128];
  int i, j = 0;

#ifdef DEBUG
  printf("[%s]\n", userid);
#endif

  sprintf(src, "%s/home/%s/favor_boards", BBSHOME, userid);
  sprintf(tar, "%s.chk", src);
  if(!dashf(src)) return -1;

  if((fs = fopen(src, "r")) == NULL) return -2;
  if((ft = fopen(tar, "w+")) == NULL) {
    fclose(fs);
    return -3;
  }

  while(1) {
    fgets(buf, 128, fs);
    if(feof(fs) || ferror(fs)) break;
    j++;

    for(i = 0 ; i < 128 && (uschar)buf[i] > ' ' ; i++) ;
    buf[i] = 0;

    if((int)getbcache(buf) > 0) {
#ifdef DEBUG
      printf("%s %s\n", src, buf);
#endif
      fprintf(ft, "%s\n", buf);
    }
  }
  fclose(fs), fclose(ft);

  if(j) return Rename(tar, src);
  else  return 1;
}

int main(int argc, char *argv[]) {
  char fsrc[MAXPATHLEN], ftar[MAXPATHLEN];
  FILE *fs, *ft, *fu;

  if(argc > 2) {
    show_syntex();
    return 0;
  }

  if(argc == 2) {
    return check_bfavor(argv[1], fsrc, ftar, fs, ft);
  }
  else {
    userec u;

    if((fu = fopen(FN_PASSWDS, "rb")) == NULL) {
      puts(".PASSWDS Open Error ...");
      return -1;
    }
    while(fread(&u, sizeof(userec), 1, fu)) {
      check_bfavor(u.userid, fsrc, ftar, fs, ft);
    }
  }

  return 0;
}
