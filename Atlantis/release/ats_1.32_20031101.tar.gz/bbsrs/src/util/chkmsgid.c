#include "bbs.h"
#include "record_util.c"

int dashf(char *fname) {
  struct stat st;
  return (stat(fname, &st) == 0 && S_ISREG(st.st_mode));
}

void show_syntex(void) {
  puts("chkmsgid <BOARDNAME>");
}

int main(int argc, char *argv[]) {
  int i;
  char fpath[MAXPATHLEN], fpath_new[MAXPATHLEN], buf[MAXPATHLEN];
  FILE *fs, *ft;
  fileheader fh;
  msgid_tb md;

  if(argc != 2) show_syntex();

  sprintf(fpath, "%s/boards/%s/%s", BBSHOME, argv[1], MSGID_FILE);
  sprintf(fpath_new, "%s.new", fpath);

  if((fs = fopen(fpath, "rb")) == NULL) return -1;
  printf("%s OPEN\n", fpath);
  if((ft = fopen(fpath_new, "wb+")) == NULL) {
    fclose(fs);
    return -1;
  }
  printf("%s OPEN\n", fpath_new);

  while(fread(&md, sizeof(md), 1, fs)) {
    sprintf(buf, "%s/boards/%s/%s", BBSHOME, argv[1], md.filename);
    if(dashf(buf)) {
      puts(buf);
      fwrite(&md, sizeof(md), 1, ft);
    }
    else printf("%s not EXIST !\n", buf);
  }
  fclose(fs), fclose(ft);

  rename(fpath_new, fpath);

  return 0;
}
