/*-------------------------------------------------------*/
/* util/expire_song.c          ( Atlantis BBS Ver 1.32 ) */
/*-------------------------------------------------------*/
/* target : �̷өU���H�����ݪO�R���ϥΪ̫H�c���U���H     */
/* create : 06/03/2003 (Dopin)                           */
/* update :   /  /                                       */
/*-------------------------------------------------------*/
/* syntex : expire_song (as bbsrsadm)                    */
/*-------------------------------------------------------*/

#include "bbs.h"
#include "stations.h"

/* �Ъ`�N SONG_NUMBER_MAX/SONG_NUMBER_MIN ��ƭȤŤp�� 10 �B MAX �ݤj�� MIN */
#define SONG_NUMBER_MAX 150  /* �Ъ`�N�o��ӭȬO��ڭ� +1 �]���Ĥ@���O�ƥ� */
#define SONG_NUMBER_MIN 100  /* �u�����I�q �O�q�ĤG���}�l�� �G�֤@�� */

#undef  SHOW_ERROR
#undef  DEBUG

// src/maple/stuff.c
int dashf(char *fname) {
  struct stat st;
  return (stat(fname, &st) == 0 && S_ISREG(st.st_mode));
}

// src/maple/kaede.c
int Rename(char *src, char *dst) {
  char cmd[200];

  if(rename(src, dst) == 0) return 0;

  sprintf(cmd, "/bin/mv %s %s", src, dst);
  return system(cmd);
}

// src/maple/record.c
long get_num_records(char *fpath, int size) {
  struct stat st;

  if(stat(fpath, &st) == -1) return 0;
  else                       return (st.st_size / size);
}

// src/maple/ main.c && mbbsd.c (modified)
int init_station_number() {
  char buf[10];
  FILE *fpd;

  if((fpd = fopen(BBSHOME "/stfiles/station_number", "r")) == NULL)
    station_num = 0;
  else {
    int k;

    fgets(buf, 9, fpd);
    k = atoi(buf);
    if(k < 1 || k > 19) k = 1;
    station_num = k;

    fclose(fpd);
  }

  return station_num;
}

// src/maple/board.c (modified)
void init_station_info(void) {
  FILE *fp, *fps, *fpm;
  char ch, buf[100];
  int i,j,l;

  if((fp = fopen(BBSHOME "/stfiles/station_list", "r")) == NULL) return;
  if((fps = fopen(BBSHOME "/stfiles/station_list_cn", "r")) == NULL) {
    fclose(fp);
    return;
  }

  for(i = 0 ; i < station_num ; i++) {
    fgets(station_list[i], 20, fp);
    for(j = 0 ; j < 19 && (uschar)station_list[i][j] > ' ' ; j++) ;
    station_list[i][j] = 0;

    sprintf(buf, BBSHOME"/run/%s.sysop_name", station_list[i]);
    fpm = fopen(buf, "r");
    if(fpm == NULL) goto Over_SYSOP;

    for(l = 0 , j = 0 ; j < 100 ; j++) {
      ch = fgetc(fpm);
      if(ch == 10 || ch == 0 || feof(fpm)) {
        if(!feof(fpm) && ch == 10) {
          station_sysops[i][l] = '/';
          l++;
        }
        else {
          if(station_sysops[i][l-1] == '/') station_sysops[i][l-1] = 0;
          else station_sysops[i][l] = 0;

          break;;
        }
      }
      else {
        station_sysops[i][l] = ch;
        l++;
        if(l >= 29) {
          station_sysops[i][l] = 0;
          break;
        }
      }
    }
    fclose(fpm);
Over_SYSOP:
    for(j = 0 ; j < 20 ; j++) {
      ch = fgetc(fps);
      if(ch == 10 || ch == 0) {
        buf[j] = 0;
        break;
      }
      else buf[j] = ch;
    }
    strcpy(station_list_cn[i], buf);
  }
  fclose(fp);
  fclose(fps);
}

int expire(char *fpath) {
  int flag = 1;

  if(dashf(fpath)) {
    char temp[MAXPATHLEN], lockfile[MAXPATHLEN], *ptr;
    int num, size = sizeof(fileheader);
    FILE *fs, *ft;
    fileheader fh;

    strcpy(lockfile, fpath);
    ptr = strstr(lockfile, ".DIR");
    *ptr = 0;
    sprintf(lockfile, "%s%s", lockfile, ".locksong");
    sprintf(temp, "touch %s", lockfile);
    system(temp);

    if((num = (int)get_num_records(fpath, size)) > SONG_NUMBER_MAX + 1) {
      int count = 0, del_num = num - SONG_NUMBER_MIN - 1;

      sprintf(temp, "%s.temp", fpath);
      if((fs = fopen(fpath, "rb")) == NULL) return -1;
      if((ft = fopen(temp, "wb+")) == NULL) {
        fclose(fs);
        return -2;
      }

      while(fread(&fh, 1, size, fs) == size) {
      /* �Ĥ@���@�w�g�J �]�� movie �{�������D �Ĥ@�ӷ��@ reserve(�@�� Note) */
        if(!count || count > del_num) fwrite(&fh, 1, size, ft);
        else {
          strcpy(temp, fpath);
          ptr = strstr(temp, ".DIR");
          *ptr = 0;

          sprintf(temp, "%s%s", temp, fh.filename);
#ifndef DEBUG
          unlink(temp);
#else
          printf("%s should be delete...\n", temp);
#endif
        }
        count++;
      }
      fclose(fs), fclose(ft);

      if(count) {
        sprintf(temp, "%s.expire", fpath);
        Rename(fpath, temp);
        sprintf(temp, "%s.temp", fpath);
        Rename(temp, fpath);

        printf("Keep %d Records of [%s]\n",
               (int)(get_num_records(fpath, size)-1), fpath);
        flag = 0;
      }
    } /* �Ъ`�N����� printf ����ܵ��G�|���ڼƭȤ֤@����] �e���w���L�F */
    else printf("Records %d <= MIN(%d) of [%s]\n", num-1,
                SONG_NUMBER_MIN, fpath);

    sprintf(temp, "rm -f %s", lockfile);
    system(temp);
  }
#ifdef SHOW_ERROR
  else printf("[ERROR] file path of %s not Exist !!\n", fpath);
#endif

  return flag;
}

int main() {
  char buf[MAXPATHLEN];
  int i;

  if(init_station_number()) {
    init_station_info();

    /* ���d�@���w�]�� Note (�\�h���� link �G���ˬd�� */
    sprintf(buf, "%s/man/boards/Note/OrderSongs/.DIR", BBSHOME);
    expire(buf);

    for(i = 0 ; i < station_num ; i++) {
      sprintf(buf, "%s/man/boards/Note.%s/OrderSongs/.DIR", BBSHOME,
              station_list[i]);
      expire(buf);
    }
  }

  return 0;
}
