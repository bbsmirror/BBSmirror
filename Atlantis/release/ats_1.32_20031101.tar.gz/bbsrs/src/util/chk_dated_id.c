/*-----------------------------------------------------*/
/* util/chk_dated_id.c        (SOB 0.22 ATS Ver. 1.32) */
/*-----------------------------------------------------*/
/* target : .PASSWDS �ˬd�L���b���W ���~�b���W��       */
/* create : 03/07/20 by Dopin                          */
/* update :   /  /                                     */
/*-----------------------------------------------------*/

#include "bbs.h"

#define TRANS BBSHOME "/PASSWDS.CHKDATED"

#define BM_DATED         (60 * 86400)
#define LOGINOK_DATED    (30 * 86400)
#define NOLOGINOK_DATED  (15 * 86400)

// ats 1.30 append
int check_u_name(userec *u) {
  int i, j;

  i = strlen(u->userid);
  if(i > IDLEN || i < 2) return -1;

  if(!isalpha(u->userid[0])) return 1;

  for(j = 0 ; j < i ; j++)
    if(!isalpha(u->userid[j]) && !isdigit(u->userid[j])) return -1;

  return 0;
}

void lower_case(char *str) {
  int i, len = strlen(str);

  for(i = 0 ; i < len ; i++) str[i] = tolower(str[i]);
}

int main(void) {
  char buf[MAXPATHLEN];
  int i, j = 0, k = 0;
  time_t now = time(NULL);
  FILE *fs, *ft;
  userec u;

  sprintf(buf, "%s/.PASSWDS", BBSHOME);
  if((fs = fopen(buf, "rb")) == NULL) return -1;
  if((ft = fopen(TRANS, "wb+")) == NULL) {
    fclose(fs);
    return -2;
  }

  while(fread(&u, sizeof(u), 1, fs)) {
    if(check_u_name(&u)) continue;

    strcpy(buf, u.userid);
    lower_case(buf);

    if(strcmp(buf, "guest")) {    /* Guest ���尣 */
      i = now - (int)u.lastlogin;

      if(u.userlevel & PERM_SYSOP || (u.userlevel & PERM_BM && i < BM_DATED)
         || (u.userlevel & PERM_LOGINOK && i < LOGINOK_DATED)
         || i < NOLOGINOK_DATED)
        fwrite(&u, sizeof(u), 1, ft);
      else {
        printf("Dated ID %s of %d days\n", u.userid, i / 86400);
        k++;
      }
      j++;
    }
  }
  fclose(fs), fclose(ft);

  printf("Dated %d/%d Records\n", k, j);

  return 0;
}
