/*-------------------------------------------------------*/
/* util/b2w.c                 (SOB 0.22 ATS Verion 1.31) */
/*-------------------------------------------------------*/
/* target : ���� bbs2html �N M.*.A �ഫ�� html form      */
/* create : 02/07/13 by Dopin                            */
/* update :   /  /                                       */
/*-------------------------------------------------------*/

#include "bbs.h"

#define BOARDS BBSHOME "/.BOARDS"

int main(void) {
  FILE *fp;

  if((fp = fopen(BOARDS, "rb")) != NULL) {
    boardheader fh;

    while(fread(&fh, sizeof(fh), 1, fp)) {
      char bpath[128], wpath[128], cmd[256];

      if(!(fh.level & PERM_POSTMASK))                    continue;
      else if((fh.level - PERM_POSTMASK) > PERM_LOGINOK) continue;

      sprintf(bpath, "%s/boards/%s", BBSHOME, fh.brdname);
      sprintf(wpath, "%s/www/boards/%s", BBSHOME, fh.brdname);

      puts(fh.brdname);

      sprintf(cmd, "%s/src/util/bbs2html %s %s %s", BBSHOME, bpath, wpath,
              fh.brdname);
      system(cmd);
    }

    fclose(fp);
  }
  else puts("ERROR Open ...");

  return 0;
}
