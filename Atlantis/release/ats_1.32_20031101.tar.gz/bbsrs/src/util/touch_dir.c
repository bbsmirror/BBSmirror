/*-----------------------------------------------------*/
/* util/touch_dir.c           (SOB 0.22 ATS Ver. 1.32) */
/*-----------------------------------------------------*/
/* target : �N�S�w�ؿ��U�ɮ��ܧ�ܧ�s�ɶ����ɦW��     */
/* create : 03/10/15 by Dopin                          */
/* update :   /  /                                     */
/*-----------------------------------------------------*/

#include "bbs.h"

#undef DEBUG

// maple/stuff.c
int dashd(char *fname) {
  struct stat st;

  return (stat(fname, &st) == 0 && S_ISDIR(st.st_mode));
}

// maple/kaede.c
int Rename(char* src, char* dst) {
  char cmd[MAXPATHLEN];  // Dopin: �[�j���� �H�K����

  if(rename(src, dst) == 0) return 0;
  sprintf(cmd, "/bin/mv %s %s", src, dst);

  return system(cmd);
}

int main(int argc, char *argv[]) {
  char src[MAXPATHLEN], tar[MAXPATHLEN], cmd[MAXPATHLEN];
  int i;
  time_t now = time(NULL);
  fileheader fh;
  FILE *fs, *ft;

  if(argc != 2 || !dashd(argv[1])) {
    puts("touch_dir <DIR FULL PATH>");

    return 0;
  }

  sprintf(src, "%s/.DIR", argv[1]);
  sprintf(tar, "%s/.DIR.touch", argv[1]);

  if((fs = fopen(src, "rb")) == NULL) {
    printf("%s Open Error !\n", src);

    return -1;
  }

  if((ft = fopen(tar, "wb+")) == NULL) {
    fclose(fs);
    printf("%s Open Error !\n", tar);

    return -1;
  }

  i = 0;
  while(fread(&fh, sizeof(fh), 1, fs)) {
    char from[64], to[64];

    strcpy(from, fh.filename);
    from[2] = 0;
    sprintf(to, "%s%d.A", from, now + i++);

    sprintf(cmd, "mv %s/%s %s/%s", argv[1], fh.filename, argv[1], to);
#ifndef DEBUG
    system(cmd);
#else
    puts(cmd);
#endif

    strcpy(fh.filename, to);
    strcpy(fh.owner, "[SYSTEM]");

#ifndef DEBUG
    fwrite(&fh, sizeof(fh), 1, ft);
#else
    printf("%s\n", fh.filename);
#endif
  }

  fclose(fs), fclose(ft);

#ifndef DEBUG
  Rename(tar, src);
#else
  unlink(tar);
#endif

  return 0;
}
