/*-------------------------------------------------------*/
/* util/usage.c                 SOB 0.22 ATS Verion 1.32 */
/*-------------------------------------------------------*/
/* target : �έp�ݪO�ϥβv                               */
/* create :   /  /   by SmallPig(Transfer From Firebird) */
/* update : 03/10/20 (Dopin)                             */
/*-------------------------------------------------------*/
/* syntax : usage [-nospc] [Station_Name]                */
/*-------------------------------------------------------*/

/* Dopin: ��� Gene �S���קﳡ���F�� ���w�P ATS ���X�� �G�R���� */

#include "bbs.h"
#include "config.h"
#include "record_util.c"
#include "bcache.c"

struct binfo {
  char  boardname[26];
  char  expname[28];
  usint times;
  usint sum;
  usint post;
} st[MAXBOARD];

char nospc = 0;
char station[IDLEN + 1];

/* ����ݪO�H�����ƶq�h�Ťj�p */
int brd_cmp(struct binfo *b, struct binfo *a) {
  boardheader *bb, *ba;

  if(!b->boardname) return  1;
  if(!a->boardname) return -1;

  bb = getbcache(b->boardname), ba = getbcache(a->boardname);

  if(!bb) return  1;
  if(!ba) return -1;

  if(*station) {
    if(strcmp(bb->station, station)) return  1;
    if(strcmp(bb->station, station)) return -1;
  }

  if(a->times != b->times) return (a->times - b->times);
  else                     return (a->sum - b->sum);
}

char *Ctime(time_t *date) {
  static char buf[80];

  strcpy(buf, (char *)ctime(date));
  buf[strlen(buf) - 1] = 0;

  return buf;
}

/* �O���U�ݪO�H���P���d�ɶ� */
int record_data(char *board, int sec) {
  int i;

  if(sec < 0) return -1;

  for(i = 0 ; i < numboards ; i++) {
    if(!st[i].boardname) break;

    if(!strcmp(st[i].boardname, board)) {
      unsigned a = st[i].times, b = st[i].sum;

      if(a < 0) a = 0;
      if(b < 0) b = 0;

      st[i].times ++;
      st[i].sum   += sec;

      if(st[i].times < 0) st[i].times = a;
      if(st[i].sum   < 0) st[i].sum   = b;

      break;
    }
  }

  return 0;
}

/* Dopin: ��禡�ΥH�O���o��� �ȥ��ϥ� */
int record_data2(char *board, int sec) {
  int i;

  for(i = 0 ; i < numboards ; i++) {
    if(!strcmp(st[i].boardname,board)) {
      st[i].post++;
      break;
    }
  }

  return 0;
}

/* Dopin: ��l�� st ���c�� ��Q�� .BOARDS Ū�� �令�s�� SHM */
int fillboard(char *station) {
  int i;

  resolve_boards(1, NULL);

  for(i = 0 ; i < numboards ; i++) {
    strcpy(st[i].boardname, brdshm->bcache[i].brdname);
    strcpy(st[i].expname,   brdshm->bcache[i].title);

    st[i].sum = st[i].times = 0;
  }

  return numboards;
}

/* �N�ɶ��Ѽƭ� �ন�r�� */
char *timetostr(int i) {
  static char str[30];
  int minute, sec, hour;

  minute = i      / 60;
  hour   = minute / 60;
  minute = minute % 60;
  sec    = i      & 60;

  sprintf(str, "%2d:%2d\'%2d\"", hour, minute, sec);

  return str;
}

/* Dopin: �ˬd����R�O���y�k */
int check_syntex(int argc, char *argv[]) {
  *station = nospc = 0;

  if(argc == 1) ;
  else if(argc >= 2 && argc <= 3) {
    if(!strcmp(argv[1] , "-nospc")) nospc = 1;
    else                            strcpy(station, argv[1]);

    if(argc == 3) {
      if(!strcmp(argv[2] , "-nospc")) {
        if(nospc)  return -1;
        else       nospc = 1;
      }
      else {
        if(!nospc) return -2;
        else       strcpy(station, argv[2]);
      }
    }
  }
  else return -3;

  return 0;
}

int main(int argc, char *argv[]) {
  char buf[256], bname[26], date[80], *p;
  char *blk[10] = {
    "  ","�j", "�k", "�l", "�m",
    "�n","�o", "�p", "�i", "�i",
  };
  int mode, sec, i, j, k, c[3], max[3];
  usint ave[3];
  time_t now;
  FILE *fp, *op;

  setuid(BBSUID);
  setgid(BBSGID);
  chdir(BBSHOME);

  mode = 1;

  if(check_syntex(argc, argv)) {
    puts("syntex : usage [-nospc] [Station_Name]");
    puts("-nospc : Don't cacular Special Boards");

    return -1;
  }

start:
  numboards = 0;

  if(mode==1) strcpy(buf, "etc/use_board.list");
  else        strcpy(buf, "etc/use_board.table");

  // Dopin: �� FN_USEBOARD --> SOB �L���w�q
  if((fp = fopen("adm/board.read", "r")) == NULL) {
    printf("cann't open use_board\n");
    return 1;
  }

  if((op = fopen(buf, "w+")) == NULL) {
    printf("Can't Write file %s\n",buf);
    return 1;
  }

  if(!fillboard(station)) {
    puts("Records of Board Cache may cause Errors...");
    return -1;
  }

  now = time(NULL);
  sprintf(date, "%6.6s", Ctime(&now) + 4);

  while(fgets(buf, 256, fp)) {
    p = buf + 20;

    if(!strncmp(p, " USE ", 5)) {
      boardheader *bp = NULL;

      p += 5, p = strtok(p, " ");
      strcpy(bname, p);

      bp = getbcache(bname);

      if(!bp || *station && strcmp(bp->station, station)) continue;
      if(nospc && !(bp->level & PERM_POSTMASK) && bp->level > PERM_LOGINOK)
        continue;

      if(p = (char *)strstr(buf + 46, "Stay: ")) sec = atoi(p + 6);
      else                                       sec = 0;

      record_data(bname, sec);
    }
  }

  fclose(fp);

  qsort((void *)st, numboards, sizeof(st[0]), (void *)brd_cmp);
  ave[0] = ave[1] = ave[2] = max[1] = max[0] = max[2] = 0;

  for(i = 0 ; i < numboards ; i++) {
    ave[0] += st[i].times;
    ave[1] += st[i].sum >= 0 ? st[i].sum : 0;
    ave[2] += st[i].times == 0 ? 0 : st[i].sum / st[i].times;

    if(max[0] < st[i].times) max[0] = st[i].times;

    if(max[1] < st[i].sum) max[1] = st[i].sum;

    if(max[2]< (st[i].times == 0 ? 0 : st[i].sum / st[i].times))
      max[2] = (st[i].times == 0 ? 0 : st[i].sum / st[i].times);
  }

  c[0] = max[0] / 30 + 1, c[1] = max[1] / 30 + 1, c[2] = max[2] / 30 + 1;

  numboards++;
  st[numboards - 1].times = ave[0] / numboards;
  st[numboards - 1].sum   = ave[1] / numboards;

  strcpy(st[numboards - 1].boardname, "Average");
  strcpy(st[numboards - 1].expname, "�`����");

  if(mode == 1) fprintf(op, "[1;37m�W�� %-15.15s%-28.28s %5s %8s %9s[m\n",
                        "�Q�װϦW��", "����ԭz", "�H��", "�ֿn�ɶ�",
                        "�����ɶ�");
  else fprintf(op, "      [1;37m1 [m[34m%2s[1;37m= %d (�`�H��) "
               "[1;37m1 [m[32m%2s[1;37m= %s (�ֿn�`�ɼ�) [1;37m1 [m"
               "[31m%2s[1;37m= %d ��(�����ɼ�)\n\n", blk[9], c[0], blk[9],
               timetostr(c[1]), blk[9], c[2]);

  for(i = 0 , sec = 0 ; i < numboards ; i++) {
    boardheader *bp = NULL;

    if(!st[i].boardname) continue;
    else                 bp = getbcache(st[i].boardname);

    if(!bp || *station && strcmp(bp->station, station)) continue;
    if(nospc && !(bp->level & PERM_POSTMASK) && bp->level > PERM_LOGINOK)
      continue;

    if(mode == 1) fprintf(op, "[1m%4d[m %-15.15s%-28.28s %5d %-.8s %9d\n",
                          sec+1, st[i].boardname, st[i].expname, st[i].times,
                          timetostr(st[i].sum),
                          st[i].times == 0 ? 0 : st[i].sum / st[i].times);
    else {
      fprintf(op,"      [1;37m��[31m%3d [37m�W �Q�װϦW�١G[31m%s "
              "[35m%s[m\n", sec+1, st[i].boardname,st[i].expname);

      fprintf(op,"[1;37m    �z�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w"
              "�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w\n");

      fprintf(op,"[1;37m�H���x[m[34m");

      for(j = 0 ; j < st[i].times / c[0] ; j++) fprintf(op, "%2s", blk[9]);

      fprintf(op, "%2s [1;37m%d[m\n",blk[(st[i].times%c[0])*10/c[0]],
              st[i].times);
      fprintf(op, "[1;37m�ɶ��x[m[32m");

      for(j = 0 ; j < st[i].sum / c[1] ; j++) fprintf(op,"%2s", blk[9]);

      fprintf(op, "%2s [1;37m%s[m\n", blk[(st[i].sum % c[1]) * 10 / c[1]],
              timetostr(st[i].sum));

      j = st[i].times == 0 ? 0 : st[i].sum / st[i].times;
      fprintf(op, "[1;37m�����x[m[31m");

      for(k = 0 ; k < j / c[2] ; k++) fprintf(op, "%2s",blk[9]);

      fprintf(op, "%2s [1;37m%s[m\n",blk[(j%c[2])*10/c[2]], timetostr(j));
      fprintf(op, "[1;37m    �|�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w"
                                "�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w[m\n\n");
    }

    sec++;
  }

  fclose(op);
  mode--;

  if(mode >= 0) goto start;
  else          return 0;
}
