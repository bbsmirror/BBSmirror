#include "bbs.h"

struct msgid_o {
  char filename[32];
  char msgid[220];
  time_t time;
};
typedef struct msgid_o msgid_o;


int main(int argc, char *argv[]) {
  char src[1024], tar[1024];
  FILE *fs, *ft;
  msgid_o o;
  msgid_tb n;

  if(argc != 2) return 0;
  sprintf(src, "%s/boards/%s/.msgid", BBSHOME, argv[1]);
  sprintf(tar, "%s.temp", src);

  if((fs = fopen(src, "rb")) == NULL) {
    printf("%s Open Error !\n", src);
    return -1;
  }

  if((ft = fopen(tar, "wb+")) == NULL) {
    fclose(fs);
    puts("TAR Error");
    return -1;
  }

  while(fread(&o, sizeof(o), 1, fs)) {
    memset(&n, 0, sizeof(n));
    strcpy(n.filename, o.filename);
    strcpy(n.msgid, o.msgid);
    n.time = o.time;

    fwrite(&n, sizeof(n), 1, ft);
  }
  fclose(fs), fclose(ft);

  return 0;
}
