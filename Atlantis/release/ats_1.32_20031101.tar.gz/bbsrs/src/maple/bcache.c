/*-------------------------------------------------------*/
/* bcache.c      ( NTHU CS MapleBBS Ver 2.36 )           */
/*-------------------------------------------------------*/
/* target : cache up data by shared memory               */
/* create : 95/03/29 (maple/cache.c)                     */
/* update : 03/06/18 (Dopin)                             */
/*-------------------------------------------------------*/

#include "bbs.h"
#include <sys/ipc.h>
#include <sys/shm.h>

char *fn_board = BBSHOME "/.BOARDS";

static int ci_strcmp(register char *s1, register char *s2) {
  register int c1, c2, diff;

  do {
    c1 = *s1++;
    c2 = *s2++;

    if(c1 >= 'A' && c1 <= 'Z') c1 |= 32;
    if(c2 >= 'A' && c2 <= 'Z') c2 |= 32;
    if(diff = c1 - c2)         return (diff);
  } while (c1);

  return 0;
}

static void attach_err(int shmkey, char *name) {
  fprintf(stderr, "[%s error] key = %x\n", name, shmkey);
  exit(1);
}

static void *attach_shm(int shmkey, int shmsize) {
  void *shmptr;
  int shmid;

  shmid = shmget(shmkey, shmsize, 0);
  if(shmid < 0) {
    shmid = shmget(shmkey, shmsize, IPC_CREAT | 0600);
    if(shmid < 0) attach_err(shmkey, "shmget");
    shmptr = (void *) shmat(shmid, NULL, 0);
    if(shmptr == (void *) -1) attach_err(shmkey, "shmat");
    memset(shmptr, 0, shmsize);
  }
  else {
    shmptr = (void *) shmat(shmid, NULL, 0);
    if(shmptr == (void *) -1) attach_err(shmkey, "shmat");
  }
  return shmptr;
}

/*-------------------------------------------------------*/
/* .BOARDS cache                                         */
/*-------------------------------------------------------*/

struct BCACHE *brdshm;
boardheader *bcache;
int numboards = -1;

/* force re-caching */

void touch_boards() {
  time(&(brdshm->touchtime));
  numboards = -1;
}

reload_bcache(char mode, char *brdname) {
  int i;
  char fpath[64];

  if(brdshm->busystate) sleep(1);
  else {
    int fd;

    brdshm->busystate = 1;

    if((fd = open(fn_board, O_RDONLY)) > 0) {
      brdshm->number = read(fd, bcache, MAXBOARD * sizeof(boardheader))
                       / sizeof(boardheader);
      close(fd);
    }

    /* ���Ҧ� boards ��Ƨ�s��A�]�w uptime */
    brdshm->uptime = brdshm->touchtime;
    brdshm->busystate = 0;
  }
}

void resolve_boards(char mode, char *brdname) {
  if(brdshm == NULL) {
    brdshm = attach_shm(BRDSHM_KEY, sizeof(*brdshm));
    if(brdshm->touchtime == 0) brdshm->touchtime = 1;
    bcache = brdshm->bcache;
  }

  while(brdshm->uptime < brdshm->touchtime) reload_bcache(mode, brdname);
  numboards = brdshm->number;
}

boardheader *getbcache(char *bname) {
  register int i;
  register boardheader *bhdr;

  resolve_boards(1, NULL);
  for(i = 0, bhdr = bcache; i < numboards; i++, bhdr++)
    if(!ci_strcmp(bname, bhdr->brdname)) return bhdr;

  return NULL;
}

int getbnum(char *bname) {
  register int i;
  register boardheader *bhdr;

  resolve_boards(1, NULL);

  for(i = 0, bhdr = bcache ; i++ < numboards; bhdr++)
    if(!ci_strcmp(bname, bhdr->brdname)) return i;

  return 0;
}
