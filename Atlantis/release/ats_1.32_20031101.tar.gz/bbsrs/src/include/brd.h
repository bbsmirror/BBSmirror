#include "version.h"

#define STRLEN   80             /* Length of most string data */
#define BTLEN    48             /* Length of board title */
#define TTLEN    72             /* Length of title */
#define NAMELEN  40             /* Length of username/realname */
#define FNLEN    33             /* Length of filename  */
#define IDLEN    12             /* Length of bid/uid */

#ifdef _CURRENT_

/* ----------------------------------------------------- */
/* BOARDS struct : Standard 828 bytes                    */
/* ----------------------------------------------------- */

struct boardheader {
  char brdname[(IDLEN+1)*2];
  char title[BTLEN + 1];
  char BM[IDLEN * 3 + 3];
  char pad[11];
  time_t bupdate;
  char pad2[3];
  unsigned char bvote;
  time_t vtime;
  unsigned char votes[16];
  time_t vts[16];
  unsigned int level;
  unsigned int readlevel;
  unsigned int postlevel;
  unsigned int manalevel;
  int l_x;
  int l_y;
  char document[128 * 3];
  char station[16];
  char sysop[IDLEN+1];
  char pastbrdname[(IDLEN+1)*2];
  char yankflags[16];
  char backup[64];
  char status[64];
};

#else

/* ----------------------------------------------------- */
/* BOARDS struct : Release 656 bytes                    */
/* ----------------------------------------------------- */

struct boardheader {
  char brdname[(IDLEN+1)*2];    /* bid */
  char title[BTLEN + 1];
  char BM[IDLEN * 3 + 3];       /* BMs' uid, token '/' */
  char pad[11];
  time_t bupdate;               /* note update time */
  char pad2[3];
  unsigned char bvote;          /* Vote flags */
  time_t vtime;                 /* Vote close time */
  unsigned level;
  char document[128 * 3];       /* add extra document */
  char station[16];
  char sysop[16];
  char pastbrdname[16];
  char yankflags[16];
  char fete[31];
  char outgo_mode;
  char backup[32];
};

#endif

typedef struct boardheader boardheader;
