// M3-BBSHOME/src/lib/radix32.c

char radix32[32] = {
  '0', '1', '2', '3', '4', '5', '6', '7',
  '8', '9', 'A', 'B', 'C', 'D', 'E', 'F',
  'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
  'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
};

// M3-BBSHOME/src/lib/archiv32.c

              /* 32 bits */  /* 7 chars */
void archiv32(time_t chrono, char *fname) {
  char *str;

  str  = fname + 7;
  *str = '\0';

  while(1) {
    *(--str) = radix32[chrono & 31];
    if(str == fname) return;
    chrono >>= 5;
  }
}
