#include "bbs.h"
#include "all_s_head.h"

#include "../../stfiles/main.h"

void point_to_classlist(void) {

   ptr_st[0] = classmainlist;

   return;
}
