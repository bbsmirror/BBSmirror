#include <stdio.h>
#include <string.h>

int check_classn(char *record, char *ip) {
  char *ptr, *ptr1, *ptr2, *ptr3, buf[128];
  int low, high, len, value;

  strcpy(buf, record);
  if(ptr = strchr(buf, ' ')) {
    *ptr = 0;
    ptr3 = ptr+1;
  }
  else return -1;                         /* �榡���~ �@�w�|�� ' ' */

  if(!(ptr = strchr(buf, '/'))) return 0; /* ���O�d����q�ԭz */
  else                          *ptr = 0;

  ptr1 = buf;
  for(low = 0 ; low < 2 ; low++)          /* ��X���d�� B/C �̦h��� '.' */
    if(ptr1 = strchr(ptr1, '.')) ptr2 = ptr1++;
    else {
      ptr1 = ptr2+1;
      break;
    }
  *ptr1 = 0;

  while(*(ptr3++) == ' ') ;              /* ���X�ഫ�r�� ex: "HiNet" */
  ptr3--;

  low = atoi(ptr1+1);                     /* ���o���Ȱ� */
  high = atoi(ptr+1);

  len = strlen(buf);
  if(!strncmp(buf, ip, len)) {
    value = atoi(ip+len);
    if(value >= low && value <= high) {
      strcpy(ip, ptr3);
      return 1;
    }
  }

  return 0;
}

int main(void) {
  char ip_s[128];
  char *compare = "210.71.0/127   Hinet";
  char *compare1 = "210.3/25      TAIWAN";

  strcpy(ip_s, "168.95.1.1");
  check_classn(compare, ip_s);
  printf("[%s]\n", ip_s);

  strcpy(ip_s, "210.71.8.210");
  check_classn(compare, ip_s);
  printf("[%s]\n", ip_s);

  strcpy(ip_s, "210.71.210.6");
  check_classn(compare, ip_s);
  printf("[%s]\n", ip_s);

  strcpy(ip_s, "210.71.210.6");
  check_classn(compare1, ip_s);
  printf("[%s]\n", ip_s);

  strcpy(ip_s, "210.16.210.6");
  check_classn(compare1, ip_s);
  printf("[%s]\n", ip_s);

  return 0;
}
