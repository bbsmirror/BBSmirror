#include "bcache.c"

int check_file_access_deny_hhmm(char *fname) {
  return 0;
}

char *brd       = "Dopin";
char *str_reply = "Re: ";

int Rename(char* src, char* dst) {
  char cmd[200];

  if(rename(src, dst) == 0) return 0;

  sprintf(cmd, "/bin/mv %s %s", src, dst);
  return system(cmd);
}

void setdirpath(char *buf, char *direct, char *fname) {
  strcpy(buf, direct);
  direct = strrchr(buf, '/');
  strcpy(direct + 1, fname);
}

#include "record.c"

int main(void) {
  boardheader bh, *bp = getbcache(brd);
  int bid = getbnum(brd);

  if(bid > 0 && bp) {
    int count = 0;

    for( ; count < 3 ; count++) {
      if(!get_record(fn_board, (char *)&bh, sizeof(bh), bid)) {
        if(strcmp(bp->brdname, bh.brdname)) {
          bid = getbnum(brd);
          continue;
        }

        strcpy(bh.document, "���դu��g�ɫ���J SHM");
        substitute_record(fn_board, (char *)&bh, sizeof(bh), bid);

        touch_boards();
        return 0;
      }
    }
    return 1;
  }
  else return -1;
}
