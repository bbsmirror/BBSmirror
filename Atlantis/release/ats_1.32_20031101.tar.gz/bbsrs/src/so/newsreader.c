/*-------------------------------------------------------*/
/* newspaper.c                                           */
/*-------------------------------------------------------*/
/* author : kenshieh.bbs@bbs.ntit.edu.tw                 */
/* target : �s�D�\Ū�t��                                 */
/* create : 2002/01/19                                   */
/*-------------------------------------------------------*/

#include "bbs.h"
#include "wd.h"

#define NEWS_PAGE           12  /* �@���s�D���� */
#define NEWSHOME BBSHOME    "/news"

static int x, y, z;
static int class_name;          /* �O�� news_class ���ĴX�� */

static int news_class[10] = {NEWS_UDN, NEWS_CTNEWS, NEWS_TWDAILY,
NEWS_REUTERS, NEWS_CNA, NEWS_FTV, NEWS_PNN, NEWS_CNYES, NEWS_ZDNET, NEWS_GREAT
};

static char *newsname[] = {
  "�p�X", "����", "�x�W", "���z", "����", "����", "�l��", "�d��",
  "���", "�j��"
};

static char newsname2[][10] = {"udn", "ctnews", "twdaily", "reuters", "cna",
"ftv","pnn", "cnyes", "2dnet", "great"};

static char newsclass2[][15] = {"polity", "realtime", "society",
"international","twoshore", "finance", "entertain", "sports", "leisure",
"health", "technology"};

static char *newsclass[] = {"�F�v","�Y��","���|","���","�⩤","�]�g","�v��",
"��|","�ͬ�","���d","���"};

int vkey() {
  return igetkey();
}

void vmsg(char *str) {
  pressanykey(str);
}

void outz(char *str) {
  out2line(1, b_lines, str);
}

static int
news_neck() {
  clear();
  out2line(0, 0, "         "
                 "[37m��[44m                                             "
                 "             [m");
  out2line(0, 1, "         "
                 "[1;36;44m    �Ѯ��Ťѷs�D�\\Ū�u�� v1.0     ��ƨӷ��G��"
                 "��_���s�D    [m");
  out2line(0, 2, "         "
                 "[1;36;44m                 http://tw.news.yahoo.com/     "
                 "             [m");
  out2line(0, 3, "         "
                 "[1;36;44m          Designed By kenshieh.bbs@bbs.ntit.edu"
                 ".tw          [m");
  out2line(0, 4, "[45m                                                    "
                 "      [���O���]           [m");
}

static void news_mainmsg() {
  out2line(0, b_lines, "[46m �ާ@����  [31;47m (��������) [30m���"
                    "[31m (Enter)[30m �T�w [31m(Q) [30m���}"
                    "                                          [m");
}

static int news_classmenu_title(pos)
  int pos;
{
  int i, j;
  int max, sum;
  char a;
  struct tm *btime;
  time_t now;

  a = 65;
  time(&now);
  btime = localtime(&now);
  move (6, 18);
  clrtobot();
  prints("[1;37m���Ѭ� [32m%d [37m�� [32m%d [37m�� �z�ثe���\\Ū"
         "[32m%s[37m�s�D", btime -> tm_mon + 1, btime -> tm_mday,
         newsname[x]);
  move(8, 2);
  /* �⦳�X�� */
  sum = sizeof(newsclass2) / (sizeof(char) * 15);

  for (i = 0, j = 1, max = 0; i < sum; i++)
  {
    if (class_name & j)
    {
      if (pos == max)
      {
        prints("[1;37;44m%c)%s[m ", a, newsclass[i]);
        z = i;
      }
      else
        prints("[m%c)%s[m ", a, newsclass[i]);

      max++;
      a++;
    }

    j <<= 1;
  }

  return max;
}

static int news_article(file, pos)
  char *file;
  int pos;
{
  char fpath[64];
  takeALL takeall;

  rec_get(file, &takeall, sizeof(takeALL), pos);
  sprintf(fpath, ""NEWSHOME"/%s/%s/%s",
          newsname2[y * 3 + x], newsclass2[z], takeall.file);

  if (more(fpath, NULL) < 0)
  {
    vmsg("���奿�b������Ϊ�Ū�����~");
    return 0;
  }

  return 1;
}

static void news_mainnews_msg()
{
  outz("[46m  �ާ@����  [31;47m (����) [30m��� [31m(Enter )[30m �T�w "
       "[31m(Q ��) [30m���}                                       [m");
}

static void news_mainnews_titleprint(take, pos, mode)
  takeALL *take;
  int pos;
  int mode; /* 0: �L����    1: No ���� */
{
  move(10 + ((pos - 1) % NEWS_PAGE), 18);

  if (!mode)
    prints("[1;37;44m%3d  %-50.50s[m", pos, take -> title);
  else
    prints("[0;37;40m%3d  %-50.50s[m", pos, take -> title);
}

static int
news_mainnews_title(file, max, n_pos, o_pos, n_y, o_y, mode)
  char *file;
  int max;
  int n_pos;
  int o_pos;
  int n_y;
  int o_y;
  int mode;     /* 1:½�� 0:��½*/
{
  takeALL takeall, ntakeall;

  if (mode)
  {
    int top, i;

    i = 0;
    move (10, 0);
    clrtobot();
    top = (n_pos / NEWS_PAGE) * NEWS_PAGE;

    while (rec_get(file, &takeall, sizeof(takeALL), top) != -1 &&
           i < NEWS_PAGE)
    {
      if (i == n_y)
        news_mainnews_titleprint(&takeall, top + 1, 0);
      else
        news_mainnews_titleprint(&takeall, top + 1, 1);

      top++;
      i++;
    }

    news_mainnews_msg();
  }
  else
  {
    rec_get(file, &takeall, sizeof(takeALL), o_pos);
    news_mainnews_titleprint(&takeall, o_pos + 1, 1);
    rec_get(file, &ntakeall, sizeof(takeALL), n_pos);
    news_mainnews_titleprint(&ntakeall, n_pos + 1, 0);
  }
}

static int news_mainnews(file, max, z_pos)
  char *file;
  int max;
  int z_pos;
{
  int n_y, o_y, max_y;
  int pos, o_pos;
  int cmd, mode, page;

  n_y = o_y = pos = o_pos = page = mode = 0;

  for (;;)
  {
    /* �P�_�O�_��½�� */
    if (o_y == 0 && (pos == max - 1 || pos == ((page + 1) * NEWS_PAGE) - 1))
    {
      mode = 1;
      n_y = max_y = (pos == max - 1) ?
      (max <= NEWS_PAGE) ? max - 1 : max % NEWS_PAGE == 0 ? NEWS_PAGE - 1 :
       max % NEWS_PAGE - 1 : NEWS_PAGE - 1;
    }
    else if ((o_y == max_y && n_y == 0) || (pos == 0 && o_pos != pos + 1))
    {
      mode = 1;
      max_y = (max - pos > NEWS_PAGE) ? NEWS_PAGE - 1 : max - pos - 1;
      n_y = o_y = 0;
    }

    news_mainnews_title(file, max_y, pos, o_pos, n_y, o_y, mode);
    o_y = n_y;
    o_pos = pos;
    cmd = vkey();

    switch (cmd)
    {
      case KEY_DOWN:
        if (n_y < max_y)
          n_y++;
        else
        {
          n_y = 0;
          if (page < max / NEWS_PAGE)
            page++;
          else
            page = 0;
        }
        if (pos < max - 1)
          pos++;
        else
          pos = 0;
        break;

      case KEY_UP:
        if (n_y > 0)
          n_y--;
        else
        {
          n_y = max_y - 1;
          if (page > 0)
            page--;
          else
            page = max / NEWS_PAGE;
        }
        if (pos > 0)
          pos--;
        else
          pos = max - 1;

      case KEY_LEFT:
      case 'q':
      case 'Q':
        break;

      case KEY_RIGHT:
      case '\n':
        break;

      default:
        continue;
    }

    if (cmd == KEY_LEFT || cmd == 'q' || cmd == 'Q')
      return 0;
    else if (cmd == '\n' || cmd == KEY_RIGHT)
    {
      if (!news_article(file, pos))
        break;

      /* ���L�@�� */
      news_neck();
      news_classmenu_title(z_pos);
      mode = 1;
    }
    else
      mode = 0;
  }
}

static void
news_class_msg()
{
  out2line(0, b_lines, "[46m  �ާ@����  [31;47m (����) [30m��� [31m"
           "(Enter��)[30m �T�w [31m(Q) [30m���}                    "
           "           [m");
}

static void
news_printbody(take, pos, num)
  takeALL *take;
  int pos;
  int num;  /* 0: �L title    1: Empty */
{
  if (!num)
  {
    move(10 + pos, 18);
    prints("[m%3d  %-50.50s[m", pos + 1, take -> title);
  }
  else
  {
    out2line(0, 14, "                              [1;37;41m  �ثe�|�L�s�D"
             "  [m");
  }
}

static int news_printnews(file)
  char *file;
{
  int i, max;
  takeALL takeall;

  i = max = 0;

  move(10, 0);
  clrtobot();

  while (rec_get(file, &takeall, sizeof(takeall), i) != -1)
  {
    max++;

    if (i < NEWS_PAGE)
      news_printbody(&takeall, i, 0);

    i++;
  }

  news_class_msg();

  if (i <= 0)
  {
    news_printbody(&takeall, i, 1);
    return 0;
  }

  return max;
}

static void
news_fpath(fpath, x, z)
  char *fpath;
  int x;
  int z;
{
  sprintf(fpath, "/home/bbs/news/%s/%s/@class", newsname2[x], newsclass2[z]);
}

static int news_classmenu() {
  int n_x, max_x;
  int max, cmd, a;
  char fpath[64];

  max_x = n_x = max = 0;

  for (;;)
  {
    max_x = news_classmenu_title(n_x);
    max_x--;
    news_fpath(fpath, x, z);
    max = news_printnews(fpath);
    cmd = vkey();

    switch (cmd)
    {
      case KEY_RIGHT:
          if (n_x < max_x)
            n_x++;
          else
            n_x = 0;
          break;

      case KEY_LEFT:
          if (n_x > 0)
            n_x--;
          else
            n_x = max_x;
          break;

      case '\n':
      case '\r':
      case KEY_DOWN:
          break;

      case 'Q':
      case 'q':
          break;

      default:
          /* ��J a(A) ~ z(Z) ������ */
          if (cmd >= 65 && cmd <= 65 + max_x)
          {
            a = cmd - 65;
            n_x = a;
          }
          else if (cmd >= 97 && cmd <= 97 + max_x)
          {
            a = cmd - 97;
            n_x = a;
          }
          break;
    }

    if((cmd == '\n' || cmd == '\r' || cmd == KEY_DOWN) && max > 0)
      news_mainnews(fpath, max, n_x);
    else if(cmd == 'q' || cmd == 'Q')
      return 0;
  }
}

int newsreader(void) {
  char ans[3];
  int i;

  x = y = z = 0;

  while(1) {
    news_neck();

    move(7, 0);
    for(i = 0 ; i < 10 ; i++) prints(" [ %2d ] ", i+1);
    move(8, 0);
    for(i = 0 ; i < 10 ; i++) prints(" [%s] ", newsname[i]);

    getdata(10, 0, "                       �п�ܾ\\Ū���s�D�ӷ� (1-10) "
            "[Q] : ", ans, 3, DOECHO, 0);
    if(!*ans || !(x = atoi(ans))) return 0;
    else if(x > 10 || x < 1) continue;

    x--;
    class_name = news_class[x];
    news_classmenu_title(x);
    news_classmenu();
  }
}
