/*-------------------------------------------------------*/
/* so/lock_post.c             (SOB 0.22 ATS Verion 1.32) */
/*-------------------------------------------------------*/
/* target : �峹��w�B�z                                 */
/* create : 03/10/14 by Dopin                            */
/* update :   /  /                                       */
/*-------------------------------------------------------*/

#include "bbs.h"

#ifdef LOCK_ARTICLE

#undef DEBUG

extern int current;
extern fileheader *currfhdr;

char lock_file[64];
int change;
fileheader fh;

char *lock_type[3] = { "(P)�ӤH��w ", "(L)�O�D��w ", "(S)������w " };

/* Dopin 03/10/08 */
void acs_lock(char key) {
  char from_ll = 0, to_ll = 0, max_ll = (char)is_board_manager(currboard) + 1;
  char lock_level[9] = "plsabcde";
  int i;

  change = 0;

  /* �u�ˬd�K�� �ڷQ���ݭn break; */
  for(i = 0 ; i < 8 ; i++) {
    if(currfhdr->report == lock_level[i]) from_ll = i + 1;
    if(key              == lock_level[i]) to_ll   = i + 1;
  }

#ifdef DEBUG
  pressanykey("F: %d T: %d M: %d", from_ll, to_ll, max_ll);
#endif

  switch(key) {
    case 'p':
    case 'l':
    case 's':
      if(max_ll < to_ll || from_ll >= to_ll)
        pressanykey("�L�k�ܧ� %s", &lock_type[to_ll - 1][3]);
      else {
        if(to_ll == 1 && strcmp(currfhdr->owner, cuser.userid)) {
          pressanykey("�u���@�̥��H�~�i�ϥ� �ӤH��w");
          break;
        }

        currfhdr->report    = lock_level[to_ll - 1];
        change = 1;
      }

      break;

    case 'u':
      if(!currfhdr->report || from_ll > 2 && max_ll < 3 ||
         max_ll < 2 && max_ll < from_ll)
        pressanykey("���奼��w �αz�õL������ ��w/���� ���v�� ...");
      else {
        currfhdr->report = 0;
        change = 2;
      }

    default :
      break;
  }
}

/* Dopin 03/09/04 */
int do_lock_post() {
  char buf[2];

  *buf = (char)is_board_manager(currboard);

#ifdef DEBUG
  pressanykey("%d", *buf);
#endif

  if(currmode & MODE_SELECT) {
    pressanykey("�Щ�峹�@������Ҧ������楻�\\��");
    return FULLUPDATE;
  }

  if(!*buf && strcmp(currfhdr->owner, cuser.userid)) {
    pressanykey("�� �ݪO/�峹 �D�z�Һ���");
    return FULLUPDATE;
  }

  for(*(buf + 1) = *lock_file = 0 ; *(buf + 1) <= *buf && *(buf + 1) < 3 ;
      (*(buf + 1))++) {
#ifdef DEBUG
    pressanykey("%d %d", *buf, *(buf+1));
#endif

    strcpy(&lock_file[strlen(lock_file)], lock_type[*(buf + 1)]);
  }

  if(currfhdr->report) {
    strcpy(&lock_file[strlen(lock_file)], "(U)������w/���� [Q] ? ");
    pressanykey("����w ��w/����");
  }

  getdata(b_lines, 0, lock_file, buf, 2, LCECHO, 0);
  if(*buf) {
    acs_lock(*buf);

    if(change) {
      getdata(b_lines, 0, MSG_SURE_NY, buf, 2, LCECHO, 0);

      if(*buf == 'y') {
        currfhdr->filemode &= ~FILE_TAGED;

        setbfile(lock_file, currboard, ".DIR");

        if(!get_record(lock_file, &fh, sizeof(fh), current)) {
          if(!strcmp(fh.filename, currfhdr->filename)) {
            substitute_record(lock_file, currfhdr, sizeof(*currfhdr), current);

            sprintf(lock_file, "%c %s/%s", *buf, currboard,
                    currfhdr->filename);
            log_usies(change == 1 ? "Lock" : "Unlock", lock_file);
          }
          else pressanykey("�����ɧ�s���� �еy�ԦA����ʧ@");
        }
        else pressanykey("���޸�Ƥ�靈�~ �еy�ԦA����ʧ@");
      }
    }
  }

  return FULLUPDATE;
}
#endif
