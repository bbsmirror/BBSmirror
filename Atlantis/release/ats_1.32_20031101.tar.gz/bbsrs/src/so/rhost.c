/*-------------------------------------------------------*/
/* so/rhost.c                 (SOB 0.22 ATS Verion 1.32) */
/*-------------------------------------------------------*/
/* target : �]�w/�ˬd �H���������ӷ�                     */
/* create : 03/08/28 by Dopin                            */
/* update :                                              */
/*-------------------------------------------------------*/

#include "bbs.h"

#define RBOARD  "SYSOP"
#define WORKDIR BBSHOME "/rhosts"
#define ALLOW   BBSHOME "/etc/rhosts"
#define RECORD  BBSHOME "/adm/rhosts"
#define RWARR   BBSHOME "/etc/rhosts.warring"

#define RS_ENABLE_LOGIN   0x01
#define RS_REQUEST_PASSWD 0x02

#define ERROR_COUNTS      3
#define CHANGE_COUNTS     5

char *msg_file_acs_err = "�t���ɮצs�����~ �Ь����ȤH��";

struct rs {
  time_t date;
  char   passwd[10];
  char   flags;
  char   passwd_error;
  char   host1[64];
  char   host2[64];
} rs;

void setrsfile(char *fpath) {
  sprintf(fpath, "%s/%s.rhosts", WORKDIR, cuser.userid);
}

int load_rs_file(char *fpath) {
  FILE *fp = fopen(fpath, "rb");

  if(fp) {
    fread(&rs, sizeof(rs), 1, fp);
    fclose(fp);
  }
  else return -1;

  return 0;
}

int save_rs_file(char *fpath) {
  FILE *fp = fopen(fpath, "wb+");

  if(fp) {
    fwrite(&rs, sizeof(rs), 1, fp);
    fclose(fp);
  }
  else return -1;

  return 0;
}

int log_rhosts(char mode) {
  char fpath[64];
  char *action[] = { "New", "Enable", "Disable", "LoginPass",
                     "LoginNonePass", "ErrorPasswd", "Update" };
  FILE *fp;
  time_t now = time(NULL);

  if((fp = fopen(RECORD, "a+")) == NULL) return 1;
  fprintf(fp, "%s %s at %s\n", cuser.userid, action[mode], Cdate(&now));
  fprintf(fp, "from : %s\n", cuser.lasthost);
  fclose(fp);

  return 0;
}

void show_rsetting(void) {
  out2line(1, b_lines-4, "");

  move(b_lines-4, 0);
  prints("  ���\\�� : %s      �n���ӷ����X�k�� : %s",
         rs.flags & RS_ENABLE_LOGIN ? "�ϥ�" : "����",
         rs.flags & RS_REQUEST_PASSWD ? "����@��n���{��" : "�����_�u");

  out2line(0, b_lines-3, "");
  move(b_lines-3, 0), prints("  ���\\�n���ӷ� (1) : %s", rs.host1);
  out2line(0, b_lines-2, "");
  move(b_lines-2, 0), prints("  ���\\�n���ӷ� (2) : %s", rs.host2);
}

int set_rhost(void) {
  char change = 0, ans[2] = {0}, fpath[64], buf[256];

#ifdef CHECK_RHOSTS_LIST
  if(!belong(ALLOW, cuser.userid)) {
    pressanykey("���\\��ݥѯ��ȳ]�w �Ц� %s �ݪO�ӽ�", RBOARD);
    return 0;
  }
#endif

  clear();
  more(RWARR, NA);

  setrsfile(fpath);
  if(load_rs_file(fpath)) {
    memset(&rs, 0, sizeof(rs));

    while(!*rs.passwd) {
      getdata(b_lines-2, 0, "  �z�O�Ĥ@���ϥ� �п�J�\\��K�X (6-10 ��) : "
              "�Ϊ��� Enter ���}", buf, 10, DOECHO, 0);
      if(strlen(buf) < 6) return 0;
      else {
        getdata(b_lines-1, 0, "  �бz�T�w y/N ? ", ans, 2, LCECHO, 0);
        if(*ans == 'y') {
          out2line(1, b_lines-2, "");

          strcpy(rs.passwd, buf);
          if(save_rs_file(fpath)) {
            pressanykey("�t���ɼg�J���~ �Ь����ȤH��");
            return 1;
          }
          log_rhosts(0);
        }
        else return 0;
      }
    }
  }
  else {
    if(rs.passwd_error > ERROR_COUNTS) {
      pressanykey("�z���K�X���~�w�F�W�� �Ь����ȤH��");
      return 1;
    }

    getdata(b_lines-2, 0, "  �п�J�\\��K�X : ", buf, 10, NOECHO, 0);
    if(strcmp(buf, rs.passwd)) {
      log_rhosts(5);
      rs.passwd_error++;

      save_rs_file(fpath);
      return 2;
    }
  }

  *ans = 0;
  while(*ans != 'q' && change < CHANGE_COUNTS) {
    show_rsetting();

    sprintf(buf, "  �� %d/%d ���ܧ� �п�� (1)�\\��}�� (2)�K�X�}�� "
            "(3)�]�w�ӷ� : [Q] ", change, CHANGE_COUNTS);
    getdata(b_lines-1, 0, buf, ans, 2, DOECHO, 0);

    switch(ans[0]) {
      case '1':
        if(rs.flags & RS_ENABLE_LOGIN) rs.flags -= RS_ENABLE_LOGIN ;
        else                           rs.flags += RS_ENABLE_LOGIN ;

        log_rhosts(rs.flags & RS_ENABLE_LOGIN ? 1 : 2);
        change++;

        break;

      case '2':
        if(rs.flags & RS_REQUEST_PASSWD) rs.flags -= RS_REQUEST_PASSWD ;
        else                             rs.flags += RS_REQUEST_PASSWD ;

        log_rhosts(rs.flags & RS_REQUEST_PASSWD ? 3 : 4);
        change++;

        break;

      case '3':
        getdata(b_lines-1, 0, "  �ܧ󤹳\\�n���� (1) �ӷ��@ (2) �ӷ��G [Q]"
                " : ", ans, 2, DOECHO, 0);

        if(*ans == '1' || *ans == '2') {
          getdata(b_lines-1, 0, *ans == '1' ? "  �ӷ��@ : " : "  �ӷ��G : ",
                  buf, 64, DOECHO, 0);
          if(*buf) {
            strcpy(*ans == '1' ? rs.host1 : rs.host2, buf);
            change++;
          }
        }

        break;

      default :
        *ans = 'q';

        break;
    }
  }

  if(change && change <= CHANGE_COUNTS) {
    getdata(b_lines-1, 0, "  ���}���\\�� �нT�w�O�_�g�J�t�θ���� y/N ? ",
            ans, 2, LCECHO, 0);
    if(*ans == 'y') {
      log_rhosts(6);
      save_rs_file(fpath);
    }
  }

  return 0;
}

int check_rhost(void) {
  char fpath[64];

  xuser.userlevel = 0;
  strcpy(cuser.userid, xuser.userid);
  setrsfile(fpath);

  if(!load_rs_file(fpath)) {
    if(rs.flags & RS_ENABLE_LOGIN && (*rs.host1 || *rs.host2)) {
      if(strcmp(fromhost, rs.host1) && strcmp(fromhost, rs.host2)) {
        if(rs.flags & RS_REQUEST_PASSWD) {
          char ci;

          for(ci = 0 ; ci < 3 ; ci++) {
            sprintf(fpath, "�D���ըӷ���} �п�J�K�X (%d/3) : ", ci+1);
            getdata(0, 0, fpath, fpath, PASSLEN, NOECHO, 0);

            if(checkpasswd(xuser.passwd, fpath)) {
              xuser.userlevel = 1;
              break;
            }
            else logattempt(cuser.userid, '-');
          }
        }
      }
      else xuser.userlevel = 1;
    }
    else xuser.userlevel = 2;
  }
  else xuser.userlevel = 2;

  if(!xuser.userlevel) {
    reset_tty();
    exit(1);
  }
  else if(xuser.userlevel == 1) {
    if(dosearchuser(xuser.userid)) {
      cuser = xuser;
      xuser.userlevel = 1;
    }
    else xuser.userlevel = 3;
  }
  else if(xuser.userlevel == 2)
    if(!dosearchuser(xuser.userid)) xuser.userlevel = 3;
    else                            xuser.userlevel = 0;

  return 0;
}
