#include "bbs.h"
#include "vote_user.h"

extern vote v1;

void setbvfile(char *buf, vote *v, char *fname) {
  sprintf(buf, "boards/%s/%s/%s", currboard, v->voteid, fname);
}

static int check_vote_item(char *buf) {
  char genbuf[VLONGLEN];

  setbvfile(genbuf, &v1, VOTE_ITEM_FILE);
  if(buf) strcpy(buf, genbuf);

  if(dashf(genbuf)) return 1;
  else {
    if(is_board_manager(currboard)) return 2;
    else                            return 0;
  }
}

void setup_vitems(vote *v) {
  pressanykey("�I�u�� XD");
}

static int init_vitem(vote *v) {
  char ans[2], buf[VLONGLEN];
  int  i;
  FILE *fp;

  i = check_vote_item(buf);
  if(i == 2) {
    getdata(b_lines - 1, 0, "�����ɤ��s�b �إ� y/N ? ", ans, 2, LCECHO, 0);
    if(*ans == 'y') {
      vitem *vp = (vitem *)malloc(sizeof(vitem) * VOTE_ITEM);

      free(vp);

      if((fp = fopen(buf, "wb+")) == NULL) {
        pressanykey("�����ɶ}�ɿ��~ ���� ...");
        return -1;
      }
      else {
        vitem it;

        memset(&it, 0, sizeof(vitem));
        for(i = 0 ; i < VOTE_ITEM ; i++) fwrite(&it, sizeof(vitem), 1, fp);
        fclose(fp);
      }
    }
  }
  else if(i == 1) setup_vitems(v);

  return 0;
}

int access_vote() {
  init_vitem(&v1);

  return 0;
}
