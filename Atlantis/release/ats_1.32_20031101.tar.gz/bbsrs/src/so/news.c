#include "bbs.h"

#define NEWSHOME BBSHOME "/news"

typedef struct takeNEWS {
  struct takeNEWS *next;
  char *file;
  char *host;
  char *path;
  int port;
} takeNEWS;

const char name_no = 10;

char *name[] = { "2dnet", "cna", "cnyes", "ctnews", "ftv", "great", "pnn",
                 "reuters", "twdaily", "udn"
               };

const char item_no = 11;

char *item[] = { "entertain", "international", "realtime", "technology",
                 "finance", "leisure", "society", "twoshore", "health",
                 "polity", "sports"
               };

int i = 0, j = 0;

void read_article(char *file, int pos, int recs) {
  char fpath[256];
  int sol;
  takeNEWS takeall;

  pressanykey("%s %d %d", file, pos, recs);

  /*
  if((sol = get_record(file, (char *)&takeall, sizeof(takeALL), pos)) != -1) {
    pressanykey("%d %d", sol, *takeall.file);

    if(*takeall.file) {
      sprintf(fpath, "%s/%s/%s/%s", NEWSHOME, name[i], item[j], takeall.file);
      pressanykey("%s", fpath);

      if(more(fpath, YEA) < 0) pressanykey("���奿�b������Ϊ�Ū�����~");
    }
    else pressanykey("NULL OF file");
  }
  else pressanykey("�O�����~ %d", pos);
  */
}

int newsreader(void) {
  takeNEWS news;
  char fpath[256];

  for(i = 0 ; i < name_no ; i++)
    for(j = 0 ; j < item_no ; j++) {
      sprintf(fpath, "%s/%s/%s/@class", NEWSHOME, name[i], item[j]);

      if(dashf(fpath)) {
        int r, records;

        records = get_num_records(fpath, sizeof(news));

        for(r = 1 ; r <= records ; r++) read_article(fpath, r, records);
      }
    }

  return 0;
}
