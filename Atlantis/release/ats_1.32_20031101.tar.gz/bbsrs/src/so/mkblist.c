/*-------------------------------------------------------*/
/* so/mkblist.c               (SOB 0.22 ATS Verion 1.32) */
/*-------------------------------------------------------*/
/* target : �N�ק�L���W���ƪ������J�O�����s         */
/* create : 03/10/05 by Dopin                            */
/* update :   /  /                                       */
/*-------------------------------------------------------*/

#include "bbs.h"

extern int getbnum(char *);
extern int reload_bcache(char, char *);
extern struct BCACHE *brdshm;

int mkblist() {

#ifdef SHM_BOARD_NAME_LIST
  char buf[64];
  char *list[] = { "permlist", "rejectlist", fn_water };
  int i, rec, count, bnum = getbnum(currboard);
  int *listnum[3];
  usint *idnum[3];
  FILE *fp;

  if(!bnum) return 0;
  else {
    listnum[0] = &brdshm->blist[bnum-1].welcome_number;
    listnum[1] = &brdshm->blist[bnum-1].reject_number;
    listnum[2] = &brdshm->blist[bnum-1].waters_number;

    idnum[0] = brdshm->blist[bnum-1].welcome;
    idnum[1] = brdshm->blist[bnum-1].reject;
    idnum[2] = brdshm->blist[bnum-1].waters;
  }

  for(count = 0 ; count < 3 ; count++) {
    setbfile(buf, currboard, list[count]);

    rec = 0;

    if((fp = fopen(buf, "r")) != NULL) {
      while(rec < (count ? MIDNAMELIST - 1 : MAXNAMELIST - 1) &&
            fgets(buf, 32, fp)) {
        strtok(buf, " \t\n\r");

        if((i = getuser(buf)) > 0) idnum[count][rec++] = i;
      }

      fclose(fp);
    }

    *listnum[count] = rec;
  }

  setbfile(buf, currboard, "dumplist");

  if((fp = fopen(buf, "wb+")) != NULL) {
    fwrite(&brdshm->blist[bnum-1], sizeof(SBNL), 1, fp);
    fclose(fp);
  }
#endif

  return 0;
}
