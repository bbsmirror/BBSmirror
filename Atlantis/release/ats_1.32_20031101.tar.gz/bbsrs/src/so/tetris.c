#include "bbs.h"

#define TETRIS BBSHOME "/src/tetris/tetris"

int tetris() {
  execl(TETRIS, "bbs", NULL);

  return 0;
}
