/*-------------------------------------------------------*/
/* fete.h                     (SOB 0.22 ATS Verion 1.32) */
/*-------------------------------------------------------*/
/* target : fete(s) for every boards and stations        */
/* create : 03/07/06 by Dopin                            */
/* update : 03/07/09                                     */
/*-------------------------------------------------------*/

struct fetelist {
  char month;
  char day;
  char fete[30];
};
typedef struct fetelist fetelist;

fetelist fete[366];

int what_day(char month, char day) {
  char months[12] = { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
  int i, days;

  if(month < 1 || month > 12 || day < 1 || day > months[month-1]) return 0;
  else for(i = 0, days = 0 ; i < month ; i++) days += months[i];
  days += day;

  return days;
}
