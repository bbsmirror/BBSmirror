/*-------------------------------------------------------*/
/* record_util.c              NTHU CS MapleBBS Ver 2.36  */
/*-------------------------------------------------------*/
/* target : binary record file I/O routines              */
/* create : 95/03/29 (maple/record.c)                    */
/* update : 03/07/06 (Dopin)                             */
/*-------------------------------------------------------*/

#include "bbs.h"

#undef  HAVE_MMAP
#ifdef  HAVE_MMAP
#include <sys/mman.h>
#endif

#define BUFSIZE         2048
#define safewrite       write

/* woju */
int apply_record(char *fpath, int (*fptr)(), int size) {
  char abuf[BUFSIZE+4];
  FILE* fp;

  if(!(fp = fopen(fpath, "r"))) return -1;

  while(fread(abuf, 1, size, fp) == size)
    if((*fptr)(abuf) == QUIT) {
      fclose(fp);
      return QUIT;
    }
  fclose(fp);

  return 0;
}

/* ------------------------------------------ */
/* mail / post �ɡA�̾ڮɶ��إ��ɮסA�[�W�l�W */
/* ------------------------------------------ */
/* Input: fpath = directory; Output: fpath = full path; */

void stampfile(char *fpath, fileheader *fh) {
  register char *ip = fpath;
  time_t dtime;
  struct tm *ptime;
  int fp;

  if(access(fpath, X_OK | R_OK | W_OK)) mkdir(fpath, 0755);

  time(&dtime);
  while(*(++ip)) ;
  *ip++ = '/';
  do {
    sprintf(ip, "M.%d.A", ++dtime);
  } while ((fp = open(fpath, O_CREAT | O_EXCL | O_WRONLY, 0664)) == -1);

  close(fp);
  memset(fh, 0, sizeof(fileheader));
  strcpy(fh->filename, ip);
  ptime = localtime(&dtime);
  sprintf(fh->date, "%2d/%02d", ptime->tm_mon + 1, ptime->tm_mday);
}

int append_record(char *fpath, char *record, int size) {
  int fd;

  if((fd = open(fpath, O_WRONLY | O_CREAT, 0664)) == -1) {
    perror("open");
    return -1;
  }

  flock(fd, LOCK_EX);
  lseek(fd, 0, SEEK_END);

  safewrite(fd, record, size);

  flock(fd, LOCK_UN);
  close(fd);

  return 0;
}
