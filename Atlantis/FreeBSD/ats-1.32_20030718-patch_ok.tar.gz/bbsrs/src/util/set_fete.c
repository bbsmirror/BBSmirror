/*-------------------------------------------------------*/
/* util/set_fete.c            (SOB 0.22 ATS Verion 1.32) */
/*-------------------------------------------------------*/
/* target : �N�U�ݪO�`��g�J .BOARDS �ç�s bcache       */
/* create : 03/07/07 by Dopin                            */
/* update :   /  /                                       */
/*-------------------------------------------------------*/

#include "bbs.h"
#include "fete.h"
#include "bcache.c"

#define SRC BBSHOME "/.BOARDS"
#define TAR BBSHOME "/.BOARDS.fete"

#define MEMERY_CONSUME
#undef  DEBUG

// src/maple/stuff.c
void setbfile(char *buf, char *boardname, char *fname) {
  sprintf(buf, "boards/%s/%s", boardname, fname);
}

// src/maple/stuff.c
int dashf(char *fname) {
  struct stat st;
  return (stat(fname, &st) == 0 && S_ISREG(st.st_mode));
}

// src/maple/dopin.c
void get_tm_time(int *year, char *month, char *day, char *hour, char *min) {
  time_t now = time(NULL);
  struct tm *ptime;

  ptime = localtime(&now);

  if(year)  *year  = (int)ptime->tm_year+1900;
  if(month) *month = (char)ptime->tm_mon+1;
  if(day)   *day   = (char)ptime->tm_mday;
  if(hour)  *hour  = (char)ptime->tm_hour;
  if(min)   *min   = (char)ptime->tm_min;
}

// src/maple/kaede.c
int Rename(char* src, char* dst) {
  char cmd[200];

  if(rename(src, dst) == 0) return 0;

  sprintf(cmd, "/bin/mv %s %s", src, dst);
  return system(cmd);
}

int load_fetelist(char *fpath) {
  FILE *fp;

  if((fp = fopen(fpath, "rb")) == NULL) return -1;
  fread(fete, sizeof(fete), 1, fp);
  fclose(fp);

  return 0;
}

int main(void) {
  char m, d, buf[MAXPATHLEN];
  int i, j;
  FILE *fs, *ft;
  boardheader bh, *bp = getbcache(DEFAULTBOARD);

#ifdef MEMERY_CONSUME
  int bnum = 0;
  boardheader bhs[MAXBOARD];
#else
  boardheader bhto;
#endif

  if((fs = fopen(SRC, "rb")) == NULL) return -1;
  if((ft = fopen(TAR, "wb+")) == NULL) {
    fclose(fs);
    return -2;
  }

  get_tm_time(NULL, &m, &d, NULL, NULL);
  i = what_day(m, d);

  while(fread(&bh, sizeof(bh), 1, fs)) {
#ifndef MEMERY_CONSUME
    memcpy(&bhto, &bh, sizeof(boardheader));
    setbfile(buf, bh.brdname, "fetelist");
    if(dashf(buf)) {
      load_fetelist(buf);
      strcpy(bhto.fete, fete[i-1].fete);
    }
    else *bhto.fete = 0;

    fwrite(&bhto, sizeof(bhto), 1, ft);
#else
    memcpy(&bhs[bnum], &bh, sizeof(boardheader));
#ifdef DEBUG
    printf("%d %s <%s>\n", bnum, bhs[bnum].brdname, bhs[bnum].fete);
#endif
    bnum++;
#endif
  }

  fclose(fs);
#ifndef MEMERY_CONSUME
  fclose(ft);
#else
  for(j = 0 ; j < bnum ; j++) {
    setbfile(buf, bhs[j].brdname, "fetelist");
#ifdef DEBUG
    printf("[%s]\n", buf);
#endif
    if(dashf(buf)) {
      load_fetelist(buf);
      strcpy(bhs[j].fete, fete[i-1].fete);
    }
    else *bhs[j].fete = 0;
  }

  fwrite(&bhs, sizeof(boardheader) *bnum, 1, ft);
  fclose(ft);
#endif

  Rename(TAR, SRC);
  touch_boards();

  return 0;
}
