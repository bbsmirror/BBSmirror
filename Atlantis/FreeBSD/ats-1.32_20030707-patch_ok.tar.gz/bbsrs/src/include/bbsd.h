#ifdef IP_FREE_PORT
struct port_ip {
  int  s_number;
  char ipvn[48];    /* �{�b�j�a�h�O�� IPV4 ���Ҽ{��ƥ� IPVN �٬O�}�j�@�I */
  int  port;        /* �ק��ĳ by sby.bbs@bbs.csie.mcu.edu.tw �令 46 �~ */
};                  /* �ŦX IPV6 ���w�q (���ҦҼ{�r����� �אּ 48)        */
typedef struct port_ip port_ip;

#define MAX_ACS_IP 2

port_ip ip_port[MAX_ACS_IP];

                        /* STATION , IP , PORT */
char *ip_port_list[] = { "0", "127.0.0.1", "0", /* Port �]�� 0 -> ALL Ports */
                       };

void init_port_ip(void) {
  int i;

  for(i = 0 ; i < MAX_ACS_IP ; i++) {
    ip_port[i].s_number = atoi(ip_port_list[i*3]);
    strcpy(ip_port[i].ipvn, ip_port_list[i*3+1]);
    ip_port[i].port = atoi(ip_port_list[i*3+2]);
  }
}
#endif

#ifdef ZBBSD_FREE_PORT
#define MAX_ACS_ZP 2

usint zbbsd_port[][2] = {  /* �e���O���x�s�� �᭱�O�� ���X���w�]�u���@���x */
  { 0, 23 }, { 0, 3001 }   /* �G�x�Ƴ]���s�� 0 �H��� 1, 2, 3 ... �H������ */
};
#endif

#ifdef MBBSD_FREE_PORT
#define MAX_ACS_MP 5

usint mbbsd_port[][2] = {
  { 0, 9001}, { 0, 9002 }, { 0, 9003 }, { 0, 9004 }, { 0, 9005 }
};
#endif

int port_2_station(char daemon_model, usint port, char *ip) {
  int i;
  int s_n = -1;

#ifdef IP_FREE_PORT
  if(daemon_model == 'P') {
    if(!ip) return s_n;

    for(i = 0 ; i < MAX_ACS_IP ; i++) {
      if((!(usint)ip_port[i].port || (usint)ip_port[i].port == port) &&
         !strcmp(ip_port[i].ipvn, ip)) {
        s_n = ip_port[i].s_number;
        break;
      }
    }
  }
#endif

#ifdef ZBBSD_FREE_PORT
  if(daemon_model == 'Z')
    for(i = 0 ; i < MAX_ACS_ZP ; i++)
      if(zbbsd_port[i][1] == port) {
        s_n = zbbsd_port[i][0];
        break;
    }
#endif

#ifdef MBBSD_FREE_PORT
  if(daemon_model == 'M')
    for(i = 0 ; i < MAX_ACS_MP ; i++)
      if(mbbsd_port[i][1] == port) {
        s_n = mbbsd_port[i][0];
        break;
      }
#endif

  return s_n;
}

int station_2_port(char daemon_model, uschar station_number) {
  int i;
  int p_n = -1;

#ifdef ZBBSD_FREE_PORT
  if(daemon_model == 'Z')
    for(i = 0 ; i < MAX_ACS_ZP ; i++)
      if(zbbsd_port[i][0] == station_number) {
        p_n = zbbsd_port[i][1];
        break;
      }
#endif

#ifdef MBBSD_FREE_PORT
   if(daemon_model == 'M')
     for(i = 0 ; i < MAX_ACS_MP ; i++)
       if(mbbsd_port[i][0] == station_number) {
         p_n = mbbsd_port[i][1];
         break;
       }
#endif

   return p_n;
}
