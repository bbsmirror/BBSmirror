extern int station_num;
extern char station_list[][13];
struct commands *ptr_st[19];
int board(), local_board(), Boards(), Post(), Read(), Select(), New(), Favor();
int Tree();
