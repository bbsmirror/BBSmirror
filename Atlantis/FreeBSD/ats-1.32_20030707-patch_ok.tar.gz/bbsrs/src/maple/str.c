#include <stdio.h>
#include <string.h>

int main(void) {
  char buf[11] = { 0 };

  printf("%s|%d\n", buf, strlen(buf));
  strncat(buf, "  ", 2);
  printf("%s|%d\n", buf, strlen(buf));

  return 0;
}
