/*-------------------------------------------------------*/
/* key.c                      (SOB 0.22 ATS Verion 1.32) */
/*-------------------------------------------------------*/
/* target : ²�������T�O��������{�� (�� visio.c ��g)   */
/* create : 03/09/16 by Dopin                            */
/* update :   /  /                                       */
/*-------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <varargs.h>
#include <arpa/telnet.h>

#define I_TIMEOUT      (-2)   /* Used for the getchar routine select call */
#define I_OTHERDATA  (-333)   /* interface, (-3) will conflict with chinese */
#define SL_STANDOUT     (2)   /* if this line has a standout region */
#define SL_MODIFIED     (1)   /* if line has been modifed, screen output */

#define INPUT_ACTIVE    (0)
#define NA              (0)
#define YEA             (1)
#define SL_ANSICODE     (4)

#define ANSISIZE      (256)
#define IBUFSIZE      (512)
#define OBUFSIZE     (3072)
#define Ctrl(c)   (c & 037)

#define O_CLEAR         "\033[;H\033[2J"
#define O_SCRLV         "\033[L"
#define O_CLROL         "\033[K"
#define O_STUP          "\033[7m"
#define O_STDOWN        "\033[m"

#define o_clear()       output(O_CLEAR,  sizeof(O_CLEAR) - 1)
#define o_cleol()       output(O_CLROL,  sizeof(O_CLROL) - 1)
#define o_standup()     output(O_STUP,   sizeof(O_STUP) - 1)
#define o_standdown()   output(O_STDOWN, sizeof(O_STDOWN) - 1)
#define o_scrollrev()   output(O_SCRLV,  sizeof(O_SCRLV) - 1)

#define KEY_TAB         9
#define KEY_ESC         27
#define KEY_UP          0x0101
#define KEY_DOWN        0x0102
#define KEY_RIGHT       0x0103
#define KEY_LEFT        0x0104
#define KEY_HOME        0x0201
#define KEY_INS         0x0202
#define KEY_DEL         0x0203
#define KEY_END         0x0204
#define KEY_PGUP        0x0205
#define KEY_PGDN        0x0206

#define STR_CURSOR      " "
#define STR_UNCUR       " "

#define uschar  unsigned char
#define usint   unsigned int

char *str_ansicode      = "[0123456789;,";

int scrollcnt, tc_col, KEY_ESC_arg, tc_line, roll = 0;
int t_lines = 24, b_lines = 23, p_lines = 20, t_columns = ANSISIZE;
int cur_pos = 0, showansi = 1;

usint docls, cur_ln = 0, cur_col = 0, standing = NA;

static int i_mode = INPUT_ACTIVE;
static int i_newfd;
static int ibufsize;
static int icurrchar;
static int obufsize = 0;

static char inbuf[IBUFSIZE];
static char outbuf[OBUFSIZE];

static struct timeval *i_top;

jmp_buf byebye;

typedef struct {
  uschar oldlen;                /* previous line length */
  uschar len;                   /* current length of line */
  uschar mode;                  /* status of line, as far as update */
  uschar smod;                  /* start of modified data */
  uschar emod;                  /* end of modified data */
  uschar sso;                   /* start stand out */
  uschar eso;                   /* end stand out */
  uschar width;                 /* line width except ANSI codes */
  uschar data[ANSISIZE];
} screenline;

screenline *big_picture, *visiop = NULL;
screenline *cur_slp;            /* current screen line pointer */

static void standoutput(screenline *, int, int);

int output(char *s, int len) {
  /* Invalid if len >= OBUFSIZE */

  register int size;
  register char *data;

  size = obufsize;
  data = outbuf;

  if(size + len > OBUFSIZE) {
    write(0, data, size);
    size = len;
  }
  else {
    data += size;
    size += len;
  }

  memcpy(data, s, len);
  obufsize = size;
}

oflush() {
  register int size;

  if(size = obufsize) {
    write(0, outbuf, size);
    obufsize = 0;
  }
}

void ochar(c)
  register int c; {
  register char *data;
  register int size;

  data = outbuf;
  size = obufsize;

  if(size > OBUFSIZE - 2) {
    write(0, data, size);
    size = 0;
  }

  data[size++] = c;
  if(c == IAC) data[size++] = c;

  obufsize = size;
}

clear() {
  if(visiop) {
    register int i;
    register screenline *slp;

    docls = YEA;
    cur_pos = cur_col = cur_ln = roll = i = 0;
    cur_slp = slp = visiop;

    while(i++ < t_lines) memset(slp++, 0, 9);
  }
}

static int standoff() {
  if(standing) {
    standing = NA;

    /* ; for null ? */
    if(cur_slp->eso < cur_pos) cur_slp->eso = cur_pos;
  }
}

static int addch(register char *str, register ch) {
  register char i;

  i = *str;
  *str = ch;

  cur_pos++;
  cur_col++;

  if(!i) {
    *++str = '\0';
    cur_slp->len = cur_pos;
    cur_slp->width = cur_col;
  }
}

int outc(register int c) {
  register screenline *cslp;
  register char *txt, *str;
  register int i, j;

  static char ansibuf[16] = "\033";
  static int ansipos = 0;

#ifndef BIT8
  c &= 0x7f;
#endif

  if(!visiop) {
#ifdef BIT8
    if(c != KEY_ESC && !isprint2(c))
#else
    if(c != KEY_ESC && !isprint(c))
#endif
    {
      if(c == '\n') ochar('\r');
      else c = '*';
    }

    ochar(c);
    return;
  }

  cslp = cur_slp;
  txt = &(cslp->data[cur_pos]); /* ���V�ثe��X��m */

 /* -------------------- */
 /* �ɨ��һݭn���ťզr�� */
 /* -------------------- */

  i = cslp->len;
  j = cur_pos - i;
  if(j >= 0) {
    memset(&cslp->data[i], ' ', j);
    *txt = '\0';
    cslp->len = cur_pos + 1;
  }

#ifdef BIT8
  if(c != KEY_ESC && !isprint2(c))
#else
  if(c != KEY_ESC && !isprint(c))
#endif

  {
    if(c == '\n') {
      if(cur_pos) {
        standoff();

        *txt = '\0';
        cslp->len = cur_pos;
        cslp->width = cur_col;
      }
      else memset((char *) cslp + 1, 0, 8);

      move(cur_ln + 1, 0);
      return;
    }
    c = '*';                    /* substitute a '*' for non-printable */
  }

  /* ---------------------------- */
  /* �P�w���Ǥ�r�ݭn���s�e�X�ù� */
  /* ---------------------------- */

  if(c != *txt || c == KEY_ESC) {
    if(cslp->mode & SL_MODIFIED) {
      if(cslp->smod > cur_pos) cslp->smod = cur_pos;
      if(cslp->emod < cur_pos) cslp->emod = cur_pos;
    }
    else {
      cslp->mode |= SL_MODIFIED;
      cslp->smod = cslp->emod = cur_pos;
    }
  }

  /* ---------------------------- */
  /* ANSI control code ���S�O�B�z */
  /* ---------------------------- */

  if(c == KEY_ESC) {
    ansipos = 1;
    return;
  }
  if(ansipos == 1 && c != '[') {  /* �i��O��L����������X */
    ansipos = 0;
    addch(txt++, KEY_ESC);
  }
  else if(ansipos) {
    if(ansipos >= 15) {
      ansipos = 0;                 /* ANSI code �Ӫ��F�A���o���X�z�A���H���� */
    }
    else if(c == 'm' || strchr(str_ansicode, c)) {
      ansibuf[ansipos++] = c;

      if(c == 'm') {               /* �u�����C����O�A�ư��첾���O */
        if(showansi || ansipos <= 4) {
          i = cur_pos + ansipos;
          if(i < ANSISIZE - 1) {
            memcpy(txt, ansibuf, ansipos);
            txt[ansipos] = '\0';
            cslp->len = cslp->emod = cur_pos = i;
            cslp->width = cur_col;
            cslp->mode |= SL_ANSICODE;
          }
        }
        ansipos = 0;
      }
    }
    return;
  }

  addch(txt, c);
  if(cur_col > t_columns) {
    standoff();
    move(cur_ln + 1, 0);
  }
}

int outch(char c) {
  outc(c);
}

int outs(register char *str) {
  register int ch;

  while(ch = *str) {
    outc(ch);
    str++;
  }
}

int clrtoeol() {
  if(visiop) {
    register screenline *cslp = cur_slp;
    register int cpos = cur_pos;

    standing = NA;

    if(cpos) {
      if(cpos <= cslp->sso) cslp->mode &= ~SL_STANDOUT;

      cslp->len = cpos;
      cslp->width = cur_col;
    }
    else memset((char *)cslp + 1, 0, 8);
  }
}

void out2line(char ref, char row, register char *str) {
  move(row, 0);
  clrtoeol();
  outs(str);

  if(ref) refresh();
}

void eolrange(char start, char end) {
  int i;

  if(start < 0) start = 0;
  if(end < 0) end = 0;
  if(start > b_lines) start = b_lines;
  if(end > b_lines) end = b_lines;
  if(end < start) return;

  for(i = start ; i <= end ; i++) out2line(0, i, "");

  return;
}

prints(va_alist)
va_dcl
{
  va_list args;
  char buff[512], *fmt;

  va_start(args);
  fmt = va_arg(args, char *);
  vsprintf(buff, fmt, args);
  va_end(args);

  outs(buff);
}

int move(int y, int x) {
  if(visiop && y < t_lines && x < t_columns) {
    register screenline *cslp;

    cur_ln = y;
    if((y += roll) >= t_lines) y -= t_lines;

    cur_slp = cslp = &visiop[y];
    cur_col = cur_pos = x;

    /* ------------------------------------- */
    /* �L�o ANSI codes�A�p���Яu���Ҧb��m */
    /* ------------------------------------- */

    if(x && (cslp->mode & SL_ANSICODE)) {
      register char *str = cslp->data;
      register int ch, cpos;
      register int ansi = NA;
      register int len = 0;

      cpos = x;
      while (x && (ch = *str)) {
        str++;
        if(ch == KEY_ESC) {
          ansi = YEA;
          cpos++;
          continue;
        }

        if(ansi) {
          cpos++;
          if(!strchr(str_ansicode, ch)) ansi = NA;

          continue;
        }

        x--;
      }

      cur_pos = cpos + x;
    }
  }
}

do_move(int col, int row) {
  char buf[40];

  sprintf(buf, "\033[%d;%dH", row + 1, col + 1);
  output(buf, strlen(buf));
}

static void rel_move(int was_col, int was_ln, int new_col, int new_ln) {
  if(new_ln >= t_lines || new_col >= t_columns) return;

  tc_col = new_col;
  tc_line = new_ln;

  if(new_col == 0) {
    if(new_ln == was_ln) {
      if(was_col) ochar('\r');
      return;
    }
    else if(new_ln == was_ln + 1) {
      ochar('\n');
      if(was_col) ochar('\r');
      return;
    }
  }
  if(new_ln == was_ln) {
    if(was_col == new_col) return;
    else if(new_col == was_col - 1) {
      ochar(Ctrl('H'));
      return;
    }
  }

  do_move(new_col, new_ln);
}

static int ansicol(screenline *slp, int len) {
  if(len && (slp->mode & SL_ANSICODE)) {
    register char ch, *str = slp->data;
    register int ansi, col;

    ansi = col = 0;

    while(len-- && (ch = *str++)) {
      if(ch == KEY_ESC && *str == '[') {
        ansi = YEA;
        continue;
      }

      if(ansi) {
        if(ch == 'm') ansi = NA;
        continue;
      }

      col++;
    }

    len = col;
  }

  return len;
}

int refresh() {
  register screenline *bp;
  register int i, j, len, smod, emod;

  if(!visiop && (icurrchar != ibufsize)) return 0;

  i = scrollcnt;

  if((docls) || (abs(i) >= p_lines)) {
    redoscr();
    return;
  }

  if(i) {
    if(i < 0) {
      rel_move(tc_col, tc_line, 0, 0);

      do {
        o_scrollrev();
      } while (++i);
    }
    else {
      rel_move(tc_col, tc_line, 0, b_lines);

      do {
        ochar('\n');
      } while (--i);
    }
    scrollcnt = 0;
  }

  for(i = 0, bp = &visiop[j = roll]; i < t_lines; i++, j++, bp++) {
    if(j >= t_lines) {
      j = 0;
      bp = visiop;
    }

    len = bp->len;
    if((bp->mode & SL_MODIFIED) && (smod = bp->smod) < len) {
      bp->mode &= ~(SL_MODIFIED);

      if(bp->emod >= len) bp->emod = len - 1;
      emod = bp->emod + 1;

      rel_move(tc_col, tc_line, ansicol(bp, smod), i);

      if(bp->mode & SL_STANDOUT) standoutput(bp, smod, emod);
      else output(&bp->data[smod], emod - smod);

      tc_col = ansicol(bp, emod);
    }
    len = bp->width /* = ansicol(bp, len) */ ;
    if(bp->oldlen > len) {
      rel_move(tc_col, tc_line, len, i);
      o_cleol();
    }

    bp->oldlen = len;
  }

  rel_move(tc_col, tc_line, cur_col, cur_ln);
  oflush();
}

static void standoutput(screenline *slp, int ds, int de) {
  register char *str = slp->data;
  register int sso = slp->sso, eso = slp->eso;

  if(eso <= ds || sso >= de) output(str + ds, de - ds);
  else {
    if(sso > ds) output(str + ds, sso - ds);
    else sso = ds;

    o_standup();
    output(str + sso, MIN(eso, de) - sso);
    o_standdown();

    if(de > eso) output(str + eso, de - eso);
  }
}

int redoscr() {
  register screenline *bp;
  register int i, j, len;

  if(!visiop) return;

  o_clear();
  for(tc_col = tc_line = i = 0, bp = &visiop[j = roll] ; i < t_lines ;
      i++, j++, bp++) {

    if(j >= t_lines) {
      j = 0;
      bp = visiop;
    }

    if(len = bp->len) {
      rel_move(tc_col, tc_line, 0, i);
      if(bp->mode & SL_STANDOUT) standoutput(bp, 0, len);
      else output(bp->data, len);

      bp->mode &= ~(SL_MODIFIED);

      bp->oldlen = tc_col = bp->width;
    }
  }

  rel_move(tc_col, tc_line, cur_col, cur_ln);
  docls = scrollcnt = 0;

  oflush();
}

static int iac_count(char *current) {
  switch (*(current + 1) & 0xff) {
    case DO:
    case DONT:
    case WILL:
    case WONT:
      return 3;

    case SB: {                     /* loop forever looking for the SE */
      register char *look = current + 2;

      for (;;) {
        if((*look++ & 0xff) == IAC) {
          if((*look++ & 0xff) == SE) return look - current;
        }
      }
    }

    default:
      return 1;
  }
}

int igetch() {
  static int trailing = 0;
  register int ch;
  register char *data;

  data = inbuf;

  for (;;) {
   if(ibufsize == icurrchar) {
     fd_set readfds;
     struct timeval to;
     register fd_set *rx;
     register int fd, nfds;

     rx = &readfds;
     fd = i_newfd;

igetnext:

     FD_ZERO(rx);
     FD_SET(0, rx);

     if(fd) {
       FD_SET(fd, rx);
       nfds = fd + 1;
     }
     else nfds = 1;

     to.tv_sec = to.tv_usec = 0;
     if((ch = select(nfds, rx, NULL, NULL, &to)) <= 0) {
       if(visiop) refresh();
       else       oflush();

       FD_ZERO(rx);
       FD_SET(0, rx);

       if(fd) FD_SET(fd, rx);

       while((ch = select(nfds, rx, NULL, NULL, i_top)) < 0) {
         if(errno != EINTR) return -1;
       }
       if(ch == 0) return I_TIMEOUT;
     }
     if(fd && FD_ISSET(fd, rx)) return I_OTHERDATA;

     for(;;) {
       ch = read(0, data, IBUFSIZE);
       if(ch > 0) break;
       if((ch < 0) && (errno == EINTR)) continue;
       longjmp(byebye, -1);
     }

     icurrchar = (*data & 0xff) == IAC ? iac_count(data) : 0;
     if(icurrchar >= ch) goto igetnext;
     ibufsize = ch;
     i_mode = INPUT_ACTIVE;
   }

   ch = data[icurrchar++];
   if(trailing) {
     trailing = 0;
     if(ch == 0 || ch == 0x0a) continue;
   }

   if(ch == Ctrl('L')) {
     redoscr();
     continue;
   }

   if(ch == 0x0d) {
     trailing = 1;
     ch = '\n';
   }

   return (ch);
 }
}

int igetkey() {
  int mode;
  int ch, last;

  mode = last = 0;

  for(;;) {
    ch = igetch();

    if(mode == 0) {
      if(ch == KEY_ESC) mode = 1;
      else              return ch;              /* Normal Key */
   }
    else if(mode == 1) {                   /* Escape sequence */
      if(ch == '[' || ch == 'O') mode = 2;
      else if(ch == '1' || ch == '4') mode = 3;
      else {
        KEY_ESC_arg = ch;
        return KEY_ESC;
      }
    }
    else if(mode == 2) {                         /* Cursor key */
      if(ch >= 'A' && ch <= 'D')      return KEY_UP + (ch - 'A');
      else if(ch >= '1' && ch <= '6') mode = 3;
      else                            return ch;
    }
    else if(mode == 3) {         /* Ins Del Home End PgUp PgDn */
      if(ch == '~') return KEY_HOME + (last - '1');
      else return ch;
    }

    last = ch;
  }
}

void initscr() {
  if(!visiop) {
    big_picture = visiop = cur_slp = (screenline *)calloc(t_lines,
                                      sizeof(screenline));
    docls = YEA;
  }
}

void cursor_show(int row, int column) {
  move(row, column);
  outs(STR_CURSOR);
  move(row, column + 1);
}

int cursor_key(int row, int column) {
  int ch;

  cursor_show(row, column);
  ch = igetkey();
  move(row, column);
  outs(STR_UNCUR);

  return ch;
}

int main(void) {
  int ch;

  initscr();

  move(1, 0), prints("  [1;37;41m Hello ! World ! [m");

  while(1) {
    out2line(1, 3, "");
    out2line(1, 2, "  Enter Any Key From KeyBoard (Ctrl+C to leave) : ");

    ch = cursor_key(2, 49);
    prints("  Value is %4d", ch);

    if(ch == Ctrl('C')) break;
  }

  if(visiop) free(visiop);

  return 0;
}
