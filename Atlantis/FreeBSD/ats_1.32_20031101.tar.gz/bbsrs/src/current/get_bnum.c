#include "bcache.c"

char *str_reply = "Re: ";

int Rename(char* src, char* dst) {
  char cmd[200];

  if(rename(src, dst) == 0) return 0;

  sprintf(cmd, "/bin/mv %s %s", src, dst);
  return system(cmd);
}

void setdirpath(char *buf, char *direct, char *fname) {
  strcpy(buf, direct);
  direct = strrchr(buf, '/');
  strcpy(direct + 1, fname);
}

#include "record.c"

int main(int argc, char *argv[]) {
  char brd[26];
  int bid;
  FILE *fp;
  boardheader bh, *bp;

//  if(argc < 2) {
    if((fp = fopen("/home/bbs/innd/board.temp", "r")) == NULL) return -1;
    fgets(brd, 26, fp);
    for(bid = 0 ; bid < 25 && (unsigned char)brd[bid] > ' ' ; bid++) ;
    brd[bid] = 0;
//  }
//  else strcpy(brd, argv[1]);

  bp  = getbcache(brd);
  bid = getbnum(brd);

  if(bid > 0 && bp) {
    int count = 0;

    for( ; count < 3 ; count++) {
      if(!get_record(fn_board, (char *)&bh, sizeof(bh), bid)) {
        if(strcmp(bp->brdname, bh.brdname)) {
          bid = getbnum(brd);
          continue;
        }

        unlink("/home/bbs/innd/board.n");
        if((fp = fopen("/home/bbs/innd/board.n", "w+")) == NULL) {
          unlink("/home/bbs/innd/board.n");
          return -1;
        }

        fprintf(fp, "%d\n", bid);
        fclose(fp);
//        printf("%d\n", bid);
        return bid;
      }
    }
    return 0;
  }
  else return -1;
}
