#include "bbs.h"
#include "dopin.h"

#define LYNX "/usr/local/bin/lynx"
#define URLS  "http://kline.polaris.com.tw/www/kline"

#define DATA BBSHOME "/game/stock_data"
#define NAME BBSHOME "/game/stock_name"
#define NOW  BBSHOME "/game/stock_now"
#define LOCK BBSHOME "/game/stock.lock"

int touch_lock(char mode) {
  char cmd[128];

  switch(mode) {
    case 'T':
      sprintf(cmd, "touch %s", LOCK);
      system(cmd);
      break;

    case 'U':
      unlink(LOCK);
      break;

    case 'V':
      return dashf(LOCK);

    default:
      break;
  }

  return 0;
}

int main(int argc, char *argv[]) {
  char cmd[256];

  if(argc != 2) return 0;

  if(!strcmp(argv[1], "download")) {
    int y;
    char m, d, day;

    touch_lock('T');

    get_tm_time(&y, &m, &d, NULL, NULL, &day);
    y -= 1911;

    if(!day || day == 6) return 0;

    sprintf(cmd, "%s -source %s/%-.3d%-.2d%-.2d.close.txt > %s", LYNX, URLS,
            y, m, d, DATA);

    if(!system(cmd)) {
      FILE *fp = fopen(DATA, "a+");

      if(fp) {
        fprintf(fp, "--\n�� Origin: STOCK Loader (SOB 0.22 ATS Ver. 1.32)");
        fclose(fp);
      }
    }
    else return -1;

    touch_lock('U');
  }
  else if(!strcmp(argv[1], "format") || !strcmp(argv[1], "list")) {
    char fg;
    FILE *fs = fopen(DATA, "r"), *ft;

    if(touch_lock('V')) return 0;

    fg = !strcmp(argv[1], "format") ? 0 : 1;
    ft = fopen(fg ? NAME : NOW, "w+");

    if(!fs || !ft) {
      if(fs) fclose(fs);
      if(ft) fclose(ft);

      return -1;
    }
    else {
      char buf[256];
      int i;

      for(i = 0 ; i < 5 ; i++) fgets(buf, 256, fs);
      while(strncmp(buf, "--", 2)) {
        fgets(buf, 256, fs);
        if(buf[0] == ' ') {
          char *ptr = buf;

          while((unsigned char)(*(ptr++)) <= ' ') ;
          ptr--;

          if(fg) buf[13] = 0;
          else {
            buf[14] = buf[41] = '|';
            buf[50] = 0;
         }

          fprintf(ft, "%s%s%s\n", fg ? "" : "|", ptr, fg ? "" : " |");
        }
      }

      fclose(fs), fclose(ft);
    }
  }

  return 0;
}
