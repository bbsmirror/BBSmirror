/*-------------------------------------------------------*/
/* util/takenews.c                                       */
/*-------------------------------------------------------*/
/* target : �s�D����{��(�]�t�����Τ��e)                 */
/* create : 2002/1/20                                    */
/* Author : kenshieh.bbs@bbs.ntit.edu.tw                 */
/*-------------------------------------------------------*/
/* syntax : takenews [mkdir][Filename]                   */
/*-------------------------------------------------------*/

#include "bbs.h"

#define HTTP_PORT        80
#define TAKE_LOGFILE     BBSHOME /run/takenews.log"
#define NEWSHOME BBSHOME "/news"

#undef QUERY

#include "dns.h"
#include "archiv32.h"
#include "../lib/rec_get.c"
#include "../lib/rec_add.c"
#include "../lib/f_cat.c"
#include "../lib/str_ncmp.c"

static char *newsname[] = { "udn", "ctnews", "twdaily", "reuters", "cna",
                            "ftv" ,"pnn", "cnyes", "2dnet", "great" };

static char *newsclass[] = { "polity", "realtime", "society", "international",
                             "twoshore", "finance", "entertain", "sports",
                             "leisure", "technology", "twoshore", "health" };

static int tmode;   /* ����O�_��Q��H */

typedef struct takeNEWS {
  struct takeNEWS *next;
  char *file;
  char *host;
  char *path;
  int port;
} takeNEWS;

static void logit(char *key, char *msg) {
  time_t now;
  struct tm *p;
  char buf[256];

  time(&now);
  p = localtime(&now);
  sprintf(buf, "%s\t%s\t%02d/%02d/%02d %02d:%02d:%02d\n",
          key, msg, p->tm_year % 100, p->tm_mon + 1, p->tm_mday,
          p->tm_hour, p->tm_min, p->tm_sec);

  f_cat(TAKE_LOGFILE, buf);
}

#define STR_SPACE       " \t\n\r"

static takeNEWS *take_parse(char *file) {
  FILE *fp;
  takeNEWS *take;
  char *host, *path, buf[256];

  take = NULL;

  if(fp = fopen(file, "r")) {
    while(fgets(buf, sizeof(buf), fp)) {
      if(buf[0] == '#') continue;

      if(file = strtok(buf, STR_SPACE)) {
        if(host = strtok(NULL, STR_SPACE)) {
          if(path = strtok(NULL, STR_SPACE)) {
            int port;
            char *str;
            takeNEWS *tmp;

            if(str = strtok(NULL, STR_SPACE)) {
              port = atoi(str);
              if(port <= 0 || port >= 65535) continue;
            }
            else port = 80;

            tmp =  (takeNEWS *)malloc(sizeof(takeNEWS));
            tmp -> next = take;
            tmp -> file = strdup(file);
            tmp -> host = strdup(host);
            tmp -> path = strdup(path);
            tmp -> port = port;

            if(tmp == NULL) exit(-1);

            take = tmp;
          }
        }
      }
    }

    fclose(fp);
  }

  logit("PARSE", take ? "take_parse finish" : "take_parse empty");

  return take;
}

static int take_getnews(char *file, char *dir, char *host, int port) {
  int sock;
  int cc, tlen, len;
  int i, num, start_show;
  char *xhead, *xtail, tag[10], buf[120], filetmp[120], bfiletmp[120];
  unsigned char aa;
  FILE *fp;
  takeALL takeall;
  static char pool[2048];

  i = 0;

  while(rec_get(file, &takeall, sizeof(takeall), i) != -1) {
    sprintf(filetmp, "%s%s", dir, takeall.file);
    fp = fopen(filetmp, "r");

    /* �P�_�O�_�w�����s�D�F�����ܪ��� break */
    if(fp != NULL) {
      i++;
      fclose(fp);
      break;
    }

    sock = dns_open(host, port);

    if(sock < 0) {
      logit("ERROR","dns_open error in take_getnews()");
      return -1;
    }

    start_show = 0;
    num = len = 1;
    sprintf(buf, "GET %s HTTP/1.0\n\n", takeall.url);
    cc = strlen(buf);

    if(send(sock, buf, cc, 0) != cc) {
      close(sock);
      logit("ERROR", "send error in take_getnews()");
      return -1;
    }

    xhead = pool;
    xtail = pool;
    tlen = 0;

    strcpy(bfiletmp, filetmp);
    strcat(bfiletmp, "-");
    fp = fopen(bfiletmp, "w");

    if(fp == NULL) {
      logit("ERROR", "open newsfile error in take_getnews()");
      return -1;
    }

    fprintf(fp, "�@��: SYSOP(�s�D���Ѥj)\n");
    fprintf(fp, "���D: %s\n", takeall.title);
    fprintf(fp, "�ɶ�: %s\n", ctime(&takeall.time));

    for(;;) {
      if(xhead >= xtail) {
        xhead = pool;
        cc = recv(sock, xhead, sizeof(pool), 0);
        if(cc <= 0) break;
        xtail = xhead + cc;
      }

      cc = *xhead++;

      if((tlen == 5) && !str_ncmp(tag, "span", 4)) start_show = 1;

      if((tlen == 6) && !str_ncmp(tag, "/span", 5)) break;

      if (cc == '<')
      {
        tlen = 1;
        continue;
      }

      if (tlen)
      {
        /* support <br> and <P> */
        if (cc == '>')
        {
          if (tlen == 3 && !str_ncmp(tag, "br", 2))
          {
            num = 1;
            len = 1;
            fputc('\n', fp);
          }
          else if (tlen == 2 && !str_ncmp(tag, "P", 1))
          {
            len = 1;
            num = 1;
            fputc('\n', fp);
            fputc('\n', fp);
          }

          tlen = 0;
          continue;
        }

        if (tlen <= 5)
          tag[tlen - 1] = cc;

        tlen++;
        continue;
      }

      if (start_show)   /* �}�l�L */
      {
        if (cc != '\r' && cc != '\n' && cc != '\t')
        {
          if (num % 2)
          {
            aa = cc;

            if (len == 1)
              fputc('\t', fp);
            else if (len >= 56)
            {
              fputc('\n', fp);
              fputc('\t', fp);
              num = len = 1;
            }

            if (aa >= 0x80) /* ����r�P�_ */
            {
              fputc(cc, fp);
              num++;
            }
            else
              fputc(cc, fp);

          }
          else
          {
            fputc(cc, fp);
            num++;
          }

          len++;
        }
      }
    }

    close(sock);
    fclose(fp);
    rename(bfiletmp, filetmp);
    i++;
  }
}

/* ���o�ؿ����| */
static char *take_getdir(char *file) {
  static char ab[64];
  int i = 0, j = 0;

  while(file[i] != '@') {
    ab[j++] = file[i];
    i++;
  }

  ab[j] = '\0';
  return ab;
}

/* "www.kimo.com.tw"  <- ��쪺�r��� " �h�� */
static char *
take_replace(buf)
  char *buf;
{
  static char ab[256];
  int i = 0, j = 0;

  while (buf[i])
  {
    if (buf[i] != '"')
      ab[j++] = buf[i];
    i++;
  }

  ab[j] = '\0';
  return ab;
}

static int
take_newsclass(file, host, path, port)
  char *file;
  char *host;
  char *path;
  int port;
{
  int cc, sock;
  int show, showurl, start, show2, end;
  int printmode, starturl, starttext, startlen, tlen;
  int i, j, k;
  char *xhead, *xtail;
  char tpath[128];
  char tag[8], savestart[2];
  char buf[128], buf3[64], url[80], urlbak[80], text[80], ofile[64];
  static char pool[2048];
  takeALL takeall, btakeall;
  struct tm *t;
  time_t now;

  show = show2 = start = showurl = startlen = end = i = j = starturl
  = starttext = printmode = tlen = k = 0;

  time(&now);

  if (!tmode)   /* �Y���Q�ѫh��@�Ѫ��ɶ��H��Q��̫᪺�H */
    now -= 86400;

  t = localtime(&now);
  sock = dns_open(host, port);

  if (sock < 0)
  {
    logit("ERROR","dns_open error in webc()");
    return -1;
  }

  sprintf(tpath,"/%d/%02d/%02d%s", 2000 + (t->tm_year % 100), t->tm_mon + 1,
          t->tm_mday, path);
  sprintf(buf, "GET %s\n\n", tpath);
  cc = strlen(buf);

  if (send(sock, buf, cc, 0) != cc)
  {
    close(sock);
    logit("ERROR","send error in takenews()");
    return -1;
  }

  xhead = pool;
  xtail = pool;
  memset(urlbak, 0, sizeof(urlbak));

  /* ��Ĥ@���� url ���s�_�ӥH�K���� */
  if (rec_get(file, &btakeall, sizeof(takeALL), 0) != -1)
    strcpy(urlbak, btakeall.url);

  strcpy(ofile, file);
  strcat(ofile, "-");

  for (;;)
  {
    if (xhead >= xtail)
    {
      xhead = pool;
      cc = recv(sock, xhead, sizeof(pool), 0);
      if (cc <= 0)
        break;
      xtail = xhead + cc;
    }

    cc = *xhead++;

    if (!start)
    {
      if (cc == '>')
      {
        show2 = 1;
        continue;
      }

      if (cc == '\r' || cc == '\t' || cc == '\n')
        continue;

      if (show2)
      {
        if (startlen < 2)
        {
          savestart[startlen++] = cc;

          if (startlen == 2)
          {
            savestart[startlen] = '\0';
            if (!strcmp(savestart, "�E"))
              start = 1;
          }
        }
        else
          startlen = show2 = 0;
      }

      continue;
    }
    else
    {
      if ((tlen == 8) && (!str_ncmp(tag, "a href=", 7)))
      {
        starttext = 1;
        starturl = 1;
      }

      if ((tlen == 3) && (!str_ncmp(tag, "/a", 2)))
      {
        starttext = 0;
        printmode = 1;
      }

      if ((tlen == 7) && (!str_ncmp(tag, "/table", 6)))
        break;

      if (cc == '<')
      {
        tlen = 1;
        continue;
      }

      if (tlen)
      {
        if (cc == '>')
        {
          if (starturl)
            url[i] = '\0';

          starturl = 0;
          tlen = 0;
          continue;
        }

        if (starturl)
          url[i++] = cc;

        if (tlen <= 7)
          tag[tlen - 1] = cc;

        tlen++;
        continue;
      }

      if (starttext)
      {
        text[j++] = cc;
        continue;
      }

      if (printmode)
      {
        text[j] = '\0';
        strcpy(takeall.url, take_replace(url));

        /* �P�_�O�_��L�F */
        if (!strcmp(urlbak, takeall.url))
        {
          while (rec_get(file, &btakeall, sizeof(takeALL), k) != -1)
          {
            rec_add(ofile, &btakeall, sizeof(takeALL));
            printf("%s\n", btakeall.file);
            k++;
          }

          break;
        }

        archiv32(now, buf3);
        strcpy(takeall.file, buf3);
        strcpy(takeall.title, text);
        takeall.time = now;
        rec_add(ofile, &takeall, sizeof(takeALL));
        memset(url, 0, sizeof(url));
        memset(text, 0, sizeof(text));
        memset(buf3, 0, sizeof(buf3));
        i = j = printmode = 0;
        now++;
        continue;
      }
    }
  }

  close(sock);
  rename(ofile, file);
  sprintf(buf, "take %s success in take_newsclass", file);
  logit("PARSE", buf);
  return take_getnews(file, take_getdir(file), host, port);
}

int
main(argc, argv)
  int argc;
  char *argv[];
{
  int i, j;
  char fpath[64];
  time_t now;
  struct tm *ttime;
  takeNEWS *takelist, *take;

  time(&now);
  ttime = localtime(&now);

  if (argc == 2)
  {
    if (!strcmp(argv[1], "mkdir"))
    {
      if (!(mkdir(NEWSHOME, 0755)))
      {
        chdir(NEWSHOME);

        for (i = 0; i < 10; i++)
          mkdir(newsname[i], 0755);

        /* �w�]�ȩҦ��������� */
        for (j = 0; j < 10; j++)
          for (i = 0; i < 12; i++)
          {
            sprintf(fpath, "%s/%s/%s", NEWSHOME, newsname[j], newsclass[i]);
            mkdir(fpath, 0755);
          }

        logit("PARSE", "Make directory success");
      }
      else
      {
        printf("ERROR: �ؿ��w�إ�\n");
        logit("ERROR", "Make directory Failed");
      }
    }
    else
    {
      time_t now;
      struct tm *btime;

      chdir(BBSHOME);
      takelist = take_parse(argv[1]);
      take = takelist;
      dns_init();
      time(&now);
      btime =localtime(&now);
      tmode = 1;

      do
      {
        /* �M���L���s�D, �ѩ�O�C2�p�ɧ�@���ҥH��n�b�o���j������ */
        if (btime -> tm_hour > 2 && btime -> tm_hour <= 4)
        {
          struct dirent *de;
          DIR *dirp;
          char *ptr;
          char cleanpath[80], path[80];

          for (j = 0; j < 10; j++)
            for (i = 0; i < 12; i++)
            {
              sprintf(path, "%s/%s/%s", NEWSHOME, newsname[j], newsclass[i]);

              if (chdir(path) || !(dirp = opendir(".")))
                continue;

              while (de = readdir(dirp))
              {
                ptr = de -> d_name;

                if (ptr[0] != '.' || ptr[0] > ' ')
                {
                  sprintf(cleanpath, "%s/%s", path, ptr);
                  unlink(cleanpath);
                }
              }

              closedir(dirp);
            }
        }

/*
   kimo ���b�ֱ��񦭤W�ɤ~�����Ѫ��s�D�A�ҥH0 ~ 4�I�����Y�줵�骺�s�D
   �h�|�]�٥���J�ӧ줣��A�B 0 �I�o������|�|�� 22 ~ 0 �I�o���A�ҥH
   �[�J���P�_�ӧP�_�O�_�ɶ��n���d�b�Q��
*/
        else if(btime->tm_hour >= 0 && btime->tm_hour <= 2) tmode = 0;

        take_newsclass(take -> file, take -> host, take -> path, take -> port);
      } while (take = take -> next);

      free(take);
      take = NULL;
      logit("PARSE", "takenews.c success");
    }
  }
  else
  {
    printf("takenews [mkdir][Filename]\n");
    printf("mkdir: �y�X�����ؿ�\n");
    printf("Filename: ����s�D\n");
  }

  exit(0);
}
