#include "bbs.h"

int main(int argc, char *argv[]) {
  char buf[80];
  msgid_tb mtb;
  FILE *fp;

  if(argc != 2) return -1;

  sprintf(buf, "%s/boards/%s/%s", BBSHOME, argv[1], MSGID_FILE);

  if((fp = fopen(buf, "rb")) != NULL) {
    while(fread(&mtb, sizeof(mtb), 1, fp))
      printf("%s\n%d %s\n", mtb.filename, strlen(mtb.msgid), mtb.msgid);
    fclose(fp);
  }
  else return -2;

  return 0;
}
