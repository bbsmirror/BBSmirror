/* Source by Snow.bbs@os.twbbs.org */
/* Modified by Dopin.bbs@bbs.ats.idv.tw */

#include <stdio.h>
#include <stdlib.h>

#undef  DEBUG
#define LOAD 100.0

int main(int argc, char *argv[]) {
  char ci, mode;
  double avg, loads[5];

  mode = (argc == 2 && !strcmp(argv[1], "boot")) ? 1 : 0;

  getloadavg(loads, 5);
  for(ci = 0, avg = 0.0 ; ci < 5 ; ci++) {
    if(!mode) printf("%.2f ", loads[ci]);
    else avg += loads[ci];
  }

  if(mode) {
#ifdef DEBUG
    printf("%f\n", avg);
#else
    if(avg > LOAD * 5.0)
      system("sync ; sync ; reboot");
#endif
  }
  else puts("");

  return 0;
}
