/*-------------------------------------------------------*/
/* util/m3tom2_gem            (SOB 0.22 ATS Verion 1.32) */
/*-------------------------------------------------------*/
/* target : ���� gem2man �ഫ�Ҧ���� M3 ���ݪO��ذ�    */
/* create : 03/08/09 by Dopin                            */
/* update :   /  /                                       */
/*-------------------------------------------------------*/
/* syntax : m3tom2_gem <.BOARDS FILE>                    */
/*-------------------------------------------------------*/

#include "bbs.h"

int main(int argc, char *argv[]) {
  char cmd[64];
  FILE *fp;
  boardheader bh;

  if(argc != 2) {
    puts("syntex : m3tom2_gem <.BOARDS FILE>");
    return 0;
  }

  if((fp = fopen(argv[1], "rb")) == NULL) {
    printf("File %s Open Error ...\n", argv[1]);
    return -1;
  }

  while(fread(&bh, sizeof(bh), 1, fp)) {
    printf("[Process BRD: %s]\n", bh.brdname);
    sprintf(cmd, "mkdir ~/man/boards/%s", bh.brdname);
    system(cmd);
    sprintf(cmd, "./gem2man %s", bh.brdname);
    system(cmd);
  }
  fclose(fp), puts("done.");

  return 0;
}
