/*-------------------------------------------------------*/
/* util/usr2home.c            (SOB 0.22 ATS Verion 1.32) */
/*-------------------------------------------------------*/
/* target : �N Maple3 usr/ �U�ɮ��ഫ�� Maple2 home/     */
/*          ���ഫ��U�� .DIR �H�ѥ��`�\Ū�ϥ�           */
/* create : 03/10/26 by Dopin                            */
/* update :   /  /                                       */
/*-------------------------------------------------------*/

#include "bbs.h"

char *dirs = "0123456789ABCDEFGHIJKLMNOPQRSTUV@"; /* @ ��������� �]�i�B�z�� */

typedef struct {
  time_t chrono;                /* timestamp */
  int xmode;

  int xid;                      /* reserved �O�d*/

  char xname[32];               /* �ɮצW�� */
  char owner[60];               /* �@�� (E-mail address) */
  char reserve[16];             /* �O�d */
  int  recommend;               /* ���ˤ峹 */
  char nick[50];                /* �ʺ� */

  char date[9];                 /* [96/12/01] */
  /* Thor.990329: �S�O�`�N, date �u����ܥ�, ���@���, �H�קK y2k ���D,
                  �w�q 2000�� 00, 2001 �� 01 */

  char title[73];               /* �D�D (TTLEN + 1) */
} HDR;

usint power(int i, int j) {
  usint res = 1, cnt;

  for(cnt = 0 ; cnt < j ; cnt ++) res *= i;

  return res;
}

int dashf(char *fname) {
  struct stat st;
  return (stat(fname, &st) == 0 && S_ISREG(st.st_mode));
}

int convert_fname(char *fname) {
  char convert[32];
  int i, j, len = strlen(fname);

  for(i = 0 ; i < len ; i++) {
    for(j = 0 ; j < 32 ; j++)
      if(fname[i] == dirs[j]) {
        convert[i] = j;
        break;
      }

    if(j == 32) return -1;   /* invalid filename */
  }

  for(i = 0, j = 0 ; j < len ; j++) i += power((int)convert[j], len-j);

  return i;
}

int main(int argc, char *argv[]) {
  char fpath[MAXPATHLEN], buf[MAXPATHLEN];
  userec u;
  HDR hdr;
  fileheader fh;
  FILE *fp, *fs, *ft;

  if(argc != 3) {
    puts("Usage : usr2home <.PASSWDS file fullpath> <OLD BBS HOME>\n");

    puts("Translation M3 usr/ -> M2 home/");
    puts("Copyright(C) Atlantis BBS Ver 1.32  July 2003 (by Dopin)");
    return -1;
  }

  sprintf(fpath, "%s/home.tgz", BBSHOME);

  if(!dashf(fpath)) {
    puts("You should BACKUP you home/ as home.tgz First !!");
    return 0;
  }

  if((fp = fopen(argv[1], "rb")) == NULL) return -1;
  sprintf(fpath, "%s/home", BBSHOME);
  mkdir(fpath, 0775); /* �v�����} �H�K�g�J�H�W �p�w�s�b�ؿ� ���~�T�������� */

  while(fread(&u, sizeof(u), 1, fp)) {
    printf("Converting %s ", u.userid);

    sprintf(fpath, "%s/usr/%c/%s/.DIR", argv[2], tolower(*u.userid), u.userid);
    if((fs = fopen(fpath, "rb")) == NULL) {
      puts(".DIR not Exist ...");
      continue;
    }

    sprintf(fpath, "%s/home/%s", BBSHOME, u.userid);
    mkdir(fpath, 0775);

    sprintf(fpath, "%s/home/%s/.DIR", BBSHOME, u.userid);

    if((ft = fopen(fpath, "ab+")) == NULL) { /* �ϥηs�W �H�K�\������ */
      fclose(fs);
      continue;
    }

    while(fread(&hdr, sizeof(hdr), 1, fs)) {
      int i;

      if((i = convert_fname(hdr.xname)) <= 0) continue;
      memset(&fh, 0, sizeof(fh));

      strncpy(fh.owner, hdr.owner, IDLEN+1);
      strncpy(fh.title, hdr.title, TTLEN > 73 ? TTLEN-1 : 73-1);
      strncpy(fh.date, &hdr.date[3], 5);
      sprintf(fh.filename, "M.%d.A", i);

      fwrite(&fh, sizeof(fh), 1, ft);

      sprintf(buf, "cp -f %s/usr/%c/%s/%c/%s %s/home/%s/%s", argv[2],
              tolower(*u.userid), u.userid, hdr.xname[strlen(hdr.xname)-1],
              hdr.xname, BBSHOME, u.userid, fh.filename);
      system(buf);
    }

    puts("OK!");

    fclose(fs), fclose(ft);
  }

  fclose(fp);

  return 0;
}
