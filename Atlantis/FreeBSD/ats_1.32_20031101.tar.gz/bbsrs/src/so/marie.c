/*-------------------------------------------------------*/
/* marie.c                           Wind & Dust BBS 2.9 */
/*-------------------------------------------------------*/
/* create :   /  /                                       */
/* update : 03/08/27 (Dopin)                             */
/*-------------------------------------------------------*/

#include "bbs.h"
#include "wd.h"

#define PICTURE BBSHOME "/game/marie"
#define GMONEY  BBSHOME "/game/money"

unsigned totalmoney;
int show_m(unsigned);

int mary_m() {
  FILE *fs;
  unsigned int total=0;

  if((fs = fopen(GMONEY, "r")) == NULL) {
    pressanykey(file_open_er);
    return 1;
  }
  fscanf(fs, "%d", &totalmoney);
  fclose(fs);

  if(load_money()) {
    pressanykey(msg_load_m_e);
    return 1;
  }

  total = cuser.havemoney;
  setutmpmode(MARIE);
  clear();
  show_file(PICTURE, 0, 24, ONLY_COLOR);
  totalmoney = show_m(totalmoney);

  if((fs = fopen(GMONEY, "w+")) == NULL) {
    pressanykey(file_open_er);
    return 1;
  }
  fprintf(fs, "%d", totalmoney);
  fclose(fs);

  return;
}

int show_m(unsigned totalmoney) {
  static int x[10] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, w = 0, bet_flag = 0;
  /* ���v */
  int c_flag[10]= { 1, 2, 5, 10, 20, 50, 100, 200, 500, 1000 };
  int i, ch, bet = 0;

  clear();
  show_file(PICTURE, 0, 24, ONLY_COLOR);
  move(8, 44);
  prints("[1m�����O�����{��: %-ld[m", totalmoney);
  move(9, 44);
  prints("[1m�z���W�{���Ȩ�: %-d��[m", cuser.havemoney);
  move(10, 44);
  prints("[1m�ثe��`�����v�O [46m%6d��[m", c_flag[w]);

  move(b_lines - 4, 0);
  for(i = 0 ; i < 9 ; i++) prints("[1;%2d;40m  %5d", x[i] ? 33 : 37, x[i]);

  ch = 0;
  while(!ch) {
    ch = cursor_key(b_lines-1, 3);

    switch(ch) {
      case 'w':
      case 'W':
        w = (w+1) % 10;
        break;

      case 's':
      case 'S':
        if(bet_flag) {
          int i, j, seed, ran, gold = 0;
          int g[10] = { 5, 40, 30, 25, 50, 20, 15, 10, 2, 0 };
          time_t now = time(0);

          seed = 1000;
          srandom((unsigned)time(NULL));
          ran = random() % seed;

               if(ran <= 400) j = 8;   /*  2 */
          else if(ran <= 520) j = 0;   /*  5 */
          else if(ran <= 580) j = 7;   /* 10 */
          else if(ran <= 620) j = 6;   /* 15 */
          else if(ran <= 650) j = 5;   /* 20 */
          else if(ran <= 663) j = 3;   /* 25 */
          else if(ran <= 678) j = 2;   /* 30 */
          else if(ran <= 686) j = 1;   /* 40 */
          else if(ran <= 690) j = 4;   /* 50 */
          else                j = 9;   /* �b�t */

          gold = x[j] * g[j];

          out2line(0, 14, "");
          move(14, 0);
          outc(' ');
          for(i = 0 ; i < 9 ; i++) {
            prints("     [1;%2d;40m��", (i-j) ? 37 : 31);
            bet += x[i];
            x[i] = 0;
          }
          prints("     [1;%2d;40m��[m", j == 9 ? 31 : 37);

          if(gold) {
            pressanykey("���� �z�i�o %d �Ȩ�", gold);

            if(gold > 100000) game_log(MARIE, "[1;31mĹ�F %d ��[m", gold);
            inmoney(gold);

            if(gold >= 100)
            totalmoney -= gold;
          }
          else {
            pressanykey("�b�t ... =.=");
            game_log(MARIE, "[1;32m��F %d ��![m",bet);
          }

          bet_flag = 0;

          break;
        }
        else pressanykey("�Х���` !");

        break;

      case 'a':
      case 'A':
        if(check_money(' ', 0) < 9 * c_flag[w]) clear();
        else {
          demoney(9 * c_flag[w]);
          totalmoney += 9 * c_flag[w];
          for(i = 0 ; i <= 8 ; i++) x[i] += c_flag[w];
          bet_flag=1;
        }

        break;

      case 'q' :
      case 'Q' :
      case '\n':
      case '\r':
        if(bet_flag) pressanykey("�z�w�g�U�`, �Х���������");
        else         return totalmoney;

        break;

      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
        i = (ch - '0');

        if(check_money(' ', 0) < c_flag[w]) clear();
        else {
          demoney(c_flag[w]);

          totalmoney += c_flag[w];
          x[i-1]     += c_flag[w];
          bet_flag    = 1;
        }

        break;

      default:
        ch = 0;
        break;
    }
  }

  show_file(PICTURE, 0, 24, ONLY_COLOR);
  show_m(totalmoney);
}
