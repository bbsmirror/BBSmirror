/*-------------------------------------------------------*/
/* cache.c      ( NTHU CS MapleBBS Ver 2.36 )            */
/*-------------------------------------------------------*/
/* target : cache up data by shared memory               */
/* create : 95/03/29                                     */
/* update : 02/07/19 (Dopin)                             */
/*-------------------------------------------------------*/

#include "bbs.h"
#include <sys/ipc.h>
#include <sys/shm.h>

#ifdef _BBS_UTIL_C_
char *fn_passwd = BBSHOME "/.PASSWDS";
char *fn_board = BBSHOME "/.BOARDS";
#endif

#ifdef  HAVE_MMAP
#include <sys/mman.h>
#else
int usernumber;
#endif

struct UCACHE *uidshm;

static void attach_err(int shmkey, char *name) {
  fprintf(stderr, "[%s error] key = %x\n", name, shmkey);
  exit(1);
}

static void *attach_shm(int shmkey, int shmsize) {
  void *shmptr;
  int shmid;

  shmid = shmget(shmkey, shmsize, 0);

  if(shmid < 0) {
    shmid = shmget(shmkey, shmsize, IPC_CREAT | 0600);
    if(shmid < 0) attach_err(shmkey, "shmget");

    shmptr = (void *) shmat(shmid, NULL, 0);
    if(shmptr == (void *) -1) attach_err(shmkey, "shmat");

    memset(shmptr, 0, shmsize);
  }
  else {
    shmptr = (void *) shmat(shmid, NULL, 0);
    if(shmptr == (void *) -1) attach_err(shmkey, "shmat");
  }

  return shmptr;
}

/*-------------------------------------------------------*/
/* .PASSWDS cache                                        */
/*-------------------------------------------------------*/

#ifndef HAVE_MMAP
static int fillucache(userec *uentp) {
  if(usernumber < MAXUSERS) {
    strncpy(uidshm->userid[usernumber], uentp->userid, IDLEN + 1);
    uidshm->userid[usernumber++][IDLEN] = '\0';
  }

  return 0;
}
#endif

/* -------------------------------------- */
/* (1) �t�αҰʫ�A�Ĥ@�� BBS user ��i�� */
/* (2) .PASSWDS ��s��                    */
/* -------------------------------------- */

void reload_ucache() {
  if(uidshm->busystate) {

    /* ------------------------------------------ */
    /* ��L user ���b flushing ucache ==> CSMA/CD */
    /* ------------------------------------------ */

    if(uidshm->touchtime - uidshm->uptime > 30) {
      uidshm->busystate = 0;  /* leave busy state */

#if !defined(_BBS_UTIL_C_)
      log_usies("CACHE", "refork token");
#endif
    }
    else sleep(1);
  }
  else {
    uidshm->busystate = 1;    /* enter busy state */

#ifdef  HAVE_MMAP
    {
      register int fd, usernumber = 0;

      if((fd = open(fn_passwd, O_RDONLY)) > 0) {
        caddr_t fimage, mimage;
        struct stat stbuf;

        fstat(fd, &stbuf);
        fimage = mmap(NULL, stbuf.st_size, PROT_READ, MAP_SHARED, fd, 0);
        if(fimage == (char *) -1) exit(-1);
        close(fd);

        fd = stbuf.st_size / sizeof(userec);
        if(fd > MAXUSERS) fd = MAXUSERS;

        for(mimage = fimage ; usernumber < fd ; mimage += sizeof(userec))
          memcpy(uidshm->userid[usernumber++], mimage, IDLEN);

        munmap(fimage, stbuf.st_size);
      }

      uidshm->number = usernumber;
    }
#else

    usernumber = 0;

    apply_record(fn_passwd, fillucache, sizeof(userec));
    uidshm->number = usernumber;
#endif

    /* �� user ��Ƨ�s��A�]�w uptime */
    uidshm->uptime = uidshm->touchtime;

#if !defined(_BBS_UTIL_C_)
    log_usies("CACHE", "reload ucache");
#endif

    uidshm->busystate = 0;    /* leave busy state */
  }
}

void resolve_ucache() {
  if(uidshm == NULL) {
    uidshm = attach_shm(UIDSHM_KEY, sizeof(*uidshm));
    if(uidshm->touchtime == 0) uidshm->touchtime = 1;
  }

  while(uidshm->uptime < uidshm->touchtime) reload_ucache();
}

int ci_strcmp(register char *s1, register char *s2) {
  register int c1, c2, diff;

  do {
    c1 = *s1++;
    c2 = *s2++;

    if(c1 >= 'A' && c1 <= 'Z') c1 |= 32;
    if(c2 >= 'A' && c2 <= 'Z') c2 |= 32;
    if(diff = c1 - c2)         return (diff);
  } while (c1);

  return 0;
}

int searchuser(char *userid) {
  register char *ptr;
  register int i = 0, j;

  resolve_ucache();

  j = uidshm->number;

  while(i < j) {
    ptr = uidshm->userid[i++];

    if(!ci_strcmp(ptr, userid)) {
      strcpy(userid, ptr);
      return i;
    }
  }

  return 0;
}

/*-------------------------------------------------------*/
/* .BOARDS cache                                         */
/*-------------------------------------------------------*/

struct BCACHE *brdshm;
boardheader *bcache;
int numboards = -1;

/* force re-caching */

void touch_boards() {
  time(&(brdshm->touchtime));
  numboards = -1;
}

int reload_bcache(char mode, char *brdname) {
  if(brdshm->busystate) sleep(1);
  else {
    int fd;

    brdshm->busystate = 1;

    if((fd = open(fn_board, O_RDONLY)) > 0) {
      brdshm->number = read(fd, bcache, MAXBOARD * sizeof(boardheader))
                            / sizeof(boardheader);
      close(fd);
    }

#if !defined(_BBS_UTIL_C_)
#ifdef SHM_BOARD_NAME_LIST
    if(numboards < 1 || !mode || !brdshm->uptime) {
      int i;
      char fpath[64];

      if(!brdname) memset(brdshm->blist, 0, sizeof(brdshm->blist));

      for(i = 0 ; i < brdshm->number ; i++) {
        if(brdname && strcmp(brdshm->bcache[i].brdname, brdname)) continue;

        setbfile(fpath, brdshm->bcache[i].brdname, "dumplist");
        if((fd = open(fpath, O_RDONLY)) == -1) continue;
        read(fd, &brdshm->blist[i], sizeof(SBNL));
        close(fd);

        if(brdname) break;
      }
    }
#endif
#endif

    /* ���Ҧ� boards ��Ƨ�s��A�]�w uptime */
    brdshm->uptime = brdshm->touchtime;

#if !defined(_BBS_UTIL_C_)
    log_usies("CACHE", "reload bcache");
#endif
    brdshm->busystate = 0;
  }

  return 0;
}

void resolve_boards(char mode, char *brdname) {
  if(brdshm == NULL) {
    brdshm = attach_shm(BRDSHM_KEY, sizeof(*brdshm));
    if(brdshm->touchtime == 0) brdshm->touchtime = 1;
    bcache = brdshm->bcache;
  }

  while(brdshm->uptime < brdshm->touchtime) reload_bcache(mode, brdname);
  numboards = brdshm->number;
}

#ifdef SHM_BOARD_NAME_LIST
/* Dopin: �Ĥ@���n���� �� SOB �a�ڥu�|�b�Ĥ@���I�s Ben_Perm �ɥh resolve  */
/*        brdshm ���o�˴N�L�k���(�����J list) �G�ݩ�n���ɹw�����ˬd���J */
void check_shm_blist() {
  if(shmget(BRDSHM_KEY, sizeof(*brdshm), SHM_R | SHM_W) < 0)
    resolve_boards(0, NULL);
}
#endif

boardheader *getbcache(char *bname) {
  register int i;
  register boardheader *bhdr;

  resolve_boards(1, NULL);
  for(i = 0, bhdr = bcache; i < numboards; i++, bhdr++)
    /* if (Ben_Perm(bhdr)) */
    if(!ci_strcmp(bname, bhdr->brdname)) return bhdr;

  return NULL;
}

int getbnum(char *bname) {
  register int i;
  register boardheader *bhdr;

  resolve_boards(1, NULL);
  for(i = 0, bhdr = bcache; i++ < numboards; bhdr++)
    /* if (Ben_Perm(bhdr)) */
    if(!ci_strcmp(bname, bhdr->brdname)) return i;
  return 0;
}

/*-------------------------------------------------------*/
/* .UTMP cache                                           */
/*-------------------------------------------------------*/

struct UTMPFILE *utmpshm;
user_info *currutmp;

void resolve_utmp() {
  if(utmpshm == NULL) {
    utmpshm = attach_shm(UTMPSHM_KEY, sizeof(*utmpshm));
    if(utmpshm->uptime == 0) utmpshm->uptime = utmpshm->number = 1;
  }
}

#if !defined(_BBS_UTIL_C_)
int getuser(char *userid) {
  int uid;

  if(uid = searchuser(userid))
    get_record(fn_passwd, &xuser, sizeof(xuser), uid);

  return uid;
}

char *getuserid(int num) {
  if(--num >= 0 && num < MAXUSERS) return ((char *) uidshm->userid[num]);

  return NULL;
}

void setuserid(int num, char *userid) {
  if(num > 0 && num <= MAXUSERS) {
    if(num > uidshm->number) uidshm->number = num;

    strncpy(uidshm->userid[num - 1], userid, IDLEN + 1);
  }
}

int searchnewuser(int mode) {  /* 0 ==> ��L���b�� / 1 ==> �إ߷s�b�� */
  register int i = 0, num;

  resolve_ucache();
  num = uidshm->number;

  while(i < num) if(!uidshm->userid[i++][0]) return (i);

  if(mode && (num < MAXUSERS)) return (num + 1);

  return 0;
}

#if 0
int apply_users(void (*func)()) {
  register int i, num;

  resolve_ucache();
  num = uidshm->number;

  for(i = 0; i < num; i++) (*func) (uidshm->userid[i], i + 1);

  return 0;
}
#endif

char *u_namearray(char buf[][IDLEN + 1], int *pnum, char *tag) {
  register struct UCACHE *reg_ushm = uidshm;
  register char *ptr, tmp;
  register int n, total;
  char tagbuf[STRLEN];
  int ch, ch2, num;

  resolve_ucache();

  if(*tag == '\0') {
    *pnum = reg_ushm->number;
    return reg_ushm->userid[0];
  }

  for(n = 0 ; tag[n] ; n++) tagbuf[n] = chartoupper(tag[n]);

  tagbuf[n] = '\0';
  ch = tagbuf[0];
  ch2 = ch - 'A' + 'a';
  total = reg_ushm->number;

  for(n = num = 0; n < total; n++) {
    ptr = reg_ushm->userid[n];
    tmp = *ptr;

    if(tmp == ch || tmp == ch2)
      if(chkstr(tag, tagbuf, ptr)) strcpy(buf[num++], ptr);
  }

  *pnum = num;

  return buf[0];
}

void setutmpmode(int mode) {
  if(currstat != mode) currutmp->mode = currstat = mode;
}

/* woju */
void resetutmpent() {
  extern int errno;
  register time_t now;
  register int i;
  register pid_t pid;
  register user_info *uentp;

  resolve_utmp();

  now = time(NULL) - 79;
  if(now > utmpshm->uptime) utmpshm->busystate = 0;

  while(utmpshm->busystate) sleep(1);

  utmpshm->busystate = 1;

  /* ------------------------------ */
  /* for ���F�ǻ�: �C 79 ����s�@�� */
  /* ------------------------------ */

  for(i = now = 0; i < USHM_SIZE; i++) {
    uentp = &(utmpshm->uinfo[i]);

    if(pid = uentp->pid) {
      if(pid == 1 || (kill(pid, 0) == -1) && (errno == ESRCH))
        memset(uentp, 0, sizeof(user_info));
      else now++;
    }
  }

  utmpshm->number = now;
  time(&utmpshm->uptime);
  utmpshm->busystate = 0;
}

void getnewutmpent(user_info *up) {
  register int i;
  register user_info *uentp;

  resetutmpent();

  while (utmpshm->busystate) sleep(1);

  utmpshm->busystate = 1;

  for(i = 0; i < USHM_SIZE; i++) {
    uentp = &(utmpshm->uinfo[i]);

    if(uentp->pid < 2) {
      memcpy(uentp, up, sizeof(user_info));
      currutmp = uentp;
      utmpshm->number++;
      utmpshm->busystate = 0;

      return;
    }
  }

  utmpshm->busystate = 0;
  sleep(1);

  exit(1);
}

int apply_ulist(int (*fptr)()) {
  register user_info *uentp;
  register int i, state;

  resolve_utmp();
  for(i = 0; i < USHM_SIZE; i++) {
    uentp = &(utmpshm->uinfo[i]);
    if(uentp->pid && (PERM_HIDE(currutmp) ||
       !(PERM_HIDE(uentp) && !(is_rejected(uentp) & 2))))
      if(state = (*fptr) (uentp)) return state;
  }

  return 0;
}

user_info *search_ulist(int (*fptr)(), int farg) {
  register int i;
  register user_info *uentp;

  resolve_utmp();

  for(i = 0; i < USHM_SIZE; i++) {
    uentp = &(utmpshm->uinfo[i]);

    if((*fptr)(farg, uentp)) return uentp;
  }

  return 0;
}

int count_multi() {
  register int i, j;
  register user_info *uentp;

  resolve_utmp();

  for(i = j = 0 ; i < USHM_SIZE ; i++) {
    uentp = &(utmpshm->uinfo[i]);

    if(uentp->uid == usernum) j++;
  }

  return j;
}

/* -------------------- */
/* for multi-login talk */
/* -------------------- */

user_info *search_ulistn(int (*fptr)(), int farg, int unum) {
  register int i, j;
  register user_info *uentp;

  resolve_utmp();

  for(i = j = 0 ; i < USHM_SIZE ; i++) {
    uentp = &(utmpshm->uinfo[i]);

    if((*fptr)(farg, uentp)) {
      if(++j == unum) return uentp;
    }
  }

  return 0;
}

int count_logins(int (*fptr)(), int farg, int show) {
  register user_info *uentp;
  register int i, j;

  resolve_utmp();

  for(i = j = 0; i < USHM_SIZE; i++) {
    uentp = &(utmpshm->uinfo[i]);

    if((*fptr)(farg, uentp)) {
      j++;

      if(show)
        prints("(%d) �ثe���A��: %-17.16s(�Ӧ� %s)\n", j,
               modestring(uentp, 0), uentp->from);
    }
  }

  return j;
}

void purge_utmp(user_info *uentp) {
  memset(uentp, 0, sizeof(user_info));

  if(utmpshm->number) utmpshm->number--;
}

int count_ulist() {
  int ans = utmpshm->number;
  register user_info *uentp;
  int ch = 0;

  while (ch < USHM_SIZE) {
    uentp = &(utmpshm->uinfo[ch++]);

    if(uentp->pid && (
       is_rejected(uentp) & 2 && !HAS_PERM(PERM_SYSOP) ||
       uentp->invisible && !HAS_PERM(PERM_SEECLOAK) &!HAS_PERM(PERM_SYSOP) ||
       !PERM_HIDE(currutmp) && PERM_HIDE(uentp) ||
       cuser.uflag & FRIEND_FLAG && !is_friend(uentp))
    ) --ans;
  }

  return ans;
}

int apply_boards(int (*func)()) {
  register int i;
  register boardheader *bhdr;

  resolve_boards(1, NULL);
  for(i = 0, bhdr = bcache; i < numboards ; i++, bhdr++) {
    if(Ben_Perm(bhdr))
      if((*func) (bhdr) == QUIT)
        return QUIT;
  }

  return 0;
}

int haspostperm(char *bname) {
  register int i;
  char buf[200];

  setbfile(buf, bname, fn_water);
  if(belong(buf, cuser.userid)) return 0;

  if(!ci_strcmp(bname, DEFAULT_BOARD)) return 1;

  if(!cuser.userlevel) {
    char *ptr;

    if(belong("etc/anonymous", cuser.userid)) {
      while(ptr = strtok(NULL, str_space)) {
        if(!ci_strcmp(bname, ptr)) return 1;
      }
    }
    return 0;
  }

  if(!HAS_PERM(PERM_POST)) return 0;
  if(!(i = getbnum(bname))) return 0;

  i = bcache[i - 1].level;

  /* ���K�ݪO�S�O�B�z */
  setbfile(buf, bname, "permlist");
  if(i & PERM_SECRET || i & PERM_ENTERSC)
    if(i & PERM_POSTMASK) return belong(buf, cuser.userid);
    else                  return 1;

  return (HAS_PERM(i & ~PERM_POSTMASK & ~PERM_POST));
}
#endif
/* !defined(_BBS_UTIL_C_) */
