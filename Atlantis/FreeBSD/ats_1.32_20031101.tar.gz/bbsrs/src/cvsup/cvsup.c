/*-------------------------------------------------------*/
/* cvsup/cvsup.c              (SOB 0.22 ATS Verion 1.32) */
/*-------------------------------------------------------*/
/* target : CVS/SUP ����D�{��                           */
/* create : 03/04/02 by Dopin                            */
/* update : 03/08/16                                     */
/*-------------------------------------------------------*/

#include "cvsup.h"
#include "dopin.h"

#undef DEBUG

char mon = 0;
int  year = 0;
int  cvsid = 0;
int  nochecksum = 0;
int  updatemode = -1;  /* 0:visit 1:fetch_only 2:update 3:force_update */

void show_syntex() {
  puts("cvsup <visit|update|fetch_only|force_update/id:CVSID/date:yyyy/mm>");
  puts("Atlantis BBS(C) 1.32-Release by Dopin");
}

int check_syntex(int argn, char *args[]) {
  char fg, ci, index;
  char *modes[] = { "visit", "fetch_only", "update", "force_update",
                    "id:00000", "date:0000/00" };

  if(argn == 1 || argn > 4) return -1;

  /* �Ĥ@�ӰѼ� �u��O visit/update/fetch_only/force_update */
  fg = 0;
  for(index = 0 ; index < 4 ; index++) {
    int ml;

    ml = strlen(modes[index]);
    if(!strncmp(modes[index], args[1], ml)) {
      if(!(strlen(args[1]) - ml - 1) && args[1][ml] == '!') nochecksum = 1;

      updatemode = index;
      fg = 1;
    }
  }
  if(!fg) return -2;

  /* �ĤG�ӰѼ� �u��O �Ҧ��D visit �B �� id �Ѽƪ����p */
  if(argn > 2) {
    if(!updatemode) return -3;

    if(strlen(args[2]) == strlen(modes[4])) {
      if(!strncmp(args[2], modes[4], 3) && (cvsid = atoi(&args[2][3]))) ;
      else return -3;
    }
  }

  if(argn > 3) {
    if(strlen(args[3]) == strlen(modes[5])) {
      if(!strncmp(args[3], modes[5], 5) && args[3][9] == '/') {
        char buf[16];

        strcpy(buf, args[3]);
        buf[9] = 0;

        year = atoi(&buf[5]);
        mon  = (char)atoi(&buf[10]);

        if(!year || !mon) return -4;
      }
      else return -5;
    }
    else return -5;
  }

  return 0;
}

int visit_temp(char mode) {
  char buf[128];

  if(dashd(CVS_WORK)) {
    if(mode == 'V') return -1;
    else {
      sprintf(buf, "rm -rf %s", CVS_WORK);
      system(buf);
    }
  }

  if(mode != 'D') {
    sprintf(buf, "mkdir %s", CVS_WORK);
    system(buf);
  }

  return 0;
}

int main(int argc, char *argv[]) {
  char day, hour, min, curcvs[64], buf[256];
  int i;
  time_t now = time(NULL);
  FILE *fs, *ft;

  if(check_syntex(argc, argv)) {
    show_syntex();
    return -1;
  }

  if(visit_temp('V')) {
    if(strcmp(argv[1], "force-update")) {
      write_log("[ERROR] Working Directory Exist !");
      return -1;
    }
    else visit_temp('F');
  }

  chdir(CVS_WORK);
  if(!year && !mon) get_tm_time(&year, &mon, &day, &hour, &min, NULL);
  for(i = 0 ; i < ERROR_COUNT ; i++) {
    sprintf(buf, "wget -c %s/%d-%d/cvs_index > /dev/null 2>&1",
            OFFICAL_URL, year, mon);
    if(system(buf)) continue;
    else break;
  }

  if(i == ERROR_COUNT) {
    write_log("[ERROR] Receving file 'cvs_index' Fault ...");
    return -2;
  }

  i = patch_update(year, mon);
  if(i == 0 || i == 999) {
    if(updatemode != 1) visit_temp('D');

    if(i == 0) write_log("[SUCCESS] BBS cvsup finished ...");
    else       write_log("[MESSAGE] Visit Mode finished ...");

#ifdef DEBUG
    printf("SYSTEM Code : %d\n", i);
#endif

    return 0;
  }
  else {
#ifdef DEBUG
    printf("ERROR Code : %d\n", i);
#endif
    return -i;
  }
}
