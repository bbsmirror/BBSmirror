/*-------------------------------------------------------*/
/* wd.h                             SOB 0.22 ATS Version */
/*-------------------------------------------------------*/
/* target : �ޥ� Wind & Dust (C) BBS ���e�������禡      */
/*          �� �ഫ WD �禡�P ATS �禡�ۮe               */
/* create : 03/08/23                                     */
/* update :                                              */
/*-------------------------------------------------------*/

#include <varargs.h>

#define COLOR1  "[46;37m"
#define COLOR2  "[1;44;33m"

extern int item_update_passwd(char);
extern int check_money(char, int);
extern int dashd(char *);
extern int dashf(char *);

char *msg_load_m_e = "�����Ū�����~ �Э��n��A�ո� ��������L�h���n���s�u";
char *file_open_er = "�}�ɿ��~ �Ь��t�ί���";

/* ----------------------------------------------------- */
/* strip ansi mode                                  Ptt  */
/* ----------------------------------------------------- */

enum {
  STRIP_ALL, ONLY_COLOR, NO_RELOAD
};

/* ----------------------------------------------------- */
/* records access                                   SOB  */
/* ----------------------------------------------------- */

int rec_get(char *fpath, void *rptr, int size, int id) {
  return get_record(fpath, rptr, size, id);
}

int rec_add(char *fpath, void *record, int size) {
  return append_record(fpath, record, size);
}

int rec_del(char *fpath, int size, int id) {
  return delete_record(fpath, size, id);
}

/* ----------------------------------------------------- */
/* Origin Functions (may modify)                     WD  */
/* ----------------------------------------------------- */

// WD/stuff.c
int answer(char *s) {
  char ch;

  outmsg(s);
  ch = igetch();
  ch = tolower(ch);  /* Dopin: �����Q�� tolower() */

  return ch;
}

// WD/stuff.c
off_t dashs(char *fname) {
  struct stat st;

  if(!stat(fname, &st)) return (st.st_size);
  else                  return -1;
}

// WD/stuff.c
int game_log(va_alist)
va_dcl
{
  va_list ap;
  int file;
  char *fmt, msg[200], ff[40];
  time_t now;
  FILE *fs;

  va_start(ap);
  file = va_arg(ap, int);
  fmt = va_arg(ap, char *);
  vsprintf(msg, fmt, ap);
  va_end(ap);

  switch(file) {
    /* �o�@�q�i�H�ۤv��! */
    case XAXB:      strcpy(ff, "log/ab.log");       break;
    case CHICKEN:   strcpy(ff, "log/pipwd.log");    break;
    case BLACKJACK: strcpy(ff, "log/bj.log");       break;
    case STOCK:     strcpy(ff, "log/stock.log");    break;
    case DICE:      strcpy(ff, "log/dice.log");     break;
    case GP:        strcpy(ff, "log/gp.log");       break;
    case MARIE:     strcpy(ff, "log/marie.log");    break;
    case RACE:      strcpy(ff, "log/race.log");     break;
    case BINGO:     strcpy(ff, "log/bingo.log");    break;
    case NINE:      strcpy(ff, "log/nine.log");     break;
    case NumFight:  strcpy(ff, "log/fightnum.log"); break;
    case CHESSMJ:   strcpy(ff, "log/chessmj.log");  break;
    case SEVENCARD: strcpy(ff, "log/seven.log");    break;
  }

  if((fs = fopen(ff, "a+")) != NULL) {
    now = time(0);
    fprintf(fs, "[1;33m%s [32m%s [36m%s[m\n", Cdate(&now), cuser.userid,
            msg);
    fclose(fs);
  }
}

// �� WD : show_file ����g��
void show_file(char *filename, int row, int col, int mode) {
  FILE *fp;
  char buf[256];

  move(row, 0);  /* Dopin: �� move(row, col); �e������ýX */
  if((fp = fopen(filename, "r")) == NULL) return;

  while(fgets(buf, 256, fp)) outs(buf);
  fclose(fp);
}

/* ---------------------------------------------------- */
/* Money Process                                   ATS  */
/* ---------------------------------------------------- */

int inmoney(int money) {
  return check_money('+', money);
}

int demoney(int money) {
  return check_money('-', money);
}

int load_money(void) {
  item_update_passwd('l');

  if(!strcmp(cuser.userid, xuser.userid)) cuser.havemoney = xuser.havemoney;
  else                                    return -1;

  return 0;
}
