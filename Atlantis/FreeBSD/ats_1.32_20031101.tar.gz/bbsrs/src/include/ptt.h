/* ---------------------------------------------------- */
/* Atlantis Function ProtoType                     ATS  */
/* ---------------------------------------------------- */

extern int item_update_passwd(char);
extern int check_money(char, int);
extern int dashd(char *);
extern int dashf(char *);

char *Ptt_prints(char *, int );

int show_file(char *filename, int y, int lines, int mode) {
  FILE *fp;
  char buf[256];

  if(y >= 0) move(y, 0);
  else return 0;

  eolrange(y, lines + y);
  move(y, 0);

  if((fp = fopen(filename, "r"))) {
    while(fgets(buf, 256, fp) && lines--) outs(Ptt_prints(buf, mode));
    fclose(fp);
  } else return 0;

  return 1;
}

/* ------------------------------------------------------ */
/*                                                        */
/* ------------------------------------------------------ */

extern struct UTMPFILE *utmpshm;
char *BBSName = BBSNAME;

/* ----------------------------------------------------- */
/* strip ansi mode                                  Ptt  */
/* ----------------------------------------------------- */

enum {
  STRIP_ALL, ONLY_COLOR, NO_RELOAD
};

int strip_ansi(char *buf, char *str, int mode) {
  register int ansi, count = 0;

  for(ansi = 0; *str /*&& *str != '\n' */; str++) {
  if(*str == 27) {
  if(mode) {
  if(buf)
  *buf++ = *str;
  count++;
  }
  ansi = 1;
  } else if(ansi && strchr("[;1234567890mfHABCDnsuJKc=n", *str)) {
  if((mode == NO_RELOAD && !strchr("c=n", *str)) ||
  (mode == ONLY_COLOR && strchr("[;1234567890m", *str))) {
  if(buf)
  *buf++ = *str;
  count++;
  }
  if(strchr("mHn ", *str))
  ansi = 0;
  } else {
  ansi =0;
  if(buf)
  *buf++ = *str;
  count++;
  }
  }
  if(buf)
  *buf = '\0';
  return count;
}

char *Ptt_prints(char *str, int mode) {
  char *po , strbuf[256];

  while((po = strstr(str, "\033*s"))) {
  po[0] = 0;
  sprintf(strbuf, "%s%s%s", str, cuser.userid, po + 3);
  strcpy(str, strbuf);
  }
  while((po = strstr(str, "\033*t"))) {
  time_t now = time(NULL);

  po[0] = 0;
  sprintf(strbuf, "%s%s", str, Cdate(&now));
  str[strlen(strbuf)-1] = 0;
  strcat(strbuf, po + 3);
  strcpy(str, strbuf);
  }
  while((po = strstr(str, "\033*u"))) {
  int attempts;

  attempts = utmpshm->number;
  po[0] = 0;
  sprintf(strbuf, "%s%d%s", str, attempts, po + 3);
  strcpy(str, strbuf);
  }

  while((po = strstr(str, "\033*b"))) {
  po[0] = 0;
  sprintf(strbuf, "%s%d/%d%s", str, cuser.month, cuser.day, po + 3);
  strcpy(str, strbuf);
  }

  while((po = strstr(str, "\033*l"))) {
  po[0] = 0;
  sprintf(strbuf, "%s%d%s", str, cuser.numlogins, po + 3);
  strcpy(str, strbuf);
  }

  while((po = strstr(str, "\033*p"))) {
  po[0] = 0;
  sprintf(strbuf, "%s%d%s", str, cuser.numposts, po + 3);
  strcpy(str, strbuf);
  }
  while((po = strstr(str, "\033*n"))) {
  po[0] = 0;
  sprintf(strbuf, "%s%s%s", str, cuser.username, po + 3);
  strcpy(str, strbuf);
  }

  while((po = strstr(str, "\033*m"))) {
  po[0] = 0;
  sprintf(strbuf, "%s%ld%s", str, cuser.havemoney, po + 3);
  strcpy(str, strbuf);
  }

  strip_ansi(str, str ,mode);
  return str;
  }

/* ----------------------------------------------------- */
/* LOCK Mode                                        Ptt  */
/* ----------------------------------------------------- */

#define LOCK_THIS   1    // lock �o�u���୫�ƪ�
#define LOCK_MULTI  2    // lock �Ҧ��u���୫�ƪ�

/*
int lockutmpmode(int unmode, int state) {
int errorno = 0;

if(currutmp->lockmode) errorno = 1;
else if(count_multiplay(unmode))errorno = 2;

if(errorno && !(state == LOCK_THIS && errorno == LOCK_MULTI)) {
clear();
move(10,20);
if(errorno == 1)
prints("�Х����} %s �~��A %s ",
ModeTypeTable[currutmp->lockmode],
ModeTypeTable[unmode]);
else
prints("��p! �z�w����L�u�ۦP��ID���b%s",
ModeTypeTable[unmode]);
pressanykey();
return errorno;
}

setutmpmode(unmode);
currutmp->lockmode = unmode;
return 0;
}

int unlockutmpmode() {
currutmp->lockmode = 0;
return 0;
}
*/

/* ----------------------------------------------------- */
/* struct/definition of ptt-chicken                 Ptt  */
/* ----------------------------------------------------- */

#ifndef MAX_CHICKEN_MONEY                   /* �i����ì�Q�W�� */
#define MAX_CHICKEN_MONEY  100
#endif

typedef struct chicken_t {
  char name[20];
  char type;              /* ���� */
  unsigned char tech[16]; /* �ޯ� */
  time_t birthday;        /* �ͤ� */
  time_t lastvisit;       /* �W�����U�ɶ� */
  int oo;                 /* �ɫ~ */
  int food;               /* ���� */
  int medicine;           /* �ī~ */
  int weight;             /* �魫 */
  int clean;              /* ���b */
  int run;                /* �ӱ��� */
  int attack;             /* �����O */
  int book;               /* ���� */
  int happy;              /* �ּ� */
  int satis;              /* ���N�� */
  int temperament;        /* ��� */
  int tiredstrong;        /* �h�ҫ� */
  int sick;               /* �f����� */
  int hp;                 /* ��q */
  int hp_max;             /* ����q */
  int mm;                 /* �k�O */
  int mm_max;             /* ���k�O */
  time_t cbirth;          /* ��ڭp��Ϊ��ͤ� */
  int pad[2];             /* �d�ۥH��� */
} chicken_t;

/* ---------------------------------------------------- */
/* Ptt Functions                                   Ptt  */
/* ---------------------------------------------------- */

int log_file(char *filename, char *buf) {
  FILE *fp;

  if((fp = fopen(filename, "a+" )) != NULL ) {
    fputs( buf, fp );
    if(!strchr(buf,'\n')) fputc('\n',fp);
    fclose( fp );

    return 0;
  }
  else return -1;
}

int oldgetdata(char r, char c, char *s, char *b, int l, int m, char *g) {
  return getdata(r, c, s, b, l, m, g);
}

void passwd_query(int usernum, userec *muser) {
item_update_passwd('l');

cuser = xuser;
}

void passwd_update(int usernum, userec *muser) {
  item_update_passwd('l');

  xuser.five_win  = xuser.five_win;
  xuser.five_lose = xuser.five_lose;
  xuser.five_tie  = xuser.five_tie;

  item_update_passwd('u');
}

/* ---------------------------------------------------- */
/* Money Process                                   ATS  */
/* ---------------------------------------------------- */

int inmoney(int money) {
  return check_money('+', money);
}

int demoney(int money) {
  return check_money('-', money);
}

int reload_money(void) {
  item_update_passwd('l');

  if(!strcmp(cuser.userid, xuser.userid)) cuser.havemoney = xuser.havemoney;
  else                                    return -1;

  return 0;
}
