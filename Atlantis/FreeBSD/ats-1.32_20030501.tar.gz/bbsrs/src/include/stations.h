#include "bbs.h"

int station_num = 0;
char station_list[MAX_STATIONS][13] = {0};
char station_list_cn[MAX_STATIONS][15] = {0};
char station_limit[MAX_STATIONS] = {0};
char station_sysops[MAX_STATIONS][31] = {0};
