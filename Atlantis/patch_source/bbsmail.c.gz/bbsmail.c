/*-------------------------------------------------------*/
/* util/bbsmail.c       ( NTHU CS MapleBBS Ver 2.36 )    */
/*-------------------------------------------------------*/
/* target           : �� Internet �H�H�� BBS �����ϥΪ�  */
/* create           : 95/03/29                           */
/* anti-spam author : benyx (star.ee.ttit.edu.tw)        */
/* update           : 03/05/02 (Dopin)                   */
/*-------------------------------------------------------*/

/* Dopin: str_decode_M3 ������ by PaulLiu.bbs@processor.tfcis.org */
/* �ϥΤ�k�j�P�p�U: innbbsd ��
   �b SUBJECT �q news Ū�i�ӫ�, �I�s str_decode_M3(SUBJECT, mode) �N��F */

/* Dopin: �o�q�ثe�L�� �ڤw�ܧ�B�z�覡 �ϥ� ICONV_OK �Ӻ��@ */
/* bsd ���U�ϥέn�sĶ�ɭn�[  -I/usr/local/include -L/usr/local/lib -liconv
   �æw�� libiconv, �Y�u���S��iconv�N�⩳�U�� #define USE_ICONV 1 �R�F */

/* �w���H�U BBS �t�Τw�g���䴩: itoc, FireBird, WD, Maple3, WindTop
   ���դ�k: �� tw.bbs.comp.linux, �p�G�ݨ�@��Ǽ��D =?Big5?B? �N�O�S�䴩 */

/*-------------------------------------------------------*/
/* lib/str_decode.c     ( NTHU CS MapleBBS Ver 3.00 )    */
/*-------------------------------------------------------*/
/* target : included C for QP/BASE64 decoding            */
/* create : 95/03/29                                     */
/* update : 97/03/29                                     */
/*-------------------------------------------------------*/

#include <stdio.h>
#include <iconv.h>
#include <errno.h>
#include <string.h>

#define ICONV_OK

/* ----------------------------------------------------- */
/* QP code : "0123456789ABCDEF"                          */
/* ----------------------------------------------------- */

static int qp_code(register int x) {
  if(x >= '0' && x <= '9') return x - '0';
  if(x >= 'a' && x <= 'f') return x - 'a' + 10;
  if(x >= 'A' && x <= 'F') return x - 'A' + 10;
  return -1;
}

/* ------------------------------------------------------------------ */
/* BASE64 :                                                           */
/* "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/" */
/* ------------------------------------------------------------------ */

static int base64_code(register int x) {
  if(x >= 'A' && x <= 'Z') return x - 'A';
  if(x >= 'a' && x <= 'z') return x - 'a' + 26;
  if(x >= '0' && x <= '9') return x - '0' + 52;
  if(x == '+') return 62;
  if(x == '/') return 63;

  return -1;
}

/* ----------------------------------------------------- */
/* judge & decode QP / BASE64                            */
/* ----------------------------------------------------- */

static inline int isreturn(unsigned char c) {
  return c == '\r' || c == '\n';
}

static inline int is_space(unsigned char c) {
   return c == ' ' || c == '\t' || isreturn(c);
}

/* static inline */
int mmdecode(src, encode, dst, body)
  unsigned char *src; /* Thor.980901: src�Mdst�i�ۦP, ��src �@�w��?��\0���� */
  unsigned char encode; /* Thor.980901: �`�N, decode�X�����G���|�ۤv�[�W \0 */
  unsigned char *dst;
  char body;            /* 1:body  0:subject */
{
  unsigned char *t = dst;
  int pattern = 0, bits = 0;
  encode |= 0x20;        /* Thor: to lower */
  switch(encode)
  {
    case 'q':            /* Thor: quoted-printable */
      while(*src && *src != '?') /* Thor: delimiter */
      {                  /* Thor.980901: 0 ��O delimiter */
        if(*src == '=')
        {
          int x = *++src, y = x ? *++src : 0;
          if(isreturn(x)) continue;
          if( (x = qp_code(x)) < 0 || ( y = qp_code(y)) < 0) return -1;
          *t++ = (x << 4) + y , src++;
        }
        else if(*src == '_' && !body) /* �� subject �ɡA'_' �~�ݭn�ܦ� ' ' */
          *t++ = ' ', src++;
#if 0
        else if(!*src)    /* Thor: no delimiter is not successful */
          return -1;
#endif
        else             /* Thor: *src != '=' '_' */
          *t++ = *src++;
      }
      return t - dst;
    case 'b':            /* Thor: base 64 */
      while(*src && *src != '?') /* Thor: delimiter */ /* Thor.980901: 0�]�� */
      {                  /* Thor: pattern & bits are cleared outside */
        int x;
#if 0
        if (!*src) return -1; /* Thor: no delimiter is not successful */
#endif
        x = base64_code(*src++);
        if(x < 0) continue; /* Thor: ignore everything not in the base64,=,.. */
        pattern = (pattern << 6) | x;
        bits += 6;       /* Thor: 1 code gains 6 bits */
        if(bits >= 8)    /* Thor: enough to form a byte */
        {
          bits -= 8;
          *t++ = (pattern >> bits) & 0xff;
        }
      }
      return t - dst;
  }
  return -1;
}

int str_iconv_m3(
        const char *fromcode,           // charset of source string
        const char *tocode,             // charset of destination string
        char *src,                      // source string
        int srclen,                     // source string length
        char *dst,                      // destination string
        int dstlen)                     // destination string length
// �o�Ө禡�|�N�@�Ӧr�� (src) �q charset=fromcode �ন charset=tocode,
//  srclen �O src ������, dst �O��X��buffer, dstlen �h���w�F
// dst ���j�p, �̫�|�� '\0', �ҥH�n�d�@��byte��'\0'.
// �p�G�J�� src �����D�r�����r, �άO src ���������㪺 byte,
// ���|�屼.
{
        iconv_t iconv_descriptor;
        int iconv_ret,dstlen_old;

        dstlen--;       // keep space for '\0'

        dstlen_old = dstlen;

#ifdef ICONV_OK
        // Open a descriptor for iconv
        iconv_descriptor = iconv_open(tocode, fromcode);

        if (iconv_descriptor == ((iconv_t)(-1)) ) // if open fail
        {
                strncpy(dst,src,dstlen);
                return dstlen;
        }

        // Start translation
        while (srclen > 0 && dstlen > 0)
        {
                iconv_ret = iconv(iconv_descriptor, (void *)&src, &srclen,
                                                    &dst, &dstlen);
                if (iconv_ret  != 0)
                {
                        switch(errno)
                        {
                                // invalid multibyte happened
                                case EILSEQ:
                                        // forward that byte
                                        *dst = *src;
                                        src++; srclen--;
                                        dst++; dstlen--;
                                        break;
                                // incomplete multibyte happened
                                case EINVAL:
                                        // forward that byte (maybe wrong)
                                        *dst = *src;
                                        src++; srclen--;
                                        dst++; dstlen--;
                                        break;
                                // dst no rooms
                                case E2BIG:
                                        // break out the while loop
                                        srclen = 0;
                                        break;
                        }
                }
        }
        *dst = '\0';
        // close descriptor of iconv
        iconv_close(iconv_descriptor);
#endif

        return (dstlen_old - dstlen);
}

char *str_decode_M3(unsigned char *str, char mode) {
  int adj, i;
  char *ans = (unsigned char *)str;
  unsigned char *src, *dst;
  unsigned char buf[512], charset[512], dst1[512];

  src = str;
  dst = buf;
  adj = 0;

  while (*src && (dst - buf) < sizeof(buf) - 1)
  {
    // Dopin: ²�������m����D �n�A���H�p�|�} �N�ݬO�n�ԭ@�٬O��쩳�F = =;;;
    if(mode && *src == '\033' && strstr(src, "m")) while(*(src++) != 'm') ;

    if (*src != '=')
    {                        /* Thor: not coded */
      unsigned char *tmp = src;
      while(adj && *tmp && is_space(*tmp)) tmp++;
      if(adj && *tmp=='=')
      {                     /* Thor: jump over space */
        adj = 0;
        src = tmp;
      }
      else
        *dst++ = *src++;
      /* continue;*/        /* Thor: take out */
    }
    else                    /* Thor: *src == '=' */
    {
      unsigned char *tmp = src + 1;
      if(*tmp == '?')       /* Thor: =? coded */
      {
        /* "=?%s?Q?" for QP, "=?%s?B?" for BASE64 */
        tmp ++;
        i=0;
        while(*tmp && *tmp != '?')
        {
                if (i+1<sizeof(charset))
                {
                        charset[i] = *tmp;
                        charset[i+1]='\0';
                        i++;
                }
                tmp++;
        }
        if(*tmp && tmp[1] && tmp[2]=='?') /* Thor: *tmp == '?' */
        {
          int i = mmdecode(tmp + 3, tmp[1], dst1, 0);
          i = str_iconv_m3(charset, "big5", dst1, i, dst,
                           sizeof(buf) - ((int)(dst-buf)));
          if (i >= 0)
          {
            tmp += 3;       /* Thor: decode's src */
            while(*tmp && *tmp++ != '?'); /* Thor: no ? end, mmdecode -1 */
                            /* Thor.980901: 0 �]�� decode ���� */
            if(*tmp == '=') tmp++;
            src = tmp;      /* Thor: decode over */
            dst += i;
            adj = 1;        /* Thor: adjcent */
          }
        }
      }

      while(src != tmp)     /* Thor: not coded */
        *dst++ = *src++;
    }
  }
  *dst = 0;
  strcpy(str, buf);

  return ans;
}

#include <sys/stat.h>
#include <sys/file.h>
#include <fcntl.h>
#include <time.h>
#include <sysexits.h>

#include "bbs.h"
#include "cache.c"
#include "record_util.c"

#define LOG_FILE        (BBSHOME "/mailog")

/* Dopin: for bad_hosts change from stuff.c */
int belong(char *filelist, char *key) {
  FILE *fp;
  char *str_space         = " \t\n\r";
  int rc = 0;

  if(fp = fopen(filelist, "r")) {
    char buf[STRLEN], *ptr;

    while(fgets(buf, STRLEN, fp)) {
      if((ptr = strtok(buf, str_space))) {
        if(!strcasecmp(ptr, key)) {
          rc = 1;
          break;
        }

        // Dopin: �B�z��Ӻ��� (���Ҽ{���פ�� �G .msn.com -> *msn.com*
        if(*buf == '.' && strstr(key, buf)) {
          rc = 1;
          break;
        }
      }
    }
    fclose(fp);
  }
  return rc;
}

/* Dopin: HTML/Attachment check */
int check_content(char *str) {
  char *bad[] = {
    "<HTML>",
    "<BR>",
    "<P>",
    "<a href",
    "<img ",
    "Content-Type",
    "text/html",
    "text/plain",
    "Content-disposition",
    "<script"
  };

  int i;
  const int badi = 10;

  for(i = 0 ; i < badi ; i++) if(strcasestr(str, bad[i])) return 1;

  return 0;
}

/* Dopin: spam mail check */
int is_spam(char *str, char *userid) {
  char *ptr = str, buf[128];

  /* Dopin: �a�� From --> �ױ� */
  if(belong(BBSHOME "/innd/bad_froms", ptr)) return 1;

  if(ptr = strchr(str, '@')) {
    int ci;

    ptr++; /* ���H�ݧڬ�ԣ���� strcat ? �U�@������ ?_? �ҥH�ڰ����o�� :p */
    for(ci = 0 ; (unsigned char)ptr[ci] > ' ' && ci < 127 ; ci++) ;
    ptr[ci] = 0;

    /* Dopin: �a�� Host Name --> �ױ� */
    if(belong(BBSHOME "/innd/bad_hosts", ptr)) return 1;
    /* Dopin: �L���� From --> �����D --> �ױ� */
    if(ci == 127) return 1;
  }

  sprintf(buf, "%s/home/%s/anti_spam", BBSHOME, userid);
  if(belong(buf, str)) return 1;

  sprintf(buf, "%s/home/%s/allow_list", BBSHOME, userid);
  if(belong(buf, str)) return 0;

  /* �p���]�w�զW�� �B ���b�զW�椤 --> Spam */
  if(dashf(buf)) return 1;
  else           return 0;
}

void mailog(char *msg) {
  FILE *fp;

  if(fp = fopen(LOG_FILE, "a+")) {
    time_t now;
    struct tm *p;

    time(&now);
    p = localtime(&now);
    fprintf(fp, "%02d/%02d/%02d %02d:%02d:%02d <bbsmail> %s\n",
            p->tm_year, p->tm_mon + 1, p->tm_mday, p->tm_hour, p->tm_min,
            p->tm_sec, msg);
    fclose(fp);
  }
}

/*
  DeltaStar BBS -- benyx ����
  �s�i�H�۰ʨ��v �ק�� rexchen.bbs@bbs.tku.edu.tw �H�j�p����
  �Ƨ@�άO�s mailing-list �@�_�ױ��A���O���{�� Load ���BI/O ��
  �Ʊ椣�ר� mailing-list �i�H�ק� Sendmail ���q�\�̧Φ��� mailer

  �i�H�[��s�i�H���e�M�ӷ��Ϊ��ТТ�b���A�Цۦ�M�w�[���[� SPAMID

  �ۦ��H��e�ԫʼƩw�q��                                    COMPARE
  �� Table ���F�᭫�m���û����ɫᦳ���ëH�󪺮e�Ԧ��Ʃw�q�� SUFFER

  �۰ʳƥ��s�i�H���S�x��ƪ��ɶ��A�w�]�Ȥ@�p��              BACKUP_TIME
  �i�H�����s��R�h�Y�Ǹ�ƩάO�ѦҪ��s�i�H���S�x�����      SPAMFLAG_FILE

  TODO:�@�q�ɶ���۰ʰh�� SPAM_MAIL
*/

#undef  SPAMID          "spam"

#define SPAMRULE        3             /* rule 2 �� 10 ����ĳ�W�L 10  */
#define COMPARE         3
#define SUFFER          2
#define SPAMTABLE       512

#ifndef SPAMSHM_KEY
#define SPAMSHM_KEY     1227
#endif

#define BACKUP_TIME     3600
#define SPAMFLAG_FILE   (BBSHOME "/etc/spamflag")

struct SPAM {
  int spam_a;
  int spam_b;
  int spam_c;
  int spam_times;
};

struct SPAM_MAIL {
  struct SPAM mail_flag[SPAMTABLE];
  time_t uptime;
  time_t touchtime;
};

struct  SPAM_MAIL     *spam;

void load_spam() {
  int i;
  FILE *fp;

  if(fp = fopen(SPAMFLAG_FILE, "r"))
    for(i=0 ; i < SPAMTABLE ; i++ )
      fscanf(fp,"%x %x %x %x\n", &spam->mail_flag[i].spam_a,
             &spam->mail_flag[i].spam_b, &spam->mail_flag[i].spam_c,
             &spam->mail_flag[i].spam_times);
  fclose(fp);

  mailog("Reload SpamFlag Table");
}

void backup_spam() {
  int i;
  FILE *fp;

  time(&spam->uptime);

  if(fp = fopen(SPAMFLAG_FILE,"w"))
    for(i=0 ; i < SPAMTABLE ; i++)
      fprintf(fp,"%x %x %x %x\n", spam->mail_flag[i].spam_a,
              spam->mail_flag[i].spam_b, spam->mail_flag[i].spam_c,
              spam->mail_flag[i].spam_times);

  fclose(fp);

  mailog("Backup SpamFlag Table");
}

void resolve_mailspam() {
  if(spam == NULL) {
    spam = attach_shm(SPAMSHM_KEY, sizeof(*spam));

    if(spam->touchtime == 0) {
      spam->touchtime = 1;
      load_spam(); }
    }

    if(time(NULL) > spam->uptime + BACKUP_TIME) backup_spam();
}

int seek_mailflag(int spam_a, int spam_b, int spam_c) {
  int i=0, j=0;

  if(spam_a == 0 && spam_b == 0 && spam_c == 0 ) return 0;

  for( i = 0 ; i < SPAMTABLE ; i++ ) {
    if(spam->mail_flag[i].spam_a == spam_a &&
       spam->mail_flag[i].spam_b == spam_b &&
       spam->mail_flag[i].spam_c == spam_c) {
      if(spam->mail_flag[i].spam_times < COMPARE) {
         spam->mail_flag[i].spam_times++;
         return 0;
      }
      else {
        spam->mail_flag[i].spam_times++;
        return 1;
      }
    }
  }
  for(i = 0 ; i < SPAMTABLE ; i++) {
    if(spam->mail_flag[i].spam_times == 0 ) {
      spam->mail_flag[i].spam_a = spam_a;
      spam->mail_flag[i].spam_b = spam_b;
      spam->mail_flag[i].spam_c = spam_c;
      spam->mail_flag[i].spam_times = 1 ;

      j = 1;
      break;
    }
  }

  if(j != 1) {
    for(i = 0 ; i < SPAMTABLE ; i++) {
      if(spam->mail_flag[i].spam_times <= SUFFER) {
        spam->mail_flag[i].spam_times = 0 ;
        spam->mail_flag[i].spam_a = 0 ;
        spam->mail_flag[i].spam_b = 0 ;
        spam->mail_flag[i].spam_c = 0 ;
      }
    }
  }

  return 0;
}



void strip_ansi(char *buf, char *str) {
  register int ch, ansi;

  for (ansi = 0; ch = *str; str++)
  {
    if (ch == '\n')
    {
      break;
    }
    else if (ch == 27)
    {
      ansi = 1;
    }
    else if (ansi)
    {
      if (!strchr("[01234567;", ch))
        ansi = 0;
    }
    else
    {
      *buf++ = ch;
    }
  }
  *buf = '\0';
}

int dashd(char *fname) {
  struct stat st;
  return (stat(fname, &st) == 0 && S_ISDIR(st.st_mode));
}

// Dopin: from --> stuff.c
int dashf(char *fname) {
  struct stat st;
  return (stat(fname, &st) == 0 && S_ISREG(st.st_mode));
}

int mail2bbs(char *userid) {
  fileheader mymail;
  char genbuf[512], title[256], sender[256], foutpath[256], *ip, *ptr;
  char fname[200], fnamepgp[200], pgppath[200];
  char firstline[100];
  struct stat st;
  time_t tmp_time;
  FILE *fout, *fpgp;
  int pgp = 0;

  /* check if the userid is in our bbs now */
  if(!searchuser(userid)) {
    sprintf(genbuf, "BBS user <%s> not existed", userid);
    puts(genbuf);
    mailog(genbuf);
    return EX_NOUSER;
  }

  sprintf(genbuf, "home/%s", userid);

  if(stat(genbuf, &st) == -1) {
    if(mkdir(genbuf, 0755) == -1) {
      sprintf(genbuf, "BBS user <%s> no mail box", userid);
      puts(genbuf);
      mailog(genbuf);
      return -1;
    }
  }
  else if(!(st.st_mode & S_IFDIR)) {
    sprintf(genbuf, "BBS user <%s> mail box error", userid);
    puts(genbuf);
    mailog(genbuf);
    return -1;
  }

#ifdef  DEBUG
  printf("dir: %s\n", genbuf);
#endif

  /* allocate a file for the new mail */
  stampfile(genbuf, &mymail);

#ifdef  DEBUG
  printf("file: %s\n", genbuf);
#endif

  /* copy the stdin to the specified file */
  if((fout = fopen(genbuf, "w")) == NULL) {
    printf("Cannot open file <%s>\n", genbuf);
    return -1;
  }
  else strcpy(foutpath, genbuf); /* �g�J file pointer path */

  sprintf(fnamepgp, "%s.pgp", strcpy(fname, genbuf));
  sprintf(pgppath, "home/%s/pgp", userid);

  /* parse header */
  title[0] = sender[0] = '\0';

  while(fgets(genbuf, sizeof(genbuf), stdin)) {
    if(!strncmp(genbuf, "From", 4)) {
      if((ip = strchr(genbuf, '<')) && (ptr = strrchr(ip, '>'))) {
        if(ip[-1] == ' ') ip[-1] = '\0';

        if(strchr(++ip, '@')) *ptr = '\0';
        else strcpy(ptr, "@" MYHOSTNAME); /* �� local host �H�H */

        ptr = (char *)strchr(genbuf, ' ');
        while(*++ptr == ' ') ;

        str_decode_M3(ip, 1);
        str_decode_M3(ptr, 1);

        /* Dopin: �ױ����i���r�����ӷ� by else.bbsbbs.kmsh.tnc.edu.tw */
        sprintf(sender,"%s",ip+1);  /* else: �����n��(�ʺ�)�[�J*/
        for(pgp = 0 ; pgp = strlen(sender) ; pgp++)
          if((unsigned)sender[pgp] < ' ' || (unsigned)sender[pgp] > 126)
            goto IS_SPAM;
        pgp = 0;
        /* Dopin */

        sprintf(sender, "%s (%s)", ip, ptr);
      }
      else {
        strtok(genbuf, " \t\n\r");
        strcpy(sender, (char *) strtok(NULL, " \t\n\r"));

        /* �� local host �H�H */
        if(strchr(sender, '@') == NULL) strcat(sender, "@" MYHOSTNAME);
      }
      continue;
    }

    if(!strncmp(genbuf, "Subject: ", 9)) {
      strip_ansi(title, genbuf + 9);
      str_decode_M3(title, 1);
      continue;
    }

    if(genbuf[0] == '\n') break;
  }

  time(&tmp_time);

  if(fgets(genbuf, sizeof(genbuf), stdin)) {
    strncpy(firstline, genbuf, 99);
    firstline[99] = 0;
    str_decode_M3(firstline, 1);
  }

  {
    char s_buf[128];

    /* Dopin: �@�����G���� �ϥΪ̩ڦ��ҥ~�H�]�@�_�ӧa QQ;;; */
    sprintf(s_buf, "home/%s/reject_imail", userid);
    if(dashf(s_buf)) goto IS_SPAM;

    strncpy(s_buf, sender, 127);
    s_buf[127] = 0;

    if(is_spam(s_buf, userid)) {
IS_SPAM:
       fclose(fout);
       unlink(foutpath); /* ���� ���d���� */

       return EX_NOUSER;
    }
  }

  if(!title[0]) sprintf(title, "�Ӧ� %.64s", sender);

  fprintf(fout, "�@��: %s\n���D: %s\n�ɶ�: %s\n", sender, title,
          ctime(&tmp_time));

  if(strstr(genbuf, "BEGIN PGP MESSAGE")
     && dashd(pgppath)
     && (fpgp = fopen(fnamepgp, "w"))) {
    fputs(genbuf, fpgp);

    while(fgets(genbuf, sizeof(genbuf), stdin)) {
      if(check_content(genbuf)) {
        fclose(fpgp);
        unlink(fnamepgp);
        goto IS_SPAM;
      }
      else fputs(genbuf, fpgp);
    }
    fclose(fpgp);
    fclose(fout);

    sprintf(genbuf, "PGPPATH=%s;PGPPASSFD=0;export PGPPATH PGPPASSFD;\
echo `cat home/%s/pgp.phrase` | /usr/local/bin/pgp +batchmode -o- %s >> %s",
            pgppath, userid, fnamepgp, fname);
    system(genbuf);
    unlink(fnamepgp);
    pgp = 1;
    mymail.filemode |= FILE_MARKED;
  }
  else {
    str_decode_M3(genbuf, 0);
    fputs(genbuf, fout);

    while(fgets(genbuf, sizeof(genbuf), stdin)) {
      str_decode_M3(genbuf, 0);

      if(check_content(genbuf)) goto IS_SPAM;
      else                      fputs(genbuf, fout);
    }
    fclose(fout);
  }

  sprintf(genbuf, "%s => %s%s", sender, userid, pgp ? " [PGP]" : "");
  mailog(genbuf);

  /* append the record to the MAIL control file */
  strncpy(mymail.title, title, 72);

  if(strtok(sender, " .@\t\n\r")) strcat(sender, ".");
  sender[IDLEN + 1] = '\0';
  strcpy(mymail.owner, sender);

  sprintf(genbuf, "home/%s/.DIR", userid);
  return append_record(genbuf, (char *)&mymail, sizeof(mymail));
}

int main(int argc, char *argv[]) {
  char receiver[256];

  /* argv[1] is userid in bbs   */
  if(argc < 2) {
    printf("Usage:\t%s <bbs_uid>\n", argv[0]);
    exit(-1);
  }

  strncpy(receiver, argv[1], 255);
  receiver[255] = 0;

  setgid(BBSGID);
  setuid(BBSUID);
  chdir(BBSHOME);

  /* DeltaStar BBS -- benyx */
  resolve_mailspam();

  if(mail2bbs(receiver)) {
    /* eat mail queue */
    while(fgets(receiver, sizeof(receiver), stdin)) ;
  }
  exit(0);

  return 0;
}
