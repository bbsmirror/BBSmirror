#include	<stdio.h>
#include	<ctype.h>
#include	<sys/stat.h>
#include	<sys/file.h>
#include	<fcntl.h>
#include	<time.h>
#include	"define.h"
#include	"struct.h"

#define	BRDPATH		"boards/%s"
#define	BRDDIR		"boards/%s/%s"
#define	BBSID		"pivot"
#define	BBSGID		99
#define	BBSUID		9999
#define	JUNK		"junk"

userec		cuser;
bhd		brdhd;

void	eat_queue(fin)
FILE	*fin;
{
	char	genbuf[STRLEN];

	while(fgets(genbuf, sizeof(genbuf), fin) != NULL);
}

int     isprint2(ch)
char    ch;
{
        return(ch & 0x80 ? 1 : isprint(ch));
}

char	*strtolow(buf1)
char	*buf1;
{
        int 	i;
        static	char	buf2[STRLEN];

        bzero(buf2, STRLEN);
        for(i = 0; i<strlen(buf1); i++)
                buf2[i] = (isalpha(buf1[i])?buf1[i]|0x20:buf1[i]);

        return buf2;
}

int	uidcmp(uid,up)
char	*uid;
userec	*up;
{
	if(!strncmpi(uid, up->userid, sizeof(up->userid)))
	{
        	strncpy(uid, up->userid, sizeof(up->userid));
		return 1;
	}
	else
	{
        	return 0;
	}
}

int	dosearchuser(userid)
char	*userid;
{
	return search_record(PASSFILE, &cuser, sizeof(cuser),
        	uidcmp, userid);
}

int	cmpbnames(n, brec)
int	n;
bhd	*brec;
{
        return !strncmpi((char *)n, brec->filename, sizeof(brec->filename));
}

int	strncmpi(s1,s2,n)
char	*s1,
	*s2;
int	n;
{
	for(; n; s1++, s2++, n--)
	{
		int	ret;
 
 		if(*s1=='\0' && *s2 == '\0')
			break;
		if((ret = (isalpha(*s1)?*s1|0x20:*s1) -
			(isalpha(*s2)?*s2|0x20:*s2)) != 0)
		return ret;
	}
	return 0;
}

char	*Ctime(clock)
time_t	*clock;
{
        char	*foo,
		*ptr = ctime(clock);

        if((int)(foo = (char *)rindex(ptr, '\n')))
                *foo = '\0';

        return (ptr);
}

int	save_post(fin, board)
FILE	*fin;
char	*board;
{
	fhd	newmessage;
	struct	tm	*ptime;
	time_t	dtime;
	char	fname[512],
		file[256],
		genbuf[256],
		title[256],
		sender[80],
		passwd[80],
		*ip;
	struct	stat	st;
	int	fp,
		i,
		check = NA,
		fault = NA,
		lsave = NA;
	FILE	*fout;

	bzero(&newmessage, sizeof(newmessage));
	strcpy(title, "<<No Title POST>>");

	if(search_record(BOARDS, (char *)&brdhd, sizeof(bhd), cmpbnames,
		(int)board) == 0)
	{
		strcpy(board, JUNK);
		if(search_record(BOARDS, (char *)&brdhd, sizeof(bhd),
			cmpbnames, (int)board) == 0)
		{
			eat_queue(fin);
			return -1;
		}
	}

	while(fgets(genbuf, 255, fin) != NULL)
	{
		if((char *)strstr(genbuf, "From ") == genbuf)
		{
			strtok(genbuf, " ");
			strcpy(newmessage.sender, (char *)strtok(NULL, " "));
			strcpy(sender, newmessage.sender);
		}
		if((char *)strstr(genbuf, "Subject: ") == genbuf)
		{
			int	len;
			char	*local;

			if((local = (char *)strstr(genbuf, "(L)")) != NULL)
				newmessage.sended = 'L';
			if((len = strlen(genbuf+9)) > 0)
			{
				bzero(title, sizeof(title));
				strncpy(title, genbuf+9, len-1);
				for(i = 0; i < len-1; i++)
                        	{
                        	        if(!isprint2(title[i]))
                        	                title[i] = '^';
                        	}
			}
			strncpy(newmessage.title, title, STRLEN);
			continue;
		}
		if((char *)strstr(genbuf, "\n") == genbuf)
			break;
	}

	sprintf(file, BRDPATH, board);
	if(stat(file,&st) == -1)
	{
		if(mkdir(genbuf,0755) == -1) 
		{
			eat_queue(fin);
			return -1;
		}
	}
	else
	{	
		if(!(st.st_mode & S_IFDIR))
		{
			eat_queue(fin);
			return -1;
		}
	}

	while(fgets(genbuf, 255, fin) != NULL)
	{
		if((char *)strstr(genbuf, "\n") == genbuf)
			continue;
		if((char *)strstr(genbuf, "#") == genbuf)
		{
			char	*token,
				*end,
				idbuf[STRLEN],
				tmpbuf[STRLEN];
			int	length;

			strcpy(tmpbuf, genbuf);
			token = (char *)strtok(tmpbuf, " :#\r\n\t");
			end = (char *)strtok(NULL, " :#\r\n\t");

			length = end - token -1;

			strncpy(idbuf, token, length);
			strcpy(passwd, end);

			dosearchuser(idbuf);

			if(!HAS_PERM(PERM_POST) ||
				!checkpasswd(cuser.passwd, passwd) ||
				!HAS_PERM(brdhd.postlevel))
			{
				fault = YEA;
				break;
			}
			check = YEA;
			strncpy(newmessage.sender, idbuf, STRLEN);
			sprintf(sender, "%s@%s", idbuf, BBSID);
			bzero(genbuf, sizeof(genbuf));
		}
		break;
	}

	if(fault)
		strcpy(board, JUNK);

	time(&dtime);
	ptime=localtime(&dtime);

	sprintf(fname, "M.%d.A", dtime);
	sprintf(file, BRDDIR, board, fname);

	ip = (char *)rindex(fname,'A');
	while((fp = open(file, O_CREAT|O_EXCL|O_WRONLY,0644)) == -1)
	{
		if(*ip == 'Z')
		{
			ip++;
			*ip = 'A';
			*(ip + 1) = '\0';
		}
		else
			(*ip)++;
		sprintf(file, BRDDIR, board, fname);
	}
	close(fp);
	strcpy(newmessage.filename, fname);

	sprintf(file, BRDDIR, board, fname);
        printf("Ok, the file is %s\n", file );

        if((fout = fopen(file, "w")) == NULL)
	{
        	printf("Cannot open %s \n", genbuf );
		eat_queue(fin);
        	return -1;
        }

	if(!check)
	{
		fprintf(fout, "�o�H�H: %s (Post Gateway), �H��: %s\n", sender, board);
		fprintf(fout, "��  �D: %s\n", title);
		fprintf(fout, "�o�H��: �����j�� BBS ���H Server (%s)\n\n", Ctime(&dtime));
		newmessage.sended = 'L';
	}
	else
	{
		fprintf(fout, "�o�H�H: %s (%s), �H��: %s\n", sender,
			(HAS_SET(SET_REALPOST))? cuser.realname :
			cuser.username, board);
		fprintf(fout, "��  �D: %s\n", title);
		fprintf(fout, "�o�H��: %s (%s)\n\n", BOARDNAME, Ctime(&dtime));
	}

	fputs("\n", fout);

	do
	{
               	fputs(genbuf, fout);
	}
	while(fgets(genbuf, 255, fin) != NULL);

	fclose(fout);

	sprintf(genbuf, BRDDIR, board, FHDIR);
	if(append_record(genbuf, &newmessage, sizeof(newmessage)) == -1)
		return 1;
        else
		return 0;
}

main(argc, argv)
int	argc;
char	*argv[];
{
	int	find;
	char	board[256],
		genbuf[256];
	bhd	fh;

	if(argc != 2)
	{
        	char *p = (char *)rindex(argv[0], '/');

		printf("Usage: %s receiver_in_bbs\n", p ? p+1 : argv[0]);
		return 1;
	}

	if(chroot(BBSHOME) == 0)
	{
        	chdir("/");
#ifdef DEBUG
        	printf("Chroot ok!\n");
#endif
	}
	else
	{
	/* assume it is in chrooted in bbs */
        /* if it is not the case, append_main() will handle it */
		chdir("/");
		printf("Already chroot\n");
	}

	setreuid(BBSUID, BBSUID);
	setregid(BBSGID, BBSGID);

	strcpy(board, argv[1]);
	if(find = search_record(BOARDS, (char *)&fh, sizeof(bhd),
		cmpbnames, (int)board))
		strcpy(board, fh.filename);
	else
		strcpy(board, JUNK);

	return save_post(stdin, board);
}
