�o�H�H: skhuang.bbs@csie.nctu (Shih-Kun Huang), �H��: bbslist
��  �D: scripts for TW.BBS �峹�����έp
�o�H��: ��j��u���s�s�D��(by nbbstin) (Fri Mar  3 03:38:52 1995)
��H��: pivot!news.nchu!ccnews.nchu!news.cc.nctu!news.csie.nctu!skhuang

����:
1. �°Ѧҥ�, �j�a�������Ӱ���.
2. �έp��Ʀb ftp://ftp.csie.nctu.edu.tw:/pub/news-archive/tw/bbs
3. ���� archive2stat �N�I�s stat2dbms, dbms2user, dbms2host. 
5. ��p�{���ܶä]�S������, ���� path �����ۦ�ק�. 

----------------------------------------------------------------
#! /bin/sh
# This is a shell archive.  Remove anything before this line, then unpack
# it by saving it into a file and typing "sh file".  To overwrite existing
# files, type "sh file -c".  You can also feed this as standard input via
# unshar, or by typing "sh <file", e.g..  If this archive is complete, you
# will see the following message at the end:
#		"End of shell archive."
# Contents:  archive2stat dbms2user dbms2host stat2dbms
# Wrapped by skhuang@news on Fri Mar  3 03:30:03 1995
PATH=/bin:/usr/bin:/usr/ucb ; export PATH
if test -f 'archive2stat' -a "${1}" != "-c" ; then 
  echo shar: Will not clobber existing file \"'archive2stat'\"
else
echo shar: Extracting \"'archive2stat'\" \(3549 characters\)
sed "s/^X//" >'archive2stat' <<'END_OF_FILE'
X#!/usr/local/bin/perl
X($month,$newfile) = @ARGV;
X@Month = (
X'Jan','Feb','Mar','Apr','May','Jun',
X'Jul','Aug','Sep','Oct','Nov','Dec'
X);
X
Xif ( !$month ) {
X  @Time=localtime(time() - 86400 * 28);
X  $month = sprintf("%02d",$Time[4] + 1);
X  $MONTH = $Month[$Time[4]];
X  $year = "19$Time[5]";
X  print "$month $year\n";
X} else {
X  if ( $month !~ /^\d+$/ ) {
X     print STDERR "Usage: $0 [month newfile]\n"; 
X     exit 1;
X  }
X  $MONTH = $Month[$month - 1];
X  $month = sprintf("%02d",$month);
X}
X$year = "1995" unless $year;
Xprint "$month $year $MONTH $newfile\n";
X$archivedir="/net/home12/archive/$year";
X
X$statdir="/homec/backup/stat/bbs-stat";
X$statbin="/home/inn/adm/stat";
X$statfile="$statdir/$month/stat$$";
X$statorg="$statdir/$month/org$$";
X$stat2dbms = "$statbin/stat2dbms";
X$dbms2user = "$statbin/dbms2user";
X$dbms2host = "$statbin/dbms2host";
X
Xmkdir("$statdir/$month",0755) unless ( -d "$statdir/$month" );
Xdbmopen(%ORG,$statorg,0644) || die "can't write $statorg $!\n";
Xopen(STAT,"> $statfile") || die "can't write $statfile $!\n";
Xselect(STAT);
X$ngdbms="/net/home12/inn/spool/bin/newsgroups.dbm";
X$quotechar=':>=';
Xdbmopen(%NG,$ngdbms,undef);
Xif ( $newfile ) {
X	if ( -f $newfile ) {
X	  &getstat($newfile,$ng);
X	}
X} else {
X  foreach $ng (keys(%NG)) {
X     if ( index($ng,'tw.bbs') == 0) {
X	$ng =~ s/\./\//g;
X	$file = "${archivedir}/$ng/${year}.${month}.gz";
X#	print "$file\n";
X	if ( -f $file ) {
X#	  print $ng,"\n";
X	  &getstat($file,$ng);
X	}
X     }
X  }
X}
Xdbmclose(%NG);
Xdbmclose(%ORG);
Xclose(STAT);
Xchdir("$statdir/$month");
Xif ( ! $newfile ) {
X	system("$stat2dbms $statfile");
X	system("ln -s ${statorg}.dir dbms/org.dir"); 
X	system("ln -s ${statorg}.pag dbms/org.pag"); 
X	system("$dbms2user");
X	system("$dbms2host");
X	system("/usr/ucb/Mail -s bbs-stat-complete skhuang < /dev/null");
X}
X
Xsub getstat {
X   local($ff,$ng)=@_;
X#   print "ff $ff\n";
X   if ($newfile) {
X     open(F,"$ff");
X   } else {
X     open(F,"/usr/local/bin/zcat $ff |");
X   }
X   undef %Header;
X   ($art,$quote,$sigc,$body,$sig)=(0,0,0,0,0);
X   ($artl,$quotel,$sigl,$bodyl,$sig)=(0,0,0,0,0);
Xnextart:   while (1) {
X#	print $_;
X#	if (/^From /) {
X        {
X#	   print $_;
X#	   last;
X           while (<F>) {
X		$artl++;
X		$art += length($_);
X		if ( /^From / ){
X		   if ($Header{'Subject'}) {&printstat($ng);}
X		   undef %Header;
X		   ($art,$quote,$sigc,$body,$sig)=(0,0,0,0,0);
X		   ($artl,$quotel,$sigl,$bodyl,$sig)=(0,0,0,0,0);
X		   next nextart;
X		}
X		last if ( $_ eq "\n" );
X		if (/^(\S+): (.*)$/) {
X			 $Header{$1} = $2;
X		}
X
X	   }
X	   while (<F>) {
X		if ( /^From / ){
X		   if ($Header{'Subject'}) {&printstat($ng);}
X		   undef %Header;
X		   ($art,$quote,$sigc,$body,$sig)=(0,0,0,0,0);
X		   ($artl,$quotel,$sigl,$bodyl,$sig)=(0,0,0,0,0);
X		   next nextart;
X		}
X		$artl++;
X		$art += length($_);
X		$body += length($_);
X		$bodyl ++;
X		if ($_ eq "--\n") {
X		  $sig=1;
X		  next;
X		}
X		if ($sig == 1) {
X		  $sigc += length($_);
X		  $sigl ++;
X		} elsif ( index($quotechar,substr($_,0,1))>=0) {
X		  $quote += length($_);
X		  $quotel ++;
X		} 
X	   }
X	   close(F);
X	   return 0;
X	}
X   }
X   close(F);
X}
X
Xsub printstat {
X  local($ng)=@_; 
X  local($ff,$from,$uid,$host);
X# print "$ng $Header{'Date'}\n";
X  return if ( $Header{'Date'} !~ /$MONTH/ );
X  if ( $newfile ) {
X     $ng = $Header{'Newsgroups'};
X  }
X  $ff = substr($ng,length("tw.bbs."));  
X  $ff =~ s/\//\./g;
X  printf("%s:%s:%s:./%s/100: From: %s\n",${body},$body - $quote,$body - $quote - $sigc,$ff,$Header{'From'});
X  $from=$Header{'From'};
X  ($uid,$host)= $from=~ /(\S+)@(\S+) \(.*\)/;
X  $ORG{$host} = $Header{'Organization'};
X}
END_OF_FILE
if test 3549 -ne `wc -c <'archive2stat'`; then
    echo shar: \"'archive2stat'\" unpacked with wrong size!
fi
chmod +x 'archive2stat'
# end of 'archive2stat'
fi
if test -f 'dbms2user' -a "${1}" != "-c" ; then 
  echo shar: Will not clobber existing file \"'dbms2user'\"
else
echo shar: Extracting \"'dbms2user'\" \(3609 characters\)
sed "s/^X//" >'dbms2user' <<'END_OF_FILE'
X#!/usr/local/bin/perl 
X$Userpost="userpost";
X$Usertotal="usertotal";
X$Usernois="usernois";
X
X@Time=localtime();
X$month = sprintf("%02d",$Time[4]);
X$statdir="/homec/backup/stat/bbs-stat";
Xchdir("$statdir/$month");
Xprint "reading dbm files\n";
X&opendbms;
X&statuser($Userpost,'sortbypost',"Posts",'User Post �峹�Ʋέp');
X&statuser($Usertotal,'sortbytotal',"Chars",'User Post Bytes �Ʋέp');
X&statuser($Usernois,'sortbynois',"Chars(no quote,signature)",'User Post ���tñ�W�ި� Bytes �Ʋέp');
X&closedbms;
X
Xsub opendbms {
X	dbmopen(%USER,"dbms/user",undef);
X	dbmopen(%Alluser,"dbms/alluser",undef);
X	dbmopen(%USERnick,"dbms/nick",undef);
X}
X
Xsub closedbms {
X	dbmclose(%USER);
X	dbmclose(%USERnick);
X	dbmclose(%Alluser);
X}
X
Xsub sortbypost {
X	$USER{'post',$a} <=> $USER{'post',$b};
X}
Xsub sortbytotal {
X	$USER{'total',$a} <=> $USER{'total',$b};
X}
Xsub sortbynois {
X	$USER{'sig',$a} <=> $USER{'sig',$b};
X}
X
X# stat by user sorted by post
X
Xsub statuser {
X	local($bbsuser,$sortby,$message,$msg)=@_;
X	local(*BBSUSER);
Xopen(BBSUSER,"> $bbsuser") || die "can't open $bbspost $!\n";
Xselect(BBSUSER);
X$| = 1;
X@gmtime=gmtime(time() - 30 * 24 * 60 * 60);
X$lastmonth= $gmtime[4] + 1 ;
X@gmtime=gmtime(time()+ 62 * 24 * 60 * 60);
X$month= (Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec)[$gmtime[4]];
X$expires= sprintf("%s %s 19%s %02d:%02d:%02d GMT",$gmtime[3],$month,$gmtime[5],$gmtime[2],$gmtime[1],$gmtime[0]);
X$i=1;
Xprint <<"EOF";
XNewsgroups: tw.bbs.lists
XSubject: 84�~${lastmonth}�� TOP 100 TW.BBS $msg
XFrom: csie.bbs.sysop@usenet.csie.nctu.edu.tw
XReply-To: csie.bbs.sysop@usenet.csie.nctu.edu.tw
XApproved: bbs-lists@csie.nctu.edu.tw
XFollowup-To: tw.bbs.config
XExpires: $expires
X
X===========83�~${lastmonth}�� TOP 100 TW.BBS $msg ====================
XR:   �����ި�ñ�W��v (�ި��[ñ�W / �`��, (TO - NQS) / TO) ---------------+
XAVG: �����C�ʫH�� byte �� (�����ި��Mñ�W, NQS / PS) ----------------+    |
XNQS: �����ި��Mñ�W���` byte �� ------------------------------+      |    |
XTO:  �Ҧ��峹�` byte �� (���t���Y)---------------------+      |      |    |
XPS:  ����� post �峹�`�� ----------------------+      |      |      |    |
X                                                |      |      |      |    |
X                                                V      V      V      V    V
XRank Username                Realname          PS     TO    NQS    AVG    R
X-----------------------------------------------------------------------------
XEOF
X
X$i=1;
X$Totaluser = 0;
X$Totalpost = 0;
X$Totalchar = 0;
X#foreach $user (keys(%Alluser)) {
X#   $Totaluser ++;
X#   $Totalpost += $USER{'post',$user};
X#   $Totalchar += $USER{'total',$user};
X#}
X#$Averagepost = $Totalpost/$Totaluser;
X#$Averagechar = $Totalchar/$Totaluser;
X#print "Average Post: $Averagepost\n";
X#print "Average Char: $Averagechar\n";
X#exit(0);
X
Xundef @All;
Xforeach $user (keys(%Alluser)) {
X   next if ($user eq "@");
X   push (@All,$user) if ($USER{'post',$user} > 15 || $USER{'total',$user} > 20000 ); 
X}
Xforeach $user (reverse sort $sortby (@All)) {
X#foreach $user ( keys(%Alluser)) {
X	$userpost = $USER{'post',$user};
X	$usertotal = $USER{'total', $user};
X	printf("%-3d%-25.25s %-14.14s%6d %6d %6d %6.0f %1.2f\n",$i, 
X	$user,$USERnick{$user},$USER{'post',$user},$USER{'total',$user},
X	$USER{'sig',$user},
X	$userpost==0?0:$USER{'sig',$user}/$USER{'post',$user},
X	$usertotal==0?0:($USER{'total',$user}-$USER{'sig',$user})/$USER{'total',$user});
X	last if ($i >=100);
X	$i++;
X}
Xclose(BBSUSER);
X}
X# stat by user sorted by post
X# stat by user sorted by char
X# stat by user sorted by char, quotation not included
X# stat by user sorted by char, quotation and signauture not included
X
END_OF_FILE
echo shar: 131 control characters may be missing from \"'dbms2user'\"
if test 3609 -ne `wc -c <'dbms2user'`; then
    echo shar: \"'dbms2user'\" unpacked with wrong size!
fi
chmod +x 'dbms2user'
# end of 'dbms2user'
fi
if test -f 'dbms2host' -a "${1}" != "-c" ; then 
  echo shar: Will not clobber existing file \"'dbms2host'\"
else
echo shar: Extracting \"'dbms2host'\" \(7499 characters\)
sed "s/^X//" >'dbms2host' <<'END_OF_FILE'
X#!/usr/local/bin/perl 
X$bbschar="bbschar";
X$bbspost="bbspost";
X
X$maxhost = 5;
X@Time=localtime();
X$month = sprintf("%02d",$Time[4]);
X$statdir="/homec/backup/stat/bbs-stat";
Xchdir("$statdir/$month");
X
X&opendbms;
X&statstationbypost();
X&statstationbychar();
X&closedbms;
X
Xsub opendbms {
X	dbmopen(%GROUP,"dbms/group",undef);
X	dbmopen(%USER,"dbms/user",undef);
X	dbmopen(%HOST,"dbms/host",undef);
X	dbmopen(%Allgroup,"dbms/allgroup",undef);
X	dbmopen(%Alluser,"dbms/alluser",undef);
X	dbmopen(%Allhost,"dbms/allhost",undef);
X	dbmopen(%ORG,"dbms/org",undef);
X}
X
Xsub closedbms {
X	dbmclose(%GROUP);
X	dbmclose(%USER);
X	dbmclose(%HOST);
X	dbmclose(%Allgroup);
X	dbmclose(%Alluser);
X	dbmclose(%Allhost);
X	dbmclose(%ORG);
X}
X
X# stat by station and post
X
Xsub sortbySTtotal {
X	$HOST{'total',$b} <=> $HOST{'total',$a};
X}
X
Xsub sortbySTpost {
X	$HOST{'post',$b} <=> $HOST{'post',$a};
X}
X
Xsub sortbyGROUPtotal {
X	$GROUP{'total',$b} <=> $GROUP{'total',$a};
X}
X
Xsub sortbyGROUPpost {
X	$GROUP{'post',$b} <=> $GROUP{'post',$a};
X}
X
Xsub statstationbypost {
X	open(BBSPOST,"> $bbspost") || die "can't open $bbspost $!\n";
X	select(BBSPOST);
X	$| = 1;
X
X@gmtime=gmtime(time() - 30 * 24 * 60 * 60);
X$lastmonth= $gmtime[4] + 1 ;
X@gmtime=gmtime(time()+ 62 * 24 * 60 * 60);
X$month= (Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec)[$gmtime[4]];
X$expires= sprintf("%s %s 19%s %02d:%02d:%02d GMT",$gmtime[3],$month,$gmtime[5],$gmtime[2],$gmtime[1],$gmtime[0]);
X$gmtime[4]++;
X	print <<"EOF";
XNewsgroups: tw.bbs.lists
XSubject: 84�~${lastmonth}�� TW.BBS Host Post �峹�Ʋέp
XFrom: csie.bbs.sysop@usenet.csie.nctu.edu.tw
XReply-To: csie.bbs.sysop@usenet.csie.nctu.edu.tw
XApproved: bbs-lists@csie.nctu.edu.tw
XFollowup-To: tw.bbs.config
XExpires: $expires
X
X==================83�~${lastmonth}�� TW.BBS Host Post �峹�Ʋέp=============
XEOF
X	foreach $station (sort sortbySTpost keys(%Allhost)) {
X	  $total += $HOST{'post',$station};
X	}
X        $hi = 0;
X	@HOSTCHAR=('A','B','C','D','E','F','G','H','I','J','K','L','M','N',
X                   'O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b',
X                   'c','d','e','f','g','h','i','j');
X	foreach $station (sort sortbySTpost keys(%Allhost)) {
X	        print 
X                 sprintf("%-25.25s ","$HOSTCHAR[$hi] (${station}):"),
X                 sprintf("%-25.25s ","$ORG{$station}"), 
X                 sprintf("%8d",$HOST{'post',$station}),sprintf("(%4.1f%%)",$HOST{'post',$station}*100/$total),"\n";
X		last if ($hi++ > 33);
X                
X	}
X	print "-" x 78,"\n";
X	print "   Total Posts",' ' x (25 - length("Total Posts")),"   ",' ' x (23 - length(" ")), sprintf("%8d",$total),"(100%)\n\n";
X
X	printf "%-13.13s", "tw.bbs.xxx";
X	$hi = 0;
X	foreach $station (sort sortbySTpost keys(%Allhost)) {
X#		next if ($station eq "F" || $station eq "I" || $station eq "T");
X		printf "%5.5s ",$HOSTCHAR[$hi];
X		last if ($hi++ > 6);
X	}
X	print "|Total\n";
X	print "----------------------------------------------------------------------------\n";
X	$i=0;
X	foreach $station (sort sortbySTpost keys(%Allhost)) {
X	  $post += $HOST{'post',$station};
X	}
X	foreach $group (sort sortbyGROUPpost keys(%Allgroup)) {
X	   $j=0;
X	   printf "%-13.13s",substr($group,rindex($group,'.')+1);
X	   $hi =0;
X	   foreach $station (sort sortbySTpost keys(%Allhost)) {
X#		next if ($station eq "F" || $station eq "I");
X		$sb = $station . $group;
X		printf("%5d ",$HOST{'post',$station,$group});
X		last if ($hi++ > 6);
X	   }
X	   printf("|%5d(%3.1f%%)",$GROUP{'post',$group},$GROUP{'post',$group}*100/$post);
X	   printf "\n";
X	   $i++;
X	}
X	print "----------------------------------------------------------------------------\n";
X	printf " " x 13;
X	$hi =0;
X	foreach $station (sort sortbySTpost keys(%Allhost)) {
X#	  next if ($station eq "F" || $station eq "I");
X	  printf("%5d ",$HOST{'post',$station});
X	  last if ($hi++ > 6);
X	}
X	printf("|%6d(%3.1f%%)",$post,100);
X	printf "\n";
X	printf " " x 10;
X	$hi =0;
X	foreach $station (sort sortbySTpost keys(%Allhost)) {
X	  next if ($station eq "F" || $station eq "I");
X	  $ff=sprintf("(%4.1f%%)",$HOST{'post', $station}*100/$post);
X	  printf "%7.7s",$ff;
X	  last if ($hi++ > 6);
X	}
X	printf "\n";
X	printf "�����@�� %.2f ��\n",$post/31; 
X	close(BBSPOST);
X}
X
Xsub statstationbychar {
X	open(BBSCHAR,"> $bbschar") || die "can't open $bbspost $!\n";
X	select(BBSCHAR);
X	$| = 1;
X@gmtime=gmtime(time() - 30 * 24 * 60 * 60);
X$lastmonth= $gmtime[4] + 1 ;
X@gmtime=gmtime(time()+ 62 * 24 * 60 * 60);
X$month= (Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec)[$gmtime[4]];
X$expires= sprintf("%s %s 19%s %02d:%02d:%02d GMT",$gmtime[3],$month,$gmtime[5],$gmtime[2],$gmtime[1],$gmtime[0]);
X$gmtime[4] ++;
X	print <<"EOF";
XNewsgroups: tw.bbs.lists
XSubject: 83�~${lastmonth}�� TW.BBS Host Post Bytes �Ʋέp
XFrom: csie.bbs.sysop@usenet.csie.nctu.edu.tw
XReply-To: csie.bbs.sysop@usenet.csie.nctu.edu.tw
XApproved: bbs-lists@csie.nctu.edu.tw
XFollowup-To: tw.bbs.config
XExpires: $expires
X
X==================83�~${lastmonth}�� TW.BBS Host Post Bytes �Ʋέp==============
XEOF
X	# stat by station and total char
X	foreach $station (sort sortbySTtotal keys(%Allhost)) {
X	  $total += $HOST{'total',$station};
X	}
X        $hi = 0;
X	@HOSTCHAR=('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O',
X                   'P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d',
X                   'e','f','g','h','i');
X	foreach $station (sort sortbySTtotal keys(%Allhost)) {
X#		printf "%5.5s ",$station;
X                print
X                 sprintf("%-25.25s ","$HOSTCHAR[$hi] (${station}):"),
X                 sprintf("%-25.25s ","$ORG{$station}"), 
X                 sprintf("%8d",$HOST{'total',$station}),sprintf("(%4.1f%%)",$HOST{'total',$station}*100/$total),"\n";
X		last if ($hi++ > 33);
X                
X	}
X	print "-" x 78,"\n";
X	print "   Total bytes",' ' x (25 - length("Total bytes")),"   ",' ' x (23 - length(" ")), sprintf("%8d",$total),"(100%)\n\n";
X	print <<"EOF";
X----------------------------------------------------------------------------
XEOF
X	printf "%-11.11s ", "tw.bbs.xxx";
X        $hi = 0;
X	foreach $station (sort sortbySTtotal keys(%Allhost)) {
X#		next if ($station eq "F" || $station eq "I" || $station eq "T");
X		printf "%7.7s ",$HOSTCHAR[$hi];
X		last if ($hi++ > $maxhost-1);
X	}
X	print "| Total\n";
X	print "----------------------------------------------------------------------------\n";
X	$i=0;
X	foreach $group (sort sortbyGROUPtotal keys(%Allgroup)) {
X	   $j=0;
X	   printf "%-12.12s",substr($group,rindex($group,'.')+1);
X	   $hi = 0;
X	   foreach $station (sort sortbySTtotal keys(%Allhost)) {
X		next if ($station eq "F" || $station eq "I" || $station eq "T");
X		printf("%7d ",$HOST{'total',$station,$group}); 
X	        last if ($hi++ > $maxhost-1);
X	   }
X	   printf("|%7d(%4.1f%%)",$GROUP{'total',$group},$GROUP{'total',$group}*100/$total);
X	   printf "\n";
X	   $i++;
X	}
X	print "----------------------------------------------------------------------------\n";
X	printf " " x 12;
X	$hi = 0;
X	foreach $station (sort sortbySTtotal keys(%Allhost)) {
X	  next if ($station eq "F" || $station eq "I" || $station eq "T");
X	  printf("%6d ",$HOST{'total',$station});
X	  last if ($hi++ > $maxhost - 1 );
X	}
X	printf("|%5d(%4.1f%%)",$total,100);
X	printf "\n";
X	printf " " x 11;
X	$hi = 0;
X	foreach $station (sort sortbySTtotal keys(%Allhost)) {
X	  next if ($station eq "F" || $station eq "I" || $station eq "T");
X	  $ff=sprintf("(%4.1f%%)",$HOST{'total',$station}*100/$total);
X	  printf "%7.7s",$ff;
X	  last if ($hi++ > $maxhost -1 );
X	}
X	printf "\n";
X	printf "�����@�� %.2f bytes\n",$total/31; 
X	close(BBSCHAR);
X}
X
END_OF_FILE
echo shar: 56 control characters may be missing from \"'dbms2host'\"
if test 7499 -ne `wc -c <'dbms2host'`; then
    echo shar: \"'dbms2host'\" unpacked with wrong size!
fi
chmod +x 'dbms2host'
# end of 'dbms2host'
fi
if test -f 'stat2dbms' -a "${1}" != "-c" ; then 
  echo shar: Will not clobber existing file \"'stat2dbms'\"
else
echo shar: Extracting \"'stat2dbms'\" \(1952 characters\)
sed "s/^X//" >'stat2dbms' <<'END_OF_FILE'
X#!/usr/local/bin/perl
Xmkdir("dbms",0750) unless -d "dbms";
Xdbmopen(%Postbyuser,"dbms/user",0640);
Xdbmopen(%Postbyhost,"dbms/host",0640);
Xdbmopen(%Postbygroup,"dbms/group",0640);
Xdbmopen(%Alluser,"dbms/alluser",0640);
Xdbmopen(%Allhost,"dbms/allhost",0640);
Xdbmopen(%Allgroup,"dbms/allgroup",0640);
Xdbmopen(%Nick,"dbms/nick",0640);
Xwhile (<ARGV>) {
X	chop;
X	($total,$nq,$ni,$gn,$from)=split(/:/,$_,5);
X	$bname=substr($gn,2,rindex($gn,'/')-2);
X	next if ($bname =~ /test|sysop|sexstory/);
X	($uid,$host,$nick)= $from=~ /From: (\S+)@(\S+) \((.*)\)/; 
X#	if (! $Alluser{"${uid}@${host}"} ) {
X		$Alluser{"${uid}@${host}"} ++;
X#	}
X#	if (! $Allhost{"${host}"} ) {
X		$Allhost{"${host}"} ++;
X#	}
X#	if (! $Allgroup{"${bname}"} ) {
X		$Allgroup{"${bname}"} ++;
X#	}
X	$Postbyuser{'post',"${uid}@${host}"} ++; 
X	$Postbyuser{'post',"${uid}@${host}",$bname} ++; 
X	$Postbyhost{'post',"${host}"}  ++; 
X	$Postbyhost{'post',"${host}",$bname} ++; 
X	$Postbygroup{'post',"${bname}"} ++; 
X	$Postbyuser{'total',"${uid}@${host}"} += $total; 
X	$Postbyuser{'total',"${uid}@${host}",$bname} += $total; 
X	$Postbyhost{'total',"${host}"} += $total; 
X	$Postbyhost{'total',"${host}",$bname} += $total; 
X	$Postbygroup{'total',"${bname}"} += $total; 
X	$Postbyuser{'quote',"${uid}@${host}"} += $nq; 
X	$Postbyuser{'quote',"${uid}@${host}",$bname} += $nq; 
X	$Postbyhost{'quote',"${host}"} += $nq; 
X	$Postbyhost{'quote',"${host}",$bname} += $nq; 
X	$Postbygroup{'quote',"${bname}"} += $nq; 
X	$Postbyuser{'sig',"${uid}@${host}"} += $ni; 
X	$Postbyuser{'sig',"${uid}@${host}",$bname} += $ni; 
X	$Postbyhost{'sig',"${host}"} += $ni; 
X	$Postbyhost{'sig',"${host}",$bname} += $ni; 
X	$Postbygroup{'sig',"${bname}"} += $ni; 
X	if ($nick) {
X	   $Nick{"${uid}@${host}"} = $nick;
X	}
X#	print "f:$from\n";
X#	print "$total $nq $ni $bname u:$uid h:$host n:$nick\n";
X}
Xdbmclose(%Postbyuser);
Xdbmclose(%Postbyhost);
Xdbmclose(%Postbygroup);
Xdbmclose(%Alluser);
Xdbmclose(%Allhost);
Xdbmclose(%Allgroup);
Xdbmclose(%Nick);
END_OF_FILE
if test 1952 -ne `wc -c <'stat2dbms'`; then
    echo shar: \"'stat2dbms'\" unpacked with wrong size!
fi
chmod +x 'stat2dbms'
# end of 'stat2dbms'
fi
echo shar: End of shell archive.
exit 0
