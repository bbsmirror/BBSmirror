/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)bbspost.c   5.08 3/19/95 (C) 1993 University \
of NCHU, Computer Center and Tseng Kuo-Feng";
#endif

char *ProgramUsage = "\
bbspost (list|visit) bbs_home\n\
	post board_path < uid + title + Article...\n\
	mail board_path < uid + title + passwd + realfrom + Article...\n\
	cancel bbs_home board filename\n\
	expire bbs_home board days [max_posts] [min_posts]\n";

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/file.h>

#include "define.h"
#include "struct.h"

#define MAXLEN		1024

#define	POST_RECEIVE	'M'	/* ��H�i�Ӫ� POST	*/
#define	POST_LOCAL	'L'	/* LOCAL SAVE �� POST	*/
#define	POST_DELIVER	'D'	/* �w�g��X���� POST	*/

char	*crypt();
char	*homepath;
int	visitflag;

void	usage()
{
	printf(ProgramUsage);
	exit(0);
}

void	search_article(brdname)
char	*brdname;
{
	fhd	head;
	struct	stat	state;
	char	index[MAXLEN],
		article[MAXLEN];
	int 	fd,
		num,
		offset,
		type;
	char	send;

	offset = (int) &(head.sended) - (int) &head;
	sprintf(index, "%s/boards/%s/.DIR", homepath, brdname);

	if ((fd = open(index, O_RDWR)) < 0)
	{
		return;
	}

	fstat(fd, &state);
	num = (state.st_size / sizeof(head)) - 1;

	while (num >= 0)
	{
		lseek(fd, num * sizeof(head) + offset, 0);

		if (read(fd, &send, 1) > 0 && (send == POST_DELIVER ||
			send == POST_RECEIVE))
		{
			break;
		}
		num -= 4;
	}
	num++;
	if (num < 0)
		num = 0;
	lseek(fd, num * sizeof(head), 0);
	for(send = POST_DELIVER; read(fd, &head, sizeof(head)) > 0; num++)
	{
		type = head.sended;
		if (type != POST_LOCAL && type != POST_DELIVER &&
			type != POST_RECEIVE && visitflag)
		{
			lseek(fd, num * sizeof(head) + offset, 0);
			write(fd, &send, 1);
			lseek(fd, (num + 1) * sizeof(head), 0);
		}
		if (type == '\0')
		{
			printf("%s\t%s\t%s\t%s\n", brdname,
				head.filename, head.sender, head.title);
		}
	}
	close(fd);
}

void	search_boards(visit)
{
	bhd	board;
	char	boardlist[MAXLEN];
	FILE	*fn;

	visitflag = visit;
	sprintf(boardlist, "%s/.BOARDS", homepath);
	if ((fn = fopen(boardlist, "r")) == NULL)
	{
		printf(":Err: unable to open %s\n", boardlist);
		return;
	}
	printf("New article listed:\n");
	while (fread(&board, sizeof(board), 1, fn) > 0)
	{
		search_article(board.filename);
	}
}

int	check_password(record)
userec	*record;
{
	FILE	*fn;
	char	*pw;
	char	passwd[MAXLEN];
	char	realfrom[MAXLEN];
	char	genbuf[MAXLEN];

	gets(passwd);
	pw = crypt(passwd, record->passwd);
	if (strcmp(pw, record->passwd) != 0)
	{
		printf(":Err: user '%s' password incorrect!!\n",
			record->userid);
		exit(0);
	}
	gets(realfrom);
	sprintf(genbuf, "tmp/email_%s", record->userid);
	if ((fn = fopen(genbuf, "w")) != NULL)
	{
		fprintf(fn, "%s\n", realfrom);
		fclose(fn);
	}
	if (!strstr(realfrom, "bbs@"))
	{
		record->termtype[15] = '\0';
		strncpy(record->termtype+16, realfrom, STRLEN-16);
	}
	if (!strstr(homepath, "test"))
	{
		record->numposts++;
	}
}

int	check_userec(record, name)
userec	*record;
char	*name;
{
	int	fh;

	if ((fh = open(".PASSWDS", O_RDWR)) == -1)
	{
		printf(":Err: unable to open .PASSWDS file.\n");
		exit(0);
	}
	while (read(fh, record, sizeof *record) > 0)
	{
		if (strcasecmp(name, record->userid) == 0)
		{
			strcpy(name, record->userid);
			check_password(record);
			lseek(fh, -1 * sizeof *record, SEEK_CUR);
			write(fh, record, sizeof *record);
			close(fh);
			return;
		}
	}
	close(fh);
	printf(":Err: unknown userid %s\n", name);
	exit(0);
}

int	isprint2(ch)
char	ch;
{
	return(ch & 0x80 ? 1 : isprint(ch));
}

int	strip(str)
char	*str;
{
	int	i;

	for (i = 0; i < strlen(str); i++)
		if (!isprint2(str[i]) && str[i]!='\n' && str[i]!='\r')
			str[i] = '_';
}

char *Ctime(clock)
time_t *clock;
{
	char *foo;
	char *ptr = ctime(clock);

	if((int)(foo = (char *)rindex(ptr, '\n')))
                *foo = '\0';

	return (ptr);
}

post_article(usermail)
{
	userec	record;
	fhd	header;
	char	userid[MAXLEN],
		subject[MAXLEN],
		index[MAXLEN],
		name[MAXLEN],
		article[MAXLEN],
		buf[MAXLEN],
		*ptr;
	FILE	*fidx;
	int	fh,
		find = NA;
	time_t	now;
	struct  tm   *ptime;

	bzero((void *)&header, sizeof(header));
	sprintf(index, "%s/.DIR", homepath);
	if ((fidx = fopen(index, "r")) == NULL)
	{
		if ((fidx = fopen(index, "w")) == NULL)
		{
			printf(":Err: Unable to post in %s.\n", homepath);
			return;
		}
	}
	fclose(fidx);

	gets(userid);
	gets(subject);
	strip(subject);
	if (usermail)
	{
		check_userec(&record, userid);
	}

	time(&now);

	while (1)
	{
		sprintf(name, "P.%d.T", now);
		sprintf(article, "%s/%s", homepath, name);
		if ((fh = open(article, O_CREAT|O_EXCL|O_WRONLY, 0644)) != -1)
			break;
		now += 5;
	}

	printf("post to %s\n", article);
	if (usermail)
	{
		ptr = rindex(homepath, '/');
		(ptr == NULL) ? (ptr = homepath) : (ptr++);
		sprintf(buf, "�o�H�H: %s@mail.gate (%s), �H��: %s\n",
			userid, record.username, ptr);
		write(fh, buf, strlen(buf));
		sprintf(buf, "��  �D: %s\n", subject);
		write(fh, buf, strlen(buf));
		sprintf(buf, "�o�H��: �����j�ǤѼϸ�T�� (%s)\n", Ctime(&now));
		write(fh, buf, strlen(buf));
	}

	while (fgets(buf, MAXLEN, stdin) != NULL)
	{
		write(fh, buf, strlen(buf));
	}
	close(fh);

	strcpy(header.filename, name);
	strncpy(header.sender, userid, STRLEN);
	strtok(header.sender, " ");
	strncpy(header.title, subject, STRLEN);

	if (! usermail)
	{
		header.sended = POST_RECEIVE;
	}
	append_record(index, &header, sizeof(header));
}

int	cancel_article(board, file)
char	*board,
	*file;
{
	fhd	header;
	struct	stat 	state;
	char	dirname[MAXLEN];
	char	buf[MAXLEN];
	long	numents,
		size,
		time,
		now;
	int	fd,
		lower,
		ent;

	if (file == NULL || file[0] != 'M' || file[1] != '.' ||
		(time = atoi(file+2)) <= 0)
		return;
	size = sizeof(header);
	sprintf(dirname, "%s/boards/%s/.DIR", homepath, board);
	if ((fd = open(dirname, O_RDWR)) == -1)
		return;
	flock(fd, LOCK_EX);
	fstat(fd, &state);
	ent = ((long)state.st_size) / size;
	lower = 0;
	while (1)
	{
		ent -= 8;
		if (ent <= 0 || lower >= 2)
			break;
		lseek(fd, size * ent, SEEK_SET);
		if (read(fd, &header, size) != size)
		{
			ent = 0;
			break;
		}
		now = atoi(header.filename + 2);
		lower = (now < time) ? lower + 1 : 0;
	}
	if (ent < 0)
		ent = 0;
	while (read(fd, &header, size) == size)
	{
		if (strcmp(file, header.filename) == 0)
		{
			sprintf(buf, "-%s", header.sender);
			strcpy(header.sender, buf);
			lseek(fd, -size, SEEK_CUR);
			safewrite(fd, &header, size);
			break;
		}
		now = atoi(header.filename + 2);
		if (now > time)
			break;
	}
	flock(fd, LOCK_UN);
	close(fd);
}

int	expire_article(brdname, days_str, maxpost, minpost)
char	*brdname,
	*days_str;
{
	fhd	head;
	struct stat 	state;
	char	lockfile[MAXLEN],
		index[MAXLEN],
		tmpfile[MAXLEN],
		delfile[MAXLEN];
	int	days,
		total,
		fd,
		fdr,
		fdw,
		done,
		keep,
		duetime,
		ftime;

	days = atoi(days_str);
	if (days < 1)
	{
		printf(":Err: expire time must more than 1 day.\n");
		return;
	}
	else if (maxpost < 100)
	{
		printf(":Err: maxmum posts number must more than 100.\n");
		return;
	}
	sprintf(lockfile, "%s/boards/%s/.dellock", homepath, brdname);
	sprintf(index, "%s/boards/%s/.DIR", homepath, brdname);
	sprintf(tmpfile, "%s/boards/%s/.tmpfile", homepath, brdname);
	sprintf(delfile, "%s/boards/%s/.deleted", homepath, brdname);

	if ((fd = open(lockfile, O_RDWR | O_CREAT | O_APPEND, 0644)) == -1)
		return;
	flock(fd, LOCK_EX);
	unlink(tmpfile);

	duetime = time(NULL) - days * 24*60*60;
	done = 0;
	if ((fdr = open(index, O_RDONLY, 0)) > 0)
	{
		fstat(fdr, &state);
		total = state.st_size / sizeof(head);
		if ((fdw = open(tmpfile, O_WRONLY|O_CREAT|O_EXCL, 0644)) > 0)
		{
			while (read(fdr, &head, sizeof head) == sizeof head)
			{
				done = 1;
				ftime = atoi(head.filename + 2);
				if (head.sender[0] == '-')
					keep = 0;
				else if (head.accessed[0] & FILE_MARKED ||
					total <= minpost)
					keep = 1;
				else if (ftime < duetime || total > maxpost)
					keep = 0;
				else
					keep = 1;
				if (keep)
				{
					if (safewrite(fdw, &head, sizeof head)
						== -1)
					{
						done = 0;
						break;
					}
				}
				else
				{
					printf("Unlink %s\n", head.filename);
					if (head.sender[0] == '-')
						printf("Unlink %s.cancel\n",
							head.filename);
					total --;
				}
			}
			close(fdw);
		}
		close(fdr);
	}

	if (done)
	{
		unlink(delfile);
		if (rename(index, delfile) != -1)
		{
			rename(tmpfile, index);
		}
		else
			unlink(tmpfile);
		unlink(delfile);
		unlink(lockfile);
	}
	flock(fd, LOCK_UN);
	close(fd);
}

void	main(argc, argv)
char	*argv[];
{
	char	*progmode;
	int	max,
		min;

	if (argc < 3)
		usage();
	progmode = argv[1];
	homepath = argv[2];
	if (strcasecmp(progmode, "list") == 0)
	{
		search_boards(0);
	}
	else if (strcasecmp(progmode, "visit") == 0)
	{
		search_boards(1);
	}
	else if (strcasecmp(progmode, "post") == 0)
	{
		post_article(0);
	}
	else if (strcasecmp(progmode, "mail") == 0)
	{
		post_article(1);
	}
	else if (strcasecmp(progmode, "cancel") == 0)
	{
		if (argc < 5)
			usage();
		cancel_article(argv[3], argv[4]);
	}
	else if (strcasecmp(progmode, "expire") == 0)
	{
		if (argc < 5)
			usage();
		max = atoi(argc > 5 ? argv[5] : "9999");
		min = atoi(argc > 6 ? argv[6] : "10");
		expire_article(argv[3], argv[4], max, min);
	}
}
