/*
 * Filename: bbs.h
 * Wrter   : kftseng@bbs.nchu.edu.tw
 * Date    : 1994.4.13
 * Version : pivot bbs 3.0
 */

#ifndef _BBS_H_
#define _BBS_H_

#ifdef HP_UX
/* kludge for TIOCNOTTY in sys/ioctl.h, must defined before include
   of <sys/ioctl.h>  */
#define notdef
#endif   

#include <setjmp.h>
#include <stdio.h>
#include <sgtty.h>
#include <strings.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/dir.h>
#include <sys/time.h>
#include <errno.h>
#include <time.h>
#include <sys/resource.h>
#include <pwd.h>
#include <varargs.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <utmp.h>
#include <netdb.h>

#ifdef lint
#include <sys/uio.h>
#endif

#ifndef XINU
#include <sys/stat.h>
#endif

#ifdef SYSV
#include <sys/ipc.h>
#include <sys/sem.h>
#endif

#ifdef AIX
#include <sys/select.h>
#include <arpa/nameser.h>
#endif

#include "config.h"             /* User-configurable stuff */
#include "define.h"
#include "struct.h"
#include "extern.h"

#endif /* _BBS_H_ */
