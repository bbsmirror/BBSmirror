/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)util.c   5.08 3/19/95 (C) 1993 University \
of NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include "bbs.h"

int	include_old(newfile, oldfile, ans)
char	*newfile,
	*oldfile,
	ans;
{
	FILE	*new,
		*old;
	char	buff[STRLEN];

	if (!(new = fopen(newfile,"w")))
		return 2; /* no target file */
	if (!(old = fopen(oldfile,"r")))
		return 1; /* no source file */
      
	while (fgets(buff, sizeof(buff)-2, old) != NULL)
	{
		if (ans != 'a' && ans != 'A')
		{
			if ((char *)strstr(buff,"�o�H�H: ") == buff ||
				(char *)strstr(buff,"�H��H: ") == buff)
			{ 
				char	string[STRLEN];
				int	i,
					j,
					flag;

				strcpy(string, buff+8);
				strtok(string, " ");
				fprintf(new, "==> �b [%s] �夤����:\n", string);
				continue;
			}
			if (((char *)strstr(buff, "��  �D: ") == buff) || 
				((char *)strstr(buff,"�o�H��: ")==buff) ||
				((char *)strstr(buff,"��H��: ")==buff) ||
				(buff[0] == '\n'))
				continue;
			if (!strcmp(buff, "--\n"))
				break;
		}
		if (buff[strlen(buff)-1] != '\n')
			fprintf(new, ": %s\n", buff);
		else
			fprintf(new, ": %s", buff);
	}
	fclose(new);
	fclose(old);
	return 0;
}

int	copyto(oldfile, newfile)
char	*newfile,
	*oldfile;
{
	FILE	*new,
		*old;
	char	buff[81];
   
	if(!(new = fopen(newfile,"w")))
		return 2;

	if(!(old = fopen(oldfile,"r")))
		return 1;
      
	while(fgets(buff, sizeof(buff), old) != NULL)
	{
		fprintf(new,"%s",buff);
	}

	fclose(new);
	fclose(old);
   
	return 0;
}

int	p_owned(fileinfo)
fhd	*fileinfo;
{
#ifndef EMAIL_POST
	return (fileinfo->accessed[usernum]& FILE_OWND);
#else
	return (!strcmp(fileinfo->sender, cuser.userid));
#endif
}

void	write_header(fp)
FILE	*fp;
{
	char	uid[20],
		timebuf[40],
		uname[40];
	time_t	ti;

	strncpy(uid, cuser.userid, 20);
	uid[19] = '\0';

	if (in_mail)
#ifdef REALINFO
	{
		if (HAS_SET(SET_REALMAIL))
			strncpy(uname, cuser.realname, 40);
		else
			strncpy(uname, cuser.username, 40);
	}
#else
		strncpy(uname, cuser.username, 40);
#endif
	else
#ifdef REALINFO
	{
		 if (HAS_SET(SET_REALPOST))
			strncpy(uname, cuser.realname, 40);
		else
			strncpy(uname, cuser.username, 40);
	}
#else
	strncpy(uname, cuser.username, 40);
#endif      
	uid[39] = '\0';
	save_title[STRLEN-10] = '\0';

	if (in_mail)
		fprintf(fp, "�H��H: %s@%s (%s)\n", uid, MYNICK, uname);
	else
		fprintf(fp, "�o�H�H: %s@%s (%s) on board '%s'\n", uid, MYNICK,
			uname, currboard);

	fprintf(fp, "��  �D: %s\n", save_title);
	time(&ti);
	fprintf(fp, "�o�H��: %s (%s)\n\n", "�����j�ǤѼϸ�T��", Ctime(&ti));
}

int	update_file(dirname, size, ent, filecheck, fileupdate)
char	*dirname;
int	size,
	ent,
	(*filecheck)();
void	(*fileupdate)();
{
	int	fd;
	char	tmpfile[80];

	strcpy(tmpfile, currfile);	
	if ((fd = open(dirname, O_RDWR)) == -1)
		return -1;
	flock(fd, LOCK_EX);

	if (lseek(fd, size*(ent-1), L_SET) != -1)
	{
		if (read(fd, abuf, size) == size)
		{
			if ((*filecheck)(abuf, tmpfile))
			{
				lseek(fd, -size, L_INCR);
				(*fileupdate)(abuf);
				if (safewrite(fd, abuf, size) != size)
				{
			  		flock(fd, LOCK_UN);
					close(fd);
					return -1;
				}
				flock(fd, LOCK_UN);
				close(fd);

				return 0;
			}
		}
	}

	lseek(fd, 0, L_SET);
	while (read(fd, abuf, size) == size)
	{
		if ((*filecheck)(abuf, tmpfile))
		{
			lseek(fd, -size, L_INCR);
			(*fileupdate)(abuf);
			if (safewrite(fd, abuf, size) != size)
			{
				flock(fd, LOCK_UN);
				close(fd);
				return -1;
			}
			flock(fd, LOCK_UN);
			close(fd);

			return 0;
		}
	}
	flock(fd, LOCK_UN);
	close(fd);

	return -1;
}

int	get_title(oldttl, newttl)
char	*oldttl, 
	*newttl;
{
	char	ans, 
		genbuf[STRLEN];

	do
	{
		if (oldttl && oldttl[0])
		{
			if (strstr(oldttl, "Re: ") != oldttl)
			{
				strcpy(newttl, "Re: ");
				strcat(newttl, oldttl);
			}
			else
				strcpy(newttl, oldttl);
		}

		move(1, 0); 
		clrtoeol();
		getdata(1, 0, "�]�w�D�D�G", newttl, STRLEN, DOECHO, NA);

		if (strlen(newttl) <= 0)
		{
			ans = getans(2, 0, POST_NOTITLE, 't');
			if (ans == 't')
			{
				move(2, 0);
				clrtoeol();
				continue;
			}

			if (ans == 'Y' || ans == 'y')
			{
				if ( oldttl == NULL )
					strncpy(newttl, "[�L�D�D]", 8);
				else
					strncpy(newttl, oldttl, strlen(oldttl));

				return 0;
			}
			else
				move(2, 0);
			clrtoeol();

              		return QUITPOST;
		}
		else
			break;
        }
	while (1);

        return 0;
}

int	init_namelist(namebuf)
char	*namebuf;
{
	char	genbuf[STRLEN];

	if (!HAS_SET(SET_USERLIST))
	{
		prints(NA, "�إ߯��ͦW��, �еy��..... ");
		u_namelist();
		refresh();
		move(1,0);
		clrtoeol();
		clear();
		prints(NA, "<Enter Userid>\n");
		move(2,0);
		namecomplete("To: ", genbuf);
	}
	else
	{
		move(1,0);
      		prints(NA, "<Enter Userid>\n");
		if (i_userid(2, USER_OLD, genbuf) <= 0)
			CLRTOP3;
        }
	strcpy(namebuf, genbuf);
	if (genbuf[0] == '\0')
		return 0;
	return getuser(genbuf);
}

void	backspace(num)
int	num;
{
	int	j;

	for (j=0; j<num; j++)
	{
		ochar(CTRL('H'));
		ochar(' ');
		ochar(CTRL('H'));
	}
}

int	pressreturn(void)
{
	char	buf[2];

	move(t_lines-1, 0);
	clrtoeol();
	prints(YEA, "[1;32;44m%s                      [m",
		"                     [<] Press Any Key to Continue... [>]");
	refresh();
	egetch();
	return 0;
}

int	dumbreturn(void)
{
	char	ch;

	prints(NA, "Press [RETURN] to continue");
	while ((ch = igetch()) != EOF)
	{
		if (ch == '\n' || ch == '\r')
			return;
	}
}

char	getans(x, y, prompt, def)
int	x,
	y,
	def;
char	*prompt;
{
	int	ch;

	ch = reply(x, y, prompt, NA);

	if (ch > 0x100 || ch == ' ' || ch == '\n' || ch == '\r')
   		ch = def;
	prints(NA, "%c\n", ch);
	refresh();
	return tolower(ch);
}


int	bbssetenv(env,val)
char	*env,
	*val;
{
	int	i,
		len;

	if (numbbsenvs == 0)
		bbsenv[0] = NULL;
	len = strlen(env);
	for (i=0;bbsenv[i];i++)
	{
		if (!strncmpi(env,bbsenv[i],len))
			break;
	}
	if (i>=MAXENVS)
		return -1;
	if (bbsenv[i])
		free(bbsenv[i]);
	else
		bbsenv[++numbbsenvs] = NULL;
	bbsenv[i] = malloc(strlen(env)+strlen(val)+2);
	strcpy(bbsenv[i],env);
	strcat(bbsenv[i],"=");
	strcat(bbsenv[i],val);
}

int	islocalbm(void)
{
	bhd	fh;

	if (!search_board(&fh,currboard))
	{
		return 0;
	}

	if ((!stricmp(cuser.userid, fh.manager1) || !stricmp(cuser.userid,
		fh.manager2) || !stricmp(cuser.userid, fh.manager3)) &&
		HAS_PERM(PERM_LOCALBM))
	{
		return 1;
	}
	return 0;
}

int	do_exec(com,wd, mode, comp)
char	*com,
	*wd;
int	mode,
	comp;
{
	char	path[MAXPATHLEN],	pcom[MAXCOMSZ],
		*arglist[MAXARGS],	*tz,	*lparse;
	int	i,	len,	argptr,	
		status,	pid,	w,	pmode,
		smode,	scomp,	spager;
	void	(*isig)(),	(*qsig)();

	strncpy(path, BINDIR, MAXPATHLEN);
	strncpy(pcom, com, MAXCOMSZ);
	len = MYMIN(strlen(com)+1, MAXCOMSZ);
	pmode = LOOKFIRST;
	for (i=0, argptr=0; i<len; i++)
	{
	        if (pcom[i] == '\0')
			break;
		if (pmode == QUOTEMODE)
		{
			if (pcom[i] == '\001')
			{
		                pmode = LOOKFIRST;
        		        pcom[i] = '\0';
		 		continue;
			}
			continue;
		}
		if (pcom[i] == '\001')
		{
			pmode = QUOTEMODE;
			arglist[argptr++] = &pcom[i+1];
			if (argptr+1 == MAXARGS)
				break;
			continue;
		}
		if (pmode == LOOKFIRST)
		{
			if (pcom[i] != ' ')
			{
				arglist[argptr++] = &pcom[i];
				if (argptr+1 == MAXARGS)
					break;
				pmode = LOOKLAST;
			}
			else
				continue;
		}
		if (pcom[i] == ' ')
		{
			pmode = LOOKFIRST;
			pcom[i] = '\0';
		}
	}
	arglist[argptr] = NULL;
	if (argptr == 0)
		return -1;
	if (*arglist[0] == '/')
		strncpy(path, arglist[0],MAXPATHLEN);
	else
		strncat(path, arglist[0],MAXPATHLEN);
	reset_tty();
	alarm(0);

	smode = uinfo.mode;
	scomp = uinfo.comp;
	spager = uinfo.pager;
	uinfo.pager = NA;

	if ((pid = vfork()) == 0)
	{
	        if (wd)
		{
			if (chdir(wd))
			{
				fprintf(stderr,"Unable to chdir to '%s'\n",wd);
				exit(-1);
			}
		}
		bbssetenv("PATH", "/bin:/usr/bin:/usr/local/bin:.:/usr/ucb");
		bbssetenv("EDITOR","/bin/ve");
		bbssetenv("TERM", cuser.termtype);
		bbssetenv("USER", cuser.userid);
		bbssetenv("USERNAME", cuser.username);
		bbssetenv("REPLYTO", cuser.email);
		if ((tz = (char *)getenv("TZ")) != NULL)
        		bbssetenv("TZ", tz);	
		if (numbbsenvs == 0)
			bbsenv[0] = NULL;
		execve(path,arglist,bbsenv);
		move(2, 0);
		prints(NA, "�����ثe������ '%s' �A��\n",path);
		getchar();
		exit(-1);
	}
	uinfo.cpid = pid;
	changemode(mode, comp);

	isig = signal(SIGINT, SIG_IGN);
	qsig = signal(SIGQUIT, SIG_IGN);
	while ((w = wait(&status)) != pid && w != 1);
	signal(SIGINT, isig);
	signal(SIGQUIT, qsig);
	restore_tty();
#ifdef DOTIMEOUT
	alarm(IDLE_TIMEOUT); 
#endif
	uinfo.cpid = 0;
	uinfo.pager = spager;
	changemode(smode, scomp);

	return ((w == -1)? w: status);
}

int	sh_exec(mode, comp, com, wd)
int	mode,
	comp;
char	*com,
	*wd;
{
	char	path[STRLEN],
		fpath[STRLEN];

	strcpy(path, com);
	sprintf(fpath, "%s/%s", BINDIR, com);
	strtok(path, " ");
	strtok(fpath, " ");
	if (access(path, R_OK) && access(fpath, R_OK))
	{
		move(2, 0);
		clrtoeol();
		prints(NA, "�L�k���榹�@�R�O, �гq�� %s �ﵽ", ADMIN);

		return 0;
	}

	reset_tty();
	do_exec(com, wd, mode, comp);
	restore_tty();

	clear();

	return 0;
}

void	Getyn(s)
char	*s;
{
	CreateNameList();
	AddNameList("yes");
	AddNameList("no");
	namecomplete("(Yes or No): ",s);
}
