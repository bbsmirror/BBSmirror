/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful, 
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)delete.c  5.08 3/19/95 (C) 1993 University of \
NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include <string.h>
#include "bbs.h"

int delusernum;

int	d_exit(void)
{
	clear();
	return QUIT;
}

int	boardcheck(fptr)
bhd	*fptr;
{
	return !strcmp(fptr->filename, genbuf);
}

int	d_board(void)
{
	bhd	binfo;
	int	bid, 
		ans;
	FILE	*fp;
	time_t	ti;

	move(3, 0);
	clrtobot();
	move(0, 0);
	prints(YEA, "DELETE BOARD DELETE BOARD DELETE BOARD");
	clrtoeol();
	move(1, 0);
        make_blist();
	namecomplete("Enter Board Name: ", genbuf);
	bid = getbnum(genbuf);

	if (get_record(BOARDS, (char *)&binfo, sizeof(binfo), bid) == -1)
	{
		move(2, 0);
		prints(NA, "Invalid Board Name\n");
		pressreturn();
		clear();

		return 0;
	}

	move(1, 0);
	prints(NA, "Delete board '%s'.", binfo.filename);
	clrtoeol();

	ans = getans(2, 0, "(Yes, or No) [N]: ", 'n');

	if (ans != 'y')
	{
		move(2, 0);
		prints(NA, "Quitting delete board\n");
		pressreturn();
		clear();
		return 0;
	}

	if (!isalpha(binfo.filename[0]))
		return -1;

	sprintf(genbuf, "/bin/rm -fr boards/%s", binfo.filename);
	system(genbuf);
	strcpy(genbuf, binfo.filename);
	delete_file(BOARDS, sizeof(binfo), bid, boardcheck);
	move(2, 0);
        numboards = -1;

	if ((fp = fopen(".changerec", "a")) != NULL)
	{
		time(&ti);
		fprintf( fp, "%s delete \"%s\" board at %s", 
		cuser.userid, binfo.filename, ctime(&ti));
		fflush(fp);
		fclose(fp);
	}
	
	prints(NA, "Board Deleted\n");
	pressreturn();
	clear();

	return 0;
}

int	delete_range(filename, id1, id2)
char	*filename;
int	id1,
	id2;
{
	int	fd,
		fdr,
		fdw,
		count;
	char	gb[STRLEN],
		lock[STRLEN],
		tmp[STRLEN],
		*t,
		del[STRLEN],
		dir[STRLEN];

        strcpy(dir, filename);
        if (t = (char *)rindex(dir, '/'))
		*t = '\0';
	sprintf(lock, "%s/%s", dir, ".dellock");
	sprintf(tmp, "%s/%s", dir, ".tmpfile");
	sprintf(del, "%s/%s", dir, ".deleted");

	if ((fd = open(lock, O_RDWR|O_CREAT|O_APPEND, 0644)) == -1)
		return -1;
	flock(fd, LOCK_EX);

	if ((fdr = open(filename, O_RDONLY, 0)) == -1)
	{
		flock(fd, LOCK_UN);
		close(fd);
		return -1;
	}

	if ((fdw = open(tmp, O_WRONLY|O_CREAT|O_EXCL, 0644)) == -1)
	{
		flock(fd, LOCK_UN);
		close(fd);
		close(fdr);
		return -1;
	}
	count = 1;
	if (uinfo.mode == RMAIL)
	{
		mhd	mail;

		while (read(fdr, &mail, sizeof(mail)) == sizeof(mail))
		{
			if (count < id1 || count > id2 || mail.accessed
				& FILE_MARKED)
			{
				if ((safewrite(fdw, (char *)&mail,
					sizeof(mail)) == -1))
				{
					unlink(tmp);
					close(fdr);
					close(fdw);
					flock(fd, LOCK_UN);
					close(fd);

					return -1;
				}
			}
			else
			{
				char	*t,
					buf[256];

				strcpy(buf, filename);
				if (t = (char *)rindex(buf, '/'))
					*t = '\0';
				sprintf(gb, PATH_MAIL, cuser.userid,
					mail.filename);
				unlink(gb);
			}
			count++;
		}
	}
	else
	{
		fhd	fhdr;

		while (read(fdr, &fhdr, sizeof fhdr) == sizeof(fhdr))
		{
			if (count < id1 || count > id2 || fhdr.accessed[0] &
				FILE_MARKED)
			{
				if ((safewrite(fdw, (char *)&fhdr, sizeof fhdr)
					== -1))
				{
					unlink(tmp);
					close(fdr);
					close(fdw);
					flock(fd, LOCK_UN);
					close(fd);

					return -1;
				}
			}
			else
			{
				char	*t,
					buf[256];

				strcpy(buf, filename);
				if (t = (char *)rindex(buf, '/'))
					*t = '\0';
				sprintf(gb, "%s/%s", buf, fhdr.filename);
				unlink(gb);
			}
			count++;
		}
        }

	close(fdr);
	close(fdw);
	flock(fd, LOCK_UN);
	close(fd);

	if (rename(filename, del) == -1)
		return -1;

	if (rename(tmp, filename) == -1)
		return -1;

	unlink(del);
	unlink(lock);

	return 0;
}

int	duentposts(fptr)
fhd	*fptr;
{
	fhd	update;
	static	int	id;

	if (fptr == NULL)
	{
		id = 0;
		return 0;
	}

	id++;
	if (get_record(strcat(bfile(currboard), FHDIR), (char *)&update, 
		sizeof(update), id))
		return -1;

	update.accessed[delusernum] = 0;

	if (substitute_record(strcat(bfile(currboard), FHDIR), (char *)&update, 
		sizeof(update), id))
		return -1;

	return 0;
}

int	d_user(void)
{
	int	id, 
		ans;
	FILE	*fp;
	time_t	ti;
	usinfo	uin;
	
	clear();
	prints(YEA, "DELETE USER DELETE USER DELETE USER");
        ans = getans(1, 0, "�п�� (1) �H Login ID (2) �H UserNum (3) �^�W�h: [3] ", 
                '3');
        move(1, 0);   
        clrtoeol();  
        switch (ans)
	{
		case '1':
			move(1, 3);
			if (!(id = init_namelist(genbuf)))
				return 0;
			break;
		case '2':
		        getdata(1, 0, "Input Usernum: ", genbuf, STRLEN, DOECHO, 
				YEA);
			id = atoi(genbuf);
        		break;
		default:
			return 0;
        }

	get_record(PASSFILE, (char *)&muser, sizeof(muser), id);
	delusernum = id;
	move(1, 0);
	prints(NA, "Delete User '%s'.", muser.userid);
	clrtoeol();

	ans = getans(2, 0, "(Yes, or No) [N]: ", 'n');
	if (ans != 'y')
	{
		move(2, 0);
		prints(NA, "Aborting delete User\n");
		pressreturn();
		clear();
		return 0;
	}
	sprintf(genbuf, PATH_USER, muser.userid);
	if (!access(genbuf, R_OK))
	{
		sprintf(genbuf, PATH_DUSER, muser.userid);
		if (genbuf[strlen(genbuf)-1] != '/')
			system(genbuf);
	}
/* MARK Error ....... fuck */
	update_utmp();
	sprintf(genbuf, "deleted user %s", muser.userid);
        if ((fp = fopen(".changerec", "a")) != NULL)
        {
                time(&ti);
                fprintf( fp, "%s delete user \"%s\" at %s", 
                cuser.userid, muser.userid, ctime(&ti));
                fflush(fp);
                fclose(fp);
        }
	bzero(&muser, sizeof(muser));
	substitute_passwd(PASSFILE, &muser, YEA, id);

	move(2, 0);
	prints(NA, "User Deleted\n");
	resolve_ucache( 1 );
	pressreturn();
	clear();
	return 0;
}
