/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)adduser.c   5.04 3/19/95 (C) 1993 University \
of NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include <stdio.h>
#include <sys/file.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "define.h"
#include "struct.h"

#define OLDDIR		".DIR"
#define NEWDIR		".FHDIR"
#define	ERR_OLDBRD	-1
#define	ERR_NEWBRD	-2

char	*bufnew = NULL;
char	*newdir = NULL;

resize_cache(oldpath, newpath, oldper, newper)
char	*oldpath,
	*newpath;
int	oldper,
	newper;
{
	int	nfd, ofd, i, size;
	fhd	fhd;

	size = sizeof(fhd) - oldper + newper;
	if (newdir == NULL)
	{
		newdir = (char *)malloc(size);
		bzero(newdir, sizeof(newdir));
	}
	if ((ofd = open(oldpath, O_RDONLY)) == -1)
		return ERR_OLDBRD;
	if ((nfd = open(newpath, O_WRONLY|O_CREAT|O_TRUNC, 0644)) == -1)
	{
		printf("no %s\r\n", newpath);
		close(ofd);
		return ERR_NEWBRD;
	}
	for (i = 0; i < MAXBOARD; i++)
	{
		if (read(ofd, &fhd, sizeof(fhd)) != NULL)
		{
			printf("file: %s\r\n", fhd.filename);
			bcopy(fhd, &newdir, sizeof(fhd));
			write(nfd, &newdir, size);
		}
		else
			break;
	}
	close(ofd);
	close(nfd);
	return 0;
}

resize_brd(OLDBRD, NEWBRD, OLDPER, NEWPER)
char	*OLDBRD,
	*NEWBRD;
int	OLDPER,
	NEWPER;
{
	int	old,
		new,
		oldsize,
		newsize,
		ret,
		i, size;
	bhd	bhd;
	char	oldpath[STRLEN], newpath[STRLEN], buf[20];

	size = sizeof(bhd) - OLDPER + NEWPER;
	if (bufnew == NULL)
	{
		bufnew = (char *)malloc(size);
		bzero(bufnew, sizeof(bufnew));
	}
	if ((old = open(OLDBRD, O_RDONLY)) == -1)
		return ERR_OLDBRD;
	if ((new = open(NEWBRD, O_WRONLY|O_CREAT|O_TRUNC, 0644)) == -1)
	{
		close(old);
		return ERR_NEWBRD;
	}
	for (i = 0; i < MAXBOARD; i++)
	{
		if (lseek(old, sizeof(bhd)*i, L_SET) == -1)
			break;
		if (read(old, &bhd, sizeof(bhd)) != NULL)
		{
			bcopy(bhd, &bufnew, sizeof(bhd));
			strcpy(buf, bhd.filename);
			sprintf(oldpath, "boards/%s/%s", buf, OLDDIR);
			sprintf(newpath, "boards/%s/%s", buf, NEWDIR);
			printf("1. [%d] %s %s %s\r\n", i, bhd.filename, oldpath, newpath);
			write(new, bufnew, size);
			printf("[%d] %s %s %s\r\n", i, bhd.filename, oldpath, newpath);
			ret = resize_cache(oldpath, newpath, OLDPER, NEWPER);
/*			switch(ret)
			{
				case ERR_OLDBRD:
				{
					printf("cannot open old: %s\r\n", oldpath);
					break;
				}
				case ERR_NEWBRD:
				{
					printf("cannot open new: %s\r\n", newpath);
					break;
				}
			}
*/		}
	}
	close(old);
	close(new);
	return 0;
}

main(argc, argv)
int	argc;
char	**argv;
{
	int	oldper, newper, ret;
	char	oldbrd[STRLEN], newbrd[STRLEN];

	if (argc != 5)
	{
		printf("Usage: %s old_brd(.board) new_brd old_persons new_person\r\n",
			argv[0]);
		exit(-1);
	}
	strcpy(oldbrd, argv[1]);
	strcpy(newbrd, argv[2]);
	oldper = atoi(argv[3]);
	newper = atoi(argv[4]);
	ret = resize_brd(oldbrd, newbrd, oldper, newper);
	switch(ret)
	{
		case ERR_OLDBRD:
		{
			printf("cannot open old board file: %s\r\n", oldbrd);
			exit(-1);
		}
		case ERR_NEWBRD:
		{
			printf("cannot open new board file: %s\r\n", newbrd);
			exit(-1);
		}
		default:
			exit(0);
	}
}
