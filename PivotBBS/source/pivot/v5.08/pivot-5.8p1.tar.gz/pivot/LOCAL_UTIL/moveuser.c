/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/*
 * ���{���O�ΨӱN�������äC�K�V�U user ���ӤH��ƭ��s�إ߱M�ݪ� HOME,
 * �ñN���Ƹs�p: mail, signature, override, plan, 4mrc ����Ʃ�^
 * �U User �� HOME DIR.
 *
 * �Ϊk�O: $ moveuser BBSHOME PASSFILE
 * �h $BBSHOME/mail/userid		=> $BBSHOME/userid/mail
 *    $BBSHOME/signatures/userid	=> $BBSHOME/userid/sig
 *    $BBSHOME/overrides/userid		=> $BBSHOME/userid/override
 *    $BBSHOME/fourm_rc/userid		=> $BBSHOME/userid/fourmrc
 *    $BBSHOME/plans/userid		=> $BBSHOME/userid/plan
 */

#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include "define.h"
#include "struct.h"

char home[80], pass[80];
int series = 0;

int rebuild(urec)
userec *urec;
{
	char userid[80], from[80], to[80];
	int i, ch;
	char *modify[] = {	"fourm_rc",	"mail",		"overrides",
				"plans",	"signatures",	NULL	};
	char *rest[] = {	"fourmrc",	"mail",		"override",
				"plan", 	"sig",		NULL	};

	series++;
	strcpy(userid, urec->userid);
	if(userid[0] == '\0' || !strcmp(userid, "new"))
		return;
	printf("%d: %s\n", series, userid);
	sprintf(from, "%s/home/%s", home, userid);
	if(access(from, X_OK)) {
		mkdir(from, 0755);
		printf("---------------------------------------------------------\n");
		printf("    *** Building HOME DIR: %s\n", from);
	}
	for(i=0; modify[i] != NULL; i++) {
		sprintf(from, "%s/%s/%s", home, modify[i], userid);
		sprintf(to, "%s/home/%s/%s", home, userid, rest[i]);
		if(!access(from, R_OK)) {
			printf("---------------------------------------------------------\n");
			printf("    rename: %s\n    ==> to: %s\n", from, to);
			rename(from, to);
		}
	}
	printf("=========================================================\n");
}

void main(argc, argv)
int argc;
char **argv;
{	
	if(argc != 3) {
		printf("Usage: %s $BBSHOME PASSFILE\n", argv[0]);
		exit(0);
	}
	strcpy(home, argv[1]);
	strcpy(pass, argv[2]);
	printf("********************************************************\n");
	if(apply_record(pass, rebuild, sizeof(userec)) == -1) {
		printf("\nCannot open BBS PASSWD FILE: %s\n", pass);
		exit(0);
	}
	printf("********************************************************\n");
}

int report(char *str)
{
	/* Keeping This Function Be Zero */
}
