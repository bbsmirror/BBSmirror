/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful, 
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)editor.c   5.08 3/19/95 (C) 1993 University \
of NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include <sys/types.h>
#include <stdio.h>
#include <setjmp.h>
#include "define.h"
#include "struct.h"

long	ti;
userec	cuser;
usinfo	uinfo;
jmp_buf byebye;
int	dumb_term;

void	bell(int i)
{
	fprintf(stderr, "%c", 0x7);
}

char	getans(x, y, prompt, def)
int	x,
	y,
	def;
char	*prompt;
{
	int	ch;

	ch = reply(x, y, prompt, NA);

	switch(ch)
	{
		case KEY_RIGHT:
		case ' ':
		case '\n':
		case '\r':
	   		ch = def;
			break;

		default:
			break;
	}
	prints(NA, "%c\n", ch);
	refresh();

	return tolower(ch);
}

int	pressreturn(void)
{
	move(23, 0);
	clrtoeol();
	prints(YEA, "[1;32;44m%s                      [m",
		"                     [<] Press Any Key to Continue... [>]");
	refresh();
	igetkey();
	return 0;
}

void	abort_bbs()
{
	fprintf(stderr, "fatal error has occured\n");
	reset_tty();
	exit(-1);
}

int	goodbye()
{
	fprintf(stderr, "edit aborted!!\n");
	reset_tty();
	exit(-1);
}

int	switch_bit(byte, bit)
int	*byte,
	bit;
{
	if ((*byte)& bit )
		(*byte) &= ~bit;
	else
		(*byte) |= bit;
	return (*byte)& bit;
}

void	main(ac, av)
int	ac;
char	*av[];
{
	char	*term,
		*getenv();
	extern	int	dumb_term;    /* this comes in from term_init */
    
	uinfo.mode =0;
	cuser.userset |= SET_ANSIMODE;

	if (ac != 2)
	{
		fprintf(stderr, "Usage: %s <filename>\n", av[0]);
		exit(-1);
	}

	get_tty();               /* get tty port mode settings */
	init_tty();              /* set up mode for NOECHO and RAW */

	if (setjmp(byebye))
	{
		fprintf(stderr, "Goodbye\n");
		reset_tty();
		exit(-1);
	}

	term = getenv("TERM");   /* Get term type from unix environment */

	if (term == NULL)
	{
		fprintf(stderr, "No Terminal environment type!\n");
		reset_tty();
		exit(-1);
	}

	/* Load up strings used to control terminal type 'term'*/
	term_init(term);

	if (dumb_term)
	{
		fprintf(stderr, "Terminal type cannot support editor\n");
		reset_tty();
		exit(-1);
	}
	initdsk();         /* Initialize screen interface */
	vedit_init();      /* Initialize editor */
	vedit(av[1], NA);   /* Start editor on file, do not save header */
	clear();           /* clear screen */
	redodsk();         /* make clear() happen */

	reset_tty();

	exit(0);
}

int	write_header()
{
	/* nothing here */
}
