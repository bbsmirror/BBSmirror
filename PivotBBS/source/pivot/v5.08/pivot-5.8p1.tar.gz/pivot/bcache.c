/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Chen Wei-ting	SLASH@bbs.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#ifndef lint
static  char    sccsid[] = "@(#)bcache.c   5.08 3/19/95 (C) 1993 University \
of NCHU, Computer Center";
#endif
#include "bbs.h"

int	numuents = 0,
	numboards = -1;
bhd	*bcache;
userec	muser;
BCACHE	*brdshm;
UTMPCACHE	*utmpshm;
UCACHE	*uidshm;

void	attach_err(shmkey, name)
int     shmkey;
char    *name; 
{
	sprintf(genbuf, "Error! %s error! key = %x.\n", name, shmkey);
	write(1, genbuf, strlen(genbuf));
	exit(1);
}

void	*attach_shm(defaultkey, shmsize)
int     defaultkey,
	shmsize;
{
	void	*shmptr;
	int	shmkey,
		shmid;

	shmkey = defaultkey;
	shmid = shmget(shmkey, shmsize, 0);
	if (shmid < 0)
	{
		shmid = shmget(shmkey, shmsize, IPC_CREAT | 0644);
		if (shmid < 0)
			attach_err(shmkey, "shmget");
		shmptr = (void *) shmat(shmid, NULL, 0);
		if (shmptr == (void *)-1)
			attach_err(shmkey, "shmat");
		memset(shmptr, 0, shmsize);
	}
	else
	{
		shmptr = (void *) shmat(shmid, NULL, 0);
		if (shmptr == (void *)-1)
			attach_err(shmkey, "shmat");
	}

	return shmptr;
}

int	fillbcache(fptr)
bhd	*fptr;
{
	bhd	*bptr;
 
	if (numboards >= MAXBOARD)
		return 0;
	bptr = &bcache[numboards++];
	memcpy(bptr, fptr, sizeof(bhd));

	return 0 ;
}

void	resolve_boards()
{
	struct	stat	st;
	time_t	now;

	if (brdshm == NULL)
		brdshm = attach_shm(BOARD_SHMKEY, sizeof(*brdshm));

	numboards = brdshm->number;
	bcache = brdshm->bcache;   
	now = time(NULL);

	if (stat(BOARDS, &st) < 0)
		st.st_mtime = now - BCACHE_UPTIME;  

	if (brdshm->uptime < st.st_mtime || brdshm->uptime < now - BCACHE_UPTIME)
	{
		brdshm->uptime = now;
		numboards = 0;
		apply_record(BOARDS, fillbcache, sizeof(bhd));
		brdshm->number = numboards;
	}
}

int	search_board(btmp, boardname)
bhd	*btmp;
char	*boardname; 
{
	int	i;

	resolve_boards();
	for (i = 0; i < numboards; i++)
	{
		if (HAS_PERM(bcache[i].readlevel))
		{
			if (!strncmpi(boardname,bcache[i].filename,
				sizeof(bcache[i].filename)))
			{
				memcpy(btmp,&bcache[i],sizeof(bhd));
				return ++i;
			}
		}
	}

	return 0;
}

int	apply_boards(func, group, yank)
int	(*func)(),
	group,
	yank;
{
        int     i;
        
	resolve_boards();
        for (i = 0; i < numboards; i++)
        {
                if (HAS_PERM(bcache[i].readlevel))
                {
                        if (((group > 0) && (bcache[i].group != group))
                                || ((bcache[i].accessed[usernum] & ZAPPED)
				&& !yank))
                                continue;
                        if ((*func)(&bcache[i]) == QUIT)
                                return QUIT;
                }
        }
        return 0;
}

int	haspostperm(bname)
char	*bname;
{
	int	i;

	if ((i = getbnum(bname)) == 0)
		return 0;
	if (!HAS_PERM(PERM_POST))
		return 0;

	return (HAS_PERM(bcache[i-1].postlevel));
}

int	fillucache(uentp)
userec	*uentp;
{
	if (numuents < MAXUSERS)
	{
        	strncpy(uidshm->id[numuents],uentp->userid,IDLEN+1);
        	uidshm->id[numuents++][IDLEN] = '\0';
    	}

	return 0;
}

/*
	flag == 0  for 	only attach on UIDSHM
	flag == 1  for 	reload the UIDSHM , cause you have changed 
			the PASSFILE	
	I don't want to use the mode of Phoenix 4.0 . Too ugly ....
 */			
 
void	resolve_ucache(flag)
int	flag;
{
	struct	stat	st;
	int	def = 0;
	
	if (uidshm == NULL)
	{
		uidshm = attach_shm(UID_SHMKEY , sizeof(UCACHE));
		++def;
	}
	if (def || flag)
	{
        	numuents = 0;
        	apply_record(PASSFILE,fillucache,sizeof(userec));
	}
}

int	u_namelist(void)
{
	register int i;

	resolve_ucache(0);
	CreateNameList();
	for (i = 0; i < numuents; i++)
	{
		if (uidshm->id[i][0] != '\0' && 
				stricmp("new", uidshm->id[i]))
			AddNameList(uidshm->id[i]);
	}
	return 0;
}

int	searchuser(userid)
char	*userid;
{
	int	i,
		crc,
		tell = 1,
		fsize,
		stsize = sizeof(ucrc),
		readnum,
		fd;
	char	ss[STRLEN];
	ucrc	crcbuf[GETCRC];
	FILE	*crcfile;
	struct	stat	stbuf;

	strcpy(ss, userid);
	crc = GetStrCrc(ss);

        if ((fd = open(CRCIDX, O_RDONLY, 0)) == -1)
		return 0;
	stat(CRCIDX, &stbuf);
	fsize = stbuf.st_size/stsize;

	while (fsize > 0)
	{
		fsize -= GETCRC;
		readnum = (fsize > 0) ? GETCRC : (fsize + GETCRC);

       		if (!read(fd, &crcbuf, (readnum * stsize)))
		{
               		close(fd);
               		return 0;
       		}

		for (i=1; i<= readnum; i++, tell++)
		{
			if (crcbuf[i-1].crcnum == crc)
			{
        			close(fd);
       				return tell;
        		}
		}
	}
	close(fd);
	return 0;
}

int	getuser(userid)
char	*userid;
{
	int	uid = searchuser(userid);

	if (uid == 0)
		return 0;

	get_record(PASSFILE, (char *)&muser, sizeof(muser), uid);

	if (stricmp(userid, muser.userid))
	{
		bzero(&muser, sizeof(muser));
		substitute_passwd(PASSFILE, &muser, YEA, uid);
		return 0;
	}

	return uid;
}

void	resolve_utmp()
{
	if (utmpshm == NULL)
	{
		utmpshm = attach_shm(UTMP_SHMKEY, sizeof(UTMPCACHE));
	}
}

int	getnewutmpent(up)
usinfo	*up;
{
	int	i;

	resolve_utmp();
	for (i = 0;i <= UTMP_SIZE; i++)
	{
		if (!utmpshm->utc[i].active || !utmpshm->utc[i].pid 
			|| kill(utmpshm->utc[i].pid,0))
			break;
	}
	memcpy(&(utmpshm->utc[i]) ,up, sizeof(usinfo));
	return i+1;		
}

void	update_utmp()
{
	update_ulist(&uinfo, utmpent);
}

void	update_ulist(uentp, uent)
usinfo	*uentp;
int     uent;
{
	resolve_utmp();
	if (uent > 0 && uent <= UTMP_SIZE)
		memcpy(&(utmpshm->utc[uent - 1]), uentp, sizeof(usinfo));
}

int	search_ulist(rptr,fptr, farg)
usinfo	*rptr;
int	(*fptr)();
int	farg;
{
	int	i;

	resolve_utmp();
    	for (i = 0; i < UTMP_SIZE; i++)
	{
		memcpy(rptr , &(utmpshm->utc[i]), sizeof(usinfo));
		if ((*fptr)(farg,rptr))
			return	++i;
	}
	return 0;
}

int	apply_ulist(fptr)
int	(*fptr)();
{
	int	i;

	resolve_utmp();
	for (i = 0; i < UTMP_SIZE; i++)
	{
		if ((*fptr)(&(utmpshm->utc[i])) == QUIT)
			return	QUIT;
	}
	return	0;
}
