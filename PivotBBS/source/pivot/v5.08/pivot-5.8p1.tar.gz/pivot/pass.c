/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)pass.c   5.08 3/19/95 (C) 1993 University of \
NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include "bbs.h"

char *genpasswd(pw)
char *pw ;
{
    char saltc[2] ;
    long salt ;
    int i,c ;
    static char pwbuf[14] ;

    if(strlen(pw) == 0)
        return "" ;
    time((time_t *)&salt) ;
    salt = 9 * getpid() ;
#ifndef lint
    saltc[0] = salt & 077 ;
    saltc[1] = (salt>>6) & 077 ;
#endif
    for(i=0;i<2;i++) {
        c = saltc[i] + '.' ;
        if(c > '9')
          c += 7 ;
        if(c > 'Z')
          c += 6 ;
        saltc[i] = c ;
    }
    strcpy(pwbuf, pw) ;
    return (char *)crypt(pwbuf, saltc) ;
}

int checkpasswd(passwd, test)
char *passwd, *test ;
{
    static char pwbuf[14] ;
    char *pw ;

    strncpy(pwbuf,test,14) ;
    pw = (char *)crypt(pwbuf, passwd) ;
    return (!strcmp(pw, passwd)) ;
}
