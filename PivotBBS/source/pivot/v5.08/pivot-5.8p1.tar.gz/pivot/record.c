/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)record.c   5.08 3/19/95 (C) 1993 University \
of NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include "bbs.h"

char abuf[4096];

#ifdef SYSV
#include <sys/ipc.h>
#include <sys/sem.h>

int	semid;

int	get_semaphore()
{
	if ((semid = semget(SEM_KEY, 1, 600)) == -1)
	{
		if ((semid = semget(SEM_KEY, 1, 600 | IPC_CREAT)) == -1)
			return -1;

		semctl(semid, 0, SETVAL, 1);
	}

	return 0;
}

int	flock(fd, op)
int	fd,
	op;
{
	struct	sembuf	sops;

	sops.sem_num = 0;
	sops.sem_flg = SEM_UNDO;

	switch (op)
	{
		case LOCK_EX:
			sops.sem_op = -1;
			break;
		case LOCK_UN:
			sops.sem_op = 1;
			break;
		default:
			return -1;
	}
	semop(semid, &sops, 1);

	return 0;
}
#endif

#ifdef POSTBUG
char	bigbuf[5120];
int	numtowrite,
	bug_possible = 0;

void	saverecords(filename, size, pos)
char	*filename;
int	size,
	pos;
{
	int	fd;

	if (!bug_possible)
		return 0;
	if ((fd = open(filename,O_RDONLY)) == -1)
		return -1;
	numtowrite = (pos > 5)? 5 : 4;
	lseek(fd, (pos-numtowrite-1)*size, L_SET);
	read(fd, bigbuf, numtowrite*size);
}

int	restorerecords(filename, size, pos)
char	*filename;
int	size,
	pos;
{
	int	fd;

	if (!bug_possible)
		return 0;
	if ((fd = open(filename, O_WRONLY)) == -1)
		return -1;
	flock(fd, LOCK_EX);
	lseek(fd, (pos-numtowrite-1)*size, L_SET);
	safewrite(fd, bigbuf, numtowrite*size);
	flock(fd, LOCK_UN);
	bigbuf[0] = '\0';
	close(fd);
}
#endif

int	safewrite(fd, buf, size)
int	fd;
char	*buf;
int	size;
{
	int	cc,
		sz = size,
		origsz = size;
	char	*bp = buf;

#ifdef POSTBUG
        if (size == sizeof(fhd))
	{
                char	foo[80];
                struct	stat	stbuf;
                fhd	*fbuf = (fhd *)buf;

                sprintf(foo, "boards/%s", fbuf->filename);
                if (!isalpha(fbuf->filename[0]) || stat(foo, &stbuf) == -1)
		{
			if (fbuf->filename[0] != 'M' ||
				fbuf->filename[1] != '.')
			{
				return origsz;
			}
		}
	}
#endif
	do
	{
		cc = write(fd, bp, sz);
		if ((cc < 0) && (errno != EINTR))
		{
			return -1;
		}
		if (cc > 0)
		{
			bp += cc;
			sz -= cc;
		}
	}
	while (sz > 0);

	return origsz;
}

int	get_num_records(filename, size)
char	*filename;
int	size;
{
	struct	stat	st;

	if (stat(filename,&st) == -1)
		return 0;

	return (st.st_size/size);
}

int	append_record(filename,record,size)
char	*filename,
	*record;
int	size;
{
	int	fd;
#ifdef POSTBUG
	int numrecs = (int)get_num_records(filename, size);
	bug_possible = 1;
	if (size == sizeof(fhd) && numrecs && (numrecs % 4 == 0))
		saverecords(filename, size, numrecs+1);
#endif

	if ((fd = open(filename,O_WRONLY|O_CREAT,0644)) == -1)
	{
		perror("open");
		return -1;
	}

	flock(fd,LOCK_EX);
	lseek(fd, 0, L_XTND);
	if (safewrite(fd,record,size) == -1);
	flock(fd,LOCK_UN);
	close(fd);
#ifdef POSTBUG
        if (size == sizeof(fhd) && numrecs && (numrecs % 4 == 0))
		restorerecords(filename, size, numrecs+1);
	bug_possible = 0;
#endif
	return 0;
}


int	apply_record(filename,fptr,size)
char	*filename;
int	(*fptr)();
int	size;
{
	char	abuf[BUFSIZE];
	int	fd;

	if (size > BUFSIZE)
	{
		fprintf(stderr,"size to big in apply record\n");
		return -1;
	}

	if ((fd = open(filename,O_RDONLY,0)) == -1)
		return -1;

	while (read(fd, abuf, size) == size)
	{
		if ((*fptr)(abuf) == QUIT)
		{
			close(fd);
			return QUIT;
		}
	}
	close(fd);
	return 0;
}

/*	t_monitor �M��	*/
int	apply_record3(filename,fptr,size,lists,count)
char	*filename;
int	(*fptr)();
int	size;
char	*lists;
int	count;
{
	char	abuf[BUFSIZE];
	int	fd;

	if (size > BUFSIZE)
	{
		fprintf(stderr,"size to big in apply record\n");
		return -1;
	}

	if ((fd = open(filename,O_RDONLY,0)) == -1)
		return -1;

	while (read(fd, abuf, size) == size)
	{
		if ((*fptr)(abuf, lists, count) == QUIT)
		{
			close(fd);
			return QUIT;
		}
	}
	close(fd);
/*	return 0;*/
}

int	search_record(filename,rptr,size,fptr,farg)
char	*filename,
	*rptr;
int	size,
	farg,
	(*fptr)();
{
	int	fd,
		id = 1;

	if ((fd = open(filename,O_RDONLY,0)) == -1)
		return 0;
	while (read(fd,rptr,size) == size)
	{
		if ((*fptr)(farg,rptr))
		{
			close(fd);
			return id;
		}
		id++;
	}
	close(fd);
	return 0;
}

int	get_record(filename, rptr, size, id)
char	*filename,
	*rptr;
int	size,
	id;
{
	int	fd;

	if (*filename == '\0')
		return -1;
	if ((fd = open(filename, O_RDONLY, 0)) == -1)
		return -1;
	if (lseek(fd, size*(id-1), L_SET) == -1)
	{
		close(fd);
		return -1;
	}
	if (read(fd,rptr,size) != size)
	{
		close(fd);
		return -1;
	}
	close(fd);

	return 0;
}

int	get_records(filename, rptr, size, id, number)
char	*filename,
	*rptr;
int	size,
	id,
	number;
{
	int	fd,
		n;

	if (*filename == '\0')
		return -1;

	if ((fd = open(filename, O_RDONLY, 0)) == -1)
		return -1;

	if (lseek(fd, size*(id-1), L_SET) == -1)
	{
		close(fd);
		return 0;
	}

	if ((n = read(fd, rptr, size*number)) == -1)
	{
		close(fd);
		return -1;
	}
	close(fd);
	return (n/size);
}

int	substitute_record(filename, rptr, size, id)
char	*filename,
	*rptr;
int	size,
	id;
{
	int	fd;
#ifdef POSTBUG
	if (size == sizeof(fhd) && (id > 1) && ((id - 1) % 4 == 0))
		saverecords(filename, size, id);
#endif
	if ((fd = open(filename,O_WRONLY|O_CREAT,0644)) == -1)
		return -1;
	flock(fd,LOCK_EX);
	if (lseek(fd, size*(id-1), L_SET) == -1);
	if (safewrite(fd, rptr, size) != size);
	flock(fd,LOCK_UN);
	close(fd);
#ifdef POSTBUG
	if (size == sizeof(fhd) && (id > 1) && ((id - 1) % 4 == 0))
		restorerecords(filename, size, id);
#endif
	return 0;
}

int	delete_record(filename,size,id)
char	*filename;
int	size,
	id;
{
	int	fdr,
		fdw,
		fd,
		count;
	char	gb[BUFSIZE];
	
	if ((fd = open(".dellock",O_RDWR|O_CREAT|O_APPEND, 0644)) == -1)
		return -1;
	flock(fd,LOCK_EX);

	if ((fdr = open(filename,O_RDONLY,0)) == -1)
	{
		flock(fd,LOCK_UN);
		close(fd);

		return -1;
	}
	if ((fdw = open(".tmpfile",O_WRONLY|O_CREAT|O_EXCL,0644)) == -1)
	{
		flock(fd,LOCK_UN);
		close(fd);
		close(fdr);

		return -1;
	}
	count = 1;
	while (read(fdr,gb,size) == size)
	{
		if (id != count++ && (safewrite(fdw,gb,size) == -1))
		{
			unlink(".tmpfile");
			close(fdr);
			close(fdw);
			flock(fd,LOCK_UN);
			close(fd);

			return -1;
		}
	}

	close(fdr);
	close(fdw);

	if (rename(filename,".deleted") == -1)
	{
		flock(fd,LOCK_UN);
		close(fd);

		return -1;
	}
	if (rename(".tmpfile",filename) == -1)
	{
		flock(fd,LOCK_UN);
		close(fd);

		return -1;
	}
	flock(fd,LOCK_UN);
	close(fd);

	return 0;
}

int	delete_file(dirname,size,ent,filecheck)
char	*dirname;
int	size,
	ent,
	(*filecheck)();
{
	int	fd;
	struct	stat	st;
	long	numents;

	if ((fd = open(dirname,O_RDWR)) == -1)
		return -1;

	flock(fd,LOCK_EX);
	fstat(fd,&st);
	numents = ((long)st.st_size)/size;

	if (((long)st.st_size) % size != 0)
		fprintf(stderr,"Irregular File Size, Truncating\n");

	if (lseek(fd,size*(ent-1),L_SET) != -1)
	{
		if (read(fd,abuf,size) == size)
		{
			if ((*filecheck)(abuf))
			{
				int i;

				for(i = ent; i < numents; i++)
				{
					if (lseek(fd,(i)*size,L_SET) == -1)
						break;
					if (read(fd,abuf,size) != size)
						break;
					if (lseek(fd,(i-1)*size,L_SET) == -1)
						break;
					if (safewrite(fd,abuf,size) != size)
						break;
				}
				ftruncate(fd,size*(numents-1));
				flock(fd,LOCK_UN);
				close(fd);

				return 0;
			}
		}
	}

	lseek(fd,0,L_SET);
	ent = 1;

	while (read(fd,abuf,size) == size)
	{
		if ((*filecheck)(abuf))
		{
			int i;
			for(i = ent; i < numents; i++)
			{
				if (lseek(fd,(i+1)*size,L_SET) == -1)
					break;
				if (read(fd,abuf,size) != size)
					break;
				if (lseek(fd,(i)*size,L_SET) == -1)
					break;
				if (safewrite(fd,abuf,size) != size)
					break;
			}
			ftruncate(fd,size*(numents-1));
			flock(fd,LOCK_UN);
			close(fd);

			return 0;
		}
		ent++;
	}
	flock(fd,LOCK_UN);
	close(fd);

	return -1;
}
