/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)xyz.c   5.08 3/19/95 (C) 1993 University of \
NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#define	_XYZ_C_

#include "bbs.h"

permin setstrings[] =
{
        "�ϥΥ�����R�O�Ҧ�",           	/* SET_AUTOHELP		*/
        "�H�H�ɪ��W�u�W",      			/* SET_REALMAIL		*/
        "Post �ɥI�W�u�W",      		/* SET_REALPOST		*/
        "�O�H�� Query �ɧi�D�u�W",      	/* SET_REALQUERD	*/
        "�Ǧ^�峹�ɪ��W�u��m�W",       	/* SET_REALFORWARD	*/
        "���� ansi �������X",         	/* SET_ANSIMODE		*/
        "�N Zap ���O���",           		/* SET_YANKIN		*/
        "�����ʵe�\\��",               		/* SET_ACTIVE		*/
	"(N)ew �ɭp��s�峹�g��",		/* SET_COUNTNEW		*/
	"���sŪ���ɤ���� Zap �O",		/* SET_GRPYANKOUT	*/
	"Chat Room �α��ʦ��ù�",		/* SET_CHATSCROLL	*/
	"���ϥΦ۰ʸɻ����",			/* SET_USERLIST		*/
	"���ϥίd���O�\\��",			/* SET_DISNOTE		*/
	"�ϥ�ñ�W�ɱ���",			/* SET_SIGNATURE	*/
	"�����i�͸ܪ��A",			/* SET_PAGER		*/
	"��Ҧ��H�����͸ܽШD",			/* SET_ALLPAGER		*/
        NULL,
};

permin permstrings[] =
{
        "�򥻾ާ@�v��",		/* PERM_BASIC */
        "�i�H�ϥ� Chat Room",	/* PERM_CHAT */
        "�i�H�ϥ� TALK �\\��",	/* PERM_PAGE */
        "�֦� POST �v��",       /* PERM_POST */ 
        "�w�q�L�����T�{",	/* PERM_TRUEDATA */
        "�U�Q�װϥN�z�H��",	/* PERM_LOCALBM */
	"Chat Room �N�z�ȹ",	/* PERM_CHATMNG */
	"�b�����|�Q�R��",	/* PERM_NOCLEAN */
	"��ذϺ޲z",		/* PERM_ANNOUNBM */
	"�O�d",			/* PERM_SPECIAL3 */
	"�O�d",			/* PERM_SPECIAL4 */
	"�O�d",			/* PERM_SPECIAL5 */
	"�O�d",			/* PERM_SPECIAL6 */
	"�O�d",			/* PERM_SPECIAL7 */
	"�O�d",			/* PERM_SPECIAL8 */
	"�O�d",			/* PERM_SPECIAL9 */
	"�O�d",			/* PERM_SPECIAL10 */
	"�O�d",			/* PERM_SPECIAL11 */
        "�i�H�������N",		/* PERM_CLOAK */
        "�i�H�ݨ��������H",	/* PERM_SEECLOAK */
        "�i�H�W���ɮ�",         /* PERM_UPLOAD */
        "��s�褵��s�D�v��",	/* PERM_WELCOME */
        "�޲z�U�O�N�z�H��",	/* PERM_BOARDS */
        "�b���Ψ����T���޲z�H", /* PERM_ACCOUNTS */
        "�b��ѫǤ��i������",   /* PERM_CHATCLOAK */
        "�O�d",			/* PERM_OVOTE */
	"�Ư����ι�߯���",	/* PERM_SUBSYSOP */
	"�ͯ�������",		/* PERM_BBSSYSOP */
	"�O�d",			/* PERM_SYSOP1 */
	"�O�d",			/* PERM_SYSOP2 */
        "�`����",		/* PERM_SYSOP */
	"�U�ݤη���",		/* PERM_MAXLEVEL */
        NULL,
};

int x_csh(void)
{
#ifdef SYSV
	sh_exec(SHELL, NA, "sh", NULL);
#else
#ifdef USE_TCSH
	sh_exec(SHELL, NA, "tcsh", NULL);
#else
	sh_exec(SHELL, NA, "csh", NULL);
#endif
#endif

	return 0;
}

usint	setperms(pbits, perms)
usint	pbits;
permin	*perms;
{
	int	lastperm,
		i=0;
	char	buf[STRLEN],
		choice[2];
	permin	*p=perms;

	move(4,0);
	prints(NA, XYZ_SWITCH);
	clrtobot();

	while (p->text)
	{
		move(6 + (i % 16), 40 * (i / 16));
		prints(NA, "(%c) %-24s %3s", 'A' + i , p->text,
			((pbits >> i) & 1 ? "ON" : "OFF"));
		i++;
		p++;
	}
	refresh();
	lastperm = i-1;

	for (;;)
	{
		getdata(t_lines-1, 0, XYZ_TOGGLE, choice, 2,
			DOECHO, YEA);
		*choice = toupper(*choice);
		if(*choice == '\n' || *choice == '\0')
			break;
		else if (*choice < 'A' || *choice > 'A' + lastperm)
			bell(1);
		else
		{
			i = *choice - 'A';
			p = perms + i;

			if((pbits >> i) & 1)
				pbits &= (~(1 << i));
			else
				pbits |= (1 << i);
			move(6 + (i % 16), 40 * (i / 16));
			prints(NA, "(%c) %-24s %3s", 'A' + i, p->text,
				((pbits >> i) & 1 ? "ON" : "OFF"));
		}
	}

	clear();
	return (pbits);
}

int	x_media(void)
{
	userec	newinfo;
	permin	*p = setstrings;
	struct	stat	st;
	int	i = 0,
		j =0,
		ans;
	char	buf[STRLEN];
    
	bcopy(&cuser,&newinfo,sizeof(cuser));
	clear();
	prints(YEA, "������ҳ]�w:\n");
	move(2,0);
	prints(NA, "�w�]�Q�װ�: %s\n",cuser.defboard);
	move(4,0);
	prints(NA, "���ҹw�]���p:\n");

	while(p->text)
	{
		move(6 + (i % 16), 40 * (i / 16));
		prints(NA, "(%c) %-24s %3s", 'A' + i , p->text,
			((cuser.userset >> j) & 1 ? "ON" : "OFF"));
		p++;
		i++;
		j++;
	}

	ans = getans(t_lines-1, 0,
		"�п�� (1)�󴫹w�]�Q�װ� (2)���ҳ]�w (3) �^�W�h�\\���: [3] ",
		'3');

	switch(ans)
	{
		case '1':
			clear();
			make_blist();
			move(0,0);
			prints(NA, "��ܰQ�װ� (��<�ť���>�C�X�����Q�װ�)\n");
			prints(NA, "Select Board: ");
			clrtoeol();
			namecomplete((char *)NULL, buf);

			if((*buf == '\0') || (stat(bfile(buf),&st) == -1) ||
				!(st.st_mode & S_IFDIR))
			{
				move(2,0);
				prints(NA, "Invalid Board Name �d�L���Q�װ�\n");
    				prints(NA, "�w�]�Q�װϤ���\n");
				pressreturn();
			}
			else
			{
				strcpy(currboard, buf);
				strcpy(newinfo.defboard, buf);
			}
			break;
		case '2':
			move(1,0);
			clrtobot();
			move(2,0);
			prints(NA, "Set Using Environment �]�w�ϥ�����:\n");
			newinfo.userset = setperms(newinfo.userset,
				setstrings);
			break;
		default:
			break;
	}
	substitute_passwd(PASSFILE, &newinfo, NA, usernum);
	bcopy(&newinfo, &cuser, sizeof(newinfo));
	clear();
	uinfo.pager = !HAS_SET(SET_PAGER);
	uinfo.allpager = !HAS_SET(SET_ALLPAGER);
	changemode(uinfo.mode, uinfo.comp);
	return 0;
}

int	x_cloak(void)
{
	SWITCH_SET(SET_CLOAK);
	uinfo.invisible = HAS_SET(SET_CLOAK);
	changemode(uinfo.mode, uinfo.comp);
	move(2, 0);
	prints(NA, uinfo.invisible ? XYZ_DISAPPEAR : XYZ_CANSEE);
	return 0;
}

int	x_date(void)
{
	time_t	t;

	move(2,0);

	time(&t);

	prints(NA, "Current local date and time: %s", ctime(&t));

	return 0;
}

int	x_info(void)
{
	changemode(XINFO, NA);
	modify_info(&cuser, usernum, NA);
	strcpy(uinfo.username, cuser.username);
	strcpy(uinfo.realname, cuser.realname);
	changemode(XMENU, NA);
	return 0;
}

int	x_offline(void)
{
	char	passbuf[100],
		buf[20];
	usinfo	uin;
	userec	last;
	time_t	ti;
	
	move(2,0);
	clrtobot();

	move(3,0);
	prints(NA, "�R���ۤv���b�� '%s' ", cuser.userid);
	Getyn(buf);

	if(buf[0] == 'Y' || buf[0] == 'y')
	{
		getdata(3, 0, "�п�J��K�X:", passbuf, PASSLEN, NOECHO, YEA);
		if(passbuf[0] == '\0' || !checkpasswd(cuser.passwd, passbuf))
		{
           		prints(NA, "\n�ܩ�p, �z���K�X�����T�C\n");
           		pressreturn();
           		return 0;
		}
		sprintf(passbuf, PATH_USER, cuser.userid);
		if (!access(passbuf, R_OK))
		{
			sprintf(passbuf, PATH_DUSER, cuser.userid);
			if (passbuf[strlen(passbuf)-1] != '/')
		        	system(passbuf);
		}
		time(&ti);
		logit(LOG_OFFLINE, "suicide: %s[R:%s][U:%s][F:%s][E:%s][A:%s]",
			cuser.userid, cuser.realname, cuser.username,
			cuser.lasthost, cuser.email, cuser.address);
#if	defined(ALLOW_MULTI_LOGINS) || defined(PERM_MULTILOG)
		search_ulist( &uin, kickall, usernum);
#endif
		bzero(&last, sizeof(userec));
		substitute_passwd(PASSFILE, &last, YEA, usernum);
		resolve_ucache( 1 );
		goodbye();
	}
	return;
}

int	x_editsig(void)
{
	int	aborted,
		ans;
	char	genbuf[STRLEN];
	
	sprintf(genbuf, PATH_SIG, cuser.userid);
	move(3,0);
	clrtobot();
	ans = getans(3, 0, "���ñ�W�� [E] �s��, [D] �R��: ", 'e');

	switch(ans)
	{
		case 'd':
			unlink(genbuf);
			move(5,0);
			prints(NA, "It's history!\n");
			pressreturn();
			clear();
			return;
		default:
			changemode(EDITSIG, NA);
			aborted = vedit(genbuf, NA);
			clear();
			if(!aborted)
				prints(NA, "Signature updated.");
			pressreturn();
			changemode(XMENU, NA);
	}
}

int	x_edlogout(void)
{
	int	aborted,
		ans;
	char	genbuf[STRLEN],
		basic[STRLEN];
	
	sprintf(genbuf, PATH_LOGOUT, cuser.userid);
	strcpy(basic, LOGOUT);
	if (access(genbuf, R_OK))
		copyto(basic, genbuf);
	move(3, 0);
	clrtobot();
	ans = getans(3, 0, "������������ [E] �s��, [D] �R��: ", 'e');

	switch(ans)
	{
		case 'd':
			unlink(genbuf);
			move(5,0);
			prints(NA, "It's history!\n");
			pressreturn();
			clear();
			return;
		default:
			changemode(EDLOGOUT, NA);
			aborted = vedit(genbuf, NA);
			clear();
			if(!aborted)
				prints(NA, "�����ɮ׵���");
			pressreturn();
			changemode(XMENU, NA);
	}
}

int	x_editplan(void)
{
	int	aborted,
		ans;

	sprintf(genbuf, PATH_PLAN, cuser.userid);
	move(3,0);
	clrtoeol();
	clrtobot();
	ans = getans(3,0,"(E)dit or (D)elete plan? [E]: ",'e');

	if (ans == 'd')
	{
		unlink(genbuf);
		move(5,0);
		prints(NA, "It's history!\n");
		pressreturn();
		clear();
		return;
	}

	changemode(EDITPLAN, NA);
	aborted = vedit(genbuf, NA);
	clear();

	if (!aborted)
	{
	    prints(NA, "Plan updated.");
	}
	pressreturn();

	changemode(XMENU, NA);
}

int	x_level(void)
{
        int	id,
		newlevel;
	FILE	*fp;
	time_t	ti;
	ucrc	crcidx;

	if (!(id = init_namelist(genbuf)))
		return 0;

        move(2,0);
        prints(NA, "���i%s�j�v��\n", genbuf);
        newlevel = setperms(muser.userlevel,permstrings);
        move(2,0);

        if(newlevel == muser.userlevel)
                prints(NA, "���͡i%s�j���v���S�����\n", muser.userid);
        else
	{
		get_record(CRCIDX, (char *)&crcidx, sizeof(ucrc), id);
		crcidx.level = muser.userlevel = newlevel;
                substitute_passwd(PASSFILE, &muser, NA, id);
		substitute_record(CRCIDX, (char *)&crcidx, sizeof(ucrc), id);
		logit(LOG_MODLEVEL, "%s ��� %s �v��", cuser.userid,
			muser.userid);
        }

        clear();
        return 0;
}

int	x_motd(void)
{
	int	aborted,
		ans;

	move(3,0);
	clrtobot();
	ans = getans(3,0,"(E)dit or (D)elete MOTD? [E]: ",'e');
	if(ans == 'd')
	{
		unlink("etc/motd");
		move(5,0);
		prints(NA, "It's history!\n");
		pressreturn();
		clear();
		return;
	}
	changemode(EDITMOTD, NA);

	aborted = vedit("etc/motd", NA);
	clear();
	if(aborted)
		prints(NA, "Message of Today NOT changed.\n");
	else
	{
		prints(NA, "MOTD updated.\n");
	}
	pressreturn();

	changemode(XMENU, NA);

	return 0;
}
