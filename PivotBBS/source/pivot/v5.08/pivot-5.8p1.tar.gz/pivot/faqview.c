/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful, 
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)faqview.c   5.08 3/19/95 (C) 1993 University \
of NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include "bbs.h"

enum {NOBODY, BD , SYSBD , SYSOP};
enum {ADDITEM, ADDGROUP, ADDMAIL};

char    genbuf[MAXLEN],
	copyname[STRLEN],
	copypath[STRLEN],
	copyfile[MAXLEN];

int	fmode = 0,
	level = 0,
	deep = 1,
	copymode;

showhelp(me)
MENU *me;
{
	clear();
	
    	prints(NA,"        �����j�ǤѼϸ�T�� ���G��ϥλ���\n");
    	prints(NA,"---------------------------------------------------------\n");
    	prints(NA,"h          This Help      �ϥλ���\n");
    	prints(NA,"q,��       Quit           ���}��W�@�h�ؿ�\n");
    	prints(NA,"k,��       Last Item      ����e�@�ӿﶵ\n");
    	prints(NA,"j,��       Next Item      �����@�ӿﶵ\n");
    	prints(NA,"PgUp       Last Page      ���ܫe�@�����\n");
    	prints(NA,"PgDn,Spc   Next Page      ���ܫ�@�����\n");
    	prints(NA,"Rtn,��     Submenu/Read   �i�J�U�@�h�ؿ� / Ū���峹\n");
    
	if(level >= BD) 
	{
    		prints(NA,"\n----< �O�N�z�H���S������ >----\n");
		prints(NA,"w          Edit index.html  �ק� http index.html\n");
    		prints(NA,"n          New article      �s�W�@�g�峹 (������ؤ峹��)\n");
    		prints(NA,"g          Add group        �s�W�@�ӥؿ� (�}�P�s���Q�ץD�D)\n");
    		prints(NA,"m          Move item        ���ʥثe�ﶵ������\n");
    		prints(NA,"d          Delete item      �R���ثe�o�g�峹\n");
    		prints(NA,"t          Title edit       ���ثe�ﶵ���W��\n");
    		prints(NA,"e          Edit article     �s���¦����峹���e\n");
    		prints(NA,"i          Import tmpfile   �m��Ȧs�Ϥ��ɮ�\n");
    		prints(NA,"a          Append article   ���[�峹��ثe�o�g�峹\n");
    		prints(NA,"f          Filename         �d���ɮצW��\n");
    		prints(NA,"c/p        Copy/Paste File  �ƻs�ɮ�\n");
	}

	if(level >= SYSBD) 
	{
    		prints(NA,"b <����>   Board Manager  �ܦ��O�N�z, ���ժO�N�z���v�O\n");
#ifdef	ALLOW_SHELL
    		prints(NA,"s <����>   Shell          ���� Shell �{��, �s���ɮץؿ�\n");
#endif
	}

	pressreturn();
}

loadnames(pm)
MENU *pm;
{
	char 	name[STRLEN],
		path[STRLEN],
		owner[STRLEN],
		date[STRLEN],
		buf[MAXLEN],
		*ptr;
	int 	mode;
	FILE	*fn;

	pm->num = 0;
	if((fn = fopen(".Names","r")) == NULL)
		return 0;
	while (fgets(buf, sizeof(buf), fn) != NULL) 
	{
		if ((ptr = strchr(buf , '\n')) != NULL) 
			*ptr = '\0';
		if (strncmp(buf , "Name=", 5) == 0)
			strcpy(name , buf + 5);
		else if (strncmp(buf , "Path=./" , 7) == 0)
		{
			strcpy(path , buf + 7);
		}
		else if (strncmp(buf , "Owner=" , 6) == 0)
		{
			strcpy(owner , buf + 6);				
			additem(pm , name , path , owner);
		}
	}
	fclose(fn);
}

checklevel(me)
MENU *me;
{
	char	*uname,
		buf[STRLEN];
	int	n;

	if (HAS_PERM(PERM_SYSOP))
	{
		level = SYSOP;
		return;
	}
	if (HAS_PERM(PERM_ANNOUNBM)){
		level = BD;
		return;
	}

	if (strstr(me->title, "BD: ") != NULL)
	{
		strcpy(buf, strstr(me->title, "BD: "));
		if(isdeputy(buf+4 , cuser.userid))
		{
			level = (level < BD) ? BD : level;
			return;
		}
	}

	level = NOBODY;

	return;
}

showmenu(pm)
MENU *pm;
{
	char	*name,
		*path,
		*owner,
		*date;
	int	n,
		mode;

	clear();
	move(0, (79-strlen(pm->title))/2);
	prints(NA, "[1m%s[m\n", pm->title);
	switch (level)
	{
		case NOBODY:
			prints(NA, "[1;32m%s[m%s%s\n", "[�\\����]",
				"  [H] ����   [Q|��] ���}   [k|��|j|��]",
				" ���ʴ��   [Enter|��] Ū�����");
			break;
		case BD:
		case SYSBD:
			prints(NA, "[1;32m%s[m%s%s\n", "[�N�z�H]",
				" [H]���� [Q|��]���} [N]�s�W�ɮ� [A]���[",
				"�ɮ� [G]�s�W�ؿ�  [E]�s���ɮ�");
			break;	
		case SYSOP:
			prints(NA, "[1;32m%s[m%s%s\n", "[�`�޲z��]",
				"  [H] ����   [N] �s�W�峹  [A] ���[�峹",
				"   [G] �[�ؿ�   [B] �ܦ��O�D");
			break;
	}
	if(fmode)
		prints(NA, "[1;32;44m %4s [%-10s] %-49s%-9s[m\n",
			"�Ǹ�", "�ɦW", "�D    ��", "[��  ��]");
	else
		prints(NA, "[1;32;44m %4s [%-4s] %-43s%-12s%-9s[m\n",
			"�Ǹ�", "�ݩ�", "�D    ��", "[��  �z]", "[��  ��]");

	if (pm->num == 0)
	        prints(NA,"        No article in this group !!\n");
	else
	{
		for(n = pm->page;n < pm->page + 20  && n < pm->num;n++)
		{
			path  = pm->item[n]->path;
			name  = pm->item[n]->name;
			owner = pm->item[n]->owner;
			date  = pm->item[n]->date;
			mode  = pm->item[n]->mode;

			if (fmode == 1)
			{
				if (mode) 
					prints(NA," %3d. D:%-10.10s %-48.48s [%6.6s]\n", n+1, path, name, date);
				else 
					prints(NA," %3d. F:%-10.10s %-48.48s [%6.6s]\n", n+1, path, name, date);
			}	
			else 
			{
				if (mode) 
					prints(NA," %3d. [[1;34m�ؿ�[m] %-54.54s [%6.6s]\n", n+1 , name, date);
				else
				{
				 	if (!strcmp(owner,"SYSOP") || owner[0] == '\0')
						prints(NA," %3d. [[1;32m���[m] %-54.54s [%6.6s]\n", n+1 ,name , date);
					else
						prints(NA," %3d. [[1;32m���[m] %-41.41s %-12.12s [%6.6s]\n",  n+1 , name , owner, date);
				}
			}
		}
	}	
}

searchboard(path, title, fun)
char	*path,
	*title;
int	fun;
{
	FILE	*fn;
	char	board[STRLEN],
		buf[STRLEN],
		*ptr;
	int 	len;

	if(!fun)
	{
		strcpy(board,path);
		len = strlen(board);
		clrtoeol();
	}	
	else
        	len = getdata(t_lines-1, 0, "��J���j�M���Q�װϦW��: ", board,
			STRLEN, DOECHO, YEA);

	path[0] = title[0] = '\0';

    	if(len == 0 || (fn = fopen(SEARCHFILE, "r")) == NULL)
		return 0;

	while(fgets(buf, sizeof(buf), fn) != NULL) 
    	{
		if(strncasecmp(buf, board, len) == 0 && buf[len] == ':') 
		{
	    		while(strchr(": \t", buf[len]) != NULL)
				len++;

	    		if((ptr = strchr(buf, '\n')) != NULL)
				*ptr = '\0';
			sprintf(path, "%s/%s", WORKPATH, &buf[len]);
	    		break;
		}
    	}
	fclose(fn);
	len = strlen(path);
	if(len == 0 || !dashd(path)) 
    	{
		move(t_lines-1, 0);
		clrtoeol();
		move(t_lines-1, 0);
		prints(YEA,"[�j�M����] %s. �Ы����N���~�� ...\n", len ? 
			"�����ؿ�����, �гq�� SYSOP" : "�䤣�� �� ���s�b");
		igetkey();
		return 0;
	}
	strcpy(buf, path);
	if((ptr = strrchr(buf, '/')) != NULL) 
		strcpy(ptr+1, ".Names");
    	if((fn = fopen(buf, "r")) == NULL)
    	{
		strcpy(title, "Title not found !!");
		return len;
    	}
	len = strlen(board);
	while(fgets(buf, sizeof(buf), fn) != NULL) 
    	{
		if((ptr = strchr(buf, '\n')) != NULL)
	    		*ptr = '\0';
		if(strncmp(buf, "Name=", 5) == 0)
		    	strcpy(title, buf+5);
		else if(strncmp(buf, "Path=./", 7) == 0)
		{
	    		if(strncmp(buf+7, board, len) == 0)
				break;
	    		else
				strcpy(title, board);
		}
   	}
	fclose(fn);

	return len;
}

moveitem(pm)
MENU *pm;
{
	ITEM	*tmp;
	char	newnum[STRLEN];
	int	num,
		n;

	sprintf(genbuf, "�п�J�� %d �ﶵ���s����: ", pm->now+1);
	if(getdata(t_lines-1, 0, genbuf, newnum, STRLEN, DOECHO, YEA) == 0)
		return;
    	num = (newnum[0] == '$') ? 9999 : atoi(newnum) - 1;
    	if(num >= pm->num)
    		num = pm->num-1;
    	else if(num < 0)		
    		num = 0;
	tmp = pm->item[pm->now];
    	if(num > pm->now) 
 		for(n = pm->now; n < num; n++)
	    		pm->item[n] = pm->item[n+1];
     	else 
 		for(n = pm->now; n > num; n--)
	    		pm->item[n] = pm->item[n-1];
     	pm->item[num] = tmp;
    	pm->now = num;
    	savenames(pm);
}
                              
deleteitem(pm)
MENU *pm;
{
    	ITEM	*item;
    	char	*title,
		*fname,
		ans;
    	int	n;

    	item = pm->item[pm->now];
    	title = item->name;
    	fname = item->path;
	
    	if(dashf(fname)) 
    	{
		ans = getans(t_lines-1, 0, "�T�w�R���ɮ׶�(Y/N)? [N]", 'n');
		if (ans == 'y'|| ans == 'Y' )
			unlink(fname);
		else
			return;
    	} 
	else if(dashd(fname)) 
    	{
		ans = getans(t_lines-1, 0, "�T�w�R���ؿ��U�Ҧ����(Y/N)? [N]",
			'n');
		if (ans == 'y' || ans == 'Y' )
			unlink(fname);
		else	
			return;
    	}
    	free(item);
    	for(n = pm->now; n < pm->num; n++)
		pm->item[n] = pm->item[n+1];
    	(pm->num)--;
    	savenames(pm);
}

dotitle(pm)
MENU *pm;
{
	char	genbuf[STRLEN];

	getdata(t_lines-1, 0, "��J�s�W��: ", genbuf, STRLEN, DOECHO, YEA);
	if (genbuf[0] != '\0')
	{
		strcpy(pm->item[pm->now]->name, genbuf);
		savenames(pm);
    	}
}

execute(command, argument)
char	*command,
	*argument;
{
	
	sprintf(genbuf, "%s %s", command, argument);
	system(genbuf);
}

dofilename(pm)
MENU *pm;
{
	ITEM	*item;
	char	fname[STRLEN];

	item = pm->item[pm->now];
    	if(getdata(t_lines-1, 0, "��J�s�ɦW : ", fname, STRLEN, DOECHO, YEA)
		== 0)
		return;
    	if(!valid(fname)) 
    	{
		prints(NA,"[���~] �W�٥u��]�t�^��μƦr ...\n");
		pressreturn();
    	} 
    	if(dashf(fname)) 
    	{
		prints(NA,"Warning: �t�Τ��w�g�� %s �o���ɮצs�b�F !\n", fname);
		pressreturn();
    	} 
    	if(dashd(fname)) 
    	{
		prints(NA,"Warning: �t�Τ��w�g�� %s �o�ӥؿ��s�b�F !\n", fname);
		pressreturn();
    	} 
    	if(rename(item->path, fname) == 0) 
    	{
		strcpy(item->path, fname);
		savenames(pm);
 
   	}
}

valid(str)
char *str;
{
	char	ch;

	while((ch = *str++) != '\0') 
    	{
		if(!((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') ||
	    		(ch >= '0' && ch <= '9') ||
			strchr("@[]-._", ch) != NULL))
			return 0;
    	}
	return 1;
}

copyitem(pm)
MENU *pm;
{
	ITEM	*item;

	item = pm->item[pm->now];
    	copymode = item->mode;
    	strcpy(copyname, item->name);
    	strcpy(copypath, item->path);
    	sprintf(copyfile, "%s/%s", pm->pwd, copypath);

   	message("�ɮ׼��ѧ���. (�`�N! �߶K�峹��~��N�峹 delete!)");
}

appendart(pm)
MENU *pm;
{
   	char	fname[STRLEN],
		buf[STRLEN],
		genbuf[STRLEN];
    	ITEM    *item;

    	item = pm->item[pm->now];
    	if(item->mode == DIRECT)
		return;

    	if(getdata(t_lines-1, 0, "[���[�峹] �п�J�ɮצW��:", fname, STRLEN,
		DOECHO, YEA) == 0)
		return;

    	sprintf(genbuf, "%s/tmp/bd.%s", BBSHOME, fname);

    	if(!dashf(genbuf)) 
    	{
		prints(NA,"���~: �d�L���ɮצs�b, �Х��s�@ TEMP �� %s\n ", fname);
		pressreturn();
		return;
    	}
    	move(23,1);
    	prints(NA,"�N [%s] ���[�b��� [%s] (Y/N)? [N]\n ", fname, item->name); 
    	switch(igetkey())
    	{
		case 'y':
		case 'Y':
			sprintf(buf, "/bin/cat %s >> %s; /bin/rm %s", genbuf,
				item->path, genbuf);
			system(buf);
			break;
		default:
			break;
    	}
    	return;
}

addnewitem(pm, mode)
MENU *pm;
int mode;
{
    	ITEM	*new;
    	char	board[STRLEN],
		*mesg,
    		fname[STRLEN],
		title[STRLEN],
		owner[STRLEN];

    	switch(mode) 
    	{
		case ADDITEM:
	    		mesg = "[�s�W�峹] �п�J�ɮצW��:";	
	    		break;
		case ADDGROUP:
	    		mesg = "[�s�W�ؿ�] �п�J�ؿ��W��:";	
	    		break;
		case ADDMAIL:
	    		mesg = "�п�J�Ȧs�ɦW��: ";
	    		if(getdata(t_lines-1, 0, mesg, board, STRLEN, DOECHO,
				YEA) == 0)
				return;
	    		sprintf(genbuf, "%s/tmp/bd.%s", BBSHOME, board);
	    		if(!dashf(genbuf)) 
	    		{
				prints(NA,"���~: �d�L���ɮצs�b, �Х��s�@ TEMP �� %s\n ",board);
				pressreturn();
				return;
	    		}
	    		mesg = "[��z���] �п�J�ɮצW��: ";	
	    		break;
     	}
    
    	if(getdata(t_lines-1, 0, mesg, fname, STRLEN, DOECHO, YEA) == 0)
		return;
    	if(!valid(fname)) 
    	{
		prints(NA,"[���~] �W�٥u��]�t�^��μƦr ...\n");
		pressreturn();
    	} 
    	else if(dashf(fname)) 
    	{
		prints(NA,"Warning: �t�Τ��w�g�� %s �o���ɮצs�b�F !\n", fname);
		pressreturn();
    	} 
    	else if(dashd(fname)) 
    	{
	        prints(NA,"Warning: �t�Τ��w�g�� %s �o�ӥؿ��s�b�F !\n", fname);
	 	pressreturn();
    	} 
    	else 
    	{
		if(getdata(t_lines-1, 11, "�п�J�ﶵ����:",
				title, sizeof(title),DOECHO,YEA) == 0)
	    		return;
		switch(mode) 
		{
	    		case ADDITEM:
				vedit(fname, NA);
				execute("chmod 0644", fname);
				break;
		    	case ADDGROUP:
				mkdir(fname, 0755);
				execute("chmod 0755", fname);
				break;
			case ADDMAIL:
				sprintf(genbuf, "/bin/mv %s/tmp/bd.%s %s",
					BBSHOME, board, fname);
				system(genbuf);
				execute("chmod 0644", fname);
				break;
		}
		if(level == SYSOP)
			strcpy(owner, "SYSOP");
		else
			strcpy(owner, cuser.userid);
		additem(pm, title, fname, owner);
		savenames(pm);
    	}
}



errmsg(mesg)
char *mesg;
{
    	move(24,1);
    	clrtoeol();
	move(24,1);
    	prints(NA,"%s\n", mesg);
    	pressreturn();
}

tty_exec(command, argument)
char    *command,
        *argument;
{
        clear();
        sprintf(genbuf, "%s %s", command, argument);
        system(genbuf);
}

savenames(pm)
MENU *pm;
{
    	FILE	*fn;
    	int	n;

    	if((fn = fopen(".Names", "w")) == NULL)
		return;

    	for(n = 0; n < pm->num; n++) 
    	{
		fprintf(fn, "#\n");
		fprintf(fn, "Name=%s\n",	pm->item[n]->name);
		fprintf(fn, "Path=./%s\n",	pm->item[n]->path);
		fprintf(fn, "Numb=%d\n",	n + 1	 ); /*  This is for Gopher */
		fprintf(fn, "Owner=%s\n",	pm->item[n]->owner);
    	}
  	fprintf(fn, "#\n\r");
    	fclose(fn);
    	execute("chmod 0644", ".Names");
}


getemailaddr(email, maxlen)
char *email;
int maxlen;
{
    	char	*ptr,
		ch,
		i;
	clear();
	move(1,0);
    	prints(NA,"�Ш̷ӤU�C�榡��J�z���H�c��}, �� ip �̤@�w�n�[[]\n");
    	prints(NA,"ex: SLASH@bbs.nctu.edu.tw or SLASH@[140.120.1.5]\n");
    	prints(NA,"E-mail address: [%s]\n", cuser.email);
    	if (getdata(4,0,"=>",email, maxlen,DOECHO,YEA) == 0)

		strcpy(email, cuser.email);

    	if(!valid(email))
	{
		prints(NA,"�l��H�c��}�榡��J���~ ...\n");
		return 0;
    	}
    	return strlen(email);
}


doarticle(title, filename)
char	*title,
	*filename;
{
    	char	email[STRLEN];
	char	fname[STRLEN];

	clear();
    	more(filename,NA);
    	move(23,1);
	sprintf(fname, "%s/tmp/forward.%s",BBSHOME , cuser.userid);
    	prints(NA,"[1m�п�� M)�H�H, U)uencode �H�H, Z)modem ����, K)ermit ����, Q)���} [Q]:[m\n"); 
    	switch(igetkey()) 
    	{
		case 'M':  
		case 'm':
	    		if(getemailaddr(email, sizeof(email))) 
	    		{
				if (copyto(filename, fname) != 0)
					return -1;
				deliver_email(fname, email, title);
				prints(NA,"�N '%s' �峹�H�� '%s'.\n", filename, email);
	    		}
			pressreturn();
	    		break;
		case 'U':  
		case 'u':
	    		if(getemailaddr(email, sizeof(email))) 
	    		{
				bzero(genbuf, sizeof(genbuf));
				sprintf(genbuf, "/usr/bin/uuencode %s %s > %s", filename, filename, fname);
				system(genbuf);
				prints(NA,"�N '%s' uuencode ��H�� '%s'.\n", filename, email);
				deliver_email(fname, email, title);
          		}
			pressreturn();
	    		break;
		case 'Z':  
		case 'z':
			prints(NA,"Sorry..  Z-Modem �Ȱ��ϥ� ...\n");
/*	    		prints(NA,"�Q�� Z-Modem �ǿ�榡�ǰe '%s' �ɮ� ...\n",filename);
	    		execute("/home/bbs/bin/sz -ve", filename);*/
	    		pressreturn();
	    		break;
		case 'K':
		case 'k':
	    		prints(NA,"�Q�� Kermit �ǿ�榡�ǰe '%s' �ɮ� ...\n",filename);
	    		execute("/home/bbs/bin/kermit -si", filename); 	
	}
}

pastefile(pm)
MENU	*pm;
{
	char	owner[80],
		ans;

    	if(copyname[0] == '\0' || copypath[0] == '\0') 
    	{
		message("[���~] �Х��ϥ� copy �\\���A�� paste");
    	} 
    	else if(dashf(copypath) || dashd(copypath)) 
    	{
		sprintf(genbuf, "[���~] %s �ɮ�/�ؿ��w�g�s�b", copypath);
		message(genbuf);
    	} 
    	else 
    	{
		sprintf(genbuf, "�T�w�n�߶K %s �ɮ׶�(Y/N)? [N] ", copypath);
		ans = getans(t_lines-1, 0, genbuf, 'n');

		if(ans == 'y') 
		{
	    		sprintf(genbuf, "/bin/cp -r %s %s; chmod %d %s",
				copyfile, copypath, (copymode == DIRECT)? 755 :
				644, copypath);
	    		system(genbuf);

			pressreturn();
			if(level == SYSOP)
				strcpy(owner, "SYSOP");
			else
				strcpy(owner, cuser.userid);

	    		additem(pm, copyname, copypath, owner);
	    		savenames(pm);
		}
    	}
}

additem(pm, name, path, owner)
MENU	*pm;
char	*name,
	*path, 
	*owner;
{
    	ITEM	*newitem;
    	struct 	stat 	st;
    	char 	date[STRLEN];

    	if(pm->num < MAXITEMS)
	{
		newitem = (ITEM *) malloc(sizeof(ITEM));
		strcpy(newitem->name, name);
		strcpy(newitem->path, path);
		strcpy(newitem->owner, owner);
		newitem->mode = ISFILE;
		if(stat(path, &st) == 0 && S_ISDIR(st.st_mode))
			newitem->mode = DIRECT;
		strncpy(date , ctime(&st.st_mtime) + 4 , 6);				
		strcpy(newitem->date, date);
		pm->item[(pm->num)++] = newitem;
    	}
}  

message(mesg)
char *mesg;
{
    	move(23,1);
    	clrtoeol();
	move(23,1);
    	prints(NA,"%s ...\n", mesg);
    	return igetkey();
}

isdeputy(str1, name)
char	*str1,
	*name;
{
	char	tmp[STRLEN],
		*p;

	strcpy(tmp, str1);
	p = strtok(tmp, " ,;:|\\.\t)");
	while (1)
	{
		if (!stricmp(p, name))
			return HAS_PERM(PERM_LOCALBM);
		if ((p = strtok(NULL, " ,;:|\\.\t)")) == NULL)
			break;
	}
	return NA;
}


igetstr(buf, maxlen)
char    *buf;
{
        int     ch,
                len = 0;

        maxlen--;

        while (1)
        {
                switch (ch = igetkey())
                {
                        case Ctrl('C'):
                        case Ctrl('D'):
                        case -1:
                                return -1;
                        case KEY_CR:
                        case KEY_LF:
                                write(1, "\n\r", 2);
                                buf[ len ] = 0;
                                return len;
                        case KEY_BS:
                        case KEY_DEL:
                        case 127:
                                if (len > 0)
                                {
                                        write(1, "\b \b", 3);
                                        len--;
                                }
                                break;
                        default:
                                if (ch >= ' ' && ch < 0xff && len < maxlen)
                                {
                                        prints(NA,"%c", ch);
                                        buf[ len++ ] = ch;
                                }
                }
        }
}

dashf(fname)
char    *fname;
{
        struct stat st;

        return (stat(fname, &st) == 0 && S_ISREG(st.st_mode));
}

dashd(fname)
char    *fname;
{
        struct stat st;

        return (stat(fname, &st) == 0 && S_ISDIR(st.st_mode));
}

domenu(maintitle)
char *maintitle;
{
	MENU 	me;
	char 	buf[10],
		*name,
		*title;
	int	ch,
		tmplevel,
		num = 0;

	bzero(buf, sizeof(buf));
	strcpy(me.title , maintitle);
	loadnames(&me);

	tmplevel = level;

	if(level < BD)
		checklevel(&me);

	getcwd(me.pwd , sizeof(me.pwd));
	me.page = 9999;
	me.now  = 0;
	while (1) 
	{
		if (me.now >= me.num && me.num > 0) 
			me.now = me.num-1; 
		else if (me.now < 0)
			me.now = 0;

		if (me.now < me.page || me.now >= me.page + PAGESIZE)
		{
			me.page = me.now - (me.now % PAGESIZE);
			showmenu(&me);
		}
		move(3 + me.now - me.page, 1);      
		prints(NA,">");
		ch = igetkey();
		move(3 + me.now - me.page, 1);      
		prints(NA," ");
		if(ch == 'Q' || ch == 'q' || ch == KEY_LEFT)
			break;
		if (ch < '0' || ch > '9')
		{
			if (num != 0)
			{
				num = 0;
				if (ch == '\n' || ch == '\r')
				{
					me.now = atoi(buf) -1;
					bzero(buf, sizeof(buf));
					continue;
				}
				bzero(buf, sizeof(buf));
			}
		}
		else
			buf[num++] = ch;

		switch(ch) 
	    	{	

	    		case KEY_UP:  
	    		case 'K': 
	    		case 'k':
				if(me.now > 0)        
					me.now--;
				else                    
					me.now = me.num-1;
				break;
	    		case KEY_DOWN:  
	    		case 'J': 
	    		case 'j':
				if(me.now < me.num-1) 
					me.now++;
				else                    
					me.now = 0;
				break;
	    		case KEY_PGUP:  
	    		case Ctrl('B'):
				if(me.now >= PAGESIZE)        
					me.now -= PAGESIZE;
				else  if(me.now > 0)           
					me.now = 0;
				else                   
				       	me.now = me.num-1;
				break;
			case KEY_PGDN: 
			case Ctrl('F'):  
			case ' ':
				if(me.now < me.num - PAGESIZE)        
					me.now += PAGESIZE;
				else if(me.now < me.num-1)    
					me.now = me.num-1; 
				else           
				        me.now = 0;
				break;
	    		case KEY_LF:
			case 'R':  
			case 'r':
	    		case KEY_CR:  
	    		case KEY_RIGHT:
				if(me.now < me.num) 
				{
		    			name  = me.item[me.now]->path;  
		    			title = me.item[me.now]->name;    
		    			if(!(me.item[me.now]->mode)) 
						doarticle(title , name);
				    	else if(chdir(name) == 0) 
		    			{
						domenu(title);
						chdir(me.pwd);
		    			}
		    			me.page = 9999;
				}
				break;
	    		case 'H': 
	    		case 'h': 
	    		case '?':
				showhelp(&me);
				me.page = 9999; 
				break;
	    		case '/':
				if(dashf(SEARCHFILE)) 
				{
					char	path[STRLEN],
						title[STRLEN];

					if(searchboard(path, title, 1)) 
					{
						chdir(path);
						domenu(title);
						chdir(me.pwd);
		    			}
		    			me.page = 9999;
				}
				break;
	    	}
		if(level >= BD)
		{
			switch(ch) 
			{
				case 'W':
				case 'w':
					vedit("index.html", NA);
					execute("chmod 0644", "index.html");
					me.page = 9999;
					break;
		    		case 'N': 
				case 'n':
					addnewitem(&me, ADDITEM);
					me.page = 9999;
					break;
		    		case 'G':
				case 'g':
					addnewitem(&me, ADDGROUP);
					me.page = 9999;
					break;
		    		case 'I':
				case 'i':
					addnewitem(&me, ADDMAIL);
					me.page = 9999;
					break;
		    		case 'A':
				case 'a':
					appendart(&me);
					me.page = 9999;
					break;
		    		case 'P':
				case 'p':
					pastefile(&me);
					me.page = 9999;
					break;
		    	}
		}
		if(level >= BD && me.num)  
		{
			switch(ch) 
			{
	    			case 'M':  
	    			case 'm':
					moveitem(&me);
					me.page = 9999; 
					break;
		    		case 'D':  
		    		case 'd':
					deleteitem(&me);
					me.page = 9999; 
					break;
		    		case 'T':  
		    		case 't':
					dotitle(&me);
					me.page = 9999; 
					break;
		    		case 'E':
		    		case 'e':
					if (dashd(me.item[me.now]->path))
						break;
					vedit(me.item[me.now]->path, NA);
					me.page = 9999; 
					break;
		    		case 'f':
					fmode = (fmode + 1) % 2;
					me.page = 9999; 
					break;
		    		case 'F':
					dofilename(&me);
					me.page = 9999; 
					break;
		    		case 'C': 
				case 'c':
					copyitem(&me);
					me.page = 9999; 
					break;
		    	}
		}
		if(level >= SYSBD)
		{
			switch(ch) 
	            	{
		    		case 'B':  
		    		case 'b':
					level = 2 + (level + 1) % 2;
					me.page = 9999; 
					break;
#ifdef	ALLOW_SHELL
		    		case 'S':  
		    		case 's':
					x_csh()
					me.page = 9999; 
					break;
#endif
		    		case 'V':  
		    		case 'v':
					name = (ch == 'V') ?  SEARCHFILE :
						".Names";
					if(dashf(name)) 
					{
			    			vedit(name, NA);
			    			me.page = 9999;
					}
		    			break;
		    	}
		}
	}
    	for(ch = 0; ch < me.num; ch++)
		free(me.item[ch]);
	level = tmplevel;
}

int	faqview(board)
char	*board;
{
	char 	fpath[STRLEN],
		title[STRLEN];
	int	savemode = uinfo.mode,
		savecomp = uinfo.comp;

	changemode(READFAQ, (board) ? YEA : NA);
 	chdir(WORKPATH);

	if (board)
	{
		strcpy(fpath, board);

		if(searchboard(fpath, title , 0))
		{
			strcpy(uinfo.ptcb, board);
			chdir(fpath);
			domenu(title);
		}
	}
	else
	{
		strcpy(title, FAQTITLE);
		domenu(title);
	}
	clear();
	move(24,1);
	
	chdir(BBSHOME);
	changemode(savemode, savecomp);
	return 0;
}
