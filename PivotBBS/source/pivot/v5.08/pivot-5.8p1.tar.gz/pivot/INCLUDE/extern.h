/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef _EXTERN_H_ 
#define _EXTERN_H_

#ifndef _BBS_C_
extern int exit_warning(void);
extern int Announce(void);
extern int Maintenance(void);
extern int Xyz(void);
extern int Talk(void);
#ifdef LEVER
extern int Lever(void);
#endif
#ifdef FILES
extern int Files(void);
#endif
extern int Mail(void);
extern char uleveltochar(usint);
extern char bleveltochar(usint);
extern int printuent(userec *);
extern int countusers(userec *);
extern int Users(void);
extern int Goodbye(void);
extern int goodbye(void);
extern int show_goodbye(char *);
#ifdef FLAG_MAIN_U
extern int get_users(userec *);
extern int UserStatus(void);
#endif
extern int Info(void);
#ifdef GNU_License
extern int Conditions(void); 
#endif
extern int Welcome(void);
extern int Note(void);

extern int usercounter, totalusers, mot, usernum,  scrint;
extern int realusernum, tuid, tfile, rfile;
extern userec cuser, olddata;
extern char currboard[], genbuf[];
#endif /* _BBS_C_ */

#ifndef _BCACHE_C_
extern int numuents, numboards;
extern userec muser;
extern	bhd *bcache;
extern	UTMPCACHE	*utmpshm;
extern	BCACHE		*brdshm;
extern	UCACHE		*uidshm;
extern	int	search_board(bhd *,char *);
extern 	int 	boardcache(bhd *);
extern	int	cmpgroup(int, ghd *);
extern	int	apply_boards(int (*func)(), int, int);
extern	int	group_boards(int (*func)(), int, int);
extern	int	getgnum(char *);
extern	int	getbnum(char *);
extern	int	haspostperm(char *);
extern	int	fillucache(userec *);
extern	void	resolve_ucache( int );
extern	int	u_namelist(void);
extern	int	searchuser(char *);
extern	int	apply_users(void (*func)());
extern 	int 	getuser(char *);
extern 	int 	getnewutmpent(usinfo *);
extern	void	resolve_utmp(void);
extern	void	update_utmp(void);
extern	void	update_ulist(usinfo *,int);
extern	int	search_ulist(usinfo *,int (*func)(),int);
extern	int	apply_ulist(int (*func)()); 

#endif /* _BCACHE_C_ */

#ifndef _BOARDVOTE_C_
extern int b_clearflags(bhd *);
extern int b_suckinfile(FILE *, char *);
extern int b_closepolls(void);
extern int b_close(bhd *);
extern int b_vote_maintain(void);
extern int b_vote(void);
extern int b_results(void);
#endif /* _BOARDVOTE_C_ */

#ifndef _CHAT_C_
extern	int do_query(char *);
extern void printchatmsg(void);
extern void fixchatid(char *);
extern int t_chat(void);
extern char *advance(char *);

extern	void	printchatline();
extern void printprivmsg(char *);
extern int  printinfoline(char *);
extern	int	printchatent(usinfo *);
extern int dowho(void);
extern int printuserent(usinfo *);
extern int dousers(void);
extern int printlongent(usinfo *);
extern int dolong(void);
#ifdef REALINFO
extern int doreal(void);
#endif
extern int chatlookup(usinfo *);
extern int domsg(char *, int);
extern int donick(char *, int);
extern int dochatcommand(char *, int);
extern int ent_chat1(void);
extern int ent_chat2(void);
#ifdef USE_CHAT3
extern int ent_chat3(void);
#endif
extern int ent_chatbm(void);

extern char *msgto, *umsgto;
extern int chatroom, chatline, echatwin, newmail;
#ifdef REALINFO
extern int chat_real_names;
#endif
#endif /* _CHAT_C_ */

#ifndef _CHECKINFO_C_
#ifdef DELAY_NON_VIP
#ifdef TRIM
extern char *trim(char *);
#endif
extern int check_valid_vip(void); 
extern int delay_non_vip(void);
extern void typing(char *);
extern int slow_type(char *);
#endif
#endif /* _CHECKINFO_C_ */

#ifndef _COMM_LISTS_C_
extern cmds cmdlist[];
extern cmds postlist[];
extern cmds maillist[];
extern cmds filelist[];
extern cmds xyzlist[];
extern cmds talklist[];
extern cmds maintlist[];
#ifdef LEVER
extern cmds leverlist[];
#endif /* LEVER */
#endif /* _COMM_LISTS_C_ */

#ifndef _DELETE_C_
extern int delusernum;

extern int d_exit(void);
extern int boardcheck(bhd *);
extern int groupcheck(ghd *);
extern int d_board(void);
extern int delete_range(char *, int, int);
extern int duentposts(fhd *);
extern void duentbds(fhd *f);
extern int d_user(void);
#endif /* _DELETE_C */

#ifndef _DISCUSS_C_
extern int Discuss(void);
extern int filepr(fhd *);
extern int getstats(char *, int *, int *, int *, int *, char *);
extern int postcount(bhd *);
extern int Boards(void);
extern int New(void);
extern int Group(void);
extern int Kind(void);
extern	void	grouptitle(void);
extern int group_read(int, ghd *, char *);
extern int group_add(int, ghd *, char *);
extern int group_modify(int, ghd *, char *);
extern int group_delete(int, ghd *, char *);
extern	void	groupdoent(int, ghd *);
extern	int	CountBoards(void);
extern	char	*bfile(char *);
/* mark*/

extern	int	g_board_names(bhd *);
extern	void	make_blist(void);
extern	int	Select(void);
extern	int	get_title(char *, char *);
extern	int	Post(void);
extern	int	ztest(void);
extern	void	readtitle(void);
extern	void	readdoent(int, fhd *);
extern int cmpfilename(fhd *, char *);
extern void updatefile(fhd *);
extern int cook_announce(int, fhd *, char *);
extern int read_post(int, fhd *, char *);
extern int do_select(void);
#ifndef NOREPLY
extern int do_reply(fhd *);
#endif
extern int read_faq(int, fhd *, char *);
extern int read_do_post(int, fhd *, char *);
extern int do_post(fhd *, int);
extern int edit_post(int, fhd *, char *);
extern int mark_post(int, fhd *, char *);
extern int del_range(int, fhd *, char *);
extern int move_post(int, fhd *, char *);
#ifdef BBSTONEWS
extern void cancelpost(char *, char *, char *);
#endif
extern int undel_post(int, fhd *, char *);
extern int del_post(int, fhd *, char *);
extern int sequent_messages(fhd *);
extern int sequential_read(int, fhd *, char *);
extern int title_change(int, fhd *, char *);
extern int unread_post(int, fhd *, char *);
extern int cross_post(int, fhd *, char *);
extern int reply_post(int, fhd *, char *);
#ifdef INTERNET_EMAIL
extern int forward_post(int, fhd *, char *);
#endif
extern int Read(void);
extern int get_messages(fhd *);
extern int get_boards(fhd *);
#ifdef FLAG_MAIN_B
extern int g_messages(fhd *);
extern int g_boards(fhd *);
extern void BoardStatus(void);
#endif
extern int Zap(void);

extern char currboard[], genbuf[], currfile[], saveboard[], atot[], currtitle[];
extern char currauth[], match[];
extern int usercounter, mot, usernum, selboard, local_post, islocal, at;
extern int whichboards, tuid, tfile, rfile, m_count, m_total;
#ifdef HAS_BOARD_ANONYMOUS
extern int isscret;
extern one_key read_comms[], group_comms[];
#endif
#endif /* _DISCUSS_C_ */

#ifndef _EDIT_C_
extern void indigestion(int);
extern txtln *back_line(txtln *, int);
extern txtln *forward_line(txtln *, int);
extern int getlineno(void);
extern char *killsp(char *);
extern txtln *alloc_line(void);
extern void append(register txtln *, register txtln *);
extern void delete_line(register txtln *);
extern void split(register txtln *, register int);
extern int join(register txtln *);
extern void insert_char(register int);
extern void delete_char(void);
extern void vedit_init(void);
extern void vedit_free(void);
extern void read_file(char *);
extern void write_header(FILE *);
#ifndef MAKEVE
extern void addsignature(FILE *);
#endif
extern int write_file(char *, int);
extern void display_buffer(void);
extern int change_sig(void);
extern int vedit(char *, int);
extern void vedit_key(int);
extern void vedit_help(void);

extern txtln *firstline, *lastline, *currline, *top_of_win;
extern int currpnt, curr_window_line, redraw_everything, insert_character;
extern char save_title[], save_filename[];
extern int in_mail;
extern char *helptxt[];
#endif /* _EDIT_C_ */

#ifndef _FASTNEW_C_
extern bhd fh;
extern newhd *nbrd;
extern uschar uarray[];
/* mark */ 
extern int newpost_board(bhd *);
extern int count_newpost(newhd *, int);
extern char *newstr(newhd *, int);
extern char *brdstr(newhd *);
extern void show_brdlist(int, int, int, int);
extern int choose_board(int, int);
extern int visit_board(bhd *, int);
/* makr */
extern int visit_boards(bhd *);
extern int Visit(void);
extern int getnewuserid(void);

#endif /* _FASTNEW_C_ */

#ifndef _FILES_C_
extern ptcol protos[];
extern char dirs[][];
extern int fileselect, numdirs;

extern char *NameProtocol(int);
extern char *CurrentProtocol(void);
extern char *filemargin(void);
extern int get_dir(void);
extern int f_list(void);
extern int f_create_namelist(void);
extern int f_download(void);
extern int f_upload(void);
extern int f_protocol(void);
extern int f_select(void);
extern int f_text(void);
#endif /* _FILES_C_ */

#ifndef _GROUP_C_
extern int gain_group(void);
#endif /* _GROUP_C_ */

#ifndef _HELP_C_
extern hlpinfo BoardSelect[];
extern hlpinfo MailRead[];
extern hlpinfo MainRead[];
extern hlpinfo GroupRead[];

extern int do_the_help(hlpinfo *);
extern int do_chat_help(void);
extern void cmds_help(int, cmds *);
extern int Help(void);
extern int p_help(void);
extern int m_help(void);
#ifdef LEVER
extern int l_help(void);
#endif /* LEVER */
#ifdef FILES
extern int f_help(void);
#endif /* FILES */
extern int x_help(void);
extern int t_help(void);
extern int a_help(void);
extern int mainreadhelp(int, fhd *, char *);
extern int mailreadhelp(int, mhd *, char *);
extern int group_read_help(int, ghd *, char *);
extern int boardhelp(void);
#endif /* _HELP_C_ */

#ifndef _INFO_C_
#ifdef TSENG
extern int changemode(int, int, int, int, char *);
#else
extern int changemode(int, int);
#endif
extern int user_display(userec *, int);
extern int checkid(char *);
extern int checkpwd(char *, char *);
extern int checkemail(char *);
extern int i_userid(int, int, char *);
extern int i_passwd(int, int, userec *, char *);
extern int i_email(int, int, char *);
extern int i_changeinfo(int, int, int, char *, char *);
extern int i_username(int, int, char *);
extern int i_realname(int, int, char *);
extern int i_address(int, int, char *);
extern int i_terminal(int, int, userec *);
extern int change_num(int, int, char *);
extern int i_logins(int, userec *);
extern int i_posts(int, userec *);
extern int i_signum(int, userec *);
extern int modify_info(userec *, int, int);
extern int substitute_passwd(char *, userec *, int, int);
#endif /* _INFO_C_ */

#ifndef _IO_O_
extern char outbuf[], inbuf[];
extern int obufsize, ibufsize, icurrchar;

extern void hit_alarm_clock(void);
extern void init_alarm(void);
extern void oflush(void);
extern void output(char *, int);
extern int ochar(int);
extern void add_io(int, int);
extern void add_flush(int (*flushfunc)());
extern int num_in_buf(void);
extern int kbhit(void);
extern int igetch(void);
extern int getdata(int, int, char *, char *, int, int, int);
extern int igetkey(void);
extern int reply(int, int, char *, int);
extern int ask(char *);
#endif /* _IO_C_ */

#ifndef _LEVER_C_
#ifdef LEVER
#ifdef USE_BBSNET 
extern int l_bbsnet(void);
#endif
#ifdef USE_GOPHER
extern int l_gopher(void);
#endif
#ifdef USE_HYTELNET
extern int l_library(void);
#endif
#ifdef USE_TIN
extern int l_news(void);
#endif
#ifdef USE_TRIPOS
extern int l_tripos(void);
#endif
#ifdef USE_IRC
extern int l_irc(void);
#endif
#ifdef USE_TRC
extern int l_trc(void);
#endif
#ifdef USE_MMMM
extern int l_4m(void);
#endif
#endif
#endif /* _LEVER_C_ */

#ifndef _MAIL_C_
extern char currmaildir[];
#ifdef INTERNET_EMAIL
extern char forwardto[];
#endif
extern int delcnt, delmsgs[];
extern mhd mailfh;
extern one_key mail_comms[];

extern	void	m_init(userec);
extern	int	chkmails(userec,int);
extern	int	chkmail(int);
extern	int	m_exit(void);
extern	int	do_send(mhd *, char *);
extern	int	m_send(void);
extern	int	m_inter(void);
extern	int	read_mail(mhd *);
extern	int	read_new_mail(mhd *);
extern	int	m_new(void);
extern	void	mailtitle(void);
extern	void	maildoent(int, mhd *);
extern	int	mail_read(int, mhd *, char *);
extern	int	mail_reply(int, mhd *, char *);
extern	int	mail_del(int, mhd *, char *);
#ifdef INTERNET_EMAIL
extern	int	mail_forward(int, mhd *, char *);
#endif /* INTERNET_EMAIL */
extern	int	mail_del_range(int, mhd *, char *);
extern	int	mail_mark(int, mhd *, char *);
extern	int	m_admin(void);
extern	int	m_read(void);
#endif /* _MAIL_C_ */

#ifndef _MAIN_C_
extern jmp_buf byebye;
extern int talkrequest, bfinger, started, utmpent, dumb_term, refscreen;
extern FILE *ufp;
extern char lasthost[], BoardName[];
extern usinfo uinfo;
extern time_t lastlogin;

extern int u_enter(char *);
extern int cmpuids(char *, userec *);
extern int cmpuids2(int, usinfo *);
extern int dosearchuser(char *);
extern int dogetuser(int);
extern void abort_bbs(void);
#ifdef LOGINASNEW
extern int register_new(char *);
#endif /* LOGINASNEW */
extern void bbs_system_init(int);
extern void u_exit(void);
extern int multi_user_check(void);
extern int kickall(int, usinfo *);
extern int account_disabled(char *);
extern void myname(void);
extern void login(int, int, char *);
extern int init_perm(int, char **);
extern void main(int, char **);
extern char *boardmargin(void);
extern int egetch(void);
extern void menu_draw(char *, char *(*func)());
extern int docmd(char *, char *, int, cmds *, char *(*func)()); 
extern int m_adduser(void);
extern void logattempt(char *, char *, int);
extern int countattempts(void);
extern void showattempts(int);
#endif /* _MAIN_C_ */

#ifndef _MAINTAIN_C_
extern time_t cut_time;
extern char curruser[];
extern	int	count_exper(userec *, int *);
extern	int	clean_user(userec *);
extern	int	del_unused(void);
extern	int	m_uclean(void);
extern int m_xempt(void);
extern int m_info(void);
extern int m_plan(void);
extern int Create(void);
extern int m_chgroup(void);
extern int m_groupdelete(char *);
extern int m_groupadd(void);
extern int m_editbrd(void);
extern int modify_group(char *);
#endif /* _MAINTAIN_C_ */

#ifndef _MODES_C_
extern char *ModeType(int);
#endif /* _MODES_C_ */

#ifndef _MORE_C_
extern int readln(FILE *, char *);
extern int more(char *, int);
#endif /* _MORE_C_ */

#ifndef _NAMECOMPLETE_C_ 
extern	word	*toplev,
		*current;
extern	void	FreeNameList(void);
extern	void	CreateNameList(void);
extern	void	AddNameList(char *);
extern	int	NumInList(word *);
extern	void	ApplyToNameList(int (*func)());
extern	int	chkstr(char *, char *);
extern	word	*GetSubList(char *, word *);
extern	void	ClearSubList(word *);
extern	int	MaxLen(word *, int);
extern	int	namecomplete(char *, char *);
#endif /* _NAMECOMPLETE_C_ */

#ifndef _PASS_C_
extern	char	*genpasswd(char *);
extern	int	checkpasswd(char *, char *);
#endif /* _PASS_C_ */

#ifndef _READ_C_
extern	fhd	*files;
extern	mhd	*mails;

extern	keeploc	*getkeep(char *, int, int, int);
extern	void	fixkeep(char *, int, int);
extern	int	i_read(char *, void (*fptr)(), void (*func)(), one_key *,
			int, char *, char, int (*gnum)(), int (*grec)());
#endif /* _READ_C_ */

#ifndef _RECORD_C_
extern	char	abuf[];
#ifdef SYSV
extern	int	semid;
#endif /* SYSV */
#ifdef POSTBUG
extern	char	bigbuf[];
extern	int	numtowrite,
		bug_possible;
#endif /* POSTBUG */

#ifdef SYSV
extern	int	get_semaphore(void);
#endif /* SYSV */
#ifdef POSTBUG
extern void saverecords(char *, int, int);
extern int restorerecords(char *, int, int);
#endif /* POSTBUG */
extern int safewrite(int, char *, int);
extern	int	get_num_records(char *, int);
extern int append_record(char *, char *, int);
extern int append_mail(char *, char *, int);
extern int apply_record(char *, int (*fptr)(), int);
extern int apply_record2(char *, char *, int, int (*fptr)(), int);
extern int apply_record3(char *, int (*fptr)(), int, char *, int);
extern int search_record(char *, char *, int, int (*fptr)(), int);
extern int get_record(char *, char *, int, int);
extern int get_records(char *, char *, int, int, int);
extern int substitute_record(char *, char *, int, int);
extern int delete_record(char *, int, int);
extern int update_file(char *, int, int, int (*fptr)(), void (func)());
extern int delete_file(char *, int, int, int (*fptr)());
#endif /* _RECORD_C_ */

#ifndef _SCREEN_C_
extern uschar dsk_lns, dsk_cols, cur_ln, cur_col, roll, docls, downfrom;
extern int scrollcnt, standing;
extern	desk	*desk_top;
extern	char nullstr[];

extern void init_screen(int, int);
extern void initdsk(void);
extern void rel_move(int, int, int, int);
extern void standoutput(char *, int, int, int, int);
extern void redodsk(void);
extern void refresh(void);
extern void clear(void);
extern void clrtoeol(void);
extern void clrtobot(void);
extern void clrstandout(void);
extern void move(int, int);
extern void getyx(int *, int *);
extern void outc(uschar);
extern void outch(uschar);
extern void outansi(char *);
extern void outs(char *);
extern void prints();
extern void addch(int);
extern void scroll(void);
extern void rscroll(void);
extern void standout(void);
extern void standend(void);
#ifdef BIT8
extern int isprint2(char);
extern int isprint3(char);
#endif /* BIT8 */
#endif /* _SCREEN_C_ */

#ifndef _STUFF_C_
extern char *bbsenv[];
extern int numbbsenvs;

extern	int	logit();
extern	int	cantpage(int);
extern	char	*Ctime(time_t *);
extern	int	p_owned(fhd *);
extern	void	backspace(int);
extern	int	pressreturn(void);
extern	int	dumbreturn(void);
extern void bell(int);
extern void Getyn(char *);
extern char *strtolow(char *);
extern void get_date(struct tm *, char *, char *);
extern char getans(int, int, char *, int);
extern int strncmpi(char *, char *, int);
extern int bbssetenv(char *, char *);
extern int islocalbm();
extern int include_old(char *, char *, char);
extern int sh_exec(int, int, char *, char *);
extern int do_exec(char *, char *, int, int);
#endif /* _STUFF_C_ */

#ifndef _TALK_C_
#ifdef REALINFO
extern int real_user_names;
#endif /* REALINFO */
extern usinfo ui;
extern char page_requestor[], talkwith[], talkobuf[];
extern int talkobuflen, talkflushfd, idle_monitor_time;

extern void talk_request(void);
#ifdef LIST_IDLE_TIME
extern char *list_idle(usinfo *);
#endif /* LIST_IDLE_TIME */
extern int ishidden(char *);
extern char *modestring(int, int, int, char *);
extern char pagechar(char *, char *, int);
extern void user_list_title();
extern void user_list_uentp(usinfo *);
extern int printcuent(usinfo *);
extern int listcuent(usinfo *);
extern void creat_list(void);
extern int t_users(void);
extern int t_numb(void);
#ifdef REALINFO
extern int t_rusers(void);
#endif /* REALINFO */
extern int t_query(void);
#ifdef FLAG_MAIN_L
extern int dumb_list(usinfo *);
extern void dumb_user_list(void);
#endif /* FLAG_MAIN_L */
#ifdef FLAG_MAIN_A
extern do_all_list(usinfo *);
extern void list_all_users(void);
#endif /* FLAG_MAIN_A */
extern int count_active(usinfo *);
extern int num_active_users(void);
extern int t_cmpuids(int, usinfo *);
extern int t_cmppids(int, usinfo *);
extern int t_talk(void);
extern int cmpunums(int, usinfo *);
extern int searchuserlist(int);
extern int setpagerequest(void);
extern int servicepage(int, char *);
extern int talkreply(void);
extern int dotalkent(usinfo *, char *);
extern int dotalkuserlist(int, int, int *, int *, char *, int *);
extern void do_talk_string(int, int, int *, int *, char *, int *, char *);
extern void do_talk_char(int, int, int *, int *, char *, int *, int);
extern int talkflush(void);
extern void do_talk(int);
extern int shortulist(usinfo *, char *, int);
extern int do_list(void);
extern int t_list(void);
extern void sig_catcher(void);
extern int t_monitor(void);
extern int can_override(char *, char *);
extern int listfriends(void);
extern int addtooverride(char *);
extern int deleteoverride(char *);
extern int t_override(void);
extern int t_pager(void);
extern int t_friend(void);
extern int kick_user(void);
extern int select_multipid(int, int);
#endif /* _TALK_C_ */

#ifndef _TERM_C_
extern char *cm, *outp, clearbuf[], cleolbuf[], cursorm[], scrollrev[];
extern char strtstandout[], endstandout[], PC, *UP, *BC;
extern int clearbuflen, cleolbuflen, scrollrevlen, strtstandoutlen;
extern int endstandoutlen, t_lines, t_columns, automargins, *outlp;
#ifdef	LINUX
extern struct termios tty_state, tty_new;
#else
extern struct sgttyb tty_state, tty_new;
#endif
extern short ospeed;

extern void get_tty(void);
extern void init_tty(void);
extern void reset_tty(void);
extern void restore_tty(void);
extern void outcf(char);
extern int term_init(char *);
extern void do_move(int, int, int (*fptr)());
#endif /* _TERM_C_ */

#ifndef _XYZ_C_
extern permin permstrings[];
extern permin setstrings[];

extern	int	x_csh(void);
extern	usint	setperms(usint, permin *);
extern	int	x_media(void);
extern	int	x_cloak(void);
extern	int	x_date(void);
extern	int	x_info(void);
extern	int	x_offline(void);
extern	int	x_editsig(void);
extern	int	x_edlogout(void);
extern	int	x_editplan(void);
extern	int	x_level(void);
extern	int	x_motd(void);
#endif /* _XYZ_C_ */

#endif /* _EXTERN_H_ */

extern	int	faqview( char *);
