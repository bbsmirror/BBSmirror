/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef _PERM_H_
/*
 * �v�������]�w
 */
#define PERM_BASIC      0x00000001
#define PERM_CHAT       0x00000002
#define PERM_PAGE       0x00000004
#define PERM_POST       0x00000008
#define PERM_TRUE       0x00000010
#define PERM_LOCALBM    0x00000020
#define PERM_CHATMNG	0x00000040
#define PERM_NOCLEAN	0x00000080
#define PERM_ANNOUNBM	0x00000100
#define PERM_SPECIAL3	0x00000200
#define PERM_SPECIAL4	0x00000400
#define PERM_SPECIAL5	0x00000800
#define PERM_SPECIAL6	0x00001000
#define PERM_SPECIAL7	0x00002000
#define PERM_SPECIAL8	0x00004000
#define PERM_SPECIAL9	0x00008000
#define PERM_SPECIAL10	0x00010000
#define PERM_SPECIAL11	0x00020000
#define PERM_CLOAK      0x00040000
#define PERM_SEECLOAK   0x00080000
#define PERM_UPLOAD     0x00100000
#define PERM_WELCOME    0x00200000
#define PERM_BOARDS     0x00400000
#define PERM_ACCOUNTS   0x00800000
#define PERM_CHATCLOAK  0x01000000
#define PERM_OVOTE      0x02000000
#define PERM_SUBSYSOP   0x04000000
#define PERM_BBSSYSOP   0x08000000
#define PERM_SYSOP1     0x10000000
#define PERM_SYSOP2     0x20000000
#define PERM_SYSOP      0x40000000
#define PERM_MAXLEVEL	0x80000000

#define PERM_SENDMAIL   0x00000000
#define	PERM_NOTE	(PERM_CHAT)
#define PERM_GUEST      PERM_BASIC
#define PERM_READMAIL   PERM_BASIC
#define PERM_SETADDR    PERM_BASIC     /* to set address for forwarding */
#define PERM_FORWARD    PERM_BASIC     /* to do the forwarding */
#define PERM_VOTE       PERM_POST 
#define PERM_MULTILOG   (PERM_SYSOP | PERM_LOCALBM | PERM_CHATMNG | \
			PERM_ACCOUNTS | PERM_BOARDS |PERM_TRUE)
#define PERM_SEEULEVELS PERM_SYSOP
#define PERM_NOTIMEOUT  PERM_SYSOP
#define PERM_SPECIAL    (PERM_ACCOUNTS | PERM_BOARDS | PERM_SYSOP)
#define PERM_LOGINCLOAK PERM_SPECIAL
#define PERM_DEFAULT    (PERM_BASIC | PERM_PAGE | PERM_POST | PERM_CHAT)
#define	PERM_IDENT	(PERM_BASIC|PERM_PAGE|PERM_POST|PERM_CHAT|PERM_TRUE)
#define	PERM_CHECKED	(PERM_DEFAULT | PERM_TRUE)
#define PERM_ADMINMENU  (PERM_ACCOUNTS | PERM_BOARDS | PERM_OVOTE | PERM_SYSOP)
#define PERM_SEEBLEVELS (PERM_SYSOP | PERM_BOARDS)
#define PERM_MARKPOST   (PERM_SYSOP | PERM_BOARDS)
#define PERM_BMS        (PERM_SYSOP | PERM_BOARDS | PERM_LOCALBM)
#define PERM_UCLEAN     (PERM_SYSOP | PERM_ACCOUNTS)
#define PERM_LOCAL	(PERM_LOCALBM | PERM_CHATMNG)
#define	PERM_INTER	PERM_TRUE

/*
 * �ϥάɭ��]�w
 */
#define SET_AUTOHELP    0x00000001	/* autohelp while select */
#define SET_REALMAIL    0x00000002	/* use realname while mail */
#define SET_REALPOST    0x00000004	/* use realname while post */
#define SET_REALQUERY   0x00000008	/* allow show realname while query */
#define SET_REALFORWARD 0x00000010	/* user realname while forward */
#define SET_ANSIMODE    0x00000020	/* users' screen is ANSI COLORful */
#define SET_YANKIN      0x00000040	/* Yank In All Boards */
#define SET_ACTIVE      0x00000080	/* Active Post */
#define SET_COUNTNEW	0x00000100	/* ���i�J New/Kind �ɺ�s�H��ƥ� */
#define SET_GRPYANKOUT  0x00000200	/* ���ϥ� Group ��, �O�� yank out */
#define SET_CHATSCROLL  0x00000400	/* Chat room �H scroll �B�z */
#define SET_USERLIST    0x00000800	/* ���Φ۰ʸɨ��\�� */
#define	SET_DISNOTE	0x00001000	/* ���ίd���O */
#define	SET_NOSIG	0x00002000	/* ñ�W�ɨϥα��� */
#define	SET_PAGER	0x00004000	/* �͸ܪ��A�}���� */
#define	SET_ALLPAGER	0x00008000	/* ��B�ͽ͸ܪ��A�}���� */
#define	SET_MEDIA0	0x00010000	/* �O�d */
#define	SET_MEDIA1	0x00020000	/* �O�d */
#define	SET_MEDIA2	0x00040000	/* �O�d */
#define	SET_MEDIA3	0x00080000	/* �O�d */
#define	SET_MEDIA4	0x00100000	/* �O�d */
#define	SET_MEDIA5	0x00200000	/* �O�d */
#define	SET_MEDIA6	0x00400000	/* �O�d */
#define	SET_MEDIA7	0x00800000	/* �O�d */
#define	SET_MEDIA8	0x01000000	/* �O�d */
#define	SET_MEDIA9	0x02000000	/* �O�d */
#define	SET_MEDIAa	0x04000000	/* �O�d */
#define	SET_MEDIAb	0x08000000	/* �O�d */
#define	SET_MEDIAc	0x10000000	/* �O�d */
#define	SET_MEDIAd	0x20000000	/* �O�d */
#define	SET_CLOAK	0x40000000	/* �ϥ������N(PERM_CLOAK only) */
#define SET_ENVMASK	0x80000000

#define SET_DEFAULT     (SET_AUTOHELP | SET_REALFORWARD | SET_CHATSCROLL \
			| SET_ANSIMODE)

#define HAS_PERM(x)     ((x)?cuser.userlevel&(x):1)
#define HAS_SET(x)      ((x)?cuser.userset&(x):1)  
#define	SWITCH_SET(x)	switch_bit(&(cuser.userset), x);

/*
 * �ɮ�Ū���ݩʳ]�w
 */
#define FILE_READ	0x1		/* Ū�L */
#define FILE_OWND	0x2		/* �����H */
#define FILE_VISIT	0x4		/* VISIT �L, ����Ū�L */
#define FILE_MARKED	0x8		/* �j�q�R���O�d�Ÿ� */

/*
 * Login ����˹�
 */
#define ERR_EMAIL	0x0001
#define ERR_NICK	0x0002
#define ERR_REALNAME	0x0004
#define ERR_ADDR	0x0008

/*
 * Ū�H, �Q�פ峹�B�z�Ѧҭ�
 */
#define DONOTHING	0x00		/* ���@�B�z */
#define FULLUPDATE	0x01		/* �����iŪ�ɥؿ� */
#define PARTUPDATE	0x02		/* ����Ū�ɥؿ���� */
#define DOQUIT		0x04		/* ���} */
#define NEWDIRECT	0x08		/* �s���|, ���Q�װ� */
#define READ_PREV	0x10		/* Ū�W�@�g */
#define READ_NEXT       0x20		/* Ū�U�@�g */
#define LOCALSAVE       0x40		/* Local �s�� */
#define REDOIREAD	0x80		/* ���� i_read() */
#define	READ_SLEEP	0x100		/* �S�ʰ� */
#define	READ_LOOP	0x200		/* ���s�@ mode ���� */
#define	FAST_SELECT	0x400		/* fastnew.c Enter ���� */

/*
 * ���i���ӤHŪ���ݩʳ]�w
 */
#define ZAPPED		0x0001		/* �������� */
#define VOTED		0x0002		/* �����w��L�� */
#define	BRD_INFO	0x0004		/* ������Ū�e��ƤwŪ�L */

/*
 * ���i���Q�װϪ��A�ݩʳ]�w  (.BOARDS)
 */
#define	BHD_BBSNEWS	0x0001		/* �����ѥ[��H */
#define BHD_VOTEING	0x0002		/* �������b�벼 */
#define	BHD_NOZAP	0x0004		/* ���O���i�Q ZAP */
#define	BHD_ANONYMOUS	0x0008		/* ���O���ΦW�O */
#define	BHD_LIMIT_R	0x0010		/* ���O�]��Ū������ */
#define	BHD_LIMIT_P	0x0020		/* ���O�]���i�K���� */

#endif /* _PERM_H_ */
