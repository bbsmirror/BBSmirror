/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)read.c  5.08 3/19/95 (C) 1995 University of \
NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include "bbs.h"
#define	SCRLN	(t_lines-4)

keeploc *getkeep(s, def_topline, def_cursline, newflag)
char	*s;
int	def_topline,
	def_cursline,
	newflag;
{
	static	keeploc	*keeplist = NULL;
	keeploc	*p;

	for(p = keeplist; p!= NULL; p = p->next)
	{
		if (!strcmp(s,p->key))
		{
			if (newflag)
			{
				p->top_line = def_topline;
				p->crs_line = def_cursline;
			}
			if (p->crs_line < 1)
				p->crs_line = 1;
			if (p->top_line < 1)
				p->top_line = 1;
			strcpy(match, p->match);
			strcpy(currtitle, p->ctitle);

			return p;
		}
	}

	p = (struct keeploc *) malloc(sizeof (*p));
	p->key = (char *) malloc(strlen(s) + 1);
	strcpy(p->key, s);
	p->top_line = def_topline;
	p->crs_line = def_cursline;
	bzero(p->match, sizeof(p->match));
	bzero(p->ctitle, sizeof(p->ctitle));
	p->next = keeplist;
	keeplist = p;

	return p;
}

void	fixkeep(s, first, last)
char	*s;
int	first,
	last;
{
	keeploc	*k;

	k = getkeep(s, 1, 1, 0);
	if (k->crs_line >= first)
	{
		k->crs_line = (first == 1 ? 1 : first-1);
		k->top_line = (first < 11 ? 1 : first-10);
	}
}

int	r_matchtitle(last, size, dbuf, loc, point, grec)
int	last,
	size,
	(*grec)();
keeploc	*loc;
char	*dbuf,
	*point;
{
	char	tmpbuf[STRLEN];
	int	ofname,
		oftitl;

	if (uinfo.mode == GROUP || uinfo.mode == KIND)
		return DONOTHING;

	if (in_mail)
	{
		mhd	mails;

		size = sizeof(mhd);
		oftitl = (int)&mails.title - (int)&mails;
	}
	else
	{
		fhd	files;

		size = sizeof(fhd);
		oftitl = (int)&files.title - (int)&files;
	}

	strcpy(tmpbuf, &point[(loc->crs_line - loc->top_line)*size + oftitl]);
	if(strstr(tmpbuf, "Re: ") == tmpbuf)
		strcpy(match, tmpbuf+4);
	else
		strcpy(match, tmpbuf);
	strcpy(loc->match, match);
	move(t_lines-1, 0);
	prints(NA, "�]�w�j�M: %s", match);

	return DONOTHING;
}

int	r_matchsender(last, size, dbuf, loc, point, grec)
int	last,
	size,
	(*grec)();
keeploc	*loc;
char	*dbuf,
	*point;
{
	int	ofname,
		oftitl;

	if (uinfo.mode == GROUP || uinfo.mode == KIND)
		return DONOTHING;

	if (in_mail)
	{
		mhd	mails;

		size = sizeof(mhd);
		ofname = (int)&mails.sender - (int)&mails;
	}
	else
	{
		fhd	files;

		size = sizeof(fhd);
		ofname = (int)&files.sender - (int)&files;
	}
	strcpy(match, &point[(loc->crs_line - loc->top_line) * size] + ofname);
	strcpy(loc->match, match);
	move(t_lines-1, 0);
	prints(NA, "�]�w�j�M: %s", match);

	return DONOTHING;
}

int	r_search(ch, last, size, dbuf, loc, point, grec)
int	ch,
	last,
	size,
	(*grec)();
keeploc	*loc;
char	*dbuf,
	*point;
{
	char	sbuf[STRLEN],
		buf[STRLEN],
		title[STRLEN],
		sender[STRLEN];
	int	i,
		next,
		quit = NA,
		end,
		limit,
		curr_line,
		curr_top,
		ofname,
		oftitl;

	if (uinfo.mode == GROUP || uinfo.mode == KIND)
		return DONOTHING;

	if (in_mail)
	{
		mhd	mails;

		size = sizeof(mhd);
		oftitl = (int)&mails.title - (int)&mails;
		ofname = (int)&mails.sender - (int)&mails;
	}
	else
	{
		fhd	files;

		size = sizeof(fhd);
		oftitl = (int)&files.title - (int)&files;
		ofname = (int)&files.sender - (int)&files;
	}

	bzero(sbuf, sizeof(sbuf));

	if (ch == '+')
	{
		if (loc->crs_line >= last)
		{
			bell(1);
			return DONOTHING;
		}
		next = 1;
		end = last + 1;
		limit = loc->top_line + SCRLN;
		sprintf(buf, "��J�V�U�j�M�r��G");  
	}
	else
	{ 
		if (loc->crs_line <= 1)
		{
			bell(1);
			return DONOTHING;
		}
		next = -1;
		end = 0;
		limit = loc->top_line - 1;
		sprintf(buf, "��J�V�W�j�M�r��G");
	}

	getdata(t_lines-1, 0, buf, match, STRLEN, DOECHO, NA);
	move(t_lines-1, 0);
	clrtoeol();
	if (match[0] == '\0')
		return DONOTHING;

	strcpy(sbuf, strtolow(match));
	curr_line = loc->crs_line;
	curr_top  = loc->top_line;

	for(i = curr_line + next; i != end; i += next)
	{
		if (kbhit() == 'q')
			break;
		if (i == limit)
		{
			curr_top += (next * SCRLN);
			if (ch == '+')
			{
				if (curr_top > last)
					curr_top = last;
				limit = curr_top + SCRLN;
				if (limit > last+1)
					limit = last+1;
			}
			else
			{
				if (curr_top <= 0)
					curr_top = 1;
				limit -= SCRLN;
				if (limit < 0)
					limit = 0;
	  		}
			(*grec)(dbuf, point, size, curr_top, SCRLN);
		}

		move(t_lines-1, 0);
		prints(NA, "�M��� [%4d] �����", i);
		refresh();
		strcpy(title, strtolow(&point[(i-curr_top)*size + oftitl]));
		strcpy(sender, strtolow(&point[(i-curr_top)*size + ofname]));

		if (strstr(title, sbuf) || strstr(sender, sbuf))
		{
			RMVCURS;
			loc->top_line = curr_top;
			loc->crs_line = i;
			quit = YEA;

			break;
		}
	}

	if (!quit)
	{
		(*grec)(dbuf, point, size, loc->top_line, SCRLN);
		move(t_lines-1, 0);
		prints(NA, "�j�M %.50s ����, �����N���~��.......", match);
		egetch();
	}
	move(t_lines-1, 0);
	clrtoeol();
	PUTCURS;

	return (quit) ? PARTUPDATE : DONOTHING;
}

int	r_searchup(last, size, dbuf, loc, point, grec)
int	last,
	size,
	(*grec)();
keeploc *loc;
char	*dbuf,
	*point;
{
	return r_search('+', last, size, dbuf, loc, point, grec);
}

int	r_searchdown(last, size, dbuf, loc, point, grec)
int	last,
	size,
	(*grec)();
keeploc	*loc;
char	*dbuf,
	*point;
{
	return r_search('-', last, size, dbuf, loc, point,
		grec);
}

int	r_upper(last, size, dbuf, loc, point, grec)
int	last,
	size,
	(*grec)();
keeploc	*loc;
char	*dbuf,
	*point;
{
	if (loc->crs_line <= loc->top_line)
	{
		if (loc->crs_line <= 1)
		{
			loc->crs_line = last;
			loc->top_line = (last / SCRLN) *
				SCRLN + 1;

			return PARTUPDATE;
		}
		loc->top_line -= SCRLN;
		if (loc->top_line <= 0)
			loc->top_line = 1;
		loc->crs_line--;

		return PARTUPDATE;
	}
	RMVCURS;
	loc->crs_line--;
	PUTCURS;

	return DONOTHING;
}

int	r_down(last, size, dbuf, loc, point, grec)
int	last,
	size,
	(*grec)();
keeploc	*loc;
char	*dbuf,
	*point;
{
	if (loc->crs_line >= last)
	{
		loc->crs_line = 1;
		loc->top_line = 1;

		return PARTUPDATE;
	}
	if (loc->crs_line + 1 >= loc->top_line + SCRLN)
	{
		loc->top_line += SCRLN;
		loc->crs_line++;

		return PARTUPDATE;
	}
	RMVCURS;
	loc->crs_line++;
	PUTCURS;

	return DONOTHING;
}

int	r_pgup(last, size, dbuf, loc, point, grec)
int	last,
	size,
	(*grec)();
keeploc	*loc;
char	*dbuf,
	*point;
{
	if (loc->top_line == 1)
	{
		bell(1);
		return DONOTHING;
	}
	loc->top_line -= SCRLN - 1;
	if (loc->top_line <= 0)
		loc->top_line = 1;
	loc->crs_line = loc->top_line;

	return PARTUPDATE;
}

int	r_end(last, size, dbuf, loc, point, grec)
int	last,
	size,
	(*grec)();
keeploc	*loc;
char	*dbuf,
	*point;
{
	if (last < loc->top_line + SCRLN)
	{
		RMVCURS;
		loc->crs_line = last;
		PUTCURS;

		return DONOTHING;
	}
	loc->top_line = last - SCRLN + 1;
	if (loc->top_line <= 0)
		loc->top_line = 1;
	loc->crs_line = last;

	return PARTUPDATE;
}

int	r_quit(last, size, dbuf, loc, point, grec)
int	last,
	size,
	(*grec)();
keeploc	*loc;
char	*dbuf,
	*point;
{
	return	DOQUIT;
}

int	r_pgdn(last, size, dbuf, loc, point, grec)
int	last,
	size,
	(*grec)();
keeploc	*loc;
char	*dbuf,
	*point;
{
	if (last < loc->top_line + SCRLN)
	{
		RMVCURS;
		loc->crs_line = last;
		PUTCURS;

		return DONOTHING;
	}
	loc->top_line += SCRLN -1;
	loc->crs_line = loc->top_line;

	return PARTUPDATE;
}

int	r_redraw(last, size, dbuf, loc, point, grec)
int	last,
	size,
	(*grec)();
keeploc	*loc;
char	*dbuf,
	*point;
{
	redodsk();
	return DONOTHING;
}

int	r_home(last, size, dbuf, loc, point, grec)
int	last,
	size,
	(*grec)();
keeploc	*loc;
char	*dbuf,
	*point;
{
	int	redraw = YEA;

	if(loc->top_line < SCRLN)
	{
		redraw = NA;
		RMVCURS;
	}
	loc->top_line = 1;
	loc->crs_line = 1;
	if(!redraw)
	{
		PUTCURS;
		return DONOTHING;
	}
	else
		return PARTUPDATE;
}

one_key	readcmd[] =
{
	'+',		r_searchup,
	'-',		r_searchdown,
	'/',		r_matchtitle,
	'?',		r_matchsender,
	'q',		r_quit,
	'e',		r_quit,
	KEY_LEFT,	r_quit,
	'p',		r_upper,
	'k',		r_upper,
	KEY_UP,		r_upper,
	CTRL('L'),	r_redraw,
	'n',		r_down,
	'j',		r_down,
	KEY_DOWN,	r_down,
	'N',		r_pgdn,
	CTRL('F'),	r_pgdn,
	KEY_PGDN,	r_pgdn,
	'P',		r_pgup,
	CTRL('B'),	r_pgup,
	KEY_PGUP,	r_pgup,
	'$',		r_end,
	KEY_END,	r_end,
	'!',		r_home,
	KEY_HOME,	r_home,
	'\0',		NULL,
};

int	rs_part(entn, last, size, dbuf, loc, point, doent, dottl, gnum, grec)
int	*entn,
	size,
	*last,
	(*grec)();
long	(*gnum)();
keeploc	*loc;
char	*dbuf,
	*point,
	*(*doent)(),
	(*dottl)();
{
	int i;

	*last = (*gnum)(dbuf, size);

	if (loc->crs_line > (*last))
		loc->crs_line = (*last);
	if (*last == 0)
	{
		prints(NA, "No Messages\n");
		*entn = 0;

		return READ_SLEEP;
	}
	*entn = (*grec)(dbuf, point, size, loc->top_line, SCRLN);

	move(3, 0);
	for(i=0; i < *entn; i++)
	{
		(*doent)(loc->top_line + i, &point[i*size]);
	}

	strcpy(loc->ctitle, currtitle);
	clrtobot();
	PUTCURS;
	refresh();
	return DONOTHING;
}

int	rs_full(entn, last, size, dbuf, loc, point, doent, dottl, gnum, grec)
int	*entn,
	size,
	*last,
	(*gnum)(),
	(*grec)();
keeploc	*loc;
char	*dbuf,
	*point,
	*(*doent)(),
	(*dottl)();
{
	move(0,0);
	clrtobot();
	(*dottl)();

	return rs_part(entn, last, size, dbuf, loc, point, doent, dottl, gnum,
		grec);
}
/*
int	rs_new(entn, last, size, dbuf, loc, point, doent, dottl, gnum, grec)
int	*entn,
	size,
	*last,
	(*gnum)(),
	(*grec)();
keeploc	*loc;
char	*dbuf,
	*point,
	*(*doent)(),
	(*dottl)();
{
	bhd	fh;
	int	pos,
		ret;

	if (!(pos = search_board(&fh,currboard)))
	{
		return FULLUPDATE;
	}
	strcpy(dbuf, strcat(bfile(currboard), FHDIR));

	ret = rs_full(entn, last, size, dbuf, loc, point, doent, dottl, gnum,
		grec);

	loc = getkeep(dbuf, ((*last) - SCRLN < 1) ? 1 : (*last) - SCRLN + 1,
		*last, 0);

	return ret;
}
*/
int	rs_prev(entn, last, size, dbuf, loc, point, doent, dottl, gnum, grec)
int	*entn,
	size,
	*last,
	(*gnum)(),
	(*grec)();
keeploc	*loc;
char	*dbuf,
	*point,
	*(*doent)(),
	(*dottl)();
{
	int	top = NA,
		redoent = NA;

	if (loc->crs_line <= loc->top_line)
	{
		loc->top_line -= SCRLN - 2;
		*entn = (*grec)(dbuf, point, size, loc->top_line, SCRLN);
	}

	if (loc->top_line < 1)
		loc->top_line = 1;

	loc->crs_line--;
	if (loc->crs_line < 1)
	{
		loc->crs_line = 1; 
		return rs_full(entn, last, size, dbuf, loc, point, doent,
			dottl, gnum, grec);
	}

	return READ_LOOP;
}

int	rs_next(entn, last, size, dbuf, loc, point, doent, dottl, gnum,
	grec)
int	*entn,
	size,
	*last,
	(*gnum)(),
	(*grec)();
keeploc	*loc;
char	*dbuf,
	*point,
	*(*doent)(),
	(*dottl)();
{
	int	bottom = NA,
		redoent = NA;

	if (loc->crs_line >= *last)
	{
		return rs_full(entn, last, size, dbuf, loc, point, doent,
			dottl, gnum, grec);
	}
	else if (++loc->crs_line == loc->top_line + SCRLN)
	{
		loc->top_line += SCRLN - 2;
		*entn = (*grec)(dbuf, point, size, loc->top_line, SCRLN);
	}

	return READ_LOOP;
}

one_key	modecmd[] =
{
/*	NEWDIRECT,	rs_new,*/
	FULLUPDATE,	rs_full,
	READ_NEXT,	rs_next,
	READ_PREV,	rs_prev,
	PARTUPDATE,	rs_part,
	0,		NULL,
};

int	i_read(direct, dottl, doent, rcmd, fcmd, prompt, def, gnum, grec)
char	*direct,	/*  ��ƨӷ��ؿ� */
	*prompt,	/*  ���ܦr�� */
	def;		/*  default command */
void	(*doent)(),	/*  ��ܸ�Ƥ��e */
	(*dottl)();	/*  �W���T�� */
int	(*grec)(),	/*  ���o��� */
	(*gnum)(),	/*  �p��i�θ�Ƶ��� */
	fcmd;		/*  first command */
one_key *rcmd;		/*  command table */
{
	int	num_entries,
		size,
		i,
		ch = 0,
		mode = DONOTHING,
		lbc = 0,
		val,
		last;
	char	*point,
		lbuf[10],
		dbuf[STRLEN];
	keeploc	*loc;

	switch (uinfo.mode)
	{
		case RMAIL:
		case MSYSOP:
		{
			size = sizeof(mhd);
			point = (char *)calloc(SCRLN, size);

			break;
		}
		case GROUP:
		case KIND:
		{
			size = sizeof(ghd);
			point = (char *)calloc(SCRLN, size);

			break;
		}
		case SHOW:
		case READNEW:
		{
			size = sizeof(newhd);
			point = (char *)calloc(SCRLN, size);

			break;
		}
		default:
		{
			size = sizeof(fhd);
			point = (char *)calloc(SCRLN, size);

			break;
		}
	}

	strcpy(dbuf, direct);
        move(0, 0);
        (*dottl)();
        clrtobot();

        last = (*gnum)(dbuf, size);

	if (last == 0)
	{
		ch = getans(3, 0, prompt, def);
		if(ch != def)
		{
			clear();
			return -1;
		}
		else
		{
			ch = fcmd;
			mode = DONOTHING;
		        last = (*gnum)(dbuf, size);
		}
	}

        loc = getkeep(dbuf, (last-SCRLN+1 < 1) ? 1 :
                (last-SCRLN+1), last, 0);

        if (loc->top_line > last)
        {
                loc->crs_line = last;
                loc->top_line = last - 10;
                if (loc->top_line < 1)
                        loc->top_line = 1;
        }
        if (loc->crs_line > last)
                loc->crs_line = last;

        num_entries = (*grec)(dbuf, point, size, loc->top_line,
                SCRLN);

        move(3, 0);

        for(i = 0; i < num_entries; i++)
        {
                (*doent)(loc->top_line+i, &point[i*size]);
        }

        PUTCURS;
        lbc = 0;

	if(mode != DONOTHING)
	{
		ch = egetch();
		mode = DONOTHING;
	}
	do
	{
		move(t_lines-1, 0);
		clrtoeol();
		PUTCURS;

		if (talkrequest)
		{
			talkreply();
			mode = FULLUPDATE;
			ch = '\0';
		}

		if (ch < 0x100 && isdigit(ch))
		{
			if (lbc < 9)
				lbuf[lbc++] = ch;
			continue;
		}

		if (ch != '\n' && ch != '\r' && ch != ' ')
			lbc = 0;
		else if(lbc != 0)
		{
			lbuf[lbc] = '\0';
			val = atoi(lbuf);
			lbc = 0;
			if (val > last)
			val = last;
			if (val <= 0)
				val = 1;
			if (val >= loc->top_line && val < loc->top_line
				+ SCRLN)
			{
				RMVCURS;
				loc->crs_line = val;
				PUTCURS;
				continue;
			}
			loc->top_line = val - 10;
			if (loc->top_line <= 0)
				loc->top_line = 1;
			loc->crs_line = val;
			mode = PARTUPDATE;
			ch = 0;
		}

		for(i = 0; readcmd[i].fptr != NULL; i++)
		{
			if(readcmd[i].key == ch)
			{
				mode = (*readcmd[i].fptr)(last, size,
					dbuf, loc, point, grec);
				PUTCURS;
				break;
			}
		}

		for(i = 0; rcmd[i].fptr != NULL; i++)
		{
			if (rcmd[i].key == ch)
			{
				mode = (*(rcmd[i].fptr))(loc->crs_line,
					&point[(loc->crs_line -
					loc->top_line)*size], dbuf, grec);
				break;
			}
		}

		for(i = 0; (*modecmd[i].fptr) != NULL; i++)
		{
			if(modecmd[i].key == mode)
			{
				mode = (*modecmd[i].fptr)(&num_entries, &last,
					size, dbuf, loc, point, doent, dottl,
					gnum, grec);
				break;
			}
		}

		switch (mode)
		{
			case	NEWDIRECT:
			case	REDOIREAD:
				return REDOIREAD;
			case	DOQUIT:
				free(point);
				clear();
				return 0;
		}

		if (num_entries == 0)
			break;
	}
	while ((mode == READ_LOOP) || (ch = egetch()) != EOF);

	clear();
	return 0;
}
