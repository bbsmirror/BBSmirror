/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)boardvote.c   5.08 3/19/95 (C) 1993 \
University of NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include "bbs.h"
#ifdef BOARD_VOTE

#include "bbs.h"
#ifndef SYSV
#include <sys/file.h>
#endif
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>

int	b_clearflags(fh)
bhd	*fh;
{
	int	i;

	for (i = 0; i < MAXUSERS; i++)
		fh->accessed[i] &= ~VOTED;

	return 0;
}

int	b_suckinfile(fp, fname)
FILE	*fp;
char	*fname;
{
	char	inbuf[256];
	FILE	*sfp;

	if ((sfp = fopen(fname, "r")) == NULL) 
		return -1;

	while (fgets(inbuf, sizeof(inbuf), sfp) != NULL)
	    fputs(inbuf, fp);
	fclose(sfp);

	return 0;
}

int	b_closepolls(void)
{
	bhd	fh;
	struct	stat	st;
	int	pos;
	char	buf[STRLEN];

	sprintf(buf, "vote/%s.control", currboard);

	if (stat(buf, &st) == -1) 
		return -1;

	if (!(pos = search_board(&fh,currboard)))
		return -1;

	if (b_close(&fh) == 1)
		return -1;
	if (substitute_record(BOARDS, (char *)&fh, sizeof(fh), pos) == -1)
		return -1;

	return 0;
}

int	b_close(fh)
bhd	*fh;
{
	FILE	*cfp,
		*tfp;
	char	inchar,
		inbuf[80],
		b_control[80],
		b_ballots[80],
		b_desc[80],
		b_temp[80],
		r_buf[STRLEN],
		b_results[80],
		b_newresults[80];
	int	bfd,
		counts[10];
	time_t	endtime;
	
	sprintf(b_control, "vote/%s.control", fh->filename);
	sprintf(b_temp, "vote/%s.temp", fh->filename);
	
	if ((cfp = fopen(b_control, "r")) == NULL) 
	{
	    	if (fh->accessed[usernum] & VOTED) 
			fh->accessed[usernum] &= ~VOTED;
	    	return 0;
	}

	if (fgets(inbuf, sizeof(inbuf), cfp) == NULL)
	{
	    fclose(cfp);
	    return 1;
	}

	fclose(cfp);
	endtime = (time_t)atol(inbuf);

	if (endtime > time(0) || endtime <= 0) 
		return 1;

	if (rename(b_control, b_temp) == -1) 
		return 1;

	fh->flag &= ~BHD_VOTEING;

	for (bfd = 0; bfd < 10; bfd++) 
		counts[bfd] = 0;
	
	sprintf(b_ballots, "vote/%s.ballots", fh->filename);
	if ((bfd = open(b_ballots, O_RDONLY)) != -1) 
	{
	    	while (read(bfd, &inchar, 1) == 1) 
			counts[(int)(inchar - '0')]++;
	    	close(bfd);
	}

	sprintf(b_newresults, "vote/%s.newresults", fh->filename);
	sprintf(b_desc, "vote/%s.desc", fh->filename);

	if (tfp = fopen(b_newresults, "w")) 
	{
	    	int totvotes = 0;
	    	fprintf(tfp, "*****************************************\n\n");
	    	fprintf(tfp, "** �벼�����: %s\n", ctime(&endtime));
	    	fprintf(tfp, "** �����D�شy�z:\n\n");
	    	b_suckinfile(tfp, b_desc);
	    	fprintf(tfp, "** �벼���G:\n\n");

	    	if (cfp = fopen(b_temp, "r")) 
	    	{
			int	cindex;
			
			fgets(inbuf, sizeof(inbuf), cfp);
			while (fgets(inbuf, sizeof(inbuf), cfp)) 
			{
		    		inbuf[(strlen(inbuf) - 1)] = '\0';
		    		inbuf[43] = '\0'; /* truncate */
		    		cindex = inbuf[0] - '0';   
		    		fprintf(tfp, "    %-40s  %3d ��\n", inbuf + 3, counts[cindex]);
		    		totvotes += counts[cindex];
			}
			fclose(cfp);
	    	}
	    	fprintf(tfp, "\n�`���� = %d ��\n\n", totvotes);
	    	sprintf(b_results, "vote/%s.results", fh->filename);
	    	b_suckinfile(tfp, b_results);
	    	fclose(tfp);
	}
	else 
		return -1; /* couldn't write out the results! */

	unlink(b_results);
	rename(b_newresults, b_results);
	unlink(b_desc);
	unlink(b_temp);
	unlink(b_ballots);
	b_clearflags(fh);

	return 0;
}

int	b_vote_maintain(void)
{
	struct	stat	statb;
	FILE	*fp;
	char	inbuf[STRLEN],
		buf[STRLEN],
		*newline,
		r_buf[STRLEN];
	int	numselections = 0,
		aborted,
		pos;
	time_t	closetime,
		numseconds;
	bhd	fh;

	if (!(pos = search_board(&fh,currboard)))
		return -1;
	
	if (!HAS_PERM(PERM_SYSOP) && !HAS_PERM(PERM_BOARDS) && !islocalbm())
	{
		bell(1);
		return 0;
	}

	clear();
	move(0,0);
	prints(YEA, "�}�ҧ벼�c");
	move(2,0);
	sprintf(buf, "vote/%s.control", currboard);

	if ((fp = fopen(buf, "r")) != NULL) 
	{
		fgets(inbuf, sizeof(inbuf), fp);
		fclose(fp);
		closetime = (time_t)atol(inbuf);
		prints(NA, "�w�}�ҤF�벼�c, �P�ɶ����L�k�|���ӥH�W���벼�C\n");
		prints(NA, "�����벼�w�p������: %s", ctime(&closetime));
		pressreturn();
		return FULLUPDATE;
	}

	prints(NA,"������}�l�s�覹�� [�벼���y�z]: \n");
	igetch();
	sprintf(buf, "vote/%s.desc", currboard);
	aborted = vedit(buf, NA);

	if (aborted) 
	{
	   	clear();
	   	prints(NA, "���������벼\n");
	   	pressreturn();
	   	return FULLUPDATE;
	}

	sprintf(buf, "vote/%s.control", currboard);
	fp = fopen(buf, "w");
	clear();
	getdata(0,0,"�����벼�Ҷ��Ѽ� (���i����): ",inbuf, 4, DOECHO, YEA);
	
	if (*inbuf == '\n' || !strcmp(inbuf, "0") || *inbuf == '\0')
		strcpy(inbuf, "1");

	numseconds = atof(inbuf) * 86400.0;
	time(&closetime);
	closetime += numseconds;
	fprintf(fp, "%lu\n", closetime);
	fflush(fp);

	while (!aborted) 
	{
	   	getdata(numselections + 1,0,"��J�i��ܶ� (�Y����, �� ENTER): ",
			 inbuf, 40, DOECHO, YEA);

	   	if (*inbuf) 
		{
			if (numselections == 9)
				numselections = 0;
	      		else
	      			numselections++;
	      		fprintf(fp, "%1d) %s\n", numselections, inbuf);
	   	}

	   	if (*inbuf == '\0' || numselections == 0)
	      		aborted = 1;
	}

	fclose(fp);
	fh.flag |= BHD_VOTEING;
	b_clearflags(&fh);

        if (substitute_record(BOARDS, (char *)&fh, sizeof(fh), pos) == -1)
             prints(NA,"Error updating BOARDS file...\n");

	prints(NA,"�벼�c�}�ҤF�I\n");
	pressreturn();

	return NEWDIRECT;
}

int	b_vote(void)
{
	FILE	*cfp;
	int	pos;
	bhd	fh;
	char	inbuf[80],
		buf[80],
		choices[10],
		vote[2];
	int	fd,
		count = 0;
	time_t	closetime;

	b_closepolls();
	move(3,0);
	sprintf(buf, "vote/%s.control", currboard);

	if ((cfp = fopen(buf, "r")) == NULL)
	{
		prints(NA,"��p, �ثe�èS������벼�|��C\n");
		clrtobot();
		pressreturn();
		clear();

		return FULLUPDATE;
	}

	if (!(pos = search_board(&fh,currboard)))
	{
                clrtoeol();
		return FULLUPDATE;
        }

	if (fh.accessed[usernum] & VOTED)
	{
		prints(NA, "�����벼, �A�w��L�F!\n");
		prints(NA, "�@�H�@��, �j�a�����C\n");
		clrtobot();
		pressreturn();
		clear();

		return FULLUPDATE;
	}

	changemode(VOTING, NA);
	sprintf(buf, "vote/%s.desc", currboard);
	more(buf , YEA);
	clear();
	move(0, 0);
	prints(YEA, "THE BALLOT");
	move(2, 0);
	prints(NA, "�벼�覡: ���A�T�w�n�A����ܫ�, ��J��Ʀr�N�X�Y�i;\n");
	prints(NA, "����L������벼�C\n");
	fgets(inbuf, sizeof(inbuf), cfp);
	closetime = (time_t)atol(inbuf);
	prints(NA, "�����벼�N������: %s\n", ctime(&closetime));		
	move(6, 0);
	bzero(choices, sizeof(choices));

	while (fgets(inbuf, sizeof(inbuf), cfp) != NULL)
	{
		choices[count++] = inbuf[0];
		prints(NA, "%s", inbuf);
	}

	fclose(cfp);
	vote[0] = vote[1] = '\0';
	getdata(count+8, 0, "��J�A�����: ", vote, 2, DOECHO, YEA);
	move(count+10, 0);

	if (vote[0] == '\0' || (char *)index(choices, vote[0]) == NULL)
		prints(NA, "���X�k�����, �벼�����C\n");
	else
	{
		sprintf(buf, "vote/%s.ballots", currboard);

                if ((fd = open(buf, O_WRONLY|O_CREAT|O_APPEND, 0600)) == 0)
                        prints(NA, "Can't open the ballot box! Aborting...\n");
		else
		{
			struct	stat	statb;

			flock(fd, LOCK_EX);
			write(fd, vote, 1);
			flock(fd, LOCK_UN);
			fstat(fd, &statb);
			close(fd);
			fh.accessed[usernum] |= VOTED;
			if (substitute_record(BOARDS, (char *)&fh, sizeof(fh),
				pos) == -1)
				prints(NA, "Error updating BOARDS file...\n");
			prints(NA, "�w��J�벼�c��! (�ثe�w�벼��: %d)\n",
				statb.st_size);
		}
	}
	pressreturn();
	changemode(XMENU, NA);
	clear();

	return NEWDIRECT;
}

int	b_results(void)
{
	char	buf[STRLEN];
	int	closepoll;

	if (closepoll = !b_closepolls());

	sprintf(buf, "vote/%s.results", currboard);

	if (more(buf, YEA) == -1) 
	{
		move(3,0);
		prints(NA, "�ثe�S������벼�����G�C\n");
		clrtobot();
		pressreturn();
	}
	else 
		clear();

	if (closepoll)
		return NEWDIRECT;
	else
		return FULLUPDATE;
}
#endif
