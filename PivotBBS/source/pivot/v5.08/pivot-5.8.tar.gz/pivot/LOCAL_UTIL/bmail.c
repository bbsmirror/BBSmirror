/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/*
 * Filename: mailbbs.c
 * Wrter   : kftseng@bbs.nchu.edu.tw
 * Date    : 1994.9.2
 * Version : pivot bbs 4.0
 *
 * Usage   : mailbbs �e��H �e��H�ƦW ����a�} ��ƨӷ�
 *
 * Example : mailbbs SYSOP NICK kftseng@bbs.nchu.edu.tw afile
 */

#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <pwd.h>
#include <netdb.h>
#include <stdio.h>
#include "define.h"
#include "config.h"

void main(argc, argv)
int argc;
char **argv;
{
	char sender[80], info[80], receive[160], source[80], buf[256];

	if(argc != 5)
	{
		printf("���{���M�� bbs �e�H�ϥ�:\n");
		printf("Usage:\n");
		printf("	%s sender nick receive message_source\n", argv[0]);
		exit(0);
	}
	strncpy(sender, argv[1], 80);
	strncpy(info, argv[2], 80);
	strncpy(receive, argv[3], 160);
	strncpy(source, argv[4], 80);

	if(!parsemail(sender, info, receive, source)) {
		sprintf(buf,"/usr/lib/sendmail -oQ%s -q", BBSMAILDIR);
		system(buf);
	}
}

void spacestozeros(s)
char *s;
{
        while(*s)
	{
        	if(*s == ' ')
			*s = '0';
        	s++;
        }
}

int getqsuffix(s)
char *s;
{
        struct stat stbuf;
        char qbuf[STRLEN], dbuf[STRLEN]; 
        char c1 = 'A', c2 = 'A';
        int pos = strlen(BBSMAILDIR) + 3;

        sprintf(dbuf, "%s/dfAA%5d", BBSMAILDIR, getpid());
        sprintf(qbuf, "%s/qfAA%5d", BBSMAILDIR, getpid());

        spacestozeros(dbuf);
        spacestozeros(qbuf);

        while(1) {
        	if(stat(dbuf, &stbuf) && stat(qbuf, &stbuf))
			break;
        	if(c2 == 'Z')
		{
                	c2 = 'A'; 
                	if(c1 == 'Z')
				return -1;
			else
				c1++;
        		dbuf[pos] = c1;
        		qbuf[pos] = c1;
        	}
        	else
			c2++;
        	dbuf[pos+1] = c2;
        	qbuf[pos+1] = c2;
        }
        strcpy(s, &(qbuf[pos]));
        return 0;
}

int createqf(sender, info, receive, src, qsuffix)
char *sender, *info, *receive, *src, *qsuffix;
{
        static int configured = 0;
        static char myhostname[STRLEN];
        static char myusername[20];
        char mytime[STRLEN];
	char title[STRLEN];
        char idtime[STRLEN];
        char qfname[STRLEN];
        char t_offset[6];
        FILE *qfp;
        time_t timenow;
        int savehour;
        struct tm *gtime, *ltime;
        struct hostent *hbuf;
        struct passwd *pbuf;

        if(!configured)
	{
        	/* get host name */
        	gethostname(myhostname, STRLEN); 
        	hbuf = gethostbyname(myhostname);
        	if(hbuf)
			strncpy(myhostname, hbuf->h_name, STRLEN);

		/* get bbs uident */
        	pbuf = getpwuid(getuid());
        	if(pbuf)
			strncpy(myusername, pbuf->pw_name, 20);
        	if(hbuf && pbuf)
			configured = 1;
        	else
			return -1; 
        }

        /* get file name */
        sprintf(qfname, "%s/qf%s", BBSMAILDIR, qsuffix);
	if((qfp = fopen(qfname, "w")) == NULL)
        	return -1;

        /* get time */
        time(&timenow);
        ltime = localtime(&timenow);

        strftime(mytime, sizeof(mytime), "%a, %d %b %Y %T ", ltime);

        savehour = ltime->tm_hour;
        gtime = gmtime(&timenow);

        strftime(idtime, sizeof(idtime), "%Y%m%d%y%H%M", gtime);

        savehour = ltime->tm_hour;
        gtime = gmtime(&timenow);
        strftime(idtime, sizeof(idtime), "%Y%m%d%y%H%M", gtime);
        convert_tz(savehour, gtime->tm_hour, t_offset);
        strcat(mytime, t_offset);

        fprintf(qfp, "P1000\nT%lu\nDdf%s\nS%s.bbs\nR%s\n", timenow, qsuffix,
                sender, receive);
#ifdef ERRORS_TO
        fprintf(qfp, "E%s\n", ERRORS_TO);
#endif
        /* do those headers! */
        fprintf(qfp, "HReceived: by %s (%s)\n\tid %s; %s\n",
                myhostname, VERSION_ID, qsuffix, mytime);
        fprintf(qfp, "HReturn-Path: <%s.bbs@%s>\n", sender, myhostname);
        fprintf(qfp, "HDate: %s\n", mytime);
        fprintf(qfp, "HMessage-Id: <%s.%s@%s>\n", idtime, qsuffix,
                myhostname);
        fprintf(qfp, "HFrom: %s.bbs@%s (%s)\n", sender, myhostname, info);
        fprintf(qfp, "HSubject: %s (fwd)\n", title);
        fprintf(qfp, "HTo: %s\n", receive);
        fprintf(qfp, "HX-Forwarded-By: %s (%s)\n", sender, info);
        fprintf(qfp, "HX-Disclaimer: %s is not responsible for the contents of this message.\n",BBSNAME);
        fclose(qfp);
        return 0;
}

parsemail(sender, info, receive, src)
char *sender, *info, *receive, *src;
{
        char dfname[STRLEN];
        char fname[STRLEN];
        char qsuffix[STRLEN];

        if(getqsuffix(qsuffix) == -1)
		return -1;
	sprintf(dfname, "%s/df%s", BBSMAILDIR, qsuffix);
	link(src, dfname);
        return(createqf(sender, info, receive, src, qsuffix));
}

convert_tz(local, gmt, buf)
int gmt, local;
char *buf;
{
	local -= gmt;
	if (local < -11) local += 24;
	else if (local > 12) local -= 24;
	sprintf(buf, " %4d", abs(local * 100));
	spacestozeros(buf);
	if (local < 0) buf[0] = '-';
	else if (local > 0) buf[0] = '+';
	else buf[0] = '\0';	
}

