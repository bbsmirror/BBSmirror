/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)talk.c   5.08 3/19/95 (C) 1993 University of \
NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include "bbs.h"

#ifdef REALINFO 
int	real_user_names = 0;
#endif

usinfo	ui;
char	page_requestor[STRLEN],
	talkwith[STRLEN],
	talkobuf[STRLEN];
int	talkobuflen,
	talkflushfd,
	idle_monitor_time,
	page = 1,
	maxpage;

void	show_plan(flag, whopage, output)
int	flag;
char	*whopage;
void	(*output)();
{
	FILE	*planfile;
	char	genbuf[STRLEN],
		inbuf[256],
		*newline;
	int	i;
	usinfo	uin;
	if (flag)
	{
		move(1, 0);
		clrtobot();
	}
	i = search_record(PASSFILE, (char *)&muser, sizeof(muser), cmpuids,
		(int)whopage);

	(*output)(NA, "%s (%.15s), %d logins, %d posts. ", muser.userid,
#ifdef  REALINFO
		((muser.userset >> 3) & 1) ? muser.realname :
#endif
		muser.username, muser.numlogins,
		muser.numposts);
#ifdef QUERY_EMAIL
	(*output)(NA, "(%d) %s\n", i, chkmails(muser, YEA) ? "���s�H��Ū!" :
		"�S������s�H��!!");
	chkmails(cuser, YEA);
#endif
	strcpy(genbuf, ctime(&(muser.lastlogin)));

	if (newline = (char *)index(genbuf, '\n'))
		*newline = '\0';

	(*output)(NA, "Last login %s from %s [%s]\n", genbuf,
		(muser.lasthost[0] == '\0' ? "(unknown)" :
		muser.lasthost), ( search_ulist( &uin,
		 cmpuids,(int)&muser.userid) ? "�ثe�b���W" : "�^�a��ı�F" ) );


	if (HAS_PERM(PERM_BASIC))
	sprintf(genbuf, PATH_PLAN, muser.userid);

	if ((planfile = fopen(genbuf, "r")) == NULL)
		(*output)(NA, "No plan.\n");
	else
	{
		(*output)(NA, "Plan:\n\n");

		for (i = 1; i <= MAXQUERYLINES; i++) 
		{
			if (fgets(inbuf, sizeof(inbuf), planfile))
		    		(*output)(NA, "%s", inbuf);
			else 
				break;
	    	}
	    	fclose(planfile);
	}
}

void	talk_request(void)
{
	char	nowx,
		nowy;

        talkrequest = YEA;

	if (!isalpha(page_requestor[0]))
		setpagerequest();
        bell(15);
        return;
}

#ifdef LIST_IDLE_TIME
char	*list_idle(uentp)
usinfo	*uentp;
{
	time_t	now,
		diff;
	struct	stat	buf;
	static	char	buff[STRLEN];

	if ((stat(uentp->ttyname, &buf) != 0) ||
		strstr(uentp->ttyname, "tty") == NULL)
		return "����";

	time(&now);
	diff=now-buf.st_atime;
#ifdef DOTIMEOUT
	if ((diff > USER_TIMEOUT) && (diff < 60*60*24*5))
		kill(uentp->pid, SIGHUP);
#endif
	sprintf(buff, "%5d", (diff/60)%60);
	return buff;
}
#endif

int	ishidden(user)
char	*user;
{
	int	tuid;
	char	gb[BUFSIZE];
	userec	saverec;
	usinfo	uin;

	bcopy(gb, &saverec, sizeof(saverec));
	if (!(tuid = getuser(user)))
		return 0;
	search_ulist(&uin, t_cmpuids, tuid);
        bcopy(&saverec, gb, sizeof(saverec));
	return(uin.invisible);
}	

char	*modestring(mode, towho, complete, chatid)
int	mode,
	towho,
	complete;
char	*chatid;
{
	static	char	modestr[STRLEN];
	userec	urec;

	if (chatid) 
	{
		if (mode == TALK &&
			(!HAS_PERM(PERM_SEECLOAK) && ishidden(chatid)))
			return (ModeType(TMENU));
		sprintf(modestr, "%s: %s", ModeType(mode), chatid);
		return(modestr);
	}
	else
		return (ModeType(mode));

	if (mode != TALK && mode != PAGE && mode != QUERY)
		return (ModeType(mode));

	return (modestr);
}

char	pagerchar(me, them, pager, allpager)
char	*me,
	*them;
int	pager,
	allpager;
{
	if (!allpager)
		return '#';
	return ((pager) ? ' ' : (can_override(them, me) ? 'O' : '*'));
}

void	user_list_title()
{
	move(3, 0);
	clrtoeol();
	prints(YEA, "[1;32;44m%-12.12s %-15.15s %-16.16s %c %c %-16.16s%6s%6s [m\n",
		"�ϥαb��", (real_user_names == 2) ? "�b���ǽX" : (
#ifdef	REALINFO
		(real_user_names == 1) ? "�u��m�W" :
#endif
		"�ʦW�ٸ�"), "�Ӧۦ��", 'P',
		(HAS_PERM(PERM_SEECLOAK) ? 'C' : ' '), "�ثe�ʺA", "PID",
#ifdef LIST_IDLE_TIME
		"���m");
#else
		"");
#endif
	clrtobot();
}

char	*itoa(number)
int	number;
{
	static	char	str[33];

	sprintf(str, "%d", number);

	return	str;
}

void	user_list_uentp(uentp)
usinfo	*uentp;
{
	prints(NA, "%-12.12s %-15.15s %-16.16s %c %c %-16.16s %5d %4s\n",
		uentp->userid,
		(real_user_names == 2) ? itoa(uentp->uid) : (
#ifdef	REALINFO
		(real_user_names == 1) ? uentp->realname :
#endif
		uentp->username), uentp->from, pagerchar(cuser.userid,
		uentp->userid, uentp->pager, uentp->allpager),
		(uentp->invisible ? '#' : ' '), modestring(uentp->mode,
		uentp->destuid, 1, (uentp->comp ? uentp->ptcb : NULL)),
		uentp->pid,
#ifdef LIST_IDLE_TIME
                list_idle(uentp));
#else
                "");
#endif
}

int	printcuent(uentp)
usinfo	*uentp;
{
	userec	utmp;
	static	int	i;

	if (uentp == NULL) 
	{
		user_list_title();
		i = 3;
		return 0;
	}
	if (!uentp->active || !uentp->pid || (!HAS_PERM(PERM_SEECLOAK) 
		&& uentp->invisible) || (kill(uentp->pid, 0) == -1))
		return 0;

	if (i == 22) 
	{
		int	ch;

		prints(YEA, "[1;32;44m%-79s[m", "--MORE--");
		clrtoeol();

		while ((ch = igetkey()) != EOF) 
		{
			if (ch == '\n' || ch == '\r' || ch == ' ' ||
				ch == KEY_RIGHT)
				break;

			if (ch == 'q' || ch == CTRL('C') || ch == CTRL('D') ||
				ch == KEY_LEFT) 
			{
			         move(23, 0);
			         clrtoeol();
			         return QUIT;
			}
			bell(1);
		}
		user_list_title();
		i = 3;
		clrtobot();
	}
	user_list_uentp(uentp);
	i++;

	return 0;
}

int	listcuent(uentp)
usinfo	*uentp;
{
	userec	utmp;

	if (uentp == NULL) 
	{
		CreateNameList();
		return 0;
	}

	if ((uentp->uid == usernum) || (!uentp->active || !uentp->pid) ||
		(uentp->mode == ULDL) || (!HAS_PERM(PERM_SEECLOAK) &&
		uentp->invisible) || (kill(uentp->pid, 0) == -1))
		return 0;

	AddNameList(uentp->userid);

	return 0;
}

void	creat_list(void)
{
	listcuent(NULL);
	apply_ulist( listcuent );
}

int	t_users(void)
{
	int	savemode = uinfo.mode;
	
	move(3, 0);
	clrtoeol();
	changemode(LUSERS, NA);

	printcuent(NULL);
	
	if ( apply_ulist( printcuent ) == -1) 
	{
		prints(NA, "No Users Exist\n");
		pressreturn();
		changemode(TMENU, NA);
		return 0;
	}
	clrtobot();
	pressreturn();
	changemode(savemode, NA);
	return 0;
}

#ifdef REALINFO
int	t_rusers(void)
{
	real_user_names = 1;
	t_users();
	real_user_names = 0;
}
#endif

int	t_pager(void)
{
	int	ans;
	char	askbuf[STRLEN];

	if (uinfo.pager)
		strcpy(askbuf, uinfo.allpager ? PAG_OFF_OFF : PAG_OFF_ON);
	else
		strcpy(askbuf, uinfo.allpager ? PAG_ON_OFF : PAG_ON_ON);
	ans = getans(2, 0, askbuf, uinfo.pager ? 'c' : 'o');
	if (ans == 'e')
		return -1;
	if (ans == 'a')
	{
		SWITCH_SET(SET_ALLPAGER);
		uinfo.allpager = !HAS_SET(SET_ALLPAGER);
	}
	else
	{
		SWITCH_SET(SET_PAGER);
		uinfo.pager = !HAS_SET(SET_PAGER);
	}
	move(2, 0);
	prints(NA, PAG_CURR, uinfo.pager ? "ON" : "OFF",
		uinfo.allpager ? "ON" : "OFF");
	changemode(uinfo.mode, uinfo.comp);
	return 0;
}

int	t_numb(void)
{
	real_user_names = 2;
	t_users();
	real_user_names = 0;
}

int	t_query(void)
{
	char	uident[STRLEN];
	int	tuid,
		i,
		savemail;
	
	changemode(QUERY, NA);

	if (!HAS_SET(SET_USERLIST))
	{
		move(2, 0);
		prints(NA, "<Enter Userid>\n");
		move(1, 0);
		clrtoeol();
		prints(NA, "Query who: ");
		u_namelist();
		namecomplete(NULL, uident);
		if (uident[0] == '\0') 
		{
			changemode(TMENU, NA);
			return 0;
		}
		if (!(tuid = getuser(uident))) 
		{
			move(2, 0);
			prints(NA, "Bad User ID\n");
			changemode(TMENU, NA);
			return -1;
		}
	}
	else
	{
		if ((tuid = i_userid(2, USER_OLD, uident)) < 0)
		{
			return 0;
		}
	}

	strncpy(uinfo.ptcb, uident, 20);
	clear();
	prints(NA, "[�լd���ͨ����P�������(%d)]\n", tuid);
	uinfo.destuid = tuid;
	changemode(QUERY, YEA);
	show_plan(YEA, uident, prints);
	pressreturn();
        uinfo.destuid = 0;
	bzero(uinfo.ptcb, sizeof(uinfo.ptcb));
	changemode(TMENU, NA);
}		

#ifdef FLAG_MAIN_L
int	dumb_list(uentp)
usinfo	*uentp;
{
	userec		utmp;

	if (uentp == NULL) 
	{
#ifdef BOARDNAME
		if (bfinger) 
		{
			sprintf(genbuf, "\n[%s]\n\n", BOARDNAME);
			write(1, genbuf, strlen(genbuf));
		}
#endif
		sprintf(genbuf, "%-14s %-25s %-10s %-10s %-16s\n",
			"�ϥαb��", "�ʦW�ٸ�", "�׺ݾ�", "�ʺA", "�ӷ�");
		write(1, genbuf, strlen(genbuf));
		return 0;
	}

	if (!uentp->active || !uentp->pid)
		return 0;

	if (kill(uentp->pid, 0) == -1)
		return 0;

	if (bfinger && uentp->invisible) return 0;
	sprintf(genbuf, "%-14.14s %-25.25s %-10.10s %-10.10s %s\n",
		uentp->userid, uentp->username, uentp->termtype,
		modestring(uentp->mode, uentp->destuid, 0, NULL), uentp->from);
	write(1, genbuf, strlen(genbuf));

	return 1;
}

void	dumb_user_list(void)
{
	dumb_list(NULL);

	if ( apply_ulist( dumb_list ) == -1) 
		write(1, "No Users Exist\n", 15);

	if (bfinger)
		write(1, "\n", 1);
}
#endif

#ifdef FLAG_MAIN_A
int	do_all_list(uentp)
usinfo	*uentp;
{
	if (uentp == NULL) 
	{
		printf("%-14s %-25s %-10s\n", "�ϥαb��", "�ʦW�ٸ�",
			"�׺ݾ�");
		return 0;
	}

	if ((kill(uentp->pid, 0) == -1) || (uentp->username[0] == '\0'))
		return 0;

	printf("%-14.14s %s", uentp->userid, ctime(&(uentp->lastlogin)));
	printf("%-14.14s %-25.25s %-10.10s %-9.9s %-16.16s %-6.6s\n",
		uentp->userid, uentp->username, uentp->termtype,
		ModeType(uentp->mode), uentp->from, (uentp->active) ?
		"ACTIVE" : "");

	return 1;
}

void	list_all_users(void)
{
	uinfo.mode = LAUSERS;  
	do_all_list(NULL);
	if ( apply_ulist( do_all_list ) == -1)
		printf("No Users Exist");
}   
#endif /* FLAG_MAIN_A */

int	count_active(uentp)
usinfo	*uentp;
{
	userec	utmp;
	static	int	count;

	if (uentp == NULL) 
	{
      		int	c = count;
      		count = 0;

      		return c;
    	}

    	if (!uentp->active || !uentp->pid || kill(uentp->pid, 0) == -1) {
		bzero(uentp,sizeof(usinfo));
      		return 0;
	}

#ifdef	NOCOUNT_MULTI
    	if (uentp->userlevel & PERM_MULTILOG)
		return 0; /* don't count multiloggers */
#endif
    	count++;

    	return 1;
}

int	num_active_users(void)
{
	count_active(NULL);
	apply_ulist( count_active );

	return count_active(NULL);
}

int	t_cmpuids(uid, up)
int	uid;
usinfo	*up;
{
	return (uid == up->uid);
}

int	t_cmppids(tpid, up)
int	tpid;
usinfo	*up;
{
	return (tpid == up->pid);
}

int	t_talk(void)
{
        char	uident[STRLEN],
		inbuf[256];
        int	tuid,
		tpid,
		i;
        usinfo	uin;
	FILE	*planfile;

        move(2, 0);
        prints(NA, "<Enter Userid>\n");
        move(1, 0);
        clrtoeol();
        prints(NA, "To: ");
        creat_list();  
        namecomplete(NULL, uident);

        if (uident[0] == '\0') 
	{
                clear();
                return 0;
        }
	tuid = getuser(uident);

        if (!tuid || tuid == usernum) 
	{
                move(2, 0);
                prints(NA, "Bad User ID\n");
                pressreturn();
                move(2, 0);
                clrtoeol();
                return -1;
        }
#if	defined(ALLOW_MULTI_LOGINS) || defined(PERM_MULTILOG)
	if ((tpid=select_multipid(tuid, sizeof(uin))) == -1)
		return -1;
	if (tpid>0)
		search_ulist(&uin, t_cmppids, tpid);
#else
        search_ulist( &uin, t_cmpuids, tuid);
#endif

        if (!HAS_PERM(PERM_SYSOP))
	{
        	if (uin.pager == NA && !can_override(uin.userid, cuser.userid))
		{ 
                	move(2, 0);
                	prints(NA, TALK_PAGEROFF);
                	return -1;
            	}
		if (uin.allpager == NA)
		{
			move(2, 0);
			prints(NA, TALK_ALLPAGEROFF);
			return -1;
		}
        }
        if (uin.mode >= 150) 
	{
                move(2, 0);
                prints(NA, TALK_CANNOTPAGE);
                return -1;
        }
        if (uin.pid == 0) 
	{
                move(2, 0);
                prints(NA, TALK_ERRORPID);
		return -1;
        }
        if (!uin.active || (kill(uin.pid, 0) == -1)) 
	{
                move(2, 0);
                prints(NA, TALK_LOGOUT);
                return -1;
        }
	else
	{
                int	sock,
			msgsock,
			length;
                struct	sockaddr_in	server;
                char	c,
                	buf[512];

                sock = socket(AF_INET, SOCK_STREAM, 0);

                if (sock < 0) 
		{
                        perror("opening stream socket\n");
                        return -1;
                }

                server.sin_family = AF_INET;
                server.sin_addr.s_addr = INADDR_ANY;
                server.sin_port = 0;

                if (bind(sock, (struct sockaddr *)&server, sizeof(server)) < 0)
		{
                        perror("binding stream socket");
                        return -1;
                }
                length = sizeof server;
                if (getsockname(sock, (struct sockaddr *)&server, &length) < 0)
		{
                        perror("getting socket name");
                        return -1;
                }

                uinfo.sockactive = YEA;
                uinfo.sockaddr = server.sin_port;
                uinfo.destuid = tuid;
		strcpy(uinfo.ptcb, uident);
		changemode(PAGE, YEA);

                kill(uin.pid, SIGUSR1);
                clear();
		show_plan(YEA, uinfo.ptcb, prints);
		move(0, 0);
                prints(NA, TALK_PAGETRYING, uident);

                listen(sock, 1);
                add_io(sock, 8);

                while (YEA) 
		{
                        int	ch;

#if defined(POSIX) || defined(LINUX)
			add_io(sock, 8);
#endif
                        ch = igetch();
                        if (ch == I_TIMEOUT) 
			{
                                move(0, 0);
				clrtoeol();
                                prints(NA, TALK_PAGEAGAIN);
                                bell(1);

                                if (kill(uin.pid, SIGUSR1) == -1) 
				{
                                        move(0, 0);
                                        prints(NA, TALK_LOGOUT);
                                        pressreturn();
                                        uinfo.mode = TMENU;
					update_utmp();
                                        return -1;
                                }
                                continue;
                        }

                        if (ch == I_OTHERDATA)
                        	break;

                        if (ch == '\004') 
			{
                        	add_io(0, 0);
                        	close(sock);
                        	uinfo.sockactive = NA;
                        	uinfo.destuid = 0;
				bzero(uinfo.ptcb, sizeof(uinfo.ptcb));
				changemode(TMENU, NA);
                        	clear();
                        	return 0;
                        }
                }

                msgsock = accept(sock, (struct sockaddr *)0, (int *) 0);
                if (msgsock == -1) 
		{
                        perror("accept");
                        uinfo.mode = TMENU;
			update_utmp();
                        return -1;
                }
                add_io(0, 0);
                close(sock);

                uinfo.sockactive = NA;
                read(msgsock, &c, sizeof c);

                if (c == 'y' || c == 'Y') 
		{
			strcpy(talkwith, uin.userid);
                	do_talk(msgsock);
                }
		else
		{
                	clear();
                	prints(NA, TALK_PAGE_REJECT);
                	pressreturn();
                }

                close(msgsock);
                clear();
                uinfo.destuid = 0;
		bzero(uinfo.ptcb, sizeof(uinfo.ptcb));
		changemode(TMENU, NA);
        }

        return 0;
}

int	cmpunums(unum, up)
int	unum;
usinfo	*up;
{
	if (!up->active)
		return 0;

	return ((unum == up->destuid) && (up->mode == PAGE));
}

int	searchuserlist(unum)
{
	return search_ulist(&ui, cmpunums, unum);
}

int	setpagerequest(void)
{
	int	tuid;
	usinfo	au;

	tuid = searchuserlist(usernum);
	if (tuid == 0 || !ui.sockactive)
		return 1;

	uinfo.destuid = ui.uid;

	strcpy(page_requestor, ui.userid);
	return 0;
}

void	talk_info(line, talkto)
int	line;
char	*talkto;
{
	int	j;
	char	pagebuf[STRLEN],
		genbuf[STRLEN];

    	move(line, 0);

    	for(j =0; j <= 78; j++)
       		prints(NA, "=");

	sprintf(pagebuf, TALK_CURR_ALLPAGER, uinfo.allpager ? "ON" : "OFF");
	if (talkrequest)
		sprintf(genbuf, TALK_NEWPAGER, page_requestor);
	else
		sprintf(genbuf, TALK_TALKWITH, talkto);
	strcat(pagebuf, genbuf);
	sprintf(genbuf, TALK_CURR_PAGER, uinfo.pager ? "ON" : "OFF");
	strcat(pagebuf, genbuf);
	move(line, (79 - strlen(pagebuf))/2);
    	prints(NA, "%s", pagebuf);
	refresh();
}

int	servicepage(arg, talkto)
int	arg;
char	*talkto;
{
	static	time_t	last_check;
	time_t	now;
	char	buf[STRLEN];
        int	tuid = searchuserlist(usernum);

        if (tuid == 0 || !ui.sockactive)
		talkrequest = NA;

        if (!talkrequest)
	{
        	if (page_requestor[0])
		{
			switch (uinfo.mode)
			{
	      			case BMCHAT:
				case CHAT1:
				case CHAT2: /* a chat mode */
					sprintf(buf, TALK_PAGESTOP,
						page_requestor);
                			printchatline(NA, buf);
					break;
	      			default:
					talk_info(arg, talkto);
					break;
	    		}
            		bzero(page_requestor, STRLEN);
            		last_check = 0;
          	}
	  	return NA;
        }
        else 
	{
        	now = time(0);
        	if (now - last_check > P_INT) 
		{
            		last_check = now;
            		if (!page_requestor[0] && setpagerequest())
	      			return NA;
            		else
	      			switch (uinfo.mode)
				{
					case BMCHAT:
					case CHAT1:
					case CHAT2: /* chat */
                  				sprintf(buf, TALK_PAGING,
							page_requestor);
                  				printchatline(NA, buf);
						break;
					default:
						talk_info(arg, talkto);
		  				break;
	      			}
          	}
        }
	return YEA;
}

int	talkreply(void)
{
	int	a,
		len;
	struct	hostent	*h;
	char	hostname[STRLEN],
		ans;
	struct	sockaddr_in	sin;

	talkrequest = NA;

	if (setpagerequest())
		return 0; 	

	strcpy(uinfo.ptcb, page_requestor);
	strcpy(talkwith, page_requestor);
	clear();
	show_plan(YEA, page_requestor, prints);
	move(0, 0);
	prints(NA, TALK_IFACCEPT, page_requestor);
	Getyn(&ans);
	bzero(page_requestor, sizeof(page_requestor));

	gethostname(hostname, STRLEN);

	if (!(h = (struct hostent *)gethostbyname(hostname))) 
	{
		perror("gethostbyname");
		return -1;
	}

	bzero(&sin, sizeof sin);
	sin.sin_family = h->h_addrtype;
	bcopy(h->h_addr, &sin.sin_addr, h->h_length);
	sin.sin_port = ui.sockaddr;
	a = socket(sin.sin_family, SOCK_STREAM, 0);

	if ((connect(a, (struct sockaddr *)&sin, sizeof sin))) 
	{
		perror("connect failed");
		return -1;
	}

	if (ans != 'n' && ans != 'N')
		ans = 'y';

	write(a, &ans, 1);

	if (ans != 'y') 
	{
		close(a);
  		clear();
		return 0;
	}

	do_talk(a);

	close(a);
	clear();

	return 0;
}

int	dotalkent(uentp, buf)
usinfo	*uentp;
char	*buf;
{
	char	mch;

	if (!uentp->active || !uentp->pid || (!HAS_PERM(PERM_SEECLOAK) &&
		uentp->invisible) || (kill(uentp->pid, 0) == -1))
	{
		 return -1;
	}

    	switch (uentp->mode) 
    	{
      		case ULDL:
           		mch = 'U';
			break;
      		case TALK:
           		mch = 'T';
			break;
      		case CHAT1:
		case CHAT2:
		case CHAT3:
	   		mch = 'C';
			break;
      		case BMCHAT:
           		mch = 'c';
			break;
      		case IRCCHAT:
			mch = 'I';
			break;
      		case FOURM: 
			mch = '4';
			break;
      		case BBSNET: 
			mch = 'B';
			break;
      		case READNEW: 
			mch = 'N';
			break;
      		case READING: 
			mch = 'R';
			break;
      		case POSTING: 
			mch = 'P';
			break;
      		case SMAIL: 
			mch = 's';
			break;
      		case RMAIL: 
			mch = 'r';
			break;
      		case MAIL: 
			mch = 'M';
			break;
      		default: 
			mch = '-';
    	}
    	sprintf(buf, "%s%s(%c), ", uentp->invisible?"*":"",
		uentp->userid, mch);

    	return 0;
}

/* mark */
 
int	dotalkuserlist(sline, eline, curln, curcol, wordbuf, wordbuflen)
int	sline,
	eline,
	*curln,
	*curcol,
	*wordbuflen;
char	*wordbuf;
{
    	char	*s = TALK_CURR_ONBBS,
    		bigbuf[STRLEN],
    		littlebuf[20];
    	int	fd,
		savecolumns,
		pos = 0,
		i;
    	usinfo	uent;

    	savecolumns = (t_columns > STRLEN ? t_columns : 0);
    	bigbuf[0] = '\0';


    	do_talk_string(sline, eline, curln, curcol, wordbuf, wordbuflen, s);

	resolve_utmp();
	for( i = 0; i < UTMP_SIZE; i++) {
		memcpy(&uent,&(utmpshm->utc[i]),sizeof(usinfo));
		if (dotalkent(&uent, littlebuf) == -1) 
			continue;
		if (pos + strlen(littlebuf) >= t_columns) {
	    		do_talk_string(sline, eline, curln, curcol,
				wordbuf, wordbuflen, bigbuf);
	    		bigbuf[0] = '\0';
	    		pos = 0;
        	}
		strcat(bigbuf, littlebuf);
		pos += strlen(littlebuf);
    	}

    	if (pos > 0) 
	{
		bigbuf[pos-2] = '\n';
        	bigbuf[pos-1] = '\0';
		do_talk_string(sline, eline, curln, curcol, wordbuf,
			wordbuflen, bigbuf);
    	}

    	if (savecolumns) 
		t_columns = savecolumns;        
}

void	do_talk_string(sline, eline, curln, curcol, wordbuf, wordbuflen, s)
int	sline,
	eline,
	*curln,
	*curcol,
	*wordbuflen;
char	*wordbuf,
	*s;
{
	while (*s) 
	{
		do_talk_char(sline, eline, curln, curcol, wordbuf, wordbuflen, *s);
		s++;
    	}
}
 
void	do_talk_char(sline, eline, curln, curcol, wordbuf, wordbuflen, ch)
int	sline,
	eline,
	*curln,
	*curcol,
	*wordbuflen,
	ch;
char	*wordbuf;
{
#ifdef BIT8
	if (isprint2(ch)) 
#else
	if (isprint(ch))
#endif
	{
	        if (*curcol != 79) 
		{
	        	wordbuf[(*wordbuflen)++] = ch;
            		if (ch == ' ')
              			*wordbuflen = 0;
            		move(*curln, (*curcol)++);
            		prints(NA, "%c", ch);
            		return;
        	}
        	if (ch == ' ' || *wordbuflen >=78) 
		{
            		(*curln)++;
            		*curcol = 0;
            		if (*curln > eline)
            			*curln = sline;
            		if ((*curln) != eline) 
			{
                		move((*curln)+1, 0);
                		clrtoeol();
            		}
            		move(*curln, *curcol);
            		clrtoeol();
            		*wordbuflen = 0;
            		return;
        	}
        	move(*curln, (*curcol) - *wordbuflen);
        	clrtoeol();
        	(*curln)++;
        	*curcol = 0;
        	if (*curln > eline)
        		*curln = sline;
        	if ((*curln) != eline) 
		{
            		move((*curln)+1, 0);
            		clrtoeol();
        	}
        	move(*curln, *curcol);
        	clrtoeol();
        	wordbuf[*wordbuflen] = '\0';
        	if (dumb_term)
          		prints(NA, "\n");
        	prints(NA, "%s%c", wordbuf, ch);
        	*curcol = (*wordbuflen)+1;
        	*wordbuflen = 0;
        	return;
    	}
    	switch (ch) 
	{
      		case CTRL('H'):
      		case '\177':
        		if (dumb_term)
          			ochar(CTRL('H'));
        		if (*curcol == 0) 
			{
            			if (sline == 0)
              				bell(1);
            			return;
        		}
        		(*curcol)--;
        		move(*curln, *curcol);
        		if (!dumb_term)
          			prints(NA, " ");
        		move(*curln, *curcol);
        		if (*wordbuflen)
          			(*wordbuflen)--;
        		return;
      		case CTRL('M'):
      		case CTRL('J'):
        		if (dumb_term)
          			prints(NA, "\n");
        		(*curln)++;
        		*curcol = 0;
        		if (*curln > eline)
          			*curln = sline;
        		if ((*curln) != eline) 
			{
        			move((*curln)+1, 0);
        			clrtoeol();
        		}
        		move(*curln, *curcol);
        		clrtoeol();
        		*wordbuflen = 0;
        		return;
      		case CTRL('G'):
        		bell(1);
        		return;
      		default:
        		break;
    	}
    	return;
}

int	talkflush(void)
{
    	if (talkobuflen) 
      		write(talkflushfd, talkobuf, talkobuflen);
    	talkobuflen = 0;
}

void	do_talk(fd)
int	fd;
{
    	int	lon,
		myln,
		mycol,
		myfirstln,
		mylastln,
		itsln,
		itscol,
		itsfirstln,
		itslastln,
    		itswordbuflen,
		mywordbuflen,
    		page_pending = NA,
		tolen =0,
		myid=0,
		savemode;
    	char	*p,
		itswordbuf[STRLEN],
		mywordbuf[STRLEN];
    
	talkrequest = NA;
	uinfo.comp = YEA;
	savemode = uinfo.mode;
	changemode(TALK, YEA);
    	itswordbuflen = 0;
    	mywordbuflen = 0;
    	talkobuflen = 0;
    	talkflushfd = fd;

	changemode(TALK, YEA);
    	clear();
    	myfirstln = 0;
    	mylastln = (t_lines-1)/2 - 1;

	talk_info(mylastln+1, talkwith);

    	itsfirstln = mylastln+2;
    	itslastln = (t_lines -1);
    	myln = myfirstln;
    	mycol = 0;
    	itsln = itsfirstln;
    	itscol = 0;
    	move(myln, mycol);
    	add_io(fd, 0);
    	add_flush(talkflush);

    	for(;;)
	{
        	int	ch,
			currx,
			curry;

		if (talkrequest) 
			page_pending = YEA;
		if (page_pending)
	  		page_pending = servicepage(mylastln+1, talkwith);
        	ch = igetch();

		if (ch == I_OTHERDATA) 
		{
            		char	data[STRLEN];
            		int	datac;
			int	i;

            		datac = read(fd, data, 80);
            		if (datac<=0) 
              			break;
            		for(i=0; i<datac; i++)
			{
              			do_talk_char(itsfirstln, itslastln, &itsln,
					&itscol, itswordbuf, &itswordbuflen,
					data[i]);
			}
		}
		else
		{
            		if (ch == CTRL('D') || ch == CTRL('C'))
              			break;
#ifdef BIT8
	    		if (isprint2(ch) || ch == CTRL('H') || ch == '\177' || 
				ch == CTRL('G')
#else
            		if (isprint(ch) || ch == CTRL('H') || ch == '\177' ||
				ch == CTRL('G')
#endif
               			|| ch == CTRL('M') || ch == CTRL('M')) 
			{
                		talkobuf[talkobuflen++] = ch;
                		if (talkobuflen == 80)
                  			talkflush();
                		do_talk_char(myfirstln, mylastln, &myln,
					&mycol, mywordbuf, &mywordbuflen, ch);
	    		}
	    		else if (ch == CTRL('U') || ch == CTRL('W'))
				dotalkuserlist(myfirstln, mylastln, &myln,
		 			&mycol, mywordbuf, &mywordbuflen);
            		else if (ch == CTRL('P') && HAS_PERM(PERM_BASIC))
			{
               			SWITCH_SET(SET_PAGER);
				uinfo.pager = !HAS_SET(SET_PAGER);
				update_utmp();
				getyx(&curry, &currx);
				talk_info(mylastln+1, talkwith);
				move(curry, currx);
            		}
			else if (ch == CTRL('A'))
			{
				SWITCH_SET(SET_ALLPAGER);
				uinfo.allpager = !HAS_SET(SET_ALLPAGER);
				update_utmp();
				getyx(&curry, &currx);
				talk_info(mylastln+1, talkwith);
				move(curry, currx);
			}	
            		else 
				bell(1);
		}
    	}
    	add_io(0, 0);
    	talkflush();
    	add_flush(NULL);
	uinfo.comp=NA;
	changemode(savemode, NA);
}

int	shortulist(uentp, f_lists, f_count)
usinfo	*uentp;			/*	userinfo	*/
char	*f_lists;		/*	�x�s friends ���r��}�C	*/
int	f_count;		/*	override �̪� friend �� */
{
	static	int	fullcount = 0,
			lineno = 0,
			cnt = 0;
	int	i,
		finaltally,
		notfriend = 1;	/*	�P�_���D�ͤH��, ��Ȭ� 1	*/
	char	uentry[30];

	if (!lineno) 
	{
		lineno = 3;
		move(lineno, 0);
	}
	if (uentp == NULL) 
	{
		clrtoeol();
		move(++lineno, 0);
		clrtobot();
		finaltally = fullcount;
		lineno = cnt = fullcount = 0;
		return finaltally;
	}
	uentry[0] = '\0';
	if (uinfo.mode == FMONITOR)
	{
		for( i=0; i<=f_count; i++)
		{
			if (!strcmp(uentp->userid, (f_lists+i*20)) )
				notfriend = 0;
		}
	}
	if ((!uentp->active || !uentp->pid) || (!HAS_PERM(PERM_SEECLOAK) &&
		uentp->invisible) || (kill(uentp->pid, 0) == -1 )
		|| ( (uinfo.mode==FMONITOR)?notfriend:0) )
		strcpy(uentry, " ");

	if (!uentry[0]) 
	{
		if ((uentry[0] != ' ') && (fullcount>=(page-1)*60) 
			&& (fullcount<=(page-1)*60+60-1)) 
		{
        		sprintf(uentry, "%-12.12s %c%-10.10s", uentp->userid,
				uentp->invisible ? '#' : ' ',
				modestring(uentp->mode, uentp->destuid, 1,
				(uentp->comp ? uentp->ptcb : NULL)));
			if (++cnt < 3)
				strcat(uentry, " : ");
			prints(NA, uentry);
		}
		fullcount++;
	}
	if (cnt == 3) 
	{
		cnt = 0;
		clrtoeol();
		if (++lineno <= t_lines)
       	        	move(lineno, 0);
	}
	return 0;
}

int	do_list(void)
{       
	int	count,
		f_count = 0,
		i;
        time_t	thetime;
	FILE	*fp;
	char	*nl,
		*lists,
		f_list[MAXACTIVE][20];

        move(2, 0);
        prints(YEA, "[1;32;44m%-12s  %-10s : %-12s  %-10s : %-12s  %-10s[m\n",
 	        "User ID", "Mode", "User ID", "Mode", "User ID", "Mode");
        if(uinfo.mode == FMONITOR)
        {
                sprintf(genbuf, PATH_OVERRIDE, cuser.userid);
                if ((fp = fopen(genbuf, "r")) == NULL)
                {
			clrtobot();
                        prints(NA, TALK_NOFRIEND);
                        return -1;
                }
		while (fgets(genbuf, STRLEN, fp) != NULL)
		{
                	if ((nl = (char *)strtok(genbuf, " \n\r\t")) != NULL)
			{
			strncpy(f_list[f_count] , genbuf, 20);
			f_count++;
			lists = f_list[0];
			}
		}
                fclose(fp);
	}
	for(i = 0;i <= UTMP_SIZE; i++) {
		if ( shortulist(&(utmpshm->utc[i]), lists, f_count) == QUIT) {
			prints(NA, "No Users Exist\n");
			return 0;
		}
	}
	count = shortulist(NULL, NULL, 0);

	if(uinfo.mode == FMONITOR && count == 0)
		prints(NA, TALK_CANT_FIND_FRIEND);

        thetime = time(0); 		
	if (uinfo.mode == MONITOR || uinfo.mode == FMONITOR) 
	{
		move(0, 60);
		if (chkmails(cuser,NA))
		    prints(NA, "(You have mail.)");
		else
			prints(NA, "%s", BoardName);
		move(1,0);
		clrtoeol();
		if(uinfo.mode == MONITOR)
			prints(NA,"�i�� f ��i��l�ܦn�Ϳù��j  ");
		else
			prints(NA,"�i�� m ��i�^��l�ܯ��Ϳù��j");
		move(1, 50);
		if (talkrequest)
			prints(NA, TALK_NEWPAGER, page_requestor);
		else
			clrtoeol();
		move(t_lines-1, 0);
	} 
	else
                move(1, 0);
	prints(NA, "[1;32;45m   �� (%2d/%2d) ��    %3d %s %-30s[m\n",
		page, maxpage, count, (uinfo.mode == FMONITOR)?
		"��n�ͦb���W  ��s�ɶ�:":"�H�b���W  ��s�ɶ�:", 
		Ctime(&thetime));
	if (dumb_term) 
		oflush();
	else 
		refresh();
}

int	t_list(void)
{
	uinfo.mode = LUSERS;
	update_utmp();
        move(0, 0);
        clrtobot();
	prints(NA, TALK_CURR_ONBBS);
	do_list();
	pressreturn();
	move(2, 0);
	clrtoeol();
        uinfo.mode = TMENU;
	update_utmp();
	return 0;
}

void	sig_catcher(void)
{
	if (uinfo.mode != MONITOR && uinfo.mode != FMONITOR) 
	{
#ifdef DOTIMEOUT
		init_alarm();
#else
		signal(SIGALRM, SIG_IGN);
#endif
		return;
        }		
	if (signal(SIGALRM, (void *)sig_catcher)==SIG_ERR) 
	{
		perror("signal");
		exit(1);
	}
#ifdef DOTIMEOUT
	idle_monitor_time += M_INT;
	if (idle_monitor_time > MONITOR_TIMEOUT) 
	{
		goodbye();
	}
#endif
	do_list();
	alarm(M_INT);
}

int	t_monitor(void)
{
	int	i,
		c;
	char	ch,
		maxpagech;

	alarm(0);
	signal(SIGALRM, (void *)sig_catcher);
	page=1;
	maxpage=(MAXACTIVE+60-1)/60;
	maxpagech=(char)(maxpage+060);
	idle_monitor_time = 0;

	changemode(MONITOR, NA);

	move(0, 0);
	clrtobot();
	prints(NA, TALK_MONITOR, M_INT);
	do_list();
	alarm(M_INT);
	while (YEA) 
	{
		c = igetkey();
		if (c == CTRL('D') || c == CTRL('C') || c == KEY_LEFT ||
			c == 'q' || c == 'Q')
			break;
	    	else
		{
			idle_monitor_time = 0;
			switch (c)
			{
	                        case KEY_DOWN:
        	                case KEY_RIGHT:
                	                if ((++page) <= maxpage)
					{
                        	                do_list();
                                	        alarm(M_INT);
                                	}
	                                else
						page=maxpage;
		                        break;
				case KEY_UP:
				case KEY_LEFT:
                                	if ((--page) >= 1)
					{
                                        	do_list();
                                        	alarm(M_INT);
                                	}
	                                else
						page = 1;
        	                        break;
				case 'f':
				case 'F':
					changemode(FMONITOR,NA);
					page = 1;		
					if(do_list() == -1)
					{
						changemode(MONITOR,NA);
					}
					alarm(M_INT);
					break;
				case 'm':
				case 'M':
					changemode(MONITOR,NA);
					page = 1;
					do_list();
					alarm(M_INT);
					break;
                	        default:        break;
			}
			if (c >= '1' && c <= maxpagech)
			{
				page = c - 48;
				do_list();
				alarm(M_INT);
			}
		}
	}
	move(2, 0);
	clrtoeol();
	changemode(TMENU, NA);
	return 0;
}

int	can_override(userid, whoasks)
char	*userid,
	*whoasks;
{
	FILE	*fp;
	char	buf[STRLEN];
	int	blen;

    	sprintf(buf, PATH_OVERRIDE, userid);
    	if ((fp = fopen(buf, "r")) == NULL)
		return 0;
    	while (fgets(buf, STRLEN, fp) != NULL) 
	{
        	blen = strlen(buf);
        	if (buf[blen-1] == '\n')
	    		buf[--blen] = '\0';
        	if (!strcmp(buf, whoasks)) 
		{
            		fclose(fp);
            		return 1;
        	}
    	}
   	fclose(fp);

    	return 0;
}

int	listfriends(void)
{
	FILE	*fp;
	int	x = 0,
		y = 3,
		cnt = 0;
	char	*nl;

	move(y, x);
	CreateNameList();
	sprintf(genbuf, PATH_OVERRIDE, cuser.userid);

	if ((fp = fopen(genbuf, "r")) == NULL) 
	{
		prints(NA, "(none)\n");
		return 0;
        }

	while (fgets(genbuf, STRLEN, fp) != NULL) 
	{
		prints(NA, "%s", genbuf);
		if (nl = (char *)rindex(genbuf, '\n')) 
			*nl = '\0';
	    	AddNameList(genbuf);
	    	cnt++;
            	if ((++y) >= t_lines-1) 
		{
			y = 3;
			x += 16;
            	}
		if( cnt == (t_lines-1-3)*5)
		{
			pressreturn();
			x = 0;
			move(y, x);
			clrtobot();
		}
	    	move(y, x);
	}

	fclose(fp);
	if (cnt == 0) 
		prints(NA, "(none)\n");
	return cnt;
}

int	addtooverride(uident)
char	*uident;
{
	FILE	*fp;
	int	rc;

	if (can_override(cuser.userid, uident)) 
		return -1;
	sprintf(genbuf, PATH_OVERRIDE, cuser.userid);
	if ((fp = fopen(genbuf, "a")) == NULL)
		return -1;
	flock(fileno(fp), LOCK_EX);
	rc = fputs(uident, fp);
	fputc('\n', fp);
	flock(fileno(fp), LOCK_UN);
	fclose(fp);
	return(rc == EOF ? -1 : 0);
}		

int	deleteoverride(uident)
char	*uident;
{
	FILE	*fp,
		*nfp;
	int	deleted = NA;
	char	fn[STRLEN],
		fnnew[STRLEN];

	sprintf(fn, PATH_OVERRIDE, cuser.userid);
	if ((fp = fopen(fn, "r")) == NULL) 
		return -1;
	sprintf(fnnew, PATH_MOVERRIDE, cuser.userid, getuid());
	if ((nfp = fopen(fnnew, "w")) == NULL) 
		return -1;
	while (fgets(genbuf, STRLEN, fp) != NULL) 
	{
		if (strncmp(genbuf, uident, strlen(uident)))
			fputs(genbuf, nfp);
	    	else 
			deleted = YEA;
	}
	fclose(fp);
	fclose(nfp);
	if (!deleted) 
		return -1;
	return(rename(fnnew, fn));
}

int	t_override(void)
{
	char	uident[STRLEN];
	int	ans,
		count;

	while (YEA) 
	{
  		clear();
		prints(NA, TALK_EDIT_OVERRIDE);
        	count = listfriends();
  		if (count)
	        	ans = getans(1, 0, TALK_ADDOVERRIDE, 'e');
	  	else 
	        	ans = getans(1, 0, TALK_NEWOVERRIDE, 'e');
	  	if (ans == 'a') 
		{
	    		u_namelist();
	    		move(2, 0);
	    		namecomplete("Enter userid: ", uident);
	    		move(2, 0);
	    		clrtoeol();
	    		if (uident[0] != '\0' && getuser(uident))
	        		addtooverride(uident);
	  	}
	  	else if ((ans == 'D' || ans == 'd') && count) 
		{
	    		move(2, 0);
	    		namecomplete("Enter userid: ", uident);
	    		move(2, 0);
	    		clrtoeol();
	    		if (uident[0] != '\0')
	        		deleteoverride(uident);
	  	}		
	  	else 
			break;
	}
	clear();
	return 0;
}		

int	t_friend(void)
{
     	FILE	*fp;
     	int	fd,
		i,
		j,
		f_count = 0,
		found = 0;
     	char	*nl,
     		entry[40],
     		u_list[MAXACTIVE * 20],
     		nick_list[MAXACTIVE * 20],
     		f_list[MAXACTIVE][20];
     	userec	utmp;
     	usinfo	uent,
     		*uentp;

	sprintf(genbuf, PATH_OVERRIDE, cuser.userid);
	if ((fp = fopen(genbuf, "r")) == NULL) 
	{
	   	move(2, 0);
           	prints(NA, TALK_NOFRIEND);
           	return 0;
	}
	while (fgets(genbuf, STRLEN, fp) != NULL) 
	{
		if ((nl = (char *)strtok(genbuf, " \n\r\t")) != NULL) 
		{
			strncpy(f_list[f_count] , genbuf, 20);
			f_count++;
		}
	}
	fclose(fp);

	u_list[0] = ':';

	resolve_utmp();
	
	changemode(FRIENDS, NA);
	user_list_title();
	uentp = &uent;
	for( j = 0; j < UTMP_SIZE; j++ ) {
		memcpy( &uent, &(utmpshm->utc[j]), sizeof(usinfo));
		if (!uentp->active || !uentp->pid || (!HAS_PERM(PERM_SEECLOAK)
			&& uentp->invisible) || (kill(uentp->pid, 0) == -1))
			continue;
		for(i = 0; i < f_count; i++) 
		{
			if (!strcmp(uentp->userid, f_list[i]))
			{
				found++;
				if (found != 0 && found %19 == 0) 
				{
					int	ch;

					prints(YEA, MSG_MORE_);
					clrtoeol();
					while ((ch = igetch()) != EOF) 
					{
						if (strchr ("\n\r qQ", ch))
							break;
						bell(1);
					}
					if (strchr("Qq", ch))
						return QUIT;
					move(4, 0);
					clrtobot();
				}
				user_list_uentp(uentp);
			}
		}
	}

	if (found == 0)
		prints(NA, TALK_CANT_FIND_FRIEND);
	else
	{
		move(2, 0);
		prints(NA, TALK_TOTAL_FRIEND, found);
	}
	pressreturn();
	clear();
	return 0;
}

int	kick_user(void)
{
        int	id,
		ind,
		ans;
        usinfo	uin;
	time_t	ti;
        char	kickuser[40],
		buffer[40];

	if (!HAS_SET(SET_USERLIST))
	{
        	u_namelist();
        	clear();    
        	move(0, 0);
        	prints(YEA, "Kick User");
        	clrtoeol();
        	move(1, 0);
        	namecomplete(TALK_KICKOUT, kickuser);
	        if (*kickuser == '\0') 
		{
	                clear();
	                return 0;
	        }
	        if (!(id = getuser(kickuser))) 
		{
	                move(2, 0);
	                prints(NA, TALK_NO_SUCH_USER);
	                clrtoeol();
	                pressreturn();
	                clear();
	                return 0;
	        }
	}
	else
	{
		clear();
		move(0, 0);
		prints(YEA, TALK_KICK_CLEAN);
		clrtoeol();
		move(1, 0);
		prints(YEA, TALK_KICKOUT);
		if ((id = i_userid(2, USER_OLD, kickuser)) < 0)
		{
			clear();
			return 0;
		}
	}
        sprintf(genbuf, TALK_KICK_MAKESURE, kickuser);

        ans = getans(1, 0, genbuf, 'n');
        if (ans != 'y') 
	{
                move(2, 0);
                prints(NA, TALK_ABORT_KICK, kickuser);
                return 0;
        }
        ind = search_ulist(&uin, t_cmpuids, id);
        if (!ind || !uin.active || (kill(uin.pid, 0) == -1)) 
	{
                move(2, 0);
                prints(NA, TALK_LOGOUT);
                return 0;
        }
        kill(uin.pid, SIGHUP);

        if ((ufp = fopen("usies", "a")) != NULL) 
	{
                ti = time(0);
                fprintf(ufp, "KICK  %-10s %-20s %s", uin.userid, uin.username,
			ctime(&ti));
                fflush(ufp);
                fclose(ufp);   
        }
        uin.active = NA;  
        uin.pid = 0;
        uin.invisible = YEA;
        uin.sockactive = 0;
        uin.sockaddr = 0;
        uin.destuid = 0;

	bzero(uin.ptcb, sizeof(uin.ptcb));
        update_ulist(&uin, ind);
        move(2, 0);
        prints(NA, "User has been Kicked\n");
        pressreturn();
        clear();
        return 0;
}

int	select_multipid(tuid, size)
int	tuid,
	size;
{
	int	fd,
		ans,
		multi_num=0,
		i,
		pidbuf[10],
		frg=0;
	usinfo	uentp,
		uentmp;
	char	buf[10];

/* mark */ 
	resolve_utmp();
	for( i = 0; i < UTMP_SIZE; i++ ) {
		memcpy(&uentp,  &(utmpshm->utc[i]), sizeof(usinfo));
		if (t_cmpuids(tuid, &uentp))
		{
			if ((!HAS_PERM(PERM_SEECLOAK) && uentp.invisible)
				|| (uentp.pid==0))
				continue;
			pidbuf[multi_num] = uentp.pid;
			multi_num++;   
			if (multi_num==1)
				bcopy((char *)&uentp, (char *)&uentmp, size);
			if (multi_num==2)
			{
				clear();
				user_list_title();
				user_list_uentp(&uentmp);
			}
			if (multi_num>=2)
				user_list_uentp(&uentp);
		}	
	}

	if (multi_num == 0)
		return 0;
	if (multi_num == 1)
		return pidbuf[0];

	do
	{
		move(multi_num+5, 0);
		clrtoeol();
		getdata(multi_num + 5, 0, TALK_CHOICE_PID, buf,	10, DOECHO,
			YEA);
		if (buf[0]=='\0')
			return -1;
		ans = atoi(buf);
		for(i=0; i<multi_num; i++)
		{
			if (ans == pidbuf[i])
				frg=1;
		}
	}
	while (!frg);

	return ans;
}
