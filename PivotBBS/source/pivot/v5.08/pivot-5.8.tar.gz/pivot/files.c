/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)files.c  5.08 3/19/95 (C) 1993 University of \
NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include "bbs.h"

#ifdef FILES 

static char currfile[STRLEN];
char dirs[MAXDIRSIZE][STRLEN];
int fileselect = 0, numdirs = 0;

ptcol protos[] =
{
{ "Kermit", "kermit -si", "kermit -ri"},
{ "Xmodem", "sx -be",       "rx -bpe"},
{ "Ymodem", "sb -be",       "rb -bpe"}
/*,
{ "Zmodem", "sz -be",       "rz -bpe"}*/
};

#define NUMPROTOS (sizeof(protos)/sizeof(ptcol))

char *NameProtocol(id)
{
	if (id < 0 || id >= NUMPROTOS)
	  return "invalid";
	return protos[id].pname;
}

char *CurrentProtocol(void)
{
	return NameProtocol(cuser.protocol);
}

char *filemargin(void)
{
	static char buf[STRLEN];
	
	if (fileselect)
	  sprintf(buf,"File Sub-board is '%s'",currfile);
	else
	  sprintf(buf,"No File Sub-board Selected");
	return buf;
}

#undef DIR

int get_dir(void)
{
	DIR *dp;
	struct direct *ent;
	struct stat status;

	numdirs = 0;
	if ((dp = opendir("ftp/files")) == NULL)
	  return -1;
	for(ent=readdir(dp);ent!=NULL;ent=readdir(dp)) {
		if (!strcmp(ent->d_name,"."))
		  continue;
		if (!strcmp(ent->d_name,".."))
		  continue;
		sprintf(genbuf,"ftp/files/%s",ent->d_name);
		if (stat(genbuf,&status))
		  continue;
		if (!(status.st_mode & S_IFDIR))
		  continue;
		if (numdirs >= MAXDIRSIZE)
		  continue;
		strcpy(dirs[numdirs],ent->d_name);
		numdirs++;
	}
	closedir(dp);
	return 0;
}


int f_list(void)
{
	DIR *dp;
	struct direct *ent;
	struct stat status;
	int i;
	int col;
	char buf[512];

	if (!fileselect) {
		move(3,0);
		clrtobot();
		prints(NA, "Use (S)elect to select a sub board first!\n");
		pressreturn();
		return -1;
	}
	move(3,0);
	clrtobot();
	prints(NA, "List of Files on bbs for download\n");
	prints(NA, "%-19s  Size","FILENAME");
	sprintf(buf,"ftp/files/%s",currfile);
	if ((dp = opendir(buf)) == NULL)
	  return -1;
	i = 5;
	col = 0;
	for(ent=readdir(dp);ent!=NULL;ent=readdir(dp)) {
		if (!strcmp(ent->d_name,"."))
		  continue;
		if (!strcmp(ent->d_name,".."))
		  continue;
		sprintf(genbuf,"ftp/files/%s/%s",currfile,ent->d_name);
		if (stat(genbuf,&status))
		  continue;
		if ((status.st_mode & S_IFDIR))
		  continue;
		if (i == 23) {
			col++;
			if (col == 3) {
				int ch;
				move(23,0);
				prints(YEA, "-- More --");
				while ((ch = igetch()) != EOF) {
					if (ch == 'q') {
						closedir(dp);
						move(23,0);
						clrtoeol();
						return 0;
					}
					if (ch == '\n' || ch == '\r' || ch == ' ')
					  break;
					bell(1);
				}
				col = 0;
				move(4,0);
				clrtobot();
			}
			move(4,col*26);
			prints(NA, "%-19s  Size","FILENAME");
			i = 5;
		}
		move(i,col*26);
		prints(NA, "%-19s %4dk",ent->d_name,(status.st_size+512)>>10);
		i++;
	}
	closedir(dp);
	pressreturn();
	return 0;
}

int f_create_namelist(void)
{
	DIR *dp;
	struct direct *ent;
	struct stat status;

	if (!fileselect) {
		return -1;
	}
	CreateNameList();
	sprintf(genbuf,"ftp/files/%s",currfile);
	if ((dp = opendir(genbuf)) == NULL)
	  return -1;
	for(ent=readdir(dp);ent!=NULL;ent=readdir(dp)) {
		if (!strcmp(ent->d_name,"."))
		  continue;
		if (!strcmp(ent->d_name,".."))
		  continue;
		sprintf(genbuf,"ftp/files/%s/%s",currfile,ent->d_name);
		if (stat(genbuf,&status))
		  continue;
		if ((status.st_mode & S_IFDIR))
		  continue;
		AddNameList(ent->d_name);
	}
	closedir(dp);
	return 0;
}

int f_download(void)
{
	char fname[STRLEN];
	char path[512];
	struct stat st;

	if (!fileselect) {
		move(3,0);
		clrtobot();
		prints(NA, "Use (S)elect to select a sub board first!\n");
		pressreturn();
		return -1;
	}
	if (cuser.protocol < 0 || cuser.protocol >= NUMPROTOS)
	  return 0;
	f_create_namelist();
	move(0,0);
	prints(NA, "%s DOWNLOAD FACILITY\n",CurrentProtocol());
	prints(NA, "Enter Filename: ");
	clrtoeol();
	namecomplete(NULL,fname);
	sprintf(path,"ftp/files/%s/%s",currfile,fname);
	if ((*fname == '\0') || (stat(path,&st) == -1)) {
		move(2,0);
		prints(NA, "Invalid File Name\n");
		pressreturn();
		move(0,0);
		clrtoeol();
		move(1,0);
		clrtoeol();
		move(2,0);
		clrtoeol();
		return 1;
	}
	if ((st.st_mode & S_IFDIR)) {
		move(1,0);
		prints(NA, "Invalid File Name\n");
		pressreturn();
		move(0,0);
		clrtoeol();
		move(1,0);
		clrtoeol();
		move(2,0);
		clrtoeol();
		return 1;
	}
	move(3,0);
	clrtobot();
	reset_tty();
	printf("Using %s protocol\n",CurrentProtocol());
	sprintf(genbuf,"%s %s",protos[cuser.protocol].sendbin,path);
	do_exec(genbuf, NULL);
	restore_tty();
	clear();
	pressreturn();
	return 0;
}

int f_upload(void)
{
	char buf[512];
	
	if (!fileselect) {
		move(3,0);
		clrtobot();
		prints(NA, "Use (S)elect to select a sub board first!\n");
		pressreturn();
		return -1;
	}
	if (cuser.protocol < 0 || cuser.protocol >= NUMPROTOS)
	  return 0;
	move(3,0);
	clrtobot();
	reset_tty();
	printf("Using %s protocol\n",CurrentProtocol());
	sprintf(buf,"ftp/files/%s",currfile);
	do_exec(protos[cuser.protocol].recvbin, buf);
	restore_tty();
	clear();
	pressreturn();
	return 0;
}

int f_protocol(void)
{
	int i;
	char proto[STRLEN];

	move(3,0);
	clrtobot();
	prints(NA, "PROTOCOL MENU\n");
	for(i = 0; i < NUMPROTOS; i++)
	  prints(NA, "%d)  %s\n",i,protos[i].pname);
	move(3,0);
	prints(NA, "Enter Protocol id (0-%d): ", NUMPROTOS - 1);
	clrtoeol();
	getdata(0,0,NULL,proto,3,DOECHO,YEA);
	if (proto[0] == '\0')
	  return 0;
	i = atoi(proto);
	if (i < 0 || i >= NUMPROTOS)
	  return 0;
	clear();
	cuser.protocol = i;
	UPDATE;
	return 0;
}

int f_select(void)
{
	int i;
	char buf[STRLEN];

	get_dir();
	move(3,0);
	clrtobot();
	prints(NA, "FILE BOARDS MENU\n");
	clrtoeol();
	for(i=0; i < numdirs; i++) {
	  move(i%20+4,(i/20)*20);
	  prints(NA, "%2d) %s",i,dirs[i]);
	}
	move(3,0);
	prints(NA, "Enter file board id (0-%d): ", numdirs - 1);
	clrtoeol();
	getdata(0,0,NULL,buf,3,DOECHO,YEA);
	if (buf[0] == '\0')
	  return 0;
	i = atoi(buf);
	if (i < 0 || i >= numdirs)
	  return 0;
	clear();
	strcpy(currfile,dirs[i]);
	fileselect = 1;
	return 0;
}

int f_text(void)
{
	char fname[STRLEN];
	char path[512];
	struct stat st;

	if (!fileselect) {
		move(3,0);
		clrtobot();
		prints(NA, "Use (S)elect to select a sub board first!\n");
		pressreturn();
		return -1;
	}
	f_create_namelist();
	move(0,0);
	prints(NA, "Text Viewing Facility\n");
	prints(NA, "Enter Filename: ");
	clrtoeol();
	namecomplete(NULL,fname);
	sprintf(path,"ftp/files/%s/%s",currfile,fname);
	if ((*fname == '\0') || (stat(path,&st) == -1)) {
		move(2,0);
		prints(NA, "Invalid File Name\n");
		pressreturn();
		move(0,0);
		clrtoeol();
		move(1,0);
		clrtoeol();
		move(2,0);
		clrtoeol();
		return 1;
	}
	if ((st.st_mode & S_IFDIR)) {
		move(1,0);
		prints(NA, "Invalid File Name\n");
		pressreturn();
		move(0,0);
		clrtoeol();
		move(1,0);
		clrtoeol();
		move(2,0);
		clrtoeol();
		return 1;
	}
	more(path,YEA);
	clear();
	return 0;
}

#endif /* FILES */
