/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)maintain.c   5.08 3/19/95 (C) 1993 University \
of NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include "bbs.h"

int	count_exper(info, dble)
userec	*info;
int	*dble;
{
	int	exper;

	*dble = VACATION + ((info->userlevel & PERM_TRUE) ? 1 : 0);
	exper = (info->numposts + (info->numlogins / 5)) * (*dble);

	return	exper;
}

int	clean_user(info)
userec	*info;
{
	time_t	now,
		idle,
		exper,
		history;
	int	dble;

	if (info->userid[0] == '\0' || info->userlevel & PERM_NOCLEAN)
		return NA;
	time(&now);

	exper = (int)count_exper(info, &dble) + 1;
	history = (now - info->reg_date)/600;
	idle = (now - info->lastlogin)/86400;

	if (!stricmp(info->userid, "new") && history > 1)
		return -1;

	if ((now - info->reg_date)/86400 <= dble*14)
		return NA;

	if ((!(info->userlevel & PERM_TRUE) && (idle > dble*7)) ||
		(exper < 30 && (idle > exper*2 || idle > 30)) ||
		(exper < 60 && idle > 45) || (exper < 120 && idle > 60) ||
		(exper < 240 && idle > 75) || (exper >= 240 && idle > 90))
		return YEA;

	return NA;
}

int	del_unused(void)
{
	userec	info;
	int	id,
		cleaned = 0;
	time_t	now;
	char	reg_date[10],
		last[10];

	for (id = 1; id <= MAXUSERS; id++)
	{
		if (get_record(PASSFILE, (char *)&info, sizeof(userec), id))
			return 0;
		if (clean_user(&info))
		{
			if (stricmp(info.userid, "new"))
			{
				++cleaned;
				sprintf(reg_date, "%6.6s",
					ctime(&info.reg_date) + 4);
				sprintf(last, "%6.6s",
					ctime(&info.lastlogin) + 4);
				logit(LOG_CLEAN,
					"%s, p:%3d, l:%3d, r:%6.6s, l:%6.6s",
					info.userid, info.numposts,
					info.numlogins, reg_date, last);
				sprintf(genbuf, PATH_USER, info.userid);
				if (!access(genbuf, R_OK))
				{
					sprintf(genbuf,PATH_DUSER,info.userid);
					system(genbuf);
				}
			}
			bzero(&info, sizeof(userec));
			substitute_passwd(PASSFILE, &info, YEA, id);
		}
	}
	return cleaned;
}

int	m_uclean(void)
{
	move(2, 0);
	prints(NA, "�M���L�����ϥΪ��b����, �еy��..");
	refresh();
	move(2, 0);
	clrtoeol();
	prints(NA, "�`�@�M��: %d ��L�����ϥΪ�����", del_unused());
	return 0;
}
		
int m_info(void)
{
	int ans, id = 0;
	char uidbuf[20];
	userec initial;

	changemode(MINFO, NA);
	clear();
	prints(YEA, "��s���W USER ���");
	ans = getans(1,0,"�п�� (1) �H Login ID (2) �H UserNum (3) �^�W�h: [3]",
		'3');
	move(1,0);
	clrtoeol();

	switch(ans)
	{
		case '1':
			move(1, 3);
			if (!(id = init_namelist(genbuf)))
				return 0;
			break;

		case '2':
			getdata(1,0,"�ѧǸ���� ", uidbuf, STRLEN, DOECHO,
				YEA);
			id = atoi(uidbuf);
			break;

		default:
			break;
	}

	if (id > 0 && id <= MAXUSERS)
	{
		get_record(PASSFILE, (char *)&initial, sizeof(userec), id);
		modify_info(&initial, id, YEA);
	}
	changemode(MADMIN, NA);
	clear();
    	return 0;
}

int	m_plan(void)
{
	char	bname[STRLEN],
		bpath[STRLEN*2];
	struct	stat	statb;
	int	pos;
	bhd	fh,
		newfh;

	make_blist();
	clear();
	prints(YEA, "Change Board Info");

	move(1,0);
	namecomplete("Enter board name: ", bname);
	if (*bname == '\0')
	{
		move(2,0);
		prints(NA, "Invalid Board Name");
		pressreturn();
		clear();
		return -1;
	}

	if (!(pos = search_board(&fh,bname)))
	{
		move(2,0);
		prints(NA, "Invalid Board Name");
		pressreturn();
		clear();
		return -1;
	}

	changemode(BOARDINFO, NA);

	sprintf(bpath,"boards/%s/.plan",bname);
	pos = vedit(bpath, NA);
	clear();
	if (!pos)
		prints(NA, "Board Plan Updated");

	pressreturn();

	changemode(MADMIN, NA);

}

int	edit_board(brd, create)
bhd	*brd;
int	create;
{
	char	genbuf[STRLEN],
		buf1[STRLEN],buf2[STRLEN];
	bhd	dh;
	int	ans,
		i;

	i = (create) ? 1 : 11;
	move(i++, 0);
	clrtoeol();
	for(;;)
	{
		getdata(i, 0, "�s�Q�װϦW: ", genbuf, 18, DOECHO, YEA);
		if (genbuf[0] == '\0')
		{
			if (create)
				return -1;
			else
				break;
		}

		if (search_board(&dh,genbuf))
		{
			move(i+1,0);
			prints(NA, "Error! Board already exists\n");
			bell(1);
			move(11,0);
			clrtobot();
			continue;
		}

		if (create) {
			sprintf(buf1,"boards/%s", genbuf);
			mkdir(buf1, 0750);
		} else {
			sprintf(buf1,"boards/%s", brd->filename);
			sprintf(buf2,"boards/%s", genbuf);
			rename( buf1 , buf2);
		}
		strncpy(brd->filename, genbuf, sizeof(brd->filename));
		break;
	}

	getdata(++i, 0, "�Q�װϥD�D�]�w: ", genbuf, 60, DOECHO, YEA);
	if (genbuf[0])
		strcpy(brd->title, genbuf);
	ans = getans(++i,0,"�ѥ[��H(Y/N): [N]",'n');
	if (ans == 'y')
		brd->flag |= BHD_BBSNEWS;
	else
  		brd->flag = 0;

	getdata(++i, 0, "�Ĥ@��O�N�z: ", genbuf, 60, DOECHO, YEA);
       	if (*genbuf != 0)
       	        strncpy(brd->manager1, genbuf, sizeof(brd->manager1));

	getdata(++i, 0, "�ĤG��O�N�z: ",genbuf, 60, DOECHO, YEA);
	if (*genbuf != 0)
                strncpy(brd->manager2, genbuf, sizeof(brd->manager2));

	getdata(++i,0, "�ĤT��O�N�z: ",genbuf, 60, DOECHO, YEA);
	if (*genbuf != 0)
                strncpy(brd->manager3, genbuf, sizeof(brd->manager3)); 

	if (create)
	{
		brd->readlevel = ~0;
		brd->postlevel = PERM_TRUE;
	}
	move(3, 0);
	prints(NA, "��� %s �i�i�K�j�v��\n", brd->filename);
	brd->postlevel = setperms(brd->postlevel, permstrings);

	move(3, 0);
	prints(NA, "��� %s �iŪ���j�v��\n", brd->filename);
	brd->readlevel = setperms(brd->readlevel, permstrings);

	ans = gain_group();
	if (ans != 0)
		brd->group = ans;
}

int	Create(void)
{
	bhd	new;
	char	*s;
	int	ans = NA;
	FILE	*fp;
	time_t	ti;

	clear();

	changemode(CREATE, NA);
	bzero(&new, sizeof(bhd));
	prints(NA, "�W�]�Q�װ�:");

	if (edit_board(&new, YEA) == -1)
	{
		prints(NA, "\n���]�߰Q�װ�\n");
		changemode(MADMIN, NA);
		pressreturn();
		return -1;
	}

	ans = getans(t_lines-2, 0, "�O�_���ߦ��Q�װ�(Y/N)? [Y]: ", 'y');
	if (ans == 'n')
	{
		prints(NA, "\n���]�߰Q�װ�\n");
		changemode(MADMIN, NA);
		pressreturn();
		return -1;
	}

	if (append_record(BOARDS, (char *)&new, sizeof(new)) == -1)
	{
		changemode(MADMIN, NA);
		pressreturn();
		clear();
		return -1;
	}

	numboards = -1;
	prints(NA, "\n�s�Q�װϤw�g�]�w����\n");
	logit(LOG_MODBRD, "%s create %s", cuser.userid, new.filename);
	pressreturn();
	changemode(MADMIN, NA);
	clear();

	return 0;
}

int	m_editbrd(void)
{
	char	bname[STRLEN],
		bpath[STRLEN*2],
		buf[10];
	struct	stat	statb;
	int	pos,
		ans,
		frg = 0,
		frg2 = 0;
	FILE	*fp;
	time_t	ti;
	bhd	fh,
		newfh;

	make_blist();
	clear();
	prints(YEA, "Change Board Info");

	move(1,0);
	namecomplete("Enter board name: ", bname);
	if (*bname == '\0')
	{
		move(2,0);
		prints(NA, "Invalid Board Name");
		pressreturn();
		clear();
		return -1;
	}

	if (!(pos = search_board(&fh,bname)))
	{
		move(2,0);
		prints(NA, "Invalid Board Name");
		pressreturn();
		clear();

		return -1;
	}

	move(3,0);
	bcopy(&fh, &newfh, sizeof(bhd));
	prints(NA, "Board Name:        %s\n", fh.filename);
	prints(NA, "Board Description: %s\n", fh.title);
        prints(NA, "Send to Other BBS: %c\n", (fh.flag & BHD_BBSNEWS)? 'Y' : 'N');
	prints(NA, "���s�s��:          %d\n", fh.group);
        prints(NA, "Board Managers:    %-13s: %-13s: %-13s\n", fh.manager1,
                fh.manager2, fh.manager3);

	ans = getans(9,0, "Change Board Info? (Yes or No) [N]: ", 'n');

	if (ans == 'y')
		edit_board(&newfh, NA);
	else
		return -1;
	ans = getans(t_lines-2, 0, "�T�w���W�z�]�w(Y/N)? [Y]: ", 'y');
	if (ans != 'n')
	{
		if (substitute_record(BOARDS, (char *)&newfh, sizeof(bhd), pos)
			== -1)
		{
			return -1;
		}
		numboards = -1;
	}
	clear();
	return 0;
}
