/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful, 
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)post.c   5.08 3/19/95 (C) 1993 University \
of NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include "bbs.h"

static	int	sequent_ent,
		quiting;

char	*bfile(boardname)
char	*boardname;
{
	static	char	buf[STRLEN];

	strcpy(buf, "boards/");
	strcat(buf, boardname);

	return buf;
}

int	Post(void)
{
	fhd	postfile;
	char	fname[STRLEN];
	int	aborted;

	if (!selboard)
	{
		move(2, 0);
		prints(NA, POST_NOCURRBRD);
		return 0;
	}

	if (!haspostperm(currboard))
	{
		move(2, 0);
		prints(NA, POST_NOLEVEL, currboard);
		return 0;
	}

	bzero((void *)&postfile, sizeof(postfile));
	postfile.accessed[usernum] = FILE_READ|FILE_OWND;
	clear();

	prints(NA, POST_CURRBRD_POST, currboard);
        if (get_title(NULL, postfile.title) == QUITPOST)
		return 0;
        strncpy(save_title, postfile.title, STRLEN-1);
        strncpy(save_filename, fname, 4096);
	in_mail = NA;
        strncpy(postfile.sender, cuser.userid, STRLEN);
	sprintf(fname, "boards/%s/", currboard);
	buildfile(fname);
	strcpy(postfile.filename, fname);
	sprintf(genbuf, "boards/%s/%s", currboard, fname);

	strncpy(uinfo.ptcb, currboard, 20);
	changemode(POSTING, YEA);
	aborted = vedit(genbuf, YEA);

	bzero(uinfo.ptcb, sizeof(uinfo.ptcb));
	changemode(MPOST, NA);

	clear();

	if (aborted == LOCALSAVE)
	{
		postfile.sended = POST_LOCAL;
		aborted = 0;
	}

	if (!aborted)
	{
		if (append_record(strcat(bfile(currboard), FHDIR), 
			(char *)&postfile, sizeof(postfile)) == -1)
		{
			prints(NA, POST_POSTERROR, ADMIN);
			pressreturn();
			clear();
			return -1;
		}
		prints(NA, POST_POSTSUCCESS, currboard);
		cuser.numposts++;
		UPDATE;
	}
	pressreturn();

	return 0;
}

void	readtitle(void)
{
	char	bmlist[50],
		output[STRLEN];
	bhd	fh;

	search_board(&fh,currboard);
	clear();
	sprintf(bmlist, "�i�N�z�t�d�H�j %s %s %s", 
		(fh.manager1[0]) ? fh.manager1 : "", 
                (fh.manager2[0]) ? fh.manager2 : "", 
                (fh.manager3[0]) ? fh.manager3 : "");
	move(0, 0);
	prints(NA, "%-50s%29s\n", bmlist, boardmargin());

	if ((fh.flag & BHD_VOTEING) && !(fh.accessed[usernum] & VOTED))
	{
		prints(YEA, "<NOTICE>");
		prints(NA, "�벼�}�l, �� 'V' �벼, Vote Polls started, %s\n", 
			"key 'V' for Vote");
        }
	else
		prints(NA, "%-18s%-8s%-30s%23s\n", 
			"[��, e]�^�W�@�e��", 
			"[h]�D�U", "[��, r, <cr>]Ū����ЩҦb�峹", 
			"[��, ��]�W, �U�@�g�峹");

	prints(YEA, "[1;32;44m �s��   %-15s %-6s  %-47s[m\n", "�@��", "���", "���D");
}

void	readdoent(num, ent)
int	num;
fhd	*ent;
{
	char	userid[80],
		*date;
	int	type;
	time_t	filetime;

	strcpy(userid, ent->sender);
	strtok(userid, ". @");

	if (ent->sended != '\0' && ent->sended != POST_LOCAL &&
		ent->sended != POST_DELIVER)
	{
		strcat(userid, ".");
	}
        filetime = atol(ent->filename + 2);

        if (filetime > 740000000)
                date = Ctime(&filetime) + 4;
        else
                date = Ctime(&filetime) + 20;

	if (ent->accessed[usernum] & FILE_VISIT)
		type = 'U';
	else if (!(ent->accessed[usernum] & FILE_READ))
		type = 'N';
	else
		type = ' ';

	if ((ent->accessed[0] & FILE_MARKED) && HAS_PERM(PERM_BMS))
	{
		if (type == ' ')
			type = 'm';
		else
			type = 'M';
	}

	if (strstr(ent->title, "Re: ") == ent->title)
	{
		if (!strcmp(ent->title+4, currtitle))
        		prints(NA, " %4d %c %-15.15s %6.6s  [1;33m%-.47s[m\n", 
				num, type, userid, date, ent->title);
		else
	        	prints(NA, " %4d %c %-15.15s %6.6s  %-47.47s\n", 
				num, type, userid, date, ent->title);
	}
	else
	{
		if (!strcmp(ent->title, currtitle))
        		prints(NA, " %4d %c %-15.15s %6.6s  [1;32m�� %-.40s ��[m\n", 
				num, type, userid, date, ent->title);
		else
	        	prints(NA, " %4d %c %-15.15s %6.6s  �� %-.40s ��\n", 
				num, type, userid, date, ent->title);
	}
}

int	cmpfilename(fhdr, currfile)
fhd	*fhdr;
char	*currfile;
{
	if (!strncmp(fhdr->filename, currfile, STRLEN))
		return 1;
	return 0;
}

void	updatefile(fhdr)
fhd	*fhdr;
{
	fhdr->accessed[usernum] |= FILE_READ;
	fhdr->accessed[usernum] &= ~FILE_VISIT;
}

int	cook_announce(ent, fileinfo, direct)
int	ent;
fhd	*fileinfo;
char	*direct;
{
	char	*t, 
		buf[80], 
		buf1[80], 
		filebuf[80];
	struct	stat	st;

	if (((uinfo.mode == RMAIL)&&HAS_PERM(PERM_LOCALBM))||
		HAS_PERM(PERM_MARKPOST)||islocalbm())
	{
        	strcpy(buf, direct);

        	if (t = (char *)rindex(buf, '/'))
          		*t = '\0';

        	sprintf(genbuf, "%s/%s", buf, fileinfo->filename);
		strcpy(buf1, "test");
		getdata(t_lines-1, 0, "��J�ɦW�G", buf1, 20, DOECHO, NA);
		buf1[strlen(buf1)] = '\0';
		sprintf(filebuf, "tmp/bd.%s", buf1);

		if ((buf1[0] == '\0') ||(stat(filebuf, &st) != -1))
		{
			move(t_lines-1, 0);
			prints(NA, "�ɮפw�g�s�b, �Э��s�]�w filename..%s", 
				" �����N���~��..");
			egetch();
			move(t_lines-1, 0);
			clrtoeol();

			return PARTUPDATE;
		}
		sprintf(buf, "cp %s %s", genbuf, filebuf);
		system(buf);
		move(t_lines-1, 0);
       		clrtoeol();

		return PARTUPDATE;
	}
	else
	{
       		bell(1);

        	return DONOTHING;
	}
}

int	read_post(ent, fileinfo, direct)
int	ent;
fhd	*fileinfo;
char	*direct;
{
	char	*t, 
		buf[512];
        int	ch;
	fhd	postinfo;
#ifdef	LINUX
	userec	myself;
#endif

	clear();
	clrtoeol();
	refresh();
	strcpy(buf, direct);

	if (t = (char *)rindex(buf, '/'))
		*t = '\0';

	sprintf(genbuf, "%s/%s", buf, fileinfo->filename);

	if (strstr(fileinfo->title, "Re: ") == fileinfo->title)
		strcpy(currtitle, fileinfo->title+4);
	else
		strcpy(currtitle, fileinfo->title);
	strcpy(currauth, fileinfo->sender);
#ifndef NOREPLY
	more(genbuf, NA);
#else
        more(genbuf, YEA);
#endif
	strncpy(currfile, fileinfo->filename, STRLEN);
#ifdef	LINUX
	bcopy(&cuser, &myself, sizeof(cuser));
#endif
	update_file(direct, sizeof(fhd), ent, cmpfilename, 
		updatefile);
#ifdef	LINUX
	bcopy(&myself, &cuser, sizeof(cuser));
#endif
#ifndef NOREPLY
#ifdef PERMS
	if (haspostperm(currboard))
	{
#endif
		move(t_lines-1, 0);
		clrtoeol();
        	prints(NA, "[m[1;34;46m \[�\\Ū�峹] [45m %s   %s  %s", 
			"[32m[R] [33m�^�H  [32m[Q|Enter|��] [33m����", 
			"[32m[��] [33m�W�@��   [32m[Space|��|��]", 
			"[33m�U�@�� [m");
        	switch(ch = egetch())
		{
                	case 'N':
			case 'Q':
			case 'n':
			case 'q':
			case KEY_LEFT:
				break; 
                	case ' ':
			case 'j':
			case KEY_RIGHT:
			case KEY_DOWN:
				return READ_NEXT;
                	case KEY_UP:
				return READ_PREV;
			case 'Y':
			case 'R':
			case 'y':
			case 'r':
	            		do_reply(fileinfo);
                	default:
				break;
        	}
#ifdef PERMS
	}
	else
		pressreturn();
#endif
	prints(NA, "\n");
#endif
	return FULLUPDATE;
}

int	do_select(void)
{
	char	bname[STRLEN];
	struct	stat	st;

	if (Select())
		return FULLUPDATE;
	else
		strncpy(uinfo.ptcb, currboard, 20);

	return NEWDIRECT;
}

void	convert_mail(fileinfo, mailinfo)
fhd	*fileinfo;
mhd	*mailinfo;
{
	bzero(mailinfo, sizeof(mhd));
	strcpy(mailinfo->sender, fileinfo->sender);
	strncpy(mailinfo->filename, fileinfo->filename, 20);
	if (!fileinfo->title[0])
		strcpy(fileinfo->title, "Re: ");
	strcpy(mailinfo->title, fileinfo->title);
}

int	do_reply_auth(oldfile)
fhd	*oldfile;
{
	mhd	maildata;
	char	bufdir[STRLEN];

	sprintf(bufdir, PATH_BRDDIRECT, currboard);
	convert_mail(oldfile, &maildata);
	return mail_reply(0, &maildata, bufdir);
}

int	do_reply_forward(oldfile, email)
fhd	*oldfile;
int	email;
{
	char	namebuf[STRLEN],
		bufdir[STRLEN];
	mhd	mailbuf;

	if (email && HAS_PERM(PERM_TRUE))
	{
		getdata(0, 0, ASK_RECEIVER, namebuf, STRLEN, DOECHO, YEA);
		if (namebuf[0] == '\0')
			return -1;
	}
	else
	{
		if (!init_namelist(namebuf))
			return -1;
	}
	sprintf(bufdir, PATH_BRDDIRECT, currboard);
	convert_mail(oldfile, &mailbuf);
	strcpy(mailbuf.sender, namebuf);
	return mail_reply(0, &mailbuf, bufdir);
}

int	do_reply(oldfile)
fhd	*oldfile;
{
	char 	ans;
	mhd	maildata;

	clear();
	ans = getans(1, 0, "�^�H (B)�Q�װ�, (A)�@��, (F)����, (E)���~, (Q)���? [B]: ",
		'b');

	switch(ans)
	{
		case 'b':
			return do_post(oldfile, YEA);
		case 'a':
			return do_reply_auth(oldfile);
		case 'f':
			return do_reply_forward(oldfile, NA);
		case 'e':
			return do_reply_forward(oldfile, YEA);
		default:
			return 0;
	}
}

int	read_faq(ent, fileinfo, direct)
int	ent;
fhd	*fileinfo;
char	*direct;
{
	int	savemode = uinfo.mode;
	char	buf[80];

	faqview(currboard);

	return FULLUPDATE;
}

int	read_do_post(ent, fileinfo, direct)
int	ent;
fhd	*fileinfo;
char	*direct;
{
       fhd	oldfile;

       bzero(&oldfile, sizeof(oldfile));
       do_post(&oldfile, NA);

       return FULLUPDATE;
}

int	do_post(oldfile, flag)
fhd	*oldfile;
int	flag;
{
	fhd	postfile;
	struct	stat	st;
	char	fname[STRLEN], 
		buf[256], 
		buff[80], 
		oldbuf[STRLEN], 
		*ip;
	int	fp, 
		aborted, 
		action, 
		ans, 
		savemode, 
		addold = 0, 
		savecmp;

	if (!haspostperm(currboard))
	{
		move(2, 0);
		prints(NA, POST_NOLEVEL, currboard);
		return 0;
	}

	bzero((void *)&postfile, sizeof(postfile));
	postfile.accessed[usernum] = FILE_READ|FILE_OWND;
	clear();

	prints(NA, POST_CURRBRD_POST, currboard);

	sprintf(fname, "boards/%s/", currboard);
	buildfile(fname);
	strcpy(postfile.filename, fname);
	sprintf(genbuf, "boards/%s/%s", currboard, fname);

	if (oldfile->title[0])
	{
		if (strstr(oldfile->title, "Re: ") == oldfile->title)
			strcpy(buf, oldfile->title);
		else
			sprintf(buf, "Re: %s", oldfile->title);
	    	if (get_title(buf, postfile.title) == QUITPOST)
	      		return 0;

		ans = getans(1, 0, POST_ASK_ORIG, 'y');

		if (ans == 'y' || ans == 'a')
		{
			sprintf(oldbuf, "boards/%s/%s", currboard, 
				oldfile->filename);
			include_old(genbuf, oldbuf, ans);
	    	}
	}
	else if (get_title(NULL, postfile.title) == QUITPOST)
		return 0;
	strncpy(save_title, postfile.title, STRLEN);
	strncpy(save_filename, fname, 4096);
	in_mail = NA;
	strncpy(postfile.sender, cuser.userid, STRLEN);

	savemode = uinfo.mode;
	savecmp = uinfo.comp;
	changemode(POSTING, YEA);

	aborted = vedit(genbuf, YEA);

	changemode(savemode, savecmp);

	clear();
        if (aborted == LOCALSAVE)
	{
		postfile.sended = POST_LOCAL;
		aborted = 0;
        }
	if (aborted)
	{
		if (stat(genbuf, &st) != -1)
	      		unlink(genbuf);
		clear();
		return FULLUPDATE;
	}

	if (append_record(strcat(bfile(currboard), FHDIR), (char *)&postfile, 
					 sizeof(postfile)) == -1)
	{
		unlink(postfile.filename);
		prints(NA, POST_POSTERROR, ADMIN);
		pressreturn();
		clear();
		return FULLUPDATE;
	}
	prints(NA, POST_POSTSUCCESS, currboard);
	cuser.numposts++;

	UPDATE;
	pressreturn();

	return FULLUPDATE;
}

/*ARGSUSED*/
int	edit_post(ent, fileinfo, direct)
int	ent;
fhd	*fileinfo;
char	*direct;
{
	char	buf[512];
	char	*t;
	int	owned;

	owned = p_owned(fileinfo);

	if (!HAS_PERM(PERM_BOARDS) && !(owned) && !islocalbm())
	{
		bell(1);
		return DONOTHING;
	}

	clear();
	strcpy(buf, direct);
	if (t = (char *)rindex(buf, '/'))
		*t = '\0';
	sprintf(genbuf, "%s/%s", buf, fileinfo->filename);
	vedit(genbuf, NA);
	strncpy(currfile, fileinfo->filename, STRLEN);

	return FULLUPDATE;
}

int	mark_post(ent, fileinfo, direct)
int	ent;
fhd	*fileinfo;
char	*direct;
{
	if (!HAS_PERM(PERM_MARKPOST) && !islocalbm())
	{
		bell(1);
		return DONOTHING;
	}

	if (fileinfo->accessed[0] & FILE_MARKED)
		fileinfo->accessed[0] &= ~FILE_MARKED;
	else
		fileinfo->accessed[0] |= FILE_MARKED;

    	substitute_record(direct, (char *)fileinfo, sizeof(*fileinfo), ent);

    	return PARTUPDATE;
}

int	del_range(ent, fileinfo, direct)
int	ent;
fhd	*fileinfo;
char	*direct;
{
	char	num1[10], 
		num2[10];
	int	inum1, 
		inum2, 
		ans;

	if ((uinfo.mode == READING) && !islocalbm() && !HAS_PERM(PERM_BOARDS))
	{
		bell(1);
		return DONOTHING;
    	}

	clear();
	prints(NA, "Delete RANGE(�]�w�R���ɭ�)\n");
	getdata(1, 0, "���R���_�l�峹�s��: ", num1, 10, 
		DOECHO, YEA);
	inum1 = atoi(num1);
	if (inum1 <= 0)
	{
		prints(NA, "Invalid Low range number �_�l�峹�s���]�w���~\n");
		pressreturn();
		return FULLUPDATE;
	}
	getdata(2, 0, "���R�������峹�s��: ", num2, 10, 
		DOECHO, YEA);

	inum2 = atoi(num2);
	if (inum2 <= inum1)
	{
		prints(NA, "Invalid High range number �����峹�s���]�w���~\n");
		pressreturn();
		return FULLUPDATE;
	}

	ans = getans(3, 0, "Are You Sure? �T�{ (Yes, or No) [N]: ", 'n');
	if (ans == 'y')
	{
		delete_range(direct, inum1, inum2);
		fixkeep(direct, inum1, inum2);
		prints(NA, "Delete Complete\n");
		pressreturn();
		return FULLUPDATE;
	}

	prints(NA, "Delete Aborted\n");
	pressreturn();

	return FULLUPDATE;
}

int	move_post(ent, fileinfo, direct)
int	ent;
fhd	*fileinfo;
char	*direct;
{
	char	ans, 
		newboard[512], 
		movefrom[STRLEN], 
		moveto[STRLEN], 
		fname[STRLEN], 
		genbuf[STRLEN], 
		*t, 
		*ip;
	int	fp, 
		owned;
	time_t	dtime;
	struct	tm	*ptime;
	fhd	newfile;

	owned = p_owned(fileinfo);

	if ((!HAS_PERM(PERM_BOARDS)) && !(owned) && !islocalbm())
	{
		bell(1);

		return DONOTHING;
	}

	move(0, 0);
	clrtobot();
	prints(NA, "Move Message '%s' on Board %s.", fileinfo->title, currboard);
	genbuf[0] = 'n';
	ans = getans(1, 0, "(Yes, or No) [N]: ", 'n');

	if (ans != 'y')
	{
		move(2, 0);
		prints(NA, "Quitting Move Post\n");
		pressreturn();
		clear();
		return FULLUPDATE;
	}

	move(1, 0);
	make_blist();
	clrtoeol();
	newboard[0] = '\0';
	namecomplete("Move to Board: ", newboard);
	if ((*newboard == '\0') || (!strcmp(newboard, currboard)) ||
		!haspostperm(newboard))
	{
		move(2, 0);
		clrtoeol();
		prints(NA, "�h�E�ت����s�b, �άO�L POST �v��\n");
		pressreturn();

		return FULLUPDATE;
	}

	bcopy(fileinfo, &newfile, sizeof(fhd));
	sprintf(fname, "boards/%s/", newboard);
	buildfile(fname);
	strcpy(newfile.filename, fname);

	sprintf(movefrom, "boards/%s/%s", currboard, fileinfo->filename);
	sprintf(moveto, "boards/%s/%s", newboard, fname);

	if (append_record(strcat(bfile(newboard), FHDIR), (char *)&newfile, 
		sizeof(newfile)) == -1 )
	{
		move(3, 0);
		prints(NA, "Updating board %s cache Error\n", newboard);
		pressreturn();
		return FULLUPDATE;
	}

        if (!delete_file(direct, sizeof(fhd), ent, cmpfilename))
	{
#ifdef	BBSTONEWS
		strncpy(currfile, fileinfo->filename, STRLEN);
		cancelpost(currboard, currfile, cuser.userid);
#endif
		copyto(movefrom, moveto);
		unlink(movefrom);
	}
	else
	{
                move(3, 0);
                prints(NA, "Delete Source Cache Failure\n");
		prints(NA, "Press use 'd' to delete it\n");
        }
	pressreturn();

	return FULLUPDATE;
}

#ifdef BBSTONEWS
void	cancelpost(board, file, userid)
char	*board, 
	*file, 
	*userid;
{
	FILE	*fh;
	char	from[STRLEN], 
		path[STRLEN], 
		genbuf[STRLEN],
		*ptr;
	int	len;

	sprintf(genbuf, "boards/%s/%s", board, file);
	if ((fh = fopen(genbuf, "r")) != NULL)
	{
		from[0] = path[0] = '\0';

		while (fgets(genbuf, sizeof(genbuf), fh) != NULL)
		{
			len = strlen(genbuf) - 1;
			genbuf[len] = '\0';

            		if (len <= 8)
			{
                		break;
            		}
			else if (strncmp(genbuf, "�o�H�H: ", 8) == 0)
			{
				if ((ptr = (char *)rindex(genbuf, ',')) != NULL)
					*ptr = '\0';
				strcpy(from, genbuf + 8);
			}
			else if (strncmp(genbuf, "��H��: ", 8) == 0)
			{
				strcpy(path, genbuf + 8);
			}
		}

		fclose(fh);
		sprintf(genbuf, "%s\t%s\t%s\t%s\t%s\n", board, file, userid, 
			 from, path);

		if ((fh = fopen("cancelpost.lst", "a")) != NULL)
		{
			fputs(genbuf, fh);
			fclose(fh);
		}
	}
}
#endif /* BBSTONEWS */

int	del_post(ent, fileinfo, direct)
int	ent;
fhd	*fileinfo;
char	*direct;
{
	char	buf[512], 
		*t;
	int owned, ans;

	owned = p_owned(fileinfo);

        if (!HAS_PERM(PERM_BOARDS) && !owned && !islocalbm())
	{
		bell(1);
		return DONOTHING;
	}

	clear();
	prints(NA, "Delete Message '%s'.", fileinfo->title);
	ans = getans(1, 0, "(Yes, or No) [N]: ", 'n');

	if (ans != 'y')
	{
		move(2, 0);
		prints(NA, "Quitting Delete Post\n");
		pressreturn();
		clear();
		return FULLUPDATE;
	}

	strcpy(buf, direct);
	if (t = (char *)rindex(buf, '/'))
		*t = '\0';

	strncpy(currfile, fileinfo->filename, STRLEN);

	if (!delete_file(direct, sizeof(fhd), ent, cmpfilename))
	{
#ifdef	BBSTONEWS
		cancelpost(currboard, currfile, cuser.userid);
#endif
		sprintf(genbuf, "boards/%s/%s", currboard, fileinfo->filename);
		unlink(genbuf);
		pressreturn();

		if (owned)
		{
			if (cuser.numposts > 0)
				cuser.numposts--;
			UPDATE;
		}

		return FULLUPDATE;
	}

	move(2, 0);
	prints(NA, "Delete failed\n");
	pressreturn();
	clear();

	return FULLUPDATE;
}

int	sequent_messages(fptr)
fhd	*fptr;
{
	static	int	idc;
	int	ans;
	
	if (fptr == NULL)
	{
		idc = 0;
		return 0;
	}
	idc++;
	if (idc < sequent_ent)
		return 0;
	if (fptr->accessed[usernum] & FILE_READ &&
		!(fptr->accessed[usernum] & FILE_VISIT))
		return 0;
	mot = 1;
	prints(NA, "Read Message on board '%s' entitled:\n\"%s\" posted by %s.\n", 
		currboard, fptr->title, fptr->sender);

	ans = getans(3, 0, "(Yes or No or Quit) [Y]: ", 'y');
	if (ans != 'y')
	{
		if (ans == 'q')
		{
			clear();
			return QUIT;
		}
		clear();
		return 0;
	}
	sprintf(genbuf, "boards/%s/%s", currboard, fptr->filename);
#ifdef NOREPLY
	more(genbuf, YEA);
#else
	more(genbuf, NA);
	if (haspostperm(currboard))
	{
		ans = getans(t_lines-1, 0, "Reply (Y/N)? [N]: ", 'n');
		if (ans == 'y')
			do_reply(fptr);
	}
	else
		pressreturn();
#endif
	clear();
	sprintf(genbuf, "%s%s", bfile(currboard), FHDIR);
	strncpy(currfile, fptr->filename, STRLEN);
	update_file(genbuf, sizeof(fhd), idc, cmpfilename, 
		updatefile);

	return 0;
}

/*ARGSUSED*/
int	sequential_read(ent, fileinfo, direct)
int	ent;
fhd	*fileinfo;
char	*direct;
{
	clear();
	sequent_messages(fileinfo);
	sequent_ent = ent;
	quiting = NA;
	apply_record(strcat(bfile(currboard), FHDIR), sequent_messages, 
		sizeof(fhd));

	return FULLUPDATE;
}

int	title_change(ent, fileinfo, direct)
int	ent;
fhd	*fileinfo;
char	*direct;
{    
	char	buf[STRLEN];
	int	owned;
	bhd	fh;

	owned = p_owned(fileinfo);

	if (!HAS_PERM(PERM_SYSOP) && !owned && !islocalbm())
	{
        	bell(1);
        	return DONOTHING;
	}
	if (!strcmp(cuser.userid, GUEST)) 
        	return DONOTHING;

	strcpy(buf, fileinfo->title);
	getdata(t_lines-1, 0, "�]�w�s�D�D�G", buf, STRLEN, DOECHO, NA);
	if (buf[0])
        	strcpy(fileinfo->title, buf);

	substitute_record(direct, (char *)fileinfo, sizeof(*fileinfo), ent);

	return PARTUPDATE;
}

int	unread_post(ent, fileinfo, direct)
int	ent;
fhd	*fileinfo;
char	*direct;
{
	if (fileinfo->accessed[usernum] & FILE_READ)
		fileinfo->accessed[usernum] &= ~FILE_READ;
	else
		fileinfo->accessed[usernum] |= FILE_READ;

	if (fileinfo->accessed[usernum] & FILE_VISIT)
		fileinfo->accessed[usernum] &= ~FILE_VISIT;

	substitute_record(direct, (char *)fileinfo, sizeof(*fileinfo), ent);

	return PARTUPDATE;
}

int	cross_post(ent, fileinfo, direct)
int	ent;
fhd	*fileinfo;
char	*direct;
{
	fhd	xfile;
	char	fname[STRLEN],
		xboard[STRLEN],
		xfname[STRLEN],
		linebuf[STRLEN];
	int	ignore = YEA,
		aborted,
		ans,
		savemode;
	FILE	*fileptr,
		*xptr;
	char	*date;
	time_t	filetime;
	struct	tm	*ptime;

	if (!HAS_PERM(PERM_POST))
	{
        	bell(1);
        	return DONOTHING;
     	}

	make_blist();
	move(1, 0);
	clrtoeol();
	namecomplete("�ƻs��K�Q�װϡG", xboard);
	if (*xboard == '\0' || !haspostperm(xboard))
		return FULLUPDATE;
	bzero(&xfile, sizeof(xfile));
	sprintf(xfname, POST_CROSSPOST,	fileinfo->title);
	ans = getans(2, 0, xfname, 'y');
	if (ans == 'n')
		return FULLUPDATE;
	if (ans == 'l')
		xfile.sended = POST_LOCAL;
        sprintf(fname, "boards/%s/%s", currboard, fileinfo->filename);
	if ((fileptr = fopen(fname, "r")) == NULL)
		return FULLUPDATE;
       	xfile.accessed[usernum] = FILE_READ|FILE_OWND;
	sprintf(xfname, "boards/%s/", xboard);
	buildfile(xfname);
	strcpy(xfile.filename, xfname);
	sprintf(xfname, "boards/%s/%s", xboard, xfile.filename);
	strncpy(xfile.sender, cuser.userid, STRLEN);
	sprintf(xfile.title, "%s", fileinfo->title);
	strcpy(save_title, xfile.title);

	if ((xptr = fopen(xfname, "w")) == NULL)
	{
		fclose(fileptr);
		return FULLUPDATE;
	}

        if (ans != 'e')
	{
		strcpy(linebuf, currboard);
		strcpy(currboard, xboard);
		write_header(xptr);
		strcpy(currboard, linebuf);
	}

	filetime = atol(fileinfo->filename+2);
        if (filetime > 740000000)
                date = Ctime(&filetime) + 4;
        else
                date = Ctime(&filetime) + 20;

	fprintf(xptr, "[ ��������� %s �Q�װ� ]\n", currboard);
	fprintf(xptr, "[ �����@�̬O: %s ]\n", fileinfo->sender);
	fprintf(xptr, "[ �o���ɶ���: %s ]\n\n", date);

        while (fgets(linebuf, sizeof(linebuf), fileptr) != NULL) 
	{
		if (ignore)
		{
			if (strstr(linebuf, "\n") == linebuf)
				ignore = NA;
			continue;
		}
		fprintf(xptr, "%s", linebuf);
	}

        fclose(fileptr);
	fclose(xptr);
   	in_mail = NA;
	savemode = uinfo.mode;
	changemode(POSTING, YEA);
	if (ans=='E' || ans=='e')
		aborted = vedit(xfname, YEA);
	else
		aborted = NA;
	changemode(savemode, NA);
	clear();

	if (aborted == LOCALSAVE)
	{
		xfile.sended = POST_LOCAL;
		aborted = NA;
	}

	if (aborted)
	{
		pressreturn();
		clear();
                return FULLUPDATE;
	}

	if (append_record(strcat(bfile(xboard), FHDIR), (char *)&xfile, 
		sizeof(xfile)) == -1)
	{
		pressreturn();
		clear();
		return FULLUPDATE;
	}
	prints(NA, "File Posted\n");
	cuser.numposts++;
	UPDATE;
	pressreturn();

	return FULLUPDATE;
}

int	reply_post(ent, fileinfo, direct)
int	ent;
fhd	*fileinfo;
char	*direct;
{
        clear();
        strncpy(currfile, fileinfo->filename, STRLEN);
        update_file(direct, sizeof(fhd), ent, cmpfilename, 
		updatefile);
        do_reply(fileinfo);

        return FULLUPDATE;
}

#ifdef INTERNET_EMAIL
int	forward_post(ent, fileinfo, direct)
int	ent;
fhd	*fileinfo;
char	*direct;
{
	mhd	mailinfo;

	convert_mail(fileinfo, &mailinfo);
	return(mail_forward(ent, &mailinfo, direct));
}
#endif

one_key	read_comms[] =
{
	CTRL('P'), 	read_do_post, 
	'A', 		b_vote_maintain, 
	'D', 		del_range, 
	'E', 		edit_post, 
#ifdef INTERNET_EMAIL
	'F', 		forward_post, 
#endif
	'M', 		move_post, 
	'O', 		b_results, 
	'R', 		reply_post, 
	'S', 		sequential_read, 
	'V', 		b_vote, 
	'a', 		cook_announce, 
	'd', 		del_post, 
	'h', 		mainreadhelp, 
	'm', 		mark_post, 
	'r', 		read_post,
	'\n',		read_post,
	'\r',		read_post,
	' ',		read_post, 
	KEY_RIGHT,	read_post,
	's', 		do_select, 
	'T', 		title_change, 
	'x', 		cross_post, 
	'z', 		unread_post, 
	CTRL('J'), 	mainreadhelp, 
	'\t', 		read_faq, 
	'\0', 		NULL, 
};

int	Read(void)
{
	int	savemode;

	if (!selboard)
	{
		move(2, 0);
		prints(NA, "�Х���ܰQ�װ�");
		return -1;
	}

	savemode = uinfo.mode;
	uinfo.comp = YEA;
	strncpy(uinfo.ptcb, currboard, 20);
	changemode(READING, YEA);
	in_mail = NA;

	while (i_read(strcat(bfile(currboard), FHDIR), readtitle, readdoent,
		&read_comms[0], CTRL('P'), ASK_POST_DEFAULT, 'y',
		get_num_records, get_records) == REDOIREAD);

        uinfo.comp = NA;
	bzero(uinfo.ptcb, sizeof(uinfo.ptcb));
	changemode(savemode, NA);

	return 0;
}
