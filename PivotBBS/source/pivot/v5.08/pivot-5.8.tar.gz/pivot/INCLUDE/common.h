#define	MESSAGE 	1
#define	CHG_NICK	2
#define	CHG_ROOM	3
