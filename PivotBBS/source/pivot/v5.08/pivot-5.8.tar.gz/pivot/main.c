/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)main.c   5.08 3/19/95 (C) 1993 University of \
NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include "bbs.h"

jmp_buf	byebye;

int	talkrequest = NA,
	bfinger = 0,
	started = 0,
	utmpent = -1,
	refscreen = NA,
	dumb_term = YEA;
FILE	*ufp;
char	lasthost[STRLEN],
	BoardName[STRLEN];
usinfo	uinfo;
time_t	lastlogin;

int	u_enter(from)
char	*from;
{
	char	myhome[STRLEN];
	ucrc	crcidx;
	
	get_record(CRCIDX, (char *)&crcidx, sizeof(ucrc), usernum);
	uinfo.userlevel = cuser.userlevel = crcidx.level;
	uinfo.active = YEA;
	uinfo.pid    = getpid();

	strcpy(lasthost, cuser.lasthost);
	strcpy(cuser.lasthost, from);
	cuser.lasthost[15] = '\0';

	bcopy(&cuser.lastlogin, &lastlogin, sizeof(lastlogin));
	time(&cuser.lastlogin);

	cuser.numlogins++;

	UPDATE;

	if (HAS_PERM(PERM_LOGINCLOAK))
		uinfo.invisible = HAS_SET(SET_CLOAK);
	else
		uinfo.invisible = NA;
	uinfo.sockactive = NA;
	uinfo.sockaddr = 0;
	uinfo.destuid = 0;
	uinfo.mode = LOGIN;
	uinfo.pager = !HAS_SET(SET_PAGER);
	uinfo.allpager = !HAS_SET(SET_ALLPAGER);
	uinfo.comp = NA;
	bzero(uinfo.ptcb, sizeof(uinfo.ptcb));
	uinfo.uid = usernum;
	strcpy(uinfo.userid, cuser.userid);
	strcpy(uinfo.realname, cuser.realname);
	strcpy(uinfo.username, cuser.username);
	strcpy(uinfo.termtype, cuser.termtype);
	bcopy(&cuser.lastlogin, &uinfo.lastlogin, sizeof(time_t));
#ifdef LIST_IDLE_TIME
	strcpy(uinfo.ttyname, (char *)ttyname(0));
#endif
	strncpy(uinfo.from, from, 20);
	utmpent = getnewutmpent(&uinfo);

	sprintf(myhome, PATH_USER, cuser.userid);
	if (access(myhome, R_OK))
		mkdir(myhome, 0700);
}

int	cmpuids(uid,up)
char	*uid;
userec	*up;
{
	return !strncmpi(uid,up->userid,sizeof(up->userid));
}

int	cmpuids2(unum, urec)
int	unum;
usinfo	*urec;
{
	return ((unum == urec->uid) && (urec->pid != uinfo.pid));
}

void	abort_bbs()
{
	time_t	ti;

	if (started)
		logit(PATH_USIES, "AXXED %-10s %-20s", cuser.userid,
			cuser.username);

	exit(0);
}

int	new_locate(void)
{
	int	fd,
		ret = -1,
		size,
		locid;
	userec	info;

	if ((fd = open(PASSFILE, O_RDWR|O_CREAT, 0600)) == -1)
	{
		perror("open");
		return -1;
	}

	size = sizeof(userec);

        for (locid = 1; locid <= MAXUSERS; locid++)
        {
                bzero(&info, sizeof(userec));
                if (get_record(PASSFILE, (char *)&info, size, locid) ||
                        info.userid[0] == '\0')
                {
			ret = locid;
                        strcpy(info.userid, "new");
                        time(&info.reg_date);
                        substitute_passwd(PASSFILE, &info, YEA, locid);
                        break;
                }
        }

	return ret;
}

int	getnewuserid(void)
{
	int	locid;

	if ((locid = new_locate()) <= 0)
	{
		prints(NA, "%s", REGISTER_SEARCH);
		del_unused();
		locid = new_locate();
	}
	return locid;
}

#ifdef LOGINASNEW
int	register_new(from)
char	*from;
{
	char	passbuf[PASSLEN],
		account[STRLEN],
		*s;
	int	allocid,
		regist,
		err = 0;
	userec	new;
	ucrc	crcidx;

	bzero(&new, sizeof(new));
	allocid = getnewuserid();

	if (allocid >= MAXUSERS || allocid <= 0)
	{
		more(NEWFULL, YEA);
		exit(1);
	}
	more(NEWUSER, NA);

	while (regist = i_userid(0, 1, new.userid))
	{
		if (regist > 0)
		{
			prints(NA, "�b���w�Q�ӽШϥ�\n");
			continue;
		}
		if (regist < 0)
		{
			if (regist == -2)
				err = 4;
			if (regist == -1)
				prints(NA, "���ŦX�ӽбb���W�w\n");
			if (++err < 3)
				continue;
			bzero(&new, sizeof(new));
			substitute_passwd(PASSFILE, &new, YEA, allocid);
			printf("Register Aborted!!\n");
			reset_tty();
			exit(1);
		}
		break;
	}
	i_passwd(0, 1, &new, from);
	i_username(0, 1, new.username);
	i_email(0, 1, new.email);
#ifdef REALINFO
	i_realname(0, 1, new.realname);
	i_address(0, 1, new.address);  
#endif
	new.userset = SET_DEFAULT;
	time(&new.lastlogin);
	new.reg_date = new.mod_email = new.lastlogin;
	crcidx.level = new.userlevel = PERM_DEFAULT;
	new.protocol = 0;
	i_terminal(0, 1, &new);
	strcpy(account, new.userid);
	crcidx.crcnum = GetStrCrc(account);
	crcidx.checksum = new.checksum = GetStrCrc(account) + new.reg_date;
	resolve_ucache( 1 );

	if (substitute_passwd(PASSFILE, &new, YEA, allocid))
	{
		fprintf(stderr,"too much, good bye!\n");
		exit(1);
	}
	bcopy(&new, &cuser, sizeof(userec));
	
	if (allocid != getuser(new.userid))
	{
		fprintf(stderr,"User failed to create\n");
		exit(1);
	}
	sprintf(passbuf, PATH_USER, new.userid);

	if (mkdir(passbuf, 0700) == -1)
	{
		bzero(&new, sizeof(new));
		substitute_passwd(PASSFILE, &new, YEA, allocid);
		fprintf(stderr, ERR_REG_NOSPACE, ADMIN);
		sleep(5);
		exit(0);
	}
#ifdef	IDENTIFY_EMAIL
	logit(LOG_NEWUSER, "register: %s %s %d", new.userid,
		new.email, new.checksum);
#endif
	return allocid;
}
#endif

void	bbs_system_init(getin)
int	getin;
{
	char	genbuf[STRLEN];
	int	users;

#ifndef lint
	signal(SIGHUP,(void *)abort_bbs);
	signal(SIGINT,SIG_IGN);
	signal(SIGQUIT,SIG_IGN);
	signal(SIGPIPE,SIG_IGN);

#ifdef DOTIMEOUT
	init_alarm();
#else
	signal(SIGALRM,SIG_IGN);
#endif
	signal(SIGTERM,SIG_IGN);
	signal(SIGURG,SIG_IGN);
	signal(SIGTSTP,SIG_IGN);
	signal(SIGTTIN,SIG_IGN);
	signal(SIGTTOU,SIG_IGN);
	signal(SIGUSR1,(void *)talk_request);
	signal(SIGUSR2,SIG_IGN);
#endif
	users = num_active_users();
	printf("\n�ثe���W�H�� [%d/%d]\n", users, MAXACTIVE);
	if (!getin && users >= MAXACTIVE)
	{
		if ((ufp = fopen("boot.off","r")) == NULL)
		{
			fprintf(stderr,"\n%s\n%s\n",
				"Sorry, BBS system is full.(�ثe�t�κ���)",
				"Call again later.(�еy��A���J)");
		}
		else
		{
			while (fgets(genbuf,256,ufp) != NULL)
				fprintf(stderr,"%s",genbuf);
		}
		exit(-1);
	}
}

void	u_exit()
{
	int	f1 = 0,
		f2 = 0;

	uinfo.active = NA;
	uinfo.pid = 0;
	uinfo.invisible = YEA;
	uinfo.sockactive = NA;
	uinfo.sockaddr = 0;
	uinfo.destuid = 0;
	update_utmp();
}

int	multi_user_check()
{
	usinfo	uin;
	char	buffer[40];
	time_t	ti;
	int	ans;
	
	if (!strcmpi(GUEST, cuser.userid))
		return 0;
	if (!search_ulist(&uin, cmpuids2, usernum))
		return 0;

	if (!uin.active || (kill(uin.pid,0) == -1))
		return 0;

	prints(YEA, "\n%s �z�n\n", cuser.userid);
#ifndef ALLOW_MULTI_LOGINS
	if (!HAS_PERM(PERM_MULTILOG))
		prints(NA, "���������\\�P�@�ӱb���P�ɦh���n��\n");
#endif
	prints(NA, "�]���z�w�g�P�ɵn���h��, �аݱz�O�_�n�N��L�n���R��");
	ans = getans(0, 0, "(Yes, or No) [N]: ",'n');

	if (ans == 'y')
	{
		uinfo.pid = getpid();
		search_ulist( &uin, kickall, usernum);
	}
#ifndef ALLOW_MULTI_LOGINS
	else
	{
		if (!HAS_PERM(PERM_MULTILOG))
			goodbye();
	}
#endif
}

int	kickall(unum,uin)
int	unum;
usinfo	*uin;
{
	if ((uin->uid == unum) && (uin->pid != uinfo.pid) && uin->pid &&
		(kill(uin->pid,0) != -1))
	{
		kill(uin->pid,SIGHUP);  
		logit(PATH_USIES, "KICK %-10 %-20", uin->userid,
			uin->username);
	}
	return 0;
}

int	account_disabled(userid)
char	*userid;
{
	FILE	*fp;
	char	buf[STRLEN];
	int	blen;

	if ((fp = fopen(".disabled", "r")) == NULL)
		return 0;
	while (fgets(buf, STRLEN, fp) != NULL)
	{
		blen = strlen(buf);
		if (buf[blen-1] == '\n')
			buf[--blen] = '\0';
		if (!strncmpi(buf, userid, blen))
		{
			fclose(fp);
			return 1;
		}
	}
	fclose(fp);

	return 0;
}

void	myname()
{
	int	fd,
		cc;
	char	*t;

	if ((fd = open(NAMEFILE,O_RDONLY)) > 0)
	{
		cc = read(fd, BoardName, STRLEN);

		BoardName[cc] = '\0';

		if (t = (char *)index(BoardName,'\n'))
			*t = '\0';
		close(fd);
	}
	else
		strcpy(BoardName, BOARDNAME);
}

void	login(getin, nu, from)
int	getin,
	nu;
char	*from;
{
	int	abort = 0,
		err = 0;
	char	uid[IDLEN+1];
	time_t	ti;

	for (;;)
	{
		prints(NA, "\n�w��Y�{%s\n", BOARDNAME);
#ifdef LOGINASNEW
		prints(NA, "���[�b��: %s ,��J new �ӽбb��\n\n", GUEST);
#else
		prints(NA, "���[�b��: %s\n\n", GUEST);
#endif
		usernum = i_userid(0, USER_LOGIN, uid);
		if (usernum == -2)
		{
#ifdef LOGINASNEW
			usernum = register_new(from);
			break;
#else
			prints(NA, "%s\n%s\n",
				"���������ѽu�W���U!",
				"�ӽбM�u: root@bbs.nchu.edu.tw");
			oflush();
			err++;
			continue;
#endif
		}
		if (usernum <= 0)
		{
			if (++err > 3)
			{
				prints(NA, "Login Aborted!!\n");
				oflush();
				reset_tty();
				exit(0);
			}
			continue;
		}

		bcopy(&muser, &cuser, sizeof(userec));
		if (!stricmp(cuser.userid, GUEST))
		{
			logattempt(cuser.userid, from, YEA);
			break;
		}
		if (i_passwd(0, 0, &cuser, NULL))
		{
			logattempt(cuser.userid, from, NA);
			if (++err > 3)
			{
				more(PATH_LOGINERR, YEA);
				exit(1);
			}
			continue;
		}
		break;
	}
	logattempt(cuser.userid, from, YEA);
}

finish_login(nu, from)
int	nu;
char	*from;
{
	int	numbad,
		ans;

	if (account_disabled(cuser.userid))
	{
		prints(NA, "%s\n%s %s %s %s\n", "���b���w�Q�޲z������.",
			"�Х�", GUEST, "�b���q��", ADMIN);
		oflush();
		reset_tty();
		exit(1);
	}

	u_enter(from);
#ifdef SYSOP_LEVEL
	if (!stricmp(cuser.userid, ADMIN))
		cuser.userlevel = ~0;
#endif
#ifdef GUEST
	if (!stricmp(cuser.userid, GUEST))
		cuser.userlevel = PERM_GUEST;
#endif
	multi_user_check();

	if ((dumb_term = term_init(cuser.termtype)) == -1)
	{
		prints(NA, "�L�k�]�w�׺ݾ�, �۰���� vt100 ��\n");
		dumb_term = term_init("vt100");
	}
	logit(PATH_USIES, "ENTER %-10s %-20s %-16s", cuser.userid,
		cuser.username, from);
	if (nu)
		changemode(NEW, NA);

       	started = 1;
       	initdsk();
       	scrint = 1;
       	clear();
       	move(0,0);

/* MARK !! just for saving some time !! */ 
	
	if (!HAS_PERM(PERM_TRUE)) 
       		more(WELCOME, YEA);


	if (HAS_SET(SET_DISNOTE))
		more (MOTD, NA);
	else
	{
		more(MOTD, YEA);
		more(NOTE, NA);
	}
	move(t_lines-1, 0);
	clrtoeol();
	prints(YEA, "[1;32;44m[�W���n���a�I] %-23.23s [�W���n���ɶ�] %-24.24s[m",
		cuser.lasthost, ctime(&cuser.lastlogin));
       	if ((numbad = countattempts()) <= 0)
	{
		if (numbad < 0)
			showattempts(NA);
		egetch();
	}
	else
	{
		refresh();
		sprintf(genbuf, "[1;34;42m[�`�N] �O�_��\\ %2.2d �������\\�� %-48s[m",
			numbad, "Login �O�� (Y/N)? [Y]: ");
		ans = getans(t_lines-2, 0, genbuf, 'y');

		if (ans == 'n')
			showattempts(NA);
		else
			showattempts(YEA);
	}
}

int	init_perm(argc, argv)
int	argc;
char	**argv;
{
/*
	if (argc < 2) {
		printf("Usage: bbs [s|h [fromhost]|b|u|l|a]\n");
		exit(0);
	}
*/
	if (argc == 2)
	{
		switch(*argv[1])
		{
#ifdef FLAG_MAIN_B
			case 'b': /* Board Status Check */
				BoardStatus();
		  		exit(0);
#endif
#ifdef FLAG_MAIN_U
		  	case 'u': /* User status check */
				UserStatus();
				exit(0);
#endif
			case 's':
				return YEA;
#ifdef FLAG_MAIN_L
			case 'l':
				bfinger = 1;
				dumb_user_list();
				exit(0);
#endif
#ifdef FLAG_MAIN_A
			case 'a':
				list_all_users();
				exit(0);
#endif
			default:
				fprintf(stderr,"UNKNOWN OPTION\n");
	       			exit(0);
		}
	}

	return NA;
}

void	main(argc, argv)
int	argc;
char	**argv;
{
	char	buff[STRLEN],
		fromhost[20];
	int	ans,
		i=0,
		cmd,
		users,
		getin,
		nu;
	time_t	ti;

#ifdef SINGLE
	char	c[256];

	gethostname(c,256);
	if (strcmp(c,SINGLE))
	{
		printf("Not on a valid machine! (�ϥΪ̨ӷ�����)\n");
		exit(-1);
	}
#endif
	getin = init_perm(argc, argv);

	if (argc >= 3)
		strncpy(fromhost, argv[2], STRLEN);
	else
		strcpy(fromhost, MYHOSTNAME);

#ifdef	COLOR_ISSUE
	cuser.userset |= SET_ANSIMODE;
#endif
	more(ISSUE, NA);

	bbs_system_init(getin);
	if (setjmp(byebye))
	{
		if (started)
		{
			if ((ufp = fopen("usies","a")) != NULL)
			{
				time(&ti);
				fprintf(ufp, "ABORT %-10s %-20s %s",
					cuser.userid,
					cuser.username,
					ctime(&ti));
				fflush(ufp);
				u_exit();
				fclose(ufp);
		  	}
		}
		printf("goodbye\n");
		exit(0);
	}
	get_tty();
	init_tty();
	myname();

	login(getin, nu, fromhost);
	finish_login(nu, fromhost);

	m_init(cuser);

#ifdef SYSV
	if (get_semaphore() == -1)
	{
		printf("Can't get semaphore! Exiting...\n");
		exit(1);
	}
#endif
	cmd = (chkmails(cuser,NA)) ?  'm' :
				 (nu || !HAS_PERM(PERM_BASIC)) ? 'h' : 'd';

	changemode(MMENU, NA);

	docmd("[�D�ؿ�]","�ާ@����: ",cmd, cmdlist, boardmargin);
	exit(0);
}

char	*boardmargin()
{
	static	char	buf[STRLEN];
	int	fp;

	if (selboard)
		sprintf(buf,"�ثe�Q�װ�: %s",currboard);
	else if (cuser.defboard)
		strcpy(currboard, cuser.defboard);

	if (!getbnum(currboard))
	{
		if ((fp = open(DEFBOARDFILE, O_RDONLY)) > 0)
		{
			char	*t;
			int	cc = read (fp, currboard, STRLEN);

			currboard[cc] = '\0';
			if (t = (char *)index(currboard,'\n'))
				*t = '\0';
			close(fp);
		 }
		else
			strcpy(currboard, DEFAULTBOARD);
	}

	if (getbnum(currboard))
	{
		selboard = 1;
		sprintf(buf,"�ثe�Q�װ�: %s",currboard);
	}
	else
		sprintf(buf,"�ثe����w�Q�װ�");

	return buf;
}

int	egetch()
{
	char	c;
	int	rval;

	for(;;)
	{
		if (talkrequest)
		{
			talkreply();
			refscreen = YEA;
			return -1;
		}
		rval = igetkey();
		if ( rval != CTRL('L') )
			break;
		redodsk();
	}
	refscreen = NA;

	return rval;
}

void	menu_draw(cmdtitle, marginnote)
char	*cmdtitle,
	*(*marginnote)();
{
	char	buf[STRLEN],
		buff[STRLEN];

#ifdef VOTE
	char	votepath[STRLEN];
	int	vote = NA,
		pos;
	bhd	fh;

	pos = search_board(&fh,ADMIN);

	sprintf(votepath, PATH_VOTEADM);
	if (HAS_PERM(PERM_VOTE) && !access(votepath, R_OK) && 
		!(fh.accessed[usernum] & VOTED))
	{
		vote = YEA;
	}

	strcpy(buf, (chkmails(cuser,NA)) ? "[�s�H���F]" :
		(vote ? "[�벼���M��]" : BoardName));
#else
	strcpy(buf, (chkmails(cuser,NA)) ? "[�s�H���F]" :
		BoardName);
#endif
	strcpy(buff, (*marginnote)());
	prints(NA, "\n");
	move(0, 0);
	clrtoeol();
	prints(NA, "=%s=", cmdtitle);
	move(0, (80+strlen(cmdtitle)-strlen(buf)-strlen(buff))/2);
	prints(NA, "%s", buf);
	move(0,50);
	prints(NA, "%28s\n", buff);
}

int	search_cmd(total, cmdtab, cmd, currcmd)
int	total,
	cmd,
	*currcmd;
cmds	*cmdtab;
{
	int	i;

	for(i=1; i<=total; i++)
	{
		if ((*(cmdtab[i].cmdname) & ~0x20) == (cmd & ~0x20))
		{
			if ((cmdtab[i].cmdname == NULL) || ((*currcmd == i) &&
				!refscreen) || (!HAS_PERM(cmdtab[i].level)))
				bell(1);
			else
			{
				*currcmd = i;
				break;
			}
		}
	}
}

int	docmd(cmdtitle, cmdprompt, firstcmd, cmdtab, marginnote)
char	*cmdtitle,
	*cmdprompt,
	*(*marginnote)();
int	firstcmd;
cmds	*cmdtab;
{
	int	lastcmd,
		currcmd,
		total,
		promptlen,
		reprint,
		err,
		line,
		lastcmdlen,
		currcmdlen,
		cmd,
		find,
		i=0,
		j,
		plus,
		start,
		end,
		ans;

	refscreen = YEA;
	promptlen = strlen(cmdprompt);
	cmd = firstcmd;

	if (cmdtab[0].level == 0)
		for(i=1; cmdtab[i].cmdname != NULL; i++, cmdtab[0].level++);

	total = cmdtab[0].level;
	if (!HAS_SET(SET_AUTOHELP))
	{
		move(2,0);
		clrtobot();
	}

	do
	{
		move(2,0);
		clrtoeol();
		switch(cmd)
		{
			case CTRL('T'):
			if (HAS_SET(SET_AUTOHELP))
			{
				move(2,0);
				prints(NA, "Auto Help Status Turn OFF �۰���ܨ�U����\n");
				cuser.userset &= (~(1 << 0));
				move(line,0);
				prints(NA, "  ");
			}
			else
			{
				move(2,0);
				prints(NA, "Auto Help Status Turn ON �۰���ܨ�U�}��\n");
				cuser.userset |= (1 << 0);
				refscreen = YEA;
				line = 4;
			}
       	   		break;

	   		case KEY_UP:
			case KEY_HOME:
			case KEY_PGUP:
	   		case KEY_DOWN: 
			case KEY_END: 
			case KEY_PGDN:
			switch(cmd)
			{
				case KEY_UP:
					plus = -1;
					start = currcmd + total -1;
					end = currcmd;
					break;
				case KEY_DOWN:
					plus = 1;
					start = currcmd+1;
					end = currcmd +total;
					break;
				case KEY_HOME:
				case KEY_PGUP:
					plus = 1;
					start = 1;
					end = total;
					break;
				case KEY_END:
				case KEY_PGDN:
					plus = -1;
					start = total;
					end = 1;
					break;
			}
			for(j = start; j != end; j += plus)
			{
				if (HAS_PERM(cmdtab[i =
					(i = j%total) == 0 ? total : i].level))
				{
					currcmd = i;
					break;
				}
			}
			break;

	   		case KEY_LEFT:
			if (uinfo.mode == MMENU)
			{
				Goodbye();
				break;
			}
			else
			{
				cmd = 'e';
				search_cmd(total, cmdtab, cmd, &currcmd);
				cmd = '\n';
			}

	   		case '\n':
	   		case '\r':
	   		case KEY_RIGHT:
	   			if ((err = (*cmdtab[currcmd].cmdfunc)()) ==
					QUIT)
					return;
				if (err)
		  			cmd = *(cmdtab[currcmd].errcmd);
				else
		  			cmd = *(cmdtab[currcmd].nextcmd);
				refscreen = YEA;

	   		default:
				search_cmd(total, cmdtab, cmd, &currcmd);
				break;
		}
		if (refscreen)
		{
			menu_draw(cmdtitle, marginnote);
			move(1,0);
			prints(NA, "%s", cmdprompt);
		}
		if (dumb_term)
		{
			if (refscreen)
			{
				refscreen = NA;
				prints(NA, "%s", cmdtab[currcmd].cmdname);
				lastcmd = currcmd;
				continue;
			}
			if (lastcmd == currcmd)
				continue;
			backspace(strlen(cmdtab[lastcmd].cmdname));
			prints(NA, "%s", cmdtab[currcmd].cmdname);
			lastcmd = currcmd;
		}
		else
		{
			if (HAS_SET(SET_AUTOHELP))
			{
				if (refscreen)
					cmds_help(cmd, cmdtab);
				move(line, 0);
				prints(NA, "  ");
				for(i=1, line=4; i<=total; i++)
					if (HAS_PERM(cmdtab[i].level))
						if (i == currcmd)
							break;
						else
							line++;
				move(line,0);
				prints(NA, "=>");
			}
			refscreen = NA;
			move(1, promptlen);
			clrtoeol();
			prints(YEA, "%s", cmdtab[currcmd].cmdname);
		}
    	}
	while (((cmd = egetch()) != EOF) || refscreen);

	abort_bbs();
}

int	m_adduser()
{
	char	passbuf[PASSLEN],
		*s;
	int	ans,
		allocid,	
		saveunum,
		line = 1;
	userec	newuser,
		saveuser;
		
	clear();
	bcopy(&cuser, &saveuser, sizeof(saveuser));
	bzero(&newuser, sizeof(newuser));
	saveunum = usernum;
	allocid = getnewuserid();
	if (allocid >= MAXUSERS || allocid <= 0)
	{
		prints(NA, "No space for new users on the system!\n");
			sleep(1);
			return 0;
	}
	prints(YEA, "Add New User");
	clrtoeol();

	newuser.userlevel = PERM_DEFAULT;
	if (i_userid(line++, 2, newuser.userid))
		return 0;
	i_passwd(line++, 1, &newuser, NULL);
	i_username(line++, 1, newuser.username);
	i_email(line++, 1, newuser.email);
#ifdef REALINFO
	i_realname(line++, 1, newuser.realname);
	i_address(line++, 1, newuser.address);
#endif
	i_terminal(line++, 1, &newuser);
	bcopy(&saveuser, &cuser, sizeof(cuser));
	usernum = saveunum;
	ans = getans(++line,0,"Add this account (Y/N)? [Y]: ",'y');

	if (ans == 'n')
	{
		newuser.userid[0] = '\0';
		substitute_passwd(PASSFILE, &newuser, YEA, allocid);
		prints(NA, "New account NOT created.\n");
		pressreturn();
		clear();
		return(0);
	}

	if (substitute_passwd(PASSFILE, &newuser, YEA, allocid) == -1)
	{
		prints(NA, "No space in password file!\n");
		pressreturn();
		clear();
		return 0;
	}
	prints(NA, "\nNew Account Created\n");
	resolve_ucache( 1 );
	pressreturn();
	clear();
	return 0;
}

void	logattempt(uid, frm, badid)
char	*uid,
	*frm;
int	badid;
{
	char	buf[BADLOGINSTRSZ+1];
	char	*timestr;
	time_t	t;

	time(&t);
	timestr = Ctime(&t);
	uid[12] = '\0';
	sprintf(buf, "%-12s %-32s %-16s %c	       \n", uid, timestr,
		frm, badid? 'Y' : 'N');
	append_record(BADLOGINFILE, buf, BADLOGINSTRSZ);

	return;
}

int	countattempts()
{
	int	fd,
		cnt = 0;
	char	buf[BADLOGINSTRSZ];

	if (!HAS_PERM(PERM_BASIC))
		return -1;    /* don't show the bad login attempts */
	if ((fd = open(BADLOGINFILE, O_RDONLY)) == -1)
		return 0;
	while (read(fd, buf, BADLOGINSTRSZ) == BADLOGINSTRSZ)
	{
		if (!strncmp(buf, cuser.userid,
			strlen(cuser.userid)) && buf[63] == 'N')
		{
			cnt++;
		}
	}
	close(fd);

	return cnt;
}

void	showattempts(really)
int	really;
{
	int	fd,
		ln = 1;
	char	buf[BADLOGINSTRSZ];

	if ((fd = open(BADLOGINFILE, O_RDWR)) == -1)
		return;

	if (really)
		clear();

	while (read(fd, buf, BADLOGINSTRSZ) == BADLOGINSTRSZ)
	{
		if (!strncmp(buf, cuser.userid,
			strlen(cuser.userid)) && buf[63] == 'N')
		{
			buf[63] = 'Y';
			flock(fd, LOCK_EX);
			if (lseek(fd, -BADLOGINSTRSZ, L_INCR) != -1)
				write(fd, buf, BADLOGINSTRSZ);
			flock(fd, LOCK_UN);
			if (really)
			{
				buf[45] = buf[62] = '\0';
				if (ln >= t_lines)
				{
					prints(YEA, "-- More --\n");
					igetch();
					clear();
					ln = 1;
				}
				prints(NA, "�� %s �� %s �������\\�W���O��\n",
					&buf[46], &buf[13]);
				ln++;
			}
		}
	}

	close(fd);

	if (really)
	{
		pressreturn();
		clear();
	}

	return;
}
