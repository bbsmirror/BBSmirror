/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef	lint
static  char    sccsid[] = "@(#)info.c  5.08 3/19/95 (C) 1993 University of \
NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include "bbs.h"

/*  mode: uinfo.mode  >=0 �ɧ�� mode, -1 �ɦ^�s�W���� mode,
 *  page: uinfo.pager
 *  cloak: uinfo.invisible
 *  complete: uinfo.comp ULIST �PŪ�O�_���l�� string
 *  ptcb: ULIST �PŪ�Ϊ� string
 */
int	changemode(mode, comp)
int	mode,
	comp;
{
        uinfo.mode = mode;
	uinfo.comp = comp;
	update_utmp();
}

int	user_display(u, id)
userec	*u;
int	id;
{
	int	exper,
		dble;

	move(3,0);
	clrtobot();

	exper = count_exper(u, &dble);
	prints(NA, "�N�� Userid  : %s [%d|%d]\n", u->userid, id, exper);
	prints(NA, "�ʺ� UserName: %s\n", u->username);
	prints(NA, "�u��m�W     : %s\n", u->realname);
	prints(NA, "�~�����}     : %s\n", u->address); 
	prints(NA, "�q�l�l��H�c : %s\n", u->email);   
	prints(NA, "�׺ݾ��κA   : %s\n", u->termtype);
	prints(NA, "�W������     : %d ��\n", u->numlogins);
	prints(NA, "�峹�ƥ�     : %d\n", u->numposts);
	prints(NA, "�ϥ�ñ�W��   : %d\n", u->signum+1);
	prints(NA, "�̪���{��� : %s", ctime(&u->lastlogin));
	prints(NA, "��%s�� �i%s�j�����T�{ %s", u->userid,
		(u->userlevel & PERM_TRUE)? "�w�g�q�L" : "�S���q�L",
		ctime(&u->reg_date));
	return 0;
}

int	checkid(loginid)
char	*loginid;
{
        char	*s;
        int	i;

        if (loginid[0] == '\0' || strlen(loginid) < 1)
                return YEA;
        for (i=0, s=loginid; *s != '\0'; s++, i++)
	{
                if ((isdigit(*s) && i==0) || !isalnum(*s))
                        return YEA;
        }
        return NA;
}

int	checkbrd(boardid)
char	*boardid;
{
        char	*s;
        int	i;

        if (boardid[0] == '\0' || strlen(boardid) < 1)
                return YEA;
        for (i=0, s=boardid; *s != '\0'; s++, i++)
	{
                if (!isprint(*s))
                        return YEA;
        }
        return NA;
}

int	checkpwd(userid, passwd)
char	*userid,
	*passwd;
{
        char	*s;

        if ((strlen(passwd) < 4) || !stricmp(userid, passwd))
                return YEA;

        for (s=passwd; *s != '\0'; s++)
                if (isalpha(*s))
                        return NA;
        return YEA;
}

int	checkemail(mailbuf)
char	*mailbuf;
{
	if (strstr(mailbuf, MYHOSTNAME) || !strchr(mailbuf, '@') ||
		strstr(mailbuf, MYIPADDR) || (strlen(mailbuf) < 14) ||
		strstr(mailbuf, ".bbs@") || (*mailbuf == '\0'))
	{
		return YEA;
	}
	return NA;
}

/*
 * line: ��ܦ��
 * new : ���� 1 ��, ���s�ӽЪ��b��;
 *	 ���� 0 ��, ���n���ˬd;
 * user: �� user ��ƨӷ�
 */

int	i_userid(line, new, user)
int	line,
	new;
char	*user;
{
	char	buf[IDLEN+2];
	int	unum = 0,
		err = 3;
	userec	tmp;

	bzero(buf, sizeof(buf));

	getdata(line, 0, "��J�b��: ", buf, IDLEN+2, DOECHO, YEA);
	if (buf[0] == '\0')
		return -3;
	if (!stricmp("new", buf))
		return -2;
	if (checkid(buf))
		return -1;

	unum = getuser(buf);

	if (unum)
	{
		strncpy(user, muser.userid, IDLEN+2);
		return unum;
	}
	strncpy(user, buf, IDLEN+2);
	return 0;
}

int	i_passwd(line, new, user, from)
int	line,
	new;
userec	*user;
char	*from;
{
	char	passbuf[PASSLEN],
		checkbuf[PASSLEN];
	int	err = 0;

	while (err < 3)
	{
		bzero(passbuf, sizeof(passbuf));
		getdata(line, 0, "����J�K�X: ", passbuf, PASSLEN,
			NOECHO, YEA);
		if (new && checkpwd(user->userid, passbuf))
		{
			prints(NA, "�z�ҳ]���K�X���X��\n");
			continue;
		}
		if (new != 1)
		{
			if (err = !checkpasswd(user->passwd, passbuf))
			{
				prints(NA, "�z�ҿ�J���K�X���~!!\n");
			}
			if (from)
				logattempt(user->userid, from, !err);
			if (!new)
				return err;
		}
		getdata(line+1, 0, "���ˬd�K�X: ", checkbuf, PASSLEN,
			NOECHO, YEA);
		if (strncmp(passbuf, checkbuf, PASSLEN))
		{
			prints(NA, "�z�ҳ]���K�X�e�ᤣ�P. ");
			if (new == 1)
			{
				prints(NA, "�Э��s�]�w!\n");
				continue;
			}
			else
				return -1;
		}
		else if (new)
		{
			strncpy(user->passwd, genpasswd(passbuf), PASSLEN);
		}
		return 0;
	}
	return err;
}

int	i_terminal(line, new, user)
int	line,
	new;
userec	*user;
{
	char	buf[STRLEN],
		*p = user->termtype;

	while (1)
	{
		getdata(line, 0, "�׺ݾ�����(vt100, ansi..): ", buf, STRLEN,
			DOECHO, YEA);
		if (strlen(buf) < 3)
			if (new)
				strcpy(buf, "vt100");
			else
				return 0;
		if ((dumb_term = term_init(buf)) == -1)
		{
			if (new)
			{
				prints(NA, "���{�ѧA��J������, �Э��].\n");
				continue;
			}
		}
		else
			strcpy(p, buf);
		return 0;
	}
}

int	i_email(line, new, user)
int	line,
	new;
char	*user;
{
	char	buf[STRLEN];

        bzero(buf, sizeof(buf));

        while (1)
	{
                getdata(line, 0, "�����H��a�}: ", buf, STRLEN, DOECHO, YEA);

                if (checkemail(buf))
		{
                        if (new)
				continue;
			return -1;		/* modify aborted! */
                }
		else
                        strcpy(user, buf);
		return 0;			/* modify new email */
        }
}

int	i_changeinfo(line, new, minlen, user, prompt)
int	line,
	new,
	minlen;
char	*user,
	*prompt;
{
	char	buf[STRLEN-40];

	bzero(buf, sizeof(buf));
	while (1)
	{
		getdata(line, 0, prompt, buf, STRLEN, DOECHO, YEA);
		if (strlen(buf) < minlen)
		{
			if (new)
				continue;
		} else
			strncpy(user, buf, STRLEN-40);
		return 0;
	}
}
 
int	i_username(line, new, user)
int	line,
	new;
char	*user;
{
	return i_changeinfo(line, new, MINNICK, user, "�z���ʺ�: ");
}

int	i_realname(line, new, user)
int	line,
	new;
char	*user;
{
	return i_changeinfo(line, new, MINREAL, user, "�u��m�W: ");
}

int	i_address(line, new, user)
int	line,
	new;
char	*user;
{
	return i_changeinfo(line, new, MINADD, user, "�p���a�}: ");
}

int	change_num(line, num, prompt)
int	line,
	num;
char	*prompt;
{
	char	buf[10];
	int	sig;

	getdata(line, 0, prompt, buf, 10, DOECHO, YEA);
	sig = atoi(buf);
	if (sig > 0)
		return sig - 1;
	return num;
}

int	i_logins(line, user)
int	line;
userec	*user;
{
	usint	buf;

}

int	i_posts(line, user)
int	line;
userec	*user;
{
	usint	buf;

}

int	i_signum(line, user)
int	line;
userec	*user;
{
	char	buf[5],
		str[80];
	int	sig;

	sprintf(str, "�ϥβĴX��ñ�W��(1~..)? [%d]: ", user->signum+1);
	user->signum = change_num(line, user->signum, str);
	return 0;
}

void	re_identify(uinfo, uid)
userec	*uinfo;
int	uid;
{
#ifdef	IDENTIFY_EMAIL
	ucrc	c;
	time_t	now;

	time(&now);
	get_record(CRCIDX, (char *)&c, sizeof(ucrc), usernum);
	c.level &= ~PERM_TRUE;
	uinfo->userlevel = c.level;
	uinfo->checksum = c.checksum = c.crcnum + now;
	uinfo->mod_email = now;
	substitute_record(CRCIDX, (char *)&c, sizeof(ucrc), uid);
	substitute_record(PASSFILE, (char *)uinfo, sizeof(userec), uid);
	logit(LOG_NEWUSER, "modify: %s %s %d", uinfo->userid, uinfo->email,
		uinfo->checksum);
#endif
}

int	modify_info(u, unum, acc)
userec	*u;
int	unum,
	acc;
{
	int	i = 15,
		identify = NA,
		ans,
		cuid = YEA;
	char	*pass,
		fieldbuf[STRLEN],
		passbuf[PASSLEN];
	userec	*newinfo;

	user_display(u, unum);
	ans = getans(14, 0,
		"�п�� (1)�ק��� (2)�]�w�K�X (3) �^�W�h�\\��� ==> [3]",
		'3');

	switch(ans)
	{
		 case '1':
			newinfo = (userec *)malloc(sizeof(userec));
			bcopy(u, newinfo, sizeof(userec));
			move(i++, 0); 
			prints(NA, "������ <ENTER> �N���ϥέ�Ӹ�ơC\n"); 

			i_username(i++, 0, newinfo->username);
			i_terminal(i++, 0, newinfo);
			i_signum(i++, newinfo);
			i_realname(i++, 0, newinfo->realname);
			i_address(i++, 0, newinfo->address);
			if (!i_email(i++, 0, newinfo->email) &&
				!HAS_PERM(PERM_ACCOUNTS))
			{
				identify = YEA;
			}
			if (acc)
			{
				cuid = i_userid(i++, 2, newinfo->userid);
				i_logins(i++, newinfo);
				i_posts(i++, newinfo);
			}
			user_display(newinfo, unum);
			ans = getans(13, 0, "�T�w�n��s�W�z���(Y/N)? [N]: ",
				'n');
			if (ans == 'y')
			{
				if (!cuid && acc && strcmp(newinfo->userid,
					u->userid))
				{
					char	from[512],
						to[512];
                
					sprintf(from, PATH_USER, u->userid);
					sprintf(to, PATH_USER, newinfo->userid);
	                		rename(from, to);
            			}
				if (identify)
					re_identify(newinfo, unum);
				substitute_passwd(PASSFILE, newinfo,
					strcmp(u->userid, newinfo->userid) ?
					YEA : NA, unum);
				bcopy(newinfo, u, sizeof(userec));
			}
			else if (!acc)
				dumb_term = term_init(cuser.termtype);
			free(newinfo);
			break;

		case '2':
			if ((HAS_PERM(PERM_SYSOP) && acc) || !i_passwd(i++, 0,
				u, NULL))
			{
				move(i++, 0);
				prints(NA, "�г]�w�s�K�X ==>\n");
				if (!i_passwd(i++, 2, u, NULL))
				{
					substitute_passwd(PASSFILE, u,
						NA, unum);
					prints(NA, "�K�X�]�w���\\, ");
				}
				else
				{
					move(i++,0);
					prints(NA, "��󥻦��K�X�]�w, ");
				}
			}
			break;

		default:
			break;
	}

	prints(NA, "�Ы� Enter �^�W�h�\\���\n");
	pressreturn();
	clear();
	return 0;
}

int	substitute_passwd(filename, rptr, crcflag, id)
char	*filename;
userec	*rptr; 
int	crcflag,
	id;
{
	ucrc	crcidx;

	if (id > MAXUSERS || id < 1)
	{
		clear();
		move(6, 0);
		prints(1, "�D�`��p, ���t�Υ��h�z���ܼv, �H�P�L�k�~��B�@\n");
		move(8, 0);
		prints(1, "�гq�� %s, �i�D�ڭ̱z�O�b�i��󶵾ާ@�ɥ���\n",
			ADMIN);
		move(10, 0);
		prints(1, "���t�Τw�N�z�j��ñ�h, �G�Q�������u\n");
		sleep(20);
		exit(0);
	}
	if (crcflag)
	{
		crcidx.crcnum = GetStrCrc(rptr->userid);
		crcidx.checksum = GetStrCrc(rptr->userid) + rptr->mod_email;  
		crcidx.level = rptr->userlevel;
		substitute_record(CRCIDX, (char *)&crcidx, sizeof(ucrc), id);
	}
	return substitute_record(filename, (char *)rptr, sizeof(userec), id);
}
