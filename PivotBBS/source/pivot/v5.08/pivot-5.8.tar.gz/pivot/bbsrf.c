/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)bbsrf.c   5.08 3/19/95 (C) 1993 University of \
NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include <stdio.h>
#include <sys/types.h>
#include <sys/file.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

#ifdef SYSV
#include <sys/utsname.h>
#include <utmpx.h>
#else
#include <utmp.h>
#endif

#include <pwd.h>
#include "define.h"
#ifdef LIST_IDLE_TIME
#include <string.h>
#endif

#define FBITS 8

#ifndef UNLIMITED_LOAD
#include <nlist.h>
#include <fcntl.h>
#include <stdio.h> 

#define loaddouble(la) ((double)(la) / (1 << FBITS))
#define VMUNIX  "/vmunix"
#define KMEM    "/dev/kmem"
#define MAX_LOAD 50

static struct nlist nlst[] = {
	{ "_avenrun" },
	{ 0 }
};

typedef long load_avg;

get_system_load(si)
double *si;
{ 
	load_avg avenrun[3];
#if defined(LINUX)
    FILE *fp;
    fp = fopen ("/proc/loadavg", "r");
    if (!fp) avenrun[0] = avenrun[1] = avenrun[2] = 0;
    else {
        float av[3];
        fscanf (fp, "%g %g %g", av, av + 1, av + 2);
        fclose (fp);
        avenrun[0] = av[0]; avenrun[1] = av[1]; avenrun[2] = av[2];
    }
#elseif defined(NETBSD)
    getloadavg( avenrun, 3 );
#elseif defined(SunOS)
    struct statstime rs;
    rstat( "localhost", &rs );
    avenrun[ 0 ] = rs.avenrun[ 0 ] / (double) (1 << 8);
    avenrun[ 1 ] = rs.avenrun[ 1 ] / (double) (1 << 8);
    avenrun[ 2 ] = rs.avenrun[ 2 ] / (double) (1 << 8);
#else
	static unsigned long avenrun_offset;
	register int i = 0;
	register double *infoloadp;
	register load_avg *sysloadp;
	long total;
	int kmem;

	if((kmem = open(KMEM, O_RDONLY)) == -1)
		return(-1);
	(void)nlist(VMUNIX, nlst);
	if(nlst[0].n_type == 0)
		return(-1);
	avenrun_offset = nlst[0].n_value;
	if(lseek(kmem, (long)avenrun_offset, L_SET) == -1)
		return(-1);
	if(read(kmem, (char *) avenrun, sizeof(avenrun)) == -1)
		return(-1);
	infoloadp = si;
	sysloadp = avenrun;
	for (i = 0; i < 3; i++)
		*infoloadp++ = loaddouble(*sysloadp++);
	close(kmem);
#endif
}

#endif /* UNLIMITED_LOAD */

#ifdef SYSV
struct utmpx *invis()
{
	static struct utmpx data;
	FILE *fp;
	int flag = 0;
	char *name, *tp;
	struct passwd *pp;

	tp = ttyname(0);
	if(!tp)
		return NULL;
	tp = (char *)index(tp,'/') + 1;
	tp = (char *)index(tp,'/') + 1;
	pp = getpwuid(getuid());
	if(!pp)	{
		fprintf(stderr,"You Don't exist!\n");
		exit(0);
	}
	name = pp->pw_name;
	
	if((fp = fopen(UTMPX_FILE,"r")) == NULL)
		exit(0);

	while(read(fileno(fp),&data,sizeof(struct utmpx))>0) {
		if(data.ut_type != DEAD_PROCESS && !strcmp(tp,data.ut_line)) {
			struct utmpx nildata;

			flag = 1;
			bcopy(&data, &nildata, sizeof(nildata));
#ifdef INVISIBLE
			bzero(nildata.ut_name,8);
			fseek(fp,(long)(ftell(fp) - sizeof(struct utmpx)),0);
			if(write(fileno(fp),&nildata,sizeof(struct utmpx))
				!= sizeof(struct utmpx)); /* NIL IF PROG */
#endif
			fclose(fp);
			return &data;
		}
	}
	fclose(fp);
	return NULL;
}
#else
struct utmp *invis()
{
	static struct utmp data;
	FILE *fp;
	int flag = 0;
	char *name, *tp ;
	struct passwd *pp;
	
	tp = ttyname(0);
	if(!tp)
		return NULL;
	tp = (char *)rindex(tp,'/') + 1;
	pp = getpwuid(getuid());

	if(!pp)	{
		fprintf(stderr,"You Don't exist!\n");
		exit(0);
	}

	name = pp->pw_name;
	
	if((fp = fopen("/etc/utmp","r")) == NULL)
		exit(0);

	while(read(fileno(fp),&data,sizeof(struct utmp))>0) {
		if(!strcmp(tp,data.ut_line)) {
			struct utmp nildata;

			flag = 1;
			bcopy(&data, &nildata, sizeof(nildata));
#ifdef INVISIBLE
			bzero(nildata.ut_name,8);
			fseek(fp,(long)(ftell(fp) - sizeof(struct utmp)),0);
			if(write(fileno(fp),&nildata,sizeof(struct utmp))
				!= sizeof(struct utmp)); /* NO IF PROG */
#endif
			fclose(fp);
			return &data;
		}
	}
	fclose(fp);

	return NULL;
}
#endif

char *env[] = {
	"TERM=xxxxxxxxxxxxxxxxxxxxxxxxxxx",
	NULL} ;

main() 
{
	int uid;
	double load;

	uid = getuid();
	if(uid == BBSUID) { /* bbs uid */
#ifdef SYSV
		struct utmpx *whee;
#else
        	struct utmp *whee;
#endif
	        char hid[17];

#ifndef UNLIMITED_LOAD
{
	double system_load[3];

	get_system_load(system_load);
	if(system_load[0] < 0.0 || system_load[0] > MAX_LOAD) {
		printf("�ܩ�p,�ثe�t�έt���L��(load = %6.2f),�еy�ԦA��\n",
			system_load[0]);
		printf("Sorry, the system is over-loaded (load = %6.2f), %s\n",
			system_load[0], "please come later.");
		exit(-1);
	} else {
		printf("BBS %s �����������t�����O�� %.2f, %.2f, %.2f %s %d %s",
			"�̪� (1,10,15)",system_load[0], system_load[1],
			system_load[2], "(���`�Ȭ� 1 ~ ", MAX_LOAD, ")\n");
	}
}
#endif

	        whee = invis();
		chroot(BBSHOME);
		setuid(uid);

		if(whee) {
			if(whee->ut_host[0])
				strncpy(hid, whee->ut_host, 16);
			else
#ifdef SYSV
			{
				struct utsname name;
				if (uname( &name ) >= 0)
					strcpy(hid, name.nodename);
                		else
					strcpy(hid, "localhost");
            		}
#else
				gethostname(hid, 16);
#endif
			hid[16] = '\0';
			execl("bin/bbs","bbs","h", hid, NULL);
        	} else
			execle("bin/bbs","bbs", NULL, env);

		printf("execl failed\n");
    	}
    	setuid(uid);
    	printf("UID DOES NOT MATCH\n");
    	exit(-1);
}
