/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful, 
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)discuss.c   5.08 3/19/95 (C) 1993 University \
of NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include "bbs.h"

userec	cuser, 
	olddata;

char	currboard[STRLEN], 
	genbuf[4096], 
	currfile[STRLEN], 
	saveboard[STRLEN], 
	atot[MAXUSERS], 
	currtitle[STRLEN], 
	currauth[STRLEN], 
	match[STRLEN];

int	usercounter, 
	mot, 
	usernum, 
	selboard = 0, 
	local_post, 
	islocal, 
	at, 
	whichboards, 
	tuid, 
	tfile, 
	rfile, 
	m_count, 
	m_total;

#ifdef HAS_BOARD_ANONYMOUS
int	isscret;
#endif

int	Discuss(void)
{
	changemode(MPOST, NA);

	docmd("[���ؿ�]", "��J���R�O�ﶵ: ", 'b', postlist, boardmargin);
	clear();

	changemode(MMENU, NA);

	return 0;
}

int	Boards(void)
{
	changemode(SHOW, NA);
	choose_board(-1, HAS_SET(SET_YANKIN));
	changemode(MPOST, NA);
	return 0;
}

int	New(void)
{
	changemode(READNEW, NA);
	choose_board(-1, HAS_SET(SET_YANKIN));
	changemode(MPOST, NA); 
        return 0;
}
/* mark */
int	g_board_names(fptr)
bhd	*fptr;
{
	if (HAS_PERM(fptr->readlevel))
		AddNameList(fptr->filename);

	return 0;
}

void	make_blist(void)
{
	CreateNameList();
	apply_boards(g_board_names, -1, YEA);
}

int	Select(void)
{
	char	bname[STRLEN];
	struct	stat	st;
	int	savemode,
		savecomp;

	savemode = uinfo.mode;
	savecomp = uinfo.comp;
	changemode(SELECT, NA);

	make_blist();
	move(0, 0);
        prints(NA, "��ܰQ�װϡi���ť���C�X�����Q�װϡj\n");
	clrtoeol();
	namecomplete("��J�Q�װϡG", bname);

	changemode(savemode, savecomp);

	if ((*bname == '\0') || (stat(bfile(bname), &st) == -1))
	{
		move(2, 0);
		prints(NA, "��p! �L�k��{�Q�װ�!");
		pressreturn();
		CLRTOP3;
		return -1;
	}

	if (!(st.st_mode & S_IFDIR))
	{
		move(1, 0);
		prints(NA, "�o�ӰQ�װϦ��G�w�Q�o��, �гq�� %s �T�{\n", ADMIN);
		pressreturn();
		CLRTOP3;
		return -1;
	}

	selboard = 1;
	strcpy(currboard, bname);
	move(0, 0);
	clrtoeol();
	move(1, 0);
	clrtoeol();

	return 0;
}

int	get_messages(fptr)
fhd	*fptr;
{
	if (fptr->accessed[tuid] & FILE_READ)
		rfile++;
	tfile++;

	return 0;
}

int	get_boards(fptr)
fhd	*fptr;
{
	char	buf[512];

	sprintf(buf, "%s%s", bfile(fptr->filename), FHDIR);
	apply_record(buf, get_messages, sizeof(fhd));

	return 0;
}


int	Zap(void)
{
	char	bname[STRLEN];
	bhd	fh;
	int	pos,
		zapped;

	changemode(ZAP, NA);

	make_blist();
	clear();
	move(0, 0);
	prints(NA, "Select Board to Zap/Unzap %s\n", 
		"(upper/lower case does not matter)");
	prints(NA, "Board Name: ");
	clrtoeol();
	namecomplete((char *)NULL, bname);

	changemode(MPOST, NA);

	if (!(pos = search_board(&fh,bname)))
	{
		move(2, 0);
		prints(NA, "Invalid Board Name");
		move(0, 0);
		clrtoeol();
		return 0;
	}

	zapped = (fh.accessed[usernum] & ZAPPED);
	zapped ? (fh.accessed[usernum] &= ~ZAPPED) :
		 (fh.accessed[usernum] |= ZAPPED);
	move(2, 0);

	if (substitute_record(BOARDS, (char *)&fh, sizeof(fh), pos) == -1)
		prints(NA, "Error updating BOARDS file...\n");
	else
	{
		numboards = -1;
		prints(NA, "%s is now %s.\n", bname, zapped ? "Un-zapped" :
			"Zapped");
	}

	move(0, 0);
	clrtoeol();
	move(1, 0);
	clrtoeol();

	return 0;
}

