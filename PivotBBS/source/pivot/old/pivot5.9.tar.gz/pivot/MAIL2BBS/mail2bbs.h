#define BBSGID          99
#define BBSUID          99
#define MYNAME          "�����j�ǤѼϸ�T��"
#define MYENAME         "NCHU Pivot BBS"
#define MYNICKNAME      "PivotBBS"
#define MAILSERVER      "bbs.nchu.edu.tw"
#ifndef MYHOSTNAME
 #define MYHOSTNAME      "bbs.nchu.edu.tw" 
#endif 
#define ADMIN           "SYSOP"
#define JUNK            "junk"

#define DAEMON          "�t�Ψ����T�{�۰��ˬd"
#define MYPASSFILE      "/.PASSWDS"
#define MYCRCIDX        "/.CRCIDX"
#define BUFLEN          256
#define BRDPATH         "boards/%s"
#define BRDDIR          "boards/%s/%s"

