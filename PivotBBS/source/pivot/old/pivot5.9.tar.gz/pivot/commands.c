/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    SccsId[] = "@(#)commands.c	1.1	7/8/95";
#endif

#include "bbs.h"
extern	int	Announce(),	Discuss(),	Goodbye(),
		Help(),		Info(),		Mail(),
		Note(),		Maintenance(),	Talk(),
		Users(),	Welcome(),	Xyz();
#ifdef	FILES
extern	int	Files();
#endif
#ifdef	LEVER
extern	int	Lever();
#endif
cmds	cmdlist[] =
{
"Main Menu",       NULL,              0,     NULL,     NULL,
			   "�D���U����",NULL,
 "Announce",   Announce,     PERM_BASIC,"Discuss",   "Discuss",
			  "�������i�ƶ�","Announce Messages",
  "Discuss",	Discuss,     PERM_BASIC,"Discuss",   "Discuss",
     			 "�i�J�����","Enter Post Menu",
#ifdef FILES
    "Files",      Files,     PERM_BASIC,  "Files",   "Files",
			 "�ɮ׶ǰe���","Enter File Transfer Menu",
#endif
  "Goodbye",    Goodbye,              0,"Goodbye",   "Goodbye",
			     "���}����","Leave This BBS",
     "Help",       Help,              0, "Discuss",   "Help",
			   "�����U�e��","Get this Help Screen",
     "Info",       Info,              0,   "Info",   "Info",
			     "���v�ŧi","Get Copyright Information",
#ifdef LEVER
    "Lever",      Lever,              0, "Discuss", "Discuss",
			     "�����A��","Services (Gopher, Hytelnet,News)",
#endif
     "Mail",       Mail,              0,   "Talk",   "Mail",
			 "�i�J�l����","Enter Mail Menu",
     "Note",	   Note,              0, "Discuss", "Discuss",
		          "�d�\\�d���O","Read Current Notes",
   "System",Maintenance, PERM_ADMINMENU,  "Admin",   "Admin",
			   "�޲z�����","Enter Admin Menu",
     "Talk",       Talk,              0,   "Talk",   "Talk",
			 "�i�J��Ϳ��","Enter Talk Menu",
    "Users",      Users,     PERM_BASIC,   "Talk",   "Users",
			 "�C�X�Ҧ��b��","List ALL users of this BBS",
  "Welcome",    Welcome,              0,"Welcome",   "Welcome",
			     "�w��e��","Look at the Welcome Screen",
      "Xyz",        Xyz,              0,    "Xyz",   "Xyz",
			   "�u��c���","Utilities",
       NULL,	   NULL,	      0,     NULL,   NULL,
				   NULL,NULL,
};


extern	int	Boards(),	d_exit(),	Group(),
		p_help(),	Kind(),		New(),
		Post(),		Read(),		Select(),
		Zap(),		Visit();

cmds	postlist[] =
{
"Post Menu",       NULL,              0,     NULL,  NULL,
		             "�����",NULL,
   "Boards",     Boards,              0, "Select", "Boards",
			   "�Q�װϦC��","List boards on system",
     "Exit",     d_exit,              0,   "Exit","Exit",
		           "�^�W�D���","EXIT Post Menu",
    "Group",	  Group,              0,   "Kind","Group",
			 "�̰Q�׸sŪ��","Read Boards by Group",
     "Help",     p_help,              0,   "Help","Help",
		           "�����U�e��","Get this Help Screen",
     "Kind",	   Kind,              0, "Select", "Read",
		       "���Q�׸sŪ�s�H","Read New Post by Group",
      "New",        New,     PERM_BASIC, "Select", "Select",
			   "Ū���s���","Read all new messages",
     "Post",       Post,      PERM_POST,   "Read",   "Post",
			     "�o������","Post a message on current board",
     "Read",       Read,              0, "Boards", "Select",
			 "�i�JŪ�����","Enter multifunction Read Menu",
   "Select",     Select,              0,   "Read", "Select",
			   "��ܰQ�װ�","Select current board",
    "Visit",      Visit,     PERM_BASIC,  "Visit",  "Visit",
			 "�y�X�Ҧ����","Make all messages current",
      "Zap",        Zap,     PERM_BASIC,    "Zap",    "Zap",
			   "���~�Q�װ�","Zap Boards from (N)ew Search",
       NULL,	   NULL,	      0,     NULL,     NULL,
				   NULL,NULL,
};

extern	int	m_admin(),	m_exit(),	m_help(),
		m_inter(),	m_new(),	m_read(),
		m_send();

cmds	maillist[] =
{
"Mail Menu",       NULL,            0,  NULL,  NULL,
		      "�l����",NULL,
    "Admin",	m_admin,   PERM_SPECIAL11, "Read", "Read",
	       "Ū�`�޲z���H��","Read SYSOP Mail BOX",
     "Exit",	 m_exit,            0,"Exit","Exit",
		    "�^�W�D���","EXIT Mail Menu",
     "Help",     m_help,            0,"Help","Help",
		    "�����U�e��","Get this Help Screen",
 "InterNet", 	m_inter,    PERM_TRUE,"Read", "Read",
	      "�H�e��ں����H��","Send Internet E-mail",
      "New",      m_new,PERM_READMAIL,"Exit","Exit",
		      "Ū�s�H��","See New Mail Messages",
     "Read",     m_read,PERM_READMAIL,"Exit","Exit",
		      "��Ū�H��","Enter Multi purpose Read Menu",
     "Send",     m_send,PERM_SENDMAIL,"Send","Exit",
		      "���e�H��","Send a Mail Message to another user",
       NULL,       NULL,	       0,  NULL,  NULL,
			    NULL,NULL,
};

#ifdef FILES
extern	int	f_download(),	f_help(),	f_list(),
		f_protocol(),	f_select(),	f_text(),
		f_upload();

cmds	filelist[] =
{
"File Menu",       NULL,          0,      NULL,    NULL,
		     "�ɮ׶ǰe���",NULL,
 "Download", f_download,          0,"Download","Select",
			 "�Ǧ^�ɮ�","Download a file from this bbs",
     "Exit",     d_exit,          0,    "Exit",  "Exit",
			 "�^�D���","EXIT File Menu",
     "Help",     f_help,          0,    "List",  "Exit",
		       "�����U�e��","Get this Help Screen",
     "List",     f_list,          0,"Download","Select",
			 "�C���ɮ�","List the files on current Sub-board",
 "Protocol", f_protocol,          0,"Download","Select",
		     "�]�w�ǰe��w","Select download/upload protocol",
   "Select",   f_select,          0,    "List",  "Exit",
			 "��ܥؿ�","Select a File Sub-board",
     "Text",     f_text,          0,    "List","Select",
		       "��ܤ�r��","View a text file",
   "Upload",   f_upload,PERM_UPLOAD,    "Exit","Select",
			 "�W���ɮ�","Upload a file to this bbs",
       NULL,	   NULL,	  0,	  NULL,    NULL,
			       NULL,NULL,
};
#endif

extern	int	x_cloak(),	x_date(),	x_help(),
		x_info(),	x_edlogout(),	x_offline(),
		x_editplan(),	x_editsig(),	x_motd(),
		x_media();
#ifdef	GNULicense
extern	int	Conditions();
#endif

cmds	xyzlist[] =
{
     "Xyz Menu",       NULL,           0,      NULL,  NULL,
			  "�u����",NULL,
	"Cloak",    x_cloak,  PERM_CLOAK,    "Exit","Exit",
		  "�����i�Q�ʬݼҦ�","Switch Cloak mode",
         "Date",     x_date,           0,    "Exit","Exit",
		      "�ثe�ɶ��d��","Show current date/time",
         "Exit",     d_exit,           0,    "Help","Exit",
			  "�^�D���","EXIT XYZ Menu",
#ifdef GNULicense
         "Fiat", Conditions,           0,    "Fiat","Help",
			  "�ϥΰ���","GNU General Public License",
#endif
         "Help",     x_help,           0,    "Help","Exit",
			"�����U�e��","Get this Help Screen",
         "Info",     x_info,   PERM_POST,    "Exit","Exit",
		  "�ӤH��Ƭd�߳]�w","Personal information",
       "Logout", x_edlogout,  PERM_BASIC,    "Exit","Exit",
		   "�s�����������","Edit Logout File",
        "Media",	x_media,  PERM_BASIC,	 "Exit","Exit",
     			  "���ҳ]�w","Check and Modify Enviroment",
      "OffLine",  x_offline,   PERM_POST,	 "Exit","Exit",
		      "�M���ۤv�b��","Remove the account",
    "QueryEdit", x_editplan,  PERM_BASIC,    "Exit","Exit",
			"���ӤH���","Edit/Delete your Plan",
    "Signature",  x_editsig,  PERM_BASIC,    "Exit","Exit",
			"�s�g�W����","Edit/Delete your signature File",
    "Today MSG",     x_motd,PERM_WELCOME,    "Exit","Exit",
			"�����Ѯ���","Edit The Message of Today",
       NULL,	   NULL,	   0,	   NULL,  NULL,
				NULL,NULL,
};

extern	int	ent_chat1(),	ent_chat2(),	t_friend(),
		t_help(),	kick_user(),	t_list(),
		t_monitor(),	t_override(),
		t_pager(),	t_query(),	
		t_talk(),	t_users();
#ifdef	USE_CHAT3
extern	int	ent_chat3();
#endif
#ifdef	USE_BMCHAT
extern	int	ent_chatbm();
#endif

cmds	talklist[] =
{
"Talk Menu",        NULL,           0,    NULL,  NULL,
			 "��ͥؿ�",NULL,
    "1Chat",   ent_chat1,   PERM_CHAT, "1Chat","Exit",
		      "�Y�ɰQ�װ�1","Enter Chat Room 1",
    "2Chat",   ent_chat2,   PERM_CHAT, "2Chat","Exit",
		      "�Y�ɰQ�װ�2","Enter Chat Room 2",
#ifdef USE_CHAT3
    "3Chat",   ent_chat3,   PERM_CHAT, "3Chat","Exit",
		      "�Y�ɰQ�װ�3","Enter Chat Room 3",
#endif
#ifdef USE_BMCHAT
"Chat Manager", ent_chatbm,  PERM_LOCAL, "List","Exit",
		     "�޲z���Q�װ�","Enter Managers Chat Room",
#endif
     "Exit",      d_exit,           0,  "Help","Exit",
			 "�^�D���","EXIT Talk Menu",
   "Friend",    t_friend,		  0,  "Help","Exit",
                     "�C�X�u�W�ͤH","List Current On Line Friends",
     "Help",      t_help,           0,  "Help","Exit",
		       "�����U�e��","Get this Help Screen",
     "Kick",   kick_user,  PERM_SYSOP, "Users","Exit",
			   "�v�ȥO","Kick User Off System",
     "List",      t_list,           0,  "List","Exit",
		     "²�ܨϥΪ��p","Short Version of (U)sers",
  "Monitor",   t_monitor,  PERM_BASIC,  "Help","Exit",
			   "�ʵ���","Monitor User List",
 "Override",  t_override,  PERM_BASIC, "Users","Exit",
		     "�]�w�i���ܪ�","Let users override Pager Off",
    "Pager", 	 t_pager, PERM_PAGE,   "Pager", "Friend",
		   "���ܾ��}������","Toggle Personal Pager",
    "Query",     t_query,           0, "Query","Exit",
		     "�d�߯��͸��","Read a user's Plan",
     "Talk",      t_talk,   PERM_PAGE,  "Talk","Exit",
			   "�ͨƱ�","Talk to another user",
    "Users"  ,   t_users,           0, "Users","Exit",
		     "�b�u�W�ϥΪ�","List Users Online Now",
       NULL,  	    NULL, 	  0,	NULL,   NULL,
			       NULL,NULL,
};

extern	int	m_adduser(),	d_board(),	m_editbrd(),
		d_user(),	m_groupadd(),	a_help(),
		m_info(),	m_chgroup(),	x_level(),
		Create(),	m_plan(),	m_uclean();
#ifdef	USE_SHELL
extern	int	x_csh();
#endif

cmds	maintlist[] =
{
  "Admin Menu",     NULL,            0,          NULL,  NULL,
		      "�޲z����U�e��",NULL,
    "Add User",m_adduser,PERM_ACCOUNTS,    "Add User","Exit",
			  "�W�[�ϥΪ�","Add a new account",
"Board Delete",  d_board,  PERM_BOARDS,       "Board","Exit",
			  "�R���Q�װ�","Delete a board",
"Change Board",m_editbrd,  PERM_BOARDS,"Change Board","Exit",
		      "���Q�װϳ]�w","Change Board Information",
 "Delete User",   d_user,PERM_ACCOUNTS,      "Delete","Exit",
		      "�R���S�w�ϥΪ�","Delete a user",
	"Exit",   d_exit,            0,        "Exit","Exit",
			    "�^�D���","EXIT Admin Menu",
   "Group Add",m_groupadd, PERM_BOARDS,	  "Group Add","Group Add",
			"�طs�� Group","Create new Group",
	"Help",   a_help,            0,        "Help","Exit",
			  "�����U�e��","Get this Help Screen",
	"Info",   m_info,PERM_ACCOUNTS,        "Info","Info",
			"���b�����","Get and change user info",
 "Kind Modify",m_chgroup,  PERM_BOARDS, "Kind Modify","Kind Modify",
                      "���Q�׸s���","Modify Group Info",
       "Level",  x_level,   PERM_SYSOP,       "Level","Exit",
			    "�]�w�v��","Change User Level",
   "New Board",   Create,  PERM_BOARDS,        "Exit","Exit",
			"�إ߷s�Q�װ�","Create a new board",
	"Plan",	  m_plan,  PERM_BOARDS,	       "Exit","Exit",
		      "�s�g���i��²��","Edit Board Plan",
#ifdef	USE_SHELL
       "Shell",    x_csh,   PERM_SYSOP,        "Exit","Exit",
		     "�ϥ� Unix Shell","Get Unix Shell",
#endif
  "User Clean", m_uclean,  PERM_UCLEAN,  "User Clean","Exit",
		      "�M���L���ϥΪ�","Clean all accounts inactive",
	  NULL,     NULL,	     0, 	 NULL,	NULL,
				  NULL,NULL,
};

#ifdef LEVER
extern	int	l_help(),	l_exit();
#ifdef	USE_BBSNET
extern	int	l_bbsnet();
#endif
#ifdef	USE_GOPHER
extern	int	l_gopher();
#endif
#ifdef	USE_IRC
extern	int	l_irc(),	l_trc();
#endif
#ifdef	USE_HYTELNET
extern	int	l_library();
#endif
#ifdef	USE_TIN
extern	int	l_news();
#endif
#ifdef	USE_TRIPOS
extern	int	l_tripos();
#endif
cmds	leverlist[] =
{
"Lever Menu",     NULL,         0,     NULL,  NULL,
		   "�S���A�ȿ��",NULL,
#ifdef USE_BBSNET
    "BBSNet", l_bbsnet, PERM_POST, "BBSNet","Exit",
		     "����䥦��","Doors To Other BBSes",
#endif
      "Exit",   d_exit,         0,   "Exit","Exit",
		       "�^�D���","Exit Lever Menu",
#ifdef USE_GOPHER
    "Gopher", l_gopher,PERM_BASIC, "Gopher","Exit",
		   "��X�d�ߨt��","Gopher service",
#endif
      "Help",   l_help,         0,   "Help","Exit",
		     "�����U�e��","Get this help screen",
#ifdef USE_IRC
       "IRC",    l_irc, PERM_TRUE,    "IRC","Exit",
		   "��ڥ�ͺ���","Enter IRC Chat",
#endif
#ifdef USE_HYTELNET
   "Library",l_library,PERM_BASIC,"Library","Exit",
		 "�Ϯ��]�A�Ȩt��","Hytelnet service",
#endif
#ifdef USE_TIN
      "News",   l_news,PERM_BASIC,   "News","Exit",
		   "�s�������A��","News service",
#endif
#ifdef USE_TRIPOS
    "Search", l_tripos,         0, "Tripos","Exit",
		       "�d�]�t��","Tripos for Exams.(Need Chinese System)",
#endif 
#ifdef USE_IRC
       "TRC",    l_trc, PERM_POST,    "TRC","Exit",
		   "�O�W��ͺ���","Enter IRC Chat",
#endif
	NULL,	  NULL, 	0,     NULL,  NULL,
			     NULL,NULL,
};
#endif
