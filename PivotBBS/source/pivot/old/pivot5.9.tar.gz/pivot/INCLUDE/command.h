/*
 * @(#)command.h	1.2	7/2/95
 */

#define MSG_PRIV  	0
#define MSG_PUB   	1 
#define MSG_WHO   	2	 
#define MSG_NICK   	3	 
#define MSG_ROOM_LST  	4	
#define MSG_TOPIC 	5	 
#define MSG_INV    	6
#define MSG_QUIT   	7
#define	MSG_HELP	8
#define MSG_JOIN	9
#define MSG_KICK	10
#define MSG_OPER	11
#define MSG_BAN		12
#define MSG_NEW_USER	13
#define	MSG_SET_ROOM	14
#define	MSG_IGNORE	15
#define	MSG_LST_INV	16
#define	MSG_LST_BAN	17
#define	MSG_RM_INV	18
#define	MSG_RM_BAN	19
#define	MSG_LST_IGN	20
#define	MSG_RM_IGN	21
#define	MSG_ADVANCE	22
#define MSG_WHOS	23
#define	MSG_DO_CLO	24
