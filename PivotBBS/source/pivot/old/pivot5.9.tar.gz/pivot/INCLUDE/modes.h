/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

    @(#)modes.h	1.2 7/2/95
*/

#ifndef	_MODES_H_
#define _MODES_H_

/*
 * ���W���ʪ��A, �I�s�~���{���� mode ��ݤj�� 150 �쬰 MODES.H
 * ���s�W�����b�o��..
 */
#define IDLE            0               /* Modes a user can be in       */

#define LMENU           1               /* MENU MODE:  1 ->  10         */
#define MMENU           2
#define MPOST           3
#define TMENU           4
#define XMENU           5
#define FMENU           6
#define MADMIN          7
#define MAIL            8
#define ANNOUNCE        9

#define LOGIN           11              /* MAIN MENU:  11 ->  20        */
#define MUSERS          13
#define NEW             14

#define CNTBRDS         21              /* DISCUSS  :  21 ->  40        */
#define READNEW         22
#define POSTING         23
#define READING         24
#define SELECT          25
#define SHOW            26
#define VISIT           27
#define ZAP             28
#define GROUP		29
#define KIND		30
#define READFAQ         31

#define FLIST           41              /* FILE     :  41 ->  50        */
#define PROTOCOL        42
#define FSELECT         43
#define FTEXT           44
#define ULDL            45

#define RMAIL           51              /* MAIL     :  51 ->  60        */
#define SMAIL           52
#define NMAIL           53
#define	MSYSOP		54

#define BMCHAT          61              /* TALK     :  61 ->  80        */
#define CHAT1           62
#define CHAT2           63
#define CHAT3           64

#define FRIENDS         65
#define LUSERS          66
#define MONITOR         67
#define PAGE            68
#define QUERY           69
#define TALK            70
#define OVERRIDE        71
#define LAUSERS         72
#define FMONITOR	73

#define EDITPLAN        81              /* XYZ      :  81 -> 100        */
#define EDITSIG         82
#define EDITMOTD        83
#define VOTING          84
#define XINFO           85
#define	EDLOGOUT	86

#define BOARDINFO       101             /* SYSTEM   : 101 -> 150        */
#define CREATE          102
#define MINFO           103
#define GCREATE		104

#define BBSNET          152		/* SHELL    : > 150             */
#define FORWARD         153
#define FOURM           154
#define GOPHER          155
#define IRCCHAT         156
#define LIBRARY         157
#define NEWS            158
#define TRCCHAT         160
#define TRIPOS          161
#define UPLOAD          162
#define DNLOAD          163
#define SHELL           164

#endif /* _MODES_H_ */
