/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdio.h>
#include <string.h>
#include <time.h>
#include "define.h"
#include "struct.h"

extern	long	GetStrCrc(char *str);

char	*strtolow(buf1)
char	*buf1;
{
	int	i;
	static	char	buf2[STRLEN];

	bzero(buf2, STRLEN);
        for(i = 0; i<strlen(buf1); i++)
                buf2[i] = (isalpha(buf1[i])?buf1[i]|0x20:buf1[i]);
	strcpy(buf1, buf2);
	return buf2;
}

void	main()
{
	userec	user;
	FILE	*passfile,
		*crcfile;
	ucrc	crcidx;

	passfile = fopen(".PASSWDS", "rb");

	if (passfile == NULL)
		passfile = fopen("PASSWDS", "rb");

	if (passfile == NULL)
		exit(-1);

	crcfile = fopen(".CRCIDX", "wb");

	if (crcfile == NULL)
		crcfile = fopen("CRCIDX","wb");

	if (crcfile == NULL)
		exit(-1);

	while (!feof(passfile))
	{
		fread(&user, sizeof(userec), 1, passfile);
		crcidx.crcnum = GetStrCrc(user.userid);
		crcidx.level = user.userlevel;
		crcidx.checksum = user.checksum;
		printf("%s: %d\n", user.userid, crcidx.crcnum);
		fwrite(&crcidx, sizeof(ucrc), 1, crcfile);
	}    
	fclose(crcfile);
	fclose(passfile);
}    
