/*
 * Usage:  <<problem to: kftseng@bbs.ccu.edu.tw>>
 *
 * 1. �ˬd struct oldbrd �P�ª� bhd/boardheader �ۦP
 * 2. �ˬd struct newbrd �P�s�� struct bhd �ۦP
 * 3. make newbrd
 * 4. mkdir /home/bbs/upgrade
 * 5. cp newbrd /home/bbs/upgrade
 * 6. cd /home/bbs
 * 7. newbrd .BOARDS new
 * 8. mv new .BOARDS
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <fcntl.h>
#include <stdio.h>

#define IDLEN           12      /* ���i�H�� */
#define STRLEN          80
#define MAXUSERS        7800    /* �令�z�b define.h �����ƥ�*/

typedef unsigned int    usint;
typedef unsigned char   uschar;

typedef struct
{
        char    filename[80];		/* �Q�װϦW			*/
        char    mngs[3][13];		/* �Q�װϥN�z�H��		*/
        char    sender[39];		/* �O�d				*/
        char    title[72];		/* �Q�װϻ���			*/
	usint	postlevel;		/* �i�i�K�Q�װϪ��v��		*/
	usint	group;			/* �Q�װϩ��ݤ��s		*/
        usint	flag;			/* �Q�װϪ��A			*/
        usint   readlevel;		/* �iŪ���Q�װϪ��v��		*/
	uschar  accessed[MAXUSERS];	/* ���ͨϥΪ��A			*/
}
pivot;

typedef struct
{
        char    filename[80];		/* �Q�װϦW			*/
        char    mngs[3][13];		/* �Q�װϥN�z�H��		*/
        char    sender[39];		/* �O�d				*/
        char    title[72];		/* �Q�װϻ���			*/
	usint	postlevel;		/* �i�i�K�Q�װϪ��v��		*/
	usint	group;			/* �Q�װϩ��ݤ��s		*/
        usint	flag;			/* �Q�װϪ��A			*/
        usint   readlevel;		/* �iŪ���Q�װϪ��v��		*/
	uschar  accessed[10000];	/* ���ͨϥΪ��A			*/
}
feeling;

void    main(argc, argv)
int     argc;
char    *argv[];
{
        FILE    *orig,
                *newf;
        int     i,
                orsize,
                nwsize;
        char    message[STRLEN];
        pivot	old;
        feeling	new;
        time_t  curr;

        if (argc < 2)
        {
                printf("Usage: %s OLD_BOARDS NEW_BOARDS", argv[0]);
                exit(0);
        }

        if ((orig = fopen(argv[1], "r")) == NULL)
        {
                sprintf(message, "File %s is not exist", argv[1]);
                perror(message);
                exit(-1);
        }

        if ((newf = fopen(argv[2], "w+")) == NULL)
        {
                sprintf(message, "File: %s cannot be creat", argv[1]);
                perror(message);
                fclose(orig);
                exit(-2);
        }

        orsize = sizeof(old);
        nwsize = sizeof(new);
        time(&curr);

        while (fread((char *)&old, orsize, 1, orig) != 0)
        {
                i++;
                curr += 20;
		strcpy(new.filename, old.filename);
		strcpy(new.mngs[0], old.mngs[0]);
		strcpy(new.mngs[1], old.mngs[1]);
		strcpy(new.mngs[2], old.mngs[2]);
		strcpy(new.title, old.title);
		new.postlevel = old.postlevel;
		new.group = old.group;
		new.flag = old.flag;
		new.readlevel = old.readlevel;
		memcpy(new.accessed, old.accessed, MAXUSERS);

                if (fwrite((char *)&new, nwsize, 1, newf) == 0)
                {
                        perror("write fail");
                        break;
                }
                printf("%d[%s(%s)]\n", i, new.filename, new.title);
        }
        fclose(newf);
        fclose(orig);
        exit(0);
        return;
}
