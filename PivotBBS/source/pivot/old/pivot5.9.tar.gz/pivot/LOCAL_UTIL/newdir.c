/*
 * Usage:  <<problem to: kftseng@bbs.ccu.edu.tw>>
 *
 * 1. �ˬd struct oldbrd �P�ª� bhd/boardheader �ۦP
 * 2. �ˬd struct newbrd �P�s�� struct bhd �ۦP
 * 3. make newbrd
 * 4. mkdir /home/bbs/upgrade
 * 5. cp newbrd /home/bbs/upgrade
 * 6. cd /home/bbs
 * 7. newbrd .BOARDS new
 * 8. mv new .BOARDS
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <fcntl.h>
#include <stdio.h>

#define IDLEN           12      /* ���i�H�� */
#define STRLEN          80
#define MAXUSERS        7800    /* �令�z�b define.h �����ƥ�*/

typedef unsigned int    usint;
typedef unsigned char   uschar;

typedef struct
{
        char    filename[79];		/* �ɦW				*/
        char    sended;			/* ��e�X���P LOCAL SAVE �X��	*/
        char    sender[STRLEN];		/* �o�H�H			*/
        char    title[STRLEN];		/* �H��D�D			*/
        usint   level;			/* �O�d				*/
        uschar  accessed[MAXUSERS];	/* Ū�����A�O��			*/
}
pivot;

typedef struct
{
        char    filename[79];		/* �ɦW				*/
        char    sended;			/* ��e�X���P LOCAL SAVE �X��	*/
        char    sender[STRLEN];		/* �o�H�H			*/
        char    title[STRLEN];		/* �H��D�D			*/
        usint   level;			/* �O�d				*/
        uschar  accessed[10000];	/* Ū�����A�O��			*/
}
feeling;

typedef	struct				/* BOARDS struct */
{
        char    filename[80];		/* �Q�װϦW			*/
        char    mngs[3][IDLEN+1];	/* �Q�װϥN�z�H��		*/
        char    sender[39];		/* �O�d				*/
        char    title[68];		/* �Q�װϻ���			*/
	time_t	flownum;		/* �O�y����			*/
	usint	postlevel;		/* �i�i�K�Q�װϪ��v��		*/
	usint	group;			/* �Q�װϩ��ݤ��s		*/
        usint	flag;			/* �Q�װϪ��A			*/
        usint   readlevel;		/* �iŪ���Q�װϪ��v��		*/
        uschar  accessed[10000];	/* ���ͨϥΪ��A			*/
}
bhd;

void    doit(board)
bhd	*board;
{
        FILE    *ori,
                *newf;
        int     i,
                orsize,
                nwsize;
        char    message[STRLEN];
        pivot	old;
        feeling	new;
        time_t  curr;
	char	orig[STRLEN],
		targ[STRLEN];

	sprintf(orig, "/home/bbs/boards/%s/.DIR", board->filename);
	sprintf(targ, "/home/bbs/boards/%s/.DD", board->filename);

        if ((ori = fopen(orig, "r")) == NULL)
        {
                sprintf(message, "File %s is not exist", orig);
                perror(message);
                exit(-1);
        }

        if ((newf = fopen(targ, "w+")) == NULL)
        {
                sprintf(message, "File: %s cannot be creat", targ);
                perror(message);
                fclose(orig);
                exit(-2);
        }

        orsize = sizeof(old);
        nwsize = sizeof(new);
        time(&curr);

        while (fread((char *)&old, orsize, 1, ori) != 0)
        {
                i++;
                curr += 20;
		strcpy(new.filename, old.filename);
		new.sended = old.sended;
		strcpy(new.sender, old.sender);
		strcpy(new.title, old.title);
		new.level = old.level;
		memcpy(new.accessed, old.accessed, MAXUSERS);

                if (fwrite((char *)&new, nwsize, 1, newf) == 0)
                {
                        perror("write fail");
                        break;
                }
                printf("%d[%s(%s)]\n", i, new.filename, new.title);
        }
        fclose(newf);
        fclose(ori);

	sprintf(message, "/home/bbs/boards/%s/.TMP", board->filename);
	rename(orig, message);
	rename(targ, orig);
	unlink(message);
        return;
}

int	apply_record(filename, fptr, size)
char	*filename;
int	(*fptr)();
int	size;
{
	char	*abuf;
	int	fd;

	if ((fd = open(filename, O_RDONLY, 0)) == -1)
		return -1;

	abuf = (char *)malloc(size);
	while (read(fd, abuf, size) == size)
	{
#define	QUIT	-100
		if ((*fptr)(abuf) == QUIT)
		{
			close(fd);
			free(abuf);
			return QUIT;
		}
	}
	close(fd);
	free(abuf);
	return 0;
}

main()
{
	apply_record("/home/bbs/.BOARDS", doit, sizeof(bhd));
}
