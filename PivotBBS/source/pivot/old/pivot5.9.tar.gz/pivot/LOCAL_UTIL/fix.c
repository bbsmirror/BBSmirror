#include <stdio.h>
#include <sys/file.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include "define.h"
#include "struct.h"

main(argc, argv)
int	argc;
char	**argv;
{
	char	output[STRLEN],
		genbuf[STRLEN],
		passfl[STRLEN];
	int	fd,
		id,
		crcnum;
	userec	info;
	ucrc	crcidx;
	time_t	now;
	FILE	*fp;

	for (id = 1; id <= MAXUSERS; id++)
	{
		if (get_record(PASSFILE, (char *)&info, sizeof(userec), id))
			exit(0);
		if (get_record(CRCIDX, (char *)&crcidx, sizeof(ucrc), id))
			exit(0);
		crcnum = GetStrCrc(info.userid);
		if (crcidx.crcnum != crcnum)
		{
			printf("%d: %s ���X(%d != %d)!!\n", id, info.userid,
				crcidx.crcnum, crcnum);
/*			sprintf(genbuf, PATH_DUSER, info.userid);
			system(genbuf);*/
			bzero(&info, sizeof(userec));
			substitute_record(PASSFILE, (char *)&info,
				sizeof(userec), id);
			continue;
		}
		sprintf(genbuf, PATH_USER, info.userid);
		if (access(genbuf, R_OK))
			mkdir(genbuf, 0700);
	}

        close(fd);
}
