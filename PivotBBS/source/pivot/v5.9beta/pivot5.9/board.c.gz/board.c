/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef	lint
static  char    SccsId[] = "@(#)board.c	1.8	7/26/95";
#endif

#include "bbs.h"

extern	int	usernum,
		t_lines,
		currgroup,
		numboards,
		selboard;
extern	char	currboard[];
extern	userec	cuser;
extern	usinfo	uinfo;
extern	char	boardmargin();

int	num_new = 0;
bhd	*brdlist[MAXBOARD];

int	count_newpost(ptr)
newhd	*ptr;
{
	struct	stat	st;
	int	fd,
		offset,
		total,
		num;
	uschar	ch;
	char	genbuf[STRLEN];
	fhd	fh;

	ptr->total = ptr->post = 0;
	sprintf(genbuf, "%s%s", bfile(ptr->name), FHDIR);

	if((fd = open(genbuf, O_RDWR)) < 0)
		return 0;

	fstat(fd, &st);
	total = st.st_size / sizeof(fhd);

	if (total <= 0)
	{
		close(fd);
		return 0;
	}

	offset = ((int)&(fh.accessed[usernum]) - (int)&(fh));
	ptr->total = total;
	num = total - 1;

	while (num > 0)
	{
		lseek(fd, offset + num * sizeof(fhd), L_SET);
		if (read(fd, &ch, 1) <= 0 || (ch & FILE_READ) ||
			(ch & FILE_VISIT))
		{
			break;
		}
		num -= 10;
	}

	if (num < 0)
		num = 0;

	while (num < total)
	{
		lseek(fd, offset + num * sizeof(fhd), L_SET);
		if(read(fd, &ch, 1) <= 0 || (ch & FILE_READ) == 0)
			break;
		num++;
	}
	ptr->post = total - num;

	close(fd);
	return 0;
}

/*
 * ���s POST �^�ǭȬ��y�����ӪO�`�g�ơz
 * �_�h���y�t�ȡz�� 0
 */
int	has_new_post(ptr)
bhd	*ptr;
{
	struct	stat	st;
	int	fd,
		offset,
		num;
	uschar	ch;
	char	genbuf[STRLEN];
	fhd	fh;

	sprintf(genbuf, "%s%s", bfile(ptr->filename), FHDIR);

	if((fd = open(genbuf, O_RDWR)) < 0)
		return 0;

	fstat(fd, &st);
	num = st.st_size / sizeof(fhd);

	if (num <= 0)
	{
		close(fd);
		return 0;
	}

	offset = ((int)&(fh.accessed[usernum]) - (int)&(fh));
	lseek(fd, offset + (num - 1) * sizeof(fhd), L_SET);

	if (!(read(fd, &ch, 1) <= 0 || (ch & FILE_READ) || (ch & FILE_VISIT)))
	{
		close(fd);
		return num;
	}

	close(fd);
	return -num;
}

void	brdttl()
{
	clear();
	menu_draw("[�Q�װϦC��]", boardmargin);
	move(1, 0);
	prints(NA, "%-20s%-11s%-27s%-20s\n", "[��,e]�^�Q�װϿ��",
		"[h]�D�U", "[��,r,<cr>]�i�J�\\Ū�e��",
		"[��,��]�W,�U�@�Q�װ�");
	prints(YEA, "[1;32;44m %-5s%5s %-18s%-18s%30s[m\n", "�s��",
		"Z V B", "�Q�װϦW��", "�Q�װϻ���", "�t�d�H");
}

void	newttl()
{
	clear();
	menu_draw("[�Q�װϦC��]", boardmargin);
	move(1, 0);
	prints(NA, "%-20s%-11s%-27s%-20s\n", "[��,e]�^�Q�װϿ��",
		"[h]�D�U", "[��,r,<cr>]�i�J�\\Ū�e��",
		"[��,��]�W,�U�@�Q�װ�");
	prints(YEA, "[1;32;44m %-5s%14s %-18s%-18s%21s[m\n", "�s��",
		"[ �s:�� ]  V B", "�Q�װϦW��", "�Q�װϻ���", "�t�d�H");
}

void	brdent(num, nphd)
int	num;
newhd	*nphd;
{
	prints(NA, " %4d %c %c %c %-18.18s%-35.35s %12s\n", num,
		((int)(*nphd->zap) & ZAPPED) ? '#' : ' ',
		((*nphd->flag) & BHD_VOTEING) ? (((int)(*nphd->zap) & VOTED) ?
		'%' : '#') : ' ', ((*nphd->flag) & BHD_BBSNEWS) ? '#' : ' ',
		nphd->name, nphd->title, nphd->mngs[0]);
}

void	newent(num, ptr)
int	num;
newhd	*ptr;
{
	if (*ptr->zap & ZAPPED)
		prints(NA, " %4d %9s", num, "--- z ---");
	else
	{
		if (HAS_SET(SET_COUNTNEW))
		{
			if (ptr->total <= 0)
				count_newpost(ptr);
			prints(NA, " %4d %4d:%4d", num, ptr->post, ptr->total);
		}
		else
		{
			ptr->post = has_new_post(ptr->name);
			ptr->total = abs(ptr->post);
			prints(NA, " %4d %4s:%4d", num, (ptr->post > 0) ?
				"��" : "��", ptr->total);
		}
	}
	prints(NA, "  %c %c %-18.18s%-26.26s %12s\n",
		(*ptr->flag & BHD_VOTEING) ?
		((*ptr->zap & VOTED) ? '%' : '#') : ' ',
		(*ptr->flag & BHD_BBSNEWS) ? '#' : ' ',
		ptr->name, ptr->title, ptr->mngs[0]);
}

int	visit_board(fptr, quick)
bhd	*fptr;
int	quick;
{
	int	i,
		offset,
		start,
		end,
		plus,
		fd,
		size;
	long	numfiles;
	uschar	ch;
	struct	stat	st;
	fhd	fh;
	char	genbuf[80];

	size = sizeof(fhd);
	offset = ((int)&fh.accessed[usernum] - (int)&fh);

	sprintf(genbuf,"%s%s",bfile(fptr->filename), FHDIR);
	if ((fd = open(genbuf, O_RDWR)) < 0)
		return 0;

	fstat(fd,&st);
	numfiles = st.st_size/size;

	if (numfiles <= 0)
	{
		close(fd);
		return 0;
	}
	flock(fd, LOCK_EX);

	if (quick)
	{
		start = numfiles-1;
		end = -1;
		plus = -1;
	}
	else
	{
		start = 0;
		end = numfiles;
		plus = 1;
	}

	lseek(fd, offset+start*size, L_SET);

	for(i = start; i != end; i+=plus, lseek(fd, offset+i*size, L_SET))
	{
		if (kbhit() == 'q')
		{
			if (uinfo.mode == VISIT)
			{
				flock(fd, LOCK_UN);
				close(fd);
				return QUIT;
			}
			else
				break;
		}
	        read(fd, &ch, 1);
	        if (!(ch & FILE_READ))
		{
			lseek(fd, offset+i*size, L_SET);
        		ch |= FILE_READ;
        		ch |= FILE_VISIT;
        		(void)write(fd, (char *)&ch, 1);
			move(t_lines-1, 0);
			prints(YEA, "�N�� [%4d] ����ƼЬ�Ū�L", i+1);
			refresh();
        	}
		else
		{
			if (quick)
				break;
		}
	}

	flock(fd, LOCK_UN);
	close(fd);

	move(t_lines-1,0);
	clrtoeol();
	return PARTUPDATE;
}

int	visit_boards(fptr)
bhd	*fptr;
{
	bhd	fh;

	move(1,0);
	prints(YEA, "�ثe Visit �� Board ��: %.20s\n", fptr->filename);

	search_board(&fh,fptr->filename);
	if (visit_board(&fh, YEA) == QUIT)
		return QUIT;
	return 0;
}

int	Visit()
{
	int	ans;
	char	bname[STRLEN];
	bhd	fh;

	clear();
	refresh();
	move(0,0);

	changemode(VISIT, NA);

	prints(NA, "Visit Board(s)\n");
	ans = getans(1,0,"(A)ll boards, (1) board, or (Q)uit? [Q]: ",'q');
	move(1,0);
	clrtoeol();

	switch(ans)
	{
		case 'a':
			apply_boards(visit_boards, -1, NA);
			break;
		case '1':
			make_blist();
			prints(NA, "Select board: ");
			namecomplete((char *)NULL, bname);
			move(5,0);
			if (*bname == '\0' || !search_board(&fh,bname))
			{
				prints(NA, "Invalid board name.\n");
				break;
			}
			prints(NA, "�ثe���b�N %s �O�Ь�Ū�L.. �еy��",
				fh.filename);
			(void)visit_board(&fh, YEA);
			move(5, 0);
			clrtoeol();
			break;
		default:
			move(5,0);
			prints(NA, "Visit aborted.\n");
	}
	pressreturn();
	clear();

	changemode(MPOST, NA);

	return -1;
}

/* ARGSUSED */
int	brd_select(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	static	int	i = 0,
			find = YEA;
	static	char	bname[STRLEN];
	int	j,
		ch;

	if (find == YEA)
	{
		bzero(bname, sizeof(bname));
		find = NA;
		i = 0;
	}

	while (1)
	{
		move(t_lines-1, 0);
		clrtoeol();
		prints(YEA, "�п�J�j�M���W ==> ");
		prints(NA, "%s", bname);
		ch = egetch();

		if (ISPRINT(ch))
		{
			bname[i++] = ch;

			for (j = 0; j < num_new; j++)
			{
				if (!strncmpi(brdlist[j]->filename, bname, i))
				{
					*ent = j+1;
					return LOOPUPDATE;
				}
			}

			if (find == NA)
			{
				bname[--i] = '\0';
				bell(1);
			}
			continue;
		}
		else if (ch == CTRL('H') || ch == KEY_LEFT || ch == KEY_DEL ||
			ch == '\177')
		{
			i--;
			if (i < 0)
			{
				find = YEA;
				break;
			}
			else
			{
				bname[i] = '\0'; 
				continue;
			}
		}
		else if (ch == '\t')
		{
			find = YEA;
			break;
		}
		else if (ch == '\n' || ch == '\r' || ch == KEY_RIGHT)
		{
			find = YEA;
			break;
		}
		bell(1);
	}
	if (find)
	{
 		move(t_lines-1, 0);
		clrtoeol();
		return PARTUPDATE;
	}
	return LOOPUPDATE;
}

/* ARGSUSED */
int	brd_zap(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	int	pos=0;
	bhd	bh;

	if (!(pos = search_board(&bh, brdinfo->name)))
	{
		numboards = -1;
		return -1;
	}
	if (*brdinfo->zap & ZAPPED)
		bh.accessed[usernum] &= ~ZAPPED;
	else
		bh.accessed[usernum] |= ZAPPED;

	bcopy(&bh.accessed[usernum], brdinfo->zap, sizeof(uschar));
	substitute_record(BOARDS, (char *)&bh, sizeof(bh), pos);

	return PARTUPDATE;
}

/* ARGSUSED */
int	brd_faqview(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	faqview(brdinfo->name);
	return FULLUPDATE;
}

/* ARGSUSED */
int	brd_yank(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	SWITCH_SET(SET_YANKIN);
	return REDOIREAD;
}

/* ARGSUSED */
int	brd_help(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	extern	hlpinfo	BoardSelect[];

	clear();
	do_the_help(BoardSelect);
	pressreturn();
	clear();

	return FULLUPDATE;
}

/* ARGSUSED */
int	brd_read(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	char	buf[STRLEN];
	int	tmp;

	strcpy(currboard, brdinfo->name);
	sprintf(buf, "%s%s", bfile(currboard), FHDIR);
	selboard = YEA;
	Read();
	return	FULLUPDATE;
}

/* ARGSUSED */
int	new_read(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	char	buf[STRLEN];
	int	tmp;

	strcpy(currboard, brdinfo->name);
	sprintf(buf, "%s%s", bfile(currboard), FHDIR);
	if (!HAS_SET(SET_COUNTNEW))
		count_newpost(brdinfo);
	tmp = brdinfo->total - brdinfo->post;
	getkeep(buf, tmp + 1, 1);
	selboard = YEA;
	Read();
	return	FULLUPDATE;
}

void	show_board_info(boardname)
char	*boardname;
{
	char	buf[WRAPMARGIN];
	FILE	*info;
	int	i;

	sprintf(buf, "boards/%s/.INFO", boardname);	
	if ((info = fopen(buf, "r")) == NULL)
		prints(NA, "\n�ثe�|�L�Q�װ�²��.\n");
	else
	{
		prints(YEA, "\n²���p�U:\n");
		for(i = 1; i <= 18; i++)
		{
			if (fgets(buf, sizeof(buf), info))
				prints(NA, "%s", buf);
			else
				break;
		}
		fclose(info);
	}
}

/* ARGSUSED */
int	brd_info(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	int	i;
	char	buf[STRLEN];

	clear();
	move(1,0);
	prints(NA, "�Q�װ� %s �D�D��: %s\n", brdinfo->name, brdinfo->title);

	for (i = 0; i < 3; i++)
	{
		if (brdinfo->mngs[i][0])
		{
			(void)strcat(buf, brdinfo->mngs[i]);
			(void)strcat(buf, " ");
		}
	}

	if (buf[0])
		prints(NA, "�Q�װϥN�z�H����: %s\n", buf);
	else
		prints(NA, "�ثe�L�Q�װϥN�z�H����¾\n");

	prints(NA, "�o�ӰQ�װ�%s�P��L�� BBS �� News �洫�H��\n",
		(*brdinfo->flag & BHD_BBSNEWS) ? "��" : "�S��");
	prints(NA, "�z%s�w�\\���Q�װ�\n",
		((int)*brdinfo->zap & ZAPPED) ? "�|��" : "�w");

	for (i = 0; i < 80; i++)
		prints(NA, "-");

	show_board_info(brdinfo->name);

	pressreturn();

	return FULLUPDATE;
}

/* ARGSUSED */
int	brd_edinfo(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	char	buf[STRLEN];
	int	bdeputy = NA;

	if (!strcasecmp(cuser.userid, brdinfo->mngs[0]) ||
		!strcasecmp(cuser.userid, brdinfo->mngs[1]) ||
		!strcasecmp(cuser.userid, brdinfo->mngs[2])) 
		bdeputy = YEA;

	if (HAS_PERM(PERM_BOARDS) || (HAS_PERM(PERM_LOCALBM) && bdeputy))
	{
		clear();
		sprintf(buf,"boards/%s/.INFO", brdinfo->name);
		(void)vedit(buf, NA);
		return FULLUPDATE;
	}
	else 
		bell(1);

	return DONOTHING;
}

/* ARGSUSED */
int	brd_qvisit(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	bhd	bh;

	if (brdinfo->name[0] == '\0' || !search_board(&bh, brdinfo->name))
		return DONOTHING;

	(void)visit_board(&bh, YEA);

	return PARTUPDATE;
}

/* ARGSUSED */
int	brd_cvisit(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	bhd	bh;

	if (brdinfo->name[0] == '\0' || !search_board(&bh, brdinfo->name))
		return DONOTHING;

	(void)visit_board(&bh, NA);

	return PARTUPDATE;
}

one_key	brdcmd[] =
{
	'y',		brd_yank,
	'h',		brd_help,
	'z',		brd_zap,
	'v',		brd_qvisit,
	'x',		brd_faqview,
	'f',		brd_cvisit,
	'\n',		brd_read,
	'\r',		brd_read,
	'r',		brd_read,
	KEY_RIGHT,	brd_read,
	'i',		brd_info,
	'E',		brd_edinfo,
	's',		brd_select,
	'S',		brd_select,
	'\t',		brd_select,
	'\0',		NULL,
};

one_key	newcmd[] =
{
	'y',		brd_yank,
	'h',		brd_help,
	'z',		brd_zap,
	'v',		brd_qvisit,
	'x',		brd_faqview,
	'f',		brd_cvisit,
	'\n',		new_read,
	'\r',		new_read,
	'r',		new_read,
	KEY_RIGHT,	new_read,
	'i',		brd_info,
	'E',		brd_edinfo,
	's',		brd_select,
	'S',		brd_select,
	'\t',		brd_select,
	'\0',		NULL,
};

int	build_board_list(ptr)
bhd	*ptr;
{
	brdlist[num_new++] = ptr;
	return 0;
}

/* ARGSUSED */
int	brdnum(direct, size)
char	*direct;
int	size;
{
	num_new = 0;
	bzero(brdlist, sizeof(brdlist));
	apply_boards(build_board_list, currgroup, HAS_SET(SET_YANKIN));
	return num_new;	
}

int	newpost_board(ptr)
bhd	*ptr;
{
	if (HAS_SET(SET_YANKIN) || has_new_post(ptr) > 0)
		brdlist[num_new++] = ptr;
	return 0;
}

/* ARGSUSED */
int	numnew(direct, size)
char	*direct;
int	size;
{
	num_new = 0;
	bzero(brdlist, sizeof(brdlist));
	apply_boards(newpost_board, currgroup, HAS_SET(SET_YANKIN));
	return num_new;	
}

/* ARGSUSED */
int	brdrec(dirbuf, ptr, size, topln, nument)
char	*dirbuf;
newhd	*ptr;
int	size,
	topln,
	nument;
{
	int	i = 0,
		curr;
	newhd	*lst;

	for (i = 0; i < nument; i++)
	{
		curr = i + topln - 1;
		if (!brdlist[curr] || !brdlist[curr]->filename[0])
			break;
		lst = &ptr[i];
		lst->name = brdlist[curr]->filename;
		lst->mngs[0] = brdlist[curr]->mngs[0];
		lst->mngs[1] = brdlist[curr]->mngs[1];
		lst->mngs[2] = brdlist[curr]->mngs[2];
		lst->title = brdlist[curr]->title;
		lst->total = lst->post = -1;
		lst->flag = &brdlist[curr]->flag;
		lst->zap = &brdlist[curr]->accessed[usernum];
	}
	return i;
}

int	Boards()
{
	int	savemode;

	savemode = uinfo.mode;
	changemode(SHOW, NA);
	while (i_read(BOARDS, brdttl, brdent, brdcmd, 'y', sizeof(newhd),
		brdnum, brdrec) == REDOIREAD);
	changemode(savemode, NA);
	clear();
	return FULLUPDATE;
}

int	New()
{
	int	savemode;

	savemode = uinfo.mode;
	changemode(READNEW, NA);
	while (i_read(BOARDS, newttl, newent, newcmd, '\0', sizeof(newhd),
		numnew, brdrec) == REDOIREAD);
	changemode(savemode, NA);
	clear();
	return FULLUPDATE;
}
