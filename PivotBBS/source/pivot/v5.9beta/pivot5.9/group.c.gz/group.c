/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef	lint
static  char    SccsId[] = "@(#)group.c	1.1	7/8/95";
#endif

#include "bbs.h"

extern	int	numboards,
		t_lines;
extern	bhd	*bcache;
extern	userec	cuser;

extern	char	*boardmargin();
extern	int	group_read_help(),
		get_records(),
		get_num_records();

int	currgroup = -1;
static	char	nowgroup[STRLEN];

int	gain_group()
{
	ghd	gcache[MAXGROUPS];
	int	i = 1,
		size,
		fd,
		num;
	char	buf[3];

	move(0,0);
	clrtobot();
	prints(YEA, "�]�w Group �s��\n");
	size = sizeof(ghd);

	if ((fd = open(GROUPS, O_RDONLY, 0)) == -1)
		return 0;

	while (read(fd, (char *)&gcache[i], size) == size)
	{
		move(i%6+2, i/6*19);
		prints(NA, "(%d) %s", i, gcache[i].filename);
		i++;
	}

	while(1)
	{
		getdata(10, 0, "��J�Q�׸s�s��: ", buf, 3, DOECHO, YEA);
		num = atoi(buf);
		if(num == 0)
			return 0;
		if (num > 0 && num < i)
			return gcache[num].groupnum;
		move(11, 0);
		prints(NA, "�Q�׸s�s�����~\n");
	}
}

int	cmpgroup(first, second)
int	first;
ghd	*second;
{
	return !strcasecmp((char *)first, second->filename);
}

int	getgnum(gname)
char	*gname;
{
	ghd	buf;

	return search_record(GROUPS, (char *)&buf, sizeof(ghd), cmpgroup,
		(int)gname);
}

int	getbnum(bname)
char	*bname;
{
	int	i;
	resolve_boards();
	for(i = 0; i < numboards; i++)
	{
      		if (!strncmpi(bname,(bcache[i]).filename,
			sizeof((bcache[i]).filename)))
		{
        		return i+1;
		}
	}
	return 0;
}

int	groupcheck(fptr)
ghd	*fptr;
{
	return !strcasecmp(fptr->filename, nowgroup);
}

void	groupdoent(num, ent)
int	num;
ghd	*ent;
{
	prints(NA, " %4d  %-15.15s %-54.54s\n", num, ent->filename,
		ent->title);
}


void	grouptitle()
{
        clrtobot();
        menu_draw("[�H��B�z]", boardmargin);
        prints(NA, "%-18.18s%-10.10s%-28.28s%-22.22s\n", "[��,e]�^�W�@�e��",
                "[h]�D�U", "[��,r,<cr>]��ܥثe�Q�׸s",
                "[��,��]�W,�U�@�ϰQ�׸s");

        prints(YEA, "[1;32;44m �s��  %-15.15s %-55.55s[m\n","�Q�׸s�W��","�Q�׸s����");
	refresh();
}

int	m_groupadd()
{
	ghd	newgroup;

	clear();

	changemode(GCREATE, NA);

	bzero(&newgroup, sizeof(newgroup));
	prints(NA, "�إ߰Q�פ���:");
	while (1)
	{
		getdata(3, 0, "�Q�׸s�W�١G",
			newgroup.filename, 18, DOECHO, YEA);
		if (!strcasecmp(newgroup.filename, "new") ||
			!strcasecmp(newgroup.filename, "quit"))
			return -1;
		if (checkid(newgroup.filename))
		{
			prints(NA, "���X�k���Q�װϦW��\n");
			continue;
		}
		if (getgnum(newgroup.filename))
		{
			prints(NA, "Error: Bad Group Name\n");
			continue;
		}
		break;
	}
	getdata(4, 0, "�Q�׸s�����G", newgroup.title, 60, DOECHO, YEA);
	(void)time((time_t *)&newgroup.groupnum);

	if (append_record(GROUPS, (char *)&newgroup, sizeof(newgroup)) == -1)
	{
		pressreturn();
		clear();
		changemode(MADMIN, NA);

		return -1;
	}

	prints(NA, "\n�s�W�Q�׸s����\n");
	pressreturn();

	changemode(MADMIN, NA);

	clear();
	return 0;
}

int	modify_group(gname)
char	*gname;
{
	int	pos,
		ans;
	ghd	fh,
		newfh;
	char	genbuf[STRLEN];

	pos = search_record(GROUPS, (char *)&fh, sizeof(fh), cmpgroup,
		(int)gname);
	if (!pos)
	{
		move(t_lines-1, 0);
		prints(NA, "Invalid Board Name.. press a key to continue..");
		egetch();
		clear();
		return FULLUPDATE;
	}
	move(3,0);
	clrtobot();
	bcopy(&fh, &newfh, sizeof(newfh));
	prints(NA, "�Q�׸s�W�١G %s\n", fh.filename);
	prints(NA, "�Q�׸s�����G %s\n", fh.title);
	prints(NA, "�Q�׸s�Ǹ��G %d\n", fh.groupnum);

	for(;;)
	{
		getdata(11, 0, "�s�Q�׸s�W�١G ", genbuf, 18, DOECHO,
			YEA);
		if (*genbuf != 0)
		{
			ghd dh;

			if (search_record(GROUPS, (char *)&dh, sizeof(dh),
				cmpgroup, (int)genbuf))
			{
				move(3,0);
				prints(NA, "Error! Board already exists\n");
				bell(1);
				move(11,0);
				clrtobot();
				continue;
			}
			strncpy(newfh.filename, genbuf, sizeof(newfh.filename));
		}
		break;
	}

	getdata(12, 0, "�s�Q�s�����G ", genbuf, 60, DOECHO, YEA);
	if (*genbuf != 0)
		strncpy(newfh.title, genbuf, sizeof(newfh.title));

	ans = getans(19, 0, "�x�s���]�w? (Yes or No) [N]: ", 'n');
	if (ans == 'y')
		substitute_record(GROUPS, (char *)&newfh, sizeof(newfh), pos);

	return FULLUPDATE;
}

int	m_chgroup()
{
	char	gname[STRLEN];

	move(0, 0);
	clrtobot();
	prints(YEA, "���Q�׸s�]�w");

	move(1,0);
	getdata(1, 0, "�Q�׸s�W��: ", gname, STRLEN, DOECHO, YEA);
	if (*gname == '\0')
	{
		move(2,0);
		prints(NA, "���X�W�w���Q�׸s�W��");
		pressreturn();
		clear();
		return;
	}
	modify_group(gname);
}

int	m_groupdelete(gname)
char	*gname;
{
        ghd	ginfo;
        int	gid,
		ans;
	char	buff[STRLEN];

        gid = getgnum(gname);

        if (get_record(GROUPS, (char *)&ginfo, sizeof(ginfo), gid) == -1)
	{
                move(t_lines-1, 0);
                prints(NA, "�Q�׸s %s ���s�b.\n", gname);
		pressreturn();
                clear();
                return FULLUPDATE;
        }

	sprintf(buff, "�R���Q�׸s '%s' (Y/N)? [N]: ", ginfo.filename);
        ans = getans(t_lines-1, 0, buff, 'n');

        if (ans != 'y')
	{
                move(t_lines-1,0);
		clrtoeol();
		prints(YEA, "[1;32;44m%s                      [m",
		"                     ...���R���Q�׸s..�Ы����N�����}...");
                return 0;
        }

	strcpy(nowgroup, ginfo.filename);
        ans = delete_file(GROUPS, sizeof(ginfo), gid, groupcheck);

        move(t_lines-1, 0);
	if (!ans) 
		prints(YEA, "[1;32;44m%s                      [m",
		"                     ...�Q�׸s�w�g�R��..�Ы����N�����}...");
	else
		prints(YEA, "[1;32;44m%s                      [m",
		"                     ...�R���Q�׸s����..�Ы����N�����}...");
	egetch();
        move(t_lines-1, 0);
	clrtoeol();
	return 0;
}

/* ARGSUSED */
int	group_read(ent, info, direct)
int	*ent;
ghd	*info;
char	*direct;
{
	currgroup = info->groupnum;
	Boards();
	currgroup = -1;
	return REDOIREAD;
}

/* ARGSUSED */
int	group_new(ent, info, direct)
int	*ent;
ghd	*info;
char	*direct;
{
	currgroup = info->groupnum;
	New();
	currgroup = -1;

	return REDOIREAD;
}

/* ARGSUSED */
int	group_add(ent, info, direct)
int	*ent;
ghd	*info;
char	*direct;
{
	if(!HAS_PERM(PERM_BOARDS))
		return 0;
	m_groupadd();

	return FULLUPDATE;
}

/* ARGSUSED */
int	group_delete(ent, info, direct)
int	*ent;
ghd	*info;
char	*direct;
{
        if(!HAS_PERM(PERM_BOARDS))
                return 0;
	m_groupdelete(info->filename);

	return FULLUPDATE;
}

/* ARGSUSED */
int	group_modify(ent, info, direct)
int	*ent;
ghd	*info;
char	*direct;
{
        if(!HAS_PERM(PERM_BOARDS))
                return 0;
	modify_group(info->filename);

        return FULLUPDATE;
}

one_key group_comms[] =
{
	'r',		group_read,
	'\n',		group_read,
	'\r',		group_read,
	' ',		group_read,
	KEY_RIGHT,	group_read,
	'h',		group_read_help,
	'a',		group_add,
	'd',		group_delete,
	'm',		group_modify,
	'\0',		NULL,
};

one_key kind_comms[] =
{
	'r',		group_new,
	'\n',		group_new,
	'\r',		group_new,
	' ',		group_new,
	KEY_RIGHT,	group_new,
	'h',		group_read_help,
	'a',		group_add,
	'd',		group_delete,
	'm',		group_modify,
	'\0',		NULL,
};

int	Group()
{
	changemode(GROUP, NA);

	while (i_read(GROUPS, grouptitle, groupdoent, &group_comms[0], 'Z',
		sizeof(ghd), get_num_records, get_records) == REDOIREAD);

	changemode(MPOST, NA);
	return 0;
}

int	Kind()
{
        changemode(KIND, NA);
	while (i_read(GROUPS, grouptitle, groupdoent, &kind_comms[0], 'Z',
		sizeof(ghd), get_num_records, get_records) == REDOIREAD);
        changemode(MPOST, NA);

        return 0;
}
