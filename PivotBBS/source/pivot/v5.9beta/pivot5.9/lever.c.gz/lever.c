/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef	lint
static  char    SccsId[] = "@(#)lever.c	1.1	7/8/95";
#endif

#include "bbs.h"

#ifdef LEVER

extern	userec	cuser;

#ifdef USE_BBSNET
int l_bbsnet()
{
        sh_exec(BBSNET, NA, "bbsnet.sh", NULL);
        return 0;
}
#endif

#ifdef USE_GOPHER
int l_gopher()
{
	sh_exec(GOPHER, NA, "gopher", NULL);

	return 0 ;
}
#endif

#ifdef USE_HYTELNET
int l_library()
{
	sh_exec(LIBRARY, NA, "hytelnet", NULL);

	return 0;
}
#endif

#ifdef USE_TIN
int l_news()
{
	sh_exec(NEWS, NA, "tin", NULL);

	return 0 ;
}
#endif

#ifdef USE_TRIPOS
int l_tripos()
{
	sh_exec(TRIPOS, NA, "tripos.sh", NULL);

	return 0 ;
}
#endif

#ifdef USE_IRC
int l_irc()
{
	char buf[512];

	sprintf(buf, PATH_IRCRC, cuser.userid);
	if(access(buf, R_OK) !=0)
		sprintf(buf, "irc %s", cuser.userid);
	else
		sprintf(buf, PATH_LDIRCRC, cuser.userid,
			cuser.userid);
	sh_exec(IRCCHAT, NA, buf, NULL);

	return 0;
}
#endif

#ifdef USE_TRC
int l_trc()
{
        char buf[512];

        sprintf(buf, PATH_IRCRC, cuser.userid);
        if(access(buf, R_OK) !=0)
                sprintf(buf, "irc %s -p 6666", cuser.userid);         
        else
                sprintf(buf, PATH_LDTRCRC, cuser.userid,
			cuser.userid);
        sh_exec(TRCCHAT, NA, buf, NULL);

        return 0;
}
#endif

#endif
