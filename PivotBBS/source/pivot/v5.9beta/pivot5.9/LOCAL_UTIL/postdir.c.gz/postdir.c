/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)postdir.c   5.08 3/19/95 (C) 1993 University \
of NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include <strings.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <sys/dir.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

#define STRLEN 80
#define	MAXUSERS 7800

typedef	unsigned int	usint;
typedef unsigned char	uschar;

struct  fhd
{
        char    filename[79];
        char    sended;
        char    sender[73];
        char    mon[4];
        char    day[3];
        char    title[80];
        usint   level;
        uschar  accessed[MAXUSERS];
};
typedef	struct	fhd	fhd;

#indef	DOIT
int	safewrite(fd, buf, size)
int	fd;
char	*buf;
int	size; 
{
	int	cc,
		sz = size,
		origsz = size;
	char	*bp = buf;

	do
	{
		cc = write(fd, bp, sz);
		if ((cc < 0) && (errno != EINTR))
		{
			report("safewrite failed!");
			return -1;
		}
		if (cc > 0)
		{
			bp += cc;
			sz -= cc;
		}
	}
	while(sz > 0);

	return origsz;  
}

int	append_record(filename,record,size)
char	*filename;
char	*record;  
int	size;
{
        int fd;

        if((fd = open(filename,O_WRONLY|O_CREAT,0644)) == -1)
	{
                perror("open");
                return -1;
        }

        flock(fd, LOCK_EX);
        lseek(fd, 0, L_XTND);

        if(safewrite(fd,record,size) == -1)
            report("append record failed (safewrite)!!!!");

        flock(fd, LOCK_UN);
        close(fd);

        return 0;
}
#else
int	append_record(filename, record, size)
char	*filename;
char	*record;  
int	size;
{
	fhd *fhd;

	fhd = (fhd *)record;

	printf("write to file: %s\n", filename);
	printf("sender: %s\n", fhd->sender);
	printf("title:  %s\n", fhd->title);
	printf("date:   %s %s\n", fhd->mon, fhd->day);
}	
#endif

int     isprint2(ch)
char    ch;
{
        return(ch & 0x80 ? 1 : isprint(ch));
}

int	strip(str)
char	*str;
{
	int	i;

	for (i = 0; i < strlen(str); i++)
		if (!isprint2(str[i]) && str[i]!='\n' && str[i]!='\r')
			str[i] = '_';
}

int	parse_owner(name, bufin)
char	*name;
char    *bufin;
{
        char    *tok;

        tok = strtok(bufin, " .@");
        tok = strtok(NULL, " .@");
        strncpy(name, tok, 73);
}

int	*parse_title(title, bufin)
char	*title;
char    *bufin;
{
        char    *tok;

	strip(bufin);
        tok = strtok(bufin, ":");
        tok = strtok(NULL, " \n\r");
        tok = strtok(NULL, "\n\r\t");
        strncpy(title, tok, 80);
}

char    *parse_date(mon, day, bufin)
char    *mon,
	*day,
	*bufin;
{
        static  char    retbuf[STRLEN];
        int     at;
        char    *tok;

        tok = strtok(bufin, "(");
        tok = strtok(NULL, " ");
        tok = strtok(NULL, " ");
        strncpy(mon, tok, 3);
        mon[3] = '\0';
        tok = strtok(NULL, " ");
        strncpy(day, tok, 2);
        day[2] = '\0';
	return;
}

int	appenddir(path, post)
char	*path,
	*post;
{
	char	buffer[256],
		dirent[STRLEN];
	char	*p;
	struct	fhd fhd;
	struct  fhd *phd;
	FILE	*fp;
	static	int count = 0;

	phd = &fhd;
	printf("%d: %s/%s found\n", ++count, path, post);
	sprintf(dirent, "%s/%s", path, post);

	if ((fp = fopen(dirent, "r")) == NULL)
		return -1;
	else
	{
		strncpy(fhd.filename, post, 79);
		fhd.sended = '%';

		fgets(buffer, sizeof(buffer), fp);
		parse_owner(phd->sender, buffer);

		fgets(buffer, sizeof(buffer), fp);
	        parse_title(phd->title, buffer);

		fgets(buffer, sizeof(buffer), fp);
	        parse_date(phd->mon, phd->day, buffer);

		sprintf(buffer, "%s/.DIR", dirent);
		append_record(dirent, (char *)&fhd, sizeof(fhd));
		fclose(fp);
	}
	if (count%24 == 0)
		sleep(1);
	return 0;
}

int	creatdir(board)
char 	*board;
{
	DIR	*dp;
	struct	direct *ent;
	char	path[STRLEN];

	sprintf(path, "/home/bbs/boards/%s", board);

	if ((dp = opendir(path)) == NULL)
		return -1; /* cannot open board */

	for (ent = readdir(dp); ent != NULL; ent = readdir(dp))
	{
                if (ent->d_name[0] != 'M')
			continue;
		appenddir(path, ent->d_name);
	}
	closedir(dp);
}

main(argc, argv)
int	argc;
char	**argv;
{
	if (argc < 2)
	{
		printf("Usage: %s [board name]\n", argv[0]);
		exit(-1);
	}

	creatdir(argv[1]);
}
