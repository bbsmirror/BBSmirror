#include <stdio.h>
#include <sys/file.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include "define.h"
#include "struct.h"

main(argc, argv)
int	argc;
char	**argv;
{
	char	output[STRLEN],
		passfl[STRLEN];
	int	fd,
		num = 0,
		size;
	userec	buf;
	time_t	now;
	FILE	*fp;

	if (argc != 2)
	{
		printf("Usage: %s passfile\n", argv[0]);
		exit(-1);
	}

	sprintf(passfl, argv[1]);

        if ((fd = open(passfl, O_RDWR, 0)) == -1)
                return -1;

	size = sizeof(userec);

	for (num = 0; num < MAXUSERS; num++)
        {
		lseek(fd, num*size, L_SET);
		read(fd, (char *)&buf, size);

		if (buf.userid[0] == '\0' || !strcmp(buf.userid, "new"))
			continue;

		printf("update info: %s\n", buf.userid);
		buf.mod_email = buf.reg_date;

		lseek(fd, num*size, L_SET);
		write(fd, (char *)&buf, size);
        }
        close(fd);
}
