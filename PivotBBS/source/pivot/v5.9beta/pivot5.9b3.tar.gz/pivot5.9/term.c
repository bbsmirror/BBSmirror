/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    SccsId[] = "@(#)term.c	1.1	7/8/95";
#endif

#include "bbs.h"
#ifdef  HP_UX
# include       "sys/ioctl.h"
# define	O_HUPCL	01
# define	O_XTABS	02
#endif

#ifdef LINUX
#include <sys/ioctl.h>
#include <linux/termios.h>
#define stty(fd, data) tcsetattr( fd, TCSETS, data )
#define gtty(fd, data) tcgetattr( fd, data )
#endif

#ifndef TANDEM
#define TANDEM  0x00000001
#endif

#ifndef CBREAK
#define CBREAK  0x00000002
#endif

#ifdef	LINUX
struct	termios	tty_state,
		tty_new;
#else
struct	sgttyb	tty_state,
		tty_new;
#endif

extern	int	tputs();
extern	char	*tgetstr();

char	PC,
	*UP,
	*BC,
	clearbuf[LINELEN],
	cleolbuf[LINELEN],
	cursorm[LINELEN],
	*cm,
	scrollrev[LINELEN],
	strtstandout[LINELEN],
	endstandout[LINELEN],
	*outp;

int	clearbuflen,
	cleolbuflen,
	scrollrevlen,
	strtstandoutlen,
	endstandoutlen,
	t_lines  = 24,
	t_columns = 80,
	automargins,
	*outlp;

void	get_tty()
{
	if (gtty(1, &tty_state) < 0)
	{
		fprintf(stderr, "gtty failed\n");
		exit(-1);
	}
}

#ifdef LINUX
void	init_tty()  
{
	bcopy(&tty_state, &tty_new, sizeof(tty_new));
/* MARK Modify by SLASH 
	tty_new.c_lflag&=~(ICANON|ECHO|RAW|ISIG);
*/
	tty_new.c_lflag &= ~(ICANON|ECHO|ECHOE|ECHOK|ISIG);
    
	tcsetattr(1, TCSANOW, &tty_new);
}
#else
void	init_tty()
{
	bcopy(&tty_state, &tty_new, sizeof(tty_new));
	tty_new.sg_flags |= RAW;
#ifdef HP_UX
	tty_new.sg_flags &= ~( O_HUPCL | O_XTABS | LCASE | ECHO | CRMOD);
#else
	tty_new.sg_flags &= ~(TANDEM | CBREAK | LCASE | ECHO | CRMOD);
#endif
	stty(1, &tty_new);
}
#endif

void	reset_tty()
{
	stty(1, &tty_state);
}

void	restore_tty()
{
	stty(1, &tty_new);
}


int	outcf(ch)
char	ch;
{
	if(*outlp >= LINELEN)
		return -1;
	(*outlp)++;
	*outp++ = ch;
	return 0;
}

int	term_init(term)
char	*term;
{
	extern short	ospeed;
	static char	UPbuf[LINELEN],
			BCbuf[LINELEN],
			buf[4096];
	char		sbuf[4096],
			*sbp;
	register	char	*s;

	if(strlen(term) < 2)
		strcpy(term, "vt100");

#ifdef LINUX
	ospeed = cfgetospeed(&tty_state);
#else
	ospeed = tty_state.sg_ospeed;
#endif

	if(tgetent(buf, term) != 1)
		return -1;

	sbp = sbuf;
	s = tgetstr("pc", &sbp); /* get pad character */
	if(s)
		PC = *s;

	t_lines = tgetnum("li");
	t_columns = tgetnum("co");
	automargins = tgetflag("am");

	outp = clearbuf;         /* fill clearbuf with clear screen command */
	outlp = &clearbuflen;
	clearbuflen = 0;
	sbp = cursorm;
	cm = tgetstr("cm", &sbp);

	sbp = sbuf;
	s = tgetstr("cl", &sbp);
    	if(s)
      		tputs(s, t_lines, outcf);
    	outp = cleolbuf;         /* fill cleolbuf with clear to eol command */
    	outlp = &cleolbuflen;
    	cleolbuflen = 0;
    	sbp = sbuf;
    	s = tgetstr("ce", &sbp);
    	if(s)
      		tputs(s, 1, outcf);
    	outp = scrollrev;
    	outlp = &scrollrevlen;
    	scrollrevlen = 0;
    	sbp = sbuf;
    	s = tgetstr("sr", &sbp);
    	if(s)
      		tputs(s, 1, outcf);
    	outp = strtstandout;
	outlp = &strtstandoutlen;
	strtstandoutlen = 0;
	sbp = sbuf;
	s = tgetstr("so", &sbp);
	if(s)
		tputs(s, 1, outcf);
    	outp = endstandout;
    	outlp = &endstandoutlen;
    	endstandoutlen = 0;
    	sbp = sbuf;
    	s = tgetstr("se", &sbp);
    	if(s)
      		tputs(s, 1, outcf);
    	sbp = UPbuf;
    	UP = tgetstr("up", &sbp);
    	sbp = BCbuf;
    	BC = tgetstr("bc", &sbp);
	if(cm)
    		return 0;
	else
	{
		t_lines = 24;
		t_columns = 80;
		return 1;
	}
}

void	do_move(destcol, destline, outc)
int	destcol,
	destline,
	(*outc)();
{
	tputs(tgoto(cm, destcol, destline), 0, outc);
}
