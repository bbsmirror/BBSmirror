/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    SccsId[] = "@(#)complete.c	1.1	7/8/95";
#endif

#include "bbs.h"

extern	int	scrint;
extern	jmp_buf	byebye;

word *toplev = NULL, *current = NULL;

void	FreeNameList() 
{
	word	*p,
		*tmp;

	for (p=toplev; p!=NULL; p=tmp)
	{
		tmp = p->next;
		free(p->word);
		free(p);
	}
}

void	CreateNameList()
{
	if (toplev)
		FreeNameList();
	toplev = NULL;
	current = NULL;
}

void	AddNameList(name)
char	*name;
{
	word	*node;

	node = (struct word *)malloc(sizeof(struct word));
	node->next = NULL;
	node->word = (char *)malloc(strlen(name)+1);
	strcpy(node->word,name);
	if (toplev)
	{
		current->next = node;
		current = node;
		return;
	}
	toplev = node;
	current = node;
	return;
}

int	NumInList(list)
word	*list;
{
	int	i;
	
	for (i=0;list != NULL;i++,list = list->next);
	return i;
}

void	ApplyToNameList(fptr)
int	((*fptr)());
{
	word	*p;

	for (p = toplev;p!=NULL;p = p->next)
		(*fptr)(p->word);
}

int	chkstr(tag,name)
char	*tag,
	*name;
{
	char	*otag = tag,
		*oname = name;

	while (*tag != '\0')
	{
		if (toupper(*tag) != toupper(*name)) 
			return 0;
		tag++;
		name++;
	}

	if (*name == '\0')
		strcpy(otag, oname);

	return 1;
}

word	*GetSubList(tag,list)
char	*tag;
word	*list;
{
	word	*wlist,
		*wcurr;

	wlist = NULL;
	wcurr = NULL;
	while (list != NULL)
	{
		if (chkstr(tag,list->word))
		{
			word	*node;

			node = (struct word *)malloc(sizeof(struct word));
			node->word = list->word;
			node->next = NULL;
			if (wlist)
				wcurr->next = node;
			else
				wlist = node;
			wcurr = node;
		}
		list = list->next;
	}
	return wlist;
}

void	ClearSubList(list)
word	*list;
{
	word	*tmp;
	
	while (list)
	{
		tmp = list->next;
		free(list);
		list = tmp;
	}
}

int	MaxLen(list,count)
word	*list;
int	count;
{
	int	len = strlen(list->word);
	
	while (list!=NULL && count)
	{
		int t = strlen(list->word);
		if (t > len)
			len = t;
		list=list->next;
		count--;
	}
	return len;
}

int	namecomplete(prompt,data)
char	*prompt,
	*data;
{
	char	*temp;
	int	ch,
		count = 0,
		clearbot = NA;

	if (toplev == NULL)
		return -1;
	if (scrint)
	{
		word	*cwlist,
			*morelist;
		int	x,
			y,
			origx,
			origy;

		if (prompt != NULL)
		{
			prints(NA, "%s",prompt);
			clrtoeol();
		}
		temp = data;
		
		if (toplev == NULL)
			AddNameList("");
		cwlist = GetSubList("",toplev);
		morelist = NULL;
		getyx(&y,&x);
		getyx(&origy, &origx);

		while ((ch = igetch()) != EOF)
		{
			if (ch == '\n' || ch == '\r')
			{
				*temp = '\0';
				prints(NA, "\n");
				if (NumInList(cwlist) == 1)
					strcpy(data,cwlist->word);
				ClearSubList(cwlist);
				break;
			}

			if (ch == ' ')
			{
				int	col,
					len;
				  
				if (NumInList(cwlist) == 1)
				{
					strcpy(data,cwlist->word);
					move(y,x);
					prints(NA, "%s",data+count);
					count = strlen(data);
					temp = data + count;
					getyx(&y,&x);
					continue;
				}
		                clearbot = YEA;
				col = 0;
				if (!morelist)
					morelist = cwlist;
				len = MaxLen(morelist,NUMLINES);
				move(3,0);
				clrtobot();
				prints(YEA, 
"------------------------------- Completion List -------------------------------");
				while (len+col < 80)
				{
					int	i;

					for (i = NUMLINES; (morelist) && (i>0);
						i--, morelist = morelist->next)
					{
						move(4+(NUMLINES - i),col);
						prints(NA, "%s",morelist->word);
					}
					col += len+2;
					if (!morelist)
						break;
					len = MaxLen(morelist,NUMLINES);
				}
				if (morelist)
				{
					move(23,0);
					prints(YEA, "-- More --");
				}
				move(y,x);
				continue;
			}
			if (ch == '\177' || ch == '\010')
			{
				if (temp == data)
					continue;
				temp--;
				count--;
				*temp = '\0';
				ClearSubList(cwlist);
				cwlist = GetSubList(data,toplev);
				morelist = NULL;
				x--;
				move(y,x);
				outc(' ');
				move(y,x);
				continue;
			}
			if (count < STRLEN)
			{
				word	*node;

				*temp++ = ch;
				count++;
				*temp = '\0';
				node = GetSubList(data,cwlist);
				if (node == NULL)
				{
					bell(1);
					temp--;
					*temp = '\0';
					count--;
					continue;
				}
				ClearSubList(cwlist);
				cwlist = node;
				morelist = NULL;
				move(y,x);
				outc(ch);
				x++;
			}
		}
		if (ch == EOF)
			longjmp(byebye,-1);
	        prints(NA, "\n");
	        refresh();
	        if (clearbot)
		{
	        	move(3,0);
	        	clrtobot();
	        }
		if (*data)
		{
			move(origy,origx); 
			prints(NA, "%s\n", data); 
		}
		return 0;
	}
	if (prompt != NULL)
	{
		printf("%s",prompt);
		fflush(stdout);
	}
	if (!fgets(data,STRLEN,stdin))
		longjmp(byebye,-1);
	if (temp = (char *)strchr(data,'\n'))
		*temp = '\0';
	return 0;
}
