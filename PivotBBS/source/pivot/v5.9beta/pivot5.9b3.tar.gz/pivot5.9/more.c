/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    SccsId[] = "@(#)more.c	1.2	7/26/95";
#endif

#include "bbs.h"
#include <sys/types.h>
#ifndef XINU
#include <sys/stat.h>
#endif

extern	int	t_lines,
		dumb_term;
extern	userec	cuser;

int	readln(fp, buf)
FILE	*fp;
char	*buf;
{
	int	i = 0,
		ansi = 0,
		bytes = 0,
		ansinum = 0,
		ch;

	while ((ch = getc(fp)) != EOF)
	{
		bytes++;
		if (ch == '\n')
		{
			buf[i] = '\0';
			return bytes;
		}

		if (ch == '\t')
		{
			do
			{
				buf[i++] = ' ';
			}
			while ((i % 8) != 0);
		}
		if (ISPRINT(ch) || ch == KEY_ESC)
		{
			if (ch == KEY_ESC)
				ansi = YEA;
			if (ansi)
			{
				ansinum++;
				if (ch != '[' && ch != ';' && !isalnum(ch) &&
					ch != KEY_ESC)
					ansi = NA;
			}
			buf[i++] = ch;
		}

		if (i-ansinum >= 79 || i > 254)
		{
			buf[i] = '\0';
			return bytes;
		}
	}

	if (i == 0)
		return 0;
	else
		buf[i] == '\0';

	return bytes;
}

int	more(filename, promptend)
char	*filename;
int	promptend;
{
	FILE	*fp;
	int	ch,
		i,
		viewed,
		pos,
		full_screen = NA,
		numbytes,
		quit=NA;
	long	tsize;
	struct	stat	st;
	char	buf[256];

	if ((fp = fopen(filename,"r")) == NULL)
		return -1;

	if (fstat(fileno(fp), &st))
		return -1;

	tsize = st.st_size;
	clear();
	i = pos = viewed = 0;

	numbytes = readln(fp,buf);

	do
	{
		if (!strcmp(buf, "--active"))
		{
			i = t_lines-2;
			full_screen = NA;
			numbytes = readln(fp,buf);
		}

		if (!strcmp("++active", buf) && HAS_SET(SET_ACTIVE) &&
			HAS_SET(SET_ANSIMODE) && !full_screen)
		{
			full_screen = YEA;
			continue;
		}

		if (!numbytes)
			break;

		viewed += numbytes;
		if (strstr(buf, "�� �ޥεo�H�H") || strstr(buf, "�� �ޭz�y")
			|| (strstr(buf, "==>") && strchr(buf, '@')) ||
			(strstr(buf, ") ����") && strchr(buf, '@')) ||
			(strstr(buf, ") wrote:") && strchr(buf, '@')) ||
			(strstr(buf, "followed") && strstr(buf, "post")))
		{
			prints(NA, "[1;32m%s[m\n", buf);
		}
		else
		{
			if (buf[0] == ':' || buf[0] == '>' ||
				(buf[0] == ' ' && buf[1] == '>'))
				prints(NA, "[36m%s[m\n",buf);
			else
				prints(NA, "%s\n", buf);
		}
		if (full_screen)
			refresh();
		pos++;
		i++;

		if (pos == t_lines)
		{
			scroll();
			pos--;
		}

		numbytes = readln(fp,buf);
		if (!numbytes)
			break;

		if (i == t_lines -1 && !full_screen)
		{
			move(t_lines-1,0);
			if (!dumb_term)
			{
				prints(YEA, "[m[1;34;42m --More-- (%d%%) [m",
					(viewed*100)/tsize);
				prints(NA, "%s    %s    %s\n",
					"[1;32;44m     [��|q] [33m����",
					"[1;32m[��|Enter] [33m�U���@��",
					"[1;32m[��|Space] [33m�U�@��   [m");
			}
			else
				bell(1);

			while ((ch = egetch()) != EOF)
			{
				if (ch == ' ' || ch == KEY_RIGHT)
				{
					move(t_lines-1,0);
					clrtoeol();
					refresh();
					i = 1;
					break;
				}

				if (ch == 'q' || ch == KEY_LEFT)
				{
					quit = YEA;
					break;
				}

				if (ch == '\r' || ch == KEY_DOWN || ch == 'h')
				{
					move(t_lines-1,0);
					clrtoeol();
					refresh();
					i = t_lines-2;
					break;
				}
				bell(1);
			 }

			 if (quit)
				break;
		} 
	}
	while (numbytes);

	fclose(fp);
	move(t_lines-1, 0);
	clrtoeol();

	if (promptend)
	{
		pressreturn();
	}

	return 0;
}
