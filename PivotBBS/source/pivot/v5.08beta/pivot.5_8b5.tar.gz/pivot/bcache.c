/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)bcache.c   5.04 3/19/95 (C) 1993 University \
of NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include "bbs.h"

long	ucached = 0;
char	ucache[MAXUSERS][IDLEN+1];
int	numuents = 0,
	numboards = -1;
userec	muser;
shthd	bcache[MAXBOARD];

int	boardcache(fptr)
bhd	*fptr;
{
	if (!HAS_PERM(fptr->readlevel))
		bcache[numboards].filename[0] = ' ';
	else
		strcpy(bcache[numboards].filename,fptr->filename);

	strcpy(bcache[numboards].manager1,fptr->manager1);
	strcpy(bcache[numboards].manager2,fptr->manager2);
	strcpy(bcache[numboards].manager3,fptr->manager3);
	strcpy(bcache[numboards].sender, fptr->sender);
	bcache[numboards].postlevel = fptr->postlevel;
	strcpy(bcache[numboards].title,fptr->title);
	bcache[numboards].flag = fptr->flag;
	bcache[numboards].group = fptr->group;
	bcache[numboards].readlevel = fptr->readlevel;
	bcache[numboards].accessed = fptr->accessed[usernum];
	if (numboards < MAXBOARD)
		numboards++;

	return 0;
}

int	apply_boards(func, group, yank)
int	(*func)(),
	group,
	yank;
{
	register	int	i;

	if (numboards < 0)
	{
        	numboards = 0;
        	apply_record(BOARDS,boardcache,sizeof(bhd));
	}

	return(group_boards(func, group, yank));
}

int	haspostperm(bname)
char	*bname;
{
	int	i;

	if ((i = getbnum(bname)) == 0)
		return 0;
	if (!HAS_PERM(PERM_POST))
		return 0;

	return (HAS_PERM(bcache[i-1].postlevel));
}

int	fillucache(uentp)
userec	*uentp;
{
	if (numuents < MAXUSERS)
	{
        	strncpy(ucache[numuents],uentp->userid,IDLEN+1);
        	ucache[numuents++][IDLEN] = '\0';
    	}

	return 0;
}

void	resolve_ucache(void)
{
	struct	stat	st;

	if (stat(FLUSH,&st) < 0)
		st.st_mtime++;

	if (ucached < st.st_mtime)
	{
        	numuents = 0;
        	apply_record(PASSFILE,fillucache,sizeof(userec));
        	ucached = st.st_mtime;
    	}
}

int	u_namelist(void)
{
	register int i;

	resolve_ucache();
	CreateNameList();
	for(i = 0; i < numuents; i++)
	{
		if (ucache[i][0] != '\0' && stricmp("new", ucache[i]))
			AddNameList(ucache[i]);
	}
	return 0;
}

int	searchuser(userid)
char	*userid;
{
	int	i,
		crc,
		tell = 1,
		fsize,
		stsize = sizeof(ucrc),
		readnum,
		fd;
	char	ss[STRLEN];
	ucrc	crcbuf[GETCRC];
	FILE	*crcfile;
	struct	stat	stbuf;

	strcpy(ss, userid);
	crc = GetStrCrc(ss);

        if ((fd = open(CRCIDX, O_RDONLY, 0)) == -1)
		return 0;
	stat(CRCIDX, &stbuf);
	fsize = stbuf.st_size/stsize;

	while (fsize > 0)
	{
		fsize -= GETCRC;
		readnum = (fsize > 0) ? GETCRC : (fsize + GETCRC);

       		if (!read(fd, &crcbuf, (readnum * stsize)))
		{
               		close(fd);
               		return 0;
       		}

		for(i=1; i<= readnum; i++, tell++)
		{
			if (crcbuf[i-1].crcnum == crc)
			{
        			close(fd);
       				return tell;
        		}
		}
	}
	close(fd);
	return 0;
}

int	apply_users(func)
void	(*func)();
{
	int	i;

	resolve_ucache();
	for(i = 0; i < numuents; i++)
	{
		(*func)(ucache[i],i+1);
	}

	return 0;
}

int	getuser(userid)
char	*userid;
{
	int	uid = searchuser(userid);

	if (uid == 0)
		return 0;

	get_record(PASSFILE, (char *)&muser, sizeof(muser), uid);

	if (stricmp(userid, muser.userid))
	{
		bzero(&muser, sizeof(muser));
		substitute_passwd(PASSFILE, &muser, YEA, uid);
		return 0;
	}

	return uid;
}

/* End of file: bcache.c */
