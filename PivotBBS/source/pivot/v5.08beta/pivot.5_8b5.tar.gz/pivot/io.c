/*
	PIVOT Bulletin Board System
	Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 1, or (at your option)
	any later version.

	This program is distributed in the hope that it will be useful, 
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char	sccsid[] = "@(#)io.c   5.04 3/19/95 (C) 1993 University of \
NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include "bbs.h"
#include <sys/types.h>
#include <sys/time.h>
#include <errno.h>

char	outbuf[OBUFSIZE], 
	inbuf[IBUFSIZE];
int	obufsize = 0, 
	ibufsize = 0, 
	icurrchar = 0, 
	i_newfd  = 0;
struct	timeval	i_to, 
		*i_top = NULL;
int	(*flushf)() = NULL;

static	int	i_mode = INPUT_ACTIVE;

void	hit_alarm_clock(void)
{
	if (HAS_PERM(PERM_NOTIMEOUT))
		return;
	if (i_mode == INPUT_IDLE)
	{
		goodbye();
	}
	i_mode = INPUT_IDLE;
	alarm(IDLE_TIMEOUT);
}

void	init_alarm(void)
{
	signal(SIGALRM, (void *)hit_alarm_clock);
	alarm(IDLE_TIMEOUT);
}

void	oflush(void)
{
	if (obufsize)
	write(1, outbuf, obufsize);
		obufsize = 0;
}

void	output(s, len)
char	*s;
{
	if (obufsize+len > OBUFSIZE)
	{
		write(1, outbuf, obufsize);
		obufsize = 0;
	}
	bcopy(s, outbuf+obufsize, len);
	obufsize+=len;
}

int	ochar(c)
{
	if (obufsize > OBUFSIZE-1)
	{
		write(1, outbuf, obufsize);
		obufsize = 0;
	}
	outbuf[obufsize++] = c;
}

void	add_io(fd, timeout)
int	fd, 
	timeout;
{
	i_newfd = fd;
	if (timeout)
	{
		i_to.tv_sec = timeout;
		i_to.tv_usec = 0;
		i_top = &i_to;
	}
	else
		i_top = NULL;
}

void	add_flush(flushfunc)
int	(*flushfunc)();
{
	flushf = flushfunc;
}

int	num_in_buf(void)
{
	return icurrchar - ibufsize;
}

int	kbhit(void)
{
	fd_set	readfds;
	struct	timeval	to;
	int	sr;
	char	buf;

	to.tv_sec = 0;
	to.tv_usec = 1;

	FD_ZERO(&readfds);
	FD_SET(0, &readfds);

	if (select(2, &readfds, NULL, NULL, &to) < 0)
		return -1;

	if (FD_ISSET(0, &readfds))
	{
		read(0, &buf, 1);
		return buf;
	}
	else
		return -1;
}

int	igetch(void)
{
igetagain:
	if (ibufsize == icurrchar)
	{
		fd_set	readfds;
		struct	timeval	to;
		int	sr;

		to.tv_sec = 0;
		to.tv_usec = 0;
		FD_ZERO(&readfds);
		FD_SET(0, &readfds);
		if (i_newfd)
			FD_SET(i_newfd, &readfds);
		if ((sr = select(getdtablesize(), &readfds, NULL, NULL, 
			&to)) <= 0)
		{
			if (flushf)
				(*flushf)();
			if (dumb_term)
				oflush();
			else
				refresh();
			FD_ZERO(&readfds);
			FD_SET(0, &readfds);
			if (i_newfd)
				FD_SET(i_newfd, &readfds);
			while ((sr = select(getdtablesize(), &readfds, 
				NULL, NULL, i_top)) <0)
			{
				if (errno == EINTR)
					continue;
				else
				{
					perror("select");
					fprintf(stderr, 
						"abnormal select conditions\n");
					return -1;
				}
			}
			if (sr == 0)
				return I_TIMEOUT;
		}
		if (i_newfd && FD_ISSET(i_newfd, &readfds))
			return I_OTHERDATA;
		while ((ibufsize = read(0, inbuf, IBUFSIZE)) <= 0)
		{
			if (ibufsize == 0)
				longjmp(byebye, -1);
			if (ibufsize < 0 && errno != EINTR)
				longjmp(byebye, -1);
		}
		icurrchar = 0;
	}
	i_mode = INPUT_ACTIVE;
	switch(inbuf[icurrchar])
	{
		case CTRL('Q'):
			SWITCH_SET(SET_ANSIMODE);
		case CTRL('L'):
			redoscr();
			icurrchar++;
			goto igetagain;
		default:
			break;
	}
	return inbuf[icurrchar++];
}

int	getdata(line, col, prompt, buf, len, echo, cflag)
int	line, 
	col, 
	len, 
	echo,
	cflag;
char	*prompt, 
	*buf;
{
	int	ch,
		clen = 0,
		curr = 0,
		x,
		y;
	char	tmp[STRLEN];

	if (cflag)
		bzero(buf, sizeof(buf));
	move(line, col);
	if (prompt)
		prints(NA, "%s", prompt);
	getyx(&y, &x);
	clen = strlen(buf);
	curr = clen = (clen > len) ? len : clen;
	buf[curr] = '\0';
	prints(NA, "%s", buf);

	if (dumb_term)
	{
		while ((ch = igetch()) != '\r')
		{
			if (ch == '\n')
				break;
			if (ch == '\177' || ch == CTRL('H'))
			{
				if (clen == 0)
				{
					bell(1);
					continue;
				}
				clen--;
				ochar(CTRL('H'));
				ochar(' ');
				ochar(CTRL('H'));
				continue;
			}
#ifdef BIT8
			if (!isprint2(ch))
#else
			if (!isprint(ch))
#endif
			{
				bell(1);
				continue;
			}
			if (clen >= len-1)
			{
				bell(1);
				continue;
			}
			buf[clen++] = ch;
			if (echo)
				ochar(ch);
			else
				ochar('*');
		}
		buf[clen] = '\0';
		prints(NA, "\n");
		oflush();
		return clen;
	}

	clrtoeol();

	while ((ch = igetkey()) != '\r')
	{
		if (ch == '\n')
			break;
		if (ch == '\177' || ch == CTRL('H'))
		{
			if (curr == 0)
			{
				bell(1);
				continue;
			}
			strcpy(tmp, &buf[curr]);
			buf[--curr] = '\0';
			strcat(buf, tmp);
			clen--;
			move(y, x);
			prints(NA, "%s", buf);
			clrtoeol();
			move(y, x + curr);
			continue;
		}
		if (ch == KEY_LEFT)
		{
			if (curr == 0)
			{
				bell(1);
				continue;
			}
			curr--;
			move(y, x + curr);
			continue;
		}
		if (ch == KEY_RIGHT)
		{
			if (curr >= clen)
			{
				curr = clen;
				bell(1);
				continue;
			}
			curr++;
			move(y, x + curr);
			continue;
		}
#ifdef BIT8
		if (!isprint2(ch))
#else
		if (!isprint(ch))
#endif
		{
			bell(1);
			continue;
		}

		if (x + clen >= scr_cols || clen >= len-1)
		{
			bell(1);
			continue;
		}
 
		if (!buf[curr])
		{
			buf[curr + 1] = '\0';
			buf[curr] = ch;
		}
		else
		{
			strncpy(tmp, &buf[curr], len);
			buf[curr] = ch;
			buf[curr + 1] = '\0';
			strncat(buf, tmp, len - curr);
		}
		curr++;
		clen++;
		if (echo)
		{
			move(y, x);
			prints(NA, "%s", buf);
			move(y, x + curr);
		}
		else
			prints(NA, "*");
	}
	buf[clen] = '\0';
	prints(NA, "\n");
	refresh();
	return clen;
}

int	igetkey(void)
{
	int	mode, 
		ch, 
		last;

	mode = last = 0;

	for (;;)
	{
		ch = igetch();
		if (ch == KEY_ESC)
			mode = 1;
		else if (mode == 0)
			return ch;
		else if (mode == 1)
		{
			if (ch == '[' || ch == 'O')
				mode = 2;
			else if (ch == '1' || ch == '4')
				mode = 3;
			else 
				return ch;
		}
		else if (mode == 2)
		{
			if (ch >= 'A' && ch <= 'D')   
				return KEY_UP + (ch - 'A');
			else if (ch >= '1' && ch <= '6')
				mode = 3;
			else
				return ch;
		}
		else if (mode == 3)
		{
			if (ch == '~')
				return KEY_HOME + (last - '1');
			else
				return ch;
		}
		last = ch;
	}
}

int	reply(x, y, prompt, flag)
int	x, 
	y, 
	flag;
char	*prompt;
{
	int	ch;

	move(x, y);
	prints((flag) ? YEA : NA, "%s", prompt);
	clrtoeol();
	ch = igetkey();

	return(ch);
}

int	ask(prompt)
char	*prompt;
{
	int	ch;

	ch = reply(0, 0, prompt, YEA);
	move(0, 0);
	clrtoeol();

	return(ch);
}
