/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef	_CHATD_H_
#define	_CHATD_H_

#define	TABLE	getdtablesize()
#define	RECPATH	"/home/bbs/reclog/chatd.log"

#define MAX_CHAT_USER 	32
#define	ID_LEN		12
#define NL_LEN		10
#define TOPLEN		79
#define CN_LEN		10

#ifndef	BADCIDCHARS
#define	BADCIDCHARS	" /*\255"
#endif

#ifndef SOMAXCONN
#define SOMAXCONN 	5
#endif

#define MAXUSER 	100
#define BUF_LEN 	256
#define CHAT_OP		0x0001
#define	CLOAK		0x0002
#define	VCLOAK		0x0004
#define	ACLOAK		0x0008
#define	MAINTAIN	0x0008
#define ROOM_LOCK	0x0001
#define ROOM_SEC	0x0002
#define	ROOM_TOPIC	0x0004


/* LOCK chat */
#define IS_LOCK(x)	(x->mode & ROOM_LOCK)
#define SITE_LOCK(x)	(x->mode |= ROOM_LOCK)
#define RM_LOCK(x)	(x->mode &= ~ROOM_LOCK)

/* secret chat */
#define	IS_SEC(x)	(x->mode & ROOM_SEC)
#define SITE_SEC(x)	(x->mode |= ROOM_SEC)
#define RM_SEC(x)	(x->mode &= ~ROOM_SEC)

/* oper topic only */
#define	IS_TOPLIM(x)	(x->mode & ROOM_TOPIC)
#define SITE_TOPLIM(x)	(x->mode |= ROOM_TOPIC)
#define RM_TOPLIM(x)	(x->mode &= ~ROOM_TOPIC)

#define IS_OP(x) 	(x->mode & CHAT_OP)
#define SITE_OP(x) 	(x->mode |= CHAT_OP)
#define RM_OP(x) 	(x->mode &= ~CHAT_OP)	

#define	SITE_ACLOAK(x)	(x->mode |= ACLOAK)
#define	IS_ACLOAK(x)	(x->mode & ACLOAK)
#define IS_CLOAK(x)	(x->mode & CLOAK)
#define VIEW_CLOAK(x)	(x->mode & VCLOAK)
#define SITE_CLOAK(x)	(x->mode |= CLOAK)
#define	SITE_VCLOAK(x)	(x->mode |= VCLOAK)
#define RM_CLOAK(x)	(x->mode &= ~CLOAK)

#define	IS_MAIN(x)	(x->mode & MAINTAIN)
#define	SITE_MAIN(x)	(x->mode |= MAINTAIN)
#define	RM_MAIN(x)	(x->mode &= ~MAINTAIN)

#define EXIT_LOSTCONN 	1
#define EXIT_LOGOUT	2
#define	EXIT_KICK	3

typedef struct	User	USER;
typedef struct 	Channel	CHANNEL;
typedef	struct 	Link	LINK;
typedef struct  Command	Command;
typedef	struct	CONTEXT	HELP;                                           

struct	CONTEXT
{
	char	*text;
};

struct 	User
{
	struct 	User	*next,
			*prev;
	CHANNEL	*channel;

	LINK	*ignore;
	
	char	id[ID_LEN+1],
		nick[NL_LEN+1];
	int 	c_pid,
		ufd,
	 	mode,
		level;
};

struct	Channel
{
	struct	Channel	*next,
			*prev;
	LINK	*invite,
		*banlist;
	char	topic[TOPLEN+1],
		chname[CN_LEN + 1];
	int 	unum,
	 	mode;
};

struct	Link
{
	struct	Link	*next,
			*prev;
	union
	{
		char	*cp;
		CHANNEL	*cptr;
		USER	*uptr;
	}
	value;
};
			
struct	Command
{
	int 	(*fun)();
};

extern	int 	read_message(void);			/* OK */
extern 	int	do_new_user(void);			/* OK */
extern	int	do_join(void);				/* OK */
extern	int	do_public(void);			/* OK */
extern 	int	do_private(void);    /*	to message	   OK */ 
extern 	int	do_who(void);				/* OK */
extern	int	do_room_lst(void);			/* OK */		
extern	int	do_topic(void);				/* OK */
extern	int	do_invite(void);			/* OK */
extern	int	do_ban(void);				/* OK */
extern	int	do_nick(void);				/* OK */
extern	int	do_oper(void);				/* OK */
extern	int	do_quit(void);				/* OK */
extern	int	do_kick(void);				/* OK */
extern	int	do_help(void);				/* OK */
extern	int	do_setroom(void);			/* ok */
extern	int	do_lst_inv(void);			/* ok */
extern	int	do_lst_ban(void);			/* ok */
extern	int	do_rm_inv(void);			/* ok */
extern	int	do_rm_ban(void); 			/* ok */
extern	int	do_ignore(void);			/* ok */
extern	int	do_lst_ign(void);			/* ok */
extern	int	do_rm_ign(void);			/* ok */
extern	int	do_adv_hlp(void);			/* ok */
extern	int	do_whos(void);				/* ok */
extern	int	do_cloak(void);				/* ok */

extern  void	send_to_room(int , char *, CHANNEL *);	/* OK */   
extern  void	priv_to_room(int , char *, CHANNEL *);	/* OK */   
extern 	void	do_send(fd_set *, char *);		/* OK */
extern 	void	enter_room(char *);			/* OK */
extern 	CHANNEL	*search_room(char *);			/* OK */
extern	USER	*search_user(char *);			/* OK */
extern	LINK	*search_link(LINK *, char *);		/* ok */
extern	void	room_insert(CHANNEL *, CHANNEL *);	/* OK */
extern	void	user_insert(USER *, USER *);		/* OK */
extern  void    link_insert(LINK *, LINK *);		/* OK */
extern 	void	send_to_user(int, char *, USER *);	/* OK */
extern 	int	open_room(LINK *, USER *);		/* OK */
extern	void	exit_room(USER *, int);   		/* OK */
extern	char	*advance(char *);			/* OK */
extern	void	bord_link(LINK *);			/* OK */ 
extern	int 	logout_user(USER *); 			/* OK */
extern	void	fixchatid(char *);			/* ok */
extern	void	rm_link(LINK *);			
extern	void	sig_catcher(int);

#endif	_CHATD_H_
