#include <stdio.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <fcntl.h>
#include <time.h>
#include "define.h"
#include "struct.h"

#define MYPASSFILE	"/.PASSWDS"
#define BBSDOMAIN	"@bbs.nchu.edu.tw"
#define BBSGID		99
#define BBSUID		99

userec	cuser;

void	eat_queue(fin)
FILE	*fin;
{
	char	genbuf[STRLEN];

	while(fgets(genbuf, sizeof(genbuf), fin) != NULL);
}

char	*Ctime(clock)
time_t	*clock;
{
        char	*foo;
        char	*ptr = ctime(clock);

        if((int)(foo = (char *)rindex(ptr, '\n')))
                *foo = '\0';

        return (ptr);
}

int	strncmpi(s1,s2,n)
char	*s1,
	*s2;
int	n;
{
	for(;n;s1++,s2++,n--)
	{
        	int	ret;
 
		if(*s1=='\0' && *s2 == '\0')
			break;
		if((ret = (isalpha(*s1)?*s1|0x20:*s1) -
			(isalpha(*s2)?*s2|0x20:*s2)) !=0)
			return ret;
	}
	return 0;
}

int	uidcmp(uid,up)
char	*uid;
userec	*up;
{
	if (!strncmpi(uid, up->userid, sizeof(up->userid)))
	{
		strncpy(uid, up->userid, sizeof(up->userid));
		return 1;
	}
	else
		return 0;
}

int	dosearchuser(userid)
char	*userid;
{
	userec	auser;

	if (access(MYPASSFILE, R_OK) != 0)
	{
		printf("cannot find file: %s\n", MYPASSFILE);
		exit(-1);
	}

	return search_record(MYPASSFILE, &auser, sizeof(cuser),
        	uidcmp, userid);
}

save_mail(fin, userid)
FILE	*fin;
char	*userid;
{
	mhd	newmessage;
	struct	tm	*ptime;
	time_t	dtime;
	char	fname[512],
		buf[256],
		genbuf[256],
		title[256],
		sender[80],
		*ip;
	struct	stat	st;
	int	fp;
	FILE	*fout;

	if(!dosearchuser(userid))
	{
		printf("cannot find user %s in this bbs\n", userid);
		eat_queue(fin);
		return -1;
	}
	
	sprintf(genbuf, "/home/%s/mail", userid);
	printf("mail box is: %s\n", genbuf);
	
	if(stat(genbuf,&st) == -1)
	{
		if(mkdir(genbuf,0755) == -1) 
		{
			printf("mail box create error\n");
			eat_queue(fin);
			return -1;
		}
	}
	else
	{	
		if(!(st.st_mode & S_IFDIR))
		{
			printf("mail box is not a DIR\n");
			eat_queue(fin);
			return -1;
		}
	}

        printf("Ok, dir is %s\n", genbuf);

	bzero(&newmessage, sizeof(newmessage));
	time(&dtime);
	ptime=localtime(&dtime);
	sprintf(fname, "M.%d.A", dtime);
	sprintf(genbuf, "/home/%s/mail/%s", userid, fname);
	ip = (char *)rindex(fname,'A');
	while((fp = open(genbuf,O_CREAT|O_EXCL|O_WRONLY,0644)) == -1)
	{
		if(*ip == 'Z')
		  ip++,*ip = 'A', *(ip + 1) = '\0';
		else
		  (*ip)++;
		sprintf(genbuf, "/home/%s/mail/%s", userid,fname);
	}
	close(fp);
	strcpy(newmessage.filename, fname);

	sprintf(genbuf, "/home/%s/mail/%s", userid, fname);
        printf("Ok, the file is %s\n", genbuf);

        if ((fout = fopen(genbuf, "w")) == NULL)
	{
        	printf("Cannot open %s \n", genbuf);
		eat_queue(fin);
        	return -1;
        }
	else
	{
        	time_t	tmp_time;

		while(fgets(genbuf, 255, fin) != NULL)
		{
			if((char *)strstr(genbuf, "From ") == genbuf)
			{
				strtok(genbuf, " ");
				strcpy(sender, (char *)strtok(NULL, " "));
				if(strchr(sender, '@') == NULL)
					strcat(sender, BBSDOMAIN);
				strncpy(newmessage.sender, sender, STRLEN);
				continue;
			}
			if((char *)strstr(genbuf, "Subject: ") == genbuf)
			{
				int len;

				len = strlen(genbuf+9);
				strncpy(title, genbuf+9, len-1);
				strncpy(newmessage.title, title, STRLEN);
				continue;
			}
			if((char *)strstr(genbuf, "\n") == genbuf)
				break;
		}
		time(&tmp_time);
		fprintf(fout, "�H��H: %s [=InterNet E-mail=]\n", sender);
		fprintf(fout, "��  �D: %s\n", title);
		fprintf(fout, "�o�H��: ��ں����H�� (%s)\n\n", Ctime(&tmp_time));

		fputs(genbuf, fout);
		while (fgets(genbuf, 255, fin) != NULL)
		{
			fputs(genbuf, fout);
		}
		fclose(fout);
	}

/* append the record to the MAIL control file */
	sprintf(genbuf, "/home/%s/mail/%s", userid, FHDIR);
	printf("append_record\n");
	return append_record(genbuf, &newmessage, sizeof(newmessage));
}


void	main(argc, argv)
int	argc;
char	*argv[];
{
	char receiver[256];
	char genbuf[256];

	/* argv[1] is userid in bbs   */

	if (argc != 2)
	{
		char *p = (char *)rindex(argv[0], '/');

		printf("Usage: %s receiver_in_bbs\n", p ? p+1 : argv[0]);
		exit(0);
	}

	if (chroot(BBSHOME) == 0)
	{
		chdir("/");
		printf("Chroot ok!\n");
	}
	else
	{
		chdir("/");
		printf("Already chroot\n");
	}

	setreuid(BBSUID, BBSUID);
	setregid(BBSGID, BBSGID);

	strcpy(receiver, argv[1]);
	printf("mail received by: %s\n", receiver);
	save_mail(stdin, receiver);
	printf("work completed\n");
	exit(0);
}
