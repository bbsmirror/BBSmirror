/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
/*
 * make new board file from old one
 * convert origional .BOARDS to new one,
 * please modify the struct of oldboard by yourself.
 */

#include <sys/file.h>
#include <time.h>
#include "define.h"
#include "struct.h"
#define OLDMAXUSERS	MAXUSERS	/* your old max users define */

struct oldboard {
        char    filename[80];
        char    manager1[13]; /* I think you dont have this one */
        char    manager2[13]; /* either */
        char    manager3[13]; /* either */
        char    sender[39];   /* either */
                              /* in Eagle above is 'char owner[80];' */
        char    listserv;     /* no this one */
        char    bbsnet;       /* no this one */
        char    title[79];    /* Eagle is '80' */
        uschar  vote;         /* no this one */
        usint   level;        
        uschar  accessed[OLDMAXUSERS];
};

/* usage:
 *	progname old.BOARD conver_to_filename
 *
 *  suggest:
 *	1. cp .BOARDS oldboard
 *	2. mkboardfl oldboard newboard
 *	3. mv newboard .BOARDS
 *
 *  compile:
 *	gcc -o mkboardfl mkboardfl.c
 */
main(argc, argv)
int argc;
char *argv[];
{
	int count =0, insize, outsize;
	int fin, fout;
	struct oldboard old;
	boardheader new;
	char source[80], target[80];

	insize = sizeof(struct oldboard);
	outsize = sizeof(struct boardheader);
	strcpy(source, argv[1]);
	strcpy(target, argv[2]);

	printf("Size of old board = %d\nSize of new board = %d\n", insize, outsize);
	printf("source file: %s\n", source);
	printf("target file: %s\n", target);
	if((fin = open(source, O_RDONLY)) == -1) {
		printf("open source file error\n");
		exit(0);
	}
	if((fout = open(target, O_WRONLY|O_CREAT|O_TRUNC, 0644)) == -1) {
		printf("open target file error\n");
		exit(0);
	}
	while(read(fin, (char *)&old, insize) == insize)
	{
		strcpy(new.filename, old.filename);
		strcpy(new.manager1, old.manager1);
		strcpy(new.manager2, old.manager2);
		strcpy(new.manager3, old.manager3);
		strcpy(new.sender, old.sender);
		strcpy(new.title, old.title);
		bcopy(old.accessed, new.accessed, STRLEN);
		new.flag = 0;
		if(old.bbsnet == '#')
			new.flag |= BBSNEWS;
		if(old.vote == 1)
			new.flag |= VOTEING;
		new.level = old.level;
		new.group = 0;
		write(fout, (char *)&new, outsize);
		printf("write: %d\n", ++count);
		printf("filename: %s\n", new.filename);
		printf("managers: [%s] [%s] [%s]\n",
			new.manager1, new.manager2, new.manager3);
		printf("sender: {%s}\n", new.sender);
		printf("group: %d\n", new.flag);
		printf("title: %s\n", new.title);
		printf("flag: %d\n", new.flag);
		printf("accessed:.............\n");
		printf("====================================================\n");
	}
	close(fin);
	close(fout);
}
