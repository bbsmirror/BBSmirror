/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdio.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include "define.h"
#include "struct.h"
extern unsigned long GetStrCrc(char *str);

char *strtolow(buf1)
char *buf1;
{
	int i;
	static char buf2[STRLEN];

	bzero(buf2, STRLEN);
        for(i = 0; i<strlen(buf1); i++)
                buf2[i] = (isalpha(buf1[i])?buf1[i]|0x20:buf1[i]);
	strcpy(buf1, buf2);
	return buf2;
}

void	main()
{
	userec user;
	FILE	*passfile,
		*crcfile;
	long	crc;
	ucrc	l;
	char	name[256],
		sname[256],
		*uname;
	int	found = 0,
		count = 0,
		num;

	printf("Username: ");
	scanf("%s",sname);
	strcpy(name, strtolow(sname));

	crc = GetStrCrc(name);

	passfile = fopen(".PASSWDS", "rb");

	if (passfile == NULL)
		passfile = fopen("PASSWDS", "rb");

	if (passfile == NULL)
		exit(-1);

	crcfile = fopen(".CRCIDX", "rb");

	if (crcfile == NULL)
		crcfile = fopen("CRCIDX","rb");

	if (crcfile == NULL)
		exit(-1);

	printf("First, we test CRC-32 ID matching......\n");

	while (!feof(crcfile))
	{
		fread(&l, sizeof(ucrc), 1, crcfile);
		if (l.crcnum == crc)
		{
			num = ftell(crcfile)/sizeof(ucrc)-1;
			fseek(passfile, num*sizeof(userec), SEEK_SET);
			fread(&user, sizeof(userec), 1, passfile);
			printf("Found!\n");
			printf("Username: %s\n",user.userid);
			break;
		}    
	}    

	fclose(crcfile);
	printf("\nIf you match user id by string comparison:\n");
	fseek(passfile, 0, SEEK_SET);

	while (!feof(passfile))
	{
		fread(&user, sizeof(user), 1, passfile);

		if (strcmp(user.userid, name)==0)
		{
			printf("Found!\n");
			printf("Username: %s\n",user.userid);
			break;
		}
	}

	fclose(passfile);
}
