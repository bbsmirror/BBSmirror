/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/*
 * Wrapping out account with '\0' in the first filed
 * and 'new' accounts..
 * This will cause passwd file lesser, but users serious number will
 * be changed also.
 *
 * Compile: gcc -o mkpassfl mkpassfl.c
 *
 * Usage: 1. cp .PASSWDS backup
 *        2. mkpassfl backup newfile
 *        3. mv newfile .PASSWDS
 */

#include <stdio.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <limits.h>
#include "define.h"
#include "struct.h"

struct oldrc {                  /* Structure used to hold information in */
        char userid[IDLEN+2] ;   /* PASSFILE */
        char filler[34];
        char lasthost[16];
        unsigned int numlogins;
        unsigned int numposts;
        char flags[2];
        char passwd[PASSLEN] ;
        char username[STRLEN] ;
        char termtype[STRLEN] ;
        unsigned userlevel ;
        time_t lastlogin ;
        int protocol ;
        char realname[STRLEN-40];
        char address[STRLEN];
        char email[STRLEN];
} ;

main(argc, argv)
int argc;
char *argv[];
{
	int count, size, nsize;
	int fin, fout;
	struct userec user;
	struct oldrc user2;
	char source[80], target[80];

	size = sizeof(struct oldrc);
	nsize = sizeof(struct userec);
	strcpy(source, argv[1]);
	strcpy(target, argv[2]);

	printf("Size of userec = %d\n", size);
	printf("source file: %s\n", source);
	printf("target file: %s\n", target);
	if((fin = open(source, O_RDONLY)) == -1) {
		printf("open source file error\n");
		exit(0);
	}
	if((fout = open(target, O_WRONLY|O_CREAT|O_TRUNC, 0644)) == -1) {
		printf("open target file error\n");
		exit(0);
	}
	while(read(fin, &user2, size) == size)
	{
		count = tell(fin)/size;
		if(user2.userid[0] != '\0' && strcmp(user2.userid, "new")) {
			bzero(&user, nsize);
			strcpy(user.userid, user2.userid);
        		strcpy(user.lasthost, user2.lasthost);
        		user.numlogins = user2.numlogins;
        		user.numposts = user2.numposts;
 		        strcpy(user.flags, user2.flags);
        		strcpy(user.passwd, user2.passwd);
        		strcpy(user.username, user2.username);
        		strcpy(user.termtype, user2.termtype);
        		user.userlevel = user2.userlevel;
        		bcopy(&user.lastlogin, &user2.lastlogin, sizeof(time_t));
        		user.protocol = user2.protocol;
        		strcpy(user.realname, user2.realname);
        		strcpy(user.address, user2.address);
        		strcpy(user.email, user2.email);
			user.signum = 0;
			user.userset = SET_DEFAULT;
			strcpy(user.defboard, DEFAULTBOARD);
			write(fout, &user, nsize);
			printf("[7m[�g�J][m %4d: %s\n", count, user2.userid);
		} else
			printf("[Warnnd] %4d: is ignored\n", count);
	}
	close(fin);
	close(fout);
}
