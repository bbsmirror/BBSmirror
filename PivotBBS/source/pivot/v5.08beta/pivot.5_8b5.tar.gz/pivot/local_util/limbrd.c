#include <stdio.h>
#include <sys/file.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include "define.h"
#include "struct.h"

main(argc, argv)
int	argc;
char	**argv;
{
	char	output[STRLEN],
		boardfl[STRLEN];
	int	fd,
		num = 0,
		maxbrd,
		size;
	time_t	now;
	FILE	*fp;
	bhd	info;

	if (argc != 3)
	{
		printf("Usage: %s .BOARDS max_board_num\n", argv[0]);
		exit(-1);
	}

	sprintf(boardfl, argv[1]);
	maxbrd = atoi(argv[2]);

        if ((fd = open(boardfl, O_RDWR, 0)) == -1)
                return -1;

	size = sizeof(bhd);

	for (num = 0; num < maxbrd-1; num++)
        {
		bzero(&info, sizeof(bhd));
		if (lseek(fd, num*size, L_SET) == -1)
			break;
		if (read(fd, (char *)&info, size) == -1)
			break;
		if (info.filename == '\0')
			break;
		info.postlevel &= ~PERM_BASIC;
		info.postlevel &= ~PERM_CHAT;
		info.postlevel &= ~PERM_PAGE;
		info.postlevel &= ~PERM_POST;
		lseek(fd, num*size, L_SET);
		write(fd, (char *)&info, size);
        }
        close(fd);
}
