#include <stdio.h>
#include <sys/file.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include "define.h"
#include "struct.h"

main(argc, argv)
int	argc;
char	**argv;
{
	char	output[STRLEN],
		passfl[STRLEN];
	int	fd,
		num = 0,
		size;
	userec	buf;
	time_t	now;
	FILE	*fp;
	ucrc	crcidx;

	if (argc != 3)
	{
		printf("Usage: %s passfile output\n", argv[0]);
		exit(-1);
	}

	sprintf(output, argv[2]);
	sprintf(passfl, argv[1]);

        if ((fd = open(passfl, O_RDWR, 0)) == -1)
                return -1;

	size = sizeof(userec);

	for (num = 0; num < MAXUSERS; num++)
        {
		lseek(fd, num*size, L_SET);
		read(fd, (char *)&buf, size);

		if (buf.userid[0] == '\0' || !strcmp(buf.userid, "new"))
			continue;

		get_record(CRCIDX, (char *)&crcidx, sizeof(ucrc), num+1);
		time(&now);

		if (buf.reg_date == 0)
			buf.reg_date = buf.mod_email = now;

		crcidx.checksum = buf.checksum = crcidx.crcnum + now;

		if (!(buf.userlevel & PERM_TRUE))
		{
			logit(output, "register: %s %s %d", buf.userid,
				buf.email, buf.checksum);
		}

		lseek(fd, num*size, L_SET);
		write(fd, (char *)&buf, size);
		substitute_record(CRCIDX, (char *)&crcidx, sizeof(ucrc), num+1);
        }
        close(fd);
}
