/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/*
 * Filename: sort_board.c
 * Wrter   : kftseng@bbs.nchu.edu.tw
 * Date    : 1994.4.13
 * Version : pivot bbs 3.0
 *
 * Goal    : BBS �Q�װϱƧ�
 * Compile : gcc -o sort_board sort_board.c
 * Notice  : �����ϥ� BBS �ثe�� bbs.h �� compile
 * Usage   : % cd ~bbs
             % cp .BOARDS .BOARDS.bak
             % sort_board .BOARDS .BOARDS.new
             % cp .BOARDS.new .BOARDS 
*/

#include <stdio.h>
#include <time.h>
#include <fcntl.h>
#include "define.h"
#include "struct.h"

bhd all_group[256];

print(bhd *p)
{
    printf("Groupname: %s\n",  p->filename);
    printf("Descripton: %s\n", p->title);
}

int board_cmp(a, b)
bhd *a, *b;
{
    return (strcasecmp(a->filename, b->filename));
}

void	main(argc, argv)
int	argc;
char	**argv;
{
	FILE	*inf,
		*outf;
	int	i,
		no,
		count,
		size;
	char buf[256];
    
	if (argc != 3)
	{
		printf("Usage: %s old_board_file new_board_file\n", argv[0]);
		exit(1);
	}
 
	size= sizeof(bhd);

	if (!strcmp(argv[1], argv[2]))
	{
		printf("Error: filename should be different\n");
		exit(1);
	}

	inf = fopen(argv[1], "rb");
	outf = fopen(argv[2], "wb");
	if (inf == NULL || outf == NULL)
	{
		printf("error open %s or %s\n", argv[1], argv[2]); 
		exit(1);
	}

	for (i = 0; ;i++)
	{
		if (fread(&all_group[i], size, 1, inf) <= 0)
			break;
	}

    /* sort them by name */
	count = i;
	qsort(all_group, count, size, board_cmp);

   /* write out the target file */
	for (i=0; i < count; i++)
	{
		if (all_group[i].filename[0])
		{
		        fwrite(&all_group[i], size, 1, outf);
			printf("%-20s %s\n", all_group[i].filename, all_group[i].title);
		}
	}
	fclose(inf);
	fclose(outf);
	exit(0);
}
