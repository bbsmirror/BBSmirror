/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)mail.c  5.04 3/19/95 (C) 1993 University of \
NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include <string.h>
#include <time.h>
#include <sys/file.h>
#include "bbs.h"

char	currmaildir[STRLEN];

#ifdef INTERNET_EMAIL
char	forwardto[STRLEN];
#endif
int	mrd,
	delmsgs[1024],
	delcnt;

mhd	mailfh;

void	m_init(lookupu)
userec	lookupu;
{
	sprintf(currmaildir, PATH_MAIL, lookupu.userid, FHDIR);
}

int	chkmails(lookupu, flag)
userec	lookupu;
int	flag;
{
	m_init(lookupu);
	return chkmail(flag);
}

int	chkmail(flag)
int	flag;
{
	static	long	lasttime = 0;
	static	ismail = 0;
	struct	stat	st;
	int	fd;
	register	int	i,
				offset;
	register	long	numfiles;
	unsigned	char	ch;

	if (flag)
	{
		lasttime = 0;
		ismail = 0;
	}	

	offset = ((int)&(mailfh.accessed)-(int)&(mailfh));
	if ((fd = open(currmaildir,O_RDONLY)) < 0)
		return (ismail = 0);
	fstat(fd,&st);

	if (lasttime >= st.st_mtime)
	{
        	close(fd);
        	return ismail;
 	}

 	lasttime = st.st_mtime;
 	numfiles = st.st_size;
 	numfiles = numfiles/sizeof(mailfh);

 	if (numfiles <= 0)
	{
		close(fd);
		return (ismail = 0);
	}

	lseek(fd,offset,L_SET);

	for(i = 0; i < numfiles; i++, lseek(fd, offset + i * sizeof(mailfh),
		L_SET))
	{
        	read(fd,&ch,1);

        	if (!(ch & FILE_READ))
		{
        		close(fd);

        		return(ismail = 1);
        	}
    	}
    	close(fd);

    	return(ismail = 0);
}

int	m_exit(void)
{
	struct	stat	mst;
	int	keep;

	m_init(cuser);

	if (stat(currmaildir, &mst) == -1)
		return QUIT;

	if ((keep = mst.st_size / sizeof(mhd)) > MAXKEEPMAIL)
	{
		move(2, 0);
		prints(NA, "�O�s�H��ƥ� %d �W�X�W�� %d, �вM���W�X����\n",
			keep, MAXKEEPMAIL);			
		return 0;
	}
	else
		return QUIT;
}

int	reply_inter(mailhd, direct)
mhd	*mailhd;
char	*direct;
{
	mhd	minfo;
	char	buff[STRLEN],
		tmpfile[STRLEN],
		source[STRLEN];
	int	ans;

	if (!(cuser.userlevel & PERM_INTER))
		return -3;
	if (!check_host(mailhd->sender))
		return -1;

	bzero(&minfo, sizeof(minfo));
	clear();
	sprintf(tmpfile, PATH_TMPFILE, cuser.userid);
       	if (get_title(mailhd->title, minfo.title) == QUITPOST)
       		return -2;
       	sprintf(buff,"�ޥέ�l��� (Y)es, (N)o, (A)ll? [Y]: ");
	ans = getans(3, 0, buff, 'y');
	if (ans == 'y' || ans == 'a') 
	{
		sprintf(source, "%s/%s", direct, mailhd->filename);
		include_old(tmpfile, source, ans);
    	}
	return send_internet(tmpfile, mailhd->sender, minfo.title);
}

int	do_send(mailhd, direct)
mhd	*mailhd;
char	*direct;
{
	char	fname[STRLEN],
		*ip,
		buff[STRLEN],
		fromfile[STRLEN],
		genbuf[STRLEN];
	struct	stat	st;
	int	fp,
		ans,
		savemode;
        time_t	dtime;      
        struct	tm	*ptime;	
        mhd	newmsg;

	strtok(mailhd->sender, " ");
	if (!getuser(mailhd->sender))
		return -1;

	if (!(muser.userlevel & PERM_READMAIL))
		return -3;

	sprintf(genbuf, PATH_M, mailhd->sender);

	if (stat(genbuf, &st) == -1)
	{
		if (mkdir(genbuf, 0700) == -1) 
			return -1;
	}
	else
	{	
		if (!(st.st_mode & S_IFDIR))
			return -1;
	}

	bzero(&newmsg,sizeof(newmsg));

	sprintf(fname, "%s/%s/mail/", MYHOME, mailhd->sender);
	buildfile(fname);
	strcpy(newmsg.filename,fname);	
	sprintf(genbuf, "%s/%s/mail/%s", MYHOME, mailhd->sender, fname);

	if (!mailhd->title[0])
	{
		if (get_title(NULL, newmsg.title) == QUITPOST)
			return -2;
	}
	else
	{
		clear();
        	if (get_title(mailhd->title, newmsg.title) == QUITPOST)
        		return -2;
        	sprintf(buff,"�ޥέ�l��� (Y)es, (N)o, (A)ll? [Y]: ");
		ans = getans(3, 0, buff, 'y');
		if (ans == 'y' || ans == 'a') 
		{
			sprintf(fromfile, "%s/%s", direct, mailhd->filename);
			include_old(genbuf, fromfile, ans);
	    	}
        }
        
	strncpy(save_title, newmsg.title, STRLEN);
	strncpy(save_filename, fname, 4096);
	strcpy(newmsg.sender, cuser.userid);
	in_mail = YEA;
#ifdef REALINFO
	if (HAS_SET(SET_REALMAIL))
		sprintf(genbuf, "%s (%s)", cuser.userid,
			cuser.realname);
	else
		sprintf(genbuf, "%s (%s)", cuser.userid,
			cuser.username);
#else
	sprintf(genbuf, "%s (%s)", cuser.userid, cuser.username);
#endif
	sprintf(genbuf, PATH_MAIL, mailhd->sender, fname);

	savemode = uinfo.mode;
	changemode(SMAIL, NA);

	if (vedit(genbuf,YEA) == -1)
	{
		if (stat(genbuf, &st) != -1)
	        	unlink(genbuf);
		clear();
	     	return -2;
	}

	changemode(savemode, NA);
	
	clear();
	sprintf(genbuf, PATH_MAIL, mailhd->sender, FHDIR);
#ifdef POSTBUG
	if (append_mail(genbuf, (char *)&newmsg, sizeof(newmsg)) == -1)
#else
        if (append_record(genbuf, (char *)&newmsg, sizeof(newmsg)) == -1)
#endif
		return -1;
	return 0;
}

int	send_internet(fname, email, title)
char	*fname,
	*email,
	*title;
{
	char	errmail[STRLEN],
		inbuff[STRLEN];
	mhd	minfo;
	FILE	*ferr,
		*source;
	time_t	now;
	int	result;

	bzero(&errmail, sizeof(errmail));
	if (vedit(fname, NA) < 0)
		return -1;
	if ((result = deliver_email(fname, email, title)) < 0)
	{
		if ((source = fopen(fname, "r")) == NULL)
			return FULLUPDATE;
		sprintf(errmail, PATH_M, cuser.userid);
		buildfile(errmail);
		strcpy(minfo.filename, errmail);
		sprintf(errmail, PATH_MAIL, cuser.userid, minfo.filename);
		strncpy(minfo.sender, cuser.userid, STRLEN);
		switch (result)
		{
			case -3:
				sprintf(minfo.title, "�ɮ� [%s] ��", fname);
				break;
			default:
				sprintf(minfo.title, "����B���~ [%s]", email);
				break;
		}
		strcpy(save_title, minfo.title);
		if ((ferr = fopen(errmail, "w")) == NULL)
		{
			fclose(source);
			unlink(fname);
			return FULLUPDATE;
		}
		write_header(ferr);
		time(&now);
		fprintf(ferr, "��H�b %s �e�� %s\n", Ctime(&now), email);
		fprintf(ferr, "�H��D�D�O: %s\n", title);
		fprintf(ferr, "\n------ ��H�󤺮e�p�U�ҥ� ------\n\n");
	        while (fgets(inbuff, sizeof(inbuff), source) != NULL) 
			fprintf(ferr, "%s", inbuff);
		fclose(ferr);
		fclose(source);
		unlink(fname);
		sprintf(genbuf, PATH_MAIL, minfo.sender, FHDIR);
		if (append_record(genbuf, (char *)&minfo, sizeof(mhd)) == -1)
			unlink(errmail);
	}
	return FULLUPDATE;
}

int	m_inter(void)
{
	char	tmpfile[STRLEN],
		sendto[STRLEN],
		title[STRLEN],
		ext;
	int	fp,
		ans;

	sprintf(tmpfile, PATH_TMPFILE, cuser.userid);
	getdata(0, 0, ASK_RECEIVER, sendto, STRLEN, DOECHO, YEA);
	if (sendto[0] == '\0' || !check_host(sendto))
		return -1;
	if (get_title(NULL, title) == QUITPOST)
		return -2;
	return send_internet(tmpfile, sendto, title);
}

int	m_send(void)
{
	char	uident[STRLEN],
		genbuf[STRLEN];
	mhd	mailinfo;

	if (!init_namelist(uident))
		return 0;

	strcpy(mailinfo.sender, uident);
	sprintf(genbuf, PATH_M, cuser.userid);
	switch (do_send(&mailinfo, genbuf))
	{
		case -1:
			prints(NA, "Bad UserId\n");
			break;
	  	case -2:
			prints(NA, "Mail Aborted\n"); 
			break;
	  	case -3: 
			prints(NA, "User '%s' cannot receive mail\n", uident); 
			break;
	  	default: 
			prints(NA, "File Sent\n");
			break;
	}
	pressreturn();

	return 0;
}

int	read_mail(fptr)
mhd	*fptr;
{
	sprintf(genbuf, PATH_MAIL, cuser.userid, fptr->filename);
	more(genbuf,NA);
	fptr->accessed |= FILE_READ;
	return 0;
}

int	read_new_mail(fptr)
mhd	*fptr;
{
	static	int	idc;
	char	done = NA,
		delete_it,
		genbuf[4],
		currmaildir[100];
	int	ans;
	
	sprintf(currmaildir, PATH_MAIL, cuser.userid, FHDIR);

	if (fptr == NULL)
	{
		delcnt = 0;
		idc = 0;
		return 0;
	}

	idc++;
	if (fptr->accessed)
		return 0;

	read_mail(fptr);
	mrd = 1;

	if (substitute_record(currmaildir, (char *)fptr, sizeof(*fptr), idc))
		return -1;
	delete_it = NA;

	move(t_lines-1, 0);
	clrtoeol();
       	prints(NA, "[m[1;34;46m\[�\\Ū�H��][45m %s %s %s",
		"[32m[R][33m�^�H [32m[D][33m�R��",
		"[32m[F][33m�൹���� [32m[E][33m��쯸�~",
		"[32m[G|Enter][33m�U�@�� [32m[Q|��][33m����  [m");
	switch(ans = igetkey())
	{
		case 'q':
		case 'Q':
		case KEY_LEFT:
			clear();
			return QUIT;
    		case 'd':
		case 'D': 
      			delete_it = YEA;
      			break;
    		case 'r':
		case 'R':
			mail_reply_auth(fptr);
			break;
    		case 'E':
		case 'e':
			mail_reply_forward(fptr, YEA);
			break;
		case 'f':
		case 'F':
			mail_reply_forward(fptr, NA);
			break;
  		default:
      			break;
	}
    	if (delete_it)
	{
        	clear();
        	prints(NA, "Delete Message '%s' ", fptr->title);
        	Getyn(genbuf);
        	if (genbuf[0] == 'Y' || genbuf[0] == 'y')
		{
	  		sprintf(genbuf, PATH_MAIL, cuser.userid,
				fptr->filename);
	  		unlink(genbuf);
	  		delmsgs[delcnt++] = idc;
		}
    	}
    	clear();
    	return 0;
}

int	m_new(void)
{
	clear();
	mrd = 0;

	changemode(RMAIL, NA);

	read_new_mail(NULL);
	m_init(cuser);
	if (apply_record(currmaildir, read_new_mail, sizeof(mhd)) == -1)
	{
		clear();
		move(0,0);
		prints(NA, "No new messages\n\n\n");

		changemode(MAIL, NA);

		return -1;
	}

	if (delcnt >= 0)
	{
		while (delcnt--)
			delete_record(currmaildir, sizeof(mhd),
				delmsgs[delcnt]);
	}
	clear();
	move(0,0);
	if (mrd)
		prints(NA, "No more messages.\n\n\n");
	else
		prints(NA, "No new messages.\n\n\n");

	changemode(MAIL, NA);

	return -1;
}

void	mailtitle(void)
{
	clrtobot();
	menu_draw("[�H��B�z]", boardmargin);
        prints(NA, "%-18s%-11s%-29s%-20s\n", "[��,e]�^�W�@�e��",
                "[h]�D�U", "[��,r,<cr>]Ū����ЩҦb�峹",   
                "[��,��]�W,�U�@�g�峹");

        prints(YEA, "[1;32;44m �s��   %-15s %-6s  %-47s[m\n","�H��H","���","����");
}

void	maildoent(num, ent)
int	num;
mhd	*ent;
{
	static	char	buf[512];
	char	b2[512],
		status,
		*t,
		*date;
	time_t	filetime;

	filetime = atoi(ent->filename + 2);

	if (filetime > 740000000)
		date = Ctime(&filetime) + 4;
	else
		date = Ctime(&filetime) + 20;

	strncpy(b2,ent->sender,STRLEN);

	if (t = (char *)index(b2,' '))
		*t = '\0';

	if (ent->accessed & FILE_READ)
	{
		if (ent->accessed & FILE_MARKED)
			status = 'm';
		else
			status = ' ';
	}
	else
	{
		if (ent->accessed & FILE_MARKED)
			status = 'M';
		else
			status = 'N';
	}

	if (strstr(ent->title, "Re: ") == ent->title)
		prints(NA," %4d %c %-15.15s %6.6s  %-47.47s\n", num, status,
			b2, date, ent->title);
	else
		prints(NA," %4d %c %-15.15s %6.6s  �� %.40s ��\n", num,
			status, b2, date, ent->title);
}

int	mail_reply_auth(oldfile)
mhd	*oldfile;
{
	char	genbuf[STRLEN];

	if (uinfo.mode == MSYSOP)
		sprintf(genbuf, PATH_M, ADMIN);
	else
		sprintf(genbuf, PATH_M, cuser.userid);
	if (!oldfile->title[0])
		strcpy(oldfile->title, "Re: ");
	return mail_reply(0, oldfile, genbuf);
}

int	mail_reply_forward(oldfile, email)
mhd	*oldfile;
int	email;
{
	char	namebuf[STRLEN],
		bufdir[STRLEN];
	mhd	mailbuf;

	if (email && HAS_PERM(PERM_TRUE))
	{
		getdata(0, 0, ASK_RECEIVER, namebuf, STRLEN, DOECHO, YEA);
		if (namebuf[0] == '\0')
			return -1;
	}
	else
	{
		if (!init_namelist(namebuf))
			return -1;
	}
	if (uinfo.mode == MSYSOP)
		sprintf(genbuf, PATH_M, ADMIN);
	else
		sprintf(bufdir, PATH_M, cuser.userid);
	strcpy(mailbuf.sender, namebuf);
	if (!oldfile->title[0])
		strcpy(oldfile->title, "Re: ");
	strcpy(mailbuf.title, oldfile->title);
	strcpy(mailbuf.filename, oldfile->filename);
	return mail_reply(0, &mailbuf, bufdir);
}

int	mail_read(ent,fileinfo,direct)
int	ent;
mhd	*fileinfo;
char	*direct;
{
	char	buf[512],
		notgenbuf[128],
		currmaildir[100],
		*t,
		done = NA,
		delete_it,
		replied;
	int	ans;
	
	clear();
	strcpy(buf,direct);
	if (t = (char *)rindex(buf,'/'))
		*t = '\0';
	sprintf(currmaildir, "%s/%s", buf, FHDIR);
	sprintf(notgenbuf, "%s/%s", buf, fileinfo->filename);
	delete_it = replied = NA;

	while (!done)
	{
		more(notgenbuf, NA);
		move(t_lines-1, 0);
		clrtoeol();
	       	prints(NA, "[m[1;34;46m\[�\\Ū�H��][45m %s %s %s",
			"[32m[R][33m�^�H [32m[D][33m�R��",
			"[32m[F][33m�൹���� [32m[E][33m��쯸�~",
			"[32m[G|Enter][33m�U�@�� [32m[Q|��][33m����  [m");
		
		switch (ans = igetkey())
		{
			case 'd':
			case 'D':
				delete_it = YEA;
				done = YEA;
				break;
			case 'r':
			case 'R':
				replied = mail_reply_auth(fileinfo);
				done = NA;
				break;
                	case 'f':
			case 'F':
				replied = mail_reply_forward(fileinfo, NA);
				done = NA;
				break;
			case 'E':
			case 'e':
				replied = mail_reply_forward(fileinfo, YEA);
				done = NA;
				break;
			case 'G':
			case '\n':
			case KEY_RIGHT:
			case KEY_DOWN:
				ans = 'g';
				done = YEA;
				break;
	        	default:						
	        		done = YEA;
	        		break;
		}
	} 

	if (delete_it)
		mail_del(ent, fileinfo, direct);
	else
	{
		fileinfo->accessed |= FILE_READ;
#ifdef POSTBUG
		if (replied)
			bug_possible = YEA;
#endif
		substitute_record(currmaildir, (char *)fileinfo,
			sizeof(*fileinfo), ent);
#ifdef POSTBUG
		bug_possible = NA;
#endif
	}

	return (ans == 'g') ? READ_NEXT : FULLUPDATE;
}

int	mail_reply(ent, mailinfo, direct)
int	ent;
mhd	*mailinfo;
char	*direct;
{
	if (strchr(mailinfo->sender, '@') && HAS_PERM(PERM_INTER))
		reply_inter(mailinfo, direct);
	else
	{
		switch (do_send(mailinfo, direct))
		{ 
			case -1:
				prints(NA, "Could not send\n");
				break;
		  	case -2:  
				prints(NA, "Reply Aborted\n"); 
				break;
		  	case -3:  
				prints(NA, "User '%s' cannot receive mail\n",
					mailinfo->sender); 
				break;
		  	default: 
				prints(NA, "File Sent\n");
		}
	}
	pressreturn();

	return FULLUPDATE;
}

int	mail_del(ent,fileinfo,direct)
int	ent;
mhd	*fileinfo;
char	*direct;
{
	char	buf[512],
		currmaildir[100],
		*t;

	clear();
	sprintf(currmaildir, "%s/%s", buf, FHDIR);
	prints(NA, "Delete Message '%s' ",fileinfo->title);
	Getyn(genbuf);

	if (genbuf[0] != 'Y' && genbuf[0] != 'y')
	{
		move(2,0);
		prints(NA, "Quitting Delete Mail\n");
		pressreturn();
		clear();
		return FULLUPDATE;
	}

	strcpy(buf,direct);
	if (t = (char *)rindex(buf,'/'))
		*t = '\0';

	strncpy(currfile,fileinfo->filename,STRLEN);

	if (!delete_file(direct,sizeof(*fileinfo),ent,cmpfilename))
	{
		sprintf(genbuf, PATH_MAIL, (uinfo.mode == MSYSOP) ? "SYSOP" :
			cuser.userid, fileinfo->filename);
		unlink(genbuf);
		return FULLUPDATE;
	}

	move(2,0);
	prints(NA, "Delete failed\n");
	pressreturn();
	clear();

	return FULLUPDATE;
}

int	mail_del_range(ent, fileinfo, direct)
int	ent;
mhd	*fileinfo;
char	*direct;
{
	return del_range(ent, (fhd *)fileinfo, direct);
}

int	mail_mark(ent,fileinfo,direct)
int	ent;
mhd	*fileinfo;
char	*direct;
{
	char	currmaildir[100],
		buf[80],
		*t;

	strcpy(buf,direct);
	if (t = (char *)rindex(buf,'/'))
		*t = '\0';
	sprintf(currmaildir, "%s/%s", buf, FHDIR);

	if (fileinfo->accessed & FILE_MARKED)
		fileinfo->accessed &= ~FILE_MARKED;
	else
		fileinfo->accessed |= FILE_MARKED;

	substitute_record(currmaildir, (char *)fileinfo, sizeof(*fileinfo),ent);

	return(PARTUPDATE);	
}

one_key  mail_comms[] =
{
	CTRL('J'),	mailreadhelp,
	'D',		mail_del_range,
#ifdef INTERNET_EMAIL
	'F',		mail_forward,
#endif
	'R',		mail_reply,
	'a',		cook_announce,
	'd',		mail_del,
	'h',		mailreadhelp,
	'm',		mail_mark,
	'r',		mail_read,
	'\n',		mail_read,
	'\r',		mail_read,
	' ',		mail_read,
	KEY_RIGHT,	mail_read,
	'\0',		NULL
};

int	m_admin(void)
{
	char	mailpath[100];

	changemode(MSYSOP, NA);

	in_mail = YEA;
	sprintf(mailpath, PATH_MAIL, ADMIN, FHDIR);
	i_read(mailpath, mailtitle, maildoent, &mail_comms[0], 's',
		ASK_MAIL_DEFAULT, 'n', get_num_records, get_records);

	in_mail = NA;
	changemode(MAIL, NA);
	return 0;
}

int	m_read(void)
{
	changemode(RMAIL, NA);

	in_mail = YEA;
	i_read(currmaildir, mailtitle, maildoent, &mail_comms[0], 's',
		ASK_MAIL_DEFAULT, 'n', get_num_records, get_records);

	in_mail = NA;

	changemode(MAIL, NA);

	return 0;
}

#ifdef INTERNET_EMAIL
int	mail_forward(ent,fileinfo,direct)
int	ent;
mhd	*fileinfo;
char	*direct;
{
	char	buf[STRLEN],
		currmaildir[100],
		*p;
	int	save_pager,
		save_mode;

	if (!HAS_PERM(PERM_FORWARD))
	{
		bell(1);
		return DONOTHING;
	}
	save_mode = uinfo.mode;
	save_pager = uinfo.pager;
	substitute_record(ULIST, (char *)&uinfo, sizeof(uinfo), utmpent);

	sprintf(currmaildir, "%s/%s", buf, FHDIR);

	strncpy(buf, direct, sizeof(buf));

	if ((p = (char *)rindex(buf, '/')) != NULL)
		*p = '\0';
	clear();

	switch (doforward(buf, fileinfo, forwardto))
	{
		case 0:
			prints(NA, "\nForward Article to: %s\n", forwardto);
			break;
		case -1:
			prints(NA, "\nForward failed: Host cannot find\n");
			prints(NA, "Set E-mail address by: (X)yz - (I)nfo\n");
			break;
		case -2:
			prints(NA, "\nForward failed: Service unavailable\n");
			break;
		case -3:
			prints(NA, "\nForward aborted.\n");
	  		break;
		default:
	  		break;
	}
	pressreturn();
	clear();
        uinfo.pager = save_pager;
	changemode(save_mode, NA);

	return FULLUPDATE;
}

int	d_read(fd, ptr, maxlen)
int	fd,
	maxlen;
char	*ptr;
{
	int	n,
		rc;
	char	c;

	for (n = 1; n < maxlen; n++)
	{
		if ((rc = read(fd, &c, 1)) == 1)
		{
			*ptr++ = c;
			if (c == '\n')
				break;
		}
		else if (rc = 0)
		{
			if (n == 1)
				return 0;
			else
				break;
		}
		else
			return -1;
	}
	*ptr = '\0';
	return n;
}

/*
 * �ˬd email-address �O�_���T
 * return:  0. �����~�o��; 1. ���`, �i�e�H; 2. �O IP ADDRESS
 */
int	check_host(email)
char	*email;
{
	char	tmp[STRLEN];
	int	i,
		ip = TRUE;
	struct	hostent	*host;

	if (strstr(email, "modem.bbs.user"))
		return 0;

	if (strchr(email, '@'))
		strcpy(tmp, (char *)strchr(email, '@')+1);

	for (i = 0; i < strlen(tmp); i++)
	{
		if (isalpha(tmp[i]))
		{
			ip = FALSE;
			break;
		}
	}

	if (tmp[0] == '[' && tmp[strlen(tmp)-1] == ']')
		return (ip == TRUE) ? 2 : 0;

	return (gethostbyname(tmp) ? 1 : 0);
}

void	wait_sending(mfd)
int	mfd;
{
	char	buf[255];
	int	n = 0;

	while (1)
	{
		read(mfd, buf, sizeof(buf));
#ifdef	AIX_SENDMAIL
		if (strstr(buf, "250") == buf && strstr(buf, "Ok"))
#else
		if (strstr(buf, "250") == buf && strstr(buf, "accepted"))
#endif
			return;
	}
}

int	deliver_email(filename, forwardto, title)
char	*filename,
	*forwardto,
	*title;
{
	char	buf[255],
		HOST[STRLEN],
		c;
	struct	sockaddr_in	sin;
	struct	hostent	*host;
	int	mfd,
		fd,
		leng,
		ip;

	if ((ip = check_host(forwardto) - 1) < 0)
		return -2; /* e-mail address error */
	
	if ((fd = open(filename, O_RDONLY)) == -1)
		return -3; /* file not exist */

#ifdef	MAILSERVER
	strcpy(HOST, MAILSERVER);
#else
	strcpy(HOST, MYHOSTNAME);
#endif
	clear();
	prints(NA, "\n\n�� mail-server: %s �e�H��.....\n", HOST);
	refresh();
	bzero((char *)&sin, sizeof(sin));

	sin.sin_family = AF_INET;
	sin.sin_port = htons(25);

	if (ip)
	{
		sin.sin_addr.s_addr = inet_addr(HOST);
	}
	else
	{
		host = gethostbyname(HOST);
		memcpy(&sin.sin_addr.s_addr, host->h_addr_list[0],
			host->h_length);
	}

	mfd = socket(AF_INET, SOCK_STREAM, 0);
	if (mfd < 0)
		return -2;	/* service unreachable */
	if (connect(mfd, (struct sockaddr *)&sin, sizeof(sin)) < 0)
		return -2;

        sprintf(buf, "HELO %s\n", HOST);
        write(mfd, buf, strlen(buf));

        sprintf(buf, "MAIL From:<%s.bbs@%s>\n", cuser.userid, MYHOSTNAME);
        write(mfd, buf, strlen(buf));

        sprintf(buf, "RCPT To:<%s>\n", forwardto);
        write(mfd, buf, strlen(buf));

        sprintf(buf, "DATA\n");
        write(mfd, buf, strlen(buf));

	sprintf(buf, "To: %s\n", forwardto);
        write(mfd, buf, strlen(buf));

	sprintf(buf, "Subject: %s\n", title);
	write(mfd, buf, strlen(buf));

	while (read(fd, &c, 1) > 0)
		write(mfd, &c, 1);

	close(fd);

	sprintf(buf, "\n.\n");
	write(mfd, buf, sizeof(buf));

	wait_sending(mfd);

	sprintf(buf, "QUIT\n");
	write(mfd, buf, sizeof(buf));


	prints(NA, "�H�󻼰e����.\n");

	refresh();
	close(mfd);
	unlink(filename);

	return 0;
}

int	doforward(direct, fh, forwardto)
char	*direct;
mhd	*fh;
char	*forwardto;
{
	char	fname[STRLEN],
		filename[STRLEN],
		buff[STRLEN],
		title[STRLEN];
	int	ch;
	time_t	now;

	sprintf(fname, PATH_FORWARD, cuser.userid);
	sprintf(filename, "%s/%s", direct, fh->filename);
	strcpy(forwardto, cuser.email);
	strcpy(title, fh->title);

	while (1)
	{
		clear();
		prints(NA, "\nForward article to: %s", forwardto);
		prints(NA, "\nIf this correct?(Y/N/Q) [Y] ");
		ch = igetkey();
		if (ch == 'q' || ch == 'Q')
			return -3;
		if (ch == 'N' || ch == 'n' || ch == KEY_LEFT)
		{
			getdata(4, 0, "Input E-mail: ",buff, STRLEN, DOECHO,
				YEA);
			if (buff[0])
				strcpy(forwardto, buff);
			else
				continue;
		}
		break;
	}
	prints(NA, "\nWould you want to uuencode it? (Yes/No/Abort) [N] ");
	ch = igetkey();
	if (ch == 'A' || ch == 'a')
		return -3;

	if (ch == 'Y' || ch == 'y' || ch == KEY_RIGHT)
	{
		time(&now);
		bzero(buff, sizeof(buff));
		sprintf(buff, "/usr/bin/uuencode %s bbs.%d > %s", filename,
			now, fname);
	  	system(buff);
	}
	else
	{
		if (copyto(filename, fname) != 0)
			return -1;
	}
	strcpy(filename, fname);
	
	return deliver_email(filename, forwardto, title);
}

#endif

int	_mail_foward(ent, fileinfo, direct, oldfile, ans)
int	ent;
char	*direct,
	ans;
mhd	*fileinfo;
fhd	*oldfile; 
{
	char	uid[STRLEN],
		title[STRLEN],
		uident[STRLEN],
		*t;
	struct	stat st;

	if (!init_namelist(uident))
		return 0;
			
	strncpy(uid,uident,STRLEN);

	if (t = (char *)index(uid,' '))
		*t = '\0';
	if (toupper(fileinfo->title[0]) != 'R' || fileinfo->title[1] != 'e' ||
		fileinfo->title[2] != ':') 
		strcpy(title,"Re: ");
	else
		title[0] = '\0';

	strncat(title,fileinfo->title,STRLEN-5);
	sprintf(genbuf, PATH_M, cuser.userid);
	switch (do_send(fileinfo, genbuf))
	{ 
		case -1:
			prints(NA, "Could not send\n");
			break;
	  	case -2:  
			prints(NA, "Reply Aborted\n"); 
			break;
	  	case -3:  
			prints(NA, "User '%s' cannot receive mail\n", uid); 
			break;
	  	default: 
			prints(NA, "File Sent\n");
	}
	pressreturn();

	return FULLUPDATE;
}
