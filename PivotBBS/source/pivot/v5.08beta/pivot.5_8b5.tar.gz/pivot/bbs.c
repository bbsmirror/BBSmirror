/*
    PIVOT Bulletin Board System [bbs.c]
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static	char	sccsid[] = "@(#)bbs.c   5.04 3/19/95 (C) 1993 University of \
NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include "bbs.h"
#include <sys/file.h>

static	int	quiting;
int	usercounter,
	totalusers,
	identuser,
	mot,
	usernum,
	scrint = 0,
	realusernum,
	tuid,
	tfile,
	rfile;
userec	cuser,
	olddata;

char	currboard[STRLEN],
	genbuf[4096];

int	exit_warning(void)
{
	bell(1);
	return 0;
}

int	Announce(void)
{
	faqview(NULL);

	return 0;
}
                                                                
int	Maintenance(void)
{
	changemode(MADMIN, NA);

	docmd("[���ץؿ�]", "��J���פu�@�ﶵ: ", 'h', maintlist, boardmargin);
	clear();

	changemode(MMENU, NA);

	return 0;
}

int	Xyz(void)
{
	changemode(XMENU, NA);

	docmd("[�ӤH�u��c]", "�ϥΤu��: ", 'h', xyzlist, boardmargin);
	clear();

	changemode(MMENU, NA);

	return 0;
}

int	Talk(void)
{
	changemode(TMENU, NA);
	docmd("[��ܥؿ�]", "��ѫ��O: ", 'h', talklist, boardmargin);
	changemode(MMENU, NA);
	clear();

	return 0;
}

#ifdef	LEVER
int	Lever(void)
{
	changemode(LMENU, NA);
	docmd("[�����A�ȥؿ�]", "���ε{�����O: ", 'h', leverlist, boardmargin);
	changemode(MMENU, NA);
	clear();

	return 0;
}
#endif

#ifdef	FILES
int	Files(void)
{
	changemode(FMENU, NA);
	docmd("[�ɮפu��]", "�ǰe�ɮשR�O: ", 's', filelist, filemargin);
	changemode(MMENU, NA);
	clear();

	return 0;
}
#endif

int	Mail(void)
{
	int	cmd;

	changemode(MAIL, NA);

	if (chkmails(cuser, NA))
		cmd = 'n';
	else
		cmd = 's';

	docmd("[�H��B�z]", "�H��B�z���O: ", cmd, maillist, boardmargin);

	changemode(MMENU, NA);

	clear();

	return 0;
}

char	uleveltochar(lvl)
usint	lvl;
{
	if (!(lvl & PERM_TRUE))
		return 'n';
	else if (lvl < PERM_DEFAULT)
		return '-';
	else if (lvl > PERM_IDENT && (lvl & PERM_TRUE))
		return '+';
	else
		return ' ';
}

int	printuent(uentp)
userec	*uentp;
{
	static	int	i;
	char	tmpstring[10],
		*field2;

#if defined(REALINFO) && defined(ACTS_REALNAMES)
	field2 = "�u��m�W";
#else
	field2 = "�ʦW�ٸ�";
#endif
	if (uentp == NULL)
	{
		move(3, 0);
		clrtoeol();
		prints(YEA,
			"[1;32;44m%-12s %-15s %-16s %-6s %-6s %-3s %-14s[m\n",
			"�ϥαb��", field2, "�̪�W���a�I", "#Login", "#Post", 
			HAS_PERM(PERM_SEEULEVELS) ? "Lvl" : " ",
			"�W���W���ɶ�");
		i = 3;
		return 0;
	}

	if (uentp->userid[0] == '\0' || !strcmp(uentp->userid, "new"))
		return 0;

	if (i == 22)
	{
		int	ch;

		prints(YEA, "[1;32;44m%-79s[m", "-- �٦���� [��'q'����] --");
		clrtoeol();
		while ((ch = igetkey()) != EOF)
		{
			if (ch == 'q' || ch == CTRL('C') || ch == CTRL('D') ||
				ch == KEY_LEFT)
			{
				move(23, 0);
				clrtoeol();
				return QUIT;
			}
			break;
		}
		move(3, 0);
		clrtoeol();
		prints(YEA, "[1;32;44m%-12s %-15s %-16s %-6s %-6s %-3s %-14s[m\n", 
			"�ϥαb��", "�ʦW�ٸ�", "�W���W���a�I", "#Login",
			"#Post", HAS_PERM(PERM_SEEULEVELS) ? "Lvl" : " ",
			"�W���W���ɶ�");
		i = 3;
		clrtobot();
	}
	sprintf(tmpstring, " %c ", uleveltochar(uentp->userlevel));
	prints(NA, "%-12.12s %-15.15s %-16.16s  %5d %5d  %-3.3s %-12.12s %c\n", uentp->userid, 
#if defined(REALINFO) && defined(ACTS_REALNAMES)
		uentp->realname, 
#else
		uentp->username, 
#endif
		uentp->lasthost, 
		uentp->numlogins, uentp->numposts, 
	        HAS_PERM(PERM_SEEULEVELS)?tmpstring:" ", 
	        Ctime(&uentp->lastlogin)+4, (HAS_PERM(PERM_UCLEAN) &&
		(uentp->userlevel & PERM_NOCLEAN) ? 'X':' '));
	i++;
	if (uentp->userlevel & PERM_TRUE)
		identuser++;
	usercounter++;
	return 0;
}

int	countusers(uentp)
userec	*uentp;
{
	if (uentp->userlevel & PERM_TRUE)
		identuser++;
	if (uentp->userid[0] != '\0' && strcmp(uentp->userid, "new"))
		totalusers++;
	if (realusernum++ > MAXUSERS)
		return QUIT;

	return 0;
}

int	Users(void)
{
	move(3, 0);
	clrtoeol();
	changemode(MUSERS, NA);
	usercounter = totalusers = realusernum = identuser = 0;
	printuent((userec *)NULL);
	if (apply_record(PASSFILE, printuent, sizeof(userec)) == -1)
	{
		prints(NA, "No Users Exist");
		pressreturn();

		changemode(MMENU, NA);

		return 0;
	}
	clrtobot();
	move(2, 0);
	apply_record(PASSFILE, countusers, sizeof(userec));
        prints(NA, "���: %d, �T�{: %d, ����: %d �ϥΪ̡e���U�H�ƤW���G%d�f", 
		usercounter, identuser, totalusers, MAXUSERS);
        pressreturn();

	changemode(MMENU, NA);

	return 0;
}

int	note_sysop(void)
{
        int	fd,
		j = 0,
		i;
        FILE	*fp;
        char	buf[128],
		*p,
		ans[2];
	admls	Sysop[MAXADMINS];

        if ((fp = fopen(ADMINLIST, "r")) == NULL)
	{
        	return 0;
        }   

        while (fgets(buf, 120, fp) != (char) NULL)
	{
        	if (buf[0] == '#' || buf[0] == '\n' || strlen(buf) < 10)
        		continue;
        	i = strlen(buf); buf[i-1] = '\0';
        	p = strtok(buf, " \t\n"); 
        	strcpy(Sysop[j].userid, p);
        	i = strlen(Sysop[j].userid)+1;
        	while (buf[i] == ' ' || buf[i] == '\t')
        		i++;
        	strcpy(Sysop[j].notes, buf+i);
        	j++;
        }

        prints(NA, "\n                   ----- ===== �����C�� ===== -----\n");
        prints(NA, " �s��   %-20s %-36s\n", "���� ID ", "�j�P�t�d����");     

        for (i = 0; i < j; i++)
	{
        	prints(NA, "   [1;%dm%2d.  %-20s %-50s[m\n" , 31+i%6, i+1, 
			Sysop[i].userid, Sysop[i].notes);
        }

        prints(NA, "   [1;%dm%2d.  ���}[37;40;0m\n", 31+j%6, j+1);
        getdata(t_lines-4, 5, "�z�n�H���֩O ? ", ans, 2, DOECHO, YEA);

        if (ans[0] - '0' > 0 && ans[0] - '0' <= j)
	{
		mhd	mailinfo;
		char	genbuf[STRLEN];

        	i = ans[0]-'0'-1;
        	clear();
		strcpy(mailinfo.sender, Sysop[i].userid);
        	do_send(&mailinfo, NULL);
        }
        return(0);
}

int	note_retry(void)
{
	int	i,
		fd,
		total,
		len,
		j = 1;
        struct	stat	st;
        FILE	*fp;
	char	ans[2],
		buf[256],
		buf2[256],
		*p;
        notedta olditem[MAXNOTE],
		note[MAXNOTE];

	bzero(&note, sizeof(note));
        move(6, 0);
	clrtobot();
        prints(NA, "\n�Яd��, �� Enter ���� (�ܦh�T��)\n");

        for (i = 0; i < 3; i++)
	{
        	getdata(8+i, 0, " : ", note[0].buf[i], 78, DOECHO, YEA);
        	if (note[0].buf[i][0] == NULL)
			break;
        }
        getdata(12, 0, "(S)�x�s (E)���s�ӹL (A)��� ? [S] : ", ans, 2, DOECHO, 
        	YEA);
        if (ans[0] == 'E' || ans[0] == 'e')
        	return 1; /* try again */
        if (ans[0] == 'A' || ans[0] == 'a' || (note[0].buf[0][0] == NULL))
		return 0;

        strncpy(note[0].userid, cuser.userid, 12);
        strncpy(note[0].username, cuser.username, 12);
        time(&(note[0].date));

/* begin load file */

        if ((fd = open(NOTEDAT, O_RDONLY)) == -1)
        	total = 0;

        if (stat(NOTEDAT, &st) != -1)
        	total = st.st_size/sizeof(notedta);

        if (total > MAXNOTE)
		total = MAXNOTE;

        for (i = 0; i < total; i++)
	{
        	read(fd, (char *) &olditem[i], sizeof(olditem[i]));

                if (olditem[i].date > note[0].date - 60*60)
                {
			strcpy(note[j].userid, olditem[i].userid);
                	strcpy(note[j].username, olditem[i].username);
                	strcpy(note[j].buf[0], olditem[i].buf[0]);
                	strcpy(note[j].buf[1], olditem[i].buf[1]);
                	strcpy(note[j].buf[2], olditem[i].buf[2]);
                	note[j].date = olditem[i].date;
                	j++;
                }
        }
        close(fd);

        if ((fd = open(NOTEDAT, O_WRONLY|O_CREAT, 0644)) == 0)
        	return 0;
        if ((fp = fopen(NOTE, "w")) == NULL)
	{
		close(fd);
        	return(0);
	}

	fprintf(fp,"[1;32;44m%28s%s%29s[m\n","","�W�@��ϥΪ̵��z���d��","");
        for (i = 0; i < j; i++)
	{
		len = 56 - strlen(note[i].userid) - strlen(note[i].username);
        	write(fd, &(note[i]), sizeof(note[i]));
		sprintf(buf, "[1;37;45m�Q[34;47m %s%s[32m(%s) [37;45m",
			note[i].userid,	(len % 2 == 1) ? "  " : " ",
			note[i].username);
		for (len /= 2; len > 0; len--)
			strcat(buf, "�e");
		sprintf(buf2, "%s[34;47m %12.12s [37;45m�Q[m\n", buf,
			ctime(&note[i].date) + 4);
        	fputs(buf2, fp);
		for (len = 0; len < 3 && note[i].buf[len][0] != '\0'; len++)
			fprintf(fp, "%s\n", note[i].buf[len]);
        }
	fputs("[m\n", fp);
        fclose(fp);
        close(fd);
	return 0;
}

int	note(void)
{
        char	ans[2];
	int	ret;

	clear();
        move(1, 0);
        prints(NA, " (1) �d�����U�@��ϥΪ�\n");
        prints(NA, " (2) �g�ʫH������\n");
        prints(NA, " (3) ���O\n");
        getdata(5, 5, "�z����� (1, 2 or 3) ? [3]: ", ans, 2, DOECHO, YEA);

       	switch (ans[0])
	{
        	case '1':
			for (ret = 1; ret != 0; ret = note_retry());
			break;
        	case '2':
			note_sysop();
			break;
        	default:
			break;
	}

}

int	Goodbye(void)
{
	int	ans;

        ans = getans(2, 0, "�z�n���}�����F (Y/N)? [N]", 'n');
        if (ans != 'y')
		return;
	if (!HAS_SET(SET_DISNOTE))
		note();

	goodbye();
}

int	goodbye()
{
	int	num;
	FILE	*lout;
	time_t	now;
	char	genbuf[256];

	clear();
	time(&now);

	sprintf(genbuf, PATH_LOGOUT, cuser.userid);

	if (access(genbuf, R_OK))
	{
		num = now%(long)LOGOUT_PIC;
		sprintf(genbuf, "%s%d", LOGOUT, num);
	}
	show_goodbye(genbuf);
	reset_tty();

	if (started)
		logit(PATH_USIES, "EXIT %-10s %-20s", cuser.userid, 
			cuser.username);

	sleep(3);
	exit(0);
}

int	show_goodbye(filename)
char	*filename;
{
	FILE	*fp;
	int	frg,
		i,
		matchfrg;
	char	numlogins[10],
		numposts[10],
		buf[256],
		lasttime[30],
		thistime[30], 
		*ptr,
		*ptr2;
	time_t	now;

	logout loglst[]  = 
	{
		"userid",	cuser.userid,
		"username",	cuser.username,
		"realname",	cuser.realname,
		"address",	cuser.address,
		"email",	cuser.email,
		"termtype",	cuser.termtype,
		"logins",	numlogins,
		"posts",	numposts,
		"lastlogin",	lasttime,
		"lasthost",	cuser.lasthost,
		"now",		thistime,
		NULL,		NULL
	};

	time(&now);
	strcpy(lasttime, Ctime(&cuser.lastlogin));
	strcpy(thistime, Ctime(&now));
	sprintf(numlogins, "%d", cuser.numlogins);
	sprintf(numposts, "%d", cuser.numposts);
	if((fp = fopen(filename,"r")) == NULL)
		return -1;

	while(fgets(buf, 255, fp) != NULL)
	{
		frg = 1;
		ptr2 = buf;
		do
		{
			if(ptr = strchr(ptr2, '$'))
			{
				matchfrg = 0;
				*ptr = '\0';
				prints( NA, "%s", ptr2);
				ptr += 1;
				for (i = 0; loglst[i].match != NULL; i++)
				{
					if(strstr(ptr, loglst[i].match) == ptr)
					{
						prints(NA, "%s", loglst[i].replace);
						matchfrg = 1;
						break;
					}
				}
				if(matchfrg)
					ptr2 = ptr+strlen(loglst[i].match);
				else
				{
					prints(NA, "$");
					ptr2 = ptr;
				}
			}
			else	
			{
				prints(NA,"%s", ptr2);
				frg = 0;
			}
		}while(frg);
	}

	refresh();
	fclose(fp);
	return;
}

#ifdef FLAG_MAIN_U
int	get_users(uptr)
userec	*uptr;
{
	userec	u;
	char	tbuf[STRLEN];

	bcopy(uptr, &u, sizeof(u));
	tfile = 0;
	rfile = 0;

	if (*(uptr->userid) == '\0')
	{
		tuid++;
		return 0;
	}

	strcpy(tbuf, ctime(&u.lastlogin));
	strncpy(genbuf, tbuf+4, 7);
	genbuf[7] = '\0';
	strcat(genbuf, tbuf+22);
#ifndef FILES
	printf("%-10s %-19s %-9s %-4d  %s", u.userid, u.username, 
		   u.termtype, u.userlevel, genbuf);
#else
	printf("%-10s %-19s %-9s %-4d %6s  %s", u.userid, u.username, 
		   u.termtype, u.userlevel, NameProtocol(u.protocol), genbuf);
#endif
	tuid++;
	return 0;
}

int	UserStatus(void)
{
	tuid = 1;
#ifndef FILES
	printf("%-10s %-19s %-9s %-4s  %s\n", "USER ID", "USERNAME", 
		   "TERMTYPE", "LEVL", "LAST LOGIN");
#else
	printf("%-10s %-19s %-9s %-4s %6s  %s\n", "USER ID", "USERNAME", 
		   "TERMTYPE", "LEVL", "PROTO", "LAST LOGIN");
#endif
	if (apply_record(PASSFILE, get_users, sizeof(userec)) == -1)
	{
		fprintf(stderr, "Error in apply_record\n");
		exit(-1);
	}
	return 0;
}
#endif /* FLAG_MAIN_U */

int	Info(void)
{
	more("Version.Info", YEA);
	clear();
	return 0;
}

#ifdef GNU_License
int	Conditions(void)
{
	more("COPYING", YEA);
	clear();
	return 0;
}
#endif

int	Welcome(void)
{
	if (more(WELCOME, YEA) == -1)
	{
		clear();
		prints(NA, "Welcome screen is not available at this time.\n");
		pressreturn();
    	}

	if (more(MOTD, YEA) == -1)
	{
		clear();
		prints(NA, "���ѨS�������T��\n");
		pressreturn();
    	}

	clear();
	return 0;
}

int	Note(void)
{
	if (more(NOTE, YEA) == -1)
	{
		clear();
		prints(NA, "�ثe�S������T���b�d���O�W�i�Ѭd��.\n");
		pressreturn();
	}
}
