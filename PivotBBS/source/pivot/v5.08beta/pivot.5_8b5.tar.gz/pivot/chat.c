/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful, 
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)chat.c   5.04 3/19/95 (C) 1993 University \
of NCHU, Computer Center";
#endif
#include "command.h"
#include "bbs.h"
#include "common.h"

static	char 	inbuf[STRLEN];
char	*msgto,
	*umsgto,
	sendbuf[STRLEN + 40],
	chatid[STRLEN],
	roomname[20];

int	chatroom,
	chatline,
	echatwin,
	newmail = 0,
	debug = 0;

#ifdef REALINFO
int	chat_real_names = 0;
#endif

int	t_chat(void)
{
	char 	hostname[STRLEN],
		chatstr[80],
		*colon,
#ifdef	HOTKEY
		lastcmd[MAXLASTCMD][80],
#endif
		*ptr;
	struct	hostent	*h;
	struct	sockaddr_in	sin;
	int	a,
		n,
		ch,
		currchar,
		chatport,
		pline,
		page_pending = NA,
		cmdpos=0,
		badlevel = 0;
	time_t	last_check = 0,
		now;

	newmail = 0;
	bzero(inbuf, sizeof(inbuf));

	chatline = currchar = 0;
	clear();
	more(CHATWELCOME,YEA);
	clear();

	move(2,0);
	prints(NA, "<Enter Chat alias (8 char max)>\n");
	getdata(1, 0, "Enter Chat id: ", chatid, 9, DOECHO, YEA);
	if (chatid[0] == '\0' || chatid[0] == '/')
		strcpy(chatid, cuser.userid);
	chatid[8] = '\0';
	strcat(chatid, ":           ");
	chatid[10] = '\0';
#ifdef	HOTKEY
        {
        	int	i;

        	for(i=0; i<=MAXLASTCMD; i++)
                	sprintf(lastcmd[i], "%s%i", chatid, i);
        }
#endif
	strcpy(inbuf, chatid);
	gethostname(hostname, STRLEN);

	if (!(h = gethostbyname(hostname)))
	{
		perror("gethostbyname");
		return -1;
	}

	bzero(&sin, sizeof sin);
	sin.sin_family = h->h_addrtype;
	bcopy(h->h_addr, &sin.sin_addr, h->h_length);

	switch(chatroom)
	{
		case 1:
			chatport = CHATPORT1;
			break;
		case 2:
			chatport = CHATPORT2;
			break;
		case 3:
			chatport = CHATPORT3;
			break;
		case 4:
			chatport = CHATPORT4;
			break;
	}

	sin.sin_port = chatport;
	a = socket(sin.sin_family, SOCK_STREAM, 0); 

	if ((connect(a, (struct sockaddr *)&sin, sizeof sin)))
	{
		move(2,0);
		prints(NA, "Creating Chat Daemon\n");
		refresh();
		close(a);
		sprintf(chatstr, "/home/bbs/bin/bbs.chatd %d", chatroom);
		system(chatstr);

		sleep(2);
		a = socket(sin.sin_family, SOCK_STREAM, 0); 

		if ((connect(a, (struct sockaddr *)&sin, sizeof sin)))
		{

			perror("connect failed");
			return -1;
		}
	}
	switch(chatroom)
	{
		case 1:
			uinfo.mode = CHAT1;
			break;
		case 2:
			uinfo.mode = CHAT2;
			break;
		case 3:
			uinfo.mode = CHAT3;
			break;
		case 4:
			uinfo.mode = BMCHAT;
			break;
	}
	uinfo.comp = YEA;
	strncpy(uinfo.ptcb, chatid, 10);
        if (colon = (char *)rindex(uinfo.ptcb, ':'))
		*colon = '\0';
      	substitute_record(ULIST, (char *)&uinfo, sizeof(uinfo), utmpent);

	strcpy(roomname , "ROOT");	
/*
        sprintf(sendbuf, "%2d:%d:%d:%s:%s:%s", MSG_NEW_USER, getpid(),
		(HAS_PERM(PERM_CHATCLOAK)) ? 1 : 0 , 
        	cuser.userid, cuser.passwd, chatid);
*/
        sprintf(sendbuf, "%2d:%d:%s:%s:%s", MSG_NEW_USER, getpid(), 
                cuser.userid, cuser.passwd, chatid);
                

	write(a,sendbuf,strlen(sendbuf)+1);

	clear();
	printchatline(NA, "  ");

	strcpy(inbuf,chatid);
	pline = t_lines - 1;
	echatwin = t_lines - 2;
	move(echatwin,0);
	printchatmsg();
	move(pline,0);

	if (!dumb_term)
		prints(NA, "%s",inbuf);
	currchar = strlen(inbuf);
	add_io(a,0);

	while (ch = igetkey())
	{
               	switch(ch)
		{
#ifdef	HOTKEY
                      	case KEY_UP:
			case KEY_DOWN:
                               	strcpy(inbuf, lastcmd[0]);
                               	cmdpos = (cmdpos + ((ch == KEY_UP) ? 1 : -1)
					+ MAXLASTCMD) % MAXLASTCMD;
                      		if (cmdpos < 0)
				cmdpos = 1;
				move(pline, 0);
                               	clrtoeol();
                               	if (!dumb_term)
                               		prints(NA, "%s", lastcmd[cmdpos]);
                               	strcpy(inbuf, lastcmd[cmdpos]);
                               	currchar = strlen(inbuf);
                               	continue;
#endif
                       	case KEY_LEFT:
				if (currchar!=10)
                                       	move(pline, --currchar);
                       		continue;
                       	case KEY_RIGHT:
				if (inbuf[currchar])
                                       	move(pline, ++currchar);
                               	continue;
                       	default:
				break;
            	}

		if (talkrequest)
			page_pending = YEA;

		if (page_pending)
			page_pending = servicepage(0, NULL);

		if (newmail = chkmails(cuser,NA))
		{
			move(echatwin,0);
			printchatmsg();
		}

		if (ch == I_OTHERDATA)
		{
			static int cnt  = 0;
			int cc;
			static char buf[512];
			
			if ((cc = read(a,buf+cnt,sizeof buf)) > 0)
			{
				int 	processed = 0,
					ret;

				while (cc > 0)
				{
					register int i;

					for(i=processed;buf[i] != '\0' &&
						i != sizeof buf;i++);

					if (i == sizeof buf && buf[i] != '\0')
					{
						bcopy(buf + processed, buf,
							processed-sizeof(buf));
						cnt = processed - sizeof(buf);
						break;
					}
					cnt = 0;

					ret = proc_server_cmd(buf + processed);

					if (ret == CHG_NICK)
					{
						move(pline, 0);
						strcpy(inbuf, chatid);
						if (!dumb_term)
							prints(NA, "%s", inbuf);
						currchar = strlen(inbuf);
					}
					else if (ret == CHG_ROOM)
					{
				                clear();
        				        move(echatwin,0);
        				        printchatmsg();
        				        chatline = 0;
        				        printchatline(NA, "  ");
						move(echatwin,0);
						printchatmsg();
						move(pline,0);
					        if (!dumb_term)
        					        prints(NA, "%s",inbuf);
      						  currchar = strlen(inbuf);

					}	

					i++;
					cc -= (i - processed);
					processed = i;

					if (i == sizeof buf)
						break;
				}
			}
			else
			{
				sprintf(buf, "%s %d, errno = %d\n",
					"CHAT FAILURE: read returned", cc,
					errno);
				break;
			}
/* mark */
                        move(pline,currchar);
			continue;
		}

#ifdef BIT8
		if (isprint2(ch))
#else
        	if (isprint(ch))
#endif
		{
	                if (currchar == 78)
			{
                		bell(1);
                		continue;
                	}
                	if (!inbuf[currchar])
			{
                		inbuf[currchar+1] = '\0';
                		inbuf[currchar] = ch;
                	}	
               		else
			{
                		int	i,
					j;

        			for(i = currchar; inbuf[i]; i++);
					inbuf[i+1] = '\0';
        	        	for(j = i; j > currchar; j--)
				inbuf[j] = inbuf[j-1];
        	        	inbuf[j] = ch;
                	}
                	currchar++;
                	move(pline,currchar-1);
                	prints(NA,"%s",&inbuf[currchar-1]);
#ifdef	HOTKEY
                	strcpy(lastcmd[0],inbuf);
#endif
                	move(pline,currchar);
                	continue;
            	}

		if (ch == '\n' || ch == '\r')
		{
			char	buf[STRLEN];
			int	i,
				j;
            
			if (dumb_term)
				prints(NA, "\n");

			for(i=10, j=0; i<STRLEN; i++)
			{
				if (inbuf[i] == '\0')
				{
					buf[j] = '\0';
					break;
				}
				if (inbuf[i] != ' ')
				buf[j++] = inbuf[i];
			}
#ifdef	HOTKEY
                	if (inbuf[10])
			{
                        	for(i = MAXLASTCMD-1; i > 0; i--)
                                	strcpy(lastcmd[i], lastcmd[i-1]);
                        	strcpy(lastcmd[0],inbuf);  
                	}
#endif              
                	cmdpos=0;                        

			if (buf[0] == '\0')
				continue;

			if (inbuf[10] == '/')
			{
/* MARK by SLASH */			
				int action = dochatcommand(&inbuf[11], a);

				if (action == -2)
				{
			/*		ch = CINTR; */
					break;
				}
				else if (action == -1)
				{
					sprintf(buf, "%s -1, errno = %d\n",
						"CHAT FAILURE: write returne",
						 errno);
					break;
				}
			}
			else 
			{
				sprintf(sendbuf,"%2d:%s",MSG_PUB,inbuf);
				if (write(a, sendbuf, strlen(sendbuf) +1) == -1) {
					sprintf(buf, "%s -1, errno = %d\n",
						"CHAT FAILURE: write returned", errno);
					break;
	        		}
			}
/* mark may not useful */
	                move(pline, 0);
        	        strcpy(inbuf, chatid);
                	currchar = strlen(inbuf);

			if (!dumb_term)
				prints(NA, "%s", inbuf);
			clrtoeol();
			move(pline,currchar);
			continue;
		}

		if (ch == CTRL('H') || ch == '\177')
		{
			char	tmp[STRLEN];

			if (currchar == 10)
			{
				bell(1);
				continue;
			}

			strcpy(tmp, &inbuf[currchar]);
			inbuf[--currchar] = '\0';
			strcat(inbuf, tmp);
			move(pline, 0);
			prints(NA, "%s", inbuf);
			clrtoeol();
	                move(pline, currchar);
			inbuf[strlen(inbuf)] = '\0';
	                continue;
		}

		if (ch == CTRL('C') || ch == CTRL('D'))
		{
			sprintf(sendbuf, "%2d:NONE", MSG_QUIT);
        	        write(a, sendbuf, strlen(sendbuf)+1);
                	break;
		}
        }

        add_io(0,0);
	close(a);

	uinfo.comp = NA;
	uinfo.ptcb[0] = '\0';

	changemode(TMENU, NA);

	clear();

	return 0;
}

int	send_to_server(cmd, fd, action, flag)
int 	cmd,
	fd,
	flag;
char	*action;
{

	int 	retval;

	if (flag && *action == '\0')
	{
		printchatline(NA,"*** invalid item ***");
		return 0;
	}
	
	sprintf(sendbuf,"%2d:%s", cmd, (flag) ? action : "NONE");
	
	retval = write(fd, sendbuf, strlen(sendbuf) + 1);
	if (retval > -1)
		retval = 0;

	return 	retval;
}
	
int	dochatcommand(cmd, fd)
char	*cmd;
int 	fd;
{
	char	*endcmd,
		buf[80];
	int	retval = 0,
		cmdlen;

	while (*cmd == ' ')
		cmd++;

	endcmd = cmd;

	while (*endcmd != ' ' && *endcmd != '\n' && *endcmd)
		endcmd++;

	if (*endcmd == '\0')
		*(endcmd+1) = '\0';
	else
		*endcmd = '\0';

	cmdlen = strlen(cmd);

        if (!strncmpi(cmd, "help",cmdlen))
	{
		retval = send_to_server(MSG_HELP, fd, endcmd+1, NA);
        }
        if (!strncmpi(cmd, "advance",cmdlen))
	{
                retval = send_to_server(MSG_ADVANCE, fd, endcmd+1, NA);
        }
	else if (!strncmpi(cmd, "list",cmdlen))
	{
		retval = send_to_server(MSG_ROOM_LST, fd, endcmd+1, NA);
	}
        else if (!strncmpi(cmd, "query",cmdlen))
	{
		retval = do_query(endcmd+1);
        }
	else if (!strncmpi(cmd, "topic", cmdlen))
	{
		retval = send_to_server(MSG_TOPIC , fd, endcmd+1,
			(*(endcmd+1) ? YEA : NA));
	}
	else if (!strncmpi(cmd, "oper", cmdlen))
	{
		retval = send_to_server(MSG_OPER, fd , endcmd+1,YEA);
	}
	else if (!strncmpi(cmd, "invite", cmdlen))
	{
		retval = send_to_server(MSG_INV , fd , endcmd+1,YEA);
	}
	else if (!strncmpi(cmd, "ban", cmdlen))
	{
		retval = send_to_server(MSG_BAN , fd, endcmd+1,YEA);
	}

	else if (!strncmpi(cmd, "set", cmdlen))
	{
		retval = send_to_server(MSG_SET_ROOM,fd,endcmd+1,YEA);
	}
	else if (!strncmpi(cmd, "ignore",cmdlen))
	{
		retval = send_to_server(MSG_IGNORE,fd , endcmd+1,YEA);
	}
        else if (!strncmpi(cmd, "lign",cmdlen))
	{
                retval = send_to_server(MSG_LST_IGN,fd , endcmd+1,NA);
        }
        else if (!strncmpi(cmd, "rmign",cmdlen))
	{
                retval = send_to_server(MSG_RM_IGN,fd , endcmd+1,YEA);
        }
	else if (!strncmpi(cmd, "join",cmdlen))
	{
		retval = send_to_server(MSG_JOIN, fd, endcmd+1 , YEA);
	}
        else if (!strncmpi(cmd, "lban",cmdlen))
	{
                retval = send_to_server(MSG_LST_BAN, fd, endcmd+1, NA);
	}
        else if (!strncmpi(cmd, "linv",cmdlen))
	{
                retval = send_to_server(MSG_LST_INV, fd, endcmd+1, NA);
	}
        else if (!strncmpi(cmd, "rminv",cmdlen))
	{
                retval = send_to_server(MSG_RM_INV, fd, endcmd+1, YEA);
        }
        else if (!strncmpi(cmd, "rmban",cmdlen)) {
                retval = send_to_server(MSG_RM_BAN, fd, endcmd+1, YEA);
        }
        else if (!strncmpi(cmd, "who", cmdlen)) {
		retval = send_to_server(MSG_WHO,  fd, endcmd+1, NA);
	}
        else if (!strncmpi(cmd, "whos", cmdlen)) {
		if (*(endcmd+1) == NULL)
			strcpy(endcmd+1, roomname);
		retval = send_to_server(MSG_WHOS,  fd, endcmd+1, YEA);
	}
        else if (!strncmpi(cmd, "msg", cmdlen))
	{
		retval = domsg(endcmd+1, fd);	
	}
	else if (!strncmpi(cmd, "kick", cmdlen))
	{
		retval = send_to_server(MSG_KICK, fd, endcmd+1, YEA);
	}
        else if (!strncmpi(cmd, "nick", cmdlen))
	{
		send_to_server(MSG_NICK, fd, endcmd+1, YEA);
		retval = 1;
	}
        else if (!strncmpi(cmd, "pager",cmdlen))
	{
		if (HAS_PERM(PERM_BASIC))
		{
			t_pager();
	        	printchatline(NA, " ");
	        	if (!uinfo.pager) 
	        		printchatline(NA, "*** Pager turned off");
			else
				printchatline(NA, "*** Pager turned on");
		} else
			printchatline(NA, "** ERROR: unknown chat command");
        }
	else if (!strncmpi(cmd, "me", cmdlen))
	{
		char	*firstlet = endcmd + 1;

		while (*firstlet == ' ' || *firstlet == '\n' ||
			*firstlet == '\t')
			firstlet++;

		if (*firstlet != '\0')
		{
			sprintf(sendbuf, "%2d:%s %s",MSG_PUB, uinfo.ptcb,
				endcmd+1);
			write(fd, sendbuf, strlen(sendbuf)+1);
		}
		else
			printchatline(NA, "** ERROR: no action specified");
	}
	else if (!strncmpi(cmd, "clear", cmdlen))
	{
		clear();
		move(echatwin,0);
		printchatmsg();
		chatline = 0;
		printchatline(NA, "  ");
	}
		else if (!strncmpi(cmd, "cloak",cmdlen))
	{
		retval = send_to_server(MSG_DO_CLO, fd,endcmd+1,NA);
	}                                        
	else if (!strncmpi(cmd,"date", cmdlen))
	{
		char	bufr[80];
		time_t	thetime;

		time(&thetime);

		printchatline(NA, "*** Date/time on this host: %s",Ctime(&thetime));
	}
	else if (!strncmpi(cmd,"exit",cmdlen))
	{
		sprintf(sendbuf,"%2d:NONE",MSG_QUIT);
		write(fd,sendbuf,strlen(sendbuf));
		retval = -1;
	}		
	return retval;
}

void	printchatmsg()
{
	prints(NA, "======= [%18.18s] === [%10.10s] === %18.18s =========",
				BoardName,roomname,
		(newmail) ? "[�z���s�H��Ū��]" : "use /help for help");
}

char	*advance(ptr)
char	*ptr;
{
	while (*ptr != ' ' && *ptr != '\n' && *ptr != '\t')
	{
		if (*ptr == '\0')
			return ptr;
		else
			ptr++;
	}

	while (*ptr == ' ' || *ptr == '\n' || *ptr == '\t')
		ptr++;

	*(ptr-1) = '\0';

	return ptr;
}

void	printchatline(std, va_alist)
int	std;
va_dcl
{
        va_list args;
        char    buff[240],
                *fmt;

        va_start(args);
        fmt = va_arg(args, char *);
        vsprintf(buff, fmt, args); 
        va_end(args);

	strcat(buff, "\n");
        move(chatline++,0);
        clrtoeol();
	if (std)
		standout();
	outs(buff);
	if (std)
		standend();

	if (chatline == echatwin)
	{
		if (HAS_SET(SET_CHATSCROLL))
		{
			move(echatwin+1,0);
			printchatmsg();
			scroll();
			outs(inbuf);
			
			chatline--;
		}
		else
			chatline = 0;
	}
        move(chatline,0);
        clrtoeol();

        if (!dumb_term)
		outs("-->");

	return ;
}

int	domsg(id,fd)
char	*id;
int	fd;
{
	char	*text,
	        buf[STRLEN];
	int     retval;


        while (*id == ' ' || *id == '\t' || *id == '\n')
                        id++;
        if (*id == '\0')
	{
        	printchatline(NA, "** ERROR: you must specify a recipient");
                return 0;
        }
        text = advance(id);
        msgto = id;

        if (*text == '\0')
        {
                printchatline(NA, "** ERROR: blank messages aren't allowed");
                return 0;
        }
	sprintf(buf,"%2d:%s %s",MSG_PRIV,id,text);
	retval = write(fd,buf, strlen(buf)+1);
	sprintf(buf, "%s> %s", msgto, text);
        printchatline(NA, buf);
        msgto = NULL;

        if (retval > -1)
                retval = 0;

        return retval;
}

int	proc_server_cmd(ptr)
char	*ptr;
{
	int  	cmd;
	char	*cptr;

	cptr = ptr;
	ptr[1] = '\0';
	cmd = atoi(cptr);
	if (cmd == MESSAGE)
	{
		printchatline(NA, &ptr[2]);
		return 0;
	} else 	
	if (cmd == CHG_NICK)
	{
		strcpy(uinfo.ptcb, &ptr[2]);
		substitute_record(ULIST, (char *)&uinfo, sizeof(uinfo), utmpent);	

		strcpy(chatid, uinfo.ptcb);
		chatid[8] = '\0';
		strcat(chatid,
        		":                      ");
		chatid[10] = '\0';
		return cmd;
	}
	else if (cmd == CHG_ROOM)
	{
		strncpy(roomname, &ptr[2], 10);
		return cmd;
	} 

	return 0;
}

int	do_query(id)
char	*id;
{

        while (*id == ' ' || *id == '\t' || *id == '\n')
                        id++;
        if (*id == '\0')
	{
                printchatline(NA, "** ERROR: you must specify a recipient");
                return 0;
        }

	if (!getuser(id))
	{
		printchatline(NA, "*** [ĵ�i]: �d�L���H %s", id);
		return 0;
	}
	show_plan(NA, id, printchatline);
	return 0;
}

/*************************************************************************/
int	ent_chat1(void)
{
	int	savecloak = uinfo.invisible;

	if (!HAS_PERM(PERM_CHATCLOAK))
		uinfo.invisible = NA;

	chatroom = 1;
	t_chat();

	if (!HAS_PERM(PERM_CHATCLOAK))
 		uinfo.invisible = savecloak;
}

int	ent_chat2(void)
{
	int	savecloak = uinfo.invisible;

	if (!HAS_PERM(PERM_CHATCLOAK))
		uinfo.invisible = NA;

	chatroom = 2;
	t_chat();

	if (!HAS_PERM(PERM_CHATCLOAK))
 		uinfo.invisible = savecloak;
}

#ifdef USE_CHAT3
#ifdef CHAT3_CLOAKED
int	ent_chat3(void)
{
	int savecloak = uinfo.invisible;

	uinfo.invisible = YEA;
	chatroom = 3;
	t_chat();
	uinfo.invisible = savecloak;
}
#else
int	ent_chat3(void)
{
	int	savecloak = uinfo.invisible;

	if (!HAS_PERM(PERM_CHATCLOAK))
		uinfo.invisible = NA;
	chatroom = 3;
	t_chat();
	if (!HAS_PERM(PERM_CHATCLOAK))
 		uinfo.invisible = savecloak;
}
#endif
#endif

int     ent_chatbm(void)
{
        int     savecloak = uinfo.invisible;

        if (!HAS_PERM(PERM_CHATCLOAK))
                uinfo.invisible = NA;

        chatroom = 4;
        t_chat();

        if (!HAS_PERM(PERM_CHATCLOAK))
                uinfo.invisible = savecloak;
}
