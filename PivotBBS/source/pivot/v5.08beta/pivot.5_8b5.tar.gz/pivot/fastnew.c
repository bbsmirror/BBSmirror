/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

static  char    sccsid[] = "@(#)fastnew.c  5.04 3/19/95 (C) 1993 University \
of NCHU, Computer Center and Tseng Kuo-Feng";

#include "bbs.h"

newhd	*nbrd;
int	newnum = 0;

int	newpost_board(fptr)
shthd	*fptr;
{
	newhd	*ptr;

	ptr = &nbrd[newnum++];
	ptr->name = fptr->filename;
	ptr->manager1 = fptr->manager1;
	ptr->manager2 = fptr->manager2;
	ptr->manager3 = fptr->manager3;
	ptr->title = fptr->title;
	ptr->total = -1;
	ptr->post = -1;
	ptr->zap = &fptr->accessed;
	ptr->flag = &fptr->flag;

	return 0;
}

int	count_newpost(ptr, newcount)
newhd	*ptr;
int	newcount;
{
	struct	stat	st;
	int	fd,
		offset,
		total,
		num;
	uschar	ch;
	fhd	fh;

	ptr->total = ptr->post = 0;
	sprintf(genbuf, "%s%s", bfile(ptr->name), FHDIR);

	if((fd = open(genbuf, O_RDWR)) < 0)
		return 0;

	fstat(fd, &st);
	total = st.st_size / sizeof(fhd);

	if (total <= 0)
	{
		close(fd);
		return 0;
	}

	offset = ((int)&(fh.accessed[usernum]) - (int)&(fh));
	ptr->total = total;
	num = total - 1;

	if (newcount == YEA)
	{
		while (num > 0)
		{
			lseek(fd, offset + num * sizeof(fhd), L_SET);
			if (read(fd, &ch, 1) <= 0 || (ch & FILE_READ) ||
				(ch & FILE_VISIT))
			{
				break;
			}
			num -= 10;
		}

		if (num < 0)
			num = 0;

		while (num < total)
		{
			lseek(fd, offset + num * sizeof(fhd), L_SET);
			if(read(fd, &ch, 1) <= 0 || (ch & FILE_READ) == 0)
				break;
			num++;
		}
		ptr->post = total - num;
	}
	else
	{
		lseek(fd, offset + num * sizeof(fhd), L_SET);
		if (!(read(fd, &ch, 1) <= 0 || (ch & FILE_READ) ||
			(ch & FILE_VISIT)))
		{
			ptr->post = 1;
		}
	}

	close(fd);
}

char	*newstr(ptr, newcount)
newhd	*ptr;
int	newcount;
{
	static	char	buf[STRLEN];

	if (*ptr->zap & ZAPPED)
	{
		ptr->total = ptr->post = -1;
		sprintf(buf, "%9s  %c %c ", "--- z ---",
			(*ptr->flag & BHD_VOTEING) ? '%' : ' ',
			(*ptr->flag & BHD_BBSNEWS) ? '#' : ' ');
	}
	else
	{
		if (ptr->total == -1)
			count_newpost(ptr, newcount);
		if (newcount)
			sprintf(buf, "%4d:%4d  %c %c ", ptr->post, ptr->total,
				(*ptr->flag & BHD_VOTEING) ?
				((*ptr->zap & VOTED) ? '%' : '#') : ' ',
				(*ptr->flag & BHD_BBSNEWS) ? '#' : ' ');
		else
			sprintf(buf, "%4s:%4d  %c %c ",
				(ptr->post) ? "��" : "��", ptr->total, 
                                (*ptr->flag & BHD_VOTEING) ?
				((*ptr->zap & VOTED) ? '%' : '#') : ' ',
                                (*ptr->flag & BHD_BBSNEWS) ? '#' : ' ');
	}
	return buf;
}

char	*brdstr(ptr)
newhd	*ptr;
{
	static	char	buf[STRLEN];

	sprintf(buf, "%c %c %c ", ((int)(*ptr->zap) & ZAPPED) ? '#' : ' ',
		((*ptr->flag) & BHD_VOTEING) ? (((int)(*ptr->zap) & VOTED) ?
		'%' : '#') : ' ', ((*ptr->flag) & BHD_BBSNEWS) ? '#' : ' ');

	return buf;
}

void	show_brdlist(page, clsflag, newflag, newcount)
int	page,
	clsflag,
	newflag,
	newcount;
{
	newhd	*ptr;
	int	n;

	if (clsflag)
	{
		clear();
		menu_draw("[�Q�װϦC��]", boardmargin);
		move(1,0);
		prints(NA, "%-20s%-11s%-27s%-20s\n", "[��,e]�^�Q�װϿ��",
			"[h]�D�U", "[��,r,<cr>]�i�J�\\Ū�e��",
			"[��,��]�W,�U�@�Q�װ�");
		prints(YEA, "[1;32;44m %-5s%*s %-18s%-18s%*s[m\n", "�s��",
			(newflag) ? 14 : 5, (newflag) ? "[ �s:�� ]  V B" :
			"Z V B", "�Q�װϦW��", "�Q�װϻ���", (newflag) ? 21 :
			30, "�t�d�H");
	}

	move(3, 0);

	if (newnum > 0)
	{
		for(n = page; n < page + PAGESIZE; n++)
		{
			if (n >= newnum)
			{
				prints(NA, "\n");
				continue;
			}
			ptr = &nbrd[n];
			prints(NA, " %4d %*s%-18.18s%-26.26s %*s\n", n+1,
				(newflag) ? 15 : 5, (newflag) ? newstr(ptr,
				newcount) : brdstr(ptr), ptr->name,
				ptr->title, (newflag) ? 12 : 21,
				ptr->manager1);
		}
	}

	refresh();
}

int	choose_board(group, yank)
int	group,
	yank;
{
	newhd	newpost_buffer[MAXBOARD],
		*ptr;
	char	lbuf[11];
	int	page,
		ch,
		tmp,
		quick,
		lbc = 0,
		newflag,
		newcount,
		ans,
		num;

	nbrd = newpost_buffer;

	if (uinfo.mode == KIND || uinfo.mode == READNEW)
	{
		newflag = YEA;
		newcount = HAS_SET(SET_COUNTNEW) ? YEA : NA;
 	}
	else
		newflag = newcount = NA;

	substitute_record(ULIST, (char *)&uinfo, sizeof(uinfo), utmpent);

	newnum = num = 0;
	show_brdlist(0, 1, newflag, newcount);
	apply_boards(newpost_board, group, yank);

	if (newnum <= 0)
	{
		ans =getans(3, 0, "�ثe�L�Q�װ�, �ӽХ����Q�װ�(Y/N)? [Y]: ",
			'y');

		if (ans == 'y')
		{
			yank = YEA;
			apply_boards(newpost_board, group, yank);
		}
		else
			return -1;
	}

	page = -1;
	while (newnum > 0)
	{
		if (num < 0)
			num = 0;
		if (num >= newnum)
			num = newnum - 1;
		if (page < 0)
		{
			if (newflag)
			{
				tmp = num;
				while (num < newnum)
				{
					ptr = &nbrd[num];
					if (ptr->total == -1 && !
						((int)*ptr->zap & ZAPPED))
						count_newpost(ptr, newcount);
					if (ptr->post != 0 && ptr->post != -1)
						break;
					num++;
				}
				if (num >= newnum)
				num = tmp;
			}
			page = (num / PAGESIZE) * PAGESIZE;
			show_brdlist(page, 1, newflag, newcount);
		}

		if (num < page || num >= page + PAGESIZE)
		{
			page = (num / PAGESIZE) * PAGESIZE;
			show_brdlist(page, 0, newflag, newcount);
		}

		move(3+num-page,0);
		prints(NA, ">");
		ch = egetch();

		if (ch < 0x100 && isdigit(ch))
		{
			if (lbc < 9)
				lbuf[lbc++]=ch;
			continue;
		}

		if (ch != '\n' && ch != '\r' && ch != '\0' && ch != KEY_RIGHT)
			lbc = 0;
		move(3+num-page,0);
		prints(NA, " ");
		if (ch == 'q' || ch == 'e' || ch == KEY_LEFT || ch == EOF)
			break;

		switch(ch)
		{
			case 'P':
			case CTRL('B'):
			case KEY_PGUP:
				num -= PAGESIZE;
				break;

			case 'N':
			case ' ':
			case CTRL('F'):
			case KEY_PGDN:
				num += PAGESIZE;
				break;

			case 'p':
			case 'k':
			case KEY_UP:
				if (num-- == 0)
					num = newnum -1;
				break;

			case 'n':
			case 'j':
			case KEY_DOWN:
				if (++num == newnum)
					num = 0;
				break;	

			case '$':
			case KEY_END:
				num = newnum - 1;
				break;

			case '!':
			case KEY_HOME:
			        num = 0;
			        break;

			case 'y':
			case 'Y':
				num = newnum = 0;
				yank = (yank+1)%2;
				apply_boards(newpost_board, group, yank);
				page = -1;
				break;

		    	case 'h':
			case 'H':
				ptr = &nbrd[num];
	        		boardhelp();
	        		ptr->total = page = -1;
				break;
			case 'z':
			case 'Z':
			{
				int	pos=0;
				bhd	bh;

				ptr = &nbrd[num];
				pos = search_record(BOARDS, (char *)&bh,
					sizeof(bh), cmpbnames, (int)ptr->name);
				if (!pos)
				{
					numboards = -1;
					return -1;
	        		}
	        		move(3+num-page, 6);
	        		if (*ptr->zap & ZAPPED)
				{
	        			if (newflag)
					{
	        			    if (ptr->total < 0 ||
						ptr->post < 0)
	        				count_newpost(ptr, newcount);
					if (newcount)
						prints(NA, "%4d:%4d  ",
						ptr->post, ptr->total);
					else
						prints(NA, "%4s:%4d  ",
						(ptr->post) ? "��" : "��",
						ptr->total);
				} else
					prints(NA, " ");
				bh.accessed[usernum] &= ~ZAPPED;
			} else {
				prints(NA, "%s", (newflag) ? "--- z --- " : "#");
				bh.accessed[usernum] |= ZAPPED;
		        }
			bcopy(&bh.accessed[usernum], ptr->zap, sizeof(uschar));
		        substitute_record(BOARDS, (char *)&bh, sizeof(bh), pos);
		        break;
		}
		case 'x':
		{	char buf[80];

			faqview(nbrd[num].name);

			page = -1;
			break;
		}
		case 'v': case  'V':
			quick = YEA;
		case 'f':
		{	bhd bh;

	        	if (ptr == '\0' || !search_record(BOARDS, (char *)&bh,
				sizeof(bh), cmpbnames, (int)nbrd[num].name)) {
				numboards = -1;
				return -1;
		        }
		        visit_board(&bh, quick);
		        nbrd[num].post = 0;
		        if (newflag && !(*nbrd[num].zap & ZAPPED)) {
				move(3+num-page, 6);
				if (newcount)
		        		prints(NA, "%4d",nbrd[num].post);
				else
					prints(NA, "%4s", "��");
	        	}
			quick = NA;
		        break;
		}
		case '\t': case 's': case 'S':
		{	int	i, quit;
			char    bname[STRLEN];

			i=0; quit= NA;
			bzero(bname, sizeof(bname));
			while (1) {
				move(t_lines-1, 0);
				clrtoeol();
				prints(YEA, "�п�J�j�M���W ==> ");
				prints(NA, "%s", bname);
				ch = egetch();
				if (isprint(ch)) {
					register find = NA;
					register int j;
					bname[i++] = ch;
					for(j=0; j < newnum; j++) {
						ptr = &nbrd[j];
			   			if (!strncmpi(ptr->name, bname, i)) {
							find = YEA;
							move(3+num-page, 0);
							prints(NA, " ");
							num = j;
                        				if (((num / PAGESIZE) * PAGESIZE) != page) {
                        					page = (num / PAGESIZE) * PAGESIZE;
								show_brdlist(page, 0, newflag, newcount);
						     	}
			                             	move(3+num-page, 0);
                             				prints(NA, ">");
	   		     				break;
					   	}
					}
					if (find == NA) {
						bname[--i] = '\0';
						bell(1);
					}
					continue;
		     		} else if (ch == CTRL('H') || ch == KEY_LEFT || ch == KEY_DEL || ch == '\177') {
					i--;
					if (i < 0) {
						i = 0;
						quit = YEA;
						break;
					} else {
						bname[i] = '\0'; 
						continue;
					}
				} else if (ch == '\t') {
					quit = YEA;
					break;
		     		} else if (ch == '\n' || ch == '\r' || ch == KEY_RIGHT) {
					break;
				}
				bell(1);
			}
			if (quit) {
 				move(t_lines-1, 0);
				clrtoeol();
				break;
			}
		}
		case 'r': case '\n': case '\r': case KEY_RIGHT:
			if (lbc == 0)
			{
	       			char	buf[STRLEN];

				ptr = &nbrd[num];
				strcpy(currboard, ptr->name);
				if (newflag && newcount)
				{
					sprintf(buf, "%s%s", bfile(currboard),
						FHDIR);
					tmp = ptr->total - ptr->post;
					getkeep(buf, tmp + 1, tmp + 1, 1);
				}
				selboard = YEA;
				Read();
				ptr->total = page = -1;
			}
			else
			{
	        		lbuf[lbc] = '\0';
	        		num = atoi(lbuf) - 1;
	        		lbc=0;
	    		}
			break;
		case 'i': case 'I':
		{	char buf[STRLEN], in[STRLEN*3];
			FILE *info;
			int i;

	        	clear();
			ptr = &nbrd[num];
	        	sprintf(buf,"boards/%s/.INFO", ptr->name);
	
			move(1,0);
			prints(NA, "Current Board is: %s\n", ptr->name);
			prints(NA, "        Title is: %s\n\n", ptr->title);
			prints(NA, "Board Managers are:\n");
			prints(NA, "1) %s\n", ptr->manager1[0] ? ptr->manager1 : "<null>");
			prints(NA, "2) %s\n", ptr->manager2[0] ? ptr->manager2 : "<null>");
			prints(NA, "3) %s\n\n", ptr->manager3[0] ? ptr->manager3 : "<null>");
			prints(NA, "Exchange Posts with other BBS: %s\n",
				(*ptr->flag & BHD_BBSNEWS) ? "YES" : "NO");
			prints(NA, "This Board is %s now.\n\n",
				((int)*ptr->zap & ZAPPED) ? "Zapped" : "Not Zapped");
			if ((info = fopen(buf, "r")) == NULL)
				prints(NA, "No Information Applied on this Board.\n");
			else {
				prints(YEA, "Information:\n");
				for(i = 1; i <= 9; i++) {
					if (fgets(in, sizeof(in), info))
						prints(NA, "%s",in);
					 else
						break;
		  		}
				fclose(info);
			}
			pressreturn();
			ptr->total = page = -1;
			break;
	    	}
		case 'E':
		{	char buf[STRLEN];
			int bm;

			clear();
			ptr = &nbrd[num];
			if (!stricmp(cuser.userid, ptr->manager1) ||
				!stricmp(cuser.userid, ptr->manager2) ||
				!stricmp(cuser.userid, ptr->manager3)) 
				bm = YEA;

			if (HAS_PERM(PERM_BOARDS) || (HAS_PERM(PERM_LOCALBM) && bm)) {
				sprintf(buf,"boards/%s/.INFO", ptr->name);
				vedit(buf, NA);
				ptr->total = page = -1;
			} else 
				bell(1);
			break;
	     	}
		default:
			bell(1);
			break;
		}
	}
	clear();
	return REDOIREAD;
}

int	visit_board(fptr, quick)
bhd	*fptr;
int	quick;
{
	int	i,
		offset,
		start,
		end,
		plus,
		fd,
		size;
	long	numfiles;
	uschar	ch;
	struct	stat	st;
	fhd	fh;
	char	genbuf[80];

	size = sizeof(fhd);
	offset = ((int)&fh.accessed[usernum] - (int)&fh);

	sprintf(genbuf,"%s%s",bfile(fptr->filename), FHDIR);
	if ((fd = open(genbuf, O_RDWR)) < 0)
		return 0;

	fstat(fd,&st);
	numfiles = st.st_size/size;

	if (numfiles <= 0)
	{
		close(fd);
		return 0;
	}
	flock(fd, LOCK_EX);

	if (quick)
	{
		start = numfiles-1;
		end = -1;
		plus = -1;
	}
	else
	{
		start = 0;
		end = numfiles;
		plus = 1;
	}

	lseek(fd, offset+start*size, L_SET);

	for(i = start; i != end; i+=plus, lseek(fd, offset+i*size, L_SET))
	{
		if (kbhit() == 'q')
		{
			if (uinfo.mode == VISIT)
			{
				flock(fd, LOCK_UN);
				close(fd);
				return QUIT;
			}
			else
				break;
		}
	        read(fd, &ch, 1);
	        if (!(ch & FILE_READ))
		{
			lseek(fd, offset+i*size, L_SET);
        		ch |= FILE_READ;
        		ch |= FILE_VISIT;
        		write(fd, &ch, 1);
			move(t_lines-1, 0);
			prints(YEA, "�N�� [%4d] ����ƼЬ�Ū�L", i+1);
			refresh();
        	}
		else
		{
			if (quick)
				break;
		}
	}

	flock(fd, LOCK_UN);
	close(fd);

	move(t_lines-1,0);
	clrtoeol();
	return PARTUPDATE;
}

int	visit_boards(fptr)
shthd	*fptr;
{
	char	buf[STRLEN];
	bhd	fh;

	move(1,0);
	prints(YEA, "�ثe Visit �� Board ��: %.20s\n", fptr->filename);
	search_record(BOARDS, (char *)&fh, sizeof(fh), cmpbnames,
		(int)fptr->filename);
	if (visit_board(&fh, YEA) == QUIT)
		return QUIT;
	return 0;
}

int	Visit(void)
{
	int	ans;
	char	bname[STRLEN];
	bhd	fh;

	clear();
	refresh();
	move(0,0);

	changemode(VISIT, NA);

	prints(NA, "Visit Board(s)\n");
	ans = getans(1,0,"(A)ll boards, (1) board, or (Q)uit? [Q]: ",'q');
	move(1,0);
	clrtoeol();

	switch(ans)
	{
		case 'a':
			apply_boards(visit_boards, -1, NA);
			break;
		case '1':
			make_blist();
			prints(NA, "Select board: ");
			namecomplete((char *)NULL, bname);
			move(5,0);
			if (*bname == '\0' || !search_record(BOARDS,
				(char *)&fh, sizeof(fh), cmpbnames,
				(int)bname))
			{
				prints(NA, "Invalid board name.\n");
				break;
			}
			prints(NA, "�ثe���b�N %s �O�Ь�Ū�L.. �еy��",
				fh.filename);
			visit_board(&fh, YEA);
			move(5, 0);
			clrtoeol();
			break;
		default:
			move(5,0);
			prints(NA, "Visit aborted.\n");
	}
	pressreturn();
	clear();

	changemode(MPOST, NA);

	return -1;
}

