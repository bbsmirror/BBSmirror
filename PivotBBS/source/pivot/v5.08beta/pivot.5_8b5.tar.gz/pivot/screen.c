/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)screen.c   5.04 3/19/95 (C) 1993 University \
of NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include "bbs.h"

uschar	scr_lns,
	scr_cols,
	cur_ln = 0,
	cur_col = 0,
	roll, 
	docls,	
	downfrom;
int	scrollcnt,
	standing = NA,
	tc_col,
	tc_line;
scrln	*big_picture = NULL;
static	char	nullstr[] = "(null)";

void	init_screen(slns,scols)
int	slns,
	scols;
{
	scr_lns = slns;
	scr_cols = MYMIN(scols,LINELEN);
	big_picture = (scrln *) calloc(scr_lns, sizeof(scrln));
	for(slns=0;slns<scr_lns;slns++)
	{
        	big_picture[slns].mode = 0;
        	big_picture[slns].len = 0;
        	big_picture[slns].oldlen = 0;
	}
    	docls = YEA;
    	downfrom = 0;
    	roll = 0;
}

void	initscr(void)
{
	if(!dumb_term && !big_picture)
		init_screen(t_lines,t_columns);
}

void	rel_move(was_col,was_ln,new_col,new_ln)
int	was_col,
	was_ln,
	new_col,
	new_ln;
{
	if(new_ln >= t_lines  || new_col >= t_columns)
		return;
	tc_col = new_col;
	tc_line = new_ln;
	if((new_col == 0) && (new_ln == was_ln+1))
	{
		ochar('\n');
        	if(was_col != 0)
        		ochar('\r');
        	return;
    	}
    	if((new_col == 0) && (new_ln == was_ln))
	{
        	if(was_col != 0)
        		ochar('\r');
        	return;
    	}
    	if(was_col == new_col && was_ln == new_ln)
      		return;
    	if(new_col == was_col - 1 && new_ln == was_ln)
	{
        	if(BC)
        		tputs(BC,1,ochar);
        	else
        		ochar(CTRL('H'));
        	return;
    	}
	do_move(new_col, new_ln, ochar);
}

void	standoutput(buf, ds, de, sso, eso)
char	*buf;
int	ds,
	de,
	sso,
	eso;
{
	int	st_start,
		st_end;

	if(eso <= ds || sso >= de)
	{
		output(buf+ds,de-ds);
		return;
    	}
    	st_start = MYMAX(sso,ds);
    	st_end = MYMIN(eso,de);
    	if(sso > ds)
      		output(buf+ds,sso-ds);
    	o_standup();
    	output(buf+st_start,st_end-st_start);
    	o_standdown();
    	if(de > eso)
      		output(buf+eso,de-eso);
}

void redoscr(void)
{
	register	int	i,
				j;
    	register	scrln	*bp = big_picture;

	if(dumb_term)
      		return;
	o_clear();
	tc_col = 0;
	tc_line = 0;
	for(i=0; i<scr_lns; i++)
	{
	        j = (i+roll)%scr_lns;
	        if(bp[j].len == 0)
			continue;
        	rel_move(tc_col,tc_line,0,i);
        	if(bp[j].mode&STANDOUT)
        		standoutput(bp[j].data, 0, bp[j].len, bp[j].sso,
				bp[j].eso);
        	else 
        		output(bp[j].data,bp[j].len);
        	tc_col+=bp[j].len;
        	if(tc_col >= t_columns)
		{
        		if(!automargins)
			{
                		tc_col -= t_columns;
                		tc_line++;
                		if(tc_line >= t_lines)
                			tc_line = t_lines - 1;
            		}
			else
              			tc_col = t_columns-1;
        	}
        	bp[j].mode &= ~(MODIFIED);
        	bp[j].oldlen = bp[j].len;
    	}
    	rel_move(tc_col, tc_line, cur_col, cur_ln);
    	docls = NA;
    	scrollcnt = 0;
    	oflush();
}

void	refresh(void)
{
	register	int	i,
				j;
    	register 	scrln	*bp = big_picture;

	if(dumb_term)
		return;
	if(num_in_buf() != 0)
		return;
	if((docls) || (abs(scrollcnt) >= (scr_lns-3)))
	{
        	redoscr();
        	return;
    	}
    	if(scrollcnt < 0)
	{
        	if(!scrollrevlen)
		{
        		redoscr();
            		return;
        	}
        	rel_move(tc_col,tc_line,0,0);
        	while(scrollcnt < 0)
		{
            		o_scrollrev();
            		scrollcnt++;
        	}
    	}
    	if(scrollcnt > 0)
	{
        	rel_move(tc_col,tc_line,0,t_lines-1);
        	while(scrollcnt > 0)
		{
            		ochar('\n');
            		scrollcnt--;
        	}
    	}
/* following statment has bug */
    	for(i=0; i<scr_lns; i++)
	{
        	j = (i + roll) % scr_lns;
        	if(bp[j].mode & MODIFIED && bp[j].smod < bp[j].len)
		{
            		bp[j].mode &= ~(MODIFIED);
            		if(bp[j].emod >= bp[j].len)
              			bp[j].emod = bp[j].len - 1;
            		rel_move(tc_col, tc_line, bp[j].smod, i);
            		if(bp[j].mode & STANDOUT)
              			standoutput(bp[j].data, bp[j].smod,
					bp[j].emod+1, bp[j].sso, bp[j].eso);
            		else 
              			output(&bp[j].data[bp[j].smod],
					bp[j].emod-bp[j].smod+1);
            		tc_col = bp[j].emod + 1;
/*            		if(tc_col >= t_columns)*/
			if(bp[j].len - bp[j].ansi >= t_columns)
			{
                		if(automargins)
				{
                    			tc_col -= t_columns;
                    			tc_line++;
                    			if(tc_line >= t_lines)
                      				tc_line = t_lines - 1;
                		}
				else
                  			tc_col = t_columns-1;
            		}
        	}
        	if(bp[j].oldlen > bp[j].len) 
		{
            		rel_move(tc_col, tc_line, bp[j].len,i);
            		o_cleol();
        	}
        	bp[j].oldlen = bp[j].len;
    	}
/* bug fixing bottom range */
    	rel_move(tc_col, tc_line, cur_col, cur_ln);
    	oflush() ;
}

void	clear(void)
{
	register	int	i;

	if(dumb_term)
	{
		outc('\n');
      		return;
	}
    	roll = 0;
    	docls = YEA;
    	downfrom = 0;
    	for(i=0; i<scr_lns; i++) 
	{
        	big_picture[i].mode = 0;
        	big_picture[i].len = 0;
        	big_picture[i].oldlen = 0;
    	}
    	move(0,0);
}

void	clrtoeol(void)
{
    	register	scrln	*slp;
	register	int	i;

    	if(dumb_term)
	{
		outc('\n');
      		return;
	}
    	standing = NA;
    	slp = &big_picture[((cur_ln + roll) % scr_lns)];
    	if(cur_col <= slp->sso)
      		slp->mode &= ~STANDOUT ;
    	if(cur_col > slp->oldlen) 
	{
        	for(i = slp->len; i<=cur_col; i++)
          		slp->data[i] = ' ';
    	}
    	slp->len = cur_col;
}

void	clrtobot(void)
{
    	register	int	i;

    	if(dumb_term)
      		return;
    	for(i = cur_ln; i < scr_lns; i++) 
	{
        	big_picture[(i + roll) % scr_lns].mode = 0;
        	big_picture[(i + roll) % scr_lns].len = 0;
		big_picture[(i + roll) % scr_lns].ansi = 0;
        	if(big_picture[(i + roll) % scr_lns].oldlen > 0)
          		big_picture[(i + roll) % scr_lns].oldlen = 300;
    	}
}

void 	clrstandout(void)
{
    	register 	int 	i;

    	if(dumb_term)
      		return;
    	for(i=0; i<scr_lns; i++)
      		big_picture[i].mode &= ~(STANDOUT);
}

void 	move(y,x)
int 	x, 
	y;
{
    	cur_col = x;
    	cur_ln = y;
}

void 	getyx(y,x)
int	*y,
	*x;
{
    	*y = cur_ln;
    	*x = cur_col;
}

void	outc(c)
register	uschar	c;
{
	static	int	ansi = NA,
			ansinum = 0;
	int	i;
	uschar	queue[STRLEN];

	if (c == KEY_ESC)
	{
		ansi = YEA;
		ansinum = 0;
		queue[ansinum++] = c;
		return;
	}
	if(!ansi)
		outch(c);
	else
	{
		if(ansinum == 1 && c != '[')
		{
			ansi = NA;
			outch(c);
			return;
		}
		if(strchr("[0123456789;", c) || isalpha(c))
		{
			queue[ansinum++] = c;
			if(isalpha(c))
			{
				if (HAS_SET(SET_ANSIMODE))
				{
					for(i = 0; i < ansinum; i++)
						outch(queue[i]);
				}
				ansi = NA;
				return;
			}
		}
		else
		{
			ansi = NA;
			outch(c);
			return;
		}
	}

	return;
}

void 	outch(c)
register	uschar	c;
{
	register 	scrln 	*slp;
	register	int	i;
    	static	int	ansi = NA, 
			ansinum = 0;

#ifndef BIT8
	c &= 0x7f ;
#endif
    	if(dumb_term) 
	{
#ifdef BIT8
		if(!isprint3(c))
#else
		if(!isprint(c))
#endif
		{ 
           		if(c == '\n') 
			{
                		ochar('\r');
                		ochar('\n');
                		return;
            		}
            		ochar('*');
            		return;
        	}
        	ochar(c);
        	return;
    	}
    	slp = &big_picture[((cur_ln + roll) % scr_lns)];
#ifdef BIT8
    	if(!isprint3(c))
#else
	if(!isprint(c))
#endif
	{
        	if(c == '\n' || c == '\r') 
		{ 
            		if(standing) 
			{
                		slp->eso = MYMAX(slp->eso, cur_col);
                		standing = NA;
            		}
            		if(cur_col - ansinum >= slp->len) 
			{
				for(i = cur_col; i > slp->len; i--)
					if(i - slp->ansi> 80)
						slp->data[i] = '\0';
					else
                    				slp->data[i] = ' ';
            		}
            		slp->len = cur_col;
			slp->ansi = ansinum;
            		cur_col = 0;
            		ansinum = 0;
            		ansi = NA;
            		if(cur_ln < scr_lns)
              			cur_ln++;
            		return;
        	}
        	c = '*';
    	}
       
    	if(cur_col >= slp->len) 
	{
        	for(i = slp->len; i < cur_col; i++)
          		if(i - slp->ansi < t_columns)
            			slp->data[i] = ' ';
          		else
            			slp->data[i] = '\0';
        	slp->data[cur_col] = '\0';
        	slp->len = cur_col + 1;
		slp->ansi = ansinum + 1;
    	}
    	if(slp->data[cur_col] != c) 
	{
        	if((slp->mode & MODIFIED) != MODIFIED)
          		slp->smod = (slp->emod = cur_col);
        	slp->mode |= MODIFIED;
        	if(cur_col > slp->emod)
          		slp->emod = cur_col;
        	if(cur_col < slp->smod)
          		slp->smod = cur_col;
    	}
    	if(c == KEY_ESC)
      		ansi = YEA;
    	if(ansi) 
	{
      		ansinum++;
      		if(isalpha(c))
        		ansi = NA;
    	}
    	slp->data[cur_col] = c;
    	cur_col++;
    	if(cur_col - ansinum >= scr_cols) 
	{
        	if(standing && slp->mode&STANDOUT) 
		{
            		standing = NA;
            		slp->eso = MYMAX(slp->eso,cur_col);
        	}
        	cur_col = 0;
        	ansinum = 0;
        	if(cur_ln < scr_lns)
          		cur_ln++;
    	}
}

void	outansi(str)
char	*str;
{
    	while(*str != '\0')  
	{
		if(*str == KEY_ESC) 
		{
           		outc('^');
	   		str++;
	   		continue;
	 	}
  	 	outc(*str++);
    	}
}

void outs(str)
register char *str ;
{
        while(*str != '\0')
        {
/*                if(*str == KEY_ESC && !HAS_SET(SET_ANSIMODE))
                {
                        for(; !isansi(*str); str++);
                        str++;
                }
                else*/
                        outc(*str++);
        }
}

void 	prints(std, va_alist)
int 	std;
va_dcl
{
	va_list	args;
	char 	buff[240],
		*fmt;

	va_start(args);
	fmt = va_arg(args, char *);
	vsprintf(buff, fmt, args);
	va_end(args);
	if(std)
		standout();
	outs(buff);
	if(std)
		standend();
	return;
}

void scroll(void)
{
    	if(dumb_term) 
	{
        	prints(NA, "\n");
        	return;
    	}
    	scrollcnt++;
    	roll = (roll + 1) % scr_lns;
    	move(scr_lns - 1, 0);
    	clrtoeol();
}

void rscroll(void)
{
    	if(dumb_term) 
	{
		outc('\n');
        	return;
    	}
    	scrollcnt--;
    	roll = (roll + (scr_lns - 1))% scr_lns;
    	move(0,0);
    	clrtoeol();
}

void 	standout(void)
{
    	register 	scrln	*slp;

    	if(dumb_term  || !strtstandoutlen)
      		return;
    	if(!standing) 
	{
        	slp = &big_picture[((cur_ln + roll) % scr_lns)];
        	standing = YEA;
        	slp->sso = cur_col;
        	slp->eso = cur_col;
        	slp->mode |= STANDOUT;
    	}
}

void 	standend(void)
{
    	register	scrln	*slp;

    	if(dumb_term || !strtstandoutlen)
      		return;
    	if(standing) 
	{
        	slp = &big_picture[((cur_ln+roll)%scr_lns)];
        	standing= NA;
        	slp->eso = MYMAX(slp->eso,cur_col);
    	}
}

#ifdef BIT8
int 	isprint2(ch)
char 	ch;
{
   	return(ch & 0x80 ? 1 : isprint(ch));
}

int 	isprint3(ch)
char 	ch;
{
   	return((ch & 0x80 || ch == KEY_ESC) ? 1 : isprint(ch));
}
#endif
