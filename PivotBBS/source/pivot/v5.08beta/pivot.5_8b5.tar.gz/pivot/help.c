/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)help.c   5.04 3/19/95 (C) 1993 University of \
NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include "bbs.h"


hlpinfo BoardSelect[] = {
     2,  0, HIGH,   0,          "��ܰQ�װϨ�U�e��  Board Select Menu Help Screen\n",
    -1, -1,  LOW,   0,          "-------------------------------------------------------\n",
    -1, -1,  LOW,   0,          "p   k       Up      �W�@��         Previous Board\n",
    -1, -1,  LOW,   0,          "n   j       Down    �U�@��         Next Board\n",
    -1, -1,  LOW,   0,          "P   CTRL(B) PgUp    �W�@��         Previous Page\n",
    -1, -1,  LOW,   0,          "N   CTRL(F) PgDn    �U�@��         Next Page\n",
    -1, -1,  LOW,   0,          "$           End     �̥���         Last Board\n",
    -1, -1,  LOW,   0,          "s   S       Tab     �ֿ�Q�װ�     Fast Select Board\n",
    -1, -1,  LOW,   0,          "!           Home    �Ĥ@�ӰQ�װ�   First Board\n",
    -1, -1,  LOW,   0,          "r   Enter   Right   ��ܥ��Q�װ�   Select Current Board\n",
    -1, -1,  LOW,   0,          "i                   ²��           About this Board\n",
    -1, -1,  LOW,   0,          "q   e       Left    ���}           Exit\n",
    -1, -1,  LOW,   0,          "f                   ���Y�Ь�Ū�L   Full Visit Board\n",
    -1, -1,  LOW, PERM_LOCALBM, "E                   �s��²�����   Edit Board Information\n",
    -1, -1,  LOW,   0,          "v                   �ֳt�Ь�Ū�L   Quick Visit Board\n",
    -1, -1,  LOW,   0,          "x                   �\\Ū��ذ�     Read Current Board FAQ\n",
    -1, -1,  LOW,   0,          "y   Y               ����Q�װ���� Yank IN/OUT Boards\n",
    -1, -1,  LOW,   0,          "z   Z               �����Q�ת�     Zap current Board\n",
    -1, -1,  LOW,   0,          "##<num>             ��� num�Ӫ�   Go to the <num> Board\n",
    -1, -1,  LOW,   0,          NULL,
};

hlpinfo MailRead[] = {
     3,  0, HIGH, 0,           "�H��Ū����U�e�� Mail Read Menu Help Screen\n",
     4,  0, HIGH, 0,           "------------- ���ʩR�O      Movement Commands\n",
    -1, -1,  LOW, 0,           "p             �W�@��        Previous Message\n",
    -1, -1,  LOW, 0,           "n             �U�@��        Next Message\n",
    -1, -1,  LOW, 0,           "P             �W�@��        Previous Page\n",
    -1, -1,  LOW, 0,           "N             �U�@��        Next Page\n",
    -1, -1,  LOW, 0,           "## <cr>       ��##��        Goto Message ##\n",
    -1, -1,  LOW, 0,           "$             �̥���        Goto Last Message\n",
    -1, -1, HIGH, 0,           "------------- �䥦�R�O      Miscellaneous Commands\n",
    -1, -1,  LOW, 0,           "r             Ū�H          Read a Message\n",
    -1, -1,  LOW, 0,           "R             �^�H          Reply to Sender\n",
    -1, -1,  LOW, PERM_FORWARD,"F             �H�^�ۤv�b��  Forward Message to your Internet Box\n",
    -1, -1,  LOW, 0,           "d             �R���ثe�H��  Delete Current Message\n",
    -1, -1,  LOW, 0,           "D             �R�����w�d��  Delete Range of Messages\n",
    -1, -1,  LOW, 0,           "m             �קK�d��R��  Mark/Unmark message for non-deletion\n",
    -1, -1,  LOW, 0,           "CTRL-L        �����        Redraw Screen\n",
    -1, -1,  LOW, 0,           "h             ���e��        This Help Screen\n",
    -1, -1,  LOW, 0,           "e             �^���        EXIT Read Menu\n",
    -1, -1,  LOW, 0,           "-/+           ���e����j�M  Search Matched UserId and Title\n",
    -1, -1,  LOW, 0,           NULL,
};

hlpinfo MainRead[] = {
     0,  0, HIGH, 0,           "ŪPost���� Main Read Menu Help Screen\n",
    -1, -1,  LOW, 0,           "[1m---------- ���ʩR�O      Movement Commands[m\n",
    -1, -1,  LOW, 0,           "p/n        �W/�U�@��     Previous/Next Message\n",
    -1, -1,  LOW, 0,           "P/N        �W/�U�@��     Previous/Next Page\n",
    -1, -1,  LOW, 0,           "## <cr>    ��##��        Goto Message ##.  $   �̥���     Goto Last Message\n",
    -1, -1,  LOW, 0,           "[1m---------- �䥦�R�O      Miscellaneous Commands[m\n",
    -1, -1,  LOW, 0,           "r          Ū�����        O   �ݧ벼���G\n",
    -1, -1,  LOW, PERM_POST,   "CTRL-P     �i�K            R   �^�T\n",
    -1, -1,  LOW, PERM_POST,   "x          ��K            T   ���D��\n",
    -1, -1,  LOW, PERM_BASIC,  "d          �R��\n",
    -1, -1,  LOW, PERM_BMS,    "D          �R���d��\n",
    -1, -1,  LOW, PERM_BMS,    "m          ���R���Х�\n",
    -1, -1,  LOW, PERM_BMS,    "A          �}�벼�c\n",
    -1, -1,  LOW, PERM_POST,   "M          �h����i\n",
    -1, -1,  LOW, PERM_SYSOP,  "E          ���g\n",
    -1, -1,  LOW, 0,           "s          ��Q�װ�\n",
    -1, -1,  LOW, 0,           "S          ��ФU�s��i\n",
    -1, -1,  LOW, PERM_FORWARD,"F          �H�^�ۤw�b��\n",
    -1, -1,  LOW, 0,           "CTRL-L     �ù���ø\n",
    -1, -1,  LOW, 0,           "h          �����U�e��\n",
    -1, -1,  LOW, 0,           "z          �Ь���Ū\n",
    -1, -1,  LOW, 0,           "e          �^�D���        TAB �ݥثe�Ҧb���� FAQ\n",
    -1, -1,  LOW, 0,           "-/+        ���e����j�M\n",
    -1, -1,  LOW, 0, NULL,
};

hlpinfo GroupRead[] = {
     7,  0, HIGH,           0,  "   (G)roup �� (K)ind �ϥΫ���  ����\n",
    -1, -1,  LOW,           0,  "--------------------------------------\n",
    -1, -1,  LOW,           0,  "r  Enter   ��h��ЩҦb�� Group\n",
    -1, -1,  LOW, PERM_BOARDS,  "a          �W�[�Q�׸s\n",
    -1, -1,  LOW, PERM_BOARDS,  "m          ���Q�׸s���\n",
    -1, -1,  LOW, PERM_BOARDS,  "d          �R���Q�׸s\n",
    -1, -1,  LOW,           0,  "h          �����U�e��\n",
    -1, -1,  LOW,           0,  "---------------------------------------\n",
    -1, -1,  LOW,           0,  NULL,
};

int do_the_help(p)
hlpinfo *p ;
{
    move(0,0) ;
    clrtobot() ;
    move(p->x,p->y) ;
    while(p->text) {
        if(p->x != -1)
          move(p->x, p->y) ;
        if(HAS_PERM(p->level))
          prints((p->highlight)? YEA : NA,"%s",p->text) ;
        p++ ;
    }
    return 0;
}


void cmds_help(cmd,cmdtab)
int cmd;
cmds *cmdtab;
{   int i, total;
    char buffer[81];

    move(3,0);
    total = cmdtab[0].level;
    clrtobot();
/*
#ifdef	LINUX
    prints(YEA, "  %-15s%-20s%-41s\n", cmdtab[0].cmdname,
#else*/
    prints(YEA, "[1;32;44m  %-15s%-20s%-41s[m\n", cmdtab[0].cmdname,
/*#endif*/
            cmdtab[0].ctext,"�� CTRL-T �����۰���� HELP �\\��");

    for (i=1; i<=total; i++)
        if (HAS_PERM(cmdtab[i].level))
           prints(NA, "  ([1;32m%c[m)%-12s%-20s%s\n",*(cmdtab[i].cmdname),
                  cmdtab[i].cmdname+1,cmdtab[i].ctext,cmdtab[i].etext);
}

Help()
{
    cmds_help('h', cmdlist);
}

p_help()
{
    cmds_help('h', postlist);
}

m_help()
{
    cmds_help('h', maillist);
}

#ifdef LEVER
l_help()
{
    cmds_help('h', leverlist);
}
#endif

#ifdef FILES
f_help()
{
    cmds_help('h', filelist);
}
#endif

x_help()
{
    cmds_help('h', xyzlist);
}

t_help()
{
    cmds_help('h', talklist);
}

a_help()
{
    cmds_help('h', maintlist) ;
}

mainreadhelp(ent,fileinfo,direct)
int ent;
fhd *fileinfo;
char *direct;
{
    clear() ;
    do_the_help(MainRead) ;
    pressreturn() ;
    clear() ;
    return FULLUPDATE ;
}

mailreadhelp(ent,fileinfo,direct)
int ent;
mhd *fileinfo;
char *direct;
{
    clear() ;
    do_the_help(MailRead) ;
    pressreturn() ;
    clear() ;
    return FULLUPDATE ;
}

group_read_help(ent,fileinfo,direct)
int ent;
ghd *fileinfo;
char *direct;
{
        clear();
        do_the_help(GroupRead);
        pressreturn();
        clear();
        return FULLUPDATE;
}

boardhelp()
{
    clear();
    do_the_help(BoardSelect);
    pressreturn();
    clear();
    return FULLUPDATE;
}
