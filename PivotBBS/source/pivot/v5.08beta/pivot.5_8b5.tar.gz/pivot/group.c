/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

static  char    sccsid[] = "@(#)group.c  5.04 3/19/95 (C) 1993 University of \
NCHU, Computer Center and Tseng Kuo-Feng";

#include "bbs.h"

int	gain_group(void)
{
	ghd	gcache[MAXGROUPS];
	int	i = 1,
		j,
		size,
		fd,
		num;
	char	buf[3];

	move(0,0);
	clrtobot();
	prints(YEA, "�]�w Group �s��\n");
	size = sizeof(ghd);

	if ((fd = open(GROUPS, O_RDONLY, 0)) == -1)
		return 0;

	while (read(fd, (char *)&gcache[i], size) == size)
	{
		move(i%6+2, i/6*19);
		prints(NA, "(%d) %s", i, gcache[i].filename);
		i++;
	}

	while(1)
	{
		getdata(10, 0, "��J�Q�׸s�s��: ", buf, 3, DOECHO, YEA);
		num = atoi(buf);
		if(num == 0)
			return 0;
		if (num > 0 && num < i)
			return gcache[num].groupnum;
		move(11, 0);
		prints(NA, "�Q�׸s�s�����~\n");
	}
}

int	group_boards(func, group, yank)
int	(*func)(),
	group,
	yank;
{
	int	i;

	for(i = 0; i < numboards; i++)
	{
		if (bcache[i].filename[0] != ' ')
		{
			if (((group > 0) && (bcache[i].group != group))
				|| ((bcache[i].accessed & ZAPPED) && !yank))
				continue;
			if ((*func)(&bcache[i]) == QUIT)
				return QUIT;
		}
	}
	return 0;
}

int	gain_boards(void)
{
	int	i;

	if (numboards < 0)
	{
        	numboards = 0;
        	apply_record(BOARDS,boardcache,sizeof(bhd));
	}

	return 0;
}

int	getgnum(gname)
char	*gname;
{
	ghd	buf;

	return search_record(GROUPS, (char *)&buf, sizeof(ghd), cmpgroup,
		(int)gname);
}

int	getbnum(bname)
char	*bname;
{
	int	i;

	if (numboards < 0)
	{
        	numboards = 0;
        	apply_record(BOARDS,boardcache,sizeof(bhd));
	}

	for(i = 0; i < numboards; i++)
	{
      		if (!strncmpi(bname,bcache[i].filename,
			sizeof(bcache[i].filename)))
		{
        		return i+1;
		}
	}
	return 0;
}

int	cmpgroup(first, second)
int	first;
ghd	*second;
{
	return !strcmpi((char *)first, second->filename);
}

int	groupcheck(fptr)
ghd	*fptr;
{
	return strcmp(fptr->filename,genbuf);
}

one_key group_comms[] =
{
	'r',		group_read,
	'\n',		group_read,
	'\r',		group_read,
	' ',		group_read,
	KEY_RIGHT,	group_read,
	'h',		group_read_help,
	'a',		group_add,
	'd',		group_delete,
	'm',		group_modify,
	'\0',		NULL,
};

void	groupdoent(num, ent)
int	num;
ghd	*ent;
{
	static	char	buf[512];

	prints(NA, " %4d  %-15.15s %-54.54s\n", num, ent->filename,
		ent->title);
}

int	Group(void)
{
	int	run;

	changemode(GROUP, NA);

	while(1)
	{
		run = i_read(GROUPS, grouptitle, groupdoent, &group_comms[0],
			'Z', ASK_POST_DEFAULT, 'n', get_num_records,
			get_records);

		if(run != REDOIREAD)
			break;
	}
	changemode(MPOST, NA);
	return 0;
}

int	group_read(ent, info, direct)
int	ent;
ghd	*info;
char	*direct;
{
	choose_board(info->groupnum, !HAS_SET(SET_GRPYANKOUT));

	return REDOIREAD;
}

int	group_add(ent, info, direct)
int	ent;
ghd	*info;
char	*direct;
{
	if(!HAS_PERM(PERM_BOARDS))
		return 0;
	m_groupadd();

	return FULLUPDATE;
}

int	group_delete(ent, info, direct)
int	ent;
ghd	*info;
char	*direct;
{
        if(!HAS_PERM(PERM_BOARDS))
                return 0;
	m_groupdelete(info->filename);

	return FULLUPDATE;
}

int	group_modify(ent, info, direct)
int	ent;
ghd	*info;
char	*direct;
{
        if(!HAS_PERM(PERM_BOARDS))
                return 0;
	modify_group(info->filename);

        return FULLUPDATE;
}

void	grouptitle()
{
        clrtobot();
        menu_draw("[�H��B�z]", boardmargin);
        prints(NA, "%-18.18s%-10.10s%-28.28s%-22.22s\n", "[��,e]�^�W�@�e��",
                "[h]�D�U", "[��,r,<cr>]��ܥثe�Q�׸s",
                "[��,��]�W,�U�@�ϰQ�׸s");

        prints(YEA, "[1;32;44m �s��  %-15.15s %-55.55s[m\n","�Q�׸s�W��","�Q�׸s����");
	refresh();
}

int	Kind(void)
{
	int	run;

        changemode(KIND, NA);
	while(1)
	{
		run = i_read(GROUPS, grouptitle, groupdoent, &group_comms[0],
			'Z', ASK_KIND_DEFAULT, 'z', get_num_records,
			get_records);

		if(run != REDOIREAD)
			break;
	}
        changemode(MPOST, NA);

        return 0;
}

int	m_groupadd(void)
{
	ghd	newgroup;
	char	*s,
		buf[80],
		num[5];
	int	ans = NA,
		numgroups;
        struct	stat	stbuf;   
 
	clear();

	changemode(GCREATE, NA);

	stat(GROUPS, &stbuf);
	numgroups = (stbuf.st_size)/sizeof(ghd);

	bzero(&newgroup, sizeof(newgroup));
	prints(NA, "�إ߰Q�פ���:");
	while (1)
	{
		getdata(3,0,"Enter Group Name �W��(use single word): ",
			newgroup.filename, 18, DOECHO, YEA);
		if (!stricmp(newgroup.filename, "new") ||
			!stricmp(newgroup.filename, "quit"))
			return -1;
		if (checkid(newgroup.filename))
		{
			prints(NA, "���X�k���Q�װϦW��\n");
			continue;
		}
		if (getgnum(newgroup.filename))
		{
			prints(NA, "Error: Bad Group Name\n");
			continue;
		}
		break;
	}
	getdata(4, 0, "Enter Group description:(²��) ", newgroup.title, 60,
		DOECHO, YEA);
	time(&newgroup.groupnum);

	if (append_record(GROUPS, (char *)&newgroup, sizeof(newgroup)) == -1)
	{
		pressreturn();
		clear();
		changemode(MADMIN, NA);

		return -1;
	}

	numgroups = -1;
	prints(NA, "\nNew GROUPS Added(�s�W���i��)\n");
	pressreturn();

	changemode(MADMIN, NA);

	clear();
	return 0;
}

int	modify_group(gname)
char	*gname;
{
	int	pos,
		ans;
	ghd	fh,
		newfh;

	pos = search_record(GROUPS, (char *)&fh, sizeof(fh), cmpgroup,
		(int)gname);
	if (!pos)
	{
		move(t_lines-1, 0);
		prints(NA, "Invalid Board Name.. press a key to continue..");
		egetch();
		clear();
		return FULLUPDATE;
	}
	move(3,0);
	clrtobot();
	bcopy(&fh, &newfh, sizeof(newfh));
	prints(NA, "Group Name:        %s\n", fh.filename);
	prints(NA, "Group Description: %s\n", fh.title);
	prints(NA, "Group Series:      %d\n", fh.groupnum);

	for(;;)
	{
		getdata(11,0, "New Group Name:         ", genbuf, 18, DOECHO,
			YEA);
		if (*genbuf != 0)
		{
			ghd dh;

			if (search_record(GROUPS, (char *)&dh, sizeof(dh),
				cmpgroup, (int)genbuf))
			{
				move(3,0);
				prints(NA, "Error! Board already exists\n");
				bell(1);
				move(11,0);
				clrtobot();
				continue;
			}
			strncpy(newfh.filename, genbuf, sizeof(newfh.filename));
		}
		break;
	}

	getdata(12,0, "Nee Group Description:  ", genbuf, 60, DOECHO, YEA);
	if (*genbuf != 0)
		strncpy(newfh.title, genbuf, sizeof(newfh.title));

	ans = getans(19,0, "Apply these changes? (Yes or No) [N]: ", 'n');
	if (ans == 'y')
		substitute_record(GROUPS, (char *)&newfh, sizeof(newfh), pos);

	return FULLUPDATE;
}

int	m_chgroup(void)
{
	char	gname[STRLEN];

	move(0, 0);
	clrtobot();
	prints(YEA, "���Q�׸s�]�w");

	move(1,0);
	getdata(1, 0, "�Q�׸s�W��: ", gname, STRLEN, DOECHO, YEA);
	if (*gname == '\0')
	{
		move(2,0);
		prints(NA, "���X�W�w���Q�׸s�W��");
		pressreturn();
		clear();
		return;
	}
	modify_group(gname);
}

int	m_groupdelete(gname)
char	*gname;
{
        ghd	ginfo;
        int	gid,
		ans;
	char	buff[STRLEN];

        gid = getgnum(gname);

        if (get_record(GROUPS, (char *)&ginfo, sizeof(ginfo), gid) == -1)
	{
                move(t_lines-1,0);
                prints(NA, "�Q�׸s %s ���s�b.\n", gname);
		pressreturn();
                clear();
                return FULLUPDATE;
        }

	sprintf(buff, "�R���Q�׸s '%s' (Y/N)? [N]: ", ginfo.filename);
        ans = getans(t_lines-1, 0, buff, 'n');

        if (ans != 'y')
	{
                move(t_lines-1,0);
		clrtoeol();
		prints(YEA, "[[1;32;44m%s                      [[m",
		"                     ...���R���Q�׸s..�Ы����N�����}...");
                return 0;
        }
        ans = delete_file(GROUPS, sizeof(ginfo), gid, groupcheck);
        move(t_lines-1, 0);
	if (!ans) 
		prints(YEA, "[[1;32;44m%s                      [[m",
		"                     ...�Q�׸s�w�g�R��..�Ы����N�����}...");
	else
		prints(YEA, "[[1;32;44m%s                      [[m",
		"                     ...�R���Q�׸s����..�Ы����N�����}...");
	egetch();
        move(t_lines-1, 0);
	clrtoeol();
}
