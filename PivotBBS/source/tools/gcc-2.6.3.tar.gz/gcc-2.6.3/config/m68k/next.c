/* next.c:  Functions for NeXT as target machine for GNU C compiler.  */

/* Note that the include below means that we can't debug routines in
   m68k.c when running on a COFF system.  */

#include "m68k/m68k.c"
#include "nextstep.c"
