#include "m68k/sun3.h"

/* LINK_SPEC is needed only for Sunos 4.  */

#undef LINK_SPEC
