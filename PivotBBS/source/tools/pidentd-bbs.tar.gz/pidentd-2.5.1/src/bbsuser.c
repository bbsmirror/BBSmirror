/*
    PIVOT Bulletin Board System for pidentd-2.5.1

    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    sccsid[] = "@(#)bbsuser.c   0.1 6/14/95 (C) 1993 University \
of NCHU, Computer Center";
#endif

#define	KERNEL	/* if not define KERNEL, struct file can not be used */

#include <sys/file.h>
#include <sys/user.h>
#include <sys/proc.h>

#undef	KERNEL 	/* remember to remove it */

#include <sys/mbuf.h>
#include <sys/socket.h>
#include <sys/socketvar.h>
#include <sys/syslog.h>
#include <net/route.h>
#include <netinet/in.h>
#include <netinet/in_pcb.h>
#include <kvm.h>
#include <pwd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>

#include "bbsuser.h"

UTMPCACHE	*utmpshm;
extern	kvm_t	*kd;
extern	char	*pw_name;
extern	getbuf();

int	compare_file(fptr)
struct	file	*fptr;
{
	struct	file	fp;
}

int	comp_file(fptr)
struct	file	*fptr;
{
	struct	file	fle;

	printf("comp_file\n");return 0;
	if (kvm_read(kd, fptr, (char *)&fle, sizeof(fle)))
	{
		syslog(LOG_INFO, "cannot read file structure %#x", fptr);

		return 0;
	}
	else
	{
		if (fle.f_type == DTYPE_SOCKET)
			return	proc_socket((caddr_t)fle.f_data);
	}
	return 0;
}

int	proc_socket(sa)
caddr_t	sa;
{
	struct	socket	s;
	struct	inpcb	inp;
	extern	int	lport;

	if (sa == NULL)
		return 0;
	if (kvm_read(kd, (unsigned long)sa, (char *)&s, sizeof(s)))
	{
		syslog(LOG_INFO, "cannot read socket address");
		return 0;
	}
	if (!s.so_type)
	{
		syslog(LOG_INFO, "no socket type");
		return 0;
	}
	if (kvm_read(kd, s.so_pcb, (char *)&inp, sizeof(inp))
		|| (struct socket *)sa != inp.inp_socket)
	{
		syslog(LOG_INFO, "cannot read inpcb at %#x", s.so_pcb);
		return 0;
	}
	if (inp.inp_lport == lport)
		return 1;
	return 0;
}

int	comp_port(uentp)
usinfo	*uentp;
{
	int	nf;
	struct	file	**uf;
	struct	proc	*cproc;
	struct	user	*user;
	static	struct	file	**xuf = NULL;

	if (kill(uentp->cpid, 0) == -1)
	{
		return 0;
	}

	if (uentp->cpid <= 0)
	{
		return 0;
	}

	if ((cproc = kvm_getproc(kd, uentp->cpid)) == NULL)
	{
		return 0;
	}

	if ((user = kvm_getu(kd, cproc)) == NULL)
	{
		return 0;
	}

	for (nf = 0; nf < NOFILE_IN_U; nf++)
	{
		if (comp_file(&user->u_ofile_arr[nf]))
		{
			strcpy(pw_name, uentp->userid);
			return	QUIT;
		}
	}

	return 0;
}

UTMPCACHE	*attach_shm(defaultkey, shmsize)
int     defaultkey,
	shmsize;
{
	UTMPCACHE	*shmptr;
	int	shmkey,
		shmid;

	shmkey = defaultkey;
	shmid = shmget(shmkey, 0, 0);
	if (shmid < 0)
	{
		syslog(LOG_INFO, "shmget error");
		return NULL;
	}
	shmptr = (UTMPCACHE *)shmat(shmid, NULL, 0);
	if (shmptr == (UTMPCACHE *)-1)
	{
		syslog(LOG_INFO, "shmat error");
		return NULL;
	}
	return shmptr;
}

int	resolve_utmp()
{
	if (utmpshm == NULL)
	{
		utmpshm = attach_shm(UTMP_SHMKEY, sizeof(UTMPCACHE));
	}
	if (utmpshm == NULL)
		return 0;
	return 1;
}

int	apply_ulist()
{
	int	i;
	usinfo	*info;

	if (!resolve_utmp())
	{
		printf("not shm\n");
		return 0;
	}

	for (i = 0; i < UTMP_SIZE; i++)
	{
		if (comp_port(&(utmpshm->utc[i])) == QUIT)
			return	1;
	}

	return	0;
}
