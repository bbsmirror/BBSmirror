bbsnnrp -v -a 1000 -r pbbs.chpi.edu.tw -p 119 news.csie.nctu.edu.tw active   
bbsnnrp -v -a 1000 -r pbbs.chpi.edu.tw -p 119 news.csie.nctu.edu.tw active.cmsg   

