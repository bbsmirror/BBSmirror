/*************************************************************************
 * download.c --- download files					 *
 *	      by Samson Chen, Apr 9, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"

static char rcsid[]="$Id: download.c,v 1.2 1994/05/14 00:24:19 pbbs Exp pbbs $";



/*
	download --- download files
*/
download(fd)
	int fd;
{
	int n;
	char part_name[25];

	if(debug_mode) printf("(download.c)toggles now %d\n", toggles);

	if( toggles==0 )
	{
		display_msg(fd, NO_TAGGED_FILE);
		return;
	}

	for(n=0; n<toggles; n++)
	{
		split_filename(tagged[n], part_name);
		update_act(8, part_name);
		send_file(fd, tagged[n]);
	}

	display_msg(fd, "\n\n");

	toggles=0;

}
/*end of download*/
