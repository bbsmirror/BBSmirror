/*************************************************************************
 * areaset.c --- set up mail areas					 *
 *	      by Samson Chen, July 7, 1995				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"
#include "dbf.h"

static char rcsid[]="$Id: areaset.c,v 1.5 1995/11/09 08:23:47 pbbs Exp pbbs $";


char inter_buf[IBUF_SIZE];


/*
	areas_set --- (as the name)
*/
areas_set(fd)
	int fd;
{
      int set_mode;
      char answer[80];
      char line[300];
      int rlen;
      char protocol;
      char crlf[3];
      char new_post_check_reseted=FALSE;
      char msg_lastread_reseted=FALSE;

      do
      {
	/***************/
	/*change prompt*/
	/***************/

	sprintf(line, "%s", LIST_MODE_TITLE);
	change_intr_prompt(fd, line);

	/*************************/
	/*assemble INTRSEL buffer*/
	/*************************/

	sprintf(crlf, "%c%c", 13, 10);

	inter_buf[0]=0;
	strcpy(inter_buf, "1!1");
	strcat(inter_buf, crlf);
	strcat(inter_buf, AREA_SET_1);
	strcat(inter_buf, crlf);
	strcat(inter_buf, " ");
	strcat(inter_buf, crlf);

	strcat(inter_buf, "2");
	strcat(inter_buf, crlf);
	if( user_use_set_area(fd) )
	  strcat(inter_buf, AREA_SET_2_A);
	else
	  strcat(inter_buf, AREA_SET_2_B);
	strcat(inter_buf, crlf);
	strcat(inter_buf, " ");
	strcat(inter_buf, crlf);

	strcat(inter_buf, "3");
	strcat(inter_buf, crlf);
	strcat(inter_buf, AREA_SET_3);
	strcat(inter_buf, crlf);
	strcat(inter_buf, " ");
	strcat(inter_buf, crlf);

	strcat(inter_buf, "4");
	strcat(inter_buf, crlf);
	strcat(inter_buf, AREA_SET_4);
	strcat(inter_buf, crlf);
	strcat(inter_buf, " ");
	strcat(inter_buf, crlf);

	strcat(inter_buf, "5");
	strcat(inter_buf, crlf);
	if( new_post_check_reseted )
	  strcat(inter_buf, AREA_SET_5_B);
	else
	  strcat(inter_buf, AREA_SET_5_A);
	strcat(inter_buf, crlf);
	strcat(inter_buf, " ");
	strcat(inter_buf, crlf);

	strcat(inter_buf, "6");
	strcat(inter_buf, crlf);
	if( msg_lastread_reseted )
	  strcat(inter_buf, AREA_SET_6_B);
	else
	  strcat(inter_buf, AREA_SET_6_A);
	strcat(inter_buf, crlf);
	strcat(inter_buf, " ");
	strcat(inter_buf, crlf);

	/*send reqest*/
	send_mpf(fd, inter_buf, strlen(inter_buf), INTRSEL);
	do
	{
	  read_mpf(fd, answer, &rlen, &protocol, FALSE);
	  if( protocol != INTRSEL )
	  {
		do_log(8, "%s protocol_stat_err with protocol code %d at area_set", user_name, protocol);
		protocol_stat_err(fd);
	  }

	  answer[rlen]=0;
	  strip_nl(answer);

	  if(answer[0]=='q')
	    break;

	  set_mode=atoi(answer);

	  /*check list mode permission*/
	  if(set_mode>0 && set_mode<=6)
		break;

	  send_mpf(fd, "SAME_BUFFER", 11, INTRSEL);

	}while(TRUE);

	if( answer[0]=='q' )
	  break;

	/***********************************************************/

	display_msg(fd, "{#c#}");

	switch( set_mode )
	{

	/***********************************************************/

	case 1: /*setup areas*/

		if(debug_mode) printf("(areaset.c)case 1\n");

		set_up_area(fd);

		break;

	/***********************************************************/

	case 2: /*switch setup areas*/

		if(debug_mode) printf("(areaset.c)case 2\n");

		switch_area_set(fd);

		break;

	/***********************************************************/

	case 3: /*Blue Wave download*/

		if(debug_mode) printf("(areaset.c)case 3\n");

		generate_blue_wave(fd);

		update_act(1, NULL);

		break;

	/***********************************************************/

	case 4: /*Blue Wave upload*/

		if(debug_mode) printf("(areaset.c)case 4\n");

		upload_blue_wave(fd);

		update_act(1, NULL);

		break;

	/***********************************************************/

	case 5: /*reset new post check flag*/

		if(debug_mode) printf("(areaset.c)case 5\n");

		if( user_use_set_area(fd) )
			reset_userset_new_post_check_flag(fd);
		else
			reset_new_post_check_flag(fd);

		new_post_check_reseted=TRUE;

		break;
	/***********************************************************/

	case 6: /*reset lastread pointer*/

		if(debug_mode) printf("(areaset.c)case 6\n");

		reset_set_lastread(fd);

		msg_lastread_reseted=TRUE;

		break;
	/***********************************************************/

	}/*end switch*/

      }while(TRUE);
}
/*end of area_set*/



/*
	switch_area_set --- switch area set mode

	use bit-1 of user_set[0], it is a mask bit, that is,
	0: means do not use set
	1: menas use set
*/
switch_area_set(fd)
	int fd;
{
	struct udb urec;
	char line[256];

	get_user_data(&urec, user_uid);

	if( (urec.user_set[0] & 2)==0 )
	{
	  sprintf(line, "%s/%d.%s", USER_PREFERENCE, user_uid, GROUP_LIST);
	  if( !file_exist(line) )
	  {
	    display_msg(fd, SET_AREA_FIRST);
	    suspend(fd);
	    return;
	  }

	  /* off -> on */
	}
	/*
	else on-> off
	*/

	urec.user_set[0] ^= 2;

	set_user_data(&urec, user_uid);
}
/*end of switch_area_set*/



/*
	get if user use set area
*/
user_use_set_area(fd)
	int fd;
/*
	return:
		TRUE:	yes! user use set area
		FALSE:	no!
*/
{
	struct udb urec;

	get_user_data(&urec, user_uid);

	if( (urec.user_set[0] & 2)==0 )
	  return(FALSE);
	else
	  return(TRUE);
}
/*end of user_use_set_area*/



/*
	turn set area off
*/
off_set_area(fd)
	int fd;
{
	struct udb urec;

	get_user_data(&urec, user_uid);

	if( (urec.user_set[0] & 2)==0 )
	  return;

	urec.user_set[0] ^= 2;

	set_user_data(&urec, user_uid);
}
/*end of off_set_area*/



/*
	turn set area on
*/
on_set_area(fd)
	int fd;
{
	char line[255];
	struct udb urec;

	sprintf(line, "%s/%d.%s", USER_PREFERENCE, user_uid, GROUP_LIST);
	if( !file_exist(line) )
	{
	  off_set_area(fd);
	  return;
	}

	get_user_data(&urec, user_uid);

	if( (urec.user_set[0] & 2)!=0 )
	  return;

	urec.user_set[0] ^= 2;

	set_user_data(&urec, user_uid);
}
/*end of off_set_area*/
