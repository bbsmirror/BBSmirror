/*************************************************************************
 * act.c ---  putmp action record functions				 *
 *	      by Samson Chen, May 14, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "dbf.h"
#include "global.h"


/*
	action stat code :
	
		1  : main menu
		2  : <unused>
		3  : blue wave
		4  : tag files
		5  : bulletin menu
		6  : read mail
		7  : write mail		: cannot interrupt
		8  : download		: cannot interrupt
		9  : upload		: cannot interrupt
		10 : chatroom		: cannot interrupt
		11 : talk		: cannot interrupt
		12 : internet		: cannot interrupt
		13 : list users		
		14 : write message
*/

/*
	update_act --- update putmp action stat
*/
update_act(stat_code, info)
	unsigned char stat_code;
	char *info;	/*stat information*/
{
	struct putmp purec;

	if( debug_mode ) printf("(act.c)update act code %d for %s\n", stat_code, user_name);

	if( user_uid==0 ) return;

	get_putmp(&purec, putmp_rec);

	if( !purec.active )
	  purec.active=TRUE;

	purec.act_stat=stat_code;

	switch(stat_code)
	{
	case 4:
	case 5:
	case 6:
	case 7:
	case 8:
	case 10:
	case 12:
	case 13:
	case 14:
		nstrcpy(purec.act_info, info, 20);
		break;
	}

	set_putmp(&purec, putmp_rec);
}
/*end of update_act*/



/*
	descript_stat --- convert stat code to readable text
*/
descript_stat(buf, len, stat_code, stat_info)
	char *buf;
	int len;	/*max len of buf*/
	unsigned char stat_code;
	char *stat_info;
{
	char line[128];
	char info[36];

	if( debug_mode ) printf("(act.c)descript stat\n");

	if( stat_code>=4 && stat_code<=8 || stat_code >=13 && stat_code<=14 )
	{
	  /*
		4  : tag files
		5  : bulletin menu
		6  : read mail
		7  : write mail		: cannot interrupt
		8  : download		: cannot interrupt
                10 : chatroom           : cannot interrupt
                11 : talk               : cannot interrupt 
		12 : internet		: cannot interrupt
		13 : list users		
		14 : write message

	 	(info) only for CO_SYSOP and SYSOP
	  */
	  if( user_level>=CO_SYSOP_LEVEL )
	  {
	    info[0]=':';
	    nstrcpy(info+1, stat_info, 20);
	  }
	  else
	    info[0]=0;
	}
	else
	  nstrcpy(info, stat_info, 20);

	switch(stat_code)
	{
	case 1:
		nstrcpy(line, MAIN_MENU_STAT, 128);
		break;
	case 2:
		strcpy(line, "<unused 2>");
		break;
	case 3:
		nstrcpy(line, USE_BLUE_WAVE, 128);
		break;
	case 4:
		sprintf(line, "%s%s", TAG_FILES, info);
		break;
	case 5:
		sprintf(line, "%s%s", BULLETIN_STAT, info);
		break;
	case 6:
		sprintf(line, "%s%s", READ_MAIL_STAT, info);
		break;
	case 7:
		sprintf(line, "%s%s", WRITE_MAIL_STAT, info);
		break;
	case 8:
		sprintf(line, "%s%s", DOWNLOAD_STAT, info);
		break;
	case 9:
		nstrcpy(line, UPLOAD_STAT, 128);
		break;
	case 10:
		sprintf(line, "%s%s", CHAT_STAT, info);
		break;
	case 11:
		nstrcpy(line, TALK_STAT, 128);
		break;
	case 12:
		sprintf(line, "%s%s", INTERNET_STAT, info);
		break;
	case 13:
		/* sprintf(line, "%s%s", LIST_USER_STAT, info); */
		strcpy(line,LIST_USER_STAT);
		strcat(line,info);
		break;
	case 14:
		sprintf(line, "%s%s", WRITE_USER_STAT, info);
		break;
	default:
		sprintf(line, "???:%d", stat_code);
		break;
	}

	nstrcpy(buf, line, len);
}
/*end of descript_stat*/
