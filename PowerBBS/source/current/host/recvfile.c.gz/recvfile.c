/*************************************************************************
 * recvfile.c --- receive file from client				 *
 *	      by Aquarius Kuo, Apr 15, 1994				 *
 *            new filexfer protocol by Samson Chen Apr 14, 1995          *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"
#include "dbf.h"


static char rcsid[]="$Id: recvfile.c,v 1.7 1995/10/14 06:34:00 pbbs Exp pbbs $";

extern int errno ;

/*
	recv_file --- receive a file to client site
*/
int recv_file(fd, filename)
int fd;
char *filename;		/* in:upload path,  out:filename(no path) */
/*
	return:
		 0: OK
		-1: received failed, connection lost
		 1: received failed, connection keep
*/
{
  int handle ;
  int i ;
  int tcpstat ;
  char prot ;
  char fn[120], *ptr ;
  char buffer[11000] ;
  long fl, len, len2 ;
  long BLOCK=1024 ;
  long len1, flen, fcnt ;
  long get_size;

  send_mpf(fd, " ", 1, GETFILE) ;

  read_mpf(fd, fn, &len, &prot, FALSE);		/*--- get file name ---*/
  fn[len]=0 ;
  if( prot!=FILEXFER )
  {
    if(debug_mode)	printf("(recvfile.c) filename error !\n") ;
    return(1) ; /*received failed, connection keep*/
  }  

  ptr=fn+strlen(fn)-1 ;			/* splite path & file name */
  while((*ptr!='/') && (*ptr!='\\') && (ptr!=fn))
    ptr-- ;
  ptr=(ptr==fn) ? ptr:ptr+1 ;  
  if(*ptr=='/' || *ptr=='\\')
    ptr++;
  
  for(i=0; i<strlen(ptr); i++)	/*--- check file name ---*/
  {
    if(ptr[i]<33)
    {
      ptr[i]=0 ;  
      break ;
    }  
  }  

  if( ptr[1]==':' ) ptr+=2;	/*strip A:, B:, C:, ... DOS disk name*/
  
  strcpy(buffer,ptr) ;
  
  strcat(filename,"/") ;
  strcat(filename,ptr) ;
  strcpy(fn,filename) ;
  
  strcpy(filename,buffer) ;	/* ptr is return file name */

  if(debug_mode) 	printf("(recvfile.c) filename=(%s) fn=(%s)\n",filename,fn) ;  
  if((handle=open(fn,O_CREAT|O_EXCL|O_WRONLY, S_IWUSR|S_IRUSR))<0)
  {
    if(debug_mode)	printf("(recvfile.c) %s open error %d!\n",fn,errno) ;
    send_mpf(fd,UPLOAD_FILE_EXIST,strlen(UPLOAD_FILE_EXIST),STOPXFER) ;
    return(1); /*received failed, connection keep*/
  } 

  /*set fail_then_remove flag*/
  fail_then_remove=TRUE;
  strcpy(f_t_r_filename, fn);
  
  send_mpf(fd," ",1,XFER_ACK) ; 
  if( debug_mode ) 	printf("(recvfile.c) filename = %s\n",fn) ;

  /*get file length*/
  read_mpf(fd,buffer,&len1,&prot,FALSE) ;
  buffer[len1]=0 ;
  sscanf(buffer,"%ld",&flen) ;

  /*assumes good(should check disk space before this), ready to receive*/
  send_mpf(fd," ",1,XFER_ACK) ;

  /*receive file until length flen*/
  fcnt=0;
  while(fcnt<flen)
  {
    get_size=flen-fcnt;
    if( get_size>BLOCK )
        get_size=BLOCK;

    reset_alarm(IDLE_TIME);	/*non-mpf xfer, must reset timer itself*/

    if( (tcpstat=read(fd,buffer,get_size)) >= 0 )
    {
      fcnt += tcpstat;
      write(handle, buffer, tcpstat);
    }
    else
    {
      return(-1); /*received failed, connection lost*/
    }

  }/*end while*/

  close(handle);

  /*SYNCHRONIZATION*/
  tcpstat=read(fd, buffer, 1);
  if( tcpstat<0 )
  {
      return(-1); /*received failed, connection lost*/
  }

  /*check SYNC*/
  if( buffer[0]!=END_XFER )
  {
      return(-1); /*received failed, connection lost*/
  }

  /*sendback SYNC*/
  if( write(fd, buffer, 1)<0 )
  {
      abnormal_disconnect(fd);
  }

  return(0) ; /*OK*/

  /*sending finished*/

}
/*end of send_file*/
