
/* MENU code for PBBS Server */

#define UNIMPLEMENT	0
#define	MAIN_MENU	1

#define	BULLETIN	20
#define	CHANGE_AREA	21
#define	C_PASSWORD	22
#define	ENTER_MAIL	23
#define	U_PERSON_DATA	24
#define	GOODBYE		25
#define	HELP_MAIN	27
#define	LIST_USER	29
#define	PALBBS		30
#define	PREVIOUS_MAIL	31
#define	PING		32
#define	READ_MAIL	33
#define	REGISTER	34
#define	SEARCH_MAIL	35
#define	VERSION_INFO	36
#define	WELCOME		37
#define	FILE_AREA	38
#define	SEARCH_FILE	39
#define	TOGGLE_FILE	40
#define	LIST_FILE	41
#define	DOWNLOAD_FILE	42
#define	UPLOAD_FILE	43
#define	RESET_TOGGLE	45
#define	KILL_MAIL	46
#define	INTER_READ	47
#define	FILE_POST	48
#define	SWITCH_PAGE	49
#define	WRITE_USER	50
#define	CHAT_ROOM	51
#define	QUICK_JOIN	52
#define	INTERNETMENU	53
#define	READ_MBOX	54
#define	SEND_MBOX	55
#define	ZAP_AREA	56
#define	POWER_NET	57
#define	SEND_EMAIL	58
