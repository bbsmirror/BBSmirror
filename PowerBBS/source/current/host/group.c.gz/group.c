/*************************************************************************
 * group.c --- groups operation file					 *
 *	        by Jones Tsai, Apr 11, 1996				 *
 *************************************************************************/

#include "pbbs.h"
#include "global.h"
#include "group.h"


struct group_group_struc {
	char	name[20];
	char	description[80];
	};

/*local global vars*/
struct group_struc gbuf;

/*
	create_ gdbf --- create group dbf 
*/
create_gdbf()
/*
	return:
		TRUE: OK!
		FASLE: failure!
*/
{
	char 	listfile[80];
	char 	gdbffile[80];
	char    test_path[255];
	char 	buf[128];
	FILE 	*glist;
	int  	gdbf;
	char 	*p;
	int 	n, ret;
	

	sprintf(listfile, "%s", GROUP_LIST);

	/**************************************/
	/*phase 1 --- get !group definitions*/
	/**************************************/
	glist=fopen(listfile, "r");
	if( glist==NULL )
	{
		do_log(9, "open %s error!", listfile);
		exit(11);
	}

	sprintf(gdbffile, "%s", GROUP_DBF);
	gdbf=open(gdbffile, O_WRONLY | O_TRUNC | O_CREAT, S_IWUSR | S_IRUSR);

	flock(gdbf, LOCK_EX);
	memset(buf, 0, 128);
	while( fgets(buf, 127, glist) )
	{
		
          /*take off comments*/
          for(n=0; n<strlen(buf); n++)
                if( buf[n]=='#' )
                {
                        buf[n]=0;
                        break;
                }

          ret=strlen(buf);
          if( ret<8 )
                continue; 

	  if(ret<126)
          {
                /*to avoid a possoble bug of next_blank*/
                buf[ret+1]=0;
                buf[ret+2]=0;
          }

	/*  if (debug_mode) printf(" (group.c) %s\n",buf); */

          /*--------------------------------------------------*/

          /*--- get area path ---*/
          p=buf;
          ret=next_params(p);
          p+=ret;
          ret=next_tab_space(p);
          if( ret==0 ) continue;
          p[ret]=0;
          nstrcpy(gbuf.path, p, 40);

	  p+=ret+1;
          ret=next_params(p);
	  p+=ret;
	  ret=next_tab_space(p);
	  p[ret]=0;
	  gbuf.join_level=atoi(p);

	  p+=ret+1;
          ret=next_params(p);
	  p+=ret;
	  ret=next_tab_space(p);
	  p[ret]=0;
	  gbuf.post_level=atoi(p);

	  p+=ret+1;
          ret=next_params(p);
	  p+=ret;
	  strip_nl(p);
	  strcpy(gbuf.describe, p);
	
	  if (debug_mode) printf("(group.c) %s	%d	%d	%s", gbuf.path, gbuf.join_level, gbuf.post_level, gbuf.describe);
	  write(gdbf, &gbuf, sizeof(struct group_struc));

	  sprintf(test_path, "%s/%s", MAIL_PATH, gbuf.path);

	  if( !path_exist(test_path) )
	  {
		/*path not found, maybe new create, touch a new one*/
		do_log(8, "mail path %s not found, touch a new one in %s", gbuf.path, user_name); 
		mkdir(test_path, 0x1c0);
		/*permission 0x1c0 is rwx------*/
	  }                                      

	  memset(buf, 0, 128);

	}/*end while*/

	flock(gdbf, LOCK_UN);
	fclose(glist);
	close(gdbf);

}
/*end of creacte dbf */
