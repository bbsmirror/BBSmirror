/***************************************************************************
 * bluewave.c --- Blue Wave Off Line Mail Packet Handle Module		   *
 *		  by Samson Chen Aug 4, 1995				   *
 ***************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "dbf.h"
#include "global.h"

#ifndef BIG_ENDIAN
#define BIG_ENDIAN
#endif

#ifndef signed
#define signed
#endif

#include "bluewave.h"

static char rcsid[]="$Id: bluewave.c,v 1.21 1995/11/01 14:56:39 pbbs Exp pbbs $";



#define INT_SIZE	2
#define WORD_SIZE	2
#define LONG_SIZE	4
#define DWORD_SIZE	4



/*
	store a unsigned integer to INTEL LSB format
	(for unsigned integer only)
*/
little_endian(buf, size, num)
char *buf;		/*memory buffer to store num*/
int size;		/*var size*/
unsigned long num;	/*the number*/
{
  int n;
  unsigned long tnum=num;

  memset(buf, 0, size);
  buf[0]=(unsigned char)(tnum & 0xff);
  for(n=0; n<(size-1); n++)
  {
    tnum=tnum>>8;
    buf[n+1]=(unsigned char)(tnum & 0xff);
  }
}
/*end of little_endian*/



/*
	generate Blue Wave packet
*/
generate_blue_wave(fd)
int fd;
{
  char line[256];
  char stop_packing;
  char pack_file[256];
  char packet_name[9];
  int bw_inf, bw_mix, bw_fti, bw_dat;
  char success_generated;
  char timebuf[35];
  int getpost;
  char ret;

  if(debug_mode) printf("(bluewave.c)generate_blue_wave\n");

  sprintf(line, "%s/%d.%s", USER_PREFERENCE, user_uid, GROUP_LIST);
  if( !file_exist(line) )
  {
    display_msg(fd, SET_AREA_FIRST);
    suspend(fd);
    return;
  }

  display_msg(fd, "           *********************************************\n");
  display_msg(fd, "           ***         P o w e r X P r e s s         ***\n");
  display_msg(fd, "           *** B l u e  W a v e  C o m p a t i b l e ***\n");
  display_msg(fd, "           *********************************************\n");
  display_msg(fd, "\n");

  if( yes_no(fd, BW_EXECUTE)!='y' )
    return;

  do_log(5, "%s use Blue Wave Download", user_name);
  update_act(3, NULL);

  nstrcpy(packet_name, BW_PACK_NAME, 9);
  stop_packing=FALSE;

  /*check unsend mail packet*/
  rfcgmtime(timebuf);
  sprintf(pack_file, "%s.%c%c1", packet_name, timebuf[0]+('a'-'A'), timebuf[1]);
  sprintf(line, "bluewave/%d/%s", user_uid, pack_file);
  if( file_exist(line) )
  {
    if( yes_no(fd, BW_OLD_MAIL_PACK)=='y' )
    {
      /* transfer mail packet file to user */
      display_msg(fd, "\n");
      send_file(fd, line);
      display_msg(fd, "\n\n");
      if( yes_no(fd, BW_GO_ON_PACK)!='y' )
	stop_packing=TRUE;	/*no*/
    }
  }

  /*initialize temporary path for bluewave packing*/
  sprintf(line, "bluewave/%d", user_uid);
  unlink_all(line);
  if( !path_exist(line) )
    mkdir(line, 0x1c0);

  if( stop_packing )
    return;	/*no packing*/

  /*open 4 BW files*/
  sprintf(line, "bluewave/%d/%s.inf", user_uid, packet_name);
    bw_inf=open(line, O_WRONLY|O_CREAT|O_TRUNC, S_IWUSR|S_IRUSR);
  sprintf(line, "bluewave/%d/%s.mix", user_uid, packet_name);
    bw_mix=open(line, O_WRONLY|O_CREAT|O_TRUNC, S_IWUSR|S_IRUSR);
  sprintf(line, "bluewave/%d/%s.fti", user_uid, packet_name);
    bw_fti=open(line, O_WRONLY|O_CREAT|O_TRUNC, S_IWUSR|S_IRUSR);
  sprintf(line, "bluewave/%d/%s.dat", user_uid, packet_name);
    bw_dat=open(line, O_WRONLY|O_CREAT|O_TRUNC, S_IWUSR|S_IRUSR);

  if(bw_inf<2 || bw_mix<2 || bw_fti<2 || bw_dat<2)
  {
    /*BW files open error!*/

    close(bw_inf);
    close(bw_mix);
    close(bw_fti);
    close(bw_dat);
    return;
  }

  do
  {

    success_generated=output_inf_head(fd, bw_inf);
      if( !success_generated ) continue;

    success_generated=output_area_info(fd, bw_inf);
      if( !success_generated ) continue;

    success_generated=scan_bw_area(fd, bw_mix, bw_fti, bw_dat, &getpost);
      if( !success_generated ) continue;

  }while(FALSE);

  close(bw_inf);
  close(bw_mix);
  close(bw_fti);
  close(bw_dat);

  if(getpost<=0)
  {
    success_generated=FALSE;
    display_msg(fd, NO_NEW_MSG);
    suspend(fd);
  }
  else
  {
    sprintf(line, "\n%s %d\n", TOTAL_MESSAGES, getpost);
    display_msg(fd, line);
  }

  if( success_generated )
  {
	display_msg(fd, BW_ZIP_PACK);

	chdir("bluewave");
	sprintf(line, "%d", user_uid);
	chdir(line);

	rfcgmtime(timebuf);
	sprintf(pack_file, "%s.%c%c1", packet_name, timebuf[0]+('a'-'A'), timebuf[1]);

	/* remove old */
	sprintf(line, "%s", pack_file);
	if( file_exist(line) )
	  unlink(line);

	sprintf(line, "%s %s %s.inf %s.mix %s.fti %s.dat", BW_ZIP_CMD, pack_file, packet_name, packet_name, packet_name, packet_name);
	reset_alarm(IDLE_TIME*3);	/*give more time for packing*/
	ret=system(line);
	reset_alarm(IDLE_TIME);	/*restore original time checking*/

	if(debug_mode)printf("%s : %d\n", line, ret);

	chdir(SYSTEM_PATH);

	/* remove all the pack files */
	sprintf(line, "bluewave/%d/%s.inf", user_uid, packet_name);
	  unlink(line);
	sprintf(line, "bluewave/%d/%s.mix", user_uid, packet_name);
	  unlink(line);
	sprintf(line, "bluewave/%d/%s.fti", user_uid, packet_name);
	  unlink(line);
	sprintf(line, "bluewave/%d/%s.dat", user_uid, packet_name);
	  unlink(line);

	/* transfer mail packet file to user */
	display_msg(fd, "\n");
	sprintf(line, "bluewave/%d/%s", user_uid, pack_file);
	send_file(fd, line);
  }
  else
  {
    /* remove all the pack files */
    sprintf(line, "bluewave/%d/%s.inf", user_uid, packet_name);
      unlink(line);
    sprintf(line, "bluewave/%d/%s.mix", user_uid, packet_name);
      unlink(line);
    sprintf(line, "bluewave/%d/%s.fti", user_uid, packet_name);
      unlink(line);
    sprintf(line, "bluewave/%d/%s.dat", user_uid, packet_name);
      unlink(line);
  }

  sprintf(line, "bluewave/%d/%s", user_uid, pack_file);
    unlink(line);

  sprintf(line, "bluewave/%d", user_uid);
  unlink_all(line);

  /*bluewave packet downloaded, reset new post checking*/
  if( user_use_set_area(fd) )
    reset_userset_new_post_check_flag(fd);
  else
    reset_new_post_check_flag(fd);
}
/*end of generate_blue_wave*/



/*
	output BW INF head info
*/
output_inf_head(fd, bw_inf)
int fd;
int bw_inf;
{
  INF_HEADER inf_head;
  struct udb urec;
  int n;

  if(debug_mode) printf("(bluewave.c)output_int_head\n");

  memset(&inf_head, 0, sizeof(INF_HEADER));

  inf_head.ver=PACKET_LEVEL;
  strcpy(inf_head.loginname, user_name);
  get_user_data(&urec, user_uid);
  strcpy(inf_head.aliasname, urec.real_name);

  strcpy(inf_head.sysop, "SYSOP");
  /*find a SysOp's name*/
  n=0;
  do
  {
    n++;
    if( !get_user_data(&urec, n) )
      break;

    if( urec.delete_mark=='X' )
      continue;

    if( urec.level<SYSOP_LEVEL )
      continue;

    strcpy(inf_head.sysop, urec.bbs_name);
    break;
  }while(TRUE);

  strcpy(inf_head.systemname, BW_BBS_NAME);

  little_endian(inf_head.inf_header_len, WORD_SIZE, ORIGINAL_INF_HEADER_LEN);
  little_endian(inf_head.inf_areainfo_len, WORD_SIZE, ORIGINAL_INF_AREA_LEN);
  little_endian(inf_head.mix_structlen, WORD_SIZE, ORIGINAL_MIX_STRUCT_LEN);
  little_endian(inf_head.fti_structlen, WORD_SIZE, ORIGINAL_FTI_STRUCT_LEN);

  inf_head.from_to_len=19;

  strcpy(inf_head.packet_id, "powerbbs");

  write(bw_inf, &inf_head, sizeof(INF_HEADER));

  return(TRUE);

}
/*end of output_inf_head*/



/*
	output BW INF area info
*/
output_area_info(fd, bw_inf)
int fd;
int bw_inf;
/*
	return:
		TRUE	ok
		FALSE	failed
*/
{
  INF_AREA_INFO area_info;
  char ret, mbox_area;
  int post_level;

  if(debug_mode) printf("(bluewave.c)output_area_info\n");

  ret=bw_all_area_prepare(fd);
  if( !ret ) return(FALSE);

  do
  {
    memset(&area_info, 0, sizeof(INF_AREA_INFO));
    ret=bw_get_all_area(fd, area_info.areanum, area_info.echotag, area_info.title, &post_level, &mbox_area);

    if( mbox_area )
	little_endian(area_info.area_flags, WORD_SIZE, INF_POST);
    else
    {
      if(user_level<post_level)
	little_endian(area_info.area_flags, WORD_SIZE, INF_NO_PRIVATE);
      else
	little_endian(area_info.area_flags, WORD_SIZE, INF_POST|INF_NO_PRIVATE);
    }

    area_info.network_type=INF_NET_INTERNET;

    write(bw_inf, &area_info, sizeof(INF_AREA_INFO));

  }while(ret);

  return(TRUE);

}
/*end of output_area_info*/



/*
	scan areas
*/
scan_bw_area(fd, bw_mix, bw_fti, bw_dat, getpost)
int fd;
int bw_mix;
int bw_fti;
int bw_dat;
int *getpost;
/*
	return:
		TRUE	ok
		FALSE	failed
*/
{
  MIX_REC mix_rec;
  char ret;
  char scan_group[30], areanum[6];
  char line[256];
  int totalmsg, totalper;
  int amount_warn=750, next_warn=500;
  long fti_ptr;

  if(debug_mode) printf("(bluewave.c)scan_bw_area\n");

  ret=bw_set_area_prepare(fd);
  if( !ret ) return(FALSE);

  *getpost=0;

  do
  {
    ret=bw_get_set_area(fd, scan_group, areanum);
      sprintf(line,"%s %s", BW_SCANNING, scan_group);
      display_msg(fd, line);
    fti_ptr=file_length(bw_fti);
    scanning_bw_area(fd, scan_group, &totalmsg, &totalper, bw_fti, bw_dat);
    if( totalmsg>0 )
    {
	memset(&mix_rec, 0, sizeof(MIX_REC));
	strcpy(mix_rec.areanum, areanum);
	little_endian(mix_rec.totmsgs, WORD_SIZE, totalmsg);
	little_endian(mix_rec.numpers, WORD_SIZE, totalper);
	little_endian(mix_rec.msghptr, LONG_SIZE, fti_ptr);
	write(bw_mix, &mix_rec, sizeof(MIX_REC));
	(*getpost)+=totalmsg;
    }

    display_msg(fd, "\n");

    if( (*getpost)>=amount_warn )
    {
      sprintf(line, "%d %s", (*getpost), BW_CONTINUE_PACK);
      if( yes_no(fd, line)!='y' )
      {
	/* no */
	break;
      }
      display_msg(fd, BW_USE_RESET_POINT);
      while( amount_warn<=(*getpost) )
	amount_warn+=next_warn;
    }
  }while(ret);

  return(TRUE);
}
/*end of scan_bw_area*/



/*
	scanning to BW fti/dat
*/
scanning_bw_area(fd, scan_group, totalmsg, totalper, bw_fti, bw_dat)
int fd;
char *scan_group;
int *totalmsg;
int *totalper;
int bw_fti;
int bw_dat;
{
  FTI_REC fti_rec;
  char filename[256];
  char ebuf[256];
  char bigbuf[10240];
  char line[255];
  char mbox_area;
  int mffd;
  int mfrec;
  int rec;
  struct msgrec mrec;
  char *p;
  int total_msg=0;
  int recno=0;
  int msg_head_len_before_parsing;
  int fp;
  char *path_field, *from_field, *subject_field;
  char *date_field, *reply_field;
  char from_line[80], from_name[80], reply_add[36];
  char swap_buf[80];
  char *ptr;
  long dat_ptr;
  char space=' ';
  long left_len;
  int ret;
  unsigned long pcount;
  int tail;
  char block[4096];

  if(debug_mode) printf("(bluewave.c)scanning_bw_area %s\n", scan_group);

  *totalmsg=0;
  *totalper=0;

  /*------------------------------------------------------------*/
  if( strcmp(scan_group, "mbox") )
	mbox_area=FALSE;
  else
	mbox_area=TRUE;
  /*------------------------------------------------------------*/

  /*------------------------------------------------------------*/
  if( !mbox_area )
    sprintf(filename, "%s/%s/messages", MAIL_PATH, scan_group);
  else
    sprintf(filename, "%s/mbox/%d.messages", MAIL_PATH, user_uid);

  mffd=open(filename, O_RDONLY|O_CREAT, S_IWUSR | S_IRUSR);
  /*------------------------------------------------------------*/

  /*------------------------------------------------------------*/
  if( !mbox_area )
    sprintf(filename, "%s/%s/records", MAIL_PATH, scan_group);
  else
    sprintf(filename, "%s/mbox/%d.records", MAIL_PATH, user_uid);

  mfrec=open(filename, O_RDONLY|O_CREAT, S_IWUSR | S_IRUSR);
  /*------------------------------------------------------------*/

  if( mffd<0 || mfrec<0 )
  {
	do_log(9, "SYSTEM ERROR bluewave.c %s", scan_group);
	sprintf(ebuf, "bluewave.c: %s\n", SYSTEM_ERROR);
	display_msg(fd, ebuf);
	return;
  }

  recno=get_specify_lastread(fd, scan_group);

  while(1)
  {
	lseek(mfrec, 0 ,SEEK_END);
	total_msg=file_length(mfrec)/sizeof(struct msgrec);

	if( recno >= total_msg )
		break;

	if( recno<0 )
		break;

	/*----------------------------------------------------*/

	lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
	read(mfrec, &mrec, sizeof(struct msgrec) );

	/*----------------------------------------------------*/

	/*check delete mark*/
	if( mrec.delete_mark=='D' )
	{
		recno++;
		continue;
	}

	/*----------------------------------------------------*/

	recno++;
	p=bigbuf;

	lseek(mffd, mrec.offset, SEEK_SET);
	fetch_msg_head(fd, mffd, mrec.length, p);
	fp=parse_msg(fd, p, "MSG");
	if( fp>0 ) p[fp]=0;
	msg_head_len_before_parsing=strlen(p);

	/*----------------------------------------------------*/

	/*skip cmsg cancel message*/
	fp=parse_msg(fd, bigbuf, "Subject: ");
	fp+=9;	/*skip "Subject: "*/
	subject_field=bigbuf+fp;

	if( !strncmp(subject_field, "cmsg cancel", 11) )
		continue;

	/*----------------------------------------------------*/

	/*convert GMT to local time*/

	fp=parse_msg(fd, bigbuf, "Date: ");
	fp+=6;	/*skip "Date: "*/
	date_field=bigbuf+fp;
	gmtlocal(date_field);

	/*----------------------------------------------------*/

	/* output to BW_FTI and BW_DAT */

	memset(&fti_rec, 0, sizeof(FTI_REC));

	/* Reply-To */
	fp=parse_msg(fd, bigbuf, "Reply-To: ");
	reply_add[0]=0;
	if( fp>0 )
	{
	  reply_field=bigbuf+fp;
	  strip_nl(reply_field);
	  reply_field+=10;
	  nstrcpy(reply_add, reply_field, 36);
	}

	/* DATE */
	fp=parse_msg(fd, bigbuf, "Date: ");
	fp+=6;
	date_field=bigbuf+fp;
	strip_nl(date_field);
	sprintf(fti_rec.date, "%-.19s", date_field);

	/* SUBJECT */
	fp=parse_msg(fd, bigbuf, "Subject: ");
	fp+=9;
	subject_field=bigbuf+fp;
	strip_nl(subject_field);
	sprintf(fti_rec.subject, "%-.71s", subject_field);

	/* FROM */
	fp=parse_msg(fd, bigbuf, "From: ");
	from_field=bigbuf+fp;
	strip_nl(from_field);
	from_field+=6;

	from_name[0]=0;

	nstrcpy(from_line, from_field, 80);
	ptr=strtok(from_line, "()<>[]");

	if( ptr != NULL )
	{
		ptr=strtok(NULL,"()<>[]") ;
		if( ptr != NULL )
		{
		  if( reply_add[0]==0 )
		    nstrcpy(reply_add, from_line, 36);

		  nstrcpy(from_name, ptr, 80);
		}
	}

	if( from_name[0]==0 )
	  nstrcpy(from_name, from_field, 80);

	if( reply_add[0]==0 )
	  nstrcpy(reply_add, from_field, 36);

	strip_nl(from_name);
	strip_nl(reply_add);

	/*sometimes From: Full Name <Email@address>*/
	if( email_check(from_name) && (!email_check(reply_add)) )
	{
	  nstrcpy(swap_buf, from_name, 80);
	  nstrcpy(from_name, reply_add, 80);
	  nstrcpy(reply_add, swap_buf, 36);
	}

	/* Path */
	if( mbox_area )
	{
	  fp=parse_msg(fd, bigbuf, "Path: ");
	  fp+=6;  /*skip "Path: "*/
	  path_field=bigbuf+fp;
	  if( !strncmp(path_field, "%SENDMAIL%", 10) )
	    sprintf(fti_rec.from, "%-.35s", reply_add); /*from email gateway*/
	  else
	    sprintf(fti_rec.from, "%-.35s", from_name); /*general post*/
	}
	else
	  sprintf(fti_rec.from, "%-.35s", from_name);   /*general post*/

	/* TO */
	if( mbox_area )
	  sprintf(fti_rec.to, "%-.35s", user_name);
	else
	  sprintf(fti_rec.to, "%-.35s", reply_add);

	/* MSGNUM */
	little_endian(fti_rec.msgnum, WORD_SIZE, recno);

	/* MSGPTR */
	dat_ptr=file_length(bw_dat);
	little_endian(fti_rec.msgptr, LONG_SIZE, dat_ptr);

	/* write to bw_dat */
	write(bw_dat, &space, 1);	/*space by the standard*/
	lseek(mffd, mrec.offset, SEEK_SET);
	lseek(mffd, msg_head_len_before_parsing, SEEK_CUR);
	left_len=mrec.length-msg_head_len_before_parsing;
	pcount=0;

	if( left_len>0 )
	{
	  while(pcount<left_len)
	  {
	    tail=left_len-pcount;
	    if( tail>4096 ) tail=4096;
	    ret=read(mffd, block, tail);

	    if( ret==0 )
	      break;

	    if( ret<0 )
	    {
	      do_log(8, "file handle size (left_len) error in scan_bw_area");
	      break;
	    }

	    pcount+=ret;

	    write(bw_dat, block, ret);

	  }/*end while*/
	}/*end if*/

	/* MSGLENGTH */
	little_endian(fti_rec.msglength, LONG_SIZE, file_length(bw_dat)-dat_ptr);

	(*totalmsg)++;
	if( mbox_area )
		(*totalper)++;

	if( ((*totalmsg)%25)==0 )
	  display_msg(fd, ".");

	/* output BW FTI */
	write(bw_fti, &fti_rec, sizeof(FTI_REC));

  }/*end while(1)*/

  set_specify_lastread(fd, total_msg, scan_group);

  close(mffd);
  close(mfrec);

}
/*end of scanning_bw_area*/



/*
	user upload Blue Wave packet
*/
upload_blue_wave(fd)
int fd;
{
  char line[256];
  char up_file[80];
  char ret;
  char reply_pack_name_low[256], reply_pack_name_up[256];

  if(debug_mode) printf("(bluewave.c)upload_blue_wave\n");

  display_msg(fd, "           *********************************************\n");
  display_msg(fd, "           ***         P o w e r X P r e s s         ***\n");
  display_msg(fd, "           *** B l u e  W a v e  C o m p a t i b l e ***\n");
  display_msg(fd, "           *********************************************\n");
  display_msg(fd, "\n");

  sprintf(line, "bluewave/%d", user_uid);
  unlink_all(line);
  if( !path_exist(line) )
    mkdir(line, 0x1c0);
  strcpy(up_file, line);

  if(debug_mode) printf("(bluewave.c)do receiving\n");

  update_act(3, NULL);

  if( (ret=recv_file(fd, up_file))==0 )
  {
    do_log(5, "%s use Blue Wave Upload", user_name);

    chdir("bluewave");
    sprintf(line, "%d", user_uid);
    chdir(line);

    sprintf(line, "%s %s", BW_UNZIP_CMD, up_file);
    ret=system(line);

    if(debug_mode)printf("%s : %d\n", line, ret);

    chdir(SYSTEM_PATH);

      strtolower(line, BW_PACK_NAME);
    sprintf(reply_pack_name_low, "bluewave/%d/%s.upl", user_uid, line);
      strtoupper(line, BW_PACK_NAME);
    sprintf(reply_pack_name_up, "bluewave/%d/%s.UPL", user_uid, line);
    if( file_exist(reply_pack_name_low) )
    {
      unpack_blue_wave(fd, reply_pack_name_low);
    }
    else if( file_exist(reply_pack_name_up) )
    {
      unpack_blue_wave(fd, reply_pack_name_up);
    }
    else
    {
      sprintf(line, "%s.upl %s\n", BW_PACK_NAME, BW_REPLY_PACK_NO_EXIST);
      display_msg(fd, line);
      suspend(fd);
    }

    sprintf(line, "bluewave/%d", user_uid);
    unlink_all(line);

    fail_then_remove=FALSE;
  }
  else if( ret>0 )
  {
    display_msg(fd, UPLOAD_FAILED);
    suspend(fd);
    do_log(2, "%s bluewave upload failed", user_name);

    sprintf(line, "bluewave/%d", user_uid);
    unlink_all(line);

    fail_then_remove=FALSE;
  }
  else /* ret<0 */
  {
    /*connection lost*/
    if( fail_then_remove )
    {
      fail_then_remove=FALSE;
      unlink(f_t_r_filename);
    }

    sprintf(line, "bluewave/%d", user_uid);
    unlink_all(line);

    do_log(2, "%s bluewave upload failed", user_name);

    abnormal_disconnect(fd);
    /*never return*/
  }

}
/*end of upload_blue_wave*/



/*
	unpacking blue wave *.upl file
*/
unpack_blue_wave(fd, reply_name)
int fd;
char *reply_name;
{
  int reply_pack;
  int ret;
  char line[255], bw_version[20], bw_reader[80];
  UPL_HEADER upl_head;
  UPL_REC upl_rec;
  int get_len;
  int head_len, rec_len;
  int t_serial;
  char ignore_area_case;

  if(debug_mode)printf("(bluewave.c)unpack_blue_wave(%s)\n", reply_name);

  reply_pack=open(reply_name, O_RDONLY);
  if(reply_pack<=0)
    return;

  if( file_length(reply_pack)<sizeof(UPL_HEADER) )
    get_len=file_length(reply_pack);
  else
    get_len=sizeof(UPL_HEADER);

  lseek(reply_pack, 0, SEEK_SET);
  ret=read(reply_pack, &upl_head, get_len);
  if(ret<=0)
  {
    close(reply_pack);
    return;
  }

  head_len=upl_head.upl_header_len[0] | (upl_head.upl_header_len[1]<<8);
  rec_len=upl_head.upl_rec_len[0] | (upl_head.upl_rec_len[1]<<8);

  if(debug_mode)printf("(unpack_blue_wave)head_len=%d, rec_len=%d\n", head_len, rec_len);

  if( head_len<=0 || rec_len<=0 )
  {
    close(reply_pack);
    return;
  }

  nstrcpy(bw_version, upl_head.vernum, 20);
  ret=0;
  while( bw_version[ret]!=0 )
  {
    bw_version[ret]+=10;
    ret++;
  }

  nstrcpy(bw_reader, upl_head.reader_name, 80);
  ret=strlen(bw_reader)-1;
  while( ret>0 )
  {
    if( bw_reader[ret]!=' ' )
      break;

    bw_reader[ret]=0;
    ret--;
  }

  sprintf(line,"\n%s %s\n", bw_reader, bw_version);
  if( strlen(line)>2 )
    display_msg(fd, line);

  /* BWave 2.20 will make 'area' to 'AREA', so unpack must not be case sense */
  if( (bw_version[0]-'0')>=2 && (bw_version[2]-'0')>=2 )
    ignore_area_case=TRUE;
  else
    ignore_area_case=FALSE;

  if( !bw_all_area_prepare(fd) )
  {
    close(reply_pack);
    return;
  }

  lseek(reply_pack, head_len, SEEK_SET);
  init_dbz_channel();
  t_serial=0;
  while( read(reply_pack, &upl_rec, rec_len) )
    blue_wave_toss(fd, upl_rec.to, upl_rec.subj, upl_rec.filename, upl_rec.echotag, upl_rec.unix_date, t_serial++, ignore_area_case);
  close_dbz_channel();

  close(reply_pack);

  display_msg(fd, BW_UNPACK_OK);
  suspend(fd);

}
/*end of unpack_blue_wave*/



/*
	toss file from blue wave to area
*/
blue_wave_toss(fd, to_name, subject, filename, areaname, unix_date, t_serial, ignore_case)
int fd;
char *to_name;
char *subject;
char *filename;
char *areaname;
char *unix_date;	/*for DBZ dup-reply checking*/
int t_serial;		/*toss serial no. for get_mid*/
char ignore_case;	/*if ignode area case*/
{
  int post_level;
  char line[256], fetch_file_low[256], fetch_file_up[256];
  char rep_dup_check[256];
  char mbox_to[20], mbox_email_not_local_user;
  char area[50];
  char bigbuf[MAX_BUF], buf[255], ebuf[128];
  char *ptr;
  int reply_handle, msgfile, recfile, test;
  int ret, n;
  unsigned long pcount;
  char from_name[20], unique_id[20], message_id[128], timebuf[35];
  char mfile[80], rfile[80];
  struct msgrec mr;
  char origin_filename[80], origin_line[80];
  FILE *origin_file;
  char crlf[3], ck1[5], ck2[5];
  unsigned int mbox_to_uid;	/*mbox recevier's uid*/
  struct udb urec;
  char find_d, od=0xd;
  long outcnt;

  /* strip hacker areaname */
  ptr=areaname+strlen(areaname)-1 ;	/* splite path */
  while((*ptr!='/') && (*ptr!='\\') && (ptr!=areaname))
    ptr-- ;
  ptr=(ptr==areaname) ? ptr:ptr+1 ;
  if(*ptr=='/' || *ptr=='\\')
    ptr++;
  strcpy(area, areaname);

  if(debug_mode)
  {
    printf("(blue_wave_toss)\n");
    printf("  To      : %s\n", to_name);
    printf("  Subject : %s\n", subject);
    printf("  Filename: %s\n", filename);
    printf("  Echotag : %s\n", area);
  }

  /*dup-reply checking*/
  sprintf(rep_dup_check, "<%d%x%x%x%x%s@%s>", user_uid, (unsigned char)unix_date[0], (unsigned char)unix_date[1], (unsigned char)unix_date[2], (unsigned char)unix_date[3], filename, BW_PACK_NAME);
  if(debug_mode)printf("(blue_wave_tossing)dup-reply check '%s'\n", rep_dup_check);
  if( query_mid(rep_dup_check, line) )
  {
    if( strcmp(area, "mbox") )
      sprintf(line, "%s(%-.20s)%s\n", area, subject, BW_REPLY_DUP);
    else
      sprintf(line, "%s(%-.20s)(%-.15s)%s\n", area, to_name, subject, BW_REPLY_DUP);
    display_msg(fd, line);
    return;
  }

  if( !bw_get_post_level(fd, area, &post_level, ignore_case) )
  {
    sprintf(line, "%s %s", area, NO_SUCH_GROUP);
    display_msg(fd, line);
    suspend(fd);
    return;
  }

  if(debug_mode && ignore_case)printf("(blue_wave_toss)get area '%s'\n", area);

  if( user_level < post_level )
  {
    sprintf(line, "%s %s", area, POST_SECURITY);
    display_msg(fd, line);
    suspend(fd);
    return;
  }

  mbox_email_not_local_user=FALSE;

  if( !strcmp(area, "mbox") )
  {
    nstrcpy(mbox_to, to_name, 20);
    process_user_name(mbox_to);
    mbox_to_uid=get_user_id(mbox_to);
    if(mbox_to_uid==0)	/*rcpt user not found*/
    {
      if( email_check(to_name) && (user_level>=USE_EMAIL_LEVEL) )
      {
	/* maybe send email via mbox area */
	mbox_email_not_local_user=TRUE;
      }
      else
      {
	sprintf(line, "mbox(%s)(%-.30s)%s", mbox_to, subject, NO_SUCH_USER);
	display_msg(fd, line);
	suspend(fd);
	return;
      }
    }
  }/*end if(mbox)*/

  /*fetch message text*/
    strtolower(line, filename);
  sprintf(fetch_file_low, "bluewave/%d/%s", user_uid, line);
    strtoupper(line, filename);
  sprintf(fetch_file_up, "bluewave/%d/%s", user_uid, line);

  if( file_exist(fetch_file_low) )
    reply_handle=open(fetch_file_low, O_RDONLY);
  else if( file_exist(fetch_file_up) )
    reply_handle=open(fetch_file_up, O_RDONLY);
  else
  {
    sprintf(line, "%s(%s) %s", area, filename, NO_SUCH_FILE);
    display_msg(fd, line);
    suspend(fd);
    return;
  }

  if(reply_handle<=0) return;
  ptr=bigbuf;
  pcount=0;
  do
  {
    ret=read(reply_handle, ptr, 1024);
    if( ret<0 ) return;
    if( ret==0 ) break;
    ptr+=ret;
    pcount+=ret;
  }while(pcount<(MAX_BUF-1025));
  *ptr=0;
  close(reply_handle);

  /*maybe this is a email*/
  if( email_check(to_name) && (user_level>=USE_EMAIL_LEVEL) )
  {
    sprintf(line, "%s(%-.30s)(%-.35s)\n", area, to_name, subject);
    display_msg(fd, line);

    if( yes_no(fd, SEND_AS_EMAIL)=='y' )
    {
      /*yes*/
      blue_wave_send_email(fd, to_name, subject, bigbuf);

      if( mbox_email_not_local_user )
      {
	/*add DBZ for future dup-reply check*/
	add_mid(rep_dup_check, "BlueWaveUpload");
	return;
      }

      if(yes_no(fd, CONTINUE_POST)!='y')
      {
	/*no*/
	/*add DBZ for future dup-reply check*/
	add_mid(rep_dup_check, "BlueWaveUpload");
	return;
      }
    }/*end if(SEND_EMAIL)*/
  }/*end if(email_check)*/

  if( mbox_email_not_local_user )
    return;

  /*---------*/
  /* tossing */
  /*---------*/

  strcpy(from_name, user_name);

  for(n=0; n<strlen(from_name); n++)
    if( from_name[n]==' ' )
    {
	from_name[n]='_';
	break;
    }

  if(debug_mode) printf("(bluewave.c)server writing post\n");

  /*---------------------------------------------------------------*/
  if( strcmp(area, "mbox") )
  {
	sprintf(mfile, "%s/%s/messages", MAIL_PATH, area);
	sprintf(rfile, "%s/%s/records", MAIL_PATH, area);
  }
  else	/*mbox*/
  {
	sprintf(mfile, "%s/mbox/%d.messages", MAIL_PATH, mbox_to_uid);
	sprintf(rfile, "%s/mbox/%d.records", MAIL_PATH, mbox_to_uid);
  }
  /*---------------------------------------------------------------*/

  if( !file_exist(mfile) )
  {
    test=open( mfile, O_WRONLY | O_APPEND | O_CREAT, S_IWUSR | S_IRUSR);
    if( test<0 )
    {
	off_putmp();
	do_log(9, "SYSTEM ERROR entermail %s open error!?", mfile);
	sprintf(ebuf, "bluewave.c: %s", SYSTEM_ERROR);
	send_mpf(fd, ebuf, strlen(ebuf), REJECT);
	exit(12);
    }
    else
	close(test);
  }

  if( !file_exist(rfile) )
  {
    test=open( rfile, O_WRONLY | O_APPEND | O_CREAT, S_IWUSR | S_IRUSR);
    if( test<0 )
    {
	off_putmp();
	do_log(9, "SYSTEM ERROR %s open error!?", rfile);
	sprintf(ebuf, "bluewave.c: %s", SYSTEM_ERROR);
	send_mpf(fd, ebuf, strlen(ebuf), REJECT);
	exit(12);
    }
    else
	close(test);
  }

  msgfile=open(mfile, O_WRONLY | O_APPEND);
  if( msgfile<0 )
  {
	off_putmp();
	do_log(9, "SYSTEM ERROR %s open error!?", mfile);
	sprintf(ebuf, "bluewave.c: %s", SYSTEM_ERROR);
	send_mpf(fd, ebuf, strlen(ebuf), REJECT);
	exit(12);
  }

  recfile=open(rfile, O_WRONLY | O_APPEND);
  if( recfile<0 )
  {
	off_putmp();
	do_log(9, "SYSTEM ERROR %s open error!?", rfile);
	sprintf(ebuf, "bluewave.c: %s", SYSTEM_ERROR);
	send_mpf(fd, ebuf, strlen(ebuf), REJECT);
	exit(12);
  }

  flock(msgfile, LOCK_EX);	/*exclusive lock*/
  flock(recfile, LOCK_EX);	/*exclusive lock*/

  lseek(msgfile, 0, SEEK_END);
  mr.offset=file_length(msgfile);
  nstrcpy(mr.subject, subject, 60);
  mr.packed=' ';
  mr.delete_mark=' ';

  memset(buf, 0, 255);
  sprintf(buf, "Path: %s%c%c", STATION_ID, 13, 10);
    write(msgfile, buf, strlen(buf) );

  memset(buf, 0, 255);
  sprintf(buf, "From: %s.pbbs@%s (%s)%c%c", from_name, NNRP_DOMAIN,  user_name, 13, 10);
    write(msgfile, buf, strlen(buf) );

  memset(buf, 0, 255);
  sprintf(buf, "Subject: %s%c%c", subject, 13, 10);
    write(msgfile, buf, strlen(buf) );

  memset(buf, 0, 255);
  memset(message_id, 0, 128);
  memset(unique_id, 0, 20);
  get_mid(unique_id);
  sprintf(message_id, "<%s%d@%s>", unique_id, t_serial, NNRP_DOMAIN);
  sprintf(buf, "Message-ID: %s%c%c", message_id, 13, 10);
    write(msgfile, buf, strlen(buf) );

  rfcgmtime(timebuf);
  memset(buf, 0, 255);
  sprintf(buf, "Date: %s GMT%c%c", timebuf, 13, 10);
    write(msgfile, buf, strlen(buf) );

  memset(buf, 0, 255);
  sprintf(buf, "Organization: %s%c%c", SORGANIZATION, 13, 10);
    write(msgfile, buf, strlen(buf) );

  if( email_check(user_email) )
  {
    memset(buf, 0, 255);
    sprintf(buf, "Reply-To: %s%c%c", user_email, 13, 10);
      write(msgfile, buf, strlen(buf) );
  }

  memset(buf, 0, 255);
  sprintf(buf, "%c%c", 13, 10);
    write(msgfile, buf, 2);

  /* output msgtxt with CR-LF */
  find_d=FALSE;
  for(outcnt=0; outcnt<strlen(bigbuf); outcnt++)
  {
    if( bigbuf[outcnt]==0xd )
    {
      find_d=TRUE;
      break;
    }
  }

  if( find_d )
  {
    if(debug_mode)printf("(bluewave.c)write msgtxt directly\n");
    write(msgfile, bigbuf, strlen(bigbuf) );
  }
  else
  {
    if(debug_mode)printf("(bluewave.c)write msgtxt with CR-LF trans\n");
    for(outcnt=0; outcnt<strlen(bigbuf); outcnt++)
    {
      if( bigbuf[outcnt]==0xa )
	write(msgfile, &od, 1);

      write(msgfile, bigbuf+outcnt, 1);
    }
  }

  /*add origin line if exist*/
  sprintf(origin_filename, "%s/%s/origin", MAIL_PATH, area);
  if( file_exist(origin_filename) || !strcmp(DEFAULT_ORIGIN, "YES") )
  {
	if( file_exist(origin_filename) )
	{
		origin_file=fopen(origin_filename, "r");
		fgets( origin_line, 79, origin_file);
		fclose(origin_file);
	}
	else
	{
		strcpy(origin_line, ORIGIN_LINE);
	}

	sprintf(crlf, "%c%c", 0xd, 0xa);
	write(msgfile, crlf, strlen(crlf) );

	memset(buf, 0, 255);

	sprintf(ck1, "%c--%c", 10, 13);
	sprintf(ck2, "%c--%c", 10, 10);

	if( strstr(bigbuf, ck1) || strstr(bigbuf, ck2) )
	  sprintf(buf, "%c%c * Origin: %s%c%c", 13, 10, origin_line, 13, 10);
	else
	  sprintf(buf, "--%c%c * Origin: %s%c%c", 13, 10, origin_line, 13, 10);
	write(msgfile, buf, strlen(buf) );
  }

  lseek(msgfile, 0, SEEK_END);
  mr.length=file_length(msgfile)-mr.offset;

  write(recfile, &mr, sizeof(mr) );

  flock(msgfile, LOCK_UN);	/*unlock*/
  flock(recfile, LOCK_UN);	/*unlock*/

  do_log(6, "%s post a new mail at %s mid %s by Blue Wave", user_name, area, message_id);

  /*add DBZ for future dup-reply check*/
  add_mid(rep_dup_check, "BlueWaveUpload");

  /*add mid for nnrp check*/
  sprintf(line, "%d", (file_length(recfile)/sizeof(struct msgrec)) );
  add_mid(message_id, line);

  close(msgfile);
  close(recfile);

  if( !strcmp(area, "mbox") )
  {
	sprintf(line, "mbox(%s)(%-.45s)\n", to_name, subject);
	display_msg(fd, line);

	do_log(0, "set mbox quote to user #%d", mbox_to_uid);
	set_mail_quote(mbox_to_uid, 'Y');
  }
  else
  {
	sprintf(line, "%s(%-.50s)\n", area, subject);
	display_msg(fd, line);

	/*add user's total_post record*/
	get_user_data(&urec, user_uid);
	urec.total_post++;
	set_user_data(&urec, user_uid);
  }

}
/*end of blue_wave_toss*/



/*
      send email from Blue Wave reply packet directly
      blue_wave_send_email(fd, to_name, subject);
*/
blue_wave_send_email(fd, reply_add, post_subject, msgtxt)
int fd;
char *reply_add;
char *post_subject;
char *msgtxt;
{
  char email_add[80];
  char from_name[20];
  char sendmail[256];
  char buf[256];
  int n, ret;
  FILE *fd_pipe;

  if(debug_mode) printf("(bluewave.c)_blue_wave_send_email\n");

  if( user_level<USE_EMAIL_LEVEL )
    return;

  nstrcpy(email_add, reply_add, 80);
  alltrim(email_add);
  strip_nl(email_add);
  ret=strlen(email_add);
  if( email_add[0]=='<' || email_add[0]=='[' || email_add[0]=='(' )
  {
    for(n=1; n<ret; n++)
    {
      if( email_add[n]=='>' || email_add[n]==']' || email_add[n]=='>' )
      {
	email_add[n-1]=0;
	break;
      }
      email_add[n-1]=email_add[n];
    }
    email_add[ret-1]=0;
  }
  for(n=0; n<ret; n++)
    if(email_add[n]==' ') {email_add[n]=0; break;}
  if( strlen(email_add)==0 ) return;

  strcpy(from_name, user_name);
  for(n=0; n<strlen(from_name); n++)
    if( from_name[n]==' ' )
    {
	from_name[n]='_';
	break;
    }

  sprintf(sendmail, "%s -f%s.pbbs -F%s %s", SENDMAIL_CMD, from_name, from_name, email_add);
  if(debug_mode)printf("(blue_wave_send_email)popen %s\n", sendmail);
  if (( fd_pipe = popen(sendmail, "w")) == NULL)
  {
    do_log(5, "%s popen sendmail %s error", user_name, email_add);
    return;
  }

  memset(buf, 0, 255);
  sprintf(buf, "Subject: %s%c%c", post_subject, 13, 10);
	fprintf(fd_pipe, "%s", buf);

  if( email_check(user_email) )
  {
	memset(buf, 0, 255);
	sprintf(buf, "Reply-To: %s%c%c", user_email, 13, 10);
	  fprintf(fd_pipe, "%s", buf);
  }
  else
  {
	memset(buf, 0, 255);
	sprintf(buf, "Reply-To: %s.pbbs@%s%c%c", from_name, NNRP_DOMAIN, 13, 10);
	  fprintf(fd_pipe, "%s", buf);
  }

  memset(buf, 0, 255);
  sprintf(buf, "%c%c", 13, 10);
    fprintf(fd_pipe, "%s", buf);

  fprintf(fd_pipe, "%s", msgtxt);

  fprintf(fd_pipe, "%c%c%c", 0xd, 0xa, 4);      /*add ctrl-d EOF*/

  do_log(5, "%s send email from Blue Wave to %s", user_name, email_add);

  pclose(fd_pipe);

}
/*end of blue_wave_send_email*/



/*
	convert a string to one of lower cases
*/
strtolower(target, source)
char *target;
char *source;
{
  int i, len;
  len=strlen(source);
  for(i=0; i<len; i++)
    target[i]=tolower(source[i]);
  target[len]=0;
}
/*end of strtolower*/



/*
	convert a string to one of upper cases
*/
strtoupper(target, source)
char *target;
char *source;
{
  int i, len;
  len=strlen(source);
  for(i=0; i<len; i++)
    target[i]=toupper(source[i]);
  target[len]=0;
}
/*end of strtoupper*/
