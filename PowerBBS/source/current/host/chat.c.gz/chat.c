/*************************************************************************
 * chat.c --- chatting function 					 *
 *	      by Samson Chen, May 18, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "dbf.h"
#include "global.h"


/*
	chat_room --- chatting room service
*/
chat_room(fd)
	int fd;
{
	char answer[80];
	char line[255];
	char room_select;
	char callsign[20];
	int room;
	struct putmp purec;
	int sig_rec;
	int n, room_users;
	char dup_callsign;
	char private_room;

	room_select=FALSE;
	for( ; ; )
	{
	if( !room_select )
	{
	  if( user_level<ALL_PUBROOM_LVL )
	    sprintf(line, "%s)", NSELECT_ROOM);
	  else if( user_level<MORE_ROOM_LVL )
	    sprintf(line, "%s) ", SELECT_ROOM);
	  else
	    sprintf(line, "%s, 91-99:OP_Only) ", SELECT_ROOM);
	  asking(fd, line, answer, 3);
	  if( answer[0]==0 || answer[0]==13 || answer[0]==10 )
		  return;

	  room=atoi(answer);

	  if( room<1 )
	  {
		  display_msg(fd, INVALID_ROOM);
		  suspend(fd);
		  return;
	  }

	  if( user_level<ALL_PUBROOM_LVL )
	  {
		  if( room > 1 && room < 11 )
		  {
			  display_msg(fd, INVALID_ROOM);
			  suspend(fd);
			  continue;
		  }
	  }

	  if( user_level<MORE_ROOM_LVL )
	  {
		  if( room > 90 )
		  {
			  display_msg(fd, INVALID_ROOM);
			  suspend(fd);
			  continue;
		  }
	  }

	  if( room>10 )
	    private_room=TRUE;
	  else
	    private_room=FALSE;

	  room_select=TRUE;
	}/*end if(room_select)*/

	dup_callsign=FALSE;
	room_users=0;

	if( private_room )
	{
	  /*use user ID as callsign*/
	  nstrcpy(callsign, user_name, 20);
	  for(n=0; n<strlen(callsign); n++)
	    if( callsign[n]==' ' )
	      callsign[n]='.';
	}
	else
	{
	  /*user-choosed callsign*/
	  asking(fd, WHAT_CALL_SIGN, callsign, 20);
	  if( callsign[0]==0 || callsign[0]==13 || callsign[0]==10 )
	    nstrcpy(callsign, user_name, 20);

	  /*callsign cannot contain blank*/
	  for(n=0; n<strlen(callsign); n++)
	    if( callsign[n]==' ' )
	      callsign[n]='.';
	}

	/*check duplicate callsign*/
	for(sig_rec=0; sig_rec<(flength(ON_LINE_USER)/sizeof(struct putmp)); sig_rec++)
	{
	  get_putmp(&purec, sig_rec);

	  if( purec.active )
	  {
	    if( purec.chatroom==room )
	    {
		room_users++;
		if( !strcasecmp(purec.callsign, callsign ) )
		{
			dup_callsign=TRUE;
			break;
		}
	    }
	  }/*end if(purec.active)*/

	}/*end for*/

	if( private_room )
	  if( (room_users>=2) && (!system_operator) )
	  {
	    display_msg(fd, PRIVATE_ROOM);
	    suspend(fd);
	    room_select=FALSE;
	    continue;
	  }

	if( dup_callsign )
	{
	  display_msg(fd, DUP_CALLSIGN);
	  if( private_room )
	  {
	    do_log(9, "SYSTEM ERROR: chat_room() private room dup callsign???(%s)", user_name);
	    suspend(fd);
	    return;
	  }
	  continue;
	}
	else
	{
	  break;
	}

	} /*end for (fake infinite-for-loop)*/

	/****************************************************************/

	if(debug_mode) printf("(chat.c)enter chat room %d\n", room);

	do_log(1, "%s enter chat room %d", user_name, room);

	/*initial chatting*/
	sprintf(line, "%s(%s%s, %s%d)", CHAT_AD_LINE, CALL_SIGN, callsign, ROOM_NO, room);
	send_mpf(fd, line, strlen(line), TALK);

	/*register chatroom*/
	get_putmp(&purec, putmp_rec);
	  purec.chatroom=room;
	  nstrcpy(purec.callsign, callsign, 20);
	set_putmp(&purec, putmp_rec);

	sprintf(line, "%d", room);
	update_act(10, line);

	chatting(fd, room, callsign);

	/*un-register chatroom at STOPTALK protocol of chatting()*/

}
/*end of chat_room*/



/*
	chatting --- (as the name)
*/
chatting(fd, room, callsign)
	int fd;
	int room;
	char *callsign;
{
	char line[256];
	char lbuf[256];
	char u_send[256];
	char chat_token[128];
	char talk_file[128];
	int token;
	int talk;
	struct putmp purec;
	struct udb urec;
	int disp_n;
	int sig_rec;
	char end_chat=FALSE;
	int rlen;
	char protocol;
	char send_msg=FALSE;
	char msg_usr[20];
	int n, m;

	sprintf(chat_token, "%s/token.%d", TALK_BUFFER, room);
	sprintf(talk_file, "%s/talk.%d", TALK_BUFFER, user_uid);

	/*signal all users at the same room*/
	sprintf(line, "***%s%s%c%c", callsign, GET_IN_LINE, 13, 10);

	token=open(chat_token, O_RDONLY|O_CREAT, S_IWUSR|S_IRUSR);
	do
	{
		flock(token, LOCK_EX);	/*get chat token*/

		talk=open(talk_file,O_WRONLY|O_CREAT|O_TRUNC,S_IWUSR|S_IRUSR);
		if(debug_mode) printf("(chat.c)ready signal %s\n", line);
		write(talk, line, strlen(line));
		close(talk);

		/*paging*/
		for(sig_rec=0; sig_rec<(flength(ON_LINE_USER)/sizeof(struct putmp)); sig_rec++)
		{
		  get_putmp(&purec, sig_rec);

		  if( purec.active )
		  {
		    if( purec.chatroom==room )
		    {
				if( send_msg && strcasecmp(msg_usr, purec.callsign) && (purec.uid!=user_uid) )
					continue;

				purec.page_mode=1;
				purec.page_uid=user_uid;
				set_putmp(&purec, sig_rec);
				kill(purec.pid, SIGUSR1);
		    }
		  }
		}

		flock(token, LOCK_UN);	/*release chat token*/

		send_msg=FALSE;

		if( end_chat )
		{
			/*release client's talk state*/
			send_mpf(fd, NULL, 0, ENDTALK);
			break;
		}

		for( ; ; )
		{
		  read_mpf(fd, u_send, &rlen, &protocol, FALSE);
		  u_send[rlen]=0;

		  if(debug_mode) printf("(chat.c)get chat string\n");

		  if( protocol==STOPTALK )
		  {
			sprintf(line, "***%s%s%c%c", callsign, GET_OFF_LINE, 13, 10);

			/*un-register chatroom*/
			get_putmp(&purec, putmp_rec);
			purec.chatroom=0;
			set_putmp(&purec, putmp_rec);

			end_chat=TRUE;
			/*send off-line signal to OTHER users*/
		  }
		  else
		  {
			/*meta --- help*/
			if( !strncmp(u_send, "/?", 2) || !strncmp(u_send, "/h", 2) )
			{
				send_mpf(fd, CHAT_HELP_1, strlen(CHAT_HELP_1), TALK);
				send_mpf(fd, CHAT_HELP_2, strlen(CHAT_HELP_2), TALK);
				send_mpf(fd, CHAT_HELP_3, strlen(CHAT_HELP_3), TALK);

				continue;
			}

			/*meta --- user list*/
			if( !strncmp(u_send, "/w", 2) )
			{
			  disp_n=0;
			  strcpy(line, "list* ");

			  for(sig_rec=0; sig_rec<(flength(ON_LINE_USER)/sizeof(struct putmp)); sig_rec++)
			  {
			    get_putmp(&purec, sig_rec);

			    if( purec.active )
			    {
			      if( purec.chatroom==room )
			      {
					get_user_data(&urec, purec.uid);
					sprintf(lbuf, "%.15s:%.15s ", purec.callsign, urec.bbs_name);
					m=strlen(lbuf);
					for(n=m; n<32; n++)
						lbuf[n]=' ';

					lbuf[32]=0;

					strcat(line, lbuf);
					disp_n++;

					if( disp_n==2 )
					{
					  send_mpf(fd, line, strlen(line), TALK);
					  disp_n=0;
					  strcpy(line, "list* ");
					}
			      }
			    }
			  }/*end for*/

			  if( disp_n>0 )
			  {
				  send_mpf(fd, line, strlen(line), TALK);
			  }

			  continue;
			}

			/*meta --- msg*/
			if( !strncmp(u_send, "/msg", 3) && strlen(u_send)>6)
			{
				n=next_char(u_send+5, ' ');

				if( strlen(u_send+5+n)<1 )
				{
					/*illegle meta command*/
					send_mpf(fd, META_CMD_ERR, strlen(META_CMD_ERR), TALK);
					continue;
				}

				sprintf(line, "*%s*%s", callsign, u_send+5+n);
				u_send[5+n]=0;
				strcpy(msg_usr, u_send+5);

				send_msg=TRUE;

				break;
			}

			/*meta --- action*/
			if( !strncmp(u_send, "/me", 3) )
			{
				if( strlen(u_send+3)<1 )
				{
					/*illegle meta command*/
					send_mpf(fd, META_CMD_ERR, strlen(META_CMD_ERR), TALK);
					continue;
				}

				sprintf(line, "%s%s", callsign, u_send+3);
			}
			else
			{
				if( u_send[0]=='/' )
				{
					/*illegle meta command*/
					send_mpf(fd, META_CMD_ERR, strlen(META_CMD_ERR), TALK);
					continue;
				}

				/*normal talk*/

				/*strip some control macro*/
				u_send[61]=0;
				strip_rude_macro(u_send);
				sprintf(line, "%-15s> %-.61s%c%c", callsign, u_send, 13, 10);
			}
		  }

			break;	/*fake infinite for-loop*/
		} /*end for*/

	}while(TRUE);
	close(token);
}
/*end of chatting*/



/*
	strip {#..c#}, {#..p..#}, add {#n#} if color macro exist
*/
strip_rude_macro(uline)
char *uline;
{
  char macro_block, macro_exist, tc;
  int cnt, ulen;

  macro_exist=FALSE;
  macro_block=FALSE;
  ulen=strlen(uline);
  for(cnt=0; cnt<ulen; cnt++)
  {
    if( !strncmp(uline+cnt, "{#", 2) )
      macro_block=TRUE;

    if( !strncmp(uline+cnt, "#}", 2) )
      macro_block=FALSE;

    if(macro_block)
    {
      tc=*(uline+cnt);
      if( tc=='c' || tc=='C' || tc=='p' || tc=='P' )
	*(uline+cnt)=' ';
      else
	macro_exist=TRUE;
    }

  }/*end for*/

  if( macro_block )	/*unfinished macro???*/
    strcat(uline, "#}");

  if( macro_exist )
    strcat(uline, "{#n#}");
}
/*end of strip_rude_macro*/
