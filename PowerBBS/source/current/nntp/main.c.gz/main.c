/* PBBSNNTP */
/*
PowerBBS InterChange Manager NNTP Server by Samson Chen, Team-Square-1991.
	V1.0 Apr 12, 1994
	V1.1 July 15, 1994
	V2.0 May 10,1995
	V2.2 Sep 5, 1995
*/
/*************************************************************************** 
 * Filename: main.c							   *
 * PBBS Interchange program via NNTP protocol (packing and transmitting)   *
 *	by Samson Chen, Apr 12, 1994					   *
 ***************************************************************************/

/*
	arguments:
		-d : debug mode, do not push process as daemon process

	exit code :
		0  = initial daemon OK
		1  = abnorlmal disconnect
		2  = pid lock error
		3  = main arguments error
		10 = err routine
		11 = fopen error
		30 = daemon initializing error
		31 = forking error
		40 = child running exit normally
*/

#include "../host/pbbs.h"

static char rcsid[]="$Id: main.c,v 1.19 1996/05/07 02:12:33 pbbs Exp pbbs $";

#define	MAX_SEND_A_TIME	7	/*number to send unsend msgpack a time*/
				/*this will prevent remote server from*/
				/*being heavy load after long disconnection*/

/*
	some global variables used in most modules
*/
char	debug_mode;		/*TRUE for debug mode*/
char	no_packing;		/*TRUE for skip packing message*/
char 	client_site[30];	/*store readable client address*/
int	max_station;		/*total linked stations*/
int	p_handle[16];		/*packing file handles*/
char	*sidbuf[16*30];
char	*station_id[16];	/*station_id*/
char	current_station[30];	/*station id of each process*/
char	xmit_error;		/*sending error flag, (maybe modify when SIGPIPE)*/
int	global_fd;		/*network fd for timeup()*/

/*
	main start here
*/
main(argc, argv)
int 	argc;
char 	*argv[];
{
	int	daemon_pid;
	char	ip[16];		/*target ip address*/
	char	port[6];	/*target port*/
	char	passwd[20];	/*link level*/
	char	sindex[10];	/*station index*/
	char	queuefile[80];	/*seending queue file*/
	int	station_order;
	int	fork_pid;
	int	sleep_counter;

	/*--- for sending token ---*/
	char token_file[80];
	int sending_lock;
	char pid[50];
	int ret, send_counter;
	/*-------------------------*/

	/*------------------*/
        char epack[255];
	struct dirent *dirp;
        DIR *dp;
	/*------------------*/

#ifndef	SYSV
	extern	int reaper();	/*for reapping child process*/
#endif
	extern	int timeup();	/*idle handling function*/
	extern	int write_close();	/*if we write to a socket that*/
				/*remote host has closed the connection*/
				/*SIGPIPE will be generated, program will*/
				/*be terminated, we must catch this signal*/


	if( !path_exist(SYSTEM_PATH) )
	{
		printf("\nSYSTEM_PATH '%s' not found!\n", SYSTEM_PATH);
		exit(30);
	}

	chdir(SYSTEM_PATH);

	/*******************************************************************/
	/*test necessary directories*/
	if( !path_exist(NNTP_QUEUE) )
	{
		printf("\nNNTP_QUEUE directory '%s' not found!\n", NNTP_QUEUE);
		exit(30);
	}
	/*******************************************************************/

	debug_mode=FALSE;
	no_packing=FALSE;

	if( argc>1 )
	{
		if( !strcmp(argv[1], "-d") ) debug_mode=TRUE;

		if( !strcmp(argv[1], "-n") )
		{
			debug_mode=TRUE;
			no_packing=TRUE;
		}

	}


	if( debug_mode )
		printf("\n Process is in debugging mode now...\n");
	else
	{
	  /*initial daemon*/
	  if( (daemon_pid=fork()) < 0 )
	  {
		  printf("initialize daemon error!\n");
		  exit(30);
	  }
	  if( daemon_pid > 0 )	/*parent goes bye-bye*/
	  {
		  sleep(1);
		  exit(0);
	  }
	  else			/*set daemon requirements up*/
	  {
		  setsid();
	  }
	} /*end of debug_mode*/
	/****************************************************/

	/*************/
	/*pid locking*/
	/*************/
	if( !lock_pid() )
	{
		printf(" pid locking error, maybe process has been run before!\n");
		do_log(9, "pid locking error, maybe process has been run before!");
		exit(2);
	}
	/*******************************************/

	/*change process runnung user id and group*/
	change_run_id();

	/*start log*/
	do_log(9, "PowerBBS NNTP Server Initialize");

	/*get group setup*/
	get_group_set();

	/********************************************************************/

	/*set signal for disconnected child*/
#ifndef	SYSV
	(void) signal(SIGCHLD, (void*)reaper);
#endif
#ifdef	SYSV
	(void) signal(SIGCHLD, SIG_IGN);
#endif


	/*********************************************************************/
	/*********************************************************************/
	do		/*forever loop*/
	{
		/*check unfinished packets in sending queue*/
		check_unfinished_pack();
 
		/*packing*/
		if( !no_packing )
			packing();

		for(station_order=0; station_order<max_station; station_order++)
		{
		  if(debug_mode) printf("(main.c)forking\n");
		  fork_pid=fork();	/*FORKing*/

		  if( fork_pid<0 )
		  {
			do_log(9, "FORKing error");
			exit(31);
		  }
		  else if( fork_pid==0 )	/*child*/
		  {

	/*********************************************************************/
			/*set idle signal*/
			(void) signal(SIGALRM, (void*)timeup);

			/*set broken pipe signal*/
			(void) signal(SIGPIPE, (void*)write_close);
	/*********************************************************************/

			get_station(station_order, ip, port, passwd, sindex);

			/*---------------------------------------*/
			strcpy(current_station, station_id[station_order]);

			if(debug_mode) printf("(main.c)get %s %s %s %s\n", ip, port, passwd, sindex);
			/*---------------------------------------------------*/

			/*getting the sending token*/
			sprintf(token_file, "%s/token.%s", NNTP_QUEUE, sindex);
			sprintf(pid, "PowerBBS NNTP Process %5d\n", getpid() );
			sending_lock=open(token_file, O_WRONLY | O_CREAT, S_IWUSR | S_IRUSR);
			ret=flock(sending_lock, LOCK_EX | LOCK_NB);  /*test locking*/

			if( ret<0 )
			{
				if(debug_mode) printf("(main.c)%s process in locking\n", sindex);
				exit(40);  /*open pid file error, lock exist*/
			}

			write(sending_lock, pid, strlen(pid) );
			if(debug_mode) printf("(main.c)%s get sending token ok\n", sindex);
			/*---------------------------------------------------*/

			xmit_error=FALSE;

			/*------------------------------------------------*/


			send_counter=0;
			while( TRUE )
			{

			  /*find earlist msg pack*/
			  epack[0]=0;

			  dp=opendir(NNTP_QUEUE);

			  while( (dirp = readdir(dp)) != NULL )
			  {
			    if( !strncmp(dirp->d_name, sindex, strlen(sindex)) )
			    {

				if( epack[0]==0 )
					strcpy(epack, dirp->d_name);
				else
				{
					if( strcmp(epack, dirp->d_name) > 0 )
						strcpy(epack, dirp->d_name);
				}

			    }/*end if(strncmp)*/
			  }/*end while(dirp)*/

			  closedir(dp);

			  if( epack[0]==0 )
				break;

			  if(debug_mode) printf("(main.c)get pack %s\n", epack);

			  do_sending(sindex, ip, port, passwd, epack);

			  if( xmit_error ) break;

			  /*this will prevent remote server from*/
			  /*being heavy load after long disconnection*/
			  send_counter++;
			  if( strcmp(passwd, "+" ) && strcmp(passwd, "*") )
			  {
			    if( send_counter>=MAX_SEND_A_TIME ) break;
			  }

			}/*end while*/


			/*------------------------------------------------*/

			/*release sending token*/
			flock(sending_lock, LOCK_UN);
			close(sending_lock);
			unlink(token_file);

			if(debug_mode) printf("(main.c)%s release sending token and exit\n", sindex);

			exit(40);

		  } /*end of chile*/

		}/*end for*/

		for(sleep_counter=0;sleep_counter<max_station;sleep_counter++)
		{
		  /*
			Some %$#^@ OS like AIX or OSF/1. The opendir will
			send an ALARM signal to parent process. This condition
			happened on combining using with wait3() and opendir()
			So that sleep() will be malfunction. We must re-catch
			that signal for this reason.
		  */

		  sleep(1);
		  if(debug_mode) printf("sleep alarm signal catched %d\n", sleep_counter);
		}

		if(debug_mode) printf("(main.c)parent sleep\n");
		sleep(NNTP_SLEEP);

	}while(1);	/*never ENDing loop*/


}
/*end of main*/

/*****************************************************************************/

/*
	reap child process which was ready to die
*/
#ifndef	SYSV
reaper()
{
	union wait status;

#ifndef ALPHA
	while(wait3((int*)&status, (int)WNOHANG, (struct rusage *)0) > 0);
#else
	while(wait3(&status, (int)WNOHANG, (struct rusage *)0) > 0);
#endif

}
#endif
/*end of reaper*/



/*
	reset_alarm --- reset alarm clock
*/
reset_alarm()
{
	alarm(NNTP_IDLE);
}
/*end of reset_alarm*/



/*
	stop_alarm --- stop alarm clock
*/
stop_alarm()
{
	alarm(0);
}
/*end of stop_alarm*/



/*
	timeup --- connection idle too long
*/
timeup()
{
	do_log(2, "idle too long");
	close(global_fd);
	exit(9);
}
/*end of timeup*/



/*
	write_close --- SIGPIPE catched
*/
write_close()
{
	if(debug_mode) printf("(main.c)catch SIGPIPE from %s\n", current_station);
	xmit_error=TRUE;
}
/*end of write_close*/
