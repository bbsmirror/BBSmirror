
/*connectTCP - TCP connection */

#include <varargs.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>

#include <netinet/in.h>

#include <netdb.h>

#ifndef INADDR_NONE
#define INADDR_NONE	0xffffffff
#endif


/*u_short htons();*/
u_long	inet_addr();

/**************************************************************/
int
connectTCP( host, service)
char *host;
int service;
/*
	return:
		fd: handle
		-1: error
*/
{
	struct hostent	*phe;
	struct servent	*pse;
	struct sockaddr_in	sin;
	int	s;

	bzero((char *)&sin, sizeof(sin));
	sin.sin_family=AF_INET;

	/*map port number*/
	if( (sin.sin_port=htons((u_short)service)) == 0 )
	{
		do_log(8, "TCP: can't get %d service entry", service);
		return(-1);
	}

	/*get IP address*/
	if( phe = gethostbyname(host) )
		bcopy(phe->h_addr, (char *)&sin.sin_addr, phe->h_length);
	else if( (sin.sin_addr.s_addr = inet_addr(host)) == INADDR_NONE )
	{
		do_log(8, "TCP: can't get %s host entry", host);
		return(-1);
	}

	/*allocate socket*/
	s = socket(PF_INET, SOCK_STREAM, 0);
	if(s<0)
	{
		do_log(8, "TCP: can't creat socket");
		return(-1);
	}

	/*connect the socket*/
	if(connect(s, (struct sockaddr *)&sin, sizeof(sin)) < 0)
	{
		do_log(8, "Service may not be available on %s.%d", host, service);
		return(-1);
	}

	return(s);
}
/*end of connectTCP*/
