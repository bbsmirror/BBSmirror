/*************************************************************************
 * sendfile.c --- send file to client					 *
 *	      by Aquarius Kuo, Apr 12, 1994				 *
 *            new filexfer protocol by Samson Chen Apr 14, 1995          *
 *	      CPPOST version May 5, 1995				 *
 *************************************************************************/

#include "../host/pbbs.h"
#include "global.h"

static char rcsid[]="$Id: sendfile.c,v 1.4 1995/09/01 11:20:33 pbbs Exp pbbs $";

/*
	send_file --- send a file to client site
*/
int send_file(fd, filename)
int fd;
char *filename;
/*
	return:
		TRUE:	OK
		FALSE:	failed
*/
{
  int handle ;
  int i ;
  char prot ;
  char fn[80], *ptr ;
  char buffer[11000] ;
  long BLOCK=1024 ;
  long len1, fcnt, flen;
  char first_byte;
    
  /*parsing filename*/
  ptr=filename+strlen(filename)-1 ;
  while((*ptr!='/') && (ptr!=filename))
    ptr-- ;
  
  ptr=(ptr==filename) ? ptr:ptr+1 ;  
  strcpy(fn,ptr) ;
  for(i=0; i<strlen(fn); i++)	/*--- check file name ---*/
  {
    if(fn[i]<33)
    {
      fn[i]=0 ;  
      break ;
    }  
  }  

  do_log(3, "(sendfile.c)%s send %s", current_station, filename);

  if((handle=open(filename,O_RDONLY))<0)      /* open upload file */
  {
    do_log(8, "(sendfile.c)open %s error", filename);
    return(FALSE) ;
  }

  /*read first byte of the file to test it*/
  if( read(handle, &first_byte, 1) <= 0 )
  {
    do_log(8, "(sendfile.c)read %s error", filename);
    return(FALSE) ;
  }

  /*send filename*/
  send_mpf(fd, fn, strlen(fn), FILEXFER);

  /*check ACK*/
  read_mpf(fd,buffer,&len1,&prot,FALSE) ;
  if(prot==STOPXFER)
  {
    do_log(3, "(sendfile.c)%s stop filexfer %s", current_station, filename);
    return(FALSE) ;
  }
  else if(prot!=XFER_ACK)
  {
    do_log(5, "(sendfile.c)%s send filexfer protocol state error(S1)", current_station);
    return(FALSE);
  }

  /*send file length*/
  flen=flength(filename) ;
  sprintf(buffer,"%ld",flen) ;
  send_mpf(fd,buffer,strlen(buffer),FILEXFER) ;

  /*check ACK*/
  read_mpf(fd,buffer,&len1,&prot,FALSE) ;
  if(prot==STOPXFER)
  {
    do_log(3, "(sendfile.c)%s stop filexfer %s", current_station, filename);
    return(FALSE) ;
  }
  else if(prot!=XFER_ACK)
  {
    do_log(5, "(sendfile.c)%s send filexfer protocol state error(S2)", current_station);
    return(FALSE);
  }

  /*send first byte of the file*/
  if( write(fd,&first_byte, 1) < 0 )
  {
	return(FALSE);
  }

  alarm(0);	/*turn alarm off*/

  /*send file until length flen*/
  fcnt=1;       /*include first byte*/
  while(fcnt<flen)
  {
    len1=read(handle, buffer, BLOCK);

    if( len1==0 )       /*eof*/
    {
	do_log(8, "(sendfile.c)%s filesize is not correct(underflow)!", filename);
	reset_alarm();
	return(FALSE);
        /*stop transmission to save network*/
        break;
    }

    if( len1 < 0 )      /*read error*/
    {
	do_log(8, "(sendfile.c)%s file read error!", filename);
	reset_alarm();
	return(FALSE);
        /*stop transmission to save network*/
        break;
    }

    if( len1 > (flen-fcnt) )
    {
	do_log(8, "(sendfile.c)%s filesize is not correct(overflow)!", filename);
        len1=flen-fcnt;
        /*continue last transmission*/
    }

    if( write(fd, buffer, len1) < 0 )
    {
	reset_alarm();
	return(FALSE);
    }

    fcnt += len1;

  }/*end while*/

  /*send SYNC*/
  buffer[0]=END_XFER;
  if( write(fd, buffer, 1) < 0 )
  {
	reset_alarm();
	return(FALSE);
  }

  alarm(IDLE_TIME * POST_FACTOR);	/*extent time to wait for sync*/

  /*SYNCHRONIZATION*/
  if( read(fd, buffer, 1)<0 )
  {
	reset_alarm();
	return(FALSE);
  }

  reset_alarm();

  /*check SYNC*/
  if( buffer[0]!=END_XFER )
  {
	do_log(5, "(sendfile.c)send %s synchronization error!", filename);
	return(FALSE);
  }

  /*send_file finished*/
  if(debug_mode) printf("(sendfile.c)send (%s) successfully\n", filename);

  return(TRUE);
}
/*end of send_file*/
