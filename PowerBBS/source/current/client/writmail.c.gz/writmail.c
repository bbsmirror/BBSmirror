#include "pbbs.h"
#include "msg.h"

static char rcsid[]="$Id: writmail.c,v 1.1 1995/11/11 08:47:27 pbbs Exp pbbs $" ;

int writer(buffer,editor) 
char *buffer ;
char *editor ;
{
  char fname[80],
       tmpbuf[101] ; 
  char tempfilename[80];
  int status ;
  FILE *fp ;
  
  struct stat f1, f2 ;

  if( success_then_remove )
  {
	/*maybe user re-edit, remove the old one*/
	unlink(s_t_r_filename);
	success_then_remove=FALSE;
  }
    
  strcpy(tmpbuf,tmpnam(NULL)) ;
 
  if((fp=fopen(tmpbuf,"w"))==NULL)
  {
    show("\nFile open error!!\n") ;
    readkey() ;
    return(FALSE) ;
  }
  fwrite(buffer,strlen(buffer),1,fp) ;
  fclose(fp) ;  
  
  stat(tmpbuf,&f1) ;
  strcpy(tempfilename, tmpbuf);
  
  sprintf(fname,"%s %s",editor,tmpbuf) ;
  
  if( term_mode ) alarm(USER_IDLE * USER_IDLE_FAC);
  status=system(fname);
  if( term_mode ) alarm(0);

  if(status<0)
  {
    show("\nCall editor error...!!\n") ;
    readkey() ;
    return(FALSE) ;
  }  
  else
  {
    stat(tmpbuf,&f2) ;
    
    if(f1.st_mtime==f2.st_mtime)
    {
      unlink(tmpbuf) ;
      return(FALSE) ;
    }
    strcpy(fname,tempfilename);
    if((fp=fopen(fname,"r"))==NULL)
    {
      show("\nfopen temp-file error!!\n") ;
      readkey() ;
      unlink(fname) ;
      return(FALSE) ;
    }
    else
    {
      buffer[0]=0 ;
      while(fgets(tmpbuf,100,fp)!=NULL)
      {
        tmpbuf[99]=0 ;
        if((strlen(buffer)+strlen(tmpbuf)+1024)<MAX_BUF)
        {
          strcat(buffer,tmpbuf) ;
          if(strlen(buffer)>MAX_MAIL_INPUT)
            break ;
        }
        else
          break ;  
      }
      buffer[strlen(buffer)]=0 ;
      fclose(fp) ;

      strcpy(s_t_r_filename, fname);
      success_then_remove=TRUE;
    }
  }
  return(TRUE) ;    
}
