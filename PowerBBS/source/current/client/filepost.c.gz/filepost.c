#include "pbbs.h"
#include "msg.h"

static char rcsid[]="$Id: filepost.c,v 1.1 1995/11/11 08:47:27 pbbs Exp pbbs $" ;

int get_file(fn,buf)
char *fn ;
char *buf ;
{
  FILE *fp ;
  char tmp[512] ;
  int c ;

  if((fp=fopen(fn,"r"))==NULL)
  {
    return(FALSE) ;
  }
  show("\n") ;
  
  c=0 ;
  while( (fgets(tmp,512,fp)!=NULL) && (c<MAX_MAIL_INPUT) )
  {
    show(tmp) ;
    c+=strlen(tmp) ;
    strcat(buf,tmp) ;
  }

  fclose(fp) ;
  if(c<1)
    return(FALSE) ;

  return(TRUE) ;
}
