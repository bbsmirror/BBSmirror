/*--- standard header for PBBS ---*/

#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef RS6K
#include <sys/select.h>
#endif

#ifndef NOMALLOC
#include <malloc.h>
#endif

#include <sys/resource.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/tcp.h>
#include <signal.h>
#include <errno.h>
#include <fcntl.h>
#include <ctype.h>
#include <memory.h>
#include <sys/file.h>

#include "protocol.h"

#define SALT    "SC"    /*internal use (salt for crypt function)*/

/*avoid redefine by other head files (eg. curses.h)*/
#ifndef TRUE
#define TRUE    -1
#endif

#ifndef FALSE
#define FALSE   0
#endif
/****************************************************/

#define MAX_BUF 102400
#define BACK_BUF 6144   /*6K*/
#define MAX_MAIL_INPUT  40960

#define PBBS_DEFAULT_SERVER     "140.126.3.111"     /* Jones */
#define PBBS_DEFAULT_PORT       6203
