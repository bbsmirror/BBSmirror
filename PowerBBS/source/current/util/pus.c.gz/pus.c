
/*
        PowerBBS Upgrade Service by Samson Chen, Dec 9, 1995
        rules:
         1. check DNS registration, if not reject
         2. if this address legal (address_filter)
         3. check ident, if not support reject
         4. check remote account, if unknown reject
         5. remote account cannot be bbs/pbbs/bb5 (remote_id_filter)
         6. get user's PBBS id, check if valid
         7. get user's password, check if correct
         8. check user's PBBS level, check if the level is allowed to use PUS
         9. check user's last name from lastname databank

        ps. lastname databank can be created by the shell script 'generate_lndb'
*/

#include <varargs.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <malloc.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/tcp.h>
#include <signal.h>
#include <errno.h>
#include <fcntl.h>
#include <ctype.h>
#include <memory.h>
#include <sys/file.h>
#include <netdb.h>
#include <pwd.h>
#include <grp.h>

#include "../setup.h"
#include "../host/dbf.h"

#ifndef FALSE
#define FALSE	0
#endif

#ifndef TRUE
#define TRUE	!FALSE
#endif


#ifndef INADDR_NONE
#define INADDR_NONE	0xffffffff
#endif

#define	SALT	"SC"

/*.................................................................*/

/*If not define STANDALONE, then default is INETD*/
/*The value of STANDALONE is the listening port  */
/*
#define	STANDALONE		5203
*/

#define LEVEL_ALLOW_USE_PUS     30
#define	LEVEL_UPGRADE_TO	40
#define	STATION_TITLE		"�諰��T�� PowerBBS �۰ʤɯŨt��"

#define PUS_IDLE_TIME		600

int nfdr;       /*network fd for read(input)*/
int nfdw;       /*network fd for write(output)*/


/*
        do logging --- (as the name)
*/
do_log(loglevel, logformat, va_alist)
        int loglevel;
        char *logformat;
        va_dcl
{
        char timing[50];
        char buffer[620];
        char logmsg[600];
        FILE *logfile;

        /*get arguments list*/
        va_list args;
        va_start(args);
        vsprintf(logmsg, logformat, args);
        va_end(args);

        get_daytime(timing);
        sprintf(buffer, "%s,%d> ", timing, loglevel);

        strcat(buffer, logmsg);

        if(loglevel>=LOGLEVEL)
        {
                logfile = fopen(LOGFILE, "a+");
                fprintf(logfile, "%s\n", buffer);
                fclose(logfile);
        }

        if(loglevel>=EXTRA_LOG_LEVEL)
        {
                logfile = fopen(EXTRA_LOG, "a+");
                fprintf(logfile, "%s\n", buffer);
                fclose(logfile);
        }
}
/*end of do_log*/



/*
        print formated message to network fd
*/
net_printf(netfd, netformat, va_alist)
        int netfd;
        char *netformat;
        va_dcl
{
        char logmsg[600];

        /*get arguments list*/
        va_list args;
        va_start(args);
        vsprintf(logmsg, netformat, args);
        va_end(args);

        write(netfd, logmsg, strlen(logmsg));
}
/*end of net_printf*/



/*********************************************************************/
main()
{
  int daemon_pid, fork_pid;
  int clilen, sockfd, newsockfd;
  struct sockaddr_in cli_addr;
  struct servent *pse;
  int remote_port, local_port;
  char remote_add[128], remote_id[128];
  char bbs_name[64];
  int n, i, bbs_uid;
  char passwd[128], pwbuffer[20];
  struct udb udb;

  extern int pus_timeup();	/*idle handling function*/

#ifdef STANDALONE
#  ifndef SYSV
  extern int reaper();		/*for reapping child process*/
#  endif

  /*....................initial daemon.........................*/
  if( (daemon_pid=fork()) < 0 )
  {
    printf("initialize daemon error!\r\n");
    exit(13);
  }
  if( daemon_pid > 0 )	/*parent goes bye-bye*/
  {
	  sleep(1);
	  exit(0);
  }
  else			/*set daemon requirements up*/
  {
	  setsid();
  }

  /* allocate socket file descriptor */
  sockfd = getsockfd();

  /*change process runnung user id and group*/
  change_run_id();

  /*************/
  /*set signals*/
  /*************/
  /*set signal for disconnected child*/
#  ifndef SYSV
     (void) signal(SIGCHLD, (void*)reaper);
#  endif
#  ifdef SYSV
     /*Just make SIGCHLD ignoed on System V*/
     (void) signal(SIGCHLD, SIG_IGN);
#  endif

  /* listenning */
  if( listen(sockfd, SOMAXCONN)<0 )
  {
    printf("PUS.C: listen error!\r\n");
    exit(14);
  }

  /* big-loop for taking services */
  while(TRUE)
  {
    clilen = sizeof(cli_addr);
    newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);

    if (newsockfd < 0)
      continue;

    fork_pid=fork();

    if( fork_pid<0 )
    {
      net_printf(newsockfd, "Fork error!\r\n");
      sleep(3);
      close(newsockfd);
      continue;
    }

    /*child*/
    if( fork_pid==0 )
    {
      nfdr=newsockfd;
      nfdw=newsockfd;
      break;
    }

    /*parent*/
    close(newsockfd);

  }/*end while*/
#endif	/*SYANDALONE*/

#ifndef STANDALONE
  nfdr=fileno(stdin);
  nfdw=fileno(stdout);
#endif

  net_printf(nfdw, "PowerBBS Upgrade Service V1.0 by Samson Chen, Dec 9, 1995\r\n");
  net_printf(nfdw, "%s\r\n\r\n", STATION_TITLE);

  (void) signal(SIGALRM, (void*)pus_timeup);
  alarm(PUS_IDLE_TIME);

  /*chdir to SYSTEM_PATH*/
  if( !path_exist(SYSTEM_PATH) )
  {
    net_printf(nfdw, "SYSTEM_PATH '%s' not found!\r\n", SYSTEM_PATH);
    net_printf(nfdw, "Please inform SysOp!\r\n");
    sexit(10);
  }
  chdir(SYSTEM_PATH);

#ifdef STANDALONE
  local_port=STANDALONE;
#endif
#ifndef STANDALONE
  /*get local port number by name 'pus/tcp'*/
  if( pse=getservbyname("pus", "tcp") )
    local_port=ntohs((u_short)pse->s_port);
  else
  {
    net_printf(nfdw, "getservbyname() ERROR! Please inform SysOp!\r\n");
    sexit(11);
  }
#endif

  /*rule 1*/
  remote_port=get_remote_host(nfdr, remote_add);
  if(remote_port==0)
  {
    net_printf(nfdw, "�z�����ϥΦb DNS �W�����U���u�@���s�W�~�i�ϥ�!\r\n");
    sexit(1);
  }

  /*rule 2*/
  if( !address_filter(remote_add) )
  {
    net_printf(nfdw, "��p, ������������ '%s'\r\n", remote_add);
    net_printf(nfdw, "      �s�J���u�@���ϥΥ��\\��!\r\n");
    sexit(2);
  }

  /*rule 3 and rule 4*/
  if( !get_remote_id(remote_add, remote_port, local_port, remote_id) )
  {
    net_printf(nfdw, "��p, �z�ҳs�J���u�@���å��䴩 ident ��w,\r\n");
    net_printf(nfdw, "�]���L�k�ϥΥ��\\��, �д������䴩 ident ��w\r\n");
    net_printf(nfdw, "���u�@���s�J, �γq���z�u�@�����t�κ޲z���w��\r\n");
    net_printf(nfdw, "ident ��w, ����.\r\n");
    net_printf(nfdw, "�Y�O�]�������L�C�ӵL�k���\\�s�J�Q�u�@���� ident\r\n");
    net_printf(nfdw, "�t�Χ@�T�{, �Ыݺ����t������ɦA���ϥΥ��\\��.\r\n");
    sexit(3);
  }

  /*rule 5*/
  if( !remote_id_filter(remote_id) )
  {
    net_printf(nfdw, "��p, �z�ثe���b��(%s)\r\n", remote_id);
    net_printf(nfdw, "      ����Χ@�s�J���t��!\r\n");
    sexit(5);
  }

  /*rule 6*/
  net_printf(nfdw, "**�Ъ`�N, �ФťN���L�H�ϥΦ۰ʤɯŨt��, �@���H�k\r\n");
  net_printf(nfdw, "  �����ƤΦD�Ƴd���ҥѨϥΦ۰ʤɯŨt�Τ��ϥΪ̭t\r\n");
  net_printf(nfdw, "  �d, �n�D�ɯŤ��ϥΪ̭Y�L�u�@���b��, �еo�H����\r\n");
  net_printf(nfdw, "  ���n�D�H�u�ɯ�, �q�аt�X, ����.\r\n\r\n");
  net_printf(nfdw, "�п�J�z�� BBS ID...\r\n");
  net_getline(nfdr, bbs_name, 64);
  bbs_name[0]=toupper(bbs_name[0]) ;
  for(n=1; n<strlen(bbs_name); n++)
  {
    if(bbs_name[n]==32)
    {
	n++ ;
	bbs_name[n]=toupper(bbs_name[n]) ;
    }
    else
    {
	bbs_name[n]=tolower(bbs_name[n]) ;
    }
  }
  bbs_uid=get_user_id(bbs_name);
  if( bbs_uid<=0 )
  {
    net_printf(nfdw, "��p, �������䤣��z�� ID(%s)\r\n", bbs_name);
    sexit(6);
  }
  net_printf(nfdw, "\r\n");

  /*rule 7*/
  net_printf(nfdw, "�п�J�z���K�X(�`�N:�K�X�|��ܥX��)...\r\n");
  net_getline(nfdr, passwd, 128);

  nstrcpy(pwbuffer, passwd, 20);
  for(i=strlen(pwbuffer); i<10; i++)
    pwbuffer[i]=59+i*2 ;
  pwbuffer[10]=0 ;
  for(i=1; i<=10; i++)
  {
    pwbuffer[i-1]=(char) ((((pwbuffer[i-1]+pwbuffer[10-i])*67)%91)+32) ;
  }

  n=strlen(passwd);
  memset(passwd, '*', n);
  passwd[n]=0;
  net_printf(nfdw, "%c[A\r%s\r\n", 27, passwd);

  if( !get_user_data(&udb, bbs_uid) )
  {
    net_printf(nfdw, "User database error! Please inform SysOp!\r\n");
    sexit(7);
  }

  if( strcmp( udb.password, crypt(pwbuffer, SALT) ) )
  {
    net_printf(nfdw, "�K�X���~!\r\n");
    sexit(7);
  }
  net_printf(nfdw, "\r\n");

  /*rule 8*/
  if( udb.level != LEVEL_ALLOW_USE_PUS )
  {
    net_printf(nfdw, "��p, ���t�Υu�A�X������ %d �� user �ϥ�!\r\n", LEVEL_ALLOW_USE_PUS);
    sexit(8);
  }

  /*rule 9*/
  if( !check_lastname(bbs_name) )
    sexit(9);

  /*all ok*/
  do_log(8, "(%s) use PUS from %s@%s successfully", bbs_name, remote_id, remote_add);
  udb.level=LEVEL_UPGRADE_TO;
  sprintf(udb.pus_add, "%s@%s", remote_id, remote_add);
  set_user_data(&udb, bbs_uid);
  net_printf(nfdw, "���߱z�w�����ɯ�! �A���W�u�K�i�ϥηs����!\r\n");
  sexit(0);

}/*end of main*/
/*********************************************************************/


/*XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
/*
        remote address filter
*/
address_filter(address)
char *address;
/*
        return: TRUE:   address ok
                FALSE:  banned address
*/
{
  if( strstr(address, "dialup" ) ) return(FALSE);
  if( strstr(address, "DIALUP" ) ) return(FALSE);

  /*add rude workstation addresses as c coded by yourself*/
  return(TRUE);
}
/*end of address_filter*/



/*
        remote id filter
*/
remote_id_filter(rid)
char *rid;
/*
        return: TRUE:   address ok
                FALSE:  banned id
*/
{
  if( !strcasecmp(rid, "bbs") ) return(FALSE);
  if( !strcasecmp(rid, "bb5") ) return(FALSE);
  if( !strcasecmp(rid, "pbbs") ) return(FALSE);

  /*add rude id as c coded by yourself*/
  return(TRUE);
}
/*end of remote_id_filter*/



/*
	check if legal last name
*/
check_lastname(bbs_name)
char *bbs_name;
/*
	return: TRUE:	OK
		FALSE:  failed! (error message show here)
*/
{
  char cln[20];
  int len, cnt, ret;
  int lndb;

  cln[0]=0;
  len=strlen(bbs_name);
  for(cnt=0; cnt<len; cnt++)
    if( bbs_name[cnt]==' ' )
    {
      strcpy(cln, bbs_name+cnt+1);
      break;
    }

  if( cln[0]!=0 )
  {
    lndb=open("lastname.db", O_RDONLY);
    if( lndb<=0 )
    {
      net_printf("'lastname.db' open error! please inform SysOp!\r\n");
      return(FALSE);
    }
    close(lndb);

    if( found_ln(cln) )
      return(TRUE);
  }/*end if(cln)*/

  /*check failed*/
  net_printf(nfdw, "��p, �z�� Lastname�j�m(%s)�������ŦX�����۰ʤɯŪ���h!\r\n", cln);
  net_printf(nfdw, "�нT�w�z���m�󳡥��Où��������Ķ(�p'��'�� Chen),\r\n");
  net_printf(nfdw, "�Y���O�бz���s���� ID ���U, �� ID �t�αN�|�۰ʧR��,\r\n");
  net_printf(nfdw, "�z�i�ۧG�i�椺��� lastname �ݬݥثe�����ǦX�k�m�����,\r\n");
  net_printf(nfdw, "�Y�z���m�󥼦b������Ʈw��, �Цb�����H�ϵo�H�q������!\r\n");
  return(FALSE);
}
/*end of check_lastname*/
/*XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/



/*
	get day and time
*/
get_daytime(buffer)
	char *buffer;	/*CAUTION: buffer must has it's own space befor
				   calling*/
{
	struct	tm	*timeptr;
	time_t		secsnow;

	time(&secsnow);
	timeptr = localtime(&secsnow);

	sprintf(buffer, "%#02d/%#02d,%#02d:%#02d", timeptr->tm_mon+1, timeptr->tm_mday , timeptr->tm_hour, timeptr->tm_min);
}
/*end of daytime*/



/*
        get_remote_host --- get remote host domain name and port number
        (code from NCSA httpd)
*/
get_remote_host(fd, remote)
        int fd;         /*network fd*/
        char *remote;   /*the domain name*/
/*
        return:
                (domain name put in *remote), return(remote_port_number)
                if failed, (remote hist not registered), return(0)
*/
{
  struct sockaddr addr;
  int len;
  struct in_addr *iaddr;
  struct hostent *hptr;
  int remote_port=0;

  len = sizeof(struct sockaddr);

  if ((getpeername(fd, &addr, &len)) < 0)
        return(0);

  remote_port = ntohs(((struct sockaddr_in *)&addr)->sin_port);
  iaddr = &(((struct sockaddr_in *)&addr)->sin_addr);
  hptr = gethostbyaddr((char *)iaddr, sizeof(struct in_addr), AF_INET);
  if(hptr)
  {
        strcpy(remote, hptr->h_name);
        return(remote_port);
  }
  else
  {
        strcpy(remote, inet_ntoa(*iaddr));
        return(0);
  }
}
/*end of get_remote_host*/



/*
        test if the path exist or not
*/
path_exist(pathname)
char *pathname;
{
        int ret;
        struct stat buf;

        ret=stat(pathname, &buf);

        if( ret<0 )
                return(FALSE);  /*path not exist*/

        if( (buf.st_mode & S_IFDIR)==0 )
                return(FALSE);  /*not a path*/

        return(TRUE);
}
/*end of path_exist*/


/*
        make a TCP connection
*/
int connectTCP(host, service)
char *host;
int service;
/*
        return:
                >0      : fd
                -1      : failed
*/
{
        struct hostent  *phe;
        struct servent  *pse;
        struct sockaddr_in      sin;
        int     s;
        char ebuf[256];

        bzero((char *)&sin, sizeof(sin));
        sin.sin_family=AF_INET;

        /*map port number*/
        if( (sin.sin_port=htons((u_short)service)) == 0 )
                return(-1);

        /*get IP address*/
        if( phe = gethostbyname(host) )
                bcopy(phe->h_addr, (char *)&sin.sin_addr, phe->h_length);
        else if( (sin.sin_addr.s_addr = inet_addr(host)) == INADDR_NONE )
                return(-1);

        /*allocate socket*/
        s = socket(PF_INET, SOCK_STREAM, 0);
        if(s<0)
                return(-1);

        /*connect the socket*/
        if(connect(s, (struct sockaddr *)&sin, sizeof(sin)) < 0)
                return(-1);

        return(s);
}
/*end of connectTCP*/



/*
        get a line from network fd
        CR-LF will be stripped
*/
net_getline(fd, line, len)
int fd;
char *line;
int len;
/*
        return: >0 <length>
               <=0 network error
*/
{
  char *p;
  int ret, p_cnt;
  int get_len, n;

  p=line;
  ret=0;
  p_cnt=0;
  do {
    p+=ret;
    p_cnt+=ret;

    get_len=len-p_cnt-1; /*reserve space for \0*/
    if(get_len<=0) break;

    ret=read(fd, p, get_len);
    p[ret]=0;
    if( ret<=0 ) return(-1);
  }while( p[ret-1]!=10 );

  /*strip CRLF*/
  for(n=0; n<strlen(line); n++)
    if( line[n]==13 || line[n]==10 )
    {
      line[n]='\0';
      break;
    }

  return(strlen(line));
}
/*end of net_getline*/



/*
        get remote account id by ident protocol
*/
get_remote_id(remote_host, remote_port, local_port, account_id)
char *remote_host;
int remote_port;
int local_port;
char *account_id;
/*
        return: TRUE:   ident successful
                FALSE:  failed(connection failed or remote not support ident
*/
{
  int ident_fd;
  char ident_res[128], buf[128];
  char *token;

  ident_fd=connectTCP(remote_host, 113);
  if( ident_fd<0 ) return(FALSE);

  net_printf(ident_fd, "%d, %d%c%c", remote_port, local_port, 0xd, 0xa);
  if( net_getline(ident_fd, ident_res, 128)<=0 )
    return(FALSE);
  close(ident_fd);

  /* xxxx , yyyy : USERID : UNIX : <account_id>*/

  /* xxxx , yyyy */
  token=strtok(ident_res, ":");
  if( token==NULL ) return(FALSE);

  /*USERID*/
  token=strtok(NULL, ":");
  if( token==NULL ) return(FALSE);
  strcpy(buf, token);
  alltrim(buf);
  if( strcmp(buf, "USERID") ) return(FALSE);

  /*UNIX*/
  token=strtok(NULL, ":");
  if( token==NULL ) return(FALSE);

  /*<account_id>*/
  token=strtok(NULL, ":");
  if( token==NULL ) return(FALSE);
  strcpy(buf, token);
  alltrim(buf);

  strcpy(account_id, buf);
  return(TRUE);
}
/*end of get_remote_id*/


  
/*
	blank trim by KKY
*/
int alltrim(str)
char *str ;
/*******************************************
    return     0   : if NULL string
	    length : the new strlen.
********************************************/
{
  int i=0 ;

    while((*(str+i)==32) || (*(str+i)==9))
    {
      i++ ;
    }
    memcpy(str,(str+i),strlen(str)-i+1) ;

    i=strlen(str)-1 ;
    while(((*(str+i)==32) || (*(str+i)==9)  || (*(str+i)==10)) && (i>=0))
    {
      i-- ;
    }
    *(str+i+1)=0 ;

    return(strlen(str)) ;
}
/*end of alltrim*/



/*
	flength --- get length of a file
*/
long flength(filename)
	char *filename;
{
	int test;
	struct stat buf;

	test=open(filename, O_RDONLY);
	fstat(test, &buf);
	close(test);

	return(buf.st_size);
}
/*end of flength*/



/*
	test if the file exist or not
*/
file_exist(filename)
char *filename;
/*
	return: TRUE: exist
		FALSE: not exist
*/
{
	FILE *testexist;

	if( (testexist=fopen(filename, "r")) == NULL)
		return(FALSE);		/*not found*/
	else	/*file found*/
	{
		fclose(testexist);
		return(TRUE);
	}
}
/*end of file_exist*/



/*
	get_user_id --- get user id from user database
*/
get_user_id(name)
	char *name;	/*bbs_name not real name*/
/*
	return:
		user id number
		note: uid >= 1, because 0 means user not found
*/
{
	char udbfile[255];
	int udbf;
	int ret;


	/*test user database file*/
	sprintf(udbfile, "%s.dbf", USER_DATA_BASE);

	if( !file_exist(udbfile) )
	{
		udbf=open( udbfile, O_WRONLY | O_APPEND | O_CREAT, S_IWUSR | S_IRUSR);
		close(udbf);
		return(0);	/*no such user*/
	}

	/*index search*/
	ret=found(name);
	if(ret==FALSE) return(0);

	return(ret);
}
/*end of get_user_id*/



/*
	nstrcpy --- some stange STRING hate strcpy... also size control is
		    needed
*/
nstrcpy(t, s, ms)
	char *t;	/*target*/
	char *s;	/*source*/
	int ms; 	/*max size*/
{
	int cpn;

	for(cpn=0; cpn<ms; cpn++)
	{
		t[cpn]=s[cpn];

		if(s[cpn]==0)
			break;
	}

	t[ms-1]=0;
}
/*end of nstrcpy*/



/*
	get_user_data --- get user data record
*/
get_user_data(dbr, uid)
	struct udb *dbr;
	int uid;
/*
	return:
		TRUE:	OK
		FALSE:	no such user id
*/
{
	char udbfile[255];
	int udbf;
	int ret;

	sprintf(udbfile, "%s.dbf", USER_DATA_BASE);
	udbf = open(udbfile, O_RDWR);
	lseek( udbf, uid*sizeof(struct udb), SEEK_SET);

	ret=read(udbf, dbr, sizeof(struct udb));

	close(udbf);

	if( ret<sizeof(struct udb) ) return(FALSE);
	else return(TRUE);
}
/*end of get_user_data*/



/*
	set_user_data --- set user data record
*/
set_user_data(dbr, uid)
	struct udb *dbr;
	int uid;
{
	char udbfile[255];
	int udbf;
	int ret;

	sprintf(udbfile, "%s.dbf", USER_DATA_BASE);
	udbf = open(udbfile, O_RDWR);
	lseek( udbf, uid*sizeof(struct udb), SEEK_SET);

	write(udbf, dbr, sizeof(struct udb));

	close(udbf);
}
/*end of set_user_data*/



/*
	sleep then exit
*/
sexit(ret_code)
int ret_code;
{
  sleep(5);
  close(nfdw);
  close(nfdr);
  exit(ret_code);
}
/*end of sexit*/



/*
	idle too long
*/
pus_timeup()
{
  net_printf(nfdw, "�ϥΥ��t�λݭn %d ������???\r\n", PUS_IDLE_TIME/60);
  sexit(12);
}
/*end of pus_timeup*/


#ifdef STANDALONE
/*
	get socket file descriptor
*/
getsockfd()
{
	int	sockfd;
	struct 	sockaddr_in serv_addr;
	int	on=1;

	/* open a TCP socket for internet stream socket */
	if( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		err("Server: cannot open stream socket");

	/* bind our local address */
	bzero((char *)&serv_addr, sizeof(serv_addr));
	serv_addr.sin_family	= AF_INET;
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_addr.sin_port	= htons(STANDALONE);

	/* set socket option --- reuseaddr */
	(void) setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on));

	/* set socket option --- keep connection alive */
	(void) setsockopt(sockfd, SOL_SOCKET, SO_KEEPALIVE, (char *)&on, sizeof(on));

	if( bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) <0)
		err("server: cannot bind local address");

	return(sockfd);
}
/*end of getsockfd*/



/********************/
/*err :  Fault Exit */
/********************/
err(errmsg)
char *errmsg;
{
	printf(" %s\n", errmsg);
	exit(20);
}
/*end of err*/



/*
	change_run_id --- change process running id
*/
change_run_id()
{
	int user_id, group_id;

	if( !strcmp(RUN_USER, "OWNER") || !strcmp(RUN_GROUP, "OWNER") )
		return;

	user_id=getuidbyname(RUN_USER);
	group_id=getgidbyname(RUN_GROUP);

	if( user_id<0 || group_id<0 )
		return;

	/*set log file permission first*/
	if( file_exist(LOGFILE) )
		chown(LOGFILE, (uid_t) user_id, (gid_t) group_id);

	/*set gid then uid*/
	setgid((gid_t) group_id);

	setuid((uid_t) user_id);
}
/*end of change_run_id*/



/*
	getuidbyname --- get system uid by RUN_USER
*/
getuidbyname(name)
	char *name;
{
	struct passwd *ent;

	if( name[0]=='#' )
		return(atoi(name+1));

	ent=getpwnam(name);

	if( !ent )
		return(-1);
	else
		return(ent->pw_uid);

}
/*end of getuidbyname*/



/*
	getgidbyname --- get system group id by RUN_GROUP
*/
getgidbyname(name)
	char *name;
{
	struct group *ent;

	if( name[0]=='#' )
		return(atoi(name+1));

	ent=getgrnam(name);

	if( !ent )
		return(-1);
	else
		return(ent->gr_gid);

}
/*end of getgidbyname*/



/*
	reap child process which was ready to die
*/
#ifndef	SYSV
reaper()
{
	union wait status;

#ifndef ALPHA
        while(wait3((int*)&status, (int)WNOHANG, (struct rusage *)0) > 0);
#else
        while(wait3(&status, (int)WNOHANG, (struct rusage *)0) > 0);
#endif    
}
#endif
/*end of reaper*/

#endif	/*STANDALONE*/
