/**********************************************************
        build new mbox records by Samson Chen. Apr 4, 1995
***********************************************************/
#include "../host/pbbs.h"
#include "../host/dbf.h"
#include "../setup.h"
#include <ctype.h>

#define MAXLB     240

char    debug_mode=TRUE;

struct msgrec_old	{
	unsigned long	offset;		/*message offset*/
	unsigned int	length;		/*message length*/
	char		packed;		/*packed for xfer*/
	char		delete_mark;
};



/*========================================================*/
main(argc,argv)
int argc ;
char *argv[] ;
{
  char mbox_path[256], ppath[256];
  int keeps;
  long user_no;
  struct dirent *dirp;
  DIR *dp;

  chdir(SYSTEM_PATH) ;

  sprintf(mbox_path,"%s/mbox", MAIL_PATH);

  /*-------------------------------------*/
  /*stage ONE, remove all null mbox files*/
  /*-------------------------------------*/
  if( debug_mode )
    printf("check null mbox files...\n");

  dp=opendir(mbox_path);
  while( (dirp = readdir(dp)) != NULL )
  {
        strcpy(ppath, dirp->d_name);
        if( !strcmp(ppath, ".") || !strcmp(ppath, "..") )
                continue;

        user_no=get_msg_uid(ppath);
	if(user_no<=0)
		continue;

        remove_null(user_no);
  }
  closedir(dp);

  /*---------------------------*/
  /*stage TWO, rebuild msg file*/
  /*---------------------------*/
  /*
    note: 1. purge message file
          2. count
          3. set del mark if msgs is over keeps
    ps. msg is deleted today, it will be purged tomorrow
  */
  if( debug_mode )
    printf("\nrebuild mbox records...\n");

  dp=opendir(mbox_path);
  while( (dirp = readdir(dp)) != NULL )
  {
        strcpy(ppath, dirp->d_name);
        if( !strcmp(ppath, ".") || !strcmp(ppath, "..") )
                continue;

        user_no=get_msg_uid(ppath);
	if(user_no<=0)
		continue;

        rebuild(user_no);
  }
  closedir(dp);

  if( debug_mode )
    printf("\n");
}
/*end of main*/



/*
        get_msg_uid --- get user id if filename is (uid.messages)
*/
get_msg_uid(filename)
char *filename;
/*
        return:
                0 : not a message file
               >0 : the user who the message file belong to
*/
{
  char fn[256];
  int flen;

  if( strlen(filename) < 10 )   /*minimum length (1.messages)*/
    return(0);

  strcpy(fn, filename);
  flen=strlen(fn);

  if( strcmp(".messages", filename+flen-9) )
    return(0);

  fn[flen-9]=0;

  return(atoi(fn));
}
/*end of get_msg_uid*/



/*
        remove_null --- check user mbox file, if null, remove it
*/
remove_null(uid)
int uid;
{
  char mpath[256], rpath[256];

  sprintf(mpath, "%s/mbox/%d.messages", MAIL_PATH, uid);
  sprintf(rpath, "%s/mbox/%d.records", MAIL_PATH, uid);

  /*not null, return*/
  if( flength(mpath)>0 )
    return;

  if( debug_mode )
    printf(" %d.messages : ", uid);

  if( user_on_line(uid) )
  {
    if( debug_mode )
      printf("user on line now, skip it\n");
  }
  else
  {
    unlink(rpath);
    unlink(mpath);
    set_lastread(uid, 0);

    if( debug_mode )
      printf("removed\n");
  }

}
/*end of remove_null*/



/*
        user_on_line --- if user uid on line now
*/
user_on_line(uid)
int uid;
/*
        return:
                TRUE : user uid on-line now
                FALSE: user uid not on-line now
*/
{
        int utf;
        struct putmp purec;

        if( !file_exist(ON_LINE_USER) )
          return(FALSE);

        utf=open(ON_LINE_USER, O_RDONLY, S_IWUSR | S_IRUSR);

        if( utf<0 )
          return(FALSE);

        while( read(utf, &purec, sizeof(struct putmp) ) )
          if( purec.active )
            if( purec.uid==uid )
              return(TRUE);

        close(utf);

        return(FALSE);

}
/*end of user_on_line*/



/*
        test if the path exist or not
*/
path_exist(pathname)
char *pathname;
{
        int ret;
        struct stat buf;

        ret=stat(pathname, &buf);

        if( ret<0 )
                return(FALSE);  /*path not exist*/

        if( (buf.st_mode & S_IFDIR)==0 )
                return(FALSE);  /*not a path*/

        return(TRUE);
}
/*end of path_exist*/



/*
    get file length
    write by Aquarius Kuo.
*/
long flength(filename)
char *filename ;
{
  struct stat file_status ;

  stat(filename,&file_status) ;
  return(file_status.st_size) ;
}
/*end of flength*/



/*
        file_exist
*/
file_exist(filename)
char *filename;
/*
        return: TRUE: exist
                FALSE: not exist
*/
{
        FILE *testexist;

        if( (testexist=fopen(filename, "r")) == NULL)
                return(FALSE);          /*not found*/
        else    /*file found*/
        {
                fclose(testexist);
                return(TRUE);
        }
}
/*end of file_exist*/


/*
        rebuild only the messages which were marked deleted
*/
rebuild(uid)
int uid;
{
  char fn[MAXLB], buf[MAX_BUF] ;
  char mesg[MAXLB], reco[MAXLB], reco2[MAXLB];
  char *ptr ;
  long i, j, m, n, tmp, cnt, offset ;
  int hm, hr, hu, ht1, ht2 ;            /* file handle */
  int f_err=0 ;
  struct msgrec recno ;
  struct msgrec_old recno_old;
  long real_keep ;

  if( debug_mode )
    printf("scan %d\r", uid);

  sprintf(mesg,"%s/mbox/%d.messages",MAIL_PATH,uid) ;
  sprintf(reco,"%s/mbox/%d.records",MAIL_PATH,uid) ;
  sprintf(reco2,"%s/mbox/%d.records.old",MAIL_PATH,uid) ;

  if( !file_exist(mesg) || !file_exist(reco) )
  {
        if( file_exist(mesg) )
                unlink(mesg);

        if( file_exist(reco) )
                unlink(reco);

        return;
  }

  rename(reco, reco2);

  i=0;       /*--- i: old file pointer ---*/

  if( (hm=open(mesg,O_RDONLY))<0 )
    return;

  if((hr=open(reco2,O_RDONLY))<0)
    return;

  if((hu=open(reco,O_WRONLY|O_CREAT|O_TRUNC|O_APPEND,S_IWUSR | S_IRUSR))<0)
      return ;

  flock(hm,LOCK_EX) ;
  flock(hr,LOCK_EX) ;
  flock(hu,LOCK_EX) ;

    while(read(hr,&recno_old,sizeof(struct msgrec_old))>0)
    {
      recno.delete_mark=recno_old.delete_mark;
      recno.length=recno_old.length;
      recno.offset=recno_old.offset;
      recno.packed=recno_old.packed;

      /*find subject*/
      lseek(hm, recno_old.offset, SEEK_SET);
      fetch_msg_head(hm, recno_old.length, buf);
      ptr=buf+9+parse_msg(buf, "Subject: ");
      strip_nl(ptr);
      nstrcpy(recno.subject, ptr, 60);

      write(hu,&recno,sizeof(struct msgrec)) ;       /* tmp for record */
      i++;
    }

  flock(hm,LOCK_UN) ;
  flock(hr,LOCK_UN) ;
  flock(hu,LOCK_UN) ;
  close(hm) ;
  close(hr) ;
  close(hu);

  if( debug_mode )
    printf("\n");

  return;
}
/*end of rebuild*/


/*
	fetch_msg_head --- fetch only message head
*/
fetch_msg_head(msgfd, max_length, buffer)
	int msgfd;	/*message file fd (must lseek before call)*/
	unsigned int max_length;	/*message total length*/
	char *buffer;
{
	int fetch_head;
	int fetch_section;
	char *fetch_pointer;
	char *check_pointer;
	char first_section=TRUE;
	int n;
	int ret;
	char ebuf[256];

	if( max_length<FETCH_HEAD_SIZE )
	{
		ret=read(msgfd, buffer, max_length);

		if( ret<0 )
		{
		  printf("SYSTEM ERROR read error\n");
		  exit(12);
		}

		buffer[ret]=0;
	}
	else
	{
		fetch_head=0;
		fetch_section=FETCH_HEAD_SIZE;
		fetch_pointer=buffer;

		do
		{
		  check_pointer=fetch_pointer;

		  ret = read(msgfd, fetch_pointer, fetch_section);

		  if( ret<0 )
		  {
		    printf("SYSTEM ERROR read error");
		    exit(12);
		  }

		  fetch_head += ret;
		  fetch_pointer += ret;
		  buffer[fetch_head]=0;


		  /*check if head found*/

		  if( !first_section )
		  {
			if( *(check_pointer-2)==0xd && *check_pointer==0xd )
				break;

			if( *(check_pointer-1)==0xd && *(check_pointer+1)==0xd )
				break;
		  }

		  for(n=0; n<(strlen(check_pointer)-2); n++)
		  {
			if( (check_pointer[n]==check_pointer[n+2]) && (check_pointer[n]==0xd) )
				return;
		  }


		  /*count next fetch section size*/

		  if( (max_length-fetch_head)<fetch_section )
			fetch_section=(max_length-fetch_head);

		  first_section=FALSE;

		} while( fetch_section>0 );

	}/*end if-else*/
}
/*end of fetch_msg_head*/



/*
	strip_nl --- strip cr-lf
*/
strip_nl(buf)
	char *buf;
{
	int n;
	int len;

	len=strlen(buf);

	for(n=0; n<len; n++)
		if( buf[n]==0 || buf[n]==13 || buf[n]==10 )
		{
			buf[n]=0;
			break;
		}
}
/*end of strip_nl*/



/*
	nstrcpy --- some stange STRING hate strcpy... also size control is
		    needed
*/
nstrcpy(t, s, ms)
	char *t;	/*target*/
	char *s;	/*source*/
	int ms; 	/*max size*/
{
	int cpn;

	for(cpn=0; cpn<ms; cpn++)
	{
		t[cpn]=s[cpn];

		if(s[cpn]==0)
			break;
	}

	t[ms-1]=0;
}
/*end of nstrcpy*/



parse_msg(msg, phead)
	char *msg;	/*original message text*/
	char *phead;	/*parsing head, if "MSG" means message body*/
/*
	return:
		position of the parsed head
		-1 means not found

	note: after parsing, the *msg will NOT be destroyed
*/
{
	char buf[1024];
	char *point;
	char head=TRUE;
	int n,p;
	int fp;

	/*
	if(debug_mode) printf("(parsemsg.c)parse_msg '%s'\n", phead);
	*/

	point=msg;
	n=0;

	do
	{
	  /*find a line*/
	  for(p=n;p<strlen(msg);p++)
		if( msg[p]==13 ) break;

	  if( p>=strlen(msg) )
	  {
		return(-1);
	  }

	  /*CR-LF-CR-LF appeared, head field finished*/
	  if( n==p )
	  {
		head=FALSE;

		if( !strcmp(phead, "MSG") )
			fp=n;
		else
			fp=-1;

		continue;
	  }

	  /*cut a line*/
	  strncpy(buf, msg+n, p-n);
	  buf[p-n]=0;

	  /*parse line*/
	  if( !strncmp(buf, phead, strlen(phead) ) )
	  {
		head=FALSE;
		fp=n;
		continue;
	  }


	  n=p+2;  /*skip CR-LF*/

	}while(head);

	/*
	if(debug_mode) printf("(parsemsg.c)return fp=%d\n", fp);
	*/

	return(fp);
}
/*end of parse_msg*/



/*
        set_lastread --- set user last read
*/
set_lastread(uid, lr)
        int uid;
        int lr;         /*new lastread number*/
{
        char userlr_filename[80];
        int user_lr;
	int records;

        sprintf(userlr_filename, "%s/mbox/users", MAIL_PATH);

        if( !file_exist(userlr_filename) )
          return;

        records=flength(userlr_filename)/sizeof(int);

        /*the user never comes here*/
        if( records < (uid+1) )
          return;

        user_lr=open(userlr_filename, O_RDWR);
        if(user_lr<0)
          return;

        if(lr<0)
                lr=0;

        lseek(user_lr, uid*sizeof(int), SEEK_SET);
        write(user_lr, &lr, sizeof(int) );

        close(user_lr);
}
