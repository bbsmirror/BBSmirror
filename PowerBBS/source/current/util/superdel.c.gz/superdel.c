/**************************************************
	Super Deletion Utility by Samson Chen
	Nov, 24, 1994
***************************************************/
#include "../host/pbbs.h"
#include "../host/dbf.h"
#include "../setup.h"
#include <ctype.h>

#define MAXLB     240

char	debug_mode=FALSE;

struct skip_struc {
	char	path[60];
	struct	skip_struc *next;
	};

struct skip_struc *skips_head, *skips_point, *skips_tmp;

/*
	del msgs if total msgs are over reserve
	(make delete mark only, should be scanpurge after this operation)
*/
do_del(dir, reserve)
char *dir ;
int reserve;
{
  char fn[MAXLB];
  char mesg[MAXLB], reco[MAXLB], user[MAXLB] ;
  long i;
  int hr;
  int total_msg, del_no;
  struct msgrec recno ;

  if( debug_mode )
    printf("scan %s\r", dir);

  if( (dir[0]==0) )      /* NULL string */
    return(1) ;

  if( !strcmp(dir,"mbox") )   /* personal mail box */
    return(1) ;

  sprintf(fn,"%s/%s",MAIL_PATH,dir) ;    /* fn is the current area path */

  sprintf(mesg,"%s/messages",fn) ;
  sprintf(reco,"%s/records",fn) ;
  sprintf(user,"%s/users",fn) ;

  if( !file_exist(mesg) || !file_exist(reco) )
  {
	return(1);
  }

  if((hr=open(reco,O_RDWR))<0)
  {
    back_up_err_msg(dir);
    return(1) ;
  }

  flock(hr,LOCK_EX) ;
  total_msg=flength(reco)/sizeof(struct msgrec) ;     /* n=record number */
  if( total_msg>reserve )
  {

    del_no=total_msg-reserve;

    for(i=0; (i<total_msg) && (i<del_no); i++)
    {
      lseek(hr,i*sizeof(struct msgrec),SEEK_SET) ;
      if( read(hr,&recno,sizeof(struct msgrec))<=0 )
	break;

      if(recno.delete_mark=='D')	/*has been deleted*/
	continue;

      if(recno.delete_mark=='C')	/*cream post*/
	continue;

      if( debug_mode )
	printf("%s: delete #%d         \r", dir, i);

      recno.delete_mark='D';
      lseek(hr, i*sizeof(struct msgrec), SEEK_SET);
      write(hr, &recno, sizeof(struct msgrec) );
    }

  }/*end if*/

  flock(hr,LOCK_UN) ;
  close(hr) ;

  return(0) ;
}
/*end of do_del*/



/*
	get_skip_set --- get skip set up file
*/
get_skip_set(skipfilename)
	char *skipfilename;
{
  FILE *skipfile;
  char line[255];
  int n, ret;
  char *includefile;

  skipfile=fopen(skipfilename, "r");
  while( fgets(line, 127, skipfile) )
  {
	  if( !strncmp(line, "#include", 8) )
	  {
		includefile=strtok(line, "<");
		if( includefile!=NULL )
		{
			includefile=strtok(NULL, ">");
			if( includefile!=NULL )
			{
				if( debug_mode )
				  printf("include skip set file: %s\n", includefile);
				get_skip_set(includefile);
			}
		}
		continue;
	  }

	  for(n=0; n<strlen(line); n++)
		if( line[n]=='#' || line[n]==9 || line[n]==0xd || line[n]==0xa || line[n]==' ' || line[n]==0 )
		{
			line[n]=0;
			break;
		}

	  ret=strlen(line);
	  if( ret<2 )
		continue;

	  skips_tmp=(struct skip_struc *)malloc(sizeof(struct skip_struc));
	  strcpy(skips_tmp->path, line);
	  skips_tmp->next=NULL;

	  if( skips_head )
	  {
		skips_point->next=skips_tmp;
		skips_point=skips_point->next;
	  }
	  else
	  {
		skips_head=skips_tmp;
		skips_point=skips_head;
	  }

  }/*end while*/
  fclose(skipfile);

}
/*end of get_skip_set*/



/*========================================================*/
main(argc,argv)
int argc ;
char *argv[] ;
{
  char skip_set[255];
  int keep_no;
  char skip_this;
  char ppath[255];
  char purgepath[255];
  struct dirent *dirp;
  DIR *dp;

  chdir(SYSTEM_PATH) ;

  if(argc<3)
  {
	printf("\n");
	printf(" usage: %s <skip_set_file> <keep_number> {-d:debug}\n", argv[0]);
	printf("\n");
	exit(1);
  }

  if(argc>3)
  {
	if( !strcmp(argv[3], "-d") )
		debug_mode=TRUE;
  }

  strcpy(skip_set, argv[1]);
  keep_no=atoi(argv[2]);

  if( debug_mode )
  {
	printf("\n");
	printf("PowerBBS Super Deletion Utility by Samson Chen, Nov, 24, 1994\n");
	printf("skip set file: %s, keep %d msgs\n", skip_set, keep_no);
  }

  if( !file_exist(skip_set) )
  {
	printf(" skip_set file '%s' not found!\n", skip_set);
	exit(3);
  }

  if( keep_no<=0 )
  {
	printf(" keep no msg (0) ???\n");
	exit(3);
  }


  /* fetch skip set file */
  skips_head=skips_point=NULL;
  get_skip_set(skip_set);
  /***********************/

  if( debug_mode )
	printf("\n");

  dp=opendir(MAIL_PATH);

  while( (dirp = readdir(dp)) != NULL )
  {
	strcpy(ppath, dirp->d_name);
	if( !strcmp(ppath, ".") || !strcmp(ppath, "..") )
		continue;

	if( !strcmp(ppath, "cancelmsg") )
		continue;	/*skip cancelmsg del*/

	/*check if skip*/
	skips_point=skips_head;
	skip_this=FALSE;
	while(skips_point)
	{
		if( !strcmp(ppath, skips_point->path) )
		{
			skip_this=TRUE;
			break;
		}
		skips_point=skips_point->next;
	}
	if(skip_this)
		continue;
	/**********************************************/

	do_del(ppath, keep_no);

	if( debug_mode ) printf("\n");
  }

  closedir(dp);
  
}
/*end of main*/



/*
	test if the path exist or not
*/
path_exist(pathname)
char *pathname;
{
	int ret;
	struct stat buf;

	ret=stat(pathname, &buf);

	if( ret<0 )
		return(FALSE);	/*path not exist*/

	if( (buf.st_mode & S_IFDIR)==0 )
		return(FALSE);	/*not a path*/

	return(TRUE);
}
/*end of path_exist*/



/*
    get file length
    write by Aquarius Kuo.
*/
long flength(filename)
char *filename ;
{
  struct stat file_status ;
  
  stat(filename,&file_status) ;
  return(file_status.st_size) ;
}
/*end of flength*/



/*
	file_exist
*/
file_exist(filename)
char *filename;
/*
        return: TRUE: exist
                FALSE: not exist
*/
{
        FILE *testexist;

        if( (testexist=fopen(filename, "r")) == NULL)
                return(FALSE);          /*not found*/
        else    /*file found*/
        {
                fclose(testexist);
                return(TRUE);
        }
}
/*end of file_exist*/



/*
	remove old *.bak, rename current one to *.bak
*/
back_up_err_msg(area)
char *area;
{
  char mpath[256], source[256], target[256];

  sprintf(mpath, "%s/%s", MAIL_PATH, area);

  sprintf(source, "%s/messages", mpath);
  sprintf(target, "%s/messages.bak", mpath);
  rename(source, target);

  sprintf(source, "%s/records", mpath);
  sprintf(target, "%s/records.bak", mpath);
  rename(source, target);

  sprintf(source, "%s/users", mpath);
  sprintf(target, "%s/users.bak", mpath);
  if( file_exist(source) )
    rename(source, target);

  printf(" superdel.c : '%s' message files error, backup files created...\n", area);
  printf(" 		try 'rebuild_msg_rec %s' utility!\n", area);
}
/*end of back_up_err_msg*/
