/**************************************************
    rm_old.c : remove files which are too old
    by Samson Chen, Jan 8, 1996
***************************************************/
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <fcntl.h>
#include <ctype.h>

#ifndef FALSE
#define	FALSE	0
#endif

#ifndef TRUE
#define	TRUE	!FALSE
#endif 


/*========================================================*/
main(argc,argv)
int argc ;
char *argv[] ;
{
  char ppath[255], rpath[255], rfile[512];
  struct stat stat_buf;
  struct dirent *dirp;
  DIR *dp;
  /* long ex_time; */
  time_t ex_time;
  char debug_mode=FALSE;

  if( argc!=3 && argc!=4 )
  {
	printf("\n");
	printf(" Remove files which are too old!\n");
	printf(" by Samson Chen, Jan 8, 1996\n");
	printf(" usage:\n");
	printf("	%s <rm dir> <expired days> {-d:verbose}\n", argv[0]);
	printf("\n");
	exit(1);
  }

  if(argc>3)
  {
	if( !strcmp(argv[3], "-d") )
		debug_mode=TRUE;
  }

  if( atoi(argv[2])<=0 )
  {
	printf("\n");
	printf("rm_old.c: <expired days> must be greater than ZERO!\n");
	printf("\n");
	exit(2);
  }

  time(&ex_time);
  ex_time-=(long)(atoi(argv[2])*24*60*60);

  strcpy(rpath, argv[1]);
  dp=opendir(rpath);

  while( (dirp = readdir(dp)) != NULL )
  {
	strcpy(ppath, dirp->d_name);
	if( !strcmp(ppath, ".") || !strcmp(ppath, "..") )
		continue;

	sprintf(rfile, "%s/%s", rpath, ppath);
	if( path_exist(rfile) ) continue;

	stat(rfile, &stat_buf);
	if( stat_buf.st_mtime<ex_time )
	{
	  if( debug_mode ) printf("unlink '%s'\n", rfile);
	  unlink(rfile);
	}
  }

  closedir(dp);
  
}
/*end of main*/



/*
	test if the path exist or not
*/
path_exist(pathname)
char *pathname;
{
	int ret;
	struct stat buf;

	ret=stat(pathname, &buf);

	if( ret<0 )
		return(FALSE);	/*path not exist*/

	if( (buf.st_mode & S_IFDIR)==0 )
		return(FALSE);	/*not a path*/

	return(TRUE);
}
/*end of path_exist*/
