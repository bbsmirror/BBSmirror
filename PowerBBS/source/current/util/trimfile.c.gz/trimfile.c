/******************************************************************
        trimfile.c --- trim file with useless space at line end
        by Jones Tsai May 20, 1996
******************************************************************/

#include <stdio.h>
#define	FALSE	0
#define TRUE	!FALSE

main(argc, argv)
        int argc;
        char *argv[];
{
	FILE 	*infp, *outfp;
	char	line[1024];
	int	len;

        if( argc<3  )
        {
                printf("\n");
                printf("trimfile parameters error!\n");
                printf("\n");
                printf("  usage: %s <input_filename> <output_filename>\n\n", argv[0]);

                exit(1);
        }

        if( !file_exist(argv[1]) )
	 {
		printf("\n\no%s not found!!\n\n",argv[1]);
                exit(-1);
 	 }


	if( (infp=fopen(argv[1],"r")) == NULL)
	 {
		printf("\n\nopen %s file error!!\n\n",argv[1]);
		exit(-1);
	 }
  
	if( (outfp=fopen(argv[2],"w")) == NULL)
         {
                printf("\n\nopen %s file error!!\n\n",argv[2]);
                exit(-1);
         }                 

        while ( fgets(line, 1024, infp) )
	 {
		len = trim_line_end(line);
		fprintf( outfp, "%s\n", line);
	 }
	
	fclose(infp);
	fclose(outfp);
}



/*
        test if the file exist or not
*/
file_exist(filename)
char *filename;
/*
        return: TRUE: exist
                FALSE: not exist
*/
{
        FILE *testexist;

        if( (testexist=fopen(filename, "r")) == NULL)
                return(FALSE);          /*not found*/
        else    /*file found*/
        {
                fclose(testexist);
                return(TRUE);
        }
}
/*end of file_exist*/    

/*
        trim_line_end --- trim the line end with useless space (add by Jones)
*/
int trim_line_end(str)
char *str ;
/*******************************************
    return     0   : if NULL string
            length : the new strlen.
********************************************/
{
  int i=0 ;

    i=strlen(str)-1 ;
    while(((*(str+i)==32) || (*(str+i)==9)  || (*(str+i)==10)) && (i>=0))
    {
      i-- ;
    }
    *(str+i+1)=0 ;

    return(strlen(str)) ;
}
/*end of trim_line_end*/ 
