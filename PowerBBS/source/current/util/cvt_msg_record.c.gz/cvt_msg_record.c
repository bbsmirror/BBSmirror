/**************************************************
    Old messages record file to new style record
    write by Samson Chen, Nov 1, 1995
***************************************************/
#include "../host/pbbs.h"
#include "../host/dbf.h"
#include "../setup.h"
#include <ctype.h>

#define	MAXLB	240
#define	MAX_MAP	1000	/*max num of lastread map*/

char	debug_mode=FALSE;

struct msgrec_old	{
	unsigned long	offset;		/*message offset*/
	unsigned int	length;		/*message length*/
	char		packed;		/*packed for xfer*/
	char		delete_mark;
};


/*
	build new record file
*/
build_new_record(dir)
char *dir ;
{
  char fn[MAXLB];
  char mesg[MAXLB], reco[MAXLB], reco2[MAXLB] ;
  char *ptr ;
  long i ;
  int hm, hr, hu ;            /* file handle */
  struct msgrec_old recno_old ;
  struct msgrec recno;
  char buf[20480];


  if( (dir[0]==0) )      /* NULL string */
  {
    return(1) ;
  }

  if(debug_mode)
    printf("%s\r", dir);

  if( !strcmp(dir,"mbox") )   /* personal mail box */
  {
    return(1) ;
  }

  sprintf(fn,"%s/%s",MAIL_PATH,dir) ;    /* fn is the current area path */

  sprintf(mesg,"%s/messages",fn) ;
  sprintf(reco,"%s/records",fn) ;
  sprintf(reco2,"%s/records.old",fn) ;

  if( !file_exist(mesg) || !file_exist(reco) )
	return(1);

  rename(reco, reco2);

  if( (hm=open(mesg,O_RDONLY))<0 )
    return(1) ;

  if((hr=open(reco2,O_RDONLY))<0)
    return(1) ;

  if((hu=open(reco,O_WRONLY|O_CREAT|O_TRUNC|O_APPEND,S_IWUSR | S_IRUSR))<0)
      return(1) ;

  flock(hm,LOCK_EX) ;
  flock(hr,LOCK_EX) ;
  flock(hu,LOCK_EX) ;

  i=0;
  printf("%s: 0\r", dir);

    while(read(hr,&recno_old,sizeof(struct msgrec_old))>0)
    {
      recno.delete_mark=recno_old.delete_mark;
      recno.length=recno_old.length;
      recno.offset=recno_old.offset;
      recno.packed=recno_old.packed;

      /*find subject*/
      lseek(hm, recno_old.offset, SEEK_SET);
      fetch_msg_head(hm, recno_old.length, buf);
      ptr=buf+9+parse_msg(buf, "Subject: ");
      strip_nl(ptr);
      nstrcpy(recno.subject, ptr, 60);

      write(hu,&recno,sizeof(struct msgrec)) ;       /* tmp for record */
      i++;

      if( debug_mode )
        if( (i%5)==0 )
	  printf("%s: %d\r", dir, i);
    }

  flock(hm,LOCK_UN) ;
  flock(hr,LOCK_UN) ;
  flock(hu,LOCK_UN) ;
  close(hm) ;
  close(hr) ;
  close(hu) ;

  return(0) ;
}

/*========================================================*/
main(argc,argv)
int argc ;
char *argv[] ;
{
  char ppath[255];
  char purgepath[255];
  struct dirent *dirp;
  DIR *dp;

  chdir(SYSTEM_PATH) ;

  debug_mode=TRUE;

  dp=opendir(MAIL_PATH);

  while( (dirp = readdir(dp)) != NULL )
  {
	strcpy(ppath, dirp->d_name);
	if( !strcmp(ppath, ".") || !strcmp(ppath, "..") )
		continue;

	build_new_record(ppath);

	if( debug_mode )
		printf("\n");
  }

  closedir(dp);
  
}
/*end of main*/



/*
	test if the path exist or not
*/
path_exist(pathname)
char *pathname;
{
	int ret;
	struct stat buf;

	ret=stat(pathname, &buf);

	if( ret<0 )
		return(FALSE);	/*path not exist*/

	if( (buf.st_mode & S_IFDIR)==0 )
		return(FALSE);	/*not a path*/

	return(TRUE);
}
/*end of path_exist*/



/*
    get file length
    write by Aquarius Kuo.
*/
long flength(filename)
char *filename ;
{
  struct stat file_status ;
  
  stat(filename,&file_status) ;
  return(file_status.st_size) ;
}
/*end of flength*/



/*
	file_exist
*/
file_exist(filename)
char *filename;
/*
        return: TRUE: exist
                FALSE: not exist
*/
{
        FILE *testexist;

        if( (testexist=fopen(filename, "r")) == NULL)
                return(FALSE);          /*not found*/
        else    /*file found*/
        {
                fclose(testexist);
                return(TRUE);
        }
}
/*end of file_exist*/


/*
	fetch_msg_head --- fetch only message head
*/
fetch_msg_head(msgfd, max_length, buffer)
	int msgfd;	/*message file fd (must lseek before call)*/
	unsigned int max_length;	/*message total length*/
	char *buffer;
{
	int fetch_head;
	int fetch_section;
	char *fetch_pointer;
	char *check_pointer;
	char first_section=TRUE;
	int n;
	int ret;
	char ebuf[256];

	if( max_length<FETCH_HEAD_SIZE )
	{
		ret=read(msgfd, buffer, max_length);

		if( ret<0 )
		{
		  printf("SYSTEM ERROR read error\n");
		  exit(12);
		}

		buffer[ret]=0;
	}
	else
	{
		fetch_head=0;
		fetch_section=FETCH_HEAD_SIZE;
		fetch_pointer=buffer;

		do
		{
		  check_pointer=fetch_pointer;

		  ret = read(msgfd, fetch_pointer, fetch_section);

		  if( ret<0 )
		  {
		    printf("SYSTEM ERROR read error");
		    exit(12);
		  }

		  fetch_head += ret;
		  fetch_pointer += ret;
		  buffer[fetch_head]=0;


		  /*check if head found*/

		  if( !first_section )
		  {
			if( *(check_pointer-2)==0xd && *check_pointer==0xd )
				break;

			if( *(check_pointer-1)==0xd && *(check_pointer+1)==0xd )
				break;
		  }

		  for(n=0; n<(strlen(check_pointer)-2); n++)
		  {
			if( (check_pointer[n]==check_pointer[n+2]) && (check_pointer[n]==0xd) )
				return;
		  }


		  /*count next fetch section size*/

		  if( (max_length-fetch_head)<fetch_section )
			fetch_section=(max_length-fetch_head);

		  first_section=FALSE;

		} while( fetch_section>0 );

	}/*end if-else*/
}
/*end of fetch_msg_head*/



/*
	strip_nl --- strip cr-lf
*/
strip_nl(buf)
	char *buf;
{
	int n;
	int len;

	len=strlen(buf);

	for(n=0; n<len; n++)
		if( buf[n]==0 || buf[n]==13 || buf[n]==10 )
		{
			buf[n]=0;
			break;
		}
}
/*end of strip_nl*/



/*
	nstrcpy --- some stange STRING hate strcpy... also size control is
		    needed
*/
nstrcpy(t, s, ms)
	char *t;	/*target*/
	char *s;	/*source*/
	int ms; 	/*max size*/
{
	int cpn;

	for(cpn=0; cpn<ms; cpn++)
	{
		t[cpn]=s[cpn];

		if(s[cpn]==0)
			break;
	}

	t[ms-1]=0;
}
/*end of nstrcpy*/



parse_msg(msg, phead)
	char *msg;	/*original message text*/
	char *phead;	/*parsing head, if "MSG" means message body*/
/*
	return:
		position of the parsed head
		-1 means not found

	note: after parsing, the *msg will NOT be destroyed
*/
{
	char buf[1024];
	char *point;
	char head=TRUE;
	int n,p;
	int fp;

	/*
	if(debug_mode) printf("(parsemsg.c)parse_msg '%s'\n", phead);
	*/

	point=msg;
	n=0;

	do
	{
	  /*find a line*/
	  for(p=n;p<strlen(msg);p++)
		if( msg[p]==13 ) break;

	  if( p>=strlen(msg) )
	  {
		return(-1);
	  }

	  /*CR-LF-CR-LF appeared, head field finished*/
	  if( n==p )
	  {
		head=FALSE;

		if( !strcmp(phead, "MSG") )
			fp=n;
		else
			fp=-1;

		continue;
	  }

	  /*cut a line*/
	  strncpy(buf, msg+n, p-n);
	  buf[p-n]=0;

	  /*parse line*/
	  if( !strncmp(buf, phead, strlen(phead) ) )
	  {
		head=FALSE;
		fp=n;
		continue;
	  }


	  n=p+2;  /*skip CR-LF*/

	}while(head);

	/*
	if(debug_mode) printf("(parsemsg.c)return fp=%d\n", fp);
	*/

	return(fp);
}
/*end of parse_msg*/
