/**************************************************
    Purge mail. redo mail data base
    write by Aquarius Kuo  July 5, 1994.
***************************************************/
#include "../host/pbbs.h"
#include "../host/dbf.h"
#include "../setup.h"
#include <ctype.h>

#define	MAXLB	240
#define	MAX_MAP	1000	/*max num of lastread map*/

char	debug_mode=FALSE;


/*
	purge only the messages which were marked deleted
*/
purge_data(dir)
char *dir ;
{
  char fn[MAXLB], buf[MAX_BUF+10240] ;
  char mesg[MAXLB], reco[MAXLB], user[MAXLB] ;
  char *ptr ;
  long i, j, m, n, tmp, cnt, offset ;
  int hm, hr, hu, ht1, ht2 ;            /* file handle */
  int f_err=0 ;
  struct msgrec recno ;
  long real_keep ;
  unsigned int map_lastread[MAX_MAP];	/*one to one map to last MAX_MAP posts*/
  unsigned int low_mark, high_mark, map_del, total_del;

/*
  ...| map slots ......(last MAX_MAP lastread slots) |
    low_mark					high_mark
     ^................map_del.....................^
  ^...................total_del...................^

   this make last MAX_MAP lastread record map correctly after purging
*/

  if( debug_mode )
    printf("scan %s\r", dir);

  if( (dir[0]==0) )      /* NULL string */
  {
    return(1) ;
  }

  if( !strcmp(dir,"mbox") )   /* personal mail box */
  {

    return(1) ;
  }

  sprintf(fn,"%s/%s",MAIL_PATH,dir) ;    /* fn is the current area path */

  sprintf(mesg,"%s/messages",fn) ;
  sprintf(reco,"%s/records",fn) ;
  sprintf(user,"%s/users",fn) ;

  if( !file_exist(mesg) || !file_exist(reco) )
  {
	return(1);
  }

  m=flength(mesg) ;
  n=flength(reco)/sizeof(struct msgrec) ;     /* n=record number */

  if( n<=MAX_MAP )
  {
    low_mark=0;
    if(n>0)
      high_mark=n-1;
    else
      high_mark=0;
  }
  else
  {
    low_mark=n-MAX_MAP;
    high_mark=n-1;
  }
  map_del=0;

  i=0;       /*--- i: old file pointer ---*/
  
  if( (hm=open(mesg,O_RDWR))<0 )
  {
    printf("scanpurge.c: %s open error!!\r\n",mesg) ;
    fflush(stdout) ;
    back_up_err_msg(dir);
    return(1) ;
  }

  if((hr=open(reco,O_RDWR))<0)
  {
    close(hm) ;
    back_up_err_msg(dir);
    return(1) ;
  }

  if((hu=open(user,O_RDWR))<0)
  {
    if((hu=open(user,O_CREAT|O_RDWR|O_TRUNC,S_IWUSR | S_IRUSR))<0)
    {
      printf("scanpurge.c: can't set users file '%s' !!\n\r", user) ;
      fflush(stdout) ;
      close(hm) ;
      close(hr) ;
      return(1) ;
    }
  }

  flock(hm,LOCK_EX) ;
  flock(hr,LOCK_EX) ;
  flock(hu,LOCK_EX) ;

    lseek(hr,i*sizeof(struct msgrec),SEEK_SET) ;

    j=0 ;   /*--- j: new file pointer ---*/
    offset=0 ;

    while(read(hr,&recno,sizeof(struct msgrec))>0)
    {
      if( (recno.offset>m) )      /* records error */
      {
        ftruncate(hm,0) ;
        ftruncate(hr,0) ;
        ftruncate(hu,0) ;
        f_err=1 ;
        break ;
      }

      if(i>=low_mark && i<=high_mark)
      {
	map_lastread[i-low_mark]=j;
        if(recno.delete_mark=='D') map_del++;
      }

      if(recno.delete_mark=='D')      /* deleted post */
      {
        i++ ;
        lseek(hr,i*sizeof(struct msgrec),SEEK_SET) ;
        continue ;
      }

      if( i==j )
      {
        i++ ;
        j++ ;
        offset+=recno.length ;
        lseek(hr,i*sizeof(struct msgrec),SEEK_SET) ;
	continue;	/*same pointer, does need to be moved*/
      }

      if( debug_mode )
	printf("%s: #%d --> #%d        \r", dir, i, j);

      if( recno.length>(MAX_BUF-128) )
      {
	printf(" scanpurge.c: huge record found in '%s', action #%d-->#%d\n", dir, i, j);
	recno.length=MAX_BUF-256;
      }

      lseek(hm,recno.offset,SEEK_SET) ;
      read(hm,buf,recno.length) ;             /* move one message to tmp */

      lseek(hm,offset,SEEK_SET) ;
      write(hm,buf,recno.length) ;

      recno.offset=offset ;
      offset+=recno.length ;

      lseek(hr,j*sizeof(struct msgrec),SEEK_SET) ;
      write(hr,&recno,sizeof(struct msgrec)) ;       /* tmp for record */

      i++ ;
      j++ ;
      lseek(hr,i*sizeof(struct msgrec),SEEK_SET) ;
    }

    real_keep=j;
    total_del=n-real_keep;

    if( !f_err )
    {
      ftruncate(hm,offset) ;
      ftruncate(hr,j*sizeof(struct msgrec)) ;


      if( read(hu,&tmp,sizeof(int))<sizeof(int) )
      {
        ftruncate(hu,0) ;
      }
      else
      {
        j=1 ;
        lseek(hu,j*sizeof(int), SEEK_SET) ;

        while( read(hu,&tmp,sizeof(int))==sizeof(int) )
        {
	  if( tmp>=low_mark && tmp<=high_mark )
	    tmp=map_lastread[tmp-low_mark];
	  else if( tmp>high_mark )
	    tmp=real_keep;
	  else	/*tmp<low_mark*/
	  {
	    if( total_del>map_del )
	      tmp-=total_del-map_del;
	  }

	  if( tmp>real_keep )
	    tmp=real_keep ;

          if( tmp<0 )
            tmp=0 ;

          lseek(hu,j*sizeof(int), SEEK_SET) ;
          write(hu,&tmp,sizeof(int)) ;
          j++ ;

          lseek(hu,j*sizeof(int), SEEK_SET) ;

        }
      }
    }

  flock(hm,LOCK_UN) ;
  flock(hr,LOCK_UN) ;
  flock(hu,LOCK_UN) ;
  close(hm) ;
  close(hr) ;
  close(hu) ;

  return(0) ;
}

/*========================================================*/
main(argc,argv)
int argc ;
char *argv[] ;
{
  char ppath[255];
  char purgepath[255];
  struct dirent *dirp;
  DIR *dp;

  chdir(SYSTEM_PATH) ;

  if(argc>1)
  {
	if( !strcmp(argv[1], "-d") )
		debug_mode=TRUE;
  }

  dp=opendir(MAIL_PATH);

  while( (dirp = readdir(dp)) != NULL )
  {
	strcpy(ppath, dirp->d_name);
	if( !strcmp(ppath, ".") || !strcmp(ppath, "..") )
		continue;

	purge_data(ppath);

	if( debug_mode )
		printf("\n");
  }

  closedir(dp);
  
}
/*end of main*/



/*
	test if the path exist or not
*/
path_exist(pathname)
char *pathname;
{
	int ret;
	struct stat buf;

	ret=stat(pathname, &buf);

	if( ret<0 )
		return(FALSE);	/*path not exist*/

	if( (buf.st_mode & S_IFDIR)==0 )
		return(FALSE);	/*not a path*/

	return(TRUE);
}
/*end of path_exist*/



/*
    get file length
    write by Aquarius Kuo.
*/
long flength(filename)
char *filename ;
{
  struct stat file_status ;
  
  stat(filename,&file_status) ;
  return(file_status.st_size) ;
}
/*end of flength*/



/*
	file_exist
*/
file_exist(filename)
char *filename;
/*
        return: TRUE: exist
                FALSE: not exist
*/
{
        FILE *testexist;

        if( (testexist=fopen(filename, "r")) == NULL)
                return(FALSE);          /*not found*/
        else    /*file found*/
        {
                fclose(testexist);
                return(TRUE);
        }
}
/*end of file_exist*/



/*
	remove old *.bak, rename current one to *.bak
*/
back_up_err_msg(area)
char *area;
{
  char mpath[256], source[256], target[256];

  sprintf(mpath, "%s/%s", MAIL_PATH, area);

  sprintf(source, "%s/messages", mpath);
  sprintf(target, "%s/messages.bak", mpath);
  rename(source, target);

  sprintf(source, "%s/records", mpath);
  sprintf(target, "%s/records.bak", mpath);
  rename(source, target);

  sprintf(source, "%s/users", mpath);
  sprintf(target, "%s/users.bak", mpath);
  if( file_exist(source) )
    rename(source, target);

  printf(" scanpurge.c : '%s' message files error, backup files created...\n", area);
  printf(" 		 try 'rebuild_msg_rec %s' utility!\n", area);
}
/*end of back_up_err_msg*/
