
/******************************************************************
        autopost.c --- PowerBBS auto local file poster
        by Samson Chen Oct 28, 1994
******************************************************************/

#include "../host/pbbs.h"
#include "../host/dbf.h"
#include "../setup.h"

main(argc, argv)
        int argc;
        char *argv[];
{
        char post_subject[80];
        char from_name[20];
        char unique_id[20];
        char message_id[128];
        char timebuf[35];
        char buf[255];
        char mfile[80], rfile[80];
        int msgfile, recfile;
        struct msgrec mr;
        int inport;
        int ret;
        int test;
        int msg_counter, continue_next;
        int subject_counter;
	char find_d=FALSE, od=0xd;
	long outcnt;
	char dup_last_buf=FALSE, last_buf[256];
	int last_buf_size;


        chdir(SYSTEM_PATH);

        if( argc<3  )
        {
                printf("\n");
                printf("autopost parameters error!\n");
                printf("\n");
                printf("  usage: %s <area_name> <file_name>\n\n", argv[0]);

                exit(1);
        }

        if( !file_exist(argv[2]) )
                exit(0);

        sprintf(mfile, "%s/%s/messages", MAIL_PATH, argv[1]);
        sprintf(rfile, "%s/%s/records", MAIL_PATH, argv[1]);

        if( !file_exist(mfile) )
        {
                test=open( mfile, O_WRONLY | O_APPEND | O_CREAT, S_IWUSR | S_IRUSR);
                if( test<0 )
                {
                        printf("open %s error!\n", mfile);
                        exit(2);
                }
                else
                        close(test);
        }

        if( !file_exist(rfile) )
        {
                test=open( rfile, O_WRONLY | O_APPEND | O_CREAT, S_IWUSR | S_IRUSR);
                if( test<0 )
                {
                        printf("open %s error!\n", rfile);
                        exit(2);
                }
                else
                        close(test);
        }

        inport=open(argv[2], O_RDONLY);
        if( inport<0 )
        {
                printf("open %s error!\n", argv[2]);
                exit(5);
        }

        /*----------------------------------------------------------------*/
        /*----------------------------------------------------------------*/
        /*----------------------------------------------------------------*/

        if( file_length(inport) > (MAX_BUF-1024) )
                subject_counter=1;
        else
                subject_counter=0;

        do
        {
          msgfile=open(mfile, O_WRONLY | O_APPEND);
          if( msgfile<0 )
          {
                printf("open %s error!\n", mfile);
                exit(3);
          }

          recfile=open(rfile, O_WRONLY | O_APPEND);
          if( recfile<0 )
          {
                printf("open %s error!\n", rfile);
                exit(3);
          }

          flock(msgfile, LOCK_EX);        /*exclusive lock*/
          flock(recfile, LOCK_EX);        /*exclusive lock*/
          /*---------------------------------------------------*/

          lseek(msgfile, 0, SEEK_END);
          mr.offset=file_length(msgfile);
          mr.packed=' ';
          mr.delete_mark=' ';

          msg_counter=0;

          memset(buf, 0, 255);
          sprintf(buf, "Path: %s%c%c", STATION_ID, 13, 10);
                  write(msgfile, buf, strlen(buf) );
		  msg_counter+=strlen(buf);

          memset(buf, 0, 255);
          sprintf(buf, "From: Auto.Post@%s (PBBS Poster)%c%c", NNRP_DOMAIN,  13, 10);
                  write(msgfile, buf, strlen(buf) );
		  msg_counter+=strlen(buf);

          if( subject_counter == 0 )
          {
            memset(buf, 0, 255);
            sprintf(buf, "Subject: Autopost <%s>%c%c", argv[2], 13, 10);
                  write(msgfile, buf, strlen(buf) );
		  msg_counter+=strlen(buf);
          }
          else
          {
            memset(buf, 0, 255);
            sprintf(buf, "Subject: Autopost <%s - %d>%c%c", argv[2], subject_counter, 13, 10);
                  write(msgfile, buf, strlen(buf) );
		  msg_counter+=strlen(buf);
          }

	  strip_nl(buf);
	  nstrcpy(mr.subject, buf+9, 60);

          memset(buf, 0, 255);
          memset(message_id, 0, 128);
          memset(unique_id, 0, 20);
          get_mid(unique_id);
          sprintf(message_id, "<%s@%s>", unique_id, NNRP_DOMAIN);
          sprintf(buf, "Message-ID: %s%c%c", message_id, 13, 10);
                  write(msgfile, buf, strlen(buf) );
		  msg_counter+=strlen(buf);

          rfcgmtime(timebuf);
          memset(buf, 0, 255);
          sprintf(buf, "Date: %s GMT%c%c", timebuf, 13, 10);
                  write(msgfile, buf, strlen(buf) );
		  msg_counter+=strlen(buf);

          memset(buf, 0, 255);
          sprintf(buf, "Organization: %s%c%c", SORGANIZATION, 13, 10);
                  write(msgfile, buf, strlen(buf) );
		  msg_counter+=strlen(buf);

          memset(buf, 0, 255);
          sprintf(buf, "%c%c", 13, 10);
          write(msgfile, buf, 2);
	  msg_counter+=2;

          continue_next=FALSE;

          while(TRUE)
          {
		  if(dup_last_buf)
		  {
		    dup_last_buf=FALSE;

		    if( last_buf_size>200 )
		      last_buf_size=200;

		    memcpy(buf, last_buf, last_buf_size);
		    ret=last_buf_size;
		  }
		  else
		    ret=read(inport, buf, 200);

		  if( ret<=0 ) break;

		  /* output msgtxt with CR-LF */
		  if( !find_d )
		  {
		    for(outcnt=0; outcnt<ret; outcnt++)
		    {
		      if( buf[outcnt]==0xd )
		      {
		        find_d=TRUE;
		        break;
		      }
		    }
		  }

		  if( find_d )
		    write(msgfile, buf, ret );
		  else
		  {
		    for(outcnt=0; outcnt<ret; outcnt++)
		    {
		      if( buf[outcnt]==0xa )
		      {
			  write(msgfile, &od, 1);
			  msg_counter++;
		      }

		      write(msgfile, buf+outcnt, 1);
		    }
		  }

                  msg_counter+=ret;
                  if( msg_counter> (MAX_BUF-2048) )
                  {
			dup_last_buf=TRUE;
			memcpy(last_buf, buf, ret);
			last_buf_size=ret;

                        strcpy(buf, "\r\n\r\n  --- FILE TOO LARGE, TO BE CONTINUED IN THE NEXT POST ---\r\n\r\n");
                        write(msgfile, buf, strlen(buf));
                        continue_next=TRUE;
                        subject_counter++;
                        break;
                  }
          }

          /*---------------------------------------------------*/
          lseek(msgfile, 0, SEEK_END);
          mr.length=file_length(msgfile)-mr.offset;

          write(recfile, &mr, sizeof(mr) );

          flock(msgfile, LOCK_UN);        /*unlock*/
          flock(recfile, LOCK_UN);        /*unlock*/

          close(msgfile);
          close(recfile);

        } while(continue_next);

        close(inport);

        /*----------------------------------------------------------------*/
        /*----------------------------------------------------------------*/
        /*----------------------------------------------------------------*/

        unlink(argv[2]);
}
/*end of main*/


/*
        sub functions
*/

/*
        get_mid --- assemble Message-ID, use time and uid with ltoa of max base
*/
get_mid(mid)
        char *mid;
{
	char buf[128];
	/* unsigned long longtime; */
	time_t longtime; 
	static unsigned long last_seed=0;
	static int t_counter=0;	/*avoid dup mid (posts in 1 second)*/

	time(&longtime);
	ltoa((unsigned long)getpid(), buf, 0);

	if( last_seed==longtime )
	{
	  t_counter++;
	  sprintf(mid, "%d%s", buf, t_counter, buf);
	}
	else
	{
	  t_counter=0;
	  sprintf(mid, "%s", buf);
	}

	last_seed=longtime;
	ltoa(longtime, buf, 0);
	strcat(mid, buf);
}
/*end of get_mid*/



int rfcgmtime(rfcbuf)
/*****************************
    get RFC-977 format time at GMT
    write by Aquarius Kuo
    Mar 23, 1994.

return: the length of string.
******************************/
char *rfcbuf ;
{
  int len ;
  time_t timenow ;
  struct tm  *timeptr ;

  time(&timenow) ;
  timeptr=gmtime(&timenow) ;
  len=strftime(rfcbuf,26,"%a, %d %b %Y %T",timeptr) ;
  return(len) ;
}
/*end of rfcgmtime*/



file_exist(filename)
char *filename;
/*
        return: TRUE: exist
                FALSE: not exist
*/
{
        FILE *testexist;

        if( (testexist=fopen(filename, "r")) == NULL)
                return(FALSE);          /*not found*/
        else    /*file found*/
        {
                fclose(testexist);
                return(TRUE);
        }
}
/*end of file_exist*/



/*
        file_length --- return file size of fd
*/
long file_length(fd)
        int fd;
{
        struct stat buf;
        fstat(fd, &buf);
        return(buf.st_size);
}
/*end of file_length*/



/*
        ltoa --- unsigned long to ascii with base n
*/
ltoa(number, buffer, base)
        unsigned long number;
        char *buffer;
        char base;
{
        char *idmap="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        unsigned long n;
        char buf[128];
        char *p;
        char nbase;

        nbase=base;

        if( nbase<=1 )
                nbase=strlen(idmap);

        n=number;

        memset(buf, 0, 128);
        p=buf+126;

        do
        {
                *p=idmap[n%nbase];
                p--;
                n/=nbase;
        } while(n>0);

        strcpy(buffer, p+1);
}
/*end of ltoa*/



/*
	strip_nl --- strip cr-lf
*/
strip_nl(buf)
	char *buf;
{
	int n;
	int len;

	len=strlen(buf);

	for(n=0; n<len; n++)
		if( buf[n]==0 || buf[n]==13 || buf[n]==10 )
		{
			buf[n]=0;
			break;
		}
}
/*end of strip_nl*/



/*
	nstrcpy --- some stange STRING hate strcpy... also size control is
		    needed
*/
nstrcpy(t, s, ms)
	char *t;	/*target*/
	char *s;	/*source*/
	int ms; 	/*max size*/
{
	int cpn;

	for(cpn=0; cpn<ms; cpn++)
	{
		t[cpn]=s[cpn];

		if(s[cpn]==0)
			break;
	}

	t[ms-1]=0;
}
/*end of nstrcpy*/
