/*
	users.dbf : NetBSD <---> SunOS format conversion program
	by Jones Tsai
*/

#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>

swapword(ch1,ch2,ch3,ch4)
  char *ch1;
  char *ch2;
  char *ch3;
  char *ch4;
 {
   char  ch;

   ch=*ch1;
   *ch1=*ch4;
   *ch4=ch;

   ch=*ch2;
   *ch2=*ch3;
   *ch3=ch;

  return;
 }

main()
 {
  FILE *inf,*outf;
  char buf[350];
  int i,j,r;


  if((inf=fopen("users.dbf","r")) == NULL) 
   {
    printf("open users.dbf error !!\n");
    exit(-1);
   }
 
  if((outf=fopen("users.dbf.new","w")) == NULL)
   {
    printf("open new users.dbf error !!\n");
    exit(-2);
   }
  

  i=0;
  
  r=fread(buf,1,344,inf);
  
  j=0;
  swapword(&(buf[j]),&(buf[j+1]),&(buf[j+2]),&(buf[j+3]));
  j=4;
  swapword(&(buf[j]),&(buf[j+1]),&(buf[j+2]),&(buf[j+3]));

  fwrite(buf,1,344,outf);

  r=fread(buf,1,344,inf);

  do
   {
    i++;
    printf("%5d\n",i); 
    
    buf[303]=8;
    
    for(j=304;j<=320;j+=4) 
      swapword(&(buf[j]),&(buf[j+1]),&(buf[j+2]),&(buf[j+3]));


    fwrite(buf,1,344,outf);
    r=fread(buf,1,344,inf);
   }
  while (!feof(inf));
  fclose(inf);
  fclose(outf);

  
  exit(0);
 }
