/********************************
    build lastname.db
    write by Aquarisu Kuo
    May 4, 1994
    revision by Samson Chen
    Dec 11, 1995
**********************************/
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>

#ifndef NEXTSTEP
#include <malloc.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>

#include "../setup.h"

#define REC_SIZE        sizeof(struct REC)

struct REC {
                char name[20] ;
           } ;
/*
	flength --- get length of a file
*/
flength(filename)
	char *filename;
{
	int test;
	unsigned long len;
	
        test=open(filename, O_RDONLY);
        lseek(test, 0, SEEK_END);
       	len = tell(test);
	close(test);

	return(len);
}
/*end of flength*/

#ifdef NETBSD
/*
	NetBSD does not support tell() function, use fstat as alternative one
*/
tell(fd)
        int fd;
{
        struct stat buf;
        fstat(fd, &buf);
        return(buf.st_size);
}
#endif

/***********************************
  reindex user database
*/
main()
{
  int utf, handle ;
  FILE *ln_txt;
  char name_buf[128];
  int i, radix, cnt ;
  char filename[100] ;
  struct LINK {
                struct REC body ;
                struct LINK *next ;
              } ;
  struct LINK *ptr, *head[255], *tmp ;

  chdir(SYSTEM_PATH);	/*change to pbbs system path which set at setup.h*/

        
  if( (ln_txt=fopen("lastname.txt", "r"))==(FILE*)NULL )
  {
    printf("fopen 'lastname.txt' error!\n");
    exit(1) ;
  }
        
  ptr=NULL ;
  for(i=0; i<255; i++)
  {
    head[i]=NULL ;
  }

  while( fgets(name_buf, 30, ln_txt) )
  {
    strip_nl(name_buf);
    if( strlen(name_buf)<=0 )
      continue;
          
    /* inster_index */
    tmp=(struct LINK *) malloc(sizeof(struct LINK)) ;
    strcpy(tmp->body.name,name_buf) ;
            
    radix=(int) tmp->body.name[0] ;

    if(head[radix]==NULL)      /* the first one */
    {
      head[radix]=ptr=tmp ;
      ptr->next=NULL ;
      continue ;
    }

    ptr=head[radix] ;
	    
    if(strcmp(ptr->body.name,tmp->body.name)>0)   /* check the head */
    {
      tmp->next=head[radix] ;
      head[radix]=tmp ;
      continue ;
    }

    while( ptr->next != NULL )
    {
      if( strcmp(ptr->next->body.name, tmp->body.name)>0 )
      {
        tmp->next=ptr->next ;
        ptr->next=tmp ;
        break ;
      }
      ptr=ptr->next ;
    }

    if(ptr->next==NULL)         /* check the last one */
    {
      ptr->next=tmp ;
      tmp->next=NULL ;
      continue ;
    }
	    
  }/*end while*/
  fclose(ln_txt);
                
  sprintf(filename, "lastname.db") ;
  if((handle=open(filename,O_CREAT|O_WRONLY,S_IWUSR|S_IRUSR))<2)
  {
    printf("'lastname.db' file open error!\r\n") ;
    exit(0) ;
  }
        
  flock(handle,LOCK_EX) ;
        
  /* rewrite index file */
  cnt=0 ;	/* count the total records */
  for(i=0; i<255; i++)
  {
    ptr=head[i] ;
    while(ptr!=NULL)
    {
      cnt++ ;
      write(handle,&(ptr->body),REC_SIZE) ;
      ptr=ptr->next ;
    }
  }
          
  ftruncate(handle,cnt*REC_SIZE) ;
  flock(handle,LOCK_UN) ;
  close(handle) ;
  exit(0) ;
}
/*end of main*/


        
/*
	strip_nl --- strip cr-lf
*/
strip_nl(buf)
	char *buf;
{
	int n;
	int len;

	len=strlen(buf);

	for(n=0; n<len; n++)
		if( buf[n]==0 || buf[n]==13 || buf[n]==10 )
		{
			buf[n]=0;
			break;
		}
}
/*end of strip_nl*/
