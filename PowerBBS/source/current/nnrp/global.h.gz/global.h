/****************************************************************************
 * global.h ---  declare some external variables which are used at most     *
 *	 	 modules						    *
 *		 by Samson Chen, Mar 24, 1994				    *
 ****************************************************************************/

#define	PBBS_NNRP_VERSION "v2.2 by Samson Chen, 09/05/1995"

/*
	for debugging
*/
extern	char debug_mode;	/*TRUE for debug mode*/


/*
	basic tested client specifications
*/
extern	char client_site[30];	/*client's readable address*/


/*
	control cancel flag
*/
extern	char get_control_cancel;


/*
	for head parser
*/
#define	PATH		1
#define	FROM		2
#define	NEWSGROUP	3
#define	SUBJECT		4
#define	MID		5
#define	DATE		6
#define	ORGANIZATION	7
#define	REPLY_TO	8
#define	CONTROL		9
#define	UNDEFINED	10
