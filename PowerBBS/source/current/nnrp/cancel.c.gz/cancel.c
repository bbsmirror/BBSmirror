/***************************************************************************
 * Filename: cancel.c							   *
 * Batch Cancel Process routine 					   *
 *	by Samson Chen, May 10, 1995					   *
 ***************************************************************************/

#include "../host/pbbs.h"
#include "global.h"
#include "../host/dbf.h"

static char rcsid[]="$Id: cancel.c,v 1.6 1996/02/01 10:51:32 pbbs Exp pbbs $";


#define CANCEL_LOCK	"cmsg.cancel"



/*
	process batched control cancel message signals
	1. try to lock cmsg.cancel
	   if lock failed, leave the function, other process is doing it
	2. search group 'controlmsg'
	3. find Control: cancel ...
	4. query from DBZ
	5. try to delete it
	6. set delete_mark='D'
	7. unlock cmsg.cancel
*/
process_batched_cancel()
{
	int lock;
	char pid[10];
	int ret;

	get_control_cancel=FALSE;	/*reset flag*/

	if(debug_mode)
	  printf("(cancel.c)process_batch_cancel\n");

	/**************/
	/*test locking*/
	/**************/
	sprintf(pid, "%5d\n", getpid() );
	lock=open(CANCEL_LOCK, O_WRONLY | O_CREAT, S_IWUSR | S_IRUSR);
	ret=flock(lock, LOCK_EX | LOCK_NB);
	if( ret<0 )
	{
	  if(debug_mode)
	    printf("(cancel.c)another process do cmsg cancel\n");

	  return;	/*open lock file error, another file locked*/
	}
	write(lock, pid, strlen(pid) );
	/************************************************************/

	do_log(4, "Process batched cmsg cancel(%s)", client_site);

	do_message_cancel();

	/************************************************************/
	/***********/
	/*unlock it*/
	/***********/
	flock(lock, LOCK_UN);
	close(lock);

	return;
}
/*end of process_batched_cancel*/



/*
	process cancel
*/
do_message_cancel()
{
  char cmsg_path[128], cmsgmfile[128], cmsgrfile[128];
  int cmsgm, cmsgr;
  int recno, total_msg;
  struct msgrec mrec;
  char msg[10240];
  int ret;
  char m_path[512], from[256], newsgroup[1024], control[256];
  char *point;
  int n,p;
  char head;
  char buf[2047];

  if( !get_mpath_nocheck(cmsg_path, "cancelmsg") )
  {
	do_log(9, "cannot find internal group 'cancelmsg'???");
	return;
  }

  sprintf(cmsgmfile, "%s/messages", cmsg_path);
  sprintf(cmsgrfile, "%s/records", cmsg_path);

  if( !file_exist(cmsgmfile) || !file_exist(cmsgrfile) )
	return;

  cmsgm=open(cmsgmfile, O_RDONLY, S_IWUSR | S_IRUSR);
  cmsgr=open(cmsgrfile, O_RDWR, S_IWUSR | S_IRUSR);

  if( cmsgm<0 || cmsgr<0 )
  {
	do_log(9, "open 'cancelmsg' error!");
	return;
  }

  recno=-1;	/*recno will be plus 1*/

  while(TRUE)
  {
    recno++;

    total_msg=file_length(cmsgr)/sizeof(struct msgrec);
    if( recno>total_msg || total_msg<=0 )
    {
	close(cmsgm);
	close(cmsgr);
	break;
    }

    lseek(cmsgr, recno*sizeof(struct msgrec), SEEK_SET);
    read(cmsgr, &mrec, sizeof(struct msgrec) );

    if(mrec.delete_mark=='D')
	continue;

    /*get msg head*/
    lseek(cmsgm, mrec.offset, SEEK_SET);
    if( mrec.length<10240 )		/*head_buf only has 5120 size*/
	  fetch_msg_head(cmsgm, mrec.length, msg);
    else
	  fetch_msg_head(cmsgm, 10240, msg);


    /*parse message*/
    m_path[0]=0;
    from[0]=0;
    newsgroup[0]=0;
    control[0]=0;

    point=msg;
    n=p=0;
    head=TRUE;

    do
    {
      /*maybe wrong message format*/
      if( p>=strlen(msg) )
      {
	do_log(8, "cancel message #%d error", recno);
	break;
      }

      /*find a line*/
      for(p=n;p<strlen(msg);p++)
	    if( msg[p]==13 ) break;

      /*CR-LF-CR-LF appeared, head field finished*/
      if( n==p )
      {
	    head=FALSE;
	    continue;
      }

      /*cut a line*/
      strncpy(buf, msg+n, p-n);
      if( (p-n)>=2047 )
	buf[2046]=0;
      else
	buf[p-n]=0;

      /*determine field*/
      switch( parse_field(buf) )
      {
      case PATH:
	    nstrcpy(m_path, buf+6, 512);
	    break;

      case FROM:
	    nstrcpy(from, buf+6, 256);
	    break;

      case NEWSGROUP:
	    nstrcpy(newsgroup, buf+12, 1024);
	    break;

      case CONTROL:
	    nstrcpy(control, buf+9, 256);
	    break;

      }

      n=p+2;  /*skip CR-LF*/

    }while(head);

    if( strlen(m_path)==0 || strlen(from)==0 || strlen(newsgroup)==0 || strlen(control)==0 )
    {
	do_log(6, "cancel message head error #%d", recno);
	continue;
    }

    if( strncmp(control, "cancel ", 7) )
	continue;	/*not cmsg cancel*/

    if( do_cancel(newsgroup, control+7, from, m_path) )
    {
	/*cancel successful, remove this cancel message*/

	flock(cmsgr, LOCK_EX);
	flock(cmsgm, LOCK_EX);

	lseek(cmsgr, recno*sizeof(struct msgrec), SEEK_SET);
	read(cmsgr, &mrec, sizeof(struct msgrec) );

	mrec.delete_mark='D';
	lseek(cmsgr, recno*sizeof(struct msgrec), SEEK_SET);
	write(cmsgr, &mrec, sizeof(struct msgrec) );

	flock(cmsgr, LOCK_UN);
	flock(cmsgm, LOCK_UN);
    }

  }/*end while*/

}
/*end of do_message_cancel*/



/*
	canceling
*/
do_cancel(newsgroups, cancel_mid, from, mpath)
	char *newsgroups;
	char *cancel_mid;
	char *from;
	char *mpath;
/*
	return:
		TRUE:	cancel ok
		FALSE:	failed
*/
{
  char crosspost=FALSE;
  char toss_gp[1536], *toss_p;
  int toss_r;
  char toss_group[80], mail_path[80];
  char mfile[90], rfile[90];
  int msgfile, recfile;
  int scan_order;
  struct msgrec mr;
  char dbz_put_rec[20];
  char ret;
  char head_buf[10240];
  int total_msg;
  char *cmsg_path;
  char *cmsg_from;
  char *cmsg_mid;
  char *cmsg_point;
  int fp;

  if(debug_mode)
    printf("(cancel.c)do_cancel: %s %s %s %s\n", newsgroups, cancel_mid, from, mpath);

  if( strchr(newsgroups, ',') )
	crosspost=TRUE;

  memset(toss_gp, 0, 1536);
  nstrcpy(toss_gp, newsgroups, 1024);
  toss_p=toss_gp;

  while( (toss_r=next_comma(toss_p)) != 0)
  {
    toss_p[toss_r]=0;
    nstrcpy(toss_group, toss_p, 80);
    if( debug_mode ) printf("(cancel.c)cancel group-> %s\n", toss_group);

    if( !get_mpath_nocheck(mail_path, toss_group) )
    {
	toss_p+=toss_r+1;
	continue;
    }

    sprintf(mfile, "%s/messages", mail_path);
    sprintf(rfile, "%s/records", mail_path);

    if( !file_exist(mfile) || !file_exist(rfile) )
	continue;

    msgfile=open(mfile, O_RDONLY);
    recfile=open(rfile, O_RDWR);

    if( msgfile>0 && recfile>0 )
    {

	flock(msgfile, LOCK_EX);
	flock(recfile, LOCK_EX);

	/*check from DBZ*/
	init_dbz_channel();
	ret=query_mid(cancel_mid, dbz_put_rec);
	close_dbz_channel();

	total_msg=file_length(recfile)/sizeof(struct msgrec);

	if( crosspost || !ret )
	  scan_order=total_msg-1;
	else
	{
	  scan_order=atoi(dbz_put_rec);

	  if( scan_order>=total_msg )
		scan_order=total_msg-1;
	}

	for(; scan_order>=0;scan_order--)
	{
	  if(scan_order>=(file_length(recfile)/sizeof(struct msgrec)))
		continue;

	  lseek(recfile, scan_order*sizeof(struct msgrec), SEEK_SET);
	  read(recfile, &mr, sizeof(struct msgrec) );
	  if( mr.delete_mark=='D' )
		continue;		/*msg has been deleted*/

	  lseek(msgfile, mr.offset, SEEK_SET);

	  if( mr.length<10240 ) /*head_buf only has 5120 size*/
		fetch_msg_head(msgfile, mr.length, head_buf);
	  else
		fetch_msg_head(msgfile, 10240, head_buf);

	  if( (fp=parse_msg(head_buf, "Message-ID: ")) < 0 ) continue;
	  cmsg_mid=head_buf+fp+12;
	  cmsg_point=strchr(cmsg_mid, 13);
	  *cmsg_point=0;

	  if( (fp=parse_msg(head_buf, "From: ")) < 0 ) continue;
	  cmsg_from=head_buf+fp+6;
	  cmsg_point=strchr(cmsg_from, 13);
	  *cmsg_point=0;

	  if( (fp=parse_msg(head_buf, "Path: ")) < 0 ) continue;
	  cmsg_path=head_buf+fp+6;
	  cmsg_point=strchr(cmsg_path, 13);
	  *cmsg_point=0;

	  if( !strcmp(cancel_mid, cmsg_mid) )
	  {
#ifdef	NNRP_DEL_NO_CHECK_PATH
	    if( !strcmp(from, cmsg_from) )
#else
	    if( !strcmp(mpath, cmsg_path) && !strcmp(from, cmsg_from) )
#endif
	    {
		mr.delete_mark='D';
		lseek(recfile, scan_order*sizeof(struct msgrec), SEEK_SET);
		write(recfile, &mr, sizeof(struct msgrec) );

		do_log(3, "%s cmsg %s cancelled!", toss_group, cancel_mid);
	    }
	    else
	    {
#ifdef	NNRP_DEL_NO_CHECK_PATH
		do_log(3, "%s cmsg %s From: not matched!!!", toss_group, cancel_mid);
#else
		do_log(3, "%s cmsg %s Path: or From: not matched!!!", toss_group, cancel_mid);
#endif
		if( debug_mode )

		{
#ifndef NNRP_DEL_NO_CHECK_PATH
		  printf("(cancel.c)-->'%s'\n", mpath);
		  printf("(cancel.c)-->'%s'\n", cmsg_path);
#endif
		  printf("(cancel.c)-->'%s'\n", from);
		  printf("(cancel.c)-->'%s'\n", cmsg_from);
		}
	    }

	    break;
	  }

	  /*UnLock then Re-Lock to reduce user's waiting*/
	  /*maybe a user is waiting for this lock*/

	  flock(msgfile, LOCK_UN);	/*unlock*/
	  flock(recfile, LOCK_UN);	/*unlock*/
	  flock(msgfile, LOCK_EX);	/*exclusive lock*/
	  flock(recfile, LOCK_EX);	/*exclusive lock*/
	}/*end for*/
	/****************************************/

	flock(msgfile, LOCK_UN);
	flock(recfile, LOCK_UN);

    }/*end if(msgfile&&recfile)*/
    else
      do_log(9, "(cancel.c)cancel open %s error!", mail_path);

    close(msgfile);
    close(recfile);

    toss_p+=toss_r+1;

  }/*end while(toss_r)*/

  /*do cancel ok*/

  return(TRUE);

}
/*end of do_cancel*/
