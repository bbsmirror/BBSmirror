/* Define Color constant */

#define		BLACK		30
#define		BLUE		34
#define		GREEN		32
#define		CYAN		36
#define		RED		31
#define		MAGENTA		35
#define		BROWN		33
#define		LIGHTGRAY	37
#define		DARKGRAY	BLACK+128
#define		LIGHTBLUE	BLUE+128
#define		LIGHTGREEN	GREEN+128
#define		LIGHTCYAN	CYAN+128
#define		LIGHTRED	RED+128
#define		LIGHTMAGENTA	MAGENTA+128
#define		YELLOW		BROWN+128
#define		WHITE		LIGHTGRAY+128
#define		NORMAL		0
#define   	HIGH_INTENSITY 	1
#define 	BLINK		5
#define		REVERSE		7
