/*************************************************************************
 * pack.c --- packing unpacked messages					 *
 *	      by Samson Chen, Apr 12, 1994				 *
 *************************************************************************/

#include <varargs.h>
#include <time.h>
#include "../host/pbbs.h"
#include "../host/dbf.h"
#include "global.h"


char buf[MAX_BUF];
char line[81];
char lb[256];



/*
	packing --- packing unpacked message
*/
packing()
{
	int n;
	char path[80];
	char group[80];
	int scan_order;
	char time_unique[40];
	char pack_filename[80];
	char new_pack_filename[80];
	char sindex[20];
	int server;
	int mffd, mfrec;
	struct msgrec mrec;
	char filename[256];
	int recno;
	int total_msg;
	int ret;
	char rchar;
	char crlf[3];
	char *rfc_path, *rfc_from, *newsgroups, *rfc_subject, *rfc_mid;
	char *rfc_date, *rfc_organization, *rfc_replyto, *msgbody;
	char *rfc_control;
	int fp;
	char *token;
	char *pointer;

	sprintf(crlf, "%c%c", 13, 10);

	get_unique(time_unique);  /*generate a unique string by time*/

	/*open these filenames*/
	for(n=0; n<max_station; n++)
	{
	  get_index_by_order(n, sindex);
	  sprintf(pack_filename, "%s/%s_%s", NNTP_QUEUE, time_unique, sindex);

	  p_handle[n]=open(pack_filename, O_WRONLY | O_APPEND | O_CREAT | O_TRUNC, S_IWUSR | S_IRUSR);
	  do_log(0, "open %s ", pack_filename);
	}

	/*scaning each group*/
	scan_order=1;
	while( get_group(scan_order++, path, group, &server) )
	{

		do_log(0, "scan %s, group %s, server %d", path, group, server);

		/********************/
		/*opeinning checking*/
		/********************/
		sprintf(filename, "%s/messages", path);
		mffd=open(filename, O_RDWR|O_CREAT, S_IWUSR | S_IRUSR);

		sprintf(filename, "%s/records", path);
		mfrec=open(filename, O_RDWR|O_CREAT, S_IWUSR | S_IRUSR);

		if( mffd<0 || mfrec<0 )
		{
			do_log(9, "%s open error!!!", path);
			continue;
		}

		/*------------------*/

		recno=0;

		while(1)
		{
			/*maybe scan and purge occur at the same time*/
			flock(mffd, LOCK_EX);
			flock(mfrec, LOCK_EX);

			/*---------------*/
			/*check file size*/
			total_msg=file_length(mfrec)/sizeof(struct msgrec);

			/*-------------*/
			/*scan finished*/
			if( recno>total_msg || total_msg<=0 )
			{
				flock(mffd, LOCK_UN);
				flock(mfrec, LOCK_UN);
				break;
			}

			/*-----------*/
			/*get records*/
			lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
			read(mfrec, &mrec, sizeof(struct msgrec) );

			/*---------------------*/
			/*post has been scanned*/
			if(mrec.packed=='P')
			{
			  flock(mffd, LOCK_UN);
			  flock(mfrec, LOCK_UN);
			  recno++;
			  continue;
			}

			/*---------------------*/
			/*post has been deleted*/
			if(mrec.delete_mark=='D')
			{
			  mrec.packed='P';
			  lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
			  write(mfrec, &mrec, sizeof(struct msgrec) );
			  flock(mffd, LOCK_UN);
			  flock(mfrec, LOCK_UN);
			  recno++;
			  continue;
			}

			/*----------------*/
			/*get message body*/
			lseek(mffd, mrec.offset, SEEK_SET);
			ret=read(mffd, buf, mrec.length);
			buf[ret]=0;

			/*---------------*/
			/*set packed mark*/
			mrec.packed='P';
			lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
			write(mfrec, &mrec, sizeof(struct msgrec) );

			/*-------------*/
			/*parse message*/

			fp=parse_msg(buf, "MSG");
			if( fp<0 )	/*CRITICAL FILE STRUCTURE ERROR!*/
			{
			  do_log(9, "%s message file CRITICAL ERROR(a) on rec #%d", group, recno);
			  /*remove this message*/
			  mrec.delete_mark='D';
			  lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
			  write(mfrec, &mrec, sizeof(struct msgrec) );
			  /*-------------------*/
			  flock(mffd, LOCK_UN);
			  flock(mfrec, LOCK_UN);
			  recno++;
			  continue;
			  /*scan for the next one*/
			}
			msgbody=buf+fp+2;

			fp=parse_msg(buf, "Reply-To: ");
			if( fp<0 )
				rfc_replyto=NULL;
			else
			{
				rfc_replyto=buf+fp;
				pointer=strchr(rfc_replyto, 13);
				*pointer=0;
			}

			fp=parse_msg(buf, "Organization: ");
			if( fp<0 )	/*CRITICAL FILE STRUCTURE ERROR!*/
			{
			  do_log(9, "%s message file CRITICAL ERROR(b) on rec #%d", group, recno);
			  /*remove this message*/
			  mrec.delete_mark='D';
			  lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
			  write(mfrec, &mrec, sizeof(struct msgrec) );
			  /*-------------------*/
			  flock(mffd, LOCK_UN);
			  flock(mfrec, LOCK_UN);
			  recno++;
			  continue;
			  /*scan for the next one*/
			}
			rfc_organization=buf+fp;
			pointer=strchr(rfc_organization, 13);
			*pointer=0;

			fp=parse_msg(buf, "Date: ");
			if( fp<0 )	/*CRITICAL FILE STRUCTURE ERROR!*/
			{
			  do_log(9, "%s message file CRITICAL ERROR(c) on rec #%d", group, recno);
			  /*remove this message*/
			  mrec.delete_mark='D';
			  lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
			  write(mfrec, &mrec, sizeof(struct msgrec) );
			  /*-------------------*/
			  flock(mffd, LOCK_UN);
			  flock(mfrec, LOCK_UN);
			  recno++;
			  continue;
			  /*scan for the next one*/
			}
			rfc_date=buf+fp;
			pointer=strchr(rfc_date, 13);
			*pointer=0;

			fp=parse_msg(buf, "Message-ID: ");
			if( fp<0 )	/*CRITICAL FILE STRUCTURE ERROR!*/
			{
			  do_log(9, "%s message file CRITICAL ERROR(d) on rec #%d", group, recno);
			  /*remove this message*/
			  mrec.delete_mark='D';
			  lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
			  write(mfrec, &mrec, sizeof(struct msgrec) );
			  /*-------------------*/
			  flock(mffd, LOCK_UN);
			  flock(mfrec, LOCK_UN);
			  recno++;
			  continue;
			  /*scan for the next one*/
			}
			rfc_mid=buf+fp;
			pointer=strchr(rfc_mid, 13);
			*pointer=0;

			fp=parse_msg(buf, "Control: ");
			if( fp<0 )
				rfc_control=NULL;
			else
			{
				rfc_control=buf+fp;
				pointer=strchr(rfc_control, 13);
				*pointer=0;
			}

			fp=parse_msg(buf, "Subject: ");
			if( fp<0 )	/*CRITICAL FILE STRUCTURE ERROR!*/
			{
			  do_log(9, "%s message file CRITICAL ERROR(e) on rec #%d", group, recno);
			  /*remove this message*/
			  mrec.delete_mark='D';
			  lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
			  write(mfrec, &mrec, sizeof(struct msgrec) );
			  /*-------------------*/
			  flock(mffd, LOCK_UN);
			  flock(mfrec, LOCK_UN);
			  recno++;
			  continue;
			  /*scan for the next one*/
			}
			rfc_subject=buf+fp;
			pointer=strchr(rfc_subject, 13);
			*pointer=0;

			fp=parse_msg(buf, "Newsgroups: ");
			if( fp<0 )
				newsgroups=NULL;
			else
			{
				newsgroups=buf+fp;
				pointer=strchr(newsgroups, 13);
				*pointer=0;
			}

			fp=parse_msg(buf, "From: ");
			if( fp<0 )	/*CRITICAL FILE STRUCTURE ERROR!*/
			{
			  do_log(9, "%s message file CRITICAL ERROR(f) on rec #%d", group, recno);
			  /*remove this message*/
			  mrec.delete_mark='D';
			  lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
			  write(mfrec, &mrec, sizeof(struct msgrec) );
			  /*-------------------*/
			  flock(mffd, LOCK_UN);
			  flock(mfrec, LOCK_UN);
			  recno++;
			  continue;
			  /*scan for the next one*/
			}
			rfc_from=buf+fp;
			pointer=strchr(rfc_from, 13);
			*pointer=0;
			
			fp=parse_msg(buf, "Path: ");
			if( fp<0 )	/*CRITICAL FILE STRUCTURE ERROR!*/
			{
			  do_log(9, "%s message file CRITICAL ERROR(g) on rec #%d", group, recno);
			  /*remove this message*/
			  mrec.delete_mark='D';
			  lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
			  write(mfrec, &mrec, sizeof(struct msgrec) );
			  /*-------------------*/
			  flock(mffd, LOCK_UN);
			  flock(mfrec, LOCK_UN);
			  recno++;
			  continue;
			  /*scan for the next one*/
			}
			rfc_path=buf+fp;
			pointer=strchr(rfc_path, 13);
			*pointer=0;

			/*-------------------------------------------------*/
			/*remove control cancel message*/
			if( rfc_control!=NULL )
			{
			  if( !strncmp(rfc_control, "Control: cancel", 15) )
			  {
			    if(debug_mode) printf("(pack.c)control cancel deleted\n");
			    mrec.delete_mark='D';
			    lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
			    write(mfrec, &mrec, sizeof(struct msgrec) );
			   }
			}

			/***************************************************/

			/*put to queue files*/
			for(n=0; n<max_station; n++)
			{
			  /*check if this station take this group and*/
			  /*if this post come from it*/
			  if( server&(1<<n) && !check_mpath(rfc_path, station_id[n]) )
			  {

			    if( rfc_control!=NULL )
			      do_log(3, "pack control %s from %s", rfc_mid, group);
			    else
			      do_log(3, "pack post %s from %s", rfc_mid, group);

			    /*for IHAVE command*/
			    sprintf(line, "%s%c%c", rfc_mid, 13, 10);
			    write(p_handle[n], line, strlen(line) );

			    sprintf(line, "%s%c%c", rfc_path, 13, 10);
			    write(p_handle[n], line, strlen(line) );

			    sprintf(line, "%s%c%c", rfc_from, 13, 10);
			    write(p_handle[n], line, strlen(line) );

			    if(newsgroups!=NULL)
			    {
			      sprintf(line, "%s%c%c", newsgroups, 13, 10);
			      write(p_handle[n], line, strlen(line) );
			    }
			    else
			    {
				sprintf(line, "Newsgroups: %s%c%c", group, 13, 10);
				write(p_handle[n], line, strlen(line) );
			    }

			    sprintf(line, "%s%c%c", rfc_subject, 13, 10);
			    write(p_handle[n], line, strlen(line) );

			    if(rfc_control!=NULL)
			    {
			      sprintf(line, "%s%c%c", rfc_control, 13, 10);
			      write(p_handle[n], line, strlen(line) );
			    }

			    sprintf(line, "%s%c%c", rfc_mid, 13, 10);
			    write(p_handle[n], line, strlen(line) );

			    sprintf(line, "%s%c%c", rfc_date, 13, 10);
			    write(p_handle[n], line, strlen(line) );

			    sprintf(line, "%s%c%c", rfc_organization, 13, 10);
			    write(p_handle[n], line, strlen(line) );

			    if(rfc_replyto!=NULL)
			    {
			      sprintf(line, "%s%c%c", rfc_replyto, 13, 10);
			      write(p_handle[n], line, strlen(line) );
			    }


			    /*seperate msgbody*/
			    write(p_handle[n], crlf, 2);

			    pointer=msgbody;
			    ret=find_nl(pointer, &rchar);
			    token=pointer+ret;

			    while(*token!=0)
			    {
				*token=0;
				nstrcpy(lb, pointer, 256);
				*token=rchar;

				if( lb[0]=='.' )	/*double the dot(.)*/
				{
					write(p_handle[n], ".", 1);
				}
				write(p_handle[n], lb, strlen(lb) );
				write(p_handle[n], crlf, 2);

				if( (*(token+1)==10 || *(token+1)==13) && *(token+1)!=rchar )
					pointer=token+2;
				else
					pointer=token+1;

			        ret=find_nl(pointer, &rchar);
			        token=pointer+ret;
			    }/*end while(*token)*/


			    if( token != pointer )
			    {
				/*left last line*/
				nstrcpy(lb, pointer, 256);
				if( lb[0]=='.' )	/*double the dot(.)*/
				{
					write(p_handle[n], ".", 1);
				}
				write(p_handle[n], lb, strlen(lb) );
				write(p_handle[n], crlf, 2);
			    }


			    /*terminated dot(.)*/
			    write(p_handle[n], ".", 1);
			    write(p_handle[n], crlf, 2);

			  }/*end if(server and check_mpath)*/

			}/*end for(max_station)*/


			/*------------------------------------*/
			/*maybe user are waiting for this lock*/
			flock(mffd, LOCK_UN);
			flock(mfrec, LOCK_UN);
	
			/*-----------------*/
			/*scan for next one*/
			recno++;
		}/*end while(1)*/

		close(mffd);
		close(mfrec);
	}/*end while(get_group)*/

	/*close packing files*/
	for(n=0; n<max_station; n++)
		close(p_handle[n]);

	/*rename pack file from [TimeUnique_Station] to [Station_TimeUnique]*/
	for(n=0; n<max_station; n++)
	{
	  get_index_by_order(n, sindex);
	  sprintf(pack_filename, "%s/%s_%s", NNTP_QUEUE, time_unique, sindex);
	  sprintf(new_pack_filename, "%s/%s_%s", NNTP_QUEUE, sindex, time_unique);

	  if(debug_mode) printf("(pack.c)rename %s to %s\n", pack_filename, new_pack_filename);
	  rename(pack_filename, new_pack_filename);

	  check_queue(sindex, new_pack_filename);
	}/*end for*/

}
/*end of packing*/
