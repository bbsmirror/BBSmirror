/****************************************************************************
 * global.h ---  declare some external variables which are used at most     *
 *	 	 modules						    *
 *		 by Samson Chen, Mar 24, 1994				    *
 ****************************************************************************/

/*
	for debugging
*/
extern	char debug_mode;	/*TRUE for debug mode*/


/*
	basic tested client specifications
*/
extern	char client_site[30];	/*client's readable address*/


extern	char sidbuf[16*30];	/*linker will not pass 2-d array parameters*/
extern	char *station_id[17];	/*station id string*/
extern	int max_station;
extern	int p_handle[16];
extern	char current_station[30];
extern	char xmit_error;
extern	int global_fd;
