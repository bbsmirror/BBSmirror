/*************************************************************************
 * getset.c --- get groups setup file					 *
 *	        by Samson Chen, Mar 29, 1994				 *
 *************************************************************************/

#include "../host/pbbs.h"
#include "global.h"



struct station_struc {
	char	index[10];
	char	ip[16];
	char	port[6];
	char	link[20];
	char	id[30];
	};



struct group_struc {
	char	group[80];
	char	path[80];
	int	server;		/*each bit map to station_struc*/
				/*max 16 stations accept*/
	struct group_struc *next;
	};


/*local global vars*/
struct station_struc station[16];
struct group_struc *group;
char stations=0;



/*
	get_group_set --- get group definitions
*/
get_group_set()
/*
	return:
		TRUE: OK!
		FASLE: failure!
*/
{
	char gfile[80];
	char buf[256];
	FILE *gf;
	int n, ret;
	int m;
	char *p;
	char t_group[80];
	char t_path[80];
	int t_server;
	char temp[10];
	struct group_struc *group_point, *previous_gp;
	

	group=NULL;

	sprintf(gfile, "%s", NNTP_GROUP);

	/**************************************/
	/*phase 1 --- get !station definitions*/
	/**************************************/
	gf=fopen(gfile, "r");
	if( gf==NULL )
	{
		do_log(9, "open %s error!", gfile);
		exit(11);
	}

	memset(buf, 0, 256);
	while( fgets(buf, 255, gf) )
	{
		trim_comment(buf);
		if( !strncmp(buf, "!station", 8) )
		{
			p=buf+9;
			ret=next_blank(p);
			p[ret]=0;
			strcpy(station[stations].index, p);

			p+=ret+1;
			ret=next_blank(p);
			p[ret]=0;
			strcpy(station[stations].ip, p);

			p+=ret+1;
			ret=next_blank(p);
			p[ret]=0;
			strcpy(station[stations].port, p);

			p+=ret+1;
			ret=next_blank(p);
			p[ret]=0;
			strcpy(station[stations].link, p);

			p+=ret+1;
			ret=next_blank(p);
			p[ret]=0;
			strcpy(station[stations].id, p);

			stations++;
		}/*end if*/

		memset(buf, 0, 256);

	}/*end while*/

	fclose(gf);


	/*************************/
	/*phase 2 --- get groups */
	/*************************/
	gf=fopen(gfile, "r");
	if( gf==NULL )
	{
		do_log(9, "open %s error!", gfile);
		exit(11);
	}

	memset(buf, 0, 256);

	while( fgets(buf, 255, gf) )
	{
		trim_comment(buf);
		ret=strlen(buf);

		if(ret<126)
		{
			/*to avoid a possoble bug of next_blank*/
			buf[ret+1]=0;
			buf[ret+2]=0;
		}

		if(strlen(buf)>5 && strncmp(buf, "!station", 8) )
		{
			p=buf;
			ret=next_blank(p);
			p[ret]=0;
			strcpy(t_group, p);

			p+=ret+1;
			ret=next_blank(p);
			if(ret==0)
			{
				do_log(8,"%s error->%s", gfile, buf);
				memset(buf, 0, 128);
				continue;
			}
			p[ret]=0;
			sprintf(t_path, "%s/%s", MAIL_PATH, p);

			p+=ret+1;
			t_server=0;
			while( (ret=next_blank(p)) != 0)
			{
				p[ret]=0;
				temp[0]=0;
				strcpy(temp, p);

				n=0;
				while(n<stations)
				{
					if( !strcmp(station[n].index, temp ) )
					{
						m=1<<n;
						t_server |= m;
					}
					n++;
				}

				p+=ret+1;
			}

			/********************/
			/* put to link list */
			/********************/

			if( !path_exist(t_path) )
				do_log(9, "mail path '%s' not exist!", t_path);

			group_point=(struct group_struc *)malloc(sizeof(struct group_struc));

			strcpy(group_point->group, t_group);
			strcpy(group_point->path, t_path);
			group_point->server=t_server;
			group_point->next=NULL;

			if(group==NULL)
			{
				group=group_point;
				previous_gp=group;
			}
			else
			{
				previous_gp->next=group_point;
				previous_gp=group_point;
			}

		}/*end if*/

		memset(buf, 0, 256);

	}/*end while*/

	max_station = stations;

	/*transfer station ids*/
        station_id[0]=sidbuf;
        for(n=0; n<max_station; n++)
        {
                strcpy(station_id[n], station[n].id);   /*exports station id*/
                station_id[n+1]=station_id[n]+strlen(station_id[n])+1;
        }

}
/*end of get_group_set*/



/*
	get_group --- get Nth group for packing
*/
get_group(nth, p, g, server)
	int nth;	/*Nth group*/
	char *p;	/*path buffer*/
	char *g;	/*group name*/
	int *server;	/*linked server,note:THIS IS A POINTER*/
/*
	return:
		n: ok (1 .. k)
		0: FAKSE (no more groups)
*/
{
	struct group_struc *group_point;
	int cnt=1;

	group_point=group;
	while( group_point!=NULL )
	{
		if( cnt==nth )
		{
			strcpy(p, group_point->path);
			strcpy(g, group_point->group);
			*server=group_point->server;
			return(cnt);
		}
			
		group_point=group_point->next;
		cnt++;
	}

	return(FALSE);
}
/*end of get_group*/



/*
	get_station --- get station datum
*/
get_station(order, ip, port, passwd, sindex)
	int order;
	char *ip;
	char *port;
	char *passwd;	/*link level*/
	char *sindex;
{
	strcpy(ip, station[order].ip);
	strcpy(port, station[order].port);
	strcpy(passwd, station[order].link);
	strcpy(sindex, station[order].index);
}
/*end of get_station*/



/*
	get_index_by_order --- get index string by order for packing
*/
get_index_by_order(order, sindex)
	int order;
	char *sindex;
{
	strcpy(sindex, station[order].index);
}
/*end of get_index_by_order*/



/*
	get_passwd_by_index --- (as the name)
*/
get_passwd_by_index(index, passwd)
	char *index;
	char *passwd;
{
	int n;

	for(n=0; n<stations; n++)
		if( !strcmp(index, station[n].index) )
		{
			strcpy(passwd, station[n].link);
			return;
		}

	strcpy(passwd, "+");
	return;
}
/*end of get_passwd_by_index*/



/*
	get_station_order --- get station_order by index 
	(used at -m manually mode)
*/
get_station_order(index)
	char *index;
{
	int n;

	for(n=0; n<stations; n++)
		if( !strcmp(index, station[n].index) )
		{
			return(n);
		}

	return(-1);	/*not found*/
}
/*end of get_station_order*/
