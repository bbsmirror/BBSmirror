/*************************************************************************
 * queue.c --- sending queue control					 *
 *	       by Samson Chen, Apr 15, 1994				 *
 *************************************************************************/

#include "../host/pbbs.h"
#include "global.h"

static char rcsid[]="$Id: queue.c,v 1.7 1995/09/05 12:50:12 pbbs Exp pbbs $";


/*
	check_queue --- check packing file in queue directory
			if compress post, compress the msg pack
*/
check_queue(index, msgpack)
	char *index;
	char *msgpack;
/*
	return:
		TRUE: msgpack ok
		FALSE: msgpack empty
*/
{
	char zip_exe[128];
	char link_level[20];
	int ret;

	if( flength(msgpack)<5 )
	{
		if(debug_mode) printf("(queue.c)unlink %s\n", msgpack);
		unlink(msgpack);

		return(FALSE);
	}


	get_passwd_by_index(index, link_level);
	if( strcmp(link_level, "+") && strcmp(link_level, "*") )  /*Compressed Post*/
	{
		sprintf(zip_exe, "%s %s", ZIP, msgpack);
		ret=system(zip_exe);

		do_log(0, "%s : %d", zip_exe, ret);
	}

	return(TRUE);
}
/*end of check_queue*/



/*
	check_unfinished_pack --- for some unknow situations
		(system shutdown, power problem, or program bug)
		pbbsnntp will halt its packing. So that it will leave
		many unfinished packets in sending queue. This
		function make these packets to be sent.
*/
check_unfinished_pack()
{
	char	ip[16];		/*target ip address*/
	char	port[6];	/*target port*/
	char	passwd[20];	/*link level*/
	char	sindex[10];	/*station index*/
	char	queuefile[80];	/*seending queue file*/
	int	station_order;
	char	index[32][10];
	int	total_indexs=0;
	int	n, counter;
	int	len;

        char epack[255];
	char opack[255];
	char fname[50];
	struct dirent *dirp;
        DIR *dp;

	/* get all station index*/
	for(station_order=0; station_order<max_station; station_order++)
	{
		get_station(station_order, ip, port, passwd, sindex);
		strcpy(index[total_indexs++], sindex);
	}

	/**************************/
	/*open queue path to check*/
	/**************************/
	dp=opendir(NNTP_QUEUE);

	while( (dirp = readdir(dp)) != NULL )
	{
	  strcpy(epack, dirp->d_name);
	  sprintf(opack, "%s/%s", NNTP_QUEUE, epack);
	  len=strlen(epack);

	  if( !strncmp(epack, "token.", 6) )
		continue;	/*of course, this is not a packet*/

	  for(counter=0; counter<total_indexs; counter++)
	  {
		n=strlen(index[counter]);

		if( (len-n)<=1 )
			continue;

		if( !strcmp(epack+len-n, index[counter]) && strncmp(epack, index[counter], n) )
		{
		  /*eg. xxxx_chpi and xxxx!=chpi found*/

		  do_log(9, "unfinished pack '%s' found, process ever crashed", epack);

		  epack[len-n-1]=0;
		  strcpy(fname, epack);
		
		  /*reassemble filename to chpi_xxxx*/
	  	  sprintf(epack, "%s/%s_%s", NNTP_QUEUE, index[counter], fname);

		  if( debug_mode ) printf("new pack name %s\n", epack);
		  rename(opack, epack);

		  /*check it and compress it if necessary*/
	  	  check_queue(index[counter], epack);

		  /*ok for this file, skip to next file*/
		  break;

		}/*end if*/
	  }/*end for*/
	}/*end while*/

	closedir(dp);

}
/*end of check_unfinished_pack*/

