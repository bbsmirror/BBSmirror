/***************************************************************************
 * serve.c --- initial service from main				   *
 *	       by Samson Chen, Mar 24, 1994				   *
 ***************************************************************************/

#include "../host/pbbs.h"
#include "global.h"	/*this module need program global vars*/

static char rcsid[]="$Id: serve.c,v 1.5 1995/05/12 13:28:46 pbbs Exp pbbs $";


/*
	do service for network client
	function will not return... just EXIT
*/
serve(fd)
	int fd;			/*the service socket file descriptor*/
{
	int	ret;
	char	bigbuf[MAX_BUF];
	unsigned long rlen;

	sprintf(bigbuf, "200 PowerBBS Interchange Manager NNRP server ready %s (posting ok).%c%c", PBBS_NNRP_VERSION, 13, 10);
	write(fd, bigbuf, strlen(bigbuf) );

	if ( !check_site_permission(fd) )
		exit(2);

	get_control_cancel=FALSE;

	do_nnrp(fd);

	(void) close(fd);

	if( get_control_cancel )
		process_batched_cancel();

	if(debug_mode) printf("(serve.c)child exit\n");
	exit(0);
}
/*end of serve*/



/*
	abnormal_disconnect --- client site disconnect without normal procedure
*/
abnormal_disconnect()
{
	do_log(5, "%s disconnect abnormally", client_site);
	exit(1);
}
/*end of abnormal_disconnect*/



/*
	reap child process which was ready to die
*/
#ifndef	SYSV
reaper()
{
	union wait status;

#ifndef ALPHA
	while(wait3((int*)&status, (int)WNOHANG, (struct rusage *)0) > 0);
#else
        while(wait3(&status, (int)WNOHANG, (struct rusage *)0) > 0);
#endif    
}
#endif
/*end of reaper*/



/*
	reset_alarm --- reset alarm clock
*/
reset_alarm()
{
	alarm(NNRP_IDLE);
}
/*end of reset_alarm*/



/*
	timeup --- connection idle too long
*/
timeup()
{
	do_log(2, "%s idle too long", client_site);
	exit(9);
}
/*end of timeup*/
