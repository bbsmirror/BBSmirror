/*************************************************************************
 * sendme.c --- get RFC850 message					 *
 *	      by Samson Chen, Mar 24, 1994				 *
 *************************************************************************/

#include "../host/pbbs.h"
#include "global.h"
#include "../host/dbf.h"



/*
	sendme --- get post via RFC850 standard
*/
sendme(fd, mode, mid)
	int fd;
	int mode;
	char *mid;
/*
	mode : 1. POST command
	       2. IHAVE command

	if IHAVE command, mid is the message-ID
*/
{
	char line[1024];
	char buf[MAX_BUF];
	char dot=FALSE;
	int n, p, ret;
	char cr_lf[3];
	int gp;
	int buf_cnt;
	char huge_msg;
	int debug_fd;
	char debug_file[80];
	char line_head;
	char head_dot;

	init_dbz_channel();

	sprintf(cr_lf, "%c%c", 13, 10);

	if( mode==2 )
	{
	  /*check duplicate from DBZ*/
	  if( query_mid(mid, NULL) )
	  {
	    /*435 duplicate*/
	    sprintf(line, "435 duplicate%c%c", 13, 10);
	    write(fd, line, strlen(line) );
	    close_dbz_channel();
	    return;
	  }
	  else
	  {
	    /*335 Ready*/
	    sprintf(line, "335 send article to be transferred.%c%c", 13, 10);
	    write(fd, line, strlen(line) );
	  }
	}

	/*put a LF char at the beginning to perform the dot(.) end checking*/
	buf[0]=0;
	buf_cnt=0;
	gp=0;

	/********************************************************/
	/*CORE DEBUG*CORE DEBUG*CORE DEBUG*CORE DEBUG*CORE DEBUG*/
	/*truncat previous succeed message*/
	/*
	sprintf(debug_file, "pbbsnnrpd.debug.%s", client_site);
	if( !file_exist("pbbsnnrpd.core") )
	{
	  debug_fd=open(debug_file, O_WRONLY|O_APPEND|O_TRUNC|O_CREAT,S_IWUSR|S_IRUSR);
	  close(debug_fd);
	}
	*/
	/********************************************************/

	/*get the unprocessed message*/
	huge_msg=FALSE;
	line_head=TRUE;
	head_dot=FALSE;

	do
	{

		reset_alarm();
		ret=read(fd, line, 1023);
		if( ret<=0 ) abnormal_disconnect();

		/********************************************************/
		/*CORE DEBUG*CORE DEBUG*CORE DEBUG*CORE DEBUG*CORE DEBUG*/
		/*for CORE debug*/
		/*
		if( !file_exist("pbbsnnrpd.core") )
		{
		debug_fd=open(debug_file, O_WRONLY|O_APPEND|O_CREAT,S_IWUSR|S_IRUSR);
		write(debug_fd, line, ret);
		close(debug_fd);
		}
		*/
		/********************************************************/


		buf_cnt+=ret;
		line[ret]='\0';

		/*control buffer size*/
		if( buf_cnt >= (MAX_BUF-1024) )
		{
			/*rewind buffer pointer, so that it can terminate*/
			buf_cnt -= 1024;
			gp -= 1024;
			huge_msg=TRUE;
		}/*end if*/

		for(n=0; n<ret; n++)
		{
		  /*make newline as cr-lf standard*/
		  if( line[n]==10 || line[n]==13 )
		  {
		    if( head_dot )	/*terminating dot*/
		    {
			dot=TRUE;
			break;
		    }

		    buf[gp]=13;
		    gp++;
		    buf[gp]=10;
		    gp++;

		    line_head=TRUE;

		    if( (line[n]!=line[n+1]) && (line[n+1]==13 || line[n+1]==10) )
				n++;
		  }
		  else
		  {
		    if( (line[n]=='.') && line_head )
		    {
			line_head=FALSE;
			head_dot=TRUE;
			/*skip the heading dot*/
		    }
		    else
		    {
		      buf[gp]=line[n];
		      gp++;
		      line_head=FALSE;
		      head_dot=FALSE;
		    }
		  }
		}/*end for*/

		/*----------------------------------------------------*/

		buf[gp]=0;

		if( dot )
		{
			if( huge_msg )
			  do_log(3, "%s send a HUGE message", client_site);
		}

	} while( !dot );

	/*here we got the total message for processing*/

	/**********************************************/

	parse_news(fd, buf, mode, mid);

	close_dbz_channel();

	if( get_control_cancel )
	{
	  /* child process do cancel processing*/
	  /* starting fork processing */
	  switch(fork())
	  {
	  case 0:  /*child*/
		process_batched_cancel();

		exit(40);
		/*child process goes bye-bye*/

		break;

	  case -1: /*error*/
	  default: /*parent*/
		get_control_cancel=FALSE;	/*reset flag*/
		break;

	  }/*end switch*/
	}/*end if*/

	return;
}
/*end of sendme*/



/*
	parse_news --- parsing the received message
*/
parse_news(fd, msg, mode, mid)
	int fd;
	char *msg;	/*message body*/
	int mode;	/*same as sendme()*/
	char *mid;	/*same as sendme()*/
{
	char buf[2047];
	char m_path[512];
	char from[256];
	char newsgroup[1024];
	char subject[256];
	char control[256];
	char message_id[256];
	char date[32];
	char organization[256];
	char reply_to[256];
	char toss_group[80], toss_gp[1536];
	char line[2048];
	char *toss_p;
	int toss_r;
	char *point;
	char head=TRUE;
	int n,p;
	char mail_path[80];
	char mfile[90], rfile[90];
	int msgfile, recfile;
	struct msgrec mr;
	int test;
	int total_msg;
	int scan_order;
	int fp;
	char get_control_message=FALSE;
	char this_is_control_cancel=FALSE;


	/*initial*/
	m_path[0]=0;
	from[0]=0;
	newsgroup[0]=0;
	subject[0]=0;
	control[0]=0;
	message_id[0]=0;
	date[0]=0;
	organization[0]=0;
	reply_to[0]=0;

	/*store IHAVE message-id*/
	if( mode==2 ) nstrcpy(message_id, mid, 256);

	point=msg;
	n=0;
	p=0;

	do
	{
	  /*maybe that message is in a wrong format*/
	  if( p>=strlen(msg) )
	  {
		do_log(8, "message error from %s", client_site);
		do_log(1, "the error message is -->\n%s", msg);

#ifdef IGNORE_NNTP_ERROR
		response_ok(fd, mode);
		return;
#else
		sprintf(buf, "441 message error%c%c", 13, 10);
		write(fd, buf, strlen(buf) );
		return;
#endif
	  }

	  /*find a line*/
	  for(p=n;p<strlen(msg);p++)
		if( msg[p]==13 ) break;

	  /*CR-LF-CR-LF appeared, head field finished*/
	  if( n==p )
	  {
		head=FALSE;
		continue;
	  }

	  /*cut a line*/
	  strncpy(buf, msg+n, p-n);
	  if( (p-n)>=2047 )
	    buf[2046]=0;
	  else
	    buf[p-n]=0;

	  /*determine field*/
	  switch( parse_field(buf) )
	  {
	  case PATH:
		nstrcpy(m_path, buf+6, 512);
		break;

	  case FROM:
		nstrcpy(from, buf+6, 256);
		break;

	  case NEWSGROUP:
		nstrcpy(newsgroup, buf+12, 1024);
		break;

	  case SUBJECT:
		nstrcpy(subject, buf+9, 256);
		break;

	  case CONTROL:
		nstrcpy(control, buf+9, 256);
		break;

	  case MID:
		nstrcpy(message_id, buf+12, 256);
		break;

	  case DATE:
		nstrcpy(date, buf+6, 32);
		break;

	  case ORGANIZATION:
		nstrcpy(organization, buf+14, 256);
		break;

	  case REPLY_TO:
		nstrcpy(reply_to, buf+10, 256);
		break;
	  }

	  n=p+2;  /*skip CR-LF*/

	}while(head);



	/*processing mail path*/
	if( check_mpath(m_path, STATION_ID) )
	{
		do_log(9, "message LOOP found at %s group from %s mid %s", newsgroup, client_site, message_id);
		do_log(9, "LOOP path is %s", m_path);


#ifdef IGNORE_NNTP_ERROR
		response_ok(fd, mode);
		return;
#else
		sprintf(buf, "435 message loop!!!%c%c", 13, 10);
		write(fd, buf, strlen(buf) );
		return;
#endif
	}
	else
	{
		sprintf(line, "%s!%s", STATION_ID, m_path);
		nstrcpy(m_path, line, 512);
	}

	/*******************/
	/*check head format*/
	/*******************/

	if( strlen(from)==0 || strlen(newsgroup)==0 || strlen(message_id)==0 )
	{
		do_log(6, "head of a post from %s was wrong", client_site);

#ifdef IGNORE_NNTP_ERROR
		response_ok(fd, mode);
		return;
#else
		sprintf(buf, "441 wrong head%c%c", 13, 10);
		write(fd, buf, strlen(buf) );
		return;
#endif
	}

	/*************************************************/
	/*check dupicate*/
	if( query_mid(message_id, NULL) )
	{
	  /*435 duplicate*/
	  sprintf(line, "441 435 duplicate%c%c", 13, 10);
	  write(fd, line, strlen(line) );
	  return;
	}

	/*************************************************/

	response_ok(fd, mode);	/*message head OK, reply client*/

	/*************************************************/
	/*check control field if this is a cancel message*/

	if( strlen(control) )
	{
	  if(debug_mode)printf("(sendme.c)cmsg %s at %s\n", control, newsgroup);
	  if( !strncmp(control, "cancel ", 7) )
	  {
		do_log(1, "%s %s", client_site, subject); /*log cancel signal*/
		get_control_cancel=TRUE;
		this_is_control_cancel=TRUE;
	  }

	  /*dup cmsg to 'controlmsg' internal group*/
	  get_control_message=TRUE;
	}

	/*************************************************/

	/*take the message body*/
	n+=2;	/*skip first cr-lf*/

	msg += n;
	/*------------------------*/

	do_log(0, "%s send a post to %s", client_site, newsgroup);


	/*********/
	/*tossing*/
	/*********/

	/*for cross-post*/
	memset(toss_gp, 0, 1536);
	nstrcpy(toss_gp, newsgroup, 1024);
	if(this_is_control_cancel)
	  strcat(toss_gp, ",cancelmsg");
	else if(get_control_message)
	  strcat(toss_gp, ",controlmsg");
	toss_p=toss_gp;

	while( (toss_r=next_comma(toss_p)) != 0)
	{
	toss_p[toss_r]=0;
	nstrcpy(toss_group, toss_p, 80);
	if( debug_mode ) printf("(sendme.c)toss_group-> %s\n", toss_group);

	if( !get_mpath(mail_path, toss_group) )
	{
		toss_p+=toss_r+1;
		continue;
	}

	sprintf(mfile, "%s/messages", mail_path);
	sprintf(rfile, "%s/records", mail_path);

	if( !file_exist(mfile) )
	{
		test=open( mfile, O_WRONLY | O_APPEND | O_CREAT, S_IWUSR | S_IRUSR);
		if( test<0 )
		{
			do_log(9, "%s open error!?", mfile);
			toss_p+=toss_r+1;
			continue;
		}
		else
			close(test);
	}

	if( !file_exist(rfile) )
	{
		test=open( rfile, O_WRONLY | O_APPEND | O_CREAT, S_IWUSR | S_IRUSR);
		if( test<0 )
		{
			do_log(9, "%s open error!?", rfile);
			toss_p+=toss_r+1;
			continue;
		}
		else
			close(test);
	}

	/***************************************************************/
	/*APPEND to msg file*/

	msgfile=open(mfile, O_WRONLY | O_APPEND);
	recfile=open(rfile, O_WRONLY | O_APPEND);

	if( msgfile<0 )
	{
		do_log(9, "%s open error!?", mfile);
		toss_p+=toss_r+1;
		continue;
	}

	if( recfile<0 )
	{
		do_log(9, "%s open error!?", rfile);
		toss_p+=toss_r+1;
		continue;
	}

	/************************************************/

	flock(msgfile, LOCK_EX);	/*exclusive lock*/
	flock(recfile, LOCK_EX);	/*exclusive lock*/

	lseek(msgfile, 0, SEEK_END);
	mr.offset=file_length(msgfile);
	nstrcpy(mr.subject, subject, 60);
	mr.packed=' ';
	/*if control cancel, the post in controlmsg should be mark 'C'*/
	/*for batch canceling					      */
	if( this_is_control_cancel && !strcmp(toss_group, "controlmsg") )
	  mr.delete_mark='C';
	else
	  mr.delete_mark=' ';

	sprintf(buf, "Path: %s%c%c", m_path, 13, 10);
		write(msgfile, buf, strlen(buf) );
	sprintf(buf, "From: %s%c%c", from, 13, 10);
		write(msgfile, buf, strlen(buf) );
	sprintf(buf, "Newsgroups: %s%c%c", newsgroup, 13, 10);
		write(msgfile, buf, strlen(buf) );
	sprintf(buf, "Subject: %s%c%c", subject, 13, 10);
		write(msgfile, buf, strlen(buf) );

	if( strlen(control) )
	{
	sprintf(buf, "Control: %s%c%c", control, 13, 10);
		write(msgfile, buf, strlen(buf) );
	}

	sprintf(buf, "Message-ID: %s%c%c", message_id, 13, 10);
		write(msgfile, buf, strlen(buf) );
	sprintf(buf, "Date: %s%c%c", date, 13, 10);
		write(msgfile, buf, strlen(buf) );
	sprintf(buf, "Organization: %s%c%c", organization, 13, 10);
		write(msgfile, buf, strlen(buf) );

	if( strlen(reply_to) )
	{
	sprintf(buf, "Reply-To: %s%c%c", reply_to, 13, 10);
		write(msgfile, buf, strlen(buf) );
	}

	/*write first cr-lf to seperate head from msg body*/
	sprintf(buf, "%c%c", 13, 10);
	write(msgfile, buf, 2);

	write(msgfile, msg, strlen(msg) );

	lseek(msgfile, 0, SEEK_END);
	mr.length=file_length(msgfile)-mr.offset;

	write(recfile, &mr, sizeof(mr) );

	/*add mid to DBZ server*/
	sprintf(line, "%d", (file_length(recfile)/sizeof(struct msgrec)) );
	add_mid(message_id, line);

	flock(msgfile, LOCK_UN);	/*unlock*/
	flock(recfile, LOCK_UN);	/*unlock*/

	close(msgfile);
	close(recfile);

	do_log(3, "get post to %s from %s", toss_group, client_site);

	toss_p+=toss_r+1;

	}/*end while(toss_r=next_comma())*/

	if(debug_mode) printf("(sendme.c)post from %s processed OK!(%d)\n", client_site, strlen(msg));
	return;

}
/*end of parse_news*/



/*
	parse_field --- parse NNTP message field
*/
parse_field(mh)
	char *mh;
{

	if( !strncmp(mh, "Path: ", 6) )
		 return(PATH);

	if( !strncmp(mh, "From: ", 6) )
		return(FROM);

	if( !strncmp(mh, "Newsgroups: ", 12) )
		return(NEWSGROUP);

	if( !strncmp(mh, "Subject: ", 9) )
		return(SUBJECT);

	if( !strncmp(mh, "Control: ", 9) )
		return(CONTROL);

	if( !strncmp(mh, "Message-ID: ", 12) )
		return(MID);

	if( !strncmp(mh, "Date: ", 6) )
		return(DATE);

	if( !strncmp(mh, "Organization: ", 14) )
		return(ORGANIZATION);

	if( !strncmp(mh, "Reply-To: ", 10) )
		return(REPLY_TO);

	return(UNDEFINED);
}
/*end of parse_field*/



/*
	response_ok --- response 2XX ok message
*/
response_ok(fd, mode)
	int fd;
	int mode;
{
	char line[80];

	if( mode==1 )
	{
		sprintf(line, "240 article posted ok%c%c", 13, 10);
	}
	else
	{
		sprintf(line, "235 article transferred ok%c%c", 13, 10);
	}

	write(fd, line, strlen(line) );
	if(debug_mode) printf("(sendme.c)response %s: %s", client_site, line);
}
/*end of response_ok*/
