/*************************************************************************
 * getset.c --- get groups setup file					 *
 *	        by Samson Chen, Mar 29, 1994				 *
 *************************************************************************/

#include "../host/pbbs.h"
#include "global.h"



struct station_struc {
	char	index[10];
	char	ip[16];
	char	port[6];
	char	link[20];
	char	id[30];
	char	feed_ip[16];	/*for client gateway*/
	};



struct group_struc {
	char	group[80];
	char	path[80];
	int	server;		/*each bit map to station_struc*/
				/*max 16 stations accept*/
	struct group_struc *next;
	};

/*local global vars*/
struct station_struc station[16];
struct group_struc *group;
char stations=0;

/*for LIST newsgroups command*/
struct group_desc {
	char	path[80];
	char	describe[50];
	struct	group_desc *previous;
	struct	group_desc *next;
	};

struct	group_desc *groupdesc;



/*
	get_group_set --- get group definitions
*/
get_group_set()
/*
	return:
		TRUE: OK!
		FASLE: failure!
*/
{
	char gfile[80];
	char buf[256];
	FILE *gf;
	int n, ret;
	int m;
	char *p;
	char t_group[80];
	char t_path[80];
	int t_server;
	char temp[10];
	struct group_struc *group_point, *previous_gp;
	

	group=NULL;

	sprintf(gfile, "%s", NNTP_GROUP);

	/**************************************/
	/*phase 1 --- get !station definitions*/
	/**************************************/
	gf=fopen(gfile, "r");
	if( gf==NULL )
	{
		do_log(9, "open %s error", gfile);
		exit(11);
	}

	memset(buf, 0, 256);
	while( fgets(buf, 254, gf) )
	{
		trim_comment(buf);

		ret=strlen(buf);
		if(ret<255)
		{
		  buf[ret]=0;
		  buf[ret+1]=0;
		}

		if( !strncmp(buf, "!station", 8) )
		{
			p=buf+9;
			ret=next_blank(p);
			p[ret]=0;
			strcpy(station[stations].index, p);

			p+=ret+1;
			ret=next_blank(p);
			p[ret]=0;
			strcpy(station[stations].ip, p);

			p+=ret+1;
			ret=next_blank(p);
			p[ret]=0;
			strcpy(station[stations].port, p);

			p+=ret+1;
			ret=next_blank(p);
			p[ret]=0;
			strcpy(station[stations].link, p);

			p+=ret+1;
			ret=next_blank(p);
			p[ret]=0;
			strcpy(station[stations].id, p);

			/*if more, alter-feed-ip*/
			p+=ret+1;
			if( *p!=0 )
			{
			  ret=next_blank(p);
			  p[ret]=0;
			  strcpy(station[stations].feed_ip, p);
			}
			else
			  strcpy(station[stations].feed_ip, station[stations].ip);

			stations++;
		}/*end if*/

		memset(buf, 0, 256);

	}/*end while*/

	fclose(gf);


	/*************************/
	/*phase 2 --- get groups */
	/*************************/
	gf=fopen(gfile, "r");
	if( gf==NULL )
	{
		do_log(9, "open %s error", gfile);
		exit(11);
	}

	memset(buf, 0, 256);

	while( fgets(buf, 255, gf) )
	{
		trim_comment(buf);
		ret=strlen(buf);

		if(ret<126)
		{
			/*to avoid a possoble bug of next_blank*/
			buf[ret+1]=0;
			buf[ret+2]=0;
		}

		if(strlen(buf)>5 && strncmp(buf, "!station", 8) )
		{
			p=buf;
			ret=next_blank(p);
			p[ret]=0;
			strcpy(t_group, p);

			p+=ret+1;
			ret=next_blank(p);
			if(ret==0)
			{
				do_log(8,"%s error->%s", gfile, buf);
				memset(buf, 0, 128);
				continue;
			}
			p[ret]=0;
			sprintf(t_path, "%s/%s", MAIL_PATH, p);

			p+=ret+1;
			t_server=0;
			while( (ret=next_blank(p)) != 0)
			{
				p[ret]=0;
				temp[0]=0;
				strcpy(temp, p);

				n=0;
				while(n<stations)
				{
					if( !strcmp(station[n].index, temp ) )
					{
						m=1<<n;
						t_server |= m;
					}
					n++;
				}

				p+=ret+1;
			}

			/********************/
			/* put to link list */
			/********************/

			if( !path_exist(t_path) )
			{
				do_log(9, "mail path '%s' not exist, touch a new one!", t_path);
				mkdir(t_path, 0x1c0);
			}

			group_point=(struct group_struc *)malloc(sizeof(struct group_struc));

			strcpy(group_point->group, t_group);
			strcpy(group_point->path, t_path);
			group_point->server=t_server;
			group_point->next=NULL;

			if(group==NULL)
			{
				group=group_point;
				previous_gp=group;
			}
			else
			{
				previous_gp->next=group_point;
				previous_gp=group_point;
			}

		}/*end if*/

		memset(buf, 0, 256);

	}/*end while*/

	/***************************/
	/*set control message group*/
	/***************************/
	sprintf(t_path, "%s/controlmsg", MAIL_PATH);
	if( !path_exist(t_path) )
	{
		do_log(9, "controlmsg path not exist, touch a new one!");
		mkdir(t_path, 0x1c0);
	}
	group_point=(struct group_struc *)malloc(sizeof(struct group_struc));
	strcpy(group_point->group, "controlmsg");
	strcpy(group_point->path, t_path);
	group_point->server=-1;		/*set all*/
	group_point->next=NULL;
	if(group==NULL)
	{
		group=group_point;
		previous_gp=group;
	}
	else
	{
		previous_gp->next=group_point;
		previous_gp=group_point;
	}

	/**************************/
	/*set cancel message group*/
	/**************************/
	sprintf(t_path, "%s/cancelmsg", MAIL_PATH);
	if( !path_exist(t_path) )
	{
		do_log(9, "cancelmsg path not exist, touch a new one!");
		mkdir(t_path, 0x1c0);
	}
	group_point=(struct group_struc *)malloc(sizeof(struct group_struc));
	strcpy(group_point->group, "cancelmsg");
	strcpy(group_point->path, t_path);
	group_point->server=-1;		/*set all*/
	group_point->next=NULL;

	/*add to link, group must not be NULL*/
	previous_gp->next=group_point;
	previous_gp=group_point;

}
/*end of get_group_set*/



/*
	get_mpath --- get mail_path from group name
*/
get_mpath(p, g)
	char *p;	/*path buffer*/
	char *g;	/*group name*/
{
	struct group_struc *group_point;

	group_point=group;
	while( group_point!=NULL )
	{
		if( !strcmp(group_point->group, g) )
		{
			strcpy(p, group_point->path);

			if( (group_point->server & get_client_site_server_bit())>0 )
			{
				if(debug_mode) printf("(getset.c)%s, %s server bit check ok!\n", client_site, g);
				return(TRUE);
			}
			else
			{
				do_log(7, "%s send to a not-belong group %s", client_site, g);
				return(FALSE);
			}
		}

		group_point=group_point->next;
	}

	do_log(4, "cannot find group %s", g);
	return(FALSE);
}
/*end of get_mpath*/



/*
	get_mpath_nocheck --- get mail_path from group name but no server
			      bit check
*/
get_mpath_nocheck(p, g)
	char *p;	/*path buffer*/
	char *g;	/*group name*/
{
	struct group_struc *group_point;

	group_point=group;
	while( group_point!=NULL )
	{
		if( !strcmp(group_point->group, g) )
		{
			strcpy(p, group_point->path);

			if(debug_mode)
			  printf("get group path->%s\n", p);

			return(TRUE);
		}

		group_point=group_point->next;
	}

	do_log(4, "cannot find group %s", g);
	return(FALSE);
}
/*end of get_mpath_nocheck*/


/*
	get_client_site_server_bit --- get the bit var of client_site
	(for checking station<--->groups mapping)
*/
get_client_site_server_bit()
{
	int n, m;

	n=0;
	m=0;

	while(n<stations)
	{
		if( !strcmp(station[n].index, client_site ) )
		{
			m=1<<n;
			return(m);
		}
		n++;
	}

	return(0);
}
/*end of get_client_site_server_bit*/



/*
	check_site_permission --- (as the name)
*/
check_site_permission(fd)
	int fd;
/*
	return:
		TRUE: OK
		FALSE: permission denied
*/
{
	int n;
	char buf[80];

	for(n=0; n<stations; n++)
		if( !strcmp(station[n].feed_ip, client_site) ) break;

	if( n==stations )	/*unrecognized station*/
	{
		do_log(5, "%s permission denied", client_site);
		sprintf(buf, "502 access restriction%c%c", 13, 10);
		write(fd, buf, strlen(buf) );
		return(FALSE);
	}
	else			/*index found*/
	{
		do_log(0, "%s known as %s", client_site, station[n].index);
		strcpy(client_site, station[n].index);
		return(TRUE);
	}
}
/*end of check_site_permission*/



/*
	check_passwd --- check CPPOST passwd
*/
check_passwd(index, passwd)
	char *index;
	char *passwd;
/*
	return:
		TRUE: OK
		FALSE: failed
*/
{
	int n;

	for(n=0;n<stations; n++)
	{
		if( !strcmp(index, station[n].index) && !strcmp(passwd, station[n].link) )
			return(TRUE);
	}

	return(FALSE);
}
/*end of check_passwd*/


/*
	send_group_list --- send all newsgroups list to remote host
*/
send_group_list(fd)
	int fd;
{
	struct group_struc *group_point;
	struct group_desc  *group_link, *plink;
	char crlf[3];
	char line[1024];

	sprintf(crlf, "%c%c", 0xd, 0xa);

	sprintf(line, "215 send current newsgroups list, <X> means not feed to you!%c%c", 0xd, 0xa);
	write(fd, line, strlen(line));

	get_group_desc();

	group_point=group;
	while( group_point!=NULL )
	{
		strcpy(line, group_point->group);
		write(fd, line, strlen(line));
	
		/*search possible description*/
		if( groupdesc!=NULL )
		{
		  group_link=groupdesc;
		  while( group_link!=NULL )
		  {

		    if( !strcmp(group_point->path, group_link->path) )
		    {
		      write(fd, " ", 1);
		      strcpy(line, group_link->describe);
		      write(fd, line, strlen(line));

		      /*remove this item in the link list*/
		      plink=group_link;
		      if( (group_link->previous)!=NULL )
		      {
			group_link=group_link->previous;
			group_link->next=plink->next;
		      }
		      else	/*head of link list*/
		      {
			groupdesc=groupdesc->next;
			groupdesc->previous=(struct group_desc *)NULL;
		      }
		      free(plink);
		      break;
		    }

		    group_link=group_link->next;

		  }/*end while(group_link...)*/
		}/*end if(groupdesc...)*/

		/*check server bit*/
		if( !(group_point->server & get_client_site_server_bit()) )
		{
			/*this site does not take this newsgroup, mark it*/
			write(fd, " <X>", 4);
		}

		write(fd, crlf, strlen(crlf));
		group_point=group_point->next;
	}

	sprintf(line, ".%c%c", 0xd, 0xa);
	write(fd, line, strlen(line));

	/*release all memory for get_group_desc()*/
	group_link=groupdesc;
	while(group_link!=NULL)
	{
		plink=group_link;
		group_link=group_link->next;
		free(plink);
	}
}
/*end of send_group_list*/



/*
	get group descriptions from GROUP_LIST (if exist)
*/
get_group_desc()
{
	struct	group_desc *group_point, *new_space, *plink;
	FILE	*listfile;
	char	line[255];
	char	mpath[40];
	char	mdescribe[50];
	char	*p;
	int	n, ret;

	groupdesc=group_point=(struct group_desc *)NULL;

	if( !file_exist(GROUP_LIST) )
		return;

	listfile=fopen(GROUP_LIST, "r");

	while( fgets(line, 127, listfile) )
	{

	  /*take off comments*/
	  for(n=0; n<strlen(line); n++)
		if( line[n]=='#' )
		{
			line[n]=0;
			break;
		}

	  ret=strlen(line);
	  if( ret<8 )
		continue;

	  if(ret<126)
	  {
		/*to avoid a possoble bug of next_blank*/
		line[ret+1]=0;
		line[ret+2]=0;
	  }

	  /*--------------------------------------------------*/

	  /*--- get area path ---*/
	  p=line;
	  ret=next_params(p);
	  p+=ret;
	  ret=next_tab_space(p);
	  if( ret==0 ) continue;
	  p[ret]=0;
	  nstrcpy(mpath, p, 40);

	  p+=ret+1;
	  ret=next_params(p);
	  p+=ret;
	  ret=next_tab_space(p);
	  if( ret==0 ) continue;

	  /*--- skip join security ---*/
	  p[ret]=0;
	  p+=ret+1;
	  ret=next_params(p);
	  p+=ret;
	  ret=next_tab_space(p);
	  if( ret==0 ) continue;

	  /*--- skip post security ---*/
	  p[ret]=0;
	  p+=ret+1;
	  ret=next_params(p);
	  p+=ret;

	  /*--- get area description */
	  strip_nl(p);
	  nstrcpy(mdescribe, p, 50);

	  /*++++++++++++++++++++++++++++++*/
	  /*+++ add to group link list +++*/
	  /*++++++++++++++++++++++++++++++*/
	  new_space=(struct group_desc *)malloc(sizeof(struct group_desc));

	  if( groupdesc==(struct group_desc *)NULL )
	  {
		groupdesc=group_point=new_space;
		groupdesc->previous=(struct group_desc *)NULL;
	  }
	  else
	  {
		group_point->next=new_space;
		plink=group_point;
		group_point=new_space;
		group_point->previous=plink;
	  }

	  nstrcpy(group_point->describe, mdescribe, 50);
	  sprintf(group_point->path, "%s/%s", MAIL_PATH, mpath);
	  group_point->next=(struct group_desc *)NULL;

	}/*end while(fgets)*/

}
/*end of get_group_desc*/
