/* PBBSNNRP */
/*
PowerBBS InterChange Manager NNRP Server by Samson Chen, Team-Square-1991.
	V1.0 Apr 12, 1994
	V1.1 July 15, 1994
	V2.0 May 10, 1995
	V2.2 Sep 5, 1995
*/
/*************************************************************************** 
 * Filename: main.c							   *
 * PBBS Interchange program via NNTP protocol				   *
 *	by Samson Chen, Mar 24, 1994					   *
 ***************************************************************************/

/*
	arguments:
		-d : debug mode, do not push process as daemon process

	exit code :
		0  = initial daemon OK
		1  = abnorlmal disconnect
		2  = site permission denied
		5  = MPF error, quit directly
		10 = err routine
		11 = fopen error
		30 = daemon initializing error
		40 = child exit
*/

#include "../host/pbbs.h"

static char rcsid[]="$Id: main.c,v 1.12 1995/09/05 12:46:44 pbbs Exp pbbs $";

/*
	some global variables used in most modules
*/
char	debug_mode;		/*TRUE for debug mode*/
char 	client_site[30];	/*store readable client address*/
char	get_control_cancel=FALSE;


/*
	main start here
*/
main(argc, argv)
int 	argc;
char 	*argv[];
{
	int	sockfd, newsockfd, clilen;
	struct 	sockaddr_in cli_addr;
	int	daemon_pid;

#ifndef	SYSV
	extern	int reaper();	/*for reapping child process*/
#endif
	extern	int timeup();	/*idle handling function*/


	if( !path_exist(SYSTEM_PATH) )
	{
		printf("\nSYSTEM_PATH '%s' not found!\n", SYSTEM_PATH);
		exit(30);
	}

	chdir(SYSTEM_PATH);

	if( argc>1 )
		if( !strcmp(argv[1], "-d") ) debug_mode=TRUE;


	if( debug_mode )
		printf("\n Process is in debugging mode now...\n");
	else
	{
	  /*initial daemon*/
	  if( (daemon_pid=fork()) < 0 )
	  {
		  printf("initialize daemon error!\n");
		  exit(30);
	  }
	  if( daemon_pid > 0 )	/*parent goes bye-bye*/
	  {
		  sleep(1);
		  exit(0);
	  }
	  else			/*set daemon requirements up*/
	  {
		  setsid();
	  }
	} /*end of debug_mode*/
	/****************************************************/

	/*************/
	/*pid locking*/
	/*************/
	if( !lock_pid() )
	{
		printf(" pid locking error, maybe process has been run before!\n");
		do_log(9, "pid locking error, maybe process has been run before!");
		exit(2);
	}
	/*******************************************/

	/*start log*/
	do_log(9, "PowerBBS NNRP Server Initialize at port %d", NNRP_PORT);

	/* allocate socket file descriptor */
	sockfd = getsockfd();

	/*change process runnung user id and group*/
	change_run_id();

	/*get group setup*/
	get_group_set();

	/*set signal for disconnected child*/
#ifndef	SYSV
	(void) signal(SIGCHLD, (void*)reaper);
#endif
#ifdef	SYSV
	(void) signal(SIGCHLD, SIG_IGN);
#endif

	/*set idle signal*/
	(void) signal(SIGALRM, (void*)timeup);

	/* listenning */
	if( listen(sockfd, SOMAXCONN)<0 )
		err("main:listenning error?");
		/* Listen for client */

	/* big-loop for taking services */
	for( ; ; )
	{
		clilen = sizeof(cli_addr);
		newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);

		if (newsockfd < 0)
		{
			if( errno != EINTR ) do_log(7, "accept EINTR error");
			continue;
		}

		/* starting fork processing */
		switch(fork())
		{
		case -1: /*error*/
			do_log(7, "fork error");
			(void) close(newsockfd);
			break;

		case 0:	/*child*/
			(void) close(sockfd);
			strcpy(client_site, inet_ntoa(cli_addr.sin_addr) );
			do_log(5, "Connected with %s", client_site);
			serve(newsockfd);
				/*do service without return*/
			break;
		
		default: /*parent*/
			(void) close(newsockfd);
			break;
		} /*end of switch*/
	} /*end of for;;*/
}
/*end of main*/
