/*************************************************************************
 * recvfile.c --- receive file from client				 *
 *	      by Aquarius Kuo, Apr 15, 1994				 *
 *            new filexfer protocol by Samson Chen Apr 14, 1995          *
 *	      CPPOST version May 5, 1995				 *
 *************************************************************************/

#include "../host/pbbs.h"
#include "global.h"

static char rcsid[]="$Id: recvfile.c,v 1.3 1995/05/12 12:58:04 pbbs Exp pbbs $";

/*
	recv_file --- receive a file to client site
*/
int recv_file(fd, filename)
int fd;
char *filename;		/* in:upload path,  out:filename(no path) */
/*
	return:
		TRUE:	OK
		FALSE:	failed, unlink(filename), return then exit
*/
{
  int handle ;
  int i ;
  int tcpstat ;
  char prot ;
  char fn[120], *ptr ;
  char buffer[11000] ;
  long fl, len, len2 ;
  long BLOCK=1024 ;
  long len1, flen, fcnt ;
  long get_size;


  read_mpf(fd, fn, &len, &prot, FALSE);		/*--- get file name ---*/
  /*fn is the remote filename which will not be used in CPPOST*/
  fn[len]=0 ;
  if( prot!=FILEXFER )
  {
    return(FALSE) ; /*received failed, connection keep*/
  }  
  
  if(debug_mode) printf("(recvfile.c) filename local=(%s) remote=(%s)\n",filename,fn) ;  
  strcpy(fn,filename) ;
  
  if((handle=open(fn,O_CREAT|O_EXCL|O_WRONLY, S_IWUSR|S_IRUSR))<0)
  {
    if(debug_mode)	printf("(recvfile.c) %s open error!\n",fn) ;
    send_mpf(fd," ",1,STOPXFER) ;
    unlink(fn);
    return(FALSE); /*received failed*/
  } 

  send_mpf(fd," ",1,XFER_ACK) ; 

  /*get file length*/
  read_mpf(fd,buffer,&len1,&prot,FALSE) ;
  buffer[len1]=0 ;
  sscanf(buffer,"%ld",&flen) ;

  /*assumes good(should check disk space before this), ready to receive*/
  send_mpf(fd," ",1,XFER_ACK) ;

  /*receive file until length flen*/
  fcnt=0;
  while(fcnt<flen)
  {
    get_size=flen-fcnt;
    if( get_size>BLOCK )
        get_size=BLOCK;

    reset_alarm();	/*non-mpf xfer, must reset timer itself*/

    if( (tcpstat=read(fd,buffer,get_size)) >= 0 )
    {
      fcnt += tcpstat;
      write(handle, buffer, tcpstat);
    }
    else
    {
      unlink(fn);
      return(FALSE); /*received failed, connection lost*/
    }

  }/*end while*/

  close(handle);

  /*SYNCHRONIZATION*/
  tcpstat=read(fd, buffer, 1);
  if( tcpstat<0 )
  {
      unlink(fn);
      return(FALSE); /*received failed, connection lost*/
  }

  /*check SYNC*/
  if( buffer[0]!=END_XFER )
  {
      unlink(fn);
      return(FALSE); /*received failed, connection lost*/
  }

  /*sendback SYNC*/
  if( write(fd, buffer, 1)<0 )
  {
      unlink(fn);
      return(FALSE);
  }

  /*sending finished*/
  if(debug_mode) printf("(recvfile.c)receive (%s) successfully\n",fn) ;  

  return(TRUE) ; /*OK*/

}
/*end of send_file*/
