/* head file for group list data base format */

/*
        data base format for group list
*/      
struct group_struc {
        char    path[40];
        char    describe[50];
        char    new_post;
        int     join_level;
        int     post_level;
        int     gid;
        struct  group_struc *next;
        struct  group_struc *previous;
        };

static char     group_fetched=FALSE;    /*local flag for grouplist fetch*/
static int      group_items=0, max_gid=0;
static struct   group_struc *gid_begin_point, *gid_end_point, *group_head;    

