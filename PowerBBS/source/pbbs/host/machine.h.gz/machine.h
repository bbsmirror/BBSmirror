/****************************************************************************
 * machine.h --- machine codes for version identity			    *
 *		 by Samson Chen, Mar 9, 1993				    *
 ****************************************************************************/

/*
	machine type is a 4-bit long in the version id for client-server
	session checking.
	if you make any patch, please inform the author.
	machine.h is used at session.c/log_platform()
*/

#define P_SUN4		1
#define P_DOS		2
#define P_NETBSD	3
#define P_RS6K		4
#define P_DEC3K 	5
#define P_HPPA		6
#define P_ALPHA 	7
#define P_LINUX 	8
#define P_NEXTSTEP	9
#define P_MSWINDOWS	10
#define P_PC32		11
#define P_FREEBSD	12		/* Jones */
#define P_IRIX		13		/* Jones */
#define P_JAVA		14
