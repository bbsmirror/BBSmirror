/*************************************************************************
 * delmail.c --- delete mail						 *
 *	         by Samson Chen, Apr 19, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "dbf.h"
#include "message.h"
#include "global.h"

static char rcsid[]="$Id: delmail.c,v 1.20 1996/02/07 08:25:30 pbbs Exp pbbs $";


char bigbuf[MAX_BUF];
char line[255];


/*
	do_del_msg --- ask msg no for deleting
*/
do_del_msg(fd)
	int fd;
{
	char answer[80];
	int del_no;

	asking(fd, KILL_WHAT_MSG, answer, 80);

	del_no=atoi(answer);

	if(debug_mode) printf("(delmail.c)do_del_msg # %d\n", del_no);

	delete_message(fd, del_no-1, FALSE);
}
/*end of do_del_msg*/



/*
	delete_message --- (as the name)
*/
delete_message(fd, delno, all_yes)
	int fd;
	int delno;	/*the msg record no to be deleted*/
	char all_yes;	/*for del messages continously*/
/*
	return:
		TRUE:  deleted
		FALSE: no deleted
*/
{
	char filename[256];
	char ebuf[128];
	int mffd;
	int mfrec;
	int rec;
	struct msgrec mrec, mr;
	int total_msg;
	char *p;
	int ret;
	char crlf[3];
	char *sender;
	char *spath;
	char *mid;
	int fp;
	int n;
	char kill_net;
	char from_name[20];
	char from_field[128];
	char answer[80];
	char buf[255];
	char message_id[128];
	char unique_id[20];
	char timebuf[35];

	if(debug_mode) printf("(delmail.c)delete_message %d\n", delno);

	sprintf(crlf, "%c%c", 13, 10);

	/*------------------------------------------------------------*/
	if( strcmp(current_group, "mbox") )
	  sprintf(filename, "%s/%s/messages", MAIL_PATH, current_group);
	else
	  sprintf(filename, "%s/mbox/%d.messages", MAIL_PATH, user_uid);

	mffd=open(filename, O_RDWR|O_CREAT, S_IWUSR | S_IRUSR);
	/*------------------------------------------------------------*/

	/*------------------------------------------------------------*/
	if( strcmp(current_group, "mbox") )
	  sprintf(filename, "%s/%s/records", MAIL_PATH, current_group);
	else
	  sprintf(filename, "%s/mbox/%d.records", MAIL_PATH, user_uid);
	
	mfrec=open(filename, O_RDWR|O_CREAT, S_IWUSR | S_IRUSR);
	/*------------------------------------------------------------*/

	if( mffd<0 || mfrec<0 )
	{
		off_putmp();
		sprintf(ebuf, "delmail.c: %s", SYSTEM_ERROR);
		do_log(9, "SYSTEM ERROR in delmail %s", current_group);
		send_mpf(fd, ebuf, strlen(ebuf), REJECT);
		exit(12);
	}
	/*------------------------------------------------------------*/

	lseek(mfrec, 0 ,SEEK_END);
	total_msg=file_length(mfrec)/sizeof(struct msgrec);

	if( delno<0 || delno>=total_msg)
	{
		display_msg(fd, MSG_NO_ERR);
		suspend(fd);
		return(FALSE);
	}

	/*------------------------------------------------------------*/
	/*get the message*/

	lseek(mfrec, delno*sizeof(struct msgrec), SEEK_SET);
	read(mfrec, &mrec, sizeof(struct msgrec) );

	p=bigbuf;
	lseek(mffd, mrec.offset, SEEK_SET);
	ret=read(mffd, p, mrec.length);

	/*------------------------------------------------------------*/
	/*get message data*/
	fp=parse_msg(fd, bigbuf, "Message-ID: ");
	mid=bigbuf+fp;
	strip_nl(mid);
	mid+=12;

	fp=parse_msg(fd, bigbuf, "From: ");
	sender=bigbuf+fp;
	strip_nl(sender);
	sender+=6;

	fp=parse_msg(fd, bigbuf, "Path: ");
	spath=bigbuf+fp;
	strip_nl(spath);
	spath+=6;

	if(debug_mode) printf("(delmail.c)get ->%s, %s, %s\n", spath, sender, mid);

	/*------------------------------------------------------------*/
	/*check sender*/
	if( !system_operator && !group_moderator && strcmp(current_group, "mbox") && (user_level<CO_SYSOP_LEVEL) )
	/*SysOp, Moderator, mbox group will skip checking*/
	{
		nstrcpy(from_name, user_name, 20);
		for(n=0; n<strlen(from_name); n++)
			if( from_name[n]==' ' )
			{
				from_name[n]='_';
				break;
			}

		sprintf(from_field, "%s.pbbs@%s (%s)", from_name, NNRP_DOMAIN,  user_name);

		if( strcmp(sender, from_field) )
		{
			display_msg(fd, CANNOT_KILL);
			suspend(fd);
			return(FALSE);
		}
	}

	/*------------------------------------------------------------*/
	/*check sending station*/
	kill_net=FALSE;
	if( strcmp(STATION_ID, spath) && strcmp(current_group, "mbox") )
	{
		sprintf(buf, "%s\n", KILL_NET);
		display_msg(fd, buf);
		kill_net=TRUE;
	}

	/*------------------------------------------------------------*/

	/*re-confirm*/
	if( !all_yes )
	{
	  if( yes_no(fd, CONFIRM_MSG)!='y' )
		return(FALSE);
	}

	/*------------------------------------------------------------*/
	/*del local msg*/
	flock(mfrec, LOCK_EX);
	mrec.delete_mark='D';
	lseek(mfrec, delno*sizeof(struct msgrec), SEEK_SET);
	write(mfrec, &mrec, sizeof(struct msgrec) );
	flock(mfrec, LOCK_UN);

	/*------------------------------------------------------------*/
	/*set NNTP delete queue if post sent from local station*/
	if( !strcmp(PBBS_NNTP, "YES") && mrec.packed=='P' && (!kill_net) )
	{
	  /*this post has been exported*/

	  /*make a cmsg post for NNTP*/

	  flock(mfrec, LOCK_EX);
	  flock(mffd, LOCK_EX);

	  if(debug_mode) printf("(delmail.c)make a cmsg post for %s %s\n", sender, mid);

	  lseek(mffd, 0, SEEK_END);
	  mr.offset=file_length(mffd);
	  mr.subject[0]=0;
	  mr.packed=' ';
	  mr.delete_mark=' ';

	  memset(buf, 0, 255);
          sprintf(buf, "Path: %s%c%c", STATION_ID, 13, 10);
	  write(mffd, buf, strlen(buf) );

	  memset(buf, 0, 255);
	  sprintf(buf, "From: %s%c%c", sender, 13, 10);
	  write(mffd, buf, strlen(buf) );

	  memset(buf, 0, 255);
	  sprintf(buf, "Subject: cmsg cancel %s%c%c", mid, 13, 10);
	  nstrcpy(mr.subject, buf+9, 60);
	  write(mffd, buf, strlen(buf) );

	  memset(buf, 0, 255);
	  sprintf(buf, "Control: cancel %s%c%c", mid, 13, 10);
	  write(mffd, buf, strlen(buf) );

	  memset(buf, 0, 255);
          memset(message_id, 0, 128);
          memset(unique_id, 0, 20);
          get_mid(unique_id);
          sprintf(message_id, "<%s@%s>", unique_id, NNRP_DOMAIN);
          sprintf(buf, "Message-ID: %s%c%c", message_id, 13, 10);
	  write(mffd, buf, strlen(buf) );

          rfcgmtime(timebuf);
          memset(buf, 0, 255);
          sprintf(buf, "Date: %s GMT%c%c", timebuf, 13, 10);
	  write(mffd, buf, strlen(buf) );

          memset(buf, 0, 255);
          sprintf(buf, "Organization: %s%c%c", SORGANIZATION, 13, 10);
	  write(mffd, buf, strlen(buf) );

	  if( email_check(user_email) )
          {
		memset(buf, 0, 255);
                sprintf(buf, "Reply-To: %s%c%c", user_email, 13, 10);
		write(mffd, buf, strlen(buf) );
          }

          memset(buf, 0, 255);
          sprintf(buf, "%c%c", 13, 10);
	  write(mffd, buf, 2);

          memset(buf, 0, 255);
	  sprintf(buf, "Article cancelled from %s by %s%c%c", NNRP_DOMAIN, user_name, 13, 10);
	  write(mffd, buf, strlen(buf) );

          memset(buf, 0, 255);
	  sprintf(buf, "%s%c%c", "PowerBBS NNTP Manager", 13, 10);
	  write(mffd, buf, strlen(buf) );

	  lseek(mffd, 0, SEEK_END);
          mr.length=file_length(mffd)-mr.offset;

	  lseek(mfrec, 0, SEEK_END);
          write(mfrec, &mr, sizeof(mr) );

	  flock(mfrec, LOCK_UN);
	  flock(mffd, LOCK_UN);

	}/*end if*/

	/*------------------------------------------------------------*/
	close(mfrec);
	close(mffd);

	do_log(5,"%s delete %s record #%d", user_name, current_group, delno);
	display_msg(fd, MSG_KILLED);

	return(TRUE);
}
/*end of delete_message*/
