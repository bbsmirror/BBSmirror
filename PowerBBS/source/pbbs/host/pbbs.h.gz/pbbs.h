/*--- standard header for PBBS ---*/

#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>

#include <sys/resource.h>

/* #ifndef NEXTSTEP  */   
#ifndef NOMALLOC            /* Jones */
#include <malloc.h>
#endif

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/tcp.h>
#include <signal.h>
#include <errno.h>
#include <fcntl.h>
#include <ctype.h>
#include <memory.h>
#include <sys/file.h>
#include <netdb.h>

#include "protocol.h"
#include "../setup.h"

/*some system does not define SOMAXCONN constant like Linux*/
#ifndef SOMAXCONN
#define	SOMAXCONN 5
#endif

#define	SALT	"SC"	/*internal use (salt for crypt function)*/

/*avoid redefine by other head files (eg. curses.h)*/
#ifndef	FALSE
#define	FALSE	0
#endif

#ifndef	TRUE
#define	TRUE	!FALSE
#endif

/****************************************************/

#define	MAX_BUF			63488		/*62K buffer*/
#define	THIS_CALLED_SMALL	5120		/*how small is a small file*/
#define	FETCH_HEAD_SIZE		256
#define	IBUF_SIZE		10240
#define	MAX_QUOTE		151		/*max line number of quotation*/
#define	MAX_QUOTE_SIZE		MAX_QUOTE * 128

#define PBBS_DEFAULT_PORT	6203
#define	ACCEPT_VERSION	2	/*client required later than 1.0*/
#define PBBS_SERVER_VER	0x21	/*server protocol-arch version*/
/*
	if client's version is older than ACCEPT_VERSION.0 (1.0), connection
	will be reject

	if client's version is older than PBBS_SERVER_VER but later than
	ACCEPT_VERSION.0, connection accept but user will be informed a
	warnning message

	the structure of PBBS_SERVER_VER is

	|..4 bits..|..4 bits..|
	   prefix  . postfix

	eg. 
	16 = 0001 0000
	Version=    1.0
	21 = 0010 0001
	Version=    2.1
*/

/*
	function prototypes
*/
long	flength();
long	file_length();
