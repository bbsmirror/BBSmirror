/*************************************************************************
 * bulletin.c --- bulletin service function				 *
 *		  by Samson Chen, Dec 2, 1993				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"

static char rcsid[]="$Id: bulletin.c,v 1.7 1995/07/05 10:55:25 pbbs Exp pbbs $";

static char lowbul=FALSE;	/*lower layer of bulletin*/

char bigbuf[MAX_BUF];
char line_buf[255];

do_bulletin(fd)
	int fd;
{
	FILE *bulletin_file;
	char temp[80];
	char user_select[80];
	char bfile[255];
	int rlen;
	char protocol;
	char part_name[30];
	int n;
	char resend_menu=FALSE;
	int bfd;
	long blen;

	/*send bulletin menu*/
	sprintf(bfile, "%s/%s/%s", BULLETIN_PATH, bstack, BULLETIN_MENU_FILE);

	if( !file_exist(bfile) )	/*no bulletin menu file*/
	{
		strcpy(temp, NO_BULLETIN_MENU);
		send_mpf(fd, temp, strlen(temp), DISPLAY);
	}
	else	/*send bulletin menu*/
	{
		bulletin_file=fopen(bfile, "r");
		bigbuf[0]=0;
		while( fgets(line_buf, 255, bulletin_file) )
		{
			parse_macro(line_buf);
			strcat(bigbuf, line_buf);
		}
		send_mpf(fd, bigbuf, strlen(bigbuf), DISPLAY);
	}

	while(TRUE)	/*infinite loop untill user quit*/
	{

		if( !resend_menu )
		{
		  /*ask user*/
		  if( !lowbul )
			strcpy(temp, ASK_BULLETIN);
		  else
			strcpy(temp, ASK_BULLETIN_MORE);

		  send_mpf(fd, temp, strlen(temp), ASK);
		  read_mpf(fd, user_select, &rlen, &protocol, FALSE);
		  user_select[rlen]='\0';	/*null-terminated*/

		  /*if user press a enter directly (null data)*/
		  if( strlen(user_select) == 0 || user_select[0]==' ')
			return; /*enter to return*/
		}

		if( !strcmp(user_select, "?") || resend_menu )
		{
			/*retrans bulletin menu*/
			resend_menu=FALSE;

			update_act(5, " ");

			/*send bulletin menu*/
			sprintf(bfile, "%s/%s/%s", BULLETIN_PATH, bstack, BULLETIN_MENU_FILE);
			if( !file_exist(bfile) )	/*no bulletin menu file*/
			{
				strcpy(temp, NO_BULLETIN_MENU);
				send_mpf(fd, temp, strlen(temp), DISPLAY);
			}
			else	/*send bulletin menu*/
			{
				bulletin_file=fopen(bfile, "r");
				bigbuf[0]=0;
				while( fgets(line_buf, 255, bulletin_file) )
				{
					parse_macro(line_buf);
					strcat(bigbuf, line_buf);
					if( strlen(bigbuf) > (MAX_BUF-256) )
						break;
				}
				send_mpf(fd, bigbuf, strlen(bigbuf), DISPLAY);
			}
			continue;	/*start loop to ask user*/
		} /*end if*/

		if( lowbul && (user_select[0]=='q' || user_select[0]=='Q') )
		{
			/*go upper layer*/

			n=strlen(bstack);
			while(n>0)
			{
				if(bstack[n]=='/')
				{
					bstack[n]=0;

					if( strstr(bstack, "/") )
					{
						break;
					}
					else
					{
						strcpy(bstack, ".");
						lowbul=FALSE;
					}
				}

				n--;
			}

			if(n==0)
			{
				/*uppest layer*/
				strcpy(bstack, ".");
				lowbul=FALSE;
			}

			resend_menu=TRUE;
			continue;
		}

		/*strip user select to make it no path*/
		strip_nl(user_select);
		split_filename(user_select, part_name);
		sprintf(bfile, "%s/%s/%s", BULLETIN_PATH, bstack, part_name);

		if( path_exist(bfile) )
		{
			/*hierachy bulletin menu*/
			strcat(bstack, "/");
			strcat(bstack, part_name);
			lowbul=TRUE;
			resend_menu=TRUE;
			continue;
		}

		if( !file_exist(bfile) )	/*user selection not found*/
		{
			strcpy(temp, NO_SUCH_BULLETIN);
			send_mpf(fd, temp, strlen(temp), DISPLAY);
			continue;	/*re-ask user*/
		}

		update_act(5, part_name);

		/*user select found --- send it*/
		bfd=open(bfile, O_RDWR);
		blen=file_length(bfd);

		if( blen<=THIS_CALLED_SMALL )
		{
		  close(bfd);

		  bulletin_file=fopen(bfile, "r");
		  bigbuf[0]=0;
		  while( fgets(line_buf, 255, bulletin_file) )
		  {
			parse_macro(line_buf);
			strcat(bigbuf, line_buf);
		  }
		  send_mpf(fd, bigbuf, strlen(bigbuf), DISPLAY);
		}
		else
		{
		  fd_direct_send_mpf(fd, bfd, blen, DISPLAY);
		  close(bfd);
		}

		do_log(1, "%s read bulletin %s", user_name, user_select);

	} /*end of while*/



}
