/**************************************************************************
 * udb.c --- user database process routines				  *
 *	     by Samson Chen, Mar 16, 1994				  *
 **************************************************************************/

#include <errno.h>
#include "pbbs.h"
#include "dbf.h"
#include "global.h"

static char rcsid[]="$Id: udb.c,v 1.3 1994/05/14 00:24:19 pbbs Exp pbbs $";

/*
	get_user_id --- get user id from user database
*/
get_user_id(name)
	char *name;	/*bbs_name not real name*/
/*
	return:
		user id number
		note: uid >= 1, because 0 means user not found
*/
{
	char udbfile[255];
	int udbf;
	int ret;


	/*test user database file*/
	sprintf(udbfile, "%s.dbf", USER_DATA_BASE);

	if( !file_exist(udbfile) )
	{
		udbf=open( udbfile, O_WRONLY | O_APPEND | O_CREAT, S_IWUSR | S_IRUSR);
		close(udbf);
		return(0);	/*no such user*/
	}

	/*index search*/
	ret=found(name);
	if(ret==FALSE) return(0);

	if(debug_mode) printf("(udb.c)get uid %d\n", ret);

	return(ret);
}
/*end of get_user_id*/



/*
	add_user_record --- add a new user record to user database
*/
add_user_record(user)
	struct udb *user;
{

	char udbfile[255];
	int udbf;
	char *bp;
	int sz;
	int cc;
	int uid;
	int recno=0;
	struct udb rec;
	struct system_rec sysrec;

	sprintf(udbfile, "%s.dbf", USER_DATA_BASE);

	sz=sizeof(struct udb);
	bp=(char*)user;

	udbf=open(udbfile, O_RDWR);

        flock(udbf, LOCK_EX);

	/*get system record*/
	lseek(udbf, 0, SEEK_SET);
	read(udbf, &sysrec, sizeof(struct system_rec) );
	sysrec.total_regs++;
	total_regs=sysrec.total_regs;
	lseek(udbf, 0, SEEK_SET);
	write(udbf, &sysrec, sizeof(struct system_rec) );

	/*scan for empty slot*/
	recno=1;
	lseek(udbf, recno*sizeof(struct udb), SEEK_SET);

        while( read(udbf, &rec, sizeof(struct udb) ) )
        {
                if( rec.delete_mark=='X' )     /*empty slot*/
                {
                        lseek(udbf, recno*sizeof(struct udb), SEEK_SET);

			do
			{
				cc=write(udbf, bp, sz);
				if( cc>0 )
				{
					bp += cc;
					sz -= cc;
				}

			if( debug_mode )
			  if( cc<0 ) printf("(udb.c.a)Error : %d\n", errno);
			}
			while( sz>0 );

			uid=recno;

			do_index(user->bbs_name, uid);

                        flock(udbf, LOCK_UN);
                        close(udbf);
                        return(uid);
                }
                recno++;
        }

        flock(udbf, LOCK_UN);
        close(udbf);

	/*no empty slot*/
	udbf=open(udbfile, O_WRONLY | O_APPEND, S_IWRITE);

	flock(udbf, LOCK_EX);    /*exclusive lock*/

        do
        {
                cc=write(udbf, bp, sz);
                if( cc>0 )
                {
                        bp += cc;
                        sz -= cc;
                }

	if( debug_mode )
		if( cc<0 ) printf("(udb.c.b)Error : %d\n", errno);

        }
        while( sz>0 );

	uid = file_length(udbf)/sizeof(struct udb)-1;
	if( debug_mode ) printf("(udb.c)add new user id %d\n", uid);

	if( debug_mode ) printf("(udb.c)creat %s uid %d\n", user->bbs_name, uid);

	do_index(user->bbs_name, uid);

        flock(udbf, LOCK_UN);    /*unlock*/

	close(udbf);

	return(uid);

}
/*end of add_user_record*/
