/*************************************************************************
 * intrread.c --- interactive read					 *
 *	      by Samson Chen, Apr 22, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"
#include "dbf.h"

static char rcsid[]="$Id: intrread.c,v 1.21 1995/11/01 15:16:29 pbbs Exp pbbs $";

char searched_string[80]="";

/*
	inter_read --- interactive reading
*/
inter_read(fd)
	int fd;
/*
	return:
		TRUE:	all mails are read
		FALSE:  still have unread mails
*/
{
	char inter_buf[IBUF_SIZE];
	char bigbuf[10240];
	char line[255];

	int mp_low=1;
	int mp_high=0;
	int old_total_msg=-1;
	int mp_be4_search=0;

	char answer[80];
	int scr_size;	/*client's screen size*/
	int scrcnt;
	int rlen;
	char protocol;
	char filename[256];
	char ebuf[256];
	char txtbuf[80];
	int mffd;
	int mfrec;
	struct msgrec mrec;
	int mp;	/*message pointer*/
	char leave;
	int total_msg;
	int recno;
	int ret;
	char crlf[3];
	int fp;
	char from_name[80];
	int cpn, slen;
	char from_line[80];
	char *from_field, *subject_field;
	char *ptr;
	int readfrom;
	char error_entry[20];
	char forward_dir;
	char *ibuf_head;
	char prompt_line[80];

	update_act(6, group_areaname);

	strcpy(error_entry, "<ERROR>");

	/*get client's screen size*/
	scr_size=get_scrsize(fd);

	forward_dir=TRUE;		/*assume read forward*/

	if(debug_mode) printf("(intrread.c)get screen size %d\n", scr_size);


	/*------------------------------------------------------------*/
	if( strcmp(current_group, "mbox") )
	  sprintf(filename, "%s/%s/messages", MAIL_PATH, current_group);
	else
	  sprintf(filename, "%s/mbox/%d.messages", MAIL_PATH, user_uid);

	mffd=open(filename, O_RDONLY|O_CREAT, S_IWUSR | S_IRUSR);
	/*------------------------------------------------------------*/

	/*------------------------------------------------------------*/
	if( strcmp(current_group, "mbox") )
	  sprintf(filename, "%s/%s/records", MAIL_PATH, current_group);
	else
	  sprintf(filename, "%s/mbox/%d.records", MAIL_PATH, user_uid);
	
	mfrec=open(filename, O_RDONLY|O_CREAT, S_IWUSR | S_IRUSR);
	/*------------------------------------------------------------*/

	if( mffd<0 || mfrec<0 )
	{
		off_putmp();
		sprintf(ebuf, "intrread.c: %s", SYSTEM_ERROR);
		do_log(9, "SYSTEM ERROR intrread.c group %s", current_group);
		send_mpf(fd, ebuf, strlen(ebuf), REJECT);
		exit(12);
	}


	/*------------------------------------------------------------*/

	sprintf(crlf, "%c%c", 13, 10);

	total_msg=file_length(mfrec)/sizeof(struct msgrec);

	mp=get_lastread(fd)-1;
	if(mp>=total_msg) mp=total_msg-1;
	if(mp<0) mp=0;

	/***************/
	/*change prompt*/
	/***************/

	if( gf_name[0]!=0 )
	  sprintf(prompt_line, "%s %.15s, %s %s, %s %d", CURRENT_POSTGROUP, group_areaname, GROUP_MODERATOR, gf_name, TOTAL_MESSAGES, total_msg);
	else
	  sprintf(prompt_line, "%s %.15s, %s %d", CURRENT_POSTGROUP, group_areaname, TOTAL_MESSAGES, total_msg);

	change_intr_prompt(fd, prompt_line);

	/***************/

	leave=FALSE;
	do
	{
	  total_msg=file_length(mfrec)/sizeof(struct msgrec);

	  if( old_total_msg != total_msg )
	  {
		/*msgs updated, IBUF must be rescanned*/
		old_total_msg=total_msg;
		mp_low=1;
		mp_high=0;
	  }

	  if( mp<0 )
		mp=total_msg-1;
	  else if( mp>=total_msg )
	  {
		mp=total_msg-1;
		mp_low=1;	/*rescan IBUF*/
		mp_high=0;
	  }

	if( mp<mp_low || mp>mp_high )
	{
	  /*user not in the same INTRREAD page*/
	  inter_buf[0]=0;
	  scrcnt=0;
	  recno=mp;

	  if( forward_dir )
	  {
		ibuf_head=inter_buf;
		mp_low=mp;
	  }
	  else
	  {
		ibuf_head=inter_buf + (IBUF_SIZE-1);
		*ibuf_head=0;
		mp_high=mp;
	  }

	  if(debug_mode) printf("(intrread.c)assemble selections, mp=%d\n", mp);

	  do
	  {
		if( total_msg<=0 )
			break;

		if( recno<0 )
		{
			inter_buf[0]=0;
			ibuf_head=inter_buf;
			scrcnt=0;
			recno=0;
			mp_low=0;
			forward_dir=TRUE;
		}
		else if( recno>=total_msg )
				break;

		/*----------------------------------------------------*/

		lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
		read(mfrec, &mrec, sizeof(struct msgrec) );

		/*----------------------------------------------------*/

		/*check delete mark*/
		if( mrec.delete_mark=='D' )
		{
			if( forward_dir )
				recno++;
			else
				recno--;

			continue;
		}

		/*get message head*/

		lseek(mffd, mrec.offset, SEEK_SET);
		fetch_msg_head(fd, mffd, mrec.length, bigbuf);


		/*parse message head*/

		fp=parse_msg(fd, bigbuf, "Subject: ");
		if( fp<0 )
		{
			subject_field=error_entry;
		}
		else
		{
			subject_field=bigbuf+fp;
			strip_nl(subject_field);
			subject_field+=9;
		}

		/*skip cmsg cancel message*/
		if( !strncmp(subject_field, "cmsg cancel", 11) )
		{
			if( forward_dir )
				recno++;
			else
				recno--;

			continue;
		}

		fp=parse_msg(fd, bigbuf, "From: ");
		if( fp<0 )
		{
			subject_field=error_entry;
		}
		else
		{
			from_field=bigbuf+fp;
			strip_nl(from_field);
			from_field+=6;
		}

		from_name[0]=0;

		nstrcpy(from_line, from_field, 80);
		ptr=strtok(from_line, "@");

		if( ptr != NULL )
		{
			nstrcpy(line, ptr, 80);
			if( strlen(line)>4 && strlen(line)<75 )
			{
			  if( !strcmp(line+(strlen(line)-4), ".bbs") )
			  {
				strcpy(from_name, line);
				from_name[strlen(line)-3]=0;
			  }
			}
		}

		if( from_name[0]==0 )
		{
		  nstrcpy(from_line, from_field, 80);
		  ptr=strtok(from_line, "(<[");

		  if( ptr !=NULL )
		  {
			ptr=strtok(NULL, ")>]");
			if( ptr!=NULL )
				nstrcpy(from_name, ptr, 80);
			else
				nstrcpy(from_name, from_field, 80);
		  }
		  else
			nstrcpy(from_name, from_field, 80);
		}

		strip_nl(from_name);

		/*assemble head buffer*/

		line[0]=0;
		sprintf(txtbuf, "%d", recno+1);
		strcat( line, txtbuf );
		strcat( line, crlf );
		strcat( line, subject_field);
		strcat( line, crlf );
		strcat( line, from_name );
		strcat( line, crlf );

		if( forward_dir )
		{
			strcat( ibuf_head, line );
		}
		else
		{
			ret=strlen(line);
			ibuf_head -= ret;

			for(ret=0; ret<strlen(line); ret++)
				ibuf_head[ret]=line[ret];
		}

		/* add counter*/

		scrcnt++;

		if( forward_dir )
			recno++;
		else
			recno--;

	  }while(scrcnt<scr_size);

	  if( forward_dir )
		mp_high=recno-1;
	  else
		mp_low=recno+1;

	  send_mpf(fd, ibuf_head, strlen(ibuf_head), INTRREAD);

	}/*end if mp_low/high*/
	else
	{
	  send_mpf(fd, "SAME_BUFFER", 11, INTRREAD);
	}


	  /*
	  if(debug_mode) printf("(intrread.c)inter_buf->\n%s\n", inter_buf);
	  */

	  read_mpf(fd, answer, &rlen, &protocol, FALSE);
	  if( protocol != INTRREAD )
	  {

		do_log(8, "%s protocol_stat_err with protocol code %d at intrread", user_name, protocol);
		protocol_stat_err(fd);
	  }

	  answer[rlen]=0;
	  strip_nl(answer);

	  /*---------------------------------------*/

	  if(answer[0]=='q' || answer[0]=='Q')
	  {
		/*quit interactive reading*/
		leave=TRUE;
		continue;
	  }

	  if(answer[0]=='s' || answer[0]=='S')
	  {
		/*search topic*/
		if( strlen(searched_string)<=0 )
		  strcpy(ebuf, SEARCH_PATTERN);
		else
		  sprintf(ebuf, "%s[%s] ", SEARCH_PATTERN, searched_string);

		asking(fd, ebuf, answer, 60);
		strip_nl(answer);

		if( answer[0]==0 || answer[0]==13 || answer[0]==10 )
		{
			if( strlen(searched_string)<=0 )
				continue;
		}
		else
		  nstrcpy(searched_string, answer, 80);

		mp_be4_search=mp;
		while(TRUE)
		{
		  mp++;
		  if( mp>=total_msg )
		  {
		    mp=mp_be4_search;
		    break;
		  }

		  lseek(mfrec, mp*sizeof(struct msgrec), SEEK_SET);
		  read(mfrec, &mrec, sizeof(struct msgrec) );
		  if( mrec.delete_mark=='D' )
		    continue;

		  if( strstr(mrec.subject, searched_string) )
		  {
		    /*IBUF must be rescanned*/
		    mp_low=1;
		    mp_high=0;
		    forward_dir=TRUE;
		    break;
		  }
		}/*end while*/

		continue;
	  }

	  if(answer[0]=='e' || answer[0]=='E')
	  {
		/*post a new mail*/
		enter_mail(fd, 0, NULL, NULL, NULL);
		continue;
	  }

	  if(answer[0]=='f' || answer[0]=='F')
	  {
		/*post a new mail by filepost*/
		enter_mail(fd, 2, NULL, NULL, NULL);
		continue;
	  }


	  if(answer[0]=='u' || answer[0]=='U')
	  {
		if(debug_mode) printf("(intrread.c)PageUp\n");

		/*PageUp*/
		mp=mp_low-1;
		forward_dir=FALSE;
		continue;
	  }

	  if(answer[0]=='d' || answer[0]=='D')
	  {
		if(debug_mode) printf("(intrread.c)PageDown\n");

		/*PageDown*/
		mp=mp_high+1;
		forward_dir=TRUE;
		continue;
	  }

	  /*---------------------------------------*/

	  readfrom=atoi(answer);

	  if( readfrom < 1 )
		readfrom=1;

	  if( readfrom > total_msg )
		readfrom=total_msg;

	  if(debug_mode) printf("(intrread.c)user select %d\n", readfrom);

	  readfrom--;

	  if( readfrom<mp_low || readfrom>mp_high )
	  {
	    /*user chose out of intrread page*/
	    mp=readfrom;
	    set_lastread(fd, mp+1);

	    /*IBUF must be rescanned*/
	    mp_low=1;
	    mp_high=0;
	    forward_dir=TRUE;
	  }
	  else
	  {
	    read_mail(fd, 1, readfrom);
	    mp=get_lastread(fd)-1;
	  }

	  forward_dir=TRUE;		/*reset direction flag*/

	}while(!leave);

	/******************************************************/
	/*make last_read more correct if last post was deleted*/
	/*----------------------------------------------------*/
	total_msg=file_length(mfrec)/sizeof(struct msgrec);
	recno=get_lastread(fd);
	while( recno<total_msg )
	{
		lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
		read(mfrec, &mrec, sizeof(struct msgrec) );
		if( mrec.delete_mark=='D' )
		{
			recno++;
			set_lastread(fd, recno);
			continue;
		}
		else
			break;
	}
	/******************************************************/

	close(mffd);
	close(mfrec);

	/*if mails unread*/
	total_msg=file_length(mfrec)/sizeof(struct msgrec);
	recno=get_lastread(fd);

	if( recno<total_msg )
		return(FALSE);
	else
		return(TRUE);
}
/*end of inter_read*/
