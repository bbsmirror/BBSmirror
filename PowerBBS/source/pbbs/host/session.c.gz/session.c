/************************************************************************
 * session.c --- some routines for makeing session of PBBS		*
 *		 by Samson Chen, Nov 29, 1993				*
 ************************************************************************/

#include "pbbs.h"
#include "global.h"
#include "message.h"
#include "machine.h"

static char rcsid[]="$Id: session.c,v 1.11 1996/01/26 17:53:18 pbbs Exp pbbs $";

/*
	get some garbage codes from client side, suppose user does not
	use the client of PBBS
*/
session1_err(fd)
	int fd;
{
	char *msg=NOT_PBBS_CLIENT;

	do_log(2, "%s did not use PBBS client", client_site);
	write(fd, msg, strlen(msg) );

	/*close session*/
	close(fd);
	exit(1);
}
/*end of sesson1_err*/


/*
	client does not send the correct identify string, suppose some
	error occurred
*/
session2_err(fd)
	int fd;
{
	char *msg=SESSION_PROC_ERR;

	do_log(3, "%s did not follow PBBS protocol", client_site);
	send_mpf(fd, msg, strlen(msg), REJECT );

	/*close session*/
	close(fd);
	exit(2);
}
/*end of session2_err*/


/*
	the version of client too old, so that maybe some protocol from
	server cannot be processed correctly
*/
session3_err(fd)
	int fd;
{
	char *msg=CLIENT_TOO_OLD;

	send_mpf(fd, msg, strlen(msg), REJECT );

	/*close session*/
	reject(fd, 3);
}
/*end of session3_err*/


/*
	the service requested by the client was unknown
*/
service_unknown(fd)
	int fd;
{
	char *msg=UNKNOWN_SERVICE;

	do_log(3, "%s request an unknown service", client_site);
	send_mpf(fd, msg, strlen(msg), REJECT );

	/*close session*/
	reject(fd, 5);
}
/*end of service_unknown*/



/*
	protocol_stat_err --- client protocol stat predict mistake
*/
protocol_stat_err(fd)
	int fd;
{
	char *msg=PROTOCOL_STAT_ERROR;

	do_log(5, "%s send a protocol out of prediction", client_site);
	send_mpf(fd, msg, strlen(msg), REJECT );

	/*close session*/
	reject(fd, 8);
}
/*end of protocol_stat_err*/



/*
	check the client's version number
*/
check_ver(h)
	unsigned char h;
/*
	return: 0 = OK
		-1= too old
*/
{
	char prefix;
	char postfix;

	prefix=(h & 0xf0) >> 4;
	postfix=(h & 0xf);

	do_log(0, "version of client at %s is %d.%d", client_site, prefix, postfix);

	/*version too old?*/
	if( prefix < ACCEPT_VERSION ) return(-1);	/*version too old*/

	if( h < PBBS_SERVER_VER ) return(0);	/*old version, but accept it*/

	return(1);				/*ok*/
}
/*end of check_ver*/



/*
	log client's platform
*/
log_platform(p)
	unsigned char p;
{
	char machine;
	char sound;
	char graphic;
	char m[20];

	sound=p & 1;
	graphic=p & 2;
	machine=(p & 0xf0)>>4;

	switch(machine)
	{
	case P_SUN4:
		strcpy(m, "SUN4");
		break;

	case P_DOS:
		strcpy(m, "DOS");
		break;

	case P_NETBSD:
		strcpy(m, "NETBSD");
		break;

	case P_RS6K:
		strcpy(m, "RS6K");
		break;

	case P_DEC3K:
		strcpy(m, "DEC3K");
		break;

	case P_HPPA:
		strcpy(m, "HPPA");
		break;

	case P_ALPHA:
		strcpy(m, "ALPHA");
		break;

	case P_LINUX:
		strcpy(m, "LINUX");
		break;

	case P_NEXTSTEP:
		strcpy(m, "NEXTSTEP");
		break;

	case P_MSWINDOWS:
		strcpy(m, "MSWIN");
		break;

	case P_PC32:
		strcpy(m, "Win32/OS2");
		break;

	case P_FREEBSD:
		strcpy(m, "FREEBSD");
		break;

	case P_IRIX:
		strcpy(m, "IRIX");
		break;

	case P_JAVA:
		strcpy(m, "JAVA");
		break;

	default:
		strcpy(m, "Unknown platform???");
		break;
	}

	if( sound && graphic )
		do_log(2, "%s use %s with sound and graphics", client_site, m);
	else if( sound )
		do_log(2, "%s use %s with sound", client_site, m);
	else if( graphic )
		do_log(2, "%s use %s with graphics", client_site, m);
	else
		do_log(2, "%s use %s", client_site, m);
}/*end of log_platform*/



/*
	get_remote_host --- get remote host domain name
	(code from NCSA httpd)
*/
get_remote_host(fd, remote)
	int fd; 	/*network fd*/
	char *remote;	/*the name*/
/*
	return:
		(domain name put in *remote)
		if failed, *remote will be kept as it was called
*/
{
  struct sockaddr addr;
  int len;
  struct in_addr *iaddr;
  struct hostent *hptr;

  len = sizeof(struct sockaddr);

  if ((getpeername(fd, &addr, &len)) < 0)
	return;

  iaddr = &(((struct sockaddr_in *)&addr)->sin_addr);
  hptr = gethostbyaddr((char *)iaddr, sizeof(struct in_addr), AF_INET);
  if(hptr)
	strcpy(remote, hptr->h_name);
}
/*end of get_remote_host*/



/*
	client disconnect abnormally
*/
abnormal_disconnect(fd)
{

	do_log(5, "%s from %s disconnect abnormally!", user_name, client_site);

	if( fail_then_remove )
	{
	  fail_then_remove=FALSE;
	  do_log(5, "%s fail_then_remove %s", user_name,  f_t_r_filename);
	  unlink(f_t_r_filename);
	}

	off_putmp();

	close(fd);
	exit(6);
}
/*and of abnormal_disconnect*/
