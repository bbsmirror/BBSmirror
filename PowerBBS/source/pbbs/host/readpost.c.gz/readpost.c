/*************************************************************************
 * readpost.c --- read posts						 *
 *	      by Samson Chen, Apr 2, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"
#include "dbf.h"

static char rcsid[]="$Id: readpost.c,v 1.30 1996/02/07 09:19:30 pbbs Exp pbbs $";

char bigbuf[MAX_BUF];
char line_buf[255];



/*
	readpost --- reading posts
*/
read_mail(fd, read_dir, readfrom)
	int fd;
	int read_dir;	/*read direction*/
	int readfrom;	/*for inter-read, -1 mean use lastread*/
{
	char filename[256];
	char ebuf[256];
	int mffd;
	int mfrec;
	int rec;
	struct msgrec mrec;
	char *p;
	int total_msg=0;
	int recno=0;
	int ret;
	int rlen;
	int msg_head_len_before_parsing;
	long load_len;
	char protocol;
	char answer[80];
	char crlf[3];
	int fp, mvp;
	char *msgtxt;
	char *path_field, *from_field, *subject_field, *reply_field;
	char *date_field;
	char from_line[80], from_name[80];
	char reply_add[80];
	int cpn, slen;
	char continue_reply, send_post_by_email;
	char *ptr;
	char search_topic;	/*topic searching flag*/
	char full_match;
	char searched_topic[80];
	char be_search[80];
	static char searched_string[80]="";
	int s_pos;
	char search_match;
	int last_stop = -1;  /*used for topic search when search not found*/
	int i;		   /*temp counter*/
	int cdel_from, cdel_to;	/*for delete continuously*/
	char *cdel_tok;


	if(debug_mode) printf("(readpost.c)read_mail\n");

	update_act(6, group_areaname);

	/*------------------------------------------------------------*/
	if( strcmp(current_group, "mbox") )
	  sprintf(filename, "%s/%s/messages", MAIL_PATH, current_group);
	else
	  sprintf(filename, "%s/mbox/%d.messages", MAIL_PATH, user_uid);

	mffd=open(filename, O_RDONLY|O_CREAT, S_IWUSR | S_IRUSR);
	/*------------------------------------------------------------*/

	/*------------------------------------------------------------*/
	if( strcmp(current_group, "mbox") )
	  sprintf(filename, "%s/%s/records", MAIL_PATH, current_group);
	else
	  sprintf(filename, "%s/mbox/%d.records", MAIL_PATH, user_uid);

	mfrec=open(filename, O_RDONLY|O_CREAT, S_IWUSR | S_IRUSR);
	/*------------------------------------------------------------*/

	if( mffd<0 || mfrec<0 )
	{
		off_putmp();
		do_log(9, "SYSTEM ERROR readpost.c %s", current_group);
		sprintf(ebuf, "readpost.c: %s", SYSTEM_ERROR);
		send_mpf(fd, ebuf, strlen(ebuf), REJECT);
		exit(12);
	}

	if( readfrom<0 )
		recno=get_lastread(fd);
	else
		recno=readfrom;

	search_topic=FALSE;
	while(1)
	{
		lseek(mfrec, 0 ,SEEK_END);
		total_msg=file_length(mfrec)/sizeof(struct msgrec);

		if( recno >= total_msg )
		{
			if( last_stop>=0 && last_stop<total_msg )
			{
				/*user searching finished*/
				recno=last_stop;
				last_stop = -1;
				search_topic=FALSE;
				continue;
			}

			display_msg(fd, NO_NEW_MSG);
			set_lastread(fd, total_msg);
			suspend(fd);
			break;
		}

		if( recno<0 )
		{
			if( last_stop>=0 && last_stop<total_msg )
			{
				/*user searching finished*/
				recno=last_stop;
				last_stop = -1;
				search_topic=FALSE;
				continue;
			}

			display_msg(fd, MSG_NO_ERR);
			set_lastread(fd, 0);
			suspend(fd);
			break;
		}

		/*----------------------------------------------------*/

		lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
		read(mfrec, &mrec, sizeof(struct msgrec) );

		/*----------------------------------------------------*/

		/*check delete mark*/
		if( mrec.delete_mark=='D' )
		{
			if( read_dir>=0 )
				recno++;
			else
				recno--;
			continue;
		}

		/*----------------------------------------------------*/

		recno++;
		subject_field=mrec.subject;

		/*----------------------------------------------------*/

		/*skip cmsg cancel message*/
		if( !strncmp(subject_field, "cmsg cancel", 11) )
		{
			if( read_dir<0 )
				recno-=2;

			continue;
		}

		/*----------------------------------------------------*/

		if(search_topic)
		{
			for(s_pos=fp; s_pos<(fp+79); s_pos++)
				if( bigbuf[s_pos]==13 || bigbuf[s_pos]==10 |bigbuf[s_pos]==0 )
					break;

			strncpy(be_search, subject_field, s_pos-fp);
			be_search[s_pos-fp]=0;

			if(debug_mode) printf("(readpost.c)compare %d: '%s' with '%s'\n", recno-1, searched_topic, be_search);

			search_match=FALSE;

			if( full_match )
			{
			  if( strncmp(be_search, "Re: ", 4) )
			  {
				if( !strcmp(be_search, searched_topic) )
					search_match=TRUE;
			  }
			  else
			  {
				if( !strcmp(be_search+4, searched_topic) )
					search_match=TRUE;
			  }
			}
			else
			{
				/*partial match*/
				if( strstr(be_search, searched_string) )
					search_match=TRUE;
			}

			if( !search_match )
			{
				if( read_dir<0 )
					recno -= 2;

				continue;
			}

			search_topic=FALSE;
			last_stop = -1;

			/*search found --- continue mail loading*/
		}

		/*----------------------------------------------------*/
		p=bigbuf;

		sprintf(p, "Area: %s%c%c", group_areaname, 13, 10);
		ret=strlen(p);
		p+=ret;

		sprintf(p, "Total: %d%c%c", total_msg, 13, 10);
		ret=strlen(p);
		p+=ret;

		sprintf(p, "Msgno: %d%c%c", recno, 13, 10);
		ret=strlen(p);
		p+=ret;

		lseek(mffd, mrec.offset, SEEK_SET);
		fetch_msg_head(fd, mffd, mrec.length, p);
		msg_head_len_before_parsing=strlen(p);
		/*----------------------------------------------------*/

		/*remove Control: if exist*/
		fp=parse_msg(fd, bigbuf, "Control: ");
		if( fp>0 )
		{
		  mvp=fp;
		  while(bigbuf[mvp]!=0xd && bigbuf[mvp]!=0xa)
		    mvp++;	/*cut the line*/
		  if(bigbuf[mvp+1]==0xd || bigbuf[mvp+1]==0xa)
		    mvp++;
		  mvp++;
		  while(bigbuf[mvp]!=0)
		  {
		    bigbuf[fp]=bigbuf[mvp];
		    fp++;
		    mvp++;
		  }
		  bigbuf[fp]=0;
		}

		/*----------------------------------------------------*/

		/*convert GMT to local time*/

		fp=parse_msg(fd, bigbuf, "Date: ");
		fp+=6;	/*skip "Date: "*/
		date_field=bigbuf+fp;
		gmtlocal(date_field);

		/*----------------------------------------------------*/

		if(debug_mode) printf("(readpost.c)send %dth post\n", recno);
		lseek(mffd, mrec.offset, SEEK_SET);
		post_direct_send_mpf(fd, mffd, bigbuf, msg_head_len_before_parsing, mrec.length);

		set_lastread(fd, recno);

		read_mpf(fd, answer, &rlen, &protocol, FALSE);
		answer[rlen]=0;
		if( protocol != GETPOST )
		{
			do_log(8, "%s protocol_stat_err with protocol code %d at read_mail", user_name, protocol);
			protocol_stat_err(fd);
		}

		/*----------------------------------------------------*/

		if( answer[0]=='q' || answer[0]=='Q' )
			break;

		/*----------------------------------------------------*/

		if( answer[0]=='k' || answer[0]=='K' )
		{
		  if( system_operator || group_moderator || !strcmp(current_group, "mbox") || (user_level>=CO_SYSOP_LEVEL) )
		  {
		    /*delete continuously allowed*/
		    asking(fd, KILL_MSGS, answer, 60);
		    strip_nl(answer);
		    cdel_tok=strchr(answer, '-');
		    if( (cdel_tok==(char*)NULL) && (atoi(answer)>0) )
		    {
		      cdel_from=atoi(answer);
		      sprintf(answer, "%d-%d", cdel_from, cdel_from);
		      cdel_tok=strchr(answer, '-');
		    }

		    if( cdel_tok!=(char*)NULL )
		    {
		      *cdel_tok=0;
		      cdel_from=atoi(answer);
		      cdel_tok++;
		      cdel_to=atoi(cdel_tok);
		      if( cdel_to<cdel_from ) cdel_to=cdel_from;
		      sprintf(ebuf, "%d ... %d %s", cdel_from, cdel_to, KILL_CONTINUOUSLY);
		      if( yes_no(fd, ebuf)=='y' )
		      {
			for(recno=cdel_from; recno<=cdel_to; recno++)
			{
			  if( !delete_message(fd, recno-1, TRUE) )
			    break;
			}
			if( recno>cdel_to )
			  recno=cdel_to;
		      }
		      else
		        recno--;		/*not deleted*/

		      continue;
		    }
		  }

		  /*normal delete action*/
		  if( delete_message(fd, recno-1, FALSE) )
		  {
		    if( read_dir<=0 )	/*deleted*/
		      recno-=2;
		  }
		  else
		    recno--;		/*not deleted*/

		  continue;
		}

		/*----------------------------------------------------*/
		if( answer[0]=='c' || answer[0]=='C' )
		{
			if( system_operator || group_moderator )
			  set_cream_mark(fd, recno-1);
			else
			  show_cream_post(fd);

			recno--;
			continue;
		}

		/*----------------------------------------------------*/

		if( answer[0]=='e' || answer[0]=='E' )
		{
			enter_mail(fd, 0, NULL, NULL, NULL);
			recno--;	/*stay at the same position*/
			continue;
		}

		/*----------------------------------------------------*/

		if( answer[0]=='f' || answer[0]=='F' )
		{
			enter_mail(fd, 2, NULL, NULL, NULL);
			recno--;	/*stay at the same position*/
			continue;
		}

		/*----------------------------------------------------*/

		if( answer[0]=='r' || answer[0]=='R' || answer[0]=='m' || answer[0]=='M' )
		{
			sprintf(crlf, "%c%c", 13, 10);

			if( answer[0]=='m' || answer[0]=='M' )  /*reply to author*/
			  send_post_by_email=TRUE;
			else
			  send_post_by_email=FALSE;

			/*reload message*/
			lseek(mffd, mrec.offset, SEEK_SET);
			load_len=mrec.length;
			if( load_len>=MAX_QUOTE_SIZE )
			  load_len=MAX_QUOTE_SIZE;
			ret=read(mffd, bigbuf, load_len);
			bigbuf[ret]=0;

			fp=parse_msg(fd, bigbuf, "MSG");
			msgtxt=bigbuf+fp+2;

			fp=parse_msg(fd, bigbuf, "Reply-To: ");
			reply_add[0]=0;
			if( fp>0 )
			{
			  reply_field=bigbuf+fp;
			  strip_nl(reply_field);
			  reply_field+=10;
			  nstrcpy(reply_add, reply_field, 80);
			}

			fp=parse_msg(fd, bigbuf, "Subject: ");
			subject_field=bigbuf+fp;
			strip_nl(subject_field);
			subject_field+=9;

			fp=parse_msg(fd, bigbuf, "From: ");
			from_field=bigbuf+fp;
			strip_nl(from_field);
			from_field+=6;
			nstrcpy(from_line, from_field, 80);
			if( reply_add[0]==0 )
			  nstrcpy(reply_add, from_line, 80);

			if( !send_post_by_email )
			{
			  fp=parse_msg(fd, bigbuf, "Path: ");
			  fp+=6;  /*skip "Path: "*/
			  path_field=bigbuf+fp;
			  if( !strncmp(path_field, "%SENDMAIL%", 10) )
			    send_post_by_email=TRUE;
			}

			ptr=strtok(from_line, "(<[");
			if( ptr !=NULL )
			{
				ptr=strtok(NULL, ")>]");
				if( ptr!=NULL )
					nstrcpy(from_name, ptr, 80);
				else
					nstrcpy(from_name, from_field, 80);
			}
			else
				nstrcpy(from_name, from_field, 80);

			strip_nl(from_name);

			continue_reply=TRUE;
			if( system_operator )
			  if( !strcmp(REQUEST_AREA, current_group) )
			    if( strncmp(subject_field, "Re: ", 4) )
			    /*ignore "RE: " post*/
			    {
			      sprintf(line_buf, "%s(Y/N)", LIST_MODE_8);
			      if( yes_no(fd, line_buf)=='y' )
			      {
				continue_reply=FALSE;
				change_user_level(fd, get_user_id(from_name));
				display_msg(fd, KILL_THIS_MSG);
				if( delete_message(fd, recno-1,FALSE) )
				{
				  if( read_dir<=0 )	/*deleted*/
				    recno--;
				}
			      }
			    }

			if( continue_reply )
			{
			  if( !send_post_by_email )
			    enter_mail(fd, 1, from_name, subject_field, msgtxt);
			  else
			  {
			    /*sometimes From: Full Name <Email@address>*/
			    if( email_check(from_name) && (!email_check(reply_add)) )
			      nstrcpy(reply_add, from_name, 80);
			    reply_email(fd, subject_field, reply_add, msgtxt);
			  }
			}

			recno--;	/*stay at the same position*/
			continue;

		}/*end if(r)*/

		/*----------------------------------------------------*/

		/************************/
		/*subject pattern search*/
		/************************/

		if( answer[0]=='s' || answer[0]=='S' )
		{

			if( strlen(searched_string)<=0 )
			  strcpy(ebuf, SEARCH_PATTERN);
			else
			  sprintf(ebuf, "%s[%s] ", SEARCH_PATTERN, searched_string);

			asking(fd, ebuf, answer, 60);

			if( answer[0]==0 || answer[0]==13 || answer[0]==10 )
			{
				if( strlen(searched_string)<=0 )
				{
					/* null search pattern */
					recno--;
					continue;
				}
			}
			else
			{
			  for(i=0; i<strlen(answer); i++)
			    if( answer[i]==0 || answer[i]==13 || answer[i]==10 )
			    {
				answer[i]=0;
				break;
			    }

			  strcpy(searched_string, answer);
			}

			read_dir=1;		/*only forward search*/
			search_topic=TRUE;
			full_match=FALSE;	/*partial match mode*/
			last_stop=recno-1;

			if(debug_mode) printf("(readpost.c)search pattern->%s\n", searched_string);
			display_msg(fd, WAIT_PLEASE);
			continue;
		}

		/*----------------------------------------------------*/

		if( answer[0]=='+' || answer[0]=='-' )
		{
			sprintf(crlf, "%c%c", 13, 10);

			fp=parse_msg(fd, bigbuf, "Subject: ");
			subject_field=bigbuf+fp+9;
			strip_nl(subject_field);

			if( strncmp(subject_field, "Re: ", 4) )
			{
				nstrcpy(searched_topic, subject_field, 80);
			}
			else
			{
				nstrcpy(searched_topic, subject_field+4, 80);
			}

			/*-----------------------------------------------*/
			search_topic=TRUE;
			full_match=TRUE;	/*full match mode*/
			last_stop=recno-1;
			/*-----------------------------------------------*/

			if( answer[0]=='+' )
				read_dir = 1;
			else
			{
				read_dir = -1;
				recno -= 2;
			}


			if(debug_mode) printf("(readpost.c)search topic->%s\n", searched_topic);
			display_msg(fd, WAIT_PLEASE);
			continue;
		}

		/*----------------------------------------------------*/

		ret=atoi(answer);
		if( ret<=0 || ret>(total_msg+1) )
		{
			display_msg(fd, MSG_NO_ERR);
			suspend(fd);
			break;
		}

		if( ret>0 )
		{
			if(debug_mode) printf("(readpost.c)request %dth post\n", recno);

			if(ret>=recno)
				read_dir = 1;
			else
				read_dir = -1;

			recno=ret-1;
		}
	}/*end while*/

	/******************************************************/
	/*make last_read more correct if last post was deleted*/
	/*----------------------------------------------------*/
	total_msg=file_length(mfrec)/sizeof(struct msgrec);
	recno=get_lastread(fd);
	while( recno<total_msg )
	{
		lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
		read(mfrec, &mrec, sizeof(struct msgrec) );
		if( mrec.delete_mark=='D' )
		{
			recno++;
			set_lastread(fd, recno);
			continue;
		}
		else
			break;
	}
	/******************************************************/

	close(mfrec);
	close(mffd);
}
/*end of read_mail*/



/*
	read_previous_mail --- as the name
*/
read_previous_mail(fd)
	int fd;
{
	int lr;

	if(debug_mode) printf("(readpost.c)read_previous_mail\n");

	lr=get_lastread(fd);

	lr--;

	if( lr<0 ) lr=0;

	set_lastread(fd, lr);

	read_mail(fd, -1, -1);
}
/*end of read_previous_mail*/



/*
	set cream mark
	delete_mark='C'
*/
set_cream_mark(fd, recno)
	int fd;
	int recno;	/*recno of the post to be set cream*/
{
  char answer[8];
  char put_mark;
  char filename[256];
  char ebuf[128];
  int mfrec;
  struct msgrec mrec;
  int total_msg;

  if( !strcmp(current_group, "mbox") )
    return;

  asking(fd, SET_CREAM_MARK, answer, 2);

  switch( tolower(answer[0]) )
  {
  case 'c':
	show_cream_post(fd);
	return; 		/*<-------- RETURN*/

  case 's':
	put_mark='C';
	break;

  case 'u':
	put_mark=' ';
	break;

  default:
	return; 		/*<-------- RETURN*/

  }/*end switch*/

  if(debug_mode) printf("(readpost.c)set_cream_mark %c, %d\n", put_mark, recno);

  /*------------------------------------------------------------*/
  sprintf(filename, "%s/%s/records", MAIL_PATH, current_group);
  mfrec=open(filename, O_RDWR|O_CREAT, S_IWUSR | S_IRUSR);
  /*------------------------------------------------------------*/

  if( mfrec<0 )
  {
	off_putmp();
	sprintf(ebuf, "readpost.c: %s", SYSTEM_ERROR);
	do_log(9, "SYSTEM ERROR in set_cream_mark %s", current_group);
	send_mpf(fd, ebuf, strlen(ebuf), REJECT);
	exit(12);
  }
  /*------------------------------------------------------------*/

  lseek(mfrec, 0 ,SEEK_END);
  total_msg=file_length(mfrec)/sizeof(struct msgrec);

  if( recno<0 || recno>=total_msg)
  {
	display_msg(fd, MSG_NO_ERR);
	suspend(fd);
	return(FALSE);
  }

  /*------------------------------------------------------------*/

  lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
  read(mfrec, &mrec, sizeof(struct msgrec) );

  /*------------------------------------------------------------*/
  /*set cream mark*/
  flock(mfrec, LOCK_EX);
  mrec.delete_mark=put_mark;
  lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
  write(mfrec, &mrec, sizeof(struct msgrec) );
  flock(mfrec, LOCK_UN);

  /*------------------------------------------------------------*/
  close(mfrec);

  do_log(5,"%s set_cream_mark '%c', %s record #%d", user_name, put_mark, current_group, recno);

}
/*end of set_cream_mark*/



/*
	show posts with CREAM mark
*/
show_cream_post(fd)
	int fd;
{
	char filename[256];
	char ebuf[256];
	int mffd;
	int mfrec;
	struct msgrec mrec;
	char *p;
	int total_msg=0;
	int recno=0;
	int ret;
	int i, cnt, cr_cnt, scr_size;

	if(debug_mode) printf("(readpost.c)show_cream_post\n");

	/*------------------------------------------------------------*/
	if( strcmp(current_group, "mbox") )
	  sprintf(filename, "%s/%s/messages", MAIL_PATH, current_group);
	else
	  return;

	mffd=open(filename, O_RDONLY|O_CREAT, S_IWUSR | S_IRUSR);
	/*------------------------------------------------------------*/

	/*------------------------------------------------------------*/
	if( strcmp(current_group, "mbox") )
	  sprintf(filename, "%s/%s/records", MAIL_PATH, current_group);
	else
	  return;

	mfrec=open(filename, O_RDONLY|O_CREAT, S_IWUSR | S_IRUSR);
	/*------------------------------------------------------------*/

	if( mffd<0 || mfrec<0 )
	{
		off_putmp();
		do_log(9, "SYSTEM ERROR show_cream_post %s", current_group);
		sprintf(ebuf, "readpost.c: %s", SYSTEM_ERROR);
		send_mpf(fd, ebuf, strlen(ebuf), REJECT);
		exit(12);
	}

	scr_size=get_scrsize(fd);
	if(scr_size>33) scr_size=0;  /*avoid full-buffered client (win client)*/
	recno=0;
	while(1)
	{
		lseek(mfrec, 0 ,SEEK_END);
		total_msg=file_length(mfrec)/sizeof(struct msgrec);

		if( (recno<0) || (recno>=total_msg) )
		  break;

		/*----------------------------------------------------*/

		lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
		read(mfrec, &mrec, sizeof(struct msgrec) );

		/*----------------------------------------------------*/

		/*check CREAM mark*/
		if( mrec.delete_mark!='C' )
		{
			recno++;
			continue;
		}

		/*----------------------------------------------------*/

		recno++;
		p=bigbuf;

		sprintf(p, "Msgno: %d%c%c", recno, 13, 10);
		ret=strlen(p);
		p+=ret;

		lseek(mffd, mrec.offset, SEEK_SET);
		ret=read(mffd, p, mrec.length);
		p[ret]=0;

		i=parse_msg(fd, p, "MSG");
		if(i<0) continue;

		/*move message body (strip msg head info) and count '/n'*/
		cr_cnt=0;
		for(cnt=i; cnt<=ret; cnt++)
		{
		  if( p[cnt]==0xa )
		    cr_cnt++;

		  p[cnt-i]=p[cnt];
		}

		/*----------------------------------------------------*/

		/*pad '\n' to a screen to let user capture*/
		while( (cr_cnt<=(scr_size+1)) && (scr_size>0) )
		{
		  strcat(bigbuf, "\n\r");
		  cr_cnt++;
		}

		display_msg(fd, "{#c#}");
		display_msg(fd, bigbuf);
		display_msg(fd, "\n\r");

		if( yes_no(fd, IF_CONTINUE)!='y' )
		{
			close(mfrec);
			close(mffd);
			return; 	/*<-----------RETURN*/
		}

	}/*end while*/

	close(mfrec);
	close(mffd);

	display_msg(fd, NO_MORE_CREAM);
	suspend(fd);
}
/*end of show_cream_post*/
