/**************************************************************************
 * psocket.c --- general network subroutie				  *
 *		 by Samson Chen, Nov 28, 1993				  *
 **************************************************************************/

#include "pbbs.h"
#include "global.h"

static char rcsid[]="$Id: psocket.c,v 1.7 1995/10/14 06:34:00 pbbs Exp pbbs $";

/*****************************
	local structure define
*/
struct	mpf_head_s {
		char	prot;
		char	length[8];
	} mpf_head;

/*
	local var
*/
int real_len;	/*used for HUGE packet prevention*/

/****************************************
	sending via Message Packet Format
*/
send_mpf(fd, buffer, buf_len, protocol)
	int fd;		/*socket file descriptor*/
	char *buffer;	/*transmit data buffer*/
	unsigned long buf_len;	/*buffer length*/
	char protocol;	/*mpf protocol code*/
/*
	return: 0 = ok
		-1 = error occurred	(standard)
*/
{
	char	iac_buff=IAC;
	int	i ;
	int	ret;

	mpf_head.prot=protocol;
	sprintf(mpf_head.length, "%ld", buf_len);

	ret=write(fd, &iac_buff, 1);			/*send IAC*/
		if( ret<0 ) abnormal_disconnect(fd);
	ret=write(fd, (char*) &(mpf_head.prot), 1 );	/*send protocol code*/
		if( ret<0 ) abnormal_disconnect(fd);
	ret=write(fd, (char*) mpf_head.length, 8 );	/*send packet length*/
		if( ret<0 ) abnormal_disconnect(fd);

	if( buf_len>0 )
	{
		ret=write(fd, buffer, buf_len);	/*send buffer*/
		if( ret<0 ) abnormal_disconnect(fd);
	}

	return(0);
}
/*end of send_mpf*/


/**********************************
	read fix length from stream
*/
fix_read(fd, fix_len, buffer)
	int fd;		/*socket file descriptor*/
	unsigned long fix_len;	/*packet length*/
	char *buffer;	/*stored buffer*/
/*
	return: standard
*/
{
	char *pointer=buffer;
	unsigned long pcount=0;
	unsigned long n;

	while( pcount < fix_len )
	{
		n = read(fd, pointer, (fix_len-pcount) );
			if( n<=0 ) abnormal_disconnect(fd);
		pcount += n;

		if( pcount < MAX_BUF-1024 )
		{
			pointer = buffer + pcount;
		}
		else
			real_len=MAX_BUF-1024;
	}

	return(0);
}
/*end of fix_read*/


/*************************************
	read via Message Packet Format
*/
read_mpf(fd, buffer, buf_len, protocol, nowait)
	int fd;		/*socket file descriptor*/
	char *buffer;	/*stored buffer*/
	unsigned long *buf_len;	/*length of stored buffer*/
	char *protocol;	/*fetched protocol code*/
	int nowait;	/*block read_mpf or not*/
/*
	return: -1 = error occurred
		-2 = non-MPF format data received, maybe garbage(in nowait mode)
		 0 = no data-in (in nowait mode)
		 1 = OK
	note: nowait mode will not reset the alarm timer, you must reset
	      it before call read_mpf
*/
{
	char iac_buff;

	fd_set	rset;
	struct timeval	timeout;
	int maxfd, n;
	int i;

	real_len=0;

	if( nowait )	/*nowait will not block function*/
	{
		/*set mutiplex I/O check bit*/
		maxfd=fd + 1;
		FD_ZERO(&rset);
		FD_SET(fd, &rset);
		timeout.tv_sec=0;
		timeout.tv_usec=1;

		if( (n=select(maxfd, &rset, NULL, NULL, &timeout)) <0)
			reject(fd, 12);

		if( FD_ISSET(fd, &rset) )
		{
			n = read(fd, &iac_buff, 1);
				if( n==0 ) abnormal_disconnect(fd);
			if( iac_buff != IAC )
			{
				/*
				Non-MPF data received.
				Maybe garbage code or non-secure data
				request.
				*/

				i=0;

				do
				{
				  buffer[i++]=iac_buff;
				  n = read(fd, &iac_buff, 1);
					if( n==0 ) abnormal_disconnect(fd);
				} while(iac_buff!=0x0a);

				buffer[i]=0;

				for(i=0; i<strlen(buffer); i++)
				  if( buffer[i]==0x0d || buffer[i]==0x0a )
				  {
					buffer[i]=0;
					break;
				  }

				*buf_len=strlen(buffer);

				return(-2);
			}
		}
		else
			return(0);	/*no data-in*/	

		/*continue at fix_read the head*/
	}
	else
	{
		reset_alarm(idling);

		do
		{ 
			n=read(fd, &iac_buff, 1); 
			if( n==0 ) abnormal_disconnect(fd);
		} while( iac_buff != IAC );
			/*skip until IAC appearred*/
	}

	fix_read(fd, 1, (char*) &(mpf_head.prot));
	fix_read(fd, 8, (char*) mpf_head.length);
		/*get packet head*/

	*protocol = mpf_head.prot;
	sscanf(mpf_head.length, "%ld", buf_len);

	if( *buf_len > 0 )	/*get the packet body if exist*/
		fix_read(fd, *buf_len, buffer);

	if( real_len!=0 )	/*huge packet received (real_len will be*/
	{			/*modified at fix_len() and buffer will */
		*buf_len=real_len;	/*be cut			*/
		buffer[real_len]=0;
		do_log(8, "%s send a huge packet", client_site);
	}

	return(1);	/*OK*/
}
/*end of read_mpf*/
	


/*
	send data from file handle directly
	no macro processing
	if len < real_len, send only len
	if len > real_len, NULL will be added
*/
fd_direct_send_mpf(fd, handle, len, protocol)
	int fd;			/*network fd*/
	int handle;		/*file handle to be sent*/
	unsigned long len;	/*assume length of handle*/
	char protocol;		/*sending protocol*/
/*
	return: 0 = ok
		-1 = error occurred	(standard)
*/
{
	char	iac_buff=IAC;
	char	null=0;
	int	i ;
	int	ret;
	unsigned long pcount=0;
	int 	tail;
	char block[4096];

	mpf_head.prot=protocol;
	sprintf(mpf_head.length, "%ld", len);

	ret=write(fd, &iac_buff, 1);			/*send IAC*/
		if( ret<0 ) abnormal_disconnect(fd);
	ret=write(fd, (char*) &(mpf_head.prot), 1 );	/*send protocol code*/
		if( ret<0 ) abnormal_disconnect(fd);
	ret=write(fd, (char*) mpf_head.length, 8 );	/*send packet length*/
		if( ret<0 ) abnormal_disconnect(fd);

	if( len>0 )
	{
	  while(pcount<len)
	  {
	    tail=len-pcount;
	    if( tail>4096 ) tail=4096;
	    ret=read(handle, block, tail);

	    if( ret==0 )
	      break;

	    if( ret<0 )
	    {
	      do_log(8, "file handle size (len) error in fd_direct_send_mpf");
	      break;
	    }

	    pcount+=ret;

	    ret=write(fd, block, ret);
	    if( ret<0 ) abnormal_disconnect(fd);
	  }
	}/*end if*/

	if( pcount<len )
	{
	  /*handle length prediction error, put NULL pads*/
	  for( ;pcount<len; pcount++)
	    write(fd, &null, 1);
	}

	return(0);

}
/*end of fd_direct_send_mpf*/



/*
	for readpost.c module.
	readpost prefetch msg head and parsing it
	send left data from msg file fd directly
	mfd should be lseek to the starting position before calling
*/
post_direct_send_mpf(fd, mfd, head, orig_head_len, post_len)
int fd;			/*network fd*/
int mfd;		/*msg fd(has been lseeked)*/
char *head;		/*parsed msg head*/
int orig_head_len;	/*original head length*/
long post_len;		/*original total post length*/
/*
	return: 0 = ok
		-1 = error occurred	(standard)
*/
{
	char	iac_buff=IAC;
	char	null=0;
	int	new_head_len;
	long	left_len;
	int	i ;
	int	ret;
	unsigned long pcount=0;
	int 	tail;
	char block[4096];

	new_head_len=strlen(head);

	mpf_head.prot=POST;
	sprintf(mpf_head.length, "%ld", post_len-orig_head_len+new_head_len);

	ret=write(fd, &iac_buff, 1);			/*send IAC*/
		if( ret<0 ) abnormal_disconnect(fd);
	ret=write(fd, (char*) &(mpf_head.prot), 1 );	/*send protocol code*/
		if( ret<0 ) abnormal_disconnect(fd);
	ret=write(fd, (char*) mpf_head.length, 8 );	/*send packet length*/
		if( ret<0 ) abnormal_disconnect(fd);

	ret=write(fd, head, new_head_len);

	lseek(mfd, orig_head_len, SEEK_CUR);
	left_len=post_len-orig_head_len;

	if( left_len>0 )
	{
	  while(pcount<left_len)
	  {
	    tail=left_len-pcount;
	    if( tail>4096 ) tail=4096;
	    ret=read(mfd, block, tail);

	    if( ret==0 )
	      break;

	    if( ret<0 )
	    {
	      do_log(8, "file handle size (left_len) error in post_direct_send_mpf");
	      break;
	    }

	    pcount+=ret;

	    ret=write(fd, block, ret);
	    if( ret<0 ) abnormal_disconnect(fd);
	  }
	}/*end if*/

	if( pcount<left_len )
	{
	  /*handle length prediction error, put NULL pads*/
	  for( ;pcount<left_len; pcount++)
	    write(fd, &null, 1);
	}

	return(0);


}
/*end of post_direct_send_mpf*/
