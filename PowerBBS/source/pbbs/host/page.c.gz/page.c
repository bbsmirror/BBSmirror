/*************************************************************************
 * page.c --- write message to on-line user				 *
 *	      by Samson Chen, May 14, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "dbf.h"
#include "global.h"



/*
	write_user --- send message to on-line user
*/
write_user(fd, wmode)
	int fd;
	int wmode;	/* 0: normal write mode, 1: kick mode */
{
	char answer[80];
	int sig_rec;
	struct udb urec;
	struct putmp purec;
	int mbox_uid;
	char line[128];
	char page_file[128];
	int msg;
	char crlf[3];
	char info[25];

	if( wmode!=1 )
	  asking(fd, WRITE_WHO, answer, 20);
	else
	  asking(fd, KICK_WHO, answer, 20);
	process_user_name(answer);

	strip_nl(answer);
	if(answer[0]==0 || answer[0]==10 || answer[0]==13)
		return;

	sprintf(crlf, "%c%c", 13, 10);

        do_log(1, "%s send message to %s", user_name, answer);

        sprintf(line, "%s", answer);
        update_act(14,line);   

	for(sig_rec=0; sig_rec<(flength(ON_LINE_USER)/sizeof(struct putmp)); sig_rec++)
	{
		get_putmp(&purec, sig_rec);

		if( purec.active )
		{
		  get_user_data(&urec, purec.uid);

		  if( !strcmp(urec.bbs_name, answer) )
		  {
			mbox_uid=purec.uid;
			if( ((urec.user_set[0] & 1)==1) && (!system_operator) )
			{
				sprintf(line, "%s%s", urec.bbs_name, USER_OFF_PAGE);
				display_msg(fd, line);
				suspend(fd);
				return;
			}

			/*edit message*/
			sprintf(page_file, "%s/talk.%d", TALK_BUFFER, user_uid);
			msg=open(page_file, O_WRONLY | O_CREAT | O_TRUNC, S_IWUSR | S_IRUSR);

			if(debug_mode) printf("(page.c)creat signal message %s\n", page_file);

			sprintf(line, "\n%s%s", user_name, WRITE_YOU);
			write(msg, line, strlen(line));

			sprintf(answer, "%c%c%c", 7, 13, 10);
			write(msg, answer, 3);	/*a BEEP*/

			/*get messages*/
			if( wmode!=1 )
			  display_msg(fd, TALK_WHAT);
			else
			  display_msg(fd, WHY_KICK);
			do
			{
			  asking(fd, ">", answer, 80);
			  strip_nl(answer);
			  if( strlen(answer)==1 && answer[0]=='.' )
				break;
			  write(msg, answer, strlen(answer) );
			  write(msg, crlf, strlen(crlf));
			} while(1);
			close(msg);

			if( yes_no(fd, CONFIRM_MSG)!='y' )
				return;

			/*re-get putmp status, maybe user change status*/
			/*	when typing messages		       */
			get_putmp(&purec, sig_rec);

			if( !purec.active )
			{
				/*user logout at that time*/
				display_msg(fd, NOT_ON_LINE_NOW);
				if( wmode!=1 )
				{
				  display_msg(fd, WRITE_TO_MBOX);
				  page_msg_to_mbox(fd, mbox_uid, page_file);
				}
				suspend(fd);
			}
			else
			{
			  switch(purec.act_stat)
			  {
			  case 3:
			  case 7:
			  case 8:
			  case 9:
			  case 10:
			  case 11:
			  case 12:
				descript_stat(info, 25, purec.act_stat, purec.act_info);
				sprintf(line, "%s%s%s\n", urec.bbs_name, CANNOT_PAGE, info);
				display_msg(fd, line);
				if( wmode!=1 )
				{
				  display_msg(fd, WRITE_TO_MBOX);
				  page_msg_to_mbox(fd, mbox_uid, page_file);
				}
				suspend(fd);
				break;
			  default:
				purec.page_mode=0;
				purec.page_uid=user_uid;
				set_putmp(&purec, sig_rec);
				kill(purec.pid, SIGUSR1);
				break;

			  }/*end switch*/

			  if( wmode==1 && system_operator )  /*kick mode*/
			  {
			    do_log(7, "%s kick out %s", user_name, urec.bbs_name);
			    kill(purec.pid, SIGTERM);
			    sleep(1);
			    disable_putmp(sig_rec);
			  }
			}/*end if-else(!purec.active)*/

			return;

		  }/*end if(bbs_name)*/
		}/*end if(active)*/
	}/*end for*/

	display_msg(fd, NOT_ON_LINE_NOW);
	suspend(fd);
}
/*end of write_user*/



/*
	disable a record of putmp
*/
disable_putmp(rec)
int rec;
{
	int utf;
	struct putmp purec;
	char talk_file[128];

	if( debug_mode ) printf("(page.c)disable_putmp %d\n", rec);

	if( rec<0 ) return;

	utf=open(ON_LINE_USER, O_RDWR | O_CREAT, S_IWUSR | S_IRUSR);

	flock(utf, LOCK_EX);

	lseek(utf, rec*sizeof(struct putmp), SEEK_SET);
	read(utf, &purec, sizeof(struct putmp));

	/*check if this record already be disabled*/
	if( purec.active )
	{
	  if( debug_mode ) printf("(page.c)redisable putmp %d", rec);

	  purec.active=FALSE;
	  lseek(utf, rec*sizeof(struct putmp), SEEK_SET);
	  write(utf, &purec, sizeof(struct putmp) );

	  /*remove talk file*/
	  sprintf(talk_file, "%s/talk.%d", TALK_BUFFER, purec.uid);
	  if( file_exist(talk_file) )
		unlink(talk_file);
	}

	flock(utf, LOCK_UN);

	close(utf);
}
/*end of disable_putmp*/



/*
	switch_page --- switch page mode

	use bit-0 of user_set[0], it is a mask bit, that is,
	0: means page ON
	1: menas page OFF
*/
switch_page(fd)
	int fd;
{
	struct udb urec;

	get_user_data(&urec, user_uid);

	if( (urec.user_set[0] & 1)==0 )
	{
		/* on -> off */
		display_msg(fd, PAGE_OFF);
		suspend(fd);
	}
	else
	{
		/* off -> on */
		display_msg(fd, PAGE_ON);
		suspend(fd);
	}

	urec.user_set[0] ^= 1;

	set_user_data(&urec, user_uid);
}
/*end of switch_page*/



/*
	write page message to mbox
*/
page_msg_to_mbox(fd, mbox_to_uid, page_file)
int fd;
int mbox_to_uid;
char *page_file;
{
  char mfile[80], rfile[80];
  int test, msgfile, recfile;
  int n;
  struct msgrec mr;
  char buf[256];
  char from_name[20];
  char unique_id[20];
  char message_id[128];
  char timebuf[35];
  FILE *page_txt;
  char line[256];

  /*----------------------------------------------------------------*/
  if( !file_exist(page_file) )
    return;

  strcpy(from_name, user_name);

  for(n=0; n<strlen(from_name); n++)
	if( from_name[n]==' ' )
	{
		from_name[n]='_';
		break;
	}

  /*----------------------------------------------------------------*/
  /*put it to mbox*/
  sprintf(mfile, "%s/mbox/%d.messages", MAIL_PATH, mbox_to_uid);
  sprintf(rfile, "%s/mbox/%d.records", MAIL_PATH, mbox_to_uid);

  /*----------------------------------------------------------------*/
  /*test files*/
  if( !file_exist(mfile) )
  {
	test=open( mfile, O_WRONLY | O_APPEND | O_CREAT, S_IWUSR | S_IRUSR);
	if( test<0 )
	{
		do_log(9, "%s open error!?", mfile);
		return;
	}
	else
		close(test);
  }

  if( !file_exist(rfile) )
  {
	test=open( rfile, O_WRONLY | O_APPEND | O_CREAT, S_IWUSR | S_IRUSR);
	if( test<0 )
	{
		do_log(9, "%s open error!?", rfile);
		return;
	}
	else
		close(test);
  }

  msgfile=open(mfile, O_WRONLY | O_APPEND);
  if( msgfile<0 )
  {
	do_log(9, "%s open error!?", mfile);
	return;
  }

  recfile=open(rfile, O_WRONLY | O_APPEND);
  if( recfile<0 )
  {
	do_log(9, "%s open error!?", rfile);
	return;
  }

  /*----------------------------------------------------------------*/
  /*put it*/
  flock(msgfile, LOCK_EX);	/*exclusive lock*/
  flock(recfile, LOCK_EX);	/*exclusive lock*/

  lseek(msgfile, 0, SEEK_END);
  mr.offset=file_length(msgfile);
  nstrcpy(mr.subject, "Paging Message", 60);
  mr.packed=' ';
  mr.delete_mark=' ';

  memset(buf, 0, 255);
  sprintf(buf, "Path: %s%c%c", STATION_ID, 13, 10);
	write(msgfile, buf, strlen(buf) );

  memset(buf, 0, 255);
  sprintf(buf, "From: %s.pbbs@%s (%s)%c%c", from_name, NNRP_DOMAIN,  user_name, 13, 10);
	write(msgfile, buf, strlen(buf) );

  memset(buf, 0, 255);
  sprintf(buf, "Subject: Paging Message%c%c", 13, 10);
	write(msgfile, buf, strlen(buf) );

  memset(buf, 0, 255);
  memset(message_id, 0, 128);
  memset(unique_id, 0, 20);
  get_mid(unique_id);
  sprintf(message_id, "<%s@%s>", unique_id, NNRP_DOMAIN);
  sprintf(buf, "Message-ID: %s%c%c", message_id, 13, 10);
	write(msgfile, buf, strlen(buf) );

  rfcgmtime(timebuf);
  memset(buf, 0, 255);
  sprintf(buf, "Date: %s GMT%c%c", timebuf, 13, 10);
	write(msgfile, buf, strlen(buf) );

  memset(buf, 0, 255);
  sprintf(buf, "Organization: %s%c%c", SORGANIZATION, 13, 10);
	write(msgfile, buf, strlen(buf) );

  if( email_check(user_email) )
  {
	memset(buf, 0, 255);
	sprintf(buf, "Reply-To: %s%c%c", user_email, 13, 10);
		write(msgfile, buf, strlen(buf) );
  }

  memset(buf, 0, 255);
  sprintf(buf, "%c%c", 13, 10);
  write(msgfile, buf, 2);

  page_txt=fopen(page_file, "r");
  if( page_txt != (FILE*)NULL )
  {
    while( fgets(line, 127, page_txt) )
    {
      strip_nl(line);
      sprintf(buf, "%s%c%c", line, 13, 10);
      write(msgfile, buf, strlen(buf) );
    }

    fclose(page_txt);
  }

  lseek(msgfile, 0, SEEK_END);
  mr.length=file_length(msgfile)-mr.offset;

  write(recfile, &mr, sizeof(mr) );

  flock(msgfile, LOCK_UN);	/*unlock*/
  flock(recfile, LOCK_UN);	/*unlock*/

  do_log(6, "%s send page message to uid %d, mid is %s", user_name, mbox_to_uid, message_id);

  close(msgfile);
  close(recfile);

  /*----------------------------------------------------------------*/
  /*set mbox quote*/
  set_mail_quote(mbox_to_uid, 'Y');

}
/*end of page_msg_to_mbox*/
