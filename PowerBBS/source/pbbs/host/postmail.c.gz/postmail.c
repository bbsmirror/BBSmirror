/*************************************************************************
 * postmail.c --- making posts						 *
 *	      by Samson Chen, Apr 7, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"
#include "dbf.h"

static char rcsid[]="$Id: postmail.c,v 1.34 1995/11/01 14:56:39 pbbs Exp pbbs $";

char bigbuf[MAX_BUF];
char headbuf[1024];
char buf[255];




/*
	enter_mail --- do posing
*/
enter_mail(fd, emode, o_from_user, o_subject, quotation)
	int fd;
	char emode;	/*0 for entermail, 1 for reply mail, 2 for file post*/
	char *o_from_user;	/*used for emode 1*/
	char *o_subject;	/*used for emode 1*/
	char *quotation;	/*used for emode 1*/
{
	char answer[80];
	char post_subject[80];
	char from_name[20];
	char unique_id[20];
	char message_id[128];
	char timebuf[35];
	int ret;
	int n, m, qc;
	int rlen;
	char protocol;
	int test;
	char mfile[80], rfile[80];
	int msgfile, recfile;
	char ebuf[128];
	struct msgrec mr;
	char origin_filename[80];
	FILE *origin_file;
	char origin_line[80];
	char *p;
	char crlf[3];
	char ck1[5], ck2[5];
	unsigned int mbox_to_uid;	/*mbox recevier's uid*/
	struct udb urec;
	char find_d, od=0xd;
	long outcnt;

	if(debug_mode) printf("(postmail.c)enter_mail emode %d\n", emode);

	update_act(7, group_areaname);

	sprintf(crlf, "%c%c", 13, 10);

	/*********************/
	/*check post security*/
	/*********************/
	if( (user_level < mini_post_level) && !group_moderator && !system_operator)
	{
		display_msg(fd, crlf);

		display_msg(fd, POST_SECURITY);
		sprintf(buf, "%s%d\n", MINIMUM_POST_LEVEL, mini_post_level);
		display_msg(fd, buf);

		suspend(fd);

		return;
	}
	/*********************/

	if( emode==0 || emode==2 )
	{
		if( !strcmp(current_group, "mbox") )
		{
			memset(answer, 0, 80);
			asking(fd, MBOX_TO, answer, 20);
			for(n=0; n<20; n++)
			  if( answer[n]==13 || answer[n]==10 || answer[n]==0 )
			  {
				answer[n]=0;
				break;
			  }

			/*processing user's input*/
			process_user_name(answer);

			/*-------------------------------------------*/
			if(debug_mode)printf("(postmail.c)search %s\n", answer);
			mbox_to_uid=get_user_id(answer);
			if(mbox_to_uid==0)	/*rcpt user not found*/
			{
				display_msg(fd, NO_SUCH_USER);
				suspend(fd);

				return;
			}
		}/*end if(mbox)*/


		/*************/
		/*ask subject*/
		/*************/
		sprintf(buf, "%s%s\n", CURRENT_POSTGROUP, current_group);
		display_msg(fd, buf);
		memset(answer, 0, 80);
		asking(fd, ASK_POST_SUBJECT, answer, 80);
		alltrim(answer);
		if( strlen(answer)==0 ) return;
		nstrcpy(post_subject, answer, 80);

		if( !strncmp(post_subject, "cmsg ", 4) )
		{
		  /*control message is forbidden*/
		  display_msg(fd, NO_CONTROL_MSG);
		  display_msg(fd, "\n");
		  suspend(fd);
		  return;
		}

		if( emode != 2 )
			send_mpf(fd, NULL, 0, MAKEPOST);
		else
			send_mpf(fd, NULL, 0, FILEPOST);

	}
	else	/*emode==1*/
	{
		if( !strcmp(current_group, "mbox") )
		{
			/*****************/
			/*check from user*/
			/*****************/
			if(debug_mode)printf("(postmail.c)search %s\n", o_from_user);
			mbox_to_uid=get_user_id(o_from_user);
			if(mbox_to_uid==0)	/*rcpt user not found*/
			{
			  display_msg(fd, NO_SUCH_USER);
			  suspend(fd);
			  return;
			}
		}
		else
		{
		  if( user_level>=USE_EMAIL_LEVEL )
		    display_msg(fd, PLZ_JUST_TO_AUTHOR);
		}

		/*************/
		/*ask subject*/
		/*************/
		memset(answer, 0, 80);
		memset(buf, 0, 255);

		if( yes_no(fd, USE_SAME_SUBJECT)!='y' )
		{
			sprintf(buf, "%s ", ASK_POST_SUBJECT);
			asking(fd, buf, answer, 80);
			alltrim(answer);
			if( strlen(answer)==0 ) return;
			nstrcpy(post_subject, answer, 80);
		}
		else
		{
			if( strncmp(o_subject, "Re: ", 4) )
			{
			  strcpy(buf, "Re: ");
			  nstrcpy(buf+4, o_subject, 80);
			  nstrcpy(post_subject, buf, 80);
			}
			else
			{
			  nstrcpy(post_subject, o_subject, 80);
			}
		}

		/*ask quotation*/
		if( yes_no(fd, USE_QUOTATION)=='y' )
		{
			/*add quotation sign*/
			p=quotation;
			n=strlen(p);

			/*add first quotation mark*/
			for(m=n; m>=0; m--)
				p[m+2]=p[m];
			p[0]='>';
			p[1]=' ';
			p[n+2]=0;

			qc=1;	/*quotation count*/

			while(1)
			{
				p++;
				if(*p==0)
					break ;

				if(*p==10)
				{
					p++;
					if(*p==0)
						break ;

					n=strlen(p);

					/*compress blank lines*/
					if(*p==13 || *p==10)
					{
					  ret=0;
					  while( p[ret]==13 || p[ret]==10 )
						ret++;
					  for(m=0; m<(n-ret); m++)
						p[m]=p[m+ret];
					  p[n-ret]=0;
					  n=strlen(p);
					}

					/*remove too old quoats (> > > )*/
					do
					{
					  ret=0;
					  if( trash_quotes(p, &ret) )
					  {
					    /*find LF*/
					    while( p[ret]!=13 && p[ret]!=10 && p[ret]!=0 )
						ret++;
					    /*remove whole line*/
					    while( p[ret]==13 || p[ret]==10 )
						ret++;
					    for(m=0; m<(n-ret); m++)
						p[m]=p[m+ret];
					    p[n-ret]=0;
					    n=strlen(p);
					    continue;
					  }
					  else
					    break;
					}
					while(TRUE);

					/*check singatur line "--\n" */
					if( n>=3 )
					{
					  if( p[0]=='-' && p[1]=='-' && (p[2]==13 || p[2]==10) )
					  /*sig lines found, strip it*/
					  {
						p[0]=0;
						break;
					  }
					}

					/*add other quotation marks*/
					for(m=n; m>=0; m--)
						p[m+2]=p[m];
					p[0]='>';
					p[1]=' ';
					p[n+2]=0;

					qc++;
				}

				if( qc > MAX_QUOTE )
				{
					p[0]=0;
					break;
				}
			}

			strcat(quotation, crlf);

			send_mpf(fd, quotation, strlen(quotation), MAKEPOST);
		}
		else
			send_mpf(fd, NULL, 0, MAKEPOST);
	}

	idling=IDLE_TIME * POST_FACTOR; /*extent editing time*/
	read_mpf(fd, bigbuf, &rlen, &protocol, FALSE);
	idling=IDLE_TIME;		/*restore idling time*/

	if( protocol==STOPPOST )
	{
		do_log(3, "%s abort posting at %s", user_name, current_group);
		return;
	}
	if( protocol!=MAKEPOST)
	{
		do_log(8, "%s protocol_stat_err with protocol code %d at enter_mail", user_name, protocol);
		protocol_stat_err(fd);
	}

	bigbuf[rlen]=0;

	/*take off trailing cr-lf*/
	ret=strlen(bigbuf);
	ret--;
	while(ret>=0)
	{
		if( (bigbuf[ret]!=13) && (bigbuf[ret]!=10) )
			break;

		bigbuf[ret]=0;
		ret--;
	}

	if( ret<0 )
	{
		do_log(3, "%s made an empty post at %s", user_name, current_group);
		return;
	}

	strcpy(from_name, user_name);

	for(n=0; n<strlen(from_name); n++)
		if( from_name[n]==' ' )
		{
			from_name[n]='_';
			break;
		}

	if(debug_mode) printf("(postmail.c)server writing post\n");

	/*---------------------------------------------------------------*/
	if( strcmp(current_group, "mbox") )
	{
		sprintf(mfile, "%s/%s/messages", MAIL_PATH, current_group);
		sprintf(rfile, "%s/%s/records", MAIL_PATH, current_group);
	}
	else	/*mbox*/
	{
		sprintf(mfile, "%s/mbox/%d.messages", MAIL_PATH, mbox_to_uid);
		sprintf(rfile, "%s/mbox/%d.records", MAIL_PATH, mbox_to_uid);
	}
	/*---------------------------------------------------------------*/

	if( !file_exist(mfile) )
	{
		test=open( mfile, O_WRONLY | O_APPEND | O_CREAT, S_IWUSR | S_IRUSR);
		if( test<0 )
		{
			off_putmp();
			do_log(9, "SYSTEM ERROR entermail %s open error!?", mfile);
			sprintf(ebuf, "postmail.c: %s", SYSTEM_ERROR);
			send_mpf(fd, ebuf, strlen(ebuf), REJECT);
			exit(12);
		}
		else
			close(test);
	}

	if( !file_exist(rfile) )
	{
		test=open( rfile, O_WRONLY | O_APPEND | O_CREAT, S_IWUSR | S_IRUSR);
		if( test<0 )
		{
			off_putmp();
			do_log(9, "SYSTEM ERROR %s open error!?", rfile);
			sprintf(ebuf, "postmail.c: %s", SYSTEM_ERROR);
			send_mpf(fd, ebuf, strlen(ebuf), REJECT);
			exit(12);
		}
		else
			close(test);
	}

	msgfile=open(mfile, O_WRONLY | O_APPEND);
	if( msgfile<0 )
	{
		off_putmp();
		do_log(9, "SYSTEM ERROR %s open error!?", mfile);
		sprintf(ebuf, "postmail.c: %s", SYSTEM_ERROR);
		send_mpf(fd, ebuf, strlen(ebuf), REJECT);
		exit(12);
	}

	recfile=open(rfile, O_WRONLY | O_APPEND);
	if( recfile<0 )
	{
		off_putmp();
		do_log(9, "SYSTEM ERROR %s open error!?", rfile);
		sprintf(ebuf, "postmail.c: %s", SYSTEM_ERROR);
		send_mpf(fd, ebuf, strlen(ebuf), REJECT);
		exit(12);
	}

	flock(msgfile, LOCK_EX);	/*exclusive lock*/
	flock(recfile, LOCK_EX);	/*exclusive lock*/

	lseek(msgfile, 0, SEEK_END);
	mr.offset=file_length(msgfile);
	nstrcpy(mr.subject, post_subject, 60);
	mr.packed=' ';
	mr.delete_mark=' ';

	memset(buf, 0, 255);
	sprintf(buf, "Path: %s%c%c", STATION_ID, 13, 10);
		write(msgfile, buf, strlen(buf) );

	memset(buf, 0, 255);
	sprintf(buf, "From: %s.pbbs@%s (%s)%c%c", from_name, NNRP_DOMAIN,  user_name, 13, 10);
		write(msgfile, buf, strlen(buf) );

	memset(buf, 0, 255);
	sprintf(buf, "Subject: %s%c%c", post_subject, 13, 10);
		write(msgfile, buf, strlen(buf) );

	memset(buf, 0, 255);
	memset(message_id, 0, 128);
	memset(unique_id, 0, 20);
	get_mid(unique_id);
	sprintf(message_id, "<%s@%s>", unique_id, NNRP_DOMAIN);
	sprintf(buf, "Message-ID: %s%c%c", message_id, 13, 10);
		write(msgfile, buf, strlen(buf) );

	rfcgmtime(timebuf);
	memset(buf, 0, 255);
	sprintf(buf, "Date: %s GMT%c%c", timebuf, 13, 10);
		write(msgfile, buf, strlen(buf) );

	memset(buf, 0, 255);
	sprintf(buf, "Organization: %s%c%c", SORGANIZATION, 13, 10);
		write(msgfile, buf, strlen(buf) );

	if( email_check(user_email) )
	{
		memset(buf, 0, 255);
		sprintf(buf, "Reply-To: %s%c%c", user_email, 13, 10);
			write(msgfile, buf, strlen(buf) );
	}

	memset(buf, 0, 255);
	sprintf(buf, "%c%c", 13, 10);
	write(msgfile, buf, 2);

	if( emode==1 && strcmp(current_group, "mbox") )
	{
		memset(buf, 0, 255);
		sprintf(buf, "followed %s's post...%c%c", o_from_user, 13, 10);
		write(msgfile, buf, strlen(buf));
	}

	/* output msgtxt with CR-LF */
	find_d=FALSE;
	for(outcnt=0; outcnt<strlen(bigbuf); outcnt++)
	{
	  if( bigbuf[outcnt]==0xd )
	  {
	    find_d=TRUE;
	    break;
	  }
	}

	if( find_d )
	{
	  if(debug_mode)printf("(postmail.c)write msgtxt directly\n");
	  write(msgfile, bigbuf, strlen(bigbuf) );
	}
	else
	{
	  if(debug_mode)printf("(postmail.c)write msgtxt with CR-LF trans\n");
	  for(outcnt=0; outcnt<strlen(bigbuf); outcnt++)
	  {
	    if( bigbuf[outcnt]==0xa )
		write(msgfile, &od, 1);

	    write(msgfile, bigbuf+outcnt, 1);
	  }
	}

	/*add origin line if exist*/
	sprintf(origin_filename, "%s/%s/origin", MAIL_PATH, current_group);
	if( file_exist(origin_filename) || !strcmp(DEFAULT_ORIGIN, "YES") )
	{
		if( file_exist(origin_filename) )
		{
			origin_file=fopen(origin_filename, "r");
			fgets( origin_line, 79, origin_file);
			fclose(origin_file);
		}
		else
		{
			strcpy(origin_line, ORIGIN_LINE);
		}

		write(msgfile, crlf, strlen(crlf) );

		memset(buf, 0, 255);

		sprintf(ck1, "%c--%c", 10, 13);
		sprintf(ck2, "%c--%c", 10, 10);

		if( strstr(bigbuf, ck1) || strstr(bigbuf, ck2) )
		  sprintf(buf, "%c%c * Origin: %s%c%c", 13, 10, origin_line, 13, 10);
		else
		  sprintf(buf, "--%c%c * Origin: %s%c%c", 13, 10, origin_line, 13, 10);
		write(msgfile, buf, strlen(buf) );
	}

	lseek(msgfile, 0, SEEK_END);
	mr.length=file_length(msgfile)-mr.offset;

	write(recfile, &mr, sizeof(mr) );

	flock(msgfile, LOCK_UN);	/*unlock*/
	flock(recfile, LOCK_UN);	/*unlock*/

	do_log(6, "%s post a new mail at %s mid %s", user_name, current_group, message_id);

	/*add mid for nnrp check*/
	sprintf(buf, "%d", (file_length(recfile)/sizeof(struct msgrec)) );
	init_dbz_channel();
	add_mid(message_id, buf);
	close_dbz_channel();

	close(msgfile);
	close(recfile);

	if( !strcmp(current_group, "mbox") )
	{
		do_log(0, "set mbox quote to user #%d", mbox_to_uid);
		set_mail_quote(mbox_to_uid, 'Y');
	}
	else
	{
		/*add user's total_post record*/
		get_user_data(&urec, user_uid);
		urec.total_post++;
		set_user_data(&urec, user_uid);
	}
}
/*end of enter_mail*/



/*
	test if a line is trash quoted.
	eg. > > >
	    : : :
*/
trash_quotes(line, quote_len)
char *line;
int *quote_len;
/*
return:
	TRUE:	yes! this line is a trash quoted line
	FALSE:	no! keep this line
*/
{
  int max_quotes_entry=2;
  int quote_entry=0;
  int q_len=0;
  char *p;

  p=line;
  do
  {

    if( !strncmp(p, "> ", 2) )
    {
      quote_entry++;
      q_len+=2;
      p+=2;
      continue;
    }
    else if( !strncmp(p, ": ", 2) )
    {
      quote_entry++;
      q_len+=2;
      p+=2;
      continue;
    }
    else if( !strncmp(p, ") ", 2) )
    {
      quote_entry++;
      q_len+=2;
      p+=2;
      continue;
    }
    else if( !strncmp(p, ">> ", 3) )
    {
      quote_entry++;
      q_len+=3;
      p+=3;
      continue;
    }
    else if( isalpha(*p) && isalpha(*(p+1)) && *(p+2)=='>' && *(p+3)==' ' )
    {
      /* eg. "SC> " */
      quote_entry++;
      q_len+=4;
      p+=4;
      continue;
    }
    else
      break;

  }while(TRUE);

  if( quote_entry>=max_quotes_entry )
  {
    *quote_len=q_len;
    return(TRUE);
  }

  return(FALSE);

}
/*end of trash_quotes*/



/*
	send Internet E-Mail
*/
send_email(fd)
int fd;
{
  char answer[80];
  char email_add[80];
  char post_subject[80];
  int rlen, ret, n;
  char protocol;
  char from_name[20];
  char sendmail[256];
  FILE *fd_pipe;

  if(debug_mode) printf("(postmail.c)send_email\n");

  if( user_level<USE_EMAIL_LEVEL )
  {
    display_msg(fd, EMAIL_SECURITY);
    suspend(fd);
    return;
  }

  memset(email_add, 0, 80);
  asking(fd, EMAIL_TO, email_add, 80);
  alltrim(email_add);
  strip_nl(email_add);
  ret=strlen(email_add);
  if( email_add[0]=='<' || email_add[0]=='[' || email_add[0]=='(' )
  {
    for(n=1; n<ret; n++)
    {
      if( email_add[n]=='>' || email_add[n]==']' || email_add[n]=='>' )
      {
	email_add[n-1]=0;
	break;
      }
      email_add[n-1]=email_add[n];
    }
    email_add[ret-1]=0;
  }
  for(n=0; n<ret; n++)
    if(email_add[n]==' ') {email_add[n]=0; break;}
  if( strlen(email_add)==0 ) return;

  memset(answer, 0, 80);
  asking(fd, ASK_POST_SUBJECT, answer, 80);
  alltrim(answer);
  if( strlen(answer)==0 ) return;
  nstrcpy(post_subject, answer, 80);

  send_mpf(fd, NULL, 0, MAKEPOST);
  idling=IDLE_TIME * POST_FACTOR;	/*extent editing time*/
  read_mpf(fd, bigbuf, &rlen, &protocol, FALSE);
  idling=IDLE_TIME;		/*restore idling time*/

  if( protocol==STOPPOST )
    return;

  if( protocol!=MAKEPOST)
  {
	do_log(8, "%s protocol_stat_err with protocol code %d at send_email", user_name, protocol);
	protocol_stat_err(fd);
  }

  bigbuf[rlen]=0;

  /*take off trailing cr-lf*/
  ret=strlen(bigbuf);
  ret--;
  while(ret>=0)
  {
    if( (bigbuf[ret]!=13) && (bigbuf[ret]!=10) )
	break;

    bigbuf[ret]=0;
	ret--;
  }

  if( ret<0 )
    return;

  strcpy(from_name, user_name);

  for(n=0; n<strlen(from_name); n++)
    if( from_name[n]==' ' )
    {
	from_name[n]='_';
	break;
    }

  sprintf(sendmail, "%s -f%s.pbbs -F%s %s", SENDMAIL_CMD, from_name, from_name, email_add);
  if(debug_mode)printf("(send_email)popen %s\n", sendmail);
  if (( fd_pipe = popen(sendmail, "w")) == NULL)
  {
    do_log(5, "%s popen sendmail %s error", user_name, email_add);
    return;
  }

  memset(buf, 0, 255);
  sprintf(buf, "Subject: %s%c%c", post_subject, 13, 10);
	fprintf(fd_pipe, "%s", buf);

  if( email_check(user_email) )
  {
	memset(buf, 0, 255);
	sprintf(buf, "Reply-To: %s%c%c", user_email, 13, 10);
	  fprintf(fd_pipe, "%s", buf);
  }
  else
  {
	memset(buf, 0, 255);
	sprintf(buf, "Reply-To: %s.pbbs@%s%c%c", from_name, NNRP_DOMAIN, 13, 10);
	  fprintf(fd_pipe, "%s", buf);
  }

  memset(buf, 0, 255);
  sprintf(buf, "%c%c", 13, 10);
    fprintf(fd_pipe, "%s", buf);

  fprintf(fd_pipe, "%s", bigbuf);

  fprintf(fd_pipe, "%c%c%c", 0xd, 0xa, 4);	/*add ctrl-d EOF*/

  do_log(5, "%s send email to %s", user_name, email_add);

  pclose(fd_pipe);

}
/*end of send_email*/



/*
	reply email
*/
reply_email(fd, subject, reply_add, quotation)
int fd;
char *subject;
char *reply_add;
char *quotation;
{
  char answer[80];
  char email_add[80];
  char post_subject[80];
  int rlen, ret, n, m, qc;
  char protocol;
  char from_name[20];
  char sendmail[256];
  FILE *fd_pipe;
  char *p;
  char crlf[3];

  if(debug_mode) printf("(postmail.c)reply_email\n");

  if( user_level<USE_EMAIL_LEVEL )
  {
    display_msg(fd, EMAIL_SECURITY);
    suspend(fd);
    return;
  }

  sprintf(buf, "%s [%-.55s](Y/N)?", REPLY_EMAIL_TO, reply_add);
  if( yes_no(fd, buf)!='y' )
  {
    memset(email_add, 0, 80);
    asking(fd, EMAIL_TO, email_add, 80);
  }
  else
    nstrcpy(email_add, reply_add, 80);

  alltrim(email_add);
  strip_nl(email_add);
  ret=strlen(email_add);
  if( email_add[0]=='<' || email_add[0]=='[' || email_add[0]=='(' )
  {
    for(n=1; n<ret; n++)
    {
      if( email_add[n]=='>' || email_add[n]==']' || email_add[n]=='>' )
      {
	email_add[n-1]=0;
	break;
      }
      email_add[n-1]=email_add[n];
    }
    email_add[ret-1]=0;
  }
  for(n=0; n<ret; n++)
    if(email_add[n]==' ') {email_add[n]=0; break;}
  if( strlen(email_add)==0 ) return;

  /*************/
  /*ask subject*/
  /*************/
  memset(answer, 0, 80);
  memset(buf, 0, 255);

  if( yes_no(fd, USE_SAME_SUBJECT)!='y' )
  {
	sprintf(buf, "%s ", ASK_POST_SUBJECT);
	asking(fd, buf, answer, 80);
	alltrim(answer);
	if( strlen(answer)==0 ) return;
	nstrcpy(post_subject, answer, 80);
  }
  else
  {
	if( strncmp(subject, "Re: ", 4) )
	{
	  strcpy(buf, "Re: ");
	  nstrcpy(buf+4, subject, 80);
	  nstrcpy(post_subject, buf, 80);
	}
	else
	{
	  nstrcpy(post_subject, subject, 80);
	}
  }

  /*ask quotation*/
  if( yes_no(fd, USE_QUOTATION)=='y' )
  {
	/*add quotation sign*/
	p=quotation;
	n=strlen(p);

	/*add first quotation mark*/
	for(m=n; m>=0; m--)
		p[m+2]=p[m];
	p[0]='>';
	p[1]=' ';
	p[n+2]=0;

	qc=1;	/*quotation count*/

	while(1)
	{
		p++;
		if(*p==0)
			break ;

		if(*p==10)
		{
			p++;
			if(*p==0)
				break ;

			n=strlen(p);

			/*compress blank lines*/
			if(*p==13 || *p==10)
			{
			  ret=0;
			  while( p[ret]==13 || p[ret]==10 )
				ret++;
			  for(m=0; m<(n-ret); m++)
				p[m]=p[m+ret];
			  p[n-ret]=0;
			  n=strlen(p);
			}

			/*remove too old quoats (> > > )*/
			do
			{
			  ret=0;
			  if( trash_quotes(p, &ret) )
			  {
			    /*find LF*/
			    while( p[ret]!=13 && p[ret]!=10 && p[ret]!=0 )
				ret++;
			    /*remove whole line*/
			    while( p[ret]==13 || p[ret]==10 )
				ret++;
			    for(m=0; m<(n-ret); m++)
				p[m]=p[m+ret];
			    p[n-ret]=0;
			    n=strlen(p);
			    continue;
			  }
			  else
			    break;
			}
			while(TRUE);

			/*check singatur line "--\n" */
			if( n>=3 )
			{
			  if( p[0]=='-' && p[1]=='-' && (p[2]==13 || p[2]==10) )
			  /*sig lines found, strip it*/
			  {
				p[0]=0;
				break;
			  }
			}

			/*add other quotation marks*/
			for(m=n; m>=0; m--)
				p[m+2]=p[m];
			p[0]='>';
			p[1]=' ';
			p[n+2]=0;

			qc++;
		}

		if( qc > MAX_QUOTE )
		{
			p[0]=0;
			break;
		}
	}

	strcat(quotation, crlf);

	send_mpf(fd, quotation, strlen(quotation), MAKEPOST);
  }
  else
	send_mpf(fd, NULL, 0, MAKEPOST);

  idling=IDLE_TIME * POST_FACTOR;	/*extent editing time*/
  read_mpf(fd, bigbuf, &rlen, &protocol, FALSE);
  idling=IDLE_TIME;		/*restore idling time*/

  if( protocol==STOPPOST )
    return;

  if( protocol!=MAKEPOST)
  {
    do_log(8, "%s protocol_stat_err with protocol code %d at reply_email", user_name, protocol);
    protocol_stat_err(fd);
  }

  bigbuf[rlen]=0;

  /*take off trailing cr-lf*/
  ret=strlen(bigbuf);
  ret--;
  while(ret>=0)
  {
    if( (bigbuf[ret]!=13) && (bigbuf[ret]!=10) )
	break;

    bigbuf[ret]=0;
    ret--;
  }

  if( ret<0 )
    return;

  strcpy(from_name, user_name);

  for(n=0; n<strlen(from_name); n++)
    if( from_name[n]==' ' )
    {
	from_name[n]='_';
	break;
    }

  sprintf(sendmail, "%s -f%s.pbbs -F%s %s", SENDMAIL_CMD, from_name, from_name, email_add);
  if(debug_mode)printf("(reply_email)popen %s\n", sendmail);
  if (( fd_pipe = popen(sendmail, "w")) == NULL)
  {
    do_log(5, "%s popen sendmail %s error", user_name, email_add);
    return;
  }

  memset(buf, 0, 255);
  sprintf(buf, "Subject: %s%c%c", post_subject, 13, 10);
	fprintf(fd_pipe, "%s", buf);

  if( email_check(user_email) )
  {
	memset(buf, 0, 255);
	sprintf(buf, "Reply-To: %s%c%c", user_email, 13, 10);
	  fprintf(fd_pipe, "%s", buf);
  }
  else
  {
	memset(buf, 0, 255);
	sprintf(buf, "Reply-To: %s.pbbs@%s%c%c", from_name, NNRP_DOMAIN, 13, 10);
	  fprintf(fd_pipe, "%s", buf);
  }

  memset(buf, 0, 255);
  sprintf(buf, "%c%c", 13, 10);
    fprintf(fd_pipe, "%s", buf);

  fprintf(fd_pipe, "%s", bigbuf);

  fprintf(fd_pipe, "%c%c%c", 0xd, 0xa, 4);	/*add ctrl-d EOF*/

  do_log(5, "%s reply email to %s", user_name, email_add);

  pclose(fd_pipe);

}
/*end of reply_email*/
