/***************************************************************************
 * serve.c --- initial service from main				   *
 *	       by Samson Chen, Nov 30, 1993				   *
 ***************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"	/*this module need program global vars*/
#include "dbf.h"

static char rcsid[]="$Id: serve.c,v 1.12 1995/11/22 10:19:11 pbbs Exp pbbs $";

/*special global var*/
int global_fd;	/*for the history reason, signal function timeup() is hard to*/
		/*  do parameter passing, my only way is to use a global var*/
		/*  as an alternative choice*/


/*global cars*/
unsigned char platform;	/*client's platform*/


/*
	do service for network client
	function will not return... just EXIT
*/
serve(fd)
	int fd;			/*the service socket file descriptor*/
{
	int	ret;
	char	bigbuf[MAX_BUF];
	unsigned long rlen;
	char	protocol;

	global_fd = fd;

	/*
		Session Check
	*/
	alarm(IDLE_TIME);
	while( !(ret=read_mpf(fd, bigbuf, &rlen, &protocol, TRUE)) );
	if( ret<0 ) 	/*get non-mpf request, suppose not PBBS client*/
	{
		/*check if non-secure data request*/
		if( non_mpf(fd, bigbuf, rlen) < 0 )
		{
			session1_err(fd);
		}
		else
		{
			close(fd);
			exit(50);
		}
	}

	if(debug_mode) printf("(serve.c)session1 passed\n");

	bigbuf[rlen]=0;	/*null-terminated tring*/
	if( (protocol != SESSION) || strcmp(bigbuf, "Samson") ) 
		session2_err(fd);	/*client procedure mistake*/

	if(debug_mode) printf("(serve.c)session2 passed\n");

	send_mpf(fd, "Aquarius", 8, SESSION);

	read_mpf(fd, bigbuf, &rlen, &protocol, FALSE);	/*block*/
	bigbuf[rlen]=0;	/*null-terminated tring*/

	/* check client version if it is too old */
	switch( check_ver((unsigned char)bigbuf[0]) )
	{
	case -1:
		do_log(3, "%s use a too-old client program", client_site);
		session3_err(fd);	/*client too old*/
		/*never return call*/
		break;

	case 0:
		do_log(3, "%s use an old client program", client_site);
		display_msg(fd, OLD_CLIENT);
		suspend(fd);
		break;
	}

	if(debug_mode) printf("(serve.c)session3 passed\n");

	/* store client's platform code */
	platform=(unsigned char)bigbuf[1];
	log_platform(platform);

	/* switch service */
	if( !strcmp(bigbuf+2, "POWERBBS") )
	{
		if( *(bigbuf+11)=='(' )	/*public client redirect address*/
		{
		  do_log(5, "redirect address from '%s' to '%s'", client_site, bigbuf+11);
		  nstrcpy(client_site, bigbuf+11, 30);
		}

		strcpy(bigbuf, "Server connected with host ");
		strcat(bigbuf, client_site);
		strcat(bigbuf, "\n");
		send_mpf(fd, bigbuf, strlen(bigbuf), DISPLAY);

		if(on_line_users>MAX_LOAD)
		{
			display_msg(fd, LOAD_TOO_HEAVY);
			do_log(1, "%s login in heavy load time", client_site);
			reject(fd, 40);
			/*never touched code*/
		}
		else
			do_BBS(fd);
	}
	else
	{
		service_unknown(fd);
	}

	off_putmp();

	(void) close(fd);
	exit(0);
}
/*end of serve*/



/*
	reap child process which was ready to die
*/
#ifndef	SYSV
reaper()
{
	union wait status;

	on_line_users--;
#ifndef ALPHA
	while(wait3((int*)&status, (int)WNOHANG, (struct rusage *)0) > 0);
#else
	while(wait3(&status, (int)WNOHANG, (struct rusage *)0) > 0);
#endif

}
#endif
/*end of reaper*/



/*
	timeup --- user idle too long
*/
timeup()
{

	char buf[255];

	do_log(2, "%s idle too long", client_site);

	if( fail_then_remove )
	{
	  fail_then_remove=FALSE;
	  do_log(5, "%s fail_then_remove %s", user_name,  f_t_r_filename);
	  unlink(f_t_r_filename);
	}

	off_putmp();
	sprintf(buf, "%s", IDLE_TOO_LONG);
	send_mpf(global_fd, buf, strlen(buf), REJECT);

	exit(9);
}
/*end of timeup*/



/*
	paging --- someone sending a message
*/
paging()
{
	char line[256];
	struct putmp purec;
	FILE *talk_file;

	get_putmp(&purec, putmp_rec);

	switch(purec.page_mode)
	{
	case 0:
	  sprintf(line, "%s/talk.%d", TALK_BUFFER, purec.page_uid);

	  send_file_display(global_fd, line);
	  display_msg(global_fd, "\n");
	  suspend(global_fd);
	
	  break;

	case 1:
	  sprintf(line, "%s/talk.%d", TALK_BUFFER, purec.page_uid);

	  talk_file=fopen(line, "r");
	  fgets(line, 80, talk_file);
	  fclose(talk_file);

	  if(debug_mode) printf("(serve.c)send talk signal %s\n", line);
	  send_mpf(global_fd, line, strlen(line), TALK);

	  break;
	}

#ifdef	LINUX
	(void) signal(SIGUSR1, (void*)paging);
#endif

}
/*end of paging*/



/*
	bbs_term --- process get SIGTERM termination signal
*/
bbs_term()
{
	do_log(5, "process for %s was terminated!", user_name);

	if( fail_then_remove )
	{
	  fail_then_remove=FALSE;
	  do_log(5, "%s fail_then_remove %s", user_name,  f_t_r_filename);
	  unlink(f_t_r_filename);
	}

	off_putmp();
	exit(6);
}
/*end of bbsabort*/
