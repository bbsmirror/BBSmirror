/**************************************************
    Purge mail. redo mail data base
    write by Aquarius Kuo  July 5, 1994.
    remodified by Samson Chen April 15, 1995
***************************************************/
#include "../host/pbbs.h"
#include "../host/dbf.h"
#include "../setup.h"
#include <ctype.h>

#define MAXLB     240

/********************************
    get file length
    write by Aquarius Kuo.
*/
long flength(filename)
char *filename ;
{
  struct stat file_status ;
  
  stat(filename,&file_status) ;
  return(file_status.st_size) ;
}



/*
	del msgs if total msgs are over maxno
	(make delete mark only, should be scanpurge after this operation)
*/
purge_data(dir,maxno,reserve)
char *dir ;
long maxno ;		/* if total_msg > maxno then purge mail database */
long reserve ;	 	/* max hold number */
{
  char fn[MAXLB];
  char mesg[MAXLB], reco[MAXLB], user[MAXLB] ;
  long i;
  int hr;
  int total_msg, del_no;
  struct msgrec recno ;

  if( (dir[0]==0) )      /* NULL string */
    return(1) ;

  if( !strcmp(dir,"mbox") )   /* personal mail box */
    return(1) ;

  sprintf(fn,"%s/%s",MAIL_PATH,dir) ;    /* fn is the current area path */

  sprintf(mesg,"%s/messages",fn) ;
  sprintf(reco,"%s/records",fn) ;
  sprintf(user,"%s/users",fn) ;

  if( !file_exist(mesg) || !file_exist(reco) )
  {
	return(1);
  }

  if((hr=open(reco,O_RDWR))<0)
  {
    back_up_err_msg(dir);
    return(1) ;
  }

  flock(hr,LOCK_EX) ;
  total_msg=flength(reco)/sizeof(struct msgrec) ;     /* n=record number */
  if( (total_msg>reserve) && (total_msg>maxno) )
  {

    del_no=total_msg-reserve;

    for(i=0; (i<total_msg) && (i<del_no); i++)
    {
      lseek(hr,i*sizeof(struct msgrec),SEEK_SET) ;
      if( read(hr,&recno,sizeof(struct msgrec))<=0 )
	break;

      if(recno.delete_mark=='D')	/*has been deleted*/
	continue;

      if(recno.delete_mark=='C')	/*cream post*/
	continue;

      recno.delete_mark='D';
      lseek(hr, i*sizeof(struct msgrec), SEEK_SET);
      write(hr, &recno, sizeof(struct msgrec) );
    }

  }/*end if*/

  flock(hr,LOCK_UN) ;
  close(hr) ;

  return(0) ;
}
/*end of do_del*/



/*========================================================*/
main(argc,argv)
int argc ;
char *argv[] ;
{
  char marea[MAXLB], dir[MAXLB], fn[MAXLB] ;
  char mesg[80], reco[80], user[80] ;
  char *ptr ;
  long i, j, offset ;
  long maxno, hold_max ;
  int  smode=0 ;
  struct msgrec recno ;
  FILE *fp ;

  chdir(SYSTEM_PATH) ;

  if(argc<3)
  {
    printf("syntax error:\n") ;
    printf("       %s -s <control_filename>\r\n\n", argv[0]) ;
    printf("       %s -d <mail_area_directory> <purge_num> <keep_num>\r\n\n", argv[0]) ;
    exit(1) ;
  }
  
  if( !strcmp(argv[1],"-s") )
  {
    sprintf(fn,"%s",argv[2]) ;
    if( (fp=fopen(fn,"r"))==NULL )
    {
      printf("%s not found!!\r\n\n",fn) ;
      exit(1) ;
    }
    smode=1 ;         /* setup file */
  }

  if( !strcmp(argv[1],"-d") )
  {
    strcpy(dir,argv[2]) ;
    if(argc>4)
    {
      maxno=atoi(argv[3]) ;
      hold_max=atoi(argv[4]) ;
      purge_data(dir,maxno,hold_max) ;
      smode=2 ;         /* mail area directory */
    }
  }
  
  if( smode==0 )
  {
    printf("syntax error:\n") ;
    printf("       %s -s <filename>\r\n\n", argv[0]) ;
    printf("       %s -d <mail_area_directory> <purge_num> <keep_num>\r\n\n", argv[0]) ;
    exit(1) ;
  }

  if( smode==1 )
  {
    while(fgets(marea,MAXLB,fp)!=NULL)
    {
      ptr=marea ;
      if(*ptr=='#')       /* remark line */
        continue ;

      while( (!isspace(*ptr)) && *ptr!=0 )        /* get area name */
        ptr++ ;

      if( *ptr==0 )       /* no maxno */
        continue ;

      *ptr=0 ;
      while( isspace(*(++ptr)) && *ptr!=0 ) ;     /* parse space alpha */
    
      if( *ptr==0 )
        continue ;
        
      maxno=atoi(ptr) ;           /* get max hold number */
      
      while( isdigit(*(++ptr)) && *ptr!=0 ) ;     /* parse digit alpha */
      while( isspace(*(++ptr)) && *ptr!=0 ) ;     /* parse space alpha */
      hold_max=atoi(ptr) ;
      if( hold_max==0 )
        hold_max=maxno ;
    
      strcpy(dir,marea) ;         /* dir record the mail area directory */

      purge_data(dir,maxno,hold_max) ;
    }

    fclose(fp) ;
  }

}
/*end of main*/
/**************************************************************************/



/*
	file_exist
*/
file_exist(filename)
char *filename;
/*
        return: TRUE: exist
                FALSE: not exist
*/
{
        FILE *testexist;

        if( (testexist=fopen(filename, "r")) == NULL)
                return(FALSE);          /*not found*/
        else    /*file found*/
        {
                fclose(testexist);
                return(TRUE);
        }
}
/*end of file_exist*/



/*
	remove old *.bak, rename current one to *.bak
*/
back_up_err_msg(area)
char *area;
{
  char mpath[256], source[256], target[256];

  sprintf(mpath, "%s/%s", MAIL_PATH, area);

  sprintf(source, "%s/messages", mpath);
  sprintf(target, "%s/messages.bak", mpath);
  rename(source, target);

  sprintf(source, "%s/records", mpath);
  sprintf(target, "%s/records.bak", mpath);
  rename(source, target);

  sprintf(source, "%s/users", mpath);
  sprintf(target, "%s/users.bak", mpath);
  if( file_exist(source) )
    rename(source, target);

  printf(" purgemail.c : '%s' message files error, backup files created...\n", area);
  printf(" 		 try 'rebuild_msg_rec %s' utility!\n", area);
}
/*end of back_up_err_msg*/
