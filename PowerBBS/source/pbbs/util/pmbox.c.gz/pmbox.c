/**************************************************
        Purge mbox by Samson Chen. Apr 4, 1995
***************************************************/
#include "../host/pbbs.h"
#include "../host/dbf.h"
#include "../setup.h"
#include <ctype.h>

#define MAXLB     240

char    debug_mode=FALSE;



/*========================================================*/
main(argc,argv)
int argc ;
char *argv[] ;
{
  char mbox_path[256], ppath[256];
  int keeps;
  long user_no;
  struct dirent *dirp;
  DIR *dp;

  chdir(SYSTEM_PATH) ;

  if(argc<2)
  {
    printf("Purge mbox by Samson Chen, Apr 4, 1995\n\n");
    printf(" Usage:\n");
    printf("   %s <keeps> [-d]\n\n", argv[0]);
    exit(0);
  }

  if(argc>=3)
    if( *(argv[2]+1)=='d' )
      debug_mode=TRUE;

  keeps=atoi(argv[1]);

  if(keeps<=0)
  {
    printf("If you want to remove all mails in mbox,\n");
    printf("maybe use 'rm *' will be sooner.\n\n");
    exit(1);
  }

  sprintf(mbox_path,"%s/mbox", MAIL_PATH);

  /*-------------------------------------*/
  /*stage ONE, remove all null mbox files*/
  /*-------------------------------------*/
  if( debug_mode )
    printf("check null mbox files...\n");

  dp=opendir(mbox_path);
  while( (dirp = readdir(dp)) != NULL )
  {
        strcpy(ppath, dirp->d_name);
        if( !strcmp(ppath, ".") || !strcmp(ppath, "..") )
                continue;

        user_no=get_msg_uid(ppath);
	if(user_no<=0)
		continue;

        remove_null(user_no);
  }
  closedir(dp);

  /*-------------------------*/
  /*stage TWO, purge msg file*/
  /*-------------------------*/
  /*
    note: 1. purge message file
          2. count
          3. set del mark if msgs is over keeps
    ps. msg is deleted today, it will be purged tomorrow
  */
  if( debug_mode )
    printf("\npurge mbox files...\n");

  dp=opendir(mbox_path);
  while( (dirp = readdir(dp)) != NULL )
  {
        strcpy(ppath, dirp->d_name);
        if( !strcmp(ppath, ".") || !strcmp(ppath, "..") )
                continue;

        user_no=get_msg_uid(ppath);
	if(user_no<=0)
		continue;

        purge(user_no);
  }
  closedir(dp);

  /*-----------------------------*/
  /*stage THREE, count and delete*/
  /*-----------------------------*/
  if( debug_mode )
    printf("\ndelete mbox files which over %d mails...\n", keeps);

  dp=opendir(mbox_path);
  while( (dirp = readdir(dp)) != NULL )
  {
        strcpy(ppath, dirp->d_name);
        if( !strcmp(ppath, ".") || !strcmp(ppath, "..") )
                continue;

        user_no=get_msg_uid(ppath);
	if(user_no<=0)
		continue;

        count_del(user_no, keeps);
  }
  closedir(dp);

  if( debug_mode )
    printf("\n");
}
/*end of main*/



/*
        get_msg_uid --- get user id if filename is (uid.messages)
*/
get_msg_uid(filename)
char *filename;
/*
        return:
                0 : not a message file
               >0 : the user who the message file belong to
*/
{
  char fn[256];
  int flen;

  if( strlen(filename) < 10 )   /*minimum length (1.messages)*/
    return(0);

  strcpy(fn, filename);
  flen=strlen(fn);

  if( strcmp(".messages", filename+flen-9) )
    return(0);

  fn[flen-9]=0;

  return(atoi(fn));
}
/*end of get_msg_uid*/



/*
        remove_null --- check user mbox file, if null, remove it
*/
remove_null(uid)
int uid;
{
  char mpath[256], rpath[256];

  sprintf(mpath, "%s/mbox/%d.messages", MAIL_PATH, uid);
  sprintf(rpath, "%s/mbox/%d.records", MAIL_PATH, uid);

  /*not null, return*/
  if( flength(mpath)>0 )
    return;

  if( debug_mode )
    printf(" %d.messages : ", uid);

  if( user_on_line(uid) )
  {
    if( debug_mode )
      printf("user on line now, skip it\n");
  }
  else
  {
    unlink(rpath);
    unlink(mpath);
    set_lastread(uid, 0);

    if( debug_mode )
      printf("removed\n");
  }

}
/*end of remove_null*/



/*
        user_on_line --- if user uid on line now
*/
user_on_line(uid)
int uid;
/*
        return:
                TRUE : user uid on-line now
                FALSE: user uid not on-line now
*/
{
        int utf;
        struct putmp purec;

        if( !file_exist(ON_LINE_USER) )
          return(FALSE);

        utf=open(ON_LINE_USER, O_RDONLY, S_IWUSR | S_IRUSR);

        if( utf<0 )
          return(FALSE);

        while( read(utf, &purec, sizeof(struct putmp) ) )
          if( purec.active )
            if( purec.uid==uid )
              return(TRUE);

        close(utf);

        return(FALSE);

}
/*end of user_on_line*/



/*
        test if the path exist or not
*/
path_exist(pathname)
char *pathname;
{
        int ret;
        struct stat buf;

        ret=stat(pathname, &buf);

        if( ret<0 )
                return(FALSE);  /*path not exist*/

        if( (buf.st_mode & S_IFDIR)==0 )
                return(FALSE);  /*not a path*/

        return(TRUE);
}
/*end of path_exist*/



/*
    get file length
    write by Aquarius Kuo.
*/
long flength(filename)
char *filename ;
{
  struct stat file_status ;

  stat(filename,&file_status) ;
  return(file_status.st_size) ;
}
/*end of flength*/



/*
        file_exist
*/
file_exist(filename)
char *filename;
/*
        return: TRUE: exist
                FALSE: not exist
*/
{
        FILE *testexist;

        if( (testexist=fopen(filename, "r")) == NULL)
                return(FALSE);          /*not found*/
        else    /*file found*/
        {
                fclose(testexist);
                return(TRUE);
        }
}
/*end of file_exist*/



/*
        get_lastread --- get user's last of current_group
*/
get_lastread(uid)
        int uid;
/*
        return:
                current lastread number of the user_uid
*/
{
        char userlr_filename[80];
        int user_lr;
        int current_lastread;
	int records;

        sprintf(userlr_filename, "%s/mbox/users", MAIL_PATH);

        if( !file_exist(userlr_filename) )
          return(0);

        records=flength(userlr_filename)/sizeof(int);

        /*the user never comes here*/
        if( records < (uid+1) )
          return(0);

        user_lr=open(userlr_filename, O_RDONLY);

        if(user_lr<0)
          return(0);

        lseek(user_lr, uid*sizeof(int), SEEK_SET);
        read(user_lr, &current_lastread, sizeof(int) );

        close(user_lr);

        return(current_lastread);
}
/*end of get_lastread*/



/*
        set_lastread --- set user last read
*/
set_lastread(uid, lr)
        int uid;
        int lr;         /*new lastread number*/
{
        char userlr_filename[80];
        int user_lr;
	int records;

        sprintf(userlr_filename, "%s/mbox/users", MAIL_PATH);

        if( !file_exist(userlr_filename) )
          return;

        records=flength(userlr_filename)/sizeof(int);

        /*the user never comes here*/
        if( records < (uid+1) )
          return;

        user_lr=open(userlr_filename, O_RDWR);
        if(user_lr<0)
          return;

        if(lr<0)
                lr=0;

        lseek(user_lr, uid*sizeof(int), SEEK_SET);
        write(user_lr, &lr, sizeof(int) );

        close(user_lr);
}
/*end of set_lastread*/



/*
        purge only the messages which were marked deleted
*/
purge(uid)
int uid;
{
  char fn[MAXLB], buf[MAX_BUF+10240] ;
  char mesg[MAXLB], reco[MAXLB];
  char *ptr ;
  long i, j, m, n, tmp, cnt, offset ;
  int hm, hr, hu, ht1, ht2 ;            /* file handle */
  int f_err=0 ;
  struct msgrec recno ;
  long real_keep ;

  if( debug_mode )
    printf("scan %d\r", uid);

  sprintf(mesg,"%s/mbox/%d.messages",MAIL_PATH,uid) ;
  sprintf(reco,"%s/mbox/%d.records",MAIL_PATH,uid) ;

  if( !file_exist(mesg) || !file_exist(reco) )
  {
        if( file_exist(mesg) )
		back_up_err_msg(uid);

        if( file_exist(reco) )
                unlink(reco);

        return;
  }

  m=flength(mesg) ;
  n=flength(reco)/sizeof(struct msgrec) ;     /* n=record number */

  i=0;       /*--- i: old file pointer ---*/

  if( (hm=open(mesg,O_RDWR))<0 )
  {
    back_up_err_msg(uid);
    return;
  }

  if((hr=open(reco,O_RDWR))<0)
  {
    close(hm) ;
    back_up_err_msg(uid);
    return;
  }

  flock(hm,LOCK_EX) ;
  flock(hr,LOCK_EX) ;

  lseek(hr,i*sizeof(struct msgrec),SEEK_SET) ;

  j=0 ;   /*--- j: new file pointer ---*/
  offset=0 ;

  while(read(hr,&recno,sizeof(struct msgrec))>0)
  {
    if( (recno.offset>m) )      /* records error */
    {
      ftruncate(hm,0) ;
      ftruncate(hr,0) ;
      f_err=1 ;
      break ;
    }

    if(recno.delete_mark=='D')      /* deleted post */
    {
      i++ ;
      lseek(hr,i*sizeof(struct msgrec),SEEK_SET) ;
      continue ;
    }

    if( i==j )
    {
      i++ ;
      j++ ;
      offset+=recno.length ;
      lseek(hr,i*sizeof(struct msgrec),SEEK_SET) ;
      continue;       /*same pointer, does need to be moved*/
    }

    if( debug_mode )
      printf("%d: #%d --> #%d        \r", uid, i, j);

    if( recno.length>(MAX_BUF-128) )
    {
      printf(" pmbox.c: huge record found in uid #%d, action #%d-->#%d\n", uid, i, j);
      recno.length=MAX_BUF-256;
    }

    lseek(hm,recno.offset,SEEK_SET) ;
    read(hm,buf,recno.length) ;             /* move one message to tmp */

    lseek(hm,offset,SEEK_SET) ;
    write(hm,buf,recno.length) ;

    recno.offset=offset ;
    offset+=recno.length ;

    lseek(hr,j*sizeof(struct msgrec),SEEK_SET) ;
    write(hr,&recno,sizeof(struct msgrec)) ;       /* tmp for record */

    i++ ;
    j++ ;
    lseek(hr,i*sizeof(struct msgrec),SEEK_SET) ;
  }

  real_keep=j;

  if( !f_err )
  {
    ftruncate(hm,offset) ;
    ftruncate(hr,j*sizeof(struct msgrec)) ;

    tmp=get_lastread(uid);
    tmp-=(n-real_keep) ;

    if( tmp>real_keep )
      tmp=real_keep ;

    if( tmp<0 )
      tmp=0 ;

    set_lastread(uid, tmp);

  }

  flock(hm,LOCK_UN) ;
  flock(hr,LOCK_UN) ;
  close(hm) ;
  close(hr) ;

  if( debug_mode )
    printf("\n");

  return;
}
/*end of purge*/



/*
        del msgs if total msgs are over reserve
        (make delete makr only, should be scanpurge after this operation)
*/
count_del(uid, reserve)
int uid;
int reserve;
{
  char fn[MAXLB];
  char mesg[MAXLB], reco[MAXLB], user[MAXLB] ;
  long i;
  int hr;
  int total_msg, del_no;
  struct msgrec recno ;

  if( debug_mode )
    printf("scan %d\r", uid);

  sprintf(mesg,"%s/mbox/%d.messages",MAIL_PATH,uid) ;
  sprintf(reco,"%s/mbox/%d.records",MAIL_PATH,uid) ;

  if( !file_exist(mesg) || !file_exist(reco) )
  {
        if( file_exist(mesg) )
		back_up_err_msg(uid);

        if( file_exist(reco) )
                unlink(reco);

        return;
  }

  if((hr=open(reco,O_RDWR))<0)
  {
    back_up_err_msg(uid);
    return;
  }

  flock(hr,LOCK_EX) ;
  total_msg=flength(reco)/sizeof(struct msgrec) ;     /* n=record number */
  if( total_msg>reserve )
  {

    del_no=total_msg-reserve;

    for(i=0; i<del_no; i++)
    {
      lseek(hr,i*sizeof(struct msgrec),SEEK_SET) ;
      if( read(hr,&recno,sizeof(struct msgrec))<=0 )
        break;

      if(recno.delete_mark=='D')
        continue;

      if( debug_mode )
        printf("%d: delete #%d         \r", uid, i);

      recno.delete_mark='D';
      lseek(hr, i*sizeof(struct msgrec), SEEK_SET);
      write(hr, &recno, sizeof(struct msgrec) );
    }

  }/*end if*/

  flock(hr,LOCK_UN) ;
  close(hr) ;

  if( debug_mode )
    printf("\n");

  return;
}
/*end of count_del*/



/*
	remove old *.bak, rename current one to *.bak
*/
back_up_err_msg(uid)
int uid;
{
  char mpath[256], source[256], target[256];

  sprintf(mpath, "%s/mbox", MAIL_PATH);

  sprintf(source, "%s/%d.messages", uid);
  sprintf(target, "%s/%d.messages.bak", uid);
  rename(source, target);

  sprintf(source, "%s/%d.records", uid);
  sprintf(target, "%s/%d.records.bak", uid);
  if( file_exist(source) )
    rename(source, target);

  printf(" pmbox.c : uid #%d message files error, backup files created...\n", uid);
}
/*end of back_up_err_msg*/
