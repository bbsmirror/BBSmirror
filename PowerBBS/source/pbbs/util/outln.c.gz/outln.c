/*
	output lastname from USER_DATA_BASE by Samson Chen
	Dec 11, 1995
*/
#include <fcntl.h>
#include "../setup.h"
#include "../host/dbf.h"


main(argc, argv)
int argc;
char *argv[];
{
  struct udb udb;
  int min_level;
  int utf;
  int cnt;
  char filename[100] ;

  if( argc!=2 )
  {
    printf("Usage: %s <minimum_output_level>\n", argv[0]);
    exit(1);
  }

  chdir(SYSTEM_PATH);

  sprintf(filename, "%s.dbf", USER_DATA_BASE) ;
  if( (utf=open(filename, O_RDONLY)) <= 0 )
  {
    printf("\r\n\nNo user index here!!\r\n") ;
    exit(2) ;
  }

  min_level=atoi(argv[1]);

  while( read(utf, &udb, sizeof(struct udb) ) )
    if( udb.level>=min_level )
      for(cnt=0; cnt<strlen(udb.bbs_name); cnt++)
	if( udb.bbs_name[cnt]==' ' )
	  printf("%s\n", udb.bbs_name+cnt+1);

  close(utf);

}
/*end of main*/
