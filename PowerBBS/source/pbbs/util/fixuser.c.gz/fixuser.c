/********************************
    modify user data base
    write by Aquarisu Kuo
    Apr 20, 1994
**********************************/
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "../host/dbf.h"
#include "../setup.h"

#define LINES	23	/* In fact, is LINES-2 */
#define HEAD	" num     ID                Real name        S  Lvl  login    E-mail\r\n"
#define MORE	"Command ( H : help ) : "
	       /*1         2         3         4         5         6*/

char id[80] ;
int last_s ;

/*
	flength --- get length of a file
*/
long flength(filename)
	char *filename;
{
	int test;
        struct stat buf;
	
        test=open(filename, O_RDONLY);
        fstat(test, &buf);
	close(test);

        return(buf.st_size);
}
/*end of flength*/

/***************************
    like gets()
*/
int kkygets(buf)
char *buf ;
{
  unsigned char str[80] ;
  int i ;
  
  fflush(stdout) ;
  
  read(0,str,80) ;
  for(i=0; i<strlen(str); i++)
  {
    if(str[i]<32)
    {
      str[i]=0 ;
      break ;
    }
    str[i]=tolower(str[i]) ;
  }
  
  strcpy(buf,str) ;
}



/***************************
    like gets() without case conversion
*/
int kky_no_case_gets(buf)
char *buf ;
{
  unsigned char str[80] ;
  int i ;
  
  fflush(stdout) ;
  
  read(0,str,80) ;
  for(i=0; i<strlen(str); i++)
  {
    if(str[i]<32)
    {
      str[i]=0 ;
      break ;
    }
  }
 
  strcpy(buf,str) ;
}

/***************************/

int edit_data(rec)
struct udb *rec ;
{
  char buf[100] ;
  int chg=0 ;
  
  printf("ID:%s\r\n",rec->bbs_name) ;
  
  printf("Real name:[%s]",rec->real_name) ;
  kky_no_case_gets(buf) ;
  if(buf[0]!=0)
  {
    chg=1 ;
    buf[19]=0 ;
    strcpy(rec->real_name,buf) ;
  }
  
  printf("Password:[%s]",rec->password) ;
  kky_no_case_gets(buf) ;
  if(buf[0]!=0)
  {
    chg=1 ;
    buf[13]=0 ;
    strcpy(rec->password,buf) ;
  }
  
  printf("E-mail:[%s]",rec->email) ;
  kkygets(buf) ;
  if(buf[0]!=0)
  {
    chg=1 ;
    buf[39]=0 ;
    strcpy(rec->email,buf) ;
  }

  printf("Phone number:[%s]",rec->phone) ;
  kkygets(buf) ;
  if(buf[0]!=0)
  {
    chg=1 ;
    buf[19]=0 ;
    strcpy(rec->phone,buf) ;
  }
  
  printf("Address:[%s]",rec->address) ;
  kky_no_case_gets(buf) ;
  if(buf[0]!=0)
  {
    chg=1 ;
    buf[59]=0 ;
    strcpy(rec->address,buf) ;
  }
  
  printf("Sex:[%c]",rec->sex) ;
  kkygets(buf) ;
  if(buf[0]!=0)
  { 
    chg=1 ;
    rec->sex=buf[0] ;
  }
  
  printf("Last_from:[%s]",rec->last_from) ;
  kky_no_case_gets(buf) ;
  if(buf[0]!=0)
  {
    chg=1 ;
    buf[20]=0 ;
    strcpy(rec->last_from,buf) ;
  }
  
  printf("Terminal:[%s]",rec->term) ;
  kkygets(buf) ;
  if(buf[0]!=0)
  {
    chg=1 ;
    buf[7]=0 ;
    strcpy(rec->term,buf) ;
  }

  printf("Upgrade_service:[%s]",rec->pus_add) ;
  kky_no_case_gets(buf) ;
  if(buf[0]!=0)
  {
    chg=1 ;
    buf[40]=0 ;
    strcpy(rec->pus_add,buf) ;
  }
  
  printf("Level:[%d]",rec->level) ;
  kkygets(buf) ;
  if(buf[0]!=0)
  {
    chg=1 ;
    rec->level=atoi(buf) ;
  }
  
  if(chg==1)
  {
    do
    {
      printf("\n\rAre you sure to change the user data (Y/N) ?") ;
      fflush(stdout) ;
      kkygets(buf) ;
      buf[0]=tolower(buf[0]) ;
    }
    while( (buf[0]!='y') && (buf[0]!='n') ) ;
    if(buf[0]=='y')
      return(1) ;
  }
  
  return(0) ;    
}
/* end edit_data */

/********************************************
  lower(str)  transfer str to lower string
*/
char *lower(str)
char *str ;
{
  int i=0 ;
  
  while(*(str+i)!=0)  
  {
    *(str+i)=tolower(*(str+i)) ;
    i++ ;
  }
  return(str) ;
}
/*  end lower */


/********************************************
  search the user name from user data base
*/    
int search_id(fd,str) 
int fd ;
char *str ;
{
  struct udb rec ;
  int i, quit, n ;
  
  if(strlen(str)>0)
  {
    strcpy(id,str) ;
    last_s=0 ;
  }
  else
  {
    if(last_s==0)
    {
      printf("%cFind string:",13) ;
      kky_no_case_gets(str) ;
      if(str[0]==0)
        return(-1) ;
      else
      {
        strcpy(id,str) ;
        last_s=0 ;
      }
    }  
    else
    {
      last_s++ ;
    }
  }
  
  lseek(fd,last_s*sizeof(struct udb),SEEK_SET) ;
  
  quit=0 ;
  i=last_s ;
  while((n=read(fd,&rec,sizeof(struct udb)))>0)
  {
    i++ ;

    if(strstr(rec.bbs_name,id)!=NULL)
    {
      quit=1 ;
      break ;
    }

    if(strstr(rec.real_name,id)!=NULL)
    {
      quit=1 ;
      break ;
    }
    lseek(fd,i*sizeof(struct udb),SEEK_SET) ;
  }

  last_s=i-1 ;
  
  if(quit)
    return(i-1) ;
    
  return(-1) ;  
}

main()
{
	struct udb rec[27] ;
	int utf ;
	int recno=0 ;
	int maxno, h, last,i ;
	int user_id=30 ;
	int quit ;
	char filename[128] ;
	char ans[80], *ptr ;

	sprintf(filename, "%s.dbf", USER_DATA_BASE) ;
	if((maxno=flength(filename)/sizeof(struct udb))<=0)
	{
	  printf("\r\n\nNo user data base here!!\r\n") ;
	  exit(1) ;
	}
	
	if( (utf=open(filename, O_RDWR)) <= 0 )
		exit(1) ;
   	
   	last_s=0 ;
   	id[0]=0 ;
   	/*/\/\/\/\/\/\/\/\/\/\/\/\/\*/
   	
   	h=0 ;
   	quit=0 ;
	do
	{
	  last=(maxno>LINES+h) ? LINES+h:maxno ;
	  
	  for(i=h; i<last; i++)
 	  {
 	    lseek(utf, i*sizeof(struct udb), SEEK_SET);
	    read(utf,&rec[i-h],i*sizeof(struct udb)) ;
	  }
 	  
 	  printf(HEAD) ;
	  for(i=h; i<last; i++)
	  {
	    if(i==0)	continue ;
	    printf("%4d %-20s%-20s%c %3d %4d %-.22s\r\n",i,rec[i-h].bbs_name,
	                             		     rec[i-h].real_name,
						     rec[i-h].delete_mark,
						     rec[i-h].level,
						     rec[i-h].total_login,
						     rec[i-h].email ) ;
	  }
	  while(last<LINES+h)
	  {
	    last++ ;
	    printf("\n") ;
	  }  
	    
	  printf(MORE) ;
	  kkygets(ans) ;
	  
	  if(ans[0]==0)		/* Enter */
	  {
	    if((h+=LINES)>maxno)
	      h=maxno-1 ;
	  }
	  
	  if(ans[0]=='/')	/* Search */
	  {
	    if((recno=search_id(utf,&ans[1]))>0)
	      h=recno ;
	   
	    continue ;
	  }
	  
	  if( ((recno=atoi(ans))>0) && (recno<maxno) )	/* edit user */
	  {
	    lseek(utf, recno*sizeof(struct udb), SEEK_SET) ;
	    read(utf,&rec[1],sizeof(struct udb)) ;
	    if( edit_data(&rec[1])!=0 )
	    {
	      lseek(utf, recno*sizeof(struct udb), SEEK_SET) ;
	      write(utf,&rec[1],sizeof(struct udb)) ;
	    }
	    h=recno ;
	  }  
	  
	  if(!strcmp(ans,"q"))		/* Quit fix user */
	  {
	    quit=1 ;
	  }
	  
	  if(!strcmp(ans,"h"))		/* help screen */
	  {
	    printf("\r\n\n") ;
	    printf("   Enter : next page.\r\n") ;
	    printf("       b : back one page.\r\n\n") ;
	    printf("       # : edit data of user #.\r\n\n") ;
	    printf("       / : searh user.\r\n\n") ;
	    printf("       a : set user active tag ON .\r\n") ;
	    printf("       d : set user disable tag ON .\r\n") ;
	    printf("       k : set user kill tag ON .\r\n\n") ;
	    printf("       q : quit.\r\n") ;
	    printf("       s : show user data.\r\n") ;
	    printf("\r\n\n Press <Enter> to continue....\r\n") ;
	    kkygets(ans) ;
	  }
	  
	  if(!strcmp(ans,"b"))		/* back one screen */
	  {
	    h-=LINES ;
	    if(h<0)
	    {
	      h=0 ;
	    }  
	  }
	  
	  if(!strcmp(ans,"a"))		/* Active user */
	  {
	    printf("\n\n\rActive number:") ;
	    kkygets(ans) ;
	    ptr=ans ;
	    while((recno=atoi(ptr))>0)
	    {
	       lseek(utf, recno*sizeof(struct udb), SEEK_SET) ;
	       read(utf,&rec[1],sizeof(struct udb)) ;
  	       
  	       rec[1].delete_mark=' ' ;
  	       
  	       lseek(utf, recno*sizeof(struct udb), SEEK_SET) ;
	       write(utf,&rec[1],sizeof(struct udb)) ;
	       
	       while( isdigit(*ptr) )
		 ptr++ ;

	       while( isspace(*ptr) )
		 ptr++ ;
	       if( *ptr==0 )
  		 break ;
	    }
	  }
	  
	  if(!strcmp(ans,"k"))		/* kill user record */
	  {
	    printf("\n\n\rKill user number:") ;
	    kkygets(ans) ;
	    ptr=ans ;
	    while((recno=atoi(ptr))>0)
	    {
	       lseek(utf, recno*sizeof(struct udb), SEEK_SET) ;
	       read(utf,&rec[1],sizeof(struct udb)) ;
  	       
  	       rec[1].delete_mark='X' ;
  	       
  	       lseek(utf, recno*sizeof(struct udb), SEEK_SET) ;
	       write(utf,&rec[1],sizeof(struct udb)) ;
	       
	       while( isdigit(*ptr) )
		 ptr++ ;

	       while( isspace(*ptr) )
		 ptr++ ;
	       if( *ptr==0 )
  		 break ;
	    }
	  }

	  if(!strcmp(ans,"d"))		/* disable user */
	  {
	    printf("\n\n\rDisable user number:") ;
	    kkygets(ans) ;
	    ptr=ans ;
	    while((recno=atoi(ptr))>0)
	    {
	       lseek(utf, recno*sizeof(struct udb), SEEK_SET) ;
	       read(utf,&rec[1],sizeof(struct udb)) ;
  	       
  	       rec[1].delete_mark='*' ;
  	       
  	       lseek(utf, recno*sizeof(struct udb), SEEK_SET) ;
	       write(utf,&rec[1],sizeof(struct udb)) ;
	       
	       while( isdigit(*ptr) )
		 ptr++ ;

	       while( isspace(*ptr) )
		 ptr++ ;
	       if( *ptr==0 )
  		 break ;
	    }
	  }
	      
	  if(!strcmp(ans,"s"))		/* disable user */
	  {
	    printf("\n\n\rshow who:") ;
	    kkygets(ans) ;
	    ptr=ans ;
	    if((recno=atoi(ptr))>0)
	    {
	       lseek(utf, recno*sizeof(struct udb), SEEK_SET) ;
	       read(utf,&rec[1],sizeof(struct udb)) ;
  	       
	       printf("ID: %s\r\n",rec[1].bbs_name) ;
	       printf("Real Name: %s\r\n",rec[1].real_name) ;
	       printf("Sex: %c\r\n",rec[1].sex) ;
	       printf("E-mail: %s\r\n",rec[1].email) ;
	       printf("Phone: %s\r\n",rec[1].phone) ;
	       printf("Address: %s\r\n",rec[1].address) ;
	       printf("Last from: %s\r\n",rec[1].last_from) ;
	       printf("Upgrade_service: %s\r\n",rec[1].pus_add) ;
	       printf("First login: %s\r\n",rec[1].first_login) ;
	       printf("Last login: %s\r\n",rec[1].last_login) ;
	       printf("Total login: %ld\r\n",rec[1].total_login) ;
	       printf("Level: %d\r\n",rec[1].level) ;
	       printf("Personal mail: %c\r\n",rec[1].mailbox) ;
	       printf("Total Post: %ld\r\n",rec[1].total_post) ;
	       printf("Total Download: %ld\r\n",rec[1].total_download) ;
	       printf("Total Upload: %ld\r\n\n",rec[1].total_upload) ;

	       kkygets(ans) ;
	    }
	  }
	}
	while(quit==0) ;

	close(utf);
	exit(0) ;
}
