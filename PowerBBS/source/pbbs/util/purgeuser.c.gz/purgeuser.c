/********************************
    modify user data base
    write by Aquarisu Kuo
    Apr 20, 1994
**********************************/
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "../host/dbf.h"
#include "../setup.h"

#ifndef FALSE
#define	FALSE	0
#endif

#ifndef TRUE
#define TRUE	!FALSE
#endif

char debug_mode=FALSE;

/*
	flength --- get length of a file
*/
long flength(filename)
	char *filename;
{
	int test;
        struct stat buf;
	
        test=open(filename, O_RDONLY);
        fstat(test, &buf);
	close(test);

        return(buf.st_size);
}
/*end of flength*/

/*****************************/
int rfctime(rfcbuf)
/*****************************
    get RFC-977 format time
    write by Aquarius Kuo 
    Mar 23, 1994.

return: the length of string.
******************************/    
char *rfcbuf ;
{
  int len ;
  time_t timenow ;
  struct tm  *timeptr ;
  
  time(&timenow) ;
  timeptr=localtime(&timenow) ;
  len=strftime(rfcbuf,26,"%a, %d %b %Y %T",timeptr) ;
  return(len) ;
}
/*end of rfctime*/

/**************
   count idle days
*/
idle_days(rfcdate)
char *rfcdate ;
{
  char *ptr, now[30] ;
  char month[100] ;
  long offset, days, m1, m2 ;

  strcpy(month,"Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec ") ;
  rfctime(now) ;
  
  offset=12 ;
  days=(atoi(now+offset)-atoi(rfcdate+offset))*365 ;

  offset=8 ;
  for(m1=0; m1<12; m1++)
    if( !strncmp(now+offset,month+m1*4,3) )
      break ;

  for(m2=0; m2<12; m2++)
    if( !strncmp(rfcdate+offset,month+m2*4,3) )
      break ;

  if( m1>=12 || m2>=12 )
    return(32767) ;

  days+=(m1-m2)*30 ;

  offset=5 ;
  days+=(atoi(now+offset)-atoi(rfcdate+offset)) ;

  if( days>32767 )	/* for integer range */
    days=32767 ;

/*
  printf("now=%s\nlast=%s  idle=%d\n",now,rfcdate,days) ;
  getchar() ;
*/
  return(days) ;

}

main(argc,argv)
int argc ;
char *argv[] ;
{
	struct udb rec ;
	int utf ;
	int recno=0 ;
	int maxno, h, i ;
	int user_id=30 ;
	int level=40, max_day=0 ;
	char filename[128] ;
	char rfc[80], *ptr ;

	if( argc<3 )
	{
	  printf("\r\nsyntax:\n\n  %s <max_days> <hold_level> -d\r\n\n", argv[0]) ;
	  exit(0) ;
	}

	if( (max_day=atoi(argv[1]))<1 )
	{
	  printf("\r\nMax_days error. should be between 1 to 32767.\r\n") ;
	  exit(1) ;
	}
	
	if( (level=atoi(argv[2]))<1 )
	{
	  printf("\r\nLevel error. should be between 1 to 32767.\r\n") ;
	  exit(1) ;
	}

	if( argc>3 )
	  if( !strcmp(argv[3], "-d") )
	    debug_mode=TRUE;

	chdir(SYSTEM_PATH) ;

	sprintf(filename, "%s.dbf", USER_DATA_BASE) ;
	if((maxno=flength(filename)/sizeof(struct udb))<=0)
	{
	  printf("\r\n\nNo user data base here!!\r\n") ;
	  exit(1) ;
	}
	
	if( (utf=open(filename, O_RDWR)) <= 0 )
		exit(1) ;
   	
   	/*/\/\/\/\/\/\/\/\/\/\/\/\/\*/
	for(recno=1; recno<=maxno; recno++)
 	{
	       lseek(utf, recno*sizeof(struct udb), SEEK_SET) ;
	       read(utf,&rec,sizeof(struct udb)) ;
	       if( (!isupper(*rec.last_login)) && rec.level<level )
	       {
  		 rec.delete_mark='X' ;

		 if( debug_mode )
		   printf(" %4d: %s  <----\n",recno,rec.last_login) ;

  	         lseek(utf, recno*sizeof(struct udb), SEEK_SET) ;
	         write(utf,&rec,sizeof(struct udb)) ;
	       }
	       else
	         if( idle_days(rec.last_login)>max_day && rec.level<level )
	 	 { 
  	           rec.delete_mark='X' ;

		   if( debug_mode )
		     printf(" %4d: %s\n",recno,rec.last_login) ;

  	       	   lseek(utf, recno*sizeof(struct udb), SEEK_SET) ;
	       	   write(utf,&rec,sizeof(struct udb)) ;
		 }
	
	}

	close(utf);
	exit(0) ;
}
