/**************************************************************************
	PBBS EMail Parser by Samson Chen
	V1.0 Mar 29 ,1995
 **************************************************************************/

#include <varargs.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include "../host/pbbs.h"
#include "../host/dbf.h"

static char rcsid[]="$Id: pbbsmailer.c,v 1.5 1995/11/01 14:58:36 pbbs Exp pbbs $";

/*local constant*/
#define	FROM		1
#define	RETURN_PATH	2
#define	SUBJECT		3
#define	MID		4
#define	DATE		5
#define	REPLY_TO	6
#define	UNDEFINED	7



/*
	do logging --- (as the name)
*/
do_log(loglevel, logformat, va_alist)
	int loglevel;
	char *logformat;
	va_dcl
{
	char timing[50];
	char buffer[620];
	char logmsg[600];
	FILE *logfile;

	/*get arguments list*/
	va_list args;
	va_start(args);
	vsprintf(logmsg, logformat, args);
	va_end(args);

	get_daytime(timing);
	sprintf(buffer, "%s,%d> ", timing, loglevel);

	strcat(buffer, logmsg);

	if(loglevel>=LOGLEVEL)
	{
		logfile = fopen(LOGFILE, "a+");
		fprintf(logfile, "%s\n", buffer);
		fclose(logfile);
	}
}
/*end of do_log*/



/*
	get day and time
*/
get_daytime(buffer)
	char *buffer;	/*CAUTION: buffer must has it's own space befor
				   calling*/
{
	struct	tm	*timeptr;
	time_t		secsnow;

	time(&secsnow);
	timeptr = localtime(&secsnow);

	sprintf(buffer, "%#02d/%#02d,%#02d:%#02d", timeptr->tm_mon+1, timeptr->tm_mday , timeptr->tm_hour, timeptr->tm_min);
}
/*end of daytime*/



/**************************************************************************/
main(argc, argv)
	int argc;
	char *argv[];
{
	char ch, bigbuf[MAX_BUF], *p;
	int c, buf_cnt;
	char huge_msg;
	char from[256], rpath[256], subject[256], mid[256];
	char date[256], replyto[256];
	int msgbody;
	char argv1[50], bbs_name[20];
	int n;
	unsigned int mbox_to_uid;
	char mfile[80], rfile[80];
	int test, msgfile, recfile;
	struct msgrec mr;
	char buf[256];
	char find_d, od=0xd;
	long outcnt;

	/*change system path*/
	chdir(SYSTEM_PATH);

	/*set running user id*/
	change_run_id();

	/*get remote mail*/
	bigbuf[0]=0;
	buf_cnt=0;
	huge_msg=FALSE;

	while((c=getchar())!=EOF)
	{
		ch=c;
		bigbuf[buf_cnt++]=ch;

		/*control msg size*/
		if( buf_cnt >= (MAX_BUF-1024) )
		{
			buf_cnt -= 1024;
			huge_msg=TRUE;
		}
	}
	bigbuf[buf_cnt]=0;

	if( !get_msg_head(bigbuf, from, rpath, subject, mid, date, replyto, &msgbody) )
	{
	  /*msg head format error, output to mail-daemon*/
	  printf("Message Format Error!!! From: and Date: cannot be empty\n");
	  return(11);
	}

	if( huge_msg )
		do_log(7, "get huge email from: %s", from);

	/*----------------------------------------------------------------*/
	/*get bbs name*/
	nstrcpy(argv1, argv[1], 50);
	argv1[ strlen(argv1)-5 ] = 0;		/*strip .pbbs*/
	nstrcpy(bbs_name, argv1, 20);

	for(n=0; n<strlen(bbs_name); n++)	/*find underline _ */
	  if( bbs_name[n]=='_' )
	  {
		bbs_name[n]=' ';
		break;
	  }

	bbs_name[0]=toupper(bbs_name[0]) ;
	for(n=1; n<strlen(bbs_name); n++)
	{
		if(bbs_name[n]==32)
		{
			n++ ;
			bbs_name[n]=toupper(bbs_name[n]) ;
		}
		else
		{  
			bbs_name[n]=tolower(bbs_name[n]) ;
		}  
	}

	/*----------------------------------------------------------------*/
	/*search for the user*/
	mbox_to_uid=get_user_id(bbs_name);
	if(mbox_to_uid==0)
	{
		/*rcpt user not found*/
		printf("PBBS user known: <%s> ???\n", bbs_name);
		return(10);
	}

	/*----------------------------------------------------------------*/
	/*put it to mbox*/
	sprintf(mfile, "%s/mbox/%d.messages", MAIL_PATH, mbox_to_uid);
	sprintf(rfile, "%s/mbox/%d.records", MAIL_PATH, mbox_to_uid);

	/*----------------------------------------------------------------*/
	/*test files*/
	if( !file_exist(mfile) )
	{
		test=open( mfile, O_WRONLY | O_APPEND | O_CREAT, S_IWUSR | S_IRUSR);
		if( test<0 )
		{
			do_log(9, "PBBSMAILER: %s open error!?", mfile);
			printf("Sorry, PBBS mbox file open error!!!\n");
			exit(12);
		}
		else
			close(test);
	}

	if( !file_exist(rfile) )
	{
		test=open( rfile, O_WRONLY | O_APPEND | O_CREAT, S_IWUSR | S_IRUSR);
		if( test<0 )
		{
			do_log(9, "PBBSMAILER: %s open error!?", rfile);
			printf("Sorry, PBBS mbox file open error!!!\n");
			exit(12);
		}
		else
			close(test);
	}

	msgfile=open(mfile, O_WRONLY | O_APPEND);
	if( msgfile<0 )
	{
		do_log(9, "PBBSMAILER: %s open error!?", mfile);
		printf("Sorry, PBBS mbox file open error!!!\n");
		exit(12);
	}

	recfile=open(rfile, O_WRONLY | O_APPEND);
        if( recfile<0 )
        {
                do_log(9, "PBBSMAILER: %s open error!?", rfile);
		printf("Sorry, PBBS mbox file open error!!!\n");
		exit(12);
        }

	/*----------------------------------------------------------------*/
	/*put it*/
	flock(msgfile, LOCK_EX);	/*exclusive lock*/
	flock(recfile, LOCK_EX);	/*exclusive lock*/

	lseek(msgfile, 0, SEEK_END);
	mr.offset=file_length(msgfile);
	nstrcpy(mr.subject, subject, 60);
	mr.packed=' ';
	mr.delete_mark=' ';

	memset(buf, 0, 255);
	sprintf(buf, "Path: %%SENDMAIL%%%c%c", 13, 10);
		write(msgfile, buf, strlen(buf) );

	memset(buf, 0, 255);
	sprintf(buf, "From: %s%c%c", from, 13, 10);
		write(msgfile, buf, strlen(buf) );

	memset(buf, 0, 255);
	sprintf(buf, "Subject: %s%c%c", subject, 13, 10);
		write(msgfile, buf, strlen(buf) );

	memset(buf, 0, 255);
	sprintf(buf, "Message-ID: %s%c%c", mid, 13, 10);
		write(msgfile, buf, strlen(buf) );

	memset(buf, 0, 255);
	sprintf(buf, "Date: %s%c%c", date, 13, 10);
		write(msgfile, buf, strlen(buf) );

	memset(buf, 0, 255);
	sprintf(buf, "Organization: PBBS Electric Mail Gateway%c%c", 13, 10);
		write(msgfile, buf, strlen(buf) );

	if( replyto[0]!=0 )
	{
		memset(buf, 0, 255);
		sprintf(buf, "Reply-To: %s%c%c", replyto, 13, 10);
			write(msgfile, buf, strlen(buf) );
	}

	memset(buf, 0, 255);
	sprintf(buf, "%c%c", 13, 10);
	write(msgfile, buf, 2);

	p=bigbuf;
	p+=msgbody;	/*strip EMAIL head*/

	/* output msgtxt with CR-LF */
	find_d=FALSE;
	for(outcnt=0; outcnt<strlen(p); outcnt++)
	{
	  if( p[outcnt]==0xd )
	  {
	    find_d=TRUE;
	    break;
	  }
	}

	if( find_d )
	  write(msgfile, p, strlen(p) );
	else
	{
	  for(outcnt=0; outcnt<strlen(p); outcnt++)
	  {
	    if( p[outcnt]==0xa )
		write(msgfile, &od, 1);

	    write(msgfile, p+outcnt, 1);
	  }
	}

	lseek(msgfile, 0, SEEK_END);
	mr.length=file_length(msgfile)-mr.offset;
	
	write(recfile, &mr, sizeof(mr) );

	flock(msgfile, LOCK_UN);	/*unlock*/
	flock(recfile, LOCK_UN);	/*unlock*/

	do_log(6, "PBBSMAILER: %s send an email to %s, mid is %s", from, bbs_name, mid);

	close(msgfile);
	close(recfile);

	/*----------------------------------------------------------------*/
	/*set mbox quote*/
	set_mail_quote(mbox_to_uid, 'Y');


	/*----------------------------------------------------------------*/
	/*seems ok, tell sendmail*/
	return(0);
}
/**************************************************************************/



/*
	get msg head information
*/
get_msg_head(msg, from, rpath, subject, mid, date, replyto, mbody)
	char *msg;	/*the msg body*/
	char *from;
	char *rpath;
	char *subject;
	char *mid;
	char *date;
	char *replyto;
	int *mbody;	/*the msg body*/
/*
	RETURN: TRUE: parsing good
		FALSE: msg head format error (EMPTY!)
*/
{
	char line[1024];
	int mlen, cnt;
	int n;

	/*var initialization*/
	from[0]=0;
	rpath[0]=0;
	subject[0]=0;
	mid[0]=0;
	date[0]=0;
	replyto[0]=0;

	cnt=0;
	mlen=strlen(msg);

	while( cnt<mlen )
	{

	  n=0;
	  line[n]=0;

	  while( (msg[cnt]!=0xa) && (cnt<mlen) )
	  {
	    if( msg[cnt] != 0xd )	/*ignore 0xd*/
		line[n]=msg[cnt];
	    n++;
	    cnt++;
	  }

	  line[n]=0;
	  cnt++;

	  if( strlen(line)<3 )	/*end of msg head*/
		break;

	  /*parse head*/
	  switch( parse_field(line) )
	  {
	  case FROM:
		nstrcpy(from, line+6, 256);
		break;

	  case RETURN_PATH:
		nstrcpy(rpath, line+13, 256);
		break;

	  case SUBJECT:
		nstrcpy(subject, line+9, 256);
		break;

	  case MID:
		nstrcpy(mid, line+12, 256);
		break;

	  case DATE:
		nstrcpy(date, line+6, 256);
		break;

	  case REPLY_TO:
		nstrcpy(replyto, line+10, 256);
		break;
	  }
	}

	*mbody=cnt;

	if( (replyto[0]==0) && (rpath[0]!=0) )
		strcpy(replyto, rpath);		/*use Return-Path:*/

	/*generate blank fields*/
	if( subject[0]==0 )
		strcpy(subject, "<Blank>");

	if( mid[0]==0 )
		strcpy(mid, "<BLANK>");

	if( (from[0]==0) || (date[0]==0) )
			/*bad format*/
		return(FALSE);

	return(TRUE);	/*ok*/
}
/*end of get_msg_head*/



/*
	parse_field --- parsing mail head
*/
parse_field(mh)
	char *mh;
{
	if( !strncmp(mh, "From: ", 6) )
		return(FROM);

	if( !strncmp(mh, "Return-Path: ", 13) )
		return(RETURN_PATH);

	if( !strncmp(mh, "Subject: ", 9) )
		return(SUBJECT);

	if( !strncmp(mh, "Message-Id: ", 12) )
		return(MID);

	if( !strncmp(mh, "Date: ", 6) )
		return(DATE);

	if( !strncmp(mh, "Reply-To: ", 10) )
		return(REPLY_TO);

	return(UNDEFINED);    
}
/*end of parse_field*/



/*
	change_run_id --- change process running id
*/
change_run_id()
{
	int user_id, group_id;

	if( !strcmp(RUN_USER, "OWNER") || !strcmp(RUN_GROUP, "OWNER") )
		return;

	user_id=getuidbyname(RUN_USER);
	group_id=getgidbyname(RUN_GROUP);

	if( user_id<0 || group_id<0 )
		return;

	/*set log file permission first*/
	if( file_exist(LOGFILE) )
		chown(LOGFILE, (uid_t) user_id, (gid_t) group_id);

	/*set gid then uid*/
	if( setgid((gid_t) group_id)==-1 )
		do_log(9, "PBBSMAILER: set gid failed!?");

	if( setuid((uid_t) user_id)==-1 )
		do_log(9, "PBBSMAILER: set uid failed!?");
}
/*end of change_run_id*/



/*
	nstrcpy --- some stange STRING hate strcpy... also size control is
		    needed
*/
nstrcpy(t, s, ms)
	char *t;	/*target*/
	char *s;	/*source*/
	int ms;		/*max size*/
{
	int cpn;

	for(cpn=0; cpn<ms; cpn++)
	{
		t[cpn]=s[cpn];

		if(s[cpn]==0)
			break;
	}

	t[ms-1]=0;
}
/*end of nstrcpy*/



/*
	get_user_id --- get user id from user database
*/
get_user_id(name)
	char *name;	/*bbs_name not real name*/
/*
	return:
		user id number
		note: uid >= 1, because 0 means user not found
*/
{
	char udbfile[255];
	int udbf;
	int ret;


	/*test user database file*/
	sprintf(udbfile, "%s.dbf", USER_DATA_BASE);

	if( !file_exist(udbfile) )
		return(0);	/*no such user*/

	/*index search*/
	ret=found(name);
	if(ret==FALSE) return(0);

	return(ret);
}
/*end of get_user_id*/



/*
	file_length --- return file size of fd
*/
long file_length(fd)
        int fd;
{
        struct stat buf;
        fstat(fd, &buf);
        return(buf.st_size);
}
/*end of file_length*/



/*
	set_mail_quote --- set mail quote to user #uid to notify new mbox mail
*/
set_mail_quote(uid, quote)
	int uid;
	char quote;	/*'Y;' or ' '*/
{
        char udbfile[255];
        int udbf;
        struct udb record;

        sprintf(udbfile, "%s.dbf", USER_DATA_BASE);
        udbf = open(udbfile, O_RDWR);
	lseek( udbf, uid*sizeof(struct udb), SEEK_SET);

	read(udbf, &record, sizeof(struct udb));

	record.mailbox=quote;

	lseek( udbf, uid*sizeof(struct udb), SEEK_SET);
	write(udbf, &record, sizeof(struct udb));

	close(udbf);
}
/*end of set_mail_quote*/



/*
	test if the file exist or not
*/
file_exist(filename)
char *filename;
/*
	return: TRUE: exist
		FALSE: not exist
*/
{
	FILE *testexist;

	if( (testexist=fopen(filename, "r")) == NULL)
		return(FALSE);		/*not found*/
	else	/*file found*/
	{
		fclose(testexist);
		return(TRUE);
	}
}
/*end of file_exist*/



/*
	flength --- get length of a file
*/
long flength(filename)
	char *filename;
{
	int test;
        struct stat buf;

        test=open(filename, O_RDONLY);
        fstat(test, &buf);
	close(test);

        return(buf.st_size);
}
/*end of flength*/



/*
	getuidbyname --- get system uid by RUN_USER
*/
getuidbyname(name)
	char *name;
{
	struct passwd *ent;

	if( name[0]=='#' )
		return(atoi(name+1));

	ent=getpwnam(name);

	if( !ent )
	{
		do_log(9, "PBBSMAILER: BAD RUN_USER '%s' setup!", RUN_USER);
		return(-1);
	}
	else
		return(ent->pw_uid);

}
/*end of getuidbyname*/



/*
	getgidbyname --- get system group id by RUN_GROUP
*/
getgidbyname(name)
	char *name;
{
	struct group *ent;

	if( name[0]=='#' )
		return(atoi(name+1));

	ent=getgrnam(name);

	if( !ent )
	{
		do_log(9, "PBBSMAILER: BAD RUN_GROUP '%s' setup!", RUN_GROUP);
		return(-1);
	}
	else
		return(ent->gr_gid);

}
/*end of getgidbyname*/


