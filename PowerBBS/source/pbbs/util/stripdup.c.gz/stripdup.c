/*
	remove duplicate line by Samson Chen
	Dec 11, 1995
*/
main()
{
  char line[128], last_line[128];

  last_line[0]=0;
  while(gets(line))
  {
    strip_nl(line);
    alltrim(line);
    if( strcmp(last_line, line) )
    {
      strcpy(last_line, line);
      printf("%s\n", line);
    }
  }
}
/*end of main*/



/*
	blank trim by KKY
*/
int alltrim(str)
char *str ;
/*******************************************
    return     0   : if NULL string
	    length : the new strlen.
********************************************/
{
  int i=0 ;

    while((*(str+i)==32) || (*(str+i)==9))
    {
      i++ ;
    }
    memcpy(str,(str+i),strlen(str)-i+1) ;

    i=strlen(str)-1 ;
    while(((*(str+i)==32) || (*(str+i)==9)  || (*(str+i)==10)) && (i>=0))
    {
      i-- ;
    }
    *(str+i+1)=0 ;

    return(strlen(str)) ;
}
/*end of alltrim*/



/*
	strip_nl --- strip cr-lf
*/
strip_nl(buf)
	char *buf;
{
	int n;
	int len;

	len=strlen(buf);

	for(n=0; n<len; n++)
		if( buf[n]==0 || buf[n]==13 || buf[n]==10 )
		{
			buf[n]=0;
			break;
		}
}
/*end of strip_nl*/
