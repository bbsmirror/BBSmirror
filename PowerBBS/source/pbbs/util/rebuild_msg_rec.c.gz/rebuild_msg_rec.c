/*
	Message Records ReBuilder by Samson Chen, Dec 6, 1995
	Note:
	  This program try to reconstruct messages records (records).
	  It will try to seperate messages by fields like Path:, From:...etc.
	  This program does not guarantee the seperation is correct.
*/

#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include "../setup.h"
#include "../host/dbf.h"

#ifndef	FALSE
#define	FALSE	0
#endif

#ifndef	TRUE
#define	TRUE	!FALSE
#endif


#define	FETCH_HEAD_SIZE	256
#define	BSIZE	20480

static char rcsid[]="$Id: rebuild_msg_rec.c,v 1.1 1996/03/09 19:44:23 pbbs Exp pbbs $";

long file_length();

/*.......................................................................*/
main(argc, argv)
int argc;
char *argv[];
{
  char mpath[256], area_name[128];
  int mffd, mfrec, fp;
  long msg_len, current_pos, left_size;
  int current_msg_len;
  char buffer[BSIZE];
  struct msgrec msgrec;
  char *subject_field;

  printf("PowerBBS Message Records ReConstructor by Samson Chen, Dec 6, 1995\n\n");

  if( argc!=2 )
  {
    printf("  usage: %s <area_name>\n", argv[0]);
    printf("\n");
    exit(1);
  }

  strcpy(area_name, argv[1]);
  sprintf(mpath, "%s/%s/messages", MAIL_PATH, area_name);
  if( !file_exist(mpath) )
  {
    printf("  '%s' not found!?\n", mpath);
    printf("\n");
    exit(2);
  }

  back_up_err_msg(area_name);	/*backup records*/

  mffd=open(mpath, O_RDONLY);
  if( mffd<=0 )
  {
    printf(" open '%s' error!?\n", mpath);
    printf("\n");
    exit(3);
  }

  sprintf(mpath, "%s/%s/records", MAIL_PATH, area_name);
  mfrec=open(mpath, O_WRONLY|O_CREAT|O_TRUNC, S_IWUSR|S_IRUSR);
  if( mfrec<=0 )
  {
    printf(" open '%s' error!?\n", mpath);
    printf("\n");
    exit(4);
  }

  /*-------------------------------------------*/
  msg_len=file_length(mffd);
  current_pos=0;

  while(current_pos<msg_len)
  {
    lseek(mffd, current_pos, SEEK_SET);
    left_size=msg_len-current_pos;
    fetch_msg_head(mffd, (BSIZE<left_size)?BSIZE:left_size, buffer);
    msgrec.offset=current_pos;
    msgrec.packed=' ';
    msgrec.delete_mark=' ';
    fp=parse_msg(buffer, "Subject: ");
    subject_field=buffer+fp+9;
    strip_nl(subject_field);
    nstrcpy(msgrec.subject, subject_field, 60);

    current_msg_len=len_to_next_path(mffd, current_pos, buffer);
    msgrec.length=current_msg_len;
    current_pos+=current_msg_len;

    /*write to records*/
    write(mfrec, &msgrec, sizeof(struct msgrec));
    printf("%5d, %5d : %s\n", msgrec.offset, msgrec.length, msgrec.subject);
  }/*end while*/

  close(mffd);
  close(mfrec);

}
/*end of main*/
/*.......................................................................*/


/*
	remove old *.bak, rename current one to *.bak
*/
back_up_err_msg(area)
char *area;
{
  char mpath[256], source[256], target[256];

  sprintf(mpath, "%s/%s", MAIL_PATH, area);

/*
  sprintf(source, "%s/messages", mpath);
  sprintf(target, "%s/messages.bak", mpath);
  rename(source, target);
*/

  sprintf(source, "%s/records", mpath);
  sprintf(target, "%s/records.bak", mpath);
  rename(source, target);

/*
  sprintf(source, "%s/users", mpath);
  sprintf(target, "%s/users.bak", mpath);
  if( file_exist(source) )
    rename(source, target);
*/
}
/*end of back_up_err_msg*/



/*
	test if the file exist or not
*/
file_exist(filename)
char *filename;
/*
	return: TRUE: exist
		FALSE: not exist
*/
{
	FILE *testexist;

	if( (testexist=fopen(filename, "r")) == NULL)
		return(FALSE);		/*not found*/
	else	/*file found*/
	{
		fclose(testexist);
		return(TRUE);
	}
}
/*end of file_exist*/



/*
	fetch_msg_head --- fetch only message head
*/
fetch_msg_head(msgfd, max_length, buffer)
	int msgfd;	/*message file fd (must lseek before call)*/
	unsigned int max_length;	/*message total length*/
	char *buffer;
{
	int fetch_head;
	int fetch_section;
	char *fetch_pointer;
	char *check_pointer;
	char first_section=TRUE;
	int n;
	int ret;
	char ebuf[256];

	if( max_length<FETCH_HEAD_SIZE )
	{
		ret=read(msgfd, buffer, max_length);

		if( ret<0 )
		{
		  printf(" fetch_msg_head(1): msgfd reading error!\n");
		  exit(12);
		}

		buffer[ret]=0;
	}
	else
	{
		fetch_head=0;
		fetch_section=FETCH_HEAD_SIZE;
		fetch_pointer=buffer;

		do
		{
		  check_pointer=fetch_pointer;

		  ret = read(msgfd, fetch_pointer, fetch_section);

		  if( ret<0 )
		  {
		    printf(" fetch_msg_head(2): msgfd reading error!\n");
		    exit(12);
		  }

		  fetch_head += ret;
		  fetch_pointer += ret;
		  buffer[fetch_head]=0;


		  /*check if head found*/

		  if( !first_section )
		  {
			if( *(check_pointer-2)==0xd && *check_pointer==0xd )
				break;

			if( *(check_pointer-1)==0xd && *(check_pointer+1)==0xd )
				break;
		  }

		  for(n=0; n<(strlen(check_pointer)-2); n++)
		  {
			if( (check_pointer[n]==check_pointer[n+2]) && (check_pointer[n]==0xd) )
				return;
		  }


		  /*count next fetch section size*/

		  if( (max_length-fetch_head)<fetch_section )
			fetch_section=(max_length-fetch_head);

		  first_section=FALSE;

		} while( fetch_section>0 );

	}/*end if-else*/
}
/*end of fetch_msg_head*/


/*
	check head by some keywords
*/
this_is_head(buffer)
char *buffer;
{
  if( parse_msg(buffer, "Organization: ") == -1 )
    return(FALSE);
  if( parse_msg(buffer, "Date: ")	== -1 )
    return(FALSE);
  if( parse_msg(buffer, "Message-ID: ")	== -1 )
    return(FALSE);
  if( parse_msg(buffer, "Subject: ")	== -1 )
    return(FALSE);
  if( parse_msg(buffer, "From: ")	== -1 )
    return(FALSE);
  if( parse_msg(buffer, "Path: ")	== -1 )
    return(FALSE);

  return(TRUE);
}
/*end of this_is_head*/



/*
	parse message head
*/
parse_msg(msg, phead)
	char *msg;	/*original message text*/
	char *phead;	/*parsing head, if "MSG" means message body*/
/*
	return:
		position of the parsed head
		-1 means not found

	note: after parsing, the *msg will NOT be destroyed
*/
{
	char buf[1024];
	char *point;
	char head=TRUE;
	int n,p;
	int fp;

	point=msg;
	n=0;

	do
	{
	  /*find a line*/
	  for(p=n;p<strlen(msg);p++)
		if( msg[p]==13 ) break;

	  if( p>=strlen(msg) )
	  {
		return(-1);
	  }

	  /*CR-LF-CR-LF appeared, head field finished*/
	  if( n==p )
	  {
		head=FALSE;

		if( !strcmp(phead, "MSG") )
			fp=n;
		else
			fp=-1;

		continue;
	  }

	  /*cut a line*/
	  strncpy(buf, msg+n, p-n);
	  buf[p-n]=0;

	  /*parse line*/
	  if( !strncmp(buf, phead, strlen(phead) ) )
	  {
		head=FALSE;
		fp=n;
		continue;
	  }


	  n=p+2;  /*skip CR-LF*/

	}while(head);

	return(fp);
}
/*end of parse_msg*/



/*
	file_length --- return file size of fd
*/
long file_length(fd)
	int fd;
{
	struct stat buf;
	fstat(fd, &buf);
	return(buf.st_size);
}
/*end of file_length*/



/*
	strip_nl --- strip cr-lf
*/
strip_nl(buf)
	char *buf;
{
	int n;
	int len;

	len=strlen(buf);

	for(n=0; n<len; n++)
		if( buf[n]==0 || buf[n]==13 || buf[n]==10 )
		{
			buf[n]=0;
			break;
		}
}
/*end of strip_nl*/



/*
	nstrcpy --- some stange STRING hate strcpy... also size control is
		    needed
*/
nstrcpy(t, s, ms)
	char *t;	/*target*/
	char *s;	/*source*/
	int ms; 	/*max size*/
{
	int cpn;

	for(cpn=0; cpn<ms; cpn++)
	{
		t[cpn]=s[cpn];

		if(s[cpn]==0)
			break;
	}

	t[ms-1]=0;
}
/*end of nstrcpy*/



/*
	find message length by two Path: keywords
*/
len_to_next_path(mffd, current_pos, buffer)
int mffd;
long current_pos;
char *buffer;	/*just share buffer*/
{
  long total_len, org_pos, cpos, left_size;
  int ret, msg_len;

  org_pos=current_pos;
  total_len=file_length(mffd);
  msg_len=total_len-current_pos;	/*presume length*/
  cpos=current_pos+1;

  while(cpos<total_len)
  {
    lseek(mffd, cpos, SEEK_SET);
    ret=read(mffd, buffer, 6);
    if( ret<6 ) break;
    if( !strncmp(buffer, "Path: ", 6) )
    {
      lseek(mffd, cpos, SEEK_SET);
      left_size=total_len-cpos;
      fetch_msg_head(mffd, (BSIZE<left_size)?BSIZE:left_size, buffer);
      if( this_is_head(buffer) )
      {
	msg_len=cpos-org_pos;
	break;
      }
    }
    cpos++;
  }

  return(msg_len);
}
/*end of len_to_next_path*/
