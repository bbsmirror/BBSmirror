/********************************
    modify user data base
    write by Aquarisu Kuo
    May 4, 1994
**********************************/
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <time.h>

#if !defined(NEXTSTEP) && !defined(NOMALLOC)
#include <malloc.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>

#include "../host/dbf.h"
#include "../setup.h"

/*
	flength --- get length of a file
*/
flength(filename)
	char *filename;
{
	int test;
	unsigned long len;
	
        test=open(filename, O_RDONLY);
        lseek(test, 0, SEEK_END);
       	len = tell(test);
	close(test);

	return(len);
}
/*end of flength*/



/*
	get day and time
*/
get_daytime(buffer)
	char *buffer;	/*CAUTION: buffer must has it's own space befor
				   calling*/
{
	struct	tm	*timeptr;
	time_t		secsnow;

	time(&secsnow);
	timeptr = localtime(&secsnow);

	sprintf(buffer, "%#02d/%#02d,%#02d:%#02d", timeptr->tm_mon+1, timeptr->tm_mday , timeptr->tm_hour, timeptr->tm_min);
}
/*end of daytime*/



#if defined(NETBSD) || defined(TELL)
/*
	NetBSD does not support tell() function, use fstat as alternative one
*/
tell(fd)
        int fd;
{
        struct stat buf;
        fstat(fd, &buf);
        return(buf.st_size);
}
#endif

/***********************************
  reindex user database
*/
main(argc, argv)
int argc;
char *argv[];
{
  int utf, i, t_mode ;
  struct udb rec ;
  long maxno ;
  char filename[100] ;
  char top20name[20][25], usrname[25], daytime[50];
  int top20val[20], uval, idx, idx2;

  if( argc!=2 )
  {
    printf(" top20 <mode>\n");
    printf("    <mode> :	l -> login times\n");
    printf("		p -> posts\n");
    exit(1);
  }

  if( argv[1][0]=='p' )
    t_mode=1;	/*mode p*/
  else
    t_mode=0;	/*mode l*/

  chdir(SYSTEM_PATH);	/*change to pbbs system path which set at setup.h*/

  sprintf(filename, "%s.dbf", USER_DATA_BASE) ;
  if((maxno=flength(filename)/sizeof(struct udb))<=0)
  {
    printf("\r\n\nNo user index here!!\r\n") ;
    exit(1) ;
  }
        
  if( (utf=open(filename, O_RDONLY)) <= 0 )
    exit(1) ;

  /*reset*/
  for(idx=0; idx<20; idx++)
    top20val[idx]=0;
        
  i=0;
  while(i<maxno)
  {
    i++;
    lseek(utf,i*sizeof(struct udb), SEEK_SET) ;
    read(utf,&rec,sizeof(struct udb)) ;
          
    if(rec.delete_mark!='X')
    {
      if( rec.level==SYSOP_LEVEL )
	continue;

      strcpy(usrname, rec.bbs_name);
      if( t_mode==0 )
	uval=rec.total_login;
      else
	uval=rec.total_post;

      idx=19;
      do
      {
	if( top20val[idx]>uval )
	  break;
	idx--;
      }
      while(idx>=0);

      if( idx<19 )
      {
	idx2=18;
	while(idx2>idx)
	{
	  strcpy(top20name[idx2+1], top20name[idx2]);
	  top20val[idx2+1]=top20val[idx2];
	  idx2--;
	}
	idx2=idx+1;
	strcpy(top20name[idx2], usrname);
	top20val[idx2]=uval;
      }

    }

  }
  close(utf) ;

  get_daytime(daytime);

  if( t_mode==0 )
  {
    printf("�ƦW  User ID		   �`�W�u����   �έp�ɶ�: %s\n", daytime);
    printf("---------------------------------------------(�W�u���ƱƦ�])\n");
  }
  else
  {
    printf("�ƦW  User ID		   �`�o�H����   �έp�ɶ�: %s\n", daytime);
    printf("---------------------------------------------(�o�H�ʼƱƦ�])\n");
  }

  for(idx=0; idx<20; idx++)
  {
    strcpy(usrname, top20name[idx]);
    uval=top20val[idx];
    printf("%2d    %-20s %d\n", idx+1, usrname, uval);
  }
    printf("---------------------------------------------(�������C�J�έp)\n");
                
  exit(0) ;
}
/*end of main*/
