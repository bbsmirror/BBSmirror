/*--- Prompt the screen ---*/          
extern char SENDER[30] ;
extern char POST_DATE[30] ;
extern char POST_SUBJECT[30] ;
extern char POST_NUM[30] ;
extern char POST_AREA[40] ;

extern char POST_REPLY[30] ;
extern char POST_ORGAN[60] ;
extern char POST_BOTTOM[80] ;   /* prompt post bottom */

extern char MORE[80] ;          /* prompt more on show() */
extern char PRESSANYKEY[80] ;   
extern char POST_MORE[100] ;    /* prompt more on post function */
extern char EDITCONFIRM[80] ;   

extern char FILEEXIST[80] ;     /* download file exist */
extern char UFILENAME[80] ;     /* upload file exist */
extern char FNOTFOUND[80] ;     /* file not found */
extern char FDISABLE[80] ;      /* disk function disable */
extern char ASKFILENAME[80] ;   /* use file to post,  prompt */

extern char SELECTMSG[80] ;     /* post list prompt */

extern char CAPTUREFILE[80] ;	/* prompt capture filename */
extern char SCANOFIND[80] ;	/* prompt search text not found */
extern char DOWNPATH[80] ;	/* prompt ask download path */

extern int term_mode ;
extern int SCR_ROWS ;
extern int SCR_COLS ;

/*prototype*/
char *ltostr();
