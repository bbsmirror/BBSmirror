#include "pbbs.h"

static char rcsid[]="$Id: writmail.c,v 1.7 1994/05/18 23:27:54 cs79026 Exp samson $" ;

int writer(buffer,editor) 
char *buffer ;
char *editor ;
{
  char fname[80],
       tmpbuf[101] ; 
  int status ;
  FILE *fp ;
  
  struct stat f1, f2 ;
    
  strcpy(tmpbuf,tmpnam(NULL)) ;
 
  if((fp=fopen(tmpbuf,"w"))==NULL)
  {
    show("\nFile open error!!\n") ;
    readkey() ;
    return(FALSE) ;
  }
  fwrite(buffer,strlen(buffer),1,fp) ;
  fclose(fp) ;  
  
  stat(tmpbuf,&f1) ;
  
  sprintf(fname,"%s %s",editor,tmpbuf) ;
  
  if((status=system(fname))<0)
  {
    show("\nCall editor error...!!\n") ;
    readkey() ;
    return(FALSE) ;
  }  
  else
  {
    stat(tmpbuf,&f2) ;
    
    if(f1.st_mtime==f2.st_mtime)
    {
      unlink(tmpbuf) ;
      return(FALSE) ;
    }
    strcpy(fname,strchr(fname,' ')+1) ;
    if((fp=fopen(fname,"rt"))==NULL)
    {
      show("\nfopen temp-file error!!\n") ;
      readkey() ;
      unlink(fname) ;
      return(FALSE) ;
    }
    else
    {
      buffer[0]=0 ;
      while(fgets(tmpbuf,100,fp)!=NULL)
      {
        tmpbuf[99]=0 ;
        if((strlen(buffer)+strlen(tmpbuf)+1024)<MAX_BUF)
        {
          strcat(buffer,tmpbuf) ;
          if(strlen(buffer)>MAX_MAIL_INPUT)
            break ;
        }
        else
          break ;  
      }
      buffer[strlen(buffer)]=0 ;
      fclose(fp) ;
      unlink(fname) ;
    }
  }
  return(TRUE) ;    
}
