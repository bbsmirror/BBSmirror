/****************************************
  Phrase the prompt string from buffer.
  
  Write by Aqaurius Kuo.
  Apr 2, 1994.
*****************************************/
#include <string.h>
#include "pbbs.h"
#include "msg.h"

#define PATH            1
#define FROM            2
#define NEWSGROUP       3
#define SUBJECT         4
#define MID             5
#define DATE            6
#define ORGANIZATION    7
#define REPLY_TO        8

#define PAREA           11
#define PTOTAL          12
#define PNUM            13
#define PROMPT_SENDER   14
#define PROMPT_DATE     15
#define PROMPT_SUBJECT  16
#define PROMPT_AREA     17
#define PROMPT_NUM      18
#define PROMPT_REPLY    19
#define PROMPT_ORGAN    20

#define PROMPT_MORE     21
#define PROMPT_PRESSKEY 22
#define PROMPT_POSTMORE 23

#define PROMPT_EDITCONFIRM      24
#define PROMPT_POSTBOTTOM       25
#define PROMPT_FILEEXIST        30
#define PROMPT_UFILENAME        31
#define PROMPT_FNOTFOUND        32
#define PROMPT_FDISABLE         33

#define PROMPT_INTERREAD        34
#define PROMPT_ASKFILENAME      35

#define PROMPT_CAPFILE		36

#define PROMPT_SCANNOFIND	37
#define PROMPT_DOWNPATH		38

#define UNDEFINED       100

char *kkytok() ;

/*
        parse_field --- parse message field (NNRP & PROMPT)
*/
parse_field(mh)
/*
  return: post number
*/  
char *mh;
{
	
	if( !strncmp(mh, "CPScanNoFind: ",14) )
                 return(PROMPT_SCANNOFIND) ;

	if( !strncmp(mh, "CPDownPath: ",12) )
                 return(PROMPT_DOWNPATH) ;

	if( !strncmp(mh, "CPCapfile: ",11) )
                 return(PROMPT_CAPFILE) ;

        if( !strncmp(mh, "CPFilepost: ",12) )
                 return(PROMPT_ASKFILENAME) ;

        if( !strncmp(mh, "CPInterread: ",13) )
                 return(PROMPT_INTERREAD) ;
        
        if( !strncmp(mh, "CPNotfound: ",12) )
                 return(PROMPT_FNOTFOUND) ;
        
        if( !strncmp(mh, "CPUfilename: ",13) )
                 return(PROMPT_UFILENAME) ;
        
        if( !strncmp(mh, "CPFdisable: ",12) )
                 return(PROMPT_FDISABLE) ;

        if( !strncmp(mh, "CPFileexist: ",13) )
                 return(PROMPT_FILEEXIST) ;
                 
        if( !strncmp(mh, "Area: ", 6) )
                 return(PAREA) ;

        if( !strncmp(mh, "Total: ", 7) )
                 return(PTOTAL) ;

        if( !strncmp(mh, "Msgno: ", 7) )
                 return(PNUM) ;

        if( !strncmp(mh, "CPMore: ", 8) )
                 return(PROMPT_MORE) ;
        
        if( !strncmp(mh, "CPPostmore: ", 12) )
                 return(PROMPT_POSTMORE) ;

        if( !strncmp(mh, "CPPresskey: ", 12) )
                 return(PROMPT_PRESSKEY) ;
        
        if( !strncmp(mh, "CPEditconfirm: ", 15) )
                 return(PROMPT_EDITCONFIRM) ;

        if( !strncmp(mh, "CPPostbottom: ", 14) )
                 return(PROMPT_POSTBOTTOM) ;

        if( !strncmp(mh, "CPSender: ", 10) )
                 return(PROMPT_SENDER) ;

        if( !strncmp(mh, "CPPostdate: ", 12) )
                 return(PROMPT_DATE) ;

        if( !strncmp(mh, "CPPostsubject: ", 15) )
                 return(PROMPT_SUBJECT) ;

        if( !strncmp(mh, "CPPostarea: ", 12) )
                 return(PROMPT_AREA) ;

        if( !strncmp(mh, "CPPostno: ", 10) )
                 return(PROMPT_NUM) ;

        if( !strncmp(mh, "CPPostreply: ", 13) )
                 return(PROMPT_REPLY) ;

        if( !strncmp(mh, "CPPostorgan: ", 13) )
                 return(PROMPT_ORGAN) ;
                 
/*--- next if parse for RFC mail system standard ---*/ 
      
        if( !strncmp(mh, "Path: ", 6) )
                 return(PATH);

        if( !strncmp(mh, "From: ", 6) )
                return(FROM);

        if( !strncmp(mh, "Newsgroups: ", 12) )
                return(NEWSGROUP);

        if( !strncmp(mh, "Subject: ", 9) )
                return(SUBJECT);

        if( !strncmp(mh, "Message-ID: ", 12) )
                return(MID);

        if( !strncmp(mh, "Date: ", 6) )
                return(DATE);

        if( !strncmp(mh, "Organization: ", 14) )
                return(ORGANIZATION);

        if( !strncmp(mh, "Reply-To: ", 10) )
                return(REPLY_TO);

        return(UNDEFINED);
}
/*end of parse_field*/

int parse_prompt(buffer)
char *buffer ;
{
  char tmp[4] ;
  char *here, *ptr ;
  int ret, len ;

  ret=TRUE ;
  len=strlen(buffer) ;
  here=buffer ;
  sprintf(tmp,"%c%c",13,10) ;
  do
  {
    ptr=strstr(here,tmp) ;
    if(ptr==NULL)
    {
      ret=FALSE ;
      break ;
    }

    *ptr=0 ;
    switch(parse_field(here))
    {
      case PROMPT_SCANNOFIND:
        here+=11 ;
        strcpy(SCANOFIND,here) ;
        break ;
      case PROMPT_DOWNPATH:
        here+=11 ;
        strcpy(DOWNPATH,here) ;
        break ;
      case PROMPT_CAPFILE:
        here+=11 ;
        strcpy(CAPTUREFILE,here) ;
        break ;
      case PROMPT_ASKFILENAME:
        here+=12 ;
        strcpy(ASKFILENAME,here) ;
        break ;
      case PROMPT_INTERREAD:
        here+=13 ;
        strcpy(SELECTMSG,here) ;
        break ;
      case PROMPT_FDISABLE:
        here+=12 ;
        strcpy(FDISABLE,here) ;
        break ;
      case PROMPT_FNOTFOUND:
        here+=12 ;
        strcpy(FNOTFOUND,here) ;
        break ;
      case PROMPT_UFILENAME:
        here+=13 ;
        strcpy(UFILENAME,here) ;
        break ;
      case PROMPT_MORE:
        here+=8 ;
        strcpy(MORE,here) ;
        break ;
      case PROMPT_POSTMORE:
        here+=12 ;
        strcpy(POST_MORE,here) ;
        break ;  
      case PROMPT_PRESSKEY:
        here+=12 ;
        strcpy(PRESSANYKEY,here) ;
        break ;
      case PROMPT_EDITCONFIRM:
        here+=15 ;
        strcpy(EDITCONFIRM,here) ;
        break ;
      case PROMPT_FILEEXIST:
        here+=13 ;
        strcpy(FILEEXIST,here) ;
        break ;  
      case PROMPT_POSTBOTTOM:
        here+=14 ;
        strcpy(POST_BOTTOM,here) ;
        break ;

      case PROMPT_SENDER:
        here+=10 ;
        strcpy(SENDER,here) ;
        break ;
      case PROMPT_DATE:
        here+=12 ;
        strcpy(POST_DATE,here) ;
        break ;
      case PROMPT_SUBJECT:
        here+=15 ;
        strcpy(POST_SUBJECT,here) ;
        break ;
      case PROMPT_AREA:
        here+=12 ;
        strcpy(POST_AREA,here) ;
        break ;
      case PROMPT_NUM:
        here+=10 ;
        strcpy(POST_NUM,here) ;
        break ;
      case PROMPT_REPLY:
        here+=13 ;
        strcpy(POST_REPLY,here) ;
        break ;
      case PROMPT_ORGAN:
        here+=13 ;
        strcpy(POST_ORGAN,here) ;
        break ;
      default:
        ret=FALSE ;
    }
    here=ptr+2 ;
    if(here>=(buffer+len))
      break ;
  }
  while(ret==TRUE) ;
}
/* end parse_prompt */


int parse_header(buffer,header)
/*
   if phrase ok then
     return post number, buffer is body, header is mail-header
   else
     return FALSE, not define buffer and header.
*/
char *buffer ;
char *header ;
{
  char tmp[4],par[100] ;
  char *here, *ptr, *token ;
  char area[100], tota[100], msgn[100] ;
  char from[100], subj[100], date[100], orga[100], rept[100] ;
  int ret, len, pnum ;

  ret=TRUE ;
  len=strlen(buffer) ;
  area[0]=tota[0]=msgn[0]=from[0]=subj[0]=date[0]=orga[0]=rept[0]=0 ;
  here=buffer ;
  sprintf(tmp,"%c%c",13,10) ;
  do
  {
    ptr=strstr(here,tmp) ;
    if(ptr==NULL)
    {
      ret=FALSE ;
      break ;
    }

    *ptr=0 ;
    switch(parse_field(here))
    {
      case PAREA:
        here+=6 ;
        strcpy(area,here) ;
        while(strlen(area)<25)
          strcat(area," ") ;
        break ;
      case PTOTAL:
        here+=7 ;
        strcpy(tota,here) ;
        break ;
      case PNUM:
        here+=7 ;
        strcpy(msgn,here) ;
        pnum=atoi(msgn) ;
        break ;
      case PATH:
        here+=6 ;
        break ;
      case FROM:
        here+=6 ;
        strncpy(par,here,99) ;
        par[99]=0 ;
        token=strtok(par,"()<>[]") ;
        if(token!=NULL)
        {
          token=strtok(NULL,"()<>[]") ;
          if(token!=NULL)
          {
            strcpy(from,token) ;
            while(strlen(from)<25)
              strcat(from," ") ;
            break ;
          }
        }
        strcpy(from,here) ;
        while(strlen(from)<25)
          strcat(from," ") ;
        break ;

      case NEWSGROUP:
        here+=12 ;
        break ;
      case SUBJECT:
        here+=9 ;
        strncpy(subj,here,80) ;
        subj[80]=0 ;
        while(strlen(subj)<80)
          strcat(subj," ") ;
        break ;
      case MID:
        here+=12 ;
        break ;
      case DATE:
        here+=6 ;
        strncpy(date,here,50) ;
        date[50]=0 ;
        while(strlen(date)<50)
          strcat(date," ") ;
        break ;
      case ORGANIZATION:
        here+=14 ;
        strncpy(orga,here,80) ;
        orga[80]=0 ;
        len=strlen(POST_ORGAN) ;
        if(len+strlen(orga)>79)
          orga[79-len]=0 ;
        break ;
      case REPLY_TO:
        here+=10 ;
        strcpy(rept,here) ;
        break ;
      default:
        ret=FALSE ;
    }
    here=ptr+2 ;
    if((*here=='\r') || (*here=='n'))
    {
      here+=2 ;
      break ;
    }
  }
  while(ret==TRUE) ;

  /*--- Make mail header ---*/
  sprintf(header,"%.10s%-.25s%.10s%-.34s\n",SENDER,from,POST_REPLY,rept) ;
  sprintf(par,"%.10s%-.25s%.10s%-.34s\n",POST_AREA,area,POST_DATE,date) ;
  strcat(header,par) ;
  sprintf(par,"%.10s%-.65s\n",POST_SUBJECT,subj) ;
  strcat(header,par) ;
  sprintf(par,"%s%s\n",POST_ORGAN,orga) ;
  strcat(header,par) ;
  sprintf(par,"------------------------------------------------------------[%s/%s]---------------",msgn,tota) ;
  par[79]='\n' ;
  par[80]=0 ;
  strcat(header,par) ;
  strcpy(buffer,here) ;
  if(ret==FALSE)
    return(ret) ;
  else
    return(pnum) ;
}
/* end parse_header */


/**************************************
   Parse the message about post data
*/
int parse_msg(pl,buf)
int *pl ;
char *buf ;
{
  char tmp1[100],tmp2[100],tmp0[100],crlf[3] ;
  char tmpbuf[6400] ;
  char *ptr ;
  int i, j ;

  if(strlen(buf)==0)
    return(0) ;

  sprintf(crlf,"%c%c",13,10) ;

  ptr=kkytok(buf,crlf) ;

  for(i=0; i<80; i++)
  {
    pl[i]=atoi(ptr) ;

    ptr=kkytok(NULL,crlf) ;
    strncpy(tmp0,ptr,55) ;
    tmp0[50]=0 ;
    for(j=0; j<50; j++)
    {
      if( tmp0[j]==9 )		/* replace tab to space */
        tmp0[j]=' ' ;
    }
    

    ptr=kkytok(NULL,crlf) ;
    strncpy(tmp1,ptr,22) ;
    tmp1[20]=0 ;

    sprintf(tmp2,"%4d %-20s %-50s",pl[i],tmp1,tmp0) ;
    strncpy(tmpbuf+i*100,tmp2,80) ;
    tmpbuf[i*100+80]=0 ;

    if((ptr=kkytok(NULL,crlf))==NULL)
    {
      memcpy(buf,tmpbuf,(i+1)*100) ;
      return(i+1) ;
    }
  }
  return(i) ;
}
