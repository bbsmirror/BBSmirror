/****************************************
    Show the post
    write by Aquarisu Kuo
    Apr 20, 1994
*****************************************/    
#include <curses.h> 
#include <ctype.h>

#ifndef LINUX
#include <sgtty.h>
#endif

#ifdef LINUX
#include <bsd/sgtty.h>
#endif

#include "pbbs.h"
#include "msg.h"

#define COL     78

long kkystr() ;

static char rcsid[]="$Id: showmail.c,v 1.20 1994/05/20 14:15:31 cs79026 Exp samson $" ;
extern WINDOW *stdscr,*curscr ;
extern int PgUp ;
extern char capfn[80] ;

static char finds[100] ;
static long last_s ;

int in_range(key)
char *key ;
{
  int ret, k ;
  
  switch(*key)
  {
    case 'q':   /* quit */
    case 'r':   /* reply */
    case 'p':   /* pre-post */
    case 'n':   /* next post */
    case 'u':   /* up page */
    case 'd':   /* down page */
    case ' ':   /* down page */
    case 'k':   /* kill post */
    case 'e':	/* enter a new post*/
    case '+':   /* relation up */
    case '-':   /* relation next */
    case '/':   /* search */
    case 13 :   /* next post */
    case 10 :
        ret=1 ;
        break ;

    case 27:
        if((k=readkey())=='[' || k=='O'  || k=='0' )
        {
          k=readkey() ;
          if( (k=='C') || (k=='D') || (k=='A') || (k=='B') )    
          {
            *key=k ;
            ret=1 ;
          }
          else
            ret=0 ;
        }
        else
          ret=0 ;      
          
        break ;

    default:
      ret=0 ;
  }
  
  return(ret) ;
}
        
/*--- To show the text by pages ---*/
/*--- return the last pressed key ---*/
int pager(head,body)
/*
  return: 
          -3: pre-post
          -2: next post
          -1: special key
           0: false
          >0: post number
*/         
char *head ;
char *body ;
{
  long i=0, j, l,
       n=0,
       cols=0,
       ass=0,
       here=0 ;          /*--- current page's head line ---*/
  int handle ;
  
  char cr=13,
       lf=10,
       *tab="        ",
       key ;
  char comm[100] ;
  char num[100] ;
  
  clrscr() ;
  show(head) ;
  
  while(1)
  {
      
    if((*(body+i)<32) && (*(body+i)>0) && (*(body+i)!=9) && (*(body+i)!=10) )
    {
      *(body+i)=' ' ;
    }
        
    if(*(body+i)==10)           /*--- if get the '\n' ---*/
    {
      write(1,&cr,1) ;  /*--- append carried return ---*/
      n++ ;
      cols=0 ;
      if(n%(SCR_ROWS-7)==0)        /*--- count the lines if full the screen ---*/
      {
        write(1,(body+i),1) ;
        
        j=i+1 ;
        while(*(body+j)!=0 && *(body+j)!=10 )
        {
          if( *(body+j)==9 )
          {
            if(cols%8==0)
            {
              write(1,tab,1) ;
              cols++ ;
            }
            while(cols%8)
            {
              write(1,tab,1) ;
              cols++ ;
              if(cols>COL)
              {
                while((*(body+j)!=10) && (*(body+j)!=0))
                  j++ ;
                cols=0 ;
                break ;
              }
            }
            if(cols!=0)
              j++ ;

            continue ;
          }     /* end check tab */

          if(cols<=COL)
            write(1,(body+j),1) ;

          cols++ ;
          j++ ;
        }

        if( *(body+j)==10 )
        {
          write(1,(body+j),1) ;
          cols=0 ;
        }

        write(1,&cr,1) ;
          
        show(POST_MORE) ;
        do
        {
          key=tolower(readkey()) ;
          if(key==23 && term_mode==0)   /*--- capture post ---*/
          {
            erase_line() ;
            show(CAPTUREFILE) ;
            getstring(-1,-1,capfn,79-strlen(CAPTUREFILE),1) ;
            
            if((handle=open(capfn,O_CREAT|O_APPEND|O_WRONLY,S_IREAD|S_IWRITE))<0)
            {
              printf("file open error") ;
            }  
            clear_cr(head) ;
            clear_cr(body) ;
            write(handle,head,strlen(head)) ;
            write(handle,body,strlen(body)) ;
            write(handle,&lf,1) ;
            close(handle) ;

            here=0 ;
            for(j=i; j>0; j--)
            {
              if( *(body+j)==10 )
                here++ ;

              if( here>(SCR_ROWS-7) )
              {
                break ;
              }
            }
            i=(j>0) ? j:-1 ;
            last_s=j ;          /* adjust last_search */

            erase_line() ;
            show(POST_MORE) ;
            continue ;
          }
          
          if(isdigit(key))
          {
            num[0]=key ;
            num[1]=0 ;
            if(getstring(-1,-1,num,4,3)<=0)
            {
              here=0 ;
              for(j=i; j>0; j--)
              {
                if( *(body+j)==10 )
                  here++ ;

                if( here>(SCR_ROWS-7) )
                {
                  break ;
                }
              }
              i=(j>0) ? j:-1 ;
              last_s=j ;          /* adjust last_search */
              key=' ' ;
              break ;
            }
            else
            {
              return(atoi(num)) ;
            }    
          }
        }
        while(!in_range(&key)) ;
        
        if(key>96)
        {
          printf("%c",key) ;
          fflush(stdout) ;
        }
          
        if( key=='q' || key=='D' )    /*--- Quit ---*/  
        {
          return(0) ;
        }  
        
        if((key=='r') || (key=='k') || (key=='e') || (key=='+') || (key=='-'))        /*--- special key ---*/
        {
          body[0]=key ;
          return(-1) ;
        }
        
        if( (key==10) || (key==13) || (key=='n') || (key=='C') )     /*--- next post ---*/
        {
          return(-2) ;
        }
          
        if( key=='p' || key=='A' )    /*--- previous post ---*/
        {
          return(-3) ;
        }  
        
        if(key=='/')    /*--- search ---*/
        {
          erase_line() ;
          show("/") ;
          comm[0]=0 ;
          getstring(-1,-1,comm,60,1) ;

          if( (l=search_word(body,comm))<0 )
          {
            show(" not found!!") ;
            readkey() ;
            here=0 ;
            for(j=i; j>0; j--)
            {
              if( *(body+j)==10 )
                here++ ;

              if( here>(SCR_ROWS-7) )
              {
                break ;
              }
            }

            i=(j>0) ? j:-1 ;

          }
          else
          {
            i=l-1 ;
          }
          i++ ;
          continue ;
        }

        clrscr() ;
        show(head) ;
        
        if(key=='u')            /*--- pre-page ---*/
        {
          here=0 ;
          for(j=i; j>0; j--)
          {
            if( *(body+j)==10 )
              here++ ;

            if( here>(SCR_ROWS-7)*2 )
            {
              break ;
            }
          }
          i=(j>0) ? j+1:0 ;
          last_s=j ;          /* adjust last_search */
          continue;
        }

        if( (key==' ') || (key=='d') || (key=='B') )    /*--- next page ---*/
        {
          i++ ;
          continue ;
        }               
      }  
      else
      {
        write(1,(body+i),1) ;
        i++ ;
        continue ;
      }
    }  
    
    if(*(body+i)==9)    /* TAB */
    {
      if(cols%8==0)
      {
        write(1,tab,1) ;
        cols++ ;
      }
      while(cols%8)
      {
        write(1,tab,1) ;
        cols++ ;
        if(cols>COL)
        {
          while((*(body+i)!=10) && (*(body+i)!=0))
            i++ ;
          cols=0 ;
          break ;
        }
      }
      if(cols!=0)
        i++ ;

      continue ;
    }

    if(*(body+i)==0)
    {
        if(n%(SCR_ROWS-7)==0)
        {
          show("\n") ;
          n++ ;
        }  

        for(ass=n; ass%(SCR_ROWS-7)!=0; ass++)
        {
          n++ ;
          show("\n") ;
        }  
        show("\n") ;
        
        show(POST_MORE) ; 
        do
        {
          key=tolower(readkey()) ;
          
          if(key==23 && term_mode==0)   /*--- capture post ---*/
          {
            printf("\r                                                                             \r") ;
            printf("%s",CAPTUREFILE) ;
            getstring(-1,-1,capfn,79-strlen(CAPTUREFILE),1) ;
            
            if((handle=open(capfn,O_CREAT|O_APPEND|O_WRONLY,S_IREAD|S_IWRITE))<0)
            {
              printf("capture file open error\r\n") ;
            }  
            clear_cr(head) ;
            clear_cr(head) ;
            write(handle,head,strlen(head)) ;
            write(handle,body,strlen(body)) ;
            write(handle,&lf,1) ;
            close(handle) ;

            here=0 ;
            for(j=i; j>0; j--)
            {
              if( *(body+j)==10 )
                here++ ;

              if( here>(SCR_ROWS-7) )
              {
                break ;
              }
            }
            i=(j>0) ? j:-1 ;
            last_s=j ;          /* adjust last_search */

            erase_line() ;
            show(POST_MORE) ;
            continue ;
          }
          
          if(isdigit(key))
          {
            num[0]=key ;
            num[1]=0 ;
            if(getstring(-1,-1,num,4,3)<=0)
            {
              here=0 ;
              for(j=i; j>0; j--)
              {
                if( *(body+j)==10 )
                  here++ ;

                if( here>(SCR_ROWS-7) )
                {
                  break ;
                }
              }
              i=(j>0) ? j:-1 ;
              last_s=j ;          /* adjust last_search */
              key=' ' ;
              cols=0 ;
              break ;
            }
            else
            {
              return(atoi(num)) ;
            }    
          }
        }
        while(!in_range(&key)) ;
        
        if(key>96)
        {
          printf("%c",key) ;
          fflush(stdout) ;
        }
          
        if(key=='q' || key=='D')    /*--- Quit ---*/  
        {
          return(0) ;
        }  
        
        if((key=='r') || (key=='k') || (key=='e') || (key=='+') || (key=='-'))        /*--- special key ---*/
        {
          body[0]=key ;
          return(-1) ;
        }
        
        if( (key==10) || (key==13) || (key=='n') || (key=='C') )     /*--- next post ---*/
        {
          return(-2) ;
        }
        if( (key==' ') || (key=='d') || (key=='B') )    /*--- next page ---*/
        {
          return(-2) ;
        }  
        if( key=='p' || key=='A' )    /*--- previous post ---*/
        {
          return(-3) ;
        }  
        
        if(key=='/')    /*--- search ---*/
        {
          erase_line() ;
          show("/") ;
          comm[0]=0 ;
          getstring(-1,-1,comm,60,1) ;

          if( (l=search_word(body,comm))<0 )
          {
            show(" not found!!") ;
            readkey() ;
            here=0 ;
            for(j=i; j>0; j--)
            {
              if( *(body+j)==10 )
                here++ ;

              if( here>(SCR_ROWS-7) )
              {
                break ;
              }
            }

            i=(j>0) ? j:-1 ;

          }
          else
          {
            i=l-1 ;
          }
        }

        clrscr() ;
        show(head) ;
        
        if(key=='u')            /*--- pre-page ---*/
        {
          here=0 ;
          for(j=i; j>0; j--)
          {
            if( *(body+j)==10 )
              here++ ;

            if( here>(SCR_ROWS-7)*2 )
            {
              break ;
            }
          }
          i=(j>0) ? j:-1 ;
          last_s=j ;          /* adjust last_search */
        }
    }
    else
    {
      write(1,(body+i),1) ;
      cols++ ;
    }
    i++ ;
    if(cols>78)
    {
      while((*(body+i)!=10) && (*(body+i)!=0))
        i++ ;
    }
  }
}

/**************************************
    List each post num, from, subject
*/
int postlist(buf)
char *buf;
{
  int pl[80] ;
  int n, i ;
  int cols ;
  char num[8] ;
  char key ;

  n=parse_msg(pl,buf)-1 ;
  clear() ;
  refresh() ;

  for(i=0; i<=n; i++)
  {
    printf("   %-.75s\r\n",(buf+i*100)) ;
  }
 
  fflush(stdout) ;
  
  while(i<SCR_ROWS-1)
  {
    show("\n") ;
    i++ ; 
  }
  
  show(SELECTMSG) ;
  cols=strlen(SELECTMSG) ;
  
  i=(PgUp) ? n:0 ;
  do
  {
    gotoxy(1,i+1) ;
    printf("->") ;
    fflush(stdout) ;
    
    gotoxy(cols,SCR_ROWS) ;
    
    key=readkey() ;
    gotoxy(1,i+1) ;
    printf("   ") ;
    fflush(stdout) ;
    
    gotoxy(cols,SCR_ROWS) ;
        
    if(tolower(key)=='q')
    {
      buf[0]='q' ;
      PgUp=FALSE ;
      return(0) ;
    }
    
    if( (key==13) || (key==10) )
    {
      PgUp=FALSE ;
      return(pl[i]) ;
    }
    
    if(key==' ' || tolower(key)=='d')   /* Page Down */
    {
      PgUp=FALSE ;
      buf[0]='d' ;
      return(0) ;
    }
    
    if(tolower(key)=='u')       /* Page Up */
    {
      PgUp=TRUE ;
      buf[0]='u' ;
      return(0) ;
    }
    
    if(tolower(key)=='p')       /* pre-post */
    {
      i-- ;
      if(i<0)
      {
        buf[0]='u' ;
        PgUp=TRUE ;
        return(0) ;
      }
    }
    
    if(tolower(key)=='n')       /* next post */
    {
      i++ ;
      if(i<0)
      {
        buf[0]='d' ;
        PgUp=FALSE ;
        return(0) ;
      }
    }
    
    if(key==27)         
    {
      if((key=readkey())!='[' && key!='O' && key!='0' )
        continue ;
      
      key=readkey() ;
      if(key=='A')      /* Up */
      {
        i-- ;
        if(i<0)
        {
          buf[0]='u' ;
          PgUp=TRUE ;
          return(0) ;
        }
      }

      if(key=='B')      /* Down */
      {
        i++ ;
        if(i>n)
        {
          buf[0]='d' ;
          PgUp=FALSE ;
          return(0) ;
        }
      }
      
      if(key=='C')      /* Left = Enter */
      {
        PgUp=FALSE ;
        return(pl[i]) ;
      }
      
      if(key=='D')      /* Right = Quit */
      {
        buf[0]='q' ;
        PgUp=FALSE ;
        return(0) ;
      }
      
      continue ;
    }
          
          
    if(isdigit(key))
    {
      num[0]=key ;
      num[1]=0 ;
      if(getstring(-1,-1,num,4,3)<=0)
      {
        buf[0]='q' ;
        return(0) ;
      }
      else
      {
        PgUp=FALSE ;
        return(atoi(num)) ;
      }    
    }
  }
  while(1) ;
}    
