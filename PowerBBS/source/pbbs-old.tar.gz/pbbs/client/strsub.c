/*******************************************
    some tools for strings
    
    Write by Aquarius Kuo on Apr 9, 1994.
    
********************************************/
#include <string.h>

static char rcsid[]="$Id" ;
/*
    transfer long int to string and add common
*/    
char *ltostr(digit)
long digit ;
{
  static char buffer[20];
  char *ptr ;
  int  n, i ;
  
  sprintf(buffer,"%ld",digit) ;
  n=strlen(buffer) ;
  if(n<=3) return(buffer) ;
  
  ptr=buffer+n ;
  for(i=0; i<=2; i++)
  {
    *ptr=*(ptr-1) ;
    ptr-- ;
  }
  *ptr=',' ; 
  
  if(n<=6) 
  {
    buffer[n+1]=0 ;
  }
  else
  {
    buffer[n+2]=0 ;
    ptr+=4 ;
    for(i=0; i<=6; i++)
    {
      *ptr=*(ptr-1) ;
      ptr-- ;
    }
    *ptr=',' ;
  }
  return(buffer) ;
}      
      
/***********************************************
   My string token. remove two token one time
*/
char *kkytok(s1,s2)
char *s1 ;
char *s2 ;
{
  static char *ptr ;
  char *p1, *p2 ;

  if(s1!=NULL)
    ptr=s1 ;

  p1=ptr ;
  while(*p1!=0)
  {
    if(*p1==*s2)
    {
      *p1=0 ;
      if(*(p1+1)==*(s2+1))
      {
        p1++ ;
        *p1=0 ;
      }
      p2=ptr ;
      ptr=p1+1 ;
      return(p2) ;
    }
    else
      p1++ ;
  }

  return(NULL) ;
}

/*******************************************
    like strstr, but work at big buffer OK!
    return : the offset of s1.
*/
long kkystr(s1,s2) 
char *s1 ;
char *s2 ;
{
  long cnt, i, j ;
  int same ;
  
  if( strlen(s2)<=0 || strlen(s2)>=100 )
    return(-1) ;
  
  cnt=i=j=0 ;
  
  while(s1[cnt]!=0)
  {
    for(i=0; i<strlen(s2); i++)
    {
      same=1 ;
      if( s1[cnt+i]!=s2[i] )
      {
        same=0 ;
        cnt++ ;
        break ;
      }
    }
    
    if(same==1)
      return(cnt) ;
      
  } 
  return(-1) ;
}  
