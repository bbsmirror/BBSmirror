/*******************************************
    UPLOAD & DOWNLOAD file from server

    Write by Aquarius Kuo on Apr 9, 1994.
    
********************************************/
#include "pbbs.h"
#include "msg.h"

static char rcsid[]="$Id" ;

/***************************************
    download file from server to client
*/    
int download(fd,buf,dmode)
int fd ;
char *buf ;
int dmode ;
{
  int handle,tcpstat ;
  int i ;
  char prot ;
  char fn[180], downdir[180] ;
  char *map="-\\|/" ;
  char bs=8 ;
  long BLOCK=4096 ;
  long bsize[10],bn,bt ;
  long len1, flen ;
  
  if(term_mode==1)
  {
    show(FDISABLE) ;    
    send_mpf(fd," ",0,STOPXFER) ;
    read_mpf(fd,buf,&len1,&prot,FALSE) ;
    return(FALSE) ;
  }
  
  strcpy(fn,buf) ;
  if( fn[0]=='~' && fn[1]=='/' )
  {
    strcpy(downdir,getenv("HOME")) ;
    strcat(downdir,&fn[1]) ;
  }
  else
  {
    strcpy(downdir,fn) ;
  }
  
  if((handle=open(downdir,O_CREAT|O_EXCL|O_WRONLY,S_IREAD|S_IWRITE))<0)
  {
    sprintf(buf,"\n%20s %s",fn,FILEEXIST) ;
    show(buf) ;
    send_mpf(fd," ",0,STOPXFER) ;
    read_mpf(fd,buf,&len1,&prot,FALSE) ;
    return(FALSE) ;
  }
  
  sprintf(buf,"%ld",BLOCK) ;
  send_mpf(fd,buf,strlen(buf),DOWNLOAD) ;
  
  read_mpf(fd,buf,&len1,&prot,FALSE) ;
  buf[len1]=0 ;
  if(dmode==2)
  { 
    sscanf(buf,"%ld",&flen) ;
    for(i=1; i<=10; i++)
    {
      bsize[i-1]=flen*i/(10*BLOCK) ;
    }  
    if(flen<BLOCK)
    {
      bsize[9]=1 ;
    }
    else
    {  
      bsize[9]=((flen%BLOCK)==0) ? bsize[9]-1:bsize[9] ;
    }    

    printf("\n\r%20s  %10s  ",fn,ltostr(flen)) ;
    printf("..........%c%c%c%c%c%c%c%c%c%c",bs,bs,bs,bs,bs,bs,bs,bs,bs,bs) ;  
    fflush(stdout) ;
  }
  
  send_mpf(fd," ",0,XFER_ACK) ;

  bn=bt=0 ;
  while(1)
  {
    if((tcpstat=read_mpf(fd,buf,&len1,&prot,TRUE))==1)
    {
      if(prot==XFER_ACK)
      {
        bn++ ;
        if(write(handle,buf,len1)<len1)
        {
          send_mpf(fd,"Write error!!",13,STOPXFER) ;
          close(handle) ;
          break ;
        }
        else
        {
          if ( dmode==2 )
          {
            printf("%c%c",map[bn%4],bs) ;
            while((bn>bsize[bt]) && (bt<10))
            {
              printf("*") ;
              bt++ ;
            }
            fflush(stdout) ;
          }
          send_mpf(fd," ",0,XFER_ACK) ; 
        }  
      }  
      if(prot==END_XFER)
      {
        close(handle) ;
        break ;
      }
      if(prot==STOPXFER)
      {
        close(handle) ;
        unlink(downdir) ;
        break ;
      }
    }
    else
    {
      if(tcpstat==-1)
      {
        hang_up("TCP network error!\n",fd) ;
      }  
    }      
  }
  return(TRUE) ;  
}  

/**************************************
    get the upload file name
*/
int get_filename(buffer) 
char *buffer ;
{
  char pathfn[200] ;
  int i=0 ;

  while(i<1)
  {
    i++ ;
    pathfn[0]=0 ;
    show("\n") ;
    show(UFILENAME) ;
    if(getstring(-1,-1,pathfn,50,1)>0)
    {
      strcpy(buffer,pathfn) ;
      show("\n") ;
      return(TRUE) ;
    }
  }
  return(FALSE) ;
}
      
/**************************************
    upload a file from client to server
*/    
int upload(fd,buffer,umode)
int fd ;
char *buffer ;
int umode ;
{
  int handle,tcpstat ;
  int i ;
  char prot ;
  char fn[80], *ptr ;
  char *map="-\\|/" ;
  char bs=8 ;
  long BLOCK=4096 ;
  long bsize[10],bn,bt ;
  long len1, flen ;
  
  if(term_mode==1) 
  {
    show(FDISABLE) ;
    send_mpf(fd," ",1,STOPXFER) ;
    return(FALSE) ;
  }  
  
  strcpy(fn,buffer) ;
  for(i=0; i<strlen(fn); i++)	/*--- check file name ---*/
  {
    if(fn[i]<33)
    {
      fn[i]=0 ;  
      break ;
    }  
  }
  
  if((handle=open(fn,O_RDONLY))<0)	/* open upload file */
  {
    sprintf(buffer,"%s\n",FNOTFOUND) ;
    show(buffer) ;
    send_mpf(fd," ",1,STOPXFER) ;	/* send blank to end */
    return(FALSE) ;
  }

  send_mpf(fd, fn, strlen(fn), UPLOAD);		/*--- send file name ---*/
  
  read_mpf(fd,buffer,&len1,&prot,FALSE) ;
  if(prot!=UPLOAD)
  {
    buffer[len1]=0 ;
    show(buffer) ;
    return(FALSE) ;
  }

  sprintf(buffer,"%ld",BLOCK) ;
  send_mpf(fd,buffer,strlen(buffer),UPLOAD) ;

  if(umode==2)		/* init the percent count */
  { 
    flen=flength(fn) ; 
    for(i=1; i<=10; i++)
    {
      bsize[i-1]=flen*i/(10*BLOCK) ;
    }  
    if(flen<BLOCK)
    {
      bsize[9]=1 ;
    }
    else
    {  
      bsize[9]=((flen%BLOCK)==0) ? bsize[9]-1:bsize[9] ;
    }    

    printf("\n\r%20s  %10s  ",fn,ltostr(flen)) ;
    printf("..........%c%c%c%c%c%c%c%c%c%c",bs,bs,bs,bs,bs,bs,bs,bs,bs,bs) ;  
    fflush(stdout) ;
  }
  
  if((len1=read(handle,buffer,BLOCK))<=0)
  {
    send_mpf(fd,"Write error!!\n",14,STOPXFER) ;
    close(handle) ;
    return(FALSE) ;
  }
  else
  {
    send_mpf(fd,buffer,len1,XFER_ACK) ;
    if(len1<BLOCK)
    {
      read_mpf(fd,buffer,&len1,&prot,FALSE) ;
      send_mpf(fd," ",1,END_XFER) ;
      show("**********\n") ;
      return(TRUE) ;
    }
  }    
          
  bn=bt=0 ;
  do
  {
    if((tcpstat=read_mpf(fd,buffer,&len1,&prot,TRUE))==1)
    {
      if(prot==XFER_ACK)
      {
        bn++ ;
        if((len1=read(handle,buffer,BLOCK))<0)
        {
          send_mpf(fd,"Write error!!",13,STOPXFER) ;
          close(handle) ;
          break ;
        }
        else
        {
          if ( umode==2 )
          {
            printf("%c%c",map[bn%4],bs) ;
            while((bn>bsize[bt]) && (bt<10))
            {
              printf("*") ;
              bt++ ;
            }
            fflush(stdout) ;
          }
          send_mpf(fd,buffer,len1,XFER_ACK) ; 

          if(len1<BLOCK)
          {
            while(bt<10)
            {
              printf("*") ;
              bt++ ;
            }  
            fflush(stdout) ;
            read_mpf(fd,buffer,&len1,&prot,FALSE) ;
            show("\n\n") ;
            send_mpf(fd," ",1,END_XFER) ;
          }  
        }  
      }  
      if(prot==END_XFER)
      {
        close(handle) ;
        break ;
      }
      if(prot==STOPXFER)
      {
        close(handle) ;
        break ;
      }
    }
    else
    {
      if(tcpstat==-1)
      {
        hang_up("TCP network error!\n",fd) ;
      }  
    }      
  }
  while(len1==BLOCK) ;
  return(TRUE) ;  
}

file_exist(filename)
char *filename;
/*
	return: TRUE: exist
		FALSE: not exist
*/
{
	FILE *testexist;

	if( (testexist=fopen(filename, "r")) == NULL)
		return(FALSE);		/*not found*/
	else	/*file found*/
	{
		fclose(testexist);
		return(TRUE);
	}
}
/*end of file_exist*/

/*
	flength --- get length of a file
*/
flength(filename)
	char *filename;
{
	int test;
	unsigned long len;

        test=open(filename, O_RDONLY);
        lseek(test, 0, SEEK_END);
       	len = tell(test);
	close(test);

	return(len);
}
/*end of flength*/



#ifdef NETBSD
/*
	NetBSD does not support tell() function, use fstat as alternative one
*/
tell(fd)
        int fd;
{
        struct stat buf;
        fstat(fd, &buf);
        return(buf.st_size);
}
#endif
