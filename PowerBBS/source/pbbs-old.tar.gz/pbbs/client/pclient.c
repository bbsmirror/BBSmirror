/***************************************************************
    pclient.c

    To connect the BBS server.
    write by Aquarius Kuo(cs79026@chpi.edu.tw)
    1993.11.24.
*****************************************************************/
#include <curses.h>
#include <malloc.h>
#include <ctype.h>
#include "pbbs.h"

#define LEFT    '{'
#define RIGHT   '}'
#define SEP     '|'
#define VERSION  (char) 17

#ifdef	SUN4
#define PLATFORM (char) 1
#endif

#ifdef	NETBSD
#define PLATFORM (char) 3
#endif

#ifdef RS6K
#define PLATFORM (char) 4
#endif

#ifdef DEC3K
#define PLATFORM (char) 5
#endif

#ifdef HPPA
#define PLATFORM (char) 6
#endif

#ifdef ALPHA
#define PLATFORM (char) 7
#endif

#ifdef LINUX
#define PLATFORM (char) 8
#endif

#ifndef PLATFORM
#define PLATFORM (char) 15
#endif

static char rcsid[]="$Id: pclient.c,v 1.35 1994/07/11 04:41:40 cs79026 Exp samson $" ;

typedef struct menu_tree 
          {
            char name[21] ;        /*--- the name of menu ---*/
            char *menu ;           /*--- menu screen ---*/
            char hotkey[60][20] ;  /*--- menu hotkey & return string ---*/
            struct menu_tree *next ;      /*--- next menu pointer ---*/
          } MENU_TREE ;
          
/*--- Prompt the screen ---*/          
char    SENDER[30], 
        POST_DATE[30], 
        POST_SUBJECT[30], 
        POST_NUM[30], 
        POST_AREA[40] ;

char    POST_REPLY[30], 
        POST_ORGAN[60], 
        POST_BOTTOM[80] ; 

char    MORE[80], 
        PRESSANYKEY[80],
        POST_MORE[100], 
        EDITCONFIRM[80],
        SELECTMSG[80] ;

char    FILEEXIST[80],
        UFILENAME[80],
        FNOTFOUND[80],
        FDISABLE[80],
        ASKFILENAME[80] ;

char	CAPTUREFILE[80],
	SCANOFIND[80],
	DOWNPATH[80] ;
        
int term_mode=0 ;
int PgUp ;
char capfn[80] ;
int SCR_ROWS, SCR_COLS ;

/*--- To create a new space to put the menu pointer ---*/
MENU_TREE *newmenu()
{
  MENU_TREE *here;
  here=(MENU_TREE *) malloc(sizeof(MENU_TREE)) ;
  memset(here,0,sizeof(MENU_TREE)) ;
  return(here);
}

/*--- To phrase the message to menu ---*/
MENU_TREE *phrase_menu(root,buf,len)
MENU_TREE **root ;
char buf[] ;
long len ;
{
  char name[21], *n ;
  MENU_TREE *here, *last ;
  long c, m ;   /*--- count the length, c:buf, m:menu table ---*/
  int kn ;  /*--- count the hotkey number ---*/
  int offset ;  /*--- count the hotkey return string number ---*/
  int updatemenu=0 ;
  
  if((n=(char*)memchr(buf,RIGHT,41))==NULL)
  {
    printf("wrong menu name\n%s",buf) ;
    end_terminal() ;
    exit(1) ;
  }
  
  c=0 ;
  while( *(buf+c)!=RIGHT )
    c++ ;
    
  c++ ;  
  memcpy(name,buf,(int) c) ;  /*--- get the menu name into name[] ---*/
  name[(int) c++]=0 ;
  here=*root ;
  last=NULL ;
  while(here!=NULL)
  {
    if(strcmp(name,here->name))
    {
      /*--- menu name not the same ---*/
      last=here ;
      here=here->next ;
    }
    else
    {
      if( len>c+c )	/* suppose len>2*c mean update menu */
      {
        updatemenu=1 ;
        break ;
      }
      else
        return(here) ;
    }
  }

  /*--- to create a new menu space ---*/
  if( updatemenu==0 )
  {
    here=newmenu() ;
    if(last!=NULL) 
      last->next=here ;
    here->next=(MENU_TREE *) NULL ;
    here->menu=(char *) malloc(len) ;
    strcpy(here->name,name) ;
  }
  
  kn=0 ;
  m=0 ;
  
  while(c<=len)
  {
    if( (buf[c]==LEFT) && (buf[c+2]==SEP) )
    {
      kn++ ;
      here->hotkey[kn][0]=buf[c+1] ;
      if((n=(char*)memchr(&buf[c+3],RIGHT,20))==NULL)
      {
        printf("error hotkey return string\n") ;
        end_terminal() ;
        exit(1) ;
      }
      offset=n-(&buf[c+2]) ;
      here->hotkey[kn][1]='{' ;
      memcpy(&(here->hotkey[kn][2]),&buf[c+3],offset) ;
      c+=offset+3 ;
    }
    else
    {
      *((here->menu)+(m++))=buf[c++] ;
    }
  }
  here->hotkey[0][0]=kn ;
  while(*(here->menu+(--m))<32) ;
  *((here->menu)+m+1)=0 ;
  if(*root==NULL)
  {
    *root=here ;
  }
  return(here) ;
}



/*--- To close the connection & exit ---*/
void hang_up(msg,fd)
char *msg ;
int fd ;
{
  printf("\n\r%s\n\r",msg) ;
  close(fd) ;
  end_terminal() ;
  exit(1) ;
}

/*--- To close the connection & exit ---*/
void abnormal_disconnect(fd)
int fd ;
{
  printf("\n\rThe server closed the connection!!\n\r") ;
  close(fd) ;
  end_terminal() ;
  exit(1) ;
}


/*========================Main program ============================*/
main(argc, argv)
int argc;
char *argv[];
{
  int fd ;
  long len, read_len ;
  char prot ;
  char ipaddr[50] ;
  int  bbsport ;
  MENU_TREE *root, *here ;
  int quit, out_getkey, i, tcpstat ;
  int mils, cnt ;
  struct timeval start_time, end_time ;
  char key ;
  char editor[120], LOCAL_DIR[120] ;
  char header[500] ;
  char buffer[MAX_BUF], pwbuffer[20] ;

  extern int broken_pipe();     /*when client and server run under the same*/
                                /*host, network will use PIPE to communicate*/

  init_terminal() ;
  
  clrscr() ;
  
  printf("\r\n\n Power BBS  client  V1.13\n\r") ;
  printf("   by Aquarius Kuo, Team SQUARE-1991, Jul 11, 1994.\r\n\n") ;

  fflush(stdout) ;

  cnt=quit=0 ;
  if(argc>1)
  {
    if(*argv[1]=='-')
    {
      
      if( *(argv[1]+1)=='t' )
      {
        term_mode=1 ;
        cnt=1 ;
      }
      else
      {
        printf("Syntax:\n\r") ;
        printf("   %%p [-t] [ip_addr | domain_name] [port]\r\n\n") ;
        printf("    -t : disable disk writing.\n\n\r") ;
        end_terminal() ;
        exit(1) ;
      }         
    }
  }     
  
  if(argc>(1+cnt))
  {    
    strncpy(ipaddr,argv[1+cnt],40) ;
    ipaddr[40]=0 ;
  }  
  else
    strcpy(ipaddr,"140.126.22.1") ;
  
  if(argc>(2+cnt))
  {
    bbsport=atoi(argv[2+cnt]) ;
    if(bbsport<=0)
      bbsport=PBBS_DEFAULT_PORT ;
  }  
  else
    bbsport=PBBS_DEFAULT_PORT ;

#ifdef TERMMODE
 	term_mode=1 ;
#endif

(void) signal(SIGPIPE, (void *) broken_pipe);          /*see broken_pipe()*/

#ifdef TERMMODE
  show("\n\n");
  show("  �z�Q�� telnet �i�Ӫ����� PowerBBS ����, �O�L�k�ɨ��� Download\n");
  show("  �H�� Screen Capture ���j�j�\\��, �Ч� ftp �� pbbs.chpi.edu.tw\n");
  show("  �h���u���� PowerBBS Client �{���a! �Y�z�� PC �s�W, ��ĳ�h�� PC\n");
  show("  ��, �ɨ��� PE2 �g�H���ַP�a!!!\n");
  show("\n");
  show("  Client �i�� Anonymous FTP �b pbbs.chpi.edu.tw �U\n");
  show("\n");
  show("     /pub/pbbs/client\n");
  show("\n\n");
  show("  �Ы����N��i�J PowerBBS �t��...");
  readkey();
  show("\n");
#endif
  
  fd=connectTCP(ipaddr, bbsport);
  strcpy(buffer,"Samson") ;
  send_mpf(fd,buffer,strlen(buffer),SESSION,FALSE) ;

  read_mpf(fd, buffer, &len,&prot,FALSE);
  buffer[len]=0 ;
  if(strcmp("Aquarius",buffer))
  {
    hang_up("you die!",fd) ;
  }
  buffer[0]=VERSION ;         /* VER_HIGH<<4+VER_LOW ;*/
  buffer[1]=(PLATFORM<<4)+0 ;   /* 1*16+0 ;*/
  

  strcpy(&buffer[2],"POWERBBS") ;
  send_mpf(fd,buffer,10,SESSION) ; 

  /*--- init variable ---*/
  root=here=NULL ;
  quit=FALSE ;
  PgUp=FALSE ;
  
  if(getenv("EDITOR")==NULL) 
    strcpy(editor,"vi") ;
  else
    strcpy(editor,getenv("EDITOR")) ;  
    
  if(getenv("DOWNLOAD")==NULL) 
    strcpy(LOCAL_DIR,".") ;
  else
    strcpy(LOCAL_DIR,"~") ;
    
  strcpy(capfn, "cap.txt") ;
  
  strcpy(SENDER,      "Post From:") ;
  strcpy(POST_AREA,   "Post area:") ;
  strcpy(POST_NUM,    "  Number: ") ;
  strcpy(POST_SUBJECT," Subject: ") ;
  strcpy(POST_DATE,   "    Date: ") ;
  
  strcpy(POST_REPLY,  "Reply-to: ") ;
  strcpy(POST_ORGAN,  "Organization: ") ;
  strcpy(POST_BOTTOM, "=== Bottom ===") ;
  
  strcpy(POST_MORE,   "Next Page?( [space], [B]ackward, [Q]uit)") ;
  strcpy(EDITCONFIRM, "P)ost  E)dit  A)bort :") ;
  strcpy(MORE,        "---more---") ;
  strcpy(PRESSANYKEY, "Press any key ....") ;
  strcpy(SELECTMSG,   "<Up>, <Down>, <Space> or Message number:") ;
  strcpy(SELECTMSG,   "<Up>, <Down>, <Space> or Message number:") ;

  strcpy(FILEEXIST,   "File exist!!") ;
  strcpy(UFILENAME,   "The file was existed on BBS!!") ;
  strcpy(FNOTFOUND,   "File not found!!") ;
  strcpy(FDISABLE,    "Host mode, funtion disabled!!") ;

  strcpy(CAPTUREFILE, "Capture file : ") ;  
  strcpy(SCANOFIND,   " not found.") ;
  strcpy(DOWNPATH,    "Download directory: ") ;
  /*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/

  
  do
  {
    if((tcpstat=read_mpf(fd,buffer,&len,&prot,TRUE))==1)
    {
      buffer[len]=0 ;
      switch(prot)
      {
        case ASK:
          show(buffer) ;
          i=strlen(buffer) ;
          buffer[0]=0 ;
          i=getstring(-1,-1,buffer,79-i,1) ;
          show("\n") ;
          send_mpf(fd,buffer,i,ASK) ;
          break ;
        case BYEBYE: 
          quit=TRUE ;
          break ;        
        case DISPLAY:
          show(buffer) ;
          break ;
        case DOWNLOAD:
          if( LOCAL_DIR[0]!=0 )
          {
            strcpy(buffer+1024,buffer) ;
            strcpy(buffer,LOCAL_DIR) ;
            
            if( LOCAL_DIR[strlen(LOCAL_DIR)-1]!='/' )
              strcat(buffer,"/") ;
              
            strcat(buffer,buffer+1024) ;
          }    
          if(download(fd,buffer,2)==FALSE)
            show("")  ;
          break ;
        case ERROR:
          show(buffer) ;
          break ;
        case FILEPOST:
          if( term_mode )       /* not support under terminal mode */
          {
            show(FDISABLE) ;
            send_mpf(fd,buffer,1,STOPPOST) ;
            readkey() ;
            break ;
          }
          show(ASKFILENAME) ;
          buffer[0]=header[0]=0 ;
          if(getstring(-1,-1,header,30,1)<1)
          {
            send_mpf(fd,buffer,1,STOPPOST) ;
          }
          else
          {
            if( get_file(header,buffer) )
            {
              show(EDITCONFIRM) ;
              do
              {
                key=tolower(readkey()) ;
                
                if(key=='e')	/* edit post again */
                {
                  printf("%c",key) ;
                  fflush(stdout) ;
                  end_terminal() ;
                  if( writer(buffer,editor)==FALSE )
                  {
                    init_terminal() ;
                    send_mpf(fd,buffer,1,STOPPOST) ;
                    break ;
                  }
                  else
                  {
                    init_terminal() ;
                    show(EDITCONFIRM) ;
                  }
                }
              }
              while( (key!='p') && (key!='a') ) ;
              printf("%c",key) ;
              fflush(stdout) ;
              if(key=='p')
              {
                send_mpf(fd,buffer,strlen(buffer),MAKEPOST) ;
                break ;
              }
              else
              {
                if(key=='a')
                {
                  send_mpf(fd,buffer,1,STOPPOST) ;
                  break ;
                }
              }
            }
            else
            {
              show("\n\n") ;
              show(FNOTFOUND) ;
              readkey() ;
              send_mpf(fd,buffer,1,STOPPOST) ;
            }
          }
          break ;
        case INTRREAD:
          if((cnt=postlist(buffer))>0)
          {
            sprintf(buffer,"%d",cnt) ;
            send_mpf(fd,buffer,strlen(buffer),INTRREAD) ;
          }
          else
          {
            send_mpf(fd,buffer,1,INTRREAD) ;
          }
          
          clear() ;
          refresh() ;
          
          break ;
        case MAKEPOST:
          clear_cr(buffer) ;
          clear_esc(buffer) ;
          do
          {
            end_terminal() ;
            if(writer(buffer,editor)==FALSE)
            {
              init_terminal() ;  
              send_mpf(fd,buffer,0,STOPPOST) ;
              break ;
            }  
            else
            {
              init_terminal() ;  
              show(EDITCONFIRM) ;
              do
              {
                key=tolower(readkey()) ;
              }
              while((key!='p')&&(key!='e')&&(key!='a')) ;
              printf("%c\r\n",key) ;
              fflush(stdout) ;
              if(key=='p')
              {
                send_mpf(fd,buffer,strlen(buffer),MAKEPOST) ;
                break ;
              }  
              else
              {
                if(key=='a')
                {
                  send_mpf(fd,buffer,0,STOPPOST) ;  
                  break ;
                }  
              }
            }
          }  
          while(key=='e') ;    
          
          break ;
        case MENU:
          here=phrase_menu(&root,buffer,len) ;
          show(here->menu) ;
          out_getkey=FALSE ;

          do    /*--- Check the input key ---*/
          {
            key=readkey() ;
            
            if( !term_mode )
            {
              if( key==4 )	/* ctrl-D : shell */
              {
                show("\n\n") ;
                end_terminal() ;
                system(getenv("SHELL")) ;
                init_terminal() ;
                show(here->menu) ;
                continue ;
              }
            
              if( key==16 )	/* ctrl-P : set local directory path */
              {
                show("\n\nDirectory: ") ;
                getstring(-1,-1,LOCAL_DIR,60,1) ;
                show(here->menu) ;
                continue ;
              }
            }
            
            for(i=1; i<=here->hotkey[0][0]; i++)
            {
              if(here->hotkey[i][0]==key)
              {
                write(1,&key,1) ;
                show("\n") ;
                /*---------------------*/
                if(!strcmp(&(here->hotkey[i][1]),"{Ping}"))
                {
                  gettimeofday(&start_time,NULL) ;
                }
                  
                send_mpf(fd,&(here->hotkey[i][1]),strlen(&(here->hotkey[i][1])),MENU) ;
                out_getkey=TRUE ; 
                break ;
              }
            }
          }
          while(!out_getkey) ;  
          break ;
        case PASSWD:
          show(buffer) ;
          pwbuffer[0]=0 ;
          cnt=getstring(-1,-1,pwbuffer,10,2) ;
          show("\n") ;
          if(cnt<=0) 
          {
            send_mpf(fd,pwbuffer,0,PASSWD) ;
            break ;
          }
          for(i=strlen(pwbuffer); i<10; i++)
            pwbuffer[i]=59+i*2 ;
          pwbuffer[10]=0 ;
          for(i=1; i<=10; i++)
          {
            pwbuffer[i-1]=(char) ((((pwbuffer[i-1]+pwbuffer[10-i])*67)%91)+32) ;
          }
          send_mpf(fd,pwbuffer,10,PASSWD) ;
          break ;
        case PECHO:
          gettimeofday(&end_time,NULL) ;
          mils=(end_time.tv_sec-start_time.tv_sec)*1000 ;
          mils+=end_time.tv_usec/1000 ;
          mils-=start_time.tv_usec/1000 ;
          sprintf(buffer,"\n     Ping echo from server in %7.2f seconds\n",(float) mils*0.001) ;
          show(buffer) ;
          break ;  
        case POST:
          clear_esc(buffer) ;
          if((cnt=parse_header(buffer,header))==FALSE)
            break ;
          clear() ;
          refresh() ;
          strcat(buffer,"\n") ;
          strcat(buffer,POST_BOTTOM) ;
          i=pager(header,buffer) ;
          if(i>0)
          {
            sprintf(buffer,"%d",i) ;
            send_mpf(fd,buffer,strlen(buffer),GETPOST) ;
          } 
          else
          {
            if(i==0)
            {
              send_mpf(fd,"q",1,GETPOST) ;
              show("\n\n") ;
            }  
            if(i==-1)
            {
              send_mpf(fd,buffer,1,GETPOST) ;
            }
            
            if(i==-2)                   /*--- next post ---*/
            {
              sprintf(buffer,"%d",++cnt) ;
              send_mpf(fd,buffer,strlen(buffer),GETPOST) ;
            }
            if(i==-3)                   /*--- pre post ---*/
            {
              sprintf(buffer,"%d",--cnt) ;
              send_mpf(fd,buffer,strlen(buffer),GETPOST) ;
            }  
          }    
          break ;
        case PROMPT:
          parse_prompt(buffer) ;
          break ;  
        case REJECT:
          quit=TRUE ;
          show(buffer) ;
          break ;
        case SCRSIZE:
          sprintf(buffer,"%d",SCR_ROWS) ;
          send_mpf(fd,buffer,strlen(buffer),SCRSIZE) ;
          break ;
        case SUSPEND:
          show(PRESSANYKEY) ; 
          readkey() ;
          sprintf(buffer,"%c                                %c",13,13) ;
          show(buffer) ;
          break ;
        case TALK:
	  chat_room(fd,buffer) ;
          break ;
        case UPLOAD:
          if(get_filename(buffer)==FALSE)
          {
            send_mpf(fd," ",1,STOPXFER) ;
          }  
          else 
          {
            show("\n") ;
            upload(fd,buffer,2) ;
          }  
          break ;  
        default:
          sprintf(buffer,"Error protocol : %d\n",prot) ;
          show(buffer) ;
          abnormal_disconnect(fd) ;
      }
    }
    else
    {
      if(tcpstat==-1)
      {
        hang_up("Error tcp communation!!\n",fd) ;
      }  
    }
  }
  while(!quit) ;
  
  end_terminal() ;
}



/*
        broken-pipe --- when client and server run under the same host,
                        communication will be the pipe. If the pipe was
                        broken, this signal will be send.
                        So that, read() or write() cannot catch any error
                        if server process was terminated, only this signal
                        handler can catch this error!

                        coded by Samson Chen
*/
broken_pipe()
{
        end_terminal();
}
/*end of end_win*/
