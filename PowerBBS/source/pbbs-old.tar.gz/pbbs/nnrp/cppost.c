/*************************************************************************
 * cppost.c --- get CPPOST PowerBBS Compressed Link by MPF stadard	 *
 *	      by Samson Chen, Apr 16, 1994				 *
 *************************************************************************/

#include "../host/pbbs.h"
#include "global.h"
#include "../host/dbf.h"



/*
	cppost --- PowerBBS compress post with password protection
*/
cppost(fd)
{
	char line[1024];
	int ret;
	char tmp_file[128];

	sprintf(line, "345 PowerBBS MPF Ready...%c%c", 13, 10);
	write(fd, line, strlen(line) );

	if(debug_mode) printf("(cppost.c)enter mpf stadard\n");

	strcpy(tmp_file, tmpnam(NULL) );
	do_log(0, "set tmp name %s for %s", tmp_file, client_site);

	ret=recv_file(fd, tmp_file);

	if( !ret )
	{
		do_log(5, "%s recvfile failed, process quit directly", client_site);

		exit(5);
		/*mpf is a binary-orientation protocol, if error occurred*/
		/*it's hard to restore to text stat			 */
	}

	/*-------------------------------------------------------------------*/
	/*send OK to prevent sending IDLE, Maybe tossing need lots time      */
	/*-------------------------------------------------------------------*/

	sprintf(line, "245 CPPosting ok%c%c", 13, 10);
	write(fd, line, strlen(line) );

	uncompress_post(tmp_file);
}
/*end of cppost*/
