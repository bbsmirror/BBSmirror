/*************************************************************************
 * getset.c --- get groups setup file					 *
 *	        by Samson Chen, Mar 29, 1994				 *
 *************************************************************************/

#include "../host/pbbs.h"
#include "global.h"



struct station_struc {
	char	index[10];
	char	ip[16];
	char	port[6];
	char	link[20];
	char	id[30];
	};



struct group_struc {
	char	group[80];
	char	path[80];
	int	server;		/*each bit map to station_struc*/
				/*max 16 stations accept*/
	struct group_struc *next;
	};


/*local global vars*/
struct station_struc station[16];
struct group_struc *group;
char stations=0;



/*
	get_group_set --- get group definitions
*/
get_group_set()
/*
	return:
		TRUE: OK!
		FASLE: failure!
*/
{
	char gfile[80];
	char buf[128];
	FILE *gf;
	int n, ret;
	int m;
	char *p;
	char t_group[80];
	char t_path[80];
	int t_server;
	char temp[10];
	struct group_struc *group_point, *previous_gp;
	

	group=NULL;

	sprintf(gfile, "%s/%s", MAIL_PATH, NNTP_GROUP);

	/**************************************/
	/*phase 1 --- get !station definitions*/
	/**************************************/
	gf=fopen(gfile, "r");
	if( gf==NULL )
	{
		do_log(9, "open %s error", gfile);
		exit(11);
	}

	memset(buf, 0, 128);
	while( fgets(buf, 127, gf) )
	{
		trim_comment(buf);
		if( !strncmp(buf, "!station", 8) )
		{
			p=buf+9;
			ret=next_blank(p);
			p[ret]=0;
			strcpy(station[stations].index, p);

			p+=ret+1;
			ret=next_blank(p);
			p[ret]=0;
			strcpy(station[stations].ip, p);

			p+=ret+1;
			ret=next_blank(p);
			p[ret]=0;
			strcpy(station[stations].port, p);

			p+=ret+1;
			ret=next_blank(p);
			p[ret]=0;
			strcpy(station[stations].link, p);

			p+=ret+1;
			ret=next_blank(p);
			p[ret]=0;
			strcpy(station[stations].id, p);

			stations++;
		}/*end if*/

		memset(buf, 0, 128);

	}/*end while*/

	fclose(gf);


	/*************************/
	/*phase 2 --- get groups */
	/*************************/
	gf=fopen(gfile, "r");
	if( gf==NULL )
	{
		do_log(9, "open %s error", gfile);
		exit(11);
	}

	memset(buf, 0, 128);

	while( fgets(buf, 127, gf) )
	{
		trim_comment(buf);
		ret=strlen(buf);

		if(ret<126)
		{
			/*to avoid a possoble bug of next_blank*/
			buf[ret+1]=0;
			buf[ret+2]=0;
		}

		if(strlen(buf)>5 && strncmp(buf, "!station", 8) )
		{
			p=buf;
			ret=next_blank(p);
			p[ret]=0;
			strcpy(t_group, p);

			p+=ret+1;
			ret=next_blank(p);
			if(ret==0)
			{
				do_log(8,"%s error->%s", gfile, buf);
				memset(buf, 0, 128);
				continue;
			}
			p[ret]=0;
			strcpy(t_path, p);

			p+=ret+1;
			t_server=0;
			while( (ret=next_blank(p)) != 0)
			{
				p[ret]=0;
				temp[0]=0;
				strcpy(temp, p);

				n=0;
				while(n<stations)
				{
					if( !strcmp(station[n].index, temp ) )
					{
						m=1<<n;
						t_server |= m;
					}
					n++;
				}

				p+=ret+1;
			}

			/********************/
			/* put to link list */
			/********************/

			if( !path_exist(t_path) )
				do_log(9, "mail path '%s' not exist!", t_path);

			group_point=(struct group_struc *)malloc(sizeof(struct group_struc));

			strcpy(group_point->group, t_group);
			strcpy(group_point->path, t_path);
			group_point->server=t_server;
			group_point->next=NULL;

			if(group==NULL)
			{
				group=group_point;
				previous_gp=group;
			}
			else
			{
				previous_gp->next=group_point;
				previous_gp=group_point;
			}

		}/*end if*/

		memset(buf, 0, 128);

	}/*end while*/

}
/*end of get_group_set*/



/*
	get_mpath --- get mail_path from group name
*/
get_mpath(p, g)
	char *p;	/*path buffer*/
	char *g;	/*group name*/
{
	struct group_struc *group_point;

	group_point=group;
	while( group_point!=NULL )
	{
		if( !strcmp(group_point->group, g) )
		{
			strcpy(p, group_point->path);

			if( (group_point->server & get_client_site_server_bit())>0 )
			{
				if(debug_mode) printf("(getset.c)%s, %s server bit check ok!\n", client_site, g);
				return(TRUE);
			}
			else
			{
				do_log(0, "%s send to a not-belong group %s", client_site, g);
				return(FALSE);
			}
		}

		group_point=group_point->next;
	}

	do_log(4, "cannot find group %s", g);
	return(FALSE);
}
/*end of get_mpath*/



/*
	get_client_site_server_bit --- get the bit var of client_site
	(for checking station<--->groups mapping)
*/
get_client_site_server_bit()
{
	int n, m;

	n=0;
	m=0;

	while(n<stations)
	{
		if( !strcmp(station[n].index, client_site ) )
		{
			m=1<<n;
			return(m);
		}
		n++;
	}

	return(0);
}
/*end of get_client_site_server_bit*/



/*
	check_site_permission --- (as the name)
*/
check_site_permission(fd)
	int fd;
/*
	return:
		TRUE: OK
		FALSE: permission denied
*/
{
	int n;
	char buf[80];

	for(n=0; n<stations; n++)
		if( !strcmp(station[n].ip, client_site) ) break;

	if( n==stations )	/*unrecognized station*/
	{
		do_log(5, "%s permission denied", client_site);
		sprintf(buf, "502 access restriction%c%c", 13, 10);
		write(fd, buf, strlen(buf) );
		return(FALSE);
	}
	else			/*index found*/
	{
		do_log(0, "%s known as %s", client_site, station[n].index);
		strcpy(client_site, station[n].index);
		return(TRUE);
	}
}
/*end of check_site_permission*/



/*
	check_passwd --- check CPPOST passwd
*/
check_passwd(index, passwd)
	char *index;
	char *passwd;
/*
	return:
		TRUE: OK
		FALSE: failed
*/
{
	int n;

	for(n=0;n<stations; n++)
	{
		if( !strcmp(index, station[n].index) && !strcmp(passwd, station[n].link) )
			return(TRUE);
	}

	return(FALSE);
}
/*end of check_passwd*/
