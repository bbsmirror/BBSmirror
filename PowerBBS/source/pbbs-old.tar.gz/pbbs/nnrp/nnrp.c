/*************************************************************************
 * nnrp.c --- nnrp service						 *
 *	      by Samson Chen, Mar 24, 1994				 *
 *************************************************************************/

#include "../host/pbbs.h"
#include "global.h"

/*
	service definition
*/
#define	RFCPOST		1
#define	IHAVE		2
#define	QUIT		3
#define	ARTICLE		4
#define	BODY		5
#define	GROUP		6
#define	HEAD		7
#define	HELP		8
#define	LAST		9
#define	LIST		10
#define	NEWGROUPS	11
#define	NEWNEWS		12
#define	NEXT		13
#define	SLAVE		14
#define	NSTAT		15
#define	CPPOST		16
#define	UNRECOGNIZED	17
/*************************/



/*
	do_nnrp --- nnrp service
*/
do_nnrp(fd)
	int fd;
{
	char buf[1024];
	char back[1024];
	char *p;
	int ret, service;
	char cont=TRUE;
	int n;
	int p_cnt;


	do
	{

	reset_alarm();
	p=buf;
	ret=0;
	p_cnt=0;

	if(debug_mode) printf("(nnrp.c)waiting RFC command\n");

	do {
		p+=ret;
		p_cnt+=ret;

		if( p_cnt<(1023-80) )
			ret=read(fd, p, 80);

		if( ret<=0 ) abnormal_disconnect();

	}while( p[ret-1]!=10 );
	p[ret]=0;

	/*trail unnacessary chars*/
	for(n=0; n<strlen(buf); n++)
	  if( buf[n]==13 || buf[n]==10 )
	  {
		buf[n]='\0';
		break;
	  }


	while( buf[strlen(buf)-1] == '\n' || buf[strlen(buf)-1] == '\r')
		buf[strlen(buf)-1]='\0';

	alltrim(buf);
	if( strlen(buf)==0 ) continue;	/*skip null*/

	if(debug_mode) printf("(nnrp.c)get command %s\n", buf);
	service=parse_service(buf);
	strcpy(back, buf);

	switch(service)
	{
	case RFCPOST:
		do_log(2, "%s request POST command", client_site);

		if( !check_passwd(client_site, "+") )
		{
			do_log(8," %s post protection error", client_site);
			sprintf(buf, "502 access restriction%c%c", 13, 10);
			write(fd, buf, strlen(buf) );
			cont=FALSE;
			break;

		}

		sprintf(buf, "340 send article to be posted.%c%c", 13, 10);
		write(fd, buf, strlen(buf) );

		sendme(fd,1, (char*)NULL);
		
		break;

	case IHAVE:
		do_log(0, "%s request IHAVE command", client_site);

		if( !check_passwd(client_site, "+") )
		{
			do_log(8," %s post protection error", client_site);
			sprintf(buf, "502 access restriction%c%c", 13, 10);
			write(fd, buf, strlen(buf) );
			cont=FALSE;
			break;

		}

		sprintf(buf, "335 send article to be transferred.%c%c", 13, 10);
		write(fd, buf, strlen(buf) );

		sendme(fd, 2, back+6);

		break;

	case CPPOST:
		do_log(0, "%s request CPPOST command", client_site);
		if( !check_passwd(client_site, back+7) )
		{
			do_log(8," %s password error (%s)", client_site, back+7);
			sprintf(buf, "502 password error!.%c%c", 13, 10);
			write(fd, buf, strlen(buf) );
			cont=FALSE;
			break;
		}

		cppost(fd);

		break;

	case QUIT:
		do_log(5, "%s request QUIT command", client_site);
		sprintf(buf, "205 closing connection - goodbye !%c%c", 13, 10);
		write(fd, buf, strlen(buf) );
		cont=FALSE;
		break;

	case ARTICLE:
	case BODY:
	case GROUP:
	case HEAD:
	case HELP:
	case LAST:
	case LIST:
	case NEWGROUPS:
	case NEWNEWS:
	case NEXT:
	case SLAVE:
	case NSTAT:
		do_log(2, "%s request an unsupportted command", client_site);
		sprintf(buf, "503 program fault - command not support%c%c", 13, 10);
		write(fd, buf, strlen(buf) );
		break;

	default:
		do_log(2, "%s request an unrecognized command %s", client_site, back);
		sprintf(buf, "500 command not recognized?%c%c", 13, 10);
		write(fd, buf, strlen(buf) );
		break;

	} /*end case*/
	} while(cont);



}




/*
	parse_service --- parsing requested NNTP services
*/
parse_service(cmd)
	char *cmd;	/*requested command*/
{

	if( !strcasecmp(cmd, "POST") )
		return(RFCPOST);

	if( !strncasecmp(cmd, "IHAVE", 5) )
		return(IHAVE);

	if( !strncasecmp(cmd, "CPPOST", 6) )
		return(CPPOST);

	if( !strcasecmp(cmd, "QUIT") )
		return(QUIT);

	if( !strcasecmp(cmd, "ARTICLE") )
		return(ARTICLE);

	if( !strcasecmp(cmd, "BODY") )
		return(BODY);

	if( !strcasecmp(cmd, "GROUP") )
		return(GROUP);

	if( !strcasecmp(cmd, "HEAD") )
		return(HEAD);

	if( !strcasecmp(cmd, "HELP") )
		return(HELP);

	if( !strcasecmp(cmd, "LAST") )
		return(LAST);

	if( !strcasecmp(cmd, "LIST") )
		return(LIST);

	if( !strcasecmp(cmd, "NEWGROUPS") )
		return(NEWGROUPS);

	if( !strcasecmp(cmd, "NEWNEWS") )
		return(NEWNEWS);

	if( !strcasecmp(cmd, "NEXT") )
		return(NEXT);

	if( !strcasecmp(cmd, "SLAVE") )
		return(SLAVE);

	if( !strcasecmp(cmd, "NSTAT") )
		return(NSTAT);

	return(UNRECOGNIZED);
}
/*end of parse_service*/
