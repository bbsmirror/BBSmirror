/****************************************************************************
 * global.h ---  declare some external variables which are used at most     *
 *	 	 modules						    *
 *		 by Samson Chen, Mar 24, 1994				    *
 ****************************************************************************/

#define	PBBS_NNRP_VERSION "v1.1 by Samson Chen, 07/15/1994"

/*
	for debugging
*/
extern	char debug_mode;	/*TRUE for debug mode*/


/*
	basic tested client specifications
*/
extern	char client_site[30];	/*client's readable address*/
