/*******************************************
   DOWNLOAD file from server

    Write by Aquarius Kuo on Apr 9, 1994.
    
********************************************/
#include "../host/pbbs.h"
#include "global.h"

static char rcsid[]="$Id" ;

char buf[32768];

/***************************************
    download file from server to client
*/    
int recv_file(fd,filename)
int fd ;
char *filename ;
{
  int handle,tcpstat ;
  int i ;
  char prot ;
  char fn[80] ;
  long BLOCK=4096 ;
  long bsize[10],bn,bt ;
  long len1, flen ;
  
  strcpy(fn,filename) ;
  if((handle=open(fn,O_CREAT|O_EXCL|O_WRONLY,S_IREAD|S_IWRITE))<0)
  {
    send_mpf(fd," ",0,STOPXFER) ;
    read_mpf(fd,buf,&len1,&prot,FALSE) ;
    unlink(fn);
    return(FALSE) ;
  }
  
  sprintf(buf,"%ld",BLOCK) ;
  send_mpf(fd,buf,strlen(buf),DOWNLOAD) ;
  
  if( read_mpf(fd,buf,&len1,&prot,FALSE)<0)
  {
	unlink(fn);
	return(FALSE);
  }
  buf[len1]=0 ;
  
  send_mpf(fd," ",0,XFER_ACK) ;

  bn=bt=0 ;
  while(1)
  {
    if((tcpstat=read_mpf(fd,buf,&len1,&prot,TRUE))==1)
    {
      if(prot==XFER_ACK)
      {
        bn++ ;
        if(write(handle,buf,len1)<len1)
        {
          send_mpf(fd,"Write error!!",13,STOPXFER) ;
          close(handle) ;
          break ;
        }
        else
        {
          send_mpf(fd," ",0,XFER_ACK) ; 
        }  
      }  
      if(prot==END_XFER)
      {
        close(handle) ;
        break ;
      }
      if(prot==STOPXFER)
      {
        close(handle) ;
        unlink(fn) ;
        break ;
      }
    }
    else
    {
      if(tcpstat==-1)
      {
	do_log(8, "%s TCP error", client_site);
	unlink(fn);
        return(FALSE);
      }  
    }      
  }
  return(TRUE) ;  
}  
