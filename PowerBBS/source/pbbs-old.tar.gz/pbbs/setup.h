/************************************/
/* User set up file for PBBS Server */
/************************************/

#define	PBBS_SERV_PORT	6203
#define SYSTEM_PATH	"."
#define	LOGFILE		"pbbs.log"
#define	LOGLEVEL	2		/*0 is the most detailed logging*/

#define RUN_USER	"OWNER"		/* name or #id, "OWNER" will skip*/
#define RUN_GROUP	"OWNER"		/* name or #id, "OWNER" will skip*/

#define	USER_DATA_BASE	"users"
#define	ON_LINE_USER	"putmp"
#define	TALK_BUFFER	"talk"

/* The following files are under MENU_PATH */
#define	MENU_PATH	"menu"

#define	PRELOG_FILE	"prelog"
#define	WELCOME_FILE	"welcome"
#define	GOODBYE_FILE	"goodbye"
#define	NEWUSER_FILE	"newuser"	/*message for new users*/
#define	LEVEL_MSG	"level"		/*LEVEL_MSG.n will show up when user*/
					/*  of level n login		    */

#define	MAIN_MENU_FILE	"main.mnu"
#define MAIL_MENU_FILE	"mail.mnu"
#define	FILE_MENU_FILE	"file.mnu"
#define TOOL_MENU_FILE	"tools.mnu"

#define	MAIN_HELP_FILE	"main.hlp"
#define MAIL_HELP_FILE	"mail.hlp"
#define	FILE_HELP_FILE	"file.hlp"
#define TOOL_HELP_FILE	"tools.hlp"

/* The following files are under BULLETIN_PATH */
#define	BULLETIN_PATH	"bulletin"

#define	BULLETIN_MENU_FILE	"bulletin.mnu"

/* The following files are under MAIL_PATH */
#define	MAIL_PATH	"mail"

#define	GROUP_LIST	"group.list"

#define	RULES		"rule"	/*files must be under every mail group path*/
				/*this file is optional*/
#define	AREANAME	"areaname"	/*same as RULES*/

#define	MODERATORS	"moderators"	/*moderator name list*/

/* the following sets are under FILE_MENU_PATH */
#define	FILE_PATH	"files"
#define	FILE_AREA_LIST	"files.area"
#define	FILE_LIST	"files.bbs"
#define	INIT_FILE_AREA	"pbbs"
#define	MAX_ALLOW_TAG	10	/*max files that user can tag*/
#define	UPLOAD_PATH	"upload"

/* the following setup if for user login session */
#define	MAX_LOGIN	5	/*max trials for logging in*/
#define	MAX_LOAD	100	/*max users to serve*/
#define	BAD_USER	"baduser"	/*file of baduser data words*/

/* the following setup is for security */
#define	INIT_LEVEL	30	/*level of a new user*/
#define	E_BULLETIN_LVL	90	/*level to edit bulletins*/
#define	SYSOP_LEVEL	99	/*level of SysOp*/
#define	IDLE_TIME	1800	/*max user idle time in seconds*/
#define	POST_FACTOR	5	/*factor to extent idle time when posting*/

/* for chat and talk*/
#define	MAX_CHAT_ROOM	10	/*max chatroom alowance*/
#define	MORE_ROOM_LVL	80	/*reserved chat room*/

/* for timezone conversion */
#define TZ_MIN_WEST	-480	/*minutes-bias from greenwitch to west*/


/*-----------------------------------------------------------------------*/
/* The following setups are for PBBS NNRP interchange program		 */
/*-----------------------------------------------------------------------*/
#define	PBBS_NNTP	"YES"	/*YES/NO to enable or disable nntp function*/

#define	NNRP_PORT	7203	/*interchange port. note: this cannot be*/
				/*  the same as PBBS_SERV_PORT*/
#define	NNRP_LOG	"nnrp.log"	/*log file*/
#define	NNRP_LOGLEVEL	5	/*same as LOGLEVEL but used at pbbsnnrpd*/
#define	NNRP_IDLE	7200	/*NNTP transfer idle time*/
				/*set a long time is OK*/

#define	NNTP_GROUP	"group.nntp"	/*this should be put under MAIL_PATH*/
					/*	at setup.h*/

#define	STATION_ID	"nhctc_pbbs"
				/*this is used at path field of NNTP-POST*/
				/*it will be used for duplicate checking*/
				/*so, do not use the same id as others*/
				/*note: please do not use 'pbbs' as the*/
				/*station id*/

#define	NNRP_DOMAIN	"cc.nhctc.edu.tw"
				/*full domain name used at message id*/

#define	SORGANIZATION	"NHCTC's PowerBBS Original Station"
				/*organization used for RFC977 standard*/



/*-----------------------------------------------------------------------*/
/* The following setups are for PBBS NNTP interchange program		 */
/*-----------------------------------------------------------------------*/

#define	NNTP_LOG	"nntp.log"	/*log file*/
#define	NNTP_LOGLEVEL	4	/*same as LOGLEVEL but used at pbbsnnrpd*/
#define	NNTP_IDLE	600	/*NNTP transfer idle time*/
#define	NNTP_SLEEP	300	/*packing interval*/
#define	NNTP_QUEUE	"s_queue"	/*sending queue*/

#define	ZIP		"gzip"	/*compress program*/
#define	UNZIP		"gzip -d -c"	/*you must do console output*/
