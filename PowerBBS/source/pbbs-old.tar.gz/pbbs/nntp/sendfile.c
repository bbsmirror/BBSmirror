/*************************************************************************
 * sendfile.c --- send file to client					 *
 *	      by Aquarius Kuo, Apr 12, 1994				 *
 *************************************************************************/

#include "../host/pbbs.h"
#include "global.h"

static char rcsid[]="$Id: sendfile.c,v 1.2 1994/07/20 04:46:32 pbbs Exp pbbs $";

/*
	send_file --- send a file to client site
*/
int send_file(fd, filename)
int fd;
char *filename;
/*
	return:
		TRUE: oK
		FASLE: failed
*/
{
  int handle ;
  int i ;
  char prot ;
  char fn[80], *ptr ;
  char buffer[11000] ;
  long BLOCK ;
  long fl, len, len2 ;

    
  ptr=filename+strlen(filename)-1 ;
  while((*ptr!='/') && (ptr!=filename))
    ptr-- ;
  
  ptr=(ptr==filename) ? ptr:ptr+1 ;  
  strcpy(fn,ptr) ;
  for(i=0; i<strlen(fn); i++)	/*--- check file name ---*/
  {
    if(fn[i]<33)
    {
      fn[i]=0 ;  
      break ;
    }  
  }  

  do_log(3, "%s sendfile %s", current_station, fn);

  send_mpf(fd, fn, strlen(fn), DOWNLOAD);	/*--- send file name ---*/
  if( debug_mode ) 	printf("(sendfile.c) filename = %s\n",fn) ;
  if( read_mpf(fd,buffer,&len,&prot,FALSE)<0 ) 	/*--- read BLOCK size ---*/
	return(FALSE);
  if(prot!=DOWNLOAD)
  {
    send_mpf(fd," ",0,STOPXFER);
    return(FALSE) ;
  }  
  buffer[len]=0 ;
  sscanf(buffer,"%ld",&BLOCK) ;
  if( debug_mode ) printf("(sendfile.c) BLOCK size = %d\n",BLOCK) ;
  if((BLOCK>11000) || (BLOCK<100))
  {
    do_log(9,"%s illegal block size %s",current_station,buffer) ;
    send_mpf(fd," ",0,STOPXFER);
    return(FALSE) ;
  }    
  fl=flength(filename) ;
  sprintf(buffer,"%ld",fl) ;
  if( debug_mode )	printf("(sendfile.c) file length = %s\n",buffer) ;
  if( send_mpf(fd,buffer,strlen(buffer),DOWNLOAD)<0 )	/*--- send file length ---*/
	return(FALSE);
  
  
  if( read_mpf(fd,buffer,&len,&prot,FALSE)<0 )
	return(FALSE);

  if(prot==XFER_ACK)
  {
    if((handle=open(filename,O_RDONLY))<0)
    {
      if(debug_mode)	printf("(sendfile.c)open %s error!\n",fn) ;
      send_mpf(fd," ",0,STOPXFER) ;
      return(FALSE) ;
    }
    len=BLOCK ;
    if(len>fl)
      len=fl ;
    read(handle,buffer,len) ;
    if( send_mpf(fd,buffer,len,XFER_ACK)<0 )
	return(FALSE);
    
    if( read_mpf(fd,buffer,&len2,&prot,FALSE)<0 )
	return(FALSE);
    if(prot==STOPXFER)  
    {
      if(debug_mode) printf("(sendfile.c)got STOPXFER(a)\n");
      close(handle) ;
      return(FALSE) ;
    }  
    
    while((fl-len)>BLOCK)
    {
      read(handle,buffer,BLOCK) ;
      if(debug_mode) printf("sendfile.c)block data sent\n");
      if( send_mpf(fd,buffer,BLOCK,XFER_ACK)<0 )
	return(FALSE);

      if( read_mpf(fd,buffer,&len2,&prot,FALSE)<0)
	return(FALSE);

      if(prot==STOPXFER)
      {
        if(debug_mode) printf("(sendfile.c)got STOPXFER(b)\n");
        close(handle) ;  
        return(FALSE) ;
      }  
      else  
        len+=BLOCK ;
    }   
    len=fl-len ;
    read(handle,buffer,len) ;
    if( send_mpf(fd,buffer,len,XFER_ACK)<0)
	return(FALSE);

    if(debug_mode) printf("(sendfile.c)XFER_ACK sent\n");

  }
  if( read_mpf(fd,buffer,&len,&prot,FALSE)<0)
	return(FALSE);

  if( send_mpf(fd," ",0,END_XFER)<0)
	return(FALSE);

  return(TRUE) ;
}
/*end of send_file*/
