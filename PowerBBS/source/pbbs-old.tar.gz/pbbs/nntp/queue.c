/*************************************************************************
 * queue.c --- sending queue control					 *
 *	       by Samson Chen, Apr 15, 1994				 *
 *************************************************************************/

#include "../host/pbbs.h"
#include "global.h"

static char rcsid[]="$Id: queue.c,v 1.4 1994/07/06 18:20:34 pbbs Exp pbbs $";


/*
	check_queue --- check packing file in queue directory
			if compress post, compress the msg pack
*/
check_queue(index, msgpack)
	char *index;
	char *msgpack;
/*
	return:
		TRUE: msgpack ok
		FALSE: msgpack empty
*/
{
	char zip_exe[128];
	char link_level[20];
	int ret;

	if( flength(msgpack)<5 )
	{
		if(debug_mode) printf("(queue.c)unlink %s\n", msgpack);
		unlink(msgpack);

		return(FALSE);
	}


	get_passwd_by_index(index, link_level);
	if( strcmp(link_level, "+") )		/*Compressed Post*/
	{
		sprintf(zip_exe, "%s %s", ZIP, msgpack);
		ret=system(zip_exe);

		do_log(0, "%s : %d", zip_exe, ret);
	}

	return(TRUE);
}
/*end of check_queue*/

