/****************************************************************************
 * queue.h ---  sending queue structure					    *
 *		by Samson Chen, Apr 15, 1994				    *
 ****************************************************************************/

/*
	queue structure rec#0 is a status record which
	rec #0 active='E' : empty
	       active='W' : wait
	       active='I' : in-trans

	other records,
		active='X' : empty
		active='A' : active
	
		type='M' : msg pack
		type-'D' : delete signal

	crlf is just for user readable
*/
struct queue_struct {
	char	active;
	char	type;
	char	msgpack[80];
	char	lf;
};
