/*************************************************************************
 * misc.c --- misc. functions						 *
 *	      by Samson Chen, Mar 24, 1994				 *
 *************************************************************************/

#include <varargs.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include "../host/pbbs.h"
#include "global.h"



/*
	do logging --- (as the name)
	note: init_log was removed, so that, logging file can be erased and
	      re-create.
*/
do_log(loglevel, logformat, va_alist)
	int loglevel;
	char *logformat;
	va_dcl
{
	char timing[50];
	char buffer[620];
	char logmsg[600];
	FILE *logfile;

	/*get arguments list*/
	va_list args;
	va_start(args);
	vsprintf(logmsg, logformat, args);
	va_end(args);

	get_daytime(timing);
	sprintf(buffer, "%s,%d> ", timing, loglevel);

	strcat(buffer, logmsg);

	/*for debugging use*/
	if( debug_mode ) printf("%s\n", buffer);

	if(loglevel>=NNTP_LOGLEVEL)
	{
		logfile = fopen(NNTP_LOG, "a+");
		if( logfile==NULL )
		{
			if(debug_mode) printf("(misc.c)open log file error\n");
			return;
		}

		fprintf(logfile, "%s\n", buffer);
		fclose(logfile);
	}
}
/*end of do_log*/



/*
	get day and time
*/
get_daytime(buffer)
	char *buffer;	/*CAUTION: buffer must has it's own space befor
				   calling*/
{
	struct	tm	*timeptr;
	time_t		secsnow;

	time(&secsnow);
	timeptr = localtime(&secsnow);

	sprintf(buffer, "%#02d/%#02d,%#02d:%#02d", timeptr->tm_mon+1, timeptr->tm_mday , timeptr->tm_hour, timeptr->tm_min);
}
/*end of daytime*/



/*
	test if the file exist or not
*/
file_exist(filename)
char *filename;
/*
	return: TRUE: exist
		FALSE: not exist
*/
{
	FILE *testexist;

	if( (testexist=fopen(filename, "r")) == NULL)
		return(FALSE);		/*not found*/
	else	/*file found*/
	{
		fclose(testexist);
		return(TRUE);
	}
}
/*end of file_exist*/



/*
	test if the path exist or not
*/
path_exist(pathname)
char *pathname;
{
	int ret;
	struct stat buf;

	ret=stat(pathname, &buf);

	if( ret<0 )
		return(FALSE);	/*path not exist*/

	if( (buf.st_mode & S_IFDIR)==0 )
		return(FALSE);	/*not a path*/

	return(TRUE);
}
/*end of path_exist*/



/*
	flength --- get length of a file
*/
long flength(filename)
	char *filename;
{
	int test;
        struct stat buf;

        test=open(filename, O_RDONLY);
        fstat(test, &buf);
	close(test);

        return(buf.st_size);
}
/*end of flength*/



/*
	trim_comment --- strip blanks, tabs, and chars after #
*/
trim_comment(line)
	char *line;	/*buffer to be trimmed*/
{
	char buf[256];
	char *p;
	int n;
	char next_word=FALSE;

	nstrcpy(buf, line, 256);
	p=line;

	for(n=0; n<strlen(buf); n++)
	{
		if(buf[n]=='#' || buf[n]==13 || buf[n]==10) break;
		if(buf[n]==32 || buf[n]==9)
		{
		  if( next_word )
		  {
			*p=32;
			p++;
			next_word=FALSE;
		  }
		  continue;
		}

		next_word=TRUE;
		*p=buf[n];
		p++;
	}

	*p=0;

	n=strlen(line);
	if(n>0)
	  if(line[n-1]==32) line[n-1]=0;
}
/*end of trim_comment*/



/*
	next_char --- find next [char] in the string
*/
next_char(str, c)
	char *str;
	char c;		/*char to be searched*/
/*
	return: position : 0 to n
*/
{
	int l, n=0;

	for(l=0; l<strlen(str); l++)
	{
		if( str[l]==c || str[l]==0)
			break;

		n++;
	}

	return(n);
}
/*end of next_char*/



/*
	next_blank --- find next blank in the string
*/
next_blank(str)
	char *str;
/*
	return: position : 0 to n
*/
{
	return( next_char(str, 32) );
}
/*end of next_blank*/



/*
	next_comma -- find next [,] in the string
*/
next_comma(str)
	char *str;
/*
	return: position : 0 to n
*/
{
	return( next_char(str, ',') );
}
/*end of next_comma*/



/*
	by KKY, just strip head and tail
*/
int alltrim(str)
char *str ;
/*******************************************
    return     0   : if NULL string
            length : the new strlen.
********************************************/            
{
  int i=0 ;
  
    while((*(str+i)==32) || (*(str+i)==9))
    {
      i++ ;
    }  
    memcpy(str,(str+i),strlen(str)-i+1) ;
        
    i=strlen(str)-1 ;
    while(((*(str+i)==32) || (*(str+i)==9)) && (i>=0))
    {
      i-- ;
    }
    *(str+i+1)=0 ;
    
    return(strlen(str)) ;
}     
/*end of alltrim*/



/*
	check_path --- check if station is in the m_path or not
*/
check_mpath(m_path, station)
	char *m_path;	/*path like chpi!csie!ccit */
	char *station;	/*the station id to be checked*/
/*
	return:
		TRUE:	exist
		FALSE:	not exist
*/
{
	char line[2048];
	char *token;

	nstrcpy(line, m_path, 2048);

	token=strtok(line, "!");
	while( token != NULL )
	{
		if( !strcmp(token, station) )
			return(TRUE);

		token=strtok(NULL, "!");
	}

	return(FALSE);
}
/*end of check_mpath*/



/*
	ltoa --- unsigned long to ascii with base n
*/
ltoa(number, buffer, base)
        unsigned long number;
        char *buffer;
        char base;
{
        char *idmap="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        unsigned long n;
        char buf[128];
        char *p;
        char nbase;

        nbase=base;

        if( nbase<=1 )
                nbase=strlen(idmap);

        n=number;

        memset(buf, 0, 128);
        p=buf+126;

        do
        {
                *p=idmap[n%nbase];
                p--;
                n/=nbase;
        } while(n>0);

        strcpy(buffer, p+1);
}
/*end of ltoa*/



/*
	get_unique --- assemble unique-ID by time
*/
get_unique(unique_id)
	char *unique_id;
{
	char buf[80];
	unsigned long longtime;

	time(&longtime);
	ltoa(longtime, buf, 0);
	nstrcpy(unique_id, buf, 30);
}
/*end of get_unique*/



/*
	find_nl --- find the new-line (0xa ir 0xd) in a string
*/
find_nl(string, fc)
	char *string;
	char *fc;	/*the finding char*/
/*
	return:
		n: the position for first nl char (0xa or 0xd)
		which *fc will be the char
*/
{
	char *p;
	int len;
	int n;

	p=string;
	len=strlen(string);

	for(n=0; n<len; n++)
		if(string[n]==10 || string[n]==13 || string[n]==0)
		{
			*fc=string[n];
			break;
		}

	return(n);
}
/*end of find_nl*/



/*
	lock_pid --- lock a file to prevent from duplicat running
*/
lock_pid()
/*
	return:
		TRUE:	OK.
		FALSE:	flaied, maybe programm has been running
*/
{
	int lock;
	char pidfile[128];
	char pid[10];
	int ret;

	sprintf(pid, "%5d\n", getpid() );

	sprintf(pidfile, "pbbsnntpd.pid");
	lock=open(pidfile, O_WRONLY | O_CREAT, S_IWUSR | S_IRUSR);

	/*test locking*/
	ret=flock(lock, LOCK_EX | LOCK_NB);

	if( ret<0 )
		return(FALSE);	/*open pid file error, maybe lock exist*/

	write(lock, pid, strlen(pid) );

	return(TRUE);
}
/*end of lock_pid*/



/*
	strip_nl --- strip cr-lf
*/
strip_nl(buf)
	char *buf;
{
	int n;
	int len;

	len=strlen(buf);

	for(n=0; n<len; n++)
		if( buf[n]==0 || buf[n]==13 || buf[n]==10 )
		{
			buf[n]=0;
			break;
		}
}
/*end of strip_nl*/



/*
	nstrcpy --- some stange STRING hate strcpy... also size control is
		    needed
*/
nstrcpy(t, s, ms)
	char *t;	/*target*/
	char *s;	/*source*/
	int ms;		/*max size*/
{
	int cpn;

	for(cpn=0; cpn<ms; cpn++)
	{
		t[cpn]=s[cpn];

		if(s[cpn]==0)
			break;
	}

	t[ms-1]=0;
}
/*end of nstrcpy*/



/*
	file_length --- return the size of fd
*/
file_length(fd)
        int fd;
{
        struct stat buf;
        fstat(fd, &buf);
        return(buf.st_size);
}



/*
	file_good --- test if file open ok
*/
file_good(fn)
	char *fn;
{
	FILE *test;
	char ret;

	test=fopen(fn, "r");

	if( test != NULL )
		ret=TRUE;
	else
		ret=FALSE;

	fclose(test);

	return(ret);
}
/*end of file_good*/



/*
	getuidbyname --- get system uid by RUN_USER
*/
getuidbyname(name)
	char *name;
{
	struct passwd *ent;

	if( name[0]=='#' )
		return(atoi(name+1));

	ent=getpwnam(name);

	if( !ent )
	{
		do_log(9, "BAD RUN_USER '%s' setup!", RUN_USER);
		return(-1);
	}
	else
		return(ent->pw_uid);

}
/*end of getuidbyname*/



/*
	getgidbyname --- get system group id by RUN_GROUP
*/
getgidbyname(name)
	char *name;
{
	struct group *ent;

	if( name[0]=='#' )
		return(atoi(name+1));

	ent=getgrnam(name);

	if( !ent )
	{
		do_log(9, "BAD RUN_GROUP '%s' setup!", RUN_GROUP);
		return(-1);
	}
	else
		return(ent->gr_gid);

}
/*end of getgidbyname*/



/*
	change_run_id --- change process running id
*/
change_run_id()
{
	int user_id, group_id;

	if( !strcmp(RUN_USER, "OWNER") || !strcmp(RUN_GROUP, "OWNER") )
		return;

	user_id=getuidbyname(RUN_USER);
	group_id=getgidbyname(RUN_GROUP);

	if( user_id<0 || group_id<0 )
		return;

	/*set log file permission first*/
	if( file_exist(NNTP_LOG) )
		chown(NNTP_LOG, (uid_t) user_id, (gid_t) group_id);

	/*set gid then uid*/
	if( setgid((gid_t) group_id)==-1 )
		do_log(9, "set gid failed!?");

	if( setuid((uid_t) user_id)==-1 )
		do_log(9, "set uid failed!?");
}
/*end of change_run_id*/
