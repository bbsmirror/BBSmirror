/*************************************************************************
 * sending.c --- sending control					 *
 *	       by Samson Chen, Apr 15, 1994				 *
 *************************************************************************/

#include "../host/pbbs.h"
#include "global.h"

static char rcsid[]="$Id: sending.c,v 1.13 1994/08/02 09:03:34 pbbs Exp pbbs $";


/*
	do_sending --- transmit the packet
*/
do_sending(index, ip, port, passwd, msgpackfile)
	char *index;
	char *ip;
	char *port;
	char *passwd;
	char *msgpackfile;
{
	char pkt_error;
	int fd;
	char line[1024];
	char response[1024];
	char bpack[80];
	char bad_pack[80];
	FILE *pkt;
	char got_post;
	char skip_current_post;
	int ret;
	char mid_back[40];
	int ncount;

	/*------------------------------------------------------------*/

	/**************/
	/*TRANSMITTING*/
	/**************/

	if(debug_mode) printf("(sending.c)start transmission %s\n", index);

	/*open connection*/
	fd=connectTCP(ip, atoi(port));

	  if(debug_mode) printf("(sending.c)%s connectted! fd=%d\n", current_station, fd);

	if(fd<0)
	{
		xmit_error=TRUE;
	}
	else
	{
		global_fd=fd;

		if( get_response(fd, response)<0 )
		{
			xmit_error=TRUE;
		}
		else
		{

		  if(debug_mode) printf("(sending.c)%s: %s\n", index, response);

		  if( response[0]=='4' || response[0]=='5' )
		  {
			  /*some err occurred*/
			  xmit_error=TRUE;
			  do_log(9, "%s sending ERROR: %s", current_station, response);
		  }
		}
	}



	if( !xmit_error )
	{

		if( strcmp(passwd, "+" ) )
		{

		/********************************************************/
		/*PowerBBS MPF Sending					*/
		/********************************************************/

			sprintf(response, "CPPOST %s%c%c", passwd, 13, 10);
			write(fd, response, strlen(response) );

			if( get_response(fd, response)<0 )
			{
				xmit_error=TRUE;
				do_log(9, "%s CPPOST failed", current_station);
			}
			else
			{
			    ret=check_nntp_error(response);
			    do_log(0, "%s response: %s", current_station, response);

			    if(ret==-1)
			    {
				    xmit_error=TRUE;
				    do_log(9, "% posting error: %s", current_station,  response);
			    }

			    if( !xmit_error )
			    {
			      /*start mpf sending*/
			      sprintf(bpack, "%s/%s", NNTP_QUEUE, msgpackfile);
			      do_log(0, "%s sending %s", current_station, bpack);

			      /*check pack file*/
			      if( file_good(bpack) )
				pkt_error=FALSE;
			      else
				pkt_error=TRUE;

			      if( !pkt_error )
			      {
				    ret=send_file(fd, bpack);
				    if( !ret )
				    {
					xmit_error=TRUE;
					do_log(9, "sending pack file %s to %s failed!", bpack, current_station);
				    }
			      }

			      /*take response message*/
			      if( !pkt_error && !xmit_error )
			      {
			        if( get_response(fd, response)<0 )
				{
					xmit_error=TRUE;
					do_log(9, "waiting MPF-send response from %s failed!", current_station);
				}

			        do_log(0, "%s response: %s", current_station, response);
			      }
			    }/*end if( !xmit_error )*/

			}/*end if-else*/

		}
		else
		{

		/*********************************************************/
		/*RFC 977 sending					 */
		/*********************************************************/

		pkt_error=FALSE;
		sprintf(bpack, "%s/%s", NNTP_QUEUE, msgpackfile);
		pkt=fopen(bpack, "r");
		if( pkt==NULL )
		{
			do_log(9, "open %s error", bpack);
			pkt_error=TRUE;
		}

		got_post=TRUE;
		skip_current_post=FALSE;

		if( !pkt_error )
		{
		while( fgets(line, 1023, pkt) )
		{
		  if(xmit_error)
			break;

		  if(got_post)
		  {
			got_post=FALSE;
			skip_current_post=FALSE;

			nstrcpy(mid_back, line+12, 40);
			for(ncount=0; ncount<strlen(mid_back); ncount++)
			  if( mid_back[ncount]==13 || mid_back[ncount]==10 )
			  {
				/*strip trailing cr-lf*/
				mid_back[ncount]=0;
				break;
			  }

			sprintf(response, "IHAVE %s", line+12);
			write(fd, response, strlen(response) );
			if( get_response(fd, response)<0 )
			{
				xmit_error=TRUE;
			}
			else
			{
			    ret=check_nntp_error(response);
			    do_log(0, "%s response: %s", current_station, response);

			    if(ret==0)
			    {
				    skip_current_post=TRUE;
				    do_log(5, "%s post skip error: %s",current_station,  response);
				    do_log(5, "%s skip mid: %s", current_station, mid_back);
			    }

			    if(ret==-1)
			    {
				    xmit_error=TRUE;
				    do_log(9, "% posting error: %s", current_station,  response);
				    do_log(9, "%s error mid: %s", current_station, mid_back);
			    }

			    continue;	/*skip first line*/
			}/*end if(get_response)*/

		     }/*end if*/

		     if( !xmit_error )
		     {
			 if( !skip_current_post )
			 {
			    if( (ret=write(fd, line, strlen(line) ))<0 )
				xmit_error=TRUE;

			    if(debug_mode) printf("(sending.c)%d send %s : %s", ret,  current_station, line);
			 }

			 if( strlen(line)==3 && line[0]=='.' )
			 {
			    got_post=TRUE;

			    if( skip_current_post )
			    {
				skip_current_post=FALSE;
				continue;
			    }

			    if( get_response(fd, response)<0 )
				xmit_error=TRUE;

			    do_log(0, "%s : %s", current_station, response);

			    ret=check_nntp_error(response);
			    if(ret==-1)
				    xmit_error=TRUE;
			 }
		     }/*end if(xmit_error)*/

		}/*end while*/

		fclose(pkt);
		}/*end if(!pkt_error)*/

		/************************************************************/
		/************************************************************/

		}/*end if*/

		if( !xmit_error && !pkt_error )
		{
			unlink(bpack);
			if(debug_mode) printf("(sending.c)unlink %s\n", bpack);
		}

		if( pkt_error )	/*rename the bad pack file to bad.<name>*/
		{
			sprintf(bad_pack, "%s/bad.%s", NNTP_QUEUE, msgpackfile);
			rename(bpack, bad_pack);
		}

	} /*end if*/

	if( !xmit_error )
	{
		sprintf(response, "QUIT%c%c", 13, 10);
		write(fd, response, strlen(response) );
		do_log(5, "QUIT connection of %s", current_station);
	}
	else
		do_log(8, "%s connection xmit error", current_station);

	close(fd);

}
/*end of do_sending*/



/*
	get_response --- get remote response from network
*/
get_response(fd, rsp)
	int fd;
	char *rsp;
/*
	return:
		0: ok
		-1: abnormal_disconnect
*/
{
	int ret;
	char *p;
	int n;

      do
      {
	reset_alarm();
	p=rsp;
	ret=0;
	do {
		p+=ret;
		ret=read(fd, p, 1023);
		if( ret<=0 )
		{
			do_log(8, "%s abnormal_disconnect", current_station);
			return(-1);
		}
	}while( p[ret-1]!=10 );
	p[ret]=0;

	/*trail unnacessary chars*/
	for(n=0; n<strlen(rsp); n++)
	  if( rsp[n]==13 || rsp[n]==10 )
	  {
		rsp[n]='\0';
		break;
	  }


	while( rsp[strlen(rsp)-1] == '\n' || rsp[strlen(rsp)-1] == '\r')
		rsp[strlen(rsp)-1]='\0';

	alltrim(rsp);
	if( strlen(rsp)==0 ) continue;	/*skip null*/

	if(debug_mode) printf("(sending.c)get response %s\n", rsp);

	break;

      }while(1);

      stop_alarm();

      return(0);
}
/*end of get_response*/



/*
	check_nntp_error --- check response number
*/
check_nntp_error(rsp)
	char *rsp;
/*
	return:
		1: OK
		0: error level one (skip only one message)
	       -1: fatal error, should close connection
		
*/
{
	if( rsp[0]!='4' && rsp[0]!='5' )
		return(1);

	/*level -1 checking*/
	if( !strncmp(rsp, "436", 3) )
		return(-1);

	/*	--DO NOT TRY AGAIN ERROR--
	if( !strncmp(rsp, "437", 3) )
		return(-1);
	*/

	if( !strncmp(rsp, "440", 3) )
		return(-1);

	if( !strncmp(rsp, "441", 3) )
		return(-1);

	if( !strncmp(rsp, "500", 3) )
		return(-1);

	if( !strncmp(rsp, "501", 3) )
		return(-1);

	if( !strncmp(rsp, "502", 3) )
		return(-1);

	if( !strncmp(rsp, "503", 3) )
		return(-1);

	return(0);	/*level 0 error*/
}
/*end of check_nntp_error*/
