/*************************************************************************
 * page.c --- write message to on-line user				 *
 *	      by Samson Chen, May 14, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "dbf.h"
#include "global.h"



/*
	write_user --- send message to on-line user
*/
write_user(fd)
	int fd;
{
	char answer[80];
	int sig_rec;
	struct udb urec;
	struct putmp purec;
	char line[128];
	int msg;
	char crlf[3];
	char info[25];

	asking(fd, WRITE_WHO, answer, 20);
	process_user_name(answer);

	strip_nl(answer);
	if(answer[0]==0 || answer[0]==10 || answer[0]==13)
		return;

	sprintf(crlf, "%c%c", 13, 10);

	for(sig_rec=0; sig_rec<(flength(ON_LINE_USER)/sizeof(struct putmp)); sig_rec++)
	{
		get_putmp(&purec, sig_rec);

		if( purec.active )
		{
		  get_user_data(&urec, purec.uid);

		  if( !strcmp(urec.bbs_name, answer) )
		  {
			if( ((urec.user_set[0] & 1)==1) && (!system_operator) )
			{
				sprintf(line, "%s%s", urec.bbs_name, USER_OFF_PAGE);
				display_msg(fd, line);
				suspend(fd);
				return;
			}

			/*edit message*/
			sprintf(line, "%s/talk.%d", TALK_BUFFER, user_uid);
			msg=open(line, O_WRONLY | O_CREAT | O_TRUNC, S_IWUSR | S_IRUSR);

			if(debug_mode) printf("(page.c)creat signal message %s\n", line);

			sprintf(line, "\n%s%s", user_name, WRITE_YOU);
			write(msg, line, strlen(line));

			sprintf(answer, "%c%c%c", 7, 13, 10);
			write(msg, answer, 3);	/*a BEEP*/

			/*get messages*/
			display_msg(fd, TALK_WHAT);
			do
			{
			  asking(fd, ">", answer, 80);
			  strip_nl(answer);
			  if( strlen(answer)==1 && answer[0]=='.' )
				break;
			  write(msg, answer, strlen(answer) );
			  write(msg, crlf, strlen(crlf));
			} while(1);
			close(msg);

			asking(fd, CONFIRM_MSG, answer, 2);
			if( answer[0]!='y' && answer[0]!='Y' )
				return;

			/*re-get putmp status, maybe user change status*/
			/*	when typing messages		       */
			get_putmp(&purec, sig_rec);

			if( !purec.active )
			{
				/*user logout at that time*/
				display_msg(fd, NOT_ON_LINE_NOW);
				suspend(fd);
			}

			switch(purec.act_stat)
			{
			case 7:
			case 8:
			case 9:
			case 10:
			case 11:
				descript_stat(info, 25, purec.act_stat, purec.act_info);
				sprintf(line, "%s%s%s\n", urec.bbs_name, CANNOT_PAGE, info);
				display_msg(fd, line);
				suspend(fd);
				break;
			  default:
				purec.page_mode=0;
				purec.page_uid=user_uid;
				set_putmp(&purec, sig_rec);
				kill(purec.pid, SIGUSR1);
				break;

			}

			return;
		  }
		}
	}

	display_msg(fd, NOT_ON_LINE_NOW);
	suspend(fd);
}
/*end of write_user*/

