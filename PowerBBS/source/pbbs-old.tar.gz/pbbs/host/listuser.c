/*************************************************************************
 * listuser.c --- list users and SysOp functions			 *
 *	      by Samson Chen, Apr 9, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"
#include "dbf.h"

static char rcsid[]="$Id: listuser.c,v 1.11 1994/07/28 16:13:05 pbbs Exp pbbs $";


char scrbuf[9120];
char bigbuf[MAX_BUF];


/*
	list_users --- (as the name)
*/
list_users(fd)
	int fd;
{
	char list_mode[3];
	char answer[80];
	char line[300];
	char info[25];
	int n;
	int list_uid;
	struct udb rec;
	int scr_size;	/*client's screen size*/
	int scr_cnt;
	int rlen;
	char protocol;
	char leave;
	char no_more;
        int utf;
        struct putmp purec;
	int sysop_talk;
	int sig_rec;
	char crlf[3];
	int bulletin_file;
	char pn[80];

	if( system_operator )
		asking(fd, SYSOP_LIST_MODE, list_mode, 2);
	else if( user_level>=E_BULLETIN_LVL )
		asking(fd, CO_SYSOP_LIST_MODE, list_mode, 2);
	else if( group_moderator )
		asking(fd, MODERATOR_LIST_MODE, list_mode, 2);
	else
		asking(fd, LIST_MODE, list_mode, 2);

	sprintf(crlf, "%c%c", 13, 10);

	switch( list_mode[0] )
	{

	/***********************************************************/

	case '1':	/*specific user*/

		if(debug_mode) printf("(listuser.c)case 1\n");

		asking(fd, LIST_WHO, answer, 20);
		process_user_name(answer);

		/*************/
		/*search user*/
		/*************/

		if( system_operator )
		{
		  list_uid=atoi(answer);	/*accept user_id input*/

		  if( list_uid>=get_total_user_recs() )
			list_uid=0;	/*input too large*/
		}
		else
			list_uid=0;

		if( list_uid<=0 )
			list_uid=get_user_id(answer);

		/*******************/
		/*user found or not*/
		/*******************/
		if(list_uid==0)
		{
			display_msg(fd, NO_SUCH_USER);
			suspend(fd);
			return;
		}

		/*****************/
		/*get user record*/
		/*****************/
		get_user_data(&rec, list_uid);

		/****************************/
		/*if account disabled or not*/
		/****************************/
		if( rec.delete_mark=='X' || rec.delete_mark=='*' )
		{
			display_msg(fd, NO_SUCH_USER);
			suspend(fd);
			return;
		}

		/******/
		/*list*/
		/******/
		display_msg(fd, "\n");

		if( system_operator )
		{
			sprintf(line, "%s%d\n", CP_USER_ID, list_uid);
			display_msg(fd, line);
		}

		sprintf(line, "%s%s\n", CP_BBS_NAME, rec.bbs_name);
		display_msg(fd, line);

		if( system_operator )
		{
			sprintf(line, "%s%s\n", CP_REAL_NAME, rec.real_name);
			display_msg(fd, line);
		}

		sprintf(line, "%s%s\n", CP_EMAIL_ADD, rec.email);
		display_msg(fd, line);
		sprintf(line, "%s%s\n", CP_INTEREST, rec.interest);
		display_msg(fd, line);
		sprintf(line, "%s%s\n", CP_SPEC, rec.spec);
		display_msg(fd, line);

		if( system_operator )	/*for SysOp ONLY*/
		{
			/*
			sprintf(line, "%s%s\n", CP_TERM, rec.term);
			display_msg(fd, line);
			*/
			sprintf(line, "%s%s\n", CP_ADDRESS, rec.address);
			display_msg(fd, line);
			sprintf(line, "%s%s\n", CP_PHONE, rec.phone);
			display_msg(fd, line);
			sprintf(line, "%s%c\n", CP_SEX, rec.sex);
			display_msg(fd, line);
			sprintf(line, "%s%d\n", CP_LEVEL, rec.level);
			display_msg(fd, line);
		}

		sprintf(line, "%s%d\n",CP_TOTAL_LOGIN,rec.total_login);
		display_msg(fd, line);
		sprintf(line, "%s%s\n", CP_LAST_LOGIN, rec.last_login);
		display_msg(fd, line);

		display_msg(fd, "\n");
		suspend(fd);

		break;

	/***********************************************************/

	case '2':	/*all*/

		if(debug_mode) printf("(listuser.c)case 2\n");

		send_mpf(fd, NULL, 0, SCRSIZE);
		read_mpf(fd, answer, &rlen, &protocol, FALSE);
		if( protocol != SCRSIZE )
		{
			do_log(8, "%s protocol_stat_err with protocol code %d at list_users(case 2)", user_name, protocol);
			protocol_stat_err(fd);
		}

		answer[rlen]=0;
		strip_nl(answer);
		scr_size=atoi(answer);
		if(debug_mode) printf("(listuser.c)get screen size %d\n", scr_size);

		display_msg(fd, "\n");
		leave=FALSE;
		no_more=TRUE;
		scr_cnt=0;
		n=0;
		scrbuf[0]=0;
		do
		{
			n++;
			scr_cnt++;

			if( !get_user_data(&rec, n) )
			{
				leave=TRUE;
				continue;
			}

			if( rec.delete_mark=='X' )
				continue;

			if( !system_operator )
			  sprintf(line, "%c %4d %-20s %-40s\n", rec.delete_mark, n, rec.bbs_name, rec.email);
			else
			  sprintf(line, "%c %4d %-20s %-10s %3d %-30s\n", rec.delete_mark, n, rec.bbs_name, rec.real_name, rec.level, rec.email);

			strcat(scrbuf, line);
			no_more=FALSE;

			if( scr_cnt>= scr_size-2 )
			{
				display_msg(fd, scrbuf);
				asking(fd, IF_CONTINUE, answer, 2);
				if( answer[0]=='n' || answer[0]=='N' )
				{
					leave=TRUE;
					no_more=TRUE;
					continue;
				}

				scr_cnt=0;
				scrbuf[0]=0;
				no_more=TRUE;
			}

		} while( !leave );

		if(!no_more)
		{
			display_msg(fd, scrbuf);
			suspend(fd);
		}

		break;

	/***********************************************************/

	case '3':	/*on-line*/

		if(debug_mode) printf("(listuser.c)case 3\n");

		send_mpf(fd, NULL, 0, SCRSIZE);
		read_mpf(fd, answer, &rlen, &protocol, FALSE);
		if( protocol != SCRSIZE )
		{
			do_log(8, "%s protocol_stat_err with protocol code %d at list_users(case 3)", user_name, protocol);
			protocol_stat_err(fd);
		}

		answer[rlen]=0;
		strip_nl(answer);
		scr_size=atoi(answer);
		if(debug_mode) printf("(listuser.c)get screen size %d\n", scr_size);

		scr_cnt=0;
		n=0;
		leave=FALSE;
		utf=open(ON_LINE_USER, O_RDONLY);
		display_msg(fd, "\n");
		while( read(utf, &purec, sizeof(struct putmp) ) && !leave )
		{
			if( purec.active )
			{
				if( !get_user_data(&rec, purec.uid) )
					continue;

				scr_cnt++;
				n++;

				descript_stat(info, 25, purec.act_stat, purec.act_info);

				if( !system_operator )
				  sprintf(line, "%3d %-18s %-19s %-25s\n", n, rec.bbs_name, purec.from, info);
				else
				  sprintf(line, "%3d %4d %-18s %-19s %-25s\n", n, purec.uid, rec.bbs_name, purec.from, info);

				display_msg(fd, line);

				if( scr_cnt>= scr_size-2 )
				{
					asking(fd, IF_CONTINUE, answer, 2);
					if( answer[0]=='n' || answer[0]=='N' )
					{
						leave=TRUE;
						continue;
					}

					scr_cnt=0;
				}
			}
		}/*end while*/

		display_msg(fd, "\n");
		suspend(fd);

		break;

	/***********************************************************/

	case '4':	/*SysOp*/

		if(debug_mode) printf("(listuser.c)case 4\n");

		leave=FALSE;
		n=0;
		display_msg(fd, "\n");
		do
		{
			n++;

			if( !get_user_data(&rec, n) )
			{
				leave=TRUE;
				continue;
			}

			if( rec.delete_mark=='X' )
				continue;

			if( rec.level<SYSOP_LEVEL )
				continue;

			if(debug_mode) printf("listuser.c)get SysOp #%d\n", n);

			sprintf(line, "# %-20s %-20s %-35s\n", rec.bbs_name, rec.real_name, rec.email);
			display_msg(fd, line);

		} while( !leave );

		display_msg(fd, "\n");
		suspend(fd);
		break;

	/***********************************************************/

	/*moderator-functions*/
	case '5':	/*edit mail rules*/

		if(debug_mode) printf("(listuser.c)case 5\n");

		if( (!system_operator) && (!group_moderator) )
			break;

		/*------------------------------------*/

		if( !strcmp(current_group, "main") || !strcmp(current_group, "mbox") )
		{
			display_msg(fd, CANNOT_EDIT_RULE);
			suspend(fd);
			break;
		}

		sprintf(line, "%s/%s/%s", MAIL_PATH, current_group, RULES);

		sprintf(bigbuf, "%s%s\n", EDIT_RULE, group_areaname);
		display_msg(fd, bigbuf);
		suspend(fd);

		if( file_exist(line) )
		{
		  n=flength(line);
		  if( n>(MAX_BUF-1024) )
			n=MAX_BUF-1024;

		  bulletin_file=open(line, O_RDONLY);
		  read(bulletin_file, bigbuf, n);
		  close(bulletin_file);
		  bigbuf[n]=0;
		}
		else
		  bigbuf[0]=0;

		send_mpf(fd, bigbuf, strlen(bigbuf), MAKEPOST);

		idling=IDLE_TIME * POST_FACTOR;/*extent editing time*/
		read_mpf(fd, bigbuf, &rlen, &protocol, FALSE);
		idling=IDLE_TIME;		/*restore idling time*/

		if( protocol==STOPPOST )
		{
			do_log(3, "%s abort edit bulletin", user_name);
			break;
		}
		if( protocol!=MAKEPOST)
		{
			do_log(8, "%s protocol_stat_err with protocol code %d at edit_bulletin", user_name, protocol);
			protocol_stat_err(fd);
	 	}

		bigbuf[rlen]=0;

		bulletin_file=open(line,  O_WRONLY|O_CREAT|O_TRUNC, S_IWUSR | S_IRUSR);
		write(bulletin_file, bigbuf, rlen);
		close(bulletin_file);

		break;

	/***********************************************************/

	/*co-sysop-functions*/
	case '6':	/*edit bulletin board*/

		if(debug_mode) printf("(listuser.c)case 6\n");

		if( user_level<E_BULLETIN_LVL )
			break;

		/*------------------------------------*/

		asking(fd, EDIT_BULLETIN_MODE, answer, 3);

		switch( answer[0] )
		{
		case '1':
		  asking(fd, EDIT_BULLETIN, answer, 50);
		  strip_nl(answer);
		  split_filename(answer, pn);

		  if( strlen(pn) <=0 )
			break;

		  sprintf(line, "%s/%s/%s", BULLETIN_PATH, bstack, pn);

		  if( file_exist(line) )
		  {
		    n=flength(line);
		    if( n>(MAX_BUF-1024) )
			n=MAX_BUF-1024;

		    bulletin_file=open(line, O_RDONLY);
		    read(bulletin_file, bigbuf, n);
		    close(bulletin_file);
		    bigbuf[n]=0;
		  }
		  else
		    bigbuf[0]=0;

		  send_mpf(fd, bigbuf, strlen(bigbuf), MAKEPOST);

		  idling=IDLE_TIME * POST_FACTOR;/*extent editing time*/
		  read_mpf(fd, bigbuf, &rlen, &protocol, FALSE);
		  idling=IDLE_TIME;		/*restore idling time*/

		  if( protocol==STOPPOST )
		  {
			do_log(3, "%s abort edit bulletin", user_name);
			break;
		  }
		  if( protocol!=MAKEPOST)
		  {
			do_log(8, "%s protocol_stat_err with protocol code %d at edit_bulletin", user_name, protocol);
			protocol_stat_err(fd);
		  }

		  bigbuf[rlen]=0;

		  bulletin_file=open(line,  O_WRONLY|O_CREAT|O_TRUNC, S_IWUSR | S_IRUSR);
		  write(bulletin_file, bigbuf, rlen);
		  close(bulletin_file);

		  break;

		case '2':
		  asking(fd, EDIT_BULLETIN, answer, 50);
		  strip_nl(answer);
		  split_filename(answer, pn);
		  sprintf(line, "%s/%s/%s", BULLETIN_PATH, bstack, pn);

		  if( !file_exist(line) )
		  {
			display_msg(fd, NO_SUCH_BULLETIN);
			suspend(fd);
			break;
		  }

		  asking(fd, CONFIRM_MSG, answer, 3);
		  if( answer[0]=='y' || answer[0]=='Y' )
			unlink(line);

		  break;
		}

		break;

	/***********************************************************/

	/*function greater than 6 are SysOp functions*/
	case '7':	/*SysOp send signal to all users*/

		if(debug_mode) printf("(listuser.c)case 7\n");

		if( !system_operator )
			break;

		/*------------------------------------*/

		sprintf(line, "%s/talk.%d", TALK_BUFFER, user_uid);

		sysop_talk=open(line, O_WRONLY | O_CREAT | O_TRUNC, S_IWUSR | S_IRUSR);

		sprintf(answer, "\nfrom %s...", user_name);
		write(sysop_talk, answer, strlen(answer));

		write(sysop_talk, SYSOP_TALK, strlen(SYSOP_TALK));
		sprintf(answer, "%c%c%c", 7, 13, 10);
		write(sysop_talk, answer, 3);	/*a BEEP*/

		/*get messages from SYSOP*/
		display_msg(fd, TALK_WHAT);
		do
		{
		  asking(fd, ">", answer, 80);
		  strip_nl(answer);
		  if( strlen(answer)==1 && answer[0]=='.' )
			break;
		  write(sysop_talk, answer, strlen(answer) );
		  write(sysop_talk, crlf, strlen(crlf));
		} while(1);
		close(sysop_talk);

		asking(fd, CONFIRM_MSG, answer, 10);
		if( answer[0]!='y' && answer[0]!='Y' )
			break;

		for(sig_rec=0; sig_rec<(flength(ON_LINE_USER)/sizeof(struct putmp)); sig_rec++)
		{
			get_putmp(&purec, sig_rec);

			if( purec.active )
			{
			  switch(purec.act_stat)
			  {
			  case 7:
			  case 8:
			  case 9:
			  case 10:
			  case 11:
				get_user_data(&rec, purec.uid);
				descript_stat(info, 25, purec.act_stat, purec.act_info);
				sprintf(line, "%s%s%s\n", rec.bbs_name, CANNOT_PAGE, info);
				display_msg(fd, line);
				break;
			  default:
				purec.page_mode=0;
				purec.page_uid=user_uid;
				set_putmp(&purec, sig_rec);
				kill(purec.pid, SIGUSR1);
				break;
			  }
			}
		}/*end for*/

		break;

	/***********************************************************/

	case '8':	/*adjust user level*/

		if(debug_mode) printf("(listuser.c)case 8\n");

		if( !system_operator )
			break;

		/*------------------------------------*/

		asking(fd, SYSOP_ASK_WHO, answer, 20);
		process_user_name(answer);

		/*************/
		/*search user*/
		/*************/

		list_uid=atoi(answer);	/*accept user_id input*/

		if( list_uid>=get_total_user_recs() )
			list_uid=0;	/*input too large*/

		if( list_uid<=0 )
			list_uid=get_user_id(answer);

		/*******************/
		/*user found or not*/
		/*******************/
		if(list_uid==0)
		{
			display_msg(fd, NO_SUCH_USER);
			suspend(fd);
			return;
		}

		/*****************/
		/*get user record*/
		/*****************/
		get_user_data(&rec, list_uid);

		/****************************/
		/*if account disabled or not*/
		/****************************/
		if( rec.delete_mark=='X' || rec.delete_mark=='*' )
		{
			display_msg(fd, NO_SUCH_USER);
			suspend(fd);
			return;
		}

		/******/
		/*list*/
		/******/
		display_msg(fd, "\n");
		sprintf(line, "%s%d\n", CP_USER_ID, list_uid);
		display_msg(fd, line);
		sprintf(line, "%s%s\n", CP_BBS_NAME, rec.bbs_name);
		display_msg(fd, line);
		sprintf(line, "%s%s\n", CP_REAL_NAME, rec.real_name);
		display_msg(fd, line);
		sprintf(line, "%s%s\n", CP_EMAIL_ADD, rec.email);
		display_msg(fd, line);
		sprintf(line, "%s%s\n", CP_INTEREST, rec.interest);
		display_msg(fd, line);
		sprintf(line, "%s%s\n", CP_SPEC, rec.spec);
		display_msg(fd, line);
		/*
		sprintf(line, "%s%s\n", CP_TERM, rec.term);
		display_msg(fd, line);
		*/
		sprintf(line, "%s%s\n", CP_ADDRESS, rec.address);
		display_msg(fd, line);
		sprintf(line, "%s%s\n", CP_PHONE, rec.phone);
		display_msg(fd, line);
		sprintf(line, "%s%c\n", CP_SEX, rec.sex);
		display_msg(fd, line);
		sprintf(line, "%s%d\n", CP_LEVEL, rec.level);
		display_msg(fd, line);
		display_msg(fd, "\n");

		asking(fd, SYSOP_ASK_NEW_LEVEL, answer, 10);
		if( answer[0]==0 || answer[0]==13 || answer[0]==10 )
			break;

		rec.level=atoi(answer);
		display_msg(fd, "\n");
		sprintf(line, "%s%d\n", CP_LEVEL, rec.level);
		display_msg(fd, line);
		display_msg(fd, "\n");

		asking(fd, CONFIRM_MSG, answer, 3);
		if( answer[0] =='Y' || answer[0]=='y' )
			set_user_data(&rec, list_uid);

		break;

	/***********************************************************/

	case '9':	/*delete user*/

		if(debug_mode) printf("(listuser.c)case 9\n");

		if( !system_operator )
			break;

		/*------------------------------------*/

		asking(fd, SYSOP_ASK_WHO, answer, 20);
		process_user_name(answer);

		/*************/
		/*search user*/
		/*************/

		list_uid=atoi(answer);	/*accept user_id input*/

		if( list_uid>=get_total_user_recs() )
			list_uid=0;	/*input too large*/

		if( list_uid<=0 )
			list_uid=get_user_id(answer);

		/*******************/
		/*user found or not*/
		/*******************/
		if(list_uid==0)
		{
			display_msg(fd, NO_SUCH_USER);
			suspend(fd);
			return;
		}

		/*****************/
		/*get user record*/
		/*****************/
		get_user_data(&rec, list_uid);

		/****************************/
		/*if account disabled or not*/
		/****************************/
		if( rec.delete_mark=='X' || rec.delete_mark=='*' )
		{
			display_msg(fd, NO_SUCH_USER);
			suspend(fd);
			return;
		}

		/******/
		/*list*/
		/******/
		display_msg(fd, "\n");
		sprintf(line, "%s%d\n", CP_USER_ID, list_uid);
		display_msg(fd, line);
		sprintf(line, "%s%s\n", CP_BBS_NAME, rec.bbs_name);
		display_msg(fd, line);
		sprintf(line, "%s%s\n", CP_REAL_NAME, rec.real_name);
		display_msg(fd, line);
		sprintf(line, "%s%s\n", CP_EMAIL_ADD, rec.email);
		display_msg(fd, line);
		sprintf(line, "%s%s\n", CP_INTEREST, rec.interest);
		display_msg(fd, line);
		sprintf(line, "%s%s\n", CP_SPEC, rec.spec);
		display_msg(fd, line);
		/*
		sprintf(line, "%s%s\n", CP_TERM, rec.term);
		display_msg(fd, line);
		*/
		sprintf(line, "%s%s\n", CP_ADDRESS, rec.address);
		display_msg(fd, line);
		sprintf(line, "%s%s\n", CP_PHONE, rec.phone);
		display_msg(fd, line);
		sprintf(line, "%s%c\n", CP_SEX, rec.sex);
		display_msg(fd, line);
		sprintf(line, "%s%d\n", CP_LEVEL, rec.level);
		display_msg(fd, line);
		sprintf(line, "%s%d\n",CP_TOTAL_LOGIN,rec.total_login);
		display_msg(fd, line);
		sprintf(line, "%s%s\n", CP_LAST_LOGIN, rec.last_login);
		display_msg(fd, line);
		display_msg(fd, "\n");

		asking(fd, CONFIRM_MSG, answer, 3);

		rec.delete_mark='X';
		if( answer[0] =='Y' || answer[0]=='y' )
			set_user_data(&rec, list_uid);

		break;

	}/*end switch*/
}
/*end of list_users*/
