/*************************************************************************
 * lastread.c --- last read control					 *
 *	          by Samson Chen, Apr 7, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "global.h"

static char rcsid[]="$Id: lastread.c,v 1.1 1994/04/22 10:03:59 pbbs Exp pbbs $";

/*
	get_lastread --- get user's last of current_group
*/
get_lastread(fd)
	int fd;
/*
	return:
		current lastread number of the user_uid
*/
{
	char userlr_filename[80];
	int user_lr;
	int records;
	int n;
	int lastread;
	int current_lastread;

	sprintf(userlr_filename, "%s/%s/users", MAIL_PATH, current_group);

	if( !file_exist(userlr_filename) )
	{
		user_lr=open(userlr_filename, O_CREAT | O_TRUNC, S_IWUSR | S_IRUSR);
		close(user_lr);
	}

	records=flength(userlr_filename)/sizeof(int);
	if( records < user_uid+1 )
	{
		user_lr=open(userlr_filename, O_WRONLY | O_APPEND);

		lastread=0;

		for(n=records; n<=user_uid; n++)
			write(user_lr, &lastread, sizeof(int) );

		close(user_lr);
	}

	user_lr=open(userlr_filename, O_RDONLY);

	lseek(user_lr, user_uid*sizeof(int), SEEK_SET);
	read(user_lr, &current_lastread, sizeof(int) );

	close(user_lr);

	if(debug_mode) printf("(lastread.c)return lastread %d for %s\n", current_lastread, user_name);

	return(current_lastread);
}
/*end of get_lastread*/



/*
	set_lastread --- set user last read
*/
set_lastread(fd, lr)
	int fd;
	int lr;		/*new lastread number*/
{
	char userlr_filename[80];
	int user_lr;
	int records;
	int n;
	int lastread;

	if(debug_mode) printf("(lastread.c)set lastread %d for %s\n", lr, user_name);

	sprintf(userlr_filename, "%s/%s/users", MAIL_PATH, current_group);

	if( !file_exist(userlr_filename) )
	{
		user_lr=open(userlr_filename, O_CREAT | O_TRUNC, S_IWUSR | S_IRUSR);
		close(user_lr);
	}

	records=flength(userlr_filename)/sizeof(int);
	if( records < user_uid+1 )
	{
		user_lr=open(userlr_filename, O_WRONLY | O_APPEND);

		lastread=0;

		for(n=records; n<=user_uid; n++)
			write(user_lr, &lastread, sizeof(int) );

		close(user_lr);
	}

	user_lr=open(userlr_filename, O_RDWR);

	/*
	lseek(user_lr, user_uid*sizeof(int), SEEK_SET);
	read(user_lr, &lastread, sizeof(int) );
	*/

	/*note: dynamic lastread pointer, this means, user can set his last
		read pointer by reading the specific mail even if he read it
		backward*/

	if(lr<0)
		lr=0;

	lseek(user_lr, user_uid*sizeof(int), SEEK_SET);
	write(user_lr, &lr, sizeof(int) );

	close(user_lr);
}
/*end of set_lastread*/
