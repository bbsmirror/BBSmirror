/*************************************************************************
 * act.c ---  putmp action record functions				 *
 *	      by Samson Chen, May 14, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "dbf.h"
#include "global.h"


/*
	action stat code :
	
		1  : main menu
		2  : mail menu
		3  : file menu
		4  : tool menu
		5  : bulletin menu
		6  : read mail
		7  : write mail		: cannot interrupt
		8  : download		: cannot interrupt
		9  : upload		: cannot interrupt
		10 : chatroom		: cannot interrupt
		11 : talk		: cannot interrupt
*/

/*
	update_act --- update putmp action stat
*/
update_act(stat_code, info)
	unsigned char stat_code;
	char *info;	/*stat information*/
{
	int utf;
	struct putmp purec;

	if( debug_mode ) printf("(act.c)update act code %d for %s\n", stat_code, user_name);

	if( user_uid==0 ) return;

	utf=open(ON_LINE_USER, O_RDWR | O_CREAT, S_IWUSR | S_IRUSR);

	lseek(utf, putmp_rec*sizeof(struct putmp), SEEK_SET);
	read(utf, &purec, sizeof(struct putmp));

	purec.act_stat=stat_code;

	switch(stat_code)
	{
	case 5:
	case 6:
	case 7:
	case 8:
	case 10:
		nstrcpy(purec.act_info, info, 20);
		break;
	}

	lseek(utf, putmp_rec*sizeof(struct putmp), SEEK_SET);
	write(utf, &purec, sizeof(struct putmp) );

	close(utf);
}
/*end of update_act*/



/*
	descript_stat --- convert stat code to readable text
*/
descript_stat(buf, len, stat_code, info)
	char *buf;
	int len;	/*max len of buf*/
	unsigned char stat_code;
	char *info;
{
	char line[128];

	if( debug_mode ) printf("(act.c)descript stat\n");

	switch(stat_code)
	{
	case 1:
		nstrcpy(line, MAIN_MENU_STAT, 128);
		break;
	case 2:
		nstrcpy(line, MAIL_MENU_STAT, 128);
		break;
	case 3:
		nstrcpy(line, FILE_MENU_STAT, 128);
		break;
	case 4:
		nstrcpy(line, TOOL_MENU_STAT, 128);
		break;
	case 5:
		sprintf(line, "%s%s", BULLETIN_STAT, info);
		break;
	case 6:
		sprintf(line, "%s%s", READ_MAIL_STAT, info);
		break;
	case 7:
		sprintf(line, "%s%s", WRITE_MAIL_STAT, info);
		break;
	case 8:
		sprintf(line, "%s%s", DOWNLOAD_STAT, info);
		break;
	case 9:
		nstrcpy(line, UPLOAD_STAT, 128);
		break;
	case 10:
		sprintf(line, "%s%s", CHAT_STAT, info);
		break;
	case 11:
		nstrcpy(line, TALK_STAT, 128);
		break;
	default:
		sprintf(line, "???:%d", stat_code);
		break;
	}

	nstrcpy(buf, line, len);
}
/*end of descript_stat*/
