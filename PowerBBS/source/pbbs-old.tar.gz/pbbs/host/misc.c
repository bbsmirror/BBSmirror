/*************************************************************************
 * misc.c --- misc. functions						 *
 *	      by Samson Chen, Dec 2, 1993				 *
 *************************************************************************/

#include <varargs.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include "pbbs.h"
#include "message.h"
#include "dbf.h"
#include "global.h"



/*
	do logging --- (as the name)

	note: init_log() was removed, so that, log file can be removed and
	      re-create without re-run the process
*/
do_log(loglevel, logformat, va_alist)
	int loglevel;
	char *logformat;
	va_dcl
{
	char timing[50];
	char buffer[620];
	char logmsg[600];
	FILE *logfile;

	/*get arguments list*/
	va_list args;
	va_start(args);
	vsprintf(logmsg, logformat, args);
	va_end(args);

	get_daytime(timing);
	sprintf(buffer, "%s,%d> ", timing, loglevel);

	strcat(buffer, logmsg);

	/*for debugging use*/
	if( debug_mode ) printf("%s\n", buffer);

	if(loglevel>=LOGLEVEL)
	{
		logfile = fopen(LOGFILE, "a+");
		fprintf(logfile, "%s\n", buffer);
		fclose(logfile);
	}
}
/*end of do_log*/



/*
	get day and time
*/
get_daytime(buffer)
	char *buffer;	/*CAUTION: buffer must has it's own space befor
				   calling*/
{
	struct	tm	*timeptr;
	time_t		secsnow;

	time(&secsnow);
	timeptr = localtime(&secsnow);

	sprintf(buffer, "%#02d/%#02d,%#02d:%#02d", timeptr->tm_mon+1, timeptr->tm_mday , timeptr->tm_hour, timeptr->tm_min);
}
/*end of daytime*/



/*
	test if the file exist or not
*/
file_exist(filename)
char *filename;
/*
	return: TRUE: exist
		FALSE: not exist
*/
{
	FILE *testexist;

	if( (testexist=fopen(filename, "r")) == NULL)
		return(FALSE);		/*not found*/
	else	/*file found*/
	{
		fclose(testexist);
		return(TRUE);
	}
}
/*end of file_exist*/



/*
	test if the path exist or not
*/
path_exist(pathname)
char *pathname;
{
	int ret;
	struct stat buf;

	ret=stat(pathname, &buf);

	if( ret<0 )
		return(FALSE);	/*path not exist*/

	if( (buf.st_mode & S_IFDIR)==0 )
		return(FALSE);	/*not a path*/

	return(TRUE);
}
/*end of path_exist*/



/*
	check_required_path --- check some necessary paths
*/
check_required_path()
/*
	return: TRUE: OK
		FALSE: Failed
*/
{
	char check_path[256];

	/*check mbox*/
	sprintf(check_path, "%s/mbox", MAIL_PATH);
	if( !path_exist(check_path) )
	{
		printf("\nmailbox path %s not found!\n", check_path);
		return(FALSE);
	}

	/*check main*/
	sprintf(check_path, "%s/main", MAIL_PATH);
	if( !path_exist(check_path) )
	{
		printf("\nmain path %s not found!\n", check_path);
		return(FALSE);
	}

	/*check initial downlad path*/
	sprintf(check_path, "%s/%s", FILE_PATH, INIT_FILE_AREA);
	if( !path_exist(check_path) )
	{
		printf("\ninitial download path %s not found!\n", check_path);
		return(FALSE);
	}

	/*check upload path*/
	sprintf(check_path, "%s/%s", FILE_PATH, UPLOAD_PATH);
	if( !path_exist(check_path) )
	{
		printf("\nupload path %s not found!\n", check_path);
		return(FALSE);
	}

	/*check talk buffer path*/
	sprintf(check_path, "%s", TALK_BUFFER);
	if( !path_exist(check_path) )
	{
		printf("\ntalk buffer path %s not found!\n", check_path);
		return(FALSE);
	}


	return(TRUE);
}
/*end of check_required_path*/



/*
	send_prompt --- send prompt messages to client
*/
send_prompt(fd)
	int fd;
{
	char buf[4096];
	char *p;
	int ret;

	if(debug_mode) printf("(misc.c)send prompt\n");

	p=buf;

	sprintf(p, "CPSender: %s%c%c", C_P_SENDER, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPPostdate: %s%c%c", C_P_POSTDATE, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPPostsubject: %s%c%c", C_P_POSTSUBJECT, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPPostarea: %s%c%c", C_P_POSTAREA, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPPostno: %s%c%c", C_P_POSTNO, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPPostreply: %s%c%c", C_P_POSTREPLY, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPPostorgan: %s%c%c", C_P_POSTORGAN, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPPresskey: %s%c%c", C_P_PRESSKEY, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPMore: %s%c%c", C_P_MORE, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPPostmore: %s%c%c", C_P_POSTMORE, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPEditconfirm: %s%c%c", C_P_EDITCONFIRM, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPPostbottom: %s%c%c", C_P_POSTBOTTOM, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPFileexist: %s%c%c", C_P_FILEEXIST, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPUfilename: %s%c%c", C_P_UFILENAME, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPNotfound: %s%c%c", C_P_NOTFOUND, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPFdisable: %s%c%c", C_P_FDISABLE, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPInterread: %s%c%c", C_P_INTERREAD, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPFilepost: %s%c%c", C_P_FILEPOST, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPCapfile: %s%c%c", C_P_CAPFILE, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPScanNoFind: %s%c%c", C_P_SCANNOFIND, 13, 10);
	ret=strlen(p);
	p+=ret;

	sprintf(p, "CPDownPath: %s%c%c", C_P_DOWNPATH, 13, 10);
	ret=strlen(p);
	p+=ret;

	*p=0;

	send_mpf(fd, buf, strlen(buf), PROMPT);
}
/*end of send_prompt*/



/*
	display_msg --- display a message
*/
display_msg(fd, msg)
	int fd;
	char *msg;
{
	/*
	if(debug_mode) printf("(display_msg)send DISPLAY [%d]%s\n", strlen(msg), msg);
	*/
	send_mpf(fd, msg, strlen(msg), DISPLAY);
}
/*end if display_msg*/



/*
	asking --- ask user
*/
asking(fd, prompt, answer, len)
	int fd;
	char *prompt;	/*prompt question*/
	char *answer;	/*user's answer*/
	int len;	/*max length for answering*/
{
	int rlen;
	char protocol;
	char user_answer[200];

	send_mpf(fd, prompt, strlen(prompt), ASK);
	read_mpf(fd, user_answer, &rlen, &protocol, FALSE);

	if( protocol != ASK )
	{
		do_log(8, "%s protocol_stat_err with procotol code %d at asking", client_site, protocol);
		protocol_stat_err(fd);
	}

	if( rlen>=200 )
		rlen=199;

	user_answer[rlen]=0;

	nstrcpy(answer, user_answer, len);
}
/*end of asking*/



/*
	reg_ask --- ask user data in register (blank input is not allowed)
*/
reg_ask(fd, prompt, answer, len)
	int fd;
	char *prompt;	/*prompt question*/
	char *answer;	/*user's answer*/
	int len;	/*max length for answering*/
{
	int trial=0;
	char ok=FALSE;

	do
	{
		trial++;
		if(trial>MAX_LOGIN)
			reject(fd, 21);

		asking(fd, prompt, answer, len);

		if( answer[0]==0 || answer[0]==13 || answer[0]==10 || answer[0]==' ')
		{
			display_msg(fd, DONT_BLANK);
			continue;
		}
		else
			ok=TRUE;

	} while(!ok);
}
/*end of reg_ask*/



/*
	flength --- get length of a file
*/
long flength(filename)
	char *filename;
{
	int test;
        struct stat buf;

        test=open(filename, O_RDONLY);
        fstat(test, &buf);
	close(test);

        return(buf.st_size);
}
/*end of flength*/



/*
	get_new_passwd --- get a new password (with confirm)
*/
get_new_passwd(fd, passwd)
	int fd;
	char *passwd;	/*users's last encryptted input*/
{
	char passwd_ok=FALSE;
	char buf[255];
	unsigned long blen;
	char protocol;
	char first_try[14];
	char next_try[14];
	char try=0;

	do
	{
		try++;

		strcpy(buf, PASSWD_PLZ);
		send_mpf(fd, buf, strlen(buf), PASSWD);
		read_mpf(fd, buf, &blen, &protocol, FALSE);
		buf[blen]='\0';
		if( protocol != PASSWD )
		{
			do_log(8, "%s protocol_stat_err with protocol code %d at get_new_passwd(a)", user_name, protocol);
			protocol_stat_err(fd);
		}

		strcpy( first_try, crypt(buf, SALT) );

		strcpy(buf, REPASSWD);
		send_mpf(fd, buf, strlen(buf), PASSWD);
		read_mpf(fd, buf, &blen, &protocol, FALSE);
		buf[blen]='\0';
		if( protocol != PASSWD )
		{
			do_log(8, "%s protocol_stat_err with protocol code %d at get_new_passwd(b)", user_name, protocol);
			protocol_stat_err(fd);
		}

		strcpy( next_try, crypt(buf, SALT) );

		if( strcmp(first_try, next_try) )	/*mismatch*/
		{
			strcpy(buf, PASSWD_MISMATCH);
			send_mpf(fd, buf, strlen(buf), DISPLAY);

			if( try >= MAX_LOGIN )	/*too many tries*/
			{
				do_log(3, "%s set new password failed", client_site);
				reject(fd, 7);
			}
		}
		else
		{
			strcpy(passwd, first_try);
			passwd_ok=TRUE;
		}

	} while (!passwd_ok);

}
/*end of get_new_passwd*/



/*
	reject --- server reject the session
*/
reject(fd ,errcode)
{
	off_putmp();
	send_mpf(fd, NULL, 0, REJECT);
	close(fd);
	exit(errcode);
}
/*end of reject*/



/*****************************/
int rfctime(rfcbuf)
/*****************************
    get RFC-977 format time
    write by Aquarius Kuo 
    Mar 23, 1994.

return: the length of string.
******************************/    
char *rfcbuf ;
{
  int len ;
  time_t timenow ;
  struct tm  *timeptr ;
  
  time(&timenow) ;
  timeptr=localtime(&timenow) ;
  len=strftime(rfcbuf,26,"%a, %d %b %Y %T",timeptr) ;
  return(len) ;
}
/*end of rfctime*/



int rfcgmtime(rfcbuf)
/*****************************
    get RFC-977 format time at GMT
    write by Aquarius Kuo 
    Mar 23, 1994.

return: the length of string.
******************************/    
char *rfcbuf ;
{
  int len ;
  time_t timenow ;
  struct tm  *timeptr ;
  
  time(&timenow) ;
  timeptr=gmtime(&timenow) ;
  len=strftime(rfcbuf,26,"%a, %d %b %Y %T",timeptr) ;
  return(len) ;
}
/*end of rfcgmtime*/



/*
	gmtlocal --- covert GMT to Local time
	note: result will write back to the same input buffer
*/
gmtlocal(timestr)
	char *timestr;
{
	static char *dayname[7]={"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
	static char *month[12]={"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
	static int days[12]={31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

	int	day, sec, min, hour, date, mon, year;
	char	tbuf[30];
	char	mbuf[10];
	int	tlen, nlen;
	char	*tptr;
	int	n;

	tptr=timestr;
	memset(tbuf, 0, 30);

	for(tlen=0; tlen<29; tlen++)
	{
		if( *tptr==10 || *tptr==13 || *tptr==0 )
		{
			tbuf[tlen]=0;
			break;
		}

		tbuf[tlen]=*tptr;
		tptr++;
	}

	tlen=strlen(tbuf);

	if( tlen<20 )
		return;

	if( strncmp(tbuf+(tlen-3), "GMT", 3) )
		return;				/*only convert GMT time*/

	/*................................*/
	/*get day*/
	day=0;
	tptr=tbuf;

	for(n=0; n<7; n++)
		if( !strncmp(tptr, dayname[n], 3) )
		{
			day=n+1;
			break;
		}

	/*................................*/
	/*get date*/
	date=0;

	if(day>0)
		tptr+=5;
	else
		tptr=tbuf;	/*some time string without day field in it*/

	strncpy(mbuf, tptr, 2);
	mbuf[2]=0;
	if( mbuf[1]==' ' )
	{
		/* date < 10 and use only 1 char */
		mbuf[1]=0;
		tptr+=2;
	}
	else
		tptr+=3;

	date=atoi(mbuf);

	/*................................*/
	/*get month*/
	mon=0;

	for(n=0; n<12; n++)
		if( !strncmp(tptr, month[n], 3) )
		{
			mon=n+1;
			break;
		}

	/*................................*/
	/*get year*/
	year=0;
	tptr+=4;
	strncpy(mbuf, tptr, 4);
	mbuf[4]=0;

	if( mbuf[2]==' ' )
	{
		mbuf[2]=0;
		tptr+=3;
	}
	else
		tptr+=5;

	year=atoi(mbuf);

	/*................................*/
	/*get hour*/
	hour=0;
	strncpy(mbuf, tptr, 2);
	mbuf[2]=0;
	hour=atoi(mbuf);

	/*................................*/
	/*get minute*/
	min=0;
	tptr+=3;
	strncpy(mbuf, tptr, 2);
	mbuf[2]=0;
	min=atoi(mbuf);

	/*................................*/
	/*get second*/
	sec=0;
	tptr+=3;
	strncpy(mbuf, tptr, 2);
	mbuf[2]=0;
	sec=atoi(mbuf);

	/*................................*/
	/*check*/
	if( year<=90 || mon<=0 || date<=0 )
		return;

	/*----------------------------------*/
	/*converting*/
	min -= TZ_MIN_WEST;

	/*................................*/
	/*normalizing*/

	if( (year%4)==0 && ((year%100)!=0 || (year%400)==0) )
		days[2-1]=29;
	else
		days[2-1]=28;

	while(min<0 || min>59)
	{
	  if( min<0 )
	  {
	    min+=60;			/*borrowed from hour*/
	    hour-=1;

	    if(hour<0)
	    {
	      hour+=24;			/*borrowed from date*/
	      date-=1;

	      if(day>0)
	      {
		day-=1;
		if(day==0) day=7;
	      }

	      if(date==0)
	      {
		mon-=1;

		if(mon==0)
		{
			mon=12;
			year-=1;
		}

		date=days[mon-1];
		
	      }/*end date*/

	    }/*end hour*/

	    continue;

	  }/*end min*/

	  if( min>59 )
	  {
	    min-=60;			/*borrowed from hour*/
	    hour+=1;

	    if(hour>=24)
	    {
	      hour-=24;			/*borrowed from date*/
	      date+=1;

	      if(day>0)
	      {
		day+=1;
		if(day==8) day=1;
	      }

	      if(date>days[mon-1])
	      {
		mon+=1;

		if(mon==13)
		{
			mon=1;
			year+=1;
		}

		date=1;
		
	      }/*end date*/

	    }/*end hour*/

	    continue;

	  }/*end min*/

	}/*end while*/
	
	/*----------------------------------*/
	/*set to string format*/
	if(day>0)
	{
		sprintf(tbuf, "%s, %02d %s %d %02d:%02d:%02d", dayname[day-1], date, month[mon-1], year, hour, min, sec);
	}
	else
	{
		sprintf(tbuf, "%02d %s %d %02d:%02d:%02d", date, month[mon-1], year, hour, min, sec);
	}

	/*----------------------------------*/
	/*write back to the buffer*/

	nlen=strlen(tbuf);

	if( nlen>tlen )
		return;		/*it is loger after conversion???*/
	
	tptr=timestr;

	for(n=0; n<nlen; n++)
	{
		*tptr=tbuf[n];
		tptr++;
	}

	for(n=nlen; n<tlen; n++)
	{
		*tptr=' ';
		tptr++;
	}

}
/*end if gmtlocal*/



/*
	file_time_format --- mm-dd-yy hh:mm
*/
file_time_format(tbuf)
	char *tbuf;	/*please allocate 15 chars space before calling*/
{
  int len ;
  time_t timenow ;
  struct tm  *timeptr ;
  
  time(&timenow) ;
  timeptr=localtime(&timenow) ;
  len=strftime(tbuf, 15, "%m-%d-%y %H:%M", timeptr) ;
  return(len) ;
}
/*end of file_time_format*/



/*
	check_putmp --- check if user use same ID dup-login
*/
check_putmp(fd)
	int fd;
{
	int utf;
	struct putmp purec;
	char answer[2];
	int recno=0;

	utf=open(ON_LINE_USER, O_RDWR|O_CREAT, S_IWUSR | S_IRUSR);
	while( read(utf, &purec, sizeof(struct putmp) ) )
	{
		if( purec.active )
		  if( purec.uid==user_uid )
		  {
			do_log(2, "%s dup-login", user_name);

			asking(fd, DUP_LOGIN, answer, 2);
			if( answer[0]=='y' || answer[0]=='Y' )
			{
				do_log(0, "%s kill another login", user_name);

				flock(utf, LOCK_EX);
				lseek(utf, recno*sizeof(struct putmp), SEEK_SET);
				purec.active=FALSE;
				write(utf, &purec, sizeof(struct putmp) );
				flock(utf, LOCK_UN);

				kill(purec.pid, SIGTERM);
				sign_putmp();
				return;
			}
			else
				reject(fd, 20);
		  }

		  recno++;
	}

	sign_putmp();

}
/*end of check_putmp*/



/*
	sign_putmp --- sign in putmp file
*/
sign_putmp()
{
	int puf;
	struct putmp purec;
	struct putmp signrec;
	int recno=0;

	signrec.active=TRUE;
	signrec.uid=user_uid;
	signrec.pid=getpid();
	nstrcpy(signrec.from, client_site, 30);
	signrec.chatroom=0;

	puf=open(ON_LINE_USER, O_RDWR|O_CREAT, S_IWUSR | S_IRUSR);

	flock(puf, LOCK_EX);

	lseek(puf, 0, SEEK_SET);
	while( read(puf, &purec, sizeof(struct putmp) ) )
	{
		if( !purec.active )	/*empty slot*/
		{
			putmp_rec=recno;
			if(debug_mode) printf("(misc.c)use exist putmp slot %d\n", putmp_rec);
			lseek(puf, recno*sizeof(struct putmp), SEEK_SET);
			write(puf, &signrec, sizeof(struct putmp) );
			flock(puf, LOCK_UN);
			close(puf);
			return;
		}
		recno++;
		lseek(puf, recno*sizeof(struct putmp), SEEK_SET);
	}

	flock(puf, LOCK_UN);
	close(puf);

	/*no empty slot, append it*/
	puf=open(ON_LINE_USER, O_WRONLY | O_APPEND);
	flock(puf, LOCK_EX);
	write(puf, &signrec, sizeof(struct putmp) );
	putmp_rec=file_length(puf)/sizeof(struct putmp)-1;
	if(debug_mode) printf("(misc.c)creat putmp slot %d\n", putmp_rec);
	flock(puf, LOCK_UN);
	close(puf);
}
/*end of sign_putmp*/



/*
	off_putmp --- sign off putmp
*/
off_putmp()
{
	int utf;
	struct putmp purec;
	char talk_file[128];

	if( debug_mode ) printf("(misc.c)off_putmp %d user=%s uid=%d\n", putmp_rec, user_name, user_uid);

	if( putmp_rec<0 ) return; /*user logout befor login (eg.dup-log)*/
	if( user_uid==0 ) return;

	utf=open(ON_LINE_USER, O_RDWR | O_CREAT, S_IWUSR | S_IRUSR);

	lseek(utf, putmp_rec*sizeof(struct putmp), SEEK_SET);
	read(utf, &purec, sizeof(struct putmp));

	purec.active=FALSE;
	lseek(utf, putmp_rec*sizeof(struct putmp), SEEK_SET);
	write(utf, &purec, sizeof(struct putmp) );

	close(utf);

	/*remove talk file*/
	sprintf(talk_file, "%s/talk.%d", TALK_BUFFER, user_uid);
	if( file_exist(talk_file) )
		unlink(talk_file);
}
/*end of off_putmp*/



/*
	set_putmp --- set putmp file
*/
set_putmp(purec, recno)
	struct putmp *purec;
	int recno;
{
	int puf;

	puf=open(ON_LINE_USER, O_WRONLY|O_CREAT, S_IWUSR | S_IRUSR);

	lseek(puf, recno*sizeof(struct putmp), SEEK_SET);
	write(puf, purec, sizeof(struct putmp) );

	close(puf);
}
/*end of set_putmp*/



/*
	get_putmp --- get putmp file
*/
get_putmp(purec, recno)
	struct putmp *purec;
	int recno;
{
	int puf;

	puf=open(ON_LINE_USER, O_RDONLY|O_CREAT, S_IWUSR | S_IRUSR);

	lseek(puf, recno*sizeof(struct putmp), SEEK_SET);
	read(puf, purec, sizeof(struct putmp) );

	close(puf);
}
/*end of get_putmp*/



/*
	chn_passwd --- change password
*/
chn_passwd(fd, magic)
	int fd;
	char magic;	/*if TRUE for magic password changing, FALSE for else*/
/*
	return:
		TRUE:	change OK
		FALSE:	change failure
*/
{
        char udbfile[255];
        int udbf;
        int n;
        struct udb record;
	char user_passwd[14];
	char first_try[14];
	char next_try[14];
	char buf[255];
	int blen;
	char protocol;
	char old_pass_ok=FALSE;
	char pass_ok=FALSE;	/*if user change his password success or not*/

        sprintf(udbfile, "%s.dbf", USER_DATA_BASE);
        udbf = open(udbfile, O_RDWR);
	lseek( udbf, user_uid*sizeof(struct udb), SEEK_SET);

	read(udbf, &record, sizeof(struct udb));
	if( debug_mode ) printf("(misc.c)(chn_passwd)\n");

	if( !magic )
	{
	  strcpy(buf, OLD_PASSWD_PLZ);
	  send_mpf(fd, buf, strlen(buf), PASSWD);
	  read_mpf(fd, buf, &blen, &protocol, FALSE);
	  buf[blen]='\0';
	  if( protocol != PASSWD )
	  {
		do_log(8, "%s protocol_stat_err with procotol code %d at chn_passwd(a)", client_site, protocol);
		protocol_stat_err(fd);
	  }

	  if( strcmp(record.password, crypt(buf, SALT) ) )
	  {
		display_msg(fd, PASSWD_WRONG);
		suspend(fd);
	  }
	  else
		old_pass_ok=TRUE;
	}

	if( magic || (!magic && old_pass_ok) )
	{
		strcpy(buf, NEW_PASSWD_PLZ);
		send_mpf(fd, buf, strlen(buf), PASSWD);
		read_mpf(fd, buf, &blen, &protocol, FALSE);
		buf[blen]='\0';
		if( protocol != PASSWD )
		{ 
			do_log(8, "%s protocol_stat_err with procotol code %d at chn_passwd(b)", client_site, protocol);
			protocol_stat_err(fd);
		}

		strcpy( first_try, crypt(buf, SALT) );

		strcpy(buf, REPASSWD);
		send_mpf(fd, buf, strlen(buf), PASSWD);
		read_mpf(fd, buf, &blen, &protocol, FALSE);
		buf[blen]='\0';
		if( protocol != PASSWD )
		{
			do_log(8, "%s protocol_stat_err with procotol code %d at chn_passwd(c)", client_site, protocol);
			protocol_stat_err(fd);
		}

		strcpy( next_try, crypt(buf, SALT) );

		if( strcmp(first_try, next_try) )	/*mismatch*/
		{
			display_msg(fd, PASSWD_MISMATCH);
			suspend(fd);
		}
		else
		{
			strcpy(record.password, first_try);

			do_log(6, "%s change passwd", user_name);
			flock(udbf, LOCK_EX);
			lseek(udbf, user_uid*sizeof(struct udb), SEEK_SET);
			write(udbf, &record, sizeof(struct udb) );
			flock(udbf, LOCK_UN);
			pass_ok=TRUE;
		}
	}

	close(udbf);
	return(pass_ok);
}
/*end of chn_passwd*/



/*
	chn_persondata --- change personal data
*/
chn_persondata(fd)
	int fd;
{
        char udbfile[255];
        int udbf;
        int n;
        struct udb record;
	char answer[80];
	char buf[80];

        sprintf(udbfile, "%s.dbf", USER_DATA_BASE);
        udbf = open(udbfile, O_RDWR);
	lseek( udbf, user_uid*sizeof(struct udb), SEEK_SET);

	read(udbf, &record, sizeof(struct udb));
	if( debug_mode ) printf("(misc.c)(chn_persondata)\n");

	display_msg(fd, YOUR_PERSON_DATA);

	sprintf(buf, "%s%s\n", CP_REAL_NAME, record.real_name);
	display_msg(fd, buf);

        sprintf(buf, "%s%s\n", CP_EMAIL_ADD, record.email);
        display_msg(fd, buf);

	/*
        sprintf(buf, "%s%s\n", CP_TERM, record.term);
        display_msg(fd, buf);
	*/

        sprintf(buf, "%s%s\n", CP_ADDRESS, record.address);
        display_msg(fd, buf);

        sprintf(buf, "%s%s\n", CP_PHONE, record.phone);
        display_msg(fd, buf);

        sprintf(buf, "%s%c\n", CP_SEX, record.sex);
        display_msg(fd, buf);

        sprintf(buf, "%s%s\n", CP_INTEREST, record.interest);
        display_msg(fd, buf);

        sprintf(buf, "%s%s\n", CP_SPEC, record.spec);
        display_msg(fd, buf);

	sprintf(buf, "%s%d\n\n", CP_LEVEL, record.level);
	display_msg(fd, buf);

	asking(fd, CHANGE_PERSON_DATA, answer, 2);

	if( answer[0]=='y' || answer[0]=='Y' )
	{
		sprintf(buf, "%s[%s] ", YOUR_REAL_NAME, record.real_name);
		asking(fd, buf, answer, 20);
		if( answer[0]!=0 && answer[0]!=13 )
			strcpy(record.real_name, answer);

		sprintf(buf, "%s[%s] ", YOUR_EMAIL_ADD, record.email);
		asking(fd, buf, answer, 40);
		if( answer[0]!=0 && answer[0]!=13 )
			strcpy(record.email, answer);

		/*
		sprintf(buf, "%s[%s] ", YOUR_TERM, record.term);
		asking(fd, buf, answer, 8);
		if( answer[0]!=0 && answer[0]!=13 )
			strcpy(record.term, answer);
		*/

		sprintf(buf, "%s[%s] ", YOUR_ADDRESS, record.address);
		asking(fd, buf, answer, 60);
		if( answer[0]!=0 && answer[0]!=13 )
			strcpy(record.address, answer);

		sprintf(buf, "%s[%s] ", YOUR_PHONE, record.phone);
		asking(fd, buf, answer, 20);
		if( answer[0]!=0 && answer[0]!=13 )
			strcpy(record.phone, answer);

		sprintf(buf, "%s[%c] ", YOUR_SEX, record.sex);
		asking(fd, buf, answer, 2);
		if( answer[0]!=0 && answer[0]!=13 )
			record.sex=answer[0];

		sprintf(buf, "%s[%s] ", YOUR_INTEREST, record.interest);
		asking(fd, buf, answer, 21);
		if( answer[0]!=0 && answer[0]!=13 )
			strcpy(record.interest, answer);

		sprintf(buf, "%s[%s] ", YOUR_SPEC, record.spec);
		asking(fd, buf, answer, 41);
		if( answer[0]!=0 && answer[0]!=13 )
			strcpy(record.spec, answer);

		asking(fd, CONFIRM_MSG, answer, 2);
		if( answer[0]=='y' || answer[0]=='Y' )
		{
			do_log(6, "%s change personal data", user_name);
			strcpy(user_email, record.email);
			flock(udbf, LOCK_EX);
			lseek(udbf, user_uid*sizeof(struct udb), SEEK_SET);
			write(udbf, &record, sizeof(struct udb) );
			flock(udbf, LOCK_UN);
		}
	}

	close(udbf);
}
/*end of chn_persondata*/



/*
	chk_user_database
*/
chk_user_database()
{
	char filename[80];
	char re_build=FALSE;
	int dbf;
	struct udb udbrec;
	struct system_rec sysrec;

	if( debug_mode ) printf("(misc.c)chk_user_database\n");

	sprintf(filename, "%s.dbf", USER_DATA_BASE);
	if( file_exist(filename) )
	{
		if( flength(filename) < sizeof(struct udb) )
			re_build=TRUE;
	}
	else
		re_build=TRUE;

	if( re_build )
	{
		if(debug_mode) printf("(misc.c)rebuild user database\n");
		dbf=open(filename, O_WRONLY | O_CREAT | O_TRUNC, S_IWUSR | S_IRUSR);
		write(dbf, &udbrec, sizeof(struct udb) );
		lseek(dbf, 0, SEEK_SET);
		sysrec.total_regs=0;
		sysrec.total_login=0;
		write(dbf, &sysrec, sizeof(struct system_rec) );
		close(dbf);
	}
}
/*end of chk_user_database*/

		

/*
        get_system --- get system record (user database rec#0) ansd add
		       total_login ++
*/
get_system()
{
        int udbf;
        char dbf[80];
	struct system_rec sysrec;

	if(debug_mode) printf("(misc.c)get_system\n");

        sprintf(dbf, "%s.dbf", USER_DATA_BASE);
        udbf=open(dbf, O_RDWR);

        /*get system record*/
        flock(udbf, LOCK_EX);
        lseek( udbf, 0, SEEK_SET);
        read(udbf, &sysrec, sizeof(struct system_rec) );
        total_regs=sysrec.total_regs;
        total_login=++sysrec.total_login;
        lseek( udbf, 0, SEEK_SET);
        write(udbf, &sysrec, sizeof(struct system_rec) );
        flock(udbf, LOCK_UN);
}
/*end of get_system*/



/*
	ltoa --- unsigned long to ascii with base n
*/
ltoa(number, buffer, base)
        unsigned long number;
        char *buffer;
        char base;
{
        char *idmap="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        unsigned long n;
        char buf[128];
        char *p;
        char nbase;

        nbase=base;

        if( nbase<=1 )
                nbase=strlen(idmap);

        n=number;

        memset(buf, 0, 128);
        p=buf+126;

        do
        {
                *p=idmap[n%nbase];
                p--;
                n/=nbase;
        } while(n>0);

        strcpy(buffer, p+1);
}
/*end of ltoa*/



/*
	get_mid --- assemble Message-ID, use time and uid with ltoa of max base
*/
get_mid(mid)
	char *mid;
{
	char buf[128];
	unsigned long longtime;

	ltoa((unsigned long)user_uid, buf, 0);
	strcpy(mid, buf);

	time(&longtime);
	ltoa(longtime, buf, 0);
	strcat(mid, buf);
}
/*end of get_mid*/



/*
	set_mail_quote --- set mail quote to user #uid to notify new mbox mail
*/
set_mail_quote(uid, quote)
	int uid;
	char quote;	/*'Y;' or ' '*/
{
        char udbfile[255];
        int udbf;
        struct udb record;

        sprintf(udbfile, "%s.dbf", USER_DATA_BASE);
        udbf = open(udbfile, O_RDWR);
	lseek( udbf, uid*sizeof(struct udb), SEEK_SET);

	read(udbf, &record, sizeof(struct udb));
	if( debug_mode ) printf("(misc.c)set_mail_quote '%c' to user #%d\n", quote, uid);

	record.mailbox=quote;

	lseek( udbf, uid*sizeof(struct udb), SEEK_SET);
	write(udbf, &record, sizeof(struct udb));

	close(udbf);
}
/*end of set_mail_quote*/



/*
	check_mail_quote --- check mail quote
*/
check_mail_quote(uid)
	int uid;
/*
	return:
		TRUE:	mail quote on
		FALSE:	mail quote off
*/
{
        char udbfile[255];
        int udbf;
        struct udb record;
	char quote;

        sprintf(udbfile, "%s.dbf", USER_DATA_BASE);
        udbf = open(udbfile, O_RDWR);
	lseek( udbf, uid*sizeof(struct udb), SEEK_SET);

	read(udbf, &record, sizeof(struct udb));
	quote=record.mailbox;

	if( debug_mode ) printf("(misc.c)check_mail_quote '%c' for user #%d\n", quote, uid);

	close(udbf);

	if( quote=='Y' )
		return TRUE;
	else
		return FALSE;

}
/*end of check_mail_quote*/



/*
	get_user_data --- get user data record
*/
get_user_data(dbr, uid)
	struct udb *dbr;
	int uid;
/*
	return:
		TRUE:	OK
		FALSE:	no such user id
*/
{
        char udbfile[255];
        int udbf;
	int ret;

        sprintf(udbfile, "%s.dbf", USER_DATA_BASE);
        udbf = open(udbfile, O_RDWR);
	lseek( udbf, uid*sizeof(struct udb), SEEK_SET);

	ret=read(udbf, dbr, sizeof(struct udb));
	if(debug_mode) printf("(get_user_data)get user #%d\n", uid);

	close(udbf);

	if( ret<sizeof(struct udb) ) return(FALSE);
	else return(TRUE);
}
/*end of get_user_data*/



/*
	set_user_data --- set user data record
*/
set_user_data(dbr, uid)
	struct udb *dbr;
	int uid;
{
        char udbfile[255];
        int udbf;
	int ret;

        sprintf(udbfile, "%s.dbf", USER_DATA_BASE);
        udbf = open(udbfile, O_RDWR);
	lseek( udbf, uid*sizeof(struct udb), SEEK_SET);

	write(udbf, dbr, sizeof(struct udb));
	if(debug_mode) printf("(set_user_data)set user #%d\n", uid);

	close(udbf);
}
/*end of set_user_data*/



/*
	get_total_user_recs --- get total user records
*/
get_total_user_recs()
/*
	return:
		total USER_DATA_BASE.dbf records
*/
{
        char udbfile[255];

        sprintf(udbfile, "%s.dbf", USER_DATA_BASE);

	return( flength(udbfile)/sizeof(struct udb) );
}
/*end of get_total_user_recs*/


/*
	strip_nl --- strip cr-lf
*/
strip_nl(buf)
	char *buf;
{
	int n;
	int len;

	len=strlen(buf);

	for(n=0; n<len; n++)
		if( buf[n]==0 || buf[n]==13 || buf[n]==10 )
		{
			buf[n]=0;
			break;
		}
}
/*end of strip_nl*/



/*
	split_filename --- filter filename without path
*/
split_filename(filename, fn)
	char *filename;
	char *fn;
{
	char *ptr;
	int i;

  ptr=filename+strlen(filename)-1 ;
  while((*ptr!='/') && (*ptr!='\\') && (ptr!=filename))
    ptr-- ;
  
  ptr=(ptr==filename) ? ptr:ptr+1 ;  
  strcpy(fn,ptr) ;
  for(i=0; i<strlen(fn); i++)	/*--- check file name ---*/
  {
    if(fn[i]<33)
    {
      fn[i]=0 ;  
      break ;
    }  
  }  

  if( (fn[0]==0) || (strchr(fn, '/')!=NULL) || !strcmp(fn, "..") || !strcmp(fn, ".") )
  {
	/*user try an illegle path*/
  	strcpy(fn, "wrong"); /*obviously... it may be a wrong path*/
  }

}
/*end of split_filename*/



/*
	email_check --- check a string if it like a email address
*/
email_check(add)
	char *add;
/*
	return:
		TRUE: OK, it is like a email address
		FALSE: it is not a email address absolutely
*/
{
	char *check;
	int n;

	check=strchr(add, '@');
	if( check==NULL )
		return(FALSE);

	for(n=0; n<strlen(add); n++)
	{
		if( ((unsigned int)(add[n]))>127 )
		{
			/*I don't belevie that chinese can be the email add*/
			return(FALSE);
		}
	}

	check=strchr(add, '(');
	if( check!=NULL )
		return(FALSE);

	check=strchr(add, ')');
	if( check!=NULL )
		return(FALSE);

	check=strchr(add, '+');
	if( check!=NULL )
		return(FALSE);

	check=strchr(add, '^');
	if( check!=NULL )
		return(FALSE);

	check=strchr(add, '&');
	if( check!=NULL )
		return(FALSE);

	check=strchr(add, '*');
	if( check!=NULL )
		return(FALSE);

	/*pass OK, maybe it is really a email address*/
	return(TRUE);
}
/*end of email_check*/



/*
	lock_pid --- lock a file to prevent from duplicat running
*/
lock_pid()
/*
	return:
		TRUE:	OK.
		FALSE:	flaied, maybe programm has been running
*/
{
	char pidfile[128];
	int lock;
	char pid[10];
	int ret;

	sprintf(pidfile, "pbbsd.pid.%d", PBBS_SERV_PORT);
	sprintf(pid, "%5d\n", getpid() );

	lock=open(pidfile, O_WRONLY | O_CREAT, S_IWUSR | S_IRUSR);

	/*test locking*/
	ret=flock(lock, LOCK_EX | LOCK_NB);

	if( ret<0 )
		return(FALSE);	/*open pid file error, maybe lock exist*/

	write(lock, pid, strlen(pid) );

	return(TRUE);
}
/*end of lock_pid*/



/*
	suspend --- suspend client
*/
suspend(fd)
	int fd;
{
	send_mpf(fd, NULL, 0, SUSPEND);
}
/*end of suspend*/


/*
	nstrcpy --- some stange STRING hate strcpy... also size control is
		    needed
*/
nstrcpy(t, s, ms)
	char *t;	/*target*/
	char *s;	/*source*/
	int ms;		/*max size*/
{
	int cpn;

	for(cpn=0; cpn<ms; cpn++)
	{
		t[cpn]=s[cpn];

		if(s[cpn]==0)
			break;
	}

	t[ms-1]=0;
}
/*end of nstrcpy*/



/*
	process_user_name --- process a user name string to Fnam Lnam
*/
process_user_name(uname)
	char *uname;
{
	int n;

	uname[20]=0 ;
	uname[0]=toupper(uname[0]) ;
	for(n=1; n<strlen(uname); n++)
	{
		if(uname[n]==32)
		{
			n++ ;
			uname[n]=toupper(uname[n]) ;
		}
		else
		{  
			uname[n]=tolower(uname[n]) ;
		}  
	}

}
/*end of process_user_name*/


/*
	file_length --- return file size of fd
*/
file_length(fd)
        int fd;
{
        struct stat buf;
        fstat(fd, &buf);
        return(buf.st_size);
}
/*end of file_length*/



/*
	trim_comment --- strip blanks, tabs, and chars after #
*/
trim_comment(line)
	char *line;	/*buffer to be trimmed*/
{
	char buf[256];
	char *p;
	int n;
	char next_word=FALSE;

	strcpy(buf, line);
	p=line;

	for(n=0; n<strlen(buf); n++)
	{
		if(buf[n]=='#' || buf[n]==13 || buf[n]==10) break;
		if(buf[n]==32 || buf[n]==9)
		{
		  if( next_word )
		  {
			*p=32;
			p++;
			next_word=FALSE;
		  }
		  continue;
		}

		next_word=TRUE;
		*p=buf[n];
		p++;
	}

	*p=0;

	n=strlen(line);
	if(n>0)
	  if(line[n-1]==32) line[n-1]=0;
}
/*end of trim_comment*/



/*
	next_char --- find next [char] in the string
*/
next_char(str, c)
	char *str;
	char c;		/*char to be searched*/
/*
	return: position : 0 to n
*/
{
	int l, n=0;

	for(l=0; l<strlen(str); l++)
	{
		if( str[l]==c || str[l]==0)
			break;

		n++;
	}

	return(n);
}
/*end of next_char*/



/*
	next_blank --- find next blank in the string
*/
next_blank(str)
	char *str;
/*
	return: position : 0 to n
*/
{
	return( next_char(str, 32) );
}
/*end of next_blank*/



/*
	next_params --- find next position not blank or tab in the string
*/
next_params(str)
	char *str;
/*
	return: position : 0 to n
*/
{
	int l, n=0;

	for(l=0; l<strlen(str); l++)
	{
		if( str[l]!=32 && str[l]!=9 && str[l]!=0 )
			break;

		n++;
	}

	return(n);
}
/*end of next_params*/



/*
	next_tab_space --- find next position blank or tab in the string
*/
next_tab_space(str)
	char *str;
/*
	return: position : 0 to n
*/
{
	int l, n=0;

	for(l=0; l<strlen(str); l++)
	{
		if( str[l]==32 || str[l]==9 || str[l]==0 )
			break;

		n++;
	}

	return(n);
}
/*end of next_tab_space*/



/*
	blank trim by KKY
*/
int alltrim(str)
char *str ;
/*******************************************
    return     0   : if NULL string
            length : the new strlen.
********************************************/            
{
  int i=0 ;
  
    while((*(str+i)==32) || (*(str+i)==9))
    {
      i++ ;
    }  
    memcpy(str,(str+i),strlen(str)-i+1) ;
        
    i=strlen(str)-1 ;
    while(((*(str+i)==32) || (*(str+i)==9)  || (*(str+i)==10)) && (i>=0))
    {
      i-- ;
    }
    *(str+i+1)=0 ;
    
    return(strlen(str)) ;
}     
/*end of alltrim*/



/*
	switch_page --- switch page mode

	use bit-0 of user_set[0], it is a mask bit, that is,
	0: means page ON
	1: menas page OFF
*/
switch_page(fd)
	int fd;
{
	struct udb urec;

	get_user_data(&urec, user_uid);

	if( (urec.user_set[0] & 1)==0 )
	{
		/* on -> off */
		display_msg(fd, PAGE_OFF);
		suspend(fd);
	}
	else
	{
		/* off -> on */
		display_msg(fd, PAGE_ON);
		suspend(fd);
	}

	urec.user_set[0] ^= 1;

	set_user_data(&urec, user_uid);
}
/*end of switch_page*/



/*
	get_on_line_users_by_putmp --- get on line users
	
	SIGCHLD will be ignored on System V. We cannot use
	fork-increase-child_exit-decrease to count on_line_users.
	So we count the on_line putmp file to count users
*/
get_on_line_users_by_putmp()
{
	int utf;
        struct putmp purec;

	utf=open(ON_LINE_USER, O_RDONLY);

	on_line_users=0;

	if( !file_exist(ON_LINE_USER) ) return;

	while( read(utf, &purec, sizeof(struct putmp) ) )
	{
		if( purec.active ) on_line_users++;
	}
		
	close(utf);

}
/*end of get_on_line_users_by_putmp*/



/*
	getuidbyname --- get system uid by RUN_USER
*/
getuidbyname(name)
	char *name;
{
	struct passwd *ent;

	if( name[0]=='#' )
		return(atoi(name+1));

	ent=getpwnam(name);

	if( !ent )
	{
		do_log(9, "BAD RUN_USER '%s' setup!", RUN_USER);
		return(-1);
	}
	else
		return(ent->pw_uid);

}
/*end of getuidbyname*/



/*
	getgidbyname --- get system group id by RUN_GROUP
*/
getgidbyname(name)
	char *name;
{
	struct group *ent;

	if( name[0]=='#' )
		return(atoi(name+1));

	ent=getgrnam(name);

	if( !ent )
	{
		do_log(9, "BAD RUN_GROUP '%s' setup!", RUN_GROUP);
		return(-1);
	}
	else
		return(ent->gr_gid);

}
/*end of getgidbyname*/



/*
	change_run_id --- change process running id
*/
change_run_id()
{
	int user_id, group_id;

	if( !strcmp(RUN_USER, "OWNER") || !strcmp(RUN_GROUP, "OWNER") )
		return;

	user_id=getuidbyname(RUN_USER);
	group_id=getgidbyname(RUN_GROUP);

	if( user_id<0 || group_id<0 )
		return;

	/*set log file permission first*/
	if( file_exist(LOGFILE) )
		chown(LOGFILE, (uid_t) user_id, (gid_t) group_id);

	/*set gid then uid*/
	if( setgid((gid_t) group_id)==-1 )
		do_log(9, "set gid failed!?");

	if( setuid((uid_t) user_id)==-1 )
		do_log(9, "set uid failed!?");
}
/*end of change_run_id*/
