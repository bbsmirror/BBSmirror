/*************************************************************************
 * upload.c --- upload files						 *
 *	      by Samson Chen, Apr 15, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"

static char rcsid[]="$Id: upload.c,v 1.5 1994/05/16 09:53:00 pbbs Exp pbbs $";



/*
	upload --- upload a file
*/
upload(fd)
	int fd;
{
	int n;
	char bfile[255];
	char line_buf[255];
	char fbuf[80];
	char tbuf[15];
	char pbuf[120];
	char fbbs[120];
	int fb;
	char file_descrip[40];
	char upload_time[26];
	int ret;
	int test;
	int upload_level=0;
	char up_file[80];

	if(debug_mode) printf("(upload.c)uploading\n");

	sprintf(bfile, "%s/%s/post.security", FILE_PATH, UPLOAD_PATH);
	if( file_exist(bfile) )	/*post security found*/
	{
		test=open(bfile, O_RDONLY);
		if( test>0 )
		{
			ret=read(test, line_buf, 5);
			line_buf[ret]=0;
			upload_level=atoi(line_buf);
			if(debug_mode) printf("(upload.c)file post.security:%d\n", upload_level);
		}
		else
		{
			do_log(8, "uploads file post.security file error");
		}
	}

	if( user_level < upload_level )
	{
		if(debug_mode) printf("(upload.c)upload security protected\n");
		sprintf(line_buf, "%s%d\n", UPLOAD_SECURITY, upload_level);
		display_msg(fd, line_buf);
		return;
	}

	update_act(9, NULL);

	sprintf(up_file, "%s/%s", FILE_PATH, UPLOAD_PATH);
	sprintf(pbuf, "%s/%s", FILE_PATH, UPLOAD_PATH);

	if(debug_mode) printf("(upload.c)do receiving\n");
	if( recv_file(fd, up_file) )
	{
		memset(file_descrip, 0, 40);
		asking(fd, UPLOAD_DESCRIPTION, file_descrip, 40);

		strcpy(fbuf, up_file);
		strcat(fbuf, "                ");
		sprintf(pbuf, "%s/%s/%s", FILE_PATH, UPLOAD_PATH, up_file);
		file_time_format(tbuf);

		sprintf(line_buf, "%-.16s%8ld %s %s\n", fbuf, flength(pbuf), tbuf, file_descrip);

		sprintf(fbbs, "%s/%s/%s", FILE_PATH, UPLOAD_PATH, FILE_LIST);
		fb=open(fbbs, O_WRONLY | O_APPEND | O_CREAT, S_IWUSR | S_IRUSR);
		write(fb, line_buf, strlen(line_buf) );
		close(fb);

		display_msg(fd, THANKS_UPLOAD);
		do_log(5, "%s upload a file %s", user_name, up_file);
	}
	else
	{
		display_msg(fd, UPLOAD_FAILED);
		do_log(2, "%s upload failed", user_name);
	}


}
/*end of upload*/
