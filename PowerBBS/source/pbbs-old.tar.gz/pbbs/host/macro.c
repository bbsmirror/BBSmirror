/*************************************************************************
 * macro.c --- macro control module					 *
 *	       by Samson Chen, Dec 3, 1993				 *
 *************************************************************************/

#include "pbbs.h"
#include "dbf.h"
#include "global.h"


/*
	replace macro string --- {$#}
*/
parse_macro(buf)
	char *buf;	/*buffer ready to be parsed*/
{
	int n, len;
	char rmacro[100];
	char tempbuf[255];
	char do_replace;
	struct udb rec;

	while(1)	/*re-do until all macro are replaced*/
	{
	do_replace=FALSE;

	len = strlen(buf);

	for(n=0; n<len; n++)
	{
	  if( buf[n] == '{' )
	    if( (len-n) >= 4 )
	    {
	      if( buf[n+1]=='$' && buf[n+3]=='}' )
	      {
		do_replace=TRUE;

		switch( buf[n+2] )
		{
		case 'a':	/*client's address*/
			strcpy(rmacro, client_site);
			break;

		case 'b':	/*user total login*/
			get_user_data(&rec, user_uid);
			sprintf(rmacro, "%d", rec.total_login);
			break;

		case 'c':	/*total logins*/
			sprintf(rmacro, "%ld", total_login);
			break;

		case 'f':	/*current file area*/
			sprintf(rmacro, "%s", file_area);
			break;

		case 'g':	/*current group*/
			sprintf(rmacro, "%s", group_areaname);
			break;

		case 'l':	/*user level*/
			sprintf(rmacro, "%d", user_level);
			break;

		case 'n':	/*user name*/
			sprintf(rmacro, "%s", user_name);
			break;

		case 'r':	/*total_registers*/
			sprintf(rmacro, "%d", total_regs);
			break;

		case 't':	/*daytime*/
			get_daytime(rmacro);
			break;

		case 'u':	/*on_line_users*/
			/*
			note: because only parent process know the real
			on_line users, please use this macro only at
			PRELOG_FILE and HEAVY_LOAD_FILE
			*/
			sprintf(rmacro, "%d", on_line_users);
			break;

		default:
			do_replace=FALSE;	/*not current macro*/
		}/*end of switch*/

		if(do_replace) break;

	      }
	    }
	}/*end for*/


	if( do_replace )
	{
		/*relpace macro with rmacro*/
		strcpy(tempbuf, buf+(n+4) );
		buf[n]='\0';
		strcat(buf, rmacro);
		strcat(buf, tempbuf);
	}
	else
		return;
	} /*end while*/

}/*end of parse_macro*/
