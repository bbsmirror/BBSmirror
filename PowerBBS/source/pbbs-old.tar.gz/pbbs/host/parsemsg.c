/*************************************************************************
 * parsemsg.c --- parsing head						 *
 *	      by Samson Chen, Apr 8, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "global.h"

static char rcsid[]="$Id: parsemsg.c,v 1.1 1994/04/22 10:03:59 pbbs Exp pbbs $";

parse_msg(fd, msg, phead)
	int fd;
	char *msg;	/*original message text*/
	char *phead;	/*parsing head, if "MSG" means message body*/
/*
	return:
		position of the parsed head
		-1 means not found

	note: after parsing, the *msg will NOT be destroyed
*/
{
	char buf[1024];
	char *point;
	char head=TRUE;
	int n,p;
	int fp;

	/*
	if(debug_mode) printf("(parsemsg.c)parse_msg '%s'\n", phead);
	*/

	point=msg;
	n=0;

	do
	{
	  /*find a line*/
	  for(p=n;p<strlen(msg);p++)
		if( msg[p]==13 ) break;

	  if( p>=strlen(msg) )
	  {
		do_log(9, "parsing message error for %s", user_name);
		return(-1);
	  }

	  /*CR-LF-CR-LF appeared, head field finished*/
	  if( n==p )
	  {
		head=FALSE;

		if( !strcmp(phead, "MSG") )
			fp=n;
		else
			fp=-1;

		continue;
	  }

	  /*cut a line*/
	  strncpy(buf, msg+n, p-n);
	  buf[p-n]=0;

	  /*parse line*/
	  if( !strncmp(buf, phead, strlen(phead) ) )
	  {
		head=FALSE;
		fp=n;
		continue;
	  }


	  n=p+2;  /*skip CR-LF*/

	}while(head);

	/*
	if(debug_mode) printf("(parsemsg.c)return fp=%d\n", fp);
	*/

	return(fp);
}
/*end of parse_msg*/
