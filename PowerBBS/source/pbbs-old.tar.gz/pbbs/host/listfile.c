/*************************************************************************
 * listfile.c --- list files						 *
 *	      by Samson Chen, Apr 12, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"
#include "dbf.h"

static char rcsid[]="$Id: listfile.c,v 1.3 1994/05/04 05:51:13 pbbs Exp pbbs $";

char line[81];
char scrbuf[9120];



/*
	list_files --- (as the name)
*/
list_files(fd)
	int fd;
{
	char bfile[255];
	char do_ls[255];
	char answer[80];
	char *ppt;
	FILE *filesbbs;
	char use_filelist;	/*for fclose or pclose*/
	int scr_size;
	int scr_cnt;
	char leave;
	char no_more;
	int rlen;
	char protocol;

	if(debug_mode) printf("(list_files)curren file area: %s\n", file_area);

	sprintf(bfile, "%s/%s/%s", FILE_PATH, file_area, FILE_LIST);

	if( file_exist(bfile) )	/*FILE_LIST found*/
	{
		filesbbs=fopen(bfile, "r");
		use_filelist=TRUE;
		if(debug_mode) printf("(listfile.c)send FILE_LIST\n");
	}
	else
	{
		sprintf(do_ls, "ls -lL %s/%s", FILE_PATH, file_area);
		filesbbs=popen(do_ls, "r");
		use_filelist=FALSE;
		if(debug_mode) printf("(listfile.c)send 'ls -l'\n");
	}


	/*get client's screen size*/
	send_mpf(fd, NULL, 0, SCRSIZE);
	read_mpf(fd, answer, &rlen, &protocol, FALSE);
	if( protocol != SCRSIZE )
	{
		do_log(8, "%s protocol_stat_err with protocol code %d at list_files", user_name, protocol);
		protocol_stat_err(fd);
	}

	answer[rlen]=0;
	strip_nl(answer);
	scr_size=atoi(answer);
	if(debug_mode) printf("(listuser.c)get screen size %d\n", scr_size);

	scr_cnt=0;
	leave=FALSE;
	no_more=TRUE;
	scrbuf[0]=0;
	display_msg(fd, "\n");

	memset(line, 0, 81);
	while( fgets(line, 81, filesbbs) && !leave )
	{
		scr_cnt++;

		if( use_filelist )
			ppt=line;
		else
			ppt=line+20;	/*strip permission display from ls*/

		strcat(scrbuf, ppt);
		no_more=FALSE;

		if( scr_cnt>= scr_size-2 )
		{
			display_msg(fd, scrbuf);
			asking(fd, LIST_CONTINUE, answer, 2);
			if( answer[0]=='n' || answer[0]=='N' )
			{
				leave=TRUE;
				no_more=TRUE;
				continue;
			}

			if( answer[0]=='t' || answer[0]=='T' )
				toggle_files(fd);

			scr_cnt=0;
			scrbuf[0]=0;
			no_more=TRUE;
		}

		memset(line, 0, 81);
	}/*end while*/

	if( !no_more )
	{
		display_msg(fd, scrbuf);
		display_msg(fd, "\n");
		toggle_files(fd);
	}

	if(use_filelist)
		fclose(filesbbs);
	else
		pclose(filesbbs);
}
/*end of list_files*/
