/*************************************************************************
 * sendfile.c --- send file to client					 *
 *	      by Aquarius Kuo, Apr 12, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"
#include "dbf.h"

static char rcsid[]="$Id: sendfile.c,v 1.1 1994/04/22 10:03:59 pbbs Exp pbbs $";

/*
	send_file --- send a file to client site
*/
int send_file(fd, filename)
int fd;
char *filename;
{
  int handle ;
  int i ;
  char prot ;
  char fn[80], *ptr ;
  char buffer[11000] ;
  long BLOCK ;
  long fl, len, len2 ;

    
  ptr=filename+strlen(filename)-1 ;
  while((*ptr!='/') && (ptr!=filename))
    ptr-- ;
  
  ptr=(ptr==filename) ? ptr:ptr+1 ;  
  strcpy(fn,ptr) ;
  for(i=0; i<strlen(fn); i++)	/*--- check file name ---*/
  {
    if(fn[i]<33)
    {
      fn[i]=0 ;  
      break ;
    }  
  }  

  do_log(3, "%s download %s", user_name, fn);

  send_mpf(fd, fn, strlen(fn), DOWNLOAD);	/*--- send file name ---*/
  if( debug_mode ) 	printf("(sendfile.c) filename = %s\n",fn) ;
  read_mpf(fd,buffer,&len,&prot,FALSE) ; 	/*--- read BLOCK size ---*/
  if(prot!=DOWNLOAD)
  {
    send_mpf(fd," ",0,STOPXFER) ;
    return(FALSE) ;
  }  
  buffer[len]=0 ;
  sscanf(buffer,"%ld",&BLOCK) ;
  if( debug_mode ) printf("(sendfile.c) BLOCK size = %d\n",BLOCK) ;
  if((BLOCK>11000) || (BLOCK<100))
  {
    do_log(9,"%s illegal block size %s",user_name,buffer) ;
    send_mpf(fd," ",0,STOPXFER) ;
    return(FALSE) ;
  }    
  fl=flength(filename) ;
  sprintf(buffer,"%ld",fl) ;
  if( debug_mode )	printf("(sendfile.c) file length = %s\n",buffer) ;
  send_mpf(fd,buffer,strlen(buffer),DOWNLOAD) ;	/*--- send file length ---*/
  
  
  read_mpf(fd,buffer,&len,&prot,FALSE) ;
  if(prot==XFER_ACK)
  {
    if((handle=open(filename,O_RDONLY))<0)
    {
      if(debug_mode)	printf("(sendfile.c)open %s error!\n",fn) ;
      send_mpf(fd," ",0,STOPXFER) ;
      return(FALSE) ;
    }
    len=BLOCK ;
    if(len>fl)
      len=fl ;
    read(handle,buffer,len) ;
    send_mpf(fd,buffer,len,XFER_ACK) ;
    
    read_mpf(fd,buffer,&len2,&prot,FALSE) ;
    if(prot==STOPXFER)  
    {
      if(debug_mode) printf("(sendfile.c)got STOPXFER(a)\n");
      close(handle) ;
      return(FALSE) ;
    }  
    
    while((fl-len)>BLOCK)
    {
      read(handle,buffer,BLOCK) ;
      send_mpf(fd,buffer,BLOCK,XFER_ACK) ;
      read_mpf(fd,buffer,&len2,&prot,FALSE) ;
      if(prot==STOPXFER)
      {
        if(debug_mode) printf("(sendfile.c)got STOPXFER(b)\n");
        close(handle) ;  
        return(FALSE) ;
      }  
      else  
        len+=BLOCK ;
    }   
    len=fl-len ;
    read(handle,buffer,len) ;
    send_mpf(fd,buffer,len,XFER_ACK) ;
  }
  read_mpf(fd,buffer,&len,&prot,FALSE) ;
  send_mpf(fd," ",0,END_XFER) ;
  return(TRUE) ;
}
/*end of send_file*/
