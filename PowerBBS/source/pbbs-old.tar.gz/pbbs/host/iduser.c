/************************************************
    To get user name and limit times.
    
    write by Aquarius Kuo. Mar 17, 1994.
*************************************************/    
#include "pbbs.h"
#include "global.h"
#include "message.h"
#include <ctype.h>

int is_boolean(c)
char c ;
{
  int retval ;

  switch(c)
  {
    case 'y':
    case 'Y':
    case 'n':
    case 'N':
    case 'q':
    case 'Q':
    case '=':
      retval=1 ;
      break ;
    default:
      retval=0 ;
  }
  return(retval) ;
}

 
int chk_baduser(name)
char *name ;
{
  FILE *fp ;
  char badname[80] ;

  if((fp=fopen(BAD_USER,"r"))==NULL)
  {
     if(debug_mode)printf("(iduser.c) BAD_USER file not found!\n") ;
     return(FALSE) ;
  }

  while(fgets(badname,50,fp)!=NULL)
  {
    if(alltrim(badname)==0)
      continue ;
    if(strstr(name,badname)!=NULL)
    {
      fclose(fp) ;
      do_log(5, "client from %s uses baduser name %s", client_site, name);
      return(TRUE) ;
    }
  }
  if(debug_mode)  printf("(iduser.c) BAD_USER test passed!\n") ;  

  fclose(fp) ;
  return(FALSE) ;
}
 

int get_user_name(fd,name)
int fd ;
char *name ;
/*********************************
   return:  1  OK
            0  new user
           -1  ERROR
**********************************/
{
  unsigned char buffer[100],name1[100],prot[1] ;
  long len=20 ;
  char *here ;
  int cnt=0, i, j ;  
  int uid ;
  int looptimes=0;	/*-- login in ---*/

  do
  {
    asking(fd,FIRST_NAME_PLZ,buffer,20) ;	/*-- ask userID --*/

    for(i=0; i<strlen(buffer); i++)
    {
      if( isalnum(buffer[i]) )
        continue ;

      if( (buffer[i]=='.') || (buffer[i]=='-') )
        continue ;
      if( (buffer[i]=='_') || (buffer[i]==32) )
        continue ;

      for(j=i; j<strlen(buffer); j++)
        buffer[j]=buffer[j+1] ;  

      i=-1 ;  
    }
         
    if((cnt=alltrim(buffer))<1)
      continue ;
      
    strcpy(name1,buffer) ;
        
    if((here=strchr(name1,32))==NULL)  /*-- ask last name --*/
    {
      if(cnt>15)
        continue ;
      strcat(name1," ") ;
      send_mpf(fd,LAST_NAME_PLZ,strlen(LAST_NAME_PLZ),ASK) ;
      read_mpf(fd,buffer,&len,prot,0) ;
      buffer[len]=0 ;    
      if(*prot!=ASK)
      {
        do_log(8, "%s protocol_stat_err with protocol code %d at get_user_name(b)", client_site, *prot);
        protocol_stat_err(fd) ;
      }
      for(i=0; i<strlen(buffer); i++)
      {
        if( isalnum(buffer[i]) )
          continue ;

        if( (buffer[i]=='.') || (buffer[i]=='-') )
          continue ;
        if( (buffer[i]=='_') || (buffer[i]==32) )
          continue ;

        for(j=i; j<strlen(buffer); j++)
        buffer[j]=buffer[j+1] ;  

        i=-1 ;  
      }
      if(alltrim(buffer)<1)
        continue ;
      for(cnt=0; cnt<len; cnt++)
      {
	if((*(buffer+cnt)==32) || (*(buffer+cnt)==9))
	{
	  *(buffer+cnt)=0 ;
	  break ;
	}
      }
      cnt=alltrim(buffer) ;
      if((cnt<1)||(cnt>15))
        continue ;
      strcat(name1,buffer) ;
    }
    else
    {
      *here=0 ;
      cnt=alltrim(name1) ;
      if((cnt<1)||(cnt>15))
        continue ;      
      strcpy(buffer,here+1) ;
      alltrim(buffer) ;
            
      here=strchr(buffer,32) ;
      
      if(here!=NULL)
      {
        *here=0 ;
        cnt=alltrim(buffer) ;
        if((cnt<1)||(cnt>15))
          continue ;
      }
      
      here=strchr(buffer,9) ;
      if(here!=NULL)
      {
	*here=0 ;
	cnt=alltrim(buffer) ;
	if((cnt<1)||(cnt>15))
	  continue ;
      }
      
      strcat(name1," ") ;
      strcat(name1,buffer) ;  
    }
    name1[19]=0 ;
    strcpy(name,name1) ;
    name[0]=toupper(name[0]) ;
    for(cnt=1; cnt<strlen(name); cnt++)
    {
      if(name[cnt]==32)
      {
    cnt++ ;
        name[cnt]=toupper(name[cnt]) ;
      }
      else
      {  
        name[cnt]=tolower(name[cnt]) ;
      }  
    }
    if (debug_mode)
      printf("(iduser.c)get_user_name  ----> [%s]\n",name) ;
    
    if(chk_baduser(name))
    {
       display_msg(fd,BAD_USER_REJECT) ;
       reject(fd,21) ;
    }

    if((uid=get_user_id(name))>0)
    {
      return(uid) ;
    }
    else        /*-- ask if the new user --*/
    {
      cnt=1 ;
      do
      {
	strcpy(buffer,name) ;
        strcat(buffer," ") ;
        strcat(buffer,ARE_YOU_NEW) ;
        send_mpf(fd,buffer,strlen(buffer),ASK) ;
        read_mpf(fd,buffer,&len,prot,0) ;
        if(++cnt>MAX_LOGIN)
          break ;
      }
      while(!is_boolean(buffer[0])) ;
      if((buffer[0]=='y')||(buffer[0]=='Y'))
      {
        return(0) ;             /*--- is new user ---*/
      }
      else
	continue ;
    }
  }
  while((++looptimes)<MAX_LOGIN) ;
  name[0]=0;
  return(-1) ;
}

