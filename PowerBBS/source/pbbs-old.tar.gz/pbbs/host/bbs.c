/**************************************************************************
 * bbs.c --- bbs service shell						  *
 *	     by Samson Chen, Nov 29, 1993				  *
 **************************************************************************/

#include "pbbs.h"
#include "menu.h"
#include "message.h"
#include "global.h"

static char rcsid[]="$Id: bbs.c,v 1.6 1994/07/13 15:37:46 pbbs Exp pbbs $";

/*
	Shell of BBS service
*/
do_BBS(fd)
	int fd;
{
	char fbuf[255];
	int menu_code=MAIN_MENU;
	int previous_menu;
	char leave=FALSE;

	/*get system record*/
	get_system();

	/*sending prompt messages of client site*/
	send_prompt(fd);

	/*show prelog message*/
	send_prelog(fd);

	login(fd);	/*if login fail, this routine will not return*/
			/*  otherwise, some user global vars will be setup*/

	if(user_level>=SYSOP_LEVEL)
	{
		system_operator=TRUE;
		do_log(2, "%s as SysOp log in", user_name);
	}

	/*show level message (macro available)*/
	sprintf(fbuf, "%s/%s.%d", MENU_PATH, LEVEL_MSG, user_level);

	if( file_exist(fbuf) )
	{
		if( debug_mode ) printf("(bbs.c)display '%s'\n", fbuf);
		send_file_display(fd, fbuf);
		suspend(fd);
	}

	/*show welcome message*/
	send_welcome(fd);

	/*initial posting group*/
	strcpy(current_group, "main");

	/*check mbox*/
	if( check_mail_quote(user_uid) )
	{
		set_mail_quote(user_uid, ' ');
		display_msg(fd, NEW_MBOX_MAIL);
		suspend(fd);
	}

	while( !leave )
	{

		switch(menu_code)
		{
			case MAIN_MENU:
				previous_menu=menu_code;
				update_act(1, NULL);
				menu_code=main_menu(fd);
				break;

			case MAIL_MENU:
				previous_menu=menu_code;
				update_act(2, NULL);
				menu_code=mail_menu(fd);
				break;

			case FILE_MENU:
				previous_menu=menu_code;
				update_act(3, NULL);
				menu_code=file_menu(fd);
				break;

			case TOOL_MENU:
				previous_menu=menu_code;
				update_act(4, NULL);
				menu_code=tool_menu(fd);
				break;

			case HELP_MAIN:
				send_help(fd, MAIN_HELP_FILE);
				menu_code=previous_menu;
				break;

			case HELP_MAIL:
				send_help(fd, MAIL_HELP_FILE);
				menu_code=previous_menu;
				break;

			case HELP_FILE:
				send_help(fd, FILE_HELP_FILE);
				menu_code=previous_menu;
				break;

			case HELP_TOOL:
				send_help(fd, TOOL_HELP_FILE);
				menu_code=previous_menu;
				break;

			case BULLETIN:
				update_act(5, " ");
				do_bulletin(fd);
				menu_code=previous_menu;
				break;

			case VERSION_INFO:
				show_copyright(fd);
				menu_code=previous_menu;
				break;

			case WELCOME:
				send_welcome(fd);
				menu_code=previous_menu;
				break;

			case PING:
				send_mpf(fd, NULL, 0, PECHO);
				display_msg(fd, "\n");
				suspend(fd);
				menu_code=previous_menu;
				break;

			case CHANGE_AREA:
				change_area(fd);
				menu_code=previous_menu;
				break;

			case QUICK_JOIN:
				quick_join(fd);
				menu_code=previous_menu;
				break;

			case READ_MAIL:
				read_mail(fd, 1, -1);
				menu_code=previous_menu;
				break;

			case INTER_READ:
				inter_read(fd);
				menu_code=previous_menu;
				break;

			case PREVIOUS_MAIL:
				read_previous_mail(fd);
				menu_code=previous_menu;
				break;

			case ENTER_MAIL:
				enter_mail(fd, 0, NULL, NULL, NULL);
				menu_code=previous_menu;
				break;

			case FILE_POST:
				enter_mail(fd, 2, NULL, NULL, NULL);
				menu_code=previous_menu;
				break;

			case KILL_MAIL:
				do_del_msg(fd);
				menu_code=previous_menu;
				break;

			case FILE_AREA:
				chn_file_area(fd);
				menu_code=previous_menu;
				break;

			case LIST_FILE:
				list_files(fd);
				menu_code=previous_menu;
				break;

			case TOGGLE_FILE:
				toggle_files(fd);
				menu_code=previous_menu;
				break;

			case RESET_TOGGLE:
				reset_toggles(fd);
				menu_code=previous_menu;
				break;

			case DOWNLOAD_FILE:
				download(fd);
				suspend(fd);
				menu_code=previous_menu;
				break;

			case UPLOAD_FILE:
				upload(fd);
				suspend(fd);
				menu_code=previous_menu;
				break;

			case C_PASSWORD:
				chn_passwd(fd, FALSE);
				menu_code=previous_menu;
				break;

			case U_PERSON_DATA:
				chn_persondata(fd);
				menu_code=previous_menu;
				break;

			case LIST_USER:
				list_users(fd);
				menu_code=previous_menu;
				break;

			case SWITCH_PAGE:
				switch_page(fd);
				menu_code=previous_menu;
				break;

			case WRITE_USER:
				write_user(fd);
				menu_code=previous_menu;
				break;

			case CHAT_ROOM:
				chat_room(fd);
				menu_code=previous_menu;
				break;

			case GOODBYE:
				leave=TRUE;
				bbs_bye(fd);
				break;

			default:
				unknown_menu(fd);
				suspend(fd);
				menu_code=previous_menu;
		}
	}
}
/*end of do_BBS*/

