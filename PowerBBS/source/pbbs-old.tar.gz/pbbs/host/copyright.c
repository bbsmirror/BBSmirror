/**********************************************************************
 * copyright.c --- show copy right message			      *
 *		   by Samson Chen, Nov 30, 1993			      *
 **********************************************************************/

#include "pbbs.h"

static char rcsid[]="$Id: copyright.c,v 1.7 1994/07/15 05:56:47 pbbs Exp pbbs $";

/*
	You cannot modify the following message without authors' permission
	This is protected by the copyright law
	If you have you own modified version, add your own message after *clf
*/
char *cl1="\n	 Power BBS since Nov 27, 1993\n";
char *cl2="	 version 1.1	July 15, 1994\n";
char *cl3="	 Developed by Team Square-1991 \n";
char *cl4="			Aquarius Kuo \n";
char *cl5="			Samson Chen \n \n";
char *cl6="	�ޢ��@�����@�ТТ� \n";
char *cl7="	1.1 ��	����K�Q�T�~�C��Q���� \n";
char *cl8="	�諰�o�i�p�� \n";
char *cl9="		���ЫT \n";
char *cla="		���ը� \n";
char *clb="		���ɦѮv : ��[���Ʊб� \n\n";
char *clc="	���ؤu�ǰ|  ��T�u�{�t\n\n";



/*
	display version information
*/
show_copyright(fd)
	int fd;
{
	display_msg(fd, cl1);
	display_msg(fd, cl2);
	display_msg(fd, cl3);
	display_msg(fd, cl4);
	display_msg(fd, cl5);
	display_msg(fd, cl6);
	display_msg(fd, cl7);
	display_msg(fd, cl8);
	display_msg(fd, cl9);
	display_msg(fd, cla);
	display_msg(fd, clb);
	display_msg(fd, clc);
	suspend(fd);
}
