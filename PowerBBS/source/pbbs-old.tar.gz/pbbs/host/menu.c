/************************************************************************
 * menu.c --- upper level menu processing				*
 *	      by Samson Chen, Nov 28, 1993				*
 ************************************************************************/

#include "pbbs.h"
#include "menu.h"
#include "message.h"
#include "global.h"

static char rcsid[]="$Id: menu.c,v 1.6 1994/07/13 15:37:46 pbbs Exp pbbs $";

char menu_sent[5]={FALSE, FALSE, FALSE, FALSE, FALSE};	
				/*suppose max 5 menu files*/
char bigbuf[MAX_BUF];
char menu_filename[255];
FILE *menu_file;
char line_buf[255];
char protocol;
unsigned long rlen;


/*
	send file to client for display	(macro available)
*/
send_file_display(fd, filename)
	int fd;
	char *filename;
{
	FILE *sfile;
	char lbuffer[255];

	/* get file */
	sfile=fopen(filename, "r");
	bigbuf[0]=0;
	while( fgets(lbuffer, 255, sfile) )
	{
		parse_macro(lbuffer);	/*check macro text*/
		strcat(bigbuf, lbuffer);
	}

	fclose(sfile);

	send_mpf(fd, bigbuf, strlen(bigbuf), DISPLAY);
} /*end of send_file_display*/



/*
	send prelog message to user	(macro available)
*/
send_prelog(fd)
	int fd;
{
	strcpy(menu_filename, MENU_PATH);
	strcat(menu_filename, "/");
	strcat(menu_filename, PRELOG_FILE);

	/* send prelog file */
	send_file_display(fd, menu_filename);
}
/*end of send_welcome*/



/*
	send welcome display to user	(macro available)
*/
send_welcome(fd)
	int fd;
{
	strcpy(menu_filename, MENU_PATH);
	strcat(menu_filename, "/");
	strcat(menu_filename, WELCOME_FILE);

	/* send welcome file */
	send_file_display(fd, menu_filename);

	suspend(fd);
}
/*end of send_welcome*/



/*
	send help file (macro available
*/
send_help(fd, helpfile)
	int fd;
	char *helpfile;
{
	sprintf(menu_filename, "%s/%s", MENU_PATH, helpfile);
	send_file_display(fd, menu_filename);
	suspend(fd);
}
/*end of send_help*/



/*
	user request main menu	(macro available)
*/
main_menu(fd)
	int fd;
{
	if( menu_sent[MAIN_MENU] )
		send_mpf(fd, "{Main_Menu}", 11, MENU);
	else
	{
		menu_sent[MAIN_MENU]=TRUE;	/*set sent-flag*/
		strcpy(menu_filename, MENU_PATH);
		strcat(menu_filename, "/");
		strcat(menu_filename, MAIN_MENU_FILE);

		/* get menu file */
		menu_file=fopen(menu_filename, "r");
		bigbuf[0]=0;
		while( fgets(line_buf, 255, menu_file) )
			if( line_buf[0]!='#' )
			{
				parse_macro(line_buf);
				strcat(bigbuf, line_buf);
			}

		send_mpf(fd, bigbuf, strlen(bigbuf), MENU);
	}

	do
	{
		read_mpf(fd, bigbuf, &rlen, &protocol, FALSE);
		if( protocol != MENU )
		{
			do_log(8, "%s menu_stat_err with protocol code %d at main_menu", user_name, protocol);
			menu_stat_err(fd);
		}

	} while (protocol != MENU);

	bigbuf[rlen]=0;
	return( parse_menu(bigbuf) );
}
/*end of main_menu*/
			
		

/*
	user request mail menu	(macro available)
*/
mail_menu(fd)
	int fd;
{
	if( menu_sent[MAIL_MENU] )
		send_mpf(fd, "{Mail_Menu}", 11, MENU);
	else
	{
		menu_sent[MAIL_MENU]=TRUE;	/*set sent-flag*/
		strcpy(menu_filename, MENU_PATH);
		strcat(menu_filename, "/");
		strcat(menu_filename, MAIL_MENU_FILE);

		/* get menu file */
		menu_file=fopen(menu_filename, "r");
		bigbuf[0]=0;
		while( fgets(line_buf, 255, menu_file) )
			if( line_buf[0]!='#' ) 
			{
				parse_macro(line_buf);
				strcat(bigbuf, line_buf);
			}

		send_mpf(fd, bigbuf, strlen(bigbuf), MENU);
	}

	do
	{
		read_mpf(fd, bigbuf, &rlen, &protocol, FALSE);
		if( protocol != MENU )
		{
			do_log(8, "%s menu_stat_err with protocol code %d at mail_menu", user_name, protocol);
			menu_stat_err(fd);
		}

	} while (protocol != MENU);

	bigbuf[rlen]=0;
	return( parse_menu(bigbuf) );
}
/*end of mail_menu*/


/*
	user request tool menu	(macro available)
*/
tool_menu(fd)
	int fd;
{
	if( menu_sent[TOOL_MENU] )
		send_mpf(fd, "{Tools}", 7, MENU);
	else
	{
		menu_sent[TOOL_MENU]=TRUE;	/*set sent-flag*/
		strcpy(menu_filename, MENU_PATH);
		strcat(menu_filename, "/");
		strcat(menu_filename, TOOL_MENU_FILE);

		/* get menu file */
		menu_file=fopen(menu_filename, "r");
		bigbuf[0]=0;
		while( fgets(line_buf, 255, menu_file) )
			if( line_buf[0]!='#' ) 
			{
				parse_macro(line_buf);
				strcat(bigbuf, line_buf);
			}

		send_mpf(fd, bigbuf, strlen(bigbuf), MENU);
	}

	do
	{
		read_mpf(fd, bigbuf, &rlen, &protocol, FALSE);
		if( protocol != MENU )
		{
			do_log(8, "%s menu_stat_err with protocol code %d at tool_menu", user_name, protocol);
			menu_stat_err(fd);
		}

	} while (protocol != MENU);

	bigbuf[rlen]=0;
	return( parse_menu(bigbuf) );
}
/*end of tool_menu*/



/*
	user request file menu	(macro available)
*/
file_menu(fd)
	int fd;
{
	if( menu_sent[FILE_MENU] )
		send_mpf(fd, "{File_Menu}", 11, MENU);
	else
	{
		menu_sent[FILE_MENU]=TRUE;	/*set sent-flag*/
		strcpy(menu_filename, MENU_PATH);
		strcat(menu_filename, "/");
		strcat(menu_filename, FILE_MENU_FILE);

		/* get menu file */
		menu_file=fopen(menu_filename, "r");
		bigbuf[0]=0;
		while( fgets(line_buf, 255, menu_file) )
			if( line_buf[0]!='#' ) 
			{
				parse_macro(line_buf);
				strcat(bigbuf, line_buf);
			}

		send_mpf(fd, bigbuf, strlen(bigbuf), MENU);
	}

	do
	{
		read_mpf(fd, bigbuf, &rlen, &protocol, FALSE);
		if( protocol != MENU )
		{
			do_log(8, "%s menu_stat_err with protocol code %d at file_menu", user_name, protocol);
			menu_stat_err(fd);
		}

	} while (protocol != MENU);

	bigbuf[rlen]=0;
	return( parse_menu(bigbuf) );
}
/*end of file_menu*/

/*
	bbs normal disconnect --- goodbye	(macro available)
*/
bbs_bye(fd)
	int fd;
{
	strcpy(menu_filename, MENU_PATH);
	strcat(menu_filename, "/");
	strcat(menu_filename, GOODBYE_FILE);

	/* get menu file */
	send_file_display(fd, menu_filename);

	suspend(fd);

	/*send byebye protocol*/
	send_mpf(fd, NULL, 0, BYEBYE);

	do_log(5, "%s logout", user_name);
}
/*end of bbs_bye*/



/*
	server get unknwon menu request
*/
unknown_menu(fd)
	int fd;
{
	char *msg=UNKNOWN_MENU_REQ;

	send_mpf(fd, msg, strlen(msg), ERROR);
}


/*
	server should get a menu request in menu stat
*/
menu_stat_err(fd)
	int fd;
{
	char *msg=MENU_STAT_ERR;

	send_mpf(fd, msg, strlen(msg), ERROR);
}



/*
	parse menu request string from client
*/
parse_menu(menu_str)
	char *menu_str;
{

	do_log(0, "%s parse menu-> %s", user_name, menu_str);

	if( !strcmp(menu_str, "{Main_Menu}") )
		return(MAIN_MENU);

	if( !strcmp(menu_str, "{Mail_Menu}") )
		return(MAIL_MENU);

	if( !strcmp(menu_str, "{Tools}") )
		return(TOOL_MENU);

	if( !strcmp(menu_str, "{File_Menu}") )
		return(FILE_MENU);

	if( !strcmp(menu_str, "{Bulletin}") )
		return(BULLETIN);

	if( !strcmp(menu_str, "{Change_Area}") )
		return(CHANGE_AREA);

	if( !strcmp(menu_str, "{Password}") )
		return(C_PASSWORD);

	if( !strcmp(menu_str, "{Enter_Mail}") )
		return(ENTER_MAIL);

	if( !strcmp(menu_str, "{UP_Data}") )
		return(U_PERSON_DATA);

	if( !strcmp(menu_str, "{Goodbye}") )
		return(GOODBYE);

	if( !strcmp(menu_str, "{Help_Mail}") )
		return(HELP_MAIL);

	if( !strcmp(menu_str, "{Help_Main}") )
		return(HELP_MAIN);

	if( !strcmp(menu_str, "{Help_Tools}") )
		return(HELP_TOOL);

	if( !strcmp(menu_str, "{List_Users}") )
		return(LIST_USER);

	if( !strcmp(menu_str, "{PalBBS}") )
		return(PALBBS);

	if( !strcmp(menu_str, "{Previous_Mail}") )
		return(PREVIOUS_MAIL);

	if( !strcmp(menu_str, "{Ping}") )
		return(PING);

	if( !strcmp(menu_str, "{Read_Mail}") )
		return(READ_MAIL);

	if( !strcmp(menu_str, "{Register}") )
		return(REGISTER);

	if( !strcmp(menu_str, "{Search_Mail}") )
		return(SEARCH_MAIL);

	if( !strcmp(menu_str, "{Version_Info}") )
		return(VERSION_INFO);

	if( !strcmp(menu_str, "{Welcome}") )
		return(WELCOME);


	if( !strcmp(menu_str, "{File_Area}") )
		return(FILE_AREA);

	if( !strcmp(menu_str, "{Search_File}") )
		return(SEARCH_FILE);

	if( !strcmp(menu_str, "{Toggle_File}") )
		return(TOGGLE_FILE);

	if( !strcmp(menu_str, "{List_File}") )
		return(LIST_FILE);

	if( !strcmp(menu_str, "{Download_File}") )
		return(DOWNLOAD_FILE);

	if( !strcmp(menu_str, "{Upload_File}") )
		return(UPLOAD_FILE);

	if( !strcmp(menu_str, "{Help_File}") )
		return(HELP_FILE);

	if( !strcmp(menu_str, "{Reset_Toggle}") )
		return(RESET_TOGGLE);

	if( !strcmp(menu_str, "{Kill_Mail}") )
		return(KILL_MAIL);

	if( !strcmp(menu_str, "{Inter_Read}") )
		return(INTER_READ);

	if( !strcmp(menu_str, "{File_Post}") )
		return(FILE_POST);

	if( !strcmp(menu_str, "{Switch_Page}") )
		return(SWITCH_PAGE);

	if( !strcmp(menu_str, "{Write_User}") )
		return(WRITE_USER);

	if( !strcmp(menu_str, "{Chat_Room}") )
		return(CHAT_ROOM);

	if( !strcmp(menu_str, "{Quick_Join}") )
		return(QUICK_JOIN);

	return(UNIMPLEMENT);
}
/*end of parse_menu*/
