/*************************************************************************
 * select.c --- interactive mail group select				 *
 *	        by Samson Chen, July 9, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"
#include "dbf.h"

static char rcsid[]="$Id: select.c,v 1.7 1994/07/20 04:45:54 pbbs Exp pbbs $";

#define	IBUF_SIZE	10240


struct group_struc {
	char	path[40];
	char	describe[50];
	char	new_post;
	int	post_level;
	int	gid;
	struct	group_struc *next;
	struct	group_struc *previous;
	};

static char	group_fetched=FALSE;	/*local flag for grouplist fetch*/
static struct	group_struc *lgroups;	/*groups link*/
static int	group_items=0;


/*
	change_area --- interactive mail area selecting
*/
change_area(fd)
	int fd;
{
	char	inter_buf[IBUF_SIZE];
	char	*ibuf_head;
	char	line[255];
	char	txtbuf[80];
	char	answer[80];
	char	crlf[3];
	struct	group_struc *gp;
	int	scr_size;	/*client's screen size*/
	int	scrcnt;
	int	rlen;
	int	ret;
	char	protocol;
	char	leave;
	char	forward_dir;
	int	sgid;
	int	n;

	/*if first use this function, fetch all accepatable groups*/
	if( !group_fetched )
	{
		fetch_group(fd);

		/*fetching failed, skip selecting*/
		if( !group_fetched )
			return;
	}

	/*get client's screen size*/
	send_mpf(fd, NULL, 0, SCRSIZE);
	read_mpf(fd, answer, &rlen, &protocol, FALSE);
	if( protocol != SCRSIZE )
	{
		do_log(8, "%s protocol_stat_err with protocol code %d at change_area", user_name, protocol);
		protocol_stat_err(fd);
	}

	sprintf(crlf, "%c%c", 13, 10);
	answer[rlen]=0;
	strip_nl(answer);
	scr_size=atoi(answer);
	scr_size--;			/*adjust output lines*/
	if(scr_size<1) scr_size=5;	/*no screen size???*/
	forward_dir=TRUE;		/*assume forward reading*/

	if(debug_mode) printf("(select.c)get screen size %d\n", scr_size);

	/*groups items is less than screen size*/
	if( group_items<scr_size ) scr_size=group_items;

	/*------------------------------------------------------------*/

	leave=FALSE;
	do
	{

	  scrcnt=0;
	  inter_buf[0]=0;
	  gp=lgroups;

          if( forward_dir )
          {
                ibuf_head=inter_buf;
          }     
          else  
          {     
                ibuf_head=inter_buf + (IBUF_SIZE-1);
                *ibuf_head=0;
          }     

	  display_msg(fd, WAIT_PLEASE);

	  /*---------------------*/
	  /*assemble groups items*/
	  /*---------------------*/
	  do
	  {

	    /*assemble single item*/
	    line[0]=0;
	    sprintf(txtbuf, "%d", gp->gid);
	    strcat(line, txtbuf);
	    strcat(line, crlf);
	    strcat(line, gp->describe);
	    strcat(line, crlf);

	    /*test if new post in*/
	    if( gp->new_post==' ' )	/*untested*/
	    {
		if( test_new_post(gp->path) )
			gp->new_post='Y';
		else
			gp->new_post='N';
	    }

	    /*-------------------------------------*/

	    if( gp->new_post=='Y' )
		strcat(line, NEW_POST_MARK);
	    else
		strcat(line, NO_NEW_POST_MARK);

	    strcat(line, gp->path);
	    strcat(line, crlf);

            if( forward_dir )
            {       
                strcat( ibuf_head, line );
            }       
            else    
            {       
                ret=strlen(line);
                ibuf_head -= ret;

                for(ret=0; ret<strlen(line); ret++)
			ibuf_head[ret]=line[ret];
            }
                
            /* add counter and move pointer*/

	    scrcnt++;

	    if( forward_dir )
		gp=gp->next;
	    else
		gp=gp->previous;

	  }while(scrcnt<scr_size);

	  /*----------------------------------------------------*/
	  /*send reqest*/

          send_mpf(fd, ibuf_head, strlen(ibuf_head), INTRREAD);
          read_mpf(fd, answer, &rlen, &protocol, FALSE);
          if( protocol != INTRREAD )
          {

                do_log(8, "%s protocol_stat_err with protocol code %d at change_area", user_name, protocol); 
                protocol_stat_err(fd);
          }     
          
          answer[rlen]=0;
          strip_nl(answer);
          
          /*---------------------------------------*/

          if(answer[0]=='q' || answer[0]=='Q')
          {     
                /*quit interactive selecting*/
                leave=TRUE;
                continue;
          }

          if(answer[0]=='u' || answer[0]=='U')
          {
                if(debug_mode) printf("(select.c)PageUp\n");
                
                if( forward_dir )
			lgroups=lgroups->previous;
		else
			lgroups=gp;
                
                forward_dir=FALSE;
                
                continue;
          }

          if(answer[0]=='d' || answer[0]=='D')
          {
                if(debug_mode) printf("(select.c)PageDown\n");
                
                /*PageDown*/
                if( forward_dir )
			lgroups=gp;
		else
			lgroups=lgroups->next;
                
                forward_dir=TRUE;
                
                continue;
	  }

	  /*----------------------------------------------------------*/

	  sgid=atoi(answer);
	  if( sgid>0 )
	  {
		gp=lgroups;

		for(n=0; n<group_items; n++, gp=gp->next)
		{
		  if( gp->gid == sgid )
		  {
			if( select_mail_area(fd, gp->path) )
			{
			  mini_post_level=gp->post_level;
			  if( user_level < mini_post_level )
			  {
				sprintf(line, "%s%d\n", MINIMUM_POST_LEVEL, mini_post_level);
				display_msg(fd, line);
			  }

			  gp->new_post='N';
			  lgroups=gp;
			  forward_dir=TRUE;
			  suspend(fd);

			  inter_read(fd);
			}
			else
				suspend(fd);

			break;

		  }/*end if*/
		}/*end for*/

	  }/*end if(sgid)*/

	}while(!leave);

}
/*end of change_area*/



/*
	quick_join --- user input for quick area join
*/
quick_join(fd)
{
	char	leave;
	char	line[100];
	char	answer[80];
	struct	group_struc *gp;
	int	n;

	/*if first use this function, fetch all accepatable groups*/
	if( !group_fetched )
	{
		fetch_group(fd);

		/*fetching failed, skip selecting*/
		if( !group_fetched )
			return;
	}

	leave=FALSE;

	do
	{

	  sprintf(line, "%s%s, %s", CURRENT_POSTGROUP, current_group, ASK_MAIL_GROUP);
	  asking(fd, line, answer, 40);

	  if( answer[0]==0 || answer[0]==13 || answer[0]==10 )
		return;	/*user press enter directly*/

	  gp=lgroups;

	  /*parse 1 --- find exactly identical group*/
	  for(n=0; n<group_items; n++, gp=gp->next)
	  {
		if( !strcmp(gp->path, answer) )
		{
		  if( select_mail_area(fd, gp->path) )
		  {
			leave=TRUE;
			lgroups=gp;
		  }
		  gp->new_post='N';
		  suspend(fd);
		  break;
		}
	  }/*end for*/

	  if( leave )
		continue;

	  /*parse 2 --- find partially like group*/

	  gp=lgroups->next;

	  for(n=0; n<group_items; n++, gp=gp->next)
	  {
		if( !strncmp(gp->path, answer, strlen(answer)) )
		{
		  if( select_mail_area(fd, gp->path) )
		  {
			leave=TRUE;
			lgroups=gp;
		  }
		  gp->new_post='N';
		  suspend(fd);
		  break;
		}
	  }/*end for*/

	  if( leave )
		continue;

	  display_msg(fd, NO_SUCH_GROUP);

	}while(!leave);

}
/*end of quick_join*/



/*
	fetch_group --- fetch group list to memory
*/
fetch_group(fd)
	int fd;
{
	char	list_filename[255];
	struct	group_struc *group_head, *group_point, *new_space, *plink;
	FILE	*listfile;
	char	line[255];
	char	test_path[255];
	char	mpath[40];
	char	mdescribe[50];
	int	mjoin;
	int	mpost;
	char	mbuf[10];
	char	*p;
	int	ret;
	int	items;
	int	n;
	char	*error_entry="<ERROR>";

	if(debug_mode) printf("(select.c)fetch mail groups\n");

	sprintf(list_filename, "%s/%s", MAIL_PATH, GROUP_LIST);
	if( !file_exist(list_filename) )	/*no group list file*/
	{
		display_msg(fd, NO_GROUP_LIST);
		suspend(fd);
		return;
	}

	group_head=group_point=lgroups=(struct group_struc *)NULL;
	items=0;

	/*--------------------------------------*/

	listfile=fopen(list_filename, "r");

	display_msg(fd, WAIT_PLEASE);

	while( fgets(line, 127, listfile) )
	{

	  /*take off comments*/
	  for(n=0; n<strlen(line); n++)
		if( line[n]=='#' )
		{
			line[n]=0;
			break;
		}

	  ret=strlen(line);
	  if( ret<8 )
		continue;

	  if(ret<126)
	  {
		/*to avoid a possoble bug of next_blank*/
		line[ret+1]=0;
		line[ret+2]=0;
	  }

	  /*--------------------------------------------------*/

	  /*--- get area path ---*/
	  p=line;
	  ret=next_params(p);
	  p+=ret;
	  ret=next_tab_space(p);
	  if( ret==0 ) continue;
	  p[ret]=0;
	  nstrcpy(mpath, p, 40);

	  p+=ret+1;
	  ret=next_params(p);
	  p+=ret;
	  ret=next_tab_space(p);
	  if( ret==0 ) continue;

	  /*--- get join security ---*/
	  p[ret]=0;
	  nstrcpy(mbuf, p, 10);
	  mjoin=atoi(mbuf);

	  if( !system_operator && (user_level<mjoin) ) continue; /*join secu*/

	  p+=ret+1;
	  ret=next_params(p);
	  p+=ret;
	  ret=next_tab_space(p);
	  if( ret==0 ) continue;

	  /*--- get post security ---*/
	  p[ret]=0;
	  nstrcpy(mbuf, p, 10);
	  mpost=atoi(mbuf);

	  p+=ret+1;
	  ret=next_params(p);
	  p+=ret;

	  /*--- get area description */
	  strip_nl(p);
	  nstrcpy(mdescribe, p, 50);

	  if(debug_mode) printf("(select.c)get %s %d %d %s\n", mpath, mjoin, mpost, mdescribe);

	  /*++++++++++++++++++++++++++++++*/
	  /*+++ add to group link list +++*/
	  /*++++++++++++++++++++++++++++++*/
	  new_space=(struct group_struc *)malloc(sizeof(struct group_struc));

	  if( group_head==(struct group_struc *)NULL )
	  {
		group_head=group_point=new_space;
	  }
	  else
	  {
		group_point->next=new_space;
		plink=group_point;
		group_point=new_space;
		group_point->previous=plink;
	  }

	  sprintf(test_path, "%s/%s", MAIL_PATH, mpath);

	  if( path_exist(test_path) )
	  {
	    nstrcpy(group_point->describe, mdescribe, 50);
	    group_point->new_post=' ';
	  }
	  else
	  {
	    nstrcpy(group_point->describe, error_entry, 50);
	    group_point->new_post='N';
	  }

	  nstrcpy(group_point->path, mpath, 40);
	  group_point->post_level=mpost;
	  group_point->gid=++items;
	  group_point->next=(struct group_struc *)NULL;

	}/*end while(fgets)*/

	group_point->next=group_head;	/*circular link*/
	group_head->previous=group_point;
	lgroups=group_head;
	group_items=items;

	group_fetched=TRUE;

}
/*end of fetch_group*/



/*
	test_new_post --- quick test if new post in
*/
test_new_post(gpath)
	char *gpath;
/*
	return:
		TRUE: new post in
		FALSE: np new post
*/
{
	char	rec_file[255];
	char	usr_file[255];
	int	total_msg;
	int	usr_rec;
	int	user_lr;
	int	lastread;

	if( !strcmp(gpath, "mbox") )
	{
		sprintf(rec_file, "%s/mbox/%d.records", MAIL_PATH, user_uid);
		sprintf(usr_file, "%s/mbox/users", MAIL_PATH);
	}
	else
	{
		sprintf(rec_file, "%s/%s/records", MAIL_PATH, gpath);
		sprintf(usr_file, "%s/%s/users", MAIL_PATH, gpath);
	}


	total_msg=flength(rec_file)/sizeof(struct msgrec);
	usr_rec=flength(usr_file)/sizeof(int);

	if( usr_rec < user_uid+1 )
		return(FALSE);		/*user never join this area*/

	user_lr=open(usr_file, O_RDONLY);
	lseek(user_lr, user_uid*sizeof(int), SEEK_SET);
	read(user_lr, &lastread, sizeof(int) );
	close(user_lr);

	if( total_msg>lastread )
		return(TRUE);
	else
		return(FALSE);

}
/*end of test_new_post*/
