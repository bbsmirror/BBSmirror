/*************************************************************************
 * login.c --- about user login						 *
 *	       by Samson Chen, Mar 16, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "global.h"
#include "dbf.h"
#include "message.h"

/*
	login --- user login procedure
*/
login(fd)
	int fd;
/*
	return: none
	note: if login fail, routine will not return,
	      if login succeed, user data will be stored in global vars
		user_uid, user_name, user_level
*/
{
	int uid;
	char rname[21];

	uid=get_user_name(fd, rname);

	if( uid<0 )		/*login failure*/
	{
		do_log(2, "%s used name %s login failure", client_site, rname);
		reject(fd, 7);
	}
	else if( uid==0 )	/*new user*/
		add_new_user(fd, rname);
	else			/*existed user*/
		sign_in(fd, uid);
}
/*end of login*/



/*
	add_new_user --- creat a new user
*/
add_new_user(fd, name)
	int fd;
	char *name;	/*user name*/
/*
	return: none
*/
{
	struct udb userdata;
	char buf[80];
	char answer[3];
	int uid;

	do_log(5, "%s from %s request as a new user", name, client_site);

	nstrcpy(userdata.bbs_name, name, 20);

	display_msg(fd, DETAIL_PLEASE);
	display_msg(fd, SECRET_PDATA);

	reg_ask(fd, YOUR_REAL_NAME, userdata.real_name, 20);
	reg_ask(fd, YOUR_EMAIL_ADD, userdata.email, 40);

	/*
	reg_ask(fd, YOUR_TERM, userdata.term, 8);
	*/
	nstrcpy(userdata.term, "SKIP", 8);	/*skip this data now*/

	reg_ask(fd, YOUR_ADDRESS, userdata.address, 60);
	reg_ask(fd, YOUR_PHONE, userdata.phone, 20);
	reg_ask(fd, YOUR_SEX, buf, 2);
		userdata.sex=buf[0];
	reg_ask(fd, YOUR_INTEREST, userdata.interest, 21);
	reg_ask(fd, YOUR_SPEC, userdata.spec, 41);

	userdata.delete_mark=' ';
	userdata.mailbox=' ';
	userdata.level=INIT_LEVEL;
	userdata.total_post=0;
	userdata.total_login=1;
	userdata.total_upload=0;
	userdata.total_download=0;
	userdata.user_set[0]=0;
	rfctime(userdata.first_login);
	rfctime(userdata.last_login);

	/*re-confirm user for registering*/
	asking(fd, REGISTER_CONFIRM, answer, 2);
	if( answer[0]!='y' && answer[0]!='Y' )
	{
		do_log(2, "%s from %s give up register", name, client_site);
		reject(fd, 7);
	}

	get_new_passwd(fd, userdata.password);

	uid=add_user_record(&userdata);

	/*set enviroment*/
	user_uid=uid;
	user_level=INIT_LEVEL;
	strcpy(user_name, name);
	strcpy(user_email, userdata.email);

	do_log(3, "%s as a new users uid=%d", user_name, user_uid);

	/*display message for new users*/
	sprintf(buf, "%s/%s", MENU_PATH, NEWUSER_FILE);
	if( file_exist(buf) )
	{
		send_file_display(fd, buf);
		suspend(fd);
	}

	check_putmp(fd);
}
/*end of add_new_user*/
	


/*
	sign_in --- user sign system in
*/
sign_in(fd, uid)
	int fd;
	int uid;	/*user id*/
{
        char udbfile[255];
        int udbf;
        int rec;
        int n;
        struct udb record;
	struct system_rec sysrec;
	char user_passwd[14];
	char buf[255];
	int blen;
	char protocol;
	int try=0;
	char passwd_ok=FALSE;

        sprintf(udbfile, "%s.dbf", USER_DATA_BASE);
        udbf = open(udbfile, O_RDONLY);

	lseek( udbf, uid*sizeof(struct udb), SEEK_SET);

	read(udbf, &record, sizeof(struct udb));
	if( debug_mode ) printf("(login.c)get user %s\n", record.bbs_name);
	close(udbf);

	if(record.delete_mark=='*' || record.delete_mark=='X')
	{
		do_log(5, "user from %s user disabled id %s", client_site, record.bbs_name);
		display_msg(fd, ACCOUNT_DISABLED);
		reject(fd, 7);
	}

	if( !strcmp(record.password, "MagicPower") )	/*magic password used*/
	{
		user_uid=uid;
		user_level=record.level;
		strcpy(user_name, record.bbs_name);
		strcpy(user_email, record.email);

		display_msg(fd, MAGIC_PASSWD);

		if( !chn_passwd(fd, TRUE) )
			reject(fd, 7);

		do_log(3, "%s login succeed under magic password from %s", user_name, client_site);
		check_putmp(fd);
		return;
	}

	do
	{
		try++;

                strcpy(buf, PASSWD_PLZ);
                send_mpf(fd, buf, strlen(buf), PASSWD);
                read_mpf(fd, buf, &blen, &protocol, FALSE);
                buf[blen]='\0';
                if( protocol != PASSWD )
		{
			do_log(8, "%s protocol_stat_err with protocol code %d at sign_in", client_site, protocol);
			protocol_stat_err(fd);
		}

                if( strcmp(record.password, crypt(buf, SALT) ) )
		{
			strcpy(buf, PASSWD_WRONG);
                        send_mpf(fd, buf, strlen(buf), DISPLAY);

                        if( try >= MAX_LOGIN )  /*too many tries*/
                        {
                                do_log(5, "%s password failed", record.bbs_name);
				reject(fd, 7);
                        }
		}
		else
		{
			user_uid=uid;
			user_level=record.level;
			strcpy(user_name, record.bbs_name);
			strcpy(user_email, record.email);
			do_log(3, "%s login succeed from %s", user_name, client_site);
			passwd_ok=TRUE;
		}

	} while( !passwd_ok);

	get_user_data(&record, user_uid);
	record.total_login++;
	rfctime(record.last_login);
	set_user_data(&record, user_uid);

	check_putmp(fd);
}
/*end of sign_in*/
