/*************************************************************************
 * readpost.c --- read posts						 *
 *	      by Samson Chen, Apr 2, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"
#include "dbf.h"

static char rcsid[]="$Id: readpost.c,v 1.10 1994/08/09 13:58:40 pbbs Exp pbbs $";

char bigbuf[MAX_BUF];
char line_buf[255];



/*
	readpost --- reading posts
*/
read_mail(fd, read_dir, readfrom)
	int fd;
	int read_dir;	/*read direction*/
	int readfrom;	/*for inter-read, -1 mean use lastread*/
{
	char filename[256];
	char ebuf[256];
	int mffd;
	int mfrec;
	int rec;
	struct msgrec mrec;
	char *p, *reload_point;
	int total_msg=0;
	int recno=0;
	int ret;
	int rlen;
	char protocol;
	char answer[80];
	char crlf[3];
	int fp;
	char *msgtxt;
	char *from_field, *subject_field;
	char *date_field;
	char from_line[80], from_name[80];
	int cpn, slen;
	char *ptr;
	char search_topic;	/*topic searching flag*/
	char searched_topic[80];
	char be_search[80];
	int s_pos;
	char search_match;
	int last_stop=-1;  /*used for topic search when search not found*/


	if(debug_mode) printf("(readpost.c)read_mail\n");

	update_act(6, group_areaname);

	/*------------------------------------------------------------*/
	if( strcmp(current_group, "mbox") )
	  sprintf(filename, "%s/%s/messages", MAIL_PATH, current_group);
	else
	  sprintf(filename, "%s/mbox/%d.messages", MAIL_PATH, user_uid);

	mffd=open(filename, O_RDONLY|O_CREAT, S_IWUSR | S_IRUSR);
	/*------------------------------------------------------------*/

	/*------------------------------------------------------------*/
	if( strcmp(current_group, "mbox") )
	  sprintf(filename, "%s/%s/records", MAIL_PATH, current_group);
	else
	  sprintf(filename, "%s/mbox/%d.records", MAIL_PATH, user_uid);
	
	mfrec=open(filename, O_RDONLY|O_CREAT, S_IWUSR | S_IRUSR);
	/*------------------------------------------------------------*/

	if( mffd<0 || mfrec<0 )
	{
		sprintf(ebuf, "readpost.c: %s", SYSTEM_ERROR);
		send_mpf(fd, ebuf, strlen(ebuf), REJECT);
		exit(12);
	}

	if( readfrom<0 )
		recno=get_lastread(fd);
	else
		recno=readfrom;

	search_topic=FALSE;
	while(1)
	{
		lseek(mfrec, 0 ,SEEK_END);
		total_msg=file_length(mfrec)/sizeof(struct msgrec);

		if( recno >= total_msg )
		{
			if( last_stop>=0 && last_stop<total_msg )
			{
				/*user searching finished*/
				recno=last_stop;
				last_stop=-1;
				search_topic=FALSE;
				continue;
			}
				
			display_msg(fd, NO_NEW_MSG);
			set_lastread(fd, total_msg);
			suspend(fd);
			break;
		}

		if( recno<0 )
		{
			if( last_stop>=0 && last_stop<total_msg )
			{
				/*user searching finished*/
				recno=last_stop;
				last_stop=-1;
				search_topic=FALSE;
				continue;
			}

			display_msg(fd, MSG_NO_ERR);
			set_lastread(fd, 0);
			suspend(fd);
			break;
		}

		/*----------------------------------------------------*/

		lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
		read(mfrec, &mrec, sizeof(struct msgrec) );

		/*----------------------------------------------------*/

		/*check delete mark*/
		if( mrec.delete_mark=='D' )
		{
			if( read_dir>=0 )
				recno++;
			else
				recno--;
			continue;
		}

		/*----------------------------------------------------*/

		recno++;
		p=bigbuf;

		sprintf(p, "Area: %s%c%c", group_areaname, 13, 10);
		ret=strlen(p);
		p+=ret;

		sprintf(p, "Total: %d%c%c", total_msg, 13, 10);
		ret=strlen(p);
		p+=ret;

		sprintf(p, "Msgno: %d%c%c", recno, 13, 10);
		ret=strlen(p);
		p+=ret;

		lseek(mffd, mrec.offset, SEEK_SET);
		if( !search_topic )
		{
			ret=read(mffd, p, mrec.length);
		}
		else
		{
			reload_point=p;

			/*load only head for comparing*/

			if( mrec.length<MAX_HEAD )
				ret=read(mffd, p, mrec.length);
			else
				ret=read(mffd, p, MAX_HEAD);
		}

		p[ret]=0;

		/*----------------------------------------------------*/

		/*skip cmsg cancel message*/
		fp=parse_msg(fd, bigbuf, "Subject: ");
		fp+=9;	/*skip "Subject: "*/
		subject_field=bigbuf+fp;

		if( !strncmp(subject_field, "cmsg cancel", 11) )
		{
			if( read_dir<0 )
				recno-=2;

			continue;
		}

		/*----------------------------------------------------*/

		if(search_topic)
		{
			fp=parse_msg(fd, bigbuf, "Subject: ");
			fp+=9;	/*skip "Subject: "*/
			subject_field=bigbuf+fp;

			for(s_pos=fp; s_pos<(fp+79); s_pos++)
				if( bigbuf[s_pos]==13 || bigbuf[s_pos]==10 |bigbuf[s_pos]==0 )
					break;

			strncpy(be_search, subject_field, s_pos-fp);
			be_search[s_pos-fp]=0;

			if(debug_mode) printf("(readpost.c)compare %d: '%s' with '%s'\n", recno-1, searched_topic, be_search);

			search_match=FALSE;

			if( strncmp(be_search, "Re: ", 4) )
			{
				if( !strcmp(be_search, searched_topic) )
					search_match=TRUE;
			}
			else
			{
				if( !strcmp(be_search+4, searched_topic) )
					search_match=TRUE;
			}

			if( !search_match )
			{
				if( read_dir<0 )
					recno -= 2;

				continue;
			}

			search_topic=FALSE;
			last_stop=-1;

			/*search found --- reload whole mail*/
			lseek(mffd, mrec.offset, SEEK_SET);
			ret=read(mffd, reload_point, mrec.length);
			reload_point[ret]=0;
		}
		/*----------------------------------------------------*/

		/*convert GMT to local time*/

		fp=parse_msg(fd, bigbuf, "Date: ");
		fp+=6;	/*skip "Date: "*/
		date_field=bigbuf+fp;
		gmtlocal(date_field);

		/*----------------------------------------------------*/

		if(debug_mode) printf("(readpost.c)send %dth post\n", recno);
		send_mpf(fd, bigbuf, strlen(bigbuf), POST);

		set_lastread(fd, recno);

		read_mpf(fd, answer, &rlen, &protocol, FALSE);
		answer[rlen]=0;
		if( protocol != GETPOST )
		{
			do_log(8, "%s protocol_stat_err with protocol code %d at read_mail", user_name, protocol);
			protocol_stat_err(fd);
		}

		/*----------------------------------------------------*/

		if( answer[0]=='q' || answer[0]=='Q' )
			break;

		/*----------------------------------------------------*/

		if( answer[0]=='k' || answer[0]=='K' )
		{
			display_msg(fd, "\n");
			delete_message(fd, recno-1);
			display_msg(fd, "\n");
			
			if( read_dir<=0 )
				recno-=2;
	
			continue;
		}

		/*----------------------------------------------------*/

		if( answer[0]=='e' || answer[0]=='E' )
		{
			enter_mail(fd, 0, NULL, NULL, NULL);
			recno--;	/*stay at the same position*/
			continue;
		}

		/*----------------------------------------------------*/

		if( answer[0]=='r' || answer[0]=='R' )
		{
			sprintf(crlf, "%c%c", 13, 10);

			fp=parse_msg(fd, bigbuf, "MSG");
			msgtxt=bigbuf+fp+2;

			fp=parse_msg(fd, bigbuf, "Subject: ");
			subject_field=bigbuf+fp;
			strip_nl(subject_field);
			subject_field+=9;

			fp=parse_msg(fd, bigbuf, "From: ");
			from_field=bigbuf+fp;
			strip_nl(from_field);
			from_field+=6;

			nstrcpy(from_line, from_field, 80);
			ptr=strtok(from_line, "(<[");

			if( ptr !=NULL )
			{
				ptr=strtok(NULL, ")>]");
				if( ptr!=NULL )
					nstrcpy(from_name, ptr, 80);
				else
					nstrcpy(from_name, from_field, 80);
			}
			else
				nstrcpy(from_name, from_field, 80);

			strip_nl(from_name);

			if(debug_mode) printf("(readpost.c)enter mail reply mode\n");

			enter_mail(fd, 1, from_name, subject_field, msgtxt);

			recno--;	/*stay at the same position*/
			continue;

		}/*end if(r)*/

		/*----------------------------------------------------*/

		if( answer[0]=='+' || answer[0]=='-' )
		{
			sprintf(crlf, "%c%c", 13, 10);

			fp=parse_msg(fd, bigbuf, "Subject: ");
			subject_field=bigbuf+fp+9;
			strip_nl(subject_field);

			if( strncmp(subject_field, "Re: ", 4) )
			{
				nstrcpy(searched_topic, subject_field, 80);
			}
			else
			{
				nstrcpy(searched_topic, subject_field+4, 80);
			}

			/*-----------------------------------------------*/
			search_topic=TRUE;
			last_stop=recno-1;
			/*-----------------------------------------------*/

			if( answer[0]=='+' )
				read_dir = 1;
			else
			{
				read_dir = -1;
				recno -= 2;
			}


			if(debug_mode) printf("(readpost.c)search topic->%s\n", searched_topic);
			display_msg(fd, WAIT_PLEASE);
			continue;
		}

		/*----------------------------------------------------*/

		ret=atoi(answer);
		if( ret<=0 || ret>(total_msg+1) )
		{
			display_msg(fd, MSG_NO_ERR);
			suspend(fd);
			break;
		}

		if( ret>0 )
		{
			if(debug_mode) printf("(readpost.c)request %dth post\n", recno);

			if(ret>=recno)
				read_dir=1;
			else
				read_dir=-1;

			recno=ret-1;
		}
	}/*end while*/

	/******************************************************/
	/*make last_read more correct if last post was deleted*/
	/*----------------------------------------------------*/
	total_msg=file_length(mfrec)/sizeof(struct msgrec);
	recno=get_lastread(fd);
	while( recno<total_msg )
	{
		lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
		read(mfrec, &mrec, sizeof(struct msgrec) );
		if( mrec.delete_mark=='D' )
		{
			recno++;
			set_lastread(fd, recno);
			continue;
		}
		else
			break;
	}
	/******************************************************/

	close(mfrec);
	close(mffd);
}



/*
	read_previous_mail --- as the name
*/
read_previous_mail(fd)
{
	int lr;

	if(debug_mode) printf("(readpost.c)read_previous_mail\n");

	lr=get_lastread(fd);

	lr--;

	if( lr<0 ) lr=0;

	set_lastread(fd, lr);

	read_mail(fd, -1, -1);
}
/*end of read_previous_mail*/
