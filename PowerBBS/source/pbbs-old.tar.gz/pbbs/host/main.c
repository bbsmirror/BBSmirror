/* Server */
/*
PowerBBS Server Daemon by Samson Chen, Team Square-1991., V1.1 July 15, 1994
*/
/*************************************************************************** 
 * Filename: main.c							   *
 * Server program for PBBS protocol					   *
 *	by Samson Chen, Nov 27, 1993					   *
 ***************************************************************************/

/*
	arguments:
		-d : debug mode, do not push process as daemon process

	exit code :
		0  = initial daemon OK
		1  = session1_err
		2  = session2_err
		3  = session3_err
		5  = service_unknown
		6  = client disconnect abnormally
		7  = login failure
		8  = protocol stat error
		10 = err routine
		12 = system error
		20 = dup_login
		21 = bad user reject
		30 = daemon initializing error
		40 = system load too heavy
*/

#include "pbbs.h"

static char rcsid[]="$Id: main.c,v 1.14 1994/07/28 18:53:07 pbbs Exp pbbs $";



/*
	some global variables used in most modules
*/
char	debug_mode;		/*TRUE for debug mode*/
char 	client_site[30];	/*store readable client address*/
int	on_line_users;		/*numbers of on-line users*/
unsigned int idling;		/*for alarm*/
unsigned char platform;		/*client's platform*/
int	putmp_rec;		/*record # of putmp of current user*/
unsigned int user_uid;		/*user database id number*/
char	user_name[20];		/*user id name*/
char	user_email[40];		/*user email address*/
unsigned int user_level;	/*user security level*/
unsigned int total_regs;	/*total registered people*/
unsigned long total_login;	/*total login*/
char	current_group[30];	/*current posting group*/
char	group_areaname[30];	/*current group name description*/
unsigned int mini_post_level;	/*minimum posting level of current_group*/
char	group_moderator;	/*group moderator flag of current group*/
char	system_operator;	/*sysop lewvel flag*/
char	file_area[30];		/*current file area*/
int	toggles;		/*total toggles*/
char	tagged[MAX_ALLOW_TAG][120];	/*tagged files*/
char	bstack[256];		/*bulletin heirachy control*/


/*
	main start here
*/
main(argc, argv)
int 	argc;
char 	*argv[];
{
	int	sockfd, newsockfd, clilen;
	struct 	sockaddr_in cli_addr;
	int	daemon_pid;
	int	tempffd;

#ifndef	SYSV
	extern	int reaper();	/*for reapping child process*/
#endif
	extern	int timeup();	/*idle handling function*/
	extern	int paging();	/*someone want to send a messages*/

	if( !path_exist(SYSTEM_PATH) )
	{
		printf("\nSYSTEM_PATH '%s' not found!\n", SYSTEM_PATH);
		exit(30);
	}

	chdir(SYSTEM_PATH);

	if( !check_required_path() )
	{
		printf("\n");
		exit(30);
	}

	if( argc>1 )
		if( !strcmp(argv[1], "-d") ) debug_mode=TRUE;


	if( debug_mode )
		printf("\n Process is in debugging mode now...\n");
	else
	{
	  /*initial daemon*/
	  if( (daemon_pid=fork()) < 0 )
	  {
		  printf("initialize daemon error!\n");
		  exit(30);
	  }
	  if( daemon_pid > 0 )	/*parent goes bye-bye*/
	  {
		  sleep(1);
		  exit(0);
	  }
	  else			/*set daemon requirements up*/
	  {
		  setsid();
	  }
	} /*end of debug_mode*/
	/****************************************************/

	/*************/
	/*pid locking*/
	/*************/
	if( !lock_pid() )
	{
		printf(" pid locking error, maybe process has been run before!\n");
		do_log(9, "pid locking error, maybe process has been run before!");
		exit(2);
	}
	/*******************************************/

	/*start log*/
	do_log(9, "PowerBBS Server Initialize at port %d", PBBS_SERV_PORT);

	on_line_users=0;	/*initial on-line users*/

	/*another initials*/
	idling=IDLE_TIME;
	mini_post_level=0;
	group_moderator=FALSE;
	system_operator=FALSE;
	user_name[0]=0;
	user_uid=0;
	toggles=0;
	strcpy(bstack, ".");

	strcpy(group_areaname, "main");
	strcpy(file_area, INIT_FILE_AREA);

	chk_user_database();

	/* allocate socket file descriptor */
	sockfd = getsockfd();

	/*change process runnung user id and group*/
	change_run_id();

	/*************/
	/*set signals*/
	/*************/
	/*set signal for disconnected child*/
#ifndef	SYSV
	(void) signal(SIGCHLD, (void*)reaper);
#endif
#ifdef	SYSV
	/*Just make SIGCHLD ignoed on System V*/
	(void) signal(SIGCHLD, SIG_IGN);
#endif


	/* listenning */
	if( listen(sockfd, SOMAXCONN)<0 )
		err("main:listenning error?");
		/* Listen for client */

	/* big-loop for taking services */
	for( ; ; )
	{
		clilen = sizeof(cli_addr);
		newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);

		if (newsockfd < 0)
		{
			if( errno != EINTR ) do_log(7, "accept EINTR error");
			continue;
		}


#ifdef	SYSV
		get_on_line_users_by_putmp();
#endif


		/* starting fork processing */
		switch( fork() )
		{
		case -1: /*error*/
			do_log(7, "fork error");
			(void) close(newsockfd);
			break;

		case 0:	/*child*/

			/***********************/
			/*set signals for child*/
			/***********************/
			(void) signal(SIGALRM, (void*)timeup);
			(void) signal(SIGUSR1, (void*)paging);

#ifndef	SYSV
/*System V use putmp to count users, so that re-init it may cause error*/
			/**********************************************/
			/*re-initial putmp file if only one login user*/
			if( on_line_users<=0 )
			{
			  tempffd=open(ON_LINE_USER, O_CREAT | O_TRUNC, S_IWUSR | S_IRUSR);
			  close(tempffd);
			}
			/**********************************************/
#endif

			putmp_rec=-1;	/*no putmp slot for user before login*/
			on_line_users++;
			(void) close(sockfd);
			strcpy(client_site, inet_ntoa(cli_addr.sin_addr) );
			do_log(5, "Connected with %s", client_site);
			serve(newsockfd);
				/*do service without return*/
			break;
		
		default: /*parent*/
			on_line_users++;
			(void) close(newsockfd);
			break;
		} /*end of switch*/
	} /*end of for;;*/
}
/*end of main*/
