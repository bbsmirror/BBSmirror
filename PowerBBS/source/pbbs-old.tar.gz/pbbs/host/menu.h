
/* MENU code for PBBS Server */

#define UNIMPLEMENT	0
#define	MAIN_MENU	1
#define	MAIL_MENU	2
#define	TOOL_MENU	3
#define FILE_MENU	4
#define	DOOR_MENU	5

#define	BULLETIN	20
#define	CHANGE_AREA	21
#define	C_PASSWORD	22
#define	ENTER_MAIL	23
#define	U_PERSON_DATA	24
#define	GOODBYE		25
#define	HELP_MAIL	26
#define	HELP_MAIN	27
#define	HELP_TOOL	28
#define	LIST_USER	29
#define	PALBBS		30
#define	PREVIOUS_MAIL	31
#define	PING		32
#define	READ_MAIL	33
#define	REGISTER	34
#define	SEARCH_MAIL	35
#define	VERSION_INFO	36
#define	WELCOME		37
#define	FILE_AREA	38
#define	SEARCH_FILE	39
#define	TOGGLE_FILE	40
#define	LIST_FILE	41
#define	DOWNLOAD_FILE	42
#define	UPLOAD_FILE	43
#define	HELP_FILE	44
#define	RESET_TOGGLE	45
#define	KILL_MAIL	46
#define	INTER_READ	47
#define	FILE_POST	48
#define	SWITCH_PAGE	49
#define	WRITE_USER	50
#define	CHAT_ROOM	51
#define	QUICK_JOIN	52
