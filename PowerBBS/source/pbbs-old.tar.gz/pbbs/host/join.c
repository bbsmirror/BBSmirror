/*************************************************************************
 * join.c --- join a new group						 *
 *	      by Samson Chen, mar 30, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"

static char rcsid[]="$Id: join.c,v 1.11 1994/07/18 02:09:34 pbbs Exp pbbs $";

char bigbuf[MAX_BUF];
char line_buf[255];



/*
	select_mail_area --- change to a seleted mail area
*/
select_mail_area(fd, select_area)
	int fd;
	char *select_area;
/*
	return:
		TRUE: OK
		FALSE: select failed
*/
{
	FILE *area_file;
	int test;
	char temp[256];
	char bfile[255];
	int rlen;
	char protocol;
	int ret;
	int n;
	char gf_name[20];	/*name of group_moderator*/

	if(debug_mode) printf("(join.c)select group %s\n", select_area);


	/*****************************/
	/*check if group exist or not*/
	/*****************************/

	if( strcmp( select_area, "mbox" ) )
	  sprintf(bfile, "%s/%s/messages", MAIL_PATH, select_area);
	else
	  sprintf(bfile, "%s/mbox/%d.messages", MAIL_PATH, user_uid);

	if( !file_exist(bfile) )	/*user selection not found*/
	{
	  test=open( bfile, O_WRONLY | O_APPEND | O_CREAT, S_IWUSR | S_IRUSR);
	  if( test<0 )
	  {
		display_msg(fd, NO_SUCH_GROUP);
		return(FALSE);
	  }
	  else
		close(test);
	}



	/***************************************************/
	/*if group mbox then return, no more checking needs*/
	/***************************************************/
	if( !strcmp(select_area, "mbox") )
	{
		do_log(3, "%s enter mbox", user_name);
		display_msg(fd, ENTER_MBOX);
		strcpy(current_group, "mbox");
		strcpy(group_areaname, MBOX_NAME);
		return(TRUE);
	}



	/*************************************************/
	/*if this user is a group moderator of this group*/
	/*************************************************/
	group_moderator=FALSE;
	gf_name[0]=0;
	if( get_moderator_name(select_area, gf_name) )
	{
		if( !strcmp( user_name, gf_name ) )
		{
			group_moderator=TRUE;
			do_log(1, "set %s as group moderator at %s", user_name, select_area);
		}
	}


	/***************/
	/*group slected*/
	/***************/
	strcpy(current_group, select_area);

	/************************************/
	/*get name description file if exist*/
	/************************************/
	sprintf(bfile, "%s/%s/%s", MAIL_PATH, current_group, AREANAME);
	if( file_exist(bfile) )
	{
		area_file=fopen(bfile, "r");
		fscanf(area_file, "%s\n", group_areaname);
		fclose(area_file);
	}
	else
		strcpy(group_areaname, current_group);
	/************************************/


	do_log(1, "%s change area to %s", user_name, current_group);

	sprintf(temp, "%s%s, %s%d\n", NOW_JOIN, current_group, LASTREAD, get_lastread(fd) );
	display_msg(fd, temp);

	if( gf_name[0]!=0 )
	{
		sprintf(temp, "%s%s\n", GROUP_MODERATOR, gf_name);
		display_msg(fd, temp);
	}

	/*-------------------------------------------------------*/

	/*****************************/
	/*display RULES file if exist*/
	/*****************************/
	sprintf(bfile, "%s/%s/%s", MAIL_PATH, current_group, RULES);
	if( file_exist(bfile) )
	{
		area_file=fopen(bfile, "r");
		bigbuf[0]=0;
		while( fgets(line_buf, 255, area_file) )
		{
			parse_macro(line_buf);
			strcat(bigbuf, line_buf);
		}
		send_mpf(fd, bigbuf, strlen(bigbuf), DISPLAY);
		fclose(area_file);
	}

	return(TRUE);
}
/*end of select_mail_area*/



/*
	chn_file_area --- change file area
*/
chn_file_area(fd)
	int fd;
{
	FILE *area_file;
	int test;
	char temp[80];
	char user_select[80];
	char bfile[255];
	int rlen;
	char protocol;
	int ret;
	int n;
	int file_join_level;
	char part_name[50];

	if(debug_mode) printf("(join.c)send file area menu\n");

	/*send file area list*/
	sprintf(bfile, "%s/%s", FILE_PATH, FILE_AREA_LIST);
	if( !file_exist(bfile) )	/*no file area file*/
	{
		display_msg(fd, NO_FILE_AREA_LIST);
	}
	else	/*send group list*/
	{
		area_file=fopen(bfile, "r");
		bigbuf[0]=0;
		while( fgets(line_buf, 255, area_file) )
		{
			parse_macro(line_buf);
			strcat(bigbuf, line_buf);
		}
		send_mpf(fd, bigbuf, strlen(bigbuf), DISPLAY);
	}

	/*---------------------------------------------------------*/

	while(TRUE)	/*infinite loop untill user reply q*/
	{
		/*initial*/
		file_join_level=0;

		/*ask user*/
		strcpy(temp, ASK_FILE_AREA);
		asking(fd, temp, user_select, 60);

		/*if user press a enter directly (null data) or blanks*/
		if( strlen(user_select) == 0 || user_select[0]==' ')
			return;

		if( !strcmp(user_select, "?") )	/*retrans file area list*/
		{
			/*send file area list*/
			sprintf(bfile, "%s/%s", FILE_PATH, FILE_AREA_LIST);
			if( !file_exist(bfile) )	/*no file area file*/
			{
				strcpy(temp, NO_FILE_AREA_LIST);
				send_mpf(fd, temp, strlen(temp), DISPLAY);
			}
			else	/*send group list*/
			{
				area_file=fopen(bfile, "r");
				bigbuf[0]=0;
				while( fgets(line_buf, 255, area_file) )
				{
					parse_macro(line_buf);
					strcat(bigbuf, line_buf);
				}
				send_mpf(fd, bigbuf, strlen(bigbuf), DISPLAY);
			}
			continue;	/*start loop to ask user*/
		} /*end if*/


		/*make userselect without path*/
		strip_nl(user_select);
		split_filename(user_select, part_name);
		strcpy(user_select, part_name);

		/*****************************/
		/*check if group exist or not*/
		/*****************************/

		sprintf(bfile, "%s/%s/%s", FILE_PATH, user_select, FILE_LIST);

		if( !file_exist(bfile) )	/*user selection not found*/
		{
			test=open( bfile, O_WRONLY | O_APPEND | O_CREAT, S_IWUSR | S_IRUSR);
			if( test<0 )
			{
				display_msg(fd, NO_SUCH_AREA);
				continue;	/*re-ask user*/
			}
			else
			{
				close(test);
				unlink(bfile);
			}
		}


		/*********************/
		/*check join security*/
		/*********************/
		sprintf(bfile, "%s/%s/join.security", FILE_PATH, user_select);
		if( file_exist(bfile) )	/*join security found*/
		{
			test=open(bfile, O_RDONLY);
			if( test>0 )
			{
				ret=read(test, line_buf, 5);
				line_buf[ret]=0;
				file_join_level=atoi(line_buf);
				if(debug_mode) printf("(join.c)file join.security:%d\n", file_join_level);
			}
			else
			{
				do_log(8, "%s file join security file error", user_select);
			}
		}


		if( (user_level < file_join_level) && !system_operator )
		{
			display_msg(fd, JOIN_SECURITY);
			sprintf(line_buf, "%s%d\n", MINIMUM_JOIN_LEVEL, file_join_level);
			display_msg(fd, line_buf);
			continue;
		}

		/*--------------------------*/
		/*join security check passed*/
		/*--------------------------*/

		strcpy(file_area, user_select);
		do_log(3, "%s join file area %s", user_name, file_area);

		sprintf(temp, "%s%s\n", NOW_SELECT, file_area);
		display_msg(fd, temp);

		suspend(fd);

		return;

	} /*end while*/
}
/*end of chn_file_area*/



/*
	get_moderator_name --- get moderator name from moderator name list
*/
get_moderator_name(group, mname)
	char *group;
	char *mname;
/*
	return: TRUE: found, name put on mname
		FALSE:not found in the name list
*/
{
	char list_filename[128];
	FILE *mlist;
	char buf[82];
	char lgroup[50], lname[30];
	int nb;

	if(debug_mode) printf("(join.c)get moderator of group %s\n", group);

	sprintf(list_filename, "%s/%s", MAIL_PATH, MODERATORS);

	if( !file_exist(list_filename) )
		return(FALSE);			/*list file not found*/

	mlist=fopen(list_filename, "r");
	if( mlist==NULL )
	{
		do_log(6, "open %s error", MODERATORS);
		return(FALSE);
	}

	/***************************************************************/
	memset(buf, 0, 80);
	while( fgets(buf, 79, mlist) )
	{
		trim_comment(buf);

		nb=next_blank(buf);

		if( (nb>=strlen(buf)) || (strlen(buf)<=5) )
			continue;

		nstrcpy(lname, buf+nb+1, 30);

		buf[nb]=0;

		nstrcpy(lgroup, buf, 50);

		if( !strcmp(group, lgroup) )
		{
			nstrcpy(mname, lname, 20);
			if(debug_mode) printf("(join.c)found moderator %s\n", mname);
			return(TRUE);
		}
	}

	return(FALSE);
}
/*end of get_moderator_name*/
