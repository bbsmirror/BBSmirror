/*************************************************************************
 * toggle.c --- toggle files for downloading				 *
 *	      by Samson Chen, Apr 12, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"
#include "dbf.h"

static char rcsid[]="$Id: toggle.c,v 1.2 1994/05/04 05:51:13 pbbs Exp pbbs $";



/*
	toggle_files --- toggle files for downloading
*/
toggle_files(fd)
	int fd;
{
	char answer[80];
	char gfile[120];
	char part_name[80];
	char leave;

	leave=FALSE;

	do
	{
		asking(fd, TAG_WHAT, answer, 80);
		if( answer[0]==0 || answer[0]==13 )
		{
			leave=TRUE;
			continue;
		}

		strip_nl(answer);
		split_filename(answer, part_name);

		do_log(1, "%s toggle %s", user_name, part_name);

		if( toggles>=MAX_ALLOW_TAG )
		{
			display_msg(fd, TAG_TOO_MORE);
			leave=TRUE;
			continue;
		}

		sprintf(gfile, "%s/%s/%s", FILE_PATH, file_area, part_name);

		if( !file_exist(gfile) )
		{
			display_msg(fd, NO_SUCH_FILE);
			continue;
		}

		strcpy( tagged[toggles], gfile );
		toggles++;

	} while( !leave );
}
/*end of toggle_files*/



/*
	reset_toggles --- reset toggled files
*/
reset_toggles(fd)
	int fd;
{
	char answer[3];
	char line[120];
	char part_name[50];
	int n;

	if( toggles==0 )
		return;

	display_msg(fd, CURRENT_TOGGLES);

	for(n=0; n<toggles; n++)
	{
		split_filename(tagged[n], part_name);
		sprintf(line, "%2d %s\n", n+1, part_name);
		display_msg(fd, line);
	}

	display_msg(fd, "\n");

	asking(fd, RESET_TAG_CONFIRM, answer, 2);
	if( answer[0]=='y' || answer[0]=='Y' )
		toggles=0;
}
/*end of reset_toggles*/
