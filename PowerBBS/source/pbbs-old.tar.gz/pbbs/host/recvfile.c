/*************************************************************************
 * recvfile.c --- receive file from client				 *
 *	      by Aquarius Kuo, Apr 15, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"
#include "dbf.h"


static char rcsid[]="$Id: recvfile.c,v 1.2 1994/04/25 09:30:37 pbbs Exp pbbs $";

extern int errno ;

/*
	recv_file --- receive a file to client site
*/
int recv_file(fd, filename)
int fd;
char *filename;		/* in:upload path,  out:filename(no path) */
{
  int handle ;
  int i ;
  int tcpstat ;
  char prot ;
  char fn[120], *ptr ;
  char buffer[11000] ;
  long BLOCK ;
  long fl, len, len2 ;

  send_mpf(fd, " ", 1, UPLOAD) ;

  read_mpf(fd, fn, &len, &prot, FALSE);		/*--- get file name ---*/
  fn[len]=0 ;
  if( prot!=UPLOAD )
  {
    if(debug_mode)	printf("(recvfile.c) filename error !\n") ;
    return(FALSE) ;
  }  

  ptr=fn+strlen(fn)-1 ;			/* splite path & file name */
  while((*ptr!='/') && (*ptr!='\\') && (ptr!=fn))
    ptr-- ;
  ptr=(ptr==fn) ? ptr:ptr+1 ;  
  
  for(i=0; i<strlen(ptr); i++)	/*--- check file name ---*/
  {
    if(ptr[i]<33)
    {
      ptr[i]=0 ;  
      break ;
    }  
  }  
  
  strcpy(buffer,ptr) ;
  
  strcat(filename,"/") ;
  strcat(filename,ptr) ;
  strcpy(fn,filename) ;
  
  strcpy(filename,buffer) ;	/* ptr is return file name */

  if(debug_mode) 	printf("(recvfile.c) filename=(%s) fn=(%s)\n",filename,fn) ;  
  if((handle=open(fn,O_CREAT|O_EXCL|O_WRONLY, S_IWUSR|S_IRUSR))<0)
  {
    if(debug_mode)	printf("(recvfile.c) %s open error %d!\n",fn,errno) ;
    send_mpf(fd,UPLOAD_FILE_EXIST,strlen(UPLOAD_FILE_EXIST),STOPXFER) ;
    return(FALSE) ;
  } 
  
  send_mpf(fd," ",1,UPLOAD) ; 
  if( debug_mode ) 	printf("(recvfile.c) filename = %s\n",fn) ;
  
  read_mpf(fd,buffer,&len,&prot,FALSE) ; 	/*--- read BLOCK size ---*/
  if(prot!=UPLOAD)
  {
    send_mpf(fd," ",0,STOPXFER) ;
    close(handle) ;
    return(FALSE) ;
  }  
  
  buffer[len]=0 ;
  sscanf(buffer,"%ld",&BLOCK) ;
  if( debug_mode ) printf("(recvfile.c) BLOCK size = %d\n",BLOCK) ;
  
  if((BLOCK>11000) || (BLOCK<100))
  {
    do_log(9,"%s illegal block size %s",user_name,buffer) ;
    send_mpf(fd," ",0,STOPXFER) ;
    return(FALSE) ;
  }
  
  while(1)
  {
    if((tcpstat=read_mpf(fd,buffer,&len,&prot,FALSE))==1)
    {
      if(prot==XFER_ACK)
      {
        write(handle,buffer,len) ;
        send_mpf(fd," ",1,XFER_ACK) ;      
      }
      
      if(prot==STOPXFER)
      {
        close(handle) ;
        return(FALSE) ;
      }
      
      if(prot==END_XFER)
      {
        close(handle) ;
        break ;
      }
    }
    else
    {
      if(tcpstat==-1)
      {
        close(handle) ;
        abnormal_disconnect(fd) ;
      }
    }
  }
  return(TRUE) ;

}
/*end of send_file*/
