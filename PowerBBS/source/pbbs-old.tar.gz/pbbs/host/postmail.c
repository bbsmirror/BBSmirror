/*************************************************************************
 * postmail.c --- making posts						 *
 *	      by Samson Chen, Apr 7, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"
#include "dbf.h"

static char rcsid[]="$Id: postmail.c,v 1.16 1994/07/15 10:31:21 pbbs Exp pbbs $";

#define	MAX_QUOTE	151	/*max line number of quotation*/

char bigbuf[MAX_BUF];
char headbuf[1024];
char buf[255];




/*
	enter_mail --- do posing
*/
enter_mail(fd, emode, o_from_user, o_subject, quotation)
	int fd;
	char emode;	/*0 for entermail, 1 for reply mail, 2 for file post*/
	char *o_from_user;	/*used for emode 1*/
	char *o_subject;	/*used for emode 1*/
	char *quotation;	/*used for emode 1*/
{
	char answer[80];
	char post_subject[80];
	char from_name[20];
	char unique_id[20];
	char message_id[128];
	char timebuf[35];
	int ret;
	int n, m, qc;
	int rlen;
	char protocol;
	int test;
	char mfile[80], rfile[80];
	int msgfile, recfile;
	char ebuf[128];
	struct msgrec mr;
	char origin_filename[80];
	FILE *origin_file;
	char origin_line[80];
	char *p;
	char crlf[3];
	char ck1[5], ck2[5];
	unsigned int mbox_to_uid;	/*mbox recevier's uid*/

	if(debug_mode) printf("(postmail.c)enter_mail emode %d\n", emode);

	update_act(7, group_areaname);

	sprintf(crlf, "%c%c", 13, 10);

	/*********************/
	/*check post security*/
	/*********************/
	if( (user_level < mini_post_level) && !group_moderator && !system_operator)
	{
		display_msg(fd, crlf);

		display_msg(fd, POST_SECURITY);
		sprintf(buf, "%s%d\n", MINIMUM_POST_LEVEL, mini_post_level);
		display_msg(fd, buf);

		suspend(fd);

		return;
	}
	/*********************/

	if( emode==0 || emode==2 )
	{
		if( !strcmp(current_group, "mbox") )
		{
			memset(answer, 0, 80);
			asking(fd, MBOX_TO, answer, 20);
			for(n=0; n<20; n++)
			  if( answer[n]==13 || answer[n]==10 || answer[n]==0 )
			  {
				answer[n]=0;
				break;
			  }

			/*processing user's input*/
			answer[20]=0 ;
			answer[0]=toupper(answer[0]) ;
			for(n=1; n<strlen(answer); n++)
			{
				if(answer[n]==32)
				{
					n++ ;
					answer[n]=toupper(answer[n]) ;
				}
				else
				{  
					answer[n]=tolower(answer[n]) ;
				}  
			}

			/*-------------------------------------------*/
			if(debug_mode)printf("(postmail.c)search %s\n", answer);
			mbox_to_uid=get_user_id(answer);
			if(mbox_to_uid==0)	/*rcpt user not found*/
			{
				display_msg(fd, NO_SUCH_USER);
				suspend(fd);

				return;
			}
		}/*end if(mbox)*/


		/*************/
		/*ask subject*/
		/*************/
		memset(answer, 0, 80);
		asking(fd, ASK_POST_SUBJECT, answer, 80);
		alltrim(answer);
		if( strlen(answer)==0 ) return;
		nstrcpy(post_subject, answer, 80);

		if( emode != 2 )
			send_mpf(fd, NULL, 0, MAKEPOST);
		else
			send_mpf(fd, NULL, 0, FILEPOST);

	}
	else	/*emode==1*/
	{
		if( !strcmp(current_group, "mbox") )
		{
			/*****************/
			/*check from user*/
			/*****************/
			if(debug_mode)printf("(postmail.c)search %s\n", o_from_user);
			mbox_to_uid=get_user_id(o_from_user);
			if(mbox_to_uid==0)	/*rcpt user not found*/
			{
			  display_msg(fd, NO_SUCH_USER);
			  suspend(fd);
			  return;
			}
		}

		/*************/
		/*ask subject*/
		/*************/
		memset(answer, 0, 80);
		memset(buf, 0, 255);
		sprintf(buf, "%s[%s] ", ASK_POST_SUBJECT, o_subject);
		asking(fd, buf, answer, 80);
		alltrim(answer);

		if( answer[0]!=0 && answer[0]!=13 )
			nstrcpy(post_subject, answer, 80);
		else
		{
			if( strncmp(o_subject, "Re: ", 4) )
			{
			  strcpy(buf, "Re: ");
			  nstrcpy(buf+4, o_subject, 80);
			  nstrcpy(post_subject, buf, 80);
			}
			else
			{
			  nstrcpy(post_subject, o_subject, 80);
			}
		}

		/*ask quotation*/
		asking(fd, USE_QUOTATION, answer, 2);
		if( answer[0]=='y' || answer[0]=='Y')
		{
			/*add quotation sign*/
			p=quotation;
			n=strlen(p);
			for(m=n; m>=0; m--)
				p[m+3]=p[m];
			p[0]=' ';
			p[1]='>';
			p[2]=' ';
			p[n+3]=0;

			qc=1;	/*quotation count*/

			while(1)
			{
				p++;
				if(*p==0)
					break ;

				if(*p==10)
				{
					p++;
					if(*p==0)
						break ;

					n=strlen(p);

					/*compress blank lines*/
					if(*p==13 || *p==10)
					{
					  ret=0;
					  while( p[ret]==13 || p[ret]==10 )
						ret++;

						for(m=0; m<(n-ret); m++)
							p[m]=p[m+ret];

						p[n-ret]=0;
					}

					n=strlen(p);

					/*check singatur line "--\n" */
					if( n>=3 )
					{
					  if( p[0]=='-' && p[1]=='-' && (p[2]==13 || p[2]==10) )
					  /*sig lines found, strip it*/
					  {
						p[0]=0;
						break;
					  }
					}

					for(m=n; m>=0; m--)
						p[m+3]=p[m];
					p[0]=' ';
					p[1]='>';
					p[2]=' ';
					p[n+3]=0;

					qc++;
				}

				if( qc > MAX_QUOTE )
				{
					p[0]=0;
					break;
				}
			}

			strcat(quotation, crlf);

			send_mpf(fd, quotation, strlen(quotation), MAKEPOST);
		}
		else
			send_mpf(fd, NULL, 0, MAKEPOST);
	}

	idling=IDLE_TIME * POST_FACTOR;	/*extent editing time*/
	read_mpf(fd, bigbuf, &rlen, &protocol, FALSE);
	idling=IDLE_TIME;		/*restore idling time*/

	if( protocol==STOPPOST )
	{
		do_log(3, "%s abort posting at %s", user_name, current_group);
		return;
	}
	if( protocol!=MAKEPOST)
	{
		do_log(8, "%s protocol_stat_err with protocol code %d at enter_mail", user_name, protocol);
		protocol_stat_err(fd);
	}

	bigbuf[rlen]=0;

	/*take off trailing cr-lf*/
	ret=strlen(bigbuf);
	ret--;
	while(ret>=0)
	{
		if( (bigbuf[ret]!=13) && (bigbuf[ret]!=10) )
			break;

		bigbuf[ret]=0;
		ret--;
	}

	if( ret<0 )
	{
		do_log(3, "%s made an empty post at %s", user_name, current_group);
		return;
	}

	strcpy(from_name, user_name);

	for(n=0; n<strlen(from_name); n++)
		if( from_name[n]==' ' )
		{
			from_name[n]='.';
			break;
		}

	if(debug_mode) printf("(postmail.c)server writing post\n");

	/*---------------------------------------------------------------*/
	if( strcmp(current_group, "mbox") )
	{
		sprintf(mfile, "%s/%s/messages", MAIL_PATH, current_group);
		sprintf(rfile, "%s/%s/records", MAIL_PATH, current_group);
	}
	else	/*mbox*/
	{
		sprintf(mfile, "%s/mbox/%d.messages", MAIL_PATH, mbox_to_uid);
		sprintf(rfile, "%s/mbox/%d.records", MAIL_PATH, mbox_to_uid);
	}
	/*---------------------------------------------------------------*/

	if( !file_exist(mfile) )
	{
		test=open( mfile, O_WRONLY | O_APPEND | O_CREAT, S_IWUSR | S_IRUSR);
		if( test<0 )
		{
			do_log(9, "%s open error!?", mfile);
			sprintf(ebuf, "postmail.c: %s", SYSTEM_ERROR);
			send_mpf(fd, ebuf, strlen(ebuf), REJECT);
			exit(12);
		}
		else
			close(test);
	}

	if( !file_exist(rfile) )
	{
		test=open( rfile, O_WRONLY | O_APPEND | O_CREAT, S_IWUSR | S_IRUSR);
		if( test<0 )
		{
			do_log(9, "%s open error!?", rfile);
			sprintf(ebuf, "postmail.c: %s", SYSTEM_ERROR);
			send_mpf(fd, ebuf, strlen(ebuf), REJECT);
			exit(12);
		}
		else
			close(test);
	}

	msgfile=open(mfile, O_WRONLY | O_APPEND);
	if( msgfile<0 )
	{
		do_log(9, "%s open error!?", mfile);
		sprintf(ebuf, "postmail.c: %s", SYSTEM_ERROR);
		send_mpf(fd, ebuf, strlen(ebuf), REJECT);
		exit(12);
	}

	recfile=open(rfile, O_WRONLY | O_APPEND);
        if( recfile<0 )
        {
                do_log(9, "%s open error!?", rfile);
		sprintf(ebuf, "postmail.c: %s", SYSTEM_ERROR);
		send_mpf(fd, ebuf, strlen(ebuf), REJECT);
		exit(12);
        }

	flock(msgfile, LOCK_EX);	/*exclusive lock*/
	flock(recfile, LOCK_EX);	/*exclusive lock*/

	lseek(msgfile, 0, SEEK_END);
	mr.offset=file_length(msgfile);
	mr.packed=' ';
	mr.delete_mark=' ';

	memset(buf, 0, 255);
	sprintf(buf, "Path: %s%c%c", STATION_ID, 13, 10);
		write(msgfile, buf, strlen(buf) );

	memset(buf, 0, 255);
	sprintf(buf, "From: %s@%s (%s)%c%c", from_name, NNRP_DOMAIN,  user_name, 13, 10);
		write(msgfile, buf, strlen(buf) );

	memset(buf, 0, 255);
	sprintf(buf, "Subject: %s%c%c", post_subject, 13, 10);
		write(msgfile, buf, strlen(buf) );

	memset(buf, 0, 255);
	memset(message_id, 0, 128);
	memset(unique_id, 0, 20);
	get_mid(unique_id);
	sprintf(message_id, "<%s@%s>", unique_id, NNRP_DOMAIN);
	sprintf(buf, "Message-ID: %s%c%c", message_id, 13, 10);
		write(msgfile, buf, strlen(buf) );

	rfcgmtime(timebuf);
	memset(buf, 0, 255);
	sprintf(buf, "Date: %s GMT%c%c", timebuf, 13, 10);
		write(msgfile, buf, strlen(buf) );

	memset(buf, 0, 255);
	sprintf(buf, "Organization: %s%c%c", SORGANIZATION, 13, 10);
		write(msgfile, buf, strlen(buf) );

	if( email_check(user_email) )
	{
		memset(buf, 0, 255);
		sprintf(buf, "Reply-To: %s%c%c", user_email, 13, 10);
			write(msgfile, buf, strlen(buf) );
	}

	memset(buf, 0, 255);
	sprintf(buf, "%c%c", 13, 10);
	write(msgfile, buf, 2);

	if( emode==1 && strcmp(current_group, "mbox") )
	{
		memset(buf, 0, 255);
		sprintf(buf, "followed %s's post...%c%c", o_from_user, 13, 10);
		write(msgfile, buf, strlen(buf));
	}

	write(msgfile, bigbuf, strlen(bigbuf) );

	/*add origin line if exist*/
	sprintf(origin_filename, "%s/%s/origin", MAIL_PATH, current_group);
	if( file_exist(origin_filename) )
	{
		origin_file=fopen(origin_filename, "r");
		fgets( origin_line, 79, origin_file);
		fclose(origin_file);

		write(msgfile, crlf, strlen(crlf) );

		memset(buf, 0, 255);

		sprintf(ck1, "%c--%c", 10, 13);
		sprintf(ck2, "%c--%c", 10, 10);

		if( strstr(bigbuf, ck1) || strstr(bigbuf, ck2) )
		  sprintf(buf, "%c%c * Origin: %s%c%c", 13, 10, origin_line, 13, 10);
		else
		  sprintf(buf, "--%c%c * Origin: %s%c%c", 13, 10, origin_line, 13, 10);
		write(msgfile, buf, strlen(buf) );
	}

	lseek(msgfile, 0, SEEK_END);
	mr.length=file_length(msgfile)-mr.offset;
	
	write(recfile, &mr, sizeof(mr) );

	flock(msgfile, LOCK_UN);	/*unlock*/
	flock(recfile, LOCK_UN);	/*unlock*/

	do_log(6, "%s post a new mail at %s mid %s", user_name, current_group, message_id);

	close(msgfile);
	close(recfile);

	if( !strcmp(current_group, "mbox") )
	{
		do_log(0, "set mbox quote to user #%d", mbox_to_uid);
		set_mail_quote(mbox_to_uid, 'Y');
	}
}
/*end of enter_mail*/
