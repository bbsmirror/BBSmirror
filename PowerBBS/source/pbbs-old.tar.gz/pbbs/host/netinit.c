/************************************************************************
 * netinit.c --- network initializing subroutines			*
 *		 by Samson Chen, Nov 30, 1993				*
 ************************************************************************/

#include "pbbs.h"

static char rcsid[]="$Id: netinit.c,v 1.2 1994/04/25 09:30:37 pbbs Exp pbbs $";

/*
	get socket file descriptor
*/
getsockfd()
{
	int	sockfd;
	struct 	sockaddr_in serv_addr;
	int	on=1;

	/* open a TCP socket for internet stream socket */
	if( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		err("Server: cannot open stream socket");

	/* bind our local address */
	bzero((char *)&serv_addr, sizeof(serv_addr));
	serv_addr.sin_family	= AF_INET;
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_addr.sin_port	= htons(PBBS_SERV_PORT);

	/* set socket option --- reuseaddr */
	(void) setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on));

	/* set socket option --- keep connection alive */
	(void) setsockopt(sockfd, SOL_SOCKET, SO_KEEPALIVE, (char *)&on, sizeof(on));

	if( bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) <0)
		err("server: cannot bind local address");

	return(sockfd);
}
/*end of getsockfd*/


	
/********************/
/*err :  Fault Exit */
/********************/
err(errmsg)
char *errmsg;
{
	do_log(9, errmsg);
	printf(" %s\n", errmsg);
	exit(10);
}
