/***************************************************************************
 * swrite.c --- safe writing routine					   *
 *	       by Samson Chen, Mar 7, 1994				   *
 ***************************************************************************/

#include <sys/file.h>
#include "protocol.h"
#include "message.h"

static char rcsid[]="$Id: swrite.c,v 1.1 1994/04/22 10:03:59 pbbs Exp pbbs $";

/*
	safe_write --- safety write
*/
safe_write(ffd, buf, len, fd)
	int ffd;	/*disk file descriptor*/
	char *buf;	/*data buffer*/
	int len;	/*data length*/
	int fd;		/*network file descriptor*/
{
	char ebuf[255];
	int cc;
	int sz=len;
	char *bp=buf;

	flock(ffd, LOCK_EX);	/*exclusive lock*/

	do
	{
		cc=write(ffd, bp, sz);
		if( cc>0 )
		{
			bp += cc;
			sz -= cc;
		}
		else if( cc<0 )
		{
			off_putmp();
			sprintf(ebuf, "swrite.c: %s", SYSTEM_ERROR);
			send_mpf(fd, ebuf, strlen(ebuf), REJECT);
			exit(12);
		}
	}
	while( sz>0 );

	flock(ffd, LOCK_UN);	/*unlock*/
}
