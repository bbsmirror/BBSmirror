
/* head file for data bas format */

/*
	data base format for user's data
*/
struct udb {
	char	delete_mark;	/*delete mark*/
	char	bbs_name[20];	/*user id*/
	char	password[14];	/*encrypted user password*/
	char	real_name[20];	/*user's real name*/
	char	email[40];	/*user's email address*/
	char	address[60];	/*user's address*/
	char	phone[20];	/*user's phone number*/
	char	sex;		/*sex*/
	char	interest[21];	/*user's interests*/
	char	term[8];	/*user's terminal type*/
	char	spec[41];	/*specification of user's platform*/
	char	first_login[26];/*date of first login*/
	char	last_login[26];	/*date of last login*/
	char	user_set[2];	/*user's set-up switch*/
				/*bit-0 of user_set[0]: page on/off*/
	char	mailbox;	/*notation for user's mail box*/
	unsigned int	level;		/*user's security level*/
	unsigned int	total_post;	/*total posts*/
	unsigned int	total_login;	/*total login number*/
	unsigned int	total_upload;	/*total upload in Kbytes*/
	unsigned int	total_download;	/*total download in Kbytes*/
	char	reserved[20];	/*reserved field*/
	};
/*end of struct udb*/



/*
	system_rec --- system record
	note: this record put on the first record (rec #0) of the user data
	      base, so the length of it cannot exceed sizeof(struct udb)
*/
struct system_rec	{
	unsigned int	total_regs;	/*total number of registered people*/
	unsigned long	total_login;	/*total number of login*/
};
/*end of system_rec*/
	


/*
	message point record
*/
struct msgrec	{
	unsigned long	offset;		/*message offset*/
	unsigned int	length;		/*message length*/
	char		packed;		/*packed for xfer*/
	char		delete_mark;
};
/*end of struct msgrec*/



/*
	on-line user database
*/
struct putmp	{
	char	active;		/*valid slot*/
	int	uid;		/*user id*/
	int	pid;
	char	from[30];	/*user connected from*/
	char	act_stat;	/*current action stat*/
	char	act_info[20];	/*action information*/
	char	page_mode;	/*0:User Page,1:Talk,2:Stop Talk*/
	int	page_uid;	/*uid of the page user*/
	char	chatroom;	/*chatroom #*/
	char	callsign[20];	/*callsign at that chatroom*/
};
/*end of struct putmp*/
