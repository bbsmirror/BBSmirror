/*************************************************************************
 * intrread.c --- interactive read					 *
 *	      by Samson Chen, Apr 22, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"
#include "dbf.h"

static char rcsid[]="$Id: intrread.c,v 1.7 1994/07/14 11:49:11 pbbs Exp pbbs $";

#define	IBUF_SIZE	10240

char inter_buf[IBUF_SIZE];
char bigbuf[MAX_BUF];
char line[255];


/*
	inter_read --- interactive reading
*/
inter_read(fd)
	int fd;
{
	char answer[80];
	int scr_size;	/*client's screen size*/
	int scrcnt;
	int rlen;
	char protocol;
	char filename[256];
	char ebuf[256];
	char txtbuf[80];
	int mffd;
	int mfrec;
	struct msgrec mrec;
	int mp;	/*message pointer*/
	char leave;
	int total_msg;
	int recno;
	int ret;
	char crlf[3];
	int fp;
	char from_name[80];
	int cpn, slen;
	char from_line[80];
	char *from_field, *subject_field;
	char *ptr;
	int readfrom;
	char error_entry[20];
	char forward_dir;
	char *ibuf_head;
	char check_link;

	update_act(6, group_areaname);

	strcpy(error_entry, "<ERROR>");

	/*get client's screen size*/

	send_mpf(fd, NULL, 0, SCRSIZE);
	read_mpf(fd, answer, &rlen, &protocol, FALSE);
	if( protocol != SCRSIZE )
	{
		do_log(8, "%s protocol_stat_err with protocol code %d at inter_read", user_name, protocol);
		protocol_stat_err(fd);
	}

	answer[rlen]=0;
	strip_nl(answer);
	scr_size=atoi(answer);
	scr_size--;			/*adjust output lines*/
	if(scr_size<1) scr_size=5;	/*no screen size???*/
	forward_dir=TRUE;		/*assume read forward*/

	if(debug_mode) printf("(intrread.c)get screen size %d\n", scr_size);


	/*------------------------------------------------------------*/
	if( strcmp(current_group, "mbox") )
	  sprintf(filename, "%s/%s/messages", MAIL_PATH, current_group);
	else
	  sprintf(filename, "%s/mbox/%d.messages", MAIL_PATH, user_uid);

	mffd=open(filename, O_RDONLY|O_CREAT, S_IWUSR | S_IRUSR);
	/*------------------------------------------------------------*/

	/*------------------------------------------------------------*/
	if( strcmp(current_group, "mbox") )
	  sprintf(filename, "%s/%s/records", MAIL_PATH, current_group);
	else
	  sprintf(filename, "%s/mbox/%d.records", MAIL_PATH, user_uid);
	
	mfrec=open(filename, O_RDONLY|O_CREAT, S_IWUSR | S_IRUSR);
	/*------------------------------------------------------------*/

	if( mffd<0 || mfrec<0 )
	{
		sprintf(ebuf, "readpost.c: %s", SYSTEM_ERROR);
		send_mpf(fd, ebuf, strlen(ebuf), REJECT);
		exit(12);
	}


	/*------------------------------------------------------------*/

	sprintf(crlf, "%c%c", 13, 10);

	total_msg=file_length(mfrec)/sizeof(struct msgrec);

	mp=get_lastread(fd)-1;
	if(mp>=total_msg) mp=total_msg-1;
	if(mp<0) mp=0;

	leave=FALSE;
	do
	{
	  display_msg(fd, WAIT_PLEASE);
	  total_msg=file_length(mfrec)/sizeof(struct msgrec);

	  if( mp<0 )
		mp=total_msg-1;
	  else if( mp>=total_msg )
		mp=0;

	  scrcnt=0;
	  recno=mp;
	  inter_buf[0]=0;
	  check_link=FALSE;

	  if( forward_dir )
	  {
		ibuf_head=inter_buf;
	  }
	  else
	  {
		ibuf_head=inter_buf + (IBUF_SIZE-1);
		*ibuf_head=0;
	  }

	  if(debug_mode) printf("(intrread.c)assemble selections, mp=%d\n", mp);

	  do
	  {
		if( total_msg<=0 )
			break;

		if( recno<0 )
			recno=total_msg-1;
		else if( recno>=total_msg )
				break;

		if( check_link )
		{
			if( recno==mp )
				break;
		}
		else
		{
			check_link=TRUE;
		}

		/*----------------------------------------------------*/

		lseek(mfrec, recno*sizeof(struct msgrec), SEEK_SET);
		read(mfrec, &mrec, sizeof(struct msgrec) );

		/*----------------------------------------------------*/

		/*check delete mark*/
		if( mrec.delete_mark=='D' )
		{
			if( forward_dir )
				recno++;
			else
				recno--;

			continue;
		}

		/*get message body*/

		lseek(mffd, mrec.offset, SEEK_SET);
		if( mrec.length<MAX_HEAD)
		{
			ret=read(mffd, bigbuf, mrec.length);
		}
		else
		{
			ret=read(mffd, bigbuf, MAX_HEAD);
		}
		bigbuf[ret]=0;


		/*parse message head*/

		fp=parse_msg(fd, bigbuf, "Subject: ");
		if( fp<0 )
		{
			subject_field=error_entry;
		}
		else
		{
			subject_field=bigbuf+fp;
			strip_nl(subject_field);
			subject_field+=9;
		}

		/*skip cmsg cancel message*/
		if( !strncmp(subject_field, "cmsg cancel", 11) )
		{
			if( forward_dir )
				recno++;
			else
				recno--;

			continue;
		}

		fp=parse_msg(fd, bigbuf, "From: ");
		if( fp<0 )
		{
			subject_field=error_entry;
		}
		else
		{
			from_field=bigbuf+fp;
			strip_nl(from_field);
			from_field+=6;
		}

		nstrcpy(from_line, from_field, 80);
		ptr=strtok(from_line, "(<[");

		if( ptr !=NULL )
		{
			ptr=strtok(NULL, ")>]");
			if( ptr!=NULL )
				nstrcpy(from_name, ptr, 80);
			else
				nstrcpy(from_name, from_field, 80);
		}
		else
			nstrcpy(from_name, from_field, 80);

		strip_nl(from_name);

		/*assemble head buffer*/

		line[0]=0;
		sprintf(txtbuf, "%d", recno+1);
		strcat( line, txtbuf );
		strcat( line, crlf );
		strcat( line, subject_field);
		strcat( line, crlf );
		strcat( line, from_name );
		strcat( line, crlf );

		if( forward_dir )
		{
			strcat( ibuf_head, line );
		}
		else
		{
			ret=strlen(line);
			ibuf_head -= ret;

			for(ret=0; ret<strlen(line); ret++)
				ibuf_head[ret]=line[ret];
		}

		/* add counter*/

		scrcnt++;

		if( forward_dir )
			recno++;
		else
			recno--;

	  }while(scrcnt<scr_size);

	  send_mpf(fd, ibuf_head, strlen(ibuf_head), INTRREAD);

	  /*
	  if(debug_mode) printf("(intrread.c)inter_buf->\n%s\n", inter_buf);
	  */

	  read_mpf(fd, answer, &rlen, &protocol, FALSE);
	  if( protocol != INTRREAD )
	  {

		do_log(8, "%s protocol_stat_err with protocol code %d at intrread", user_name, protocol);
		protocol_stat_err(fd);
	  }

	  answer[rlen]=0;
	  strip_nl(answer);

	  /*---------------------------------------*/

	  if(answer[0]=='q' || answer[0]=='Q')
	  {
		/*quit interactive reading*/
		leave=TRUE;
		continue;
	  }

	  if(answer[0]=='u' || answer[0]=='U')
	  {
		if(debug_mode) printf("(intrread.c)PageUp\n");

		/*PageUp*/
		if( forward_dir )
			mp -= 1;
		else
			mp = recno;


		forward_dir=FALSE;

		continue;
	  }

	  if(answer[0]=='d' || answer[0]=='D')
	  {
		if(debug_mode) printf("(intrread.c)PageDown\n");

		/*PageDown*/
		if( forward_dir )
			mp = recno;
		else
			mp += 1;


		forward_dir=TRUE;

		continue;
	  }

	  /*---------------------------------------*/

	  readfrom=atoi(answer);

	  if( readfrom > total_msg )
		readfrom=total_msg;

	  if(debug_mode) printf("(intrread.c)user select %d\n", readfrom);

	  read_mail(fd, 1, readfrom-1);

	  mp=get_lastread(fd)-1;

	  forward_dir=TRUE;		/*reset direction flag*/

	}while(!leave);

	close(mffd);
	close(mfrec);
}
/*end of inter_read*/
