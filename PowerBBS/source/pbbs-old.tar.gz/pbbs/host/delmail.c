/*************************************************************************
 * delmail.c --- delete mail						 *
 *	         by Samson Chen, Apr 19, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "dbf.h"
#include "message.h"
#include "global.h"

static char rcsid[]="$Id: delmail.c,v 1.9 1994/05/14 00:24:19 pbbs Exp pbbs $";


char bigbuf[MAX_BUF];
char line[255];


/*
	do_del_msg --- ask msg no for deleting
*/
do_del_msg(fd)
	int fd;
{
	char answer[80];
	int del_no;

	asking(fd, KILL_WHAT_MSG, answer, 80);

	del_no=atoi(answer);

	if(debug_mode) printf("(delmail.c)do_del_msg # %d\n", del_no);

	delete_message(fd, del_no-1);
}
/*end of do_del_msg*/



/*
	delete_message --- (as the name)
*/
delete_message(fd, delno)
	int fd;
	int delno;	/*the msg record no to be deleted*/
{
	char filename[256];
	char ebuf[128];
	int mffd;
	int mfrec;
	int rec;
	struct msgrec mrec, mr;
	int total_msg;
	char *p;
	int ret;
	char crlf[3];
	char *sender;
	char *spath;
	char *mid;
	int fp;
	int n;
	char from_name[20];
	char from_field[128];
	char answer[80];
	char buf[255];
	char message_id[128];
	char unique_id[20];
	char timebuf[35];

	if(debug_mode) printf("(delmail.c)delete_message %d\n", delno);

	sprintf(crlf, "%c%c", 13, 10);

	/*------------------------------------------------------------*/
	if( strcmp(current_group, "mbox") )
	  sprintf(filename, "%s/%s/messages", MAIL_PATH, current_group);
	else
	  sprintf(filename, "%s/mbox/%d.messages", MAIL_PATH, user_uid);

	mffd=open(filename, O_RDWR|O_CREAT, S_IWUSR | S_IRUSR);
	/*------------------------------------------------------------*/

	/*------------------------------------------------------------*/
	if( strcmp(current_group, "mbox") )
	  sprintf(filename, "%s/%s/records", MAIL_PATH, current_group);
	else
	  sprintf(filename, "%s/mbox/%d.records", MAIL_PATH, user_uid);
	
	mfrec=open(filename, O_RDWR|O_CREAT, S_IWUSR | S_IRUSR);
	/*------------------------------------------------------------*/

	if( mffd<0 || mfrec<0 )
	{
		sprintf(ebuf, "delmail.c: %s", SYSTEM_ERROR);
		send_mpf(fd, ebuf, strlen(ebuf), REJECT);
		exit(12);
	}
	/*------------------------------------------------------------*/

	lseek(mfrec, 0 ,SEEK_END);
	total_msg=file_length(mfrec)/sizeof(struct msgrec);

	if( delno<0 || delno>=total_msg)
	{
		display_msg(fd, MSG_NO_ERR);
		suspend(fd);
		return;
	}

	/*------------------------------------------------------------*/
	/*get the message*/

	lseek(mfrec, delno*sizeof(struct msgrec), SEEK_SET);
	read(mfrec, &mrec, sizeof(struct msgrec) );

	p=bigbuf;
	lseek(mffd, mrec.offset, SEEK_SET);
	ret=read(mffd, p, mrec.length);

	/*------------------------------------------------------------*/
	/*get message data*/
	fp=parse_msg(fd, bigbuf, "Message-ID: ");
	mid=bigbuf+fp;
	strip_nl(mid);
	mid+=12;

	fp=parse_msg(fd, bigbuf, "From: ");
	sender=bigbuf+fp;
	strip_nl(sender);
	sender+=6;

	fp=parse_msg(fd, bigbuf, "Path: ");
	spath=bigbuf+fp;
	strip_nl(spath);
	spath+=6;

	if(debug_mode) printf("(delmail.c)get ->%s, %s, %s\n", spath, sender, mid);

	/*------------------------------------------------------------*/
	/*check sender*/
	if( !system_operator && !group_moderator && strcmp(current_group, "mbox") )
	/*SysOp, Moderator, mbox group will skip checking*/
	{
		nstrcpy(from_name, user_name, 20);
		for(n=0; n<strlen(from_name); n++)
			if( from_name[n]==' ' )
			{
				from_name[n]='.';
				break;
			}

		sprintf(from_field, "%s@%s (%s)", from_name, NNRP_DOMAIN,  user_name);

		if( strcmp(sender, from_field) )
		{
			display_msg(fd, CANNOT_KILL);
			suspend(fd);
			return;
		}
	}

	/*------------------------------------------------------------*/
	/*check sending station*/
	if( strcmp(STATION_ID, spath) )
	{
		display_msg(fd, CANNOT_KILL_NET);
		suspend(fd);
		return;
	}

	/*------------------------------------------------------------*/

	/*re-confirm*/
	asking(fd, CONFIRM_MSG, answer, 2);
	if( answer[0]!='y' && answer[0]!='Y' )
		return;

	/*------------------------------------------------------------*/
	/*del local msg*/
	flock(mfrec, LOCK_EX);
	mrec.delete_mark='D';
	lseek(mfrec, delno*sizeof(struct msgrec), SEEK_SET);
	write(mfrec, &mrec, sizeof(struct msgrec) );
	flock(mfrec, LOCK_UN);

	/*------------------------------------------------------------*/
	/*set NNTP delete queue*/
	if( !strcmp(PBBS_NNTP, "YES") && mrec.packed=='P' )
	{
	  /*this post has been exported*/

	  /*make a cmsg post for NNTP*/

	  flock(mfrec, LOCK_EX);
	  flock(mffd, LOCK_EX);

	  if(debug_mode) printf("(delmail.c)make a cmsg post for %s %s\n", sender, mid);

	  lseek(mffd, 0, SEEK_END);
	  mr.offset=file_length(mffd);
	  mr.packed=' ';
	  mr.delete_mark=' ';

	  memset(buf, 0, 255);
          sprintf(buf, "Path: %s%c%c", STATION_ID, 13, 10);
	  write(mffd, buf, strlen(buf) );

	  memset(buf, 0, 255);
	  sprintf(buf, "From: %s%c%c", sender, 13, 10);
	  write(mffd, buf, strlen(buf) );

	  memset(buf, 0, 255);
	  sprintf(buf, "Subject: cmsg cancel %s%c%c", mid, 13, 10);
	  write(mffd, buf, strlen(buf) );

	  memset(buf, 0, 255);
          memset(message_id, 0, 128);
          memset(unique_id, 0, 20);
          get_mid(unique_id);
          sprintf(message_id, "<%s@%s>", unique_id, NNRP_DOMAIN);
          sprintf(buf, "Message-ID: %s%c%c", message_id, 13, 10);
	  write(mffd, buf, strlen(buf) );

        
          rfcgmtime(timebuf);
          memset(buf, 0, 255);
          sprintf(buf, "Date: %s GMT%c%c", timebuf, 13, 10);
	  write(mffd, buf, strlen(buf) );

          memset(buf, 0, 255);
          sprintf(buf, "Organization: %s%c%c", SORGANIZATION, 13, 10);
	  write(mffd, buf, strlen(buf) );

	  if( email_check(user_email) )
          {
		memset(buf, 0, 255);
                sprintf(buf, "Reply-To: %s%c%c", user_email, 13, 10);
		write(mffd, buf, strlen(buf) );
          }

          memset(buf, 0, 255);
          sprintf(buf, "%c%c", 13, 10);
	  write(mffd, buf, 2);

          memset(buf, 0, 255);
	  sprintf(buf, "%s%s%c%c", "Article cancelled from ", NNRP_DOMAIN, 13, 10);
	  write(mffd, buf, strlen(buf) );

          memset(buf, 0, 255);
	  sprintf(buf, "%s%c%c", "PowerBBS NNTP Manager", 13, 10);
	  write(mffd, buf, strlen(buf) );

	  lseek(mffd, 0, SEEK_END);
          mr.length=file_length(mffd)-mr.offset;

	  lseek(mfrec, 0, SEEK_END);
          write(mfrec, &mr, sizeof(mr) );

	  flock(mfrec, LOCK_UN);
	  flock(mffd, LOCK_UN);

	}/*end if*/

	/*------------------------------------------------------------*/
	close(mfrec);
	close(mffd);

	do_log(5,"%s delete msg record #%d", user_name, delno);
	display_msg(fd, MSG_KILLED);

}
/*end of delete_message*/
