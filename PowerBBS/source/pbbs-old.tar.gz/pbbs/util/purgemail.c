/**************************************************
    Purge mail. redo mail data base
    write by Aquarius Kuo  July 5, 1994.
***************************************************/
#include "../host/pbbs.h"
#include "../host/dbf.h"
#include "../setup.h"
#include <ctype.h>

#define MAXLB     240

/********************************
    get file length
    write by Aquarius Kuo.
*/
long flength(filename)
char *filename ;
{
  struct stat file_status ;
  
  stat(filename,&file_status) ;
  return(file_status.st_size) ;
}

purge_data(dir,maxno,hold_max)
char *dir ;
long maxno ;		/* if recno > maxno then purge mail database */
long hold_max ; 	/* max hold number */
{
  char fn[MAXLB], buf[MAX_BUF] ;
  char mesg[80], reco[80], user[80] ;
  char *ptr ;
  long i, j, m, n, tmp, cnt, offset ;
  int hm, hr, hu, ht1, ht2 ;            /* file handle */
  int f_err=0 ;
  struct msgrec recno ;
  long real_keep ;


  if( (dir[0]==0) || (maxno<=0) || (hold_max<=0) )      /* NULL string or MAXNO=0 */
  {
    return(1) ;
  }

  if( !strcmp(dir,"mbox") )   /* personal mail box */
  {

    return(1) ;
  }

  sprintf(fn,"%s/%s",MAIL_PATH,dir) ;    /* fn is the current area path */

  sprintf(mesg,"%s/messages",fn) ;
  sprintf(reco,"%s/records",fn) ;
  sprintf(user,"%s/users",fn) ;

  m=flength(mesg) ;
  n=flength(reco)/sizeof(struct msgrec) ;     /* n=record number */

  if( (n>maxno) && (n>hold_max) )
  {
    i=n-hold_max ;       /*--- i: old file pointer ---*/
  }
  else
  {
    return(1) ;
  }
  
  if( (hm=open(mesg,O_RDWR))<0 )
  {
    printf("%s open error!!\r\n",mesg) ;
    fflush(stdout) ;
    unlink(mesg) ;
    unlink(reco) ;
    unlink(user) ;
    return(1) ;
  }

  if((hr=open(reco,O_RDWR))<0)
  {
    close(hm) ;
    unlink(mesg) ;
    unlink(reco) ;
    unlink(user) ;
    return(1) ;
  }

  if((hu=open(user,O_RDWR))<0)
  {
    if((hu=open(user,O_CREAT|O_RDWR|O_TRUNC,S_IWUSR | S_IRUSR))<0)
    {
      printf("can't set users file '%s' !!\n\r", user) ;
      fflush(stdout) ;
      close(hm) ;
      close(hr) ;
      return(1) ;
    }
  }

  flock(hm,LOCK_EX) ;
  flock(hr,LOCK_EX) ;
  flock(hu,LOCK_EX) ;

    lseek(hr,i*sizeof(struct msgrec),SEEK_SET) ;

    j=0 ;   /*--- j: new file pointer ---*/
    offset=0 ;

    while(read(hr,&recno,sizeof(struct msgrec))>0)
    {
      if( (recno.offset>m) || (recno.offset<10) )      /* records error */
      {
        ftruncate(hm,0) ;
        ftruncate(hr,0) ;
        ftruncate(hu,0) ;
        f_err=1 ;
        break ;
      }

      if(recno.delete_mark=='D')      /* deleted post */
      {
        i++ ;
        lseek(hr,i*sizeof(struct msgrec),SEEK_SET) ;
        continue ;
      }

      lseek(hm,recno.offset,SEEK_SET) ;
      read(hm,buf,recno.length) ;             /* move one message to tmp */

      lseek(hm,offset,SEEK_SET) ;
      write(hm,buf,recno.length) ;

      recno.offset=offset ;
      offset+=recno.length ;

      lseek(hr,j*sizeof(struct msgrec),SEEK_SET) ;
      write(hr,&recno,sizeof(struct msgrec)) ;       /* tmp for record */

      i++ ;
      j++ ;
      lseek(hr,i*sizeof(struct msgrec),SEEK_SET) ;
    }

    real_keep=j;

    if( !f_err )
    {
      ftruncate(hm,offset) ;
      ftruncate(hr,j*sizeof(struct msgrec)) ;


      if( read(hu,&tmp,sizeof(int))<sizeof(int) )
      {
        ftruncate(hu,0) ;
      }
      else
      {
        j=1 ;
        lseek(hu,j*sizeof(int), SEEK_SET) ;

        while( read(hu,&tmp,sizeof(int))==sizeof(int) )
        {
          tmp-=(n-real_keep) ;

	  if( tmp>real_keep )
	    tmp=real_keep ;

          if( tmp<0 )
            tmp=0 ;

          lseek(hu,j*sizeof(int), SEEK_SET) ;
          write(hu,&tmp,sizeof(int)) ;
          j++ ;

          lseek(hu,j*sizeof(int), SEEK_SET) ;

        }
      }
    }

  flock(hm,LOCK_EX) ;
  flock(hr,LOCK_EX) ;
  flock(hu,LOCK_EX) ;
  close(hm) ;
  close(hr) ;
  close(hu) ;

  return(0) ;
}

/*========================================================*/
main(argc,argv)
int argc ;
char *argv[] ;
{
  char marea[MAXLB], dir[MAXLB], fn[MAXLB] ;
  char mesg[80], reco[80], user[80] ;
  char *ptr ;
  long i, j, offset ;
  long maxno, hold_max ;
  int  smode=0 ;
  struct msgrec recno ;
  FILE *fp ;

  chdir(SYSTEM_PATH) ;

  if(argc<3)
  {
    printf("syntax error:\n") ;
    printf("       %s -s <control_filename>\r\n\n", argv[0]) ;
    printf("       %s -d <mail_area_directory> <purge_num> <keep_num>\r\n\n", argv[0]) ;
    exit(1) ;
  }
  
  if( !strcmp(argv[1],"-s") )
  {
    sprintf(fn,"%s/%s",MAIL_PATH,argv[2]) ;
    if( (fp=fopen(argv[2],"r"))==NULL )
    {
      printf("%s not found!!\r\n\n",argv[2]) ;
      exit(1) ;
    }
    smode=1 ;         /* setup file */
  }

  if( !strcmp(argv[1],"-d") )
  {
    strcpy(dir,argv[2]) ;
    if(argc>4)
    {
      maxno=atoi(argv[3]) ;
      hold_max=atoi(argv[4]) ;
      purge_data(dir,maxno,hold_max) ;
      smode=2 ;         /* mail area directory */
    }
  }
  
  if( smode==0 )
  {
    printf("syntax error:\n") ;
    printf("       %s -s <filename>\r\n\n", argv[0]) ;
    printf("       %s -d <mail_area_directory> <purge_num> <keep_num>\r\n\n", argv[0]) ;
    exit(1) ;
  }

  if( smode==1 )
  {
    while(fgets(marea,MAXLB,fp)!=NULL)
    {
      ptr=marea ;
      if(*ptr=='#')       /* remark line */
        continue ;

      while( (!isspace(*ptr)) && *ptr!=0 )        /* get area name */
        ptr++ ;

      if( *ptr==0 )       /* no maxno */
        continue ;

      *ptr=0 ;
      while( isspace(*(++ptr)) && *ptr!=0 ) ;     /* parse space alpha */
    
      if( *ptr==0 )
        continue ;
        
      maxno=atoi(ptr) ;           /* get max hold number */
      
      while( isdigit(*(++ptr)) && *ptr!=0 ) ;     /* parse digit alpha */
      while( isspace(*(++ptr)) && *ptr!=0 ) ;     /* parse space alpha */
      hold_max=atoi(ptr) ;
      if( hold_max==0 )
        hold_max=maxno ;
    
      strcpy(dir,marea) ;         /* dir record the mail area directory */

      purge_data(dir,maxno,hold_max) ;
    }

    fclose(fp) ;
  }

}
