/*************************************************************************
 * internet.c --- go another site					 *
 *	      by Samson Chen, Nov 25, 1994				 *
 *	      revisioned by Jones Tsai Aug 16, 1995			 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "dbf.h"
#include "global.h"


struct powernet_struc {
        char    *address;
	char	*port;
        char    *describe;
       	int     gid;  
        struct  powernet_struc *next;
        struct  powernet_struc *previous;
        };

static char	powernet_fetched=FALSE;	/*local flag for powernet list fetch*/
static int	powernet_items=0,  max_gid=0;
static struct	powernet_struc *gid_begin_point, *gid_end_point, *powernet_head;
                                                                
struct internet_struc {
        char    *address;
	char	*logname;
        char    *describe;
       	int     gid;  
        struct  internet_struc *next;
        struct  internet_struc *previous;
        };

static char	internet_fetched=FALSE;	/*local flag for internet list fetch*/
static int	internet_items=0;
static struct	internet_struc *igid_begin_point, *igid_end_point, *internet_head;
                                                                

/*
        fetch_internet_list --- fetch internet list to memory
*/      
fetch_internet_list(fd)
/*
        return:
                TRUE:   ok
                FALSE:  internet list not found
*/         
{
	char    list_filename[255];
        struct  internet_struc *internet_point, *new_space, *plink;
	int     items;
        FILE    *listfile;                                  
        char    line[255];
        char    *p;
        int     ret;
        int     n;
	char    maddr[40]; 
        char    mdescribe[50];
	char	mlogname[10];
	char	*check_p;



	if(debug_mode) printf("(internet.c)fetch Internet site list\n");

        sprintf(list_filename, "%s", INTERNET_LIST);
        if( !file_exist(list_filename) )        /*no group list file*/
        {
                display_msg(fd, NO_INTERNET_LIST);
                suspend(fd);
                return;
        }         

        internet_head=internet_point=(struct internet_struc *)NULL;
        igid_begin_point=igid_end_point=(struct internet_struc *)NULL;
        items=0; 

        /*--------------------------------------*/

        listfile=fopen(list_filename, "r");

        while( fgets(line, 127, listfile) )
        {

          /*take off comments*/
          for(n=0; n<strlen(line); n++)
                if( line[n]=='#' )
                {
                        line[n]=0;
                        break;
                }

          ret=strlen(line);
          if( ret<8 )
                continue;

          if(ret<126)
          {
                /*to avoid a possoble bug of next_blank*/
                line[ret+1]=0;
                line[ret+2]=0;
          }

          /*--------------------------------------------------*/ 

          /*--- get site address ---*/
          p=line;
          ret=next_params(p);
          p+=ret;
          ret=next_tab_space(p);
          if( ret==0 ) continue;
          p[ret]=0;
          nstrcpy(maddr, p, 40);

	  /* check port set up (ADDRESS.port) */
	  n=strlen(maddr)-1;
	  while(n>=0)
	  {
	    if(maddr[n]=='.')
	    {
	      check_p=maddr+n+1;
	      if( atoi(check_p)>256 )
		maddr[n]=' ';
	      break;
	    }
	    n--;
	  }

          p+=ret+1;
          ret=next_params(p);
          p+=ret;
          ret=next_tab_space(p);
          if( ret==0 ) continue;   

          /*--- get logname ---*/
          p[ret]=0;
          nstrcpy(mlogname, p, 10);

          p+=ret+1;
          ret=next_params(p);
          p+=ret;
          ret=next_tab_space(p);
          if( ret==0 ) continue;

          /*--- get site description */
          strip_nl(p);
          nstrcpy(mdescribe, p, 50);

          /*++++++++++++++++++++++++++++++*/
          /*+++ add to site link list +++*/
          /*++++++++++++++++++++++++++++++*/
          new_space=(struct internet_struc *)malloc(sizeof(struct internet_struc));

          if( internet_head==(struct internet_struc *)NULL )
          {
                internet_head=internet_point=new_space;
          }
          else
          {
                internet_point->next=new_space;
                plink=internet_point;
                internet_point=new_space;
                internet_point->previous=plink;
          }
                                         
          make_string(&(internet_point->address), maddr, 40);
          make_string(&(internet_point->logname), mlogname, 10);
          make_string(&(internet_point->describe), mdescribe, 50);
          internet_point->gid=++items;
          internet_point->next=(struct internet_struc *)NULL;

        }/*end while(fgets)*/

        fclose(listfile); 

        internet_point->next=internet_head;           /*circular link*/
        internet_head->previous=internet_point;

        internet_items=items;
        max_gid=internet_point->gid;

        igid_begin_point=igid_end_point=internet_head;

        internet_fetched=TRUE;      

}


/*
	Internet List Selection
*/
internet(fd)
/*
        return:
                TRUE:   select another site
                FALSE:  quit
*/         
int fd;
{
        char    inter_buf[IBUF_SIZE];
        char    *ibuf_head;
        char    line[255];
        char    txtbuf[80];
        char    answer[80];
        char    crlf[3];
        struct  internet_struc *gp;
        int     scr_size;       /*client's screen size*/
        int     scrcnt;
        int     rlen;
        int     ret;
        char    protocol;
        char    leave;
        char    forward_dir, same_buffer;
        int     sgid, igid_begin, igid_end;
        int     n;
        char    prompt_line[128];
        char    re_asm=FALSE;


        /*if first use this function, fetch all accepatable site name*/
        if( !internet_fetched )
        {
                fetch_internet_list(fd);

                /*fetching failed, skip selecting*/
                if( !internet_fetched )
                        return;
        }        
 
        /*get client's screen size*/
        scr_size=get_scrsize(fd);

        sprintf(crlf, "%c%c", 13, 10);

        forward_dir=TRUE;               /*assume forward reading*/

        /*site items is less than screen size*/
        if( internet_items<scr_size ) scr_size=internet_items;

        /*------------------------------------------------------------*/

        /***************/
        /*change prompt*/
        /***************/

        sprintf(prompt_line, "%s", LIST_MODE_TITLE);
        change_intr_prompt(fd, prompt_line);

        /***************/ 

        leave=FALSE;
        same_buffer=FALSE;
        do
        {
          scrcnt=0;
          inter_buf[0]=0;
          gp=igid_begin_point;
          igid_begin=gp->gid;

          if( forward_dir )
          {
                ibuf_head=inter_buf;
          }
          else
          {
                ibuf_head=inter_buf + (IBUF_SIZE-1);
                *ibuf_head=0;
          }

          /*---------------------*/
          /*assemble sites items*/
          /*---------------------*/
          if( !same_buffer || re_asm )
          {
            do
            {

              /*assemble single item*/
              line[0]=0;
              sprintf(txtbuf, "%d", gp->gid);
              strcat(line, txtbuf);
              strcat(line, crlf);
              strcat(line, gp->describe);
              strcat(line, crlf);

              /*-------------------------------------*/

              strcat(line, " ");
              strcat(line, crlf);


              if( forward_dir )
              {
                  strcat( ibuf_head, line );
              }
              else
              {
                  ret=strlen(line);
                  ibuf_head -= ret;

                  for(ret=0; ret<strlen(line); ret++)
                          ibuf_head[ret]=line[ret];
              }

              /*add counter*/
              scrcnt++;
              if( scrcnt>=scr_size )
                  break;

              /*stop at last item*/
              if( (gp->gid>=max_gid) && forward_dir )
                  break;

              /*get then 1st one, regenerate from first*/
              if( (gp->gid == 1) && !forward_dir )
              {
                  scrcnt=0;
                  inter_buf[0]=0;
                  igid_begin_point=gp;
                  igid_begin=gp->gid;
                  ibuf_head=inter_buf; 
                  forward_dir=TRUE;
                  continue;
              }

              /*move pointer*/
              if( forward_dir )
                  gp=gp->next;
              else
                  gp=gp->previous;

            }while(scrcnt<scr_size);

            igid_end_point=gp;
            igid_end=gp->gid;

            if( igid_end<igid_begin )
            {
                  /*swap*/
                  sgid=igid_end;
                  igid_end=igid_begin;
                  igid_begin=sgid;  
            }

            if(debug_mode) printf("igid_begin: %d, igid_end:%d\n", igid_begin, igid_end);
 
          }/*end if(same_buffer)*/

          /*---------------------------------------*/ 

          /*send reqest*/
          if( same_buffer && !re_asm )
            send_mpf(fd, "SAME_BUFFER", 11, INTRSEL);
          else
            send_mpf(fd, ibuf_head, strlen(ibuf_head), INTRSEL);

          read_mpf(fd, answer, &rlen, &protocol, FALSE);

          if( protocol != INTRSEL )
          {

                do_log(8, "%s protocol_stat_err with protocol code %d at internet", user_name, protocol);
                protocol_stat_err(fd);
          }

          answer[rlen]=0;
          strip_nl(answer);

          /*---------------------------------------*/ 

          same_buffer=FALSE;

          if(answer[0]=='q')
          {
                if( !forward_dir )
                  igid_begin_point=igid_end_point;

                /*quit interactive selecting*/
                leave=TRUE;
		
                continue;
          }

          if(answer[0]=='u')
          {
                if(debug_mode) printf("(internet.c) internet PageUp\n");

                if( forward_dir )
                        igid_begin_point=igid_begin_point->previous;
                else
                        igid_begin_point=igid_end_point->previous;

                forward_dir=FALSE;

                continue;
          }

          if(answer[0]=='d')
          {
                if(debug_mode) printf("(internet.c) internet PageDown\n");

                /*PageDown*/
                if( forward_dir )
                        igid_begin_point=igid_end_point->next;
                else                
                        igid_begin_point=igid_begin_point->next;

                forward_dir=TRUE;

                continue;
          }

          /*----------------------------------------------------------*/  

          sgid=atoi(answer);
          if( sgid>0 )
          {
                gp=igid_begin_point;

                for(n=0; n<internet_items; n++, gp=gp->next)
                {
                  if( gp->gid == sgid )
                  {
                          go_another_site(fd, gp->address , gp->logname, gp->describe);
			  return;

                  }/*end if*/
                }/*end for*/

          }/*end if(sgid)*/

        }while(!leave); 

	if(answer[0]!='q') 
	  return TRUE;
	else 
	  return FALSE;
}
/*end of internet*/


/*
	go_another_site
*/
go_another_site(fd,site,logname,describe)

	int fd;
	char *site;
	char *logname;
	char *describe;
{
	char crlf[3];
	char mbuf[80];

	sprintf(crlf, "%c%c", 0xd, 0xa);

	do_log(2, "%s go INTERNET to %s (%s)", user_name, describe, site);
	
	sprintf(mbuf, "%s", describe);
	update_act(12,mbuf);
	sprintf(mbuf, "%s%s%s%s", site, crlf, logname, crlf);
	send_mpf(fd, mbuf, strlen(mbuf), INTERNET);

}
/*end of go_another_site*/


/*
        fetch_powernet_list --- fetch powernet list to memory
*/      
fetch_powernet_list(fd)
/*
        return:
                TRUE:   ok
                FALSE:  powernet list not found
*/         
{
	char    list_filename[255];
        struct  powernet_struc *powernet_point, *new_space, *plink;
	int     items;
        FILE    *listfile;                                  
        char    line[255];
        char    *p;
        int     ret;
        int     n;
	char    maddr[40]; 
        char    mdescribe[50];
	char	mport[6];



	if(debug_mode) printf("(internet.c)fetch PowerNet site list\n");

        sprintf(list_filename, "%s", POWERNET_LIST);
        if( !file_exist(list_filename) )        /*no group list file*/
        {
                display_msg(fd, NO_POWERNET_LIST);
                suspend(fd);
                return;
        }         

        powernet_head=powernet_point=(struct powernet_struc *)NULL;
        gid_begin_point=gid_end_point=(struct powernet_struc *)NULL;
        items=0; 

        /*--------------------------------------*/

        listfile=fopen(list_filename, "r");

        while( fgets(line, 127, listfile) )
        {

          /*take off comments*/
          for(n=0; n<strlen(line); n++)
                if( line[n]=='#' )
                {
                        line[n]=0;
                        break;
                }

          ret=strlen(line);
          if( ret<8 )
                continue;

          if(ret<126)
          {
                /*to avoid a possoble bug of next_blank*/
                line[ret+1]=0;
                line[ret+2]=0;
          }

          /*--------------------------------------------------*/ 

          /*--- get site address ---*/
          p=line;
          ret=next_params(p);
          p+=ret;
          ret=next_tab_space(p);
          if( ret==0 ) continue;
          p[ret]=0;
          nstrcpy(maddr, p, 40);

          p+=ret+1;
          ret=next_params(p);
          p+=ret;
          ret=next_tab_space(p);
          if( ret==0 ) continue;   

          /*--- get port ---*/
          p[ret]=0;
          nstrcpy(mport, p, 6);

          p+=ret+1;
          ret=next_params(p);
          p+=ret;
          ret=next_tab_space(p);
          if( ret==0 ) continue;

          /*--- get site description */
          strip_nl(p);
          nstrcpy(mdescribe, p, 50);

          /*++++++++++++++++++++++++++++++*/
          /*+++ add to site link list +++*/
          /*++++++++++++++++++++++++++++++*/
          new_space=(struct powernet_struc *)malloc(sizeof(struct powernet_struc));

          if( powernet_head==(struct powernet_struc *)NULL )
          {
                powernet_head=powernet_point=new_space;
          }
          else
          {
                powernet_point->next=new_space;
                plink=powernet_point;
                powernet_point=new_space;
                powernet_point->previous=plink;
          }
                                         
          make_string(&(powernet_point->address), maddr, 40);
          make_string(&(powernet_point->port), mport, 6);
          make_string(&(powernet_point->describe), mdescribe, 50);
          powernet_point->gid=++items;
          powernet_point->next=(struct powernet_struc *)NULL;

        }/*end while(fgets)*/

        fclose(listfile); 

        powernet_point->next=powernet_head;           /*circular link*/
        powernet_head->previous=powernet_point;

        powernet_items=items;
        max_gid=powernet_point->gid;

        gid_begin_point=gid_end_point=powernet_head;

        powernet_fetched=TRUE;      

}


/*
	PowerNET List Selection
*/
power_net(fd)
int fd;
/*
        return:
                TRUE:   select another site
                FALSE:  quit
*/         
{
        char    inter_buf[IBUF_SIZE];
        char    *ibuf_head;
        char    line[255];
        char    txtbuf[80];
        char    answer[80];
        char    crlf[3];
        struct  powernet_struc *gp;
        int     scr_size;       /*client's screen size*/
        int     scrcnt;
        int     rlen;
        int     ret;
        char    protocol;
        char    leave;
        char    forward_dir, same_buffer;
        int     sgid, gid_begin, gid_end;
        int     n;
        char    prompt_line[128];
        char    re_asm=FALSE;


        /*if first use this function, fetch all accepatable site name*/
        if( !powernet_fetched )
        {
                fetch_powernet_list(fd);

                /*fetching failed, skip selecting*/
                if( !powernet_fetched )
                        return;
        }        
 
        /*get client's screen size*/
        scr_size=get_scrsize(fd);

        sprintf(crlf, "%c%c", 13, 10);

        forward_dir=TRUE;               /*assume forward reading*/

        /*site items is less than screen size*/
        if( powernet_items<scr_size ) scr_size=powernet_items;

        /*------------------------------------------------------------*/

        /***************/
        /*change prompt*/
        /***************/

        sprintf(prompt_line, "%s", LIST_MODE_TITLE);
        change_intr_prompt(fd, prompt_line);

        /***************/ 

        leave=FALSE;
        same_buffer=FALSE;
        do
        {
          scrcnt=0;
          inter_buf[0]=0;
          gp=gid_begin_point;
          gid_begin=gp->gid;

          if( forward_dir )
          {
                ibuf_head=inter_buf;
          }
          else
          {
                ibuf_head=inter_buf + (IBUF_SIZE-1);
                *ibuf_head=0;
          }

          /*---------------------*/
          /*assemble sites items*/
          /*---------------------*/
          if( !same_buffer || re_asm )
          {
            do
            {

              /*assemble single item*/
              line[0]=0;
              sprintf(txtbuf, "%d", gp->gid);
              strcat(line, txtbuf);
              strcat(line, crlf);
              strcat(line, gp->describe);
              strcat(line, crlf);

              /*-------------------------------------*/

              strcat(line, " ");
              strcat(line, crlf);


              if( forward_dir )
              {
                  strcat( ibuf_head, line );
              }
              else
              {
                  ret=strlen(line);
                  ibuf_head -= ret;

                  for(ret=0; ret<strlen(line); ret++)
                          ibuf_head[ret]=line[ret];
              }

              /*add counter*/
              scrcnt++;
              if( scrcnt>=scr_size )
                  break;

              /*stop at last item*/
              if( (gp->gid>=max_gid) && forward_dir )
                  break;

              /*get then 1st one, regenerate from first*/
              if( (gp->gid == 1) && !forward_dir )
              {
                  scrcnt=0;
                  inter_buf[0]=0;
                  gid_begin_point=gp;
                  gid_begin=gp->gid;
                  ibuf_head=inter_buf; 
                  forward_dir=TRUE;
                  continue;
              }

              /*move pointer*/
              if( forward_dir )
                  gp=gp->next;
              else
                  gp=gp->previous;

            }while(scrcnt<scr_size);

            gid_end_point=gp;
            gid_end=gp->gid;

            if( gid_end<gid_begin )
            {
                  /*swap*/
                  sgid=gid_end;
                  gid_end=gid_begin;
                  gid_begin=sgid;  
            }

            if(debug_mode) printf("gid_begin: %d, gid_end:%d\n", gid_begin, gid_end);
 
          }/*end if(same_buffer)*/

          /*---------------------------------------*/ 

          /*send reqest*/
          if( same_buffer && !re_asm )
            send_mpf(fd, "SAME_BUFFER", 11, INTRSEL);
          else
            send_mpf(fd, ibuf_head, strlen(ibuf_head), INTRSEL);

          read_mpf(fd, answer, &rlen, &protocol, FALSE);

          if( protocol != INTRSEL )
          {

                do_log(8, "%s protocol_stat_err with protocol code %d at power_net", user_name, protocol);
                protocol_stat_err(fd);
          }

          answer[rlen]=0;
          strip_nl(answer);

          /*---------------------------------------*/ 

          same_buffer=FALSE;

          if(answer[0]=='q')
          {
                if( !forward_dir )
                  gid_begin_point=gid_end_point;

                /*quit interactive selecting*/
                leave=TRUE;
                continue;
          }

          if(answer[0]=='u')
          {
                if(debug_mode) printf("(internet.c)PageUp\n");

                if( forward_dir )
                        gid_begin_point=gid_begin_point->previous;
                else
                        gid_begin_point=gid_end_point->previous;

                forward_dir=FALSE;

                continue;
          }

          if(answer[0]=='d')
          {
                if(debug_mode) printf("(internet.c)PageDown\n");

                /*PageDown*/
                if( forward_dir )
                        gid_begin_point=gid_end_point->next;
                else                
                        gid_begin_point=gid_begin_point->next;

                forward_dir=TRUE;

                continue;
          }

          /*----------------------------------------------------------*/  

          sgid=atoi(answer);
          if( sgid>0 )
          {
                gp=gid_begin_point;

                for(n=0; n<powernet_items; n++, gp=gp->next)
                {
                  if( gp->gid == sgid )
                  {
                          go_power_net(fd, gp->address , gp->port, gp->describe);
			  return;

                  }/*end if*/
                }/*end for*/

          }/*end if(sgid)*/

        }while(!leave); 

	if(answer[0]!='q') 
	  return TRUE;
	else 
	  return FALSE;

/*test*/
/*go_power_net(fd, "140.119.152.114", "6203"); */

}
/*end of power_net*/



/*
	go PowerNET
*/
go_power_net(fd, site, port, describe)
int fd;
char *site;
char *port;
char *describe;
{
	char crlf[3];
	char powernet[80];

	if(toggles>0)
	{
	  display_msg(fd, TAG_YET_DOWNLOAD);
	  if( yes_no(fd, DOWNLOAD_NOW)=='y' )
	    download(fd);
	}

	sprintf(crlf, "%c%c", 0xd, 0xa);

	do_log(2, "%s go PowerNet to %s (%s)", user_name, describe, site);

	sprintf(powernet, "%s PowerBBS Site", describe);
	update_act(12,powernet);
	sprintf(powernet, "%s %s%sPowerBBS%s", site, port, crlf, crlf);
	send_mpf(fd, powernet, strlen(powernet), INTERNET);
}
/*end of go_power_net*/



/*
	hold_network --- hold until new network data-in
	(not in used now)
*/
hold_network(fd)
	int fd;
{
	fd_set	rset;
	struct timeval	timeout;
	int maxfd;

	while(TRUE)
	{
	  /*set mutiplex I/O check bit*/
	  maxfd=fd + 1;
	  FD_ZERO(&rset);
	  FD_SET(fd, &rset);
	  timeout.tv_sec=10;
	  timeout.tv_usec=1;

	  if( select(maxfd, &rset, NULL, NULL, &timeout) <0 )
		reject(fd, 12);

	  if( FD_ISSET(fd, &rset) )
		return;
	}
}
