/*************************************************************************
 * listuser.c --- list users and SysOp functions			 *
 *	      by Samson Chen, Apr 9, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"
#include "dbf.h"

static char rcsid[]="$Id: listuser.c,v 1.34 1996/02/10 07:00:40 pbbs Exp pbbs $";


char scrbuf[9120];
char bigbuf[MAX_BUF];
char inter_buf[IBUF_SIZE];


/*
	list_users --- (as the name)
*/
list_users(fd)
	int fd;
{
      int list_mode;
      char answer[80];
      char line[300];
      char info[25];
      int n;
      int list_uid;
      struct udb rec;
      int list_range_down;
      int list_range_up;
      int scr_size;	/*client's screen size*/
      int scr_cnt;
      int rlen;
      char protocol;
      char leave;
      char no_more;
      int utf;
      struct putmp purec;
      time_t current_time;
      int sysop_talk;
      int sig_rec;
      char crlf[3];
      int bulletin_file;
      char pn[80];

      do
      {
	/***************/
	/*change prompt*/
	/***************/

	sprintf(line, "%s", LIST_MODE_TITLE);
	change_intr_prompt(fd, line);

	/*************************/
	/*assemble INTRSEL buffer*/
	/*************************/

	sprintf(crlf, "%c%c", 13, 10);

	inter_buf[0]=0;
	strcpy(inter_buf, "1!1");
	strcat(inter_buf, crlf);
	strcat(inter_buf, LIST_MODE_1);
	strcat(inter_buf, crlf);
	strcat(inter_buf, " ");
	strcat(inter_buf, crlf);

	strcat(inter_buf, "2");
	strcat(inter_buf, crlf);
	strcat(inter_buf, LIST_MODE_2);
	strcat(inter_buf, crlf);
	strcat(inter_buf, " ");
	strcat(inter_buf, crlf);

	strcat(inter_buf, "3");
	strcat(inter_buf, crlf);
	strcat(inter_buf, LIST_MODE_3);
	strcat(inter_buf, crlf);
	strcat(inter_buf, " ");
	strcat(inter_buf, crlf);

	strcat(inter_buf, "4");
	strcat(inter_buf, crlf);
	strcat(inter_buf, LIST_MODE_4);
	strcat(inter_buf, crlf);
	strcat(inter_buf, " ");
	strcat(inter_buf, crlf);

	if( system_operator || group_moderator )
	{
	  strcat(inter_buf, "5");
	  strcat(inter_buf, crlf);
	  strcat(inter_buf, LIST_MODE_5);
	  strcat(inter_buf, crlf);
	  strcat(inter_buf, " ");
	  strcat(inter_buf, crlf);
	}

	if( system_operator || (user_level>=CO_SYSOP_LEVEL) )
	{
	  strcat(inter_buf, "6");
	  strcat(inter_buf, crlf);
	  strcat(inter_buf, LIST_MODE_6);
	  strcat(inter_buf, crlf);
	  strcat(inter_buf, " ");
	  strcat(inter_buf, crlf);
	}

	if( system_operator )
	{
	  strcat(inter_buf, "7");
	  strcat(inter_buf, crlf);
	  strcat(inter_buf, LIST_MODE_7);
	  strcat(inter_buf, crlf);
	  strcat(inter_buf, " ");
	  strcat(inter_buf, crlf);

	  strcat(inter_buf, "8");
	  strcat(inter_buf, crlf);
	  strcat(inter_buf, LIST_MODE_8);
	  strcat(inter_buf, crlf);
	  strcat(inter_buf, " ");
	  strcat(inter_buf, crlf);

	  strcat(inter_buf, "9");
	  strcat(inter_buf, crlf);
	  strcat(inter_buf, LIST_MODE_9);
	  strcat(inter_buf, crlf);
	  strcat(inter_buf, " ");
	  strcat(inter_buf, crlf);

	  strcat(inter_buf, "10");
	  strcat(inter_buf, crlf);
	  strcat(inter_buf, LIST_MODE_10);
	  strcat(inter_buf, crlf);
	  strcat(inter_buf, " ");
	  strcat(inter_buf, crlf);

	  strcat(inter_buf, "11");
	  strcat(inter_buf, crlf);
	  strcat(inter_buf, LIST_MODE_11);
	  strcat(inter_buf, crlf);
	  strcat(inter_buf, " ");
	  strcat(inter_buf, crlf);

	  strcat(inter_buf, "12");
	  strcat(inter_buf, crlf);
	  strcat(inter_buf, LIST_MODE_12);
	  strcat(inter_buf, crlf);
	  strcat(inter_buf, " ");
	  strcat(inter_buf, crlf);
	}

	/*send reqest*/
	send_mpf(fd, inter_buf, strlen(inter_buf), INTRSEL);
	do
	{
	  read_mpf(fd, answer, &rlen, &protocol, FALSE);
	  if( protocol != INTRSEL )
	  {
		do_log(8, "%s protocol_stat_err with protocol code %d at list_user", user_name, protocol);
		protocol_stat_err(fd);
	  }

	  answer[rlen]=0;
	  strip_nl(answer);

	  if(answer[0]=='q')
	    break;

	  list_mode=atoi(answer);

	  /*check list mode permission*/
	  if(list_mode>0)
	  {
	    if( system_operator )		/*SYSOP*/
	    {
	      if(list_mode<=12)
		break;
	    }
	    else if( group_moderator )		/*MODERATOR*/
	    {
	      if(list_mode<=5)
		break;
	    }
	    else if(user_level>=CO_SYSOP_LEVEL) /*CO-SYSOP*/
	    {
	      if( (list_mode<=6) && (list_mode!=5) )
		break;
	    }
	    else				/*General USERS*/
	    {
	      if(list_mode<=4)
		break;
	    }
	  }/*end if(list_mode>0)*/

	  send_mpf(fd, "SAME_BUFFER", 11, INTRSEL);

	}while(TRUE);

	if( answer[0]=='q' )
	  break;

	/***********************************************************/

	display_msg(fd, "{#c#}");

	switch( list_mode )
	{

	/***********************************************************/

	case 1: /*specific user*/

		if(debug_mode) printf("(listuser.c)case 1\n");

		asking(fd, LIST_WHO, answer, 20);
		process_user_name(answer);

		/*************/
		/*search user*/
		/*************/

		if( system_operator )
		{
		  list_uid=atoi(answer);	/*accept user_id input*/

		  if( list_uid>=get_total_user_recs() )
			list_uid=0;	/*input too large*/
		}
		else
			list_uid=0;

		if( list_uid<=0 )
			list_uid=get_user_id(answer);

		/*******************/
		/*user found or not*/
		/*******************/
		if(list_uid==0)
		{
			display_msg(fd, NO_SUCH_USER);
			suspend(fd);
			break;;
		}

		/*****************/
		/*get user record*/
		/*****************/
		get_user_data(&rec, list_uid);

		/****************************/
		/*if account disabled or not*/
		/****************************/
		if( rec.delete_mark=='X' || rec.delete_mark=='*' )
		{
			display_msg(fd, NO_SUCH_USER);
			suspend(fd);
			break;
		}

		sprintf(info,"%s %s",LIST_MODE_1, answer);
		update_act(13,info);

		show_user_data(fd, list_uid, &rec);
		suspend(fd);

		break;

	/***********************************************************/

	case 2: /*all*/

		if(debug_mode) printf("(listuser.c)case 2\n");

		sprintf(info,"%s",LIST_MODE_2);
		update_act(13,info);

		if( system_operator )
		{
		  asking(fd, LIST_ALL_RANGE_DOWN, answer, 10);
		  list_range_down=atoi(answer);
		  asking(fd, LIST_ALL_RANGE_UP, answer, 10);
		  list_range_up=atoi(answer);

		  if(list_range_down>list_range_up) /*down>up ???*/
		  {
			list_range_down=-1;
			list_range_up=-1;
		  }

		  if(list_range_down==list_range_up && list_range_down==0)
		  {
			list_range_down=-1;
			list_range_up=-1;
		  }

		}

		scr_size=get_scrsize(fd);
		display_msg(fd, "\n");
		leave=FALSE;
		no_more=TRUE;
		scr_cnt=0;
		n=0;
		scrbuf[0]=0;
		do
		{
			n++;

			if( !get_user_data(&rec, n) )
			{
				leave=TRUE;
				continue;
			}

			if( rec.delete_mark=='X' )
				continue;

			if( system_operator )
			{
			  if( list_range_down!=-1 )
			    if( rec.level<list_range_down )
			      continue;

			  if( list_range_up!=-1 )
			    if( rec.level>list_range_up )
			      continue;
			}

			if( !system_operator )
			  sprintf(line, "%c %5d %-20s %-39s\n", rec.delete_mark, n, rec.bbs_name, rec.email);
			else
			  sprintf(line, "%c %5d %-20s %-10s %3d %-29s\n", rec.delete_mark, n, rec.bbs_name, rec.real_name, rec.level, rec.email);

			strcat(scrbuf, line);
			no_more=FALSE;

			scr_cnt++;
			if( scr_cnt>(scr_size+1) )
			{
				display_msg(fd, scrbuf);
				display_msg(fd, "\n");
				asking(fd, IF_CONTINUE, answer, 2);
				if( answer[0]=='n' || answer[0]=='N' )
				{
					leave=TRUE;
					no_more=TRUE;
					continue;
				}

				scr_cnt=0;
				scrbuf[0]=0;
				no_more=TRUE;
			}

		} while( !leave );

		if(!no_more)
		{
			display_msg(fd, "{#c#}");
			display_msg(fd, scrbuf);
			display_msg(fd, "\n");
			suspend(fd);
		}

		break;

	/***********************************************************/

	case 3: /*on-line*/

		if(debug_mode) printf("(listuser.c)case 3\n");

		sprintf(info,"%s",LIST_MODE_3);
		update_act(13,info);
   
		scr_size=get_scrsize(fd);
		scr_cnt=0;
		n=0;
		leave=FALSE;
		display_msg(fd, "\n");
		current_time=time((time_t*)NULL);

		for(sig_rec=0; sig_rec<(flength(ON_LINE_USER)/sizeof(struct putmp)); sig_rec++)
		{
		  get_putmp(&purec, sig_rec);

		  if( purec.active )
		  {
		    if( ((purec.last_action+purec.max_idle)<current_time) && (purec.max_idle!=0) )
		      continue;

		    if( !get_user_data(&rec, purec.uid) )
		      continue;

		    scr_cnt++;
		    n++;

		    descript_stat(info, 25, purec.act_stat, purec.act_info);

		    if( !system_operator )
		      sprintf(line, "%3d %-18s %-23s %-25s\n", n, rec.bbs_name, purec.from, info);
		    else
		      sprintf(line, "%3d %5d %-18s %-23s %-24s\n", n, purec.uid, rec.bbs_name, purec.from, info);

		    display_msg(fd, line);

		    if( scr_cnt>(scr_size+1) )
		    {
			    asking(fd, IF_CONTINUE, answer, 2);
			    if( answer[0]=='n' || answer[0]=='N' )
			      break;

			    scr_cnt=0;
		    }
		  }/*end if(purec.active)*/
		}/*end for*/

		display_msg(fd, "\n");
		suspend(fd);

		break;

	/***********************************************************/

	case 4: /*SysOp*/

		if(debug_mode) printf("(listuser.c)case 4\n");

                sprintf(info,"%s",LIST_MODE_4);
                update_act(13,info);          

		leave=FALSE;
		n=0;
		display_msg(fd, "\n");
		do
		{
			n++;

			if( !get_user_data(&rec, n) )
			{
				leave=TRUE;
				continue;
			}

			if( rec.delete_mark=='X' )
				continue;

			if( rec.level<SYSOP_LEVEL )
				continue;

			if(debug_mode) printf("(listuser.c)get SysOp #%d\n", n);

			sprintf(line, "# %-20s %-20s %-35s\n", rec.bbs_name, rec.real_name, rec.email);
			display_msg(fd, line);

		} while( !leave );

		display_msg(fd, "\n");
		suspend(fd);
		break;

	/***********************************************************/

	/*moderator-functions*/
	case 5: /*edit mail rules*/

		if(debug_mode) printf("(listuser.c)case 5\n");

		if( (!system_operator) && (!group_moderator) )
			break;

		/*------------------------------------*/

		if( !strcmp(current_group, "mbox") )
		{
			display_msg(fd, CANNOT_EDIT_RULE);
			suspend(fd);
			break;
		}

		sprintf(bigbuf, "%s%s\n", EDIT_RULE, group_areaname);
		display_msg(fd, bigbuf);
		suspend(fd);

                do_log(3, "%s edit %s group rules", user_name, current_group);

	        sprintf(info,"%s %s",LIST_MODE_5, current_group);
                update_act(13,info);          

		sprintf(line, "%s/%s/%s", MAIL_PATH, current_group, RULES);

		if( file_exist(line) )
		{

		  n=flength(line);
		  if( n>(MAX_BUF-1024) )
			n=MAX_BUF-1024;

		  bulletin_file=open(line, O_RDONLY);
		  read(bulletin_file, bigbuf, n);
		  close(bulletin_file);
		  bigbuf[n]=0;
		}
		else
		  bigbuf[0]=0;

		send_mpf(fd, bigbuf, strlen(bigbuf), MAKEPOST);

		idling=IDLE_TIME * POST_FACTOR;/*extent editing time*/
		read_mpf(fd, bigbuf, &rlen, &protocol, FALSE);
		idling=IDLE_TIME;		/*restore idling time*/

		if( protocol==STOPPOST )
		{
			do_log(3, "%s abort edit mail rules", user_name);
			break;
		}
		if( protocol!=MAKEPOST)
		{
			do_log(8, "%s protocol_stat_err with protocol code %d at edit_mail_rules", user_name, protocol);
			protocol_stat_err(fd);
		}

		bigbuf[rlen]=0;

		if( strlen(bigbuf)>2 )
		{
			bulletin_file=open(line,  O_WRONLY|O_CREAT|O_TRUNC, S_IWUSR | S_IRUSR);
			write(bulletin_file, bigbuf, rlen);
			close(bulletin_file);
		}
		else	/*unlink area rule file*/
		{
			if( file_exist(line) )
			  unlink(line);
		}

		break;

	/***********************************************************/

	/*co-sysop-functions*/
	case 6: /*edit bulletin board*/

		if(debug_mode) printf("(listuser.c)case 6\n");

		if( user_level<CO_SYSOP_LEVEL )
			break;

		/*------------------------------------*/

		asking(fd, EDIT_BULLETIN, answer, 50);
		strip_nl(answer);
		split_filename(answer, pn);

		if( strlen(pn) <=0 )
			break;

		split_path(answer, bstack);

	        do_log(3, "%s edit bulletin board : %s%s", user_name, bstack, pn);

		sprintf(info,"%s %s%s",LIST_MODE_6, bstack, pn);
                update_act(13,info);          

		sprintf(line, "%s/%s%s", BULLETIN_PATH, bstack, pn);
		if (debug_mode) printf ("(listuser.c)edit bulletin board : %s\n",line);

		if( file_exist(line) )
		{
		    n=flength(line);
		    if( n>(MAX_BUF-1024) )
			n=MAX_BUF-1024;

		    bulletin_file=open(line, O_RDONLY);
		    read(bulletin_file, bigbuf, n);
		    close(bulletin_file);
		    bigbuf[n]=0;
		}
		else
		    bigbuf[0]=0;

		send_mpf(fd, bigbuf, strlen(bigbuf), MAKEPOST);

		idling=IDLE_TIME * POST_FACTOR;/*extent editing time*/
		read_mpf(fd, bigbuf, &rlen, &protocol, FALSE);
		idling=IDLE_TIME;		/*restore idling time*/

		if( protocol==STOPPOST )
		{
			do_log(3, "%s abort edit bulletin", user_name);
			break;
		}
		if( protocol!=MAKEPOST)
		{
			do_log(8, "%s protocol_stat_err with protocol code %d at edit_bulletin", user_name, protocol);
			protocol_stat_err(fd);
		}

		bigbuf[rlen]=0;

		if( strlen(bigbuf)>2 )
		{
		  bulletin_file=open(line,  O_WRONLY|O_CREAT|O_TRUNC, S_IWUSR | S_IRUSR);
		  write(bulletin_file, bigbuf, rlen);
		  close(bulletin_file);
		}
		else	/*unlink bulletin file*/
		{
			if( file_exist(line) )
			  unlink(line);
		}

		break;

	/***********************************************************/

	/*function greater than 6 are SysOp functions*/
	case 7: /*SysOp send signal to all users*/

		if(debug_mode) printf("(listuser.c)case 7\n");

		if( !system_operator )
			break;

		/*------------------------------------*/

		sprintf(line, "%s/talk.%d", TALK_BUFFER, user_uid);

		sysop_talk=open(line, O_WRONLY | O_CREAT | O_TRUNC, S_IWUSR | S_IRUSR);

		sprintf(answer, "\nfrom %s...", user_name);
		write(sysop_talk, answer, strlen(answer));

		write(sysop_talk, SYSOP_TALK, strlen(SYSOP_TALK));
		sprintf(answer, "%c%c%c", 7, 13, 10);
		write(sysop_talk, answer, 3);	/*a BEEP*/

		/*get messages from SYSOP*/
		display_msg(fd, TALK_WHAT);
		do
		{
		  asking(fd, ">", answer, 80);
		  strip_nl(answer);
		  if( strlen(answer)==1 && answer[0]=='.' )
			break;
		  write(sysop_talk, answer, strlen(answer) );
		  write(sysop_talk, crlf, strlen(crlf));
		} while(1);
		close(sysop_talk);

		if( yes_no(fd, CONFIRM_MSG)!='y' )
			break;

	        do_log(3, "%s send signal to all users", user_name);

		sprintf(info,"%s",LIST_MODE_7);
                update_act(13,info);          

		for(sig_rec=0; sig_rec<(flength(ON_LINE_USER)/sizeof(struct putmp)); sig_rec++)
		{
			get_putmp(&purec, sig_rec);

			if( purec.active )
			{
			  switch(purec.act_stat)
			  {	
			  case 3:
			  case 7:
			  case 8:
			  case 9:
			  case 10:
			  case 11:
			  case 12:
				/* cannot page */
				get_user_data(&rec, purec.uid);
				descript_stat(info, 25, purec.act_stat, purec.act_info);
				sprintf(line, "%s%s%s\n", rec.bbs_name, CANNOT_PAGE, info);
				display_msg(fd, line);
				break;
			  default:
				purec.page_mode=0;
				purec.page_uid=user_uid;
				set_putmp(&purec, sig_rec);
				kill(purec.pid, SIGUSR1);
				break;
			  }
			}
		}/*end for*/

		break;

	/***********************************************************/

	case 8: /*adjust user level*/

		if(debug_mode) printf("(listuser.c)case 8\n");

		if( !system_operator )
			break;

		/*------------------------------------*/
		sprintf(info,"%s",LIST_MODE_8);
                update_act(13,info);          

		asking(fd, SYSOP_ASK_WHO, answer, 20);
		process_user_name(answer);

		/*************/
		/*search user*/
		/*************/

		list_uid=atoi(answer);	/*accept user_id input*/

		if( list_uid>=get_total_user_recs() )
			list_uid=0;	/*input too large*/

		if( list_uid<=0 )
			list_uid=get_user_id(answer);

		change_user_level(fd, list_uid);

		break;

	/***********************************************************/

	case 9: /*delete user*/

		if(debug_mode) printf("(listuser.c)case 9\n");

		if( !system_operator )
			break;

		/*------------------------------------*/
		sprintf(info,"%s",LIST_MODE_9);
                update_act(13,info);          

		asking(fd, SYSOP_ASK_WHO, answer, 20);
		process_user_name(answer);

		/*************/
		/*search user*/
		/*************/

		list_uid=atoi(answer);	/*accept user_id input*/

		if( list_uid>=get_total_user_recs() )
			list_uid=0;	/*input too large*/

		if( list_uid<=0 )
			list_uid=get_user_id(answer);

		/*******************/
		/*user found or not*/
		/*******************/
		if(list_uid==0)
		{
			display_msg(fd, NO_SUCH_USER);
			suspend(fd);
			break;
		}

		/*****************/
		/*get user record*/
		/*****************/
		get_user_data(&rec, list_uid);

		/****************************/
		/*if account disabled or not*/
		/****************************/
		if( rec.delete_mark=='X' || rec.delete_mark=='*' )
		{
			display_msg(fd, NO_SUCH_USER);
			suspend(fd);
			break;
		}

		show_user_data(fd, list_uid, &rec);

		rec.delete_mark='X';
		if( yes_no(fd, CONFIRM_MSG)=='y' )
			set_user_data(&rec, list_uid);

		break;

	/***********************************************************/

	case 10:	/*remove user password*/

		if(debug_mode) printf("(listuser.c)case 10\n");

		if( !system_operator )
			break;

		/*------------------------------------*/
		sprintf(info,"%s",LIST_MODE_10);
                update_act(13,info);          

		asking(fd, SYSOP_ASK_WHO, answer, 20);
		process_user_name(answer);

		/*************/
		/*search user*/
		/*************/

		list_uid=atoi(answer);	/*accept user_id input*/

		if( list_uid>=get_total_user_recs() )
			list_uid=0;	/*input too large*/

		if( list_uid<=0 )
			list_uid=get_user_id(answer);

		/*******************/
		/*user found or not*/
		/*******************/
		if(list_uid==0)
		{
			display_msg(fd, NO_SUCH_USER);
			suspend(fd);
			break;
		}

		/*****************/
		/*get user record*/
		/*****************/
		get_user_data(&rec, list_uid);

		/****************************/
		/*if account disabled or not*/
		/****************************/
		if( rec.delete_mark=='X' || rec.delete_mark=='*' )
		{
			display_msg(fd, NO_SUCH_USER);
			suspend(fd);
			break;
		}

		show_user_data(fd, list_uid, &rec);

		if( yes_no(fd, CONFIRM_MSG)=='y' )
		{
			strcpy(rec.password, "MagicPower");
			set_user_data(&rec, list_uid);
		}

		break;

	/***********************************************************/

	case 11:	/*view new users*/

		if(debug_mode) printf("(listuser.c)case 11\n");

		if( !system_operator )
			break;

		/*------------------------------------*/
		sprintf(info,"%s",LIST_MODE_11);
                update_act(13,info);          

		leave=FALSE;
		n=0;
		do
		{
		  n++;

		  if( !get_user_data(&rec, n) )
		  {
			leave=TRUE;
			continue;
		  }

		  if( rec.delete_mark!='N' )    /*new user mark*/
			continue;

		  rec.delete_mark=' ';
		  set_user_data(&rec, n);

		  display_msg(fd, "{#c#}");
		  show_user_data(fd, n, &rec);
		  asking(fd, LIST_VIEW_NEWUSER, answer, 10);

		  if( answer[0]==0 || answer[0]==10 || answer[0]==13 )
			continue;

		  switch(tolower(answer[0]))
		  {
		  case 'd':
			if( yes_no(fd, CONFIRM_MSG)=='y' )
			{
			  rec.delete_mark='X';
			  set_user_data(&rec, n);
			}
			break;

		  case 'l':
			asking(fd, SYSOP_ASK_NEW_LEVEL, answer, 10);
			if( answer[0]==0 || answer[0]==13 || answer[0]==10 )
				break;

			if( yes_no(fd, CONFIRM_MSG)=='y' )
			{
				rec.level=atoi(answer);
				display_msg(fd, "\n");
				sprintf(line, "%s%d\n", CP_LEVEL, rec.level);
				display_msg(fd, line);
				display_msg(fd, "\n");
				set_user_data(&rec, n);
			}

			break;

		  case 'q':
			leave=TRUE;
			break;
		  }

		}while(!leave);

		break;

	/***********************************************************/

	case 12:	/*kick user out*/

		if(debug_mode) printf("(listuser.c)case 11\n");

		if( !system_operator )
			break;

		/*------------------------------------*/
		sprintf(info,"%s",LIST_MODE_12);
                update_act(13,info);          

		write_user(fd, 1);

		break;

	/***********************************************************/

	}/*end switch*/

      }while(TRUE);
}
/*end of list_users*/



/*
	display user's data
	control the detail by the permission from user level
*/
show_user_data(fd, list_uid, rec)
	int fd;
	int list_uid;
	struct udb *rec;
{
	char line[300];

	/******/
	/*list*/
	/******/
	display_msg(fd, "\n");

	sprintf(line, "%s%s\n", CP_BBS_NAME, rec->bbs_name);
	display_msg(fd, line);

	if( system_operator || list_uid==user_uid )
	{
		sprintf(line, "%s%s\n", CP_REAL_NAME, rec->real_name);
		display_msg(fd, line);
	}

	sprintf(line, "%s%s\n", CP_EMAIL_ADD, rec->email);
	display_msg(fd, line);

	if( system_operator || list_uid==user_uid ) /*for SysOp,own-user ONLY*/
	{
		/*
		sprintf(line, "%s%s\n", CP_TERM, rec->term);
		display_msg(fd, line);
		*/
		sprintf(line, "%s%s\n", CP_ADDRESS, rec->address);
		display_msg(fd, line);
		sprintf(line, "%s%s\n", CP_PHONE, rec->phone);
		display_msg(fd, line);
		sprintf(line, "%s%c\n", CP_SEX, rec->sex);
		display_msg(fd, line);
		sprintf(line, "%s%d\n", CP_LEVEL, rec->level);
		display_msg(fd, line);
	}

	sprintf(line, "%s%d\n",CP_TOTAL_LOGIN,rec->total_login);
	display_msg(fd, line);
	sprintf(line, "%s%d\n",CP_TOTAL_POST,rec->total_post);
	display_msg(fd, line);
	sprintf(line, "%s%s\n", CP_LAST_LOGIN, rec->last_login);
	display_msg(fd, line);

	if( system_operator )
	{
		sprintf(line, "%s%s\n", CP_LAST_FROM, rec->last_from);
		display_msg(fd, line);
		sprintf(line, "%s%d\n", CP_USER_ID, list_uid);
		display_msg(fd, line);
		sprintf(line, "%s%s\n", CP_PUS, rec->pus_add);
		display_msg(fd, line);
	}

	display_msg(fd, "\n");
}
/*end of show_user_data*/



/*
	charge level of user uid
*/
change_user_level(fd, uid)
int fd;
unsigned int uid;
{
	char answer[80];
	char line[300];
	struct udb rec;
	unsigned int old_level;
	char	list_filename[255];
	int listfile;

	if(debug_mode) printf("(listuser.c)change_user_level %d\n", uid);

	/*******************/
	/*user found or not*/
	/*******************/
	if(uid==0)
	{
		display_msg(fd, NO_SUCH_USER);
		suspend(fd);
		return;
	}

	/*****************/
	/*get user record*/
	/*****************/
	get_user_data(&rec, uid);
	old_level=rec.level;

	/****************************/
	/*if account disabled or not*/
	/****************************/
	if( rec.delete_mark=='X' || rec.delete_mark=='*' )
	{
		display_msg(fd, NO_SUCH_USER);
		suspend(fd);
		return;
	}

	show_user_data(fd, uid, &rec);

	asking(fd, SYSOP_ASK_NEW_LEVEL, answer, 10);
	if( answer[0]==0 || answer[0]==13 || answer[0]==10 )
		return;

	rec.level=atoi(answer);
	display_msg(fd, "\n");
	sprintf(line, "%s%d\n", CP_LEVEL, rec.level);
	display_msg(fd, line);
	display_msg(fd, "\n");

	if( yes_no(fd, CONFIRM_MSG)=='y' )
	{
	  /*fill pus_add data manually*/
	  asking(fd, LIST_LEVEL_DATA, answer, 30);
	  if( answer[0]==0 || answer[0]==13 || answer[0]==10 )
	    strcpy(answer, "(=BLANK)");
	  sprintf(line, "[%s]%s", user_name, answer);
	  nstrcpy(rec.pus_add, line, 41);

	  set_user_data(&rec, uid);
	  do_log(7, "%s change user level of %s from %d to %d", user_name, rec.bbs_name, old_level, rec.level);

	  /*user area must be reset if level down*/
	  if( rec.level < old_level )
	  {
	    sprintf(list_filename, "%s/%d.%s", USER_PREFERENCE, uid, GROUP_LIST);
	    if( file_exist(list_filename) && flength(list_filename)>3 )
	    {
	      listfile=open(list_filename, O_WRONLY);
	      if( listfile>0 )
	      {
		lseek(listfile, 0, SEEK_SET);
		write(listfile, "0", 1);
		close(listfile);
	      }
	    }
	  }/*end if(rec.level<old_level)*/

	}/*end if(yes_no)*/

}
/*end of change_user_level*/
