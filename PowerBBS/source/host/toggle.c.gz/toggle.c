/*************************************************************************
 * toggle.c --- toggle files for downloading				 *
 *	      by Samson Chen, Apr 12, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"
#include "dbf.h"

static char rcsid[]="$Id: toggle.c,v 1.8 1995/09/09 05:39:54 pbbs Exp pbbs $";


struct group_struc {
	char	path[40];
	char	describe[50];
	char	new_post;
	int	gid;
	struct	group_struc *next;
	struct	group_struc *previous;
	};

static char	group_fetched=FALSE;	/*local flag for grouplist fetch*/
static int	group_items=0, max_gid=0;;
static struct	group_struc *gid_begin_point, *gid_end_point;


/*
	select a file area
*/
select_files(fd)
	int fd;
{
	change_file_area(fd);

	if( toggles>0 )
	  if( yes_no(fd, DOWNLOAD_NOW)=='y' )
	    download(fd);
}
/*end of select_files*/



/*
	toggle_files --- toggle files for downloading
*/
toggle_files(fd)
	int fd;
{
	char answer[80];
	char gfile[120];
	char part_name[80];
	char leave;

	leave=FALSE;

	do
	{
		asking(fd, TAG_WHAT, answer, 80);
		if( answer[0]==0 || answer[0]==13 )
		{
			leave=TRUE;
			continue;
		}

		strip_nl(answer);
		split_filename(answer, part_name);

		do_log(1, "%s toggle %s", user_name, part_name);

		if( toggles>=MAX_ALLOW_TAG )
		{
			display_msg(fd, TAG_TOO_MORE);
			leave=TRUE;
			continue;
		}

		sprintf(gfile, "%s/%s/%s", FILE_PATH, file_area, part_name);

		if( !file_exist(gfile) )
		{
			display_msg(fd, NO_SUCH_FILE);
			continue;
		}

		strcpy( tagged[toggles], gfile );
		toggles++;

	} while( !leave );
}
/*end of toggle_files*/



/*
	reset_toggles --- reset toggled files
*/
reset_toggles(fd)
	int fd;
{
	char answer[3];
	char line[120];
	char part_name[50];
	int n;

	if( toggles==0 )
		return;

	display_msg(fd, CURRENT_TOGGLES);

	for(n=0; n<toggles; n++)
	{
		split_filename(tagged[n], part_name);
		sprintf(line, "%2d %s\n", n+1, part_name);
		display_msg(fd, line);
	}

	display_msg(fd, "\n");

	if( yes_no(fd, RESET_TAG_CONFIRM)=='y' )
		toggles=0;
}
/*end of reset_toggles*/



/*
	change_file_area --- interactive file area selection
*/
change_file_area(fd)
	int fd;
{
	char	inter_buf[IBUF_SIZE];
	char	*ibuf_head;
	char	line[255];
	char	txtbuf[80];
	char	answer[80];
	char	crlf[3];
	struct	group_struc *gp;
	int	scr_size;	/*client's screen size*/
	int	scrcnt;
	int	rlen;
	int	ret;
	char	protocol;
	char	leave;
	char	forward_dir, same_buffer;
	int	sgid, gid_begin, gid_end;
	int	n;
	char	prompt_line[128];

	/*if first use this function, fetch all accepatable groups*/
	if( !group_fetched )
	{
		fetch_file_area(fd);

		/*fetching failed, skip selecting*/
		if( !group_fetched )
			return;
	}

	/*get client's screen size*/
	scr_size=get_scrsize(fd);

	sprintf(crlf, "%c%c", 13, 10);

	forward_dir=TRUE;		/*assume forward reading*/

	/*groups items is less than screen size*/
	if( group_items<scr_size ) scr_size=group_items;

	/*------------------------------------------------------------*/

	/***************/
	/*change prompt*/
	/***************/

	sprintf(prompt_line, "%s", SELECT_FILEAREA);
	change_intr_prompt(fd, prompt_line);

	/***************/

	leave=FALSE;
	same_buffer=FALSE;
	do
	{

	  scrcnt=0;
	  inter_buf[0]=0;
	  gp=gid_begin_point;
	  gid_begin=gp->gid;

          if( forward_dir )
          {
                ibuf_head=inter_buf;
          }     
          else  
          {     
                ibuf_head=inter_buf + (IBUF_SIZE-1);
                *ibuf_head=0;
          }     

	  /*---------------------*/
	  /*assemble groups items*/
	  /*---------------------*/
	  if( !same_buffer )
	  {
	    do
	    {

	      /*assemble single item*/
	      line[0]=0;
	      sprintf(txtbuf, "%d", gp->gid);
	      strcat(line, txtbuf);
	      strcat(line, crlf);
	      strcat(line, gp->describe);
	      strcat(line, crlf);

	      /*test if new post in*/
	      if( gp->new_post==' ' )	/*untested*/
	      {
		  if( test_new_income_files(gp->path) )
			  gp->new_post='Y';
		  else
			  gp->new_post='N';
	      }

	      /*-------------------------------------*/

	      if( gp->new_post=='Y' )
		  strcat(line, NEW_POST_MARK);
	      else
		  strcat(line, NO_NEW_POST_MARK);

	      strcat(line, gp->path);
	      strcat(line, crlf);

	      if( forward_dir )
	      {       
		  strcat( ibuf_head, line );
	      }       
	      else    
	      {       
		  ret=strlen(line);
		  ibuf_head -= ret;

		  for(ret=0; ret<strlen(line); ret++)
			  ibuf_head[ret]=line[ret];
	      }
		  
	      /*add counter*/
	      scrcnt++;
	      if( scrcnt>=scr_size )
		  break;

	      /*stop at last item*/
	      if( (gp->gid>=max_gid) && forward_dir )
		  break;

	      /*get then 1st one, regenerate from first*/
	      if( (gp->gid == 1) && !forward_dir )
	      {
		  scrcnt=0;
		  inter_buf[0]=0;
		  gid_begin_point=gp;
		  gid_begin=gp->gid;
		  ibuf_head=inter_buf;
		  forward_dir=TRUE;
		  continue;
	      }

	      /*move pointer*/
	      if( forward_dir )
		  gp=gp->next;
	      else
		  gp=gp->previous;

	    }while(scrcnt<scr_size);

	    gid_end_point=gp;
	    gid_end=gp->gid;

	    if( gid_end<gid_begin )
	    {
		  /*swap*/
		  sgid=gid_end;
		  gid_end=gid_begin;
		  gid_begin=sgid;
	    }

	    if(debug_mode) printf("file: gid_begin: %d, gid_end:%d\n", gid_begin, gid_end);

	  }/*end if(same_buffer)*/

	  /*----------------------------------------------------*/

	  /*send reqest*/
	  if( same_buffer )
	    send_mpf(fd, "SAME_BUFFER", 11, INTRSEL);
	  else
	    send_mpf(fd, ibuf_head, strlen(ibuf_head), INTRSEL);

	  read_mpf(fd, answer, &rlen, &protocol, FALSE);

          if( protocol != INTRSEL )
          {

                do_log(8, "%s protocol_stat_err with protocol code %d at change_file_area", user_name, protocol); 
                protocol_stat_err(fd);
          }     
          
          answer[rlen]=0;
          strip_nl(answer);
          
          /*---------------------------------------*/

	  same_buffer=FALSE;

          if(answer[0]=='q')
          {     
                /*quit interactive selecting*/
                leave=TRUE;
                continue;
          }

	  if(answer[0]=='s')
	  {
		/*quick join*/
		quick_file_area_join(fd);
		forward_dir=TRUE;
		continue;
	  }

          if(answer[0]=='u')
          {
                if(debug_mode) printf("(toggle.c)PageUp\n");
                
                if( forward_dir )
			gid_begin_point=gid_begin_point->previous;
		else
			gid_begin_point=gid_end_point->previous;
                
                forward_dir=FALSE;
                
                continue;
          }

          if(answer[0]=='d')
          {
                if(debug_mode) printf("(toggle.c)PageDown\n");
                
                /*PageDown*/
                if( forward_dir )
			gid_begin_point=gid_end_point->next;
		else
			gid_begin_point=gid_begin_point->next;
                
                forward_dir=TRUE;
                
                continue;
	  }

	  /*----------------------------------------------------------*/

	  sgid=atoi(answer);
	  if( sgid>0 )
	  {
		gp=gid_begin_point;

		for(n=0; n<group_items; n++, gp=gp->next)
		{
		  if( gp->gid == sgid )
		  {
			if( chn_file_area(fd, gp->path) )
			{
			  gp->new_post='N';

			  if( (gp->gid >= gid_begin) && (gp->gid <= gid_end) )
				same_buffer=TRUE;
			  else
			  {
				gid_begin_point=gp;
				forward_dir=TRUE;
			  }
			}

			break;

		  }/*end if*/
		}/*end for*/

	  }/*end if(sgid)*/

	}while(!leave);

}
/*end of change_file_area*/



/*
	quick_file_area_join --- user input for quick file area join
*/
quick_file_area_join(fd)
{
	char	leave;
	char	line[100];
	char	answer[80];
	struct	group_struc *gp;
	int	n;

	/*if first use this function, fetch all accepatable groups*/
	if( !group_fetched )
	{
		fetch_file_area(fd);

		/*fetching failed, skip selecting*/
		if( !group_fetched )
			return;
	}

	leave=FALSE;

	do
	{

	  sprintf(line, "\n%s", ASK_FILE_AREA);
	  asking(fd, line, answer, 40);

	  if( answer[0]==0 || answer[0]==13 || answer[0]==10 )
		return;	/*user press enter directly*/

	  gp=gid_begin_point;

	  /*parse 1 --- find exactly identical group*/
	  for(n=0; n<group_items; n++, gp=gp->next)
	  {
		if( !strcmp(gp->path, answer) )
		{
		  if( chn_file_area(fd, gp->path) )
		  {
			leave=TRUE;
			gid_begin_point=gp;
		  }
		  gp->new_post='N';
		  break;
		}
	  }/*end for*/

	  if( leave )
		continue;

	  /*parse 2 --- find partially like group*/

	  gp=gid_begin_point->next;

	  for(n=0; n<group_items; n++, gp=gp->next)
	  {
		if( !strncmp(gp->path, answer, strlen(answer)) )
		{
		  if( chn_file_area(fd, gp->path) )
		  {
			leave=TRUE;
			gid_begin_point=gp;
		  }
		  gp->new_post='N';
		  break;
		}
	  }/*end for*/

	  if( leave )
		continue;

	  display_msg(fd, NO_SUCH_AREA);

	}while(!leave);

}
/*end of quick_file_area_join*/



/*
	fetch file area list to memory
*/
fetch_file_area(fd)
	int fd;
{
	char	list_filename[255];
	struct	group_struc *group_head, *group_point, *new_space, *plink;
	FILE	*listfile;
	char	line[255];
	char	test_path[255];
	char	mpath[40];
	char	mdescribe[50];
	int	mjoin;
	int	mpost;
	char	mbuf[10];
	char	*p;
	int	ret;
	int	items;
	int	n;
	char	*error_entry="<ERROR>";

	if(debug_mode) printf("(select.c)fetch mail groups\n");

	sprintf(list_filename, "%s", FILE_AREA_LIST);
	if( !file_exist(list_filename) )	/*no file area list file*/
	{
		display_msg(fd, NO_FILE_AREA_LIST);
		suspend(fd);
		return;
	}

	group_head=group_point=(struct group_struc *)NULL;
	gid_begin_point=gid_end_point=(struct group_struc *)NULL;
	items=0;

	/*--------------------------------------*/

	listfile=fopen(list_filename, "r");

	while( fgets(line, 127, listfile) )
	{

	  /*take off comments*/
	  for(n=0; n<strlen(line); n++)
		if( line[n]=='#' )
		{
			line[n]=0;
			break;
		}

	  ret=strlen(line);
	  if( ret<8 )
		continue;

	  if(ret<126)
	  {
		/*to avoid a possoble bug of next_blank*/
		line[ret+1]=0;
		line[ret+2]=0;
	  }

	  /*--------------------------------------------------*/

	  /*--- get area path ---*/
	  p=line;
	  ret=next_params(p);
	  p+=ret;
	  ret=next_tab_space(p);
	  if( ret==0 ) continue;
	  p[ret]=0;
	  nstrcpy(mpath, p, 40);

	  p+=ret+1;
	  ret=next_params(p);
	  p+=ret;
	  ret=next_tab_space(p);
	  if( ret==0 ) continue;

	  /*--- get join security ---*/
	  p[ret]=0;
	  nstrcpy(mbuf, p, 10);
	  mjoin=atoi(mbuf);

	  if( !system_operator && (user_level<mjoin) ) continue; /*join secu*/

	  p+=ret+1;
	  ret=next_params(p);
	  p+=ret;
	  ret=next_tab_space(p);
	  if( ret==0 ) continue;

	  /*--- get area description */
	  strip_nl(p);
	  nstrcpy(mdescribe, p, 50);

	  /*++++++++++++++++++++++++++++++*/
	  /*+++ add to group link list +++*/
	  /*++++++++++++++++++++++++++++++*/
	  new_space=(struct group_struc *)malloc(sizeof(struct group_struc));

	  if( group_head==(struct group_struc *)NULL )
	  {
		group_head=group_point=new_space;
	  }
	  else
	  {
		group_point->next=new_space;
		plink=group_point;
		group_point=new_space;
		group_point->previous=plink;
	  }

	  nstrcpy(group_point->describe, mdescribe, 50);
	  group_point->new_post=' ';

	  nstrcpy(group_point->path, mpath, 40);
	  group_point->gid=++items;
	  group_point->next=(struct group_struc *)NULL;

	}/*end while(fgets)*/

	group_point->next=group_head;		/*circular link*/
	group_head->previous=group_point;

	group_items=items;
	max_gid=group_point->gid;

	gid_begin_point=gid_end_point=group_head;

	group_fetched=TRUE;

}
/*end of fetch_file_area*/



/*
	quick test if new files in
	(NOT IMPLEMENT YET)
*/
test_new_income_files(gpath)
	char *gpath;
/*
	return:
		TRUE: new post in
		FALSE: np new post
*/
{
	return(FALSE);
}
/*end of test_new_income_files*/
