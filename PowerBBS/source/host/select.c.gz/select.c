/*************************************************************************
 * select.c --- interactive mail group select				 *
 *		by Samson Chen, July 9, 1994				 *
 *************************************************************************/

#include "pbbs.h"
#include "message.h"
#include "global.h"
#include "dbf.h"

static char rcsid[]="$Id: select.c,v 1.25 1995/11/09 08:23:47 pbbs Exp pbbs $";



struct group_struc {
	char	*path;
	char	*describe;
	char	new_post;
	int	post_level;
	int	gid;
	struct	group_struc *next;
	struct	group_struc *previous;
	};

static char	group_fetched=FALSE;	/*local flag for grouplist fetch*/
static int	group_items=0, max_gid=0;
static struct	group_struc *gid_begin_point, *gid_end_point, *group_head;

/*
	for Blue Wave Control
*/
static int	bw_counter;
static struct	group_struc *bw_point;


/*
	change_area --- interactive mail area selecting
*/
change_area(fd)
	int fd;
{
	char	inter_buf[IBUF_SIZE];
	char	*ibuf_head;
	char	line[255];
	char	txtbuf[80];
	char	answer[80];
	char	crlf[3];
	struct	group_struc *gp;
	int	scr_size;	/*client's screen size*/
	int	scrcnt;
	int	rlen;
	int	ret;
	char	protocol;
	char	leave;
	char	forward_dir, same_buffer;
	int	sgid, gid_begin, gid_end;
	int	n;
	char	prompt_line[128];
	char	re_asm=FALSE;

	/*if first use this function, fetch all accepatable groups*/
	if( !group_fetched )
	{
		fetch_group(fd);

		/*fetching failed, skip selecting*/
		if( !group_fetched )
			return;
	}

	/*get client's screen size*/
	scr_size=get_scrsize(fd);

	sprintf(crlf, "%c%c", 13, 10);

	forward_dir=TRUE;		/*assume forward reading*/

	/*groups items is less than screen size*/
	if( group_items<scr_size ) scr_size=group_items;

	/*------------------------------------------------------------*/

	/***************/
	/*change prompt*/
	/***************/

	sprintf(prompt_line, "%s %s", CURRENT_POSTGROUP, group_areaname);
	change_intr_prompt(fd, prompt_line);

	/***************/

	leave=FALSE;
	same_buffer=FALSE;
	do
	{

	  scrcnt=0;
	  inter_buf[0]=0;
	  gp=gid_begin_point;
	  gid_begin=gp->gid;

	  if( forward_dir )
	  {
		ibuf_head=inter_buf;
	  }
	  else
	  {
		ibuf_head=inter_buf + (IBUF_SIZE-1);
		*ibuf_head=0;
	  }

	  /*---------------------*/
	  /*assemble groups items*/
	  /*---------------------*/
	  if( !same_buffer || re_asm )
	  {
	    do
	    {

	      /*assemble single item*/
	      line[0]=0;
	      sprintf(txtbuf, "%d", gp->gid);
	      strcat(line, txtbuf);
	      strcat(line, crlf);
	      strcat(line, gp->describe);
	      strcat(line, crlf);

	      /*test if new post in*/
	      if( gp->new_post==' ' )   /*untested*/
	      {
		  if( test_new_post(gp->path) )
			  gp->new_post='Y';
		  else
			  gp->new_post='N';
	      }

	      /*-------------------------------------*/

	      if( gp->new_post=='Y' )
		  strcat(line, NEW_POST_MARK);
	      else
		  strcat(line, NO_NEW_POST_MARK);

	      strcat(line, gp->path);
	      strcat(line, crlf);

	      if( forward_dir )
	      {
		  strcat( ibuf_head, line );
	      }
	      else
	      {
		  ret=strlen(line);
		  ibuf_head -= ret;

		  for(ret=0; ret<strlen(line); ret++)
			  ibuf_head[ret]=line[ret];
	      }

	      /*add counter*/
	      scrcnt++;
	      if( scrcnt>=scr_size )
		  break;

	      /*stop at last item*/
	      if( (gp->gid>=max_gid) && forward_dir )
		  break;

	      /*get then 1st one, regenerate from first*/
	      if( (gp->gid == 1) && !forward_dir )
	      {
		  scrcnt=0;
		  inter_buf[0]=0;
		  gid_begin_point=gp;
		  gid_begin=gp->gid;
		  ibuf_head=inter_buf;
		  forward_dir=TRUE;
		  continue;
	      }

	      /*move pointer*/
	      if( forward_dir )
		  gp=gp->next;
	      else
		  gp=gp->previous;

	    }while(scrcnt<scr_size);

	    gid_end_point=gp;
	    gid_end=gp->gid;

	    if( gid_end<gid_begin )
	    {
		  /*swap*/
		  sgid=gid_end;
		  gid_end=gid_begin;
		  gid_begin=sgid;
	    }

	    if(debug_mode) printf("gid_begin: %d, gid_end:%d\n", gid_begin, gid_end);

	  }/*end if(same_buffer)*/

	  /*----------------------------------------------------*/

	  /*send reqest*/
	  if( same_buffer && !re_asm )
	    send_mpf(fd, "SAME_BUFFER", 11, INTRSEL);
	  else
	    send_mpf(fd, ibuf_head, strlen(ibuf_head), INTRSEL);

	  read_mpf(fd, answer, &rlen, &protocol, FALSE);

	  if( protocol != INTRSEL )
	  {

		do_log(8, "%s protocol_stat_err with protocol code %d at change_area", user_name, protocol);
		protocol_stat_err(fd);
	  }

	  answer[rlen]=0;
	  strip_nl(answer);

	  /*---------------------------------------*/

	  same_buffer=FALSE;

	  if(answer[0]=='q')
	  {
		if( !forward_dir )
		  gid_begin_point=gid_end_point;

		/*quit interactive selecting*/
		leave=TRUE;
		continue;
	  }

	  if(answer[0]=='s')
	  {
		/*quick join*/
		quick_join(fd, FALSE);
		forward_dir=TRUE;
		continue;
	  }

	  if(answer[0]=='u')
	  {
		if(debug_mode) printf("(select.c)PageUp\n");

		if( forward_dir )
			gid_begin_point=gid_begin_point->previous;
		else
			gid_begin_point=gid_end_point->previous;

		forward_dir=FALSE;

		continue;
	  }

	  if(answer[0]=='d')
	  {
		if(debug_mode) printf("(select.c)PageDown\n");

		/*PageDown*/
		if( forward_dir )
			gid_begin_point=gid_end_point->next;
		else
			gid_begin_point=gid_begin_point->next;

		forward_dir=TRUE;

		continue;
	  }

	  /*----------------------------------------------------------*/

	  sgid=atoi(answer);
	  if( sgid>0 )
	  {
		gp=gid_begin_point;

		for(n=0; n<group_items; n++, gp=gp->next)
		{
		  if( gp->gid == sgid )
		  {
			if( select_mail_area(fd, gp->path) )
			{
			  mini_post_level=gp->post_level;
			  if( user_level < mini_post_level )
			  {
				sprintf(line, "%s%d\n", MINIMUM_POST_LEVEL, mini_post_level);
				display_msg(fd, line);
			  }

			  gp->new_post='N';

			  if( (gp->gid >= gid_begin) && (gp->gid <= gid_end) )
				same_buffer=TRUE;
			  else
			  {
				gid_begin_point=gp;
				forward_dir=TRUE;
			  }

			  re_asm=inter_read(fd);
			}
			else
				suspend(fd);

			break;

		  }/*end if*/
		}/*end for*/

	  }/*end if(sgid)*/

	}while(!leave);

}
/*end of change_area*/



/*
	quick_join --- user input for quick area join
*/
quick_join(fd, menu_quick_join)
int fd;
char menu_quick_join;	/*if select by main menu quick join*/
{
	char	leave;
	char	line[100];
	char	answer[80];
	struct	group_struc *gp;
	int	n;

	/*if first use this function, fetch all accepatable groups*/
	if( !group_fetched )
	{
		fetch_group(fd);

		/*fetching failed, skip selecting*/
		if( !group_fetched )
			return;
	}

	leave=FALSE;

	do
	{

	  sprintf(line, "\n%s%s\n", CURRENT_POSTGROUP, current_group);
	  display_msg(fd, line);
	  asking(fd, ASK_MAIL_GROUP, answer, 40);

	  if( answer[0]==0 || answer[0]==13 || answer[0]==10 )
		return; /*user press enter directly*/

	  gp=gid_begin_point;

	  /*parse 1 --- find exactly identical group*/
	  for(n=0; n<group_items; n++, gp=gp->next)
	  {
		if( !strcmp(gp->path, answer) )
		{
		  if( select_mail_area(fd, gp->path) )
		  {
			mini_post_level=gp->post_level;
			if( user_level < mini_post_level )
			{
			  sprintf(line, "%s%d\n", MINIMUM_POST_LEVEL, mini_post_level);
			  display_msg(fd, line);
			}
			leave=TRUE;
			gid_begin_point=gp;
		  }
		  gp->new_post='N';
		  break;
		}
	  }/*end for*/

	  if( leave )
		continue;

	  /*parse 2 --- find partially like group*/

	  gp=gid_begin_point->next;

	  for(n=0; n<group_items; n++, gp=gp->next)
	  {
		if( !strncmp(gp->path, answer, strlen(answer)) )
		{
		  if( select_mail_area(fd, gp->path) )
		  {
			mini_post_level=gp->post_level;
			if( user_level < mini_post_level )
			{
			  sprintf(line, "%s%d\n", MINIMUM_POST_LEVEL, mini_post_level);
			  display_msg(fd, line);
			}
			leave=TRUE;
			gid_begin_point=gp;
		  }
		  gp->new_post='N';
		  break;
		}
	  }/*end for*/

	  if( leave )
	  {
		if( menu_quick_join )
		  leave=FALSE;	/*continue selection if partial matched*/
		continue;
	  }

	  display_msg(fd, NO_SUCH_GROUP);

	}while(!leave);

}
/*end of quick_join*/



/*
	fetch_group --- fetch group list to memory
*/
fetch_group(fd)
	int fd;
{
	char	list_filename[255];
	struct	group_struc *group_point, *new_space, *plink;
	FILE	*listfile;
	char	line[255];
	char	test_path[255];
	char	mpath[40];
	char	mdescribe[50];
	int	mjoin;
	int	mpost;
	char	mbuf[10];
	char	*p;
	int	ret;
	int	items;
	int	n;
	char	*error_entry="<ERROR>";

	if(debug_mode) printf("(select.c)fetch mail groups\n");

	sprintf(list_filename, "%s", GROUP_LIST);
	if( !file_exist(list_filename) )	/*no group list file*/
	{
		display_msg(fd, NO_GROUP_LIST);
		suspend(fd);
		return;
	}

	group_head=group_point=(struct group_struc *)NULL;
	gid_begin_point=gid_end_point=(struct group_struc *)NULL;
	items=0;

	/*--------------------------------------*/

	listfile=fopen(list_filename, "r");

	while( fgets(line, 127, listfile) )
	{

	  /*take off comments*/
	  for(n=0; n<strlen(line); n++)
		if( line[n]=='#' )
		{
			line[n]=0;
			break;
		}

	  ret=strlen(line);
	  if( ret<8 )
		continue;

	  if(ret<126)
	  {
		/*to avoid a possoble bug of next_blank*/
		line[ret+1]=0;
		line[ret+2]=0;
	  }

	  /*--------------------------------------------------*/

	  /*--- get area path ---*/
	  p=line;
	  ret=next_params(p);
	  p+=ret;
	  ret=next_tab_space(p);
	  if( ret==0 ) continue;
	  p[ret]=0;
	  nstrcpy(mpath, p, 40);

	  p+=ret+1;
	  ret=next_params(p);
	  p+=ret;
	  ret=next_tab_space(p);
	  if( ret==0 ) continue;

	  /*--- get join security ---*/
	  p[ret]=0;
	  nstrcpy(mbuf, p, 10);
	  mjoin=atoi(mbuf);

	  if( !system_operator && (user_level<mjoin) ) continue; /*join secu*/

	  p+=ret+1;
	  ret=next_params(p);
	  p+=ret;
	  ret=next_tab_space(p);
	  if( ret==0 ) continue;

	  /*--- get post security ---*/
	  p[ret]=0;
	  nstrcpy(mbuf, p, 10);
	  mpost=atoi(mbuf);

	  p+=ret+1;
	  ret=next_params(p);
	  p+=ret;

	  /*--- get area description */
	  strip_nl(p);
	  nstrcpy(mdescribe, p, 50);

	  /*++++++++++++++++++++++++++++++*/
	  /*+++ add to group link list +++*/
	  /*++++++++++++++++++++++++++++++*/
	  new_space=(struct group_struc *)malloc(sizeof(struct group_struc));

	  if( group_head==(struct group_struc *)NULL )
	  {
		group_head=group_point=new_space;
	  }
	  else
	  {
		group_point->next=new_space;
		plink=group_point;
		group_point=new_space;
		group_point->previous=plink;
	  }

	  sprintf(test_path, "%s/%s", MAIL_PATH, mpath);

	  if( !path_exist(test_path) )
	  {
		/*path not found, maybe new create, touch a new one*/
		do_log(8, "mail path %s not found, touch a new one in %s", mpath, user_name);
		mkdir(test_path, 0x1c0);
		/*permission 0x1c0 is rwx------*/
	  }

	  make_string(&(group_point->describe), mdescribe, 50);
	  group_point->new_post=' ';
	  make_string(&(group_point->path), mpath, 40);
	  group_point->post_level=mpost;
	  group_point->gid=++items;
	  group_point->next=(struct group_struc *)NULL;

	}/*end while(fgets)*/

	fclose(listfile);

	group_point->next=group_head;		/*circular link*/
	group_head->previous=group_point;

	group_items=items;
	max_gid=group_point->gid;

	gid_begin_point=gid_end_point=group_head;

	group_fetched=TRUE;

}
/*end of fetch_group*/



/*
	test_new_post --- quick test if new post in
*/
test_new_post(gpath)
	char *gpath;
/*
	return:
		TRUE: new post in
		FALSE: no new post
*/
{
	char	rec_file[255];
	char	usr_file[255];
	int	total_msg;
	int	usr_rec;
	int	user_lr;
	int	lastread;

	if( !strcmp(gpath, "mbox") )
	{
		sprintf(rec_file, "%s/mbox/%d.records", MAIL_PATH, user_uid);
		sprintf(usr_file, "%s/mbox/users", MAIL_PATH);
	}
	else
	{
		sprintf(rec_file, "%s/%s/records", MAIL_PATH, gpath);
		sprintf(usr_file, "%s/%s/users", MAIL_PATH, gpath);
	}


	total_msg=flength(rec_file)/sizeof(struct msgrec);
	usr_rec=flength(usr_file)/sizeof(int);

	if( usr_rec < user_uid+1 )
		return(FALSE);		/*user never join this area*/

	user_lr=open(usr_file, O_RDONLY);
	lseek(user_lr, user_uid*sizeof(int), SEEK_SET);
	read(user_lr, &lastread, sizeof(int) );
	close(user_lr);

	if( total_msg>lastread )
		return(TRUE);
	else
		return(FALSE);

}
/*end of test_new_post*/



/*
	read_box
*/
read_mbox(fd)
	int fd;
{
	char old_current_group[30];
	char old_group_areaname[30];
	unsigned int old_mini_post_level;
	char old_group_moderator;
	char old_gf_name[20];

	/*save old mail area informations*/
	strcpy(old_current_group, current_group);
	strcpy(old_group_areaname, group_areaname);
	old_mini_post_level=mini_post_level;
	old_group_moderator=group_moderator;
	strcpy(old_gf_name, gf_name);
	/*********************************/

	select_mail_area(fd, "mbox");
	inter_read(fd);

	/*restore old mail area informations*/
	strcpy(current_group, old_current_group);
	strcpy(group_areaname, old_group_areaname);
	mini_post_level=old_mini_post_level;
	group_moderator=old_group_moderator;
	strcpy(gf_name, old_gf_name);
	/************************************/


}
/*end of read_mbox*/



/*
	send_mbox
*/
send_mbox(fd)
	int fd;
{
	char old_current_group[30];
	char old_group_areaname[30];
	unsigned int old_mini_post_level;
	char old_group_moderator;
	char old_gf_name[20];

	/*save old mail area informations*/
	strcpy(old_current_group, current_group);
	strcpy(old_group_areaname, group_areaname);
	old_mini_post_level=mini_post_level;
	old_group_moderator=group_moderator;
	strcpy(old_gf_name, gf_name);

	select_mail_area(fd, "mbox");
	enter_mail(fd, 0, NULL, NULL, NULL);

	/*restore old mail area informations*/
	strcpy(current_group, old_current_group);
	strcpy(group_areaname, old_group_areaname);
	mini_post_level=old_mini_post_level;
	group_moderator=old_group_moderator;
	strcpy(gf_name, old_gf_name);
	/************************************/
}
/*end of send_box*/



/*
	prefetch mail group if necessary
*/
prefetch_mail_group(fd)
{
	if( !group_fetched )
		fetch_group(fd);
}
/*end of prefetch_mail_group*/



/*
	reset new post check flag
*/
reset_new_post_check_flag(fd)
int fd;
{
	struct	group_struc *gp;
	int	n;

	if( !group_fetched )
		return;

	if(debug_mode) printf("(select.c)reset_new_post_check_flag\n");

	gp=gid_begin_point;
	for(n=0; n<group_items; n++, gp=gp->next)
		gp->new_post=' ';
}
/*end of reset_new_post_ckeck_flag*/



/*
	interactive mail area setup
*/
set_up_area(fd)
	int fd;
{
	FILE	*yankfile;
	char	inter_buf[IBUF_SIZE];
	char	*ibuf_head;
	char	line[255];
	char	txtbuf[80];
	char	answer[80];
	char	crlf[3];
	struct	group_struc *gp;
	int	scr_size;	/*client's screen size*/
	int	scrcnt;
	int	rlen;
	int	ret;
	char	protocol;
	char	leave;
	char	forward_dir;
	int	sgid, gid_begin, gid_end;
	int	n;
	char	prompt_line[128];
	struct	stat stat_buf;

	/*if first use this function, fetch all accepatable groups*/
	if( !group_fetched )
	{
		fetch_group(fd);

		/*fetching failed, skip selecting*/
		if( !group_fetched )
			return;
	}

	/*get client's screen size*/
	scr_size=get_scrsize(fd);

	sprintf(crlf, "%c%c", 13, 10);

	forward_dir=TRUE;		/*assume forward reading*/

	/*groups items is less than screen size*/
	if( group_items<scr_size ) scr_size=group_items;

	/*------------------------------------------------------------*/

	/***************/
	/*change prompt*/
	/***************/

	change_intr_prompt(fd, AREA_SET_1);

	/***************/

	/*set flags for record*/
	gid_begin_point=group_head;
	gp=gid_begin_point;
	for(n=0; n<group_items; n++, gp=gp->next)
		gp->new_post='N';

	/*******************/
	/*compare old setup*/
	/*******************/
	sprintf(line, "%s/%d.%s", USER_PREFERENCE,  user_uid, GROUP_LIST);
	if( file_exist(line) )
	{
	  if( (yankfile=fopen(line, "r"))!=NULL )
	  {
	    fgets(line, 127, yankfile); /*skip first line (time serial)*/
	    while( fgets(line, 127, yankfile) )
	    {
	      ret=next_tab_space(line);
	      line[ret]=0;
	      gp=gid_begin_point;
	      for(n=0; n<group_items; n++, gp=gp->next)
	      {
		if( !strcmp(gp->path, line) )
		{
		  gp->new_post='Y';
		  break;
		}/*end if*/
	      }/*end for*/
	    }/*end while*/
	    fclose(yankfile);
	  }/*end if(yankfile)*/
	}/*end if(file_exist)*/

	/********************************/
	/*compare YANK setup(force read)*/
	/********************************/
	if( file_exist(GROUP_YANK) )
	{
	  if( (yankfile=fopen(GROUP_YANK, "r"))!=NULL )
	  {
	    while( fgets(line, 127, yankfile) )
	    {
	      strip_nl(line);
	      gp=gid_begin_point;
	      for(n=0; n<group_items; n++, gp=gp->next)
	      {
		if( !strcmp(gp->path, line) )
		{
		  gp->new_post='F';
		  break;
		}/*end if*/
	      }/*end for*/
	    }/*end while*/
	    fclose(yankfile);
	  }/*end if(yankfile)*/
	}/*end if(file_exist)*/

	leave=FALSE;
	do
	{

	  scrcnt=0;
	  inter_buf[0]=0;
	  gp=gid_begin_point;
	  gid_begin=gp->gid;

	  if( forward_dir )
	  {
		ibuf_head=inter_buf;
	  }
	  else
	  {
		ibuf_head=inter_buf + (IBUF_SIZE-1);
		*ibuf_head=0;
	  }

	  /*---------------------*/
	  /*assemble groups items*/
	  /*---------------------*/
	  do
	  {

	      /*assemble single item*/
	      line[0]=0;
	      sprintf(txtbuf, "%d", gp->gid);
	      strcat(line, txtbuf);
	      strcat(line, crlf);
	      strcat(line, gp->describe);
	      strcat(line, crlf);

	      /*-------------------------------------*/

	      if( gp->new_post=='F' )
		  strcat(line, FORCE_READ_MARK);
	      else if( gp->new_post=='Y' )
		  strcat(line, NEW_POST_MARK);
	      else
		  strcat(line, NO_NEW_POST_MARK);

	      strcat(line, gp->path);
	      strcat(line, crlf);

	      if( forward_dir )
	      {
		  strcat( ibuf_head, line );
	      }
	      else
	      {
		  ret=strlen(line);
		  ibuf_head -= ret;

		  for(ret=0; ret<strlen(line); ret++)
			  ibuf_head[ret]=line[ret];
	      }

	      /*add counter*/
	      scrcnt++;
	      if( scrcnt>=scr_size )
		  break;

	      /*stop at last item*/
	      if( (gp->gid>=max_gid) && forward_dir )
		  break;

	      /*get then 1st one, regenerate from first*/
	      if( (gp->gid == 1) && !forward_dir )
	      {
		  scrcnt=0;
		  inter_buf[0]=0;
		  gid_begin_point=gp;
		  gid_begin=gp->gid;
		  ibuf_head=inter_buf;
		  forward_dir=TRUE;
		  continue;
	      }

	      /*move pointer*/
	      if( forward_dir )
		  gp=gp->next;
	      else
		  gp=gp->previous;

	  }while(scrcnt<scr_size);

	  gid_end_point=gp;
	  gid_end=gp->gid;

	  if( gid_end<gid_begin )
	  {
		  /*swap*/
		  sgid=gid_end;
		  gid_end=gid_begin;
		  gid_begin=sgid;
	  }

	  if(debug_mode) printf("gid_begin: %d, gid_end:%d\n", gid_begin, gid_end);

	  /*----------------------------------------------------*/

	  /*send reqest*/
	  send_mpf(fd, ibuf_head, strlen(ibuf_head), INTRSEL);
	  read_mpf(fd, answer, &rlen, &protocol, FALSE);

	  if( protocol != INTRSEL )
	  {

		do_log(8, "%s protocol_stat_err with protocol code %d at change_area", user_name, protocol);
		protocol_stat_err(fd);
	  }

	  answer[rlen]=0;
	  strip_nl(answer);

	  /*---------------------------------------*/

	  if(answer[0]=='q')
	  {
		/*****************/
		/*save preference*/
		/*****************/
		if( yes_no(fd, SAVE_PREFERENCE)=='y' )
		{
		  stat(GROUP_LIST, &stat_buf);
		  sprintf(line, "%s/%d.%s", USER_PREFERENCE,  user_uid, GROUP_LIST);
		  if( (yankfile=fopen(line, "w"))!=NULL )
		  {
		    fprintf(yankfile, "%ld\n", stat_buf.st_mtime);
		    gp=group_head;
		    for(n=0; n<group_items; n++, gp=gp->next)
		    {
		      if( gp->new_post=='Y' || gp->new_post=='F' )
			fprintf(yankfile, "%s\t%d\t%d\t%s\n", gp->path, user_level, gp->post_level, gp->describe);
		    }/*end for*/
		    fclose(yankfile);
		    on_set_area(fd);
		    reset_fetched_set_group(fd);
		  }
		  else
		  {
		    display_msg(fd, SYSTEM_ERROR);
		    suspend(fd);
		  }/*end if-else*/
		}/*end if(yes_no)*/

		gid_begin_point=group_head;
		reset_new_post_check_flag(fd);

		/*quit interactive selecting*/
		leave=TRUE;
		continue;
	  }

	  if(answer[0]=='s')
	  {
		/*quick set*/
		quick_set(fd);
		forward_dir=TRUE;
		continue;
	  }

	  if(answer[0]=='u')
	  {
		if(debug_mode) printf("(select.c)PageUp\n");

		if( forward_dir )
			gid_begin_point=gid_begin_point->previous;
		else
			gid_begin_point=gid_end_point->previous;

		forward_dir=FALSE;

		continue;
	  }

	  if(answer[0]=='d')
	  {
		if(debug_mode) printf("(select.c)PageDown\n");

		/*PageDown*/
		if( forward_dir )
			gid_begin_point=gid_end_point->next;
		else
			gid_begin_point=gid_begin_point->next;

		forward_dir=TRUE;

		continue;
	  }

	  /*----------------------------------------------------------*/

	  sgid=atoi(answer);
	  if( sgid>0 )
	  {
		gp=gid_begin_point;

		for(n=0; n<group_items; n++, gp=gp->next)
		{
		  if( gp->gid == sgid )
		  {
		    if( gp->new_post!='F' )     /*'F' for force read*/
		    {
		      if( gp->new_post=='Y' )
			gp->new_post='N';
		      else
		      {
			gp->new_post='Y';
			reset_msg_lastread(fd, gp->path);
		      }
		    }
		    else
		      reset_msg_lastread(fd, gp->path);

		    break;

		  }/*end if*/
		}/*end for*/

	  }/*end if(sgid)*/

	}while(!leave);

}
/*end of set_up_area*/



/*
	quick_set --- user input for quick area set
*/
quick_set(fd)
{
	char	leave;
	char	line[100];
	char	answer[80];
	struct	group_struc *gp;
	int	n;

	/*if first use this function, fetch all accepatable groups*/
	if( !group_fetched )
	{
		fetch_group(fd);

		/*fetching failed, skip selecting*/
		if( !group_fetched )
			return;
	}

	leave=FALSE;

	do
	{

	  sprintf(line, "\n%s", ASK_MAIL_GROUP);
	  asking(fd, line, answer, 40);

	  if( answer[0]==0 || answer[0]==13 || answer[0]==10 )
		return; /*user press enter directly*/

	  gp=gid_begin_point;

	  /*parse 1 --- find exactly identical group*/
	  for(n=0; n<group_items; n++, gp=gp->next)
	  {
		if( !strcmp(gp->path, answer) )
		{
		  gid_begin_point=gp;
		  leave=TRUE;
		  break;
		}
	  }/*end for*/

	  if( leave )
		continue;

	  /*parse 2 --- find partially like group*/

	  gp=gid_begin_point->next;

	  for(n=0; n<group_items; n++, gp=gp->next)
	  {
		if( !strncmp(gp->path, answer, strlen(answer)) )
		{
		  leave=TRUE;
		  gid_begin_point=gp;
		  break;
		}
	  }/*end for*/

	  if( leave )
		continue;

	  display_msg(fd, NO_SUCH_GROUP);

	}while(!leave);

}
/*end of quick_set*/



/*
	reconfiguration user set area (when GROUP_LIST newer that user's)
*/
reconfig_user_area(fd)
int fd;
/*
	return:
		TRUE:	OK
		FALSE:	failed
*/
{
	FILE	*yankfile;
	char	line[255];
	struct	group_struc *gp;
	int	n;
	int	ret;
	struct	stat stat_buf;

	if( debug_mode )printf("(select.c)reconfig_user_area\n");

	/*if first use this function, fetch all accepatable groups*/
	if( !group_fetched )
	{
		fetch_group(fd);

		/*fetching failed, skip selecting*/
		if( !group_fetched )
			return(FALSE);
	}

	/*set flags for record*/
	gid_begin_point=group_head;
	gp=gid_begin_point;
	for(n=0; n<group_items; n++, gp=gp->next)
		gp->new_post='N';

	/*******************/
	/*compare old setup*/
	/*******************/
	sprintf(line, "%s/%d.%s", USER_PREFERENCE,  user_uid, GROUP_LIST);
	if( file_exist(line) )
	{
	  if( (yankfile=fopen(line, "r"))!=NULL )
	  {
	    fgets(line, 127, yankfile); /*skip first line (time serial)*/
	    while( fgets(line, 127, yankfile) )
	    {
	      ret=next_tab_space(line);
	      line[ret]=0;
	      gp=gid_begin_point;
	      for(n=0; n<group_items; n++, gp=gp->next)
	      {
		if( !strcmp(gp->path, line) )
		{
		  gp->new_post='Y';
		  break;
		}/*end if*/
	      }/*end for*/
	    }/*end while*/
	    fclose(yankfile);
	  }/*end if(yankfile)*/
	}/*end if(file_exist)*/

	/********************************/
	/*compare YANK setup(force read)*/
	/********************************/
	if( file_exist(GROUP_YANK) )
	{
	  if( (yankfile=fopen(GROUP_YANK, "r"))!=NULL )
	  {
	    while( fgets(line, 127, yankfile) )
	    {
	      strip_nl(line);
	      gp=gid_begin_point;
	      for(n=0; n<group_items; n++, gp=gp->next)
	      {
		if( !strcmp(gp->path, line) )
		{
		  gp->new_post='F';
		  break;
		}/*end if*/
	      }/*end for*/
	    }/*end while*/
	    fclose(yankfile);
	  }/*end if(yankfile)*/
	}/*end if(file_exist)*/

	stat(GROUP_LIST, &stat_buf);
	sprintf(line, "%s/%d.%s", USER_PREFERENCE,  user_uid, GROUP_LIST);
	if( (yankfile=fopen(line, "w"))!=NULL )
	{
	    fprintf(yankfile, "%ld\n", stat_buf.st_mtime);
	    gp=group_head;
	    for(n=0; n<group_items; n++, gp=gp->next)
	    {
	      if( gp->new_post=='Y' || gp->new_post=='F' )
		fprintf(yankfile, "%s\t%d\t%d\t%s\n", gp->path, user_level, gp->post_level, gp->describe);
	    }/*end for*/
	    fclose(yankfile);
	}
	else
	{
	    display_msg(fd, SYSTEM_ERROR);
	    suspend(fd);
	}/*end if-else*/

	return(TRUE);

}
/*end of reconfig_user_area*/


/*.........................................................................*/
/*................Blue.Wave.Control........................................*/
/*.........................................................................*/

/*
	reset area pointer for inf_area_info
*/
bw_all_area_prepare(fd)
/*
	return:
		TRUE	ok
		FALSE	failed
*/
{
	if( !group_fetched )
	{
		fetch_group(fd);

		/*fetching failed, skip selecting*/
		if( !group_fetched )
			return(FALSE);
	}

	bw_counter=0;
	bw_point=group_head;
}
/*end of bw_all_area_prepare*/



/*
	fetch all areas
*/
bw_get_all_area(fd, areanum, echotag, title, post_level, mbox_area)
int fd;
char *areanum;	/*size=6*/
char *echotag;	/*size=21*/
char *title;	/*size=50*/
int *post_level;
char *mbox_area;
/*
	return:
		TRUE	more areas waiting to be output
		FALSE	this is a last one
*/
{
  sprintf(areanum, "%d", bw_point->gid);
  sprintf(echotag, "%-.20s", bw_point->path);
  sprintf(title, "%-.49s", bw_point->describe);
  *post_level=bw_point->post_level;
  if( !strcmp(bw_point->path, "mbox") )
    *mbox_area=TRUE;
  else
    *mbox_area=FALSE;

  bw_point=bw_point->next;
  bw_counter++;

  if( bw_counter>=group_items )
    return(FALSE);
  else
    return(TRUE);
}
/*end of gw_get_all_area*/



/*
	get real gid from all areas
*/
get_real_gid(areanum, path)
char *areanum;
char *path;
{
  struct group_struc *gp;
  int n;

  gp=group_head;
  for(n=0; n<group_items; n++, gp=gp->next)
  {
	if( !strcmp(gp->path, path) )
	{
		sprintf(areanum, "%d", gp->gid);
		return;
	}
  }/*end for*/

  sprintf(areanum, "%d", 0);
}
/*end of get_real_gid*/



/*
	get post level
*/
bw_get_post_level(fd, area, post_level, ignore_case)
int fd;
char *area;
int *post_level;
char ignore_case;	/*if ignore area case*/
/*
	return:
		TRUE:	ok
		FALSE:	no such area

	if(ignore_case == TRUE )
	  area will be put real area name
*/
{
  struct group_struc *gp;
  int n;

  *post_level=0;

  gp=group_head;
  for(n=0; n<group_items; n++, gp=gp->next)
  {
    if( ignore_case )
    {

      if( !strcasecmp(gp->path, area) )
      {
	*post_level=gp->post_level;
	nstrcpy(area, gp->path, 50);
	return(TRUE);
      }

    }
    else
    {

      if( !strcmp(gp->path, area) )
      {
	*post_level=gp->post_level;
	return(TRUE);
      }

    }
  }/*end for*/

  return(FALSE);
}
/*end of bw_get_post_level*/
