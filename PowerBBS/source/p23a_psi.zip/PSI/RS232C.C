/****************************************************************
 * RS-232C Level-0 Interface Layer by Samson Chen March 25,1992 *
 *								*
 * Functions... 						*
 *   open_com_port(port_no,baud,parity,word_length,stop_bit)	*
 *   close_com_port(port_no)					*
 *   recv_data(port_no) 					*
 *   xsmit_data(port_no,*string)				*
 *   send_data(port_no,character)				*
 *   buffer_empty(port_no)					*
 *   clear_buffer(port_no)					*
 *								*
 * Return...							*
 *   recv_data() : char ASCII					*
 *   buffer_empty() : -1 -> empty , 0 -> not empty		*
 *								*
 * Remarks...							*
 *   recv_data() will NOT wait a character if buffer is empty,	*
 *   programmer should check whether the buffer is empty or not *
 *   by himself then call recv_data() to get the char.		*
 *   this program use RTS/CTS hardware flow control		*
 ****************************************************************/



#define INTR_COM1 0x0c	/*IRQ4*/
#define INTR_COM2 0x0b	/*IRQ3*/

#define PIC_8259  0x21	/*Peripheral Interrupt Controller*/
#define EOI_8259  0x20	/*End of Interrupt command*/

#define IRQ4_MASK 0xef	/*enable PIC for IRQ4 (Bit4=0)*/
#define IRQ3_MASK 0xf7	/*enable PIC for IRQ3 (Bit3=0)*/

#define UART_COM1 0x3f8 /*UART base address for COM1*/
#define UART_COM2 0x2f8 /*UART base address for COM2*/

			/*8250 Registers Offset*/
#define IERO 0x01	/*Interrupt Enable Register Offset*/
#define IIDO 0x02	/*Interrupt ID Register Offset*/
#define FCRO 0x02	/*FIFO Control Register Offset*/
#define DFRO 0x03	/*Data Format Register Offset*/
#define RSOO 0x04	/*RS-232 Output Register Offset*/
#define SSRO 0x05	/*Serialization Status Register Offset*/
#define RSIO 0x06	/*RS-232 Input Status Register Offset*/

#define LSB  0x00	/*LSB Baud Rate Divisor Latch Offset*/
#define MSB  0x01	/*MSB Baud Rate Divisor Latch Offset*/

/*for the quick assembly code control, do not change the BUFFER_SIZE*/
#define BUFFER_SIZE 8192	/*buffer size for each com port*/
#define BUFFER_LOW_WATER BUFFER_SIZE/4	/*25%*/

/*global vars for system internal usage*/
int uart;			/*UART base address*/
int intr_com;			/*com interrupt*/
unsigned char irq_mask; 	/*PIC enable mask*/
char com_buffer[BUFFER_SIZE];	/*buffer for com*/
char out_buffer[BUFFER_SIZE];	/*buffer for output*/
int cf,cr,cp;			/*buffer queue pointer for com*/
int of,or;			/*buffer queue for output buf*/
int left_buffer;		/*counter for left buffer size*/
char com_has_set=FALSE; 	/*flag to prevent from duplicate init com*/
int uart_rsoo;			/*UART+RSOO (for NewIRQ)*/
int uart_ssro;			/*UART+SSRO (for NewIRQ)*/
char RTS=TRUE;			/*flow control DTE <- DCE(MODEM)*/
char ns16550=FALSE;		/*National Semiconductor's 16550*/






/**********************************************************************/
/* for PSI data transfer protocol */
#define TIMEOUT 	5	/* 5 seconds before timeout */
#define PACKET_SIZE	1024
#define char_ESCAPE	2
#define char_ETB0	3
#define char_ETB1	4
#define char_ACK0	5
#define char_ACK1	6
#define char_REAC	18

/*
	character mapping

	realdata	mapping data
	.................................
	255		1
	9		7
	1		2+1
	2		2+2
	3		2+3
	4		2+4
	5		2+5
	6		2+6
	0		2+10
	7		2+11
	18		2+12
	29		2+13
	157		2+14
	24		2+15

*/

int received_ACK[]={ FALSE,FALSE };   /* ACK0 & ACK1 */
int send_seq=0, recv_seq=0; /* sequence no. for ETB0, ETB1, ACK0, and ACK1 */
int is_escape_char=FALSE; /* true if previous received byte is ESCAPE_CHAR */
int icf;	   /* read_COMport() internal buffer queue pointer for com */
unsigned char recv_checksum=0;	      /* checksum for received data stream */
int recv_length=0;		      /* received data length */
unsigned char is_trans_char[256], trans_map[256], trans_restore[256];
static char psi_format;
int nCTRLX=0;
char int_buzy;



/*
  build char mapping table

  by Samson Chen
*/
build_mapping_table()
{
  int n;

  memset(is_trans_char, FALSE, 256);
    is_trans_char[0]=TRUE;
    is_trans_char[1]=TRUE;
    is_trans_char[2]=TRUE;
    is_trans_char[3]=TRUE;
    is_trans_char[4]=TRUE;
    is_trans_char[5]=TRUE;
    is_trans_char[6]=TRUE;
    is_trans_char[7]=TRUE;
    is_trans_char[18]=TRUE;
    is_trans_char[29]=TRUE;
    is_trans_char[157]=TRUE;
    is_trans_char[24]=TRUE;

  for(n=0; n<256; n++) trans_map[n]=(unsigned char)n;
    trans_map[0]=10;
    trans_map[1]=1;
    trans_map[2]=2;
    trans_map[3]=3;
    trans_map[4]=4;
    trans_map[5]=5;
    trans_map[6]=6;
    trans_map[7]=11;
    trans_map[18]=12;
    trans_map[29]=13;
    trans_map[157]=14;
    trans_map[24]=15;

  for(n=0; n<256; n++) trans_restore[n]=(unsigned char)n;
    trans_restore[1]=1;
    trans_restore[2]=2;
    trans_restore[3]=3;
    trans_restore[4]=4;
    trans_restore[5]=5;
    trans_restore[6]=6;
    trans_restore[10]=0;
    trans_restore[11]=7;
    trans_restore[12]=18;
    trans_restore[13]=29;
    trans_restore[14]=157;
    trans_restore[15]=24;

  return(0);
}
/*end of build_mapping_table*/



/*
   data transmitter
	for PSI data transfer protocol

   by Henry Chen
*/

unsigned char send_data_map(unsigned char out_data)
{
  unsigned char data;

  /* look up our real/tran map table */
  if (is_trans_char[out_data]) {	/* data is in map table */
    send_data(char_ESCAPE);		/* send extra escape char */
    data=trans_map[out_data];		/* and the mapped data */
  }
  else
  {
    switch (out_data) {
      case 255:     data=1; break;  /* map 255 to 1 */
      case 9:	    data=7; break;  /* map 9 to 7 */
      default:	    data=out_data;
		    break;  /* no map needed */
    }
  }

  return data;
}

int send_packet(char *buffer, int count)
{
  int length;
  unsigned char checksum;
  unsigned char data;
  int timeout;
  time_t stime;
  int retrys=0, old_x, old_y;

  do {
    checksum=0;
    length=0;
    while (length < count) {
      data=buffer[length++];
      checksum ^= data;
      send_data(send_data_map(data));
    }

    /* send the length, checksum & the ETB */
    send_data(send_data_map(length%256));
    send_data(send_data_map(checksum));
    if (send_seq)
      send_data(char_ETB1);
    else
      send_data(char_ETB0);

    received_ACK[send_seq]=FALSE;	/* clear ACK flag */

    stime=time(NULL);			/* start timeout check */
    while (!received_ACK[send_seq] && difftime(time(NULL),stime)<=TIMEOUT) {
      /* wait for ACK */
      buffer_empty();
      kbhit();
    }

    if (received_ACK[send_seq]) {    /* ACK received, advance to next pass */
      send_seq ^= 1;
      timeout=FALSE;
    } else {			     /* timeout */
      old_x=wherex();
      old_y=wherey();
      gotoxy(1, 1);
      printf("send_packet(): ACK time out! Re-send data:%d \n", ++retrys);
      gotoxy(old_x, old_y);
      timeout=TRUE;
    }

  } while (timeout);

  return count;
}


void set_psi_format(char psi_switch)
{
  if( psi_switch && (psi_format!=psi_switch) )
    clear_buffer();

  psi_format=psi_switch;
}




/*
  data receiver
	for PSI data transfer protocol

  by Henry Chen
*/


void read_COMport(void)
{
  unsigned char data;
  unsigned char checksum, length; /* records in received packet */
  int data_in=TRUE;
  int check_data=FALSE;
  int discard=FALSE;
  unsigned char register_status;

  data=inportb(uart);		    /* read a byte from port */

  if( psi_format )
  {
   if (data==char_REAC)
   {
     data_in=FALSE;
   }
   else if (is_escape_char) {	    /* must look up our real/tran map table */

      is_escape_char=FALSE;	    /* reset this flag first */
      data=trans_restore[data];     /* the mapped data */

   } else {
      switch (data) {
	case 1: 	data=255; break;	/* map 1 to 255 */
	case 7: 	data=9; break;		/* map 7 to 9 */
	case char_ESCAPE:
	case char_ETB0:
	case char_ETB1:
	case char_ACK0:
	case char_ACK1: nCTRLX=0; data_in=FALSE; break;
	default:	break;
      }
   } /* if (is_escape_char) */
  }/*end if(psi_format)*/

  if( !psi_format )
    data_in=TRUE;

  if (data_in) {

     recv_checksum ^= data;
     com_buffer[icf++]=data;
     left_buffer--;
     recv_length++;

     if(icf>=BUFFER_SIZE) icf=0;
     /*icf &= (BUFFER_SIZE-1);*/
     if( !psi_format )
       cf=icf;

     if (data==char_CTRLX) {

	nCTRLX++;
	if (nCTRLX>=TERMINATED_CTRL_X_SEQ)
	{
	  /*buffer_empty check must be FALSE, so that psi_terminated
	    flag will be checked*/
	  cf=icf;
	  psi_terminated=TRUE;
	}

     } else {

       nCTRLX=0;

     } /* endif */


     if( left_buffer<=BUFFER_LOW_WATER ) {
       /*flow_control --- set RTS low*/
       disable();     /*CLI*/
       outportb(uart_rsoo, inportb(uart_rsoo) & 0xfd);	  /*bit1=0*/
       enable();      /*STI*/
       RTS=FALSE;
     }

  } else {

    switch (data) {
      case char_ESCAPE: is_escape_char=TRUE; break;
      case char_ETB0:
	   if (recv_seq) /* we expect ETB1 so discard the data received */
	      discard=TRUE;
	   else 				/* ETB0 is what we want */
	      check_data=TRUE;
	   break;
      case char_ETB1:
	   if (recv_seq)			/* ETB1 is what we want */
	      check_data=TRUE;
	   else 	 /* we expect ETB0 so discard the data received */
	      discard=TRUE;
	   break;
      case char_ACK0:	received_ACK[0]=TRUE; break;
      case char_ACK1:	received_ACK[1]=TRUE; break;
      case char_REAC:	break;	/* reactive char, ignore it! */
    }

    if (data==char_ETB0 || data==char_ETB1) {

       if (check_data) {
	 if( recv_length>2 )
	 {
	   checksum=com_buffer[--icf];
	   if (icf < 0) icf += BUFFER_SIZE;
	   length=com_buffer[--icf];
	   if (icf < 0) icf += BUFFER_SIZE;
	   recv_checksum^=checksum;
	   recv_checksum^=length;
	   left_buffer+=2;
	   recv_length-=2;

	   if (icf < 0) icf += BUFFER_SIZE;
	   /*icf &= (BUFFER_SIZE-1);*/

	   if (checksum==recv_checksum && length==(unsigned char)recv_length) {
	      cf=icf;			     /* adjust cf to icf */
	      recv_seq ^= 1;		     /* advance to next pass */
	    } else
	      discard=TRUE;
	 }
	 else
	   discard=TRUE;
       }

       if (discard) {
	  icf=cf;
	  left_buffer += recv_length;
       }

       /* reset checksum & length */
       recv_checksum=0;
       recv_length=0;

       if(!discard)
       {
	 /* send ACK0/1 */
	 if (data==char_ETB0 && recv_seq==1)
	    send_data(char_ACK0);
	 if (data==char_ETB1 && recv_seq==0)
	    send_data(char_ACK1);
       }

       if( !RTS )
	 if( left_buffer>BUFFER_LOW_WATER )
	 {
	   /*flow_control --- set RTS high*/
	   disable();	  /*CLI*/
	   register_status=inportb(uart+RSOO);
	   register_status |= 0x02;  /*bit1=1*/
	   outportb(uart+RSOO, register_status);
	   enable();	  /*STI*/
	   RTS=TRUE;
	 }

    } /* if (data==char_ETB0 || data==char_ETB1) */

  } /* if (data_in) */
}



void interrupt (*old_int)(void);



/*ISR for com (8250/16450)*/
void interrupt newIRQ_8250(void)
{
  int_buzy=TRUE;
  read_COMport();

  outportb(EOI_8259,0x20);	/*end of interrupt*/
  int_buzy=FALSE;
} /*end of newIRQ_8250()*/



/*ISR for com (16550)*/
void interrupt newIRQ_16550(void)
{
  int_buzy=TRUE;
  do {
    read_COMport();
  } while ( inportb(uart_ssro)&1 );

  outportb(EOI_8259,0x20);	/*end of interrupt*/
  int_buzy=FALSE;
} /*end of newIRQ_16550()*/



void detect_16550_uart(void)
{
  unsigned char register_status;

  outportb(uart+FCRO, 0x81);	   /*FIFO enable (if 16550)*/
  register_status=inportb(uart+IIDO);
  if( (register_status>>6)==3 )
  {
    printf("16550 UART detected\n");
    ns16550=TRUE;
  }
  else
    outportb(uart+FCRO, 0);	/*avoid buggy 16550*/

} /*end of detect_16550_uart()*/



int open_com_port(int com,long baud,int parity,int length,int stop_bit)
{
 char outdata,ratehi,ratelo;
 long int bb;
 int cc;

 if(com_has_set) return(-1);		/*dup init*/
 if(com!=1 && com!=2) return(-2);

 build_mapping_table();

 /*set parameters*/
 com_has_set=TRUE;
 icf=cf=cr=0;
 left_buffer=BUFFER_SIZE;
 if(com==1) {	/*set to com1*/
   uart=UART_COM1;
   intr_com=INTR_COM1;
   irq_mask=IRQ4_MASK;
 }
 else { 	/*set to com2*/
   uart=UART_COM2;
   intr_com=INTR_COM2;
   irq_mask=IRQ3_MASK;
 }
 uart_rsoo=uart+RSOO;
 uart_ssro=uart+SSRO;

 /*test if there exist National Semiconductor's 16550 UART*/
 detect_16550_uart();

 /*set frame length*/
 outdata=0x03;
 switch(length) {
   case 5:
     outdata=0x00;
     break;
   case 6:
     outdata=0x01;
     break;
   case 7:
     outdata=0x02;
     break;
   case 8:
     outdata=0x03;
     break;
 }

 /*set parity*/
 outdata |= parity;

 /*set stop bit*/
 if(stop_bit==2) outdata |= 0x04;

 /*set baud rate divisor*/
 ratehi=0x00;
 ratelo=0x60;
 bb=115200L;
 cc=bb/baud;
 ratehi=(cc & 0xff00) >> 8;
 ratelo=cc & 0xff;

 /*set 16550 FIFO mode*/
 if( ns16550 )
   outportb(uart+FCRO, 0x87);	  /*8 bytes trigger, TX/RX FIFO reset*/

 /*output all setting to UART registers*/
 disable();	/*CLI*/
 outportb(uart+DFRO,0x80);	/*set DLAB*/
 outportb(uart+LSB,ratelo);
 outportb(uart+MSB,ratehi);
 outportb(uart+DFRO,outdata & 0x1f);
 outportb(uart+IERO,0x00);	/*disable UART interrupt*/
 inportb(uart+SSRO);		/*clear register*/
 inportb(uart); 		/*clear register*/
 enable();	/*STI*/

 enable8259();

 /*clear the data input before com open*/
 delay(1000);
 clear_buffer();
 int_buzy=FALSE;

 return(0);
} /*end of open_com_port()*/



int enable8259(void)
{
  int n;

  /*get old int vector address*/
  old_int=getvect(intr_com);

  disable();	/*CLI*/

  /*set new int vector address*/
  if( ns16550 )
    setvect(intr_com,newIRQ_16550);
  else
    setvect(intr_com,newIRQ_8250);

  /*set PIC IMR*/
  outportb(PIC_8259,inportb(PIC_8259) & irq_mask);

  /*active UART*/
    /*set GPO2,RTS,DTR*/
  outportb(uart+RSOO,0x0b);
    /*set RxRDY*/
  outportb(uart+IERO,0x01);

  /*clear 6 UART registers by reading it*/
  for(n=0;n<6;n++)
    inportb(uart+n);

  enable();	/*STI*/

  return(0);
} /*end of enable8259()*/



int buffer_empty()
{
  unsigned char register_status;
  char CTS;
  char sc;

  /*output queue processed here*/
  while( of!=or )
  {
    while( int_buzy );	/*waiting for receiving int*/

    sc=out_buffer[of++];
    if(of>=BUFFER_SIZE) of=0;

    /*flow control --- detect CTS*/
    do
    {
      register_status=inportb(uart+RSIO);
      CTS=register_status & 0x10;  /*filter bit4*/
      kbhit();			   /*unblocking keyboard*/
    }while(!CTS);

    while( (inportb(uart+SSRO) & 0x20) != 0x20);  /*wait until TBE set*/
    outportb(uart,sc);
  }/*end while*/

  if(cf!=cr) return(FALSE);

  return(TRUE);
} /*end of buffer_empty*/



int clear_buffer()
{
  left_buffer=BUFFER_SIZE;
  icf=cr=cf=0;
  of=or=0;
  is_escape_char=FALSE;
  recv_checksum=0;
  recv_length=0;

  return(0);
} /*end of clear_buffer*/



char recv_data()
{
  char gc;
  unsigned char register_status;

  if(buffer_empty()) return(0);

  gc=com_buffer[cr++];
  if(cr>=BUFFER_SIZE) cr=0;
  left_buffer++;

  if( !RTS )
  {
    if( left_buffer>BUFFER_LOW_WATER )
    {
      /*flow_control --- set RTS high*/
      disable();     /*CLI*/
      register_status=inportb(uart+RSOO);
      register_status |= 0x02;	/*bit1=1*/
      outportb(uart+RSOO, register_status);
      enable();      /*STI*/
      RTS=TRUE;
    }
  }

  return(gc);
} /*end of recv_data()*/



int send_data(char sc)
{
  /*put it to output queue*/
  out_buffer[or++]=sc;
  if(or>=BUFFER_SIZE) or=0;

  return(0);
} /*end of send_data()*/



int CTS_set(void)
{
  if(inportb(uart+RSIO) & 0x10)
    return(TRUE);
  else
    return(FALSE);
} /*end of CTS_set()*/



int send_data_no_flow_control(char sc)
{
  while( (inportb(uart+SSRO) & 0x20) != 0x20);	/*wait until TBE set*/
  outportb(uart,sc);

  return(0);
} /*end of send_data()*/



int xsmit_data(char *s)
{

 while(*s) {
   send_data(*s);
   s++;
 }

 return(0);
} /*end of xsmit_data()*/



int close_com_port()
{
 disable();	/*CLI*/

 if(com_has_set) {
   setvect(intr_com,old_int);
   outportb(PIC_8259,inportb(PIC_8259) | (0xff ^ irq_mask) ); /*disable IMR*/
   com_has_set=FALSE;
 }

 enable();	/*STI*/

 return(0);
} /*end of close_com_port()*/
