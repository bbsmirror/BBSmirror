/*
  PSI version RS232C Interface by Samson Chen

  This program was derived from original tcp_pc.c, so the function names
  are like it was in TCP/IP version, please do not be confused.

  PSI Handshaking:
	1. PSI Client submit a command '\npsi <PBBS_SERVER> <PBBS_PORT>\n'
	2. psi try to init terminal and connect to PBBS_SERVER
	3. if ok, psi send ASC(255) to PSI Client
	4. if failed, psi send ASC(254) to PSI Client
	5. PSI Client ignore all chars except ASC(254) and ASC(255)
	6. if PSI Client get ASC(254), abort
	7. if PSI Client get ASC(255), send back one ASC(255)
	8. PSI Client send back ^C or ^X to stop psi on unix
	9. start PSI session
*/

/*--- head files ---*/
#include <dos.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "proto.h"
#include "msg.h"

/*--- constant definitions ---*/
#define TRUE	-1
#define FALSE	0

/* number of ^X to terminate program */
#define TERMINATED_CTRL_X_SEQ	5
#define char_CTRLX		24
/**********************/

#include "rs232c.c"                     /*include RS232C library*/

/* local global vars */
int com;

/*********************/

/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/

/*
	tcp_get --- read tcp socket
*/
int tcp_get(char *buf, int maxn)
{
  unsigned char chr;
  int cnt=0;

  while( buffer_empty() ) kbhit();

  do
  {
    chr=recv_data();
    buf[cnt++]=chr;

    if( psi_terminated )
    {
      printf("\n");
      printf("Server send %d ^X to close PSI session!\n", TERMINATED_CTRL_X_SEQ);
      return(-1);
    }

  }while( !buffer_empty() && cnt<maxn);

  return(cnt);

}
/*end of tcp_get*/



/*
	tcp_get_nowait --- read socket without blocking
*/
int tcp_get_nowait(char *buf, int maxn)
{
  int status;
  int ret;
  char *errmsg;


  if( buffer_empty() )
	return(0);

  if( psi_terminated )
  {
    printf("\n");
    printf("Server send %d ^X to close PSI session!\n", TERMINATED_CTRL_X_SEQ);
    return(-1);
  }

  ret=tcp_get(buf, maxn);

  return(ret);

}
/*end of tcp_get_nowait*/



/*
	tcp_put --- write socket
*/
int tcp_put(char *buf, int tn)
{
  int bytes_to_send = tn;
  int packet_size;
  char *cp=buf;

  /*
     sends packets each of size PACKET_SIZE or less.
     PACKET_SIZE and send_packet() are defined in rs232c.c
  */
  while (bytes_to_send > 0) {
    packet_size = (bytes_to_send>PACKET_SIZE) ? PACKET_SIZE : bytes_to_send;
    /*
       if our buffer has more than PACKET_SIZE bytes
       send a packet of size PACKET_SIZE  else
       send a packet of all the bytes left in buffer
    */
    send_packet(cp,packet_size);
    bytes_to_send -= packet_size;
    cp += packet_size;
  }

  return(tn);
}
/*end of tcp_put*/



/*
	put data directly(handshaking)
*/
hs_put(char *buf, int tn)
{
  int cnt;

  for(cnt=0; cnt<tn; cnt++)
     send_data(buf[cnt]);
  buffer_empty();

  return(tn);
}
/*hs_put*/



/*
	get data directly(handshaking)
*/
int hs_get(char *buf, int maxn)
{
  unsigned char chr;
  int cnt=0;

  while( buffer_empty() ) kbhit();

  do
  {
    chr=recv_data();
    buf[cnt++]=chr;

    if( psi_terminated )
    {
      printf("\n");
      printf("Server send %d ^X to close PSI session!\n", TERMINATED_CTRL_X_SEQ);
      return(-1);
    }

  }while( !buffer_empty() && cnt<maxn);

  return(cnt);

}
/*end of hs_get*/



/*
	ctrl-break handle
*/
int cbrk_handler()
{
  int cnt;

  /*wait for CTS for 3 seconds if not set (flow control)*/
  printf("\n");
  printf("Send ^X stop sequence");
  cnt=0;
  while(cnt<3 && !CTS_set())
  {
     cnt++;
     sleep(1);
     printf(".");
  }
  for( ; cnt<3; cnt++)
    printf(".");

  printf("\n");

  /*output stop sequence ^X*/
  send_data_no_flow_control(3); /*send a ctrl-c(useful before PSI handshaking)*/
  for (cnt=0; cnt<=TERMINATED_CTRL_X_SEQ; cnt++)
     send_data_no_flow_control(char_CTRLX);
  send_data_no_flow_control(10);/*send a nl to go to go to next command prompt*/

  printf("User Break!\n");
  end_tcp();
  return(0);
}
/*end of cbrk_handler*/



/*
	end_tcp --- end all network sessions (include UDP)
*/
void end_tcp()
{
  close_com_port();
  if( success_then_remove )
  {
	printf("%s %s, %s", S_T_R_MSG, s_t_r_filename, PRESSANYKEY);
	success_then_remove=FALSE;
	readkey();
  }
}
/*end of end_tcp*/



/*
	connectTCP --- connect to com port (PSI)
*/
int connectTCP(comport, baudrate)
char *comport ;
char *baudrate ;
/*
	return: TRUE	connection successfully
		FALSE	connection failed
*/
{
  com=atoi(comport);

  if( open_com_port(com,atol(baudrate),0,8,1) )
  {
	printf("Open com port %d error!\n", com);
	return(FALSE);
  }

  ctrlbrk(cbrk_handler);
  atexit(end_tcp);

  return(TRUE);
}
/*end of connectTCP*/



/*
	terminate session by ^X's
*/
void terminate_com(void)
{
  int cnt;

  /*wait for CTS for 3 seconds if not set (flow control)*/
  printf("\n");
  printf("Send ^X stop sequence");
  cnt=0;
  while(cnt<3 && !CTS_set())
  {
     cnt++;
     sleep(1);
     printf(".");
  }
  for( ; cnt<3; cnt++)
    printf(".");

  printf("\n");

  /*output stop sequence ^X*/
  send_data_no_flow_control(3); /*send a ctrl-c(useful before PSI handshaking)*/
  for (cnt=0; cnt<=TERMINATED_CTRL_X_SEQ; cnt++)
     send_data_no_flow_control(char_CTRLX);
  send_data_no_flow_control(10);/*send a nl to go to go to next command prompt*/
  buffer_empty();
  sleep(5);
  clear_buffer();
}
/*end of terminate_com*/
