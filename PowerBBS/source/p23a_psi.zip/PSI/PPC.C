/***************************************************************
    ppc.c	(for PC + Dos)

    To connect the BBS server.
    write by Aquarius Kuo(cs79026@chpi.edu.tw)
    1993.11.24.
    program was developed under Turbo C V1.0

    version 2.0 was remodified by Samson Chen Nov 12, 1994
    program was developed under Borland C++ V3.1
    Nov 21, 1994 modified
    Dec 3, 1994
    Version 2.01 Dec 9, 1994
    Version 2.1 Apr 1, 1995
    Version 2.2 Apr 22, 1995
    Version 2.2a May 30, 1995

    PSI Version by Samson Chen
    2.2a Jun 3, 1995
    2.2b Aug 9, 1995
    2.3a Jan 12, 1996
    2.3a1 Feb 17, 1996

    Trademarks:

	Borland C++ is a registered trademark of Borland International.

	Waterloo TCP Library is a registered trademark of
	Waterloo TCP Architect, Erick Engelke.

	MS-DOS is a registered trademark of Microsoft.

	Turbo C is a registered trademark of Borland International.

	SPAWNO is a copyright of Ralf Brown.

*****************************************************************/
#include <ctype.h>
#include <conio.h>
#include "pcpbbs.h"
#include "proto.h"
#include "msg.h"

#define LEFT	'{'
#define RIGHT	'}'
#define SEP	'|'
#define VERSION  (char) 0x23		/*protocol version 2.1*/
#define PLATFORM (char) 2		/*MS-DOS platform number*/

#define DISCARD_PORT		9	/*discarding service*/

/*
    Note: ASC(253) PSI_START can be ASC(255), too. Some system like
	  Solaris 2.x cannot send ASC(255), so we changed the hand-
	  shaking char to ASC(253)
*/
#define PSI_START	253		/*for PSI Handshaking*/
#define PSI_ABORT	254		/*		     */
#define PSI_START_OLD	255

unsigned extern _stklen=30000 ;

static char rcsid[]="$Id$" ;

/*	global vars declared here */
unsigned int DEFAULT_TIMEOUT;

/*--- Prompt the screen ---*/
char	SELECTMSG[80];

int PBBS_DEFAULT_PORT;
char PBBS_DEFAULT_SERVER[80];
char pbbs_psicmd[40];
int term_mode=0, slipper_mode=0, time_polling=0 ;
int mouse_mode=0;
int slip_fd;
int mono;
char capfn[80] ;
char editor[80];
char telnet_path[80];
char show_readmpf_status=FALSE;
int intrread_point=0;
char success_then_remove=FALSE;
char s_t_r_filename[80];
char iread_mark[51];
char comport[10];
char baudrate[10];
char psi_terminated;

/*for multi-layer INTRSEL point stack*/
int isel_point_stk[256];  /*ASC 49 (1) --- ASC 255 : 207 layers max*/



char downpath[80];
char temppath[80];


/*WATTCP user initial*/
static void my_init(char *name, char *value)
{
  if( !strcmp(name, "PBBS_EDIT") )
  {
	strcpy(editor, value);
  }
  else if( !strcmp(name, "PBBS_DOWNPATH") )
  {
	strcpy(downpath, value);
  }
  else if( !strcmp(name, "PBBS_TEMPPATH") )
  {
	strcpy(temppath, value);
  }
  else if( !strcmp(name, "PBBS_TERMMODE") )
  {
	if( !stricmp(value, "YES") )
		term_mode=1;
  }
  else if( !strcmp(name, "PBBS_MONO") )
  {
	if( !stricmp(value, "YES") )
		mono=1;
	else
		mono=0;
  }
  else if( !strcmp(name, "PBBS_MOUSE") )
  {
	if( !stricmp(value, "NO") )
		mouse_mode=0;
  }
  else if( !strcmp(name, "PBBS_SERVER") )
  {
	strcpy(PBBS_DEFAULT_SERVER, value);
  }
  else if( !strcmp(name, "PBBS_PORT") )
  {
	PBBS_DEFAULT_PORT=atoi(value);
  }
  else if( !strcmp(name, "PBBS_COM") )
  {
	strcpy(comport, value);
  }
  else if( !strcmp(name, "PBBS_BAUD") )
  {
	strcpy(baudrate, value);
  }
  else if( !strcmp(name, "PBBS_PSICMD") )
  {
	strcpy(pbbs_psicmd, value);
  }
}
/*end of my_init*/



/* get config from WATTCP.CFG */
void get_config(arg)
char *arg;
{
  int cnt;
  char *path;
  char line[100];
  char watcfg[100];
  FILE *fp;
  char envname[128];		/* new, temporarily save env name */
  char envval[128];		/* new, temporarily save env value */
  char *sptr;			/* new, string pointer */

  if ((path = getenv("WATTCP.CFG")) != NULL )
  {
    strcpy(line, path);
    cnt=strlen(line)-1;
    if(line[cnt]=='\\')
      line[cnt]=0;
  }
  else
  {
    strcpy(line, arg);
    cnt=strlen(line)-1;
    while(cnt>=0)
    {
      if(line[cnt]=='\\')
      {
	line[cnt]=0;
	break;
      }
      cnt--;
    }
  }

  sprintf(watcfg, "%s\\WATTCP.CFG", line);

  if((fp=fopen(watcfg,"r"))==NULL)
   {
    printf("Can't open %s !! \n\7\n", watcfg);
    exit(1);
   }

   fgets(line, 100, fp);
   do
   {
    sptr=strchr(line,'=');
    if( sptr==NULL ) continue;
    sptr++;
    while ((*sptr)==' ' || (*sptr)=='\t') sptr++;   /* remove SPACE & TAB */

    /*strip CR-NL*/
    cnt=strlen(sptr)-1;
    while(cnt>=0)
    {
      if(sptr[cnt]!=0xd && sptr[cnt]!=0xa)
	break;

      sptr[cnt]=0;
      cnt--;
    }

    strcpy(envval,sptr);
    sptr=line;
    while ((*sptr)==' ' || (*sptr)=='\t') sptr++;   /* remove SPACE & TAB */
    strcpy(envname,strtok(sptr,"="));
    if(envname[0]=='#') continue;
    sptr=strchr(envval, '#');
    if( sptr ) *sptr='\0';

    /*strip SPACE and TAB*/
    cnt=strlen(envval)-1;
    while(cnt>=0)
    {
      if(envval[cnt]!=' ' && envval[cnt]!='\t')
	break;

      envval[cnt]=0;
      cnt--;
    }

    strupr(envname);
    my_init(envname, envval);
  } while(fgets(line, 100, fp));
  fclose(fp);

}
/*end of get_config*/
/*************************************************************************/
/*************************************************************************/
/*************************************************************************/
/*
	Upload psi.c to remote program
*/
upload_psi(void)
{
  FILE *psi_src;
  char line[256], cmd[128], chr;
  char is_empty;

  if( (psi_src=fopen("psi.c", "rt"))==(FILE*)NULL )
  {
    printf("  cannot open 'psi.c' !?\n");
    return(FALSE);
  }

  printf("Use COM%d:%ld,N,8,1\n\r", atoi(comport), atol(baudrate));

  if( !connectTCP(comport, baudrate) )
  {
      printf("Can not open com port!\n");
      return(FALSE);
  }

  /*do not use psi error-free format*/
  set_psi_format(FALSE);

  printf("\n\n\n");

  /*start cat command*/
  sprintf(cmd, "       %c", 10);
  hs_put(cmd, strlen(cmd));
  sprintf(cmd, "cat > %s.c%c", pbbs_psicmd, 10);
  hs_put(cmd, strlen(cmd));

  /*transfer psi.c*/
  fgets(line, 255, psi_src);
  do
  {
    hs_put(line, strlen(line));
    while( !buffer_empty() )
    {
      hs_get(&chr, 1);
      switch(chr)
      {
      case 10:
	printf("\n\r");
	break;
      default:
	printf("%c", chr);
	break;
      }/*end switch*/
    }/*end while*/
  }while(fgets(line, 255, psi_src));
  fclose(psi_src);

  send_data(4); 	/*send ^D to save*/

  is_empty=0;
  while(is_empty<=2)
  {
    while( !buffer_empty() )
    {
      is_empty=0;
      hs_get(&chr, 1);
      switch(chr)
      {
      case 10:
	printf("\n\r");
	break;
      default:
	printf("%c", chr);
	break;
      }/*end switch*/
    }/*end while*/

    if( buffer_empty() )
      is_empty++;
    sleep(1);
  }/*end while(is_empty)*/

  /*clear keyborad buffer*/
  while(kbhit()) getch();

  printf("\n\n\n");
  printf("Transfer Complete!\n");
  printf("===========================================================\n");
  printf("Enter to Dump Terminal Mode, Please compile psi.c manually!\n");
  printf("===========================================================\n");
  printf("Press Ctrl-Q to exit!\n");

  send_data(10);	/*send a \n*/

  chr=0;
  do
  {
    while( !buffer_empty() )
    {
      hs_get(&chr, 1);
      switch(chr)
      {
      case 10:
	printf("\n\r");
	break;
      default:
	printf("%c", chr);
	break;
      }/*end switch*/
    }/*end while*/

    if( kbhit() )
    {
      chr=getch();
      if( chr==17 )
	continue;	/*exit*/
      send_data(chr);
    }
  } while(chr!=17);	/*^Q to exit*/

  end_tcp() ;
  return(TRUE);
}
/*end of upload_psi*/



/*
	dumb terminal
*/
dumb_terminal(void)
{
  char chr;

  printf("Use COM%d:%ld,N,8,1\n\r", atoi(comport), atol(baudrate));

  if( !connectTCP(comport, baudrate) )
  {
      printf("Can not open com port!\n");
      return(FALSE);
  }

  /*do not use psi error-free format*/
  set_psi_format(FALSE);

  /*dumb terminal*/
  printf("============================\n");
  printf("Enter to Dump Terminal Mode!\n");
  printf("============================\n");
  printf("Press Ctrl-Q to exit!\n");

  chr=0;
  do
  {
    while( !buffer_empty() )
    {
      hs_get(&chr, 1);
      switch(chr)
      {
      case 10:
	printf("\n\r");
	break;
      default:
	printf("%c", chr);
	break;
      }/*end switch*/
    }/*end while*/

    if( kbhit() )
    {
      chr=getch();
      if( chr==17 )
	continue;	/*exit*/
      send_data(chr);
    }
  } while(chr!=17);	/*^Q to exit*/

  end_tcp() ;
  return(TRUE);
}
/*end of dumb_terminal*/



/*
	Make PowerBBS Session
*/
make_pbbs_session(ipaddr, bbsport)
  char *ipaddr;
  int bbsport;
{
  char buffer[256] ;
  long len ;
  char prot ;
  int ret ;
  char psi_cmd[128];
  unsigned char psi_start=PSI_START, psi_start_old=PSI_START_OLD;
  unsigned char chr;
  char has_got_first_nl=FALSE;
  char quit;

  /*do not use psi error-free format*/
  set_psi_format(FALSE);

  /****************************************************/
  /*send '\n<pbbs_psicmd> <pbbs_server> <pbbs_port>\n'*/
  /****************************************************/
  /*
    '+' is the reactive sign. PSI client has no way to find if remote psi
    server is in TERMMODE. '+' will make TERMMODE psi resend PSI_START to
    active PSI Client. But '+' will useless in command prompt.
  */
  sprintf(psi_cmd, "       %c", 10);
  hs_put(psi_cmd, strlen(psi_cmd));
  sprintf(psi_cmd, "%s %s %d +%c", pbbs_psicmd, ipaddr, bbsport, 10);
  hs_put(psi_cmd, strlen(psi_cmd));

  /*****************/
  /*PSI handshaking*/
  /*****************/
  printf("-------------------- Communication Port Monitor -------------------\n\r");
  quit=FALSE;
  while(!quit)
  {
    hs_get(&chr, 1);
    switch(chr)
    {
    case 10:
	if( has_got_first_nl )
	  printf("\n\r");
	else
	  has_got_first_nl=TRUE;
	break;
    case PSI_ABORT:
	printf("\n\r");
	printf("PSI Session Abort...\n\r");
	exit(2);
	break;
    case PSI_START:
	/*switch psi format on*/
	set_psi_format(TRUE);
	sleep(1);
	hs_put(&psi_start, 1);		/*send back psi_start*/
	quit=TRUE;
	break;
    case PSI_START_OLD: 		/*remote use old psi server*/
	/*switch psi format on*/
	set_psi_format(TRUE);
	sleep(1);
	hs_put(&psi_start_old, 1);	/*send back psi_start_old*/
	quit=TRUE;
	break;
    default:
	if( has_got_first_nl )
	  printf("%c", chr);
	break;
    }/*end switch*/
  }/*end while*/

  printf("\n\r");
  printf("----------------------- PSI Handshaking OK ------------------------\n\r");

  /*********************/
  /*handshaking session*/
  /*********************/
  strcpy(buffer,"Samson") ;
  if(send_mpf(buffer,strlen(buffer),SESSION)<0)
  {
      printf("(send) PBBS Session 1 error!\n");
      end_tcp() ;
      exit(2);
  }

  ret=read_mpf(buffer,&len,&prot,FALSE) ;

  if( ret<0 )
  {
      printf("(send) PBBS Session 2 error!\n");
      end_tcp() ;
      exit(3);
  }

  buffer[len]=0 ;
  if(strcmp("Aquarius",buffer))
  {
    printf("PowerBBS handshaking error!\n") ;
    end_tcp();
    exit(5);
  }
  buffer[0]=VERSION ;	      /* VER_HIGH<<4+VER_LOW ;*/
  buffer[1]=(PLATFORM<<4)+0 ;	/* 1*16+0 ;*/
  strcpy(&buffer[2],"POWERBBS") ;
  send_mpf(buffer,10,SESSION) ;

  return(0);
}
/*end of make_pbbs_session*/
/*************************************************************************/



/*========================Main program ============================*/
void main(argc,argv)
int argc;
char *argv[];
{
  int gdriver, gmode, gerrcode;
  unsigned int original_timeout;
  long len, read_len ;
  char prot ;
  char ipaddr[50] ;
  int  bbsport ;
  char *buffer, pwbuffer[20] ;
  char *intrread_buf, *intrsel_buf;
  char menu_buf[2048];
  char menu_protocol[80];
  char key ;
  int quit, out_getkey, i, tcpstat ;
  struct time now, wait_time ;
  int mils, cnt, ret ;
  char LOCAL_DIR[80] ;
  char header[500] ;
  char file_prepart[9];
  char file_postpart[4];
  char *token;
  struct text_info ti;
  int fore_color, back_color;
  char crlf[3];
  char *site;
  char *login;


  printf("\nPowerBBS PC-Client by Aquarius Kuo, PBBSWare Group.\n");
  printf("%s", CLIENT_VER_NOTE2);

  /*initial global vars*/
  editor[0]=0;
  downpath[0]=0;
  temppath[0]=0;
  PBBS_DEFAULT_PORT=6203;
  strcpy(PBBS_DEFAULT_SERVER, "140.126.3.111");
  strcpy(pbbs_psicmd, "psi");
  strcpy(telnet_path, "telnet %1");
  strcpy(comport, "2");
  strcpy(baudrate, "19200");
  psi_terminated=FALSE;


  /*test mouse*/
  mouse_mode=mouse_init();
  if( mouse_mode )
  {
	set_mouse_cursor(0,0);
	hide_mouse_cursor();
  }

  /*test display hardware*/
  detectgraph(&gdriver, &gmode);
  gerrcode=graphresult();
  if( gerrcode==0 )	/*detectgraph ok*/
  {
	switch(gdriver)
	{
	case 2: /*MCGA*/
	case 5: /*EGAMONO*/
	case 7: /*HERCMONO*/
		mono=1;
		break;

	default:
		mono=0;
		break;
	}
  }
  else			/*detectgraph failed --- default mono display*/
	mono=1;


  /*read setup in WATTCP.CFG*/
  /*config file and TCP API initial*/
  get_config(argv[0]);

  /*make remote psi server*/
  if(argc>1)
  {
    if( !strcmp(argv[1], "/upload_psi" ) )
    {
      upload_psi();
      exit(0);
    }

    if( !strcmp(argv[1], "/dumb_term" ) )
    {
      dumb_terminal();
      exit(0);
    }
  }

  /*initial SPAWNO*/
  /*it's too hard to handle hooked int in spawning*/
  __spawn_resident = (unsigned long) 5120;	/*keep 80K*/
  init_SPAWNO(temppath,SWAP_ANY) ;

  /*get argv*/
  if(argc>1)
  {
      if( argv[1][0]=='/' || argv[1][0]=='?' )
      {
	printf("Syntax:\n\r") ;
	printf("   %s [ip_addr | domain_name] [port]\r\n", argv[0]) ;
	printf("   %s /upload_psi\r\n", argv[0]) ;
	printf("   %s /dumb_term\r\n\n", argv[0]) ;
	exit(1) ;
      }
  }

  if(argc>1)
  {
    strcpy(ipaddr,argv[1]) ;
  }
  else
    strcpy(ipaddr, PBBS_DEFAULT_SERVER);

  if(argc>2)
  {
    bbsport=atoi(argv[2]) ;
    if(bbsport<=0)
      bbsport=PBBS_DEFAULT_PORT ;
  }
  else
    bbsport=PBBS_DEFAULT_PORT ;

  /*allocate memory, must use Model Large to compile this*/
  buffer=(char *) farmalloc(MAX_BUF) ;
  intrread_buf=(char *) farmalloc(BACK_BUF) ;
  intrsel_buf=(char *) farmalloc(BACK_BUF) ;
  printf("Memory left %ld\r\n",farcoreleft()) ;

  if( mono )
	printf("MONO display\n");
  else
	printf("COLOR display\n");

  printf("Use COM%d:%ld,N,8,1\n\r", atoi(comport), atol(baudrate));

  if( !connectTCP(comport, baudrate) )
  {
      printf("Can't connect to PowerBBS Shell Interface server!\n");
      exit(1) ;
  }

  make_pbbs_session(ipaddr, bbsport);

  /* initial isel_point_stk */
  for(cnt=0; cnt<256; cnt++)
	isel_point_stk[cnt]=0;

  /*--- init variable ---*/
  quit=FALSE ;

  if( strlen(downpath)<=0 )
    LOCAL_DIR[0]=0 ;
  else
    strcpy(LOCAL_DIR, downpath) ;

  strcpy(capfn, "CAP.TXT") ;

  /***********************************/
  /*INTRSELECT/INTRREAD TITLE MESSAGE*/
  /***********************************/
  strcpy(SELECTMSG,   "PowerBBS PC Client Menu Selection") ;

  /********************/
  /*get original color*/
  /********************/
  gettextinfo(&ti) ;
  fore_color=ti.normattr & 15 ;
  back_color=(ti.normattr >> 4 ) & 7 ;

  /*set WHITE-BLACK */
  textbackground(BLACK);
  textcolor(LIGHTGRAY);
  lowvideo();

  /*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/

  do
  {
    original_timeout=DEFAULT_TIMEOUT;
    DEFAULT_TIMEOUT=0;	/*block MPFread in transaction get*/

    tcpstat=read_mpf(buffer,&len,&prot,FALSE);

    DEFAULT_TIMEOUT=original_timeout;

    if( success_then_remove )
    {
	success_then_remove=FALSE;
	unlink(s_t_r_filename);
    }

    if(tcpstat==1)
    {
      if(len>MAX_BUF)
	len=MAX_BUF-1 ;

      buffer[len]=0 ;
      switch(prot)
      {
	case ASK:
	  show(buffer) ;
	  i=strlen(buffer) ;
	  buffer[0]=0 ;
	  i=getstring(-1,-1,buffer,79-i,1) ;
	  show("\n") ;
	  send_mpf(buffer,i,ASK) ;
	  break ;
	/*-------------------------------------------------------*/
	case BYEBYE:
	  quit=TRUE ;
	  break ;
	/*-------------------------------------------------------*/
	case DISPLAY:
	  clear_esc(buffer) ;
	  show(buffer) ;
	  break ;
	/*-------------------------------------------------------*/
	case ERROR:
	  show(buffer) ;
	  /*quit=TRUE ;*/
	  break ;
	/*-------------------------------------------------------*/
	case FILEPOST:
	  if( term_mode )	/* not support under terminal mode */
	  {
	    show(FDISABLE) ;
	    send_mpf(buffer,1,STOPPOST) ;
	    readkey() ;
	    break ;
	  }
	  show(ASKFILENAME) ;
	  buffer[0]=header[0]=0 ;
	  if(getstring(-1,-1,header,30,1)<1)
	  {
	    send_mpf(buffer,1,STOPPOST) ;
	  }
	  else
	  {
	    if( get_file(header,buffer) )
	    {
	      show(EDITCONFIRM) ;
	      do
	      {
		key=tolower(readkey()) ;
		if(key=='e')
		{
		  if(writer(buffer)==FALSE)
		  {
		    send_mpf(buffer,1,STOPPOST) ;
		    break ;
		  }
		  else
		  {
		    show(EDITCONFIRM) ;
		  }
		}
	      }
	      while( (key!='p') && (key!='a') ) ;
	      printf("%c",key) ;
	      fflush(stdout) ;
	      if(key=='p')
	      {
		send_mpf(buffer,strlen(buffer),MAKEPOST);
		break ;
	      }
	      else
	      {
		if(key=='a')
		{
		  send_mpf(buffer,1,STOPPOST) ;
		  break ;
		}
	      }
	    }
	    else
	    {
	      show("\n\n") ;
	      show(FNOTFOUND) ;
	      readkey() ;
	      send_mpf(buffer,1,STOPPOST) ;
	    }
	  }
	  break ;
	/*-------------------------------------------------------*/
	case FILEXFER:	/*DOWNLOAD*/
	  if(term_mode==1)
	  {
		send_mpf(" ",1,STOPXFER) ;
		show("\n") ;
		show(FDISABLE) ;
		show(PRESSANYKEY) ;
		user_confirm();
		show("\n") ;
	  }
	  else
	  {

	    /*analyze filename, maybe it just fit UNIX style*/
	    memset(file_prepart, 0, 9);
	    memset(file_postpart, 0, 4);
	    token=strtok(buffer, ".");
	    if( token )
	    {
		  strncpy(file_prepart, token, 8);
		  token=strtok(NULL, ".");
	    }
	    else
		  strncpy(file_prepart, buffer, 8);

	    if( token )
		  strncpy(file_postpart, token, 3);

	    strcpy(buffer, file_prepart);

	    if( strlen(file_postpart)>0 )
	    {
		  strcat(buffer, ".");
		  strcat(buffer, file_postpart);
	    }

	    if( LOCAL_DIR[0]!=0 )
	    {
	      strcpy(buffer+1024, buffer) ;
	      strcpy(buffer,LOCAL_DIR) ;
	      if( LOCAL_DIR[strlen(LOCAL_DIR)-1]!='\\' && LOCAL_DIR[strlen(LOCAL_DIR)-1]!=':' )
		strcat(buffer,"\\") ;
	      strcat(buffer,buffer+1024) ;
	    }

	    if(download(buffer,2)==FALSE)
	      show(" ")  ;

	  }/*end if-else (termmode)*/

	  break ;
	/*-------------------------------------------------------*/
	case GETFILE:	/*UPLOAD*/
	  if(term_mode==1)
	  {
		send_mpf(" ",1,STOPXFER) ;
		show("\n") ;
		show(FDISABLE) ;
		show(PRESSANYKEY) ;
		user_confirm();
		show("\n") ;
	  }
	  else
	  {
		if(get_filename(buffer)==FALSE)
		{
		    send_mpf(" ",1,STOPXFER) ;
		}
		else
		{
		    upload(buffer,2) ;
		    show("\n") ;
		}
	  }
	  break ;
	/*-------------------------------------------------------*/
	case INTERNET:
	  /*..............................................*/
	  /*INTERNET Protocol Format:			  */
	  /*   "<site IP or domain>\crlf<login name>\crlf"*/
	  /*   if <login name>=="PowerBBS" then PowerNet  */
	  /*   site format: "<site address> <port number>"*/
	  /*..............................................*/
	  if(term_mode==1)
	  {
		show("\n") ;
		show(FDISABLE) ;
		show(PRESSANYKEY) ;
		user_confirm();
		show("\n") ;
	  }
	  else
	  {
	    sprintf(crlf,"%c%c",13,10) ;
	    site=kkytok(buffer,crlf) ;
	    login=kkytok(NULL,crlf) ;

	    if( !strcmp(login, "PowerBBS") )
	    {
	       /* PowerNET */
	       for(cnt=0; cnt<strlen(site); cnt++)
	       {
		 if( *(site+cnt)==' ')
		 {
		   *(site+cnt)=0;
		   login=site+cnt+1;
		   break;
		 }
	       }

	       terminate_com();

	       show("\nTry to connect to PowerBBS site ");
	       show(site);
	       show(".");

	       if( atoi(login)>0 )
	       {
		 show(login);
		 show("\n");
		 make_pbbs_session(site, atoi(login) );
	       }
	       else
	       {
		 show("6203");
		 show("\n");
		 make_pbbs_session(site, 6203);
	       }
	    }
	    else
	    {
	       /* Internet */
		internet(site, login);
		/*internet() is a never-return call in PC client*/
	    }
	  }
	  break;
	/*-------------------------------------------------------*/
	case INTRREAD:

	  if( !strcmp(buffer, "SAME_BUFFER") )
	  {
		/*if Server send "SAME_BUFFER",
		  client should use the previous one*/

		strcpy(buffer, intrread_buf);
	  }
	  else
	  {
		/*else backup the current,
		  maybe next time will use it*/

		strcpy(intrread_buf, buffer);
	  }

	  if((cnt=postlist(buffer, 1))>0)
	  {
	    sprintf(buffer,"%d",cnt) ;
	    send_mpf(buffer,strlen(buffer),INTRREAD) ;
	  }
	  else
	  {
	    send_mpf(buffer,1,INTRREAD) ;
	  }
	  break ;
	/*-------------------------------------------------------*/
	case INTRSEL:

	  if( !strcmp(buffer, "SAME_BUFFER") )
	  {
		/*description is same as INTRREAD, but for INTRSEL*/
		strcpy(buffer, intrsel_buf);
	  }
	  else
	  {
		strcpy(intrsel_buf, buffer);
	  }

	  if((cnt=postlist(buffer, 2))>0)
	  {
	    sprintf(buffer,"%d",cnt) ;
	    send_mpf(buffer,strlen(buffer),INTRSEL) ;
	  }
	  else
	  {
	    send_mpf(buffer,1,INTRSEL) ;
	  }
	  break ;
	/*-------------------------------------------------------*/
	case MAKEPOST:
	  do
	  {
	    if(writer(buffer)==FALSE)
	    {
	      send_mpf(buffer,1,STOPPOST) ;
	      break ;
	    }
	    else
	    {
	      show(EDITCONFIRM) ;
	      do
	      {
		key=tolower(readkey()) ;
	      }
	      while((key!='p')&&(key!='e')&&(key!='a')) ;
	      printf("%c",key) ;
	      fflush(stdout) ;
	      if(key=='p')
	      {
		send_mpf(buffer,strlen(buffer),MAKEPOST) ;
		break ;
	      }
	      else
	      {
		if(key=='a')
		{
		  send_mpf(buffer,1,STOPPOST) ;
		  break ;
		}
	      }
	    }
	  }
	  while(key=='e') ;
	  break ;
	/*-------------------------------------------------------*/
	case MENU:
	  if( strlen(buffer)>0 )	/*new menu sent*/
		strncpy(menu_buf, buffer, 1632);

	  show("{#c#}");        /*clrscr*/
	  normal_text();
	  show(menu_buf) ;

	  out_getkey=FALSE ;
	  do	/*--- Check the input key ---*/
	  {
	    key=pop_menu();

	    if( !term_mode )
	    {
	      if( key==15 )	   /* ctrl-O : set local directory path */
	      {
		show("\n\n") ;
		show(DOWNPATH) ;
		getstring(-1,-1,LOCAL_DIR,60,1) ;
		show("{#c#}");
		normal_text();
		show(menu_buf) ;
		continue ;
	      }

	      if( key==4 )	  /* ctrl-D : shell to dos */
	      {
		show("\ntype 'EXIT' to go back to PowerBBS!\n");
		system(getenv("COMSPEC")) ;
		show("{#c#}");
		normal_text();
		show(menu_buf) ;
		if(mouse_mode)
		  mouse_mode=mouse_init();	/*reinitial mouse driver*/
		continue ;
	      }
	    }

	    out_getkey=map_key_menuprotocol(menu_protocol, key);

	    if( out_getkey )
	    {
	      if( !strcmp(menu_protocol, "{Ping}") )
		  gettime(&wait_time) ;

	      if( !strcmp(menu_protocol, "{Version_Info}") )
	      {
		show(CLIENT_VER_NOTE1);
		show(CLIENT_VER_NOTE2);
		show(CLIENT_VER_NOTE3);
	      }

	      /*--- send menu protocol ---*/
	      send_mpf(menu_protocol, strlen(menu_protocol), MENU) ;

	    }/*endif*/

	  } while(!out_getkey) ;
	  cnt=0 ;
	  break ;
	/*-------------------------------------------------------*/
	case PASSWD:
	  show(buffer) ;
	  pwbuffer[0]=0 ;
	  cnt=getstring(-1,-1,pwbuffer,10,2) ;
	  show("\n") ;
	  if(cnt<=0)
	  {
	    send_mpf(pwbuffer,1,PASSWD) ;
	    break ;
	  }
	  /* encoding (algorithms by Aquarius Kuo)*/
	  for(i=strlen(pwbuffer); i<10; i++)
	    pwbuffer[i]=59+i*2 ;
	  pwbuffer[10]=0 ;
	  for(i=1; i<=10; i++)
	  {
	    pwbuffer[i-1]=(char) ((((pwbuffer[i-1]+pwbuffer[10-i])*67)%91)+32) ;
	  }
	  send_mpf(pwbuffer,10,PASSWD) ;
	  cnt=0 ;
	  break ;
	/*-------------------------------------------------------*/
	case PECHO:
	  gettime(&now) ;
	  mils=now.ti_sec*100+now.ti_hund ;
	  mils-=(wait_time.ti_sec*100+wait_time.ti_hund) ;
	  sprintf(buffer,"\n     Ping echo from server in %7.2f seconds\n",(float) mils*0.01) ;
	  show(buffer) ;
	  break ;
	/*-------------------------------------------------------*/
	case POST:
	  if((cnt=parse_header(buffer,header))==FALSE)
	    break ;
	  clrscr() ;
	  strcat(buffer,"\n") ;
	  strcat(buffer,POST_BOTTOM) ;
	  /*clear_esc(buffer) ;*/
	  clear_esc(header) ;
	  i=pager(header,buffer) ;
	  if(i>0)			/*user input a number*/
	  {
	    sprintf(buffer,"%d",i) ;
	    send_mpf(buffer,strlen(buffer),GETPOST) ;
	  }
	  else
	  {
	    if(i==0)			/*quit read*/
	    {
	      send_mpf("q",1,GETPOST) ;
	    }
	    if(i==-1)			/*user response key*/
	    {
	      send_mpf(buffer,1,GETPOST) ;
	    }
	    if(i==-2)			/*--- next post ---*/
	    {
	      sprintf(buffer,"%d",++cnt) ;
	      send_mpf(buffer,strlen(buffer),GETPOST) ;
	    }
	    if(i==-3)			/*--- pre post ---*/
	    {
	      sprintf(buffer,"%d",--cnt) ;
	      send_mpf(buffer,strlen(buffer),GETPOST) ;
	    }
	  }
	  break ;
	/*-------------------------------------------------------*/
	case PROMPT:
	  parse_prompt(buffer) ;
	  break ;
	/*-------------------------------------------------------*/
	case REJECT:
	  quit=TRUE ;
	  write(1,buffer,len) ;
	  break ;
	/*-------------------------------------------------------*/
	case SCRSIZE:
	  sprintf(buffer,"%d",LINES-3) ;
	  send_mpf(buffer,strlen(buffer),SCRSIZE) ;
	  break ;
	/*-------------------------------------------------------*/
	case SUSPEND:
	  show(PRESSANYKEY) ;
	  user_confirm();
	  show("\n") ;
	  break ;
	/*-------------------------------------------------------*/
	case TALK:
	  chat_room(buffer) ;
	  break ;
	/*-------------------------------------------------------*/
	case YESNO:
	  yesno_confirm(buffer);
	  send_mpf(buffer,1,YESNO) ;
	  break;
	/*-------------------------------------------------------*/
	default:
	  sprintf(buffer,"Error protocol : %d\n",prot) ;
	  printf(buffer) ;
	  end_tcp();
	  exit(50);
      }
    }
    else
    {
      if(tcpstat==-1)
      {
	printf("Error tcp communation!!\n") ;
	end_tcp();
	exit(6);
      }
    }
  }
  while(!quit) ;

  end_tcp() ;

  /*restore original color*/
  textbackground(back_color);
  textcolor(fore_color);

}
/*end of main*/
/**************************************************************************/
/**************************************************************************/
/**************************************************************************/
