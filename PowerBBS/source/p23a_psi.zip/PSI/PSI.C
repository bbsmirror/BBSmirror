/***********************************************************************
    PSI.C

    PSI --- the PowerBBS Shell Interface

    version 1.0 written by Lerca Huang (wen@richard.iim.nctu.edu.tw)
    1995.6.2

    version 2.0 revised by Henry Chen (henry@richard.iim.nctu.edu.tw)
    1995.8.3
    1996.1.20

    version 2.1 ASC(255) changed to ASC(253) by Samson Chen
    1996.2.17

    PSI Handshaking:
	1. PSI Client submit a command '\npsi <PBBS_SERVER> <PBBS_PORT>\n'
	2. psi try to init terminal and connect to PBBS_SERVER
	3. if ok, psi send ASC(253) to PSI Client
	4. if failed, psi send ASC(254) to PSI Client
	5. PSI Client ignore all chars except ASC(254) and ASC(253)
	6. if PSI Client get ASC(254), abort
	7. if PSI Client get ASC(253), send back one ASC(253)
	8. PSI Client send back ^C or ^X to stop psi on unix
	9. start PSI session

    Note: ASC(253) PSI_START can be ASC(255), too. Some system like
	  Solaris 2.x cannot send ASC(255), so we changed the hand-
	  shaking char to ASC(253)
***********************************************************************/

/****************************************************/
/*		   for SYSOP setup		    */
/****************************************************/

#define PBBS_DEFAULT_SERVER	"140.126.3.111"
#define PBBS_DEFAULT_PORT	6203

/*uncomment the next line, if you want to cc a TERMMODE PSI*/
/*#define	TERMMODE*/
/****************************************************/

#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef RS6K
#include <sys/select.h>
#endif

#ifndef NOMALLOC
#include <malloc.h>
#endif

#include <sys/resource.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/tcp.h>
#include <signal.h>
#include <errno.h>
#include <fcntl.h>
#include <ctype.h>
#include <memory.h>
#include <sys/file.h>
#include <netdb.h>
#include <time.h>

#include <termios.h>

#ifndef TRUE
#define TRUE	-1
#endif

#ifndef FALSE
#define FALSE	0
#endif

#ifndef INADDR_NONE
#define INADDR_NONE	0xffffffff
#endif

extern int	errno;
#ifdef NETBSD
#else
#ifdef FREEBSD
#else
extern char	*sys_errlist[];
#endif
#endif

#ifdef SYSV
#define bzero(a, b)	memset(a, 0, b) /*SysV do not support bzero*/
#define bcopy(a, b, c)	memcpy(b ,a, c) /*SysV do not support bcopy*/
#endif

#ifndef ALPHA
/*u_short htons();*/
u_long	inet_addr();
#endif

/*save old terminal parameters*/
static struct termios oldterm;

static char rcsid[]="$Id$" ;

/* number of ^X to terminate program */
#define TERMINATED_CTRL_X_SEQ	5

#define PSI_START	253	   /*PSI handshaking code*/
#define PSI_ABORT	254	   /*			 */

/*................................*/
/* for PSI data transfer protocol */
/*................................*/
#define TIMEOUT 	5	/* 5 seconds before timeout */
#define BUFFER_SIZE	8192
#define PACKET_SIZE	1024
#define char_ESCAPE	2
#define char_ETB0	3
#define char_ETB1	4
#define char_ACK0	5
#define char_ACK1	6
#define char_REAC	18
#define char_CTRLX	24

int received_ACK[]={ FALSE,FALSE };			    /* ACK0 & ACK1 */
int wait_ACK=FALSE;				    /* flag of waiting ACK */
time_t start_time;				 /* start time of wait_ACK */
int send_seq=0, recv_seq=0; /* sequence no. for ETB0, ETB1, ACK0, and ACK1 */
int is_escape_char=FALSE; /* true if previous received byte is ESCAPE_CHAR */
unsigned char recv_checksum=0;	      /* checksum for received data stream */
int recv_length=0;	    /* received data length */
int nCTRLX=0;				  /* # countinuous CTRL-X received */
char com_buffer[BUFFER_SIZE];	  /* buffer for data received from tty */
unsigned char is_trans_char[256], trans_map[256], trans_restore[256];

/**************************************************************/
int
connectTCP( host, service)
char *host;
int service;
/*
	return:
		>0	: fd
		-1	: failed
*/
{
	struct hostent	*phe;
	struct servent	*pse;
	struct sockaddr_in	sin;
	int	s;

	bzero((char *)&sin, sizeof(sin));
	sin.sin_family=AF_INET;

	/*map port number*/
	if( (sin.sin_port=htons((u_short)service)) == 0 )
	{
		printf("can't get %s service entry\n\r", service);
		return(-1);
	}

	/*get IP address*/
	if( phe = gethostbyname(host) )
		bcopy(phe->h_addr, (char *)&sin.sin_addr, phe->h_length);
	else if( (sin.sin_addr.s_addr = inet_addr(host)) == INADDR_NONE )
	{
		printf("can't get %s host entry\n\r", host);
		return(-1);
	}

	/*allocate socket*/
	s = socket(PF_INET, SOCK_STREAM, 0);
	if(s<0)
	{
		printf("can't create socket: %s\n\r", sys_errlist[errno]);
		return(-1);
	}

	/*connect the socket*/
	if(connect(s, (struct sockaddr *)&sin, sizeof(sin)) < 0)
	{
		printf("PBBS service may not be available on %s.%d: %s\n\r", host, service, sys_errlist[errno]);
		return(-1);
	}

	return(s);
}
/*end of connectTCP*/



/*
  build char mapping table

  by Samson Chen

	character mapping

	realdata	mapping data
	.................................
	255		1
	9		7
	1		2+1
	2		2+2
	3		2+3
	4		2+4
	5		2+5
	6		2+6
	0		2+10
	7		2+11
	18		2+12
	29		2+13
	157		2+14
	24		2+15

*/
build_mapping_table()
{
  int n;

  memset(is_trans_char, FALSE, 256);
    is_trans_char[0]=TRUE;
    is_trans_char[1]=TRUE;
    is_trans_char[2]=TRUE;
    is_trans_char[3]=TRUE;
    is_trans_char[4]=TRUE;
    is_trans_char[5]=TRUE;
    is_trans_char[6]=TRUE;
    is_trans_char[7]=TRUE;
    is_trans_char[18]=TRUE;
    is_trans_char[29]=TRUE;
    is_trans_char[157]=TRUE;
    is_trans_char[24]=TRUE;

  for(n=0; n<256; n++) trans_map[n]=(unsigned char)n;
    trans_map[0]=10;
    trans_map[1]=1;
    trans_map[2]=2;
    trans_map[3]=3;
    trans_map[4]=4;
    trans_map[5]=5;
    trans_map[6]=6;
    trans_map[7]=11;
    trans_map[18]=12;
    trans_map[29]=13;
    trans_map[157]=14;
    trans_map[24]=15;

  for(n=0; n<256; n++) trans_restore[n]=(unsigned char)n;
    trans_restore[1]=1;
    trans_restore[2]=2;
    trans_restore[3]=3;
    trans_restore[4]=4;
    trans_restore[5]=5;
    trans_restore[6]=6;
    trans_restore[10]=0;
    trans_restore[11]=7;
    trans_restore[12]=18;
    trans_restore[13]=29;
    trans_restore[14]=157;
    trans_restore[15]=24;

  return(0);
}
/*end of build_mapping_table*/



/*
   data transmitter
	for PSI data transfer protocol
	receive data from PBBS server then
	send encoded packet to TTY

   by Henry Chen
*/

unsigned char send_data_map(out_data)
unsigned char out_data;
{
  unsigned char data;

  /* look up our real/tran map table */
  if (is_trans_char[out_data]) {	/* data is in map table */
    data=char_ESCAPE;
    write(1, &data, 1); 		/* send extra escape char */
    data=trans_map[out_data];		/* and the mapped data */
  }
  else
  {
    switch (out_data) {
      case 255:     data=1; break;  /* map 255 to 1 */
      case 9:	    data=7; break;  /* map 9 to 7 */
      default:	    data=out_data;
		    break;  /* no map need */
    }
  }

  return data;
}

send_packet_to_tty(buffer, count)
char *buffer;
int count;
{
  int length=0;
  unsigned char checksum=0;
  unsigned char data;

  wait_ACK=FALSE;	/* and the wait_ACK flag */

  while (length < count) {
    data=buffer[length++];
    checksum ^= data;
    data=send_data_map(data);
    write(1, &data, 1);
  }

  /* send the length, checksum & the ETB */
  data=send_data_map(length%256);
  write(1, &data, 1);
  data=send_data_map(checksum);
  write(1, &data, 1);
  if (send_seq) data=char_ETB1; else data=char_ETB0;
  write(1, &data, 1);

  received_ACK[send_seq]=FALSE; 	/* clear ACK flag */
  start_time=time(NULL);		/* start timeout check */
  wait_ACK=TRUE;			/* M... we are waiting for ACK */

}



/*
  data receiver
	for PSI data transfer protocol
	receive encoded packet from TTY then
	decode and send to PBBS server

  by Henry Chen
*/

send_data_to_server(fd, buf, count)
int fd;
char *buf;
int count;
{
  unsigned char data, ch;
  unsigned char checksum, length; /* records in received packet */
  int data_in;
  int check_data;
  int discard;
  int ip;


  for (ip=0; ip<count; ip++) {
	data=buf[ip];

     data_in=TRUE;
     check_data=FALSE;
     discard=FALSE;

     if (data==char_REAC)
     {
	data_in=FALSE;
     }
     else if (is_escape_char) { 	/* must look up our real/tran map table */

	is_escape_char=FALSE;		/* reset this flag first */
	data=trans_restore[data];	/* the mapped data */

     } else {
       switch (data) {
	 case 1:	 data=255; break;	 /* map 1 to 255 */
	 case 7:	 data=9; break; 	 /* map 7 to 9 */
	 case char_ESCAPE:
	 case char_ETB0:
	 case char_ETB1:
	 case char_ACK0:
	 case char_ACK1: nCTRLX=0; data_in=FALSE; break;
	 default:	 break;
       } /* switch (data) */
     } /* if (is_escape_char) */


     if (data_in) {

	recv_checksum ^= data;
	com_buffer[recv_length++]=data;
	if( recv_length>=BUFFER_SIZE )
	  recv_length=0;

	if (data==char_CTRLX) {

	   nCTRLX++;
	   if (nCTRLX>=TERMINATED_CTRL_X_SEQ)
	       return(FALSE);

	} else {

	  nCTRLX=0;

	} /* endif */

     } else {

       switch (data) {
	 case char_ESCAPE: is_escape_char=TRUE; break;
	 case char_ETB0:
	      if (recv_seq) /* we expect ETB1 so discard the data received */
		 discard=TRUE;
	      else				   /* ETB0 is what we want */
		 check_data=TRUE;
	      break;
	 case char_ETB1:
	      if (recv_seq)			   /* ETB1 is what we want */
		 check_data=TRUE;
	      else	    /* we expect ETB0 so discard the data received */
		 discard=TRUE;
	      break;
	 case char_ACK0:   received_ACK[0]=TRUE; break;
	 case char_ACK1:   received_ACK[1]=TRUE; break;
	 case char_REAC:   break;  /* reactive char, ignore it! */
       } /* swicth (data) */

       if (data==char_ETB0 || data==char_ETB1) {

	  if (check_data) {
	    if( recv_length>2 )
	    {
	      checksum=com_buffer[--recv_length];
	      length=com_buffer[--recv_length];
	      recv_checksum^=checksum;
	      recv_checksum^=length;

	      if (checksum==recv_checksum && length==(unsigned char)recv_length) {
		 write(fd, com_buffer, recv_length); /* send data to server */
		 recv_seq ^= 1; 		/* advance to next pass */
	       }
	       else
		 discard=TRUE;
	    }
	    else
	      discard=TRUE;
	  }

	  /* reset checksum & length */
	  recv_checksum=0;
	  recv_length=0;

	  if (!discard)
	  {
	    /* send ACK0/ACK1 */
	    if (data==char_ETB0 && recv_seq==1) {
	       ch=char_ACK0;
	       write(1, &ch, 1);
	    }
	    if (data==char_ETB1 && recv_seq==0) {
	       ch=char_ACK1;
	       write(1, &ch, 1);
	    }
	  }

       } /* if (data==char_ETB0 || data==char_ETB1) */

     } /* if (data_in) */

  } /* end for(ip=0; data=buf[ip++]; ip<count) */

  return(TRUE);

} /* send_data_to_server */



/*----------------------------------------------------------*/
void psi(fd)
int fd ;
{
  fd_set rset, allset ;
  struct timeval timeout ;
  char quit=FALSE;
  int maxfd ;
  int net_count, tty_count;
  char buf[256];
  char net_buf[BUFFER_SIZE], tty_buf[BUFFER_SIZE];

  /*--- init select I/O ---*/
  maxfd=(fd>fileno(stdin)) ? (fd+1):(fileno(stdin)+1) ;
  FD_ZERO(&allset) ;
  FD_SET(fd,&allset) ;
  FD_SET(fileno(stdin),&allset) ;
  timeout.tv_sec=10 ;
  timeout.tv_usec=0 ;

  while(!quit)	    /* PSI routing mode */
  {
    rset=allset ;
    if( select(maxfd,&rset,NULL,NULL,&timeout)<0 )
    {
      out_terminated_ctrl_x_sequence();
      sprintf(buf, "\r\nI/O select error!!\r\n");
      printf("%s",buf) ;
      fflush(stdout) ;
      break;
    }

    if( FD_ISSET(fd,&rset) )	/*data from network*/
    {
       if (!wait_ACK) {
	 /* we are not waiting for ACK, so read data from network */
	 net_count=read(fd, net_buf, PACKET_SIZE);
	 if(net_count<=0) {
	   out_terminated_ctrl_x_sequence();
	   break;
	 }
	 else {
	   send_packet_to_tty(net_buf,net_count);	/* send data to TTY */
	 }
       }
    }	/* data from network */

    if( wait_ACK )
    {
	 if (received_ACK[send_seq]) {
	   send_seq ^= 1;	/* ACK received, advance to next pass */
	   wait_ACK=FALSE;	/* clear the wait_ACK flag */
	 }
	 else
	   if( (time(NULL)-start_time) > TIMEOUT) { /* timeout */
	     wait_ACK=FALSE;
	     send_packet_to_tty(net_buf,net_count);	/* re-send data */
	   }
    }

    while( (tty_count=read(0, tty_buf, PACKET_SIZE)) > 0 )   /*data from tty*/
    {
      if( !send_data_to_server(fd,tty_buf,tty_count) )
	quit=TRUE;
    }/*end while(read())*/

  }/*end while(!quit)*/

}
/*end of psi*/



/*========================Main program ============================*/
main(argc, argv)
int argc;
char *argv[];
{
  char ipaddr[50] ;
  int  bbsport ;
  unsigned char psi_start=PSI_START, psi_abort=PSI_ABORT;
  unsigned char chr;
  char quit;
  int fd ;

  extern int broken_pipe();	/*when client and server run under the same*/
				/*host, network will use PIPE to communicate*/

  printf("\n\r");
  printf("PowerBBS Shell Interface\n\r") ;
  printf("  by Henry Chen(henry@richard.iim.nctu.edu.tw), PBBSWare Group\n\r");
  printf("  v2.1 Feb 17, 1996.\n\r");
  printf("\n\r");

  /*set default PBBS Server*/
  strcpy(ipaddr, PBBS_DEFAULT_SERVER);
  bbsport=PBBS_DEFAULT_PORT;

#ifndef TERMMODE
  if(argc>1)
  {
    strncpy(ipaddr,argv[1],40) ;
    ipaddr[40]=0 ;
  }

  if(argc>2)
  {
    bbsport=atoi(argv[2]) ;
    if(bbsport<=0)
      bbsport=PBBS_DEFAULT_PORT ;
  }
#endif

  (void) signal(SIGPIPE, (void *) broken_pipe); /*see broken_pipe()*/

  printf("  Trying to connect to %s\n\r", ipaddr);
  fflush(stdout) ;

  fd=connectTCP(ipaddr, bbsport);

  if( init_terminal()<0 )
  {
    printf("  Initialize Noncanonical Terminal Mode Error!?\n\r");
    write(1, &psi_abort, 1);
    fflush(stdout);
  }
  else
  {
#ifdef TERMMODE
    printf("  TERMMODE PSI ON. You can only connect to %s\n\r", ipaddr);
    printf("  Start your PBBSPSI Client Now...\n\n\r");
#endif

    if( fd<0 )	/*connect to PBBS_SERVER error!*/
    {
      write(1, &psi_abort, 1);
      fflush(stdout);
    }
    else
    {
      printf("  PBBS Server connection established!\n\r");
      printf("  If you want to terminate this program, type ^C or %d ^X keys\n\n\r", TERMINATED_CTRL_X_SEQ);

      build_mapping_table();

      write(1, &psi_start, 1);
      fflush(stdout);

      /*waiting for PSI handshaking code from client site*/
      quit=FALSE;
      do
      {
	while(read(0,&chr,1)==0);
	switch(chr)
	{
	case PSI_START:
	  psi(fd);	/*start PSI session*/
	  quit=TRUE;
	  break;
#ifdef TERMMODE
	case '+':
	/*
	 '+' is the reactive sign. PSI client has no way to find if remote psi
	 server is in TERMMODE. '+' will make TERMMODE psi resend PSI_START to
	 active PSI Client. But '+' will useless in command prompt.
	*/
	  write(1, &psi_start, 1);
	  fflush(stdout);
	  break;
#endif
	case 3: 	/*^C*/
	case 4: 	/*^D*/
	case 24:	/*^X*/
	case 26:	/*^Z*/
	case 27:	/*[ESC]*/
	  printf(" PSI Client handshaking error!!!\n\r");
	  fflush(stdout);
	  quit=TRUE;
	  break;
	}
      }while(!quit);

      close(fd);
    }/*end if-else(fd)*/

    end_terminal();

  }/*end if-else(init_terminal)*/

}
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
init_terminal()
{
  struct termios tempio;

  tcgetattr(0, &oldterm);

  /*set to noncanonical mode*/
  tcgetattr(0, &tempio);

  tempio.c_iflag=0;
  tempio.c_oflag=0;
  tempio.c_lflag=0;

  tempio.c_cc[VMIN]=0;		/*return if no char get*/
  tempio.c_cc[VTIME]=0; 	/*wait max n*0.1 second*/

  return( tcsetattr(0, TCSANOW, &tempio) );
}



end_terminal()
{
  tcsetattr(0, TCSANOW, &oldterm);
}



/*
	broken-pipe --- when client and server run under the same host,
			communication will be the pipe. If the pipe was
			broken, this signal will be send.
			So that, read() or write() cannot catch any error
			if server process was terminated, only this signal
			handler can catch this error!

			coded by Samson Chen
*/
broken_pipe()
{
  out_terminated_ctrl_x_sequence();
  end_terminal();
}
/*end of broken_pipe*/



/*
	send termination sequence ^X to psi client
*/
out_terminated_ctrl_x_sequence()
{
  int cnt;
  char chr=24; /*^X*/

  for(cnt=0; cnt<=TERMINATED_CTRL_X_SEQ; cnt++) /* send one more CTRL-X */
    write(1, &chr, 1);

  fflush(stdout) ;
}
/* end of out_terminated_ctrl_x_sequence*/
