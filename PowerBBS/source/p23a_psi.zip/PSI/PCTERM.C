#include <dos.h>
#include <bios.h>
#include <conio.h>
#include <ctype.h>
#include "pcpbbs.h"
#include "msg.h"
#include "proto.h"

#define META_LEFT       "{#"
#define META_RIGHT      "#}"

static char finds[100] ;
static long last_s ;

int getstring(x,y,str,len,gmode)
int x ;
int y ;
char *str ;
int len ;
int gmode ;     /*-- 1: normal, 2: password, 3:number --*/
{
  int i=0 ;
  int otherwise ;
  unsigned int chr ;
  char tmp[81] ;
  int bs=8 ;

  if((x>=0) && (y>=0))
  {
    gotoxy(x,y) ;
  }

  strcpy(tmp,str) ;
  i=strlen(str) ;

  cprintf("%s",tmp) ;
  fflush(stdout) ;

  while(i>=0)
  {
    chr=bioskey(0) & 0xff ;
    otherwise=TRUE ;

    if((chr=='\b')||(chr==bs))
    {
      otherwise=FALSE ;
      if(i>0)
      {
        cprintf("%c%c%c",8,32,8) ;
        tmp[i--]=0 ;
        fflush(stdout) ;
      }
      else
      {
        /* beep */
      }
    }

    if((chr=='\r') || (chr=='\n'))
    {
      otherwise=FALSE ;
      tmp[i]=0 ;
      break ;
    }

    if(chr==27)
    {
      otherwise=FALSE ;
    }

    if(gmode==3)
    {  
      if(!isdigit(chr))
      {
        continue ;
      }
    }

    if(otherwise)
    {
      if(i<len)
      {
        if(gmode==2)
          cprintf("*") ;
        else  
          cprintf("%c",chr) ;
        tmp[i++]=chr ;
        fflush(stdout) ;
      }
    }
  }

  strcpy(str,tmp) ;
  return(strlen(tmp)) ;
}

/*--- To search a word ---*/
long search_word(str,word)
/*
    return : -1: not found.
            >=0: closest \n.
*/
char *str ;
char *word ;    /* search pattern */
{
  long i, offset ;

  if( strlen(word)>0 )
  {
    last_s=0 ;
    strcpy(finds,word) ;
  }
  else
  {
    strcpy(word,finds) ;
  }

  if( (offset=kkystr((str+last_s),word))<0 )
    return(-1) ;

  offset+=last_s ;

  last_s=offset+1 ;

  i=offset ;
  while( *(str+i)!=10 && *(str+i)!=13 && i>0 )
    i-- ;

  if(i>0)
    i++ ;

  return(i) ;
}
    

/*--- To show the menu screen ---*/
int show(str)
char *str ;
{
  int i, j ;
  int posi ;
  int n, cols ;
  int ph ;
  int handle ;
  char key ;
  char cr=13 ;
  char comm[100] ;
  char *tab="  " ;
  int tail=1 ;          /* check if last page */
  int l, blink=0, fc, bc, ofc ,obc ,jmp, no ;
  int cnt=0 ;
  char num[5] ;
  char prompt_line[80];
  int x, y, a, b;

  ofc=fc=LIGHTGRAY;
  obc=bc=BLACK;

  i=n=cols=ph=0 ;

  while(*(str+i)!=0)
  {
    if( !strncmp((str+i), META_LEFT, 2) )
    {
      i+=2 ;
      l=0 ;     /* command length */
      jmp=0 ;   /* fc & bc switch */

      while( strncmp((str+i), META_RIGHT, 2) )
      {
        if(*(str+i)==0  || l>10)
          break ;

        if(tolower(*(str+i))=='b')
        {
          blink=BLINK ;         /* set blink */
        }

        if(tolower(*(str+i))=='c')
        {
          clrscr() ;         /* clear screen */
          fc=ofc ;
          bc=obc ;
          blink=0 ;
        }

        if(tolower(*(str+i))=='p')
        {
          readkey() ;         /* Pause */
        }

        if(tolower(*(str+i))=='n')
        {
          blink=0 ;             /* set normal color */
          fc=ofc ;
          bc=obc ;
        }

        if(tolower(*(str+i))==',')
        {
          jmp=1 ;
        }

        if( isdigit(*(str+i)) )
        {
          num[0]=*(str+i++) ;
          l++ ;
          if( isdigit(*(str+i)) )
          {
            num[1]=*(str+i++) ;
            l++ ;
            num[2]=0 ;
          }
          else
          {
            num[1]=0 ;
          }

          if( jmp==0 )
          {
            fc=atoi(num) ;
            jmp=1 ;
          }
          else
          {
            bc=atoi(num) ;
          }
          continue ;
        }
        i++ ;
      }

      i+=2 ;    /*skip META_RIGHT*/

      textattr(fc | (bc<<4) | blink) ;

      continue;

    }/*end if(META_LEFT)*/


    if(*(str+i)==10)
    {
      write(1,&cr,1) ;
      write(1,(str+i),1) ;      /* print new line */
      n++ ;
      cols=0 ;

      if(n%(LINES-2)==0)
      {
        cnt=0 ;         /* for the last page repeat the head line */
        j=i+1 ;
        while(*(str+j)!=0)
        {
          if(cnt==0)
            posi=j ;

          if(*(str+(j++))==10)
            cnt++ ;
        }

        if( cnt<LINES )
          tail=1 ;
        else
          tail=0 ;

        j=i+1 ;
        while( *(str+j)!=10 && *(str+j)!=0 )
        {
          if( !strncmp((str+j), META_LEFT, 2) )
          {
            j+=2 ;
            l=0 ;     /* command length */
            jmp=0 ;   /* fc & bc switch */

            while( strncmp((str+j), META_RIGHT, 2) )
            {
              if(*(str+j)==0  || l>10)
                break ;

              if(tolower(*(str+j))=='b')
              {
                blink=BLINK ;         /* set blink */
              }

              if(tolower(*(str+j))=='c')
              {
                clrscr() ;         /* clear screen */
                fc=7 ;
                bc=0 ;
                blink=0 ;
              }

              if(tolower(*(str+j))=='p')
              {
                readkey() ;         /* Pause */
              }

              if(tolower(*(str+j))=='n')
              {
                blink=0 ;             /* set normal color */
                fc=LIGHTGRAY ;
                bc=BLACK ;
              }

              if(tolower(*(str+j))==',')
              {
                jmp=1 ;
              }

              if( isdigit(*(str+j)) )
              {
                num[0]=*(str+j++) ;
                l++ ;
                if( isdigit(*(str+j)) )
                {
                  num[1]=*(str+j++) ;
                  l++ ;
                  num[2]=0 ;
                }
                else
                {
                  num[1]=0 ;
                }

                if( jmp==0 )
                {
                  fc=atoi(num) ;
                  jmp=1 ;
                }
                else
                {
                  bc=atoi(num) ;
                }
                continue ;
              }
              j++ ;
            }
            j+=2 ;      /* skip META_RIGHT*/
            textattr(fc | (bc<<4) | blink) ;
          }
    
          if(*(str+j)==9)     /* TAB */
          {
            if((cols%8)==0)
            {
              write(1,tab,1) ;
              cols++ ;
            }
            while(cols%8)
            {
              write(1,tab,1) ;
              cols++ ;
            }  
            j++ ;
            continue ;
          }
          
          write(1,(str+j),1) ;
          cols++ ;
          j++ ;

        }

        if( *(str+j)==10 )
        {
          write(1,(str+j),1) ;
          write(1,&cr,1) ;
          cols=0 ;
        }
        else
          return(0) ;   /* *(str+j)=0 */

        if( term_mode==0 )
          sprintf(prompt_line, "%s, %s ", MORE, CAP_PROMPT);
        else
          sprintf(prompt_line, "%s ", MORE);

        do
        {
          if( !mono )
                textcolor(2);
          gotoxy(1, 24);
          show(prompt_line) ;
          if( !mono )
                normal_text();

          if( mouse_mode )
                show_mouse_cursor();

          do
          {
           if( mouse_mode )
           {
                mouse_xy_press(&x, &y, &a, &b);

                if( b==1 )  /*mouse right button pressed (quit)*/
                {
                  /*hold until mouse button depressed*/
                  while( b!=0 )
                    mouse_xy_press(&x, &y, &a, &b);

                  key='Q';
                  break;
                }

                if( a==1 )  /*mouse left button pressed*/
                {
                  /*hold until mouse button depressed*/
                  while( a!=0 )
                    mouse_xy_press(&x, &y, &a, &b);

                  /*next page*/
                  if( x>=0 && x<=13 && y==23 )
                  {
                        key=' ';
                        break;
                  }

                  /*backward*/
                  if( x>=16 && x<=24 && y==23 )
                  {
                        key='B';
                        break;
                  }

                  /*quit*/
                  if( x>=27 && x<=33 && y==23 )
                  {
                        key='Q';
                        break;
                  }

                  /*left mouse button as 'next page' function*/
                  if( y<23 )
                  {
                        key=' ';
                        break;
                  }

                }/*end if(mouse_presse)*/

           }/*end if(mouse)*/

           if( kbhit() )
           {
                key=readkey() ;
                break;
           }

          } while(TRUE);

          if( mouse_mode )
                hide_mouse_cursor();

          if(key==23 && term_mode==0)   /*--- capture post ---*/
          {
            printf("\r                                                                            \r") ;
            printf("%s",CAPTUREFILE) ;
            getstring(-1,-1,capfn,80-strlen(CAPTUREFILE),1) ;
            if((handle=open(capfn,O_CREAT|O_APPEND|O_WRONLY,S_IREAD|S_IWRITE))<0)
            {
              printf("file open error") ;
              readkey();
            }  
            else
            {
              write(handle,str,strlen(str)) ;
              write(handle,"\n\n",2) ;
              close(handle) ;
            }
            printf("\r                                                                            \r") ;
            fflush(stdout) ;

            continue;
          }

          break;

        } while(TRUE);

        switch(key)
        {
          case 'q':
          case 'Q':
            erase_line() ;
            show("\n") ;
            return(FALSE) ;
          case 'b':
          case 'B':
            ph=0 ;
            for(j=i; j>=0; j--)
            {
              if( *(str+j)==10 )
                ph++ ;
                
              if( ph>(LINES-2)*2 )
              {
                break ;
              }
            }
            
            cnt=0 ;
            i=j ;
            last_s=j ;          /* adjust last_search */
            clrscr() ;

            break ;
          case '/':     /* search */
            erase_line() ;
            show("/") ;
            comm[0]=0 ;
            getstring(-1,-1,comm,60,1) ;
            
            if( (l=search_word(str,comm))<0 )
            {
              show(SCANOFIND) ;
              readkey() ;
              ph=0 ;
              for(j=i; j>=0; j--)
              {
                if( *(str+j)==10 )
                  ph++ ;
                
                if( ph>(LINES-2) )
                {
                  break ;
                }
              }
            
              cnt=0 ;
              i=j ;

            }
            else
            {
              i=l-1 ;
              cnt=0 ;
            }
            clrscr() ;

            break ;
            
        }
        erase_line() ;
        if( (cnt<LINES-1) && (cnt>0) )
        {
          i=posi ;
        }

        if( !tail )
          clrscr() ;
      }


      i++ ;
      continue ;
    }

    if(*(str+i)==9)
    {
      if((cols%8)==0)
      {
        putch(*tab) ;
        cols++ ;
      }
      while(cols%8)
      {
        putch(*tab) ;
        cols++ ;
      }
    }
    else
    {
      putch(*(str+i)) ;
      cols++ ;
    }
    i++ ;
  }
  return(0);
}
/*end of show*/


/*--- To get a key input ---*/
int readkey()
{
  char k ;

  k=bioskey(0) & 0xff ;
  return(k) ;
}


/*--- To erase cr ---*/
int clear_cr(buf)
char *buf ;
{
  int i ;
  
  i=0 ;
  while(*(buf+i)!=0)
  {
    if((*(buf+i)==13) && (*(buf+i+1)==10))
      *(buf+i)=' ' ;
    i++ ;
  }

  return(0);
}

/*--- To erase esc ---*/
int clear_esc(buf)
char *buf ;
{
  int i ;
  
  i=0 ;
  while(*(buf+i)!=0)
  {
    if( *(buf+i)==27 )
      *(buf+i)=' ' ;
    i++ ;
  }

  return(0);
}

/*--- Erase one line ---*/
int erase_line()
{
  char cr=13, line[80] ;

  memset(line,32,79) ;
  write(1,&cr,1) ;
  write(1,line,79) ;
  write(1,&cr,1) ;

  return(0);
}
  
