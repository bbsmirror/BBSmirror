
#include <windows.h>
#include <conio.h>
#include "mycon.h"
/*
        simulate bioskey in OS/2
*/
int bioskey(int p)
{
  int key;
  int ret=0;

  if( p==1 )
  {
    if( _kbhit() )
      return(TRUE);
    else
      return(FALSE);
  }


  key=_getch();
  if( key==0 || key==224 )
  {
    key=_getch();
    ret=key<<8;
  }
  else
    ret=key;

  return(ret);

}
/*end of bioskey*/

void gotoxy(int x, int y)
{
	COORD cd;
	cd.X = (short) x-1; cd.Y = (short) y-1;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), cd);
}
int wherex()
{
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi);
	return csbi.dwCursorPosition.X+1;
}
int wherey()
{
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi);
	return csbi.dwCursorPosition.Y+1;
}

void lowvideo()
{
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	GetConsoleScreenBufferInfo(hOut, &csbi);
	csbi.wAttributes &= (WORD) !FOREGROUND_INTENSITY;
	SetConsoleTextAttribute(hOut, csbi.wAttributes);
}
void highvideo()
{
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	GetConsoleScreenBufferInfo(hOut, &csbi);
	csbi.wAttributes |= (WORD) FOREGROUND_INTENSITY;
	SetConsoleTextAttribute(hOut, csbi.wAttributes);
}
void textcolor(WORD c)
{
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	GetConsoleScreenBufferInfo(hOut, &csbi);
	csbi.wAttributes &= (!WHITE);
	csbi.wAttributes |= c;
	SetConsoleTextAttribute(hOut, csbi.wAttributes);
}
void textbackground(WORD c)
{
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	GetConsoleScreenBufferInfo(hOut, &csbi);
	csbi.wAttributes &= (WORD) (!(WHITE<<4));
	SetConsoleTextAttribute(hOut, csbi.wAttributes);
}
void clrscr()
{
	COORD cdStart;
	DWORD dwWrt, dwNum;
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	GetConsoleScreenBufferInfo(hOut, &csbi);
	dwNum = csbi.dwMaximumWindowSize.X * csbi.dwMaximumWindowSize.Y;
	cdStart.X = cdStart.Y = 0;
	csbi.wAttributes = WHITE;
	FillConsoleOutputCharacter(hOut, ' ',  dwNum, cdStart, &dwWrt);
	FillConsoleOutputAttribute(hOut, csbi.wAttributes, dwNum, cdStart, &dwWrt);
 	SetConsoleCursorPosition(hOut, cdStart);
}
void gettext(int x1, int y1, int x2, int y2, LPSTR pBuff)
{
	COORD cdStart;
	DWORD dwNum;
	cdStart.X = (WORD) x1;
	cdStart.Y = (WORD) y1;
	ReadConsoleOutputCharacter(GetStdHandle(STD_OUTPUT_HANDLE), pBuff, x2-x1, cdStart, &dwNum);
}
void puttext(int x1, int y1, int x2, int y2, LPSTR pBuff)
{
	COORD cdStart;
	DWORD dwNum;
	cdStart.X = (WORD) x1;
	cdStart.Y = (WORD) y1;
	WriteConsoleOutputCharacter(GetStdHandle(STD_OUTPUT_HANDLE), pBuff, x2-x1, cdStart, &dwNum);
}
