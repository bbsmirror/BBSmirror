

/*--- head files ---*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
//#include <varargs.h>
#include <errno.h>
#include <sys/types.h>
//#include <sys/socket.h>
#include <winsock.h>

//#include <netinet/in.h>

//#include <netdb.h>
//#include <utils.h>

//#define  BSD_SELECT

//#include <sys/time.h>
//#include <sys/select.h>

#include "proto.h"
#include "msg.h"

#ifndef SOCBASEERR
#define SOCBASEERR 10000
#endif

#ifndef INADDR_NONE
#define INADDR_NONE     0xffffffff
#endif

extern char     *sys_errlist[];

/*--- constant definitions ---*/
#ifndef FALSE
#define FALSE   0
#endif

#ifndef TRUE
#define TRUE    !FALSE
#endif
/**********************/


/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/



/*
        tcp_close --- close network API sessions (include UDP)
*/
int tcp_close()
{
  shutdown(tcpport, 2);
  closesocket(tcpport);
  return(0);
}
/*end of tcp_close*/



/*
        tcp_get --- read tcp socket
*/
int tcp_get(char *buf, int maxn)
{
  int ret;

  ret=recv(tcpport, buf, maxn, 0);
  if( ret==SOCKET_ERROR )
  {
  		ret = WSAGetLastError();
		printf("TCP_GET error code = %d\n", ret);
		return(-1);
  }
  else
        return(ret);
}
/*end of tcp_get*/



/*
        tcp_get_nowait --- read socket without blocking
*/
int tcp_get_nowait(char *buf, int maxn)
{
  fd_set rset;
  struct timeval timeout;
  int maxfd;
  int ret;

   /*set mutiplex I/O check bit*/
   maxfd=tcpport + 1;
   FD_ZERO(&rset);
   FD_SET(tcpport, &rset);
   timeout.tv_sec=0;
   timeout.tv_usec=1;

   if( select(maxfd, &rset, NULL, NULL, &timeout) <0)
      printf("select error\n");

   if( FD_ISSET(tcpport, &rset) )
   {
      ret=tcp_get(buf, maxn);
      if( ret<0 )
        return(-1);
      else
        return(ret);
   }
   else
     return(0);      /*no data-in*/
}
/*end of tcp_get_nowait*/



/*
        tcp_put --- write socket
*/
int tcp_put(char *buf, int tn)
{
  int ret;

  ret=send(tcpport, buf, tn, 0);
  if( ret<0 )
        return(-1);

  return(0);
}
/*end of tcp_put*/



/**************************************************************/
int
connectTCP( host, service)
char *host;
int service;
/*
        return:
                fd: handle
                -1: error
*/
{
        struct hostent  *phe;
        //struct servent  *pse;
        struct sockaddr_in      sin;
        int     s;

        memset(&sin, 0, sizeof(sin));
        sin.sin_family=AF_INET;

        /*map port number*/
        if( (sin.sin_port=htons((u_short)service)) == 0 )
                return(INVALID_SOCKET);

        /*get IP address*/
        if( (phe = gethostbyname(host))!=NULL )
                memcpy(phe->h_addr, &sin.sin_addr, phe->h_length);
        else if( (sin.sin_addr.s_addr = inet_addr(host)) == INADDR_NONE )
        {
                printf("can't get %s host entry\n\r", host);
                return(INVALID_SOCKET);
        }

        /*allocate socket*/
        s = socket(PF_INET, SOCK_STREAM, 0);
        if(s==INVALID_SOCKET)
        {
				int e = GetLastError();
                printf("can't create socket: %d\n\r", e);
                return(INVALID_SOCKET);
        }

        /*connect the socket*/
        if(connect(s, (struct sockaddr *)&sin, sizeof(sin)) < 0)
        {
                printf("PBBS service may not be available on %s.%d: %s\n\r", host, service, sys_errlist[WSAGetLastError()-SOCBASEERR]);
                return(INVALID_SOCKET);
        }

        tcpport=s;
        return(s);
}
/*end of connectTCP*/



/*
        end_tcp --- end all network sessions (include UDP)
*/
int end_tcp()
{
  tcp_close();
  if( success_then_remove )
  {
        printf("%s %s, %s", S_T_R_MSG, s_t_r_filename, PRESSANYKEY);
        success_then_remove=FALSE;
        readkey();
  }
  return(0);
}
/*end of end_tcp*/

