/***************************************************************
    ppc.c       (for PC + Dos)
                (for PC + OS/2)

    To connect the BBS server.
    write by Aquarius Kuo(cs79026@chpi.edu.tw)
    1993.11.24.
    program was developed under Turbo C V1.0

    version 2.0 was remodified by Samson Chen Nov 12, 1994
    program was developed under Borland C++ V3.1
    Nov 21, 1994 modified
    Dec 3, 1994
    Version 2.01 Dec 9, 1994
    Version 2.1 Apr 1, 1995
    Version 2.2 Apr 22, 1995
    Version 2.2a May 30, 1995
    Version 2.2b June 30, 1995

    Version 2.2b OS/2 Version July 10, 1995 by Henry Chen
    OS/2 version was developed under Borland C for OS/2 V2.0

    V2.3 Aug 18,1995
    V2.3a Nov 14, 1995
          Dec 30, 1995

    Version 2.3a Win32 (NT/95) Version Jan 17, 1996 by Nieh Jong Liang

    Trademarks:

        WATCOM C++ is a registered trademark of WATCOM International.

        OS/2 is a registered trademark of International Business
        Machine Corp.

	Windows NT/Windows 95 is a registered trademark of Microsoft Corp.

*****************************************************************/
//#include <ctype.h>
//#include <conio.h>
//#include <time.h>
#include <windows.h>
#include "pcpbbs.h"
#include "proto.h"
#include "msg.h"
#include "mycon.h"

#define LEFT    '{'
#define RIGHT   '}'
#define SEP     '|'
#define VERSION  (char) 0x23            /*protocol version 2.1*/
#define PLATFORM (char) 11              /*OS/2 platform number*/

static char rcsid[]="$Id$" ;
extern int tcpdrv ;

/*--- Prompt the screen ---*/
char    SELECTMSG[80];

int PBBS_DEFAULT_PORT;
char PBBS_DEFAULT_SERVER[80];
char downpath[80];
char temppath[80];
int term_mode=0;
int mouse_mode=0;
int mono=0;     /*default is COLOR*/
char capfn[80] ;
char editor[80];
char telnet_path[80];
char show_readmpf_status=FALSE;
int intrread_point=0;
char success_then_remove=FALSE;
char s_t_r_filename[80];
char iread_mark[51];

/*for multi-layer INTRSEL point stack*/
int isel_point_stk[256];  /*ASC 49 (1) --- ASC 255 : 207 layers max*/


/*network ports handler*/
int     tcpport;


/*WATTCP user initial*/
static void (*other_init)();
static void my_init(char *name, char *value)
{
  if( !strcmp(name, "PBBS_W32_EDIT") )
  {
        strcpy(editor, value);
  }
  else if( !strcmp(name, "PBBS_DOWNPATH") )
  {
        strcpy(downpath, value);
  }
  else if( !strcmp(name, "PBBS_TEMPPATH") )
  {
        strcpy(temppath, value);
  }
  else if( !strcmp(name, "PBBS_TERMMODE") )
  {
        if( !stricmp(value, "YES") )
                term_mode=1;
  }
  else if( !strcmp(name, "PBBS_MONO") )
  {
        if( !stricmp(value, "YES") )
                mono=1;
        else
                mono=0;
  }
  else if( !strcmp(name, "PBBS_MOUSE") )
  {
        if( !stricmp(value, "NO") )
                mouse_mode=0;
  }
  else if( !strcmp(name, "PBBS_SERVER") )
  {
        strcpy(PBBS_DEFAULT_SERVER, value);
  }
  else if( !strcmp(name, "PBBS_PORT") )
  {
        PBBS_DEFAULT_PORT=atoi(value);
  }
  else if( !strcmp(name, "PBBS_W32_TELNET") )
  {
        strcpy(telnet_path, value);
  }
  else if( other_init )
        (*other_init)(name, value);
}
/*end of my_init*/



/* get config from WATTCP.CFG */
void get_config(arg)
char *arg;
{
  int cnt;
  char *path;
  char line[100];
  char watcfg[100];
  FILE *fp;
  char envname[128];            /* new, temporarily save env name */
  char envval[128];             /* new, temporarily save env value */
  char *sptr;                   /* new, string pointer */

  if ((path = getenv("WATTCP.CFG")) != NULL )
  {
    strcpy(line, path);
    cnt=strlen(line)-1;
    if(line[cnt]=='\\')
      line[cnt]=0;
	sprintf(watcfg, "%s\\WATTCP.CFG", line);
  }
  else
  {
  	HFILE hfp;
	OFSTRUCT	of;
    memset(&of, 0, sizeof(of));
    of.cBytes = sizeof(of);
    if((hfp=OpenFile("WATTCP.CFG", &of, OF_EXIST | OF_READ))==HFILE_ERROR)
    {
      printf("Can't open WATTCP.CFG !! \n\7\n");
      exit(1);
     }
     _lclose(hfp);
     lstrcpy(watcfg, of.szPathName);
  }

  if((fp=fopen(watcfg,"r"))==NULL)
   {
    printf("Can't open %s !! \n\7\n", watcfg);
    exit(1);
   }

  //for(fgets(line,100,fp); !feof(fp); fgets(line,100,fp))
  while(fgets(line,100,fp))
  {
    sptr=strchr(line,'=');
    if( sptr==NULL ) continue;
    sptr++;											/* skip the '=' */
    while ((*sptr)==' ' || (*sptr)=='\t') sptr++;   /* remove SPACE & TAB */
	for (cnt = strlen(sptr); isspace(*(sptr+cnt-1)); cnt--)
					*(sptr+cnt-1)=0; /* remove CR & other space */
    strcpy(envval,sptr);
    sptr=line;
    while ((*sptr)==' ' || (*sptr)=='\t') sptr++;   /* remove SPACE & TAB */
    strcpy(envname,strtok(sptr,"="));
    if(envname[0]=='#') continue;
    sptr=strchr(envval, '#');
    if( sptr ) *sptr='\0';

    /*strip SPACE and TAB*/
    cnt=strlen(envval)-1;
    while(cnt>=0)
    {
      if(envval[cnt]!=' ' && envval[cnt]!='\t')
        break;

      envval[cnt]=0;
      cnt--;
    }

    strupr(envname);
    my_init(envname, envval);
  }
  if (!feof(fp))
  {
	printf("Read %s error!! Use the default value!!\n\7\n", watcfg);
    //exit(1);
  }
  fclose(fp);
}
/*end of get_config*/



/*
        Make PowerBBS Session
*/
make_pbbs_session(ipaddr, bbsport)
  char *ipaddr;
  int bbsport;
{
  char buffer[256] ;
  long len ;
  char prot ;
  int ret ;

  if( connectTCP(ipaddr,bbsport)==INVALID_SOCKET)
  {
      printf("Can't connect to Power BBS server!\n");
      exit(1) ;
  }

  /*********************/
  /*handshaking session*/
  /*********************/

  strcpy(buffer,"Samson") ;
  if(send_mpf(buffer,strlen(buffer),SESSION)<0)
  {
      printf("(send) PBBS Session 1 error!\n");
      end_tcp() ;
      exit(2);
  }

  ret=read_mpf(buffer, &len, &prot, FALSE) ;

  if( ret<0 )
  {
      printf("(send) PBBS Session 2 error!\n");
      end_tcp() ;
      exit(3);
  }

  buffer[len]=0 ;
  if(strcmp("Aquarius",buffer))
  {
    printf("PowerBBS handshaking error!\n") ;
    end_tcp();
    exit(5);
  }
  buffer[0]=VERSION ;         /* VER_HIGH<<4+VER_LOW ;*/
  buffer[1]=(PLATFORM<<4)+0 ;   /* 1*16+0 ;*/
  strcpy(&buffer[2],"POWERBBS") ;
  send_mpf(buffer,10,SESSION) ;

  return(0);
}
/*end of make_pbbs_session*/

/*************************************************************************/
/*************************************************************************/
/*************************************************************************/



/*========================Main program ============================*/
void main(argc,argv)
int argc;
char *argv[];
{
  long len, read_len ;
  char prot ;
  char ipaddr[50] ;
  int  bbsport ;
  char *buffer, pwbuffer[20] ;
  char *intrread_buf, *intrsel_buf;
  char menu_buf[2048];
  char menu_protocol[80];
  char key ;
  int quit, out_getkey, i, tcpstat ;
  time_t now, wait_time ;
  int mils, cnt, ret ;
  char LOCAL_DIR[80] ;
  char header[500] ;
  char file_prepart[9];
  char file_postpart[4];
  char *token;
  //struct text_info ti;
  int fore_color, back_color;
  char crlf[3];
  char *site;
  char *login;
  int iStatus;
  WSADATA WSAData;

  printf("\nPowerBBS PC-Client by Aquarius Kuo, Team Square-1991.\n");
  printf("%s", CLIENT_VER_NOTE2);

  // Update Console Title
  SetConsoleTitle("PowerBBS Win32 Client ver 2.3a");
  // initial the winsock.dll
  if ((iStatus = WSAStartup(MAKEWORD(1,1), &WSAData)) != 0) 
  {
	printf("Initial winsock.dll error!! err=%d\n", iStatus);
  }
  /*initial global vars*/
  editor[0]=0;
  downpath[0]=0;
  temppath[0]=0;
  PBBS_DEFAULT_PORT=6203;
  strcpy(PBBS_DEFAULT_SERVER, "140.126.3.111");
  strcpy(telnet_path, "telnet %1");


  /*test mouse*/
  mouse_mode=FALSE;
  if( mouse_mode )
  {
        set_mouse_cursor(0,0);
        hide_mouse_cursor();
  }



  /*read setup in PBBS_OS2.CFG*/
  /*config file*/
  get_config(argv[0]);

  if(argc>1)
  {
      if( argv[1][0]=='/' || argv[1][0]=='?' )
      {
        printf("Syntax:\n\r") ;
        printf("   %s [ip_addr | domain_name] [port]\r\n\n", argv[0]) ;
        exit(1) ;
      }
  }

  if(argc>1)
  {
    strcpy(ipaddr,argv[1]) ;
  }
  else
    strcpy(ipaddr, PBBS_DEFAULT_SERVER);

  if(argc>2)
  {
    bbsport=atoi(argv[2]) ;
    if(bbsport<=0)
      bbsport=PBBS_DEFAULT_PORT ;
  }
  else
    bbsport=PBBS_DEFAULT_PORT ;

  /*allocate memory, must use Model Large to compile this*/
  buffer=(char *) malloc(MAX_BUF) ;
  intrread_buf=(char *) malloc(BACK_BUF) ;
  intrsel_buf=(char *) malloc(BACK_BUF) ;

  if( mono )
        printf("MONO display\n");
  else
        printf("COLOR display\n");

  make_pbbs_session(ipaddr, bbsport);

  /* initial isel_point_stk */
  for(cnt=0; cnt<256; cnt++)
        isel_point_stk[cnt]=0;

  /*--- init variable ---*/
  quit=FALSE ;

  if( strlen(downpath)<=0 )
    LOCAL_DIR[0]=0 ;
  else
    strcpy(LOCAL_DIR, downpath) ;

  strcpy(capfn, "CAP.TXT") ;

  /***********************************/
  /*INTRSELECT/INTRREAD TITLE MESSAGE*/
  /***********************************/
  strcpy(SELECTMSG,   "PowerBBS PC Client Menu Selection") ;

  /********************/
  /*get original color*/
  /********************/
  //gettextinfo(&ti) ;
  //fore_color=ti.normattr & 15 ;
  //back_color=(ti.normattr >> 4 ) & 7 ;

  /*set WHITE-BLACK */
  textbackground(BLACK);
  //textcolor(LIGHTGRAY);
  textcolor(WHITE);
  lowvideo();

  /*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/

  do
  {
    tcpstat=read_mpf(buffer,&len,&prot,FALSE);

    if( success_then_remove )
    {
        success_then_remove=FALSE;
        unlink(s_t_r_filename);
    }

    if(tcpstat==1)
    {
      if(len>MAX_BUF)
        len=MAX_BUF-1 ;

      buffer[len]=0 ;
      switch(prot)
      {
        case ASK:
          show(buffer) ;
          i=strlen(buffer) ;
          buffer[0]=0 ;
          i=getstring(-1,-1,buffer,79-i,4) ;
          show("\n") ;
          send_mpf(buffer,i,ASK) ;
          break ;
        /*-------------------------------------------------------*/
        case BYEBYE:
          quit=TRUE ;
          break ;
        /*-------------------------------------------------------*/
        case DISPLAY:
          clear_esc(buffer) ;
          show(buffer) ;
          break ;
        /*-------------------------------------------------------*/
        case ERROR:
          show(buffer) ;
          /*quit=TRUE ;*/
          break ;
        /*-------------------------------------------------------*/
        case FILEPOST:
          if( term_mode )       /* not support under terminal mode */
          {
            show(FDISABLE) ;
            send_mpf(buffer,1,STOPPOST) ;
            readkey() ;
            break ;
          }
          show(ASKFILENAME) ;
          buffer[0]=header[0]=0 ;
          if(getstring(-1,-1,header,30,1)<1)
          {
            send_mpf(buffer,1,STOPPOST) ;
          }
          else
          {
            if( get_file(header,buffer) )
            {
              show(EDITCONFIRM) ;
              do
              {
                key=tolower(readkey()) ;
                if(key=='e')
                {
                  if(writer(buffer)==FALSE)
                  {
                    send_mpf(buffer,1,STOPPOST) ;
                    break ;
                  }
                  else
                  {
                    show(EDITCONFIRM) ;
                  }
                }
              }
              while( (key!='p') && (key!='a') ) ;
              printf("%c",key) ;
              fflush(stdout) ;
              if(key=='p')
              {
                send_mpf(buffer,strlen(buffer),MAKEPOST);
                break ;
              }
              else
              {
                if(key=='a')
                {
                  send_mpf(buffer,1,STOPPOST) ;
                  break ;
                }
              }
            }
            else
            {
              show("\n\n") ;
              show(FNOTFOUND) ;
              readkey() ;
              send_mpf(buffer,1,STOPPOST) ;
            }
          }
          break ;
        /*-------------------------------------------------------*/
        case FILEXFER:  /*DOWNLOAD*/
          if(term_mode==1)
          {
                send_mpf(" ",1,STOPXFER) ;
                show("\n") ;
                show(FDISABLE) ;
                show(PRESSANYKEY) ;
                user_confirm();
                show("\n") ;
          }
          else
          {

            /*analyze filename, maybe it just fit UNIX style*/
            memset(file_prepart, 0, 9);
            memset(file_postpart, 0, 4);
            token=strtok(buffer, ".");
            if( token )
            {
                  strncpy(file_prepart, token, 8);
                  token=strtok(NULL, ".");
            }
            else
                  strncpy(file_prepart, buffer, 8);

            if( token )
                  strncpy(file_postpart, token, 3);

            strcpy(buffer, file_prepart);

            if( strlen(file_postpart)>0 )
            {
                  strcat(buffer, ".");
                  strcat(buffer, file_postpart);
            }

            if( LOCAL_DIR[0]!=0 )
            {
              strcpy(buffer+1024, buffer) ;
              strcpy(buffer,LOCAL_DIR) ;
              if( LOCAL_DIR[strlen(LOCAL_DIR)-1]!='\\' && LOCAL_DIR[strlen(LOCAL_DIR)-1]!=':' )
                strcat(buffer,"\\") ;
              strcat(buffer,buffer+1024) ;
            }

            if(download(buffer,2)==FALSE)
              show(" ")  ;

          }/*end if-else (termmode)*/

          break ;
        /*-------------------------------------------------------*/
        case GETFILE:   /*UPLOAD*/
          if(term_mode==1)
          {
                send_mpf(" ",1,STOPXFER) ;
                show("\n") ;
                show(FDISABLE) ;
                show(PRESSANYKEY) ;
                user_confirm();
                show("\n") ;
          }
          else
          {
                if(get_filename(buffer)==FALSE)
                {
                    send_mpf(" ",1,STOPXFER) ;
                }
                else
                {
                    upload(buffer,2) ;
                    show("\n") ;
                }
          }
          break ;
        /*-------------------------------------------------------*/
        case INTERNET:
          /*..............................................*/
          /*INTERNET Protocol Format:                     */
          /*   "<site IP or domain>\crlf<login name>\crlf"*/
          /*   if <login name>=="PowerBBS" then PowerNet  */
          /*   site format: "<site address> <port number>"*/
          /*..............................................*/
          if(term_mode==1)
          {
                show("\n") ;
                show(FDISABLE) ;
                show(PRESSANYKEY) ;
                user_confirm();
                show("\n") ;
          }
          else
          {
            sprintf(crlf,"%c%c",13,10) ;
            site=kkytok(buffer,crlf) ;
            login=kkytok(NULL,crlf) ;

            if( !strcmp(login, "PowerBBS") )
            {
               /* PowerNET */
               for(cnt=0; cnt<strlen(site); cnt++)
               {
                 if( *(site+cnt)==' ')
                 {
                   *(site+cnt)=0;
                   login=site+cnt+1;
                   break;
                 }
               }

               end_tcp();

               show("\nTry to connect to PowerBBS site ");
               show(site);
               show(".");

               if( atoi(login)>0 )
               {
                 show(login);
                 show("\n");
                 make_pbbs_session(site, atoi(login) );
               }
               else
               {
                 show("6203");
                 show("\n");
                 make_pbbs_session(site, 6203);
               }
            }
            else
            {
               /* Internet */
                internet(site, login);
                /*internet() is a never-return call in PC client*/
            }
          }
          break;
        /*-------------------------------------------------------*/
        case INTRREAD:

          if( !strcmp(buffer, "SAME_BUFFER") )
          {
                /*if Server send "SAME_BUFFER",
                  client should use the previous one*/

                strcpy(buffer, intrread_buf);
          }
          else
          {
                /*else backup the current,
                  maybe next time will use it*/

                strcpy(intrread_buf, buffer);
          }

          if((cnt=postlist(buffer, 1))>0)
          {
            sprintf(buffer,"%d",cnt) ;
            send_mpf(buffer,strlen(buffer),INTRREAD) ;
          }
          else
          {
            send_mpf(buffer,1,INTRREAD) ;
          }
          break ;
        /*-------------------------------------------------------*/
        case INTRSEL:

          if( !strcmp(buffer, "SAME_BUFFER") )
          {
                /*description is same as INTRREAD, but for INTRSEL*/
                strcpy(buffer, intrsel_buf);
          }
          else
          {
                strcpy(intrsel_buf, buffer);
          }

          if((cnt=postlist(buffer, 2))>0)
          {
            sprintf(buffer,"%d",cnt) ;
            send_mpf(buffer,strlen(buffer),INTRSEL) ;
          }
          else
          {
            send_mpf(buffer,1,INTRSEL) ;
          }
          break ;
        /*-------------------------------------------------------*/
        case MAKEPOST:
          do
          {
            if(writer(buffer)==FALSE)
            {
              send_mpf(buffer,1,STOPPOST) ;
              break ;
            }
            else
            {
              show(EDITCONFIRM) ;
              do
              {
                key=tolower(readkey()) ;
              }
              while((key!='p')&&(key!='e')&&(key!='a')) ;
              printf("%c",key) ;
              fflush(stdout) ;
              if(key=='p')
              {
                send_mpf(buffer,strlen(buffer),MAKEPOST) ;
                break ;
              }
              else
              {
                if(key=='a')
                {
                  send_mpf(buffer,1,STOPPOST) ;
                  break ;
                }
              }
            }
          }
          while(key=='e') ;
          break ;
        /*-------------------------------------------------------*/
        case MENU:
          if( strlen(buffer)>0 )        /*new menu sent*/
                strncpy(menu_buf, buffer, 1632);

          show("{#c#}");        /*clrscr*/
          normal_text();
          show(menu_buf) ;

          out_getkey=FALSE ;
          do    /*--- Check the input key ---*/
          {
            key=pop_menu();

            if( !term_mode )
            {
              if( key==15 )        /* ctrl-O : set local directory path */
              {
                show("\n\n") ;
                show(DOWNPATH) ;
                getstring(-1,-1,LOCAL_DIR,60,1) ;
                show("{#c#}");
                normal_text();
                show(menu_buf) ;
                continue ;
              }

              if( key==4 )        /* ctrl-D : shell to dos */
              {
                show("\ntype 'EXIT' to go back to PowerBBS!\n");
                system(getenv("COMSPEC")) ;
                show("{#c#}");
                normal_text();
                show(menu_buf) ;
                if(mouse_mode)
                  mouse_mode=mouse_init();      /*reinitial mouse driver*/
                continue ;
              }
            }

            out_getkey=map_key_menuprotocol(menu_protocol, key);

            if( out_getkey )
            {
              if( !strcmp(menu_protocol, "{Ping}") )
				  wait_time=clock();

              if( !strcmp(menu_protocol, "{Version_Info}") )
              {
                show(CLIENT_VER_NOTE1);
                show(CLIENT_VER_NOTE2);
                show(CLIENT_VER_NOTE3);
              }

              /*--- send menu protocol ---*/
              send_mpf(menu_protocol, strlen(menu_protocol), MENU) ;

            }/*endif*/

          } while(!out_getkey) ;
          cnt=0 ;
          break ;
        /*-------------------------------------------------------*/
        case PASSWD:
          show(buffer) ;
          pwbuffer[0]=0 ;
          cnt=getstring(-1,-1,pwbuffer,10,2) ;
          show("\n") ;
          if(cnt<=0)
          {
            send_mpf(pwbuffer,1,PASSWD) ;
            break ;
          }
          /* encoding (algorithms by Aquarius Kuo)*/
          for(i=strlen(pwbuffer); i<10; i++)
            pwbuffer[i]=59+i*2 ;
          pwbuffer[10]=0 ;
          for(i=1; i<=10; i++)
          {
            pwbuffer[i-1]=(char) ((((pwbuffer[i-1]+pwbuffer[10-i])*67)%91)+32) ;
          }
          send_mpf(pwbuffer,10,PASSWD) ;
          cnt=0 ;
          break ;
        /*-------------------------------------------------------*/
        case PECHO:
		  now=clock();
           mils=(now-wait_time) * 1000 / CLOCKS_PER_SEC ;
          sprintf(buffer,"\n     Ping echo from server in %d ms\n",mils) ;
          show(buffer) ;
          break ;
        /*-------------------------------------------------------*/
        case POST:
          if((cnt=parse_header(buffer,header))==FALSE)
            break ;
          clrscr() ;
          strcat(buffer,"\n") ;
          strcat(buffer,POST_BOTTOM) ;
          /*clear_esc(buffer) ;*/
          clear_esc(header) ;
          i=pager(header,buffer) ;
          if(i>0)                       /*user input a number*/
          {
            sprintf(buffer,"%d",i) ;
            send_mpf(buffer,strlen(buffer),GETPOST) ;
          }
          else
          {
            if(i==0)                    /*quit read*/
            {
              send_mpf("q",1,GETPOST) ;
            }
            if(i==-1)                   /*user response key*/
            {
              send_mpf(buffer,1,GETPOST) ;
            }
            if(i==-2)                   /*--- next post ---*/
            {
              sprintf(buffer,"%d",++cnt) ;
              send_mpf(buffer,strlen(buffer),GETPOST) ;
            }
            if(i==-3)                   /*--- pre post ---*/
            {
              sprintf(buffer,"%d",--cnt) ;
              send_mpf(buffer,strlen(buffer),GETPOST) ;
            }
          }
          break ;
        /*-------------------------------------------------------*/
        case PROMPT:
          parse_prompt(buffer) ;
          break ;
        /*-------------------------------------------------------*/
        case REJECT:
          quit=TRUE ;
          write(1,buffer,len) ;
          break ;
        /*-------------------------------------------------------*/
        case SCRSIZE:
          sprintf(buffer,"%d",LINES-3) ;
          send_mpf(buffer,strlen(buffer),SCRSIZE) ;
          break ;
        /*-------------------------------------------------------*/
        case SUSPEND:
          show(PRESSANYKEY) ;
          user_confirm();
          show("\n") ;
          break ;
        /*-------------------------------------------------------*/
        case TALK:
          chat_room(buffer) ;
          break ;
        /*-------------------------------------------------------*/
        case YESNO:
          yesno_confirm(buffer);
          send_mpf(buffer,1,YESNO) ;
          break;
        /*-------------------------------------------------------*/
        default:
          sprintf(buffer,"Error protocol : %d\n",prot) ;
          printf(buffer) ;
          end_tcp();
          exit(50);
      }
    }
    else
    {
      if(tcpstat==-1)
      {
        printf("Error tcp communation!!\n") ;
        end_tcp();
        exit(6);
      }
    }
  }
  while(!quit) ;

  end_tcp() ;

  /*restore original color*/
  textbackground((WORD)BLACK);
  textcolor((WORD)WHITE);

  WSACleanup();
}
/*end of main*/
/**************************************************************************/
/**************************************************************************/
/**************************************************************************/
