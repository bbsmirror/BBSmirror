/**************************************************************************
 * pc_sock.c --- general network subroutie from PC to UNIX                *
 *               by Aquarius Kuo . DEC 3, 1993                            *
 **************************************************************************/

#include <windows.h>
#include <conio.h>
#include "pcpbbs.h"
#include "proto.h"
#include "msg.h"
#include "mycon.h"

#define MPF_MTU         1400

static char rcsid[]="$Id$" ;
/*****************************
        local structure define
*/
struct  mpf_head_s {
                char    prot;
                char    length[8];
        } ;
static struct mpf_head_s mpf_head ;

/****************************************
        sending via Message Packet Format
*/
send_mpf(buffer, buf_len, protocol)
        char *buffer;   /*transmit data buffer*/
        long buf_len;  /*buffer length*/
        char protocol;  /*mpf protocol code*/
/*
        return: 0 = ok
                -1 = error occurred     (standard)
*/
{
        char    iac_buff=IAC;
        char    *ptr ;
        char    block[MPF_MTU];
        int     i, tail ;
        long    l, pointer ;

        mpf_head.prot=protocol;
        sprintf(mpf_head.length,"%ld",buf_len) ;

        if( tcp_put(&iac_buff, 1)<0 )        /*send IAC*/
          return(-1) ;
        if( tcp_put((char*) &(mpf_head.prot), 1 )<0 )
          return(-1) ;
        if( tcp_put((char*) mpf_head.length, 8 )<0 )
          return(-1) ;
                                /*send protocol code and packet length*/

        l=buf_len ;
        tail=MPF_MTU ;
        ptr=buffer ;
        while( l>0 )
        {
          if(l<tail)
            tail=l ;

          memcpy(block, ptr, MPF_MTU);

          if( tcp_put(block,tail)<0 )
            return(-1) ;

          l-=tail ;
          ptr+=tail ;
        }

        /*flush data to network*/

        return(0);
}
/*end of send_mpf*/



/**********************************
        read fix length from stream
*/
fix_read(fix_len, buffer)
        long fix_len;  /*packet length*/
        char *buffer;   /*stored buffer*/
/*
        return: standard
*/
{
        char *pointer=buffer;
        long pcount=0;
        long n;
        int tail ;

        /*******************/
        /* for show status */
        /*******************/
        char orig_text[10*2];
        int orig_x, orig_y;
        int fetch_percent;
        /*******************/

        if( show_readmpf_status )
        {
                orig_x=wherex();
                orig_y=wherey();
                gettext(71, 1, 80, 1, orig_text);

                gotoxy(76, 1);
                printf("  0%%");
        }

        tail=MPF_MTU ;
        while( pcount < fix_len )
        {
                if( tail>(fix_len-pcount) )
                  tail=fix_len-pcount ;

                n = tcp_get(pointer, tail);
                if( n<0 )
                {
                        printf("Socket fixread error!\n");
                        end_tcp();
                        exit(10);
                }

                pcount += n;

                if(pcount<MAX_BUF-1024)
                  pointer = buffer + pcount;

                if( show_readmpf_status )
                {
                  fetch_percent=(pcount*100)/fix_len;
                  gotoxy(76, 1);
                  printf("%3d%%", fetch_percent);
                }
        }

        if( show_readmpf_status )
        {
                gotoxy(76, 1);
                printf("100%%");

                puttext(71, 1, 80, 1, orig_text);
                gotoxy(orig_x, orig_y);
                show_readmpf_status=FALSE;      /*reset var*/
        }

        return(0);
}
/*end of fix_read*/



/*************************************
        read via Message Packet Format
*/
read_mpf(buffer, buf_len, protocol, nowait)
        char *buffer;   /*stored buffer*/
        long *buf_len; /*length of stored buffer*/
        char *protocol; /*fetched protocol code*/
        int nowait;     /*block read_mpf or not*/
/*
        return: -1 = error occurred
                -2 = garbage code received (in nowait mode)
                 0 = no data-in (in nowait mode)
                 1 = OK
*/
{
        char iac_buff;
        int n;
        int i ;

        if( nowait )    /*nowait will not block function*/
        {

          n = tcp_get_nowait(&iac_buff, 1);
          if( n<0 ) return(-1);                 /*network error*/
          if(n==0) return(0);                   /*no data-in*/
          if( iac_buff != IAC ) return(-2);     /*garbage code received*/

                /*continue at fix_read the head*/
        }
        else
        {
                do
                {
                        n=tcp_get(&iac_buff, 1);
                        if( n<0 )
                        {
                                printf("Socket MPFread error!\n");
                                end_tcp();
                                exit(11);
                        }
                } while( iac_buff != IAC );
                        /*skip until IAC appearred*/
        }

        fix_read((long) 1, (char *) &(mpf_head.prot));
        fix_read((long) 8, (char *) mpf_head.length);
                /*get packet head*/

        *protocol = mpf_head.prot;
        sscanf(mpf_head.length,"%ld",buf_len) ;

        if( *buf_len > 0 )       /*get the packet body if exist*/
        {
                /***************************************************/
                /* if show readmpf status line when reading network*/
                /***************************************************/
                switch(mpf_head.prot)
                {
                case DISPLAY:
                case FILEPOST:
                case INTRREAD:
                case INTRSEL:
                case MAKEPOST:
                case POST:
                        show_readmpf_status=TRUE;
                        break;

                default:
                        show_readmpf_status=FALSE;
                        break;
                }

                /* skip show status if short packet*/
                if( show_readmpf_status && (*buf_len<1024) )
                        show_readmpf_status=FALSE;
                /***************************************************/

                fix_read(*buf_len, buffer);
        }

        return(1);      /*OK*/
}
/*end of read_mpf*/

