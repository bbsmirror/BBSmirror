
#include <windows.h>
#include "resource.h"

char szBuff[81];
int iBuffLen;

LRESULT APIENTRY GetStringDlgProc(
        HWND hDlg,                /* window handle of the dialog box */
        UINT message,             /* type of message                 */
        UINT wParam,              /* message-specific information    */
        LONG lParam)
{

   switch (message) {
      case WM_INITDIALOG:                     /* message: initialize dialog box */
	  {
        SetDlgItemText( hDlg, IDC_EDIT1, szBuff);
        SetFocus(GetDlgItem( hDlg, IDC_EDIT1));
        return (TRUE);
	  }
      case WM_COMMAND: {                    /* message: received a command */
        switch(LOWORD(wParam)) {
            case IDOK:                      /* "OK" box selected?          */
            {
               GetDlgItemText( hDlg, IDC_EDIT1, szBuff, iBuffLen);
                  EndDialog( hDlg, IDOK);
            }
            break;

         case IDCANCEL: /* System menu close command? */
            EndDialog(hDlg, IDCANCEL);           /* Exits the dialog box        */
            break;
         default:
           return FALSE;
         }
                return (TRUE);
      }
    }   /* switch message */

    return (FALSE);                           /* Didn't process a message    */
        UNREFERENCED_PARAMETER(lParam);
}



int getstringw(x,y,str,len,gmode)
int x ;			/*-- no use here --*/
int y ;			/*-- no use here --*/
char *str ;
int len ;
int gmode ;     /*-- 1: normal, 2: password --*/
{
	int iStatus;
	HWND hWnd = GetActiveWindow();
	HANDLE hInst = (HANDLE) GetClassLong(hWnd, GCL_HMODULE);
	lstrcpy(szBuff, str);
	iBuffLen = len;

	iStatus = DialogBox(hInst,             /* current instance         */
	MAKEINTRESOURCE(IDD_INPUTDLG),                      /* resource to use          */
	hWnd,                              /* parent handle            */
	GetStringDlgProc);                       /* instance address         */

	if (iStatus==IDOK)
	{
		lstrcpy(str, szBuff);
		return lstrlen(szBuff);
	}
	else return 0;

}

