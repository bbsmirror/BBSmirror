//#include <dos.h>
#include <windows.h>
#include <conio.h>
//#include <ctype.h>
#include "pcpbbs.h"
#include "msg.h"
#include "proto.h"
#include "mycon.h"

int chat_room(buf)
char *buf ;
{
  char tmp[100] ;
  char prot ;
  long l ;
  int i,
      len,
      quit=FALSE,
      cy=1,       /* chat y-axis */
      sx=2 ;
  int tcpstat;

  unsigned int chr ;

  /* init screen */
  clrscr() ;
  for(i=1; i<=LINES-3; i++)
    show("\n") ;
  memset(tmp,'=',80) ;
  tmp[80]=0 ;
  len=strlen(buf) ;
  if(len<40)
  {
    write(1,tmp,40) ;
    write(1,buf,len) ;
    write(1,tmp,COLUMNS-len-40) ;
  }
  else
  {
    write(1,tmp,COLUMNS-len) ;
    write(1,buf,len) ;
  }
  show("\n>") ;

  i=0 ;
  while(TRUE)      /* into chat room & start talking */
  {
    i++ ;
    if(i>5)
    {
      i=0 ;
      tcpstat=read_mpf(buf,&l,&prot,!quit);	/*if not quit use no-wait mode*/
      if( tcpstat==1 )				/*otherwise use wait mode to wait ENDTALK*/
      {
        buf[l]=0 ;
        if( prot==ENDTALK )
        {
	  /*quit talk until ENDTALK protocol get*/
	  /*old version has a state-bug in talk procudure*/
	  /*2.0 uses ENDTALK to prevent from receiving TALK after STOPTALK send*/

	  break;
	  /*break while loop*/
        }

        if( prot==TALK )
        {
          gotoxy(1,cy++) ;
          erase_line() ;
          show(buf) ;
          if(cy>LINES-3)
          {
            cy=1 ;
          }
          gotoxy(1,cy) ;
          erase_line() ;
          show("---->") ;

          gotoxy(sx,LINES) ;
        }

        if( prot==REJECT )
        {
          show("\n") ;
	  printf("System rejected!\n");
	  end_tcp();
	  exit(14);
        }
      }/*end if(tcpstat)*/
      else if( tcpstat<0 )
      {
	show("\n");
	printf("network error in talking!\n");
	end_tcp();
	exit(14);
      }
    }/* reduce the read_mpf() time */

    if( bioskey(1)!=0 )         /* key pressed */
    {
      chr=bioskey(0) & 0xff ;

      if( quit )
	continue;	/* ctrl-e has been pressed, skip all keyboard input*/

      switch(chr)
      {
        case 8:
          if(sx>2)
          {
            cprintf("%c%c%c",8,32,8) ;
            tmp[sx--]=0 ;
          }
          break ;
        case 10:
        case 13:
          tmp[sx]=0 ;
          if(sx>2)
          {
            send_mpf(&tmp[2],sx-2,TALK) ;
            erase_line() ;
            show(">") ;
            memset(tmp,0,80) ;
            sx=2 ;
          }
          break ;
        case 5:		/*ctrl-e or ctrl-q to exit*/
        case 17:
          quit=TRUE ;
          send_mpf(buf,1,STOPTALK) ;
          break ;
        default:
          if( sx<COLUMNS-18 && chr>=32 )
          {
            write(1,&chr,1) ;
            tmp[sx++]=chr ;
          }
      }/*end switch*/
    }/*end if(bioskey)*/
  } /* end while */

  return(0);
}
