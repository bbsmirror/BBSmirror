/************************************************************************
        PowerBBS Client NF Module (Not-Flexible)
        by Samson Chen
        Oct 28, 1994
 ************************************************************************/

#include "pcpbbs.h"
#include <conio.h>
#include <process.h>
#include "proto.h"
#include "msg.h"

char *menu1[]={MENU10, MENU11, MENU12, MENU13, MENU14, MENU15, MENU16, MENU17};
char *menu2[]={MENU20, MENU21, MENU22, MENU23};
char *menu3[]={MENU30, MENU31, MENU32, MENU33, MENU34, MENU35, MENU36, MENU37, MENU38};
char *menu4[]={MENU40, MENU41, MENU42, MENU43, MENU44};
char *menu5[]={MENU50, MENU51, MENU52, MENU53, MENU54, MENU55, MENU56, MENU57, MENU58};

int m_cur_x, m_cur_y;

/*
        pop_menu --- pop up main menu
*/
pop_menu()
        /*
          return: >0  : ASCII
                   0  : request protocol sent
        */
{
        int key;
        int i;
        char clean[80];
        char sprompt[50];
        static int item1=1, item2=1, item3=1, item4=1, item5=1;
        static int current_menu=1;
        int item;
        char user_select=FALSE;
        int get_key;
        char user_key;
        char direct_press;

        normal_text();
        cursor_off();

        if( mouse_mode )
        {
                switch(current_menu)
                {
                case 1:
                        m_cur_x=3;
                        m_cur_y=11;
                        break;
                case 2:
                        m_cur_x=21;
                        m_cur_y=12;
                        break;
                case 3:
                        m_cur_x=32;
                        m_cur_y=11;
                        break;
                case 4:
                        m_cur_x=48;
                        m_cur_y=12;
                        break;
                case 5:
                        m_cur_x=60;
                        m_cur_y=11;
                        break;
                }
                set_mouse_cursor(m_cur_x, m_cur_y);
                show_mouse_cursor();
        }

        show_menu(5, FALSE);
        show_menu(4, FALSE);
        show_menu(3, FALSE);
        show_menu(2, FALSE);
        show_menu(1, FALSE);

	if( !term_mode )
	{
		gotoxy(5, 23); printf("^D : Shell");
		gotoxy(5, 24); printf("^O : Change Download Path");
	}

        direct_press=FALSE;

        do
        {
          switch(current_menu)
          {
          case 1:

            /*************************************************************
             * MENU 1 Operation
             *************************************************************/

            show_menu(1, TRUE);

            get_key=FALSE;
            do
            {
              sprintf(sprompt, "%s%s", MENUSEL, menu1[item1]);
              sprompt[strlen(sprompt)-1]=0;     /*strip quick key display*/
              gotoxy(1, 11);
              printf("%s", sprompt);

              if( direct_press )
              {
                /*user select a function by key or mouse directly*/
                get_key=TRUE;
                user_select=TRUE;
                continue;
              }

              inverse_text();
              gotoxy(6, 14+item1);
              cprintf("%s", menu1[item1]);

              do
              {
                get_key=get_user_input(1, &user_key);

                if(get_key==5)  /*key input*/
                  if( !valid_key_check(user_key) )
                    continue;

                break;

              }while(TRUE);

              normal_text();
              gotoxy(6, 14+item1);
              cprintf("%s", menu1[item1]);

              switch(get_key)
              {
              case 0:   /*enter*/
                map_menu(&user_key, current_menu, item1);
                get_key=TRUE;
                user_select=TRUE;
                break;

              case 1:   /*up*/
                item1--;
                if( item1<=0 )
                        item1=7;
                get_key=FALSE;
                break;

              case 2:   /*down*/
                item1++;
                if( item1>=8 )
                        item1=1;
                get_key=FALSE;
                break;

              case 3:   /*right*/
                current_menu=2;
                break;

              case 4:   /*left*/
                current_menu=5;
                break;

              case 5:   /*key input*/
                if( user_key==4 || user_key==15 )
                  user_select=TRUE;
                else
                {
                  map_key(&current_menu, &item1, &item2, &item3, &item4, &item5, user_key);
                  direct_press=TRUE;
                }

                break;

              default:
                if( get_key>=10 && get_key<=70 )
                {
                        map_menu(&user_key, 1, get_key/10);
                  	map_key(&current_menu, &item1, &item2, &item3, &item4, &item5, user_key);

                        inverse_text();
                        gotoxy(6, 14+get_key/10);
                        cprintf("%s", menu1[get_key/10]);
                        delay(150);
                        normal_text();
                        direct_press=TRUE;
                        break;
                }
                else if( get_key>=1000 )
                {
                        current_menu=get_key/1000;
                        break;
                }
                else
                {
                        get_key=FALSE;
                        break;
                }

              }/*end of switch*/

            }while(!get_key);

            down_menu(1);
            break;

          case 2:

            /*************************************************************
             * MENU 2 Operation
             *************************************************************/

            show_menu(2, TRUE);

            get_key=FALSE;
            do
            {
              sprintf(sprompt, "%s%s", MENUSEL, menu2[item2]);
              sprompt[strlen(sprompt)-1]=0;     /*strip quick key display*/
              gotoxy(1, 11);
              printf("%s", sprompt);

              if( direct_press )
              {
                /*user select a function by key directly*/
                get_key=TRUE;
                user_select=TRUE;
                continue;
              }

              inverse_text();
              gotoxy(20, 15+item2);
              cprintf("%s", menu2[item2]);

              do
              {
                get_key=get_user_input(2, &user_key);

                if(get_key==5)  /*key input*/
                  if( !valid_key_check(user_key) )
                    continue;

                break;

              }while(TRUE);

              normal_text();
              gotoxy(20, 15+item2);
              cprintf("%s", menu2[item2]);

              switch(get_key)
              {
              case 0:   /*enter*/
                map_menu(&user_key, current_menu, item2);
                get_key=TRUE;
                user_select=TRUE;
                break;

              case 1:   /*up*/
                item2--;
                if( item2<=0 )
                        item2=3;
                get_key=FALSE;
                break;

              case 2:   /*down*/
                item2++;
                if( item2>=4 )
                        item2=1;
                get_key=FALSE;
                break;

              case 3:   /*right*/
                current_menu=3;
                break;

              case 4:   /*left*/
                current_menu=1;
                break;

              case 5:   /*key input*/
                if( user_key==4 || user_key==15 )
                  user_select=TRUE;
                else
                {
                  map_key(&current_menu, &item1, &item2, &item3, &item4, &item5, user_key);
                  direct_press=TRUE;
                }

                break;

              default:
                if( get_key>=10 && get_key<=30 )
                {
                        map_menu(&user_key, 2, get_key/10);
                  	map_key(&current_menu, &item1, &item2, &item3, &item4, &item5, user_key);

                        inverse_text();
                        gotoxy(20, 15+get_key/10);
                        cprintf("%s", menu2[get_key/10]);
                        delay(150);
                        normal_text();
                        direct_press=TRUE;
                        break;
                }
                else if( get_key>=1000 )
                {
                        current_menu=get_key/1000;
                        break;
                }
                else
                {
                        get_key=FALSE;
                        break;
                }

              }/*end of switch*/

            }while(!get_key);

            down_menu(2);
            break;

          case 3:

            /*************************************************************
             * MENU 3 Operation
             *************************************************************/

            show_menu(3, TRUE);

            get_key=FALSE;
            do
            {
              sprintf(sprompt, "%s%s", MENUSEL, menu3[item3]);
              sprompt[strlen(sprompt)-1]=0;     /*strip quick key display*/
              gotoxy(1, 11);
              printf("%s", sprompt);

              if( direct_press )
              {
                /*user select a function by key directly*/
                get_key=TRUE;
                user_select=TRUE;
                continue;
              }

              inverse_text();
              gotoxy(34, 14+item3);
              cprintf("%s", menu3[item3]);

              do
              {
                get_key=get_user_input(3, &user_key);

                if(get_key==5)  /*key input*/
                  if( !valid_key_check(user_key) )
                    continue;

                break;

              }while(TRUE);

              normal_text();
              gotoxy(34, 14+item3);
              cprintf("%s", menu3[item3]);

              switch(get_key)
              {
              case 0:   /*enter*/
                map_menu(&user_key, current_menu, item3);
                get_key=TRUE;
                user_select=TRUE;
                break;

              case 1:   /*up*/
                item3--;
                if( item3<=0 )
                        item3=8;
                get_key=FALSE;
                break;

              case 2:   /*down*/
                item3++;
                if( item3>=9 )
                        item3=1;
                get_key=FALSE;
                break;

              case 3:   /*right*/
                current_menu=4;
                break;

              case 4:   /*left*/
                current_menu=2;
                break;

              case 5:   /*key input*/
                if( user_key==4 || user_key==15 )
                  user_select=TRUE;
                else
                {
                  map_key(&current_menu, &item1, &item2, &item3, &item4, &item5, user_key);
                  direct_press=TRUE;
                }

                break;

              default:
                if( get_key>=10 && get_key<=80 )
                {
                        map_menu(&user_key, 3, get_key/10);
                  	map_key(&current_menu, &item1, &item2, &item3, &item4, &item5, user_key);

                        inverse_text();
                        gotoxy(34, 14+get_key/10);
                        cprintf("%s", menu3[get_key/10]);
                        delay(150);
                        normal_text();
                        direct_press=TRUE;
                        break;
                }
                else if( get_key>=1000 )
                {
                        current_menu=get_key/1000;
                        break;
                }
                else
                {
                        get_key=FALSE;
                        break;
                }

              }/*end of switch*/

            }while(!get_key);

            down_menu(3);
            break;

          case 4:

            /*************************************************************
             * MENU 4 Operation
             *************************************************************/

            show_menu(4, TRUE);

            get_key=FALSE;
            do
            {
              sprintf(sprompt, "%s%s", MENUSEL, menu4[item4]);
              sprompt[strlen(sprompt)-1]=0;     /*strip quick key display*/
              gotoxy(1, 11);
              printf("%s", sprompt);

              if( direct_press )
              {
                /*user select a function by key directly*/
                get_key=TRUE;
                user_select=TRUE;
                continue;
              }

              inverse_text();
              gotoxy(48, 15+item4);
              cprintf("%s", menu4[item4]);

              do
              {
                get_key=get_user_input(4, &user_key);

                if(get_key==5)  /*key input*/
                  if( !valid_key_check(user_key) )
                    continue;

                break;

              }while(TRUE);

              normal_text();
              gotoxy(48, 15+item4);
              cprintf("%s", menu4[item4]);

              switch(get_key)
              {
              case 0:   /*enter*/
                map_menu(&user_key, current_menu, item4);
                get_key=TRUE;
                user_select=TRUE;
                break;

              case 1:   /*up*/
                item4--;
                if( item4<=0 )
                        item4=4;
                get_key=FALSE;
                break;

              case 2:   /*down*/
                item4++;
                if( item4>=5 )
                        item4=1;
                get_key=FALSE;
                break;

              case 3:   /*right*/
                current_menu=5;
                break;

              case 4:   /*left*/
                current_menu=3;
                break;

              case 5:   /*key input*/
                if( user_key==4 || user_key==15 )
                  user_select=TRUE;
                else
                {
                  map_key(&current_menu, &item1, &item2, &item3, &item4, &item5, user_key);
                  direct_press=TRUE;
                }

                break;

              default:
                if( get_key>=10 && get_key<=40 )
                {
                        map_menu(&user_key, 4, get_key/10);
                  	map_key(&current_menu, &item1, &item2, &item3, &item4, &item5, user_key);

                        inverse_text();
                        gotoxy(48, 15+get_key/10);
                        cprintf("%s", menu4[get_key/10]);
                        delay(150);
                        normal_text();
                        direct_press=TRUE;
                        break;
                }
                else if( get_key>=1000 )
                {
                        current_menu=get_key/1000;
                        break;
                }
                else
                {
                        get_key=FALSE;
                        break;
                }

              }/*end of switch*/

            }while(!get_key);

            down_menu(4);
            break;

          case 5:

            /*************************************************************
             * MENU 5 Operation
             *************************************************************/

            show_menu(5, TRUE);

            get_key=FALSE;
            do
            {
              sprintf(sprompt, "%s%s", MENUSEL, menu5[item5]);
              sprompt[strlen(sprompt)-1]=0;     /*strip quick key display*/
              gotoxy(1, 11);
              printf("%s", sprompt);

              if( direct_press )
              {
                /*user select a function by key directly*/
                get_key=TRUE;
                user_select=TRUE;
                continue;
              }

              inverse_text();
              gotoxy(62, 14+item5);
              cprintf("%s", menu5[item5]);

              do
              {
                get_key=get_user_input(5, &user_key);

                if(get_key==5)  /*key input*/
                  if( !valid_key_check(user_key) )
                    continue;

                break;

              }while(TRUE);

              normal_text();
              gotoxy(62, 14+item5);
              cprintf("%s", menu5[item5]);

              switch(get_key)
              {
              case 0:   /*enter*/
                map_menu(&user_key, current_menu, item5);
                get_key=TRUE;
                user_select=TRUE;
                break;

              case 1:   /*up*/
                item5--;
                if( item5<=0 )
                        item5=8;
                get_key=FALSE;
                break;

              case 2:   /*down*/
                item5++;
                if( item5>=9 )
                        item5=1;
                get_key=FALSE;
                break;

              case 3:   /*right*/
                current_menu=1;
                break;

              case 4:   /*left*/
                current_menu=4;
                break;

              case 5:   /*key input*/
                if( user_key==4 || user_key==15 )
                  user_select=TRUE;
                else
                {
                  map_key(&current_menu, &item1, &item2, &item3, &item4, &item5, user_key);
                  direct_press=TRUE;
                }
                break;

              default:
                if( get_key>=10 && get_key<=80 )
                {
                        map_menu(&user_key, 5, get_key/10);
                  	map_key(&current_menu, &item1, &item2, &item3, &item4, &item5, user_key);

                        inverse_text();
                        gotoxy(62, 14+get_key/10);
                        cprintf("%s", menu5[get_key/10]);
                        delay(150);
                        normal_text();
                        direct_press=TRUE;
                        break;
                }
                else if( get_key>=1000 )
                {
                        current_menu=get_key/1000;
                        break;
                }
                else
                {
                        get_key=FALSE;
                        break;
                }

              }/*end of switch*/

            }while(!get_key);

            down_menu(5);
            break;

          }
        }while( !user_select);

        /*clear popmenus and return to normal mode*/
        normal_text();
        memset(clean, ' ', 79);
        clean[79]=0;
        for(i=12; i<=24; i++)
        {
                gotoxy(1, i);
                cprintf("%s", clean);
        }
        gotoxy(1,12);
        cursor_on();
        if( mouse_mode )
                hide_mouse_cursor();

        return(user_key);

}
/*end of pop_menu*/



/*
        get_user_input --- keyboard or mouse
*/
get_user_input(cmenu, ukey)
        int cmenu;      /*current menu*/
        char *ukey;
/*
        RETURN:
                0       enter
                1       up
                2       down
                3       right
                4       left
                5       user key (put in ukey)
                10      item[1]
                20      item[2]
                30      item[3]
                ...
                1000    jump to menu1
                2000    jump to menu2
                3000    jump to menu3
                ...
*/
{
        int x,y,a,b;
        int ret;
        int key;

        ret=0;
        gotoxy(79,25);  /*when press [->] in chinese...skip this problem*/

        do
        {
          if( mouse_mode )
          {
            mouse_xy_press(&x, &y, &a, &b);

            if( a==1 )  /*mouse left button pressed*/
            {
              /*hold until mouse button depressed*/
              while( a!=0 )
                  mouse_xy_press(&x, &y, &a, &b);

              switch(cmenu)
              {
              /*individual function check*/
              case 1:
                if( x>=5 && x<=18 )
                  if( y>=14 && y<=20 )
                    ret=(y-13)*10;
                break;

              case 2:
                if( x>=19 && x<=32 )
                  if( y>=15 && y<=17 )
                    ret=(y-14)*10;
                break;

              case 3:
                if( x>=33 && x<=46 )
                  if( y>=14 && y<=21 )
                    ret=(y-13)*10;
                break;

              case 4:
                if( x>=47 && x<=60 )
                  if( y>=15 && y<=18 )
                    ret=(y-14)*10;
                break;

              case 5:
                if( x>=61 && x<=74 )
                  if( y>=14 && y<=21 )
                    ret=(y-13)*10;
                break;
              }/*end switch*/

              /*check if jump to other menu*/
              if( ret==0 )
              {
                if( x>=3 && y>=11 && x<=20 && y<=21 )
                        ret=1000;
                else if ( x>=21 && y>=12 && x<=31 && y<=18 )
                        ret=2000;
                else if ( x>=32 && y>=11 && x<=47 && y<=22 )
                        ret=3000;
                else if ( x>=48 && y>=12 && x<=59 && y<=19 )
                        ret=4000;
                else if ( x>=60 && y>=11 && x<=75 && y<=22 )
                        ret=5000;
                else
                        ret=0;

              }/*endif(ret==0)*/
            }/*endif(a==1)*/

            if( ret!=0 ) continue;
          }/*endif(mouse_mode)*/

          if( kbhit() )
          {
            key=bioskey(0);

            if( (key & 0xff)==0 )
            {
              key=key>>8;

              if( key==72 )     /*up*/
                ret=1;

              if( key==77 )     /*right*/
                ret=3;

              if( key==75 )     /*left*/
                ret=4;

              if( key==80 )     /*down*/
                ret=2;

              continue;

            }/*endif arrowkey*/

            key=toupper(key);
            if( key==13 )
                return(0);

            if( valid_key_check(key) )
            {
                *ukey=key;
                ret=5;
            }

            continue;

          }/*endif(kbhit)*/

        }while(ret==0);

        return(ret);

}
/*end of get_user_input*/



/*
        map_menu --- map menu item to quick key
*/
map_menu(key, menu, item)
        char *key;      /*mapped key*/
        int menu;
        int item;
{
        switch(menu)
        {
        case 1:         /*menu1*/
          switch(item)
          {
          case 1:
            *key='J';
            break;
          case 2:
            *key='Q';
            break;
          case 3:
            *key='I';
            break;
          case 4:
            *key='F';
            break;
          case 5:
            *key='P';
            break;
          case 6:
            *key='R';
            break;
          case 7:
            *key='E';
            break;
          default:
            *key='H';
            break;
          }
          break;

        case 2:         /*menu2*/
          switch(item)
          {
          case 1:
            *key='N';
            break;
          case 2:
            *key='Y';
            break;
          case 3:
            *key='A';
            break;
          default:
            *key='H';
            break;
          }
          break;

        case 3:         /*menu3*/
          switch(item)
          {
          case 1:
            *key='B';
            break;
          case 2:
            *key='V';
            break;
          case 3:
            *key='H';
            break;
          case 4:
            *key='W';
            break;
          case 5:
            *key='C';
            break;
          case 6:
            *key='X';
            break;
          case 7:
            *key='G';
            break;
          case 8:
            *key='!';
            break;
          default:
            *key='H';
            break;
          }
          break;

        case 4:         /*menu4*/
          switch(item)
          {
          case 1:
            *key='T';
            break;
          case 2:
            *key='O';
            break;
          case 3:
            *key='D';
            break;
          case 4:
            *key='U';
            break;
          default:
            *key='H';
            break;
          }
          break;

        case 5:         /*menu5*/
          switch(item)
          {
          case 1:
            *key='S';
            break;
          case 2:
            *key='*';
            break;
          case 3:
            *key='$';
            break;
          case 4:
            *key='#';
            break;
          case 5:
            *key='%';
            break;
          case 6:
            *key='Z';
            break;
          case 7:
            *key='K';
            break;
          case 8:
            *key='M';
            break;
          default:
            *key='H';
            break;
          }
          break;

        default:
          *key='H';
          break;
        }

        return(0);
}
/*end of map_menu*/



/*
        map_key --- map keu to menu item
*/
map_key(menu, item1, item2, item3, item4, item5, key)
        int *menu;
        int *item1;
        int *item2;
        int *item3;
        int *item4;
        int *item5;
        char key;
{
        switch(key)
        {
        /*--- menu1 ---*/

        case 'J':
                *menu=1;
                *item1=1;
                break;

        case 'Q':
                *menu=1;
                *item1=2;
                break;

        case 'I':
                *menu=1;
                *item1=3;
                break;

        case 'F':
                *menu=1;
                *item1=4;
                break;

        case 'P':
                *menu=1;
                *item1=5;
                break;

        case 'R':
                *menu=1;
                *item1=6;
                break;

        case 'E':
                *menu=1;
                *item1=7;
                break;

        /*--- menu2 ---*/

        case 'N':
                *menu=2;
                *item2=1;
                break;

        case 'Y':
                *menu=2;
                *item2=2;
                break;

        case 'A':
                *menu=2;
                *item2=3;
                break;

        /*--- menu3 ---*/

        case 'B':
                *menu=3;
                *item3=1;
                break;

        case 'V':
                *menu=3;
                *item3=2;
                break;

        case 'H':
                *menu=3;
                *item3=3;
                break;

        case 'W':
                *menu=3;
                *item3=4;
                break;

        case 'C':
                *menu=3;
                *item3=5;
                break;

        case 'X':
                *menu=3;
                *item3=6;
                break;

        case 'G':
                *menu=3;
                *item3=7;
		break;

        case '!':
                *menu=3;
                *item3=8;
                break;

        /*--- menu4 ---*/

        case 'T':
                *menu=4;
                *item4=1;
                break;

        case 'O':
                *menu=4;
                *item4=2;
                break;

        case 'D':
                *menu=4;
                *item4=3;
                break;

        case 'U':
                *menu=4;
                *item4=4;
                break;

        /*--- menu5 ---*/

        case 'S':
                *menu=5;
                *item5=1;
                break;

        case '*':
                *menu=5;
                *item5=2;
                break;

        case '$':
                *menu=5;
                *item5=3;
                break;

        case '#':
                *menu=5;
                *item5=4;
                break;

        case '%':
                *menu=5;
                *item5=5;
                break;

        case 'Z':
                *menu=5;
                *item5=6;
                break;

        case 'K':
                *menu=5;
                *item5=7;
                break;

        case 'M':
                *menu=5;
                *item5=8;
                break;

        /*--- set default to HELP function ---*/

        default:
                *menu=3;
                *item3=3;
                break;
        }

        return(0);
}
/*end of map_key*/



/*
        valid_key_check --- check if key valid
*/
valid_key_check(key)
        int key;
/*
        RETURN: TRUE: OK
                FALSE: not allowed key
*/
{
        int ret;

        switch(key)
        {
                case  4 :       /*ctrl-D*/
                case 13 :       /*[Enter]*/
                case 15 :       /*ctrl-O*/
                case 'A':
                case 'B':
                case 'C':
                case 'D':
                case 'E':
                case 'F':
                case 'G':
                case 'H':
                case 'I':
                case 'J':
                case 'K':
                case 'M':
                case 'N':
                case 'O':
                case 'P':
                case 'Q':
                case 'R':
                case 'S':
                case 'T':
                case 'U':
                case 'V':
                case 'W':
                case 'X':
                case 'Y':
                case 'Z':
                case '!':
                case '*':
                case '$':
                case '#':
                case '%':
                        ret=TRUE;
                        break;

                default:
                        ret=FALSE;
                        break;
        }

        return(ret);
}
/*end of valid_key_check*/



/*
        get bolder style
*/
get_bolder(up, bup, bsp, bmd, bdn)
        char up;        /*up or down*/
        char *bup;
        char *bsp;
        char *bmd;
        char *bdn;
{
        if(up)
        {
                strcpy(bup, UBOLDUP);
                strcpy(bsp, UBOLDSP);
                strcpy(bmd, UBOLDMD);
                strcpy(bdn, UBOLDDN);
        }
        else
        {
                strcpy(bup, DBOLDUP);
                strcpy(bsp, DBOLDSP);
                strcpy(bmd, DBOLDMD);
                strcpy(bdn, DBOLDDN);
        }

        return(0);
}
/*end of get_bolder*/



/*
        put_bolder --- draw bolder lines
*/
put_bolder(cx, cy, size, bup, bsp, bmd, bdn)
        int cx;         /*conner X*/
        int cy;         /*conner Y*/
        int size;       /*lines*/
        char *bup;
        char *bsp;
        char *bmd;
        char *bdn;
{
        int i;

        /*draw bolder*/
        gotoxy(cx, cy);
        cprintf("%s", bup);
        gotoxy(cx, cy+1);
        cprintf("%s", bmd);
        gotoxy(cx, cy+2);
        cprintf("%s", bsp);

        for(i=1; i<=size; i++)
        {
                gotoxy(cx, cy+2+i);
                cprintf("%s", bmd);
        }

        gotoxy(cx, cy+2+size+1);
        cprintf("%s", bdn);

        return(0);
}
/*end of put_bolder*/



/*
        show_menu
*/
show_menu(smenu, up)
        int smenu;
        char up;        /*up or down*/
{
        char bup[50], bsp[50], bmd[50], bdn[50];
        char v[3];
        int cx,cy,h;
        int i;

        switch(smenu)
        {
        case 1:
                cx=4;
                cy=12;
                h=7;
                break;
        case 2:
                cx=18;
                cy=13;
                h=3;
                break;
        case 3:
                cx=32;
                cy=12;
                h=8;
                break;
        case 4:
                cx=46;
                cy=13;
                h=4;
                break;
        case 5:
                cx=60;
                cy=12;
                h=8;
                break;
        }

        get_bolder(up, bup, bsp, bmd, bdn);
        put_bolder(cx, cy, h, bup, bsp, bmd, bdn);


        gotoxy(cx+2, cy+1);

        switch(smenu)
        {
        case 1:
                cprintf("%s", menu1[0]);
                break;
        case 2:
                cprintf("%s", menu2[0]);
                break;
        case 3:
                cprintf("%s", menu3[0]);
                break;
        case 4:
                cprintf("%s", menu4[0]);
                break;
        case 5:
                cprintf("%s", menu5[0]);
                break;
        }

        for(i=1; i<=h; i++)
        {
                gotoxy(cx+2, cy+2+i);

                switch(smenu)
                {
                case 1:
                        cprintf("%s", menu1[i]);
                        break;
                case 2:
                        cprintf("%s", menu2[i]);
                        break;
                case 3:
                        cprintf("%s", menu3[i]);
                        break;
                case 4:
                        cprintf("%s", menu4[i]);
                        break;
                case 5:
                        cprintf("%s", menu5[i]);
                        break;
                }
        }

        return(0);

}
/*end of show_menu*/



/*
        down_menu --- draw just down bolder
*/
down_menu(dmenu)
        int dmenu;
{
        char v[3];
        int cx,cy,h;
        int i;

        strncpy(v, DBOLDMD, 2);
        v[2]=0;

        switch(dmenu)
        {
        case 1:
                cx=4;
                cy=12;
                h=7;
                break;
        case 2:
                cx=18;
                cy=13;
                h=3;
                break;
        case 3:
                cx=32;
                cy=12;
                h=8;
                break;
        case 4:
                cx=46;
                cy=13;
                h=4;
                break;
        case 5:
                cx=60;
                cy=12;
                h=8;
                break;
        }

        /*draw bolder*/
        gotoxy(cx, cy);
        cprintf("%s", DBOLDUP);

        gotoxy(cx, cy+1);
        cprintf("%s", v);
        gotoxy(cx+16, cy+1);
        cprintf("%s", v);

        gotoxy(cx, cy+2);
        cprintf("%s", DBOLDSP);

        for(i=1; i<=h; i++)
        {
                gotoxy(cx, cy+2+i);
                cprintf("%s", v);
                gotoxy(cx+16, cy+2+i);
                cprintf("%s", v);
        }

        gotoxy(cx, cy+2+h+1);
        cprintf("%s", DBOLDDN);

        return(0);
}
/*end of down_menu*/



/*
        set inverse text color
*/
inverse_text()
{
        if( mono )
        {
                textbackground(WHITE);
                textcolor(BLACK);
        }
        else
        {
                textbackground(BLUE);
                textcolor(WHITE);
        }

        highvideo();

        return(0);
}
/*end of inverse_text*/



/*
       set normal text color
*/
normal_text()
{
        textbackground(BLACK);
        textcolor(LIGHTGRAY);
        lowvideo();

        return(0);
}
/*end if normal_text*/



/*
        cursor_off
*/
cursor_off()
{
 union REGS regs;

 regs.h.ah=0x01;
 regs.x.cx=0x1e00;
 int86(0x10,&regs,&regs);

 return(0);
}
/*end of cursor_off*/



/*
        cursor_on
*/
cursor_on()
{
 union REGS regs;

 regs.h.ah=0x01;
 regs.x.cx=0x0a0b;
 int86(0x10,&regs,&regs);

 return(0);
}
/*end of cursor_on*/



/*
        map_key_menuprotocol --- map key to menu protocol string
*/
map_key_menuprotocol(menups, ukey)
        char *menups;
        char ukey;
/*
        RETURN: TRUE    ok (result in menups)
                FALSE   ukey not defined
*/
{
        int ret;

        ret=TRUE;

        switch(ukey)
        {
                case 'A':
                  strcpy(menups, "{Send_Email}");
                  break;
                case 'B':
                  strcpy(menups, "{Bulletin}");
                  break;
                case 'C':
                  strcpy(menups, "{Chat_Room}");
                  break;
                case 'D':
                  strcpy(menups, "{Download_File}");
                  break;
                case 'E':
                  strcpy(menups, "{Enter_Mail}");
                  break;
                case 'F':
                  strcpy(menups, "{File_Post}");
                  break;
                case 'G':
                  strcpy(menups, "{Internet}");
                  break;
                case 'H':
                  strcpy(menups, "{Help_Main}");
                  break;
                case 'I':
                  strcpy(menups, "{Inter_Read}");
                  break;
                case 'J':
                  strcpy(menups, "{Change_Area}");
                  break;
                case 'K':
                  strcpy(menups, "{Power_Net}");
                  break;
                case 'M':
                  strcpy(menups, "{More_Functions}");
                  break;
                case 'N':
                  strcpy(menups, "{Read_Mbox}");
                  break;
                case 'O':
                  strcpy(menups, "{Reset_Toggle}");
                  break;
                case 'P':
                  strcpy(menups, "{Previous_Mail}");
                  break;
                case 'Q':
                  strcpy(menups, "{Quick_Join}");
                  break;
                case 'R':
                  strcpy(menups, "{Read_Mail}");
                  break;
                case 'S':
                  strcpy(menups, "{List_Users}");
                  break;
                case 'T':
                  strcpy(menups, "{Toggle_File}");
                  break;
                case 'U':
                  strcpy(menups, "{Upload_File}");
                  break;
                case 'V':
                  strcpy(menups, "{Version_Info}");
                  break;
                case 'W':
                  strcpy(menups, "{Welcome}");
                  break;
                case 'X':
                  strcpy(menups, "{Write_User}");
                  break;
                case 'Y':
                  strcpy(menups, "{Send_Mbox}");
                  break;
                case 'Z':
                  strcpy(menups, "{Zap_Area}");
                  break;
                case '!':
                  strcpy(menups, "{Goodbye}");
                  break;
                case '*':
                  strcpy(menups, "{Password}");
                  break;
                case '$':
                  strcpy(menups, "{UP_Data}");
                  break;
                case '#':
                  strcpy(menups, "{Ping}");
                  break;
                case '%':
                  strcpy(menups, "{Switch_Page}");
                  break;

                default:
                        ret=FALSE;
                        break;
        }

        return(ret);
}
/*end of map_key_menuprotocol*/



/*
        user_confirm --- user press any key to continue
*/
user_confirm()
{
        int oldx, oldy;
        int x,y,a,b;

        oldx=wherex();
        oldy=wherey();
        cursor_off();

        if( mouse_mode )
        {
                gotoxy(72, 25);
                highvideo();
		if( !mono )
		{
                  textbackground(GREEN);
                  textcolor(WHITE);
		}
                cprintf("%s", MB_CONFIRM);
                normal_text();

                set_mouse_cursor(71, 24);
                show_mouse_cursor();
        }

        do
        {

          if( mouse_mode )
          {
            mouse_xy_press(&x, &y, &a, &b);

	   if( b==1 )  /*mouse right button pressed (quit)*/
	   {
              	  /*hold until mouse button depressed*/
              	  while( b!=0 )
                    mouse_xy_press(&x, &y, &a, &b);

                  inverse_text();
                  gotoxy(72, 25);
                  cprintf("%s", MB_CONFIRM);
                  normal_text();
		  break;
	    }

            if( a==1 )  /*mouse left button pressed*/
            {
              /*hold until mouse button depressed*/
              while( a!=0 )
                  mouse_xy_press(&x, &y, &a, &b);

              if( x>=71 && x<=76 && y==24 )
              {
                inverse_text();
                gotoxy(72, 25);
                cprintf("%s", MB_CONFIRM);
                normal_text();
                break;
              }
            }
          }/*end mouse*/

          if( kbhit() )
          {
                getch();
                break;
          }

        } while(TRUE);

        if( mouse_mode )
        {
          gotoxy(72, 25);
          cprintf("      ");
          hide_mouse_cursor();
        }

        gotoxy(oldx, oldy);
        cursor_on();

        return(0);
}
/*end of user_confirm*/



/*
        yesno_confirm --- get yes/no from user
*/
yesno_confirm(buf)
	char *buf;
/*
	the answer 'y' or 'n' put in buf[0]
*/
{
        int oldx, oldy;
        int x,y,a,b;
	char answer;
	char line[10];

	show(buf);

        oldx=wherex();
        oldy=wherey();

        if( mouse_mode )
        {
		gotoxy(68, 25);
		show(YN_MOUSE);
                set_mouse_cursor(72, 24);
                show_mouse_cursor();
        }

        gotoxy(oldx, oldy);

        do
        {
          if( mouse_mode )
          {
            mouse_xy_press(&x, &y, &a, &b);

            if( a==1 )  /*mouse left button pressed*/
            {
              /*hold until mouse button depressed*/
              while( a!=0 )
                  mouse_xy_press(&x, &y, &a, &b);

	      /*yes*/
              if( x>=67 && x<=71 && y==24 )
              {
		answer='y';
		break;
              }

	      /*no*/
	      if( x>=74 && x<=77 && y==24 )
	      {
		answer='n';
		break;
	      }

            }/*end if(mouse_pressed)*/
          }/*end mouse*/

          if( kbhit() )
          {
                answer=tolower(getch());
		if( answer=='y' || answer=='n' )
			break;
          }

        } while(TRUE);

        if( mouse_mode )
	{
          hide_mouse_cursor();
	  gotoxy(68, 25);
	  show("           ");
	}

        gotoxy(oldx, oldy);
	sprintf(line, "%c", toupper(answer));
	show(line);
	show("\n");

	buf[0]=answer;

        return(0);
}
/*end of yesno_confirm*/



/*
	internet --- call 'telnet' to another place in the net
	input format: "<site IP or domain>\crlf<login name>\crlf"
*/
void internet(buf)
	char *buf;
/*
	note: This function is a never-return call.
	      In the other word, program will exist if call this function
*/
{
	char crlf[3];
	char *site;
	char *login;
	char *ptr;
	char *ptr2;
	int argc=0;
	char *argv[10];
	int n;

	sprintf(crlf,"%c%c",13,10) ;

	site=kkytok(buf,crlf) ;
	login=kkytok(NULL,crlf) ;

	show("\n");
	show(INET1);
	show(site);
	show("\n");
	show(INET2);
	show(login);
	show("\n");
	show(INET_PC);

	show("\n");
	show(PRESSANYKEY) ;
	user_confirm();
	show("\n");

	/**********************************************************/
	/* Disconnect with PowerBBS Server			  */
	/* note: TCP Layer in PC Client and TELNET is different,  */
	/*	 so connection must be disconnected before loading*/
	/*	 TELNET	process					  */
	/**********************************************************/
	end_tcp();

	/****************************/
	/*assemble telnet parameters*/
	/****************************/
	ptr=telnet_path;
	while( *ptr==' ' )
	  ptr++;
	if(*ptr!=0)
	{
	  ptr2=ptr+1;
	  while( *ptr2!=' ' && *ptr2!=0 )
		ptr2++;
	}

	while( *ptr!=0 )
	{
		if( !strncmp(ptr, "%1", 2) )
			ptr=site;

		argv[argc++]=ptr;

		if( argc>9 )
			break;

		if( *ptr2!=0 )
		{
			*ptr2=0;
			ptr=ptr2+1;
			while( *ptr==' ' )
			  ptr++;
			if(*ptr!=0)
			{
			  ptr2=ptr+1;
			  while( *ptr2!=' ' && *ptr2!=0 )
				ptr2++;
			}
		}
		else
			break;
	}

	/*display calling parameters*/
	printf("Executing ");
	for(n=0; n<argc; n++)
		printf("%s ", argv[n]);
	printf("\n");

	/**********************/
	/*load another process*/
	/**********************/
	switch(argc)
	{
	case 0:
	case 1:
	  printf("PBBS_TELNET setup error!\n");
	  exit(7);
	case 2:
	  execl(argv[0], argv[0], argv[1], NULL);
	  break;
	case 3:
	  execl(argv[0], argv[0], argv[1], argv[2], NULL);
	  break;
	case 4:
	  execl(argv[0], argv[0], argv[1], argv[2], argv[3], NULL);
	  break;
	case 5:
	  execl(argv[0], argv[0], argv[1], argv[2], argv[3], argv[4], NULL);
	  break;
	case 6:
	  execl(argv[0], argv[0], argv[1], argv[2], argv[3], argv[4], argv[5], NULL);
	  break;
	case 7:
	  execl(argv[0], argv[0], argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], NULL);
	  break;
	case 8:
	  execl(argv[0], argv[0], argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], NULL);
	  break;
	case 9:
	  execl(argv[0], argv[0], argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], NULL);
	  break;
	default:
	  execl(argv[0], argv[0], argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], NULL);
	  break;
	}/*end switch*/

	/*if secceed, exec should not return otherwise something wrong*/
	perror("EXEC error ");

	exit(7);
}
/*end of internet*/
