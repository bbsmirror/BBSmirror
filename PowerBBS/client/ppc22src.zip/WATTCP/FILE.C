/*******************************************************************
    UPLOAD & DOWNLOAD file from server
    Write by Aquarius Kuo on Apr 9, 1994.

    Protocol re-defined and re-implemented by Samson Chen, Apr 1, 1995

    If you want to know detail about file-xfer protocol,
    please refer to the pbbs technical reference
*******************************************************************/
#include "pcpbbs.h"
#include "msg.h"
#include "proto.h"

static char rcsid[]="$Id: file.c,v 1.4 1994/05/17 13:42:50 cs79026 Exp cs79026 $" ;

/***************************************
    download file from server to client
*/
int download(buf,dmode)
char *buf ;
int dmode ;
{
  int handle,tcpstat ;
  int i ;
  char prot ;
  char fn[80] ;
  char *map="-\\|/" ;
  char bs=8 ;
  long BLOCK=1024 ;
  long bsize[10],bn,bt ;
  long len1, flen, fcnt ;
  long get_size;
  int t_bar;    /*turning bar*/
  struct dfree free;    /*for check free disk space*/
  long diskfree;        /*..                       */
  int drive;            /*..                       */

  /*get output file disk*/
  if( fn[1]==':' )
        drive=toupper(fn[0])-'A';
  else
        drive=getdisk();

  strcpy(fn,buf) ;
  if((handle=open(fn,O_CREAT|O_EXCL|O_WRONLY|O_BINARY,S_IREAD|S_IWRITE))<0)
  {
    send_mpf(" ",1,STOPXFER) ;
    sprintf(buf,"\n%20s %s",fn,FILEEXIST) ;
    show(buf) ;
    return(FALSE) ;
  }

  /*open file good, send ACK*/
  send_mpf(" ", 1, XFER_ACK);

  /*get file length*/
  read_mpf(buf,&len1,&prot,FALSE) ;
  buf[len1]=0 ;
  sscanf(buf,"%ld",&flen) ;

  /*draw the transfer meter*/
  if(dmode==2)
  {
    for(i=1; i<=10; i++)
    {
      bsize[i-1]=flen*i/(10*BLOCK) ;
    }
    if(flen<BLOCK)
    {
      bsize[9]=1 ;
    }
    else
    {
      bsize[9]=((flen%BLOCK)==0) ? bsize[9]-1:bsize[9] ;
    }
    ltostr(flen,buf) ;
    printf("\n\r%20s  %10s  ",fn,buf) ;
    printf("..........%c%c%c%c%c%c%c%c%c%c",bs,bs,bs,bs,bs,bs,bs,bs,bs,bs) ;
    fflush(stdout) ;
  }

  /*check if enough disk space*/
  getdfree(drive+1, &free);
  if( free.df_sclus==0xffff )
  {
        send_mpf(" ", 1, STOPXFER);
        printf("\n");
        printf("Internal error, getdfree() error!\n");
        return(FALSE);
  }
  diskfree=(long)free.df_avail * (long)free.df_bsec * (long)free.df_sclus;
  if( diskfree<flen )
  {
        send_mpf(" ", 1, STOPXFER);
        printf("\n");
        printf("%c %s", drive+'A', NO_DISK_ROOM);
        return(FALSE);
  }

  /*seems good, ready to receive*/
  send_mpf(" ",1,XFER_ACK) ;

  /*receive file until length flen*/
  bt=0;
  fcnt=0;
  t_bar=0;
  while(fcnt<flen)
  {
    get_size=flen-fcnt;
    if( get_size>BLOCK )
        get_size=BLOCK;

    if( (tcpstat=tcp_get(buf, get_size)) >= 0 )
    {
        fcnt += tcpstat;
        write(handle, buf, tcpstat);
        bn=fcnt/BLOCK;
        t_bar++;

        if ( dmode==2 )
        {
          printf("%c%c",map[t_bar%4],bs) ;
          while((bn>bsize[bt]) && (bt<10))
          {
                printf("*") ;
                bt++ ;
          }
          fflush(stdout) ;
        }
    }
    else
    {
        printf("TCP network error(D1)!\n") ;
        end_tcp();
        exit(12);
    }

  }/*end while*/

  close(handle);

  if( dmode==2 )
  {
    while(bt<10)
    {
      printf("*") ;
      bt++ ;
    }
    fflush(stdout) ;
  }

  /*SYNCHRONIZATION*/
  tcpstat=tcp_get(buf, 1);
  if( tcpstat<0 )
  {
        printf("TCP network error(D2)!\n");
        end_tcp();
        exit(12);
  }

  /*check SYNC*/
  if( buf[0]!=END_XFER )
  {
        printf("Synchronization error!\n");
        end_tcp();
        exit(12);
  }

  /*sendback SYNC*/
  if( tcp_put(buf, 1)<0 )
  {
        printf("TCP network error(D3)!\n");
        end_tcp();
        exit(12);
  }

  /*download finished*/

  return(TRUE) ;
}
/*end of download*/



/**************************************
    get the upload file name
*/
int get_filename(buffer)
char *buffer ;
{
  char pathfn[200] ;
  int i=0 ;

  while(i<1)
  {
    i++ ;
    pathfn[0]=0 ;
    show("\n") ;
    show(UFILENAME) ;
    if(getstring(-1,-1,pathfn,50,1)>0)
    {
      strcpy(buffer,pathfn) ;
      show("\n") ;
      return(TRUE) ;
    }
  }
  return(FALSE) ;
}

/**************************************
    upload a file from client to server
*/
int upload(buffer,umode)
char *buffer ;
int umode ;
{
  int handle,tcpstat ;
  int i ;
  char prot ;
  char fn[80], *ptr ;
  char *map="-\\|/" ;
  char bs=8 ;
  long BLOCK=1024 ;
  long bsize[10],bn,bt ;
  long len1, flen ;
  long fcnt;
  int t_bar;
  char first_byte;      /*for test file read*/

  strcpy(fn,buffer) ;
  for(i=0; i<strlen(fn); i++)   /*--- check file name ---*/
  {
    if(fn[i]<33)
    {
      fn[i]=0 ;
      break ;
    }
  }

  if((handle=open(fn,O_BINARY|O_RDONLY))<0)      /* open upload file */
  {
    sprintf(buffer,"%s\n",FNOTFOUND) ;
    show(buffer) ;
    send_mpf(" ",1,STOPXFER) ;
    return(FALSE) ;
  }

  /*read first byte of the file to test it*/
  if( read(handle, &first_byte, 1) <= 0 )
  {
    sprintf(buffer,"%s\n",FILEREAD_ERR) ;
    show(buffer) ;
    send_mpf(" ",1,STOPXFER) ;
    return(FALSE) ;
  }

  /*send filename*/
  send_mpf(fn, strlen(fn), FILEXFER);

  /*check ACK*/
  read_mpf(buffer,&len1,&prot,FALSE) ;
  if(prot==STOPXFER)
  {
    buffer[len1]=0 ;
    show(buffer) ;
    return(FALSE) ;
  }
  else if(prot!=XFER_ACK)
  {
    printf("Protocol State Error, %d!(U1)\n", prot);
    end_tcp();
    exit(13);
  }

  /*send file length*/
  flen=filelength(handle) ;
  sprintf(buffer,"%ld",flen) ;
  send_mpf(buffer,strlen(buffer),FILEXFER) ;

  /*check ACK*/
  read_mpf(buffer,&len1,&prot,FALSE) ;
  if(prot==STOPXFER)
  {
    buffer[len1]=0 ;
    show(buffer) ;
    return(FALSE) ;
  }
  else if(prot!=XFER_ACK)
  {
    printf("Protocol State Error, %d!(U2)\n", prot);
    end_tcp();
    exit(13);
  }

  /*draw the transfer meter*/
  if(umode==2)
  {
    for(i=1; i<=10; i++)
    {
      bsize[i-1]=(double) flen*i/(10*BLOCK) ;
    }
    if(flen<BLOCK)
    {
      bsize[9]=1 ;
    }
    else
    {
      bsize[9]=((flen%BLOCK)==0) ? bsize[9]-1:bsize[9] ;
    }
    ltostr(flen,buffer) ;
    printf("\n\r%20s  %10s  ",fn,buffer) ;
    printf("..........%c%c%c%c%c%c%c%c%c%c",bs,bs,bs,bs,bs,bs,bs,bs,bs,bs) ;
    fflush(stdout) ;
  }

  /*send first byte of the file*/
  if( tcp_put(&first_byte, 1) < 0 )
  {
        printf("TCP network error!(U1)\n") ;
        end_tcp();
        exit(13);
  }

  /*send file until length flen*/
  bn=bt=0 ;
  fcnt=1;       /*include first byte*/
  t_bar=0;
  while(fcnt<flen)
  {
    if( eof(handle) )
    {
        show("File size is not correct(underflow)!!!");
        /*stop transmission to save network*/
        end_tcp();
        exit(13);
        break;
    }

    if( (len1=read(handle, buffer, BLOCK)) < 0 )
    {
        sprintf(buffer,"%s(U2R)\n",FILEREAD_ERR) ;
        show(buffer) ;
        /*stop transmission to save network*/
        end_tcp();
        exit(13);
        break;
    }

    if( len1 > (flen-fcnt) )
    {
        show("File size is not correct(overflow)!!!");
        len1=flen-fcnt;
        /*continue last transmission*/
    }

    if( tcp_put(buffer, len1) < 0 )
    {
        printf("TCP network error!(U2)\n") ;
        end_tcp();
        exit(13);
    }

    fcnt += len1;
    bn=fcnt/BLOCK;
    t_bar++;

    if ( umode==2 )
    {
        printf("%c%c",map[t_bar%4],bs) ;
        while((bn>bsize[bt]) && (bt<10))
        {
          printf("*") ;
          bt++ ;
        }
        fflush(stdout) ;
    }

  }/*end while(fcnt<flen)*/

  if( umode==2 )
  {
    while(bt<10)
    {
      printf("*") ;
      bt++ ;
    }
    fflush(stdout) ;
  }

  /*send SYNC*/
  buffer[0]=END_XFER;
  if( tcp_put(buffer, 1) < 0 )
  {
        printf("TCP network error!(U3)\n") ;
        end_tcp();
        exit(13);
  }

  /*flush it*/
  sock_flushnext(&tcpport);

  /*SYNCHRONIZATION*/
  if( tcp_get(buffer, 1)<0 )
  {
        printf("TCP network error(U4)!\n");
        end_tcp();
        exit(13);
  }

  /*check SYNC*/
  if( buffer[0]!=END_XFER )
  {
        printf("Synchronization error!\n");
        end_tcp();
        exit(13);
  }

  /*upload finished*/

  return(TRUE) ;
}
/*end of upload*/
