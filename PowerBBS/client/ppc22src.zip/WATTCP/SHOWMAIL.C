#include <ctype.h>
#include <conio.h>
#include "pcpbbs.h"
#include "msg.h"
#include "proto.h"

#define COL     78

static int PgUp=FALSE ;
static int last_page_i ;

static char finds[100] ;
static long last_s ;

/**********************************
   check the input key
   for the function pager()
*/
int in_range(key)
char *key ;
{
  int ret, k ;

  switch(*key)
  {
    case 'q':   /* quit */
    case 'r':   /* reply */
    case 'm':   /* email reply */
    case 's':   /* search pattern */
    case 'f':   /* file post */
    case 'p':   /* pre-post */
    case 'n':   /* next post */
    case 'u':   /* up page */
    case 'd':   /* down page */
    case ' ':   /* down page */
    case 'k':   /* kill post */
    case 'e':   /* enter a new post */
    case 'c':   /* cream */
    case '+':   /* relation up */
    case '-':   /* relation next */
    case 13 :   /* next post */
    case '/':   /* in-post search */
        ret=1 ;
        break ;
    default:
      ret=0 ;
  }

  return(ret) ;
}
/* end in_range() */


/*--- To show the text by pages ---*/
/*--- return the last pressed key ---*/
int pager(head,body)
/*
  return: -3: pre-post
          -2: next post
          -1: key response
           0: quit
          >0: post number
*/
char *head ;
char *body ;
{
  long i=0, j, l, head_p=0,     /*head_p mark the first char of each page*/
       n=0,
       cols=0,
       here=0 ;          /*--- current page's head line ---*/
  int key ;
  char cr=13 ;
  char *tab="  " ;

  int page_lines=15;    /* how many lines of a page*/

  int handle ;
  char comm[100] ;
  char num[100] ;

  int ret;


  clrscr() ;
  if( !mono )
    show("{#3#}");
  show(head) ;
  if( !mono )
    show("{#n#}");
  page_lines=LINES-8;

  while(1)
  {
    if( (*(body+i)<32) && (*(body+i)!=9) && (*(body+i)!=10) && (*(body+i)>0) )
    {
      *(body+i)=' ' ;
    }

    if( *(body+i)==10 )
    {
      /*--- get '\n' ---*/
      write(1,&cr,1) ;  /*--- append carried return ---*/
      n++ ;
      cols=0 ;
      if(n % (page_lines-1)==0)        /*--- count the lines if full the screen ---*/
      {
        write(1,(body+i),1) ;

        j=i+1 ;
        while(*(body+j)!=0 && *(body+j)!=10 )
        {
          if( *(body+j)==9 )
          {
            if(cols%8==0)
            {
              write(1,tab,1) ;
              cols++ ;
            }
            while(cols%8)
            {
              write(1,tab,1) ;
              cols++ ;
              if(cols>COL)
              {
                while((*(body+j)!=10) && (*(body+j)!=0))
                  j++ ;
                cols=0 ;
                break ;
              }
            }
            if(cols!=0)
              j++ ;

            continue ;
          }     /* end check tab */

          if(cols<=COL)
            write(1,(body+j),1) ;

          cols++ ;
          j++ ;
        }

        if( *(body+j)==10 )
        {
          write(1,(body+j),1) ;
          cols=0 ;
        }

        write(1,&cr,1) ;


        do
        {
          n=0;
          ret=get_read_answer(&key);
          if( ret>0 )
                return(ret);            /*user input number*/

          if(key==23 && term_mode==0)           /* save capture file */
          {
            printf("%s",CAPTUREFILE) ;
            getstring(-1,-1,capfn,80-strlen(CAPTUREFILE),1) ;
            if((handle=open(capfn,O_CREAT|O_APPEND|O_WRONLY,S_IREAD|S_IWRITE))<0)
            {
              printf("\r\nOpen capture file error!\r\n") ;
              readkey() ;
            }
            else
            {
              clear_cr(head) ;
              clear_cr(body) ;
              write(handle,head,strlen(head)) ;
              write(handle,body,strlen(body)) ;
              write(handle,"\n\n",2) ;
              close(handle) ;
            }

            erase_line() ;
            continue ;
          }

          break;
        }
        while(TRUE);


        /********/
        /* quit */
        /********/
        if(key=='q' || key==75)    /*--- Quit ---*/
        {              /* <- */
          return(0) ;
        }


        /*************/
        /* next post */
        /*************/
        if((key==13) || (key=='n') || (key==77))
        {                             /* -> */
          return(-2) ;
        }


        /*****************/
        /* previous post */
        /*****************/
        if(key=='p')
        {
          return(-3) ;
        }


        /******************/
        /* in-post search */
        /******************/
        if(key=='/')
        {
          erase_line() ;
          show("/") ;
          comm[0]=0 ;
          getstring(-1,-1,comm,60,1) ;

          if( (l=search_word(body,comm))<0 )
          {
            show(SCANOFIND) ;
            readkey() ;
            i=head_p-1;
          }
          else
          {
            i=l-1 ;
          }

          i++ ;
          n=0;
          head_p=i;
          clrscr() ;
          if( !mono )
            show("{#3#}");
          show(head) ;
          if( !mono )
            show("{#n#}");
          continue ;

        }


        /***************/
        /*previous page*/
        /***************/
        if(key=='u' || key==72)
        {               /* ^ */
          clrscr() ;
          if( !mono )
            show("{#3#}");
          show(head) ;
          if( !mono )
            show("{#n#}");

          here=0 ;
          for(j=head_p; j>0; j--)
          {
            if( *(body+j)==10 )
              here++ ;

            if( here >= page_lines )
            {
              break ;
            }
          }
          i=(j>0) ? j: -1 ;
          i++ ;
          last_s=i ;          /* adjust last_search */
          head_p=i;
          continue ;
        }


        /*************/
        /* next page */
        /*************/
        if((key==' ') || (key=='d') || (key==80))
        {                              /* v */
          clrscr() ;
          if( !mono )
            show("{#3#}");
          show(head) ;
          if( !mono )
            show("{#n#}");

          i++ ;
          head_p=i;
          continue ;
        }

        /**********************/
        /* Other response key */
        /**********************/
        body[0]=key ;
        return(-1) ;

      }
      else
      {
        write(1,(body+i),1) ;
        i++ ;
        continue ;
      }
    }

    if(*(body+i)==9)    /* TAB */
    {
      if(cols%8==0)
      {
        write(1,tab,1) ;
        cols++ ;
      }
      while(cols%8)
      {
        write(1,tab,1) ;
        cols++ ;
        if(cols>COL)
        {
          while((*(body+i)!=10) && (*(body+i)!=0))
            i++ ;
          cols=0 ;
          break ;
        }
      }
      if(cols!=0)
        i++ ;

      continue ;
    }


    if(*(body+i)==0)
    {
        /**************************/
        /*** last page run here ***/
        /**************************/

        do
        {
          n=0;
          ret=get_read_answer(&key);
          if( ret>0 )
                return(ret);            /*user input number*/

          if(key==23 && term_mode==0)
          {
            printf("%s",CAPTUREFILE) ;
            getstring(-1,-1,capfn,80-strlen(CAPTUREFILE),1) ;
            if((handle=open(capfn,O_CREAT|O_APPEND|O_WRONLY,S_IREAD|S_IWRITE))<0)
            {
              printf("\r\nOpen capture file error!\r\n") ;
              readkey() ;
            }
            else
            {
              clear_cr(head) ;
              clear_cr(body) ;
              write(handle,head,strlen(head)) ;
              write(handle,body,strlen(body)) ;
              write(handle,"\n\n",2) ;
              close(handle) ;
            }

            erase_line() ;
            continue ;
          }/*end if*/

          break;
        }while(TRUE);


        /********/
        /* quit */
        /********/
        if(key=='q' || key==75)
        {              /* <- */
          return(0) ;
        }


        /*************/
        /* next post */
        /*************/
        if((key==13) || (key=='n') || (key==77))
        {                             /* -> */
          return(-2) ;
        }


        /************************************/
        /* next page (no more so next post) */
        /************************************/
        if((key==' ') || (key=='d') || (key==80))
        {                              /* v */
          return(-2) ;
        }


        /*****************/
        /* previous post */
        /*****************/
        if(key=='p')
        {
          return(-3) ;
        }


        /******************/
        /* in-post search */
        /******************/
        if( key=='/')
        {
          erase_line() ;
          show("/") ;
          comm[0]=0 ;
          getstring(-1,-1,comm,60,1) ;

          if( (l=search_word(body,comm))<0 )
          {
            show(SCANOFIND) ;
            readkey() ;
            i=head_p-1;
          }
          else
          {
            i=l-1 ;
          }

          i++ ;
          n=0;
          head_p=i;
          clrscr() ;
          if( !mono )
            show("{#3#}");
          show(head) ;
          if( !mono )
            show("{#n#}");
          continue;
        }


        /*****************/
        /* previous page */
        /*****************/
        if(key=='u' || key==72)
        {               /* ^ */
          clrscr() ;
          if( !mono )
            show("{#3#}");
          show(head) ;
          if( !mono )
            show("{#n#}");

          here=0 ;
          for(j=head_p; j>0; j--)
          {
            if( *(body+j)==10 )
              here++ ;

            if( here>= page_lines )
            {
              break ;
            }
          }
          i=(j>0) ? j: -1 ;
          i++ ;
          last_s=i ;          /* adjust last_search */
          head_p=i;
          continue;
        }


        /*********************/
        /* user response key */
        /*********************/
        body[0]=key ;
        return(-1) ;

    }
    else
    {
      write(1,(body+i),1) ;
      cols++ ;
    }
    i++ ;
    if(cols>COL)
    {
      while((*(body+i)!=10) && (*(body+i)!=0))
        i++ ;
    }
  }
}
/* end pager() */



/*
        get_read_answer --- get user input in read prompt
        for pager() function
*/
get_read_answer(ukey)
        int *ukey;
/*
        return: 0:      user_key
                >0      number
*/
{
        char num[80];
        int ret;
        int x, y, a, b;

        /***************/
        /* show prompt */
        /***************/
        if( !mono )
            show("{#2#}");

        if( term_mode==0 )
        {
          gotoxy(51, 23);
          show(CAP_PROMPT);
        }
        gotoxy(66, 23);
        show(SEARCH_PMT);
        gotoxy(1, 24);
        show(POST_MORE1);
        gotoxy(1, 25);
        show(POST_MORE2);
        if( !mono )
            show("{#n#}");

        ret=0;

        if( mouse_mode )
                show_mouse_cursor();

        do
        {
          if( mouse_mode )
          {
                mouse_xy_press(&x, &y, &a, &b);

                if( b==1 )  /*mouse right button pressed (quit)*/
                {
                  /*hold until mouse button depressed*/
                  while( b!=0 )
                    mouse_xy_press(&x, &y, &a, &b);

                  *ukey='q';
                  break;
                }

                if( a==1 )  /*mouse left button pressed*/
                {
                  /*hold until mouse button depressed*/
                  while( a!=0 )
                    mouse_xy_press(&x, &y, &a, &b);

                  /*next page*/
                  if( x>=0 && x<=12 && y==24 )
                  {
                        *ukey='d';
                        break;
                  }

                  /*next post*/
                  if( x>=15 && x<=26 && y==24 )
                  {
                        *ukey='n';
                        break;
                  }

                  /*previous page*/
                  if( x>=29 && x<=37 && y==24 )
                  {
                        *ukey='u';
                        break;
                  }

                  /*previous post*/
                  if( x>=40 && x<=48 && y==24 )
                  {
                        *ukey='p';
                        break;
                  }

                  /*delete post*/
                  if( x>=51 && x<=57 && y==24 )
                  {
                        *ukey='k';
                        break;
                  }

                  /*---------------------------------------------------*/

                  /* reply */
                  if( x==1 && y==23 )
                  {
                        *ukey='r';
                        break;
                  }

                  /* mail-reply */
                  if( x==3 && y==23 )
                  {
                        *ukey='r';
                        break;
                  }

                  /* enter new post */
                  if( x>=11 && x<=17 && y==23 )
                  {
                        *ukey='e';
                        break;
                  }

                  /* file post */
                  if( x>=20 && x<=30 && y==23 )
                  {
                        *ukey='f';
                        break;
                  }

                  /* '-' */
                  if( x==34 && y==23 )
                  {
                        *ukey='-';
                        break;
                  }

                  /* '+' */
                  if( x==36 && y==23 )
                  {
                        *ukey='+';
                        break;
                  }

                  /* search pattern */
                  if( x>=48 && x<=58 && y==23 )
                  {
                        *ukey='s';
                        break;
                  }

                  /* cream */
                  if( x>=61 && x<=67 && y==23 )
                  {
                        *ukey='c';
                        break;
                  }

                  /* quit */
                  if( x>=70 && x<=76 && y==23 )
                  {
                        *ukey='q';
                        break;
                  }

                  /*---------------------------------------------------*/

                  /*left mouse button as 'next page' function*/
                  if( y<22 )
                  {
                        *ukey='d';
                        break;
                  }

                }/*end mouse button pressed*/

          }/*end if(mouse)*/

          if( kbhit() )
          {
            if( mouse_mode )
                hide_mouse_cursor();

            *ukey=bioskey(0) ;

            if((*ukey & 0xff)==0)
            {
              *ukey=*ukey>>8 ;

              if(*ukey==72 || *ukey==75 || *ukey==77 || *ukey==80)
                break ;
              else
                continue ;
            }

            *ukey=tolower(*ukey & 0xff) ;

             /* save capture file */
            if(*ukey==23 && term_mode==0)
                break;

            if(isdigit(*ukey))
            {
              num[0]=*ukey ;
              num[1]=0 ;

              if(getstring(-1,-1,num,5,3)<=0)
                continue;
              else
              {
                ret=atoi(num);
                break;
              }
            }

            if( in_range((char*)ukey) )
                break;
            else
            {
                show_mouse_cursor();
            }

          }/*end if(kbhit)*/

        }
        while(TRUE);

        /****************/
        /* erase prompt */
        /****************/
        if( mouse_mode )
        {
            hide_mouse_cursor();
        }
        gotoxy(1, 23);
        erase_line();
        gotoxy(1, 24);
        erase_line();
        gotoxy(1, 25);
        erase_line();

        gotoxy(1, 24);

        return(ret);
}
/*end of get_read_answer*/



/*
    List each post num, from, subject
    input format: "<msg_no>\crlf<description>\crlf<item_name>\crlf{next_one}"
*/
int postlist(buf, imode)
char *buf;
int imode;      /* mode 1: INTRREAD, mode 2: INTRSEL*/
{
  char *pbuf ;
  int pl[80] ;
  int n, i, j ;
  int cols ;
  char num[8] ;
  int ch, key,empty=0 ;
  char select_msg[100];
  char null_pad[80];
  int ukey;
  int ret_no;
  int new_i;
  int x, y, a, b;
  int intrsel_point=0;
  unsigned char isel_point=0;   /*default layer*/

  pbuf=buf;

  /******************************************************************/
  /* parsing INTRSEL layer number                                   */
  /*----------------------------------------------------------------*/
  /* layer number encapsulated with other intrsel text like         */
  /* <layer no.>![intrsel text] for example,                        */
  /* 1![intrsel text]                                               */
  /* <layer no.> is an unsigned char withc begins from 1 (ASC 49)   */
  /* only ONE char is used, that is when layer > 10, for example 10 */
  /* the char for <layer no.> is ':' (ASC 58)                       */
  /* by the way, the ASC of the seperator '!' is 33                 */
  /******************************************************************/
  if( imode==2 && strlen(buf)>3 )
  {
    if( pbuf[1]=='!' )
    {
        isel_point=pbuf[0]-'1';
        pbuf=pbuf+2;
    }

    if( isel_point_stk[isel_point]>0 )
    {
        intrsel_point=isel_point_stk[isel_point];
        n=isel_point;
        while( isel_point_stk[n]!=0 && n<255 )
                isel_point_stk[n++]=0;
    }
  }

  if(pbuf[0]==0)
    empty=TRUE ;

  n=parse_msg(pl,pbuf)-1 ;

  clrscr() ;

  /*********************/
  /*assemble title line*/
  /*********************/
  i=strlen(SELECTMSG);
  j=(79-i)/2;
  memset(null_pad, ' ', j);
  null_pad[j]=0;
  if( !mono )
    strcpy(select_msg, "{#15,5#}");
  else
    select_msg[0]=0;
  strcat(select_msg, null_pad);
  strcat(select_msg, SELECTMSG);
  strcat(select_msg, null_pad);
  if( !mono )
    strcat(select_msg, "{#n#}");
  strcat(select_msg, "\r\n");

  show(select_msg);

  /******************/
  /*put select items*/
  /******************/
  for(i=0; i<=n; i++)
  {
    printf("   %-.75s\r\n",(pbuf+i*100)) ;
  }

  if( !mono )
        show("{#2#}");
  if( imode==1 )        /*INTRREAD*/
  {
    gotoxy(1, 24);
    show(IR_PROMPT1);
    gotoxy(1, 25);
    show(IR_PROMPT2) ;
    cols=strlen(IR_PROMPT2)+1 ;
  }
  else                  /*INTRSEL*/
  {
    gotoxy(1, 24);
    show(SEL_PROMPT1);
    gotoxy(1, 25);
    show(SEL_PROMPT2) ;
    cols=strlen(SEL_PROMPT2)+1 ;
  }
  if( !mono )
        show("{#n#}");

  i=0;
  if(n<0)
        empty=TRUE ;
  else
  {
        if( PgUp )      /*find next i followed the previous page*/
        {
          i=n;

          while(i>=0)
          {
            if( pl[i]<=last_page_i )
                break;
            i--;
          }

          if(i<0)
                i=n;

          PgUp=FALSE;   /*reset PgUp*/

        }/*end if(PgUp)*/
        else
        {
          /*intrread/intrsel_point checking*/

          if( imode==1 && intrread_point>0 )
          {
            /*note:
              intrread_point will be setup additionally in function parse_head()
            */
            i=n;
            while(i>0)
            {
                if( pl[i]==intrread_point )
                        break;
                i--;
            }

            intrread_point=0;   /*reset var*/
          }
          else if( imode==2 && intrsel_point>0 )
          {
            i=n;
            while(i>0)
            {
                if( pl[i]==intrsel_point )
                        break;
                i--;
            }

            intrsel_point=0;    /*reset var*/
          }

        }/*end if*/

  }/*end if*/

  if( mouse_mode )
        show_mouse_cursor();

  do
  {
    /*******************/
    /* draw arrow mark */
    /*******************/
    if(!empty)
    {
      gotoxy(1,i+2) ;
      inverse_text();
      cprintf("   %-.75s\r",(pbuf+i*100)) ;
      fflush(stdout) ;
      normal_text();

      gotoxy(cols,LINES) ;
    }


    do
    {

      if( mouse_mode )
      {
        mouse_xy_press(&x, &y, &a, &b);

        if( b==1 )  /*mouse right button pressed (quit)*/
        {
          /*hold until mouse button depressed*/
          while( b!=0 )
            mouse_xy_press(&x, &y, &a, &b);

          ukey='q';
          break;
        }

        if( a==1 )  /*mouse left button pressed*/
        {
          /*hold until mouse button depressed*/
          while( a!=0 )
                mouse_xy_press(&x, &y, &a, &b);

          /* choose between items */
          if( y>=1 && y<=(n+1) && x>=8 && x<=60 )
          {
                if( (y-1)==i )          /*choose arrowed item */
                {
                        ukey=13;
                        break;
                }
                else
                {
                        ukey=0;
                        ret_no=0;
                        new_i=y-1;
                        break;
                }
          }

          /*------------------------------------------------------------*/

          /* next page */
          if( x>=0 && x<=14 && y==24 )
          {
                ukey='d';
                break;
          }

          /* previous page */
          if( x>=17 && x<=25 && y==24 )
          {
                ukey='u';
                break;
          }

          /* next item */
          if( x>=28 && x<=36 && y==24 )
          {
                ukey='n';
                break;
          }

          /* previous item */
          if( x>=39 && x<=47 && y==24 )
          {
                ukey='p';
                break;
          }

          /*------------------------------------------------------------*/

          /* <- (left arrow) */
          if( x>=0 && x<=3 && y==23 )
          {
                ukey='q';
                break;
          }

          /* -> (right arrow) */
          if( x>=6 && x<=9 && y==23 )
          {
                ukey=13;
                break;
          }

          /* ^ (up arrow) */
          if( x>=12 && x<=15 && y==23 )
          {
                ukey='p';
                break;
          }

          /* v (down arrow) */
          if( x>=18 && x<=21 && y==23 )
          {
                ukey='n';
                break;
          }

          /*------------------------------------------------------------*/

          if( imode==1 )        /*INTRREAD*/
          {
                /* enter post */
                if( x>=24 && x<=30 && y==23 )
                {
                        ukey='e';
                        break;
                }

                /* file post */
                if( x>=33 && x<=43 && y==23 )
                {
                        ukey='f';
                        break;
                }

                /* quit */
                if( x>=46 && x<=52 && y==23 )
                {
                        ukey='q';
                        break;
                }

          }
          else                  /*INTRSEL*/
          {
                /* select */
                if( x>=24 && x<=34 && y==23 )
                {
                        ukey='s';
                        break;
                }

                /* quit */
                if( x>=37 && x<=43 && y==23 )
                {
                        ukey='q';
                        break;
                }
          }

        }/*end if(mouse_press)*/
      }/*end if(mouse_mode)*/


      if( kbhit() )
      {
        if( mouse_mode )
          hide_mouse_cursor();

        ukey=bioskey(0) ;

        if( (ukey & 0xff)==0 )
        {
          ukey=ukey>>8 ;

          switch(ukey)
          {
          case 72:      /* ^ */
                ukey='p';
                break;

          case 75:      /* <- */
                ukey='q';
                break;

          case 77:      /* -> */
                ukey=13;
                break;

          case 80:      /* v */
                ukey='n';
                break;

          default:
                continue;

          }/*end switch*/

          break;        /* get user key */

        }/*end if*/

        ukey=tolower(ukey & 0xff) ;

        if(isdigit(ukey))
        {
          num[0]=ukey ;
          num[1]=0 ;

          if(getstring(-1,-1,num,5,3)<=0)
                continue;
          else
          {
                ukey=0;
                ret_no=atoi(num);
                break;
          }
        }

        if( imode==1 )          /*INTRREAD*/
        {
          if( intrread_valid_key(ukey) )
                break;
          else
                show_mouse_cursor();
        }
        else                    /*INTRSEL*/
        {
          if( intrsel_valid_key(ukey) )
                break;
          else
                show_mouse_cursor();
        }

      }/*end if(kbhit)*/

    } while(TRUE);

    /********************/
    /* erase arrow mark */
    /********************/
    if(!empty)
    {
      gotoxy(1,i+2) ;
      normal_text();
      cprintf("   %-.75s\r",(pbuf+i*100)) ;
      fflush(stdout) ;

      gotoxy(cols,LINES) ;
    }

    /*********************/
    /* user press number */
    /*********************/
    if( ukey==0 && ret_no>0 )
    {
        /*keep point*/
        if( imode==1 )          /*intrread*/
                intrread_point=ret_no;
        else if( imode==2 )     /*intrsel*/
                isel_point_stk[isel_point]=ret_no;

        break;
    }

    /*********************/
    /* mouse choose item */
    /*********************/
    if( ukey==0 && ret_no==0 )
    {
        i=new_i;
        continue;
    }

    /********/
    /* quit */
    /********/
    if(ukey=='q')
      break;

    /*********/
    /* enter */
    /*********/
    if(ukey==13)
    {
      ret_no=pl[i];
      ukey=0;

      /*keep point*/
      if( imode==1 )            /*intrread*/
        intrread_point=ret_no;
      else if( imode==2 )       /*intrsel*/
        isel_point_stk[isel_point]=ret_no;

      break;
    }

    /*************/
    /* page down */
    /*************/
    if(ukey==' ' || ukey=='d')
    {
      ukey='d';
      break;
    }

    /***********/
    /* page up */
    /***********/
    if(ukey=='u')
    {
      PgUp=TRUE ;
      last_page_i=pl[0];
      break;
    }

    /*****************/
    /* previous item */
    /*****************/
    if(ukey=='p')
    {
      i-- ;
      if(i<0)
      {
        ukey='u';
        PgUp=TRUE ;
        last_page_i=pl[0];
        break;
      }
      else
      {
        if( mouse_mode )
                show_mouse_cursor();

        continue;
      }
    }

    /*************/
    /* next item */
    /*************/
    if(ukey=='n')
    {
      i++ ;
      if(i>n)
      {
        ukey='d';
        break;
      }
      else
      {
        if( mouse_mode )
                show_mouse_cursor();

        continue;
      }
    }

    /***************************************/
    /* enter post or file post in INTRREAD */
    /***************************************/
    if( imode==1 && (ukey=='e' || ukey=='f') )
    {
        break;
    }

    /*********************/
    /* select in INTRSEL */
    /*********************/
    if( imode!=1 && (ukey=='s') )
    {
        break;
    }

  }
  while(TRUE) ;

  /****************/
  /* erase prompt */
  /****************/
  if( mouse_mode )
  {
        hide_mouse_cursor();
  }
  gotoxy(1, 24);
  erase_line();
  gotoxy(1, 25);
  erase_line();

  gotoxy(1, 24);

  if( ukey==0 )
        return(ret_no);
  else
  {
        buf[0]=ukey;
        return(0);
  }
}
/*end of postlist*/



/*
        intrread_valid_key --- check if key valid in intrread
*/
intrread_valid_key(key)
        int key;
/*
        RETURN: TRUE: OK
                FALSE: not allowed key
*/
{
        int ret;

        switch(key)
        {
                case 13 :       /*enter*/
                case ' ':       /*next page*/
                case 'd':       /*next page*/
                case 'e':       /*enter mail*/
                case 'f':       /*file post*/
                case 'n':       /*next item*/
                case 'p':       /*previous item*/
                case 'q':       /*quit*/
                case 'u':       /*previous page*/
                        ret=TRUE;
                        break;

                default:
                        ret=FALSE;
                        break;
        }

        return(ret);
}
/*end of intrread_valid_key*/



/*
        intrsel_valid_key --- check if key valid in intrsel
*/
intrsel_valid_key(key)
        int key;
/*
        RETURN: TRUE: OK
                FALSE: not allowed key
*/
{
        int ret;

        switch(key)
        {
                case 13 :       /*enter*/
                case ' ':       /*next page*/
                case 'd':       /*next page*/
                case 'n':       /*next item*/
                case 'p':       /*previous item*/
                case 'q':       /*quit*/
                case 's':       /*select*/
                case 'u':       /*previous page*/
                        ret=TRUE;
                        break;

                default:
                        ret=FALSE;
                        break;
        }

        return(ret);
}
/*end of intrsel_valid_key*/
