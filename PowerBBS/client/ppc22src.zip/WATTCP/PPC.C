/***************************************************************
    ppc.c       (for PC + Dos)

    To connect the BBS server.
    write by Aquarius Kuo(cs79026@chpi.edu.tw)
    1993.11.24.
    program was developed under Turbo C V1.0

    version 2.0 was remodified by Samson Chen Nov 12, 1994
    program was developed under Borland C++ V3.1
    Nov 21, 1994 modified
    Dec 3, 1994
    Version 2.01 Dec 9, 1994
    Version 2.1 Apr 1, 1995
    Version 2.2 Apr 22, 1995

    Trademarks:

        Borland C++ is a registered trademark of Borland International.

        Waterloo TCP Library is a registered trademark of
        Waterloo TCP Architect, Erick Engelke.

        MS-DOS is a registered trademark of Microsoft.

        Turbo C is a registered trademark of Borland International.

*****************************************************************/
#include <ctype.h>
#include <conio.h>
#include "pcpbbs.h"
#include "proto.h"
#include "msg.h"

#define LEFT    '{'
#define RIGHT   '}'
#define SEP     '|'
#define VERSION  (char) 0x22            /*protocol version 2.1*/
#define PLATFORM (char) 2               /*MS-DOS platform number*/

#define DISCARD_PORT            9       /*discarding service*/

unsigned extern _stklen=30000 ;

static char rcsid[]="$Id: ppc.c,v 1.13 1994/05/17 13:38:09 cs79026 Exp cs79026 $" ;
extern int tcpdrv ;

/*      global vars declared here */
unsigned int DEFAULT_TIMEOUT;

/*--- Prompt the screen ---*/
char    SELECTMSG[80];

int PBBS_DEFAULT_PORT;
char PBBS_DEFAULT_SERVER[80];
int term_mode=0, slipper_mode=0, time_polling=0 ;
int mouse_mode=0;
int slip_fd;
int mono;
char capfn[80] ;
char editor[80];
char telnet_path[80];
char show_readmpf_status=FALSE;
int intrread_point=0;
char success_then_remove=FALSE;
char s_t_r_filename[80];

/*for multi-layer INTRSEL point stack*/
int isel_point_stk[256];  /*ASC 49 (1) --- ASC 255 : 207 layers max*/


/*network ports structures*/
tcp_Socket      tcpport;
udp_Socket      udpport;


char downpath[80];
char temppath[80];


/*WATTCP user initial*/
static void (*other_init)();
static void my_init(char *name, char *value)
{
  if( !strcmp(name, "PBBS_EDIT") )
  {
        strcpy(editor, value);
  }
  else if( !strcmp(name, "PBBS_DOWNPATH") )
  {
        strcpy(downpath, value);
  }
  else if( !strcmp(name, "PBBS_TEMPPATH") )
  {
        strcpy(temppath, value);
  }
  else if( !strcmp(name, "PBBS_SLIPPER") )
  {
        if( !stricmp(value, "YES") )
                slipper_mode=1;
  }
  else if( !strcmp(name, "PBBS_TERMMODE") )
  {
        if( !stricmp(value, "YES") )
                term_mode=1;
  }
  else if( !strcmp(name, "PBBS_MONO") )
  {
        if( !stricmp(value, "YES") )
                mono=1;
        else
                mono=0;
  }
  else if( !strcmp(name, "PBBS_MOUSE") )
  {
        if( !stricmp(value, "NO") )
                mouse_mode=0;
  }
  else if( !strcmp(name, "PBBS_TIMEOUT") )
  {
        DEFAULT_TIMEOUT=atoi(value);
  }
  else if( !strcmp(name, "PBBS_SERVER") )
  {
        strcpy(PBBS_DEFAULT_SERVER, value);
  }
  else if( !strcmp(name, "PBBS_PORT") )
  {
        PBBS_DEFAULT_PORT=atoi(value);
  }
  else if( !strcmp(name, "PBBS_TELNET") )
  {
        strcpy(telnet_path, value);
  }
  else if( other_init )
        (*other_init)(name, value);
}
/*end of my_init*/

/*************************************************************************/
/*************************************************************************/
/*************************************************************************/



/*========================Main program ============================*/
void main(argc,argv)
int argc;
char *argv[];
{
  int gdriver, gmode, gerrcode;
  unsigned int original_timeout;
  long len, read_len ;
  char prot ;
  char ipaddr[50] ;
  int  bbsport ;
  char *buffer, pwbuffer[20] ;
  char *intrread_buf, *intrsel_buf;
  char menu_buf[2048];
  char menu_protocol[80];
  char key ;
  int quit, out_getkey, i, tcpstat ;
  struct time now, wait_time ;
  int mils, cnt, ret ;
  char LOCAL_DIR[80] ;
  char header[500] ;
  char file_prepart[9];
  char file_postpart[4];
  char *token;
  struct text_info ti;
  int fore_color, back_color;


  printf("\nPowerBBS PC-Client by Aquarius Kuo, Team Square-1991.\n");
  printf("           V2.2 Apr 22, 1995 by Samson Chen\n\n");

  /*initial global vars*/
  editor[0]=0;
  downpath[0]=0;
  temppath[0]=0;
  PBBS_DEFAULT_PORT=6203;
  strcpy(PBBS_DEFAULT_SERVER, "140.126.3.111");
  strcpy(telnet_path, "telnet %1");


  /*test mouse*/
  mouse_mode=mouse_init();
  if( mouse_mode )
  {
        set_mouse_cursor(0,0);
        hide_mouse_cursor();
  }

  /*test display hardware*/
  detectgraph(&gdriver, &gmode);
  gerrcode=graphresult();
  if( gerrcode==0 )     /*detectgraph ok*/
  {
        switch(gdriver)
        {
        case 2: /*MCGA*/
        case 5: /*EGAMONO*/
        case 7: /*HERCMONO*/
                mono=1;
                break;

        default:
                mono=0;
                break;
        }
  }
  else                  /*detectgraph failed --- default mono display*/
        mono=1;


  /*read setup in WATTCP.CFG*/
  /*config file and TCP API initial*/
  other_init=usr_init;
  usr_init=my_init;
  sock_init();


  if(argc>1)
  {
      if( argv[1][0]=='/' || argv[1][0]=='?' )
      {
        printf("Syntax:\n\r") ;
        printf("   %s [ip_addr | domain_name] [port]\r\n\n", argv[0]) ;
        exit(1) ;
      }
  }

  if(argc>1)
  {
    strcpy(ipaddr,argv[1]) ;
  }
  else
    strcpy(ipaddr, PBBS_DEFAULT_SERVER);

  if(argc>2)
  {
    bbsport=atoi(argv[2]) ;
    if(bbsport<=0)
      bbsport=PBBS_DEFAULT_PORT ;
  }
  else
    bbsport=PBBS_DEFAULT_PORT ;

  /*allocate memory, must use Model Large to compile this*/
  buffer=(char *) farmalloc(MAX_BUF) ;
  intrread_buf=(char *) farmalloc(BACK_BUF) ;
  intrsel_buf=(char *) farmalloc(BACK_BUF) ;
  printf("Memory left %ld\r\n",farcoreleft()) ;

  if( mono )
        printf("MONO display\n");
  else
        printf("COLOR display\n");

  if( slipper_mode )
        printf("SLIP mode on\n");

  if( DEFAULT_TIMEOUT<=5 )
        DEFAULT_TIMEOUT=30;

  if( !connectTCP(ipaddr,bbsport) )
  {
      printf("Can't connect to Power BBS server!\n");
      exit(1) ;
  }

  /*********************/
  /*handshaking session*/
  /*********************/

  strcpy(buffer,"Samson") ;
  if(send_mpf(buffer,strlen(buffer),SESSION)<0)
  {
      printf("(send) PBBS Session 1 error!\n");
      end_tcp() ;
      exit(2);
  }

  ret=read_mpf(buffer, &len,&prot,FALSE) ;

  if( ret<0 )
  {
      printf("(send) PBBS Session 2 error!\n");
      end_tcp() ;
      exit(3);
  }

  buffer[len]=0 ;
  if(strcmp("Aquarius",buffer))
  {
    printf("PowerBBS handshaking error!\n") ;
    end_tcp();
    exit(5);
  }
  buffer[0]=VERSION ;         /* VER_HIGH<<4+VER_LOW ;*/
  buffer[1]=(PLATFORM<<4)+0 ;   /* 1*16+0 ;*/
  strcpy(&buffer[2],"POWERBBS") ;
  send_mpf(buffer,10,SESSION) ;

  /********************************************************/
  /*                OPEN UDP DISCARD_PORT                 */
  /********************************************************/
  if( slipper_mode==1 )
  {
    if( !connectUDP(ipaddr, DISCARD_PORT) )
      printf("Can't open UDP DISCARD PORT %d\n\n", DISCARD_PORT);
    else
    {
      /*trigger SLIP server automatically*/
      initial_interrupt() ;
      /*set exit handler to restore old timer ISR*/
      atexit(recover_interrupt);

      initial_slip_poll();
      time_polling=1 ;
    }
  }
  /********************************************************/

  /* initial isel_point_stk */
  for(cnt=0; cnt<256; cnt++)
        isel_point_stk[cnt]=0;

  /*--- init variable ---*/
  quit=FALSE ;

  if( strlen(downpath)<=0 )
    LOCAL_DIR[0]=0 ;
  else
    strcpy(LOCAL_DIR, downpath) ;

  strcpy(capfn, "CAP.TXT") ;

  /***********************************/
  /*INTRSELECT/INTRREAD TITLE MESSAGE*/
  /***********************************/
  strcpy(SELECTMSG,   "PowerBBS PC Client Menu Selection") ;

  /********************/
  /*get original color*/
  /********************/
  gettextinfo(&ti) ;
  fore_color=ti.normattr & 15 ;
  back_color=(ti.normattr >> 4 ) & 7 ;

  /*set WHITE-BLACK */
  textbackground(BLACK);
  textcolor(LIGHTGRAY);
  lowvideo();

  /*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/

  do
  {
    original_timeout=DEFAULT_TIMEOUT;
    DEFAULT_TIMEOUT=0;  /*block MPFread in transaction get*/

    tcpstat=read_mpf(buffer,&len,&prot,FALSE);

    DEFAULT_TIMEOUT=original_timeout;

    if( success_then_remove )
    {
        success_then_remove=FALSE;
        unlink(s_t_r_filename);
    }

    if(tcpstat==1)
    {
      if(len>MAX_BUF)
        len=MAX_BUF-1 ;

      buffer[len]=0 ;
      switch(prot)
      {
        case ASK:
          show(buffer) ;
          i=strlen(buffer) ;
          buffer[0]=0 ;
          i=getstring(-1,-1,buffer,79-i,1) ;
          show("\n") ;
          send_mpf(buffer,i,ASK) ;
          break ;
        /*-------------------------------------------------------*/
        case BYEBYE:
          quit=TRUE ;
          break ;
        /*-------------------------------------------------------*/
        case DISPLAY:
          clear_esc(buffer) ;
          show(buffer) ;
          break ;
        /*-------------------------------------------------------*/
        case ERROR:
          show(buffer) ;
          /*quit=TRUE ;*/
          break ;
        /*-------------------------------------------------------*/
        case FILEPOST:
          if( term_mode )       /* not support under terminal mode */
          {
            show(FDISABLE) ;
            send_mpf(buffer,1,STOPPOST) ;
            readkey() ;
            break ;
          }
          show(ASKFILENAME) ;
          buffer[0]=header[0]=0 ;
          if(getstring(-1,-1,header,30,1)<1)
          {
            send_mpf(buffer,1,STOPPOST) ;
          }
          else
          {
            if( get_file(header,buffer) )
            {
              show(EDITCONFIRM) ;
              do
              {
                key=tolower(readkey()) ;
                if(key=='e')
                {
                  if(writer(buffer)==FALSE)
                  {
                    send_mpf(buffer,1,STOPPOST) ;
                    break ;
                  }
                  else
                  {
                    show(EDITCONFIRM) ;
                  }
                }
              }
              while( (key!='p') && (key!='a') ) ;
              printf("%c",key) ;
              fflush(stdout) ;
              if(key=='p')
              {
                send_mpf(buffer,strlen(buffer),MAKEPOST);
                break ;
              }
              else
              {
                if(key=='a')
                {
                  send_mpf(buffer,1,STOPPOST) ;
                  break ;
                }
              }
            }
            else
            {
              show("\n\n") ;
              show(FNOTFOUND) ;
              readkey() ;
              send_mpf(buffer,1,STOPPOST) ;
            }
          }
          break ;
        /*-------------------------------------------------------*/
        case FILEXFER:  /*DOWNLOAD*/
          if(term_mode==1)
          {
                send_mpf(" ",1,STOPXFER) ;
                show("\n") ;
                show(FDISABLE) ;
                show(PRESSANYKEY) ;
                user_confirm();
                show("\n") ;
          }
          else
          {

            /*analyze filename, maybe it just fit UNIX style*/
            memset(file_prepart, 0, 9);
            memset(file_postpart, 0, 4);
            token=strtok(buffer, ".");
            if( token )
            {
                  strncpy(file_prepart, token, 8);
                  token=strtok(NULL, ".");
            }
            else
                  strncpy(file_prepart, buffer, 8);

            if( token )
                  strncpy(file_postpart, token, 3);

            strcpy(buffer, file_prepart);

            if( strlen(file_postpart)>0 )
            {
                  strcat(buffer, ".");
                  strcat(buffer, file_postpart);
            }

            if( LOCAL_DIR[0]!=0 )
            {
              strcpy(buffer+1024, buffer) ;
              strcpy(buffer,LOCAL_DIR) ;
              if( LOCAL_DIR[strlen(LOCAL_DIR)-1]!='\\' && LOCAL_DIR[strlen(LOCAL_DIR)-1]!=':' )
                strcat(buffer,"\\") ;
              strcat(buffer,buffer+1024) ;
            }

            if(download(buffer,2)==FALSE)
              show(" ")  ;

          }/*end if-else (termmode)*/

          break ;
        /*-------------------------------------------------------*/
        case GETFILE:   /*UPLOAD*/
          if(term_mode==1)
          {
                send_mpf(" ",1,STOPXFER) ;
                show("\n") ;
                show(FDISABLE) ;
                show(PRESSANYKEY) ;
                user_confirm();
                show("\n") ;
          }
          else
          {
                if(get_filename(buffer)==FALSE)
                {
                    send_mpf(" ",1,STOPXFER) ;
                }
                else
                {
                    upload(buffer,2) ;
                    show("\n") ;
                }
          }
          break ;
        /*-------------------------------------------------------*/
        case INTERNET:
          internet(buffer);
          /*internet() is a never-return call in PC client*/
          break;
        /*-------------------------------------------------------*/
        case INTRREAD:

          if( !strcmp(buffer, "SAME_BUFFER") )
          {
                /*if Server send "SAME_BUFFER",
                  client should use the previous one*/

                strcpy(buffer, intrread_buf);
          }
          else
          {
                /*else backup the current,
                  maybe next time will use it*/

                strcpy(intrread_buf, buffer);
          }

          if((cnt=postlist(buffer, 1))>0)
          {
            sprintf(buffer,"%d",cnt) ;
            send_mpf(buffer,strlen(buffer),INTRREAD) ;
          }
          else
          {
            send_mpf(buffer,1,INTRREAD) ;
          }
          break ;
        /*-------------------------------------------------------*/
        case INTRSEL:

          if( !strcmp(buffer, "SAME_BUFFER") )
          {
                /*description is same as INTRREAD, but for INTRSEL*/
                strcpy(buffer, intrsel_buf);
          }
          else
          {
                strcpy(intrsel_buf, buffer);
          }

          if((cnt=postlist(buffer, 2))>0)
          {
            sprintf(buffer,"%d",cnt) ;
            send_mpf(buffer,strlen(buffer),INTRSEL) ;
          }
          else
          {
            send_mpf(buffer,1,INTRSEL) ;
          }
          break ;
        /*-------------------------------------------------------*/
        case MAKEPOST:
          do
          {
            if(writer(buffer)==FALSE)
            {
              send_mpf(buffer,1,STOPPOST) ;
              break ;
            }
            else
            {
              show(EDITCONFIRM) ;
              do
              {
                key=tolower(readkey()) ;
              }
              while((key!='p')&&(key!='e')&&(key!='a')) ;
              printf("%c",key) ;
              fflush(stdout) ;
              if(key=='p')
              {
                send_mpf(buffer,strlen(buffer),MAKEPOST) ;
                break ;
              }
              else
              {
                if(key=='a')
                {
                  send_mpf(buffer,1,STOPPOST) ;
                  break ;
                }
              }
            }
          }
          while(key=='e') ;
          break ;
        /*-------------------------------------------------------*/
        case MENU:
          if( strlen(buffer)>0 )        /*new menu sent*/
                strncpy(menu_buf, buffer, 1632);

          show("{#c#}");        /*clrscr*/
          normal_text();
          show(menu_buf) ;

          out_getkey=FALSE ;
          do    /*--- Check the input key ---*/
          {
            key=pop_menu();

            if( !term_mode )
            {
              if( key==15 )        /* ctrl-O : set local directory path */
              {
                show("\n\n") ;
                show(DOWNPATH) ;
                getstring(-1,-1,LOCAL_DIR,60,1) ;
                show("{#c#}");
                normal_text();
                show(menu_buf) ;
                continue ;
              }

              if( key==4 )        /* ctrl-D : shell to dos */
              {
                show("\ntype 'EXIT' to go back to PowerBBS!\n");
                system(getenv("COMSPEC")) ;
                show("{#c#}");
                normal_text();
                show(menu_buf) ;
                if(mouse_mode)
                  mouse_mode=mouse_init();      /*reinitial mouse driver*/
                continue ;
              }
            }

            out_getkey=map_key_menuprotocol(menu_protocol, key);

            if( out_getkey )
            {
              if( !strcmp(menu_protocol, "{Ping}") )
                  gettime(&wait_time) ;

              if( !strcmp(menu_protocol, "{Version_Info}") )
              {
                show(CLIENT_VER_NOTE1);
                show(CLIENT_VER_NOTE2);
                show(CLIENT_VER_NOTE3);
              }

              /*--- send menu protocol ---*/
              send_mpf(menu_protocol, strlen(menu_protocol), MENU) ;

            }/*endif*/

          } while(!out_getkey) ;
          cnt=0 ;
          break ;
        /*-------------------------------------------------------*/
        case PASSWD:
          show(buffer) ;
          pwbuffer[0]=0 ;
          cnt=getstring(-1,-1,pwbuffer,10,2) ;
          show("\n") ;
          if(cnt<=0)
          {
            send_mpf(pwbuffer,1,PASSWD) ;
            break ;
          }
          /* encoding (algorithms by Aquarius Kuo)*/
          for(i=strlen(pwbuffer); i<10; i++)
            pwbuffer[i]=59+i*2 ;
          pwbuffer[10]=0 ;
          for(i=1; i<=10; i++)
          {
            pwbuffer[i-1]=(char) ((((pwbuffer[i-1]+pwbuffer[10-i])*67)%91)+32) ;
          }
          send_mpf(pwbuffer,10,PASSWD) ;
          cnt=0 ;
          break ;
        /*-------------------------------------------------------*/
        case PECHO:
          gettime(&now) ;
          mils=now.ti_sec*100+now.ti_hund ;
          mils-=(wait_time.ti_sec*100+wait_time.ti_hund) ;
          sprintf(buffer,"\n     Ping echo from server in %7.2f seconds\n",(float) mils*0.01) ;
          show(buffer) ;
          break ;
        /*-------------------------------------------------------*/
        case POST:
          if((cnt=parse_header(buffer,header))==FALSE)
            break ;
          clrscr() ;
          strcat(buffer,"\n") ;
          strcat(buffer,POST_BOTTOM) ;
          clear_esc(buffer) ;
          clear_esc(header) ;
          i=pager(header,buffer) ;
          if(i>0)                       /*user input a number*/
          {
            sprintf(buffer,"%d",i) ;
            send_mpf(buffer,strlen(buffer),GETPOST) ;
          }
          else
          {
            if(i==0)                    /*quit read*/
            {
              send_mpf("q",1,GETPOST) ;
            }
            if(i==-1)                   /*user response key*/
            {
              send_mpf(buffer,1,GETPOST) ;
            }
            if(i==-2)                   /*--- next post ---*/
            {
              sprintf(buffer,"%d",++cnt) ;
              send_mpf(buffer,strlen(buffer),GETPOST) ;
            }
            if(i==-3)                   /*--- pre post ---*/
            {
              sprintf(buffer,"%d",--cnt) ;
              send_mpf(buffer,strlen(buffer),GETPOST) ;
            }
          }
          break ;
        /*-------------------------------------------------------*/
        case PROMPT:
          parse_prompt(buffer) ;
          break ;
        /*-------------------------------------------------------*/
        case REJECT:
          quit=TRUE ;
          write(1,buffer,len) ;
          break ;
        /*-------------------------------------------------------*/
        case SCRSIZE:
          sprintf(buffer,"%d",LINES-3) ;
          send_mpf(buffer,strlen(buffer),SCRSIZE) ;
          break ;
        /*-------------------------------------------------------*/
        case SUSPEND:
          show(PRESSANYKEY) ;
          user_confirm();
          show("\n") ;
          break ;
        /*-------------------------------------------------------*/
        case TALK:
          chat_room(buffer) ;
          break ;
        /*-------------------------------------------------------*/
        case YESNO:
          yesno_confirm(buffer);
          send_mpf(buffer,1,YESNO) ;
          break;
        /*-------------------------------------------------------*/
        default:
          sprintf(buffer,"Error protocol : %d\n",prot) ;
          printf(buffer) ;
          end_tcp();
          exit(50);
      }
    }
    else
    {
      if(tcpstat==-1)
      {
        printf("Error tcp communation!!\n") ;
        end_tcp();
        exit(6);
      }
    }
  }
  while(!quit) ;

  end_tcp() ;

  /*restore original color*/
  textbackground(back_color);
  textcolor(fore_color);

}
/*end of main*/
/**************************************************************************/
/**************************************************************************/
/**************************************************************************/
