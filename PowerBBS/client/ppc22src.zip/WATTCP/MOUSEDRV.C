/*
        mouse driver module
*/

#include "pcpbbs.h"
#include "proto.h"

/*
        initialize --- restart mouse driver
*/
mouse_init()
/*
        RETURN: TRUE    mouse driver detected
                FALSE   no mouse driver
*/
{
  union REGS regs;

  regs.x.ax=0;
  int86(0x33,&regs,&regs);
  if(regs.x.ax==0)
        return(FALSE);

  return(TRUE);
}
/*end of mouse_init*/



/*
        show mouse cursor
*/
show_mouse_cursor()
{
  union REGS regs;

  regs.x.ax=1;
  int86(0x33,&regs,&regs);
  regs.x.ax=1;
  int86(0x33,&regs,&regs);
  regs.x.ax=1;
  int86(0x33,&regs,&regs);

  /*note: call 3 time to prevent from mutiple call of hide_mouse_cursor()*/

  return(0);
}
/*end of show_mouse_cursor*/



/*
        hide mouse cursor
*/
hide_mouse_cursor()
{
  union REGS regs;

  regs.x.ax=2;
  int86(0x33,&regs,&regs);

  return(0);
}
/*end of hide_mouse_cursor*/



/*
        get mouse condition
*/
mouse_xy_press(x, y, lb, rb)
        int *x;         /*cursor axis X*/
        int *y;         /*cursor axis Y*/
        int *lb;        /*left button*/
        int *rb;        /*right button*/
{
  union REGS regs;

  regs.x.ax=3;
  int86(0x33,&regs,&regs);
  *x=regs.x.cx/8;
  *y=regs.x.dx/8;
  *lb=*rb=0;
  if( regs.x.bx & 0x1 ) *lb=1;  /* Left */
  if( regs.x.bx & 0x2 ) *rb=1;  /* Right */

  return(0);
}
/*end of mouse_xy_press*/



/*
        set mouse cursor position
*/
set_mouse_cursor(int x,int y)
{
  union REGS regs;

  regs.x.ax=4;
  regs.x.cx=x*8;
  regs.x.dx=y*8;
  int86(0x33,&regs,&regs);

  return(0);
}
/*end of set_mouse_cursor*/

