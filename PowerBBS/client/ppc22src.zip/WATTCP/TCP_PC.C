
/*--- head files ---*/
#include <dos.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <tcp.h>
#include "proto.h"
#include "msg.h"

/*--- constant definitions ---*/
#define TRUE	-1
#define FALSE	0
#define TIMER	0x1c			/*system timer int number*/
#define SLIP_POLL  546			/*30 seconds*/
/**********************/


/*--- gloabl var for interrupts declaration ---*/
void interrupt (*oldint1c)();		/*store old int 1c vector*/

/*--- gloable var declerations ---*/
static unsigned int tcpdrv;		      /*store the vector of TCP_DRVR*/
static unsigned int slip_counter;
static char *slip_send="STOP_HANG_UP";
static int in_poll;
extern int errno;			      /*store last error no*/
extern unsigned int DEFAULT_TIMEOUT ;
extern int time_polling;		      /*flag for polling port 9 intervally*/
extern int slip_fd;
/***************************************/

/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/

/***********************************/
/*initial new interrupt subroutines*/
/***********************************/
void initial_interrupt(void)
{
 void interrupt tcp_doio(void); 	 /*prototype for int 1c*/

 oldint1c=getvect(TIMER);		 /*get old int1c vector*/

 disable();				/*CLI*/
  setvect(TIMER,tcp_doio);		 /*set new int8 vector*/
 enable();				/*SDI*/

}

/******************************/
/*recover old interrupt status*/
/******************************/
void recover_interrupt(void)
{
 disable();
 setvect(TIMER,oldint1c);		 /*set to old int8 vector*/
 enable();
 printf("interrupt recovered\n");
}


/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/

/**********************************************/
/*add extra processing for interrupt vector 1c*/
/**********************************************/
void interrupt tcp_doio(void)
{
  if( slipper_mode && time_polling )
  {
	if( (++slip_counter) > SLIP_POLL  && !in_poll)
	{
	   in_poll=1;	/*make sure only one UDP polling*/

	   /***************************************************/
	   /*send UDP packet to reset the timer of SLIP SERVER*/
	   /***************************************************/

	   sock_write(&udpport, "S", 1);

	   slip_counter=0;
	   in_poll=0;
	}
  }

  oldint1c();				  /*continue old timer routine*/
}
/*end of ISR tcp_doio*/



/*
	initial_slip_poll
*/
void initial_slip_poll(void)
{
 slip_counter=0;
 in_poll=0;
}
/*end of initial_slip_poll*/



/*
	tcp_close --- close network API sessions (include UDP)
*/
int tcp_close()
{
  int status;
  char *errmsg;

  sock_close(&tcpport);

  if( slipper_mode )
	sock_close(&udpport);

  sock_wait_closed(&tcpport, DEFAULT_TIMEOUT, NULL, &status);

  return(0);

sock_err:
  if( status==1 )
  {
	printf("Closed normally\n");
	return(0);
  }
  else
  {
	errmsg=sockerr(&tcpport);
	if( errmsg )
		printf("Socket closed with error '%s'\n", errmsg);
  }

  return(0);
}
/*end of tcp_close*/



/*
	tcp_get --- read tcp socket
*/
int tcp_get(char *buf, int maxn)
{
  int status;
  int len;
  int ret;
  char *errmsg;

  sock_wait_input(&tcpport, DEFAULT_TIMEOUT, NULL, &status);

  len=sock_dataready(&tcpport);

  if( len>maxn )
	len=maxn;

  ret=sock_read(&tcpport, buf, len);

  if( ret<0 )
	return(-1);
  else
	return(ret);

sock_err:
  if( status==1 )
	printf("Closed normally\n");
  else
  {
	errmsg=sockerr(&tcpport);
	if( errmsg )
		printf("Socket closed with error '%s'\n", errmsg);
  }

  return(-1);
}
/*end of tcp_get*/



/*
	tcp_get_nowait --- read socket without blocking
*/
int tcp_get_nowait(char *buf, int maxn)
{
  int status;
  int ret;
  char *errmsg;

  ret=sock_fastread(&tcpport, buf, maxn);

  if( ret<0 )
	return(-1);
  else
	return(ret);

sock_err:
  if( status==1 )
	printf("Closed normally\n");
  else
  {
	errmsg=sockerr(&tcpport);
	if( errmsg )
		printf("Socket closed with error '%s'\n", errmsg);
  }

  return(-1);
}
/*end of tcp_get_nowait*/



/*
	tcp_put --- write socket
*/
int tcp_put(char *buf, int tn)
{
  int ret;
  int status;
  char *errmsg;

  ret=sock_write(&tcpport, buf, tn);

  if( ret<0 )
	return(-1);

  return(0);

sock_err:
  if( status==1 )
	printf("Closed normally\n");
  else
  {
	errmsg=sockerr(&tcpport);
	if( errmsg )
		printf("Socket closed with error '%s'\n", errmsg);
  }

  return(-1);
}
/*end of tcp_put*/



/*
	connectTCP --- connect to remote BBS port
*/
int connectTCP(domainadd, bbsport)
char *domainadd ;
int bbsport ;
/*
	return:	TRUE	connection successfully
		FALSE	connection failed
*/
{
  longword host;
  word port;
  word status;
  char *errmsg;

  if( !(host=resolve(domainadd)) )
  {
	printf("Could not resolve host %s\n", domainadd);
	return(FALSE);
  }

  port=bbsport;

  printf("attempting to open %s.%d\n", domainadd, bbsport);

  if( !tcp_open(&tcpport, 0, host, port, NULL) )
  {
	printf("Unable to open TCP session\n");
	return(FALSE);
  }

  printf("Waiting a maximum of %u seconds for connection to be established\n", DEFAULT_TIMEOUT);

  sock_wait_established(&tcpport, DEFAULT_TIMEOUT, NULL, &status);
  printf("Socket connection established!\n");

  /*set socket mode*/
  sock_mode(&tcpport, TCP_MODE_BINARY);
  sock_mode(&tcpport, TCP_MODE_NAGLE);

  return(TRUE);

sock_err:
  if( status==1 )
	printf("Closed normally\n");
  else 
  {
	errmsg=sockerr(&tcpport);
	if( errmsg )
		printf("Socket closed with error '%s'\n", errmsg);
  }

  return(FALSE);
}
/*end of connectTCP*/



/*
	connectUDP --- connect to remote UDP port
*/
int connectUDP(domainadd, uport)
char *domainadd ;
int uport ;
/*
	return:	TRUE	connection successfully
		FALSE	connection failed
*/
{
  longword host;
  word port;
  word status;
  char *errmsg;

  if( !(host=resolve(domainadd)) )
  {
	return(FALSE);
  }

  port=uport;

  if( !udp_open(&udpport, 0, host, port, NULL) )
  {
	return(FALSE);
  }

  /*set socket mode*/
  sock_mode(&udpport, UDP_MODE_NOCHK);

  return(TRUE);

sock_err:
  if( status==1 )
	printf("Closed normally\n");
  else 
  {
	errmsg=sockerr(&tcpport);
	if( errmsg )
		printf("Socket closed with error '%s'\n", errmsg);
  }

  return(FALSE);
}
/*end of connectUDP*/



/*
	end_tcp --- end all network sessions (include UDP)
*/
int end_tcp()
{
  tcp_close();
  if( success_then_remove )
  {
	printf("%s %s, %s", S_T_R_MSG, s_t_r_filename, PRESSANYKEY);
	success_then_remove=FALSE;
	readkey();
  }
  return(0);
}
/*end of end_tcp*/

