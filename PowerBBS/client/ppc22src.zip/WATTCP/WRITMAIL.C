#include <process.h>
#include "pcpbbs.h"
#include "proto.h"
#include "msg.h"

static char rcsid[]="$Id: writmail.c,v 1.5 1994/05/04 05:15:23 cs79026 Exp cs79026 $" ;

int writer(buffer)
char *buffer ;
{
  char fname[80],
       tmpbuf[101] ;
  int status ;
  FILE *fp ;
  struct stat f1, f2 ;

  if( success_then_remove )
  {
	/*maybe user re-edit, remove the old one*/
	unlink(s_t_r_filename);
	success_then_remove=FALSE;
  }

  if( strlen(temppath)<=0 )
  {
    tmpbuf[0]=0 ;
  }
  else
  {
    strcpy(tmpbuf, temppath);
    if( tmpbuf[strlen(tmpbuf)-1]!='\\' && tmpbuf[strlen(tmpbuf)-1]!=':' )
      strcat(tmpbuf,"\\") ;
  }

  strcat(tmpbuf,tmpnam(NULL)) ;

  if((fp=fopen(tmpbuf,"wf"))==NULL)
  {
    show("\nFile open error!!\n") ;
    readkey() ;
    return(FALSE) ;
  }
  clear_cr(buffer) ;
  fwrite(buffer,strlen(buffer),1,fp) ;
  fclose(fp) ;

  stat(tmpbuf,&f1) ;

  sprintf(fname,"%s %s",editor,tmpbuf) ;

  if(system(fname)<0)
  {
    show("\nCall editor error...!!\n") ;
    readkey() ;
    return(FALSE) ;
  }
  else
  {
    if(mouse_mode)
      mouse_mode=mouse_init();		/*reinitial mouse driver*/
    stat(tmpbuf,&f2) ;
    if(f1.st_mtime==f2.st_mtime)
    {
      unlink(tmpbuf) ;
      return(FALSE) ;
    }
    strcpy(fname,tmpbuf) ;
    if((fp=fopen(fname,"rt"))==NULL)
    {
      show("\nfopen temp-file error!!\n") ;
      readkey() ;
      unlink(fname) ;
      return(FALSE) ;
    }
    else
    {
      buffer[0]=0 ;
      while(fgets(tmpbuf,100,fp)!=NULL)
      {
        strcat(buffer,tmpbuf) ;
        if((unsigned long)strlen(buffer)>TMP_MAX)
          break ;
      }
      fclose(fp) ;
      success_then_remove=TRUE;
      strcpy(s_t_r_filename, fname);
    }
  }
  return(TRUE) ;
}

