/*
        PowerBBS Screen Previewer by Samson Chen, May 10, 1995
        Code modified from Aquarius Kuo's pcterm.c of PBBS source
        For PC Only (Compiled by Borland C++ V3.1)
*/

#include <stdio.h>
#include <dos.h>
#include <bios.h>
#include <conio.h>
#include <ctype.h>
#include <io.h>
#include <stdlib.h>
#include <string.h>

#define	TRUE	-1
#define	FALSE	0

#define LINES	24

#define META_LEFT       "{#"
#define META_RIGHT      "#}"

/* function prototype */
int readkey(void);
int clear_cr(char*);
int clear_esc(char*);
int erase_line(void);
int show(char*);


static long last_s ;



/*--- To get a key input ---*/
int readkey(void)
{
  char k ;

  k=bioskey(0) & 0xff ;
  return(k) ;
}


/*--- To erase cr ---*/
int clear_cr(buf)
char *buf ;
{
  int i ;
  
  i=0 ;
  while(*(buf+i)!=0)
  {
    if((*(buf+i)==13) && (*(buf+i+1)==10))
      *(buf+i)=' ' ;
    i++ ;
  }

  return(0);
}

/*--- To erase esc ---*/
int clear_esc(buf)
char *buf ;
{
  int i ;
  
  i=0 ;
  while(*(buf+i)!=0)
  {
    if( *(buf+i)==27 )
      *(buf+i)=' ' ;
    i++ ;
  }

  return(0);
}

/*--- Erase one line ---*/
int erase_line(void)
{
  char cr=13, line[80] ;

  memset(line,32,79) ;
  write(1,&cr,1) ;
  write(1,line,79) ;
  write(1,&cr,1) ;

  return(0);
}
    

/*--- To show the menu screen ---*/
int show(str)
char *str ;
{
  int i, j ;
  int posi ;
  int n, cols ;
  int ph ;
  int handle ;
  char key ;
  char cr=13 ;
  char comm[100] ;
  char *tab="  " ;
  int tail=1 ;          /* check if last page */
  int l, blink=0, fc, bc, ofc ,obc ,jmp, no ;
  int cnt=0 ;
  char num[5] ;
  char prompt_line[80];
  int x, y, a, b;

  ofc=fc=LIGHTGRAY;
  obc=bc=BLACK;

  i=n=cols=ph=0 ;

  while(*(str+i)!=0)
  {
    if( !strncmp((str+i), META_LEFT, 2) )
    {
      i+=2 ;
      l=0 ;     /* command length */
      jmp=0 ;   /* fc & bc switch */

      while( strncmp((str+i), META_RIGHT, 2) )
      {
        if(*(str+i)==0  || l>10)
          break ;

        if(tolower(*(str+i))=='b')
        {
          blink=BLINK ;         /* set blink */
        }

        if(tolower(*(str+i))=='c')
        {
          clrscr() ;         /* clear screen */
          fc=ofc ;
          bc=obc ;
          blink=0 ;
        }

        if(tolower(*(str+i))=='p')
        {
          readkey() ;         /* Pause */
        }

        if(tolower(*(str+i))=='n')
        {
          blink=0 ;             /* set normal color */
          fc=ofc ;
          bc=obc ;
        }

        if(tolower(*(str+i))==',')
        {
          jmp=1 ;
        }

        if( isdigit(*(str+i)) )
        {
          num[0]=*(str+i++) ;
          l++ ;
          if( isdigit(*(str+i)) )
          {
            num[1]=*(str+i++) ;
            l++ ;
            num[2]=0 ;
          }
          else
          {
            num[1]=0 ;
          }

          if( jmp==0 )
          {
            fc=atoi(num) ;
            jmp=1 ;
          }
          else
          {
            bc=atoi(num) ;
          }
          continue ;
        }
        i++ ;
      }

      i+=2 ;    /*skip META_RIGHT*/

      textattr(fc | (bc<<4) | blink) ;

      continue;

    }/*end if(META_LEFT)*/


    if(*(str+i)==10)
    {
      write(1,&cr,1) ;
      write(1,(str+i),1) ;      /* print new line */
      n++ ;
      cols=0 ;

      if(n%(LINES-2)==0)
      {
        cnt=0 ;         /* for the last page repeat the head line */
        j=i+1 ;
        while(*(str+j)!=0)
        {
          if(cnt==0)
            posi=j ;

          if(*(str+(j++))==10)
            cnt++ ;
        }

        if( cnt<LINES )
          tail=1 ;
        else
          tail=0 ;

        j=i+1 ;
        while( *(str+j)!=10 && *(str+j)!=0 )
        {
          if( !strncmp((str+j), META_LEFT, 2) )
          {
            j+=2 ;
            l=0 ;     /* command length */
            jmp=0 ;   /* fc & bc switch */

            while( strncmp((str+j), META_RIGHT, 2) )
            {
              if(*(str+j)==0  || l>10)
                break ;

              if(tolower(*(str+j))=='b')
              {
                blink=BLINK ;         /* set blink */
              }

              if(tolower(*(str+j))=='c')
              {
                clrscr() ;         /* clear screen */
                fc=7 ;
                bc=0 ;
                blink=0 ;
              }

              if(tolower(*(str+j))=='p')
              {
                readkey() ;         /* Pause */
              }

              if(tolower(*(str+j))=='n')
              {
                blink=0 ;             /* set normal color */
                fc=LIGHTGRAY ;
                bc=BLACK ;
              }

              if(tolower(*(str+j))==',')
              {
                jmp=1 ;
              }

              if( isdigit(*(str+j)) )
              {
                num[0]=*(str+j++) ;
                l++ ;
                if( isdigit(*(str+j)) )
                {
                  num[1]=*(str+j++) ;
                  l++ ;
                  num[2]=0 ;
                }
                else
                {
                  num[1]=0 ;
                }

                if( jmp==0 )
                {
                  fc=atoi(num) ;
                  jmp=1 ;
                }
                else
                {
                  bc=atoi(num) ;
                }
                continue ;
              }
              j++ ;
            }
            j+=2 ;      /* skip META_RIGHT*/
            textattr(fc | (bc<<4) | blink) ;
          }
    
          if(*(str+j)==9)     /* TAB */
          {
            if((cols%8)==0)
            {
              write(1,tab,1) ;
              cols++ ;
            }
            while(cols%8)
            {
              write(1,tab,1) ;
              cols++ ;
            }  
            j++ ;
            continue ;
          }
          
          write(1,(str+j),1) ;
          cols++ ;
          j++ ;

        }

        if( *(str+j)==10 )
        {
          write(1,(str+j),1) ;
          write(1,&cr,1) ;
          cols=0 ;
        }
        else
          return(0) ;   /* *(str+j)=0 */

        textcolor(2);
        gotoxy(1, 25);
	show("[���N��]�U�@��, [B]�e�@��, [Q]����");
        textbackground(BLACK);
        textcolor(LIGHTGRAY);
        lowvideo();

        key=readkey() ;

        switch(key)
        {
          case 'q':
          case 'Q':
            erase_line() ;
            show("\n") ;
            return(FALSE) ;
          case 'b':
          case 'B':
            ph=0 ;
            for(j=i; j>=0; j--)
            {
              if( *(str+j)==10 )
                ph++ ;
                
              if( ph>(LINES-2)*2 )
              {
                break ;
              }
            }
            
            cnt=0 ;
            i=j ;
            last_s=j ;          /* adjust last_search */
            clrscr() ;

            break ;
        }
        erase_line() ;
        if( (cnt<LINES-1) && (cnt>0) )
        {
          i=posi ;
        }

        if( !tail )
          clrscr() ;
      }


      i++ ;
      continue ;
    }

    if(*(str+i)==9)
    {
      if((cols%8)==0)
      {
        putch(*tab) ;
        cols++ ;
      }
      while(cols%8)
      {
        putch(*tab) ;
        cols++ ;
      }
    }
    else
    {
      putch(*(str+i)) ;
      cols++ ;
    }
    i++ ;
  }
  return(0);
}
/*end of show*/


  
/*************************************************************************/
main(int argc, char *argv[])
{
  FILE *pv_file;
  char buf[62000];
  char line_buf[256];

  printf("\n");
  printf("PowerBBS Screen Preview by Samson Chen, May 10, 1995\n");
  printf("Code modified from Aquarius Kuo's PCTERM.c of PBBS source\n");
  printf("\n");

  if( argc<2 )
  {
    printf("  usage: ppreview [preview_file]\n");
    exit(1);
  }

  pv_file=fopen(argv[1], "r");
  if( pv_file )
  {
    buf[0]=0;
    while( fgets(line_buf, 255, pv_file) )
	strcat(buf, line_buf);

    show(buf);

    textbackground(BLACK);
    textcolor(LIGHTGRAY);
    lowvideo();
  }
  else
    printf("  open '%s' error!\n", argv[1]);

  return(0);
}
/*************************************************************************/

