
#include <stdio.h>
#include <string.h>
#include <conio.h>

#define SIZE    10000
#define VIDIO   (unsigned) 0xb800
/*#define DEBUG*/

struct SCREEN {
                int x ;
                int y ;
                int offset ;
                int front ;
                int back ;
                int blink ;
                char cCode ;
                char cAttr ;
              } ;

char V_peekattr(int offset)
{
  char bAttr ;

  bAttr=peekb(VIDIO,offset) ;

#ifdef DEBUG
        printf("V_peekattr: offset=%d, bAttr=%d\n",offset,bAttr) ;
#endif

  return(bAttr) ;
}

void V_pokeattr(int offset,char value)
{

#ifdef DEBUG
        printf("V_pokeattr: offset=%d, value=%d\n",offset,value) ;
#endif

  pokeb(VIDIO,offset,value) ;
}

/*--- transfer position X,Y to VIDIO offset
        for character, attribute need add 1
*/
int pos2offset(int x, int y)
{
#ifdef DEBUG
        if(x<1 || x>80 || y<1 || y>25)
        {
          printf("pos2offset: x=%d, y=%d\n",x,y) ;
          exit(1) ;
        }
#endif
  return(((y-1)*80+x-1)*2) ;
}

char val2attr(int frontcolor,int backcolor)
{
  return(backcolor<<4 | frontcolor) ;
}

int attr2val(char attr,int *frontcolor,int *backcolor)
{
  *frontcolor=attr & 0x0f ;
  *backcolor=((unsigned char) attr) >> 4 ;

  return(*backcolor) ;
}

int getcolor(struct SCREEN *sBuf,int x, int y)
{
  sBuf->x=x ;
  sBuf->y=y ;
  sBuf->offset=pos2offset(x,y) ;
  sBuf->cCode=V_peekattr(sBuf->offset) ;
  sBuf->cAttr=V_peekattr(sBuf->offset+1) ;
  attr2val(sBuf->cAttr,&(sBuf->front),&(sBuf->back)) ;

  if(sBuf->back & 0x8)
  {
    sBuf->blink=1 ;
    sBuf->back&=0x7 ;
  }
  else
    sBuf->blink=0 ;

  return(0) ;
}


main(int argc, char **argv)
{
  int i, j ;
  char cpCommand[80], cpBuf[SIZE], cpTmp[30] ;
  struct SCREEN sHere,sPre ;
  FILE *fp ;

  if(argc<3)
  {
    printf("COLORMAP 1.00 Copyright (c) 1995 Aquarius Kuo.\n") ;
    printf("Free for everyone use.  Aug 5 1995\n\n") ;
    printf("Convert the ANSI_format file to PBBS_format file (only one screen size)\n\n") ;
    printf("Usage:     COLORMAP <ANSI_format_file> <PBBS_screen_file> [/A]\n") ;
    printf("           /A : Append. (default overwrite)\n") ;
    printf("Examples:  COLORMAP ship.ans welcome.mnu , COLORMAP dragon.ans prelog.mnu /A\n\n") ;
    printf("NOTE: You must setup ANSI.SYS in your config.sys .\n\n") ;
    exit(0) ;
  }

  clrscr() ;
  sprintf(cpCommand,"type %s",argv[1]) ;
  system(cpCommand) ;
  gotoxy(1,25) ;
  printf("Press <ESC> to quit , any key to convert file...") ;
  if(getch()==27)
    exit(0) ;

  memset(cpBuf,0,SIZE) ;
  getcolor(&sPre,1,1) ;

  if(sPre.blink)
    sprintf(cpTmp,"{#cb%d,%d#}",sPre.front,sPre.back) ;
  else
    sprintf(cpTmp,"{#c%d,%d#}",sPre.front,sPre.back) ;

  strcpy(cpBuf,cpTmp) ;

  for(j=1; j<25; j++)
  {
    for(i=1; i<=80; i++)
    {
      getcolor(&sHere,i,j) ;
      if(sHere.cAttr==sPre.cAttr)
      {
        sprintf(cpTmp,"%c",sHere.cCode) ;
      }
      else
      {
        if(sHere.blink)
          sprintf(cpTmp,"{#b%d,%d#}%c",sHere.front,sHere.back,sHere.cCode) ;
        else
          sprintf(cpTmp,"{#n%d,%d#}%c",sHere.front,sHere.back,sHere.cCode) ;

        memcpy(&sPre,&sHere,sizeof(struct SCREEN)) ;
      }
      strcat(cpBuf,cpTmp) ;
    }
    strcat(cpBuf,"\n") ;
  }

  strcpy(cpTmp,"w") ;
  if(argc==4)
  {
    if( !stricmp(argv[3],"/A") )
    {
      strcpy(cpTmp,"a") ;
    }
  }

  if((fp=fopen(argv[2],cpTmp))==NULL)
  {
    perror("Output file error: ") ;
    exit(1) ;
  }

  fwrite(cpBuf,1,strlen(cpBuf),fp) ;
  fwrite("{#n#}", 1, 5, fp) ;
  fclose(fp) ;

  gotoxy(1,24) ;
  printf("\n\nTransfer %s to %s OK!\n",argv[1],argv[2]) ;

}

