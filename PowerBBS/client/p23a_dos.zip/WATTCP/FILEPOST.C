#include "pcpbbs.h"
#include "proto.h"

int get_file(fn,buf)
char *fn ;
char *buf ;
{
  FILE *fp ;
  char tmp[512] ;
  long c ;

  if((fp=fopen(fn,"r"))==NULL)
  {
    return(FALSE) ;
  }
  printf("\r\n") ;      /* new line */

  c=0 ;
  while( (fgets(tmp,512,fp)!=NULL) && (c<TMP_BUF) )
  {
    show(tmp) ;
    c+=strlen(tmp) ;
    strcat(buf,tmp) ;
  }

  fclose(fp) ;
  if(c<1)
    return(FALSE) ;

  return(TRUE) ;
}
