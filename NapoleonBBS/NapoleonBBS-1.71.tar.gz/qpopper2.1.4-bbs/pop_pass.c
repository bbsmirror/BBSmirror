/*
 * Copyright (c) 1989 Regents of the University of California.
 * All rights reserved.  The Berkeley software License Agreement
 * specifies the terms and conditions for redistribution.
 */

#ifndef lint
static char copyright[] = "Copyright (c) 1990 Regents of the University of California.\nAll rights reserved.\n";
static char SccsId[] = "@(#)@(#)pop_pass.c	2.3  2.3 4/2/91";
#endif not lint

#include <stdio.h>
#include <sys/types.h>
#if defined(SYSV) || defined(AIX)
# include <string.h>
#else
# include <strings.h>
#endif

#include <pwd.h>
#ifdef BBS
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <fcntl.h>
#include <bbs.h>
#endif
#include "popper.h"


/* This error message is vague on purpose to help reduce help improve
   security at the inconvience of administrators and users */

char	*pwerrmsg = "Password supplied for \"%s\" is incorrect.";


#ifdef NONAUTHFILE
checknonauthfile(user) 
     char *user;
{
    char buf[MAXUSERNAMELEN+1];
    FILE *fp;
    char cool = 0;

    if ((fp = fopen(NONAUTHFILE, "r")) != NULL) {
	while (fgets(buf, MAXUSERNAMELEN+1, fp)) {
	    buf[strlen(buf) -1] = '\0';
	    if (!strcmp(buf, user)) {
		fclose(fp);
		return(-1);
	    }
	}

	fclose(fp);
    }
    return(0);
}
#endif

#ifdef AUTHFILE
checkauthfile(user) 
     char *user;
{
    char buf[MAXUSERNAMELEN+1];
    FILE *fp;
    char cool = 0;

    if ((fp = fopen(AUTHFILE, "r")) != NULL) {
	while (fgets(buf, MAXUSERNAMELEN+1, fp)) {
	    buf[strlen(buf) -1] = '\0';
	    if (!strcmp(buf, user)) {
		fclose(fp);
		return(0);
	    }
	}

	fclose(fp);
    }
    return(-1);
}
#endif

#ifdef KERBEROS
int auth_user (p, pw)
POP     *   p;
struct passwd *pw;
{
    char lrealm[REALM_SZ];
    int status;
    struct passwd *pwp;
 
    if ((status = krb_get_lrealm(lrealm,1)) == KFAILURE) {
        pop_log(p, LOG_WARNING, "%s: (%s.%s@%s) %s", p->client, kdata.pname, 
		kdata.pinst, kdata.prealm, krb_err_txt[status]);
        return(pop_msg(p,POP_FAILURE,
            "Kerberos error:  \"%s\".", krb_err_txt[status]));
    }

    if (strcmp(kdata.prealm,lrealm))  {
         pop_log(p, LOG_WARNING, "%s: (%s.%s@%s) realm not accepted.", 
		 p->client, kdata.pname, kdata.pinst, kdata.prealm);
	 return(pop_msg(p,POP_FAILURE,
		     "Kerberos realm \"%s\" not accepted.", kdata.prealm));
    }

    if (strcmp(kdata.pinst,"")) {
        pop_log(p, LOG_WARNING, "%s: (%s.%s@%s) instance not accepted.", 
		 p->client, kdata.pname, kdata.pinst, kdata.prealm);
        return(pop_msg(p,POP_FAILURE,
	      "Must use null Kerberos(tm) instance -  \"%s.%s\" not accepted.",
	      kdata.pname, kdata.pinst));
    }

    return(POP_SUCCESS);
}

#else /* Not Kerberos */
#ifdef AUTH
    char *crypt();

#ifdef SUNOS4

#include <sys/label.h>
#include <sys/audit.h>
#include <pwdadj.h>

static int
auth_user(p, pw)
POP     *   p;
struct passwd *pw;
{
    struct passwd_adjunct *pwadj;

    /*  Look for the user in the shadow password file */
    if ((pwadj = getpwanam(p->user)) == NULL) {
	return (pop_msg(p,POP_FAILURE,
	    "(shadow) Password supplied for \"%s\" is empty.",p->user));
    } else {
        pw->pw_passwd = (char *)strdup(pwadj->pwa_passwd);
    }

    /*  We don't accept connections from users with null passwords */
    /*  Compare the supplied password with the password file entry */
    if ((pw->pw_passwd == NULL) || (*pw->pw_passwd == '\0') ||
		    strcmp(crypt(p->pop_parm[1], pw->pw_passwd), pw->pw_passwd))
	return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));

    return(POP_SUCCESS);
}

#endif	/* SUNOS4 */

#if defined(SOLARIS2) || defined(AUX)

#include <shadow.h>

static int
auth_user(p, pw)
POP     *   p;
struct passwd *pw;
{
    register struct spwd * pwd;
    long today;

    /*  Look for the user in the shadow password file */
    if ((pwd = getspnam(p->user)) == NULL) {
        if (!strcmp(pw->pw_passwd, "x"))	/* This my be a YP entry */
	    return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));
    } else {
	today = (long)time((time_t *)NULL)/24/60/60;

	/* Check for expiration date */
	if (pwd->sp_expire > 0 && today > pwd->sp_expire)
	    return (pop_msg(p,POP_FAILURE,"\"%s\": account expired.",p->user));

	/* Check if password is valid */
	if (pwd->sp_max > 0 && today > pwd->sp_lstchg+pwd->sp_max)
	    return (pop_msg(p,POP_FAILURE,"\"%s\": account expired.",p->user));

	pw->pw_passwd = (char *)strdup(pwd->sp_pwdp);
	endspent();
    }

    /*  We don't accept connections from users with null passwords */
    /*  Compare the supplied password with the password file entry */
    if ((pw->pw_passwd == NULL) || (*pw->pw_passwd == '\0') ||
		    strcmp(crypt(p->pop_parm[1], pw->pw_passwd), pw->pw_passwd))
	return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));

    return(POP_SUCCESS);
}

#endif	/* SOLARIS2 || AUX */

#if defined(PTX)

#include <shadow.h>

static int
auth_user(p, pw)
POP     *   p;
struct passwd *pw;
{
    register struct spwd * pwd;
    long today;

    /*  Look for the user in the shadow password file */
    if ((pwd = getspnam(p->user)) == NULL) {
        if (!strcmp(pw->pw_passwd, "x"))	/* This my be a YP entry */
	    return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));
    } else {
	pw->pw_passwd = (char *)strdup(pwd->sp_pwdp);
    }

    /*  We don't accept connections from users with null passwords */
    /*  Compare the supplied password with the password file entry */
    if ((pw->pw_passwd == NULL) || (*pw->pw_passwd == '\0') ||
		    strcmp(crypt(p->pop_parm[1], pw->pw_passwd), pw->pw_passwd))
	return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));

    return(POP_SUCCESS);
}

#endif	/* PTX */

#ifdef POPSCO

# include <sys/security.h>
# include <sys/audit.h>
# include <prot.h>
# define PASSWD(p)	p->ufld.fd_encrypt

static int
auth_user(p, pw)
POP     *   p;
struct passwd *pw;
{
    register struct pr_passwd *pr;

    if ((pr = getprpwnam(p->user)) == NULL) {
        if (!strcmp(pw->pw_passwd, "x"))	/* This my be a YP entry */
	    return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));

	/*  We don't accept connections from users with null passwords */
	if ((pw->pw_passwd == NULL) || (*pw->pw_passwd == '\0') ||
					    (strlen(pw->pw_passwd) != 13))
	    return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));

	/*  Compare the supplied password with the password file entry */
	if (strcmp (crypt (p->pop_parm[1], pw->pw_passwd), pw->pw_passwd) != 0)
	    return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));
    } else {
	/*  We don't accept connections from users with null passwords */
	/*  Compare the supplied password with the password file entry */
	if ((PASSWD(pr) == NULL) || (*PASSWD(pr) == '\0') ||
		    strcmp(bigcrypt(p->pop_parm[1], PASSWD(pr)), PASSWD(pr)))
	    return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));

	/*  Compare the supplied password with the password file entry */
	    return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));
    }

    return(POP_SUCCESS);
}

#endif	/* POPSCO */

#ifdef ULTRIX

#include <auth.h>

static int
auth_user(p, pw)
struct passwd  *   pw;
POP     *   p;
{
    AUTHORIZATION *auth, *getauthuid();

    if ((auth = getauthuid(pw->pw_uid)) == NULL) {
        if (!strcmp(pw->pw_passwd, "x"))	/* This my be a YP entry */
	    return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));
    } else {
	pw->pw_passwd = (char *)strdup(auth->a_password);
    }

    /*  We don't accept connections from users with null passwords */
    /*  Compare the supplied password with the password file entry */
    if ((pw->pw_passwd == NULL) || (*pw->pw_passwd == '\0') ||
		strcmp(crypt16(p->pop_parm[1], pw->pw_passwd), pw->pw_passwd))
	return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));

    return(POP_SUCCESS);
}

#endif	/* ULTRIX */

#ifdef OSF1
#include <sys/types.h>
#include <sys/security.h>
#include <prot.h>
#define   PASSWD(p)   (p->ufld.fd_encrypt)
static int
auth_user(p, pw)
POP     *   p;
struct passwd *pw;
{
    register struct pr_passwd *pr;

    if ((pr = getprpwnam(p->user)) == NULL) {
        if (!strcmp(pw->pw_passwd, "x"))	/* This my be a YP entry */
	    return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));
    } else {
	pw->pw_passwd = (char *)strdup(PASSWD(pr));
    }

    /*  We don't accept connections from users with null passwords */
    /*  Compare the supplied password with the password file entry */
    if ((pw->pw_passwd == NULL) || (*pw->pw_passwd == '\0') ||
		strcmp(bigcrypt(p->pop_parm[1], pw->pw_passwd), pw->pw_passwd))
	return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));

    return(POP_SUCCESS);
}

#endif        /* OSF1 */

#ifdef UNIXWARE

#include <shadow.h>

static int
auth_user(p, pw)
struct passwd  *   pw;
POP     *   p;
{
    register struct spwd * pwd;
    long today;

    /*  Look for the user in the shadow password file */
    if ((pwd = getspnam(p->user)) == NULL) {
        if (!strcmp(pw->pw_passwd, "x"))	/* This my be a YP entry */
	    return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));
    } else {
	today = (long)time((time_t *)NULL)/24/60/60;

	/* Check for expiration date */
	if (pwd->sp_expire > 0 && today > pwd->sp_expire)
	    return (pop_msg(p,POP_FAILURE,"\"%s\": account expired.",p->user));

	/* Check if password is valid */
	if (pwd->sp_max > 0 && today > pwd->sp_lstchg+pwd->sp_max)
	    return (pop_msg(p,POP_FAILURE,"\"%s\": account expired.",p->user));

	pw->pw_passwd = (char *)strdup(pwd->sp_pwdp);
	endspent();
    }

    /*  We don't accept connections from users with null passwords */
    /*  Compare the supplied password with the password file entry */
    if ((pw->pw_passwd == NULL) || (*pw->pw_passwd == '\0') ||
		    strcmp(crypt(p->pop_parm[1], pw->pw_passwd), pw->pw_passwd))
	return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));

    return(POP_SUCCESS);
}

#endif	/* UNIXWARE */

#ifdef LINUX
#include <shadow.h>
 
static int
auth_user(p, pw)
POP     *   p;
struct passwd *pw;
{
    register struct spwd * pwd;
    long today;

    /*  Look for the user in the shadow password file */
    if ((pwd = getspnam(p->user)) == NULL) {
        if (!strcmp(pw->pw_passwd, "x"))	/* This my be a YP entry */
	    return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));
    } else {
	today = (long)time((time_t *)NULL)/24/60/60;

	/* Check for expiration date */
	if (pwd->sp_expire > 0 && today > pwd->sp_expire)
	    return (pop_msg(p,POP_FAILURE,"\"%s\": account expired.",p->user));

	/* Check if password is valid */
	if (pwd->sp_max > 0 && today > pwd->sp_lstchg+pwd->sp_max)
	    return (pop_msg(p,POP_FAILURE,"\"%s\": account expired.",p->user));

	pw->pw_passwd = (char *)strdup(pwd->sp_pwdp);
	endspent();
    }

    /*  We don't accept connections from users with null passwords */
    /*  Compare the supplied password with the password file entry */
    if ((pw->pw_passwd == NULL) || (*pw->pw_passwd == '\0') ||
		    strcmp(crypt(p->pop_parm[1], pw->pw_passwd), pw->pw_passwd))
	return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));

    return(POP_SUCCESS);
}

#endif  /* LINUX */

#else	/* NOT AUTH */

char *crypt();

static int
auth_user(p, pw)
POP     *   p;
struct passwd  *   pw;
{
    /*  We don't accept connections from users with null passwords */
    /*  Compare the supplied password with the password file entry */
    if ((pw->pw_passwd == NULL) || (*pw->pw_passwd == '\0') ||
		    strcmp(crypt(p->pop_parm[1], pw->pw_passwd), pw->pw_passwd))
	return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));

    return(POP_SUCCESS);
}

#ifdef BBS
static struct userec foo;

struct userec *
bbsgetpwnam(char *name)
{
    int fd, size;
    char buffer[IDLEN+2];
   
    strcpy(buffer, name);
    buffer[strlen(name) - 4] = '\0';

    if ((fd = open("/home/bbs/.PASSWDS",O_RDONLY,0)) == -1) {
        perror("Woop");
    }
 
    size = sizeof (foo); 

    while (read(fd,&foo, size) == size) {
	if ( !strcmp(buffer, foo.userid)) {
	    return &foo;
	}
    }
    return NULL; 
}

static int
auth_bbsuser(p, uinfo)
POP	*p;
struct userec  *uinfo;
{
    /*  We don't accept connections from users with null passwords */
    /*  Compare the supplied password with the password file entry */
    if ((uinfo->passwd == NULL) || (*uinfo->passwd == '\0') ||
                    strcmp(crypt(p->pop_parm[1], uinfo->passwd), uinfo->passwd))
        return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));

    return(POP_SUCCESS);
}
#endif

#endif	/* AUTH */

#endif  /* Kerberos */

/* 
 *  pass:   Obtain the user password from a POP client
 */
int inbbs = 0;

int pop_pass (p)
POP     *   p;
{
    struct passwd pw, *pwp;
#ifdef BBS
    struct userec *uinfo;
#endif

#ifdef NONAUTHFILE
    /* Is the user not authorized to use POP? */
    if (checknonauthfile(p->user) != 0)
	return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));
#endif

#ifdef AUTHFILE
    /* Is the user authorized to use POP? */
    if (checkauthfile(p->user) != 0)
	return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));
#endif

    /*  Look for the user in the password file */
    if ((pwp = getpwnam(p->user)) == NULL) {
#ifdef BBS
	if ((uinfo = bbsgetpwnam(p->user)) == NULL) {
#endif
	    return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));
#ifdef BBS
	}
	inbbs = 1;
#endif
    }

#ifdef BBS
    if (!inbbs) {
#endif BBS
    pw = *pwp;

    if (pw.pw_uid <= BLOCK_UID)
	return (pop_msg(p,POP_FAILURE, pwerrmsg, p->user));
    if (auth_user(p, pwp) != POP_SUCCESS) {
	sleep(10);
	return(POP_FAILURE);
    }
#ifdef BBS
    } else {
	if (auth_bbsuser(p, uinfo) != POP_SUCCESS) {
	    sleep(10);
	    return(POP_FAILURE);
	}
        pw.pw_uid = BBSUID;
	pw.pw_gid = BBSGID; 
    }
#endif 

    /*  Build the name of the user's maildrop */
#ifdef HOMEDIRMAIL
    (void)sprintf(p->drop_name, POP_MAILDIR, pw.pw_dir);
#else
#ifdef BBS
    if (inbbs) {
        sprintf(p->drop_name,"%s/%s/%s",POP_MAILDIR, "bbs", p->user);
#ifdef DEBUG
	printf("%s\n", p->drop_name);
	fflush(stdout);
#endif
    } else {
#endif
    (void)sprintf(p->drop_name,"%s/%s",POP_MAILDIR,p->user);
#ifdef BBS
    }
#endif BBS
#endif

    /*  Make a temporary copy of the user's maildrop */
    /*    and set the group and user id */
    /*    and get information about the maildrop */
    if (pop_dropcopy(p, &pw) != POP_SUCCESS) return (POP_FAILURE);

    /*  Initialize the last-message-accessed number */
    p->last_msg = 0;

    /*  Authorization completed successfully */
    return (pop_msg (p,POP_SUCCESS,
        "%s has %d message(s) (%d octets).",
            p->user,p->msg_count,p->drop_size));
}
