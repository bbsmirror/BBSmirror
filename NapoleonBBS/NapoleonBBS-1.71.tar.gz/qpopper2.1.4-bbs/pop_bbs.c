#include "pop_bbs.h"


report(shit)
char *shit;
{
  fprintf(stderr,"\n Err: %s\n",shit);
}

cmpuids(uid,up)
char *uid ;
struct userec *up ;
{
    if (!strncasecmp(uid, up->userid, sizeof(up->userid))) {
        strncpy( uid, up->userid, sizeof( up->userid ));
        return 1;
    } else {
        return 0;
    } 
}

int
dosearchuser(userid)
char *userid ;
{
    struct userec auser;
    return search_record(MYPASSFILE, &auser, sizeof(currentuser),
        cmpuids, userid) ;
}


get_pop( userid, poppath )
char *userid;
char *poppath;
{
	struct fileheader msg ;
	char fname[ 512 ], genbuf[ 256 ], nickname[128];
	struct stat st ;
	FILE *popfp, *dirfp, *tmpfp;
	int id,count;
	long time_int;
	time_t tmptime;
	int localhost;
	char *p;

/* get process time */
	time(&tmptime);
/* check if the userid is in our bbs now */
	if (!dosearchuser(userid)) return -1 ;

/* check for the mail dir for the userid */
	sprintf(genbuf, "%s/%s", MAILDIR, userid) ;

	if(stat(genbuf,&st) == -1) {
		if(mkdir(genbuf,0755) == -1) 
		  return -1 ;
	} else {	
		if(!(st.st_mode && S_IFDIR))
		  return -1 ;
	}
#ifdef DEBUG
        printf("Ok, dir is %s\n", genbuf );
#endif /* DEBUG */
/* check for the Pop mail file for the userid and delete it*/
	sprintf(genbuf, "%s/%s.bbs",poppath, userid);
	if(stat(genbuf,&st) != -1) {
		if( unlink(genbuf) == -1)
		  return -1;
	}

/* create Pop mail file */
	if((popfp= fopen(genbuf,"wb"))==NULL)
	{
		printf("Err... can't open file %s...\n",genbuf);
		return -1;
	}

/* Open .DIR file */
	sprintf(fname, "%s/%s/%s", MAILDIR,userid,DIR);
	if(stat(fname,&st)==-1)
	   return -1;
	
	if((dirfp=fopen(fname,"rb"))==NULL)
	   return -1;
	id=0;
    	while(fread(&msg,1,sizeof(msg),dirfp))
	{
	   id++;
	   localhost=0;
	   if( !(msg.accessed[0] & FILE_READ))
	   {

	    sscanf(msg.filename,"M.%d.A%s",&time_int,genbuf);
	    strcpy(genbuf,msg.owner);

	    if( (index(genbuf, '@')) == NULL )
	    {
		localhost=1;
		if( (p=index(genbuf,'(')) !=NULL)
	        {
		 strcpy(nickname,p);
	         p--;
		 p[0]=0;
		  strcat(genbuf, ".bbs@localhost");
	         }
	    }
	    else
	    {
		if( (p=index(genbuf,'(')) !=NULL)
		{
		  strcpy(nickname,p);
		  p--;
		  p[0]=0;
		 }
	    }
	    fprintf(popfp,"From %s %s",genbuf,ctime(&(time_t)time_int));
	    if(!localhost)
	      fprintf(popfp,"From: %s\n",genbuf);
	    else
	      fprintf(popfp,"From: %s %s\n",genbuf,nickname);
	    fprintf(popfp,"Subject: %s\n",msg.title);
	    fprintf(popfp,"To: %s.bbs@%s\n",HOSTNAME,userid);
	    fprintf(popfp,"X-Process: %s POP3 gateway %s\n",BBSNAME,ctime(&tmptime));
	    sprintf(genbuf,"%s//%s//%s",MAILDIR,userid,msg.filename);
	    if( (tmpfp=fopen(genbuf,"rb"))!=NULL )
	    {
		while(!feof(tmpfp))
		{
		   count=fread(genbuf,sizeof(char),256,tmpfp);
		   fwrite(genbuf,sizeof(char),count,popfp);
		}
		fclose(tmpfp);
	    }
	    msg.accessed[0] |= FILE_READ;
	    substitute_record(fname, &msg, sizeof(msg),id);	    
#ifdef DEBUG
printf("!!Find a unread mail [%s] from%s\n",msg.title,msg.owner);
printf("ID: %d, Filename: %s\n",id,msg.filename);
printf("From %s  %s\n",msg.owner,ctime( &(time_t) time_int));	    
#endif
	   }
	   else
	   {
#ifdef DEBUG
printf("??Find a readed mail [%s] from%s\n",msg.title,msg.owner);
printf("ID: %d, Filename: %s\n",id,msg.filename);
sscanf(msg.filename,"M.%d.A%s",&time_int,genbuf);
printf("From %s  %s\n",msg.owner,ctime( &(time_t) time_int));	    
#endif
	   }
	}

fclose(popfp);
fclose(dirfp);
}
