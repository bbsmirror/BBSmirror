/*
 * Copyright (c) 1989 Regents of the University of California.
 * All rights reserved.  The Berkeley software License Agreement
 * specifies the terms and conditions for redistribution.
 *
 * static char copyright[] = "Copyright (c) 1990 Regents of the University of California.\nAll rights reserved.\n";
 * static char SccsId[] = "@(#)@(#)version.h	2.6  2.6 4/3/91";
 *
 */

/*
 *  Current version of this POP implementation
 */

#ifdef KERBEROS
#define VERSION         "2.1.4-R3-krb-IV"
#else
#define VERSION         "2.1.4-R3"
#endif
