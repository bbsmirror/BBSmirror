#include <bbs.h>
#include <stdio.h>
#include <fcntl.h>

main(argc, argv)
char *argv[];
{
    struct userec uuu;
    int fd;

    fd = open(argv[1], O_RDONLY);

    while(1) {
        if (read( fd, &uuu, sizeof(uuu)) > 0) 
	    printf("%s %s %s\n", uuu.userid, uuu.realname, uuu.address);
	else 
	    exit(0);
    }
}
