#ifndef POP_BBS_H
#define POP_BBS_H

#include "bbs.h"

#define HOSTNAME	"dear.dorm8.nctu.edu.tw"
#define BBSNAME		"��j�u�u��"
#define MAILDIR 	"/home/bbs/mail"
#define MYPASSFILE	"/home/bbs/.PASSWDS"
#ifndef DIR
#define DIR	".DIR"
#endif

#endif /* POP_BBS_H */
