
#include <stdio.h>
#include "config.h"

static char     edit_name[35];
static char     flag;

char           *
Edit(void)
{
	extern char     Editor[35];

	char            command[80];

	umask(077);

	printf("\n���s�誺�ɮצW�� (�� [Enter] ���p���ɮצW��) : ");
	fflush(stdout);
	gets(edit_name);
	flag = 'N';
	if (edit_name[0] == '\0') {
		sprintf(edit_name, "/tmp/.bbs.edit.%d\000", getpid());
		flag = 'Y';
	}
	/* Edit */
	sprintf(command, "%s %s\000", Editor, edit_name);
	system(command);

	return (edit_name);
}

void
Delete(void)
{
	if (flag == 'Y')
		unlink(edit_name);
}
