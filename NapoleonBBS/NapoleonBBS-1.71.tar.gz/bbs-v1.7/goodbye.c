
#include <stdio.h>
#include <stdlib.h>

#include "config.h"

void
Welcome(void)
{

	char            buffer[80];
	int             i;
	extern FILE    *fp;
	printf("\033[37;1m\n" Header1 "\033[37;0m\n");

	i = 0;
	printf("\n");
	fseek(fp, 0L, SEEK_SET);
	while (fgets(buffer, Rec_Len, fp) != NULL) {
		buffer[strlen(buffer) - 1] = '\0';
		if ((buffer[0] == '*') && (!strncmp(&buffer[3], "Banner", 6)))
			printf("\033[32;1m%s\033[37;0m\n", &buffer[11]);
	}

	printf("\n");
	fclose(fp);
	exit(0);
}

void
Bye(void)
{
	alarm(0);
	clear();
	refresh();
	endwin();
	ansi_clear;
	Welcome();
}
