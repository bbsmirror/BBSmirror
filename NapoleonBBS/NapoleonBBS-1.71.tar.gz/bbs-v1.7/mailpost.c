
#include <stdio.h>
#include "config.h"

void
MailPost(char c)
{

	extern struct BBS bbs[BBS_Max];
	extern char     Mailer[35];

	FILE           *pfp, *mfp;
	char            buffer[80];

	char           *edit_name, *passwd;
	char            mail_name[30];

	printf("\033[1;4H");
	edit_name = Edit();

	sprintf(mail_name, "/tmp/.mail.post.%d\000", getpid());

	if ((mfp = fopen(mail_name, "w")) == NULL) {
		printf("�L�k�}���ɮ� %s. �{�����_..\n", mail_name);
		return;
	}
	ansi_clear;

	printf(" �`�N: �ϥ� Mail post �\\��e�Х��T�w %s BBS ���䴩 Mail Post ���\\��\n\n", bbs[c].name);

	printf("�п�J�z�b %s BBS ���b��\n\nUsername: \000", bbs[c].name);
	fflush(stdout);
	gets(buffer);
	fprintf(mfp, "#name: %s\n", buffer);

	passwd = NULL;

	do {
		if (passwd != NULL) {
			printf("\n�⦸��J���K�X���P, �Э��s��J");
			fflush(stdout);
		}
		passwd = (char *) getpass("\nPassword: ");
		strcpy(buffer, passwd);
		passwd = (char *) getpass("Password again: ");

	} while (strcmp(passwd, buffer));

	fprintf(mfp, "#password: %s\n", buffer);

	printf("\n\n�п�J�ұ� Post ���Q�װ�\n\nBoard: ");
	fflush(stdout);
	gets(buffer);
	fprintf(mfp, "#board: %s\n", buffer);

	printf("\n�п�J�峹�����D\n\nSubject: ");
	fflush(stdout);
	gets(buffer);
	fprintf(mfp, "#title: %s\n\n", buffer);

	if ((pfp = fopen(edit_name, "r")) == NULL) {
		printf("�L�k�}���ɮ� %s. �{�����_..\n", edit_name);
		fclose(mfp);
		return;
	}
	while (fgets(buffer, 90, pfp) != NULL)
		fputs(buffer, mfp);

	fclose(mfp);
	fclose(pfp);

	/* Mail post */
	if (!isdigit(bbs[c].hostname[0]))
		sprintf(buffer, "%s bbs@%s < %s\000", Mailer, bbs[c].hostname, mail_name);
	else
		sprintf(buffer, "%s bbs@[%s]. < %s\000", Mailer, bbs[c].hostname, mail_name);
	system(buffer);

	/* printf("\nE-Mail post to %s BBS\n", bbs[c].name); */

	unlink(mail_name);
	Delete();
}
