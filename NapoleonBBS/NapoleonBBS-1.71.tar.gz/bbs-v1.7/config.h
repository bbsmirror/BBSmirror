
/* BBS version 1.6            */
/* First version: Oct 1,1994  */

/* �򥻪�����T */
#define BBSver      "v1.7"
#define Patch       "0"
#define BBSdate     "Oct 03,1995"
#define BBSfirst    "Oct 01,1994"
#define BBSvers     BBSver" PL"Patch

/* �������ɳ]�w */
#define CFGFILE     "bbsdata-"BBSver
#define BBS_Max     52		/* �̤j�e�q */
#define Rec_Len     85		/* �C��̤j�r���� */
#define Header1     "bbs "BBSvers"   �� �����귽�s�u�{�� ��"
#define DEF_SYS_BBSDATA     "/usr/local/etc/"CFGFILE

/* default ����ɦ�m */
#if defined(NCTUCC)
#define BBSDATA    "/afs/cc.nctu.edu.tw/user0/ec/ie/u8117100/Bin/."CFGFILE
#elif defined(NCTUCSIE)
#define BBSDATA    "/u/cp/81/8117100/."CFGFILE
#elif defined(USERDEF)
#define BBSDATA    USERDEF
#endif

/* �ù��O�@��, Check mailbox �����j�ɶ�(����) */
#define MAILCHK     (2)

/* mail spool ��m */
#define BSD_MAILSPOOL  "/var/mail/"
#define SYSV_MAILSPOOL "/var/spool/mail/"
#define MAILBOX1     SYSV_MAILSPOOL
#define MAILBOX2     BSD_MAILSPOOL

#if defined(LINUX_ver)
#include <ncurses.h>
#elif defined(FreeBSD_ver)
#include <ncurses.h>
#elif defined(ULTRIX_ver)
#include <cursesX.h>
#else
#include <curses.h>
#endif


/* Host structure */

struct BBS {
	char            name[18];	/* ��� */
	char            alias[20];	/* ���W */
	char            hostname[60];	/* ��} */
	int             port;	/* port */
};

#define Host_TEL	(char)0	/* ��� telnet */
#define Host_BBS	(char)1	/* �i�@ Mailpost/Mail-to-user  */
#define Host_GOPHER	(char)2	/* �|�յۥH Gopher Client �s�u */
#define Host_MUD	(char)3	/* ��� telnet */
#define Host_LIB	(char)4	/* ��� telnet */
#define Host_WWW	(char)5	/* �H Browser �s�W */
#define Host_FTP	(char)6	/* �H FTP client �s�W */

#define ansi_clear printf("\033[2J\033[1;1H")
#define ansi_print(attr,text) printf("\033["attr"m%s\033[37;0m", text)
#define ansi_print_xy(x,y,attr,text) printf("\033[%d;%dH\033["attr"m%s\033[37;40;0m",x + 1, y + 1, text)
#define ansi_print_xy_n(x,y,attr,text,n) printf("\033[%d;%dH\033[%sm%"n"s\033[37;0m",x + 1, y + 1, color,text)

extern void     Welcome(void);
extern void     Bye(void);
extern void     Clock(int);
extern void     PutTitle(int, int);
extern void     HelpBar(char *, char *);
extern void     Menu(void);
extern void     DrawBox1(int, int, int, int);
extern void     DrawBox2(int, int, int, int);
extern void     MailPost(char);
extern void     Mail2user(char);
extern void     Mail2author(void);
extern void     Help(void);
extern char    *Edit(void);
extern void     Delete(void);
extern int      read_section(long);
extern void     MainMenu(int, int);
extern void     Saver(void);
