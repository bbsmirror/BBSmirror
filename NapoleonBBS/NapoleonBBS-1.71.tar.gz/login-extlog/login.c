

#ifndef lint
char copyright[] =
"@(#) Copyright (c) 1980, 1987, 1988 The Regents of the University of California.\n\
 All rights reserved.\n";
#endif 

#ifndef lint
static char sccsid[] = "@(#)login.c	5.40 (Berkeley) 5/9/89";
#endif 
#define index strchr
#define rindex strrchr

#include <sys/param.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/file.h>

#include <err.h>
#include <errno.h>
#include <grp.h>
#include <pwd.h>
#include <setjmp.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <ttyent.h>
#include <unistd.h>
#include <utmp.h>

#ifdef	SKEY
#include <skey.h>
#endif

#include "pathnames.h"



#define P_(s) ()
void opentty P_((const char *tty));
char *stypeof P_((char *ttyid));
#undef P_(s) ()


#define TTYGRPNAME      "other"
#  ifndef MAXPATHLEN
#    define MAXPATHLEN 1024
#endif


struct	passwd *pwd;
char	term[64], *hostname, *username, *tty;





void 
opentty(const char * tty)
{
    int i;
    int fd = open(tty, O_RDWR);

    for (i = 0 ; i < fd ; i++)
      close(i);
    for (i = 0 ; i < 3 ; i++)
      dup2(fd, i);
    if (fd >= 3)
      close(fd);
}

int
main(argc, argv)
int argc;
char **argv;
{
	extern int errno, optind;
	extern char *optarg, **environ;
	struct timeval tp;
	struct tm *ttp;
	struct group *gr;
	register int ch;
	register char *p;
	int ask, fflag, hflag, pflag, cnt;
	int quietlog, passwd_req, ioctlval;
	char *domain, *salt, *ttyn, *pp;
	char tbuf[MAXPATHLEN + 2], tname[sizeof(_PATH_TTY) + 10];
	char *ctime(), *ttyname(), *stypeof();
	time_t time();
	char *termenv;

	char tmp[100];

	(void)signal(SIGQUIT, SIG_IGN);
	(void)signal(SIGINT, SIG_IGN);

	(void)setpriority(PRIO_PROCESS, 0, 0);


        
	fflag = hflag = pflag = 0;
	passwd_req = 1;
	while ((ch = getopt(argc, argv, "fh:p")) != EOF)
		switch (ch) {
		case 'h':
			if (getuid()) {
				(void)fprintf(stderr,
				    "login: -h for super-user only.\n");
				exit(1);
			}
			hflag = 1;
			hostname = optarg;
			break;

		case 'p':
			pflag = 1;
			break;
		case '?':
		default:
			(void)fprintf(stderr,
			    "usage: login [-fp] [username]\n");
			exit(1);
		}
	argc -= optind;
	argv += optind;
	if (*argv) {
		username = *argv;
		ask = 0;
	} else
		ask = 1;


	for (cnt = getdtablesize(); cnt > 2; cnt--)
		close(cnt);

	ttyn = ttyname(0);
	if (ttyn == NULL || *ttyn == '\0') {
		(void)sprintf(tname, "%s??", _PATH_TTY);
		ttyn = tname;
	}

	    setsid();

	    opentty(ttyn);

	if (tty = rindex(ttyn, '/'))
		++tty;
	else
		tty = ttyn;


	for (cnt = 0;; ask = 1) {
		ioctlval = 0;

		if (ask) {
			fflag = 0;
		}

		(void)strcpy(tbuf, username);
		if (pwd = getpwnam(username))
			salt = pwd->pw_passwd;
		else
			salt = "xx";

		if (fflag && pwd) {
			int uid = getuid();

			passwd_req = pwd->pw_uid == 0 ||
			    (uid && uid != pwd->pw_uid);
		}

                if (!passwd_req || (pwd && !*pwd->pw_passwd))
			break;

		setpriority(PRIO_PROCESS, 0, -4);
	}

	(void)alarm((unsigned int)0);

	endpwent();
	{
	    char tmpstr[MAXPATHLEN];
	    uid_t ruid = getuid();
	    gid_t egid = getegid();

	    strncpy(tmpstr, pwd->pw_dir, MAXPATHLEN-12);

	    setregid(-1, pwd->pw_gid);
	    setreuid(0, pwd->pw_uid);
	    quietlog = (access(tmpstr, R_OK) == 0);
	    setuid(0); 
	    setreuid(ruid, 0);
	    setregid(-1, egid);
	}

	
	(void)chown(ttyn, pwd->pw_uid,
	    (gr = getgrnam(TTYGRPNAME)) ? gr->gr_gid : pwd->pw_gid);

	(void)chmod(ttyn,0622);
	(void)setgid(pwd->pw_gid);

	initgroups(username, pwd->pw_gid);


        (void)setenv("HOME", pwd->pw_dir, 0);      /* legal to override */
        if(pwd->pw_uid)
          (void)setenv("PATH", _PATH_DEFPATH, 1);


	(void)setenv("LOGNAME", pwd->pw_name, 1);

	(void)signal(SIGALRM, SIG_DFL);
	(void)signal(SIGQUIT, SIG_DFL);
	(void)signal(SIGINT, SIG_DFL);
	(void)signal(SIGTSTP, SIG_IGN);
	(void)signal(SIGHUP, SIG_DFL);

	tbuf[0] = '-';
	strcpy(tbuf + 1, (p = rindex(pwd->pw_shell, '/')) ?
	    p + 1 : pwd->pw_shell);

	if(setuid(pwd->pw_uid) < 0 && pwd->pw_uid) {
	    syslog(LOG_ALERT, "setuid() failed");
	    exit(1);
	}

	if (chdir(pwd->pw_dir) < 0) {
		(void)printf("No directory %s!\n", pwd->pw_dir);
		if (chdir("/"))
			exit(0);
		pwd->pw_dir = "/";
		(void)printf("Logging in with home = \"/\".\n");
	}

        bbsrf(ttyn,hostname,pwd->pw_dir);
	(void)fprintf(stderr, "login: no shell: %s.\n", strerror(errno));
	exit(0);
}


/*
 *   from  bbsrf.c
 */






int
bbsrf(ttyn, host, bbshome)
char	*ttyn;
char	*host;
char	*bbshome;
{

    char	bbs_prog_path[ 256 ];
    double	cpu_load[ 3 ];
    


        sprintf( bbs_prog_path, "%s/bin/bbs",bbshome );


        execl( bbs_prog_path,"bbs","h", host, ttyn, NULL) ;

        printf("execl failed\n") ;
        exit( -1 );

}


