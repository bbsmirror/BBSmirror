#include <stdio.h>
#include "bbs.h"
main()
{
 struct boardheader newboard ;
 int fd, fd2 ;
 int size;
 char *p;
 char buf[100];

        if((fd = open(".BOARDS",O_RDONLY,0)) == -1)
          return 0 ;
        size=sizeof(newboard);

        if((fd2 = open("NEW",O_WRONLY|O_CREAT,0644)) == -1)
          return -1 ;

        while(read(fd,&newboard,size) == size) {
           p=newboard.title+3;
           if (!strncmp(newboard.title,"�� ",3)) {
                strcpy(buf,"[�޲z] ");
                strcat(buf,p);
		strcpy(newboard.title,buf);
        	write(fd2,&newboard,size); 
		puts(newboard.title);
                continue;
           } 
           if (!strncmp(newboard.title,"�� ",3)) {
                strcpy(buf,"[����] ");
                strcat(buf,p);
		strcpy(newboard.title,buf);
        	write(fd2,&newboard,size); 
		puts(newboard.title);
                continue;
           } 
           if (!strncmp(newboard.title,"�� ",3)) {
                strcpy(buf,"[�j�P] ");
                strcat(buf,p);
		strcpy(newboard.title,buf);
        	write(fd2,&newboard,size); 
		puts(newboard.title);
                continue;
           } 
           if (!strncmp(newboard.title,"�� ",3)) {
                strcpy(buf,"[�q��] ");
                strcat(buf,p);
		strcpy(newboard.title,buf);
        	write(fd2,&newboard,size); 
		puts(newboard.title);
                continue;
           } 
           if (!strncmp(newboard.title,"�� ",3)) {
                strcpy(buf,"[���] ");
                strcat(buf,p);
		strcpy(newboard.title,buf);
        	write(fd2,&newboard,size); 
		puts(newboard.title);
                continue;
           } 
           if (!strncmp(newboard.title,"�� ",3)) {
                strcpy(buf,"[����] ");
                strcat(buf,p);
		strcpy(newboard.title,buf);
        	write(fd2,&newboard,size); 
		puts(newboard.title);
                continue;
           } 
           if (!strncmp(newboard.title,"�� ",3)) {
                strcpy(buf,"[��] ");
                strcat(buf,p);
		strcpy(newboard.title,buf);
        	write(fd2,&newboard,size); 
		puts(newboard.title);
                continue;
           } 
           if (!strncmp(newboard.title,"�� ",3)) {
                strcpy(buf,"[�ǳN] ");
                strcat(buf,p);
		strcpy(newboard.title,buf);
        	write(fd2,&newboard,size); 
		puts(newboard.title);
                continue;
           } 
           if (!strncmp(newboard.title,"�� ",3)) {
                strcpy(buf,"[���|] ");
                strcat(buf,p);
		strcpy(newboard.title,buf);
        	write(fd2,&newboard,size); 
		puts(newboard.title);
                continue;
           } 
           if (!strncmp(newboard.title,"�� ",3)) {
                strcpy(buf,"[�B��] ");
                strcat(buf,p);
		strcpy(newboard.title,buf);
        	write(fd2,&newboard,size); 
		puts(newboard.title);
                continue;
           } 
           if (!strncmp(newboard.title,"�� ",3)) {
                strcpy(buf,"[���] ");
                strcat(buf,p);
		strcpy(newboard.title,buf);
        	write(fd2,&newboard,size); 
		puts(newboard.title);
                continue;
           } 
           if (!strncmp(newboard.title,"�� ",3)) {
                strcpy(buf,"[��L] ");
                strcat(buf,p);
		strcpy(newboard.title,buf);
        	write(fd2,&newboard,size); 
		puts(newboard.title);
                continue;
           } 
           if (!strncmp(newboard.title,"��  ",3)) {
                strcpy(buf,"[�p��] ");
                strcat(buf,p);
		strcpy(newboard.title,buf);
        	write(fd2,&newboard,size); 
		puts(newboard.title);
                continue;
           } 
        }
	close(fd2);
        close(fd) ;
}
