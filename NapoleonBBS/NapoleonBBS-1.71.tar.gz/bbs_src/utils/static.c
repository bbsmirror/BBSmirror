#include <stdio.h>
#define USIES "var/usies"

struct {
	int             no[24];	/* ���� */
	int             sum[24];/* �`�X */
}               st;

char            month[12][4] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct",
"Nov", "Dec"};

main(argc, argv)
	char           *argv[];
{
	char           *progmode;
	char           *homepath, *outpath;
	FILE           *fp;
	char            buf[128], buf2[120];
	char           *mon, *day, *year;
	int             hour, max = 0, item, total = 0;
	int             totaltime = 0;
	int             i, j;

	if (argc < 3) {
		printf(" usage %s :\n   %s bbshome output\n\n", argv[0], argv[0]);
		return;
	}
	homepath = argv[1];
	outpath = argv[2];

	chdir(homepath);
	if ((fp = fopen(USIES, "r")) == NULL) {
		printf("cann't open usies\n");
		return 0;
	}
	printf("open success\n");

	while (fgets(buf, 128, fp) != NULL) {
		if (strlen(buf) <= 40)
			continue;
		if (buf[3] != ' ' || buf[6] != ' ' || buf[15] != ' ')
			continue;
		mon = (char *) strtok(buf, " ");
		printf("%s  ", mon);
		day = (char *) strtok(NULL, " ");
		printf("%s  ", day);
		hour = atoi(strtok(NULL, " :"));
		strtok(NULL, " ");
		year = (char *) strtok(NULL, " ");
		printf("%s  ", year);
		if (!strcmp((char *) strtok(NULL, " "), "ENTER")) {
			st.no[hour]++;
			printf("Enter\n");
			continue;
		}
		strtok(NULL, " ");
		printf("Userid  ");
		if (!strcmp((char *) strtok(NULL, " "), "Stay:")) {
			st.sum[hour] += atoi(strtok(NULL, " "));
			printf("Stay\n");
			continue;
		}
	}
	fclose(fp);

	for (i = 0; i < 23; i++) {
		total += st.no[i];
		totaltime += st.sum[i];
		if (st.no[i] > max)
			max = st.no[i];
	}

	item = max / 15;
	item++;

	for (i = 0; i < 12; i++) {
		if (!strcmp(mon, month[i]))
			break;
	}
	printf("write to output file\n");
	chdir(outpath);
	if ((fp = fopen("var/countusr", "w")) == NULL) {
		printf("cann't open countusr\n");
		return 0;
	}
	sprintf(buf2, "         [1;31m------[37m======[44m [35m%2d [37m�� [35m%s [37m�� �C�p�ɤW���H�Ʋέp [40m======[31m------             \n\n", i + 1, day);
	fputs(buf2, fp);
	for (i = 16; i > 0; i--) {
		fprintf(fp, "   [31m");
		for (j = 0; j < 24; j++) {
			if ((item * i > st.no[j]) && (item * (i - 1) <= st.no[j]) && st.no[j] != 0) {
				fprintf(fp, "[33m%-3d[31m", st.no[j]);
				continue;
			}
			if (item * i <= st.no[j])
				fprintf(fp, "�i ");
			else
				fprintf(fp, "   ");
		}
		fprintf(fp, "\n");
	}
	fprintf(fp, "   [32m0  1  2  3  4  5  6  7  8  9  10 11 12 13 14 15 16 17 18 19 20 21 22 23\n");
	fprintf(fp, "\n       [34m�`�@�W���H�� :[37m%5d      [34m�����ϥήɶ� :[37m%5d"
		,total, totaltime / total + 1);
	fprintf(fp, "[37;40;0m");
	fclose(fp);
	printf("%d, %d\n", st.no[15], item);
}
