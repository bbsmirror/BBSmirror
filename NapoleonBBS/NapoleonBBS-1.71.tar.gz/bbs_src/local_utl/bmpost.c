#include <stdio.h>
#define BBSHOME		"/home/bbs"
#define BBSGID		99
#define BBSUID		9999


int
bm2bbs(bbsuid,fin)
char	*bbsuid;
FILE	*fin;
{
	char	genbuf[ 256 ] ;
	FILE	*fout;

/* allocate a record for the new mail */
	sprintf(genbuf, "%s/tmp/bm.%s",BBSHOME, bbsuid) ;
        printf("Ok, the file is %s\n", genbuf );

/* copy the stdin to the specified file */
        if ( (fout = fopen( genbuf, "a+" )) == NULL) {
            printf("Cannot open %s \n", genbuf );
            return -1;
        } else {

            while (fgets( genbuf, 255, fin ) != NULL) {
                fputs( genbuf, fout );
            }
            fclose( fout );
        }
       return 0;    



}


main(argc,argv)
int	argc;
char	*argv[];
{
 
  char genbuf[256],receiver[256];
   
     

  setreuid( BBSUID, BBSUID );
  setregid( BBSGID, BBSGID );

  if (argc < 2) {
    printf("Usage:\t%s <bm_name> \n", argv[0]);
    exit(-1);
  }

  while (fgets(genbuf, 255, stdin)) {
    if (genbuf[0] == '\n')
        break;
  }

  strcpy(receiver, argv[1]);

  if (bm2bbs(receiver,stdin)){
    while (fgets(receiver, sizeof(receiver), stdin));
  }

  exit(0);

}








