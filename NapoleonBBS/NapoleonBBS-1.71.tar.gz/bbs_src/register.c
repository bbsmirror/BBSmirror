/*
 * register.c
 */



#include "bbs.h"

#define  EMAIL		0x0001 
#define  NICK		0x0002 
#define  REALNAME	0x0004 
#define  ADDR		0x0008
#define  REALEMAIL	0x0010
#define  BADEMAIL	0x0020
#define  NEWREG		0x0040


char	*genpasswd();


time_t		system_time;

int
bad_user_id( userid )
char	*userid;
{
    FILE	*fp;
    char	buf[STRLEN];
    char	*ptr, ch;

    ptr = userid;
    while( (ch = *ptr++) != '\0' ) {
	if( !isalnum( ch ) && ch != '_' )
            return 1;
    }
    if( (fp = fopen( ".badname", "r" )) != NULL ) {
	while( fgets( buf, STRLEN, fp ) != NULL ) {
	    ptr = strtok( buf, " \n\t\r" );
	    if( ptr != NULL && *ptr != '#' && strcmp( ptr, userid ) == 0 ) {
		fclose( fp );
		return 1;
	    }
	}
	fclose(fp);
    }
    return 0;
}



int 
compute_user_value( urec )
struct userec *urec;
{
    int 	value;

      
    /* if (urec) has XEMPT permission, don't kick it */
    if( urec->userlevel & PERM_XEMPT )
	return 9999;
    value = (system_time - urec->lastlogin) / 60;    /* min */
	/* new user should register in 30 mins */
    if( strcmp( urec->userid, "new" ) == 0 ) {
	return (30 - value) * 60;
    }
    if( urec->numlogins <= 3 )
	return 15 * 24 * 60 - value;
    if( !(urec->userlevel & PERM_LOGINOK) )
	return 30 * 24 * 60 - value;
    return 120 * 24 * 60;
}



int
getnewuserid()
{
    struct userec utmp, zerorec;
    struct stat	st;
    int		fd, size, val, i;
    extern char	fromhost[ 60 ];

    system_time = time( NULL );
    if( stat( "tmp/killuser", &st )== -1 || st.st_mtime < system_time-3600 ) {
	if( (fd = open( "tmp/killuser", O_RDWR|O_CREAT, 0600 )) == -1 )
	    return -1;
	write( fd, ctime( &system_time ), 25 );
	close( fd );
	log_usies( "CLEAN", "dated users." );
	printf( "�M��s�b����, �еy�ݤ���...\n\r" );
	memset( &zerorec, 0, sizeof( zerorec ) );
	if( (fd = open( PASSFILE, O_RDWR|O_CREAT, 0600 )) == -1 )
	    return -1;
	size = sizeof( utmp );
	for( i = 0; i < MAXUSERS; i++ ) {
	    if( read( fd, &utmp, size ) != size )
		break;
	    val = compute_user_value( &utmp );
	    if( utmp.userid[0] != '\0' && val < 0 ) {
		sprintf( genbuf, "#%d %-12s %15.15s %d %d %d",
			i+1, utmp.userid, ctime( &(utmp.lastlogin) )+4,
			utmp.numlogins, utmp.numposts, val );
		log_usies( "KILL ", genbuf );
		if( !bad_user_id( utmp.userid ) ) {
		    sprintf( genbuf, "/bin/rm -fr mail/%s", utmp.userid );
		    system( genbuf );
		    sprintf( genbuf, "/bin/rm -fr home/%s", utmp.userid );
		    system( genbuf );
		    sprintf(genbuf,"tmp/regmail_%s",utmp.userid);
		    if(dashf(genbuf))unlink(genbuf);
		}
		lseek( fd, (off_t)-size, SEEK_CUR );
		write( fd, &zerorec, sizeof( utmp ) );
	    }
	}
	close( fd );
	touchnew();
    }
    if( (fd = open( PASSFILE, O_RDWR|O_CREAT, 0600 )) == -1 )
	return -1;
    flock( fd, LOCK_EX );

    i = searchnewuser();
    sprintf( genbuf, "uid %d from %s", i, fromhost );
    log_usies( "APPLY", genbuf );

    if( i <= 0 || i > MAXUSERS ) {
	flock(fd,LOCK_UN) ;
	close(fd) ;
	if( dashf( "etc/user_full" ) ) {
	    ansimore( "etc/user_full", NA );
	    oflush();
	} else {
	    printf( "��p, �ϥΪ̱b���w�g���F, �L�k���U�s���b��.\n\r" );
	}
	val = (st.st_mtime - system_time + 3660) / 60;
	printf( "�е��� %d ������A�դ@��, ���A�n�B.\n\r", val );
	sleep( 2 );
	exit( 1 );
    }
    memset( &utmp, 0, sizeof( utmp ) );
    strcpy( utmp.userid, "new" );
    utmp.lastlogin = time( NULL );
    if( lseek( fd, (off_t)sizeof(utmp) * (i-1), SEEK_SET ) == -1 ) {
	flock( fd, LOCK_UN );
	close( fd );
	return -1;
    }
    write( fd, &utmp, sizeof(utmp) );
    setuserid( i, utmp.userid );
    flock( fd, LOCK_UN );
    close( fd );
    return i;
}



void
new_register()
{
    struct userec	newuser;
    struct tbyconfig    *selfconf;
    char	passbuf[ STRLEN ];
    int		allocid, try;
    FILE        *confp;
    char        *tby;

    if( 1 ) {
	time_t  now;

	now = time( 0 );
	sprintf( genbuf, "etc/no_register_%3.3s", ctime( &now ) );
	if( dashf( genbuf ) ) {
	    ansimore( genbuf, NA );
	    pressreturn();
	    exit( 1 );
	}
    }
    memset( &newuser, 0, sizeof(newuser) );
    allocid = getnewuserid()  ;
    if(allocid > MAXUSERS || allocid <= 0) {
	printf("No space for new users on the system!\n\r") ;
	exit(1) ;
    }

    ansimore("etc/register", NA);
    try = 0;
    while( 1 ) {
	if( ++try >= 10 ) {
	    prints("\nBye Bye, 10 <Enter> makes you leave.\n");
	    refresh();
	    longjmp( byebye, -1 );
	}
	getdata(0,0,"�п�J�N��: ",newuser.userid,IDLEN+1,DOECHO,NULL) ;

        if ( (*newuser.userid == '\0') || bad_user_id( newuser.userid ) ) {
	    prints( "�L�k�����o�ӥN���A�Шϥέ^��r���A�åB���n�]�t�Ů�.\n" );
	} else if( dosearchuser( newuser.userid ) ) { 
            prints("���N���w�g���H�ϥ�\n") ;
        } else {
	    break;
	}
    }

    while( 1 ) {
	getdata(0,0,"�г]�w�z���K�X: ",passbuf,PASSLEN,NOECHO,NULL) ;
	if( strlen( passbuf ) < 4 || !strcmp( passbuf, newuser.userid ) ) {
            prints("�K�X�ӵu�λP�ϥΪ̥N���ۦP, �Э��s��J\n") ;
	    continue;
	}
	strncpy( newuser.passwd, passbuf, PASSLEN );
	getdata(0,0,"�ЦA��J�@���A���K�X: ",passbuf,PASSLEN,NOECHO,NULL);
	if( strncmp( passbuf, newuser.passwd, PASSLEN ) != 0 ) {
	    prints("�K�X��J���~, �Э��s��J�K�X.\n") ;
	    continue;
        }
	passbuf[8] = '\0' ;
	strncpy( newuser.passwd, genpasswd( passbuf ), PASSLEN );
	break;
    }
    getdata(0,0,"�п�J�׺ݾ��κA: [vt100] ",newuser.termtype,16,DOECHO,NULL);
    if( newuser.termtype[0] == '\0' ) {
	strcpy(newuser.termtype, "vt100");
    }
    getdata(0,0,"�O�_�ϥ� ANSI ? (Y/N) [Y]: ",genbuf,2,DOECHO,NULL);
    if ( !(genbuf[0] == 'n' || genbuf[0] == 'N') ) 
          newuser.address[STRLEN-9]=iscolor=1;
    else  newuser.address[STRLEN-9]=iscolor=0;
    
    newuser.userlevel = PERM_DEFAULT;
    newuser.flags[0] = CURSOR_FLAG;
    newuser.flags[1] = 1;
    newuser.firstlogin = newuser.lastlogin = time(NULL) ;

    if( substitute_record(PASSFILE,&newuser,sizeof(newuser),allocid) == -1 ) {
	fprintf(stderr,"too much, good bye!\n") ;
	exit(1) ;
    }
    setuserid( allocid, newuser.userid );
    if( !dosearchuser(newuser.userid) ) {
	fprintf(stderr,"User failed to create\n") ;
	exit(1) ;
    }
    report( "new account" );
}



char *
trim( s )
char *s;
{
    static char buf[ 256 ];
    char *l, *r;

    buf[ 0 ] = '\0' ;
    r = s + strlen( s ) - 1;

    for (l = s ; strchr(" \t\r\n", *l) && *l; l++);

    /* if all space, *l is null here, we just return null */
    if (*l != '\0') {   
        for ( ; strchr(" \t\r\n", *r) && r >= l ; r-- );
        strncpy( buf, l, r - l + 1 );
    }
    return buf;
}



int
invalid_realmail( userid, email, msize )
char	*userid, *email;
int	msize;
{
    FILE	*fn;
    char	*emailfile, ans[2];
    int		now;
    char	*Ctime();
    char	*sysconf_str();

    if( (emailfile = sysconf_str( "EMAILFILE" )) == NULL )
	return 0;
    if(  strchr( email, '@' ) && valid_ident( email ) )
	return 0;

 	sprintf( genbuf, "tmp/regmail_%s", userid );
	if( (fn = fopen( genbuf, "r" )) != NULL ) {
	    fgets( genbuf, STRLEN, fn );
	    fclose( fn );
	    strtok( genbuf, "\n" );
	    if( !valid_ident( genbuf ) ){
		move( t_lines-2, 0 );
		clrtoeol();
		prints( "���~��} %s, �Э��s��g e-mail address", genbuf );
		pressanykey();
	    } else if( strchr( genbuf, '@' ) != NULL ) {
	        FILE	*fd;
	        
		strncpy( email, genbuf, msize );
		move( t_lines-1, 0 );
		prints( "�w����z�� email, �w��[�J����." );
		if((fd=fopen("var/register.list","a+"))!=NULL){
		 fprintf(fd,"'%s' register from '%s'\n",currentuser.userid,email);
		 fclose(fd);
		 }
		return 0;
	    }
	}
    ansimore( emailfile, YEA );	
    if(valid_ident(currentuser.email )){
      move(t_lines-2,0);
      prints("�z�� E-mail address �� %s",currentuser.email);
      getdata(t_lines-1,0,"�Ѩt�ΰe�X�����T�{�H�� (Y/N) [Y] ",ans,2,DOECHO,NULL);
      if ( *ans != 'n' && *ans !='N') {
          time_t	regtime;
          char		title[STRLEN];
          FILE		*dp;

          regtime=time(NULL);
          sprintf(genbuf,"home/%s/mailcheck",currentuser.userid);
          if((dp=fopen(genbuf,"w"))==NULL) {
                fclose(dp);
                return;
           }
           fprintf(dp,"%d\n",regtime);
           fclose(dp);          
          sprintf(title,"[%d] NCTUIEM bbsuser checkmail",regtime);
          bbsreg_sendmail("etc/bbsregister",title,currentuser.email); 
       }
    }  

    return 1;
}


void
check_register_info()
{
    struct userec *urec = &currentuser;
    char	*newregfile;
    int		perm;
    char	*sysconf_str();    

    clear();
    if( !(urec->userlevel & PERM_BASIC) ) {
	urec->userlevel = 0;
	return;
    }
    urec->userlevel |= PERM_DEFAULT;
#ifdef NAPOLEON
    if((strstr(urec->termtype+16,"u84330")||strstr(urec->termtype+16,"u83330")||
           strstr(urec->termtype+16,"u82330")||strstr(urec->termtype+16,"u81330")) &&
            strstr(urec->termtype+16,"@cc.nctu.edu.tw"))
     urec->userlevel |= PERM_UNUSE1;          
#endif           

    perm = PERM_DEFAULT & sysconf_eval( "AUTOSET_PERM" );

    if( sysconf_str( "IDENTFILE" ) != NULL ) {
	while( strlen( urec->username ) < 2 ) {
	    move( 1, 0 );
	    prints( "�п�J�z���ʺ�:\n" );
	    getdata( 2, 0, "> ", urec->username, NAMELEN,DOECHO,NULL );
	}
	while( strlen( urec->realname ) < 3 ) {
	    move( 3, 0 );
	    prints( "�п�J�z���u��m�W:\n" );
	    getdata( 4, 0, "> ", urec->realname, NAMELEN,DOECHO,NULL );
	}
	while( strlen( urec->address ) < 10 ) {
	    move( 5, 0 );
	    prints( "�п�J������}���:\n" );
	    getdata( 6, 0, "> ", urec->address, NAMELEN,DOECHO,NULL );
	}
	while( strchr( urec->email, '@' ) == NULL ) {
	    move( 7, 0 );
	    prints( "�п�J�q�l�H�c: ");
	    getdata( 8, 0, "> ", urec->email, STRLEN,DOECHO,NULL );
            move(t_lines-5,0);
	    prints("�аȥ���J�z�� E-mail address,�t�αN�H�X�����T�{�H,\n�L�b���̽п�J %s.bbs@%s\n",urec->userid, email_domain());
	}

    }

    if( !HAS_PERM( PERM_SYSOP ) &&
	invalid_realmail( urec->userid, urec->termtype+16, STRLEN-16 ) ) {
	urec->userlevel &= ~(perm);
    }

    newregfile = sysconf_str( "NEWREGFILE" );
    if( urec->lastlogin - urec->firstlogin < 3*86400 &&
	!HAS_PERM( PERM_SYSOP) && newregfile != NULL ) {
	urec->userlevel &= ~(perm);
	ansimore( newregfile, YEA );
    }

    if (!HAS_PERM(PERM_CLOAK))
            uinfo.invisible = 0;

    if( HAS_PERM( PERM_DENYPOST ) && !HAS_PERM( PERM_SYSOP ) )
        currentuser.userlevel &= ~PERM_POST;
}

#include <sys/param.h>
#include <sys/resource.h>
#include <pwd.h>


char	*crypt() ;


char *
genpasswd(pw)
char *pw ;
{
    char saltc[2] ;
    long salt ;
    int i,c ;
    static char pwbuf[14] ;

    if(strlen(pw) == 0)
        return "" ;
    salt = 9 * getpid() ;
#ifndef lint
    saltc[0] = salt & 077 ;
    saltc[1] = (salt>>6) & 077 ;
#endif
    for(i=0;i<2;i++) {
        c = saltc[i] + '.' ;
        if(c > '9')
          c += 7 ;
        if(c > 'Z')
          c += 6 ;
        saltc[i] = c ;
    }
    strcpy(pwbuf, pw) ;
    return crypt(pwbuf, saltc) ;
}



int
checkpasswd(passwd, test)
char *passwd, *test ;
{
    static char pwbuf[14] ;
    char *pw ;

    strncpy(pwbuf,test,14) ;
    pw = crypt(pwbuf, passwd) ;
    return (!strcmp(pw, passwd)) ;
}

