
#define	BBSUID	9999
#define	BBSGID	99
#define	BBSHOME	"/home/bbs"

#define index strchr
#define rindex strrchr

#include <sys/param.h>
#include <sys/stat.h>
#include <sys/resource.h>
#include <sys/file.h>

#include <grp.h>
#include <setjmp.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <ttyent.h>
#include <unistd.h>


#include "pathnames.h"


#define TTYGRPNAME      "other"
#  ifndef MAXPATHLEN
#    define MAXPATHLEN 1024
#endif


char	term[64], *tty;
int
xlogin(username, hostname)
char *username, *hostname;
{
	extern int errno;
	register int ch;
	register char *p;
	int quietlog, i;
    	int fd = open(tty, O_RDWR);	
	char *ttyn;
	char tname[sizeof(_PATH_TTY) + 10];
	char *ctime(), *ttyname(), *stypeof();
	time_t time();


	char tmp[100];

	(void)signal(SIGQUIT, SIG_IGN);
	(void)signal(SIGINT, SIG_IGN);
	(void)setpriority(PRIO_PROCESS, 0, -4);



	ttyn = ttyname(0);
	if (ttyn == NULL || *ttyn == '\0') {
		(void)sprintf(tname, "%s??", _PATH_TTY);
		ttyn = tname;
	}

	setsid();
/* search tty*/
	for (i = 0 ; i < fd ; i++)
      		close(i);
    	for (i = 0 ; i < 3 ; i++)
      		dup2(fd, i);
    	if (fd >= 3)
      		close(fd);

	if (tty = rindex(ttyn, '/'))
		++tty;
	else
		tty = ttyn;

	(void)setpriority(PRIO_PROCESS, 0, 0);
	(void)alarm((unsigned int)0);

	(void)chown(ttyn, BBSUID, BBSGID);

	(void)chmod(ttyn,0622);

	(void)setgid(BBSGID);

        (void)setenv("HOME", BBSHOME, 0);      /* legal to override */
	(void)setenv("LOGNAME", username, 1);

	(void)signal(SIGALRM, SIG_DFL);
	(void)signal(SIGQUIT, SIG_DFL);
	(void)signal(SIGINT, SIG_DFL);
	(void)signal(SIGTSTP, SIG_IGN);
	(void)signal(SIGHUP, SIG_DFL);


	if(setuid(BBSUID) < 0 ) {
	    syslog(LOG_ALERT, "setuid() failed");
	    exit(1);
	}

	if (chdir(BBSHOME) < 0) {
		(void)printf("No directory %s!\n", BBSHOME);
		if (chdir("/"))
			exit(0);
	}

        bbsrf(ttyn,hostname,BBSHOME);
	(void)fprintf(stderr, "login: no shell\n");
	exit(0);
}


/*
 *   from  bbsrf.c
 */



int
bbsrf(ttyn, host, bbsdir)
char	*ttyn;
char	*host;
char	*bbsdir;
{
    char	bbs_prog_path[ 256 ];
    extern double	cpu_load[ 3 ];
    extern int	loadlimit;   


    printf("BBS �̪� (1,10,15) �����������t�����O�� %.2f, %.2f, %.2f (�ثe�W�� = %d)\n\n", 
			cpu_load[ 0 ], cpu_load[ 1 ], cpu_load[ 2 ] ,loadlimit);
    sprintf( bbs_prog_path, "%s/bin/bbs",bbsdir );

    execl( bbs_prog_path,"bbs","h", host, ttyn, NULL) ;

    printf("execl failed\n") ;
    exit( -1 );

}


