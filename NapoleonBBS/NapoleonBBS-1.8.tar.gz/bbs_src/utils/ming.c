#include <sys/types.h>
#include <dirent.h>
#include <fcntl.h>
#include <strings.h>
#include <stdio.h>
#include "../src/bbs.h"

#define BBSHOME  "/s1/bbs"
#define INDEX    ".DIR"
#define BOARDS   ".BOARDS"

#define STRLEN   80

/*
struct fileheader {             
        char filename[STRLEN] ;     
        char owner[STRLEN] ;
        char title[STRLEN ] ;
        unsigned level;
        unsigned char accessed[ 12 ] ;  
} ;
*/

struct bnode {
     char data[STRLEN];
     struct bnode *lchild, *rchild;
};

int    bsort(), blist(), bfind(), freebtree();
char   *bmax(), *bmin();
struct bnode *mkbnode();

main()
{
   char buf[STRLEN];
   int fp;
   struct fileheader board;

   sprintf(buf,"%s/%s", BBSHOME, BOARDS);
   if ((fp = open(buf,O_RDONLY,0)) == -1) {
      printf("File [%s] open error.\n", buf);
      return -1;
   }

   while (read(fp, &board, sizeof board) == sizeof board)
       clr_junk_file(board.filename);
   close(fp);
}

clr_junk_file(boardname)
char *boardname;
{
   struct fileheader indexrec;
   struct bnode *btree;
   struct dirent *direntry;
   DIR    *dirptr;
   char   max[STRLEN], min[STRLEN], buf[STRLEN], *strptr;
   int    fp;

   sprintf(buf,"%s/%s/%s/%s", BBSHOME, "boards", boardname, INDEX);
   if ((fp = open(buf,O_RDONLY,0)) == -1) {
      printf("File [%s] open error.\n", buf);
      return -1;
   }

   btree = NULL;
   while (read(fp, &indexrec, sizeof indexrec) == sizeof indexrec)
         bsort(&btree, indexrec.filename);
   close(fp);

   if (btree == NULL) return;

   sprintf(max, "%s", bmax(btree));
   sprintf(min, "%s", bmin(btree));
   /* blist(btree); */

   strptr = rindex(buf, '/');  *strptr = '\0';
   if ((dirptr = opendir(buf)) == NULL) {
      printf("Directory [%s] open error.\n", buf);
      return -1;
   }

   printf("Cleaning %s/%s/%s\n", BBSHOME, "boards", boardname);
   while ((direntry = readdir(dirptr)) != NULL)
      if (!strncmp(direntry->d_name, "M.", 2)) {
         if (strcmp(direntry->d_name, max) > 0)
            continue;
         else if ((strcmp(direntry->d_name, min) < 0) ||
                       !bfind(btree, direntry->d_name))  {
            sprintf(buf,"%s/%s/%s/%s",BBSHOME,"boards", boardname,
                                                   direntry->d_name);
            printf("\t\t%s\n", buf);
            unlink(buf);
         }
      } else {
	 if (!strcmp(direntry->d_name, ".DIR"))
		continue;
         sprintf(buf,"%s/%s/%s/%s",BBSHOME,"boards", boardname,
                                                   direntry->d_name);
	 unlink(buf);
      }

  closedir(dirptr);
  freebtree(btree);
}

struct bnode *
mkbnode(data)
char *data;
{
   struct bnode *node;

   node = (struct bnode *) (malloc(sizeof(struct bnode)));
   node->lchild = node->rchild = NULL;
      strncpy(node->data, data, STRLEN );
   return(node);
}

bsort(node, data)
struct bnode **node;
char *data;
{
   struct bnode *newnode;
   int    flag;

   if (*node == NULL) {
      *node = mkbnode(data);
      return;
   }

   if ((flag = strcmp((*node)->data, data)) == 0)
      return;
   else if (flag >= 0)
      bsort(&(*node)->lchild, data);
   else
      bsort(&(*node)->rchild, data);
   return;
}

blist(node)
struct bnode *node;
{
   static int counter;

   if (node == NULL) return;
   blist(node->lchild);
   printf("%3d %s\n", counter++, node->data);
   blist(node->rchild);
}

char *
bmax(node)
struct bnode *node;
{
   if (node->rchild == NULL)
      return(node->data);
   else
      return(bmax(node->rchild));
}

char *
bmin(node)
struct bnode *node;
{
   if (node->lchild == NULL)
      return(node->data);
   else
      return(bmin(node->lchild));
}

bfind(node, data)
struct bnode *node;
char   *data;
{
   int flag;

   if (node == NULL) return 0;
   if ((flag = strcmp(data, node->data)) == 0)
      return 1;
   else if (flag < 0)
      return(bfind(node->lchild, data));
   else
      return(bfind(node->rchild, data));
}

freebtree(node)
struct bnode *node;
{
   struct bnode *tmp;

   if (node == NULL) return;
   freebtree(node->lchild);
   freebtree(node->rchild);
   free(node);
}
