/*
 *    read.c
 */
 
 
#include "bbs.h"

#define PUTCURS   move(3+locmem->crs_line-locmem->top_line,0);prints(">");
#define RMVCURS   move(3+locmem->crs_line-locmem->top_line,0);prints(" ");


struct keeploc {
    char *key ;
    int top_line ;
    int crs_line ;
    struct keeploc *next ;
} ;


struct	fileheader SR_fptr;    
char		currdirect[ STRLEN ];
char		*pnt;
int		screen_len;
int		last_line;


struct keeploc *
getkeep(s,def_topline,def_cursline)
char	*s;
int	def_topline;
int	def_cursline;
{
    static struct keeploc *keeplist = NULL ;
    struct keeploc *p ;

    for(p = keeplist; p!= NULL; p = p->next) {
        if(!strcmp(s,p->key)) {
	  if (p->crs_line < 1) p->crs_line = 1;   /* DAMMIT! - rrr */
          return p ;
	}
    }
    p = (struct keeploc *) malloc(sizeof (*p)) ;
    p->key = (char *) malloc(strlen(s)+1) ;
    strcpy(p->key,s) ;
    p->top_line = def_topline ;
    p->crs_line = def_cursline ;
    p->next = keeplist ;
    keeplist = p ;
    return p ;
}


void
fixkeep(s, first, last)
char *s;
int first, last;
{
    struct keeploc *k;
    k = getkeep(s, 1, 1);
    if (k->crs_line >= first) {
	k->crs_line = (first == 1 ? 1 : first-1);
	k->top_line = (first < 11 ? 1 : first-10);
    }
}


void
modify_locmem( locmem, total )
struct keeploc	*locmem;
int		total;
{
    if( locmem->top_line > total ) {
	locmem->crs_line = total;
	locmem->top_line = total - t_lines / 2;
	if( locmem->top_line < 1 )  locmem->top_line = 1;
    } else if( locmem->crs_line > total ) {
	locmem->crs_line = total;
    }
}



int
move_cursor_line( locmem, mode )
struct keeploc	*locmem;
int		mode;
{
    int		top, crs;
    int		reload = 0;

    top = locmem->top_line;
    crs = locmem->crs_line;
    if( mode == READ_PREV ) {
	if( crs <= top ) {
	    top -= screen_len - 1;
	    if( top < 1 )  top = 1;
	    reload = 1;
	}
	crs--;
	if( crs < 1 ) {
	    crs = 1;
	    reload = -1;
	}
    } else if( mode == READ_NEXT ) {
	if( crs + 1 >= top + screen_len ) {
	    top += screen_len - 1;
	    reload = 1;
	}
	crs++;
	if( crs > last_line ) {
	    crs = last_line;
	    reload = -1;
	}
    }
    locmem->top_line = top;
    locmem->crs_line = crs;
    return reload;
}


void
draw_title( dotitle )
int (*dotitle)() ;
{
    move( 0, 0 );
    clrtobot();
    (*dotitle)();
    clrtobot();
}


void
draw_entry( doentry, locmem, num, ssize)
char		*(*doentry)();
struct keeploc	*locmem;
int		num;
int		ssize;
{
    char	*str;
    int		base, i;

    base = locmem->top_line;
    showansi=1;
    move( 3, 0 );
    if(uinfo.mode==READING){
      for( i = 0; i < num; i++ ) {
	str = (*doentry)( base + i, &pnt[ i*ssize ] );
	if( str[93] != '\0' ) 
	    str[93] = '\0';
	prints( "%s[m\n", str );
      }
     } else{
        for( i = 0; i < num; i++ ) {
	   str = (*doentry)( base + i, &pnt[ i*ssize ] );
	   if( str[88] != '\0' ) {
	       str[88] = '\0';
	   }
	   prints( "%s[m\n", str );
        }
      }  
    showansi=0; 
    clrtobot();
}



void
i_read( cmdmode, direct, dotitle, doentry, rcmdlist, ssize)
int	cmdmode;
char	*direct ;
int	(*dotitle)() ;
char	*(*doentry)() ;
struct one_key *rcmdlist ;
int	ssize;
{
    extern int	talkrequest;
    struct keeploc	*locmem;
    char	lbuf[11];
    int		lbc, recbase, mode, ch;
    int		num, entries;

    screen_len = t_lines - 4;
    modify_user_mode( cmdmode );
    pnt =  calloc( screen_len, ssize );
    strcpy( currdirect, direct );
    draw_title( dotitle );
    last_line = get_num_records( currdirect, ssize );
    if( last_line == 0 ) {
        if (cmdmode==RMAIL){
            prints("�S������s�H��...");
            pressreturn();
            clear();
        }else if(cmdmode==OVERRIDE){
            getdata(t_lines-1, 0, "�S������n�� (A)�s�W�n�� (Q)���}�H[Q] ",
               genbuf, 4, DOECHO,NULL,YEA);
            if (genbuf[0] == 'a'||genbuf[0] == 'A')
               friend_add();
        }else{
            getdata(t_lines-1, 0, "�ݪO�s���� (P)�o���峹 (Q)���}�H[Q] ",
              genbuf, 4, DOECHO,NULL);
            if (genbuf[0] == 'p'||genbuf[0] == 'P')
              do_post();
        }
        free(pnt);
        clear();
        return;
    }
    num = last_line - screen_len + 2;
    locmem = getkeep( currdirect, num < 1 ? 1 : num, last_line );
    modify_locmem( locmem, last_line );
    recbase = locmem->top_line;
    entries = get_records( currdirect, pnt, ssize, recbase, screen_len );
    draw_entry( doentry, locmem, entries, ssize );
    PUTCURS;
    lbc = 0;
    mode = DONOTHING;
    while( (ch = egetch()) != EOF ) {
	if( talkrequest ) {
	    talkreply();
	    mode = FULLUPDATE;
	} else if( ch >= '0' && ch <= '9' ) {
	    if( lbc < 9 )
		lbuf[ lbc++ ] = ch;
	} else if( lbc > 0 && (ch == '\n' || ch == '\r') ) {
	    lbuf[ lbc ] = '\0';
	    lbc = atoi( lbuf );
	    if( cursor_pos( locmem, lbc, 10 ) )
		mode = PARTUPDATE;
	    lbc = 0;
	} else {
	    lbc = 0;
	    mode = i_read_key( rcmdlist, locmem, ch, ssize );
            while( mode == READ_NEXT || mode == READ_PREV) {
		int	reload, tmp;

    	        reload = move_cursor_line(locmem, mode);
	if (reload == -1){
          mode = DIRCHANGED;
	  break;
	}
	else if (reload){
	  recbase = locmem->top_line;
	  entries = get_records(currdirect, pnt, ssize, recbase, screen_len);
	  if (entries <= 0){
	    last_line = -1;
	    break;
	  }
	}

	num = locmem->crs_line - locmem->top_line;
        mode = i_read_key( rcmdlist, locmem, ch ,ssize);
	    }
	    modify_user_mode( cmdmode );
	}
	if( mode == DOQUIT )
	    break;
	if( mode == GOTO_NEXT ) {
	    cursor_pos( locmem, locmem->crs_line + 1, 1 );
	    mode = PARTUPDATE;
	}
	switch( mode ) {
	    case -1:
	    case NEWDIRECT:
	    case DIRCHANGED:
		recbase = -1;
		last_line = get_num_records( currdirect, ssize );
		if( mode == NEWDIRECT ) {
		    num = last_line - screen_len + 2;
		    locmem = getkeep(currdirect, num<1 ? 1 : num, last_line );
		}
	    case FULLUPDATE:
		draw_title( dotitle );
	    case PARTUPDATE:
		if( last_line < locmem->top_line + screen_len ) {
		    num = get_num_records(currdirect, ssize) ;
		    if( last_line != num ) {
			last_line = num;
			recbase = -1;
		    }
		}
		if(last_line == 0) {
		    prints("No Messages\n") ;
		    entries = 0 ;
		} else if( recbase != locmem->top_line ) {
		    recbase = locmem->top_line;
		    if( recbase > last_line ) {
			recbase = last_line - screen_len / 2;
			if( recbase < 1 )  recbase = 1;
			locmem->top_line = recbase;
		    }
		    entries = get_records(currdirect, pnt, ssize,
					recbase, screen_len);
		}
		if(locmem->crs_line > last_line)
		    locmem->crs_line = last_line;
		draw_entry( doentry, locmem, entries, ssize );
		PUTCURS;
		break;
	    default:
		break;
	}
	mode = DONOTHING;
	if( entries == 0 )
	    break;
    }
    clear();
    free(pnt);
}



int
i_read_key( rcmdlist, locmem, ch, ssize)
struct one_key	*rcmdlist ;
struct keeploc	*locmem;
int	ch;
int	ssize;
{

    int		i, mode = DONOTHING;
    int	        redraw=0;
    int		chk_curr();
    extern int	ANONYmode;

    switch( ch ) {
	case 'q': case 'e': case KEY_LEFT: case 'i':
	    return DOQUIT;
	case Ctrl('L'):
	    redoscr();
	    break;
	case 'p': case 'k': case KEY_UP:
	    if( cursor_pos( locmem, locmem->crs_line-1, screen_len-2 ) )
		return PARTUPDATE;
	    break;
	case 'n': case 'j': case KEY_DOWN:
	    if( cursor_pos( locmem, locmem->crs_line+1, 0 ) )
		return PARTUPDATE;
	    break;
	case 'N': case Ctrl('F'): case KEY_PGDN: case ' ':
	    if( last_line >= locmem->top_line + screen_len) {
		locmem->top_line += screen_len - 1;
		locmem->crs_line = locmem->top_line;
		return PARTUPDATE;
	    }
	    RMVCURS;
	    locmem->crs_line = last_line;
	    PUTCURS;
	    break;
	case 'P': case Ctrl('B'): case KEY_PGUP:
	    if( locmem->top_line > 1 ) {
		locmem->top_line -= screen_len - 1;
		if( locmem->top_line <= 0 )
		    locmem->top_line = 1;
		locmem->crs_line = locmem->top_line;
		return PARTUPDATE;
	    }
	    break;
	case '$':
	    if( last_line >= locmem->top_line + screen_len ) {
		locmem->top_line = last_line - screen_len + 1;
		if( locmem->top_line <= 0 )
		    locmem->top_line = 1;
		locmem->crs_line = last_line;
		return PARTUPDATE;
	    }
	    RMVCURS;
	    locmem->crs_line = last_line;
	    PUTCURS;
	    break;
	case '\n': case '\r': case 'l': case KEY_RIGHT:
	    ch = 'r';
	    /* lookup command table */
	default:
	    for( i = 0; rcmdlist[i].fptr != NULL; i++ ) {
		if( rcmdlist[i].key == ch ) {
		    mode = (*(rcmdlist[i].fptr)) (locmem->crs_line,
			    &pnt[ (locmem->crs_line - locmem->top_line)*ssize],
			    currdirect );
		    break;
		}
	    }
    }
    return mode;
}



int
search_author( locmem, offset )
struct keeploc	*locmem;
int		offset;
{
    static char	author[ IDLEN+1 ];
    char	ans[ IDLEN+1 ], pmt[ STRLEN ];

    strcpy( ans, author );
    sprintf( pmt, "%s�j�M�@�� [%s]: ", offset > 0 ? "���U" : "���W", ans );
    getdata( t_lines-1, 0, pmt, ans, IDLEN, DOECHO, NULL );
    if( *ans != '\0' )  strcpy( author, ans );
    return search_articles( locmem, author, offset, 1 );
}



int
search_title( locmem, offset )
struct keeploc	*locmem;
int		offset;
{
    static char	title[ STRLEN ];
    char	ans[ STRLEN ], pmt[ STRLEN ];

    strcpy( ans, title );
    sprintf( pmt, "%s�j�M���D [%s]: ", offset > 0 ? "���U" : "���W", ans );
    getdata( t_lines-1, 0, pmt, ans, STRLEN, DOECHO, NULL );
    if( *ans != '\0' )  strcpy( title, ans );
    return search_articles( locmem, title, offset, 0 );
}



int
search_thread( locmem, offset, title )
struct keeploc	*locmem;
int		offset;
char		*title;
{

    if( title[0] == 'R' && title[1] == 'e' && title[2] == ':' )
	title += 4;
    return search_articles( locmem, title, offset, 0 );
}



int
search_articles( locmem, query, offset, aflag )
struct keeploc	*locmem;
char		*query;
int		offset, aflag;
{
    char	*ptr;
    int		now, match = 0;
    int		ssize = sizeof(struct fileheader);

    move( t_lines-1, 0 );
    clrtoeol();
    if( *query == '\0' ) {
	return 0;
    }
    prints( "�B�z��, �еy��..." );
    refresh();
    now = locmem->crs_line;
    while( 1 ) {
	if( offset > 0 ) {
	    if( ++now > last_line )  break;
	} else {
	    if( --now < 1 )  break;
	}
	if( now == locmem->crs_line )
	    break;
	get_record( currdirect, &SR_fptr, ssize, now );
	ptr = aflag ? SR_fptr.owner : SR_fptr.title;
	if( aflag && (SR_fptr.accessed[0]&FILE_ANONYMOUS) )
	    continue;
	if( strstr( ptr, query ) != NULL ) {
	    match = cursor_pos( locmem, now, 10 );
	    break;
	}
    }
    move( t_lines-1, 0 );
    clrtoeol();
    return match;
}

/* calc cursor pos and show cursor correctly -cuteyu */
int cursor_pos( locmem, val, from_top )
struct keeploc *locmem;
int val;
int from_top;
{
    if ( val > last_line ) {
    	val = last_line;
    }
    if ( val <= 0 ) {
    	val = 1;
    }
    if ( val >= locmem->top_line && val < locmem->top_line + screen_len-1 ) {
    	RMVCURS ;
	locmem->crs_line = val ;
	PUTCURS ;
	return 0;
    }
    locmem->top_line = val - from_top ;
    if ( locmem->top_line <= 0 )
    	locmem->top_line = 1 ;
    locmem->crs_line = val ;
    return 1;
}



int
sread(ptitle)
struct fileheader *ptitle;
{   
    struct	keeploc  *locmem;
    int	istest=0,isnext=1;
    int	entries,previous;
    char	genbuf[STRLEN],title[STRLEN];
    extern	char	quote_file[256];

    
    previous=0;
    move(t_lines-1,0);
    clrtoeol();
    prints("[1;44;35m[�D�D�\\Ū] [33m�U�@�� <Enter>,���x�W�@�� ��,U                                  [m" );
    switch(egetch()){
        case ' ': case '\n':
        case KEY_DOWN:
            isnext=1;
            break;      
        case KEY_UP:case 'u':case'U':
            isnext=-1;
            break;      
        default : 
            break;
      }
     locmem = getkeep( currdirect, 1, 1);

     if(strncmp(ptitle->title,"Re: ",4)!=0&&strncmp(ptitle->title,"RE: ",4)!=0)
            sprintf(title,"Re: %s",ptitle->title);
     else   strcpy(title,ptitle->title);

     strcpy(title,title+4);
     memcpy(&SR_fptr,ptitle,sizeof(SR_fptr));
 
  while(!istest){
     search_articles( locmem, title, isnext, 0);
     if(previous==locmem->crs_line)
        break;
     previous=locmem->crs_line;           
     setbfile( genbuf, currboard, SR_fptr.filename );
     strcpy(quote_file,genbuf);
     ansimore(genbuf,NA) ;
     brc_addlist( SR_fptr.filename ) ;
     move(t_lines-1, 0);
     clrtoeol();
     prints("\033[1;44;35m[�D�D�\\Ū] \033[33m�^�H R �x ���� Q,�� �x�U�@�� ��,Enter�x�W�@�� ��,U �x ^R �^�H���@�� \033[m");
     switch( egetch() ) {
            case 'N': case 'Q':case 'n': case 'q':
            case KEY_LEFT:
                 istest=1;
                 break;
            case 'Y' : case 'R':case 'y' : case 'r':
                 do_reply(SR_fptr.title);
            case ' ': case '\n': case 'j':
            case KEY_DOWN:
                 isnext=1;
                 break;
            case KEY_UP:case 'u':case'U':
                 isnext=-1;
                 break;
            case Ctrl('R'):
                 post_reply( 0, &SR_fptr, (char *)NULL );
                 break;
            default : 
                break;
        }
    }       
return 1;
}
