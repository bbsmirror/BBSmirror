/*
 *	bcache.c
 */


#include "bbs.h"
#include <sys/ipc.h>
#include <sys/shm.h>


struct BCACHE	*brdshm;
struct UCACHE	*uidshm;
struct UTMPFILE	*utmpshm;
struct userec lookupuser;
struct shortfile *bcache;
int	usernumber;
int	numboards = -1 ;

#ifdef	HAVE_MMAP
#include <sys/mman.h>
#else
int usernumber;
#endif

void
attach_err( shmkey, name )
int	shmkey;
char	*name;
{
    sprintf( genbuf, "Error! %s error! key = %x.\n", name, shmkey );
    write( 1, genbuf, strlen( genbuf ) );
    exit( 1 );
}

void *
attach_shm( shmstr, defaultkey, shmsize )
char	*shmstr;
int	defaultkey, shmsize;
{
    void	*shmptr;
    int		shmkey, shmid;

    shmkey = sysconf_eval( shmstr );
    if( shmkey < 1024 )
	shmkey = defaultkey;
    shmid = shmget( shmkey, shmsize, 0 );
    if( shmid < 0 ) {
	shmid = shmget( shmkey, shmsize, IPC_CREAT | 0600 );
	if( shmid < 0 )
	    attach_err( shmkey, "shmget" );
	shmptr = (void *) shmat( shmid, NULL, 0 );
	if( shmptr == (void *)-1 )
	    attach_err( shmkey, "shmat" );
	memset( shmptr, 0, shmsize );
    } else {
	shmptr = (void *) shmat( shmid, NULL, 0 );
	if( shmptr == (void *)-1 )
	    attach_err( shmkey, "shmat" );
    }
    return shmptr;
}

/*���sŪ������W��*/
int
load_b_override(vptr) 
struct shortfile *vptr;
{
    char	buf[STRLEN];
    int		j;

    setvfile( buf, vptr->filename, "overrides");
    if(dashf(buf)){
         struct friend *topfriend;
         int	nf,i,unum;
         int	myfriends[MAXFRIENDS];

         nf = get_num_records(buf,sizeof(struct friend));
         if(nf <= 0)
               return 0;
         nf = (nf >= MAXFRIENDS) ? MAXFRIENDS:nf;
         topfriend = (struct friend *)calloc(sizeof(struct friend),nf);
         get_records(buf,topfriend,sizeof(struct friend),1,nf);
         memset(myfriends, 0, sizeof(myfriends));
         j=0;
         for( i=0; i<nf; i++){
             if(unum = searchuser(topfriend[i].id)){
                   myfriends[j]= unum;
                   j++;
              }
         }
         memcpy(vptr->friends, myfriends, sizeof(myfriends));
         free(topfriend);
      } else return 0;
      return 1;
}

int
fillbcache(fptr)
struct boardheader *fptr ;
{
    struct shortfile *bptr;
    char	buf[STRLEN];

    if( numboards >= MAXBOARD )
	return 0;
    bptr = &bcache[ numboards++ ]; /* �N bptr ��}���� bcache[i] */
    memcpy( bptr, fptr, sizeof( struct shortbfile ) ); /* �ҥH�o�̵�����F bcache*/
    load_b_override(bptr);
    return 0 ;
}


void
resolve_boards()
{
    struct stat	st;
    time_t	now;

    if( brdshm == NULL ) {
	brdshm = attach_shm( "BCACHE_SHMKEY", 3693, sizeof( *brdshm ) );
    }
    numboards = brdshm->number;
    bcache = brdshm->bcache;
    now = time( NULL );
    if( stat( BOARDS, &st ) < 0 ) {
	st.st_mtime = now - 3600;
    }
    if( brdshm->uptime < st.st_mtime || brdshm->uptime < now - 3600 ) {
	log_usies( "CACHE", "reload bcache" );
	numboards = 0;
	apply_record( BOARDS, fillbcache, sizeof(struct boardheader) );
	brdshm->number = numboards;
	brdshm->uptime = now; /* bug fixed */
    }
}

int
apply_boards(func)
int (*func)() ;
{
    register int i ;

    resolve_boards();
    for(i=0;i<numboards;i++)
	if( bcache[i].level & PERM_POSTMASK || HAS_PERM( bcache[i].level ) )
	    if((*func)(&bcache[i]) == QUIT)
		return QUIT;
    return 0;
}

struct shortfile *
getbcache( bname )
char *bname ;
{
    register int i ;

    resolve_boards();
    for(i=0;i<numboards;i++)
	if( bcache[i].level & PERM_POSTMASK || HAS_PERM( bcache[i].level ) )
	    if( !ci_strncmp( bname, bcache[i].filename, STRLEN ) )
		return &bcache[i];
    return NULL;
}

int
getbnum( bname )
char	*bname;
{
    register int i;

    resolve_boards();
    for(i=0;i<numboards;i++)
	if( bcache[i].level & PERM_POSTMASK || HAS_PERM( bcache[i].level ) )
	    if(!ci_strncmp( bname, bcache[i].filename, STRLEN ) )
		return i+1 ;
    return 0 ;
}

int
haspostperm(bname)
char *bname;
{
    register int i;

    if( strcmp( bname, DEFAULTBOARD ) == 0 )  return 1;
    if ((i = getbnum(bname)) == 0) return 0;
    if (!HAS_PERM(PERM_POST)) return 0;
    return (HAS_PERM(bcache[i-1].level & ~PERM_POSTMASK));
}

#ifndef HAVE_MMAP
int
fillucache(uentp)
struct userec *uentp ;
{
    if(usernumber < MAXUSERS) {
	strncpy(uidshm->userid[usernumber],uentp->userid,IDLEN+1) ;
	uidshm->userid[usernumber++][IDLEN] = '\0' ;
    }
    return 0 ;
}
#endif


void
resolve_ucache()
{
    struct stat st ;
    int		ftime;

    if( uidshm == NULL ) {
	uidshm = attach_shm( "UCACHE_SHMKEY", 3696, sizeof( *uidshm ) );
    }
    if( stat( FLUSH,&st ) < 0 ) {
	st.st_mtime++ ;
    }
    ftime = st.st_mtime;
    if( uidshm->uptime < ftime ) {
#ifdef	HAVE_MMAP
      {
	register int fd, usernumber;

	usernumber = 0;

	if ((fd = open(PASSFILE, O_RDONLY)) > 0){
	  caddr_t fimage, mimage;
	  struct stat stbuf;

	  fstat(fd, &stbuf);
	  fimage = mmap(NULL, stbuf.st_size, PROT_READ, MAP_SHARED, fd, 0);
	  if (fimage == (char *) -1)
	    exit(-1);
	  close(fd);
	  fd = stbuf.st_size / sizeof(struct userec);
	  if (fd > MAXUSERS)
	    fd = MAXUSERS;
	  for (mimage = fimage; usernumber < fd; mimage += sizeof(struct userec)){
    	         memcpy(uidshm->userid[usernumber++], mimage, IDLEN);
	  }
	  munmap(fimage, stbuf.st_size);
	}
	uidshm->number = usernumber;
      }
#else
	usernumber = 0;
	apply_record( PASSFILE, fillucache, sizeof(struct userec) );
	uidshm->number = usernumber;
#endif
	log_usies( "CACHE", "reload ucache" );
	uidshm->uptime = ftime; /* bug fixed */
    }
}



void
setuserid( num, userid )
int	num;
char	*userid;
{
    if( num > 0 && num <= MAXUSERS ) {
	if( num > uidshm->number )
	    uidshm->number = num;
	strncpy( uidshm->userid[ num - 1 ], userid, IDLEN+1 );
    }
}

int
searchnewuser()
{
    register int num, i;

    resolve_ucache() ;
    num = uidshm->number;
    for(i=0; i < num; i++)
	if( uidshm->userid[i][0] == '\0' )                
	    return i+1 ;
    if( num < MAXUSERS )           
	return( num + 1 );
    return 0 ;
}

int
searchuser(userid)
char *userid ;
{
    register int i ;

    resolve_ucache() ;
    for(i=0; i < uidshm->number; i++)
	if(!ci_strncmp(userid,uidshm->userid[i],IDLEN+1))
	    return i+1 ;
    return 0 ;
}

int
apply_users(func)
void (*func)() ;
{
    register int i ;
    resolve_ucache() ;
    for(i=0; i < uidshm->number; i++)
	(*func)(uidshm->userid[i],i+1) ;
    return 0 ;
}

int
getuser(userid)
char *userid ;
{
    int uid = searchuser(userid) ;

    if(uid == 0) return 0 ;
    get_record(PASSFILE,&lookupuser,sizeof(lookupuser),uid) ;
    return uid ;
}

char *
u_namearray( buf, pnum, tag )
char	buf[][ IDLEN+1 ], *tag;
int	*pnum;
{
    register struct UCACHE *reg_ushm = uidshm;
    register char	*ptr, tmp;
    register int	n, total;
    char	tagbuf[ STRLEN ];
    int		ch, num = 0;

    resolve_ucache();
    if( *tag == '\0' ) {
	*pnum = reg_ushm->number;
	return reg_ushm->userid[0];
    }
    for( n = 0; tag[n] != '\0'; n++ ) {
        tagbuf[ n ] = chartoupper( tag[n] );
    }
    tagbuf[ n ] = '\0';
    ch = tagbuf[0];
    total = reg_ushm->number;
    for( n = 0; n < total; n++ ) {
	ptr = reg_ushm->userid[n];
	tmp = *ptr;
	if( tmp == ch || tmp == ch - 'A' + 'a' )
	    if( chkstr( tag, tagbuf, ptr ) )
		strcpy( buf[ num++ ], ptr );
    }
    *pnum = num;
    return buf[0];
}

void
resolve_utmp()
{
    if( utmpshm == NULL ) {
	utmpshm = attach_shm( "UTMP_SHMKEY", 3699, sizeof( *utmpshm ) );
    }
}

int
getnewutmpent( up )
struct user_info *up;
{
    static int		utmpfd;
    struct user_info	*uentp;
    time_t	now;
    int		i, n;

    if( utmpfd == 0 ) {
	utmpfd = open( ULIST, O_RDWR|O_CREAT, 0600 );
	if( utmpfd < 0 )
	    return -1;
    }
    resolve_utmp();
    flock( utmpfd, LOCK_EX );
    for( i = 0; i < USHM_SIZE; i++ ) {
	uentp = &(utmpshm->uinfo[ i ]);
	if( !uentp->active || !uentp->pid ) break ;
    }
    if( i >= USHM_SIZE ) {
	flock( utmpfd, LOCK_UN );
	return -1;
    }
    utmpshm->uinfo[i] = *up;
    flock( utmpfd, LOCK_UN );

    now = time( NULL );
    if( now > utmpshm->uptime + 60 ) {
	utmpshm->uptime = now;
	for( n = 0; n < USHM_SIZE; n++ ) {
	    uentp = &(utmpshm->uinfo[ n ]);
	    if( uentp->active && uentp->pid && kill( uentp->pid, 0 ) == -1 )
		memset( uentp, 0, sizeof( struct user_info ) );
	}
	n = USHM_SIZE - 1;
	while( n > 0 && utmpshm->uinfo[ n ].active == 0 )
	    n--;
	ftruncate( utmpfd, 0 );
	write( utmpfd, utmpshm->uinfo, (n+1) * sizeof(struct user_info) );
    }
    return i+1 ;
}

int
apply_ulist( fptr )
int (*fptr)();
{
    struct user_info	*uentp, utmp;
    int		i, max;

    resolve_utmp();
    max = USHM_SIZE - 1;
    while( max > 0 && utmpshm->uinfo[ max ].active == 0 )
	max--;
    for( i = 0; i <= max; i++ ) {
	uentp = &(utmpshm->uinfo[ i ]);
	utmp = *uentp;
	if( (*fptr)( &utmp ) == QUIT )
	    return QUIT;
    }
    return 0;
}

int
search_ulist( uentp, fptr, farg )
struct user_info *uentp;
int (*fptr)();
int farg;
{
    int		i;

    resolve_utmp();
    for( i = 0; i < USHM_SIZE; i++ ) {
	*uentp = utmpshm->uinfo[ i ];
	if( (*fptr)( farg, uentp ) )
	    return i+1;
    }
    return 0;
}

int
search_ulistn( uentp, fptr, farg, unum )
struct user_info *uentp;
int (*fptr)();
int farg;
int unum;
{
    int		i, j;

    j = 1;
    resolve_utmp();
    for( i = 0; i < USHM_SIZE; i++ ) {
	*uentp = utmpshm->uinfo[ i ];
	if( (*fptr)( farg, uentp ) ) {
		if (j == unum) return i+1;
		else j++; }
    }
    return 0;
}

int
count_logins( uentp, fptr, farg, show )
struct user_info *uentp;
int (*fptr)();
int farg;
int show;
{
    int		i, j;

    j = 0;
    resolve_utmp();
    for( i = 0; i < USHM_SIZE; i++ ) {
	*uentp = utmpshm->uinfo[ i ];
	if( (*fptr)( farg, uentp ) ) 
	  if(show == 0) j++; 
	  else if(show == 1) {
	    j++;
	    prints("(%d) �ثe���A��: %s, �Ӧ�: %s \n", j, 
                     modestring(uentp->mode, uentp->destuid, 1, 
                     uentp->in_chat ? uentp->chatid : NULL), uentp->from ); 
	  }
    }
    return j;
}

void
update_ulist( uentp, uent )
struct user_info *uentp;
int	uent;
{
    resolve_utmp();
    if( uent > 0 && uent <= USHM_SIZE ) {
	utmpshm->uinfo[ uent - 1 ] = *uentp;
    }
}

void
update_utmp()
{
    update_ulist( &uinfo, utmpent );
}

