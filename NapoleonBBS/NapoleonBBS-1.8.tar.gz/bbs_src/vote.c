/*
 *	vote.c
 */


#include "bbs.h"

extern cmpbnames();
extern int numboards;

void
b_report( str )
char *str;
{
    char	buf[ STRLEN ];

    sprintf( buf, "%s %s", currboard, str );
    report( buf );
}

void
makevdir( bname )
char	*bname;
{
    struct stat	st;
    char	buf[ STRLEN ];

    sprintf( buf, "vote/%s", bname );
    if( stat( buf, &st ) != 0 )
	mkdir( buf, 0755 );
}

void
setvfile( buf, bname, filename )
char	*buf, *bname, *filename;
{
    sprintf( buf, "vote/%s/%s", bname, filename );
}

int
b_notes_edit()
{
    char	buf[ STRLEN ];
    int		aborted;
    int		chk_curr();
    char	ans[2];

    if( !HAS_PERM( PERM_SYSOP ) ) 
	if( (!HAS_PERM(PERM_BOARDS)) || !chk_curr(currBM,currentuser.userid) )
	    return 0 ;

    makevdir( currboard );
    setvfile( buf, currboard, "notes" );
    clear();
    getdata(0,0,"(E)���, (D)�R��, (Q)����? [E]: ",ans,2,DOECHO,NULL);
    if( ans[0]=='Q' || ans[0]=='q' )
          return FULLUPDATE;
    if( ans[0]=='D'|| ans[0]=='d' ){
        unlink(buf);
        outs("IT IS HISTORY");
        pressreturn();
        return FULLUPDATE;
    }

    aborted = vedit( buf, NA );
    if( aborted ) {
	clear();
	prints( "�����C\n" );
	pressreturn();
    }
    return FULLUPDATE;
}

int
b_suckinfile( fp, fname )
FILE *fp;
char *fname;
{
    char inbuf[256];
    FILE *sfp;
    if ( ( sfp = fopen( fname, "r" ) ) == NULL ) 
	return -1;
    while ( fgets( inbuf, sizeof( inbuf ), sfp ) != NULL )
	fputs( inbuf, fp );
    fclose( sfp );
    return 0;
}

int
b_closepolls()
{
    struct boardheader fh;
    struct stat st;
    FILE	*cfp;
    char	buf[80];
    time_t	now;
    int		fd, size;

    now = time( NULL );
    strcpy( buf, "vote/lastpolling" );
    if( stat( buf, &st ) != -1 && st.st_mtime > now - 3600 ) {
	return 0;
    }
    move( t_lines-1, 0 );
    prints( "�����벼��..." );
    refresh();
    cfp = fopen( buf, "w" );
    fprintf( cfp, "%s", ctime( &now ) );
    fclose( cfp );
    if ( ( fd = open( BOARDS, O_RDWR ) ) == -1 ) {
	prints("WHOA! Can't open the boards!\n");
	return -1;
    }
    flock( fd, LOCK_EX );
    size = sizeof( fh );
    while ( read( fd, &fh, size ) == size ) {
    	setvfile(buf,fh.filename,"results");
        if( (fh.BM[ BM_LEN - 1 ]==2) && stat( buf, &st ) != -1 && (st.st_mtime < now - (60*60*24*7)) ) {
           fh.BM[BM_LEN-1]=0;
           lseek( fd, (off_t)-size, SEEK_CUR );   /* back up */
	   if ( write( fd, &fh, sizeof( fh ) ) != sizeof( fh ) ) 
		continue;
	}
	if( (fh.BM[ BM_LEN - 1 ]==1) && b_close( &fh ) ) {
	    lseek( fd, (off_t)-size, SEEK_CUR );   /* back up */
	    if ( write( fd, &fh, sizeof( fh ) ) != sizeof( fh ) ) 
		continue;
	}
    }
    flock( fd, LOCK_UN );
    close( fd );
    return 0;
}


int
b_close( fh )
struct boardheader *fh;
{
    time_t      endtime;
    FILE        *cfp, *tfp;
    char        *bname;
    char        buf[ STRLEN ];
    char        inchar, inbuf[80];
    int         counts[31], fd;
    int         total, num;
    char        b_control[80];
    char        b_newresults[80];


    bname = fh->filename;
    setvfile( buf, bname, "control" );
    if( (cfp = fopen( buf, "r" )) == NULL ) {
        return 1;
    }
    if( fgets( inbuf, sizeof( inbuf ), cfp ) == NULL ) {
        fclose(cfp);
        return 1;
    }
    fclose(cfp);
    fh->BM[ BM_LEN - 1 ] = 2;
    endtime = (time_t)atol( inbuf );
    if( endtime > time(0) ) 
        return 0;
    
    return mk_result(fh, (time_t)time(NULL));
}


int
mk_result(fh,endtime)
struct	boardheader *fh;
time_t	endtime;
{
    FILE        *cfp, *tfp;
    char        *bname;
    char        buf[ STRLEN ];
    char        inchar, inbuf[80];
    int         counts[31], fd;
    int         total, num;
    char        b_control[80];
    char        b_newresults[80];

    bname = fh->filename;
    setvfile( buf, bname, "control" );    
    setvfile( b_control, bname, "temp" );
    if( rename( buf, b_control ) == -1 ) 
        return 1;

    b_report( "CLOSE" );
    memset( counts, 0, sizeof( counts ) );
    setvfile( buf, bname, "flags" );
    unlink( buf );
    setvfile( buf, bname, "tickets" );
    unlink( buf );
    setvfile( buf, bname, "ballots" );
    if( (fd = open( buf, O_RDONLY )) != -1 ) {
        while( read( fd, &inchar, 1 ) == 1 ) 
            counts[(int)(inchar - 'A')]++;
        close( fd );
    }
    unlink( buf );

    setvfile( b_newresults, bname, "newresults" );
    if( (tfp = fopen( b_newresults, "w" )) == NULL )
        return 1;
    memset( buf, '-', 78 );
    buf[ 78 ] = '\0';
    fprintf( tfp, "%s\n\n", buf );
    fprintf( tfp, "** �벼�����: %s\n", ctime( &endtime ) );
    fprintf( tfp, "** �����D�شy�z:\n\n" );

    setvfile( buf, bname, "desc" );
    b_suckinfile( tfp, buf );
    unlink( buf );

    fprintf( tfp, "** �벼���G:\n\n" );
    total = 0;
    if( (cfp = fopen( b_control, "r" )) != NULL ) {
        fgets( inbuf, sizeof( inbuf ), cfp );
        while ( fgets( inbuf, sizeof( inbuf ), cfp ) ) {
            inbuf[(strlen( inbuf ) - 1)] = '\0';
            inbuf[43] = '\0'; /* truncate */
            num = counts[ inbuf[0] - 'A' ];
            fprintf(tfp, "    %-40s  %3d ��\n", inbuf + 3, num );
            total += num;
        }
        fclose( cfp );
    }
    unlink( b_control );

    fprintf( tfp, "\n�`���� = %d ��\n\n", total );
    setvfile( buf, bname, "results" );
    fclose(tfp);
    rename( b_newresults, buf );
    return 1;
}



int
v_override(filename)
char filename[STRLEN];
{
    char	uident[STRLEN];
    char	ans[8];
    int		count,n,deleted=0;
    struct	friend  bf;


    if( !HAS_PERM(PERM_SYSOP)) 
       if( !HAS_PERM(PERM_BOARDS) || !chk_curr(currBM,currentuser.userid)  ) 
           return DONOTHING ;

    makevdir(currboard);
    while (1) {
        clear();
        prints("�]�w����W��\n");
        count = list_overrides(filename);
        if (count)
            getdata(1,0,"(A)�W�[ (D)�R�� or (E)���} [E]: ",ans,7,DOECHO,NULL);
        else 
            getdata(1,0,"(A)�W�[ or (E)���} [E]: ", ans, 7, DOECHO, NULL);
        if (*ans == 'A' || *ans == 'a') {
            move(1,0);
            usercomplete("Add userid: ", uident);
            if(seek_in_file(filename,uident)){
		move(2,0);
		prints("�W�椤�w�����b��");
		pressanykey();
		continue;
            } else if( *uident != '\0' ){
            	 strcpy(bf.id, uident);
		 addtofile(filename, bf);
		 deleted=1;
            }
        } else if ((*ans == 'D' || *ans == 'd') && count) {
            move(1,0);
            namecomplete("Delete userid: ", uident);
            move(1,0);
            clrtoeol();
            if (uident[0] != '\0')
		del_from_file(filename,uident);
	    deleted=1;
        } else break;
    }
    clear();
    if(deleted){
       struct	shortfile *bptr;
       struct	shortfile *getbcache(char *);
       
       bptr = getbcache(currboard);
       load_b_override(bptr);
    }
    return FULLUPDATE;
}               

int
vote_maintain( bname )
char	*bname;
{
    FILE	*fp,*cfp;
    char	inbuf[STRLEN], buf[STRLEN], inchar;
    int		num = 0, aborted;
    time_t	closetime, numseconds;
    int		chk_curr();
    int         counts[31],total=0,pos,fd;
    struct	boardheader fh;
	
    if( !HAS_PERM( PERM_SYSOP ) )
	if( (!HAS_PERM(PERM_BOARDS)) || !chk_curr(currBM,currentuser.userid) )
	    return 0 ;

    stand_title( "�}�ҧ벼�c" );
    move( 2,0 );
    makevdir( bname );
    setvfile( buf, bname, "control" );
    if ( ( fp = fopen( buf, "r" ) ) != NULL ) {
	fgets( inbuf, sizeof( inbuf ), fp );
	fclose( fp );
	closetime = (time_t)atol( inbuf );
	prints( "�A�w�}�ҤF�벼�c, �P�ɶ����L�k�|���ӥH�W���벼�C\n" );
	prints( "�����벼�w�p������: %s", ctime( &closetime ) );

    	outs("\n�� �w���벼����:\n\n");
    	memset( counts, 0, sizeof( counts ) );
    	setvfile( buf, bname, "ballots" );
	if( (fd = open( buf, O_RDONLY )) != -1 ) {
        	while( read( fd, &inchar, 1 ) == 1 ) 
            	counts[(int)(inchar - 'A')]++;
        	close( fd );
    	}
    	setvfile(buf,bname,"control");
	if( (cfp = fopen( buf, "r" )) != NULL ) {
        	fgets( inbuf, sizeof( inbuf ), cfp );
        	while ( fgets( inbuf, sizeof( inbuf ), cfp ) ) {
            		inbuf[(strlen( inbuf ) - 1)] = '\0';
            		inbuf[43] = '\0'; /* truncate */
            		num = counts[ inbuf[0] - 'A' ];
            		prints("    %-40s  %3d ��\n", inbuf + 3, num );
            		total += num;
            	}
            	fclose(cfp);
            	prints("\n�� �ثe�`���� = %d ��", total);
        }
        
        getdata(t_lines-2, 0, "(A)�����벼 (B)�����}�� (C)�~��H[C] ", genbuf, 4, DOECHO, NULL);
	pos = search_record( BOARDS, &fh, sizeof(fh), cmpbnames, bname );        
	if (genbuf[0] == 'a' || genbuf[0] == 'A'){
	      setvfile(buf, bname, "control");
      	      unlink(buf);
	      setvfile(buf, bname, "flags");
      	      unlink(buf);
              setvfile(buf, bname, "desc");
              unlink(buf);
              setvfile(buf, bname, "ballots");
              unlink(buf);
      	      fh.BM[ BM_LEN - 1 ] = 0;
      	      if (substitute_record(BOARDS, &fh, sizeof(fh), pos) == -1)
		   prints("Error updating BOARDS file...\n");
  	      prints("A OK");
        } else if (genbuf[0] == 'b' || genbuf[0] == 'B') {
              if( mk_result(&fh,(time_t)time(NULL)) ) {
                 fh.BM[ BM_LEN - 1 ] = 2;
                 if (substitute_record(BOARDS, &fh, sizeof(fh), pos) == -1)
		     prints("Error updating BOARDS file...\n");
	      }
        } 
        fclose(fp);
	pressreturn();
	return FULLUPDATE;
    }

    prints("������}�l�s�覹�� [�벼���y�z]: \n");
    igetch();
    setvfile( buf, bname, "desc" );
    aborted = vedit( buf, NA );
    if ( aborted ) {
	clear();
	prints( "���������벼\n" );
	pressreturn();
	return FULLUPDATE;
    }
    setvfile( buf, bname, "flags" );
    unlink( buf );
    setvfile( buf, bname, "control" );
    fp = fopen( buf, "w");
    clear();
    getdata( 0,0,"�����벼�Ҷ��Ѽ� (���i����): ",inbuf, 4, DOECHO, NULL );

    if ( *inbuf == '\n' || !strcmp( inbuf, "0" ) || *inbuf == '\0' )
	strcpy( inbuf, "1" );

    numseconds = atof(inbuf) * 86400.0;
    time( &closetime );
    closetime += numseconds;
    fprintf( fp, "%lu\n", closetime );
    fflush( fp );

    prints( "�Ш̧ǿ�J�i��ܶ�, �� ENTER �����]�w.\n" );
    num = 0;
    while ( !aborted ) {
	sprintf( buf, "%c) ", num + 'A' );
	getdata( (num%15)+2, (num/15)*40, buf, inbuf, 36, DOECHO, NULL);
	if (*inbuf) {
	    fprintf( fp, "%1c) %s\n", (num+'A'), inbuf);
	    num++;
	}
	if ( *inbuf == '\0' || num == 0 )
	    aborted = 1;
    }
    fclose( fp );
    {
	int	pos;
	char	ans[2];
	struct	boardheader fh;
	

	pos = search_record( BOARDS, &fh, sizeof(fh), cmpbnames, bname );

	getdata(t_lines-3,0,"�O�_���w�벼�� (Y/N)? [N]:",ans,2,DOECHO,NULL);
	if (  ans[0] == 'y' || ans[0] == 'Y') {
	     setvfile(buf,bname,"overrides");
	     if(!dashf(buf)){
	     	clear();
	     	move(t_lines-2,0);
	     	prints("���]�w�벼�W��, �Х��]�w");
	     	pressanykey();
	     	v_override(buf);
	     }
             fh.BM[ BM_LEN - 2 ] = 1;
        } else  fh.BM[ BM_LEN - 2 ] = 0;

	fh.BM[ BM_LEN - 1 ] = 1;
	getdata(t_lines-2,0,"�T�w�����벼 (Y/N)? [Y]:",ans,2,DOECHO,NULL);
        if ( ans[0] == 'n' || ans[0] == 'N' ) {
            setvfile( buf, bname, "control" );
            unlink(buf);
	    setvfile( buf, bname, "desc" );            
	    unlink(buf);
	    setvfile( buf, bname, "flags" );
	    unlink(buf);
            return FULLUPDATE;
        }
        if ( substitute_record( BOARDS, &fh, sizeof(fh), pos ) == -1 ){
	    prints("Error updating BOARDS file...\n");
	    exit(0);
	}
	b_report( "OPEN" );
	prints("�벼�c�}�ҤF�I\n");
	numboards = -1;
    }
    pressreturn();
    return FULLUPDATE;
}



int
vote_flag( bname, val )
char	*bname, val;
{
    char	buf[ STRLEN ], flag;
    int		fd, num, size;

    num = usernum - 1;
    setvfile( buf, bname, "flags" );
    if( (fd = open( buf, O_RDWR | O_CREAT, 0600 )) == -1 ) {
	return -1;
    }
    size = lseek( fd, 0, SEEK_END );
    memset( buf, 0, sizeof( buf ) );
    while( size <= num ) {
	write( fd, buf, sizeof( buf ) );
	size += sizeof( buf );
    }
    lseek( fd,(off_t) num, SEEK_SET );
    read( fd, &flag, 1 );
    if( flag == 0 && val != 0 ) {
	lseek( fd,(off_t) num, SEEK_SET );
	write( fd, &val, 1 );
    }
    close( fd );
    return flag;
}



int
user_vote( bname )
char	*bname;
{
    FILE	*cfp;
    char	buf[ STRLEN ];
    char	inbuf[80], choices[10], vote[2];
    int		fd, count = 0;
    time_t	closetime;
    struct	shortfile   *fh;    
    struct	shortfile   *getbcache(char *);
    
	
    move(3,0);
    setvfile( buf, bname, "control" );
    if ((cfp = fopen(buf, "r")) == NULL) {
        prints("��p, �ثe�èS������벼�|��C\n");
	clrtobot();
	pressreturn();
	return FULLUPDATE;
    }
    if( vote_flag( bname, '\0' ) != 0 ) {
        prints( "�����벼, �A�w��L�F!\n�@�H�@��, �j�a�����C\n" );
        clrtobot();
	fclose( cfp );
        pressreturn();
        return FULLUPDATE;
    }
    fh = getbcache(bname);
    if ( fh->BM[BM_LEN-2] ){
        if(!seek_b_record(fh)){
           move(3,0);
           clrtobot();
           prints("��p, �����벼���]��,\n�z�å��b�i�벼�W�椺");
           pressreturn();
           return FULLUPDATE;
        }
    }

    modify_user_mode( VOTING );
    setvfile( buf, bname, "desc" );
    ansimore( buf, YEA );
    stand_title( "�벼�c" );
    move( 2, 0 );
    prints( "�벼�覡: ���A�T�w�n�A����ܫ�, ��J��^��N�X�Y�i;\n" );
    prints( "����L������벼�C\n" );
    fgets( inbuf, sizeof(inbuf), cfp );
    closetime = (time_t)atol(inbuf);
    prints( "�����벼�N������: %s\n", ctime(&closetime) );
    move(6,0);
    memset( choices, 0, sizeof(choices) );
    while( fgets(inbuf, sizeof(inbuf), cfp) != NULL ) {
	choices[ count++ ] = inbuf[0];
	prints( "%s", inbuf );
    }
    fclose(cfp);
    vote[0] = vote[1] = '\0';
    getdata( count+8, 0, "��J�A�����: ", vote, 2, DOECHO, NULL);
    move( count+10, 0);
    if (vote[0] == '\0' || strchr(choices, vote[0]) == NULL) {
	prints( "���X�k�����, �벼�����C\n" );
    } else if( vote_flag( bname, vote[0] ) != 0 ) {
	prints( "���Ч벼! �벼���ѡC\n" );
    } else {
	setvfile( buf, bname, "ballots" );
	if ((fd = open( buf, O_WRONLY|O_CREAT|O_APPEND, 0600)) == 0)
	    prints("Can't open the ballot box! Aborting...\n");
	else {
	    struct stat statb;

	    flock(fd, LOCK_EX);
	    write(fd, vote, 1);
	    flock(fd, LOCK_UN);
	    fstat(fd, &statb);
	    close(fd);
	    prints("�w��J�벼�c��! (�ثe�w�벼��: %d)\n", statb.st_size);
	    sprintf(genbuf, "VOTE '%c'", vote[0]);
	    b_report( genbuf );
	    numboards = -1;
	}
    }
    pressreturn();
    return FULLUPDATE;
}



int
vote_results( bname )
char	*bname;
{
    char buf[STRLEN];

    setvfile( buf, bname, "results" );
    if ( ansimore( buf, YEA ) == -1 ) {
	move(3,0);
	prints("�ثe�S������벼�����G�C\n");
	clrtobot();
	pressreturn();
    } else clear();
    return FULLUPDATE;
}


int
b_vote_maintain()
{
    return vote_maintain( currboard );
}


int
b_vote()
{
    return user_vote( currboard );
}


int
b_results()
{
    return vote_results( currboard );
}


int
b_v_override()
{
    char	buf[STRLEN];
 
    setvfile(buf,currboard,"overrides");
    return v_override( buf );
}

int
m_vote()
{
    modify_user_mode(ADMIN);
    return vote_maintain( DEFAULTBOARD );
}

int
x_vote()
{
    return user_vote( DEFAULTBOARD );
}

int
x_results()
{
    modify_user_mode(RESULTS);
    return vote_results( DEFAULTBOARD );
}

