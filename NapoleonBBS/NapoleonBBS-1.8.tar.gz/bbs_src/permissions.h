/*
 *	permissions.h
 */



/*
   These are the 16 basic permission bits. 
   All but the last one are used in comm_lists.c and help.c to control user 
   access to priviliged functions. The symbolic names are given to roughly
   correspond to their actual usage; feel free to use them for different
   purposes though. The PERM_SPECIAL1 and PERM_SPECIAL2 are not used by 
   default and you can use them to set up restricted boards or chat rooms.
*/

#define	PERM_BASIC  	    000001
#define PERM_CHAT	    000002
#define	PERM_PAGE	    000004
#define PERM_POST	    000010
#define	PERM_LOGINOK 	    000020
#define PERM_DENYPOST	    000040
#define PERM_CLOAK	    000100
#define PERM_SEECLOAK	    000200
#define PERM_XEMPT	    000400
#define PERM_WELCOME	    001000
#define PERM_BOARDS	    002000
#define PERM_ACCOUNTS	    004000
#define PERM_CHATCLOAK	    010000
#define	PERM_OVOTE	    020000
#define PERM_SYSOP	    040000
#define PERM_POSTMASK      0100000     /* means the rest is a post mask */
#define PERM_UNUSE1        0200000
#define PERM_UNUSE2   	   0400000
#define PERM_UNUSE3       01000000
#define PERM_UNUSE4       02000000
#define PERM_UNUSE5       04000000
#define PERM_UNUSE6      010000000
#define PERM_UNUSE7      020000000
#define PERM_UNUSE8      040000000
#define PERM_UNUSE9     0100000000
#define PERM_UNUSE10    0200000000
#define PERM_UNUSE11    0400000000
#define PERM_UNUSE12   01000000000
#define PERM_UNUSE13   02000000000
#define PERM_UNUSE14   04000000000
#define PERM_SETREAD  010000000000

/* This is the default permission granted to all new accounts. */
#define PERM_DEFAULT 	(PERM_BASIC | PERM_CHAT | PERM_PAGE |\
			 PERM_POST | PERM_LOGINOK | PERM_SETREAD)

/* These permissions are bitwise ORs of the basic bits. They work that way
   too. For example, anyone with PERM_SYSOP or PERM_BOARDS or both has
   PERM_SEEBLEVELS. */

#define PERM_ADMINMENU	(PERM_ACCOUNTS | PERM_OVOTE | PERM_SYSOP)
#define PERM_MULTILOG	PERM_SYSOP
#define PERM_LOGINCLOAK	(PERM_SYSOP | PERM_ACCOUNTS | PERM_BOARDS | PERM_WELCOME)
#define PERM_SEEULEVELS (PERM_SYSOP | PERM_BOARDS)
#define PERM_SEEBLEVELS (PERM_SYSOP | PERM_BOARDS)
#define PERM_MARKPOST   (PERM_SYSOP | PERM_BOARDS)
#define PERM_UCLEAN	(PERM_SYSOP | PERM_ACCOUNTS)
#define PERM_NOTIMEOUT  PERM_SYSOP

#define PERM_SENDMAIL	0
#define PERM_READMAIL	PERM_BASIC
#define PERM_VOTE	PERM_BASIC

/* These are used only in Internet Mail Forwarding */
/* You may want to be more restrictive than the default, especially for an
   open access BBS. */

#define PERM_SETADDR	PERM_BASIC     /* to set address for forwarding */
#define PERM_FORWARD	PERM_BASIC     /* to do the forwarding */

/* Don't mess with this. */
#define HAS_PERM(x)	((x)?currentuser.userlevel&(x):1)

#ifndef EXTERN
extern char *permstrings[];
#else

#define NUMPERMS 31
/* You might want to put more descriptive strings for SPECIAL1 and SPECIAL2
   depending on how/if you use them. */
char *permstrings[] = {
	"���v�O",		/* PERM_BASIC */
	"�i�J��ѫ�", 		/* PERM_CHAT */
	"�I�s�L�H���",		/* PERM_PAGE */
	"�o���峹",		/* PERM_POST */
	"�ϥΪ̸�ƥ��T",	/* PERM_LOGINOK */
	"�T��o���峹",		/* PERM_DENYPOST */
	"�����N",		/* PERM_CLOAK */
	"�ݨ������ϥΪ�",	/* PERM_SEECLOAK */
	"�b���ä[�O�d",		/* PERM_XEMPT */
	"�s��i���e��",		/* PERM_WELCOME */
	"�Q�װϺ޲z��",		/* PERM_BOARDS */
	"�b���޲z��",		/* PERM_ACCOUNTS */
	"��ѫ������N",		/* PERM_CHATCLOAK */
	"�벼�޲z��",		/* PERM_OVOTE */
	"�t�κ��@�޲z��",	/* PERM_SYSOP */
	"Read/Post ����",	/* PERM_POSTMASK */
        "IEM�j�ǳ��v��",	/* PERM_UNUSE1*/	
        "�S���v�� 2",         /* PERM_UNUSE2*/
        "�S���v�� 3",           /* PERM_UNUSE3*/
        "�S���v�� 4",           /* PERM_UNUSE4*/
        "�S���v�� 5",           /* PERM_UNUSE5*/
        "�S���v�� 6",           /* PERM_UNUSE6*/
        "�S���v�� 7",           /* PERM_UNUSE7*/
        "�S���v�� 8",           /* PERM_UNUSE8*/
        "�S���v�� 9",           /* PERM_UNUSE9*/
        "�S���v��10 ",           /* PERM_UNUSE10*/
        "�S���v��11",           /* PERM_UNUS11*/	
        "�S���v��12",           /* PERM_UNUSE12*/
        "�p�_�M��",           /* PERM_UNUSE13*/
        "�۰�Forward",           /* PERM_UNUSE14*/
        "�]�w�\\Ū�v��",		/*PERM_SETREAD*/
};
#endif

