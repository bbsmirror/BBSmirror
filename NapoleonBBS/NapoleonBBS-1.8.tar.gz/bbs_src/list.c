/*
 *   �ϥΪ̦C��......begin
 */

#include "bbs.h"
#define	BBS_PAGESIZE    (20)
#define refreshtime	(30)
time_t	update_time=0;
int	friendmode=0;
int	freshmode=0;
int	page;
int	actor = 0;

struct pkuser
{
   struct  user_info	*ui;
   int	   myfriend;
   int	   friendme;
};


int
getfriend()
{
    int	nf,i,unum,j;
    int	myfriends[MAXFRIENDS];
    struct friend *topfriend;
    char buf[80];

    setuserfile( buf, "overrides" );
    nf = get_num_records( buf,sizeof(struct friend));
    if(nf <= 0)
        return 0 ;
    nf = (nf >= MAXFRIENDS) ? MAXFRIENDS:nf;
    topfriend = (struct friend *)calloc(sizeof(struct friend),nf);
    get_records( buf, topfriend,sizeof(struct friend),1,nf);
    j=0;
    memset(myfriends, 0, sizeof(myfriends));
    /*��X�ϥΪ̧Ǹ�*/
    for( i=0; i<nf; i++){
       if( (unum = (int)searchuser(topfriend[i].id)) > 0 ){
         myfriends[j]= unum;
         j++;
       }
    }
    memcpy(uinfo.friend, myfriends, sizeof(myfriends));
    free(topfriend);
}


/* �ڪ��n�� */
int
my_friend(ui)
struct user_info *ui;
{
   register int unum, *friends;
   
   friends = uinfo.friend;
   while(unum = *friends++) 
      if(unum == ui->uid)
	  return 1;

   return 0;   
}

/*�P�ڬ���*/
int
friend_me(ui)
struct user_info *ui;
{

   register int unum, *friends;
   
   friends = ui->friend;
   while( unum = *friends++ )
      if( unum == uinfo.uid )
         return 1;
         
   return 0;

}


char
pagerchar(friend, pager)
int friend, pager;
{
    if (pager&ALL_PAGER) return ' ';
    if ((friend)) {
        if(pager&FRIEND_PAGER)
                return 'O';
        else
                return '*';
    }
    return '*';
}

int
do_userlist(pkentp)
struct pkuser pkentp;
{       
    static	int i;
    char	user_info_str[STRLEN*2];
    int		override;
    char	*overrideflag[2]={"","[1;32m"};
    struct user_info	*uentp;

    uentp = pkentp.ui;
    if( uentp == NULL ) {
        char title_str[ 160 ];
        char *field[2]={"�ϥΪ̰κ�","�u��m�W  "} ;

    	showansi=1;
    	move(2,0);
    	clrtoeol();
    	sprintf( title_str,
    	    "%5s%-12.12s %-16.16s %-16.16s %c %c %-16.16s %5s\n",
    	    " �s�� ","�ϥΪ̥N��", field[currentuser.address[STRLEN-3]], "�Ӧ�", 'P',
    	    (HAS_PERM(PERM_SEECLOAK) ? 'C' : ' '), "�ʺA",
#ifdef SHOW_IDLE_TIME
    	    "��:��" );
#else
    	    "" );
#endif
    	standout();
    	prints( "%s", title_str );
    	standend();
        i = 0;
        return 0;
    }
    if(!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
        return 0;
    override=pkentp.myfriend;
    if( i < page ||i >= page + BBS_PAGESIZE || i >= actor){
        i++;
        return 0;
    }
    if( !uentp->active || !uentp->pid ){
        clrtoeol();
        prints("    -- ���ϥΪ̤w�g���u --\n");
        i++;
        return 0;
    }

    sprintf( user_info_str,
        " %4d %s%-12.12s[m %-16.16s %-16.16s %c %c %-16.16s %5.5s\n",
        i+1,overrideflag[override],uentp->userid,
        (currentuser.address[STRLEN-3]) ? uentp->realname:uentp->username,
        (uentp->pager&ALL_PAGER || HAS_PERM(PERM_SYSOP))? uentp->from : "*",
        pagerchar( pkentp.friendme, uentp->pager),
        (uentp->invisible ? '#' : ' '),
        modestring(uentp->mode, uentp->destuid, 1,
                (uentp->in_chat ? uentp->chatid : NULL)),
#ifdef SHOW_IDLE_TIME
        idle_str(uentp) );
#else
        "" );
       override);
#endif
    clrtoeol();
    prints( "%s", user_info_str );
    i++ ;
    return 0 ;
}

struct	pkuser	user_record[USHM_SIZE];

int
do_ulist()
{
    int	i;

    for( i = 0; i < actor; i++ ) {
	if( do_userlist(user_record[i]) == QUIT )
	    return QUIT;
    }
    return 0;
}

int
cmpulist(i, j)
struct	pkuser  *i, *j;
{

  if( i->myfriend - j->myfriend == 0){
     return strcasecmp(i->ui->userid, j->ui->userid);
  }else {
     if( i->myfriend == 1 )
        return -1;
     else return 1;
  }
}


int
fill_ulist()
{

  int	i;
  extern struct UTMPFILE  *utmpshm;
  struct user_info *uentp;
 
  actor = 0;
  for( i= 0; i< USHM_SIZE; i++ ){
     uentp = &(utmpshm->uinfo[i]);
     if( !uentp->active || !uentp->pid )
       	  continue;
     if(!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
          continue;
     user_record[actor].ui = uentp;
     user_record[actor].myfriend = my_friend(uentp);
     user_record[actor].friendme = friend_me(uentp);
     if( friendmode && !user_record[actor].myfriend )
         actor--;
     actor++;
  }
  if(!actor) return 0;
  qsort(user_record, actor, sizeof(struct pkuser), cmpulist);
}


int
show_userlist()
{   

    if( update_time + refreshtime < time(0) ){
         update_time=time(0);
    }
    do_userlist(NULL);
    if( actor==0 || do_ulist() == -1 ) {
        move(2,0);
        prints( "�S���ϥΪ̡]�B�͡^�b�C����...\n" );
        pressanykey();
        return -1;
    }
    clrtobot();
    return 1;
}




void
t_rusers()
{
    currentuser.address[STRLEN-3] = 1;
    t_users();
    currentuser.address[STRLEN-3] = 0;
}


void
update_data()
{
        page=-1;
        if(time(0)>=update_time+refreshtime-1){
                freshmode=1;
        }
        signal(SIGALRM, update_data);
        alarm(refreshtime);
        return;
}


int
t_friends()
{
    FILE        *fp;
    char        genbuf[STRLEN];
    extern	int		count_friends;
    
    modify_user_mode(FRIEND);
    friendmode=1;
    setuserfile( genbuf, "overrides" );
    if ((fp = fopen(genbuf, "r")) == NULL) {
        move( 1, 0 );
        clrtobot();
        prints("�A�|���Q�� Info -> Override �]�w�n�ͦW��A�Х� override �]�w�n�ͦW��\n");
        pressreturn();
        return ;
    }
    fclose(fp);
    actor=1;
    choose();
    clrtobot() ;
    friendmode=0;
    return;
}



int
t_users()
{
    friendmode=0;
    modify_user_mode(LUSERS);
    report("users");
    update_time=0;
    actor=1;
    choose();
    return 0;
}


int
choose()
{
    int	ch, num, number;
    register	int	do_command;
    register	struct	user_info  *uentp;
  
    clear();
     docmdtmp((friendmode)?"[�n�B�ͦC��]":"[�ϥΪ̦C��]",
     " ���[t,��] �H�H[m] �e�T��[s] �[,��B��[o,d] �ݭp����[r] �����Ҧ�[f] �D��[h]");
    update_data();     
    page=-1;
    num=0;
    number=0;
    do_command=0;
    while( 1 ) {
        if( num < 0 )  num = 0;
        if( num >= actor )  num = actor - 1;
        if( page < 0||freshmode==1 ) {
            freshmode=0;
            page = (num / BBS_PAGESIZE) * BBS_PAGESIZE;
            move(3,0);clrtobot();
            fill_ulist();
            if(show_userlist()==-1)
                return -1;
        }
        if( num < page || num >= page + BBS_PAGESIZE ) {
            page = (num / BBS_PAGESIZE) * BBS_PAGESIZE;
            move(3,0);clrtobot();
            if(show_userlist()==-1)
                return -1;
        }
        move( 3+num-page,0 ); prints( "��" );
        ch = egetch();
        move( 3+num-page,0 ); prints( "  " );

	if( ch == 'q' || ch == 'e' || ch == KEY_LEFT || ch == EOF )
	    break;        
        switch( ch ) {
            case 'P': case 'b': case Ctrl('B'): case KEY_PGUP:
                if( num == 0 )  num = actor - 1;
                else  num -= BBS_PAGESIZE;
                break;
            case 'N': case Ctrl('F'): case KEY_PGDN: case ' ':
                if( num == actor - 1 )  num = 0;
                else  num += BBS_PAGESIZE;
                break;
            case 'p': case 'l': case KEY_UP:
                if( num-- <= 0 )  num = actor - 1;
                break;

            case 'n': case 'j': case KEY_DOWN:
                if( ++num >= actor )  num = 0;
                break;
            case '\n': case '\r':
                if( number > 0 ) {
                    num = number - 1;
                    move(t_lines-1);
                    clrtoeol();
                    break;
                }
            case 't': case 'T': case KEY_RIGHT:
            case 'k': case 'K': case 'h': case 'H':
            case 'm': case 'M': case 'i': case 'I':
            case 'f': case 'F': case 's': case 'S':
            case 'o': case 'O': case 'd': case 'D':
            case 'r': case 'Q': case KEY_TAB:
            	do_command=1;
            	break;
            case '$':
                num = actor - 1;       break;
            default:
                ;
        }
        if( ch >= '0' && ch <= '9' ) {
            number = number * 10 + (ch - '0');
            move(t_lines-1,0);
            clrtoeol();
            prints("%d",number);
            ch = '\0';
        } else {
            number = 0;
        }
        
        if(do_command==1){
              uentp = user_record[num].ui;
              switch(ch)
               {
                 case 'k': case'K':
                  if(!HAS_PERM(PERM_SYSOP))
                        return 1;
                  kick_user(uentp->userid);
                        break;
                 case 'h':case 'H':
                      ansimore("etc/userlisthelp",YEA );
                      clear();
                      break;
                 case 'm': case'M':
                      if(!HAS_PERM(PERM_POST))
                          return 1;
                      my_send(uentp->userid);
                      break;
                 case 'i': case 'I':
                       if(!HAS_PERM(PERM_SYSOP))
                           return 1;
                       my_info(uentp->userid);
                       break;
                 case 'f': case 'F':
                      if(friendmode)
                           friendmode=0; /*�n��/�ϥΪ̦C���ഫ*/
                       else
                           friendmode=1;
                       fill_ulist();
                       break;
                 case '\r': case '\n':
                 case 't': case 'T': case KEY_RIGHT:                 
          	       if(!HAS_PERM(PERM_PAGE))
             	           break;
               	       uentp = user_record[num].ui;
          	       if(strcmp(currentuser.userid, uentp->userid))
                           ttt_talk(uentp);
                       break;
                 case 's': case 'S':
                      if(!HAS_PERM(PERM_PAGE))
                            return 1;
                      do_sendmsg(uentp,NULL,NORMAL);
                      break;
                 case 'o': case 'O':
                      if(addtooverride(uentp->userid))
                          fill_ulist();
                      break;
                 case 'd': case'D':
                      if(deleteoverride(uentp->userid))
                           fill_ulist();
                      break;
                 case 'r':
                 case 'Q':
                     my_query(uentp->userid);
                     break;
                 case KEY_TAB :
                    if(!HAS_PERM(PERM_SYSOP))
                       return 1;
                     if(currentuser.address[STRLEN-3]==0)
                           currentuser.address[STRLEN-3]=1;
                     else currentuser.address[STRLEN-3]=0;
                    break;
                 default:
                     return 0;
              }

              if(friendmode)
                   modify_user_mode(FRIEND);
              else modify_user_mode(LUSERS);

              clrtobot();
              do_command=0;
	      if(show_userlist()==-1)
	          return -1;
              docmdtmp((friendmode)?"[�n�B�ͦC��]":"[�ϥΪ̦C��]",
                   " ���[t,��] �H�H[m] �e�T��[s] �[,��B��[o,d] �ݭp����[r] �����Ҧ�[f] �D��[h]");
          }
    }
    clear();
    return -1 ;
}

int
tell_friendme()
{

  struct user_info *usr;
  int	i;
  extern  struct UTMPFILE *utmpshm;
  char	buf[100];
 
  for( i= 0; i< USHM_SIZE; i++ ){
     usr = &(utmpshm->uinfo[i]);
     if( !usr->active || !usr->pid )
       	  continue;
     if( usr->uid == uinfo.uid )
     	  continue;
     if( friend_me(usr) && ((usr->pager&ALL_PAGER)||(usr->pager&FRIEND_PAGER)) ){
     	  sprintf(buf,"[0;1;44;37m�z���n�͡i%s�j(%s) �W�u�F[m", currentuser.userid, currentuser.username);
     	  do_sendmsg(usr, buf, NORMAL);
     }
  }
}

