/*
 *	userinfo.c
 */



#include "bbs.h"

extern time_t	login_start_time;
char	*genpasswd() ;

void
user_display( u, real )
struct userec *u ;
int	real;
{
    struct stat st;
    int		num, diff;
 
    showansi=1;
    move(3,0);
    clrtobot();
    prints("�z���N��     : [1;31m%s[m\n", u->userid);
    prints("�z���ʺ�     : [1;31m%s[m\n", u->username);
    prints("�u��m�W     : [1;32m%s[m\n", u->realname);
    prints("�~�����}     : [1;32m%s[m\n", u->address);
    prints("�q�l�l��H�c : [1;33m%s[m\n", u->email);
    if( real ) {
	prints("�u�� E-mail  : %s\n", u->termtype + 16 );
	prints("Ident ���   : %s\n", u->ident );
    }
    prints("�׺ݾ��κA   : [1;33m%s[m\n", u->termtype );
    prints("���U���     : [1;34m%s[m", ctime( &u->firstlogin));
    prints("�̪���{��� : [1;34m%s[m", ctime( &u->lastlogin));
    if( real ) {
	prints("�̪���{���� : [1;35m%s[m\n", u->lasthost );
    }
    prints("�W������     : [1;35m%d[m ��\n", u->numlogins);
    prints("�峹�ƥ�     : [1;36m%d / %d[m (Board/1Discuss)\n",
           u->numposts, post_in_tin( u->userid ));

    sprintf( genbuf, "mail/%s/%s", u->userid, DOT_DIR );
    if( stat( genbuf, &st ) >= 0 )
	num = st.st_size / (sizeof( struct fileheader ));
    else
	num = 0;
    prints("�p�H�H�c     :[1;36m %d ��[m\n", num );

    if( real ) {
	strcpy( genbuf, "bTCPRp#@XWBA#VS-" );
	for( num = 0; num < 16; num++ )
	    if( !(u->userlevel & (1 << num)) )
		genbuf[num] = '-';
	genbuf[num] = '\0';
	prints("�ϥΪ��v��   : %s\n", genbuf );
    } else {
	diff = (time(0) - login_start_time) / 60;
	prints("���d����     : [1;32m%d �p�� %02d ��[m\n", diff / 60, diff % 60 );
	prints("�ù��j�p     : [1;32m%dx%d[1;36m\n", t_lines, t_columns );
    }
    prints("\n");
    if( u->userlevel & PERM_LOGINOK ) {
	prints("  �z�����U�{�Ǥw�g����, �w��[�J����.\n");
    } else if( u->lastlogin - u->firstlogin < 3 * 86400 ) {
	prints("  �s��W��, �о\\Ū Announce �Q�װ�, �T�ѫ�}���v��.\n" );
    } else {
	prints("  ���U�|�����\\, �аѦҥ����i���e������.\n");
    }
    showansi=0;
}

int
uinfo_query( u, real, unum )
struct userec *u ;
int	real, unum;
{
    struct userec	newinfo;
    char	ans[2], buf[ STRLEN ];
    int		i, fail = 0;
    char	regbuf[STRLEN];

    modify_user_mode(FORM);
    memcpy( &newinfo, u, sizeof(currentuser));
    getdata( t_lines-1, 0, real ?
	"�п�� (0)���� (1)�ק��� (2)�]�w�K�X (3) �� ID ==> [0]" :
	"�п�� (0)���� (1)�ק��� (2)�]�w�K�X ==> [0]",
	ans, 2, DOECHO, NULL );
    clear();
    refresh();
    
    regbuf[0] == '\0';
    i = 3;
    move( i++, 0 );
    prints("�ϥΪ̥N��: %s\n", u->userid );

    switch( ans[0] ) {
	case '1':
	    move( 1, 0 );
	    prints("�гv���ק�,������ <ENTER> �N���ϥ� [] ������ơC\n");

	    sprintf( genbuf, "�ʺ� [%s]: ", u->username );
	    getdata( i++, 0, genbuf, buf, NAMELEN, DOECHO, NULL );
	    if( buf[0] )strncpy( newinfo.username, buf, NAMELEN );

	    sprintf( genbuf, "�u��m�W [%s]: ", u->realname );
	    getdata( i++, 0, genbuf, buf, NAMELEN, DOECHO, NULL );
	    if( buf[0] )   strncpy( newinfo.realname, buf, NAMELEN );

	    sprintf( genbuf, "�~���a�} [%s]: ", u->address );
	    getdata( i++, 0, genbuf, buf, STRLEN, DOECHO, NULL );
	    if( buf[0] ) strncpy( newinfo.address, buf, NAMELEN );

	    sprintf( genbuf, "�q�l�H�c [%s]: ", u->email );
	    getdata( i++, 0, genbuf, regbuf, STRLEN, DOECHO, NULL );
	    if( regbuf[0] ) strncpy( newinfo.email, regbuf, STRLEN );

	    sprintf( genbuf, "�׺ݾ��κA [%s]: ", u->termtype );
	    getdata( i++, 0, genbuf, buf, 16, DOECHO, NULL );
	    if( buf[0] ) strncpy( newinfo.termtype, buf, 16 );


	if( real ) {
	    sprintf( genbuf, "�u��Email[%s]: ", u->termtype+16 );
	    getdata( i++, 0, genbuf, buf, STRLEN, DOECHO, NULL );
	    if( buf[0] ) strncpy( newinfo.termtype+16, buf, STRLEN-16 );

	    sprintf( genbuf, "�W�u���� [%d]: ", u->numlogins );
	    getdata( i++, 0, genbuf, buf, 16, DOECHO, NULL );
	    if( atoi( buf ) > 0 ) newinfo.numlogins = atoi( buf );

	    sprintf( genbuf, "�峹�ƥ� [%d]: ", u->numposts );
	    getdata( i++, 0, genbuf, buf, 16, DOECHO, NULL );
	    if( atoi( buf ) > 0 ) newinfo.numposts = atoi( buf );
	}

	    break;
	case '2':
	    if( ! real ) {
		getdata(i++,0,"�п�J��K�X: ",buf,PASSLEN,NOECHO,NULL);
		if( *buf == '\0' || !checkpasswd( u->passwd, buf )) {
		    prints("\n\n�ܩ�p, �z��J���K�X�����T�C\n");
		    fail++;
		    break;
		}
	    }
	    getdata(i++,0,"�г]�w�s�K�X: ",buf,PASSLEN,NOECHO,NULL);
	    if( buf[0] == '\0' ) {
		prints("\n\n�K�X�]�w����, �~��ϥ��±K�X\n");
		fail++;
		break;
	    }
	    strncpy(genbuf,buf,PASSLEN) ;

	    getdata(i++,0,"�Э��s��J�s�K�X: ",buf,PASSLEN,NOECHO,NULL);
	    if(strncmp(buf,genbuf,PASSLEN)) {
		prints("\n\n�s�K�X�T�{����, �L�k�]�w�s�K�X�C\n");
		fail++;
		break;
	    }
	    buf[8] = '\0';
	    strncpy( newinfo.passwd, genpasswd( buf ), PASSLEN );
	    break;
	case '3':
	    if( ! real ) {
		clear();
		return 0;
	    }
	    getdata(i++,0,"�s���ϥΪ̥N��: ",genbuf,IDLEN,DOECHO,NULL);
	    if(*genbuf != '\0') {
		if(getuser(genbuf)) {
		    prints("\n���~! �w�g���P�� ID ���ϥΪ�\n") ;
		    fail++;
		} else {
		    strncpy(newinfo.userid, genbuf,IDLEN+2) ;
		}
	    }
	    break;
	default:
	    clear();
	    return 0;
    }
    if( fail != 0 ) {
	pressreturn();
	clear();
	return 0;
    }
    getdata(t_lines-1,0,"�T�w�n���ܶ�?  (Yes or No) [N]: ",ans,2,DOECHO,NULL);
    if( *ans == 'y' || *ans == 'Y' ) {
	if( strcmp( u->userid, newinfo.userid ) ) {
	    char src[ STRLEN ], dst[ STRLEN ];

	    sprintf( src, "mail/%s", u->userid );
	    sprintf( dst, "mail/%s", newinfo.userid );
	    rename( src, dst );
	    sethomepath( src, u->userid );
	    sethomepath( dst, newinfo.userid );
	    rename( src, dst );
	    setuserid( unum, newinfo.userid );
	}
        if(valid_ident(newinfo.email) && regbuf[0] && !invalidaddr(newinfo.email) ){ /* �o�X�����T�{�H  */
            time_t	regtime;
            char		title[STRLEN];
            FILE		*dp;

  	    newinfo.termtype[16]='\0';
            regtime=time(NULL);
            sprintf(genbuf,"home/%s/mailcheck",currentuser.userid);
            if((dp=fopen(genbuf,"w"))==NULL) {
                fclose(dp);
                return;
            }
            fprintf(dp,"%d\n",regtime);
            fclose(dp);
            sprintf(genbuf,"tmp/regmail_%s",currentuser.userid);
            if(dashf(genbuf))
                unlink(genbuf);
            sprintf(title,"[%d] NCTUIEM bbsuser checkmail",regtime);
            bbsreg_sendmail("etc/bbsregister",title,newinfo.email); 
        }
	memcpy( u, &newinfo, sizeof(newinfo) );
	substitute_record( PASSFILE, &newinfo, sizeof(newinfo), unum );
	report("change userinfo");
    }
    clear();
    return 0;
}

void
x_info()
{
    user_display( &currentuser, 0 );
    if (!strcmp("guest", currentuser.userid)) {
        pressreturn();
        return;
    }
    uinfo_query( &currentuser, 0, usernum );
}

void
getfield( line, info, desc, buf, len )
int	line, len;
char	*info, *desc, *buf;
{
    char	prompt[ STRLEN ];

    sprintf( genbuf, "  ����]�w: %-46.46s (%s)", buf, info );
    move( line, 0 );
    prints( genbuf );
    sprintf( prompt, "  %s: ", desc );
    getdata( line+1, 0, prompt, genbuf, len, DOECHO, NULL );
    if( genbuf[0] != '\0' ) {
	strncpy( buf, genbuf, len );
    }
    move( line, 0 );
    clrtoeol();
    prints( "  %s: %s\n", desc, buf );
    clrtoeol();
}

void
x_fillform()
{
    char	rname[ NAMELEN ], addr[ STRLEN ];
    char	phone[ STRLEN ], career[ STRLEN ];
    char        Sysop[10];
    char	ans[3], *mesg, *ptr,me[3],getmetmp[3];
    FILE	*fn;
    time_t	now;
    int         getme;

    move( 3, 0 );
    clrtobot();
    modify_user_mode(FORM);
    if (!strcmp("guest", currentuser.userid)) {
	prints( "��p, �Х� new �ӽФ@�ӷs�b����A��ӽЪ�." );
        pressreturn();
        return;
    }
    if( currentuser.userlevel & PERM_LOGINOK ) {
	prints( "�z�������T�{�w�g���\\, �w��[�J��������C." );
        pressreturn();
        return;
    }
    if( (fn = fopen( "new_register", "r" )) != NULL ) {
	while( fgets( genbuf, STRLEN, fn ) != NULL ) {
	    if( (ptr = strchr( genbuf, '\n' )) != NULL )
		*ptr = '\0';
	    if( strncmp( genbuf, "userid: ", 8 ) == 0 &&
		strcmp( genbuf + 8, currentuser.userid ) == 0 ) {
		fclose( fn );
		prints( "�����|���B�z�z�����U�ӽг�, �Э@�ߵ���." );
		pressreturn();
		return;
	    }
	}
	fclose( fn );
    }
    getdata(3,0,"�z�T�w�n��g���U��� (Y/N)? [N]: ",ans,3,DOECHO,NULL);
    if( ans[0] != 'Y' && ans[0] != 'y' )
	return;
    strncpy( rname, currentuser.realname, NAMELEN );
    strncpy( addr,  currentuser.address,  STRLEN  );
    career[0] = phone[0] = '\0';
    while( 1 ) {
	move( 3, 0 );
	clrtoeol();
	prints( "%s �A�n, �оڹ��g�H�U�����:\n", currentuser.userid ); 
	getfield(  6, "�ХΤ���",           "�u��m�W", rname, NAMELEN );
	getfield(  8, "�Ǯըt�ũγ��¾��", "�A�ȳ��", career,STRLEN );
	getfield( 10, "�]�A��ǩΪ��P���X", "�ثe���}", addr,  STRLEN );
	getfield( 12, "�]�A�i�s���ɶ�",     "�s���q��", phone, STRLEN );
	mesg = "�H�W��ƬO�_���T, �� Q �����U (Y/N/Quit)? [N]: ";
	getdata(t_lines-1,0,mesg,ans,3,DOECHO,NULL);
	if( ans[0] == 'Q' || ans[0] == 'q' )
	    return;
	if( ans[0] == 'Y' || ans[0] == 'y' )
	    break;
    }
    strncpy( currentuser.realname, rname,  NAMELEN );
    strncpy( currentuser.address,  addr,   STRLEN  );
    if( (fn = fopen( "new_register", "a" )) != NULL ) {
	now = time( NULL );
	fprintf( fn, "usernum: %d, %s",	usernum, ctime( &now ) );
	fprintf( fn, "userid: %s\n",	currentuser.userid );
	fprintf( fn, "realname: %s\n",	rname );
	fprintf( fn, "career: %s\n",	career );
	fprintf( fn, "addr: %s\n",	addr );
	fprintf( fn, "phone: %s\n",	phone );
	fprintf( fn, "----\n" );
	fclose( fn );
    }
clear();
}




int
kill_myself()
{
      int id ;


    stand_title( "�۱�!!!!!!! ([1;5;31mWARRNING!!!�p�ߨS�b��[m)" );
    bell();bell();bell();bell();bell();bell();
    modify_user_mode(ADMIN);
    move(1,0) ;
    
    strcpy(genbuf,currentuser.userid);

    if(!(id = getuser(genbuf))) {
	move(3,0) ;
	prints("Invalid User Id") ;
	clrtoeol() ;
	pressreturn() ;
	clear() ;
	return 0 ;
    }
    if (!isalpha(lookupuser.userid[0])) return 0;
    prints("�u�n�۱�",genbuf) ;
    clrtoeol();
    getdata(2,0,"(Yes, or No) [N]: ",genbuf,4,DOECHO,NULL) ;
    if(genbuf[0] != 'Y' && genbuf[0] != 'y') { /* if not yes quit */
	move(2,0) ;
	prints("Aborting delete User\n") ;
	pressreturn() ;
	clear() ;
	return 0 ;
    }

    sprintf(genbuf, "deleted user %s", lookupuser.userid);
    report(genbuf);

    sprintf(genbuf,"/bin/rm -fr mail/%s", lookupuser.userid) ;
    system(genbuf) ;
    sprintf(genbuf,"/bin/rm -fr home/%s", lookupuser.userid) ;
    system(genbuf) ;
    lookupuser.userid[0] = '\0' ;
    substitute_record(PASSFILE,&lookupuser,sizeof(lookupuser),id) ;
    setuserid( id, lookupuser.userid );
    move(2,0) ;
    prints("�A���F, �ڪ��B��\n") ;
    pressreturn() ;
    clear() ;
    log_usies( "KILL_myself" , "���F");
    u_exit() ;
    reset_tty() ;
    exit(0) ;
}


