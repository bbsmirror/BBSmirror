/*
 *	comm_lists.c
 */




#include "bbs.h"

#define SC_BUFSIZE		10240
#define SC_KEYSIZE		256
#define SC_CMDSIZE		256
#define sysconf_ptr( offset )	(&sysconf_buf[ offset ]);

extern time_t   login_start_time;


struct smenuitem {
    int		line, col, level;
    char	*name, *desc, *arg;
    int		(*fptr)();
} *menuitem;


struct sdefine {
    char	*key, *str;
    int		val;
} *sysvar;

char	*sysconf_buf;
int	sysconf_menu, sysconf_key, sysconf_len;

int	domenu();
int	Announce(), Boards(), EGroup(), TUsers(), Info(), Goodbye();
int	Help(), New(), Post(), Read(), Select(), Users(), Welcome();
int	Conditions(), x_cloak(), t_users(), x_info(), x_fillform(), x_vote();
int	x_results(), ent_bnet(), EditWelcome(), x_editsig(), x_editplan();
int	x_date(),x_forward(),s_msg(),m_note(),v_msg(),wall(),x_Iscolor();
int	m_new(), m_read(), m_send(), m_internet(), m_gsend();

int	t_users(), t_friends(), t_rusers(), t_list(), t_monitor();
int	t_query(), t_talk(), t_pager(), t_override(), x_cloak();
int	ent_chat(), kick_user(), kill_myself();

int	x_level(), m_info(), d_user(), m_register(), m_newbrd();
int	d_board(), m_editbrd(), m_mclean(), m_trace(), m_vote();

struct scommandlist {
    char	*name;
    int		(*fptr)();
} sysconf_cmdlist[] = {
	"domenu",	domenu,

	"EGroups",	EGroup,
	"BoardsAll",	Boards,
	"BoardsNew",	New,
	"LeaveBBS",	Goodbye,
	"Announce",	Announce,
	"ShowAllUsers", TUsers,
	"SelectBoard",	Select,
	"ReadBoard",	Read,
	"PostArticle",	Post,
	"SetHelp",	Help,

	"ReadNewMail",	m_new,
	"ReadMail",	m_read,
	"SendMail",	m_send,
	"SendNetMail",	m_internet,
	"GroupMail",	m_gsend,

	"ShowFriends",	t_friends,
	"ShowLogins",	t_users,
	"QueryUser",	t_query,
	"Talk",		t_talk,
	"SetPager",	t_pager,
	"SetCloak",	x_cloak,
	"SendMsg",	s_msg,
	"ViewMsg",	v_msg,
	"Wall",		wall,
	
	"SetFriends",	t_override,
	"EnterChat",	ent_chat,
	"ListLogins",	t_list,
	"Monitor",	t_monitor,
	"RealLogins",	t_rusers,

	"FillForm",	x_fillform,
	"SetInfo",	x_info,
	"EditSig",	x_editsig,
	"EditPlan",	x_editplan,
	"Iscolor",	x_Iscolor,

	"ShowLicense",	Conditions,
	"ShowVersion",	Info,
	"ShowDate",	x_date,
	"DoVote",	x_vote,
	"VoteResult",	x_results,
	"Forward",	x_forward,
	"ExecBBSNet",	ent_bnet,
	"ShowWelcome",	Welcome,
	"SpecialUser",	Users,

	"CheckForm",	m_register,
	"ModifyInfo",	m_info,
	"ModifyLevel",	x_level,
	"KickUser",	kick_user,
	"DelUser",	d_user,
	"OpenVote",	m_vote,
	"NewBoard",	m_newbrd,
	"EditBoard",	m_editbrd,
	"DelBoard",	d_board,
	"SetTrace",	m_trace,
	"CleanMail",	m_mclean,
	"EditWelcome",	EditWelcome,
        "Killmyself",	kill_myself,
        "sys_note",	m_note,

       
	NULL,		NULL
};





void
encodestr( str )
register char *str;
{
    register char	ch, *buf;
    int			n;

    buf = str;
    while( (ch = *str++) != '\0' ) {
	if( *str == ch && str[1] == ch && str[2] == ch ) {
	    n = 4;
	    str += 3;
	    while( *str == ch && n < 100 ) {
		str++;
		n++;
	    }
	    *buf++ = '\01';
	    *buf++ = ch;
	    *buf++ = n;
	} else
	    *buf++ = ch;
    }
    *buf = '\0';
}


void
decodestr( str )
register char *str;
{
    register char	ch;
    int		n;

    while( (ch = *str++) != '\0' )
	if( ch != '\01' )
	    outc( ch );
	else if( *str != '\0' && str[1] != '\0' ) {
	    ch = *str++;
	    n =  *str++;
	    while( --n >= 0 )
		outc( ch );
	}
}



void *
sysconf_funcptr( func_name )
char	*func_name;
{
    int		n = 0;
    char	*str;

    while( (str = sysconf_cmdlist[n].name) != NULL ) {
	if( strcmp( func_name, str ) == 0 )
	    return( sysconf_cmdlist[n].fptr );
	n++;
    }
    return NULL;
}

void *
sysconf_addstr( str )
char	*str;
{
    int		len = sysconf_len;
    char	*buf;

    buf = sysconf_buf + len;
    strcpy( buf, str );
    sysconf_len = len + strlen( str ) + 1;
    return buf;
}



char *
sysconf_str( key )
char	*key;
{
    int		n;

    for( n = 0; n < sysconf_key; n++ )
	if( strcmp( key, sysvar[n].key ) == 0 )
	    return( sysvar[n].str );
    return NULL;
}



int
sysconf_eval( key )
char	*key;
{
    int		n;

    for( n = 0; n < sysconf_key; n++ )
	if( strcmp( key, sysvar[n].key ) == 0 )
	    return( sysvar[n].val );
    if( *key < '0' || *key > '9' ) {
	sprintf( genbuf, "sysconf: unknown key: %s.", key );
	report( genbuf );
    }
    return( strtol( key, NULL, 0 ) );
}



void
sysconf_addkey( key, str, val )
char	*key, *str;
int	val;
{
    int		num;

    if( sysconf_key < SC_KEYSIZE ) {
	if( str == NULL )  str = sysconf_buf;
	else  str = sysconf_addstr( str );
	num = sysconf_key++;
	sysvar[ num ].key = sysconf_addstr( key );
	sysvar[ num ].str = str;
	sysvar[ num ].val = val;
    }
}



void
sysconf_addmenu( fp, key )
FILE	*fp;
char	*key;
{
    struct smenuitem	*pm;
    char	buf[ STRLEN * 2 ];
    char	*cmd, *arg[5], *ptr;
    int		n;


    sysconf_addkey( key, "menu", sysconf_menu );
    while( fgets( buf, sizeof( buf ), fp ) != NULL && buf[0] != '%' ) {
	cmd = strtok( buf, " \t\n" );
	if( cmd == NULL || *cmd == '#' ) {
	    continue;
	}
	arg[0] = arg[1] = arg[2] = arg[3] = arg[4] = "";
	n = 0;
	for( n = 0; n < 5; n++ ) {
	    if( (ptr = strtok( NULL, ",\n" )) == NULL )
		break;
	    while( *ptr == ' ' || *ptr == '\t' )  ptr++;
	    if( *ptr == '"' ) {
		arg[n] = ++ptr;
		while( *ptr != '"' && *ptr != '\0' )  ptr++;
		*ptr = '\0';
	    } else {
		arg[n] = ptr;
		while( *ptr != ' ' && *ptr != '\t' && *ptr != '\0' )
		    ptr++;
		*ptr = '\0';
	    }
	}
	pm = &menuitem[ sysconf_menu++ ];
	pm->line  = sysconf_eval( arg[0] );
	pm->col   = sysconf_eval( arg[1] );
	if( *cmd == '@' ) {
	    pm->level = sysconf_eval( arg[2] );
	    pm->name  = sysconf_addstr( arg[3] );
	    pm->desc  = sysconf_addstr( arg[4] );
	    pm->fptr  = sysconf_addstr( cmd+1 );
	    pm->arg   = pm->name;
	} else if( *cmd == '!' ) {
	    pm->level = sysconf_eval( arg[2] );
	    pm->name  = sysconf_addstr( arg[3] );
	    pm->desc  = sysconf_addstr( arg[4] );
	    pm->fptr  = sysconf_addstr( "domenu" );
	    pm->arg   = sysconf_addstr( cmd+1 );
	} else {
	    pm->level = -2;
	    pm->name  = sysconf_addstr( cmd );
	    pm->desc  = sysconf_addstr( arg[2] );
	    pm->fptr  = (void *)sysconf_buf;
	    pm->arg   = sysconf_buf;
	}
    }
    pm = &menuitem[ sysconf_menu++ ];
    pm->name = pm->desc = pm->arg = sysconf_buf;
    pm->fptr = (void *)sysconf_buf;
    pm->level = -1;
}



void
sysconf_addblock( fp, key )
FILE	*fp;
char	*key;
{
    char	buf[ STRLEN ];
    int		num;

    if( sysconf_key < SC_KEYSIZE ) {
	num = sysconf_key++;
	sysvar[ num ].key = sysconf_addstr( key );
	sysvar[ num ].str = sysconf_buf + sysconf_len;
	sysvar[ num ].val = -1;
	while( fgets( buf, sizeof( buf ), fp ) != NULL && buf[0] != '%' ) {
	    encodestr( buf );
	    strcpy( sysconf_buf + sysconf_len, buf );
	    sysconf_len += strlen( buf );
	}
	sysconf_len++;
    } else {
	while( fgets( buf, sizeof( buf ), fp ) != NULL && buf[0] != '%' ) {
	}
    }
}



void
parse_sysconf( fname )
char *fname;
{
    FILE	*fp;
    char	buf[ STRLEN ];
    char	tmp[ STRLEN ], *ptr;
    char	*key, *str;
    int		val;

    if( (fp = fopen( fname, "r" )) == NULL ) {
	return;
    }
    sysconf_addstr( "(null ptr)" );
    while( fgets( buf, sizeof( buf ), fp ) != NULL ) {
	ptr = buf;
	while( *ptr == ' ' || *ptr == '\t' )  ptr++;
	
	if( *ptr == '%' ) {
	    strtok( ptr, " \t\n" );
	    if( strcmp( ptr, "%menu" ) == 0 ) {
		str = strtok( NULL, " \t\n" );
		if( str != NULL )
		    sysconf_addmenu( fp, str );
	    } else {
		sysconf_addblock( fp, ptr+1 );
	    }
	} else if( *ptr == '#' ) {
	    key = strtok( ptr, " \t\"\n" );
	    str = strtok( NULL, " \t\"\n" );
	    if( key != NULL && str != NULL &&
		strcmp( key, "#include" ) == 0 ) {
		parse_sysconf( str );
	    }
	} else if( *ptr != '\n' ) {
	    key = strtok( ptr, "=#\n" );
	    str = strtok( NULL, "#\n" );
	    if( key != NULL & str != NULL ) {
		strtok( key, " \t" );
		while( *str == ' ' || *str == '\t' )  str++;
		if( *str == '"' ) {
		    str++;
		    strtok( str, "\"" );
		    val = atoi( str );
		    sysconf_addkey( key, str, val );
		} else {
		    val = 0;
		    strcpy( tmp, str );
		    ptr = strtok( tmp, ", \t" );
		    while( ptr != NULL ) {
			val |= sysconf_eval( ptr );
			ptr = strtok( NULL, ", \t" );
		    }
		    sysconf_addkey( key, NULL, val );
		}
	    } else {
		report( ptr );
	    }
	}
    }
    fclose( fp );
}


void
build_sysconf( configfile, imgfile )
char	*configfile, *imgfile;
{
    struct smenuitem	*old_menuitem;
    struct sdefine	*old_sysvar;
    char		*old_buf;
    int			old_menu, old_key, old_len;
    struct sysheader {
	char	*buf;
	int	menu, key, len;
    } shead;
    int		fh;

    old_menuitem = menuitem;	old_menu = sysconf_menu;
    old_sysvar   = sysvar;	old_key  = sysconf_key;
    old_buf      = sysconf_buf;	old_len  = sysconf_len;
    menuitem    = (void *) malloc( SC_CMDSIZE * sizeof(struct smenuitem) );
    sysvar      = (void *) malloc( SC_KEYSIZE * sizeof( struct sdefine ) );
    sysconf_buf = (void *) malloc( SC_BUFSIZE );
    sysconf_menu = 0;
    sysconf_key  = 0;
    sysconf_len  = 0;
    parse_sysconf( configfile );
    if( (fh = open( imgfile, O_WRONLY|O_CREAT, 0644 )) > 0 ) {
	ftruncate( fh, 0 );
	shead.buf  = sysconf_buf;
	shead.menu = sysconf_menu;
	shead.key  = sysconf_key;
	shead.len  = sysconf_len;
	write( fh, &shead, sizeof( shead ) );
	write( fh, menuitem, sysconf_menu * sizeof(struct smenuitem) );
	write( fh, sysvar,   sysconf_key  * sizeof(struct sdefine) );
	write( fh, sysconf_buf, sysconf_len );
	close( fh );
    }
    free( menuitem );
    free( sysvar );
    free( sysconf_buf );
    menuitem    = old_menuitem; sysconf_menu = old_menu;
    sysvar      = old_sysvar;   sysconf_key  = old_key;
    sysconf_buf = old_buf;      sysconf_len  = old_len;
}




void
load_sysconf_image( imgfile )
char *imgfile;
{
    struct sysheader {
	char	*buf;
	int	menu, key, len;
    } shead;
    struct stat	st;
    char	*ptr, *func;
    int		fh, n, diff;

    if( (fh = open( imgfile, O_RDONLY )) > 0 ) {
	fstat( fh, &st );
	ptr = malloc( st.st_size );
	read( fh, &shead, sizeof( shead ) );
	read( fh, ptr, st.st_size );
	close( fh );

	menuitem = (void *) ptr;
	ptr += shead.menu * sizeof( struct smenuitem );
	sysvar = (void *) ptr;
	ptr += shead.key  * sizeof( struct sdefine );
	sysconf_buf = (void *) ptr;
	ptr += shead.len;
	sysconf_menu = shead.menu;
	sysconf_key  = shead.key;
	sysconf_len  = shead.len;
	diff = sysconf_buf - shead.buf;
	for( n = 0; n < sysconf_menu; n++ ) {
	    menuitem[n].name += diff;
	    menuitem[n].desc += diff;
	    menuitem[n].arg  += diff;
	    func = (char *) menuitem[n].fptr;
	    menuitem[n].fptr = sysconf_funcptr( func + diff );
	}
	for( n = 0; n < sysconf_key; n++ ) {
	    sysvar[n].key += diff;
	    sysvar[n].str += diff;
	}
    }
}



void
load_sysconf()
{
    if( dashf( "etc/rebuild.sysconf" ) || ! dashf( "sysconf.img" ) ) {
	report( "build sysconf.img" );
	build_sysconf( "etc/sysconf.ini", "sysconf.img" );
    }
    load_sysconf_image( "sysconf.img" );
}



int
domenu_screen( pm, cmdprompt)
struct smenuitem *pm;
int	cmdprompt;
{
    char	*str;
    int		help, line, col, num;

    clear();
    help = (currentuser.flags[0] & CURSOR_FLAG);
    line = 3;
    col  = 0;
    num  = 0;

    
    while( 1 ) {
	switch( pm->level ) {
	    case -1:
		showansi=1;
		return( num );
	    case -2:
		if( strcmp( pm->name, "title" ) == 0 ) {
		  if(iscolor)
	             docmdtitle( pm->desc, cmdprompt,0 );
	          else
	             docmdtmp( pm->desc, cmdprompt,0 );
		} else if( strcmp( pm->name, "screen" ) == 0 ) {
		    showansi=1;
		    if( help && (str = sysconf_str( pm->desc )) != NULL ) {
			move( pm->line, pm->col );
			decodestr( str );
		    }
		}
		break;
	    default:
		showansi=1;
		if( pm->line >= 0 && HAS_PERM( pm->level ) ) {
		    if( pm->line == 0 ) {
			pm->line = line;  pm->col = col;
		    } else {
			line = pm->line;  col = pm->col;
		    }
		    if( help ) {
			move( line, col+2 );
			prints( "%s", pm->desc );
		    }
		    line++;
		} else {
		    if( pm->line > 0 ) {
			line = pm->line;  col = pm->col;
		    }
		    pm->line = -1;
		}
	}
	num++;
	pm++;
    }
    move(t_lines-1,80);prints("[m");
    showansi=0;

}



int
domenu( menu_name )
char	*menu_name;
{
    extern int		refscreen;
    struct smenuitem	*pm;
    char	*cmdprompt = "�z�����: ";
    int		size, now;
    int		cmdplen, cmd, i;
    char        *menubuf;
    int		menunum,c=0;
#ifdef NAPOLEON
    char	*iem_flag[3]={"��","��","��"};
#endif

    menunum=atoi(menu_name);
    modify_user_mode(menunum);

    if( sysconf_menu <= 0 ) {
	return -1;
    }
    pm = &menuitem[ sysconf_eval( menu_name ) ];
    size = domenu_screen( pm, cmdprompt );
    cmdplen = strlen( cmdprompt );
    now = 0;
    if( strcmp( menu_name, "0" ) == 0 && chkomail(currentuser.userid) ) {
	for( i = 0; i < size; i++ )
	    if( pm[i].line > 0 && pm[i].name[0] == 'M' )
		now = i;
  
    }
   

 while ( 1 )    
     {
	
	while( pm[now].level < 0 || !HAS_PERM( pm[now].level ) ) {
	    now++;
	    if( now >= size )  now = 0;
	}

	move( 1, cmdplen );
	standout(); prints( "%s", pm[now].name );
	standend(); clrtoeol();
/*        currentuser.address[STRLEN-1]=strlen(pm[now].name);*/
	if( currentuser.flags[0] & CURSOR_FLAG ) {
	    c++;
	    move( pm[now].line, pm[now].col );
#ifdef NAPOLEON
	    prints("%s",iem_flag[c%3]);
#else
	    prints("��");
#endif	    
	    	    
	}
	move( 1, cmdplen+strlen(pm[now].name) );
/*	standout(); prints( "%s", pm[now].name );
	standend(); clrtoeol();*/
	cmd = egetch();
	if( currentuser.flags[0] & CURSOR_FLAG ) {
	    move( pm[now].line, pm[now].col );
	    prints( "  " );
	}

	switch( cmd ) {
	    case EOF:
		if( ! refscreen ) {
		    abort_bbs();
		}
               menunum=atoi(menu_name);
               modify_user_mode(menunum);
	       domenu_screen( pm, cmdprompt );

		break;
	    case KEY_RIGHT:
		for( i = 0; i < size; i++ ) {
		    if( pm[i].line == pm[now].line && pm[i].level >= 0 &&
			pm[i].col > pm[now].col && HAS_PERM( pm[i].level ) )
			break;
		}
		if( i < size ) {
		    now = i;
		    break;
		}
	    case '\n': case '\r':
		if( strcmp( pm[now].arg, ".." ) == 0 ) {
		    return 0;
		}
		if( pm[now].fptr != NULL ) {
		    move( 1, cmdplen );
		    clrtoeol();
		    (*pm[now].fptr)( pm[now].arg );
#ifndef NAPOLEON
		    if( pm[now].fptr == Select ) {
			now++;
		    }
#endif		    
                 menunum=atoi(menu_name);
                 modify_user_mode(menunum);                
     	         domenu_screen( pm, cmdprompt );
                }
		break;
	    case KEY_LEFT:
		for( i = 0; i < size; i++ ) {
		    if( pm[i].line == pm[now].line && pm[i].level >= 0 &&
			pm[i].col < pm[now].col && HAS_PERM( pm[i].level ) )
			break;
		    if( pm[i].fptr == Goodbye )
			break;
		}
		if( i < size ) {
		    now = i;
		    break;
		}
		return 0;
	    case KEY_DOWN:
		now++;
		break;
	    case KEY_UP:
		now--;
		while( pm[now].level < 0 || !HAS_PERM( pm[now].level ) ) {
		    if( now > 0 )  now--;
		    else  now = size - 1;
		}
		break;
	    case '~':
		if(!HAS_PERM(PERM_SYSOP)) {
		    break;
		}
		free( menuitem );
		report( "rebuild sysconf.img" );
		build_sysconf( "etc/sysconf.ini", "sysconf.img" );
		report( "reload sysconf.img" );
		load_sysconf_image( "sysconf.img" );
		pm = &menuitem[ sysconf_eval( menu_name ) ];
		size = domenu_screen( pm, cmdprompt );
		now = 0;
		break;
	    default:
		if( cmd >= 'a' && cmd <= 'z' )
		    cmd = cmd - 'a' + 'A';
		for( i = 0; i < size; i++ ) {
		    if( pm[i].line > 0 && cmd == pm[i].name[0] &&
			HAS_PERM( pm[i].level ) ) {
			now = i;
			break;
		    }
		}
           }	    
   }
 }           
           

