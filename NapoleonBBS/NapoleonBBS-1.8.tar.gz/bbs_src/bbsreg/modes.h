/*
 *    modes.h
 */



#define MMENU		0       /*  In order to use the current mode */
#define	SMENU		1       /*  i must use the menu so */
#define	AMENU		2        
#define TMENU		3
#define XMENU		4
#define MMAIL		5
#define	EMENU		6
#define IDLE		11	/* Modes a user can be in */
#define ULDL		12	/* see mode in struct user_info in bbs.h */
#define TALK		13
#define NEW		14
#define CHAT1		15
#define READNEW		16
#define POSTING		17
#define CHAT2		18
#define CHAT4		19
#define CHAT3		20
#define LAUSERS		21
#define LUSERS		22
#define SMAIL		23
#define RMAIL		24
#define MSG		25
#define READING		26
#define PAGE		27
#define ADMIN		28
#define READBRD		29
#define SELECT		30
#define LOGIN		31
#define MONITOR		32
#define EDITWELC	33
#define ZAP		34
#define EDITSIG		35
#define EDITPLAN	36
#define QUERY		37
#define CNTBRDS		38
#define VOTING		39
#define VISIT		40
#define IRCCHAT		41
#define BBSNET		42
#define FOURM		43
#define CSIE_GOPHER	44
#define CSIE_TIN	45
#define CSIE_ANNOUNCE	46
#define FRIEND		47
#define YANKING		48
#define RESULTS         49
#define WELCOME		50
#define	BYE		51
#define FORM		52
