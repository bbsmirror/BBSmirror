/*
 *	boards.c
 */



#include "bbs.h"

#define BBS_PAGESIZE	(t_lines - 5)

#define BRC_MAXSIZE	32768
#define BRC_MAXNUM	60
#define BRC_STRLEN	15
#define BRC_ITEMSIZE	(BRC_STRLEN + 1 + BRC_MAXNUM * sizeof( int ))
#define UNREAD_TIME	(login_start_time - 30 * 365 * 86400)

char	brc_buf[ BRC_MAXSIZE ];
int	brc_size, brc_changed = 0;
char	brc_name[ BRC_STRLEN ];
int	brc_list[ BRC_MAXNUM ], brc_num;

extern time_t	login_start_time;
extern int	numboards;
extern struct shortfile *bcache;


struct newpostdata {
    char	*name, *title, *BM;
    int		pos, total;
    char	unread, zap;
} *nbrd;

int	*zapbuf;
int	brdnum, yank_flag = 0;
char	*boardprefix;


void
EGroup( cmd )
char *cmd;
{
    char	buf[ STRLEN ];
    char	*sysconf_str();

    sprintf( buf, "EGROUP%c", *cmd );
    boardprefix = sysconf_str( buf );
    choose_board( 0 );
}



void
Boards()
{
    boardprefix = NULL;
    choose_board( 0 );
}

void
New()
{
    boardprefix = NULL;
    choose_board( 1 );
}


void
load_zapbuf()
{
    char	fname[ STRLEN ];
    int		fd, size, n;


    size = (numboards + 10) * sizeof( int );
    zapbuf = (int *) malloc( size );
    for( n = 0; n < numboards + 10; n++ )
	zapbuf[n] = 1;
    setuserfile( fname, ".lastread" );
    if( (fd = open( fname, O_RDONLY, 0600 )) != -1 ) {
	size = numboards * sizeof( int );
	read( fd, zapbuf, size );
	close( fd );
    }
}


void
save_zapbuf()
{
    char	fname[ STRLEN ];
    int		fd, size;

    setuserfile( fname, ".lastread" );
    if( (fd = open( fname, O_WRONLY | O_CREAT, 0600 )) != -1 ) {
	size = numboards * sizeof( int );
	write( fd, zapbuf, size );
	close( fd );
    }
}



int
load_boards()
{
    struct shortfile	*bptr;
    struct newpostdata	*ptr;
    char	buf[STRLEN];
    int		n;

    resolve_boards();
    if( zapbuf == NULL ) {
	load_zapbuf();
    }
    brdnum = 0;

    for( n = 0; n < numboards; n++ ) {
	bptr = &bcache[ n ];
	if( !(bptr->level & PERM_POSTMASK) && !HAS_PERM(bptr->level) )
	    continue;
	if( (bptr->level & PERM_SETREAD) && !HAS_PERM(PERM_SYSOP) )
	    if( !seek_b_record(bptr) )
	       continue;
	if( boardprefix != NULL &&
	    strchr( boardprefix, bptr->title[0]) == NULL )
	    continue;
	if( yank_flag || zapbuf[ n ] != 0 ) {
	    ptr = &nbrd[ brdnum++ ];
	    ptr->name  = bptr->filename;
	    ptr->title = bptr->title;
	    ptr->BM    = bptr->BM;
	    ptr->pos = n;
	    ptr->total = -1;
	    ptr->zap = (zapbuf[ n ] == 0);
	}
    }
    return 0;
}




int
check_newpost( ptr )
struct newpostdata *ptr;
{
    struct fileheader fh ;
    struct stat st;
    char        filename[ STRLEN ];
    int         fd, total;

    ptr->total = ptr->unread = 0;
    setbdir( genbuf, ptr->name );
    if( (fd = open( genbuf, O_RDWR )) < 0 )
        return 0;
    fstat( fd, &st );
    total = st.st_size / sizeof( fh );
    if( total <= 0 ) {
        close( fd );
        return 0;
    }
    ptr->total = total;
    if( !brc_initial( ptr->name ) ) {
        ptr->unread = 1;
    } else {
        lseek( fd,(off_t)  (total-1) * sizeof(fh), SEEK_SET );
        if( read( fd, filename, STRLEN ) > 0 && brc_unread( filename ) ) {
            ptr->unread = 1;
        }
    }
    close( fd );
    return 1;
}



int
unread_position( dirfile, ptr )
char    *dirfile;
struct newpostdata *ptr;
{
    struct fileheader fh ;
    char        filename[ STRLEN ];
    int         fd, step, num;

    num = ptr->total + 1;
    if( ptr->unread && (fd = open( dirfile, O_RDWR )) > 0 ) {
        if( !brc_initial( ptr->name ) ) {
            num = 1;
        } else {
            num = ptr->total - 1;
            step = 4;
            while( num > 0 ) {
                lseek( fd,(off_t)  num * sizeof(fh), SEEK_SET );
                if( read( fd, filename, STRLEN ) <= 0 ||
                    !brc_unread( filename ) )  break;
                num -= step;
                if( step < 32 )  step += step / 2;
            }
            if( num < 0 )  num = 0;
            while( num < ptr->total ) {
                lseek( fd,(off_t) num * sizeof(fh), SEEK_SET );
                if( read( fd, filename, STRLEN ) <= 0 || 
                    brc_unread( filename ) )  break;
                num ++;
            }
        }
        close( fd );
    }
    if( num < 0 )  num = 0;
    return num;
}



void
show_brdlist( page, clsflag, newflag )
int	page, clsflag, newflag;
{
    struct	newpostdata	*ptr;
    int		n,color,news_int;
    char	vote_flags[3] = " VR";
    char	*news_flag[2] = {"��","��"};
    extern	char	BoardName[STRLEN] ;


    if( clsflag ) {
	clear();
	if(iscolor)
           showtitle( "�Q�װϦC�� ", chkomail(currentuser.userid) ? "[1;41;5m[�z������]": BoardName );
        else
           titletmp( "�Q�װϦC�� ", chkomail(currentuser.userid) ? "[�z������]": BoardName );
        showansi=1;
	move(1,0);
	prints("[m�Q�װϦW��: ");
	showansi=0;
	move(2,0);
	prints("�j�M�r��: ");
        move(t_lines-1,0);
	prints("�D���[��,E,Q] �\\Ū[��,R] ���[��,��] �C�X[Y] �Ƨ�[S] ��ܼҦ�����[TAB] �D�U[H]" );
    }
    move(3,0); 
    standout();
    showansi=1;
    prints( " %s �Q�װϦW��     ��H ���O  %-24s    �O  �D        [m\n",
                newflag ? "���� ��Ū" : "�s�� �벼", "��  ��  ��  �z" );
    standend();
    move( 4, 0 );
    for( n = page; n < page + BBS_PAGESIZE; n++ ) {
	if( n >= brdnum ) {
	    prints( "\n" );
	    continue;
	}
	ptr = &nbrd[n];
	color=ptr->title[0]%7+31;
	news_int=atoi(&ptr->title[1]);
	if( !newflag ){
	    prints( " %4d %c", n+1, ptr->zap ? '-' : ' ' );
            prints( "%c   [1;%2dm%-16s[m%2s %-34s %-12.12s\n",
  	                vote_flags[ptr->BM[BM_LEN-1]],
	                color,ptr->name, news_flag[news_int], ptr->title + 2,
#ifdef NAPOLEON	                
	        	ptr->BM);
#else
	        	ptr->BM[0] <= ' ' ? "[�x�D��]" : ptr->BM);
#endif
         }
	else if( ptr->zap ) {
	    ptr->total = ptr->unread = 0;
	    prints( "    -    -" );
	    prints( " [1;%2dm%-16s[m%2s %-34s %-12.12s\n",
	    		color, ptr->name, news_flag[news_int] ,ptr->title + 2,
#ifdef NAPOLEON	                
	        	ptr->BM);
#else
	        	ptr->BM[0] <= ' ' ? "[�x�D��]" : ptr->BM);
#endif
	} else {
           if( ptr->total == -1 ) {
		refresh();
		check_newpost( ptr );
	    }
   	    prints( " %4d  %s ", ptr->total, ptr->unread ? "��" : "�C" );
	    prints( " [1;%2dm%-16s[m%2s %-34s %-12.12s\n",
	    	        color, ptr->name, news_flag[news_int] ,ptr->title + 2,
#ifdef NAPOLEON	                
	        	ptr->BM);
#else
	        	ptr->BM[0] <= ' ' ? "[�x�D��]" : ptr->BM);
#endif
	 }
    }
    refresh();    
    showansi=0;

}


int
cmpboard( brd, tmp )
struct newpostdata	*brd, *tmp;
{
    register int	type = 0;

    if( !(currentuser.flags[0] & BRDSORT_FLAG) )
	type = brd->title[0] - tmp->title[0];
    if( type == 0 )
	type = ci_strcmp( brd->name, tmp->name );
    return type;
}




int
choose_board( newflag )
int	newflag;
{
    static 	int	num;
    struct 	newpostdata newpost_buffer[ MAXBOARD ];
    struct	newpostdata *ptr;
    int		page, ch, tmp, number, tmpnum, c=0;
    void	brc_update();
    int		i = 0,find = YEA;
    char	bname[STRLEN];
    int		n,tmpn=NA,sort=0;

    if( !strcmp( currentuser.userid, "guest" ) )
	yank_flag = 1;
    nbrd = newpost_buffer;
    modify_user_mode( newflag ? READNEW : READBRD );
    brdnum = number = 0;
    show_brdlist( 0, 1, newflag );

    while( 1 ) {
	if( brdnum <= 0 ) {
	    load_boards();
	    qsort( nbrd, brdnum, sizeof( nbrd[0] ), cmpboard );
	    page = -1;
	    if( brdnum <= 0 )  break;
	}
	if( num < 0 )  num = 0;
	if( num >= brdnum )  num = brdnum - 1;
	if( page < 0 ) {
	    if( newflag ) {
		tmp = num;
		while( num < brdnum ) {
		    ptr = &nbrd[ num ];
		    if( ptr->total == -1 ) check_newpost( ptr );
		    if( ptr->unread )  break;
		    num++;
		}
		if( num >= brdnum )  num = tmp;
	    }
	    page = (num / BBS_PAGESIZE) * BBS_PAGESIZE;
       	    show_brdlist( page, 1, newflag );
            if(currentuser.address[STRLEN-8]){
                 move(2,0);
	         prints("�D���[��,e,q] �\\Ū[��,r] ���[��,��] �C�X[y] �Ƨ�[s] �j�M�Ҧ�����[TAB] �D�U[h]" );
                 move(t_lines-1,0);
		 clrtoeol();	    
             }
	}
	if( num < page || num >= page + BBS_PAGESIZE ) {
	    page = (num / BBS_PAGESIZE) * BBS_PAGESIZE;
	    show_brdlist( page, 0, newflag );
	    if(sort){
	    	redoscr();
	    	sort=0;
	    }
	}

        if (find == YEA) {
              bzero(bname, sizeof(bname));
              i=0;              
         } 
        move(1, 12);
        clrtoeol();
        standout();
        prints("%s",nbrd[num].name); 
        standend();	         

	if(!currentuser.address[STRLEN-8]){
            move(2, 10);
            clrtoeol();
            showansi=1;
            prints("[1m%s[m",bname); 
            showansi=0;
         }

	c++;
	move( 4+num-page,0 );
	prints( ">" );
        ch = egetch();
	move( 4+num-page,0 ); prints( " " );
	if(currentuser.address[STRLEN-8])
	  ch=chartoupper(ch);
	if( ch == 'Q' || ch == 'E' || ch == KEY_LEFT || ch == EOF || ch== 'I' )
	    break;
	switch( ch ) {
	    case 'P': case 'B': case Ctrl('B'): case KEY_PGUP:
		find=YEA;	    
		if( num == 0 )  num = brdnum - 1;
		else  num -= BBS_PAGESIZE;
		break;
            case Ctrl('N'): case ',':
                if(newflag==1)
                        newflag=0;
                else
                        newflag=1;
                show_brdlist( page, 0, newflag );
                break;		
	    case 'N': case ' ': case Ctrl('F'): case KEY_PGDN:
		find=YEA;	    
		if( num == brdnum - 1 )  num = 0;
		else  num += BBS_PAGESIZE;
		break;
	    case 'K': case KEY_UP:
		find=YEA;	    
		if( num-- <= 0 )  num = brdnum - 1;
		break;
	    case 'J': case KEY_DOWN:
		find=YEA;	    
		if( ++num >= brdnum )  num = 0;
		break;
	    case '$':
		find=YEA;	    
		num = brdnum - 1;	break;
	    case 'H':
		ansimore("etc/choosebrdhelp",YEA);
		page = -1;
		break;
	    case 'S':	/* sort/unsort -mfchen */
		find=YEA;	    
		currentuser.flags[0] ^= BRDSORT_FLAG;
		qsort( nbrd, brdnum, sizeof( nbrd[0] ), cmpboard );
		sort=1;
		page = 999;
		break;
	    case 'Y':
		find=YEA;	    	    
		yank_flag = !yank_flag;
		brdnum = -1;
	    	break;
	    case 'Z':
		if( HAS_PERM( PERM_BASIC ) ) {
		    ptr = &nbrd[num];
		    ptr->zap = !ptr->zap;
		    ptr->total = -1;
		    zapbuf[ ptr->pos ] = (ptr->zap ? 0 : login_start_time);
		    page = 999;
		}
	    	break;
            case 'V':
              ptr = &nbrd[num];
              brc_initial(ptr->name);
              ptr->unread = 0;
              visit_post(ptr->name);
              show_brdlist(page, 0, 1);
              break;
/***	some bug here, so take out
            case 'X': case Ctrl('V'):
             {
              char  buf[2];
              
              clear();
              getdata(0,0,"�N�Ҧ��O�]���wŪ (Y/N) [N]: ",buf,2,DOECHO,NULL);
              if ( buf[0]=='y' || buf[0]=='Y' ){
                visit_allbrd();
                pressreturn();                
              }
              show_brdlist(page,1,newflag);
              break;
             }
   ***/
            case KEY_TAB: case '\'':
              if(currentuser.address[STRLEN-8]){
	         move(2,0);
		 prints("�j�M�r��: ");	                       
                 move(t_lines-1,0);
	         prints("�D���[��,E,Q] �\\Ū[��,R] ���[��,��] �C�X[Y] �Ƨ�[S] ��ܼҦ�����[TAB] �D�U[H]" );
                 currentuser.address[STRLEN-8]=0;
                 bell();
               }else {
	         move(2,0);
	         prints("�D���[��,e,q] �\\Ū[��,r] ���[��,��] �C�X[y] �Ƨ�[s] �j�M�Ҧ�����[TAB] �D�U[h]" );
                 move(t_lines-1,0);
		 clrtoeol();
                 currentuser.address[STRLEN-8]=1;
                 bell();
                 }
              break;
	    case '\n': case '\r':
		if( number > 0 ) {
		    num = number - 1;
   		    find=YEA;	    		    
		    break;
		}
		
		/* fall through */
	    case 'R': case KEY_RIGHT: case 'L':
	    {
		char	buf[ STRLEN ];

		find=YEA;	    
		ptr = &nbrd[num];
		brc_initial( ptr->name );
		memcpy( currBM, ptr->BM, BM_LEN );
		if( newflag ) {
		    setbdir( buf, currboard );
		    tmp = unread_position( buf, ptr );
		    page = tmp - t_lines / 2;
		    getkeep( buf, page > 1 ? page : 1, tmp + 1 );
		}
		clear();
	        sprintf( genbuf, "vote/%s/notes", currboard );
                a_more(genbuf,YEA,1,t_lines-1);
		Read();
		if( zapbuf[ ptr->pos ] > 0 && brc_num > 0 ) {
		    zapbuf[ ptr->pos ] = brc_list[0];
		}
		ptr->total = page = -1;
		modify_user_mode( newflag ? READNEW : READBRD );

		break;
	    }
	    default:
	    {
   	       if( (ch >= 'a' && ch <= 'z') || ch=='_' || ch=='.' || ch=='-'||
   	                 ch == Ctrl('H') || ch == KEY_DEL ||  ch == '\177'|| ( find==NA && (ch >= '0' && ch <= '9'))){
		    find=tmpn=NA;     
                    if (isprint2(ch)) {
                       bname[i++] = ch;
                       for (n = 0; n < brdnum; n++) {
                           if (!ci_strncmp(nbrd[n].name, bname, i)) {
                               tmpn=YEA;
                               num = n;
                              if(!ci_strcmp(nbrd[n].name, bname))
                                break;
                            }
                        }
                       if(tmpn)
                            break;
                       if(find==NA)
                            bname[--i] = '\0';                            
                        break;
                     } else 
                        if (ch == Ctrl('H') || ch == KEY_DEL ||  ch == '\177'){
                           i--;
                           if (i < 0){
                               find=YEA;
                               break;
                            } else {
                               bname[i] = '\0';
                               break;
                            }
                        }
                  }else find=YEA;
             break;
            }
	}
	if( find==YEA && (ch >= '0' && ch <= '9') ) {
	    number = number * 10 + (ch - '0');
	    ch = '\0';
	} else {
	    number = 0;
	}
    }
    clear();
    save_zapbuf();
    return -1 ;
}


int 
v_board( fhdrp )
struct boardheader *fhdrp ;
{
  brc_initial(fhdrp->filename);
  visit_post( fhdrp->filename );
  move(1,0);
  clrtoeol();
  prints("Visting board: %s",fhdrp->filename); 
  refresh();
}

int
visit_allbrd()
{
    apply_boards( v_board ) ;
}

int
v_post( fptr )
struct fileheader *fptr ;
{
  void  brc_addlist(char *);

  brc_addlist(fptr->filename);  
}

int
visit_post( brd )
char *brd;
{
   char buf[STRLEN];

   setbdir( buf , brd );
   apply_record( buf,v_post,sizeof(struct fileheader)) ;
}



char *
brc_getrecord( ptr, name, pnum, list )
char	*ptr, *name;
int	*pnum, *list;
{
    int		num;
    char	*tmp;

    strncpy( name, ptr, BRC_STRLEN );
    ptr += BRC_STRLEN;
    num = (*ptr++) & 0xff;
    tmp = ptr + num * sizeof( int );
    if( num > BRC_MAXNUM ) {
	num = BRC_MAXNUM;
    }
    *pnum = num;
    memcpy( list, ptr, num * sizeof( int ) );
    return tmp;
}



char *
brc_putrecord( ptr, name, num, list )
char	*ptr, *name;
int	num, *list;
{
    if( num > 0 && list[0] > UNREAD_TIME ) {
	if( num > BRC_MAXNUM ) {
	    num = BRC_MAXNUM;
	}
	while( num > 1 && list[num-1] < UNREAD_TIME ) {
	    num--;
	}
	strncpy( ptr, name, BRC_STRLEN );
	ptr += BRC_STRLEN;
	*ptr++ = num;
	memcpy( ptr, list, num * sizeof( int ) );
	ptr += num * sizeof( int );
    }
    return ptr;
}


void
brc_update()
{
 if(brc_changed){
    char	dirfile[ STRLEN ], *ptr;
    char	tmp_buf[ BRC_MAXSIZE - BRC_ITEMSIZE ], *tmp;
    char	tmp_name[ BRC_STRLEN ];
    int		tmp_list[ BRC_MAXNUM ], tmp_num;
    int		fd, tmp_size;


    ptr = brc_buf;
    if( brc_num > 0 ) {
	ptr = brc_putrecord( ptr, brc_name, brc_num, brc_list );
    }
    setuserfile( dirfile, ".boardrc" );
    if( (fd = open( dirfile, O_RDONLY )) != -1 ) {
       tmp_size = read( fd, tmp_buf, sizeof( tmp_buf ) );
       close( fd );
     } else {
	    tmp_size = 0;
      }
    tmp = tmp_buf;
    while( tmp < &tmp_buf[ tmp_size ] && (*tmp >= ' ' && *tmp <= 'z') ) {
	tmp = brc_getrecord( tmp, tmp_name, &tmp_num, tmp_list );
	if( strncmp( tmp_name, currboard, BRC_STRLEN )  ) {
	    ptr = brc_putrecord( ptr, tmp_name, tmp_num, tmp_list );
	}
    }
    brc_size = (int)(ptr - brc_buf);

    if( (fd = open( dirfile, O_WRONLY|O_CREAT, 0644)) != -1 ) {
	ftruncate( fd, 0 );
	write( fd, brc_buf, brc_size );
	close( fd );
    }
    brc_changed = 0;
  }
}





int
brc_initial( boardname )
char	*boardname;
{
    char	dirfile[ STRLEN ], *ptr;
    int		fd;

    if( strcmp( currboard, boardname ) == 0 ) {
	return brc_num;
    }
    brc_update();
    strcpy( currboard, boardname );
    if( brc_buf[0] == '\0' ) {
	setuserfile( dirfile, ".boardrc" );
	if( (fd = open( dirfile, O_RDONLY )) != -1 ) {
	    brc_size = read( fd, brc_buf, sizeof( brc_buf ) );
	    close( fd );
	} else {
	    brc_size = 0;
	}
    }
    ptr = brc_buf;
    while( ptr < &brc_buf[ brc_size ] && (*ptr >= ' ' && *ptr <= 'z') ) {
	ptr = brc_getrecord( ptr, brc_name, &brc_num, brc_list );
	if( strncmp( brc_name, currboard, BRC_STRLEN ) == 0 ) {
	    return brc_num;
	}
    }
    strncpy( brc_name, boardname, BRC_STRLEN );
    brc_list[0] = 1;
    brc_num = 1;
    return 0;
}




void
brc_addlist( filename )
char	*filename;
{
  int ftime, n, i;


  ftime = atoi(&filename[2]);
  if (filename[0] != 'M' || filename[1] != '.' || ftime <= UNREAD_TIME) {
    return;
  }
  if (brc_num <= 0){
    brc_list[brc_num++] = ftime;
    brc_changed = 1;
    return;
  }
  for (n = 0; n < brc_num; n++) {
    if (ftime == brc_list[n]) {
      return;
    }
    else if (ftime > brc_list[n]){
      if (brc_num < BRC_MAXNUM)
	brc_num++;
      for (i = brc_num - 1; i > n; i--){
	brc_list[i] = brc_list[i - 1];
      }
      brc_list[n] = ftime;
      brc_changed = 1;
      return;
    }
  }
  if (brc_num < BRC_MAXNUM){
    brc_list[brc_num++] = ftime;
    brc_changed = 1;
  }
}



int
brc_unread( filename )
char    *filename;
{
    int		ftime, n;

    ftime = atoi( &filename[2] );
    if( filename[0] != 'M' || filename[1] != '.' || ftime <= UNREAD_TIME ) {
	return 0;
    }
    if( brc_num <= 0 )
	return 1;
    for( n = 0; n < brc_num; n++ ) {
	if( ftime > brc_list[n] ) {
	    return 1;
	} else if( ftime == brc_list[n] ) {
	    return 0;
	}
    }
    return 0;
}
   
