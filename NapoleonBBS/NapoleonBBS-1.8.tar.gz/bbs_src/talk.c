/*
 *	talk.c
 */



#include "bbs.h"
#ifdef lint
#include <sys/uio.h>
#endif
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>


#define M_INT 8         /* monitor mode update interval */
#define P_INT 20        /* interval to check for page req. in talk/chat */




struct talk_win {
    int         curcol, curln;
    int         sline, eline;
};



#include "modetype.c"

extern int t_columns;
int      friendonly=0;
char    *talk_uent_buf;

char save_page_requestor[STRLEN];


int t_cmpuids();




int
ishidden(user)
char *user;
{
    int tuid;
    struct user_info uin;

    if (!(tuid = getuser(user))) return 0;
    search_ulist( &uin, t_cmpuids, tuid );
    return( uin.invisible );
}



char *
modestring(mode, towho, complete, chatid)
int mode, towho, complete;
char *chatid;
{
    static char modestr[STRLEN];
    struct userec urec;

    if (chatid) {
        if (complete) sprintf(modestr, "%s as '%s'", ModeType(mode), chatid);
        else return (ModeType(mode));
        return (modestr);
    }
    if (mode != TALK && mode != PAGE && mode != QUERY)
        return (ModeType(mode));
    if (get_record(PASSFILE, &urec, sizeof(urec), towho) == -1)
        return (ModeType(mode));

    if (mode != QUERY && !HAS_PERM(PERM_SEECLOAK) && 
        ishidden(urec.userid)) return (ModeType(TMENU));        
    if (complete)
        sprintf(modestr, "%s '%s'", ModeType(mode), urec.userid);
    else
        return (ModeType(mode));
    return (modestr);
}




int
canpage(friend, pager)
int friend,pager;
{
    if ((pager&ALL_PAGER) || HAS_PERM(PERM_SYSOP)) return YEA;
    if ((pager&FRIEND_PAGER)){
        if(friend)
                return YEA;
    }
    return NA;
}



#ifdef SHOW_IDLE_TIME
char *
idle_str( uent )
struct user_info *uent ;
{
    static char hh_mm_ss[ 32 ];
    struct stat buf;
    char        tty[ 128 ];
    time_t      now, diff;
    int         hh, mm;

    strcpy( tty, uent->tty );

    if ( (stat( tty, &buf ) != 0) || 
         (strstr( tty, "tty" ) == NULL)) {
        strcpy( hh_mm_ss, "����");
        return hh_mm_ss;
    };

    now = time( 0 );

    diff = now - buf.st_atime;

#ifdef DOTIMEOUT
    /* the 60 * 60 * 24 * 5 is to prevent fault /dev mount from
       kicking out all users */
    
    
    if ((diff > IDLE_TIMEOUT) && (diff < 60 * 60 * 24 * 5 ))
         if(!HAS_PERM(PERM_SYSOP))
            kill( uent->pid, SIGHUP );
#endif

    hh = diff / 3600;
    mm = (diff / 60) % 60;
    
    if ( hh > 0 ) 
        sprintf( hh_mm_ss, "%d:%02d", hh, mm );
    else if ( mm > 0 ) 
        sprintf( hh_mm_ss, "%d", mm );
    else sprintf ( hh_mm_ss, "   ");

    return hh_mm_ss;
}
#endif




int
listcuent(uentp)
struct user_info *uentp ;
{
    if(uentp == NULL) {
        CreateNameList() ;
        return 0;
    }
    if(uentp->uid == usernum)
        return 0;
    if(!uentp->active || !uentp->pid)
        return 0;
    if(uentp->mode == ULDL)
        return 0;
    if(!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
        return 0;
    AddNameList( uentp->userid );
    return 0 ;
}



void
creat_list()
{
    listcuent(NULL) ;
    apply_ulist( listcuent );
}



int
t_pager()
{
    int	    a;


    modify_user_mode(FORM);
    showansi=1;
    if(uinfo.pager&ALL_PAGER){
      getdata(1,0,"�����ϰ� (1)�ϰ�(�n�ͥi�I�s) (2)����(�n�ͤ��i�I�s) [1]:",
                 genbuf,2,DOECHO,NULL);
      uinfo.pager&=~ALL_PAGER;;
      if(genbuf[0]!='2')
             uinfo.pager|=FRIEND_PAGER;
       else 
           uinfo.pager&=~FRIEND_PAGER;
    } else {
        uinfo.pager|=ALL_PAGER;
        uinfo.pager|=FRIEND_PAGER;
    }    
    update_utmp();
    if ( !uinfo.in_chat ) {
        move(1,0);
        clrtoeol();
        move( 1, 0 );
        prints( "�z���I�s�� (pager) �w�g[1m%s[m�F!", 
                         (uinfo.pager&ALL_PAGER) ? "���}" : "����" );
        pressreturn();
    }
    return 0 ;
}


int
t_query()
{
   char	uident[IDLEN];

   modify_user_mode( QUERY );
   refresh();
   move(2,0);
   prints("<��J�ϥΪ̥N��, ���ť���i�C�X�ŦX�r��>\n");
   move(1,0);
   clrtoeol();
   prints("�d�߽�: ");
   usercomplete(NULL,uident);
   if(uident[0] == '\0') {
     clear() ;
     return 0 ;
   }
   my_query(uident);


}


int
my_query(uident)
char *uident;
{
    char	*newline ;
    int		tuid, i;
    FILE	*planfile;
    struct user_info uin;

    if(!(tuid = getuser(uident))) {
   	move(2,0) ;
	prints("�����T���ϥΪ̥N��\n") ;
	pressreturn() ;
	move(2,0) ;
	clrtoeol() ;
	return -1 ;
    }
    uinfo.destuid = tuid ;
    update_utmp();

    move(2,0);
    clrtobot();
    sprintf(genbuf, "query %s", lookupuser.userid);
    report(genbuf);
    prints( "%s (%s).�@�W�� %d ��,�@�i�K %d �g,\n",
/*             ���U���: %s"*/
	lookupuser.userid, lookupuser.username, lookupuser.numlogins,lookupuser.numposts
/*	ctime( &lookupuser.firstlogin )*/ );

    strcpy(genbuf, ctime(&(lookupuser.lastlogin)));
    if( (newline = strchr(genbuf, '\n')) != NULL )
	*newline = '\0';
    prints( "�W�� login %s �q %s\n", genbuf, 
	(lookupuser.lasthost[0] == '\0' ? "(����)" : lookupuser.lasthost));

#if defined(QUERY_REALNAMES)
    if (HAS_PERM(PERM_BASIC))	
	prints("�u��m�W: %s, ",lookupuser.realname);
#endif
    if( chkomail(lookupuser.userid) ) prints("�H�c�����s���H��, ");
    else prints("�H�c�����H��Ū�L�F, ");
    search_ulist(&uin, t_cmpuids, tuid);
    if( !(uin.invisible) && uin.active ){
    	prints("�ثe���A��: %s.\n", modestring(uin.mode, uin.destuid, 1,
			   uin.in_chat ? uin.chatid : NULL) );
    } else prints("�ثe���b�u�W.\n");
    sprintf( genbuf,"home/%s/plans",lookupuser.userid);
    showansi=1;
    if (!dashf(genbuf))
	prints("���@�ثe�L����p�� ��\n");
    else {
	prints("���@�p�� ��\n");
        a_more(genbuf,NA,7,t_lines-1);
    }
    pressreturn();
    uinfo.destuid = 0;
    showansi=0;
    return 0;
    
}		




int
t_cmpuids(uid,up)
int uid ;
struct user_info *up ;
{
    return (up->active && uid == up->uid) ;
}

int
t_talk()
{
    char uident[IDLEN] ;
    int tuid, ucount, unum, tmp ;
    struct user_info uin ;
    char tbybuf[30];


    modify_user_mode(PAGE);
    move(1,0);
    clrtobot();
    move(2,0) ;
    prints("<��J�ϥΪ̥N��>\n") ;
    move(1,0) ;
    clrtoeol() ;
    prints("��ֲ��: ") ;
    creat_list() ;
    namecomplete(NULL,uident) ;
    if(uident[0] == '\0') {
        clear() ;
        return 0 ;
    }
    if(!(tuid = getuser(uident)) || tuid == usernum) {
        move(2,0) ;
        prints("���~�N��\n") ;
        pressreturn() ;
        move(2,0) ;
        clrtoeol() ;
        return -1 ;
    }
    ucount=count_logins( &uin, t_cmpuids, tuid, 0);

 if(ucount>1) {
list:
    move(3,0);
    prints("�ثe %s �� %d logins �p�U: \n", uident, ucount);
    clrtobot() ;
    move(5,0) ;
    prints("(0) ��F��F�A����F�C\n");
    ucount=count_logins( &uin, t_cmpuids, tuid, 0);
    count_logins( &uin, t_cmpuids, tuid, 1);
    clrtobot() ;
    tmp=ucount+8;
    getdata( tmp, 0, "�п�@�� login number [0]: ",
    genbuf, 4, DOECHO, NULL );
    unum=atoi(genbuf);
    if(unum == 0) { 
    	clear(); 
    	return 0; 
    }
    if(unum > ucount || unum < 0) {
        move(tmp,0);
        prints("����F�I\n") ;
        clrtobot();
        pressreturn();
        goto list;
    }
    search_ulistn( &uin, t_cmpuids, tuid, unum );
    } else search_ulist( &uin, t_cmpuids, tuid );
   ttt_talk(&uin);
}

int
ttt_talk(userinfo)
struct user_info *userinfo ;
{
    char uident[IDLEN] ;
    int tuid, ucount, unum, tmp ;
    struct user_info uin ;
    char tbybuf[30];
    int     bind(/*int,struct sockaddr *, int*/) ;
    

    uin=*userinfo;
    tuid=uin.uid;
    strcpy(uident,uin.userid);
    if (!HAS_PERM(PERM_SYSOP)) {
       if( !canpage(friend_me(&uin),uin.pager) ) {
            move(2,0) ;
            prints("���I�s���w����.\n");
            pressreturn() ;
            return -1 ;
        }
    }
    if(uin.mode == ULDL || uin.mode == IRCCHAT || uin.mode == BBSNET ) {
        move(2,0) ;
        prints("�ثe�L�k�I�s.\n") ;
        pressreturn() ;
        return -1 ;
    }
    if(!uin.active || (kill(uin.pid,0) == -1)) {
        move(2,0) ;
        prints("���w���}\n") ;
        pressreturn() ;
        return -1 ;
    } else {
        int sock, msgsock, length ;
        struct sockaddr_in server ;
         char c ;
        char buf[512] ;
        FILE *planfile;

       if(uinfo.mode!=LUSERS&&uinfo.mode!=FRIEND){
        move( 2, 0 );
        clrtobot();
        sethomefile( genbuf, uident, "plans" );
        if ( ( planfile = fopen( genbuf, "r" ) ) == NULL ) {
             prints( "%s �S���p����\n", uident );
         } else {
             showansi=1; 
             prints( "\033[1;33m%s ���p����:\033[m\n\n", uident );
             for ( length = 0; length < MAXQUERYLINES; length++ ) {
                 if( fgets( genbuf, sizeof(genbuf), planfile ) )
                     prints( "%s", genbuf );
                 else 
                     break;
             }
             showansi=0;
             fclose( planfile );
         }
       }
        sprintf(tbybuf,"�T�w�n�M %s �ͤѶ�? (Y/N) [N]: ",uident);
        getdata( 1, 0, tbybuf, genbuf, 2, DOECHO, NULL );
        if ( *genbuf != 'y' && *genbuf != 'Y' ) {
            clear();
            return 0;
        }

        sprintf(buf,"Talk to '%s'",uident) ;
        report(buf) ;
        sock = socket(AF_INET, SOCK_STREAM, 0) ;
        if(sock < 0) {
            perror("socket err\n") ;
            return -1 ;
        }

        server.sin_family = AF_INET ;
        server.sin_addr.s_addr = INADDR_ANY ;
        server.sin_port = 0 ;
        if(bind(sock, (struct sockaddr *) & server, sizeof server ) < 0) {
            perror("bind err") ;
            return -1 ;
        }
        length = sizeof server ;
        if(getsockname(sock, (struct sockaddr *) &server, &length) < 0) {
            perror("socket name err") ;
            return -1 ;
        }
        uinfo.sockactive = YEA ;
        uinfo.sockaddr = server.sin_port ;
        uinfo.destuid = tuid ;
        modify_user_mode( PAGE );
        kill(uin.pid,SIGUSR1) ;
        clear() ;
        prints("�I�s %s ��...\n��J Ctrl-D ����\n", uident) ;

        listen(sock,1) ;
        add_io(sock,20) ;
        while(YEA) {
            int ch ;
            ch = igetch() ;
            if(ch == I_TIMEOUT) {
#ifdef LINUX
      add_io(sock, 20);		/* added 4 linux... achen */
#endif

                move(0,0) ;
                prints("�A���I�s.\n") ;
                bell() ;
                if(kill(uin.pid,SIGUSR1) == -1) {
#ifdef LINUX
	add_io(sock, 20);	/* added 4 linux... achen */
#endif
                    move(0,0) ;
                    prints("���w���u\n") ;
                    uinfo.sockactive = NA ;
                    uinfo.destuid = 0 ;
                    pressreturn() ;
                    return -1 ;
                }
                continue ;
            }
            if(ch == I_OTHERDATA)
                break ;
            if(ch == '\004') {
                add_io(0,0) ;
                close(sock) ;
                uinfo.sockactive = NA ;
                uinfo.destuid = 0 ;
                clear() ;
                return 0 ;
            }
        }

        msgsock = accept(sock, (struct sockaddr *)0, (int *) 0) ;
        if(msgsock == -1) {
            perror("accept") ;
            return -1 ;
        }
        add_io(0,0) ;
        close(sock) ;
        uinfo.sockactive = NA ;
        read(msgsock,&c,sizeof c) ;

        clear() ;

        if(c == 'y'|| c=='Y' ) { sprintf( save_page_requestor, "%s (%s)",
            uin.userid, uin.username); do_talk(msgsock) ;
        } else {
        move(9, 9);
        outs("�i�^���j ");
        switch (c)
        {
         case 'a':
           outs("�ڲ{�b�ܦ��A�е��@�|��A call ��, �n��?");
           break;
         case 'b':
           outs("�藍�_�A�ڦ��Ʊ������A talk....");
           break;
         case 'd':
           outs("�A�u���ܷСA�ڹ�b���Q��A talk....");
           break;
        case 'c':
           outs("�Ф��n�n�ڦn�ܡH");
           break;
        default:
           outs("�ڲ{�b���Q talk�.....:)");
         }
         pressanykey();
        }                        
        close(msgsock) ;
        clear() ;
        refresh();
        uinfo.destuid = 0;
    }
    return 0 ;
}

extern int talkrequest ;
struct user_info  ui ;
char page_requestor[STRLEN];
char page_requestorid[STRLEN];

int
cmpunums(unum,up)
int unum ;
struct user_info *up ;
{
    if(!up->active)
      return 0 ;
        return (unum == up->destuid) ;
}

int
setpagerequest()
{
    int tuid;

    tuid = search_ulist( &ui, cmpunums, usernum );
    if(tuid == 0)
        return 1;
    if(!ui.sockactive)
        return 1;
    uinfo.destuid = ui.uid;
    sprintf(page_requestor, "%s (%s)", ui.userid, ui.username);
    strcpy( page_requestorid, ui.userid );
    return 0;
}

int
servicepage( line, mesg )
int     line;
char    *mesg;
{
    static time_t last_check;
    time_t now;
    char buf[STRLEN];
    int tuid = search_ulist( &ui, cmpunums, usernum );

    if(tuid == 0 || !ui.sockactive) talkrequest = NA;
    if (!talkrequest) {
        if (page_requestor[0]) {
            switch (uinfo.mode) {
                case TALK:
                    move(line, 0);
                    printdash( mesg );
                    break;
                default: /* a chat mode */
                    sprintf(buf, "** %s �w����I�s.", page_requestor);
                    printchatline(buf);
            }
            memset(page_requestor, 0, STRLEN);
            last_check = 0;
        }
        return NA;
    } else {
        now = time(0);
        if (now - last_check > P_INT) {
            last_check = now;
            if (!page_requestor[0] && setpagerequest())
                return NA;
            else switch (uinfo.mode) {
                case TALK:
                    move(line, 0);
                    sprintf(buf, "** %s ���b�I�s�A", page_requestor);
                    printdash( buf );
                    break;
                default: /* chat */
                    sprintf(buf, "** %s ���b�I�s�A", page_requestor);
                    printchatline(buf);
            }
        }
    }
    return YEA;
}



int
talkreply()
{
    int a ;
    struct hostent *h ;
    char buf[512] ;
    char hostname[STRLEN] ;
    struct sockaddr_in sin ;
    FILE *planfile;
    char inbuf[STRLEN*2];
    int i;
                
    talkrequest = NA ;
#ifdef BBSNTALKD
    ntalkrequest = NA ;
#endif
    if (setpagerequest()) return 0;     
    clear() ;

    modify_user_mode(TALK);
    move( 5, 0 );
    clrtobot();
    sethomefile( genbuf, page_requestorid, "plans" );
    report( genbuf );
    if ( ( planfile = fopen( genbuf, "r" ) ) == NULL ) {
        prints( "%s �S���p����\n", page_requestorid );
    } else {
        showansi=1;
        prints( "%s ���p����:\n\n", page_requestorid );
        for ( i = 1; i <= 18; i++ ) {
            if ( fgets( inbuf, sizeof(inbuf), planfile ) )
                prints( "%s", inbuf );
            else 
                break;
        }
        showansi=0;
        fclose( planfile );
    } 
   move(1,0);
   outs("\
       (Y) ���ڭ� talk �a�I     (A) �ڲ{�b�ܦ��A�е��@�|��A call ��\n\
       (N) �ڲ{�b���Q talk      (B) �藍�_�A�ڦ��Ʊ������A talk\n\
       (C) �Ф��n�n�ڦn�ܡH     (D) �A�u���ܷСA�ڹ�b���Q��A talk\n\n");
    sprintf( inbuf, "�A�Q�� %s ���Ѷ�? (Y/N/B/C/D)[Y]: ", page_requestor );
    strcpy(save_page_requestor, page_requestor);
    memset(page_requestor, 0, sizeof(page_requestor));
    memset(page_requestorid, 0, sizeof(page_requestorid));
    getdata(0,0, inbuf ,buf,STRLEN,DOECHO,NULL) ;
    gethostname(hostname,STRLEN) ;
    if(!(h = gethostbyname(hostname))) {
        perror("gethostbyname") ;
        return -1 ;
    }
    memset(&sin, 0, sizeof sin) ;
    sin.sin_family = h->h_addrtype ;
    memcpy( &sin.sin_addr, h->h_addr, h->h_length) ;
    sin.sin_port = ui.sockaddr ;
    a = socket(sin.sin_family,SOCK_STREAM,0) ;
    if((connect(a, (struct sockaddr *)&sin, sizeof sin))) {
        perror("connect err") ;
        return -1 ;
    }
   if (!strchr("abcdn", buf[0] |= 0x20))
      buf[0]='y';            
    write(a,buf,1) ;
    if(buf[0] != 'y') {
        close(a) ;
        report("page refused");
        clear() ;
        refresh();
        return 0 ;
    }
    report("page accepted");
    clear();
    do_talk(a) ;
    close(a) ;
    clear() ;
    refresh();
    return 0 ;
}



int
dotalkent(uentp, buf)
struct user_info *uentp;
char *buf;
{
    char mch;
    if (!uentp->active || !uentp->pid) return -1;
    if(!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
        return -1;
    switch(uentp->mode) {
        case ULDL: mch = 'U'; break;
        case TALK: mch = 'T'; break;
        case CHAT1:
        case CHAT2:
        case CHAT3:
        case CHAT4: mch = 'C'; break;
        case IRCCHAT: mch = 'I'; break;
        case FOURM: mch = '4'; break;
        case BBSNET: mch = 'B'; break;
        case READNEW:
        case READING: mch = 'R'; break;
        case POSTING: mch = 'P'; break;
        case SMAIL:
        case RMAIL:
        case MMAIL: mch = 'M'; break;
        default: mch = '-';
    }
    sprintf(buf, "%s%s(%c), ", uentp->invisible?"*":"", uentp->userid, mch);
    return 0;
}
 
 
 
int
dotalkuent(uentp)
struct user_info *uentp;
{
    char        buf[ STRLEN ];

    if( dotalkent( uentp, buf ) != -1 ) {
        strcpy( talk_uent_buf, buf );
        talk_uent_buf += strlen( buf );
    }
    return 0;
}
 
 
 
void
do_talk_nextline( twin )
struct talk_win *twin;
{
    int         curln;

    curln = twin->curln + 1;
    if( curln > twin->eline )
        curln = twin->sline;
    if( curln != twin->eline ) {
        move( curln + 1, 0 );
        clrtoeol();
    }
    move( curln, 0 );
    clrtoeol();
    twin->curcol = 0;
    twin->curln  = curln;
}
 
void
do_talk_char( twin, ch )
struct talk_win *twin;
int             ch ;
{
    extern int dumb_term ;

    if(isprint2(ch)) {
        if( twin->curcol < 79) {
            move( twin->curln, (twin->curcol)++ );
            prints( "%c",ch );
            return;
        }
        do_talk_nextline( twin );
        twin->curcol++;
        prints( "%c", ch );
        return;
    }
    switch(ch) {
        case Ctrl('H'):
        case '\177':
            if(dumb_term) ochar(Ctrl('H')) ;
            if( twin->curcol == 0 ) {
                return;
            }
            (twin->curcol)-- ;
            move( twin->curln, twin->curcol );
            if(!dumb_term) prints(" ") ;
            move( twin->curln, twin->curcol );
            return ;
        case Ctrl('M'):
        case Ctrl('J'):
            if(dumb_term) prints("\n") ;
            do_talk_nextline( twin );
            return ;
        case Ctrl('G'):
            bell() ;
            return ;
        default:
            break ;
    }
    return ;
}


void
do_talk_string( twin, str )
struct talk_win *twin;
char            *str;
{
    while( *str ) {
        do_talk_char( twin, *str++ );
    }
}

void
dotalkuserlist( twin )
struct talk_win *twin;
{
    char        bigbuf[ MAXACTIVE * 20 ];
    int         savecolumns;

    do_talk_string( twin, "\n*** �W�u���� ***\n" );
    savecolumns = (t_columns > STRLEN ? t_columns : 0);
    talk_uent_buf = bigbuf;
    if( apply_ulist( dotalkuent ) == -1 ) {
        strcpy( bigbuf, "�S������ϥΪ̤W�u\n" );
    }
    strcpy( talk_uent_buf, "\n" );
    do_talk_string( twin, bigbuf );
    if (savecolumns) t_columns = savecolumns;        
}


int
moveto(mode,twin)
struct talk_win *twin;
{
        if(mode==1)
              twin->curln--;
        if(mode==2)
              twin->curln++;
        if(mode==3)
              twin->curcol++;
        if(mode==4)
              twin->curcol--;
        if(twin->curcol<0){
                twin->curln--;
                twin->curcol=0;
        }else if(twin->curcol>79){
                twin->curln++;
                twin->curcol=0;
        }
        if(twin->curln<twin->sline){
                twin->curln=twin->eline;
        }
        if(twin->curln>twin->eline){
                twin->curln=twin->sline;
        }
        move(twin->curln,twin->curcol);
}


char talkobuf[80] ;
int talkobuflen ;
int talkflushfd ;



void
talkflush()
{
    if(talkobuflen) 
      write(talkflushfd,talkobuf,talkobuflen) ;
    talkobuflen = 0 ;
}

int
do_talk(fd)
int fd ;
{
    struct talk_win     mywin, itswin;
    char        mid_line[ 256 ];
    int         page_pending = NA;
    int         i;

    refresh() ;
    modify_user_mode( TALK );
    sprintf( mid_line, " %s (%s) v.s. %s ", 
        currentuser.userid, currentuser.username, save_page_requestor );

    memset( &mywin,  0, sizeof( mywin ) );
    memset( &itswin, 0, sizeof( itswin ) );
    i = (t_lines-1) / 2;
    mywin.eline = i - 1;
    itswin.curln = itswin.sline = i + 1;
    itswin.eline = t_lines - 1;
    move( i, 0 );
    printdash( mid_line );
    move( 0, 0 );

    talkobuflen = 0 ;
    talkflushfd = fd ;
    add_io(fd,0) ;
    add_flush(talkflush) ;

    while(YEA) {
        int ch ;
        if (talkrequest) page_pending = YEA;
        if (page_pending)
            page_pending = servicepage( (t_lines-1) / 2, mid_line );
        ch = igetkey() ;
        if ( ch == '' ) 
        {
           igetch();
           igetch();    
           continue;
        }
        if(ch == I_OTHERDATA) {
            char data[80] ;
            int datac ;
            register int i ;

            datac = read(fd,data,80) ;
            if(datac<=0) 
                break ;
            for(i=0;i<datac;i++){
              if(data[i]>=1&&data[i]<=4){
                 moveto(data[i]-'\0',&itswin);
                 continue;
              }
               do_talk_char( &itswin, data[i] );
            }
        } else {
            if(ch == Ctrl('D') || ch == Ctrl('C'))
                break ;
            if(isprint2(ch) || ch == Ctrl('H') || ch == '\177'
                || ch == Ctrl('G') || ch == Ctrl('M') ) {
                talkobuf[talkobuflen++] = ch ;
                if(talkobuflen == 80) talkflush() ;
                do_talk_char( &mywin, ch );
            } else if (ch == '\n') {
                talkobuf[talkobuflen++] = '\r';
                talkflush();
                do_talk_char( &mywin, '\r' );
            }else if(ch>=KEY_UP&&ch<=KEY_LEFT) {
                  moveto(ch-KEY_UP+1,&mywin);
                  talkobuf[talkobuflen++] = ch -KEY_UP+1;
                  if(talkobuflen == 80) talkflush() ;
            } else if (ch == Ctrl('U') || ch == Ctrl('W')) {
                dotalkuserlist( &mywin );
            } else if (ch == Ctrl('P') && HAS_PERM(PERM_BASIC)) {
                if( uinfo.pager&ALL_PAGER ) {
                    do_talk_string( &mywin, "** �����I�s��\n" );
                    uinfo.pager &= ~ALL_PAGER;
                    uinfo.pager |= FRIEND_PAGER;
                } else {
                    do_talk_string( &mywin, "** ���}�I�s��\n" );
                    uinfo.pager|=ALL_PAGER;
                    uinfo.pager|=FRIEND_PAGER;    
                }
                update_utmp();
            }
        }
    }
    add_io(0,0) ;
    talkflush() ;
    add_flush(NULL) ;
    return 0;
}



int
shortulist(uentp)
struct user_info *uentp;
{
    static int lineno, fullactive, linecnt;
    static int moreactive, page, num;
    char uentry[30];
    int ovv,show;


    if (!lineno) {
        lineno = 3;
        page = moreactive ? (page + (t_lines-4) * 3) : 0;
        linecnt = num = moreactive = 0;
        move( 1, 67 );
        prints( "Page: %-3d", page / (t_lines-4) / 3 + 1 );
        move(lineno, 0);
    }
    if( uentp == NULL ) {
        int     finaltally;

        clrtoeol();
        move(++lineno, 0);
        clrtobot();
        lineno = 0;
        finaltally = fullactive;
        fullactive = 0;
        return finaltally;
    }
    if( !uentp->active || !uentp->pid ||
	    (!HAS_PERM(PERM_SEECLOAK) && uentp->invisible) ) {
        if( lineno >= t_lines-1 )  return 0;
        if( num++ < page )  return 0;
        memset( uentry, ' ', 24 );        
        uentry[ 24 ] = '\0';
    } else {
    	int	override;
        
        fullactive++;
        if( lineno >= t_lines-1 ) {
            moreactive = 1;
            return 0;
        }
        if( num++ < page )  return 0;
        override=my_friend(uentp);
        sprintf(uentry,"%-12s%c%c%-10s", uentp->userid,
                override ? '&' : ' ', uentp->invisible ? '#' : ' ',
                modestring(uentp->mode, uentp->destuid, 0, NULL));
        uentry[24]='\0';
     }
    if( ++linecnt < 3 ) {
	strcat(uentry, " | ");
	prints(uentry);
    } else {
	prints(uentry);
	linecnt = 0;
	clrtoeol();
	move(++lineno, 0);        
    }
    return 0;
}


int
do_list( modestr )
char *modestr;
{       
    extern char BoardName[];
    char        buf[ STRLEN ];
    int         count;


    showansi=1;
    move(0,0);
        clrtoeol();
   if(chkomail(currentuser.userid))
     if(iscolor)
       showtitle(modestr,"[1;41;5m[�z������]");
     else
       titletmp(modestr,"[�z������]");
   else
     if(iscolor)
      showtitle(modestr,BoardName);
     else
      titletmp(modestr,BoardName);     
    move(2,0);
    showansi=1;
    clrtoeol();
    sprintf( buf, "%-12sF%c%-10s", "�ϥΪ� ID", HAS_PERM(PERM_SEECLOAK) ? 'C' : ' ' ,"�ثe�ʺA" );
    standout();
    prints( "%s | %s | %s ", buf, buf, buf );
    standend();

    if(apply_ulist( shortulist ) == -1) {
        prints("No Users Exist\n") ;
        return 0;
    }
    count = shortulist(NULL);
    if (uinfo.mode == MONITOR) {
        time_t thetime = time(0);
     	float	f_load[3];

      if(HAS_PERM(PERM_SYSOP)){
         get_load(f_load);
         move(t_lines-1,0);
         prints("�W�u�H��: %3d ,�{�b�ɨ�: %s ,�����t��:  %-2.2f  %-2.2f  %-2.2f",
                  count,Ctime(&thetime),f_load[0],f_load[1],f_load[2]);
      }
     else{

        move(t_lines-1, 0);
        prints("�W�u�H�� :  %3d , �{�b�ɨ�: %s ", count,Ctime(&thetime));
      }
    }
    refresh();
    return 0;
}



int
t_list()
{
    modify_user_mode( LUSERS );
    report("t_list");
    do_list("�ϥΪ̪��A");
    pressreturn();
    clear();
    return 0;
}



int idle_monitor_time;
                    


void
sig_catcher()
{
    if (uinfo.mode != MONITOR) {
#ifdef DOTIMEOUT
        init_alarm();
#else
        signal(SIGALRM, SIG_IGN);
#endif
        return;
    }           
    if (signal(SIGALRM, sig_catcher)==SIG_ERR) {
        perror("signal");
        exit(1);
    }
#ifdef DOTIMEOUT
    if(!HAS_PERM(PERM_SYSOP))
       idle_monitor_time += M_INT;
    if (idle_monitor_time > MONITOR_TIMEOUT) {
        clear();
        fprintf(stderr, "timeout ...\n");
        exit(1);
    }
#endif
    do_list("�ʬݨϥΪ�");
    if(HAS_PERM(PERM_SYSOP))
       alarm(2);
    else   alarm(M_INT);
       
}



int
t_monitor()
{
    char c;
    int i;

    alarm(0);
    signal(SIGALRM, sig_catcher);
    idle_monitor_time = 0;
    report("monitor");
    modify_user_mode( MONITOR );
    move(1,0);
    clrtoeol();
    prints("�C�j %d ����s�@���ACtrl-C �� Ctrl-D ���}",M_INT);
    clrtoeol();
    do_list("�ʬݨϥΪ�");
    alarm(M_INT);
    while (YEA) {
        i = read(0,&c,1);
        if (!i || c == Ctrl('D') || c == Ctrl('C')) break;
        else if (i == -1) {
            if (errno != EINTR) { perror("read"); exit(1); }
        } else idle_monitor_time = 0;
    }
    move(2,0);
    clrtoeol();
    return 0;
}


/**************************************************************************
void
exec_cmd( umode, pager, cmdfile )
int     umode, pager;
char    *cmdfile;
{
    char buf[512] ;
    int save_pager;

    if( ! dashf( cmdfile ) ) {
        move(2,0);
        prints( "no %s\n", cmdfile );
        pressreturn();
        return;
    }
    save_pager = uinfo.pager;
    if( pager == NA ) {
        uinfo.pager = pager;
    }
    modify_user_mode( umode );
    sprintf( buf, "/bin/sh %s", cmdfile );
    reset_tty() ;
    do_exec(buf,NULL) ;
    restore_tty() ;
    uinfo.pager = save_pager;
    clear();
}

#ifdef IRC
void
t_irc() {
    exec_cmd( IRCCHAT, NA, "bin/irc.sh" );
}
#endif 


void
t_announce() {
    exec_cmd( CSIE_ANNOUNCE, YEA, "bin/faq.sh" );
}

void
t_tin() {
    exec_cmd( CSIE_TIN, YEA, "bin/tin.sh" );
}

void
t_gopher() {
    exec_cmd( CSIE_GOPHER, YEA, "bin/gopher.sh" );
}

**************************************************************************/

int
list_overrides(fname)
char *fname;
{
    int	nf, i;
    int	x = 0, y = 3, max = 0, len;
    struct friend *topfriend;    
    
    
    nf = get_num_records(fname,sizeof(struct friend));
    if(nf <= 0)
        return 0 ;
    nf = (nf >= MAXFRIENDS ) ? MAXFRIENDS : nf;
    CreateNameList();
    topfriend = (struct friend *)calloc(sizeof(struct friend),nf);
    get_records(fname, topfriend, sizeof(struct friend), 1, nf);
    move( y, x);
    for( i = 0; i < nf; i++){
       AddNameList( topfriend[i].id );
       if( (len = strlen( topfriend[i].id )) > max )  max = len;
       prints( "%s", &topfriend[i].id);
       if ((++y) >= t_lines-1) {
            y = 3;
            x += max + 2;
            max = 0;
            if( x > 70 )  break;
       }
       move(y,x);
    }
    free(topfriend);
    if( nf == 0 ) prints("<none>");
    return nf;
}


int
cmpfnames(userid, uv)
char    *userid;
struct friend *uv;
{
        return !strcmp(userid, uv->id);
}
        

int
seek_in_file(filename,seekstr)
char *filename,*seekstr;
{
   struct friend fh;

   return (search_record( filename, &fh, sizeof(fh), cmpfnames, seekstr )>0) ? YEA : NA;
}


int
can_override( userid, whoasks )
char *userid;
char *whoasks;
{
    FILE *fp;
    char buf[STRLEN];

    sethomefile( buf, userid, "overrides" );
    return seek_in_file(buf,whoasks);
}


int
addtofile(filename,fn)
char *filename;
struct friend fn; 
{
    return (append_record(filename,&fn,sizeof(struct friend)) >=0 ) ?1:0;
}


int
addtooverride(uident)
char *uident;
{
    char buf[41];
    int  n;
    struct friend tmp;
    
    if( can_override( currentuser.userid, uident ) )
	return -1;
    strcpy(tmp.id,uident);
    if( uinfo.mode!=LUSERS && uinfo.mode!=FRIEND)
        getdata(2,0,"��J����: ", buf,40,DOECHO,NULL);
    else{
        getdata(t_lines-2,0,"��J����: ", buf,40,DOECHO,NULL);
        move(t_lines-2,0);
        clrtoeol();
    }
    
    strcpy(tmp.exp,buf);
    setuserfile( genbuf, "overrides" );
    n = addtofile(genbuf,tmp);
    if( n == 1 ) getfriend();
    return n;
} 

int
del_from_file(filename,uident)
char *filename;
char *uident;
{
   int	deleted;
   struct friend fh; 

   deleted = search_record( filename, &fh, sizeof(fh), cmpfnames, uident );
   if(deleted > 0)
        deleted = delete_record(filename,sizeof(fh),deleted);
   else{
        prints("No record");
        return -1;
   }
        
   return ( deleted >0 || deleted==0 ) ? 1 :-1 ;
}


int
deleteoverride(uident)
char *uident;
{
    int deleted;
    char fn[STRLEN];

    setuserfile( fn, "overrides" );
    deleted = del_from_file(fn, uident);
    if(deleted != -1)
        getfriend();
    return deleted;
}

int
friend_query(ent,fh,direct)
int ent;
struct friend *fh;
char *direct;
{

   my_query(fh->id);
   return FULLUPDATE;
}

int
friend_add(ent,fh,direct)
int ent;
struct friend *fh;
char *direct;
{
      char uident[13];

      clear();
      move(1,0);
      usercomplete("�п�J�n�W�[���N��: ", uident);
      if( uident[0] != '\0' ){
        if( getuser(uident) <= 0 ){
            move(2,0);
            prints("���~���ϥΪ̥N��...");
            pressanykey();
        }else
            addtooverride(uident);
      }
      return FULLUPDATE;
}




int
friend_delete(ent,fh,direct)
int ent;
struct friend *fh;
char *direct;
{
      char buf[STRLEN];
      int deleted=NA;

      move(t_lines-2,0);
      clrtoeol();
      sprintf(buf,"�O�_��i%s�j�q�n�ͦW�椤�h�� (Yes/No)[N]: ", fh->id );
      getdata(1, 0, buf, genbuf,2,DOECHO,NULL);
      if( genbuf[0] == 'Y' || genbuf[0] == 'y'){
         move(t_lines-2,0);
         clrtoeol();
         if(deleteoverride(fh->id)==1){
                prints("�w�q�n�ͦW�椤�����i%s�j,���������~��...",fh->id);
                deleted=YEA;
         }
         else
                prints("�䤣��i%s�j,���������~��...",fh->id);
      } else{
         move(t_lines-2,0);
         clrtoeol();
         prints("�����R���n��...");
      }
      pressanykey();
      move(t_lines-2,0);
      clrtoeol();
/*      saveline(t_lines-2, 1);*/
      return (deleted) ? FULLUPDATE : DONOTHING;
}


int
friend_edit(ent,fh,direc)
int ent;
struct friend *fh;
char *direc;
{

     struct	friend nh;        
     char	buf[STRLEN/2];
     int	pos;  

     pos = search_record( direc, &nh, sizeof(nh), cmpfnames, fh->id );
     move(t_lines-2,0);
     clrtoeol();
     if( pos > 0 ){
        sprintf(genbuf,"�п�J %s ���s�n�ͻ���: ",fh->id);
        getdata(t_lines-2,0,genbuf,buf,40,DOECHO,NULL);
     }
     strcpy( nh.exp, buf);
     if(substitute_record(direc, &nh, sizeof(nh), pos) < 0 )
        report("Friend files subs err");
     move(t_lines-2,0);
     clrtoeol();
     return NEWDIRECT;
}


int
friend_mail(ent,fh,direc)
int ent;
struct friend *fh;
char *direc;
{
  my_send(fh->id);
  return NEWDIRECT;
}


int
friend_help()
{
     ansimore("etc/friendshelp",YEA);
     return FULLUPDATE;
}


void
friendtitle()
{
   char	title[ STRLEN ];
   extern char BoardName[];

   if ( chkomail(currentuser.userid) )
	strcpy( title, "[1;41;5m[�z������]" );
   else
	strcpy( title, BoardName );

   if( iscolor )
      showtitle( "�n�ͦC��", title );
   else
      titletmp( "�n�ͦC��", title );
   showansi=1;
   prints(" [0;1m���}[��,e]  ���[��,��]  �W�[�n��[a]  �R���n��[d]  �ק�n�ͻ���[E]  �D�U[h][m\n");
   move(2,0);
   standout();
   prints(" �s��  �n�ͥN��      �n�ͻ���                                                   \n");
   standend();
   clrtobot() ;
   showansi=0;

}

char *
friend_doentry(num,fh)
int num;
struct friend *fh;
{
        static char buf[STRLEN/2];
        
        sprintf(buf," %4d  %-12.12s  %s",num,fh->id,fh->exp);
        return buf;
}


void
t_override()
{

struct one_key  friend_comms[] = {
    'r',        friend_query,
    'a',        friend_add,
    'A',        friend_add,
    'd',        friend_delete,
    'D',        friend_delete,
    'E',        friend_edit,
    'm',	friend_mail,
    'h',        friend_help,
    'H',        friend_help,
    '\0',       NULL
  } ;
    setuserfile( genbuf, "overrides" );
    i_read( OVERRIDE, genbuf , friendtitle , friend_doentry, friend_comms ,sizeof(struct friend));
    clear();
    return;
}   


struct user_info *
t_search(sid)
char *sid;
{
    int         i;
    extern      struct UTMPFILE *utmpshm;
    struct      user_info *tmp;

    resolve_utmp();
    for( i = 0; i < USHM_SIZE; i++ ) {
        tmp = &(utmpshm->uinfo[ i ]);
        if (!tmp->active || !tmp->pid )
            continue;
        if( !strcasecmp(tmp->userid,sid) )
            return tmp;
    }
    return NULL;
}
            

/*
 * send mesg to user..........rrrrrrr
 */

char	wallmsg[STRLEN];


int
s_msg()
{
   int	do_snedmsg(),msg;
   
      msg = do_sendmsg(NULL,NULL,NORMAL);
      return msg;
}

int
do_sendmsg(uentp, msgstr, mode)
struct user_info *uentp;
char *msgstr;
int  mode;
{
    char	uident[STRLEN] ;
    int		tuid ;
    FILE	*fp;
    struct	user_info uin ;
    int		state,ucount,unum,tmp;
    char	buf[80],msgbuf[256] ,msgbuf2[256];
    int		lastmode;
    struct	tm		*msgdate;
    time_t	msgtime;
    
    
    
    lastmode = uinfo.mode;
    modify_user_mode( MSG );
    move(2,0) ;

    if(uentp==NULL){
    	prints("<��J�ϥΪ̥N��>\n") ;
    	move(1,0) ;
    	clrtoeol() ;
    	prints("�e�T����: ") ;
    	creat_list() ;
    	namecomplete(NULL,uident) ;
    	if(uident[0] == '\0') {
            clear() ;
            return 0;
    	}
    	if(!(tuid = getuser(uident)) || tuid == usernum) {
       	    if(uentp==NULL){
	        move(2,0) ;
        	prints("���~���ϥΪ� ID\n") ;
        	pressreturn() ;
        	move(2,0) ;
        	clrtoeol() ;
       	    }
        return -1;
    }
    ucount=count_logins( &uin, t_cmpuids, tuid, 0);
    
    if(ucount>1) {
again:   
    	move(3,0);
    	prints("�ثe %s �� %d logins �p�U: \n", uident, ucount);
   	clrtobot() ;
    	move(5,0) ;
    	prints("(0) ���Q�e�T��\n");
    	ucount=count_logins( &uin, t_cmpuids, tuid, 0);
    	count_logins( &uin, t_cmpuids, tuid, 1);
    	clrtobot() ;
    	tmp=ucount+8;
    	getdata( tmp, 0, "�п�ܤ@�� login number [0]: ",genbuf, 4, DOECHO, NULL );
    	unum=atoi(genbuf);
    	if(unum == 0) { clear(); return 0; }
    	    if(unum > ucount || unum < 0) {
        	move(tmp,0);
        	prints("����F�I\n") ;
        	clrtobot();
        	pressreturn();
        	goto again;
             }
         search_ulistn( &uin, t_cmpuids, tuid, unum );
        } else  search_ulist( &uin, t_cmpuids, tuid );  
    } else {
        if(!strcmp(uentp->userid,currentuser.userid))
             return; 
        uin=*uentp;
        strcpy(uident,uin.userid); 
        tuid = getuser(uident); 
    }
    
     if (!HAS_PERM(PERM_SYSOP) || msgstr==NULL) {
        if( !canpage(friend_me(&uin),uin.pager) ) {
            move(2,0) ;
            prints("���I�s���w����.\n") ;
            pressreturn() ;
            return -1 ;
        }
    }
    
    if(uin.mode == ULDL || uin.mode == IRCCHAT || uin.mode == BBSNET ) {
        move(2,0) ;
        prints("�ثe�L�k�e�T��.\n") ;
        pressreturn() ;
        return -1 ;
    }
    if(!uin.active ) {
        move(2,0) ;
        prints("���w���u\n") ;
        pressreturn() ;
        return -1 ;
    }

    if( msgstr==NULL ) {
        move(1,0);
        clrtoeol();
        prints("�e���H���G%s",uident);
        getdata( 2, 0, "���H : ", buf, 50, DOECHO, NULL);
      	getdata( 2, 0, "�T�w�n�e�X��(Y/N)? [Y]: ", 
             			genbuf, 2, DOECHO, NULL );

        if ( genbuf[0] == 'n' || genbuf[0] == 'N' ) {
            move(1,0); clrtoeol();
            move(2,0); clrtoeol(); 
            return 0;
        }
        sprintf(msgbuf,"[0;1;44;33m%s(%s)�ǨӡG[1;37;44m%-65.80s[m", 
        			currentuser.userid, currentuser.username, buf);
        sprintf(msgbuf2,"%-100.100s[m",msgbuf);
        
        sprintf(genbuf, "home/%s/msgfile.all", uident);
        if( ( fp= fopen(genbuf, "a+")) == NULL )
             return -1;
        msgtime = time(0);
        msgdate = localtime(&msgtime);
        fprintf(fp, "%2.2d:%2.2d [%s] : %s\n", msgdate->tm_hour, msgdate->tm_min,
     	          currentuser.userid, buf);
        fprintf(fp, "-----------------------------------------------------------------------------\n");
        fclose(fp);
     } else strcpy(msgbuf2,msgstr);

     sprintf(genbuf,"home/%s/msgfile",uident);
     if( ( fp= fopen(genbuf, "w")) == NULL ) 
         return -1;
     fputs( msgbuf2, fp );
     fclose(fp);

     if( kill( uin.pid,SIGTTOU) == -1 && msgstr == NULL ) {
         prints("\n���w�g���u....\n") ; 
         pressreturn();
         clear();
         return -1;
     }
     if( msgstr == NULL ){
         if( mode!=REPLY ){
             prints("�w�e�X�T��....\n") ;
             pressreturn();
             clear() ;
         }
     }
    modify_user_mode(lastmode);
    return 0 ;
}


int
dowall(uin)
struct user_info *uin;
{
    if (!uin->active || !uin->pid ) 
       return -1;
    move(1,0);
    clrtoeol();
    prints("[1;32m���� %s �s��.... Ctrl-D ����惡�� User �s���C[m",uin->userid); 
    refresh();
    do_sendmsg(uin,wallmsg,NORMAL);
}


int
wall()
{
    char uident[STRLEN],buf[STRLEN];
    int tuid ;
    struct user_info uin ;
    int state;
    char *p;

    modify_user_mode( MSG );
    move(2,0) ; clrtobot();
    getdata( 2, 0, "���H : ", buf, 73, DOECHO, NULL,YEA);
    getdata( 2, 0, "�T�w�n�e�X��(Y/N)? [Y]: ", 
        genbuf, 2, DOECHO, NULL ,1);
    clear();
    if ( *genbuf == 'n' || *genbuf == 'N' ) {
        move(1,0); clrtoeol();
        move(2,0); clrtoeol(); 
        return 0;
    }
    sprintf(wallmsg,"[0;1;44;33m����(�s��)�G[m[1;37;44m%-80.80s\n",buf);
    if( apply_ulist( dowall ) == -1 ) {
        move(2,0);
        prints( "�S������ϥΪ̤W�u\n" );
        pressanykey();
    }
    prints("\n�w�g�s������....\n");
    pressanykey();
}



void
r_msg()
{
    int	ch;
    int y,x;
    FILE *fp;
    char buf[120] ;
    char fname[STRLEN] ;
    int good_id=NA;
    char *ptr,usid[IDLEN];
    struct user_info *uin ;
   
    
    signal(SIGTTOU,r_msg) ;
    getyx(&y,&x);
    bell();
    bell();
    sprintf(fname,"home/%s/msgfile",currentuser.userid);
    if((fp=fopen(fname,"r"))==NULL)
        return;
    fgets( buf, 120, fp );
    saveline(0, 0);
    move(0,0);
    clrtoeol(); 
    showansi=1;
    move(0,0); 
    prints("%s",buf); 
    refresh();
    showansi=0;
    oflush();
    report("Get message");    
    
    ptr=(char *)strtok(buf+12,"(");
    if(ptr==NULL || !strcmp(ptr,currentuser.userid))
      	good_id=YEA;
    else{
      	strcpy(usid,ptr);
      	uin=t_search(usid);
      	if(uin==NULL)
	   good_id=NA;
	else good_id=YEA;
    }
    fclose(fp);

    if(!(uinfo.in_chat == YEA||uinfo.mode==TALK|| uinfo.mode==PAGE) && good_id==YEA) {
    	     move(1,0);
    	     clrtoeol();
    	     prints("*** �i�� r �^���H, �Ϋ� enter ���� ***");
    	     refresh();
    	     while(ch!='\n'&&ch!='\r'){
    	       ch=igetkey();
    	       if(ch=='\n'||ch=='\r')
    	           break;
    	       if(ch=='r'||ch=='R'){
    	               report("Reply MSG");
    	               move(1,0);
    	               clrtoeol();
    	               sprintf(buf,"�^�T���� %s: ",usid);
    	               prints("%s",buf);
    	               do_sendmsg(uin,NULL,REPLY);
    	           }else {
    	               report("Lost Sender of MSG ");
    	           }
    	           sleep(1);
    	           break;
    	       }
    }else igetch();
    
    saveline(0, 1); /* restore line */
    move(y,x);
    refresh();
    return ;
}

v_msg()
{
    char   filepath[30];
    
    modify_user_mode(VMSG);
    sprintf(filepath,"home/%s/msgfile.all",currentuser.userid);
    ansimore(filepath,YEA);
    clear();
    return  FULLUPDATE;

}

/*
 *  end of sendmsg
 */

get_load(load)
float	*load;
{
    double	av[3];

#if defined(LINUX)
    FILE *fp;
    fp = fopen ("/proc/loadavg", "r");
    if (!fp) av[0] = av[1] = av[2] = 0;
    else {
        float av[3];
        fscanf (fp, "%g %g %g", av, av + 1, av + 2);
        fclose (fp);
    }
#elif defined(BSD44)
    getloadavg( av, 3 );
#endif  

    load[0] = av[0]; load[1]=av[1]; load[2]=av[2];
}

