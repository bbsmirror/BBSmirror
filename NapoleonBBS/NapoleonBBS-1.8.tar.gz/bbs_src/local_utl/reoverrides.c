#include        <stdio.h>
#include        <sys/types.h>
#include        <sys/stat.h>
#include        <dirent.h>
#include        <limits.h>
#include        "bbs.h"


report()
{
}

cmpuids(uid,up)
char *uid ;
struct userec *up ;
{
    if (!strncasecmp(uid, up->userid, sizeof(up->userid))) {
        strncpy( uid, up->userid, sizeof( up->userid ));
        return 1;
    } else {
        return 0;
    } 
}


int
redo_override(source, target)
char	*source;
char	*target;
{
    FILE	*sfp, *tfp;
    struct	friend  fn;
    char	genbuf[STRLEN],*nick;
    
    if( (sfp = fopen(source,"r")) == NULL){
        printf("No [%s] file\n",source);
        return  0;
    }
    while(fgets(genbuf, STRLEN, sfp) != NULL) {
        strtok( genbuf, " \n\r\t" );
        strcpy( fn.id, genbuf );
        nick = (char *) strtok( NULL, "\n\r\t" );
        if( nick != NULL ) {
            while( *nick == ' ' )  nick++;
            if( *nick == '\0' )  nick = NULL;
        }
        if( nick != NULL ) {
           if( strlen(nick) > 40 )
               nick[40] = '\0';
            strcpy( fn.exp, nick);
        } else fn.exp[0] = '\0';
        append_record(target,&fn,sizeof(struct friend));
    }
    fclose(sfp);
    return 1;
}



void
do_overrides(direct,fname)
char *direct;
char *fname;
{
  DIR	*dp;
  struct dirent *dirp;
  char  control[80];
  char  buf[80];
           
    
  printf("�i�J�ؿ� %s\n",direct);
  if( (dp = opendir(direct))==NULL){
       printf("OpenDir error for %s\n",direct);
       return;
  }
  while((dirp = readdir(dp))!=NULL){
       char pname[256];
       DIR  *subdp;
       
       if(!strcmp(dirp->d_name,".")||!strcmp(dirp->d_name,".."))
                continue;
       printf("into directory [%s]\n", dirp->d_name);
       sprintf(control,"%s/%s/%s",direct,dirp->d_name,fname);
       sprintf(buf,"%s.bak",control);
       rename(control,buf);
       printf("redo override\n");
       redo_override(buf, control);
       unlink(buf);
   }
   closedir(dp);  
}


void
do_cancel(direct,fname)
char *direct;
char *fname;
{
  DIR	*dp;
  FILE	*fd;
  struct dirent *dirp;
  char  control[80];
           
    
  printf("�i�J�ؿ� %s\n",direct);
  if( (dp = opendir(direct))==NULL){
       printf("OpenDir error for %s\n",direct);
       return;
  }
  while((dirp = readdir(dp))!=NULL){
       char pname[256];
       DIR  *subdp;
       
       if(!strcmp(dirp->d_name,".")||!strcmp(dirp->d_name,".."))
                continue;
       printf("into directory [%s]\n", dirp->d_name);
       sprintf(control,"%s/%s/%s",direct,dirp->d_name,fname);
       if((fd=fopen(control,"r"))!=NULL){
          unlink(control);
          printf("cancel %s\n",fname);
          fclose(fd);
       }
  }
  closedir(dp);
}


main(argc,argv)
int	argc;
char	*argv[];
{
        char	dir[80];
        char	fname[20];
        char	*command;
        
	if (argc < 3) {
            printf("Usage:\t%s (cancel|trans) <bbshome/dir> <filename>\n", argv[0]);
            exit(-1);
        }
        command = argv[1];

        strcpy(dir,argv[2]);
        sprintf(fname,argv[3]);
        if( strcasecmp(command,"cancel")==0 ){
            do_cancel(dir,fname);
        } else if(strcasecmp(command,"trans")==0){
           do_overrides(dir,fname);
        } else {
            printf("Usage:\t%s (cancel|trans) <bbshome/dir> <filename>\n", argv[0]);
            exit(-1);
        }
}

