#include "bbs.h"


main()
{
        FILE *rec,*rec2;
        int i=0;
        struct boardheader fh;
        rec=fopen("./.BOARDS","rb");
        rec2=fopen("./.BOARDS.tmp","wb");
        

        printf("Records transfer...");
        while(1){
             i++;
             if(fread(&fh,sizeof(fh),1,rec)<=0) break;
             fh.level &= ~PERM_SETREAD;
             fwrite(&fh,sizeof(fh),1,rec2);     
        }
        printf("\n%d records changed...\n",i);
        fclose(rec);
        fclose(rec2);
}
