/*
 *	xyz.c
 */

#define EXTERN
#include "bbs.h"


int
modify_user_mode( mode )
int	mode;
{
    uinfo.mode = mode;
    update_ulist( &uinfo, utmpent );
    return 0;
}

void
showperminfo( pbits, i )
int	pbits, i;
{
    char	buf[ STRLEN ];

    sprintf( buf, "%c. %-20s %3s\n", 'A' + i, permstrings[i],
	    ((pbits >> i) & 1 ? "ON" : "OFF"));
    move( i+6-(( i>14)? 15:0) , 0+(( i>14)? 40:0) );
    prints( buf );
}

unsigned
setperms(pbits)
unsigned pbits;
{
    int lastperm = NUMPERMS - 1;
    int i, done = NA;
    char choice[2];

    move(4,0);
    prints("Enter the permission letter to toggle, RETURN when done.\n");
    move(6,0);
 /*   pbits &= (1 << NUMPERMS) - 1;*/
    for (i=0; i<=lastperm; i++) {
	showperminfo( pbits, i );
    }
    clrtobot();
    while (!done) {
	getdata(t_lines-1, 0, "Choice (ENTER to quit): ",choice,2,DOECHO,NULL);
	*choice = toupper(*choice);
	if (*choice == '\n' || *choice == '\0') done = YEA;
	else if (*choice < 'A' || *choice > 'A' + lastperm) bell();
	else {
	    i = *choice - 'A';
	    pbits ^= (1 << i);
	    showperminfo( pbits, i );
	}
    }
    return( pbits );
}


int
x_level()
{
    int id ;
    int newlevel;

    move(0,0) ;
    prints("Change User Priority\n") ;
    modify_user_mode(ADMIN);
    clrtoeol() ;
    move(1,0) ;
    usercomplete("Enter userid to be changed: ",genbuf) ;
    if(genbuf[0] == '\0') {
	clear() ;
	return 0 ;
    }
    if(!(id = getuser(genbuf))) {
	move(3,0) ;
	prints("Invalid User Id") ;
	clrtoeol() ;
	pressreturn() ;
	clear() ;
	return 0 ;
    }
    clear();
    move(1,0);
    clrtobot();
    move(2,0);
    prints("Set the desired permissions for user '%s'\n", genbuf);
    newlevel = setperms(lookupuser.userlevel);	
    move(2,0);
    if (newlevel == lookupuser.userlevel)
	prints("User '%s' level NOT changed\n", lookupuser.userid);
    else {
        lookupuser.userlevel = newlevel;
        substitute_record(PASSFILE,&lookupuser,sizeof(struct userec),id) ;
        prints("User '%s' level changed\n",lookupuser.userid) ;
	sprintf(genbuf, "changed permissions for %s", lookupuser.userid);
	report(genbuf);
    }
    pressreturn() ;
    clear() ;
    return 0 ;
}



int
x_cloak()
{
    report("toggle cloak");
    uinfo.invisible = (uinfo.invisible)?NA:YEA ;
    update_utmp();
    if (!uinfo.in_chat) {
	move(2,0) ;
	prints( "�����N (cloak) �w�g%s�F!",
		(uinfo.invisible) ? "�Ұ�" : "����" ) ;
	pressreturn();
    }
    return 0 ;
}


int
x_date()
{
    time_t t;
    move(2,0);
    time(&t);
    prints("�ثe�t�Τ���P�ɶ�: %s", ctime(&t));
    clrtoeol();
    pressreturn();
    return 0;
}

void
x_Iscolor()
{
  
  if(iscolor)
    iscolor=currentuser.address[STRLEN-9]=NA;
  else
    iscolor=currentuser.address[STRLEN-9]=YEA;
  substitute_record(PASSFILE,&currentuser,sizeof(struct userec),usernum);    
}    
  

void
x_editsig()
{
    int aborted;
    char ans[7];
    static char msg[] = "�п��ñ�W�� (1/2/3)[1]: ";    
    int	j;    
    
    move(3,0);
    clrtoeol();
    clrtobot();
    modify_user_mode( EDITSIG );
    clear();
 
    j = showsignature(genbuf);
    if (currentuser.flags[0] & SIG_FLAG)    
      getdata(0,0,"(E)���, (D)�R��, (T)�}��ñ�W��, [S]�]�wDEFAULTñ�W�� or (Q)����? [E]: ",ans,2,DOECHO,NULL);
    else
      getdata(0,0,"(E)�s��, (D)�R��, (T)����ñ�W��, [S]�]�wDEFAULTñ�W�� or (Q)���� [E]: ",ans,2,DOECHO,NULL);

    if (ans[0] == 'D' || ans[0] == 'd') {
        aborted=1;
    }
    if (ans[0] == 'E' || ans[0] == 'e')
      aborted = 2;
    if(ans[0]=='Q'||ans[0]=='q')
      aborted =0;
    if (ans[0] == 'T' || ans[0] == 't') {
       move(1,0);
       if (currentuser.flags[0] & SIG_FLAG) {
           currentuser.flags[0] &= ~SIG_FLAG;
           prints("ñ�W�ɤw�}��(enabled).\n");
        }
        else {
            currentuser.flags[0] |= SIG_FLAG;
            prints("ñ�W�ɤw����(disabled).\n");
        }
        substitute_record(PASSFILE,&currentuser,sizeof(struct userec),usernum);
        pressreturn();
        clear();
        return;
    }
    
    msg[21]=currentuser.flags[1];
    if (ans[0] == 'S' || ans[0] == 's') {
       move(0,0); 
       clrtoeol();
       prints("�ثe�]�w���� [%c] ñ�W��",currentuser.flags[1]);
       getdata(1,0,msg, ans, 2, DOECHO);
       if (ans[0] == '\0')
           ans[0] = currentuser.flags[1] ;
       if (ans[0] >= '1' && ans[0] <= '3')
	   currentuser.flags[1]=ans[0];
       substitute_record(PASSFILE,&currentuser,sizeof(struct userec),usernum);
       pressreturn();
       return;
    }     
       
      
    if (aborted){
       getdata(1, 0, msg, ans, 2, DOECHO);
       if (ans[0] == '\0')
          ans[0] = currentuser.flags[1];
       if (ans[0] >= '1' && ans[0] <= '3'){
          genbuf[j] = ans[0];
          if (aborted == 1){
   	     unlink(genbuf);
	     outs("ñ�W�ɤw�R��");
          } else{
	     modify_user_mode(EDITSIG);
 	     aborted = vedit(genbuf, NA);
	     clear();
	     if (!aborted)
	        outs("ñ�W�ɧ�s����");
          }
        }
       pressanykey();
    }
    return;
}



void
x_editplan()
{
    int aborted;
    char ans[7];

    setuserfile( genbuf, "plans" );
    move(3,0);
    clrtoeol();
    clrtobot();
    modify_user_mode( EDITPLAN );
    getdata(3,0,"(E)dit or (D)elete plan? [E]: ",ans,7,DOECHO,NULL);
    if (ans[0] == 'D' || ans[0] == 'd') {
	unlink(genbuf);
	move(5,0);
	prints("It's history!\n");
	report("delete plan");
	pressreturn();
	clear();
	return;
    }

    aborted = vedit(genbuf, NA);		
    clear();
    if (!aborted) {
	prints("Plan updated.");
	report("edited plan");
    }
    pressreturn();
}


void
x_forward()
{
  modify_user_mode(FORM);
  if( (char *)strchr(currentuser.termtype+16,'$') || invalidaddr(currentuser.termtype+16) || currentuser.termtype[16]=='\0'){
     clear();
     move(9,9);
     prints("���z���֦����T email address, ���i�]�w�۰� forward");
     pressreturn();
     return ;     
  }
  if(HAS_PERM(PERM_UNUSE14)){
     currentuser.userlevel ^= PERM_UNUSE14;
     clear();
     move(9,9);
     prints("������ Auto-forward �]�w");
  } else {
     currentuser.userlevel |= PERM_UNUSE14;
     ansimore("etc/x_forward",NA);
     move(t_lines-2,0);
     prints("�H��H��N�Q Forward-To: %s",currentuser.termtype+16);     
  }
  substitute_record(PASSFILE,&currentuser,sizeof(struct userec),usernum) ;
  pressreturn();
}  
 


#ifdef BBSDOORS
void
ent_bnet()  /* Bill Schwartz */
{
    int save_pager = uinfo.pager;

#ifdef LINUX
    int	f_load[3];

    get_load(f_load);
    if( f_load[0] > 150 ){
      clear();
      move(0,0);
      prints("load to high to exec bbsnet");
      return ;
    } 
#endif

    uinfo.pager = NA;
    report("BBSNet Enter") ;

    modify_user_mode( BBSNET );

    reset_tty() ;
    do_exec("bbs",NULL) ;
    restore_tty() ;
    uinfo.pager = save_pager;
    report("BBSNet Exit") ;
    clear() ;
}
#endif


