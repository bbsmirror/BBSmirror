/*
 *	main.c
 */




#include "bbs.h"

#define BADLOGINFILE    "logins.bad"

char    *getenv();

char    *Ctime();
jmp_buf byebye ;

int 	talkrequest = NA ;
int 	ntalkrequest = NA ;
int	enter_uflags;
struct	user_info uinfo ;

char	fromhost[ 60 ] ;
char	tty_name[ 20 ] ;

char	BoardName[STRLEN] ;
char	ULIST[STRLEN] ;
int	utmpent = -1 ;
time_t  login_start_time;
int     showansi=1;
int	iscolor=1;
char    friendstr[0x1000];
int	ANONYmode;

void
log_usies( mode, mesg )
char *mode, *mesg;
{
    time_t      now;
    FILE        *fp;
    char        buf[ 256 ], *fmt;

    now = time(0);
    fmt = currentuser.userid[0] ? "%s %s %-12s %s\n" : "%s %s %s%s\n";
    sprintf( buf, fmt, Ctime( &now )+4, mode, currentuser.userid, mesg );
    if( (fp = fopen( "var/usies", "a" )) != NULL ) {
        fputs( buf, fp );
        fclose( fp );
    }
}

void
u_enter()
{
    enter_uflags = currentuser.flags[0];
    memset( &uinfo, 0, sizeof( uinfo ) );
    uinfo.active = YEA ;
    uinfo.pid    = getpid();
    if( HAS_PERM(PERM_LOGINCLOAK) && (currentuser.flags[0] & CLOAK_FLAG) )
        uinfo.invisible = YEA;
    uinfo.mode = LOGIN ;
/*  uinfo.pager = !(currentuser.flags[0] & PAGER_FLAG);*/
    if(currentuser.flags[0] & PAGER_ALL) {
        uinfo.pager|=ALL_PAGER;
        uinfo.pager|=FRIEND_PAGER;
    }
    else{
        uinfo.pager&=~ALL_PAGER;
        if(currentuser.flags[0]&PAGER_FRIEND)
              uinfo.pager|=FRIEND_PAGER;
         else 
              uinfo.pager&=~FRIEND_PAGER;
    }

    uinfo.uid = usernum;
    strncpy( uinfo.from, fromhost, 60 );
#ifdef SHOW_IDLE_TIME
    strncpy( uinfo.tty, tty_name, 20 );
#endif
    strncpy( uinfo.userid,   currentuser.userid,   20 );
    strncpy( uinfo.realname, currentuser.realname, 20 );
    strncpy( uinfo.username, currentuser.username, 40 );
    memset( uinfo.stuff, '-', sizeof( uinfo.stuff ) );
    getfriendstr();
    utmpent = getnewutmpent(&uinfo) ;
}

void
setflags(mask, value)
int mask, value;
{
    if (((currentuser.flags[0] & mask) && 1) != value) {
        if (value) currentuser.flags[0] |= mask;
        else currentuser.flags[0] &= ~mask;
    }
}

void
u_exit()
{
/*  setflags(PAGER_FLAG, !uinfo.pager);*/
    if(uinfo.pager&ALL_PAGER) {
        currentuser.flags[0]|=PAGER_ALL;
        currentuser.flags[0]|=PAGER_FRIEND;
    } else {
        currentuser.flags[0]&=~PAGER_ALL;
        if(uinfo.pager&FRIEND_PAGER)
           currentuser.flags[0]|=PAGER_FRIEND;
        else
           currentuser.flags[0]&=~PAGER_FRIEND;
    }

   
/*    setflags(PAGER_FLAG, (uinfo.pager&ALL_PAGER));*/
    if (HAS_PERM(PERM_LOGINCLOAK))
        setflags(CLOAK_FLAG, uinfo.invisible);

    if( currentuser.flags[0] != enter_uflags ) {
        substitute_record(PASSFILE,&currentuser,sizeof(currentuser),usernum);
    }

    uinfo.active = NA ;
    uinfo.pid = 0 ;
    uinfo.invisible = YEA ;
    uinfo.sockactive = NA ;
    uinfo.sockaddr = 0 ;
    uinfo.destuid = 0 ;
#ifdef SHOW_IDLE_TIME
    strcpy(uinfo.tty, "NoTTY");
#endif
    update_utmp();
}


int
cmpuids(uid,up)
char *uid ;
struct userec *up ;
{
    return !ci_strncmp(uid,up->userid,sizeof(up->userid)) ;
}



int
dosearchuser(userid)
char *userid ;
{
    int         id;

    if( (id = getuser( userid )) != 0 ) {
        if( cmpuids( userid, &lookupuser ) ) {
            memcpy( &currentuser, &lookupuser, sizeof(currentuser) );
            return usernum = id;
        }
    }
    memset( &currentuser, 0, sizeof( currentuser ) );
    return usernum = 0;
}

int started = 0;



void
talk_request()
{
#ifdef	LINUX
    signal(SIGUSR1,talk_request);
#endif
    talkrequest = YEA ;
    bell(); bell(); bell();
    sleep( 1 );
    bell(); bell(); bell(); bell(); bell();
    return ;
}


void
abort_bbs()
{
    time_t      stay;

    if(uinfo.mode==POSTING||uinfo.mode==SMAIL||uinfo.mode==EDITWELC)
                keep_fail_post();
    if( started ) {
        stay = time( 0 ) - login_start_time;
        sprintf( genbuf, "Stay: %3ld (%s)", stay / 60, currentuser.username );
        log_usies( "AXXED", genbuf );
        u_exit();
    }
    exit( 0 );
}



int
cmpuids2(unum, urec)
int unum;
struct user_info *urec;
{
    return (unum == urec->uid);
}


int
count_multi( uentp )
struct user_info *uentp;
{
    static int  count;

    if( uentp == NULL ) {
        int     num = count;
        count = 0;
        return num;
    }
    if( !uentp->active || !uentp->pid )
        return 0;
    if( uentp->uid == usernum )
        count++;
    return 1;
}

int
count_user()
{
    count_multi( NULL );
    apply_ulist( count_multi );
    return count_multi( NULL );
}




void
multi_user_check()
{
    struct user_info uin;
    char buffer[40];

    if (HAS_PERM(PERM_MULTILOG)) return;  /* don't check sysops */

    /* allow multiple guest user */
    if (!strcmp("guest", currentuser.userid)) {
        if ( count_user() > 16 ) {
            prints( "��p, �ثe�w���Ӧh guest, �еy��A�աC\n");
            pressreturn();
            oflush();
            exit(1);
        }
        return;
    }
    if ( !search_ulist( &uin, cmpuids2, usernum) )
        return;  /* user isn't logged in */

    if (!uin.active || (kill(uin.pid,0) == -1))
        return;  /* stale entry in utmp file */

    getdata(0, 0, "�z�Q�R�����ƪ� login �� (Y/N)? [N]", genbuf, 4, 
            DOECHO, NULL);

    if(genbuf[0] == 'Y' || genbuf[0] == 'y') {
        kill(uin.pid,9);
        sprintf(buffer, "kicked (multi-login)" );
        report(buffer);
        log_usies( "KICK ", currentuser.username );
    }
}



int
simplepasswd( str )
char *str;
{
    char        ch;

    while( (ch = *str++) != '\0' ) {
        if( ! (ch >= 'a' && ch <= 'z') )
            return 0;
    }
    return 1;
}



void
system_init(argc, argv)
int     argc;
char    **argv;
{
    char        *rhost;
    void	r_msg();
 
    login_start_time = time( 0 );
    gethostname( genbuf ,256 );
#ifdef SINGLE
    if( strcmp( genbuf, SINGLE ) ) {
        printf("Not on a valid machine!\n") ;
        exit(-1) ;
    }
#endif
    sprintf( ULIST, "%s.%s", ULIST_BASE, genbuf );

    if( argc >= 3 ) {
        strncpy( fromhost, argv[2], 60 );
    } else {
        fromhost[0] = '\0';
    }
    if( (rhost = getenv( "REMOTEHOSTNAME" )) != NULL )
        strncpy( fromhost, rhost, 60 );
#ifdef SHOW_IDLE_TIME
    if(argc >= 4) { 
        strncpy( tty_name, argv[3], 20 ) ;
    } else {
        tty_name[0] = '\0' ;
    }
#endif

#ifndef lint
    signal(SIGHUP,abort_bbs) ;
    signal(SIGINT,SIG_IGN) ;
    signal(SIGQUIT,SIG_IGN) ;
    signal(SIGPIPE,SIG_IGN) ;
#ifdef DOTIMEOUT
    init_alarm();
#else
    signal(SIGALRM,SIG_IGN) ;
#endif
    signal(SIGTERM,SIG_IGN) ;
    signal(SIGURG,SIG_IGN) ;
    signal(SIGTSTP,SIG_IGN) ;
    signal(SIGTTIN,SIG_IGN) ;
    signal(SIGTTOU,SIG_IGN) ;
    signal(SIGUSR1,talk_request) ;
    signal(SIGTTOU,r_msg);
#endif
}



void
system_abort()
{
    if( started ) {
        log_usies( "ABORT", currentuser.username );
        u_exit() ;
    }
    clear();
    refresh();
    printf("���¥��{, �O�o�`�ӳ� !\n");
    exit(0) ;
}

void
logattempt( uid, frm )
char *uid, *frm;
{
    char        fname[ STRLEN ];
    int         fd, len;

    sprintf( genbuf, "%-12.12s  %-30s %s\n",
                uid, Ctime( &login_start_time ), frm );
    len = strlen( genbuf );
    if( (fd = open( BADLOGINFILE, O_WRONLY|O_CREAT|O_APPEND, 0644 )) > 0 ) {
        write( fd, genbuf, len );
        close( fd );
    }
    sethomefile( fname, uid, BADLOGINFILE );
    if( (fd = open( fname, O_WRONLY|O_CREAT|O_APPEND, 0644 )) > 0 ) {
        write( fd, genbuf, len );
        close( fd );
    }
}


void
login_query()
{
    char        uid[STRLEN], passbuf[PASSLEN], *ptr;
    int         curr_login_num;
    int         attempts;
    int		randtime;
    char	tby[10];
    int		issueget;
    int		issuenum,maxlogin;
    int		animenum;
    char	fname[STRLEN];
    FILE	*fn,*PASS;
    char	*sysconf_str();        


    curr_login_num = num_active_users();
    maxlogin=sysconf_eval("MAXLOGIN_NUM");
    if( curr_login_num >= maxlogin ) {
        ansimore ( "etc/loginfull", NA );
        oflush();
        sleep( 1 );
        exit( 1 ) ;
    }
    ptr = sysconf_str( "BBSNAME" );
    if( ptr == NULL )  ptr = "�|���R�W���կ�";
    strcpy( BoardName, ptr );
 
    ansimore("etc/issue",NA);
    showansi=1;
    prints( "�w����{ [1;36m%s[0m (�ثe�@�� %d �H�W�u)\n", BoardName, curr_login_num );
    attempts = 0;
    while( 1 ) {
        if( attempts++ >= LOGINATTEMPTS ) {
            ansimore( "etc/goodbye", NA );
            oflush();
            sleep( 1 );
            exit( 1 );
        }
   
      getdata( 0, 0, "\n�п�J�N��(�եνп�J `guest', ���U�п�J`new'): ",
                uid, STRLEN, DOECHO, NULL );
        if( strcmp( uid, "new" ) == 0 ) {
#ifdef LOGINASNEW
            memset( &currentuser, 0, sizeof( currentuser ) );
            new_register();
            break;
#else
            prints( "���t�Υثe�L�k�H new ���U, �Х� guest �i�J.\n" );
#endif
        } else if( *uid == '\0' || !dosearchuser( uid )||bad_user_id(uid) ) {
            printf( "[1;33m���~���ϥΪ̥N��...[0m\n" );
        } else if( strcmp( uid, "guest" ) == 0 ) {
            currentuser.userlevel = 0;
            currentuser.flags[0] = CURSOR_FLAG | ~PAGER_ALL;
            break;
        } else {
            getdata( 0, 0, "�п�J�K�X: ", passbuf, PASSLEN, NOECHO, NULL );
            passbuf[8] = '\0';
            if( !checkpasswd( currentuser.passwd, passbuf ) ) {
                logattempt( currentuser.userid, fromhost );
                printf( "[1;36m�K�X��J���~...[0m\n" );
            } else {
                if( !HAS_PERM( PERM_BASIC ) ) {
                    prints( "���b���w�����C�ЦV SYSOP �d�߭�]\n" );
                    oflush();
                    sleep( 1 );
                    exit( 1 );
                }
                if( simplepasswd( passbuf ) ) {
                    prints("* �K�X�L��²��, �п�ܤ@�ӥH�W���S���r��.\n");
                    getdata( 0, 0, "�� [Enter] �~��",genbuf,10,NOECHO,NULL);
                }
               break;
            }
          }
    }
    multi_user_check();
    if( !term_init(currentuser.termtype) ) {
        prints("Bad terminal type.  Defaulting to 'vt100'\n") ;
        term_init("vt100") ;
    }
    sprintf(fname,"home/%s/%s.deadve",currentuser.userid,currentuser.userid);
    if((fn=fopen(fname,"r"))!=NULL)
    {
        mail_file(fname,currentuser.userid,"[�t�ΫH��] �����`�_�u�ҫO�d������");
        unlink(fname);
    }    
    sethomepath( genbuf, currentuser.userid );
    mkdir( genbuf, 0755 );
    sprintf(genbuf,"%d on line",curr_login_num);
    report(genbuf);
    showansi=0;
}



int
valid_ident( ident )
char *ident;
{
    static char *invalid[] = { "unknown@", "root@", "gopher@", "bbs@",
        "guest@", NULL };
    int         i;

    for( i = 0; invalid[i] != NULL; i++ )
        if( strstr( ident, invalid[i] ) != NULL )
            return 0;
    return 1;
}




void
user_login()
{
    char        fname[ STRLEN ];
    char        ans[4], *ruser,*realhost;
    int         wan;
    void	start_note();
    void	start_sysnote();
    
    
    if( strcmp( currentuser.userid, "SYSOP" ) == 0 )
        currentuser.userlevel = ~0;   /* SYSOP gets all permission bits */

    ruser = getenv( "REMOTEUSERNAME" );
    sprintf( genbuf, "%s@%s", ruser ? ruser : "?", fromhost );
    log_usies( "ENTER", genbuf );
    if( ruser ) {
        sprintf( genbuf, "%s@%s", ruser, fromhost );
        if( valid_ident( genbuf ) ) {
            strncpy( currentuser.ident, genbuf, NAMELEN );
        }
        if( !valid_ident( currentuser.ident ) ) {
            currentuser.ident[0] = '\0';
        }
    }
    sys_num();
    u_enter() ;
    report("Enter") ;
    started = 1 ;
    initscr() ;
    scrint = 1 ;
        
        
    if(currentuser.numlogins==0||strcmp("guest",currentuser.userid)==0){
     bell();bell();
     ansimore("0Announce/note.ans");
     ansimore("0Announce/sysnote.ans");
    }
    else{
     start_note();
     start_sysnote();
    }
    ansimore ("etc/Welcome",YEA);
    wan= currentuser.numlogins ;
    showansi=1;    
    move( t_lines - 4, 0 );
    prints( "\n [1;46m *�o�O�z��[5;33m %d [0;1;46m�����X�����A�W���z�O�q %s �s�������C              [0m\n",
        currentuser.numlogins + 1, currentuser.lasthost );
    prints( " * �W���s�u����� %s ", ctime(&currentuser.lastlogin) );
    pressreturn();

    setuserfile( fname, BADLOGINFILE );
    if( ansimore( fname, NA ) != -1 ) {
        getdata( t_lines-1, 0, "�z�n�R���H�W�K�X��J���~���O���� (Y/N)? [Y] ",
                ans, 4, DOECHO, NULL );
        if( *ans != 'N' && *ans != 'n' )
            unlink( fname );
    }

    strncpy(currentuser.lasthost, fromhost, 16);
    currentuser.lasthost[15] = '\0';   /* dumb mistake on my part */
    currentuser.lastlogin = time(NULL) ;
    currentuser.numlogins++;
       if (currentuser.firstlogin == 0) {
        currentuser.firstlogin = login_start_time - 7 * 86400;
    }
    check_register_info();
    substitute_record(PASSFILE,&currentuser,sizeof(currentuser),usernum) ;

    showansi=0;
}

/*
 *   ����]�w�ƭ�
 */
sys_num()
{
   currentuser.address[STRLEN-4]=2;			        /* ���ʬݪ��ثe�� */
   currentuser.address[STRLEN-5]=sysconf_eval("SHOW_TOTALNUM"); /* ���ʬݪO�`�� */
   currentuser.address[STRLEN-6]=sysconf_eval("SHOW_LNNUM");	/* ���ʬݪ��`��� */
   currentuser.address[STRLEN-7]=sysconf_eval("SHOW_CONTROL");        /* ���� menu ���ϥ� */
   currentuser.address[STRLEN-8]=0;
   iscolor=currentuser.address[STRLEN-9];
   ANONYmode=YEA;
}



void
main(argc, argv)
int argc ;
char **argv ;
{
    int wan;
    extern char currmaildir[ STRLEN ];

#ifdef BBS_INFOD
    if (strstr( argv[ 0 ], "bbsinfo") != NULL) {
        load_sysconf();
        bbsinfod_main(argc, argv);
        exit( 0 );
    }
#endif

    load_sysconf();
    if( argc < 2 || *argv[1] != 'h' ) {
        printf( "You cannot execute this program directly.\n" );
        exit( -1 );
    }
    system_init( argc, argv );
    if( setjmp(byebye) ) {
        system_abort();
    }
    get_tty();
    init_tty();
    login_query();
    user_login();
    m_init();
    b_closepolls();
 
   if(!HAS_PERM(PERM_SYSOP))
    if( get_num_records( currmaildir, sizeof(struct fileheader) ) > 50 ) {
        clear();
        prints("\n�z���p�H�H��L�h, �ЧR���L���H��, ���q�����b 50 �ʥH�U.\n");
        pressreturn();
    }
    while( 1 ) {
        domenu( "0" );
        Goodbye();
    }
}

int refscreen = NA ;

int
egetch()
{
    int rval ;

    if (talkrequest) {
        talkreply() ;
        refscreen = YEA ;
        return -1 ;
    }
    while( 1 ) {
        rval = igetkey();
        if(talkrequest) {
            talkreply() ;
            refscreen = YEA ;
            return -1 ;
        }
        if( rval != Ctrl('L') )
            break;
        redoscr();
    }
    refscreen = NA ;
    return rval ;
}

char *
boardmargin()
{
    static char buf[15] ;
    if(selboard)
        sprintf(buf,"�Q�װ�: [%s]",currboard) ;
    else {
        brc_initial( DEFAULTBOARD );
        if (getbnum(currboard)) {
            selboard = 1 ;
            sprintf(buf,"�Q�װ�: [%s]",currboard) ;
        }
        else sprintf(buf,"�ثe�èS���]�w�Q�װ�") ;
    }
    return buf ;
}



void
showtitle( title, mid )
char    *title, *mid;
{
    char        buf[15], *note;
    int         spc;
    int         leng,wan;


    showansi=1;
    if(uinfo.mode<currentuser.address[STRLEN-7]){
       showback(uinfo.mode);
       active_board();
    }
    note = boardmargin();
    spc = 79 - strlen( title ) - strlen( mid ) - strlen( note );
    if( spc < 4 )  spc = 4;
    
    wan = (time(NULL)%7)+41;
    showansi=1;
    move(0,0);
    prints( "[1;%2dm%s",wan,title);
    if(chkmail()) leng=(104-strlen(mid))/2;
    else leng=(95-strlen(mid))/2;
    move(0,leng);
    prints("[1m%s[%2dm",mid,wan);
    if(chkmail()) leng=104-strlen(note);  
    else  leng=95-strlen(note);
    move(0,leng);
    prints( "[0;1;%2dm%s[0;1;36m\n",wan,note );
    showansi=0;
}

void
docmdtitle( title, prompt )
char    *title, *prompt;
{
    showansi=1;
    showtitle( title, chkmail() ? "[1;41;5m[�z������]": BoardName );
    move(1,0);
    showansi=1;
    prints( "%s", prompt );
    showansi=0;
    clrtoeol() ;
}




void
titletmp( title, mid )
char	*title, *mid;
{
    char	buf[ STRLEN ], *note;
    int		spc;

    if(uinfo.mode<currentuser.address[STRLEN-7]){
       showback(uinfo.mode);
       active_board();
    }
    note = boardmargin();
    spc = 78 - strlen( title ) - strlen( mid ) - strlen( note );
    if( spc < 4 )  spc = 4;
    move(0,0);
    sprintf( buf, "%*s", spc/2, "" );
    prints( "%s%s%s", title, buf, mid );
    sprintf( buf, "%*s", (spc+1)/2, "" );
    prints( "%s%s\n", buf, note );
}

void
docmdtmp( title, prompt )
char	*title, *prompt;
{
    titletmp( title, chkmail() ? "[�z������]" : BoardName );
    prints( "%s", prompt );
    clrtoeol() ;
}



void
start_note()
{
    struct	stat st;
    time_t	mtime;
    
    strcpy(genbuf,"var/note.ans");
    if( dashf( genbuf ) ) {
	    stat( genbuf, &st );
            mtime=st.st_mtime;
       if(mtime>currentuser.lastlogin){
         bell();bell();
         ansimore(genbuf);
         }
     }
}

void
start_sysnote()
{
    struct	stat st;
    time_t	mtime;
    
    strcpy(genbuf,"var/sysnote.ans");
    if( dashf( genbuf ) ) {
	stat( genbuf, &st );
        mtime=st.st_mtime;
        if(mtime>currentuser.lastlogin-86400)
           ansimore(genbuf);
     }
}


