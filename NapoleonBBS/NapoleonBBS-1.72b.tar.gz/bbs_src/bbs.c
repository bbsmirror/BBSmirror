/*
 *	bbs.c
 */


#include "bbs.h"

int	continue_flag;
int	scrint = 0 ;


struct	userec currentuser ;
int	usernum ;
char	currboard[STRLEN-BM_LEN] ;
char	currBM[BM_LEN] ;
int	selboard = 0 ;

void	report();
void	outgo_post();
void	cancelpost();

extern int	numboards;
extern time_t	login_start_time;
extern char	BoardName[];
extern int	cmpbnames();

char related_title[41]="\0";
char genbuf[ 1024 ];
char quote_file[ 256 ], quote_user[ 256 ];
#ifndef NOREPLY
char replytitle[STRLEN];
#endif

int totalusers,usercounter;

char *
sethomepath( buf, userid )
char	*buf, *userid;
{
    sprintf( buf, "home/%s", userid );
    return buf;
}

char *
sethomefile( buf, userid, filename )
char	*buf, *userid, *filename;
{
    sprintf( buf, "home/%s/%s", userid, filename );
    return buf;
}

char *
setuserfile( buf, filename )
char	*buf, *filename;
{
    sprintf( buf, "home/%s/%s", currentuser.userid, filename );
    return buf;
}

char *
setbpath( buf, boardname )
char *buf, *boardname;
{
    strcpy( buf, "boards/" );
    strcat( buf, boardname );
    return buf;
}

char *
setbdir( buf, boardname )
char *buf, *boardname;
{
    sprintf( buf, "boards/%s/%s", boardname, DOT_DIR );
    return buf;
}

char *
setbfile( buf, boardname, filename )
char *buf, *boardname, *filename;
{
    sprintf( buf, "boards/%s/%s", boardname, filename );
    return buf;
}

                        

void 
setquotefile(filepath)
char filepath[];
{
   strcpy(quote_file,filepath);
}   



int
uleveltochar( buf, lvl )
char	*buf;
unsigned lvl;
{
    lvl &= currentuser.userlevel;
    if( !(lvl & PERM_BASIC) ) {
	strcpy( buf, "----" );
	return 1;
    }
    if( lvl <= PERM_DEFAULT )
	return 0;
    buf[0] = (lvl & (PERM_CLOAK|PERM_SEECLOAK|PERM_CHATCLOAK)) ? 'C' : ' ';
    buf[1] = (lvl & (PERM_XEMPT)) ? 'X' : ' ';
    buf[2] = (lvl & (PERM_BOARDS)) ? 'B' : ' ';
    buf[3] = (lvl & (PERM_DENYPOST)) ? 'p' : ' ';
    if( lvl & PERM_ACCOUNTS ) buf[3] = 'A';
    if( lvl & PERM_SYSOP ) buf[3] = 'S';
    buf[4] = '\0';
    return 1;
}

char *
Ctime(clock)
time_t *clock;
{
    char *foo;
    char *ptr = ctime(clock);
    if( (foo = strrchr(ptr, '\n')) != NULL ) *foo = '\0';
    return (ptr);
}

void
printutitle()
{
    move(2,0) ;
    standout() ;
    prints("�ϥΪ̥N��     %-25s  #�W�� #�峹 %4s   �̪���{���  \n",
#if defined(ACTS_REALNAMES)
	"�u��m�W",
#else
	"�ϥΪ̼ʺ�",
#endif
	HAS_PERM(PERM_SYSOP)?"����":"" ) ;
    standend() ;
}

int
printuent(uentp)
struct userec *uentp ;
{
    static int	i;
    char permstr[10]; 

    if(uentp == NULL) {
	printutitle();
	i = 2 ;
	return 0;
    }
    if( uentp->numlogins == 0 ||
	uleveltochar( permstr, uentp->userlevel ) == 0 )
	return 0;
    if(i == t_lines-2) {
	int ch ;
	standout() ;
	prints("�w��� %d �H, ���U�H�� %d �H [�� Q ���}]",
		usercounter, totalusers );
	standend() ;
	clrtoeol();
	while((ch = igetch()) != EOF) {
	    if(ch == '\n' || ch == '\r' || ch == ' ')
		break ;
	    if(ch == 'q' || ch == Ctrl('C')) {
		move(t_lines-1,0) ;
		clrtoeol() ;
		return QUIT ;
	    }
	}
	printutitle();
	i = 2 ;
	clrtobot() ;
    }
    prints("%-14s %-25s  %5d %5d %4s %-16s\n",uentp->userid,
#if defined(ACTS_REALNAMES)
	uentp->realname,
#else
	uentp->username,
#endif 
	uentp->numlogins, uentp->numposts,
	HAS_PERM(PERM_SEEULEVELS) ? permstr : "",
	Ctime(&uentp->lastlogin) );
    i++ ;
    usercounter++;
    return 0 ;
}

int 
countusers2(userid,unum)
char	*userid;
int	unum;
{
    if( userid[0] != '\0')  totalusers++;
    return 0;
}

int
Users()
{
    totalusers = 0;
    apply_users( countusers2 );

    usercounter = 0;
    report("User List");
    modify_user_mode( LAUSERS );
    printuent((struct userec *)NULL) ;
    if(apply_record(PASSFILE,printuent ,sizeof(struct userec)) == -1) {
	prints("No Users Exist") ;
	pressreturn() ;
	return 0;
    }
    clrtobot() ;
    move(t_lines-1,0);
    prints("�@��� %d �H, ���U�H�� %d/%d �H�C[�Ы����N���~��]", 
                usercounter, totalusers, MAXUSERS);
    egetch();
    move(2,0);
    clrtoeol();
    return 0;
}


int
printtuent(uentp)
struct userec *uentp ;
{
    static int i ;
    char permstr[10];

    if(uentp == NULL) {
	printutitle();
	i = 2 ;
	return 0;
    }
    if( uentp->numlogins == 0 )
         return 0;
    if(i == t_lines-2) {
	int ch ;
	standout() ;
	prints("�w��� %d �H, ���U�H�� %d �H [�� Q ���}]",
		usercounter, totalusers );
	standend() ;
	clrtoeol();
	while((ch = igetch()) != EOF) {
	    if(ch == '\n' || ch == '\r' || ch == ' ')
		break ;
	    if(ch == 'q' || ch == Ctrl('C')) {
		move(t_lines-1,0) ;
		clrtoeol() ;
		return QUIT ;
	    }
	}
	printutitle();
	i = 2 ;
	clrtobot() ;
    }
    prints("%-14s %-25s  %5d %5d  %-20s\n",uentp->userid,
#if defined(ACTS_REALNAMES)
	uentp->realname,
#else
	uentp->username,
#endif 
	uentp->numlogins, uentp->numposts,
	Ctime(&uentp->lastlogin) );
    i++ ;
    usercounter++;
    return 0 ;
}


int
TUsers()
{

    totalusers = 0;
    apply_users( countusers2 );

    usercounter = 0;
    report("User List");
    modify_user_mode( LAUSERS );
    printtuent((struct userec *)NULL,0) ;
    if(apply_record(PASSFILE,printtuent,sizeof(struct userec)) == -1) {
	prints("No Users Exist") ;
	pressreturn() ;
	return 0;
    }
    clrtobot() ;
    move(t_lines-1,0);
    prints("�@��� %d �H, ���U�H�� %d/%d �H�C[�Ы����N���~��]", 
                usercounter, totalusers, MAXUSERS);
    egetch();
    move(2,0);
    clrtoeol();
    return 0;
}



int
g_board_names(fhdrp)
struct boardheader *fhdrp ;
{
    char	buf[STRLEN];
    

    if ((fhdrp->level & PERM_POSTMASK) || HAS_PERM(fhdrp->level)) {
	setvfile( buf, fhdrp->filename, "overrides");
    	if( fhdrp->level & PERM_SETREAD ) { 
 	   if( !seek_in_file(buf,currentuser.userid) )
	        return 0;
	   else AddNameList(fhdrp->filename) ;
	} else
	      AddNameList(fhdrp->filename) ;
    }
    return 0 ;
}



void
make_blist()
{
    CreateNameList() ;
    apply_boards(g_board_names) ;
}


int
Select()
{
    modify_user_mode( SELECT );
    do_select( 0, NULL, genbuf );
    return 0 ;
}



int
junkboard()
{
    return( strcmp( currboard, "test" ) == 0 ||
	    strcmp( currboard, "newscast" ) == 0 );
}


int
Post()
{
    if(!selboard) {
	prints("\n\n���� (S)elect �h��ܤ@�ӰQ�װϡC\n") ;
	pressreturn() ;
	clear() ;
	return 0 ;
    }
#ifndef NOREPLY
    *replytitle = '\0';
#endif
    modify_user_mode(POSTING);
    do_post();
    return 0 ;
}

void
readtitle()
{
    struct shortfile	*bp;
    struct shortfile	*getbcache();
    char	header[ STRLEN ], title[ STRLEN ];
    int		a;    

    bp = getbcache( currboard );
    memcpy( currBM, bp->BM, BM_LEN );
    if( currBM[0] == '\0' || currBM[0] == ' ' ) {
	strcpy( header, "�ثe�L�O�D" );
	prints( header );
    } else {
	sprintf( header, "�O�D: %s", currBM );
	prints( "�O�D: " );
	standout();
	prints( currBM );
	standend();
    }

    if ( chkmail() )
	strcpy( title, "[1;41;5m[�z������]" );
    else if ( currBM[ BM_LEN - 1 ]==1 )
	strcpy( title, "[�Q�װϧ벼��]" );
    else
#ifdef NAPOLEON
        strcpy(title,(char *)strchr(bp->title,' '));
#else
	strcpy(title,bp->title);
#endif


    clear();
    if(iscolor)
      showtitle( header, title );
    else
      titletmp( header, title );
    prints("���}[��,e] ���[��,��] �\\Ū[��,r] �o���峹[Ctrl-P] ��H[d]  ��ذ�[TAB] �D�U[h]\n" );
    standout();
    prints("�s��   %-12s  %6s %-50s \n", "�Z �n ��", "��  ��", " ��  �D") ;
    standend();
    clrtobot();
}


char *
readdoent(num,ent)
int	num;
struct fileheader *ent ;
{
 
    char	*mytag[2] = {"�� ", ""};
    char	*bcolortag[2]={"[1;33m@@","[1;32m�E"};
#ifdef NAPOLEON
    char	*atag[2]={"@----�u��",""};
#else
    char	*atag[2]={"@",""};
#endif
    static	char	buf[1024] ;
    time_t	filetime;
    char	*date;
    int		type;
    int         i=0;
    char	*related;
    char	temp[51];
    int		color;
    char	realowner[12];
    extern int	ANONYmode;
    
    type = brc_unread( ent->filename ) ? 'N' : ' ';
    if ( (ent->accessed[0] & FILE_MARKED) && HAS_PERM(PERM_MARKPOST) )
    {
       if (type == ' ') type = 'm';
        else type = 'M';
    }
    filetime = atoi( ent->filename + 2 );
    if( filetime > 740000000 ) {
	date = ctime( &filetime ) + 4;
    }
    else{ 
	date = "";
    }
    
    if( (ent->accessed[0] & FILE_ANONYMOUS) && ANONYmode )
       strcpy(realowner,"Anonymous");
    else
       strcpy(realowner,ent->owner);
    
    color= atoi(date+4)%2+35;
    temp[0]=EOS;
    related = (char *) ent->title;
    if (!strncmp(ent->title,"Re: ",4)) {
      related+=4;
      i=1;
    }
    strncpy(temp,ent->title,47);
    temp[48]='\0';
    if (*related!='\0' && !strncmp(related_title, related, 40))
         sprintf(buf," %4d %c %-12.12s [%2dm%6.6s[m%s%s%s%s", num, type,
	     	 realowner,color, date, bcolortag[i] ,mytag[i],temp,atag[i]);
    else  sprintf(buf," %4d %c %-12.12s [%2dm%6.6s[m  %s%-44s",num,type,
                 realowner,color, date, mytag[i],temp);
    return buf ;
}


char currfile[STRLEN] ;


int
cmpfilename(fhdr)
struct fileheader *fhdr ;
{
    if(!strncmp(fhdr->filename,currfile,STRLEN))
	return 1 ;
    return 0 ;
}



int
cpyfilename(fhdr)
struct fileheader *fhdr ;
{
    char	buf[ STRLEN ];

    sprintf( buf, "-%s", fhdr->owner );
    strncpy( fhdr->owner, buf, IDLEN );
    sprintf( buf, "<< article canceled by %s >>", currentuser.userid );
    strncpy( fhdr->title, buf, STRLEN );
    fhdr->filename[ STRLEN - 1 ] = 'L';
    fhdr->filename[ STRLEN - 2 ] = 'L';
    return 0;
}


	
int
read_post(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char *t ;
    char buf[1024];
    int  ch;
    char *related;

    clear() ;
    strcpy(buf,direct) ;
    if( (t = strrchr(buf,'/')) != NULL )
	*t = '\0' ;
    sprintf(genbuf,"%s/%s",buf,fileinfo->filename) ;
    strcpy( quote_file, genbuf );
    quote_file[255] = fileinfo->filename[STRLEN-2];
    strcpy( quote_user, fileinfo->owner );
    
    related = (char *) fileinfo->title;
    if (!strncmp(fileinfo->title,"Re: ",4))
      related+=4;
    strncpy(related_title, related, 40);
    related_title[40]='\0';

#ifndef NOREPLY
    ch = ansimore(genbuf,NA) ;
#else
    ch = ansimore(genbuf,YEA) ;
#endif
    brc_addlist( fileinfo->filename ) ;
#ifndef NOREPLY
    move(t_lines-1, 0);
    showansi=1;
    if (haspostperm(currboard)) {
	prints("[1;44;35m[�\\Ū�峹] [33m�^�H R�x�Ȧs�� S�x���� Q,���x�W�@�� ���x�U�@�� <Space>,<Enter>,�� [m");
    } else {
	prints("[1;44;35m[�\\Ū�峹] [33m���� Q,�� �x�W�@�� ���x�U�@�� <Space>,<Enter>,�� [m");
    }

    refresh();
    sleep(1);
    if (!( ch == KEY_RIGHT || ch == KEY_UP || ch == KEY_PGUP )) 
        ch = egetch();

    switch( ch ) {
	case 'N': case 'Q':
	case 'n': case 'q': case KEY_LEFT : case 'i' :
		break; 
	case ' ':
	case 'j': case KEY_RIGHT: case KEY_DOWN: case KEY_PGDN:
		return READ_NEXT;
	case KEY_UP: case KEY_PGUP: 
		return READ_PREV;
	case 'Y' : case 'R':
	case 'y' : case 'r': case 'f':
		do_reply(fileinfo->title);
		break;
	case Ctrl('R'):
		post_reply( ent, fileinfo, direct );
		break;
        case 'F':
                forward_post(ent,fileinfo,direct);
                break;
        case 'S': case 's':
           {
        	char	inbuf[2];
        	
        	getdata(t_lines-1,0,"���g�峹�g�J�ŶKï�ĴX��? (0-7) [�w�]�� 0]",inbuf,2,DOECHO);
	        if ( inbuf[0] == '\n' || inbuf[0] == '\r')  
	        	inbuf[0] = '0';
   		if ( inbuf[0] >= '0' && inbuf[0] <= '7')
        		save_intmp(fileinfo,direct,inbuf[0]);
 	        break;
            }
        case '\'':
        	sread(fileinfo);
        	break;
	default : break;
    }
#endif
    showansi=0;
    return FULLUPDATE ;
}



int
skip_post( ent, fileinfo, direct )
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    brc_addlist( fileinfo->filename ) ;
    return GOTO_NEXT;
}


int
save_intmp(fileinfo,direct,num)
struct	fileheader *fileinfo;
char	*direct;
char	num;
{
    char	xpath[STRLEN],fname[STRLEN];
    FILE	*xptr;
    

    sprintf( xpath, "/tmp/%s_clip_%c", currentuser.userid,num);
    if( (xptr = fopen( xpath , "w" )) != NULL ) {
	 setbfile(fname, currboard, fileinfo->filename);
         b_suckinfile(xptr, fname);
         fclose(xptr);
    }
    return 1;	
}

int
do_select( ent, fileinfo, direct )
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char bname[STRLEN], bpath[ STRLEN ];
    struct stat st ;
    int	pos;
    struct boardheader fh;

    move(0,0) ;
    clrtoeol();
    showansi=1;
    prints("��ܤ@�ӰQ�װ� (�^��r���j�p�g�ҥi) [1;36m����: �i������ enter Ū���ثe�Q�װ�[m\n") ;
    showansi=0;
    prints("��J�Q�װϦW (���ť���۰ʷj�M): ") ;
    clrtoeol() ;
	
    make_blist() ;    
    namecomplete((char *)NULL,bname) ;

    if(*bname == '\0') {
        Read();
    	return FULLUPDATE ;
    }	    
    pos = search_record(BOARDS, &fh, sizeof(fh), cmpbnames, bname);
    if (!pos) {
	move(2,0);
	prints("���~���Q�װϦW��");
	pressreturn();
	return FULLUPDATE;
    }
    setbpath( bpath, fh.filename );

    if ( stat(bpath,&st) == -1){
	move(2,0);
	prints("�����T���Q�װ�.\n");
	pressreturn();
	return FULLUPDATE ;
    }
    if(!(st.st_mode & S_IFDIR)) {
	move(2,0) ;
	prints("�����T���Q�װ�.\n") ;
	pressreturn() ;
	return FULLUPDATE ;
    }

    selboard = 1;
    brc_initial( fh.filename );

    move(0,0);
    clrtoeol();
    move(1,0);
    clrtoeol();
    setbdir( direct, currboard );
    Read();
    return NEWDIRECT ;
}




#ifndef NOREPLY
int
do_reply(title)
char *title;
{
    strcpy(replytitle, title);
    post_article();
    replytitle[0] = '\0';
    return FULLUPDATE;
}
#endif



int
garbage_line( str )
char *str;
{
    int qlevel = 0;

    while( *str == ':' || *str == '>' ) {
	str++;
	if( *str == ' ' )  str++;
	if( qlevel++ >= 1 )  return 1;
    }
    while( *str == ' ' || *str == '\t' )  str++;
    if( qlevel >= 1 )
	if( strstr( str, ") ����:\n" ) || strncmp( str, "==>", 3 ) == 0 )
	    return 1;
    return( *str == '\n' );
}



/* When there is an old article that can be included -jjyang */        
void
do_quote( filepath )
char	*filepath;
{
    FILE	*inf, *outf;
    char	*qfile, *quser;
    char	buf[256], *ptr;
    char	ans[4], op;
    int		bflag;
    int		n=0;

    qfile = quote_file;
    quser = quote_user;
    bflag = strncmp( qfile, "mail", 4 );
    outf = fopen( filepath, "w" );
    if( *qfile != '\0' && (inf = fopen( qfile, "r" )) != NULL ) {
	if( bflag ) ptr = "�ޥέ�峹�� (Y/N/All/Repost)? [Y]: ";
	else ptr = "�аݭn�ޥέ�H�ܡS (Y/N/All)? [Y]: ";
	getdata( t_lines-2, 0, ptr ,ans, 4, DOECHO, NULL );
	op = toupper( ans[0] );
	if( op != 'N' ) {
	    fgets( buf, 256, inf );
	    if( (ptr = strrchr( buf, ')' )) != NULL ) {
		ptr[1] = '\0';
		if( (ptr = strchr( buf, ':' )) != NULL ) {
		    quser = ptr + 1;
		    while( *quser == ' ' )  quser++;
		}
	    }

	    if( bflag ) fprintf( outf, "==> �b %s ���峹������:\n", quser );
	    else fprintf( outf, "==> �b %s ���ӫH������:\n", quser );

	    if( op == 'A' ) {
		while( fgets( buf, 256, inf ) != NULL )
		    fprintf( outf, "> %s", buf );
	    } else if( op == 'R' ) {
		while (fgets( buf, 256, inf ) != NULL)
		    if( buf[0] == '\n' )  break;
		while( fgets( buf, 256, inf ) != NULL )
		    fprintf( outf, "%s", buf );
	    } else {
		while (fgets( buf, 256, inf ) != NULL)
		    if( buf[0] == '\n' )  break;
		while (fgets( buf, 256, inf ) != NULL) {
		    if( strcmp( buf, "--\n" ) == 0 || strcmp( buf, ".\n")==0)
			break;
		    if( buf[ 76 ] != '\0' )
			strcpy( buf+76, "\n" );
		    if( !garbage_line( buf ) )
			fprintf( outf, "> %s", buf );
		}
	    }
	}
	fclose( inf ); 
    }
    *quote_file = '\0';
    *quote_user = '\0';

  if ( !(currentuser.address[STRLEN-1]=='Y') )     /* �ΦW���^���O�� */
    if( !(currentuser.flags[0] & SIG_FLAG) )
	addsignature(outf,1);
    fclose(outf);
}


int
do_post()
{
    *quote_file = '\0';
    *quote_user = '\0';
    return post_article();
}



/*ARGSUSED*/
int
post_reply(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char        uid[STRLEN] ;
    char        title[STRLEN] ;
    char        *t ;
    FILE	*fp;

    modify_user_mode( SMAIL );
    
   if(fileinfo->accessed[0]&FILE_ANONYMOUS)
   	return 0;
/* indicate the quote file/user */
    setbfile( quote_file, currboard, fileinfo->filename );
    strcpy( quote_user, fileinfo->owner );

/* find the author */
    if (strchr(quote_user, '.')) { 
        uid[ 0 ] = '\0';
        fp = fopen( quote_file, "r" );
        if (fp != NULL) {
             fgets( genbuf, 255, fp );
             fclose( fp ); 
              if( strtok( genbuf, " \t\n\r" ) != NULL )
                if( (t = strtok( NULL, " \t\n\r" )) != NULL )
                   strcpy( uid, t );
          }
       if( uid[0] == '\0' ) {
         move( t_lines-1, 0 );
         prints("Error: Cannot find Author ... \n");
         egetch();
         return FULLUPDATE ;
      }
    }
   else strcpy( uid, quote_user );
   
/* make the title */
    if (toupper(fileinfo->title[0]) != 'R' || fileinfo->title[1] != 'e' ||
        fileinfo->title[2] != ':') strcpy(title,"Re: ") ;
    else title[0] = '\0';
    strncat(title,fileinfo->title,STRLEN-5) ;

    clear();
    prints("�^�H����@��: %s\n", uid );
    prints("���D        : %s\n", title );

/* edit, then send the mail */
    switch (do_send(uid,title)) {
        case -1: prints("�t�εL�k�e�H\n"); break;
        case -2: prints("�e�H�ʧ@�w�g����\n"); break;
        case -3: prints("�ϥΪ� '%s' �L�k���H\n", uid); break;
        default: prints("�H��w���\\�a�H����@�� %s\n", uid);
    }
    pressreturn() ;
    return FULLUPDATE ;
}



int
post_article()
{
    struct fileheader postfile ;
    char	filepath[STRLEN], fname[STRLEN], *ip;
    char	ans[4], buf[256];
    int		fp, aborted;
    int		n;
    int		a=0;
    static char	*nickbrd;
    char	anonyans[2];

 
    if (!haspostperm(currboard)) 
    {
	move( 3, 0 );
	clrtobot();
   	prints("\n\n        ���Q�װϬO��Ū��, ����ܨ�L�Q�װ�.\n");
	pressreturn();
	clear();
	return FULLUPDATE;
    }

    memset(&postfile,0,sizeof(postfile)) ;
    clear() ;
    sprintf( buf, "vote/%s/notes", currboard );
    if( dashf( buf ) ) {
	a_more( buf, NA ,1,t_lines-5);
    } else if( dashf( "vote/notes" ) ) {
	a_more( "vote/notes", NA ,1,t_lines-5);
    }
    move( t_lines - 5, 0 );
    prints("�o���峹�� '%s' �Q�װ�\n\n",currboard) ;

#ifndef NOREPLY

      if( replytitle[0] != '\0' ) {
	if( ci_strncmp( replytitle, "Re:", 3 ) == 0 )
	    strcpy(buf, replytitle);
	else 
	    sprintf(buf,"Re: %s", replytitle);
	buf[50] = '\0';
	sprintf(replytitle, "�ϥμ��D: \"%s\" �� (Y/N)? [Y]: ", buf);
	getdata(t_lines-4,0, replytitle,ans, 4, DOECHO, NULL);
	if (!(ans[0] == 'N' || ans[0] == 'n'))
	    strcpy(postfile.title, buf);
	else 
	    getdata(t_lines-4,0,"���D: ",postfile.title,STRLEN,DOECHO,NULL) ;
    } else
#endif
    getdata(t_lines-4,0,"���D: ",postfile.title,STRLEN,DOECHO,NULL);
    strncpy(save_title,postfile.title,STRLEN) ;
    strncpy(save_filename,fname,4096) ;
    if( save_title[0] == '\0' ) {
	return FULLUPDATE;
    }

    nickbrd=(char *)sysconf_str("NICKBRDLIST");

#if defined(IS_ASK)
    if ( (int)chk_curr(nickbrd,currboard) ) {
      getdata (t_lines-3,0,"�O�_�ϥΰΦW [Y]:",anonyans,2,DOECHO,NULL);
      if (  anonyans[0] == 'n' || anonyans[0] == 'N')
             currentuser.address[STRLEN-1]='N';      /* �ΦW���^���O�� */
      else
      	     currentuser.address[STRLEN-1]='Y';
     }
#else
    if ( (int)chk_curr(nickbrd,currboard) ) 
      currentuser.address[STRLEN-1]='Y';    
#endif
    
    sprintf(fname,"M.%d.A",time(NULL)) ;
    setbfile( filepath, currboard, fname );
    ip = strrchr(fname,'A') ;
    while((fp = open(filepath,O_CREAT|O_EXCL|O_WRONLY,0644)) == -1) {
	if(*ip == 'Z')
  	    ip++,*ip = 'A', *(ip + 1) = '\0' ;
	else
	    (*ip)++ ;
	setbfile( filepath, currboard, fname );
    }
    close(fp) ;
    strcpy(postfile.filename,fname) ;

    in_mail = NA ;

    if ( currentuser.address[STRLEN-1]=='Y' )          /* �ΦW���^���O�� */
            postfile.accessed[0] |= FILE_ANONYMOUS;

    strncpy(postfile.owner,currentuser.userid,STRLEN);
    setbfile( filepath, currboard, postfile.filename );
   

    currentuser.address[STRLEN-3] = 0;            /* local_article �O�� */
    if ( !strcmp( postfile.title, buf ) && quote_file[0] != '\0' )
	if ( quote_file[255] == 'L' )
	    currentuser.address[STRLEN-3] = 1;      /* local_article �O�� */

    modify_user_mode( POSTING );

    do_quote( filepath );
    aborted = vedit(filepath,YEA) ;
    strncpy( postfile.title, save_title, STRLEN );
    if ( aborted == 1 ) /* local save */
    {
	postfile.filename[ STRLEN - 1 ] = 'L';
	postfile.filename[ STRLEN - 2 ] = 'L';
    }

    if (aborted  == -1) {
	unlink( filepath );
    	pressreturn() ;
        clear() ;
        return FULLUPDATE ;
    }
    setbdir( buf, currboard );
    if (append_record( buf, &postfile, sizeof(postfile)) == -1) {
	sprintf(buf, "posting '%s' on '%s': append_record failed!",
      		postfile.title, currboard);
	report(buf);
	pressreturn() ;
	clear() ;
	return FULLUPDATE ;
    }
    brc_addlist( postfile.filename ) ;

    sprintf(buf,"posted '%s' on '%s'", postfile.title, currboard) ;
    report(buf) ;
    if(!(postfile.filename[STRLEN-1]=='L'))
        outgo_post(&postfile, currboard);
    if ( !junkboard() ) {
        currentuser.numposts++;
	substitute_record(PASSFILE, &currentuser, sizeof(currentuser), usernum);
    }
    return FULLUPDATE ;
}



/*ARGSUSED*/
int
edit_post(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char	buf[512] ;
    char	*t ;
    int		owned ;
    FILE	*fp;
    extern char	fromhost[60];

    owned = ! strcmp( fileinfo->owner, currentuser.userid );
    if(!HAS_PERM(PERM_SYSOP) && !(owned))
      if ( (!HAS_PERM(PERM_BOARDS)) || !chk_curr(currBM,currentuser.userid) )
      {
        return DONOTHING ;
      }
    clear() ;
    strcpy(buf,direct) ;
    if( (t = strrchr(buf,'/')) != NULL )
	*t = '\0' ;
    sprintf(genbuf,"%s/%s",buf,fileinfo->filename) ;
    vedit(genbuf,NA) ;
    if((fp=fopen(genbuf,"a"))!=NULL){
      fprintf(fp,"�� Last modify by�i%s�jFrom: %s ��",currentuser.userid,fromhost);
      fclose(fp);    
    }
    sprintf(genbuf, "edited post '%s' on %s", fileinfo->title, currboard);
    report(genbuf);
    return FULLUPDATE ;
}



int
edit_title(ent,fileinfo,direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
    char	buf[ STRLEN ];
    int         owned;

     owned = ! strcmp( fileinfo->owner, currentuser.userid );
    if(!HAS_PERM(PERM_SYSOP) && !(owned))
        return DONOTHING ;
    getdata(t_lines-1,0,"�s�峹���D: ",buf,STRLEN,DOECHO,NULL) ;
    if( buf[0] != '\0' ) {
	strcpy(fileinfo->title,buf);
	substitute_record(direct, fileinfo, sizeof(*fileinfo), ent);
    }
    return PARTUPDATE;
}



int
mark_post(ent,fileinfo,direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
    if( !HAS_PERM(PERM_SYSOP) )
	if( (!HAS_PERM(PERM_BOARDS)) || !chk_curr(currBM,currentuser.userid) )
	{
	    return DONOTHING;
	}
    if (fileinfo->accessed[0] & FILE_MARKED)
	fileinfo->accessed[0] &= ~FILE_MARKED;
    else fileinfo->accessed[0] |= FILE_MARKED;
    substitute_record(direct, fileinfo, sizeof(*fileinfo), ent);
    return PARTUPDATE;
}



int
del_range(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char num1[10],num2[10] ;
    int inum1, inum2 ;
    
    if(uinfo.mode == READING && !HAS_PERM(PERM_SYSOP)) 
    if( !HAS_PERM(PERM_BOARDS) || !chk_curr(currBM,currentuser.userid)  ) {
        return DONOTHING ;
    }

    clear() ;
    prints("�ϰ�R��\n") ;
    getdata(1,0,"���g�峹�s��: ",num1,10,DOECHO,NULL) ;
    inum1 = atoi(num1) ;
    if(inum1 <= 0) {
        prints("���~�s��\n") ;
        pressreturn() ;
        return FULLUPDATE ;
    }
    getdata(2,0,"���g�峹�s��: ",num2,10,DOECHO,NULL) ;
    inum2 = atoi(num2) ;
    if(inum2 <= inum1) {
        prints("���~�s��\n") ;
        pressreturn() ;
        return FULLUPDATE ;
    }
    getdata(3,0,"�T�w�R�� (Y/N)? [N]: ",num1,10,DOECHO,NULL) ;
    if(*num1 == 'Y' || *num1 == 'y') {
        delete_range(direct,inum1,inum2) ; fixkeep(direct, inum1, inum2);
        sprintf(genbuf, "del %d-%d on %s", inum1, inum2, currboard);
        report(genbuf); prints("�R������\n") ; pressreturn() ; return
        DIRCHANGED ;
    }
    prints("Delete Aborted\n") ;
    pressreturn() ;
    return FULLUPDATE ;
}



int
del_post(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    FILE	*fn;
    char	buf[512];
    char	*t ;
    int		owned, keep, fail;

    keep = sysconf_eval( "KEEP_DELETED_HEADER" );
    if( fileinfo->owner[0] == '-' && keep > 0 ) {
	clear();
	prints( "���峹�w�R��.\n" );
	pressreturn();
	clear();
	return FULLUPDATE;
    }
    owned = ! strcmp( fileinfo->owner, currentuser.userid );
    if(( !(owned) && !HAS_PERM(PERM_SYSOP))||(fileinfo->accessed[0] & FILE_MARKED)) 
	if( (!HAS_PERM(PERM_BOARDS)) || !chk_curr(currBM,currentuser.userid) ||(fileinfo->accessed[0] & FILE_MARKED)) 
	{
	    return DONOTHING ;
	}
    clear() ;
    prints("�R���峹 '%s'",fileinfo->title) ;
    getdata(1,0,"(Y/N) [N]: ",genbuf,STRLEN,DOECHO,NULL) ;
    if(genbuf[0] != 'Y' && genbuf[0] != 'y') { /* if not yes quit */
	move(2,0) ;
	prints("����\n") ;
	pressreturn() ;
	clear() ;
	return FULLUPDATE ;
    }		
    if ( strcmp(fileinfo->owner,"dear")==0){
    prints("\n�a!!!! dear ���峹����!!!!!!!\n");
    pressreturn();
    clear();
    return FULLUPDATE;
    }    
    strcpy(buf,direct) ;
    if( (t = strrchr(buf,'/')) != NULL )
	*t = '\0' ;
    sprintf(genbuf,"Del '%s' on '%s'",fileinfo->title,currboard) ;
    report(genbuf) ;
    strncpy(currfile,fileinfo->filename,STRLEN) ;
    if( keep <= 0 ) {
	fail = delete_file(direct,sizeof(struct fileheader),ent,cmpfilename);
    } else {
	fail = update_file(direct,sizeof(struct fileheader),ent,cmpfilename,
			  cpyfilename);
    }
    if( !fail ) {
	cancelpost( currboard, currentuser.userid, fileinfo, owned );
	sprintf(genbuf,"%s/%s",buf,fileinfo->filename) ;
	if( keep <= 0 ) {
	    unlink(genbuf) ;
	} else if( (fn = fopen( genbuf, "w" )) != NULL ) {
	    fprintf( fn, "\n\n\t\t���峹�w�Q %s �R��.\n",
			currentuser.userid );
	    fclose( fn );
	}
	if (owned) {
	    if (currentuser.numposts > 0) currentuser.numposts--;
	    substitute_record( PASSFILE, &currentuser,
				sizeof(currentuser), usernum);		
	}
	return DIRCHANGED;
    }
    move(2,0) ;
    prints("�R������\n") ;
    pressreturn() ;
    clear() ;
    return FULLUPDATE ;
}



static int sequent_ent ;



int
sequent_messages(fptr)
struct fileheader *fptr ;
{
    static int idc;

    if(fptr == NULL) {
	idc = 0 ;
	return 0 ;
    }
    idc++ ;
    if(idc < sequent_ent)
	return 0;
    if( !brc_unread( fptr->filename ) )  return 0;

    if (continue_flag != 0) {
	genbuf[ 0 ] = 'y';
    } else {
	prints("�Q�װ�: '%s' ���D:\n\"%s\" posted by %s.\n",
		 currboard,fptr->title,fptr->owner) ;
	getdata(3,0,"Ū�� (Y/N/Quit) [Y]: ",genbuf,5,DOECHO,NULL) ;
    }

    if(genbuf[0] != 'y' && genbuf[0] != 'Y' && genbuf[0] != '\0') {
	if(genbuf[0] == 'q' || genbuf[0] == 'Q') {
	    clear() ;
	    return QUIT ;
	}
	clear() ;
	return 0;
    }
    setbfile( genbuf, currboard, fptr->filename );
    strcpy( quote_file, genbuf );
    strcpy( quote_user, fptr->owner );
#ifdef NOREPLY
    more(genbuf,YEA);
#else
    more(genbuf,NA) ;
    move(t_lines-1, 0); 
    prints("[�s��Ū�H] �^�H R �x ���� Q,�� �x�U�@�� ' ',�� ");
    continue_flag = 0;
    switch( egetch() ) {
	case 'N': case 'Q':
	case 'n': case 'q':
	case 'i': case KEY_LEFT: 
	    break;
	case 'Y' : case 'R':
	case 'y' : case 'r':
	    do_reply(fptr->title);
	case ' ': case '\n':
	case KEY_DOWN:
	    continue_flag = 1; break;
        case Ctrl('R'):
            /* post_reply uses only ftpr as argument! */
	    post_reply( 0, fptr, (char *)NULL );
	    break;
	default : break;
    }
#endif
    clear() ;
    setbdir( genbuf, currboard );
    brc_addlist( fptr->filename ) ;
    return 0;
}



/*ARGSUSED*/
int
sequential_read(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char	buf[ STRLEN ];

    clear() ;
    sequent_messages((struct fileheader *)NULL) ;
    sequent_ent = ent ;
    continue_flag = 0;
    setbdir( buf, currboard );
    apply_record( buf,sequent_messages,sizeof(struct fileheader)) ;
    return FULLUPDATE ;
}



/*add by tby to port the file to another board*/
int
changefnbrd(ent, fileinfo,direct )
int	ent ;
struct	fileheader *fileinfo ;
char	*direct ;
{
  char		xboard[20], fname[80], xfpath[80];
  struct	fileheader xfile;
  FILE		*xptr;
  time_t	now;
  int		pos;
  struct boardheader fh;
  
  if(!HAS_PERM(PERM_BOARDS))
       return;
  now=time(NULL);
  move(1, 0);
  clrtoeol();
  make_blist();    
  namecomplete("��K���峹��ݪO�G", xboard);

  pos = search_record(BOARDS, &fh, sizeof(fh), cmpbnames, xboard);
  if (!pos) {
	move(2,0);
	prints("���~���Q�װϦW��");
	pressreturn();
	clear();
	return FULLUPDATE;
    }  
  if (*xboard == '\0' || !haspostperm(fh.filename))
    return FULLUPDATE;
  sprintf(xfpath, "��K�i%.40s�j[S]ave (L)ocal (Q)uit ? ", fileinfo->title);
  getdata(1, 0, xfpath, genbuf, 3, DOECHO);
  if (genbuf[0] == 'q' || genbuf[0] == 'Q')
    return FULLUPDATE;

  sprintf(xfile.filename,"M.%d.A",time(NULL));
  sprintf(xfpath,"boards/%s/%s",fh.filename,xfile.filename);
  strcpy(xfile.owner, currentuser.userid);
/*  if(strstr(fileinfo->title,"[��K]"))*/
    sprintf(xfile.title,"%.60s",fileinfo->title);
/*  else sprintf(xfile.title, "[��K]%.60s", fileinfo->title);*/
  if (genbuf[0] == 'l' || genbuf[0] == 'L') {
	xfile.filename[ STRLEN - 1 ] = 'L';
	xfile.filename[ STRLEN - 2 ] = 'L';

  }
  if (xptr = fopen(xfpath, "w"))  {

    fprintf(xptr,"Posted By: %s (%s) on board '%s'\n",currentuser.userid,currentuser.username,fh.filename) ;
    fprintf(xptr,"Title:     %s\n",xfile.title) ;
    fprintf(xptr,"Date:      %s\n",ctime(&now)) ;
    fprintf(xptr, "\n [������K�� %s �Q�װ�]\n\n", currboard);

    setbfile(fname, currboard, fileinfo->filename);
    b_suckinfile(xptr, fname);
    addsignature(xptr);
    fclose(xptr);

    xfile.accessed[0] &= ~(FILE_MARKED | FILE_ANONYMOUS);
    setbdir(fname, fh.filename);
    append_record(fname, (char *) &xfile, sizeof(xfile));
    if(xfile.filename[ STRLEN - 1 ] != 'L')
         outgo_post(&xfile, fh.filename);
    outs("�峹��K����");
    pressanykey();
  }
  return FULLUPDATE;
}
 


#ifdef INTERNET_EMAIL
int
forward_post(ent,fileinfo,direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
    if( strcmp( "guest", currentuser.userid) == 0 )
	return DONOTHING;
    return(mail_forward(ent, fileinfo, direct));
}



int
forward_u_post(ent,fileinfo,direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
    if( strcmp( "guest", currentuser.userid) == 0 )
	return DONOTHING;
    return(mail_uforward(ent, fileinfo, direct));
}

#endif



int
mainreadhelp()
{
   ansimore("etc/mainreadhelp",YEA);
   clear() ;
   return FULLUPDATE ;
}


extern int b_vote();
extern int b_results();
extern int b_vote_maintain();
extern int b_notes_edit();
extern int b_v_override();

struct one_key  read_comms[] = {
    'r',	read_post,
    'K',        skip_post,
    'd',	del_post,
    'D',	del_range,
    'm',	mark_post,
    'E',	edit_post,
    'T',	edit_title,
    's',	do_select,
    Ctrl('P'),	do_post,
    'S',	sequential_read,
#ifdef INTERNET_EMAIL
    'F',	forward_post,
    'U',	forward_u_post,
    Ctrl('R'),	post_reply,
#endif
    'R',	b_results,
    'V',	b_vote,
    'M',	b_vote_maintain,
    'O',	b_v_override,    
    'W',	b_notes_edit,
    'h',	mainreadhelp,
    Ctrl('J'),	mainreadhelp,
    'b',	changefnbrd,
    '\0',	NULL
  } ;


int
Read()
{
    char	buf[ STRLEN*2 ];
    char        tby[10];
    int         a=0;    

    if(!selboard) {
	move(2,0) ;
	prints("�Х���ܰQ�װ�\n") ;
	pressreturn() ;
	move(2,0) ;
	clrtoeol() ;
	return -1 ;
    }
    in_mail = NA;
    brc_initial( currboard );
    setbdir( buf, currboard );
    i_read( READING, buf,readtitle,readdoent,&read_comms[0]) ;
    brc_update();
    return 0 ;
}

int
Goodbye()
{
    int		sec,min,hour,a;    
    extern int	started ;
    time_t	stay;
    int		timetmp;
    char	filepath[30];
    
    
   
    modify_user_mode(BYE);
    move(2,0);
    clrtoeol();
    getdata(1,0, "�A�T�w�n���}��? (Yes/No) [N]: ",
			genbuf, 2, DOECHO, NULL );
    if ( *genbuf != 'y' && *genbuf != 'Y' ) {
	clear();
	return 0;
    }
     

    if (HAS_PERM(PERM_POST)) 
      if(!note()) 
          return 0;
      else 
          clear();
    
    sprintf(filepath, "home/%s/msgfile.all",currentuser.userid);
    if(dashf(filepath)) {
    	ansimore(filepath,NA);
        getdata(t_lines-1,0,"�H�W�O�z�o���W���Ҧ������T��, �O�_�s�J�z���H�c? (Yes/No) [N]: ",
			     genbuf, 2, DOECHO, NULL);
	if( genbuf[0] == 'y' || genbuf[0] == 'Y' ){
	      time_t	date;
	      char	*msgbuf;
	      
	      date = time(0);
	      msgbuf = ctime( &date ) + 4;
	      sprintf(msgbuf,"%6.6s �T���O����",msgbuf);
              mail_file(filepath, currentuser.userid, msgbuf);
        }
        unlink(filepath);
        clear();
    }
    
    prints("�˷R�� %s (%s)�A�O�ѤF�A�ץ��{ ", 
	currentuser.userid, currentuser.username);
    standout();
    prints("%s", BoardName);
    standend();
    prints(" �A�A�|��!\n\n");
    
    prints("�H�U�O�z�b���������U���:%d\n\n",login_start_time);
    user_display ( &currentuser,0);
    showansi=1;

    hour = ( ( time ( NULL )- login_start_time ) /3600 );
    min =  ( ( ( time ( NULL ) - login_start_time ) % 3600 ) /60 );
    sec = ( ( ( time ( NULL ) - login_start_time ) % 3600 ) %60) ;    

    report("exit") ;
    sleep(1); 
    stay = time(NULL) - login_start_time; 
    if(started) {
	sprintf( genbuf, "Stay:%3ld (%s)", stay / 60, currentuser.username );
	log_usies( "EXIT ", genbuf );
	u_exit() ;
    }

    showansi=0;
    pressreturn();
    sleep(1);
    reset_tty() ;
    exit(0) ;
    return -1;
}

  

void
report(s)
char *s ;
{
    static int disable = NA ;
    int fd ;

    if(disable)
	return ;
    if((fd = open("var/trace",O_WRONLY,0644)) != -1 ) {
	char buf[512] ;
	char timestr[10], *thetime;
	time_t dtime;
	time(&dtime);
	thetime = ctime(&dtime);
	strncpy(timestr, &(thetime[11]), 8);
	timestr[8] = '\0';
	flock(fd,LOCK_EX) ;
	lseek(fd,0,SEEK_END) ;
	sprintf(buf,"%s %s %s\n",currentuser.userid, timestr, s) ;
	write(fd,buf,strlen(buf)) ;
	flock(fd,LOCK_UN) ;
	close(fd) ;
	return ;
    }
    disable = YEA ;
    return ;
}


int
Info()
{
    ansimore("Version.Info",YEA) ;
    clear() ;
    return 0 ;
}


int
Conditions()
{
    ansimore("COPYING",YEA) ;
    clear() ;
    return 0 ;
}



int
Welcome()
{
  int    wan,rnum;
   char   mybuf[1024],gnum[10];  
     
     wan =  currentuser.numlogins-1;     
       modify_user_mode(WELCOME);   
       ansimore( "etc/Welcome", NA );
       pressreturn();
       clear() ;
     return 0 ;
}



int
EditWelcome()
{
    int aborted;
    char ans[7];
    move(3,0);
    clrtoeol();
    clrtobot();
    getdata(3,0,"(E)�s�� or (D)�R�� Welcome? [E]: ",ans,7,DOECHO,NULL);
    if (ans[0] == 'D' || ans[0] == 'd') {
	unlink("etc/Welcome");
	move(5,0);
	prints("�w�R��!\n");
	pressreturn();
	clear();
	report( "del welcome" ) ;
	return 0;
    }
    modify_user_mode( EDITWELC );
    aborted = vedit("etc/Welcome", NA);		
    clear() ;
    if (aborted)
	prints("�����s��.\n");
    else {
	report("edit Welcome") ;
	prints("�ק粒��.\n") ;
    }
    pressreturn() ;
    return 0 ;
}



int
cmpbnames( bname, brec)
char *bname;
struct fileheader *brec;
{
    if (!ci_strncmp( bname, brec->filename, sizeof(brec->filename)))
	return 1;
    else
	return 0;
}


void
outgo_post(fh, board)
struct fileheader *fh;
char		*board;
{
  FILE	*foo;
  char	owner[12];

  if (foo = fopen("innd/out.bntp", "a")) {
    if( fh->accessed[0] & FILE_ANONYMOUS )
      strcpy(owner,"Anonymous");
    else
      strcpy(owner,fh->owner);
    fprintf(foo,"%s\t%s\t%s\t%s\n", board,fh->filename, owner, fh->title);
    fclose(foo);
  }
}


void
cancelpost( board, userid, fh, owned )
char	*board, *userid;
struct fileheader *fh;
int	owned;
{
    struct fileheader	postfile;
    FILE	*fin, *fout, *chkout, *chkin;
    char	from[ STRLEN ], path[ STRLEN ];
    char	fname[ STRLEN ], *ptr, *brd;
    int		len, chk=0;
    char	result[512];

    setbfile( genbuf, board, fh->filename );
    if( (fin = fopen( genbuf, "r" )) != NULL ) {
	brd = owned ? "junk" : "deleted";
	sprintf( fname, "M.%d.A", time(NULL) );
	setbfile( genbuf, brd, fname );
	if( (fout = fopen( genbuf, "w" )) != NULL ) {
	    memset(&postfile,0,sizeof(postfile)) ;
	    sprintf( genbuf, "%-35.35s - %s", fh->title, userid );
	    strcpy( postfile.filename, fname );
	    strncpy( postfile.owner, fh->owner, IDLEN );
	    strncpy( postfile.title, genbuf, STRLEN );
	    postfile.filename[ STRLEN - 1 ] = 'D';
	    postfile.filename[ STRLEN - 2 ] = 'D';
	}
	while( fgets( genbuf, sizeof( genbuf ), fin ) != NULL ) {
	    if( fout != NULL ) {
		fputs( genbuf, fout );
	    }
	    len = strlen( genbuf ) - 1;
	    genbuf[ len ] = '\0';
	    if( len <= 8 ) {
		break;
	    } else if( strncmp( genbuf, "�o�H�H: ", 8 ) == 0 ) {
		if( (ptr = strrchr( genbuf, ',' )) != NULL )
		    *ptr = '\0';
		strcpy( from, genbuf + 8 );
	    } else if( strncmp( genbuf, "��H��: ", 8 ) == 0 ) {
		strcpy( path, genbuf + 8 );
	    }
	}
	if( fout != NULL ) {
	    while( fgets( genbuf, sizeof( genbuf ), fin ) != NULL )
		fputs( genbuf, fout );
	}
	fclose( fin );
	if( fout != NULL ) {
	    fclose( fout );
	    setbdir( genbuf, brd );
	    append_record( genbuf, &postfile, sizeof(postfile) );
	}
	if( (chkin=fopen("innd/out.bntp","r+")) != NULL){
	  if( (chkout=fopen("tmp/tmp.bntp","w"))!=NULL){
     	     while( fgets(result, sizeof result, chkin) != NULL ) {
  	        if(strstr(result,fh->filename) == NULL)
     	           fputs(result,chkout);
     	        else     chk=1;
  	     }
  	     fclose(chkout);
  	   }
  	   fclose(chkin);             	   
           if((chkin=fopen("innd/out.bntp","w"))!=NULL){
                b_suckinfile(chkin,"tmp/tmp.bntp");
                fclose(chkin);
            }
           unlink("tmp/tmp.bntp");

  	 }
        
  	if(chk==1)
  	    return;
        else { 	  
	     sprintf( genbuf, "%s\t%s\t%s\t%s\t%s\n",
		   board, fh->filename, userid, from, path );
	     if( (fin = fopen( "cancelpost.lst", "a" )) != NULL ) {
	          fputs( genbuf, fin );
     	          fclose( fin );
	     }
        }
    }
}


note()
{
     char	ans[2];

       getdata(2,0,"(1)�g�d���� (2)�d�ܵ����� (3)��ꤣ�Q�� (4)���O? [4]: ",
		ans, 2, DOECHO, NULL);
       switch(ans[0]) {
        case '1': 
           add_note();
           break;          
        case '2':
           sysop_list();
           break;
        case '3':
           return 0;
           break;
        default: 
           return 1;
       }
       return 1;
}




sysop_list()
{
   FILE		*fp;
   struct	SYSOPLIST	Sysop[10];   
   int		total=0,i,j=1;
   char		buf[200];
   char		ans[2],*p;
   
	if ((fp=fopen("etc/SYSOP","r")) == NULL) {
	   return 0;
	} 
	j=0;
	while (fgets(buf,120,fp) != (char) NULL) {
	 if (buf[0]=='#' || buf[0]=='\n' || strlen(buf) < 10)
           continue;
	 i=strlen(buf); buf[i-1]='\0';
         p=(char *) strtok(buf," \t\n");
	 strcpy(Sysop[j].userid,p);
	 i=strlen(Sysop[j].userid)+1;
	 while (buf[i] == ' ' || buf[i] =='\t')
	    i++;
	 strcpy(Sysop[j].notes,buf+i); 
	 j++;
        }
        move(12,0); clrtobot(); refresh();
        prints("                   -----===== �����C�� =====-----");
        prints("\n �s��   %-20s %-36s\n","�����N��", "�t�d����");  
	for (i=0; i<j; i++) {
	 prints("   [1;%dm%2d.  %-20s %-50s[0m\n"
           ,31+i%6,i+1, Sysop[i].userid, Sysop[i].notes);
	}
        prints("   [1;%dm%2d.  ���}[37;40;0m\n",31+j%6,j+1);
	getdata(t_lines-2,0,"�z�n�H���֩O ? ", ans, 2, DOECHO, NULL);
	if (ans[0]-'0' > 0 && ans[0]-'0' <= j) {
	  i=ans[0]-'0'-1;
	  clear();
	  do_send(Sysop[i].userid, NULL);
	}
	return 0;
}




add_note()
{
	struct	notedata	olditem[41], newitem[41];
	struct	tm		*postdate;
	int	total=0,i,j=1;
	struct	stat	st;
	char	buf[200], ans[2], temp[3];
	char	*week;
	int	fd;
	FILE	*fp;


        week=(char *) "��@�G�T�|����";
retry:
	newitem[0].buf[0][0]=newitem[0].buf[1][0]=newitem[0].buf[2][0]=EOS;
	move(12,0); clrtobot();
	prints("�Яd��, �� Enter ���� (�ܦh�T��)");
	for (i=0; i<3; i++) {
	  getdata(13+i,0," : ",newitem[0].buf[i], 76, DOECHO, NULL);
	  if (newitem[0].buf[i][0]==EOS) break;
	}
	getdata(t_lines-2,0,"(S)�x�s (E)���s�ӹL (A)��� ? [S] : ", 
		ans, 2, DOECHO, NULL);
	if (ans[0]=='E' || ans[0]=='e')
	 goto retry;
	if (ans[0]=='A' || ans[0]=='a' || (newitem[0].buf[0][0]==EOS))
	 return 0;

	strncpy(newitem[0].userid,currentuser.userid,12);
	strncpy(newitem[0].username,currentuser.username,29);
	newitem[0].userid[12]=EOS;
	newitem[0].username[30]=EOS;
	time(&(newitem[0].date));

/* begin load file */

	if((fd = open("var/note.dat",O_RDONLY)) == -1) {
          total=0;
        }
	if(stat("var/note.dat",&st) != -1)
	  total=st.st_size/sizeof(struct notedata) ;

	if (total>40) total=40;
         
        for (i=0; i<total; i++) {
		read(fd,(char *) &olditem[i],sizeof(olditem[i]));
		if (olditem[i].date > newitem[0].date - 72*60*60){ /*  ����d���ɶ� */
		    strcpy(newitem[j].userid, olditem[i].userid);
		    strcpy(newitem[j].username, olditem[i].username);
		    strcpy(newitem[j].buf[0], olditem[i].buf[0]);
		    strcpy(newitem[j].buf[1], olditem[i].buf[1]);
		    strcpy(newitem[j].buf[2], olditem[i].buf[2]);
		    newitem[j].date=olditem[i].date;
                    j++;
		}
	}
	close(fd);
      
	if((fd = open("var/note.dat",O_WRONLY|O_CREAT)) == 0) {
	     printf("Can't open the note.dat! Aborting...\n");
             return(0);
	}
	if((fp = fopen("0Announce/note.ans","w")) == NULL) {
	     printf("Can't open the note.ans! Aborting...\n");
             return(0);
	}
     sprintf(buf,"                    [1;44m         [%s]   �d �� �O   [m\n\n",BoardName);
     fputs(buf,fp);
     for (i=0; i<j; i++) {
	int k;
        write(fd, &(newitem[i]), sizeof(newitem[i]));
        sprintf(buf,"[1;31m�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w[m\n");
        fputs(buf,fp);
	postdate=localtime(&(newitem[i].date));
	strncpy(temp,(week+postdate->tm_wday*2),2); temp[2]=EOS;
	sprintf(buf," [1;35m�� [32m%s [36m(%s)    [33m�� [36m %2.2d-%2.2d-%4d �P��%2s %2.2d:%2.2d[33m ���d��[m\n",
       	  		newitem[i].userid, newitem[i].username ,
	  		postdate->tm_mon+1, postdate->tm_mday, postdate->tm_year+1900,
	  		temp, postdate->tm_hour, postdate->tm_min);
	fputs(buf,fp);
	for (k=0; k<3; k++) {
	    sprintf(buf,"[1m %s\n", newitem[i].buf[k]);
            fputs(buf,fp);
	}
     }
     sprintf(buf,"[1;31m�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w[m\n");
     fputs(buf,fp);
     fclose(fp);


     if((fp = fopen("var/note.ans","w")) == NULL) {
       	  printf("Can't open the note.ans! Aborting...\n");
       	  return(0);
     }
     sprintf(buf,"                    [1;44m         [%s]   �d �� �O   [m\n\n",BoardName);
     fputs(buf,fp);
     if(j>9)j=9;
     for (i=0; i<j; i++) {
	int k;
        sprintf(buf,"[1;31m�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w[m\n");
        fputs(buf,fp);
	postdate=localtime(&(newitem[i].date));
	strncpy(temp,(week+postdate->tm_wday*2),2); temp[2]=EOS;
	sprintf(buf," [1;35m�� [32m%s [36m(%s)    [33m�� [36m %2.2d-%2.2d-%4d �P��%2s %2.2d:%2.2d[33m ���d��[m\n",
       	  		newitem[i].userid, newitem[i].username ,
	  		postdate->tm_mon+1, postdate->tm_mday, postdate->tm_year+1900,
	  		temp, postdate->tm_hour, postdate->tm_min);
	fputs(buf,fp);
	for (k=0; k<3; k++) {
	    sprintf(buf,"[1m %s\n", newitem[i].buf[k]);
            fputs(buf,fp);
	}
     }
     sprintf(buf,"[1;31m�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w[m\n");
     fputs(buf,fp);
     fclose(fp);	
     close(fd);
}



int
chk_curr(frontbuf,stdbuf)
char	*frontbuf;
char	*stdbuf;
{
  int ch, len;

  ch = frontbuf[0];
  if ((ch > ' ') && (ch < 128)){
    len = strlen(stdbuf);
    do{
      if (!ci_strncmp(frontbuf, stdbuf, len)) {
 	  ch = frontbuf[len];
	  if ((ch == 0) || (ch == ',') || (ch == ']'))
	     return 1;
      }
      while (ch = *frontbuf++) {
	if (ch == ',')
	  break;
      }
    } while (ch);
  }
  return 0;
}


void
Help()
{
    currentuser.flags[0] ^= CURSOR_FLAG;
}

