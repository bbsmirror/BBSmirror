/*
 *	maintain.c
 */



#include "bbs.h"



void
stand_title( title )
char	*title;
{
    clear();
    standout();
    prints( title );
    standend();
}

int
m_info(userid)
char	userid[];
{
    struct userec m_uinfo ;
    int id;
  

   if(uinfo.mode!=LUSERS&&uinfo.mode!=LAUSERS&&uinfo.mode!=FRIEND)
   {
    move(1,0) ;
    clrtoeol() ;
    modify_user_mode(ADMIN);
    stand_title("�ק�ϥΪ̥N��") ;
    move(1,0) ;
    usercomplete("�п�J�ϥΪ̥N��: ", genbuf) ;
    if(genbuf[0] == '\0') {
        clear() ;
        return 0 ;
     }
    }else{
     strcpy(genbuf,userid);	
     modify_user_mode(ADMIN);
     }
    if(*genbuf == '\0') {
        clear() ;
        return -1;
    }

    if(!(id = getuser(genbuf))) {
        move(3,0) ;
        prints("���~���ϥΪ̥N��") ;
        clrtoeol() ;
        pressreturn() ;
        clear() ;
        return -1;
    }
    memcpy( &m_uinfo, &lookupuser, sizeof(m_uinfo)) ;
    user_display( &m_uinfo, 1 );
    uinfo_query( &m_uinfo, 1, id );
    return 0;
}

extern int cmpbnames();
extern int numboards;

int
valid_brdname( brd )
char	*brd;
{
    char	ch;

    ch = *brd++;
    if( !isalpha( ch ) && ch != '_' )
	return 0;
    while( (ch = *brd++) != '\0' ) {
	if( !isalpha(ch) && ch != '_' && ch != '.' )
	    return 0;
    }
    return 1;
}

int
m_newbrd()
{
    struct boardheader newboard ;
    extern int	numboards ;
    char	ans[4];
    char	vbuf[100];
    int		bid;

    clear() ;
    modify_user_mode( ADMIN );
    memset(&newboard, 0, sizeof(newboard));
    prints( "�}�ҷs�Q�װ�:" );
    while( 1 ) {
	getdata( 3, 0, "�Q�װϦW��:   ", newboard.filename,18,DOECHO,NULL);
	if( newboard.filename[0] == '\0' )
	    return -1;
	if( valid_brdname( newboard.filename ) )
	    break;
	prints( "���X�k�W��..." );
    }
    getdata(4,0,"�Q�װϻ���:   ",newboard.title,60,DOECHO,NULL) ;
    strcpy(vbuf, "vote/");
    strcat(vbuf, newboard.filename);
    setbpath( genbuf, newboard.filename );
    if( getbnum(newboard.filename) > 0 || mkdir(genbuf,0755) == -1
	 || mkdir(vbuf, 0755) == -1 ) {
	prints("\nError: Bad Board Name\n");
	pressreturn();
	clear();
	return -1;
    }

    getdata(5,0,"�Q�װϺ޲z��: ", newboard.BM, BM_LEN, DOECHO,NULL) ;
    getdata(6,0,"�O�_����s���v�O (Y/N)? [N]: ", ans,4,DOECHO,NULL);	
    if (*ans == 'y' || *ans == 'Y') {
	getdata(6,0,"���� Read/Post [R]: ",ans,4,DOECHO, NULL);		
	if (*ans == 'P' || *ans == 'p' ) 
	     newboard.level = PERM_POSTMASK;
	else
	     newboard.level = 0;
	move(1,0);
	clrtobot();
	move(2,0);
	prints( "�]�w %s �v�O. �Q�װ�: '%s'\n",
		(newboard.level & PERM_POSTMASK ? "POST" : "READ"),
		newboard.filename);
	newboard.level = setperms(newboard.level);
	clear();
    } else newboard.level = 0;	
    if( (bid = getbnum( "" )) > 0 ) {
	substitute_record( BOARDS, &newboard, sizeof( newboard ), bid );
    } else if( append_record(BOARDS,&newboard,sizeof(newboard)) == -1 ) {
	pressreturn() ;
	clear() ;
	return -1 ;
    }
    numboards = -1 ;
    prints("\n�s�Q�װϦ���\n") ;
    sprintf(genbuf, "add brd %s", newboard.filename);
    report(genbuf);
    pressreturn() ;
    clear()  ;
    return 0 ;
}

int
m_editbrd()
{
    char bname[STRLEN];
    int pos;
    struct boardheader fh, newfh;

    modify_user_mode(ADMIN);
    make_blist();    
    namecomplete("��J�Q�װϦW��: ", bname);
    stand_title("�ק�Q�װϸ�T");
    move(1,0);

    if (*bname == '\0') {
	move(2,0);
	prints("���~���Q�װϦW��");
	pressreturn();
	clear();
	return -1;
    }
    pos = search_record(BOARDS, &fh, sizeof(fh), cmpbnames, bname);
    if (!pos) {
	move(2,0);
	prints("���~���Q�װϦW��");
	pressreturn();
	clear();
	return -1;
    }
    move(3,0);
    memcpy( &newfh, &fh, sizeof(newfh));
    prints("�Q�װϦW��:   %s\n", fh.filename);
    prints("�Q�װϻ���:   %s\n", fh.title);
    prints("�Q�װϺ޲z��: %s\n", fh.BM);

    prints("���� %s �v�O: %s", (fh.level & PERM_POSTMASK) ? "POST" : "READ",
	    (fh.level & ~PERM_POSTMASK) == 0 ? "���]��" : "���]��" );
    getdata(7,0, "�O�_���H�W��T? (Yes or No) [N]: ", genbuf,4,DOECHO,NULL);
    if (*genbuf == 'y' || *genbuf == 'Y') {
	move(8,0);
	prints("������ <Return> ���ק惡���T\n");
enterbname:
	getdata(9,0, "�s�Q�װϦW��: ", genbuf, 18, DOECHO, NULL);
	if (*genbuf != 0) {
	    struct boardheader dh;
	    if (search_record(BOARDS,&dh,sizeof(dh),cmpbnames,genbuf)){
		move(3,0);
		prints("���~! ���Q�װϤw�g�s�b\n");
		move(10,0);
		clrtobot();
		goto enterbname;
	    }
	    strncpy(newfh.filename, genbuf, sizeof(newfh.filename));
	}
	getdata(10,0, "�s�Q�װϻ���: ", genbuf, 60, DOECHO, NULL);
	if (*genbuf != 0)
	    strncpy(newfh.title, genbuf, sizeof(newfh.title));
	getdata(11,0, "�Q�װϺ޲z��: ", genbuf, 60, DOECHO, NULL);
	if (*genbuf != 0)
	    strncpy(newfh.BM, genbuf, sizeof(newfh.BM));

	getdata(12,0, "�O�_���s���v�� (Y/N)? [N]: ", genbuf,4,DOECHO, NULL);
	if (*genbuf == 'Y' || *genbuf == 'y') {
	    char ans[4];
	    sprintf(genbuf, "���� (R)�\\Ū �� (P)�i�K �峹 [%c]: ",
		(newfh.level & PERM_POSTMASK ? 'P' : 'R'));
	    getdata(13,0, genbuf, ans, 4, DOECHO, NULL);
	    if ((newfh.level & PERM_POSTMASK) && (*ans=='R' || *ans=='r'))
		newfh.level &= ~PERM_POSTMASK;
	    else if (!(newfh.level & PERM_POSTMASK) && (*ans=='P'||*ans=='p'))
		newfh.level |= PERM_POSTMASK;
	    move(1,0);
	    clrtobot();
	    move(2,0);
	    prints("�]�w %s '%s' �Q�װϪ��v��\n",
		newfh.level & PERM_POSTMASK ? "�i�K" : "�\\Ū", newfh.filename);
	    newfh.level = setperms(newfh.level);
	    clear();
	    getdata(0,0, "�T�w�n����? (Y/N) [N]: ",genbuf,4,DOECHO,NULL);
	} else {
	    getdata(13,0,"�T�w�n����? (Y/N) [N]: ",genbuf,4,DOECHO,NULL);
	}
	if (*genbuf == 'Y' || *genbuf == 'y') {
	    if (strcmp(fh.filename, newfh.filename)) {
		char old[256], tar[256];

		setbpath( old, fh.filename );
		setbpath( tar, newfh.filename );
		rename(old, tar);
		sprintf(old, "vote/%s", fh.filename);
		sprintf(tar, "vote/%s", newfh.filename);
		rename(old, tar);
	    }
	    substitute_record(BOARDS, &newfh, sizeof(newfh), pos);
	    sprintf(genbuf, "���Q�װ� %s ����� --> %s",
			fh.filename, newfh.filename);
	    report(genbuf);
	    numboards = -1;    /* force re-caching */
	}
    }
    clear();
    return 0;
}

int
post_in_tin(username)
char *username;
{
    char buf[ 256 ];
    FILE *fh;
    int  counter = 0;

    sethomefile( buf, username, ".tin/posted" );
    fh = fopen(buf, "r");
    if (fh == NULL) return 0;
    else {
        while ( fgets(buf, 255, fh) != NULL ) 
        {
            if ( buf[9] != 'd' && strncmp( &buf[11], "csie.bbs.test", 13 ) )
        	counter++;
	    if ( buf[9] == 'd' )
	    	counter--;
        }
        fclose( fh );
        return counter;
    }

}

FILE *cleanlog;
char curruser[IDLEN+2];
extern int delmsgs[];
extern int delcnt;

void
domailclean(fhdrp)
struct fileheader *fhdrp;
{
    static int newcnt, savecnt, deleted, idc;
    char buf[STRLEN];

    if (fhdrp == NULL) {
	fprintf(cleanlog, "new = %d, saved = %d, deleted = %d\n",
		newcnt, savecnt, deleted);	
	newcnt = savecnt = deleted = idc = 0;
	if (delcnt) {
	   sprintf(buf, "mail/%s/%s", curruser, DOT_DIR);
	   while (delcnt--)
		delete_record(buf, sizeof(struct fileheader), delmsgs[delcnt]);
	}
	delcnt = 0;	    
	return;
    }
    idc++;
    if (!(fhdrp->accessed[0] & FILE_READ))
	newcnt++;
    else if (fhdrp->accessed[0] & FILE_MARKED)
	savecnt++;
    else {
	deleted++;
	sprintf(buf, "mail/%s/%s", curruser, fhdrp->filename);
	unlink(buf);
	delmsgs[delcnt++] = idc;
    }
}

int
cleanmail(urec)
struct userec *urec;
{
    struct stat statb;
    if (urec->userid[0] == '\0' || !strcmp(urec->userid, "new"))
	return 0;
    sprintf(genbuf, "mail/%s/%s", urec->userid, DOT_DIR);
    fprintf(cleanlog, "%s: ", urec->userid);
    if (stat(genbuf, &statb) == -1)
	fprintf(cleanlog, "no mail\n");
    else if (statb.st_size == 0)
	fprintf(cleanlog, "no mail\n");
    else {
	strcpy(curruser, urec->userid);
	delcnt = 0;
	apply_record(genbuf, domailclean, sizeof(struct fileheader));
	domailclean(NULL);
    }
    return 0;
}

int
m_mclean()
{
    char ans[4];

    modify_user_mode(ADMIN);
    stand_title("�M���p�H�H��");
    move(1,0);
    prints("�M���Ҧ��wŪ�B�� mark ���H��\n");
    getdata(2,0, "�T�w�� (Y/N)? [N]: ", ans, 3, DOECHO, NULL);
    if (ans[0] != 'Y' && ans[0] != 'y') {
	clear();
	return 0;
    }
    cleanlog = fopen("mailclean.log", "w");
    move(3,0);
    prints("�Э@�ߵ���.\n");
    refresh();
    if (apply_record(PASSFILE, cleanmail, sizeof(struct userec)) == -1) {
	move(4,0);
	prints("apply PASSFILE err...\n");
	pressreturn();
	clear();
	return -1;
    }
    move(4,0);
    fclose(cleanlog);
    prints("�M������! �O���� mailclean.log.\n");
    report("Mail Clean");
    pressreturn();
    clear();
    return 0;
}

void
trace_state( flag, name, size )
int	flag, size;
char	*name;
{
    char	buf[ STRLEN ];

    if( flag != -1 ) {
	sprintf( buf, "ON (size = %d)", size );
    } else {
	strcpy( buf, "OFF" );
    }
    prints( "%s�O�� %s\n", name, buf );
}

int
touchfile( filename )
char	*filename;
{
    int		fd;

    if( (fd = open( filename, O_RDWR | O_CREAT, 0600 )) > 0 ) {
	close( fd );
    }
    return fd;
}

int
m_trace()
{
    struct stat ostatb, cstatb;
    int otflag, ctflag, done = 0;
    char ans[2];
    char *msg;

    modify_user_mode(ADMIN);
    stand_title("Set Trace Options");
    while (!done) {
	move(2,0);
	otflag = stat("var/trace", &ostatb);
	ctflag = stat("var/trace.chatd", &cstatb);
	prints("�ثe�]�w:\n");
	trace_state( otflag, "�@��", ostatb.st_size );
	trace_state( ctflag, "���", cstatb.st_size );
	move(9,0);
	prints("<1> �����@��O��\n" );
	prints("<2> ������ѰO��\n" );
	getdata(12,0,"�п�� (1/2/Exit) [E]: ",ans,2,DOECHO,NULL);

	switch (ans[0]) {
	    case '1':
		if (otflag) {
		    touchfile( "var/trace" );
		    msg = "�@��O�� ON";
		} else {
		    rename( "var/trace", "var/trace.old" );
		    msg = "�@��O�� OFF";
		}
		break;
	    case '2':
		if (ctflag) {
		    touchfile( "var/trace.chatd" );
		    msg = "��ѰO�� ON";
		} else {
		    rename( "var/trace.chatd", "var/trace.chatd.old" );
		    msg = "��ѰO�� OFF";
		}
		break;
	    default:
		msg = NULL;
		done = 1;
	}
	move(t_lines-2, 0);
	if (msg) {
	    prints( "%s\n", msg );
	    report( msg );
	}
    }
    clear();
    return 0;
}

int
scan_register_form( logfile, regfile )
char	*logfile, *regfile;
{
    static char	*field[] = { "usernum", "userid", "realname", "career",
		"addr", "phone", NULL };
    static char *finfo[] = { "�b����m", "�ӽХN��", "�u��m�W", "�A�ȳ��",
		"�ثe���}", "�s���q��", NULL };
    static char *reason[] = { "�п�J�u��m�W.", "�иԶ�Ǯլ�t�P�~��.",
		"�ж�g���㪺���}���.", "�иԶ�s���q��.",
 		"�нT���g���U�ӽЪ�.", "�ХΤ����g�ӽг�.",
		"�Х� E-Mail �覡�����T�{", NULL };
    struct userec uinfo;
    FILE	*fn, *fout, *freg;
    char	fdata[ 6 ][ STRLEN ];
    char	fname[ STRLEN ], buf[ STRLEN ];
    char	ans[3], *ptr, *uid;
    int		n, unum;
    char	*Ctime();


    modify_user_mode(ADMIN);
    uid = currentuser.userid;
    stand_title( "�̧ǳ]�w�Ҧ��s���U���" );
    sprintf( fname, "%s.tmp", regfile );
    move( 2, 0 );
    if( dashf( fname ) ) {
	prints( "��L SYSOP ���b�d�ݵ��U�ӽг�, ���ˬd�ϥΪ̪��A.\n" );
	pressreturn();
	return -1;
    }
    rename( regfile, fname );
    if( (fn = fopen( fname, "r" )) == NULL ) {
	move( 2, 0 );
	prints( "�t�ο��~, �L�kŪ�����U�����: %s\n", fname );
	pressreturn();
	return -1;
    }
    memset( fdata, 0, sizeof( fdata ) );
    while( fgets( genbuf, STRLEN, fn ) != NULL ) {
	if( (ptr = (char *)strstr( genbuf, ": " )) != NULL ) {
	    *ptr = '\0';
	    for( n = 0; field[n] != NULL; n++ ) {
		if( strcmp( genbuf, field[n] ) == 0 ) {
		    strcpy( fdata[n], ptr+2 );
		    if( (ptr = (char *)strchr( fdata[n], '\n' )) != NULL )
			*ptr = '\0';
		}
	    }
	} else if( (unum = getuser( fdata[1] )) == 0 ) {
	    move( 2, 0 );
	    clrtobot();
	    prints( "�t�ο��~, �d�L���b��.\n\n" );
	    for( n = 0; field[n] != NULL; n++ )
		prints( "%s     : %s\n", finfo[n], fdata[n] );
	    pressreturn();
	    memset( fdata, 0, sizeof( fdata ) );
	} else {
	    memcpy( &uinfo, &lookupuser, sizeof( uinfo ) );
	    move( 2, 0 );
	    prints( "�b����m     : %d\n", unum );
	    user_display( &uinfo, 1 );
	    move( 16, 0 );
	    printdash( NULL );
	    for( n = 0; field[n] != NULL; n++ )
		prints( "%s     : %s\n", finfo[n], fdata[n] );
	    if( uinfo.userlevel & PERM_LOGINOK ) {
		move( t_lines-1, 0 );
		prints( "���b�����ݦA��g���U��.\n" );
		igetkey();
		ans[0] = 'D';
	    } else {
		getdata(t_lines-1,0, "�O�_��������� (Y/N/Q/Del/Skip)? [S]: ",
			ans,3,DOECHO,NULL);
	    }
	    move( 2, 0 );
	    clrtobot();
	    switch( ans[0] ) {
		case 'D': case 'd':
		    break;
		case 'Y': case 'y':
		    prints( "�H�U�ϥΪ̸�Ƥw�g��s:\n" );
		    n = strlen( fdata[5] );
		    if( n + strlen( fdata[3] ) > 60 ) {
			if( n > 40 )  fdata[5][ n = 40 ] = '\0';
			fdata[3][ 60-n ] = '\0';
		    }
		    strncpy( uinfo.realname, fdata[2], NAMELEN );
		    strncpy( uinfo.address,  fdata[4], NAMELEN );
		    sprintf( genbuf, "%s$%s@%s", fdata[3], fdata[5], uid );
		    strncpy( uinfo.termtype+16, genbuf, STRLEN-16 );
		    sprintf( buf, "tmp/regmail_%s", uinfo.userid );
		    if( (fout = fopen( buf, "w" )) != NULL ) {
			fprintf( fout, "%s\n", genbuf );
			fclose( fout );
		    }
		    substitute_record( PASSFILE, &uinfo, sizeof(uinfo), unum );
		    if( (fout = fopen( logfile, "a" )) != NULL ) {
			for( n = 0; field[n] != NULL; n++ )
			    fprintf( fout, "%s: %s\n", field[n], fdata[n] );
			n = time( NULL );
			fprintf( fout, "Date: %s\n", Ctime( &n ) );
			fprintf( fout, "Approved: %s\n", uid );
			fprintf( fout, "----\n" );
			fclose( fout );
		    }
		    if( (fout = fopen( "var/register.list","a+" )) != NULL ){
		       fprintf( fout,"'%s' register from '%s$%s@%s'\n",uinfo.userid,fdata[3],fdata[5],uid);
		       fclose(fout);
		     }
		    break;
		case 'Q': case 'q':
		    if( (freg = fopen( regfile, "a" )) != NULL ) {
			for( n = 0; field[n] != NULL; n++ )
			    fprintf( freg, "%s: %s\n", field[n], fdata[n] );
			fprintf( freg, "----\n" );
			while( fgets( genbuf, STRLEN, fn ) != NULL )
			    fputs( genbuf, freg );
			fclose( freg );
		    }
		    break;
		case 'N': case 'n':
		    for( n = 0; field[n] != NULL; n++ )
			prints( "%s: %s\n", finfo[n], fdata[n] );
		    move(9,0);
		    prints( "�п��/��J�h�^�ӽЪ���], �� <enter> ����.\n" );
		    for( n = 0; reason[n] != NULL; n++ )
			prints( "%d) %s\n", n, reason[n] );
		    getdata(10+n,0,"�h�^��]: ",buf,STRLEN,DOECHO,NULL);
		    if( buf[0] != '\0' ) {
			if( buf[0] >= '0' && buf[0] < '0' + n ) {
			    strcpy( buf, reason[ buf[0] - '0' ] );
			}
			sprintf( genbuf, "<���U����> - %s", buf );
			strncpy( uinfo.address, genbuf, NAMELEN );
			substitute_record(PASSFILE,&uinfo,sizeof(uinfo),unum);
			break;
		    }
		    move( 10, 0 );
		    clrtobot();
		    prints( "�����h�^�����U�ӽЪ�.\n" );
		    /* run default -- put back to regfile */
		default:
		    if( (freg = fopen( regfile, "a" )) != NULL ) {
			for( n = 0; field[n] != NULL; n++ )
			    fprintf( freg, "%s: %s\n", field[n], fdata[n] );
			fprintf( freg, "----\n" );
			fclose( freg );
		    }
	    }
	    memset( fdata, 0, sizeof( fdata ) );
	}
    }
    fclose( fn );
    unlink( fname );
    return( 0 );
}

int
m_register()
{
    FILE	*fn;
    char	ans[2], *fname;
    int		x, y, wid, len;

    stand_title("�]�w�ϥΪ̵��U���");
    modify_user_mode(ADMIN);
    move( 2, 0 );
    fname = "new_register";
    if( (fn = fopen( fname, "r" )) == NULL ) {
	prints( "�ثe�õL�s���U���." );
	pressreturn();
    } else {
	y = 2, x = wid = 0;
	while( fgets( genbuf, STRLEN, fn ) != NULL && x < 65 ) {
	    if( strncmp( genbuf, "userid: ", 8 ) == 0 ) {
		move( y++, x );
		prints( genbuf + 8 );
		len = strlen( genbuf + 8 );
		if( len > wid )  wid = len;
		if( y >= t_lines - 2 ) {
		    y = 2;
		    x += wid + 2;
		}
	    }
	}
	fclose( fn );
	getdata(t_lines-1,0,"�]�w��ƶ� (Y/N)? [N]: ",ans,2,DOECHO,NULL);
	if( ans[0] == 'Y' || ans[0] == 'y' ) {
	    scan_register_form( "register.list", fname );
	}
    }
    clear();
    return 0;
}


/*
 * add by tby for system note
 */
m_note()
{
     modify_user_mode(ADMIN);
     vedit("var/sysnote.ans",NA);
}  
  


int
d_board()
{
    struct boardheader binfo ;
    int bid ;
    extern int numboards ;

    stand_title( "�R���Q�װ�" );
    modify_user_mode(ADMIN);
    make_blist() ;
    move(1,0) ;
    namecomplete( "Enter Board Name: ",genbuf) ;
    if( genbuf[0] == '\0' )
	return 0;
    bid = getbnum(genbuf) ;
    if( get_record(BOARDS,&binfo,sizeof(binfo),bid) == -1 ) {
	move(2,0) ;
	prints("Invalid Board Name\n") ;
	pressreturn() ;
	clear() ;
	return 0 ;
    }
    move(1,0) ;
    prints( "Delete board '%s'.", binfo.filename );
    clrtoeol();
    getdata(2,0,"(Yes, or No) [N]: ",genbuf,4,DOECHO,NULL) ;
    if( genbuf[0] != 'Y' && genbuf[0] != 'y') { /* if not yes quit */
	move(2,0) ;
	prints("Quitting delete board\n") ;
	pressreturn() ;
	clear() ;
	return 0 ;
    }
    if( binfo.filename[0] == '\0' ) return -1; /* rrr - precaution */
    sprintf(genbuf, "deleted board %s", binfo.filename);
    report(genbuf);
    sprintf(genbuf,"/bin/rm -fr boards/%s",binfo.filename) ;
    system(genbuf) ;
    sprintf(genbuf,"/bin/rm -fr vote/%s",binfo.filename) ;
    system(genbuf) ;

    sprintf( genbuf, " << '%s' deleted by %s >>",
			binfo.filename, currentuser.userid );
    memset( &binfo, 0, sizeof( binfo ) );
    strcpy( binfo.title, genbuf );
    binfo.level = PERM_SYSOP;
    substitute_record( BOARDS, &binfo, sizeof( binfo ), bid );

    move(2,0) ;
    prints("Board Deleted\n") ;
    pressreturn() ;
    numboards = -1 ;
    clear() ;
    return 0 ;
}

int
d_user()
{
    int id ;

    stand_title( "�R���ϥΪ̱b��" );
    modify_user_mode(ADMIN);
    move(1,0) ;
    usercomplete("Enter userid to be deleted: ",genbuf);
    if(*genbuf == '\0') {
	clear() ;
	return 0 ;
    }

    if(!(id = getuser(genbuf))) {
	move(3,0) ;
	prints("Invalid User Id") ;
	clrtoeol() ;
	pressreturn() ;
	clear() ;
	return 0 ;
    }
    if (!isalpha(lookupuser.userid[0])) return 0;
	/* rrr - don't know how...*/
    move(1,0) ;
    prints("Delete User '%s'.",genbuf) ;
    clrtoeol();
    getdata(2,0,"(Yes, or No) [N]: ",genbuf,4,DOECHO,NULL) ;
    if(genbuf[0] != 'Y' && genbuf[0] != 'y') { /* if not yes quit */
	move(2,0) ;
	prints("Aborting delete User\n") ;
	pressreturn() ;
	clear() ;
	return 0 ;
    }

    sprintf(genbuf, "deleted user %s", lookupuser.userid);
    report(genbuf);

    sprintf(genbuf,"/bin/rm -fr mail/%s", lookupuser.userid) ;
    system(genbuf) ;
    sprintf(genbuf,"/bin/rm -fr home/%s", lookupuser.userid) ;
    system(genbuf) ;
    lookupuser.userid[0] = '\0' ;
    substitute_record(PASSFILE,&lookupuser,sizeof(lookupuser),id) ;
    setuserid( id, lookupuser.userid );
    move(2,0) ;
    prints("User Deleted\n") ;
    pressreturn() ;

    clear() ;
    return 0 ;
}





int
kick_user(userid)
char	userid[];
{
    int id, ind ;
    struct user_info uin;
    struct userec kuinfo;
    char kickuser[40], buffer[40];
    extern int cmpuids(), t_cmpuids();    

  if(uinfo.mode!=LUSERS&&uinfo.mode!=LAUSERS&&uinfo.mode!=FRIEND) {
    stand_title( "Kick User" );
    modify_user_mode(ADMIN);
    move(1,0) ;
    creat_list();
    namecomplete("Enter userid to be kicked: ",kickuser) ;

   }else{
     strcpy(kickuser,userid);	
     modify_user_mode(ADMIN);
   }
  if(*kickuser == '\0') {
	clear() ;
	return 0 ;
   }
      if(!(id = getuser(kickuser))) {
     	move(1,0) ;
     	prints("Invalid User Id") ;
     	clrtoeol() ;
     	pressreturn() ;
     	clear() ;
     	return 0 ;
       }
       move(1,0) ;
       prints("Kick User '%s'.",kickuser) ;
       clrtoeol();
       getdata(t_lines-1,0,"[1m (Yes, or No) [N][m :",genbuf,4,DOECHO,NULL) ;
       if(genbuf[0] != 'Y' && genbuf[0] != 'y') { 
     	move(2,0) ;
     	prints("Aborting Kick User\n") ;
     	pressreturn() ;
     	clear() ;
     	return 0 ;
       }
    search_record(PASSFILE, &kuinfo, sizeof(kuinfo), cmpuids, kickuser);
    ind = search_ulist( &uin, t_cmpuids, id );
    if (!ind || !uin.active || (kill(uin.pid,0) == -1)) {
	move(3,0) ;
	prints("User Has Logged Out") ;
	clrtoeol() ;
	pressreturn() ;
	clear() ;
	return 0 ;
    }
    kill(uin.pid,9);
    sprintf(buffer, "kicked %s", kickuser);
    report(buffer);
    sprintf( genbuf, "%s (%s)", kuinfo.userid, kuinfo.username );
    log_usies( "KICK ", genbuf );
    uin.active = NA;
    uin.pid = 0;
    uin.invisible = YEA;
    uin.sockactive = 0;
    uin.sockaddr = 0;
    uin.destuid = 0;
    update_ulist( &uin, ind );
    move(2,0) ;
    prints("User has been Kicked\n") ;
    pressreturn() ;
    clear() ;
    return 0 ;
}
  
