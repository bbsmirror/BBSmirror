/*
 *   �ϥΪ̦C��......begin
 */

#include "bbs.h"
#define	BBS_PAGESIZE    (20)
#define refreshtime	(30)
time_t update_time=0;
int	range,page;
int	freshmode=0;



struct	user_info	user_record[BBS_PAGESIZE];
struct	friend	user_record[BBS_PAGESIZE];

int
print_user_info_title()
{
    char title_str[ 512 ];
    char *field[2]={"�ϥΪ̰κ�","�u��m�W  "} ;


    showansi=1;
    move(2,0);
    clrtoeol();
    sprintf( title_str,
        "%5s%-12.12s %-16.16s %-16.16s %c %c %-16.16s %5s\n",
        " �s�� ","�ϥΪ̥N��", field[currentuser.address[STRLEN-3]], "�Ӧ�", 'P',
        (HAS_PERM(PERM_SEECLOAK) ? 'C' : ' '), "�ʺA",
#ifdef SHOW_IDLE_TIME
        "��:��" );
#else
        "" );
#endif
    standout();
    prints( "%s", title_str );
    standend();
    return 0;
}


int
getfriendstr()
{
    FILE        *fp;
    extern char friendstr[];

    setuserfile( genbuf, "overrides" );
    if ((fp = fopen(genbuf, "r")) == NULL) {
        friendstr[0]='\0';
        return 0;
    }

    strcpy( friendstr, " " );
    while (fgets(genbuf, STRLEN, fp) != NULL) {
        if ( strtok( genbuf, " \n\r\t") != NULL) {
            strcat( friendstr, genbuf );
            strcat( friendstr, " " );
        }
    }
    fclose( fp );
}

int
myfriend(str)
char str[IDLEN];
{
        extern char friendstr[];
        char buf[IDLEN+3];
	extern char friendstr[];        
        
        if(friendstr[0]=='\0')
                return 0;
        sprintf(buf," %s ",str);
        if(strstr(friendstr,buf))
                return 1;
        else return 0;
}


show_message(msg)
char msg[];
{
     move(t_lines-1,0);
     clrtoeol();
     if(msg!=NULL)
        prints("[1m%s[m",msg);
}


int
do_userlist(uentp)
struct user_info *uentp;
{       
    static	int i;
    char	user_info_str[STRLEN*2];
    int		override,beoverride;
    char	*overrideflag[2]={"","[1;32m"};

    if( uentp == NULL ) {
        move(3,0);
        print_user_info_title();
        i = 0;
        return 0;
    }
    if( !uentp->active || !uentp->pid )
        return 0;
    if(!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
        return 0;
    override=myfriend(uentp->userid);
    if( currentuser.address[STRLEN-1] ) {
        sprintf( user_info_str, " %s ", uentp->userid );
        if(!override)
            return 0;
    }
    if(i<page||i>=page+BBS_PAGESIZE||i>=range){
        i++;
        return 0;
    }

    user_record[i-page]=*uentp;
    sprintf( user_info_str,
        " %4d %s%-12.12s[m %-16.16s %-16.16s %c %c %-16.16s %5.5s\n",
        i+1,overrideflag[override],uentp->userid,
        (currentuser.address[STRLEN-3]) ? uentp->realname:uentp->username,
        (uentp->pager&ALL_PAGER || HAS_PERM(PERM_SYSOP))? uentp->from : "*",
        pagerchar( can_override(uentp->userid,currentuser.userid), uentp->pager),
        (uentp->invisible ? '#' : ' '),
        modestring(uentp->mode, uentp->destuid, 1,
                (uentp->in_chat ? uentp->chatid : NULL)),
#ifdef SHOW_IDLE_TIME
        idle_str( uentp ) );
#else
        "" );
#endif
    clrtoeol();
    prints( "%s", user_info_str );
    i++ ;
    return 0 ;
}



int
show_userlist()
{   
    char	genbuf[5];
    extern	int		count_users,count_friends;



    num_alcounter();
    if(!currentuser.address[STRLEN-1])
         range=count_users;
    else
         range=count_friends;
    if(update_time+refreshtime<time(0)){
	    apply_ulist(do_userlist);
            update_time=time(0);
    }
    do_userlist(NULL);
    if( range==0||apply_ulist(do_userlist) == -1 ) {
        move(2,0);
        prints( "�S���ϥΪ̡]�B�͡^�b�C����...\n" );
        pressanykey();
        return -1;
    }
    clrtobot();
    return 1;
}




void
t_rusers()
{
    currentuser.address[STRLEN-3] = 1;
    t_users();
    currentuser.address[STRLEN-3] = 0;
}




void
update_data()
{

        page=-1;
        if(time(0)>=update_time+refreshtime-1){
                freshmode=1;
        }
        signal(SIGALRM, update_data
        );
        alarm(refreshtime);
        return;
}


int
countusers(uentp)
struct userec *uentp ;
{
    static int totalusers;

    if(uentp==NULL){
        int c=totalusers;
        totalusers=0;
        return c;
    }
    if(uentp->numlogins != 0)  totalusers++;
    return 0;
}


int
deal_key(ch,allnum,pagenum)
int ch;
int allnum,pagenum;
{
   char    buf[STRLEN],genbuf[5];
   static  int   msgflag;



  if(msgflag==YEA){
      show_message(NULL);
      msgflag=NA;
  }
  switch(ch)
   {
     case 'k': case'K':
      if(!HAS_PERM(PERM_SYSOP))
            return 1;
      if(kick_user(&user_record[allnum-pagenum].userid)==1){
          sprintf(buf,"%s �w�Q��X���~",user_record[allnum-pagenum].userid);
       } else {
         sprintf(buf,"%s �L�k��X���~",user_record[allnum-pagenum].userid);
       }
       break;
     case 'h':case 'H':
          ansimore("etc/userlisthelp",YEA );
          clear();
          break;                        

     case 'm': case'M':
          if(!HAS_PERM(PERM_POST))
              return 1;
          m_send(user_record[allnum-pagenum].userid);
          break;
     case 'i': case 'I':
           if(!HAS_PERM(PERM_SYSOP))
               return 1;
           m_info(user_record[allnum-pagenum].userid);
           break;
     case 'f': case 'F':
          if(currentuser.address[STRLEN-1])               
               currentuser.address[STRLEN-1]=0; /*�n��/�ϥΪ̦C���ഫ*/
           else
              currentuser.address[STRLEN-1]=1;
           update_time=0;
           break;
     case 's': case 'S':
          if(!HAS_PERM(PERM_PAGE))
                return 1;
          do_sendmsg(&user_record[allnum-pagenum],NULL,NORMAL);
          break;
     case 'o': case 'O':
          if(addtooverride(user_record[allnum-pagenum].userid) ==-1){
               sprintf(buf,"%s �w�b�n�ͦW��",
           user_record[allnum-pagenum].userid);
             }
          else  {
              sprintf(buf,"%s �C�J�n�ͦW��",
              user_record[allnum-pagenum].userid);
             }
          msgflag=YEA;
          break;
     case 'd': case'D':
          if(deleteoverride(user_record[allnum-pagenum].userid)==-1) {
             sprintf(buf,"%s ���b�n�ͦW�椤",
             user_record[allnum-pagenum].userid);
            }
          else {
             sprintf(buf,"%s �w�q�B�ͦW�沾��",
             user_record[allnum-pagenum].userid);
            }
          msgflag=YEA;    
          break;
     case 'r':
     case 'Q':
         t_query(user_record[allnum-pagenum].userid);
         break;
     case KEY_TAB :
        if(!HAS_PERM(PERM_SYSOP))
           return 1;
         if(currentuser.address[STRLEN-3]==0)
               currentuser.address[STRLEN-3]=1;
         else currentuser.address[STRLEN-3]=0;
        break; 
     default:
         return 0;
  }

  if(currentuser.address[STRLEN-1])
       modify_user_mode(FRIEND);
  else
       modify_user_mode(LUSERS);
  clrtobot();


  if(show_userlist()==-1)
      return -1;
  if(msgflag)                                                                                
      show_message(buf);                                                                 

  docmdtmp((currentuser.address[STRLEN-1])?"[�n�B�ͦC��]":"[�ϥΪ̦C��]",
       " ���[t,��] �H�H[m] �e�T��[s] �[,��B��[o,d] �ݭp����[r] �����Ҧ�[f] �D��[h]");
  return 1;                                                                                  
}





int
t_friends()
{
    FILE        *fp;
    char        genbuf[STRLEN];
    extern	int		count_friends;
    

    modify_user_mode(FRIEND);
    currentuser.address[STRLEN-1]=1;
    setuserfile( genbuf, "overrides" );
    if ((fp = fopen(genbuf, "r")) == NULL) {
        move( 1, 0 );
        clrtobot();
        prints("�A�|���Q�� Info -> Override �]�w�n�ͦW��A�Х� override �]�w�n�ͦW��\n");
        pressreturn();
        return ;
    }
    fclose(fp);
    num_alcounter();
    range=count_friends;
    if( range == 0 ) {
        move( 2, 0 );
        clrtobot();
        prints( "�ثe�L�n�ͤW�u\n");
        pressreturn();
    }else
            choose(deal_key,show_userlist);
    clrtobot() ;
    currentuser.address[STRLEN-1]=0;
    return;
}



int
t_users()
{
    currentuser.address[STRLEN-1]=0;
    modify_user_mode(LUSERS);
    report("users");
    range=num_visible_users();
    if( range == 0 ) {
        move( 3, 0 );
        clrtobot();
        prints( "�ثe�L�ϥΪ̤W�u\n");
    }
    update_time=0;
    choose(deal_key,show_userlist);
    return 0;
}


int
choose(key_deal,list_show)
int (*key_deal)();
int (*list_show)();
{
    int         ch, tmp, num, number, deal;
  
    clear();
     docmdtmp((currentuser.address[STRLEN-1])?"[�n�B�ͦC��]":"[�ϥΪ̦C��]",
     " ���[t,��] �H�H[m] �e�T��[s] �[,��B��[o,d] �ݭp����[r] �����Ҧ�[f] �D��[h]");
    update_data();     
    page=-1;
    num=0;
    number=0;
    while( 1 ) {
        if( num < 0 )  num = 0;
        if( num >= range )  num = range - 1;
        if( page < 0||freshmode==1 ) {
            freshmode=0;
            page = (num / BBS_PAGESIZE) * BBS_PAGESIZE;
            move(3,0);clrtobot();
            if((*list_show)()==-1)
                return -1;
        }
        if( num < page || num >= page + BBS_PAGESIZE ) {
            page = (num / BBS_PAGESIZE) * BBS_PAGESIZE;
            move(3,0);clrtobot();
            if((*list_show)()==-1)
                return -1;
        }
        move( 3+num-page,0 ); prints( "��" );
        ch = egetch();
        move( 3+num-page,0 ); prints( "  " );
        deal=(*key_deal)(ch,num,page);

        if(deal==1)   continue;
	if( ch == 'q' || ch == 'e' || ch == KEY_LEFT || ch == EOF )
	    break;        
        switch( ch ) {
            case 'P': case 'b': case Ctrl('B'): case KEY_PGUP:
                if( num == 0 )  num = range - 1;
                else  num -= BBS_PAGESIZE;
                break;
            case 'N': case Ctrl('F'): case KEY_PGDN: case ' ':
                if( num == range - 1 )  num = 0;
                else  num += BBS_PAGESIZE;
                break;
            case 'p': case 'l': case KEY_UP:
                if( num-- <= 0 )  num = range - 1;
                break;
            case '\n': case '\r':
                if( number > 0 ) {
                    num = number - 1;
                    move(t_lines-1);
                    clrtoeol();
                    break;
                }
	    case 't': case 'T': case KEY_RIGHT:
          	if(!HAS_PERM(PERM_PAGE))
             	    break;
          	if(strcmp(currentuser.userid, user_record[num-page].userid)){
                    ttt_talk(&user_record[num-page]);
                    if(currentuser.address[STRLEN-1])
		       modify_user_mode(FRIEND);
		    else
		       modify_user_mode(LUSERS);
                    if(show_userlist()==-1)
		       break;
		    docmdtmp((currentuser.address[STRLEN-1])?"[�n�B�ͦC��]":"[�ϥΪ̦C��]",
				       " ���[t,��] �H�H[m] �e�T��[s] �[,��B��[o,d] �ݭp����[r] �����Ҧ�[f] ����[h]");
                       
            	} else
             	    break;
             	break;
            case 'n': case 'j': case KEY_DOWN:
                if( ++num >= range )  num = 0;
                break;
            case '$':
                num = range - 1;       break;
            default:
                ;
        }
        if( ch >= '0' && ch <= '9' ) {
            number = number * 10 + (ch - '0');
            ch = '\0';
        } else {
            number = 0;
        }        
    }
    clear();
    return -1 ;
}


/*
 *
 *   For override
 *
 */

struct	friend	user_record[BBS_PAGESIZE];


int
print_friend_info_title()
{
    char title_str[ 512 ];


    showansi=1;
    move(2,0);
    clrtoeol();
    sprintf( title_str,
        "%5s%-12.12s %-16.16s %-16.16s\n",
        " �s�� ","�ϥΪ̥N��",  "����", 'P',
    standout();
    prints( "%s", title_str );
    standend();
    return 0;
}



int
do_friendlist(uentp)
struct	friend	*uentp;
{
    static	int i;
    char	user_info_str[STRLEN];    

    if( uentp == NULL ) {
        print_friend_info_title();
        return 0;
    }
    if(i<page||i>=page+BBS_PAGESIZE||i>=range){
        i++;
        return 0;
    }

    friend_record[i-page]=*uentp;
    sprintf( user_info_str,
        " %4d %-12.12s %-40.40s \n",
        i+1,,uentp->id, uentp->exp );
    clrtoeol();
    prints( "%s", user_info_str );
    i++ ;
    return 0 ;
}

int
show_friendlist()
{

  range=t_listfriends();
  setuserfile( genbuf, "friends" );
  apply_record(genbuf, do_friendlist, sizeof(struct friend);
  clrtobot();
  return 1;
}


int
choose_friend(list_show)
int (*list_show)();
(
    int         ch, tmp, num, number;
   
 
    clear();
    docmdtmp("�ק�n�ͦW��",
       "  ���}[e,Q]  �d��[q,->]   �W�[[a]   �R��[d]   �ק�[n,c]   �e�H[m]   ����[?,h]"); 
    page=-1;
    num=0;
    number=0;
    while( 1 ) {
        if( num < 0 )  num = 0;
        if( num >= range )  num = range - 1;
        if( page < 0 ) {
            freshmode=0;
            page = (num / BBS_PAGESIZE) * BBS_PAGESIZE;
            move(3,0);clrtobot();
            if((*list_show)()==-1)
                return -1;
        }
        if( num < page || num >= page + BBS_PAGESIZE ) {
            page = (num / BBS_PAGESIZE) * BBS_PAGESIZE;
            move(3,0);clrtobot();
            if((*list_show)()==-1)
                return -1;
        }
        move( 3+num-page,0 ); prints( "��" );
        ch = egetch();
        move( 3+num-page,0 ); prints( "  " );

	if( ch == 'q' || ch == 'e' || ch == KEY_LEFT || ch == EOF )
	    break;        
        switch( ch ) {
            case 'P': case 'b': case Ctrl('B'): case KEY_PGUP:
                if( num == 0 )  num = range - 1;
                else  num -= BBS_PAGESIZE;
                break;
            case Ctrl('F'): case KEY_PGDN: case ' ':
                if( num == range - 1 )  num = 0;
                else  num += BBS_PAGESIZE;
                break;
            case 'p': case 'l': case KEY_UP:
                if( num-- <= 0 )  num = range - 1;
                break;
            case '\n': case '\r':
                if( number > 0 ) {
                    num = number - 1;
                    move(t_lines-1);
                    clrtoeol();
                }
                break;
	    case 'q': case 'r': case KEY_RIGHT:
		t_query(friend_record[num-page].id);
             	break;
            case 'm': case 'M':
                m_send(friend_record[num-page].id);
                break;
            case 'a': case 'A':
                addtooverride(friend_record[num-page].id);
                break;
            case 'd': case 'D':
                deleteoverride(friend_record[num-page].id);
                break;
            case 'n': case 'c':
		editoverride(friend_record[num-page].id);
		break;                   
            case 'j': case KEY_DOWN:
                if( ++num >= range )  num = 0;
                break;
            case '$':
                num = range - 1;       
                break;
            default:
                ;
        }
        if( ch >= '0' && ch <= '9' ) {
            number = number * 10 + (ch - '0');
            ch = '\0';
        } else {
            number = 0;
        }        
    }
    clear();
    return -1 ;
}

