
#include "bbs.h"

main()
{
        FILE *rec;
        int i=0;
        struct userec user;
        char  buf[80];
        
        rec=fopen("./.PASSWDS","rb");
        printf("Reading PASSWDS");
        while(1){
             i++;
             if(fread(&user,sizeof(user),1,rec)<=0) break;
 	     if(!((char *)strchr(user.termtype+16,'$')||user.termtype[16]=='\0')){
 	        sprintf(buf,"/bin/mail -s ��j�u��BBS���i %s < art",user.termtype+16);
		system(buf);
		printf(buf);
	      }
        }
        printf("\n%d mails...\n",i);
        fclose(rec);
}
