/*
    �\��     :  �C�X�����ϥΪ̸��
    �`�N�ƶ� :  ���n�ثe�� bbs.h
    Compile  :  gcc -o showuser showuser.c
    �ϥΤ覡 :  showuser ~bbs/.PASSWD i10 l5 e25
                (�C�X�ϥΪ̪� ID, login ����, email �a�})
*/

/* 
   '#define FIRSTLOGIN' is for NCTU CSIE BBS only, you may 
   delete it or keep it 
*/

#define  FIRSTLOGIN

#include <stdio.h>
#include "bbs.h"

struct userec aman;
char field_str[ 20 ][ 128 ];
char field_idx[] = "dihlpnvraetuf" ;
int  field_count = 0;
int  field_lst_no [ 20 ];
int  field_lst_size [ 20 ];
int  field_default_size [ 20 ] = {
    4,  8, 16,  4,  4,  
   12, 24, 12, 24, 30, 
   10,  8, 16,  0,  0,
    0,  0,  0,  0,  0
};

char *field_name[] = {
    "Num", 
    "ID ", 
    "LastHost",
    "Visit",
    "Post",
    "Nick",
    "LastVisit",
    "Real",
    "Addr",
    "Email",
    "Term",
    "Userlevel",
    "FirstVisit"
};

char *MYPASSFILE;

set_opt(argc, argv)
int argc;
char *argv[];
{
    int i, flag, field, size;
    int  *p;
    char *ptr, *field_ptr;

    field_count = 0;

    for (i = 2; i < argc; i++) {
        field_ptr = (char *)strchr(field_idx, argv[ i ][ 0 ] );
        if (field_ptr == NULL) continue;
        else field = field_ptr - field_idx ;

        size  = atoi( argv[ i ] + 1 );

        field_lst_no[ field_count ] = field;
        field_lst_size[ field_count ] = (size == 0) ? 
            field_default_size[ field ] : size;
        field_count++;
    }

}

char *repeat(ch, n)
int ch, n;
{
    char *p;
    int   i;
    static char buf[ 256 ];

    p = buf;
    for (i = 0 ; i < n ; i++) *(p++) = ch ;
    *p = '\0';
    return buf;
}

print_head()
{
    int i, field, size;

    for (i = 0; i < field_count; i++) {
        field = field_lst_no[ i ];
        size  = field_lst_size[ i ];
        printf("%-*.*s ", size, size, field_name[ field ] );
    }
    printf("\n");
    for (i = 0; i < field_count; i++) {
        field = field_lst_no[ i ];
        size  = field_lst_size[ i ];
        printf("%-*.*s ", size, size, repeat('=', size ));
    }
    printf("\n");
}

print_record()
{
    int i, field, size;

    for (i = 0 ; i < field_count; i++) {
        field = field_lst_no[ i ];
        size  = field_lst_size[ i ];
        printf("%-*.*s ", size, size, field_str[ field ] );
    }
    printf("\n");
}

dump_record(serial_no, p)
int serial_no;
struct userec *p;
{
    int i = 0, j ;
    int pat;

    /* the order of sprint should follow the order of list_idx[] */
  
    sprintf( field_str[ i++ ], "%d", serial_no );
    sprintf( field_str[ i++ ], "%s", p->userid );
    sprintf( field_str[ i++ ], "%s", p->lasthost );
    sprintf( field_str[ i++ ], "%d", p->numlogins );
    sprintf( field_str[ i++ ], "%d", p->numposts );
    sprintf( field_str[ i++ ], "%s", p->username );
    sprintf( field_str[ i++ ], "%s", ctime(&p->lastlogin) );
    sprintf( field_str[ i++ ], "%s", p->realname );
    sprintf( field_str[ i++ ], "%s", p->address );
    sprintf( field_str[ i++ ], "%s", p->email );
    sprintf( field_str[ i++ ], "%s", p->termtype );

    pat = p->userlevel;
    for ( j=0; j<31; j++, pat >>= 1) {
        field_str[ i ][ j ] = (pat &  1) ? '1' : '0' ;
    } 
    field_str[ i++ ][ j ] = '\0'; 

#ifdef FIRSTLOGIN    
    sprintf( field_str[ i++ ], "%s", ctime(&p->firstlogin) );
#endif
}

main(argc, argv)
int  argc;
char *argv[];
{
    FILE *inf;
    int  i;

    if (argc < 2) {
    printf("Usage: %s %s\n%s\n",
     argv[ 0 ], 
     "password_file [(d|i|h|l|p|n|v|r|a|e|t|u)(field_width)] ....", "\
     no,                /* d */
     userid,            /* i */
     lasthost,          /* h */
     numlogins,         /* l */
     numposts,          /* p */
     username,          /* n */
     lastlogin,         /* v */
     realname,          /* r */
     address,           /* a */
     email,             /* e */ 
     termtype,          /* t */
     userlevel,         /* u */
     firstlogin,        /* f */");
     exit( 0 );
    } else {
        set_opt( argc, argv );
        MYPASSFILE = argv[ 1 ];
    }

    
    inf = fopen( MYPASSFILE, "rb" );
    if (inf == NULL) printf("Error open %s\n", MYPASSFILE); 

    print_head(); 

    for (i=0; ; i++) {
        if (fread(&aman, sizeof( aman ), 1, inf ) <= 0) break;
        dump_record(i,  &aman);    
        print_record();
    }

    fclose( inf );
}

