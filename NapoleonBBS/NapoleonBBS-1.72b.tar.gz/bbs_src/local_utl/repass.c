#include "bbs.h"


main()
{
        FILE *rec,*rec2;
        int i=0;
        struct userec user;
        rec=fopen("./.PASSWDS","rb");
        rec2=fopen("./.PASSWDS.tmp","wb");
        

        printf("Records transfer...");
        while(1){
             i++;
             if(fread(&user,sizeof(user),1,rec)<=0) break;
             user.userlevel &= ~PERM_OVOTE;
             fwrite(&user,sizeof(user),1,rec2);     
        }
        printf("\n%d records changed...\n",i);
        fclose(rec);
        fclose(rec2);
}
