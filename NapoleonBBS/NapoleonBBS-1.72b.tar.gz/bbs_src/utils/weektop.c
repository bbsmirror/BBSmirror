#include <stdio.h>
#include <time.h>

#define hashsize 1024
#define token1   "�H��:"
#define token2   "��  �D:"
#define token3   "�o�H��:"
#define UNIX

struct postrec {
 char 		*title;     	/* title name */
 char           *board;      /* board name */
 int  		postno;     	/* post number */
 time_t 	postdate;   	/* last post's date */
 struct postrec *next;          /* next rec */
} *bucket[hashsize];

struct posttop {
 char 		title[80];     	/* title name */
 char           board[40];      /* board name */
 int  		postno;     	/* post number */
 time_t 	postdate;   	/* last post's date */
} top[30];

char month[12][4]={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct",
	    "Nov","Dec"};

search(key,rec1, rec2)
char *key;
char *rec1;
time_t rec2;
{
  struct postrec *p,*q,*s;
  int i,found=0;

  i=hash(key);
  q=NULL;
  p=bucket[i];
  while(p!=NULL && (!found))
  {
    if (!strcmp(p->title,key))
       found=1;
    else {
       q=p;
       p=p->next;
    }
  }
  if (found) {
    p->postno++;
    p->postdate=(p->postdate > rec2 ? p->postdate : rec2);
  }
  else {
    s=(struct postrec *)malloc(sizeof(struct postrec));
    s->title = (char *) malloc(strlen(key)+1);
    s->board = (char *) malloc(strlen(rec1)+1);
    strcpy(s->title,key);
    strcpy(s->board,rec1);
    s->postno=1;
    s->postdate=rec2;
    s->next=NULL;
    if (q==NULL)
      bucket[i]=s;
    else
      q->next=s;
  }
}

hash(key)
char *key;
{
 int i, value=0;

 for (i=0; i<80 && key[i]!=NULL; i++)
   value+=key[i]<0 ? -key[i]: key[i];

 value=value%hashsize;
 return value;
}

#ifdef LINUX
time_t
cvtime(date)
char *date;
{
  int i;
  int long mon, day, year, hour, min, sec;
  char buf[3];
  time_t result=0;
  struct tm ltm;

  for (i=0;i<12;i++) {
    if (!strncmp(date+4, month[i],3))
       break;
  }
  ltm.tm_mon = i;
  buf[2]=NULL;
  strncpy(buf, date+8,2);
  ltm.tm_mday = atoi(buf);
  strncpy(buf, date+11,2);
  ltm.tm_hour = atoi(buf);
  strncpy(buf, date+14,2);
  ltm.tm_min = atoi(buf);
  strncpy(buf, date+17,2);
  ltm.tm_sec = atoi(buf);
  strncpy(buf, date+22,2);
  ltm.tm_year = atoi(buf);

/*
  result=(year-70)*365*86400;
  result+=((year-70+2)/4)*86400;
  switch (mon) {
   case 12: result+=30*86400;
   case 11: result+=31*86400;
   case 10: result+=30*86400;
   case 9:  result+=31*86400;
   case 8:  result+=31*86400;
   case 7:  result+=30*86400;
   case 6:  result+=31*86400;
   case 5:  result+=30*86400;
   case 4:  result+=31*86400;
   case 3:  result+=28*86400;
	    if (year%4==0) result+=86400;
   case 2:  result+=31*86400;
  }
  result+=(day-1)*86400;
  result+=(hour-8)*3600;
  result+=min*60;
  result+=sec; */
  result = mktime(&ltm);
  return(result);
}
#endif

sort(pp)
struct postrec *pp;
{
 int i,j;

 for (i=0; i<30; i++) {
  if (pp->postno > top[i].postno) {
     for (j=28; j>=i; j--) {
      strcpy(top[j+1].title, top[j].title);
      strcpy(top[j+1].board, top[j].board);
      top[j+1].postno=top[j].postno;
      top[j+1].postdate=top[j].postdate;
     }
      strcpy(top[i].title, pp->title);
      strcpy(top[i].board, pp->board);
      top[i].postno=pp->postno;
      top[i].postdate=pp->postdate;
      break;
  }
 }
}

search_group(fp2, group, board)
FILE *fp2;
char *group, *board;
{
   char buf[80],*p, *q;
   int len;

   if ((len=strlen(group)) <= 2) return;
    group[len-1]=NULL;
   rewind(fp2);
   while (fgets(buf,79,fp2)!=NULL) {
     if (!strncmp(buf,group,len-1)) {
       q=buf+len; len=strlen(q);
       p=(char *) strtok((char *) q," \t");
       strncpy(board,p,39);
       return;
     }
    }
     strncpy(board, group,39);
     return;
}

main( argc, argv )
char    *argv[];
{
    char        *progmode;
    char        *homepath, *outpath;

   FILE   *fp, *fp2;
   char   dirbuf[40];
   char   buf[128];
   char   board[40];
   char   title[80];
   char   date[25];
   time_t realdate;
   char   *p;
   struct postrec *pp,*qq,*ss;
   int    i, j, find=1;
   struct tm     ltm;

    if( argc < 3 ) {
      printf(" usage %s :\n   %s bbshome output\n\n",argv[0],argv[0]);
      return ;
    }
    homepath = argv[1];
    outpath = argv[2];

   chdir(homepath);
/*
   system("mkdir TOPWEEK");
*/
   chdir("TOPWEEK");
   system("rm echomail.7");
   system("mv echomail.6 echomail.7");
   system("mv echomail.5 echomail.6");
   system("mv echomail.4 echomail.5");
   system("mv echomail.3 echomail.4");
   system("mv echomail.2 echomail.3");
   system("mv echomail.1 echomail.2");
   system("mv ../echomail.log echomail.1");
   strcpy(dirbuf,"echomail.7");

   if ((fp2=fopen("../innd/newsfeeds.bbs","r"))==NULL) {
     find=0;
     fclose(fp2);
   }
 for (j=7; j>0; j--) {
  dirbuf[9]='0'+j;
   if ((fp=fopen(dirbuf,"r"))==NULL) {
     printf("Cann't find %s\n", dirbuf);
     continue;
   }

   while (fgets(buf,127,fp)!=NULL) {
    if ((p=(char *)strstr(buf, token1))!=NULL) {       /* get board name */
       if (find) 
         search_group(fp2, p+6, board); 
       else {
         strncpy(board,p+6,39);
         i=strlen(p+6);
         board[i]=NULL;
       }
       if (fgets(buf,127,fp)!=NULL) {
	 if ((p=(char *)strstr(buf, token2))!=NULL) {  /* get title */
	   if (!strncmp(p+8, "Re:",3))
	     p+=4;
	   strncpy(title, p+8, 79);
	   i=strlen(p+8);
	   title[i-1]=NULL;
	   if (fgets(buf,127,fp)!=NULL) {
	     if (strstr(buf, token3)!=NULL) {         /* get date */
	       p=(char *)strrchr(buf, '(');
	       strncpy(date, p+1, 24);
	       date[24]=NULL;
#ifdef UNIX
               strptime(date, "%A %h %e %T %Y", &ltm);
               realdate = timelocal(&ltm);
#endif
#ifdef LINUX
               realdate=cvtime(date);
#endif
	       search(title,board,realdate);
	     }
	   }
	 }
       }
    }
   }
   fclose(fp);
 }
   for (i=0; i<hashsize; i++) {
    if ((pp=bucket[i])!=NULL) {
	sort(pp);
	pp=pp->next;
    }
   }
  chdir(outpath);
  if ((fp=fopen("weektop","w")) == NULL) {
    printf("cann't open weektop\n");
    return 0;
  }
   fprintf(fp,"            [1;34m-----[37m=====[41m �@�g�������D [40m=====[34m-----                           [0m\n");
   for (i=0; i<30; i++) {
	strcpy(buf,ctime(&top[i].postdate));
        buf[20]=NULL; p=buf+4;
	fprintf(fp," [1;31m%2d. [33m�H�� : [32m%-40s [33m�ɶ� : [0;32m%s\n"
        ,i+1
	,top[i].board
	,p);
        fprintf(fp,"     [1;33m���D : [0;44;37m%-40s[40m [1;33m�H��� : [35m%2d[0m\n"
	,top[i].title
	,top[i].postno);
   }
  fclose(fp);
}
