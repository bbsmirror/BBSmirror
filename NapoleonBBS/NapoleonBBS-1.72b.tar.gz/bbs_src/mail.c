/*
 * 	mail.c
 */




#include "bbs.h"
#define		INTERNET_PRIVATE_EMAIL

extern char quote_file[], quote_user[];

char	currmaildir[ STRLEN ] ;

char *email_domain()
{
    char	*domain;
    char	*sysconf_str();

    domain = sysconf_str( "BBSDOMAIN" );
    if( domain == NULL )  domain = "unknown.BBSDOMAIN";
    return domain;
}

char *get_bbs_english_name()
{
    char	*name;
    char	*sysconf_str();

    name = sysconf_str( "BBSID" );
    if( name == NULL )  name = "unknown.BBSID";
    return name;
}

int
chkmail()
{
    static long lasttime = 0;
    static ismail = 0 ;
    struct fileheader fh ;
    struct stat st ;
    int fd ;
    register int i, offset ;
    register long numfiles ;
    unsigned char ch ;
    extern char currmaildir[ STRLEN ] ;

    if( !HAS_PERM( PERM_BASIC ) ) {
	return 0;
    }
    offset = (int)((char *)&(fh.accessed[0]) - (char *)&(fh)) ;
    if((fd = open(currmaildir,O_RDONLY)) < 0)
      return (ismail = 0) ;
    fstat(fd,&st) ;
    if(lasttime >= st.st_mtime) {
        close(fd) ;
        return ismail ;
    }
    lasttime = st.st_mtime ;
    numfiles = st.st_size ;
    numfiles = numfiles/sizeof(fh) ;
    if(numfiles <= 0) {
      close(fd) ;
      return (ismail = 0) ;
    }
    lseek(fd,(off_t)offset,SEEK_SET) ;
    for(i = 0 ; i < numfiles ; i++,lseek(fd,(off_t)offset+i*sizeof(fh),SEEK_SET)) {
        read(fd,&ch,1) ;
        if(!(ch & FILE_READ)) {
            close(fd) ;
            return(ismail = 1) ;
        }
    }
    close(fd) ;
    return(ismail = 0) ;
}

void
m_internet()
{
    char receiver[ STRLEN ], title[ STRLEN ] ;

    modify_user_mode(SMAIL);
    getdata(1, 0, "���H�H: ", receiver, STRLEN, DOECHO, NULL) ;
    getdata(2, 0, "�D�D  : ", title, STRLEN, DOECHO, NULL ); 
    if ( !invalidaddr(receiver) && strlen( title ) > 0 ) {
	*quote_file = '\0';
        do_send( receiver, title );
    } else {
        move(3, 0);
        prints("���H�H�ΥD�D�����T, �Э��s������O\n");
        pressreturn();
    }
    clear();
    refresh();
}

void
m_init()
{
	sprintf(currmaildir,"mail/%s/%s",currentuser.userid, DOT_DIR) ;
}

int
do_send(userid,title)
char *userid, *title ;
{
    struct fileheader newmessage ;
    struct stat st ;
    char	filepath[STRLEN], fname[STRLEN], *ip;
    int		fp ;
#ifdef INTERNET_PRIVATE_EMAIL
    int		internet_mail = 0;
    char	tmp_fname[ 256 ];

    /* I hate go to , but I use it again for the noodle code :-) */
    if (strchr(userid, '@')) {
	internet_mail = 1;
	sprintf( tmp_fname, "/tmp/bbs-internet-gw-%05d", getpid() );
	strcpy( filepath, tmp_fname);   
	goto edit_mail_file;
    }
    /* end of kludge for internet mail */
#endif

    if(!getuser(userid))
	return -1 ;
    if (!(lookupuser.userlevel & PERM_READMAIL))
	return -3;
    sprintf(filepath,"mail/%s",userid) ;
    if(stat(filepath,&st) == -1) {
	if(mkdir(filepath,0755) == -1) 
	    return -1 ;
    } else {	
	if(!(st.st_mode & S_IFDIR))
	    return -1 ;
    }
    memset(&newmessage, 0,sizeof(newmessage)) ;
    sprintf(fname,"M.%d.A", time(NULL)) ;
    sprintf(filepath,"mail/%s/%s",userid,fname) ;
    ip = strrchr(fname,'A') ;
    while((fp = open(filepath,O_CREAT|O_EXCL|O_WRONLY,0644)) == -1) {
	if(*ip == 'Z')
	    ip++,*ip = 'A', *(ip + 1) = '\0' ;
	else
	    (*ip)++ ;
	sprintf(filepath,"mail/%s/%s",userid,fname) ;
    }
    close(fp) ;
    strcpy(newmessage.filename,fname) ;
    if(!title)
	getdata(2,0,"Title: ",newmessage.title,STRLEN,DOECHO,NULL) ;
    else 
	strncpy(newmessage.title,title,STRLEN) ;
    strncpy(save_title,newmessage.title,STRLEN) ;
    strncpy(save_filename,fname,4096) ;
    in_mail = YEA ;
#if defined(MAIL_REALNAMES)
    sprintf(genbuf,"%s (%s)",currentuser.userid,currentuser.realname) ;
#else
    sprintf(genbuf,"%s (%s)",currentuser.userid,currentuser.username) ;
#endif
    strncpy(newmessage.owner,genbuf,STRLEN) ;
    sprintf(filepath,"mail/%s/%s",userid,fname) ;

#ifdef INTERNET_PRIVATE_EMAIL
edit_mail_file:
#endif

    do_quote( filepath );

#ifdef INTERNET_PRIVATE_EMAIL
    if (internet_mail) {
	int res, ch;
	if (vedit(filepath,NA) == -1) {
	    unlink( filepath );
	    clear(); return -2;
	}
	clear() ;
        prints("�H��Y�N�H�� %s \n", userid);
        prints("���D���G %s \n", title );
        prints("�T�w�n�H�X��? (Y/N) [Y]");
        refresh();
        ch = egetch();
        switch ( ch ) {
	    case 'N': case 'n': 
		prints("%c\n", 'N');
		prints("\n�H��w����...\n");
		res = -2;
	    default: 
		prints("%c\n", 'Y');
		prints("�еy��, �H��ǻ���...\n"); refresh();
		res = bbs_sendmail( tmp_fname, title, userid ); 
		prints("�H��w�H�X...\n");
		break;
	}
	unlink(tmp_fname); 
	return res;
    } else
#endif
    {
	if (vedit(filepath,YEA) == -1) {
	    unlink( filepath );
	    clear(); return -2;
	}
/*	getdata(t_lines-1,0,"�H��O�_�d�� (Y/N)? [N]: ",genbuf,2,DOECHO,NULL);
	if( genbuf[0]=='y' || genbuf[0]=='Y' )
	    mail_file(filepath,currentuser.userid,save_title);
	clear() ;*/
        if((lookupuser.userlevel & PERM_LOGINOK) && (lookupuser.userlevel & PERM_UNUSE14))
   	    if(out_mail(filepath,newmessage.title,lookupuser.termtype+16)){
   	        unlink(filepath);
   	        sprintf(genbuf, "mailed %s forwarded %s", userid, lookupuser.termtype+16);
                report(genbuf);       	   
	        return 0;
	    }
	sprintf(genbuf,"mail/%s/%s",userid, DOT_DIR) ;
	if(append_record(genbuf,&newmessage,sizeof(newmessage)) == -1)
	     return -1 ;
	sprintf(genbuf, "mailed %s", userid);
	report(genbuf);
	return 0 ;
    }
}

int
out_mail(fname, title, receiver)
char *fname, *title, *receiver;
{
  
   if((char *)strchr(receiver,'$'))
       return 0;
   if( bbs_sendmail(fname,title,receiver) != -1 ){
       return 1;
   } else
      return 0;
}



int
m_send(userid)
char	userid[];
{
    char uident[STRLEN] ;


   if(uinfo.mode!=LUSERS&&uinfo.mode!=LAUSERS&&uinfo.mode!=FRIEND){
       modify_user_mode(SMAIL);
       move(2,0) ;
       prints("<Enter Userid>\n") ;
       move(1,0) ;
       clrtoeol() ;
       usercomplete("To: ",uident) ;
    } else{
     strcpy(uident,userid);	
     modify_user_mode(SMAIL);
    }

    if(uident[0] == '\0') {
	clear() ;
	return 0 ;
    }
    *quote_file = '\0';
    switch (do_send(uident,NULL)) {
	case -1: prints("Bad UserId\n") ; break;
	case -2: prints("Mail Aborted\n"); break;
	case -3: prints("User '%s' cannot receive mail\n", uident); break;
    }
    pressreturn() ;
    return 0 ;
}

int
read_mail(fptr)
struct fileheader *fptr ;
{
    sprintf(genbuf,"mail/%s/%s",currentuser.userid,fptr->filename) ;
    ansimore(genbuf,NA) ;
    fptr->accessed[0] |= FILE_READ;
    return 0 ;
}

int mrd ;

int delmsgs[1024] ;
int delcnt ;

int
read_new_mail(fptr)
struct fileheader *fptr ;
{
	static int idc ;
	char done = NA, delete_it;
	char fname[256];

	if(fptr == NULL) {
		delcnt = 0 ;
		idc = 0 ;
		return 0;
	}
	idc++ ;
	if(fptr->accessed[0])
	  return 0 ;
	prints("Read message titled '%s' from: %s?\n",fptr->title,fptr->owner) ;
	prints("(Yes, or No): ") ;
	getdata(1,0,"(Yes, or No) [Y]: ",genbuf,4,DOECHO,NULL) ;
	if(genbuf[0] != 'y' && genbuf[0] != 'Y' && genbuf[0] != '\0') {
		clear() ;
		return 0 ;
	}
	read_mail(fptr) ;
	strcpy(fname, genbuf);
	mrd = 1 ;
	if(substitute_record(currmaildir,fptr,sizeof(*fptr),idc))
	  return -1 ;
	delete_it = NA;
    while (!done) {
	move(t_lines-1, 0);
        prints("(R)eply, (D)elete, or (G)o on? [G]: ");
	switch ( egetch() ) {
	    case 'R': case 'r': 
	      mail_reply(idc, fptr, currmaildir);
	      break;
	    case 'D': case 'd': delete_it = YEA;
	    default: done = YEA;
	}
        if (!done) ansimore(fname, NA);  /* re-read */
    }
    if (delete_it) {
        clear() ;
        prints("Delete Message '%s' ",fptr->title) ;
	getdata(1,0,"(Yes, or No) [N]: ",genbuf,STRLEN,DOECHO,NULL) ;
        if(genbuf[0] == 'Y' || genbuf[0] == 'y') { /* if not yes quit */
	  sprintf(genbuf,"mail/%s/%s",currentuser.userid,fptr->filename) ;
	  unlink(genbuf) ;
	  delmsgs[delcnt++] = idc ;
	}
    }
    clear() ;
    return 0 ;
}

int
m_new()
{
    clear() ;
    mrd = 0 ;
    modify_user_mode( RMAIL );
    read_new_mail(NULL) ;
    if(apply_record(currmaildir,read_new_mail,sizeof(struct fileheader)) == -1) {
	clear() ;
	move(0,0) ;
	prints("No new messages\n\n\n") ;
	return -1 ;
    }
    if(delcnt) {
	while(delcnt--)
 	delete_record(currmaildir,sizeof(struct fileheader),delmsgs[delcnt]) ;
    }
    clear() ;
    move(0,0) ;
    if(mrd)
	prints("No more messages.\n\n\n") ;
    else
	prints("No new messages.\n\n\n") ;
    return -1 ;
}

extern char BoardName[];

void
mailtitle()
{
    
  
    char	title[ STRLEN ];


   if ( chkmail() )
	strcpy( title, "[1;41;5m[���z���H]" );
    else
	strcpy( title, BoardName );

    if( iscolor )
      showtitle( "�l����", title );
    else
      titletmp( "�l����", title );
    showansi=1;
    prints( "[0;1;32m���}[��,e]  ���[��,��]  �\\Ū�H��[��,r]  �^�H[R]  ��H�M���«H[d/D]  �D�U[h]\n" );
    prints("[0;1;44m�s��   %-12s %6s  %-50s [m\n", "�Ӧ�", "��  ��", " ��  �D") ;
    clrtobot() ;
    showansi=0;
}

char *
maildoent(num,ent)
int	num;
struct fileheader *ent ;
{
	static char buf[512] ;
	char b2[512] ;
	char status;
	char *t ;
        time_t	filetime;
        char	*date;

	strncpy(b2,ent->owner,STRLEN) ;
	if( (t = strchr(b2,' ')) != NULL )
	  *t = '\0' ;
	if (ent->accessed[0] & FILE_READ) {
	  if (ent->accessed[0] & FILE_MARKED) status = 'm';
	  else status = ' ';
	}
	else {
	  if (ent->accessed[0] & FILE_MARKED) status = 'M';
	  else status = 'N';
	}
        filetime = atoi( ent->filename + 2 );
	date = ctime( &filetime ) + 4;
	ent->title[48]='\0';
	sprintf(buf," %3d %c %-12.12s %6.6s   %-44s",num,status,b2,date,ent->title) ;
	return buf ;
}

#ifdef POSTBUG
extern int bug_possible;
#endif

int
mail_read(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
	char buf[512], notgenbuf[128];
	char *t ;
	char done = NA, delete_it, replied;

	clear() ;
	strcpy(buf,direct) ;
	if( (t = strrchr(buf,'/')) != NULL )
	  *t = '\0' ;
	sprintf(notgenbuf, "%s/%s",buf,fileinfo->filename) ;
	delete_it = replied = NA;
	while (!done) {
	    ansimore(notgenbuf, NA) ;
	    move(t_lines-1, 0);
            showansi=1;
            prints("[1;44;35m[�\\Ū�H��] [33m�^�H R �x �H�^ F �x���� Q,���x�W�@�� ���x�U�@�� <Space>,<Enter>,�� [m ");
            showansi=0;
	    switch (egetch()) {
		case 'R': case 'r': 
		  replied = YEA;
		  mail_reply(ent,fileinfo, direct);
		  break;
		case 'j': case KEY_RIGHT: case KEY_DOWN: case KEY_PGDN:
		case 23:
	 	     return READ_NEXT;
    	        case KEY_UP: case KEY_PGUP: 
	  	     return READ_PREV;
		case 'D': case 'd':
		    delete_it = YEA;
		    break;
	        case 'F':case 'f':
                    forward_post(ent,fileinfo,direct);
                    break;
	        default: done = YEA;
	        
	    }
	} 
	if (delete_it) mail_del(ent, fileinfo, direct);
	else {
	  fileinfo->accessed[0] |= FILE_READ;
#ifdef POSTBUG
	  if (replied) bug_possible = YEA;
#endif
	  substitute_record(currmaildir, fileinfo, sizeof(*fileinfo),ent) ;
#ifdef POSTBUG
	  bug_possible = NA;
#endif
	}
	return FULLUPDATE ;
}


int
mail_reply(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char	uid[STRLEN] ;
    char	title[STRLEN] ;
    char	*t ;

    modify_user_mode( SMAIL );
    strncpy(uid,fileinfo->owner,STRLEN) ;
    if( (t = strchr(uid,' ')) != NULL )
	*t = '\0' ;
    if (toupper(fileinfo->title[0]) != 'R' || fileinfo->title[1] != 'e' ||
	fileinfo->title[2] != ':') strcpy(title,"Re: ") ;
    else title[0] = '\0';
    strncat(title,fileinfo->title,STRLEN-5) ;

    sprintf(quote_file,"mail/%s/%s",currentuser.userid,fileinfo->filename);
    strcpy(quote_user, fileinfo->owner);      
    switch (do_send(uid,title)) {
	case -1: prints("Could not send\n"); break;
	case -2: prints("Reply Aborted\n"); break;
	case -3: prints("User '%s' cannot receive mail\n", uid); break;
	default: prints("File Sent\n");
    }
    pressreturn() ;
    return FULLUPDATE ;
}

int
mail_del(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
	char buf[512] ;
	char *t ;
	extern int cmpfilename() ;
	extern char currfile[] ;

	clear() ;
	prints("Delete Message '%s' ",fileinfo->title) ;
	getdata(1,0,"(Yes, or No) [N]: ",genbuf,STRLEN,DOECHO,NULL) ;
	if(genbuf[0] != 'Y' && genbuf[0] != 'y') { /* if not yes quit */
		move(2,0) ;
		prints("Quitting Delete Mail\n") ;
		pressreturn() ;
		clear() ;
		return FULLUPDATE ;
	}		
	strcpy(buf,direct) ;
	if( (t = strrchr(buf,'/')) != NULL )
	  *t = '\0' ;
	strncpy(currfile,fileinfo->filename,STRLEN) ;
	if(!delete_file(direct,sizeof(*fileinfo),ent,cmpfilename)) {
		sprintf(genbuf,"%s/%s",buf,fileinfo->filename) ;
		unlink(genbuf) ;
		return DIRCHANGED ;
	}
	move(2,0) ;
	prints("Delete failed\n") ;
	pressreturn() ;
	clear() ;
	return FULLUPDATE ;
}

#ifdef INTERNET_EMAIL

int
mail_forward(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
	char buf[STRLEN];
	char *p;
	if (!HAS_PERM(PERM_FORWARD)) {
	    return DONOTHING;
	}
	strncpy(buf, direct, sizeof(buf));
	if ((p = strrchr(buf, '/')) != NULL)
	    *p = '\0';
	clear();
	switch (doforward(buf, fileinfo, 0)) {
	  case 0:  
                   prints("�峹��H����!\n");
		   sprintf(genbuf, "forwarded file '%s' to %s",fileinfo->title, currentuser.email);
		   report(genbuf);
		   break;
	  case -1: prints("Forward failed: system error.\n");
		   break;
	  case -2: prints("Forward failed: missing or invalid address.\n");
	}
	pressreturn();
	clear();
	return FULLUPDATE;
}

int
mail_uforward(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
	char buf[STRLEN];
	char *p;
	if (!HAS_PERM(PERM_FORWARD)) {
	    return DONOTHING;
	}
	strncpy(buf, direct, sizeof(buf));
	if ((p = strrchr(buf, '/')) != NULL)
	    *p = '\0';
	clear();
	switch (doforward(buf, fileinfo, 1)) {
	  case 0:  
                   prints("�峹��H����!\n");
/* comment out by jjyang for direct mail delivery */
		   sprintf(genbuf, "forwarded file to %s", currentuser.email);
		   report(genbuf);
/* comment out by jjyang for direct mail delivery */

		   break;
	  case -1: prints("Forward failed: system error.\n");
		   break;
	  case -2: prints("Forward failed: missing or invalid address.\n");
	}
	pressreturn();
	clear();
	return FULLUPDATE;
}

#endif

int
mail_del_range(ent, fileinfo, direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
    return(del_range(ent, fileinfo, direct));
}

int
mail_mark(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
	if (fileinfo->accessed[0] & FILE_MARKED)
	   fileinfo->accessed[0] &= ~FILE_MARKED;
	else fileinfo->accessed[0] |= FILE_MARKED;
	substitute_record(currmaildir, fileinfo, sizeof(*fileinfo),ent) ;
	return(PARTUPDATE);	
}


int
mail_skip( ent, fileinfo, direct )
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    fileinfo->accessed[0] |= FILE_READ;
    substitute_record(currmaildir, fileinfo, sizeof(*fileinfo),ent) ;
    return GOTO_NEXT;
}

int
mailreadhelp()
{
	ansimore("etc/mailreadhelp",YEA);
	clear();
	return FULLUPDATE;
}

struct one_key  mail_comms[] = {
	'd',        mail_del,
	'D',	    mail_del_range,
	'r',        mail_read,
	'R',        mail_reply,
	'm',	    mail_mark,
	'K',	    mail_skip,
#ifdef INTERNET_EMAIL
	'F',	    mail_forward,
	'U',	    mail_uforward,
#endif
	'h',        mailreadhelp,
	Ctrl('J'),  mailreadhelp,
	'\0',       NULL
} ;

int
m_read()
{
    in_mail = YEA;
    i_read( RMAIL, currmaildir,mailtitle,maildoent,&mail_comms[0]) ;
    in_mail = NA;
    return 0 ;
}

#ifdef INTERNET_EMAIL

#include <netdb.h>
#include <pwd.h>
#include <time.h>
#define BBSMAILDIR "/usr/spool/mqueue"
extern char BoardName[];

int
invalidaddr(addr)
char *addr;
{
	if (*addr == '\0') return 1;   /* blank */
	while (*addr) {
	    if (!isalnum(*addr) && strchr("[].%!@:-_", *addr) == NULL)
		return 1;
	    addr++;
	}
	return 0;
}

void
spacestozeros(s)
char *s;
{
	while (*s) {
	    if (*s == ' ') *s = '0';
	    s++;
	}
}

int
getqsuffix(s)
char *s;
{
	struct stat stbuf;
	char qbuf[STRLEN], dbuf[STRLEN];
	char c1 = 'A', c2 = 'A';
	int pos = strlen(BBSMAILDIR) + 3;
	sprintf(dbuf, "%s/dfAA%5d", BBSMAILDIR, getpid());
	sprintf(qbuf, "%s/qfAA%5d", BBSMAILDIR, getpid());
	spacestozeros(dbuf);
	spacestozeros(qbuf);
	while (1) {
	    if (stat(dbuf, &stbuf) && stat(qbuf, &stbuf)) break;
	    if (c2 == 'Z') {
		c2 = 'A';
		if (c1 == 'Z') return -1;
		else c1++;
		dbuf[pos] = c1;
		qbuf[pos] = c1;
	    }
	    else c2++;
	    dbuf[pos+1] = c2;
	    qbuf[pos+1] = c2;	    	    
	}
	strcpy(s, &(qbuf[pos]));
	return 0;
}

void
convert_tz(local, gmt, buf)
int gmt, local;
char *buf;
{
	local -= gmt;
	if (local < -11) local += 24;
	else if (local > 12) local -= 24;
	sprintf(buf, " %4d", abs(local * 100));
	spacestozeros(buf);
	if (local < 0) buf[0] = '-';
	else if (local > 0) buf[0] = '+';
	else buf[0] = '\0';	
}

#if 0
int
createqf(title, qsuffix)
char *title, *qsuffix;
{
	static int configured = 0;
        static char myhostname[STRLEN];
        static char myusername[20];
        char mytime[STRLEN];
        char idtime[STRLEN];
	char qfname[STRLEN];
	char t_offset[6];
	FILE *qfp;
        time_t timenow;
	int savehour;
	struct tm *gtime, *ltime;
        struct hostent *hbuf;
        struct passwd *pbuf;

	if (!configured) {
            /* get host name */
            gethostname(myhostname, STRLEN);
            hbuf = gethostbyname(myhostname);
            if (hbuf) strncpy(myhostname, hbuf->h_name, STRLEN);

            /* get bbs uident */
            pbuf = getpwuid(getuid());
            if (pbuf) strncpy(myusername, pbuf->pw_name, 20);
	    if (hbuf && pbuf) configured = 1;
	    else return -1;
	}

	/* get file name */
	sprintf(qfname, "%s/qf%s", BBSMAILDIR, qsuffix);
	if ((qfp = fopen(qfname, "w")) == NULL) return -1;
	
        /* get time */
        time(&timenow);
	ltime = localtime(&timenow);
#ifdef SYSV
	ascftime(mytime, "%a, %d %b %Y %T ", ltime);
#else
        strftime(mytime, sizeof(mytime), "%a, %d %b %Y %T ", ltime);
#endif
	savehour = ltime->tm_hour;
	gtime = gmtime(&timenow);
        strftime(idtime, sizeof(idtime), "%Y%m%d%y%H%M", gtime); 
	convert_tz(savehour, gtime->tm_hour, t_offset);
	strcat(mytime, t_offset);
        fprintf(qfp, "P1000\nT%lu\nDdf%s\nS%s\nR%s\n", timenow, qsuffix,
                myusername, currentuser.email);
#ifdef ERRORS_TO
	fprintf(qfp, "E%s\n", ERRORS_TO);
#endif
	/* do those headers! */
        fprintf(qfp, "HReceived: by %s (%s)\n\tid %s; %s\n",
                myhostname, VERSION_ID, qsuffix, mytime);
	fprintf(qfp, "HReturn-Path: <%s@%s>\n", myusername, myhostname);
        fprintf(qfp, "HDate: %s\n", mytime);
        fprintf(qfp, "HMessage-Id: <%s.%s@%s>\n", idtime, qsuffix,
                myhostname);
        fprintf(qfp, "HFrom: %s@%s (%s in NCTU CSIE BBS)\n", myusername, myhostname, currentuser.userid);
        fprintf(qfp, "HSubject: %s (fwd)\n", title);
        fprintf(qfp, "HTo: %s\n", currentuser.email);
	fprintf(qfp, "HX-Forwarded-By: %s (%s)\n", currentuser.userid,
#ifdef REALNAME
		currentuser.realname);
#else
		currentuser.username);
#endif
	fprintf(qfp, "HX-Disclaimer: %s �糧�H���e�����t�d�C\n", BoardName);
	fclose(qfp);
	return 0;
}
#endif

int
bbs_sendmail(fname, title, receiver)
char *fname, *title, *receiver;
{
    static int configured = 0;
    static char myhostname[STRLEN];
    static char myusername[20];
    struct hostent *hbuf;
    struct passwd *pbuf;

    FILE *fin, *fout;


    if (!configured) {
            /* get host name */
            gethostname(myhostname, STRLEN);
            hbuf = gethostbyname(myhostname);
            if (hbuf) strncpy(myhostname, hbuf->h_name, STRLEN);

            /* get bbs uident */
            pbuf = getpwuid(getuid());
            if (pbuf) strncpy(myusername, pbuf->pw_name, 20);
            if (hbuf && pbuf) configured = 1;
            else return -1;
    }

    sprintf( genbuf, "/usr/sbin/sendmail -f %s.bbs@%s %s ", 
        currentuser.userid, email_domain(), receiver );
    fout = popen( genbuf, "w" );
    fin  = fopen( fname, "r" );
    if (fin == NULL || fout == NULL) return -1;
    
#ifdef INTERNET_PRIVATE_EMAIL
    fprintf( fout, "Reply-To: %s.bbs@%s\n", currentuser.userid, email_domain());
    fprintf( fout, "From: %s.bbs@%s\n", currentuser.userid, email_domain() ); 
#else
    fprintf( fout, "From: %s@%s (%s)\n", 
        myusername, myhostname, get_bbs_english_name()); 
#endif
    fprintf( fout, "To: %s\n", receiver);
    fprintf( fout, "Subject: %s\n", title);
    fprintf( fout, "X-Forwarded-By: %s (%s)\n", 
        currentuser.userid, 
#ifdef REALNAME
	currentuser.realname);
#else
	currentuser.username);
#endif

    fprintf(fout, "X-Disclaimer: %s �糧�H���e�����t�d�C\n", BoardName);
    fprintf(fout, "Precedence: junk\n"); 
    fprintf(fout, "\n");

    while (fgets( genbuf, 255, fin ) != NULL ) {
        if (genbuf[0] == '.' && genbuf[ 1 ] == '\n')
            fputs( ". \n", fout );
        else fputs( genbuf, fout );
    }
   
    fprintf(fout, ".\n");
    
    fclose( fin );
    pclose( fout );
    return 0;
}

int
doforward(direct, fh,mode)
char *direct;
struct shortfile *fh;
int mode;
{
    static char	address[ STRLEN ];
    char	fname[STRLEN];
    char	receiver[STRLEN];
    int		return_no;
    char	tmp_buf[200];

    clear();
    if( address[0] == '\0' ) {
	strncpy( address, currentuser.email, STRLEN );
    }
    prints("�Ъ����� Enter �����A�������ܪ��a�}, �Ϊ̿�J��L�a�}\n"); 
    prints("��H����H�� [%s]\n", address );

    getdata(2, 0, "==> ", receiver, STRLEN, DOECHO, NULL);

    if( receiver[0] == '\0' ) {
	sprintf( genbuf, "�T�w�N�峹�H�� %s ��? (Y/N) [Y]: ", address );
	getdata( 2, 0, genbuf, receiver, STRLEN, DOECHO, NULL );
	if( receiver[0] == 'n' || receiver[0] == 'N' )
	    return 1;
	strncpy( receiver, address, STRLEN );
    } else {
	strncpy( address, receiver, STRLEN );
    }
    if (invalidaddr(receiver)) return -2;

    prints("��H�H�� %s, �еy��....\n", receiver);
    if(strchr(address,';')) {
    prints("\n���~�� address");
    return 1;
    }
    refresh();

    if ( mode == 0 )
	sprintf(fname, "%s/%s", direct, fh->filename);
    else if ( mode == 1) {
	sprintf(fname, "/tmp/file.uu%05d", getpid() );
	sprintf( tmp_buf, "uuencode %s/%s csie.bbs.%05d > %s",
 			direct, fh->filename, getpid(), fname ); 
	system( tmp_buf );
    }
    return_no = bbs_sendmail(fname, fh->title, receiver);

    if ( mode == 1 ) {
	sprintf( tmp_buf, "/bin/rm -r -f %s", fname );
	system( tmp_buf );
    }
    return ( return_no );	

#if 0 
    {
	char	dfname[STRLEN];

	/* create data file */
	if (getqsuffix(qsuffix) == -1) return -1;
	sprintf(fname, "%s/%s", direct, fh->filename);
	sprintf(dfname, "%s/df%s", BBSMAILDIR, qsuffix);
	if (link(fname, dfname) != 0) return -1;
	return(createqf(fh->title, qsuffix));
    }
#endif
}

#endif


int
chkomail(userid)
{
    long lasttime = 0;
    int ismail = 0 ;
    struct fileheader fh ;
    struct stat st ;
    int fd ;
    register int i, offset ;
    register long numfiles ;
    unsigned char ch ;
    char maildir[ STRLEN ] ;

    sprintf(maildir,"mail/%s/%s",userid, DOT_DIR) ;

    offset = (int)((char *)&(fh.accessed[0]) - (char *)&(fh)) ;
    if((fd = open(maildir,O_RDONLY)) < 0)
       return (ismail = 0) ; 
    fstat(fd,&st) ;
    if(lasttime >= st.st_mtime) {
        close(fd) ;
       return ismail ; 
    }
    lasttime = st.st_mtime ;
    numfiles = st.st_size ;
    numfiles = numfiles/sizeof(fh) ;
    if(numfiles <= 0) {
      close(fd) ;
       return (ismail = 0) ; 
    }
    lseek(fd,(off_t)offset,SEEK_SET) ;
    for(i = 0 ; i < numfiles ; i++,lseek(fd,(off_t)offset+i*sizeof(fh),SEEK_SET)) {
        read(fd,&ch,1) ;
        if(!(ch & FILE_READ)) {
            close(fd) ;
            return(ismail = 1) ;
        }
    }
    close(fd) ;
    return(ismail = 0) ;
}


int
mail_file(tmpfile,userid,title)
char tmpfile[STRLEN],userid[STRLEN],title[STRLEN];
{
      FILE   *xptr;
      struct fileheader newmessage ;
      struct stat st ;
      char fname[STRLEN],filepath[STRLEN],*ip;
      int fp;

    memset(&newmessage, 0,sizeof(newmessage)) ;
#if defined(MAIL_REALNAMES)
    sprintf(genbuf,"%s (%s)",currentuser.userid,currentuser.realname) ;
#else
    sprintf(genbuf,"%s (%s)",currentuser.userid,currentuser.username) ;
#endif
    strncpy(newmessage.owner,genbuf,STRLEN) ;

    strncpy(newmessage.title,title,STRLEN) ;

    strncpy(save_title,newmessage.title,STRLEN) ;

      sprintf(filepath,"mail/%s",userid) ;
      if(stat(filepath,&st) == -1) {
        if(mkdir(filepath,0755) == -1) 
            return -1 ;
      } else {  
        if(!(st.st_mode & S_IFDIR))
            return -1 ;
      }
      sprintf(fname,"M.%d.A", time(NULL)) ;
      sprintf(filepath,"mail/%s/%s",userid,fname) ;
      ip = strrchr(fname,'A') ;
      while((fp = open(filepath,O_CREAT|O_EXCL|O_WRONLY,0644)) == -1) {
        if(*ip == 'Z')
            ip++,*ip = 'A', *(ip + 1) = '\0' ;
        else
            (*ip)++ ;
        sprintf(filepath,"mail/%s/%s",userid,fname) ;
      }
      close(fp) ;
      strcpy(newmessage.filename,fname) ;
      strncpy(save_filename,fname,4096) ;
      sprintf(filepath,"mail/%s/%s",userid,fname) ;

      if(xptr = fopen(filepath, "w")){
         b_suckinfile(xptr, tmpfile);
         fclose(xptr);
         sprintf(genbuf,"mail/%s/%s",userid, DOT_DIR) ;
         if(append_record(genbuf,&newmessage,sizeof(newmessage)) == -1)
            return -1 ;
         sprintf(genbuf, "mailed %s ", userid);
         report(genbuf);
       }
    return 0 ;
}

int
bbsreg_sendmail(fname, title, receiver)
char *fname, *title, *receiver;
{
    static int configured = 0;
    static char myhostname[STRLEN];
    static char myusername[20];
    struct hostent *hbuf;
    struct passwd *pbuf;

    FILE *fin, *fout;


    if (!configured) {
            /* get host name */
            gethostname(myhostname, STRLEN);
            hbuf = gethostbyname(myhostname);
            if (hbuf) strncpy(myhostname, hbuf->h_name, STRLEN);

            /* get bbs uident */
            pbuf = getpwuid(getuid());
            if (pbuf) strncpy(myusername, pbuf->pw_name, 20);
            if (hbuf && pbuf) configured = 1;
            else return -1;
    }

    sprintf( genbuf, "/usr/sbin/sendmail -f %s.reg@%s %s ", 
        currentuser.userid, email_domain(), receiver );
    fout = popen( genbuf, "w" );
    fin  = fopen( fname, "r" );
    if (fin == NULL || fout == NULL) return -1;
    
    fprintf( fout, "Reply-To: %s.reg@%s\n", currentuser.userid, email_domain());
    fprintf( fout, "From: %s.reg@%s\n", currentuser.userid, email_domain() ); 
    fprintf( fout, "To: %s\n", receiver);
    fprintf( fout, "Subject: %s\n", title);
    fprintf( fout, "X-Forwarded-By: SYSOP");
    fprintf(fout, "\n");

    while (fgets( genbuf, 255, fin ) != NULL ) {
        if (genbuf[0] == '.' && genbuf[ 1 ] == '\n')
            fputs( ". \n", fout );
        else fputs( genbuf, fout );
    }
   
    fprintf(fout, ".\n");
    
    fclose( fin );
    pclose( fout );
    return 0;
}

int
m_gsend()
{
  
    FILE	*fp;
    char	ask[2];
    char	maillists[STRLEN];
    char	uident[10];
    char	title[STRLEN];
    char	tmpfile[STRLEN];
    char	buf[10];
    int		count=0;
    
    
    modify_user_mode( SMAIL );
    
    clear();
    sethomefile( maillists, currentuser.userid, "maillist" );
    count=listfriends(maillists);
    while(1){
       getdata(0,0,"(A)�W�[ (D)�R�� (C)�M���ثe�W�� (E)�s��H�� (Q)���? [A]�G ", ask,2,DOECHO,NULL,YEA);
       if( ask[0]=='e' && count!=0 )
            break;
       switch (ask[0]) {
          case 'a': case 'A': case '\0': case'\n':
          { 
             usercomplete("�Ш̦���J�ϥΪ̥N��(�u�� ENTER ������J): ",uident) ;
             if(!getuser(uident)) {
         	move(2,0);
         	prints("�o�ӨϥΪ̥N���O���~��.\n");
             } else if(seek_in_file(maillists,uident)){
		move(2,0);
		prints("�W�椤�w�����b��");
             } else {
                addtofile(maillists,uident);
                count++;
             }
             break;
          }
          case 'd': case'D':
          {
             namecomplete("�Ш̦���J�ϥΪ̥N��(�u�� ENTER ������J): ",uident) ;
             if(seek_in_file(maillists,uident)) {
                del_from_file(maillists,uident);
                count--;
             }
             break;
           }    
          case 'c': case 'C':
          {
             unlink(maillists);
             count=0;
             break;      
   	  }
          case 'q': case 'Q':
          {
            return 0 ;
          }
          default:
            break;
       }
       move(1,0);
       clrtobot();
       listfriends(maillists);
    }
    move(1,0);
    clrtobot();    
    in_mail = YEA;
    getdata(1,0,"Title: ",title,STRLEN,DOECHO,NULL) ;    
    strncpy(save_title,title,STRLEN);
    sprintf( tmpfile, "tmp/bbs-gsend-%05d", getpid() ); 
    if(dashf(tmpfile)) 
        unlink(tmpfile);

    if (vedit(tmpfile,YEA) == -1) {
        unlink(tmpfile );
        clear(); 
        return 0 ;
    }
    if (( fp = fopen(maillists, "r")) == NULL){
             return 0;
    }    
    while(fgets(buf,10,fp)!=NULL){
      if ( strtok( buf, " \n\r\t") != NULL)
          strcpy( uident, buf);
      getuser(uident);
      if((lookupuser.userlevel & PERM_LOGINOK) && (lookupuser.userlevel & PERM_UNUSE14))
   	    if(out_mail(tmpfile,title,lookupuser.termtype+16))
	        continue;
      mail_file(tmpfile,uident,title);
    }
    unlink(tmpfile);
   return 1;
}
        
