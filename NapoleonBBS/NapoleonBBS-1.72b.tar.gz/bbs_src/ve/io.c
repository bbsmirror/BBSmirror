/*
 *	io.c
 */




#include "bbs.h"
#ifdef AIX
#include <sys/select.h>
#endif

#define OBUFSIZE  (4096)
#define IBUFSIZE  (256)

#define INPUT_ACTIVE 0
#define INPUT_IDLE 1
#define M_INT	5
extern int dumb_term ;

char outbuf[OBUFSIZE] ;
int obufsize = 0 ;

char inbuf[IBUFSIZE] ;
int ibufsize = 0 ;
int icurrchar = 0 ;
int KEY_ESC_arg;


static int i_mode = INPUT_ACTIVE;


void
hit_alarm_clock()
{
  if (HAS_PERM(PERM_NOTIMEOUT))
    return;
  if (i_mode == INPUT_IDLE)
  {
    clear();
    fprintf(stderr, "�W�L���m�ɶ��IBooting...\n");
    kill(getpid(), SIGHUP);
  }
  i_mode = INPUT_IDLE;
  alarm(IDLE_TIMEOUT);
}



void
init_alarm()
{
    signal(SIGALRM,hit_alarm_clock) ;
    alarm(IDLE_TIMEOUT) ;
}


void
oflush()
{
    if(obufsize)
      write(1,outbuf,obufsize) ;
    obufsize = 0 ;
}

void
output(s,len)
char	*s;
int	len;
{
    /* Invalid if len >= OBUFSIZE */

    if(obufsize+len > OBUFSIZE) {  /* doin a oflush */
        write(1,outbuf,obufsize) ;
        obufsize = 0 ;
    }
    memcpy(outbuf+obufsize, s, len) ;
    obufsize+=len ;
}

void
ochar(c)
int	c;
{
    if(obufsize > OBUFSIZE-1) {  /* doin a oflush */
        write(1,outbuf,obufsize) ;
        obufsize = 0 ;
    }
    outbuf[obufsize++] = c ;
}

int i_newfd  = 0 ;
struct timeval i_to, *i_top = NULL ;
int (*flushf)() = NULL ;

void
add_io(fd,timeout)
int fd ;
int timeout ;
{
    i_newfd = fd ;
    if(timeout) {
        i_to.tv_sec = timeout ;
        i_to.tv_usec = 0 ;
        i_top = &i_to ;
    } else i_top = NULL ;
}

void
add_flush(flushfunc)
int (*flushfunc)() ;
{
    flushf = flushfunc ;
}

int
num_in_buf()
{
    return icurrchar - ibufsize ;
}

int
igetch()
{
  igetagain:
    if(ibufsize == icurrchar) {
        fd_set readfds ;
        struct timeval to ;
        int sr ;

        to.tv_sec = 0 ;
        to.tv_usec = 0 ;
        FD_ZERO(&readfds) ;
        FD_SET(0,&readfds) ;
        if(i_newfd)
          FD_SET(i_newfd,&readfds) ;
        if((sr = select(FD_SETSIZE,&readfds, NULL, NULL, &to)) <= 0) {
            if(flushf)
              (*flushf)() ;
            if(dumb_term)
              oflush() ;
            else
              refresh() ;
            FD_ZERO(&readfds) ;
            FD_SET(0,&readfds) ;
            if(i_newfd)
              FD_SET(i_newfd,&readfds) ;
            while((sr = select(FD_SETSIZE,&readfds, NULL, NULL, i_top)) <0) {
                if(errno == EINTR)
                  continue ;
                else {
                    perror("select") ;
                    fprintf(stderr,"abnormal select conditions\n") ;
                    return -1 ;
                }
            }
            if(sr == 0)
              return I_TIMEOUT ;
        }
        if(i_newfd && FD_ISSET(i_newfd,&readfds))
          return I_OTHERDATA ;
        while((ibufsize = read(0,inbuf,IBUFSIZE)) <= 0) {
            if(ibufsize == 0)
              longjmp(byebye,-1) ;
            if(ibufsize < 0 && errno != EINTR)
              longjmp(byebye,-1) ;
        }
        icurrchar = 0 ;
    }
    i_mode = INPUT_ACTIVE;
    switch(inbuf[icurrchar]) {
      case Ctrl('L'):
        redoscr() ;
        icurrchar++ ;
        goto igetagain ;
      default:
        break ;
    }
    return inbuf[icurrchar++] ;
}

int
igetkey()
{
    int  mode;
    int  ch, last;

    mode = last = 0;
    while( 1 ) {
	ch = igetch();
	if( mode == 0 ) {
	    if( ch == KEY_ESC ) mode = 1;
	    else  return ch;	/* Normal Key */
	} else if( mode == 1 ) {  /* Escape sequence */
	    if( ch == '[' || ch == 'O' )  mode = 2;
	    else if( ch == '1' || ch == '4' )  mode = 3;
	    else { KEY_ESC_arg=ch; return KEY_ESC; }
	} else if( mode == 2 ) {  /* Cursor key */
	    if( ch >= 'A' && ch <= 'D' )
		return KEY_UP + (ch - 'A');
	    else if( ch >= '1' && ch <= '6' )  mode = 3;
	    else  return ch;
	} else if( mode == 3 ) {  /* Ins Del Home End PgUp PgDn */
	    if( ch == '~' )
		return KEY_HOME + (last - '1');
	    else  return ch;
	}
	last = ch;
    }
}

int
getdata(line,col,prompt,buf,len,echo,complete)
int line,col ;
char *prompt, *buf ;
int len, echo ;
int (*complete)() ;
{
    int ch ;
    int clen = 0 ;
    int x,y ;
    extern unsigned char scr_cols ;

    showansi=1;
    if(prompt) {
        move(line,col) ;
        prints("%s",prompt) ;
    }
    if(dumb_term) {
        while((ch = igetkey()) != '\r') {
            if(ch == '\n')
              break ;
            if(ch == '\177' || ch == Ctrl('H')) {
                if(clen == 0) {
                    continue ;
                }
                clen-- ;
                if(echo) {
                    ochar(Ctrl('H')) ;
                    ochar(' ') ;
                    ochar(Ctrl('H')) ;
                }
                continue ;
            }
	    if(!isprint2(ch)) {
                continue ;
            }
            if(clen >= len-1) {
                continue ;
            }
            buf[clen++] = ch ;
            if(echo)
              ochar(ch) ;
        }
        buf[clen] = '\0' ;
        prints("\n") ;
        oflush() ;
        return clen ;
    }
    clrtoeol() ;
    getyx(&y,&x) ;
    while((ch = igetkey()) != '\r') {
        if(ch == '\n')
          break ;
        if(ch == '\177' || ch == Ctrl('H')) {
            if(clen == 0) {
                continue ;
            }
            clen-- ;
            if(echo) {
                move(y,x+clen) ;
                prints(" ") ;
                move(y,x+clen) ;
            }
            continue ;
        }
	if(!isprint2(ch)) {
            continue ;
        }
        if(x+clen >= scr_cols || clen >= len-1) {
            continue ;
        }
        buf[clen++] = ch ;
        if(echo)
          prints("%c",ch) ;
    }
    buf[clen] = '\0' ;
    if(echo)
      prints("\n") ;
    refresh() ;
    return clen ;
}


void 
top_show( prompt )
char	*prompt;
{
    if (editansi) { prints(ANSI_RESET); refresh(); }
    move(0,0) ;
    clrtoeol() ;
    standout() ;
    prints("%s", prompt) ;
    standend() ;
}

int
ask( prompt )
char *prompt;
{
    int		ch;

    top_show( prompt );
    ch = igetkey() ;
    move(0,0) ;
    clrtoeol() ;
    return( ch );
}


#define MORE_BUFSIZE	4096

char	more_buf[ MORE_BUFSIZE ];
int	more_size, more_num;



int
readln(fd,buf)
int fd ;
char *buf ;
{
    int len, bytes, in_esc, ch;

    len = bytes = in_esc = 0;
    while( 1 ) {
	if( more_num >= more_size ) { 
	    more_size = read( fd, more_buf, MORE_BUFSIZE );
	    if( more_size == 0 ) {
		break;
	    }
	    more_num = 0;
	}
	ch = more_buf[ more_num++ ];
	bytes++;
	if( ch == '\n' || len >= 79 || bytes>250) {
	    break;
	} else if( ch == '\t' ) {
	    do {
		len++, *buf++ = ' ';
	    } while( (len % 8) != 0 );
	} else if( ch == '\033' ) {
	    if( showansi )  *buf++ = ch;
	    in_esc = 1;
	} else if( in_esc ) {
	    if( showansi )  *buf++ = ch;
	    if( strchr( "[0123456789;,", ch ) == NULL ) {
		in_esc = 0;
	    }
	} else if( isprint2( ch ) ) {
	    len++, *buf++ = ch;
	}
    }
    *buf++ = ch;
    *buf = '\0';
    return bytes;
}

int
morekey()
{
    while( 1 ) {
	switch( egetch() ) {
	    case 'q':  case KEY_LEFT:  case EOF:
		return KEY_LEFT;
	    case ' ':  case KEY_RIGHT: 
	    case KEY_PGDN: case Ctrl('F'):
		return KEY_RIGHT;
	    case KEY_PGUP : case Ctrl('B'):
		return KEY_PGUP;
	    case '\r': case KEY_DOWN: case 'j':
		return KEY_DOWN;
	    case 'k' : case KEY_UP:
		return KEY_UP;
	    case 'h': case 'H': case '?':
		return 'H';
	    default:	;
	}
    }
}

int seek_nth_line(fd, no)
int fd, no;
{
   int	n_read, line_count, viewed;
   char *p, *end;

   lseek(fd, 0, SEEK_SET );
   line_count = viewed = 0;
   if ( no > 0 ) while ( 1 ) {
       n_read = read( fd, more_buf, MORE_BUFSIZE );
       p = more_buf; end = p + n_read;
       for ( ; p < end && line_count < no; p++) 
           if (*p == '\n') line_count++;
       if (line_count >= no) {
           viewed += ( p - more_buf ); 
           lseek(fd, viewed, SEEK_SET);
           break; 
       } else viewed += n_read;
   }  
    
   more_num = MORE_BUFSIZE + 1;  /* invalidate the readln()'s buffer */
   return viewed;
}



int
rawmore(filename,promptend)
char	*filename;
int	promptend;
{
    extern int	t_lines ;
    struct stat st ;
    int		fd, tsize;
    char	buf[ 256 ] ;
    int		i, ch, viewed, pos ;
    int 	numbytes ,timecolor=0;
    int		curr_row = 0;

    if( (fd = open(filename,O_RDONLY)) == -1 ) {
        return -1;
    }
    if( fstat( fd, &st ) ) {
        return -1;
    }
    tsize = st.st_size ;
    more_size = more_num = 0;
    clear() ;
    i = pos = viewed = 0 ;
    numbytes = readln(fd,buf) ;  curr_row++;
    while( numbytes ) {
	viewed += numbytes ;
       showansi=1;
       if (buf[0]=='>' || buf[0]==':')          /* �B�z�ި����� */
            prints("[32m%s[37m",buf);
        else {
        showansi=1;
        prints( "[37m%s", buf ) ;
        }
	i++ ;
	pos++ ;
	if(pos == t_lines) {
	    scroll() ;
	    pos-- ;
	}
	numbytes = readln(fd,buf) ; curr_row++;
	if( numbytes == 0 )
	    break ;
	if( i == t_lines -1 ) {
	    if( showansi ) {
		move( t_lines-1, 79 ) ;
		prints( "\033[37;40;0m\033[m" );
		refresh();
	    }
	    move( t_lines-1, 0 ) ;
	    showansi=1;
	    prints("[1;44;35m �٦��� (%d%%) [33m�x���� �� <q> �x��/��/PgUp/PgDn ���ʢx? ���U�����x [m",(viewed*100)/tsize);
	    ch = morekey();
	    move( t_lines-1, 0 );
	    clrtoeol();
	    refresh();
	    if( ch == KEY_LEFT ) {
		close( fd );
		return ch;
	    } else if( ch == KEY_RIGHT ) {
		i = 1;
	    } else if( ch == KEY_DOWN ) {
		i = t_lines-2 ;
	    } else if(ch == KEY_PGUP || ch == KEY_UP) {
		clear(); i = pos = 0;
		curr_row -= (ch == KEY_PGUP) ? (2 * t_lines - 2) : (t_lines + 1);
		if (curr_row < 0) { close( fd ); return ch; }
        	viewed = seek_nth_line(fd, curr_row);        
                numbytes = readln(fd,buf) ;  curr_row++;
	    } else if(ch == 'H') {
		ansimore("etc/morehelp",YEA);
		clear();
		i = pos = 0;
		curr_row -= (t_lines);
		if (curr_row < 0) curr_row = 0;
        	viewed = seek_nth_line(fd, curr_row);        
                numbytes = readln(fd,buf) ;  curr_row++;
            }
	}
    }

    close( fd ) ;
    if( promptend ) {
	pressanykey();
    }
    return 0 ;
}


int
more(filename,promptend)
char	*filename ;
int	promptend;
{
    return rawmore( filename, promptend );
}


int
ansimore(filename,promptend)
char	*filename ;
int	promptend;
{
    int	   ch;
    char   morebuf[30];

    showansi = 1;
    ch = rawmore( filename, promptend );
    refresh();
    return ch;
}


int
a_more(filename, promptend, begin, end, arc, what)
char *filename;      
char *what;
{
  extern int t_lines;
  struct stat st;
  int fd, tsize;
  char buf[256];
  int i, ch, viewed;
  int numbytes;

  if ((fd = open(filename, O_RDONLY)) == -1)
    return -1;

  if (fstat(fd, &st))
    return -1;

  tsize = st.st_size;
  viewed = more_size = more_num = 0;

  i=begin;

  if (arc) {
    char buf[256];
    move( begin-1, 0 ) ; clrtoeol();
    sprintf(buf,"=============================================================================");
    if (*what) {
	int len;
	len=strlen(what);
	strncpy(buf+20," [1;33;44m",11);
	strncpy(buf+31,what,len);
	strncpy(buf+31+len,"[0m ",5);
	strcat(buf,"===============");
    }
    showansi=1;
    prints(buf);
    move( end-1, 0 ) ; clrtoeol(); 
    prints("==============================================================================");
  }

  while (numbytes = readln(fd, buf))
  { 
    move(i,0); clrtoeol();
    showansi=1;
    prints("%s\n", buf);

    viewed += numbytes;
    i++;
  
    if (i == end - 1)
    {
      if (arc) {
        move( end-1, 0 ) ; clrtoeol(); 
        prints("==============================================================================");
      }
     presscontinue();
     i = begin;
    }
  }

  while(i < end-1) {
    move(i++,0);
    clrtoeol();
  } 
  if(fd!=-1){
  if (promptend)  
      pressanykey();
  }
 close(fd); 
  return 0;
}                             


/*add by tby for active_show adapted from games*/
movie(num)
int  num;
{
    static	char  buf[20][251];
    FILE	*fp;
    int 	i,j=0,bufleng;
    char	dirbuf[40];
    int		show_line;
    
     show_line=currentuser.address[STRLEN-6];
     sprintf(dirbuf,"0Announce/show/issue.%d",num);
     bufleng=strlen(dirbuf);
     dirbuf[bufleng]=EOS;
     
     if( (fp=fopen(dirbuf,"r"))!=NULL){
      for (i=0; i<show_line; i++) {
        if (fgets(buf[i],250,fp) == (char *) NULL) {
          buf[i][0]='\0';
        }
     
      }
    fclose(fp);
    }
    showansi=1;
    move(2,0);
    for (i=0; i<show_line; i++) {
    prints( buf[i][0] ? buf[i]:"[m\n");
    }
}



clearmenu()
{
  register i;
  int	show_line;
  
  show_line=currentuser.address[STRLEN-6];
  for (i=0; i<show_line; i++) {
    move(2+i,0);
    clrtoeol();
  }
    refresh(); 
}




void
active_board()
{
     char	*activebuf;
     int	alarcountmp;
     int	active_col;    

      
    if(uinfo.mode<6){
      clearmenu();
      if(currentuser.address[STRLEN-5]>1){
       do{
          alarcountmp=(rand()%currentuser.address[STRLEN-5]);
         } while(alarcountmp==currentuser.address[STRLEN-4]);
       currentuser.address[STRLEN-4]=alarcountmp;
       movie(alarcountmp);
       active_col=currentuser.address[STRLEN-1];
       move(1,active_col+10);
       refresh();
       signal(SIGALRM,active_board);
       alarm(8);
      }
      else if(currentuser.address[STRLEN-5]==1) movie(0); 
    }
}



showback(namebuf)
int	namebuf;
{
    static	char  buf[24][201];
    FILE	*fp;
    int 	i,j=0,dirlen;
    char	dirbuf[40];
    int	        show_line;

 
     show_line=currentuser.address[STRLEN-6];
     sprintf(dirbuf,"menu/menu.%d",namebuf);
     dirlen=strlen(dirbuf);
     dirbuf[dirlen+1]=EOS;
     j=22-show_line;
     if( (fp=fopen(dirbuf,"r"))!=NULL){
      for (i=0; i<j; i++) {
        if (fgets(buf[i],200,fp) == (char *) NULL) {
          buf[i][0]='\0';
        }
       }
     fclose(fp);
     showansi=1;
     move(show_line+2,0);
     for (i=0; i<j; i++) {
      prints( buf[i][0] ? buf[i]:"[m\n"); 
     }
    }
}
