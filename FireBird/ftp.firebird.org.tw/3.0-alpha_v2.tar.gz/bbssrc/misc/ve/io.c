/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "../../include/bbs.h"
#ifdef AIX
#include <sys/select.h>
#endif

#define OBUFSIZE  (4096)
#define IBUFSIZE  (256)

#define INPUT_ACTIVE 0
#define INPUT_IDLE 1

extern int dumb_term ;

char outbuf[OBUFSIZE] ;
int obufsize = 0 ;

char inbuf[IBUFSIZE] ;
int ibufsize = 0 ;
int icurrchar = 0 ;
int KEY_ESC_arg;

static int i_mode = INPUT_ACTIVE;

void
hit_alarm_clock()
{
    if (HAS_PERM(PERM_NOTIMEOUT))
        return;
    if(i_mode == INPUT_IDLE) {
        clear();
        fprintf(stderr,"Idle timeout exceeded! Booting...\n") ;
        kill(getpid(),SIGHUP) ;
    }
    i_mode = INPUT_IDLE ;
    alarm(IDLE_TIMEOUT) ;
}

void
init_alarm()
{
    signal(SIGALRM,hit_alarm_clock) ;
    alarm(IDLE_TIMEOUT) ;
}

void
oflush()
{
    if(obufsize)
      write(1,outbuf,obufsize) ;
    obufsize = 0 ;
}

void
output(s,len)
char    *s;
int     len;
{
    /* Invalid if len >= OBUFSIZE */

    if(obufsize+len > OBUFSIZE) {  /* doin a oflush */
        write(1,outbuf,obufsize) ;
        obufsize = 0 ;
    }
    memcpy(outbuf+obufsize, s, len) ;
    obufsize+=len ;
}

void
ochar(c)
int     c;
{
    if(obufsize > OBUFSIZE-1) {  /* doin a oflush */
        write(1,outbuf,obufsize) ;
        obufsize = 0 ;
    }
    outbuf[obufsize++] = c ;
}

int i_newfd  = 0 ;
struct timeval i_to, *i_top = NULL ;
int (*flushf)() = NULL ;

void
add_io(fd,timeout)
int fd ;
int timeout ;
{
    i_newfd = fd ;
    if(timeout) {
        i_to.tv_sec = timeout ;
        i_to.tv_usec = 0 ;
        i_top = &i_to ;
    } else i_top = NULL ;
}

void
add_flush(flushfunc)
int (*flushfunc)() ;
{
    flushf = flushfunc ;
}

int
num_in_buf()
{
    return icurrchar - ibufsize ;
}

int
igetch()
{
  igetagain:
    if(ibufsize == icurrchar) {
        fd_set readfds ;
        struct timeval to ;
        int sr ;

        to.tv_sec = 0 ;
        to.tv_usec = 0 ;
        FD_ZERO(&readfds) ;
        FD_SET(0,&readfds) ;
        if(i_newfd)
          FD_SET(i_newfd,&readfds) ;
        if((sr = select(FD_SETSIZE,&readfds, NULL, NULL, &to)) <= 0) {
            if(flushf)
              (*flushf)() ;
            if(dumb_term)
              oflush() ;
            else
              refresh() ;
            FD_ZERO(&readfds) ;
            FD_SET(0,&readfds) ;
            if(i_newfd)
              FD_SET(i_newfd,&readfds) ;
            while((sr = select(FD_SETSIZE,&readfds, NULL, NULL, i_top)) <0) {
                if(errno == EINTR)
                  continue ;
                else {
                    perror("select") ;
                    fprintf(stderr,"abnormal select conditions\n") ;
                    return -1 ;
                }
            }
            if(sr == 0)
              return I_TIMEOUT ;
        }
        if(i_newfd && FD_ISSET(i_newfd,&readfds))
          return I_OTHERDATA ;
        while((ibufsize = read(0,inbuf,IBUFSIZE)) <= 0) {
            if(ibufsize == 0)
              longjmp(byebye,-1) ;
            if(ibufsize < 0 && errno != EINTR)
              longjmp(byebye,-1) ;
        }
        icurrchar = 0 ;
    }
    i_mode = INPUT_ACTIVE;
    switch(inbuf[icurrchar]) {
      case Ctrl('L'):
        redoscr() ;
        icurrchar++ ;
        goto igetagain ;
      default:
        break ;
    }
    return inbuf[icurrchar++] ;
}

int
igetkey()
{
    int  mode;
    int  ch, last;

    mode = last = 0;
    while( 1 ) {
        ch = igetch();
        if( mode == 0 ) {
            if( ch == KEY_ESC ) mode = 1;
            else  return ch;    /* Normal Key */
        } else if( mode == 1 ) {  /* Escape sequence */
            if( ch == '[' || ch == 'O' )  mode = 2;
            else if( ch == '1' || ch == '4' )  mode = 3;
            else { KEY_ESC_arg=ch; return KEY_ESC; }
        } else if( mode == 2 ) {  /* Cursor key */
            if( ch >= 'A' && ch <= 'D' )
                return KEY_UP + (ch - 'A');
            else if( ch >= '1' && ch <= '6' )  mode = 3;
            else  return ch;
        } else if( mode == 3 ) {  /* Ins Del Home End PgUp PgDn */
            if( ch == '~' )
                return KEY_HOME + (last - '1');
            else  return ch;
        }
        last = ch;
    }
}

int
getdata2(line,col,prompt,buf,len,echo,complete)
int line,col ;
char *prompt, *buf ;
int len, echo ;
int (*complete)() ;
{
    int ch ;
    int clen = 0 ;
    int curr = 0 ;
    int x,y ;
    char    tmp[STRLEN];
    extern unsigned char scr_cols ;

    if(prompt) {
        move(line,col) ;
        prints("%s",prompt) ;
    }
    if(dumb_term) {
        while((ch = igetkey()) != '\r') {
            if(ch == '\n')
              break ;
            if(ch == '\177' || ch == Ctrl('H')) {
                if(clen == 0) {
                    continue ;
                }
                clen-- ;
                if(echo) {
                    ochar(Ctrl('H')) ;
                    ochar(' ') ;
                    ochar(Ctrl('H')) ;
                }
                continue ;
            }
            if(!isprint2(ch)) {
                continue ;
            }
            if(clen >= len-1) {
                continue ;
            }
            buf[clen++] = ch ;
            if(echo)
              ochar(ch) ;
        }
        buf[clen] = '\0' ;
        prints("\n") ;
        oflush() ;
        return clen ;
    }
    clrtoeol() ;
    getyx(&y,&x) ;
    while((ch = igetkey()) != '\r') {
        if(ch == '\n')
          break ;
        if(ch == '\177' || ch == Ctrl('H')) {
            if(clen == 0) {
                continue ;
            }
            clen-- ;
            if(echo) {
                move(y,x+clen) ;
                prints(" ") ;
                move(y,x+clen) ;
            }
            continue ;
        }
                if (ch == KEY_LEFT)
                {
                        if (curr == 0)
                        {
                                bell(1);
                                continue;
                        }
                        curr--;
                        move(y, x + curr);
                        continue;
                }
                if (ch == KEY_RIGHT)
                {
                        if (curr >= clen)
                        {
                                curr = clen;
                                bell(1);
                                continue;
                        }
                        curr++;
                        move(y, x + curr);
                        continue;
                }

        if(!isprint2(ch)) {
            continue ;
        }
        if(x+clen >= scr_cols || clen >= len-1) {
            continue ;
        }
                if (!buf[curr])
                {
                        buf[curr + 1] = '\0';
                        buf[curr] = ch;
                }
                else
                {
                        strncpy(tmp, &buf[curr], len);
                        buf[curr] = ch;
                        buf[curr + 1] = '\0';
                        strncat(buf, tmp, len - curr);
                }
        curr++;
        clen++;
                if (echo)
                {
                        move(y, x);
                        prints(NA, "%s", buf);
                        move(y, x + curr);
                }
                else
                        prints(NA, "*");
        
    }
    buf[clen] = '\0' ;
    if(echo)
      prints("\n") ;
    refresh() ;
    return clen ;
}

void 
top_show( prompt )
char    *prompt;
{
    if (editansi) { prints(ANSI_RESET); refresh(); }
    move(0,0) ;
    clrtoeol() ;
    standout() ;
    prints("%s", prompt) ;
    standend() ;
}

int
ask( prompt )
char *prompt;
{
    int         ch;

    top_show( prompt );
    ch = igetkey() ;
    move(0,0) ;
    clrtoeol() ;
    return( ch );
}

int     getdata(line, col, prompt, buf, len, echo)
int     line,   col,    len,    echo;
char    *prompt,        *buf;
{
        int     ch,     clen = 0,       curr = 0,
                x,      y;
        char    tmp[STRLEN];
        extern unsigned char scr_cols ;

/*       if (clearflag!=cflag)
           bzero(buf, sizeof(buf));*/
        move(line, col);
        if (prompt)
             prints("%s", prompt);
        y = line;
        x = col /*+ (prompt == NULL) ? 0 : strlen(prompt)*/;
        clen = 0 /*strlen(buf)*/;
        curr = clen/* = (clen > len) ? len : clen*/;
        buf[curr] = '\0';
/*        prints("%s", buf);*/

        if (dumb_term)
        {
                while ((ch = igetkey()) != '\r')
                {
                        if (ch == '\n')
                                break;
                        if (ch == '\177' || ch == Ctrl('H'))
                        {
                                if (clen == 0)
                                {
                                        continue;
                                }
                                clen--;
                                ochar(Ctrl('H'));
                                ochar(' ');
                                ochar(Ctrl('H'));
                                continue;
                        }
                        if (!isprint2(ch))
                        {
                                continue;
                        }
                        if (clen >= len-1)
                        {
                                continue;
                        }
                        buf[clen++] = ch;
                        if (echo)
                                ochar(ch);
                        else
                                ochar('.');
                }
                buf[clen] = '\0';
                prints("\n");
                oflush();
                return clen;
        }
        clrtoeol();
        getyx(&y,&x) ;
        while ((ch = igetkey()) != '\r')
        {
                if (ch == '\n')
                        break;
                if (ch == '\177' || ch == Ctrl('H'))
                {
                        if (curr == 0)
                        {
                                continue;
                        }
                        strcpy(tmp, &buf[curr]);
                        buf[--curr] = '\0';
                        (void)strcat(buf, tmp);
                        clen--;
                        move(y, x);
                        prints("%s", buf);
                        clrtoeol();
                        move(y, x + curr);
                        continue;
                }
                if (ch == KEY_DEL)
                {
                        if (curr >= clen)
                        {
                                curr = clen;
                                continue;
                        }
                        strcpy(tmp, &buf[curr+1]);
                        buf[curr] = '\0';
                        (void)strcat(buf, tmp);
                        clen--;
                        move(y, x);
                        prints("%s", buf);
                        clrtoeol();
                        move(y, x + curr);
                        continue;
                }
                if (ch == KEY_LEFT)
                {
                        if (curr == 0)
                        {
                                continue;
                        }
                        curr--;
                        move(y, x + curr);
                        continue;
                }
                if (ch == KEY_RIGHT)
                {
                        if (curr >= clen)
                        {
                                curr = clen;
                                continue;
                        }
                        curr++;
                        move(y, x + curr);
                        continue;
                }
                if (!isprint2(ch))
                {
                        continue;
                }

                if (x+clen >= scr_cols || clen >= len-1)
                {
                        continue;
                }

                if (!buf[curr])
                {
                        buf[curr + 1] = '\0';
                        buf[curr] = ch;
                }
                else
                {
                        strncpy(tmp, &buf[curr], len);
                        buf[curr] = ch;
                        buf[curr + 1] = '\0';
                        strncat(buf, tmp, len - curr);
                }
                curr++;
                clen++;
                if (echo)
                {
                        move(y, x);
                        prints("%s", buf);
                        move(y, x + curr);
                }
                else
                        prints(".");
        }
        buf[clen] = '\0';
        prints("\n");
        refresh();
        return clen;
}
