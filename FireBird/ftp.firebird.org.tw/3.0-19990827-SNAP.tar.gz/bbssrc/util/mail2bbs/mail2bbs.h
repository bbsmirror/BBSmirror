/* for shm antispam of rexchen */
/* $Id: mail2bbs.h,v 1.2 1999/06/05 08:41:13 edwardc Exp $ */

#ifndef _MAIL2BBS_H_
#define _MAIL2BBS_H_

//#define MAIL_LIST_MODULE
//#define MAILLIST_RECEIVER	"_mail-list_"

#define RULE  3    /* rule 2 .... 10 (����ĳ�W�L 10 ) */

struct SPAM
{
	int spam_a;
	int spam_b;
	int spam_c;
	int spam_times;
};
                                
struct SPAM_MAIL
{
	struct SPAM mail_flag[512];
	time_t update_time;
};
                                                
#endif/*_MAIL2BBS_H_*/
