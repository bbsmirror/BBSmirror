
#include <stdio.h>

#if defined(LINUX_ver)
#include <ncurses.h>
#elif defined(FreeBSD_ver)
#include <ncurses.h>
#elif defined(ULTRIX_ver)
#include <cursesX.h>
#else
#include <curses.h>
#endif


int
main(void)
{

	int             key;

	initscr();
	cbreak();
	nonl();
	noecho();
	keypad(stdscr, TRUE);
	refresh();

	printw("Press 'q' to quit .....\n");

	while ((key = getch()) != (int) 'q')
		printw("[%.3d='%c'] ", key, (char) key);

	endwin();
}
