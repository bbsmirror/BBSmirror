
#include <signal.h>

#if defined(ULTRIX_ver)
#include <sys/types.h>
#endif

#include <sys/stat.h>
#include <time.h>

#include "config.h"

void
Clock(int ignore)
{
	extern char     mailbox[35];
	extern int      mailbox_size;
	struct stat     now_status;
	extern char    *helpbar[];
	extern int      showbar;
	long int        now;
	struct tm      *tmstruct;
	char            buffer[25];

	time(&now);
	tmstruct = localtime(&now);

	if ((stat(mailbox, &now_status) >= 0)
	    && (mailbox_size < now_status.st_size))
		ansi_print_xy(LINES - 1, 69, "1;31", "\033[5m\007�z���s�H��");

	sprintf(buffer, "19%02d/%02d/%02d  %.2d:%.2d\000",
		tmstruct->tm_year, tmstruct->tm_mon + 1, tmstruct->tm_mday, tmstruct->tm_hour, tmstruct->tm_min);

	ansi_print_xy(0, COLS - strlen(buffer), "1;33", buffer);

	if ((tmstruct->tm_min == 0) && (tmstruct->tm_sec < 15))
		ansi_print_xy(LINES - 1, 69, "1;31", "\033[5m\007  ���I����");
	else if (tmstruct->tm_min == 1)
		ansi_print_xy(LINES - 1, 69, "1;31", "          ");
	HelpBar("1;36", helpbar[showbar = (++showbar) % 3]);
	refresh();
	signal(SIGALRM, Clock);
	alarm(10);

}
