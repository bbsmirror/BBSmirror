/*
 * queue.h: header for queue.c
 *
 * copyright(c) 1994 matthew green
 *
 * See the copyright file, or do a help ircii copyright 
 *
 * @(#)$Id: queue.h,v 1.2 1995/01/02 13:31:53 mrg stable $
 */

#ifndef __queue_h
# define __queue_h

extern	void	queuecmd _((char *, char *, char *));

#endif /* __queue_h */
