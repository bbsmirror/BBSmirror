/*
 * mail.h: header for mail.c
 *
 * Written By Michael Sandrof
 *
 * Copyright(c) 1990 
 *
 * See the COPYRIGHT file, or do a HELP IRCII COPYRIGHT 
 *
 * @(#)$Id: mail.h,v 1.4 1994/07/02 02:38:10 mrg stable $
 */

#ifndef _MAIL_H_
#define _MAIL_H_

extern	char	*check_mail();
extern	int	check_mail_status();

#endif /* _MAIL_H_ */
