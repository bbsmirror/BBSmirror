/*
 * crypt.h: header for crypt.c 
 *
 * Written By Michael Sandrof
 *
 * Copyright(c) 1990 
 *
 * See the COPYRIGHT file, or do a HELP IRCII COPYRIGHT 
 *
 * @(#)$Id: crypt.h,v 1.6 1995/01/02 13:31:23 mrg stable $
 */

#ifndef _CRYPT_H_
#define _CRYPT_H_

extern	char	*crypt_msg();
extern	void	encrypt_cmd _((char *, char *, char *));
extern	char	*is_crypted();

#define CRYPT_HEADER ""
#define CRYPT_HEADER_LEN 5

#endif /* _CRYPT_H_ */
