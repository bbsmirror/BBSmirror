/*
 * help.h: header for help.c
 *
 * copyright(c) 1994 matthew green
 *
 * See the copyright file, or do a help ircii copyright 
 *
 * @(#)$Id: help.h,v 1.2 1995/01/02 13:31:30 mrg stable $
 */

#ifndef __help_h
# define __help_h

extern	void	help _((char *, char *, char *));

#endif /* __help_h */
