/*
 * parse.h
 *
 * written by matthew green
 * copyright (c) 1993
 *
 * @(#)$Id: parse.h,v 1.5 1995/01/02 13:31:51 mrg stable $
 */

#ifndef __parse_h_
# define __parse_h_

extern	char	*PasteArgs();
extern	void	parse_server _((char *));

extern	char	*FromUserHost;

extern	int	doing_privmsg;

#endif /* __parse_h_ */
