/*
 * flood.h: header file for flood.c
 *
 * @(#)$Id: flood.h,v 1.4 1994/07/02 02:38:10 mrg stable $
 */

#ifndef _FLOOD_H_
#define _FLOOD_H_

extern	int	check_flooding();

#define MSG_FLOOD 0
#define PUBLIC_FLOOD 1
#define NOTICE_FLOOD 2
#define WALL_FLOOD 3
#define WALLOP_FLOOD 4
#define NUMBER_OF_FLOODS 5

#endif /* _FLOOD_H_ */
