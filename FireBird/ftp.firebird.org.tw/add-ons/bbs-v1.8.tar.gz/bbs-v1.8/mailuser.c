
#include <stdio.h>
#include "config.h"

void Mail2user(char c)
{
    extern struct BBS bbs[BBS_Max];
    extern char Mailer[35];

    char id[30];
    char command[120];
    char subject[60];
    char *edit_name;
    time_t b_time;

    b_time = time(NULL);

    umask(077);

    ansi_clear;

    ansi_cprint(LIGHTRED, "�`�N: �ϥΥ��\\��e�Х��T�w %s BBS ���䴩 Internet Mail to User\n\n", bbs[c].name);

    ansi_cprint(LIGHTGREEN, "\n�п�J�z�n�H�� %s BBS �������@��ϥΪ�\n", bbs[c].name);

    do {
	ansi_cprint(LIGHTCYAN, "\nMail to: ");
	ansi_flush();
	fgets(id, 29, stdin);
	id[strlen(id) - 1] = '\0';
	ansi_cprint(YELLOW, "\n�T�w�H�� ");
	ansi_cprint(LIGHTMAGENTA, id);
	ansi_cprint(YELLOW, " ��? [Y] ");
	ansi_flush();
	fgets(command, 20, stdin);

    } while ((command[0] != '\n') && (toupper(command[0]) != 'Y'));

    ansi_cprint(WHITE, "\n�H�󪺼��D�O: ");
    ansi_flush();
    fgets(subject, 59, stdin);
    subject[strlen(subject) - 1] = '\0';
    edit_name = Edit();

    /* Mail post */
    if (!isdigit(bbs[c].hostname[0]))
	sprintf(command, "%s -s \"%s\" %s.bbs@%s < %s", Mailer, subject, id, bbs[c].hostname, edit_name);
    else
	sprintf(command, "%s -s \"%s\" %s.bbs@[%s]. < %s", Mailer, subject, id, bbs[c].hostname, edit_name);

    system(command);

    Delete();

    sprintf(command, "%s/%s", id, subject);

    log(LOG_MAILUSER, b_time, bbs[c].hostname, command);
}
