/*
 * hyindex.c  - Index Hytelnet (or other HYPERRES) database.
 *
 *      Reads one or more text files and outputs the filename & title
 *      for each, where the title is defined as the first line of
 *      plain text.  Output format is:
 *
 *                <filename> Title
 *
 *      To create an index, run this from your Hytelnet directory.
 *	The index is sent to stdout, which should be redirected
 *	into a file named 'index' in the main Hytelnet data directory.
 *
 * CHANGE LOG
 *
 *	Aug 1993 - support for multi-line titles
 *	Jul 1993 - fixed argument parsing bug
 *
 * Written by Earl Fogel, November 1991
 */
#include <stdio.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <ftw.h>

main(argc, argv)
int argc;
char *argv[];
{
    char *path = ".";
    int fn();

    if (argc > 2 || (argc==2 && *(argv[1])=='-')) {
        printf("Usage: hyindex [directory]\n");
	exit();
    }
    if (argc==2)
	path = argv[1];

     ftw (path, fn ,2);
}

fn(fname, statbuf, flag)
char *fname;
struct stat *statbuf;
int  flag;
{
    int  c, i, n;
    int  spaces;
    FILE *fp;
    char *strrchr();

    if (flag == FTW_F) {
	if ( (fp=fopen(fname,"r")) != NULL) {
	    while ((c=getc(fp)) != EOF && ! isalnum(c))
		; /* NO BODY */	/* find first text character */

	    if (strrchr(fname,'/') != NULL)
		fname = strrchr(fname,'/') + 1;

	    printf("<%s> ", fname);
	    n = strlen(fname) + 3;
	    while (n < 12) {
		putchar(' ');
		n++;
	    }
	    while (c != EOF && c != '\n' && c != '\r' && n++ < 160) {
		if (isprint(c))
		    putchar(c);
		c = getc(fp);
		if (c == '\n') {  /* multi-line title? */
		    spaces = 0;
		    while ((c = getc(fp)) == ' ' || c == '\t')
			spaces++;
		    if (spaces && isalnum(c)) {
			putchar(',');
			putchar(' ');
		    } else {
			c = '\n';
		    }
		}
	    }
	    putchar('\n');
	    fclose(fp);
	} else {
	    fprintf(stderr, "hyindex: can't open %s\n", fname);
	}
    }
    return(0);
}
