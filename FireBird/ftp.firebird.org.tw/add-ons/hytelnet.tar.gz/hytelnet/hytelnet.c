char *Version =
"     Hytelnet software 3.2 for Unix, VMS and MS-DOS  (c) 1994 Earl Fogel      ";
/*
 * hytelnet.c - a text-based hypertext browser and menuing system.
 *
 *      This is a general hypertext browser, packaged with
 *      Peter Scott's database of Internet-accessible telnet sites.
 *      Hytelnet lists libraries, Campus-Wide Information Systems,
 *      Freenets and more.  Runs on PC, Unix and VMS systems.
 *
 *      Peter's version uses HYPERRES (an IBM PC hypertext browser).
 *      This program uses the same file format as HYPERRES, and it is
 *      possible to plug-and-play other databases as well.
 *
 *      The database consists of many more-or-less plain text files,
 *      all in a single directory.  Any text in angle brackets (eg <HELP>)
 *      is a link.  Selecting it moves you to the named file.  Filenames
 *      are mapped to lower case (so <HELP> refers to the file 'help').
 *
 *      The program notices telnet, tn3270, ftp and rlogin commands
 *      embedded in the text files, and will execute them for the user.
 *
 * NOTES
 *	This is the third release of the Unix/VMS version of Hytelnet,
 *      and the first release of this software for MS-DOS.
 *
 *      Many people have contributed suggestions, bug-fixes and enhancements
 *      to this program. Thanks to:
 *	  Michael A. Crowley <mcrowley@mtholyoke.edu>
 *        Tim Weaver <tweaver@kzoo.edu>
 *        Andy Harper <UDAA055@OAK.CC.KCL.AC.UK>
 *        David A. Curry <davy@ecn.purdue.edu>
 *        Jeff Dean <jeff@igc.org>
 *        Darryl Friesen <darryl.friesen@usask.ca>
 *
 * BUGS
 *    - Should do resize if term is resizable (eg. xterm)
 *    - Ignores the page & line numbers in more complex HYPERRES links
 *    - Should distinguish between the escape key and escape sequences
 *      (ie. cursor keys).
 *    - Should be able to handle more than one database.
 *
 * TROUBLESHOOTING
 *
 *    If "make" fails, you may need to add some of the following defines:
 *       #define strchr index
 *       #define strrchr rindex
 *       #define cbreak crmode
 *       #define cuserid(x) getlogin()
 *
 *    If your compiler complains about "utmp",
 *    remove the "#   define UTMP_FNAME" line below.
 *
 * AUTHOR
 *      Earl Fogel, Computing Services, University of Saskatchewan
 *	fogel@sask.usask.ca
 *
 * CHANGE LOG
 *	Sep 1994 - fix to runaway hytelnet process/SIGHUP bug (at last!)
 *      Oct 1993 - accepts long (up to 80 char) internet addresses
 *                 and addresses containing underscores
 *               - check for vt400 series terminals on VMS
 *               - pc version works with either pkunzip or unzip
 *      Sep 1993 - better MS-DOS support, and better unzipping
 *               - added hostname exception list (Unix only)
 *      Aug 1993 - Can unzip database on the fly
 *               - new command synonyms: 'u' for left arrow, '/' for search
 *      Jul 1993 - can specify a directory on the command line
 *      Jun 1993 - added 'i' command to search the title index
 *               - emacs cursor keys work now
 *               - works on the PC
 *               - better handling of user-specified terminal types
 *               - hostnames without '.'s must be in local domain
 *      May 1993 - up/down arrows wrap at start/end of file
 *      Apr 1993 - no longer uses PASTHRU on VMS
 *               - added finger command
 *      Mar 1993 - added generic command execution <!command>
 *               - can display nice names in place of filenames & commands
 *                 Eg. <HELP Help Me> displays as <Help Me>,
 *                      <!who:Who's There?> displays as <Who's There?>
 *      Feb 1993 - recognizes port numbers more reliably
 *               - added ftp, rlogin and pad commands
 *      Dec 1992 - fixed 'm' from main highlighting bug
 *               - allow 'l' and KEY_RIGHT responses to "Telnet (y/n)?"
 *      Oct 1992 - start from any file by, eg. "hytelnet cn008"
 *      Jun 1992 - fixed link to non-existant file bug
 *               - use getlogin() instead of cuserid() on Ultrix systems
 *      May 1992 - can tab between fields
 *               - don't scroll screen (as much) when telnetting
 *      Apr 1992 - fixed bug parsing two or more arguments (thanks Kee)
 *               - on exit, terminal was occasionaly left in standout mode
 *               - added a redraw screen command (^L or ^R)
 *      Mar 1992 - exits gracefully on hangup (instead of hanging)
 *               - no longer crashes if there are too many links on a page
 *               - accepts uppercase responses to yes/no questions
 *               - now handles port numbers
 *      Feb 1992 - Unix version handles more terminal types
 *      Jan 1992 - says -more- iff there is more to see
 *               - anonymous users are not permitted to telnet
 *      Dec 1991 - tabs display properly
 *               - cursor positioning improved in VMS
 *               - last line -more- bug is less obtrusive
 *               - VMS version now checks terminal type itself
 *      Nov 1991 - added interrupt handling
 *               - fixed up-arrow at top of file bug
 *               - fixed column 80 ^M bug
 *               - CAN NOW EXEC EMBEDDED TELNET COMMANDS!
 *
 * NOTICE
 *	Feel free to copy, use, redistribute and modify this program as
 *	you see fit.
 *
 *		    (c) Copyright 1993 Earl Fogel
 */
#include <stdio.h>
#include <ctype.h>
#include <signal.h>
#include <string.h>	/* some systems require <strings.h> instead */
#include <curses.h>

#ifdef __MSDOS__
#define MSDOS
#define strncasecmp strnicmp  /* at least for Turbo C 2.0 */
#define strcasecmp stricmp    /* at least for Turbo C 2.0 */
#endif

#if !defined(VMS) && !defined(MSDOS)
#   define UNIX
#endif

/*********************************
 * Things you may want to adjust *
 *********************************/

#ifdef VMS
#   define STARTDIR "pub:[hytelnet]"
#   define TELNET_COMMAND "telnet"
#ifdef MULTINET
#   define TN3270_COMMAND "telnet/tn3270"
#else
#   define TN3270_COMMAND NULL
#endif
#   define RLOGIN_COMMAND NULL
#   define FINGER_COMMAND NULL
#   define FTP_COMMAND    "ftp"
#   define PAD_COMMAND    NULL
#else
#ifdef MSDOS
#   define STARTDIR "."		  /* actually this is ignored */
#   define TELNET_COMMAND "telnet"
#   define TN3270_COMMAND "tn3270"
#   define RLOGIN_COMMAND NULL
#   define FINGER_COMMAND NULL
#   define FTP_COMMAND    "ftp"
#   define PAD_COMMAND    NULL
#else
#   define STARTDIR "/usr/local/hytelnet"
#   define TELNET_COMMAND "/usr/ucb/telnet"
#   define TN3270_COMMAND "/usr/local/bin/tn3270"
#   define RLOGIN_COMMAND "/usr/ucb/rlogin"
#   define FINGER_COMMAND "/usr/ucb/finger"
#   define FTP_COMMAND    "/usr/ucb/ftp"
#   define PAD_COMMAND    "pad"
#endif
#endif

char *unzip_command="unzip -aj";

/*
 * Hytelnet can execute generic commands enclosed in angle brackets
 * and prefaced by an exclamation mark, eg. <!who>.  If you don't
 * want this, remove the #define GENERIC_OK.
 */
#define GENERIC_OK

/*
 * The string that separates an Internet address and port number.
 *
 *    " "       - most systems            (eg. telnet 130.132.1.4 300)
 *    " /port=" - VMS Multinet systems    (eg. telnet 130.132.1.4 /port=300)
 *    "#"       - DOS NCSA Telnet systems (eg. telnet 130.132.1.4#300)
 */
#ifdef MSDOS
#   define PORTSEP "#"
#else
#ifdef MULTINET
#   define PORTSEP " /port="
#else
#   define PORTSEP " "		/* most systems */
#endif
#endif

int connect_by_name = TRUE;	/* TRUE to use Internet name for telnet */
int connect_by_number = TRUE;	/* TRUE to use Internet number for telnet */

/*
 * The telnet-out feature is disabled for:
 *  1) anonymous users (on VMS systems)
 *  2) anonymous users outside the local domain (on Unix systems)
 *  3) all users if SECURE is defined
 *
 * To enable telnet-out for anonymous users, define ANONYMOUS_USER as "".
 * To enable it for anon. users outside your domain, define DOMAIN_CUE as "".
 * To disable it for anonymous users from specific hosts, list them under
 * hostexceptions (Unix only).
 */
#define ANONYMOUS_USER "hytelnet"
#define DOMAIN_CUE ".usask."	/* CHANGE THIS! */
int nhostexceptions = 0;
char *hostexceptions[] = {""};

/*
 * Replace cuserid() with getlogin() on DEC Ultrix
 */
#ifdef ultrix
#   define cuserid(x) getlogin()
extern char *getlogin();
#endif

extern char *strcpy(), *strncpy();	/* comment this out on IBM RS 6000 */

/*********************************************************
 * You shouldn't need to change anything below this line *
 *********************************************************/

#ifdef VMS
#   define unlink delete
#else
#   include <sys/types.h>
#   include <sys/stat.h>
#endif

#define TELNET    1
#define TN3270    2
#define RLOGIN    3
#define FINGER    4
#define FTP       5
#define PAD       6
#define GENERIC   7
#define NCOMMANDS 7
int command_ok[NCOMMANDS+1] = {0};

#define MAXFNAME 80	/* max length of filename and other stuff in <>'s */
#define MAXHIST  65	/* number of links we remember in history */
#define MAXLINKS 65	/* max links on one screen */
#define STARTFILE "start"
#define HELPFILE "help"
#define INDEX "index"

#ifdef MSDOS
#   define HELP "Commands: Use arrow keys to move, 'F1' for help, 'q' to quit"
#   define MOREHELP \
  "-- PgDn for more, use arrow keys to move, 'F1' for help, 'q' to quit"
#   define MORE "-- PgDn for more --"
#else
#   define HELP "Commands: Use arrow keys to move, '?' for help, 'q' to quit"
#   define MOREHELP \
  "-- press space for more, use arrow keys to move, '?' for help, 'q' to quit"
#   define MORE "-- press space for more --"
#endif

#define STREQ(a,b) (strcasecmp(a,b) == 0)
#define STRNEQ(a,b,c) (strncasecmp(a,b,c) == 0)
#define printable(c) (((c)>31 && (c)<=127) || (c)==9 || (c)==10)

#define ON	1
#define OFF	0
#define HLINE   196     /* horizontal line segment */
#define VLINE   179     /* vertical line segment */
#define VLINE2  186     /* vertical line segment */
#define UL      218     /* upper left corner */
#define UR      191     /* upper right corner */
#define LL      192     /* lower left corner */
#define LR      217     /* lower right corner */
#define UL2     214     /* upper left corner */
#define UR2     183     /* upper right corner */
#define LL2     211     /* lower left corner */
#define LR2     189     /* lower right corner */
#define BULLET  4       /* list item marker */
#define BLOT1   178
#define BLOT2   177
#define BLOT3   176

#ifndef KEY_RIGHT
#   define KEY_DOWN	0402
#   define KEY_UP	0403
#   define KEY_LEFT	0404
#   define KEY_RIGHT	0405
#endif

#ifdef SVR4
#   define UTMP_FNAME UTMPX_FILE
#else
#ifdef UNIX
#   define UTMP_FNAME "/etc/utmp"
#endif
#endif

struct link {
    char lname[MAXFNAME];
    char ldata[MAXFNAME];
    short lx;
    short ly;
    short tcmd;
    short tx;
} links[MAXLINKS];
int nlinks = 0;

struct hist {
    char *hfname;
    short hlinkno;
    short hpageno;
    char *hpattern;
} history[MAXHIST];
int nhist = 0;

char *zipfile = NULL; /* for on the fly unzipping     */
char *unz[MAXHIST];   /* list of files we've unzipped */
int nun = 0;          /* number of files we've ...    */

char *startfile = STARTFILE;
char *helpfile  = HELPFILE;
char *startdir  = STARTDIR;

int in_curses = FALSE;
int more = 0;
int lastpage = -1;	/* page number of last page in current file */
char term[81];
char *interaddr(), *findport(), *nextword();
char *mystrncpy(), *strcasestr(), *strsave(), *match_fgets();
FILE *myfopen();

#ifdef __STDC__
/* function prototypes, for more discriminating compilers */
void	cleanup(void);
void	highlight(int flag, int cur);
void	statusline(char *text, int line);
void	push(char *fname, int cur, int page, char *pattern);
void	pop(char *fname, int *cur, int *page, char *pattern);
#else
void	cleanup();
void	highlight();
void	statusline();
void	push();
void	pop();
#endif


#ifndef MSDOS
/*
 * Interrupt handler.  Stop curses and exit gracefully.
 */
void
cleanup_sig (sig)
int sig;
{
    /* ignore further interrupts */     /*  mhc: 11/2/91 */
    (void) signal (SIGHUP, SIG_IGN);
    (void) signal (SIGINT, SIG_IGN);
    (void) signal (SIGTERM, SIG_IGN);

    if (sig != SIGHUP) {
	if (in_curses) cleanup();
	printf("\nExiting via interrupt: exit(%d)\n",sig);
	fflush(stdout);
    }

    exit(sig);
}
#endif

main(argc, argv)
int argc;
char *argv[];
{
    int  i, j;
    char *cp;
    FILE *fp;
#ifndef VMS
    struct stat statbuf;
#endif

#ifndef MSDOS
    /* trap interrupts */     /*  mhc: 11/2/91 */
    (void) signal (SIGHUP, cleanup_sig);
    (void) signal (SIGINT, cleanup_sig);
    (void) signal (SIGTERM, cleanup_sig);
#endif

    command_ok[TELNET]  = (TELNET_COMMAND != NULL);
    command_ok[TN3270]  = (TN3270_COMMAND != NULL);
    command_ok[RLOGIN]  = (RLOGIN_COMMAND != NULL);
    command_ok[FINGER]  = (FINGER_COMMAND != NULL);
    command_ok[FTP]     = (FTP_COMMAND    != NULL);
    command_ok[PAD]     = (PAD_COMMAND    != NULL);
#ifdef GENERIC_OK
    command_ok[GENERIC] = TRUE;
#else
    command_ok[GENERIC] = FALSE;
#endif

#ifdef MSDOS	/* by default, program & data reside in same directory */
    startdir = argv[0];
    *(strrchr(startdir,'\\')) = '\0';
#endif

    /*
     * Process arguments
     */
    for (i=1; i<argc; i++) {
	if        (strcmp(argv[i], "-secure") == 0) {
	    for (j=1; j<=NCOMMANDS; j++)
		command_ok[j] = FALSE;
	} else if (strcmp(argv[i], "-name") == 0) {
	    connect_by_name = FALSE;
	} else if (strcmp(argv[i], "-number") == 0) {
	    connect_by_number = FALSE;
        } else if (strncmp(argv[i], "-", 1) == 0) {
	    printf("Usage: hytelnet [options] [file]\n");
	    printf("Options are:\n");
	    printf("    -secure   disable external commands\n");
	    printf("    -name     disable use of Internet name\n");
	    printf("    -number   disable use of Internet number\n");
	    exit(0);
	} else {	/* alternate database path */
#ifdef VMS
	    cp = strrchr(argv[i], ']');
	    if (cp == NULL)
		cp = strrchr(argv[i], ':');
	    if (cp && *(cp+1) == '\0') {
		startdir = argv[i];
	    } else {
		if (cp == NULL) {
		    startfile = argv[i];
		} else {
		    startdir = argv[i];
		    startfile = strsave(cp+1);
		    *(cp+1) = '\0';
		}
	    }
#else
	    if (stat(argv[i], &statbuf) == 0 && (statbuf.st_mode & S_IFDIR)) {
		startdir = argv[i];
	    } else {
		cp = strrchr(argv[i], '/');
#ifdef MSDOS
		if (cp == NULL)
		    cp = strrchr(argv[i], '\\');
#endif /* MSDOS */
		if (cp == NULL) {
		    startfile = argv[i];
		} else {
		    startdir = argv[i];
		    startfile = cp+1;
		    *cp = '\0';
		}
	    }
#endif /* not VMS */
	}
    }

    /*
     * check for help file
     */
    if ((fp=myfopen(helpfile, "r")) == NULL)
	helpfile = "help.txt";
    else
	(void) fclose(fp);

    /*
     * check for zip file (and zip command on MS-DOS)
     */
    cp = strrchr(startfile, '.');
    if (cp != NULL && STREQ(cp, ".zip")) {
        zipfile = startfile;
        startfile = STARTFILE;
    } else if ((fp=myfopen("hytelnet.zip", "r")) != NULL) {
            zipfile = "hytelnet.zip";
            (void) fclose(fp);
    }
#ifdef MSDOS
    if (searchpath("unzip.exe") != NULL)
	unzip_command = "unzip -j";
    else if (searchpath("pkunzip.exe") != NULL)
	unzip_command = "pkunzip";
    else
	zipfile = NULL;	/* couldn't find an unzip command */
#endif
 
    /*
     * check for start file
     */
    fp=myfopen(startfile, "r");
    if (fp == NULL && STREQ(startfile, "start")) {
	if ((fp=myfopen("start.txt", "r")) != NULL)
	    startfile = "start.txt";
    }
    if (fp == NULL) {
	printf("Hytelnet: can't find file: %s/%s\n", startdir, startfile);
	exit(0);
    } else
	(void) fclose(fp);

    /*
     * The telnet-out feature is disabled for:
     *  1) anonymous users (on VMS systems)
     *  2) anonymous users outside the local domain (on Unix systems)
     *  3) all users if SECURE is defined
     */
#ifndef MSDOS
    if (STREQ(cuserid((char *) NULL), ANONYMOUS_USER) && !inlocaldomain())
	for (i=1; i<=NCOMMANDS; i++)
	    command_ok[i] = FALSE;
#endif
#ifdef SECURE
	for (i=1; i<=NCOMMANDS; i++)
	    command_ok[i] = FALSE;
#endif

    /*
     * here's where we do all the work
     */
    if (setup()) {
	mainloop();
	cleanup();
    }

#ifndef MSDOS
    /* wait a bit to make sure output is flushed before hanging up */
    if (STREQ(cuserid((char *) NULL), ANONYMOUS_USER))
	sleep(1);
#endif

    exit(0);
    /* NOTREACHED */
}


#ifdef VMS
/*
 * check terminal type, start curses & setup terminal
 */
setup() /* VMS version */
{
    int c;
    char *dummy, *cp;

    /*
     * get terminal type, and convert to lower case
     */
    longname(dummy, term);
    for (cp=term; *cp!='\0'; cp++)
	if (isupper(*cp))
	    *cp = tolower(*cp);

    if (!STRNEQ(term, "vt", 2)) {
	if (*term == '\0') strcpy(term, "Unknown");
	printf("Terminal = %s\n", term);
	printf(
	    "You must use a vt100, 200, etc. terminal with this program.\n\n");
	return(0);
    }

    start_curses();

    return(1);
}
#endif /* VMS */

#ifdef MSDOS
/*
 * check terminal type, start curses & setup terminal
 */
setup() /* MSDOS */
{
    start_curses();
    return(1);
}
#endif /* MSDOS */

#ifdef UNIX
/*
 * check terminal type, start curses & setup terminal
 */
setup() /* Unix */
{
    start_curses();

    /* get terminal type (strip 'dec-' from vms style types) */
    if (strncmp(ttytype, "dec-vt", 6) == 0) {
	strcpy(term, ttytype+4);
	(void) setterm(term);
    }

    if (dumbterm()) {
	printw("Please enter your terminal type (default vt100): ");
	refresh();
	echo();
	getstr(term);
	noecho();
	if (strlen(term) == 0)
	    strcpy(term, "vt100");

	/*
	 * you can remove the stop_curses() and start_curses() calls
	 * below if they cause problems
	 */
        stop_curses();
        (void) setterm(term);
        start_curses();

	if (dumbterm()) {
	    stop_curses();
	    printf("Hytelnet does not support your terminal (%s)\n", term);
	    return(0);
	}
    }

    return(1);
}

dumbterm() /* Unix */
{
    int dumb = FALSE;

    if (STREQ(ttytype, "network") ||
	STREQ(ttytype, "unknown") ||
	STREQ(ttytype, "dialup")  ||
	STREQ(ttytype, "dumb")    ||
	STREQ(ttytype, "switch")  ||
	STREQ(ttytype, "ethernet")  )
	dumb = TRUE;
    return(dumb);
}
#endif /* Unix */


start_curses()
{
#ifdef VMS
    void setterm_pas();

    setterm_pas();
    (void) initscr();	/* start curses */
    crmode();
#endif

#ifdef MSDOS
    (void) initscr();	/* start curses */
    cbreak();
    raw();
    keypad(stdscr, TRUE);	/* enable keypad */
#ifdef PC_CURSES
    leaveok(stdscr, TRUE);	/* hide the cursor */
    pc_uptype(T_DIRECT);	/* enable direct video updates */
#endif
#endif

#ifdef UNIX
    (void) initscr();	/* start curses */
    if (*term)
	setterm(term);
    cbreak();
#endif

    noecho();
    in_curses = TRUE;
}


stop_curses()
{
#ifdef VMS
    void resetterm_pas();
#endif

    endwin();	/* stop curses */

#ifdef VMS
    resetterm_pas();
#endif

    in_curses = FALSE;
}

void
cleanup()
{
    if (in_curses) {
	move(LINES-1, 0);
	clrtoeol();
	refresh();
	stop_curses();
    }
    while (nun-- > 0)
	unlink(unz[nun]);
}


/*
 * here's where we do all the work
 */
mainloop()
{
    int  doitanyway=FALSE;
    int  show_help=FALSE, show_version=FALSE;
    int  val, lastline;
    int  c, arrowup=FALSE;
    int  cur = 0, savcur = -1;
    int  oldpage = 0, newpage = 1, savpage = 1;
    char oldfile[MAXFNAME], newfile[MAXFNAME];
    char buf[81], tncommand[81], tnaddr[81];
    char pattern[81];
    char *cp, *port;
    FILE *fp = NULL, *oldfp;

    strcpy(pattern, "");
    strcpy(newfile, startfile);

    while (TRUE) {
	if (!STREQ(oldfile, newfile) || doitanyway) {
	    /*
	     * Try to open the new file.
	     * If the file is not found in the current directory, use
	     * the first three letters of the filename as a directory name,
	     * and try again.  This is for compatibility with HYPERRES.
	     */
            oldfp = fp;
            if ((fp=myfopen(newfile, "r")) != NULL) {
                if (oldfp != NULL)
                    (void) fclose(oldfp); /* close previous file */
                oldpage = 0; /* to force a showpage() */
		newpage = savpage;
		savpage = 1;
		lastpage = -1;
                strcpy(oldfile, newfile);
            } else {
		pop(newfile, &cur, &newpage, pattern);
                fp = oldfp;
            }
	    doitanyway=FALSE;
        }

	if (oldpage != newpage) {
	    val=showpage(fp, newpage, oldpage, pattern);
	    if (val > 0) {
		cur = 0;
		lastline = val;
            } else if (val < 0) {	/* empty file */
		pop(newfile, &cur, &newpage, pattern);
		if STREQ(oldfile,newfile)
		    doitanyway=TRUE;
		savcur = cur;
		continue;
	    } else
		newpage = oldpage;
	    if (newpage == -1)	/* flag for last page */
		newpage = lastpage;
	    oldpage = newpage;
	}
	if (arrowup) {
	    cur = nlinks - 1;
	    arrowup = FALSE;
	} else if (savcur >= 0) {
	    cur = savcur;
	    savcur = -1;
	}

	if (show_help) {
	    statusline((more? MOREHELP: HELP), LINES-1);
	    show_help = FALSE;
	} else if (show_version) {
	    statusline(Version,LINES-1);
	    show_version = FALSE;
	} else if (more) {
	    statusline(MORE,LINES-1);
	}
	highlight(ON, cur);

	c=mygetch();

	highlight(OFF, cur);
	statusline("",LINES-1);

	switch(c) {
	case 'q':	/* quit */
	case 'Q':
	case 4:
	case EOF:
#ifdef MSDOS
	case 27:
	case 3:
#endif
	    return;
	case 12:	/* redraw screen */
	case 18:
	    clearok(curscr, TRUE);
	    refresh();
	    break;
	case ' ':	/* next page */
	case '+':
#ifdef KEY_NPAGE
        case KEY_NPAGE:
#endif
	    newpage++;
	    break;
	case 'b':	/* prev page */
	case 'B':
	case '-':
#ifdef KEY_PPAGE
        case KEY_PPAGE:
#endif
	    newpage--;
	    break;
	case KEY_UP:			/* up to previous link */
	case 'k':
	case 16:	/* ^P */
	    if (cur>0) {
		cur--;
	    } else if (oldpage > 1) {	/* previous page */
		newpage--;
		arrowup = TRUE;
	    } else {			/* wrap */
		newpage = lastpage;
		arrowup = TRUE;
	    }
	    break;
	case KEY_DOWN:			/* down to next link */
	case 'j':
	case '\t':
	case 14:	/* ^N */
	    if (cur<nlinks-1) {
		cur++;
	    } else if (feof(fp)) {	/* wrap */
		newpage = 1;
		cur = 0;
	    } else {			/* next page */
		newpage++;
	    }
	    break;
	case KEY_LEFT:			/* back up a level */
	case 'h':
	case 'u':
	case 'U':
	case 2:		/* ^B */
	    if (nhist>0) {
		pop(newfile, &savcur, &savpage, pattern);
		if STREQ(oldfile,newfile)
		    doitanyway=TRUE;
		}
	    break;
	case KEY_RIGHT:			/* follow a link */
	case 'l':
	case '\n':
	case '\r':
	case 6:		/* ^F */
	    if (nlinks > 0) {
		if (links[cur].tcmd == 0) {	/* it's a link  */
		    strcpy(newfile, links[cur].ldata);
		    push(oldfile, cur, newpage, pattern);
		    strcpy(pattern, "");
		} else {			/* it's a command */
		    if (links[cur].tcmd == GENERIC) {
		      strcpy(tncommand, links[cur].ldata);
		      move(lastline+1,0);
		      refresh();
		    } else {
		      port = findport(links[cur].ldata);
		      if (port) {
			*(port-1) = '\0';
			sprintf(tnaddr,"%s%s%s",links[cur].ldata,PORTSEP,port);
		      } else {
			strcpy(tnaddr, links[cur].ldata);
		      }
		      sprintf(buf, "%s %s %s",
			links[cur].lname, tnaddr, "Proceed (y/n)?");
		      statusline(buf,lastline+1);
		      c=mygetch();
		      if (c == 'y' || c== 'Y' || c == '\n' || c == '\r' ||
			c == 'l' || c == KEY_RIGHT) {
			addstr(" Ok...");
			refresh();
			tncommand[0] = '\0';
			if (links[cur].tcmd==TELNET)
			  sprintf(tncommand,"%s %s",TELNET_COMMAND,tnaddr);
			if (links[cur].tcmd==TN3270)
			  sprintf(tncommand,"%s %s",TN3270_COMMAND,tnaddr);
			if (links[cur].tcmd==RLOGIN)
			  sprintf(tncommand,"%s %s",RLOGIN_COMMAND,tnaddr);
			if (links[cur].tcmd==FINGER)
			  sprintf(tncommand,"%s %s",FINGER_COMMAND,tnaddr);
			if (links[cur].tcmd==FTP)
			  sprintf(tncommand,"%s %s",FTP_COMMAND,tnaddr);
			if (links[cur].tcmd==PAD)
			  sprintf(tncommand,"%s %s",PAD_COMMAND,tnaddr);
		      } else {
		        statusline("",lastline+1);
			break;
		      }
		      if (port)
			  *(port-1) = ' ';
		    }

		    /*
		     * security check on command
		     */
		    for (cp=tncommand; *cp; cp++) {
                        if (isalnum(*cp) ||
#ifdef VMS
                            strchr("[]:", *cp) ||
#endif
                            strchr("\"-_=.@/ ", *cp))
			    ; /* NULL BODY */
			else
			    *cp = ' ';
		    }
#ifdef hpux
                    saveterm(); /* save for return to curses */
                    resetterm(); /* go to default settings */
#else
		    stop_curses();
#endif

		    (void) system(tncommand);

		    if (links[cur].tcmd == GENERIC ||
		       links[cur].tcmd == FINGER) {
		      printf("\nPress <return> to continue\n");
		      (void) getchar();
		    }

#ifdef hpux
                    fixterm(); /* return to curses */
#else
		    start_curses();
#endif
		    rewind(fp);
		    oldpage = 0;		/* force a redraw */
		    savcur = cur;

		    if (links[cur].tcmd != GENERIC) {
		      statusline("",lastline+1);
		    }
		}
	    } else
		show_help = TRUE;
	    break;
	case '?':			/* show help text */
#ifdef KEY_F
        case KEY_F(1):
#endif
	    strcpy(newfile, helpfile);
	    push(oldfile, cur, newpage, pattern);
	    strcpy(pattern, "");
	    break;
	case '/':			/* search index */
	case 'i':			/* search index */
	case 'I':			/* search index */
	    push(oldfile, cur, newpage, pattern);
	    val = get_line("Search Index: ", buf);
	    if (val > 0)
		strcpy(pattern, buf);
	    else
		break;			/* do nothing */
	    strcpy(newfile, INDEX);
	    if STREQ(oldfile,newfile)
		doitanyway=TRUE;
	    break;
	case 'm':	/* return to main screen */
	case 'M':
	    if (!STREQ(newfile, startfile)) {
		while(nhist > 0)
		    pop(newfile, &cur, &newpage, pattern);
		strcpy(newfile, startfile);
		cur = 0;
		newpage = 1;
		strcpy(pattern, "");
	    }
	    break;
	case 'v':	/* give version info */
	case 'V':
	    show_version = TRUE;
	    break;
	default:
	    show_help = TRUE;
	    break;
	}
    }
}


/*
 * display one screen of text
 *
 * Read & display one screenfull of text.
 * Looks for (and remembers) links, and converts IBM PC line drawing
 * characters to standard ascii
 *
 * Pre-reads one line from the next page, to ensure that the "- more -"
 * message is only displayed when there really is more.
 */
int
showpage(fp, page, oldpage, pattern)
FILE *fp;
int page, oldpage;
char *pattern;
{
    int lineno, col, cmdtype;
    static char line[182];
    char *cp, *cp2, *cp3, *acp;
    unsigned char uc;

    if (page < 0) {			/* go to last page */
	lineno = oldpage*(LINES-1) - 1 + more;
	while (match_fgets(line, 181, fp, pattern) != NULL) {
	    lineno++;
	    if (strlen(line) > COLS) lineno++;
	}
	page = lastpage = lineno/(LINES-1) + 1;
	if (page == oldpage)
	    return(0);			/* nothing to do */
	rewind(fp);
	oldpage = 0;
    } else if (page == 0) {
	page = 1;
    } else if (page < oldpage) {	/* have to back up */
	rewind(fp);
	oldpage = 0;
    }
    if (oldpage == 0)			/* throw away saved line */
	more = 0;
    if (page == oldpage)		/* nothing to do */
	return(0);

    if (page == 1 || page != oldpage+1) {
	lineno = oldpage*(LINES-1) + more;
	while (lineno<(page-1)*(LINES-1)
	    && match_fgets(line, 181, fp, pattern) != NULL) {
	    lineno++;
	    if (strlen(line) > COLS) lineno++;
	}
	more = 0;
    }

    lineno = 0;
    while (lineno<(LINES-1)
	&& (more || match_fgets(line, 181, fp, pattern) != NULL)) {
	more = 0;
	cp = line+strlen(line)-1;
	if (*cp == 13)
	    *cp = '\0';		/* remove trailing <return> */

	if (lineno == 0) {
	    nlinks = 0;
	    clear();
	}
	col = 0;
	for (cp=line; *cp != '\0'; cp++) {
	    uc = *cp;
	    if (!printable(uc)) {
#ifndef MSDOS
		if      (uc == HLINE)	*cp = '-';
		else if (uc == VLINE)	*cp = '|';
		else if (uc == VLINE2)	*cp = '|';
		else if (uc == UL)	*cp = '+';
		else if (uc == UR)	*cp = '+';
		else if (uc == LL)	*cp = '+';
		else if (uc == LR)	*cp = '+';
		else if (uc == UL2)	*cp = '+';
		else if (uc == UR2)	*cp = '+';
		else if (uc == LL2)	*cp = '+';
		else if (uc == LR2)	*cp = '+';
		else if (uc == BULLET)	*cp = '*';
		else if (uc == BLOT1)	*cp = '*';
		else if (uc == BLOT2)	*cp = '*';
		else if (uc == BLOT3)	*cp = '*';
		else {
		    *cp = ' ';
		}
#endif
		addch(*cp);
		col++;
	    } else if (*cp == '\\') {
		cp2 = cp+1;
		if (*cp2 == '<' || iscommand(cp2))
		    cp++;
		addch(*cp);
		col++;
	    } else if (*cp == '<') {	/* start of link? */
		for (cp2 = cp+1;
		    *cp2 != '>' && *cp2 != '<' && *cp2 != '\0' &&
		    cp2-cp+1 < MAXFNAME; cp2++)
		    ; /* NULL BODY */
		if (*cp2 == '>' && nlinks < MAXLINKS) { /* it's a link */
		    links[nlinks].lx = col;
		    links[nlinks].ly = lineno;
		    if (*(cp+1) == '!' && command_ok[GENERIC]) {
		      links[nlinks].tcmd = GENERIC;
		      for (cp3 = cp; cp3 < cp2 && *cp3 != ':'; cp3++)
			;  /* NULL BODY */
		    } else {
		      links[nlinks].tcmd = 0;
		      for (cp3 = cp; cp3 < cp2 && *cp3 != ':' &&
                        !isspace(*cp3); cp3++)
			;  /* NULL BODY */
		    }
		    if (cp3 >= cp2) {
			mystrncpy(links[nlinks].lname, cp, cp2-cp+1);
			mystrncpy(links[nlinks].ldata, cp+1, cp2-cp-1);
		    } else {
		        if (*(cp+1) == '!')
		          cp++;
			mystrncpy(links[nlinks].ldata, cp+1, cp3-cp-1);
		        while (isspace(*cp3) || *cp3 == ':')
			  cp3++;
			*links[nlinks].lname = '<';
			mystrncpy(links[nlinks].lname+1, cp3, cp2-cp3);
			strcat(links[nlinks].lname, ">");
		    }
		    addstr(links[nlinks].lname);
		    col += strlen(links[nlinks].lname);
		    cp = cp2;
		    nlinks++;
		} else {
		    addch(*cp);
		    col++;
		}
	    } else if (*cp == '\t') {	/* expand tabs */
		addch(*cp);
		col += 8 - (col % 8);
	    } else if (col == 0 || isspace(*(cp-1))) {  /* a command? */
		if ((cmdtype=iscommand(cp))) {
		    acp=interaddr(nextword(cp),links[nlinks].ldata);
		    while (acp != NULL && nlinks < MAXLINKS) {
			copyword(links[nlinks].lname, cp);
			links[nlinks].tcmd = cmdtype;
			links[nlinks].lx = col;
			links[nlinks].tx = col + acp - cp;
			links[nlinks].ly = lineno;
			acp += strlen(links[nlinks].ldata);
			nlinks++;
			acp=interaddr(acp,links[nlinks].ldata);
		    }
		}
		addch(*cp);
		col++;
	    } else {
		addch(*cp);
		col++;
	    }
	    if (col >= COLS-1 && *(cp+1) != '\0'
		&& *(cp+1) != '\n') {	/* wrap long lines */
	        addch('\n');
		col = 0;
		lineno++;
	    }
	}
#if defined(MSDOS) && !defined(PC_CURSES)
       addch('\r');
#endif
	lineno++;
    }
    if (lineno==(LINES-1) && match_fgets(line, 181, fp, pattern) != NULL)
	    more = 1;
    if (lineno>=LINES && strlen(line) > COLS) {
	    lineno = LINES;
	    strcpy(line,line+COLS-1);
	    more = 1;
    }
    refresh();
    if (page == 1 && lineno == 0)	/* empty file */
	return(-1);
    else
	return(lineno);
}


/*
 * Check if string cp begins with an acceptable command, and, if so,
 * return the command type.
 */
iscommand(cp)
char *cp;
{
    if (command_ok[TELNET] && STRNEQ(cp,"TELNET ",7))
	return(TELNET);
    if (command_ok[TN3270] && STRNEQ(cp,"TN3270 ",7))
	return(TN3270);
    if (command_ok[RLOGIN] && STRNEQ(cp,"RLOGIN ",7))
	return(RLOGIN);
    if (command_ok[FINGER] && STRNEQ(cp,"FINGER ",7))
	return(FINGER);
    if (command_ok[FTP] && STRNEQ(cp,"FTP ",4))
	return(FTP);
    if (command_ok[PAD] && STRNEQ(cp,"PAD ",4))
	return(PAD);

    return(0);
}

/*
 * Search through a string for the first valid internet address.
 * We define an internet address as a word consisting of alpha-
 * numeric characters and dots (and with at least one embedded dot).
 *
 * If the address is immediately followed by a space and a port number,
 * or a " -l " and a login id, those are included as well.
 *
 * This is not a general purpose routine.
 *
 * Returns an pointer to the address if one is found, NULL otherwise.
 */
char *
interaddr(cp, buf)
char *cp, *buf;
{
    int isaddr, isname;
    char *cp2, *word;

    isaddr = FALSE;
    isname = FALSE;

    while (isspace(*cp)) cp++;		/* skip spaces */
    if (STRNEQ(cp, "or ", 3)) {		/* skip the word 'or' */
	cp += 3;
	while (isspace(*cp)) cp++;
    }

    word = cp;				/* start of word? */
    while (*cp && (strchr("\"-_=.@", *cp) || isalnum(*cp))) {
	if (*cp == '.' && isalnum(*(cp+1)) )
	    isaddr = TRUE;
	if (isalpha(*cp))
	    isname = TRUE;
	cp++;
    }

    if (isaddr) {			/* it's an internet address */
	if ((connect_by_name && isname) ||
	    (connect_by_number && !isname) ) {
	    if (STRNEQ(cp," -l ",4)) {	/* -l argument to rlogin */
		cp = nextword(cp);
		cp = nextword(cp);
		while (isalnum(*cp)) cp++;
	    } else if (isspace(*cp)) {	/* check for port number */
		cp2 = findport(cp);
		if (cp2) {
		    cp = cp2;
		    while (isdigit(*cp)) cp++;
		}
	    }
	    while (!isalnum(*cp) && *cp != '"') cp--;
	    mystrncpy(buf,word,cp-word+1);
	    /* printw("interaddr: '%s'\n", buf); refresh(); */
	    return(word);
	}
    }
    return(NULL);
}

/*
 * Looks for something resembling a port number in a telnet argument string
 */
char *
findport(cp)
char *cp;
{
    char *port;

    cp = port = nextword(cp);
    while (isdigit(*cp)) cp++;
    if (cp>port && (isspace(*cp) || *cp=='\0')) {
	return(port);
    }

    return(NULL);
}

/*
 * Return pointer to the next word in a string
 */
char *
nextword(cp)
char *cp;
{
    while (*cp != ' ' && *cp != '\0') cp++;	/* skip non-spaces */
    while (isspace(*cp)) cp++;			/* skip spaces */
    return(cp);
}

/*
 * Copy the next word in s2 to s1
 */
copyword(s1,s2)
char *s1, *s2;
{
    while (*s2 != ' ' && *s2 != '\0')
	*s1++ = *s2++;
    *s1 = '\0';
}


/*
 * my strncpy() terminates strings with a null byte.
 * Writes a null byte into the n+1 byte of dst.
 */
char *
mystrncpy(dst, src, n)
char *dst, *src;
int n;
{
    char *val;

    val = strncpy(dst, src, n);
    *(dst+n) = '\0';
    return val;
}


/*
 * my getch() translates some escape sequences
 */
mygetch()
{
    int a, b, c;

#ifdef VMS
int w_getch();
#define wgetch w_getch
#endif

    c = getch();
#ifndef MSDOS
      /* Rick Mallett's fix to the runaway process (missing SIGHUP) problem */
      if (feof(stdin) || ferror(stdin) || c == EOF) {
         cleanup();
         exit(0);
      }
    
    if (c == 27) {	/* handle escape sequence */
	b = getch();
	if (b == '[' || b == 'O')
	    a = getch();
	else
	    a = b;

	switch (a) {
	case 'A': c = KEY_UP; break;
	case 'B': c = KEY_DOWN; break;
	case 'C': c = KEY_RIGHT; break;
	case 'D': c = KEY_LEFT; break;
	case '5':			/* vt 300 prev. screen */
	    if (b == '[' && getch() == '~')
		c = '-';
	    break;
	case '6':			/* vt 300 next screen */
	    if (b == '[' && getch() == '~')
		c = '+';
	    break;
	}
    }
#endif
    return(c);
}


/*
 * highlight (or unhighlight) a given link
 */
void
highlight(flag, cur)
int flag;
int cur;
{
    if (nlinks > 0) {
	move(links[cur].ly, links[cur].lx);
	if (flag == ON) standout();
	addstr(links[cur].lname);
	if (links[cur].tcmd != 0 && links[cur].tcmd != GENERIC) {
	    move(links[cur].ly, links[cur].tx);
	    addstr(links[cur].ldata);
	}
	if (flag == ON) standend();
	refresh();
    }
}


/*
 * open a file relative to startdir
 * convert filename to lowercase and, if not found,
 * look in subdir (eg. look for US001 as us0/us001)
 */
FILE *
myfopen(fname,type)
char *fname, *type;
{
    char *cp, altfname[MAXFNAME], buf[200];
    FILE *fp;
#ifdef VMS
    int n;
    char *sep = "";
#else
    char *sep = "/";
#endif

    mystrncpy(altfname, fname, 3);
    strcat(altfname, "/");
    strcat(altfname, fname);

#ifdef VMS
    sprintf(buf, "%s%s", startdir, fname);
    fp = fopen(buf,type);
    if (fp == NULL) {
	strcpy(buf, startdir);
	n = strlen(buf);
	if (buf[n-1] == ']')
	    buf[n-1] = '.';
	else
	    strcat(buf, "[");
	strncat(buf, fname, 3);
	strcat(buf, "]");
	strcat(buf, fname);
	fp=fopen(buf, type);
    }
#else

    for (cp=fname; *cp!='\0'; cp++) {
	if (isupper(*cp))
	    *cp = tolower(*cp);
    }
    for (cp=altfname; *cp!='\0'; cp++) {
	if (isupper(*cp))
	    *cp = tolower(*cp);
    }
    sprintf(buf, "%s/%s", startdir, fname);
    fp = fopen(buf,type);
    if (fp == NULL) {			/* look in subdirectory */
	strcpy(buf, startdir);
	strcat(buf, "/");
	strcat(buf, altfname);
	fp=fopen(buf, type);
    }
#endif

    if (fp == NULL && zipfile) {	/* look in zip file */
	if (nun>=MAXHIST-1) unlink(unz[nun--]);

	getcwd(buf, sizeof(buf));
	strcat(buf, sep);
	strcat(buf, fname);
        unz[nun] = strsave(buf);
        sprintf(buf, "%s %s%s%s %s %s", unzip_command, startdir, sep, zipfile,
	    fname, altfname);
	fp = fopen(unz[nun],type); /* perhaps we've unzipped it already */
	if (fp) {
	    free(unz[nun]);
	} else {
#ifdef DEBUG
debug(buf);
#endif
	    system(buf);
	    fp=fopen(unz[nun++], "r");
	}
#ifndef PC_CURSES
	if (in_curses) clearok(curscr, TRUE);
#endif
    }

    return(fp);
}

/*
 * like fgets(), but only returns lines matching pattern
 */
char *
match_fgets(line, size, fp, pattern)
char *line;
int  size;
FILE *fp;
char *pattern;
{
    char *val;

    if (!pattern || strlen(pattern) == 0)
	return fgets(line, size, fp);

    while ((val=fgets(line, size, fp)) != NULL
	&& strcasestr(line, pattern) == NULL)
	; /* NULL BODY */

    return(val);
}

char *
strcasestr(s1,s2)
char *s1, *s2;
{
    int n;

    n = strlen(s2);

    while (*s1 && strncasecmp(s1,s2,n) != 0) {
	s1++;
    }

    return (*s1)? s1: NULL;
}

char *
strsave(s)
char *s;
{
    char *cp;
    char *malloc();

    cp = (char *) malloc((unsigned)strlen(s)+1);
    if (cp) strcpy(cp, s);
    return(cp);
}

/*
 * Prompts the user for a line of input.
 * Input is ended when the user presses <return>,
 * or when he or she backspaces past the beginning of the line.
 */
get_line(prompt, buf)
char *prompt, *buf;
{
    int  x, y, z;
    int  i;
    char c;

    move(LINES, 0);
    addstr(prompt);
    refresh();
    for (i=0; i<81 && i>=0 && (c=mygetch())!='\n' && c!='\r'; i++) {
        if (c == 8 || c == 127) {                /* backspace or delete */
	    getyx(stdscr,y,x);
	    move(y,x-1);
	    addch(' ');
	    move(y,x-1);
            i--; i--;       /* backup & undo next loop increment */
        } else if (c == 21) {                    /* ^U erase line */
	    getyx(stdscr,y,x);
	    z = strlen(prompt);
	    while (x-- > z) {
		move(y,x);
		addch(' ');
		move(y,x);
	    }
	    i = -1;
        } else {
            buf[i] = c;
            addch(c);
        }
	refresh();
    }
    if (i>=0)
	buf[i] = '\0';
    else
	buf[0] = '\0';
    addch('\r');
    clrtoeol();
    refresh();
    return(i);
}

/*
 * display (or hide) the status line
 */
void
statusline(text,line)
char *text;
int line;
{
    if (line > LINES-1)
	line = LINES-1;
    move(line,0);
    clrtoeol();
    if (text && *text) {
	standout();
	addstr(text);
	standend();
    }
    refresh();
}


/*
 * push the current file info onto the history list
 */
void
push(fname, cur, page, pattern)
char *fname, *pattern;
int cur, page;
{
    if (nhist<MAXHIST)  {
	history[nhist].hfname = strsave(fname);
	history[nhist].hlinkno = cur;
	history[nhist].hpageno = page;
	history[nhist].hpattern = strsave(pattern);
	nhist++;
    }
}


/*
 * pop the previous file info from the history list
 */
void
pop(fname, cur, page, pattern)
int *cur, *page;
char *fname, *pattern;
{
    if (nhist>0) {
	nhist--;
	strcpy(fname,history[nhist].hfname);
	*cur = history[nhist].hlinkno;
	*page = history[nhist].hpageno;
	strcpy(pattern,history[nhist].hpattern);
	if (history[nhist].hfname) free(history[nhist].hfname);
	if (history[nhist].hpattern) free(history[nhist].hpattern);
    }
}

/*
 * On Unix, returns TRUE if hostname includes DOMAIN_CUE
 * or if hostname does not include a '.'.
 * Returns FALSE for machines listed in hostexceptions.
 *
 * Always returns FALSE on other platforms.
 */
inlocaldomain()
{
#ifdef UTMP_FNAME
#ifdef SVR4
#include <utmpx.h>
#define utmp utmpx
#else
#include <utmp.h>
#endif
    int i, n;
    FILE *fp;
    struct utmp me;
    char *cp, *mytty=NULL;
    char *ttyname();

    if ((cp=ttyname(0)))
	mytty = strrchr(cp, '/');
#ifdef SVR4
    if (mytty)
	for (mytty--; *mytty != '/' && mytty >= cp; mytty--)
	    ;  /* NULLBODY */
#endif
    if (mytty && (fp=fopen(UTMP_FNAME, "r")) != NULL) {
	    mytty++;
	    do {
		n = fread((char *) &me, sizeof(struct utmp), 1, fp);
	    } while (n>0 && !STREQ(me.ut_line,mytty));
	    (void) fclose(fp);

	    if (n > 0) {
		for (i=0; i<nhostexceptions; i++) {
		    if (STRNEQ(me.ut_host, hostexceptions[i],
			strlen(hostexceptions[i])) )
			return(FALSE);
		}
		if (strstr(me.ut_host, DOMAIN_CUE) )
		    return(TRUE);
		if (strchr(me.ut_host, '.') == NULL)
		    return(TRUE);
	    }
    }
#endif
    return(FALSE);
}

#ifdef DEBUG
debug(s)
char *s;
{
    if (in_curses) {
	printw("%s\n", s); refresh();
    } else {
	printf("%s\n", s);
    }
    sleep(1);
}
#endif
