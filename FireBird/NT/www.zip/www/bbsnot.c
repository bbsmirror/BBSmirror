#include "Lily-1.0.inc"

int bbs_main() {
   FILE *fp;
   char ArgOfQuery[STRLEN], Board[STRLEN], buf[512], 
	ch, tmp[80], *ptr;
   int  fd, index = 0, n, len, number, total, 
	infont = 0, inblink =0, inbold =0, inunderline =0;
   struct fileheader 	DirInfo;
   struct stat 		st;

   printf("<body>\n");
   printf("<center>\n");

   strncpy(ArgOfQuery, getenv("QUERY_STRING"), STRLEN);
   if (strstr(ArgOfQuery, "..") != NULL)
   {
      printf("Error input!\n");
      exit(1);
   }

   ptr = strchr(ArgOfQuery, '=');
   if (ptr == NULL)
   {
      printf("Error input!\n");
      exit(1);
   }
   number = atoi(ptr + 1);
   ptr[0] = '\0';


   strcpy(Board, ArgOfQuery);

   sprintf(buf, "%s/boards/%s/.DIR", MY_BBS_HOME, Board);
   fd = open(buf, O_RDONLY);
   if (fd == -1)
   {
      fprintf(stderr, "Error in handling file %s\n", buf);
      exit(1);
   }

   printf("<table class=title width=90%%><tr>");
   printf("<th class=title width=33%% align=left>����¼</th>\n");
   printf("<th class=title width=33%% align=center>%s</th>\n", MY_BBS_NAME);
   printf("<th class=title width=34%% align=right>������ [%s]</th>\n",
           Board);
   printf("</table>\n");

   printf("<hr>\n");

   fstat( fd, &st );
   total = st.st_size / sizeof( DirInfo );
   if ((number < 1) || (number > total))
      number = total;

   sprintf(buf, "%s/vote/%s/notes", MY_BBS_HOME, Board);

   if ((fp = fopen(buf, "r")) == NULL)
   {
      printf("<p>�����������ޡ�����¼����</p>\n");
      close(fd);
   }
   else
   {

   printf("<table class=doc>");
   printf("<tr><td class=doc>");
   printf("<pre>\n");

   while( fgets(buf, 512, fp ) != NULL )  hprintf1(buf);
   printf("</pre>\n");
   printf("</table>\n");
   
   fclose(fp);
   }

   printf("<hr>\n");
   printf("<th class=foot><a href=bbssec>����������</a>");
   printf("<th class=foot><a href=bbsall>ȫ��������</a>");
   printf("<th class=foot><a href=bbsdoc?%s=S&Q=%d>��������</a>", 
		Board, number);
   close(fd);
   printf("</table>\n");
   printf("</center>\n"); 

   printf("</body>\n");
}

int hprintf1(char *s) {
  char *s1=0, *s2=0;
  char *ss;
  while(s) {
    s1=strstr(s, "<img ");
    if(s1) {
      s1[0]=0;
      s2=strstr(s1+1, ">");
      s1+=4;
      if(s2) {
        s2[0]=0;
        s2++;
      }
      hprintf2(s);
      printf("<img ");
      while(ss=strcasestr(s1, " ON")) ss[0]=0;
      hprintf(s1);
      printf(">");
      s=s2;
    } else {
      hprintf2(s);
      return 0;
    }
  }
}
int hprintf2(char *s) {
  char *s1=0, *s2=0;
  while(s) {
  s1=strstr(s, "http://");
  if(s1) {
    s1[0]=0;
    s2=strstr(s1+1, " ");
      if(s2) {
        s2[0]=0;
        s2++;
      }
      hprintf(s);
      s1[0]='h';
      printf("<a href=");hprintf(s1);printf(" target=_blank>");hprintf(s1);printf("</a> ");
      s=s2;
    } else {
      hprintf(s);
      return 0;
    }
  }
}

