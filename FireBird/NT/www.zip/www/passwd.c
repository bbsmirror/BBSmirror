#include "lib.a.c"
#define UCSHM 20010

struct UCACHE *uidshm;
struct userec currentuser;
char id[100], pw[100];
int usernum;

char *crypt();
int checkpasswd(char *pw1, char *pw2) {
  return !strcmp(crypt(pw2, pw1), pw1);
}

int check() {
  init_shm();
  usernum=getuser(id, &currentuser);
  if(usernum==-1) return -1;
  if(!checkpasswd(currentuser.passwd, pw)) return -2;
  return 0;
}

init_shm() {
  uidshm = (struct UCACHE*) shm_get(UCSHM, sizeof(uidshm));
}

int getuser(char *id, struct userec *u) {
  int n;
  FILE *fp;
  for(n=0; n<uidshm->number; n++)
    if(!strcasecmp(uidshm->userid[n], id)) {
      strcpy(id, uidshm->userid[n]);
      fp=fopen(".PASSWDS", "r");
      if(fp==NULL) fatal("can't open passwds file!");
      fseek(fp, n*sizeof(*u), SEEK_SET);
      fread(u, sizeof(*u), 1, fp);
      fclose(fp);
      return n;
  }
  return -1;
}

main() {
  char buf1[100], buf2[100];
  chdir(MY_BBS_HOME);
  fgets(buf1, 12, stdin);
  fgets(buf2, 12, stdin);
  str_a(buf1, "\r\n");
  strcpy(id, str_a(0,0));
  str_a(buf2, "\r\n");
  strcpy(pw, str_a(0,0));
  usleep(100000);
  if(check()==0) printf("1");
    else  printf("0");
  exit(0);
}
