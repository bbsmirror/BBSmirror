#include "stdio.h"

main() {
  int n;
  char buf[2049];
  printf("Content-type: text/html; charset=gb2312\n\n\n");
  fread(buf, 1, atoi(getenv("CONTENT_LENGTH")), stdin);
  printf("%s %s\n<br>", buf, getenv("CONTENT_LENGTH")); //buf);
  printf("%s\n", getenv("REQUEST_METHOD"));
}
