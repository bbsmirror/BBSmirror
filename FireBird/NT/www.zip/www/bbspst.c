#include "Lily-1.0.inc"

char *void1(unsigned char *s) {
        int i;
        int flag=0;
        for(i=0; s[i]; i++) {
                if(flag==0) {
                        if(s[i]>=128) flag=1;
                        continue;
                }
                flag=0;
                if(s[i]<32) s[i-1]=32;
        }
        if(flag) s[strlen(s)-1]=0;
        return s;
}

int bbs_main() {
   FILE *fp;
   char ch, ArgOfQuery[STRLEN], LineBuf[256], Board[20], *quser, *ptr, buf[256],
	FileName[20], DirOfBoard[256];
   int  fd, index = 0, number = 0, total, num = 0, newfile = 1, found;
   struct boardheader  brdhdr;
   struct fileheader  DirInfo;
   struct stat st;
   if(!loginok) fatal("�Ҵҹ��Ͳ��ܷ������£����ȵ�¼");
   printf("<center>\n");
   strncpy(ArgOfQuery, getenv("QUERY_STRING"), STRLEN);
   if (strstr(ArgOfQuery, "..") != NULL)
   {
      printf("Error in handling file\n");
      exit(1);
   }
   
   if(ptr = strchr(ArgOfQuery, '='))
   {
      newfile = 0;
      number = atoi(ptr + 1);
      ptr[0] = '\0';
      if (ptr = strchr(ArgOfQuery, '/'))
      {
         strcpy(FileName, ptr + 1);
         ptr[0] = '\0';
      }
   }
   strcpy(Board, ArgOfQuery);   

   printf("<form method=post action=bbssnd>\n");
   printf("<table class=title width=90%%><tr>");
   printf("<th class=title width=33%% align=left>��������</th>\n");
   printf("<th class=title width=33%% align=center>%s</th>\n", MY_BBS_NAME);
   printf("<th class=title width=34%% align=right>������ [%s]</th>\n", Board);
   printf("</table>\n");
   printf("<hr>\n");
   found = 0;
   sprintf(DirOfBoard, "%s/.BOARDS", MY_BBS_HOME);
   if((fd = open(DirOfBoard, O_RDONLY, 0)) == -1)
   {
      printf( ":err: unable to open .BOARDS file.\n" );
      exit(1);
   }
   while (read(fd, &brdhdr, sizeof(brdhdr)) == sizeof(brdhdr))
      if (strcasecmp(brdhdr.filename, Board) == 0)
      {
         found = 1;
         break;
      }
   close(fd);
   if (!found)
   {
      printf( "�Ҳ��������� %s!\n", Board);
      exit(1);
   }

   printf("<input type=hidden name=board value=%s>\n", Board);
   printf("<table class=post>\n");
   printf("<tr><td class=post>ʹ�ñ��� <input type=text name=title size=40 maxlength=100 ");
   printf("value=\"");
   if(!newfile)
   {
      sprintf(DirOfBoard, "%s/boards/", MY_BBS_HOME);
      strcat(DirOfBoard, Board);
      strcat(DirOfBoard, "/.DIR");
      fd = open(DirOfBoard, O_RDONLY);
      if (fd == -1)
      {
         printf("Error in handling file %s!\n", DirOfBoard);
         exit(1);
      }
      while ( sizeof(DirInfo) == read(fd, &DirInfo, sizeof(DirInfo)))
      {
         if(strcmp(DirInfo.filename, FileName) == 0)
         {
            if(strncmp(DirInfo.title, "Re: ", sizeof(char) * 4) != 0)
            	printf("Re: ");
            printf("%s", void1(DirInfo.title));
            break;
         }
      }
      close(fd);
   }

   printf("\"> ");
      printf("<input type=hidden name=anonymous value=N>");
      printf("<input type=radio name=exchange value=Y checked>ת�� ");
      printf("<script>void function help1() {open('/posthelp.html','','width=480; height=300; menubar=no');}</script>"); 
      printf("<input type=radio name=exchange value=N>վ���ż� <a href=javascript:help1()>����</a>");
   printf("<tr><td class=post>���ߣ�%s ", currentuser.userid);
   printf("  ʹ��ǩ���� ");
   printf("<input type=radio name=signature value=1");
   printf(" checked>1");
   printf("<input type=radio name=signature value=2>2");
   printf("<input type=radio name=signature value=3>3");
   printf("<input type=radio name=signature value=0"); 
   printf(">0");
   printf("<tr><td class=post>");
   printf("<textarea name=text rows=20 cols=80 wrap=physicle>\n");

   if (!newfile)
   {
      sprintf(LineBuf, "boards/%s/%s", Board, FileName);

      fp = fopen(LineBuf, "r");
      if (fp == NULL)
      {
         printf("Error in handling file\n");
         exit(1);
      }

      fgets( buf, 256, fp );
      if( (ptr = strrchr( buf, ')' )) != NULL ) {
         ptr[1] = '\0';
         if( (ptr = strchr( buf, ':' )) != NULL ) {
            quser = ptr + 1;
            while( *quser == ' ' )  quser++;
         }
      }
      printf("�� �� %s �Ĵ������ᵽ: ��\n", quser);
      while( fgets( buf, 256, fp ) != NULL )
         if( buf[0] == '\n' )  break;
      while( fgets( buf, 256, fp ) != NULL )
      {
         if( strcmp( buf, "--\n" ) == 0 ) break;
         if(!strncmp(buf, ": : ", 4)) continue;
         if(!strncmp(buf, ": ��", 4)) continue;
         if(!strncmp(trim(buf), "\n", 1)) continue;
         if(!strncmp(trim(buf), ":", 1)) continue;
         printf(": ");
         index = 0;
         while(index < 256 && buf[index] != '\0')
         {
            if(buf[index] != 27)
               putchar(buf[index]);
            else
               while(buf[index] != 'm' && index < 256)
                  index++;
            index++;
            if(index>72 && buf[index]!=0) {
              printf(" ..\n"); 
              break;
            }
         }
      }
   }
   printf("\n\n");
   printf("</textarea>\n");
   printf("<tr><td class=post align=center>");
   printf("<input type=submit value=\"����\">");
   printf(" <input type=reset value=\"���\">\n</table>\n");

   printf("<hr>\n");
   printf("<table class=foot>");
   printf("<th class=foot><a href=\"\">������ҳ</a>");
   printf("<th class=foot><a href=\"bbssec\">����������</a>");
   printf("<th class=foot><a href=\"bbsall\">ȫ��������</a>");
   if (newfile)
      printf("<th class=foot><a href=\"bbsdoc?%s\">��������</a></table>",
		Board);
   else
   {
      printf("<th class=foot>");
      printf("<a href=\"bbsdoc?%s=S&Q=%d\">��������</a></table>", 
		Board, number);
   }
   printf("</center>\n"); 
}
