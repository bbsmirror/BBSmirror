#include "Lily-1.0.inc"

int replylimit=0;
//zhch
int quote_mode;
char *void1(unsigned char *s) {
	int i;
	int flag=0;
	for(i=0; s[i]; i++) {
		if(flag==0) {
			if(s[i]>=128) flag=1;
			continue;
		}
		flag=0;
		if(s[i]<32) s[i-1]=32;
	}
	if(flag) s[strlen(s)-1]=0;
	return s;
}

int bbs_main() {
   FILE *fp;
   char ArgOfQuery[STRLEN], Board[STRLEN], Filename[STRLEN], buf[512], 
	ch, tmp[80], *ptr;
   int  fd, index = 0, n, len, number, quote = 1, total, 
	infont = 0, inblink =0, inbold =0, inunderline =0, signature=0;
   struct fileheader 	DirInfo;
   struct stat 		st;
   printf("<center>\n");
   strncpy(ArgOfQuery, getenv("QUERY_STRING"), STRLEN);
   if (strstr(ArgOfQuery, "..") != NULL) fatal("������ļ���");
   ptr = strchr(ArgOfQuery, '=');
   if (ptr == NULL) fatal("���������");
   number = atoi(ptr + 1); 
   ptr[0] = '\0';
   
   ptr = strchr(ArgOfQuery, '/');
   if (ptr == NULL) fatal("���������");
   strcpy(Filename, ptr + 1);
   if (strlen(Filename) < 5) fatal("���������");
   ptr[0] = '\0';
   strcpy(Board, ArgOfQuery);
   {
     struct boardheader BoardInfo; 
     if(fd = open(".BOARDS", O_RDONLY)==-1) exit(-1);
     while (sizeof(BoardInfo) == read(fd, &BoardInfo, sizeof(BoardInfo))) 
       if (strncasecmp(Board, BoardInfo.filename, STRLEN) == 0) {
         int tmp;
         tmp=BoardInfo.level;
         if (!(tmp==0 || tmp & currentuser.userlevel || tmp & (PERM_POSTMASK | PERM_NOZAP)))  fatal("������������!");
         break;
      }
   close(fd);
   }
   if(!strcmp(Board, "News")) replylimit=1;
   if(!strcmp(Board, "NoticeBoard")) replylimit=1;
   sprintf(buf, "boards/%s/.DIR", Board);
   fd = open(buf, O_RDONLY);
   if (fd == -1) fatal("�������������ڻ�û������");;
   printf("<table class=title width=90%%><tr>");
   printf("<th class=title width=33%% align=left>�����Ķ�</th>\n");
   printf("<th class=title width=33%% align=center>%s</th>\n", MY_BBS_NAME);
   printf("<th class=title width=34%% align=right>������ [%s]</th>\n",
           Board);
   printf("</table>\n");
   printf("<hr>\n");
   fstat( fd, &st );
   total = st.st_size / sizeof( DirInfo );
   if ((number < 1) || (number > total))
      number = total;
   sprintf(buf, "boards/%s/%s", Board, Filename);
   if ((fp = fopen(buf, "r")) == NULL) fatal("���Ĳ����ڻ��ѱ�ɾ��");
   printf("<table class=body width=720>");
   printf("<tr><td class=doc>");
   printf("<pre>\n");
   while( fgets(buf, 512, fp ) != NULL ) {
     if(buf[0]==':') quote_mode=1; else quote_mode=0;
     hprintf1(void1(buf));
   }
   printf("</pre>\n");
   printf("</table>\n");
   fclose(fp);
   printf("<hr>\n");
   printf("<table class=foot><th class=foot><a href=\"bbssec\">����������</a>");
   printf("<th class=foot><a href=\"bbsall\">ȫ��������</a>");
   if (number > 2)
      lseek(fd, (number - 2) * sizeof(DirInfo), SEEK_SET);
   if(strchr(Filename, 'M')) 
	printf("<th class=foot><a onclick='return confirm(\"�����Ҫɾ��������?\")' href='bbsdel?board=%s&num=%d'>ɾ��</a>\n", Board, number);
   if (number > 1)
   {
      read(fd, &DirInfo, sizeof(DirInfo));
      printf("<th class=foot><a href=\"bbscon?%s/%s=%d\">��һƪ</a>", 
                             Board, DirInfo.filename, number - 1);
   }
   printf("<th class=foot><a href=\"bbsdoc?%s=S&Q=%d\">��������</a>", 
		Board, number);
   if (number < total)
   {
      lseek(fd, sizeof(DirInfo), SEEK_CUR);
      read(fd, &DirInfo, sizeof(DirInfo));
      printf("<th class=foot><a href=\"bbscon?%s/%s=%d\">��һƪ</a>", 
                             Board, DirInfo.filename, number + 1);
      lseek(fd, -2 * sizeof(DirInfo), SEEK_CUR);
   }
   read(fd, &DirInfo, sizeof(DirInfo));
   if(!replylimit) printf("<th class=foot><a href=\"bbspst?%s/%s=%d\">������</a>",
                             Board, DirInfo.filename, number);
   close(fd);
   {
     char* buf2;
     buf2= DirInfo.title;
     if(!strncmp(buf2, "Re: ", 4)) buf2+=4;
     printf("<th class=foot><a href='bbsdoc?%s=T&Q=%s'>ͬ�����Ķ�</a>\n", Board, void1(buf2));
   }
   printf("</table>\n");
   printf("</center>\n"); 
   if(number>0&&number<=total) {
     FILE *fp2;
     char buf2[200];
     struct fileheader x;
     int *m;
     sprintf(buf, "boards/%s/.DIR", Board);
     fp2=fopen(buf, "r+");
     fseek(fp2, (number-1)*sizeof(x), SEEK_SET);
     fread(&x, sizeof(x), 1, fp2);
     m=(int*) (x.title+73);
     (*m)++; 
     fseek(fp2, (number-1)*sizeof(x), SEEK_SET);
     fwrite(&x, sizeof(x), 1, fp2);
     fclose(fp2);
   }
}

int hprintf2(char *s) {
  char *s1=0, *s2=0;
  while(s) {
    s1=strstr(s, "http://");
    if(s1) {
      s1[0]=0;
      s2=strstr(s1+1, " ");
      if(s2) { 
        s2[0]=0;
        s2++;
      }
      hprintf(s);
      s1[0]='h';
      printf("<a href=");hprintf(s1);printf(" target=_blank>");hprintf(s1);printf("</a> ");
      s=s2;
    } else {
      hprintf(s);
      return 0;
    }
  }
}

int hprintf1(char *s) {
  char *s1=0, *s2=0;
  char *ss;
  if(quote_mode) {
    hprintf(s);
    return 0;
  }
  while(s) {
    s1=strstr(s, "<img ");
    if(s1) {
      s1[0]=0;
      s2=strstr(s1+1, ">");
      s1+=4;
      if(s2) {
        s2[0]=0;
        s2++;
      }
      hprintf2(s);
      printf("<img ");
      while(ss=strstr(s1, " ON")) ss[0]=0; 
      while(ss=strstr(s1, " on")) ss[0]=0;
      while(ss=strstr(s1, " On")) ss[0]=0;
      while(ss=strstr(s1, " oN")) ss[0]=0;
      hprintf(s1);
      printf(">");
      s=s2;
    } else {
      hprintf2(s);
      return 0;
    }
  }
}


