#include "Lily-1.0.inc"
int bbs_main() {
   FILE *fp;
   char ch, ArgOfQuery[STRLEN], LineBuf[256], Board[20], *quser, *ptr, buf[256],
	FileName[20], DirOfBoard[256];
   int  fd, index = 0, number = 0, total, num = 0, newfile = 1, found;
   struct boardheader  brdhdr;
   static struct fileheader  DirInfo;
   struct stat st;
   if(!loginok) fatal("�Ҵҹ��Ͳ���д��, ���ȵ�¼");
   printf("<body onload='f0.text.focus()'>\n");
   printf("<center>\n");
   strncpy(ArgOfQuery, getenv("QUERY_STRING"), STRLEN);
   if (strstr(ArgOfQuery, "..") != NULL)
   {
      printf("Error in handling file\n");
      exit(1);
   }
   
   if(ptr = strchr(ArgOfQuery, '='))
   {
      newfile = 0;
      number = atoi(ptr + 1);
      ptr[0] = '\0';
      if (ptr = strchr(ArgOfQuery, '/'))
      {
         strcpy(FileName, ptr + 1);
         ptr[0] = '\0';
      }
   }
   strcpy(Board, ArgOfQuery);   

   printf("<form method=post name=f0 action=bbssnd2>\n");
   printf("<table class=title width=90%%><tr>");
   printf("<th class=title width=33%% align=left>�����Ÿ�</th>\n");
   printf("<th class=title width=33%% align=center>%s</th>\n", MY_BBS_NAME);
   printf("<th class=title width=33%% align=right>[%s]</th>\n", currentuser.userid);
   printf("</table>\n");
   printf("<hr>\n");
   found = 0;
   printf("<table class=post>\n");
   printf("<tr><td class=post>ʹ�ñ��� <input type=text name=title size=40 maxlength=100 ");
   printf("value=\"");
   if(!newfile)
   {
      sprintf(DirOfBoard, "%s/mail/%c/%s/.DIR", MY_BBS_HOME, toupper(currentuser.userid[0]), currentuser.userid);
      fd = open(DirOfBoard, O_RDONLY);
      if (fd == -1)
      {
         printf("Error in handling file %s!\n", DirOfBoard);
         exit(1);
      }
      while ( sizeof(DirInfo) == read(fd, &DirInfo, sizeof(DirInfo)))
      {
         if(strcmp(DirInfo.filename, FileName) == 0)
         {
            if(strncmp(DirInfo.title, "Re: ", sizeof(char) * 4) != 0)
            printf("Re: ");
            printf("%s", DirInfo.title);
            break;
         }
      }
      close(fd);
   }

   printf("\"> ");
      printf("<input type=hidden name=anonymous value=N>");
      printf("<input type=radio name=exchange value=Y checked>ת�� ");
      printf("<input type=radio name=exchange value=N>վ���ż�");
   printf("<tr><td class=post>������: &nbsp<input type=text name=board value=%s> �����ˣ�%s ", DirInfo.owner, currentuser.userid);
   printf("  ʹ��ǩ���� ");
   printf("<input type=radio name=signature value=1");
   printf(" checked>1");
   printf("<input type=radio name=signature value=2>2");
   printf("<input type=radio name=signature value=3>3");
   printf("<input type=radio name=signature value=0"); 
   printf(">0");
   printf("<tr><td class=post>");
   printf("<textarea name=text rows=20 cols=80 wrap=physicle>\n");

   if (!newfile)
   {
      sprintf(LineBuf, "mail/%c/%s/%s", toupper(currentuser.userid[0]), currentuser.userid, FileName);

      fp = fopen(LineBuf, "r");
      if (fp == NULL)
      {
         printf("Error in handling file\n");
         exit(1);
      }

      fgets( buf, 256, fp );
      if( (ptr = strrchr( buf, ')' )) != NULL ) {
         ptr[1] = '\0';
         if( (ptr = strchr( buf, ':' )) != NULL ) {
            quser = ptr + 1;
            while( *quser == ' ' )  quser++;
         }
      }
      printf("�� �� %s �Ĵ������ᵽ: ��\n", quser);
      while( fgets( buf, 256, fp ) != NULL )
         if( buf[0] == '\n' )  break;
      while( fgets( buf, 256, fp ) != NULL )
      {
         if( strcmp( buf, "--\n" ) == 0 )
            break;
         printf(": ");
         index = 0;
         while(index < 256 && buf[index] != '\0')
         {
            if(buf[index] != 27)
               putchar(buf[index]);
            else
               while(buf[index] != 'm' && index < 256)
                  index++;
            index++;
         }
      }
   }
   printf("</textarea>\n");
   printf("<tr><td class=post align=center>");
   printf("<input type=submit value=\"����\">");
   printf(" <input type=reset value=\"���\">\n</table>\n");

   printf("<hr>\n");
   printf("<table class=foot>");
   printf("<th class=foot><a href=\"bbssec\">����������</a>");
   printf("<th class=foot><a href=\"bbsall\">ȫ��������</a>");
   if (newfile)
      printf("<th class=foot><a href=\"bbsmail?%s\">��������</a></table>",
		Board);
   else
   {
      printf("<th class=foot>");
      printf("<a href=\"bbsmail?%s=S&Q=%d\">��������</a></table>", 
		Board, number);
   }
   printf("</center>\n"); 
}
