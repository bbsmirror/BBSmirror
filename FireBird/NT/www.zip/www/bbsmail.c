#include "Lily-1.0.inc"

void plustospace(char *str)
{
    register int x;

    for(x=0;str[x];x++) if(str[x] == '+') str[x] = ' ';
}

char x2c(char *what) {
    register char digit;

    digit = (what[0] >= 'A' ? ((what[0] & 0xdf) - 'A')+10 : (what[0] - '0'));
    digit *= 16;
    digit += (what[1] >= 'A' ? ((what[1] & 0xdf) - 'A')+10 : (what[1] - '0'));
    return(digit);
}

void unescape_url(char *url) {
    register int x,y;

    for(x=0,y=0;url[y];++x,++y) {
        if((url[x] = url[y]) == '%') {
            url[x] = x2c(&url[y+1]);
            y+=2;
        }
    }
    url[x] = '\0';
}

void print_title(char *title)
{
    int i;

    for (i = 0; title[i]; i++)
	if (title[i] == '<')
	   printf("&lt;");
	else if (title[i] == '>')
	   printf("&gt;");
	else
	   putchar(title[i]); 
}

void uppercase(char *word)
{
    int i;
    int diff = 'A' - 'a';

    for(i=0; word[i]; i++)
        if((word[i] >= 'a') && (word[i] <= 'z'))
            word[i] += diff;
}

char *id, *getparm();
int bbs_main() {
   FILE *fn;
   char buf[256], Board[STRLEN], ch, *ptr, filename[256], category, 
	ArgOfQuery[STRLEN], *date, QueryString[STRLEN], buf1[256];
   int  i, index, fd, CheckPerm = 0, total, number = 0, start, end, found = 0,
	type;
   struct fileheader  *buffer;
   struct stat st;
   time_t filetime;
#ifdef COLOR_POST_DATE
   struct tm *mytm;
#endif
   if(!loginok) fatal("������ʱ��δ��¼�������µ�¼��");
   id=getparm("id");
   printf("<html>\n");
   strncpy(ArgOfQuery, getenv("QUERY_STRING"), STRLEN);
   if (strstr(ArgOfQuery, "..")||strstr(ArgOfQuery,"./")||strstr(ArgOfQuery,".DIR"))
   {
      printf("Error input!\n");
      exit(1);
   }
   if (ptr = strchr(ArgOfQuery, '='))
   {
      ch = ptr[1];
      strncpy(QueryString, ptr + 5, STRLEN);
      ptr[0] = '\0';
   }
   else
      ch = 'N';

   if (ch == 'B')
   {
      ch = 'N';
      strcpy(ArgOfQuery, QueryString);
   }

   if ((ch == 'S') || (ch == 'U') || (ch == 'D'))
      number = atoi(QueryString); 
   else if (ch != 'N')
   {
      plustospace(QueryString);
      unescape_url(QueryString);
   }
   printf("<link rel=stylesheet type=text/css href=\"%s\">\n", "/bbs/bbstyle3.css");
   printf("<body>\n");
   printf("<center>\n");
   printf("<form action=bbsmail>\n");
   printf("<table class=title width=90%%><tr>");
   printf("<th class=title width=33%% align=left>");
   printf("�û� [%s]", id);
   printf("</th>\n<th class=title width=33%% align=center>%s</th>\n", MY_BBS_NAME);
   printf("<th class=title width=34%% align=right>�ż��б� </th>\n");
   printf("</table>\n");

   sprintf(buf, "%s/mail/%c/%s/.DIR", MY_BBS_HOME, toupper(id[0]), id);
   fd = open(buf, O_RDONLY);
   if (fd == -1)
   {
      fprintf(stderr, "Error in handling file %s!\n", buf);
      exit(1);
   }
   fstat( fd, &st );
   total = st.st_size / sizeof(struct fileheader);
   buffer = (struct fileheader *)calloc(total, sizeof(struct fileheader));
   if (buffer == NULL)
   {
      printf("Out of memory");
      exit(1);
   }
   if (read(fd, buffer, st.st_size) < st.st_size)
   {
      printf("Error reading file %s", buf);
      free(buffer);
      exit(1);
   }
   close(fd);

   if (ch == 'T')
      printf("<p>���� \"%s\" �������\n</p>", QueryString);
   else if (ch == 'W')
      printf("<p>���� \"%s\" �������\n</p>", QueryString);
   else if (ch == 'C')
      printf("<p>�������� \"%s\" �������\n</p>", QueryString); 
   printf("<hr>\n");
   
   if (total == 0 && (ch == 'N' || ch == 'B'))
   {
      printf("��������Ŀǰû������\n");
   }  
   else
   {

      switch (ch){
         case 'U':  start = number - 20;
                    if (start < 1)
                       start = 1;
                    end = start + 19; 
                    if (end > total)
                       end = total;
                    break;
         case 'D':  end = number + 20;  
                    if (end > total)
                       end = total;
                    start = end - 19;
                    if (start < 1)
                       start = 1; 
                    break;
	 case 'T':
	 case 'W':
	 case 'C':
         case 'A':  start = 1;
                    end = total;
                    break;
         case 'S':  if (number < 11)
                    {
                       start = 1; 
                       end = 20;
                       if (end > total)
                          end = total;
                    }  
                    else if (number > total - 10)
                    {
                       end = total;
                       start = end - 19;
                       if (start < 1)
                          start = 1;
                    }
                    else
                    {
                        start = number - 10;
                        end = start + 19; 
                    }
                    break;
         default :  end = total;
                    start = total - 19;
                    if (start < 1)
                        start = 1;
      }
   
      printf("<table class=body>\n");
      printf("<tr><th class=body>���<th class=body>״̬<th class=body>����");
      printf("<th class=body>����<th class=body>����\n");

      uppercase(QueryString);
      i = 0;
      for (index = start; index <= end; index ++)
      {
         if (ch == 'T')
	 {
	    strncpy(buf1, buffer[index -1].title, STRLEN);
	    uppercase(buf1);
	    if (strstr(buf1, QueryString) == NULL)
	       continue;
	 }
	 else if (ch == 'W')
	 {
	    strncpy(buf1, buffer[index -1].owner, STRLEN);
	    uppercase(buf1);
	    if (strcmp(buf1, QueryString))
               continue;
	 }
	 else if (ch == 'C')
	 {
	    sprintf(buf1, "%s/boards/%s/%s", MY_BBS_HOME, ArgOfQuery, 
				buffer[index -1].filename);
	    found = 0;
	    if((fn = fopen(buf1, "r")) == NULL)
	       continue;
	    while(fgets(buf1,256,fn))
	    {
	       if (strstr(buf1, "������:")
		   || strstr(buf1, "��  ��:")
		   || strstr(buf1, "����վ:")
		   || strstr(buf1, "�� �޸�:")
		   || strstr(buf1, "�� ��Դ:")
		   || strstr(buf1,"�Ĵ������ᵽ: ��")
	           || strstr(buf1,"�� ���÷�����:")
        	   || strstr(buf1,"==>[����]:")
    	           || (strstr(buf1,"==>") && strstr(buf1,") �ᵽ:"))
  	           || (strstr(buf1,"�� ��") && strstr(buf1,"���������ᵽ: ��"))
        	   || (strstr(buf1,"==>") && strstr(buf1,"] �����ᵽ:"))
    	           || (strstr(buf1,"==> ��") && strstr(buf1,"���������ᵽ:"))
   	           || (strstr(buf1,"==> �") && strstr(buf1,"��������:"))
       		   || (strstr(buf1,"�� ����") && strstr(buf1,"֮���ԣ�")) )
		  continue;

	       uppercase(buf1);
	       if (strstr(buf1, QueryString))
	       {
		  found = 1;
		  break;
	        }
	    }
	    fclose(fn);
	    if (!found)
	       continue; 	
	 }

         type = ' ';
	 printf("<tr><td class=body%d>%d<td class=body%d>", i % 2 + 1,
			index, i % 2 + 1);
         if (!(buffer[index -1].accessed[0] & FILE_READ))
            type = 'N';
         if (buffer[index -1].accessed[0] & FILE_MARKED)
	    if (type == 'N')
	       type = 'M';
	    else
	       type = 'm';

         putchar(type);
         {
           char *x;
           str_set(buffer[index-1].owner, " (");
           x=str_next();
           printf("<td class=body%d><a href=bbsqry?id2=%s>%s</a>",
		 i % 2 + 1, x, x);
         }
	 filetime = atoi( buffer[index -1].filename + 2 );
	 if( filetime > 740000000 )
	    date = ctime( &filetime ) + 4;
	 else
	    date = "\0";

         printf("<td class=body%d>", i % 2 + 1);
         {
         	struct tm *mytm;
            mytm = localtime(&filetime);
            printf("<font class=col3%d>%15.15s&nbsp;</font>", mytm->tm_wday + 1, date);
         }  
         printf("<td class=body%d><a href=bbsmailcon?%s/%s=%d>", i % 2 + 1,
		ArgOfQuery, buffer[index -1].filename, index);
	 if (strncmp("Re:", buffer[index -1].title, 3) 
	     && strncmp("RE:", buffer[index -1].title, 3))
	    printf("�� ");
         print_title(buffer[index -1].title);
	 printf("</a>");
         i++;
      }
      free(buffer);

      printf("</table>\n");
   }

   printf("<hr>\n");

   printf("<table class=foot>\n");
   printf("<th class=foot><a href=\"bbssec\">����������</a>\n");
   printf("<th class=foot><a href=\"bbsall\">ȫ��������</a>\n");
   if (ch != 'A' && ch != 'T' && ch != 'W' && ch != 'C')
   {
      if (start > 1)
         printf("<th class=foot><a href=\"bbsmail?%s=U&Q=%d\">��һҳ</a>\n", 
		ArgOfQuery, start);
      if (end < total)
         printf("<th class=foot><a href=\"bbsmail?%s=D&Q=%d\">��һҳ</a>\n", 
		ArgOfQuery, end);
      if (total > 20)
         printf("<th class=foot><a href=\"bbsmail?%s=A\">ȫ��</a>\n", 
			ArgOfQuery);
   }
   printf("<th class=foot><a href=bbspst2>д���ż�</a>\n</table>\n");

   printf("<select name=\"%s\">\n", ArgOfQuery);
   printf("<option value=T>��������\n");
   printf("<option value=W>��������\n");
   printf("<option value=C>�����ż�����\n");
   printf("<option value=S>��ת�����\n");
   printf("<option value=B>��ת��������\n");
   printf("</select>\n");

   printf("<input type=text name=Q size=20 maxlength=25>\n");
   printf("</form>\n");
   printf("</center>\n");
}

