#include "Lily-1.0.inc"
char id[20], idle[20];
int pid, dt, num;
int mail_total, mail_unread=0;

int bbs_main() {
	printf("</center><style type=text/css>\n");
	printf("A {color: #0000FF}\n");
	printf("</style>\n");
	num=atoi(getparm("num"));
  	strsncpy(id, getparm("id"), 13);
  	strsncpy(idle, getparm("idle"), 13);
  	dt=abs(time(0)-atoi(idle))/60;
  	if(dt>120) dt=0;
  	if(id[0]==0) strcpy(id, "guest");
  	printf("<body bgcolor=#ic0c0f0>\n");
        if(loginok) {
                pid=shm_utmp->uinfo[num].pid;
                *(time_t *)(shm_utmp->uinfo[num].tty+1)=time(0);
                if(pid>0) kill(pid, SIGINT);
        }
  	printf("ʱ��[%16.16s <a href=bbsmain target=_blank>%s</a>] ", Ctime(time(0)), MY_BBS_NAME);
	printf("����[<a href=bbsusr target=f3>%d</a>] ", count_online());
	printf("�ʺ�[<a href=bbsqry?id2=%s target=f3>%s</a>] ", id, id);
	if(loginok) {
		Ccount_mails(&mail_total, &mail_unread);
		if(mail_unread==0)
			printf("����[<a href=bbsmail?mail target=f3>%d��</a>] ", mail_total);
		if(mail_unread>0)
			printf("����[<a href=bbsmail?mail target=f3>%d(����<font color=red>%d</font>)</a>] ", 
			mail_total, mail_unread);
	}
	printf("ͣ��[%dСʱ%d��]", dt/60, dt%60);
  	printf("<script>setTimeout('self.location=self.location', 60000);</script>");
  	printf("</body>");
}

int Ccount_mails(int *total, int *unread) {
	struct fileheader x1;
	int n;
	FILE *fp;
	if(id[0]==0) return 0;
   	sprintf(genbuf, "%s/mail/%c/%s/.DIR", MY_BBS_HOME, toupper(id[0]), id);
	fp=fopen(genbuf, "r");
	if(fp==0) return;
	while(fread(&x1, sizeof(x1), 1, fp)>0) {
		(*total)++;
		if(!(x1.accessed[0] & FILE_READ)) (*unread)++;
	}
	fclose(fp);
}
