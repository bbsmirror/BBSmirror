#include "Lily-1.0.inc"

int bbs_main() {
   FILE *fp;
   char ArgOfQuery[STRLEN], Board[STRLEN], Filename[STRLEN], buf[512], 
	ch, tmp[80], *ptr;
   int  fd, index = 0, n, len, number, quote = 1, total, 
	infont = 0, inblink =0, inbold =0, inunderline =0, signature=0;
   struct fileheader 	DirInfo;
   struct stat 		st;
   if(!loginok) fatal("��δ��¼���߲�����ʱ�������µ�¼");
   printf("<center>\n");
   strncpy(ArgOfQuery, getenv("QUERY_STRING"), STRLEN);
   if (strstr(ArgOfQuery, "..") != NULL) fatal("error input");
   ptr = strchr(ArgOfQuery, '=');
   if (ptr == NULL)
   {
      printf("Error input!\n");
      exit(1);
   }
   number = atoi(ptr + 1); 
   ptr[0] = '\0';
 
   ptr = strchr(ArgOfQuery, '/');
   if (ptr == NULL)
   {
      printf("Error input!\n");
      exit(1);
   }
   strcpy(Filename, ptr + 1);
   if (strlen(Filename) < 5)
   {
      printf("Error input!\n");
      exit(1);
   }
   ptr[0] = '\0';
   strcpy(Board, ArgOfQuery);
  
  sprintf(buf, "mail/%c/%s/.DIR", toupper(currentuser.userid[0]), currentuser.userid);

  	fp=fopen(buf, "r+");
	if(fp==0) fatal("û���κ��ż�");
	fseek(fp, (number-1)*sizeof(DirInfo), SEEK_SET);
	if(fread(&DirInfo, sizeof(DirInfo), 1, fp)) {
		DirInfo.accessed[0] |=FILE_READ;
		fseek(fp, (number-1)*sizeof(DirInfo), SEEK_SET);
		fwrite(&DirInfo, sizeof(DirInfo), 1, fp);
	}
	fclose(fp);

    fd = open(buf, O_RDONLY);
   if (fd == -1)
   {
      fprintf(stderr, "Error in handling file %s\n", buf);
      exit(1);
   }
   printf("<table class=title width=90%%><tr>");
   printf("<th class=title width=33%% align=left>�Ķ��ż�</th>\n");
   printf("<th class=title width=33%% align=center>%s</th>\n", MY_BBS_NAME);
   printf("<th class=title width=34%% align=right>�û��� [%s]</th>\n",
           currentuser.userid);
   printf("</table>\n");

   printf("<hr>\n");
   fstat( fd, &st );
   total = st.st_size / sizeof( DirInfo );
   if ((number < 1) || (number > total))
      number = total;

   sprintf(buf, "mail/%c/%s/%s", toupper(currentuser.userid[0]), currentuser.userid, Filename);

   if ((fp = fopen(buf, "r")) == NULL)
   {
      printf("Error in handling file %s\n", buf);
      close(fd);
      exit(1);
   }

   printf("<table class=doc>");
   printf("<tr><td class=doc>");
   printf("<pre>\n");

   while( fgets(buf, 512, fp ) != NULL )
   {
      index = 0;
      if (quote && (strstr(buf,"�Ĵ������ᵽ: ��")
          ||strstr(buf,"�� ���÷�����:")
          ||strstr(buf,"==>[����]:")
          ||(strstr(buf,"==>")&&strstr(buf,") �ᵽ:"))
          ||(strstr(buf,"�� ��")&&strstr(buf,"���������ᵽ: ��"))
          ||(strstr(buf,"==>")&&strstr(buf,"] �����ᵽ:"))
          ||(strstr(buf,"==> ��")&&strstr(buf,"���������ᵽ:"))
          ||(strstr(buf,"==> �")&&strstr(buf,"��������:"))
          ||(strstr(buf,"�� ����")&&strstr(buf,"֮���ԣ�"))))
      {
         printf("<font class=col33>%s</font><br>", buf);
	 quote = 0;
      }
      else 
      {
	 if (strcmp(buf, "--\n") == 0)
	    signature = 1;
	 if (buf[0] == ':' || buf[0] == '>')
	    printf("<font class=col36>");
         while (buf[index] != '\0')
         {
            if( buf[index] != 27 || buf[index+1] != '[')
	    {
	       if (buf[index] == '<' && !signature)
		  printf("&lt;");
	       else if (buf[index] == '>' && !signature)
		  printf("&gt;");
	       else
                  putchar(buf[index]);
	       index++;
	    }
            else
            {
               index += 2;
	       n = 0;
               while(buf[index+n] != 'm' && buf[index+n] != '\0')
                  n++;
	       if (buf[index+n] == 'm')
	       {
		  len = (n > 79) ? 79 : (n + 1);
		  strncpy(tmp, buf+ index, len);
		  tmp[len] = '\0';
		  index += n + 1;
		  if (tmp[0] == 'm')
		     strcpy(tmp, "0;");
		  else
		     tmp[len - 1] = ';'; 
		  ptr = strtok(tmp, ";");
		  while (ptr) 
		  {
		     n = atoi(ptr);
		     switch (n) {
			case 0 : if (infont)	/* ״̬��ԭ */
                                    printf("</font>");
                                 if (inblink)
                                    printf("</blink>");
                                 if (inbold)
                                    printf("</b>");
                                 if (inunderline)
                                    printf("</u>");
                                 infont = inblink = inbold = inunderline = 0;
				 break;
			case 1 : if (inbold == 0)	/* ������ */
                                    printf("<b>");
                                 inbold = 1; 
				 break;
			case 4 : if (inunderline == 0)	/* �»��� */
                                    printf("<u>");
                                 inunderline = 1;
				 break;
			case 5 : if (inblink == 0)	/* ��˸ */
                                    printf("<blink>");
                                 inblink = 1;
				 break;
			case 30: if (infont == 1)	/* ��ɫ */
				    printf("</font>");
				 printf("<font class=col30>");
				 infont = 1;
				 break;
			case 31: if (infont == 1)       /* ��ɫ */
                                    printf("</font>");
                                 printf("<font class=col31>");
                                 infont = 1;
                                 break;
			case 32: if (infont == 1)       /* ��ɫ */
                                    printf("</font>");
                                 printf("<font class=col32>");
                                 infont = 1;
                                 break;
			case 33: if (infont == 1)       /* ��ɫ */
                                    printf("</font>");
                                 printf("<font class=col33>");
                                 infont = 1;
                                 break;
                        case 34: if (infont == 1)       /* ��ɫ */
                                    printf("</font>");
                                 printf("<font class=col34>");
                                 infont = 1;
                                 break;
                        case 35: if (infont == 1)       /* �ۺ�ɫ */
                                    printf("</font>");
                                 printf("<font class=col35>");
                                 infont = 1;
                                 break;
			case 36: if (infont == 1)       /* ǳ��ɫ */
                                    printf("</font>");
                                 printf("<font class=col36>");
                                 infont = 1;
                                 break;
                        case 37: if (infont == 1)       /* ��ɫ */
                                    printf("</font>");
                                 printf("<font class=col37>");
                                 infont = 1;
                                 break;
		     }
		     ptr = strtok(NULL, ";");
		  }
		
	       }
	       else
	       {
		  index += n;
	       }

            }
         }
	 if (buf[0] == ':' || buf[0] == '>')
            printf("</font>");

      }
   }
   if (infont)
      printf("</font>");
   if (inblink)
      printf("</blink>");
   if (inbold)
      printf("</b>");
   if (inunderline)
      printf("</u>");

   printf("</pre>\n");
   printf("</table>\n");
   
   fclose(fp);

   printf("<hr>\n");
   printf("<table class=foot><th class=foot><a href=\"bbssec\">����������</a>");
   printf("<th class=foot><a href=\"bbsall\">ȫ��������</a>");
   if (number > 2)
      lseek(fd, (number - 2) * sizeof(DirInfo), SEEK_SET);
   if (number > 1)
   {
      read(fd, &DirInfo, sizeof(DirInfo));
      printf("<th class=foot><a href=\"bbsmailcon?%s/%s=%d\">��һƪ</a>", 
                             Board, DirInfo.filename, number - 1);
   }
	printf("<th class=foot><a onclick='return confirm(\"�����Ҫɾ��������?\")' href='bbsdel?board=mail&num=%d'>ɾ��</a>\n", number);
   printf("<th class=foot><a href=\"bbsmail?%s=S&Q=%d\">�����ż��б�</a>", 
		Board, number);
   if (number < total)
   {
      lseek(fd, sizeof(DirInfo), SEEK_CUR);
      read(fd, &DirInfo, sizeof(DirInfo));
      printf("<th class=foot><a href=\"bbsmailcon?%s/%s=%d\">��һƪ</a>", 
                             Board, DirInfo.filename, number + 1);
      lseek(fd, -2 * sizeof(DirInfo), SEEK_CUR);
   }
   read(fd, &DirInfo, sizeof(DirInfo));
   printf("<th class=foot><a href=\"bbspst2?%s/%s=%d\">����</a>",
                             Board, DirInfo.filename, number);
   close(fd);
   printf("</table>\n");
   printf("</center>\n"); 
}
