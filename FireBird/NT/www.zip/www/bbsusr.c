#include "Lily-1.0.inc"

struct user_info user_record[MAXACTIVE];

void swap_user_record(int a, int b)
{
        struct user_info c;

        memcpy(&c, &user_record[a], sizeof(struct user_info));
        memcpy(&user_record[a], &user_record[b], sizeof(struct user_info));
        memcpy(&user_record[b], &c, sizeof(struct user_info));
}

void sort_user_record(int left, int right)
{
   int i,last;

   if(left>=right)
       return;
   swap_user_record(left,(left+right)/2);
   last=left;
   for(i=left+1;i<=right;i++)
      if(strcasecmp(user_record[i].userid,user_record[left].userid)<0)
         swap_user_record(++last,i);
   swap_user_record(left,last);
   sort_user_record(left,last-1);
   sort_user_record(last+1,right);
}

char *idle_str( uent )
struct user_info *uent ;
{
    static char buf[20];
    sprintf(buf, "%d", (time(0) - *(time_t *)(uent->tty+1))/60);
    if(atoi(buf)==0) buf[0]=0;
    return buf;
}

int bbs_main() {
   int  i, num, fh, shmkey, shmid; 
   struct user_info *uin;
   struct UTMPFILE  *utmpshm;
   printf("<center>\n");

   printf("<table class=title width=90%%><tr>");
   printf("<th class=title align=center>%s -- �����û��б�</th>\n",
           MY_BBS_NAME);
   printf("</table>\n");

   printf("<hr>\n");
   num = 0;
   shmid = shmget(UTMP_SHMKEY, sizeof(struct UTMPFILE), 0 );
   if (shmid >= 0)
   {
      utmpshm = (struct UTMPFILE *) shmat( shmid, 0, 0 );
      if (utmpshm != (struct UTMPFILE *) -1)
      {
         num = 0;
         for( i = 0; i < USHM_SIZE; i++ )
         {
            uin = &(utmpshm->uinfo[ i ]);

            if(!uin->active || !uin->pid || (uin->invisible && !HAS_PERM(PERM_SEECLOAK)))
               continue;
            memcpy(&user_record[num], uin, sizeof(struct user_info));
            num++;
         }
      }
   }

   if (num == 0)
   {
      printf("<p>Ŀǰû���û���վ��</p>\n");
   }
   else
   {
      printf("<table class=body>\n");
      printf("<tr><th class=body>���<th class=body>ʹ���ߴ���");
      printf("<th class=body>ʹ�����ǳ�<th class=body>����<th class=body>");
      printf("��̬<th class=body>ʱ:��\n");

      sort_user_record(0, num - 1);

      for (i = 0; i < num; i++)
      {
         printf("<tr><td class=body%d>%d", i % 2 + 1, i + 1);
	 if(user_record[i].invisible) printf("<font color=green>C</font>");
         printf("<td class=body%d><a href=\"bbsqry?id2=%s\">%s</a>", 
		i % 2 + 1, user_record[i].userid, user_record[i].userid);
         printf("<td class=body%d><a href=\"bbsqry?id2=%s\">%s</a>",
		i % 2 + 1, user_record[i].userid, user_record[i].username);
         printf("<td class=body%d>%s", i % 2 + 1, user_record[i].from);
         printf("<td class=body%d>%s", i % 2 + user_record[i].invisible, ModeType(user_record[i].mode));
         printf("<td class=body%d align=right>%s", i % 2 + 1, idle_str(&user_record[i]));
      }
      
      printf("</table>\n");
   }


   printf("<hr>");
   printf("[<a href=bbssec>����������</a>] ");
   printf("[<a href=bbsall>ȫ��������</a>] ");
   printf("[<a href=bbs0an>����������</a>] ");
   printf("</center>\n");
}
