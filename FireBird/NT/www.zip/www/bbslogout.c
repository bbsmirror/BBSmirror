#include "Lily-1.0.inc"

int bbs_main() {
	int num, login_time;
	if(!strcmp(getparm("id"), "")) fatal("����δ��¼");
	num=atoi(getparm("num"));
  	setcookie("id", "");
  	setcookie("pw", "");
  	setcookie("idle", "");
  	setcookie("key", "");
	setcookie("num", "");
	if(loginok) {
		int pid, stay=0;
		pid=shm_utmp->uinfo[num].pid;
		if(pid>0) kill(pid, SIGHUP);
		shm_utmp->uinfo[num].active=0;
	}
	redirect("bbsmain");
}
