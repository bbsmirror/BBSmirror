#include "Lily-1.0.inc"

char mybrd[22][80];
int mybrdnum=0;
struct shortfile boards[256], tmp1;
int boardnum=0;

int bbs_main() {
	int i, i1, i2, n;
	char buf1[200];
	char *brd;
   	FILE *fp;
	if(!loginok) fatal("��δ��¼���߳�ʱ");
   	sprintf(buf1, "home/%c/%s/mybrds", toupper(currentuser.userid[0]), currentuser.userid);
   	fp=fopen(buf1, "r");
   	if(fp) mybrdnum=fread(mybrd, sizeof(mybrd[0]), 20, fp);
   	if(fp) fclose(fp);
   	printf("<center>\n");
	printf("<style type=text/css>A {color: 000080} </style>\n����Ԥ������������(��ĿǰԤ����%d��������������Ԥ��20��)<hr>\n", mybrdnum);
	printf("<form action=bbsmybrdok method=post>\n");
	printf("<input type=hidden name=confirm1 value=1>\n");
	printf("<table>\n");
	n=0;
	for(i=0; i<MAXBOARD; i++) {
		int level;
		brd=shm_bcache->bcache[i].filename;
		level=shm_bcache->bcache[i].level;
		if(brd[0]==0) continue;
		if(!readperm(level, currentuser.userlevel)) continue;
		memcpy(&boards[boardnum], &shm_bcache->bcache[i], sizeof(boards[0]));
		boardnum++;
	}
	for(i1=0; i1<boardnum; i1++)
	for(i2=0; i2<boardnum; i2++) 
		if(strcasecmp(boards[i1].filename, boards[i2].filename)<0) {
			memcpy(&tmp1, &boards[i1], sizeof(tmp1));
			memcpy(&boards[i1], &boards[i2], sizeof(tmp1));
			memcpy(&boards[i2], &tmp1, sizeof(tmp1));
		}
	for(i=0; i<boardnum; i++) {
		char *buf3="";
		if(is_booked(boards[i].filename)) buf3=" checked";
		if(i%3==0) printf("\n<tr>");
		printf("<td><input type=checkbox name=%s %s><a href=bbsdoc?%s>%s(%s)</a>", 
			boards[i].filename, buf3, boards[i].filename, boards[i].filename, boards[i].title+11);
	}
	printf("</table><hr>\n");
	printf("<input type=submit value=ȷ��Ԥ��> <input type=reset value=��ԭ>\n");
	printf("</form>\n");
}

int is_booked(char *brd) {
	int i;
	for(i=0; i<mybrdnum; i++)
		if(!strcasecmp(brd, mybrd[i])) return 1;
	return 0;
}

int readperm(brdlevel, mylevel) {
	if(brdlevel & PERM_NOZAP || brdlevel & PERM_POSTMASK) return 1;
	if(brdlevel==0) return 1;
	if(brdlevel & mylevel) return 1;
	return 0;
}
