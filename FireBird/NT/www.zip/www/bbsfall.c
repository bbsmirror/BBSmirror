#include "Lily-1.0.inc"

struct user_info user_record[MAXACTIVE];
struct override fff[200];
int friendnum=0;

char id[20];
int bbs_main() {
   int  i, num, fh, shmkey, shmid; 
   struct user_info *uin;
   struct UTMPFILE  *utmpshm;
   char buf1[200];
   FILE *fp;
   int n;
   if(!loginok) fatal("��ʱ��δ��¼��������login");
   sprintf(buf1, "home/%c/%s/friends", toupper(currentuser.userid[0]), currentuser.userid);
   fp=fopen(buf1, "r");
   if(fp) friendnum=fread(fff, sizeof(fff[0]), 200, fp);
   if(fp) fclose(fp);
   printf("<center>\n");
   printf("<table class=title width=90%%><tr>");
   printf("<th class=title align=center>%s -- ���ߺ����б�</th>\n", MY_BBS_NAME);
   printf("</table>\n");
   printf("<hr>\n");
   printf("�����趨�� %d λ����<br>", friendnum);
   printf("<table class=body><tr><td>���<td>���Ѵ���<td>����˵��");
   for(n=0; n<friendnum; n++) printf("<tr><td>%d<td><a href=bbsqry?id2=%s>%s</a><td>%s<br>\n", n+1, fff[n].id, fff[n].id, fff[n].exp);
   printf("</table>");
   printf("</center>\n");
}
