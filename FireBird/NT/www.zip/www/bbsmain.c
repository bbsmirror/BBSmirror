#define DO_NOT_INIT
#include "Lily-1.0.inc"

int main() {
	printf("Content-type: text/html; charset=gb2312\n\n\n");
	printf("
	<html>
	<head><title>%s</title></head>
  	<frameset cols='128,*'>
    	    <frame name=f2 framespacing=2 src=bbsleft>
    	    <frameset rows='*, 20'>
      		<frame framespacing=2 name=f3 src=bbssec>
      		<frame scrolling=no marginwidth=4 marginheight=4 framespacing=2 name=f4 src=bbsfoot>
    	    </frameset>
  	</frameset>
	</html>
", MY_BBS_NAME);
}
