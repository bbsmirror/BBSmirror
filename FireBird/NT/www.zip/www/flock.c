/*
   a flock implemention
   Firebird BBS for Windows NT
   Copyright (C) 2000, COMMAN,Kang Xiao-ning, kxn@student.cs.tsinghua.edu.cn

*/
#include <fcntl.h>
#include <stdio.h>
#define LOCK_EX 2
#define LOCK_NB 4
#define LOCK_UN 8
static struct flock lock = {
  l_whence: SEEK_SET,
  l_start: 0,
  l_len: 0,	
};	
int flock(int fd,int operation)
{
    if (operation & LOCK_EX) lock.l_type = F_WRLCK;
    if (operation & LOCK_UN) lock.l_type = F_UNLCK;
    if (operation & LOCK_NB) return fcntl(fd,F_SETLK,&lock);
        else return fcntl(fd,F_SETLKW,&lock);
}
