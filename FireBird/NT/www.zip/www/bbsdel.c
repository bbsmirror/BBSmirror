#include "Lily-1.0.inc"

int bbs_main() {
	struct shortfile *brd;
	struct fileheader f;
	struct userec *x;
	char id[14], pw[14], board[80], file[80], num[10];
	int n;
	strsncpy(id, getparm("id"), 13);
	strsncpy(pw, getparm("pw"), 13);
	if(!checkuser(id, pw)) fatal("��δ��¼�����������");
	x=getuser(id);
	memcpy(&currentuser, x, sizeof(currentuser));
	strsncpy(board, getparm("board"), 60);
	strsncpy(file, getparm("file"), 20);
	n=atoi(getparm("num"))-1;
	if(!strcasecmp(board, "mail")) {
		sprintf(genbuf, "mail/%c/%s/.DIR", toupper(id[0]), id);
		if(get_record(&f, sizeof(f), n, genbuf)==0) fatal("�Ƿ�����");
		del_record(genbuf, sizeof(f), n);
		sprintf(genbuf, "mail/%c/%s/%s", toupper(id[0]), id, f.filename);
		unlink(genbuf);
		sprintf(genbuf, "bbsmail?mail=U&Q=%d", n+2);
		redirect(genbuf);
	} else {
		char filebuf[256];
		brd=getbcache(board);
		if(brd==0) fatal("�������");
		if(!has_post_perm(&currentuser, board)) fatal("Ȩ�޴���");
		sprintf(genbuf, "boards/%s/.DIR", brd->filename);
		if(get_record(&f, sizeof(f), n, genbuf)==0) fatal("�Ƿ�����");
		if(strcasecmp(id, f.owner)) fatal("����Ȩɾ������");
		del_record(genbuf, sizeof(f), n);
		sprintf(filebuf, "boards/%s/%s", brd->filename, f.filename);
		post_article("junk", f.title, filebuf, f.owner, "", fromhost);
		sprintf(genbuf, "boards/%s/%s", brd->filename, f.filename);
		unlink(genbuf);
		sprintf(genbuf, "bbsdoc?%s=U&Q=%d", board, n+2);
		redirect(genbuf);
		if(strstr(JUNK_BRDS, brd->filename)==0 && x->numposts>0)  {
			x->numposts--;
			save_user_data(x);
		}
	}
	sprintf(genbuf, "%s %s bbsdel %s %d\n", Ctime(time(0)), currentuser.userid, board, n);
	f_append("trace", genbuf);
}
