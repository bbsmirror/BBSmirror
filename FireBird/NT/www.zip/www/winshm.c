/*
    Firebird BBS for Windows NT
    Copyright (C) 2000, COMMAN,Kang Xiao-ning, kxn@student.cs.tsinghua.edu.cn

  A dirty implementation of share memory on Win32 by COMMAN <kxn@263.net>
*/
#include <windows.h>
#include <string.h>
#include "winshm.h"

static SECURITY_ATTRIBUTES sa;
static SECURITY_DESCRIPTOR sd;

int shmget(int key,int size,int shmflg)
{
   HANDLE maphandle;
   char fnbuf1[100];
   sprintf(fnbuf1,"SHM%05X",key);
   InitializeSecurityDescriptor(&sd,SECURITY_DESCRIPTOR_REVISION);
   SetSecurityDescriptorDacl(&sd,TRUE,NULL,TRUE);
   sa.nLength = sizeof (sa);
   sa.lpSecurityDescriptor = &sd;
   sa.bInheritHandle = FALSE;
   if (shmflg & IPC_CREAT)
     maphandle = CreateFileMapping((HANDLE)0xFFFFFFFF,
                                 &sa,
                                 PAGE_READWRITE,
                                 0,
                                 size,
                                 fnbuf1);
   else
        maphandle = OpenFileMapping(FILE_MAP_ALL_ACCESS,FALSE,fnbuf1);
   return maphandle?(int)maphandle:-1;
                                 
}

void *shmat(int shmid,int size,int shmflg)
{
   void *retv;
   retv = MapViewOfFile( (HANDLE) shmid,
                         FILE_MAP_ALL_ACCESS,
                         0,0,
                         size);
   return retv;
}
