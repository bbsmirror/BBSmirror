#include "Lily-1.0.inc"

#define ANONY_FLAG	0x8
#define PERM(x)		((x)?record.userlevel&(x):1)

char *getparm();
int junkboard=0;

int bbs_main ()
{
   FILE *fp, *fidx;
   char idle[20];
   char *buf, *ptr, *ptr1, *pw, article[256], board[20], buf1[256], 
	filename[STRLEN],passwd[20], title[100], username[20], signature[2],
	tmpsig[MAXSIGLINES][256], signfile[STRLEN]; 
   int  fh0, i, color, length, exchange = 1, fh, found = 0, noname = 0, 
	sign, valid_ln, n;
   struct boardheader  brdhdr;
   struct fileheader   header;
   struct userec       record;
   time_t	now;
   strsncpy(username, getparm("id"), 14);
   strsncpy(passwd, getparm("pw"), 14);
   strsncpy(idle, getparm("idle"), 14);
   if(username[0]==0||passwd[0]==0) fatal("�Ҵҹ��Ͳ��ܷ������£����ȵ�¼");
   if(abs(time(0)-atoi(idle))>7200) fatal("������ʱ�������µ�¼");
   strsncpy(board, getparm("board"), 18);
   strsncpy(title, getparm("title"), 50);
   for(n=0; n<strlen(title); n++) if (title[n]==27) title[n]='*';
   sign = atoi(getparm("signature"));
   buf=getparm("text");
   if (title[0] == '\0')
      fatal("����û�б���,���ܷ���!\n");

   if (username[0] != '\0' && passwd[0] != '\0')
   {
      now = time(NULL);
      sprintf(filename, "%s/boards/%s/.DIR", MY_BBS_HOME, board);
      if( (fidx = fopen(filename, "r+" )) == NULL ) {
        if( (fidx = fopen(filename, "w+" )) == NULL ) {
            fatal(":err: unable to post in this board.\n");
        }
      }
      sprintf(filename, "%s/.PASSWDS", MY_BBS_HOME);
      if( (fh0 = open(filename, O_RDWR)) == -1 ) {
        fatal( ":err: unable to open .PASSWDS file.\n" );
      }
      while( read( fh0, &record, sizeof(record) ) > 0 ) 
      {
        if( strcasecmp( username, record.userid ) == 0 ) 
        {
            strcpy( username, record.userid );
	    pw = crypt( passwd, record.passwd );
	    if( strcmp( pw, record.passwd ) != 0 ) 
            {
		fatal("�û������������!\n");
	    }
	    found = 1;
            break;
        }
        memset(&record, 0, sizeof(record));
      } 
      if (!found)
	fatal( "�Ҳ����û���!\n");
      
      found = 0;
      sprintf(filename, "%s/.BOARDS", MY_BBS_HOME);
      if((fh = open(filename, O_RDONLY, 0)) == -1)
	 fatal( ":err: unable to open .BOARDS file.\n" );
      while (read(fh, &brdhdr, sizeof(brdhdr)) == sizeof(brdhdr))
	if (strcasecmp(brdhdr.filename, board) == 0)
	{
	   found = 1;
	   break;
	}
      if (!found)
         fatal( "�Ҳ��������� !\n");

      if (!PERM(PERM_SYSOP)) {
         if (PERM(PERM_SPECIAL8) || !PERM(PERM_POST) || !PERM(brdhdr.level & ~PERM_NOZAP) || PERM(PERM_DENYPOST))
	    fatal("��Ǹ,��û���ڱ��������������µ�Ȩ��!");
	 sprintf(filename, "%s/boards/%s/deny_users", MY_BBS_HOME, board);
	 if (fp = fopen(filename, "r"))
	 {
	   while (fgets(buf1, STRLEN, fp)) 
	      if (strncasecmp(buf1, username, strlen(username)) == 0)
        	fatal("��Ǹ,��û���ڱ��������������µ�Ȩ��!");
	   fclose(fp);
	 }
      }

      if(strstr(JUNK_BRDS, brdhdr.filename)==0) {
           record.numposts++;
           lseek (fh0, -1 * sizeof (record), SEEK_CUR);
           write (fh0, &record, sizeof (record));
      }

	close(fh0);
	close(fh);	
      sprintf(filename, "M.%d.A", now);
      ptr1 = strrchr(filename, 'A' );
      while( 1 ) {
        sprintf( article, "%s/boards/%s/%s", MY_BBS_HOME, board, filename );
        fh = open( article, O_CREAT | O_EXCL | O_WRONLY, 0644 );
        if( fh != -1 )  break;
        if( *ptr1 < 'z' )  (*ptr1)++;
        else  ptr1++, *ptr1 = 'a', ptr1[1] = '\0';
      }

      color=(record.numlogins%7)+31;
      sprintf(buf1, "������: %s (%s), ����: %s\n��  ��: %s\n����վ: %s (%.24s) , %s\n\n", noname?"Anonymous":record.userid, 
		noname?"����������ʹ":record.username, 
		brdhdr.filename, title, MY_BBS_NAME, ctime(&now),
		exchange?"ת��":"վ���ż�");
      write(fh, buf1, strlen(buf1));
      write2(fh, buf, strlen(buf));
      write(fh, "\n\n--\n", 5);
      if (sign)
      {
         sprintf(signfile, "%s/home/%c/%s/signatures", MY_BBS_HOME,
			toupper(record.userid[0]), record.userid);
         if (fp = fopen(signfile, "r"))
         {
            for (i=1; i<=(sign - 1) * MAXSIGLINES; i++)
               if (!fgets(buf1, sizeof(buf1), fp))
                  break;

            for (i=1; i<= MAXSIGLINES; i++)
            {
               if (fgets(buf1, sizeof(buf1), fp))
               {
                  if (buf1[0] != '\n')
                     valid_ln = i;
                  strcpy(tmpsig[i-1], buf1);
               }
               else
                  break;
            }
            fclose(fp);
            for( i = 1; i <= valid_ln; i++)
               write(fh, tmpsig[i - 1], strlen(tmpsig[i - 1]));
         }
      }

      sprintf(buf1, "\n[1;%2dm�� ��Դ:��%s %s [FROM: %.20s][m\n",
			color, MY_BBS_NAME, "http://bbs.nju.edu.cn", 
			getenv("REMOTE_ADDR")); 
      write(fh, buf1, strlen(buf1));
      close(fh);

   }
   else
      fatal("��������ȷ���û���������!\n");
   bzero( (void *)&header, sizeof( header ) );
   strcpy( header.filename, filename);
   header.filename[ STRLEN - 1 ] = 'L';
   header.filename[ STRLEN - 2 ] = 'L';
   strncpy( header.owner, record.userid, IDLEN );
   strncpy( header.title, title, STRLEN );
   flock(fileno(fidx), LOCK_EX);
   fseek(fidx, 0, SEEK_END);
   fwrite(&header, sizeof(header), 1, fidx);
   flock(fileno(fidx), LOCK_UN);
   fclose(fidx);
   sprintf(genbuf, "bbsdoc?%s", board);
   redirect(genbuf);
}

int write2(int fd, unsigned char *buf, int max) {
  int len=0, n;
  unsigned char c;
  for(n=0; n<strlen(buf); n++) {
    c=buf[n];
    len++; 
    write(fd, &c, 1); 
    if(c>159&&buf[n+1]>159) {
      len++;
      write(fd, &buf[n+1], 1);
      n++;
    } 
    if(c==13||c==10) len=0;
    if(len>=78) {
      write(fd, "\n", 1);
      len=0;
    }
  }
}
