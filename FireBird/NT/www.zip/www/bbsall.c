#include "Lily-1.0.inc"

int namesort(const void *board1, const void *board2) {
	struct boardheader *b1, *b2;
	b1=(struct boardheader *) board1;
	b2=(struct boardheader *) board2;
	return (strcasecmp(b1->filename, b2->filename));
}

int bbs_main () {
   char	filename[256], category, *title, *user, *ptr;
   int 	fd, fd1, num, index = 0, total = 0, count;
   struct boardheader 	*buffer;
   struct stat 		st;
   printf("<center>\n");
   printf("ȫ��������\n");
   printf("<hr>\n");
   printf("<table class=body width=720>\n");
   printf("<tr><th class=body>���<th class=body>����������");
   printf("<th class=body>���<th class=body>ת��<th class=body>");
   printf("��������<th class=body>����<th class=body>������</tr>\n");
   fd=open(".BOARDS", O_RDONLY);
   if(fd==-1) fatal("�Ҳ���.BOARDS, �뱨��վ��");
   fstat(fd, &st);
   total = st.st_size / sizeof(struct boardheader);
   buffer = (struct boardheader *)calloc(total, sizeof(struct boardheader));
   if (buffer == NULL) fatal("�ڲ�����, �ڴ����");
   if (read(fd, buffer, st.st_size) < st.st_size) fatal(".BOARDS������");
   close(fd);

   qsort(buffer, total, sizeof(struct boardheader), namesort); 
   num = 0;
   for(index=0; index<total; index++) {
      int tmp;
      tmp=buffer[index].level;
      if (!( tmp & currentuser.userlevel || tmp==0 || tmp & (PERM_POSTMASK | PERM_NOZAP)))
	 continue;
      sprintf(filename, "boards/%s/.DIR", buffer[index].filename);
      fd1= open(filename, O_RDONLY);
      if (fd1 == -1)
         continue;
      fstat( fd1, &st );
      count = st.st_size / sizeof(struct fileheader);
      close(fd1);
      num++; 

      printf("<tr><td class=body%d>", (num - 1) % 2 + 1);
      printf("%d<td class=body%d><a href=\"bbsdoc?%s\">%s</a>", 
	      num, (num - 1) % 2 + 1, buffer[index].filename, buffer[index].filename);
      title = buffer[index].title + 1;
      title[6] = '\0';
      printf("<td class=body%d>%s", (num - 1) % 2 + 1, title);
      title += 7;
      title[2] = '\0';
      printf("<td class=body%d align=center>%s", (num - 1) % 2 + 1, title);
      title += 3;
      printf("<td class=body%d><a href=\"bbsdoc?%s\">%s</a>", 
		(num - 1) % 2 + 1, buffer[index].filename, title);
      printf("<td class=body%d>", (num - 1) % 2 + 1);
      user = buffer[index].BM;
      while (ptr = strchr(user, ' '))
      {
         *ptr = '\0';
         printf("<a href=\"bbsqry?id2=%s\">%s</a> ", user, user);
         user = ptr + 1;
      }
      if (user[0])
         printf("<a href=\"bbsqry?id2=%s\">%s</a>", user, user);
      else
         printf(" ");
      printf("<td class=body%d align=right>%d\n", (num - 1) % 2 + 1, count);
   }
   free(buffer);
   printf("</table>\n");

   printf("<hr>\n");

   printf("</center>\n");
}
