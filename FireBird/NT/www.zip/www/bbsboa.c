#include "Lily-1.0.inc"

int bbs_main() {
	char BoardsFile[256], category, DirOfBoard[256], *title, *user, *ptr;
	int  index, fd, fd1, SectNumber, total, num = 0, all;
	int m, n;
	struct boardheader tmp;
	struct boardheader 	*buffer;
	struct fileheader  	DirInfo;
	struct stat 		st;
	SectNumber=atoi(getparm("sec"));
	printf("<nobr>\n");
	printf("<table class=title width=720><tr>");
	printf("<th class=title width=33%% align=left>[������ѡ��]</th>\n");
	printf("<th class=title width=33%% align=center>%s</th>\n", MY_BBS_NAME);
	printf("<th class=title width=34%% align=right>��� [%s]</th>\n", secname[SectNumber]);
	printf("</table>\n");
	printf("<hr>\n");
	printf("<table class=body width=720>\n");
	printf("<tr><th class=body>���<th class=body>����������<th class=body>����ʱ��");
	printf("<th class=body>���<th class=body>ת��<th class=body>��������");
	printf("<th class=body>����<th class=body>������</tr>\n");
	fd=open(".BOARDS", O_RDONLY);
	if(fd==-1) fatal("�޷���.BOARDS�ļ�, ��֪ͨվ��");
	fstat(fd, &st);
	total=st.st_size/sizeof(struct boardheader);
	buffer=(struct boardheader *)calloc(total, sizeof(struct boardheader));
	if(buffer==NULL) fatal("�ڴ����");
	if(read(fd, buffer, st.st_size) < st.st_size) fatal(".BOARDS�ļ�������");
	close(fd);
	for(m=0; m<total; m++)
	for(n=m+1; n<total; n++) {
		if(strcmp(buffer[m].filename, buffer[n].filename)> 0) {
			memcpy(&tmp, &buffer[m], sizeof tmp);
			memcpy(&buffer[m], &buffer[n], sizeof tmp);
			memcpy(&buffer[n], &tmp, sizeof tmp); 
		}
	}
	for(index=0; index<total; index++) {
		int tmp;
		char* updatetime();
		tmp=buffer[index].level;
		category = buffer[index].title[0];
		if (strchr(seccode[SectNumber], category)==NULL) continue;
		if (!(tmp==0 || tmp & currentuser.userlevel || tmp & (PERM_POSTMASK | PERM_NOZAP))) continue;
		sprintf(DirOfBoard, "boards/");
		strcat(DirOfBoard, buffer[index].filename);
		strcat(DirOfBoard, "/.DIR");
		fd1=open(DirOfBoard, O_RDONLY);
		if (fd1==-1) continue;
		fstat(fd1, &st);
		all=st.st_size/sizeof(DirInfo);
		close(fd1);
		num++;
		printf("<tr><td class=body%d>", (num - 1) % 2 + 1);
		printf("%d<td class=body%d><a href=\"bbsdoc?%s\">%s</a>", 
			num, (num-1)%2+1, buffer[index].filename, buffer[index].filename);
		title=buffer[index].title+1;
		title[6]=0;
		printf("<td class=body%d> %12.12s <td class=body%d>%s", 
			(num-1)%2+1, updatetime(buffer[index].filename)+4, (num - 1) % 2 + 1, title);
		title += 7;
		title[2] = '\0';
		printf("<td class=body%d align=center>%s", (num - 1) % 2 + 1, title);
		title+=3;
		printf("<td class=body%d><a href=\"bbsdoc?%s\">%s</a>", 
		(num-1)%2+1, buffer[index].filename, title);
		printf("<td class=body%d>", (num - 1) % 2 + 1);
		user=buffer[index].BM;
		while(ptr=strchr(user, ' ')) {
		*ptr=0;
		printf("<a href=\"bbsqry?id2=%s\">%s</a> ", user, user);
		user=ptr+1;
	}
	if(user[0])
		printf("<a href=\"bbsqry?id2=%s\">%s</a>", user, user);
	else
		printf(" ");
		printf("<td class=body%d align=right>%d\n", (num - 1) % 2 + 1, all);
	}
	free(buffer);
	printf("</table>\n");
	printf("<hr>");
	printf("<th class=foot><a href=\"bbssec\">����������</a> ");
	printf("<th class=foot><a href=\"bbsall\">ȫ��������</a> ");
	printf("<th class=foot><a href=\"bbs0an\">����������</a> ");
	printf("</center>\n");
}

char* updatetime(char* brd) {
	sprintf(genbuf, "boards/%s", brd);
	return Ctime(file_time(genbuf));
}

