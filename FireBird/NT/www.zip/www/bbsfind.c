#include "Lily-1.0.inc"
char day[20], user[20], title[80];

int bbs_main() {
  strsncpy(user, getparm("user"), 12);
  strsncpy(title, getparm("title"), 50);
  strsncpy(day, getparm("day"), 4);
  if(strlen(day)==0) {
	printf("
		</center>
		<form name=f action=bbsfind>
  		��������: <input name=user type=text maxlength=12 size=12>(���������������)<br>
  		���⺬��: <input name=title type=text maxlength=50 size=50><br>
  		����: <input name=day type=text maxlength=4 size=4 value=7 > �����ڵ�����<br><br>
  		<input type=submit value=ȷ��> 
  		<input type=reset value=����>
		</form>
	");
	quit();
  }
  searchallboard(user, title, atoi(day));
}

int searchallboard(char *id, char *patten, int dt) {
  FILE *fp,*fp2;
  char f[100],buf2[150];
  struct fileheader xx;
  struct boardheader xx2;
  int counts=0,n2=0,n3,now,t0;
  now=time(0);
  printf("%s���²�ѯ��� (����: <a href=bbsqry?id2=%s>%s</a> ����ƥ��: '%s' ʱ��: %d ��)<br><hr>\n",
    MY_BBS_NAME, id, id, patten, dt);
  fp2=fopen(".BOARDS","r");
  if(fp2==NULL) fatal("can't open .BOARDS file");
  dt=dt*86400;
  while(1) {
    if(fread(&xx2, sizeof(xx2), 1, fp2)<=0) break;
    if(xx2.level & PERM_POSTMASK || xx2.level==0 || (xx2.level&PERM_NOZAP)) {
      int n=0;
      sprintf(f, "boards/%s/.DIR", xx2.filename);
      if((fp=fopen(f, "r"))!=NULL) {
        printf("<table>");
        n2=0;
        while(fread(&xx, sizeof(xx), 1, fp)>0) {
          n++;
          t0=atoi(xx.filename+2);
          if((id[0]==0 ||!strcasecmp(xx.owner,id))&&strstr(xx.title,patten)&&abs(now-t0)<dt) {
            if(counts++>999) break;
              n2++;
              printf("<tr><td>%d<td>%s<td>%s<td><a href=bbscon?%s/%s=%d>",
                n, xx.owner, Ctime(t0), xx2.filename, xx.filename, n);
              hprintf(xx.title);
              printf("</a>\n");
          }
        }
        fclose(fp);
        printf("</table>");
        if(n2!=0)
          printf("Above %d are found on board <a href=bbsdoc?%s>%s</a>.<br><br>\n\n",
            n2, xx2.filename, xx2.filename);
      }
    }
  }
  printf("%d matched found.", counts);
  fclose(fp2);
}


