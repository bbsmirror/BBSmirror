#include "Lily-1.0.inc"

int
check_query_mail(qry_mail_dir)
char qry_mail_dir[STRLEN];
{
    struct fileheader fh ;
    struct stat st ;
    int fd ;
    register int offset ;
    register long numfiles ;
    unsigned char ch ;

    offset = (int)((char *)&(fh.accessed[0]) - (char *)&(fh)) ;
    if((fd = open(qry_mail_dir,O_RDONLY)) < 0)
      return 0 ;
    fstat(fd,&st) ;
    numfiles = st.st_size ;
    numfiles = numfiles/sizeof(fh) ;
    if(numfiles <= 0) {
      close(fd) ;
      return 0 ;
    }
    lseek(fd,(off_t)(st.st_size-(sizeof(fh)-offset)),SEEK_SET) ;
    read(fd,&ch,1) ;
    if(!(ch & FILE_READ)) {
        close(fd) ;
        return YEA ;
    }
    close(fd) ;
    return NA ;
}

int bbs_main ()
{
   FILE *fp;
   static char username[IDLEN]; 
   char ArgOfQuery[STRLEN], filename[STRLEN], genbuf[STRLEN], *newline,
        buf[256], tmp[80], *ptr;
   int  i, index, exp, num, perf, fh, found = 0, n, len, quote = 1,
        infont = 0, inblink =0, inbold =0, inunderline =0, shmkey, shmid;
   register int offset;
   struct user_info *uin;
   struct userec record;
   struct UTMPFILE  *utmpshm;

   printf("<center>\n");
   printf("<table class=title width=90%%><tr>");
   printf("<th class=title align=center>%s -- ��ѯ����</th>\n", 
	   MY_BBS_NAME);
   printf("</table>\n");

   printf("<hr>\n");
   strsncpy(ArgOfQuery, getparm("id2"), 20);

   if (ArgOfQuery[0])
   {
      if (strstr(ArgOfQuery, "id="))
         strncpy(username, ArgOfQuery + 3, IDLEN);
      else
         strncpy(username, ArgOfQuery, IDLEN);
         
      sprintf(filename, "%s/.PASSWDS", MY_BBS_HOME);
      if( (fh = open(filename, O_RDONLY)) == -1 ) {
         printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
         printf( ":err: unable to open .PASSWDS file.\n" );
         exit( 0 );
      }
      while (read(fh, &record, sizeof(record)) > 0)
         if( strcasecmp( username, record.userid ) == 0 ) {
            found = 1;
            break;
         }
      close(fh);
   }

   if (!found)
   {

      if (ArgOfQuery[0])
         printf("<p>�û��� <B>[%s]</B> ������!", username);
      else
         printf("<p>�������û���:\n");
      
      printf("<form action=bbsqry>\n");
      printf("<input type=submit value=\"��ѯ�û�\">");
      printf(" <input type=text name=id2 size=%d maxlength=%d>", IDLEN, IDLEN); 
      printf("</form></p>");
   }
   else
   {
      printf("<table class=doc>\n");
      printf("<tr><td class=doc>");

      printf("<font class=col37>%s</font> (<font class=col33>%s</font>) ����վ <font class=col32>%d</font> �Σ������� <font class=col32>%d</font> ƪ����", 
	record.userid, record.username, record.numlogins, record.numposts);
      if (record.userlevel & PERM_SYSOP) printf("[��վվ��]");
      strcpy(genbuf, ctime(&(record.lastlogin)));
      if( (newline = strchr(genbuf, '\n')) != NULL )
         *newline = '\0';
      printf("<br>�ϴ��� [<font class=col32>%s</font>] �� [<font class=col32>%s</font>] ����վһ�Ρ�\n",
	genbuf, (record.lasthost[0] == '\0' ? "(����)" : record.lasthost));

      exp = countexp(&record);
      perf = countperf(&record);
      sprintf(filename, "%s/mail/%c/%s/.DIR", MY_BBS_HOME,
                        toupper(record.userid[0]), record.userid);
      printf("<br>���䣺[<blink><font class=col32>%2s</font></blink>]������ֵ��[<font class=col32>%d</font>](<font class=col33>%s</font>) ����ֵ��[<font class=col32>%d</font>](<font class=col33>%s</font>) ��������[<font class=col32>%d</font>]��\n",
	(check_query_mail(filename)==1)? "��":"  ", exp, cexp(exp),
	perf, cperf(perf), count_life_value(getuser(record.userid)));
        if (record.userlevel & PERM_SPECIAL8) printf("���ѹ�������\n");

      num = 0;

      shmid = shmget(UTMP_SHMKEY, sizeof(struct UTMPFILE), 0 );
      if (shmid >= 0)
      {
         utmpshm = (struct UTMPFILE *) shmat( shmid, 0, 0 );
         if (utmpshm != (struct UTMPFILE *) -1)
         {
            num = 0;
            for( i = 0; i < USHM_SIZE; i++ )
            {
               uin = &(utmpshm->uinfo[ i ]);

               if (strcmp(uin->userid, record.userid) == 0)
               {
                  if(!uin->active || !uin->pid || (uin->invisible && !HAS_PERM(PERM_SEECLOAK)))
                     continue;
                  num++;
                  if (num == 1)
                     printf("<tr><td class=doc>Ŀǰ��վ�ϣ�״̬���£�<br>\n");
		  if(uin->invisible) printf("<font color=green>C</font>");
                  printf("<b>%-14s</b> ", ModeType(uin->mode));
                  if((num)%5==0)
                     printf("<br>\n");
               }
            }

         }
      }

      sprintf(filename, "%s/home/%c/%s/plans", MY_BBS_HOME,
                        toupper(record.userid[0]), record.userid);
      if ((fp = fopen(filename, "r")) == NULL)
      {
         printf("<tr><td class=doc><font class=col36>û�и���˵����</font>\n");
      }
      else
      {
         printf("<tr><td class=doc><pre><font class=col36>����˵�������£�</font>\n");
         while( fgets(buf, 512, fp ) != NULL)
         {
            index = 0;
            while (buf[index] != '\0')
            {
               if( buf[index] != 27 || buf[index+1] != '[')
                  putchar(buf[index++]);
               else
               {
                  index += 2;
                  n = 0;
                  while(buf[index+n] != 'm' && buf[index+n] != '\0')
                     n++;

                 if (buf[index+n] == 'm')
                 {
                    len = (n > 79) ? 79 : (n + 1);
                    strncpy(tmp, buf+ index, len);
                    tmp[len] = '\0';
                    index += n + 1;
                    if (tmp[0] == 'm')
                       strcpy(tmp, "0;");
                    else
                       tmp[len - 1] = ';';
                    ptr = strtok(tmp, ";");
                    while (ptr)
                    {
                       n = atoi(ptr);
                       switch (n) {
                          case 0 : if (infont)    /* ״̬��ԭ */
                                      printf("</font>");
                                   if (inblink)
                                      printf("</blink>");
                                   if (inbold)
                                      printf("</b>");
                                   if (inunderline)
                                      printf("</u>");
                                   infont = inblink = inbold = inunderline = 0;
                                   break;
                          case 1 : if (inbold == 0)       /* ������ */
                                      printf("<b>");
                                   inbold = 1;
                                   break;
                          case 4 : if (inunderline == 0)  /* �»��� */
                                      printf("<u>");
                                   inunderline = 1;
                                   break;
                          case 5 : if (inblink == 0)      /* ��˸ */
                                      printf("<blink>");
                                   inblink = 1;
                                   break;
                          case 30: if (infont == 1)       /* ��ɫ */
                                      printf("</font>");
                                   printf("<font class=col30>");
                                   infont = 1;
                                   break;
                          case 31: if (infont == 1)       /* ��ɫ */
                                      printf("</font>");
                                   printf("<font class=col31>");
                                   infont = 1;
                                   break;
                          case 32: if (infont == 1)       /* ��ɫ */
                                      printf("</font>");
                                   printf("<font class=col32>");
                                   infont = 1;
                                   break;
                          case 33: if (infont == 1)       /* ��ɫ */
                                      printf("</font>");
                                   printf("<font class=col33>");
                                   infont = 1;
                                   break;
                          case 34: if (infont == 1)       /* ��ɫ */
                                      printf("</font>");
                                   printf("<font class=col34>");
                                   infont = 1;
                                   break;
                          case 35: if (infont == 1)       /* �ۺ�ɫ */
                                      printf("</font>");
                                   printf("<font class=col35>");
                                   infont = 1;
                                   break;
                          case 36: if (infont == 1)       /* ǳ��ɫ */
                                      printf("</font>");
                                   printf("<font class=col36>");
                                   infont = 1;
                                   break;
                          case 37: if (infont == 1)       /* ��ɫ */
                                      printf("</font>");
                                   printf("<font class=col37>");
                                   infont = 1;
                                   break;
                       }
                       ptr = strtok(NULL, ";");
                    }

                 }
                 else
                 {
                    index += n;
                 }

              }
           }
        }
        if (infont)
            printf("</font>");
        if (inblink)
           printf("</blink>");
        if (inbold)
           printf("</b>");
        if (inunderline)
           printf("</u>");

        fclose(fp);
        printf("</pre>");
      }
	
        printf("<tr><td><br><br><br><a href=bbspst3?id2=%s>[д���ʺ�]</a> ", record.userid);
	printf("<a href=bbssendmsg?destid=%s>[����ѶϢ]</a> ", record.userid);
        printf("<a href=bbsfadd?id2=%s>[�������]</a> ", record.userid);
        printf("<a href=bbsfdel?id2=%s>[ɾ������]</a>", record.userid);

      printf("</table>\n");
   }
   printf("<hr>");

   printf("<th class=foot><a href=bbssec>����������</a>");
   printf("<th class=foot><a href=bbsall>ȫ��������</a>");
   printf("<th class=foot><a href=bbs0an>����������</a>");

   printf("</center>\n");
   printf("</body>\n");
   printf("</html>");
}
