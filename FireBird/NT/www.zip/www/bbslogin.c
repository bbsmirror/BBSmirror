#include "Lily-1.0.inc"

int bbs_main() {
	int pid, n, t;
	char id[20], pw[20];
	struct userec *x;
	FILE *fp;
	strsncpy(id, getparm("id"), 13);
	strsncpy(pw, getparm("pw"), 13);
	x=getuser(id);
	if(x==0) fatal("������ʺ�");
	if(strcasecmp(id, "guest")) {
		if(!checkpasswd(x->passwd, pw)) fatal("�������");
		if(!user_perm(x, PERM_BASIC)) fatal("���ʺ��ѱ�ͣ��, ��������, ���������ʺ���sysop��ѯ��.");
		t=x->lastlogin;
		x->lastlogin=time(0);
		save_user_data(x);
		if(abs(t-time(0))<5) fatal("���ε�¼�������!");
		x->numlogins++;
		strsncpy(x->lasthost, fromhost, 17);
		save_user_data(x);
	}
	setcookie("id", id);
	setcookie("pw", pw);
	sprintf(genbuf, "%d", time(0));
	setcookie("idle", genbuf);
	sprintf(genbuf, "%s %s %s\n", Ctime(time(0)), x->userid, fromhost);
	f_append("www.log", genbuf);
	sprintf(genbuf, "%s ENTER %12s @%s [www]\n", Ctime(time(0))+4, x->userid, fromhost);
	f_append("usies", genbuf);
	n=0;
	fp=fopen("wwwcounts.dat", "r");
	if(fp) fscanf(fp, "%d", &n);
	if(fp) fclose(fp);
	n++;
	if(!loginok && strcasecmp(id, "guest"))
		wwwlogin(x);
	redirect("bbsmain");
}

int wwwlogin(struct userec *user) {
	int pid, n;
	
	pid=fork();
	if(pid==0) {
		execl("bin/wwwagent", "wwwagent", NULL);
		fatal("bin/wwwagent δ�ҵ�");
	}
	for(n=0; n<MAXACTIVE; n++)
		if(shm_utmp->uinfo[n].active == 0) {
			userinfo=&(shm_utmp->uinfo[n]);
			bzero((void*)userinfo, sizeof(struct user_info));
			userinfo->active=1;
			userinfo->uid=getusernum(user->userid)+1;
			userinfo->pid=pid;
			userinfo->mode=WWW;
			strsncpy(userinfo->from, fromhost, 24);
			strsncpy(userinfo->username, user->username, 20);
			strsncpy(userinfo->userid, user->userid, 13);
			sprintf(genbuf, "%d", n);
			setcookie("num", genbuf);
			sprintf(genbuf, "%d", 10000000 + rand() %1000000);
			strcpy(userinfo->from+40, genbuf);
			setcookie("key", genbuf);
			return 0;
		}
	fatal("��Ǹ��Ŀǰ�����û����Ѵ����ޣ��޷���¼�����Ժ�������");
}
