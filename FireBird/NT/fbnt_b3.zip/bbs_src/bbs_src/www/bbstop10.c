#include "Lily-1.0.inc"

int bbs_main() {
  FILE *fp;
  int n;
  char s1[256], s2[256], s3[256], s4[256],s5;
  char brd[256], id[256], title[256], num[100];
  printf("<center>%s����ʮ����\n<hr>\n", MY_BBS_NAME);
  fp=fopen("etc/posts/day", "r");
  fgets(s1, 255, fp);
  fgets(s1, 255, fp);
  printf("<table class=body>\n");
  printf("<tr><td>����<td>������<td>����<td>����<td>����\n");
  for(n=1; n<=10; n++) {
    fgets(s1, 255, fp);
    sscanf(s1+45, "%s", brd);
    sscanf(s1+122, "%s", id);
    sscanf(s1+102, "%s", num);
    fgets(s1, 255, fp);
    strcpy(title, s1+27);
    title[60]=0;
    safe(brd);
    safe(id);
    safe(num);
    safe(title); 
    printf("<tr><td>��%d ��<td><a href=bbsdoc?%s>%s</a><td><a href='bbsdoc?%s=T&Q=%s'>%s</a><td><a href=bbsqry?id2=%s>%12s</a><td>%s\n",
      n, brd, brd, brd, title, title, id, id, num);
  }
  printf("</table><center>");
}

int safe(char *s) {
  int n;
  for(n=0; n<strlen(s); n++) {
    if(s[n]=='<') s[n]=' ';
    if(s[n]=='>') s[n]=' ';
  } 
}
