#include "Lily-1.0.inc"

char *ptr;

char userid[IDLEN + 1], passwd[PASSLEN + 1], repass[IDLEN + 1], 
     nickname[NAMELEN], realname[NAMELEN], career[STRLEN],
     address[STRLEN], email[NAMELEN], phone[STRLEN], year[5], month[3], day[3];
int gender;

void plustospace(char *str) 
{
    register int x;

    for(x=0;str[x];x++) if(str[x] == '+') str[x] = ' ';
}

char x2c(char *what) {
    register char digit;

    digit = (what[0] >= 'A' ? ((what[0] & 0xdf) - 'A')+10 : (what[0] - '0'));
    digit *= 16;
    digit += (what[1] >= 'A' ? ((what[1] & 0xdf) - 'A')+10 : (what[1] - '0'));
    return(digit);
}

void unescape_url(char *url) {
    register int x,y;

    for(x=0,y=0;url[y];++x,++y) {
        if((url[x] = url[y]) == '%') {
            url[x] = x2c(&url[y+1]);
            y+=2;
        }
    }
    url[x] = '\0';
}

void read_form(char *buf, char *str, char *match, char *next)
{
   int i, length;

   buf = strstr(buf, match); 
   if(buf == NULL || (strstr(buf, next)== NULL)) 
      return;
   else
      buf += strlen(match); 
   length = strlen(next);
   for(i = 0; strncmp(buf + i, next, length); i++)
      str[i] = buf[i];
   str[i] = '\0';    
}

void print_table(char *information)
{
   free(ptr);

   printf("<form method=post action=\"bbsreg\">\n");
   printf("<table class=title width=90%%><tr>");
   printf("<th class=title align=center>%s -- ���û�ע��</th>\n",
           MY_BBS_NAME);
   printf("</table>\n");
   printf("<hr>\n");

   printf("<table class=post>\n");
   printf("<tr><td class=post align=center colspan=3>");
   if (information)
      printf("<font color=""#FF0000"">%s<font color=""#000000"">\n", information);
   else
      printf("���ʵ��д�����ע�����뵥.����������ٵ����Ͻ���������.\n");

   printf("<tr><td class=post align=right>���������:\n");
   printf("<td class=post colspan=2 align=left>");
   printf("<input type=text name=userid size=%d", IDLEN);
   printf(" maxlength=%d value=\"%s\">\n", IDLEN, userid);

   printf("<tr><td class=post align=right>���趨����:\n");
   printf("<td class=post colspan=2 align=left>");
   printf("<input type=password name=passwd size=14 maxlength=%d", PASSLEN);
   printf(" value=\"%s\">\n", passwd);

   printf("<tr><td class=post align=right>������һ������:\n");
   printf("<td class=post colspan=2 align=left>");
   printf("<input type=password name=repass size=14 maxlength=%d", PASSLEN);
   printf(" value=\"%s\">\n", repass);

   printf("<tr><td class=post align=right>�����������ǳ�:\n");
   printf("<td class=post colspan=2 align=left>");
   printf("<input type=text name=nickname size=20 maxlength=%d", NAMELEN);
   printf(" value=\"%s\"> (����:С�ٺ�)\n", nickname);

   printf("<tr><td class=post align=right>������ʵ����(��������):");
   printf("<td class=post colspan=2 align=left>");
   printf("<input type=text name=realname size=20 maxlength=%d", NAMELEN);
   printf(" value=\"%s\"> (վ����������ܵ�!)\n", realname);

   printf("<tr><td class=post align=right>����ѧУϵ��������λ:");
   printf("<td class=post colspan=2 align=left>");
   printf("<input type=text name=career size=50 maxlength=%d", 
		STRLEN - 10);
   printf(" value=\"%s\">\n", career);

   printf("<tr><td class=post align=right>������ϸͨѶ��ַ:\n");
   printf("<td class=post colspan=2 align=left>");
   printf("<input type=text name=address size=50 maxlength=%d", STRLEN - 10);
   printf(" value=\"%s\">\n", address);

   printf("<tr><td class=post align=right>���ĵ�������(��ѡ):");
   printf("<td class=post colspan=2 align=left>");
   printf("<input type=text name=email size=%d", NAMELEN);
   printf(" maxlength=%d value=\"%s\">\n", NAMELEN, email);

   printf("<tr><td class=post align=right>��������绰(��ѡ):");
   printf("<td class=post colspan=2 align=left>");
   printf("<input type=text name=phone size=%d", NAMELEN);
   printf(" maxlength=%d value=\"%s\"> (����������ʱ��)\n", STRLEN, phone);

   printf("<tr><td class=post align=right>��������������:\n");
   printf("<td class=post align=left>");
   printf("<input type=text name=year size=4 maxlength=4");
   printf(" value=\"%s\">��", year);
   printf("<input type=text name=month size=2 maxlength=2");
   printf(" value=\"%s\">��", month);
   printf("<input type=text name=day size=2 maxlength=2");
   printf(" value=\"%s\">��", day);

   printf("<td class=post align=left>�����Ա���: ");
   printf("<input type=radio name=gender value=0");
   if (gender == 0)
      printf(" checked");
   printf(">�� <input type=radio name=gender value=1");
   if (gender == 1)
      printf(" checked");
   printf(">Ů");

   printf("</table><hr>\n");

   printf("<input type=submit value=\"ע��\">");
   printf("<input type=reset value=\"���\">\n");
   printf("</form>\n");
   printf("<center></body>\n</html>\n");
   exit(1);
}

int bbs_main ()
{
   FILE *fp;
   char *buf, *ptr1, *pw, buf1[256], saltc[2], filename[STRLEN];
   int  i, c, length, fh, total, birthyear, birthmonth, birthday;
   long salt;
   struct userec newuser;
   struct stat	st;
   struct tm *tmnow;
   time_t       now;

   printf("<body><center>\n");
   ptr = getenv("CONTENT_LENGTH");
   if (!ptr)
      print_table(NULL);

   length = atoi(ptr);

   ptr = buf = (char *)malloc(length + 1);
   if (buf == NULL)
   {
      cgi_head();
      printf("Out of memory!\n");
      exit(1);
   }
   buf[length] = '\0';
   fread(buf, sizeof(char), length, stdin);
   plustospace(buf);
   unescape_url(buf);

   read_form(buf, userid, "userid=", "&passwd=");
   read_form(buf, passwd, "passwd=", "&repass=");
   read_form(buf, repass, "repass=", "&nickname=");
   read_form(buf, nickname, "nickname=", "&realname=");
   read_form(buf, realname, "realname=", "&career=");
   read_form(buf, career, "career=", "&address=");
   read_form(buf, address, "address=", "&email=");
   read_form(buf, email, "email=", "&phone=");
   read_form(buf, phone, "phone=", "&year=");
   read_form(buf, year, "year=", "&month=");
   read_form(buf, month, "month=", "&day=");
   read_form(buf, day, "day=", "&gender=");

   if((buf = strstr(buf, "gender=")) == NULL)
      gender = 0;
   else
      gender = atoi(buf + 7);

   if (!userid[0])
      print_table("���������!");
   for (i = 0; userid[i]; i++)
      if (!isalpha(userid[i]))
	print_table("���ű���ȫΪӢ����ĸ!");
   if (strlen(userid) < 2)
      print_table("����������������Ӣ����ĸ!\n");
   if (!passwd[0])
      print_table("����������!");
   if (strlen(passwd) < 4 || !strcmp(passwd, userid))
      print_table("����̫�̻���ʹ���ߴ�����ͬ, ����������!");
   if (!repass[0])
      print_table("��������������!");
   if (strcmp(passwd, repass))
      print_table("������������벻һ��!");
   if (!nickname[0] || strlen(nickname) < 2) 
      print_table("�������ǳ�!(�ǳƳ��ȱ������1)");
   if (!realname[0] || strlen(realname) < 3)
      print_table("��������ʵ����!");
   if (!career[0] || strlen(career) < 6)
      print_table("��λ���Ƴ��ȱ������5!");
   if (!address[0] || strlen(address) < 6)
      print_table("ͨѶ��ַ���ȱ������5!");
   
   if(badstr(passwd)||badstr(nickname)||badstr(realname)||badstr(career)||badstr(address)
       ||badstr(email)||badstr(phone))
      print_table("����ע�ᵥ�к��зǷ��ַ�!");
   //by zhch
   /*
   if (!email[0])
      print_table("�������������!");
   if (!strchr(email, '@') || !strchr(email, '.'))
      print_table("���������ʽΪ: user@your.domain.name\n");
   if (!phone[0] || strlen(phone) < 4)
      print_table("��������ϵ�绰!");
   */
   
   if (!year[0] || !month[0] || !day[0])
      print_table("��������������!");
   now = time(NULL);
   tmnow = localtime(&now);
   birthyear = atoi(year);
   birthmonth = atoi(month);
   birthday = atoi(day);
   if (birthyear < 100)
      birthyear += 1900;
   if (birthyear - 1900 <  tmnow->tm_year - 98	/* Too old to BBS */
       || birthyear - 1900 >  tmnow->tm_year - 3 /* Too young :-) */
       || birthmonth < 1 || birthmonth > 12
       || birthday < 1 || birthday > 31)
      print_table("��������������!");

   sprintf(filename, "%s/.badname", MY_BBS_HOME);
   if(fp = fopen(filename, "r" )) {
        char ptr2[20];
        while(fgets( buf1, STRLEN, fp )) {
            ptr1 = strtok( buf1, " \n\t\r" );
            strtolow(ptr2,userid);
            if(strstr(ptr2, ptr1)){
                fclose( fp );
                print_table("ϵͳ���ֻ��ǲ��ŵĴ��š�" );
            }
        }
        fclose(fp);
   }
   
   sprintf(filename, "%s/.PASSWDS", MY_BBS_HOME);
   if( (fh = open(filename, O_RDWR)) == -1 ) {
      free(ptr);
      cgi_head();
      printf( ":err: unable to open .PASSWDS file.\n" );
      exit( 0 );
   }
   fstat(fh, &st);
   total = st.st_size / sizeof(newuser);

   for(i = 0; i < total; i++)
   {
      read(fh, &newuser, sizeof(newuser));
      if( strcasecmp(userid, newuser.userid ) == 0 )
      {
         close(fh);
         print_table("���ʺ��Ѿ�����ʹ��,������ѡ��");
      }
   }

   free(ptr);

   memset(&newuser, 0, sizeof(newuser));

   strncpy(newuser.userid, userid, IDLEN);
   strncpy(newuser.username, nickname, NAMELEN);
   strncpy(newuser.realname, realname, NAMELEN);
   strncpy(newuser.email, email, STRLEN);
   strncpy(newuser.address, address, STRLEN);

   salt = 9 * getpid();
#ifndef lint
   saltc[0] = salt & 077 ;
   saltc[1] = (salt>>6) & 077 ;
#endif
   for(i=0;i<2;i++) {
      c = saltc[i] + '.' ;
      if(c > '9')
         c += 7 ;
      if(c > 'Z')
         c += 6 ;
      saltc[i] = c ;
   }
   ptr1 = crypt(passwd, saltc);

   strncpy(newuser.passwd, ptr1, PASSLEN);

   strcpy(newuser.termtype, "vt100");
   strcpy(newuser.lasthost, getenv("REMOTE_ADDR"));
   newuser.numlogins = 1;
   newuser.numposts = 0;
   if(!strcmp(newuser.userid,"guest"))
      newuser.userlevel = 0;
   else if(!strcmp(newuser.userid,"SYSOP"))
      newuser.userlevel = ~0;
   else
      newuser.userlevel = PERM_BASIC;
   newuser.firstlogin = newuser.lastlogin = time(NULL);
   newuser.userdefine = -1;
   newuser.flags[0]  = CURSOR_FLAG | PAGER_FLAG;
   newuser.flags[1] = 0;

#ifdef FB30
      newuser.birthyear = atoi(year) - 1900;
      newuser.birthmonth = atoi(month);
      newuser.birthday = atoi(day);
      if (gender == 0)
         newuser.gender = 'M';
      else
         newuser.gender = 'F';
#endif

//   flock(fh, LOCK_EX);
   lseek(fh, 0, SEEK_END);
   write(fh, &newuser, sizeof(newuser));
//   flock(fh, LOCK_UN);
   close(fh);

   sprintf(filename, "%s/new_register", MY_BBS_HOME);
   if (fp = fopen(filename, "a"))
   {
      fprintf( fp, "usernum: %d, %s", total + 1, ctime( &now ) );
      fprintf( fp, "userid: %s\n",    userid );
      fprintf( fp, "realname: %s\n",  realname );
      fprintf( fp, "career: %s\n",    career);
      fprintf( fp, "addr: %s\n",      address );
      fprintf( fp, "phone: %s\n",     phone );
      fprintf( fp, "birth: %s��%s��%��\n", year, month, day);
      fprintf( fp, "----\n" );
      fclose(fp);
   }

   sprintf(filename, "%s/%s", MY_BBS_HOME, FLUSH);
   if (fp = fopen(filename, "a"))
   {
      fprintf(fp, "touch by: %s", userid);
      fclose(fp);
   }

   sprintf(filename, "%s/home/%c/%s", MY_BBS_HOME, toupper(userid[0]), userid);
   mkdir(filename, 0755);

   printf("<table class=post>\n");
   printf("<tr><td class=post colspan=2 align=left>");
   printf("������! ����˳����ɱ�վ��ʹ����ע������.<br>\n");
   printf("վ����ܿ��������ע������, �����ĵȺ�.\n</table><hr>");
   printf("<br><br>���Ļ�����������:<br>\n");
   printf("<table>");
   printf("<tr><td>ʹ���ߴ��ţ�\n");
   printf("<td>%s (%s)<br>\n", userid, nickname);
   printf("<tr><td>��  ����\n");
   printf("<td>%s<br>\n", realname);
   printf("<tr><td>��վλ�ã�\n");
   printf("<td>%s<br>\n", newuser.lasthost);
   printf("<tr><td>�����ʼ���\n");
   printf("<td>%s<br></table>\n", email);
   printf("<center><input type=button onclick='window.close()' value=����></center>\n");
   printf("</body>\n");
   printf("</html>");
   newcomer(userid, nickname, newuser.lasthost);
}

int strtolow(char* c1, char*c2)
{
  int n;
  strcpy(c1,c2);
  for(n=0;n<=strlen(c2)-1;n++)
    if(c1[n]>='A'&&c1[n]<='Z')c1[n]+=32;
}

int badstr(char* c1)
{
  int n;
  if(strlen(c1)==0) return 0;
  for(n=0;n<=strlen(c1)-1;n++)
    if(c1[n]==27)return -1;
  return 0;
}

int newcomer(char *id, char *nick, char *host) {
  FILE *fp;
  static struct fileheader header;
  char filename[80];
  time_t now=time(0);
  chdir(MY_BBS_HOME);
  system("./user.flush");
  strcpy(header.owner, id);
  sprintf(header.filename, "M.%d.A", time(0));
  strcpy(header.title, "WWW������·");
  sprintf(filename, "boards/newcomers/%s", header.filename);
  fp=fopen(filename, "w");
  if(fp==NULL) {printf("err"); exit(0);}
  fprintf(fp, "������: %s (%s), ����: newcomers\n��  ��: WWW������·\n����վ: %s (%24.24s)\n\n",id, nick, MY_BBS_NAME, ctime(&now));
  fprintf(fp, "������·������%s, ������.\n", host);
  fclose(fp);
  fp=fopen("boards/newcomers/.DIR", "a");
  fwrite(&header, sizeof(header), 1, fp);
  fclose(fp);
  
}
