#include "Lily-1.0.inc"

int bbs_main() {
  	printf("</center><style type=text/css>A {color: #000080} BODY {BACKGROUND-COLOR: #c0f0c0; FONT-SIZE: 14px;}</style>\n
  		<br>
		<script>
		function closebut(x, y) {
			if(document.all.div0) document.all.div0.style.display='none';
			if(document.all.div1) document.all.div1.style.display='none';
			if(document.all.div2) document.all.div2.style.display='none';
			if(document.all.div3) document.all.div3.style.display='none';
			x.style.display='block';
		}
		function t(x, y) {
			if(x.style.display!='none') {
				x.style.display='none';
			}
			else
				closebut(x, y);
		}
		</script>
	");
	printf("<nobr>\n");
	if(!loginok) {
                printf("<center>
                	<form action=bbslogin method=post target=_top><br>
			bbs�û���¼<br>
                	�ʺ� <input style='height:20px;BACKGROUND-COLOR:e0f0e0' type=text name=id maxlength=12 size=8><br>
                	���� <input style='height:20px;BACKGROUND-COLOR:e0f0e0' type=password name=pw maxlength=12 size=8><br>
                	<input style='width:72px; height:22px; BACKGROUND-COLOR:b0e0b0' type=submit value=��¼��վ>
			</center>
		");
	} else {
                char buf[256]="δע���û�";
		printf("�û�: <a href=bbsqry?id2=%s target=f3>%s</a><br>", currentuser.userid, currentuser.userid);
                if(currentuser.userlevel&PERM_LOGINOK) strcpy(buf, cexp(countexp(&currentuser)));
                if(currentuser.userlevel&PERM_BOARDS) strcpy(buf, "����");
                if(currentuser.userlevel&PERM_SYSOP) strcpy(buf, "��վվ��");
                printf("����: %s<hr style='color:2020f0; height:1px' width=84px align=left>", buf);
                printf("<a href=bbslogout target=_top>ע�����ε�¼</a><br>\n");
	}
  	printf("<hr style='color:2020f0; height=1px' width=84px align=left><br><a href=bbsall target=f3>��������ҳ</a><br>\n");
        printf("<a target=f3 href=bbs0an>����������</a><br>\n");
   	printf("<a target=f3 href=bbstop10>����ʮ��</a><br>\n");
	if(loginok) {
 		FILE *fp;
		int i, mybrdnum=0;
		char mybrd[22][80];
		printf("<a href='javascript: t(document.all.div0, document.img0)'>Ԥ��������</a><br>\n");
		printf("<div id=div0 style='display:none'>\n");
   		sprintf(genbuf, "home/%c/%s/mybrds", toupper(currentuser.userid[0]), currentuser.userid);
   		fp=fopen(genbuf, "r");
   		if(fp) mybrdnum=fread(mybrd, sizeof(mybrd[0]), 20, fp);
   		if(fp) fclose(fp);
  		for(i=0; i<mybrdnum; i++)
     			printf("<a target=f3 href=bbsdoc?%s> %s</a><br>\n", mybrd[i], mybrd[i]);
                printf("<a target=f3 href=bbsmybrd> Ԥ������</a><br>\n");
		printf("</div>\n");
	}
  	printf("
		<a href='javascript: t(document.all.div1, document.img1)'>����������</a><br>
		<div id=div1 style='display:none'>
		<a target=f3 href=bbsboa?sec=0> ��վϵͳ</a><br>
		<a target=f3 href=bbsboa?sec=1> ��УԺϵ</a><br>
		<a target=f3 href=bbsboa?sec=2> �ֵ�ԺУ</a><br>
		<a target=f3 href=bbsboa?sec=3> ���Լ���</a><br>
		<a target=f3 href=bbsboa?sec=4> ѧ����ѧ</a><br>
		<a target=f3 href=bbsboa?sec=5> �Ļ�����</a><br>
		<a target=f3 href=bbsboa?sec=6> �����˶�</a><br>
		<a target=f3 href=bbsboa?sec=7> ��������</a><br>
		<a target=f3 href=bbsboa?sec=8> ����ʱ��</a><br>
		</div>
	");
	printf("<a href='javascript: t(document.all.div2, document.img2)'≯��˵����</a><br>\n");
	printf("<div id=div2 style='display:none'>\n");
  	if(loginok) {
		printf("<a href=bbsfriend target=f3> ���ߺ���</a><br>\n");
	}
  	printf("<a href=bbsusr target=f3> �����ķ�</a><br>\n");
  	printf("<a href=bbsqry target=f3> ��ѯ����</a><br>\n");
        if(currentuser.userlevel & PERM_PAGE) {
                printf("<a href=bbssendmsg target=f3> ����ѶϢ</a><br>\n");
                printf("<a href=bbsmsg target=f3> �鿴����ѶϢ</a><br>\n");
		printf("<a onclick='return confirm(\"�����Ҫ�������ѶϢ��?\")' href=delmsg target=f3>  �������ѶϢ</a><br>\n");
	}
	printf("</div>\n");
	if(loginok)
                printf("
			<a href='javascript: t(document.all.div3, document.img3)'>���˹�����</a><br>
			<div id=div3 style='display:none; font-color:red'>
			<a target=f3 href=bbsinfo> ��������</a><br>
			<a target=f3 href=bbsplan> ��˵����<a><br>
			<a target=f3 href=bbssig> ��ǩ����<a><br>
			<a target=f3 href=bbspwd> �޸�����</a><br>
			<a target=f3 href=bbsform> ��ע�ᵥ</a><br>
			</div>
		");
  	if(loginok) 
		printf("<a href=bbsmail?mail target=f3>�����ż�</a><br>\n");
  	printf("<a href=bbsfind target=f3>���²�ѯ</a><br>\n");
	printf("<a href='telnet:%s'>Telnet��¼</a><br>\n", MY_BBS_IP);
	if(!loginok) 
		printf("<a href=\"javascript:void open('bbsreg', '', 'width=620,height=400')\">���û�ע��</a><br>\n");
   	if(loginok)
		if(count_new_mails()>0) 
			printf("<script>alert('�������ż�!')</script>\n");
  	printf("</body>");
}

int count_new_mails() {
        struct fileheader x1;
        int n, unread=0;
	char genbuf[1024];
        FILE *fp;
        if(currentuser.userid[0]==0) return 0;
        sprintf(genbuf, "mail/%c/%s/.DIR", toupper(currentuser.userid[0]), currentuser.userid);
        fp=fopen(genbuf, "r");
        if(fp==0) return;
        while(fread(&x1, sizeof(x1), 1, fp)>0)
                if(!(x1.accessed[0] & FILE_READ)) unread++;
        fclose(fp);
	return unread;
}
