#include "Lily-1.0.inc"

bbs_main() {
	FILE *fp;
	if(!loginok) fatal("��δ��¼");
	sethomefile(genbuf, currentuser.userid, "msgfile.me");
	fp=fopen(genbuf, "r");
	if(fp==0) fatal("û���κ�ѶϢ");
	printf("<pre>\n");
	while(1) {
		if(fgets(genbuf, 256, fp)<=0) break;
		hprintf(genbuf);
	}
	fclose(fp);
	printf("</pre>");
}
