#include "Lily-1.0.inc"

#define ANONY_FLAG	0x8
#define PERM(x)		((x)?record.userlevel&(x):1)

char *crypt();
char *getparm();
char id[20];

int bbs_main() {
   FILE *fp, *fidx;
   char idle[20];
   char *buf, *ptr, *ptr1, *pw, article[256], board[20], buf1[256], 
	filename[STRLEN],passwd[20], title[100], username[20], signature[2],
	tmpsig[MAXSIGLINES][256], signfile[STRLEN]; 
   int  i, color, length, exchange = 1, fh, found = 0, noname = 0, 
	sign, valid_ln, n;
   struct boardheader  brdhdr;
   struct fileheader   header;
   struct userec       record;
   time_t	now;
   strsncpy(id, getparm("id"), 13);
   strsncpy(username, getparm("id"), 13);
   strsncpy(passwd, getparm("pw"), 13);
   strsncpy(idle, getparm("idle"), 13);
   if(!loginok) fatal("�Ҵҹ��Ͳ��ܷ��ţ����ȵ�¼");
   strsncpy(board, getparm("board"), 18);
   if(strstr(board, "@")) fatal("��Ǹ��Ŀǰ���ܷ���Internet mail.");
   if(getusernum(board)<0) fatal("�����˲�����!"); 
   strsncpy(title, getparm("title"), 50);
   sign = atoi(getparm("signature"));
   buf=getparm("text");
   if (title[0] == '\0') strcpy(title, "û����");
   for(n=0; n<strlen(title); n++) if(title[n]==27) title[n]='*';
   now = time(NULL);
   strsncpy(board, getuser(board)->userid, 15);
   sprintf(filename, "mail/%c/%s/.DIR", toupper(board[0]), board);
   if( (fidx = fopen(filename, "r+" )) == NULL ) {
     if( (fidx = fopen(filename, "w+" )) == NULL ) {
         fatal(":err: unable mail to this user.\n");
     }
   }
   sprintf(filename, "%s/.PASSWDS", MY_BBS_HOME);
   if( (fh = open(filename, O_RDWR)) == -1 ) {
     fatal( ":err: unable to open .PASSWDS file.\n" );
   }
   found = 0;

   sprintf(filename, "M.%d.A", now);
   ptr1 = strrchr(filename, 'A' );
   while( 1 ) {
     sprintf( article, "%s/mail/%c/%s/%s", MY_BBS_HOME, toupper(board[0]), board, filename );
     fh = open( article, O_CREAT | O_EXCL | O_WRONLY, 0644 );
     if( fh != -1 )  break;
     if( *ptr1 < 'z' )  (*ptr1)++;
     else  ptr1++, *ptr1 = 'a', ptr1[1] = '\0';
   }
   color=(record.numlogins%7)+31;
   sprintf(buf1, "������: %s\n��  ��: %s\n����վ: %s (%.24s) , %s\n\n", id, 
		title, MY_BBS_NAME, ctime(&now),
		exchange?"ת��":"վ���ż�");
   write(fh, buf1, strlen(buf1));
   write(fh, buf, strlen(buf));
   write(fh, "\n\n--\n", 5);
   
   sprintf(buf1, "[1;%2dm�� ��Դ:��%sWWW %s. [FROM: %.20s][m\n",
	color, MY_BBS_NAME, MY_BBS_IP, 
	getenv("REMOTE_ADDR")); 
   write(fh, buf1, strlen(buf1));
   close(fh);
   bzero( (void *)&header, sizeof( header ) );
   strcpy( header.filename, filename);
   header.filename[ STRLEN - 1 ] = 'L';
   header.filename[ STRLEN - 2 ] = 'L';
   strsncpy( header.owner, id, 13 );
   strsncpy( header.title, title, 64 );
   flock(fileno(fidx), LOCK_EX);
   fseek(fidx, 0, SEEK_END);
   fwrite(&header, sizeof(header), 1, fidx);
   flock(fileno(fidx), LOCK_UN);
   fclose(fidx);
   printf("�ż����ͳɹ�.<br>");
   printf("<a href=bbsmail>�����ż��б�</a>"); 
}
