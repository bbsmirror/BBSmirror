#include "Lily-1.0.inc"
struct user_info user_record[MAXACTIVE];
struct override fff[200];
int friendnum=0;
char id[20];

int friendno(char *s) {
  int n;
  for(n=0; n<friendnum; n++)
    if(!strcasecmp(s, fff[n].id)) return n;
  return -1;
}

int bbs_main() {
   int  i, num, fh, shmkey, shmid; 
   char id2[20];
   struct user_info *uin;
   struct UTMPFILE  *utmpshm;
   char buf1[200];
   struct userec tmp;
   FILE *fp;
   int n;
   if(!loginok) fatal("��ʱ��δ��¼��������login");
   sprintf(buf1, "home/%c/%s/friends", toupper(currentuser.userid[0]), currentuser.userid);
   fp=fopen(buf1, "r");
   if(fp) friendnum=fread(fff, sizeof(fff[0]), 200, fp);
   if(fp) fclose(fp);
   printf("<center>\n");
   printf("<table class=title width=90%%><tr>");
   printf("<th class=title align=center>%s -- ���ߺ����б�</th>\n", MY_BBS_NAME);
   printf("</table>\n");
   printf("<hr>\n");
   if(friendnum<=0) fatal("��û���趨�κκ���");
   strsncpy(id2, getparm("id2"), 13);
   if(friendno(id2)<0) fatal("���˱����Ͳ�����ĺ���������");
   for(n=friendno(id2); n<friendnum; n++) {
     strcpy(fff[n].id, fff[n+1].id);
     strcpy(fff[n].exp, fff[n+1].exp);
   }
   friendnum--;
   fp=fopen(buf1, "w");
   fwrite(fff, sizeof(fff[0]), friendnum, fp);
   fclose(fp);
   printf("ɾ�����ѳɹ� <a href=bbsfriend>���غ����б�</a>");
}
