#include "Lily-1.0.inc"

int bbs_main() {
   FILE	*inf;
   char filename[256], *ptr, ArgOfQuery[512], buf[STRLEN], 
	title[STRLEN], fname[STRLEN], *user;
   int  index = 0, num = 0, pos;
   struct stat st;
   struct tm   *pt;
  
   printf("<center>\n");
   strncpy(ArgOfQuery, getenv("QUERY_STRING"), 500);
   if (strstr(ArgOfQuery, "..")||strstr(ArgOfQuery, "SYSHome")) fatal("��Ŀ¼������");
   sprintf(filename, "0Announce%s/.Names", ArgOfQuery);
   if(!(inf = fopen(filename, "r"))) fatal("��Ŀ¼�������ļ�, ����վ����ϵ");
   while(fgets(buf, sizeof(buf), inf))
   {
      if(strncmp( buf, "Numb=", 5 ) == 0)
      {
          num = 1;
          break;
      }
   }
   rewind(inf);

   while(fgets( buf, sizeof(buf), inf))
   {
     if (ptr = strchr(buf, '\n')) 
        *ptr = '\0';
     if (strncmp(buf, "# Title=", 8) == 0)
     {
       if (strstr(buf, "BMS") || strstr(buf, "SYSOPS")
				|| strstr(buf, "SECRET"))
       {
          printf("Error input!");
          exit(1);
       } 
       if (ptr = strstr(buf, "(BM: "))
          *ptr = '\0';
       ptr = buf + strlen(buf) - 1;
       while (*ptr == ' ')
	  *ptr-- = '\0';
       printf("������<br>\n");
       printf("<hr>\n");
       printf("<table class=title width=90%><tr>");
       if (num == 0)
       {
          printf("<p><< Ŀǰû������ >>\n</p>");
          exit(1);
       }
       printf("<table class=body>\n");
       printf("<tr><th class=body>���<th class=body>���<th class=body>");
       printf("����<th class=body>����<th class=body>�༭����\n");
     }
     else if( strncmp( buf, "Name=", 5 ) == 0)
     {
       memset(title, 0, STRLEN);
       strncpy(title, buf + 5, sizeof(title));
       if (title[39] != '\0')
       {
	  if (title[38] == '(')
	     user = title + 43;
	  else
             user = title + 39;
	  pos = strlen(user) - 1;
          for (pos = strlen(user) - 1; pos >= 0; pos --)
          {
	     if (user[pos] == ')' || user[pos] == ' ')
                user[pos] = '\0';
             else
                break;
          } 
       }
       else
          user = "\0";
     }
     else if(strncmp(buf, "Path=", 5 ) == 0)
     {
       if(strncmp(buf, "Path=~/", 7 ) == 0) 
          strncpy(fname, buf+7, sizeof(fname));
       else
          strncpy(fname, buf+5, sizeof(fname));
       if(!strstr(title, "BMS") && !strstr(title, "SYSOPS"))
       {
	  pos = 37;
	  while (title[pos] == ' ')
	     title[pos--] = '\0';
          index++;
          printf("<tr><td class=body%d>%d<td class=body%d>", 
			(index - 1) % 2 + 1, index, (index - 1) % 2 + 1);
          sprintf(filename, "%s/0Announce%s/%s", MY_BBS_HOME, ArgOfQuery, fname);
	  if ( stat(filename, &st) != 0)
	  {
	     printf("����<td class=body%d>", (index - 1) % 2 + 1);
             hprintf(title);
             printf("<td class=body%d>%s\n", (index - 1) % 2 + 1);
             if (user[0])
                printf("%s", user);
             else
                printf(" ");
             printf("<td class=body%d> <td class=body%d> \n",
			(index - 1) % 2 + 1, (index - 1) % 2 + 1);
	  }
	  else
	  {
	     if (S_ISREG( st.st_mode))
	     {
		printf("�ļ�");
                printf("<td class=body%d><a href=bbsanc?%s/%s>",
                       (index - 1) % 2 + 1, ArgOfQuery, fname);
	     }
	     else if (S_ISDIR( st.st_mode))
	     {
	        printf("Ŀ¼");
                printf("<td class=body%d><a href=\"bbs0an?%s/%s\">",
                       (index - 1) % 2 + 1, ArgOfQuery, fname);
	     }
             hprintf(title);
             printf("</a><td class=body%d>", (index - 1) % 2 + 1);
             while (ptr = strchr(user, ' '))
             {
                *ptr = '\0';
                printf("<a href=\"bbsqry?id2=%s\">%s</a> ", user, user);
                user = ptr + 1;
             }
             if (user[0])
                printf("<a href=\"bbsqry?id2=%s\">%s</a>", user, user);
             else
                printf(" ");

	     pt = localtime(&(st.st_mtime));
	     pt->tm_year += 1900;
	     printf("<td class=body%d>%04d.%02d.%02d\n", (index - 1) % 2 + 1,
			pt->tm_year, pt->tm_mon+1, pt->tm_mday );
	  }
       }
     }    
   }
  
   fclose(inf);
   printf("</table>\n");

   printf("<hr>\n");
   printf("<a href='javascript:history.go(-1)'>������һҳ</a>");
   printf("</center>\n");
}

