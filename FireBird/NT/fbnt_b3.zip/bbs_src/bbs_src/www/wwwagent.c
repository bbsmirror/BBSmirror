#define DO_NOT_INIT
#include "Lily-1.0.inc"
char myid[20]="guest";

int idle_time;

void add_msg() {
	int i;
	FILE *fp;
	char filebuf[129];
	sprintf(genbuf, "touch home/%c/%s/wwwmsg.flush", toupper(myid[0]), myid);
	system(genbuf);
	sprintf(genbuf, "home/%c/%s/msgfile", toupper(myid[0]), myid);
	i=file_size(genbuf)/129;
	if(get_record(&filebuf, 129, i-1, genbuf)==-1) return;
	sprintf(genbuf, "home/%c/%s/wwwmsg", toupper(myid[0]), myid);
	fp=fopen(genbuf, "a");
	fwrite(filebuf, 129, 1, fp);
	fclose(fp);
}

void add_idle() {
	idle_time=time(0);
}

void abort_program() {
	exit(0);
}

int main(int num, char *arg[]) {
	int n;
	if(num>1) strsncpy(myid, arg[1], 13);
	add_idle();
	for(n=0; n<1024; n++) close(n);
	for(n=0; n<NSIG; n++) signal(n, SIG_IGN);
	signal(SIGINT, add_idle);
	signal(SIGHUP, abort_program);
	signal(SIGUSR2, add_msg);
	while(1) {
		sleep(30);
		if(abs(time(0)-idle_time)>600) exit(0);
	}
}
