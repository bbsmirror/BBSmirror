#include "Lily-1.0.inc"

int bbs_main() {
	static char buf[256], buf2[256]=".";
	char toid[13];
	int topid;
        printf("<style type=text/css>\n");
        printf("A {color: #0000FF}\n");
        printf("</style>\n");
	if(loginok==0) {
		printf("<body style='BACKGROUND-COLOR: #f8f0f0'>");
		quit();
	}
	sethomefile(buf, currentuser.userid, "wwwmsg");
	if(file_size(buf)>0) {
		int total;
		printf("<bgsound src=http://bbs.nju.edu.cn/msg.wav>\n");
		printf("<body onkeypress='checkrmsg(event.keyCode)' style='BACKGROUND-COLOR: #f0ffd0'>");
		total=file_size(buf)/129;
		get_record(buf2, 129, 0, buf);
		del_record(buf, 129, 0);
		printf("<table width=100%>\n");
		printf("<tr><td>");
		buf2[111]=0;
		hprintf(buf2);
		sscanf(buf2+12, "%s", toid);
		sscanf(buf2+122, "%d", &topid);
		printf("<td align=right><a target=f3 href=bbssendmsg?destid=%s&destpid=%d>[��ѶϢ]</a> <a href=getmsg>[����]</a>", toid, topid);
		quit();
	}
	refreshto("bbsgetmsg", 45);
}
