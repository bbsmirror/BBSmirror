#include "Lily-1.0.inc"

int bbs_main () {
	int index;
	printf("<body>\n");
	printf("<center>\n");
	printf("<table class=title width=90%%><tr>");
	printf("<th class=title width=33%% align=left>[����������ѡ��]</th>\n");
	printf("<th class=title width=33%% align=center>%s</th>\n", MY_BBS_NAME); 
	printf("<th class=title width=34%% align=right>���� [%s]</th>\n", MY_BBS_IP);
	printf("</table>\n");
	printf("<hr>\n");
	printf("<table class=body>\n");
	printf("<tr><th class=body>���<th class=body>���<th class=body>����\n");
	for(index=0; index<secnum; index++) {
		printf("<tr><td class=body%d>%d<td class=body%d><a href=bbsboa?sec=%d>", 
			index % 2 + 1, index + 1, index % 2 + 1, index);
		printf("%s</a>", secname[index]);
	}
	printf("</table>\n");
	printf("<hr><table>\n");
	printf("[<a href=bbsall>ȫ��������</a>] ");
	printf("[<a href=bbs0an>����������</a>] ");
	printf("</center>\n");
	printf("</body>\n");
}
