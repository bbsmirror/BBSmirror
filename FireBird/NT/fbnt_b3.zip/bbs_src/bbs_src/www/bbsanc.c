#include "Lily-1.0.inc"

int bbs_main() {
	FILE *fp;
	char ArgOfQuery[512], buf[512], ch, tmp[80], *ptr; 
   	int  index = 0, n, len, infont = 0, inblink =0, inbold =0, inunderline =0,
	quote = 1, signature = 0;
	printf("<center>\n");
	printf("<table class=title width=90%%><tr>");
	printf("<th class=title width=33%% align=left>�����Ķ�</th>\n");
	printf("<th class=title width=33%% align=center>%s</th>\n", MY_BBS_NAME);
	printf("<th class=title width=34%% align=right>������</th>\n");
	printf("</table>\n");
	printf("<hr>\n");
	strncpy(ArgOfQuery, getenv("QUERY_STRING"), 500);
	if (strstr(ArgOfQuery, ".Names")|| strstr(ArgOfQuery, "..")|| strstr(ArgOfQuery, "SYSHome"))
		fatal("������ļ���");
	sprintf(buf, "0Announce%s", ArgOfQuery);
	if ((fp = fopen(buf, "r")) == NULL)
		fatal("������ļ���");
	printf("<table class=doc>");
	printf("<tr><td class=doc>");
	printf("<pre>");
	while(fgets(buf, 256, fp)!=NULL) hprintf(buf);
   	printf("</pre>\n");
  	printf("</table>\n");
   	fclose(fp);
   	printf("<hr>\n");
   	printf("[<a href=bbssec>����������</a>] ");
   	printf("[<a href=bbsall>ȫ��������</a>] </table>");
   	printf("</center>\n"); 
}
