#define DO_NOT_INIT
#include "Lily-1.0.inc"

int main() {
	char data[30];
	printf("Content-type: text/html\n\n");
	strsncpy(data, getparm("data"), 20);
	if(!strcasecmp(data, "top")) {
	printf("
		
	");
	}
}
