#include "Lily-1.0.inc"
FILE *fp;
char file[80];
char buf[10000];

int bbs_main() {
   	if(!loginok) fatal("�Ҵҹ��Ͳ�������˵���������ȵ�¼");
	sprintf(file, "home/%c/%s/plans", toupper(me[0]), me);
	if(!strcasecmp(getparm("mode"), "update")) save_it();
   	printf("<form method=post action=bbsplan?mode=update>\n");
   	printf("<table class=title width=90%%><tr>");
   	printf("<th class=title width=33%% align=left>����˵����</th>\n");
   	printf("<th class=title width=33%% align=center>%s</th>\n", MY_BBS_NAME);
   	printf("<th class=title width=34%% align=right>[%s]</th>\n", me);
   	printf("</table>\n");
   	printf("<hr>\n");
	fp=fopen(file, "r");
	if(fp) {
		char *s;
		fread(buf, 9999, 1, fp);
		if(s=strcasestr(buf, "</textarea>")) s[0]=0;
		fclose(fp);
	}
   	printf("<table>\n<tr><td class=post>");
   	printf("<textarea name=text rows=20 cols=80 wrap=physicle>\n");
	printf(buf);
   	printf(" </textarea>\n");
   	printf("<tr><td class=post align=center>");
   	printf("<input type=submit value=����> ");
   	printf("<input type=reset value=��ԭ>\n</table>\n");
   	printf("<hr>\n");
}

int save_it() {
	fp=fopen(file, "w");
	strsncpy(buf, getparm("text"), 9999);
	fprintf(fp, "%s", buf);
	fclose(fp);
	printf("����˵�����޸ĳɹ���");
	quit();
}
