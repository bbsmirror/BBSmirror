#include <stdio.h>

int ahextoi(char* s)
{
   char *p=s;
   int i=0;
   while (*p==' ') p++;
   while (1) {
        char c;
        c=toupper(*p);
        printf("%d %c",i,c);
        if ((c<='9')&&(c>='0')) {
               i=i*16+c-'0';
        }
        else
        if ((c<='F')&&(c>='A')) {
               i=i*16+10+c-'A';
        }
        else break;
        p++;
   }
   return i;
}
main(argc,argv)
int argc;
char** argv;
{
    FILE* fp;
    int beginnum,endnum,i;
    if (argc<2)
         beginnum=0;
    else
         beginnum=ahextoi(argv[1]);
    if (argc<3)
         endnum=0x0ffff;
    else
         endnum=ahextoi(argv[2]);
    if (!(fp = fopen("chartable","w+")))
        return 1;

    for (i=0;i<endnum-beginnum;i++)
    {
        int ch=i+beginnum;
        fprintf(fp,"   %4X %c%c %c%c",ch,ch/256,ch%256,ch/256,ch%256);
        if (i%5==0) fprintf(fp,"\n");
    }
    fclose(fp);
}

