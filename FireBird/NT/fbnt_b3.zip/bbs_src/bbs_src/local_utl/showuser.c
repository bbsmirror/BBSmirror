#include "bbs.h"
#define PASSWDFILE MY_BBS_HOME "/.PASSWDS"

main()
{
   int fd1,fd2;
   struct userec rec;
   int size1=sizeof(rec);
   int sz,cc;
   char* bp;

    if((fd1 = open(PASSWDFILE,O_RDONLY,0660)) == -1) {
        perror("open PASSWDFILE") ;
        return -1 ;
    }
  
    printf("userec size:%d\n",size1);
    cc=0;
    while(read(fd1,&rec,size1) == size1) {
	printf("%s %s %s %s\n",rec.userid,rec.lasthost,rec.username,rec.email);       
	cc++;
	if (cc>4) break;
    } 
    close(fd1);
}

