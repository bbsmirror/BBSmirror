/*   Filename: correctBM.c      Location: bbs_src/local_utl    */
/*   Compile:  gcc -O2 -o correctBM correctBM.c record.c         */
/*   Assume bbs is in /home/bbs                              */
#include "bbs.h"

#define PASSWDFILE MY_BBS_HOME "/.PASSWDS"
#define BOARDSFILE MY_BBS_HOME "/.BOARDS"
int
report()
{
   return;
}

int
cpuserid(user1,user2)
struct userec *user1;
struct userec *user2;
{
	return !strcmp(user1->userid,user2->userid);
}

main()
{
        FILE *rec;
        struct userec user,user2;
        struct boardheader board;
        int i=0;
        char* ptr;
        char BMstrbuf[ BM_LEN - 1];

        system("cp " PASSWDFILE " passwds.bak");
        rec=fopen(PASSWDFILE,"rb");
        printf("Cleaning Board Manager Permission...\n");
        while(1)
        {
                if(fread(&user,sizeof(user),1,rec)<=0) break;
                i++;
		if (user.userlevel&PERM_BOARDS)
		{
		  user.userlevel&=~PERM_BOARDS;
                  substitute_record(PASSWDFILE,&user,sizeof(user),i);
		  printf("%s...\n",user.userid);
		}
	}
	fclose(rec);
	
        printf("Seting Board Manager Permission...\n");
        rec=fopen(BOARDSFILE,"rb");
        while(1)
        {
                if(fread(&board,sizeof(board),1,rec)<=0) break;
                strcpy(BMstrbuf,board.BM);
	        ptr=strtok(BMstrbuf,",: ;|&()\0\n");
        	while(1)
        	{
           	  if(ptr==NULL)
              	    break;
		  printf("%s...",ptr);
		  strcpy(user2.userid,ptr);
		  i=search_record(PASSWDFILE,&user,sizeof(user),cpuserid,&user2);
		  if (i)
		  {
		    user.userlevel|=PERM_BOARDS;
                    substitute_record(PASSWDFILE,&user,sizeof(user),i);
                    printf("ok\n");
		  }
		  else
		  {
		  	printf("Error...Can't find user\n");
		  }
                  ptr=strtok(NULL,",: ;|&()\0\n");
                }
        }
                
	fclose(rec);
}
