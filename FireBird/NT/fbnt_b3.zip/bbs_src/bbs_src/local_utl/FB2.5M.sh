#!/bin/sh
make chboard
make refriend2
make repassold
repassold
chboard
refriend2
