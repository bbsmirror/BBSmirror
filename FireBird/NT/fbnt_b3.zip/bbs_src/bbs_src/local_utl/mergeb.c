#include <time.h>
#include <stdio.h>
#include "bbs.h"
int report(err)
char* err;
{return printf(err);
}
main(argc,argv)
int argc;
char** argv;
{
  char dir1[256],dir2[256],tmpfile[256];
  struct boardheader bh;
  struct fileheader  fh1,fh2;
  int ssize;
  int id1,id2;
  int num1,num2;
  int time1,time2;
  ssize=sizeof(struct fileheader);

  if (argc<3) {
     printf("Usage:%s board1 board2\n",argv[0]);
     exit(0);
  }
  strcpy(tmpfile,".TMPDIR");
  strncpy(dir1,argv[1],255);
  strcat(dir1,"/.DIR");
  dir1[255]=0;
  strncpy(dir2,argv[2],255);
  strcat(dir2,"/.DIR");
  dir2[255]=0;

  id1=1;
  id2=1;
  printf("get num\n");
  num1=get_num_records(dir1,sizeof(fh1));
  num2=get_num_records(dir2,sizeof(fh2));
  printf("num1=%d,num2=%d\n",num1,num2);
  if (get_record(dir1,&fh1,ssize,id1)==-1)
        time1=99999999999; 
  else
        time1=atoi(&fh1.filename[2]);
 
  if (get_record(dir2,&fh2,ssize,id2)==-1)
        time2=99999999999;
  else
        time2=atoi(&fh2.filename[2]); 
  while ((id1<=num1)||(id2<=num2)) {
       printf("b\n");
       if ((time1<time2)||(id2>num2)) {
                append_record(tmpfile,&fh1,ssize);
                if (get_record(dir1,&fh1,ssize,id1)==-1) {
                    time1=99999999999;
                }
                else
                    time1=atoi(&fh1.filename[2]);
                id1++;
       }
       else 
       {
                if (append_record(tmpfile,&fh2,ssize)) return 0;
                if (get_record(dir2,&fh2,ssize,id2)==-1) {
                    time2=99999999999;
                }
                else
                    time2=atoi(&fh2.filename[2]);
                id2++;
       }
       printf("%d-%s,%d-%s\n",id1,fh1.filename,id2,fh2.filename);
   }
}
