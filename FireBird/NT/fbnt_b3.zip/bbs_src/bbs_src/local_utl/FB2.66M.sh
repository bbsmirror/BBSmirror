#!/bin/sh
make repass266
./repass266
