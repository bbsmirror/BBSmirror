#!/bin/sh
make refriend2
make repassold
repassold
refriend2
