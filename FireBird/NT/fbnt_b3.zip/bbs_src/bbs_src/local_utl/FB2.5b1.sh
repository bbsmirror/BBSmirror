#! /bin/sh
make renotepad
make chboard
make refriend2
make repassold
repassold
renotepad
mv /home/bbs/etc/systempassword /home/bbs/etc/.syspasswd
chboard
refriend2
