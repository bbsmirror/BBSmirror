/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu
    Firebird Bulletin Board System
    Copyright (C) 1996, Hsien-Tsung Chang, Smallpig.bbs@bbs.cs.ccu.edu.tw
                        Peng Piaw Foong, ppfoong@csie.ncu.edu.tw
    Copyright (C) 1999, KCN,Zhou Lin, kcn@cic.tsinghua.edu.cn

    Firebird BBS for Windows NT
    Copyright (C) 2000, COMMAN,Kang Xiao-ning, kxn@student.cs.tsinghua.edu.cn
 
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/

#define EXTERN
#include "bbs.h"
int use_define=0;
extern int iscolor;
extern int enabledbchar;
extern int switch_code();
extern int convcode;

int
modify_user_mode( mode )
int     mode;
{
    uinfo.mode = mode;
    update_ulist( &uinfo, utmpent );
    return 0;
}

int
x_csh()
{
    char        buf[PASSLEN];    
    int save_pager;
    int magic;

    if( !HAS_PERM( PERM_SYSOP ) )
        {
                    return 0 ;
        }
    if(!check_systempasswd())
        {
                return;
        }
    modify_user_mode( SYSINFO );            
    clear();
    getdata(1,0,"������ͨ�а���: ",buf,PASSLEN,NOECHO,NULL,YEA);
    if( *buf == '\0' || !checkpasswd( currentuser.passwd, buf )) {
        prints("\n\n���Ų���ȷ, ����ִ�С�\n");
        pressreturn() ;
        clear() ;
        return;
        }
    randomize();
    magic = rand()%1000;
    prints("\nMagic Key: %d",magic*3-1);
    getdata(4,0,"Your Key : ",buf,PASSLEN,NOECHO,NULL,YEA);
    if( *buf == '\0' || !(atoi(buf)==magic)) {
        securityreport("Fail to shell out");
        prints("\n\nKey ����ȷ, ����ִ�С�\n");
        pressreturn() ;
        clear() ;
        return;
        }
    securityreport("Shell out");
    modify_user_mode( SYSINFO );            
    clear() ;
    refresh() ;
    reset_tty() ;
    save_pager = uinfo.pager;
    uinfo.pager = 0 ;
    update_utmp();
    do_exec("csh", NULL);
    restore_tty() ;
    uinfo.pager = save_pager;
    update_utmp();
    clear() ;
    return 0 ;
}

int
showperminfo( pbits, i )
int     pbits, i;
{
    char        buf[ STRLEN ];

    sprintf( buf, "%c. %-30s %3s", 'A' + i, (use_define)?user_definestr[i]:permstrings[i],
            ((pbits >> i) & 1 ? "ON" : "OFF"));
    move( i+6-(( i>15)? 16:0) , 0+(( i>15)? 40:0) );
    prints( buf );
    refresh();
    return YEA;
}

unsigned int
setperms(pbits,prompt,numbers,showfunc)
unsigned int pbits;
char *prompt;
int numbers;
int (*showfunc)();
{
    int lastperm = numbers - 1;
    int i, done = NA;
    char choice[3];

    move(4,0);
    prints("�밴����Ҫ�Ĵ������趨%s���� Enter ����.\n",prompt);
    move(6,0);
    clrtobot();
/*    pbits &= (1 << numbers) - 1;*/
    for (i=0; i<=lastperm; i++) {
        (*showfunc)( pbits, i,NA);
    }
    while (!done) {
        getdata(t_lines-1, 0, "ѡ��(ENTER ����): ",choice,2,DOECHO,NULL,YEA);
        *choice = toupper(*choice);
        if (*choice == '\n' || *choice == '\0') done = YEA;
        else if (*choice < 'A' || *choice > 'A' + lastperm) bell();
        else {
            i = *choice - 'A';
            pbits ^= (1 << i);
            if((*showfunc)( pbits, i ,YEA)==NA)
            {
                   pbits ^= (1 << i);
            }
        }
    }
    return( pbits );
}

int
x_level()
{
    int id ;
    unsigned int newlevel;

    modify_user_mode( ADMIN );
    if(!check_systempasswd())
    {
        return;
    }
    clear();
    move(0,0) ;
    prints("Change User Priority\n") ;
    clrtoeol() ;
    move(1,0) ;
    usercomplete("Enter userid to be changed: ",genbuf) ;
    if(genbuf[0] == '\0') {
        clear() ;
        return 0 ;
    }
    if(!(id = getuser(genbuf))) {
        move(3,0) ;
        prints("Invalid User Id") ;
        clrtoeol() ;
        pressreturn() ;
        clear() ;
        return 0 ;
    }
    move(1,0);
    clrtobot();
    move(2,0);
    prints("Set the desired permissions for user '%s'\n", genbuf);
    newlevel = setperms(lookupuser.userlevel,"Ȩ��",NUMPERMS,showperminfo);  
    move(2,0);
    if (newlevel == lookupuser.userlevel)
        prints("User '%s' level NOT changed\n", lookupuser.userid);
    else {
        lookupuser.userlevel = newlevel;
        {
		char secu[STRLEN];
                sprintf(secu,"�޸� %s ��Ȩ��",lookupuser.userid);
                securityreport(secu);
         }
        substitute_record(PASSFILE,&lookupuser,sizeof(struct userec),id) ;
        prints("User '%s' level changed\n",lookupuser.userid) ;
    }
    pressreturn() ;
    clear() ;
    return 0 ;
}

int
x_userdefine()
{
    int id ;
    unsigned int newlevel;
    extern int nettyNN;

    modify_user_mode( USERDEF );
    if(!(id = getuser(currentuser.userid))) {
        move(3,0) ;
        prints("�����ʹ���� ID...") ;
        clrtoeol() ;
        pressreturn() ;
        clear() ;
        return 0 ;
    }
    move(1,0);
    clrtobot();
    move(2,0);
    use_define=1;
    newlevel = setperms(lookupuser.userdefine,"����",NUMDEFINES,showperminfo);  
    move(2,0);
    if (newlevel == lookupuser.userdefine)
        prints("����û���޸�...\n");
    else {
        lookupuser.userdefine = newlevel;
        currentuser.userdefine=newlevel;
	if ((!convcode&&!(newlevel&DEF_USEGB))
	    ||(convcode&&(newlevel&DEF_USEGB)))
 		switch_code();
        substitute_record(PASSFILE,&lookupuser,sizeof(struct userec),id) ;
        uinfo.pager|=FRIEND_PAGER;
        if(!(uinfo.pager&ALL_PAGER))
        {
                if(!DEFINE(DEF_FRIENDCALL))
                        uinfo.pager&=~FRIEND_PAGER;
        }
        uinfo.pager&=~ALLMSG_PAGER;
        uinfo.pager&=~FRIENDMSG_PAGER;
        if (DEFINE(DEF_DELDBLCHAR))
            enabledbchar=1;
        else
            enabledbchar=0;
        if(DEFINE(DEF_FRIENDMSG))
        {
                uinfo.pager|=FRIENDMSG_PAGER;
        }
        if(DEFINE(DEF_ALLMSG))
        {
                uinfo.pager|=ALLMSG_PAGER;
                uinfo.pager|=FRIENDMSG_PAGER;
        }
        update_utmp();
        if(DEFINE(DEF_ACBOARD))
                nettyNN=NNread_init();
        prints("�µĲ����趨���...\n\n") ;
    }
    iscolor=(DEFINE(DEF_COLOR))?1:0;
    pressreturn() ;
    clear() ;
    use_define=0;
    return 0 ;
}

int
x_cloak()
{
    modify_user_mode( GMENU ); 
    report("toggle cloak");
    uinfo.invisible = (uinfo.invisible)?NA:YEA ;
    update_utmp();
    if (!uinfo.in_chat) {
        move(1,0) ;
        clrtoeol();
        prints( "������ (cloak) �Ѿ�%s��!",
                (uinfo.invisible) ? "����" : "ֹͣ" ) ;
        pressreturn();
    }
    return 0 ;
}

int
x_state()
{
    char buf[STRLEN];
/*
#if defined(LINUX)
    modify_user_mode( XMENU ); 
    sprintf(buf,"tmp/procinfo.%s",currentuser.userid);
    sprintf(genbuf,"/usr/local/bin/procinfo -F %s",buf);
    system(genbuf);
    ansimore(buf, YEA);
    unlink(buf);
#else
*/
    time_t t;
    double      cpu_load[3];

#if defined(LINUX)
    int         i;
    char        pbuf[256];
    FILE        *fp;
#endif

    modify_user_mode( XMENU ); 
    stand_title("��ʾϵͳ״��");
    move(6,0);
    time(&t);
    prints("Ŀǰϵͳ������ʱ��: %s\n", ctime(&t));
    get_load(cpu_load);
    sprintf(buf,"ϵͳ��� (1,10,15) ���ӵ�ƽ�����ɷֱ�Ϊ [%.2f, %.2f, %.2f]",
           cpu_load[0], cpu_load[1], cpu_load[2]);
    prints("%s\n\n",buf);

 
#if defined(LINUX)
    prints("Ŀǰϵͳ������ʹ��״������:\n");
    if ((fp = fopen("/proc/meminfo", "r")) != NULL)
    {
        for (i=1; i<=3; i++)
        {
        if (fgets(pbuf, sizeof(pbuf), fp))
           prints("%s", pbuf);
        else break;
        }                                                                                                            
    }            
    fclose(fp);
#endif       
    pressreturn();

/* #endif  */
    return FULLUPDATE;
}

void
x_edits()
{
    int aborted;
    char ans[7],buf[STRLEN];
    int ch,num,confirm;
    static char *e_file[]={"plans","signatures","notes","logout",NULL};    
    static char *explain_file[]={"����˵����","ǩ����","�Լ��ı���¼","��վ�Ļ���",NULL};

    modify_user_mode( GMENU ); 
    clear();
    move(1,0);
    prints("���޸��˵���\n\n");
    for(num=0;e_file[num]!=NULL&&explain_file[num]!=NULL;num++)
    {
        prints("[[1;32m%d[m] %s\n",num+1,explain_file[num]);
    }
        prints("[[1;32m%d[m] �������\n",num+1);

    getdata(num+5,0,"��Ҫ������һ����˵���: ",ans,2,DOECHO,NULL,YEA);
    if(ans[0]-'0'<=0 || ans[0]-'0'>num|| ans[0]=='\n'|| ans[0]=='\0')
        return;

    ch=ans[0]-'0'-1;
    setuserfile(genbuf,e_file[ch]);
    move(3,0);
    clrtobot();
    sprintf(buf,"(E)�༭ (D)ɾ�� %s? [E]: ",explain_file[ch]);
    getdata(3,0,buf,ans,2,DOECHO,NULL,YEA);
    if (ans[0] == 'D' || ans[0] == 'd') {
        confirm = askyn("��ȷ��Ҫɾ���������",NA,NA);
        if (confirm != 1){
           move(5, 0);
           prints("ȡ��ɾ���ж�\n");
           pressreturn();
           clear();
           return;
           }
        unlink(genbuf);
        move(5,0);
        prints("%s ��ɾ��\n",explain_file[ch]);
        sprintf(buf,"delete %s",explain_file[ch]);
        report(buf);
        pressreturn();
        clear();
        return;
    }
    modify_user_mode( EDITUFILE);
    aborted = vedit(genbuf, NA);
    clear();
    if (!aborted) {
        prints("%s ���¹�\n",explain_file[ch]);
        sprintf(buf,"edit %s",explain_file[ch]);
        if(!strcmp(e_file[ch],"signatures"))
        {
            set_numofsig();
            prints("ϵͳ�����趨�Լ��������ǩ����...");
        }
        report(buf);
    }else
        prints("%s ȡ���޸�\n",explain_file[ch]);
    pressreturn();
}

void
a_edits()
{
    int aborted;
    char ans[7],buf[STRLEN],buf2[STRLEN];
    int ch,num,confirm;
    static char *e_file[]=
           {"../Welcome","../Welcome2","issue","logout","movie","../vote/notes",
            "menu.ini","../.badname","../.bad_email","../.bansite","../.blockmail",
            "autopost","junkboards","sysops",NULL};    
    static char *explain_file[]=
            {"�����վ������","��վ����","��վ��ӭ��","��վ����","�����"
            ,"���ñ���¼","menu.ini","����ע��� ID","����ȷ��֮E-Mail","������վ֮λַ"
            ,"����E-mail������","ÿ���Զ����ŵ�","����POST���İ�","����������",NULL};

    modify_user_mode( ADMIN ); 
    if(!check_systempasswd())
    {
        return;
    }
    clear();
    move(1,0);
    prints("����ϵͳ����\n\n");
    for(num=0;HAS_PERM(PERM_SYSOP)?e_file[num]!=NULL&&explain_file[num]!=NULL:explain_file[num]!="menu.ini";num++)
    {
        prints("[[1;32m%2d[m] %s\n",num+1,explain_file[num]);
    }
        prints("[[1;32m%2d[m] �������\n",num+1);

    getdata(num+5,0,"��Ҫ������һ��ϵͳ����: ",ans,3,DOECHO,NULL,YEA);
    ch=atoi(ans);
    if(!isdigit(ans[0])||ch<=0 || ch>num|| ans[0]=='\n'|| ans[0]=='\0')
        return;
    ch-=1;        
    sprintf(buf2,"etc/%s",e_file[ch]);
    move(3,0);
    clrtobot();
    sprintf(buf,"(E)�༭ (D)ɾ�� %s? [E]: ",explain_file[ch]);
    getdata(3,0,buf,ans,2,DOECHO,NULL,YEA);
    if (ans[0] == 'D' || ans[0] == 'd') {
       confirm = askyn("��ȷ��Ҫɾ�����ϵͳ��",NA,NA);
       if (confirm != 1){
          move(5, 0);
          prints("ȡ��ɾ���ж�\n");
          pressreturn();
          clear();
          return;
          }
      {
          char        secu[STRLEN];
          sprintf(secu,"ɾ��ϵͳ������%s",explain_file[ch]);
          securityreport(secu);
      }
        unlink(buf2);
        move(5,0);
        prints("%s ��ɾ��\n",explain_file[ch]);
        pressreturn();
        clear();
        return;
    }
    modify_user_mode( EDITSFILE);
    aborted = vedit(buf2, NA);
    clear();
    if (aborted!=-1) {
        prints("%s ���¹�",explain_file[ch]);
        {
          char        secu[STRLEN];
          sprintf(secu,"�޸�ϵͳ������%s",explain_file[ch]);
          securityreport(secu);
        }

        if(!strcmp(e_file[ch],"../Welcome"))
        {
                unlink("Welcome.rec");
                prints("\nWelcome ��¼������");
        }
    }
    pressreturn();
}

void
x_lockscreen() {
    char buf[PASSLEN+1];
    time_t      now;
    
    modify_user_mode( LOCKSCREEN );
    move(9,0);
    clrtobot();
    update_endline();
    buf[0]='\0';
    now=time(0);
    move(9,0);
    prints ("\n[1;37m       _       _____   ___     _   _   ___     ___       __");
    prints ("\n      ( )     (  _  ) (  _`\\  ( ) ( ) (  _`\\  (  _`\\    |  |");
    prints ("\n      | |     | ( ) | | ( (_) | |/'/' | (_(_) | | ) |   |  |");
    prints ("\n      | |  _  | | | | | |  _  | , <   |  _)_  | | | )   |  |");
    prints ("\n      | |_( ) | (_) | | (_( ) | |\\`\\  | (_( ) | |_) |   |==|"); 
    prints ("\n      (____/' (_____) (____/' (_) (_) (____/' (____/'   |__|[m\n");
    prints ("\n[1;36mөĻ����[33m %19s[36m ʱ��[32m %-12s [36m��ʱ��ס��...[m",ctime(&now),currentuser.userid);
    while( *buf == '\0' || !checkpasswd( currentuser.passwd, buf )) {
        move (18,0);
        clrtobot();
        update_endline();
        getdata(19,0,"��������������Խ���: ",buf,PASSLEN,NOECHO,NULL,YEA);
    }
}            

heavyload()
{
    double cpu_load[3];

    get_load(cpu_load);
    if(cpu_load[0]>10)
       return 1;
    else return 0;   
}

void
exec_cmd( umode, pager, cmdfile, param1 )
int     umode, pager;
char    *cmdfile, *param1;
{
    char buf[STRLEN*2] ;
    int save_pager;
     
    if(num_useshell()>=20)
    {
        clear();
        prints("̫����ʹ���ⲿ��ʽ�ˣ����һ�����ð�...");
        pressanykey();
        return ;
    }
    if(!HAS_PERM(PERM_SYSOP)&&heavyload())
    {
        clear();
        prints("��Ǹ��Ŀǰϵͳ���ɹ��أ��˹�����ʱ����ִ��...");
        pressanykey();
        return;
    }    
    if( ! dashf( cmdfile ) ) {
        move(2,0);
        prints( "no %s\n", cmdfile );
        pressreturn();
        return;
    }
    save_pager = uinfo.pager;
    if( pager == NA ) {
        uinfo.pager = 0;
    }
    modify_user_mode( umode );
    sprintf( buf, "/bin/sh %s %s %s %d", cmdfile, param1, currentuser.userid, getpid());
    report(buf);
    reset_tty() ;
    do_exec(buf,NULL) ;
    restore_tty() ;
    uinfo.pager = save_pager;
    clear();
}

#ifdef IRC
void
t_irc() {
    exec_cmd( IRCCHAT, NA, "bin/irc.sh", "" );
}
#endif /* IRC */

void
x_www() {
    exec_cmd( WWW, NA, "bin/www.sh", "" );
}

void
x_hytelnet() {
    exec_cmd( HYTELNET, NA, "bin/hytelnet.sh", "" );
}

/* ppfoong */
void
x_excearchie() {
    char buf[STRLEN];
    char *s;
    
    if(heavyload())
    {
        clear();
        prints("��Ǹ��Ŀǰϵͳ���ɹ��أ��˹�����ʱ����ִ��...");
        pressanykey();
        return;
    }    
    modify_user_mode( ARCHIE );
    clear();
    prints("\n\n[1;33m       _______ ______ ______ _______ _______ _______");
    prints("\n      |   _   |   __ \\      |   |   |_     _|    ___|");
    prints("\n      |       |      <   ---|       |_|   |_|    ___|");
    prints("\n      |___|___|___|__|______|___|___|_______|_______|[0m");
    prints("\n\n\n��ӭʹ�� ARCHIE ����");
    prints("\n\n�����ܽ�Ϊ���г����ĸ� FTP վ��������Ѱ�ҵĵ���.");
    prints("\n\n����������Ѱ���ִ�, ��ֱ�Ӱ� <ENTER> ȡ����");
    getdata(13,0,">",buf,20,DOECHO,NULL,YEA);
    if (buf[0]=='\0') {
      prints("\nȡ����Ѱ.....\n");
      pressanykey();
      return;
      }
    for(s=buf;*s != '\0';s++) {
        if(isspace(*s)) {
            prints("\nһ��ֻ����Ѱһ���ִ���, ����̫̰���!!");
            pressanykey();
            return;
            }
    }      
    exec_cmd( ARCHIE, YEA, "bin/archie.sh", buf );
    sprintf(buf,"tmp/archie.%s.%05d",currentuser.userid,uinfo.pid);
    if (dashf(buf))
       {
       if(askyn("Ҫ������Ļ�������",NA,NA)==YEA)
          mail_file(buf,currentuser.userid,"ARCHIE ��Ѱ���");
       ansimore( buf, YEA);
       unlink (buf);
       } 
}

/* ppfoong */
void
x_dict() {
    char buf[STRLEN];
    char *s;
    int whichdict;

    if(heavyload())
    {
        clear();
        prints("��Ǹ��Ŀǰϵͳ���ɹ��أ��˹�����ʱ����ִ��...");
        pressanykey();
        return;
    }    
    modify_user_mode( DICT );
    clear();
    prints("\n[1;32m     _____  __        __   __");
    prints("\n    |     \\|__|.----.|  |_|__|.-----.-----.---.-.----.--.--.");
    prints("\n    |  --  |  ||  __||   _|  ||  _  |     |  _  |   _|  |  |");
    prints("\n    |_____/|__||____||____|__||_____|__|__|___._|__| |___  |");
    prints("\n                                                     |_____|[m");
    prints("\n\n\n��ӭʹ�ñ�վ���ֵ䡣");
    prints("\n���ֵ���ҪΪ[1;33m��Ӣ����[m����, �������[1;33m����Ӣ��[m��ѯ��");
    prints("\n\nϵͳ����������������ִ�, �Զ��ж�����Ҫ�������Ӣ���ֻ��������֡�");
    prints("\n\n\n���������������Ӣ���ֻ�������, ��ֱ�Ӱ� <ENTER> ȡ����");
    getdata(15,0,">",buf,30,DOECHO,NULL,YEA);
    if (buf[0]=='\0') {
      prints("\n����������...");
      pressanykey();
      return;
      }
    for(s=buf;*s != '\0';s++) {
        if(isspace(*s)) {
            prints("\nһ��ֻ�ܲ�һ������, ����̫̰���!!");
            pressanykey();
            return;
            }
    }
    whichdict = YEA;
    for(s=buf;*s != '\0';s++) {
        if(!(isalpha(*s) || *s=='-')) {
            whichdict = NA;
            break ;
         }
    }
    if (whichdict) exec_cmd( DICT, YEA, "bin/cdict.sh", buf);
       else exec_cmd( DICT, YEA, "bin/edict.sh", buf); 
    sprintf(buf,"tmp/dict.%s.%05d",currentuser.userid,uinfo.pid);
    if (dashf(buf))
       {
       if(askyn("Ҫ������Ļ�������",NA,NA)==YEA)
          mail_file(buf,currentuser.userid,"�ֵ��ѯ���");
       ansimore( buf, YEA);
       unlink (buf);
       } 
}

/* Add By P.P.Foong */
void
x_sysinfo() {
    char buf[STRLEN];

    sprintf(buf,"tmp/sysinfo.%s",currentuser.userid);
    if (!dashf(buf)) {
    exec_cmd( SYSINFO, YEA, "bin/sysinfo.sh", "" );
    ansimore( buf, YEA);
    }
    unlink ( buf );
}
                    
/* Add By P.P.Foong */
void
x_game() {
    exec_cmd( GAME, YEA, "bin/game.sh", "" );
}

void
x_showuser() {
    char buf[STRLEN];

    modify_user_mode(SYSINFO);
    clear();
    stand_title("��վʹ�������ϲ�ѯ");
    ansimore ("etc/showuser.msg", NA);
    getdata(20,0,"Parameter: ",buf,30,DOECHO,NULL,YEA);
    if ((buf[0]=='\0')||dashf("tmp/showuser.result")) return;
    securityreport("��ѯʹ��������");
    exec_cmd( SYSINFO, YEA, "bin/showuser.sh",buf);
    sprintf(buf,"tmp/showuser.result");
    if (dashf(buf))
       {
       mail_file(buf,currentuser.userid,"ʹ�������ϲ�ѯ���");
       unlink (buf);
       }
}
int child_pid;
void
ent_bnet() {
     clear();
 //   exec_cmd( BBSNET, YEA, "bin/bbsnet.sh", "" );
     signal(SIGALRM, SIG_IGN);
     modify_user_mode(BBSNET);
     child_pid=fork();
     switch (child_pid)
     {
     	 case 0:
            execl("bin/bbsnet.exe", "bbsnet.exe", "etc/bbsnet.ini", "bin/telnet", currentuser.userid, NULL);
            break;
         case -1:
             break;
         default:    
              waitpid(child_pid,NULL,0);
            break;
     }  
     child_pid=0;

}
let_child_stop() {
   if(child_pid>0) kill(child_pid, SIGSTOP);
}

let_child_cont() {
   if(child_pid>0) kill(child_pid, SIGCONT);
}

let_child_exit() {
   if(child_pid>0) kill(child_pid, SIGHUP); 
}

void
x_tetris() {
     clear();
 //   exec_cmd( BBSNET, YEA, "bin/bbsnet.sh", "" );
     signal(SIGALRM, SIG_IGN);
     modify_user_mode(BBSNET);
     child_pid=fork();
     switch (child_pid)
     {
     	 case 0:
           execl("bin/tetris.exe", "tetris.exe", currentuser.userid,
            uinfo.from, NULL);
            break;
         case -1:
             break;
         default:    
              waitpid(child_pid,NULL,0);
            break;
     }  
     child_pid=0;

}
void
x_winmine() {
     clear();
 //   exec_cmd( BBSNET, YEA, "bin/bbsnet.sh", "" );
     signal(SIGALRM, SIG_IGN);
     modify_user_mode(BBSNET);
     child_pid=fork();
     switch (child_pid)
     {
     	 case 0:
            execl("bin/winmine.exe", "winmine.exe", currentuser.userid, uinfo.from, NULL);
            break;
         case -1:
             break;
         default:    
              waitpid(child_pid,NULL,0);
            break;
     }  
     child_pid=0;

}

char tt_id[20][20], tt_ip[20][30];
int tt_scr[20];

int tt_load_record() {
  int n;
  FILE *fp=fopen("tt.dat", "r");
  if(fp==0) {
    fp=fopen("tt.dat", "w");
    for(n=0; n<20; n++)
      fprintf(fp, "%s %s %d\n", "none", "0.0.0.0", 0);
    fclose(fp);
    fp=fopen("tt.dat", "r");
  }
  for(n=0; n<20; n++)
    fscanf(fp, "%s %s %d", tt_id[n], tt_ip[n], &tt_scr[n]);
  fclose(fp);
}

int tt_save_record() {
  int n, m1, m2;
  char id[20], ip[30];
  int scr;
  FILE *fp=fopen("tt.dat", "w");
  for(m1=0; m1<20; m1++)
  for(m2=m1+1; m2<20; m2++) 
    if(tt_scr[m1]<tt_scr[m2]) {
      strcpy(id, tt_id[m1]);
      strcpy(ip, tt_ip[m1]);
      scr=tt_scr[m1];
      strcpy(tt_id[m1], tt_id[m2]);
      strcpy(tt_ip[m1], tt_ip[m2]);
      tt_scr[m1]=tt_scr[m2];
      strcpy(tt_id[m2], id);
      strcpy(tt_ip[m2], ip);
      tt_scr[m2]=scr;
    }
  for(n=0; n<20; n++)
    fprintf(fp, "%s %s %d\n", tt_id[n], tt_ip[n], tt_scr[n]);
  fclose(fp);
}

int tt_check_record(int score) {
  int n;
  tt_load_record();
  for(n=0; n<20; n++)
    if(!strcasecmp(tt_id[n], currentuser.userid)) {
      if(tt_scr[n]>score) return 0;
      tt_scr[n]=score;
      strncpy(tt_ip[n], uinfo.from, 16);
      tt_ip[n][16]=0;
      tt_save_record();
      return 1;
    }
  if(tt_scr[19]<score) {
    tt_scr[19]=score;
    strcpy(tt_id[19], currentuser.userid);
    strncpy(tt_ip[19], uinfo.from, 16);
    tt_ip[19][16]=0;
    tt_save_record();
    return 1;
  }
  return 0;
}
#include <sys/times.h>
int x_tt() {
  char c[30], a;
  char chars[]="���£ãģţƣǣȣɣʣˣ̣ͣΣϣУѣңӣԣգ֣ףأ٣�";
  int m, n, t, score;
  struct tms faint;
  randomize();
  modify_user_mode(BBSNET);
  report("tt game");
  tt_load_record();
  printf("[2J��վ���ָ������а�\r\n\r\n%4s %12.12s %24.24s %5s(WPMs)\r\n", "����", "�ʺ�", "��Դ", "�ٶ�");
  for(n=0; n<20; n++)
    printf("%4d %12.12s %24.24s %5.2f\r\n", n+1, tt_id[n], tt_ip[n], tt_scr[n]/10.);
  fflush(stdout);
  read(0, genbuf, 32);
  printf("[H[J[1;32m�££�[m������ϰ����. (��Сд����, �����һ�ַ�ǰ�ĵȴ�����ʱ. [1;32m^C[m or [1;32m^D[m �˳�.)\r\n\r\n\r\n");

start:
  for(n=0; n<30; n++) {
    c[n]=rand()%26;
    printf("%c%c", chars[c[n]*2], chars[c[n]*2+1]);
  }
  printf("\r\n");
  fflush(stdout);
  m=0;
  t=times(&faint);
  while(m<30) {
    if(read(0, genbuf, 32)<=0) return 0;
    a=genbuf[0];
    if(a==c[m]+65 || a==c[m]+97) {
      printf("%c%c", chars[c[m]*2], chars[c[m]*2+1]);
      if(m==0) {
        if(abs(times(&faint)-t)>3000) {
           printf("\r\n��ʱ! �������[1;32m3[m�������ڿ�ʼ!\r\n");
           goto start;
        }
        t=times(&faint);
      }
      m++;
      fflush(stdout);
      usleep(60000);
    }
    if(genbuf[0]==3||genbuf[0]==4) return 0;
  }
  score=3600000/(times(&faint)-t);
  printf("\r\n\r\nSpeed=%5.2f WPMs\r\n\r\n", score/10.);
  if(tt_check_record(score)) printf("[1;33mף�أ���ˢ�����Լ��ļ�¼��[m\r\n\r\n");
  fflush(stdout);
  goto start;
}

