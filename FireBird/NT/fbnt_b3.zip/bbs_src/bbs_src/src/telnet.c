
/* Telnet for FB3.0, zhch.bbs@bbs.nju.edu.cn, NJU Lily BBS, Dec 12, 2000 */

/*
    Firebird BBS for Windows NT/2K
    Copyright (C) 2000, COMMAN,Kang Xiao-ning, kxn@student.cs.tsinghua.edu.cn
*/

#include "bbs.h"
#include "netinet/in.h"
#include "termios.h"
#include <netdb.h>
#include <netinet/in.h>
#include <sys/types.h>

unsigned char buf[2048];
struct timeval tv;
fd_set readfds;
int result, readnum;
char remotehost[80]="localhost";
int  remoteport=23;

static void break_check() {
	int i;
        tv.tv_sec = 0;
	tv.tv_usec = 0;
	FD_ZERO(&readfds) ;
	FD_SET(0, &readfds);
	result = select(1, &readfds, NULL, NULL, &tv);
	if (FD_ISSET(0, &readfds)) {
		readnum = read(0, buf, 80);
		for(i=0; i<readnum; i++) 
			if(buf[i]==3 || buf[i]==4) {
				printf("\r\nBreak\r\n");
				quit(0);
			}
	}
	alarm(1);
}

int telnet(char *server, int port) {
	char tmp[1024];
	int fd, tmplen;
	struct sockaddr_in blah;
	struct hostent *he;
	tmplen=0;
	signal(SIGALRM, break_check);
	alarm(1);
	bzero((char *)&blah, sizeof(blah));
	blah.sin_family=AF_INET;
	blah.sin_addr.s_addr=inet_addr(server);
	blah.sin_port=htons(port);
	printf("Trying %s... \n\r", server); 
	fflush(stdout);
	fd=socket(AF_INET, SOCK_STREAM, IPPROTO_TCP); 
	if((he=gethostbyname(server))!=NULL)
		bcopy(he->h_addr, (char *)&blah.sin_addr, he->h_length);
	else
		if((blah.sin_addr.s_addr=inet_addr(server))<0) return;
	if(connect(fd, (struct sockaddr *)&blah, 16)<0) return;
	signal(SIGALRM, SIG_IGN);
	printf("Connected to %s.\n\r", server);
	printf("Escape character is '^]'\r\n"); 
	fflush(stdout);
	while(1) {
		tv.tv_sec = 2400;
		tv.tv_usec = 0;
		FD_ZERO(&readfds) ;
		FD_SET(fd, &readfds);
		FD_SET(0, &readfds);
		result=select(fd+1, &readfds, NULL, NULL, &tv);
		if(result<=0) break;
                if(FD_ISSET(0, &readfds)) {
			readnum=read(0, buf, 2048);
			if(readnum<=0) break;
			if(buf[0]==29) return;
			if(buf[0]==13 && readnum==1) {
				buf[1]=10;
				readnum++;
			}
			write(fd, buf, readnum);
		} else {
			readnum=read(fd, buf, 2048);
			if (readnum<=0) break;
			if(strchr(buf, 255)) 
				telnetopt(fd, buf, readnum);
			else
				write(0, buf, readnum);
		}
	}
}

int telnetopt(int fd, unsigned char *buf, int max) {
	unsigned char c2, c3;
	int i;
	unsigned char tmp[30];
	for(i=0; i<max; i++) {
		if(buf[i]!=255) {
			write(0, &buf[i], 1);
			continue;
		}
		c2=buf[i+1];
		c3=buf[i+2];
		i+=2;
		if(c2==253 && (c3==3 || c3==24)) {
			sprintf(tmp, "%c%c%c", 255, 251, c3);
			write(fd, tmp, 3); 
			continue;
		}
		if((c2==251 || c2==252) && (c3==1 || c3==3 || c3==24)) {
			sprintf(tmp, "%c%c%c", 255, 253, c3); 
			write(fd, tmp, 3);
			continue;
		}
		if(c2==251 || c2==252) {
			sprintf(tmp, "%c%c%c", 255, 254, c3);
			write(fd, tmp, 3);
			continue;
		}
		if(c2==253 || c2==254) {
			sprintf(tmp, "%c%c%c", 255, 252, c3);
			write(fd, tmp, 3);
			continue;
		}
		if(c2==250) {
			while(c3!=240 && i<max) {
				c3=buf[i];
				i++;
			}
			sprintf(tmp, "%c%c%c%c%c%c%c%c%c%c", 255, 250, 24, 0, 65, 78, 83, 73, 255, 240);
			write(fd, tmp, 10);
		}
	}
	fflush(stdout);
}

struct termios termios_o, termios_p;
int main(int num, char* arg[]) {
	if(num>=2) strcpy(remotehost, arg[1]);
	if(num>=3) remoteport=atoi(arg[2]);
	tcgetattr(1, &termios_o);
//	cfmakeraw(&termios_p);
    termios_p.c_iflag &= ~(IGNBRK|BRKINT|PARMRK|ISTRIP
                    |INLCR|IGNCR|ICRNL|IXON);
    termios_p.c_oflag &= ~OPOST;
    termios_p.c_lflag &= ~(ECHO|ECHONL|ICANON|ISIG|IEXTEN);
    termios_p.c_cflag &= ~(CSIZE|PARENB);
    termios_p.c_cflag |= CS8;
	tcsetattr(1, TCSANOW, &termios_p);
	telnet(remotehost, remoteport);
	quit();
}

int quit() {
	tcsetattr(1, TCSANOW, &termios_o);
	exit(0);
}
