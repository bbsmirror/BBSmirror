/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu
    Firebird Bulletin Board System
    Copyright (C) 1996, Hsien-Tsung Chang, Smallpig.bbs@bbs.cs.ccu.edu.tw
                        Peng Piaw Foong, ppfoong@csie.ncu.edu.tw
    
    Copyright (C) 1999, KCN,Zhou Lin, kcn@cic.tsinghua.edu.cn

    Firebird BBS for Windows NT
    Copyright (C) 2000, COMMAN,Kang Xiao-ning, kxn@student.cs.tsinghua.edu.cn


    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/

#include "bbs.h"

#define BADLOGINFILE    "logins.bad"
int     ERROR_READ_SYSTEM_FILE=NA;
int     RMSG=YEA;
int     msg_num=0;
int     nettyNN=0;
int     count_friends=0,count_users=0;
int     iscolor=1;
char    *getenv();
int     friend_login_wall();
char    *sysconf_str();
char    *Ctime();
struct user_info *t_search();
void    r_msg();
void    count_msg();
int     listmode;
int     numofsig=0;
jmp_buf byebye ;

FILE *ufp ;
int talkrequest = NA ;
int enter_uflags;
time_t lastnote;

struct user_info uinfo ;

char netty_path[ 256 ];
char fromhost[ 60 ] ;
char tty_name[ 20 ] ;

char BoardName[STRLEN] ;
char ULIST[STRLEN] ;
int utmpent = -1 ;
time_t  login_start_time;
int     showansi=1;
int convcode=0;
extern int conv_init();

extern int enabledbchar;

void
log_usies( mode, mesg )
char *mode, *mesg;
{
    time_t      now;
    FILE        *fp;
    char        buf[ 256 ], *fmt;

    now = time(0);
    fmt = currentuser.userid[0] ? "%s %s %-12s %s\n" : "%s %s %s%s\n";
    sprintf( buf, fmt, Ctime( &now )+4, mode, currentuser.userid, mesg );
    if( (fp = fopen( "usies", "a" )) != NULL ) {
        fputs( buf, fp );
        fclose( fp );
    }
}

void
u_enter()
{
    enter_uflags = currentuser.flags[0];
    memset( &uinfo, 0, sizeof( uinfo ) );
    uinfo.active = YEA ;
    uinfo.pid    = getpid();
    if( HAS_PERM(PERM_LOGINCLOAK) && (currentuser.flags[0] & CLOAK_FLAG))
        uinfo.invisible = YEA;
    uinfo.mode = LOGIN ;
    uinfo.pager = 0;
    if (DEFINE(DEF_DELDBLCHAR))
        enabledbchar=1;
    else 
        enabledbchar=0;
    if(DEFINE(DEF_FRIENDCALL))
    {
        uinfo.pager|=FRIEND_PAGER;
    }
    if(currentuser.flags[0] & PAGER_FLAG)
    {
        uinfo.pager|=ALL_PAGER;
        uinfo.pager|=FRIEND_PAGER;
    }
    if(DEFINE(DEF_FRIENDMSG))
    {
        uinfo.pager|=FRIENDMSG_PAGER;
    }
    if(DEFINE(DEF_ALLMSG))
    {
        uinfo.pager|=ALLMSG_PAGER;
        uinfo.pager|=FRIENDMSG_PAGER;
    }
    uinfo.uid = usernum;
    strncpy( uinfo.from, fromhost, 60 );
#ifdef SHOW_IDLE_TIME
    if (tty_name[0])
    strncpy( uinfo.tty, tty_name, 20 );
    else {
      *(time_t*)(uinfo.tty+1)=time(0);
      uinfo.tty[0]=0;
    }
#endif
    iscolor=(DEFINE(DEF_COLOR))? 1:0;
    strncpy( uinfo.userid,   currentuser.userid,   20 );
    strncpy( uinfo.realname, currentuser.realname, 20 );
    strncpy( uinfo.username, currentuser.username, 40 );
    getfriendstr();
    getrejectstr();
    if(HAS_PERM(PERM_EXT_IDLE))
        uinfo.ext_idle = YEA;
    utmpent = getnewutmpent(&uinfo) ;
    if (utmpent < 0) {
        sprintf( genbuf, "Fault: No utmpent slot for %s\n", uinfo.userid);
        report( genbuf );
    }
    listmode=0;
    digestmode=NA;
}

void
setflags(mask, value)
int mask, value;
{
    if (((currentuser.flags[0] & mask) && 1) != value) {
        if (value) currentuser.flags[0] |= mask;
        else currentuser.flags[0] &= ~mask;
    }
}

void
u_exit()
{
    setflags(PAGER_FLAG, (uinfo.pager&ALL_PAGER));
    if (HAS_PERM(PERM_LOGINCLOAK))
        setflags(CLOAK_FLAG, uinfo.invisible);

    if( currentuser.flags[0] != enter_uflags && !ERROR_READ_SYSTEM_FILE) {
        set_safe_record();
        substitute_record(PASSFILE,&currentuser,sizeof(currentuser),usernum);
    }

    uinfo.active = NA ;
    uinfo.pid = 0 ;
    uinfo.invisible = YEA ;
    uinfo.sockactive = NA ;
    uinfo.sockaddr = 0 ;
    uinfo.destuid = 0 ;
#ifdef SHOW_IDLE_TIME
    strcpy(uinfo.tty, "NoTTY");
#endif
    update_utmp2();
}

int
cmpuids(uid,up)
char *uid ;
struct userec *up ;
{
    return !ci_strncmp(uid,up->userid,sizeof(up->userid)) ;
}

int
dosearchuser(userid)
char *userid ;
{
    int         id;

    if( (id = getuser( userid )) != 0 ) {
        if( cmpuids( userid, &lookupuser ) ) {
            memcpy( &currentuser, &lookupuser, sizeof(currentuser) );
            return usernum = id;
        }
    }
    memset( &currentuser, 0, sizeof( currentuser ) );
    return usernum = 0;
}

int started = 0;

void
talk_request()
{
    signal(SIGUSR1,talk_request) ;
    talkrequest = YEA ;
    bell(); bell(); bell();
    sleep( 1 );
    bell(); bell(); bell(); bell(); bell();
    return ;
}
void
abort_bbs()
{
    time_t      stay;
#ifdef CAN_EXEC
    extern char tempfile[];

    unlink(tempfile);
#endif

    if(uinfo.mode==POSTING||uinfo.mode==SMAIL||uinfo.mode==EDIT
        ||uinfo.mode==EDITUFILE||uinfo.mode==EDITSFILE||uinfo.mode==EDITANN)
                keep_fail_post();
    if( started ) {
        stay = time( 0 ) - login_start_time;
        sprintf( genbuf, "Stay: %3ld (%s)", stay / 60, currentuser.username );
        log_usies( "AXXED", genbuf );
        u_exit();
    }
    let_child_exit();
    exit( 0 );
}

int
cmpuids2(unum, urec)
int unum;
struct user_info *urec;
{
    return (unum == urec->uid);
}

int
count_multi( uentp )
struct user_info *uentp;
{
    static int  count;

    if( uentp == NULL ) {
        int     num = count;
        count = 0;
        return num;
    }
    if( !uentp->active || !uentp->pid )
        return 0;
    if( uentp->uid == usernum )
        count++;
    return 1;
}

int
count_user()
{
    count_multi( NULL );
    apply_ulist( count_multi );
    return count_multi( NULL );
}

void
multi_user_check()
{
    struct user_info uin;
    char buffer[40];
    int logins;

    if (HAS_PERM(PERM_MULTILOG)) return;  /* don't check sysops */

    /* allow multiple guest user */
    logins=count_user();

    if (heavyload()&&logins) {
         prints( "[1;33m��Ǹ, Ŀǰϵͳ���ɹ���, �����ظ� Login��[m\n");
         oflush();
         sleep(3);
         exit(1);
    }

    if(!strcmp("guest", currentuser.userid))
    {/*
        if ( logins > 16 ) {
            prints( "[1;33m��Ǹ, Ŀǰ����̫�� [1;36mguest[33m, ���Ժ����ԡ�[m\n");
            oflush();
            sleep(3);
            exit(1);
        }
     */ /* Modified by calling for testing */
        return;
    }else if(logins >= 5)
    {
      prints("[1;33m�ܱ�Ǹ, ���� Login ��ͬ�ʺ����, Ϊȷ��������վȨ��,\n �����߽���ȡ����[m\n");
      oflush();
      sleep(3);
      exit(1);
    }
    if ( !search_ulist( &uin, cmpuids2, usernum) )
        return;  /* user isn't logged in */

    if (!uin.active || (kill(uin.pid,0) == -1))
        return;  /* stale entry in utmp file */

    getdata(0, 0, "\033[1;37m����ɾ���ظ��� login �� (Y/N)? [N][m", genbuf, 4, 
            DOECHO, NULL,YEA);

    if(genbuf[0] == 'Y' || genbuf[0] == 'y') {
        kill(uin.pid,9);
        sprintf(buffer, "kicked (multi-login)" );
        report(buffer);
        log_usies( "KICK ", currentuser.username );
    }
}

int
simplepasswd( str, check )
char *str;
int check;
{
    char        ch;

    while( (ch = *str++) != '\0' ) {
      if (check == 1)
      {
        if( !(ch >= 'a' && ch <= 'z')) return 0;
      }
      else if( !(ch >= '0' && ch <= '9')) return 0;
    }
    return 1;
}

void
reaper()
{
  while (waitpid(-1, NULL, WNOHANG | WUNTRACED) > 0);
  signal(SIGCHLD,(void *)reaper);
}

void
system_init(argc, argv)
int     argc;
char    *argv;
{
    char        *rhost;

    login_start_time = time( 0 );
    gethostname( genbuf ,256 );
#ifdef SINGLE
    if( strcmp( genbuf, SINGLE ) ) {
        prints("Not on a valid machine!\n") ;
        oflush();
        exit(-1) ;
    }
#endif
    sprintf( ULIST, "%s.%s", ULIST_BASE, genbuf );

   // if( argc >= 3 ) {
        strncpy( fromhost, argv, 60 );
   /* } else {
        fromhost[0] = '\0';
    }*/
    
    if( (rhost = getenv( "REMOTEHOST" )) != NULL )
        strncpy( fromhost, rhost, 60 );
    fromhost[59] = '\0';
/*#ifdef SHOW_IDLE_TIME
    if(argc >= 4) { 
        strncpy( tty_name, argv[3], 20 ) ;
    } else {
        tty_name[0] = '\0' ;
    }
#endif
*/
#ifndef lint
    signal(SIGINT,SIG_IGN) ;
    signal(SIGQUIT,SIG_IGN) ;
    signal(SIGPIPE,SIG_IGN) ;
#ifdef DOTIMEOUT
    init_alarm();
    uinfo.mode = LOGIN;    
    alarm(LOGIN_TIMEOUT);
#else
    signal(SIGALRM,SIG_SIG) ;
#endif
    signal(SIGTERM,SIG_IGN) ;
    signal(SIGURG,SIG_IGN) ;
    signal(SIGTSTP,SIG_IGN) ;
    signal(SIGTTIN,SIG_IGN) ;
#endif
    signal(SIGHUP,abort_bbs) ;
    signal(SIGTTOU,count_msg) ;
    signal(SIGUSR1,talk_request) ;
    signal(SIGUSR2,r_msg) ;
    signal(SIGCHLD,SIG_IGN) ;
}

void
system_abort()
{
    if( started ) {
        log_usies( "ABORT", currentuser.username );
        u_exit() ;
    }
    clear();
    refresh();
    prints("лл����, �ǵó���� !\n");
    oflush();
    exit(0) ;
}

void
logattempt( uid, frm )
char *uid, *frm;
{
    char        fname[ STRLEN ];
    int         fd, len;

    sprintf( genbuf, "%-12.12s  %-30s %s\n",
                uid, Ctime( &login_start_time ), frm );
    len = strlen( genbuf );
    if( (fd = open( BADLOGINFILE, O_WRONLY|O_CREAT|O_APPEND, 0644 )) > 0 ) {
        write( fd, genbuf, len );
        close( fd );
    }
    sethomefile( fname, uid, BADLOGINFILE );
    if( (fd = open( fname, O_WRONLY|O_CREAT|O_APPEND, 0644 )) > 0 ) {
        write( fd, genbuf, len );
        close( fd );
    }
}

void
login_query()
{
    char        uid[IDLEN+2], passbuf[PASSLEN], *ptr;
    int         curr_login_num;
    int         attempts;
    char fname[STRLEN];
    extern      struct UTMPFILE *utmpshm;

    curr_login_num = num_active_users();
    if( curr_login_num >= MAXACTIVE ) {
        ansimore( "etc/loginfull", NA );
        oflush();
        sleep( 1 );
        exit( 1 ) ;
    }
    ptr = sysconf_str( "BBSNAME" );
    if( ptr == NULL )  ptr = "��δ��������վ";
    strcpy( BoardName, ptr );
    if(fill_shmfile(1,"etc/issue","ISSUE_SHMKEY"))
    {
        show_issue();
    }
    prints( "[1;32m��ӭ����[1;33m�� %s ��[32m�� ��վһ�������� [36m%d[32m ��ע��ʹ�á�[m\n", 
            BoardName, MAXUSERS);
    resolve_utmp();
    if(utmpshm->usersum == 0)
        utmpshm->usersum = allusers();
    prints( "[1;32mĿǰ��վ����: [[36m%d/%d[32m]�� Ŀǰ���� [36m%d[32m ��ע���ʺš���%s��[m\n", 
            curr_login_num, MAXACTIVE, utmpshm->usersum,VERSION_ID);
    attempts = 0;  
    while( 1 ) {
        if( attempts++ >= LOGINATTEMPTS ) {
            ansimore( "etc/goodbye", NA );
            oflush();
            sleep( 1 );
            exit( 1 );
        }
        getdata( 0, 0, "[1;33m�������ʺ�[m(���������� `[1;36mguest[m', ע��������`[1;31mnew[m'): ",
                uid, IDLEN+1, DOECHO, NULL ,YEA);
        /* ppfoong */        
        if((strcmp(uid,"guest") == 0)&&(MAXACTIVE-curr_login_num<10)) {
            ansimore( "etc/loginfull", NA);
            oflush();
            sleep(1);
            exit(1);
        }    
        if( strcmp( uid, "new" ) == 0 ) {
#ifdef LOGINASNEW
            memset( &currentuser, 0, sizeof( currentuser ) );
            new_register();
            ansimore( "etc/firstlogin", YEA );
            break;
#else
            prints("[1;37m��ϵͳĿǰ�޷��� [36mnew[37m ע��, ����[36m guest[37m ����...[m\n");
#endif
        } else if( *uid == '\0' || !dosearchuser( uid ) ) {
            prints( "[1;31m�����ʹ�����ʺ�...[m\n" );
        } 
        else if( strcmp( uid, "guest" ) == 0 ) {
            currentuser.userlevel = 0;
            currentuser.flags[0] = CURSOR_FLAG;
            break;
        }
        else {
	    if (!convcode)
	       convcode=!(currentuser.userdefine&DEF_USEGB);
            getdata( 0, 0, "[1;37m����������: [m", passbuf, PASSLEN, NOECHO, NULL ,YEA);
            passbuf[8] = '\0';
            if( !checkpasswd( currentuser.passwd, passbuf )) {
                logattempt( currentuser.userid, fromhost );
                prints( "[1;31m�����������...[m\n" );
            } else {
                if( !HAS_PERM( PERM_BASIC ) ) {
                    prints( "[1;32m���ʺ���ͣ�������� [36mSYSOP[32m ��ѯԭ��[m\n" );
                    oflush();
                    sleep( 1 );
                    exit( 1 );
                }
                if( simplepasswd(passbuf,1)||simplepasswd(passbuf,2)
                    ||strstr(passbuf,currentuser.userid)) {
                    prints("[1;33m* ������ڼ�, ��ѡ��һ�����ϵ�������Ԫ.[m\n");
                    getdata( 0, 0, "�� <ENTER> ����",genbuf,5,NOECHO,NULL,YEA);
                }
                bzero(passbuf,PASSLEN-1);
                break;
            }
        }
    }
    multi_user_check();
    if( !term_init(currentuser.termtype) ) {
        prints("Bad terminal type.  Defaulting to 'vt100'\n") ;
        term_init("vt100") ;
    } 
    sprintf(fname,"home/%c/%s/%s.deadve",toupper(currentuser.userid[0]),currentuser.userid,currentuser.userid);
    if(dashf(fname))
    {
        mail_file(fname,currentuser.userid,"�����������������Ĳ���...");
        unlink(fname);
    }
    sethomepath( genbuf, currentuser.userid );
    mkdir( genbuf, 0775 );
}

int
valid_ident( ident )
char *ident;
{
    static char *invalid[] = { "unknown@", "root@", "gopher@", "bbs@",
        "guest@", "nobody@", "www@", NULL };
    int         i;

    if(ident[0] == '@') return 0;
    for( i = 0; invalid[i] != NULL; i++ )
        if( strstr( ident, invalid[i] ) != NULL )
            return 0;
    return 1;
}

void
write_defnotepad()
{
  currentuser.notedate=time(NULL);
  set_safe_record();
  substitute_record(PASSFILE, &currentuser, sizeof(currentuser), usernum);
  return;
}
/*
void
defnotepad()
{
  FILE          *def;
  char          fname[STRLEN],spbuf[STRLEN];
  
 
  setuserfile(fname,"defnotepad");
  if((def=fopen(fname,"r"))!=NULL)
  {
    fgets(spbuf,sizeof(spbuf),def);
    currentuser.notemode=spbuf[0]-'0';
    if(currentuser.notemode==2)
    {
        fgets(spbuf,sizeof(spbuf),def);
        currentuser.notedate=atol(spbuf);
        fgets(spbuf,sizeof(spbuf),def);
        currentuser.noteline=atol(spbuf);
    }
    fclose(def);
    unlink(fname);
  }

  if(currentuser.notemode==-1)
  {
     while(1){
        getdata( 0, 0, "��������Ҫ�����԰�ģʽ (1) ȫ�� (2) ֻ��û������ (3) ������: ", spbuf, 2, DOECHO, NULL ,YEA);
        if(spbuf[0]=='1' || spbuf[0]=='2' || spbuf[0]=='3')
                break;
        else
                continue;
     }
     currentuser.notemode=spbuf[0]-'0';
     if(currentuser.notemode==2)
     {
        currentuser.notedate=time(NULL);
        currentuser.noteline=0;     
     }
     set_safe_record();
     substitute_record(PASSFILE, &currentuser, sizeof(currentuser), usernum);
     return;
  }
}  
*/
void
notepad_init()
{
    FILE *check;
    char notetitle[STRLEN];
    char tmp[STRLEN*2];
    char *fname,*bname,*ntitle;
    long int  maxsec;
    time_t now;
    
    maxsec=24*60*60;
    lastnote=0;
    if( (check = fopen( "etc/checknotepad", "r" )) != NULL )
    {
        fgets(tmp,sizeof(tmp),check);
        lastnote=atol(tmp);
        fclose(check);
    }
    else
        lastnote=0;
        if(lastnote==0)
        {
                lastnote=time(NULL)-(time(NULL)%maxsec);
                check=fopen( "etc/checknotepad", "w" );
                fprintf(check,"%d",lastnote);
                fclose(check);
                sprintf(tmp,"���԰��� %s Login �������ڶ�����ʱ��Ϊ %s"
                ,currentuser.userid,Ctime(&lastnote));
                report(tmp);
        }
        if((time(NULL)-lastnote)>=maxsec)
        {
                move(t_lines-1,0);
                prints("�Բ���ϵͳ�Զ����ţ����Ժ�.....");
                refresh();
                now=time(0);
                check=fopen( "etc/checknotepad", "w" );
                lastnote=time(NULL)-(time(NULL)%maxsec);
                fprintf(check,"%d",lastnote);
                fclose(check);
                if((check=fopen("etc/autopost","r"))!=NULL)
                {
                        while(fgets(tmp,STRLEN,check)!=NULL)
                        {
                           fname=strtok(tmp," \n\t:@");
                           bname=strtok(NULL," \n\t:@");
                           ntitle=strtok(NULL," \n\t:@");
                           if(fname==NULL||bname==NULL||ntitle==NULL)
                              continue;
                           else
                           {
                              sprintf(notetitle,"[%.10s] %s",ctime(&now),ntitle);
                              if(dashf(fname))
                              {
                                 postfile(fname,bname,notetitle,1);
                                 sprintf(tmp,"%s �Զ�����",ntitle);
                                 report(tmp);
                              }
                           }
                        }
                        fclose(check);
                }
                sprintf(notetitle,"[%.10s] ���԰��¼",ctime(&now));
                if(dashf("etc/notepad","r"))
                {
                        postfile("etc/notepad","notepad",notetitle,1);
                        unlink("etc/notepad");
                }
                report("�Զ�����ʱ�����");
        }
    return;
}
        

void
user_login()
{
    char        fname[ STRLEN ];
    char        *ruser;
    int         w_screens;

    if( strcmp( currentuser.userid, "SYSOP" ) == 0 )
        currentuser.userlevel = ~0;   /* SYSOP gets all permission bits */

    ruser = getenv( "REMOTEUSERNAME" );
    sprintf( genbuf, "%s@%s", ruser ? ruser : "?", fromhost );
    log_usies( "ENTER", genbuf );
    if( ruser ) {
        sprintf( genbuf, "%s@%s", ruser, fromhost );
        if( valid_ident( genbuf ) ) {
            strncpy( currentuser.ident, genbuf, NAMELEN );
            currentuser.ident[NAMELEN-1] = '\0';
        }
        if( !valid_ident( currentuser.ident ) ) {
            currentuser.ident[0] = '\0';
        }
    }
    u_enter() ;
    report("Enter") ;
    started = 1 ;
    initscr() ;
    scrint = 1 ;
    if( USE_NOTEPAD == 1)
            notepad_init();                    
    if(strcmp(currentuser.userid,"guest")!=0 && USE_NOTEPAD == 1){
/*      if(currentuser.notemode==1)
        shownotepad();
      else */
      if(DEFINE(DEF_NOTEPAD))
      { 
        int noteln;
        if(lastnote>currentuser.notedate)
                currentuser.noteline=0;
        noteln=countln("etc/notepad");
        if(lastnote>currentuser.notedate||currentuser.noteline==0)
        {
                shownotepad();
                currentuser.noteline=noteln;
                write_defnotepad();
        }
        else if((noteln-currentuser.noteline)>0){        
                move(0,0);
                ansimore2("etc/notepad",NA,0,noteln-currentuser.noteline+1);
                igetkey();
                currentuser.noteline=noteln;
                write_defnotepad();     
                clear();
        }
      }
    }
    if(show_statshm("0Announce/bbslist/countusr",0))
    {
        refresh();
        pressanykey();
    }    
    if((vote_flag(NULL,'\0',2/*�������µ�Welcome û*/)==0)
        &&DEFINE(DEF_SEEWELC1))
    {
        if(dashf("Welcome"))
        {
                ansimore("Welcome",YEA);
                vote_flag(NULL,'R',2/*д������µ�Welcome*/);
        }
    } else 
    {
      if(fill_shmfile(3,"Welcome2","WELCOME_SHMKEY"))
         show_welcomeshm();
    }
    show_statshm("etc/posts/day",1);
    refresh();
    move( t_lines - 2, 0 );
    clrtoeol();
    prints( "[1;36m�� �������� [33m%d[36m �ΰݷñ�վ���ϴ����Ǵ� [33m%s[36m ������վ��\n",
            currentuser.numlogins + 1, currentuser.lasthost );
    prints( "�� �ϴ�����ʱ��Ϊ [33m%s[m ", ctime(&currentuser.lastlogin) );
    igetkey();
    setuserfile( fname, BADLOGINFILE );
    if( ansimore( fname, NA ) != -1 ) {
        if(askyn("��Ҫɾ�����������������ļ�¼��",YEA,YEA) == YEA )
            unlink( fname );
    }

    strncpy(currentuser.lasthost, fromhost, 16);
    currentuser.lasthost[15] = '\0';   /* dumb mistake on my part */
    currentuser.lastlogin = time(NULL) ;

    set_safe_record();
#ifdef REG_EXPIRED
    /* ppfoong - ÿ REG_EXPIRED �����½�������ȷ�� */
    if (HAS_PERM(PERM_LOGINOK) &&
        strcmp(currentuser.userid,"SYSOP") &&
        strcmp(currentuser.userid,"guest"))
    {
       struct stat st;
       time_t now;
       int expired = 0;

       now = time(0);
       setuserfile(fname,"mailcheck");
       if (stat(fname,&st) == -1 || now - st.st_mtime >= REG_EXPIRED*86400)
       {
          setuserfile(fname,"register");
          if (stat(fname,&st) == 0)
          {
             if (now - st.st_mtime >= REG_EXPIRED*86400)
             {
             setuserfile(fname,"register.old");
             if (stat(fname,&st) == -1 || now - st.st_mtime >= REG_EXPIRED*86400)
                expired = 1;
             else expired = 0;
             }
          } 
          else expired = 1;    /*  ©��֮��??  */
       }
       if (expired)
       {
           strcpy(currentuser.email,"");
           strcpy(currentuser.address,"");
           currentuser.userlevel &= ~(PERM_LOGINOK|PERM_PAGE);
           mail_file("etc/expired",currentuser.userid,"���¸�������˵����");
           setuserfile(fname,"sucessreg");
           unlink(fname);
       }
    }
#endif
    currentuser.numlogins++;
    substitute_record(PASSFILE, &currentuser, sizeof(currentuser), usernum);
    if (currentuser.firstlogin == 0) {
        currentuser.firstlogin = login_start_time - 7 * 86400;
    }
    check_register_info();
}


void
set_numofsig()
{
    int sigln;
    char signame[STRLEN];

    setuserfile( signame, "signatures" );
    sigln=countln(signame);
    numofsig=sigln/MAXSIGLINES;
    if((sigln%MAXSIGLINES)!=0)
         numofsig+=1;
}
int
chk_friend_book()
{
        FILE *fp;
        int idnum,n=0;
        char buf[STRLEN],*ptr;

        
        if((fp=fopen("friendbook","r"))==NULL)
                return n;
        move(5,0);
        prints("[1mϵͳѰ�������б�:[m\n\n");
        while(fgets(buf,sizeof(buf),fp)!=NULL)
        {
                char uid[14];
                char msg[STRLEN];
                struct user_info *uin;

                ptr=strstr(buf,"@");
                if(ptr==NULL)
                   continue;
                ptr++;
                strcpy(uid,ptr);
                ptr=strstr(uid,"\n");
                *ptr='\0';
                idnum=atoi(buf);
                if(idnum!=usernum||idnum<=0)
                   continue;    
                uin=t_search(uid,NA);
                sprintf(msg,"%s �Ѿ���վ��",currentuser.userid);
                if(!uinfo.invisible&&uin!=NULL&&!DEFINE(DEF_NOLOGINSEND)
                    &&do_sendmsg(uin,msg,2,uin->pid)==1)
                {
                     prints("[1m%s[m ���㣬ϵͳ�Ѿ�����������վ����Ϣ��\n",uid);
                }else
                     prints("[1m%s[m ���㣬ϵͳ�޷����絽��������������硣\n",uid);
                n++;
                del_from_file("friendbook",buf);
                if (n>15) {
                   pressanykey();
                   move (7,0);
                   clrtobot();
                }
        }
        fclose(fp);
        return n;
}

int 
check_maxmail()
{
   extern char currmaildir[ STRLEN ];
   int maxmail,currmail;

   maxmail=(HAS_PERM(PERM_SYSOP))?MAX_SYSOPMAIL_HOLD:MAX_MAIL_HOLD;
   currmail=get_num_records( currmaildir, sizeof(struct fileheader) );
   if( currmail > maxmail ) {
      prints("\n\n����˽���ż��ߴ� %d ��, ��ɾ�������ż�, ����ά���� %d �����¡�\n",currmail,maxmail);
      prints("���ż����� %d ��ʱ, �㽫�޷�ʹ�ñ�վ�����Ź��ܡ�\n",maxmail+10);
      if(currmail > maxmail*2) {
         sprintf(genbuf,"˽���ż�����: %d ��",currmail);
         securityreport(genbuf);
      }
   }
   if(currmail > maxmail+10) return(1); 
       else return(0);
}

int
main_bbs(argc, argv)
int argc ;
char *argv ;
{
    char   fname[STRLEN];
    //umask(0007);
#ifdef BBS_INFOD
    if (strstr( argv[ 0 ], "bbsinfo") != NULL) {
        load_sysconf();
        bbsinfod_main(argc, argv);
        exit( 0 );
    }
#endif
    load_sysconf();
    conv_init();
/*    if( argc < 2 || ((*argv[1] != 'h' )&&(*argv[1] != 'e' )&&(*argv[1] != 'd'))) {
        prints( "You cannot execute this program directly.\n" );
        oflush();
        exit( -1 );
    }*/
    //if (*argv[1]=='e')
    	convcode=argc;
    system_init( argc, argv );
    if( setjmp(byebye) ) {
        system_abort();
    }
    get_tty();
    init_tty();
    login_query();
    user_login();
    m_init();
    RMSG = NA;
    clear();
    if (strcmp(currentuser.userid,"guest"))
    {
       if (HAS_PERM(PERM_ACCOUNTS)&&dashf("new_register"))
          {
           prints("[1;33m����ʹ�������ڵ���ͨ��ע�����ϡ�[m");
           pressanykey();
           clear();
          }
       check_maxmail();
       if (chk_friend_book()) 
           pressanykey();
       move(7,0);
       clrtobot();
       if(!DEFINE(DEF_NOLOGINSEND))
          if(!uinfo.invisible) 
             apply_ulist(friend_login_wall);
/*       pressanykey();
       clear();*/
       set_numofsig();
       if(DEFINE(DEF_INNOTE))
       {
          setuserfile(fname,"notes");
          if(dashf(fname))
                ansimore(fname,YEA);
       }
    }
    memset(netty_path,0,sizeof(netty_path));
    nettyNN=NNread_init();
    b_closepolls();
    num_alcounter();
    if(count_friends>0&&DEFINE(DEF_LOGFRIEND))
        t_friends();
    while( 1 ) {
        if(DEFINE(DEF_NORMALSCR))
                domenu( "TOPMENU" );
        else
                domenu( "TOPMENU2" );
        Goodbye();
    }
}

int refscreen = NA ;

int
egetch()
{
    int rval ;

    check_calltime();
    if (talkrequest) {
        talkreply() ;
        refscreen = YEA ;
        return -1 ;
    }
/*    if (ntalkrequest) {
        ntalkreply() ;
        refscreen = YEA ;
        return -1 ;
    } */
    while( 1 ) {
        rval = igetkey();
        if(talkrequest) {
            talkreply() ;
            refscreen = YEA ;
            return -1 ;
        }
/*        if(ntalkrequest) {
            ntalkreply() ;
            refscreen = YEA ;
            return -1 ;
        } */
        if( rval != Ctrl('L') )
            break;
        redoscr();
    }
    refscreen = NA ;
    return rval ;
}

char *
boardmargin()
{
    static char buf[STRLEN] ;
    if(selboard)
        sprintf(buf,"������ [%s]",currboard) ;
    else {
        brc_initial( DEFAULTBOARD );
        if (getbnum(currboard)) {
            selboard = 1 ;
            sprintf(buf,"������ [%s]",currboard) ;
        }
        else sprintf(buf,"Ŀǰ��û���趨������") ;
    }
    return buf ;
}
/*Add by SmallPig*/
void
update_endline()
{   
    char        buf[ STRLEN ];
    time_t      now;
    int         allstay;
    
    if(!DEFINE(DEF_ENDLINE))
    {
        move(t_lines-1,0);
        clrtoeol();
        return;
    }
    now=time(0);
    allstay=(now - login_start_time)/60;
    move(t_lines-1,0);
    clrtoeol();
    sprintf(buf,"[[36m%.12s[33m]",currentuser.userid);
    if(!DEFINE(DEF_NOTMSGFRIEND))
    {
         prints("[1;44;33m ʱ��:[[36m%19s[33m]  ״̬:[[36m%1s%1s%1s%1s%1s%1s[33m] ʹ����:%-24s ͣ��:[[36m%3d[33m:[36m%2d[33m] [m",ctime(&now),
                  (uinfo.pager&ALL_PAGER)?"P":"p",(uinfo.pager&FRIEND_PAGER)?"O":"o",(uinfo.pager&ALLMSG_PAGER)?"M":"m",
                  (uinfo.pager&FRIENDMSG_PAGER)?"F":"f",(DEFINE(DEF_MSGGETKEY))?"X":"x",
                  (uinfo.invisible==1)?"C":"c",buf,(allstay/60)%1000,allstay%60);
    }else
    {
            num_alcounter();
            prints("[1;44;33mʱ��:[[36m%16s[33m]  ����/����:[[36m%3d[33m/[1;36m%3d[33m] ״̬:[[36m%1s%1s%1s%1s%1s%1s[33m]  ʹ����:%-22s[m",ctime(&now),
                  count_users,count_friends,(uinfo.pager&ALL_PAGER)?"P":"p",(uinfo.pager&FRIEND_PAGER)?"O":"o",
                  (uinfo.pager&ALLMSG_PAGER)?"M":"m",(uinfo.pager&FRIENDMSG_PAGER)?"F":"f",
                  (DEFINE(DEF_MSGGETKEY))?"X":"x",(uinfo.invisible==1)?"C":"c",buf);
            
    }

}


/*ReWrite by SmallPig*/
void
showtitle( title, mid )
char    *title, *mid;
{
    char        buf[ STRLEN ], *note;
    int         spc1,spc2;
    
    note = boardmargin();
    spc1 = 39-strlen(title)-strlen(mid)/2 ;
    spc2 = 40-strlen(note)-strlen(mid)/2 ;
    if( spc1 < 2 )  spc1 = 2;
    if( spc2 < 2 )  spc2 = 2;
    move(0,0);
    clrtoeol();
    sprintf( buf, "%*s", spc1, "" );
    if(!strcmp(mid,BoardName))
        prints( "[1;44;33m%s%s[37m%s[1;44m", title, buf,mid);
    else if(mid[0]=='[')
        prints( "[1;44;33m%s%s[5;36m%s[m[1;44m", title, buf,mid);
    else 
        prints( "[1;44;33m%s%s[36m%s", title, buf,mid);
    sprintf( buf, "%*s", spc2, "" );
    prints( "%s[33m%s[m\n", buf, note );
    update_endline();
    move(1,0);
}

void
docmdtitle( title, prompt )
char    *title, *prompt;
{
    char   middoc[30];

    if(chkmail())
        strcpy(middoc,"[�����ż�]");
    else
        strcpy(middoc,BoardName);

    showtitle( title, middoc);
    move(1,0);
    clrtoeol() ;
    prints( "%s", prompt );
    clrtoeol();
}
