//    sendmail.c : a little program that simulates sendmail -f <source> <dest> using SMTP relay
//
//    Firebird BBS for Windows NT
//    Copyright (C) 2000, COMMAN,Kang Xiao-ning, kxn@student.cs.tsinghua.edu.cn
//
#include "bbs.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "config.h"
#define SMTPHOST "mail.cs.tsinghua.edu.cn"

int main(int argc, char* argv[])
{
	int sock;
	struct sockaddr_in sin;
	struct hostent* hostent;
	FILE *outf,*inf;
	int c;
        char buffer[255];
	if (argc!=4) return -1;
	if (strncmp(argv[1],"-f",2) !=0) return -1;
        sock = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if (sock < 0) return -1;
	hostent = gethostbyname(SMTPHOST);
	memcpy(&sin.sin_addr,hostent->h_addr,sizeof(struct in_addr));
	sin.sin_family = AF_INET;
	sin.sin_port=htons(25);
	if (connect(sock,(struct sockaddr *) &sin,sizeof(sin))<0) return -1;
	outf = fdopen(sock,"wb");
	inf = fdopen(sock,"rb");
	if (!outf) { close(sock); return -1;}
	setbuf(outf,NULL);
	setbuf(inf,NULL);
        fgets(buffer,255,inf);
        fprintf(outf,"HELO %s\r\n",MY_BBS_DOMAIN);
        fgets(buffer,255,inf);
	fprintf(outf,"MAIL FROM:<%s>\r\n",argv[2]);
	fgets(buffer,255,inf);
	fprintf(outf,"RCPT TO:<%s>\r\n",argv[3]);
	fgets(buffer,255,inf);
	fprintf(outf,"DATA\r\n");
	fgets(buffer,255,inf);
	c= fgetc(stdin);
	while (!feof(stdin))
	{
	   if (c == '\n') fputc('\r',outf);	
           fputc(c,outf);
	   c= fgetc(stdin);
	}
	fprintf(outf,"\r\n");
	fgets(buffer,255,inf);
	fprintf(outf,"QUIT\r\n");
	fclose(outf);
	fclose(inf);
	close(sock);
	return 0;
}
