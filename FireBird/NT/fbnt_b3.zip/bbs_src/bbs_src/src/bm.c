/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu
    Firebird Bulletin Board System
    Copyright (C) 1996, Hsien-Tsung Chang, Smallpig.bbs@bbs.cs.ccu.edu.tw
                        Peng Piaw Foong, ppfoong@csie.ncu.edu.tw

    Copyright (C) 1999, KCN,Zhou Lin, kcn@cic.tsinghua.edu.cn

    Firebird BBS for Windows NT
    Copyright (C) 2000, COMMAN,Kang Xiao-ning, kxn@student.cs.tsinghua.edu.cn
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/

#include "bbs.h"
extern cmpbnames();

int
addtodeny(uident,msg,ischange)
char *uident;
char *msg;
int ischange;
{
    char buf[50],strtosave[256];
    char buf2[50];
    int day;
    time_t nowtime;
    char ans[8];
    int seek;

    setbfile( genbuf, currboard,"deny_users" );
    seek=seek_in_file(genbuf,uident);
    if ((ischange&&!seek)||(!ischange&&seek))
    {
	move(2,0);
	prints("�����ID����!");
	pressreturn();
        return -1;
    }
    getdata(2,0,"����˵��: ", buf,40,DOECHO,NULL,YEA);
    getdata(3,0,"��������(0-�ֶ����): ", buf2,4,DOECHO,NULL,YEA);
    day=atoi(buf2);

    nowtime=time(NULL);
    if (day) {
    	struct tm* tmtime;
	time_t daytime=nowtime+(day+1)*24*60*60;
	time_t undenytime=nowtime+day*24*60*60;
	tmtime=gmtime(&daytime);
	sprintf( strtosave, "%-12s %-40s %2d��%2d�ս� \x1b[%um", uident, buf ,
		tmtime->tm_mon+1,tmtime->tm_mday, undenytime);
    	sprintf(msg, "����ԭ��: %s\n��������: %d\n�������%2d��%2d��:\n",
		buf,day,tmtime->tm_mon+1,tmtime->tm_mday);
    } else {
	sprintf( strtosave, "%-12s %-35s �ֶ����", uident, buf);
        sprintf( msg ,"����ԭ��: %s\n��������: �ֶ����\n",buf);
    }
    if (ischange)
          getdata(4,0,"���Ҫ�ı�ô?[Y/N]: ", ans, 7, DOECHO, NULL,YEA);
    else
          getdata(4,0,"���Ҫ��ô?[Y/N]: ", ans, 7, DOECHO, NULL,YEA);
    if( (*ans!='Y')&&(*ans!='y'))
	return -1;
    if (ischange)
          deldeny(uident);
    setbfile( genbuf, currboard,"deny_users" );
    return addtofile(genbuf,strtosave);
}
               
int
deldeny(uident)
char *uident;
{
    char fn[STRLEN];

    setbfile( fn,currboard, "deny_users" );
    return del_from_file(fn,uident);
}

int
deny_user()
{
    char uident[STRLEN];
    char ans[8],repbuf[STRLEN];
    char msgbuf[256];
    int count;

    if(!chk_currBM(currBM))
    {
        return DONOTHING;
    }

    while (1) {
        clear();
        prints("�趨�޷� Post ������\n");
        setbfile(genbuf,currboard,"deny_users");
        count = listfilecontent(genbuf);
        if (count)
            getdata(1,0,"(A)���� (D)ɾ�� (C)�ı� or (E)�뿪 [E]: ",ans,7,DOECHO,NULL,YEA);
        else 
            getdata(1,0,"(A)���� or (E)�뿪 [E]: ", ans, 7, DOECHO, NULL,YEA);
        if (*ans == 'A' || *ans == 'a') {
            move(1,0);
            usercomplete("�����޷� POST ��ʹ����: ", uident);
            if( *uident != '\0' )
            {
                if(addtodeny(uident,msgbuf,0)==1)
                {
                        sprintf(repbuf,"%s��%sȡ����%s��POSTȨ��",
                                uident,currentuser.userid,currboard);
                        securityreport(repbuf);
			deliverreport(repbuf,msgbuf);
                }
            }
        } else if ((*ans == 'C'|| *ans == 'c')) {
            move(1,0);
            usercomplete("�ı����ʱ���˵��: ", uident);
            if( *uident != '\0' )
            {
                if(addtodeny(uident,msgbuf,1)==1)
                {
                        sprintf(repbuf,"%s�ı��%s��ʱ���˵��",
                                currentuser.userid,uident);
                        securityreport(repbuf);
                        deliverreport(repbuf,msgbuf);
                }
            }
	}
	else if ((*ans == 'D' || *ans == 'd') && count) {
            move(1,0);
            namecomplete("ɾ���޷� POST ��ʹ����: ", uident);
            move(1,0);
            clrtoeol();
            if (uident[0] != '\0')
            {
                if(deldeny(uident))
                {
                        sprintf(repbuf,"�ָ� %s �� %s �� POST Ȩ��",
                             uident,currboard);
			strcpy(msgbuf,"���ԭ��: ��������:)\n");
                        securityreport(repbuf);
			deliverreport(repbuf,msgbuf);
                }
             }
        } else break;
    }
    clear();
    return FULLUPDATE;
}               

