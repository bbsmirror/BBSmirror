/*
    Firebird BBS for Windows NT/2K
    Copyright (C) 2000, COMMAN,Kang Xiao-ning, kxn@student.cs.tsinghua.edu.cn

    Windows NT/2000 Service Utility for Firebird BBS NT

*/

#include <stdio.h>
#include <process.h>
#include <strings.h>
#include "bbs.h"
main()
{
   FILE *fp = fopen(MY_BBS_HOME BBS_PID_LOG,"r");
   char buf[255];
   pid_t mypid = getpid();
   pid_t thepid;
   if (fp)
   {
   	for (fgets(buf,255,fp);!feof(fp);fgets(buf,255,fp))
   	{
   	    strtok(buf,"\r\n ");
   	    thepid = atoi(buf);
   	    if (thepid && thepid!=mypid) kill(thepid,9);
   	}	
   	fclose(fp);
   	unlink(MY_BBS_HOME BBS_PID_LOG);
   	return 0;
   }
   return 2;
}