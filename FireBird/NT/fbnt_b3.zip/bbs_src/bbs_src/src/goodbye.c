/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu
    Firebird Bulletin Board System
    Copyright (C) 1996, Hsien-Tsung Chang, Smallpig.bbs@bbs.cs.ccu.edu.tw
                        Peng Piaw Foong, ppfoong@csie.ncu.edu.tw
    
    Copyright (C) 1999, KCN,Zhou Lin, kcn@cic.tsinghua.edu.cn
    Firebird BBS for Windows NT
    Copyright (C) 2000, COMMAN,Kang Xiao-ning, kxn@student.cs.tsinghua.edu.cn


    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/

#include "bbs.h"

extern char BoardName[];
typedef struct
{
        char    *match;
        char    *replace;
}
tag_logout;

int 
countlogouts(filename)
char filename[STRLEN];
{
        FILE    *fp;
        char    buf[256];
        int count=0;
        
        if((fp = fopen(filename, "r")) == NULL)
                return 0;

        while(fgets(buf, 255, fp) != NULL)
        {
                if(strstr(buf,"@logout@")||strstr(buf,"@login@"))
                        count++;
        }
        return count+1;
}


user_display(filename,number,mode)
char    *filename;
int number,mode;
{
        FILE    *fp;
        char    buf[256];
        int     count=1;

        clear();
        move(1,0);
        if((fp = fopen(filename, "r")) == NULL)
                return;

        while(fgets(buf, 255, fp) != NULL)
        {
                if(strstr(buf,"@logout@")||strstr(buf,"@login@"))
                {
                        count++;
                        continue;
                }
                if(count==number)
                {
                   if(mode==YEA)
                        showstuff(buf);
                   else
                   {
                        prints("%s",buf);
                    }
                }
                else if(count>number)
                   break;
                else
                    continue;
        }
        refresh();
        fclose(fp);
        return;
}


char *
cexp(exp)
int exp;
{
        int expbase=0;

        if(exp==-9999)
                return "û�ȼ�";
        if(exp<=100+expbase)
                return "������·";
        if(exp>100+expbase&&exp<=450+expbase)
                return "һ��վ��";
        if(exp>450+expbase&&exp<=850+expbase)
                return "�м�վ��";
        if(exp>850+expbase&&exp<=1500+expbase)
                return "�߼�վ��";
        if(exp>1500+expbase&&exp<=2500+expbase)
                return "��վ��";
        if(exp>2500+expbase&&exp<=3000+expbase)
                return "���ϼ�";
        if(exp>3000+expbase&&exp<=5000+expbase)
                return "��վԪ��";
        if(exp>5000+expbase)
                return "��������";
        
}

char *
cperf(perf)
int perf;
{        
        
        if(perf==-9999)
                return "û�ȼ�";
        if(perf<=5)
                return "�Ͽ����";
        if(perf>5&&perf<=12)
                return "Ŭ����";
        if(perf>12&&perf<=35)
                return "������";
        if(perf>35&&perf<=50)
                return "�ܺ�";
        if(perf>50&&perf<=90)
                return "�ŵ���";
        if(perf>90&&perf<=140)
                return "̫������";
        if(perf>140&&perf<=200)
                return "��վ֧��";
        if(perf>200)
                return "�񡫡�";

}

int
countexp(udata)
struct userec *udata;
{
   int exp;

   if(!strcmp(udata->userid,"guest"))
        return -9999;
   exp=udata->numposts/*+post_in_tin( udata->userid )*/+udata->numlogins/5+(time(0)-udata->firstlogin)/86400+udata->stay/3600;
   return exp>0?exp:0;
}

int
countperf(udata)
struct userec *udata;
{
   int perf;
   int reg_days;

   if(!strcmp(udata->userid,"guest"))
        return -9999;
   reg_days=(time(0)-udata->firstlogin)/86400+1;
   perf=((float)(udata->numposts/*+post_in_tin( udata->userid )*/)/(float)udata->numlogins+
        (float)udata->numlogins/(float)reg_days)*10;
   return perf>0?perf:0;
}

showstuff(buf)
char    buf[256];
{
        extern time_t   login_start_time;
        int     frg,
                i,
                matchfrg,
                strlength,
                cnt,
                tmpnum;
              static  char    numlogins[10],
                        numposts[10],
                        rgtday[35],
                        lasttime[35],
                        thistime[35],
                        stay[10],
                        alltime[20],
                        ccperf[20],
                        perf[10],
                        exp[10],
                        ccexp[20];
        char    buf2[STRLEN],
                *ptr,
                *ptr2;
        time_t  now;

        static tag_logout loglst[] =
        {
                "userid",       currentuser.userid,
                "username",     currentuser.username,
                "realname",     currentuser.realname,
                "address",      currentuser.address,
                "email",        currentuser.email,
                "termtype",     currentuser.termtype,
                "realemail",    currentuser.termtype+16,
                "ident",        currentuser.ident,
                "rgtday",       rgtday,
                "log",          numlogins,
                "pst",          numposts,
                "lastlogin",    lasttime,
                "lasthost",     currentuser.lasthost,
                "now",          thistime,
                "bbsname",      BoardName,
                "stay",         stay,
                "alltime",      alltime,
                "exp",          exp,
                "cexp",         ccexp,
                "perf",         perf,
                "cperf",        ccperf,
                NULL,           NULL,
        };
        if(!strchr(buf, '$'))
        {
                prints("%s",buf);
                return;
        }
        now=time(0);
        tmpnum=countexp(&currentuser);
        sprintf(exp,"%d",tmpnum);
        strcpy(ccexp,cexp(tmpnum));
        tmpnum=countperf(&currentuser);
        sprintf(perf,"%d",tmpnum);
        strcpy(ccperf,cperf(tmpnum));
        sprintf(alltime,"%dСʱ%d����",currentuser.stay/3600,(currentuser.stay/60)%60);
        sprintf(rgtday, "%24.24s",ctime(&currentuser.firstlogin));
        sprintf(lasttime, "%24.24s",ctime(&currentuser.lastlogin));
        sprintf(thistime,"%24.24s",ctime(&now));
        sprintf(stay,"%d",(time(0) - login_start_time) / 60);
        sprintf(numlogins, "%d", currentuser.numlogins);
        sprintf(numposts, "%d", currentuser.numposts);

                frg = 1;
                ptr2 = buf;
                do
                {
                        if(ptr = strchr(ptr2, '$'))
                        {
                                matchfrg = 0;
                                *ptr = '\0';
                                prints("%s", ptr2);
                                ptr += 1;
                                for (i = 0; loglst[i].match != NULL; i++)
                                {
                                        if(strstr(ptr, loglst[i].match) == ptr)
                                        {
                                                strlength=strlen(loglst[i].match);
                                                ptr2 = ptr+strlength;
                                                for(cnt=0; *(ptr2+cnt) == ' '; cnt++);
    sprintf(buf2,"%-*.*s", cnt?strlength+cnt:strlength+1, strlength+cnt,loglst[i].replace);
    prints("%s",buf2);
                                                ptr2 += (cnt?(cnt-1):cnt);
                                                matchfrg=1;
                                                break;
                                        }
                                }
                                if(!matchfrg)
                                {
                                        prints("$");
                                        ptr2 = ptr;
                                }
                        }
                        else
                        {
                                prints("%s", ptr2);
                                frg = 0;
                        }
                }
                while(frg);
        return;
}
