/*
    Firebird BBS for Windows NT/2K
    Copyright (C) 2000, COMMAN,Kang Xiao-ning, kxn@student.cs.tsinghua.edu.cn

    Windows NT/2000 Service for Firebird NT

*/

#include <windows.h>
#include <stdlib.h>
#include <process.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/cygwin.h>
#include "config.h"

SERVICE_STATUS          FBServiceStatus; 
SERVICE_STATUS_HANDLE   FBServiceStatusHandle; 
 
void  __stdcall FBServiceStart (DWORD argc, LPTSTR argv); 
WINBOOL  __stdcall FBServiceCtrlHandler (DWORD opcode); 
DWORD ExecuteBBSD(DWORD argc,LPTSTR argv);

void __stdcall  FBServiceStart (DWORD argc, LPTSTR argv) 
{ 
    DWORD status; 

    FBServiceStatus.dwServiceType        = SERVICE_WIN32; 
    FBServiceStatus.dwCurrentState       = SERVICE_START_PENDING; 
    FBServiceStatus.dwControlsAccepted   = SERVICE_ACCEPT_STOP; 
    FBServiceStatus.dwWin32ExitCode      = 0; 
    FBServiceStatus.dwServiceSpecificExitCode = 0; 
    FBServiceStatus.dwCheckPoint         = 0; 
    FBServiceStatus.dwWaitHint           = 0; 
 
    FBServiceStatusHandle = RegisterServiceCtrlHandler( 
        "FirebirdNT", 
         FBServiceCtrlHandler); 
 
    if (FBServiceStatusHandle == (SERVICE_STATUS_HANDLE)0) 
    { 
        MessageBox(0,"RegisterServiceCtrlHandler failed","Error",MB_OK); 
        return; 
    } 
 
    status = ExecuteBBSD(argc,argv); 
 
    if (status != 0) 
    { 
        FBServiceStatus.dwCurrentState       = SERVICE_STOPPED; 
        FBServiceStatus.dwCheckPoint         = 0; 
        FBServiceStatus.dwWaitHint           = 0; 
        FBServiceStatus.dwWin32ExitCode      = status; 
        FBServiceStatus.dwServiceSpecificExitCode = status; 
 
        SetServiceStatus (FBServiceStatusHandle, &FBServiceStatus); 
        return; 
    } 
 
    FBServiceStatus.dwCurrentState       = SERVICE_RUNNING; 
    FBServiceStatus.dwCheckPoint         = 0; 
    FBServiceStatus.dwWaitHint           = 0; 
 
    SetServiceStatus (FBServiceStatusHandle, &FBServiceStatus); 
    return; 
} 
int mysystem(char *cmd)
{
	pid_t pid;
	int status;
	pid = fork();
	if (pid>0)
	{
	    while (waitpid(pid,	&status, 0) <0)
	        if (errno != EINTR) return -1;
        }
	else if (pid==0)
	{
	    execl(cmd,NULL);
	    _exit(errno);	
	}
	else return 127;
	return 0;
}

int stop_bbs()
{
   FILE *fp = fopen(MY_BBS_HOME BBS_PID_LOG,"r");
   char buf[255];
   pid_t mypid = getpid();
   pid_t thepid;
   if (fp)
   {
   	for (fgets(buf,255,fp);!feof(fp);fgets(buf,255,fp))
   	{
   	    strtok(buf,"\r\n ");
   	    thepid = atoi(buf);
   	    if (thepid && thepid!=mypid) kill(thepid,9);
   	}	
   	fclose(fp);
   	unlink(MY_BBS_HOME BBS_PID_LOG);
   	return 0;
   }
   return 2;
}	
WINBOOL  __stdcall FBServiceCtrlHandler (DWORD opcode)
{
	switch(opcode)
	{
		case SERVICE_CONTROL_STOP:
				stop_bbs();
		        FBServiceStatus.dwCurrentState       = SERVICE_STOPPED; 
        		FBServiceStatus.dwCheckPoint         = 0; 
        		FBServiceStatus.dwWaitHint           = 0; 
        		FBServiceStatus.dwWin32ExitCode      = 0; 
        		SetServiceStatus (FBServiceStatusHandle, &FBServiceStatus); 
			break;
		default:
			break;
	}
} 
DWORD ExecuteBBSD(DWORD argc,LPTSTR argv)
{
   char buf[255];
   cygwin_conv_to_full_win32_path(MY_BBS_HOME"/bin/bbsd.exe",buf);
   if (WinExec(buf,SW_HIDE)>31) return 0; else return ERROR_FILE_NOT_FOUND;
}

void help(void)
{
    printf("Firebird BBS NT Service -- by COMMAN \n");
    printf("Usage: fbsvc [/i] [/u]\n");
    printf("     /i: Install Firebird NT Service\n");
    printf("	 /u: Uninstall Service\n");
}
int main(int argc, char *argv[]) 
{ 
    SC_HANDLE hSCHandle;
    SC_HANDLE hService;
    char buf[1024];
    SERVICE_TABLE_ENTRY   DispatchTable[] = 
    { 
        { "FirebirdNT", FBServiceStart      }, 
        { NULL,              NULL          } 
    }; 
    GetModuleFileName(NULL,buf,1024);
    if (argc > 1)
    {
    	if (argv[1][0] != '/' && argv[1][0] != '-')
    	{
    	    help();
    	    return 0;
    	} 
    	switch (argv[1][1])
    	{
    	    case 'i':
    	    case 'u':
    	       hSCHandle = OpenSCManager( NULL,NULL,SC_MANAGER_ALL_ACCESS);
    	       if (!hSCHandle)
    	       { 
    	       	   printf("Opening SC Manager Failed\n");
    	       	   return -1;
    	       }
    	       if (argv[1][1] == 'i')
    	       {
    	       	   hService =CreateService( 
                                  hSCHandle,  
        			  "FirebirdNT",    
        			  "Firebird BBS NT",
                                  SERVICE_ALL_ACCESS,       
                                  SERVICE_WIN32_OWN_PROCESS,
                                  SERVICE_DEMAND_START,    
                                  SERVICE_ERROR_NORMAL,    
                                  buf,    
        			  NULL,                  
			          NULL,                  
          			  NULL,                  
  			          NULL,                  
                                  NULL);
                 
		   if (hService == NULL) 
		       printf("CreateService Failed!\n");
                   else 
                       printf("CreateService SUCCESS.\n"); 
  
                   CloseServiceHandle(hService); 
    	       }
    	       else 
    	       {

		   hService = OpenService( 
        	   	 hSCHandle,       // SCManager database 
		   	"FirebirdNT",       // name of service 
        		DELETE);            // only need DELETE access 
 
    		  if (hService == NULL) 
                     printf("OpenService Failed!\n"); 
                 if (! DeleteService(hService) ) 
                     printf("DeleteService Failed!\n"); 
                 else 
                     printf("DeleteService SUCCESS\n"); 
 
                 CloseServiceHandle(hService); 
    	       }
    	       CloseServiceHandle(hSCHandle);
    	    break;
    	    default :
    	    help();
    	    break;
    	}
    	return 0;
    }
/*    else
    {
    	help();
    	return -1;
    }*/
    if (!StartServiceCtrlDispatcher( DispatchTable)) 
    { 
		MessageBox(0,"Failed starting Firebird BBS Service!\nDon't execute this program directly","Error",MB_OK|MB_ICONERROR);
    } 
    return 0;
} 
 
