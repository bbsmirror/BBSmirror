
// NJU bbsnet, preview version, zhch@dii.nju.edu.cn, 2000.3.23 //

/*
    Firebird BBS for Windows NT/2K
    Copyright (C) 2000, COMMAN,Kang Xiao-ning, kxn@student.cs.tsinghua.edu.cn

*/

#include <stdio.h>
#include <termios.h>
#include <string.h>
#include <sys/times.h>
#include <time.h>

char host1[100][40], host2[100][40], ip[100][40];
int port[100], counts= 0; 
char str[]= "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()";

char datafile[80]= "bbsnet.ini"; 
char telnet[80]=   "bin/telnet";
char userid[80]=   "unknown.";

init_data() {
    FILE *fp;
    char t[256], *t1, *t2, *t3, *t4;
    fp= fopen(datafile, "r");
    if(fp== NULL) return;
    while(fgets(t, 255, fp)&& counts <= 72) {
        t1= strtok(t, " \t");
        t2= strtok(NULL, " \t\n\r");
        t3= strtok(NULL, " \t\n\r"); 
        t4= strtok(NULL, " \t\n\r");
        if(t1[0]== '#'|| t1== NULL|| t2== NULL|| t3== NULL) continue;
        strncpy(host1[counts], t1, 16);
        strncpy(host2[counts], t2, 36);
        strncpy(ip[counts], t3, 36);
        port[counts]= t4? atoi(t4): 23;
        counts++;
    } 
    fclose(fp);
}

sh(int n) {
    static oldn= -1;
    if(n>= counts) return;
    if(oldn >=0) {
        locate(oldn);
        printf("[1;32m %c.[m%s", str[oldn], host1[oldn]);
    }
    oldn= n; 
    locate(n);
    printf("[%c][1;42m%s[m", str[n], host1[n]);
    printf("[22;3H[1;37m��λ: [1;33m%s                   [22;32H[1;37m վ��: [1;33m%s              \r\n", host1[n], host2[n]);
    printf("[1;37m[23;3H����: [1;33m%s                   [1;1H", ip[n]);
}

show_all() {
    int n;
    printf("[H[2J[m");
    printf("��������������������[1;37m�Σʣ�[m������[1;37m�̣ɣ̣�[m����[1;37m�££ӣΣţ�[m������������������������\r\n");
    for(n= 1; n< 23; n++)
    printf("��                                                                            ��\r\n");
    printf("������������������������������������������������������������������������������");
    printf("[21;3H----------------------------------------------------------------------------");
    for(n= 0; n< counts; n++) {
        locate(n);
        printf("[1;32m %c.[m%s", str[n], host1[n]);
    }
}

locate(int n) {
    int x, y;
    char buf[20];
    if(n>= counts) return;
    y= n% 19+ 2;
    x= n/ 19* 24+ 4;
    sprintf(buf, "[%d;%dH", y, x);
    printf(buf);
}

int getch()
{
    int c, d, e;
    static lastc= 0;
    c= getchar();
    if(c== 10&& lastc== 13) c=getchar();
    lastc= c;
    if(c!= 27) return c;
    d= getchar();
    e= getchar();
    if(d== 27) return 27;
    if(e== 'A') return 257;
    if(e== 'B') return 258;
    if(e== 'C') return 259;
    if(e== 'D') return 260;
    return 0;
}

main_loop() {
    int p= 0;
    int c, n;
L:
    show_all();
    sh(p);
    fflush(stdout);
    while(1) {
        c= getch();
        if(c== 3|| c== 4|| c== 27|| c< 0) break;
        if(c== 257&& p> 0) p--;
        if(c== 258&& p< counts- 1) p++;
        if(c== 259&& p< counts- 19) p+=19;
        if(c== 260&& p>= 19) p-=19; 
        if(c== 13|| c== 10) { 
            bbsnet(p);
            goto L;
        }
        for(n=0; n< counts; n++) if(str[n]== c) p= n;
        sh(p);
        fflush(stdout);
    } 
}

bbsnet(int n) {
    char pp[180];
    if(n>= counts) return;
    printf("[H[2J[1;32mo ����: %s (%s)\r\n", host1[n], ip[n]);
    printf("%s\r\n\r\n[m", "o ������ʱ����Ctrl+C�˳�");
    syslog(host1[n]);
    sprintf(pp, "%d", port[n]);
    fflush(stdout);
    reset_tty();
    execl(telnet, "bin/telnet.exe", ip[n], pp, NULL);
}

static struct termios t1, t2;

int save_tty() {
    if(ttyname(0)) tcgetattr(0, &t1);
}

init_tty() {
    if(ttyname(0)) {
         //cfmakeraw(&t2);
      t2.c_iflag &= ~(IGNBRK|BRKINT|PARMRK|ISTRIP
                     |INLCR|IGNCR|ICRNL|IXON);
      t2.c_oflag &= ~OPOST;
      t2.c_lflag &= ~(ECHO|ECHONL|ICANON|ISIG|IEXTEN);
      t2.c_cflag &= ~(CSIZE|PARENB);
      t2.c_cflag |= CS8;
         tcsetattr(0, TCSANOW, &t2);
     }    
}

reset_tty() {
    if(ttyname(0)) tcsetattr(0, TCSANOW, &t1);
}

main(int n, char* cmd[]) {
    save_tty();
    init_tty();
    if(n>= 2) strcpy(datafile, cmd[1]);
    if(n>= 3) strcpy(telnet, cmd[2]);
    if(n>= 4) strcpy(userid, cmd[3]); 
    init_data();
    main_loop();
    printf("[m");
    reset_tty();
}

syslog(char* s) {
        char buf[512], timestr[16], *thetime;
        time_t dtime;
        FILE *fp;
        fp=fopen("bbsnet.log", "a");
        time(&dtime);
        thetime = (char*) ctime(&dtime);
        strncpy(timestr, &(thetime[4]), 15);
        timestr[15] = '\0';
        sprintf(buf,"%s %s %s\n", userid, timestr, s) ;
        fprintf(fp, buf);
        fclose(fp);
}

