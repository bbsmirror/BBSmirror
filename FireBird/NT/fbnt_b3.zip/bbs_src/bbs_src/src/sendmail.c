// sendmail.c : send mail using M$ SMTP pickup service
//
//    Firebird BBS for Windows NT
//    Copyright (C) 2000, COMMAN,Kang Xiao-ning, kxn@student.cs.tsinghua.edu.cn

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

#define MAILPICKDIR "I:\\InetPub\\mailroot\\Pickup"

int main(int argc, char* argv[])
{
	char fnbuf[255];
	int c;
	FILE *fp;
    sprintf(fnbuf,"%s\\%d.txt",MAILPICKDIR,rand());
    fp = fopen(fnbuf,"w");
	c = fgetc(stdin);
	while (!feof(stdin))
	{
		fputc(c,fp);
		c = fgetc(stdin);
	}
	fclose(fp);
}
