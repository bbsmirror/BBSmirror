#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>

main()
{
    char * imgfile = "fuck/test.dat";
    struct stat st;
    struct sysheader {
        char    *buf;
        int     menu, key, len;
    } shead;

    char        *ptr, *func;
    int         fh, n, diff;

    if( (fh = open( imgfile, O_RDONLY )) > 0 ) {
        fstat( fh, &st );
        ptr = malloc( st.st_size );
        read( fh, &shead, sizeof( shead ) );
        read( fh, ptr, st.st_size );
        close( fh );
  }
}