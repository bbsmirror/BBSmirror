/*
    WWW Interface for Firebird Bulletin Board System
    Copyright (C) 1996,1997 Computer Application Studio.
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdio.h>
#include "bbs2www.h"

#define STRLEN   80

void main (int argc, char *argv[])
{
   char buf[1024];
   char ArgOfQuery[STRLEN];
   int index;

   strncpy(ArgOfQuery, getenv("QUERY_STRING"), sizeof(char) * STRLEN);   
   printf("Content-type: text/html\n\n\n");
   printf("<html>\n");
   printf("<title>Welcome to %sBBS</title>\n", SCHOOLSHORT);
   printf("<body background=\"%sbackground.gif\">\n", GIFSHOME);
   printf("<center>\n");

   printf("<font size=5 color=red>");
   printf("<i>%s -- ����������</i>", STATIONNAME); 
   printf("</font>\n");

   printf("<hr>\n");

   printf("<table border=1 align=center>\n");
   printf("<tr><th>���<th>���<th>����</tr>\n");
   for (index=0; index<SectNum; index++)
   {
      printf("<tr><td>%d<td><a href=\"/cgi-bin/bbsboa?%d\">", index + 1, index);
      printf(" %s</a>", SectNames[index][0]);
      printf("<td>%s</tr>\n", SectNames[index][1]);
   }
   printf("</table>\n");
   printf("<hr>");

   printf("[<a href=\"%s\">������ҳ</a>]", BBSURL);
   printf(" [<a href=\"/cgi-bin/bbsall\">ȫ��������</a>]");
   printf(" [<a href=\"/cgi-bin/bbs0an\">������</a>]");
   printf(" [<a href=\"%s\">%s</a>]", SCHOOLURL, SCHOOLNAME);

   printf("</center>\n");
   printf("</body>\n");
   printf("</html>");
}
