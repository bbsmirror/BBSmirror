/*
    WWW Interface for Firebird Bulletin Board System
    Copyright (C) 1996,1997 Computer Application Studio.
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/stat.h>

#include "bbs2www.h"

#define STRLEN   80

struct fileheader {             
   char filename[STRLEN];     
   char owner[STRLEN];
   char title[STRLEN];
   unsigned level;
   unsigned char accessed[12];
};


void main (int argc, char *argv[])
{
   struct fileheader  DirInfo;
   char ch; 
   int  fd;
   FILE *inf;
   char ArgOfQuery[STRLEN];
   char LineBuf[512];
   char Board[20], *quser, *ptr, buf[256];
   char FileName[20];
   char DirOfBoard[200];
   struct stat st;
   int  index = 0, number, total, num = 0, newfile = 0;

  
   strncpy(ArgOfQuery, getenv("QUERY_STRING"), sizeof(char) * STRLEN);
   if (strstr(ArgOfQuery, "..") != NULL)
   {
      printf("Error in handling file\n");
      exit(1);
   }
   number = strlen(ArgOfQuery); 
   while((index < number) && (ArgOfQuery[index] != '='))
      index ++;
   number = atoi(ArgOfQuery + index + 1); 
   ArgOfQuery[index] = '\0';
   
   printf("Content-type: text/html\n\n\n");
   printf("<html>\n");
   printf("<title>Welcome to %sBBS</title>\n", SCHOOLSHORT);
   printf("<body background=\"%sbackground.gif\">\n", GIFSHOME);
   
   index = 0;
   while(ArgOfQuery[index] != '/')
   {
      if(ArgOfQuery[index] == '\0')
         break;
      Board[index] = ArgOfQuery[index];
      index++;
   }
   Board[index] = '\0';
   strcpy(FileName, ArgOfQuery + index + 1);
   if(strstr(FileName, "M.") == 0)
      newfile = 1;
   else
   {
      sprintf(DirOfBoard, "%sboards/", BBSHOME);
      strcat(DirOfBoard, Board);
      strcat(DirOfBoard, "/.DIR");
      fd = open(DirOfBoard, O_RDONLY);
      if (fd == -1) 
      {
         fprintf(stderr, "Error in handling file!\n");
         exit(1);
      }
   }

   printf("<form method=post action=\"/cgi-bin/bbssnd\">");
   printf("<p>");
   printf("��������������� <input type=text name=board size=15 maxlength=15 value=%s> \n", Board);
   printf(" <input type=radio name=exchange value=Y checked>ת�� \n");
   printf(" <input type=radio name=exchange value=N>վ���ż�<br>\n");
   printf("ʹ�ñ��� <input type=text name=title size=40 maxlength=100 value=\"");
   if(newfile == 0)
   {
      while ( sizeof(DirInfo) == read(fd, &DirInfo, sizeof(DirInfo)))
      {
         if(strcmp(DirInfo.filename, FileName) == 0)
         {
            if(strncmp(DirInfo.title, "Re: ", sizeof(char) * 4) != 0)
            printf("Re: ");
            printf("%s", DirInfo.title);
            break;
         }
      }
      close(fd);
   }

   printf("\"><br>\n");
   printf("���Ĵ��� <input type=text name=username size=15 maxlength=20><br>\n");
   printf("�������� <input type=password name=passwd size=15 maxlength=20><br>\n");
   printf("</p>");
   printf("<textarea name=text rows=20 cols=60>\n");

   if (newfile ==0)
   {
      sprintf(LineBuf, "%sboards/%s/%s", BBSHOME, Board, FileName);

      inf = fopen(LineBuf, "r");
      if (inf == NULL)
      {
         printf("Error in handling file\n");
         exit(1);
      }

      fgets( buf, 256, inf );
      if( (ptr = strrchr( buf, ')' )) != NULL ) {
         ptr[1] = '\0';
         if( (ptr = strchr( buf, ':' )) != NULL ) {
            quser = ptr + 1;
            while( *quser == ' ' )  quser++;
         }
      }
      printf("�� �� %s �Ĵ������ᵽ: ��\n", quser);
      while( fgets( buf, 256, inf ) != NULL )
         if( buf[0] == '\n' )  break;
      while( fgets( buf, 256, inf ) != NULL )
      {
         if( strcmp( buf, "--\n" ) == 0 )
            break;
         printf(": ");
         index = 0;
         while(index < 256 && buf[index] != '\0')
         {
            if(buf[index] != 27)
               putchar(buf[index]);
            else
               while(buf[index] != 'm' && index < 256)
                  index++;
            index++;
         }
      }
   }
   printf("</textarea>\n");
   printf("<center><p><input type=submit value=\"����\">");
   printf(" <input type=reset value=\"���\"></P></center>\n");
   printf("</form>\n");

   printf("<hr>\n");
   printf("<center>\n");
   printf("[<a href=\"%s\">������ҳ</a>]", BBSURL);
   printf(" [<a href=\"/cgi-bin/bbssec\">����������</a>]");
   printf(" [<a href=\"/cgi-bin/bbsall\">ȫ��������</a>]");
   printf(" [<a href=\"/cgi-bin/bbsdoc?S%s=%d\">��������</a>]", Board, number);
   printf("</center>\n"); 
   printf("</body>\n");
   printf("</html>");
}
