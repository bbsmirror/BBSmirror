/*
    WWW Interface for Firebird Bulletin Board System
    Copyright (C) 1996, Computer Application Studio.
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "bbs2www.h"

#define STRLEN   80
#define BM_LEN   60

struct fileheader {             
   char filename[STRLEN];     
   char owner[STRLEN];
   char title[STRLEN];
   unsigned level;
   unsigned char accessed[12];   
};

struct boardheader {             
        char filename[STRLEN];   
        char owner[STRLEN - BM_LEN];
        char BM[ BM_LEN ];
        char title[STRLEN ];
        unsigned level;
        unsigned char accessed[ 12 ];
};

int namesort(void *board1, void *board2)
{
   struct boardheader *b1, *b2;
   b1 = (struct boardheader *)board1;
   b2 = (struct boardheader *)board2;
   return(strcasecmp(b1->filename, b2->filename));
}

void main (int argc, char *argv[])
{
   int fd,fd1;
   char DirOfBoard[200];
   struct boardheader *buffer;
   struct boardheader BoardInfo;
   struct fileheader  DirInfo;
   char BoardsFile[512];
   char category;
   int  index = 0, num;
   int  total, count; 
   struct stat st;
   char Secret_boards[][20] = {"admin", "comment", "deleted", "junk", "master", "syssecurity"};

   printf("Content-type: text/html\n\n\n");
   printf("<html>\n");
   printf("<title>Welcome to %sBBS</title>\n", SCHOOLSHORT);
   printf("<body background=\"%sbackground.gif\">\n", GIFSHOME);
   printf("<center>\n");

   printf("<font size=5 color=red>");
   printf("<i>%s -- ȫ���������б�</i>", STATIONNAME);
   printf("</font>\n");

   printf("<hr>\n");

   printf("<table border=1 align=center>\n");
   printf("<tr><th>���<th>����������<th>����<th>��������<th>������</tr>");
  
   sprintf(BoardsFile, "%s.BOARDS", BBSHOME);
   fd = open(BoardsFile, O_RDONLY);
   if (fd == -1)
   {
      printf("Error in opening file %s", BoardsFile);
      exit(1);  
   }
   fstat( fd, &st );
   total = st.st_size / sizeof(BoardInfo);
   buffer = (struct boardheader *)calloc(total, sizeof(BoardInfo));
   if (buffer == NULL)
   {
      printf("Out of memory");
      exit(1);
   } 
   index = 0;
   while (sizeof(BoardInfo) == read(fd, &BoardInfo, sizeof(BoardInfo)))
   {
      if(!strcmp(BoardInfo.filename,Secret_boards[0]))
      { 
         total--;
         continue;
      }
      if(!strcmp(BoardInfo.filename,Secret_boards[1])) 
      {
         total--;
         continue;
      }
      if(!strcmp(BoardInfo.filename,Secret_boards[2])) 
      {
         total--;
         continue;
      }
      if(!strcmp(BoardInfo.filename,Secret_boards[3]))
      { 
         total--;
         continue;
      }
      if(!strcmp(BoardInfo.filename,Secret_boards[4])) 
      {
         total--;
         continue;
      }
      if(!strcmp(BoardInfo.filename,Secret_boards[5])) 
      {
         total--;
         continue;
      }
      strcpy(buffer[index].filename, BoardInfo.filename);
      strcpy(buffer[index].BM, BoardInfo.BM);                        
      strcpy(buffer[index].title, BoardInfo.title);
      index++;
   }  
   qsort(buffer, total, sizeof(BoardInfo), namesort); 
   num = 0;
   for (index = 0; index < total; index++)
   {
      sprintf(DirOfBoard, "%sboards/", BBSHOME);
      strcat(DirOfBoard, buffer[index].filename);
      strcat(DirOfBoard, "/.DIR");
      fd1= open(DirOfBoard, O_RDONLY);
      if (fd1 == -1)
         continue;
      fstat( fd1, &st );
      count = st.st_size / sizeof(DirInfo);
      close(fd1);
      num++; 
      printf("<tr><td>%d<td><a href=\"/cgi-bin/bbsdoc?N%s\">%s</a>",
             num, buffer[index].filename,  buffer[index].filename);
      printf("<td> %s<td> %s<td>%d", buffer[index].BM, buffer[index].title + 1, count);
   }
   close(fd);
   free(buffer);
   printf("</table>\n");

   printf("<hr>");

   printf("[<a href=\"%s\">������ҳ</a>]", BBSURL);
   printf(" [<a href=\"/cgi-bin/bbssec\">����������</a>]");
   printf(" [<a href=\"/cgi-bin/bbs0an\">������</a>]");
   printf(" [<a href=\"%s\">%s</a>]", SCHOOLURL, SCHOOLNAME);

   printf("</center>\n");
   printf("</body>\n");
   printf("</html>");
}
