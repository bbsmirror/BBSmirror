/*
    WWW Interface for Firebird Bulletin Board System
    Copyright (C) 1996,1997 Computer Application Studio.
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/stat.h>

#include "bbs2www.h"

#define STRLEN   80

struct fileheader {             
   char filename[STRLEN];     
   char owner[STRLEN];
   char title[STRLEN];
   unsigned level;
   unsigned char accessed[12];   
};


void main (int argc, char *argv[])
{
   char buf[200];
   struct fileheader  DirInfo;
   char ch, *ptr; 
   int  fd;
   FILE *fn;
   int  index = 1;
   int  total;
   int  number = 0;
   int start, end;
   struct stat st;
   char ArgOfQuery[STRLEN];
  
   strncpy(ArgOfQuery, getenv("QUERY_STRING"), sizeof(char) * STRLEN);
   ch = ArgOfQuery[0];
   strcpy(ArgOfQuery, ArgOfQuery + 1);
   if ((ch == 'S') || (ch == 'U') || (ch == 'D'))
   {
      index = 0;
      number = strlen(ArgOfQuery); 
      while((index < number) && (ArgOfQuery[index] != '='))
         index ++;
      number = atoi(ArgOfQuery + index + 1); 
      ArgOfQuery[index] = '\0';
   }

   printf("Content-type: text/html\n\n\n");
   printf("<html>\n");
   printf("<title>Welcome to %sBBS</title>\n", SCHOOLSHORT);
   printf("<body background=\"%sbackground.gif\">\n", GIFSHOME);
   printf("<center>\n");

   printf("<font size=5 color=red>");
   printf("%s -- [%s������]�����б�", STATIONNAME, ArgOfQuery);
   printf("</font>\n");

   printf("<hr>\n");
   
   sprintf(buf, "%sboards/%s/.DIR", BBSHOME, ArgOfQuery);
 
   fd = open(buf, O_RDONLY);
   if (fd == -1) 
   {
      fprintf(stderr, "Error in handling file!\n");
      exit(1);
   }
   fstat( fd, &st );           
   total = st.st_size / sizeof( DirInfo );
   if (total == 0)
   {
      printf("��������Ŀǰû������\n");
      exit(1);
   }  

   switch (ch){
      case 'U':  start = number - 20;
                 if (start < 1)
                    start = 1;
                 end = start + 19; 
                 if (end > total)
                    end = total;
                 break;
      case 'D':  end = number + 20;  
                 if (end > total)
                    end = total;
                 start = end - 19;
                 if (start < 1)
                    start = 1; 
                 break;
      case 'A':  start = 1;
                 end = total;
                 break;
      case 'S':  if (number < 11)
                 {
                    start = 1; 
                    end = 20;
                    if (end > total)
                       end = total;
                 }  
                 else if (number > total - 10)
                 {
                    end = total;
                    start = end - 19;
                    if (start < 1)
                       start = 1;
                 }
                 else
                 {
                     start = number - 10;
                     end = start + 19; 
                 }
                 break;
      default :  end = total;
                 start = total - 19;
                 if (start < 1)
                     start = 1;
   }
   
   printf("<table border=1 align=center>\n");
   printf("<tr><th>���<th>����<th>����</tr>");
   index = 1;
   while ( sizeof(DirInfo) == read(fd, &DirInfo, sizeof(DirInfo)))
   {
      if ((start <= index) && (index <= end))
      {  
         printf("<tr><td>%d<td><a href=\"/cgi-bin/bbscon?%s/%s=%d\">",index, ArgOfQuery, DirInfo.filename, index);
         printf("%s</a><td>%s ", DirInfo.title, DirInfo.owner);
      }
      index++;
   }
   close(fd);
   printf("</table>\n");

   printf("<hr>");

   printf("<form action=\"/cgi-bin/bbsdoc\">");

/* Hide these too items in case it's too long
   printf(" [<a href=\"/cgi-bin/bbssec\">����������</a>]");
   printf(" [<a href=\"/cgi-bin/bbsall\">ȫ��������</a>]");
*/
   sprintf(buf, "%s0Announce/.Search", BBSHOME);
   if(fn = fopen(buf, "r"))
   {
      while( fgets(buf, sizeof(buf), fn))
      {
         ptr = strstr(buf, ":");
         if (ptr)
         {
             *ptr = '\0';
             ptr = strtok(ptr+1, " \t\n");
             if ( strstr(buf, ArgOfQuery))
             {
                printf("[<a href=/cgi-bin/bbs0an?/%s>������</a>]", ptr);
                break;
             }
         }
      } 
      fclose(fn);
   }
   if (ch != 'A')
   {
      if (start > 1)
         printf(" [<a href=\"/cgi-bin/bbsdoc?U%s=%d\">��һҳ</a>]", ArgOfQuery, start);
      if (end < total)
         printf(" [<a href=\"/cgi-bin/bbsdoc?D%s=%d\">��һҳ</a>]", ArgOfQuery, end);
      if (total > 20)
      {
         printf(" [<a href=\"/cgi-bin/bbsdoc?A%s\">ȫ��</a>]", ArgOfQuery);
         printf(" ��%dƪ,����", total);
         printf("<input type=\"text\" name=\"S%s\" size=4>ƪ", ArgOfQuery);   
      }
   }
   printf(" [<a href=/cgi-bin/bbspst?%s>��������</a>]", ArgOfQuery);
   printf("</form>\n");

   printf("</center>\n");
   printf("</body>\n");
   printf("</html>");
}

