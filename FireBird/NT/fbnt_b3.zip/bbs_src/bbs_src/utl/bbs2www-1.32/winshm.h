#ifndef WINSHM_H
#define WINSHM_H

#define IPC_CREAT 0x80000000

int shmget(int key,int size,int shmflg);

void *shmat(int shmid,int size,int shmflg);
#endif