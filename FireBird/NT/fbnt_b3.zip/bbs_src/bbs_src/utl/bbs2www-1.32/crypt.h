#ifndef CRYPT_H
#define CRYPT_H
char *crypt(const char *key,const char * salt);
#endif