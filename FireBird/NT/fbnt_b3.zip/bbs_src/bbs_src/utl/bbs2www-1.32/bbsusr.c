/*
    BBS2WWW -- WWW Interface for Firebird Bulletin Board System
    Copyright (C) 1996-1999 Computer Application Studio.
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/uio.h>

#include "bbs2www.h"

struct user_info user_record[MAXACTIVE];


char *ModeType(int mode)
{
    switch(mode) {
        case IDLE:      return "" ;
        case NEW:       return "��վ��ע��" ;
        case LOGIN:     return "���뱾վ";
#ifdef FB25
        case CSIE_ANNOUNCE:     return "��ȡ����";
        case CSIE_TIN:          return "����TIN";
        case CSIE_GOPHER:       return "����Gopher";
#else
        case DIGEST:    return "���������";
#endif
        case MMENU:     return "��ѡ��";
        case ADMIN:     return "������ѡ��";
        case SELECT:    return "ѡ��������";
        case READBRD:   return "��������";
        case READNEW:   return "��������";
        case READING:   return "Ʒζ����";
        case POSTING:   return "��������" ;
        case MAIL:      return "�����ż�" ;
        case SMAIL:     return "�����Ÿ�";
        case RMAIL:     return "�����ż�";
        case TMENU:     return "����ѡ��";
        case LUSERS:    return "�����ķ�";
        case FRIEND:    return "Ѱ�Һ���";
        case MONITOR:   return "̽������";
        case QUERY:     return "��ѯ����";
        case TALK:      return "����" ;
        case PAGE:      return "����" ;
        case CHAT1:     return "Chat1";
        case CHAT2:     return "Chat2";
        case CHAT3:     return "Chat3";
        case CHAT4:     return "Chat4";
        case IRCCHAT:   return "��̸IRC";
        case LAUSERS:   return "̽������";
        case XMENU:     return "ϵͳ��Ѷ";
        case VOTING:    return "ͶƱ";
        case BBSNET:    return "BBSNET";
        case EDITWELC:  return "�༭Welc";
        case EDITUFILE: return "�༭���˵�";
        case EDITSFILE: return "����ϵͳ��";
        case ZAP:       return "����������";
#ifndef FB25
        case GAME:      return "��������";
        case SYSINFO:   return "���ϵͳ";
        case ARCHIE:    return "ARCHIE";
        case DICT:      return "�����ֵ�";
#endif
        case LOCKSCREEN:return "өĻ����";
        case NOTEPAD:   return "���԰�";
        case GMENU:     return "������";
        case MSG:       return "��ѶϢ";
        case USERDEF:   return "�Զ�����";
        case EDIT:      return "�޸�����";
        case OFFLINE:   return "��ɱ��..";
        case EDITANN:   return "���޾���";
        case WWW:       return "���� WWW";
#ifndef FB25
        case HYTELNET:  return "Hytelnet";
#endif
        case CCUGOPHER: return "��վ����";
        case LOOKMSGS:  return "�쿴ѶϢ";
        case WFRIEND:   return "Ѱ������";
#ifdef FB30
        case WNOTEPAD:  return "���߻���";
        case BBSPAGER:  return "��·����";
#endif
        default: return "ȥ������!?" ;
    }
}

void swap_user_record(int a, int b)
{
        struct user_info c;

        memcpy(&c, &user_record[a], sizeof(struct user_info));
        memcpy(&user_record[a], &user_record[b], sizeof(struct user_info));
        memcpy(&user_record[b], &c, sizeof(struct user_info));
}

void sort_user_record(int left, int right)
{
   int i,last;

   if(left>=right)
       return;
   swap_user_record(left,(left+right)/2);
   last=left;
   for(i=left+1;i<=right;i++)
      if(strcasecmp(user_record[i].userid,user_record[left].userid)<0)
         swap_user_record(++last,i);
   swap_user_record(left,last);
   sort_user_record(left,last-1);
   sort_user_record(last+1,right);
}

char *idle_str( uent )
struct user_info *uent ;
{
    static char hh_mm_ss[ 32 ];
#ifndef BBSD
    struct stat buf;
    char        tty[ 128 ];
#endif
    time_t      now, diff;
    int         limit, hh, mm;

    if (uent == NULL) {
        strcpy(hh_mm_ss, "����");
        return hh_mm_ss;
    }

#ifndef BBSD
    strcpy( tty, uent->tty );

#ifndef SOLARIS
    if ( (stat( tty, &buf ) != 0) ||
         (strstr( tty, "tty" ) == NULL)) {
        strcpy( hh_mm_ss, "����");
        return hh_mm_ss;
    };
#else
    if ( (stat( tty, &buf ) != 0) ||
         (strstr( tty, "pts" ) == NULL)) {
        strcpy( hh_mm_ss, "����");
        return hh_mm_ss;
    }
#endif

#endif

    now = time( 0 );

#ifndef BBSD
    diff = now - buf.st_atime;
#else
    diff = now - uent->idle_time;
#endif

#ifdef DOTIMEOUT
    /* the 60 * 60 * 24 * 5 is to prevent fault /dev mount from
       kicking out all users */

#ifndef FB25
    if (uent->ext_idle)
        limit = IDLE_TIMEOUT * 3;
    else
#endif
        limit = IDLE_TIMEOUT;

    if ((diff > limit) && (diff < 86400 * 5))
        kill(uent->pid, SIGHUP);
#endif

    hh = diff / 3600;
    mm = (diff / 60) % 60;

    if ( hh > 0 )
        sprintf( hh_mm_ss, "%d:%02d", hh, mm );
    else if ( mm > 0 )
        sprintf( hh_mm_ss, "%d", mm );
    else sprintf ( hh_mm_ss, "   ");

    return hh_mm_ss;
}

int main (int argc, char *argv[])
{
   int  i, num, fh, shmkey, shmid; 
   struct user_info *uin;
   struct UTMPFILE  *utmpshm;

   printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
   printf("<html>\n");
#ifdef STYLESHEET
   printf("<link rel=stylesheet type=text/css href=\"%s\">\n", STYLESHEET);
#endif
   printf("<title>%sʹ�����б�</title>\n", BBSID); 
   printf("<body>\n");
   printf("<center>\n");

   printf("<table class=title width=90%%><tr>");
   printf("<th class=title align=center>%s -- �����û��б�</th>\n",
           BBSNAME);
   printf("</table>\n");

   printf("<hr>\n");

   num = 0;
   shmid = shmget(UTMP_SHMKEY, sizeof(struct UTMPFILE), 0 );
   if (shmid >= 0)
   {
      utmpshm = (struct UTMPFILE *) shmat( shmid, NULL, 0 );
      if (utmpshm != (struct UTMPFILE *) -1)
      {
         num = 0;
         for( i = 0; i < USHM_SIZE; i++ )
         {
            uin = &(utmpshm->uinfo[ i ]);

            if(!uin->active || !uin->pid || uin->invisible)
               continue;
            memcpy(&user_record[num], uin, sizeof(struct user_info));
            num++;
         }
      }
   }

   if (num == 0)
   {
      printf("<p>Ŀǰû���û���վ��</p>\n");
   }
   else
   {
      printf("<table class=body>\n");
      printf("<tr><th class=body>���<th class=body>ʹ���ߴ���");
      printf("<th class=body>ʹ�����ǳ�<th class=body>����<th class=body>");
      printf("��̬<th class=body>ʱ:��\n");

      sort_user_record(0, num - 1);

      for (i = 0; i < num; i++)
      {
         printf("<tr><td class=body%d>%d", i % 2 + 1, i + 1);
         printf("<td class=body%d><a href=\"%s/bbsqry?%s\">%s</a>", 
		i % 2 + 1, BBSCGI, user_record[i].userid, user_record[i].userid);
         printf("<td class=body%d><a href=\"%s/bbsqry?%s\">%s</a>",
		i % 2 + 1, BBSCGI, user_record[i].userid, user_record[i].username);
         printf("<td class=body%d>%s", i % 2 + 1, user_record[i].from);
         printf("<td class=body%d>%s", i % 2 + 1, ModeType(user_record[i].mode));
         printf("<td class=body%d align=right>%s", i % 2 + 1, idle_str(&user_record[i]));
      }
      
      printf("</table>\n");
   }


   printf("<hr>");

   printf("<table class=foot><th class=foot><a href=\"%s\">������ҳ</a>", 
		BBSURL);
   printf("<th class=foot><a href=\"%s/bbssec\">����������</a>", BBSCGI);
   printf("<th class=foot><a href=\"%s/bbsall\">ȫ��������</a>", BBSCGI);
   printf("<th class=foot><a href=\"%s/bbs0an\">����������</a>", BBSCGI);
   printf("<th class=foot><a href=\"%s\">%s</a></table>", SCHOOLURL, 
		SCHOOLNAME);

   printf("</center>\n");
   printf("</body>\n");
   printf("</html>");
}
