/*
    BBS2WWW -- WWW Interface for Firebird Bulletin Board System
    Copyright (C) 1996-1999 Computer Application Studio.
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <time.h>

#include "bbs2www.h"

char *crypt();

char *ptr;

char userid[IDLEN + 1], passwd[PASSLEN + 1], repass[IDLEN + 1], 
     nickname[NAMELEN], realname[NAMELEN], career[STRLEN],
     address[STRLEN], email[NAMELEN], phone[STRLEN], year[5], month[3], day[3];
int gender;

void plustospace(char *str) 
{
    register int x;

    for(x=0;str[x];x++) if(str[x] == '+') str[x] = ' ';
}

char x2c(char *what) {
    register char digit;

    digit = (what[0] >= 'A' ? ((what[0] & 0xdf) - 'A')+10 : (what[0] - '0'));
    digit *= 16;
    digit += (what[1] >= 'A' ? ((what[1] & 0xdf) - 'A')+10 : (what[1] - '0'));
    return(digit);
}

void unescape_url(char *url) {
    register int x,y;

    for(x=0,y=0;url[y];++x,++y) {
        if((url[x] = url[y]) == '%') {
            url[x] = x2c(&url[y+1]);
            y+=2;
        }
    }
    url[x] = '\0';
}

void read_form(char *buf, char *str, char *match, char *next)
{
   int i, length;

   buf = strstr(buf, match); 
   if(buf == NULL || (strstr(buf, next)== NULL)) 
      return;
   else
      buf += strlen(match); 
   length = strlen(next);
   for(i = 0; strncmp(buf + i, next, length); i++)
      str[i] = buf[i];
   str[i] = '\0';    
}

void print_table(char *information)
{
   free(ptr);

   printf("<form method=post action=\"%s/bbsreg\">\n", BBSCGI);
   printf("<table class=title width=90%%><tr>");
   printf("<th class=title align=center>%s -- ���û�ע��</th>\n",
           BBSNAME);
   printf("</table>\n");
   printf("<hr>\n");

   printf("<table class=post>\n");
   printf("<tr><td class=post align=center colspan=3>");
   if (information)
      printf("%s\n", information);
   else
      printf("���ʵ��д�����ע�����뵥.����������ٵ����Ͻ���������.\n");

   printf("<tr><td class=post align=right>���������:\n");
   printf("<td class=post colspan=2 align=left>");
   printf("<input type=text name=userid size=%d", IDLEN);
   printf(" maxlength=%d value=\"%s\">\n", IDLEN, userid);

   printf("<tr><td class=post align=right>���趨��������:\n");
   printf("<td class=post colspan=2 align=left>");
   printf("<input type=password name=passwd size=14 maxlength=%d", PASSLEN);
   printf(" value=\"%s\">\n", passwd);

   printf("<tr><td class=post align=right>��������һ����������:\n");
   printf("<td class=post colspan=2 align=left>");
   printf("<input type=password name=repass size=14 maxlength=%d", PASSLEN);
   printf(" value=\"%s\">\n", repass);

   printf("<tr><td class=post align=right>�����������ǳ�:\n");
   printf("<td class=post colspan=2 align=left>");
   printf("<input type=text name=nickname size=20 maxlength=%d", NAMELEN);
   printf(" value=\"%s\"> (����,С����)\n", nickname);

   printf("<tr><td class=post align=right>������������ʵ����:\n");
   printf("<td class=post colspan=2 align=left>");
   printf("<input type=text name=realname size=20 maxlength=%d", NAMELEN);
   printf(" value=\"%s\"> (վ����������ܵ�!)\n", realname);

   printf("<tr><td class=post align=right>���������ķ���λ:\n");
   printf("<td class=post colspan=2 align=left>");
   printf("<input type=text name=career size=50 maxlength=%d", 
		STRLEN - 10);
   printf(" value=\"%s\">\n", career);

   printf("<tr><td class=post align=right>����������ͨѶ��ַ:\n");
   printf("<td class=post colspan=2 align=left>");
   printf("<input type=text name=address size=50 maxlength=%d", STRLEN - 10);
   printf(" value=\"%s\">\n", address);

   printf("<tr><td class=post align=right>�������������:\n");
   printf("<td class=post colspan=2 align=left>");
   printf("<input type=text name=email size=%d", NAMELEN);
   printf(" maxlength=%d value=\"%s\">\n", NAMELEN, email);

   printf("<tr><td class=post align=right>����������绰:\n");
   printf("<td class=post colspan=2 align=left>");
   printf("<input type=text name=phone size=%d", NAMELEN);
   printf(" maxlength=%d value=\"%s\"> (����������ʱ��)\n", STRLEN, phone);

   printf("<tr><td class=post align=right>��������������:\n");
   printf("<td class=post align=left>");
   printf("<input type=text name=year size=4 maxlength=4");
   printf(" value=\"%s\">��", year);
   printf("<input type=text name=month size=2 maxlength=2");
   printf(" value=\"%s\">��", month);
   printf("<input type=text name=day size=2 maxlength=2");
   printf(" value=\"%s\">��", day);

   printf("<td class=post align=left>�����Ա���: ");
   printf("<input type=radio name=gender value=0");
   if (gender == 0)
      printf(" checked");
   printf(">�� <input type=radio name=gender value=1");
   if (gender == 1)
      printf(" checked");
   printf(">Ů");

   printf("</table><hr>\n");

   printf("<input type=submit value=\"ע��\">");
   printf(" <input type=reset value=\"���\">\n");
   printf("</form>\n");
   printf("<center></body>\n</html>\n");
   exit(1);
}

int main (int argc, char *argv[])
{
   FILE *fp;
   char *buf, *ptr1, *pw, buf1[256], saltc[2], filename[STRLEN];
   int  i, c, length, fh, total;
   long salt;
   struct userec newuser;
   struct stat	st;
   struct tm *tmnow;
   time_t       now;


   printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
   printf("<html>\n");
#ifdef STYLESHEET
   printf("<link rel=stylesheet type=text/css href=\"%s\">\n", STYLESHEET);
#endif
   printf("<title>%s�û��Ǽ�</title>\n", BBSID);
   printf("<body><center>\n");


   ptr = getenv("CONTENT_LENGTH");
   if (!ptr)
      print_table(NULL);

   length = atoi(ptr);

   ptr = buf = (char *)malloc(length + 1);
   if (buf == NULL)
   {
      printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
      printf("Out of memory!\n");
      exit(1);
   }
   buf[length] = '\0';
   fread(buf, sizeof(char), length, stdin);
   plustospace(buf);
   unescape_url(buf);

   read_form(buf, userid, "userid=", "&passwd=");
   read_form(buf, passwd, "passwd=", "&repass=");
   read_form(buf, repass, "repass=", "&nickname=");
   read_form(buf, nickname, "nickname=", "&realname=");
   read_form(buf, realname, "realname=", "&career=");
   read_form(buf, career, "career=", "&address=");
   read_form(buf, address, "address=", "&email=");
   read_form(buf, email, "email=", "&phone=");
   read_form(buf, phone, "phone=", "&year=");
   read_form(buf, year, "year=", "&month=");
   read_form(buf, month, "month=", "&day=");
   read_form(buf, day, "day=", "&gender=");

   if((buf = strstr(buf, "gender=")) == NULL)
      gender = 0;
   else
      gender = atoi(buf + 7);

   if (!userid[0])
      print_table("���������!");
   for (i = 0; userid[i]; i++)
      if (!isalpha(userid[i]) && userid[i] != '_')
	print_table("���ű���ȫΪӢ����ĸ!");
   if (strlen(userid) < 2)
      print_table("����������������Ӣ����ĸ!\n");
   if (!passwd[0])
      print_table("����������!");
   if (strlen(passwd) < 4 || !strcmp(passwd, userid))
      print_table("����̫�̻���ʹ���ߴ�����ͬ, ����������!");
   if (!repass[0])
      print_table("��������������!");
   if (strcmp(passwd, repass))
      print_table("������������벻һ��!");
   if (!nickname[0] || strlen(nickname) < 2) 
      print_table("�������ǳ�!");
   if (!realname[0] || strlen(realname) < 4)
      print_table("��������ʵ����!");
   if (!career[0] || strlen(career) < 6)
      print_table("�����뵥λ����!");
   if (!address[0] || strlen(address) < 6)
      print_table("������ͨѶ��ַ!");

   if (!email[0])
      print_table("�������������!");
   if (!strchr(email, '@') || !strchr(email, '.'))
      print_table("���������ʽΪ: user@your.domain.name\n");

   if (!phone[0] || strlen(phone) < 4)
      print_table("��������ϵ�绰!");
   if (!year[0] || !month[0] || !day[0])
      print_table("��������������!");
   now = time(NULL);
   tmnow = localtime(&now);
   if (atoi(year) <  tmnow->tm_year - 98 || atoi(year) >  tmnow->tm_year - 3 
       || atoi(month) < 1 || atoi(month) > 12
       || atoi(day) < 1 || atoi(day) > 31)
      print_table("��������������!");

   sprintf(filename, "%s/.badname", BBSHOME);
   if(fp = fopen(filename, "r" )) {
        while(fgets( buf1, STRLEN, fp )) {
            ptr1 = strtok( buf1, " \n\t\r" );
            if( ptr1 != NULL && *ptr1 != '#' && strcasecmp(ptr1, userid) == 0){
                fclose( fp );
                print_table("ϵͳ���ֻ��ǲ��ŵĴ��š�" );
            }
        }
        fclose(fp);
   }
   
   sprintf(filename, "%s/.PASSWDS", BBSHOME);
   if( (fh = open(filename, O_RDWR)) == -1 ) {
      free(ptr);
      printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
      printf( ":err: unable to open .PASSWDS file.\n" );
      exit( 0 );
   }
   fstat(fh, &st);
   total = st.st_size / sizeof(newuser);

   for(i = 0; i < total; i++)
   {
      read(fh, &newuser, sizeof(newuser));
      if( strcasecmp(userid, newuser.userid ) == 0 )
      {
         close(fh);
         print_table("���ʺ��Ѿ�����ʹ��,������ѡ��");
      }
   }

   free(ptr);

   memset(&newuser, 0, sizeof(newuser));

   strncpy(newuser.userid, userid, IDLEN);
   strncpy(newuser.username, nickname, NAMELEN);
   strncpy(newuser.realname, realname, NAMELEN);
   strncpy(newuser.email, email, STRLEN);
   strncpy(newuser.address, address, STRLEN);

   salt = 9 * getpid();
#ifndef lint
   saltc[0] = salt & 077 ;
   saltc[1] = (salt>>6) & 077 ;
#endif
   for(i=0;i<2;i++) {
      c = saltc[i] + '.' ;
      if(c > '9')
         c += 7 ;
      if(c > 'Z')
         c += 6 ;
      saltc[i] = c ;
   }
   ptr1 = crypt(passwd, saltc);

   strncpy(newuser.passwd, ptr1, PASSLEN);

   strcpy(newuser.termtype, "vt100");
   strcpy(newuser.lasthost, getenv("REMOTE_ADDR"));
   newuser.numlogins = 1;
   newuser.numposts = 0;
   if(!strcmp(newuser.userid,"guest"))
      newuser.userlevel = 0;
   else if(!strcmp(newuser.userid,"SYSOP"))
      newuser.userlevel = ~0;
   else
      newuser.userlevel = PERM_BASIC;
   newuser.firstlogin = newuser.lastlogin = time(NULL);
   newuser.userdefine = -1;
   newuser.flags[0]  = CURSOR_FLAG | PAGER_FLAG;
   newuser.flags[1] = 0;

#ifdef FB30
      newuser.birthyear = atoi(year) - 1900;
      newuser.birthmonth = atoi(month);
      newuser.birthday = atoi(day);
      if (gender == 0)
         newuser.gender = 'M';
      else
         newuser.gender = 'F';
#endif

   flock(fh, LOCK_EX);
   lseek(fh, 0, SEEK_END);
   write(fh, &newuser, sizeof(newuser));
   flock(fh, LOCK_UN);
   close(fh);

   sprintf(filename, "%s/new_register", BBSHOME);
   if (fp = fopen(filename, "a"))
   {
      fprintf( fp, "usernum: %d, %s", total + 1, ctime( &now ) );
      fprintf( fp, "userid: %s\n",    userid );
      fprintf( fp, "realname: %s\n",  realname );
      fprintf( fp, "career: %s\n",    career);
      fprintf( fp, "addr: %s\n",      address );
      fprintf( fp, "phone: %s\n",     phone );
      fprintf( fp, "birth: %s��%s��%��\n", year, month, day);
      fprintf( fp, "----\n" );
      fclose(fp);
   }

   sprintf(filename, "%s/%s", BBSHOME, FLUSH);
   if (fp = fopen(filename, "a"))
   {
      fprintf(fp, "touch by: %s", userid);
      fclose(fp);
   }

   sprintf(filename, "%s/home/%c/%s", BBSHOME, toupper(userid[0]), userid);
   mkdir(filename, 0755);

   printf("<table class=post>\n");
   printf("<tr><td class=post colspan=2 align=left>");
   printf("������! ����˳����ɱ�վ��ʹ����ע������,\n");
   printf("վ�������������������ע������, �����ĵȺ�.\n");
   printf("<tr><td class=post colspan=2 align=center>���Ļ�����������:\n");
   printf("<tr><td class=post align=right>ʹ���ߴ��ţ�\n");
   printf("<td class=post align=left>%s (%s)\n", userid, nickname);
   printf("<tr><td class=post align=right>��  ����\n");
   printf("<td class=post align=left>%s\n", realname);
   printf("<tr><td class=post align=right>��վλ�ã�\n");
   printf("<td class=post align=left>%s\n", newuser.lasthost);
   printf("<tr><td class=post align=right>�����ʼ���\n");
   printf("<td class=post align=left>%s\n", email);
   printf("</table><hr>\n");

   printf("<table class=foot><th class=foot><a href=\"%s\">������ҳ</a>", 
		BBSURL);
   printf("<th class=foot><a href=\"%s/bbssec\">����������</a>", BBSCGI);
   printf("<th class=foot><a href=\"%s/bbsall\">ȫ��������</a>", BBSCGI);
   printf("<th class=foot><a href=\"%s/bbs0an\">����������</a>", BBSCGI);
   printf("<th class=foot><a href=\"%s\">%s</a></table>", SCHOOLURL, 
		SCHOOLNAME);

   printf("</center>\n");
   printf("</body>\n");
   printf("</html>");
}
