/*
    BBS2WWW -- WWW Interface for Firebird Bulletin Board System
    Copyright (C) 1996-1999 Computer Application Studio.
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/uio.h>

#include "bbs2www.h"

int main (int argc, char *argv[])
{
   char ArgOfQuery[STRLEN], BoardsFile[256], category, DirOfBoard[256], *title,
	*user, *ptr;
   int  index, fd, fd1, SectNumber, total, num = 0, all;
   struct boardheader 	*buffer;
   struct fileheader  	DirInfo;
   struct stat 		st;

   strncpy(ArgOfQuery, getenv("QUERY_STRING"), STRLEN);
   SectNumber = ArgOfQuery[0] - '0';

   printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
   printf("<html>\n");
#ifdef STYLESHEET
   printf("<link rel=stylesheet type=text/css href=\"%s\">\n", STYLESHEET);
#endif
   printf("<title>%s[%s��]�������б�</title>\n", BBSID, 
	  SectNames[SectNumber][0]);
   printf("<body>\n");
   printf("<center>\n");

   printf("<table class=title width=90%%><tr>");
   printf("<th class=title width=33%% align=left>[������ѡ��]</th>\n");
   printf("<th class=title width=33%% align=center>%s</th>\n", BBSNAME);
   printf("<th class=title width=34%% align=right>��� [%s]</th>\n", 
	   SectNames[SectNumber][0]);
   printf("</table>\n");


   printf("<hr>\n");

   printf("<table class=body>\n");
   printf("<tr><th class=body>���<th class=body>����������");
   printf("<th class=body>���<th class=body>ת��<th class=body>��������");
   printf("<th class=body>����<th class=body>������</tr>\n");
  
   sprintf(BoardsFile, "%s/.BOARDS", BBSHOME);
   fd = open(BoardsFile, O_RDONLY);
   if (fd == -1)
   {
      printf("Error in opening file %s", BoardsFile);
      exit(1);  
   }
   fstat( fd, &st );
   total = st.st_size / sizeof(struct boardheader);
   buffer = (struct boardheader *)calloc(total, sizeof(struct boardheader));
   if (buffer == NULL)
   {
      printf("Out of memory");
      exit(1);
   }
   if (read(fd, buffer, st.st_size) < st.st_size)
   {
      printf("Error reading file %s", BoardsFile);
      exit(1);
   }
   close(fd);

   for (index = 0; index < total; index++)
   {
      category = buffer[index].title[0];
      if (strchr(CateInSect[SectNumber], category) == NULL)
	 continue;
      if(buffer[index].level > 0) 
         continue;
      sprintf(DirOfBoard, "%s/boards/", BBSHOME);
      strcat(DirOfBoard, buffer[index].filename);
      strcat(DirOfBoard, "/.DIR");
      fd1= open(DirOfBoard, O_RDONLY);
      if (fd1 == -1)
         continue;
      fstat( fd1, &st );
      all = st.st_size / sizeof( DirInfo );
      close(fd1);
      num++;
      printf("<tr><td class=body%d>", (num - 1) % 2 + 1);
      printf("%d<td class=body%d><a href=\"%s/bbsdoc?%s\">%s</a>", 
      		num, (num - 1) % 2 + 1, BBSCGI, buffer[index].filename, buffer[index].filename);
      title = buffer[index].title + 1;
      title[6] = '\0';
      printf("<td class=body%d>%s", (num - 1) % 2 + 1, title);
      title += 7;
      title[2] = '\0';
      printf("<td class=body%d align=center>%s", (num - 1) % 2 + 1, title);
#ifdef FB25
      title += 5;
#else
      title += 3;
#endif
      printf("<td class=body%d><a href=\"%s/bbsdoc?%s\">%s</a>", 
		(num - 1) % 2 + 1, BBSCGI, buffer[index].filename, title);
      printf("<td class=body%d>", (num - 1) % 2 + 1);
      user = buffer[index].BM;
      while (ptr = strchr(user, ' '))
      {
         *ptr = '\0';
         printf("<a href=\"%s/bbsqry?%s\">%s</a> ", BBSCGI, user, user);
         user = ptr + 1;
      }
      if (user[0])
         printf("<a href=\"%s/bbsqry?%s\">%s</a>", BBSCGI, user, user);
      else
         printf(" ");
      printf("<td class=body%d align=right>%d\n", (num - 1) % 2 + 1, all);
   }
   free(buffer);
   printf("</table>\n");

   printf("<hr>");

   printf("<table class=foot><th class=foot><a href=\"%s\">������ҳ</a>", 
		BBSURL);
   printf("<th class=foot><a href=\"%s/bbssec\">����������</a>", BBSCGI);
   printf("<th class=foot><a href=\"%s/bbsall\">ȫ��������</a>", BBSCGI);
   printf("<th class=foot><a href=\"%s/bbs0an\">����������</a>", BBSCGI);
   printf("<th class=foot><a href=\"%s\">%s</a></table>", SCHOOLURL, 
		SCHOOLNAME);

   printf("</center>\n");
   printf("</body>\n");
   printf("</html>");
}
