/*
    BBS2WWW -- WWW Interface for Firebird Bulletin Board System
    Copyright (C) 1996-1999 Computer Application Studio.
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/uio.h>

#include "bbs2www.h"

#define ANONY_FLAG      0x8

int main (int argc, char *argv[])
{
   FILE *fp;
   char ch, ArgOfQuery[STRLEN], LineBuf[256], Board[20], *quser, *ptr, buf[256],
	FileName[20], DirOfBoard[256];
   int  fd, index = 0, number = 0, total, num = 0, newfile = 1, noname, found;
   struct boardheader  brdhdr;
   struct fileheader  DirInfo;
   struct stat st;

  
   printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
   printf("<html>\n");
#ifdef STYLESHEET
   printf("<link rel=stylesheet type=text/css href=\"%s\">\n", STYLESHEET);
#endif
   printf("<title>%s��������</title>\n", BBSID);
   printf("<body>\n");
   printf("<center>\n");

   strncpy(ArgOfQuery, getenv("QUERY_STRING"), STRLEN);
   if (strstr(ArgOfQuery, "..") != NULL)
   {
      printf("Error in handling file\n");
      exit(1);
   }
   
   if(ptr = strchr(ArgOfQuery, '='))
   {
      newfile = 0;
      number = atoi(ptr + 1);
      ptr[0] = '\0';
      if (ptr = strchr(ArgOfQuery, '/'))
      {
         strcpy(FileName, ptr + 1);
         ptr[0] = '\0';
      }
   }
   strcpy(Board, ArgOfQuery);   

   printf("<form method=post action=\"%s/bbssnd\">\n", BBSCGI);

   printf("<table class=title width=90%%><tr>");
   printf("<th class=title width=33%% align=left>��������</th>\n");
   printf("<th class=title width=33%% align=center>%s</th>\n", BBSNAME);
   printf("<th class=title width=34%% align=right>������ [%s]</th>\n",
           Board);
   printf("</table>\n");

   printf("<hr>\n");

   found = 0;
   sprintf(DirOfBoard, "%s/.BOARDS", BBSHOME);
   if((fd = open(DirOfBoard, O_RDONLY, 0)) == -1)
   {
      printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
      printf( ":err: unable to open .BOARDS file.\n" );
      exit(1);
   }
   while (read(fd, &brdhdr, sizeof(brdhdr)) == sizeof(brdhdr))
      if (strcasecmp(brdhdr.filename, Board) == 0)
      {
         found = 1;
         break;
      }
   close(fd);
   if (!found)
   {
      printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
      printf( "�Ҳ��������� %s!\n", Board);
      exit(1);
   }

#ifdef FB25
   noname = 0;
   sprintf(DirOfBoard, "%s/etc/anonymous", BBSHOME);
   if (fp = fopen(DirOfBoard, "r"))
   {
       while (fgets(buf, STRLEN, fp))
          if (strncmp(buf, Board, strlen(Board)) == 0)
          {
             noname = 1;
             break;
          }
       fclose(fp);
   }
#else
   noname = brdhdr.flag & ANONY_FLAG;
#endif

   printf("<input type=hidden name=board value=%s>\n", Board);
   printf("<table class=post>\n");
   printf("<tr><td class=post>ʹ�ñ��� <input type=text name=title size=40 maxlength=100 ");
   printf("value=\"");
   if(!newfile)
   {
      sprintf(DirOfBoard, "%s/boards/", BBSHOME);
      strcat(DirOfBoard, Board);
      strcat(DirOfBoard, "/.DIR");
      fd = open(DirOfBoard, O_RDONLY);
      if (fd == -1)
      {
         printf("Error in handling file %s!\n", DirOfBoard);
         exit(1);
      }
      while ( sizeof(DirInfo) == read(fd, &DirInfo, sizeof(DirInfo)))
      {
         if(strcmp(DirInfo.filename, FileName) == 0)
         {
            if(strncmp(DirInfo.title, "Re: ", sizeof(char) * 4) != 0)
            printf("Re: ");
            printf("%s", DirInfo.title);
            break;
         }
      }
      close(fd);
   }

   printf("\"> ");
   if (noname)
   {
      printf("<input type=radio name=anonymous value=Y checked>���� ");
      printf("<input type=radio name=anonymous value=N>������");
      printf("<input type=hidden name=exchange value=N>");
   }
   else
   {
      printf("<input type=hidden name=anonymous value=N>");
      printf("<input type=radio name=exchange value=Y checked>ת�� ");
      printf("<input type=radio name=exchange value=N>վ���ż�");
   }

   printf("<tr><td class=post>���Ĵ��� <input type=text name=username size=%d ",		 IDLEN);
   printf("maxlength=%d>", IDLEN);
   printf(" �������� ");
   printf("<input type=password name=passwd size=14 maxlength=%d>", PASSLEN);
   printf("  ʹ��ǩ���� ");
   printf("<input type=radio name=signature value=1");
   if (noname)
      printf(">1");
   else
      printf(" checked>1");
   printf("<input type=radio name=signature value=2>2");
   printf("<input type=radio name=signature value=3>3");
   printf("<input type=radio name=signature value=0"); 
   if (noname) 
      printf(" checked>0"); 
   else 
      printf(">0");
   
   printf("<tr><td class=post>");
   printf("<textarea name=text rows=25 cols=80 wrap=physicle>\n");

   if (!newfile)
   {
      sprintf(LineBuf, "%s/boards/%s/%s", BBSHOME, Board, FileName);

      fp = fopen(LineBuf, "r");
      if (fp == NULL)
      {
         printf("Error in handling file\n");
         exit(1);
      }

      fgets( buf, 256, fp );
      if( (ptr = strrchr( buf, ')' )) != NULL ) {
         ptr[1] = '\0';
         if( (ptr = strchr( buf, ':' )) != NULL ) {
            quser = ptr + 1;
            while( *quser == ' ' )  quser++;
         }
      }
      printf("�� �� %s �Ĵ������ᵽ: ��\n", quser);
      while( fgets( buf, 256, fp ) != NULL )
         if( buf[0] == '\n' )  break;
      while( fgets( buf, 256, fp ) != NULL )
      {
         if( strcmp( buf, "--\n" ) == 0 )
            break;
         printf(": ");
         index = 0;
         while(index < 256 && buf[index] != '\0')
         {
            if(buf[index] != 27)
               putchar(buf[index]);
            else
               while(buf[index] != 'm' && index < 256)
                  index++;
            index++;
         }
      }
   }
   printf("</textarea>\n");
   printf("<tr><td class=post align=center>");
   printf("<input type=submit value=\"����\">");
   printf(" <input type=reset value=\"���\">\n</table>\n");

   printf("<hr>\n");
   printf("<table class=foot>");
   printf("<th class=foot><a href=\"%s\">������ҳ</a>", BBSURL);
   printf("<th class=foot><a href=\"%s/bbssec\">����������</a>", BBSCGI);
   printf("<th class=foot><a href=\"%s/bbsall\">ȫ��������</a>", BBSCGI);
   if (newfile)
      printf("<th class=foot><a href=\"%s/bbsdoc?%s\">��������</a></table>",
		BBSCGI, Board);
   else
   {
      printf("<th class=foot>");
      printf("<a href=\"%s/bbsdoc?%s=S&Q=%d\">��������</a></table>", 
		BBSCGI, Board, number);
   }
   printf("</center>\n"); 
   printf("</form>\n");
   printf("</body>\n");
   printf("</html>");
}
