/*
    BBS2WWW -- WWW Interface for Firebird Bulletin Board System
    Copyright (C) 1996-1999 Computer Application Studio.
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/uio.h>

#include "bbs2www.h"

int main ()
{
   int index;

   printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
   printf("<html>\n");
#ifdef STYLESHEET
   printf("<link rel=stylesheet type=text/css href=\"%s\">\n", STYLESHEET);
#endif
   printf("<title>%s����������</title>\n", BBSID);
   printf("<body>\n");
   printf("<center>\n");

   printf("<table class=title width=90%%><tr>");
   printf("<th class=title width=33%% align=left>[����������ѡ��]</th>\n");
   printf("<th class=title width=33%% align=center>%s</th>\n", BBSNAME); 
   printf("<th class=title width=34%% align=right>���� [%s]</th>\n", BBSHOST);
   printf("</table>\n");

   printf("<hr>\n");

   printf("<table class=body>\n");
   printf("<tr><th class=body>���<th class=body>���<th class=body>����\n");
   for (index = 0; index < SectNum; index++)
   {
      printf("<tr><td class=body%d>%d<td class=body%d><a href=\"%s/bbsboa?%d\">", 
		index % 2 + 1, index + 1, index % 2 + 1, BBSCGI, index);
      printf("%s</a>", SectNames[index][0]);
      printf("<td class=body%d><a href=\"%s/bbsboa?%d\">%s</a>\n", 
		index % 2 + 1, BBSCGI, index, SectNames[index][1]);
   }
   printf("</table>\n");

   printf("<hr>\n");

   printf("<table class=foot><th class=foot><a href=\"%s\">������ҳ</a>", 
		BBSURL);
   printf("<th class=foot><a href=\"%s/bbsall\">ȫ��������</a>", BBSCGI);
   printf("<th class=foot><a href=\"%s/bbs0an\">����������</a>", BBSCGI);
   printf("<th class=foot><a href=\"%s\">%s</a></table>\n", SCHOOLURL, 
		SCHOOLNAME);
   printf("</center>\n");
   printf("</body>\n");
   printf("</html>");
}
