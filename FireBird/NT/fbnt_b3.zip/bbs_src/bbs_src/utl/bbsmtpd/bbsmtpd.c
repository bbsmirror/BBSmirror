/* bbsmtpd for FB, by tim.bbs@bbs.nju.edu.cn, NJU Lily BBS, Oct 2000 */

#include <unistd.h>
#include <sys/ioctl.h>

#include <sys/wait.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <netdb.h>

#include <sys/time.h>
#include <sys/stat.h>

#define BBS_HOME "/home/bbs"

#include BBS_HOME"/bbs_src/include/bbs.h"
#include "util.h"

//Ҳ���Ժ����ʹ��BBSHOST����BBSMAIL����

#define BUF_SIZE         1024

#define SMTP_PORT 25
#define SMTP_TIMEOUT         60
#define MAX_RCPT 10

#define MAX_RETRY	'Z'	//Ѱ����ʱ�ļ��ļ�������ʱ������Դ���
#define MAX_DATA_LEN	500	//ÿ���ż�������󳤶�
#define TEMP_DIR "tmp"	//��ʱ�ļ����Ŀ¼
#define LOG_FILE	"reclog/smtpd.log"	//��־�ļ�
#define FREE_IP_LIST MY_BBS_HOME"/etc/free.txt"	//���IP�б�

struct fileheader currentmail;
struct userec currentuser;

int sender_set, rcpter_set, tmpfile_set;
char recipients[MAX_RCPT][IDLEN];
int rcpt_count;
char sender[BUF_SIZE];
char tempfilename[BUF_SIZE];
char genbuf[BUF_SIZE];

#define QLEN            5

#define S_CONNECTED	1
#define S_WELCOMED	2
#define S_ADDR_GOT	3
#define S_DATA_GOT	4

#define snprintf _snprintf;

static jmp_buf timebuf;

int     state;
int     msock,sock;    /* master server socket */
static void reaper();
char    fromhost[ STRLEN ];
char    inbuf[ BUF_SIZE ];
char    remote_userid[ STRLEN ];
FILE    *cfp, *logfp;
char    *msg,*cmd;
int     fd;
struct  fileheader *fcache;
int     idletime;
int     *postlen;
int		maxlen;

void    log_usies();
/* Minimum commands set, see RFC 821 */
int     Quit(), Mail(), Rcpt(), Noop(), Helo(), Data(), Rset();

struct commandlist {
    char        *name;
    int         (*fptr)();
} cmdlists[] = {
        "quit",	Quit,
        "mail",	Mail,
        "rcpt",	Rcpt,
        "noop",	Noop,
        "helo",	Helo,
        "data",	Data,
        "rset",	Rset,
        NULL,         NULL
};

static unsigned int free_addr[2000], free_mask[2000], free_num;

int get_free_list() {
  FILE *fp;
  char buf1[100], buf2[100];
  free_num= 0;
  fp=fopen(FREE_IP_LIST, "r");
  if (fp== NULL) 
    return 0;
  
  while(fscanf(fp, "%s%s", buf1, buf2)>0) {
    free_addr[free_num]= inet_addr(buf1);
    free_mask[free_num]= inet_addr(buf2);
    free_num++;
  }
  fclose(fp);
  return 1;
}

int is_free(unsigned int x) {
  int n;
  for (n= 0; n< free_num; n++)
    if(((x^ free_addr[n])| free_mask[n])==free_mask[n]) return 1;
  return 0;
}

static int
abort_server()
{
    log_usies("ABORT SERVER");
    close(msock);
    close(sock);
    exit(1);
}

void dokill()
{
   kill(0,SIGKILL);
}

static FILE *fsocket(int domain, int type, int protocol)
{
    int     s;
    FILE   *fp;
        
    if ((s = socket(domain, type, protocol)) < 0) {
      return (0);
    } else {
      if ((fp = fdopen(s, "r+")) == 0) {
        close(s);
      }
      return (fp);
    }
}

void smtp_reply(int code, char *msg)
{
	char sendbuf[255];
	(void)bzero(sendbuf, sizeof(sendbuf));
	(void)snprintf(sendbuf,sizeof(sendbuf), "%d %s\r\n", code, msg);
	(void)write(sock, sendbuf, strlen(sendbuf));
}

/* timeout - handle timeouts */
static void timeout(int sig)
{
    longjmp(timebuf, sig);
}

char *nextwordlower(char **str)
{
    char *p;

    if (**str==':')
    	(*str)++;
    while (isspace(**str))
      (*str)++;
    p = (*str);

    while (**str && !isspace(**str) && (**str!=':')) {
      **str = tolower(**str);
      (*str)++;
    }

    if (**str) {
      **str = '\0';
      (*str)++;
    }
    return p;
}

void
Init()
{
	state = S_CONNECTED;
	sender_set = 0;
	rcpter_set = 0;
	tmpfile_set = 0;
	idletime = 0;
	rcpt_count = 0;
	maxlen = MAX_DATA_LEN;
	logfp = fopen(LOG_FILE, "w");
}
 
void
smtp_timeout()
{
    idletime++;
    if (idletime > 5) {
      log_usies("ABORT - TIMEOUT");
      fclose(cfp);
      if (logfp)
      	fclose(logfp);
      close(sock);
      exit(1);
    }
    alarm(SMTP_TIMEOUT);
}


main(int argc, char **argv)
{

        struct sockaddr_in fsin,our;
        int on,alen,len,i, n;
        char *str, flag;
        int portnum = SMTP_PORT;
        int childpid;

        if (2 == argc) portnum = atoi(argv[1]);
        if (0 == portnum) portnum = SMTP_PORT;

        if (get_free_list() == 0)
        	printf("Fatal error: file free.txt not found!\n");
        	
//        if(fork()) 
//          exit(0);
        printf("Starting..pid=%d\n", getpid());
        for (n = 0; n<10; n++)
          close(n);
//        open("/dev/null", O_RDONLY);
        dup2(0,1);
        dup2(0,2);
//        if((n=open("/dev/tty",O_RDWR)) > 0) {
//         ioctl(n, TIOCNOTTY, 0) ; 
//          close(n);
//        }
        
        if ((msock = socket(AF_INET,SOCK_STREAM,0)) < 0) {
          exit(1);
        }
        setsockopt(msock,SOL_SOCKET,SO_REUSEADDR, (char *) &on, sizeof(on));
        bzero((char *)&fsin,sizeof(fsin));
        fsin.sin_family = AF_INET;
        fsin.sin_addr.s_addr = htonl(INADDR_ANY);
        fsin.sin_port = htons(portnum);
                                                        
        if (bind(msock,(struct sockaddr *)&fsin,sizeof(fsin))<0) {
          exit(1);
        }

        signal(SIGHUP, (void *)abort_server) ;
        signal(SIGCHLD, reaper);
        signal(SIGINT,dokill);
        signal(SIGTERM,dokill);

        listen(msock,QLEN);
        sleep(1); 
        while (1) {

          alen=sizeof(fsin);
          sock = accept(msock,(struct sockaddr *)&fsin,&alen);
          if (sock < 0) {
            if (errno != EINTR) 
            continue;
          }

          if ((childpid = fork()) < 0) {
            exit(1);
          }  

          switch (childpid) {
          case 0:  /* child process */
            close(msock);

            setgid(BBSGID);
            setuid(BBSUID);
			chdir(MY_BBS_HOME);
			
            strcpy(fromhost, (char *)inet_ntoa(fsin.sin_addr));
            len = sizeof our;
            getsockname(sock, (struct sockaddr *) &our,&len);

            Init();
            cfp = fdopen(sock, "r+");
            setbuf(cfp, (char *) 0);
 
            sprintf(genbuf, "Firebird NT BBS SMTP server (NJU Lily) at %s ready.", MY_BBS_DOMAIN);
            smtp_reply(220, genbuf);

            log_usies(fromhost);
            log_usies("CONNECT");
            alarm(0);
            signal(SIGALRM, smtp_timeout);
            alarm(SMTP_TIMEOUT);
            
            while (fgets(inbuf, sizeof(inbuf), cfp)!=0) {
            
               idletime = 0;
               msg = inbuf;
       
               inbuf[ strlen(inbuf)-1 ] = '\0';
               if (inbuf[strlen(inbuf)-1] == '\r') inbuf[strlen(inbuf)-1] = '\0';
			log_usies(inbuf);
               cmd = nextwordlower(&msg);

               if (*cmd==0) continue;
               
               i = 0;
               while ( (str = cmdlists[i].name) != NULL ) {
                 if ( strcmp( cmd, str ) == 0 ) break;
                 i++;
               }

               if (str==NULL)
               {
                  sprintf(genbuf, "Unknown command: \"%s\".", cmd);
                  smtp_reply(500, genbuf);
               }
               else (*cmdlists[i].fptr)();

            }

            if (state == S_WELCOMED) {
              free(fcache);
              free(postlen);
            }
            log_usies("ABORT");
            fclose(cfp);
            close(sock);
            exit(0);
            break;
          default:   /* parent process */
            close(sock);
            break;
          }        
        }
}

static void
reaper()
{
     int state, pid;
     
     signal(SIGCHLD,SIG_IGN);
     signal(SIGINT,dokill);
     signal(SIGTERM,dokill);

     while (( pid = waitpid(-1, &state, WNOHANG|WUNTRACED)) > 0);
}

int
get_userdata(char *user, int *pLevel, int *pVolume) //�û���Ȩ�޺Ϳ�������
{
        FILE *rec, *tempfile;
        int found=0, max_size, cur_size;
        char buf[BUF_SIZE], command[BUF_SIZE], mailpath[BUF_SIZE];

        sprintf(buf, "%s/.PASSWDS", MY_BBS_HOME);
        if((rec=fopen(buf,"rb"))==NULL)
                return 0;
        while(1)
        {
                if(fread(&currentuser,sizeof(currentuser),1,rec)<=0) break;
                if(currentuser.numlogins<=0)
                        continue;
                if(strcasecmp(user,currentuser.userid))
                        continue;
                else
                {
                        found=1;
                        strcpy(user,currentuser.userid);
                        *pLevel = currentuser.userlevel;
						cur_size=0;
			/*			max_size= ( HAS_PERM(PERM_LARGEMAIL)) ?
        		MAX_SYSOPMAIL_HOLD : ( HAS_PERM(PERM_BOARDS) ) ?
				MAX_BMMAIL_HOLD : MAX_MAIL_HOLD;*/
                        max_size = MAX_MAIL_HOLD;				        
						sprintf(mailpath,"mail/%c/%s/",
				toupper(currentuser.userid[0]),currentuser.userid);
					    sprintf(buf,"tmp/size.%s", currentuser.userid);
					    sprintf(command,"du %s > %s",mailpath,buf);
					    system(command);
					    if((tempfile=fopen(buf,"rt"))==NULL) cur_size = max_size;
					    if((fscanf(tempfile,"%d", &cur_size))==0) cur_size = max_size;
					    fclose(tempfile);
					    unlink(buf);
					    *pVolume = max_size- cur_size;
                        break;
                }
        }
        fclose(rec);
        return found;
}

/** 
	Max entry of mail header info: 
	0 : date sent
	1 : sender name
	2 : sender address
	3 : rcpt.'s name
	4 : subject
 */
#define DATE	0
#define FROMADDR	1
#define TOADDR	2
#define SUBJECT	3
#define ENCODING	4
#define CHARSET	5
#define FROMNAME	6
#define MAX_ENTRY	7
	/** Info. of current mail */
static char *szKeywords[] =
		{"Date: ", "From: ", "To: ", "Subject: ",
		 "Content-Transfer-Encoding: ", "Content-Type: "};
	
#define BASE64_KEYWORD	"BASE64"
#define QUOTED_KEYWORD	"QUOTED-PRINTABLE"

char szMailInfo[MAX_ENTRY][BUF_SIZE];
/* ����Ҫ�����ϣ�
������: Tim Bao <timbao@yahoo.com>
��  ��: ����һ�������ż�
��  Դ: from tim (tim.nju.edu.cn [202.119.37.9])
��  ��: Fri May 19 14:53:18 2000
 */
int parse_header()
{
	int i, type, iEncode;
	char process_buf[BUF_SIZE], *ptr, *pCharset;
	FILE *fpin, *fpout;
	
	for (i = 0; i< MAX_ENTRY; i++)
		strcpy(szMailInfo[i], "");
		
	fpin = fopen(tempfilename, "r");
	if (fpin == NULL){
		return 0;
	}

	while (!feof(fpin)) {
		fgets(process_buf, BUF_SIZE-1, fpin);
		trim(process_buf);

		if (strlen(process_buf) == 0)
			break;  //Delimiter of header and content encounted.
		
		type = 0;
		while ((type <= CHARSET) && 
			(strncmp(szKeywords[type], process_buf, strlen(szKeywords[type]))))
			type ++;
			
		if (type < CHARSET) {//Otherwise garbage header, not interested in.
			strcpy(szMailInfo[type], process_buf+ strlen(szKeywords[type]));
		}
		else if (type == CHARSET) {
			pCharset = strstr(process_buf, "charset=");
			if ((pCharset == NULL) && (!feof(fpin)) ){
				fgets(process_buf, BUF_SIZE-1, fpin);
				trim(process_buf);
				pCharset = strstr(process_buf, "charset=");
			}
			if (pCharset != NULL){
				strcpy(szMailInfo[CHARSET], pCharset+ 8);
			}
		}
	}

	handleAddress(szMailInfo[FROMADDR], szMailInfo[FROMNAME]);
	decodeHeaderLine(szMailInfo[SUBJECT]);

	sprintf(genbuf, "%s.out", tempfilename);
	fpout = fopen(tempfilename, "w");
	if (fpout == NULL){
		log_usies("Cannot out ");
		fclose(fpin);
		return 0;
	}
	
	fprintf(fpout, "������: %s <%s>\n", szMailInfo[FROMNAME], szMailInfo[FROMADDR]);
	fprintf(fpout, "��  ��: %s\n", szMailInfo[SUBJECT]);
	fprintf(fpout, "��  ��: %s\n", szMailInfo[DATE]);
	fprintf(fpout, "�ַ���: %s\n\n", szMailInfo[CHARSET]);

	if (strcasecmp(szMailInfo[ENCODING], BASE64_KEYWORD)==0)
		iEncode = 1;
	else if (strcasecmp(szMailInfo[ENCODING], QUOTED_KEYWORD)==0)
		iEncode = 2;
	else
		iEncode = 3;
		
	while (!feof(fpin)) {
		fgets(process_buf, BUF_SIZE-1, fpin);
		trim(process_buf);
		switch (iEncode) {
		case 1:	
			fputs(decodeBase64(process_buf), fpout);
			break;
		case 2:	
			fputs(decodeQuoted(process_buf), fpout);
			break;
		case 3:	 
			fputs(process_buf, fpout);
			fputs(POP3_NEWLINE, fpout);
		}
	}
	fclose(fpin);
	fclose(fpout);	
	sprintf(genbuf, "mv %s.out %s", tempfilename, tempfilename);
	system(genbuf);
}

//��Quit()���ã��˳�ʱ��recipients��tempfilename�����ݽ���Ͷ��
int deliver() 
{
	int n = 0, ok = 0, succ = 1;
	int fd, cc, sz;
	char *bp;
	char try = 'A';
	char dest_file[BUF_SIZE];
	time_t now;
	struct stat st;
	struct fileheader newmail;

	memset(&newmail, 0, sizeof(newmail));
	now =  time(0);
	
	while (n < rcpt_count) {
		while (try < MAX_RETRY) {
			sprintf(dest_file, "mail/%c/%s/M.%d.%c", toupper(recipients[n][0]),
				recipients[n], now, try++);
			if (stat(dest_file, &st) != 0) //Ѱ���ļ���
				break;
		}
		
		if (try >= MAX_RETRY) {
			sprintf(genbuf, "Delivering failed: %s, temp file=%s, dest file=%s\n", 
				recipients[n], tempfilename, dest_file);
			log_usies(genbuf);
			succ = 0;
			continue; 
		}

		sprintf(genbuf, "cp %s %s", tempfilename, dest_file);
		system(genbuf);
		sprintf(genbuf, "mail/%c/%s/"DOT_DIR, toupper(recipients[n][0]),
				recipients[n]);
        strncpy(newmail.owner, sender, STRLEN);
        strncpy(newmail.title, szMailInfo[SUBJECT], STRLEN);
        strncpy(newmail.filename, strrchr(dest_file, '/')+1, STRLEN);

		if ((fd = open(genbuf, O_WRONLY | O_CREAT, 0644)) == -1) {
		        succ = 0;
		        continue;
		}
		flock(fd, LOCK_EX);
		lseek(fd, 0, SEEK_END);
		bp = (char*)(&newmail);
		sz = sizeof(newmail);
		do {
			cc = write(fd, bp, sz);
			if ((cc < 0) && (errno != EINTR)) {
				succ = 0;
				break;
			}
			if (cc > 0) {
				bp += cc;
				sz -= cc;
			}
		} while (sz > 0);
		flock(fd, LOCK_UN);
		close(fd);
		n++;
	}
	return succ;
}

int
Noop()
{
    smtp_reply(250, "NOOP ok.");
    return 1;
}

int
Rset()
{
 	maxlen = MAX_DATA_LEN;
	sender_set = 0; 
	rcpter_set = 0;	
	rcpt_count = 0;
	if (tmpfile_set == 1)
		unlink(tempfilename);
	state = S_CONNECTED;	
	smtp_reply(250, "All buffers cleared.");
	return 1;
}

int
Quit()
{
	if ((state == S_DATA_GOT)&&(tmpfile_set == 1)) {
		parse_header();
		if (deliver())	
			unlink(tempfilename);
	}
	log_usies("EXIT");
	sprintf(genbuf, "Lily BBS SMTP server at %s signing off.", MY_BBS_DOMAIN);
	smtp_reply(221, genbuf);
	fclose(cfp);
	if (logfp)
		fclose(logfp);
	close(sock);
	exit(0);
}

int 
Helo()
{
	state = S_WELCOMED;
	smtp_reply(250, "Hello, glad to meet you.");
	return 1;
}

int 
Mail()
{
	if (state < S_WELCOMED){
		smtp_reply(503, "Unexpected command or sequence of commands.");
		return 0;
	}
	
	cmd = nextwordlower(&msg);
	if (strcmp(cmd, "from") != 0){
		smtp_reply(501, "Syntax error in parameters or arguments.");
		return 0;
	}

	cmd = nextwordlower(&msg);
	if (cmd == NULL){
		smtp_reply(501, "Syntax error in parameters or arguments.");
		return 0;
	}
	
	strcpy(sender, cmd);
	sender_set = 1;
	if ((sender_set == 1) && (rcpter_set == 1))
		state = S_ADDR_GOT;
	sprintf(genbuf, "Sender %s ok.", cmd);
	smtp_reply(250, genbuf);
	return 1;
}

int 
Rcpt()
{
	char temp[BUF_SIZE], *ptr;
	int level, vol;
	
	if (state < S_WELCOMED){
		smtp_reply(503, "Unexpected command or sequence of commands.");
		return 0;
	}
	
	cmd = nextwordlower(&msg);
	if (strcmp(cmd, "to") != 0){
		smtp_reply(501, "Syntax error in parameters or arguments.");
		return 0;
	}

	cmd = nextwordlower(&msg);
	if (cmd == NULL){
		smtp_reply(501, "Syntax error in parameters or arguments.");
		return 0;
	}
	
	/* ɾ��<tim@bbs.nju.edu.cn>�����˵ļ����� */	
	if (*cmd == '<') 
		cmd++;
	if (cmd[strlen(cmd)-1]== '>')
		cmd[strlen(cmd)-1] = '\0';
	
	strcpy(temp, cmd);
	ptr = strchr(temp, '@'); 
	/* userid@domain.com��ʽ����@֮�������BBSDOMAIN */
	if (ptr != NULL)
		if (strcmp((ptr+1), MY_BBS_DOMAIN)) {
		sprintf(genbuf, "Address %s not local, we don't relay.", cmd);
		smtp_reply(551, genbuf);
		return 0;
	}
	else
		*ptr = '\0';
	/* ʣ�µĲ�����userid.bbs����userid�� */
	ptr = strchr(temp, '.');
	if (ptr!=NULL)
		*ptr = '\0';
	
	if ((strlen(temp)> IDLEN) || (get_userdata(temp, &level, &vol)==0)) {
		sprintf(genbuf, "Unknown user %s.", cmd);		
		smtp_reply(550, genbuf);
		return 0;
	}
	
	if ((!is_free(inet_addr(fromhost)))&&(!HAS_PERM( PERM_SYSOP))) {
		sprintf(genbuf, "User %s don't have permission to receive your mail.", cmd);		
		smtp_reply(550, genbuf);
		return 0;
	}
	
	maxlen = (maxlen > vol)? vol: maxlen; //���н����߿��Խ��յ��ʼ���С�ĳߴ�
	if (maxlen < 0 ) {
		sprintf(genbuf, "Mailbox %s is full.", cmd);		
		smtp_reply(552, genbuf);
  		return 0;
  	}
  	
  	strcpy(recipients[rcpt_count++], temp);
	rcpter_set = 1;
	if ((sender_set == 1) && (rcpter_set == 1))
		state = S_ADDR_GOT;
	sprintf(genbuf, "Recipient %s, %d Kbytes free, vol =%d K, ok.", temp, maxlen, vol);
	smtp_reply(250, genbuf);
	return 1;
}

int 
Data()
{
    time_t      now;
    char try = 'A';
    int len = 0, len_read;
    FILE *tmp_fp;
    struct stat st;
    char *to_put;
    
	if (state < S_ADDR_GOT ) {
		smtp_reply(503, "Address not specified.");
		return 0;
	}
	
	tmpfile_set = 1;
	now=time(0);
	sprintf(tempfilename, "%s/%d.A", TEMP_DIR, now);
	while (try < MAX_RETRY) 
		if (stat(tempfilename, &st) == 0) //Ѱ���ļ���
			sprintf(tempfilename, "%s/%d.%c", TEMP_DIR, now, ++try);
		else
			break;
	if (try >= MAX_RETRY) {
		smtp_reply(552, "Cannot allocate temporory space.");
		return 0;
	}
	
	smtp_reply(354, "Use <cr>.<cr> to end your data.");
	tmp_fp = fopen(tempfilename, "wt");
	if (tmp_fp == NULL) {
		smtp_reply(552, "Cannot allocate temporory space.");
		return 0;
	}
	
	while ((len/1024) < maxlen) {  
		fgets(inbuf, sizeof(inbuf), cfp);
		len_read = strlen(inbuf);
		len += len_read;
		if (inbuf[0] != '.')
			to_put = inbuf;
		else if (inbuf[1] == '.')
			to_put = inbuf+1;
		else
		{ 
			char *ptr = inbuf+1;
			while ((*ptr=='\x0d')|| (*ptr=='\x0a'))
				ptr++;
			if (*ptr == '\0')
				break;
			else
				to_put = inbuf;
		}
		
		if ((len/1024) < maxlen)
			fputs(to_put, tmp_fp);

	}
	fclose(tmp_fp);
	if ((len/1024) >= maxlen) {
		sprintf(genbuf, "Mail body is too large. %d recved, %d allowed.", len, maxlen);
		smtp_reply(552, genbuf);
		return 0;
	}
	
	state = S_DATA_GOT;
	smtp_reply(250, "Data ok.");
	return 1;
}

void    log_usies(msg)
char *msg;
{
	if (logfp)
		fputs(msg, logfp);
}

	
