#include "util.h"

char *trim(char *szInput)
{
	char *s, *e;
	char genbuf[BUF_SIZE];
	
	s = szInput;
	while (isspace(*s)&&(*s)) 
		s++;
		
	e = &szInput[strlen(szInput)-1];
	while (isspace(*e)&&(*e)) {
		*e='\0';
		e--;
	}
	strcpy(genbuf, s);
	strcpy(szInput, genbuf);
	return szInput;
}

/**
 * Split name and email addr in FROM and TO field.
 * Example: 
 *	case 1: Alfred Neuman <Neuman@BBN-TENEXA>
 *		name: Alfred Neuman
 *		addr: Neuman@BBN-TENEXA
 *	case 2: Neuman@BBN-TENEXA
 *		name: (unknown)
 *		addr: Neuman@BBN-TENEXA
 *	case 3: "George, Ted" <Shared@Group.Arpanet>
 *		name: George, Ted
 *		addr: Shared@Group.Arpanet
 *	case 4: Wilt.Chamberlain@NBA.US (the  Stilt)
 *		name: the  Stilt
 *		addr: Wilt.Chamberlain@NBA.US
 *	case 5: <Neuman@BBN-TENEXA>
 *		name: (unknown)
 *		addr: Neuman@BBN-TENEXA
 * @param szNameAndAddr	the combination of name and address
 * @return String[]
 * 	The 1st element is the address, and the second, the sender's name.
 *	Moreover, the sender's name has been decoded.
 */
void handleAddress(char *szNameAndAddr, char *szName)
{
	char process_buf[BUF_SIZE];
	char  *s, *e;
	
	strcpy(process_buf, szNameAndAddr);
	s = strchr(process_buf, '<');
	e = strchr(process_buf, '>');
	
	if ((s==NULL) && (e==NULL)) //case 2, 4
	{
		s = strchr(process_buf, '(');
		e = strchr(process_buf, ')');
		if ((s!=NULL) && (e!=NULL)) //case 4
		{
			*s = '\0'; s++;
			*e = '\0';
			decodeHeaderLine(s);
			strcpy(szName , s);
			strcpy(szNameAndAddr, process_buf);
			return;
		}
		else {
			*szName = '\0';
			return;
		}
	}
	else if ((s!=NULL) && (e!=NULL)) //case 1,3
	{
		*s = '\0'; s++;
		*e = '\0';
		decodeHeaderLine(process_buf);
		strcpy(szName, process_buf);
		strcpy(szNameAndAddr, s);
		return;
	}
	else {
		*szName = '\0';
		return;
	}
}

char* decodeHeaderLine(char *szEntry) {
	/* According to RFC1342, an encoded header must  
	 * begins with "=?", ends with "?=". So if the string doesn't
	 * satisfy this requirement, return directly.
	 * Otherwise, try to scan the 2nd '?' and the 3rd '?' in the 
	 * string. There should exactly be 2 '?' left beside the first
	 * and the last one. If not, invalid, either. Return directly.
	 */
	char *second = NULL, *third = NULL; 
	int i;
	char process_buf[BUF_SIZE];

	strcpy(process_buf, szEntry);
	if ((strncmp("=?", process_buf, 2)) || 
		(strncmp(process_buf+ strlen(process_buf)- 2, "?=", 2))||
		(strlen(process_buf)< 9))
		return szEntry; //invalid format, should be "=?x?B?t?="

	for (i = 2; i < strlen(process_buf)-2; i++)
	{
		if (process_buf[i] == '?')
			if (second == NULL)
				second = &process_buf[i];
			else
				third = &process_buf[i];
	}
	if ((second == NULL) || (third == NULL) || (second == third))
		return szEntry;

	process_buf[strlen(process_buf)- 2] = '\0';
	second++; third++;
	
	if (*second == 'B'){
		strcpy(szEntry, decodeBase64(third));
	}
	else if (*second == 'Q'){
		strcpy(szEntry, decodeQuoted(third));
	}
	
	return szEntry;
}

char pop3Base64Code(char c)
{

	if ( c >= 'A' && c <= 'Z' )	//A-Z
		return (c - 'A');
	if ( c >= 'a' && c <= 'z' )	//a-z
		return (char)(c- 'a'+ 26);
	if ( c >= '0' && c <= '9' )	//0-9
		return (char)(c- '0'+ 52);
	if ( c == '+' )			// +
		return (char)62 ;
	if ( c == '/' )			// /
		return (char)63 ;

	return (char)64 ;	
}

char *decodeBase64(char *szInput)
{
	int len = 0 ;
	int tlen ;
	int i ;
	unsigned char tmpbuf[BUF_SIZE], obuf[BUF_SIZE];

	strcpy(tmpbuf, szInput);
	tlen = strlen(tmpbuf);
/*	if ( strcmp((char *)tmpbuf+tlen-2, POP3_NEWLINE) == 0 ) {
		tmpbuf[tlen-2] = '\0' ;
	}
 */	
	for ( i = 0 ; i < tlen ; i++ ) {		
		tmpbuf[i] = pop3Base64Code(tmpbuf[i]);
	}
											
	for ( i = 0 ; i < tlen ; i += 4 ) {
		obuf[len++] = (tmpbuf[i]<<2) | ((tmpbuf[i+1]&0x30)>>4) ;
		if ( tmpbuf[i+2] == 64 )
			break ;
		obuf[len++] = (tmpbuf[i+1]<<4) | ((tmpbuf[i+2]&0x3c)>>2) ;
		if ( tmpbuf[i+3] == 64 )
			break ;
		obuf[len++] = (tmpbuf[i+2]<<6) | (tmpbuf[i+3]&0x3f) ;
	}
	obuf[len] = '\0' ;
	strcpy(szInput, obuf);
	return szInput;
}

int pop3_htoi(char *hex)
{
	int num = 0 ;

	for ( ; *hex != '\0' ; hex ++ ) {
		num *= 0x10 ;
		if ( *hex >= '0' && *hex <= '9' )
			num += (*hex) - '0' ;
		else if ( *hex >= 'A' && *hex <= 'F' )
			num += (*hex) - 'A' + 0x0a ;
		else if ( *hex >= 'a' && *hex <= 'f' )
			num += (*hex) - 'a' + 0x0a ;
		else
			break ;
	}
	return num ;
}

char *decodeQuoted(char *szInput)
{
	unsigned char *ptr = szInput, obuf[BUF_SIZE];
	int len = 0, inbuflen;
	char num[3] ;

	num[2] = '\0' ;
	inbuflen = strlen(szInput);
/*	if ( strcmp((char *)szInput+inbuflen-2, POP3_NEWLINE) == 0 ) {
		szInput[inbuflen-2] = '\0' ;
	}
 */	
	for ( ; *ptr != '\0' ; ) {
		if ( *ptr == '=' ) {
			if ( *(ptr+1) == '\0' )
				break;

			num[0] = *(ptr+1) ;
			num[1] = *(ptr+2) ;

			obuf[len++] = (unsigned char)pop3_htoi(num) ;
			ptr += 3 ;
		}
		else 
			obuf[len++] = *(ptr++) ;
	}

	if (*ptr == '=') 
		obuf[len]= '\0';
	else {
		obuf[len++]= '\r';
		obuf[len++]= '\n';
		obuf[len] = '\0' ;
	}
	strcpy(szInput, obuf);
	return szInput ;
}