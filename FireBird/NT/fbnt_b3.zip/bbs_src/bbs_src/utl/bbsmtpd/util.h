#include <sys/time.h>
#include <sys/stat.h>
#include <string.h>

#define BUF_SIZE 1024
#define BASE64_KEYWORD	"BASE64"
#define QUOTED_KEYWORD	"QUOTED-PRINTABLE"
#define POP3_NEWLINE "\r\n"

void handleAddress(char *szNameAndAddr, char *szName);
char* decodeHeaderLine(char *szEntry);
char *decodeBase64(char *szInput);
char *decodeQuoted(char *szInput);
char *trim(char *szInput);