#ifndef FLOCK_H
#define FLOCK_H
int flock(int fd,int operation);
#endif