// �Ȯ��٨S�M�w�n�񨺭��ɮת�func

#include "bbs.h"

int direct_showfile(char *fname)
{
	char buf[250];
	FILE *fp;
	
	fp=fopen(fname,"r");
	if(fp!=NULL) {
	 fgets(buf,250,fp);
	 while(!feof(fp))
	   {   output(buf,strlen(buf));
	       fgets(buf,128,fp);
	   }
	 }  
}	                                        

int edit_delconf()
{
      char buf[255];
  
      if(!HAS_PERM(PERM_SYSOP))
                 return -1;
      setbfile(buf,currboard,".autodel");                
      vedit( buf, NA );
}

