/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

extern struct postheader header;

#include "bbs.h"
#define         INTERNET_PRIVATE_EMAIL

/*For read.c*/
int     auth_search_down();
int     auth_search_up();
int     do_cross();
int     t_search_down();
int     t_search_up();
int     post_search_down();
int     post_search_up();
int     thread_up();
int     thread_down();
int     deny_user();
int     show_author();
int     SR_first_new();
int     SR_last();
int     SR_first();
int     SR_read();
int     SR_read();
int     SR_author();
int     G_SENDMODE=NA;

extern struct friend *topfriend;
extern int nf;
extern int numofsig;
extern char quote_file[], quote_user[];
char    *sysconf_str();
char    currmaildir[ STRLEN ] ;

#define maxrecp 300

char *email_domain()
{
    char        *domain;

    domain = sysconf_str( "BBSDOMAIN" );
    if( domain == NULL )  domain = "unknown.BBSDOMAIN";
    return domain;
}

char *get_bbs_english_name()
{
    char        *name;

    name = sysconf_str( "BBSID" );
    if( name == NULL )  name = "unknown.BBSID";
    return name;
}

int
chkmail()
{
    static long lasttime = 0;
    static ismail = 0 ;
    struct fileheader fh ;
    struct stat st ;
    int fd ;
    register int i, offset ;
    register long numfiles ;
    unsigned char ch ;
    extern char currmaildir[ STRLEN ] ;

    if( !HAS_PERM( PERM_BASIC ) ) {
        return 0;
    }
    offset = (int)((char *)&(fh.accessed[0]) - (char *)&(fh)) ;
    if((fd = open(currmaildir,O_RDONLY)) < 0)
      return (ismail = 0) ;
    fstat(fd,&st) ;
    if(lasttime >= st.st_mtime) {
        close(fd) ;
        return ismail ;
    }
    lasttime = st.st_mtime ;
    numfiles = st.st_size ;
    numfiles = numfiles/sizeof(fh) ;
    if(numfiles <= 0) {
      close(fd) ;
      return (ismail = 0) ;
    }
    lseek(fd,(st.st_size-(sizeof(fh)-offset)),SEEK_SET) ;
    for(i = 0 ; i < numfiles ; i++) {
        read(fd,&ch,1) ;
        if(!(ch & FILE_READ)) {
            close(fd) ;
            return(ismail = 1) ;
        }
        lseek(fd,-sizeof(fh)-1,SEEK_CUR);
    }
    close(fd) ;
    return(ismail = 0) ;
}


int
check_query_mail(qry_mail_dir)
char qry_mail_dir[STRLEN];
{
    struct fileheader fh ;
    struct stat st ;
    int fd ;
    register int  offset ;
    register long numfiles ;
    unsigned char ch ;
   
    offset = (int)((char *)&(fh.accessed[0]) - (char *)&(fh)) ;
    if((fd = open(qry_mail_dir,O_RDONLY)) < 0)
      return 0 ;
    fstat(fd,&st) ;
    numfiles = st.st_size ;
    numfiles = numfiles/sizeof(fh) ;
    if(numfiles <= 0) {
      close(fd) ;
      return 0 ;
    }
    lseek(fd,(st.st_size-(sizeof(fh)-offset)),SEEK_SET) ;
/*    for(i = 0 ; i < numfiles ; i++) {
        read(fd,&ch,1) ;
        if(!(ch & FILE_READ)) {
            close(fd) ;
            return YEA ;
        }
        lseek(fd,-sizeof(fh)-1,SEEK_CUR);
    }*/
/*���u�d�߷s�H�u�n�d�̫߳�@�ʬO�_���s�H�A��L�ä����n*/
/*Modify by SmallPig*/
    read(fd,&ch,1) ;
    if(!(ch & FILE_READ)) {
        close(fd) ;
        return YEA ;
    }
    close(fd) ;
    return NA ;
}

int 
mailall()
{
        char    ans4[4],ans2[4],fname[STRLEN],title[STRLEN];
        char    doc[4][STRLEN],buf[STRLEN];
        int     i;

        strcpy(title,"�S�D�D");
        modify_user_mode( SMAIL );
        clear();
        move(0,0);
        sprintf(fname,"etc/%s.mailtoall",currentuser.userid);
        prints("�A�n�H���Ҧ����G\n");
        prints("(0) ���\n");
        strcpy(doc[0],"(1) �|���q�L�����T�{���ϥΪ�");
        strcpy(doc[1],"(2) �Ҧ��q�L�����T�{���ϥΪ�");
        strcpy(doc[2],"(3) �Ҧ����O�D");
        strcpy(doc[3],"(4) �|�ʦ~�ӲĤ@�����n��");
        for(i=0;i<4;i++)
                prints("%s\n",doc[i]);
        getdata(8, 0, "�п�J�Ҧ� (0~4)? [0]: ", ans4, 2, DOECHO, NULL,YEA) ;
        if(ans4[0]-'0'<1||ans4[0]-'0'>4)
        {
                return NA;
        }
        sprintf(buf,"�O�_�T�w�H��%s (Y/N)? [N]: ",doc[ans4[0]-'0'-1]);
        getdata(9, 0, buf, ans2, 2, DOECHO, NULL,YEA) ;
        if(ans2[0]!='Y' && ans2[0]!='y')
                return NA;
        in_mail = YEA;
        header.reply_mode=NA;
        strcpy(header.title,"�S�D�D");
        strcpy(header.ds,doc[ans4[0]-'0'-1]);
        header.postboard=NA;
        if(post_header(&header))
                strncpy(save_title,header.title,STRLEN) ;
        setquotefile("");
        do_quote( fname ,header.include_mode);
        if (vedit(fname,YEA) == -1) 
        {
                in_mail = NA;
                unlink( fname );
                clear(); return -2;
        }
        move(t_lines-1,0);
        clrtoeol();
        prints("[5;1;32;44m���b�H�󤤡A�еy��.....                                                        [m");
        refresh();
        mailtoall(ans4[0]-'0');
        move(t_lines-1);
        clrtoeol();
        unlink( fname );
        in_mail = NA;
        return 0;
}

void
m_internet()
{
    char receiver[ STRLEN ];

    modify_user_mode( SMAIL );
    getdata(1, 0, "���H�H: ", receiver, 70, DOECHO, NULL,YEA) ;
/*    getdata(2, 0, "�D�D  : ", title, 70, DOECHO, NULL ,YEA); */
    if ( !invalidaddr(receiver) && strchr(receiver, '@') ) {
        *quote_file = '\0';
        do_send( receiver, NULL );
    } else {
        move(3, 0);
        prints("���H�H�����T, �Э��s������O\n");
        pressreturn();
    }
    clear();
    refresh();
}

void
m_init()
{
        sprintf(currmaildir,"mail/%c/%s/%s", toupper(currentuser.userid[0]) , currentuser.userid, DOT_DIR) ;
}

int
do_send(userid,title)
char *userid, *title ;
{
    struct fileheader newmessage ;
    struct stat st ;
    char        filepath[STRLEN], fname[STRLEN], *ip;
    int         fp ;
    
#ifdef INTERNET_PRIVATE_EMAIL
    int         internet_mail = 0;
    char        tmp_fname[ 256 ];

    /* I hate go to , but I use it again for the noodle code :-) */
    if (strchr(userid, '@')) {
        internet_mail = YEA;
        sprintf( tmp_fname, "/tmp/bbs-internet-gw-%05d", getpid() );
        strcpy( filepath, tmp_fname);   
        goto edit_mail_file;
    }
    /* end of kludge for internet mail */
#endif

    if(!getuser(userid))
        return -1 ;
    if (!(lookupuser.userlevel & PERM_READMAIL))
        return -3;
    sprintf(filepath,"mail/%c/%s",toupper(userid[0]),userid) ;
    if(stat(filepath,&st) == -1) {
        if(mkdir(filepath,0755) == -1) 
            return -1 ;
    } else {    
        if(!(st.st_mode & S_IFDIR))
            return -1 ;
    }
    memset(&newmessage, 0,sizeof(newmessage)) ;
    sprintf(fname,"M.%d.A", time(NULL)) ;
    sprintf(filepath,"mail/%c/%s/%s",toupper(userid[0]),userid,fname) ;
    ip = strrchr(fname,'A') ;
    while((fp = open(filepath,O_CREAT|O_EXCL|O_WRONLY,0644)) == -1) {
        if(*ip == 'Z')
            ip++,*ip = 'A', *(ip + 1) = '\0' ;
        else
            (*ip)++ ;
        sprintf(filepath,"mail/%c/%s/%s",toupper(userid[0]),userid,fname) ;
    }
    close(fp) ;
    strcpy(newmessage.filename,fname) ;
#if defined(MAIL_REALNAMES)
    sprintf(genbuf,"%s (%s)",currentuser.userid,currentuser.realname) ;
#else
    sprintf(genbuf,"%s (%s)",currentuser.userid,currentuser.username) ;
#endif
    strncpy(newmessage.owner,genbuf,STRLEN) ;
    sprintf(filepath,"mail/%c/%s/%s",toupper(userid[0]),userid,fname) ;

#ifdef INTERNET_PRIVATE_EMAIL
edit_mail_file:
#endif
    if(title==NULL)
    {
        header.reply_mode=NA;
        strcpy(header.title,"�S�D�D");
    }
    else
    {
        header.reply_mode=YEA;
        strcpy(header.title,title);
    }
    header.postboard=NA;
    in_mail = YEA ;

  strcpy(header.ds,userid);
  if(post_header(&header))
  {
          strcpy(newmessage.title, header.title);
          strncpy(save_title,newmessage.title,STRLEN) ;
          strncpy(save_filename,fname,4096) ;
  }
  do_quote( filepath ,header.include_mode);

#ifdef INTERNET_PRIVATE_EMAIL
    if (internet_mail) {
        int res, ch;
        if (vedit(filepath,NA) == -1) {
            unlink( filepath );
            clear(); return -2;
        }
        clear() ;
        prints("�H��Y�N�H�� %s \n", userid);
        prints("���D���G %s \n", header.title );
        prints("�T�w�n�H�X��? (Y/N) [Y]");
        refresh();
        ch = egetch();
        switch ( ch ) {
            case 'N': case 'n': 
                prints("%c\n", 'N');
                prints("\n�H��w����...\n");
                res = -2;
                break;
            default: 
                prints("%c\n", 'Y');
                if(askyn("�O�_�ƥ����ۤv",NA)==YEA)
                        mail_file(tmp_fname,currentuser.userid,save_title);
                prints("�еy��, �H��ǻ���...\n"); refresh();
                res = bbs_sendmail( tmp_fname, header.title, userid ); 
                break;
        }
        unlink(tmp_fname);      
        return res;
    } else
#endif
    {
        if (vedit(filepath,YEA) == -1) {
            unlink( filepath );
            clear(); return -2;
        }
        clear() ;
        if(askyn("�O�_�ƥ����ۤv",NA)==YEA)
                mail_file(filepath,currentuser.userid,save_title);
        sprintf(genbuf,"mail/%c/%s/%s",toupper(userid[0]),userid, DOT_DIR) ;
        if(append_record(genbuf,&newmessage,sizeof(newmessage)) == -1)
             return -1 ;
        sprintf(genbuf, "mailed %s", userid);
        report(genbuf);
        return 0 ;
    }
}

int
m_send(userid)
char userid[];
{
    char uident[STRLEN] ;

   if(uinfo.mode!=LUSERS&&uinfo.mode!=LAUSERS&&uinfo.mode!=FRIEND
      &&uinfo.mode!=GMENU)
   {
    move(1,0) ;
    clrtoeol() ;
    modify_user_mode( SMAIL );
    usercomplete("���H�H�G ",uident) ;
    if(uident[0] == '\0') {
        clear() ;
        return 0 ;
    }
   }else
    strcpy(uident,userid);
    clear();
    *quote_file = '\0';
    switch (do_send(uident,NULL)) {
        case -1: prints("���H�̤����T\n") ; break;
        case -2: prints("����\n"); break;
        case -3: prints("'%s' �L�k���H\n", uident); break;
        default: prints("�H��w�H�X\n") ;
    }
    pressreturn() ;
    return 0 ;
}

int
read_mail(fptr)
struct fileheader *fptr ;
{
    sprintf(genbuf,"mail/%c/%s/%s",toupper(currentuser.userid[0]),currentuser.userid,fptr->filename) ;
    ansimore(genbuf,NA) ;
    fptr->accessed[0] |= FILE_READ;
    return 0 ;
}

int mrd ;

int delmsgs[1024] ;
int delcnt ;

int
read_new_mail(fptr)
struct fileheader *fptr ;
{
        static int idc ;
        char done = NA, delete_it;
        char fname[256];

        if(fptr == NULL) {
                delcnt = 0 ;
                idc = 0 ;
                return 0;
        }
        idc++ ;
        if(fptr->accessed[0])
          return 0 ;
        prints("Ū�� %s �H�Ӫ� '%s' ?\n",fptr->owner,fptr->title);
        prints("(Yes, or No): ") ;
        getdata(1,0,"(Y)Ū�� (N)��Ū (Q)���} [Y]: ",genbuf,3,DOECHO,NULL,YEA) ;
        if(genbuf[0] == 'q'||genbuf[0] == 'Q')
        {
                clear();
                return QUIT;
        }
        if(genbuf[0] != 'y' && genbuf[0] != 'Y' && genbuf[0] != '\0') {
                clear() ;
                return 0 ;
        }
        read_mail(fptr) ;
        strcpy(fname, genbuf);
        mrd = 1 ;
        if(substitute_record(currmaildir,fptr,sizeof(*fptr),idc))
          return -1 ;
        delete_it = NA;
    while (!done) {
        move(t_lines-1, 0);
        prints("(R)�^�H, (D)�R��, (G)�~�� ? [G]: ");
        switch ( egetch() ) {
            case 'R': case 'r': 
              mail_reply(idc, fptr, currmaildir);
              break;
            case 'D': case 'd': delete_it = YEA;
            default: done = YEA;
        }
        if (!done) ansimore(fname, NA);  /* re-read */
    }
    if (delete_it) {
        clear() ;
        prints("�R���H�� '%s' ",fptr->title) ;
        getdata(1,0,"(Y)es ,(N)o [N]: ",genbuf,3,DOECHO,NULL,YEA) ;
        if(genbuf[0] == 'Y' || genbuf[0] == 'y') { /* if not yes quit */
          sprintf(genbuf,"mail/%c/%s/%s",toupper(currentuser.userid[0]),currentuser.userid,fptr->filename) ;
          unlink(genbuf) ;
          delmsgs[delcnt++] = idc ;
        }
    }
    clear() ;
    return 0 ;
}

int
m_new()
{
    clear() ;
    mrd = 0 ;
    modify_user_mode( RMAIL );
    read_new_mail(NULL) ;
    if(apply_record(currmaildir,read_new_mail,sizeof(struct fileheader)) == -1) {
        clear() ;
        move(0,0) ;
        prints("No new messages\n\n\n") ;
        return -1 ;
    }
    if(delcnt) {
        while(delcnt--)
        delete_record(currmaildir,sizeof(struct fileheader),delmsgs[delcnt]) ;
    }
    clear() ;
    move(0,0) ;
    if(mrd)
        prints("No more messages.\n\n\n") ;
    else
        prints("No new messages.\n\n\n") ;
    return -1 ;
}

extern char BoardName[];

void
mailtitle()
{
    showtitle( "�l����    ", BoardName );
    prints( "���}[[1;32m��[m,[1;32me[m]  ���[[1;32m��[m,[1;32m��[m]  �\\Ū�H��[[1;32m��[m,[1;32mr[m]  �^�H[[1;32mR[m]  ��H���M���«H[[1;32md[m,[1;32mD[m]  �D�U[[1;32mh[m][m\n" );
    prints("[30;47m�s��   %-20s %-50s[m\n","�o�H��","��  �D") ;
    clrtobot() ;
}

char *
maildoent(num,ent)
int     num;
struct fileheader *ent ;
{
        static char buf[512] ;
        char b2[512] ;
        char status;
        char *t ;
        extern char  ReadPost[];
        extern char  ReplyPost[];
        char c1[8];
        char c2[8];
        int same=NA;

        strcpy(c1,"[1;33m");
        strcpy(c2,"[1;36m");
        if(!strcmp(ReadPost,ent->title)||!strcmp(ReplyPost,ent->title))
                same=YEA;
        strncpy(b2,ent->owner,STRLEN) ;
        if( (t = strchr(b2,' ')) != NULL )
          *t = '\0' ;
        if (ent->accessed[0] & FILE_READ) {
          if (ent->accessed[0] & FILE_MARKED) status = 'm';
          else status = ' ';
        }
        else {
          if (ent->accessed[0] & FILE_MARKED) status = 'M';
          else status = 'N';
        }
        if (!strncmp("Re:",ent->title,3)){
            sprintf(buf," %s%3d[m %c %-20.20s %s%.50s[m",same?c1:"",num,status,b2,same?c1:"",ent->title) ;}
        else{
            sprintf(buf," %s%3d[m %c %-20.20s �� %s%.47s[m",same?c2:"",num,status,b2,same?c2:"",ent->title);}
        return buf ;
}

#ifdef POSTBUG
extern int bug_possible;
#endif

int
mail_read(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
        char buf[512], notgenbuf[128];
        char *t ;
        int  readnext;
        char done = NA, delete_it, replied;

        clear() ;
        readnext=NA;
        setqtitle(fileinfo->title);
        strcpy(buf,direct) ;
        if( (t = strrchr(buf,'/')) != NULL )
          *t = '\0' ;
        sprintf(notgenbuf, "%s/%s",buf,fileinfo->filename) ;
        delete_it = replied = NA;
        while (!done) {
            ansimore(notgenbuf, NA) ;
            move(t_lines-1, 0);
            prints("(R)�^�H, (D)�R��, (G)�~��? [G]: ");
            switch (egetch()) {
                case 'R': case 'r': 
                  replied = YEA;
                  mail_reply(ent,fileinfo, direct);
                  break;
                case ' ':
                case 'j': case KEY_RIGHT: case KEY_DOWN: case KEY_PGDN:
                done = YEA;
                readnext=YEA;
                break;
                case 'D': case 'd': delete_it = YEA;
                default: done = YEA;
            }
        } 
        if (delete_it) mail_del(ent, fileinfo, direct);
        else {
          fileinfo->accessed[0] |= FILE_READ;
#ifdef POSTBUG
          if (replied) bug_possible = YEA;
#endif
          substitute_record(currmaildir, fileinfo, sizeof(*fileinfo),ent) ;
#ifdef POSTBUG
          bug_possible = NA;
#endif
        }
        if(readnext==YEA)
                return READ_NEXT;
        return FULLUPDATE ;
}

/*ARGSUSED*/
int
mail_reply(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char        uid[STRLEN] ;
    char        title[STRLEN] ;
    char        *t ;
    char        tokensep[] = "<>";

    clear();
    modify_user_mode( SMAIL );
    strncpy(uid,fileinfo->owner,STRLEN) ;
    if(strchr(uid,'<') != NULL ) 
    {
        t = strtok (uid,tokensep);
        /*t = strtok (NULL,tokensep);*/
        strcpy (uid,t);
    }
    if( (t = strchr(uid,' ')) != NULL )
        *t = '\0' ;
    if (toupper(fileinfo->title[0]) != 'R' || toupper(fileinfo->title[1]) != 'E' ||
        fileinfo->title[2] != ':') strcpy(title,"Re: ") ;
    else title[0] = '\0';
    strncat(title,fileinfo->title,STRLEN-5) ;
    sprintf(quote_file,"mail/%c/%s/%s",toupper(currentuser.userid[0]),currentuser.userid,fileinfo->filename);
    strcpy(quote_user, fileinfo->owner);      
    switch (do_send(uid,title)) {
        case -1: prints("�L�k�뻼\n"); break;
        case -2: prints("�����^�H\n"); break;
        case -3: prints("'%s' �L�k���H\n", uid); break;
        default: prints("�H��w�H�X\n");
    }
    pressreturn() ;
    return FULLUPDATE ;
}

int
mail_del(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
        char buf[512] ;
        char *t ;
        extern int cmpfilename() ;
        extern char currfile[] ;

        clear() ;
        prints("Delete Message '%s' ",fileinfo->title) ;
        getdata(1,0,"(Yes, or No) [N]: ",genbuf,2,DOECHO,NULL,YEA) ;
        if(genbuf[0] != 'Y' && genbuf[0] != 'y') { /* if not yes quit */
                move(2,0) ;
                prints("Quitting Delete Mail\n") ;
                pressreturn() ;
                clear() ;
                return FULLUPDATE ;
        }               
        strcpy(buf,direct) ;
        if( (t = strrchr(buf,'/')) != NULL )
          *t = '\0' ;
        strncpy(currfile,fileinfo->filename,STRLEN) ;
        if(!delete_file(direct,sizeof(*fileinfo),ent,cmpfilename)) {
                sprintf(genbuf,"%s/%s",buf,fileinfo->filename) ;
                unlink(genbuf) ;
                return DIRCHANGED ;
        }
        move(2,0) ;
        prints("Delete failed\n") ;
        pressreturn() ;
        clear() ;
        return FULLUPDATE ;
}
/** Added by netty to handle mail to 0Announce */
int
mail_to_tmp(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
        char buf[STRLEN];
        char *p;
        char        fname[STRLEN];
        char        board[ STRLEN ];
        char        ans[ STRLEN ];
                
        if (!HAS_PERM(PERM_BOARDS)) {
            return DONOTHING;
        }
        strncpy(buf, direct, sizeof(buf));
        if ((p = strrchr(buf, '/')) != NULL)
            *p = '\0';
        clear();
        sprintf(fname, "%s/%s", buf, fileinfo->filename);
        sprintf ( genbuf, "�N--%s--�s�J�Ȧs��,�T�w��?(Y/N) [N]: " , fileinfo->title );
        a_prompt( -1, genbuf, ans );
        if( ans[0] == 'Y' || ans[0] == 'y' ) {
                sprintf( board, "tmp/bm.%s", currentuser.userid );
                if( dashf( board ) ) {
                        sprintf ( genbuf, "�n���[�b�¼Ȧs�ɤ����?(Y/N) [N]: " ); 
                        a_prompt( -1, genbuf, ans );
                        if( ans[0] == 'Y' || ans[0] == 'y' ) {
                        sprintf( genbuf, "/bin/cat %s >> tmp/bm.%s", fname , currentuser.userid );                      
                        }   
                        else {
                        sprintf( genbuf, "/bin/cp -r %s  tmp/bm.%s", fname , currentuser.userid );
                        }
                }
                else {
                        sprintf( genbuf, "/bin/cp -r %s  tmp/bm.%s", fname , currentuser.userid );
                }
                system( genbuf );
                sprintf( genbuf, " �w�N�Ӥ峹�s�J�Ȧs��, �Ы�������H�~�� << " );
                a_prompt( -1, genbuf, ans );
        }
        clear();
        return FULLUPDATE;
}
   
     
#ifdef INTERNET_EMAIL

int
mail_forward(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
        char buf[STRLEN];
        char *p;
        if (!HAS_PERM(PERM_FORWARD)) {
            return DONOTHING;
        }
        strncpy(buf, direct, sizeof(buf));
        if ((p = strrchr(buf, '/')) != NULL)
            *p = '\0';
        clear();
        switch (doforward(buf, fileinfo, 0)) {
          case 0:  
                   prints("�峹��H����!\n");
/* comment out by jjyang for direct mail delivery */
                   sprintf(genbuf, "forwarded file to %s", currentuser.email);
                   report(genbuf);
/* comment out by jjyang for direct mail delivery */

                   break;
          case -1: prints("Forward failed: system error.\n");
                   break;
          case -2: prints("Forward failed: missing or invalid address.\n");
                   break;
          default: prints("������H...\n");
        }
        pressreturn();
        clear();
        return FULLUPDATE;
}

int
mail_uforward(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
        char buf[STRLEN];
        char *p;
        if (!HAS_PERM(PERM_FORWARD)) {
            return DONOTHING;
        }
        strncpy(buf, direct, sizeof(buf));
        if ((p = strrchr(buf, '/')) != NULL)
            *p = '\0';
        clear();
        switch (doforward(buf, fileinfo, 1)) {
          case 0:  
                   prints("�峹��H����!\n");
/* comment out by jjyang for direct mail delivery */
                   sprintf(genbuf, "forwarded file to %s", currentuser.email);
                   report(genbuf);
/* comment out by jjyang for direct mail delivery */

                   break;
          case -1: prints("Forward failed: system error.\n");
                   break;
          case -2: prints("Forward failed: missing or invalid address.\n");
        }
        pressreturn();
        clear();
        return FULLUPDATE;
}

#endif

int
mail_del_range(ent, fileinfo, direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
    return(del_range(ent, fileinfo, direct));
}

int
mail_mark(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
        if (fileinfo->accessed[0] & FILE_MARKED)
           fileinfo->accessed[0] &= ~FILE_MARKED;
        else fileinfo->accessed[0] |= FILE_MARKED;
        substitute_record(currmaildir, fileinfo, sizeof(*fileinfo),ent) ;
        return(PARTUPDATE);     
}

extern int mailreadhelp();

struct one_key  mail_comms[] = {
        'd',        mail_del,
        'D',        mail_del_range,
        'r',        mail_read,
        'R',        mail_reply,
        'm',        mail_mark,
        'i',        mail_to_tmp,
#ifdef INTERNET_EMAIL
        'F',        mail_forward,
        'U',        mail_uforward,
#endif
        'a',        auth_search_down,
        'A',        auth_search_up,
        '/',        t_search_down,
        '?',        t_search_up,
        '\'',       post_search_down,
        '\"',       post_search_up,
        ']',        thread_down,
        '[',        thread_up,
        Ctrl('A'),  show_author,
        Ctrl('N'),  SR_first_new,
        '\\',       SR_last,
        '=',        SR_first,
        Ctrl('C'),  do_cross,
        Ctrl('S'),  SR_read,
        'n',        SR_first_new,
        'p',        SR_read,
        Ctrl('X'),  SR_read,
        Ctrl('U'),  SR_author,
        'h',        mailreadhelp,
        Ctrl('J'),  mailreadhelp,
        '\0',       NULL
} ;

int
m_read()
{
    in_mail = YEA;
    i_read( RMAIL, currmaildir,mailtitle,maildoent,&mail_comms[0],sizeof(struct fileheader)) ;
    in_mail = NA;
    return 0 ;
}

#ifdef INTERNET_EMAIL

#include <netdb.h>
#include <pwd.h>
#include <time.h>
#define BBSMAILDIR "/usr/spool/mqueue"
extern char BoardName[];

int
invalidaddr(addr)
char *addr;
{
        if (*addr == '\0') return 1;   /* blank */
        while (*addr) {
            if (!isalnum(*addr) && strchr("[].%!@:-_", *addr) == NULL)
                return 1;
            addr++;
        }
        return 0;
}

void
spacestozeros(s)
char *s;
{
        while (*s) {
            if (*s == ' ') *s = '0';
            s++;
        }
}

int
getqsuffix(s)
char *s;
{
        struct stat stbuf;
        char qbuf[STRLEN], dbuf[STRLEN];
        char c1 = 'A', c2 = 'A';
        int pos = strlen(BBSMAILDIR) + 3;
        sprintf(dbuf, "%s/dfAA%5d", BBSMAILDIR, getpid());
        sprintf(qbuf, "%s/qfAA%5d", BBSMAILDIR, getpid());
        spacestozeros(dbuf);
        spacestozeros(qbuf);
        while (1) {
            if (stat(dbuf, &stbuf) && stat(qbuf, &stbuf)) break;
            if (c2 == 'Z') {
                c2 = 'A';
                if (c1 == 'Z') return -1;
                else c1++;
                dbuf[pos] = c1;
                qbuf[pos] = c1;
            }
            else c2++;
            dbuf[pos+1] = c2;
            qbuf[pos+1] = c2;               
        }
        strcpy(s, &(qbuf[pos]));
        return 0;
}

void
convert_tz(local, gmt, buf)
int gmt, local;
char *buf;
{
        local -= gmt;
        if (local < -11) local += 24;
        else if (local > 12) local -= 24;
        sprintf(buf, " %4d", abs(local * 100));
        spacestozeros(buf);
        if (local < 0) buf[0] = '-';
        else if (local > 0) buf[0] = '+';
        else buf[0] = '\0';     
}

#if 0
int
createqf(title, qsuffix)
char *title, *qsuffix;
{
        static int configured = 0;
        static char myhostname[STRLEN];
        static char myusername[20];
        char mytime[STRLEN];
        char idtime[STRLEN];
        char qfname[STRLEN];
        char t_offset[6];
        FILE *qfp;
        time_t timenow;
        int savehour;
        struct tm *gtime, *ltime;
        struct hostent *hbuf;
        struct passwd *pbuf;

        if (!configured) {
            /* get host name */
            gethostname(myhostname, STRLEN);
            hbuf = gethostbyname(myhostname);
            if (hbuf) strncpy(myhostname, hbuf->h_name, STRLEN);

            /* get bbs uident */
            pbuf = getpwuid(getuid());
            if (pbuf) strncpy(myusername, pbuf->pw_name, 20);
            if (hbuf && pbuf) configured = 1;
            else return -1;
        }

        /* get file name */
        sprintf(qfname, "%s/qf%s", BBSMAILDIR, qsuffix);
        if ((qfp = fopen(qfname, "w")) == NULL) return -1;
        
        /* get time */
        time(&timenow);
        ltime = localtime(&timenow);
#ifdef SYSV
        ascftime(mytime, "%a, %d %b %Y %T ", ltime);
#else
        strftime(mytime, sizeof(mytime), "%a, %d %b %Y %T ", ltime);
#endif
        savehour = ltime->tm_hour;
        gtime = gmtime(&timenow);
        strftime(idtime, sizeof(idtime), "%Y%m%d%y%H%M", gtime); 
        convert_tz(savehour, gtime->tm_hour, t_offset);
        strcat(mytime, t_offset);
        fprintf(qfp, "P1000\nT%lu\nDdf%s\nS%s\nR%s\n", timenow, qsuffix,
                myusername, currentuser.email);
#ifdef ERRORS_TO
        fprintf(qfp, "E%s\n", ERRORS_TO);
#endif
        /* do those headers! */
        fprintf(qfp, "HReceived: by %s (%s)\n\tid %s; %s\n",
                myhostname, VERSION_ID, qsuffix, mytime);
        fprintf(qfp, "HReturn-Path: <%s@%s>\n", myusername, myhostname);
        fprintf(qfp, "HDate: %s\n", mytime);
        fprintf(qfp, "HMessage-Id: <%s.%s@%s>\n", idtime, qsuffix,
                myhostname);
        fprintf(qfp, "HFrom: %s@%s (%s in NCTU CSIE BBS)\n", myusername, myhostname, currentuser.userid);
        fprintf(qfp, "HSubject: %s (fwd)\n", title);
        fprintf(qfp, "HTo: %s\n", currentuser.email);
        fprintf(qfp, "HX-Forwarded-By: %s (%s)\n", currentuser.userid,
#ifdef REALNAME
                currentuser.realname);
#else
                currentuser.username);
#endif
        fprintf(qfp, "HX-Disclaimer: %s �糧�H���e�����t�d�C\n", BoardName);
        fclose(qfp);
        return 0;
}
#endif

int
bbs_sendmail(fname, title, receiver)
char *fname, *title, *receiver;
{
    static int configured = 0;
    static char myhostname[STRLEN];
    static char myusername[20];
    struct hostent *hbuf;
    struct passwd *pbuf;

    FILE *fin, *fout;

    /*
     *  setup the hostname and username 
     */
    if (!configured) {
            /* get host name */
            gethostname(myhostname, STRLEN);
            hbuf = gethostbyname(myhostname);
            if (hbuf) strncpy(myhostname, hbuf->h_name, STRLEN);

            /* get bbs uident */
            pbuf = getpwuid(getuid());
            if (pbuf) strncpy(myusername, pbuf->pw_name, 20);
            if (hbuf && pbuf) configured = 1;
            else return -1;
    }

    /*
     *  Running the sendmail 
     */
    sprintf( genbuf, "/usr/lib/sendmail -f %s.bbs@%s %s", 
        currentuser.userid, email_domain(), receiver );
    fout = popen( genbuf, "w" );
    fin  = fopen( fname, "r" );
    if (fin == NULL || fout == NULL) return -1;
    
#ifdef INTERNET_PRIVATE_EMAIL
    fprintf( fout, "Return-Path: %s.bbs@%s\n", currentuser.userid, email_domain());
    fprintf( fout, "Reply-To: %s.bbs@%s\n", currentuser.userid, email_domain());
    fprintf( fout, "From: %s.bbs@%s\n", currentuser.userid, email_domain() ); 
#else
    fprintf( fout, "From: %s@%s (%s)\n", 
        myusername, myhostname, get_bbs_english_name()); 
#endif
    fprintf( fout, "To: %s\n", receiver);
    fprintf( fout, "Subject: %s\n", title);
    fprintf( fout, "X-Forwarded-By: %s (%s)\n", 
        currentuser.userid, 
#ifdef REALNAME
        currentuser.realname);
#else
        currentuser.username);
#endif

    fprintf(fout, "X-Disclaimer: %s �糧�H���e�����t�d�C\n", BoardName);
    fprintf(fout, "Precedence: junk\n"); 
    fprintf(fout, "\n");

    while (fgets( genbuf, 255, fin ) != NULL ) {
        if (genbuf[0] == '.' && genbuf[ 1 ] == '\n')
            fputs( ". \n", fout );
        else fputs( genbuf, fout );
    }
   
    fprintf(fout, ".\n");
    
    fclose( fin );
    pclose( fout );
    return 0;
}

/*Add by SmallPig*/

int
g_send()
{
    char uident[13],tmp[3];
    int cnt, i,n,fmode=NA;
    char maillists[STRLEN];
    
    modify_user_mode( SMAIL );
    *quote_file = '\0';
    clear();
    sethomefile( maillists, currentuser.userid, "maillist" );
    cnt=listfilecontent(maillists);
  while(1)
  {
    if(cnt>maxrecp-10)
    {
        move(2,0);
        prints("�ثe����H�H�� [1m%d[m �H",maxrecp);
    }
    getdata(0,0,"(A)�W�[ (D)�R�� (I)�ޤJ�n�� (C)�M���ثe�W�� (E)��� (S)�H�X? [S]�G ",
            tmp,2,DOECHO,NULL,YEA);
    if(tmp[0]=='\n'||tmp[0]=='\0'||tmp[0]=='s'||tmp[0]=='S')
    {
        break;
    }
    if(tmp[0]=='a'||tmp[0]=='d'||tmp[0]=='A'||tmp[0]=='D')
    {
     move(1,0);
     if(tmp[0]=='a'||tmp[0]=='A')
             usercomplete("�Ш̦���J�ϥΪ̥N��(�u�� ENTER ������J): ",uident) ;
     else
             namecomplete("�Ш̦���J�ϥΪ̥N��(�u�� ENTER ������J): ",uident) ;
     move(1,0);
     clrtoeol();
     if(uident[0] == '\0') continue ;
     if(!getuser(uident)) 
     {
         move(2,0);
         prints("�o�ӨϥΪ̥N���O���~��.\n");
      }
    }
    switch(tmp[0])
    {
        case 'A': case 'a':
              if (!(lookupuser.userlevel & PERM_READMAIL)) 
              {
                move(2,0);
                prints("�H��L�k�Q�H��: [1m%s[m\n", lookupuser);
                break;
              }
              else if ( seek_in_file(maillists,uident) ) {
                move(2,0);
                prints("�w�g�C������H���@ \n");
                break;
              }
              addtofile(maillists,uident);
              cnt++;
              break;
        case 'E':case 'e':
              cnt=0;
              break;
        case 'D':case 'd':
        {
              if(seek_in_file(maillists,uident))
              {
                del_from_file(maillists,uident);
                cnt--;
              }
              break;
        }
        case 'I':case 'i':
                n=0;
                clear();
                for(i=cnt;i<maxrecp&&n<nf;i++)
                {
                        int key;
                        move(2,0);
                        prints("%s\n",topfriend[n].id);
                        move(3,0);
                        n++;
                        prints("(A)�����[�J (Y)�[�J (N)���[�J (Q)����? [Y]:");
                        if(!fmode)
                                key=igetkey();
                        else
                                key='Y';
                        if(key=='q'||key=='Q')
                                break;
                        if(key=='A'||key=='a')
                        {
                                fmode=YEA;
                                key='Y';
                        }
                        if(key=='\0'||key=='\n'||key=='y'||key=='Y')
                        {
                             strcpy(uident,topfriend[n-1].id);
                             if(!getuser(uident))
                             {
                                move(4,0);
                                prints("�o�ӨϥΪ̥N���O���~��.\n");
                                i--;
                                continue;
                              }else 
                              if (!(lookupuser.userlevel & PERM_READMAIL))
                              {
                                move(4,0);
                                prints("�H��L�k�Q�H��: [1m%s[m\n", lookupuser);
                                i--;
                                continue;
                              }else
                              if ( seek_in_file(maillists,uident) ) 
                              {
                                i--;
                                continue;
                              }
                              addtofile(maillists,uident);
                              cnt++;
                        }
                }
                fmode=NA;
                clear();
                break;
        case 'C': case 'c':
                unlink(maillists);
                cnt=0;
                break;      
    }
    if(tmp[0]=='e'||tmp[0]=='E')
        break;
    move(5,0);
    clrtobot();
    if(cnt>maxrecp)
        cnt=maxrecp;
    move(3,0);
    clrtobot();
    listfilecontent(maillists);
  } 
    if(cnt > 0) {
      G_SENDMODE=2;
      switch (do_gsend(NULL,NULL,cnt)) {
        case -1: prints("�H��ؿ����~\n"); break;
        case -2: prints("����\n"); break;
        default: prints("�H��w�H�X\n") ;
      }
      G_SENDMODE=0;
      pressreturn() ;
    }
    return 0 ;
}

/*Add by SmallPig*/

int
do_gsend(userid,title,num)
char *userid[], *title ;
int num ;
{
    struct stat st ;
    char        filepath[STRLEN], tmpfile[STRLEN], fname[STRLEN];
    int         cnt;
    FILE        *mp;
   
    in_mail = YEA ;
#if defined(MAIL_REALNAMES)
    sprintf(genbuf,"%s (%s)",currentuser.userid,currentuser.realname) ;
#else
    sprintf(genbuf,"%s (%s)",currentuser.userid,currentuser.username) ;
#endif
    header.reply_mode=NA;
    strcpy(header.title,"�S�D�D");
    strcpy(header.ds,"�H�H���@�s�H");
    header.postboard=NA;
    sprintf( tmpfile, "tmp/bbs-gsend-%05d", getpid() );
    if(post_header(&header))
    {
        strncpy(save_title,header.title,STRLEN) ;
        strncpy(save_filename,fname,4096) ;
    }
    do_quote( tmpfile,header.include_mode );
    if (vedit(tmpfile,YEA) == -1) {
      unlink( tmpfile );
      clear(); return -2;
    }
    clear() ;
    if(G_SENDMODE==2)
    {
        char maillists[STRLEN];

        setuserfile( maillists,"maillist"  );
        if ((mp = fopen(maillists, "r")) == NULL)
        {
             return -3;
        }
    }
    for(cnt = 0; cnt < num; cnt++) 
    {
      char uid[13];
      char buf[STRLEN];
   
      if(G_SENDMODE==1)
              strcpy(uid,topfriend[cnt].id);
      else if(G_SENDMODE==2)
      {
         if(fgets(buf, STRLEN, mp) != NULL) 
         {
             if ( strtok( buf, " \n\r\t") != NULL)
               strcpy( uid, buf);
             else
               continue;
         }else
         {
             cnt=num;
             continue;
          }
      }
      else
              strcpy(uid, userid[cnt]);
      sprintf(filepath,"mail/%c/%s",toupper(uid[0]),uid) ;
      if(stat(filepath,&st) == -1) {
        if(mkdir(filepath,0755) == -1) 
        {
            if(G_SENDMODE==2)
                fclose(mp);
            return -1 ;
        }
      } else {  
        if(!(st.st_mode & S_IFDIR))
        {
            if(G_SENDMODE==2)
                fclose(mp);
            return -1 ;
        }
      }
      mail_file(tmpfile,uid,save_title);
    }
    unlink( tmpfile ) ;
    if(G_SENDMODE==2)
        fclose(mp);
    return 0 ;
}

int
mail_file(tmpfile,userid,title)
char tmpfile[STRLEN],userid[STRLEN],title[STRLEN];
{
      struct fileheader newmessage ;
      struct stat st ;
      char fname[STRLEN],filepath[STRLEN],*ip;
      int fp;

      memset(&newmessage, 0,sizeof(newmessage)) ;
#if defined(MAIL_REALNAMES)
    sprintf(genbuf,"%s (%s)",currentuser.userid,currentuser.realname) ;
#else
    sprintf(genbuf,"%s (%s)",currentuser.userid,currentuser.username) ;
#endif
    strncpy(newmessage.owner,genbuf,STRLEN) ;
    strncpy(newmessage.title,title,STRLEN) ;
    strncpy(save_title,newmessage.title,STRLEN) ;

      sprintf(filepath,"mail/%c/%s",toupper(userid[0]),userid) ;
      if(stat(filepath,&st) == -1) {
        if(mkdir(filepath,0755) == -1) 
            return -1 ;
      } else {  
        if(!(st.st_mode & S_IFDIR))
            return -1 ;
      }
      sprintf(fname,"M.%d.A", time(NULL)) ;
      sprintf(filepath,"mail/%c/%s/%s",toupper(userid[0]),userid,fname) ;
      ip = strrchr(fname,'A') ;
      while((fp = open(filepath,O_CREAT|O_EXCL|O_WRONLY,0644)) == -1) {
        if(*ip == 'Z')
            ip++,*ip = 'A', *(ip + 1) = '\0' ;
        else
            (*ip)++ ;
        sprintf(filepath,"mail/%c/%s/%s",toupper(userid[0]),userid,fname) ;
      }
      close(fp) ;
      strcpy(newmessage.filename,fname) ;
      strncpy(save_filename,fname,4096) ;
      sprintf(filepath,"mail/%c/%s/%s",toupper(userid[0]),userid,fname) ;

      sprintf(genbuf, "cp %s %s",tmpfile, filepath) ;
      system(genbuf);

      sprintf(genbuf,"mail/%c/%s/%s",toupper(userid[0]),userid, DOT_DIR) ;
      if(append_record(genbuf,&newmessage,sizeof(newmessage)) == -1)
        return -1 ;
      sprintf(genbuf, "mailed %s ", userid);
      report(genbuf);
    return 0 ;
}

/*Add by SmallPig*/
int
ov_send()
{
        int all,i;

        modify_user_mode( SMAIL );
        move(1,0); clrtobot();
        move(2,0); prints("�H�H���n�ͦW�椤���H�A�ثe��������ȥi�H�H�� [1m%d[m ��C\n", maxrecp);
        if(nf<=0)
        {
             prints("�A�èS���]�w�n�͡C\n");
             pressanykey();
             clear();
             return 0;
        }
        else
        {
             prints("�W��p�U�G\n");
        }
        G_SENDMODE=1;
        all=(nf>=maxrecp)? maxrecp:nf;
        for(i=0;i<all;i++)
        {
            prints("%-12s ",topfriend[i].id);
            if((i+1)%6==0)
                prints("\n");
        }
        pressanykey();
        switch (do_gsend(NULL,NULL,all)) 
        {
          case -1: prints("�H��ؿ����~\n"); break;
          case -2: prints("�H�����\n"); break;
          default: prints("�H��w�H�X\n") ;
        }
        pressreturn();
        G_SENDMODE=0;
        return 0;
}

int
in_group(uident, cnt)
char uident[maxrecp][STRLEN];
int cnt;
{
    int i;

    for(i = 0; i < cnt; i++) 
      if(!strcmp(uident[i], uident[cnt])) 
      {
                return i+1;
      }
    return 0; 
}


int
doforward(direct, fh,mode)
char *direct;
struct shortfile *fh;
int mode;
{
    static char address[ STRLEN ];
    char        fname[STRLEN],tmpfname[STRLEN];
    char        receiver[STRLEN];
    char        title[STRLEN];
    int         return_no;
    char        tmp_buf[200];

    clear();
    if( address[0] == '\0' ) {
        strncpy( address, currentuser.email, STRLEN );
    }
    prints("�Ъ����� Enter �����A�������ܪ��a�}, �Ϊ̿�J��L�a�}\n"); 
    prints("��H����H�� [%s]\n", address );

    getdata(2, 0, "==> ", receiver, 70, DOECHO, NULL,YEA);
    if( receiver[0] == '\0' ) {
        sprintf( genbuf, "�T�w�N�峹�H�� %s ��? (Y/N) [Y]: ", address );
        getdata( 2, 0, genbuf, receiver, 3, DOECHO, NULL ,YEA);
        if( receiver[0] == 'n' || receiver[0] == 'N' )
            return 1;
        strncpy( receiver, address, STRLEN );
    } else {
        strncpy( address, receiver, STRLEN );
    }
    if (invalidaddr(receiver)) return -2;
    sprintf(tmpfname,"/tmp/.forward.%s.%05d",currentuser.userid,currentuser.userid,getpid());
    sprintf( tmp_buf, "cp %s/%s %s",
                  direct, fh->filename, tmpfname);
    system( tmp_buf );
    if(askyn("�O�_�ק�峹���e",0)==1)
    {
        vedit(tmpfname,NA);
        clear();
    }
    prints("��H�H�� %s, �еy��....\n", receiver);
    refresh();

    if ( mode == 0 )
        strcpy(fname, tmpfname);
    else if ( mode == 1) {
        sprintf(fname, "/tmp/file.uu%05d", getpid() );
        sprintf( tmp_buf, "uuencode %s csie.bbs.%05d > %s",
                        tmpfname, getpid(), fname ); 
        system( tmp_buf );
    }
    sprintf(title,"%.50s(��H)",fh->title);
    if(!strstr(receiver,"@")&&!strstr(receiver,"."))
    {
        return_no=getuser(receiver);
        if(return_no==0)
        {
                return_no=1;
                prints("�ϥΪ̧䤣��...\n");
        }else
        {
                return_no = mail_file(fname, lookupuser.userid,title);
        }
    }
    else
        return_no = bbs_sendmail(fname, title, receiver);

    if ( mode == 1 ) {
        sprintf( tmp_buf, "/bin/rm -r -f %s", fname );
        system( tmp_buf );
    }
    unlink(tmpfname);
    return ( return_no );       
}

#endif

