/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"

#define BADLOGINFILE    "logins.bad"
int     MAXFRIENDS;
int     ERROR_READ_SYSTEM_FILE=NA;
int     RMSG=NA;
int     RUNSH=NA;
int     count_friends,count_users;/*Add by SmallPig for count users and Friends*/
int     iscolor=1;
int     nf;
char    *getenv();
int     friend_login_wall();
char    *sysconf_str();
char    *Ctime();
struct user_info *t_search();
void    r_msg();
void    update_endline();
int     listmode;
int     numofsig=0;
jmp_buf byebye ;

FILE *ufp ;
int talkrequest = NA ;
int ntalkrequest = NA ;
int enter_uflags;
time_t lastnote;

struct user_info uinfo ;

char netty_path[ 60 ];
char fromhost[ 60 ] ;
char tty_name[ 20 ] ;
char postfrom[ 30 ] ;

char BoardName[STRLEN] ;
char ULIST[STRLEN] ;
int utmpent = -1 ;
time_t  login_start_time;
int     showansi=1;
extern char currentbar[60];
int     showlbar=1;
extern int datacoming;

void
log_usies( mode, mesg )
char *mode, *mesg;
{
    time_t      now;
    FILE        *fp;
    char        buf[ 256 ], *fmt;

    now = time(0);
    fmt = currentuser.userid[0] ? "%s %s %-12s %s\n" : "%s %s %s%s\n";
    sprintf( buf, fmt, Ctime( &now )+4, mode, currentuser.userid, mesg );
    if( (fp = fopen( "usies", "a" )) != NULL ) {
        fputs( buf, fp );
        fclose( fp );
    }
}

void
u_enter()
{
    extern struct friend *topfriend;
    int exp;

    enter_uflags = currentuser.flags[0];
    memset( &uinfo, 0, sizeof( uinfo ) );
    uinfo.active = YEA ;
    uinfo.pid    = getpid();
    if( HAS_PERM(PERM_LOGINCLOAK) && (currentuser.flags[0] & CLOAK_FLAG) && HAS_PERM(PERM_SYSOP))
        uinfo.invisible = YEA;
    uinfo.mode = LOGIN ;
    uinfo.pager = 0;
/*    uinfo.pager = !(currentuser.flags[0] & PAGER_FLAG);*/
    if(DEFINE(DEF_FRIENDCALL))
    {
        uinfo.pager|=FRIEND_PAGER;
    }
    if(currentuser.flags[0] & PAGER_FLAG)
    {
        uinfo.pager|=ALL_PAGER;
        uinfo.pager|=FRIEND_PAGER;
    }
    if(DEFINE(DEF_FRIENDMSG))
    {
        uinfo.pager|=FRIENDMSG_PAGER;
    }
    if(DEFINE(DEF_ALLMSG))
    {
        uinfo.pager|=ALLMSG_PAGER;
        uinfo.pager|=FRIENDMSG_PAGER;
    }
    uinfo.uid = usernum;
    strncpy( uinfo.from, fromhost, 60 );
    strncpy( postfrom , fromhost, 30 );
    postfrom[29]=0;
#ifdef SHOW_IDLE_TIME
    strncpy( uinfo.tty, tty_name, 20 );
#endif
    iscolor=(DEFINE(DEF_COLOR))? 1:0;
    strncpy( uinfo.userid,   currentuser.userid,   20 );
    strncpy( uinfo.realname, currentuser.realname, 20 );
    strncpy( uinfo.username, currentuser.username, 40 );
    memset( uinfo.stuff, '-', sizeof( uinfo.stuff ) );
    nf=0;
    topfriend=NULL;
    exp=countexp(&currentuser);
    if(exp<=0)
        MAXFRIENDS=0;
    MAXFRIENDS=(exp/20);
    if( MAXFRIENDS > MAXFRIENDBOUND )
        MAXFRIENDS=MAXFRIENDBOUND;
    if(MAXFRIENDS<MINFRIENDBOUND)
        MAXFRIENDS=MINFRIENDBOUND;
    getfriendstr();
    if(uinfo.invisible==YEA)
        update_ulistnum(1,1);
    else
        update_ulistnum(0,1);
    utmpent = getnewutmpent(&uinfo) ;
    listmode=0;
    digestmode=NA;
}

void
setflags(mask, value)
int mask, value;
{
    if (((currentuser.flags[0] & mask) && 1) != value) {
        if (value) currentuser.flags[0] |= mask;
        else currentuser.flags[0] &= ~mask;
    }
}

void
u_exit()
{
    setflags(PAGER_FLAG, (uinfo.pager&ALL_PAGER));
    if (HAS_PERM(PERM_LOGINCLOAK)&&HAS_PERM(PERM_SYSOP))
        setflags(CLOAK_FLAG, uinfo.invisible);

    if( currentuser.flags[0] != enter_uflags && !ERROR_READ_SYSTEM_FILE) {
        set_safe_record();
        substitute_record(PASSFILE,&currentuser,sizeof(currentuser),usernum);
    }
    if(uinfo.invisible==YEA)
        update_ulistnum(1,-1);
    else
        update_ulistnum(0,-1);
    uinfo.active = NA ;
    uinfo.pid = 0 ;
    uinfo.invisible = YEA ;
    uinfo.sockactive = NA ;
    uinfo.sockaddr = 0 ;
    uinfo.destuid = 0 ;
#ifdef SHOW_IDLE_TIME
    strcpy(uinfo.tty, "NoTTY");
#endif
    update_utmp();
}

int
cmpuids(uid,up)
char *uid ;
struct userec *up ;
{
    return !ci_strncmp(uid,up->userid,sizeof(up->userid)) ;
}

int
dosearchuser(userid)
char *userid ;
{
    int         id;

    if( (id = getuser( userid )) != 0 ) {
        if( cmpuids( userid, &lookupuser ) ) {
            memcpy( &currentuser, &lookupuser, sizeof(currentuser) );
            return usernum = id;
        }
    }
    memset( &currentuser, 0, sizeof( currentuser ) );
    return usernum = 0;
}

int started = 0;

void
ntalk_request()
{
    signal(SIGUSR2,ntalk_request) ;
    ntalkrequest = YEA ;
    bell(); bell(); bell();
    sleep( 1 );
    bell(); bell(); bell(); bell(); bell();
    return ;
}

void
talk_request()
{
    signal(SIGUSR1,talk_request) ;
    talkrequest = YEA ;
    bell(); bell(); bell();
    sleep( 1 );
    bell(); bell(); bell(); bell(); bell();
    return ;
}


void
abort_bbs()
{
    time_t      stay;

    if(uinfo.mode==POSTING||uinfo.mode==SMAIL||uinfo.mode==EDIT
        ||uinfo.mode==EDITUFILE||uinfo.mode==EDITSFILE||uinfo.mode==EDITANN)
                keep_fail_post();
    if( started ) {
        stay = time( 0 ) - login_start_time;
        sprintf( genbuf, "Stay: %3ld (%s)", stay / 60, currentuser.username );
        log_usies( "AXXED", genbuf );
        u_exit();
    }
    exit( 0 );
}

int
cmpuids2(unum, urec)
int unum;
struct user_info *urec;
{
    return (unum == urec->uid);
}

int
count_multi( uentp )
struct user_info *uentp;
{
    static int  count;

    if( uentp == NULL ) {
        int     num = count;
        count = 0;
        return num;
    }
    if( !uentp->active || !uentp->pid )
        return 0;
    if( uentp->uid == usernum )
        count++;
    return 1;
}

int
count_user()
{
    count_multi( NULL );
    apply_ulist( count_multi );
    return count_multi( NULL );
}

void
multi_user_check()
{
    struct user_info uin;
    char buffer[40];
    int logins;

    if (HAS_PERM(PERM_MULTILOG)) return;  /* don't check sysops */
    /* allow multiple guest user */
    logins=count_user();
    if(!strcmp("guest", currentuser.userid))
    {
        if ( logins > 16 ) {
            prints( "[1;33m��p, �ثe�w���Ӧh [1;36mguest[33m, �еy��A�աC[m\n");
            pressreturn();
            oflush();
            exit(1);
        }
        return;
    }else if(logins>=3)
    {
      prints(
      "�ܩ�p %s ,�A Login �ۦP�b���T��,���T�O�L�H�W���v�q\n���s�u�N�Q����.\n"
      ,currentuser.userid );
      pressreturn();
      oflush();
      exit(1);
    }
    if ( !search_ulist( &uin, cmpuids2, usernum) )
        return;  /* user isn't logged in */

    if (!uin.active || (kill(uin.pid,0) == -1))
        return;  /* stale entry in utmp file */

    getdata(0, 0, "�z�Q�R�����ƪ� login �� (Y/N)? [N]", genbuf, 4, 
            DOECHO, NULL,YEA);

    if(genbuf[0] == 'Y' || genbuf[0] == 'y') {
        kill(uin.pid,9);
        sprintf(buffer, "kicked (multi-login)" );
        report(buffer);
        log_usies( "KICK ", currentuser.username );
    }
}

int
simplepasswd( str )
char *str;
{
    char        ch;

    while( (ch = *str++) != '\0' ) {
        if( ! (ch >= 'a' && ch <= 'z') )
            return 0;
    }
    return 1;
}

void
system_init(argc, argv)
int     argc;
char    **argv;
{
    char        *rhost;

    login_start_time = time( 0 );
    gethostname( genbuf ,256 );
#ifdef SINGLE
    if( strcmp( genbuf, SINGLE ) ) {
        printf("Not on a valid machine!\n") ;
        exit(-1) ;
    }
#endif
    sprintf( ULIST, "%s.%s", ULIST_BASE, genbuf );

    if( argc >= 3 ) {
        strncpy( fromhost, argv[2], 60 );
    } else {
        fromhost[0] = '\0';
    }
    if( (rhost = getenv( "REMOTEHOSTNAME" )) != NULL )
        strncpy( fromhost, rhost, 60 );
#ifdef SHOW_IDLE_TIME
    if(argc >= 4) { 
        strncpy( tty_name, argv[3], 20 ) ;
    } else {
        tty_name[0] = '\0' ;
    }
#endif

#ifndef lint
    signal(SIGHUP,abort_bbs) ;
    signal(SIGINT,SIG_IGN) ;
    signal(SIGQUIT,SIG_IGN) ;
    signal(SIGPIPE,SIG_IGN) ;
#ifdef DOTIMEOUT
    init_alarm();
#else
    signal(SIGALRM,SIG_SIG) ;
#endif
    signal(SIGTERM,SIG_IGN) ;
    signal(SIGURG,SIG_IGN) ;
    signal(SIGTSTP,SIG_IGN) ;
    signal(SIGTTIN,SIG_IGN) ;
    signal(SIGUSR1,talk_request) ;
/*    signal(SIGUSR2,r_msg) ;*/
    signal(SIGUSR2,ntalk_request) ;
    signal(SIGTTOU,r_msg) ;
#endif
}

void
system_abort()
{
    if( started ) {
        log_usies( "ABORT", currentuser.username );
        u_exit() ;
    }
    clear();
    refresh();
    printf("���¥��{, �O�o�`�ӳ� !\n");
    exit(0) ;
}

void
logattempt( uid, frm )
char *uid, *frm;
{
    char        fname[ STRLEN ];
    int         fd, len;

    sprintf( genbuf, "%-12.12s  %-30s %s\n",
                uid, Ctime( &login_start_time ), frm );
    len = strlen( genbuf );
    if( (fd = open( BADLOGINFILE, O_WRONLY|O_CREAT|O_APPEND, 0644 )) > 0 ) {
        write( fd, genbuf, len );
        close( fd );
    }
    sethomefile( fname, uid, BADLOGINFILE );
    if( (fd = open( fname, O_WRONLY|O_CREAT|O_APPEND, 0644 )) > 0 ) {
        write( fd, genbuf, len );
        close( fd );
    }
}

void
login_query()
{
    char        uid[STRLEN], passbuf[PASSLEN], *ptr;
    int         curr_login_num;
    int         attempts;
    char fname[STRLEN];

/*    curr_login_num = num_active_users();*/
    curr_login_num = ulist_num(2);
    if( curr_login_num >= MAXACTIVE ) {
        ansimore( "etc/loginfull", NA );
        oflush();
        sleep( 1 );
        exit( 1 ) ;
    }
    ptr = sysconf_str( "BBSNAME" );
    if( ptr == NULL )  ptr = "�|���R�W���կ�";
    strcpy( BoardName, ptr );
    direct_showfile("etc/issue.pre");
    
    strcpy(fname,"etc/issue");
/*    if(dashf(fname,"r"))
    {
        issues=countlogouts(fname);
        if(issues>=1)
        {
                user_display(fname,(issues==1)?1:
                                   ((time(0)/24*60*60)%(issues))+1,NA);
        }
    }
    ansimore(fname,NA);*/
/*    fill_shmfile(3,"systemexp","EXP_SHMKEY");*/
    if(fill_shmfile(1,fname,"ISSUE_SHMKEY"))
    {
        show_issue();
    }
    prints("[1m�w����{ [1;33m%s[37m (�ثe�@�� [1;36m%d[37m �H�W�u)[m\n", BoardName, curr_login_num );
    attempts = 0;
    while( 1 ) {
        if( attempts++ >= LOGINATTEMPTS ) {
            ansimore( "etc/goodbye", NA );
            oflush();
            sleep( 1 );
            exit( 1 );
        }
        getdata( 0, 0, "[1;37m�п�J�N��(�եνп�J `[36mguest[37m', ���U�п�J`[36mnew[37m'): [m",
                uid, STRLEN-1, DOECHO, NULL ,YEA);
        if( strcmp( uid, "new" ) == 0 ) {
#ifdef LOGINASNEW
            memset( &currentuser, 0, sizeof( currentuser ) );
            new_register();
            break;
#else
            prints([1;37m���t�Υثe�L�k�H [36mnew[37m ���U, �Х�[36m guest[37m �i�J.[m);
#endif
        } else if( *uid == '\0' || !dosearchuser( uid ) ) {
            prints( "[1;32m���~���ϥΪ̥N��...[m\n" );
        } else if( strcmp( uid, "guest" ) == 0 ) {
            currentuser.userlevel = 0;
            currentuser.flags[0] = CURSOR_FLAG | PAGER_FLAG;
            break;
        } else {
            getdata( 0, 0, "[1;37m�п�J�K�X: [m", passbuf, PASSLEN, NOECHO, NULL ,YEA);
            passbuf[8] = '\0';
            if( !checkpasswd( currentuser.passwd, passbuf )) {
                logattempt( currentuser.userid, fromhost );
                prints( "[1;32m�K�X��J���~...[m\n" );
            } else {
                if( !HAS_PERM( PERM_BASIC ) ) {
                    prints( "[1;32m���b���w�����C�ЦV [36mSYSOP[32m �d�߭�][m\n" );
                    oflush();
                    sleep( 1 );
                    exit( 1 );
                }
                if(id_with_num(uid))
                {
                  prints("[1;5;31m��p!![m\n");
                  prints("[1;32m���b���ϥμƦr�Τ��嬰�N���A���b���H�g����...[m\n");
                  prints("[1;32m�Q�O�d����ñ�W�ɽи򯸪��p�� �A�L�|���A�A�ȡC[m\n");
                  getdata( 0, 0, "�� [RETURN] �~��",genbuf,10,NOECHO,NULL,YEA);
                    oflush();
                    sleep( 1 );
                    exit( 1 );
                }
                if( simplepasswd( passbuf ) ) {
                    prints("[1;33m* �K�X�L��²��, �п�ܤ@�ӥH�W���S���r��.[m\n");
                    getdata( 0, 0, "�� [RETURN] �~��",genbuf,10,NOECHO,NULL,YEA);
                }
                break;
            }
        }
    }
    multi_user_check();
    if( !term_init(currentuser.termtype) ) {
        prints("Bad terminal type.  Defaulting to 'vt100'\n") ;
        term_init("vt100") ;
    }
    sprintf(fname,"home/%c/%s/%s.deadve",toupper(currentuser.userid[0]),currentuser.userid,currentuser.userid);
    if(dashf(fname))
    {
        mail_file(fname,currentuser.userid,"�����`�_�u�ҫO�d������...");
        unlink(fname);
    }
    sethomepath( genbuf, currentuser.userid );
    mkdir( genbuf, 0755 );
}

int
valid_ident( ident )
char *ident;
{
    static char *invalid[] = { "unknown@", "root@", "gopher@", "bbs@",
        "guest@", NULL };
    int         i;

    for( i = 0; invalid[i] != NULL; i++ )
        if( strstr( ident, invalid[i] ) != NULL )
            return 0;
    return 1;
}

void
write_defnotepad()
{
  currentuser.notedate=time(NULL);
  set_safe_record();
  substitute_record(PASSFILE, &currentuser, sizeof(currentuser), usernum);
  return;
}

/*
void
defnotepad()
{
  FILE          *def2;
  char          fname[STRLEN],spbuf[STRLEN];
  
 
  setuserfile(fname,"defnotepad");
  if((def2=fopen(fname,"r"))!=NULL)
  {
    fgets(spbuf,sizeof(spbuf),def2);
    currentuser.notemode=spbuf[0]-'0';
    if(currentuser.notemode==2)
    {
        fgets(spbuf,sizeof(spbuf),def2);
        currentuser.notedate=atol(spbuf);
        fgets(spbuf,sizeof(spbuf),def2);
        currentuser.noteline=atol(spbuf);
    }
    fclose(def2);
    unlink(fname);
  }

  if(currentuser.notemode==-1)
  {
     while(1){
        getdata( 0, 0, "�п�J�A�n���d���O�Ҧ� (1) ���� (2) �u�ݨS�ݹL�� (3) ������: ", spbuf, 2, DOECHO, NULL ,YEA);
        if(spbuf[0]=='1' || spbuf[0]=='2' || spbuf[0]=='3')
                break;
        else
                continue;
     }
     currentuser.notemode=spbuf[0]-'0';
     if(currentuser.notemode==2)
     {
        currentuser.notedate=time(NULL);
        currentuser.noteline=0;     
     }
     set_safe_record();
     substitute_record(PASSFILE, &currentuser, sizeof(currentuser), usernum);
     return;
  }
}
*/

void
notepad_init()
{
    FILE *check;
    char notetitle[STRLEN];
    char tmp[STRLEN*2];
    char *fname,*bname,*ntitle;
    long int  maxsec;
    time_t now;
    
    maxsec=24*60*60;
    lastnote=0;
    if( (check = fopen( "etc/checknotepad", "r" )) != NULL )
    {
        fgets(tmp,sizeof(tmp),check);
        lastnote=atol(tmp);
        fclose(check);
    }
    else
        lastnote=0;
        if(lastnote==0)
        {
                lastnote=time(NULL)-(time(NULL)%maxsec);
                check=fopen( "etc/checknotepad", "w" );
                fprintf(check,"%d",lastnote);
                fclose(check);
                sprintf(tmp,"�d���O�b %s Login �}�ҡA���w�}�Үɶ��ɶ��� %s"
                ,currentuser.userid,Ctime(&lastnote));
                report(tmp);
        }
        if((time(NULL)-lastnote)>=maxsec)
        {
                move(t_lines-1,0);
                prints("�藍�_�A�t�Φ۰ʵo�H�A�еy��.....");
                refresh();
                now=time(0);
                check=fopen( "etc/checknotepad", "w" );
                lastnote=time(NULL)-(time(NULL)%maxsec);
                fprintf(check,"%d",lastnote);
                fclose(check);
                if((check=fopen("etc/autopost","r"))!=NULL)
                {
                        while(fgets(tmp,STRLEN,check)!=NULL)
                        {
                           fname=strtok(tmp," \n\t:@");
                           bname=strtok(NULL," \n\t:@");
                           ntitle=strtok(NULL," \n\t:@");
                           if(fname==NULL||bname==NULL||ntitle==NULL)
                              continue;
                           else
                           {
                              sprintf(notetitle,"[%.10s] %s",ctime(&now),ntitle);
                              if(dashf(fname))
                              {
                                 postfile(fname,bname,notetitle,1);
                                 sprintf(tmp,"%s �۰ʱi�K",ntitle);
                                 report(tmp);
                              }
                           }
                        }
                        fclose(check);
                }
                sprintf(notetitle,"[%.10s] �d���O�O��",ctime(&now));
                if(dashf("etc/notepad","r"))
                {
                        postfile("etc/notepad","notepad",notetitle,1);
                        unlink("etc/notepad");
                }
                report("�۰ʵo�H�ɶ����");
        }
    return;
}


void
user_login()
{
    char        fname[ STRLEN ];
    char        ans[5], *ruser;

    if( strcmp( currentuser.userid, "SYSOP" ) == 0 )
        currentuser.userlevel = ~0;   /* SYSOP gets all permission bits */

    ruser = getenv( "REMOTEUSERNAME" );
    sprintf( genbuf, "%s@%s", ruser ? ruser : "?", fromhost );
    log_usies( "ENTER", genbuf );
    if( ruser ) {
        sprintf( genbuf, "%s@%s", ruser, fromhost );
        if( valid_ident( genbuf ) ) {
            strncpy( currentuser.ident, genbuf, NAMELEN );
        }
        if( !valid_ident( currentuser.ident ) ) {
            currentuser.ident[0] = '\0';
        }
    }
    u_enter() ;
    report("Enter") ;
    started = 1 ;
    initscr() ;
    scrint = 1 ;
    if( USE_NOTEPAD == 1)
            notepad_init();
    if(strcmp(currentuser.userid,"guest")!=0 && USE_NOTEPAD == 1){
/*      if(currentuser.notemode==1)
        shownotepad();
      else */
      if(DEFINE(DEF_NOTEPAD))
      { 
        int noteln;
        if(lastnote>currentuser.notedate)
                currentuser.noteline=0;
        noteln=countln("etc/notepad");
        if(lastnote>currentuser.notedate||currentuser.noteline==0)
        {
                shownotepad();
                currentuser.noteline=noteln;
                write_defnotepad();
        }
        else if((noteln-currentuser.noteline)>0){
                move(0,0);
                ansimore2("etc/notepad",NA,0,noteln-currentuser.noteline+1);
                prints("[1;41;31m��r�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�r��[m\n");
                igetkey();
                currentuser.noteline=noteln;
                write_defnotepad();     
                clear();
        }
      }
    }
    if( (vote_flag(NULL,'\0',2/*�ˬdŪ�L�s��Welcome �S*/)==0) )
    {
        if(dashf( "Welcome" ))
        {
                clear();
                ansimore("Welcome",YEA);
                vote_flag(NULL,'R',2/*�g�JŪ�L�s��Welcome*/);
        }
    }
    clear();
    ansimore("etc/posts/day",NA);
    move( t_lines - 1, 0 );
    clrtoeol();
    prints( "�z�� [1m%d[m ���W���A�W����[1m %s [m�q[1m %s [m�W���C\n",
            currentuser.numlogins + 1, Ctime(&currentuser.lastlogin),currentuser.lasthost );
    igetkey();
    move( t_lines - 1, 0 );
    setuserfile( fname, BADLOGINFILE );
    if( ansimore( fname, NA ) != -1 ) {
        getdata( t_lines-1, 0, "�z�n�R���H�W�K�X��J���~���O���� (Y/N)? [Y] ",
        ans, 4, DOECHO, NULL ,YEA);
        if( *ans != 'N' && *ans != 'n' )
            unlink( fname );
    }

    strncpy(currentuser.lasthost, fromhost, 16);
    currentuser.lasthost[15] = '\0';   /* dumb mistake on my part */
    currentuser.lastlogin = time(NULL) ;
    set_safe_record();
    currentuser.numlogins++;
    substitute_record(PASSFILE, &currentuser, sizeof(currentuser), usernum);
    if (currentuser.firstlogin == 0) {
        currentuser.firstlogin = login_start_time - 7 * 86400;
    }
    check_register_info();
}

void
set_numofsig()
{
    int sigln;
    char signame[STRLEN];

    setuserfile( signame, "signatures" );
    sigln=countln(signame);
    numofsig=sigln/6;
    if((sigln%6)!=0)
         numofsig+=1;
}
int
chk_friend_book()
{
        FILE *fp;
        int idnum,n=0;
        char buf[STRLEN],*ptr;

        move(3,0);
        prints("[1m�t�δM�H�W�U�C��:[m\n\n");
        if((fp=fopen("friendbook","r"))==NULL)
                return n;
        while(fgets(buf,sizeof(buf),fp)!=NULL)
        {
                char uid[14];
                char msg[STRLEN];
                struct user_info *uin;

                ptr=strstr(buf,"@");
                if(ptr==NULL)
                   continue;
                ptr++;
                strcpy(uid,ptr);
                ptr=strstr(uid,"\n");
                *ptr='\0';
                idnum=atoi(buf);
                if(idnum!=usernum||idnum<=0)
                   continue;    
                uin=t_search(uid,NA);
                sprintf(msg,"%s �w�g�W���C",currentuser.userid);
                if(uin!=NULL&&do_sendmsg(uin,msg,2,uin->pid)==1)
                {
                     prints("[1m%s[m ��A�A�t�Τw�g�i�D�L�A�W���������C\n",uid);
                }else
                     prints("[1m%s[m ��A�A�t�εL�k�p����L�A�ЧA��L�p���C\n",uid);
                n++;
                del_from_file("friendbook",buf);
        }
        fclose(fp);
        return n;
}

void
oldmain(argc, argv)
int argc ;
char **argv ;
{
    extern char currmaildir[ STRLEN ];
    char   notename[STRLEN];

#ifdef BBS_INFOD
    if (strstr( argv[ 0 ], "bbsinfo") != NULL) {
        load_sysconf();
        bbsinfod_main(argc, argv);
        exit( 0 );
    }
#endif
    load_sysconf();
    if( argc < 2 || *argv[1] != 'h' ) {
        printf( "You cannot execute this program directly.\n" );
        exit( -1 );
    }
    system_init( argc, argv );
    if( setjmp(byebye) ) {
        system_abort();
    }
    get_tty();
    init_tty();
    login_query();
    user_login();
    m_init();
    clear();
    {
      int maxmail,currmail;

      maxmail=(HAS_PERM(PERM_SYSOP))?MAX_SYSOPMAIL_HOLD:MAX_MAIL_HOLD;
      currmail=get_num_records( currmaildir, sizeof(struct fileheader) );
      prints("�A���n�ͤW���� %d �H�A�ثe�w�g�n�� %d �H�C\n",MAXFRIENDS,nf);
      if( currmail > maxmail) {
        prints("�z���p�H�H�󰪹F %d ��, �ЧR���L���H��, ���q�����b %d �ʥH�U\n",currmail,maxmail);
      }
    }
    if (HAS_PERM(PERM_SYSOP)&&dashf("new_register"))
    {
           prints("���s�ϥΪ̥��b���z�q�L���U��ơC\n");
    }
    chk_friend_book();
    if(!uinfo.invisible)
        apply_ulist(friend_login_wall);
    pressreturn();
    clear();
    memset(netty_path,0,sizeof(netty_path));
  /*  nettyNN=NNread_init(); */
    set_numofsig();
    if(DEFINE(DEF_INNOTE))
    {
        setuserfile(notename,"notes");
        if(dashf(notename))
                ansimore(notename,YEA);
    }
    b_closepolls();
    num_alcounter();
    if(count_friends>0&&DEFINE(DEF_LOGFRIEND))
        t_friends();
    while( 1 ) {
                domenu( "TOPMENU" );
        Goodbye();
    }
}

int refscreen = NA ;

int
egetch()
{
    int rval, old_mode, x, y ;
    struct SCRBUF scrbuf;
    char oldchatid[16]; 
    
    refscreen = NA;

    check_calltime();
    if (talkrequest) {
        talkreply() ;
        refscreen = YEA ;
        return -1 ;
    }
    if (ntalkrequest) {
        ntalkreply() ;
        refscreen = YEA ;
        return -1 ;
    }
    while( 1 ) {
        rval = igetkey();
        if(talkrequest) {
            talkreply() ;
            refscreen = YEA ;
            return -1 ;
        }
        if(ntalkrequest) {
            ntalkreply() ;
            refscreen = YEA ;
            return -1 ;
        }
  /* maniac �ҧ�� 01/04/98 */
        if(( rval == Ctrl('U'))&&(uinfo.mode!=LUSERS)&&(uinfo.mode!=LAUSERS)
        &&(uinfo.mode!=WFRIEND)&&(uinfo.mode!=MONITOR)&&(uinfo.mode!=FRIEND)
        &&(uinfo.mode!=VIEWABOARD)&&(uinfo.mode!=LOOKMSGS)) {
            old_mode=uinfo.mode;
            savescreen(&scrbuf,0);

            showlbar=0;
            if (uinfo.mode==TALK || uinfo.mode==CHAT) 
                 { strcpy(oldchatid,uinfo.chatid);
                   strcpy(uinfo.chatid,"��ͤ�"); 
                  update_ulist( &uinfo, utmpent);}
            t_users(); 
            if (uinfo.mode==TALK || uinfo.mode==CHAT) 
                 { strcpy(uinfo.chatid,oldchatid);
                   update_ulist( &uinfo, utmpent);}
            showlbar=1;
            
              savescreen(&scrbuf,1);
              modify_user_mode(old_mode);
              ikeypress(100); /* check if datacoming */
              if (datacoming) return 0;
        } else 
        if( rval != Ctrl('L') )
            break;
        else
            redoscr();
    }
    refscreen = NA ;
    return rval ;
}

char *
boardmargin()
{
    static char buf[STRLEN] ;
    if(selboard)
        sprintf(buf,"�Q�װ� [%s]",currboard) ;
    else {
        brc_initial( DEFAULTBOARD );
        if (getbnum(currboard)) {
            selboard = 1 ;
            sprintf(buf,"�Q�װ� [%s]",currboard) ;
        }
        else sprintf(buf,"�ثe�èS���]�w�Q�װ�") ;
    }
    return buf ;
}
/*Add by SmallPig*/
void
update_endline()
{   
    char        buf[ STRLEN ];
    char        stitle[256];
    time_t      now;
    int         allstay;
    int         colour;

    if(DEFINE(DEF_TITLECOLOR))
    {
        colour=4;
    }else
    {
            colour=currentuser.numlogins%4+3;
            if(colour==3)
                colour=1;
    }
    if(!DEFINE(DEF_ENDLINE))
    {
        move(t_lines-1,0);
        clrtoeol();
        return;
    }
    now=time(0);
    allstay=(now - login_start_time)/60;
    sprintf(buf,"[[31m%.12s[30m]",currentuser.userid);
    if(DEFINE(DEF_NOTMSGFRIEND))
    {
            sprintf(stitle,"[0;34;46m�ɶ�[%12.12s] [47;30m �H��[[31m%3d[30m] �@��G�n��[[31m%c[30m�G[31m%c[30m] �ϥΪ�%-23s ���d[[31m%3d[30m:[31m%2d[30m][m",ctime(&now)+4,ulist_num(0),
                  (uinfo.pager&ALL_PAGER)?'Y':'N',(!(uinfo.pager&FRIEND_PAGER))?'N':'Y',buf,(allstay/60)%1000,allstay%60);
    }else
    {
            num_alcounter();
            sprintf(stitle,"[1;4%d;33m�ɶ�[[36m%12.12s[33m] �`�H��:�n��[[36m%3d[33m:[36m%3d[33m][[36m%c[33m�G[36m%c[33m] �ϥΪ�%-24s [33m���d[[36m%3d[33m:[36m%2d[33m][m",colour,
                    ctime(&now)+4,count_users,count_friends,(uinfo.pager&ALL_PAGER)?'Y':'N',(!(uinfo.pager&FRIEND_PAGER))?'N':'Y',buf,(allstay/60)%1000,allstay%60);
    }
    move(t_lines-1,0);
    clrtoeol();
    prints("%s",stitle);

}


/*ReWrite by SmallPig*/
void
showtitle( title, mid )
char    *title, *mid;
{
    char        buf[ STRLEN ], *note;
    char        stitle[256];
    int         spc1,spc2;
    int         colour;

    if(DEFINE(DEF_TITLECOLOR))
    {
        colour=4;
    }else
    {
            colour=currentuser.numlogins%4+3;
            if(colour==3)
                colour=1;
    }
    note = boardmargin();
    spc1 = 39-strlen(title)-strlen(mid)/2 ;
    spc2 = 40-strlen(note)-strlen(mid)/2 ;
    if( spc1 < 2 )  spc1 = 2;
    if( spc2 < 2 )  spc2 = 2;
    move(0,0);
    clrtoeol();
    sprintf( buf, "%*s", spc1, "" );
    if(!strcmp(mid,BoardName))
    {
        sprintf(stitle, "[1;4%d;33m%s%s[37m%s[1;4%dm",colour, title, buf,mid,colour);
        prints("%s",stitle);
    }
    else if(mid[0]=='[')
    {
        sprintf( stitle,"[1;4%d;33m%s%s[5;37m%s[m[1;4%dm",colour, title, buf,mid,colour);
        prints("%s",stitle);
    }
    else 
    {
        sprintf( stitle,"[1;4%d;33m%s%s[36m%s",colour, title, buf,mid);
        prints("%s",stitle);
    }
    sprintf( buf, "%*s", spc2, "" );
    prints( "%s[33m%s[m\n", buf, note );
    update_endline();
    move(1,0);
}


void
docmdtitle( title, prompt )
char    *title, *prompt;
{
    char   middoc[30];
    struct shortfile    *getbcache();

    if(chkmail())
        strcpy(middoc,"[�z���H��]");
    else
        strcpy(middoc,BoardName);
        

    showtitle( title, middoc);
    move(1,0);
    clrtoeol() ;
    prints( "%s", prompt ); 
    clrtoeol();
}

