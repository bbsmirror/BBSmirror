/*    Ptt   �}�� ��utility  */
// modified for MagicBBS by Magi

#include "../bbs.h"
#define BBSHOME          "/home/bbs"
#define FN_TICKET_RECORD "etc/ticket.data"
#define FN_TICKET_USER   "etc/ticket.user"
#define FN_TICKET        "etc/ticket.result"

extern char *betname[8];
                    
#define MAX_DES 7 /* �̤j�O�d���� */

#define DOTPASSWDS "/home/bbs/.PASSWDS"
struct userec xuser;

int getuser(userid)
  char *userid;
{
  int uid;
  if (uid = searchuser(userid))
   {
    get_record(DOTPASSWDS, &xuser, sizeof(xuser), uid);
   }
  return uid;
}

int inumoney(char *tuser,int money)
{
  int unum;

  if (unum = getuser(tuser))
    {
      xuser.money += money;
      substitute_record(DOTPASSWDS, &xuser, sizeof(xuser), unum);
      return xuser.money;
    }
  return -1;
}

Link(char* src, char* dst)
{
   char cmd[200];

   if (link(src, dst) == 0)
      return 0;

   sprintf(cmd, "/bin/cp -R %s %s", src, dst);
   return system(cmd);
}

char *
Cdatelite(clock)
  time_t *clock;
{
  static char foo[18];
  struct tm *mytm = localtime(clock);

  strftime(foo, 18, "%D %T", mytm);
  return (foo);
}


main()
{
 int money, bet, n, total=0, ticket[8] = {0,0,0,0,0,0,0,0};
 FILE *fp;
 time_t  now = time(0);
 char  des[MAX_DES][200]={"","","",""};

 rename(BBSHOME "/" FN_TICKET_RECORD,BBSHOME "/" FN_TICKET_RECORD".tmp");
 rename(BBSHOME "/" FN_TICKET_USER,BBSHOME "/" FN_TICKET_USER".tmp");

 if(!(fp = fopen(BBSHOME "/" FN_TICKET_RECORD ".tmp" ,"r")))  return;
 fscanf(fp,"%9d %9d %9d %9d %9d %9d %9d %9d\n",
                 &ticket[0],&ticket[1],&ticket[2],&ticket[3],
                 &ticket[4],&ticket[5],&ticket[6],&ticket[7]);
 for(n = 0; n < 8; n++)
                total += ticket[n];
 fclose(fp);

 if(!total) return;

 if(fp = fopen(BBSHOME "/" FN_TICKET,"r"))
  {
   for(n=0; n < MAX_DES && fgets(des[n],200,fp); n++);
   fclose(fp);
  }

 srandom(now + 11 );
 bet=(int) (8.0*random()/(RAND_MAX+1.0));

 money = ticket[bet] ? total * 95 / ticket[bet] : 9999999;

 if(fp = fopen(BBSHOME "/" FN_TICKET,"w"))
  {
   if(des[MAX_DES-1][0]) n = 1;
   else n = 0;
   for(; n < MAX_DES && des[n][0] != 0; n++)
        {
         fprintf(fp,des[n]);
        }
   fprintf(fp,"%s ��L�}�X:%s �`���B:%d00 �� ����/�i:%d �� ���v:%1.2f\n",
         Cdatelite(&now), betname[bet], total, money,
         (float)ticket[bet]/total);
   fclose(fp);
  }

 if(ticket[bet] && (fp = fopen(BBSHOME "/" FN_TICKET_USER".tmp","r")))
                        /* ���H�㤤 */
        {
          int mybet, num;
          char userid[20];
          char title[STRLEN];

          while (fscanf(fp,"%s %d %d\n", userid, &mybet, &num) != EOF)
                {
                  if(mybet == bet)
                        {
                          printf("%s ���F %d �i [%s] �o %d ��\n",userid, num, betname[mybet], money * num);
                          if(inumoney(userid, money * num) == -1) 
                            { printf("Error writing passwd!\n"); continue; }
                          chdir(BBSHOME); // fix for mail_file()
                          strcpy(currentuser.userid,"�]�k��L");
                          strcpy(currentuser.username,"");
                          strcpy(currentuser.realname,"");
                          sprintf(title, "[%s] �����o! $ %d", Cdatelite(&now), money * num);
                          mail_file(FN_TICKET,userid,title);
                        }
                }
        }
 unlink(BBSHOME "/" FN_TICKET_RECORD".tmp");
 unlink(BBSHOME "/" FN_TICKET_USER".tmp");
}
