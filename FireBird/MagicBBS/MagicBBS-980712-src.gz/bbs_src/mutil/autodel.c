/* �۰ʬ�H�{�� by Magi 4/25/98 */

#include "../bbs.h"
#include <stdio.h>
#include <time.h>
#define CONFNAME  "autodel"
#define BBSHOME   "/home/bbs"
#define MAXCMD    (100)

char cmdbuf[MAXCMD][255];
int  lp=100,gp=100,gsize=0,size=0;

int loadconf(int s,char *fname)
{
    char buf[255];
    FILE *fp;

    if((fp=fopen(fname,"r"))==NULL) return s;
    while(fgets(cmdbuf[s],255,fp)!=NULL)
      {   
      if (cmdbuf[s][0]=='P')
          sscanf(cmdbuf[s],"P%d\n",&lp);
          cmdbuf[s][strlen(cmdbuf[s])-1]=0;

          s++; 
      }   
    cmdbuf[s][0]=0;
    printf("%s load OK. preserve=%d, size=%d\n",fname,lp,s);
    return s;
}

int should_del(char *path,struct fileheader *fh,int exp_t)
{
    int i=0;
    char buf[255];
    FILE *fp;
    char tmp;
    time_t ftime;
    struct stat st;
    
    sprintf(buf,"%s/%s",path,fh->filename);    
    if(stat( buf, &st ) != 0) return 1; 
     
    sscanf(fh->filename,"%c.%d.%c",&tmp,&ftime,&tmp);
    if (ftime<exp_t) { /*printf("Skipped %s\n",fh->filename);*/ return 0; }

    if((fp=fopen(buf,"r"))==NULL)
           return 1; 
    if(fgets(buf,255,fp)==NULL)
         { fclose(fp); return 1; }
    fclose(fp);
    
    while(i<size) 
    {
       switch(cmdbuf[i][0])
       { 
        case 's':
             if(strstr(fh->title,&cmdbuf[i][1])!=NULL)
                       return 1; break;
        case 'S':
             if(strcmp(fh->title,&cmdbuf[i][1])==0)
                       return 1; break;
        case 'f':
             if(strstr(buf,&cmdbuf[i][1])!=NULL)
                       return 1; break;
       }
       i++;
    }
    return 0;
}


int scanboard(char *path)
{          
     struct fileheader fh;
     char buf[255],tmpf[255],dirf[255],last[255];
     int fdt,fdr,fdw,range,i=0,val;
     time_t now=0,prev=0;
     
     lp=gp;
     sprintf(buf,"%s/.%s",path,CONFNAME);
     size=loadconf(gsize,buf); 

     sprintf(buf,"%s/.lastscan",path);
     if((fdt = open(buf, O_RDONLY , 0))!=-1)
        if(read(fdt,&prev,sizeof(prev))==sizeof(time_t))
               close(fdt);

    printf("Enter %s prev_time=%10s\n",path,ctime(&prev));

     
     sprintf(dirf,"%s/.DIR",path);
    if((fdr = open(dirf,O_RDONLY,0)) == -1) 
        { fprintf(stderr,"Can't open %s for read\n",dirf); return(-1); }
     
     sprintf(tmpf,"%s/.DIR.tmp",path);
    if((fdw = open(tmpf,O_WRONLY | O_CREAT , 0644)) == -1)
            { fprintf(stderr,"Can't open %s for write\n",tmpf); return(-1); }
    
    range=lseek(fdr,0,SEEK_END)-lp*sizeof(fh);
    lseek(fdr,0,SEEK_SET);
    
                   
    while(read(fdr,&fh,sizeof(fh)) == sizeof(fh)) {

           val=i*sizeof(fh)-range;
           if(  (should_del(path,&fh,prev) || ( val < 0)) && 
                !(fh.accessed[0] & FILE_MARKED) )
             { printf("Del %s(%d/%d) %d %d\n",fh.filename,i*sizeof(fh),range,should_del(path,&fh,prev),(i*sizeof(fh) -range)); 
               sprintf(buf,"%s/%s",path,fh.filename);
               unlink(buf);
           } else 
           { if(write(fdw,&fh,sizeof(fh))!=sizeof(fh))
                 { fprintf(stderr,"Error writing new index for %s\n",path);
                   return(-1);	
                 }
           }
       i++;      
    }
    close(fdr);
    close(fdw);
    unlink(dirf);
    rename(tmpf,dirf);

    sprintf(buf,"%s/.lastscan",path);
    if((fdt = open(buf,O_WRONLY | O_CREAT , 0644)) == -1)
            { fprintf(stderr,"Can't open %s for write\n",buf); return(-1); }
    now=time(0);
    write(fdt,&now,sizeof(time_t));
    close(fdt);
    return 0;
}

int main(int argc,char *argv[])
{
     int i=0;
     char buf[255];
     int fdb;
     struct boardheader bh;

     sprintf(buf,"%s/etc/%s.conf",BBSHOME,CONFNAME);
     gsize=loadconf(0,buf);
     gp=lp;

    sprintf(buf,"%s/.BOARDS",BBSHOME); 
    if((fdb = open(buf,O_RDONLY,0)) == -1) 
        { fprintf(stderr,"Can't open %s for read\n",buf); exit(-1); }
    while(read(fdb,&bh,sizeof(bh))==sizeof(bh)) 
    {
         sprintf(buf,"%s/boards/%s",BBSHOME,bh.filename);
         scanboard(buf);
    }
}