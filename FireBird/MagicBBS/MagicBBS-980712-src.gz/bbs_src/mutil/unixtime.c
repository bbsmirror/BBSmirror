void main(void)
{
   printf("%d",time());
} 