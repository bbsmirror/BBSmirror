#include "../bbs.h"
#include <stdio.h>

extern struct UTMPFILE *utmpshm;
extern int friendmode,range;
struct user_info *user_record[MAXACTIVE];

int main()
{
   struct user_info *uentp;
   int i;
   char *ptr;

   printf("�]�k����BBS�u�W�Τ�C��\n\n");      
   
   chdir("/home/bbs");
   load_sysconf();
   ptr = sysconf_str("BBSNAME");

   friendmode=0;
   fill_userlist();
   printf("No. �ϥΪ̥N��   �ϥΪ̼ʺ�       �Ӧ�                         �ʺA       ���m\n");
   printf("=== ============ ================ ============================ ========== ====\n");
   
   for(i=0;i<range;i++)
   {
      uentp=user_record[i];
      printf("%2d  %-12.12s %-16.16s %-28.28s %-10.10s %s\n",i+1,uentp->userid,uentp->username,uentp->from
      ,modestring(uentp->mode, uentp->destuid, 1,
      ((uentp->in_chat) || (uentp->mode==IDLE)) ? uentp->chatid : NULL)   
      ,idle_str( uentp )); 
   }
   printf("\n                                                 [�ثe���W�@�� %d �H]\n",i);
}
