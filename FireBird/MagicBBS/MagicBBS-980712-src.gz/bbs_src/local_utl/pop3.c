#include "bbs.h"
#ifdef lint
#include <sys/uio.h>
#endif
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#define COLOR (4)
char TOPSTR[160];
int a;

typedef struct node GOPHER;
struct node {
    char        file[81],title[71],server[41];
    int         port;
    int         position;
    GOPHER      *next;
};

GOPHER *g_main[100];/*100 directories to move in to*/
GOPHER *tmpitem;
GOPHER *topitem;
int    gopher_position=0;


GOPHER *
next(node)
GOPHER *node;
{
        if(node==NULL)
                return NULL;
        else
                return node->next;
}


GOPHER *
find_kth(node,n)
GOPHER *node;
int n;
{
        int i;
        GOPHER *tmpnode;

        tmpnode=node;
        for(i=0;i<=n;i++)
        {
                tmpnode=next(tmpnode);
        }
        return tmpnode;
}

int
readfield(fd, ptr, maxlen)
  int   fd;
  char  *ptr;
  int   maxlen;
{
     int n;
     int rc;
     char c;

     for (n=1; n < maxlen; n++) {
          if ( (rc = read(fd, &c, 1)) == 1) {
               *ptr++ = c;
               if (c == '\t') {
                    *(ptr - 1) = '\0';
                    break;
               }
          }
          else if (rc == 0) {
               if (n == 1)
                    return(0);  /* EOF, no data read */
               else
                    break;              /* EOF, some data was read */
          }
          else
               return(-1);              /* error */
     }

     *ptr = 0;                          /* Tack a NULL on the end */
     return(n);
}

int readline(fd, ptr, maxlen)
  int   fd;
  char  *ptr;
  int   maxlen;
{
     int n;
     int rc;
     char c;


     for (n=1; n < maxlen; n++) {
          if ( (rc = read(fd, &c, 1)) == 1) {
               *ptr++ = c;
               if (c == '\n')
                    break;
          }
          else if (rc == 0) {
               if (n == 1)
                    return(0);  /* EOF, no data read */
               else
                    break;              /* EOF, some data was read */
          }
          else
               return(-1);              /* error */
     }

     *ptr = 0;                          /* Tack a NULL on the end */
     return(n);
}

int
savetmpfile(tmpname)
char tmpname[];
{
        char ch;
        char buf[256];
        FILE *fp;
        int cc;

    if((fp=fopen(tmpname,"w"))==NULL)
        return -1;
         fprintf(fp,"��  ��: %s\n",tmpitem->server);
         fprintf(fp,"��  �W: %s(�ϥ� %d ��)\n",tmpitem->file,tmpitem->port);
         fprintf(fp,"��  �D: %s\n\n",tmpitem->title+1);
        while(1)
        {
         if((cc=read(a,buf,255))>0)
         {
             buf[cc]='\0';
             fprintf(fp,"%s",buf);
         }else
         {
                fclose(fp);
                break;
         }
        }
        return 1;

}

int
enterdir(path)
char path[];
{
        char buf[256];
        sprintf(buf,"%s\r\n",path==NULL?"":path);
        write(a,buf,sizeof(buf));
}

int
get_con(servername,port)
char *servername;
int port;
{
    struct hostent *h,*h2 ;
    char buf[1024] ;
    char hostname[81] ;
    struct sockaddr_in sin ;
    char ch[1];
    int  get;

    gethostname(hostname,80);
    if(!(h = gethostbyname(hostname))) {
        perror("gethostbyname") ;
        return -1 ;
    }

    if(!(h2 = gethostbyname(servername)))
    {
        perror("gethostbyname");
        return -1;
    }
    sin.sin_family=AF_INET;
    memcpy(&sin.sin_addr, h2->h_addr, h2->h_length);
    if(!(a=socket(AF_INET,SOCK_STREAM,0)))
    {
        perror("Socket:");
        return -1;
    }
    sin.sin_port = htons(port);
    bind(a,(struct sockaddr *)h,sizeof h);
    if((connect(a, (struct sockaddr *)&sin, sizeof sin))) {
        perror("connect err") ;
        return -1 ;
    }
    return 1;
}

int
showout()
{
    int i,len,lines,i2;
    char cch[5],tmpbar[80],rc,buf[1024];
    char hostname[81] ,tmpfile[STRLEN],foo[1024];
    struct sockaddr_in sin ;
    char ch,model[]="-/|\\";
    int  get;
    FILE *fp,*fp2;
    GOPHER *newitem,*tmpnode;

    i=0;
    if(get_con(g_main[gopher_position]->server,g_main[gopher_position]->port)==-1)
    {
        printf("�L�k�s�W....\n");
    }
    while(read(a,buf,1024)>0)
    {
        printf("%s",buf);
        break;
    }
    printf("aaaaaaaaaaaaaaaaaaaaaaaa");
    write(a,"user chj83u",11);
    while(read(a,buf,1024)>0)
    {
        printf("%s",buf);
        break;
    }
    printf("aaaaaaaaaaaaaaaaaaaaaaaa");

    write(a,"pass smpcty123",13);
    while(read(a,buf,1024)>0)
    {
        printf("%s",buf);
        break;
    }
    printf("aaaaaaaaaaaaaaaaaaaaaaaa");

    return;

}

main()
{
/*         gopher("gopher.nsysu.edu.tw","nntp ls cna.today",4320,"test");*/
           gopher("cs.ccu.edu.tw","",110,"");
 /*        gopher("news.csie.nctu.edu.tw","gonnrp -T cna.today",4870,"test");*/
}

gopher(serv,dire,port,title)
char serv[],dire[],title[];
int port;
{
        GOPHER *newitem;
        char buf[80];


        gopher_position=0;
        sprintf(TOPSTR,"[4%dm                            [1;3%dm�i[37m�������Y�ɷs�D����[3%dm�j[m[4%dm                            [m",COLOR,COLOR,COLOR,COLOR);
        newitem = (GOPHER *) malloc( sizeof(GOPHER) );
        strncpy(newitem->server,serv,40);
        strncpy(newitem->file,dire,80);
        sprintf(buf," %s",title);
        strncpy(newitem->title,buf,70);
        newitem->port=port;
        newitem->position=0;
        g_main[gopher_position]=newitem;

        topitem = (GOPHER *) malloc( sizeof(GOPHER) );
        topitem->next=NULL;
        showout();
        close(a);
}
