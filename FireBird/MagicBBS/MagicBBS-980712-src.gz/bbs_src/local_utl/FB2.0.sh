#! /bin/sh
gcc -o rehome rehome.c record.o
gcc -o refriend refriend.c record.o
refriend
rehome
