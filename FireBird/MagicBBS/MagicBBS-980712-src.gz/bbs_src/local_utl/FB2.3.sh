#! /bin/sh
gcc -o rehome rehome.c record.o
rehome
