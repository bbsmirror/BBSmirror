#! /bin/sh
make renotepad
renotepad
mv /home/bbs/etc/systempassword /home/bbs/etc/.syspasswd
