#! /bin/sh
gcc -o repass repass.c
gcc -o rehome rehome.c record.o
gcc -o refriend refriend.c record.o
cp /home/bbs/.PASSWDS /home/bbs/.PASSWDS.old
repass
cp .PASSWDS.tmp /home/bbs/.PASSWDS
chown bbs.bbs /home/bbs/.PASSWDS
refriend
rehome
