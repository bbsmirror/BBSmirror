#include "bbs.h"

int has_card();

extern char BoardName[];
typedef struct
{
        char    *match;
        char    *replace;
}
logout;

int 
countlogouts(filename)
char filename[STRLEN];
{
        FILE    *fp;
        char    buf[256];
        int count=0;
        
        if((fp = fopen(filename, "r")) == NULL)
                return 0;

        while(fgets(buf, 255, fp) != NULL)
        {
                if(strstr(buf,"@logout@")||strstr(buf,"@issue@"))
                        count++;
        }
        return count+1;
}


user_display(filename,number,mode)
char    *filename;
int number,mode;
{
        FILE    *fp;
        char    buf[256];
        int     count=1;

        clear();
        move(1,0);
        if((fp = fopen(filename, "r")) == NULL)
                return;

        while(fgets(buf, 255, fp) != NULL)
        {
                if(strstr(buf,"@logout@")||strstr(buf,"@issue@"))
                {
                        count++;
                        continue;
                }
                if(count==number)
                {
                   if(mode==YEA)
                        showstuff(buf);
                   else
                   {
                        prints("%s",buf);
                    }
                }
                else if(count>number)
                   break;
                else
                    continue;
        }
        refresh();
        fclose(fp);
        return;
}


char *
cexp(exp)
int exp;
{
        int expbase=0;

        if(exp==-9999)
                return "�S����";
        if(exp<=100+expbase)
                return "�s�ө~��";
        if(exp>100+expbase&&exp<=250+expbase)
                return "�@��~��";
        if(exp>250+expbase&&exp<=550+expbase)
                return "�u�}����";
        if(exp>550+expbase&&exp<=1000+expbase)
                return "���ѯ�";
        if(exp>1000+expbase&&exp<=2000+expbase)
                return "��������";
        if(exp>2000+expbase)
                return "�}��j��";
}

char *
cstrperf(udata)
struct userec *udata;
{        
 int perf;
 perf=countperf(udata);	
   switch(udata->sex)
    { case 1:
      case 2:     
        if(perf==32767) 
         	return "���F";
        else if(perf==-9999)
                return "�C��";
        else if(perf<=45)
                return "�˪L�U����";
        else if(perf<=85)
                return "�]�k�Ƕ��ť�";
        else if(perf<=150)
                return "�]�k�Ƕ餤�ť�";
        else if(perf<=250) 
                return "�]�k�Ƕ鰪�ť�";
        else if(perf<=400)
                return "����]�ɤh";
        else if(perf<=650)
                return "�����]�ɤh";                
        else if(perf<=900)
                return "�W���]�ɤh";
        else if(perf<=1400)
                return "�Ӯa�]�k�v��|�|��";
        if(perf>1400)
                return "�j�Ѧ��]�ɮv";
        break;
       case 3:
       case 4:         
        if(perf==32767)
                return "���F";
        else if(perf==-9999)
                return "�C��";
        else if(perf<=45)
                return "�i�R�U����";
        else if(perf<=85)
                return "�]�k�Ƕ��ť�";
        else if(perf<=150)
                return "�]�k�Ƕ餤�ť�";
        else if(perf<=250)
                return "�]�k�Ƕ鰪�ť�";
        else if(perf<=400)
                return "���֤k�Ԥh";
        else if(perf<=650)
                return "�]�k�֤k";
        else if(perf<=900)
                return "�]�k�M�h";
        else if(perf<=1400)
                return "�]�k���D";
        if(perf>1400)
                return "�j�Ѧ��]�ɮv";
        break;
       case 5:
        if(perf==32767)
                return "���F";
        else if(perf==-9999)
                return "�C��";
        else if(perf<=45)
                return "�p�ؤl";
        else if(perf<=100)
                return "�]�k�U�]";
        else if(perf<=250)
                return "�p����F";
        else if(perf<=450)
                return "�]�k����";
        else if(perf<=800)
                return "���U�Ѩ�";
        if(perf>800)
                return "�ᤧ���F";
	break;
       case 6:         
        if(perf==32767)
                return "���F";
        else if(perf==-9999)
                return "�C��";
        else if(perf<=45)
                return "�p�x��";
        else if(perf<=85)
                return "������";
        else if(perf<=150)
                return "�j�z��";
        else if(perf<=250)
                return "������";
        else if(perf<=400)
                return "���V��";
        else if(perf<=600)
                return "�]�k���_��";
        else if(perf<=800)
                return "�]�k���_��";
        else if(perf<=1200)
                return "�]�k�p��";
        if(perf>1200)
                return "�]�k�R���|���q";
        break;        
       default:
        if(perf==32767)
                return "���F";
        else if(perf==-9999)
                return "�C��";
        else if(perf<=45)
                return "�˪L�U����";
        else if(perf<=85)
                return "�]�k�Ƕ��ť�";
        else if(perf<=150)
                return "�]�k�Ƕ餤�ť�";
        else if(perf<=250)
                return "�]�k�Ƕ鰪�ť�";
        else if(perf<=400)
                return "����]�ɤh";
        else if(perf<=650)
                return "�����]�ɤh";
        else if(perf<=900)
                return "�W���]�ɤh";
        else if(perf<=1400)
                return "�Ӯa�]�k�v��|�|��";
        if(perf>1400)
                return "�j�Ѧ��]�ɮv"; 
   }
}

int
countexp(udata)
struct userec *udata;
{
   int exp;
   if(!strcmp(udata->userid,"guest"))
        return -9999;
   if(udata->userlevel & PERM_SYSOP)
           return 32767;        
   exp=udata->numposts+post_in_tin( udata->userid )+udata->numlogins/5+(time(0)-udata->firstlogin)/86400+udata->stay/3600;
   return exp>0?exp:0;
}

int
countperf(udata)
struct userec *udata;
{
   int perf;
   int reg_days;
   int stay_hours;
   float avg,f1,f2;

   if(!strcmp(udata->userid,"guest"))
        return -9999;
   if(udata->userlevel & PERM_SYSOP)
   	  return 32767;
   if((udata->numlogins) < 4) return 0;   	  
   reg_days=(time(0)-udata->firstlogin)/86400+1;
   stay_hours=udata->stay/3600;
   
   avg=((float)udata->numlogins/(float)reg_days);
   f1=90*(float)(udata->numposts)/(float)(udata->numlogins);
   
   
   if (avg>4) { avg=4; }
   if (f1>450) { f1=450; }
   
   perf=udata->addmagic+(udata->numlogins+8*stay_hours+f1+
        15*avg+
        2*udata->numposts+
        (3*(float)(udata->stay/60))/(float)(udata->numlogins))/3.1415926535;
        
   if (reg_days<5) { perf=perf/(5-reg_days); } 
   if (perf > ((avg+5)*udata->numlogins)) {return ((avg+5)*udata->numlogins+udata->addmagic);} 
   if (udata->card & CARD_MAGICPRO) perf*=1.5;
   return perf>0?perf:0;
}

showstuff(buf)
char    buf[256];
{
        extern time_t   login_start_time;
        int     frg,
                i,
                matchfrg,
                strlength,
                cnt,
                tmpnum;
              static  char    numlogins[10],
                        numposts[10],
                        rgtday[35],
                        lasttime[35],
                        thistime[35],
                        tin[10],
                        stay[10],
                        alltime[20],
                        ccperf[20],
                        perf[10],
                        exp[10],
                        ccexp[20];
        char    buf2[STRLEN],
                *ptr,
                *ptr2;
        time_t  now;

        static logout loglst[] =
        {
                "userid",       currentuser.userid,
                "username",     currentuser.username,
                "realname",     currentuser.realname,
                "address",      currentuser.address,
                "email",        currentuser.email,
                "termtype",     currentuser.termtype,
                "realemail",    currentuser.termtype+16,
                "ident",        currentuser.ident,
                "rgtday",       rgtday,
                "log",          numlogins,
                "pst",          numposts,
                "lastlogin",    lasttime,
                "lasthost",     currentuser.lasthost,
                "now",          thistime,
                "bbsname",      BoardName,
                "tin",          tin,
                "stay",         stay,
                "alltime",      alltime,
                "exp",          exp,
                "cexp",         ccexp,
                "perf",         perf,
                "cperf",        ccperf,
                NULL,           NULL,
        };
        if(!strchr(buf, '$'))
        {
                prints("%s",buf);
                return;
        }
        now=time(0);
        tmpnum=countexp(&currentuser);
        sprintf(exp,"%d",tmpnum);
        strcpy(ccexp,cexp(tmpnum));
        tmpnum=countperf(&currentuser);
        sprintf(perf,"%d",tmpnum);
        strcpy(ccperf,cstrperf(&currentuser));
        sprintf(alltime,"%d�p��%d����",currentuser.stay/3600,(currentuser.stay/60)%60);
        sprintf(rgtday, "%24.24s",ctime(&currentuser.firstlogin));
        sprintf(lasttime, "%24.24s",ctime(&currentuser.lastlogin));
        sprintf(thistime,"%24.24s",ctime(&now));
        sprintf(stay,"%d",(time(0) - login_start_time) / 60);
        sprintf(numlogins, "%d", currentuser.numlogins);
        sprintf(numposts, "%d", currentuser.numposts);
        sprintf(tin, "%d", post_in_tin(currentuser.userid));

                frg = 1;
                ptr2 = buf;
                do
                {
                        if(ptr = strchr(ptr2, '$'))
                        {
                                matchfrg = 0;
                                *ptr = '\0';
                                prints("%s", ptr2);
                                ptr += 1;
                                for (i = 0; loglst[i].match != NULL; i++)
                                {
                                        if(strstr(ptr, loglst[i].match) == ptr)
                                        {
                                                strlength=strlen(loglst[i].match);
                                                ptr2 = ptr+strlength;
                                                for(cnt=0; *(ptr2+cnt) == ' '; cnt++);
                                                sprintf(buf2,"%-*.*s", cnt?strlength+cnt:strlength+1, strlength+cnt,loglst[i].replace);
                                                    prints("%s",buf2);
                                                ptr2 += (cnt?(cnt-1):cnt);
                                                matchfrg=1;
                                                break;
                                        }
                                }
                                if(!matchfrg)
                                {
                                        prints("$");
                                        ptr2 = ptr;
                                }
                        }
                        else
                        {
                                prints("%s", ptr2);
                                frg = 0;
                        }
                }
                while(frg);
        return;
}
