#define MONEY 0
#define MAGIC 1
#define BANK  3

#define CARD_GOLD     (0x01)
#define CARD_SILVER   (0x02)
#define CARD_MAGICPRO (0x04)

#define inmoney(num)   inc(MONEY,num)  //�Mptt�ۮe
#define demoney(num)   inc(MONEY,-(num))
