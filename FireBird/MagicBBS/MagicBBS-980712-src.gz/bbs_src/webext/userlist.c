#include "../bbs.h"
#include "cgic.h"
#include <stdio.h>
#include "config.h"

#define ME      "http://tsunami.ml.org/cgi-bin/userlist"
extern struct UTMPFILE *utmpshm;
extern int friendmode,range;
struct user_info *user_record[MAXACTIVE];

int cgiMain()
{
   char buf[255],p[10],id[IDLEN];
   struct user_info *uentp;
   int i;

   cgiFormStringNoNewlines("id", id, IDLEN);
   cgiFormStringNoNewlines("p", p, 10);   
   ht_header("�]�k����BBS�u�W�Τ�C��");      
   ht_default_color();
      
   if(resumeuser(id,p)!=0)
          ht_exit(-1);
             
   resys();
   friendmode=0;
   fill_userlist();
   fprintf(cgiOut,"<CENTER><TABLE BORDER=2>");
   fprintf(cgiOut,"<TR><TD>�s��</TD><TD>�ϥΪ̥N��</TD><TD>�ϥΪ̼ʺ�</TD><TD>�Ӧ�</TD><TD>�ʺA</TD><TD>���m�ɶ�</TD>");
   for(i=0;i<range;i++)
   {
      uentp=user_record[i];
      fprintf(cgiOut,"<TR>");
      fprintf(cgiOut,"<TD>%d</TD>",i+1);
      fprintf(cgiOut,"<TD>%s</TD>",uentp->userid);
      fprintf(cgiOut,"<TD>%s</TD>",uentp->username);
      fprintf(cgiOut,"<TD>%s</TD>",uentp->from);
      fprintf(cgiOut,"<TD>%s</TD>",modestring(uentp->mode, uentp->destuid, 1,
                      ((uentp->in_chat) || (uentp->mode==IDLE)) ? uentp->chatid : NULL));   
      fprintf(cgiOut,"<TD>%s</TD>",idle_str( uentp )); 
      fprintf(cgiOut,"</TR>");             
   }
   fprintf(cgiOut,"</TABLE>");
   ht_end();
}
