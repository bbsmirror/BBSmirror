#include "cgic.h"

int cgiMain()
{
   cgiHeaderContentType("text/html");
   fprintf(cgiOut,"%s",cgiQueryString);
}
