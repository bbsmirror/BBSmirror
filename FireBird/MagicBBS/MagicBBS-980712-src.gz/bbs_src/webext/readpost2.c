#include "../bbs.h"
#include <stdio.h>
#define BBSHOME "/home/bbs"

void main()
{
   struct fileheader *fh;
   char *board="Talk",buf[256];
   int msgnum=10;
   FILE *fp;
   int fd;
   
   sprintf(buf,"%s/boards/%s/.DIR",BBSHOME,board);
   getrecord(buf,fh,sizeof(fh),msgnum);  
   sprintf(buf,"%s/boards/%s/%s",BBSHOME,board,fh->filename);
   if((fp=fopen(buf,"r"))==NULL)
         { printf("error opening %s\n",fh->filename);
           exit(-1);
         }
   while(fgets(buf,255,fp)!=NULL)
        printf("%s",buf);
   close(fd);
}
   
void report(char *s)
{
}
