#include "cgic.h"
#include "../bbs.h"
#include <stdio.h>
#include "config.h"
#include <string.h>
extern char BoardName[STRLEN] ;

int ht_header(char *s)
{
   cgiHeaderContentType("text/html");
   fprintf(cgiOut, "<HTML><HEAD>\n");                        
   fprintf(cgiOut, "<TITLE>%s</TITLE></HEAD>\n",s);
   fprintf(cgiOut, "<BODY>\n");                  
}         

int ht_end()
{
   fprintf(cgiOut,"</BODY></HTML>\n");
}

void ht_default_color()
{
   fprintf(cgiOut,"<BODY BGCOLOR=\"#ffffff\" TEXT=\"#000000\" LINK=\"#0000ff\" VLINK=\"#ff00ff\" ALINK=\"#ff0000\" ");
   fprintf(cgiOut,"BACKGROUND=\"http://tsunami.ml.org/graph/bkg-mbbs.gif\">");
   fprintf(cgiOut,"<FONT FACE=\"�з���\">");
}


int ht_exit(int i)
{  
   ht_end();
   exit(i);
}

int resumeuser(char *id,char *p)
{
   char buf[255];
   int fd;
   struct stat st;
   time_t now;

   sprintf(buf,"/tmp/www_%s_%s",id,p);
   if((fd=open(buf,O_RDONLY))<0)
      { fprintf(cgiOut, "�ϥΪ̻{�ҥ��ѡA�Э��sLogin.<BR>\n");
        return -1; }
        
   now=time(0);
   fstat(fd,&st);
   if(now-st.st_atime > WEB_TIMEOUT) 
      { fprintf(cgiOut, "�{���ɮ׹L���A�Э��sLogin�C<BR>\n");
        return -1; }
   
   if(read(fd,&currentuser,sizeof(currentuser))<0)
      { fprintf(cgiOut, "�{���ɮ׿��~�A�Ц^�������C<BR>\n");
        return -1; }
   close(fd);
   return 0;
}   


char *r_authstr(char *s,char *id,char *p,char *b)
{
   char *pos;
   char ch;
   char static buf[256];
   char buf2[256];
            
   pos=strstr(s,"$_auth_");
   if (pos!=NULL)
      {
         strncpy(buf,s,pos-s);
         buf[pos-s]=0;
         if(b!=NULL)
         sprintf(buf2,"id=%s&p=%s&board=%s%s",id,p,b,pos+7);
         else sprintf(buf2,"id=%s&p=%s%s",id,p,pos+7);
         strcat(buf,buf2);
         return buf; }
   else return s;
}

void resys(void)
{
   char *ptr;

   sprintf(genbuf,"%s",BBSHOME);
   chdir(genbuf);
   load_sysconf();   
   
   ptr = sysconf_str( "BBSNAME" );
   if( ptr == NULL )  ptr = "�|���R�W���կ�";
   strcpy( BoardName, ptr );
}

char *query_encode(unsigned char *src)
{
   int i=0;
   static char out[255];
   
   while(src[i]!=0)
   {
      sprintf(out+i*3,"%c%2.2x",'%',(int)src[i]);
      i++;
   }
   return out;
}

char *esc_filter(char *src)
{
   int i=0,j=0,in_esc=0;
   static char out[255];
   
   while(src[i]!=0)
   {
       if (src[i]==27 && src[i+1]=='[')
                in_esc=1;

       if (!in_esc)
               out[j++]=src[i];
       if (src[i]=='m')
                in_esc=0;   
       i++;                 
   }
   out[j]=0;
   return out;
}