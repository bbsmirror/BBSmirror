#include <stdio.h>
#include "cgic.h"
#define E_ILLINS	(0)
#define E_HALT		(1)
#define OP1             (mem[ip])
#define OP1_H           (mem[ip] >> 4 )
#define OP1_L           (mem[ip] & 0x0F)
#define OP2             (mem[ip+1])
#define OP2_H           (mem[ip+1] >> 4 )
#define OP2_L           (mem[ip+1] & 0x0F)

unsigned char mem[256];
unsigned char reg[16];
unsigned char ip;

struct FLP
{
    unsigned int mant:4;
    int exp:3;
    unsigned int sign:1;
};

void showmem(void)
{
    int i,j;

    printf("Registers:<BR>\n ");
    for(i=0;i<16;i++)
	printf("R%x ",i);
    printf("<BR>\n");
    for(i=0;i<16;i++)
	printf("%3.2x",reg[i]);

    printf("<BR>\nMemory dump:<BR>\n");
    for (i=0;i<16;i++)
     {
	printf("(%.4d):",i*16);
	for (j=0;j<16;j++)
	  { 	if (j==8) printf(" -");
		printf("%3.2x",mem[16*i+j]); }
	printf("<BR>\n");
     }
}

void excepthdr(int code)
{
    switch (code)
    {
      case E_ILLINS: printf("Illegal instruction. (ip=%d)\n",ip);
		     showmem();
		     fprintf(cgiOut,"</BODY></HTML>\n");
		     exit(-1);

      case E_HALT:   printf("HALT execution. (ip=%d)\n",ip);
		     showmem();
		     fprintf(cgiOut,"</BODY></HTML>\n");
		     exit(0);
    }
}

int cgiMain()
{
    struct FLP *fr,*f1,*f2;
    char *filename;
    char image[1000];

    int i,h,l,postive,tmp=0;
    unsigned char ch;

    ip=0;
    for (i=0;i<16;i++)
	 reg[i]=0;

   cgiFormStringNoNewlines("image", image, 1000);
   cgiHeaderContentType("text/html");
   fprintf(cgiOut,"<HTML><BODY>\n");
   i=0;
    while(image[i]!=0)
      {
       ch=toupper(image[i++]);
 	      if (ch=='\n') tmp++;
       else if (ch==';') { while((ch=image[i++]!='\n') && image[i]!=0);
			   tmp++; continue; }
       if (isspace(ch) || ch==255) continue;
	  if (ch>='0' && ch<='9')
	     h=ch-'0';
	  else if (ch>='A' && ch <='F')
	     h=ch-'A'+10;
	  else { printf("Error in image file line %d.\n",tmp+1); exit(-1);}
	 ch=toupper(image[i++]);
	  if (ch>='0' && ch<='9')
	     l=ch-'0';
	  else if (ch>='A' && ch <='F')
	     l=ch-'A'+10;
	  else { printf("Error in image file line %d.\n",tmp+1); exit(-1);}
	 mem[ip++]=(h*16+l);
      }

    printf("Image file loaded successfully.<BR>\n");
    printf("Code size = %d Bytes<BR>\n",ip);

    ip=0;
    while(1)
    {
	switch(OP1_H)
	{
	case 1:
	    reg[OP1_L]=mem[OP2];
	    break;
	case 2:
	    reg[OP1_L]=OP2;
	    break;
	case 3:
	    mem[OP2]=reg[OP1_L];
	    break;
	case 4:
	    if (OP1_L==0) reg[OP2_L]=reg[OP2_H];
	    else excepthdr(E_ILLINS);
	    break;
	case 5:
	    reg[OP1_L]=(reg[OP2_H] + reg[OP2_L]);
	    break;
	case 6:
	    f1=&reg[OP2_H];
	    f2=&reg[OP2_L];
	    fr=&reg[OP1_L];
	    h=(f1->exp ^ 0x04) & 0x07;
	    l=(f2->exp ^ 0x04) & 0x07;
	    if (h>3) h-=8;
	    if (l>3) l-=8;

	    if (h<l)
		 tmp=  ((f1->sign==0 ? 1 : -1)*f1->mant) +
			(f2->sign==0 ? 1 : -1)*(f2->mant << (l-h));
	    else tmp=  ((f2->sign==0 ? 1 : -1)*f2->mant) +
			(f1->sign==0 ? 1 : -1)*(f1->mant << (h-l));

	    fr->sign=tmp > 0 ? 0 : 1;

	    tmp=abs(tmp);
	    i=h>l ? h : l;
	    i-=abs(h-l);

	    if (tmp>(0xFF << abs(l-h))) i++;
	    while(tmp>15) { tmp >>= 1; i++; }

	    fr->exp=i;
	    fr->mant=tmp;
	    if (fr->mant != 0)
	    while( (fr->exp>-4) && (fr->mant*2<16))
		 { fr->exp--; fr->mant <<= 1; }
	    else { fr->sign=0; fr->exp=-4; }
	    fr->exp^=0x04;

	    break;
	case 7:
	    reg[OP1_L]=(reg[OP2_H] | reg[OP2_L]);
	    break;
	case 8:
	    reg[OP1_L]=(reg[OP2_H] & reg[OP2_L]);
	    break;
	case 9:
	    reg[OP1_L]=(reg[OP2_H] ^ reg[OP2_L]);
	    break;
	case 10:
	    if (OP2_H==0)
		reg[OP1_L]=( reg[OP1_L] >> (OP2_L % 8)) |
			    (reg[OP1_L] << (8-(OP2_L%8)) );
	    else excepthdr(E_ILLINS);
	    break;
	case 11:
	    if (reg[0]==reg[OP1_L]) { ip=OP2; continue; }
	    break;
	case 12:
	    excepthdr(E_HALT);
	    break;
	default:
	    excepthdr(E_ILLINS);
       }
       ip+=2;
    }
}
