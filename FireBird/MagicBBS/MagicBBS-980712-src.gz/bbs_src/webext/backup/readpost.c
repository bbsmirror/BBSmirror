#include "../bbs.h"
#include "cgic.h"
#include <stdio.h>
#include "config.h"

#define ME      "http://tsunami.ml.org/cgi-bin/readpost"
#define READPOST (0)
#define LISTDIR  (1)
extern int      cmpbnames();

int cgiMain()
{
   struct fileheader fh;
   struct boardheader bh;
   char board[20],buf[256],id[IDLEN],p[10];
   int spos=0,i,mode=LISTDIR,over=0,ri=0;
   time_t t;
   FILE *fp;
   int fd;
   struct stat st ;
   
   cgiFormStringNoNewlines("id", id, IDLEN);
   cgiFormStringNoNewlines("p", p, 10);

   cgiFormStringNoNewlines("spos", buf, 10); 
   spos=atoi(buf);                          
   if (buf[0]==0) spos=-1;

   cgiFormStringNoNewlines("read", buf, 10); 
   ri=atoi(buf);                             
      
   mode=(buf[0]==0) ? LISTDIR : READPOST; 
      
   cgiFormStringNoNewlines("board", board, 20);   
   
   sprintf(buf,"%s/boards/%s/.DIR",BBSHOME,board);
   
   if((fd=open(buf,O_RDONLY))==NULL)
                           exit(-1);
                           
   cgiHeaderContentType("text/html");
   fprintf(cgiOut, "<HTML><HEAD>\n");                        
   fprintf(cgiOut, "<TITLE>�]�k���� BBS - %s �Q�װ�</TITLE></HEAD>\n",board);
   fprintf(cgiOut, "<BODY>\n");                           

      if(resumeuser(id,p)!=0)
             ht_exit(-1);   

   sprintf(genbuf,"%s",BBSHOME);
   chdir(genbuf);
                   
   if(search_record(BOARDS, &bh, sizeof(bh), cmpbnames, board)<=0)
        { fprintf(cgiOut,"�Q�װϧ䤣��C<BR>\n");ht_exit(-1); } 
   if(!((bh.level & PERM_POSTMASK) || HAS_PERM(bh.level)))  
        { fprintf(cgiOut,"�v�������I<BR>\n");ht_exit(-1); }   

if(mode==LISTDIR)
 {  

   if(spos<0)   
      {fstat(fd,&st);
       spos=st.st_size/sizeof(fh)-60; 
       if (spos<0) spos=0; 
      }

   if(spos!=0)
      fprintf(cgiOut,"[<A HREF=\"%s?board=%s&spos=%d&id=%s&p=%s\">�^�W�@��</A>]\n",ME,board,spos>60 ? spos-60 : 0,id,p);
   fprintf(cgiOut,"[<A HREF=\"%s?f=dopost.html&board=%s&id=%s&p=%s\">�o���峹</A>]",CGI_EHTML,board,id,p);      
   fprintf(cgiOut,"<TABLE BORDER=3>\n");   
     for(i=spos;i<(60+spos);i++)
     {
        lseek(fd,i*sizeof(fh),SEEK_SET);
        if(read(fd,&fh,sizeof(fh))>0)
       {
        sscanf(fh.filename,"M.%l.A",&t);
        strncpy(buf,4+ctime(&t),6);
        buf[6]=0;
        fprintf(cgiOut,"<TR><TD>%5d</TD><TD>%s</TD><TD>%s</TD><TD><A HREF=%s?board=%s&read=%d&id=%s&p=%s>%s</A></TD></TR>\n",i+1,fh.owner, buf, ME,board,i,id,p,fh.title);
       }
       else over=1;
     }
   fprintf(cgiOut,"</TABLE>\n");
   if(read(fd,&fh,sizeof(fh))>0)
      fprintf(cgiOut,"<A HREF=%s?board=%s&spos=%d>�i�U�@��</A><BR>\n",ME,board,spos+60);     
     
 } else if(mode==READPOST)
 {
 
   lseek(fd,ri*sizeof(fh),SEEK_SET);
   read(fd,&fh,sizeof(fh));
   sprintf(buf,"%s/boards/%s/%s",BBSHOME,board,fh.filename);

   if((fp=fopen(buf,"r"))==NULL)
           exit(-1);

   while(fgets(buf,255,fp)!=NULL)
      { buf[(i=strlen(buf))> 0 ? i-1 : 0]=0;
        fprintf(cgiOut,"%s<BR>\n",buf); }

 }          
   fprintf(cgiOut,"</BODY></HTML>\n");
   close(fd);
}
