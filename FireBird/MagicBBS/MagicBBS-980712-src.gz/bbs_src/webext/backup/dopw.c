#include "../bbs.h"
#include "cgic.h"
#include <stdio.h>

#define BBSHOME "/home/bbs"
#define ME      "http://tsunami.ml.org/cgi-bin/update"
extern struct UTMPFILE *utmpshm;
extern int      cmpbnames();
extern char     BoardName[];

int cgiMain()
{
   struct fileheader fh;
   struct boardheader bh;
   struct stat st ;
   int fd;
   char buf[255],p[10],id[IDLEN],board[STRLEN],text[1000*STRLEN],os[2],title[STRLEN],
        fname[20];
   time_t now;
   FILE *fp;
   
   cgiFormStringNoNewlines("id", id, IDLEN);
   cgiFormStringNoNewlines("p", p, 10);
   cgiFormStringNoNewlines("board",board,STRLEN);
   cgiFormStringNoNewlines("title",title,STRLEN);
   cgiFormStringNoNewlines("os",os,2);
   cgiFormStringNoNewlines("text",text,1000*STRLEN); 
 
   
   ht_header("�o���峹 Posting");      
   
   if(resumeuser(id,p)!=0)
          ht_exit(-1);
             
   resys();

   strcpy(currboard,board);
   strcpy(bh.filename,board);
   if(search_record(BOARDS, &bh, sizeof(bh), cmpbnames, board)<=0)
   { fprintf(cgiOut,"�Q�װϧ䤣��C<BR>\n");ht_exit(-1); }
   
   if(!haspostperm(board) || deny_me())
   { fprintf(cgiOut,"�z�|�L�v���b���o���峹�I<BR>\n");ht_exit(-1); } 
   
   now=time(0);
   sprintf(fname,"M.%d.A",now) ;
      
   strcpy(fh.filename,fname);
   strncpy(fh.owner,id,IDLEN);
   strncpy(fh.title,title,STRLEN);
   fh.accessed[0]=0;
   if(os[0]!='Y')
   {   fh.filename[ STRLEN - 1 ] = 'L';
       fh.filename[ STRLEN - 2 ] = 'L'; }
   else
   {   fh.filename[ STRLEN - 1 ] = 'S';
       fh.filename[ STRLEN - 2 ] = 'S'; 
       outgo_post(&fh,currboard);
   }

   sprintf(buf,"%s/boards/%s/%s",BBSHOME,board,fname);
   umask( S_IRGRP | S_IROTH | S_IWOTH );
   fp=fopen(buf,"w");
   fprintf(fp,"�o�H�H�G%s (%s)\n",currentuser.userid,currentuser.username);
   fprintf(fp,"���D�G%s\n",title);
   fprintf(fp,"�o�H��: %s (%24.24s) , %s\n",BoardName,ctime(&now),os[0]=='Y' ? "��H" : "����") ;
   fprintf(fp,"\n%s\n\n--\n** Posted from Web **\n",text);
   fclose(fp);    
   sprintf(buf,"%s/boards/%s/.DIR",BBSHOME,board);
   
   if (append_record( buf, &fh, sizeof(fh)) == -1) {
   sprintf(buf, "[WEB] posting '%s' on '%s': append_record failed!",
      fh.title, currboard); 
   report(buf); }
      
   sprintf(buf,"[WEB] posted '%s' on '%s'", fh.title, currboard) ;
   report(buf) ;

   fprintf(cgiOut,"�峹�w�g���\\�o�X�I<BR>\n");                         
   ht_end();
   close(fd);
}
