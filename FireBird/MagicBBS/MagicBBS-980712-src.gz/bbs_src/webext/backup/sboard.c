#include "../bbs.h"
#include "cgic.h"
#include <stdio.h>

#define BBSHOME "/home/bbs"
#define ME      "http://tsunami.ml.org/cgi-bin/sboard"
#define READPOST "http://tsunami.ml.org/cgi-bin/readpost"

int cgiMain()
{
   struct boardheader bh;
   int i,fd;
   struct stat st ;
   char buf[255],id[IDLEN],p[10];
   time_t t;
   
   cgiFormStringNoNewlines("id", id, IDLEN);
   cgiFormStringNoNewlines("p", p, 10);
    
   ht_header("�]�k����BBS - ��ܬݪ�");      

   if(resumeuser(id,p)!=0) 
       ht_exit(-1); 

   sprintf(buf,"%s/.BOARDS",BBSHOME);
   
   if((fd=open(buf,O_RDONLY))==NULL)
                           exit(-1);

   fstat(fd,&st);                         

   fprintf(cgiOut,"<TABLE BORDER=3>\n");   
     for(i=0;i<(st.st_size/sizeof(bh));i++)
     {
        lseek(fd,i*sizeof(bh),SEEK_SET);
        if(read(fd,&bh,sizeof(bh))>0)
         if((bh.level & PERM_POSTMASK) || HAS_PERM(bh.level))
          fprintf(cgiOut,"<TR><TD>%s</TD><TD><A HREF=%s?board=%s&id=%s&p=%s>%s</A></TD><TD>
          <A HREF=mailto:%s.bbs@tsunami.ml.org>%s</A></TD></TR>\n",bh.filename,READPOST,bh.filename,id,p,bh.title+1,strtok(bh.BM," "),bh.BM);
     }
   fprintf(cgiOut,"</TABLE>\n");
   ht_end();
   close(fd);
}
