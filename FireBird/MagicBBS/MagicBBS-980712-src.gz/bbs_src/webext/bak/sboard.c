#include "../bbs.h"
#include "cgic.h"
#include <stdio.h>

#define BBSHOME "/home/bbs"
#define ME      "http://tsunami.ml.org/cgi-bin/sboard"
#define READPOST "http://tsunami.ml.org/cgi-bin/readpost"

int cgiMain()
{
   struct boardheader bh;
   int i,fd;
   struct stat st ;
   char buf[255],id[IDLEN];
   time_t t;
   
   cgiFormStringNoNewlines("id", id, IDLEN);
   cgiFormStringNoNewlines("p", buf, 10);
    
   ht_header("�]�k����BBS - ��ܬݪ�");      

   if(resumeuser(id,buf)!=0) 
       ht_exit(-1); 

   sprintf(buf,"%s/.BOARDS",BBSHOME);
   
   if((fd=open(buf,O_RDONLY))==NULL)
                           exit(-1);

   fstat(fd,&st);                         

   fprintf(cgiOut,"<TABLE BORDER=3>\n");   
     for(i=0;i<(st.st_size/sizeof(bh));i++)
     {
        lseek(fd,i*sizeof(bh),SEEK_SET);
        if(read(fd,&bh,sizeof(bh))>0)
         if((bh.level & PERM_POSTMASK) || HAS_PERM(bh.level))
          fprintf(cgiOut,"<TR><TD>%s</TD><TD><A HREF=%s?board=%s>%s</A></TD><TD>%s</TD></TR>\n",bh.filename,READPOST,bh.filename,bh.title+1,bh.BM);
     }
   fprintf(cgiOut,"</TABLE>\n");
   ht_end();
   close(fd);
}
