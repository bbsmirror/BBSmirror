#include <string.h>

char *r_authstr(char *s,char *id,char *p)
{
   char *pos;
   char ch;
   char static buf[256];
   char buf2[256];
   
   pos=strstr(s,"$_auth_");
   if (pos!=NULL) 
   {     
     strncpy(buf,s,pos-s);
     sprintf(buf2,"?id=%s&p=%s%s",id,p,pos+7);
     strcat(buf,buf2);
     return buf; }
   else return s;

}

int main(void)
{
   puts(r_authstr("http://tsunami.ml.org/cgi-bin/sboard$_auth_</A>","pig","30321"));
}
