#include "../bbs.h"
#include "cgic.h"
#include "config.h"

int cgiMain()
{
   FILE *fp;
   char buf[255],filename[50],id[IDLEN],p[10];
   
   cgiHeaderContentType("text/html");
   cgiFormStringNoNewlines("f", filename, 50);
   cgiFormStringNoNewlines("id", id, IDLEN);
   cgiFormStringNoNewlines("p", p , 10);

   if(filename[0]=='.') ht_exit(-1);
   sprintf(buf,"%s/%s",EHTML_DIR,filename);
      
   if((fp=fopen(buf,"r"))==NULL)
       { fprintf(cgiOut,"Can't open %s for read.<BR>",buf);
         return -1; }
   while(fgets(buf,255,fp)!=NULL)
        fprintf(cgiOut,"%s",r_authstr(buf,id,p));
}
