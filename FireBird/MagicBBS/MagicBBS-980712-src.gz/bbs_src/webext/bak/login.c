#include "../bbs.h"
#include "cgic.h"
#include "config.h"
#include <stdio.h>

#define ME      "http://tsunami.ml.org/cgi-bin/login"

int cgiMain()
{
   struct fileheader fh;
   char uid[IDLEN],pass[PASSLEN];
   time_t t;
   FILE *fp;
   int fd;
   struct stat st ;

   cgiFormStringNoNewlines("id", uid, IDLEN); 
   cgiFormStringNoNewlines("p", pass, PASSLEN); 
   
   cgiHeaderContentType("text/html");
   fprintf(cgiOut, "<HTML><HEAD>\n");                        
   fprintf(cgiOut, "<TITLE>�]�k���� BBS - Login</TITLE></HEAD>\n");
   fprintf(cgiOut, "<BODY>\n");                           
   sprintf(genbuf,"%s",BBSHOME);
   chdir(genbuf);
   
   load_sysconf();
   
if(uid[0]=0 || !dosearchuser( uid ) ) {
            fprintf(cgiOut, "���~���ϥΪ̥N��...\n"); ht_exit(-1);}
   else if( strcmp( uid, "guest" ) == 0 ) {
   currentuser.userlevel = 0;
   currentuser.flags[0] = CURSOR_FLAG | PAGER_FLAG;
   } 
   
   if( !checkpasswd( currentuser.passwd, pass )) {
     logattempt( currentuser.userid, "Web login");
     fprintf(cgiOut, "�K�X��J���~...\n" );
     ht_exit(-1); }
   else {
          if( !HAS_PERM( PERM_BASIC ) ) {
            fprintf(cgiOut, "���b���w�g�����A�ЦVSysop�d��"); exit(-1);}
        }                      
        
   t=time(NULL);
        
   sprintf(genbuf,"/tmp/www_%s_%d",currentuser.userid,t);
   if((fd=open(genbuf,O_CREAT | O_WRONLY,S_IRWXU))==NULL)
          { fprintf(cgiOut, "Error creating login record."); ht_exit(-1); }
   write(fd,&currentuser,sizeof(currentuser));
   fprintf(cgiOut,"�١I %s �w��Ө��]�k����<BR><BR>\n",currentuser.username);
   
   fprintf(cgiOut,"<A HREF=http://tsunami.ml.org/cgi-bin/ehtml?f=main.html&id=%s&p=%d>",currentuser.userid,t);
   fprintf(cgiOut,"�i�J�D���</A><BR>\n");
   fprintf(cgiOut,"</BODY></HTML>\n");
}
