#define WEB_TIMEOUT	(20*60)
#define BBSHOME 	"/home/bbs"
#define EHTML_DIR	"/home/www/ehtml"
#define CGI_EHTML	"http://tsunami.ml.org/cgi-bin/ehtml"
