#include "../bbs.h"
#include "cgic.h"
#include <stdio.h>

#define BBSHOME "/home/bbs"
#define ME      "http://tsunami.ml.org/cgi-bin/update"
extern struct UTMPFILE *utmpshm;

int cgiMain()
{
   struct boardheader bh;
   struct stat st ;
   int fd;
   char buf[255],p[10],id[IDLEN];
   time_t now;
   
   cgiFormStringNoNewlines("id", id, IDLEN);
   cgiFormStringNoNewlines("p", p, 10);
    
   ht_header("Update Bottom Line");      
   sprintf(genbuf,"%s",BBSHOME);
   chdir(genbuf);   
   load_sysconf();

   now=time(0);
   fprintf(cgiOut,"<META HTTP-EQUIV=\"Refresh\" content=\"60 ;URL=%s?id=%s&p=%s\">",ME,id,p);
   ht_default_color();
   fprintf(cgiOut,"<CENTER>");
   fprintf(cgiOut,"<TABLE BORDER=3>\n");   
   fprintf(cgiOut,"<TR><TD>�ɶ�:[%12.12s]</TD><TD>�ثe���W��%d�H</TD><TD>�ڬO%s</TD>",ctime(&now)+4,ulist_num(0),id);
   fprintf(cgiOut,"</TABLE>\n");
   fprintf(cgiOut,"</CENTER>");
   ht_end();
}
