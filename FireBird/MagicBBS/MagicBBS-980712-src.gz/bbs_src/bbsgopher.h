typedef struct node GOPHER;
struct node {
    char        file[81],title[71],server[41];
    int         port;
    int         position;
    GOPHER      *next;
};
