#include <stdio.h>
#include <sgtty.h>
#include <sys/stat.h>
#include "keymap.h"

struct sgttyb tty_state, tty_new;

init_tty()
{
    if( gtty( 1, &tty_state ) < 0 ) {
	fprintf( stderr, "gtty failed!\n" );
	exit( -1 );
    }
    bcopy( &tty_state, &tty_new, sizeof(tty_new) );
    tty_new.sg_flags |= RAW;
    tty_new.sg_flags &= ~(TANDEM|CBREAK|LCASE|ECHO|CRMOD);
    stty( 1, &tty_new );
}

reset_tty()
{
    stty( 1, &tty_state );
}

restore_tty()
{
    stty( 1, &tty_new );
}

clrscr()
{
    printf( "\33[2J\33[1;1H" );
    fflush( stdout );
}

clreol()
{
    printf( "\33[K" );
}

gotoxy( x, y )
{
    printf( "\33[%d;%dH", y, x );
}

igetch()
{
    char	ch;

    if( read( 0, &ch, 1 ) <= 0 )
	return -1;
    return (ch & 0xff);
}

igetkey()
{
    int		mode, ch, last;

    fflush( stdout );
    mode = 0;
    while( (ch = igetch()) != -1 ) {
	if( ch == KEY_ESC )	mode = 1;
	else if( mode == 0 )	return ch;
	else if( mode == 1 ) {
	    if( ch == '[' || ch == 'O' )	mode = 2;
	    else if( ch >= '1' && ch <= '4' )	mode = 3;
	    else	return ch;
	} else if( mode == 2 ) {
	    if( ch >= 'A' && ch <= 'D' )	return KEY_UP + ch - 'A';
	    else if( ch >= '1' && ch <= '6' )	mode = 3;
	    else	return ch;
	} else if( mode == 3 ) {
	    if( ch == '~' )	ch = KEY_HOME + last - '1';
	    return ch;
	}
	last = ch;
    }
    return -1;
}

igetstr( buf, maxlen )
char	*buf;
{
    int		ch, len = 0;

    maxlen--;
    while( 1 ) {
	switch( ch = igetkey() ) {
	    case Ctrl( 'C' ):  case Ctrl( 'D' ):  case -1:
		return -1;
	    case KEY_CR:  case KEY_LF:
		write( 1, "\n\r", 2 );
		buf[ len ] = 0;
		return len;
	    case KEY_BS:  case KEY_DEL:  case 127:
		if( len > 0 ) {
		    write( 1, "\b \b", 3 );
		    len--;
		}
		break;
	    default:
		if( ch >= ' ' && ch < 0xff && len < maxlen ) {
		    printf( "%c", ch );
		    buf[ len++ ] = ch;
		}
	}
    }
}

dashf( fname )
char	*fname;
{
    struct stat st;

    return ( stat( fname, &st ) == 0 && S_ISREG( st.st_mode ) );
}

dashd( fname )
char	*fname;
{
    struct stat st;

    return ( stat( fname, &st ) == 0 && S_ISDIR( st.st_mode ) );
}

