/*
 * keymap.h	-- define key value
 */

#ifndef _local_keymap_h
#define _local_keymap_h

#define Ctrl( ch )	(ch & 0x1f)

#define KEY_BS		8
#define KEY_TAB		9
#define KEY_CR		10
#define KEY_LF		13
#define KEY_ESC		27
#define KEY_UP		0x1001
#define KEY_DOWN	0x1002
#define KEY_RIGHT	0x1003
#define KEY_LEFT	0x1004
#define KEY_HOME	0x1005
#define KEY_INS		0x1006
#define KEY_DEL		0x1007
#define KEY_END		0x1008
#define KEY_PGUP	0x1009
#define KEY_PGDN	0x100a

#endif /*!_local_keymap_h*/
