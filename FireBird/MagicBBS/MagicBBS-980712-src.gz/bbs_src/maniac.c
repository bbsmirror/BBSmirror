/***********
  maniac.c -- ���X�S��

  ���{���|������
  �G�ФŨϥ�
 ***********/


void scroll_up(char *buffer)
{
   int in_ansi = 0, x, y;
   char now_color, tmp_color;
   char temp[24][80], color[24][80], *point;

   for(x = 0; x < 24; x++)
     for(y = 0; y < 80; y++)
        color[x][y]=7;

   for(point = buffer, x = 0, y = 0; *point; point++) {
     if(in_ansi) {
        if(*point == ';') {
           if(tmp_color / 10 == 3) {
                color[x][y] &= 0x8f;
                color[x][y] += (tmp_color % 10) << 4;
           } else if (tmp_color / 10 == 4) {
                color[x][y] &= 0xf8;
                color[x][y] += (tmp_color % 10);
           } else if (tmp_color == 1) {
                color[x][y] |= 0x8;
           } else if (tmp_color == 4) {
                color[x][y]
