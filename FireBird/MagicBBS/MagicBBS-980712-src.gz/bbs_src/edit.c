/* 
        �o�ӵ{���O�� Firebird BBS �ұM�Ϊ� Editor �A�w��U��ϥ�
        �p�G��������D�� Mail �� SmallPig.bbs@bbs.cs.ccu.edu.tw
        �άO�� 140.123.101.78(bbs.cs.ccu.edu.tw) Post ���D�C
*/

#include "bbs.h"
#include "edit.h"
extern int  RUNSH;

void vedit_key();
extern int local_article;
#ifndef VEDITOR
extern char BoardName[];
#endif
char searchtext[80];
int        marknum;
int        ismsgline;
int        tmpline;
int curr_window_line ,currln;
int redraw_everything ;
#ifdef VEDITOR
char bkfname[STRLEN];
char currfname[STRLEN];
int  bkfile=0;
#endif
/* for copy/paste */
#define CLEAR_MARK()  mark_on = 0; mark_begin = mark_end = NULL;
struct textline *mark_begin, *mark_end;
char save_title[STRLEN] ;
char save_filename[4096] ;
int in_mail ;

#ifndef VEDITOR
int
write_posts()
{
    char *ptr;
    time_t now;
    struct
    {
      char author[IDLEN + 1];
      char board[IDLEN + 1];
      char title[66];
      time_t date;
      int number;
    }      postlog;

    if(junkboard()||normal_board(currboard)!=1||!strcmp(currboard,"blame"))
        return ;
    now = time(0) ;
    strcpy(postlog.author, currentuser.userid);
    strcpy(postlog.board, currboard);
    ptr = save_title;
    if (!strncmp(ptr, "Re: ", 4))
      ptr += 4;
    strncpy(postlog.title, ptr, 65);
    postlog.date = now;
    postlog.number = 1;
    append_record(".post", &postlog, sizeof(postlog));

}
#endif


#ifndef VEDITOR
void
write_header(fp,mode)
FILE *fp ;
int mode;
{
    int  noname;
    extern char BoardName[];    
    extern struct postheader header;
    char uid[20] ;
    char uname[40] ;
    time_t now;

    now = time(0) ;
    strncpy(uid,currentuser.userid,20) ;
    uid[19] = '\0' ;
    if (in_mail)
#if defined(MAIL_REALNAMES)
      strncpy(uname,currentuser.realname,NAMELEN) ;
#else
      strncpy(uname,currentuser.username,NAMELEN) ;
#endif
    else
#if defined(POSTS_REALNAMES)
      strncpy(uname,currentuser.realname,NAMELEN) ;
#else
      strncpy(uname,currentuser.username,NAMELEN) ;
#endif
    uid[39] = '\0' ;
    save_title[STRLEN-10] = '\0' ;
    noname=seek_in_file("etc/anonymous",currboard);
    if(in_mail)
      fprintf(fp,"�H�H�H: %s (%s)\n",uid,uname) ;
    else 
    {
            if(mode==0&&!(noname&&header.chk_anony))
            {
                    write_posts();
            }
      fprintf(fp,"�o�H�H: %s (%s), �H��: %s\n",(noname&&header.chk_anony)?"Anonymous":uid,
              (noname&&header.chk_anony)?"�ڬO�ΦW�Ѩ�":uname,currboard) ;
    }
      fprintf(fp,"��  �D: %s\n",save_title) ;
      fprintf(fp,"�o�H��: %s (%24.24s)",BoardName,ctime(&now)) ;
    if(in_mail)
      fprintf(fp,"\n��  ��: %s \n",currentuser.lasthost) ;
    else 
      fprintf(fp," , %s\n",(local_article) ? "�����H��":"��H") ;
                            
      fprintf(fp,"\n");
}
#endif

#ifndef VEDITOR
void
addsignature(fp,blank)
FILE *fp;
int blank;
{
        FILE *sigfile;
        int  i,valid_ln=0;
        char tmpsig[MAXSIGLINES][256];
        char inbuf[256];
        char fname[STRLEN];

        setuserfile( fname, "signatures" );
        if ((sigfile = fopen(fname, "r"))== NULL)
          {return;}
        if ( blank ) fputs("\n", fp);
        fputs("--\n", fp);
        for (i=1; i<=(currentuser.signature-1)*MAXSIGLINES&&currentuser.signature!=1; i++) 
        {
            if (!fgets(inbuf, sizeof(inbuf), sigfile)){
            fclose(sigfile);  
            return;}
        }
        for (i=1; i<=MAXSIGLINES; i++) {
            if (fgets(inbuf, sizeof(inbuf), sigfile))
            {
                if(inbuf[0]!='\n')
                        valid_ln=i;
                strcpy(tmpsig[i-1],inbuf);
             }
            else break;
        }
        fclose(sigfile);
        for(i=1;i<=valid_ln;i++)
                fputs(tmpsig[i-1], fp);
}
#endif

#define KEEP_EDITING -2

int
deal_file(filename,saveheader)
char *filename ;
int saveheader ;
{
    if(!saveheader)
        return 0;
    clear() ;
    if(uinfo.mode == POSTING)
    {
        if(askyn("�O�_��H (Y)��H, (N)����H",!local_article)==YEA)
        {
            sprintf( genbuf, "local_article = %u", local_article );
            report( genbuf );
            local_article = 0;
        } else
            local_article = 1;
    }
    if(saveheader)
    {
        FILE *fp;
        char buf2[256+5];

        sprintf(buf2,"%s.tmp",filename);
        if(dashf(filename))
        {
                if((fp=fopen(buf2,"w"))!=NULL)
                {
                        write_header(fp,0) ;
                        b_suckinfile(fp,filename);
                        fclose(fp);
                        rename(buf2,filename);
                }
        }
    }
    return local_article;
}

#ifndef VEDITOR
int
Origin2(text)
char text[256];
{
        char tmp[STRLEN];

        sprintf(tmp,"�� �ӷ�:�E%s %s�E[FROM:",BoardName,email_domain());
        if(strstr(text,tmp))
                return 1;
        else
                return 0;
}
#endif

int
vedit(filename, saveheader)
char *filename ;
int saveheader ;
{
    struct stat st;
    time_t ptime,mtime;
    int ans;
    char buf[256];

    RUNSH=YEA;
    if(stat(filename,&st)<0)
        ptime=0;
    else
        ptime=st.st_mtime;
    switch(currentuser.editor)
    {
        case 2:
            sprintf(buf,"/usr/local/bin/rjoe %s",filename);
            break;
        case 3:
            sprintf(buf,"bin/celvis %s",filename);
            break;
        default:
            currentuser.editor=1;
            veedit(filename);
            break;
    }
    if(currentuser.editor!=1)
    {
        RUNSH=YEA;
        system(buf);
        RUNSH=NA;
    }
    if(stat(filename,&st)<0)
        mtime=0;
    else
        mtime=st.st_mtime;
    if(ptime<mtime)
    {
        ans=deal_file(filename,saveheader);
    }
    else
        ans=-1;        
    
    return ans;
}
