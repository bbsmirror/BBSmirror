/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"
#include "edit.h"
#include <sys/param.h>
#include <varargs.h>

extern char clearbuf[] ;
extern char cleolbuf[] ;
extern char scrollrev[] ;
extern char strtstandout[] ;
extern char endstandout[] ;
extern int iscolor ;
extern int clearbuflen ;
extern int cleolbuflen ;
extern int scrollrevlen ;
extern int strtstandoutlen ;
extern int endstandoutlen ;
extern int showlbar ;

#ifndef VEDITOR
#endif
extern int editansi;

extern int automargins ;
extern int dumb_term ;

#define o_clear()     output(clearbuf,clearbuflen)
#define o_cleol()     output(cleolbuf,cleolbuflen) 
#define o_scrollrev() output(scrollrev,scrollrevlen)
#define o_standup()   output(strtstandout,strtstandoutlen)
#define o_standdown() output(endstandout,endstandoutlen)

unsigned char   scr_lns=24, scr_cols ;
unsigned char   cur_ln = 0, cur_pos=0 ,cur_col = 0 ;
int             roll=0, scrollcnt ;
unsigned char   docls ;
unsigned char   downfrom ;
int             standing = NA ;
char currentbar[60];

struct screenline *big_picture = NULL ;

int
num_noans_chr(str)
char *str;
{
        int len,i,ansinum,ansi;

        ansinum=0;
        ansi=NA;
        len=strlen(str);
        for (i=0; i < len; i++)
        {
                if (str[i] == KEY_ESC)
                {
                        ansi = YEA;
                        ansinum++;
                        continue;
                }
                if (ansi)
                {
                        if (strchr("[0123456789; ", str[i]))
                        {
                                ansinum++;
                                continue;
                        }
                        else if (isalpha(str[i]))
                        {
                                ansinum++;
                                ansi = NA;
                                continue;
                        }
                        else
                                break;
                }
        }
        return len-ansinum;
}


void
init_screen(slns,scols)
int     slns, scols;
{
    register struct screenline *slp;

    scr_lns = slns ;
    scr_cols = Min(scols, LINELEN) ;
    big_picture = (struct screenline *) calloc(scr_lns,
                                               sizeof(struct screenline)) ;
    for(slns=0;slns<scr_lns;slns++) {
        slp = &big_picture[ slns ];
        slp->mode = 0 ;
        slp->len = 0 ;
        slp->oldlen = 0 ;
    }
    docls = YEA ;
    downfrom = 0 ;
    roll = 0 ;
}

void
initscr()
{
    if(!dumb_term && !big_picture)
      t_columns=WRAPMARGIN;
      init_screen(t_lines,WRAPMARGIN) ;
}

int tc_col, tc_line ;

void
rel_move(new_col,new_ln)
int     new_col,new_ln;
{
    int ochar() ;
    extern char *BC ;

    int was_col=tc_col;
    int was_ln=tc_line;
    
    if(new_ln >= t_lines  || new_col >= t_columns)
      return ;
    tc_col = new_col ;
    tc_line = new_ln ;
    if((new_col == 0) && (new_ln == was_ln+1)) {
        ochar('\n') ;
        if(was_col != 0)
          ochar('\r') ;
        return ;
    }
    if((new_col == 0) && (new_ln == was_ln)) {
        if(was_col != 0)
          ochar('\r') ;
        return ;
    }
    if(was_col == new_col && was_ln == new_ln)
      return ;
    if(new_col == was_col - 1 && new_ln == was_ln) {
        if(BC)
          tputs(BC,1,ochar) ;
        else
          ochar(Ctrl('H')) ;
        return ;
    }
    
 /*   new_col-=c_shift(new_ln,new_col);  */
    do_move(new_col,new_ln,ochar) ;
}

void
standoutput(buf,ds,de,sso,eso)
char *buf ;
int ds,de,sso,eso ;
{
    int st_start, st_end ;

    if(eso <= ds || sso >= de) {
        output(buf+ds,de-ds) ;
        return ;
    }
    st_start = Max(sso,ds) ;
    st_end = Min(eso,de) ;
    if(sso > ds)
      output(buf+ds,sso-ds) ;
    o_standup() ;
    output(buf+st_start,st_end-st_start) ;
    o_standdown() ;
    if(de > eso)
      output(buf+eso,de-eso) ;
}

void
redoscr()
{
    register int i,j ;
    int ochar() ;
    register struct screenline *bp = big_picture ;

    if(dumb_term)
      return ;
    o_clear() ;
    tc_col = 0 ;
    tc_line = 0 ;
    for(i=0;i<scr_lns;i++) {
        j = i + roll;
        while( j >= scr_lns )  j -= scr_lns;
        if(bp[j].len == 0)
            continue ;
        rel_move(0,i) ;
        if(bp[j].mode&STANDOUT)
          standoutput(bp[j].data,0,bp[j].len,bp[j].sso,bp[j].eso) ;
        else 
          output(bp[j].data,bp[j].len) ;
        tc_col+=bp[j].len ;
        if(tc_col >= t_columns) {
            if(!automargins) {
                tc_col -= t_columns ;
                tc_line++ ;
                if(tc_line >= t_lines)
                  tc_line = t_lines - 1 ;
            }  else
              tc_col = t_columns-1 ;
        }
        bp[j].mode &= ~(MODIFIED) ;
        bp[j].oldlen = bp[j].len ;
    }
    if (showlbar) output(currentbar,strlen(currentbar));
    rel_move(cur_col,cur_ln) ;
    docls = NA ;
    scrollcnt = 0 ;
    oflush() ;
}

void
refresh()
{
    register int i,j ;
    register struct screenline *bp = big_picture ;
    extern int automargins ;
    extern int scrollrevlen ;

    if(dumb_term)
      return ;
    if(num_in_buf() != 0)
      return ;
    if((docls) || (abs(scrollcnt) >= (scr_lns-3)) ) {
        redoscr() ;
        return ;
    }
    if(scrollcnt < 0) {
        if(!scrollrevlen) {
            redoscr() ;
            return ;
        }
        rel_move(0,0) ;
        while(scrollcnt < 0) {
            o_scrollrev() ;
            scrollcnt++ ;
        }
    }
    if(scrollcnt > 0) {
        rel_move(0,t_lines-1) ;
        while(scrollcnt > 0) {
            ochar('\n') ;
            scrollcnt-- ;
        }
    }
    for(i=0;i<scr_lns;i++) {
        j = i + roll;
        while( j >= scr_lns )  j -= scr_lns;
        if(bp[j].mode&REDRAW)
           { rel_move(0,i);
             o_cleol();
             output(bp[j].data,bp[j].len); 
             bp[j].mode^=REDRAW;
           }
           
        if(bp[j].mode&MODIFIED && bp[j].smod < bp[j].len) {
            bp[j].mode &= ~(MODIFIED) ;
            if(bp[j].emod >= bp[j].len)
              bp[j].emod = bp[j].len - 1 ;
            rel_move(bp[j].smod-c_shift(j,bp[j].smod),i) ;
            if(bp[j].mode&STANDOUT)
              standoutput(bp[j].data,bp[j].smod,bp[j].emod+1,
                          bp[j].sso,bp[j].eso) ;
            else 
              output(&bp[j].data[bp[j].smod],bp[j].emod-bp[j].smod+1) ;
            tc_col = bp[j].emod+1 ;
            if(tc_col >= t_columns) {
                if(automargins) {
                    tc_col -= t_columns ;
                    tc_line++ ;
                    if(tc_line >= t_lines)
                      tc_line = t_lines - 1 ;
                } else
                  tc_col = t_columns-1 ;
            }
        }
        if(bp[j].oldlen > bp[j].len) {
            rel_move(bp[j].len-c_shift(j,bp[j].len),i) ;
            o_cleol() ;
        }
        bp[j].oldlen = bp[j].len ;
    }
    rel_move(cur_col,cur_ln) ;
    oflush() ;
}

void
move(y,x)
int     y,x;
{
    cur_col = x;
    cur_ln = y;
    cur_pos = c_pos(y,x);
}

void
getyx(y,x)
int *y,*x ;
{
    *y = cur_ln ;
    *x = cur_col;
}

inline int
c_shift(int y,int x)
{
    register struct screenline *bp = big_picture ;
    int i,count=0,inesc=0;
//    y=(y+roll) % scr_lns; // �Ҽ{scroll�����p�C
        
    for(i=0;i<x;i++) 
    { 
      if (bp[y].data[i]=='\x1b') inesc=1;
      if (inesc) count++;
      if (bp[y].data[i]=='m') inesc=0;
    }
    return count;
}

inline int
c_pos(int y,int x)
{
    struct screenline *bp = &big_picture[(y+roll) % scr_lns] ;
    int i=0,count=0,inesc=0;

    while(x && (i<bp->len)) 
    {   
      if (bp->data[i]=='\x1b' && bp->data[i+1]=='[') inesc=1;
      if (inesc!=1) x--;
      if (bp->data[i]=='m') inesc=0;
      i++;
    }
    
//    { FILE *fp;
//      fp=fopen("/tmp/debug","a+");
//      fprintf(fp,"%d %d\n",y,(y+roll) % scr_lns);
//      fclose(fp);
//    }    
    return i+x;
}

void
clear()
{
    register int i ;
    register struct screenline *slp;

    if(dumb_term)
      return ;
    roll = 0 ;
    docls = YEA ;
    downfrom = 0 ;
    for(i=0 ;i<scr_lns;i++) {
        slp = &big_picture[ i ];
        slp->mode = 0 ;
        slp->len = 0 ;
        slp->oldlen = 0 ;
    }
    move(0,0);
}

void
clear_whole_line(i) 
int i;
{
    register struct screenline *slp = &big_picture[ i ];
    slp->mode = slp->len = 0;
    slp->oldlen = 79;
}

void
clrtoeol()
{
    register struct screenline *slp ;
    register int        ln;

    if(dumb_term)
      return ;
    standing = NA ;
    ln = cur_ln + roll;
    while( ln >= scr_lns )  ln -= scr_lns;
    slp = &big_picture[ ln ];
    if(cur_pos <= slp->sso)
      slp->mode &= ~STANDOUT ;
    if(cur_pos > slp->oldlen) {
        register int i ;
        for(i=slp->len;i<=cur_pos;i++)
          slp->data[i] = ' ' ;
    }
    slp->len = cur_pos ;
}

void
clrtobot()
{
    register struct screenline *slp ;
    register int        i, j;

    if(dumb_term)
      return ;
    for(i=cur_ln; i<scr_lns;i++) {
        j = i + roll;
        while( j >= scr_lns )  j -= scr_lns;
        slp = &big_picture[ j ];
        slp->mode = 0 ;
        slp->len = 0 ;
        if( slp->oldlen > 0 )  slp->oldlen = 255 ;
    }
}

void
clrnlines(int n)
{
    register struct screenline *slp ;
    register int        i, j,k;

    if(dumb_term)
      return ;
    for(i=cur_ln; i<cur_ln+n;i++) {
        slp = &big_picture[(i + roll) % scr_lns];
        slp->mode = 0;
        slp->oldlen = 255;
        slp->len = 0;
        for(k=0;k<LINELEN;k++)
           slp->data[k]=0;
    }
}

void
clrstandout()
{
    register int i ;
    if(dumb_term)
      return ;
    for(i=0;i<scr_lns;i++)
      big_picture[i].mode &= ~(STANDOUT) ;
}

static char nullstr[] = "(null)" ;

void
outc(c)
register unsigned char c ;
{
    register struct screenline *slp ;
    register unsigned char reg_col;
    static int inansi=0;

#ifndef BIT8
    c &= 0x7f ;
#endif
    if(inansi==1)
    {
        if(c=='m') inansi=0;
        if(iscolor==0) return;
        cur_col--;
    }
    if(c==KEY_ESC)
    {
        inansi=1;
        if (iscolor==0) return;
        cur_col--;
    }
    if(dumb_term) {
        if( !isprint2(c)) {
            if(c == '\n') {
                ochar('\r') ;
            } else if( c != KEY_ESC || !showansi ) {
                c = '*';
            }
        }
        ochar(c) ;
        return ;
    }
    if( 1 ) {
        register int    reg_line  = cur_ln+roll;
        register int    reg_scrln = scr_lns;

        while( reg_line >= reg_scrln )  reg_line -= reg_scrln;
        slp = &big_picture[ reg_line ] ;
    }
    reg_col = cur_pos;
    

        
    /* deal with non-printables */
    if( !isprint2(c) ) {
        if(c == '\n' || c =='\r') {  /* do the newline thing */
            if(standing) {
                slp->eso = Max(slp->eso,reg_col) ;
                standing = NA ;
            }
            if(reg_col > slp->len) {
                register int i ;
                for(i=slp->len;i<=reg_col;i++)
                    slp->data[i] = ' ' ;
            }
            slp->len = reg_col ;
            cur_col=cur_pos = 0 ;       /* reset cur_pos */
            if(cur_ln < scr_lns)
                cur_ln++ ;
            return ;
        } else if( c != KEY_ESC || !showansi ) {
            c = '*' ;  /* else substitute a '*' for non-printable */
        }
    }
    if(reg_col >= slp->len) {
        register int i ;
        for(i=slp->len;i<reg_col;i++)
            slp->data[i] = ' ';
        slp->data[reg_col] = '\0' ;
        slp->len = reg_col+1 ;
    }
    if(slp->data[reg_col] != c) {
        if((slp->mode & MODIFIED) != MODIFIED)
            slp->smod = (slp->emod = reg_col) ;
        else {
            if(reg_col > slp->emod)
                slp->emod = reg_col ;
            if(reg_col < slp->smod)
                slp->smod = reg_col ;
        }
        slp->mode |= MODIFIED ;
    }

//    if(inansi || flag)
//    {   memcpy(slp->data+reg_col,slp->data+reg_col+1,slp->len-reg_col);
//         slp->len++; }    
    
    slp->data[ reg_col ] = c ;
    reg_col++;
    if(reg_col >= scr_cols) {
        if(standing && slp->mode&STANDOUT) {
            standing = NA ;
            slp->eso = Max(slp->eso,reg_col) ;
        }
        reg_col = 0 ;
        if(cur_ln < scr_lns)
            cur_ln++ ;
    }
    cur_pos = reg_col;  /* store cur_pos back */
    cur_col++;
}

void *ccode(char *str) // ����X by Magi
{
if( strstr(str,"\x1b?")!=NULL || strstr(str,"\x1b/")!=NULL )
{
  static char *strbuf=NULL;
  static char *strbuf2=NULL;
  char format[20];
  char content[80];
  time_t now;
  struct userec *u;
  
  char *hit;
  char *s,*p,*tmp;
  int right,width=0;

  if(strbuf) free(strbuf);
  if(strbuf2) free(strbuf2);
  
  strbuf=(char *)malloc(strlen(str)+100);
  strbuf2=(char *)malloc(strlen(str)+100);    

  strcpy(strbuf,str);
  s=strbuf;
  p=strbuf2;
	while(((hit=strstr(s,"\x1b?")) !=NULL) || 
	      ((hit=strstr(s,"\x1b/")) !=NULL))
	      { *hit=0;
	        hit+=2;
	        width=0;
                while(isdigit(*hit))
                   width=width*10+(*(hit++)-'0');
                if(*hit=='>') { hit++; right=YEA; } else right=NA;
                if(width<80 && width>0)
                   sprintf(format,"%%s%%%s%d.%ds%%s",right ? "" : "-" ,width,width);
                else sprintf(format,"%%s%%s%%s");
                if(*hit=='L')
                { hit++; u=&lookupuser; } else { u=&currentuser; }
	        switch (*hit)
	        {
	          case 'n': sprintf(content,"%s",u->username); break;
	          case 'i': sprintf(content,"%s",u->userid); break;
	          case 'l': sprintf(content,"%d",u->numlogins); break;
	          case 't': now = time(0);
	                    sprintf(content,"%24s",ctime(&now));break;
	          case 'u': sprintf(content,"%d",ulist_num(0));break;
	          case 'p': sprintf(content,"%d",u->numposts); break;
	          case 'm': sprintf(content,"%d",u->magic); break;
	          case 'M': sprintf(content,"%d",countperf(u)); break;
	          case 's': sprintf(content,"%s",cstrperf(u)); break;
	          case 'e': sprintf(content,"%d",countexp(u)); break;
	          case 'E': sprintf(content,"%s",cexp(countexp(u))); break;
	          case 'v': sprintf(content,"%d",compute_user_value(u)); break;
	          case 'h': sprintf(content,"%s",u->lasthost); break;
	          case 'T': sprintf(content,"%24s",ctime(&u->lastlogin)); break;
	          case 'S': sprintf(content,"%d �� %d ��",u->stay/3600,u->stay/60 % 60); break;
	          case '$': sprintf(content,"%d",u->money); break;
	          default:  content[0]=0;
	        }
	        sprintf(p,format,s,content,hit+1);
	        tmp=p;
	        p=s;
	        s=tmp;
 	     }
      str=s;
}
   return str;
}

void
outs(str)
register char *str ;
{

    str=ccode(str);
    while(*str != '\0'){
#ifndef VEDITOR
         if(*str==''&&!iscolor){
          while(*str!='m'){
            str++;}
          str++;}else
#endif
          outc(*str++) ;}
}

void
outns(str,n)
register char *str ;
register int n ;
{
    for(;n>0;n--){
#ifndef VEDITOR
     if(*str==''&&!iscolor){
       while(*str!='m'){
           str++;n--;}
       str++;n--;}else
#endif
       outc(*str++) ;}
}


int dec[] = {1000000000,100000000,10000000,1000000,100000,10000,1000,100,10,1};
 
void
prints(va_alist)
va_dcl
{
        va_list ap ;
        register char *fmt ;
        char *bp ;
        register int i, count, hd, indx ;
        
        va_start(ap) ;
        fmt = ccode(va_arg(ap, char *)) ;
        while(*fmt != '\0')
        {
#ifndef VEDITOR
          if(*fmt==''&&!iscolor){
                while(strchr("[ 1234567890;", *fmt))
                        fmt++;
                fmt++;continue;}
#endif

        if(*fmt == '%')
            {
                int sgn = 1 ;
                int val = 0 ;
                int len,negi ;

                fmt++ ;
                while(*fmt == '-') {
                    sgn *= -1 ;
                    fmt++ ;
                }
                while(isdigit(*fmt)) {
                    val *= 10 ;
                    val += *fmt - '0' ;
                    fmt++ ;
                }
                switch(*fmt)
                  {
                    case 's':
                      bp = va_arg(ap, char *) ;
                      if(bp == NULL)
                        bp = nullstr ;
                      if(val) {
                          register int slen = strlen(bp) ;
                          if(val <= slen)
                            outns(bp,val) ;
                          else if(sgn > 0) {
                              for(slen=val-slen;slen > 0; slen--)
                                outc(' ') ;
                              outs(bp) ;
                          } else {
                              outs(bp) ;
                              for(slen=val-slen;slen > 0; slen--)
                                outc(' ') ;
                          }
                      } else outs(bp) ;
                      break ;
                    case 'd':
                      i = va_arg(ap, int) ;

                      negi = NA ;
                      if(i < 0)
                        {
                            negi = YEA ;
                            i *= -1 ;
                        }
                      for(indx=0;indx < 10;indx++)
                        if(i >= dec[indx])
                          break ;
                      if(i == 0)
                        len = 1 ;
                      else
                        len = 10 - indx ;
                      if(negi)
                        len++ ;
                      if(val >= len && sgn > 0) {
                          register int slen ;
                          for(slen = val-len;slen>0;slen--)
                            outc(' ') ;
                      }
                      if(negi)
                        outc('-') ;
                      hd = 1, indx = 0;
                      while(indx < 10)
                        {
                            count = 0 ;
                            while(i >= dec[indx])
                              {
                                  count++ ;
                                  i -= dec[indx] ;
                              }
                            indx++ ;
                            if(indx == 10)
                              hd = 0 ;
                            if(hd && !count)
                              continue ;
                            hd = 0 ;
                            outc('0'+count) ;
                        }
                      if(val >= len && sgn < 0) {
                          register int slen ;
                          for(slen = val-len;slen>0;slen--)
                            outc(' ') ;
                      }
                      break ;
                    case 'c':
                      i = va_arg(ap, int) ;
                      outc(i) ;
                      break ;
                    case '\0':
                      goto endprint ;
                    default:
                      outc(*fmt) ;
                      break ;
                  }
                fmt++ ;
                continue ;
            }
          
          outc(*fmt) ;
          fmt++ ;
      }
  endprint:
        return ;
}

void
printoeol(void)
{
   while(cur_col<79)
       outc(' ');
}

void
addch(ch)
int     ch;
{
    outc(ch) ;
}

void
scroll()
{
    if(dumb_term) {
        prints("\n") ;
        return ;
    }
    scrollcnt++ ;
    roll++;
    if( roll >= scr_lns )  roll -= scr_lns;
    move(scr_lns-1,0) ;
    clrtoeol() ;
}

void
rscroll()
{
    if(dumb_term) {
        prints("\n\n") ;
        return ;
    }
    scrollcnt-- ;
    if( roll > 0 )  roll--;
    else  roll = scr_lns - 1;
    move(0,0) ;
    clrtoeol() ;
}

void
standout()
{
    register struct screenline *slp ;
    register int        ln;

    if(dumb_term  || !strtstandoutlen)
      return ;
    if(!standing) {
        ln = cur_ln + roll;
        while( ln >= scr_lns )  ln -= scr_lns;
        slp = &big_picture[ ln ] ;
        standing = YEA ;
        slp->sso = cur_pos ;
        slp->eso = cur_pos ;
        slp->mode |= STANDOUT ;
    }
}

void
standend()
{
    register struct screenline *slp ;
    register int        ln;

    if(dumb_term || !strtstandoutlen)
      return ;
    if(standing) {
        ln = cur_ln + roll;
        while( ln >= scr_lns )  ln -= scr_lns;
        slp = &big_picture[ ln ] ;
        standing= NA ;
        slp->eso = Max(slp->eso,cur_pos) ;
    }
}

saveline(line, mode)  /* 0 : save, 1 : restore */
int line, mode;
{
    register struct screenline *bp = big_picture ;
    static char tmp[256];
    int x,y;

    switch (mode) {
        case 0 :
            strncpy(tmp/*old_line.data*/, bp[line].data, LINELEN) ;
            tmp[bp[line].len]='\0';
            break;
        case 1 :
            getyx(&x,&y);
            move(line,0);
            clrtoeol();
            prints("%s",tmp);
            move(x,y);
            refresh();
    }
} ;


void
lock_monitor()
{
    int x,y,c;
    int cy,cx;
    time_t tm;
        getyx(&cy,&cx);
        alarm(0);
        tm=time(0);
        x=tm%60;
        y=tm%12;
        c=tm%7+1;
        move(y,x);
        if(tm%2==0)
                prints("[1;3%dm�ڬO %12s[m",c,currentuser.userid);
        else
                prints("[1;3%dm�ڬO %12s[m",c,currentuser.username);
        signal(SIGALRM,lock_monitor);
        alarm(11);
        move(cy,cx);
        refresh();

}

int
lock_scr()
{
        char passbuf[STRLEN];

        modify_user_mode(LOCKSCREEN);
        clear();
        lock_monitor();
        while(1)
        {
                move(13,0);
                clrtobot();
                getdata( 13, 0, "�п�J�K�X(�ù���w): ", passbuf, PASSLEN, NOECHO,
                        NULL ,YEA);
                passbuf[8] = '\0';
                move(14,30);
                if( !checkpasswd( currentuser.passwd, passbuf )) {
                        prints( "[1;32m�K�X��J���~...[m\n" );
                        pressanykey();
                }
                else
                {
                        prints( "[1;32m�����ù���w�Ҧ�[m\n" );
                        pressanykey();
                        alarm(0);
                        break;
                }
        }
}

lbar(char *high,char *norm)
{
    int x,y;
    char tmp[60];
    static char oldbar[60];
    getyx(&x,&y);
    output(oldbar,strlen(oldbar));
    output(high, strlen(high));
    strcpy(currentbar,high);
    strcpy(oldbar,norm);
    sprintf(tmp,"\x1b[%d;%dH",x+1,y+1);
    output(tmp,strlen(tmp));    
}

struct screenline *
lineptr(line)
int line;
{
    register struct screenline *bp = big_picture ;

    return(& bp[line]);
}

savescreen(scr,mode)  /* 0 : save, 1 : restore */
struct SCRBUF *scr;
int mode;
{
    struct screenline *oldbp;

    switch (mode) {
        case 0 :
            scr->s = (struct screenline *) 
            calloc(scr_lns,sizeof(struct screenline)) ;
            memcpy(scr->s,big_picture,t_lines*sizeof(struct screenline));
            getyx(&scr->y,&scr->x);
            scr->rollx = roll;  
            break;
        case 1 :
            oldbp=big_picture;  // ������free���A�]�����٨S�]�s�ȴN�Q���T���_�C
            big_picture=scr->s;
            free(oldbp);
            roll = scrollcnt = scr->rollx;
            redoscr();
            move(scr->y,scr->x);
       }
}

save3line(line,mode)    // 980630 Magi
int line,mode;
{
    static struct screenline bufz[3];
    int i;
    
    switch(mode)
    {
        case 0:
             for(i=line;i<line+3;i++)
                memcpy(&bufz[i-line],&big_picture[(i+roll) % scr_lns],sizeof(bufz[0]));
             break;
        case 1:
             for(i=line;i<line+3;i++)
             {
                int j = (i+roll) % scr_lns;
                memcpy(&big_picture[j],&bufz[i-line],sizeof(bufz[0]));
                big_picture[j].mode|=REDRAW;
             }
             refresh();
             break;
    }        
}

void
buf2file(void)
{
           int i,j;
           FILE *fp;
           char buf[LINELEN+1];
           char ch=0;
           struct SCRBUF scrbuf;
           
           register struct screenline *bp=NULL;

           savescreen(&scrbuf,0);
           move(1,0);
           clrtoeol();
           prints("�аݭn�s�J�X���Ȧs�� (0-7) :");          
           refresh(); 

           while(ch<'0' || ch>'7')
               ch=igetch();
           sprintf(buf,"/tmp/%s_clip_%c",currentuser.userid,ch);  
           savescreen(&scrbuf,1);
           bp=big_picture;
           fp=fopen(buf,"w");
           for(i=0;i<t_lines;i++)
           {
              j=(i+roll) % scr_lns;
              strncpy(buf, bp[j].data, LINELEN) ;
              buf[bp[j].len]='\n';
              buf[bp[j].len+1]=0;
              fputs(buf,fp);
           }
           fclose(fp); 
}
