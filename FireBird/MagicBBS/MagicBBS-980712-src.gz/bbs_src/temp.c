
int
getdata(line, col, prompt, buf, len, echo,nouse,clearlabel)
int     line,   col,    len,    echo, clearlabel;
int     nouse;
char    *prompt,        *buf;
{
        int     i,ch,clen = 0,curr = 0,x,y;
        char    tmp[STRLEN];
        extern unsigned char scr_cols ;
        extern int RMSG;

        if (clearlabel==YEA)
        {
                memset(buf,0, sizeof(buf));
        }
        move(line, col);
        
        if (prompt)
                prints("%s", prompt);
               
        y = line;
        col+= (prompt == NULL) ? 0 : num_noans_chr(prompt);
//        x = col; 
        getyx(&y,&x);       

        clen = strlen(buf);
        curr = (clen >= len) ? len-1: clen;
        buf[curr]='\0';
        
        prints("%s", buf); 
        
        if (dumb_term||echo==NA)
        {
                while ((ch = egetch()) != '\r')
                {
                        if (ch == '\n')
                                break;
                        if (ch == '\177' || ch == Ctrl('H'))
                        {
                                if (clen == 0)
                                {
                                        continue;
                                }
                                clen--;
                                ochar(Ctrl('H'));
                                ochar(' ');
                                ochar(Ctrl('H'));
                                continue;
                        }
                        if (!isprint2(ch))
                        {
                                continue;
                        }
                        if (clen >= len-1)
                        {
                                continue;
                        }
                        buf[clen++] = ch;
                        if (echo)
                                ochar(ch);
                        else
                                ochar('*');
                }
                buf[clen] = '\0';
                prints("\n");
                oflush();
                return clen;
        }
        else {
            getyx(&y, &x);
            standout();
            for (i = len-1; i; i--)
             outc(' ');
            standend(); 
            }
             
        
        clrtoeol();
        move(y,x);
        while (1)
        {
                if((uinfo.in_chat == YEA||uinfo.mode==TALK )&& RMSG==YEA)
                {
                        refresh();
                }
                ch = egetch();
                if (ch == '\n'||ch == '\r')
                        break;
                if (ch == '\177' || ch == Ctrl('H'))
                {
                        if (curr == 0)
                        {
                                continue;
                        }
                        strcpy(tmp, &buf[curr]);
                        buf[--curr] = '\0';
                        (void)strcat(buf, tmp);
                        clen--;
                        move(y, x);
                        standout();
                        prints("%s", buf);
                        for(i=strlen(buf)+1;i<len;i++)
                           outc(' ');
                        standend();

                        move(y, x + curr);
                        continue;
                }
                if (ch == KEY_DEL)
                {
                        if (curr >= clen)
                        {
                                curr = clen;
                                continue;
                        }
                        strcpy(tmp, &buf[curr+1]);
                        buf[curr] = '\0';
                        (void)strcat(buf, tmp);
                        clen--;
                        move(y, x);
                        
                        standout();
                        prints("%s", buf);
                        for(i=strlen(buf)+1;i<len;i++)
                           outc(' ');
                        standend();   

                        move(y, x + curr);
                        continue;
                }
                if (ch == KEY_LEFT)
                {
                        if (curr == 0)
                        {
                                continue;
                        }
                        curr--;
                        move(y, x + curr);
                        continue;
                }
                if(ch==Ctrl('E') || ch==KEY_END)
                {
                        curr = clen;
                        move(y, x + curr);
                        continue;
                }
                if(ch==Ctrl('A') || ch== KEY_HOME)
                {
                        curr = 0;
                        move(y, x + curr);
                        continue;
                }
                if (ch == KEY_RIGHT)
                {
                        if (curr >= clen)
                        {
                                curr = clen;
                                continue;
                        }
                        curr++;
                        move(y, x + curr);
                        continue;
                }
                if (!isprint2(ch))
                {
                        continue;
                }

                if (x+clen >= scr_cols || clen >= len-1)
                {
                        continue;
                }

                if (!buf[curr])
                {
                        buf[curr + 1] = '\0';
                        buf[curr] = ch;
                }
                else
                {
                        strncpy(tmp, &buf[curr], len);
                        buf[curr] = ch;
                        buf[curr + 1] = '\0';
                        strncat(buf, tmp, len - curr);
                }
                curr++;
                clen++;
                move(y, x);
                prints("%s", buf);
                move(y, x + curr);
        }
        buf[clen] = '\0';
        if(echo)
        {
                move(y, x);
                prints("%s", buf);
        }
        prints("\n");
        refresh();
        return clen;
}
