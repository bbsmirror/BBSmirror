/*****************************************************************
 * Game Name   : BlackJack (21 �I)
 * Ideal Design: SiEpthero (BBS site: 140.116.96.199)
 * Code  Design: Richard
 * E-mail      : Richard.bbs@english.nccu.edu.tw
 *
 * If there is any question about the game, please mail to me.
 *****************************************************************/

#include "bbs.h"

extern char BoardName[];

typedef struct HAND {
    int card[5];
    int num;
} HAND;

HAND player, dealer;
int  bet = 0, topCard = 0;

int
iValue(card)
int card;
{
  int value;

  value = card %13;
  return (value>10||value==0) ? 10: value;
}

/*
 * Black Jack := Two card with 21 points
 **/
int
isBlackJack(p)
HAND p;
{
  if(p.num==2) {
    if(((iValue(p.card[0]) ==  1) && (iValue(p.card[1]) == 10)) ||
       ((iValue(p.card[0]) == 10) && (iValue(p.card[1]) ==  1)) )
return 1;
  }
  return 0;
}

/*
 * Super BlackJack := SA & SJ
 **/
int
isSBlackJack(p)
HAND p;
{
  if(p.num==2) {
    if(((p.card[0] == 40) && (p.card[1] == 50)) ||
       ((p.card[0] == 50) && (p.card[1] == 40)) )
return 1;
  }
  return 0;
}

/*
 * Triple Senven := ������
 **/
int
isTripleSeven(p)
HAND p;
{
  if(p.num==3) {
    if((iValue(p.card[0])==7)&&(iValue(p.card[1])==7)&&(iValue(p.card[2])==7))
return 1;
  }
  return 0;
}

/*
 * Six-Seven-Eight := ������
 **/
int
isSSE(p)
HAND p;
{
  if(p.num==3) {
    if((iValue(p.card[0])==6 && iValue(p.card[1])==7 && iValue(p.card[2])==8)||
       (iValue(p.card[0])==6 && iValue(p.card[1])==8 && iValue(p.card[2])==7)||
       (iValue(p.card[0])==7 && iValue(p.card[1])==6 && iValue(p.card[2])==8)||
       (iValue(p.card[0])==7 && iValue(p.card[1])==8 && iValue(p.card[2])==6)||
       (iValue(p.card[0])==8 && iValue(p.card[1])==6 && iValue(p.card[2])==7)||
       (iValue(p.card[0])==8 && iValue(p.card[1])==7 && iValue(p.card[2])==6))
return 1;
  }
  return 0;
}

int
bestScore(p, hideFirstCard)
int hideFirstCard;
HAND p;
{
  int i, points=0;
  int haveAce= 0;

  i= (hideFirstCard)? 1: 0;

  for(; i<p.num; i++) {
    points+=iValue(p.card[i]);
    if(iValue(p.card[i]) == 1) haveAce = 1;
  }
  if(haveAce) {
    if(points+10 < 22) points+=10;
  }
  return points;
}


void
shuffle(cards)
int cards[52];
{
  int i, j, k, card_temp;

  /* Randomly exchange two cards int the deck */
  for(i=0; i<52; i++) {
    j = rand() % 52;
    k = rand() % 52;
    card_temp = cards[j];
    cards[j]  = cards[k];
    cards[k]  = card_temp;
  }
  topCard = 0;
}

void
addCard(cards,isDealer)
int isDealer;
int cards[52];
{
  int count;

  if(isDealer) {
    count = dealer.num;
    if(dealer.num >=5)
return;
    dealer.num++;
    dealer.card[count] = cards[topCard];
  }
  else {
    count = player.num;
    if(player.num >=5)
return;
    player.num++;
    player.card[count] = cards[topCard];
  }
  topCard++;
}

int
underMax(p)
HAND p;
{
  return (bestScore(p, 0)<22);
}

int
busted(p)
HAND p;
{
  return (!underMax(p));
}


/*
 * Show single card picture
 **/
void
showPicture(isDealer, turn, hideCard)
int isDealer, turn, hideCard;
{
  int card, beginL;
  char test[5];
  char *suit[4] = {"��","��","��","��"};
  char *num[13] = {"��","��","��","��","��","��","��",
                   "��","��","��","10","��","��"};


  card =(isDealer)? dealer.card[turn]: player.card[turn];
  beginL=(isDealer)? 2: 12;
  move(beginL, turn*4);
  outs("�~�w�w�w��");
  move(beginL+1, turn*4);
  prints("�x%2s    �x", (hideCard)? "  ": num[(int)(card%13)]);
  move(beginL+2, turn*4);
  prints("�x%2s    �x", (hideCard)? "  ": suit[(int)((card-1)/13)]);
  move(beginL+3, turn*4);
  outs("�x      �x");
  move(beginL+4, turn*4);
  outs("�x      �x");
  move(beginL+5, turn*4);
  outs("�x      �x");
  move(beginL+6, turn*4);
  outs("���w�w�w��");
}

/*
 * Show all the user cards
 **/
void
showCard(isDealer, hideFirstCard)
int isDealer, hideFirstCard;
{
  int i=0;

  if(hideFirstCard) {
    showPicture(isDealer, 0, 1);
    i=1;
  }

  if(isDealer) {
    for(; i<dealer.num; i++)
showPicture(1, i, 0);
    move(9,0);
    clrtoeol();
    prints("[1;32m�I��: [1;33m%d[m", bestScore(dealer, hideFirstCard));
  }
  else {
    for(; i<player.num; i++)
showPicture(0, i, 0);
    move(11,0);
    clrtoeol();
    prints("[1;32m�I��: [1;33m%d[m", bestScore(player, 0));
  }
}

/*
 * Deliver two cards when game start
 **/
void
initialDeal(cards)
int cards[52];
{
  int i;

  for(i=0; i<2; i++) {
    addCard(cards, 0);
    addCard(cards, 1);
  }

  showCard(0, 0);
  showCard(1, 1);
}

void
showMoneyBar(bet)
int bet;
{
  move(19,0);
  clrtoeol();
  prints("[1;37;44m�A�{���{��: [36m%-18d[37m��`���B: [36m%-38d[m",
  currentuser.money, bet);
}

/*
 * Show the win message
 **/
void
showWin(isDealer, flag)
int isDealer, flag;
{
  char msg[11];
  int beginL;

  beginL = (isDealer)? 5: 15;
  switch(flag) {
  case 1:
    strcpy(msg, "�³ǧJ");
    break;
  case 2:
    strcpy(msg, "�W�Ŷ³ǧJ");
    break;
  case 3:
    strcpy(msg ,"�T�i�C");
    break;
  case 4:
    strcpy(msg ,"���C�K");
    break;
  case 5:
    strcpy(msg ,"�L����");
    break;
  default:
    strcpy(msg ,"��Ĺ�F");
  }
  move(beginL,3);
  prints("[1;33;41m%s[m", msg);
  move(21,0);
  if(isDealer)
    prints("[1;33;41m�A��F~~~ �Ȩ�S��![m");
  else
    prints("[1;33;41m%s !!! �o���� %d[m", msg, bet);
}

int
playerWin(flag)
int flag;
{
  switch(flag) {
  case 1:
    bet*=3;/* BlackJack */
    break;
  case 2:
    bet*=20;/* Super BlackJack */
    break;
  case 3:/* 777 */
    bet*=7;
    break;
  case 4:/* 678 */
    bet*=5;
    break;
  case 5:/* Have more than Five cards */
    bet*=4;
    break;
  default:/* The case that points is bigger than dealer */
    bet*=2;
  }
  showWin(0, flag);
  return 0;
}

int
dealerWin(flag)
int flag;
{
  showWin(1, flag);
  bet = 0;
  return 0;
}

/*
 * Item request for player get card
 **/
int
playerTakesAHit()
{
  int get;

  move(20, 0);
  clrtoeol();
  refresh();
  outs("[0;36m(y)�ɵP  (n) ���ɵP (d) ��`�[��[m");
  while(1) {
    get=igetch();
    if(get == 'y' || get == 'Y')
return 'y';
    else if(get == 'n' || get == 'N')
return 'n';
    else if(get == 'd' || get == 'D') {
    reload_mg();
if(currentuser.money >= bet) {
    demoney(bet);
    bet*=2;
    showMoneyBar(bet);
}
return 'd';
    }
    else
continue;
  }
}

/*
 * Main crontol procedur
 **/
int
blackjack_game()
{
  int i, key, cards[52];

  for(i=0; i<52; i++) cards[i] = i+1;

  srand(time(0));
  shuffle(cards);
  initialDeal(cards);
  if(isSBlackJack(player))
    return playerWin(2);
  else if(isBlackJack(player))
    return playerWin(1);
  else {
    while(underMax(player)) {
key = playerTakesAHit();
if(key =='y' || key == 'd') {
    addCard(cards, 0);
    showCard(0, 0);
}
if(isTripleSeven(player))
    return playerWin(3);
else if(isSSE(player))
    return playerWin(4);
else if(underMax(player) && player.num == 5)
    return playerWin(5);

if(key == 'd' || key == 'n') break;
    }

    if(busted(player)) {
showCard(1, 0);
return dealerWin(0);
    }
    else {
while(underMax(dealer) && bestScore(dealer,0) < bestScore(player,0)) {
  addCard(cards, 1);
  if(dealer.num == 5 && !busted(dealer)) {
    showCard(1,0);
    return dealerWin(5);
  }
}
        showCard(1, 0);
    }

    if(busted(dealer)) return playerWin(0);
    else return dealerWin(0);
  }
}

/*
 * Maximun of 10000 bet
 **/
placeBet(bound)
int bound;
{
  char msg[40], buf[7];

  while(1) {
    move(20,0);
    clrtobot();
    refresh();
    sprintf(msg, "�n�U�`�h�֩O(�W��%d)?�Ϋ� Enter ���}", bound);
    getdata(20, 0, msg, buf, 6, DOECHO,NULL,YEA);
    bet = atoi(buf);
    if(bet <=bound) break;
  }

  bet = (bet < 0) ? 0 : bet;
  reload_mg();
  if ((bet > currentuser.money)||(currentuser.money == 0)) {
    (msg,"�{������ !!!");
    bet = 0;
  }
  else
    demoney(bet);
}

void
bj_main()
{
  int i;
  char msg[80];

//  setutmpmode(JACK);
  while(1) {
    /* Initialize value*/
    bet = 0;
    player.num = 0;
    dealer.num = 0;
    topCard = 0;
    for(i=0; i<5; i++) {
player.card[i] = -1;
dealer.card[i] = -1;
    }

    clear();
    showtitle("�W�Ŷ³ǧJ", BoardName);
    move(19,0);
    clrtoeol();
    prints("[1;37;44m�A�{���{��: [36m%-18d[m", currentuser.money);
    placeBet(5000);

    if(bet==0) {
break;
    }

    showMoneyBar(bet);
    blackjack_game();
    /*cuser.playnum++;*/
    inmoney(bet);
    pressanykey(NULL);
  }
}
