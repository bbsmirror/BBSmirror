/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"

extern time_t   login_start_time;
char *genpasswd() ;
char    *sysconf_str();

void
disply_userinfo( u, real )
struct userec *u ;
int     real;
{
    struct stat st;
    int         num, diff;
    int         exp;
    
    clear();
    move(real==1?2:3,0);
    clrtobot();
    prints("�z���N��     : %s\n", u->userid);
    prints("�z���ʺ�     : %s\n", u->username);
    prints("�u��m�W     : %s\n", u->realname);
    prints("�~�����}     : %s\n", u->address);
    prints("�q�l�l��H�c : %s\n", u->email);
    if( real ) {
        prints("�u�� E-mail  : %s\n", u->termtype + 16 );
        prints("Ident ���   : %s\n", u->ident );
    }
    prints("�׺ݾ��κA   : %s\n", u->termtype );
    prints("���U���     : %s", ctime( &u->firstlogin));
    prints("�̪���{��� : %s", ctime( &u->lastlogin));
    if( real ) {
        prints("�̪���{���� : %s\n", u->lasthost );
    }
    prints("�W������     : %d ��\n", u->numlogins);
    if( real ) {
        prints("�峹�ƥ�     : %d / %d (Board/1Discuss)\n",
           u->numposts, post_in_tin( u->userid ));
    }
        exp=countexp(u);
        prints("�g���       : %d(%s)\n",exp,cexp(exp));
        exp=countperf(u);
        prints("�]�k�O       : %d(%s)\n",exp,cstrperf(u));
        prints("�W���`�ɼ�   : %d �p�� %d ����\n",u->stay/3600,(u->stay/60)%60);
    sprintf( genbuf, "mail/%c/%s/%s", toupper(u->userid[0]),u->userid, DOT_DIR );
    if( stat( genbuf, &st ) >= 0 )
        num = st.st_size / (sizeof( struct fileheader ));
    else
        num = 0;
    prints("�p�H�H�c     : %d ��\n", num );

    if( real ) {
        strcpy( genbuf, "bTCPRp#@XWBA#VS-DEM1234567890" );
        for( num = 0; num < 32; num++ )
            if( !(u->userlevel & (1 << num)) )
                genbuf[num] = '-';
        genbuf[num] = '\0';
        prints("�ϥΪ��v��   : %s\n", genbuf );
    } else {
        diff = (time(0) - login_start_time) / 60;
        prints("���d����     : %d �p�� %02d ��\n", diff / 60, diff % 60 );
        prints("�ù��j�p     : %dx%d\n", t_lines, t_columns );
    }
    prints("\n");
    if( u->userlevel & PERM_LOGINOK ) {
        prints("  �z�����U�{�Ǥw�g����, �w��[�J����.\n");
    } else if( u->lastlogin - u->firstlogin < 3 * 86400 ) {
        prints("  �s��W��, �о\\Ū Announce �Q�װ�.\n" );
    } else {
        prints("  ���U�|�����\\, �аѦҥ����i���e������.\n");
    }
}


int
uinfo_query( u, real, unum )
struct userec *u ;
int     real, unum;
{
    struct userec       newinfo;
    char        ans[3], buf[ STRLEN ],*emailfile,genbuf[STRLEN];
    int         i, fail = 0 ,netty_check  = 0;
    FILE        *fin, *fout,*dp;
    time_t      code;

    memcpy( &newinfo, u, sizeof(currentuser));
    getdata( t_lines-1, 0, real ?
        "�п�� (0)���� (1)�ק��� (2)�]�w�K�X (3) �� ID ==> [0]" :
        "�п�� (0)���� (1)�ק��� (2)�]�w�K�X (3)�]�w�s�边 ==> [0]",
        ans, 2, DOECHO, NULL,YEA);
    clear();
    refresh();

    i = 3;
    move( i++, 0 );
    if(ans[0]!='3'||real)
        prints("�ϥΪ̥N��: %s\n", u->userid );

    switch( ans[0] ) {
        case '1':
            move( 1, 0 );
            prints("�гv���ק�,������ <ENTER> �N���ϥ� [] ������ơC\n");

            sprintf( genbuf, "�ʺ� [%s]: ", u->username );
            getdata( i++, 0, genbuf, buf, NAMELEN, DOECHO, NULL ,YEA);
            if( buf[0] ) strncpy( newinfo.username, buf, NAMELEN );
            if(!real && buf[0]) strncpy(uinfo.username,buf,40);            

            sprintf( genbuf, "�u��m�W [%s]: ", u->realname );
            getdata( i++, 0, genbuf, buf, NAMELEN, DOECHO, NULL,YEA);
            if( buf[0] ) strncpy( newinfo.realname, buf, NAMELEN );

            sprintf( genbuf, "�~���a�} [%s]: ", u->address );
            getdata( i++, 0, genbuf, buf, STRLEN, DOECHO, NULL,YEA);
            if( buf[0] ) strncpy( newinfo.address, buf, NAMELEN );

            sprintf( genbuf, "�q�l�H�c [%s]: ", u->email );
            getdata( i++, 0, genbuf, buf, STRLEN, DOECHO, NULL,YEA);
            if ( buf[0] )
            { 
                 netty_check = 1;
                 strncpy( newinfo.email, buf, STRLEN );
                 
            }
            sprintf( genbuf, "�׺ݾ��κA [%s]: ", u->termtype );
            getdata( i++, 0, genbuf, buf, 16, DOECHO, NULL ,YEA);
            if( buf[0] ) strncpy( newinfo.termtype, buf, 16 );

        if( real ) {
            sprintf( genbuf, "�u��Email[%s]: ", u->termtype+16 );
            getdata( i++, 0, genbuf, buf, STRLEN, DOECHO, NULL ,YEA);
            if( buf[0] ) strncpy( newinfo.termtype+16, buf, STRLEN-16 );

            sprintf( genbuf, "�W�u���� [%d]: ", u->numlogins );
            getdata( i++, 0, genbuf, buf, 16, DOECHO, NULL ,YEA);
            if( atoi( buf ) > 0 ) newinfo.numlogins = atoi( buf );

            sprintf( genbuf, "�峹�ƥ� [%d]: ", u->numposts );
            getdata( i++, 0, genbuf, buf, 16, DOECHO, NULL ,YEA);
            if( atoi( buf ) > 0 ) newinfo.numposts = atoi( buf );

            sprintf( genbuf, "�ʧO [%d]: ", u->sex );
            getdata( i++, 0, genbuf, buf, 2, DOECHO, NULL ,YEA);
            if( atoi( buf ) > 0 ) newinfo.sex = atoi( buf );      
		
	    sprintf( genbuf, "�]�k�O�[�I [%d]: ", u->addmagic );
            getdata( i++, 0, genbuf, buf, 4, DOECHO, NULL ,YEA);
            newinfo.addmagic = atoi( buf ); 

	    sprintf( buf, "%d", u->magic );
            getdata( i++, 0, "�]�k�O:" , buf, 10, DOECHO, NULL ,NA);
            newinfo.magic = atoi( buf );                                                      

	    sprintf( buf, "%d", u->money );
            getdata( i++, 0, "����:" , buf, 10, DOECHO, NULL ,NA);
            newinfo.money = atoi( buf ); 
            
	    sprintf( buf, "%d", u->bank );
            getdata( i++, 0, "�s��:" , buf, 10, DOECHO, NULL ,NA);
            newinfo.bank = atoi( buf );             

	    sprintf( buf, "%d", u->card );
            getdata( i++, 0, "�d��" , buf, 10, DOECHO, NULL ,NA);
            newinfo.card = atoi( buf );             
        }

            break;
        case '2':
            if( ! real ) {
                getdata(i++,0,"�п�J��K�X: ",buf,PASSLEN,NOECHO,NULL,YEA);
                if( *buf == '\0' || !checkpasswd( u->passwd, buf )) {
                    prints("\n\n�ܩ�p, �z��J���K�X�����T�C\n");
                    fail++;
                    break;
                }
            }
            getdata(i++,0,"�г]�w�s�K�X: ",buf,PASSLEN,NOECHO,NULL,YEA);
            if( buf[0] == '\0' ) {
                prints("\n\n�K�X�]�w����, �~��ϥ��±K�X\n");
                fail++;
                break;
            }
            strncpy(genbuf,buf,PASSLEN) ;

            getdata(i++,0,"�Э��s��J�s�K�X: ",buf,PASSLEN,NOECHO,NULL,YEA);
            if(strncmp(buf,genbuf,PASSLEN)) {
                prints("\n\n�s�K�X�T�{����, �L�k�]�w�s�K�X�C\n");
                fail++;
                break;
            }
            buf[8] = '\0';
            strncpy( newinfo.passwd, genpasswd( buf ), PASSLEN );
            break;
        case '3':
/*            if( ! real ) {
                currentuser.notemode=-1;
                defnotepad();
                clear();
                return 0;
                
            }*/
            if(!real)
            {
                    int editornum;
                    sprintf( genbuf, "�]�w�s�边 (1)BBS (2)joe (3)vi ? [%d]: ", u->editor );
                    getdata( i++, 0, genbuf, buf, 16, DOECHO, NULL ,YEA);
                    editornum=atoi( buf );
                    if( editornum >=1&&  editornum<=3 ) newinfo.editor = editornum;
            }else
            {
            getdata(i++,0,"�s���ϥΪ̥N��: ",genbuf,IDLEN,DOECHO,NULL,YEA);
            if(*genbuf != '\0') {
                if(getuser(genbuf)) {
                    prints("\n���~! �w�g���P�� ID ���ϥΪ�\n") ;
                    fail++;
                } else {
                    strncpy(newinfo.userid, genbuf,IDLEN+2) ;
                }
            }
            }
            break;
        case '4':
            if(!real)
            {
                    int editornum;
                    sprintf( genbuf, "�]�w�s�边 (1)BBS (2)joe (3)vi ? [%d]: ", u->editor );
                    getdata( i++, 0, genbuf, buf, 16, DOECHO, NULL ,YEA);
                    editornum=atoi( buf );
                    if( editornum >=1&&  editornum<=3 ) newinfo.editor = editornum;
            }
            else
            {
                        clear();
                        return 0;
            }
            break;            
        default:
            clear();
            return 0;
    }
    if( fail != 0 ) {
        pressreturn();
        clear();
        return 0;
    }
    getdata(t_lines-1,0,"�T�w�n���ܶ�?  (Yes or No) [N]: ",ans,2,DOECHO,NULL,YEA);
    if( *ans == 'y' || *ans == 'Y' ) {
       if(real)
       {
        char        secu[STRLEN];
        sprintf(secu,"�ק� %s ���򥻸�ƩαK�X�C",u->userid);
        securityreport(secu);
       }
        if( strcmp( u->userid, newinfo.userid ) ) {
            char src[ STRLEN ], dst[ STRLEN ];

            sprintf( src, "mail/%c/%s",toupper(u->userid[0]), u->userid );
            sprintf( dst, "mail/%c/%s",toupper(newinfo.userid[0]), newinfo.userid );
            rename( src, dst );
            sethomepath( src, u->userid );
            sethomepath( dst, newinfo.userid );
            rename( src, dst );
            sprintf(src,"tmp/email_%s",u->userid);
            unlink(src);
            setuserid( unum, newinfo.userid );
        }
/* added by netty to automatically send a mail to new user. */

if ((netty_check == 1))
{
 if((strchr( newinfo.email, '@' ) != NULL ) &&
    (!strstr( newinfo.email, "@firebird.cs") ) &&
    (!strstr( newinfo.email, "@bbs.") ) &&
    (!invalidaddr(newinfo.email))&&
    (!strstr( newinfo.email, ".bbs@") )) {
if( (emailfile = sysconf_str( "EMAILFILE" )) != NULL )
{
           code=(time(0)/2)+(rand()/10);
           sethomefile(genbuf,u->userid,"mailcheck");
           if((dp=fopen(genbuf,"w"))==NULL)
           {
                fclose(dp);
                return;
           }
           fprintf(dp,"%9.9d\n",code);
           fclose(dp);
sprintf( genbuf, "/usr/lib/sendmail -f SYSOP.bbs@%s %s ", 
email_domain(), newinfo.email );
fout = popen( genbuf, "w" );
fin  = fopen( emailfile, "r" );
if (fin == NULL || fout == NULL) return -1;
fprintf( fout, "Reply-To: SYSOP.bbs@%s\n", email_domain());
fprintf( fout, "From: SYSOP.bbs@%s\n",  email_domain() ); 
fprintf( fout, "To: %s\n", newinfo.email);
fprintf( fout, "Subject: @%s@[-%9.9d-]firebird mail check.\n", u->userid,code );
fprintf( fout, "X-Forwarded-By: SYSOP \n" );
fprintf( fout, "X-Disclaimer: None\n");
fprintf( fout, "\n");
fprintf(fout,"�z���򥻸�Ʀp�U�G\n",u->userid);
fprintf(fout,"�ϥΪ̥N���G%s (%s)\n",u->userid,u->username);
fprintf(fout,"�m      �W�G%s\n",u->realname);
fprintf(fout,"�W����m  �G%s\n",u->lasthost);
fprintf(fout,"�q�l�l��  �G%s\n\n",u->email);
fprintf(fout,"�˷R�� %s(%s):\n",u->userid,u->username);

while (fgets( genbuf, 255, fin ) != NULL ) {
        if (genbuf[0] == '.' && genbuf[ 1 ] == '\n')
                fputs( ". \n", fout );
        else fputs( genbuf, fout );
}
fprintf(fout, ".\n");                                    
fclose( fin );
pclose( fout );                                     
}
}else
{
   if(sysconf_str( "EMAILFILE" )!=NULL)
   {
        move(t_lines-5,0);
        prints("\n�A���q�l�l��a�} �i[1;33m%s[m�j\n",newinfo.email);
        prints("�ëD Unix �b���A�t�Τ��|�뻼�����T�{�H�A�Ш�[1;32m�u��c[m���ק�..\n");
        pressanykey();
   }
}
}
        memcpy( u, &newinfo, sizeof(newinfo) );
        set_safe_record();
        substitute_record( PASSFILE, &newinfo, sizeof(newinfo), unum );
    }
    clear();
    return 0;
}

void
x_info()
{
    modify_user_mode( GMENU ); 
    disply_userinfo( &currentuser, 1 );
    if (!strcmp("guest", currentuser.userid)) {
        pressreturn();
        return;
    }
    uinfo_query( &currentuser, 0, usernum );
}

void
getfield( line, info, desc, buf, len )
int     line, len;
char    *info, *desc, *buf;
{
    char        prompt[ STRLEN ];

    sprintf( genbuf, "  ����]�w: %-46.46s (%s)", buf, info );
    move( line, 0 );
    prints( genbuf );
    sprintf( prompt, "  %s: ", desc );
    getdata( line+1, 0, prompt, genbuf, len, DOECHO, NULL ,YEA);
    if( genbuf[0] != '\0' ) {
        strncpy( buf, genbuf, len );
    }
    move( line, 0 );
    clrtoeol();
    prints( "  %s: %s\n", desc, buf );
    clrtoeol();
}

void
x_fillform()
{
    char        rname[ NAMELEN ], addr[ STRLEN ];
    char        phone[ STRLEN ], career[ STRLEN ],birth[ STRLEN];
    char        ans[5], *mesg, *ptr;
    FILE        *fn;
    time_t      now;

    modify_user_mode(NEW);
    move( 3, 0 );
    clrtobot();
    if (!strcmp("guest", currentuser.userid)) {
        prints( "��p, �Х� new �ӽФ@�ӷs�b����A��ӽЪ�." );
        pressreturn();
        return;
    }
    if( currentuser.userlevel & PERM_LOGINOK ) {
        prints( "�z�������T�{�w�g���\\, �w��[�J��������C." );
        pressreturn();
        return;
    }
    if( (fn = fopen( "new_register", "r" )) != NULL ) {
        while( fgets( genbuf, STRLEN, fn ) != NULL ) {
            if( (ptr = strchr( genbuf, '\n' )) != NULL )
                *ptr = '\0';
            if( strncmp( genbuf, "userid: ", 8 ) == 0 &&
                strcmp( genbuf + 8, currentuser.userid ) == 0 ) {
                fclose( fn );
                prints( "�����|���B�z�z�����U�ӽг�, �Э@�ߵ���." );
                pressreturn();
                return;
            }
        }
        fclose( fn );
    }
    getdata(3,0,"�z�T�w�n��g���U��� (Y/N)? [N]: ",ans,3,DOECHO,NULL,YEA);
    if( ans[0] != 'Y' && ans[0] != 'y' )
        return;
    strncpy( rname, currentuser.realname, NAMELEN );
    strncpy( addr,  currentuser.address,  STRLEN  );
    career[0] = phone[0] = birth[0]='\0';
    while( 1 ) {
        move( 3, 0 );
        clrtoeol();
        prints( "%s �A�n, �оڹ��g�H�U�����:\n", currentuser.userid ); 
        getfield(  6, "�ХΤ���",           "�u��m�W", rname, NAMELEN );
        getfield(  8, "�Ǯըt�ũγ��¾��", "�A�ȳ��", career,STRLEN );
        getfield( 10, "�]�A��ǩΪ��P���X", "�ثe���}", addr,  STRLEN );
        getfield( 12, "�]�A�i�s���ɶ�",     "�s���q��", phone, STRLEN );
        getfield( 14, "�~.��.��(����)",     "�X�ͦ~��", birth, STRLEN );
        mesg = "�H�W��ƬO�_���T, �� Q �����U (Y/N/Quit)? [N]: ";
        getdata(t_lines-1,0,mesg,ans,3,DOECHO,NULL,YEA);
        if( ans[0] == 'Q' || ans[0] == 'q' )
            return;
        if( ans[0] == 'Y' || ans[0] == 'y' )
            break;
    }
    strncpy( currentuser.realname, rname,  NAMELEN );
    strncpy( currentuser.address,  addr,   STRLEN  );
    if( (fn = fopen( "new_register", "a" )) != NULL ) {
        now = time( NULL );
        fprintf( fn, "usernum: %d, %s", usernum, ctime( &now ) );
        fprintf( fn, "userid: %s\n",    currentuser.userid );
        fprintf( fn, "realname: %s\n",  rname );
        fprintf( fn, "career: %s\n",    career );
        fprintf( fn, "addr: %s\n",      addr );
        fprintf( fn, "phone: %s\n",     phone );
        fprintf( fn, "birth: %s\n",     birth);
        fprintf( fn, "----\n" );
        fclose( fn );
    }
}

