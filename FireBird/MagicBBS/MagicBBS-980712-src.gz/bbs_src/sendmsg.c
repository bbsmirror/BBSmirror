#include "bbs.h"
#ifdef lint
#include <sys/uio.h>
#endif
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

extern int  RMSG;
extern int RUNSH;
extern int showlbar;
char buf2[STRLEN];
struct user_info *t_search();
extern int i_newfd;
extern int roll;
extern int scr_lns;

int
get_msg(uid,msg,line)
char *msg,*uid;
int line;
{
        char genbuf[3];

        move(line,0);
        clrtoeol();
        prints("�e���H���G%s",uid);
        memset(msg,0,sizeof(msg));
        while(1)
        {
                getdata( line+1, 0, "���H : ", msg, 60, DOECHO, NULL,NA);
                if(msg[0]=='\0')
                        return NA;
                getdata( line+2, 0, "�T�w�n�e�X��(Y)�O�� (N)���n (E)�A�s��? [Y]: ",
                    genbuf, 2, DOECHO, NULL ,1);
                if(genbuf[0]=='e'||genbuf[0]=='E')
                        continue;
                if(genbuf[0]=='n'||genbuf[0]=='N')
                        return NA;
                else
                        return YEA;
        }
}

char
msgchar(uin)
struct user_info *uin;
{
    if ((uin->pager&ALLMSG_PAGER)) return ' ';
    if ((can_override(uin->userid,currentuser.userid)))
    {
        if((uin->pager&FRIENDMSG_PAGER))
                return 'O';
        else
                return '#';
    }
    return '*';
}

int
canmsg(uin)
struct user_info *uin;
{
    if ((uin->pager&ALLMSG_PAGER) || HAS_PERM(PERM_SYSOP)) return YEA;
    if ((uin->pager&FRIENDMSG_PAGER))
    {
        if(can_override(uin->userid,currentuser.userid))
                return YEA;
    }
    return NA;
}

s_msg()
{
      do_sendmsg(NULL,NULL,0,0);
}

int
show_allmsgs()
{
        char fname[STRLEN];

        setuserfile(fname,"msgfile");
        clear();
        modify_user_mode( LOOKMSGS);
        if(dashf(fname))
        {
                ansimore(fname,YEA);
                clear();
        }
        else
        {
                move(5,30);
                prints("�S�����󪺰T���s�b�I�I");
                pressanykey();
                clear();
        }
}

int
do_sendmsg(uentp,msgstr,mode,userpid)
struct user_info *uentp;
char msgstr[256];
int mode;
int userpid;/*�ˬd PID, �H�K�e���H */
{
    char uident[STRLEN];
    FILE *fp;
    time_t now;
    struct user_info *uin ;
    char buf[80],msgbuf[256] ,msgbuf2[256],*timestr;
    msgbuf2[0]=0;
    
    if(mode==0)
    {
            modify_user_mode( MSG );
            move(2,0) ; clrtobot();
    }
  if(uentp==NULL)
  {
    prints("<��J�ϥΪ̥N��>\n") ;
    move(1,0) ;
    clrtoeol() ;
    prints("�e�T����: ") ;
    creat_list() ;
    namecomplete(NULL,uident) ;
    if(uident[0] == '\0') 
    {
        clear() ;
        return 0 ;
    }
/*    if(searchuser(uident)==0 || tuid == usernum) 
    {
       if(uentp==NULL)
       {
        move(2,0) ;
        prints("���~���ϥΪ� ID\n") ;
        pressreturn() ;
        move(2,0) ;
        clrtoeol() ;
       }
        return -1 ;
    }*/
    uin=t_search(uident,NA);
    if(uin==NULL)
    {  
        move(2,0) ;
        prints("���ثe���b�u�W�A�άO�ϥΪ̥N����J���~...\n");
        pressreturn() ;
        move(2,0) ;
        clrtoeol() ;
        return -1 ;
    } 
    if(!canmsg(uin))
    {
        move(2,0) ;
        prints("���w�g���������T�����I�s��...\n");
        pressreturn() ;
        move(2,0) ;
        clrtoeol() ;
        return -1;
    }
  }else
  {
  if(!strcmp(uentp->userid,currentuser.userid))
      return 0;    
   uin=uentp;
   strcpy(uident,uin->userid);
  }
    if(msgstr==NULL)
    {
        if (!get_msg(uident,buf,1) ){
            move(1,0); clrtoeol();
            move(2,0); clrtoeol(); 
            return 0;
        }
     }

        now=time(0);
        timestr=ctime(&now)+11;
        *(timestr+8)='\0';
        if(msgstr==NULL||mode==2)
        {
               sprintf(msgbuf,"[0;1;45;36m%-12.12s[33m([36m%-5.5s[33m):[1;37;45m%-59.59s[m[%dm\n", currentuser.userid, 
               timestr, (msgstr==NULL)?buf:msgstr,uinfo.pid+100);
               sprintf(msgbuf2,"[0;1;44;37m���M %s ���G%s[m\n", uident, (msgstr==NULL)?buf:msgstr);
        }else
        {
           if(mode==0)
                   sprintf(msgbuf,"[1;5;44;33m���F��[1;36;44m %8.8s [33m�ɼs���G[m[1;37;44m%-55.55s[m\n",timestr,msgstr);
           else if(mode==1)
           {
                   sprintf(msgbuf,"[0;1;44;36m%-12.12s[37m([36m%-5.5s[37m) �ܽЧA[1;37;44m%-52.52s[m[%dm\n", 
                   currentuser.userid, timestr, msgstr,uinfo.pid+100);
           }else if(mode==3)
           {
               sprintf(msgbuf,"[0;1;44;32mBBS �t�γq�i[33m([36m%-5.5s[33m):[1;37;44m%-58.58s[m\n",
               timestr, (msgstr==NULL)?buf:msgstr);
           }else if(mode==4)
           {
               sprintf(msgbuf,"[0;1;45;36m%-12.12s[33m([36m%-5.5s[33m):[1;37;45m%-59.59s[m[%dm\n", currentuser.userid, 
               timestr, (msgstr==NULL)?buf:msgstr,uinfo.pid+100);
           }    
        }
        if(userpid)
        {
                if(userpid!=uin->pid)
                {
                        saveline(0, 0); /* Save line */
                        move(0,0);
                        clrtoeol();
                        prints("[1m�V�|�A���w�g���]�F...[m\n");
                        sleep(1);
                        saveline(0, 1); /* restore line */
                        return -1;
                }
        }
        sethomefile(buf,uident,"msgfile");
        if((fp=fopen(buf,"a"))==NULL)
                return -1;
        fputs(msgbuf,fp);
        fclose(fp);
        if (msgbuf2[0]!=0)
         { sethomefile(buf,currentuser.userid,"msgfile");
           if((fp=fopen(buf,"a"))==NULL)
          	return -1;
          fputs(msgbuf2,fp);
          fclose(fp);}
        if(kill(uin->pid,SIGTTOU)==-1&&msgstr==NULL)
        {
            prints("\n�V�|�A���w�g���]�F...\n") ; pressreturn();
            clear();
            return -1;
        }
        if(msgstr==NULL)
        {
            prints("\n�w�e�X�T��....\n") ; pressreturn();
            clear() ;
        }
    return 1 ;
}

int
dowall(uin)
struct user_info *uin;
{
        if (!uin->active || !uin->pid) return -1;
        move(1,0);
        clrtoeol();
        prints("[1;32m���� %s �s��.... Ctrl-D ����惡�� User �s���C[m",uin->userid); 
        refresh();
        do_sendmsg(uin,buf2,0,uin->pid);
}


int
wall()
{
    modify_user_mode( MSG );
    move(2,0) ; clrtobot();
    if (!get_msg("�Ҧ��ϥΪ�",buf2,1) ){
         move(1,0); clrtoeol();
         move(2,0); clrtoeol();
         return 0;
    }
    if( apply_ulist( dowall ) == -1 ) {
        move(2,0);
        prints( "�S������ϥΪ̤W�u\n" );
        pressanykey();
    }
    prints("\n�w�g�s������....\n");
    pressanykey();
}

int
dofwall(uin)
struct user_info *uin;
{
        if (!uin->active || !uin->pid) return -1;
        if (can_override(currentuser.userid,uin->userid))
            if (canmsg(uin))
                  do_sendmsg(uin,buf2,4,uin->pid);
}

int
fwall()
{
    FILE *fp;
    char msgbuf[STRLEN];
    
    modify_user_mode( MSG );
    move(2,0) ; clrtobot();
    if (!get_msg("�Ҧ��B��",buf2,1) ){
         move(1,0); clrtoeol();
         move(2,0); clrtoeol();
         return 0;
    }
    
    apply_ulist(dofwall);
    sprintf(msgbuf,"\x1b[44m���M���n�ͻ��G%s\x1b[m\n",buf2);
         sethomefile(buf2,currentuser.userid,"msgfile");
           if((fp=fopen(buf2,"a"))==NULL)
          	return -1;
          fputs(msgbuf,fp);
          fclose(fp);    
    prints("\n�w�g�s������....\n");
    pressanykey();    
}

#define MSG_HISTORY 40

static char msg_history[MSG_HISTORY][256];  
static int head, tail;
static char tmp_screen[2][256];
int rmsgs_old_mode;

static int 
read_msgs()
{
    int i;
    char fname[STRLEN], buf[256];
    FILE *fp;

    head = tail = 0;

    setuserfile(fname,"msgfile");
    if((fp=fopen(fname,"r"))==NULL)
        {modify_user_mode(rmsgs_old_mode);
         return 0;}
    while(fgets( buf, 256, fp )!=NULL)
    {
        strcpy(msg_history[tail % MSG_HISTORY], buf);
        tail++;
    }
    fclose(fp);

    strcpy(msg_history[tail % MSG_HISTORY],"[1;46;37m�� \x1b[33m�� [L] ��ݩҦ����T  [R] �^�T  [Enter] ����  [����] ���ʼ��T \x1b[37m��[m");

    if(tail >= MSG_HISTORY) {
       head = (tail + 2) % MSG_HISTORY;    
       tail %= MSG_HISTORY;
    }
    return 1;
}
static void
show_msgs(line, i)
register int line, i;
{
    register int tmp;
    if(rmsgs_old_mode == TALK) {
      move(line, 0);
      clrtoeol();
      outs(msg_history[i]);
    } else {
      for(tmp = 0; tmp < 3; tmp++) {
         move(tmp, 0);
         clrtoeol();
         if( ((i + tmp) > tail) && (i <= tail) )
            outs(tmp_screen[tmp - 1]);
         else 
            outs(msg_history[(i+tmp)%MSG_HISTORY]);
      }
    }
   refresh();
   oflush();
}

static int get_other_msg = 0;
void
r_msg()
{
    char buf[256];
    int line, tmpansi, y, x, ch, i, tmp,old_fd=0;
    struct SCRBUF scrbuf;
    
    signal(SIGTTOU, r_msg) ;

    old_fd=i_newfd;
    add_io(0,0);
    
    if (RMSG==YEA) {
       get_other_msg = 1;
       add_io(old_fd,0);
       return;
    }

    RMSG = YEA;
    
    get_other_msg = 0;
    rmsgs_old_mode=uinfo.mode;
    modify_user_mode(LOOKMSGS);

    
    getyx(&y, &x);
    
    tmpansi = showansi;
    showansi = 1;
    
    {
       register struct screenline *bp;
       register int i;
       for(i = 0; i < 2; i++) {
          bp = (struct screenline *)lineptr((i+1+roll) % scr_lns);
          strncpy(tmp_screen[i], bp->data, bp->len);
          tmp_screen[i][bp->len]=0;
       }
    }
    
    if(rmsgs_old_mode==TALK)
        line = t_lines/2 - 1;
    else
        line = 0;
        
    if(rmsgs_old_mode == TALK)
       saveline(line, 0); /* save line */
    else
      { save3line(0, 0);
      }    


    if(DEFINE(DEF_SOUNDMSG))
    {
            bell();
    }
    
    
    if(!read_msgs()) {
       RMSG = NA;
       add_io(old_fd,0);
       return;
    }
    i = tail-1;
    show_msgs(line, i);
    
   ch = 0;
   while(ch != '\n' && ch != '\r' && ch != KEY_LEFT && ch != KEY_ESC)
   {
        if(get_other_msg) {
           if(!read_msgs()) {
              RMSG = NA;
              add_io(old_fd,0);
              return;
           }
           i = tail-1;
           show_msgs(line, i);
           get_other_msg = 0;
        }

        ch = igetkey();

        if(!ch)
             continue;
        if(ch == '\n' || ch == '\r')
             break;
         
    else if(ch == KEY_UP && i != head) {
             i--;
             if(i < 0) i += MSG_HISTORY;
             show_msgs(line, i);
         }
         
    else if(ch == KEY_DOWN && i != (tail-1)) {
             i++;
             i %= MSG_HISTORY;
             show_msgs(line ,i );
         }
    else if(ch=='$') {
             i=tail-1;
             show_msgs(line,i);
    }
    else if(ch=='l'||ch=='L')
    {
             savescreen(&scrbuf,0);
             RMSG=NA;
             showlbar=0;
             show_allmsgs();
             showlbar=1;
             RMSG=YEA;
             savescreen(&scrbuf,1); 
    } else 
    if(ch==Ctrl('R')||ch=='r'||ch=='R')
    {
          struct user_info *uin ;
          char msgbuf[STRLEN], msg[256];
          int good_id,send_pid;
          char *ptr,usid[STRLEN];

          strcpy(msg, msg_history[i]);
                    
          ptr=strrchr(msg,'[');
          send_pid=atoi(ptr+1);
          if(send_pid>100)
                send_pid-=100;
          ptr=strtok(msg+12," [");
          if(ptr==NULL|| !strcmp(ptr,currentuser.userid))
                good_id=NA;
          else
          {
                strcpy(usid,ptr);
                uin=t_search(usid,send_pid);
                if(uin==NULL)
                        good_id=NA;
                else
                        good_id=YEA;
          }
          
          if(good_id==YEA)
          {
                  int userpid;
              if (canmsg(uin))
              {
                  userpid = uin->pid;
                  if(rmsgs_old_mode != TALK) move(1, 0); else move(line,0);
                  clrnlines(1);
                  sprintf(msgbuf ,"\x1b[1;37m�^�T���� %s: ",usid);
                  getdata((rmsgs_old_mode != TALK)? 1:line,0,msgbuf,buf,60,DOECHO,NULL,YEA);
                  if(buf[0]!='\0')
                  {
                        do_sendmsg(uin,buf,2,userpid);
                        sprintf(msgbuf,"[1m�T���w�g�ǥX�F..[Enter]���� [�W�U]�~��^�O�H�����T [m");
                  }else
                        sprintf(msgbuf,"[1m�ŰT��, �ҥH���e�X.^[[m");
              } else  sprintf(msgbuf,"���w�g�����I�s��"); 

          }else
          {
              if (strcmp(usid,"���M"))
              {
                   sprintf(msgbuf,"[1m�V�|�I%s �w�g���]�F...[m",usid);
              }
          }
        if (strcmp(usid,"���M"))
        {
          move((rmsgs_old_mode != TALK)? 1:line,0);
          get_other_msg = 1;
          clrtoeol();
          /* refresh(); */
          prints("%s",msgbuf);
          refresh();
        }
      }
    } 
    showansi=tmpansi;
    if(rmsgs_old_mode == TALK)
       saveline(line, 1); /* restore line */
    else
       save3line(0, 1);
    move(y,x);
    refresh();
    RMSG=NA;
    modify_user_mode(rmsgs_old_mode);
    add_io(old_fd,0);
    return ;
}

int
friend_login_wall(pageinfo)
struct user_info *pageinfo;
{
        char msg[STRLEN];

       if(!DEFINE(DEF_SECLOGIN))
       {
        if( !pageinfo->active || !pageinfo->pid )
                return 0;
        if (can_override(pageinfo->userid,currentuser.userid)) {
                if(getuser(pageinfo->userid)<=0)
                        return 0;
                if(!(lookupuser.userdefine&DEF_LOGININFORM))
                        return 0;
                if(!strcmp(pageinfo->userid,currentuser.userid))
                        return 0;
                sprintf(msg,"�A���n�B�� %s �w�g�W���o�I",currentuser.userid);
                do_sendmsg(pageinfo,msg,4,pageinfo->pid);
        }
       }
        return 0;
}
