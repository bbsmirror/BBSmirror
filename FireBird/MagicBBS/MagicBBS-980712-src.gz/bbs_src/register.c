/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"

#define  EMAIL          0x0001 
#define  NICK           0x0002 
#define  REALNAME       0x0004 
#define  ADDR           0x0008
#define  REALEMAIL      0x0010
#define  BADEMAIL       0x0020
#define  NEWREG         0x0040

char    *sysconf_str();
char    *genpasswd();
char    *Ctime();

extern char     fromhost[ 60 ];
extern time_t   login_start_time;
time_t          system_time;

int
bad_user_id( userid )
char    *userid;
{
    FILE        *fp;
    char        buf[STRLEN];
    char        *ptr, ch;

    ptr = userid;
    while( (ch = *ptr++) != '\0' ) {
        if( !isalnum( ch ) && ch != '_' )
            return 1;
    }
    if( (fp = fopen( ".badname", "r" )) != NULL ) {
        while( fgets( buf, STRLEN, fp ) != NULL ) {
            ptr = strtok( buf, " \n\t\r" );
            if( ptr != NULL && *ptr != '#' && ci_strcmp( ptr, userid ) == 0 ) {
                fclose( fp );
                return 1;
            }
        }
        fclose(fp);
    }
    return 0;
}

int 
compute_user_value( urec )
struct userec *urec;  // �Ǧ^�Ȫ��ܦ��X�ѨS�W���N�尣��ID�I
{
    int         value;

    /* if (urec) has XEMPT permission, don't kick it */
    if( urec->userlevel & PERM_XEMPT )
        return 999;
    value = (time(0) - urec->lastlogin) / 60;    /* min */
        /* new user should register in 30 mins */
    if( strcmp( urec->userid, "new" ) == 0 ) {
        return (30 - value) * 60;
    }
    if( urec->numlogins <= 3 )
        return (15 * 24 * 60 - value)/(60*24);
    if( !(urec->userlevel & PERM_LOGINOK) )
        return (20 * 24 * 60 - value)/(60*24);
    return urec->stay/(60*60*2) + (90 * 24 * 60 - value)/(60*24);
}

int
getnewuserid()
{
    struct userec utmp, zerorec;
    struct stat st;
    int         fd, size, val, i;

    system_time = time( NULL );
    if( stat( "tmp/killuser", &st )== -1 || st.st_mtime < system_time-3600 ) {
        if( (fd = open( "tmp/killuser", O_RDWR|O_CREAT, 0600 )) == -1 )
            return -1;
        write( fd, ctime( &system_time ), 25 );
        close( fd );
        log_usies( "CLEAN", "dated users." );
        printf( "�M��s�b����, �еy�ݤ���...\n\r" );
        memset( &zerorec, 0, sizeof( zerorec ) );
        if( (fd = open( PASSFILE, O_RDWR|O_CREAT, 0600 )) == -1 )
            return -1;
        size = sizeof( utmp );
        for( i = 0; i < MAXUSERS; i++ ) {
            if( read( fd, &utmp, size ) != size )
                break;
            val = compute_user_value( &utmp );
            if( utmp.userid[0] != '\0' && val < 0 ) {
                sprintf( genbuf, "#%d %-12s %15.15s %d %d %d",
                        i+1, utmp.userid, ctime( &(utmp.lastlogin) )+4,
                        utmp.numlogins, utmp.numposts, val );
                log_usies( "KILL ", genbuf );
                if( !bad_user_id( utmp.userid ) ) {
                    sprintf( genbuf, "/bin/rm -fr mail/%c/%s", 
                             toupper(utmp.userid[0]),utmp.userid );
                    system( genbuf );
                    sprintf( genbuf, "/bin/rm -fr home/%c/%s", toupper(utmp.userid[0]),utmp.userid );
                    system( genbuf );
                    sprintf( genbuf, "/bin/rm -f tmp/email_%s", utmp.userid );
                    system( genbuf );
                }
                lseek( fd, -size, SEEK_CUR );
                write( fd, &zerorec, sizeof( utmp ) );
            }
        }
        close( fd );
        touchnew();
    }
    if( (fd = open( PASSFILE, O_RDWR|O_CREAT, 0600 )) == -1 )
        return -1;
    flock( fd, LOCK_EX );

    i = searchnewuser();
    sprintf( genbuf, "uid %d from %s", i, fromhost );
    log_usies( "APPLY", genbuf );

    if( i <= 0 || i > MAXUSERS ) {
        flock(fd,LOCK_UN) ;
        close(fd) ;
        if( dashf( "etc/user_full" ) ) {
            ansimore( "etc/user_full", NA );
            oflush();
        } else {
            printf( "��p, �ϥΪ̱b���w�g���F, �L�k���U�s���b��.\n\r" );
        }
        val = (st.st_mtime - system_time + 3660) / 60;
        printf( "�е��� %d ������A�դ@��, ���A�n�B.\n\r", val );
        sleep( 2 );
        exit( 1 );
    }
    memset( &utmp, 0, sizeof( utmp ) );
    strcpy( utmp.userid, "new" );
    utmp.lastlogin = time( NULL );
    if( lseek( fd, sizeof(utmp) * (i-1), SEEK_SET ) == -1 ) {
        flock( fd, LOCK_UN );
        close( fd );
        return -1;
    }
    write( fd, &utmp, sizeof(utmp) );
    setuserid( i, utmp.userid );
    flock( fd, LOCK_UN );
    close( fd );
    return i;
}

int 
id_with_num(userid)
char userid[IDLEN];
{
        char *s;
        for(s=userid;*s != '\0'; s++) {
            if(*s<1 || ispunct(*s)) {
            return 1;
            }
        }
        return 0;
}
void
new_register()
{
    struct userec       newuser;
    char        passbuf[ STRLEN ];
    int         allocid, try,flag;

    if( 1 ) {
        time_t  now;

        now = time( 0 );
        sprintf( genbuf, "etc/no_register_%3.3s", ctime( &now ) );
        if( dashf( genbuf ) ) {
            ansimore( genbuf, NA );
            pressreturn();
            exit( 1 );
        }
    }
    memset( &newuser, 0, sizeof(newuser) );
    allocid = getnewuserid()  ;
    if(allocid > MAXUSERS || allocid <= 0) {
        printf("No space for new users on the system!\n\r") ;
        exit(1) ;
    }

    ansimore("etc/register", NA);
    try = 0;
    while( 1 ) {
        if( ++try >= 10 ) {
            prints("\n�T�T�A���Ӧh�U  <Enter> �F...\n");
            refresh();
            longjmp( byebye, -1 );
        }
        getdata(0,0,"�п�J�N��: ",newuser.userid,IDLEN+1,DOECHO,NULL,YEA);
        flag = 1;
        if(id_with_num(newuser.userid)==1)
        {
                prints("�b���������^��r���μƦr���զX!\n");
                flag=0;
        }
        if (flag) {if(strlen(newuser.userid) < 2) {
            prints("�N���ܤֻݦ���ӭ^��r��!\n");
        } else if ( (*newuser.userid == '\0') || bad_user_id( newuser.userid )){
            prints( "�t�ΥΦr�άO�������N���C\n" );
        } else if( dosearchuser( newuser.userid ) ) {
            prints("���b���w�g���H�ϥ�\n") ;
        } else if (!isalpha(newuser.userid[0])) {
            prints("�ФŨϥΥH�Ʀr�}�Y��ID\n");
        }
        else break;}
    }
    while( 1 ) {
        getdata(0,0,"�г]�w�z���K�X: ",passbuf,PASSLEN,NOECHO,NULL,YEA) ;
        if( strlen( passbuf ) < 4 || !strcmp( passbuf, newuser.userid ) ) {
            prints("�K�X�ӵu�λP�ϥΪ̥N���ۦP, �Э��s��J\n") ;
            continue;
        }
        strncpy( newuser.passwd, passbuf, PASSLEN );
        getdata(0,0,"�ЦA��J�@���A���K�X: ",passbuf,PASSLEN,NOECHO,NULL,YEA);
        if( strncmp( passbuf, newuser.passwd, PASSLEN ) != 0 ) {
            prints("�K�X��J���~, �Э��s��J�K�X.\n") ;
            continue;
        }
        passbuf[8] = '\0' ;
        strncpy( newuser.passwd, genpasswd( passbuf ), PASSLEN );
        break;
    }
    getdata(0,0,"�п�J�׺ݾ��κA: [vt100] ",newuser.termtype,16,DOECHO,NULL,YEA);
    if( newuser.termtype[0] == '\0' ) {
        strcpy(newuser.termtype, "vt100");
    }
    newuser.userlevel = PERM_BASIC;
    newuser.userdefine=-1;
    newuser.userdefine&=~DEF_MAILMSG;
    newuser.userdefine&=~DEF_SECLOGIN;
    newuser.editor=1;
    newuser.sex=0; 
    newuser.magic=0;
    newuser.addmagic=0;
    newuser.showfile=0xffff;
    
    newuser.bmonth=0;
    newuser.bday=0;
    newuser.byear=0;
    newuser.unsign_ffff=0xffff;
    newuser.unsign_0000=0x0000;
    newuser.card=0;
    newuser.unused1=0;
    
    newuser.magic=0;
    newuser.money=500;
    newuser.lent=0;  
    newuser.bank=0;  	
    
    newuser.flags[0] = CURSOR_FLAG;
    newuser.flags[0]|= PAGER_FLAG;
    newuser.flags[1] = 0;
    newuser.firstlogin = newuser.lastlogin = time(NULL) ;

    if( substitute_record(PASSFILE,&newuser,sizeof(newuser),allocid) == -1 ) {
        fprintf(stderr,"too much, good bye!\n") ;
        exit(1) ;
    }
    setuserid( allocid, newuser.userid );
    if( !dosearchuser(newuser.userid) ) {
        fprintf(stderr,"User failed to create\n") ;
        exit(1) ;
    }
    report( "new account" );
}

char *
trim( s )
char *s;
{
    static char buf[ 256 ];
    char *l, *r;

    buf[ 0 ] = '\0' ;
    r = s + strlen( s ) - 1;

    for (l = s ; strchr(" \t\r\n", *l) && *l; l++);

    /* if all space, *l is null here, we just return null */
    if (*l != '\0') {   
        for ( ; strchr(" \t\r\n", *r) && r >= l ; r-- );
        strncpy( buf, l, r - l + 1 );
    }
    return buf;
}

int
invalid_realmail( userid, email, msize )
char    *userid, *email;
int     msize;
{
    FILE        *fn;
    char        *emailfile, ans[4],fname[STRLEN];
    
    if( (emailfile = sysconf_str( "EMAILFILE" )) == NULL )
        return 0;
      
    if( strchr( email, '@' ) && valid_ident( email ) ) 
        return 0;
/* 
    ansimore( emailfile, NA );
    getdata(t_lines-1,0,"�z�n�{�b email-post ��? (Y/N) [Y]: ",
        ans,2,DOECHO,NULL,YEA);
    while( *ans != 'n' && *ans != 'N' ) {
*/
        sprintf( fname, "tmp/email_%s", userid );
        if( (fn = fopen( fname, "r" )) != NULL ) {
            fgets( genbuf, STRLEN, fn );
            fclose( fn );
            strtok( genbuf, "\n" );
            if (!valid_ident( genbuf )) { 
            } else if( strchr( genbuf, '@' ) != NULL ) {
                unlink(fname);
                strncpy( email, genbuf, msize );
                move( 10, 0 );
                prints( "���P�z!! �z�w�q�L��������, ������������. \n" );
                prints( "         �������z�Ҵ��Ѫ��B�~�A��, \n" );
                prints( "         �]�ATIN,IRC,����Ȫe  ��. \n" ); 
                prints( "  \n" );
                prints( "��ĳ�z,  ���|�B�s���@�U, \n" );
                prints( "         �������a��, �Цb sysop �O�d��, \n" );
                prints( "         �����|���M�H���z�ѵ�. \n" );
                getdata( 18 ,0, "�Ы� <Enter>  <<  ", ans,2,DOECHO,NULL ,YEA);
                return 0;
            }
        }
    return 1;
}

void
check_register_info()
{
    struct userec *urec = &currentuser;
    char        *newregfile;
    int         perm;
    time_t      code;
    FILE        *fin, *fout,*dp;
    char        ans[4],buf[STRLEN];
    extern int showansi;

    clear();
    sprintf(buf,"%s",email_domain());
    if( !(urec->userlevel & PERM_BASIC) ) {
        urec->userlevel = 0;
        return;
    }
    /*urec->userlevel |= PERM_DEFAULT;*/
    perm = PERM_DEFAULT & sysconf_eval( "AUTOSET_PERM" );

/*    if( sysconf_str( "IDENTFILE" ) != NULL ) {  commented out by netty to save time */
        while ( strlen( urec->username ) < 2 ) {
            getdata( 2, 0, "�п�J�z���ʺ�:(�Ҧp,�p����) << ", urec->username, NAMELEN,DOECHO,NULL ,YEA);
            strcpy(uinfo.username,urec->username);
            update_utmp();
        }
      while ( strlen( urec->realname ) < 2 ) {
            move( 3, 0 );
            prints( "�п�J�z���u��m�W: (�����|���z�O�K�� !)\n" );
            getdata( 4, 0, "> ", urec->realname, NAMELEN,DOECHO,NULL,YEA);
        }
       while ( strlen( urec->address ) < 6 ) {
            move( 5, 0 );
            prints( "�z�����}�O�G\n" );
/*            getdata( 6 ,0, "�Ы� <Enter>  <<  ", ans,2,DOECHO,NULL,YEA);*/
            getdata( 6, 0, "> ", urec->address, NAMELEN,DOECHO,NULL,YEA); 
        }
       while ( (urec->sex <1) || (urec->sex >6) ) {
        move( 6, 0 );
        prints("�п�ܱz���ʧO (1.�j���� 2.�p�̧� 3.�j�n�n 4.�p�f�f 5.�Ӫ� 6.�q��) ");	
 	getdata(6,66, ": ",genbuf, 2, DOECHO, NULL,YEA );
 	urec->sex=genbuf[0]-'0';      	   
      }
              
       while ( strchr( urec->email, '@' ) == NULL ) {
            move( 7, 0 );
            prints( "�z�p�L  �@��q�l�H�c(�D BBS�� ���q�l�H�c), \n" );
            prints( "      �N�L�k���������X�椽�� \n" );
            prints( "      �X�椽���i�H�ɥΫܦh�S�O�A�Ȯ@!! \n" );
            move( 11, 0 );
            prints( "�q�l�H�c�榡��: xxx@xxx.xxx.edu.tw \n" );
            getdata( 12, 0, "�п�J�q�l�H�c: (���ണ�Ѫ̫� <Enter>) << "
                            , urec->email, STRLEN,DOECHO,NULL,YEA);
            if ((strchr( urec->email, '@' ) == NULL )) { 
                sprintf( genbuf, "%s.bbs@%s", urec->userid,buf );
                strncpy( urec->email, genbuf, STRLEN);
            }
    }   
  if(!strcmp(currentuser.userid,"SYSOP"))
  {
        currentuser.userlevel=~0;
        substitute_record(PASSFILE,&currentuser,sizeof(struct userec),usernum);
  }
  if(!(currentuser.userlevel&PERM_LOGINOK))
  {
    if( HAS_PERM( PERM_SYSOP )) 
        return;
    if(!invalid_realmail( urec->userid, urec->termtype+16, STRLEN-16 ))
    {
        set_safe_record();
        urec->userlevel |= PERM_DEFAULT;
        if( HAS_PERM( PERM_DENYPOST ) && !HAS_PERM( PERM_SYSOP ) )
             urec->userlevel &= ~PERM_POST;
        substitute_record(PASSFILE,urec,sizeof(struct userec),usernum) ;
    }else {
       /* added by netty to automatically send a mail to new user. */
       /* begin of check if local email-addr  */
       if (
           /*(!strstr( urec->email, "@bbs.") ) &&*/
           (!strstr( urec->email, ".bbs@") )&&
           (!invalidaddr(urec->email))&&
           sysconf_str( "EMAILFILE" )!=NULL) 
       {
           move( 15, 0 );
           prints( "�z���q�l�H�c  �|���q�L�^�H����...  \n" );
           prints( "      SYSOP �N�H�@�����ҫH���z,\n" );
           prints( "      �z�u�n�^�H, �N�i�H���������X�椽��.\n" );
           getdata( 19 ,0, "�z�n SYSOP �H�o�@�ʫH��?(Y/N) [Y] << ", ans,2,DOECHO,NULL,YEA);
           if ( *ans != 'n' && *ans != 'N' ) {
           code=(time(0)/2)+(rand()/10);
           sethomefile(genbuf,urec->userid,"mailcheck");
           if((dp=fopen(genbuf,"w"))==NULL)
           {
                fclose(dp);
                return;
           }
           fprintf(dp,"%9.9d\n",code);
           fclose(dp);
           sprintf( genbuf, "/usr/lib/sendmail -f SYSOP.bbs@%s %s ", 
                 email_domain(), urec->email );
           fout = popen( genbuf, "w" );
           fin  = fopen( sysconf_str( "EMAILFILE" ), "r" );
           /* begin of sending a mail to user to check email-addr */
           if ((fin != NULL) && (fout != NULL)) {
               fprintf( fout, "Reply-To: SYSOP.bbs@%s\n", email_domain());
               fprintf( fout, "From: SYSOP.bbs@%s\n",  email_domain() ); 
               fprintf( fout, "To: %s\n", urec->email);
               fprintf( fout, "Subject: @%s@[-%9.9d-]firebird mail check.\n", urec->userid ,code);
               fprintf( fout, "X-Forwarded-By: SYSOP \n" );
               fprintf( fout, "X-Disclaimer: None\n");
               fprintf( fout, "\n");
               fprintf(fout,"�z���򥻸�Ʀp�U�G\n",urec->userid);
               fprintf(fout,"�ϥΪ̥N���G%s (%s)\n",urec->userid,urec->username);
               fprintf(fout,"�m      �W�G%s\n",urec->realname);
               fprintf(fout,"�W����m  �G%s\n",urec->lasthost);
               fprintf(fout,"�q�l�l��  �G%s\n\n",urec->email);
               fprintf(fout,"�˷R�� %s(%s):\n",urec->userid,urec->username);
               while (fgets( genbuf, 255, fin ) != NULL ) {
                   if (genbuf[0] == '.' && genbuf[ 1 ] == '\n')
                        fputs( ". \n", fout );
                   else fputs( genbuf, fout );
               }
               fprintf(fout, ".\n");                                    
               fclose( fin );
               fclose( fout );                                     
           } /* end of sending a mail to user to check email-addr */
           getdata( 20 ,0, "�H�w�H�X, SYSOP �N���z�^�H�@!! �Ы� <Enter> << ", ans,2,DOECHO,NULL ,YEA);
           }
       }else
       {
        showansi=1;
        if(sysconf_str( "EMAILFILE" )!=NULL)
        {
          prints("\n�A���q�l�l��a�} �i[1;33m%s[m�j\n",urec->email);
          prints("�ëD Unix �b���A�t�Τ��|�뻼�����T�{�H�A�Ш�[1;32m�u��c[m���ק�..\n");
          pressanykey();
        }
       }
   }
 /* end of check if local email-addr */
/*  above lines added by netty...  */   
}
    newregfile = sysconf_str( "NEWREGFILE" );
    if( urec->lastlogin - urec->firstlogin < 3*86400 &&
        !HAS_PERM( PERM_SYSOP) && newregfile != NULL ) {
        set_safe_record();
        urec->userlevel &= ~(perm);
        substitute_record(PASSFILE,urec,sizeof(struct userec),usernum) ;
        ansimore( newregfile, YEA );
    }
    set_safe_record();
    if( HAS_PERM( PERM_DENYPOST ) && !HAS_PERM( PERM_SYSOP ) )
    {
        currentuser.userlevel &= ~PERM_POST;
        substitute_record(PASSFILE,urec,sizeof(struct userec),usernum) ;
    }
}

