int
noanslen(char *str)
{
    int len=0,inesc=0;
    
    len=strlen(str);    
    while(*str) 
    {   
      if (*str=='\x1b' && *(str+1)=='[') inesc=1;
      if (inesc==1) len--;
      if (*str++=='m') inesc=0;
    }
    return len;
}
