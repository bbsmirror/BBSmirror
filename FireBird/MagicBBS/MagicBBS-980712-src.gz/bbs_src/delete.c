/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"

int
d_board()
{
    struct boardheader binfo ;
    int bid ;
    char bname[STRLEN];
    extern char lookgrp[];
    extern int numboards ;

    modify_user_mode( ADMIN );
    if(!check_systempasswd())
    {
        return;
    }
    clear();
    stand_title( "�R���Q�װ�" );
    make_blist() ;
    move(1,0) ;
    namecomplete( "�п�J�Q�װ�: ",genbuf) ;
    if( genbuf[0] == '\0' )
        return 0;
    bid = getbnum(genbuf) ;
    if( get_record(BOARDS,&binfo,sizeof(binfo),bid) == -1 ) {
        move(2,0) ;
        prints("�����T���Q�װ�\n") ;
        pressreturn() ;
        clear() ;
        return 0 ;
    }
    strcpy(bname,genbuf);
    move(1,0) ;
    prints( "�R���Q�װ� '%s'.", binfo.filename );
    clrtoeol();
    getdata(2,0,"(Yes, or No) [N]: ",genbuf,4,DOECHO,NULL,YEA) ;
    if( genbuf[0] != 'Y' && genbuf[0] != 'y') { /* if not yes quit */
        move(2,0) ;
        prints("�����R��....\n") ;
        pressreturn() ;
        clear() ;
        return 0 ;
    }
    {
        char        secu[STRLEN];
        sprintf(secu,"�R���Q�װϡG%s",binfo.filename);
        securityreport(secu);
    }
    if(seek_in_file("0Announce/.Search",bname))
    {
            getdata(3,0,"������ذ� (Yes, or No) [Y]: ",genbuf,4,DOECHO,NULL,YEA) ;
            if( genbuf[0] != 'N' && genbuf[0] != 'n') 
            {
                get_grp(binfo.filename);
                del_grp(lookgrp,binfo.filename,binfo.title+13);
            }
     }
    if(seek_in_file("etc/anonymous",bname))
            del_from_file("etc/anonymous",bname);
    if(seek_in_file("0Announce/.Search",bname))
            del_from_file("0Announce/.Search",bname);

    if( binfo.filename[0] == '\0' ) return -1; /* rrr - precaution */
    sprintf(genbuf, "deleted board %s", binfo.filename);
    report(genbuf);
    sprintf(genbuf,"/bin/rm -fr boards/%s",binfo.filename) ;
    system(genbuf) ;
    sprintf(genbuf,"/bin/rm -fr vote/%s",binfo.filename) ;
    system(genbuf) ;

    sprintf( genbuf, " << '%s'�Q %s �R�� >>",
                        binfo.filename, currentuser.userid );
    memset( &binfo, 0, sizeof( binfo ) );
    strcpy( binfo.title, genbuf );
    binfo.level = PERM_SYSOP;
    substitute_record( BOARDS, &binfo, sizeof( binfo ), bid );

    move(4,0) ;
    prints("���Q�װϤw�g�R��...\n") ;
    pressreturn() ;
    numboards = -1 ;
    clear() ;
    return 0 ;
}

offline()
{

    modify_user_mode( OFFLINE );

    if(HAS_PERM(PERM_SYSOP))
        return;
    clear();
    move(1,0);
    prints("[1;32m�n���L��.....[m");
    move(3,0);
    if(askyn("�A�T�w�n���}�o�Ӥj�a�x",0)==1)
    {
        clear();
        if(d_user(currentuser.userid)==1)
        {
                mail_info();
                kick_user(&uinfo);
                exit(0);
        }
    }
}

getuinfo(fn)
FILE *fn;
{
        fprintf(fn,"\n\n�z���N��     : %s\n", currentuser.userid);
        fprintf(fn,"�z���ʺ�     : %s\n", currentuser.username);
        fprintf(fn,"�u��m�W     : %s\n", currentuser.realname);
        fprintf(fn,"�~�����}     : %s\n", currentuser.address);
        fprintf(fn,"�q�l�l��H�c : %s\n", currentuser.email);
        fprintf(fn,"�u�� E-mail  : %s\n", currentuser.termtype + 16);
        fprintf(fn,"Ident ���   : %s\n", currentuser.ident);
        fprintf(fn,"���U���     : %s", ctime( &currentuser.firstlogin));
        fprintf(fn,"�̪���{��� : %s", ctime( &currentuser.lastlogin));
        fprintf(fn,"�̪���{���� : %s\n", currentuser.lasthost );
        fprintf(fn,"�W������     : %d ��\n", currentuser.numlogins);
        fprintf(fn,"�峹�ƥ�     : %d / %d (Board/1Discuss)\n",
           currentuser.numposts, post_in_tin( currentuser.userid ));
}
mail_info()
{
        FILE *fn;
        time_t now;
        char filename[STRLEN];

        now=time(0);
        sprintf(filename,"etc/%s.tmp",currentuser.userid);
        fn=fopen(filename,"w");
        fprintf(fn,"[1m%s[m �w�g�b [1m%24.24s[m �۱��F�A�H�U�O�L����ơA�ЫO�d...",currentuser.userid
                ,ctime(&now));
        getuinfo(fn);
        fprintf(fn,"\n                      [1m �t�Φ۰ʵo�H�t�ίd[m\n");
        fclose(fn);
        mail_file(filename,"acmanager","�۱��q��....");
        unlink(filename);
}



int
d_user(cid)
char cid[IDLEN];
{
    int id ;

if(uinfo.mode!=OFFLINE)
{
    modify_user_mode( ADMIN );
    if(!check_systempasswd())
    {
        return;
    }
    clear();
    stand_title( "�R���ϥΪ̱b��" );
    move(1,0) ;
    usercomplete("�п�J���R�����ϥΪ̥N��: ",genbuf);
    if(*genbuf == '\0') {
        clear() ;
        return 0 ;
    }
}else
    strcpy(genbuf,cid);
    if(!(id = getuser(genbuf))) {
        move(3,0) ;
        prints("���~���ϥΪ̥N��...") ;
        clrtoeol() ;
        pressreturn() ;
        clear() ;
        return 0 ;
    }
/*    if (!isalpha(lookupuser.userid[0])) return 0;*/
        /* rrr - don't know how...*/
    move(1,0) ;
if(uinfo.mode!=OFFLINE)
    prints("�R���ϥΪ� '%s'.",genbuf) ;
else
    prints(" %s �N���}�o��",cid);
    clrtoeol();
    getdata(2,0,"(Yes, or No) [N]: ",genbuf,4,DOECHO,NULL,YEA) ;
    if(genbuf[0] != 'Y' && genbuf[0] != 'y') { /* if not yes quit */
        move(2,0) ;
if(uinfo.mode!=OFFLINE)
        prints("�����R���ϥΪ�...\n") ;
else
        prints("�A�ש�^����N�F�A�n������...");
        pressreturn() ;
        clear() ;
        return 0 ;
    }
    if(uinfo.mode!=OFFLINE)
    {
        char        secu[STRLEN];
        sprintf(secu,"�R���ϥΪ̡G%s",lookupuser.userid);
        securityreport(secu);
    }
    sprintf(genbuf, "%s deleted user %s", currentuser.userid,lookupuser.userid);
    report(genbuf);

    sprintf(genbuf,"/bin/rm -fr mail/%c/%s", toupper(lookupuser.userid[0]),lookupuser.userid) ;
    system(genbuf) ;
    sprintf(genbuf,"/bin/rm -fr home/%c/%s", toupper(lookupuser.userid[0]),lookupuser.userid) ;
    system(genbuf) ;
    sprintf(genbuf,"/bin/rm -fr tmp/email_%s", lookupuser.userid) ;
    system(genbuf) ;
    lookupuser.userlevel = 0;
    strcpy(lookupuser.address, "");
    strcpy(lookupuser.username, "");
    strcpy(lookupuser.realname, "");
    strcpy(lookupuser.termtype, "");
    lookupuser.userid[0] = '\0' ;
    substitute_record(PASSFILE,&lookupuser,sizeof(lookupuser),id) ;
    setuserid( id, lookupuser.userid );
    move(2,0) ;
    prints("%s �w�g�w�g�M���a�x���h�p��....\n",lookupuser.userid) ;
    pressreturn() ;

    clear() ;
    return 1 ;
}
extern int cmpuids(), t_cmpuids();

int
kick_user(userinfo)
struct user_info *userinfo;
{
    int id, ind ;
    struct user_info uin;
    struct userec kuinfo;
    char kickuser[40], buffer [40];

   if(uinfo.mode!=LUSERS&&uinfo.mode!=OFFLINE&&uinfo.mode!=FRIEND)
   {
    modify_user_mode( ADMIN );
    stand_title( "Kick User" );
    move(1,0) ;
    usercomplete("Enter userid to be kicked: ",kickuser) ;
    if(*kickuser == '\0') {
        clear() ;
        return 0 ;
    }
    if(!(id = getuser(kickuser))) {
        move(3,0) ;
        prints("Invalid User Id") ;
        clrtoeol() ;
        pressreturn() ;
        clear() ;
        return 0 ;
    }
    move(1,0) ;
    prints("Kick User '%s'.",kickuser) ;
    clrtoeol();
    getdata(2,0,"(Yes, or No) [N]: ",genbuf,4,DOECHO,NULL,YEA) ;
    if(genbuf[0] != 'Y' && genbuf[0] != 'y') { /* if not yes quit */
        move(2,0) ;
        prints("Aborting Kick User\n") ;
        pressreturn() ;
        clear() ;
        return 0 ;
    }
    search_record(PASSFILE, &kuinfo, sizeof(kuinfo), cmpuids, kickuser);
    ind = search_ulist( &uin, t_cmpuids, id );
   }else
   {
        uin=*userinfo;
        strcpy(kickuser,uin.userid);
/*        id = getuser(kickuser);
        search_record(PASSFILE, &kuinfo, sizeof(kuinfo), cmpuids, kickuser);
        ind = search_ulist( &uin, t_cmpuids, id );*/
        ind=YEA;
   }
    if (!ind || !uin.active || (kill(uin.pid,0) == -1)) {
       if(uinfo.mode!=LUSERS&&uinfo.mode!=OFFLINE&&uinfo.mode!=FRIEND)
       {
        move(3,0) ;
        prints("User Has Logged Out") ;
        clrtoeol() ;
        pressreturn() ;
        clear() ;
       }
        return 0 ;
    }
    kill(uin.pid,SIGHUP);
    sprintf(buffer, "kicked %s", kickuser);
    report(buffer);
    sprintf( genbuf, "%s (%s)", kuinfo.userid, kuinfo.username );
    log_usies( "KICK ", genbuf );
    uin.active = NA;
    uin.pid = 0;
    uin.invisible = YEA;
    uin.sockactive = 0;
    uin.sockaddr = 0;
    uin.destuid = 0;
    update_ulist( &uin, ind );
    move(2,0) ;
   if(uinfo.mode!=LUSERS&&uinfo.mode!=OFFLINE&&uinfo.mode!=FRIEND)
   {
    prints("User has been Kicked\n") ;
    pressreturn() ;
    clear() ;
   }
    return 1 ;
}

