#include "bbs.h"

struct FILESHM
{
        char line[FILE_MAXLINE][FILE_BUFSIZE];
        int  fileline;
        int  max;
        time_t  update;
};
struct  FILESHM   *goodbyeshm;
struct  FILESHM   *issueshm;
struct  FILESHM   *expshm;

int
fill_shmfile(mode,fname,shmkey)
int mode;
char *shmkey,*fname;
{
     FILE *fffd ;
     char *ptr;
     char buf[FILE_BUFSIZE];
     struct stat st ;
     time_t  ftime,now;
     int lines=0,nowfn=0,maxnum;
     struct FILESHM *tmp;

     switch(mode)
     {
        case 1:
                maxnum=MAX_ISSUE;
                break;
        case 2:
                maxnum=MAX_GOODBYE;
                break;
        case 3:
                maxnum=MAX_EXP;
                break;
     }
        now=time(0);
        if( stat( fname,&st ) < 0 ) {
            return 0;
        }
        ftime = st.st_mtime;
        tmp =(void *)attach_shm( shmkey, 5001+mode, sizeof( struct FILESHM )*maxnum );
     switch(mode)
     {
        case 1:
                issueshm=tmp;
                break;
        case 2:
                goodbyeshm=tmp;
                break;
/*        case 3:
                expshm=tmp;
                break;*/
     }

        if(abs(now-tmp[0].update)<24*60*60&&ftime<tmp[0].update)
        {
                return 1;
        }
        if ((fffd = fopen( fname , "r" )) == NULL)
        {
                return 0;
        }
        while ((fgets( buf,FILE_BUFSIZE, fffd )!=NULL)&&nowfn<maxnum)
        {
                 if(lines>FILE_MAXLINE)
                        continue;
                 if(strstr(buf,"@logout@")||strstr(buf,"@issue@")||strstr(buf,"@systemexp@"))
                 {
                        tmp[nowfn].fileline=lines;
                        tmp[nowfn].update=now;
                        nowfn++;
                        lines=0;
                        continue;
                 }
                 ptr=tmp[nowfn].line[lines];
                 memcpy( ptr, buf, sizeof(buf) );
                 lines++;
        }
        tmp[nowfn].fileline=lines;
        tmp[nowfn].update=now;
        nowfn++;
        tmp[0].max=nowfn;
        fclose(fffd);
        return 1;
}
void
show_shmfile(fh)
struct FILESHM *fh;
{
        int i;
        char buf[FILE_BUFSIZE];

        for(i=0;i<fh->fileline;i++)
        {
                strcpy(buf,fh->line[i]);
                showstuff(buf);
        }
}

void
show_goodbyeshm()
{
        int logouts;

        logouts=goodbyeshm[0].max;
        clear();
        move(1,0);
        show_shmfile(&goodbyeshm[(currentuser.numlogins%((logouts<=1)?1:logouts))]);
}

void
show_issue()
{
        int issues=issueshm[0].max;

        show_shmfile(&issueshm[(issues<=1)?0:
                  ((time(0)/86400)%(issues))]);

}

/*
char *
get_systemexp(place)
int place;
{
        int issues=expshm[0].max;
        int maxline;
        int line,page;

        page=place/24;
        line=place%24;

        if(page<issues)
        {
                maxline=expshm[page].fileline;
                if(line<maxline)
                {
                        return expshm[page].line[line];
                }
        }
        return NULL;
}
*/
