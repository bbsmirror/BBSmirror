#include "bbs.h"
#define b_lines 24

void gorilla_anykey(char *msg)
{
  if(msg)
    { 
     move (b_lines, 0);
     clrtoeol();
     prints("[1;36;44m    %-54s  [37;42m [[33m�Ы����N���~��[37m] [m",msg);
     igetkey();
    } else
    {
     move (b_lines, 0);
     prints("[1;44;32m                                 ��[33m��[35m�N[36m��[32m�~��....                              [m");
     igetkey();
    }
  move(b_lines,0);
  clrtoeol();
  refresh();
}


hint_message()
{
        struct timeval  timep;
        struct timezone timezp;
        int     i, j, msgNum;
        FILE    *hintp;
        char    msg[136];
        modify_user_mode(HINTMESSAGE);
        if (!(hintp = fopen("etc/hint", "r")))
          return 0;
        fgets(msg, 135, hintp);
        msgNum = atoi(msg);
        gettimeofday(&timep, &timezp);
        i = (int) timep.tv_sec%(msgNum + 1);
        if (i == msgNum)
          i--;
        j = 0;

        while (j < i)
        {
          fgets(msg, 135, hintp);
          msg[1] = '\0';
          if (!strcmp(msg,"#"))
            j++;
        }
        move(12, 0);
        clrtobot();
        fgets(msg, 135, hintp);
        prints("[1;32m�����j�L�Ӫ��n�� [1;36m�z���D��???[40;0m\n");
        prints("                   %s", msg);
        fgets(msg, 135, hintp);
        prints("                   %s", msg);
        pressanykey();
        fclose(hintp);
}

void
gorilla_title(char *gtitle)
{
 move(0,0);
 prints("[1;44;36m%040s                                      [m",gtitle);

}

#define MAX_SCORE       20
struct tetrisrec
{
char userid[IDLEN + 1];
time_t playtime;
char lasthost[16];
int u_score;
int u_level;
int u_rkill;
};
typedef struct tetrisrec tetrisrec;

int
tetris_cmp(b, a)
struct tetrisrec *a, *b;
{
  return (a->u_score - b->u_score);
}

game_score(swi)
int swi;
{

  FILE *fp;
  int score=0,level=0,rkill=0;
  int i,j;
  struct tetrisrec alltetris[MAX_SCORE+1];

  switch(swi){

    case 0:
       if(fp=fopen("etc/tetris.tmp","r"))
       {
          fscanf(fp,"%d %d %d ",&score,&level,&rkill);
          fclose(fp);
       }
       unlink("etc/tetris.tmp");
       break;
  }

  switch(swi){
     char genbuf[100];

     case 0:
             if((fp=fopen("etc/tetris.score","r+")) == NULL )
               fp=fopen("etc/tetris.score","w");
             for(i=0;i<MAX_SCORE;i++)
                if(fread(&alltetris[i],sizeof(struct tetrisrec),1,fp) == NULL)
                    break;

             strcpy(alltetris[i].userid, currentuser.userid);
             alltetris[i].playtime = time(0);
             strcpy(alltetris[i].lasthost, currentuser.lasthost);
             alltetris[i].u_score = score;
             alltetris[i].u_level = level;
             alltetris[i].u_rkill = rkill;

             qsort(alltetris, i+1, sizeof(struct tetrisrec), tetris_cmp);
             rewind(fp);
             for(j=0;j<i+1 && j<MAX_SCORE;j++)
               fwrite(&alltetris[j],sizeof(struct tetrisrec),1,fp);
             fclose(fp);
             clear();
             prints("[1;41;32m    �A������: [37m%d    [36m����: [37m%d    [33m���: [37m%d    [m\n",score,level,rkill);

             prints("[1;32;44m  �ϥΪ�id        [35m����   [33m����    [36m���     [37m�ӷ�                  [31m�ɶ�            [m");
            for(j=0;j<i+1 && j<MAX_SCORE;j++)
             {
               sprintf(genbuf,"[1;33m%-12s[37m%-9.9d [32m%-3.3d    [31m%-4.4d [36m%-17.16s[35m%s[m",alltetris[j].userid,
               alltetris[j].u_score,alltetris[j].u_level,alltetris[j].u_rkill,
               alltetris[j].lasthost,ctime(&alltetris[j].playtime));
               prints("%02d. %s",j+1,genbuf);
             }
             gorilla_anykey(NULL);
             break;


  }
  return 0;
}

void reload_cuser()
{
   get_record(PASSFILE,&currentuser,sizeof(userec),usernum);
}

void gcounter(char *filename,char *modes)
{
  FILE *fp;
  unsigned long visited;
  int year,mon,day;
  time_t now = time(0);
  struct tm *gtime;

  time(&now);
  gtime = localtime(&now);

  if(fopen(filename,"r")==NULL)
   {
    fp = fopen(filename,"w");
    fprintf(fp,"%d %d %d %d",gtime->tm_year + 1900,gtime->tm_mon+1,gtime->tm_mday,0);
    fclose(fp);
   }

  fp = fopen(filename,"r");
  fscanf(fp,"%d %d %d %d",&year,&mon,&day,&visited);
  fclose(fp);
  prints("[1m  [32m�z�O�q[44;35m %d[34m/[36m%d[34m/[37m%d [0;1;32m�_��[33m %d [32m�� [33m%s [32m���ϥΪ�\n[m",year,mon,day, visited++ ,modes);
  fp = fopen(filename,"w");
  fprintf(fp,"%d %d %d %d",year,mon,day,visited);
  fclose(fp);
}
