#include "bbs.h"
#ifdef lint
#include <sys/uio.h>
#endif
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

extern int  RMSG;
extern int RUNSH;
char buf2[STRLEN];
struct user_info *t_search();

int
get_msg(uid,msg,line)
char *msg,*uid;
int line;
{
        char genbuf[3];

        move(line,0);
        clrtoeol();
        prints("�e���H���G%s",uid);
        memset(msg,0,sizeof(msg));
        while(1)
        {
                getdata( line+1, 0, "���H : ", msg, 50, DOECHO, NULL,NA);
                if(msg[0]=='\0')
                        return NA;
                getdata( line+2, 0, "�T�w�n�e�X��(Y)�O�� (N)���n (E)�A�s��? [Y]: ",
                    genbuf, 2, DOECHO, NULL ,1);
                if(genbuf[0]=='e'||genbuf[0]=='E')
                        continue;
                if(genbuf[0]=='n'||genbuf[0]=='N')
                        return NA;
                else
                        return YEA;
        }
}

char
msgchar(uin)
struct user_info *uin;
{
    if ((uin->pager&ALLMSG_PAGER)) return ' ';
    if ((can_override(uin->userid,currentuser.userid)))
    {
        if((uin->pager&FRIENDMSG_PAGER))
                return 'O';
        else
                return '#';
    }
    return '*';
}

int
canmsg(uin)
struct user_info *uin;
{
    if ((uin->pager&ALLMSG_PAGER) || HAS_PERM(PERM_SYSOP)) return YEA;
    if ((uin->pager&FRIENDMSG_PAGER))
    {
        if(can_override(uin->userid,currentuser.userid))
                return YEA;
    }
    return NA;
}

s_msg()
{
      do_sendmsg(NULL,NULL,0,0);
}

int
show_allmsgs()
{
        char fname[STRLEN];

        setuserfile(fname,"msgfile");
        clear();
        modify_user_mode( LOOKMSGS);
        if(dashf(fname))
        {
                ansimore(fname,YEA);
                clear();
        }
        else
        {
                move(5,30);
                prints("�S�����󪺰T���s�b�I�I");
                pressanykey();
                clear();
        }
}

int
do_sendmsg(uentp,msgstr,mode,userpid)
struct user_info *uentp;
char msgstr[256];
int mode;
int userpid;/*�ˬd PID, �H�K�e���H */
{
    char uident[STRLEN] ,ret_str[20];
    FILE *fp;
    time_t now;
    struct user_info *uin ;
    char buf[80],msgbuf[256] ,*timestr;
    
    if(mode==0)
    {
            modify_user_mode( MSG );
            move(2,0) ; clrtobot();
    }
  if(uentp==NULL)
  {
    prints("<��J�ϥΪ̥N��>\n") ;
    move(1,0) ;
    clrtoeol() ;
    prints("�e�T����: ") ;
    creat_list() ;
    namecomplete(NULL,uident) ;
    if(uident[0] == '\0') 
    {
        clear() ;
        return 0 ;
    }
/*    if(searchuser(uident)==0 || tuid == usernum) 
    {
       if(uentp==NULL)
       {
        move(2,0) ;
        prints("���~���ϥΪ� ID\n") ;
        pressreturn() ;
        move(2,0) ;
        clrtoeol() ;
       }
        return -1 ;
    }*/
    uin=t_search(uident,NA);
    if(uin==NULL)
    {  
        move(2,0) ;
        prints("���ثe���b�u�W�A�άO�ϥΪ̥N����J���~...\n");
        pressreturn() ;
        move(2,0) ;
        clrtoeol() ;
        return -1 ;
    } 
    if(!canmsg(uin))
    {
        move(2,0) ;
        prints("���w�g���������T�����I�s��...\n");
        pressreturn() ;
        move(2,0) ;
        clrtoeol() ;
        return -1;
    }
  }else
  {
  if(!strcmp(uentp->userid,currentuser.userid))
      return 0;    
   uin=uentp;
   strcpy(uident,uin->userid);
  }
    if(msgstr==NULL)
    {
        if (!get_msg(uident,buf,1) ){
            move(1,0); clrtoeol();
            move(2,0); clrtoeol(); 
            return 0;
        }
     }

        now=time(0);
        timestr=ctime(&now)+11;
        *(timestr+8)='\0';
        strcpy(ret_str,"R �^�T��");
        if(msgstr==NULL||mode==2)
        {
               sprintf(msgbuf,"[0;1;44;36m%-12.12s[33m([36m%-5.5s[33m):[1;37;44m%-49.49s[31m(%s)[m[%dm\n", currentuser.userid, 
               timestr, (msgstr==NULL)?buf:msgstr,ret_str,uinfo.pid+100);
        }else
        {
           if(mode==0)
                   sprintf(msgbuf,"[1;5;44;33m������[1;36;44m %8.8s [33m�ɼs���G[m[1;37;44m%-55.55s[m\n",timestr,msgstr);
           else if(mode==1)
           {
                   sprintf(msgbuf,"[0;1;44;36m%-12.12s[37m([36m%-5.5s[37m) �ܽЧA[1;37;44m%-43.43s[31m(%s)[m[%dm\n", 
                   currentuser.userid, timestr, msgstr,ret_str,uinfo.pid+100);
           }else if(mode==3)
           {
               sprintf(msgbuf,"[0;1;44;32mBBS �t�γq�i[33m([36m%-5.5s[33m):[1;37;44m%-49.49s[31m(%s)[m\n",
               timestr, (msgstr==NULL)?buf:msgstr,ret_str);
           }
        }
        if(userpid)
        {
                if(userpid!=uin->pid)
                {
                        saveline(0, 0); /* Save line */
                        move(0,0);
                        clrtoeol();
                        prints("[1m���w�g���u...[m\n");
                        sleep(1);
                        saveline(0, 1); /* restore line */
                        return -1;
                }
        }
        sethomefile(buf,uident,"msgfile");
        if((fp=fopen(buf,"a"))==NULL)
                return -1;
        fputs(msgbuf,fp);
        fclose(fp);
        if(kill(uin->pid,SIGTTOU)==-1&&msgstr==NULL)
        {
            prints("\n���w�g���u....\n") ; pressreturn();
            clear();
            return -1;
        }
        if(msgstr==NULL)
        {
            prints("\n�w�e�X�T��....\n") ; pressreturn();
            clear() ;
        }
    return 1 ;
}

int
dowall(uin)
struct user_info *uin;
{
        if (!uin->active || !uin->pid) return -1;
        move(1,0);
        clrtoeol();
        prints("[1;32m���� %s �s��.... Ctrl-D ����惡�� User �s���C[m",uin->userid); 
        refresh();
        do_sendmsg(uin,buf2,0,uin->pid);
}


int
wall()
{
    modify_user_mode( MSG );
    move(2,0) ; clrtobot();
    if (!get_msg("�Ҧ��ϥΪ�",buf2,1) ){
         move(1,0); clrtoeol();
         move(2,0); clrtoeol();
         return 0;
    }
    if( apply_ulist( dowall ) == -1 ) {
        move(2,0);
        prints( "�S������ϥΪ̤W�u\n" );
        pressanykey();
    }
    prints("\n�w�g�s������....\n");
    pressanykey();
}


void
r_msg()
{
    FILE *fp;
    char buf[256] ;
    char msg[256] ;
    char fname[STRLEN] ;
    int line,tmpansi;
    int y,x,ch;

    signal(SIGTTOU,r_msg) ;
    getyx(&y,&x);
    tmpansi=showansi;
    showansi=1;
    if(uinfo.mode==TALK)
        line=t_lines/2-1;
    else
        line=0;
    if(DEFINE(DEF_SOUNDMSG))
    {
            bell();
            bell();
    }
    setuserfile(fname,"msgfile");
    if((fp=fopen(fname,"r"))==NULL)
        return;
    while(fgets( buf, 256, fp )!=NULL)
    {
        strcpy(msg,buf);
    }
    fclose(fp);
    RMSG=YEA;
    saveline(line, 0);
    move(line,0); clrtoeol(); prints("%s",msg); refresh();
    oflush() ;
   ch=0;
   while(ch!='\n'&&ch!='\r'&&ch!=KEY_ESC)
   {
/*      read(0,&ch,1);*/
        ch=igetkey();
    if(ch=='\n'||ch=='\r')
        break;
    if(ch==Ctrl('R')||ch=='r'||ch=='R')
    {
          struct user_info *uin ;
          char msgbuf[STRLEN];
          int good_id,send_pid;
          char *ptr,usid[STRLEN];

          ptr=strrchr(msg,'[');
          send_pid=atoi(ptr+1);
          if(send_pid>100)
                send_pid-=100;
          ptr=strtok(msg+12," [");
          if(ptr==NULL|| !strcmp(ptr,currentuser.userid))
                good_id=NA;
          else
          {
                strcpy(usid,ptr);
                uin=t_search(usid,send_pid);
                if(uin==NULL)
                        good_id=NA;
                else
                        good_id=YEA;
          }
          if(good_id==YEA)
          {
                  int userpid;
                  userpid=uin->pid;
                  move(line,0);
                  clrtoeol();
                  sprintf(msgbuf,"�^�T���� %s: ",usid);
                  getdata(line,0,msgbuf,buf,49,DOECHO,NULL,YEA);
                  if(buf[0]!='\0')
                  {
                        do_sendmsg(uin,buf,2,userpid);
                        sprintf(msgbuf,"[1m���A�e�X�T���F[m");
                  }else
                        sprintf(msgbuf,"[1m�ŰT��, �ҥH���e�X.[m");

          }else
          {
                  sprintf(msgbuf,"[1m�䤣�X�o�T�����H[m");
          }
          move(line,0);
          clrtoeol();
          refresh();
          prints("%s",msgbuf);
          refresh();
          sleep(1);
          break;
    }
   }
    showansi=tmpansi;
    saveline(line, 1); /* restore line */
    move(y,x);
    refresh();
    RMSG=NA;
    return ;
}

int
friend_login_wall(pageinfo)
struct user_info *pageinfo;
{
        char msg[STRLEN];

        if( !pageinfo->active || !pageinfo->pid )
                return 0;
        if (can_override(pageinfo->userid,currentuser.userid)) {
                if(getuser(pageinfo->userid)<=0)
                        return 0;
                if(!(lookupuser.userdefine&DEF_LOGININFORM))
                        return 0;
                if(!strcmp(pageinfo->userid,currentuser.userid))
                        return 0;
                sprintf(msg,"�A���n�B�� %s �w�g�W���o�I",currentuser.userid);
                do_sendmsg(pageinfo,msg,2,pageinfo->pid);
        }
        return 0;
}
