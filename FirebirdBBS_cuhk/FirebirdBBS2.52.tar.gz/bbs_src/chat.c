/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"

#ifdef lint
#include <sys/uio.h>
#endif

#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "chat.h"


#define MAXLASTCMD 6
char chatroom[IDLEN];           /* Chat-Room Name */
int chatline;                   /* Where to display message now */
int stop_line;                  /* next line of bottom of message window area */
FILE *rec;
int recflag=0;
char buftopic[STRLEN];
char chat_station[20];

extern char page_requestor[];
extern int talkrequest;
extern char *modestring();
extern char pagerchar();
extern void t_pager();
/*
extern char *Cdate();
*/
void set_rec();
struct user_info *t_search();

#define b_lines t_lines-1
#define cuser currentuser
#define CHAT_LOGIN_OK       "OK"
#define CHAT_LOGIN_EXISTS   "EX"
#define CHAT_LOGIN_INVALID  "IN"
#define CHAT_LOGIN_BOGUS    "BG"
char *msg_seperator = "\
�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w";
char *msg_shortulist = "[1;33;44m\
 �ϥΪ̥N��    �ثe���A  �x �ϥΪ̥N��    �ثe���A  �x �ϥΪ̥N��    �ثe���A [m";
extern char BoardName[];

char *
Cdate(clock)
  time_t *clock;
{
  static char foo[22];
  struct tm *mytm = localtime(clock);

  strftime(foo, 22, "%D %T %a", mytm);
  return (foo);
}

void
printchatline(str)
  char *str;
{
  move(chatline, 0);
  clrtoeol();
  outs(str);
  outc('\n');
  if(recflag==1)
          fprintf(rec,"%s\n",str);
  if (++chatline == stop_line)
    chatline = 2;
  move(chatline, 0);
  clrtoeol();
  outs("��");
}


void
chat_clear()
{
  for (chatline = 2; chatline < stop_line; chatline++)
  {
    move(chatline, 0);
    clrtoeol();
  }
  chatline = stop_line - 1;
  printchatline("");
}


void
print_chatid(chatid)
  char *chatid;
{
  move(b_lines, 0);
  outs(chatid);
  outc(':');
}


int
chat_send(fd, buf)
  int fd;
  char *buf;
{
  int len;

  sprintf(genbuf, "%s\n", buf);
  len = strlen(genbuf);
  return (send(fd, genbuf, len, 0) == len);
}

int
chat_recv(fd, chatid)
  int fd;
  char *chatid;
{
  static char buf[512];
  static int bufstart = 0;
  int c, len;
  char *bptr;

  len = sizeof(buf) - bufstart - 1;
  if ((c = recv(fd, buf + bufstart, len, 0)) <= 0)
    return -1;
  c += bufstart;
  bptr = buf;
  while (c > 0)
  {
    len = strlen(bptr) + 1;
    if (len > c && len < (sizeof buf / 2))
      break;

    if (*bptr == '/')
    {
      switch (bptr[1])
      {
      case 'c':
        chat_clear();
        break;
      case 'n':
        strncpy(chatid, bptr + 2, 8);
        print_chatid(chatid);
        clrtoeol();
        break;
      case 'r':
        strncpy(chatroom, bptr + 2, IDLEN - 1);
        break;
      case 't':
        move(0, 0);
        clrtoeol();
        sprintf(genbuf, "�ж��G [32m%s", chatroom);
        strcpy(buftopic,bptr+2);
        prints("[1;44;33m %-21s  [33m���D�G[36m%-47s[5;31m%6s[m", genbuf, bptr + 2,(recflag==1)?"������":"      ");
      }
    }
    else{
      printchatline(bptr);
    }

    c -= len;
    bptr += len;
  }

  if (c > 0)
  {
    strcpy(genbuf, bptr);
    strcpy(buf, genbuf);
    bufstart = len - 1;
  }
  else
    bufstart = 0;
  return 0;
}


int
ent_chat(chatbuf)
char *chatbuf;
{
  char inbuf[80], chatid[20], lastcmd[MAXLASTCMD][80];
  struct sockaddr_in sin;
  struct hostent *h;
  int cfd, cmdpos, ch;
  int chatroom,chatport;
  int currchar;
  int newmail;
  extern int talkidletime;
  extern int dumb_term;
  int page_pending = NA;
  int chatting = YEA;

  chatroom=atoi(chatbuf);
  switch(chatroom)
  {
        case 1:
          strcpy(chat_station,CHATNAME1);
          modify_user_mode(CHAT1);
          chatport=CHATPORT1;
          break;
        case 2:
          strcpy(chat_station,CHATNAME2);
          modify_user_mode(CHAT2);
          chatport=CHATPORT2;
          break;
        case 3:
          strcpy(chat_station,CHATNAME3);
          modify_user_mode(CHAT3);
          chatport=CHATPORT3;
          break;
        case 4:
          strcpy(chat_station,CHATNAME4);
          modify_user_mode(CHAT4);
          chatport=CHATPORT4;
          break;
  }

  gethostname(inbuf, STRLEN);
  if (!(h = gethostbyname(inbuf)))
  {
    perror("gethostbyname");
    return -1;
  }
  memset(&sin, 0, sizeof sin);
  sin.sin_family = PF_INET;
  /* sin.sin_family = h->h_addrtype; */
  memcpy(&sin.sin_addr, h->h_addr, h->h_length);
  sin.sin_port = htons(chatport);
  cfd = socket(sin.sin_family, SOCK_STREAM, 0);

  if (connect(cfd, (struct sockaddr *) & sin, sizeof sin))
  {
    char runchatbuf[STRLEN];

    close(cfd);
    move(1,0);
    clrtoeol();
    prints("�}�Ҳ�ѫ�...");
    sprintf(runchatbuf,"bin/chatd %d",chatroom);
    system(runchatbuf);
    sleep(1);
    cfd = socket(sin.sin_family, SOCK_STREAM, 0);
    if ((connect(cfd, (struct sockaddr *) & sin, sizeof sin)))
    {
      perror("connect failed");
      return -1;
    }
  }

  while (1)
  {
    getdata(2, 0, "�п�J��ѥN���G", inbuf, 9, DOECHO, NULL,YEA);
    sprintf(chatid, "%s", ((inbuf[0]!='\0'&&inbuf[0]!='\n'&&inbuf[0]!='/') ? inbuf : cuser.userid));
    chatid[8] = '\0';

    sprintf(inbuf, "/! %d %d %s %s %d", uinfo.uid,
      cuser.userlevel, cuser.userid, chatid, uinfo.invisible);
    chat_send(cfd, inbuf);
    if (recv(cfd, inbuf, 3, 0) != 3)
    {
      return 0;
    }
    move(3, 0);
    if (!strcmp(inbuf, CHAT_LOGIN_OK))
      break;
    else if (!strcmp(inbuf, CHAT_LOGIN_EXISTS))
      prints("�o�ӥN���w�g���H�ΤF");
    else if (!strcmp(inbuf, CHAT_LOGIN_INVALID))
      prints("�o�ӥN���O���~��");
    else
      prints("�A�w�g���t�@�ӵ����i�J����ѫǡC");
    clrtoeol();
    refresh();
    sleep(1);
    bell();
  }
  endmsg();
  add_io(cfd, 0);

  newmail = cmdpos = currchar = 0;
  memset(lastcmd, 0, MAXLASTCMD * 80);

  uinfo.in_chat = YEA;
  strcpy(uinfo.chatid, chatid);
  update_utmp();

  clear();
  chatline = 2;
  strcpy(inbuf, chatid);
  stop_line = t_lines - 2;
  move(stop_line, 0);
  outs(msg_seperator);
  move(1, 0);
  outs(msg_seperator);
  print_chatid(chatid);
  memset(inbuf, 0, 80);

  while (chatting)
  {
    move(b_lines, currchar + 10);
    ch = igetkey();
    talkidletime=0;
    if (talkrequest)
      page_pending = YEA;
    if (page_pending)
      page_pending = servicepage(0, NULL);

    switch (ch)
    {
    case KEY_UP:
      cmdpos += MAXLASTCMD - 2;

    case KEY_DOWN:
      cmdpos++;
      cmdpos %= MAXLASTCMD;
      strcpy(inbuf, lastcmd[cmdpos]);
      move(b_lines, 10);
      clrtoeol();
      outs(inbuf);
      currchar = strlen(inbuf);
      continue;

    case KEY_LEFT:
      if (currchar)
        --currchar;
      continue;

    case KEY_RIGHT:
      if (inbuf[currchar])
        ++currchar;
      continue;
    }

    if (!newmail && chkmail(0))
    {
      newmail = 1;
      printchatline("[1;32m�� [31m���I�l�t�S�ӤF...[m");
    }

    if (ch == I_OTHERDATA)      /* incoming */
    {
      if (chat_recv(cfd, chatid) == -1)
        break;
      continue;
    }

#ifdef BIT8
    if (isprint2(ch))
#else
    if (isprint(ch))
#endif

    {
      if (currchar < 68)
      {
        if (inbuf[currchar])
        {                       /* insert */
          int i;
          for (i = currchar; inbuf[i] && i < 68; i++);
          inbuf[i + 1] = '\0';
          for (; i > currchar; i--)
            inbuf[i] = inbuf[i - 1];
        }
        else
        {                       /* append */
          inbuf[currchar + 1] = '\0';
        }
        inbuf[currchar] = ch;
        move(b_lines, currchar + 10);
        outs(&inbuf[currchar++]);
      }
      continue;
    }

    if (ch == '\n' || ch == '\r')
    {
      if (currchar)
      {
        chatting = chat_cmd(inbuf, cfd);
        if (chatting == 0)
          chatting = chat_send(cfd, inbuf);
        if (!strncmp(inbuf, "/b", 2))
          break;

        for (cmdpos = MAXLASTCMD - 1; cmdpos; cmdpos--)
          strcpy(lastcmd[cmdpos], lastcmd[cmdpos - 1]);
        strcpy(lastcmd[0], inbuf);

        inbuf[0] = '\0';
        currchar = cmdpos = 0;
        move(b_lines, 10);
        clrtoeol();
      }
      continue;
    }

    if (ch == Ctrl('H') || ch == '\177')
    {
      if (currchar)
      {
        currchar--;
        inbuf[69] = '\0';
        memcpy(&inbuf[currchar], &inbuf[currchar + 1], 69 - currchar);
        move(b_lines, currchar + 10);
        clrtoeol();
        outs(&inbuf[currchar]);
      }
      continue;
    }
    if (ch == Ctrl('Z'))
    {
      inbuf[0] = '\0';
      currchar = 0;
      move(b_lines, 10);
      clrtoeol();
      continue;
    }

    if (ch == Ctrl('C') || ch == Ctrl('D'))
    {
      chat_send(cfd, "/b");
      if(recflag==1)
      {
        set_rec();
      }
      break;
    }
  }
  close(cfd);
  add_io(0, 0);
  uinfo.in_chat = NA;
  uinfo.chatid[0] = '\0';
  update_utmp();
  clear();
  refresh();
  return 0;
}


int
printuserent(uentp)
  struct user_info *uentp;
{
  static char uline[256];
  static int cnt;
  char pline[50];

  if (!uentp)
  {
    if (cnt)
      printchatline(uline);
    bzero(uline, 256);
    cnt = 0;
    return 0;
  }
  if (!uentp->active || !uentp->pid)
    return 0;
  if (!HAS_PERM(PERM_SYSOP) && uentp->invisible)
    return 0;

#if 0
  if (kill(uentp->pid, 0) == -1)
    return 0;
#endif
  
  sprintf(pline, " %s%-13s[m%c%-10.10s",myfriend(uentp->userid)?"[1;32m":"", uentp->userid, uentp->invisible ? '#' : ' ',
    modestring(uentp->mode, uentp->destuid, 0, NULL));
  if (cnt < 2)
    strcat(pline, "�x");
  strcat(uline, pline);
  if (++cnt == 3)
  {
    printchatline(uline);
    memset(uline, 0, 256);
    cnt = 0;
  }
  return 0;
}


void
chat_help(arg)
char *arg;
{
    char buf[256];
    FILE *fp;

  if (strstr(arg, " op"))
  {
    if((fp=fopen("help/chatophelp","r"))==NULL)
        return;
    while(fgets(buf, 255, fp) != NULL)
    {
        printchatline(buf);
    }
    fclose(fp);
    if(HAS_PERM(PERM_SYSOP))
            printchatline("  [/s]etrec           - �Ұʩ���������");
  }
  else
  {
    if((fp=fopen("help/chathelp","r"))==NULL)
        return;
    while(fgets(buf, 255, fp) != NULL)
    {
        char *ptr;

        ptr=strstr(buf,"\n");
        *ptr='\0';
        printchatline(buf);
    }
    fclose(fp);
  }
}

void
call_user(arg)
char *arg;
{
  char *userid,msg[STRLEN*2];
  struct user_info *uin ;
  int good_id;

  userid=strrchr(arg,' ');
  if(userid==NULL)
  {
        printchatline("[1;37m�� [32m�п�J�A�n�ܽЪ� ID[37m ��[m");
        return;
  }else
        userid+=1;
  if(!strcasecmp(userid,currentuser.userid)) 
        good_id=NA;
  else
  {
        uin=t_search(userid,NA);
        if(uin==NULL)
                good_id=NA;
        else
                good_id=YEA;
  }
  if(good_id==YEA)
  {
          sprintf(msg,"�� %s �� %s �]�[����",chat_station,chatroom);
          do_sendmsg(uin,msg,1,uin->pid);
          sprintf(msg,"[1;37m�w�g���A�ܽ� [32m%s[37m �F[m",uin->userid);
  }else
          sprintf(msg,"[1;32m%s[37m �èS���W��[m",userid);
  printchatline(msg);
}


void
chat_date()
{
  time_t thetime;

  time(&thetime);
  sprintf(genbuf, "[1m %s�зǮɶ�: [32m%s[m", BoardName, Cdate(&thetime));
  printchatline(genbuf);
}


void
chat_users()
{
  printchatline("");
  sprintf(genbuf,"[1m�i [36m%s [37m���X�ȦC�� �j[m", BoardName);
  printchatline(genbuf);
  printchatline(msg_shortulist);

  if (apply_ulist(printuserent) == -1)
  {
    printchatline("[1m�ŵL�@�H[m");
  }
  printuserent(NULL);
}

void
set_rec()
{
        char fname[STRLEN];
        time_t now;
        
        now=time(0);
        if(!HAS_PERM(PERM_SYSOP))
                return;

        sprintf(fname,"etc/%s.chat",currentuser.userid);
        if(recflag==0)
        {
                if((rec=fopen(fname,"w"))==NULL)
                        return;

                printchatline("[1;5;32m�}�l����...[m");
                recflag=1;
                move(0, 0);
                clrtoeol();
                sprintf(genbuf, "�ж��G [32m%s", chatroom);
                prints("[1;44;33m %-21s  [33m���D�G[36m%-47s[5;31m%6s[m", genbuf, buftopic ,(recflag==1)?"������":"      ");

                fprintf(rec,"���q�� %s",currentuser.userid);
                fprintf(rec,"�ҿ��U�A�ɶ��G %s",ctime(&now));
        }else
        {
                recflag=0;
                move(0, 0);
                clrtoeol();
                sprintf(genbuf, "�ж��G [32m%s", chatroom);
                prints("[1;44;33m %-21s  [33m���D�G[36m%-47s[5;31m%6s[m", genbuf, buftopic ,(recflag==1)?"������":"      ");

                printchatline("[1;5;32m��������...[m");
                fprintf(rec,"�����ɶ��G%s\n",ctime(&now));
                fclose(rec);
                mail_file(fname,currentuser.userid,"�������G");
                unlink(fname);
        }
}


void
setpager()
{
        char buf[STRLEN];

        t_pager();
        sprintf(buf,"[1;32m�� [31m�I�s�� %s �F[m",(uinfo.pager&ALL_PAGER)?"���}":"����");
        printchatline(buf);

}

struct chat_command chat_cmdtbl[] = {
  {"pager",setpager},
  {"help", chat_help},
  {"clear", chat_clear},
  {"date", chat_date},
  {"users", chat_users},
  {"set",set_rec},
  {"call",call_user},
  {NULL, NULL}
};

int
chat_cmd_match(buf, str)
  char *buf;
  char *str;
{
  while (*str && *buf && !isspace(*buf))
  {
    if (tolower(*buf++) != *str++)
      return 0;
  }
  return 1;
}


int
chat_cmd(buf)
  char *buf;
{
  int i;

  if (*buf++ != '/')
    return 0;

  for (i = 0; chat_cmdtbl[i].cmdname; i++)
  {
    if (*buf!='\0'&&chat_cmd_match(buf, chat_cmdtbl[i].cmdname))
    {
      chat_cmdtbl[i].cmdfunc(buf);
      return 1;
    }
  }
  return 0;
}
