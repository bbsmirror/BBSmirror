/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#define EXTERN
#include "bbs.h"
int use_define=0;
extern int iscolor;

int
modify_user_mode( mode )
int     mode;
{
    uinfo.mode = mode;
    update_ulist( &uinfo, utmpent );
    return 0;
}
/*
int
x_csh()
{
    int save_pager;
    clear() ;
    refresh() ;
    reset_tty() ;
    save_pager = uinfo.pager;
    uinfo.pager = 0 ;
    update_utmp();
    report("shell out");
#ifdef SYSV
    do_exec("sh", NULL) ;
#else
    do_exec("csh", NULL);
#endif
    restore_tty() ;
    uinfo.pager = save_pager;
    update_utmp();
    clear() ;
    return 0 ;
}
*/
int
showperminfo( pbits, i )
int     pbits, i;
{
    char        buf[ STRLEN ];

    sprintf( buf, "%c. %-30s %3s", 'A' + i, (use_define)?user_definestr[i]:permstrings[i],
            ((pbits >> i) & 1 ? "ON" : "OFF"));
    move( i+6-(( i>15)? 16:0) , 0+(( i>15)? 40:0) );
    prints( buf );
    refresh();
    return YEA;
}

unsigned int
setperms(pbits,prompt,numbers,showfunc)
unsigned int pbits;
char *prompt;
int numbers;
int (*showfunc)();
{
    int lastperm = numbers - 1;
    int i, done = NA;
    char choice[3];

    move(4,0);
    prints("�Ы��U�A�n���N�X�ӳ]�w%s�A�� Enter ����.\n",prompt);
    move(6,0);
    clrtobot();
/*    pbits &= (1 << numbers) - 1;*/
    for (i=0; i<=lastperm; i++) {
        (*showfunc)( pbits, i,NA);
    }
    while (!done) {
        getdata(t_lines-1, 0, "���(ENTER ����): ",choice,2,DOECHO,NULL,YEA);
        *choice = toupper(*choice);
        if (*choice == '\n' || *choice == '\0') done = YEA;
        else if (*choice < 'A' || *choice > 'A' + lastperm) bell();
        else {
            i = *choice - 'A';
            pbits ^= (1 << i);
            if((*showfunc)( pbits, i ,YEA)==NA)
            {
                   pbits ^= (1 << i);
            }
        }
    }
    return( pbits );
}

int
x_level()
{
    int id ;
    int newlevel;

    modify_user_mode( ADMIN );
    if(!check_systempasswd())
    {
        return;
    }
    clear();
    move(0,0) ;
    prints("Change User Priority\n") ;
    clrtoeol() ;
    move(1,0) ;
    usercomplete("Enter userid to be changed: ",genbuf) ;
    if(genbuf[0] == '\0') {
        clear() ;
        return 0 ;
    }
    if(!(id = getuser(genbuf))) {
        move(3,0) ;
        prints("Invalid User Id") ;
        clrtoeol() ;
        pressreturn() ;
        clear() ;
        return 0 ;
    }
    move(1,0);
    clrtobot();
    move(2,0);
    prints("Set the desired permissions for user '%s'\n", genbuf);
    newlevel = setperms(lookupuser.userlevel,"�v��",NUMPERMS,showperminfo);  
    move(2,0);
    if (newlevel == lookupuser.userlevel)
        prints("User '%s' level NOT changed\n", lookupuser.userid);
    else {
        lookupuser.userlevel = newlevel;
        {
                char        secu[STRLEN];
                sprintf(secu,"�ק� %s ���v��",lookupuser.userid);
                securityreport(secu);
         }

        substitute_record(PASSFILE,&lookupuser,sizeof(struct userec),id) ;
        prints("User '%s' level changed\n",lookupuser.userid) ;
        sprintf(genbuf, "changed permissions for %s", lookupuser.userid);
        report(genbuf);
    }
    pressreturn() ;
    clear() ;
    return 0 ;
}

int
x_userdefine()
{
    int id ;
    int newlevel;
    extern int nettyNN;

    modify_user_mode( USERDEF );
    if(!(id = getuser(currentuser.userid))) {
        move(3,0) ;
        prints("���~�� �ϥΪ� ID...") ;
        clrtoeol() ;
        pressreturn() ;
        clear() ;
        return 0 ;
    }
    move(1,0);
    clrtobot();
    move(2,0);
    use_define=1;
    newlevel = setperms(lookupuser.userdefine,"�v��",NUMDEFINES,showperminfo);  
    move(2,0);
    if (newlevel == lookupuser.userdefine)
        prints("�ѼƨS���ק�...\n");
    else {
        lookupuser.userdefine = newlevel;
        currentuser.userdefine=newlevel;
        substitute_record(PASSFILE,&lookupuser,sizeof(struct userec),id) ;
        uinfo.pager|=FRIEND_PAGER;
        if(!(uinfo.pager&ALL_PAGER))
        {
                if(!DEFINE(DEF_FRIENDCALL))
                        uinfo.pager&=~FRIEND_PAGER;
        }
        uinfo.pager&=~ALLMSG_PAGER;
        uinfo.pager&=~FRIENDMSG_PAGER;
        if(DEFINE(DEF_FRIENDMSG))
        {
                uinfo.pager|=FRIENDMSG_PAGER;
        }
        if(DEFINE(DEF_ALLMSG))
        {
                uinfo.pager|=ALLMSG_PAGER;
                uinfo.pager|=FRIENDMSG_PAGER;
        }
        update_utmp();
        if(DEFINE(DEF_ACBOARD))
                nettyNN=NNread_init();
        prints("�s���ѼƳ]�w����...\n\n") ;
    }
    iscolor=(DEFINE(DEF_COLOR))?1:0;
    pressreturn() ;
    clear() ;
    use_define=0;
    return 0 ;
}




int
x_cloak()
{
    modify_user_mode( GMENU ); 
    report("toggle cloak");
    if(uinfo.invisible==YEA)
    {
                update_ulistnum(1,-1);
                update_ulistnum(0,1);
    }else
    {
                update_ulistnum(1,1);
                update_ulistnum(0,-1);
    }
    uinfo.invisible = (uinfo.invisible)?NA:YEA ;
    update_utmp();
    if (!uinfo.in_chat) {
        move(1,0) ;
        clrtoeol();
        prints( "�����N (cloak) �w�g%s�F!",
                (uinfo.invisible) ? "�Ұ�" : "����" ) ;
        pressreturn();
    }
    return 0 ;
}

int
x_date()
{
    time_t t;

    modify_user_mode( XMENU ); 
    clear();
        move(8,0);
        time(&t);
        prints("�ثe�t�Τ���P�ɶ�: %s", ctime(&t));
        clrtoeol();
        pressreturn();
        return 0;
}

void
x_edits()
{
    int aborted;
    char ans[7],buf[STRLEN];
    int ch,num;
    char *e_file[]={"plans","signatures","notes","logout",NULL};    
    char *explain_file[]={"�ӤH������","ñ�W��","�ۤv���Ƨѿ�","�������e��",NULL};

    modify_user_mode( GMENU ); 
    clear();
    move(1,0);
    prints("�s�׭ӤH�ɮ�\n\n");
    for(num=0;e_file[num]!=NULL&&explain_file[num]!=NULL;num++)
    {
        prints("[[1;32m%d[m] %s\n",num+1,explain_file[num]);
    }
        prints("[[1;32m%d[m] �����Q��\n",num+1);

    getdata(num+5,0,"�A�n�s�׭��@���ӤH�ɮ�: ",ans,2,DOECHO,NULL,YEA);
    if(ans[0]-'0'<=0 || ans[0]-'0'>num|| ans[0]=='\n'|| ans[0]=='\0')
        return;

    ch=ans[0]-'0'-1;
    setuserfile(genbuf,e_file[ch]);
    move(3,0);
    clrtobot();
    sprintf(buf,"(E)�s�� (D)�R�� %s? [E]: ",explain_file[ch]);
    getdata(3,0,buf,ans,2,DOECHO,NULL,YEA);
    if (ans[0] == 'D' || ans[0] == 'd') {
        unlink(genbuf);
        move(5,0);
        prints("%s �w�R��\n",explain_file[ch]);
        sprintf(buf,"delete %s",explain_file[ch]);
        report(buf);
        pressreturn();
        clear();
        return;
    }
    modify_user_mode( EDITUFILE);
    aborted = vedit(genbuf, NA);
    clear();
    if (!aborted) {
        prints("%s ��s�L\n",explain_file[ch]);
        sprintf(buf,"edit %s",explain_file[ch]);
        if(!strcmp(e_file[ch],"signatures"))
        {
            set_numofsig();
            prints("�t�έ��s�]�w�H��Ū�J�A��ñ�W��...");
        }
        report(buf);
    }else
        prints("%s �����ק�\n",explain_file[ch]);
    pressreturn();
}

void
a_edits()
{
    int aborted;
    char ans[7],buf[STRLEN];
    int ch,num;
    char *e_file[]={"../Welcome","../vote/notes","issue","movie","logout","menu.ini",
                    "mailcheck","s_fill","f_fill","smail","fmail","../.badname",
                     NULL};    
    char *explain_file[]={"Welcome","���γƧѿ�","�i���w����","���ʬݪ�","�����e��",
                          "menu.ini","�����T�{��","���U�槹����","���U�楢����"
                          ,"�����T�{������","�����T�{������","���i���U�� ID",
                          NULL};

    modify_user_mode( ADMIN ); 
    if(!check_systempasswd())
    {
        return;
    }
    clear();
    move(1,0);
    prints("�s�רt���ɮ�\n\n");
    for(num=0;e_file[num]!=NULL&&explain_file[num]!=NULL;num++)
    {
        prints("[[1;32m%2d[m] %s\n",num+1,explain_file[num]);
    }
        prints("[[1;32m%2d[m] �����Q��\n",num+1);

    getdata(num+5,0,"�A�n�s�׭��@���t���ɮ�: ",ans,3,DOECHO,NULL,YEA);
    ch=atoi(ans);
    if(!isdigit(ans[0])||ch<=0 || ch>num|| ans[0]=='\n'|| ans[0]=='\0')
        return;
    ch-=1;
    sprintf(genbuf,"etc/%s",e_file[ch]);
    move(3,0);
    clrtobot();
    sprintf(buf,"(E)�s�� (D)�R�� %s? [E]: ",explain_file[ch]);
    getdata(3,0,buf,ans,2,DOECHO,NULL,YEA);
    if (ans[0] == 'D' || ans[0] == 'd') {
      {
          char        secu[STRLEN];
          sprintf(secu,"�R���t���ɮסG%s",explain_file[ch]);
          securityreport(secu);
      }
        unlink(genbuf);
        move(5,0);
        prints("%s �w�R��\n",explain_file[ch]);
        sprintf(buf,"delete %s",explain_file[ch]);
        report(buf);
        pressreturn();
        clear();
        return;
    }
    modify_user_mode( EDITSFILE);
    aborted = vedit(genbuf, NA);
    clear();
    if (aborted!=-1) {
        prints("%s ��s�L",explain_file[ch]);
        sprintf(buf,"edit %s",explain_file[ch]);
        report(buf);
        {
          char        secu[STRLEN];
          sprintf(secu,"�ק�t���ɮסG%s",explain_file[ch]);
          securityreport(secu);
        }

        if(!strcmp(e_file[ch],"../Welcome"))
        {
                unlink("Welcome.rec");
                prints("\nWelcome �O���ɧ�s");
        }
    }
    pressreturn();
}

#ifdef BBSDOORS

void
ent_bnet()  /* Bill Schwartz */
{
    int save_pager = uinfo.pager;
    uinfo.pager = -1;
    report("BBSNet Enter") ;
    modify_user_mode( BBSNET );
    /* bbsnet.sh is a shell script that can be customized without */
    /* having to recompile anything.  If you edit it while someone */
    /* is in bbsnet they will be sent back to the xyz menu when they */
    /* leave the system they are currently in. */

    reset_tty() ;
    do_exec("bbsnet.sh",NULL) ;
    restore_tty() ;
    uinfo.pager = save_pager;
    report("BBSNet Exit") ;
    clear() ;
}

#endif
