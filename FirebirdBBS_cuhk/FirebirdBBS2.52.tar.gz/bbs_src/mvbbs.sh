#!/bin/sh
mv /home/bbs/bin/bbs /home/bbs/bin/bbs.x
mv /home/bbs/bbs_src/bbs /home/bbs/bin/
