#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "keymap.h"

#define MAINTITLE	"������u (0)Announce ���G��{�� v3.0"
#define SEARCHFILE	".Search"
#define EDITOR		"ve"

#define	STRLEN		128
#define MAXLEN		1024
#define MAXITEMS	256
#define PAGESIZE	18

enum { NOBODY, MANAGER, SYSOP };
enum { ADDITEM, ADDGROUP, ADDMAIL };

typedef struct {
    char	title[ STRLEN ];
    char	fname[ STRLEN ];
    int		date;
} ITEM; 

typedef struct {
    ITEM	*item[ MAXITEMS ];
    char	mtitle[ STRLEN ];
    char	pwd[ MAXLEN ];
    int		num, page, now;
    int		level;
} MENU;

char	*SYSOPLIST[] = { "password", "NTfool", "SmallPig", "Excellent", "netty", 
			 NULL };
char	genbuf[ MAXLEN ], username[ STRLEN ];
char	copytitle[ STRLEN ], copyfname[ STRLEN ], copyfile[ MAXLEN ];
int	fmode;

checksysop()
{
    char	*uname;
    int		n;

    if( (uname = getenv( "USER" )) == NULL ) {
	username[0] = '\0';
    } else {
	strcpy( username, uname );
	for( n = 0; SYSOPLIST[n] != NULL; n++ )
	    if( strcmp( username, SYSOPLIST[n] ) == 0 )
		return SYSOP;
    }
    return NOBODY;
}

pause()
{
    char        junk[ STRLEN ];

    printf( "�Ы� [Enter] ���~�� ..." );
    igetstr( junk, sizeof(junk) );
}

prompt( mesg, buf, maxlen )
char	*mesg, *buf;
{
    gotoxy( 1, 23 );
    clreol();
    printf( "%s", mesg );
    return igetstr( buf, maxlen );
}

message( mesg )
char	*mesg;
{
    gotoxy( 1, 23 );
    clreol();
    printf( "%s ...", mesg );
    return igetkey();
}

mksure( mesg )
char	*mesg;
{
    gotoxy( 1, 23 );
    clreol();
    printf( "%s", mesg );
    igetstr( genbuf, sizeof(genbuf) );
    if( strcmp( genbuf, "Y" ) == 0 ||
	strcmp( genbuf, "y" ) == 0 )  return 1;
    return 0;
}

errmsg( mesg )
char	*mesg;
{
    gotoxy( 1, 24 );
    clreol();
    printf( "%s", mesg );
    igetkey();
}

execute( command, argument )
char	*command, *argument;
{
    sprintf( genbuf, "%s %s", command, argument );
    system( genbuf );
}

tty_exec( command, argument )
char    *command, *argument;
{
    clrscr();
    reset_tty();
    sprintf( genbuf, "%s %s", command, argument );
    system( genbuf );
    restore_tty();
}

valid( str )
char	*str;
{
    char	ch;

    while( (ch = *str++) != '\0' ) {
	if( (ch >= 'A' && ch <= 'Z') ||
	    (ch >= 'a' && ch <= 'z') ||
	    (ch >= '0' && ch <= '9') ||
	    strchr( "@[]-._", ch ) != NULL ) {
	    ;
	} else {
	    return 0;
	}
    }
    return 1;
}

additem( pm, title, fname )
MENU	*pm;
char	*title, *fname;
{
    ITEM	*newitem;

    if( pm->num < MAXITEMS ) {
	newitem = (ITEM *) malloc( sizeof(ITEM) );
	strcpy( newitem->title, title );
	strcpy( newitem->fname, fname );
	newitem->date = 0;
	pm->item[ (pm->num)++ ] = newitem;
    }
}  

loadnames( pm )
MENU	*pm;
{
    FILE	*fn;
    char	title[ STRLEN ], fname[ STRLEN ];
    char	buf[ MAXLEN ], *ptr;

    pm->num = 0;
    if( (fn = fopen( ".Names", "r" )) == NULL )
	return 0;
    while( fgets( buf, sizeof(buf), fn ) != NULL ) {
	if( (ptr = strchr( buf, '\n' )) != NULL )
	    *ptr = '\0';
	if( strncmp( buf, "Name=", 5 ) == 0 ) {
	    strcpy( title, buf + 5 );
	} else if( strncmp( buf, "Path=~/", 7 ) == 0 ) {
	    strcpy( fname, buf + 7 );
	    additem( pm, title, fname );
	} else if( strncmp( buf, "# Title=", 8 ) == 0 ) {
	    if( pm->mtitle[0] == '\0' )
		strcpy( pm->mtitle, buf + 8 );
	}
    }
    fclose( fn );
    if( pm->mtitle[0] == '\0' )
	strcpy( pm->mtitle, MAINTITLE );
}

savenames( pm )
MENU	*pm;
{
    FILE	*fn;
    ITEM	*item;
    int		n;

    if( (fn = fopen( ".Names", "w" )) == NULL )
	return;
    fprintf( fn, "#\n" );
    fprintf( fn, "# Title=%s\n", pm->mtitle );
    fprintf( fn, "#\n" );
    for( n = 0; n < pm->num; n++ ) {
	item = pm->item[ n ];
	fprintf( fn, "Name=%s\n",	item->title );
	fprintf( fn, "Path=~/%s\n",	item->fname );
	fprintf( fn, "Numb=%d\n",	n+1 );
	fprintf( fn, "#\n" );
    }
    fclose( fn );
    execute( "chmod 0644", ".Names" );
}

showmenu( pm )
MENU	*pm;
{
    char	*title, *fname;
    int		n;

    clrscr();
    printf( "        %s\n\r\
------------------------------------------------------------------------------\
\n\r", pm->mtitle );
    if( fmode == 1 )
	printf( " �s��  ��    �D%52s\n\r", "�ɮצW��" );
    else if( fmode == 2 )
	printf( " �s��  ��    �D%62s\n\r", "��    ��" );
    else
	printf( " �s��  ��    �D\n\r" );
    if( pm->num == 0 ) {
	printf( "       No article in this group !!\n\r" );
    }
    for( n = pm->page; n < pm->page + 18 && n < pm->num; n++ ) {
	title = pm->item[n]->title;
	fname = pm->item[n]->fname;
	if( fmode == 1 ) {
	    if( dashf( fname ) ) {
		printf( "  %3d  %-50.50s  %s\n\r", n+1, title, fname );
	    } else if( dashd( fname ) ) {
		printf( "  %3d  %-50.50s  %s/\n\r", n+1, title, fname );
	    } else {
		printf( "  %3d  %-50.50s ^%s\n\r", n+1, title, fname );
	    }
	} else if( fmode == 2 ) {
	    printf( "  %3d  %-60.60s [%8.8s]\n\r", n+1, title, "??" );
	} else {
	    title[ 72 ] = '\0';
	    printf( "  %3d  %s\n\r", n+1, title );
	}
    }
    gotoxy( 1, 23 );
    if( pm->level == MANAGER )  printf( "%s",
"[�O  �D] ���� h �x ���} q,�� �x �s�W�峹 a �x �s�W�ؿ� g �x �s���ɮ� e" );
    else if( pm->level == SYSOP )  printf( "%s",
"[�޲z��] ���� h �x �[�峹 a �x �[�ؿ� g �x �ܦ��O�D b �x ���� Shell s" );
    else  printf( "%s",
"[�\\����] ���� h �x ���} q,�� �x ���ʴ�� k,��,j,�� �x Ū����� Rtn,��" );
}

showhelp( pm )
MENU	*pm;
{
    clrscr();
    printf( "        ��u BBS �����G��ϥλ���\n\r\
--------------------------------------------------------\n\r\
[����]      [�^�廡��]     [���廡��]\n\r\
h           This Help      �ϥλ���\n\r\
q,��        Quit           ���}��W�@�h�ؿ�\n\r\
k,��        Last Item      ����e�@�ӿﶵ\n\r\
j,n,��      Next Item      �����@�ӿﶵ\n\r\
PgUp        Last Page      ���ܫe�@�����\n\r\
N,PgDn,Spc  Next Page      ���ܫ�@�����\n\r\
Rtn,r,��    Submenu/Read   �i�J�U�@�h�ؿ� / Ū���峹\n\r\
/           Search board   �j�M�S�w�Q�װ�\n\r" );

    if( pm->level >= MANAGER ) {
	printf( "\n\r----< �O�D�S������ >----\n\r\
a/g         Add article/group    ������ؤ峹/�}�P�l���\n\r\
m/d         Move/Delete item     ����/�R���峹\n\r\
t/e         Title/Article edit   �ק�峹���D/���e\n\r\
i           Import e-mail        Ū�� E-Mail ���峹\n\r\
f/F         Filename/Rename      �d���ɮצW��/����ɮצW��\n\r\
c/p         Copy/Paste           ����/�߶K�@�g�峹\n\r" );
    }
    if( pm->level >= SYSOP ) {
	printf( "\n\r----< �����S������ >----\n\r\
b/s <����>  Board Manager/Shell  �ܦ��O�D/���� Shell\n\r\
V/v <����>  V.Search/v.Names     �s��.Search/.Name��\n\r" );
    }
    gotoxy( 1, 24 );
    printf( "�Ы����N���~�� ..." );
    igetkey();
}

getemailaddr( email, maxlen )
char	*email;
{
    char	*ptr, ch;

    if( (ptr = getenv( "REPLYTO" )) == NULL )
	ptr = "";
    printf( "\n\r�Ш̷ӤU�C�榡��J�z���H�c��}, �� ip �̤@�w�n�[ []\n\r" );
    printf( "ex: lab@cs.ccu.edu.tw or lab@[140.123.101.100]\n\r" );
    printf( "E-mail address: [%s]", ptr );
    if( igetstr( email, maxlen ) == 0 ) {
	strcpy( email, ptr );
    }
    if( !valid( email ) ) {
	printf( "�l��H�c��}�榡��J���~ ...\n\r" );
	return 0;
    }
    return strlen( email );
}

doarticle( title, fname )
char	*title, *fname;
{
    char	email[ STRLEN ];

    tty_exec( "cless", fname );
    printf( "\n\r\
[�\\Ū�峹] �H�H M �x Uuencode �H�H U �x Zmodem ���� Z �x ���} Q " );
    switch( igetkey() ) {
	case 'M':  case 'm':
	    if( getemailaddr( email, sizeof(email) ) ) {
		printf( "�N '%s' �峹�H�� '%s'.\n\r", fname, email );
		sprintf( genbuf, "/bin/mail %s < %s", email, fname );
		system( genbuf );
	    }
	    pause();
	    break;
	case 'U':  case 'u':
	    if( getemailaddr( email, sizeof(email) ) ) {
		printf( "�N '%s' uuencode ��H�� '%s'.\n\r", fname, email );
		sprintf( genbuf, "uuencode %s %s | /bin/mail %s",
			 fname, fname, email );
		system( genbuf );
	    }
	    pause();
	    break;
	case 'Z':  case 'z':
	    printf( "\n\r�Q�� Z-Modem �ǿ�榡�ǰe '$fname' �ɮ� ...\n\r" );
	    execute( "sz -ve", fname );
	    pause();
	    break;
    }
}

searchboard( path, title )
char	*path, *title;
{
    FILE	*fn;
    char	board[ STRLEN ];
    char	buf[ STRLEN ], *ptr;
    int		len;

    path[0] = title[0] = '\0';
    len = prompt( "��J���j�M���Q�װϦW��: ", board, sizeof(board) );
    if( len == 0 )  return 0;
    if( (fn = fopen( SEARCHFILE, "r" )) == NULL )
	return 0;
    while( fgets( buf, sizeof(buf), fn ) != NULL ) {
	if( strncmp( buf, board, len ) == 0 && buf[len] == ':' ) {
	    while( strchr( ": \t", buf[len] ) != NULL )
		len++;
	    if( (ptr = strchr( buf, '\n' )) != NULL )
		*ptr = '\0';
	    strcpy( path, &buf[ len ] );
	    break;
	}
    }
    fclose( fn );
    len = strlen( path );
    if( len == 0 || !dashd( path ) ) {
	gotoxy( 1, 24 );
	clreol();
	printf( "[�j�M����] %s. �Ы����N���~�� ... ",
		len ? "�����ؿ�����, �гq�� SYSOP" : "�䤣�� �� ���s�b" );
	igetkey();
	return 0;
    }
    strcpy( buf, path );
    if( (ptr = strrchr( buf, '/' )) != NULL ) {
	strcpy( ptr+1, ".Names" );
    }
    if( (fn = fopen( buf, "r" )) == NULL ) {
	strcpy( title, "Title not found !!" );
	return len;
    }
    len = strlen( board );
    while( fgets( buf, sizeof(buf), fn ) != NULL ) {
	if( (ptr = strchr( buf, '\n' )) != NULL )
	    *ptr = '\0';
	if( strncmp( buf, "Name=", 5 ) == 0 ) {
	    strcpy( title, buf+5 );
	} else if( strncmp( buf, "Path=~/", 7 ) == 0 ) {
	    if( strncmp( buf+7, board, len ) == 0 )
		break;
	    else
		strcpy( title, board );
	}
    }
    close( fn );
    return len;
}

addnewitem( pm, mode )
MENU	*pm;
{
    ITEM	*new;
    char	board[ STRLEN ], *mesg;
    char	fname[ STRLEN ], title[ STRLEN ];
    int		len;

    switch( mode ) {
	case ADDITEM:
	    mesg = "[�s�W�峹] �п�J�ɮצW��: ";	break;
	case ADDGROUP:
	    mesg = "[�s�W�ؿ�] �п�J�ؿ��W��: ";	break;
	case ADDMAIL:
	    mesg = "�п�J�Q�װϦW�� (???.bm@cs.ccu.edu.tw) : ";
	    if( prompt( mesg, board, sizeof(board) ) == 0 )
		return;
	    sprintf( genbuf, "/tmp/bm.%s", board );
	    if( !dashf( genbuf ) ) {
		printf( "���~: �d�L���H, �бH�� %s.bm@cs.ccu.edu.tw. ",
			board );
		igetkey();
		return;
	    }
	    mesg = "[Ū���l��] �п�J�ɮצW��: ";	break;
     }
    if( (len = prompt( mesg, fname, sizeof(fname) )) == 0 )
	return;
    if( !valid( fname ) ) {
	printf( "[���~] �W�٥u��]�t�^��μƦr ..." );
	igetkey();
    } else if( dashf( fname ) ) {
	printf( "Warning: �t�Τ��w�g�� %s �o���ɮצs�b�F !", fname );
	igetkey();
    } else if( dashd( fname ) ) {
	printf( "Warning: �t�Τ��w�g�� %s �o�ӥؿ��s�b�F !", fname );
	igetkey();
    } else {
	printf( "           �п�J�ﶵ����: " );
	if( igetstr( title, sizeof(title) ) == 0 )
	    return;
	switch( mode ) {
	    case ADDITEM:
		execute( EDITOR, fname );
		execute( "chmod 0644", fname );
		break;
	    case ADDGROUP:
		mkdir( fname, 0755 );
		execute( "chmod 0755", fname );
		break;
	    case ADDMAIL:
		sprintf( genbuf, "cp /tmp/bm.%s %s", board, fname );
		system( genbuf );
		execute( "chmod 0644", fname );
		break;
	}
	if( mode != ADDGROUP ) {
	    sprintf( genbuf, " -- %s ��z", username );
	    strcat( title, genbuf );
	}
	additem( pm, title, fname );
	savenames( pm );
    }
}

moveitem( pm )
MENU	*pm;
{
    ITEM	*tmp;
    char	newnum[ STRLEN ];
    int		num, n;

    sprintf( genbuf, "�п�J�� %d �ﶵ���s����: ", pm->now+1 );
    if( prompt( genbuf, newnum, sizeof(newnum) ) == 0 )
	return ;
    num = (newnum[0] == '$') ? 9999 : atoi( newnum ) - 1;
    if( num >= pm->num )	num = pm->num-1;
    else if( num < 0 )		num = 0;
    tmp = pm->item[ pm->now ];
    if( num > pm->now ) {
	for( n = pm->now; n < num; n++ )
	    pm->item[ n ] = pm->item[ n+1 ];
    } else {
	for( n = pm->now; n > num; n-- )
	    pm->item[ n ] = pm->item[ n-1 ];
    }
    pm->item[ num ] = tmp;
    pm->now = num;
    savenames( pm );
}

deleteitem( pm )
MENU	*pm;
{
    ITEM	*item;
    char	*title, *fname;
    int		n;

    item = pm->item[ pm->now ];
    title = item->title;
    fname = item->fname;
    sprintf( genbuf, "�R�� [%s] �ﶵ? (Y/N) ", title );
    if( !mksure( genbuf ) )
	return;
    if( dashf( fname ) ) {
	sprintf( genbuf, "�A�T�w�n�R�� '%s' �o���ɮ׶�? (Y/N) ", fname );
	if( !mksure( genbuf ) )
	    return;
	execute( "/bin/rm -f", fname );
    } else if( dashd( fname ) ) {
	sprintf( genbuf, "�A�T�w�n�R�� '%s' �ؿ��U�Ҧ���ƶ�? (Y/N) ", fname );
	if( !mksure( genbuf ) )
	    return;
	execute( "/bin/rm -rf", fname );
    }
    free( item );
    for( n = pm->now; n < pm->num; n++ )
	pm->item[ n ] = pm->item[ n+1 ];
    (pm->num)--;
    savenames( pm );
}

dotitle( pm )
MENU	*pm;
{
    if( prompt( "��J�s�W��: ", genbuf, sizeof(genbuf) ) > 0 ) {
	strcpy( pm->item[ pm->now ]->title, genbuf );
	savenames( pm );
    }
}

dofilename( pm )
MENU	*pm;
{
    ITEM	*item;
    char	fname[ STRLEN ];

    item = pm->item[ pm->now ];
    if( prompt( "��J�s�ɦW : ", fname, sizeof(fname) ) == 0 )
	return;
    if( !valid( fname ) ) {
	printf( "[���~] �W�٥u��]�t�^��μƦr ..." );
	igetkey();
    } else if( dashf( fname ) ) {
	printf( "Warning: �t�Τ��w�g�� %s �o���ɮצs�b�F !", fname );
	igetkey();
    } else if( dashd( fname ) ) {
	printf( "Warning: �t�Τ��w�g�� %s �o�ӥؿ��s�b�F !", fname );
	igetkey();
    } else if( rename( item->fname, fname ) == 0 ) {
	strcpy( item->fname, fname );
	savenames( pm );
    }
}

copyitem( pm )
MENU	*pm;
{
    ITEM	*item;

    item = pm->item[ pm->now ];
    strcpy( copytitle, item->title );
    strcpy( copyfname, item->fname );
    sprintf( copyfile, "%s/%s", pm->pwd, copyfname );
    message( "�ɮ׼��ѧ���. (�`�N! �߶K�峹��~��N�峹 delete!)" );
}

pastefile( pm )
MENU	*pm;
{
    if( copytitle[0] == '\0' || copyfname[0] == '\0' ) {
	message( "[���~] �Х��ϥ� copy �\\���A�� paste" );
    } else if( dashf( copyfname ) || dashd( copyfname ) ) {
	sprintf( genbuf, "[���~] %s �ɮ�/�ؿ��w�g�s�b", copyfname );
	message( genbuf );
    } else {
	sprintf( genbuf, "�T�w�n�߶K %s �ɮ׶�? (Y/N) ", copyfname );
	if( mksure( genbuf ) ) {
	    sprintf( genbuf, "/bin/cp -r %s %s",
				copyfile, copyfname );
	    system( genbuf );
	    additem( pm, copytitle, copyfname );
	    savenames( pm );
	}
    }
}

domenu( maintitle, lastlevel )
char	*maintitle;
{
    MENU	me;
    char	*fname, *title;
    int		ch;

    umask( 022 );
    strcpy( me.mtitle, maintitle );
    me.level = lastlevel;
    loadnames( &me );
    sprintf( genbuf, "(BM: %s)", username );
    if( me.level < MANAGER && strstr( me.mtitle, genbuf ) ) {
	me.level = MANAGER;
    }
    getcwd( me.pwd, sizeof( me.pwd ) );
    me.page = 9999;
    me.now = 0;
    while( 1 ) {
	if( me.now >= me.num && me.num > 0 ) {
	    me.now = me.num - 1;
	} else if( me.now < 0 ) {
	    me.now = 0;
	}
	if( me.now < me.page || me.now >= me.page + PAGESIZE ) {
	    me.page = me.now - (me.now % PAGESIZE);
	    showmenu( &me );
	}
	gotoxy( 1, 4 + me.now - me.page );	printf( " >" );
	ch = igetkey();
	gotoxy( 1, 4 + me.now - me.page );	printf( "  " );
	if( ch == 'Q' || ch == 'q' || ch == KEY_LEFT )
	    break;
	switch( ch ) {
	    case KEY_UP:  case 'K': case 'k':
		if( me.now > 0 )	me.now--;
		else			me.now = me.num-1;
		break;
	    case KEY_DOWN:  case 'J': case 'j':
		if( me.now < me.num-1 )	me.now++;
		else			me.now = 0;
		break;
	    case KEY_PGUP:  case Ctrl( 'B' ):
		if( me.now >= PAGESIZE )	me.now -= PAGESIZE;
		else if( me.now > 0 )		me.now = 0;
		else				me.now = me.num-1;
		break;
	    case KEY_PGDN:  case Ctrl( 'F' ):  case ' ':
		if( me.now < me.num - PAGESIZE )	me.now += PAGESIZE;
		else if( me.now < me.num-1 )		me.now = me.num-1;
		else					me.now = 0;
		break;
	    case 'R':  case 'r':
	    case KEY_CR:  case KEY_LF:  case KEY_RIGHT:
		if( me.now < me.num ) {
		    fname = me.item[ me.now ]->fname;
		    title = me.item[ me.now ]->title;
		    if( dashf( fname ) ) {
			doarticle( title, fname );
		    } else if( chdir( fname ) == 0 ) {
			domenu( title, me.level );
			chdir( me.pwd );
		    }
		    me.page = 9999;
		}
		break;
	    case 'H':  case 'h':  case '?':
		showhelp( &me );
		me.page = 9999;	break;
	    case '/':
		if( dashf( SEARCHFILE ) ) {
		    char	path[ STRLEN ], title[ STRLEN ];

		    if( searchboard( path, title ) ) {
			chdir( path );
			domenu( title, me.level );
			chdir( me.pwd );
		    }
		    me.page = 9999;
		}
		break;
	}
	if( me.level >= MANAGER )  switch( ch ) {
	    case 'A':  case 'a':
		addnewitem( &me, ADDITEM );
		me.page = 9999;	break;
	    case 'G':  case 'g':
		addnewitem( &me, ADDGROUP );
		me.page = 9999;	break;
	    case 'I':  case 'i':
		addnewitem( &me, ADDMAIL );
		me.page = 9999;	break;
	    case 'P':  case 'p':
		pastefile( &me );
		me.page = 9999;	break;
	}
	if( me.level >= MANAGER && me.num )  switch( ch ) {
	    case 'M':  case 'm':
		moveitem( &me );
		me.page = 9999;	break;
	    case 'D':  case 'd':
		deleteitem( &me );
		me.page = 9999;	break;
	    case 'T':  case 't':
		dotitle( &me );
		me.page = 9999;	break;
	    case 'E':  case 'e':
		execute( EDITOR, me.item[ me.now ]->fname );
		me.page = 9999;	break;
	    case 'f':
		fmode = (fmode + 1) % 3;
		me.page = 9999;	break;
	    case 'F':
		dofilename( &me );
		me.page = 9999;	break;
	    case 'C':  case 'c':
		copyitem( &me );
		me.page = 9999;	break;
	}
	if( me.level == SYSOP )  switch( ch ) {
	    case 'B':  case 'b':
		me.level = 0;
		me.page = 9999;	break;
	    case 'S':  case 's':
		tty_exec( "/bin/csh", "" );
		me.page = 9999;	break;
	    case 'V':  case 'v':
		fname = (ch == 'V') ?  SEARCHFILE : ".Names";
		if( dashf( fname ) ) {
		    execute( EDITOR, fname );
		    me.page = 9999;
		}
		break;
	}
    }
    for( ch = 0; ch < me.num; ch++ )
	free( me.item[ ch ] );
}

main( argc, argv )
char	*argv[];
{
    char	*title = "";

    if( argc > 1 )	title = argv[1];
    init_tty();
    chdir ("/0Announce");
    domenu( title, checksysop() );
    gotoxy( 1, 24 );
    reset_tty();
}

