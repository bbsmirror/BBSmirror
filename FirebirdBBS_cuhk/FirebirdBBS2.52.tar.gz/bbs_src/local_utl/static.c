/* static.c : �W���H���έp */
/*Modify By SmallPig*/
#include <time.h>
#include <stdio.h>
#define MAX_LINE        15

struct
{
  int no[24];                   /* ���� */
  int sum[24];                  /* �`�X */
}      st;


char    *Ctime(date)
time_t  *date;
{
        static char buf[80];

        strcpy(buf, (char *)ctime(date));
        buf[strlen(buf)-1] = '\0';
        return buf;
}

main(argc, argv)
  char *argv[];
{
  char *progmode;
  FILE *fp;
  char buf[256], *p;
  char date[80];
  int now;
  int hour, max = 0, item, total = 0;
  int totaltime = 0;
  int i, j;
  char    *blk[10] =
  {
      "��", "��", "�b", "�c", "�d",
      "�e", "�f", "�g", "�h", "�i",
  };

  if ((fp = fopen("/home/bbs/usies", "r")) == NULL)
  {
    printf("cann't open usies\n");
    return 1;
  }

  now=time(0);
  sprintf(date,"%6.6s",Ctime(&now)+4);
  while (fgets(buf, 256, fp))
  {
    hour = atoi(buf+7);
    if (hour < 0 || hour > 23)
    {
       printf("%s", buf);
       continue;
    }
    if(strncmp(buf,date,6))
        continue;
    if ( !strncmp(buf+21, "ENTER", 5))
    {
      st.no[hour]++;
      continue;
    }
    if ( p = (char *)strstr(buf+40, "Stay:"))
    {
      st.sum[hour] += atoi( p + 6);
      continue;
    }
  }
  fclose(fp);

  for (i = 0; i < 24; i++)
  {
    total += st.no[i];
    totaltime += st.sum[i];
    if (st.no[i] > max)
      max = st.no[i];
  }

  item = max / MAX_LINE + 1;

  if ((fp = fopen("/home/bbs/0Announce/bbslists/countlogins", "w")) == NULL)
  {
    printf("Cann't open countlogins\n");
    return 1;
  }

  fprintf(fp,"\n[1;36m    �z�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�{\n");
  for (i = max/item+1 ; i >= 0; i--)
  {
    fprintf(fp, "[1;34m%4d[36m�x[33m",(i)*item);
    for (j = 0; j < 24; j++)
    {
      if ((item * (i) > st.no[j]) && (item * (i-1) <= st.no[j]) && st.no[j])
      {
        if(st.no[j]>=1000)
                fprintf(fp, "[35m###[33m");
        else
                fprintf(fp, "[35m%-3d[33m", (st.no[j]));
        continue;
      }
      if(st.no[j]-item*i<item && item*i<st.no[j])
              fprintf(fp,"%s ", blk[((st.no[j]-item * i)*10)/item]);
      else if(st.no[j]-item * i>=item)
              fprintf(fp,"%s ",blk[9]);
      else
           fprintf(fp,"   ");
    }
    fprintf(fp, "[1;36m�x\n");
  }
  fprintf(fp, "   [36m"
    " �|�w�w�w[37m�����j�ǥ|�ʦ~�ӲĤ@���W���H����[36m�w�w�w[37m%s[36m�w�w�}\n"
    "    [1;34m  0  1  2  3  4  5  6  7  8  9  10 11 [31m12 13 14 15 16 17 18 19 20 21 22 23 \n\n"
    "               [36m 1 [33m�i[36m = [37m%-5d [36m�`�@�W���H���G[37m%-9d[36m�����ϥήɶ��G[37m%d[m \n"
    ,Ctime(&now),item,total, totaltime / total + 1);
  fclose(fp);
}
