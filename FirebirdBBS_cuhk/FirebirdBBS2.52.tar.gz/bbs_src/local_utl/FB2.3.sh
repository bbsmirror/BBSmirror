#! /bin/sh
make rehome
make renotepad
rehome
renotepad
