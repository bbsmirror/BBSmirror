#! /bin/sh
make renotepad
renotepad
