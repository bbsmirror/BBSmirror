/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"
extern cmpbnames();

/*Add by SmallPig*/
int
listdeny()
{
    FILE *fp;
    int x = 0, y = 3, cnt = 0, max = 0, len;
    char u_buf[20], line[STRLEN], *nick;

    move(y,x);
    CreateNameList();
    setbfile( genbuf, currboard,"deny_users" );
    if ((fp = fopen(genbuf, "r")) == NULL) {
        prints("(none)\n");
        return 0;
    }
    while(fgets(genbuf, STRLEN, fp) != NULL) {
        strtok( genbuf, " \n\r\t" );
        strcpy( u_buf, genbuf );
        AddNameList( u_buf );
        nick = (char *) strtok( NULL, "\n\r\t" );
        if( nick != NULL ) {
            while( *nick == ' ' )  nick++;
            if( *nick == '\0' )  nick = NULL;
        }
        if( nick == NULL ) {
            strcpy( line, u_buf );
        } else {
            sprintf( line, "%-12s%s", u_buf, nick );
        }
        if( (len = strlen( line )) > max )  max = len;
        if( x + len > 78 )  line[ 78 - x ] = '\0';
        prints( "%s", line );
        cnt++;
        if ((++y) >= t_lines-1) {
            y = 3;
            x += max + 2;
            max = 0;
            if( x > 70 )  break;
        }
        move(y,x);
    }
    fclose(fp);
    if (cnt == 0) prints("(none)\n");
    return cnt;
}

int
addtodeny(uident)
char *uident;
{
    char buf[50],strtosave[STRLEN];

    setbfile( genbuf, currboard,"deny_users" );
    if( seek_in_file(genbuf,uident) )
        return -1;
    getdata(2,0,"��J����: ", buf,40,DOECHO,NULL,YEA);
    sprintf( strtosave, "%-12s %s", uident, buf );
    return addtofile(genbuf,strtosave);
}
               
int
deldeny(uident)
char *uident;
{
    char fn[STRLEN];

    setbfile( fn,currboard, "deny_users" );
    return del_from_file(fn,uident);
}

int
deny_user()
{
    char uident[STRLEN];
    char ans[8],repbuf[STRLEN];
    int count;

    if(!HAS_PERM(PERM_SYSOP))
       if(!chk_currBM(currBM))
        {
        return DONOTHING;
        }

    while (1) {
        clear();
        prints("�]�w�L�k Post ���W��\n");
        count = listdeny();
        if (count)
            getdata(1,0,"(A)�W�[ (D)�R�� or (E)���} [E]: ",ans,7,DOECHO,NULL,YEA);
        else 
            getdata(1,0,"(A)�W�[ or (E)���} [E]: ", ans, 7, DOECHO, NULL,YEA);
        if (*ans == 'A' || *ans == 'a') {
            move(1,0);
            usercomplete("�W�[�L�k POST ���ϥΪ�: ", uident);
            if( *uident != '\0' )
            {
                if(addtodeny(uident)==1)
                {
                        sprintf(repbuf,"%s ���� %s �b %s �� POST �v�O",
                        currentuser.userid,uident,currboard);
                        report(repbuf);
                }
            }
        } else if ((*ans == 'D' || *ans == 'd') && count) {
            move(1,0);
            namecomplete("�R���L�k POST ���ϥΪ�: ", uident);
            move(1,0);
            clrtoeol();
            if (uident[0] != '\0')
            {
                if(deldeny(uident))
                {
                        sprintf(repbuf,"%s ��_ %s �b %s �� POST �v�O",
                        currentuser.userid,uident,currboard);
                        report(repbuf);
                }
             }
        } else break;
    }
    clear();
    return FULLUPDATE;
}               

