#define PASS "/home/bbs/.PASSWDS"
#define BBSHOME "/home/bbs"
