#! /bin/sh
make rehome
make refriend
make renotepad
refriend
rehome
renotepad
