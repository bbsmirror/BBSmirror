#include "bbs.h"

char tname[STRLEN];
char fname[STRLEN];

struct postnode
{
int num;
struct postnode *next;
};

struct titlenode 
{
char *title;
struct titlenode *next;
struct postnode *post;
};

struct titlenode toptitle;

int
thread(post,num)
struct fileheader *post;
int num;
{
        struct titlenode *tmp;
        char *ntitle;

/*        printf("%d ",num);*/
        tmp=&toptitle;
        if(post->title[0]=='R'&&post->title[1]=='e'&&post->title[2]==':')
                ntitle=post->title+4;
        else
                ntitle=post->title;
        while(1)
        {
                if(tmp->next==NULL)
                {
                        struct titlenode *titletmp;
                        titletmp=(struct titlenode *)malloc(sizeof(struct titlenode));
                        titletmp->title=malloc(sizeof(char)*(strlen(ntitle)+1));
                        strcpy(titletmp->title,ntitle);
                        titletmp->post=NULL;
                        titletmp->next=NULL;
                        tmp->next=titletmp;
                }
                if(!strcmp(tmp->next->title,ntitle))
                {
                        struct postnode *tmppost,*first=tmp->next->post;
                        if(first==NULL)
                        {
                                tmppost=(struct postnode *)malloc(sizeof(struct postnode));
                                tmppost->num=num;
                                tmppost->next=NULL;
                                tmp->next->post=tmppost;
                                return;
                        }
                        while(1)
                        {
                                if(first->next==NULL)
                                {
                                  tmppost=(struct postnode *)malloc(sizeof(struct postnode));
                                  tmppost->num=num;
                                  tmppost->next=NULL;
                                  first->next=tmppost;
                                  return;
                                }
                                first=first->next;
                        }
                }else
                {
                        tmp=tmp->next;
                }
        }
}

int
report()
{
        return;
}

int 
visit_all()
{
        struct titlenode *tmp;
        struct fileheader post;
        int i=0;

        tmp=toptitle.next;
        
        while(tmp)
        {
                struct postnode *tmppost;

                i++;
/*                printf("%d %s",i,tmp->title);*/
                tmppost=tmp->post;
                while(tmppost)
                {
/*                        printf("%d ",tmppost->num);*/
                        get_record(fname,&post,sizeof(post),tmppost->num);
                        append_record(tname,&post,sizeof(post));
                        tmppost=tmppost->next;
                }
/*                printf("\n");*/
                tmp=tmp->next;
        }

}

int
main(argc, argv)
char *argv[];
int argc;
{
        FILE *tf;
        int i=0;
        struct fileheader post;
        char dname[STRLEN];
        char buf[256];

        sprintf(dname,"/home/bbs/boards/%s/%s",argv[1],DOT_DIR);
        sprintf(fname,"/home/bbs/boards/%s/%s2",argv[1],DOT_DIR);
        sprintf(tname,"/home/bbs/boards/%s/%s",argv[1],THREAD_DIR);
        unlink(tname);
        sprintf(buf,"cp %s %s",dname,fname);
        system(buf);

        if((tf=fopen(fname,"rb"))==NULL)
        {
                printf(".DIR cant open...");
                return ;
        }
        toptitle.next=NULL;
        toptitle.post=NULL;
        while(1)
        {
                i++;
                if(fread(&post,sizeof(post),1,tf)<=0) break;
                thread(&post,i);
        }
        visit_all();
        fclose(tf);
        unlink(fname);
}
