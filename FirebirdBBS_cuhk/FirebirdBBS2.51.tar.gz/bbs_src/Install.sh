#! /bin/sh

BBS_HOME=/home/bbs
INSTALL="//bin/install -c"
TARGET=/home/bbs/bin

echo "This script will install the whole BBS to ${BBS_HOME}..."
echo -n "Press <Enter> to continue ..."
read ans

if [ -d ${BBS_HOME} ] ; then
        echo -n "Warning: ${BBS_HOME} already exists, overwrite whole bbs [N]?"
        read ans
        ans=${ans:-N}
        case $ans in
            [Yy]) echo "Installing new bbs to ${BBS_HOME}" ;;
            *) echo "Abort ..." ; exit ;;
        esac
else
        echo "Making dir ${BBS_HOME}"
        mkdir ${BBS_HOME}
        chown -R bbs ${BBS_HOME}
        chgrp -R bbs ${BBS_HOME}
fi

echo "Setup bbs directory tree ....."
( cd bbshome ; tar cf - * ) | ( cd ${BBS_HOME} ; tar xf - )

chown -R bbs ${BBS_HOME}
chgrp -R bbs ${BBS_HOME}

${INSTALL} -m 770  -s -g bbs -o bbs    bbs        ${TARGET}
${INSTALL} -m 770  -s -g bbs -o bbs    bbs.chatd  ${TARGET}
${INSTALL} -m 4755 -s -g bin -o root   bbsrf      ${TARGET}

mv {BBS_HOME}\bbs_src\menu.ini {BBS_HOME}\etc
mv {BBS_HOME}\bbs_src\sysconf.ini {BBS_HOME}\etc
mv {BBS_HOME}\bbs_src\movie {BBS_HOME}\etc
