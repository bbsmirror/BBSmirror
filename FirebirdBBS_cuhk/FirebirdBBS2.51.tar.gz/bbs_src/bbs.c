/*  
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"
#include <time.h>

int mot ;
struct postheader header;
static int quiting ;
extern int numofsig;
int continue_flag;
int scrint = 0 ;
int local_article;
int readpost;
int digestmode;
struct userec currentuser ;
int usernum ;
char currboard[STRLEN-BM_LEN] ;
char currBM[BM_LEN-1] ;
int selboard = 0 ;

char    ReadPost[STRLEN]="";
char    ReplyPost[STRLEN]="";
int     FFLL=0;
int     Anony;
 
char    *filemargin() ;
void    report();
void    board_usage();
void    cancelpost();
/*For read.c*/
int     auth_search_down();
int     auth_search_up();
int     t_search_down();
int     t_search_up();
int     post_search_down();
int     post_search_up();
int     thread_up();
int     thread_down();
int     deny_user();
int     show_author();
int     SR_first_new();
int     SR_last();
int     SR_first();
int     SR_read();
int     SR_read();
int     SR_author();
int     SR_BMfunc();

extern int      numboards;
extern time_t   login_start_time;
extern char     BoardName[];
extern int      cmpbnames();

char genbuf[ 1024 ];
char quote_title[120],quote_board[120];
char quote_file[120], quote_user[120];
#ifndef NOREPLY
char replytitle[STRLEN];
#endif

int totalusers, usercounter;

int
check_stuffmode()
{
        if(uinfo.mode==RMAIL)
                return YEA;
        else
                return NA;
}

int
set_safe_record()
{
        struct userec tmp;
        extern int ERROR_READ_SYSTEM_FILE;

        if(get_record(PASSFILE,&tmp,sizeof(currentuser),usernum)==-1)
        {
                char buf[STRLEN];

                sprintf(buf,"Error:Read Passfile %4d %12.12s",usernum,currentuser.userid);
                report(buf);
                ERROR_READ_SYSTEM_FILE=YEA;
                abort_bbs();
                return -1;
        }
        currentuser.numposts=tmp.numposts;
        currentuser.userlevel=tmp.userlevel;
        currentuser.numlogins=tmp.numlogins;
        currentuser.stay=tmp.stay;
}

char *
sethomepath( buf, userid )
char    *buf, *userid;
{
    sprintf( buf, "home/%c/%s", toupper(userid[0]), userid );
    return buf;
}

/*Add by SmallPig*/
void 
setqtitle(stitle)
char *stitle;
{
        FFLL=1;
        if(strncmp(stitle,"Re: ",4)!=0&&strncmp(stitle,"RE: ",4)!=0)
        {
                sprintf(ReplyPost,"Re: %s",stitle);
                strcpy(ReadPost,stitle);
         } 
         else
         {
                strcpy(ReplyPost,stitle);
                strcpy(ReadPost,ReplyPost+4);
          }
}

int
chk_currBM(BMstr)
char BMstr[STRLEN-1];
{
        char *ptr;
        char BMstrbuf[STRLEN-1];

        if(HAS_PERM(PERM_OBOARDS)||HAS_PERM(PERM_SYSOP))
                return YEA;
        if(!HAS_PERM(PERM_BOARDS))
                return NA;
        strcpy(BMstrbuf,BMstr);
        ptr=strtok(BMstrbuf,",: ;|&()\0\n");
        while(1)
        {
           if(ptr==NULL)
              return NA;
           if(!strcmp(ptr,currentuser.userid/*,strlen(currentuser.userid)*/))
              return YEA;
           ptr=strtok(NULL,",: ;|&()\0\n");
        }
}

void 
setquotefile(filepath)
char filepath[];
{
   strcpy(quote_file,filepath);
}   



char *
sethomefile( buf, userid, filename )
char    *buf, *userid, *filename;
{
    sprintf( buf, "home/%c/%s/%s", toupper(userid[0]), userid, filename );
    return buf;
}

char *
setuserfile( buf, filename )
char    *buf, *filename;
{
    sprintf( buf, "home/%c/%s/%s", toupper(currentuser.userid[0]),currentuser.userid, filename );
    return buf;
}

char *
setbpath( buf, boardname )
char *buf, *boardname;
{
    strcpy( buf, "boards/" );
    strcat( buf, boardname );
    return buf;
}

char *
setbdir( buf, boardname )
char *buf, *boardname;
{
    char dir[STRLEN];

    switch(digestmode)
    {
        case NA:
                strcpy(dir,DOT_DIR);
                break;
        case YEA:
                strcpy(dir,DIGEST_DIR);
                break;
        case 2:
                strcpy(dir,THREAD_DIR);
                break;

    }
    sprintf( buf, "boards/%s/%s", boardname, dir);
    return buf;
}

char *
setbfile( buf, boardname, filename )
char *buf, *boardname, *filename;
{
    sprintf( buf, "boards/%s/%s", boardname, filename );
    return buf;
}

int 
deny_me()
{
   char buf[STRLEN];

   setbfile(buf,currboard,"deny_users");
   return seek_in_file(buf,currentuser.userid);
}


/*Add by SmallPig*/
void 
shownotepad()
{
modify_user_mode( NOTEPAD );
ansimore("etc/notepad", YEA);
clear();
return;
}

int
uleveltochar( buf, lvl )
char    *buf;
unsigned lvl;
{
    if( !(lvl &  PERM_BASIC) ) {
        strcpy( buf, "----" );
        return 0;
    }
    if( lvl < PERM_DEFAULT )
    {
        strcpy( buf, "- --" );
        return 1;
    }

    buf[0] = (lvl & (PERM_SYSOP)) ? 'C' : ' ';
    buf[1] = (lvl & (PERM_XEMPT)) ? 'X' : ' ';
    buf[2] = (lvl & (PERM_BOARDS)) ? 'B' : ' ';
    buf[3] = (lvl & (PERM_DENYPOST)) ? 'p' : ' ';
    if( lvl & PERM_ACCOUNTS ) buf[3] = 'A';
    if( lvl & PERM_SYSOP ) buf[3] = 'S';
    buf[4] = '\0';
    return 1;
}
/*
char *
chtime(clock)
time_t *clock;
{
    char chinese[STRLEN],week[10],mont[10],date[4],time[10],year[5];
    char *ptr = ctime(clock),*seg,*returndate;

    seg=strtok(ptr," \n\0");
    if(!strcmp(seg,"Sun"))
        strcpy(week,"�P����");
    if(!strcmp(seg,"Mon"))
        strcpy(week,"�P���@");
    if(!strcmp(seg,"Tue"))
        strcpy(week,"�P���G");
    if(!strcmp(seg,"Wed"))
        strcpy(week,"�P���T");
    if(!strcmp(seg,"Thu"))
        strcpy(week,"�P���|");
    if(!strcmp(seg,"Fri"))
        strcpy(week,"�P����");
    if(!strcmp(seg,"Sat"))
        strcpy(week,"�P����");

    seg=strtok(NULL," \n\0");
    if(!strcmp(seg,"Jan"))
        strcpy(mont," 1��");
    if(!strcmp(seg,"Feb"))
        strcpy(mont," 2��");
    if(!strcmp(seg,"Mar"))
        strcpy(mont," 3��");
    if(!strcmp(seg,"Apr"))
        strcpy(mont," 4��");
    if(!strcmp(seg,"May"))
        strcpy(mont," 5��");
    if(!strcmp(seg,"Jun"))
        strcpy(mont," 6��");
    if(!strcmp(seg,"Jul"))
        strcpy(mont," 7��");
    if(!strcmp(seg,"Aug"))
        strcpy(mont," 8��");
    if(!strcmp(seg,"Sep"))
        strcpy(mont," 9��");
    if(!strcmp(seg,"Oct"))
        strcpy(mont,"10��");
    if(!strcmp(seg,"Nov"))
        strcpy(mont,"11��");
    if(!strcmp(seg,"Dec"))
        strcpy(mont,"12��");
    strcpy(date,strtok(NULL," \n\0"));
    strcpy(time,strtok(NULL," \n\0"));
    strcpy(year,strtok(NULL," \n\0"));

    sprintf(chinese,"����%2.2d�~%4.4s%2.2s�� %s %s",atoi(year)-1911,mont,date,week,time);
    strncpy(ptr,chinese,strlen(chinese));
    return (ptr);

}
*/

char *
Ctime(clock)
time_t *clock;
{
    char *foo;
    char *ptr = ctime(clock);

    if (foo = strchr(ptr, '\n')) *foo = '\0';
    return (ptr);
}

void
printutitle()
{
    move(2,0) ;

    prints("[1;44m �s ��  �ϥΪ̥N��     %-19s  #�W�� #�峹 %4s    �̪���{���   [m\n",

#if defined(ACTS_REALNAMES)
        "�u��m�W",
#else
        "�ϥΪ̼ʺ�",
#endif
        "����" ) ;
}


int
g_board_names(fhdrp)
struct boardheader *fhdrp ;
{
    if ((fhdrp->level & PERM_POSTMASK) || HAS_PERM(fhdrp->level)
        ||(fhdrp->level & PERM_NOZAP))
    {
        AddNameList(fhdrp->filename) ;
    }
    return 0 ;
}

void
make_blist()
{
    CreateNameList() ;
    apply_boards(g_board_names) ;
}

int
Select()
{
    modify_user_mode( SELECT );
    do_select( 0, NULL, genbuf );
    return 0 ;
}

int
junkboard()
{
   return seek_in_file("etc/junkboards",currboard);
}

int
Post()
{
    if(!selboard) {
        prints("\n\n���� (S)elect �h��ܤ@�ӰQ�װϡC\n") ;
        pressreturn() ;
        clear() ;
        return 0 ;
    }
#ifndef NOREPLY
    *replytitle = '\0';
#endif
    do_post();
    return 0 ;
}

int
postfile(filename,nboard,posttitle,mode)
char *filename,*nboard,*posttitle;
int mode;
{
    char bname[STRLEN];
    char dbname[STRLEN];
    struct boardheader fh;

    if(search_record(BOARDS, &fh, sizeof(fh), cmpbnames, nboard)<=0)
    {
        sprintf(bname,"%s �Q�װϧ䤣��",nboard);
        report(bname);
        return -1;
    }
    in_mail = NA ;    
    strcpy(quote_board,nboard);
    strcpy(dbname,currboard);
    strcpy(currboard,nboard);
    strcpy( quote_file, filename);
    strcpy(quote_title,posttitle);
    post_cross('l',mode); 
    strcpy(currboard,dbname);
    return;
}               

int
get_a_boardname(bname,prompt)
char *bname,*prompt;
{
    struct boardheader fh;

    make_blist();
    namecomplete(prompt,bname);
    if (*bname == '\0') {
        return 0;
    }
    if(search_record(BOARDS, &fh, sizeof(fh), cmpbnames, bname)<=0)
    {
        move(1,0);
        prints("���~���Q�װϦW��\n");
        pressreturn();
        move(1,0);
        return 0;
    }
    return 1;
}

/* Add by SmallPig */
int
do_cross(ent,fileinfo,direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
    char bname[STRLEN];
    char dbname[STRLEN];
    char ispost[10];
    
    if (!HAS_PERM(PERM_POST))
    {return DONOTHING;}
    if(uinfo.mode!=RMAIL)
        sprintf(genbuf,"boards/%s/%s",currboard,fileinfo->filename) ;
    else
        sprintf(genbuf,"mail/%c/%s/%s",toupper(currentuser.userid[0]),currentuser.userid,fileinfo->filename) ;
    strcpy( quote_file, genbuf );
    strcpy(quote_title,fileinfo->title);

    clear();
    if(!get_a_boardname(bname,"�п�J�n��K���Q�װϦW��: "))
    {
        return FULLUPDATE;
    }
    move(0,0);
    clrtoeol();
    prints("��� ' %s ' �� %s �O ",quote_title,bname);
    move(1,0);
    getdata(1,0,"(S)��H (L)���� (A)����? [A]: ",ispost, 9, DOECHO, NULL,YEA);
    if(ispost[0]=='s'||ispost[0]=='S'||ispost[0]=='L'||ispost[0]=='l')
    {
    strcpy(quote_board,currboard);
    strcpy(dbname,currboard);
    strcpy(currboard,bname);
    if(post_cross(ispost[0],0)==-1)
    {pressreturn();
    move(2,0);
    strcpy(currboard,dbname);
    return FULLUPDATE;}
    strcpy(currboard,dbname);
    move(2,0);
    prints("' %s ' �w��K�� %s �O \n",quote_title,bname);
    }else 
   { prints("����");}
    move(2,0);
    pressreturn();
    return FULLUPDATE;
}



void
readtitle()
{
    struct shortfile    *bp;
    struct shortfile    *getbcache();
    char        header[ STRLEN ], title[ STRLEN ];
    char        readmode[10];

    bp = getbcache( currboard );
    memcpy( currBM, bp->BM, BM_LEN -1);
    if( currBM[0] == '\0' || currBM[0] == ' ' ) {
        strcpy( header, "�ۼx�O�D��" );
    } else {
        sprintf( header, "�O�D: %s", currBM );
    }
    if ( chkmail() )
        strcpy( title, "[�z���H��]" );
    else if ( (bp->flag&VOTE_FLAG))
        sprintf( title, "�벼���A�� V �i�J�벼");
    else
        strcpy( title, bp->title+13 );

    showtitle( header, title );
    prints("���}[[1;32m��[m,[1;32me[m] ���[[1;32m��[m,[1;32m��[m] �\\Ū[[1;32m��[m,[1;32mr[m] �o���峹[[1;32mCtrl-P[m] ��H[[1;32md[m] �Ƨѿ�[[1;32mTAB[m] �D�U[[1;32mh[m]\n" );
    if(digestmode==0)
        strcpy(readmode,"�@��");
    else if(digestmode==1)
        strcpy(readmode,"��K");
    else if(digestmode==2)
        strcpy(readmode,"�D�D");
    prints("[1;44m �s��   �Z �n ��     ��  ��  ��  �D                                 [%4s�Ҧ�] [m\n",readmode) ;
    clrtobot();
}

char *
readdoent(num,ent)
int     num;
struct fileheader *ent ;
{
    static char buf[120] ;
    time_t      filetime;
    char        *date;
    char        *TITLE;
    int         type;

    type = brc_unread( ent->filename ) ? 'N' : ' ';
    if ((ent->accessed[0] & FILE_DIGEST) /*&& HAS_PERM(PERM_MARKPOST)*/)
    {
       if (type == ' ') type = 'g';
       else type = 'G';
    }
    if(ent->accessed[0] & FILE_MARKED)
    {
        switch(type)
        {
                case ' ':
                        type='m';
                        break;
                case 'N':
                        type='M';
                        break;
                case 'g':
                        type='b';
                        break;
                case 'G':
                        type='B';
                        break;
        }
    }
    filetime = atoi( ent->filename + 2 );
    if( filetime > 740000000 ) {
        date = ctime( &filetime ) + 4;
    } else {
        date = "";
    }

      /*  Re-Write By Excellent */

    TITLE=ent->title;  
     
   if(FFLL==0)
   { 
    if (!strncmp("Re:",ent->title,3) || !strncmp("RE:",ent->title,3)){ 
    sprintf(buf," %4d %c %-12.12s %6.6s  %-.48s ", num, type,
                ent->owner, date, TITLE) ;
                }
    else{
        sprintf(buf," %4d %c %-12.12s %6.6s  �� %-.45s ",num,type,
                    ent->owner,date,TITLE);}
    }
   else
   { 
    if (!strncmp("Re:",ent->title,3) || !strncmp("RE:",ent->title,3)){ 
     if(strcmp(ReplyPost,ent->title)==0){
      sprintf(buf," [1;36m%4d[m %c %-12.12s %6.6s[1;36m�E%-.48s[m ", num, type,
                ent->owner, date, TITLE) ;
                 }
     else
      {
      sprintf(buf," %4d %c %-12.12s %6.6s  %-.48s ", num, type,
                ent->owner, date, TITLE) ; }           
        }       
        
    else{
      if(strcmp(ReadPost,ent->title)==0)
      { 
        sprintf(buf," [1;32m%4d[m %c %-12.12s %6.6s[1;32m�D�� %-.45s[m ",num,type,
                    ent->owner,date,TITLE);
       }  
      else 
      { 
        sprintf(buf," %4d %c %-12.12s %6.6s  �� %-.45s ",num,type,
                    ent->owner,date,TITLE);
        }
       }                        
    }
    return buf ;
}

char currfile[STRLEN] ;

int
cmpfilename(fhdr)
struct fileheader *fhdr ;
{
    if(!strncmp(fhdr->filename,currfile,STRLEN))
        return 1 ;
    return 0 ;
}

int
cpyfilename(fhdr)
struct fileheader *fhdr ;
{
    char        buf[ STRLEN ];

    sprintf( buf, "-%s", fhdr->owner );
    strncpy( fhdr->owner, buf, IDLEN );
    sprintf( buf, "<< �峹�w�Q %s �ҧR�� >>", currentuser.userid );
    strncpy( fhdr->title, buf, STRLEN );
    fhdr->filename[ STRLEN - 1 ] = 'L';
    fhdr->filename[ STRLEN - 2 ] = 'L';
    return 0;
}

int
read_post(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char *t ;
    char buf[512];
    int  ch;
    int cou;

    strcpy(buf,direct) ;
    if( (t = strrchr(buf,'/')) != NULL )
        *t = '\0' ;
    clear() ;
    sprintf(genbuf,"%s/%s",buf,fileinfo->filename) ;
    strcpy( quote_file, genbuf );
    strcpy( quote_board, currboard );
    strcpy(quote_title,fileinfo->title);
    quote_file[255] = fileinfo->filename[STRLEN-2];
    strcpy( quote_user, fileinfo->owner );
#ifndef NOREPLY
    ch = ansimore(genbuf,NA) ;
#else
    ch = ansimore(genbuf,YEA) ;
#endif
    brc_addlist( fileinfo->filename ) ;
#ifndef NOREPLY
    move(t_lines-1, 0);
        clrtoeol();
    if (haspostperm(currboard)) {
        prints("[1;44;31m[�\\Ū�峹]  [33m�^�H R �x ���� Q,�� �x�W�@�� ���x�U�@�� <Space>,���x�D�D�\\Ū ^X��p [m");
    } else {
        prints("[1;44;31m[�\\Ū�峹]  [33m���� Q,�� �x�W�@�� ���x�U�@�� <Space>,<Enter>,���x�D�D�\\Ū ^X �� p [m");
    }
    
    /* Re-Write By Excellent */
    
    FFLL=1;
   if(strncmp(fileinfo->title,"Re:",3)!=0)
    {strcpy(ReplyPost,"Re: ");
        strncat(ReplyPost,fileinfo->title,STRLEN-4);
        strcpy(ReadPost,fileinfo->title);
          }
    else
    {strcpy(ReplyPost,fileinfo->title);
       for(cou=0;cou<STRLEN;cou++)
    ReadPost[cou]=ReplyPost[cou+4];}
                                                
    refresh();
    sleep(1);
    if (!( ch == KEY_RIGHT || ch == KEY_UP || ch == KEY_PGUP )) 
        ch = egetch();

    switch( ch ) {
        case 'N': case 'Q':
        case 'n': case 'q': case KEY_LEFT:
                break; 
        case ' ':
        case 'j': case KEY_RIGHT: case KEY_DOWN: case KEY_PGDN:
                return READ_NEXT;
        case KEY_UP: case KEY_PGUP: 
                return READ_PREV;
        case 'Y' : case 'R':
        case 'y' : case 'r':
                do_reply(fileinfo->title);
                break;
        case Ctrl('R'):
                post_reply( ent, fileinfo, direct );
                break;
        case 'g':
                digest_post( ent, fileinfo, direct );
                break;
        case Ctrl('U'):
                sread(0,1,ent,1,fileinfo);
                break;
        case Ctrl('N'):
                sread(2,0,ent,0,fileinfo);
                sread(3,0,ent,0,fileinfo);
                sread(0,1,ent,0,fileinfo);
                break;
        case Ctrl('S'):case Ctrl('X'):case 'p':/*Add by SmallPig*/
                sread(0,0,ent,0,fileinfo);
                break;
        case Ctrl('A'):/*Add by SmallPig*/
                clear();
                show_author(0,fileinfo,'\0');
                return READ_NEXT;
                break;
                                        
        default : break;
    }
#endif
    return FULLUPDATE ;
}

int
skip_post( ent, fileinfo, direct )
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    brc_addlist( fileinfo->filename ) ;
    return GOTO_NEXT;
}

int
do_select( ent, fileinfo, direct )
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char bname[STRLEN], bpath[ STRLEN ];
    struct stat st ;

    move(0,0) ;
    clrtoeol();
    prints("��ܤ@�ӰQ�װ� (�^��r���j�p�g�ҥi)\n") ;
    prints("��J�Q�װϦW (���ť���۰ʷj�M): ") ;
    clrtoeol() ;
        
    make_blist() ;
    namecomplete((char *)NULL,bname) ;
    setbpath( bpath, bname );
    if((*bname == '\0') || (stat(bpath,&st) == -1)) {
        move(2,0);
        prints("�����T���Q�װ�.\n");
        pressreturn();
        return FULLUPDATE ;
    }
    if(!(st.st_mode & S_IFDIR)) {
        move(2,0) ;
        prints("�����T���Q�װ�.\n") ;
        pressreturn() ;
        return FULLUPDATE ;
    }

    selboard = 1;
    brc_initial( bname );

    move(0,0);
    clrtoeol();
    move(1,0);
    clrtoeol();
    setbdir( direct, currboard );
    return NEWDIRECT ;
}

int
digest_mode()
{
    extern  char  currdirect[ STRLEN ];

  if(digestmode==YEA)
  {
    digestmode=NA;
    setbdir(currdirect,currboard);
  }
  else
  {
    digestmode=YEA;
    setbdir(currdirect,currboard);
    if(!dashf(currdirect))
    {
            digestmode=NA;
            setbdir(currdirect,currboard);
            return DONOTHING;
    }
  }
    return NEWDIRECT ;
}

int
do_thread()
{
        char buf[STRLEN];

        sprintf(buf,"Threading %s",currboard);
        report(buf);
        move(t_lines-1,0);
        clrtoeol();
        prints("[1;5m�еy��A�t�γB�z���D��...[m\n");
        refresh();
        sprintf(buf,"bin/thread %s",currboard);
        system(buf);
}

int
thread_mode()
{
    extern  char  currdirect[ STRLEN ];

  if(digestmode==2)
  {
    digestmode=NA;
    setbdir(currdirect,currboard);
  }
  else
  {
    digestmode=2;
    setbdir(currdirect,currboard);
    do_thread();
    if(!dashf(currdirect))
    {
            digestmode=NA;
            setbdir(currdirect,currboard);
            return PARTUPDATE;
    }
  }
    return NEWDIRECT ;
}

int
dele_digest(dname,direc)
char *dname;
char *direc;
{
     char digest_name[STRLEN];
     char new_dir[STRLEN];
     char buf[STRLEN];
     char *ptr;
     struct fileheader fh;
     int  pos;

     strcpy(digest_name,dname);
     strcpy(new_dir,direc);

     digest_name[0]='G';
     ptr = strrchr(new_dir, '/') + 1;
     strcpy(ptr, DIGEST_DIR);
     strcpy(buf,currfile);
     strcpy(currfile,digest_name);
     pos=search_record(new_dir, &fh, sizeof(fh), cmpfilename, digest_name);
     if(pos<=0)
     {
        return;
     }
     delete_file(new_dir,sizeof(struct fileheader),pos,cmpfilename);
     strcpy(currfile,buf);
     *ptr='\0';
     sprintf(buf,"%s%s",new_dir,digest_name);
     unlink(buf);
}

int
digest_post(ent, fhdr, direct)
int ent;
struct fileheader *fhdr;
char *direct;
{

  if(!chk_currBM(currBM))
  {
      return DONOTHING ;
  }
  if (digestmode==YEA)
    return DONOTHING;

  if (fhdr->accessed[0] & FILE_DIGEST)
  {
    fhdr->accessed[0]  = (fhdr->accessed[0] & ~FILE_DIGEST);
    dele_digest(fhdr->filename,direct);
  }
  else
  {
    struct fileheader digest;
    char *ptr, buf[64];

    memcpy(&digest, fhdr, sizeof(digest));
    digest.filename[0]='G';
    strcpy(buf, direct);
    ptr = strrchr(buf, '/') + 1;
    ptr[0] = '\0';
    sprintf(genbuf, "%s%s", buf, digest.filename);
    if (dashf(genbuf))
    {
      fhdr->accessed[0] = fhdr->accessed[0] | FILE_DIGEST;
      substitute_record(direct, fhdr, sizeof(*fhdr), ent);
      return PARTUPDATE;
    }
    digest.accessed[0] = 0;
    sprintf( &genbuf[512], "%s%s", buf, fhdr->filename);
    link(&genbuf[512], genbuf);
    strcpy(ptr, DIGEST_DIR);
    if( get_num_records(buf,sizeof(digest) )>MAX_DIGEST)
    {
        move(3,0);
        clrtobot();
        move(4,10);
        prints("��p�A�A����K�峹�w�g�W�L %d �g�A�L�k�A�[�J...\n",MAX_DIGEST);
        pressanykey();
        return PARTUPDATE;
    }
    append_record(buf, &digest, sizeof(digest));
    fhdr->accessed[0] = fhdr->accessed[0] | FILE_DIGEST;
  }
  substitute_record(direct, fhdr, sizeof(*fhdr), ent);
  return PARTUPDATE;
}

#ifndef NOREPLY
int
do_reply(title)
char *title;
{
    strcpy(replytitle, title);
    post_article();
    replytitle[0] = '\0';
    return FULLUPDATE;
}
#endif

int
garbage_line( str )
char *str;
{
    int qlevel = 0;

    while( *str == ':' || *str == '>' ) {
        str++;
        if( *str == ' ' )  str++;
        if( qlevel++ >= 0 )  return 1;
    }
    while( *str == ' ' || *str == '\t' )  str++;
    if( qlevel >= 0 )
        if( strstr( str, "����:\n" )||strstr( str, ": �j\n" ) || strncmp( str, "==>", 3 ) == 0 ||strstr( str, "���峹 ��" ))
            return 1;
    return( *str == '\n' );
}

/* When there is an old article that can be included -jjyang */        
void
do_quote( filepath ,quote_mode)
char    *filepath;
char quote_mode;
{
    FILE        *inf, *outf;
    char        *qfile, *quser;
    char        buf[256], *ptr;
    char        op;
    int         bflag;

    qfile = quote_file;
    quser = quote_user;
    bflag = strncmp( qfile, "mail", 4 );
    outf = fopen( filepath, "w" );
    if( *qfile != '\0' && (inf = fopen( qfile, "r" )) != NULL ) {
        op = quote_mode;
        if( op != 'N' ) {
            fgets( buf, 256, inf );
            if( (ptr = strrchr( buf, ')' )) != NULL ) {
                ptr[1] = '\0';
                if( (ptr = strchr( buf, ':' )) != NULL ) {
                    quser = ptr + 1;
                    while( *quser == ' ' )  quser++;
                }
            }

            if( bflag ) fprintf( outf, "�i �b %s ���j�@������: �j\n", quser );
            else fprintf( outf, "�i �b %s ���ӫH������: �j\n", quser );

            if( op == 'A' ) {
                while( fgets( buf, 256, inf ) != NULL )
                {
                    fprintf( outf, ": %s", buf );
                }
            } else if( op == 'R' ) {
                while (fgets( buf, 256, inf ) != NULL)
                    if( buf[0] == '\n' )  break;
                while( fgets( buf, 256, inf ) != NULL )
                {
                    if(Origin2(buf))
                        continue;
                    fprintf( outf, "%s", buf );
                }
            } else {
                while (fgets( buf, 256, inf ) != NULL)
                    if( buf[0] == '\n' )  break;
                while (fgets( buf, 256, inf ) != NULL) {
                    if( strcmp( buf, "--\n" ) == 0 )
                        break;
                    if( buf[ 250 ] != '\0' )
                        strcpy( buf+250, "\n" );
                    if( !garbage_line( buf ) )
                        fprintf( outf, ": %s", buf );
                }
            }
        }
        fprintf(outf,"\n");
        fclose( inf ); 
    }
    *quote_file = '\0';
    *quote_user = '\0';

    if(!(currentuser.signature==0||header.chk_anony==1))
    {
                addsignature(outf,1);
    }
    fclose(outf);
}

/* Add by SmallPig */
void
getcross(filepath,mode)
char *filepath;
int mode;
{
    FILE        *inf, *of;
    char        buf[256];
    char        owner[256];
    int         count;
    time_t      now;

    now=time(0);
    inf=fopen(quote_file,"r");
    of = fopen( filepath, "w" );
    if(inf==NULL || of ==NULL)
    {
        report("Cross Post error");
        return ;
    }
        if(mode==0)
        {
            if(in_mail==YEA)
            {
                in_mail=NA;
                write_header(of,1/*���g�J .posts*/);
                in_mail=YEA;
            }else
                write_header(of,1/*���g�J .posts*/);
            if(fgets( buf, 256, inf ) != NULL)
            { for(count=8;buf[count]!=' '&&buf[count]!='\n'&&buf[count]!='\0';count++)
                owner[count-8]=buf[count];}
                owner[count-8]='\0';
            if(in_mail==YEA)
                fprintf( of, "[1;37m�i �H�U��r����� [32m%s [37m���H�c �j\n",currentuser.userid);
            else
                fprintf( of, "[1;37m�i �H�U��r����� [32m%s [37m�Q�װ� �j\n",quote_board);
            fprintf( of, "�i ����[32m %s[37m �ҵo�� �j[m\n",owner);
            while( fgets( buf, 256, inf ) != NULL)/*Clear Post header*/
                   if( buf[0] == '\n' )  break;
        }else if(mode==1)
        {
            fprintf( of,"�o�H�H: deliver (�۰ʵo�H�t��), �H��: %s\n",quote_board);
            fprintf( of,"��  �D: %s\n",quote_title);
            fprintf( of,"�o�H��: %s�۰ʵo�H�t�� (%24.24s)\n\n",BoardName,ctime(&now));
            fprintf( of,"�i���g�峹�O�Ѧ۰ʵo�H�t�Ωұi�K�j\n\n");
        }else if(mode==2)
        {
                write_header(of,0/*�g�J .posts*/);
        }
                while( fgets( buf, 256, inf ) != NULL)
                {
                    if((strstr(buf,"�i �H�U��r����� ")&&strstr(buf,"�Q�װ� �j"))||(strstr(buf,"�i ����")&&strstr(buf,"�ҵo�� �j")))
                           continue;
                    else
                           fprintf( of, "%s", buf );
                }
        fclose( inf ); 
        fclose( of);
    *quote_file = '\0';
}


int
do_post()
{
    *quote_file = '\0';
    *quote_user = '\0';
    return post_article();
}

/*ARGSUSED*/
int
post_reply(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char        uid[STRLEN] ;
    char        title[STRLEN] ;
    char        *t ;
    FILE        *fp;


    if(!strcmp(currentuser.userid,"guest"))
        return DONOTHING;
    modify_user_mode( SMAIL );

/* indicate the quote file/user */
    setbfile( quote_file, currboard, fileinfo->filename );
    strcpy( quote_user, fileinfo->owner );

/* find the author */
/*    if (strchr(quote_user, '.')|| strchr(quote_user, '\"')|| strchr(quote_user, '<')) { */
        if(!getuser(quote_user))
        {
        genbuf[ 0 ] = '\0';
        fp = fopen( quote_file, "r" );
        if (fp != NULL) {
             fgets( genbuf, 255, fp );
             fclose( fp ); 
        } 
        t = strtok( genbuf, ":" );
        if ( strncmp( t, "�o�H�H", 6 ) == 0 ||
             strncmp( t, "Posted By", 9) == 0 ||
             strncmp( t, "�@  �a", 6) == 0 ) {
             t = (char *)strtok( NULL, "\r\t\n" ); 
             if(strchr(t, '<'))
             {
                t = (char *)strchr( t, '<' ); 
                t = (char *)strtok( t, "<>" );
             }else
                t = (char *)strtok( t, " " ); 
             strcpy( uid, t );
        } else {
            prints("Error: Cannot find Author ... \n");
            pressreturn();
        }
    } else strcpy( uid, quote_user );
   
/* make the title */
    if (toupper(fileinfo->title[0]) != 'R' || fileinfo->title[1] != 'e' ||
        fileinfo->title[2] != ':') strcpy(title,"Re: ") ;
    else title[0] = '\0';
    strncat(title,fileinfo->title,STRLEN-5) ;

    clear();

/* edit, then send the mail */
    switch (do_send(uid,title)) {
        case -1: prints("�t�εL�k�e�H\n"); break;
        case -2: prints("�e�H�ʧ@�w�g����\n"); break;
        case -3: prints("�ϥΪ� '%s' �L�k���H\n", uid); break;
        default: prints("�H��w���\\�a�H����@�� %s\n", uid);
    }
    pressreturn() ;
    return FULLUPDATE ;
}

/* Add by SmallPig */
int
post_cross(islocal,mode)
char islocal;
int mode;
{
    struct fileheader postfile ;
    char        filepath[STRLEN], fname[STRLEN];
    char        buf[256],buf4[STRLEN],whopost[IDLEN];
    int         fp;
    time_t      now;

    if (!haspostperm(currboard)&&!mode) 
    {
        move( 1, 0 );
        prints("�z�|�L�v���b %s �o���峹.\n",currboard);
        return -1;
    }

    memset(&postfile,0,sizeof(postfile)) ;
    strncpy(save_filename,fname,4096) ;

    now=time(0);
    sprintf(fname,"M.%d.A",now) ;
    if(!mode){
     if(!strstr(quote_title,"(���)"))
         sprintf(buf4,"%s (���)",quote_title);
     else
         strcpy(buf4,quote_title);
    }else
        strcpy(buf4,quote_title);
    strncpy(save_title,buf4,STRLEN) ;   
    setbfile( filepath, currboard, fname );
/*    ip = strrchr(fname,'A') ;*/
    while((fp = open(filepath,O_CREAT|O_EXCL|O_WRONLY,0644)) == -1) {
/*        if(*ip == 'Z')
            ip++,*ip = 'A', *(ip + 1) = '\0' ;
        else
            (*ip)++ ;*/
        now++;
        sprintf(fname,"M.%d.A",now) ;
        setbfile( filepath, currboard, fname );
    }
    close(fp) ;
    strcpy(postfile.filename,fname) ;
    if(mode==1)
        strcpy(whopost,"deliver");
    else
        strcpy(whopost,currentuser.userid);

    strncpy(postfile.owner,whopost,STRLEN) ;
    setbfile( filepath, currboard, postfile.filename );

    local_article = 0;
    /*if ( !strcmp( postfile.title, buf ) && quote_file[0] != '\0' )
       if ( quote_file[255] == 'L' )
            local_article = 1;*/
    if(islocal=='l'||islocal=='L')
         local_article=YEA;
                                                        
    modify_user_mode( POSTING );

    getcross( filepath ,mode);

    strncpy( postfile.title, save_title, STRLEN );
    if ( local_article ) /* local save */
    {
        postfile.filename[ STRLEN - 1 ] = 'L';
        postfile.filename[ STRLEN - 2 ] = 'L';
    }else
    {
        postfile.filename[ STRLEN - 1 ] = 'S';
        postfile.filename[ STRLEN - 2 ] = 'S';
        outgo_post(&postfile,currboard);
    }
    setbdir( buf, currboard );
    if (append_record( buf, &postfile, sizeof(postfile)) == -1) {       
      if(!mode)
      { 
        sprintf(buf, "cross_posting '%s' on '%s': append_record failed!",
                postfile.title, quote_board);
      }else{
        sprintf(buf, "Posting '%s' on '%s': append_record failed!",
                postfile.title, quote_board);
      }                      
        report(buf);
        pressreturn() ;
        clear() ;
        return 1 ;
    }
    if(!mode)
        sprintf(buf,"cross_posted '%s' on '%s'", postfile.title, currboard) ;
    else
        sprintf(buf,"�۰ʵo���t�� POST '%s' on '%s'", postfile.title, currboard) ;
    report(buf) ;
    return 1;
}


void add_loginfo(filepath)
char *filepath;
{       FILE *fp;
        int color,noidboard;
        char fname[STRLEN];
        
        noidboard=/*(seek_in_file("etc/anonymous",currboard)&&Anony)*/header.chk_anony;
        color=(currentuser.numlogins%7)+31;
        setuserfile( fname, "signatures" );
        fp=fopen(filepath,"a");
        if (!dashf(fname)||
            currentuser.signature==0||noidboard)
        {       fputs("\n--\n", fp);
                fprintf(fp, "[m[1;%2dm�� �ӷ�:�E%s %s�E[FROM: %s][m\n"
                ,color,BoardName,email_domain(),(noidboard)?
                "�ΦW�ѨϪ��a":currentuser.lasthost);
                 }else{
                 fprintf(fp, "\n[m[1;%2dm�� �ӷ�:�E%s %s�E[FROM: %s]\033[m\n"
                 ,color,BoardName,email_domain(),(noidboard)?
                 "�ΦW�ѨϪ��a":currentuser.lasthost);
         }
         fclose(fp);
         return;
}

int 
show_board_notes(bname)
char bname[30];
{
    char buf[256];

    sprintf( buf, "vote/%s/notes", bname );
    if( dashf( buf ) ) {
        ansimore2( buf,NA,0,19);
        return 1;
    } else if( dashf( "vote/notes" ) ) {
        ansimore2( "vote/notes",NA,0,19 );
        return 1;
    }
        return -1;
}

int
outgo_post(fh, board)
struct fileheader *fh;
  char *board;
{
  FILE *foo;

  if (foo = fopen("innd/out.bntp", "a"))
  {
    fprintf(foo, "%s\t%s\t%s\t%s\t%s\n", board,
      fh->filename, header.chk_anony?"Anonymous":currentuser.userid, 
      header.chk_anony?"�ڬO�ΦW�Ѩ�":currentuser.username, save_title);
    fclose(foo);
  }
}

int
post_article()
{
    struct fileheader postfile ;
    char        filepath[STRLEN], fname[STRLEN],buf[STRLEN];
    int         fp, aborted;
    time_t      now;

    modify_user_mode(POSTING);
    if (!haspostperm(currboard)) 
    {
        move( 3, 0 );
        clrtobot();
        if(digestmode==NA)
        {
              prints("\n\n        ���Q�װϬO��Ū��, �άO�z�|�L�v���b���o���峹�C");
        }else
        {
              prints("\n\n     �ثe�O��K�ΥD�D�Ҧ�, �ҥH����o���峹.(���������}���Ҧ�)");
        }
        pressreturn();
        clear();
        return FULLUPDATE;
    } else if(deny_me()&&!HAS_PERM(PERM_SYSOP))
    {
        move( 3, 0 );
        clrtobot();
        prints("\n\n                 �ܩ�p�A�A�Q�O�D���� POST ���v�O�C");
        pressreturn();
        clear();
        return FULLUPDATE;
    }    

    memset(&postfile,0,sizeof(postfile)) ;
    clear() ;
    show_board_notes(currboard);
#ifndef NOREPLY
    if( replytitle[0] != '\0' ) {
        if( ci_strncmp( replytitle, "Re:", 3 ) == 0 )
            strcpy(header.title, replytitle);
        else
            sprintf(header.title,"Re: %s", replytitle);
        header.reply_mode=1;
    } else
#endif
   {
      header.title[0]='\0';
      header.reply_mode=0;

   }
   strcpy(header.ds,currboard);
   header.postboard=YEA;
   if( post_header(&header) )
   {
        strcpy(postfile.title, header.title);
        strncpy(save_title,postfile.title,STRLEN) ;
        strncpy(save_filename,fname,4096) ;
   }else
        return FULLUPDATE;
    now=time(0);
    sprintf(fname,"M.%d.A",now) ;
    setbfile( filepath, currboard, fname );
/*    ip = strrchr(fname,'A') ;*/
    while((fp = open(filepath,O_CREAT|O_EXCL|O_WRONLY,0644)) == -1) {
/*        if(*ip == 'Z')
            ip++,*ip = 'A', *(ip + 1) = '\0' ;
        else
            (*ip)++ ;*/
        now++;
        sprintf(fname,"M.%d.A",now) ;
        setbfile( filepath, currboard, fname );
    }
    close(fp) ;
    strcpy(postfile.filename,fname) ;
    in_mail = NA ;
    strncpy(postfile.owner,(header.chk_anony)?
            "Anonymous":currentuser.userid,STRLEN) ;
    setbfile( filepath, currboard, postfile.filename );
    local_article = 0;
    if ( !strcmp( postfile.title, buf ) && quote_file[0] != '\0' )
    if ( quote_file[255] == 'L' )
            local_article = 1;
    modify_user_mode( POSTING );
    do_quote( filepath ,header.include_mode);
    aborted = vedit(filepath,YEA) ;
    add_loginfo(filepath);
    strncpy( postfile.title, save_title, STRLEN );
    if ( aborted == 1 ) /* local save */
    {
        postfile.filename[ STRLEN - 1 ] = 'L';
        postfile.filename[ STRLEN - 2 ] = 'L';
    }else
    {
        postfile.filename[ STRLEN - 1 ] = 'S';
        postfile.filename[ STRLEN - 2 ] = 'S';
      outgo_post(&postfile, currboard);
    }
    if (aborted  == -1) {
        unlink( filepath );
        clear() ;
        return FULLUPDATE ;
    }
    setbdir( buf, currboard );
    if (append_record( buf, &postfile, sizeof(postfile)) == -1) {
        sprintf(buf, "posting '%s' on '%s': append_record failed!",
                postfile.title, currboard);
        report(buf);
        pressreturn() ;
        clear() ;
        return FULLUPDATE ;
    }
    brc_addlist( postfile.filename ) ;

    sprintf(buf,"posted '%s' on '%s'", postfile.title, currboard) ;
    report(buf) ;
    if ( !junkboard() )
    {
           set_safe_record();
           currentuser.numposts++;
    }
    substitute_record(PASSFILE, &currentuser, sizeof(currentuser), usernum);
    return FULLUPDATE ;
}

int
add_edit_mark(fname,mode,title)
char *fname;
int mode;
char *title;
{
        FILE *fp,*out;
        char buf[256];
        time_t now;
        char outname[STRLEN];
        int step=0;

        if( ( fp = fopen (fname,"r") ) == NULL )
                return 0;
        sprintf( outname ,"tmp/%d.editpost",getpid());
        if( ( out = fopen ( outname ,"w") ) == NULL )
                return 0;

        while( ( fgets(buf , 256 , fp) ) != NULL)
        {
                if(mode==1)
                {
/*                        if(step==1)
                                step=2;
                        if(!step && !strncmp(buf,"�o�H��: ",8))
                        {
                                step=1;
                        }*/
                        if(!strncmp(buf,"[1;36m�� �ק�:�E",17))
                                continue;
                        /*if(step!=3&&(!strncmp(buf,"�X  �B: ",8)||!strncmp(buf,"��H��: ",8)))
                                step=1;*/
                        if(Origin2(buf))
                        {
                             now=time(0);   
                             fprintf(out,"[1;36m�� �ק�:�E%s �� %15.15s �ק糧��E[FROM: %.15s][m\n",currentuser.userid,ctime(&now)+4,currentuser.lasthost);
                             step=3;
                        }
                        fputs(buf,out);
                }else
                {
                        if(step!=3&&!strncmp(buf,"��  �D: ",8))
                        {
                                step=3;
                                fprintf(out,"��  �D: %s\n",title);
                                continue;
                        }
                        fputs(buf,out);
                }
        }
        fclose(fp);
        fclose(out);
        rename(outname,fname);
}

/*ARGSUSED*/
int
edit_post(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char buf[512] ;
    char *t ;

    modify_user_mode( EDIT );

    if( !chk_currBM( currBM) )
    {
        if(strcmp( fileinfo->owner, currentuser.userid))
        {
                return DONOTHING ;
        }
    }
    clear() ;
    strcpy(buf,direct) ;
    if( (t = strrchr(buf,'/')) != NULL )
        *t = '\0' ;
    sprintf(genbuf,"%s/%s",buf,fileinfo->filename) ;
    if( vedit(genbuf,NA)!=-1)
    {
            if(ADD_EDITMARK)
                    add_edit_mark(genbuf,1,NULL);
    }
    sprintf(genbuf, "edited post '%s' on %s", fileinfo->title, currboard);
    report(genbuf);
    return FULLUPDATE ;
}

int
edit_title(ent,fileinfo,direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
    char        buf[ STRLEN ];

    if(!HAS_PERM(PERM_SYSOP))
            if( !chk_currBM(currBM))    
        if(strcmp( fileinfo->owner, currentuser.userid))
    {
        return DONOTHING ;
    }
    getdata(t_lines-1,0,"�s�峹���D: ",buf,50,DOECHO,NULL,YEA) ;
    if( buf[0] != '\0' ) {
        char tmp[STRLEN*2],*t;

        strcpy(fileinfo->title,buf);
        strcpy(tmp,direct) ;
        if( (t = strrchr(tmp,'/')) != NULL )
            *t = '\0' ;
        sprintf(genbuf,"%s/%s",tmp,fileinfo->filename) ;
        add_edit_mark(genbuf,2,buf);
        substitute_record(direct, fileinfo, sizeof(*fileinfo), ent);
    }
    return PARTUPDATE;
}

int
mark_post(ent,fileinfo,direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
    if( !HAS_PERM(PERM_SYSOP) )
        if( !chk_currBM(currBM) )
        {
            return DONOTHING;
        }
    if (fileinfo->accessed[0] & FILE_MARKED)
        fileinfo->accessed[0] &= ~FILE_MARKED;
    else fileinfo->accessed[0] |= FILE_MARKED;
    substitute_record(direct, fileinfo, sizeof(*fileinfo), ent);
    return PARTUPDATE;
}

int
del_range(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char num1[11],num2[11] ;
    int inum1, inum2 ;
    
    if(uinfo.mode == READING && !HAS_PERM(PERM_SYSOP ) ) 
        if(!chk_currBM(currBM))
    {
        return DONOTHING ;
    }
    if(digestmode==2)
        return DONOTHING;
    clear() ;
    prints("�ϰ�R��\n") ;
    getdata(1,0,"���g�峹�s��: ",num1,10,DOECHO,NULL,YEA) ;
    inum1 = atoi(num1) ;
    if(inum1 <= 0) {
        prints("���~�s��\n") ;
        pressreturn() ;
        return FULLUPDATE ;
    }
    getdata(2,0,"���g�峹�s��: ",num2,10,DOECHO,NULL,YEA) ;
    inum2 = atoi(num2) ;
    if(inum2 <= inum1) {
        prints("���~�s��\n") ;
        pressreturn() ;
        return FULLUPDATE ;
    }
    getdata(3,0,"�T�w�R�� (Y/N)? [N]: ",num1,10,DOECHO,NULL,YEA) ;
    if(*num1 == 'Y' || *num1 == 'y') {
        delete_range(direct,inum1,inum2) ;
        fixkeep(direct, inum1, inum2);
        sprintf(genbuf, "del %d-%d on %s", inum1, inum2, currboard);
        report(genbuf);
        prints("�R������\n") ;
        pressreturn() ;
        return DIRCHANGED ;
    }
    prints("Delete Aborted\n") ;
    pressreturn() ;
    return FULLUPDATE ;
}

int
del_post(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    FILE        *fn;
    char        buf[512];
    char        usrid[STRLEN];
    char        *t ;
    int         owned, keep, fail;
    extern int SR_BMDELFLAG;

   if(digestmode==2)
        return DONOTHING; 
   keep = sysconf_eval( "KEEP_DELETED_HEADER" );
    if( fileinfo->owner[0] == '-' && keep > 0 &&!SR_BMDELFLAG) {
        clear();
        prints( "���峹�w�R��.\n" );
        pressreturn();
        clear();
        return FULLUPDATE;
    }
    owned = ! strcmp( fileinfo->owner, currentuser.userid );
    strcpy(usrid,fileinfo->owner);
    if( !(owned) && !HAS_PERM(PERM_SYSOP) )
        if( !chk_currBM(currBM))
        {
            return DONOTHING ;
        }
    if(!SR_BMDELFLAG)
    {
      clear() ;
      prints("�R���峹 '%s'.",fileinfo->title) ;
      getdata(1,0,"(Y/N) [N]: ",genbuf,3,DOECHO,NULL,YEA) ;
      if(genbuf[0] != 'Y' && genbuf[0] != 'y') { /* if not yes quit */
        move(2,0) ;
        prints("����\n") ;
        pressreturn() ;
        clear() ;
        return FULLUPDATE ;
      }           
    }
    strcpy(buf,direct) ;
    if( (t = strrchr(buf,'/')) != NULL )
        *t = '\0' ;
    sprintf(genbuf,"Del '%s' on '%s'",fileinfo->title,currboard) ;
    report(genbuf) ;
    strncpy(currfile,fileinfo->filename,STRLEN) ;
    if( keep <= 0 ) {
        fail = delete_file(direct,sizeof(struct fileheader),ent,cmpfilename);
    } else {
        fail = update_file(direct,sizeof(struct fileheader),ent,cmpfilename,
                          cpyfilename);
    }
    if( !fail ) {
        cancelpost( currboard, currentuser.userid, fileinfo, owned );
        sprintf(genbuf,"%s/%s",buf,fileinfo->filename) ;
        if( keep <= 0 ) {
            unlink(genbuf) ;
        } else if( (fn = fopen( genbuf, "w" )) != NULL ) {
            fprintf( fn, "\n\n\t\t���峹�w�Q %s �R��.\n",
                        currentuser.userid );
            fclose( fn );
        }
        if (owned) {
            set_safe_record();
            if (currentuser.numposts > 0&&!junkboard()) currentuser.numposts--;
            substitute_record( PASSFILE, &currentuser,
                                sizeof(currentuser), usernum);          
        }else if(!strstr(usrid,".")&&BMDEL_DECREASE)
        {
                int id;
                if(id = getuser(usrid)) 
                {
                        lookupuser.numposts--;
                        substitute_record(PASSFILE,&lookupuser,sizeof(struct userec),id) ;
                }

        }
        return DIRCHANGED;
    }
    move(2,0) ;
    prints("�R������\n") ;
    pressreturn() ;
    clear() ;
    return FULLUPDATE ;
}

static int sequent_ent ;

int
sequent_messages(fptr)
struct fileheader *fptr ;
{
    static int idc;

    if(fptr == NULL) {
        idc = 0 ;
        return 0 ;
    }
    idc++ ;
  if(readpost){
    if(idc < sequent_ent)
        return 0;
    if( !brc_unread( fptr->filename ) )  return 0;
    mot = 1 ;
    if (continue_flag != 0) {
        genbuf[ 0 ] = 'y';
    } else {
        prints("�Q�װ�: '%s' ���D:\n\"%s\" posted by %s.\n",
                 currboard,fptr->title,fptr->owner) ;
        getdata(3,0,"Ū�� (Y/N/Quit) [Y]: ",genbuf,5,DOECHO,NULL,YEA) ;
    }
    if(genbuf[0] != 'y' && genbuf[0] != 'Y' && genbuf[0] != '\0') {
        if(genbuf[0] == 'q' || genbuf[0] == 'Q') {
            clear() ;
            return QUIT ;
        }
        clear() ;
        return 0;
    }
    setbfile( genbuf, currboard, fptr->filename );
    strcpy( quote_file, genbuf );
    strcpy( quote_user, fptr->owner );
#ifdef NOREPLY
    more(genbuf,YEA);
#else
    ansimore(genbuf,NA) ;
    move(t_lines-1, 0); 
    clrtoeol();
    prints("\033[1;44;31m[�s��Ū�H]  \033[33m�^�H R �x ���� Q,�� �x�U�@�� ' ',�� �x^R �^�H���@��                \033[m");
    continue_flag = 0;
    switch( egetch() ) {
        case 'N': case 'Q':
        case 'n': case 'q':
        case KEY_LEFT: 
            break;
        case 'Y' : case 'R':
        case 'y' : case 'r':
            do_reply(fptr->title);
        case ' ': case '\n':
        case KEY_DOWN:
            continue_flag = 1; break;
        case Ctrl('R'):
            post_reply( 0, fptr, (char *)NULL );
            break;
        default : break;
    }
#endif
    clear() ;}
    setbdir( genbuf, currboard );
    brc_addlist( fptr->filename ) ;
    return 0;
}

int
clear_new_flag(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
        readpost=0;
        sequential_read2(ent);
        return PARTUPDATE;
}
int
sequential_read(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
        readpost=1;
        clear();
        return sequential_read2(ent);
}
/*ARGSUSED*/
int
sequential_read2(ent/*,fileinfo,direct*/)
int ent ;
/*struct fileheader *fileinfo ;
char *direct ;*/
{
    char        buf[ STRLEN ];
      
    sequent_messages((struct fileheader *)NULL) ;
    sequent_ent = ent ;
    quiting = NA ;
    continue_flag = 0;
    setbdir( buf, currboard );
    apply_record( buf,sequent_messages,sizeof(struct fileheader)) ;
    return FULLUPDATE ;
}
/* Added by netty to handle post saving into (0)Announce */
int
Save_post(ent,fileinfo,direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
    if(!HAS_PERM(PERM_SYSOP)) 
        if(!chk_currBM(currBM))
        return DONOTHING ;
    return(a_Save( "0Announce", currboard, fileinfo ,NA));
}

/* Added by netty to handle post saving into (0)Announce */
int
Import_post(ent,fileinfo,direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
    if(!HAS_PERM(PERM_SYSOP)) 
        if(!chk_currBM(currBM) )
        return DONOTHING ;
    return(a_Import( "0Announce", currboard, fileinfo,NA ));
}
int
show_b_note()
{
     clear();
     if(show_board_notes(currboard)==-1)
     {
           move(3,30);
           prints( "���Q�װϩ|�L�u�Ƨѿ��v�C" );
      }
      pressanykey();
      return FULLUPDATE;
}

int
into_announce()
{
     if( a_menusearch( "0Announce", currboard, (HAS_PERM(PERM_ANNOUNCE)||
     HAS_PERM(PERM_SYSOP)||HAS_PERM(PERM_OBOARDS)) ? PERM_BOARDS:0) )
                return FULLUPDATE;
      return DONOTHING;
}

#ifdef INTERNET_EMAIL
int
forward_post(ent,fileinfo,direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
    if( strcmp( "guest", currentuser.userid) == 0 )
        return DONOTHING;
    return(mail_forward(ent, fileinfo, direct));
}

int
forward_u_post(ent,fileinfo,direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
    if( strcmp( "guest", currentuser.userid) == 0)
        return DONOTHING;
    return(mail_uforward(ent, fileinfo, direct));
}

#endif

extern int mainreadhelp() ;
extern int b_vote();
extern int b_results();
extern int b_vote_maintain();
extern int b_notes_edit();

struct one_key  read_comms[] = {
    'r',        read_post,
    'K',        skip_post,
    'u',        skip_post,    
    'd',        del_post,
    'D',        del_range,
    'm',        mark_post,
    'E',        edit_post,
    Ctrl('G'),  digest_mode,
    '`',        digest_mode,
    'g',        digest_post,
    'T',        edit_title,
    's',        do_select,
    Ctrl('C'),  do_cross,
    Ctrl('P'),  do_post,
    'f',        clear_new_flag,
    'S',        sequential_read,
#ifdef INTERNET_EMAIL
    'F',        forward_post,
    'U',        forward_u_post,
    Ctrl('R'),  post_reply,
#endif
    'i',        Save_post,
    'I',        Import_post,
    'R',        b_results,
    'V',        b_vote,
    'M',        b_vote_maintain,
    'W',        b_notes_edit,
    'h',        mainreadhelp,
    Ctrl('J'),  mainreadhelp,
    KEY_TAB,    show_b_note,
    'x',        into_announce,
    'a',        auth_search_down,
    'A',        auth_search_up,
    '/',        t_search_down,
    '?',        t_search_up,
    '\'',        post_search_down,
    '\"',        post_search_up,
    ']',        thread_down,
    '[',        thread_up,
    Ctrl('D'),  deny_user,
    Ctrl('A'),  show_author,
    Ctrl('N'),  SR_first_new,
    'n',        SR_first_new,
    '\\',       SR_last,
    '=',        SR_first,
    Ctrl('S'),  SR_read,
    'p',        SR_read,  
    Ctrl('X'),  SR_read,
    Ctrl('U'),  SR_author,
     'b',       SR_BMfunc,
     'B',       SR_BMfunc,
    Ctrl('T'),  thread_mode,
    '\0',       NULL
  } ;

int
Read()
{
    char        buf[ STRLEN ];
    char        notename[STRLEN];
    time_t      usetime;    
    struct stat st ;

    if(!selboard) {
        move(2,0) ;
        prints("�Х���ܰQ�װ�\n") ;
        pressreturn() ;
        move(2,0) ;
        clrtoeol() ;
        return -1 ;
    }
    in_mail = NA;
    brc_initial( currboard );
    setbdir( buf, currboard );
    
    setvfile(notename,currboard,"notes");
    if(stat(notename,&st)!=-1)
    {
        if(st.st_mtime<(time(NULL)-7*86400))
        {
            sprintf(genbuf,"touch %s",notename);
            system(genbuf);
            setvfile( genbuf, currboard, "noterec" );
            unlink(genbuf);
        }
    }
    if(vote_flag(currboard,'\0',1/*�ˬdŪ�L�s���Ƨѿ��S*/)==0)
    {
        if(dashf( notename ))
        {
                ansimore(notename,YEA);
                vote_flag(currboard,'R',1/*�g�JŪ�L�s���Ƨѿ�*/);
        }
    }
    usetime=time(0);
    i_read( READING, buf,readtitle,readdoent,&read_comms[0],sizeof(struct fileheader)) ;
    board_usage(currboard,time(0)-usetime);
      
    brc_update();
    return 0 ;
}

/*Add by SmallPig*/
void
notepad()
{
    char        tmpname[STRLEN],note1[4];
    char        note[3][STRLEN-4];
    char        tmp[STRLEN];
    FILE        *in;
    int         i,n;
    time_t thetime = time(0);
    extern int talkrequest;
    

    clear();
    move(0,0);
    prints("�}�l�A���d���a�I�j�a�����إH��....\n");
    sprintf(tmpname,"etc/notepad_tmp/%s.notepad",currentuser.userid);
    if( (in = fopen( tmpname, "w" )) != NULL ) {
      for(i=0;i<3;i++)
           memset(note[i],0,STRLEN-4);
      while(1)
      {
              for (i = 0; i < 3; i++)
              {
                     getdata(1 + i, 0, ": ", note[i], STRLEN-5, DOECHO, NULL,NA);
                     if (note[i][0] == '\0')
                         break;
               }
              if(i==0)
              {
                fclose(in);
                unlink(tmpname);
                return;
              }
              getdata(5,0,"�O�_��A���j�@��J�d���O (Y)�O�� (N)���n (E)�A�s�� [Y]: ",note1, 3, DOECHO, NULL,YEA);
              if(note1[0]=='e' || note1[0]=='E')
                continue;
              else
                break;
      }
      if(note1[0]!='N' && note1[0]!='n')
      {
              sprintf(tmp,"[1;32m%s[37m�]%.17s�^",currentuser.userid,currentuser.username);
              fprintf(in,"[1;31;41m��s�w�w�w�w�w�w�w�w�w�w�w�w�w�w�t[37m�Ĳ��W���O[31m�u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�s��[m\n");
              fprintf(in,"[1;31m�~�t%-45s[33m�b [36m%.19s[33m ���}�ɯd�U����[31m�u��\n",tmp,Ctime(&thetime));
              for(n=0;n<i;n++)
              {
                      if (note[n][0] == '\0')
                         break;
                      fprintf(in,"[1;31m�x[m%-74.74s[1;31m�x[m \n",note[n]);
              }
              fprintf(in,"[1;31m���s�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�s��[m \n");
              catnotepad( in, "etc/notepad");
              fclose(in);
              rename(tmpname,"etc/notepad");
      }else
      {
        fclose(in);
        unlink(tmpname);
      }
  }
  if(talkrequest){
          talkreply();
}
    clear();
    return;
} 
    

int
Goodbye()
{
    extern int  started;
    time_t      stay;
    char        fname[STRLEN],notename[STRLEN];
    char        sysoplist[10][STRLEN],syswork[10][STRLEN],spbuf[STRLEN],buf[STRLEN];
    int         i,num_sysop,choose,logouts,mylogout=NA;
    FILE        *sysops;

/* Add by SmallPig */
    strcpy(quote_file,"");
    i=0;
   if((sysops=fopen("etc/sysops","r"))!=NULL)
   {
    while(fgets(buf,STRLEN,sysops)!=NULL&&i<=9)
    {
        strcpy(sysoplist[i],(char *)strtok( buf, " \n\r\t" ));
        strcpy(syswork[i],(char *)strtok( NULL, " \n\r\t" ));
        i++;
    }
    fclose(sysops);
   }
    num_sysop=i;
    move(1,0);
    alarm(0);
    clear() ;
    move(0,0);
    prints("�A�N�n���} %s �A�������@�ǫ�ĳ�ܡH\n",BoardName);
    prints("[[1;33m1[m] �H�H��������\n");
    prints("[[1;33m2[m] �����F�աA���٭n��\n");
 if(strcmp(currentuser.userid,"guest")!=0){
    if( USE_NOTEPAD == 1)
      prints("[[1;33m3[m] �g�g[1;32m�d[33m��[35m��[m�o\n");
 }
    prints("[[1;33m4[m] ���H�o�A�n���}��\n");
    sprintf(spbuf,"�A����ܬO [[1;32m4[m]�G");
    getdata(7,0, spbuf,genbuf, 4, DOECHO, NULL,YEA );
    clear();
    choose=genbuf[0]-'0';
    if(choose==1){
        prints("     ������ ID   �t�d��¾��\n");
        prints("   ============ =============\n");
        for(i=1;i<=num_sysop;i++){
                prints("[[1;33m%1d[m] [1;3%1dm%-12s %s[m\n",i,i%7,sysoplist[i-1]
                ,syswork[i-1]);}
        prints("[[1;33m%1d[m] �٬O���F�o�I\n",num_sysop+1);
        sprintf(spbuf,"�A����ܬO [[1;32m%1d[m]�G",num_sysop+1);      
        getdata(num_sysop+5,0, spbuf,genbuf, 4, DOECHO, NULL ,YEA);
        choose=genbuf[0]-'0';
        if(choose>=1&&choose<=num_sysop)
                do_send(sysoplist[choose-1], "�ϥΪ̱H�Ӫ�����ĳ�H");
                choose=-1;
    }
    if(choose==2)
        return 0;
 if(strcmp(currentuser.userid,"guest")!=0){
    if(choose==3)
        if( USE_NOTEPAD ==1 &&HAS_PERM(PERM_POST))
                notepad();
 }
    
      clear();
      prints("\n\n\n\n");
    if(DEFINE(DEF_OUTNOTE))
    {
        setuserfile(notename,"notes");
        if(dashf(notename))
                ansimore(notename,YEA);
    }

    if(DEFINE(DEF_LOGOUT))
    {
        setuserfile( fname, "logout" );
        if(dashf(fname))
                mylogout=YEA;
    }
    if(mylogout)
    {
        logouts=countlogouts(fname);      
        if(logouts>=1)
        {
                user_display(fname,(logouts==1)?1:
                                   (currentuser.numlogins%(logouts))+1,YEA);
        }
    }else
    {
            if(fill_shmfile(2,"etc/logout","GOODBYE_SHMKEY"))
            {
                show_goodbyeshm();
            }
    }
    report("exit") ;

    stay = time(NULL) - login_start_time; 
    if(started) {
        sprintf( genbuf, "Stay:%3ld (%s)", stay / 60, currentuser.username );
        log_usies( "EXIT ", genbuf );
        u_exit() ;
    }
    set_safe_record();
    currentuser.stay+=stay;
    substitute_record(PASSFILE, &currentuser, sizeof(currentuser), usernum);
    pressreturn();
    if(num_user_logins(currentuser.userid)==0||!strcmp(currentuser.userid,"guest"))/*�ˬd�٦��S���H�b�u�W*/
    {
        FILE *fp;
        char buf[STRLEN],*ptr;

        setuserfile(fname,"msgfile");
        if(DEFINE(DEF_MAILMSG)&&dashf(fname))
        {
                char title[STRLEN];
                time_t now;
                
                now=time(0);
                sprintf(title,"[%12.12s] �Ҧ��T���ƥ�",ctime(&now)+4);
                mail_file(fname,currentuser.userid,title);
        }
        unlink(fname);
        if( (fp=fopen("friendbook","r")) != NULL)
        {
          while(fgets(buf,sizeof(buf),fp)!=NULL)
          { 
                char uid[14];

                ptr=strstr(buf,"@");
                if(ptr==NULL)
                {
                   del_from_file("friendbook",buf);
                   continue;
                }
                ptr++;
                strcpy(uid,ptr);
                ptr=strstr(uid,"\n");
                *ptr='\0';
                if(!strcmp(uid,currentuser.userid))
                        del_from_file("friendbook",buf);
          }
          fclose(fp);
        }
    }
    sleep(1);
    reset_tty() ;
    exit(0) ;
    return -1;
}

void
report(s)
char *s ;
{
    static int disable = NA ;
    int fd ;

    if(disable)
        return ;
    if((fd = open("trace",O_WRONLY|O_CREAT,0644)) != -1 ) {
        char buf[512] ;
        char timestr[10], *thetime;
        time_t dtime;
        time(&dtime);
        thetime = ctime(&dtime);
        strncpy(timestr, &(thetime[11]), 8);
        timestr[8] = '\0';
        flock(fd,LOCK_EX) ;
        lseek(fd,0,SEEK_END) ;
        sprintf(buf,"%s %s %s\n",currentuser.userid, timestr, s) ;
        write(fd,buf,strlen(buf)) ;
        flock(fd,LOCK_UN) ;
        close(fd) ;
        return ;
    }
    disable = YEA ;
    return ;
}

void
board_usage( mode, usetime )
char *mode;
time_t usetime;
{
    time_t      now;
    FILE        *fp;
    char        buf[ 256 ];

    now = time(0);
    sprintf( buf, "%s USE %-20.20s Stay: %5ld (%s)\n", Ctime( &now )+4, mode, usetime ,currentuser.userid);
    if( (fp = fopen( "use_board", "a" )) != NULL ) {
        fputs( buf, fp );
        fclose( fp );
    }
}


int
Info()
{
    modify_user_mode( XMENU );
    ansimore("Version.Info",YEA) ;
    clear() ;
    return 0 ;
}

int
Conditions()
{
    modify_user_mode( XMENU );
    ansimore("COPYING",YEA) ;
    clear() ;
    return 0 ;
}

int
Welcome()
{
    modify_user_mode( XMENU );
    ansimore( "Welcome", YEA );
    clear() ;
    return 0 ;
}

/*int
EditWelcome()
{
    int aborted;
    char ans[8];
    move(3,0);
    
    modify_user_mode( EDITWELC );
    clrtoeol();
    clrtobot();
    getdata(3,0,"(E)�s�� or (D)�R�� Welcome? [E]: ",ans,7,DOECHO,NULL,YEA);
    if (ans[0] == 'D' || ans[0] == 'd') {
        unlink("Welcome");
        move(5,0);
        prints("�w�R��!\n");
        pressreturn();
        clear();
        report( "del welcome" ) ;
        return 0;
    }
    aborted = vedit("Welcome", NA);             
    clear() ;
    if (aborted)
        prints("�����s��.\n");
    else {
        report("edit Welcome") ;
        prints("�ק粒��.\n") ;
    }
    pressreturn() ;
    return 0 ;
}
*/

int
cmpbnames( bname, brec)
char *bname;
struct fileheader *brec;
{
    if (!ci_strncmp( bname, brec->filename, sizeof(brec->filename)))
        return 1;
    else
        return 0;
}

void
cancelpost( board, userid, fh, owned )
char    *board, *userid;
struct fileheader *fh;
int     owned;
{
    struct fileheader   postfile;
    FILE        *fin, *fout;
    char        from[ STRLEN ], path[ STRLEN ];
    char        fname[ STRLEN ], *ptr, *brd;
    int         len;
    time_t      now;

    setbfile( genbuf, board, fh->filename );
    if( (fin = fopen( genbuf, "r" )) != NULL ) {
        brd = owned ? "junk" : "deleted";
        sprintf( fname, "M.%d.A", time(NULL) );
        setbfile( genbuf, brd, fname );
        while(dashf(genbuf)) {
                now++;
                sprintf(fname,"M.%d.A",now) ;
                setbfile( genbuf, brd, fname );
        }
        if( (fout = fopen( genbuf, "w" )) != NULL ) {
            memset(&postfile,0,sizeof(postfile)) ;
            sprintf( genbuf, "%-32.32s - %s", fh->title, userid );
            strcpy( postfile.filename, fname );
            strncpy( postfile.owner, fh->owner, IDLEN );
            strncpy( postfile.title, genbuf, STRLEN );
            postfile.filename[ STRLEN - 1 ] = 'D';
            postfile.filename[ STRLEN - 2 ] = 'D';
        }
        from[0]='\0';
        while( fgets( genbuf, sizeof( genbuf ), fin ) != NULL ) {
            if( fout != NULL ) {
                fputs( genbuf, fout );
            }
            len = strlen( genbuf ) - 1;
            genbuf[ len ] = '\0';
            if( len <= 8 ) {
                break;
            } else if( strncmp( genbuf, "�o�H�H: ", 8 ) == 0 ) {
                if( (ptr = strrchr( genbuf, ')' )) != NULL )
                {
                    *ptr = '\0';
                    if( (ptr = strrchr( genbuf, '(' )) != NULL )
                        strcpy( from, ptr+1 );
                }
            } else if( strncmp( genbuf, "��H��: ", 8 ) == 0 ) {
                strcpy( path, genbuf + 8 );
            }
        }
        if( fout != NULL ) {
            while( fgets( genbuf, sizeof( genbuf ), fin ) != NULL )
                fputs( genbuf, fout );
        }
        fclose( fin );
        if( fout != NULL ) {
            fclose( fout );
            setbdir( genbuf, brd );
            append_record( genbuf, &postfile, sizeof(postfile) );
        }
        if(strchr(fh->owner,'.')||strchr(fh->owner,'"')||strchr(fh->owner,'<')||strchr(fh->owner,'>'))
                return;
        sprintf( genbuf, "%s\t%s\t%s\t%s\t%s\n",
                 board, fh->filename, fh->owner, from, fh->title );
        if( (fin = fopen( "innd/cancel.bntp", "a" )) != NULL ) {
            fputs( genbuf, fin );
            fclose( fin );
        }
    }
}
