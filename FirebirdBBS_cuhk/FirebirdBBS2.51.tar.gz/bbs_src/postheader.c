#include "bbs.h"
extern int numofsig;

int
post_header(header)
struct postheader *header;
{
        int anonyboard=0;
        char r_prompt[20],command_prompt[256],ans[5];
        char titlebuf[STRLEN];

  if(currentuser.signature>numofsig||currentuser.signature<0)
        currentuser.signature=1;
  if(header->reply_mode)
  {
        strcpy(titlebuf,header->title);
        header->include_mode='Y';
  }
  else
        titlebuf[0]='\0';
  if(header->postboard)
        anonyboard=seek_in_file("etc/anonymous",header->ds);
  header->chk_anony=anonyboard;
  while(1)
  {
    if(header->reply_mode)
            sprintf(r_prompt,"�ި��Ҧ� [[1m%c[m]",header->include_mode);
    move( t_lines-4, 0 );
    clrtobot();
    prints("[m%s [1m%s[m      %s\n",
          (header->postboard)?"�o���峹��":"���H�H�G",header->ds,
          (anonyboard)?(header->chk_anony==1?"[1m�n[m�ϥΰΦW":"[1m��[m�ϥΰΦW"):"");
    prints("�ϥμ��D: [1m%-50s[m\n", (header->title[0]=='\0') ? "[���b�]�w�D�D]":header->title);
    prints("�ϥβ� [1m%d[m ��ñ�W��     %s",currentuser.signature
           ,(header->reply_mode)? r_prompt: "");
    if(titlebuf[0]=='\0'){
           move(t_lines-1,0);
           if(header->postboard==YEA||strcmp(header->title,"�S�D�D"))
                strcpy(titlebuf,header->title);
           getdata(t_lines-1,0,"���D: ",titlebuf,50,DOECHO,NULL,NA);
           if(titlebuf[0]=='\0')
           {
                if(header->title[0]!='\0')
                {
                        titlebuf[0]=' ';
                        continue;
                }
                else
                        return NA;
           }
           strcpy(header->title,titlebuf);
           continue;
    }
    move(t_lines-1,0);
sprintf(command_prompt,
"�Ы� [1;32m0[m~[1;32m%d[m ��ñ�W��%s�A[1;32mT[m ����D%s�A[1;32mEnter[m �����Ҧ��]�w: ",numofsig,(header->reply_mode) ? "�A[1;32mY[m/[1;32mN[m/[1;32mR[m/[1;32mA[m ��ި��Ҧ�" : "",(anonyboard)?"[1;32m�AS[m�ΦW":"");     
    getdata(t_lines-1,0,command_prompt,ans,3,DOECHO,NULL,YEA);
    if((ans[0]-'0')>=0&&ans[0]-'0'<=9)
    {
           if(atoi(ans)<=numofsig)
              currentuser.signature=atoi(ans);
    }else if(header->reply_mode&&(toupper( ans[0] )=='Y'||toupper( ans[0] )=='N'
             ||toupper( ans[0] )=='A'||toupper( ans[0] )=='R'))
    {
           header->include_mode=toupper( ans[0] );
    }else if(toupper( ans[0] )=='T')
    {
           titlebuf[0]='\0';
    }else if(toupper( ans[0] )=='S'&& (anonyboard) == 1)
    {
        header->chk_anony=(header->chk_anony==1)?0:1;
    }
     else
    {
        if( header->title[0] == '\0' ) 
                return NA;
        else
                return YEA;
    }
  }
}
