#define VOTE_YN         (1)
#define VOTE_SINGLE     (2)
#define VOTE_MULTI      (3)
#define VOTE_VALUE      (4)
#define VOTE_ASKING     (5)

struct ballot
{
        char    uid[IDLEN];                   /* �벼�H       */
        unsigned int voted;                  /* �벼�����e   */
        char    msg[3][STRLEN];         /* ��ĳ�ƶ�     */
};

struct votebal
{
        char            userid[IDLEN+1];
        char            title[STRLEN];
        char            type;
        char            items[32][38];
        int             maxdays;
        int             maxtkt;
        int             totalitems;
        time_t          opendate;
}
;
