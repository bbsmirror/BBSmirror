#include "bbs.h"
#ifdef lint
#include <sys/uio.h>
#endif
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

int a;

int
enterdir(path)
char *path;
{
        char buf[256];
        sprintf(buf,"%s\r\n",path==NULL?"":path);
        write(a,buf,sizeof(buf));
}

get_con(servername,port)
char *servername;
int port;
{
    struct hostent *h,*h2 ;
    char buf[512] ;
    char hostname[81] ;
    struct sockaddr_in sin ;
    char ch[1];
    int  get;

    gethostname(hostname,80) ;
    if(!(h = gethostbyname(hostname))) {
        perror("gethostbyname") ;
        return -1 ;
    }

    h2 = gethostbyname(servername);
    sin.sin_family=AF_INET;
    memcpy(&sin.sin_addr, h2->h_addr, h2->h_length);
    a=socket(AF_INET,SOCK_STREAM,0);
    sin.sin_port = port;
    if((connect(a, (struct sockaddr *)&sin, sizeof sin))) {
        perror("connect err") ;
        return -1 ;
    }
}

int
showout()
{
    int i,i2,len;
    char *item;
    struct hostent *h,*h2 ;
    char title[100][100];
    char file[100][100];
    char server[100][100];
    int  port[100];
    char buf[512],cch[100];
    char hostname[81] ;
    struct sockaddr_in sin ;
    char ch[1];
    int  get;
buf[0]='\0';


for(i=0;;i++)
{
    i2=0;
    for(i2=0;i2<=255&&(len=read(a,ch,sizeof ch))==1&&ch[0]!='+';i2++)
    {
       buf[i2]=ch[0]; 
    }
       buf[i2]='\0';
        if(/*buf[0]=='.'||*/len!=1)
        {
                break;
        }
        strcpy(title[i],strtok(buf,"\t\n\r"));
        strcpy(file[i],strtok(NULL,"\t\n\r"));
        strcpy(server[i],strtok(NULL,"\t\n\r"));
        port[i]=atoi(strtok(NULL,"\t\n\r"));
        buf[0]='\0';
        ch[0]=' ';
}
  while(1)
  {
    for(i2=0;i2<i;i2++)
        printf("[1;32m%2d [36m%s\n[m",i2,title[i2]+1);
    printf("\n�п�J�A�����: ");
    scanf("%d",&i2);
    if(i2==-1)
        return;
    printf("Entering %s\n",file[i2]);
    get_con(server[i2],port[i2]);
    enterdir(file[i2]);
    if(file[i2][0]=='0')
    {
       while(1)
       {
        if((len=read(a,ch,sizeof ch))==1)
                printf("%s",ch);
        else
                break;
       }
        continue;
    }
    showout();
 }
}


main()
{
    int i,i2;
    char *item;
    struct hostent *h,*h2 ;
    char title[100][100];
    char file[100][100];
    char server[100][100];
    int  port[100];
    char buf[512] ;
    char hostname[81] ;
    struct sockaddr_in sin ;
    char ch[1];
    int  get;
buf[0]='\0';
get_con("sparc.nhltc.edu.tw",70);    
        enterdir("1/bbs");
showout();
    close(a);
}
