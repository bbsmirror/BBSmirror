
import java.io.*;
import java.net.*;
import java.util.*;
import java.text.*;

public class DAYTIMEd
{
	private SimpleDateFormat sdf = new SimpleDateFormat("EEE, MMM dd, yyyy hh:mm:ss +0800", Locale.ENGLISH);

	public void startup(Socket S) throws Exception 
	{
		DataOutputStream sout = new DataOutputStream(new BufferedOutputStream(S.getOutputStream()));
		sout.writeBytes(sdf.format(new Date()));
		sout.writeByte(13);
		sout.writeByte(10);
		sout.flush();
		S.close();
	}	
}
