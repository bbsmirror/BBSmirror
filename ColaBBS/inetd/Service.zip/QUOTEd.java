
import java.io.*;
import java.net.*;
import java.util.*;

public class QUOTEd implements FilenameFilter
{
	public boolean accept(File dir, String name)
	{
		return name.trim().toLowerCase().endsWith(".txt");
	}
	
	private byte[] ReadFile(String FileName) throws Exception
	{
		RandomAccessFile raf;
		String tmp;
		byte[] B = new byte[2048];
		
		raf = new RandomAccessFile(FileName, "r");
		raf.read(B);
		raf.close();
		
		return B;
	}
	
	public void startup(Socket S) throws Exception 
	{
		DataOutputStream sout = new DataOutputStream(new BufferedOutputStream(S.getOutputStream()));
		
		String Path = new String(System.getProperty("user.dir") + File.separatorChar + "QUOTES");
		File FILE = new File(Path);
		
		String FL[] = FILE.list(new QUOTEd());
		Random R = new Random();
		int N = Math.abs(R.nextInt()) % FL.length;

		sout.write(ReadFile(Path + File.separatorChar + FL[N]));
		sout.writeByte(13);
		sout.writeByte(10);
		sout.flush();
		S.close();
	}	
}
