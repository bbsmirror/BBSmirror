
import java.io.*;
import java.net.*;

public class ECHOd
{
	public void startup(Socket S) throws Exception 
	{
		DataOutputStream sout = new DataOutputStream(new BufferedOutputStream(S.getOutputStream()));
		DataInputStream sin = new DataInputStream(S.getInputStream());
		
		byte B;
		while(true)
		{
			B = sin.readByte();
			sout.writeByte(B);
			sout.flush();
		}
	}
}
