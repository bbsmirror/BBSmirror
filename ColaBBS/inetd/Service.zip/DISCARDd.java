
import java.io.*;
import java.net.*;

public class DISCARDd
{
	public void startup(Socket S) throws Exception 
	{	
		DataInputStream sin = new DataInputStream(S.getInputStream());
		
		while(true)
		{
			sin.readByte();
		}
	}	
}
