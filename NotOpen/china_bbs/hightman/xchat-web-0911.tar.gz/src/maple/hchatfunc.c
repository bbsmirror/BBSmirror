/* write by hightman for WebXchat of MapleBBS 3.x 
 * date: 2001/09/11
 * email: hightman@263.net
 * notice: Please dont delete these messages! thanks you!
 */

#ifdef	HAVE_HTTP_SUPPORT

static int strsncpy(char *s1, char *s2, int n) {
	strncpy(s1, s2, n-1);
	if(strlen(s1)>=n && n>0) s1[n-1]=0;
}

static char *ltrim(char *s) {
	char *s2=s;
	while(s2[0]==32) s2++;
	return s2;
}

static char *rtrim(char *s) {
	static char t[512], *t2;
	strsncpy(t, s, 512);
	t2=t+strlen(s)-1;
	while (t2[0]==32 && t2>=0) t2--;
	t2[1]=0;
	return t;
}

#define trim(s) ltrim(rtrim(s))

static char* str_set(char *c1, char *c2) {
	static char str[512], del[256], *tmp1, **tmp2, *s;
	if(c1!=0 && c2!=0) {
		strsncpy(str, c1, 512);
		strsncpy(del, c2, 256);
		tmp1=str;
		tmp2=&tmp1;
	} else {
		while(1) {
			if(tmp2==0) return "";
			if(*tmp2==0) return "";
			s=strsep(tmp2, del);
			if(s[0]) return s;
		}
	}	
}
#define str_next() str_set(0, 0)

static int __to16(char c) {
	if(c>='a'&&c<='f') return c-'a'+10;
	if(c>='A'&&c<='F') return c-'A'+10;
	if(c>='0'&&c<='9') return c-'0';
	return 0;
}

static int __unhcode(char *s) {
	int m, n;
	for(m=0, n=0; s[m]!=0; m++, n++) {
		if(s[m]=='+') {
			s[n]=' ';
			continue;
		}
		if(s[m]=='%') {
			s[n]=__to16(s[m+1])*16+__to16(s[m+2]);
			m+=2;
			continue;
		}
		s[n]=s[m];
	}
	s[n]=0;
}


static
char* webformat(char *s) {

 	int m, n, l, c, mode;
 	char buf[256], *buf2, tmp[20], *ptr;
	char result[5120]; 
	
        l=strlen(s);
		if(l>5120) l = 5120;
		mode = 0;

		bzero(result, 5120);
		ptr = result;
        for(n=0; n<l; n++) {
                c=s[n];
                if(c=='&')
						strcat(result, "&amp;");
                else if(c=='<')
						strcat(result, "&lt;");
                else if(c=='>')
						strcat(result, "&gt;");
				else if(c=='\n')
						strcat(result, "<br>\n");
				else if(c==' ')
						strcat(result, "&nbsp;");
				else if(c=='\t')
						strcat(result, "&nbsp;&nbsp;");
                else if(c==27) {
                        if(s[n+1]!='[') continue;

                        for(m=n+2; m<l && m<n+24; m++)
                                if(!strchr("0123456789;", s[m])) break;
                        strsncpy(buf, &s[n+2], m-(n+2)+1);
                        n=m;
                        if(s[m]!='m') continue;
                        if(strlen(buf)==0) strcat(result, "</font>");
                        str_set(buf, ";");
                        while(1) {
                                buf2=str_next();
                                if(strlen(buf2)==0) break;
                                c=atoi(buf2);
                                if(c==0) strcat(result, "</font>");
                                if(c>=30 && c<=37) 
									{
										if(mode) { mode = 0; strcat(result, "</font>"); }
										else mode = 1;
										sprintf(tmp, "<font class=c%d>", c);
										strcat(result, tmp);
									}
                        }
                }
                else 
					{ 
						sprintf(tmp, "%c", c);
						strcat(result, tmp);
					}
        }
		
		//if(mode) strcat(result, "</font>");
		strcat(result, "</font><br>\n");
		s = result;
		return s;
}

#endif
