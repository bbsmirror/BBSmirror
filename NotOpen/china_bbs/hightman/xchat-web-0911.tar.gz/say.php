<?php
/* write by hightman for WebXchat of MapleBBS 3.x 
 * date: 2001/09/11
 * email: hightman@263.net
 * notice: Please dont delete these messages! thanks you!
 */
$talkurl = "http://10.14.61.248:3636/doTalk"; //please modify it!
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<script language=javascript>
<!--
var dx ='';
var max=10;
var sdx=new Array(max+1);
var whamsg=new Array(20+1);
var base=1;
var saybase=1;
var j,i=0;
var p=1;
var sayp=0;

for (j=1;j<=max+1;j++)sdx[j]='';sdx[0]="������";
for (j=0;j<=max+1;j++)
  whamsg[j]='';
  
function addOne(what){
if (what ==''){
	return false;
}
  if (saybase<max+1) {
   whamsg[saybase]=what;
    saybase++;
  } else {
   for (i=0;i<max;i++)
    whamsg[i]=whamsg[i+1];
   whamsg[i]=what;
  }
  sayp=saybase;
 }
 
 function goPrev(theForm){
  if (sayp>0) sayp--;
   theForm.msg.value=whamsg[sayp];
  theForm.msg.focus();
 }
 function goNext(theForm){
  if (sayp<saybase) sayp++;
   theForm.msg.value=whamsg[sayp];
  theForm.msg.focus(); 
 }


function add(w){
  if (base<max+1) {
   sdx[base]=w;
    base++;
  } else {
   for (i=0;i<max;i++)
    sdx[i]=sdx[i+1];
   sdx[i]=w;
  }
  p=base;
 }
 function gP(){
  if (p>0) p--;
  if(sdx[p]=='')document.inputform.talkto.value='������';
  else document.inputform.talkto.value=sdx[p];
  document.inputform.msg.focus();
 }
 function gN(){
  if (p<base) p++;
  if(sdx[p]=='')document.inputform.talkto.value='������';
  else document.inputform.talkto.value=sdx[p];
  document.inputform.msg.focus();
 }

function checksay( ){
	if(document.inputform.msg.value==''){
		alert('��������Ϊ��');
		document.inputform.msg.focus();
		return false;
	}
	/*
	//������
	if(document.inputform.msg.value.indexOf('/') == 0) // ��'/'��ͷ��action ����
	{
		var msg = document.inputform.msg.value;
		var words = msg.split(' '); // �ָ
		if((words[2] == '') && (document.inputform.talkto.value != '������')) //��talkto���Ϻ��ˡ�
		{
		 document.inputform.message.value = words[0]++document.inputform.talkto.value+words[1];
		 //��/kick //kick
		}
	}
	else if(document.inputform.talkto.value != '������')
	{
		if(document.inputform.ws.value == 'on')
		{
			document.inputform.message.value = '/m'+document.inputform.talkto.value+document.inputform.msg.value;
		}
		else
		{
			document.inputform.message.value = '/to'+document.inputform.talkto.value+document.inputform.msg.value;
		}
	}
	else
	{
		document.inputform.message.value = document.inputform.msg.value;
	}
	
	//end
	*/
	document.inputform.message.value = document.inputform.msg.value;
	dx=document.inputform.talkto.value;
	addOne(document.inputform.msg.value);
	document.inputform.msg.value ='';
	document.inputform.msg.focus();
	return(true);
}

function leavechat()
{
  document.inputform.msg.value='/bye';
  document.inputform.message.value='/bye';
  document.inputform.onSubmit='return true';
  document.inputform.Submit.click();
  //alert('���Ѿ��뿪�����ң�');
  //parent.window.close();
}
				
//-->
</script>
</head>
<body bgcolor="#DCEEC9" topmargin="0" marginwidth="0" marginheight="0">
 <table width="100%" border="0" cellspacing="0" cellpadding="0" align=left>
  <tr> 
  <form method=GET name=inputform action='<? echo $talkurl;?>' target='bl' onsubmit='return(checksay());'>
	<input type='hidden' name='passwd' value='<? echo $passwd; ?>'>
	<input type='hidden' name='userid' value='<? echo $userid; ?>'>
	<input type='hidden' name='message' value=''>
    <td width="100%"  bgcolor="#A0D16B" height="2"></td>
  </tr>
  <tr> 
    <td width="100%" height="4"  bgcolor="#6A9D31"></td>
  </tr>
    <tr >
	<td align=left>����
	<input type="text" name="talkto" size="8" maxlength="20" readonly value="������">
		<input type="button" value="&lt;&lt;" name="cP" language="javascript" onclick="gP();" style="color: #FFFFFF; background-color: #6A9D31">
		<input type="button" value="&gt;&gt;" name="cN" language="javascript" onclick="gN();" style="color: #FFFFFF; background-color: #6A9D31">
    	<input type="checkbox" name="ws">���Ļ�
		<input type='checkbox' name='as' checked=true onclick='parent.u.scrollit();'>����
		<a href="#" onclick="parent.u.document.close();parent.u.document.open();">ˢ��</a>
		<a href="#" target=_blank>����</a>
		[����] <span id="room" class="c31">Main</span> [����] <span id="topic" class="c31">Ƽˮ�������Ե</span>
	</span>
	</td>
    </tr>
    <tr>
      <td>
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td align=left><span id="chatid"><?echo $chatid;?></span>
              <input type="text" name="msg" MAXLENGTH="250" size="50">
              <input type="submit" name="Submit" value="����" style="color: #FFFFFF; background-color: #6A9D31">
		       <input type="button" value="&lt;&lt;" name="pre" language="javascript" onclick="goPrev(document.inputform);" style="color: #FFFFFF; background-color: #6A9D31">
		      <input type="button" value="&gt;&gt;" name="pre" language="javascript" onclick="goNext(document.inputform);" style="color: #FFFFFF; background-color: #6A9D31">
            </td>
            <td align=right>
	         <input TYPE=button name=leave Value='�뿪' onclick="leavechat()"  style="color: #FFFFFF; background-color: #6A9D31">            
            </td>
          </tr>
        </table>
      </td>
    </tr>
</table>
</form>
</body>
</html>