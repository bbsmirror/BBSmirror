<?
/* write by hightman for WebXchat of MapleBBS 3.x 
 * date: 2001/09/11
 * email: hightman@263.net
 * notice: Please dont delete these messages! thanks you!
 */

?>
<html><head>
<script>
<!--
function checkBrowser(){
     if (navigator.appName.indexOf('Netscape') > -1){
     	browser = 'ns';
     	version = navigator.appVersion.charAt(0);
     	bv = browser + version;
     }

     if (navigator.appName.indexOf('Explorer') > -1){
	browser = 'ie';
     	version = navigator.appVersion.charAt(0);
     	bv = browser + version;
     }else{
     	browser = 'other';
     	version = 'other';
     	bv = 'other';
     }
     if (browser!='ie'){
	alert('Ϊ������Ч����������ʹ��Internet Explore����������');
	return;
     }
     if (version<4){
	alert('Ϊ������Ч����������ʹ��IE 4.0���ϰ汾����������');
	return;
     }
}

function dosubmit(){
        if (document.login.userid.value == '' || document.login.passwd.value == ''){
                window.alert("�ʺź������������д!!");
                return false;
        }
        var url="chat.php?userid="+document.forms.login.userid.value+"&passwd="+document.forms.login.passwd.value+"&chatid="+document.login.chatid.value;
        var width = screen.availWidth - 40;
        var height = screen.availHeight - 40;
    	var prop = "toolbar=0,directories=0,scrollbars=1,location=0,frameborder=no,border=0,status=0,menubar=0,resizable=1,top=0,left=0,width="+width+",height="+height;
        newwin=window.open(url,'chat',prop);
        newwin.focus();
        return false;
}
//-->
</script>
<link rel="stylesheet" type="text/css" href="style.css">
<title>��ӭ����MapleBBS Xchat Web�汾! 
		--write by hightman@263.net</title>
</head>
 <body onload='checkBrowser()'><form name=login onsubmit="return(dosubmit())">
 Userid: <input type=text name=userid size=15> <br>
 Chatid: <input type=text name=chatid size=15> <br>
 Passwd: <input type=password name=passwd size=15> <br>
 <input type=submit value=Submit> <input type=reset value=Reset> <br>
 </form></body></html>