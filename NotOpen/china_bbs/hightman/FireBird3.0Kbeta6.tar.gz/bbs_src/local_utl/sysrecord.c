#include "bbs.h"

char *
setbfile( buf, boardname, filename )
char *buf, *boardname, *filename;
{
    sprintf( buf, MY_BBS_HOME "/boards/%s/%s", boardname, filename );
    return buf;
}

char *
setbdir( buf, boardname )
char *buf, *boardname;
{
    char dir[STRLEN];

    strncpy(dir,DOT_DIR,STRLEN);
    dir[STRLEN-1] = '\0';
    sprintf( buf, MY_BBS_HOME "/boards/%s/%s", boardname, dir);
    return buf;
}

void
getcross(filepath,filepath2,nboard,posttitle)
char *filepath,*filepath2,*nboard,*posttitle;
{
    FILE        *inf, *of;
    char        buf[256];
    char        owner[248];
    int         count;
    time_t      now;

    now=time(0);
    inf=fopen(filepath2,"r");
    of = fopen( filepath, "w" );
	
    if(inf==NULL || of ==NULL)
    {
        report("Cross Post error");
        return ;
    }
    fprintf( of,"������: deliver (�Զ�����ϵͳ), ����: %s\n",nboard);
    fprintf( of,"��  ��: %s\n",posttitle);
    fprintf( of,"����վ: �Զ�����ϵͳ (%24.24s)\n\n",ctime(&now));
    fprintf( of,"����ƪ���������Զ�����ϵͳ��������\n\n");
    while( fgets( buf, 256, inf ) != NULL)
              fprintf( of, "%s", buf );
    fclose( inf ); 
    fclose( of);
}

int
post_cross(filename,nboard,posttitle,owner)
char* filename,*nboard,*posttitle,*owner;
{
    struct fileheader postfile ;
    struct shortfile *bp;
    char        filepath[STRLEN], fname[STRLEN];
    char        buf[256],buf4[STRLEN];
    int         fp, count;
    time_t      now;

    memset(&postfile,0,sizeof(postfile)) ;

    now=time(0);
    sprintf(fname,"M.%d.A",now) ;

    setbfile( filepath, nboard, fname );
    count=0;
    while((fp = open(filepath,O_CREAT|O_EXCL|O_WRONLY,0770)) == -1) {
        now++;
        sprintf(fname,"M.%d.A",now) ;
        setbfile( filepath, nboard, fname );
        if (count++ > MAX_POSTRETRY) {
        printf("post retry failed%s\n",filepath);
        return -1;
        }
    }
    close(fp) ;

    strcpy(postfile.filename,fname) ;
    strncpy(postfile.owner,owner,STRLEN);
    strncpy(postfile.title,posttitle,STRLEN);
    
    setbfile( filepath, nboard, postfile.filename );

    getcross( filepath ,filename, nboard,posttitle);
    
    setbdir( buf, nboard );
    if (append_record( buf, &postfile, sizeof(postfile)) == -1) {       
    	printf("post recored fail!\n");
    	return 0;
    }
    printf("post sucessful\n");
    return 1;
}

int
cmpbnames( bname, brec)
char *bname;
struct fileheader *brec;
{
    if (!strncmp( bname, brec->filename, sizeof(brec->filename)))
        return 1;
    else
        return 0;
}

int
postfile(filename,owner,nboard,posttitle)
char *filename,*owner,*nboard,*posttitle;
{
    char dbname[STRLEN];
    struct boardheader fh;

    if(search_record(MY_BBS_HOME "/" BOARDS, &fh, sizeof(fh), cmpbnames, nboard)<=0)
    {
        printf("%s �������Ҳ���",nboard);
        return -1;
    }
    post_cross(filename,nboard,posttitle,owner); 
    return;
}               

securityreport(owner,str,title)
char *owner;
char *str;
{
        FILE *se;
        char fname[STRLEN];

        sprintf(fname,"tmp/security.%s",owner);
        if((se=fopen(fname,"w"))!=NULL)
        {
                fprintf(se,"ϵͳ��ȫ��¼ϵͳ\n\x1b[1mԭ��%s\x1b[m\n",str);
                fclose(se);
                postfile( fname,owner,"syssecurity",title);
                unlink(fname);
        }
}

deliverreport(board,title,str)
char *board;
char *title;
char *str;
{
        FILE *se;
        char fname[STRLEN];

        sprintf(fname,"tmp/deliver.%s.%d",board,time(NULL));
        if((se=fopen(fname,"w"))!=NULL)
        {
                fprintf(se,"%s",str);
                fclose(se);
                postfile( fname,"deliver",board,title);
                unlink(fname);
        }
}


