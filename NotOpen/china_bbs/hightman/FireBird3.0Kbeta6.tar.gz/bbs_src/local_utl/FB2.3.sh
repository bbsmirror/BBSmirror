#! /bin/sh
gcc -o rehome rehome.c record.o
gcc -o chboard chboard.c record.o
gcc -o refriend2 refriend2.c record.o
make repassold
repassold
rehome
chboard
refriend2

