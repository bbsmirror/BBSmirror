#include "bbs.h"
#define PASSWDFILE MY_BBS_HOME "/.PASSWDS"

struct userec66 {                  /* Structure used to hold information in */
        char            userid[IDLEN+2];   /* PASSFILE */
        time_t          firstlogin;
        char            lasthost[16];
        unsigned int    numlogins;
        unsigned int    numposts;
        char            flags[2];
        char            passwd[PASSLEN];
        char            username[NAMELEN];
        char            ident[NAMELEN];
        char            termtype[STRLEN];
        unsigned int    userlevel;
        time_t          lastlogin;
        time_t          stay;
        char            realname[NAMELEN];
        char            address[STRLEN];
        char            email[STRLEN];
        int             signature;
        unsigned int    userdefine;
        time_t          notedate;
        int             noteline;
};
 
main()
{
   int fd1,fd2;
   struct userec newrec;
   struct userec66 oldrec;
   int size1=sizeof(oldrec);
   int size2=sizeof(newrec);
   int sz,cc;
   char* bp;

    if((fd1 = open(PASSWDFILE,O_RDONLY,0660)) == -1) {
        perror("open PASSWDFILE") ;
        return -1 ;
    }
  
    if((fd2 = open("NEWPASSWD",O_WRONLY|O_CREAT,0770)) == -1) {
        perror("create PASSWDFILE") ;
        return -1 ;
    }

    while(read(fd1,&oldrec,size1) == size1) {
       strncpy(newrec.userid,oldrec.userid,IDLEN+1);
       newrec.firstlogin=oldrec.firstlogin;
       strncpy(newrec.lasthost,oldrec.lasthost,15);
       newrec.numlogins=oldrec.numlogins;
       newrec.numposts=oldrec.numposts;
       memcpy(newrec.flags,oldrec.flags,2);
       memcpy(newrec.passwd,oldrec.passwd,PASSLEN);
       memcpy(newrec.username,oldrec.username,NAMELEN);
       memcpy(newrec.ident,oldrec.ident,NAMELEN);
       memcpy(newrec.termtype,oldrec.termtype,STRLEN);
       newrec.userlevel=oldrec.userlevel;
       newrec.lastlogin=oldrec.lastlogin;
       newrec.stay=oldrec.stay;
       memcpy(newrec.realname,oldrec.realname,NAMELEN);
       memcpy(newrec.address,oldrec.address,STRLEN);
       memcpy(newrec.email,oldrec.email,STRLEN);
       newrec.signature=oldrec.signature;
       newrec.userdefine=oldrec.userdefine;
       newrec.notedate=oldrec.notedate;
       newrec.noteline=oldrec.noteline;
       newrec.notemode=0;

       bp=(char*)&newrec;
       sz=size2;
       do {
          cc = write(fd2,bp,sz);
          if ((cc < 0) && (errno != EINTR)) {
              printf("Error on change %s\n",oldrec.userid);
              return;
          }
          if (cc > 0) {
              bp += cc;
              sz -= cc;
          }
       } while (sz > 0);
       printf("%s Sucessful.\n",oldrec.userid);      
    } 
    close(fd1);
    close(fd2);
    system("cp " PASSWDFILE " PASSWD.BAK");
    system("rm -f " PASSWDFILE);
    system("cp NEWPASSWD " PASSWDFILE);       
}

