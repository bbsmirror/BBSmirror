#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "b2g_tables.c"

main()
{
	int fd;
	fd=creat("b2g_table",0660);
	write(fd,BtoG,sizeof(BtoG));
	close(fd);
	fd=creat("g2b_table",0660);
	write(fd,GtoB,sizeof(GtoB));
	close(fd);
}
