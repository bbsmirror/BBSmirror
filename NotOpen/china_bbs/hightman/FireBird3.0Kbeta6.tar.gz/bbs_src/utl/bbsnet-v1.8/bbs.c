
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>
#include <time.h>
#include <pwd.h>

#include "config.h"

unsigned int mode;
struct BBS  bbs[BBS_Max];
int         hosttype;
unsigned char x[BBS_Max];
unsigned char y[BBS_Max];
int         H, n;
char        Username[15];
char        mailbox[35];
int         mailbox_size;
struct stat mailbox_status;
struct stat file_status;
char        Editor[35];
char        Mailer[35];
char        Gopher[35];
char        Ftp[35];
char        Browser[35];
char        Telnet[40];
char        cport[6];
char        clogin[30];		/*---	Add by Zhangwei	1999-08-14	---*/
char        label[5];
char        sel_label[5];
char        symbol[54];
char        Title[MAIN_MENU][20];
char        command[120];
FILE       *fp;
long        now;
long        now_time;
long        idle_time;
long        connect_time;
long        last_key_time;
long        offscreen;
char	    cfg;
void        Clock(int);

int
Info(int c)
{

    if (hosttype == Host_GOPHER) {
	if(Gopher[0])
	    strcpy(command, Gopher);
	else {
	    strcpy(command, "[����] �Ҳ��� Gopher client !");
	    return(0);
	}
    }
    else if (hosttype == Host_FTP) {
	if(Ftp[0])
	    strcpy(command, Ftp);
	else {
	    strcpy(command, "[����] �Ҳ��� FTP client !");
	    return(0);
	}
    }
    else
	strcpy(command, Telnet);

    strcat(command, " ");
    strcat(command, bbs[c].hostname);

    sprintf(cport, " %-4d", bbs[c].port);
    sprintf(clogin, " -l %s", bbs[c].login);

    if (bbs[c].port != 23) {
//        strcat(command, " ");
        strcat(command, cport);
    }
    if (bbs[c].login[0] != '\0') strcat(command, clogin);

    return(1);
}


void
VerErr(void)
{
    ansi_forecolor(LIGHTGRAY);
    ansi_print(Header1 "\n\n");
    ansi_print("��·��Դ��ʽ���ϵ������ڣ���ʽ��ִֹ��!\n");
    ansi_print("���跨�����ϵͳ��װһ�����ϵ�������ʽ��Ѱ���ϵ���˳��Ϊ:\n\n");
    ansi_print("  -  ~/." CFGFILE "\n");
    ansi_print("  -  /usr/local/etc/" CFGFILE "\n");
#if defined(BBSDATA)
    ansi_print("  -  " BBSDATA "\n");
#endif

    if(DEF(DEF_MAILSERV))
	ansi_print("\n����ѯ���ϵ���ʽ, ��ִ�� \"bbs -f\"\n\n");

    ansi_flush();
}

void
Init(void)
{
    doupdate();
    Clock(0);
}

void
Leave(void)
{
    ansi_clear;
    ansi_flush();
    alarm(0);
    wnoutrefresh(stdscr);
    endwin();
}

int         s, secs;

char        helpbar1[] = "[Ctrl-C] ����  [Enter] ����  [Space] ����Ŀ¼  [?] ����";
char        helpbar2[] = "[?] ����  [/] �ػ�өĻ  [!] өĻ����  [1-9] ����Ŀ¼";
char        helpbar3[] = "[Enter] ����   BBS- [Tab] Mailpost  [Ctrl-U] ����";
char       *helpbar[] = {helpbar1, helpbar2, helpbar3};

#define     HELPNUM 3

int         showbar = HELPNUM-1 ;

char        divide_line[] = "����������������������������������������������������������������������������";

void
Redraw(void)
{

    ansi_clear;
    ansi_forecolor(LIGHTGRAY);
    DrawBox2(0, 1, COLS - 1, LINES - 2);
    ansi_print_xy(LINES - 5, 2, divide_line);
    MainMenu(s, secs);
    PutTitle(s, secs);
    Clock(0);
    Menu();
    ansi_flush();
}

#if 0
int
Ask(char *msg)
{
    char        filename[25];
    FILE       *fp;

	sprintf(filename, "/tmp/.bbs.ask.%d", getpid());

	if ((fp = fopen(filename, "w")) == NULL)
	    return;
	fprintf(fp, "BBS " BBSvers "  " BBSdate "  Request: %s\n", msg);

	fclose(fp);
	sprintf(command, "%s -s \"Request %s\" cdsheen@csie.nctu.edu.tw < %s", Mailer, msg, filename);
	system(command);
	unlink(filename);
	return (1);
}
#endif 0

void
Saver(void)
{

    struct stat now_status;

    long int    now;
    struct tm  *tmstruct;
    static      show;

    show = 0;
    nodelay(stdscr, TRUE);
    while (getch() == ERR) {
	time(&now);
	tmstruct = localtime(&now);

	if (tmstruct->tm_sec == 0) {
	    ansi_clear;
	    if (tmstruct->tm_min == 0)
		ansi_bufs("\007");
	    if ((show != 1) && (stat(mailbox, &now_status) >= 0)
		&& (mailbox_size < now_status.st_size))
		show = 1;
	    if (DEF(DEF_MAILCHECK)&&(show == 1) && (!(tmstruct->tm_min % MAILCHKBEEP)))
		ansi_bufs("\007");
	}
	ansi_cprint_xy((tmstruct->tm_min + 1) % (LINES - 1),
	     tmstruct->tm_sec, LIGHTGREEN, "  [19%.2d/%02d/%02d %.2d:%.2d]",
		 tmstruct->tm_year, tmstruct->tm_mon + 1, tmstruct->tm_mday,
		       tmstruct->tm_hour, tmstruct->tm_min);
	if ( DEF(DEF_MAILCHECK) && show == 1)
	    ansi_cprint_xy((tmstruct->tm_min) % (LINES - 1), tmstruct->tm_sec, LIGHTRED, "  [%.2d:%.2d] �������ż�", tmstruct->tm_hour, tmstruct->tm_min);
	ansi_flush();
	sleep(1);
    }
    nodelay(stdscr, FALSE);
    time(&last_key_time);
}


void
Clock(int ignore)
{
    struct stat now_status;
    long int    now;
    struct tm  *tmstruct;

    time(&now);


    tmstruct = localtime(&now);
    if ( DEF(DEF_MAILCHECK) && (stat(mailbox, &now_status) >= 0)
	&& (mailbox_size < now_status.st_size))
	ansi_cprint_xy(LINES - 1, 69, LIGHTRED, "\033[5m\007�������ż�\033[0m");

    ansi_cprint_xy(0, COLS - 17, YELLOW, "19%02d/%02d/%02d  %.2d:%.2d",
		   tmstruct->tm_year, tmstruct->tm_mon + 1,
		   tmstruct->tm_mday, tmstruct->tm_hour, tmstruct->tm_min);

    if ((tmstruct->tm_min == 0) && (tmstruct->tm_sec < 15))
	ansi_cprint_xy(LINES - 1, 69, LIGHTRED, "\033[5m\007  ���㱨ʱ\033[0m");
    else if (tmstruct->tm_min == 1)
	ansi_cprint_xy(LINES - 1, 69, LIGHTRED, "          ");

    HelpBar(LIGHTCYAN, helpbar[showbar = (++showbar) % HELPNUM]);

    signal(SIGALRM, Clock);
    alarm(10);

}


int
main(int argc, char *argv[])
{

    int         c;
    int         i, j, key, callkey;
    char        buffer[Rec_Len + 1];
    long        loc[MAIN_MENU + 1];
    struct stat file_status;
    char	usercfg[50];

    struct passwd *pws;
    char       *ptr, *ptr2;

    now_time = time(NULL);
    idle_time = connect_time = 0;

    strcpy(label, " ?.");
    strcpy(sel_label, "[?]");
    strcpy(symbol, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
    mode = 0;

	if ((pws = getpwuid(getuid())) == NULL) {
		strcpy(usercfg, (char *) getenv("HOME"));
		strcpy(Username, (char *) getenv("USER"));
	} else {
		strcpy(usercfg, pws->pw_dir);
		strcpy(Username, pws->pw_name);
	}

	sprintf(mailbox, MAILBOX1 "%s", Username);

	if (stat(mailbox, &mailbox_status) >= 0)
	    mailbox_size = mailbox_status.st_size;
	else {
		sprintf(mailbox, MAILBOX2 "%s", Username);
		if (stat(mailbox, &mailbox_status) >= 0)
			mailbox_size = mailbox_status.st_size;
		else mailbox_size = 0;
   	}

	if ((ptr = (char *) getenv("EDITOR")) != NULL)
		strcpy(Editor, ptr);
	else
		Editor[0] = '\0';

    Gopher[0] = '\0';

    strcat(usercfg, "/.");
    strcat(usercfg, CFGFILE);

    cfg='u';
    if ((fp = fopen(usercfg, "r")) == NULL) {
	cfg='s';
	if ((fp = fopen(DEF_SYS_BBSDATA, "r")) == NULL) {
	  #if defined(BBSDATA)
	    cfg='d';
	    fp = fopen(BBSDATA, "r");
	  #else
	    cfg='n';
	    ;
	  #endif
	}
    }

	if (fp == NULL) {
		VerErr();
		exit(2);
	}
	i = secs = 0;
	j = 1;
	Gopher[0] = Browser[0] = Ftp[0] = '\0';
	while (fgets(buffer, Rec_Len, fp) != NULL) {
		switch (buffer[0]) {
			case '*':
			    buffer[strlen(buffer) - 1] = '\0';

				ptr = (char *) strchr(buffer, '#');
				if(ptr) *ptr = '\0';

			    ptr = buffer;

			    for (; *ptr != '\0' && *ptr != '['; ptr++);
			    ptr++;

			    for (ptr2 = ptr; *ptr2 != '\0' && *ptr2 != ']'; ptr2++);
			    if(*ptr2) ptr2++;
				while ( (*ptr2 != '\0') && (*ptr2 == ' ') )
					ptr2++;
/*				printf("[%s] [%s]\n", ptr, ptr2); */
				if ((!strncasecmp(ptr, "editor", 6))
						&& (Editor[0] == '\0'))
					strcpy(Editor, ptr2);
			    else if (!strncasecmp(ptr, "telnet", 6))
					strcpy(Telnet, ptr2);
			    else if (!strncasecmp(ptr, "mailer", 6))
					strcpy(Mailer, ptr2);
/*			    else if (!strncasecmp(ptr, "gopher", 6))
					strcpy(Gopher, ptr2);
			    else if (!strncasecmp(ptr, "ftp", 3))
					strcpy(Ftp, ptr2);
*/			    else if (!strncasecmp(ptr, "title", 5))
					strcpy(Title[j - 1], ptr2);
			    else if (!strncasecmp(ptr, "section", 7))
					loc[j++] = loc[0];
			    else if (!strncasecmp(ptr, "mailcheck", 9) && toupper(*ptr2)=='T')
					SETMODE(DEF_MAILCHECK);
			    else if (!strncasecmp(ptr, "counttime", 9) && toupper(*ptr2)=='T')
					SETMODE(DEF_COUNTTIME);
			    else if (!strncasecmp(ptr, "mailserv", 8) && toupper(*ptr2)=='T')
					SETMODE(DEF_MAILSERV);
			    else if (!strncasecmp(ptr, "security", 8) && toupper(*ptr2)=='T')
					SETMODE(DEF_SECURITY);
			    else if (!strncasecmp(ptr, "etenmode", 8) && toupper(*ptr2)=='T')
					SETMODE(DEF_ETENMODE);
			    else if (!strncasecmp(ptr, "offscreen", 9))
					offscreen = atol(ptr2);
			    break;
		}
		loc[0] = ftell(fp);
	}
/*	scanf(">%s", buffer); */
	secs = j - 1;

    if(DEF(DEF_SECURITY)) mode &= ~DEF_MAILSERV;

    for (ptr = Editor, j = 0; *ptr != ' ' && *ptr != '\0'; ptr++, j++)
		command[j] = *ptr;
    command[j] = '\0';

    if ((command[0] == '/') && (stat(command, &file_status) < 0)) {
		printf("�����ʹ�õ� editor : %s\n"
	       "����: �Ҳ��� editor - ������趨���� [Editor] һ��\n"
	       "      �����޸���� EDITOR ��������\n", Editor);
		exit(1);
    }
	for (ptr = Mailer, j = 0; *ptr != ' ' && *ptr != '\0'; ptr++, j++)
		command[j] = *ptr;
	command[j] = '\0';

	if (stat(command, &file_status) < 0) {
		printf("����: �Ҳ��� `mail' - ������趨���� [Mailer] һ��\n");
		exit(1);
	}
	for (ptr = Telnet, j = 0; *ptr != ' ' && *ptr != '\0'; ptr++, j++)
		command[j] = *ptr;
	command[j] = '\0';

	if (stat(command, &file_status) < 0) {
		printf("����: �Ҳ��� `telnet' - ������趨���� [Telnet] һ��\n");
		exit(1);
	}

	for (ptr = Gopher, j = 0; *ptr != ' ' && *ptr != '\0'; ptr++, j++)
		command[j] = *ptr;
	command[j] = '\0';

	if ((command[0] != '\0') && (stat(command, &file_status) < 0)) {
		Gopher[0]='\0';
	}

	for (ptr = Ftp, j = 0; *ptr != ' ' && *ptr != '\0'; ptr++, j++)
		command[j] = *ptr;
	command[j] = '\0';

	if ((command[0] != '\0') && (stat(command, &file_status) < 0)) {
		Ftp[0]='\0';
	}

    callkey = 0;
    s = 1;
	if (argc > 1) {

		if (argv[1][0] == '-') {
			if ( DEF(DEF_MAILSERV) && argv[1][1] == 'f') {
/*				Ask("Format");
				printf("\n������һ�������յ����ϵ���ʽ����, ������������\n\n");
*/			} else if ( DEF(DEF_MAILSERV) && argv[1][1] == 's') {
/*				Ask("Source");
				printf("\n������һ�������յ�ԭʼ��ʽ, ������������\n\n");
*/			} else if (argv[1][1] == 'z') {
				callkey = 1;
				key = '!';
			} else {
/*				printf(Header1 "\n\n");
				if (argv[1][1] != 'h')
				    printf("[����] ��ʽ����ʶ�Ĳ���:  `%s'\n\n", argv[1]);
				if( DEF(DEF_MAILSERV)) {
					printf("Usage: bbs [-f] [-s] [-h] [-z] [1-9[a-Z]]\n\n");
					printf("            -f  ȡ�����ϵ���ʽ\n");
					printf("            -s  ȡ��ԭʼ��ʽ��\n");
				} else
					printf("Usage: bbs [-h] [-z] [1-9[a-Z]]\n\n");
				printf("            -h  ������ѡ��˵��\n");
				printf("            -z  ֱ�ӽ��뱣��ģʽ\n");
				printf("            N   ֱ�������� N ��ѡ��\n");
				printf("            Nx  ֱ������ Nx ѡ��\n\n");
*/			}
			if (!callkey) exit(1);
		} else if (isdigit(argv[1][0])) {
		    s = argv[1][0] - '0';
		    if (s > secs) s = 1;
		    n = read_section(loc[s]);
		    if (argv[1][1] == '\0')
				goto quickmenu;
			else if (argv[1][1] >= 'a')
				c = argv[1][1] - 'a';
			else if ((argv[1][1] <= 'Z') && (argv[1][1] >= 'A'))
				c = 26 + argv[1][1] - 'A';
			else c = 0;

		    if (c >= n)
			c = 0;
			if(!Info(c)) {
				printf("\n%s\n\n",command);
				exit(1);
			}
		    ansi_clear;
		    ansi_cprint(WHITE, Header1 "\n\n");
		    ansi_cprint(LIGHTGREEN, "o ����: %s (%s)\n", bbs[c].name, bbs[c].hostname);
		    ansi_cprint(LIGHTGREEN, "o ������ʱ, �밴 Ctrl-C �뿪\n\n");
		    if (bbs[c].login[0])
				ansi_cprint(LIGHTCYAN, "o ���� %s login\n\n", bbs[c].login);
		    ansi_forecolor(LIGHTGRAY);
		    ansi_flush();
		    idle_time += time(NULL) - now_time;
		    now_time = time(NULL);
		    exec_wait(command, 0);
		    connect_time += time(NULL) - now_time;
		    now_time = time(NULL);
		    Welcome();
		}
	}
quickmenu:

    n = read_section(loc[s]);

    time(&last_key_time);

    initscr();
    raw();
/*    cbreak();*/
    nonl();
    noecho();
    keypad(stdscr, TRUE);
    refresh();

    signal(SIGQUIT, Bye);	/* Ctrl-\ */
    signal(SIGINT, Bye);	/* Ctrl-C */
    signal(SIGTERM, Bye);	/* Terminate */
    signal(SIGTSTP, SIG_IGN);	/* Ctrl-Z */
    /* signal(SIGCONT,CtrlZ); */
    signal(SIGALRM, Clock);

    Clock(0);

    ansi_normal();
    ansi_forecolor(LIGHTGRAY);
    DrawBox2(0, 1, COLS - 1, LINES - 2);
    ansi_print_xy(LINES - 5, 2, divide_line);

    MainMenu(s, secs);
    PutTitle(s, secs);

    H = LINES - 7;
    Menu();

    c = 0;
    do {
	ansi_forecolor(WHITE);
	ansi_print_xy(LINES - 4, 2,
		      "��λ:                 վ��:                                                ");
	ansi_print_xy(LINES - 3, 2,
		      "����:                                                                      ");

	sel_label[1] = symbol[c];

	ansi_ccprint_xy(x[c], y[c] - 1, LIGHTGREEN, BLUE, sel_label);
	ansi_ccprint_xy(x[c], y[c] + 2, LIGHTCYAN, BLUE, bbs[c].name);

	ansi_forecolor(YELLOW);
	ansi_backcolor(BLACK);

	ansi_print_xy(LINES - 4, 8, bbs[c].name);
	ansi_print_xy(LINES - 4, 30, bbs[c].alias);

	ansi_print_xy(LINES - 3, 8, bbs[c].hostname);
	if (bbs[c].port != 23)
	    ansi_print(" %d", bbs[c].port);

	if (bbs[c].login[0] != '\0')
	    ansi_print_xy(LINES - 4, 52, "login: %s", bbs[c].login);

	if(!Info(c))
	    HelpBar( LIGHTRED, command);

	ansi_flush();
	if (callkey == 0)
	    key = getch();
	callkey = 0;
	if (key != ERR)		/* Normal key */
	    time(&last_key_time);
	else {			/* alarm() side-effect */
	    time(&now);
	    if (now - last_key_time >= offscreen) {
		key = '!';
	    }
	}

	label[1] = symbol[c];
	ansi_cprint_xy(x[c], y[c] - 1, LIGHTGREEN, label);
	ansi_cprint_xy(x[c], y[c] + 2, LIGHTGRAY, bbs[c].name);

	ansi_flush();
	switch (key) {
	case 4:	/*---	Ctrl-D	Added by Zhangwei	1999-08-13	---*/
		key = 3;
		break;
	case 27:
	    HelpBar(LIGHTMAGENTA, "�㰴�� [Esc] ��, ��Ҫ�뿪���ٰ�һ�� ..");
	    ansi_flush();
	    key = getch();
	    if ((key == 'O') || (key == '['))
		key = getch();
	    callkey = 1;
	    if (key != 27) {
		switch (key) {
		case 'A':	/* Up */
		case 'i':
		    key = KEY_UP;
		    break;
		case 'B':	/* Down */
		    key = KEY_DOWN;
		    break;
		case 'C':	/* Right */
		    key = KEY_RIGHT;
		    break;
		case 'D':	/* Left */
		    key = KEY_LEFT;
		    break;
		case 'I':	/* ansi  PgUp */
		    /* case 'V':	 at386 PgUp */
		    /* case 'S':	 97801 PgUp */
		    /* case 'v':	 emacs style */
		    key = 32;
		    break;
		case 'G':	/* ansi  PgDn */
		    /* case 'U':	 at386 PgDn */
		    /* case 'T':	 97801 PgDn */
		    key = 127;
		    break;
		case 'H':	/* at386  Home */
		    key = '^';
		    break;
		case 'w':
		case 'F':	/* ansi   End */
		    /* case 'Y':	 at386  End */
		    key = '$';
		    break;
		case '5':	/* vt200 PgUp */
		    key = 127;
		    getch();
		    break;
		case '6':	/* vt200 PgDn */
		    key = 32;
		    getch();
		    break;
		case '1':	/* vt200 Home */
		    key = '^';
		    getch();
		    break;
		case '4':	/* vt200 End */
		    key = '$';
		    getch();
		    break;
		default:
		    callkey = 0;
		}

	    } else {
		key = 3;	/* One more Esc to QUIT */
	    }
	    HelpBar(LIGHTCYAN, helpbar[showbar]);
	    break;
	case KEY_LEFT:
	    c -= H;
	    if (c < 0)
		c = c + H * (int) ((n - 1) / H + 1);
	    if (c >= n)
		c -= H;
	    break;
	case KEY_UP:
	    if (c > 0)
		c--;
	    else
		c = n - 1;
	    break;
	case KEY_RIGHT:
	    c += H;
	    if (c >= n)
		c = c % H;
	    break;
	case KEY_DOWN:
	    c = (c + 1) % n;
	    break;
	case '^':
	    c = 0;
	    break;
	case '$':
	case 273:
	    c = n - 1;
	    break;
	case 32:		/* Space */
	case 338:		/* xterm PgDn */
	    s = (s % secs) + 1;

	    n = read_section(loc[s]);
	    if (c >= n)
		c = n - 1;
	    Redraw();
	    break;
	case 127:		/* Backspace */
	case 8:
	case 339:		/* xterm PgUp */
	    if (s-- == 1)
		s = secs;

	    n = read_section(loc[s]);
	    if (c >= n)
		c = n - 1;
	    Redraw();
	    break;
	case '?':
	    alarm(60);
	    Help();
	    alarm(30);
	case '/':
	    Redraw();
	    break;
	case '!':
	case 26:
	    alarm(0);
	if(DEF(DEF_ETENMODE))
	    printf("\033iM;");
	    ansi_clear;
	    ansi_flush();
	    Saver();
	if(DEF(DEF_ETENMODE))
	    printf("\033iMim;");
	    Redraw();
	    break;
	case '\r':
	case 1943:		/* IBM AIX */
	    if(command[0]=='[') break;
	    Leave();
	    ansi_cprint_xy(0, 0, WHITE, Header1 "\n\n");
	    ansi_cprint(LIGHTGREEN, "o ����: %s (%s)\n", bbs[c].name, bbs[c].hostname);
	    ansi_cprint(LIGHTGREEN, "o ������ʱ���밴 Ctrl-C �뿪\n\n");

	    if (bbs[c].login[0])
		    ansi_cprint(LIGHTCYAN, "o ���� %s login\n\n", bbs[c].login);
	    ansi_forecolor(LIGHTGRAY);

	    ansi_flush();
	    idle_time += time(NULL) - now_time;
	    now_time = time(NULL);
	    exec_wait(command, 1);
	    connect_time += time(NULL) - now_time;
	    last_key_time = now_time = time(NULL);
	    Init();
	    Redraw();
	    break;
	case 22:		/* Ctrl-V */
	    HelpBar(LIGHTRED, "�� ����: " BBSfirst "  ����: " BBSdate " (" BBSvers ") ��");
	    break;
	default:
	    if (!DEF(DEF_SECURITY)) {
		int kk;
	    	switch( key ) {
			case 5:
			    alarm(0);
			    if( cfg != 'u' ) {
				HelpBar( LIGHTCYAN, "�������Լ����趨�����Ƿ�������Ŀ¼�´��һ�� ? (y/n)");
				ansi_flush();
				strcpy( command, "/bin/test");
				kk = getch();
				if( toupper(kk) == 'Y' ) {
				    if( cfg == 's' )
					sprintf( command, "/bin/cp %s %s",
						DEF_SYS_BBSDATA, usercfg);
#if defined(BBSDATA)
				    else
					sprintf( command, "/bin/cp %s %s",
						BBSDATA, usercfg);
#endif
				    exec_wait( command, 1);
				}
				else {
					HelpBar( LIGHTGREEN, "��ʹ���Լ����趨�� - �޷��༭");
					alarm(5);
					break;
				}
			    }
			    if( stat( usercfg, &file_status) < 0 ) {
				HelpBar( LIGHTRED, "[����] �޷��������ϵ�");
				alarm(5);
				break;
			    }
			    sprintf( command, "%s %s", Editor, usercfg);
			    Leave();
			    exec_wait( command, 1);
			    Bye();
			    break;
			case '\t':
			case 16:		/* Ctrl-P */
/*				if (hosttype == Host_BBS) {
					Leave();
					MailPost(c);
					Init();
					Redraw();
					HelpBar(LIGHTRED, "Mailpost - �ż��Ѿ��ĳ�");
				}
*/			    break;
			case 21:		/* Ctrl-U */
/*				if (hosttype == Host_BBS) {
					Leave();
					Mail2user(c);
					Init();
					Redraw();
					HelpBar(LIGHTRED, "�ż��Ѿ��ĳ�����վ�ڵ�ʹ����");
				}
*/			    break;
			case 2:		/* Ctrl-B */
/*			    if (DEF(DEF_MAILSERV) && Ask("Source"))
					HelpBar(LIGHTRED, "[ȡ��ԭʼ��ʽ] �������������յ�������ԭʼ��ʽ");
*/			    break;
			case 6:		/* Ctrl-F */
/*			    if (DEF(DEF_MAILSERV) && Ask("Format"))
					HelpBar(LIGHTRED, "[��ѯ���ϵ���ʽ] �������������յ����������ϵ���ʽ");
*/			    break;
			case 1:		/* Ctrl-A */
/*			    if(!DEF(DEF_MAILSERV))
			    	break;
			    Leave();
			    Mail2author();
			    Init();
			    Redraw();
			    HelpBar(LIGHTRED, "�ż��Ѿ��ͳ�������");
*/			    break;
		}
	    }
	}
	if ((key <= '9') && (key >= '1') && (s != (key - '0'))) {
	    s = key - '0';
	    if (s > secs)
		s = 1;
	    n = read_section(loc[s]);
	    if (c >= n)
		c = n - 1;
	    Redraw();
	}
	if ((key <= 'z') && (key >= 'A')) {
	    if (key >= 'a')
		c = key - 'a';
	    else if ((key <= 'Z') && (key >= 'A'))
		c = 26 + key - 'A';
	    if (c >= n)
		c = 0;
	}
    } while (key != 3);


    Leave();

    Welcome();
}


/* End of `bbs.c' - cdsheen@csie.nctu.edu.tw */
