
#include "config.h"
#include <stdarg.h>

char        _ANSI_BUF[ANSI_LINEMAX];
char        ANSI_BUF[ANSI_BUF_MAX];
int         ANSI_IDX = 0;

int         ANSI_DEF_FORE = LIGHTGRAY;
int         ANSI_NOW_FORE;

char        ansi_fore_color[][8] = {
    "\033[30;0m", "\033[34;0m", "\033[32;0m",
    "\033[36;0m", "\033[31;0m", "\033[35;0m",
    "\033[33;0m", "\033[37;0m",
    "\033[30;1m", "\033[34;1m", "\033[32;1m",
    "\033[36;1m", "\033[31;1m", "\033[35;1m",
    "\033[33;1m", "\033[37;1m"
    };

char        ansi_back_color[][6] = {
    "\033[40m", "\033[44m", "\033[42m",
    "\033[46m", "\033[41m", "\033[45m",
    "\033[43m", "\033[47m"
    };

/*
void
ansi_buf(int len)
{
    int         i;
    for (i = 0; i < len; i++) {
	ANSI_BUF[ANSI_IDX++] = _ANSI_BUF[i];
	if (ANSI_IDX == ANSI_BUF_MAX)
	    ansi_flush();
    }
}
*/

void
ansi_bufs(char *buf)
{
    int         i, len;
    len = strlen(buf);
    for (i = 0; i < len; i++) {
	ANSI_BUF[ANSI_IDX++] = buf[i];
	if (ANSI_IDX == ANSI_BUF_MAX)
	    ansi_flush();
    }
}

void
ansi_flush(void)
{
    if (ANSI_IDX != 0) {
	write(1, ANSI_BUF, ANSI_IDX);
	ANSI_IDX = 0;
    }
}


void
ansi_gotoxy(int x, int y)
{
    sprintf(_ANSI_BUF, "\033[%d;%dH", x + 1, y + 1);
    ansi_bufs(_ANSI_BUF);
}

void
ansi_forecolor(int fore)
{
    ansi_bufs(ansi_fore_color[ANSI_NOW_FORE = ANSI_DEF_FORE = fore]);
}

void
ansi_backcolor(int back)
{
    ansi_bufs(ansi_back_color[back]);
}

void
ansi_color(int fore, int back)
{
    ansi_bufs(ansi_fore_color[ANSI_NOW_FORE = ANSI_DEF_FORE = fore]);
    ansi_bufs(ansi_back_color[back]);
}

void
ansi_normal(void)
{
    ansi_bufs(ansi_fore_color[ANSI_NOW_FORE = ANSI_DEF_FORE = LIGHTGRAY]);
    ansi_bufs(ansi_back_color[BLACK]);
}

void
ansi_print( char *format, ...)
{
    va_list     args;
    if (ANSI_NOW_FORE != ANSI_DEF_FORE)
	ansi_bufs(ansi_fore_color[ANSI_NOW_FORE = ANSI_DEF_FORE]);
    va_start(args ,format);
    vsprintf(_ANSI_BUF, format, args);
    ansi_bufs(_ANSI_BUF);
    va_end(args);
}

void
ansi_cprint( int fore, char *format, ...)
{
    va_list     args;

    ansi_bufs(ansi_fore_color[ANSI_NOW_FORE = fore]);

    va_start(args ,format);
    vsprintf(_ANSI_BUF, format, args);
    ansi_bufs(_ANSI_BUF);
    va_end(args);
}

void
ansi_print_xy( int x, int y, char *format, ...)
{
    va_list     args;
    if (ANSI_NOW_FORE != ANSI_DEF_FORE)
	ansi_bufs(ansi_fore_color[ANSI_NOW_FORE = ANSI_DEF_FORE]);
    ansi_gotoxy(x, y);

    va_start(args ,format);
    vsprintf(_ANSI_BUF, format, args);
    ansi_bufs(_ANSI_BUF);
    va_end(args);
}

void
ansi_cprint_xy( int x, int y, int fore, char *format, ...)
{
    va_list     args;

    ansi_gotoxy( x, y);
    ansi_bufs(ansi_fore_color[ANSI_NOW_FORE = fore]);

    va_start(args ,format);
    vsprintf(_ANSI_BUF, format, args);
    ansi_bufs(_ANSI_BUF);
    va_end(args);
}

void
ansi_ccprint_xy(int x, int y, int fore, int back, char *format, ...)
{
    va_list     args;

    ansi_gotoxy(x, y);
    ansi_bufs(ansi_fore_color[ANSI_NOW_FORE = fore]);
    ansi_bufs(ansi_back_color[back]);

    va_start(args ,format);
    vsprintf(_ANSI_BUF, format, args);
    ansi_bufs(_ANSI_BUF);
    va_end(args);
}

void
HelpBar(int color, char *str)
{
    ansi_cprint_xy(LINES, 0, color, "%-68s", str);
}
