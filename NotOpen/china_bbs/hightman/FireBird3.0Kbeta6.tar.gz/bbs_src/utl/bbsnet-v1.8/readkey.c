
#include <stdio.h>

#if defined(LINUX)
#include <ncurses.h>
#elif defined(FreeBSD)
#include <ncurses.h>
#elif defined(ULTRIX)
#include <cursesX.h>
#else
#include <curses.h>
#endif


int
main(void)
{

    int         key;

    initscr();
    cbreak();
    nonl();
    noecho();
    keypad(stdscr, FALSE);
    refresh();

    printw("Press 'q' to quit .....\n");

    while ((key = getch()) != (int) 'q')
	printw("[%.3d='%c'] ", key, (char) key);

    endwin();
}
