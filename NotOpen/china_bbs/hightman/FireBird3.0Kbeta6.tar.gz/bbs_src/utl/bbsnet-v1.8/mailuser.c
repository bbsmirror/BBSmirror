
#include <stdio.h>
#include "config.h"

#if 0
void
Mail2user(char c)
{
    extern struct BBS bbs[BBS_Max];
    extern char Mailer[35];

    char        buffer[30];
    char        command[80];
    char        subject[60];
    char       *edit_name;

    umask(077);

    ansi_clear;

    ansi_cprint(LIGHTRED, "ע��: ʹ�ñ���\��ǰ����ȷ�� %s BBS ��֧Ԯ Internet Mail to User\n\n", bbs[c].name);

    ansi_cprint(LIGHTGREEN, "\n��������Ҫ�ĸ� %s BBS �ڵ���һλʹ����\n", bbs[c].name);

    do {
	ansi_cprint(LIGHTCYAN, "\nMail to: ");
	ansi_flush();
	fgets(buffer, 20, stdin);
	buffer[strlen(buffer) - 1] = '\0';
	ansi_cprint(YELLOW, "\nȷ���ĸ� ");
	ansi_cprint(LIGHTMAGENTA, buffer);
	ansi_cprint(YELLOW, " ��? [Y] ");
	ansi_flush();
	fgets(command, 20, stdin);

    } while ((command[0] != '\n') && (command[0] != 'y')
	     && (command[0] != 'Y'));

    ansi_cprint(WHITE, "\n�ż��ı�����: ");
    ansi_flush();
    fgets(subject, 59, stdin);
    subject[strlen(subject) - 1] = '\0';
    edit_name = Edit();

    /* Mail post */
    if (!isdigit(bbs[c].hostname[0]))
	sprintf(command, "%s -s \"%s\" %s.bbs@%s < %s", Mailer, subject, buffer, bbs[c].hostname, edit_name);
    else
	sprintf(command, "%s -s \"%s\" %s.bbs@[%s]. < %s", Mailer, subject, buffer, bbs[c].hostname, edit_name);

    system(command);

    Delete();
}
#endif 0
