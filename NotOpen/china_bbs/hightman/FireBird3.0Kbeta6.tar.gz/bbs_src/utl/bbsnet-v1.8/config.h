
/* BBS version 1.8            */
/* First version: Oct 1,1994  */

/* �����汾��Ѷ */
#define BBSver      "v1.8"
#define Patch       "0"
#define BBSdate     "Sep 03,1996"
#define BBSfirst    "Oct 01,1994"
#define BBSvers     BBSver""Patch

#define CFGFILE     "bbsdata-"BBSver
#define BBS_Max     52		/* ������� */
#define Rec_Len     85		/* ÿ�������Ԫ�� */
#define Header1     "bbs "BBSvers"   �� ��·��Դ���߳�ʽ ��"
/* #define DEF_SYS_BBSDATA     "/usr/local/etc/"CFGFILE */
#define DEF_SYS_BBSDATA     "/home/bbs/"CFGFILE
#define MAIN_MENU	(9)
#define MAILCHKBEEP     (5)

/* default ���ϵ�λ�� */
#if defined(NCTUCC)
#define BBSDATA    "/afs/cc.nctu.edu.tw/user0/ec/ie/u8117100/Bin/."CFGFILE
#elif defined(NCTUCSIE)
#define BBSDATA    "/u/cp/81/8117100/."CFGFILE
#elif defined(USERDEF)
#define BBSDATA    USERDEF
#endif

/* mail spool λ�� - �������! */
#define BSD_MAILSPOOL  "/var/mail/"
#define SYSV_MAILSPOOL "/var/spool/mail/"
#define MAILBOX1     SYSV_MAILSPOOL
#define MAILBOX2     BSD_MAILSPOOL

#if defined(LINUX)
#include <ncurses.h>
#elif defined(FREEBSD)
#include <ncurses.h>
#elif defined(ULTRIX)
#include <cursesX.h>
#else
#include <curses.h>
#endif

/* Host structure */

struct BBS {
    char        name[18];	/* ��λ */
    char        alias[20];	/* վ�� */
    char        hostname[60];	/* λַ */
    int         port;		/* port */
    char        login[20];	/* login name */
};

#define Host_TEL	(char)0	/* ���� telnet */
#define Host_BBS	(char)1	/* ���� Mailpost/Mail-to-user  */
#define Host_GOPHER	(char)2	/* �������� Gopher Client ���� */
#define Host_FTP	(char)3	/* �� FTP client ���� */
#define Host_WWW	(char)4	/* disable now */

extern void Welcome(void);
extern void Bye(void);
extern void PutTitle(int, int);
extern void Menu(void);
extern void DrawBox1(int, int, int, int);
extern void DrawBox2(int, int, int, int);
extern void MailPost(char);
extern void Mail2user(char);
extern void Mail2author(void);
extern void Help(void);
extern char *Edit(void);
extern void Delete(void);
extern int  read_section(long);
extern void MainMenu(int, int);
extern int  exec_wait(char *, int);


/* ANSI I/O function ֮ buffer ��С */
#define ANSI_BUF_MAX	4000

/* ANSI I/O function ������֮ÿ�������Ԫ�� */
#define ANSI_LINEMAX	200

/* user define stuff */
#define DEF_MAILCHECK	0x0001
#define DEF_COUNTTIME	0x0002
#define DEF_MAILSERV	0x0004
#define DEF_SECURITY	0x0008
#define DEF_ETENMODE	0x0010

#define DEF(v)		(mode&v)
#define SETMODE(v)	mode |= v

/* ��ɫ���� */

#define BLACK		0
#define BLUE		1
#define	GREEN		2
#define CYAN		3
#define RED		4
#define MAGENTA		5
#define	BROWN		6
#define	LIGHTGRAY	7

#define DARKGRAY	8
#define LIGHTBLUE	9
#define LIGHTGREEN	10
#define LIGHTCYAN	11
#define LIGHTRED	12
#define	LIGHTMAGENTA	13
#define YELLOW		14
#define WHITE		15

/* ���өĻ */
#define ansi_clear		ansi_bufs("\033[2J\033[1;1H")

/* extern void ansi_buf(int); */
extern void ansi_bufs(char *);
extern void ansi_flush(void);
extern void ansi_color(int fore, int back);
extern void ansi_normal(void);

extern void ansi_print( char *, ...);
extern void ansi_cprint( int , char *, ...);
extern void ansi_print_xy( int x, int y, char *, ...);
extern void ansi_cprint_xy( int , int , int , char *, ...);
extern void ansi_ccprint_xy(int , int , int , int , char *, ...);

