/*
    WWW Interface for Firebird Bulletin Board System
    Copyright (C) 1996,1997 Computer Application Studio.
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/stat.h>
#include <sys/param.h>

#include "bbs2www.h"

#define STRLEN   80


void main (int argc, char *argv[])
{
   char DirOfBoard[200], *ptr;
   FILE *inf;
   int  index = 0;
   struct stat st;
   char ArgOfQuery[STRLEN], buf[STRLEN], title[80], fname[80], user[21];
  
   strncpy(ArgOfQuery, getenv("QUERY_STRING"), sizeof(char) * STRLEN);
   if (strstr(ArgOfQuery, ".."))
   {
      printf("Error in handling file!\n");
      exit(1);
   }
   sprintf(DirOfBoard, "%s0Announce%s/.Names", BBSHOME, ArgOfQuery);
   if(!(inf = fopen(DirOfBoard, "r")))
   {
      printf("Error in handling file!\n");
      exit(1);
   }

   printf("Content-type: text/html\n\n\n");
   printf("<html>\n");
   printf("<title>%sBBS������</title>\n", SCHOOLSHORT);
   printf("<body background=\"%sbackground.gif\">\n", GIFSHOME);
   printf("<center>\n");

   while( fgets( buf, sizeof(buf), inf))
   {
     if (ptr = strchr(buf, '\n')) 
        *ptr = '\0';
     if ( strncmp(buf, "# Title=", 8) == 0)
     {
       if (strstr(buf, "(BM: BMS)") || strstr(buf, "(BM: SYSOPS)"))
       {
          printf("Error input!");
          exit(1);
       } 
       printf("<font size=5 color=red>");
       printf("%s", buf + 8);
       printf("</font>\n");
       printf("<hr>\n");
       stat(DirOfBoard, &st);
       if (st.st_size < 83)
       {
          printf("<< Ŀǰû������ >>\n");
          exit(1);
       }
       printf("<table border=1 align=center>\n");
       printf("<tr><th>���<th>���<th>����<th>����</tr>\n");
     }
     else if( strncmp( buf, "Name=", 5 ) == 0)
     {
       strncpy(title, buf + 5, sizeof(title));
       if (title[38] != '\0')
       {
          strncpy(user, title + 38, sizeof(user));
          title[37] = '\0';
          user[20] = '\0';
       }
       else
          user[0] = '\0';
     }
     else if( strncmp( buf, "Path=", 5 ) == 0)
     {
       if( strncmp( buf, "Path=~/", 7 ) == 0) 
          strncpy(fname, buf+7, sizeof(fname));
       else
          strncpy(fname, buf+5, sizeof(fname));
       if(!strstr(title, "(BM: BMS)") && !strstr(title, "(BM: SYSOPS)"))
       {
          index++;
          printf("<tr><td>%d<td>", index);
          sprintf(DirOfBoard, "%s0Announce%s/%s", BBSHOME, ArgOfQuery, fname);
          if (stat (DirOfBoard, &st) == 0 && S_ISREG( st.st_mode) )
          {
             printf("�ļ�");
             printf("<td><a href=\"/cgi-bin/bbsanc?%s/%s\">", ArgOfQuery, fname);
          }
          else if (stat (DirOfBoard, &st) == 0 && S_ISDIR( st.st_mode) )
          {
             printf("Ŀ¼");
             printf("<td><a href=\"/cgi-bin/bbs0an?%s/%s\">", ArgOfQuery, fname);
          }
          else
             printf("����<td><a href=\"mailto:SYSOP.bbs@localhost\">");
          printf("%s</a><td>%s\n", title, user);
       }
     }  
   }

   
   fclose(inf);
   printf("</table>\n");

   printf("<hr>");

   printf("[<a href=%s>������ҳ</a>]", BBSURL);
   printf(" [<a href=\"/cgi-bin/bbssec\">����������</a>]");
   printf(" [<a href=\"/cgi-bin/bbsall\">ȫ��������</a>]");

   printf("</center>\n");
   printf("</body>\n");
   printf("</html>");
}

