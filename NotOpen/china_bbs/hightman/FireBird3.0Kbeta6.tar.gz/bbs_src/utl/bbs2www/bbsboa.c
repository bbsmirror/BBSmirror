/*
    WWW Interface for Firebird Bulletin Board System
    Copyright (C) 1996,1997 Computer Application Studio.
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "bbs2www.h"

#define STRLEN   80
#define BM_LEN   60

struct fileheader {             
   char filename[STRLEN];     
   char owner[STRLEN];
   char title[STRLEN];
   unsigned level;
   unsigned char accessed[12];   
};

struct boardheader {             
        char filename[STRLEN];  
        char owner[STRLEN - BM_LEN];
        char BM[ BM_LEN ];
        char title[STRLEN ];
        unsigned level;
        unsigned char accessed[ 12 ];
};

extern int errno;

void main (int argc, char *argv[])
{
   int fd,fd1;
   char DirOfBoard[200];
   struct boardheader BoardInfo;
   struct fileheader  DirInfo;
   char BoardsFile[512];
   char category;
   int  SectNumber;
   int  index = 0;
   int  total; 
   struct stat st;
   char ArgOfQuery[STRLEN];
   char Secret_boards[][20] = {"admin", "comment", "deleted", "junk", "master", "syssecurity"};

   strncpy(ArgOfQuery, getenv("QUERY_STRING"), sizeof(char) * STRLEN);
   SectNumber =(int) ArgOfQuery[0];
   SectNumber -= '0';

   printf("Content-type: text/html\n\n\n");
   printf("<html>\n");
   printf("<title>Welcome to %sBBS</title>\n", SCHOOLSHORT);
   printf("<body background=\"%sbackground.gif\">\n", GIFSHOME);
   printf("<center>\n");

   printf("<font size=5 color=red>");
   printf("<i>%s -- [%s��]�������б�</i>", STATIONNAME, SectNames[SectNumber][0]);
   printf("</font>\n");

   printf("<hr>\n");

   printf("<table border=1 align=center>\n");
   printf("<tr><th>���<th>����������<th>����<th>��������<th>������</tr>");
  
   sprintf(BoardsFile, "%s.BOARDS", BBSHOME);
//   sprintf(BoardsFile,"/home/httpd/bbs/.BOARDS");
   fd = open(BoardsFile, O_RDONLY);
   if (fd == -1)
   {
      
      printf("no error %d\n",errno);
      printf("Error in opening file %s", BoardsFile);
      exit(1);  
   }
   while (sizeof(BoardInfo) == read(fd, &BoardInfo, sizeof(BoardInfo)))
   {
      category = BoardInfo.title[0];
      if (strchr(CateInSect[SectNumber], category) != NULL)
      {
         if(!strcmp(BoardInfo.filename,Secret_boards[0])) 
            continue;
         if(!strcmp(BoardInfo.filename,Secret_boards[1])) 
            continue;
         if(!strcmp(BoardInfo.filename,Secret_boards[2])) 
            continue;
         if(!strcmp(BoardInfo.filename,Secret_boards[3])) 
            continue;
         if(!strcmp(BoardInfo.filename,Secret_boards[4])) 
            continue;
         if(!strcmp(BoardInfo.filename,Secret_boards[5])) 
            continue;
         sprintf(DirOfBoard, "%sboards/", BBSHOME);
         strcat(DirOfBoard, BoardInfo.filename);
         strcat(DirOfBoard, "/.DIR");
         fd1= open(DirOfBoard, O_RDONLY);
         if (fd1 == -1)
            continue;
         fstat( fd1, &st );
         total = st.st_size / sizeof( DirInfo );
         close(fd1);
         index++;
         printf("<tr><td>%d<td><a href=\"/cgi-bin/bbsdoc?N%s\">%s</a>",index, BoardInfo.filename,  BoardInfo.filename);
         printf("<td> %s<td> %s<td>%d", BoardInfo.BM,BoardInfo.title + 1, total);
      }
   }
   close(fd);
   printf("</table>\n");

   printf("<hr>");

   printf("[<a href=\"%s\">������ҳ</a>]", BBSURL);
   printf(" [<a href=\"/cgi-bin/bbssec\">����������</a>]");
   printf(" [<a href=\"/cgi-bin/bbsall\">ȫ��������</a>]");
   printf(" [<a href=\"%s\">%s</a>]", SCHOOLURL, SCHOOLNAME);

   printf("</center>\n");
   printf("</body>\n");
   printf("</html>");
}
