/*
    WWW Interface for Firebird Bulletin Board System
    Copyright (C) 1996,1997 Computer Application Studio.
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "bbs2www.h"

void plustospace(char *str) {
    register int x;

    for(x=0;str[x];x++) if(str[x] == '+') str[x] = ' ';
}

char x2c(char *what) {
    register char digit;

    digit = (what[0] >= 'A' ? ((what[0] & 0xdf) - 'A')+10 : (what[0] - '0'));
    digit *= 16;
    digit += (what[1] >= 'A' ? ((what[1] & 0xdf) - 'A')+10 : (what[1] - '0'));
    return(digit);
}

void unescape_url(char *url) {
    register int x,y;

    for(x=0,y=0;url[y];++x,++y) {
        if((url[x] = url[y]) == '%') {
            url[x] = x2c(&url[y+1]);
            y+=2;
        }
    }
    url[x] = '\0';
}

char *read_form(char *buf, char *str, char *match, int length)
{
   int i;

   buf = strstr(buf, match); 
   if(buf != NULL) 
      buf += strlen(match); 
   else 
   { 
      printf("Error input!\n"); 
      exit(1); 
   }
   for(i = 0; buf[i] != '&'; i++)
   {
      if(i == length -1)
         break;
      str[i] = buf[i];
   }
   str[i] = '\0';    
   plustospace(str);
   unescape_url(str);
}

void main (int argc, char *argv[])
{
   char *buf, *ptr;
   FILE *fout;
   int i, length, exchange = 1;
   char board[15], title[100], username[20], passwd[20];

   length = atoi(getenv("CONTENT_LENGTH"));
   ptr = buf = (char *)malloc(length + 1);
   buf[length] = '\0';
   fread(buf, sizeof(char), length, stdin);

   read_form(buf, board, "board=", 15); 
   if(strstr(buf, "exchange=N") != NULL)
      exchange = 0;
   read_form(buf, title, "title=", 100); 
   read_form(buf, username, "username=", 20); 
   read_form(buf, passwd, "passwd=", 20); 
   if((buf = strstr(buf, "text=")) == NULL)
   { 
      printf("Input error!\n"); 
      exit(1); 
   } 
   else 
      buf += 5;
   plustospace(buf);
   unescape_url(buf);

   if (username[0] != '\0' && passwd[0] != '\0')
   {
      fout = popen("/usr/lib/sendmail -f www-post@bbs bbs", "w");
      fprintf(fout, "#name: %s\n", username);
      fprintf(fout, "#password: %s\n", passwd);
      fprintf(fout, "#board: %s\n", board);
      fprintf(fout, "#title: %s\n", title);   
      if(exchange == 0)
         fprintf(fout, "#localpost: \n");
      fprintf(fout, "\n");
   
      fputs(buf, fout);
      pclose(fout);
   }

   free(ptr);
   
   printf("Content-type: text/html\n\n\n");
   printf("<html>\n");
   printf("<head><title>Welcome to %sBBS</title>\n", SCHOOLSHORT);
   printf("<meta http-equiv=Refresh content=\"5; url=/cgi-bin/bbsdoc?N%s\">\n", board);
   printf("<body background=\"%sbackground.gif\">\n", GIFSHOME);
   printf("<P>��������������������BBSϵͳ�У���ȴ�Ƭ��... </P>\n");
   printf("<P>����������û����BBS�Ͽ������������£���������������������ơ�");
   printf("�û����Ϳ����Ƿ���ȷ�� ��һ��������Կ���</P>\n");
   printf("</body></html>");
}
