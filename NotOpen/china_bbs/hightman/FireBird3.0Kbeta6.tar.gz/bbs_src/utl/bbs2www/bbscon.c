/*
    WWW Interface for Firebird Bulletin Board System
    Copyright (C) 1996,1997 Computer Application Studio.
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/stat.h>

#include "bbs2www.h"

#define STRLEN   80

struct fileheader {             
   char filename[STRLEN];     
   char owner[STRLEN];
   char title[STRLEN];
   unsigned level;
   unsigned char accessed[12];
};


void main (int argc, char *argv[])
{
   struct fileheader  DirInfo;
   char ch; 
   int  fd;
   FILE *inf;
   char ArgOfQuery[STRLEN];
   char buf[256];
   char Board[20];
   struct stat st;
   int  index = 0, number, total;
   int  infont = 0,inblink =0, inbold =0, inunderline =0;

  
   strncpy(ArgOfQuery, getenv("QUERY_STRING"), sizeof(char) * STRLEN);
   number = strlen(ArgOfQuery); 
   while((index < number) && (ArgOfQuery[index] != '='))
      index ++;
   number = atoi(ArgOfQuery + index + 1); 
   ArgOfQuery[index] = '\0';
   
   if (strstr(ArgOfQuery, "..") != NULL)
   {
      printf("Error in handling file\n");
      exit(1);
   }

   printf("Content-type: text/html\n\n\n");
   printf("<html>\n");
   printf("<title>Welcome to %sBBS</title>\n", SCHOOLSHORT);
   printf("<body background=\"%sbackground.gif\">\n", GIFSHOME);
   
   sprintf(buf, "%sboards/%s", BBSHOME, ArgOfQuery);

   if ((inf = fopen(buf, "r")) == NULL)
   {
      printf("Error in handling file\n");
      exit(1);
   }
   while( fgets( buf, 256, inf ) != NULL )
   {
      index = 0;
      buf[255] = '\0';
      if (buf[0] == ':' || buf[0] == '>')
      {
         printf("<font color=#408080>%c ", buf[0]);
         index = 1; 
         while(index < 256 && buf[index] != '\0')
         {
            if(buf[index] != 27)
               putchar(buf[index]);
            else
               while(buf[index] != 'm' && index < 256)
                  index++;
            index++;
         }
         printf("</font><br>\n");
      }
      else 
      {
         while (buf[index] != '\0')
         {
            if( buf[index] != 27 )
               putchar(buf[index++]);
            else
            {
               index++;
               if (strncmp(buf + index, "[0m", 3) == 0)  /* ״̬��ԭ */
               {
                  if (infont == 1)
                     printf("</font>");
                  if (inblink == 1)
                     printf("</blink>");
                  if (inbold == 1)
                     printf("</b>");
                  if (inunderline == 1)
                     printf("</u>");
                  infont = inblink = inbold = inunderline = 0;
                  index += 3;
               }
               else if (strncmp(buf + index, "[1m", 3) == 0)  /* ������ */
               {
                  if (inbold == 0)
                     printf("<b>");
                  inbold = 1;
                  index += 3;
               }
               else if (strncmp(buf + index, "[4m", 3) == 0)  /* �»��� */
               {
                  if (inunderline == 0)
                     printf("<u>");
                  inunderline = 1;
                  index += 3;
               }
               else if (strncmp(buf + index, "[5m", 3) == 0)  /* ��˸ */
               {
                  if (inblink == 0)
                     printf("<blink>");
                  inblink = 1;
                  index += 3;
               }
               else if (strncmp(buf + index, "[30m", 4) == 0)  /* ��ɫ */
               {
                  if (infont == 1)
                     printf("</font>");
                  printf("<font color=\"#000000\">"); 
                  infont = 1;
                  index += 4;
               } 
               else if (strncmp(buf + index, "[31m", 4) == 0)  /* ��ɫ */
               {
                  if (infont == 1)
                     printf("</font>");
                  printf("<font color=\"#FF0000\">"); 
                  infont = 1;
                  index += 4;
               }
               else if (strncmp(buf + index, "[32m", 4) == 0)  /* ��ɫ */
               {
                  if (infont == 1)
                     printf("</font>");
                  printf("<font color=\"#00FF00\">"); 
                  infont = 1;
                  index += 4;
               }
               else if (strncmp(buf + index, "[33m", 4) == 0)  /* ��ɫ */
               {
                  if (infont == 1)
                     printf("</font>");
                  printf("<font color=\"#800000\">"); 
                  infont = 1;
                  index += 4;
               } 
               else if (strncmp(buf + index, "[34m", 4) == 0)  /* ��ɫ */
               { 
                  if (infont == 1)
                     printf("</font>");
                  printf("<font color=\"#0000FF\">"); 
                  infont = 1;
                  index += 4;
               }
               else if (strncmp(buf + index, "[35m", 4) == 0)  /* ���ɫ */
               {
                  if (infont == 1)
                     printf("</font>");
                  printf("<font color=\"#FF00FF\">"); 
                  infont = 1;
                  index += 4;
               }
               else if (strncmp(buf + index, "[36m", 4) == 0)  /* ����ɫ */
               {
                  if (infont == 1)
                     printf("</font>");
                  printf("<font color=\"#0080FF\">"); 
                  infont = 1;
                  index += 4;
               }
               else if (strncmp(buf + index, "[37m", 4) == 0)  /* ����ɫ */
               { 
                  if (infont == 1)
                     printf("</font>");
                  printf("<font color=\"#C0C0C0\">"); 
                  infont = 1;
                  index += 4;
               }
               else if (strncmp(buf + index, "[1;30m", 6) == 0)  /* ��ɫ */
               {
                  if (infont == 1)
                     printf("</font>");
                  printf("<font color=\"#808080\">"); 
                  infont = 1;
                  index += 6;
               }
               else if (strncmp(buf + index, "[1;31m", 6) == 0)  /* ����ɫ */
               {
                  if (infont == 1)
                     printf("</font>");
                  printf("<font color=\"#FF8080\">"); 
                  infont = 1;
                  index += 6;
               }
               else if (strncmp(buf + index, "[1;32m", 6) == 0)  /* ����ɫ */
               {
                  if (infont == 1)
                     printf("</font>");
                  printf("<font color=\"#00FF80\">"); 
                  infont = 1;
                  index += 6;
               }
               else if (strncmp(buf + index, "[1;33m", 6) == 0)  /* ��ɫ */
               {
                  if (infont == 1)
                     printf("</font>");
                  printf("<font color=\"#FFFF00\">"); 
                  infont = 1;
                  index += 6;
               }
               else if (strncmp(buf + index, "[1;34m", 6) == 0)  /* ����ɫ */
               {
                  if (infont == 1)
                     printf("</font>");
                  printf("<font color=\"#0080FF\">"); 
                  infont = 1;
                  index += 6;
               }
               else if (strncmp(buf + index, "[1;35m", 6) == 0)  /* �����ɫ */
               {
                  if (infont == 1)
                     printf("</font>");
                  printf("<font color=\"#FF80FF\">"); 
                  infont = 1;
                  index += 6;
               }
               else   /* unknow esc sequence */
               {
                  while(buf[index] != 'm' && buf[index] != '\0')
                     index++;
                  index++;
               }
            }
         }
         printf("<br>\n");
      }
   }
   if (infont)
      printf("</font>\n");
   
   fclose(inf);
   index = 0;
   while(ArgOfQuery[index] != '/')
   {
      Board[index] = ArgOfQuery[index];
      index++;
   }
   Board[index] = '\0';
   sprintf(buf, "%sboards/", BBSHOME);
   strcat(buf, Board);
   strcat(buf, "/.DIR");
   fd = open(buf, O_RDONLY);
   if (fd == -1)
   {
      fprintf(stderr, "Error in handling file\n");
      exit(1);
   }
   fstat( fd, &st );           
   total = st.st_size / sizeof( DirInfo );
   if ((number < 1) || (number > total))
      number = total; 
   printf("<hr>\n");
   printf("<center>\n");
   printf(" [<a href=\"/cgi-bin/bbssec\">����������</a>]");
   printf(" [<a href=\"/cgi-bin/bbsall\">ȫ��������</a>]");
   for (index = 1; index < number; index++)
      read(fd, &DirInfo, sizeof(DirInfo));
   if (number > 1)
      printf(" [<a href=\"/cgi-bin/bbscon?%s/%s=%d\">��һƪ</a>]", 
                             Board, DirInfo.filename, number - 1);
   printf(" [<a href=\"/cgi-bin/bbsdoc?S%s=%d\">��������</a>]", Board, number);
   read(fd, &DirInfo, sizeof(DirInfo));
   printf(" [<a href=\"/cgi-bin/bbspst?%s/%s=%d\">����</a>]", 
                             Board, DirInfo.filename, number);
   if (number < total)
   {
      read(fd, &DirInfo, sizeof(DirInfo));
      printf(" [<a href=\"/cgi-bin/bbscon?%s/%s=%d\">��һƪ</a>]", 
                             Board, DirInfo.filename, number + 1);
   }
   printf("</center>\n"); 
   printf("</body>\n");
   printf("</html>");
   close(fd);

}
