/*
    BBS2WWW -- WWW Interface for Firebird Bulletin Board System
    Copyright (C) 1996-1999 Computer Application Studio.
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/uio.h>

#include "bbs2www.h"

int main (int argc, char *argv[])
{
   FILE *fp;
   char ArgOfQuery[STRLEN], buf[256], ch, tmp[80], *ptr; 
   int  index = 0, n, len, infont = 0, inblink =0, inbold =0, inunderline =0,
	quote = 1, signature = 0;

  
   printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
   printf("<html>\n");
#ifdef STYLESHEET
   printf("<link rel=stylesheet type=text/css href=\"%s\">\n", STYLESHEET);
#endif
   printf("<title>%s����������</title>\n", BBSID);
   printf("<body>\n");
   printf("<center>\n");
   printf("<table class=title width=90%%><tr>");
   printf("<th class=title width=33%% align=left>�����Ķ�</th>\n");
   printf("<th class=title width=33%% align=center>%s</th>\n", BBSNAME);
   printf("<th class=title width=34%% align=right>������</th>\n");
   printf("</table>\n");

   printf("<hr>\n");


   strncpy(ArgOfQuery, getenv("QUERY_STRING"), STRLEN);
   
   if (strstr(ArgOfQuery, "..") != NULL)
   {
      printf("Error in handling file\n");
      exit(1);
   }

   sprintf(buf, "%s/0Announce%s", BBSHOME, ArgOfQuery);

   if ((fp = fopen(buf, "r")) == NULL)
   {
      printf("Error in handling file\n");
      exit(1);
   }

   printf("<table class=doc>");
   printf("<tr><td class=doc>");
   printf("<pre>");

   while( fgets( buf, 256, fp) != NULL )
   {
      index = 0;
      buf[255] = '\0';
      if (quote && (strstr(buf,"�Ĵ������ᵽ: ��")
          ||strstr(buf,"�� ���÷�����:")
          ||strstr(buf,"==>[����]:")
          ||(strstr(buf,"==>")&&strstr(buf,") �ᵽ:"))
          ||(strstr(buf,"�� ��")&&strstr(buf,"���������ᵽ: ��"))
          ||(strstr(buf,"==>")&&strstr(buf,"] �����ᵽ:"))
          ||(strstr(buf,"==> ��")&&strstr(buf,"���������ᵽ:"))
          ||(strstr(buf,"==> �")&&strstr(buf,"��������:"))
          ||(strstr(buf,"�� ����")&&strstr(buf,"֮���ԣ�"))))
      {
         printf("<font class=col33>%s</font><br>", buf);
	 quote = 0;
      }
      else
      {
         if (strcmp(buf, "--\n") == 0)
            signature = 1;
         if (buf[0] == ':' || buf[0] == '>')
            printf("<font class=col36>");

         while (buf[index] != '\0')
         {
            if( buf[index] != 27 || buf[index+1] != '[')
            {
               if (buf[index] == '<' && !signature)
                  printf("&lt;");
               else if (buf[index] == '>' && !signature)
                  printf("&gt;");
               else
                  putchar(buf[index]);
               index++;
            }
            else
            {
               index += 2;
               n = 0;
               while(buf[index+n] != 'm' && buf[index+n] != '\0')
                  n++;
               if (buf[index+n] == 'm')
               {
                  len = (n > 79) ? 79 : (n + 1);
                  strncpy(tmp, buf+ index, len);
                  tmp[len] = '\0';
                  index += n + 1;
                  if (tmp[0] == 'm')
                     strcpy(tmp, "0;");
                  else
                     tmp[len - 1] = ';';
                  ptr = strtok(tmp, ";");
                  while (ptr)
                  {
                     n = atoi(ptr);
                     switch (n) {
                        case 0 : if (infont)    /* ״̬��ԭ */
                                    printf("</font>");
                                 if (inblink)
                                    printf("</blink>");
                                 if (inbold)
                                    printf("</b>");
                                 if (inunderline)
                                    printf("</u>");
                                 infont = inblink = inbold = inunderline = 0;
                                 break;
                        case 1 : if (inbold == 0)       /* ������ */
                                    printf("<b>");
                                 inbold = 1;
                                 break;
                        case 4 : if (inunderline == 0)  /* �»��� */
                                    printf("<u>");
                                 inunderline = 1;
                                 break;
                        case 5 : if (inblink == 0)      /* ��˸ */
                                    printf("<blink>");
                                 inblink = 1;
                                 break;
                        case 30: if (infont == 1)       /* ��ɫ */
                                    printf("</font>");
                                 printf("<font class=col30>");
                                 infont = 1;
                                 break;
                        case 31: if (infont == 1)       /* ��ɫ */
                                    printf("</font>");
                                 printf("<font class=col31>");
                                 infont = 1;
                                 break;
                        case 32: if (infont == 1)       /* ��ɫ */
                                    printf("</font>");
                                 printf("<font class=col32>");
                                 infont = 1;
                                 break;
                        case 33: if (infont == 1)       /* ��ɫ */
                                    printf("</font>");
                                 printf("<font class=col33>");
                                 infont = 1;
                                 break;
                        case 34: if (infont == 1)       /* ��ɫ */
                                    printf("</font>");
                                 printf("<font class=col34>");
                                 infont = 1;
                                 break;
                        case 35: if (infont == 1)       /* �ۺ�ɫ */
                                    printf("</font>");
                                 printf("<font class=col35>");
                                 infont = 1;
                                 break;
                        case 36: if (infont == 1)       /* ǳ��ɫ */
                                    printf("</font>");
                                 printf("<font class=col36>");
                                 infont = 1;
                                 break;
                        case 37: if (infont == 1)       /* ��ɫ */
                                    printf("</font>");
                                 printf("<font class=col37>");
                                 infont = 1;
                                 break;
                     }
                     ptr = strtok(NULL, ";");
                  }

               }
               else
               {
                  index += n;
               }

            }
         }
         if (buf[0] == ':' || buf[0] == '>')
            printf("</font>");

      }
   }
   if (infont)
      printf("</font>");
   if (inblink)
      printf("</blink>");
   if (inbold)
      printf("</b>");
   if (inunderline)
      printf("</u>");

   printf("</pre>\n");
   printf("</table>\n");
   
   fclose(fp);
   printf("<hr>\n");
   printf("<table class=foot><th class=foot><a href=%s>������ҳ</a>", BBSURL);
   printf("<th class=foot><a href=\"%s/bbssec\">����������</a>", BBSCGI);
   printf("<th class=foot><a href=\"%s/bbsall\">ȫ��������</a></table>", 
		BBSCGI);
   printf("</center>\n"); 
   printf("</body>\n");
   printf("</html>");

}
