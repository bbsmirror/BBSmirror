/*
    BBS2WWW -- WWW Interface for Firebird Bulletin Board System
    Copyright (C) 1996-1999 Computer Application Studio.
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <time.h>

#include "bbs2www.h"

void print_title(char *title)
{
   int i;

   for (i = 0; title[i]; i++)
      if (title[i] == '<')
         printf("&lt;");
      else if (title[i] == '>')
         printf("&gt;");
      else
         putchar(title[i]);
}

int main (int argc, char *argv[])
{
   FILE	*inf;
   char filename[256], *ptr, ArgOfQuery[STRLEN], buf[STRLEN], 
	title[STRLEN], fname[STRLEN], *user;
   int  index = 0, num = 0, pos;
   struct stat st;
   struct tm   *pt;
  
   printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
   printf("<html>\n");
#ifdef STYLESHEET
   printf("<link rel=stylesheet type=text/css href=\"%s\">\n", STYLESHEET);
#endif
   printf("<title>%s������</title>\n", BBSID);
   printf("<body>\n");
   printf("<center>\n");

   strncpy(ArgOfQuery, getenv("QUERY_STRING"), STRLEN);
   if (strstr(ArgOfQuery, ".."))
   {
      printf("Error input!\n");
      exit(1);
   }
   sprintf(filename, "%s/0Announce%s/.Names", BBSHOME, ArgOfQuery);
   if(!(inf = fopen(filename, "r")))
   {
      printf("Error in handling file %s!\n", filename);
      exit(1);
   }

   while(fgets(buf, sizeof(buf), inf))
   {
      if(strncmp( buf, "Numb=", 5 ) == 0)
      {
          num = 1;
          break;
      }
   }
   rewind(inf);

   while(fgets( buf, sizeof(buf), inf))
   {
     if (ptr = strchr(buf, '\n')) 
        *ptr = '\0';
     if (strncmp(buf, "# Title=", 8) == 0)
     {
       if (strstr(buf, "(BM: BMS)") || strstr(buf, "(BM: SYSOPS)")
				|| strstr(buf, "(BM: : SECRET)"))
       {
          printf("Error input!");
          exit(1);
       } 
       if (ptr = strstr(buf, "(BM: "))
          *ptr = '\0';
       ptr = buf + strlen(buf) - 1;
       while (*ptr == ' ')
	  *ptr-- = '\0';

       printf("<table class=title width=90%%><tr>");
       if (ArgOfQuery[0])
       {
	  printf("<th class=title align=left width=33%%>������</th>\n");
          printf("<th class=title align=center width=33%%>%s</th>\n", BBSNAME);
          printf("<th class=title align=right width=34%%>%s</th>\n", buf + 8);
       }
       else
	  printf("<th class=title align=center>%s</th>\n", buf + 8);
       printf("</table>\n");

       printf("<hr>\n");
       if (num == 0)
       {
          printf("<p><< Ŀǰû������ >>\n</p>");
          exit(1);
       }
       printf("<table class=body>\n");
       printf("<tr><th class=body>���<th class=body>���<th class=body>");
       printf("����<th class=body>����<th class=body>�༭����\n");
     }
     else if( strncmp( buf, "Name=", 5 ) == 0)
     {
       memset(title, 0, STRLEN);
       strncpy(title, buf + 5, sizeof(title));
       if (title[39] != '\0')
       {
	  if (title[38] == '(')
	     user = title + 43;
	  else
             user = title + 39;
	  pos = strlen(user) - 1;
          for (pos = strlen(user) - 1; pos >= 0; pos --)
          {
	     if (user[pos] == ')' || user[pos] == ' ')
                user[pos] = '\0';
             else
                break;
          } 
       }
       else
          user = "\0";
     }
     else if(strncmp(buf, "Path=", 5 ) == 0)
     {
       if(strncmp(buf, "Path=~/", 7 ) == 0) 
          strncpy(fname, buf+7, sizeof(fname));
       else
          strncpy(fname, buf+5, sizeof(fname));
       if(!strstr(title, "(BM: BMS)") && !strstr(title, "(BM: SYSOPS)"))
       {
	  pos = 37;
	  while (title[pos] == ' ')
	     title[pos--] = '\0';
          index++;
          printf("<tr><td class=body%d>%d<td class=body%d>", 
			(index - 1) % 2 + 1, index, (index - 1) % 2 + 1);
          sprintf(filename, "%s/0Announce%s/%s", BBSHOME, ArgOfQuery, fname);
	  if ( stat(filename, &st) != 0)
	  {
	     printf("����<td class=body%d>", (index - 1) % 2 + 1);
             print_title(title);
             printf("<td class=body%d>%s\n", (index - 1) % 2 + 1);
             if (user[0])
                printf("%s", user);
             else
                printf(" ");
             printf("<td class=body%d> <td class=body%d> \n",
			(index - 1) % 2 + 1, (index - 1) % 2 + 1);
	  }
	  else
	  {
	     if (S_ISREG( st.st_mode))
	     {
		printf("�ļ�");
                printf("<td class=body%d><a href=\"%s/bbsanc?%s/%s\">",
                       (index - 1) % 2 + 1, BBSCGI, ArgOfQuery, fname);
	     }
	     else if (S_ISDIR( st.st_mode))
	     {
	        printf("Ŀ¼");
                printf("<td class=body%d><a href=\"%s/bbs0an?%s/%s\">",
                       (index - 1) % 2 + 1, BBSCGI, ArgOfQuery, fname);
	     }
             print_title(title);
             printf("</a><td class=body%d>", (index - 1) % 2 + 1);
             while (ptr = strchr(user, ' '))
             {
                *ptr = '\0';
                printf("<a href=\"%s/bbsqry?%s\">%s</a> ", BBSCGI, user, user);
                user = ptr + 1;
             }
             if (user[0])
                printf("<a href=\"%s/bbsqry?%s\">%s</a>", BBSCGI, user, user);
             else
                printf(" ");

	     pt = localtime(&(st.st_mtime));
	     pt->tm_year += 1900;
	     printf("<td class=body%d>%04d.%02d.%02d\n", (index - 1) % 2 + 1,
			pt->tm_year, pt->tm_mon+1, pt->tm_mday );
	  }
       }
     }    
   }
  
   fclose(inf);
   printf("</table>\n");

   printf("<hr>\n");

   printf("<table class=foot><th class=foot><a href=%s>������ҳ</a>", BBSURL);
   
   if (strlen(ArgOfQuery) > 1)
      for (index = strlen(ArgOfQuery) - 2; index >= 0; index--)
      {
         if (ArgOfQuery[index] == '/')
         {
     	    ArgOfQuery[index] = '\0';
     	    printf("<th class=foot><a href=\"%s/bbs0an?%s\">�ϲ�Ŀ¼</a>", 
			BBSCGI, ArgOfQuery);
     	    break;
         }
      }
   printf("<th class=foot><a href=\"%s/bbssec\">����������</a>", BBSCGI);
   printf("<th class=foot><a href=\"%s/bbsall\">ȫ��������</a></table>\n", 
		BBSCGI);

   printf("</center>\n");
   printf("</body>\n");
   printf("</html>");
}

