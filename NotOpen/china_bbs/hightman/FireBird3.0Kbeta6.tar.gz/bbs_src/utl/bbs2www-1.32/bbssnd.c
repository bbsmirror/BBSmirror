/*
    BBS2WWW -- WWW Interface for Firebird Bulletin Board System
    Copyright (C) 1996-1999 Computer Application Studio.
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/uio.h>

#include "bbs2www.h"

#define ANONY_FLAG	0x8
#define PERM(x)		((x)?record.userlevel&(x):1)

char *crypt();

void plustospace(char *str) 
{
    register int x;

    for(x=0;str[x];x++) if(str[x] == '+') str[x] = ' ';
}

char x2c(char *what) {
    register char digit;

    digit = (what[0] >= 'A' ? ((what[0] & 0xdf) - 'A')+10 : (what[0] - '0'));
    digit *= 16;
    digit += (what[1] >= 'A' ? ((what[1] & 0xdf) - 'A')+10 : (what[1] - '0'));
    return(digit);
}

void unescape_url(char *url) {
    register int x,y;

    for(x=0,y=0;url[y];++x,++y) {
        if((url[x] = url[y]) == '%') {
            url[x] = x2c(&url[y+1]);
            y+=2;
        }
    }
    url[x] = '\0';
}

void read_form(char *buf, char *str, char *match, char *next)
{
   int i, length;

   buf = strstr(buf, match); 
   if(buf == NULL || (strstr(buf, next)== NULL)) 
   {
      printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
      printf("Error input! \n");
      exit(1);
   }
   else
      buf += strlen(match); 
   length = strlen(next);
   for(i = 0; strncmp(buf + i, next, length); i++)
      str[i] = buf[i];
   str[i] = '\0';    
}

int junkboard(char *board)
{
#ifdef FB30
   if (strstr(JUNKBOARDS, board))
        return 1;
   else
        return 0;
#else
   FILE *fp;
   char filename[STRLEN], buf[256];

   sprintf(filename, "%s/etc/junkboards", BBSHOME);
   if (fp = fopen(filename, "r"))
   {
       while (fgets(buf, STRLEN, fp))
          if (strncmp(buf, board, strlen(board)) == 0)
             return 1;
       fclose(fp);
   }
   return 0;
#endif
}


int main (int argc, char *argv[])
{
   FILE *fp, *fidx;
   char *buf, *ptr, *ptr1, *pw, article[256], board[15], buf1[256], 
	filename[STRLEN],passwd[20], title[100], username[20], signature[2],
	tmpsig[MAXSIGLINES][256], signfile[STRLEN]; 
   int  i, color, length, exchange = 1, fh, found = 0, noname = 0, 
	sign, valid_ln;
   struct boardheader  brdhdr;
   struct fileheader   header;
   struct userec       record;
   time_t	now;
   struct{
      char author[13];
      char board[80];
      char title[66];
      time_t date;
      int number;
   }      postlog;


   length = atoi(getenv("CONTENT_LENGTH"));
   ptr = buf = (char *)malloc(length + 1);
   if (buf == NULL)
   {
      printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
      printf("Out of memory!\n");
      exit(1);
   }
   buf[length] = '\0';
   fread(buf, sizeof(char), length, stdin);

   plustospace(buf);
   unescape_url(buf);
   read_form(buf, board, "board=", "&title="); 
   if(strstr(buf, "exchange=N") != NULL)
      exchange = 0;
   if (strstr(buf, "anonymous=Y") != NULL)
      noname = 1;
   read_form(buf, title, "title=", "&anonymous="); 
   read_form(buf, username, "username=", "&passwd="); 
   read_form(buf, passwd, "passwd=", "&signature="); 
   read_form(buf, signature, "signature=", "&text=");
   sign = atoi(signature);
   if((buf = strstr(buf, "text=")) == NULL)
   { 
      free(ptr);
      printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
      printf("input error!\n"); 
      exit(1); 
   } 
   else 
      buf += 5;

   if (title[0] == '\0')
   {
      free(ptr);
      printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
      printf("����û�б���,���ܷ���!\n");
      exit(1);
   }

   if (buf[0] == '\0')
   {
      free(ptr);
      printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
      printf("������,���ܷ���!\n");
      exit(1);
   }

   if (username[0] != '\0' && passwd[0] != '\0')
   {
      now = time(NULL);

      sprintf(filename, "%s/boards/%s/.DIR", BBSHOME, board);
      if( (fidx = fopen(filename, "r+" )) == NULL ) {
        if( (fidx = fopen(filename, "w+" )) == NULL ) {
            free(ptr);
            printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
            printf(":err: unable to post in %s board.\n", board);
printf("Filename is: %s\n", filename);
            exit(1);
        }
      }
      sprintf(filename, "%s/.PASSWDS", BBSHOME);
      if( (fh = open(filename, O_RDWR)) == -1 ) {
        free(ptr);
        printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
        printf( ":err: unable to open .PASSWDS file.\n" );
        exit( 0 );
      }
      while( read( fh, &record, sizeof(record) ) > 0 ) {
        if( strcasecmp( username, record.userid ) == 0 ) {
            strcpy( username, record.userid );
	    pw = crypt( passwd, record.passwd );
	    if( strcmp( pw, record.passwd ) != 0 ) {
                free(ptr);
                printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
		printf( "�û������������!\n");
		exit(0);
	    }
	    if (!junkboard(board))
	       record.numposts++;
	    record.lastlogin = now;
            
            if (!PERM(PERM_LOGINOK) && PERM(PERM_BASIC))
            {
#ifdef FB25
               if (strchr(record.termtype+16, '@'))
                  record.userlevel |= PERM_DEFAULT;
#else
               sprintf(filename, "%s/home/%c/%s/register", BBSHOME,
					toupper(username[0]), username);
               if (fp = fopen(filename, "r"))
               {
                  fgets(buf1, STRLEN, fp);
		  fclose(fp);
		  if (strstr(buf1, "usernum"))
		     record.userlevel |= PERM_DEFAULT;
               }
#endif
            }

            flock(fh, LOCK_EX);
            lseek(fh, -1 * sizeof(record), SEEK_CUR);
            write(fh, &record, sizeof(record) );
            flock(fh, LOCK_UN);
	    found = 1;
            break;
        }
        memset(&record, 0, sizeof(record));
      } 
      close(fh);
      if (!found)
      {
        free(ptr);
        printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
	printf( "�Ҳ����û��� %s!\n", username );
	exit( 0 );
      }
      
      found = 0;
      sprintf(filename, "%s/.BOARDS", BBSHOME);
      if((fh = open(filename, O_RDONLY, 0)) == -1)
      {
         free(ptr);
         printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
	 printf( ":err: unable to open .BOARDS file.\n" );
         exit( 0 );
      }
      while (read(fh, &brdhdr, sizeof(brdhdr)) == sizeof(brdhdr))
	if (strcasecmp(brdhdr.filename, board) == 0)
	{
	   found = 1;
	   break;
	}
      close(fh);
      if (!found)
      {
         free(ptr);
         printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
         printf( "�Ҳ��������� %s!\n", board);
         exit( 0 );
      }

      if (!PERM(PERM_SYSOP))
      {
         if (!PERM(PERM_POST) || !PERM(brdhdr.level) || PERM(PERM_DENYPOST))
         {
            free(ptr);
            printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
	    printf("��Ǹ,��û����%s�������������µ�Ȩ��!", board);
	    exit(0);
         }

	 sprintf(filename, "%s/boards/%s/deny_users", BBSHOME, board);
	 if (fp = fopen(filename, "r"))
	 {
	   while (fgets(buf1, STRLEN, fp)) 
	      if (strncasecmp(buf1, username, strlen(username)) == 0)
	      {
                free(ptr);
		printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
        	printf("��Ǹ,��û����%s�������������µ�Ȩ��!", board);
        	exit(0);
	      }
	   fclose(fp);
	 }
      }

      sprintf(filename, "M.%d.A", now);
      ptr1 = strrchr(filename, 'A' );
      while( 1 ) {
        sprintf( article, "%s/boards/%s/%s", BBSHOME, board, filename );
        fh = open( article, O_CREAT | O_EXCL | O_WRONLY, 0644 );
        if( fh != -1 )  break;
        if( *ptr1 < 'z' )  (*ptr1)++;
        else  ptr1++, *ptr1 = 'a', ptr1[1] = '\0';
      }

      color=(record.numlogins%7)+31;
      sprintf(buf1, "������: %s (%s), ����: %s\n��  ��: %s\n����վ: %s (%.24s) , %s\n\n", noname?"Anonymous":record.userid, 
		noname?"����������ʹ":record.username, 
		brdhdr.filename, title, BBSNAME, ctime(&now),
		exchange?"ת��":"վ���ż�");
      write(fh, buf1, strlen(buf1));
      write(fh, buf, strlen(buf));
      write(fh, "\n\n--\n", 5);

      if (sign)
      {
         sprintf(signfile, "%s/home/%c/%s/signatures", BBSHOME,
			toupper(record.userid[0]), record.userid);
         if (fp = fopen(signfile, "r"))
         {
            for (i=1; i<=(sign - 1) * MAXSIGLINES; i++)
               if (!fgets(buf1, sizeof(buf1), fp))
                  break;

            for (i=1; i<= MAXSIGLINES; i++)
            {
               if (fgets(buf1, sizeof(buf1), fp))
               {
                  if (buf1[0] != '\n')
                     valid_ln = i;
                  strcpy(tmpsig[i-1], buf1);
               }
               else
                  break;
            }
            fclose(fp);
            for( i = 1; i <= valid_ln; i++)
               write(fh, tmpsig[i - 1], strlen(tmpsig[i - 1]));
         }
      }

#ifdef HIDE_IP
      sprintf(buf1,"%c[1;%2dm�� ��Դ:��%s %s. [FROM: WWW] %c[m\n",
                        27, color, BBSNAME, BBSHOST, 27);
#else
      sprintf(buf1,"%c[1;%2dm�� ��Դ:��%sWWW %s. [FROM: %.20s] %c[m\n",
			27, color, BBSNAME, BBSHOST, 
			noname?"������ʹ�ļ�":getenv("REMOTE_ADDR"), 27); 
#endif
      write(fh, buf1, strlen(buf1));
      close(fh);

   }
   else
   {
      free(ptr);
      printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
      printf("��������ȷ���û���������!\n");
      exit(1);
   }
   bzero( (void *)&header, sizeof( header ) );
   strcpy( header.filename, filename);
   strncpy( header.owner, noname?"Anonymous":record.userid, IDLEN );
   strncpy( header.title, title, STRLEN );
   flock(fileno(fidx), LOCK_EX);
   fseek(fidx, 0, SEEK_END);
   fwrite(&header, sizeof(header), 1, fidx);
   flock(fileno(fidx), LOCK_UN);
   fclose(fidx);

   free(ptr);
   
   if (exchange)
   {
      sprintf(filename, "%s/innd/out.bntp", BBSHOME);
      if (fp = fopen(filename, "a"))
      {
         fprintf(fp, "%s\t%s\t%s\t%s\t%s\n", board, header.filename,
		header.owner, record.username, header.title);
         fclose(fp);
      }
   }
   
   if (!junkboard(board) && !brdhdr.level)
   {
      strcpy(postlog.author, record.userid);
      strcpy(postlog.board, board);
      ptr = header.title;
      if (!strncmp(ptr, "Re: ", 4))
         ptr += 4;
      strncpy(postlog.title, ptr, 65);
      postlog.date = time(0);
      postlog.number = 1;
      sprintf(filename, "%s/.post", BBSHOME);
      if (fh = open(filename, O_WRONLY|O_CREAT|O_APPEND))
      {
         write(fh, &postlog, sizeof(postlog));
         close(fh);
      }
   }

   printf("Location: http://%s%s/bbsdoc?%s\n\n", BBSHOST, BBSCGI, board);
}
