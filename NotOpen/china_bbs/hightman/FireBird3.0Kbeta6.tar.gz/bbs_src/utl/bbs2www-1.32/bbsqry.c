/*
    BBS2WWW -- WWW Interface for Firebird Bulletin Board System
    Copyright (C) 1996-1999 Computer Application Studio.
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/uio.h>

#include "bbs2www.h"

int
countexp(udata)
struct userec *udata;
{
   int exp;

   if(!strcmp(udata->userid,"guest"))
        return -9999;
   exp = udata->numposts +
        udata->numlogins / 5 +
        ( time(0) - udata->firstlogin ) / 86400 +
        udata->stay / 3600;
   return exp > 0 ? exp : 0;
}

int
countperf(udata)
struct userec *udata;
{
   int perf;
   int reg_days;

   if(!strcmp(udata->userid,"guest"))
        return -9999;
   reg_days = ( time(0) - udata->firstlogin ) / 86400 + 1;

   if ( reg_days <= 0 )
        return 0;

   perf = ( (float) udata->numposts / (float) udata->numlogins +
         (float) udata->numlogins / (float) reg_days ) * 10;
   return perf > 0 ? perf : 0;
}

int
compute_user_value( urec )
struct userec *urec;
{
    int         value;

    /* if (urec) has XEMPT permission, don't kick it */
    if((urec->userlevel & PERM_XEMPT)||strcmp(urec->userid,"guest")==0)
        return 999;
    value = (time(0) - urec->lastlogin) / 60;    /* min */
        /* new user should register in 30 mins */
    if( strcmp( urec->userid, "new" ) == 0 ) {
        return (30 - value) * 60;
    }
    if( urec->numlogins <= 3 )
        return (15 * 1440 - value)/1440;
    if( !(urec->userlevel & PERM_LOGINOK) )
        return (30 * 1440 - value)/1440;
    if( urec->stay > 1000000 )
        return (365 * 1440 - value)/1440;
    return (120 * 1440 - value)/1440;
}

char *
cexp(exp)
int exp;
{
        int expbase=0;

        if(exp==-9999)
                return "û�ȼ�";
        if(exp<=100+expbase)
                return "������·";
        if(exp>100+expbase&&exp<=450+expbase)
                return "һ��վ��";
        if(exp>450+expbase&&exp<=850+expbase)
                return "�м�վ��";
        if(exp>850+expbase&&exp<=1500+expbase)
                return "�߼�վ��";
        if(exp>1500+expbase&&exp<=2500+expbase)
                return "��վ��";
        if(exp>2500+expbase&&exp<=3000+expbase)
                return "���ϼ�";
        if(exp>3000+expbase&&exp<=5000+expbase)
                return "��վԪ��";
        if(exp>5000+expbase)
                return "��������";

}

char *
cperf(perf)
int perf;
{

        if(perf==-9999)
                return "û�ȼ�";
        if(perf<=5)
                return "�Ͽ����";
        if(perf>5&&perf<=12)
                return "Ŭ����";
        if(perf>12&&perf<=35)
                return "������";
        if(perf>35&&perf<=50)
                return "�ܺ�";
        if(perf>50&&perf<=90)
                return "�ŵ���";
        if(perf>90&&perf<=140)
                return "̫������";
        if(perf>140&&perf<=200)
                return "��վ֧��";
        if(perf>200)
                return "�񡫡�";

}

char *
ModeType(mode)
int     mode;
{
    switch(mode) {
        case IDLE:      return "" ;
        case NEW:       return "��վ��ע��" ;
        case LOGIN:     return "���뱾վ";
#ifdef FB25
	case CSIE_ANNOUNCE:	return "��ȡ����";
	case CSIE_TIN:		return "����TIN";
	case CSIE_GOPHER:	return "����Gopher";
#else
        case DIGEST:    return "���������";
#endif
        case MMENU:     return "��ѡ��";
        case ADMIN:     return "������ѡ��";
        case SELECT:    return "ѡ��������";
        case READBRD:   return "��������";
        case READNEW:   return "��������";
        case READING:   return "Ʒζ����";
        case POSTING:   return "��������" ;
        case MAIL:      return "�����ż�" ;
        case SMAIL:     return "�����Ÿ�";
        case RMAIL:     return "�����ż�";
        case TMENU:     return "����ѡ��";
        case LUSERS:    return "�����ķ�";
        case FRIEND:    return "Ѱ�Һ���";
        case MONITOR:   return "̽������";
        case QUERY:     return "��ѯ����";
        case TALK:      return "����" ;
        case PAGE:      return "����" ;
        case CHAT1:     return "Chat1";
        case CHAT2:     return "Chat2";
        case CHAT3:     return "Chat3";
        case CHAT4:     return "Chat4";
        case IRCCHAT:   return "��̸IRC";
        case LAUSERS:   return "̽������";
        case XMENU:     return "ϵͳ��Ѷ";
        case VOTING:    return "ͶƱ";
        case BBSNET:    return "BBSNET";
        case EDITWELC:  return "�༭Welc";
        case EDITUFILE: return "�༭���˵�";
        case EDITSFILE: return "����ϵͳ��";
        case ZAP:       return "����������";
#ifndef FB25
        case GAME:      return "��������";
        case SYSINFO:   return "���ϵͳ";
        case ARCHIE:    return "ARCHIE";
        case DICT:      return "�����ֵ�";
#endif
        case LOCKSCREEN:return "өĻ����";
        case NOTEPAD:   return "���԰�";
        case GMENU:     return "������";
        case MSG:       return "��ѶϢ";
        case USERDEF:   return "�Զ�����";
        case EDIT:      return "�޸�����";
        case OFFLINE:   return "��ɱ��..";
        case EDITANN:   return "���޾���";
        case WWW:       return "���� WWW";
#ifndef FB25
        case HYTELNET:  return "Hytelnet";
#endif
        case CCUGOPHER: return "��վ����";
        case LOOKMSGS:  return "�쿴ѶϢ";
        case WFRIEND:   return "Ѱ������";
#ifdef FB30
        case WNOTEPAD:  return "���߻���";
        case BBSPAGER:  return "��·����";
#endif
        default: return "ȥ������!?" ;
    }
}

int
check_query_mail(qry_mail_dir)
char qry_mail_dir[STRLEN];
{
    struct fileheader fh ;
    struct stat st ;
    int fd ;
    register int offset ;
    register long numfiles ;
    unsigned char ch ;

    offset = (int)((char *)&(fh.accessed[0]) - (char *)&(fh)) ;
    if((fd = open(qry_mail_dir,O_RDONLY)) < 0)
      return 0 ;
    fstat(fd,&st) ;
    numfiles = st.st_size ;
    numfiles = numfiles/sizeof(fh) ;
    if(numfiles <= 0) {
      close(fd) ;
      return 0 ;
    }
    lseek(fd,(off_t)(st.st_size-(sizeof(fh)-offset)),SEEK_SET) ;
    read(fd,&ch,1) ;
    if(!(ch & FILE_READ)) {
        close(fd) ;
        return YEA ;
    }
    close(fd) ;
    return NA ;
}

int main (int argc, char *argv[])
{
   FILE *fp;
   char ArgOfQuery[STRLEN], filename[STRLEN], genbuf[STRLEN], *newline,
        username[IDLEN], buf[256], tmp[80], *ptr;
   int  i, index, exp, num, perf, fh, found = 0, n, len, quote = 1,
        infont = 0, inblink =0, inbold =0, inunderline =0, shmkey, shmid;
   register int offset;
   struct user_info *uin;
   struct userec record;
   struct UTMPFILE  *utmpshm;

   strncpy(ArgOfQuery, getenv("QUERY_STRING"), STRLEN);

   printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
   printf("<html>\n");
#ifdef STYLESHEET
   printf("<link rel=stylesheet type=text/css href=\"%s\">\n", STYLESHEET);
#endif
   printf("<title>%s��ѯ����</title>\n", BBSID); 
   printf("<body>\n");
   printf("<center>\n");

   printf("<table class=title width=90%%><tr>");
   printf("<th class=title align=center>%s -- ��ѯ����</th>\n", 
	   BBSNAME);
   printf("</table>\n");

   printf("<hr>\n");

   if (ArgOfQuery[0])
   {
      if (strstr(ArgOfQuery, "id="))
         strncpy(username, ArgOfQuery + 3, IDLEN);
      else
         strncpy(username, ArgOfQuery, IDLEN);
         
      sprintf(filename, "%s/.PASSWDS", BBSHOME);
      if( (fh = open(filename, O_RDONLY)) == -1 ) {
         printf("Content-type: text/html; charset=%s\n\n\n", CHARSET);
         printf( ":err: unable to open .PASSWDS file.\n" );
         exit( 0 );
      }
      while (read(fh, &record, sizeof(record)) > 0)
         if( strcasecmp( username, record.userid ) == 0 ) {
            found = 1;
            break;
         }
      close(fh);
   }

   if (!found)
   {

      if (ArgOfQuery[0])
         printf("<p>�û��� <B>%s</B> ������!", username);
      else
         printf("<p>�������û���:\n");
      
      printf("<form action=\"%s/bbsqry\">", BBSCGI);
      printf("<input type=submit value=\"��ѯ�û�\">");
      printf(" <input type=text name=id size=%d maxlength=%d>", IDLEN, IDLEN); 
      printf("</form></p>");
   }
   else
   {
      printf("<table class=doc>\n");
      printf("<tr><td class=doc>");

      printf("<font class=col37>%s</font> (<font class=col33>%s</font>) ����վ <font class=col32>%d</font> �Σ������� <font class=col32>%d</font> ƪ����\n", 
	record.userid, record.username, record.numlogins, record.numposts);
      strcpy(genbuf, ctime(&(record.lastlogin)));
      if( (newline = strchr(genbuf, '\n')) != NULL )
         *newline = '\0';
      printf("�ϴ��� [<font class=col32>%s</font>] �� [<font class=col32>%s</font>] ����վһ�Ρ�\n",
	genbuf, (record.lasthost[0] == '\0' ? "(����)" : record.lasthost));

      exp = countexp(&record);
      perf = countperf(&record);
      sprintf(filename, "%s/mail/%c/%s/.DIR", BBSHOME,
                        toupper(record.userid[0]), record.userid);
      printf("���䣺[<blink><font class=col32>%2s</font></blink>]������ֵ��[<font class=col32>%d</font>](<font class=col33>%s</font>) ����ֵ��[<font class=col32>%d</font>](<font class=col33>%s</font>) ��������[<font class=col32>%d</font>]��\n",
	(check_query_mail(filename)==1)? "��":"  ", exp, cexp(exp),
	perf, cperf(perf), compute_user_value(&record));

      num = 0;

      shmid = shmget(UTMP_SHMKEY, sizeof(struct UTMPFILE), 0 );
      if (shmid >= 0)
      {
         utmpshm = (struct UTMPFILE *) shmat( shmid, NULL, 0 );
         if (utmpshm != (struct UTMPFILE *) -1)
         {
            num = 0;
            for( i = 0; i < USHM_SIZE; i++ )
            {
               uin = &(utmpshm->uinfo[ i ]);

               if (strcmp(uin->userid, record.userid) == 0)
               {
                  if(!uin->active || !uin->pid || uin->invisible)
                     continue;
                  num++;
                  if (num == 1)
                     printf("<tr><td class=doc>Ŀǰ��վ�ϣ�״̬���£�\n");
                  printf("<b>%-14s</b> ", ModeType(uin->mode));
                  if((num)%5==0)
                     printf("<br>\n");
               }
            }

         }
      }

      sprintf(filename, "%s/home/%c/%s/plans", BBSHOME,
                        toupper(record.userid[0]), record.userid);
      if ((fp = fopen(filename, "r")) == NULL)
      {
         printf("<tr><td class=doc><font class=col36>û�и���˵����</font>\n");
      }
      else
      {
         printf("<tr><td class=doc><pre><font class=col36>����˵�������£�</font>\n");
         while( fgets(buf, 512, fp ) != NULL)
         {
            index = 0;
            while (buf[index] != '\0')
            {
               if( buf[index] != 27 || buf[index+1] != '[')
                  putchar(buf[index++]);
               else
               {
                  index += 2;
                  n = 0;
                  while(buf[index+n] != 'm' && buf[index+n] != '\0')
                     n++;

                 if (buf[index+n] == 'm')
                 {
                    len = (n > 79) ? 79 : (n + 1);
                    strncpy(tmp, buf+ index, len);
                    tmp[len] = '\0';
                    index += n + 1;
                    if (tmp[0] == 'm')
                       strcpy(tmp, "0;");
                    else
                       tmp[len - 1] = ';';
                    ptr = strtok(tmp, ";");
                    while (ptr)
                    {
                       n = atoi(ptr);
                       switch (n) {
                          case 0 : if (infont)    /* ״̬��ԭ */
                                      printf("</font>");
                                   if (inblink)
                                      printf("</blink>");
                                   if (inbold)
                                      printf("</b>");
                                   if (inunderline)
                                      printf("</u>");
                                   infont = inblink = inbold = inunderline = 0;
                                   break;
                          case 1 : if (inbold == 0)       /* ������ */
                                      printf("<b>");
                                   inbold = 1;
                                   break;
                          case 4 : if (inunderline == 0)  /* �»��� */
                                      printf("<u>");
                                   inunderline = 1;
                                   break;
                          case 5 : if (inblink == 0)      /* ��˸ */
                                      printf("<blink>");
                                   inblink = 1;
                                   break;
                          case 30: if (infont == 1)       /* ��ɫ */
                                      printf("</font>");
                                   printf("<font class=col30>");
                                   infont = 1;
                                   break;
                          case 31: if (infont == 1)       /* ��ɫ */
                                      printf("</font>");
                                   printf("<font class=col31>");
                                   infont = 1;
                                   break;
                          case 32: if (infont == 1)       /* ��ɫ */
                                      printf("</font>");
                                   printf("<font class=col32>");
                                   infont = 1;
                                   break;
                          case 33: if (infont == 1)       /* ��ɫ */
                                      printf("</font>");
                                   printf("<font class=col33>");
                                   infont = 1;
                                   break;
                          case 34: if (infont == 1)       /* ��ɫ */
                                      printf("</font>");
                                   printf("<font class=col34>");
                                   infont = 1;
                                   break;
                          case 35: if (infont == 1)       /* �ۺ�ɫ */
                                      printf("</font>");
                                   printf("<font class=col35>");
                                   infont = 1;
                                   break;
                          case 36: if (infont == 1)       /* ǳ��ɫ */
                                      printf("</font>");
                                   printf("<font class=col36>");
                                   infont = 1;
                                   break;
                          case 37: if (infont == 1)       /* ��ɫ */
                                      printf("</font>");
                                   printf("<font class=col37>");
                                   infont = 1;
                                   break;
                       }
                       ptr = strtok(NULL, ";");
                    }

                 }
                 else
                 {
                    index += n;
                 }

              }
           }
        }
        if (infont)
            printf("</font>");
        if (inblink)
           printf("</blink>");
        if (inbold)
           printf("</b>");
        if (inunderline)
           printf("</u>");

        fclose(fp);
        printf("</pre>");

      }

      printf("</table>\n");
   }

   printf("<hr>");

   printf("<table class=foot><th class=foot><a href=\"%s\">������ҳ</a>", 
		BBSURL);
   printf("<th class=foot><a href=\"%s/bbssec\">����������</a>", BBSCGI);
   printf("<th class=foot><a href=\"%s/bbsall\">ȫ��������</a>", BBSCGI);
   printf("<th class=foot><a href=\"%s/bbs0an\">����������</a>", BBSCGI);
   printf("<th class=foot><a href=\"%s\">%s</a></table>", SCHOOLURL, 
		SCHOOLNAME);

   printf("</center>\n");
   printf("</body>\n");
   printf("</html>");
}
