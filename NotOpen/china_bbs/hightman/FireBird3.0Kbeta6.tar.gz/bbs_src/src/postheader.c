/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu
    Firebird Bulletin Board System
    Copyright (C) 1996, Hsien-Tsung Chang, Smallpig.bbs@bbs.cs.ccu.edu.tw
                        Peng Piaw Foong, ppfoong@csie.ncu.edu.tw
    
    Copyright (C) 1999, KCN,Zhou Lin, kcn@cic.tsinghua.edu.cn

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/

#include "bbs.h"

extern int numofsig;
struct shortfile *getbcache();

int
post_header(header)
struct postheader *header;
{
  int anonyboard=0;
  char r_prompt[20],mybuf[256],ans[5];
  char titlebuf[STRLEN];
  struct shortfile *bp;

  if(currentuser.signature>numofsig||currentuser.signature<0)
        currentuser.signature=1;
  if(header->reply_mode)
  {
        strcpy(titlebuf,header->title);
        header->include_mode='Y';
  }
  else
        titlebuf[0]='\0';
  bp = getbcache(currboard);
  if(header->postboard)
        anonyboard=bp->flag&ANONY_FLAG;
  header->chk_anony=(anonyboard)?1:0;
  while(1)
  {
    if(header->reply_mode)
            sprintf(r_prompt,"����ģʽ [[1m%c[m]",header->include_mode);
    move( t_lines-4, 0 );
    clrtobot();
    prints("[m%s [1m%s[m      %s\n",
          (header->postboard)?"����������":"�����ˣ�",header->ds,
          (anonyboard)?(header->chk_anony==1?"[1mҪ[mʹ������":"[1m��[mʹ������"):"");
    prints("ʹ�ñ���: [1m%-50s[m\n", (header->title[0]=='\0') ? "[�����趨����]":header->title);
    prints("ʹ�õ� [1m%d[m ��ǩ����     %s",currentuser.signature
           ,(header->reply_mode)? r_prompt: "");
    if(titlebuf[0]=='\0'){
           move(t_lines-1,0);
           if(header->postboard==YEA||strcmp(header->title,"û����"))
                strcpy(titlebuf,header->title);
           getdata(t_lines-1,0,"����: ",titlebuf,50,DOECHO,NULL,NA);
           if(titlebuf[0]=='\0')
           {
                if(header->title[0]!='\0')
                {
                        titlebuf[0]=' ';
                        continue;
                }
                else
                        return NA;
           }
           strcpy(header->title,titlebuf);
           continue;
    }
    move(t_lines-1,0);
sprintf(mybuf,
"�밴 [1;32m0[m~[1;32m%d V[m ѡ/��ǩ����%s��[1;32mT[m �ı���%s��[1;32mEnter[m ���������趨: ",
    numofsig,(header->reply_mode) ? "��[1;32mY[m/[1;32mN[m/[1;32mR[m/[1;32mA[m ������ģʽ" : "",(anonyboard)?"��[1;32mS[m ����":"");
    getdata(t_lines-1,0,mybuf,ans,3,DOECHO,NULL,YEA);
    ans[0] = toupper(ans[0]);
    if((ans[0]-'0')>=0&&ans[0]-'0'<=9)
    {
        if(atoi(ans)<=numofsig)
           currentuser.signature=atoi(ans);
    }else if(header->reply_mode &&
             (ans[0]=='Y'||ans[0]=='N'||ans[0]=='A'||ans[0]=='R'))
    {
        header->include_mode=ans[0];
    }else if(ans[0]=='T')
    {
        titlebuf[0]='\0';
    }else if(ans[0]=='S' && anonyboard)
    {
        header->chk_anony=(header->chk_anony==1)?0:1;
    }else if(ans[0]=='V')
    {
        setuserfile(mybuf,"signatures");
        if (askyn("Ԥ����ʾǰ����ǩ����, Ҫ��ʾȫ����",NA,YEA)==YEA)
           ansimore(mybuf);
        else
        {
        clear();
        ansimore2(mybuf,NA,0,18);
        }
    }
    else
    {
        if( header->title[0] == '\0' ) 
           return NA;
        else
           return YEA;
    }
  }
}
