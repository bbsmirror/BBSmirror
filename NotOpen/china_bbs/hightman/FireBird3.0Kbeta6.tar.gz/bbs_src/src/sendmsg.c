/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu
    Firebird Bulletin Board System
    Copyright (C) 1996, Hsien-Tsung Chang, Smallpig.bbs@bbs.cs.ccu.edu.tw
                        Peng Piaw Foong, ppfoong@csie.ncu.edu.tw

    Copyright (C) 1999	KCN,Zhou lin,kcn@cic.tsinghua.edu.cn
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/

#include "bbs.h"

extern int  RMSG;
extern int msg_num;
char buf2[STRLEN];
struct user_info *t_search();
extern struct UTMPFILE *utmpshm;

int
get_msg(uid,msg,line)
char *msg,*uid;
int line;
{
        char genbuf[3];

        move(line,0);
        clrtoeol();
        prints("�����Ÿ���%s",uid);
        memset(msg,0,sizeof(msg));
        while(1)
        {
                getdata( line+1, 0, "���� : ", msg, 55, DOECHO, NULL,NA);
                if(msg[0]=='\0')
                        return NA;
                getdata( line+2, 0, "ȷ��Ҫ�ͳ���(Y)�ǵ� (N)��Ҫ (E)�ٱ༭? [Y]: ",
                    genbuf, 2, DOECHO, NULL ,1);
                if(genbuf[0]=='e'||genbuf[0]=='E')
                        continue;
                if(genbuf[0]=='n'||genbuf[0]=='N')
                        return NA;
                else
                        return YEA;
        }
}

char
msgchar(uin)
struct user_info *uin;
{
    if(isreject(uin)) return '*';
    if ((uin->pager&ALLMSG_PAGER)) return ' ';
    if (hisfriend(uin))
    {
        if((uin->pager&FRIENDMSG_PAGER))
                return 'O';
        else
                return '#';
    }
    return '*';
}

int
canmsg(uin)
struct user_info *uin;
{
    if(isreject(uin)) return NA;
    if ((uin->pager&ALLMSG_PAGER) || HAS_PERM(PERM_SYSOP|PERM_FORCEPAGE))
        return YEA;
    if ((uin->pager&FRIENDMSG_PAGER)&&hisfriend(uin))
        return YEA;
    return NA;
}

s_msg()
{
      do_sendmsg(NULL,NULL,0,0);
}

int
show_allmsgs()
{
        char fname[STRLEN];

        setuserfile(fname,"msgfile");
        clear();
        modify_user_mode( LOOKMSGS);
        if(dashf(fname))
        {
                ansimore(fname,YEA);
                clear();
        }
        else
        {
                move(5,30);
                prints("û���κε�ѶϢ���ڣ���");
                pressanykey();
                clear();
        }
}

int
do_sendmsg(uentp,msgstr,mode,userpid)
struct user_info *uentp;
char msgstr[256];
int mode;
int userpid;
{
    char uident[STRLEN],ret_str[20];
    FILE *fp;
    time_t now;
    struct user_info *uin ;
    char buf[80],msgbuf[256] ,*timestr,mymsgbuf[256];
    mymsgbuf[0]=0;
    
    if(mode==0)
    {
        move(2,0) ; clrtobot();
        if(uinfo.invisible && !HAS_PERM(PERM_SYSOP))
        {
        move(2,0);
        prints("��Ǹ, �˹���������״̬�²���ִ��...\n");
        pressreturn();
        return 0;
        }
        modify_user_mode( MSG );
    }
  if(uentp==NULL)
  {
    prints("<����ʹ���ߴ���>\n") ;
    move(1,0) ;
    clrtoeol() ;
    prints("��ѶϢ��: ") ;
    creat_list() ;
    namecomplete(NULL,uident) ;
    if(uident[0] == '\0') 
    {
        clear() ;
        return 0 ;
    }
/*    if(searchuser(uident)==0 || tuid == usernum) 
    {
       if(uentp==NULL)
       {
        move(2,0) ;
        prints("�����ʹ���� ID\n") ;
        pressreturn() ;
        move(2,0) ;
        clrtoeol() ;
       }
        return -1 ;
    }*/
    uin=t_search(uident,NA);
    if(uin==NULL)
    {  
        move(2,0) ;
        prints("�Է�Ŀǰ��������...\n");
        pressreturn() ;
        move(2,0) ;
        clrtoeol() ;
        return -1 ;
    } 
    if(uin->mode == IRCCHAT || uin->mode == BBSNET || uin->mode == WWW
       || uin->mode == HYTELNET || uin->mode == GAME || uin->mode == PAGE
       || !canmsg(uin)) {
       move(2,0) ;
       prints("Ŀǰ�޷�����ѶϢ���Է�.\n") ;
       pressreturn() ;
       move(2,0) ;
       clrtoeol() ;
       return -1 ;
    }
  }else
  {
  if(!strcmp(uentp->userid,currentuser.userid))
      return 0;    
  uin=uentp;
  if(uin->mode == IRCCHAT || uin->mode == BBSNET || uin->mode == WWW
      || uin->mode == HYTELNET || uin->mode == GAME || uin->mode == PAGE 
      || !canmsg(uin)) return 0;
  strcpy(uident,uin->userid);
  }
    if(msgstr==NULL)
    {
        if (!get_msg(uident,buf,1) ){
            move(1,0); clrtoeol();
            move(2,0); clrtoeol();
            return 0;
        }
     }

        now=time(0);
        timestr=ctime(&now)+11;
        *(timestr+8)='\0';
        strcpy(ret_str,"^Z��");
        if(msgstr==NULL||mode==2)
        {
           sprintf(msgbuf,"[0;1;44;36m%-12.12s[33m([36m%-5.5s[33m):[37m%-54.54s[31m(%s)[m[%05dm\n",
                currentuser.userid, timestr, (msgstr==NULL)?buf:msgstr,ret_str,uinfo.pid);
           sprintf(mymsgbuf,"[0;1;44;39m=>[33m%-12.12s[33m([36m%-5.5s[33m):[37m%-54.54s[31m��Ѷ[m[m\n",
        	uident, timestr, (msgstr==NULL)?buf:msgstr);
        }else
        {
           if(mode==0)
                sprintf(msgbuf,"[0;1;5;44;33mվ�� ��[36m %8.8s [33m�㲥��[m[1;37;44m%-57.57s[m[%05dm\n",
                timestr,msgstr,uinfo.pid);
           else if(mode==1)
           {
                sprintf(msgbuf,"[0;1;44;36m%-12.12s[37m([36m%-5.5s[37m) ������[37m%-48.48s[31m(%s)[m[%05dm\n",
                currentuser.userid, timestr, msgstr,ret_str,uinfo.pid);
           }
           else if(mode==3)
           {
                sprintf(msgbuf,"[0;1;45;36m%-12.12s[33m([36m%-5.5s[33m):[37m%-54.54s[31m(%s)[m[%05dm\n",
                currentuser.userid, timestr, (msgstr==NULL)?buf:msgstr,ret_str,uinfo.pid);
        	sprintf(mymsgbuf,"[0;1;44;39m=>[33m%-12.12s[33m([36m%-5.5s[33m):[37m%-54.54s[31m�㲥[m[m\n",
	       		uident, timestr, (msgstr==NULL)?buf:msgstr);
           }
        }
        if(userpid)
        {
                if(userpid!=uin->pid)
                {
                        saveline(0, 0); /* Save line */
                        move(0,0);
                        clrtoeol();
                        prints("[1m�Է��Ѿ�����...[m\n");
                        sleep(1);
                        saveline(0, 1); /* restore line */
                        return -1;
                }
        }
        if(!uin->active||kill(uin->pid,0)==-1)
        {
              if(msgstr==NULL)
              {
                    prints("\n�Է��Ѿ�����...\n") ; pressreturn();
                    clear();
              }  
              return -1;
        }
        sethomefile(buf,uident,"msgfile");
        if((fp=fopen(buf,"a"))==NULL)
                return -1;
        fputs(msgbuf,fp);
        fclose(fp);

	if (mymsgbuf[0])
	{
        	sethomefile(buf,currentuser.userid,"msgfile");
        	if((fp=fopen(buf,"a"))==NULL)
                	return -1;
	        fputs(mymsgbuf,fp);
        	fclose(fp);
        }
        
        kill(uin->pid,SIGTTOU);
        kill(uin->pid,SIGUSR2);
        if(msgstr==NULL)
        {
            prints("\n���ͳ�ѶϢ...\n") ; pressreturn();
            clear() ;
        }
        return 1 ;
}

int
dowall(uin)
struct user_info *uin;
{
        if (!uin->active || !uin->pid) return -1;
        move(1,0);
        clrtoeol();
        prints("[1;32m���� %s �㲥.... Ctrl-D ֹͣ�Դ�λ User �㲥��[m",uin->userid); 
        refresh();
        do_sendmsg(uin,buf2,0,uin->pid);
}

int
myfriend_wall(uin)
struct user_info *uin;
{
        if ((uin->pid-uinfo.pid==0) || !uin->active || !uin->pid || isreject(uin))
           return -1;
        if(myfriend(uin->uid))
        {
           move(1,0);
           clrtoeol();
           prints("[1;32m������ѶϢ�� %s...  [m",uin->userid);
           refresh();
           do_sendmsg(uin,buf2,3,uin->pid);
        }    
}

int
hisfriend_wall(uin)
struct user_info *uin;
{
        if ((uin->pid-uinfo.pid==0) || !uin->active || !uin->pid || isreject(uin))
           return -1;
        if(hisfriend(uin))
        {
           move(1,0);
           clrtoeol();
           prints("[1;32m������ѶϢ�� %s...  [m",uin->userid);
           refresh();
           do_sendmsg(uin,buf2,3,uin->pid);
        }    
}

int
wall()
{
    if(!HAS_PERM(PERM_SYSOP))
         return 0;
    modify_user_mode( MSG );
    move(2,0) ; clrtobot();
    if (!get_msg("����ʹ����",buf2,1) ){
         return 0;
    }    
    if( apply_ulist( dowall ) == 0 ) {
        move(2,0);
        prints( "���Ͽ���һ��\n" );
        pressanykey();
    }
    prints("\n�Ѿ��㲥���...\n");
    pressanykey();
    return 1;
}

int
friend_wall()
{
    char buf[3];

    if(uinfo.invisible)
    {
        move(2,0);
        prints("��Ǹ, �˹���������״̬�²���ִ��...\n");
        pressreturn();
        return 0;
    }
    modify_user_mode( MSG );
    move(2,0); clrtobot();
    getdata(4,0,"��ѶϢ�� [[1;32m1[m] �ҵĺ����ѣ�[[32;1m2[m] ����Ϊ����: ",
        buf, 2, DOECHO, NULL,YEA);
    switch(buf[0])
    {
        case '1':
            if (!get_msg("�ҵĺ�����",buf2,1))
                return 0;
            if( apply_ulist( myfriend_wall ) == -1 ) {
                move(2,0);
                prints( "���Ͽ���һ��\n" );
                pressanykey();
            }
            break;
        case '2':
            if (!get_msg("����Ϊ����",buf2,1))
                return 0;
            if( apply_ulist( hisfriend_wall ) == -1 ) {
               move(2,0);
               prints( "���Ͽ���һ��\n" );
               pressanykey();
            }
            break;
        default:
            return 0;
    }
    move(6,0);
    prints("ѶϢ�������...");
    pressanykey();
    return 1;
}

int
get_num_msg(fname,total)
char *fname;
int *total;
{
    int fd ;
    int id = 0;
    char buf[256];
    if((fd = open(fname,O_RDONLY,0)) == -1)
        return 0 ;
    while(read(fd,buf,129) == 129)
    {
    	   if (buf[10]!='9') id++;
    	   (*total)++;
    }
    close(fd) ;
    return id;
}

void
r_msg2()
    {
    char buf[256];
    char msg[256];
    char fname[STRLEN];
    int line,tmpansi;
    int y,x,ch,i,j;
    int  MsgNum;
    int totalmsg;

    getyx(&y,&x);
    if(uinfo.mode==TALK)
        line=t_lines/2-1;
    else
        line=0;
    setuserfile(fname,"msgfile");
    totalmsg=0;
    i = get_num_msg(fname,&totalmsg);
    if (i == 0)
       return;
    tmpansi=showansi;
    showansi=1;
    oflush();
    if (RMSG == NA)
    {
       saveline(line,  4);
       saveline(line+1,6);
    }
    MsgNum=0;
    RMSG=YEA;
    while(1)
        {
        int countmsg;
        MsgNum=(MsgNum%i);
	countmsg=0;
	for (j=totalmsg;j>0;j--)
	  if (get_record(fname,msg,129,j)==0)
	  	if (msg[10]!='9')
	  	{
	  		 countmsg++;
	  		 if (countmsg==MsgNum+1) break;
	  	}
	msg[129]=0;	  	
        
        move(line,0); clrtoeol(); prints("%s",msg); refresh();
        {
          struct user_info *uin ;
          char msgbuf[STRLEN];
          int good_id,send_pid;
          char *ptr,usid[STRLEN];

          ptr=strrchr(msg,'[');
          send_pid=atoi(ptr+1);
          ptr=strtok(msg+12," [");
          if(ptr==NULL)
              good_id=NA;
          else if (!strcmp(ptr,currentuser.userid))
              good_id=NA;
          else
              {
              strcpy(usid,ptr);
              uin=t_search(usid,send_pid);
              if(uin==NULL)
                  good_id=NA;
              else
                  good_id=YEA;
              }
          if(good_id==YEA&&canmsg(uin))
              {
              int userpid;

              userpid=uin->pid;
              move(line+1, 0);
              clrtoeol();
              sprintf(msgbuf,"��ѶϢ�� %s: ",usid);
              getdata(line+1,0,msgbuf,buf,55,DOECHO,NULL,YEA);
              if(buf[0]==Ctrl('Z'))
                  {
                  MsgNum++;
                  continue;
                  }
              else if(buf[0]==Ctrl('A'))
               	  {
              	  MsgNum--;
              	  if(MsgNum<0)
              		MsgNum=i-1;
              	  continue;
                  }
              if(buf[0]!='\0')
                  {
                  if(do_sendmsg(uin,buf,2,userpid)==1)
                     sprintf(msgbuf,"[1;32m�����ͳ�ѶϢ�� %s ��![m",usid);
                  else
                     sprintf(msgbuf,"[1;32mѶϢ�޷��ͳ�.[m");
                  }
              else
                  sprintf(msgbuf,"[1;33m��ѶϢ, ���Բ��ͳ�.[m");
              move(line+1,0);
              clrtoeol();
              refresh();
              prints("%s",msgbuf);
              refresh();
              if(!strstr(msgbuf,"����"))
                 sleep(1);
              }
          else
              {
              sprintf(msgbuf,"[1;32m�Ҳ�����ѶϢ�� %s! �밴��:[^Z ��] ����:[^A ��] ���������뿪.[m",usid);
              move(line+1,0);
              clrtoeol();
              refresh();
              prints("%s",msgbuf);
              refresh();
              if((ch=igetkey())==Ctrl('Z')||ch==KEY_UP)
                {
                MsgNum++;
                continue;
                }
              if(ch==Ctrl('A')||ch==KEY_DOWN)
              	{
              	MsgNum--;
              	if(MsgNum<0)
              		MsgNum=i-1;
              	continue;
              	}  
              }
          }
          break;
        }
    saveline(line,  5);
    saveline(line+1,7);
    showansi=tmpansi;
    move(y,x);
    refresh();
    RMSG=NA;
    return ;
}

void
count_msg()
{
    signal(SIGTTOU,count_msg);
    msg_num++;
}

void
r_msg()
{
    char buf[256];
    char msg[256];
    char fname[STRLEN];
    int line,tmpansi;
    int y,x,i,j,premsg,totalmsg;
    char ch;

    signal(SIGUSR2,r_msg);
    getyx(&y,&x);
    tmpansi=showansi;
    showansi=1;
    if(uinfo.mode==TALK)
        line=t_lines/2-1;
    else
        line=0;
    if(DEFINE(DEF_MSGGETKEY))
    {
       oflush();
       saveline(line,0);
       premsg = RMSG;
    }
    while(msg_num)
    {
       int countmsg;
       if(DEFINE(DEF_SOUNDMSG))
       {
            bell();
       }
       setuserfile(fname,"msgfile");
    totalmsg=0;
    i = get_num_msg(fname,&totalmsg);
	countmsg=0;
	for (j=totalmsg;j>0;j--)
	  if (get_record(fname,msg,129,j)==0)
	  	if (msg[10]!='9')
	  	{
	  		 countmsg++;
	  		 if (countmsg==msg_num) break;
	  	}
	msg[129]=0;
       move(line,0); clrtoeol(); prints("%s",msg); refresh();
       msg_num--;
       if(DEFINE(DEF_MSGGETKEY))
       {  
          RMSG=YEA;
          ch=0;
          while (ch!='\r' && ch!='\n')
          {
             ch = igetkey();
             if (ch=='\r'||ch=='\n')
                break;
             else if (ch == Ctrl('R')||ch == 'R'||ch == 'r'||ch == Ctrl('Z'))
                {
                struct user_info *uin ;
                char msgbuf[STRLEN];
                int good_id,send_pid;
                char *ptr,usid[STRLEN];

                ptr=strrchr(msg,'[');
                send_pid=atoi(ptr+1);
                ptr=strtok(msg+12," [");
                if(ptr==NULL)
                    good_id=NA;
                else if(!strcmp(ptr,currentuser.userid))
                    good_id=NA;
                else
                {
                   strcpy(usid,ptr);
                   uin=t_search(usid,send_pid);
                   if(uin==NULL)
                        good_id=NA;
                   else
                        good_id=YEA;
                }
                oflush();
                saveline(line+1,2);
                if(good_id==YEA)
                {
                    int userpid;
                    userpid=uin->pid;
                    move(line+1, 0);
                    clrtoeol();
                    sprintf(msgbuf,"������ѶϢ�� %s: ",usid);
                    getdata(line+1,0,msgbuf,buf,55,DOECHO,NULL,YEA);
                    if(buf[0]!='\0'&&buf[0]!=Ctrl('Z')&&buf[0]!=Ctrl('A'))
                    {
                        if(do_sendmsg(uin,buf,2,userpid))
                           sprintf(msgbuf,"[1;32m�����ͳ�ѶϢ�� %s ��![m",usid);
                        else
                           sprintf(msgbuf,"[1;32mѶϢ�޷��ͳ�.[m");
                    }
                    else sprintf(msgbuf,"[1;33m��ѶϢ, ���Բ��ͳ�.[m");
                 }
                else
                {
                    sprintf(msgbuf,"[1;32m�Ҳ�����ѶϢ�� %s.[m",usid);
                }
                move(line+1,0);
                clrtoeol();
                refresh();
                prints("%s",msgbuf);
                refresh();
                if(!strstr(msgbuf,"����"))
                    sleep(1);
                saveline(line+1,3);
                refresh();
                break;
                }  /* if */
          }  /* while */
       }    /* if */
    }  /* while */
    if(DEFINE(DEF_MSGGETKEY))
    {
       RMSG=premsg;
       saveline(line,1);
    }
    showansi=tmpansi;
    move(y,x);
    refresh();
    return ;
}

int
friend_login_wall(pageinfo)
struct user_info *pageinfo;
{
        char msg[STRLEN];
        int x,y;

        if( !pageinfo->active || !pageinfo->pid ||isreject(pageinfo))
                return 0;
        if (hisfriend(pageinfo)) {
                if(getuser(pageinfo->userid)<=0)
                        return 0;
                if(!(lookupuser.userdefine&DEF_LOGINFROM))
                        return 0;
                if(!strcmp(pageinfo->userid,currentuser.userid))
                        return 0;
                getyx(&y,&x);
                if (y > 22)
                   {
                   pressanykey();
                   move(7,0);
                   clrtobot();
                   }
                prints("�ͳ�������վ֪ͨ�� %s\n",pageinfo->userid);
                sprintf(msg,"��ĺ����� %s �Ѿ���վ�ޣ�",currentuser.userid);
                do_sendmsg(pageinfo,msg,2,pageinfo->pid);
        }
        return 0;
}
