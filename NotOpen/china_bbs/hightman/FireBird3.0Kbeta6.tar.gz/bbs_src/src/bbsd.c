/*
    Pirate Bulletin Board System
    Copyright (C) 1999, KCN,Zhou Lin, kcn@cic.tsinghua.edu.cn
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/


#include "bbs.h"

#define	QLEN		5
#define	PID_FILE	"reclog/bbs.pid"
#define	LOG_FILE	"reclog/bbs.log"

#define LOAD_LIMIT
static int myports[] = {BBS_PORT /* , 3456, 3001, 3002, 3003 */ };
static int big5ports[] = {BBS_BIG5_PORT/* , 3456, 3001, 3002, 3003 */ };
int big5 = 0;

static int mport;

int max_load = 15;
int csock;			/* socket for Master and Child */

void
cat(filename,msg)
char *filename,*msg;
{
    FILE        *fp;

    if( (fp = fopen( filename, "a" )) != NULL ) {
        fputs( msg, fp );
        fclose( fp );
    }
}

int Net_Sleep(time)
{
        struct timeval tv ;
	int	sr;
	fd_set fd,efd;

	tv.tv_sec = time;
	tv.tv_usec = 0;
	FD_ZERO(&fd);
	FD_ZERO(&efd);
	FD_SET(csock,&fd);
	FD_SET(csock,&efd);

	while((sr=select(csock+1,&fd,NULL,&efd,&tv))>0) {
		char buf[256];
		if (FD_ISSET(csock,&efd))
			break;
		if (recv(csock,buf,256,0)<=0) break;
		tv.tv_sec = time;
		tv.tv_usec = 0;
		FD_SET(csock,&fd);
		FD_SET(csock,&efd);
	};
}

void
prints(va_alist)
va_dcl
{
  va_list args;
  char buf[512], *fmt;
  int cc;

  va_start(args);
  fmt = va_arg(args, char *);
  vsprintf(buf, fmt, args);
  va_end(args);
  write(0,buf,strlen(buf));
}

void
get_load( load )
double load[];
{
#ifdef LINUX
    FILE *fp;
    fp = fopen ("/proc/loadavg", "r");
    if (!fp) load[0] = load[1] = load[2] = 0;
    else {
        float av[3];
        fscanf (fp, "%g %g %g", av, av + 1, av + 2);
        fclose (fp);
        load[0] = av[0]; load[1] = av[1]; load[2] = av[2];
    }
#else
#ifdef BSD44
    getloadavg( load, 3 );
#else
    struct statstime rs;
    rstat( "localhost", &rs );
    load[ 0 ] = rs.avenrun[ 0 ] / (double) (1 << 8);
    load[ 1 ] = rs.avenrun[ 1 ] / (double) (1 << 8);
    load[ 2 ] = rs.avenrun[ 2 ] / (double) (1 << 8);
#endif
#endif
}

int 
check_ban_site( addr )
char *addr;
{
   FILE *fp;
   char temp[STRLEN];

   if((fp = fopen( ".bansite", "r" )) != NULL ) 
     {
     while( fgets(temp,STRLEN,fp) != NULL)
        {
        strtok(temp," \n");
        if ((!strncmp(addr,temp,16))
           ||(!strncmp(temp,addr,strlen(temp)) && temp[strlen(temp) - 1] == '.')
           ||(temp[0] == '.' && strstr(addr,temp)!=NULL))
           {
            fclose(fp);
            return 1;
           }
        }
     fclose(fp);
     }
     return 0;
}

#ifndef CAN_EXEC
static void
telnet_init()
{
  static char svr[] = {
    IAC, DO, TELOPT_TTYPE,
    IAC, SB, TELOPT_TTYPE, TELQUAL_SEND, IAC, SE,
    IAC, WILL, TELOPT_ECHO,
    IAC, WILL, TELOPT_SGA
  };

  send(0, svr, sizeof(svr), 0);
}
#endif


static void
start_daemon(inetd, port)
  int inetd;
  int port; 
{
  int n;
  struct linger ld;
  struct sockaddr_in sin;
  struct rlimit rl;
  char buf[80], data[80];
  time_t val;
  int portcount,big5portcount;
  time_t now;


  portcount=sizeof(myports)/sizeof(int);
  big5portcount=sizeof(big5ports)/sizeof(int);

  chdir(MY_BBS_HOME);
  umask(007);

  close(1);
  close(2);

  now=time(0);

  if(inetd) 
  {
    setgid(BBSGID);
    setuid(BBSUID);
    mport = port;

    big5=port;
    sprintf(data, "%d\tinetd -i\n", getpid() );
    cat(PID_FILE, data);

    return;
  }

  sprintf(buf,"bbsd start at %s",ctime(&now));
  cat(PID_FILE, buf);


  close(0);

  if (fork())
    exit(0);

  setsid();

  if (fork())
    exit(0);

  sin.sin_family = AF_INET;
  sin.sin_addr.s_addr = INADDR_ANY;

  if (port <= 0) 
  {
    n =portcount+big5portcount-1;
    while (n) {
	if (fork()==0)
	  break;
	sleep(1);
	n--;
    }
    if (n<portcount)
	port = myports[n];
    else {
	big5=1;
	port = big5ports[n-portcount];
    }
  }

  n = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

  val = 1;
  setsockopt(n, SOL_SOCKET, SO_REUSEADDR, (char *) &val, sizeof(val));
  ld.l_onoff = ld.l_linger = 0;
  setsockopt(n, SOL_SOCKET, SO_LINGER, (char *) &ld, sizeof(ld));

  mport = port;
  sin.sin_port = htons(port);
  if ((bind(n, (struct sockaddr *)&sin, sizeof(sin)) < 0) || (listen(n, QLEN) < 0))
    exit(1);

  setgid(BBSGID);
  setuid(BBSUID);

  sprintf(data, "%d\t\t%d\n", getpid(), port);
  cat(PID_FILE, data);
}


static inline void
reaper()
{
  while (waitpid(-1, NULL, WNOHANG | WUNTRACED) > 0);
}

static void
main_term()
{
  exit(0);
}

static inline void
main_signals()
{
  struct sigaction act;

  /* act.sa_mask = 0; */ /* Thor.981105: ��׼�÷� */
  sigemptyset(&act.sa_mask);      
  act.sa_flags = 0;

  act.sa_handler = reaper;
  sigaction(SIGCHLD, &act, NULL);

  act.sa_handler = main_term;
  sigaction(SIGTERM, &act, NULL);

  /* sigblock(sigmask(SIGPIPE)); */
}

int
bbs_main(hid) 
char* hid;
{
    int         uid;
    char        buf[256];
    char bbs_prog_path[ 256 ];


/* load control for BBS */
#ifdef LOAD_LIMIT
{
    double      cpu_load[ 3 ];
    int         load ;

    get_load( cpu_load );
    load = cpu_load[ 0 ];
    if (big5)
      prints("\033[1;36mBBS �̪� \033[33m(1,10,15)\033[36m �����������t�����O��\033[33m %.2f, %.2f, %.2f \033[36m(�ثe�W�� = %d).\033[0m\n\r\n\r", 
                cpu_load[ 0 ], cpu_load[ 1 ], cpu_load[ 2 ], max_load );
    else
      prints("\033[1;36mBBS ��� \033[33m(1,10,15)\033[36m ���ӵ�ƽ�����ɷֱ�Ϊ\033[33m %.2f, %.2f, %.2f \033[36m(Ŀǰ���� = %d).\033[0m\n\r\n\r", 
                cpu_load[ 0 ], cpu_load[ 1 ], cpu_load[ 2 ], max_load );

    if ( load < 0 || load > max_load ) {
    	if (big5)
          prints("�ܩ�p,�ثe�t�έt���L��, �еy��A��\n\r");
    	else
          prints("�ܱ�Ǹ,Ŀǰϵͳ���ɹ���, ���Ժ�����\n\r");
        Net_Sleep( load );
	shutdown(csock,2);
	close(csock);
        exit( -1 );
    }
}
#endif	/* LOAD_LIMIT */
{
    FILE        *fp;

    if((fp = fopen("NOLOGIN","r")) != NULL) 
    {
        while(fgets(buf,256,fp) != NULL)
 	       prints(buf);
        fclose(fp);
        Net_Sleep(3);
	shutdown(csock,2);
	close(csock);
        exit(-1);
    }
}

#ifdef BBSRF_CHROOT
        sprintf( bbs_prog_path, "/bin/bbs", MY_BBS_HOME );
        if (chroot(BBSHOME) != 0) {
            prints("Cannot chroot, exit!\r\n");
            exit( -1 );
        } 
#else
        sprintf( bbs_prog_path, "%s/bin/bbs", MY_BBS_HOME );
#endif

        if (check_ban_site(hid))
        {
            if (big5)
              prints("�����ثe���w��Ӧ� %s �X��!\r\n", hid);
            else
              prints("��վĿǰ����ӭ���� %s ����!\r\n", hid);
            Net_Sleep(4);
	    shutdown(csock,2);
	    close(csock);
            exit(-1);
        }


	hid[16] = '\0' ;

        if (big5)
        	execl( bbs_prog_path,"bbs","e", hid,  NULL) ; /*����BBS*/
        else
        	execl( bbs_prog_path,"bbs","d", hid,  NULL) ; /*����BBS*/
	write(0,"execl failed\r\n",12);
        exit( -1 );
}

int
main(argc, argv)
  int argc;
  char *argv[];
{
  int *totaluser;
  int value;
  struct sockaddr_in sin;
  struct hostent * whee;
  char hid[17];

  start_daemon(argc > 2, atoi(argv[argc-1]));

  main_signals();

  if (argc<=2)
  for (;;)
  {
    value = 1;
    if (select(1, (fd_set *) & value, NULL, NULL, NULL) < 0)
      continue;

    value = sizeof(sin);
    csock = accept(0, (struct sockaddr *)&sin, &value);
    if (csock < 0)
    {
      reaper();
      continue;
    }

    if (fork())
    {
      close(csock);

#ifdef LOAD_LIMIT
{
      double      cpu_load[ 3 ];
      int         load ;
      get_load( cpu_load );
      load = cpu_load[ 0 ];
      if ( load < 0 || load > max_load ) 
	sleep(5);	/* sleep for heavy load */
}
#endif
      continue;
    }

    
    if (csock) {
	dup2(csock, 0);
	close(csock);
    }
    break;
  }
  else {
	int sinlen = sizeof (struct sockaddr_in);
	getpeername (0,(struct sockaddr *) &sin,(void *) &sinlen);
  }
  whee = gethostbyaddr((char*)&sin.sin_addr.s_addr,sizeof(struct in_addr),AF_INET);
  if ((whee)&&(whee->h_name[0]))
      strncpy(hid, whee->h_name, 17) ;
  else
  {
      char*host = (char*)inet_ntoa(sin.sin_addr);
      strncpy(hid,host,17);
  }
    	
#ifndef CAN_EXEC
  telnet_init();
#endif
  bbs_main(hid);
}

