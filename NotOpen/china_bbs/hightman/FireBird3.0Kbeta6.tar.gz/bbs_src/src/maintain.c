/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu
    Firebird Bulletin Board System
    Copyright (C) 1996, Hsien-Tsung Chang, Smallpig.bbs@bbs.cs.ccu.edu.tw
                        Peng Piaw Foong, ppfoong@csie.ncu.edu.tw
    
    Copyright (C) 1999, KCN,Zhou Lin, kcn@cic.tsinghua.edu.cn

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/

#include "bbs.h"

char    cexplain[STRLEN];
char    *Ctime();
char    lookgrp[30];
int showperminfo(int,int );

int
check_systempasswd()
{
    FILE *pass;
    char passbuf[20],prepass[STRLEN];

    clear();
    if((pass=fopen("etc/.syspasswd","r"))!=NULL)
    {
           fgets(prepass,STRLEN,pass);
           fclose(pass);
           prepass[strlen(prepass)-1]='\0';
           getdata(1,0,"������ϵͳ����: ",passbuf,19,NOECHO,NULL,YEA);
           if(passbuf[0]=='\0'||passbuf[0]=='\n')
                return NA;
           if(!checkpasswd(prepass,passbuf))
           {
                 move(2,0);
                 prints("�����ϵͳ����...");
                 securityreport("ϵͳ�����������...");
                 pressanykey();
                 return NA;
           }
    }
    return YEA;
}

int
setsystempasswd()
{
        FILE *pass;
        char passbuf[20],prepass[20];

        modify_user_mode( ADMIN );
        if(strcmp(currentuser.userid,"SYSOP"))
                return ;
        if(!check_systempasswd())
                return ;
        getdata(2,0,"�������µ�ϵͳ����: ",passbuf,19,NOECHO,NULL,YEA);
        getdata(3,0,"ȷ���µ�ϵͳ����: ",prepass,19,NOECHO,NULL,YEA);
        if(strcmp(passbuf,prepass))
                return ;
        if((pass=fopen("etc/.syspasswd","w"))==NULL)
        {
                move(4,0);
                prints("ϵͳ�����޷��趨....");
                pressanykey();
                return;
        }
        fprintf(pass,"%s\n",genpasswd(passbuf));
        fclose(pass);
        move(4,0);
        prints("ϵͳ�����趨���....");
        pressanykey();
        return;
}

deliverreport(title,str)
char *title;
char *str;
{
        FILE *se;
        char fname[STRLEN];
	int  savemode;

	savemode = uinfo.mode;
        report(str);
        sprintf(fname,"tmp/deliver.%s.%05d",currentuser.userid,uinfo.pid);
        if((se=fopen(fname,"w"))!=NULL)
        {
                fprintf(se,"%s",str);
                fclose(se);
                postfile( fname,currboard,title,1);
                unlink(fname);
	        modify_user_mode( savemode );        
        }
}

securityreport(str)
char *str;
{
        FILE *se;
        char fname[STRLEN];
	int  savemode;

	savemode = uinfo.mode;
        report(str);
        sprintf(fname,"tmp/security.%s.%05d",currentuser.userid,uinfo.pid);
        if((se=fopen(fname,"w"))!=NULL)
        {
                fprintf(se,"ϵͳ��ȫ��¼ϵͳ\n[1mԭ��%s[m\n",str);
                fprintf(se,"�����Ǹ�������");
                getuinfo(se);
                fclose(se);
                postfile( fname,"syssecurity",str,2);
                unlink(fname);
        modify_user_mode( savemode );        
        }
}

int
get_grp(seekstr)
char seekstr[STRLEN];
{
    FILE *fp;
    char buf[STRLEN];
    char *namep;

    if ((fp = fopen("0Announce/.Search", "r")) == NULL)
        return 0;
    while (fgets(buf, STRLEN, fp) != NULL) {
        namep = strtok( buf, ": \n\r\t" );
        if (namep != NULL && ci_strcmp(namep, seekstr) == 0 ) {
            fclose(fp);
            strtok( NULL, "/" );
            namep= strtok( NULL, "/" );
            if (strlen(namep)<30)
               {
               strcpy(lookgrp,namep);
               return 1;
               } else return 0;
        }
    }
    fclose(fp);
    return 0;
}

void
stand_title( title )
char    *title;
{
    clear();
    standout();
    prints( title );
    standend();
}

int
m_info()
{
    struct userec uinfo ;
    int id;

    modify_user_mode( ADMIN );
    if(!check_systempasswd())
    {
        return;
    }
    clear();
    stand_title("�޸�ʹ���ߴ���") ;
    move(1,0) ;
    usercomplete("������ʹ���ߴ���: ", genbuf) ;
    if(*genbuf == '\0') {
        clear() ;
        return -1;
    }

    if(!(id = getuser(genbuf))) {
        move(3,0) ;
        prints("�����ʹ���ߴ���") ;
        clrtoeol() ;
        pressreturn() ;
        clear() ;
        return -1;
    }
    memcpy( &uinfo, &lookupuser, sizeof(uinfo)) ;

    move(1,0);
    clrtobot();
    disply_userinfo( &uinfo, 1 );
    uinfo_query( &uinfo, 1, id );
    return 0;
}

extern int cmpbnames();
extern int numboards;

int
valid_brdname( brd )
char    *brd;
{
    char        ch;

    ch = *brd++;
    if( !isalnum( ch ) && ch != '_' )
        return 0;
    while( (ch = *brd++) != '\0' ) {
        if( !isalnum(ch) && ch != '_' )
            return 0;
    }
    return 1;
}

char *
chgrp()
{
     int i,ch;
     char buf[STRLEN],ans[6];

static char *explain[]={
        "��վϵͳ", 
        "ͬѧ��",
        "���Լ���",   
        "ѧ����ѧ", 
        "�����Ļ�",  
        "�������",
        "��������", 
        "֪�Ը���",  
        "����ʱ��",  
        NULL
};

static char *groups[]={
        "GROUP_0",
        "GROUP_1",
        "GROUP_2",
        "GROUP_3",
        "GROUP_4",
        "GROUP_5",
        "GROUP_6",
        "GROUP_7",
        "GROUP_8",
        NULL
};

        clear();
        move(2,0);
        prints("ѡ�񾫻�����Ŀ¼\n\n");
        for(i=0;;i++)
        {
                if(explain[i]==NULL||groups[i]==NULL)
                        break;
                prints("[1;32m%2d[m. %-20s%-20s\n",i,explain[i],groups[i]);
        }
        sprintf(buf,"���������ѡ��(0~%d): ",--i);
        while(1)
        {
                getdata(i+6,0,buf,ans,4,DOECHO,NULL,YEA);
                if(!isdigit(ans[0]))
                        continue;
                ch=atoi(ans);
                if(ch<0||ch>i||ans[0]=='\r'||ans[0]=='\0')
                        continue;
                else
                        break;
        }                
                sprintf(cexplain,"%s",explain[ch]);

        return groups[ch];
}


int
m_newbrd()
{
    struct boardheader newboard ;
    extern int  numboards ;
    char        ans[4];
    char        vbuf[100];
    char        *group;
    int         bid;
    

    modify_user_mode( ADMIN );
    if(!check_systempasswd())
    {
        return;
    }
    clear();
    stand_title("������������") ;
    memset(&newboard, 0, sizeof(newboard));
    move(2,0);
    ansimore2("etc/boardref",NA,3,7);
    while( 1 ) {
        getdata(10,0, "����������:   ", newboard.filename,18,DOECHO,NULL,YEA);
        if (newboard.filename[0] != 0) {
            struct boardheader dh;
            if (search_record(BOARDS,&dh,sizeof(dh),cmpbnames,newboard.filename)){
                prints("\n����! ���������Ѿ�����!!");
                pressanykey();
                return -1;
                }
            } else return -1;
        if( valid_brdname( newboard.filename ) )
            break;
        prints( "\n���Ϸ�����!!" );
    }
    newboard.flag=0;
    while( 1 ) {
        getdata(11,0,"������˵��:   ",newboard.title,60,DOECHO,NULL,YEA) ;
        if (newboard.title[0] == '\0') return -1;
        if(strstr(newboard.title,"��")||strstr(newboard.title,"��"))
           {
           newboard.flag |= OUT_FLAG;
           break;
           }
        else if(strstr(newboard.title,"��"))
           {
           newboard.flag &= ~OUT_FLAG;
           break;
           }
        else prints("����ĸ�ʽ, �޷��ж��Ƿ�ת��!!");
    }
    strcpy(vbuf, "vote/");
    strcat(vbuf, newboard.filename);
    setbpath( genbuf, newboard.filename );
    if( getbnum(newboard.filename) > 0 || mkdir(genbuf,0777) == -1
         || mkdir(vbuf, 0777) == -1 ) {
        prints("\n���������������!!\n");
        pressreturn();
        rmdir(vbuf);
        rmdir(genbuf);
        clear();
        return -1;
    }
    getdata(12,0,"����������Ա: ", newboard.BM, BM_LEN-1, DOECHO,NULL,YEA) ;
    move(13,0);
    if (askyn("�Ƿ����ƴ�ȡȨ��",NA,NA)==YEA) {
        getdata(14,0,"���� Read/Post? [R]: ",ans,2,DOECHO, NULL,YEA);                
        if (*ans == 'P' || *ans == 'p') newboard.level = PERM_POSTMASK;
        else newboard.level = 0;
        move(1,0);
        clrtobot();
        move(2,0);
        prints( "�趨 %s Ȩ��. ������: '%s'\n",
                (newboard.level & PERM_POSTMASK ? "POST" : "READ"),
                newboard.filename);
        newboard.level = setperms(newboard.level,"Ȩ��",NUMPERMS,showperminfo);
        clear();                                        
    } else newboard.level = 0;  
    if( (bid = getbnum( "" )) > 0 ) {
        substitute_record( BOARDS, &newboard, sizeof( newboard ), bid );
    } else if( append_record(BOARDS,&newboard,sizeof(newboard)) == -1 ) {
        pressreturn() ;
        clear() ;
        return -1 ;
    }
    move(14,0);
    if(askyn("�Ƿ����������",NA,NA)==YEA)
        newboard.flag |= ANONY_FLAG;
    else
        newboard.flag &= ~ANONY_FLAG;
    group=chgrp();
    if(group!=NULL)
    {
        if(newboard.BM[0]!='\0')
            sprintf( vbuf, "%-38.38s(BM: %s)", newboard.title+8,newboard.BM);
        else
            sprintf( vbuf, "%-38.38s", newboard.title+8);

        if(add_grp(group,cexplain,newboard.filename,vbuf)==-1)
                prints("\n����������ʧ��....\n");
        else
                prints("�Ѿ����뾫����...\n");
    }
           
    numboards = -1 ;
    prints("\n������������\n") ;
    {
        char        secu[STRLEN];
        sprintf(secu,"�����°壺%s",newboard.filename);
        securityreport(secu);
    }
    pressreturn() ;
    clear()  ;
    return 0 ;
}

int
m_editbrd()
{
    char bname[STRLEN],buf[STRLEN],oldtitle[STRLEN],vbuf[256],*group;
    char oldpath[STRLEN],newpath[STRLEN],tmp_grp[30];
    int pos,noidboard,a_mv;
    struct boardheader fh, newfh;

    modify_user_mode( ADMIN );
    if(!check_systempasswd())
    {
        return;
    }
    clear();
    stand_title("�޸���������Ѷ");
    move(1,0);
    make_blist();
    namecomplete("��������������: ", bname);
    if (*bname == '\0') {
        move(2,0);
        prints("���������������");
        pressreturn();
        clear();
        return -1;
    }
    pos = search_record(BOARDS, &fh, sizeof(fh), cmpbnames, bname);
    if (!pos) {
        move(2,0);
        prints("���������������");
        pressreturn();
        clear();
        return -1;
    }
    noidboard=fh.flag&ANONY_FLAG;
    move(3,0);
    memcpy( &newfh, &fh, sizeof(newfh));
    prints("����������:   %s\n", fh.filename);
    prints("������˵��:   %s\n", fh.title);
    prints("����������Ա: %s\n", fh.BM);
    prints("����������:   %s\n", (noidboard)?"Yes":"No");
    strcpy(oldtitle,fh.title);
    prints("���� %s Ȩ��: %s", 
       (fh.level & PERM_POSTMASK) ? "POST" : 
       (fh.level & PERM_NOZAP) ? "ZAP" : "READ",
            (fh.level & ~PERM_POSTMASK) == 0 ? "������" : "������" );
    move(8,0);
    if (askyn("�Ƿ����������Ѷ",NA,NA) == YEA) {
    move(9,0);
    prints("ֱ�Ӱ� <Return> ���޸Ĵ�����Ѷ...");
enterbname:
        getdata(10,0, "������������: ", genbuf, 18, DOECHO, NULL,YEA);
        if (*genbuf != 0) {
            struct boardheader dh;
            if (search_record(BOARDS,&dh,sizeof(dh),cmpbnames,genbuf)){
                move(2,0);
                prints("����! ���������Ѿ�����!!");
                move(10,0);
                clrtoeol();
                goto enterbname;
            }
            if(valid_brdname(genbuf))
            {
              strncpy(newfh.filename, genbuf, sizeof(newfh.filename));
              strcpy(bname,genbuf);
            } else
            {
                move(2,0);
                prints("���Ϸ�������������!");
                move(10,0);
                clrtoeol();
                goto enterbname;
            }  
        }
    ansimore2("etc/boardref",NA,11,7);
    while( 1 ) {
        getdata(18,0, "��������˵��: ", genbuf, 60, DOECHO, NULL,YEA);
        if (*genbuf != 0)
            strncpy(newfh.title, genbuf, sizeof(newfh.title));
        else break;
        if(strstr(newfh.title,"��")||strstr(newfh.title,"��"))
           {
           newfh.flag |= OUT_FLAG;
           break;
           }
        else if(strstr(newfh.title,"��"))
           {
           newfh.flag &= ~OUT_FLAG;
           break;
           }
        else prints("\n����ĸ�ʽ, �޷��ж��Ƿ�ת��!!");
    }
        move(20,0);
        clrtoeol();
        getdata(19,0, "����������Ա: ", genbuf, 60, DOECHO, NULL,YEA);
        if (*genbuf != 0)
            strncpy(newfh.BM, genbuf, sizeof(newfh.BM));
        if (*genbuf == ' ')
            strncpy(newfh.BM, "\0", sizeof(newfh.BM));
        sprintf(buf,"������ (Y/N)? [%c]: ",(noidboard)?'Y':'N');
        getdata(20,0, buf , genbuf, 4, DOECHO, NULL,YEA);
        if(*genbuf=='y'||*genbuf=='Y'||*genbuf=='N'||*genbuf=='n')
        {
                if(*genbuf=='y'||*genbuf=='Y')
                    newfh.flag |= ANONY_FLAG;
                else
                    newfh.flag &= ~ANONY_FLAG;
        }
        move(21,0);
        if(askyn("�Ƿ��ƶ���������λ��",NA,NA)==YEA)
                a_mv=2;
        else
                a_mv=0;        
        move(22,0);
        if(askyn("�Ƿ���Ĵ�ȡȨ��",NA,NA)==YEA)
        {
            char ans[4];
            sprintf(genbuf, "���� (R)�Ķ� �� (P)���� ���� [%c]: ",
                (newfh.level & PERM_POSTMASK ? 'P' : 'R'));
            getdata(23,0, genbuf, ans, 2, DOECHO, NULL,YEA);
            if ((newfh.level & PERM_POSTMASK) && (*ans=='R' || *ans=='r'))
                newfh.level &= ~PERM_POSTMASK;
            else if (!(newfh.level & PERM_POSTMASK) && (*ans=='P'||*ans=='p'))
                newfh.level |= PERM_POSTMASK;
            clear();
            move(2,0);
            prints("�趨 %s '%s' ��������Ȩ��\n",
                newfh.level & PERM_POSTMASK ? "����" : "�Ķ�", newfh.filename);
            newfh.level = setperms(newfh.level,"Ȩ��",NUMPERMS,showperminfo);
            clear();
            getdata(0,0, "ȷ��Ҫ������? (Y/N) [N]: ",genbuf,4,DOECHO,NULL,YEA);
        } else {
            getdata(23,0,"ȷ��Ҫ������? (Y/N) [N]: ",genbuf,4,DOECHO,NULL,YEA);
        }
        if (*genbuf == 'Y' || *genbuf == 'y') {
            {
               char        secu[STRLEN];
               sprintf(secu,"�޸���������%s(%s)",fh.filename,newfh.filename);
               securityreport(secu);
            }
            if (strcmp(fh.filename, newfh.filename)) {
                char old[256], tar[256];
                a_mv=1;           
                setbpath( old, fh.filename );
                setbpath( tar, newfh.filename );
                rename(old, tar);
                sprintf(old, "vote/%s", fh.filename);
                sprintf(tar, "vote/%s", newfh.filename);
                rename(old, tar);
             }
             if(newfh.BM[0]!='\0')
                  sprintf( vbuf, "%-38.38s(BM: %s)", newfh.title+8,newfh.BM);
             else
                  sprintf( vbuf, "%-38.38s", newfh.title+8);
             get_grp(fh.filename);
             edit_grp(fh.filename,lookgrp,oldtitle+8,vbuf);

            if(a_mv>=1)
            {
                    group=chgrp();
                    get_grp(fh.filename);
                    strcpy(tmp_grp,lookgrp);
                 if(strcmp(tmp_grp,group)||a_mv!=2)
                 {       
                    del_from_file("0Announce/.Search",fh.filename);
                    if(group!=NULL)
                    {
                        if(newfh.BM[0]!='\0')
                            sprintf( vbuf, "%-38.38s(BM: %s)", newfh.title+8,newfh.BM);
                        else
                            sprintf( vbuf, "%-38.38s", newfh.title+8);

                        if(add_grp(group,cexplain,newfh.filename,vbuf)==-1)
                                prints("\n����������ʧ��....\n");
                        else
                                prints("�Ѿ����뾫����...\n");
                        sprintf(newpath,"0Announce/groups/%s/%s",group,newfh.filename);
                        sprintf(oldpath,"0Announce/groups/%s/%s",tmp_grp,fh.filename);
                        if(dashd(oldpath))
                        {
                                deltree(newpath) ;
                        }
                        rename(oldpath,newpath);
                        del_grp(tmp_grp,fh.filename,fh.title+8);
                    }
                  }
            }
            substitute_record(BOARDS, &newfh, sizeof(newfh), pos);
            sprintf(genbuf, "���������� %s ������ --> %s",
                        fh.filename, newfh.filename);
            report(genbuf);
            numboards = -1;    /* force re-caching */
        }
    }
    clear();
    return 0;
}

FILE *cleanlog;
char curruser[IDLEN+2];
extern int delmsgs[];
extern int delcnt;

void
domailclean(fhdrp)
struct fileheader *fhdrp;
{
    static int newcnt, savecnt, deleted, idc;
    char buf[STRLEN];

    if (fhdrp == NULL) {
        fprintf(cleanlog, "new = %d, saved = %d, deleted = %d\n",
                newcnt, savecnt, deleted);      
        newcnt = savecnt = deleted = idc = 0;
        if (delcnt) {
           sprintf(buf, "mail/%c/%s/%s", toupper(curruser[0]), curruser, DOT_DIR);
           while (delcnt--)
                delete_record(buf, sizeof(struct fileheader), delmsgs[delcnt]);
        }
        delcnt = 0;         
        return;
    }
    idc++;
    if (!(fhdrp->accessed[0] & FILE_READ))
        newcnt++;
    else if (fhdrp->accessed[0] & FILE_MARKED)
        savecnt++;
    else {
        deleted++;
        sprintf(buf, "mail/%c/%s/%s", toupper(curruser[0]), curruser, fhdrp->filename);
        unlink(buf);
        delmsgs[delcnt++] = idc;
    }
}

int
cleanmail(urec)
struct userec *urec;
{
    struct stat statb;
    if (urec->userid[0] == '\0' || !strcmp(urec->userid, "new"))
        return 0;
    sprintf(genbuf, "mail/%c/%s/%s", toupper(urec->userid[0]), urec->userid, DOT_DIR);
    fprintf(cleanlog, "%s: ", urec->userid);
    if (stat(genbuf, &statb) == -1)
        fprintf(cleanlog, "no mail\n");
    else if (statb.st_size == 0)
        fprintf(cleanlog, "no mail\n");
    else {
        strcpy(curruser, urec->userid);
        delcnt = 0;
        apply_record(genbuf, domailclean, sizeof(struct fileheader));
        domailclean(NULL);
    }
    return 0;
}

int
m_mclean()
{
    modify_user_mode( ADMIN );
    if(!check_systempasswd())
    {
        return;
    }
    clear();
    stand_title("���˽���ż�");
    move(1,0);
    prints("��������Ѷ���δ mark ���ż�\n");
    if (askyn("ȷ����",NA,NA)==NA) {
        clear();
        return 0;
    }
    {
         char        secu[STRLEN];
         sprintf(secu,"�������ʹ�����Ѷ��ż���");
         securityreport(secu);
    }

    cleanlog = fopen("mailclean.log", "w");
    move(3,0);
    prints("�����ĵȺ�.\n");
    refresh();
    if (apply_record(PASSFILE, cleanmail, sizeof(struct userec)) == -1) {
        move(4,0);
        prints("apply PASSFILE err...\n");
        pressreturn();
        clear();
        return -1;
    }
    move(4,0);
    fclose(cleanlog);
    prints("������! ��¼�� mailclean.log.\n");
    pressreturn();
    clear();
    return 0;
}

void
trace_state( flag, name, size )
int     flag, size;
char    *name;
{
    char        buf[ STRLEN ];

    if( flag != -1 ) {
        sprintf( buf, "ON (size = %d)", size );
    } else {
        strcpy( buf, "OFF" );
    }
    prints( "%s��¼ %s\n", name, buf );
}

int
touchfile( filename )
char    *filename;
{
    int         fd;

    if( (fd = open( filename, O_RDWR | O_CREAT, 0600 )) > 0 ) {
        close( fd );
    }
    return fd;
}

int
m_trace()
{
    struct stat ostatb, cstatb;
    int otflag, ctflag, done = 0;
    char ans[3];
    char *msg;

    modify_user_mode( ADMIN );
    if(!check_systempasswd())
    {
        return;
    }
    clear();
    stand_title("Set Trace Options");
    while (!done) {
        move(2,0);
        otflag = stat("trace", &ostatb);
        ctflag = stat("trace.chatd", &cstatb);
        prints("Ŀǰ�趨:\n");
        trace_state( otflag, "һ��", ostatb.st_size );
        trace_state( ctflag, "����", cstatb.st_size );
        move(9,0);
        prints("<1> �л�һ���¼\n" );
        prints("<2> �л������¼\n" );
        getdata(12,0,"��ѡ�� (1/2/Exit) [E]: ",ans,2,DOECHO,NULL,YEA);

        switch (ans[0]) {
            case '1':
                if (otflag) {
                    touchfile( "trace" );
                    msg = "һ���¼ ON";
                } else {
                    rename( "trace", "trace.old" );
                    msg = "һ���¼ OFF";
                }
                break;
            case '2':
                if (ctflag) {
                    touchfile( "trace.chatd" );
                    msg = "�����¼ ON";
                } else {
                    rename( "trace.chatd", "trace.chatd.old" );
                    msg = "�����¼ OFF";
                }
                break;
            default:
                msg = NULL;
                done = 1;
        }
        move(t_lines-2, 0);
        if (msg) {
            prints( "%s\n", msg );
            report( msg );
        }
    }
    clear();
    return 0;
}

int
scan_register_form( regfile )
char    *regfile;
{
    static char *field[] = { "usernum", "userid", "realname", "dept",
                "addr", "phone","assoc" ,NULL };
    static char *finfo[] = { "�ʺ�λ��", "�����ʺ�", "��ʵ����", "ѧУϵ��",
                "Ŀǰסַ", "����绰","�� �� ��", NULL };
    static char *reason[] = { "��ȷʵ��д��ʵ����.", "������ѧУ��ϵ���꼶.",
                "����д������סַ����.", "����������绰.",
                "����дУ�ѻ�����.", "��ȷʵ��дע�������.",
                "����������д���뵥.", "����ϸ��д����������.",
		 NULL };
    struct userec uinfo;
    FILE        *fn, *fout, *freg;
    struct stat st;
    char        fdata[ 7 ][ STRLEN ];
    char        fname[ STRLEN ], buf[ STRLEN ];
    char        ans[5], *ptr, *uid;
    int         n, unum;

    uid = currentuser.userid;
    stand_title( "�����趨������ע������" );
    sprintf( fname, "%s.tmp", regfile );
    move( 2, 0 );
    if( dashf( fname ) ) {
      if( stat( fname, &st ) != -1 && st.st_atime > time(0) - 86400 ) {
        prints( "���� SYSOP ���ڲ鿴ע�����뵥, ����ʹ����״̬.\n" );
        unlink(fname);
        pressreturn();
      } else {
        prints( "���� SYSOP ���ڲ鿴ע�����뵥, ����ʹ����״̬.\n" );
        pressreturn();
        return -1;
      }
    }
    rename( regfile, fname );
    if( (fn = fopen( fname, "r" )) == NULL ) {
        move( 2, 0 );
        prints( "ϵͳ����, �޷���ȡע�����ϵ�: %s\n", fname );
        pressreturn();
        return -1;
    }
    memset( fdata, 0, sizeof( fdata ) );
    while( fgets( genbuf, STRLEN, fn ) != NULL ) {
        if( (ptr = (char *)strstr( genbuf, ": " )) != NULL ) {
            *ptr = '\0';
            for( n = 0; field[n] != NULL; n++ ) {
                if( strcmp( genbuf, field[n] ) == 0 ) {
                    strcpy( fdata[n], ptr+2 );
                    if( (ptr = (char *)strchr( fdata[n], '\n' )) != NULL )
                        *ptr = '\0';
                }
            }
        } else if( (unum = getuser( fdata[1] )) == 0 ) {
            move( 2, 0 );
            clrtobot();
            prints( "ϵͳ����, ���޴��ʺ�.\n\n" );
            for( n = 0; field[n] != NULL; n++ )
                prints( "%s     : %s\n", finfo[n], fdata[n] );
            pressreturn();
            memset( fdata, 0, sizeof( fdata ) );
        } else {
            memcpy( &uinfo, &lookupuser, sizeof( uinfo ) );
            move( 1, 0 );
            prints( "�ʺ�λ��     : %d\n", unum );
            disply_userinfo( &uinfo, 1 );
            move( 15, 0 );
            printdash( NULL );
            for( n = 0; field[n] != NULL; n++ )
                prints( "%s     : %s\n", finfo[n], fdata[n] );
            if( uinfo.userlevel & PERM_LOGINOK ) {
                move( t_lines-1, 0 );
                prints( "���ʺŲ�������дע�ᵥ.\n" );
                igetkey();
                ans[0] = 'D';
            } else {
                getdata(t_lines-1,0, "�Ƿ���ܴ����� (Y/N/Q/Del/Skip)? [S]: ",
                        ans,3,DOECHO,NULL,YEA);
            }
            move( 1, 0 );
            clrtobot();
            switch( ans[0] ) {
                case 'D': case 'd':
                    break;
                case 'Y': case 'y':
                    prints( "����ʹ���������Ѿ�����:\n" );
                    n = strlen( fdata[5] );
                    if( n + strlen( fdata[3] ) > 60 ) {
                        if( n > 40 )  fdata[5][ n = 40 ] = '\0';
                        fdata[3][ 60-n ] = '\0';
                    }
                    strncpy( uinfo.realname, fdata[2], NAMELEN );
                    strncpy( uinfo.address,  fdata[4], NAMELEN );
                    sprintf( genbuf, "%s$%s@%s", fdata[3], fdata[5], uid );
                    strncpy( uinfo.termtype+16, genbuf, STRLEN-16 );
                    substitute_record( PASSFILE, &uinfo, sizeof(uinfo), unum );

                    sethomefile(buf,uinfo.userid,"sucessreg");
                    if( (fout = fopen( buf, "w" )) != NULL ) {
                        fprintf( fout, "\n");
                        fclose( fout );
                    }
                    
                    sethomefile(buf,uinfo.userid,"register");
                    if(dashf(buf))
                        {
                        sethomefile(genbuf,uinfo.userid,"register.old");
                        rename(buf, genbuf);
                        }
                    if( (fout = fopen( buf, "w" )) != NULL ) {
                        for( n = 0; field[n] != NULL; n++ )
                            fprintf( fout, "%s: %s\n", field[n], fdata[n] );
                        n = time( NULL );
                        fprintf( fout, "Date: %s\n", Ctime( &n ) );
                        fprintf( fout, "Approved: %s\n", uid );
                        fclose( fout );
                    }
                    mail_file("etc/s_fill",uinfo.userid,"�����㣬���Ѿ����ע�ᡣ");
                    sethomefile(buf,uinfo.userid,"mailcheck");
                    unlink(buf);
                    sprintf(genbuf,"�� %s ͨ������ȷ��.",uinfo.userid);
                    securityreport(genbuf);
                    break;
                case 'Q': case 'q':
                    if( (freg = fopen( regfile, "a" )) != NULL ) {
                        for( n = 0; field[n] != NULL; n++ )
                            fprintf( freg, "%s: %s\n", field[n], fdata[n] );
                        fprintf( freg, "----\n" );
                        while( fgets( genbuf, STRLEN, fn ) != NULL )
                            fputs( genbuf, freg );
                        fclose( freg );
                    }
                    break;
                case 'N': case 'n':
                    for( n = 0; field[n] != NULL; n++ )
                        prints( "%s: %s\n", finfo[n], fdata[n] );
                    printdash( NULL );
                    move(9,0);
                    prints( "��ѡ��/�����˻������ԭ��, �� <enter> ȡ��.\n\n" );
                    for( n = 0; reason[n] != NULL; n++ )
                        prints( "%d) %s\n", n, reason[n] );
                    getdata(12+n,0,"�˻�ԭ��: ",buf,60,DOECHO,NULL,YEA);
                    if( buf[0] != '\0' ) {
                        if( buf[0] >= '0' && buf[0] < '0' + n ) {
                            strcpy( buf, reason[ buf[0] - '0' ] );
                        }
                        sprintf( genbuf, "<ע��ʧ��> - %s", buf );
                        strncpy( uinfo.address, genbuf, NAMELEN );
                        substitute_record(PASSFILE,&uinfo,sizeof(uinfo),unum);
                        mail_file("etc/f_fill",uinfo.userid,uinfo.address);
                        /* user_display( &uinfo, 1 ); */
                        /* pressreturn(); */
                        break;
                    }
                    move( 10, 0 );
                    clrtobot();
                    prints( "ȡ���˻ش�ע�������.\n" );
                    /* run default -- put back to regfile */
                default:
                    if( (freg = fopen( regfile, "a" )) != NULL ) {
                        for( n = 0; field[n] != NULL; n++ )
                            fprintf( freg, "%s: %s\n", field[n], fdata[n] );
                        fprintf( freg, "----\n" );
                        fclose( freg );
                    }
            }
            memset( fdata, 0, sizeof( fdata ) );
        }
    }
    fclose( fn );
    unlink( fname );
    return( 0 );
}

int
m_register()
{
    FILE        *fn;
    char        ans[3], *fname;
    int         x, y, wid, len;
    char        uident[STRLEN];

    modify_user_mode( ADMIN );
    if(!check_systempasswd())
    {
        return;
    }
    clear();

    stand_title("�趨ʹ����ע������");
    for (;;)
        {
    	   getdata(1,0,"(0)�뿪  (1)�����ע������  (2)��ѯʹ����ע������ ? : ",
    	          ans,2,DOECHO,NULL,YEA);
           if(ans[0]=='0') return 0;
           if(ans[0]=='1'||ans[0]=='2') break;
	}
    if (ans[0]=='1')
    {    
    fname = "new_register";
    if( (fn = fopen( fname, "r" )) == NULL ) {
        prints( "\n\nĿǰ������ע������." );
        pressreturn();
    } else {
        y = 3, x = wid = 0;
        while( fgets( genbuf, STRLEN, fn ) != NULL && x < 65 ) {
            if( strncmp( genbuf, "userid: ", 8 ) == 0 ) {
                move( y++, x );
                prints( genbuf + 8 );
                len = strlen( genbuf + 8 );
                if( len > wid )  wid = len;
                if( y >= t_lines - 2 ) {
                    y = 3;
                    x += wid + 2;
                }
            }
        }
        fclose( fn );
        if(askyn("�趨������",NA,YEA)==YEA) {
            securityreport("�趨ʹ����ע������");
            scan_register_form( fname );
        }
    }
    } else
    {
      move (1,0);
      usercomplete("������Ҫ��ѯ�Ĵ���: ", uident);
      if( uident[0] != '\0' )
         if (!getuser(uident))
           {
                move(2,0);
                prints("�����ʹ���ߴ���...");
           } else
           {         
           sprintf(genbuf,"home/%c/%s/register",toupper(lookupuser.userid[0]),lookupuser.userid) ;
           if ((fn = fopen(genbuf, "r")) != NULL)
            {
                prints("\nע����������:\n\n");
                for (x=1; x<=15; x++) 
                {
                if (fgets(genbuf, STRLEN, fn))
                        prints("%s", genbuf);
                else break;
                }
           } else prints("\n\n�Ҳ�����/����ע������!!\n");
         }
    pressanykey();
    }
    clear();
    return 0;
}

