/*
 * 
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation 
 * bbs, the cross-media distributed communication platform. And it is 
 * developed by Cyberwork Solution in 2000.
 * 
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 * 
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or (at 
 * your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or 
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution.com , Isabel Ho
 *
 */

#include "system_lib.h"

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
#include <fcntl.h>
#include <syslog.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>


int daemon_proc;

static void err_doit(int, int, const char*, va_list);

void sys_log(char *fpath, char *message)
{
	int fd;
  
	if ((fd = open(fpath, O_WRONLY | O_CREAT | O_APPEND, 0600)) >= 0) {
		write(fd, message, strlen(message));
		close(fd);
	}
}

void sys_error(const char *fmt, ...)
{
	va_list	ap;

	va_start(ap, fmt);
	err_doit(1, LOG_ERR, fmt, ap);
	va_end(ap);
}

void sys_err_quit(const char *fmt, ...)
{
	va_list	ap;

	va_start(ap, fmt);
	err_doit(0, LOG_ERR, fmt, ap);
	va_end(ap);
	exit(1);
}

static void err_doit(int errnoflag, int level, const char *fmt, va_list ap)
{
	int		errno_save;
	int		n;
	char	buf[MAXLINE];

	errno_save = errno; /* value caller might want printed */

	vsnprintf(buf, sizeof(buf), fmt, ap); /* this is safe */

	n = strlen(buf);

	if (errnoflag) {
		snprintf(buf + n, sizeof(buf) - n, ": %s", strerror(errno_save));
	}
	strcat(buf, "\n");

	if (daemon_proc) {
		syslog(level, buf);
	}
	else {
		fflush(stdout); /* in case stdout and stderr are the same */
		fputs(buf, stderr);
		fflush(stderr);
	}
	return;
}


