/*
 * 
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation 
 * bbs, the cross-media distributed communication platform. And it is 
 * developed by Cyberwork Solution in 2000.
 * 
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 * 
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or (at 
 * your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or 
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution.com , Isabel Ho
 *
 */

#include "arni_server.h"
#include "w3if.h"

int arni_add_modules()
{
	/* bbs_login */
	arni_module_register("bbs_login", mod_bbs_login);
	arni_module_addarg("bbs_login", "USERID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("bbs_login", "PASSWORD", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("bbs_login", "REMOTE-USERNAME", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("bbs_login", "FROM-HOST", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("bbs_login", "FROM-IP", MRR_SINGLE_TEXTLINE);

	/* bbs_logout */
	arni_module_register("bbs_logout", mod_bbs_logout);

	/* talk_ulist */
	arni_module_register("talk_ulist", mod_talk_ulist);
	arni_module_addarg("talk_ulist", "USERID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("talk_ulist", "PAGETOP", MRR_INTEGER);
	arni_module_addarg("talk_ulist", "PAGESIZE", MRR_INTEGER);
	arni_module_addarg("talk_ulist", "SORT-METHOD", MRR_INTEGER);

	/* talk_sendmsg */
	arni_module_register("talk_sendmsg", mod_talk_sendmsg);
	arni_module_addarg("talk_sendmsg", "TO-PID", MRR_INTEGER);
	arni_module_addarg("talk_sendmsg", "MESSAGE", MRR_SINGLE_TEXTLINE);

	/* talk_recvmsg */
	arni_module_register("talk_recvmsg", mod_talk_recvmsg);

	/* talk_paladd */
	arni_module_register("talk_paladd", mod_talk_paladd);
	arni_module_addarg("talk_paladd", "PAL-ID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("talk_paladd", "FRIENDSHIP", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("talk_paladd", "IS-BAD", MRR_INTEGER);

	/* talk_paldel */
	arni_module_register("talk_paldel", mod_talk_paldel);
	arni_module_addarg("talk_paldel", "PAL-ID", MRR_SINGLE_TEXTLINE);

	/* talk_paledit */
	arni_module_register("talk_paledit", mod_talk_paledit);
	arni_module_addarg("talk_paledit", "PAL-ID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("talk_paledit", "FRIENDSHIP", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("talk_paledit", "IS-BAD", MRR_INTEGER);

	/* talk_query_user */
	arni_module_register("talk_query_user", mod_talk_query_user);
	arni_module_addarg("talk_query_user", "QUERY-ID", MRR_SINGLE_TEXTLINE);

	/* chat_connect */
	arni_module_register("chat_connect", mod_chat_connect);
	arni_module_addarg("chat_connect", "USERID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("chat_connect", "CHATID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("chat_connect", "ACTION", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("chat_connect", "MESSAGE", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("chat_connect", "TYPE", MRR_SINGLE_TEXTLINE);

	/* mail_mbox */
	arni_module_register("mail_mbox", mod_mail_mbox);
	arni_module_addarg("mail_mbox", "USERID", MRR_SINGLE_TEXTLINE);

	/* mail_readmail */
	arni_module_register("mail_readmail", mod_mail_readmail);
	arni_module_addarg("mail_readmail", "USERID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("mail_readmail", "FILENAME", MRR_SINGLE_TEXTLINE);

	/* mail_toggle_mark */
	arni_module_register("mail_toggle_mark", mod_mail_toggle_mark);
	arni_module_addarg("mail_toggle_mark", "USERID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("mail_toggle_mark", "FILENAME", MRR_SINGLE_TEXTLINE);

	/* mail_send_localmail */
	arni_module_register("mail_send_localmail", mod_mail_send_localmail);
	arni_module_addarg("mail_send_localmail", "FROM-ID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("mail_send_localmail", "TO-ID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("mail_send_localmail", "SUBJECT", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("mail_send_localmail", "BODY", MRR_MULTI_TEXTLINE);

	/* mail_send_internetmail */
	arni_module_register("mail_send_internetmail", mod_mail_send_internetmail);
	arni_module_addarg("mail_send_internetmail", "FROM-ID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("mail_send_internetmail", "TO-ADDR", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("mail_send_internetmail", "SUBJECT", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("mail_send_internetmail", "BODY", MRR_MULTI_TEXTLINE);

	/* mail_delete */
	arni_module_register("mail_delete", mod_mail_delete);
	arni_module_addarg("mail_delete", "USERID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("mail_delete", "FILENAME", MRR_SINGLE_TEXTLINE);

	/* mail_delete_range */
	arni_module_register("mail_delete_range", mod_mail_delete_range);
	arni_module_addarg("mail_delete_range", "USERID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("mail_delete_range", "START-FILENAME", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("mail_delete_range", "END-FILENAME", MRR_SINGLE_TEXTLINE);

	/* mail_first_unread_mail */
	arni_module_register("mail_first_unread_mail", mod_mail_first_unread_mail);
	arni_module_addarg("mail_first_unread_mail", "USERID", MRR_SINGLE_TEXTLINE);

	/* brd_class_list */
	arni_module_register("brd_class_list", mod_brd_class_list);
	arni_module_addarg("brd_class_list", "USERID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("brd_class_list", "CHANNEL", MRR_INTEGER);
	arni_module_addarg("brd_class_list", "PAGETOP", MRR_INTEGER);
	arni_module_addarg("brd_class_list", "PAGESIZE", MRR_INTEGER);
	arni_module_addarg("brd_class_list", "MODE", MRR_INTEGER);

	/* brd_plist */
	arni_module_register("brd_plist", mod_brd_plist);
	arni_module_addarg("brd_plist", "BRDID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("brd_plist", "PAGETOP", MRR_INTEGER);
	arni_module_addarg("brd_plist", "PAGESIZE", MRR_INTEGER);

	/* brd_readpost */
	arni_module_register("brd_readpost", mod_brd_readpost);
	arni_module_addarg("brd_readpost", "BRDID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("brd_readpost", "FILENAME", MRR_SINGLE_TEXTLINE);

	/* brd_toggle_mark */
	arni_module_register("brd_toggle_mark", mod_brd_toggle_mark);
	arni_module_addarg("brd_toggle_mark", "BRDID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("brd_toggle_mark", "FILENAME", MRR_SINGLE_TEXTLINE);

	/* brd_forward */
	arni_module_register("brd_forward", mod_brd_forward);
	arni_module_addarg("brd_forward", "USERID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("brd_forward", "TO-ADDR", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("brd_forward", "BRDID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("brd_forward", "FILENAME", MRR_SINGLE_TEXTLINE);

	/* brd_note */
	arni_module_register("brd_note", mod_brd_note);
	arni_module_addarg("brd_note", "BRDID", MRR_SINGLE_TEXTLINE);

	/* user_info_show */
	arni_module_register("user_info_show", mod_user_info_show);

	/* user_passwd_setup */
	arni_module_register("user_passwd_setup", mod_user_passwd_setup);
	arni_module_addarg("user_passwd_setup", "PASSWD", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("user_passwd_setup", "NEW-PASSWD", MRR_SINGLE_TEXTLINE);

	/* user_info_setup */
	arni_module_register("user_info_setup", mod_user_info_setup);
	arni_module_addarg("user_info_setup", "PASSWD", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("user_info_setup", "NEW-USERNAME", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("user_info_setup", "NEW-REALNAME", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("user_info_setup", "NEW-ADDRESS", MRR_SINGLE_TEXTLINE);

	/* user_register */
	arni_module_register("user_register", mod_user_register);
	arni_module_addarg("user_register", "NEW-ID", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("user_register", "NEW-PASSWD", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("user_register", "NEW-USERNAME", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("user_register", "NEW-REALNAME", MRR_SINGLE_TEXTLINE);
	arni_module_addarg("user_register", "NEW-ADDRESS", MRR_SINGLE_TEXTLINE);

	return 0;
}

         
int arni_remove_modules()
{
	arni_module_unregister("bbs_login");
	arni_module_unregister("bbs_logout");
	arni_module_unregister("talk_ulist");
	arni_module_unregister("talk_sendmsg");
	arni_module_unregister("talk_paladd");
	arni_module_unregister("talk_paldel");
	arni_module_unregister("talk_paledit");
	arni_module_unregister("talk_query_user");
	arni_module_unregister("mail_mbox");
	arni_module_unregister("mail_readmail");
	arni_module_unregister("mail_toggle_mark");
	arni_module_unregister("mail_send_localmail");
	arni_module_unregister("mail_send_internetmail");
	arni_module_unregister("mail_delete");
	arni_module_unregister("mail_delete_range");
	arni_module_unregister("mail_first_unread_mail");
	arni_module_unregister("brd_class_list");
	arni_module_unregister("brd_plist");
	arni_module_unregister("brd_readpost");
	arni_module_unregister("brd_toggle_mark");
	arni_module_unregister("brd_forward");
	arni_module_unregister("brd_note");
	arni_module_unregister("chat_connect");
	arni_module_unregister("user_info_show");
	arni_module_unregister("user_passwd_setup");
	arni_module_unregister("user_info_setup");
	arni_module_unregister("user_register");

	return 0;
}

