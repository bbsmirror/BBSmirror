/*
 * 
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation 
 * bbs, the cross-media distributed communication platform. And it is 
 * developed by Cyberwork Solution in 2000.
 * 
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 * 
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or (at 
 * your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or 
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution.com , Isabel Ho
 *
 */
                               
#undef   DEBUG_LIVE_SERVER

#include "live_server.h"
#include "system_lib.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>


/*
 *  live module routines
 */

struct LIVE_MODULE	live_modules = { 0 };


int live_module_register(char *mod_name, void *mod_fptr)
{
	struct LIVE_MODULE_ENTRY	*pmd = 0;
	struct LIVE_MODULE_ENTRY	*modent;

#ifdef DEBUG_LIVE_SERVER
	DEBUG_PRINT3("DEBUG(%s,%d): register module: %s\n",
	        __FILE__, __LINE__, mod_name);
#endif /* DEBUG_LIVE_SERVER */

	if (live_modules.mods) {
		for (pmd = live_modules.mods; pmd->next; pmd = pmd->next)
			;
	}

	if (!(modent = (struct LIVE_MODULE_ENTRY*)
 	               malloc(sizeof(struct LIVE_MODULE_ENTRY)))) {
		return -999;
	}
	memset(modent, 0, sizeof(struct LIVE_MODULE_ENTRY));

	if (!(modent->name = (char*)
                         malloc(sizeof(char) *
                                (strlen(mod_name) + 1)))) {
		free(modent->next);
		modent->next = 0;
		return -999; /* cannot allocate memory */
	}
	if (pmd) {
		pmd->next = modent;
	}
	else {
		live_modules.mods = modent;
	}
	strcpy(modent->name, mod_name);
	modent->fptr = mod_fptr;

#ifdef DEBUG_LIVE_SERVER

	DEBUG_PRINT3("DEBUG(%s,%d): module %s registered.\n",
	        __FILE__, __LINE__, mod_name);

#endif /* DEBUG_LIVE_SERVER */

	return 0;
}


int live_module_addarg(char *mod_name, char *arg_name, int arg_type)
{
	struct LIVE_MODULE_ENTRY	*modent;

#ifdef DEBUG_LIVE_SERVER
	DEBUG_PRINT4("DEBUG(%s,%d): add arg %s into %s\n",
	        __FILE__, __LINE__, arg_name, mod_name);
#endif /* DEBUG_LIVE_SERVER */

	for (modent = live_modules.mods; modent; modent = modent->next) {
		if (!strcmp(modent->name, mod_name)) {
			break; /* for (modent) */
		}
	}
	if (!modent) {
		return 999; /* cannot find module */
	}

	if (modent->narg >= LIVE_MAX_ARGS) {
		return 999; /* cannot add more arg */
	}

	if (!(modent->args[modent->narg].name = (char*)malloc(sizeof(char) *
	                                        (strlen(arg_name) + 1)))) {
		return -999; /* cannot allocate memory */
	}
	strcpy(modent->args[modent->narg].name, arg_name);
	modent->args[modent->narg].type = arg_type;
	++(modent->narg);

	return 0;
}


int live_module_unregister(char *mod_name)
{
	struct LIVE_MODULE_ENTRY	*modprv;
	struct LIVE_MODULE_ENTRY	*modent;

#ifdef DEBUG_LIVE_SERVER
	DEBUG_PRINT3("DEBUG(%s,%d): unregister module %s\n",
	        __FILE__, __LINE__, mod_name);
#endif /* DEBUG_LIVE_SERVER */

	for (modprv = 0, modent = live_modules.mods;
	     modent;
	     modprv = modent, modent = modent->next) {
		if (!strcmp(modent->name, mod_name)) {
			break;
		}
	}
	if (!(modent)) {
		return 999; /* cannot find module */
	}

	if (modprv) {
		modprv = modent->next;
	}

	free(modent->name);
	free(modent);
	return 0;
}

#if 0 /* JeffHung.20001107: unused */

/*
 *  IO routines
 */

static int send_response(int fd, char *msg)
{
	int		len;
	char	*buf;

	len = strlen(msg);
	buf = (char*)malloc(sizeof(char) * (len + 2));
	strcpy(buf, msg);
	/* make sure with a padding '\n' */
	if (msg[len - 1] != '\n') {
		buf[len++] = '\n';
	}
	buf[len++] = '\0';

	return send(fd, (void*)buf, len, 0);
}

#endif /* 0 */


/*
 *  MRR parsing routines
 */

struct MRR_REQUEST_ARG {
	char	*name;
	char	*val;
};

struct MRR_REQUEST {
	char					*name;
	int						narg;
	struct MRR_REQUEST_ARG	args[LIVE_MAX_ARGS];
	struct MRR_REQUEST		*next;
};

static int purgeMrrRequest(struct MRR_REQUEST **preqs)
{
	struct MRR_REQUEST	*pr;
	int					i;

	while (*preqs) {
		pr = *preqs;
		*preqs = (*preqs)->next;
		if (pr->name) {
			free(pr->name);
		}
		for (i = 0; i < LIVE_MAX_ARGS; ++i) {
			if (pr->args[i].name) {
				free(pr->args[i].name);
			}
			if (pr->args[i].val) {
				free(pr->args[i].val);
			}
		}
		free(pr);
	}

	return 0;
}

#if 0
static int mrr_parse(struct MRR_REQUEST **preqs, int fd)
#endif
/*  Arlo.20000905
 *  �ĳɱ���check��û��session id û�о�ban��
 *  ��return session id
 */

static char *mrr_parse(struct MRR_REQUEST **preqs, int fd)
{
	int						n; /* generic n */
	char					buf[BUF_SIZE]; /* generic buffer */
	int						readin_size = 0; /* # of bytes read in from fd */
	int						ml_haserror = 0; /* has error in MRR line */
	int						ml_totallen = 0; /* MRR line total length */
	int						ml_namelen = 0; /* MRR line command length */
	int						ml_vallen = 0; /* MRR line value length */
	int						ml_tmpvallen = 0; /* MRR line temp value length */
	int						ml_done = 0;
	struct MRR_REQUEST_ARG	reqarg;
	char					*pval;
	int						ml_type;
	struct MRR_REQUEST		req; /* MRR request now */
	int						done = 0;
	struct MRR_REQUEST		*preq = 0;
	int						retval = 0;

/* session id */
  static char sid[32+1];

  memset( sid , 0 , (32+1) );
	memset(&reqarg, 0, sizeof(struct MRR_REQUEST_ARG));
	memset(&req, 0, sizeof(struct MRR_REQUEST));

	while (1) {
		if (ml_done) {
			if (reqarg.name) {
				ml_type = strcasecmp(MRR_CMD_CONTINUE, reqarg.name) ? 0 : 1;
        ml_type += strcasecmp(MRR_CMD_SID, reqarg.name) ? 0 : 2;
				ml_type += strcasecmp(MRR_CMD_REQUEST, reqarg.name) ? 0 : 3;
				ml_type += strcasecmp(MRR_CMD_END, reqarg.name) ? 0 : 4;
				if ((ml_type > 2) && req.name) {
					if (*preqs) {
						for (preq = *preqs; preq->next; preq = preq->next)
							;
						preq = preq->next = (struct MRR_REQUEST*)
						                    malloc(sizeof(struct MRR_REQUEST));
					}
					else {
						preq = *preqs = (struct MRR_REQUEST*)
						              malloc(sizeof(struct MRR_REQUEST));
					}
					memcpy(preq, &req, sizeof(struct MRR_REQUEST));
				}

				switch (ml_type) {
				  case 4: /* MRR_CMD_END */
					  done = 1;
            /*
             * Arlo:���ֵط���goto�����Ư����(���Ǳ�������..) 
             */
					  goto final_proc;

				  case 3: /* MRR_CMD_REQUEST */
					  memset(&req, 0, sizeof(struct MRR_REQUEST));
						free(reqarg.name);
					  reqarg.name = 0;
						req.name = reqarg.val;
					  
						break;
				  case 2: /* MRR_CMD_SID */
            strncpy( sid , reqarg.val , 32);
						sid[32] = '\0';
						free(reqarg.name);
						free(reqarg.val);
            reqarg.name = 0;
						reqarg.val = 0;
						break;

				  case 1: /* MRR_CMD_CONTINUE */
					  if (req.name && req.narg) {
						  /* JeffHung.20000821: reuse ml_namelen, ml_vallen */
						  ml_namelen = strlen(req.args[req.narg - 1].val);
						  ml_vallen = strlen(reqarg.val);
						  req.args[req.narg].val =
						      (char*)realloc(req.args[req.narg - 1].val,
							                   ml_namelen + ml_vallen + 2);
						  req.args[req.narg - 1].val[ml_namelen] = '\n';
						  strcpy(req.args[req.narg - 1].val + ml_namelen + 1,
						         reqarg.val);
					  }
						free(reqarg.name);
					  free(reqarg.val);
						reqarg.name = 0;
						reqarg.val = 0;
					  break;
				  default:
					  if (req.name) {
						  if (req.narg < LIVE_MAX_ARGS) {
								req.args[req.narg].name = reqarg.name;
							  req.args[req.narg].val = reqarg.val;
							  ++(req.narg);
				  		}
					  	else {
						  	free(reqarg.name);
 	 					  	free(reqarg.val);
    						reqarg.name = 0;
    						reqarg.val = 0;
					  	}
					  } /* if(req.name) */
					  break;
				} /* switch (ml_tppe) */
			} /* if (reqarg.name) */
			memset(&reqarg, 0, sizeof(struct MRR_REQUEST_ARG));
			ml_vallen = 0;
		}

		if ((n = sys_readline(fd, buf, BUF_SIZE)) < 0) {
			retval = -999; /* readline error */
			break;
		}

		if (!n) {

#ifdef	DEBUG_LIVE_SERVER
			DEBUG_PRINT2("DEBUG(%s,%d): EOF\n", __FILE__, __LINE__);
#endif	/* DEBUG_LIVE_SERVER */

			break; /* n == 0: EOF, normal ending */
		}

		if ((readin_size += n) >= MAX_SIZE) {
			retval = -999; /* input exceed limit */
			break;
		}

		ml_done = 0;

		if (done) {
#if 1
			break;
#else /* 1 */
			continue; /* eat all the rest stuffs */
#endif /* 1 */
		}

		if (ml_haserror) {
			if (strpbrk(buf, "\n\r")) {
				/* end of thie MRR line */
				ml_haserror = 0;
				ml_done = 1;
			}
			continue; /* eat the rest stuffs */
		}

		ml_totallen = n - 1;
		while ((buf[ml_totallen] == '\n') || (buf[ml_totallen] == '\r')) {
			ml_done = 1;
			/* trim trailing newlines */
			buf[ml_totallen--] = 0;
		}
		++ml_totallen;

		if (!(reqarg.name)) {
			if (!(pval = strchr(buf, (int)':'))) {
				ml_haserror = 1;
				continue; /* eat the rest stuff */
			}
			*pval = 0;
			++pval;
			ml_namelen = strlen(buf);
			reqarg.name = (char*)malloc(sizeof(char) * (ml_namelen + 1));
			strcpy(reqarg.name, buf);
			ml_tmpvallen = ml_totallen - ml_namelen - 1;
		}
		else {
			pval = buf;
			ml_tmpvallen = ml_totallen;
		}
		reqarg.val = (char*)realloc(reqarg.val, sizeof(char) *
		                                        (ml_vallen + ml_tmpvallen + 1));
		strcpy(reqarg.val + ml_vallen, pval);
		ml_vallen += ml_tmpvallen;

#ifdef	DEBUG_LIVE_SERVER
		DEBUG_PRINT3("DEBUG(%s,%d): reqarg.name: %s\n",
		        __FILE__, __LINE__, reqarg.name);
		DEBUG_PRINT3("DEBUG(%s,%d): reqarg.val: %s\n",
		        __FILE__, __LINE__, reqarg.val);
#endif	/* DEBUG_LIVE_SERVER */

	} /* while (1) */

/*
 * �����һЩfree��process 
 */
final_proc:

	if (reqarg.name) {
		free(reqarg.name);
	}
	if (reqarg.val) {
		free(reqarg.val);
	}
#if 0 /*����..����..����free...*/
	if (req.name) {
		free(req.name);
	}
#endif

	return sid;
}

static int mrr_process(int ofd, char *sid, struct MRR_REQUEST *req, USER_INFO *user_info_pool)
{
	struct LIVE_MODULE_ENTRY  *pmd;
	struct LIVE_ARGS          args;
	int                       i;
  int                       match_request;
	
	/* find corresponding module */

	for (pmd = live_modules.mods; pmd; pmd = pmd->next) {
		if (!strcasecmp(pmd->name, req->name)) {
			break;
		}
	}

	if (!pmd) {
		return 999; /* cannot find module */
	}

	memset(&args, 0, sizeof(struct LIVE_ARGS));

	/* fill up module parameters */
	for (args.narg = 0 , match_request = 0 ; args.narg < pmd->narg; ++(args.narg)) {
		/* scan req and find the corresponding parameter */
		for (i = 0; i < req->narg; ++i) {
			if (!strcasecmp(pmd->args[args.narg].name, req->args[i].name)) {
			  /* ���match��.�Ͱ�counter��һ */
				match_request++;
				/* now we got the corresponding parameter */
				switch (pmd->args[args.narg].type) {
				  case MRR_SINGLE_TEXTLINE:
				  	/* FALLTHROUGH */
				  case MRR_MULTI_TEXTLINE:
			  		/* FALLTHROUGH */
				  case MRR_DATETIME:
					  /* FALLTHROUGH */
				  case MRR_FILENAME:
				  	args.args[args.narg].s = req->args[i].val;
				  	break;
				  case MRR_INTEGER:
				  	args.args[args.narg].i = atoi(req->args[i].val);
					  break;
				  default:
					  return - 999; /* request parameter type not match */
				}
				break; /* for (i) */
			} /* if (found the corresponding parameter) */
		} /* for (i) */
		if (i >= req->narg) {
			return -999; /* no request parameter matched */
		}
	} /* for (args.narg) */

  /* Arlo.20000905
	 * check ��������request�㲻�㹻 
	 */

	if( match_request < pmd->narg ) {
		return -999;
	}
#ifdef DEBUG_LIVE_SERVER
  fprintf(stderr , "pre starting module...\n");
#endif
	/* run the module and return */
	return (pmd->fptr)(ofd, sid , user_info_pool, &args);
}


int live_server(int fd, USER_INFO *user_info_pool)
{
  char *sid;
	struct MRR_REQUEST	*reqs = 0;
	struct MRR_REQUEST	*req;

	/* phase 1: parse input and stored in reqs */
	sid = mrr_parse(&reqs, fd);

#ifdef	DEBUG_LIVE_SERVER

	if (reqs) {
		struct MRR_REQUEST	*pr;
		int					ii;
		int					jj;

		for (pr = reqs, ii = 0; pr; pr = pr->next, ++ii) {
			DEBUG_PRINT3("DEBUG(%s,%d): ii:%d\n", __FILE__, __LINE__, ii);
			if (!pr->name) {
			}
			DEBUG_PRINT3("DEBUG(%s,%d): reqs->name: %s\n",
							__FILE__, __LINE__, pr->name);
			DEBUG_PRINT3("DEBUG(%s,%d): reqs->narg: %d\n",
							__FILE__, __LINE__, pr->narg);
			for (jj = 0; jj < pr->narg; ++jj) {
				DEBUG_PRINT3("DEBUG(%s,%d): args[%d]\n",
								__FILE__, __LINE__, jj);
				DEBUG_PRINT3("DEBUG(%s,%d): args->name: %s\n",
								__FILE__, __LINE__, pr->args[jj].name);
				DEBUG_PRINT3("DEBUG(%s,%d): args->val: %s\n",
								__FILE__, __LINE__, pr->args[jj].val);
			}
		}
	}
	else {
		DEBUG_PRINT2("DEBUG(%s,%d):reqs==NULL\n", __FILE__, __LINE__);
	}

#endif	/* DEBUG_LIVE_SERVER */
	/* phase 2: process mrr requests */
	for (req = reqs; req; req = req->next) {
		mrr_process(fd, sid, req,user_info_pool);
	}

	purgeMrrRequest(&reqs);

	return 0;
}



