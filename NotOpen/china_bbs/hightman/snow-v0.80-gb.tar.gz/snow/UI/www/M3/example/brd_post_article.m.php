<FORM METHOD="POST" ACTION="" onSubmit="alert('not implement yet'); return false;">
	<INPUT TYPE="hidden" NAME="iAuthorID" VALUE="<?php echo $sUserID; ?>">
	<INPUT TYPE="hidden" NAME="iBoardID" VALUE="<?php echo $iBoardID; ?>">
	<P>
		���ߣ�<?php echo query_user_link($sUserID, $sUserID); ?> (<?php echo query_user_link($UserID, $sUserName); ?>)<BR>
		��������<?php echo $iBoardID; ?><BR>
		���±��⣺<INPUT TYPE="text" NAME="iSubject">
	</P>
	<P><B>Attention!! not implement yet.</B></P>
	<P> 
		<TEXTAREA NAME="iBody" COLS="80" ROWS="24"></TEXTAREA>
	</P>
	<P> 
		<INPUT TYPE="submit" VALUE="��������">
	</P>
</FORM>