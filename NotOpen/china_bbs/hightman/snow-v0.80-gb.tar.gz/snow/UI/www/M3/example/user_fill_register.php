<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("��дע�ᵥ");

$SNOW_PAGE_TITLE = "��дע�ᵥ";
$SNOW_PAGEAREA_MAIN = "user_fill_register.m.php";
$SNOW_PAGEAREA_FUNC = "user_fill_register.f.php";

include("bone.php");

?>