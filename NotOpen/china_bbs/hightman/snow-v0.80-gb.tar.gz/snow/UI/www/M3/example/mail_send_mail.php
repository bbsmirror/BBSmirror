<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�����ż�");

$SNOW_PAGE_TITLE = "�����ż�";
$SNOW_PAGEAREA_MAIN = "mail_send_mail.m.php";
$SNOW_PAGEAREA_FUNC = "mail_send_mail.f.php";

include("bone.php");

?>