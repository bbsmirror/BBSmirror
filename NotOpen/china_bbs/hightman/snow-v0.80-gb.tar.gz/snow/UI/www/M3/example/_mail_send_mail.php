<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();

SESSIONcache("sUserID");
SESSIONcache("sUserName");

if (strstr($iTo, "@") == false) {
	// local mail
	$mrr = array(
		"mail_send_localmail" => array(
			0 => array(
				"MRR-SID" => array(0 => session_id()),
				"FROM-ID" => array(0 => $sUserID),
				"TO-ID" => array(0 => $iTo),
				"SUBJECT" => array(0 => $iSubject),
				"BODY" => explode("\n", $iBody)
			)
		)
	);

}
else {
	// internet mail
	$mrr = array(
		"mail_send_internetmail" => array(
			0 => array(
				"MRR-SID" => array(0 => session_id()),
				"FROM-ID" => array(0 => $sUserID),
				"TO-ADDR" => array(0 => $iTo),
				"SUBJECT" => array(0 => $iSubject),
				"BODY" => explode("\n", $iBody)
			)
		)
	);
}
$result = MRRquery($mrr);

$goPage = HISTORYget(1); // 0: д���Ǹ�page��1:д��ǰ�Ǹ�page��
$redirect = sprintf("Location: %s", $goPage["URI"]);
header($redirect);
exit();

?>