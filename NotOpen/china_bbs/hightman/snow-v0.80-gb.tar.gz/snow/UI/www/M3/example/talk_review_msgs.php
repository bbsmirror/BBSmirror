<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�ع�ѶϢ");

$SNOW_PAGE_TITLE = "�ع�ѶϢ";
$SNOW_PAGEAREA_MAIN = "talk_review_msgs.m.php";
$SNOW_PAGEAREA_FUNC = "talk_review_msgs.f.php";

include("bone.php");

?>