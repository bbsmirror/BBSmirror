<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("���ע�ᵥ");

/*
 * Required Inputs: (none)
 */

$SNOW_PAGE_TITLE = "���ע�ᵥ";
$SNOW_PAGEAREA_MAIN = "admin_check_registers.m.php";
$SNOW_PAGEAREA_FUNC = "admin_check_registers.f.php";

include("bone.php");

?>