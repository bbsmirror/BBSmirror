<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�ҵ�����");

$mrr = array(
	"mail_mbox" => array(
		0 => array(
			"USERID" => array(0 => $sUserID)
		)
	)
);

$result = MRRquery($mrr);

$SNOW_PAGE_TITLE = "�ҵ�����";
$SNOW_PAGEAREA_MAIN = "mail_mbox.m.php";
$SNOW_PAGEAREA_FUNC = "mail_mbox.f.php";

include("bone.php");

?>