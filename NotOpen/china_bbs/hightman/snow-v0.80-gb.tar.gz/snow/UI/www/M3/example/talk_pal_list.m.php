<FORM METHOD="post" ACTION="">
	<P> 
		<INPUT TYPE="BUTTON" NAME="Submit4" VALUE="��һҳ">
		<INPUT TYPE="BUTTON" NAME="Submit5" VALUE="��һҳ">
		<INPUT TYPE="BUTTON" NAME="Submit6" VALUE="��һҳ">
		<INPUT TYPE="BUTTON" NAME="Submit7" VALUE="��ĩҳ">
		ֱ�ӵ��� 
		<SELECT NAME="select2">
			<OPTION VALUE="1" SELECTED>1</OPTION>
			<OPTION VALUE="2">2</OPTION>
		</SELECT>
		ҳ</P>
	<TABLE WIDTH="100%" BORDER="1">
		<TR> 
			<TH>���</TH>
			<TH>����</TH>
			<TH>����/����</TH>
			<TH>����</TH>
		</TR>
		<TR> 
			<TD>1
				<INPUT TYPE="radio" NAME="radiobutton" VALUE="radiobutton">
			</TD>
			<TD><A HREF="talk_query_user.php">Arlo</A></TD>
			<TD>��</TD>
			<TD>����</TD>
		</TR>
		<TR> 
			<TD>2
				<INPUT TYPE="radio" NAME="radiobutton" VALUE="radiobutton">
			</TD>
			<TD><A HREF="talk_query_user.php">JeffHung</A></TD>
			<TD>��</TD>
			<TD>����</TD>
		</TR>
		<TR> 
			<TD>3
				<INPUT TYPE="radio" NAME="radiobutton" VALUE="radiobutton">
			</TD>
			<TD><A HREF="talk_query_user.php">Kevin</A></TD>
			<TD>��</TD>
			<TD>�Թ�</TD>
		</TR>
	</TABLE>
    <P>
		<INPUT TYPE="BUTTON" NAME="Submit42" VALUE="��һҳ">
		<INPUT TYPE="BUTTON" NAME="Submit52" VALUE="��һҳ">
		<INPUT TYPE="BUTTON" NAME="Submit62" VALUE="��һҳ">
		<INPUT TYPE="BUTTON" NAME="Submit72" VALUE="��ĩҳ">
		ֱ�ӵ��� 
		<SELECT NAME="select3">
			<OPTION VALUE="1" SELECTED>1</OPTION>
			<OPTION VALUE="2">2</OPTION>
		</SELECT>
		ҳ</P>
</FORM>