<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();

SESSIONcache("sUserID");
SESSIONcache("sUserName");

$mrr = array(
	"mail_delete" => array(
		0 => array(
			"USERID" => array(0 => $sUserID),
			"FILENAME" => array(0 => $iFilename),
		)
	)
);
$result = MRRquery($mrr);

$goPage = HISTORYget(0);
$redirect = sprintf("Location: %s", $goPage["URI"]);
header($redirect);
exit();

?>