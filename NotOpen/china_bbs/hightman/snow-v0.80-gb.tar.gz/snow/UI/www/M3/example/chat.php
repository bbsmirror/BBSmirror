<?php

$mrr = array(
	"chat_client" => array(
		0 => array(
		// ...
			"BRDID" => array(0 => $iBoardID),
			"PAGETOP" => array(0 => $iPageTop),
			"PAGESIZE" => array(0 => $iPageSize)
		)
	)
);

$result = MRRquery($mrr);
Header("Content-type: application/x-javascript");

?>

addChatMessage(new Array(
<?php

for ($i = 0; $i < $result["chat_client"]; ++$i) {
	printf("%s\"\"", (($i != 0) ? "," : ""), $result["chat_client"][$i]["MESSAGE"][0]);
}

?>
));

