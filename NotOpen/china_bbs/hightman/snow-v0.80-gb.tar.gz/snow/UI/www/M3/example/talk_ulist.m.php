<SCRIPT LANGUAGE="JavaScript">
<!--

<?php

$max = $result["talk_ulist_max"][0]["MAX"][0];
debug_print($max);

?>

// ����һҳ
function pg2first()
{
	document.fPageChanger.iPageTop.value = "1";
	document.fPageChanger.submit();
}

// ����һҳ
function pg2prev()
{
	<?php if ($iPageTop > $iPageSize) { ?>
	document.fPageChanger.iPageTop.value = <?php
	$prevPage = $iPageTop - $iPageSize;
	printf("\"%d\"", $iPageTop - $iPageSize);
	?>;
	<?php } ?>
	document.fPageChanger.submit();
}

// ����һҳ
function pg2next()
{
	<?php if (($max - $iPageTop) > $iPageSize) { ?>
	document.fPageChanger.iPageTop.value = <?php
	$nextPage = $iPageTop + $iPageSize;
	printf("\"%d\"", $iPageTop + $iPageSize);
	?>;
	<?php } ?>
	document.fPageChanger.submit();
}

// ����ĩҳ
function pg2last()
{
	document.fPageChanger.iPageTop.value = <?php
	printf("\"%d\"", floor($max / $iPageSize) * $iPageSize + 1);
	?>;
	document.fPageChanger.submit();
}

function pg2go()
{
	document.fPageChanger.iPageTop.value = document.fPageChanger.iDirectGo.options[document.fPageChanger.iDirectGo.selectedIndex].value;
	document.fPageChanger.submit();
}

//-->
</SCRIPT>
<FORM METHOD="POST" NAME="fPageChanger" ACTION="talk_ulist.php">
	<INPUT TYPE="hidden" NAME="iPageTop" VALUE="<?php echo $iPageTop; ?>">
	<INPUT TYPE="hidden" NAME="iPageSize" VALUE="<?php echo $iPageSize; ?>">
	<P>����ģʽ��
		<SELECT NAME="iSortMethod" onChange="document.fPageChanger.iSortMethod2.selectedIndex = document.fPageChanger.iSortMethod.selectedIndex;">
			<OPTION VALUE="RANDOM" SELECTED>����</OPTION>
			<OPTION VALUE="ID">����</OPTION>
			<OPTION VALUE="FROM">��Դ</OPTION>
			<OPTION VALUE="MODE">��̬</OPTION>
			<OPTION VALUE="FRIEND">����</OPTION>
		</SELECT>
		<INPUT TYPE="button" VALUE="��һҳ" onClick="pg2first();">
		<INPUT TYPE="button" VALUE="��һҳ" onClick="pg2prev();">
		<INPUT TYPE="button" VALUE="��һҳ" onClick="pg2next();">
		<INPUT TYPE="button" VALUE="��ĩҳ" onClick="pg2last();">
		ֱ�ӵ��� 
		<SELECT NAME="iDirectGo" onChange="document.fPageChanger.iDirectGo2.selectedIndex = document.fPageChanger.iDirectGo.selectedIndex;">
		<?php

		for ($i = 0; $i < ceil($max / $iPageSize); ++$i) {
			printf("<OPTION VALUE=\"%d\"%s>%d</OPTION>\n",
			       $iPageSize * $i + 1,
				   ((($iPageSize * $i + 1) == $iPageTop) ? " SELECTED" : ""),
				   $i + 1);
		}
		
		?>
		</SELECT>
		ҳ
		<INPUT TYPE="button" VALUE="Go" onClick="pg2go();">
	</P>
	<TABLE WIDTH="100%" BORDER="1">
		<TR> 
			<TH>���</TH>
			<TH>C</TH>
			<TH>P</TH>
			<TH>����</TH>
			<TH>�ǳ�</TH>
			<TH>����</TH>
			<TH>��̬</TH>
			<TH>����</TH>
		</TR>
		<?php

		$ulist = $result["talk_ulist"];
		printf("<!-- %s -->\n", serialize($ulist));

		for ($i = 0; $i < count($ulist); ++$i) {
			printf("<TR>\n");
			printf("<TD>%d <INPUT TYPE=\"radio\" NAME=\"iItem\" VALUE=\"%s\"></TD>\n",
			       $iPageTop + $i, $ulist[$i]["PID"][0]);
			printf("<TD>*</TD>\n");
			printf("<TD>&nbsp;</TD>\n");
			printf("<TD>%s</TD>\n",
			       query_user_link($ulist[$i]["USERID"][0], $ulist[$i]["USERID"][0]));
			printf("<TD>%s</TD>\n", $ulist[$i]["USERNAME"][0]);
			printf("<TD>%s</TD>\n", $ulist[$i]["FROM"][0]);
			printf("<TD>%s</TD>\n", $ulist[$i]["MODE"][0]);
			printf("<TD>%s</TD>\n", $ulist[$i]["IDLE-TIME"][0]);
			printf("</TR>\n");
		}

		?>
	</TABLE>
	<P>����ģʽ�� 
		<SELECT NAME="iSortMethod2" onChange="document.fPageChanger.iSortMethod.selectedIndex = document.fPageChanger.iSortMethod2.selectedIndex;">
			<OPTION VALUE="RANDOM" SELECTED>����</OPTION>
			<OPTION VALUE="ID">����</OPTION>
			<OPTION VALUE="FROM">��Դ</OPTION>
			<OPTION VALUE="MODE">��̬</OPTION>
			<OPTION VALUE="FRIEND">����</OPTION>
		</SELECT>
		<INPUT TYPE="button" VALUE="��һҳ" onClick="pg2first();">
		<INPUT TYPE="button" VALUE="��һҳ" onClick="pg2prev();">
		<INPUT TYPE="button" VALUE="��һҳ" onClick="pg2next();">
		<INPUT TYPE="button" VALUE="��ĩҳ" onClick="pg2last();">
		ֱ�ӵ��� 
		<SELECT NAME="iDirectGo2" onChange="document.fPageChanger.iDirectGo.selectedIndex = document.fPageChanger.iDirectGo2.selectedIndex;">
		<?php

		for ($i = 0; $i < ceil($max / $iPageSize); ++$i) {
			printf("<OPTION VALUE=\"%d\"%s>%d</OPTION>\n",
			       $iPageSize * $i + 1,
				   ((($iPageSize * $i + 1) == $iPageTop) ? " SELECTED" : ""),
				   $i + 1);
		}
		
		?>
		</SELECT>
		ҳ
		<INPUT TYPE="button" VALUE="Go" onClick="pg2go();">
	</P>
</FORM>
<SCRIPT LANGUAGE="JavaScript">
<!--

function selectedRadio()
{
	var i;
	var o;

	for (i = 0; i < document.fPageChanger.iItem.length; ++i) {
		if (document.fPageChanger.iItem[i].checked) {
			return document.fPageChanger.iItem[i];
		}
	}
	return false;
}

function sendMessage()
{
	var o = selectedRadio();

	if (o != false) {
		alert(o.value);
		document.fMessagePack.iToPID.value = o.value;
		return true;
	}
	return false;
}

//-->
</SCRIPT>
<FORM METHOD="POST" NAME="fMessagePack" ACTION="_talk_sendmsg.php" onSubmit="return sendMessage();">
	<INPUT TYPE="hidden" NAME="iToPID" VALUE="">
	ѶϢ���ݣ�<INPUT TYPE="text" NAME="iMessage" VALUE="">
	<INPUT TYPE="submit" VALUE="�ͳ�">
</FORM>