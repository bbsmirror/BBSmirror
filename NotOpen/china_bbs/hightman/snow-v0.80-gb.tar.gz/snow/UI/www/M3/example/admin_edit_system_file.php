<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�༭ϵͳ����");

/*
 * Required Inputs: iSysFilename
 */

$SNOW_PAGE_TITLE = "�༭ϵͳ����";
$SNOW_PAGEAREA_MAIN = "admin_edit_system_file.m.php";
$SNOW_PAGEAREA_FUNC = "admin_edit_system_file.f.php";

include("bone.php");

?>