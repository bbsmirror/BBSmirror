<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
SESSIONcache("SNOW_CHATCACHE");

$mrr = array(
	"chat_connect" => array(
		0 => array(
			// ...
			"MRR-SID" => array(0 => session_id()),
			"USERID" => array(0 => $sUserID),
			"CHATID" => array(0 => $iChatID),
			"ACTION" => array(0 => "enter"),
			"MESSAGE" => array(0 => $iPassword),
			"TYPE" => array(0 => "chat")
		)
	)
);

$result = MRRquery($mrr);

?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE>������</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=gb2312">
<META NAME="Generator" CONTENT="">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
<STYLE TYPE="text/css">
<!--

a:link		{	color: blue;	text-decoration: none;	}
a:visited	{	color: blue;	text-decoration: none;	}
a:hover		{	color: red;		text-decoration: none;	}
a:active	{	color: red;		text-decoration: none;	}

-->
</STYLE>
</HEAD>

<!-- <?php echo $iPassword; ?> -->
<FRAMESET ROWS="*,100">
	<FRAME SRC="chatarea.php?iChatID=<?php echo $iChatID; ?>" NAME="area">
	<FRAME SRC="chatbar.php?iChatID=<?php echo $iChatID; ?>" NAME="bar">
</FRAMESET>
</HTML>
