<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=gb2312">
<META NAME="Generator" CONTENT="">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
<STYLE TYPE="text/css">
<!--

a:link		{	color: blue;	text-decoration: none;	}
a:visited	{	color: blue;	text-decoration: none;	}
a:hover		{	color: red;		text-decoration: none;	}
a:active	{	color: red;		text-decoration: none;	}

-->
</STYLE>
</HEAD>

<BODY BGCOLOR="white">

<FORM METHOD="POST" NAME="fChatBar" ACTION="">
	����ѶϢ��
	<INPUT TYPE="text" NAME="iChatMessage" VALUE="">
	<INPUT TYPE="button" VALUE="�ͳ�" onClick="top.area.sendChatMessage(document.fChatBar.iChatMessage.value);">
</FORM>

<?php //phpinfo(); ?>
</BODY>
</HTML>
