<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("��վ");

$SNOW_PAGE_TITLE = "��վ";
$SNOW_PAGEAREA_MAIN = "bbs_goodbye.m.php";
$SNOW_PAGEAREA_FUNC = "bbs_goodbye.f.php";

include("bone.php");

?>