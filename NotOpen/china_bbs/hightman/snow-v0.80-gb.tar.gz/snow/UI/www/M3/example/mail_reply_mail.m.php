<?php

$rmail = $result["mail_readmail"][0];

?>
<FORM METHOD="POST" ACTION="_mail_send_mail.php">
	<P>�����ˣ�<A HREF="talk_query_user.php"><?php echo $sUserID ?></A> (<?php echo $sUserName; ?>)<BR>
		�����ˣ� 
		<INPUT TYPE="text" NAME="iTo" VALUE="<?php echo $rmail["AUTHOR-ID"][0] ?>">
		<BR>
		���±��⣺ 
		<INPUT TYPE="text" NAME="iSubject" VALUE="<?php
		
		if (substr($rmail["SUBJECT"][0], 0, 4) != "Re: ") {
			echo "Re: ";
		}
		echo $rmail["SUBJECT"][0];

		?>">
	</P>
	<P> 
		<TEXTAREA NAME="iBody" COLS="80" ROWS="24"><?php

		printf("�� ������%s (%s)��֮���ԣ�\n", $rmail["AUTHOR-ID"][0], $rmail["AUTHOR-NAME"][0]);
		for ($i = 0; $i < count($rmail["BODY"]); ++$i) {
			if (chop($rmail["BODY"][$i]) == "") {
				continue; // skip empty line
			}
			printf("&gt; %s\n", htmlspecialchars($rmail["BODY"][$i]));
		}
		
		?>
		</TEXTAREA>
	</P>
	<P> 
		<INPUT TYPE="submit" VALUE="�ĳ��ż�">
	</P>
</FORM>