<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();

SESSIONcache("sUserID");
SESSIONcache("sUserName");

$mrr = array(
	"user_passwd_setup" => array(
		0 => array(
			"MRR-SID" => array(0 => session_id()),
			"PASSWD" => array(0 => $iOldPassword),
			"NEW-PASSWD" => array(0 => $iNewPassword),
		)
	)
);
$result = MRRquery($mrr);

$goPage = HISTORYget(0);
$redirect = sprintf("Location: %s", $goPage["URI"]);
header($redirect);
exit();

?>