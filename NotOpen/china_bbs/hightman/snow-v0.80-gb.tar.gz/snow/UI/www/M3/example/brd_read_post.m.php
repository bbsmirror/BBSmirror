<FORM METHOD="post" ACTION="">
	<P> 
		<SELECT NAME="select2">
			<OPTION VALUE="NORMAL" SELECTED>һ��ģʽ</OPTION>
			<OPTION VALUE="SUBJECT">ͬ����ģʽ</OPTION>
			<OPTION VALUE="AUTHOR">ͬ����ģʽ</OPTION>
		</SELECT>
		<INPUT TYPE="BUTTON" NAME="Submit4" VALUE="��һƪ">
		<INPUT TYPE="BUTTON" NAME="Submit5" VALUE="��һƪ">
	</P>
	<P>���壺<?php echo $iBoardID ?><BR>
		���ߣ�<?php echo query_user_link($result["brd_readpost"][0]["AUTHOR-ID"][0], $result["brd_readpost"][0]["AUTHOR-ID"][0]); ?> (<?php
			echo query_user_link($result["brd_readpost"][0]["AUTHOR-ID"][0], $result["brd_readpost"][0]["AUTHOR-NAME"][0]);
		?>)<BR>
		���⣺<?php
			echo $result["brd_readpost"][0]["SUBJECT"][0];
		?><BR>
		ʱ�䣺<?php
			echo $result["brd_readpost"][0]["DATE"][0];
		?><BR>
		<!--
		վ����NCTU CSIE FreeBSD Server<BR>
		·����OBW3IFBBS!netnews.hinet.net!ctu-gate!ctu-peer!news.nctu!News.Math.NCTU!<BR>
		��Դ��freebsd.csie.nctu.edu.tw </P>
		-->
	<P>
	<?php

		$body = $result["brd_readpost"][0]["BODY"];
//		printf("<!-- %s -->\n", serialize($body));
		for ($i = 0; $i < count($body); ++$i) {
			$bodyline = strip_ansi($body[$i]);
			$leadingString = substr($bodyline, 0, 2);
			if ((chop($leadingString) == "��") || (chop($leadingString) == "��")) {
				$span_class = "MoreQuoteFrom";
			}
			else if (chop($leadingString) == ":") {
				$span_class = "MoreQuote";
			}
			else if (chop($leadingString) == ">") {
				$span_class = "MoreQuote";
			}
			else {
				$span_class = "MoreText";
			}
			printf("<SPAN CLASS=\"%s\">%s</SPAN><BR>\n", $span_class, $bodyline);
		}

	?>
	<P>
		<SELECT NAME="select3">
			<OPTION VALUE="NORMAL" SELECTED>һ��ģʽ</OPTION>
			<OPTION VALUE="SUBJECT">ͬ����ģʽ</OPTION>
			<OPTION VALUE="AUTHOR">ͬ����ģʽ</OPTION>
		</SELECT>
		<INPUT TYPE="BUTTON" NAME="Submit42" VALUE="��һƪ">
		<INPUT TYPE="BUTTON" NAME="Submit52" VALUE="��һƪ">
	</P>
</FORM>