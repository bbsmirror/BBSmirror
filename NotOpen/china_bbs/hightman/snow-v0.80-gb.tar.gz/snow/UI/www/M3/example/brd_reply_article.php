<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�ظ�����");

$SNOW_PAGE_TITLE = "�ظ�����";
$SNOW_PAGEAREA_MAIN = "brd_reply_article.m.php";
$SNOW_PAGEAREA_FUNC = "brd_reply_article.f.php";

include("bone.php");

?>