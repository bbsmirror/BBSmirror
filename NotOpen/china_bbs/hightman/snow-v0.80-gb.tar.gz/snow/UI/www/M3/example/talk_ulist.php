<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("ʹ�����б�");

if (!isset($iSortMethod) || (strlen($iSortMethod) <= 0) || ($iSortMethod < 0) || ($iSortMethod > 2)) {
	$iSortMethod = 1;
}


$mrr = array(
	"talk_ulist" => array(
		0 => array(
			"USERID" => array(0 => $sUserID),
			"PAGETOP" => array(0 => 1),
			"PAGESIZE" => array(0 => 10),
			"SORT-METHOD" => array(0 => 1)
		)
	)
);

$result = MRRquery($mrr);

$SNOW_PAGE_TITLE = "ʹ�����б�";
$SNOW_PAGEAREA_MAIN = "talk_ulist.m.php";
$SNOW_PAGEAREA_FUNC = "talk_ulist.f.php";

include("bone.php");

?>