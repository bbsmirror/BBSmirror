<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�Ķ�����");

$mrr = array(
	"brd_readpost" => array(
		0 => array(
			"BRDID" => array(0 => $iBoardID),
			"FILENAME" => array(0 => $iFilename)
		)
	)
);
$result = MRRquery($mrr);

$SNOW_PAGE_TITLE = "�Ķ�����";
$SNOW_PAGEAREA_MAIN = "brd_read_post.m.php";
$SNOW_PAGEAREA_FUNC = "brd_read_post.f.php";

include("bone.php");

?>