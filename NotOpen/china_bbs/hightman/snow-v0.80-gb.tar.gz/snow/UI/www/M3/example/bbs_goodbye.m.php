<SCRIPT LANGUAGE="JavaScript">
<!--

function byebyeOption()
{
	if (document.fBye.iByeOption.value == "LEAVE") {
		window.location = "_logout.php";
	}
	else if (document.fBye.iByeOption.value == "YESSIR") {
		window.location = "mail_yessir.php";
	}
	else if (document.fBye.iByeOption.value == "NOTEPAD") {
		window.location = "";
	}
	else if (document.fBye.iByeOption.value == "ABORT") {
		window.location = "<?php echo HISTORYget(1); ?>"; // ����һҳ
	}
}

//-->
</SCRIPT>
<FORM METHOD="post" NAME="fBye">
	<P>
		<INPUT TYPE="radio" NAME="iByeOption" VALUE="LEAVE" CHECKED>
		��Ҫ������<BR>
		<INPUT TYPE="radio" NAME="iByeOption" VALUE="YESSIR">
		����վ��<BR>
		<INPUT TYPE="radio" NAME="iByeOption" VALUE="NOTEPAD">
		���԰� <BR>
		<INPUT TYPE="radio" NAME="iByeOption" VALUE="ABORT">
		ȡ����վ</P>
	<P>
		<INPUT TYPE="button" VALUE="����..." onClick="">
	</P>
</FORM>