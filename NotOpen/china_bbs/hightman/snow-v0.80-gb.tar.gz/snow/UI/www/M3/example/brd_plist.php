<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("������");


/*
 * Required Inputs: iBoardID
 */

/*
 * Optional Inputs: iPageTop, iPageSize
 */

$mrr = array(
	"brd_plist" => array(
		0 => array(
			"BRDID" => array(0 => $iBoardID),
			"PAGETOP" => array(0 => $iPageTop),
			"PAGESIZE" => array(0 => $iPageSize)
		)
	)
);

$result = MRRquery($mrr);
printf("<!-- %s -->\n", serialize($result["brd_post_num"]));

$SNOW_PAGE_TITLE = "������";
$SNOW_PAGEAREA_MAIN = "brd_plist.m.php";
$SNOW_PAGEAREA_FUNC = "brd_plist.f.php";

include("bone.php");

?>