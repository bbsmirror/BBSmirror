/*
 *  $Id: talk_paladd.c,v 1.5 2000/10/23 17:56:39 jeffhung Exp $
 */

#undef DEBUG_TALK_PALADD

#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */
#include "w3if_talk.h"
#include "w3if_session.h"
#include "bbs.h"
#include <sys/param.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <string.h>
#include "w3ifglobal.h"
#include "dao.h"


#ifdef AS_ARNI_MODULE

int mod_talk_paladd(int ofd, char *sid, struct ARNI_ARGS *parg)
{
    return talk_paladd(ofd, sid, parg->args[0].s, parg->args[1].s,
	                   parg->args[2].i);
}

#endif /* AS_ARNI_MODULE */


int talk_paladd(int ofd, char *sid, char *palid, char *friendship, int is_bad)
{
	W3IF_SESSENTRY *psess;
	ACCT           palacct;
	int            userno;
	PAL            pal;
	char           buf[MAXPATHLEN];

	chdir(BBSHOME);

	write(ofd, "MRR-RESULT:talk_paladd\n", strlen("MRR-RESULT:talk_paladd\n"));

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

	if (!(psess = w3ifsession_get(sid))) {
		write(ofd, "RESULT:no such user\nMRR-END:\n",
		      strlen("RESULT:no such user\nMRR-END:\n"));
		return -999; /* no such user */
	}

	ap_start = psess->ap_start;
	cutmp = psess->utmp_entry;

	acct_load(&cuser, cutmp->userid);

	if (!cuser.userlevel) {
		write(ofd, "RESULT:no permission\nMRR-END:\n",
		      strlen("RESULT:no permission\nMRR-END:\n"));
		return 999; /* no permission */
	}

	acct_load(&palacct, palid);
	pal_cache(); /* JeffHung.20000904: load pal cache first */

	/* ulist_makepal() */

	userno = palacct.userno;
	if (userno <= 0) {
		write(ofd, "RESULT:userno error\nMRR-END:\n",
		      strlen("RESULT:userno error\nMRR-END:\n"));
		return -999; /* userno error */
	}
	if (is_pal(userno)) {
		write(ofd, "RESULT:already in pal list\nMRR-END:\n",
		      strlen("RESULT:already in pal list\nMRR-END:\n"));
	    return 999; /* ������������� */
	}
	if (userno == cuser.userno) {
		write(ofd, "RESULT:can not set myself as pal\nMRR-END:\n",
		      strlen("RESULT:can not set myself as pal\nMRR-END:\n"));
		return 999; /* lkchu.981217: �Լ�����Ϊ���� */
	}

	strcpy(buf, palacct.userid);

	strcpy(pal.userid, palacct.userid);
	strncpy(pal.ship, friendship, sizeof(pal.ship) - 1);
	pal.ftype = is_bad ? PAL_BAD : 0;
	pal.userno = userno;
	usr_fpath(buf, cuser.userid, FN_PAL);
	rec_add(buf, &pal, sizeof(PAL));

#ifdef HAVE_ALOHA
	if (!(pal.ftype & PAL_BAD)) {
		BMW bmw;

		bmw.recver = cuser.userno;
		strcpy(bmw.userid, cuser.userid);
		usr_fpath(buf, pal.userid, FN_FRIEND_BENZ);
		rec_add(buf, &bmw, sizeof(BMW));
	}
#endif /* HAVE_ALOHA */

	pal_cache();

	write(ofd, "RESULT:OK\nMRR-END:\n",
	      strlen("RESULT:OK\nMRR-END:\n"));

	return 0;
}

