/*
 *  $Id: talk_recvmsg_main.c,v 1.6 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_TALK_RECVMSG_MAIN

#include <stdio.h>
#include "w3if_talk.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 2) {
		printf("Usage: %s <session-id>\n", argv[0]);
		return 0;
	}

	ret = talk_recvmsg(fileno(stdout), argv[1]);

	if (ret != 0) {
#ifdef DEBUG_TALK_RECVMSG_MAIN
		fprintf(stderr, "talk_recvmsg() error(%d).\n", ret);
#endif /* DEBUG_TALK_RECVMSG_MAIN */
	}

	return 0;
}

