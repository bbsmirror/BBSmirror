/*
 * $Id: chat_client.c,v 1.20 2000/11/14 16:51:48 arlo Exp $
 */

/* ----------------------------------------------- */
/* chat client adaptor for live_server             */
/* ----------------------------------------------- */

#undef DEBUG_CHAT_CLIENT

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <sys/socket.h>
#include "live.h"
#include "live_server.h"
#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"

static char chatroom[IDLEN]; /* Chat-Room Name */
static char chatopic[48];


#ifdef AS_ARNI_MODULE

int mod_chat_client(int ofd, char *sid,
                    USER_INFO *user_info_pool,
                    struct LIVE_ARGS *args)
{
	char *userid;
	char *chatid;
	char *action;
	char *message;
	char *type;
#if 0 /* JeffHung.20001025: i is unused */
	int  i;
#endif /* 0 */
	int  index;

	userid  = args->args[0].s;
	chatid  = args->args[1].s;
	action  = args->args[2].s;
	message = args->args[3].s;
	type    = args->args[4].s;

#ifdef DEBUG_CHAT_CLIENT
	fprintf(stderr, "chat_client starting..\n");
#endif /* DEBUG_CHAT_CLIENT */

	if (!strcasecmp(type, "chat")) {
		if (!strcasecmp(action, ACTION_ENTER)) {
			for (index = 0; index < MAX_CLIENT; ++index) {
				if (user_info_pool[index].type == TYPE_OFFLINE) {
					break;
				}
			}

#ifdef DEBUG_CHAT_CLIENT
			fprintf(stderr, "call chat_client..\n");
#endif /* DEBUG_CHAT_CLIENT */

			return chat_client(0, ofd, userid, chatid, action, message,
			                   &user_info_pool[index], sid);
		}
		if (!strcasecmp(action, ACTION_MSG)) {
			for (index = 0; index < MAX_CLIENT; ++index) {
				if (user_info_pool[index].type != TYPE_OFFLINE) {
					if (!strcasecmp(user_info_pool[index].userid, userid)) {
						break;
					}
				}
			}

			if (index < MAX_CLIENT) {
				return chat_client(user_info_pool[index].fd, ofd, userid,
				                   chatid, action, message,
				                   &user_info_pool[index], sid);       
			}
			else {
				return -1;
			}
		}
	}
  return -1;
}

#endif /* AS_ARNI_MODULE */


#if 0 /* JeffHung.20001107: tatic function sys_log unused */

static void sys_log(char *fpath, char *message)
{
	int fd;

	if ((fd = open(fpath, O_WRONLY | O_CREAT | O_APPEND, 0600)) >= 0) {
		write(fd, message, strlen(message));
		close(fd);
	}
}

#endif /* 0 */

static int chat_send(int fd, char *buf)
{
	int len;

	len = strlen(buf);
	return (send(fd, buf, len, 0) == len);
}

static void printchatline(char *msg, USER_INFO *user_info)
{
	int index;

	index = user_info->index;
	strncpy(user_info->msg_pool[index].msg, msg, 80);
	strcpy(user_info->msg_pool[index].chatroom, chatroom);
	user_info->msg_pool[index].msg[79] = '\0';
	user_info->msg_pool[index].chatroom[IDLEN-1] = '\0';
	user_info->index++;

}

static int chat_recv(int fd, char *chatid, USER_INFO *user_info)
{
	static char buf[512];
	static int  bufstart = 0;
	int         cc;
	int         len;
	char        *bptr;
	char        *str;
	char        option;

	bptr = buf;
	cc = bufstart;
	len = sizeof(buf) - cc - 1;
	if ((len = recv(fd, bptr + cc, len, 0)) <= 0) {
		return -1;
	}
	cc += len;

	for (;;) {
		len = strlen(bptr);

		if (len >= cc) {
			/* wait for trailing data */
			memcpy(buf, bptr, len);
			bufstart = len;
			break;
		}
		if (*bptr == '/') {
			str = bptr + 1;
			option = *str++;

			if (option == 'n') {
				strncpy(chatid, str, 9);
				strncpy(cutmp->mateid, str, sizeof(cutmp->mateid));
				printchatline(chatid, user_info);
			}
			else if (fd == 'r') {
				strncpy(chatroom, str, sizeof(chatroom));
			}
			else if (fd == 't') {
				str_ncpy(chatopic, str, sizeof(chatopic));
			}
		} /* if (*bptr == '/') */
		else {
			printchatline(bptr, user_info); 
		}

		cc -= ++len;
		if (cc <= 0) {
			bufstart = 0;
			break;
		}
		bptr += len;
	}

	return 0;
}

/* ---------------------------------------------------------------- */
/* Argument: fd      -> ��������socket fd                           */
/*           UserID  -> ʹ����ID                                    */
/*           ChatID  -> chat�õ�ID                                  */
/*           Action  -> ʹ���߶���                                  */
/*           Message -> ѶϢ                                        */
/* ---------------------------------------------------------------- */


int chat_client(int fd, int ofd, char *UserID, char *ChatID, char *Action,
                char *Message, USER_INFO *User_Info, char *sid)
{
	int                i;
	int                index;
	char               buf[80];
	char               userid[IDLEN + 1];
	char               chatid[8 + 1];
	struct sockaddr_in sin;
	char               out_buf[GENERAL_BUFSIZE];

#ifdef CHAT_SECURE
	char               passbuf[9]; /*arlo: from bbsd */

	if (!strcasecmp(Action, ACTION_ENTER)) {
		strncpy(passbuf, Message, 9);
	}
#endif /* CHAT_SECURE */
  
	chdir(BBSHOME);
	if (!strcasecmp(Action, ACTION_ENTER)) {
		sin.sin_family = AF_INET;
		sin.sin_port = htons(CHAT_PORT);
		sin.sin_addr.s_addr = INADDR_ANY; 
		memset(sin.sin_zero, 0, sizeof(sin.sin_zero));
		fd = socket(AF_INET, SOCK_STREAM, 0);
	}

	if (fd < 0) {
		return -1;
	}

#ifdef DEBUG_CHAT_CLIENT
	else {
		fprintf(stderr, "action:%s fd:%d\n", Action,fd);
	}
	fprintf(stderr, "pre compare action string\n");
#endif /* DEBUG_CHAT_CLIENT */

	if (!strcasecmp(Action, ACTION_ENTER)) {
		/* begin enter command  */

#ifdef DEBUG_CHAT_CLIENT
		fprintf(stderr, "pre connect\n");
#endif /* DEBUG_CHAT_CLIENT */

		if (connect(fd, (struct sockaddr*)&sin, sizeof(sin))) {
			close(fd);
			fprintf(stderr, "connect fail\n");
			return -1;
		}

#ifdef DEBUG_CHAT_CLIENT
		fprintf(stderr, "connect ok\n");
#endif /* DEBUG_CHAT_CLIENT */

		/* load ACCT data to cuser struct */
		str_lower(userid, UserID);
		if (acct_load(&cuser, userid) < 0)  {

#ifdef DEBUG_CHAT_CLIENT
			fprintf(stderr, "user:%s acct_load failed\n", userid);
#endif /* DEBUG_CHAT_CLIENT */

			return -1;
		}

#if 0
		if (!(up = utmp_find(cuser.userno))) {
			return -1;
		}
		else {
			cutmp = up;
		}
#endif /* 0 */

		/* ��ֹ�������հ�id */
		strncpy(userid, UserID, IDLEN);
		strncpy(chatid, ChatID, 8);
		userid[IDLEN] = '\0';  
		chatid[8] = '\0';

		for(i = 0; i < 8; ++i) {
			if (chatid[i] == ' ')
				;
		}
		chatid[i] = '\0';
#ifdef CHAT_SECURE
		sprintf(buf, "/! %s %s %s\n",
		        cuser.userid, chatid, passbuf);
#else
		sprintf(buf, "/! %d %d %s %s\n",
		        cuser.userno, cuser.userlevel, cuser.userid, chatid);
#endif
		chat_send(fd, buf);
		if (recv(fd, buf, 3, 0) != 3) {
#ifdef DEBUG_CHAT_CLIENT
			fprintf(stderr, "can't login la\n");
#endif
			return 1;
		}
		if (!strcmp(buf, CHAT_LOGIN_EXISTS)) {
#ifdef DEBUG_CHAT_CLIENT
			fprintf(stderr, "login exists\n");
#endif
			return -20;
		}
		else if (!strcmp(buf, CHAT_LOGIN_INVALID)) {
#ifdef DEBUG_CHAT_CLIENT
			fprintf(stderr, "login invalid\n");
#endif
			return -30;
		}
		else if (!strcmp(buf, CHAT_LOGIN_BOGUS)) {
			/* ��ֹ��ͬ���˽��� */
#ifdef DEBUG_CHAT_CLIENT
			fprintf(stderr, "login bogus\n");
#endif
			return -40;
		}

		User_Info->fd = fd;
		User_Info->type = TYPE_CHAT;
		strcpy(User_Info->sid, sid);
		strcpy(User_Info->userid, cuser.userid);

		for(;;) {
			chat_recv(fd, buf, User_Info);
		}

	} /* end of enter command */
	else if (!strcasecmp(Action, ACTION_MSG)) {
#ifdef DEBUG_CHAT_CLIENT
		fprintf(stderr, "action=%s\n", Action);
		fprintf(stderr, "DEBUG:message:%s\n", Message);
#endif /* DEBUG_CHAT_CLIENT */
		write(fd, Message, strlen(Message));
		write(fd, "\n", 1);

		/* �����뿪��ָ��..�������leak */
		if ((Message[0] == '/') && (Message[1] == 'b')) {
			close(fd);
		}

		/* ���ݴ�� message ���� , ���ü򵥵ķ��� */
		for (index = 0; index < User_Info->index; ++index) {
			/*
			 * JeffHung.20001025:
			 * ����� string literal ���� embed һ�� \0��Ҫ��Ȼ�� core dump.
			 */
			snprintf(out_buf, GENERAL_BUFSIZE,
			         "MRR-RESULT:chat_connect\n"
			         "MESSAGE:%s\n\0",
			         User_Info->msg_pool[index].msg);
			write(ofd,out_buf,strlen(out_buf));
		} /* for( index = 0 ...*/

		if (!(User_Info->index)) {
			/*
			 * JeffHung.20001025:
			 * ����� string literal ���� embed һ�� \0��Ҫ��Ȼ�� core dump.
			 */
			snprintf(out_buf, GENERAL_BUFSIZE,
			         "MRR-RESULT:chat_connect\n"
			         "NO-MSG:YES\n\0");
			         write(ofd, out_buf,strlen(out_buf));
		}

		/*
		 * JeffHung.20001025:
		 * ����� string literal ���� embed һ�� \0��Ҫ��Ȼ�� core dump.
		 */
		snprintf(out_buf, GENERAL_BUFSIZE, "MRR-END:\n\0");
		write(ofd, out_buf, strlen(out_buf));
		User_Info->index = 0;
	}
	return 0;
} /* end of chat_client() */


