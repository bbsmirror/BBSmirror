/*
 *  $Id: sys_load.c,v 1.5 2000/10/23 17:56:39 jeffhung Exp $
 */

#undef DEBUG_SYS_LOAD

#include "w3ifglobal.h"
#include <stdio.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <string.h>

int sys_load(int ofd)
{
	double *load;
	char   buf[80];

	ushm_init();

	load = ushm->sysload;
	sprintf(buf, "MRR-RESULT:sys_load\nLOAD:%.2f %.2f %.2f\n",
	        load[0], load[1], load[2]);
	write(ofd, buf, strlen(buf));

	return 0;
}

