/*
 *  $Id: brd_forward.c,v 1.6 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_BRD_FORWARD

#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */
#include "w3if_brd.h"
#include <time.h>
#include <sys/param.h>
#include <stdio.h>
#include "w3if_general.h"
#include "bbs.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <string.h>
#include "w3iflib.h"


#ifdef AS_ARNI_MODULE

/* ARGSUSED 1 */

int mod_brd_forward(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return brd_forward(ofd, parg->args[0].s, parg->args[1].s,
	                   parg->args[2].s, parg->args[3].s);
}

#endif /* AS_ARNI_MODULE */


int brd_forward(int ofd, char *userid, char *toaddr, char *brdname,
                char *fname)
{
#if 0 /* now is unused */
	time_t	now;
#endif /* 0 */
	char	fpath[MAXPATHLEN];
	FILE    *fp;
	char	buf[GENERAL_BUFSIZE];
	char    subject[TTLEN + 1];

	/*
	 *  JeffHung.20000731: Arlo said, before using acct_XXX, we should
	 *  chdir to BBSHOME
	 */
	chdir(BBSHOME);

	write(ofd, "MRR-RESULT:brd_forward\n", strlen("MRR_RESULT:brd_forward\n"));

	/* JeffHung.20000731: prevent buffer overflow */
	if (strlen(userid) > IDLEN) {
		userid[IDLEN] = 0;
	}
	if (strlen(brdname) > IDLEN) {
		brdname[IDLEN] = 0;
	}

	if (!(userid = w3if_getCorrectUserID(userid))) {

#ifdef DEBUG_BRD_FORWARD
		fprintf(stderr, "DEBUG(%s,%d): no such user: userid: %s\n",
		        __FILE__, __LINE__, userid);
#endif /* DEBUG_BRD_FORWARD */

		write(ofd, "RESULT:no such user\nMRR-END:\n",
		      strlen("RESULT:no such user\nMRR-END:\n"));

		return -999; /* no such user */
	}

#ifdef	DEBUG_BRD_FORWARD
	fprintf(stderr, "DEBUG(%s:%d): acct_load\n", __FILE__, __LINE__);
#endif	/* DEBUG_BRD_FORWARD */

	acct_load(&cuser, userid);

#ifdef	DEBUG_BRD_FORWARD
	fprintf(stderr, "DEBUG(%s:%d): acct_load done.\n", __FILE__, __LINE__);
#endif	/* DEBUG_BRD_FORWARD */

	snprintf(fpath, MAXPATHLEN, "brd/%s/%c/%s", brdname, fname[7], fname);

	if (!(fp = fopen(fpath, "r"))) {

#ifdef DEBUG_BRD_FORWARD
		fprintf(stderr, "DEBUG(%s,%d): cannot open post file: fpath: %s\n",
		        __FILE__, __LINE__, fpath);
#endif /* DEBUG_BRD_FORWARD */

		write(ofd, "RESULT:cannot open post file\nMRR-END:\n",
		      strlen("RESULT:cannot open post file\nMRR-END:\n"));

		return -999; /* cannot open post file */
	}
	memset(subject, 0, sizeof(subject));
	while (fgets(buf, GENERAL_BUFSIZE, fp)) {
		if (!strncmp(buf, "����: ", 6)) {
			snprintf(subject, TTLEN, "[fwd]%s", buf + 6);
			break; /* while */
		}
		else if (!strncmp(buf, "��  ��: ", 8)) {
			snprintf(subject, TTLEN, "[fwd]%s", buf + 8);
			break; /* while */
		}
	}
	fclose(fp);

#ifdef	DEBUG_BRD_FORWARD
	fprintf(stderr, "DEBUG(%s:%d): fpath: %s\n", __FILE__, __LINE__, fpath);
#endif	/* DEBUG_BRD_FORWARD */

#ifdef	DEBUG_BRD_FORWARD
	fprintf(stderr, "DEBUG(%s:%d): bsmtp\n", __FILE__, __LINE__);
#endif	/* DEBUG_BRD_FORWARD */
	if (bsmtp(fpath, subject, toaddr, 0) < 0) {

#ifdef DEBUG_BRD_FORWARD
		fprintf(stderr, "DEBUG(%s,%d): cannot send mail: subject: %s\n",
		        __FILE__, __LINE__, subject);
#endif /* DEBUG_BRD_FORWARD */

		write(ofd, "RESULT:can not send mail\nMRR-END:\n",
		      strlen("RESULT:can not send mail\nMRR-END:\n"));

		return -999; /* can not send mail */
	}
#ifdef	DEBUG_BRD_FORWARD
	fprintf(stderr, "DEBUG(%s:%d): bsmtp done.\n", __FILE__, __LINE__);
#endif	/* DEBUG_BRD_FORWARD */

	write(ofd, "RESULT:OK\nMRR-END:\n",
	      strlen("RESULT:OK\nMRR-END:\n"));

	return 0; /* success */
}

