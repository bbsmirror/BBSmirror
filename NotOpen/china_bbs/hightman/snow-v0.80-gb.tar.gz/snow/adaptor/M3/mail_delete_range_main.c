/*
 *  $Id: mail_delete_range_main.c,v 1.7 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_MAIL_DELETE_RANGE_MAIN

#include <stdio.h>
#include "w3if_mail.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 4) {
		printf("Usage: %s <user-id> <fname of first mail> "
		       "<fname of last mail\n",
		       argv[0]);
		return 0;
	}

	ret = mail_delete_range(fileno(stdout), argv[1], argv[2], argv[3]);

	if (ret < 0) {
#ifdef DEBUG_MAIL_DELETE_RANGE_MAIN
		fprintf(stderr, "mail_delete_range error(%d).\n", ret);
#endif /* DEBUG_MAIN_DELETE_RANGE_MAIN */
	}

	return 0;
}

