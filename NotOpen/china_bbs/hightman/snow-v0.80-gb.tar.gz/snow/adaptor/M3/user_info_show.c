/*
 *  $Id: user_info_show.c,v 1.9 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_USER_INFO_SHOW

#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */
#include "w3if_user.h"
#include <stdio.h>
#include "w3if_session.h"
#include <sys/param.h>
#include "w3if_general.h"
#include "bbs.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <string.h>
#include "dao.h"


#ifdef AS_ARNI_MODULE

/* ARGSUSED 2 */

int mod_user_info_show(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return user_info_show(ofd, sid);
}

#endif /* AS_ARNI_MODULE */

#if 0 /* JeffHung.20001107: lint: static function bitmsg unused */

/*
 *  bit-wise display and setup
 */
static void bitmsg(char* msg, char* str, int level)
{
	int cc;

	printf(msg);
	while ((cc = *str) != NULL) {
		printf("%c", (level & 1) ? cc : '-');
		level >>= 1;
		str++;
	}

	printf("\n");
}

#endif /* 0 */

int user_info_show(int ofd, char* sid)
{
	W3IF_SESSENTRY *psess;
	int            totalogintime;
	char           buf[MAXPATHLEN];
	int            numails;
	char           obuf[GENERAL_BUFSIZE];
	int            len;
	int            ch;
	BRD            *bhdr;
	BRD            *tail;
	char           *list;
	int            n_bm;
	extern BCACHE  *bshm;

	/*
	 *  JeffHung.20000731: Arlo said, before using acct_XXX, we should
	 *  chdir to BBSHOME
	 */
	chdir(BBSHOME);

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();
	bshm_init();

	psess = w3ifsession_get(sid);

	if (!psess) {
		return -999; /* no such user */
	}

	ap_start = psess->ap_start;
	cutmp = psess->utmp_entry;
	acct_load(&cuser, cutmp->userid);

	totalogintime = cuser.staytime / 60;

	usr_fpath(buf, cuser.userid, fn_dir);
	numails = rec_num(buf, sizeof(HDR));

	sprintf(obuf, "MRR-RESULT:user_info_show\n");
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "USERID:%s\n", cuser.userid);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "USERNAME:%s\n", cuser.username);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "REALNAME:%s\n", cuser.realname);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "ADDRESS:%s\n", cuser.address);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "EMAIL:%s\n", cuser.email);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "REGIST-DATE:%s", ctime(&(cuser.firstlogin)));
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "NUM-LOGINS:%d\n", cuser.numlogins);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "LOGIN-TIME:%d\n", totalogintime);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "NUM-POSTS:%d\n", cuser.numposts);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "MAILBOX:%d\n", numails);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "REGIST-INFO:%s\n",
	        ((cuser.userlevel & PERM_VALID) ?
	         (cuser.tvalid ? Ctime(&(cuser.tvalid))
	                       : "Registeration Expired") :
	         "Not Registered"));
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "JUSTIFY:%s\n", cuser.justify);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "VALID-EMAIL:%s\n", cuser.vmail);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "IDENT:%s\n", cuser.ident);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "LAST-HOST:%s\n", cuser.lasthost);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "NUM-MAILS:%d\n", cuser.numemail);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "TOTAL-LOGINTIME:%d\n", totalogintime);
	write(ofd, obuf, strlen(obuf));

	if (cuser.userlevel & PERM_BM) {
		sprintf(obuf, "AS-BM:");
		write(ofd, obuf, strlen(obuf));
		/*
		 *  ��ʾ userid ����Щ��İ���
		 */
		len = strlen(cuser.userid);
		bhdr = bshm->bcache;
		tail = bhdr + bshm->number;
		n_bm = 0;

		do {
			list = bhdr->BM;
			ch = *list;
			if ((ch > ' ') && (ch < 128)) {
				do {
					if (!strncmp(list, cuser.userid, len)) {
						ch = list[len];
						if ((ch == 0 || ch == '/')) {
							if ((++n_bm) > 1) {
								write(ofd, " ", strlen(" "));
							}
							sprintf(obuf, "%s", bhdr->brdname);
							write(ofd, obuf, strlen(obuf));
							break;
						}
					}
					while ((ch = *list++) != NULL) {
						if (ch == '/') {
							break;
						}
					}
				} while (ch);
			}
		} while (++bhdr < tail);
		write(ofd, "\n", strlen("\n"));
	}

#ifdef	NEWUSER_LIMIT

	if (cuser.lastlogin - cuser.firstlogin < 3 * 86400) {
		sprintf(obuf, "IS-NEWUSER:YES\n");
		write(ofd, obuf, strlen(obuf));
	}

#endif	/* NEWUSER_LIMIT */

	write(ofd, "MRR-END:\n", strlen("MRR-END:\n"));

	return 0;
}


