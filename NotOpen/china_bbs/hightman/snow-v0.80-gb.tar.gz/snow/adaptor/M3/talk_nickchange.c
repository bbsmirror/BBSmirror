/*
 *  $Id: talk_nickchange.c,v 1.5 2000/10/23 17:56:39 jeffhung Exp $
 */

#undef DEBUG_TALK_NICKCHANGE

#include "w3if_talk.h"
#include "w3if_session.h"
#include "bbs.h"
#include <unistd.h>
#include "w3ifglobal.h"


int talk_nickchange(char *sid, char *newnick)
{
	W3IF_SESSENTRY *psess = 0;

	chdir(BBSHOME);

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

	psess = w3ifsession_get(sid);

	if (!psess) {
		return -999; /* no such user */
	}

	ap_start = psess->ap_start;
	cutmp = psess->utmp_entry;
	acct_load(&cuser, cutmp->userid);

	strncpy(cutmp->username, newnick, 24 - 1);

	return 0;
}

