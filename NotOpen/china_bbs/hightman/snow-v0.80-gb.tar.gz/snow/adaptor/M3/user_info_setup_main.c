/*
 * $Id: user_info_setup_main.c,v 1.4 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_USER_INFO_SETUP_MAIN

#include <stdio.h>
#include "w3if_user.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 6) {
		printf("Usage: %s <session-id> <old-password> <new-nickname> "
		       "<new-realname> <new-address>\n",
		       argv[0]);
		return 0;
	}

	ret = user_info_setup(fileno(stdout), argv[1], argv[2], argv[3], argv[4],
	                      argv[5]);

	if (ret < 5) {
#ifdef DEBUG_USER_INFO_SETUP_MAIN
		fprintf(stderr, "user_info_setup error(%d).\n", ret);
#endif /* DEBUG_USER_INFO_SETUP_MAIN */
	}

	return 0;
}

