/*
 *  $Id: brd_toggle_mark_main.c,v 1.5 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_BRD_TOGGLE_MARK_MAIN

#include <stdio.h>
#include "w3if_brd.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 3) {
		printf("Usage: %s <board-id> <post-file-name>\n", argv[0]);
		return 0;
	}

	ret = brd_toggle_mark(fileno(stdout), argv[1], argv[2]);

	if (ret < 0) {
#ifdef DEBUG_BRD_TOGGLE_MARK_MAIN
		fprintf(stderr, "brd_toggle_mark error(%d).\n", ret);
#endif /* DEBUG_BRD_TOGGLE_MARK_MAIN */
	}

	return 0;
}

