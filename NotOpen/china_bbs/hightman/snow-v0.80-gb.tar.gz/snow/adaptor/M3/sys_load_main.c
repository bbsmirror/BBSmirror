/*
 *  $Id: sys_load_main.c,v 1.5 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_SYS_LOAD_MAIN

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 1) {
		printf("Usage: %s\n", argv[0]);
		return 0;
	}

	ret = sys_load(fileno(stdout));

	if (ret < 0) {
#ifdef DEBUG_SYS_LOAD_MAIN
		fprintf(stderr, "sys_load error(%d).\n", ret);
#endif /* DEBUG_SYS_LOAD_MAIN */
	}

	return 0;
}

