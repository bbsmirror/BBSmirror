/*
 *  $Id: talk_paldel.c,v 1.6 2000/10/25 12:31:55 jeffhung Exp $
 */

#undef DEBUG_TALK_PALDEL

#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */
#include "w3if_talk.h"
#include "bbs.h"
#include "w3if_session.h"
#include <sys/param.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <string.h>
#include "w3ifglobal.h"
#include <stdio.h>
#include "dao.h"


#ifdef AS_ARNI_MODULE

int mod_talk_paldel(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return talk_paldel(ofd, sid, parg->args[0].s);
}

#endif /* AS_ARNI_MODULE */

#if 0 /* JeffHung.20000930: already defined in w3ifglobal.c */

int is_samepal(int userno, PAL *pal)
{
	return (userno == pal->userno);
}

#endif /* 0 */

#ifdef HAVE_ALOHA

int cmpbmw(BMW *benz)
{
	return benz->recver == cuser.userno;
}

#endif /* HAVE_ALOHA */

int talk_paldel(int ofd, char *sid, char *palid)
{
	W3IF_SESSENTRY *psess;
	ACCT           palacct;
	int            userno;
	PAL            pal;
	char           fpath[MAXPATHLEN];
	int            palno;

	chdir(BBSHOME);

	write(ofd, "MRR-RESULT:talk_paldel\n", strlen("MRR-RESULT:talk_paldel\n"));

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

	if (!(psess = w3ifsession_get(sid))) {
		write(ofd, "RESULT:no such user\nMRR-END:\n",
		      strlen("RESULT:no such user\nMRR-END:\n"));
		return -999; /* no such user */
	}

	ap_start = psess->ap_start;
	cutmp = psess->utmp_entry;

	acct_load(&cuser, cutmp->userid);

	if (!cuser.userlevel) {
		write(ofd, "RESULT:no permission\nMRR-END:\n",
		      strlen("RESULT:no permission\nMRR-END:\n"));
		return 999; /* no permission */
	}

	acct_load(&palacct, palid);
	pal_cache(); /* JeffHung.20000904: load pal cache first */

#ifdef DEBUG_TALK_PALDEL

	fprintf(stderr, "DEBUG(%s,%d): 1st pal_cache()\n", __FILE__, __LINE__);

#endif /* DEBUG_TALK_PALDEL */

	/* pal_del() */

	userno = palacct.userno;
	if (userno <= 0) {
		write(ofd, "RESULT:userno error\nMRR-END:\n",
		      strlen("RESULT:userno error\nMRR-END:\n"));
		return -999; /* userno error */
	}

	usr_fpath(fpath, cuser.userid, FN_PAL);
	if (!(palno = rec_search(fpath, (char*)&pal, sizeof(PAL), is_samepal,
	                         userno))) {
		write(ofd, "RESULT:no such pal\nMRR-END:\n",
		      strlen("RESULT:no such pal\nMRR-END:\n"));
		return -999; /* no such pal */
	}
#if 0 /* JeffHung.20000904: rec_search() ���ж�ȡ�Ĺ��� */
	rec_get(fpath, &pal, sizeof(PAL), palno);
#endif /* 0 */

#ifdef DEBUG_TALK_PALDEL

	fprintf(stderr, "DEBUG(%s,%d): get pal record\n", __FILE__, __LINE__);

#endif /* DEBUG_TALK_PALDEL */

#ifdef HAVE_ALOHA

	if (!(pal.ftype & PAL_BAD)) {
		/* we are good friend */
		usr_fpath(fpath, palacct.userid, FN_FRIEND_BENZ);
		rec_del(fpath, sizeof(BMW), 0, cmpbmw, NULL);
	}

#endif /* HAVE_ALOHA */

	usr_fpath(fpath, cuser.userid, FN_PAL);

#ifdef DEBUG_TALK_PALDEL

	fprintf(stderr, "DEBUG(%s,%d): before 2nd pal_cache()\n",
	        __FILE__, __LINE__);

#endif /* DEBUG_TALK_PALDEL */

	if (!rec_del(fpath, sizeof(PAL), palno - 1, NULL, NULL)) {
		pal_cache();
	}

	write(ofd, "RESULT:OK\nMRR-END:\n",
	      strlen("RESULT:OK\nMRR-END:\n"));

	return 0;
}

