/*
 * $Id: chat_client_main.c,v 1.4 2000/10/23 17:56:39 jeffhung Exp $
 */

#include <stdio.h>
#include <stdlib.h>
#include "w3if_chat.h"

int main(int argc, char *argv[])
{
	int return_val;

	if (argc < 5) {
		fprintf(stderr,
"/* ---------------------------------------------------------------- */\n"
"/* Argument: fd      -> ��������socket fd                           */\n"
"/*           UserID  -> ʹ����ID                                    */\n"
"/*           ChatID  -> chat�õ�ID                                  */\n"
"/*           Action  -> ʹ���߶���                                  */\n"
"/*           Message -> ѶϢ                                        */\n"
"/* ---------------------------------------------------------------- */\n"
		);
		return -1;
	}

	return_val = chat_client(atoi(argv[1]), fileno(stdout), argv[2], argv[3],
	                         argv[4], argv[5], NULL, NULL);
	return return_val;
}


