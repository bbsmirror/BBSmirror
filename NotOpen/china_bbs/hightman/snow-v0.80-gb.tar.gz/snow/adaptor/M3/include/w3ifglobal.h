/*
 *  $Id: w3ifglobal.h,v 1.7 2000/10/25 12:31:55 jeffhung Exp $
 */

#ifndef	W3IFGLOBAL_H_INCLUDED
#define	W3IFGLOBAL_H_INCLUDED

#include "bbs.h"


/*
 *  Global variables for w3if
 */
extern time_t	ap_start;

/* 
 * �Ͼɵ�OSû��INET_ADDRSTRLEN���definition 
 */
#ifndef INET_ADDRSTRLEN
#define INET_ADDRSTRLEN 16
#endif /* #ifndef INET_ADDRSTRLEN */

/*
 *  Global variables declared in bbsd.c
 */
extern char	*str_host;
extern char	*str_site;
extern char *str_sysop;
extern char	*fn_dir;
extern char	*fn_acct;
extern char	*fn_plans;
extern char	*fn_note;

extern pid_t currpid;		/* current process ID */
extern char  currboard[IDLEN + 2]; /* name of currently selected board */

#ifdef  HAVE_REGISTER_FORM
extern char	*fn_rform; /* ע����� */
#endif  /* HAVE_REGISTER_FORM */

/*
 *  Global variables declared in global.h
 */
#if	0	/* JeffHung.2000707: ��Щ�� src/include/global.h �ﶼ���� */

extern ACCT		cuser;	/* current user structure */
extern time_t	ap_start; /* start time form user login */
extern UTMP*	cutmp; /* current utmp */

#endif	/* 0 */


/*
 *  Global variables declared in cache.c
 */

extern int		ap_semid; /* application's semaphore id */
extern UCACHE*	ushm; /* .UTMP cache */
extern BCACHE*	bshm; /* .BRD cache */
#ifdef	MODE_STAT
extern UMODELOG	modelog;
#endif	/* MODE_STAT */


/*
 *  Global variables declared in mail.c
 */

extern LinkList*	ll_head;	/* head of link list */
extern LinkList*	ll_tail;	/* tail of link list */

struct tagCMBOX {
	XO		mail_xo;
	char	dir[32];
};

extern struct tagCMBOX	cmbox;
extern int	TagNum;

/*
 *  Global variables decalred in xover.c
 */

extern int		TagNum; /* tag's number */
extern TagItem	TagList[TAG_MAX]; /* ascending list */
extern char		xo_pool[]; /* XO's data I/O pool */

#if	0	/* JeffHung.20000714: try to discard this to decouple sources */
extern XZ	xz[];
#endif	/* 0 */

extern char *user_flags[];
extern int  user_flags_num;


extern char *trim_r_newline(char *s);
extern int is_samepal(int userno, PAL *pal);
extern int rec_search(char *fpath, char *rptr, int size,
                      int (*fptr)(), int farg);

#endif	/* W3IFGLOBAL_H_INCLUDED */

