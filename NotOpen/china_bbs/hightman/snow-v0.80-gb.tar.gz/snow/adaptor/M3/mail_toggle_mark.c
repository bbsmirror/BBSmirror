/*
 *  $Id: mail_toggle_mark.c,v 1.8 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_MAIL_TOGGLE_MARK

#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */
#include "w3if_mail.h"
#include "bbs.h"
#include <sys/param.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "w3if_general.h"
#include <unistd.h>
#include <sys/uio.h>
#include <string.h>
#include "dao.h"
#include <stdlib.h>


#ifdef AS_ARNI_MODULE

/* ARGSUSED 1 */

int mod_mail_toggle_mark(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return mail_toggle_mark(ofd, parg->args[0].s, parg->args[1].s);
}

#endif /* AS_ARNI_MODULE */


int mail_toggle_mark(int ofd, char *userid, char *fname)
{
	char		lower_userid[IDLEN + 1];
	char		fpath[MAXPATHLEN];
	struct stat	st;
	int			mailnum;
	HDR			*mailbuf;
	FILE		*mailfp;
	int			i; /* generic i */
#if 0 /* obuf is unused */
	char        obuf[GENERAL_BUFSIZE];
#endif /* 0 */

	/*
	 *  JeffHung.20000731: Arlo said, before using acct_XXX, we should
	 *  chdir to BBSHOME
	 */
	chdir(BBSHOME);

	write(ofd, "MRR-RESULT:mail_toggle_mark\nMRR-END:\n",
	      strlen("MRR-RESULT:mail_toggle_mark\nMRR-END:\n"));

	/* prevent buffer overflow */
	if (strlen(userid) > IDLEN) {
		userid[IDLEN] = 0;
	}

	str_lower(lower_userid, userid);

	snprintf(fpath, MAXPATHLEN, BBSHOME "/usr/%c/%s/" FN_DIR,
	         lower_userid[0], lower_userid);

	if (lstat(fpath, &st) < 0) {
#ifdef	DEBUG_MAIL_TOGGLE_MARK
		fprintf(stderr, "DEBUG(%d): mailbox index file not found.\n",
		        __LINE__);
#endif	/* DEBUG_MAIL_TOGGLE_MARK */

		write(ofd, "RESULT:mail index file not found\nMRR-END:\n",
		      strlen("RESULT:mail index file not found\nMRR-END:\n"));

		return -999; /* mailbox index file not found */
	}
	mailnum = st.st_size / sizeof(HDR);

	if (!(mailbuf = (HDR*)malloc(sizeof(HDR) * mailnum))) {
#ifdef	DEBUG_MAIL_TOGGLE_MARK
		fprintf(stderr, "DEBUG(%d): allocate memory error.\n", __LINE__);
#endif	/* DEBUG_MAIL_TOGGLE_MARK */

		write(ofd, "RESULT:allocate memory error\nMRR-END:\n",
		      strlen("RESULT:allocate memory error\nMRR-END:\n"));

		return -999; /* allocate memory error */
	}
	memset(mailbuf, 0, sizeof(HDR) * mailnum);

	if (!(mailfp = fopen(fpath, "r+"))) {
#ifdef	DEBUG_MAIL_TOGGLE_MARK
		fprintf(stderr, "DEBUG(%d): can not open mail index file.\n",
		        __LINE__);
#endif	/* DEBUG_MAIL_TOGGLE_MARK */
		free(mailbuf);

		write(ofd, "RESULT:can not open mail index file\nMRR-END:\n",
		      strlen("RESULT:can not open mail index file\nMRR-END:\n"));

		return -999; /* can not open mail index file */
	}

	/* read all stuffs into buffer */
	fseek(mailfp, 0, SEEK_SET);
	if ((mailnum = fread(mailbuf, sizeof(HDR), mailnum, mailfp)) < 0) {
#ifdef	DEBUG_MAIL_TOGGLE_MARK
		fprintf(stderr, "DEBUG(%d): read mailbox index file error.\n",
		        __LINE__);
#endif	/* DEBUG_MAIL_TOGGLE_MARK */
		fclose(mailfp);
		free(mailbuf);

		write(ofd, "RESULT:read mailbox index file error\n"
		           "MRR-END:\n",
		      strlen("RESULT:read mailbox index file error\n"
		             "MRR-END:\n"));

		return -999; /* read mailbox index file error */
	}

	for (i = 0; i < mailnum; ++i) {
		if (!strcmp(mailbuf[i].xname, fname)) {
			mailbuf[i].xmode ^= MAIL_MARKED;
			fseek(mailfp, sizeof(HDR) * i, SEEK_SET);
			if (fwrite(&(mailbuf[i]), sizeof(HDR), 1, mailfp) != 1) {
#ifdef	DEBUG_MAIL_TOGGLE_MARK
				fprintf(stderr, "DEBUG(%d): write to mail index file error.\n",
				        __LINE__);
#endif	/* DEBUG_MAIL_TOGGLE_MARK */
				fclose(mailfp);
				free(mailbuf);

				write(ofd, "RESULT:write to mail index file error\n"
				           "MRR-END:\n",
				      strlen("RESULT:write to mail index file error\n"
				             "MRR-END:\n"));
				return -999; /* write to mail index file error */
			}

			fclose(mailfp);
			free(mailbuf);

			write(ofd, "RESULT:OK\nMRR-END:\n",
			      strlen("RESULT:OK\nMRR-END:\n"));

			return 0; /* success */
		}
	}

#ifdef	DEBUG_MAIL_TOGGLE_MARK
	fprintf(stderr, "DEBUG(%d): mail not found.\n", __LINE__);
#endif	/* DEBUG_MAIL_TOGGLE_MARK */

	write(ofd, "RESULT:mail not found\nMRR-END:\n",
	      strlen("RESULT:mail not found\nMRR-END:\n"));

	return 999; /* mail not found */
}

