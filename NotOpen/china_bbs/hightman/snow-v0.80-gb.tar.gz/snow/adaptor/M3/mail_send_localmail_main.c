/*
 *  $Id: mail_send_localmail_main.c,v 1.6 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef	DEBUG_MAIL_SEND_LOCALMAIL_MAIN

#include <stdio.h>
#include "w3if_mail.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 5) {
		printf("Usage: %s <from-user-id> <to-user-id> <subject> "
		       "<mail-file-name>\n",
		       argv[0]);
		return 0;
	}

#ifdef	DEBUG_MAIL_SEND_LOCALMAIL_MAIN
	{
	int	debug_i;
	for (debug_i = 1; debug_i <= argc; ++debug_i) {
		fprintf(stderr, "DEBUG(%s:%d): argv[%d]: %s`\n",
		        __FILE__, __LINE__, debug_i, argv[debug_i]);
	} /* for (debug_i) */
	}
#endif	/* DEBUG_MAIL_SEND_LOCALMAIL_MAIN */

	argv[3][strlen(argv[3]) - 1] = 0;
	ret = mail_send_localmail(fileno(stdout), argv[1], argv[2], &(argv[3][1]),
	                          argv[4]);
	if (ret < 0) {
#ifdef DEBUG_MAIL_SEND_LOCALMAIL_MAIN
		fprintf(stderr, "mail_send_localmail error(%d).\n", ret);
#endif /* DEBUG_MAIL_SEND_LOCALMAIL_MAIN */
	}

	return 0;
}

