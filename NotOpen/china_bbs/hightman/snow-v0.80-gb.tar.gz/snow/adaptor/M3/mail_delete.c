/*
 *  $Id: mail_delete.c,v 1.7 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_MAIL_DELETE

#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */
#include "w3if_mail.h"
#include "bbs.h"
#include <sys/param.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/uio.h>
#include <string.h>
#include "dao.h"
#include <stdlib.h>

#ifdef AS_ARNI_MODULE

/* ARGSUSED 1 */

int mod_mail_delete(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return mail_delete(ofd, parg->args[0].s, parg->args[1].s);
}

#endif /* AS_ARNI_MODULE */


int mail_delete(int ofd, char *userid, char *fname)
{
	char		lower_userid[IDLEN + 1];
	char		fpath[MAXPATHLEN];
	struct stat	st;
	int			mailnum;
	HDR			*mailbuf;
	FILE		*mailfp;
	int			i; /* generic i */

	/*
	 *  JeffHung.20000731: Arlo said, before using acct_XXX, we should
	 *  chdir to BBSHOME
	 */
	chdir(BBSHOME);

	write(ofd, "MRR-RESULT:mail_delete\n", strlen("MRR-RESULT:mail_delete\n"));

	if (strlen(userid) > IDLEN) {
		userid[IDLEN] = 0;
	}

	str_lower(lower_userid, userid);
	snprintf(fpath, MAXPATHLEN, BBSHOME "/usr/%c/%s/" FN_DIR,
	         lower_userid[0], lower_userid);

	if (lstat(fpath, &st) < 0) {
		write(ofd, "RESULT:mailbox index file not found\nMRR-END:\n",
		      strlen("RESULT:mailbox index file not found\nMRR-END:\n"));
		return -999; /* mailbox index file not found */
	}
	mailnum = st.st_size / sizeof(HDR);

	if (!(mailbuf = (HDR*)malloc(sizeof(HDR) * mailnum))) {
		write(ofd, "RESULT:allocate memory error\nMRR-END:\n",
		      strlen("RESULT:allocate memory error\nMRR-END:\n"));
		return -999; /* allocate memory error */
	}
	memset(mailbuf, 0, sizeof(HDR) * mailnum);

	if (!(mailfp = fopen(fpath, "r"))) {
		free(mailbuf);
		write(ofd, "RESULT:open mailbox index file error\nMRR-END:\n",
		      strlen("RESULT:open mailbox index file error\nMRR-END:\n"));
		return -999; /* open mailbox index file error */
	}

	/* read all stuffs into buffer */
	if ((mailnum = fread(mailbuf, sizeof(HDR), mailnum, mailfp)) < 0) {
		fclose(mailfp);
		free(mailbuf);
		write(ofd, "RESULT:read mailbox index file error\nMRR-END:\n",
		      strlen("RESULT:read mailbox index file error\nMRR-END:\n"));
		return -999; /* read mailbox index file error */
	}

	fclose(mailfp);

	for (i = 0; i < mailnum; ++i) {
		if (!strcmp(mailbuf[i].xname, fname)) {
			/*
			 *  Thor.980901: mark������'D'����, ��һ������delete,
			 *  ֻ�� MARK & no delete�Ż���Ч
			 */
			if ((mailbuf[i].xmode & (MAIL_MARKED | MAIL_DELETE))
			    == MAIL_MARKED) {
				free(mailbuf);
				write(ofd, "RESULT:delete not allowed\nMRR-END:\n",
				      strlen("RESULT:delete not allowed\nMRR-END:\n"));
				return 999; /* delete not allowed */
			}

			if (!rec_del(fpath, sizeof(HDR), i, NULL, NULL)) {
				snprintf(fpath, MAXPATHLEN, BBSHOME "/usr/%c/%s/@/%s",
				         lower_userid[0], lower_userid, mailbuf[i].xname);
				unlink(fpath);
				free(mailbuf);
				write(ofd, "RESULT:OK\nMRR-END:\n",
				      strlen("RESULT:OK\nMRR-END:\n"));
				return 0; /* success */
			}

			free(mailbuf);
			write(ofd, "RESULT:can not delete mail\nMRR-END:\n",
			      strlen("RESULT:can not delete mail\nMRR-END:\n"));
			return -999; /* can not delete mail */
		}
	}

	free(mailbuf);
	write(ofd, "RESULT:mail not found\nMRR-END:\n",
	      strlen("RESULT:mail not found\nMRR-END:\n"));
	return -999; /* mail not found */
}

