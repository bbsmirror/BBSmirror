/*
 *  $Id: more_lib.c,v 1.1 2000/09/30 03:48:18 arlo Exp $
 */

#include "w3iflib.h"
#include "w3ifglobal.h"

#include "bbs.h"


#define MORE_BUFSIZE	4096
#define	MORE_WINSIZE	4096	/* window size : 2048 or 4096 */
#define	NET_WINSIZE	3072


#define	STR_ANSICODE	"[0123456789;,"


static uschar more_pool[MORE_BUFSIZE];
static int more_base, more_size;


char *
mgets(fd)
  int fd;
{
  char *pool, *base, *head, *tail;
  int ch;

  if (fd < 0)
  {
    more_base = more_size = 0;
    return NULL;
  }

  pool = more_pool;
  base = pool + more_base;
  tail = pool + more_size;
  head = base;

  for (;;)
  {
    if (head >= tail)
    {
      if (ch = head - base)
	memcpy(pool, base, ch);

      head = pool + ch;
      ch = read(fd, head, MORE_BUFSIZE - ch);

      if (ch <= 0)
	return NULL;

      base = pool;
      tail = head + ch;
      more_size = tail - pool;
    }

    ch = *head;

    if (ch == '\n')
    {
      *head++ = '\0';
      more_base = head - pool;
      return base;
    }

    if (ch == '\r')
      *head = '\0';

    head++;
  }
}


/* use mgets(-1) to reset */


void *
mread(fd, len)
  int fd, len;
{
  char *pool;
  int base, size;

  base = more_base;
  size = more_size;
  pool = more_pool;

  if (size < len)
  {
    if (size)
    {
      memcpy(pool, pool + base, size);
    }

    base = read(fd, pool + size, MORE_BUFSIZE - size);

    if (base <= 0)
      return NULL;

    size += base;
    base = 0;
  }

  more_base = base + len;
  more_size = size - len;

  return pool + base;
}
