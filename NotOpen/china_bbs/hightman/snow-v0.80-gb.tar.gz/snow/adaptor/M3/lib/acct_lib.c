/*
 *  $Id: acct_lib.c,v 1.3 2000/10/25 12:31:55 jeffhung Exp $
 */

#define _ADMIN_C_

#include "bbs.h"

extern BCACHE *bshm;

#define STR_PERM      "bctpjm#x--------PTCM--L*B#--ACBS"


/* ----------------------------------------------------- */
/* (.ACCT) ʹ�����ʺ� (account) subroutines		 */
/* ----------------------------------------------------- */

void
blog(mode, msg)
  char *mode, *msg;
{
  char buf[512], data[256];
  time_t now;

  time(&now);
  if (!msg)
  {
    msg = data;
    sprintf(data, "Stay: %d (%d)", (now - ap_start) / 60, currpid);
  }

  sprintf(buf, "%s %s %-13s%s\n", Etime(&now), mode, cuser.userid, msg);
  f_cat(FN_USIES, buf);
}


int
acct_load(acct, userid)
  ACCT *acct;
  char *userid;
{
  int fd;

  usr_fpath((char *) acct, userid, fn_acct);
  fd = open((char *) acct, O_RDONLY);
  if (fd >= 0)
  {
    /* Thor.990416: �ر�ע��, ��ʱ .ACCT�ĳ��Ȼ���0 */
    read(fd, acct, sizeof(ACCT));
    close(fd);
  }
  return fd;
}


void acct_save(ACCT *acct)
{
  int fd;
  char fpath[80];

  usr_fpath(fpath, acct->userid, fn_acct);
  fd = open(fpath, O_WRONLY, 0600);	/* fpath �����Ѿ����� */
  if (fd >= 0)
  {
    write(fd, acct, sizeof(ACCT));
    close(fd);
  }
}


int
acct_userno(userid)
  char *userid;
{
  int fd;
  int userno;
  char fpath[80];

  usr_fpath(fpath, userid, fn_acct);
  fd = open(fpath, O_RDONLY);
  if (fd >= 0)
  {
    read(fd, &userno, sizeof(userno));
    close(fd);
    return userno;
  }
  return 0;
}

/* ----------------------------------------------------- */
/* bit-wise display and setup				 */
/* ----------------------------------------------------- */

void
bitmsg(msg, str, level)
  char *msg, *str;
  int level;
{
  int cc;

  printf("%s",msg);
  while (cc = *str)
  {
    putchar((level & 1) ? cc : '-');
    level >>= 1;
    str++;
  }

  putchar('\n');
}

/* Arlo.20000706
 * delete bitset() setperm()
*/

/* ----------------------------------------------------- */
/* �ʺŹ���						 */
/* ----------------------------------------------------- */

void
bm_list(userid)                 /* ��ʾ userid ����Щ��İ��� */
  char *userid;
{
  int len, ch;
  BRD *bhdr, *tail;
  char *list;
  extern BCACHE *bshm;

  len = strlen(userid);
  printf("���ΰ�����");

  bhdr = bshm->bcache;
  tail = bhdr + bshm->number;

  do
  {
    list = bhdr->BM;
    ch = *list;
    if ((ch > ' ') && (ch < 128))
    {
      do
      {
        if (!str_ncmp(list, userid, len))
        {
          ch = list[len];
          if ((ch == 0) || (ch == '/'))
          {
            printf(bhdr->brdname);
            printf(" ");
            break;
          }
        }
        while (ch = *list++)
        {
          if (ch == '/')
            break;
        }
      } while (ch);
    }
  } while (++bhdr < tail);

  printf("\n");
}

#ifdef LOG_ADMIN
/* Thor.990405: log permission modify */
void
perm_log(u, oldu)
  ACCT *u;
  ACCT *oldu;
{
  int i;
  usint level;
  char buf[128];

  for(i = 0, level = 1; i < NUMPERMS; i++, level <<= 1)
  {
    if ((u->userlevel & level) != (oldu->userlevel & level))
    {
      sprintf(buf, "%s %s %s (%s) by %s\n", u->userid,  
                       (u->userlevel & level) ? "��" : "��",
                       perm_tbl[i], Now(), cuser.userid);

      f_cat(FN_SECURITY, buf);
    }
  }
  if(str_ncmp(u->userid,oldu->userid,IDLEN))   
  {
      sprintf(buf, "%s ����Ϊ %s (%s) by %s\n", oldu->userid, u->userid,
                                                Now(), cuser.userid);
      f_cat(FN_SECURITY, buf);
  }                                                  
  
}
#endif

void
acct_show(u, adm)
  ACCT *u;
  int adm;			/* 1: admin 2: reg-form */
{
  int diff;
  usint ulevel;
  char *uid, buf[80];

  uid = u->userid;
  if (adm != 2)
    printf("\n��    �ţ�%s", uid);

  printf(
    "\n��    �ƣ�%s\n"
    "��ʵ������%s\n"
    "��ססַ��%s\n"
    "�ʼ����䣺%s\n",
    u->username,
    u->realname,
    u->address,
    u->email);

  printf("ע�����ڣ�%s", ctime(&u->firstlogin));

  printf("�������ڣ�%s", ctime(&u->lastlogin));

  diff = u->staytime / 60;
  printf("��վ������%d �� (�� %d ʱ %d ��)\n",
    u->numlogins, diff / 60, diff % 60);

  printf("������Ŀ��%d ƪ\n", u->numposts);

  usr_fpath(buf, uid, fn_dir);
  printf("�����ż���%d ��\n", rec_num(buf, sizeof(HDR)));

  ulevel = u->userlevel;

  printf("������֤��");
  if (ulevel & PERM_VALID)
  {
    printf(u->tvalid ? Ctime(&u->tvalid) : "��Ч�ڼ��ѹ�����������֤");
  }
  else
  {
    printf("��ο���վ����������ȷ�ϣ�����NȨ��");
  }
#if 0
  printf("\033[m\n");
#endif

  if (adm)
  {
    printf("��֤���ϣ�%s\n", u->justify);
    printf("��֤��ַ��%s\n", u->vmail);
    printf("RFC 931 ��%s\n", u->ident);
    printf("��վ�ص㣺%s (%d)\n", u->lasthost, u->numemail);
    bitmsg(MSG_USERPERM, STR_PERM, ulevel);
    bitmsg("��    �꣺", "amnsEPQFAC", u->ufo);
  }
  else
  {
    diff = (time(0) - ap_start) / 60;
    printf("ͣ���ڼ䣺%d Сʱ %d ��\n", diff / 60, diff % 60);
  }

  if (adm == 2)
    return;

  /* Thor: �뿴����� user ����Щ��İ��� */

  if (ulevel & PERM_BM)
    bm_list(uid);

#ifdef	NEWUSER_LIMIT
  if (u->lastlogin - u->firstlogin < 3 * 86400)
    printf("\n������·�������Ὺ��Ȩ��");
#endif
}

/*Arlo.20000708 
 * delete acct_setup() u_info() m_user()
*/

/* ----------------------------------------------------- */
/* �趨 E-mail address					 */
/* ----------------------------------------------------- */


int ban_addr(char *addr)
{
  int i;
  char *host, *str;
  char foo[64]; /* SoC: ���ô����� email address */

  static char *invalid[] =
  {"@bbs", "bbs@", "root@", "gopher@",
    "guest@", "@ppp", "@slip", "@dial", "unknown@", "@anon.penet.fi",
    "193.64.202.3", NULL
  };

#if 1 /* Thor.991112: ��¼������֤��email */
  sprintf(foo, "%s # %s (%s)\n",addr, cuser.userid, Now());
  f_cat("run/emailreg.log", foo);
#endif  

  /* SoC: ����ԭ email �Ĵ�Сд */
  str_lower(foo, addr);

  for (i = 0; str = invalid[i]; i++)
  {
    if (strstr(foo, str))
      return 1;
  }

#ifdef TRUST_ACLFILE
#ifdef UNTRUST_ACLFILE

  /* check for mail.acl (lower case filter) */

  host = (char *) strchr(foo, '@');
  *host = '\0';
  /* Thor.991103: ������ */
  i = acl_has(TRUST_ACLFILE, foo, host + 1);
  /* if(i < 0 ) TRACE("NOACL","TRUST_ACLFILE"); */
  if (i == 0) return 1; /* BAN */ 

  /* i = acl_has(MAIL_ACLFILE, foo, host + 1); */
  /* Thor.981223: ��bbsreg�ܾ����ַֿ� */
 /* Thor.991103: ������ */   
  i = acl_has(UNTRUST_ACLFILE, foo, host + 1);
  /* *host = '@'; */
  if(i < 0)
    TRACE("NOACL",host);

  return i > 0;

#else /* UNTRUST_ACLFILE */

  return 0;

#endif /* UNTRUST_ACLFILE */
#endif /* TRUST_ACLFILE */
}


/* Arlo.20000707
 * delete u_lock() u_xfile()
*/

/* ----------------------------------------------------- */
/* �������						 */
/* ----------------------------------------------------- */


int
valid_brdname(brd)
  char *brd;
{
  int ch;

  if (!is_alnum(*brd))
    return 0;

  while (ch = *++brd)
  {
    if (!is_alnum(ch) && ch != '.' && ch != '-' && ch != '_')
      return 0;
  }
  return 1;
}

/* Arlo.20000707
 * delete m_setbrd() brd_edit()
*/

#ifdef	HAVE_REGISTER_FORM
/* ----------------------------------------------------- */
/* ʹ������дע�����					 */
/* ----------------------------------------------------- */

/* Arlo.20000707
 * delete getfield()  u_register() 
 *        scan_register_form()  m_register()
*/


#endif


/* ----------------------------------------------------- */
/* ����׷�ټ�¼��������� log_usies()��TRACE()		 */
/* ----------------------------------------------------- */


#ifdef	HAVE_REPORT
void
report(s)
  char *s;
{
  static int disable = NA;
  int fd;

  if (disable)
    return;

  if ((fd = open("trace", O_WRONLY, 0600)) != -1)
  {
    char buf[256];
    char *thetime;
    time_t dtime;

    time(&dtime);
    thetime = Etime(&dtime);

    /* flock(fd, LOCK_EX); */
    /* Thor.981205: �� fcntl ȡ��flock, POSIX��׼�÷� */
    f_exlock(fd);

    lseek(fd, 0, L_XTND);
    sprintf(buf, "%s %s %s\n", cuser.userid, thetime, s);
    write(fd, buf, strlen(buf));

    /* flock(fd, LOCK_UN); */
    /* Thor.981205: �� fcntl ȡ��flock, POSIX��׼�÷� */
    f_unlock(fd);

    close(fd);
  }
  else
    disable = YEA;
}


#endif
