/*
 *  $Id: xover_lib.c,v 1.1 2000/09/30 03:48:18 arlo Exp $
 */

#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"


/*
 *  op: TAG_NIN / TOGGLE / INSERT
 *
 *  return  0: not found / full
 *          1: add
 *         -1: remove
 */
int Tagger(time_t chrono, int recno, int op)
{
	int		head;
	int		tail;
	int		pos;
	int		cmp;
	TagItem	*tagp;

	for (head = 0, tail = TagNum - 1, tagp = TagList, cmp = 1;
	     head <= tail; ) {
		pos = (head + tail) >> 1;
		cmp = tagp[pos].chrono - chrono;
		if (!cmp) {
			break; /* for */
		}
		else if (cmp < 0) {
			head = pos + 1;
		}
		else {
			tail = pos - 1;
		}
	}

	if (op == TAG_NIN) {
		if (!cmp && recno) {
			/* �����Ͻ����� recno һ��ȶ� */
			cmp = recno - tagp[pos].recno;
		}
		return cmp;
	}

	tail = TagNum;

	if (!cmp) {
		if (op != TAG_TOGGLE) {
			return NA;
		}

		TagNum = --tail;
		memcpy(&tagp[pos], &tagp[pos + 1], (tail - pos) * sizeof(TagItem));
		return -1;
	}

	if (tail < TAG_MAX) {
		TagItem	buf[TAG_MAX];

		TagNum = tail + 1;
		tail = (tail - head) * sizeof(TagItem);
		tagp += head;
		memcpy(buf, tagp, tail);
		tagp->chrono = chrono;
		tagp->recno = recno;
		memcpy(++tagp, buf, tail);
		return YEA;
	}

	/* TagList is full */
	return 0;
}



