/*
 *  $Id: user_register_main.c,v 1.3 2000/11/07 14:21:13 jeffhung Exp $
 */

#undef DEBUG_USER_REGISTER_MAIN

#include <stdio.h>
#include "w3if_user.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 7) {
		printf("Usage: %s <session-id> <new-id> <new-password> "
		       "<new-nick> <new-realname> <new-address>\n", argv[0]);
		return 0;
	}

	ret = user_register(fileno(stdout), argv[1], argv[2], argv[3], argv[4],
	                    argv[5], argv[6]);

	if (ret < 0) {
#ifdef DEBUG_USER_REGISTER_MAIN
		fprintf(stderr, "user_register error(%d).\n", ret);
#endif /* DEBUG_USER_REGISTER_MAIN */
	}

	return 0;
}

