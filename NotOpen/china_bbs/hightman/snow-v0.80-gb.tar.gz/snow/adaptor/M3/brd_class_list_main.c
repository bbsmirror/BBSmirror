/*
 *  $Id: brd_class_list_main.c,v 1.3 2000/10/23 17:56:39 jeffhung Exp $
 */

#include <stdio.h>
#include <stdlib.h>
#include "w3if_brd.h"


int main(int argc , char *argv[])
{
	int return_val;

	if (argc != 6) {
		fprintf(stderr, 
"usage: UserID Channel Top Range Mode\n"
"/* ------------------------------------------------------------ */\n"
"/* Argument: ofd     : output file descriptor                   */\n"
"/*           username: ʹ����ID                                 */\n"
"/*           channel : ��һ������Ƶ��( -2Ϊ��Ƶ�� )             */\n"
"/*           top     : ��ʼ��λ��                               */\n"
"/*           range   : ��top������ķ�Χ                        */\n"
"/*           mode    : ��һ��Mode(BFO_NONE/BFO_YANK/BFO_ENJOY)  */\n"
"/*                               ( 0 / 1 / 2 )                  */\n"
"/* ------------------------------------------------------------ */\n"
		);
		return -1;
	}

	return_val = brd_class_list(fileno(stdout),argv[1], atoi(argv[2]),
	                            atoi(argv[3]), atoi(argv[4]), atoi(argv[5]));

	return return_val;
}


