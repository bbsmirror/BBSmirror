/*
 *  $Id: bbs_login.c,v 1.9 2000/11/07 14:21:11 jeffhung Exp $
 */

#undef DEBUG_BBS_LOGIN

#include <time.h>
#include <sys/param.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/uio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "bbs.h"
#include "dao.h"
#include "w3if_bbs.h"
#include "w3ifglobal.h"
#include "w3if_session.h"
#include "w3if_general.h"
#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */

#ifdef AS_ARNI_MODULE

int mod_bbs_login(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return bbs_login(ofd, sid, parg->args[0].s, parg->args[1].s,
	                 parg->args[2].s, parg->args[3].s, parg->args[4].s);
}

#endif /* AS_ARNI_MODULE */

#define FN_BADLOGIN "logins.bad"

static char   iprec[1024];
static u_long tn_addr;
static char   *sess_fromhost;

#if 0 /* JeffHung.20000904: ���� lib/talk_lib.c */

#define PAL_MAX (200)

static int    pal_count;
static int    *pal_pool;

static int int_cmp(int *a, int *b)
{
	return *a - *b;
}

void pal_cache()
{
	int  count;
	int  fsize;
	int  ufo;
	int  *plist;
	int  *cache;
	PAL  *phead;
	PAL  *ptail;
	char *fimage;
	char fpath[MAXPATHLEN];

	if ((cache = pal_pool)) {
		free(cache);
	}
	cache = 0;
	count = 0;
	ufo = cuser.ufo & ~(UFO_REJECT | UFO_FCACHE);

	usr_fpath(fpath, cuser.userid, FN_PAL);
	fimage = f_img(fpath, &fsize);

	if (fimage) {
		if (fsize > PAL_MAX * sizeof(PAL)) {
			snprintf(fpath, MAXPATHLEN, "%-13s%d\n", cuser.userid, fsize);
			f_cat("run/pal", fpath);
			fsize = PAL_MAX * sizeof(PAL);
		}

		count = fsize / sizeof(PAL);
		if (count) {
			cache = plist = (int*)malloc(sizeof(int) * count);
			phead = (PAL*)fimage;
			ptail = (PAL*)(fimage + fsize);
			do {
				if (phead->ftype & PAL_BAD) {
					ufo |= UFO_REJECT;
					--count;
				}
				else {
					*plist++ = phead->userno;
				}
			} while (++phead < ptail);

			if (count > 0) {
				ufo |= UFO_FCACHE;
				if (count > 1) {
					xsort(cache, count, sizeof(int), int_cmp);
				}
			}
			else {
				free(cache);
				cache = 0;
			}
		}
		free(fimage);
	} /* if (fimage) */

	pal_pool = cache;
	pal_count = count;

	if (cutmp) {
		ufo = (ufo & ~UFO_UTMP_MASK) | (cutmp->ufo & UFO_UTMP_MASK);
		cutmp->ufo = ufo;
	}
	cuser.ufo = ufo;
}

#endif /* 0 */



/* '-' login failure   ' ' success */
static void logattempt(int type)
{
	char buf[128];
	char fpath[MAXPATHLEN];

	/* Thor.991014: ���� Btime()����ϸ */
	sprintf(buf, "%s %cBBS\t%s\n", Btime(&ap_start), type, iprec);
	usr_fpath(fpath, cuser.userid, "log");
	f_cat(fpath, buf);

	if (type != ' ') {
		usr_fpath(fpath, cuser.userid, FN_BADLOGIN);
		sprintf(buf, "[%s] %s\n", Ctime(&ap_start),
		        ((type == '*') ? iprec : sess_fromhost));
		f_cat(fpath, buf);
	}
}


#if 0 /* JeffHung.20000829: already defined in lib/acct_lib.c */

void blog(char *mode, char *msg)
{
	char   buf[512];
	char   data[256];
	time_t now;

	time(&now);
	if (!msg) {
		msg = data;
		sprintf(data, "Stay: %d (%d)", (now - ap_start) / 60, getpid());
	}

	sprintf(buf, "%s %s %-13s%s\n", Etime(&now), mode, cuser.userid, msg);
	f_cat(FN_USIES, buf);
}

#endif /* 0 */

#if 1 /* JeffHung.20000929: already defined in lib/cache_lib.c */
      /* JeffHung.20000929: we have to use this version of utmp_new() */
      /*
       * JeffHung.20001103:
       * change static utmp_new() to bbs_login_utmp_new() in order to
       * avoid name conflict
       */

static int bbs_login_utmp_new(UTMP* up)
{
	UCACHE *xshm;
	UTMP   *uentp;
	UTMP   *utail;

	/* semaphore : critical section */
#ifdef HAVE_SEM
	sem_lock(BSEM_ENTER);
#endif /* HAVE_SEM */

	xshm = ushm;
	uentp = xshm->uslot;
	utail = uentp + MAXACTIVE;

	do {
		if (!uentp->pid) {
			usint offset;

#if 0
			/*
			 * JeffHung.20001107:
			 * lint: arning: cannot do pointer arithmetic on operand of
			 * unknown size
			 */
			offset = (void*)uentp - (void*)xshm->uslot;
#else /* 0 */
			offset = (char*)uentp - (char*)xshm->uslot;
#endif /* 0 */
			memcpy(uentp, up, sizeof(UTMP));
			++(xshm->count);
			if (xshm->offset < offset) {
				xshm->offset = offset;
			}
			cutmp = uentp;

#ifdef HAVE_SEM
			sem_lock(BSEM_LEAVE);
#endif /* HAVE_SEM */

			return 0;
		}
	} while (++uentp < utail);

	/* Thor:����user���˵���һ���� */

#ifdef HAVE_SEM
	sem_lock(BSEM_LEAVE);
#endif /* HAVE_SEM */

	return 999; /* utmp is fulled. */
}

#endif /* 0 */


static int utmp_setup(int mode)
{
	UTMP utmp;

	cutmp = 0; /* Thor.980805: pal_cache�л� check cutmp  */
	pal_cache();

	memset(&utmp, 0, sizeof(utmp));
	utmp.pid = getpid();
	utmp.userno = cuser.userno;
	utmp.mode = mode;
	utmp.in_addr = tn_addr;
	utmp.ufo = cuser.ufo;

	strcpy(utmp.userid, cuser.userid);
	strcpy(utmp.username, cuser.username);
	strncpy(utmp.from, sess_fromhost, sizeof(utmp.from));

	if (bbs_login_utmp_new(&utmp)) {
		return 999; /* utmp is fulled. */
	}

	return 0;
}


#if 0 /* JeffHung.20000829: already defined in lib/cache_lib.c */

UTMP *utmp_find(int userno)
{
	UTMP *uentp;
	UTMP *uceil;

	uentp = ushm->uslot;
	uceil = (UTMP*)((void*)uentp + ushm->offset);

	do {
		if (uentp->userno == userno) {
			return uentp;
		}
	} while (++uentp <= uceil);

	return 0;
}

#endif /* 0 */

#if 0 /* JeffHung.20000829: don't use is_pal() to reduce complexity */

/* JeffHung.20000829: need initailized pal_pool and pal_count. >< */
/* JeffHung.20000904: ���� lib/talk_lib.c */

int is_pal(int userno)
{
	int count;
	int *cache;
	int datum;
	int mid;

	/* JeffHung.20000829: a typical binary search */
	if (cache = pal_pool) {
		for (count = pal_count; count > 0; ) {
			datum = cache[mid = count >> 1];
			if (userno == datum) {
				return 1;
			}
			if (userno > datum) {
				cache += (++mid);
				count -= mid;
			}
			else {
				count = mid;
			}
		}
	}
	return 0;
}

#endif /* 0 */

#if 0 /* JeffHung.20000829: already defined in lib/mail_lib.c */

int m_query(char *userid)
{
	int         fd;
	int         ans;
	int         fsize;
	HDR         *head;
	HDR         *tail;
	char        folder[MAXPATHLEN];
	struct stat st;

	ans = 0;
	usr_fpath(folder, userid, fn_dir);
	if ((fd = open(folder, O_RDONLY)) >= 0) {
		fsize = 0;

		if (!fstat(fd, &st) && ((fsize = st.st_size) >= sizeof(HDR)) &&
		    (head = (HDR*)malloc(fsize))) {
			if ((fsize = read(fd, head, fsize)) >= sizeof(HDR)) {
				tail = (HDR*)((char*)head + fsize);

				while (--tail >= head) {
					if (!(tail->xmode & MAIL_READ)) {
						ans = UFO_BIFF;
						break;
					}
				}
			}
			free(head);
		}

		close(fd);
		if (fsize < sizeof(HDR)) {
			unlink(folder);
		}
	}

	return ans;
}

#endif /* 0 */

/*
 *  JeffHung.20000829:
 *
 *  need initailized ushm. ><
 */
static int bmw_send(UTMP *callee, BMW *bmw)
{
	BMW    *mpool;
	BMW    *mhead;
	BMW    *mtail;
	BMW    **mslot;
	int    i;
	pid_t  pid;
	time_t texpire;

	if ((callee->userno != bmw->recver) || (pid = callee->pid) <= 0) {
		return 1;
	}

	/* sem_lock(BSEM_ENTER); */

	/* find callee's available slot */

	mslot = callee->mslot;
	i = 0;

	for (;;) {
		if (mslot[i] == 0) {
			break;
		}

		if (++i >= BMW_PER_USER) {
			/* sem_lock(BSEM_LEAVE); */
			return 1;
		}
	}

	/* find available BMW slot in pool */

	texpire = time(&bmw->btime) - BMW_EXPIRE;

	mpool = ushm->mpool;
	mhead = ushm->mbase;
	if (mhead < mpool) {
		mhead = mpool;
	}
	mtail = mpool + BMW_MAX;

	do {
		if (++mhead >= mtail) {
			mhead = mpool;
		}
	} while (mhead->btime > texpire);

	*mhead = *bmw;
	ushm->mbase = mslot[i] = mhead;
	/*
	 *  Thor.981206:
	 *
	 *  ��ע��, ��ushm mapping��ͬ, ��ֻͬ bbsd ��call��core dump,
	 *  ������Ҳ��offset, �������� -i, Ӧ���ǷǱ�Ҫ
	 */

	/* sem_lock(BSEM_LEAVE); */

	/* JeffHung.20000829: Codes below should be modified for web interface. */
	return kill(pid, SIGUSR2);
}

#ifdef LOGIN_NOTIFY


void loginNotify()
{
	UTMP *up;
	UTMP *ubase;
	UTMP *uceil;
	int  fd;
	char fpath[MAXPATHLEN];
	BMW  *bmw;
	BMW  benz;
	int  userno;

	usr_fpath(fpath, cuser.userid, FN_BENZ);

	if ((fd = open(fpath, O_RDONLY)) >= 0) {
		benz.caller = cutmp;
		benz.sender = 0; /* Thor.980805: ϵͳЭѰΪ���� call in */
		strcpy(benz.userid, cuser.userid);
		snprintf(benz.msg, 70, "�� �ո�̤��%s���� [ϵͳЭѰ] ��", BOARDNAME);

		ubase = ushm->uslot;
#if 0
		/* 
		 * JeffHung.20001107:
		 * lint: arning: cannot do pointer arithmetic on operand of
		 * unknown size
		 */
		uceil = (UTMP*)((void*)ubase + ushm->offset);
#else /* 0 */
		uceil = (UTMP*)((char*)ubase + ushm->offset);
#endif /* 0 */

		mgets(-1);
		while ((bmw = mread(fd, sizeof(BMW))) != 0) {
			/* Thor.1030:ֻ֪ͨ���� */

			up = bmw->caller;
			userno = bmw->recver;

			if (up >= ubase &&
			    up <= uceil &&
			    up->userno == userno &&
				/* Thor.980804: ������վ��֪ͨ, վ����Ȩ */
			    !(cuser.ufo & UFO_CLOAK)) {

#if 0 /* JeffHung.20000829: don't use is_pal() to reduce complexity */
				/* lkchu.980806: ���Ѳſ��� reply */
				benz.sender = is_pal(userno) ? cuser.userno : 0;
#else /* 0 */
				benz.sender = 0;
#endif /* 0 */

				benz.recver = userno;
				bmw_send(up, &benz);
			}
		}
		close(fd);
		unlink(fpath);
	}
}

#endif /* LOGIN_NOTIFY */

#ifdef HAVE_ALOHA

void aloha()
{
	UTMP        *up;
	UTMP        *ubase;
	UTMP        *uceil;
	int         fd;
	char        fpath[MAXPATHLEN];
	BMW         *bmw;
	BMW         benz;
	int         userno;
	struct stat st;

	/* lkchu.981201: ����֪ͨ */

	usr_fpath(fpath, cuser.userid, FN_FRIEND_BENZ);

	if (((fd = open(fpath, O_RDONLY)) >= 0) &&
	    !fstat(fd, &st)
	    && (st.st_size > 0)) {

		benz.caller = cutmp;
		benz.sender = 0; /* Thor.980805: ϵͳЭѰΪ���� call in */
		strcpy(benz.userid, cuser.userid);
		snprintf(benz.msg, 70, "�� �ո�̤��%s���� [������վ] ��", BOARDNAME);

		ubase = ushm->uslot;
#if 0
		/*
		 * JeffHung.20001107:
		 * lint: arning: cannot do pointer arithmetic on operand of
		 * unknown size
		 */
		uceil = (UTMP*)((void*)ubase + ushm->offset);
#else /* 0 */
		uceil = (UTMP*)((char*)ubase + ushm->offset);
#endif /* 0 */

		mgets(-1); /* reset mread() */
		while ((bmw = (BMW*)mread(fd, sizeof(BMW))) != 0) {
			/* Thor.1030:ֻ֪ͨ���� */
			userno = bmw->recver;
			up = utmp_find(userno); /* lkchu.981201: frienz �е� utmp ��Ч */
			if (up >= ubase &&
			    up <= uceil &&
			    up->userno == userno &&
			    /* Thor.980804: ������վ��֪ͨ, վ����Ȩ */
			    !(cuser.ufo & UFO_CLOAK) &&
			    /* lkchu.981201: �Է�Ҫ�򿪡�������վ֪ͨ����֪ͨ */
			    (up->ufo & UFO_ALOHA)) {

#if 0 /* JeffHung.20000829: don't use is_pal() to reduce complexity */
				if (is_pal(userno)) { /* lkchu.980806: ���Ѳſ��� reply */
					benz.sender = cuser.userno;
				}
				else {
					benz.sender = 0;
				}
#else /* 0 */
				benz.sender = 0;
#endif /* 0 */

				benz.recver = userno;
				bmw_send(up, &benz);
			}
		} /* while (read a bmw) */
		close(fd);
	} /* if (file opened) */
}

#endif /* HAVE_ALOHA */


int bbs_login(int ofd, char *sid, char *userid, char *password,
              char *rusername, char *fromhost, char *fromip)
{
	usint  level;
	char   w3if_fromhost[34];
	usint  ufo;
	char   buf[80];
	char   fpath[MAXPATHLEN];
	int    fd;
	char   obuf[GENERAL_BUFSIZE];

	chdir(BBSHOME);

#ifdef DEBUG_BBS_LOGIN
	fprintf(stderr, "DEBUG(%s,%d): enter bbs_login():sid:%s\n",
	        __FILE__, __LINE__, sid);
#endif /* DEBUG_BBS_LOGIN */

	write(ofd, "MRR-RESULT:bbs_login\n", strlen("MRR-RESULT:bbs_login\n"));

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

	snprintf(w3if_fromhost, 33, "%c%s", W3IF_FROM_TAG, fromhost);
	sess_fromhost = w3if_fromhost;
	time(&ap_start);
	if (strlen(fromip) > INET_ADDRSTRLEN) {
		fromip[INET_ADDRSTRLEN] = 0;
	}
	if (!inet_pton(AF_INET, fromip, (void*)&tn_addr)) {

#ifdef DEBUG_BBS_LOGIN
		fprintf(stderr, "DEBUG(%s,%d): invalid fromip\n", __FILE__, __LINE__);
#endif /* DEBUG_BBS_LOGIN */

		write(ofd, "LOGIN-RESULT:Invalid from ip\nMRR-END:\n",
		      strlen("LOGIN-RESULT:Invalid from ip\nMRR-END:\n"));

		return -999; /* invalid fromip */
	}
	sprintf(iprec, "%s@%s ip:%08lx", rusername, w3if_fromhost, tn_addr);

#ifdef DEBUG_BBS_LOGIN
	fprintf(stderr, "DEBUG(%s,%d): iprec: %s\n", __FILE__, __LINE__, iprec);
#endif /* DEBUG_BBS_LOGIN */

	if (!userid || !*userid) {

#ifdef DEBUG_BBS_LOGIN
		fprintf(stderr, "DEBUG(%s,%d): there should have something"
		        " in userid\n", __FILE__, __LINE__);
#endif /* DEBUG_BBS_LOGIN */

		write(ofd, "LOGIN-RESULT:Invalid input\nMRR-END:\n",
		      strlen("LOGIN-RESULT:Invalid input\nMRR-END:\n"));

		return -999; /* there should have something in userid */
	}
	if (!strcasecmp(userid, "new")) {

#ifdef DEBUG_BBS_LOGIN
		fprintf(stderr, "DEBUG(%s, %d): register new account as new"
		        " not allowed through this module\n",
		        __FILE__, __LINE__);
#endif /* DEBUG_BBS_LOGIN */

		write(ofd, "LOGIN-RESULT:Register as new here is not allowed\n"
		           "MRR-END:\n",
		      strlen("LOGIN-RESULT:Register as new here is not allowed\n"
		             "MRR-END:\n"));

		return 999; /* not allowed */
	}

#ifdef DEBUG_BBS_LOGIN
	fprintf(stderr, "DEBUG(%s,%d): address of cuser: %p\n",
	        __FILE__, __LINE__, &cuser);
#endif /* DEBUG_BBS_LOGIN */

	if (acct_load(&cuser, userid) < 0) {

#ifdef DEBUG_BBS_LOGIN
		fprintf(stderr, "DEBUG(%s,%d): no such user: %s\n",
		        __FILE__, __LINE__, userid);
#endif /* DEBUG_BBS_LOGIN */

		write(ofd, "LOGIN-RESULT:No such user\nMRR-END:\n",
		      strlen("LOGIN-RESULT:No such user\nMRR-END:\n"));

		return 999; /* no such user */
	}
	else if (strcasecmp(userid, STR_GUEST)) { /* if (!guest) */
		if (strlen(password) > 8) {
			password[8] = 0;
		}
		if (chkpasswd(cuser.passwd, password)) {
			logattempt('-');

			write(ofd, "LOGIN-RESULT:Invalid password\nMRR-END:\n",
			      strlen("LOGIN-RESULT:Invalid password\nMRR-END:\n"));

			return 999; /* wrong password */
		}

		if (!strcmp(cuser.userid, "SYSOP")) {
#ifndef LINTHACK_SIGNED_UNSIGNED_CAST
			cuser.userlevel = ~0 ^ (PERM_DENYMAIL | PERM_DENYTALK |
			                        PERM_DENYCHAT | PERM_DENYPOST);
#else /* LINTHACK_SIGNED_UNSIGNED_CAST */
			cuser.userlevel = (unsigned long)
			                  ~0 ^ (PERM_DENYMAIL | PERM_DENYTALK |
			                        PERM_DENYCHAT | PERM_DENYPOST);
#endif /* LINTHACK_SIGNED_UNSIGNED_CAST */
		}

		level = cuser.userlevel;

		ufo = cuser.ufo & ~(HAS_PERM(PERM_LOGINCLOAK) ?
		                    (UFO_BIFF | UFO_SOCKET) :
		                    (UFO_BIFF | UFO_SOCKET | UFO_CLOAK));

		if ((level & PERM_ADMIN) && (ufo & UFO_ACL)) {
			usr_fpath(fpath, cuser.userid, "acl");
			str_lower(rusername, rusername);
			str_lower(w3if_fromhost, w3if_fromhost);
			if (!acl_has(fpath, rusername, w3if_fromhost)) {
				/*
				 *   Thor.980728:
				 *
				 *   ע�� acl��, �� rusername, w3if_fromhost Ҫȫ��Сд
				 */
				logattempt('*');

				write(ofd, "LOGIN-RESULT:Invalid fromhost\nMRR-END:\n",
				      strlen("LOGIN-RESULT:Invalid fromhost\nMRR-END:\n"));

				return 999; /* ��վ�ص㲻̫�Ծ�����˶� [��վ�ص��趨��] */
			}
		}

		logattempt(' ');

		/* check for multi-session */
		/* JeffHung:20000828: ��Ϊ web �����ƣ��ݲ������ṩ multi-session��*/
		if (!(level & PERM_SYSOP) && utmp_find(cuser.userno)) {

			write(ofd, "LOGIN-RESULT:Multi-login denied\nMRR-END:\n",
			      strlen("LOGIN-RESULT:Multi-login denied\nMRR-END:\n"));

			return 999; /* deny multi-login */
		}

	}
	else { /* if (!guest) */
		logattempt(' ');
		cuser.userlevel = level = 0;
		ufo = UFO_COLOR | UFO_PAGER | UFO_BNOTE | UFO_MOVIE;
	} /* if (!guest) */

	/*
	 *  ����ϵͳ
	 */

	sprintf(buf, "%s (%d)", iprec, currpid);
	blog("ENTER", buf);
	if (rusername[0]) {
		strcpy(cuser.ident, iprec);
	}

	/* initialize utmp, flag, mode */
	cuser.ufo = ufo;
	if (utmp_setup(M_LOGIN)) { /* Thor.980917: ע��: cutmp, cutmp-> setup ok */

		write(ofd, "LOGIN-RESULT:UTMP is full\nMRR-END:\n",
		      strlen("LOGIN-RESULT:UTMP is full\nMRR-END:\n"));
	
		return 999; /* JeffHung.20000828: utmp is full. */
	}


#ifdef MY_FAVORITE
#if 0 /* JeffHung.20000829: �� bbs_login ��ʽ������cache ҲûЧ����*/
	/* Arlo.20000710: �Ȱ�favorite board list�ŵ�cache�� */
	fab_cache();
#endif /* 0 */
#endif /* MY_FAVORITE */

#ifdef MODE_STAT
#if 0 /* JeffHung.20000828: What's this for? */
	memset(&modelog, 0, sizeof(UMODELOG));
	mode_lastchange = ap_start;
#endif /* 0 */
#endif /* MODE_STAT */

	if (level) { /* if (!guest) */
#ifdef JUSTIFY_PERIODICAL
		if ((level & PERM_VALID) && !(level && PERM_SYSOP)) {
			/* Thor.980819: վ����������������֤, ex. SysOp  */
			if (cuser.tvalid + VALID_PERIOD < ap_start) {
				level ^= PERM_VALID;
			}
		}
#endif /* JUSTIFY_PERIODICAL */

		level |= (PERM_POST | PERM_PAGE | PERM_CHAT);

		if (!(level & PERM_SYSOP)) { /* if (!sysop) */
#ifdef NEWUSER_LIMIT
			/*
			 *  Thor.980825: lkchu patch:
			 *
			 *  ��Ȼ�� NEWUSER_LIMIT, ���Ǽ�һ�º���, ����һֱ�ش� FAQ
			 *  ͦ�۵�. :)
			 */
			if (ap_start - cuser.firstlogin < 3 * 86400) {
				level &= ~PERM_POST; /* ��ʹ�Ѿ�ͨ����֤������Ҫ��ϰ���� */
			}
#endif /* NEWUSER_LIMIT */
			/* Thor.980629: δ��������֤, ��ֹ chat/talk/write */
			if (!(level & PERM_VALID)) {
				level &= ~(PERM_CHAT | PERM_PAGE);
			}

			if (level & PERM_DENYPOST) {
				level &= ~PERM_POST;
			}

			if (level & PERM_DENYTALK) {
				level &= ~PERM_PAGE;
			}

			if (level & PERM_DENYCHAT) {
				level &= ~PERM_CHAT;
			}

			if ((cuser.numemail >> 4) > (cuser.numlogins + cuser.numposts)) {
				level |= PERM_DENYMAIL;
			}
		} /* if (!sysop) */

		cuser.userlevel = level;

		/* ��������ͬ�������������ż� */

		if (ap_start > cuser.tcheck + CHECK_PERIOD) {

#if 0 /* JeffHung.20000829: we just pal_cache(), right?! ^^ */
			pal_sync(NULL); /* Thor.990318: �������֤�ŵĻ��ʲ���:P */
#endif /* 0 */

			/* Thor.980804: ע��, �������������а��� BIFF check */
			ufo |= m_quota();

			cuser.ufo = ufo;
			cuser.tcheck = ap_start;
		}
		else {
			ufo = (ufo & ~UFO_MQUOTA) | m_query(cuser.userid);
		}
		cutmp->ufo = cuser.ufo = ufo; /* Thor.980805: ��� ufo ͬ������ */

		/* �� .ACCT д�� */

		cuser.lastlogin = ap_start;
		strncpy(cuser.lasthost, w3if_fromhost, sizeof(cuser.lasthost));
		usr_fpath(fpath, cuser.userid, fn_acct);
		fd = open(fpath, O_WRONLY);
		write(fd, &cuser, sizeof(ACCT));
		close(fd);

		/* JeffHung.20000828: ȱ: ���������ʾ��ɾ�� */

		if (!(level & PERM_VALID)) {
			 /* ��Чʱ������ 10 ��ǰ������� */
			;
		}
#ifdef JUSTIFY_PERIODICAL
		else if (!(level & PERM_SYSOP)) {
			if (cuser.tvalid + VALID_PERIOD - 10 * 86400 < ap_start) {
				/* ������֤ */
				;
			}
		}
#endif /* JUSTIFY_PERIODICAL */

#ifdef NEWUSER_LIMIT
		/*
		 *  Thor.980825: lkchu patch:
		 *
		 *  ��Ȼ�� NEWUSER_LIMIT, ���Ǽ�һ�º���, ����һֱ�ش� FAQ ͦ��
		 *  ��. :)
		 */
		if (ap_start - cuser.firstlogin < 3 * 86400) {
			/* ��ʾ������· */
			;
		}

#endif /* NEWUSER_LIMIT */

		if (ufo & UFO_MQUOTA) {
			/* ��ʾ����ʹ�ù��� */
			;
		}

#ifdef LOGIN_NOTIFY

		if (!(ufo & UFO_CLOAK)) { /* lkchu.981201: �Լ������Ͳ��� notify */
			void loginNotify();
			loginNotify();
		}
		else {
			/* lkchu.981201: ��� benz, ��֪ͨ�� */
			usr_fpath(fpath, cuser.userid, FN_BENZ);
			unlink(fpath);
		}

#endif /* LOGIN_NOTIFY */

#ifdef HAVE_ALOHA

		if (!(ufo & UFO_CLOAK)) { /* lkchu.981201: �Լ������Ͳ��� notify */
			void aloha();
			aloha();
		}
#endif /* HAVE_ALOHA */

	} /* if (!guest) */

	w3ifsession_insert(sid, cutmp);

	snprintf(obuf, GENERAL_BUFSIZE,
	         "USERID:%s\n"
	         "USERNAME:%s\n"
	         "LOGIN-RESULT:OK\n"
	         "MRR-END:\n",
	         cuser.userid, cuser.username);
	write(ofd, obuf, strlen(obuf));

	return 0;
}

