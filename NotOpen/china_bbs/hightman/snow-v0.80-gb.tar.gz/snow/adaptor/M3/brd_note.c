/*
 *  $Id: brd_note.c,v 1.5 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_BRD_NOTE

#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */
#include "w3if_brd.h"
#include <sys/param.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include "w3if_general.h"
#include "bbs.h"
#include <unistd.h>
#include <sys/uio.h>
#include <string.h>


#ifdef AS_ARNI_MODULE

/* ARGSUSED 1 */

int mod_brd_note(int ofd, char *sid, struct ARNI_ARGS *parg)
{
    return brd_note(ofd, parg->args[0].s);
}

#endif /* AS_ARNI_MODULE */

int brd_note(int ofd, char *brdname)
{
	char        fpath[MAXPATHLEN];
	struct stat st;
	FILE        *fp;
	int         i;
	int         len;
	char        buf[GENERAL_BUFSIZE];

	chdir(BBSHOME);

	write(ofd, "MRR-RESULT:brd_note\n", strlen("MRR-RESULT:brd_note\n"));

	if (strlen(brdname) > IDLEN) {
		brdname[IDLEN] = 0;
	}

	/* todo: check if brdname exist */

	snprintf(fpath, MAXPATHLEN, "brd/%s/note", brdname);

	if (lstat(fpath, &st) < 0) {

#ifdef DEBUG_BRD_NOTE
		fprintf(stderr, "DEBUG(%s,%d):no such file\n", __FILE__, __LINE__);
#endif /* DEBUG_BRD_NOTE */

		write(ofd, "RESULT:no such file\nMRR-END:\n",
		      strlen("RESULT:no such file\nMRR-END:\n"));
		return 0;
	}

	if (!(fp = fopen(fpath, "r"))) {

#ifdef DEBUG_BRD_NOTE
		fprintf(stderr, "DEBUG(%s,%d):cannot open file: %s\n",
		        __FILE__, __LINE__, fpath);
#endif /* DEBUG_BRD_NOTE */

		write(ofd, "RESULT:cannot open file\nMRR-END:\n",
		      strlen("RESULT:cannot open file\nMRR-END:\n"));
		return -999; /* cannot open file */
	}

	for (i = 0; fgets(buf, GENERAL_BUFSIZE, fp); ++i) {
		if (i == 0) {
			write(ofd, "BODY:", strlen("BODY"));
		}
		else {
			write(ofd, "CONTINUE:", strlen("CONTINUE:"));
		}
		len = strlen(buf);
		if (write(ofd, buf, len) < 0) {
			fclose(fp);
			write(ofd, "RESULT:write error\nMRR-END:\n",
			      strlen("RESULT:write error\nMRR-END:\n"));
			return -2;
		}
	}

	fclose(fp);

	write(ofd, "RESULT:OK\nMRR-END:\n",
	      strlen("RESULT:OK\nMRR-END:\n"));
	return 0;
}

