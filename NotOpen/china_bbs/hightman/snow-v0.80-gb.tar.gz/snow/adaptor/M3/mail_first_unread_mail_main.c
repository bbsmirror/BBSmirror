/*
 * $Id: mail_first_unread_mail_main.c,v 1.5 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_MAIL_FIRST_UNREAD_MAIL_MAIN

#include <stdio.h>
#include "w3if_mail.h"

int main(int argc, char* argv[])
{
	int	fd;
	int	ret;

	if (argc != 2) {
		printf("Usage: %s <user-id>\n", argv[0]);
		return 0;
	}

	fd = fileno(stdout);
	ret = mail_first_unread_mail(fd, argv[1]);

	if (ret != 0) {
#ifdef DEBUG_MAIL_FIRST_UNREAD_MAIL_MAIN
		fprintf(stderr, "mail_first_unread_mail error(%d).\n", ret);
#endif /* DEBUG_MAIL_FIRST_UNREAD_MAIL_MAIN */
	}

	return 0;
}

