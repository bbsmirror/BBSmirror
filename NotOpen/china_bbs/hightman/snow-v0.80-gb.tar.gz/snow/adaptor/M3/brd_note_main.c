/*
 *  $Id: brd_note_main.c,v 1.4 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_BRD_NOTE_MAIN

#include <stdio.h>
#include "w3if_brd.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 2) {
		printf("Usage: %s <brd-id>\n", argv[0]);
		return 0;
	}

	ret = brd_note(fileno(stdout), argv[1]);

	if (ret < 0) {
#ifdef DEBUG_BRD_NOTE_MAIN
		fprintf(stderr, "brd_note error(%d).\n", ret);
#endif /* DEBUG_BRD_NOTE_MAIN */
	}

	return 0;
}

