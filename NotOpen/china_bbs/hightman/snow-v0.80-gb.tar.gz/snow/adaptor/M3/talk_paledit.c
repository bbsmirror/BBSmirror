/*
 *  $Id: talk_paledit.c,v 1.6 2000/10/25 12:31:55 jeffhung Exp $
 */

#undef DEBUG_TALK_PALEDIT

#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */
#include "w3if_talk.h"
#include "w3if_session.h"
#include "bbs.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/uio.h>
#include "w3ifglobal.h"
#include <string.h>
#include "dao.h"


#ifdef AS_ARNI_MODULE

int mod_talk_paledit(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return talk_paledit(ofd, sid, parg->args[0].s, parg->args[1].s,
	                   parg->args[2].i);
}

#endif /* AS_ARNI_MODULE */

#if 0 /* JeffHung.20000930: already defined in w3ifglobal.c */

int is_samepal(int userno, PAL *pal)
{
	return (userno == pal->userno);
}

#endif /* 0 */


int talk_paledit(int ofd, char *sid, char *palid, char *friendship, int is_bad)
{
	W3IF_SESSENTRY *psess;
	ACCT           palacct;
	int            userno;
	PAL            pal;
	int            palno;
	char           fpath[MAXPATHLEN];

	chdir(BBSHOME);

	write(ofd, "MRR-RESULT:talk_paledit\n",
	      strlen("MRR-RESULT:talk_paledit\n"));

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

	if (!(psess = w3ifsession_get(sid))) {
		write(ofd, "RESULT:no such user\nMRR-END:\n",
		      strlen("RESULT:no such user\nMRR-END:\n"));
		return -999; /* no such user */
	}

	ap_start = psess->ap_start;
	cutmp = psess->utmp_entry;

	acct_load(&cuser, cutmp->userid);

	if (!cuser.userlevel) {
		write(ofd, "RESULT:no permission\nMRR-END:\n",
		      strlen("RESULT:no permission\nMRR-END:\n"));
		return 999; /* no permission */
	}

	acct_load(&palacct, palid);
	pal_cache(); /* JeffHung.20000904: load pal cache first */

	userno = palacct.userno;
	if (userno <= 0) {
		write(ofd, "RESULT:userno error\nMRR-END:\n",
		      strlen("RESULT:userno error\nMRR-END:\n"));
		return -999; /* userno error */
	}

	usr_fpath(fpath, cuser.userid, FN_PAL);
	if (!(palno = rec_search(fpath, (char*)&pal, sizeof(PAL), is_samepal,
	                         userno))) {
		write(ofd, "RESULT:no such pal\nMRR-END:\n",
		      strlen("RESULT:no such pal\nMRR-END:\n"));
		return -999; /* no such pal */
	}

	strncpy(pal.ship, friendship, sizeof(pal.ship));
	pal.ftype = is_bad ? PAL_BAD : 0;

	rec_put(fpath, &pal, sizeof(PAL), palno - 1);

	pal_cache(); /* JeffHung.20000904: ��������ͬ�� */

	write(ofd, "RESULT:OK\nMRR-END:\n",
	      strlen("RESULT:OK\nMRR-END:\n"));

	return 0;
}

