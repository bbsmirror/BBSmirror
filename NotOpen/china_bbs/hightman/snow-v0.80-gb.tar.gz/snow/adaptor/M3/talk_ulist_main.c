/*
 *  $Id: talk_ulist_main.c,v 1.6 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_TALK_ULIST_MAIN

#include <stdio.h>
#include <stdlib.h>
#include "w3if_talk.h"

int main(int argc, char *argv[])
{
	int return_val;

	if (argc < 5) {
		fprintf(stderr, 
"usage: UserID Top Range PickupWay\n"
" ----------------------------------------------------- \n"
"  fd      : output file descriptor                     \n"
"  username: User ID                                    \n"
"  top     : begin number                               \n"
"  range   : how many item to list                      \n"
"  way     : list sort way                              \n"
"            1:���� 2:���� 3:��Դ 4:��̬ 5:����         \n"
" ----------------------------------------------------- \n");
		return -1;
	}

	return_val = talk_ulist(fileno(stdout), argv[1], atoi(argv[2]),
	             atoi(argv[3]), atoi(argv[4]));
  
	return return_val;
}

