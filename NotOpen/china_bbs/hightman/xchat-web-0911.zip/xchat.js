var autoScrollOn = 1;
var scrollOnFunction;
var scrollOffFunction;

function scrollit(){
	if(!parent.d.document.inputform.as.checked){
		autoScrollOn=0;
		return true;
	}else {
		autoScrollOn=1;
		StartUp();
		return true;
	}
}

function scrollWindow( ){
	if ( autoScrollOn == 1 ){
		this.scroll(0, 99999);
		setTimeout('scrollWindow()',200);
	}
}

function scrollOn( ){
	autoScrollOn = 1;
	scrollWindow( );
}

function scrollOff( ){
	autoScrollOn = 0;
}

function StartUp( ){
	this.onblur  = scrollOnFunction;
	this.onfocus = scrollOffFunction;
	scrollWindow( );
}

scrollOnFunction = new Function('scrollOn( )')
scrollOffFunction = new Function('scrollOff( )')
StartUp();