<?php

/* write by hightman for WebXchat of MapleBBS 3.x 
 * date: 2001/09/11
 * email: hightman@263.net
 * notice: Please dont delete these messages! thanks you!
 */

$chaturl = "http://10.14.61.248:3636";	//��Ҫ�޸�

?>
<html>
<head>
<title>MapleBBS-3.x-������Web��</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<script language=JavaScript>
<!--	
var timerID=null;
var timerRunning=false;

function stop()
{
if(timerRunning)clearTimeout(timerID);
timerRunning=false;
}

function start()
{
stop();
}

function cs(name)
{
	if(this.d.document==null)
		return;

	this.d.add(name);
	this.d.document.inputform.talkto.value=name;
	this.d.document.inputform.msg.focus();
	return;
}

//-->
</script>
</head>
  <frameset rows="*,85,0" cols="*" border="0" framespacing="0">
     <frame src="<? echo $chaturl; ?>/chat?userid=<?echo $userid;?>&passwd=<?echo $passwd;?>&chatid=<? echo $chatid;?>&" name="u" frameborder="NO">
    <frame src="say.php?userid=<?echo $userid;?>&passwd=<?echo $passwd;?>&chatid=<? echo $chatid;?>&" name="d" frameborder="NO" noresize>
    <frame src="about:blank" name="bl">
  </frameset>
<noframes><body bgcolor="#FFFFFF" onLoad="start();">
�����������֧�ַ�֡������
</body></noframes>
</html>
				