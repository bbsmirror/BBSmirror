<?php
/*-------------------------------------------------------*/
/* webbbs.class.php  ( ZJU Shanty MapleBBS Ver 3.10 )    */
/*-------------------------------------------------------*/
/* target : PHP Class					 */
/* author : hightman.bbs@bbs.dot66.net			 */
/* create : 2001/09/20                                   */
/* update :                                              */
/*-------------------------------------------------------*/

class server_class {

  var $d_host = "localhost";
  var $d_port = 7000;
  
  var $fp = 0;
  var $errno = 0;
  var $errstr = "";
  var $data = "";
  
  function connect(){
  	if(0 == $this->fp){
  		$this->fp = fsockopen($this->d_host, $this->d_port, &$this->errno, &$this->errstr, 10);
  		if (!$this->fp) {
  			$this->halt("Link-FP: FALSE, ����������ʧ��!");
  		}  		
  	}
  }

  function set_cmd(){
    $numargs = func_num_args();
	$cmd = "PST /";
    $arg_list = func_get_args();
    for ($i = 0; $i < $numargs; $i++) {		
		if($i > 0)
			$cmd .= ($i == 1 ? "?" : "\t");
		$cmd .= $arg_list[$i];
    }
	$cmd .= "\n";
	return $cmd;
  }
  
  function query($cmd){
  	$this->data = "";
  	fputs($this->fp, $cmd);
  	while(!feof($this->fp)) 
 	{
    	 $this->data .= fgets($this->fp,128);
 	}
 	return $this->close($this->fp); 	
  }

  function send($cmd){
	return fputs($this->fp, $cmd);
  }

  function recv($maxlen){
	if(feof($this->fp)){
		$this->close($this->fp);
		return -1;
	}
	else
		return fgets($this->fp, $maxlen);
  }

  function parse($string = "") {
	  if($string == "")
		  $string = $this->data;

	  $string = str_replace("\n", "", $string);
	  $string = str_replace("+", "%2B", $string);
	  $string = str_replace(" ", "+", $string);
	  $result = array();
	  parse_str($string, $result); /* ͳһ��ϵͳ���� */
	  return $result;
  }

  function close(){
  	if($this->fp != 0) return @fclose($this->fp);
  }

  function my_read(&$buf, $maxlen){
	  $buf = ""; 
	  $i = $j = 0;

	  $maxlen--;
	  while($i < $maxlen) {
		  if(feof($this->fp)) {
			  $this->close();
			  return -1;
			  break;
		  }

		  $j = fread($this->fp, 1);
		  if($j === FALSE) {
			  $this->close();
			  return -1;
			  break;
		  }
		  else if ($j == "\0")
			  continue;
		  else if ($j == "\n")
			  break;
		  else if($j != "\r") {
			  $i++;
			  $buf .= $j;
		  }
	  }
	  $buf .= "\n";
	  return ++$i;
  }

  function halt($msg){
	$this->close();
  	$this->alert($msg."\\n".$this->errstr."(".$this->errno.")");
	exit;
  }
  
  function filter($string){
  	$string=addslashes($string);
	$string=eregi_replace("\n", "\\n", $string);
  	$string=eregi_replace("\\<html\\>([^\\<]*)\\<\/html\\>(.*)","\\1",$string);
  	return $string;
  }
  
  function alert($string){
  	$string = $this->filter($string);
  	echo "<script>alert('".$string."'); top.window.history.go(-1)</script>\n";
  	return;
  }
}
?>
