<?php
//Gem Read

require_once('config.php');

unset($cuser);
session_start();

$pid = $cuser[pid];
if(!$pid) {
	echo "<html>���Ѿ��Ͽ�����! �밴F5ˢ����ҳ!</html>";
	exit; 
}

if($page < 1) $page = 1;

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

?>
<html>
<head>
<title>Gem List</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #0000a0}
A:visited {color: #0000a0}
PRE {color: #000000}
</style>
</head>
<body leftmargin="3" topmargin="0" marginwidth="3" marginheight="0" bgcolor="#FFFFFF">
<table width="617" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td colspan="3"><img src="images/gem/gem_top.jpg" width="617" height="51" usemap="#Map" border="0"></td>
  </tr>
  <tr> 
    <td width="20" background="images/gem/gem_left_bg.jpg">&nbsp;</td>
    <td height="100%" width="585">
	   <table width='560' border='0' cellspacing='1' cellpadding='0' bgcolor='#ffffff'>

		<?php

		require_once('webbbs.class.php');
		require_once('ansi2web.inc.php');
		
		$ws = new server_class;
		$ws->connect();
		$cmd = $ws->set_cmd("gembrowse", G_GEM, $pid, $fpath, $num);

		$ws->query($cmd);
		$data = split("\n", $ws->data, 2);
		$ret = $ws->parse($data[0]);

		if($ret[result] != 'OK') {
			echo "<br><br>";
			echo alertMsg($ws->data);
			echo "<br><br><a href='#' onclick='window.history.back()'>[���˷���]</a>";
			exit;
		}	

		/* ����GoTo Page */
		$prv = $num-1;
		$nxt = $num+1;
		
		/* ����GoTo Page */
		$gotoString  = "�����Ķ�";
		if($num != 1)
			$gotoString .= " | <a href=\"".$PHP_SELF."?method=".$method."&fpath=".$fpath."&num=1\">��ƪ</a>";

		if($prv > 0)
			$gotoString .= " | <a href=\"".$PHP_SELF."?method=".$method."&fpath=".$fpath."&num=".$prv."\">��һƪ</a>";

		if($nxt <= $ret[max])
			$gotoString .= " | <a href=\"".$PHP_SELF."?method=".$method."&fpath=".$fpath."&num=".$nxt."\">��һƪ</a>";

		if($num != $ret[max])
			$gotoString .= " | <a href=\"".$PHP_SELF."?method=".$method."&fpath=".$fpath."&num=".$ret[max]."\">ĩƪ</a>";

		$gotoString .= " | <a href='gem_forward.php?fpath=$fpath&num=$num&title=".urlencode($ret[title])."'>ת��</a>";

		$gotoString .= " | <a href='#' onclick='window.history.back()'>�����ϲ�</a>";

        print "
		<tr height='20'> 
	      <td> ����: <font color='green'>$ret[title]</font> </td>
		</tr>		
		<tr bgcolor='#dddddd' height='20'><td>
		 $gotoString	
		</td></tr>
		<tr bgcolor='#000000' height='240' valign='top'> 
	      <td width='560'><pre style='color: f0f0f0'>";
		echo ansi2web($data[1]);
	    print "
		 </pre></td></tr>
		<tr bgcolor='#dddddd' height='20'><td>
		 $gotoString	
		</td></tr>
		";
		?>

      </table>	
	</td>
    <td background="images/gem/gem_right_bg.jpg" width="20">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="3" height="2"><img src="images/gem/gem_bottom.jpg" width="617" height="26"></td>
  </tr>
</table>
<map name="Map"> 
  <area shape="rect" coords="48,16,118,36" href="services.php" alt="վ�������" title="վ�������">
  <area shape="rect" coords="127,17,198,35" href="board.php" alt="��վ����������" title="��վ����������">
  <area shape="rect" coords="336,17,408,35" href="personal.php" alt="�ҵĸ���С��" title="�ҵĸ���С��">
  <area shape="rect" coords="417,17,487,36" href="talk.php" alt="����������" title="����������">
  <area shape="rect" coords="497,17,567,36" href="group.php" alt="Ⱥ�鹦����" title="Ⱥ�鹦����">
</map>
</body>
</html>