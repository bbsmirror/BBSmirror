<?php
//Read Mail No.

require_once('config.php');

unset($cuser);
session_start();

$pid = $cuser[pid];
$level = $cuser[level];
if(!$pid || !($level & PERM_BASIC)) {
	echo "<html>���ȵ�¼! <a href='main.php'> [���˷���] </a></html>";
	exit; 
}

if($num < 1) $num = 1;
$page = intval($num / XO_TALL);	/* ���page */
if($num % XO_TALL) $page++;

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

?>
 
<html>
<head>
<title>ReadSpecialMail</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #000080}
A:visited {color: #444480}
PRE {color: #c0c0c0}
</style>
<script language="JavaScript">
<!--
//-->
</script>
</head>
<body bgcolor="#ffffff" leftmargin="3" topmargin="0" marginwidth="3" marginheight="0">
<table width="635" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="80"><img src="images/mail_top.gif" width="474" height="80" usemap="#Map" border="0"></td>
  </tr>
  <tr>
    <td valign="top">
	
	<?php
	//maillist
	require_once('webbbs.class.php');
	require_once('ansi2web.inc.php');
	
	$ws = new server_class;
	$ws->connect();

	$cmd = $ws->set_cmd("readmail", G_MAIL, $pid, $num);
	$ws->query($cmd);

	$data = split("\n\n", $ws->data, 2);
	
	$ret = $ws->parse($data[0]);

	if($ret[result] != 'OK') {
		echo "<br><br>";
		echo alertMsg($ws->data);
		echo "<br><br><a href='maillist.php?page=$page'>[���˷���]</a>";
		exit;
	}
	
	$prv = $num-1;
	$nxt = $num+1;	
	
	/* ����GoTo Page */
	$gotoString  = "�Ķ��ż��� �� <font color=000000>".$num."</font> / ".$ret[max]." ��";
	if($num != 1) $gotoString .= " | <a href=\"".$PHP_SELF."?num=1\">�׷�</a>";
	if($prv > 0)  $gotoString .= " | <a href=\"".$PHP_SELF."?num=".$prv."\">��һ��</a>";
	if($nxt <= $ret[max]) $gotoString .= " | <a href=\"".$PHP_SELF."?num=".$nxt."\">��һ��</a>";
	if($num != $ret[max]) $gotoString .= " | <a href=\"".$PHP_SELF."?num=".$ret[max]."\">ĩ��</a>";

	if($ret[noreply])
		$gotoString .= " | �ظ�";
	else 
		$gotoString .= " | <a href=\"mail_reply.php?num=".$num."&page=".$page."\">�ظ�</a>";
	$gotoString .= " | <a href=\"maillist.php?page=".$page."\">����</a>";
	
	$gotoString .=" | <a href=\"mail_delete.php?num=".$num."\">ɾ��</a> | <a href=\"mail_mark.php?num=".$num."\">���</a>";
	//start to show
	print "<table width='100%' border='0' cellspacing='0' cellpadding='3'>\n";
	print "
		<tr bgcolor='#dddddd' height='20'><td>
		$gotoString
        </td></tr>
		";
	
	print "<tr width='100%' height='300'>
			<td align='left' valign='top' bgcolor='#000000'>
			<pre style='color: c0c0c0'>\n";
	echo ansi2web(htmlspecialchars($data[1]));
	print "</pre></td></tr>\n";
		
	print "
		<tr bgcolor='#dddddd' height='20'><td>
		$gotoString
        </td></tr>
		";

	echo "</table>\n";

	?>	
	</td>
  </tr>
</table>
<map name="Map"> 
  <area shape="rect" coords="93,62,172,77" href="maillist.php" alt="�Ķ��ʼ�" title="�Ķ��ʼ�">
  <area shape="rect" coords="179,62,256,77" href="sendmail.php" alt="д���ʼ�" title="д���ʼ�">
  <area shape="rect" coords="266,62,369,77" href="mail_internet.php" alt="���ŵ�Internet" title="���ŵ�Internet">
  <area shape="rect" coords="378,63,467,77" href="mail_sysop.php" alt="д�Ÿ�վ��" title="д�Ÿ�վ��">
  <area shape="rect" coords="467,73,469,80" href="#">
</map>
</body>
</html>