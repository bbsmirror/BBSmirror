<?php
//sort my friend

require_once('config.php');

unset($cuser);
session_start();

$pid = $cuser[pid];
$level = $cuser[level];
if(!$pid || !($level & PERM_BASIC)) {
	echo "<html>Ȩ�޲���! <a href='pal_list.php'> [���˷���] </a></html>";
	exit; 
}

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

?>
 
<html>
<head>
<title>ReplySpecialMail</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #000080}
A:visited {color: #444480}
PRE {color: #c0c0c0}
</style>
<script language="JavaScript">
<!--
//-->
</script>
</head>
<body bgcolor="#ffffff" leftmargin="3" topmargin="0" marginwidth="3" marginheight="0">
<table width="635" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="55" align="center"><img src="images/pal.gif" width="289" height="55" border="0"></td>
  </tr>
  <tr>
    <td valign="top" align="center">
	<hr size="2" color="green" noshade width="95%">
	
	<?php
	//maillist
	require_once('webbbs.class.php');
	
	$ws = new server_class;
	$ws->connect();

	$cmd = $ws->set_cmd("fsort", G_TALK, $pid);
	$ws->query($cmd);

	$ret = $ws->parse();

	if($ret[result] != 'OK') 
		$data = $ws->data;
	else
		$data = $ret[msg];

	echo "<br><br>";
	echo alertMsg($data);
	echo "<br><br><a href='pal_list.php'>[���˷���]</a>";

	?>	
	</td>
  </tr>
</table>
</body>
</html>