               	<form action=bbslogin method=post target=_top><br>
		С�ٺ��û���¼<br>
               	�ʺ� <input style='height:20px;' type=text name=id maxlength=12 size=8><br>
               	���� <input style='height:20px;' type=password name=pw maxlength=12 size=8><br>
               	<input style='width:72px; height:22px; BACKGROUND-COLOR: #d0f0c0' type=submit value=��¼��վ>