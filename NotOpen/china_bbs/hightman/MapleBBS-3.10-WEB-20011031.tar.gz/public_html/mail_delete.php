<?php
//Delete a Mail

require_once('config.php');

unset($cuser);
session_start();

$pid = $cuser[pid];
$level = $cuser[level];
if(!$pid || !($level & PERM_BASIC)) {
	echo "<html>������û��дInternet�ŵ�Ȩ��! <a href='maillist.php'> [���˷���] </a></html>";
	exit; 
}

if($num < 1) $num = 1;
$page = intval($num / XO_TALL) + 1;

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

?>
 
<html>
<head>
<title>ReplySpecialMail</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #000080}
A:visited {color: #444480}
PRE {color: #c0c0c0}
</style>
<script language="JavaScript">
<!--
//-->
</script>
</head>
<body bgcolor="#ffffff" leftmargin="3" topmargin="0" marginwidth="3" marginheight="0">
<table width="635" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="80"><img src="images/mail_top.gif" width="474" height="80" usemap="#Map" border="0"></td>
  </tr>
  <tr>
    <td valign="top" align="center">
	
	<?php
	//maillist
	require_once('webbbs.class.php');
	
	$ws = new server_class;
	$ws->connect();

	$cmd = $ws->set_cmd("delmail", G_MAIL, $pid, $num);
	$ws->query($cmd);
	$ret = $ws->parse();

	if($ret[result] != 'OK') 
		$data = $ws->data;
	else
		$data = "ɾ���ɹ�!";

	echo "<br><br>";
	echo alertMsg($data);
	echo "<br><br><a href='maillist.php?page=$page'>[���˷���]</a>";

	?>	
	</td>
  </tr>
</table>
<map name="Map"> 
  <area shape="rect" coords="93,62,172,77" href="maillist.php" alt="�Ķ��ʼ�" title="�Ķ��ʼ�">
  <area shape="rect" coords="179,62,256,77" href="sendmail.php" alt="д���ʼ�" title="д���ʼ�">
  <area shape="rect" coords="266,62,369,77" href="mail_internet.php" alt="���ŵ�Internet" title="���ŵ�Internet">
  <area shape="rect" coords="378,63,467,77" href="mail_sysop.php" alt="д�Ÿ�վ��" title="д�Ÿ�վ��">
  <area shape="rect" coords="467,73,469,80" href="#">
</map>
</body>
</html>