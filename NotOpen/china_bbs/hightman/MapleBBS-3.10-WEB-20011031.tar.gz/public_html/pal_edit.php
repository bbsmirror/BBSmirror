<?php
//sort my friend

require_once('config.php');

unset($cuser);
session_start();

$pid = $cuser[pid];
$level = $cuser[level];
if(!$pid || !($level & PERM_BASIC)) {
	echo "<html>Ȩ�޲���! <a href='pal_list.php'> [���˷���] </a></html>";
	exit; 
}

if($num < 1) $num = 1;
$page = intval($num / XO_TALL) + 1;

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

?>
 
<html>
<head>
<title>ReplySpecialMail</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #000080}
A:visited {color: #444480}
PRE {color: #c0c0c0}
</style>
<script language="JavaScript">
<!--
//-->
</script>
</head>
<body bgcolor="#ffffff" leftmargin="3" topmargin="0" marginwidth="3" marginheight="0">
<table width="635" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="55" align="center"><img src="images/pal.gif" width="289" height="55" border="0"></td>
  </tr>
  <tr>
    <td valign="top">
	<hr size="2" color="green" noshade width="95%">
	
	<?php
	//pal edit

	if(!isset($submit)) {
		print "<form method='post' action='$PHP_SELF'>
				�û�����: <input type='text' size='15' name='userid' value='$userid' readonly> <br>
				��������: <input type='text' size='20' name='ship' maxlength='30'> (10��������)<br>
				�Ƿ�����: <input type='radio' name='ftype' value='0' checked>����  <input type='radio' name='ftype' value='1'>���� <br>
				<input type='hidden' name='page' value='$page'>
				<input type='hidden' name='num' value='$num'>
				<input type='submit' name='submit' value='ȷ��'> <input type='button' value='����' onclick='window.history.back()'>
				</form>
					";

	} else {
		require_once('webbbs.class.php');
	
		$ws = new server_class;
		$ws->connect();

		if(!isset($ftype)) $ftype = 0;
		if(!$ship) $ship = " ";
		$cmd = $ws->set_cmd("fedit", G_TALK, $pid, $userid, $num, $ship, $ftype);
		$ws->query($cmd);
		
		$ret = $ws->parse();
		if($ret[result] != 'OK') 
			$data = $ws->data;
		else
			$data = $ret[msg];

		echo "<br><br><center>";
		echo alertMsg($data);
		echo "<br><br><a href='pal_list.php?page=$page'>[���˷���]</a></center>";
	}

	?>	
	</td>
  </tr>
</table>
</body>
</html>