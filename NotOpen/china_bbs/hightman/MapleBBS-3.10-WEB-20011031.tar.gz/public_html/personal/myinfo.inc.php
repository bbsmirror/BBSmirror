<?php
//modify ufile: myInfo

require_once('config.php');

unset($cuser);
session_start();

$pid = $cuser[pid];
$level = $cuser[level];
if(!$pid || !($level & PERM_BASIC)) {
	echo "<html>���ȵ�¼! <a href='personal.php'> [���˷���] </a></html>";
	exit; 
}

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

?>

<html>
<head>
<title>Modify My Info</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body bgcolor="#ffffff">
<table width="609" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="100%" align="center"><img src="images/myinfo.gif" border="0"></td>
  </tr>
  <tr> 
    <td width="100%" align="center"><hr size="2" noshade width="76%" color="#b751af"></td>
  </tr>

  <?php
  require_once('webbbs.class.php');

  
  $ws = new server_class;
  $ws->connect();
 
  if($submit && $realname && $passwd) {
	  
	  $cmd = $ws->set_cmd("modinfo", G_ACCT, $pid, $passwd);
	  $ws->send($cmd);
	  $data = $ws->recv(32);
	  $check = substr($data, 0, 2);
	  if($check == 'OK') {
		  $ws->send("NAME: $nickname\n");		/* nickname */
		  $ws->send("RNME: $realname\n");		/* realname */
		  $ws->send("ADDR: $address\n");		/* address	*/
		  $ws->send("\n");						/* tell end */
		  
		  $data = $ws->recv(128);				/* recv end */
		  $ws->close();							/* ����close� */
		  
		  $check = $ws->parse($data);

		  print "
			  <tr><td align='center'> ".alertMsg($check[msg])."
			  <br><br><a href='$PHP_SELF?action=myinfo'>���˿��Կ��ٷ���...</a>
			  </td></tr>
			  ";

	  } else {
		  print "
			  <tr><td align='center'> ".alertMsg($data)."
			  <br><br><a href='$PHP_SELF?action=myinfo'>���˿��Կ��ٷ���...</a>
			  </td></tr>
			  ";
	  }
  } else {
	  //else
	  $cmd = $ws->set_cmd("modrqst", G_ACCT, $pid);
	  $ws->query($cmd);

	  $ret = $ws->parse();
	  if($ret[result] != "OK") {
		  $ws->alert($ws->data);
		  exit;
	  }

	  if(!$realname || $realname == '' ) $realname = $ret[realname];
	  if(!$nickname || $nickname == '' ) $nickname = $ret[nickname];
	  if(!$address || $address == '' ) $address = $ret[address];

	  if($submit) $alertMsg = "<font color=red><b>����: ��д���������ύ!</b></font>";
	  else $alertMsg = "";

	  print "
		  <tr> 
		   <form action='$PHP_SELF' method='post'>
		   <td width='100%' align='center'>
			<table width='76%' border='0' bgcolor='#f0f0f0' align='center' height='260'>
			 <tr><td> $alertMsg </td></tr>
			 <tr><td>�����ʺ�: $cuser[userid] </td></tr>
		     <tr><td>�����ǳ�: <input type='text' size='18' name='nickname' value='$nickname'></td></tr>
		     <tr><td>��������: $ret[numposts] ƪ</td></tr>
		     <tr><td>��վ����: $ret[numlogins] �� </td></tr>
		     <tr><td>ͣ��ʱ��: $ret[staytime] Сʱ </td></tr>
		     <tr><td>��ʵ����: <input type='text' size='18' name='realname' value='$realname'> </td></tr>
		     <tr><td>��ס��ַ: <input type='text' size='42' name='address' value='$address'> </td></tr>
		     <tr><td>�ʺŽ���: $ret[firstlogin] </td></tr>
		     <tr><td>�������: $ret[lastlogin] </td></tr>
		     <tr><td>�ϴ���Դ: $ret[lasthost] </td></tr>
		     <tr><td>ȷ������: <input type='password' size='18' name='passwd'> </td></tr>
		    </table>
		   </td>
		  </tr>
		  <tr> 
		   <td width='100%' align='center'>
		   <input type='hidden' name='action' value='myinfo'>
		   <input type='submit' name='submit' value='ȷ���޸�'>
		   <input type='reset' name='reset' value='�ָ�����'>
		   </td>
		   </form>
		  </tr>
		  ";
  }
  ?>

  <tr> 
    <td width="100%" align="center"><hr size="2" noshade width="76%" color="#c0c0c0"></td>
  </tr>
</table>
</body>
</html>