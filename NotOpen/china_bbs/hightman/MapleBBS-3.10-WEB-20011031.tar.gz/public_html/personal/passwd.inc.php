<?php
//modify ufile: passwd

require_once('config.php');

unset($cuser);
session_start();

$pid = $cuser[pid];
$level = $cuser[level];
if(!$pid || !($level & PERM_BASIC)) {
	echo "<html>���ȵ�¼! <a href='personal.php'> [���˷���] </a></html>";
	exit; 
}

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

?>

<html>
<head>
<title>Modify My Password</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body bgcolor="#ffffff">
<table width="609" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="100%" align="center"><img src="images/passwd.gif" border="0"></td>
  </tr>
  <tr> 
    <td width="100%" align="center"><hr size="2" noshade width="76%" color="#b751af"></td>
  </tr>

  <?php
  require_once('webbbs.class.php');

  
  $ws = new server_class;
  $ws->connect();
 
  if($submit && $passwd) {
	  
	  if($passwd1 != $passwd2) {
		  $data = "������������벻һ��!";
	  } else if((strlen($passwd1) < 4) || (strlen($passwd1) > 10)) {
		  $data = "���������4~8λ֮��!";			  
	  } else {
		  $cmd = $ws->set_cmd("modinfo", G_ACCT, $pid, $passwd);
		  $ws->send($cmd);
		  $data = $ws->recv(32);
		  $check = substr($data, 0, 2);
		  if($check == 'OK') {
			  $ws->send("PASS: $passwd1\n");		/* passwd	*/
			  $ws->send("\n");						/* tell end */
		  
			  $data = $ws->recv(128);				/* recv end */
			  $ws->close();							/* ����close� */
		  
			  $check = $ws->parse($data);
			  $data = $check[msg];
			  $cuser[passwd] = $passwd1;			/* update Session */
		  }
	  }

	  print "
		  <tr><td align='center'> ".alertMsg($data)."
		  <br><br><a href='$PHP_SELF?action=passwd'>���˿��Կ��ٷ���...</a>
		  </td></tr>
	  ";
  } else {
	  //else
	  print "
		  <tr> 
		   <form action='$PHP_SELF' method='post'>
		   <td width='100%' align='center'>
			<table width='50%' border='0' bgcolor='#f0f0f0' align='center' height='120'>
			 <tr><td>ʹ�����ʺ�: $cuser[userid] </td></tr>
		     <tr><td>����ԭ����: <input type='password' size='18' name='passwd'></td></tr>
		     <tr><td>����������: <input type='password' size='18' name='passwd1'></td></tr>
		     <tr><td>���������: <input type='password' size='18' name='passwd2'></td></tr>
		    </table>
		   </td>
		  </tr>
		  <tr> 
		   <td width='100%' align='center'>
		   <input type='hidden' name='action' value='passwd'>
		   <input type='submit' name='submit' value='ȷ���޸�'>
		   </td>
		   </form>
		  </tr>
		  ";
  }
  ?>

  <tr> 
    <td width="100%" align="center"><hr size="2" noshade width="76%" color="#c0c0c0"></td>
  </tr>
</table>
</body>
</html>