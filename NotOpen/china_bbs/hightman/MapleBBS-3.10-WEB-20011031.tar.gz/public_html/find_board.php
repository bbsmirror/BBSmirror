<?php
//����������


if(!$pid) {
	unset($cuser);
	session_start();
	$pid = $cuser[pid];
}

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}
?>

<html>
<head>
<title>FindBoard</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body bgcolor="#ffffff">
<table width="609" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="100%" align="center"><font size="3" color="00a000">�� ���������� </font> (��"ȷ��"���в���)</td>
  </tr>
  <tr> 
    <td width="100%" align="center"><hr size="1" noshade width="76%" color="#b751af"></td>
  </tr>
  <tr> 
    <td width="100%" align="center">
	<?php
	if(!isset($submit) || $keys == "") {
		print "
			<form action=\"".$PHP_SELF."\" method=\"post\">
			�����뿴������: <input type=\"text\" size=\"15\" maxlength=\"15\" name=\"keys\">
			<input type=\"hidden\" name=\"pid\" value=\"".$pid."\">
			<input type=\"submit\" name=\"submit\" value=\"ȷ����ѯ\">
			</form>
			";
	} else {
		require_once("webbbs.class.php");
		require_once("config.php");

		$ws = new server_class;
		$ws->connect();
		$cmd = $ws->set_cmd("searchbrd", G_BOARD, $pid, $keys);
		$ws->query($cmd);
		$list = split("\n", $ws->data);
		$len = count($list);
		$len--;

		$ret = $ws->parse($list[$len]);
		if($ret[result] != 'OK') {
			echo "<br><br>\n";
			echo alertMsg($ws->data);
			echo "<br><br>\n";
		} else {

			print "
				<table border=0 width=76% align=center>
				<tr><td colspan=3 align=left> ���������ҽ��, ���ҵ���ذ��� <font color=red>".$ret[max]."</font> ��. </td></tr>
				";

			for($i=0; $i<$len; $i++) {
				$tmp = $ws->parse($list[$i]);
				print "
					<tr>
					<td> $tmp[no] </td>
					<td> <a href='postlist.php?board=$tmp[bname]'>$tmp[bname]</a> </td>
					<td> <a href='postlist.php?board=$tmp[bname]'>$tmp[btitle]</a> </td>
					</tr>
					";
			}

			print "</table>\n";
		}
	}
	?>
	</td>
  </tr>
  <tr> 
    <td width="100%" align="center"><hr size="1" noshade width="76%" color="#c0c0c0"></td>
  </tr>
</table>
</body>
</html>