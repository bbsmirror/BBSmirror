<?php

/* ��ɫת�� */

$highlight = 0;
$underline = 0;
$blink = 0;
$fgcolor1 = "none";
$bgcolor1 = "none";

$bbscolors = array("606060", "ff0000", "00ff00", "ffff00", "0000ff", "ff00ff", "00ffff", "ffffff", /* 30-37 */
				   "underline", "blink",	/* 8-9 */
				   "000000", "a00000", "00a000", "a0a000", "0000a0", "a000a0", "00a0a0", "c0c0c0", /* 40-47 */
				   "none"=>"none"); /* 18 */

$mode = 0; /* �жϱ�� */

function color_init()
{
 //*[1;4;5;7;31;42m /* ���*/
 global $highlight;
 global $underline;
 global $blink;
 global $fgcolor1;
 global $bgcolor1;

 $highlight = 0;
 $underline = 0;
 $blink = 0; /* ��IE����Ч */
 $fgcolor1 = "none";
 $bgcolor1 = "none";

 return "</font>";
}

function tran_colorstr($string = '0') /* x;x;x;x */
{
	global $highlight;
	global $underline;
	global $blink;
	global $fgcolor1;
	global $bgcolor1;
	global $bbscolors;

	global $mode;

	$settings = split(";", $string);
	$len = count($settings);
	$colorstr = "";

    while($tmp = each ($settings)) {
		$value = intval($tmp[1]);
		if(!$value) { 
				$colorstr .= color_init(); /* 0 �� �� */
				if($len < 2) { $mode=0; return $colorstr; }/* ����ǻ�ԭɫ */
		}
		else if($value == 1) {
			$highlight = 1;
			if($len < 2) return;	/* ���ֻ�Ǽ���ɫ */
		}
		else if($value == 4) $underline = 1 + 7;
		else if($value == 5) $blink = 1 + 8;
		else if($value == 7) { $bgcolor = 47; $fgcolor1 = 30; } /* ��ɫ */
		else if($value > 29 && $value < 38) $fgcolor1 = ($highlight ? $value-30 : $value-20); /* ǰ�� */
		else if($value > 39 && $value < 48) $bgcolor1 = $value-30; /* ���� */
	}
	$decoration = "";
	if($underline) $decoration .= $bbscolors[$underline].", ";
	if($blink) $decoration .= $bbscolors[$blink].", ";
	if(!$decoration) $decoration = $bbscolors[none];
	
	if($mode) $colorstr .= "</font>";
	$colorstr .= "<font style=\"color: ".$bbscolors[$fgcolor1]."; background: ".$bbscolors[$bgcolor1]."; text-decoration: ".$decoration."\">";
	$mode = 1;
	return $colorstr;
}


function ansi2web($string) /* ��ɫת�� */
{
 /* $string = nl2br($string); ÿ��ֻ��һ�� */
 global $mode;

 //$string = htmlspecialchars($string, ENT_QUOTES);
 //$string = str_replace(" ", "&nbsp;", $string);
 $times = preg_match_all("/\033\\[([01234567;]*)m/", $string, &$matches);
 for($i=0; $i<$times; $i++)
 {
  $string = str_replace($matches[0][$i], tran_colorstr($matches[1][$i]), $string);
 }

 if($mode) { $mode=0; $string .= "</font>"; } /* �Է���һ */

 $string = eregi_replace("\n(&gt;[^\n]*)", "\n<font color=00AA00>\\1</font>", $string);

 return $string;
}

?>