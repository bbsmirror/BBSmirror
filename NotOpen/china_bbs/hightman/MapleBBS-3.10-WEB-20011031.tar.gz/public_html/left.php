<?php
//left frame page  for Login

if(!$reload) $reload = 0;
$reload++;

if($reload > 4) {
	echo "<html>ϵͳ����3���ˣ��������޷����ӷ���������ر�����������������!</html>";
	exit;
}
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<title>leftFrame</title>
<script language=javascript>
<!--

  function re_load()
  {
	  var reloadTimes = '<?echo $reload;?>';
	  var myUrl = '<?echo $PHP_SELF;?>';
	  document.location = myUrl+ '?reload=' + reloadTimes;
  }

  function load_ok()
  {
	  if(!top.activeFrame || !top.activeFrame.pid)
		 setTimeout('re_load()', 500);
	  else
	  {
		 document.login.pid.value = top.activeFrame.pid;
		 document.login.submit();
	  }
  }

  function left_init()
  {
	  //clearTimeout();
	  load_ok();
  }
//-->
</script>
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="119" border="0" cellspacing="0" cellpadding="0" height="100%" background="images/leftBg.jpg">
  <tr>
    <td height="100" valign="top">����������...</td>
  </tr>
</table>
<form name="login" action="login.php" method="post">
 <input type="hidden" name="pid" value="">
</form>
<script language="JavaScript"> left_init(); </script>
</body>
</html>