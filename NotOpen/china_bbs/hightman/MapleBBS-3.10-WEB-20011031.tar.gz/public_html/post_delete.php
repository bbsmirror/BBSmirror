<?php
//Post delete
require_once('config.php');

unset($cuser);
session_start();

if(!isset($board)) $board = "sysop";

if(!isset($num)) $num = 1;

$page = intval($num / XO_TALL);	/* ���page */
if($num % XO_TALL) $page++;

$pid = $cuser[pid];
if(!$pid) {
	echo "<html>���Ѿ��Ͽ�����! �밴F5ˢ����ҳ!</html>";
	exit; 
}

$level = $cuser[level];
if(!($level & PERM_BM)) {
	echo "<html>��û��Ȩ��! <a href='postlist.php?board=$board&page=$page&num=$num'> [���˷���] </a></html>";
	exit; 
}

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

?>
 
<html>
<head>
<title>Post Delete</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #0000a0}
A:visited {color: #0000a0}
PRE {color: #c0c0c0}
</style>
<script language="javascript">
<!--
 function do_go() {
	 var num = document.go.num.value;
	 var page = num / 20;

	 if(num % 20) page++;
	 document.go.page.value = page;
}
//-->
</script>
</head>
<body leftmargin="3" topmargin="0" marginwidth="3" marginheight="0" bgcolor="#FFFFFF">
<table width="617" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td colspan="3"><img src="images/brd/brd_top.jpg" width="618" height="54" usemap="#Map" border="0"></td>
  </tr>
  <tr> 
    <td width="20" background="images/brd/brd_left_bg.jpg">&nbsp;</td>
    <td height="100%" width="585" align="center">

	<?php
	//post mark
	require_once('webbbs.class.php');
	
	$ws = new server_class;
	$ws->connect();

	$cmd = $ws->set_cmd("deletepost", G_BOARD, $pid, $board, $num);
	$ws->query($cmd);

	$ret = $ws->parse();

	if($ret[result] != 'OK') 
		$data = $ws->data;
	else
		$data = "�ɹ�ɾ������!";

	echo "<br><br>";
	echo alertMsg($data);
	echo "<br><br><a href='postlist.php?board=$board&page=$page&num=$num'> [���˷���] </a>";

	?>	
	</td>
    <td background="images/brd/brd_right_bg.jpg" width="20">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="3" height="2"><img src="images/brd/brd_bottom.jpg" width="618" height="25"></td>
  </tr>
</table>
<map name="Map"> 
  <area shape="rect" coords="47,18,117,38" href="services.php" alt="��վ������" title="��վ������">
  <area shape="rect" coords="258,20,327,39" href="gem.php" alt="��վ��������" title="��վ��������">
  <area shape="rect" coords="336,20,408,40" href="personal.php" alt="���˹�����" title="���˹�����">
  <area shape="rect" coords="416,20,488,40" href="talk.php" alt="����������" title="����������">
  <area shape="rect" coords="497,19,567,39" href="group.php" alt="�ҵ�Ⱥ�鹦����" title="�ҵ�Ⱥ�鹦����">
</map>
</body>
</html>