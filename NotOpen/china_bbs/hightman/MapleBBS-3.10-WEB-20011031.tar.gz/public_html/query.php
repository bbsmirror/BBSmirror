<?php
//user Query

require_once('config.php');
require_once('webbbs.class.php');
require_once('ansi2web.inc.php');

unset($cuser);
session_start();

/* ���û����userid������form��ͷȥ */
if(!$userid) {
	header("location: queryform.php");
	exit;
}

?>
<html>
<head>
<title>UserQuery</title>
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #000080}
A:visited {color: #444480}
PRE {color: #c0c0c0}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<script language="javascript">
<!--hide
function sendmsg(userno){
	var userid = "<?echo $userid;?>";
	var check  = "<?echo $cuser[userid];?>";

	if(check == userid || check == "guest" || userno <= 0) return false; //���ܸ��Լ����Ͳ����ߵķ�
  	var prom = "�� �����"+userid+"˵ʲô�أ�";
	var xx=prompt(prom,'');
	if(xx != '' && xx!=null) top.activeFrame.bmw_send(userno, xx);
    return false;
}
//-->
</script>
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="649" border="0" cellspacing="0" cellpadding="0" align="left">
<tr width="100%"><td align="left" valign="top">
<?php

$pid = $cuser[pid];

$ws = new server_class;
$ws->connect();

$cmd = $ws->set_cmd("doquery", G_TALK, $pid, $userid);
$ws->send($cmd);	/* ����ָ�� */

$plans = "";
$binfo = "";
$pflag = 0;

while(1) {
    $tmp = $ws->recv(128);
	if(intval($tmp) === -1) break;

	if(!strncmp("<--Start-Plan-->", $tmp, 16)) {
		$pflag = 1;
		continue;
	}
	if($pflag) {
		$plans .= $tmp;
	} else {
		$binfo .= $tmp;
	}
}

$ws->close();

$ret = $ws->parse($binfo);

if($ret[result] != "OK") {
	$ws->alert($binfo);
	exit;
}

if(!$plans || empty($plans)) $plans = "[û����Ƭ]";

print "
<br>
<table width='600' border='0' cellspacing='0' cellpadding='0' align='center'>
  <tr bgcolor='#663300'> 
    <td colspan='3' height='25'> <font color='#FFFFFF'>�� ��ѯ���� - $ret[id] ��</font></td>
  </tr>
  <tr> 
    <td rowspan='5' width='13' bgcolor='#CCCCCC'>&nbsp;</td>
    <td width='572' height='13' bgcolor='#CCCCCC'>&nbsp;</td>
    <td rowspan='5' width='13' bgcolor='#CCCCCC'>&nbsp;</td>
  </tr>
  <tr> 
    <td width='572' height='80' bgcolor='#F9E2B1'>
	";

/* �ؼ��Ĳ�ѯ����, ��ʾ�û���Ϣ */
 $moneyStr = $markStr = "";

 if(isset($ret[money])) $moneyStr = "��Ǯ: [<font class='col032'>".$ret[money]."</font>]";
 if(isset($ret[nummark])) $markStr = "<font class='col131'>".$ret[nummark]."</font>/";

 printf("<u>%s</u> (<font class='col036'>%s</font>) ����վ <font class='col032'>%d</font> �� ������ %s<font class='col032'>%d</font> ƪ���� %sͨ��������֤<br>\n", $ret[id], $ret[nick], $ret[numlogin], $markStr, $ret[numpost], $ret[valid] == 1 ? "�Ѿ�" : "��δ");

 printf("�ϴ� [<font class='col032'>%s</font>] [<font class='col032'>%s</font>] ����վһ��<br>\n", $ret[lastlogin], $ret[lastfrom]);

 printf("����ֵ: [<font class='col032'>%d</font>] (<font class='col036'>%s</font>) ����ֵ: [<font class='col032'>%d</font>] (<font class='col036'>%s</font>) ������: [<font class='col032'>%d</font>] %s<br>\n", $ret[exp], $ret[cexp], $ret[perf], $ret[cperf], $ret[live], $moneyStr);

 printf("��̬: %s ����: %s [��Ƭ]<br>\n", ansi2web($ret[mode]), $ret[mail] == 1 ? "�����ż�" : "��������");

 if(!strncmp($ret[mode], "����վ��", 8)) {
	 $ret[uno] = 0;
 }

 print "	
	</td>
  </tr>
  <tr> 
    <td width='572' bgcolor='#CCCCCC' height='13'>&nbsp;</td>
  </tr>
  <tr> 
    <td width='572' height='220' valign='top' bgcolor='#000000'>
	 <pre>".ansi2web($plans)."</pre>
	</td>
  </tr>
  <tr> 
    <td width='572' bgcolor='#CCCCCC' height='13'>&nbsp;</td>
  </tr>
  <tr height='20'>
    <td align='left' colspan='3' bgcolor='#9CA4C8'>
	<img src='images/friend.gif'> <a href='pal_add.php?userid=$userid'>��Ϊ����</a>
	<img src='images/ok.gif'> <a href='#' onclick='return sendmsg($ret[uno])'>����ѶϢ</a>
	<img src='images/mail.gif'> <a href=\"sendmail.php?receiver=$userid\">д���ʺ�</a>
	<img src='images/home.gif'> <a href='#'>�ݷ���ҳ</a>
	<a href='#' onclick='window.history.back()'>������ҳ</a>
	</td>
  </tr>
  </table>
";
?>
</td></tr>
</table>
</body>
</html>

<?php
  exit();
?>