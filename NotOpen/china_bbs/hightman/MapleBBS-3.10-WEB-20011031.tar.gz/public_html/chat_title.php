<html>
<head>
<title>Xchat_Title</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body bgcolor="#ffffff" text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="640" border="0" cellspacing="0" cellpadding="0" height="20">
<tr height="15">
<td align="left"><font color="#338080">[<span id="chatfunc"≯��</span>��] <span id="roomname">Main</span></font></td>
<td align="left"><font color="#900090">[����] <span id="topic">Ƽˮ�������Ե</span></font></td>
</tr>
<tr><td colspan="2" height=4></td></tr>
<tr><td colspan="2" bgcolor="#000000" height=1></td></tr>
</table>
</body></html>