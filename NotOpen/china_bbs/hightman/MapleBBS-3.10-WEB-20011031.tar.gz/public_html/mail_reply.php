<?php
//Reply Mail No.

require_once('config.php');

unset($cuser);
session_start();

$pid = $cuser[pid];
$level = $cuser[level];
if(!$pid || !($level & PERM_BASIC)) {
	echo "<html>���ȵ�¼! <a href='main.php'> [���˷���] </a></html>";
	exit; 
}

if($num < 1) $num = 1;
$page = intval($num / XO_TALL) + 1;

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

?>
 
<html>
<head>
<title>ReplySpecialMail</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #000080}
A:visited {color: #444480}
PRE {color: #c0c0c0}
</style>
<script language="JavaScript">
<!--
//-->
</script>
</head>
<body bgcolor="#ffffff" leftmargin="3" topmargin="0" marginwidth="3" marginheight="0">
<table width="635" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="80"><img src="images/mail_top.gif" width="474" height="80" usemap="#Map" border="0"></td>
  </tr>
  <tr>
    <td valign="top">
	
	<?php
	//maillist
	require_once('webbbs.class.php');
	
	$ws = new server_class;
	$ws->connect();

	$cmd = $ws->set_cmd("replymail", G_MAIL, $pid, $num);
	$ws->query($cmd);

	$data = split("\n\n", $ws->data, 2);
	
	$ret = $ws->parse($data[0]);

	if($ret[result] != 'OK') {
		echo "<br><br>";
		echo alertMsg($ws->data);
		echo "<br><br><a href='maillist.php?page=$page'>[���˷���]</a>";
		exit;
	}
	
	/* ����GoTo Page */
	$gotoString  = "�ظ��ż��� �� <font color=000000>".$num."</font> ��";
	$gotoString .= " | <a href=\"maillist.php?page=".$page."\">�����б�</a>";
	
	if(!eregi("^Re: ", $ret[title])) {
		$title = "Re: ".$ret[title];
	} else {
		$title = $ret[title];
	}

	//start to show
	print "<table width='100%' border='0' cellspacing='0' cellpadding='3' align='right'>\n";
	print "
		<tr bgcolor='#dddddd' height='20'><td>
		$gotoString
        </td></tr>
		";
	
	print "
	 <tr width='100%' bgcolor='#f0f0f0'><form action='sendmail.php' method='post'><td>
	   �ż�����: <input type=text name=title value='".$title."' size=40 maxlength=60> ������: $cuser[userid] 
	 </td></tr>
	 <tr bgcolor='#f0f0f0'><td>
	   ������&nbsp;&nbsp;: <input type=text name=receiver value='".$ret[receiver]."' readonly size=15 maxlength=20>
	   ʹ��ǩ���� <input type=radio name=sign value=1 checked>1 <input type=radio name=sign value=2>2
	   <input type=radio name=sign value=3>3 <input type=radio name=sign value=0>0 
	   �����ż�<input type=checkbox value=1 name=sign>
	 </td></tr>
     <tr bgcolor='#f0f0f0'><td><textarea name=content wrap=hard cols=79 rows=22>".$data[1]."</textarea></td></tr>
	 <tr bgcolor='#f0f0f0'><td align=center>
	  <input type=submit name=submit value=' �� �� '>
	  <input type=button onclick='top.window.history.go(-1)' value=' �� �� '>
	 </td></form></tr>\n";
		
	print "
		<tr bgcolor='#dddddd' height='20'><td>
		$gotoString
        </td></tr>
		";
	echo "</table>\n";

	?>	
	</td>
  </tr>
</table>
<map name="Map"> 
  <area shape="rect" coords="93,62,172,77" href="maillist.php" alt="�Ķ��ʼ�" title="�Ķ��ʼ�">
  <area shape="rect" coords="179,62,256,77" href="sendmail.php" alt="д���ʼ�" title="д���ʼ�">
  <area shape="rect" coords="266,62,369,77" href="mail_internet.php" alt="���ŵ�Internet" title="���ŵ�Internet">
  <area shape="rect" coords="378,63,467,77" href="mail_sysop.php" alt="д�Ÿ�վ��" title="д�Ÿ�վ��">
  <area shape="rect" coords="467,73,469,80" href="#">
</map>
</body>
</html>