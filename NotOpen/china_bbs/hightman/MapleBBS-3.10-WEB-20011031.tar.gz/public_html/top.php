<html>
<head>
<title>TopFrame</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<base target="mainFrame">
</head>
<body bgcolor="#ffffff" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table border="0" cellpadding="0" cellspacing="0" width="768">
  <tr>
    <td rowspan="2"><img name="top_r1_c1" src="images/top/top_r1_c1.jpg" height="85" border="0" usemap="#top_r1_c1Map"></td>
    <td rowspan="2"><img name="top_r1_c2" src="images/top/top_r1_c2.jpg" height="85" border="0" usemap="#top_r1_c2Map"></td>
    <td background="images/top/top_r1_c3.jpg" align="right"> 
      <div align="right" style="font-size: 10pt"><a href="xchat.php">������</a> <a href="ulist.php">�����ķ�</a> <a href="queryform.php">��ѯ����</a> <a href="about.php">��ϵ����</a> <a href="main.php">����</a> <a href="help.php">����</a></div>
    </td>
   <td><img src="images/top/spacer.gif" width="1" height="19" border="0"></td>
  </tr>
  <tr>
    <td><img name="top_r2_c3" src="images/top/top_r2_c3.jpg" height="66" border="0" usemap="#top_r2_c3Map"></td>
   <td><img src="images/top/spacer.gif" width="1" height="66" border="0"></td>
  </tr>
</table>
<map name="top_r1_c1Map"> 
  <area shape="rect" coords="145,58,234,82" href="services.php" title="���桢ʮ���">
</map>
<map name="top_r1_c2Map">
  <area shape="rect" coords="7,43,98,67" href="board.php" title="��վ���࿴��">
  <area shape="rect" coords="113,58,202,81" href="gem.php" title="��վ������">
</map>
<map name="top_r2_c3Map"> 
  <area shape="rect" coords="11,25,99,47" href="personal.php" title="�����趨��">
  <area shape="rect" coords="118,40,207,61" href="talk.php" title="̸��˵����">
  <area shape="rect" coords="223,24,311,47" href="group.php" title="Ⱥ�鹦��">
</map>
</body>
</html>
