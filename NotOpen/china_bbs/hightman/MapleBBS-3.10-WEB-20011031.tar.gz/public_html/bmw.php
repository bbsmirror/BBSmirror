<html>
<head>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<title>bmwFrame</title>
<script language="javascript">
<!--hide
var max = 10;
var whamsg=new Array(max+1);
var base=1;
var maxlength = 60;

function replymsg(uno, msg){

  	var prom = msg+"\n�ظ�: (���ظ����ؼ���)\n";
	var xx=prompt(prom,'');
	if(xx=='' || xx==null) return false;
	return top.activeFrame.bmw_send(uno, xx);
}

function replymsg2(){
		if(base < 2) return false;
		var i = document.msg.msglist.selectedIndex;
		var uno = document.msg.msglist.options[i].value;
		var msg = document.msg.msglist.options[i].innerText;
		var prom = msg+"\n�ظ�: (���ظ����ؼ���)";
		var xx=prompt(prom,'');
		if(xx=='' || xx==null) return false;
		return top.activeFrame.bmw_send(uno, xx);
}

function showmsg(){
 var string;
 string = "ѶϢ��";
 string += "<select name='msglist' style='width: 500; height:22; font-size: 10pt;' size='1' onChange='replymsg(this.options[this.selectedIndex].value, this.options[this.selectedIndex].innerText)'>\n";

 for(var i=max+1; i>0; i--)
 {
   if(whamsg[i] == '' || whamsg[i] == null || whamsg[i] == 'undefined') continue;
   var tmp = whamsg[i].split('��');
   if(tmp[1].length > maxlength) tmp[1] = tmp[1].substring(0, maxlength);
   string += '<option value='+tmp[0]+'>'+tmp[1]+'</option>\n';
 }
 string += "</select> [<a href=# onclick='return replymsg2()'><font color=blue>�ظ�</font></a>]";
 allmsg.innerHTML = string;
}

function addOne(uno, msg){ /* i.e: uno��msg */
var string = uno+'��'+msg;
if (base<max+1) {
    whamsg[base]=string;
    base++;
  } else {
   for (i=0;i<max;i++)
    whamsg[i]=whamsg[i+1];
    whamsg[i]=string;
  }
 showmsg();
}

function msg_init()
{
	for(var i=max+1; i>0; i--)
		whamsg[i] = '';
	showmsg();
}

//-->
</script>
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" onLoad="msg_init()">
<table width="768" border="0" cellspacing="0" cellpadding="0" height="25">
  <tr>
    <td width="119"  background="images/leftBg.jpg">&nbsp;</td>
    <td width="30" background="images/bmwBg.jpg">&nbsp;</td>
    <form name="msg" target="hideFrame" action="sendmsg.php">
    <td background="images/bmwBg.jpg" width="619"><div id="allmsg"> </div></td>
	</form>
  </tr>
</table>
</body>
</html>