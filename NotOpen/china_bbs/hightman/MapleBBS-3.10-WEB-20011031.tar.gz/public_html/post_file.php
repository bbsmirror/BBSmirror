<?php
//Post Mark
require_once('config.php');

unset($cuser);
session_start();

if(!isset($board)) $board = "sysop";

$files = array("note"=>"���滭��", "deny"=>"ˮͰ����");

if(empty($filename)) $filename = 'note';

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

?>
 
<html>
<head>
<title>Post File Data</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #0000a0}
A:visited {color: #0000a0}
PRE {color: #c0c0c0}
</style>
<script language="javascript">
<!--
 function do_go() {
	 var num = document.go.num.value;
	 var page = num / 20;

	 if(num % 20) page++;
	 document.go.page.value = page;
}
//-->
</script>
</head>
<body leftmargin="3" topmargin="0" marginwidth="3" marginheight="0" bgcolor="#FFFFFF">
<table width="617" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td colspan="3"><img src="images/brd/brd_top.jpg" width="618" height="54" usemap="#Map" border="0"></td>
  </tr>
  <tr> 
    <td width="20" background="images/brd/brd_left_bg.jpg">&nbsp;</td>
    <td height="100%" width="585">

	<?php
	//file data
	require_once('webbbs.class.php');
	require_once('ansi2web.inc.php');
	
	$ws = new server_class;
	$ws->connect();

	$cmd = $ws->set_cmd("postfile", G_BOARD, $board, $filename);
	$ws->query($cmd);

	$data = split("\n", $ws->data, 2); /* \n������ */
	$ret = $ws->parse($data[0]);
	if($ret[result] != 'OK') {
		echo "<br><br>";
		echo alertMsg($ws->data);
		echo "<br><br><a href='postlist.php?board=$board&page=$page&hotmode=$hotmode'>[���˷���]</a>";
		exit;
	}

	if(!$data[1]) $data[1] = 'û������';

	print "
		<table border='0' width='95%'>
		<tr><td>
			��ʾ: $files[$filename] | <a href='postlist.php?board=$board&page=$page&hotmode=$hotmode'>���˷���[".$board."]</a>
		</td></tr>
		";

	print "
		<tr><td bgcolor='#000000' height='100'> ";

	echo "<pre style='color: c0c0c0'>";
	echo ansi2web(htmlspecialchars($data[1]));
	echo "</pre>";
	
	print "</td></tr></table>\n";
	?>	
	</td>
    <td background="images/brd/brd_right_bg.jpg" width="20">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="3" height="2"><img src="images/brd/brd_bottom.jpg" width="618" height="25"></td>
  </tr>
</table>
<map name="Map"> 
  <area shape="rect" coords="47,18,117,38" href="services.php" alt="��վ������" title="��վ������">
  <area shape="rect" coords="258,20,327,39" href="gem.php" alt="��վ��������" title="��վ��������">
  <area shape="rect" coords="336,20,408,40" href="personal.php" alt="���˹�����" title="���˹�����">
  <area shape="rect" coords="416,20,488,40" href="talk.php" alt="����������" title="����������">
  <area shape="rect" coords="497,19,567,39" href="group.php" alt="�ҵ�Ⱥ�鹦����" title="�ҵ�Ⱥ�鹦����">
</map>
</body>
</html>