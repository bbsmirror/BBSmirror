<?php
//logout.php
require_once('config.php');
require_once('webbbs.class.php');

session_start();

if(session_is_registered("cuser")) {
	unset($pid);
	$pid = $cuser[pid];
	
	$ws = new server_class;
	$ws->connect();
	$cmd = $ws->set_cmd("chgusr", G_LOGIN, $pid, STR_GUEST);
	$ws->query($cmd);
	
	$ret = $ws->parse();
	if($ret[result] == 'OK') {
		$cuser[userid] = STR_GUEST;
		$cuser[passwd] = "";
		$cuser[level] = 0;
		$cuser[login] = "no";

	} else {
		$ws->alert($ws->data);
	}

 header("location: left.php");
 exit;

} else {
	echo "<html>403: ��������!</html>";
	exit;

}
?>