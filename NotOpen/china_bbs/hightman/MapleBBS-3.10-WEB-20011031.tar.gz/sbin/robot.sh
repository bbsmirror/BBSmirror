#!/bin/bash

PID=`ps -aux|grep "./robot"|awk '{print $2}'`
echo $PID
