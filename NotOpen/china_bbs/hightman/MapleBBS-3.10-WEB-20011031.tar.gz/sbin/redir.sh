#!/usr/bin/perl 
$archive32 = "0123456789ABCDEFGHIJKLMNOPQRSTUV"; 
$pwd = `pwd`; 
@DIR = (); 
if($pwd =~ /\/usr\//) { 
  opendir(DIR, "@"); 
  @p = readdir(DIR); 
  @DIR = (@DIR, @p); 
  closedir(DIR); 
} else { 
  for($i = 0; $i < length($archive32); $i++) { 
    opendir(DIR, substr($archive32, $i, 1)); 
    @p = readdir(DIR); 
    @DIR = (@DIR, @p); 
    closedir(DIR); 
  } 
} 
  
@DIR = sort {$a cmp $b} @DIR; 
  
open(NEW, "> .DIR.new"); 
binmode(NEW); 
  
foreach $k (@DIR) { 
  if($k =~ /^\./) { 
    next; 
  } 
  
  $time = 0; 
  for($i = 1; $i < length($k); $i++) { 
    $time = $time * 32 + index($archive32, $key = substr($k, $i, 1)); 
  } 
  
  if($k =~ /\@/) { 
    open(FD, "< \@/$k"); 
  } else { 
    open(FD, "< $key/$k"); 
  } 
  
  $author = "[�� �� ¼]"; 
  $nick = ""; 
  $subject = "�Ȼ�֮�ż�"; 
  
  while(<FD>) { 
    chomp; 
    if(/^������: (.*?) \((.*?)\)/ || /^����: (.*?) \((.*?)\)/) { 
      $author = $1; 
      $nick = $2; 
    } elsif(/^������: (.*?) / || /^����: (.*?) /) { 
      $author = $1; 
      $nick = ""; 
    } elsif(/^����: (.*?)$/ || /^��  ��: (.*?)$/) { 
      $subject = $1; 
    } elsif(/^$/) { 
      last; 
    } 
  } 
  
  @p = localtime($time); 
  $p[5] %= 100; 
  $date = sprintf("%02d/%02d/%02d", $p[5], $p[4] + 1, $p[3]); 
  print NEW pack("LIIa32a80a50a9a73", $time, 0, 0, $k, $author, $nick, 
                 $date, $subject); 
  close(FD); 
} 
close(NEW); 
rename(".DIR", ".DIR.old"); 
rename(".DIR.new", ".DIR"); 
