#!/bin/sh
cd /home/bbs/
MON=`/bin/date -v-2m "+%m"`
tar zcvf backup/bin`date +%m%d`.tgz bin/ &
tar zcvf backup/USR`date +%m%d`.tgz .USR &
tar zcvf backup/BRD`date +%m%d`.tgz .BRD &
tar zcvf backup/etc`date +%m%d`.tgz etc/ &
tar zcvf backup/innd`date +%m%d`.tgz innd/ &
rm -rf /var/backup1/brd1 
rm -rf /var/backup1/gem1 
rm -rf /var/backup2/usr1
mv /var/backup1/brd/ /var/backup1/brd1/
mv /var/backup1/gem/ /var/backup1/gem1/
mv /var/backup2/usr/ /var/backup2/usr1/
mkdir /var/backup1/brd /var/backup1/gem /var/backup2/usr
bin/backupusr
bin/backupbrd
bin/backupgem
rm -f backup/bin$MON* &
rm -f backup/BRD$MON* &
rm -f backup/etc$MON* &
rm -f backup/innd$MON* &
