/*-------------------------------------------------------*/
/* post.c       ( NTHU CS MapleBBS Ver 2.39 )            */
/*-------------------------------------------------------*/
/* target : bulletin boards' routines		 	 */
/* create : 95/03/29				 	 */
/* update : 96/04/05				 	 */
/*-------------------------------------------------------*/


#define xlog(x)		f_cat("/tmp/b.log", x)

#include "bbs.h"


extern BCACHE *bshm;
extern XZ xz[];


extern int cmpchrono();
extern int xo_delete();
extern int xo_uquery();
extern int xo_usetup();
extern int xo_fpath();          /* lkchu.981201 */

#if 0
/* Thor.990220: �Ĳ���� */
extern int vote_result();
extern int XoVote();
#endif

extern int TagNum;
extern char xo_pool[];
extern char brd_bits[];

/* Thor.990113: imports for anonymous log */
extern char rusername[];

int
cmpchrono(hdr)
  HDR *hdr;
{
  return hdr->chrono == currchrono;
}


/* ----------------------------------------------------- */
/* ���� innbbsd ת���ż������߿���֮��������		 */
/* ----------------------------------------------------- */

static void
outgo_post(hdr, board)
  HDR *hdr;
  char *board;
{
  char *fpath, buf[256];

  if (board)
  {
    fpath = "innd/out.bntp";
  }
  else
  {
    board = currboard;
    fpath = "innd/cancel.bntp";
  }

  sprintf(buf, "%s\t%s\t%s\t%s\t%s\n",
    board, hdr->xname, hdr->owner, hdr->nick, hdr->title);
  f_cat(fpath, buf);
}


void
cancel_post(hdr)
  HDR *hdr;
{
  if ((hdr->xmode & POST_OUTGO) &&		/* ��ת�ż� */
    (hdr->chrono > ap_start - 7 * 86400))	/* 7 ��֮����Ч */
  {
    outgo_post(hdr, NULL);
  }
}


static inline void
move_post(hdr, board, by_bm)	/* �� hdr �� currboard �ᵽ board */
  HDR *hdr;
  char *board;
  int by_bm;
{
  HDR post;
  char folder[80], fpath[80];

  brd_fpath(folder, currboard, fn_dir);
  hdr_fpath(fpath, folder, hdr);

  brd_fpath(folder, board, fn_dir);
  hdr_stamp(folder, HDR_LINK | 'A', &post, fpath);
  unlink(fpath);

  /* ֱ�Ӹ��� trailing data */

  memcpy(post.owner, hdr->owner, TTLEN + 140);

  if (by_bm)
    sprintf(post.title, "%-13s%.59s", cuser.userid, hdr->title);

  rec_add(folder, &post, sizeof(post));
  cancel_post(hdr);
}


/* ----------------------------------------------------- */
/* ��������Ӧ���༭��ת¼����				 */
/* ----------------------------------------------------- */

#ifdef HAVE_ANONYMOUS
/* Thor.980727: lkchu patch: log anonymous post */
/* Thor.980909: gc patch: log anonymous post filename */
void
log_anonymous(fname)
  char *fname;
{
  char buf[512];
  time_t now = time(0);
  /* Thor.990113: ���� rusername �� fromhost�Ƚ��꾡 */
  sprintf(buf, "%s %-13s(%s@%s) %s %s %s\n", Etime(&now), cuser.userid, rusername, fromhost, currboard, ve_title, fname);
  f_cat(FN_ANONYMOUS_LOG, buf);
}
#endif


#ifdef HAVE_BM_DENYPOST
/* hightman.011028: ��������ͣpostȨ */
static int
is_denyid(userid)
  char *userid;
{
 char fpath[80];
 brd_fpath(fpath, currboard, fn_deny);
 return (belong(fpath, userid));
}

#endif	/* HAVE_BM_DENYPOST */

static int
do_post(title)
  char *title;
{
  /* Thor.1105: ����ǰ����� curredit */
  HDR post;
  char fpath[80], folder[80], *nick, *rcpt;
  int mode;

#ifdef HAVE_MONEY_ISM  
  int fee;	/* ��� */
  time_t from;	/* ��ʼʱ�� */
  cutmp->reward = 0;
#endif  

#ifdef HAVE_BM_DENYPOST
/* hightman.011028: ��������ͣpostȨ */
 if (is_denyid(cuser.userid) && !HAS_PERM(PERM_ALLBOARD|PERM_SYSOP))
    {
     vmsg("�ܱ�Ǹ�������ڽ��ܴ�����,Ŀǰ�޷���������!");
     return XO_FOOT;
    }
#endif
   
  if (!(bbstate & STAT_POST))
  {
    vmsg("�Բ��𣬱�������Ψ����");
    return XO_FOOT;
  }

  film_out(FILM_POST, 0);

  prints("��������춡� %s ������", currboard);

  if (!ve_subject(21, title, NULL))
    return XO_HEAD;

  /* δ�߱� Internet Ȩ���ߣ�ֻ����վ�ڷ������� */
  /* Thor.990111: ûת�ų�ȥ�Ŀ���, Ҳֻ����վ�ڷ������� */

  if (!HAS_PERM(PERM_INTERNET) || (bbstate & BRD_NOTRAN))
    curredit &= ~EDIT_OUTGO;

#ifdef HAVE_ANONYMOUS
  /* Thor.980727: lkchu����֮[�򵥵�ѡ������������] */
  /* Thor.980909: gc patch: edit ʱ��������ǩ���� */
  if ((bbstate & BRD_ANONYMOUS)
     && (vans("��(��)��Ҫ������(Y/N)?[Y]") != 'n'))
       curredit |= EDIT_ANONYMOUS;
#endif

  utmp_mode(M_POST);
#ifdef HAVE_MONEY_ISM
  from = time(0);  /* hightman ��ʼ�Ʒ� */
  cutmp->reward = 0; /* ��ʼ����! */
#endif
  fpath[0] = 0;
  if (vedit(fpath, YEA) < 0)
  {
    unlink(fpath);
    vmsg("ȡ��");
    return XO_HEAD;
  }
  
#ifdef HAVE_MONEY_ISM
/* hightman.011028: Ǯ���ƶ�����. */
  fee = (cutmp->reward)/2;
  if(fee >= (time(0) - from) * 2)
    fee = time(0) - from;
#endif

  /* build filename */

  brd_fpath(folder, currboard, fn_dir);
  hdr_stamp(folder, HDR_LINK | 'A', &post, fpath);

  /* set owner to anonymous for anonymous board */

  rcpt = cuser.userid;
  nick = cuser.username;
  mode = curredit & POST_OUTGO;
  title = ve_title;

#ifdef HAVE_ANONYMOUS
  /* Thor.980727: lkchu����֮[�򵥵�ѡ������������] */
  if (curredit & EDIT_ANONYMOUS)
  {
    /* nick = rcpt; */ /* lkchu: nick ����Ϊ  userid */
    nick = "�²�����˭ ? ^o^";
    /* Thor.990113: �����ִ�id���� */
    /* rcpt = "anonymous"; */
    rcpt = "[��������]";
    mode = 0;

/* Thor.980727: lkchu patch: log anonymous post */
/* Thor.980909: gc patch: log anonymous post filename */
    log_anonymous(post.xname);
    
  }
#endif

  post.xmode = mode;
  strcpy(post.owner, rcpt);
  strcpy(post.nick, nick);
  strcpy(post.title, title);

  if (!rec_add(folder, &post, sizeof(HDR)))
  {
    /* if ((mode) && (!(bbstate & BRD_NOTRAN))) */
    /* Thor.990111: ���� edit.c ��ͳһcheck */
    if (mode)
      outgo_post(&post, currboard);

 /* fuse: �Լ������¾Ͳ�Ҫ��+���� */
#if 1
    mode = post.chrono;
    brh_add(mode - 1, mode, mode + 1);
#endif

    clear();
    outs("˳���������棬");

    if (bbstate & BRD_NOCOUNT)
    {
      outs("���²������¼�����������\n\nͬʱҲ�޷�����Ʒ�!");
    }
    else
    {
      prints("�������ĵ� %d ƪ���¡�", ++cuser.numposts);

#ifdef HAVE_MONEY_ISM      
      if(fee>10)
      {
        if(fee>500) fee=500;      	
        prints("\n\n����������һƪ������%dԪ",fee);
        cuser.money+=fee; 
        acct_save(&cuser);
      }
#endif
      
    }

    /* ��Ӧ��ԭ�������� */

    if (curredit & EDIT_BOTH)
    {
      char *msg = "�����޷�����";
#define	_MSG_OK_	"��Ӧ����������"

      rcpt = quote_user;
      if (strchr(rcpt, '@'))
      {
#ifndef USE_SENDMAIL      	
	if (bsmtp(fpath, title, rcpt, 0) >= 0)
	  msg = _MSG_OK_;
#else	  
        if (bbs_sendmail(fpath, title, rcpt, 0) >= 0)
          msg = _MSG_OK_;
#endif          
      }
      else
      {
	usr_fpath(folder, rcpt, fn_dir);
	if (hdr_stamp(folder, HDR_LINK, &post, fpath) == 0)
	{
	  strcpy(post.owner, cuser.userid);
	  strcpy(post.title, title);
	  if (!rec_add(folder, &post, sizeof(post)))
	    msg = _MSG_OK_;
	}
      }
      outs(msg);
    }
  }
  unlink(fpath);

  vmsg(NULL);

  return XO_INIT;
}


static int
do_reply(hdr)
  HDR *hdr;
{
  curredit = 0;

  switch (vans("�� ��Ӧ�� (F)���� (M)�������� (B)���߽��� (Q)ȡ����[F] "))
  {
  case 'm':
#ifdef HAVE_HOT_MODE
    hdr->xmode &= ~POST_HOT;	/* hightman.011028: ����, POST_HOT��MAIL_NOREPLY���� 
				 * �����˱�Թ��H���޷����Ÿ�ԭ����
				 * �ش˽��
				 */
#endif
    mail_reply(hdr);
    *quote_file = '\0';
    return XO_HEAD;

  case 'q':
    /*
     * Thor: ��� Gao ���ֵ� bug.. �ȼ�װ reply���£�ȴ�� Qȡ���� Ȼ��ȥ
     * Admin/Xfile�����ѡһ���༭�� ��ͻᷢ���ܳ� reply����ʱ��ѡ���ˡ�
     */
    *quote_file = '\0';
    return XO_FOOT;

  case 'b':
    curredit = EDIT_BOTH;
    break;
  }

  /*
   * Thor.1105: ������ת����, ����Ҫת����, ���Ǳ�վ�ɿ�����,
   * ���Ի���Ҳ��Ӧ��ת��
   */
  if (hdr->xmode & (POST_INCOME | POST_OUTGO))
    curredit |= POST_OUTGO;

  strcpy(quote_user, hdr->owner);
  strcpy(quote_nick, hdr->nick);
  return do_post(hdr->title);
}


static int
post_reply(xo)
  XO *xo;
{
  if (bbstate & STAT_POST)
  {
    HDR *hdr;

    hdr = (HDR *) xo_pool + (xo->pos - xo->top);
    if (!(hdr->xmode & (POST_CANCEL | POST_DELETE)))
    {
      hdr_fpath(quote_file, xo->dir, hdr);
      return do_reply(hdr);
    }
  }
  return XO_NONE;
}


/* ----------------------------------------------------- */
/* ���幦�ܱ�						 */
/* ----------------------------------------------------- */

#ifdef HAVE_MODERATED_BOARD
extern int XoBM();
#endif


/* ----------------------------------------------------- */


static int post_add();
static int post_body();
static int post_head();		/* Thor: ��Ϊ XoBM Ҫ�� */


#ifdef XZ_XPOST
static int XoXpost();		/* Thor: for XoXpost */
#endif

static int
post_init(xo)
  XO *xo;
{
  xo_load(xo, sizeof(HDR));
#ifdef HAVE_HOT_MODE
  if((xo->key == XZ_HOT) && !xo->pos) xo->pos = xo->max - 1;
#endif
  return post_head(xo);
}


static int
post_load(xo)
  XO *xo;
{
  xo_load(xo, sizeof(HDR));
  return post_body(xo);
}


static int
post_attr(fhdr)
  HDR *fhdr;
{
  int mode, attr;

  mode = fhdr->xmode;

  if (mode & POST_CANCEL)
    return 'c';

  if (mode & POST_DELETE)
    return 'd';

  attr = brh_unread(fhdr->chrono) ? 0 : 0x20;
  mode &= (bbstate & STAT_BOARD) ? ~0 : ~POST_GEM;
  /* Thor:һ��user������G */

#ifdef HAVE_HOT_MODE
  if(!(mode & POST_MARKED) && !(mode &  POST_GEM) && (mode & POST_HOT))
    attr |= 'H';
  else
#endif

  if (mode &= (POST_MARKED | POST_GEM))
    attr |= (mode == POST_MARKED ? 'M' : (mode == POST_GEM ? 'G' : 'B'));

  else if (!attr)
    attr = '+';

  return attr;
}


static void
post_item(num, hdr)
  int num;
  HDR *hdr;
{

#ifdef	HAVE_DECORATE
#ifdef HAVE_HOT_MODE
  prints(hdr->xmode & POST_HOT ? "%6d \033[1;31m%c\033[m" : (hdr->xmode & POST_MARKED ? "%6d \033[1;36m%c\033[m" : "%6d %c"), num, post_attr(hdr));
#else
 prints(hdr->xmode & POST_MARKED ? "%6d \033[1;36m%c\033[m" : "%6d %c", num, post_attr(hdr));
#endif
#else
  prints("%6d %c", num, post_attr(hdr));
#endif

  /* Thor.990418: HYL.bbs@Rouge.Dorm10.NCTU.edu.tw patch
                  ��Ȼ��title > 46����ʱ������ҵ�... */
  hdr_outs(hdr, 47); 
  /* hdr_outs(hdr, 46); */
}


static int
post_body(xo)
  XO *xo;
{
  HDR *fhdr;
  int num, max, tail;

  max = xo->max;
  if (max <= 0)
  {
    if (bbstate & STAT_POST)
    {
      if (vans("Ҫ����������(Y/N) [N] ") == 'y')
	return post_add(xo);
    }
    else
    {
      vmsg("��������������");
    }
    return XO_QUIT;
  }

  fhdr = (HDR *) xo_pool;
  num = xo->top;
  tail = num + XO_TALL;
  if (max > tail)
    max = tail;

  move(3, 0);
  do
  {
    post_item(++num, fhdr++);
  } while (num < max);

  clrtobot();
  update_foot();
  return XO_NONE;
}


static int			/* Thor: ��Ϊ XoBM Ҫ�� */
post_head(xo)
  XO *xo;
{
  vs_head(currBM, xo->xyz);
  outs("\
[��]�뿪 [��]�Ķ� [^P]���� [b]����¼ [d]ɾ�� [V]ͶƱ [TAB]������ [h]elp\n\
\033[44m  ���   �� ��  ��  ��       ��  ��  ��  ��                                   \033[m");
  return post_body(xo);
}


static int
post_visit2(xo)
  XO *xo;
{
  int row, max;
  HDR *fhdr;

  row = xo->top;
  max = xo->max - xo->top + 3;
  if (max > b_lines)
      max = b_lines;

  fhdr = (HDR *) xo_pool;
  row = 3;
  
  /* hightman.010412: ��Ϊǰ�Ѷ���δ�� */
  brh_visit(fhdr[xo->pos - xo->top].chrono);   

  do
  {
    move(row, 7);
    outc(post_attr(fhdr++));
  } while (++row < max);

  return XO_FOOT;
}


static int
post_visit(xo)
  XO *xo;
{
  int ans, row, max;
  HDR *fhdr;

  ans = vans("�趨�������� (U)δ�� (V)�Ѷ� (W)ǰ�Ѷ���δ�� (Q)ȡ���� [Q] ");
  if (ans == 'v' || ans == 'u' || ans == 'w')
  {

    row = xo->top;
    max = xo->max - xo->top + 3;
    if (max > b_lines)
      max = b_lines;

    fhdr = (HDR *) xo_pool;
    row = 3;
    /* Thor.990430: ���� ǰ�Ѷ���δ�� */
    switch(ans)
    {
     case 'v': brh_visit(0);break;
     case 'u': brh_visit(1);break;
     case 'w': brh_visit(fhdr[xo->pos - xo->top].chrono);break;
    }

    do
    {
      move(row, 7);
      outc(post_attr(fhdr++));
    } while (++row < max);
  }
  return XO_FOOT;
}


int
getsubject(row, reply)
  int row;
  int reply;
{
  char *title;

  title = ve_title;

  if (reply)
  {
    char *str;

    str = currtitle;
    if(STR4(str) == STR4(STR_REPLY)) /* Thor.980914: �бȽϿ����? */
#if 0
    if (str[0] == 'R' && str[1] == 'e' && str[2] == ':' && str[3] == ' ')
#endif
    {
      strcpy(title, str);
    }
    else
    {
      sprintf(title, STR_REPLY "%s", str);
      title[TTLEN] = '\0';
    }
  }
  else
  {
    *title = '\0';
  }

  return vget(row, 0, "���⣺", title, TTLEN + 1, GCARRY);
}


static int
post_add(xo)
  XO *xo;
{
  int cmd;

#ifdef HAVE_HOT_MODE
  if(xo->key == XZ_HOT)
   {
    zmsg("��������ժģʽ�������޷���ɡ������뿪");
    return XO_FOOT;
   }
#endif

  curredit = EDIT_OUTGO;
  cmd = do_post(NULL);
  return cmd;
}


int
post_cross(xo)
  XO *xo;
{
  char xboard[20], fpath[80], xfolder[80], xtitle[80], buf[80], *dir;
  HDR *hdr, xpost, xhdr;
  int method, rc, tag, locus, battr;
  FILE *xfp;

  if (!cuser.userlevel)
    return XO_NONE;

#ifdef SECURE_SYSLOG	/* hightman: �߼���ȫ���� */
  if(!str_cmp(currboard, BRD_SYSLOG))
   return XO_NONE;
#endif   

  /* lkchu.990428: mat patch ��������δѡ��ʱ������cross post����ߵ����� */
  if (bbsmode == M_READA)
  {
    battr = (bshm->bcache + brd_bno(currboard))->battr;
    if (!HAS_PERM(PERM_SYSOP) && (battr & BRD_NOFORWARD))
    {
      outz("�� �˰����²���ת��");
      return -1;
    }
  }

  /* lkchu.981201: ����ת�� */
  tag = AskTag("ת��");
  if (tag < 0)
    return XO_FOOT;

  if (ask_board(xboard, BRD_W_BIT,
      "\n\n[1;33m����ѡ�ʵ��Ŀ��壬����ת���������塣[m\n\n")
    && (*xboard || xo->dir[0] == 'u'))	/* �����п���ת����currboard */
  {
    if (*xboard == 0)
      strcpy(xboard, currboard);

    hdr = tag ? &xhdr : (HDR *) xo_pool + (xo->pos - xo->top);
          /* lkchu.981201: ����ת�� */
          
    method = 1;
    if ((HAS_PERM(PERM_ALLBOARD) || (!strcmp(hdr->owner, cuser.userid) && (cuser.firstlogin < hdr->chrono))) &&
    /* hightman.010713: ��ֹС������! */
      (vget(2, 0, "(1)ԭ��ת�� (2)ת¼���£�[1] ", buf, 3, DOECHO) != '2'))
    {
      method = 0;
    }

    if (!tag)   /* lkchu.981201: ����ת¼�Ͳ�Ҫһһѯ�� */
    {
      if (method)
        sprintf(xtitle, "[ת¼]%.66s", hdr->title);
      else
        strcpy(xtitle, hdr->title);

      if (!vget(2, 0, "���⣺", xtitle, TTLEN + 1, GCARRY))
        return XO_HEAD;
    }
    
    rc = vget(2, 0, "(S)�浵 (L)վ�� (Q)ȡ����[Q] ", buf, 3, LCECHO);
    if (rc != 'l' && rc != 's')
      return XO_HEAD;
      
    locus = 0;
    dir = xo->dir;

    battr = (bshm->bcache + brd_bno(xboard))->battr; 

    do	/* lkchu.981201: ����ת�� */
    {
      if (tag)
      {
        EnumTagHdr(hdr, dir, locus++);

        if (method)
          sprintf(xtitle, "[ת¼]%.66s", hdr->title);
        else
          strcpy(xtitle, hdr->title);
      }

      /* if (rc == 'l' || rc == 's') */
      /* lkchu.981201: ��ִ�е����ʾ rc Ϊ 's' or 'l' */
      {
        /* hdr_fpath(fpath, xo->dir, hdr); */
        xo_fpath(fpath, dir, hdr);      /* lkchu.981201 */
        brd_fpath(xfolder, xboard, fn_dir);

        if (method)
        {
  	  method = hdr_stamp(xfolder, 'A', &xpost, buf);
  	  xfp = fdopen(method, "w");

  	  strcpy(ve_title, xtitle);
  	  strcpy(buf, currboard);
  	  strcpy(currboard, xboard);

  	  ve_header(xfp);

  	  strcpy(currboard, buf);

  	  if (hdr->xname[0] == '@')
  	    sprintf(buf, "%s] ����", cuser.userid);
  	  else
  	    strcat(buf, "] ����");
  	  fprintf(xfp, "�� ����ת¼�� [%s\n\n", buf);

  	  f_suck(xfp, fpath);
  	  /* ve_sign(xfp); */
  	  fclose(xfp);
  	  close(method);

    	  strcpy(xpost.owner, cuser.userid);
  	  /* if (rc == 's') */
  	    strcpy(xpost.nick, cuser.username);
        }
        else
        {
  	  hdr_stamp(xfolder, HDR_LINK | 'A', &xpost, fpath);
  	  memcpy(xpost.owner, hdr->owner,
  	  sizeof(xpost.owner) + sizeof(xpost.nick));
          memcpy(xpost.date, hdr->date, sizeof(xpost.date));
                                 /* lkchu.981201: ԭ��ת�ر���ԭ���� */
        }

        /* Thor.981205: ���� method ��ſ������� */
        /* method = (bshm->bcache + brd_bno(xboard))->battr; */

        /* Thor.990111: �ڿ���ת��ǰ, Ҫcheck user��û��ת����Ȩ��? */
        if (!HAS_PERM(PERM_INTERNET) || (/* method */ battr & BRD_NOTRAN))
          rc = 'l';

        strcpy(xpost.title, xtitle);

        if (rc == 's' && (!(battr & BRD_NOTRAN)))
  	  xpost.xmode = POST_OUTGO;

        rec_add(xfolder, &xpost, sizeof(xpost));

        if (rc == 's' && (!(battr & BRD_NOTRAN)))
  	  outgo_post(&xpost, xboard);
      }
    } while (locus < tag);
       
    /* Thor.981205: check ��ת�İ���û�������¼? */
    if (/* method */ battr & BRD_NOCOUNT)
    {
      outs("ת¼��ɣ����²������¼�����������");
    }
    else
    {
      /* cuser.numposts++; */
      cuser.numposts += (tag == 0) ? 1 : tag; /* lkchu.981201: Ҫ�� tag */
      vmsg("ת¼���");
    }
  }
  return XO_HEAD;
}


/* ----------------------------------------------------- */
/* ����֮�����edit / title				 */
/* ----------------------------------------------------- */


static void
post_history(xo, fhdr)
  XO *xo;
  HDR *fhdr;
{
  int prev, chrono, next, pos, top;
  char *dir;
  HDR buf;

  chrono = fhdr->chrono;
  if (!brh_unread(chrono))
    return;

  dir = xo->dir;
  pos = xo->pos;
  top = xo->top;

  if (--pos >= top)
  {
    prev = fhdr[-1].chrono;
  }
  else
  {
    if (!rec_get(dir, &buf, sizeof(HDR), pos))
      prev = buf.chrono;
    else
      prev = chrono;
  }

  pos += 2;
  if (pos < top + XO_TALL)
    next = fhdr[1].chrono;
  else
  {
    if (!rec_get(dir, &buf, sizeof(HDR), pos))
      next = buf.chrono;
    else
      next = chrono;
  }

  brh_add(prev, fhdr->chrono, next);
}


static int
post_browse(xo)
  XO *xo;
{
  HDR *hdr;
  int cmd, xmode, pos;
  char *dir, fpath[64];

  int key;

  dir = xo->dir;
  cmd = XO_NONE;

  for (;;)
  {

    pos = xo->pos;
    hdr = (HDR *) xo_pool + (pos - xo->top);
    xmode = hdr->xmode;
    if (xmode & (POST_CANCEL | POST_DELETE))
      break;

    hdr_fpath(fpath, dir, hdr);

    /* Thor.990204: Ϊ����more ����ֵ */   
    if ((key = more(fpath, MSG_POST)) < 0)
      break;
    cmd = XO_HEAD;
    post_history(xo, hdr);
    strcpy(currtitle, str_ttl(hdr->title));

    switch (xo_getch(xo, key))
    {
    case XO_BODY:
      continue;

    case 'y':
    case 'r':
      if (bbstate & STAT_POST)
      {
	strcpy(quote_file, fpath);
	if (do_reply(hdr) == XO_INIT)	/* �гɹ��� post ��ȥ�� */
	  return post_init(xo);
      }
      break;

    case 'm':
      if ((bbstate & STAT_BOARD) && !(xmode & POST_MARKED))
      {
	hdr->xmode = xmode | POST_MARKED;
	rec_put(dir, hdr, sizeof(HDR), pos);
      }
      break;
    }
    break;
  }

  return cmd;
}


/* ----------------------------------------------------- */
/* ������						 */
/* ----------------------------------------------------- */


static int
post_gem(xo)
  XO *xo;
{
  char fpath[32];

  strcpy(fpath, "gem/");
  strcpy(fpath + 4, xo->dir);

  /* Thor.990118: �����ܹܲ��� GEM_SYSOP */
  XoGem(fpath, "", HAS_PERM(PERM_SYSOP) ? GEM_SYSOP :
    (bbstate & STAT_BOARD ? GEM_MANAGER : GEM_USER));

  return post_init(xo);
}


/* ----------------------------------------------------- */
/* ���屸��¼						 */
/* ----------------------------------------------------- */


static int
post_memo(xo)
  XO *xo;
{
  char fpath[64];

  brd_fpath(fpath, currboard, fn_note);
  /* Thor.990204: Ϊ����more ����ֵ */   
  if (more(fpath, NULL) < 0)
  {
    vmsg("���������ޡ�����¼��");
    return XO_FOOT;
  }

  return post_head(xo);
}


static int
post_memo_edit(xo)
  XO *xo;
{
  int mode;
  char fpath[64];

  if (!(bbstate & STAT_BOARD))
    return XO_NONE;

  mode = vans("����¼ (D)ɾ�� (E)�޸� (Q)ȡ����[E] ");
  if (mode != 'q')
  {
    brd_fpath(fpath, currboard, fn_note);
    if (mode == 'd')
    {
      unlink(fpath);
    }
    else
    {
      if (vedit(fpath, NA)) /* Thor.981020: ע�ⱻtalk������ */
	vmsg(msg_cancel);
      return post_head(xo);
    }
  }
  return XO_FOOT;
}


static int
post_switch(xo)
  XO *xo;
{
  int bno;
  BRD *brd;
  char bname[16];

  if (brd = ask_board(bname, BRD_R_BIT, NULL))
  {
    if (*bname && ((bno = brd - bshm->bcache) >= 0))
    {
      XoPost(bno);
      return XZ_POST;
    }
  }
  else
  {
    vmsg(err_bid);
  }
  return post_head(xo);
}

/* ----------------------------------------------------- */
/* ����ͣȨ����   w ��ˮͰ����  ^w  ����ͣȨ             */
/* ----------------------------------------------------- */
/* hightman.000704: ����ˮͰ�������� */

#ifdef HAVE_BM_DENYPOST
static int
post_deny(xo)
  XO *xo;
{
  char fpath[64];

  brd_fpath(fpath, currboard, fn_deny);

  if (more(fpath, NULL) < 0)
  {
    vmsg("���������ޡ�ˮͰ������");
    return XO_FOOT;
  }
  return post_head(xo);
}


static int
post_deny_edit(xo)
  XO *xo;
{
  int mode;
  char fpath[64];

  if (!(bbstate & STAT_BOARD))
    return XO_NONE;

  mode = vans("ˮͰ���� (E)�޸� (Q)ȡ����[E] ");
  if (mode != 'q')
  {
    brd_fpath(fpath, currboard, fn_deny);
    if (mode == 'd')
    {
      unlink(fpath);
    }
    else
    {
      if (vedit(fpath, NA)) /* Thor.981020: ע�ⱻtalk������ */
        vmsg(msg_cancel);
      return post_head(xo);
    }
  }
  return XO_FOOT;
}

#endif	/* hightman.000704: ����ˮͰ�������� */

/* ----------------------------------------------------- */
/* ���ܣ�tag / copy / forward / download		 */
/* ----------------------------------------------------- */


static int
post_tag(xo)
  XO *xo;
{
  HDR *hdr;
  int tag, pos, cur;

  pos = xo->pos;
  cur = pos - xo->top;
  hdr = (HDR *) xo_pool + cur;

#ifdef XZ_XPOST
  if (xo->key == XZ_XPOST)
    pos = hdr->xid;
#endif

  if (tag = Tagger(hdr->chrono, pos, TAG_TOGGLE))
  {
    move(3 + cur, 8);
    outc(tag > 0 ? '*' : ' ');
  }

  /* return XO_NONE; */
  return xo->pos + 1 + XO_MOVE; /* lkchu.981201: ������һ�� */
}


/* ----------------------------------------------------- */
/* �������ܣ�mark / delete				 */
/* ----------------------------------------------------- */

#ifdef HAVE_COUNT_MARK	/* hightman.011028: ͳ�Ʊ�mark������ */
static int
set_mark_count(userid, xmode)
  char *userid;
  int xmode;
{
  ACCT acct;
  if(acct_load(&acct, userid) < 0) return;
  (xmode & POST_MARKED) ? acct.nummark++ : acct.nummark--;
  if(acct.nummark < 0) acct.nummark = 0;
  acct_save(&acct);
  return 1;
}
#endif

static int
post_mark(xo)
  XO *xo;
{
  if (bbstate & STAT_BOARD)
  {
    HDR *hdr;
    int pos, cur;

    pos = xo->pos;
    cur = pos - xo->top;
    hdr = (HDR *) xo_pool + cur;
    hdr->xmode ^= POST_MARKED;

#ifdef HAVE_COUNT_MARK	/* hightman.011028: ͳ�Ʊ�mark������ */
    if(!(bbstate & BRD_NOCOUNT))
    	set_mark_count(hdr->owner, hdr->xmode);
#endif
    
#ifdef HAVE_HOT_MODE
    rec_put(xo->dir, hdr, sizeof(HDR), (xo->key == XZ_POST || xo->key == XZ_HOT) ? pos : hdr->xid);
#else
    rec_put(xo->dir, hdr, sizeof(HDR), xo->key == XZ_POST ? pos : hdr->xid);
#endif

    move(3 + cur, 7);
    outc(post_attr(hdr));
  }
  return XO_NONE;
}


#ifdef HAVE_HOT_MODE	/* hightman.010412: hot mark */

extern KeyFunc post_cb[];

static void
XoHot(folder, title)
  char *folder;
  char *title;
{
  XO *xo, *last;

  last = xz[XZ_HOT - XO_ZONE].xo;       /* record */

  xz[XZ_HOT - XO_ZONE].xo = xo = xo_new(folder);
  xz[XZ_HOT - XO_ZONE].cb = post_cb;
  xo->xyz = title;
  xo->key = XZ_HOT;   //����������ģʽ

  xover(XZ_HOT);

  free(xo);

  xz[XZ_HOT - XO_ZONE].xo = last;       /* restore */

#ifdef LOG_BRD_USIES
  /* lkchu.981201: �Ķ������¼ */
  brd_usies();
#endif
}

static int
post_hot(xo) /* hightman.011028: �������� */
 XO *xo;
{
 if ((bbstate & STAT_BOARD) && xo->key != XZ_HOT)
  {
    HDR *hdr;
    int pos, cur, tmp_mode;
    char fpath[256];

    str_folder(fpath, xo->dir, FN_GEM);

    pos = xo->pos;                           
    cur = pos - xo->top;
    hdr = (HDR *) xo_pool + cur;
    currchrono = hdr->chrono;
    tmp_mode = hdr->xmode;

   if(hdr->xmode & POST_HOT)  /* �Ѿ����˵ľ�ȡ��,���ǵľ������ϡ� */
      rec_del(fpath, sizeof(HDR),
            hdr->xid, cmpchrono, NULL);
    else
    {
      hdr->xmode = 0; /* ��� */
      rec_add(fpath, hdr, sizeof(HDR));
    }

    hdr->xmode = tmp_mode;
    hdr->xmode ^= POST_HOT;
    rec_put(xo->dir, hdr, sizeof(HDR), pos);

    move(3 + cur, 7);
    outc(post_attr(hdr));
  }
  return XO_NONE;
}

static int
hot_read(xo)
  XO *xo;
{
  char fpath[64];
  char buf[128];

  if(xo->key == XZ_HOT)  /* �Ѿ������ģʽ�˾ͻ���ȥ */
   { 
    xo->key = XZ_POST;
    return XO_QUIT;
  }

  str_folder(fpath, xo->dir, FN_GEM);
  if (rec_num(fpath, sizeof(HDR)) <= 0)
  {
    zmsg("Ŀǰ����û����������");
    return XO_FOOT;
  }
 
  sprintf(buf, "�� ���������Ķ� ��");
  XoHot(fpath, buf);
  return XO_INIT;
}

static int
hdr_cmp(i, j)
  HDR *i, *j;
{
  return (i->chrono - j->chrono);
}

static int
hot_sync(xo)
 XO *xo;
{
  int fd, size;
  struct stat st;

  if (!(bbstate & STAT_BOARD) || (xo->key != XZ_HOT)) return XO_NONE;

  if ((fd = open(xo->dir, O_RDWR, 0600)) < 0)  /* ���� */
  return XO_NONE;

  outz("�� �������������У����Ժ� \033[5m...\033[m");
  refresh();

  if (!fstat(fd, &st) && (size = st.st_size) > 0) /* ������Ҫ�� */
  {
    HDR *base, *head, *tail;
    char fpath[64];

    base = head = (HDR *) malloc(size); /* �����ڴ� */
    size = read(fd, base, size);
    if (size >= sizeof(HDR)) /* ����һ�� */
    {
      tail = (HDR *) ((char *) base + size);
      while (head < tail)
      {
        hdr_fpath(fpath, xo->dir, head);
        head->xmode = 0;
        if(((time(0) - head->chrono) < 30 * 86400) && !access(fpath,0))
		 /* һ�����˲����ȣ����¶������˻��ȣ�*/
        {
          head++;
          continue;
        }
        tail--;
        if (head >= tail) /* ��û�� */
          break;
        memcpy(head, tail, sizeof(HDR));
      }

      size = (char *) tail - (char *) base;
      if (size > 0)
      {
        if (size > sizeof(HDR))
        {
          if (size > 150 * sizeof(HDR))
            vmsg("�ð���������¶��150ƪ�����Ƽ�����");
          xsort(base, size / sizeof(HDR), sizeof(HDR), hdr_cmp);
        }

        lseek(fd, 0, SEEK_SET);
        write(fd, base, size);
        ftruncate(fd, size);
      }
    }
    free(base);
  }
  close(fd);

  if (size <= 0)
    unlink(xo->dir); /* ��û�˻�������ɶ */

  return XO_INIT;
}

static int
hot_delete(xo)
  XO *xo;
{
  int pos, cur;
  HDR *fhdr;
 
 if(xo->key != XZ_HOT)
   return XO_NONE;
 if (!(bbstate & STAT_BOARD))
    return XO_NONE;

  pos = xo->pos;
  cur = pos - xo->top;
  fhdr = (HDR *) xo_pool + cur;

 if (vans(msg_del_ny) == 'y')
   rec_del(xo->dir, sizeof(HDR), pos, cmpchrono, NULL);
   /* ��ȥ, û��Ҫ������ϵ�h����� */
  return XO_LOAD;   
}

#endif

static int
lazy_delete(hdr)
  HDR *hdr;
{
  sprintf(hdr->title, "<< �����¾� %s ɾ�� >>", cuser.userid);
  hdr->xmode |= POST_DELETE;
  return 0;
}

#ifdef HAVE_CLEAR_LAZYDEL
static int
pack_delete(xo)
  XO* xo;
{
  int count, fdr, fsize, xmode, cancel, dmode;
  HDR *hdr, *fhdr;
  FILE *fpw;
  char fnew[80], fold[80];
  char *folder;
  int pos, cur, by_BM;

#define BN_DELETED      "deleted"
#define BN_JUNK         "junk"

#ifdef HAVE_HOT_MODE
  if(xo->key == XZ_HOT) return hot_sync(xo); 
#endif

  pos = xo->pos;
  cur = pos - xo->top;
  fhdr = (HDR *) xo_pool + cur;

  if (!cuser.userlevel ||
    !strcmp(currboard, BN_DELETED) ||
    !strcmp(currboard, BN_JUNK))
    return XO_NONE;

  /* by_BM = strcmp(fhdr->owner, cuser.userid); */
  by_BM = (strcmp(fhdr->owner, cuser.userid) ||
                 (cuser.firstlogin > fhdr->chrono) );
                 /* hightman.011028: ��ɱ���ܸ��������~ ����ͬ��Ȼ�� */

  if (!(bbstate & STAT_BOARD) && by_BM)
    return XO_NONE;

  folder = xo->dir;
  if ((fdr = open(folder, O_RDONLY)) < 0)
    return -1;


  if (!(fpw = f_new(folder, fnew)))
  {
    close(fdr);
    return -1;
  }
  xmode = *folder;
  cancel = (xmode == 'b');
  dmode = (xmode == 'u') ? 0 : (POST_CANCEL | POST_DELETE);

  fsize = count = 0;
  mgets(-1);
  while (hdr = mread(fdr, sizeof(HDR)))
  {
    xmode = hdr->xmode;
    count++;
    if (xmode & dmode)          /* ��ɾ�� */
    {
       if (cancel)
         cancel_post(hdr);
         
       hdr_fpath(fold, folder, hdr);
       unlink(fold);
    }
    else
    {
      if ((fwrite(hdr, sizeof(HDR), 1, fpw) != 1))
      {
        close(fdr);
        fclose(fpw);
        unlink(fnew);
        return -1;
      }
      fsize++;
    }
  }
  close(fdr);
  fclose(fpw);

  sprintf(fold, "%s.o", folder);
  rename(folder, fold);
  if (fsize)
    rename(fnew, folder);
  else
    unlink(fnew);

  return 0;

}

#endif


static int
post_delete(xo)
  XO *xo;
{
  int pos, cur, by_BM;
  HDR *fhdr;
  char buf[80];
  ACCT xuser;      /* ɾˮ���¼�ȥ��ˮ������ */
  char xuserid[14];

#ifdef SECURE_SYSLOG	/* hightman: �߼���ȫ���� */
if(!str_cmp(currboard, BRD_SYSLOG))
  return XO_NONE; 
#endif  

#ifdef HAVE_HOT_MODE
if(xo->key == XZ_HOT)
   return hot_delete(xo);
#endif

#define BN_DELETED	"deleted"
#define BN_JUNK		"junk"

  if (!cuser.userlevel ||
    !strcmp(currboard, BN_DELETED) ||
    !strcmp(currboard, BN_JUNK))
    return XO_NONE;

  pos = xo->pos;
  cur = pos - xo->top;
  fhdr = (HDR *) xo_pool + cur;

  if (fhdr->xmode & (POST_MARKED | POST_CANCEL | POST_DELETE))
    return XO_NONE;
 
  strcpy(xuserid, fhdr->owner);
  /* copy ���� */
  by_BM = (strcmp(fhdr->owner, cuser.userid) || 
                                       (cuser.firstlogin > fhdr->chrono) );
                                         /* hightman.010713: ���ע��ʱ���
                                         * ����ʱ�仹�����ǲ�һ�����������
                                         * �������޸ġ�
                                         */
        

 if (!(bbstate & STAT_BOARD) && by_BM)
    return XO_NONE;

  if (vans(msg_del_ny) == 'y')
  {
    currchrono = fhdr->chrono;

    /* Thor.980911: for ���������� in ���� */
    /* if (!rec_del(xo->dir, sizeof(HDR), xo->pos, cmpchrono, lazy_delete)) */
    if (!rec_del(xo->dir, sizeof(HDR), xo->key == XZ_POST ? pos : fhdr->xid, cmpchrono, lazy_delete))
    {
      move_post(fhdr, by_BM ? BN_DELETED : BN_JUNK, by_BM);
      if (!by_BM && !(bbstate & BRD_NOCOUNT))
      {
         acct_load(&cuser, cuser.userid);
	if (cuser.numposts > 0)
         cuser.numposts--;
        /* hightman: ������,��������ȥ��  cuser.money-=300;   ����300 */
         acct_save(&cuser);
         sprintf(buf, "%s���������¼�Ϊ %d ƪ!", 
                                        MSG_DEL_OK, cuser.numposts);
	vmsg(buf);
      }
      else if(by_BM && !(bbstate & BRD_NOCOUNT)) 
         {   
             acct_load(&xuser, xuserid); 
             if (xuser.numposts > 0) xuser.numposts --;
             /* hightman: ������ xuser.money-=400; �������� ��400 */
             acct_save(&xuser);
      }
#ifdef HAVE_HOT_MODE	/* ���hot��� */
    if(fhdr->xmode & POST_HOT)
     {
      char fpath[64];
      str_folder(fpath, xo->dir, FN_GEM);
      rec_del(fpath, sizeof(HDR), 0, cmpchrono, NULL);
     }
#endif
      lazy_delete(fhdr); /* Thor.980911: ע��: �޸� xo_pool */
      move(3 + cur, 0);
      post_item(++pos, fhdr); 
    }
  }
  return XO_FOOT;

#undef	BN_DELETED
#undef	BN_JUNK
}


/* ----------------------------------------------------- */
/* վ�����ܣ�edit / title				 */
/* ----------------------------------------------------- */


static int
post_edit(xo)
  XO *xo;
{
  HDR *hdr;
  FILE *fp;
  char fpath[80];
  int ans, num;

#ifdef SECURE_SYSLOG	/* hightman: �߼���ȫ���� */
  if(!str_cmp(currboard, BRD_SYSLOG))
   return XO_NONE;
#endif   

  hdr = (HDR *) xo_pool + (xo->pos - xo->top);

  num = cuser.userlevel;
  if (!(num & PERM_POST))
    return XO_NONE;

  /* Kenghua990827:�����ɵ��˻���ɶ.. */
  if (hdr->xmode & (POST_CANCEL | POST_DELETE))
    return XO_NONE;

  /* Kenghua.990827:����Ҳ�����޸� */
  if ((cuser.userlevel & PERM_ALLBOARD) || 
     (!strcmp(hdr->owner, cuser.userid) && (cuser.firstlogin < hdr->chrono))|| 
					/* hightman.010713: ���ע��ʱ���
                                         * ����ʱ�仹�����ǲ�һ�����������
                                         * �������޸ġ�
                                         */
       (bbstate & STAT_BOARD))
  {
    hdr_fpath(fpath, xo->dir, hdr);
    ans = vedit(fpath, NA);
    /* Kenghua.990904:Ϊ�˰�ȫ,��վ���޸Ļ�ȡ��������޸���Ѷ */
    if (!((cuser.userlevel & PERM_ALLBOARD) || (ans)))
     if (fp = fopen(fpath, "a"))
     {
       fprintf(fp, "\033[1;33m�� �޸�: \033[35m%s\033[37m<%s> \033[m\n",
     Now(), fromhost);
       fclose(fp);
     }

    post_head(xo);
  }

  return XO_NONE;
}


static int
post_title(xo)
  XO *xo;
{
  HDR *fhdr, mhdr;
  int pos, cur;

/* hightman: �ð���Ҳ�ܸİ� */
/*
  if (!HAS_PERM(PERM_ALLBOARD))
    return XO_NONE;
*/

#ifdef SECURE_SYSLOG	/* hightman: �߼���ȫ���� */
  if(!str_cmp(currboard, BRD_SYSLOG))
    return XO_NONE;
#endif

  pos = xo->pos;
  cur = pos - xo->top;
  fhdr = (HDR *) xo_pool + cur;
  mhdr = *fhdr;

  if ((strcmp(cuser.userid,mhdr.owner) || (cuser.firstlogin>mhdr.chrono))
     && (!(cuser.userlevel & PERM_ALLBOARD))
     && (!(bbstate & STAT_BOARD)))
    return XO_NONE;

  vget(b_lines, 0, "���⣺", mhdr.title, sizeof(mhdr.title), GCARRY);
  if (HAS_PERM(PERM_ALLBOARD)) {
    vget(b_lines, 0, "���ߣ�", mhdr.owner, 74 /* sizeof(mhdr.owner)*/, GCARRY);
           /* Thor.980727:lkchu patch: sizeof(mhdr.owner) = 80�ᳬ��һ�� */
    vget(b_lines, 0, "���ڣ�", mhdr.date, sizeof(mhdr.date), GCARRY);
  }
  if (vans(msg_sure_ny) == 'y' &&
    memcmp(fhdr, &mhdr, sizeof(HDR)))
  {
    *fhdr = mhdr;
    rec_put(xo->dir, fhdr, sizeof(HDR), pos);
    move(3 + cur, 0);
    post_item(++pos, fhdr);
  }
  return XO_FOOT;
}


#ifdef HAVE_TERMINATOR
static int
post_cross_terminator(xo)	/* Thor.0521: �ռ����´� */
  XO *xo;
{
  char *title, buf[100];

  if (!HAS_PERM(PERM_SYSOP))
    return XO_NONE;

#ifdef HAVE_HOT_MODE
  if(xo->key == XZ_HOT)
  {
   zmsg("��������ժģʽ�������޷���ɡ������뿪");
   return XO_FOOT;
  }
#endif
  title = currtitle;
  if (!*title)
    return XO_NONE;

  sprintf(buf, "���������ն�����⣺%.40s��ȷ����Y/[N]", title);
  if (vans(buf) == 'y')
  {
    BRD *bhdr, *head, *tail;

    /* Thor.0616: ���� currboard, �Ա㸴ԭ */
    strcpy(buf, currboard);

    head = bhdr = bshm->bcache;
    tail = bhdr + bshm->number;
    do				/* ������sysopһ�� */
    {
      int fdr, fsize, xmode;
      FILE *fpw;
      char fpath[80];
      char fnew[80], fold[80];
      HDR *hdr;

      /* Thor.0616:����currboard,��cancel post */

      strcpy(currboard, head->brdname);

#ifdef SECURE_SYSLOG	/* hightman: �߼���ȫ���� */
     if(!str_cmp(currboard, BRD_SYSLOG))
      continue;   /* hightman:... */
#endif      

      sprintf(fpath, "���������ն�����棺%s \033[5m...\033[m", currboard);
      outz(fpath);
      refresh();

      brd_fpath(fpath, currboard, fn_dir);

      if ((fdr = open(fpath, O_RDONLY)) < 0)
	continue;

      if (!(fpw = f_new(fpath, fnew)))
      {
	close(fdr);
	continue;
      }

      fsize = 0;
      mgets(-1);
      while (hdr = mread(fdr, sizeof(HDR)))
      {
	xmode = hdr->xmode;
	if (xmode & (POST_CANCEL | POST_DELETE))
	  continue;

	if ((xmode & POST_MARKED) || strcmp(title, str_ttl(hdr->title)))
	{
	  if ((fwrite(hdr, sizeof(HDR), 1, fpw) != 1))
	  {
	    fclose(fpw);
	    unlink(fnew);
	    close(fdr);
	    goto contWhileOuter;
	  }
	  fsize++;
	}
	else
	{
	  /* ��Ϊ��������߿��� */

	  cancel_post(hdr);
	  hdr_fpath(fold, fpath, hdr);
	  unlink(fold);
	}
      }
      close(fdr);
      fclose(fpw);

      sprintf(fold, "%s.o", fpath);
      rename(fpath, fold);
      if (fsize)
	rename(fnew, fpath);
      else
	unlink(fnew);

contWhileOuter:

    } while (++head < tail);

    strcpy(currboard, buf);
    post_load(xo);
  }

  return XO_FOOT;
}
#endif


static int
post_help(xo)
  XO *xo;
{
  film_out(FILM_BOARD, -1);
  return post_head(xo);
}


KeyFunc post_cb[] =
{
  XO_INIT, post_init,
  XO_LOAD, post_load,
  XO_HEAD, post_head,
  XO_BODY, post_body,

  'r', post_browse,
  's', post_switch,
  KEY_TAB, post_gem,
  'z', post_gem,

  'y', post_reply,
  'd', post_delete,
  'v', post_visit,
  'c', post_visit2,

  Ctrl('P'), post_add,
  Ctrl('X'), post_cross,
  Ctrl('Q'), xo_uquery,
  Ctrl('U'), xo_usetup,

#ifdef HAVE_CLEAR_LAZYDEL  
  'S', pack_delete,
#endif  

#if 1 /* Thor.981120: ��ʱȡ��, ������ */
      /* lkchu.981201: û�� 'D' �ܲ�ϰ�� :p */
  'D', xo_delete,
#endif

#ifdef HAVE_TERMINATOR
  'X', post_cross_terminator,
#endif

  't', post_tag,

  'E', post_edit,
  'T', post_title,
  'm', post_mark,
#ifdef HAVE_HOT_MODE
  'H', post_hot, /* hightman.010412: hot post mark */
#endif

#if 0
  'R', vote_result,
  'V', XoVote,
#endif
#if 1
  /* Thor.990220: �Ĳ���� */
  'R' | XO_DL, "bin/vote.so:vote_result",
  'V' | XO_DL, "bin/vote.so:XoVote",
#endif

  'b', post_memo,
  'W', post_memo_edit,

#ifdef HAVE_BM_DENYPOST		/* hightman.011028: sˮͰ */
  'w', post_deny,
  Ctrl('W'), post_deny_edit,
#endif  

/* ���ܼ����� */
#ifdef HAVE_HOT_MODE
  Ctrl('H'), hot_read, /* hightman.010412: hot read */
#endif

#ifdef HAVE_MODERATED_BOARD
  Ctrl('G'), XoBM,
#endif

#ifdef XZ_XPOST
  '~', XoXpost,			/* Thor: for XoXpost */
#if 0
  'M', XoMpost,
#endif
#endif

  'h', post_help
};


#ifdef XZ_XPOST
/*------------------------------------------------------------------------
  Thor.0509: �µ� ������Ѱģʽ
             ��ָ��һkeyword, �г�����keyword���֮�����б�

  �� tmp/ �¿� xpost.{pid} ��Ϊ folder, ����һmap����, ������ԭpost��map
  ���ظ���������ԭpost�ĺδ�, ��˿��� mark,gem,edit,title�ȹ���,
  �����뿪ʱ������Ӧ���´�
  <�����뷨 obsolete...>

  Thor.0510:
  �����������۴�, like tin, �����´� index ���� memory��,
  ��ʹ�� thread, ��Ϊ threadҪ�� folder��...

  ��Ϊ����Mode, Title & post list

  �������ṩ�򻯵� ���¼��ƶ�..

  O->O->O->...
  |  |  |
  o  o  o
  |  |  |

  index��field {next,text} ��Ϊint, ����Ҳ�� int
  ��һ�� sorted by title, ����ʱ�� binary search
  �� MMAP only , ��һ����ʾ # and +

  ���ṩ�κ�ɾ������, �������

  Thor.980911: �����ṩɾ��ָ��, ������
-------------------------------------------------------------------------*/
#if 0
extern XO *xpost_xo;		/* Thor: dynamic programmin for variable dir
				 * name */
extern XO *ypost_xo;
#endif


#define	MSG_XYPOST	"[����ģʽ]����ؼ���:"
#define	MSG_XY_NONE	"����һ��"


typedef struct
{
  char *subject;
  int first;
  int last;
  time_t chrono;
}      Chain;			/* Thor: negative is end */



static int
chain_cmp(a, b)
  Chain *a;
  Chain *b;
{
  return a->chrono - b->chrono;
}


static int *xypostI;


/* Thor: first ypost pos in ypost_xo.key */

static int comebackPos;

/* Thor: first xpost pos in xpost_xo.key */

static char xypostKeyword[30];


/* -1 to find length, otherwise return index */

static int
XoXpost(xo)			/* Thor: call from post_cb */
  XO *xo;
{
  int *plist, *xlist, fsize, max, locus, sum, i, m, n;
  Chain *chain;
  char *fimage, *key, author[30], buf[30];
  HDR *head, *tail;
  int filter_author;
  XO *xt;

  if ((max = xo->max) <= 0) /* Thor.980911: ע��: �Է���һ */
    return XO_FOOT;

  /* input condition */

  key = xypostKeyword;
  vget(b_lines, 0, MSG_XYPOST, key, sizeof(xypostKeyword), GCARRY);
  str_lower(buf, key);
  key = buf;

  if (filter_author = vget(b_lines, 0, "[����ģʽ]���ߣ�", author, 30, DOECHO))
  {
    filter_author = strlen(author);
    str_lower(author, author);
  }

  /* build index according to input condition */

  fimage = f_map(xo->dir, &fsize);

  if (fimage == (char *) -1)
  {
    vmsg("Ŀǰ�޷�����������");
    return XO_FOOT;
  }

  if (xlist = xypostI) /* Thor.980911: ע��: ���ظ�����ʱ, �˷Ѽ����� */
    free(xlist);

  /* allocate index memory, remember free first */

  /* Thor.990113: ����title,author��˲��������post */
  max = fsize / sizeof(HDR);
  
  plist = (int *) malloc(sizeof(int) * max);
  chain = (Chain *) malloc(sizeof(Chain) * max);

  max = sum = 0;

  head = (HDR *) fimage;
  tail = (HDR *) (fimage + fsize);

  locus = -1;
  do
  {
    int left, right, mid;
    char *title;

    locus++;
    if (head->xmode & (POST_CANCEL | POST_DELETE))
      continue;			/* Thor.0701: ���������������� */

    /* check author */

    /* Thor.981109: �ر�ע��, author�Ǵ�ͷmatch, ����substr match, Ϊ����load */
    if (filter_author && str_ncmp(head->owner, author, filter_author))
      continue;

    /* check condition */

    title = head->title;

    if (STR4(title) == STR4(STR_REPLY)) /* Thor.980911: �Ȱ� Re: ���� */
      title += 4;

    if (*key && !str_str(title, key))
      continue;

#if 0
    if (STR4(title) == STR4(STR_REPLY))
      title += 4;
#endif

    sum++;

    /* check if in table, binary check */

    left = 0;
    right = max - 1;
    for (;;)
    {
      int cmp;
      Chain *cptr;

      if (left > right)
      {
	for (i = max; i > left; i--)
	  chain[i] = chain[i - 1];

	cptr = &chain[left];
	cptr->subject = title;
	cptr->first = cptr->last = locus;
	cptr->chrono = head->chrono;
	max++;
	break;
      }

      mid = (left + right) >> 1;
      cptr = &chain[mid];
      cmp = strcmp(title, cptr->subject);

      if (!cmp)
      {
	plist[cptr->last] = locus;
	cptr->last = locus;
	break;
      }

      if (cmp < 0)
	right = mid - 1;
      else
	left = mid + 1;
    }
  } while (++head < tail);
  munmap(fimage, fsize);

  if (max <= 0)
  {
    free(chain);
    free(plist);
    vmsg(MSG_XY_NONE);
    return XO_FOOT;
  }

  if (max > 1)
    xsort(chain, max, sizeof(Chain), chain_cmp);

  xypostI = xlist = (int *) malloc(sizeof(int) * sum);

  i = locus = 0;
  do
  {
    xlist[locus++] = n = chain[i].first;
    m = chain[i].last;

    while (n != m)
    {
      xlist[locus++] = n = plist[n];
    }

  } while (++i < max);

  free(chain);
  free(plist);

  /* build XO for xpost_xo */

  if (xt = xz[XZ_XPOST - XO_ZONE].xo)
    free(xt);

  comebackPos = xo->pos;	/* Thor: record pos, future use */
  xz[XZ_XPOST - XO_ZONE].xo = xt = xo_new(xo->dir);
  xt->pos = 0;
  xt->max = sum;
  xt->xyz = xo->xyz;
  xt->key = XZ_XPOST;

  xover(XZ_XPOST);

  /* set xo->pos for new location */

  xo->pos = comebackPos;

  /* free xpost_xo */

  if (xt = xz[XZ_XPOST - XO_ZONE].xo)
  {
    free(xt);
    xz[XZ_XPOST - XO_ZONE].xo = NULL;
  }

  /* free index memory, remember check free pointer */

  if (xlist = xypostI)
  {
    free(xlist);
    xypostI = NULL;
  }

  return XO_INIT;
}

#if 0
/* Thor.980911: ���� post_body() ����*/
static int
xpost_body(xo)
  XO *xo;
{
  HDR *fhdr;
  int num, max, tail;

  max = xo->max;
#if 0
  if (max <= 0)
  { /* Thor.980911: ע��: �Է���һ�� */
    vmsg(MSG_XY_NONE);
    return XO_QUIT;
  }
#endif

  fhdr = (HDR *) xo_pool;
  num = xo->top;
  tail = num + XO_TALL;
  if (max > tail)
    max = tail;

  move(3, 0);
  do
  {
    post_item(++num, fhdr++);
  } while (num < max);

  clrtobot();
  return XO_NONE;
}

#endif

static int
xpost_head(xo)
  XO *xo;
{
  vs_head("���⴮��" /* currBM */ , xo->xyz);
  outs(MSG_XYPOST);
  if (*xypostKeyword)
    outs(xypostKeyword);

  outs("\n\
\033[44m  ���   �� ��  ��  ��       ��  ��  ��  ��                                   \033[m");

  /* return xpost_body(xo); */
  return post_body(xo); /* Thor.980911: ���ü��� */
}


static void
xypost_pick(xo)
  XO *xo;
{
  int *xyp, fsize, pos, max, top;
  HDR *fimage, *hdr;

  fimage = (HDR *) f_map(xo->dir, &fsize);
  if (fimage == (HDR *) - 1)
    return;

  hdr = (HDR *) xo_pool;
  xyp = xypostI;

  pos = xo->pos;
  xo->top = top = (pos / XO_TALL) * XO_TALL;
  max = xo->max;
  pos = top + XO_TALL;
  if (max > pos)
    max = pos;

  do
  {
    pos = xyp[top++];
    *hdr = fimage[pos];
    hdr->xid = pos;
    hdr++;
  } while (top < max);

  munmap((void *)fimage, fsize);
}


static int
xpost_init(xo)
  XO *xo;
{
  /* load into pool */

  xypost_pick(xo);

  return xpost_head(xo);
}


static int
xpost_load(xo)
  XO *xo;
{
  /* load into pool */

  xypost_pick(xo);

  /* return xpost_body(xo); */
  return post_body(xo); /* Thor.980911: ���ü��� */
}


static int
xpost_help(xo)
  XO *xo;
{
  film_out(FILM_BOARD, -1);
  return XO_HEAD;
}


/* Thor.0509: Ҫ��취���� ctrl('D') */


static int
xpost_browse(xo)
  XO *xo;
{
  HDR *hdr;
  int cmd, chrono, xmode;
  char *dir, fpath[64];

  int key;

  cmd = XO_NONE;
  dir = xo->dir;

  for (;;)
  {
    hdr = (HDR *) xo_pool + (xo->pos - xo->top);
    xmode = hdr->xmode;
    if (xmode & (POST_CANCEL | POST_DELETE))
      break;

    hdr_fpath(fpath, dir, hdr);

    /* Thor.990204: Ϊ����more ����ֵ */   
    if ((key = more(fpath, MSG_POST)) < 0)
      break;

    comebackPos = hdr->xid; 
    /* Thor.980911: �Ӵ���ģʽ����ʱҪ�ص���������ƪ����λ�� */

    cmd = XO_HEAD;

    chrono = hdr->chrono;
    if (brh_unread(chrono))
    {
      int prev, next, pos;
      char *dir;
      HDR buf;

      dir = xo->dir;
      pos = hdr->xid;

      if (!rec_get(dir, &buf, sizeof(HDR), pos - 1))
	prev = buf.chrono;
      else
	prev = chrono;

      if (!rec_get(dir, &buf, sizeof(HDR), pos + 1))
	next = buf.chrono;
      else
	next = chrono;

      brh_add(prev, hdr->chrono, next);
    }

    strcpy(currtitle, str_ttl(hdr->title));

    /* Thor.990204: Ϊ����more ����ֵ */   
    if(!key)
      key = vkey();

    switch (key)
    {
    case ']':  /* Thor.990204: ��ʱ����]����������� */
    case 'j':  /* Thor.990204: ��ʱ����j����������� */
    case ' ':
      {
        int pos = xo->pos + 1;

        /* Thor.980727: ��������ͷ��bug */

        if (pos >= xo->max)
    	  return cmd;

        xo->pos = pos;

        if (pos >= xo->top + XO_TALL)
  	  xypost_pick(xo);

        continue;
      }

    case 'y':
    case 'r':
      if (bbstate & STAT_POST)
      {
	strcpy(quote_file, fpath);
	if (do_reply(hdr) == XO_INIT)	/* �гɹ��� post ��ȥ�� */
	  return xpost_init(xo);
      }
      break;

    case 'm': 
      if ((bbstate & STAT_BOARD) && !(xmode & POST_MARKED)) 
      { 
        hdr->xmode = xmode | POST_MARKED; 
        rec_put(dir, hdr, sizeof(HDR), hdr->xid); 
      } 
      break; 

    }
    break;
  }

  return cmd;
}


KeyFunc xpost_cb[] =
{
  XO_INIT, xpost_init,
  XO_LOAD, xpost_load,
  XO_HEAD, xpost_head,
#if 0
  XO_BODY, xpost_body,
#endif
  XO_BODY, post_body, /* Thor.980911: ���ü��� */

  'r', xpost_browse,
  'y', post_reply,
  't', post_tag,
  'm', post_mark,

  'd', post_delete,  /* Thor.980911: �������*/

  Ctrl('P'), post_add,
  Ctrl('Q'), xo_uquery,
  Ctrl('U'), xo_usetup,
  Ctrl('X'), post_cross,

  'h', xpost_help
};
#endif
