/*-------------------------------------------------------*/
/* cache.c	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : cache up data by shared memory		 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#include "bbs.h"
#include <sys/ipc.h>
#include <sys/shm.h>


#ifdef	HAVE_SEM
#include <sys/sem.h>
#endif


#ifdef MODE_STAT
UMODELOG modelog;
time_t mode_lastchange;
#endif

static void
attach_err (shmkey, name)
     int shmkey;
     char *name;
{
  char buf[80];

  sprintf (buf, "key = %x", shmkey);
  blog (name, buf);
  exit (1);
}


static void *
attach_shm (shmkey, shmsize)
     int shmkey, shmsize;
{
  void *shmptr;
  int shmid;

  shmid = shmget (shmkey, shmsize, 0);
  if (shmid < 0)
    {
      shmid = shmget (shmkey, shmsize, IPC_CREAT | 0600);
      if (shmid < 0)
	attach_err (shmkey, "shmget");
    }
  else
    {
      shmsize = 0;
    }

  shmptr = (void *) shmat (shmid, NULL, 0);
  if (shmptr == (void *) -1)
    attach_err (shmkey, "shmat");

  if (shmsize)
    memset (shmptr, 0, shmsize);

  return shmptr;
}


#ifdef	HAVE_SEM


/* ----------------------------------------------------- */
/* semaphore : for critical section			 */
/* ----------------------------------------------------- */


static int ap_semid;


void
sem_init ()
{
  int semid;

  union semun
  {
    int val;
    struct semid_ds *buf;
    ushort *array;
  }
  arg =
  {
  1};

  semid = semget (BSEM_KEY, 1, 0);
  if (semid == -1)
    {
      semid = semget (BSEM_KEY, 1, IPC_CREAT | BSEM_FLG);
      if (semid == -1)
	attach_err (BSEM_KEY, "semget");
      semctl (semid, 0, SETVAL, arg);
    }
  ap_semid = semid;
}


void
sem_lock (op)
     int op;			/* op is BSEM_ENTER or BSEM_LEAVE */
{
  struct sembuf sops;

  sops.sem_num = 0;
  sops.sem_flg = SEM_UNDO;
  sops.sem_op = op;
  semop (ap_semid, &sops, 1);
}


#endif /* HAVE_SEM */


/*-------------------------------------------------------*/
/* .UTMP cache						 */
/*-------------------------------------------------------*/


UCACHE *ushm;


void
ushm_init ()
{
  UCACHE *xshm;

  ushm = xshm = attach_shm (UTMPSHM_KEY, sizeof (UCACHE));

#if 0
  if (xshm->mbase < xshm->mpool)
    xshm->mbase = xshm->mpool;
#endif
}


#ifndef	_BBTP_


void
utmp_mode (mode)
     int mode;
{
  if (bbsmode != mode)
    {

#ifdef MODE_STAT
      if (mode != M_XMODE && bbsmode != M_XMODE)
	{			/* XMODE ����������������, ������ͳ�� */
	  time_t now;

	  time (&now);
	  modelog.used_time[bbsmode] += (now - mode_lastchange);
	  mode_lastchange = now;
	}
#endif

      cutmp->mode = bbsmode = mode;

    }
}


int
utmp_new (up)
     UTMP *up;
{
  UCACHE *xshm;
  UTMP *uentp, *utail;

  /* --------------------------------------------------- */
  /* semaphore : critical section                        */
  /* --------------------------------------------------- */

#ifdef	HAVE_SEM
  sem_lock (BSEM_ENTER);
#endif

  xshm = ushm;
  uentp = xshm->uslot;
  utail = uentp + MAXACTIVE;

  /* uentp += (up->pid % xshm->count);  /* hashing */

  do
    {
      if (!uentp->pid)
	{
	  usint offset;

	  offset = (void *) uentp - (void *) xshm->uslot;
	  memcpy (uentp, up, sizeof (UTMP));
	  xshm->count++;
	  if (xshm->offset < offset)
	    xshm->offset = offset;
	  cutmp = uentp;

#ifdef	HAVE_SEM
	  sem_lock (BSEM_LEAVE);
#endif

	  return 1;
	}
    }
  while (++uentp < utail);

  /* Thor:����user���˵���һ���� */

#ifdef	HAVE_SEM
  sem_lock (BSEM_LEAVE);
#endif

  return 0;
}


void
utmp_free ()
{
  UTMP *uentp;

  uentp = cutmp;
  if (!uentp || !uentp->pid)
    return;

#ifdef	HAVE_SEM
  sem_lock (BSEM_ENTER);
#endif

  uentp->pid = uentp->userno = 0;
  ushm->count--;

#ifdef	HAVE_SEM
  sem_lock (BSEM_LEAVE);
#endif
}


UTMP *
utmp_find (userno)
     int userno;
{
  UTMP *uentp, *uceil;

  uentp = ushm->uslot;
  uceil = (void *) uentp + ushm->offset;
  do
    {
      if (uentp->userno == userno)
	return uentp;
    }
  while (++uentp <= uceil);

  return NULL;
}


#if 0
int
apply_ulist (fptr)
     int (*fptr) ();
{
  UTMP *uentp;
  int i, state;

  uentp = ushm->uslot;
  for (i = 0; i < USHM_SIZE; i++, uentp++)
    {
      if (uentp->pid)
	if (state = (*fptr) (uentp))
	  return state;
    }
  return 0;
}


UTMP *
utmp_search (userno, order)
     int userno;
     int order;			/* �ڼ��� */
{
  UTMP *uentp, *uceil;

  uentp = ushm->uslot;
  uceil = (void *) uentp + ushm->offset;
  do
    {
      if (uentp->userno == userno)
	{
	  if (--order <= 0)
	    return uentp;
	}
    }
  while (++uentp <= uceil);
  return NULL;
}
#endif


int
utmp_count (userno, show)
     int userno;
     int show;
{
  UTMP *uentp, *uceil;
  int count;

  count = 0;
  uentp = ushm->uslot;
  uceil = (void *) uentp + ushm->offset;
  do
    {
      if (uentp->userno == userno)
	{
	  count++;
	  if (show)
	    {
	      prints ("(%d) Ŀǰ״̬Ϊ: %-17.16s(���� %s)\n",
		      count, bmode (uentp, 0), uentp->from);
	    }
	}
    }
  while (++uentp <= uceil);
  return count;
}


/*-------------------------------------------------------*/
/* .BRD cache						 */
/*-------------------------------------------------------*/


BCACHE *bshm;


#if 0
void
bsync ()
{
  rec_put (FN_BRD, bshm->bcache, sizeof (BRD) * bshm->number, 0);
}
#endif


void
bshm_init ()
{
  BCACHE *xshm;
  time_t *uptime;
  int n, turn;

  turn = 0;
  xshm = bshm;
  if (xshm == NULL)
    {
      bshm = xshm = attach_shm (BRDSHM_KEY, sizeof (BCACHE));
    }

  uptime = &(xshm->uptime);

  for (;;)
    {
      n = *uptime;
      if (n > 0)
	return;

      if (n < 0)
	{
	  if (++turn < 30)
	    {
	      sleep (2);
	      continue;
	    }
	}

      *uptime = -1;

      if ((n = open (FN_BRD, O_RDONLY)) >= 0)
	{
	  xshm->number =
	    read (n, xshm->bcache, MAXBOARD * sizeof (BRD)) / sizeof (BRD);
	  close (n);
	}

      /* ������ boards ���ϸ��������趨 uptime */

      time (uptime);
      blog ("CACHE", "reload bcache");
      return;
    }
}


#if 0
int
apply_boards (func)
     int (*func) ();
{
  extern char brd_bits[];
  BRD *bhdr;
  int i;

  for (i = 0, bhdr = bshm->bcache; i < bshm->number; i++, bhdr++)
    {
      if (brd_bits[i])
	{
	  if ((*func) (bhdr) == -1)
	    return -1;
	}
    }
  return 0;
}
#endif


int
brd_bno (bname)
     char *bname;
{
  BRD *brdp, *bend;
  int bno;

  brdp = bshm->bcache;
  bend = brdp + bshm->number;
  bno = 0;

  do
    {
      if (!str_cmp (bname, brdp->brdname))
	return bno;

      bno++;
    }
  while (++brdp < bend);

  return -1;
}


#if 0
BRD *
getbrd (bname)
     char *bname;
{
  BRD *bhdr, *tail;

  bhdr = bshm->bcache;
  tail = bhdr + bshm->number;
  do
    {
      if (!str_cmp (bname, bhdr->brdname))
	return bhdr;
    }
  while (++bhdr < tail);
  return NULL;
}
#endif

/*-------------------------------------------------------*/
/* etc/movie cache					 */
/*-------------------------------------------------------*/


FCACHE *fshm;
void
fshm_init ()
{
  if (fshm == NULL)
    fshm = attach_shm (FILMSHM_KEY, sizeof (FCACHE));
}


static inline void
out_rle (str)
  uschar *str;
{
#ifdef SHOW_USER_IN_TEXT
  uschar *t_name = cuser.userid;
  uschar *t_nick = cuser.username;
#endif
  int cc, rl;

  while (cc = *str)
    {
      str++;
      switch (cc)
	{
	case 8:		/* Thor.980804: ע��һ��, opusѹ������ */
	  rl = *str++;
	  cc = *str++;

	  while (--rl >= 0)
	    outc (cc);
	  continue;

#ifdef SHOW_USER_IN_TEXT
	case 1:
	  if (cc = *t_name)
	    t_name++;
	  else
	    cc = ' ';
	  break;

	case 2:
	  if (cc = *t_nick)
	    t_nick++;
	  else
	    cc = ' ';
#endif
	}

      outc (cc);
    }
}


int
film_out (tag, row)
     int tag;
     int row;			/* -1 : help */
{
  int fmax, len, *shot;
  char *film, buf[FILM_SIZ];

  if (row <= 0)
    clear ();
  else
    move (row, 0);

  len = 0;
  shot = fshm->shot;
  film = fshm->film;

  while (!(fmax = *shot))	/* util/camera.c ���ڻ�Ƭ */
    {
      sleep (5);
      if (++len > 10)
	return FILM_MOVIE;
    }

  if (tag >= FILM_MOVIE)	/* random select */
    {
      tag += (time (0) & 7);	/* 7 steps forward */
      if (tag >= fmax)
	tag = FILM_MOVIE;
    }				/* Thor.980804: �����ǹ���İ�? ��һ�� random selectǰ�˸�����һ�� */

  if (tag)
    {
      len = shot[tag];
      film += len;
      len = shot[++tag] - len;
    }
  else
    {
      len = shot[1];
    }

  if (len >= FILM_SIZ - 10)
    return tag;

  memcpy (buf, film, len);
  buf[len] = '\0';
  out_rle (buf);

  if (row < 0)			/* help screen */
    vmsg (NULL);

  return tag;
}

#endif /* _BBTP_ */
