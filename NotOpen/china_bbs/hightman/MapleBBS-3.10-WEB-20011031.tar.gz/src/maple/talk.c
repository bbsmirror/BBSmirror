/*-------------------------------------------------------*/
/* talk.c	( NTHU CS MapleBBS Ver 3.00 )		 */
/*-------------------------------------------------------*/
/* target : talk/query/friend(pal) routines	 	 */
/* create : 95/03/29				 	 */
/* update : 97/03/29				 	 */
/*-------------------------------------------------------*/


#define	_MODES_C_
#define	PAL_MAX		200	/* ������������ */


#include "bbs.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#ifdef REDHAT
#undef LINUX
#endif
/* Thor.981221: RedHat�����ڴ� #undef LINUX */
static int ulist_neck(XO *xo);

#ifdef  HAVE_CHICKEN
static int (*p)();
#endif

static int pal_count;
static int *pal_pool;


extern UCACHE *ushm;
extern XZ xz[];


#ifdef EVERY_Z
extern int vio_fd;		/* Thor.0725: Ϊtalk,chat����^z��׼�� */
extern int holdon_fd;
#endif


typedef struct
{
  int curcol, curln;
  int sline, eline;
}      talk_win;


typedef UTMP *pickup;


void my_query();


/* ----------------------------------------------------- */
/* ��¼ pal �� user number				 */
/* ----------------------------------------------------- */

#define PICKUP_WAYS	4

static int pickup_way;

static char page_requestor[40];

#ifdef SHOW_BMW_NUM
const int bmwmax = 10;  /* hightman.010324: ��X��ִѶ */
#endif

char *
bmode(up, simple)
  UTMP *up;
  int simple;
{
  static char modestr[32];

#ifdef SHOW_BMW_NUM  
  static char cnum[9][3] = {"һ","��","��","��","��","��","��","��","��"};
  int bmwnum; /* hightman.010324: ��X����Ѷ */
#endif  

  int mode;
  char *word;

#ifdef SHOW_BMW_NUM  
  /* hightman.010324: patch for ��X��ִѶ */
  word = ModeTypeTable[(mode = up->mode) & ~M_BMW_NUMMASK];
#else  
  word = ModeTypeTable[mode = up->mode];
#endif  

  if (simple)
    return (word);
#ifdef SHOW_BMW_NUM    
  /* hightman.010324: ��X����Ѷ */
    if(bmwnum = mode & M_BMW_NUMMASK)
  {
    bmwnum /= M_BMW_SHIFTER ;
    if(bmwnum < 10)
      sprintf(modestr,"��%s������",cnum[bmwnum-1]);
    else if(bmwnum < bmwmax)
      sprintf(modestr,"��%d������",bmwnum);
    else
      sprintf(modestr,"���ս��� @_@");

    return (modestr);
  }
#endif
  if (mode < M_TALK || mode > M_CHESS)
    return (word);  /* hightman.001206: ���ýӶ��� */

  if (mode != M_QUERY && !HAS_PERM(PERM_SEECLOAK) && (up->ufo & UFO_CLOAK))
    return (word); /* Thor.980805: ע��: �������˲��ᱻ֪����˭talk */

  sprintf(modestr, "%s [%s]", word, up->mateid);
  return (modestr);
}

/* ----------------------------------------------------- */
/* ������������ѯ״̬����������				 */
/* ----------------------------------------------------- */

/* Thor: ����ֵ -> 0 for good, 1 for normal, 2 for bad */


/* hightman.010707:
 * for message
 */
#define	PAGER	(0)
#define	MSG	(1)

static int
/* hightman.010707: 
 * ����message���жϣ���mode���жϡ�0: pager 1: message
 * ��������дcan_override2(up)
 * can_override(up)
 *   UTMP *up;  
 */
 can_override(up, mode)
   UTMP *up;
   int mode;
{
  int self, ufo, can, fd;
  char fpath[64];
  PAL *pal;

  if (up->userno == (self = cuser.userno))
    return NA;

  if (HAS_PERM(PERM_SYSOP | PERM_ACCOUNTS))	/* վ�����ʺŹ���Ա */
    return YEA;

  ufo = up->ufo;

  if (ufo & UFO_QUIET)		/* Զ�볾�� */
    return NA;

 /* hightman.010707:
  * ��д��֧��message
  * if (!(ufo & (UFO_PAGER | UFO_REJECT)))
  */
  if(!(ufo & ((mode == MSG ? UFO_MESSAGE : UFO_PAGER) | UFO_REJECT))) 
    return YEA;			/* ������/ѶϢ��û�ص����������� */
 /* hightman.010707:
  * ��дһ֧��message
  * if ((ufo & UFO_PAGER) && !(ufo & UFO_FCACHE))
  */
  if ((ufo & (mode == MSG ? UFO_MESSAGE : UFO_PAGER)) && !(ufo & UFO_FCACHE))
    return NA;

  can = 1;			/* �Ҳ���Ϊ normal */

  usr_fpath(fpath, up->userid, FN_PAL);
  if ((fd = open(fpath, O_RDONLY)) >= 0)
  {
    mgets(-1);
    while (pal = mread(fd, sizeof(PAL)))
    {
      if (self == pal->userno)
      {
	can = pal->ftype;
	break;
      }
    }
    close(fd);
  }

  return (ufo & (mode==MSG ? UFO_MESSAGE : UFO_PAGER)) 
                                /* hightman.010707: UFO_PAGER)*/
    ? can == 0			/* ֻ�к��ѿ��� */
    : can < 2 /* ֻҪ�������� */ ;
}

static int
is_friend(up)
  UTMP *up;
{
  int self, found, fd;
  char fpath[64];
  PAL *pal;

  found = 1;
  /* 1 : ����  0 : ����  2 : ���� */

  usr_fpath(fpath, up->userid, FN_PAL);
  if ((fd = open(fpath, O_RDONLY)) >= 0)
  {
    self = cuser.userno;

    mgets(-1);
    while (pal = mread(fd, sizeof(PAL)))
    {
      if (self == pal->userno)
      {
        found = pal->ftype;
        break;
      }
    }
    close(fd);
  }

  return found;
}

/* ----------------------------------------------------- */
/* ����������������ɾ�����޸ġ����롢ͬ��		 */
/* ----------------------------------------------------- */


int
is_pal(userno)
  int userno;
{
  int count, *cache, datum, mid;

  if (cache = pal_pool)
  {
    for (count = pal_count; count > 0;)
    {
      datum = cache[mid = count >> 1];
      if (userno == datum)
	return 1;
      if (userno > datum)
      {
	cache += (++mid);
	count -= mid;
      }
      else
      {
	count = mid;
      }
    }
  }
  return 0;
}


static int
int_cmp(a, b)
  int *a;
  int *b;
{
  return *a - *b;
}


void
pal_cache()
{
  int count, fsize, ufo;
  int *plist, *cache;
  PAL *phead, *ptail;
  char *fimage, fpath[64];

  if (cache = pal_pool)
    free(cache);

  cache = NULL;
  count = 0;
  ufo = cuser.ufo & ~(/* UFO_BIFF |*/ UFO_REJECT | UFO_FCACHE);
  /* Thor.980805: �� BIFF����û��̫���ϵ */

  usr_fpath(fpath, cuser.userid, FN_PAL);
  fimage = f_img(fpath, &fsize);
  if (fimage != NULL)
  {
    if (fsize > PAL_MAX * sizeof(PAL))
    {
      sprintf(fpath, "%-13s%d\n", cuser.userid, fsize);
      f_cat("run/pal", fpath);
      fsize = PAL_MAX * sizeof(PAL);
    }

    count = fsize / sizeof(PAL);
    if (count)
    {
      cache = plist = (int *) malloc(count * sizeof(int));
      phead = (PAL *) fimage;
      ptail = (PAL *) (fimage + fsize);
      do
      {
	if (phead->ftype & PAL_BAD)
	{
	  ufo |= UFO_REJECT;
	  count--;
	}
	else
	{
	  *plist++ = phead->userno;
	}
      } while (++phead < ptail);

      if (count > 0)
      {
	ufo |= UFO_FCACHE;
	if (count > 1)
	  xsort(cache, count, sizeof(int), int_cmp);
      }
      else
      {
	free(cache);
	cache = NULL;
      }
    }
    free(fimage);
  }

  pal_pool = cache;
  pal_count = count;
  /* cuser.ufo = ufo; */
  if (cutmp)
  {
    ufo = (ufo & ~UFO_UTMP_MASK) | (cutmp->ufo & UFO_UTMP_MASK);
    /* Thor.980805: ��� cutmp.ufo�� cuser.ufo��ͬ������ */
    cutmp->ufo = ufo;
  }
  cuser.ufo = ufo;
}


void
pal_sync(fpath)
  char *fpath;
{
  int fd, size;
  struct stat st;
  char buf[64];

  if (!fpath)
  {
    fpath = buf;
    usr_fpath(fpath, cuser.userid, FN_PAL);
  }

  if ((fd = open(fpath, O_RDWR, 0600)) < 0)
    return;

  outz("�� �������������У����Ժ� \033[5m...\033[m");
  refresh();

  if (!fstat(fd, &st) && (size = st.st_size) > 0)
  {
    PAL *pbase, *phead, *ptail;
    int userno;

    pbase = phead = (PAL *) malloc(size);
    size = read(fd, pbase, size);
    if (size >= sizeof(PAL))
    {
      ptail = (PAL *) ((char *) pbase + size);
      while (phead < ptail)
      {
	userno = phead->userno;
	if (userno > 0 && userno == acct_userno(phead->userid))
	{
	  phead++;
	  continue;
	}

	ptail--;
	if (phead >= ptail)
	  break;
	memcpy(phead, ptail, sizeof(PAL));
      }

      size = (char *) ptail - (char *) pbase;
      if (size > 0)
      {
	if (size > sizeof(PAL))
	{
	  if (size > 128 * sizeof(PAL))
	    vmsg("���ĺ�������̫�࣬���Ƽ�����");
	  xsort(pbase, size / sizeof(PAL), sizeof(PAL), str_cmp);
	}

	/* Thor.0709: �Ƿ�Ҫ���������ظ��ĺ��ѵĶ���? */

	lseek(fd, 0, SEEK_SET);
	write(fd, pbase, size);
	ftruncate(fd, size);
      }
    }
    free(pbase);
  }
  close(fd);

  if (size <= 0)
    unlink(fpath);
}


/* ----------------------------------------------------- */
/* ����������ѡ��ʽ������������				 */
/* ----------------------------------------------------- */


static int pal_add();


static void
pal_item(num, pal)
  int num;
  PAL *pal;
{
  prints("%6d %-3s%-14s%s\n", num, pal->ftype & PAL_BAD ? "��" : "",
    pal->userid, pal->ship);
}


static int
pal_body(xo)
  XO *xo;
{
  PAL *pal;
  int num, max, tail;

  move(3, 0);
  clrtobot();
  max = xo->max;
  if (max <= 0)
  {
    if (vans("Ҫ����������(Y/N)��[N] ") == 'y')
      return pal_add(xo);
    return XO_QUIT;
  }

  pal = (PAL *) xo_pool;
  num = xo->top;
  tail = num + XO_TALL;
  if (max > tail)
    max = tail;

  do
  {
    pal_item(++num, pal++);
  } while (num < max);

  update_foot(); 


  return XO_NONE;
}


static int
pal_head(xo)
  XO *xo;
{
  vs_head("��������", str_site);
  outs("\
  [��]�뿪 a)���� c)�޸� d)ɾ�� m)���� s)���� w)��·���� [��]��ѯ [h]elp\n\
\033[44m  ���    �� ��         ��       ��                                           \033[m");
  return pal_body(xo);
}


static int
pal_load(xo)
  XO *xo;
{
  xo_load(xo, sizeof(PAL));
  return pal_body(xo);
}


static int
pal_init(xo)
  XO *xo;
{
  xo_load(xo, sizeof(PAL));
  return pal_head(xo);
}


static void
pal_edit(pal, echo)
  PAL *pal;
  int echo;
{
  if (echo == DOECHO)
    memset(pal, 0, sizeof(PAL));
  vget(b_lines, 0, "���꣺", pal->ship, sizeof(pal->ship), echo);
  pal->ftype = vans("����(Y/N)��[N] ") == 'y' ? PAL_BAD : 0;
}


static int
pal_add(xo)
  XO *xo;
{
  ACCT acct;
  int userno;

  if (xo->max >= PAL_MAX)
  {
    vmsg("���ĺ�������̫�࣬���Ƽ�����");
    return XO_FOOT;
  }

  userno = acct_get(msg_uid, &acct);

  /* jhlin : for board_moderator, temporarily */

#if 1				/* Thor.0709: ���ظ����� */
  /* if (is_pal(userno)) */
  if ((xo->dir[0] == 'u') && is_pal(userno))
              /* lkchu.981201: ֻ���� moderator board �ſ��ظ����� */
  {
    vmsg("���������д˺���");
    return XO_FOOT;
  }
  else if (userno == cuser.userno)
  {
    vmsg("�Լ�����������������");
    return XO_FOOT;
  }
#endif

  if ((userno > 0) /* && !pal_state(cutmp, userno, NULL) */ )
  {
    PAL pal;

    pal_edit(&pal, DOECHO);
    strcpy(pal.userid, acct.userid);
    pal.userno = userno;
    rec_add(xo->dir, &pal, sizeof(PAL));
#ifdef	HAVE_ALOHA
    if ((xo->dir[0] == 'u') && (pal.userno != cuser.userno) && !(pal.ftype & PAL_BAD))
    {
      char fpath[64];
      BMW bmw;

      /* bmw.caller = cutmp; */		/* lkchu.981201: frienz �� utmp ��Ч */
      bmw.recver = cuser.userno;
      strcpy(bmw.userid, cuser.userid);
      usr_fpath(fpath, pal.userid, FN_FRIEND_BENZ);
      rec_add(fpath, &bmw, sizeof(BMW));
    }
#endif
    xo->pos = XO_TAIL /* xo->max */ ;
    xo_load(xo, sizeof(PAL));
  }

#if 1				/* Thor.0709: ��������ͬ�� */
  pal_cache();
#endif

  return pal_head(xo);
}


#ifdef HAVE_ALOHA
int
cmpbmw(benz)
  BMW *benz;
{
    return benz->recver == cuser.userno;
}
#endif


static int
pal_delete(xo)
  XO *xo;
{
  if (vans(msg_del_ny) == 'y')
  {
#ifdef HAVE_ALOHA
    if (xo->dir[0] == 'u')
    {
      PAL *pal;

      pal = (PAL *) xo_pool + (xo->pos - xo->top);
      if (!(pal->ftype & PAL_BAD))
      {
        char fpath[64];

        usr_fpath(fpath, pal->userid, FN_FRIEND_BENZ);
        rec_del(fpath, sizeof(BMW), 0, cmpbmw, NULL);
      }
    }
#endif

    if (!rec_del(xo->dir, sizeof(PAL), xo->pos, NULL, NULL))
    {

#if 1				/* Thor.0709: ��������ͬ�� */
      pal_cache();
#endif

      return pal_load(xo);
    }
  }
  return XO_FOOT;
}


static int
pal_change(xo)
  XO *xo;
{
  PAL *pal, mate;
  int pos, cur;
#ifdef HAVE_ALOHA
  char old_ftype, fpath[64];
#endif
  
  pos = xo->pos;
  cur = pos - xo->top;
  pal = (PAL *) xo_pool + cur;

#ifdef HAVE_ALOHA
  old_ftype = pal->ftype;
  usr_fpath(fpath, pal->userid, FN_FRIEND_BENZ);
#endif
    
  mate = *pal;
  pal_edit(pal, GCARRY);
  if (memcmp(pal, &mate, sizeof(PAL)))
  {
    rec_put(xo->dir, pal, sizeof(PAL), pos);
    move(3 + cur, 0);
    pal_item(++pos, pal);
  }

#ifdef HAVE_ALOHA
  if (xo->dir[0] == 'b')	/* lkchu.981201: moderator board */
    return XO_FOOT;
  
  if ( !(old_ftype & PAL_BAD) && (pal->ftype & PAL_BAD) )
      /* lkchu.981201: ԭ���Ǻ���, �ĳ�����Ҫ rec_del */
  {
    rec_del(fpath, sizeof(BMW), 0, cmpbmw, NULL);
  }
  else if ( (old_ftype & PAL_BAD) && !(pal->ftype & PAL_BAD) )
      /* lkchu.981201: ԭ��������, �ĳɺ���Ҫ rec_add */
  {
    BMW bmw;

    /* bmw.caller = cutmp; */	/* lkchu.981201: frienz �� utmp ��Ч */
    bmw.recver = cuser.userno;
    strcpy(bmw.userid, cuser.userid);
    rec_add(fpath, &bmw, sizeof(BMW));
  }  
#endif

  return XO_FOOT;
}


static int
pal_mail(xo)
  XO *xo;
{
  PAL *pal;
  char *userid;

  pal = (PAL *) xo_pool + (xo->pos - xo->top);
  userid = pal->userid;
  if (*userid)
  {
    vs_bar("��  ��");
    prints("�����ˣ�%s", userid);
    my_send(userid);
  }
  return pal_head(xo);
}


static int
pal_sort(xo)
  XO *xo;
{
  pal_sync(xo->dir);
  return pal_load(xo);
}


static int
pal_query(xo)
  XO *xo;
{
  PAL *pal;

  pal = (PAL *) xo_pool + (xo->pos - xo->top);
  move(1, 0);
  clrtobot();
  /* move(2, 0); *//* Thor.0810: ���Բ�����? */
  /* if(*pal->userid) *//* Thor.0806:ż������һ��, Ӧ��û�� */
  my_query(pal->userid, 1);
  return pal_head(xo);
}


static int
pal_help(xo)
  XO *xo;
{
  film_out(FILM_PAL, -1);
  return pal_head(xo);
}


KeyFunc pal_cb[] =
{
  XO_INIT, pal_init,
  XO_LOAD, pal_load,
  XO_HEAD, pal_head,
  XO_BODY, pal_body,

  'a', pal_add,
  'c', pal_change,
  'd', pal_delete,
  'm', pal_mail,
  'r', pal_query,
  Ctrl('Q'), pal_query,
  's', pal_sort,
#if 1
  'w' | XO_DL, "bin/bbcall.so:pal_bbc",
#endif

  'h', pal_help
};


int
t_pal()
{
  XO *xo;
  char fpath[64];

  usr_fpath(fpath, cuser.userid, FN_PAL);
  xz[XZ_PAL - XO_ZONE].xo = xo = xo_new(fpath);
  xover(XZ_PAL);
  pal_cache();
  free(xo);

  return 0;
}


#if 0
int
t_pal()
{
  XO *xo;

  xo = pal_xo;
  if (xo == NULL)
  {
    char fpath[64];

    usr_fpath(fpath, cuser.userid, FN_PAL);
    pal_xo = xo = xo_new(fpath);
  }
  xover(XZ_PAL);
  pal_cache();
  return 0;
}
#endif


/* ----------------------------------------------------- */
/* ѶϢ�б�: ѡ��ʽ������������ by lkchu                 */
/* ----------------------------------------------------- */

#ifndef HAVE_GROUP_FUNC
static void bmw_edit(); /* hightman.010720: ��group�����ˣ������������� */
#else
void bmw_edit();
#endif

static void
bmw_item(num, bmw)
  int num;
  BMW *bmw;
{
  struct tm *ptime = localtime(&bmw->btime);

  if (bmw->sender == cuser.userno)
  {
    /* lkchu.990206: ���ѹ㲦 */
    if (*bmw->userid == (char) NULL)
      strcpy(bmw->userid, "�ڼҺ���");
      
    prints("%5d %02d:%02d �͸� %-13s%s\n", num, ptime->tm_hour, ptime->tm_min,
      bmw->userid, bmw->msg);
  }
  else
  {
    /* lkchu.990206: ���ѹ㲦 */
#if 0
    if(*bmw->userid == (char) NULL)
    {
      UTMP *up = utmp_find(bmw->sender);
      strcpy(bmw->userid, up->userid);
    }
#endif

    prints("%5d \033[32m%02d:%02d �յ� %-13s%s\033[m\n", num, ptime->tm_hour, ptime->tm_min,
      bmw->userid, bmw->msg);
  }
}


static int
bmw_body(xo)
  XO *xo;
{
  BMW *bmw;
  int num, max, tail;

  move(3, 0);
  clrtobot();
  max = xo->max;
  if (max <= 0)
  {
    vmsg("��ǰ����ѶϢ����");
    return XO_QUIT;
  }

  bmw = (BMW *) xo_pool;
  num = xo->top;
  tail = num + XO_TALL;
  if (max > tail)
    max = tail;

  do
  {
    bmw_item(++num, bmw++);
  } while (num < max);

  update_foot();

  return XO_NONE;
}


static int
bmw_head(xo)
  XO *xo;
{
  vs_head("�쿴ѶϢ", str_site);
  outs("\
  [��]�뿪  [d]ɾ��  [m]����  [w]��Ѷ  [s]����  [��]��ѯ  [h]elp\n\
\033[44m ��� ʱ �� ��� �� ��        ��       ��                                     \033[m");
  return bmw_body(xo);
}


static int
bmw_load(xo)
  XO *xo;
{
  xo_load(xo, sizeof(BMW));
  return bmw_body(xo);
}


static int
bmw_init(xo)
  XO *xo;
{
  xo_load(xo, sizeof(BMW));
  return bmw_head(xo);
}


static int
bmw_delete(xo)
  XO *xo;
{
  if (vans(msg_del_ny) == 'y')
    if (!rec_del(xo->dir, sizeof(BMW), xo->pos, NULL, NULL))
      return bmw_load(xo);

  return XO_FOOT;
}


static int
bmw_mail(xo)
  XO *xo;
{
  BMW *bmw;
  char *userid;

  bmw = (BMW *) xo_pool + (xo->pos - xo->top);
  userid = bmw->userid;
  if (*userid)
  {
    vs_bar("��  ��");
    prints("�����ˣ�%s", userid);
    my_send(userid);
  }
  return bmw_head(xo);
}


static int
bmw_query(xo)
  XO *xo;
{
  BMW *bmw;

  bmw = (BMW *) xo_pool + (xo->pos - xo->top);
  move(1, 0);
  clrtobot();
  /* move(2, 0); *//* Thor.0810: ���Բ�����? */
  /* if(*pal->userid) *//* Thor.0806:ż������һ��, Ӧ��û�� */
  my_query(bmw->userid, 1);
  return bmw_head(xo);
}


static int
bmw_write(xo)
  XO *xo;
{
  if (HAS_PERM(PERM_PAGE))
  {
    UTMP *up;
    BMW *benz;

    benz = (BMW *) xo_pool + (xo->pos - xo->top);
    if ((up = utmp_find(benz->sender)) && can_override(up, MSG))
        /* lkchu.990104: ����ǰ�� bmw Ҳ���Ի� */
    {
#ifndef HAVE_SUPER_CLOAK	/* hightman.010723: �������� */
      if ((up->ufo & UFO_CLOAK) && !HAS_PERM(PERM_SEECLOAK))
      {
        return XO_NONE;		/* lkchu.990111: ������ */
      }
#else
      if (((up->ufo & UFO_CLOAK) && !HAS_PERM(PERM_SEECLOAK)) ||
             ((up->ufo & UFO_SUPERCLOAK) && !HAS_PERM(PERM_SYSOP)))
      {
        return XO_NONE;
      }
#endif
      else if(up -> ufo & UFO_EXEC)   /* hightman.001114: ��� */
       {
         vmsg("����ԭ��,�޷�����,����վ���㲥!");
         return XO_NONE;
       }
      else
      {
        BMW bmw;
        char buf[20];
        sprintf(buf, "��[%s]", up->userid);
        bmw_edit(up, buf, &bmw, 0);
      }
    }
  }
  return XO_NONE;
}


static int
bmw_help(xo)
  XO *xo;
{
  film_out(FILM_BMW, -1);
  return bmw_head(xo);
}


KeyFunc bmw_cb[] =
{
  XO_INIT, bmw_init,
  XO_LOAD, bmw_load,
  XO_HEAD, bmw_head,
  XO_BODY, bmw_body,
  
  'd', bmw_delete,
  'm', bmw_mail,
  'w', bmw_write,
  'r', bmw_query,
  Ctrl('Q'), bmw_query,
  's', bmw_init,
  
  'h', bmw_help
};


int
t_bmw()
{
  xover(XZ_BMW);
  return 0;
}


#ifdef HAVE_MODERATED_BOARD
/* ----------------------------------------------------- */
/* ����������moderated board				 */
/* ----------------------------------------------------- */


#define FN_FIMAGE	"fimage"


static void
bm_image()
{
  int fd;
  char fpath[80];

  brd_fpath(fpath, currboard, FN_PAL);
  if ((fd = open(fpath, O_RDONLY)) >= 0)
  {
    struct stat st;
    PAL *pal, *up;
    int count;

    fstat(fd, &st);
    if (pal = (PAL *) malloc(count = st.st_size))
    {
      count = read(fd, pal, count) / sizeof(PAL);
      if (count > 0)
      {
	int *userno;
	int c = count;

	userno = (int *) up = pal;
	do
	{
	  *userno++ = up->userno;
	  up++;
	} while (--c);

	if (count > 1)		/* Thor: �������������彡��... */
	  xsort(pal, count, sizeof(int), int_cmp);

	brd_fpath(fpath, currboard, FN_FIMAGE);
	if ((count = open(fpath, O_WRONLY | O_CREAT | O_TRUNC, 0600)) >= 0)
	{
	  write(count, pal, (char *) userno - (char *) pal);
	  close(count);
	}
      }
      else  /* Thor.980811: lkchu patch: �� friend ͬ�� */
      {
	brd_fpath(fpath, currboard, FN_FIMAGE);
        unlink(fpath);
      }
      free(pal);
    }
    close(fd);
  }
}


int
bm_belong(board)
  char *board;
{
  int fsize, count, result;
  char fpath[80];

  result = 0;

  brd_fpath(fpath, board, FN_FIMAGE);	/* Thor: fimageҪ�� sort��! */
  board = f_img(fpath, &fsize);

  if (board != NULL)
  {
    count = fsize / sizeof(int);
    if (count > 0)
    {
      int userno, *up;
      int datum, mid;

      userno = cuser.userno;
      up = (int *) board;

      while (count > 0)
      {
	datum = up[mid = count >> 1];
	if (userno == datum)
	{
	  result = BRD_R_BIT | BRD_W_BIT;
	  break;
	}
	if (userno > datum)
	{
	  up += (++mid);
	  count -= mid;
	}
	else
	{
	  count = mid;
	}
      }
    }
    free(board);
  }
  return result;
}


int
XoBM(xo)
  XO *xo;
{
  if ((bbstate & STAT_BOARD) && (bbstate & STAT_MODERATED))
    /* && (cbhdr.readlevel == PERM_SYSOP)) */
    /*
     * Thor.1020: bbstate�� STAT_MODERATED�ʹ�������MODERATED BOARD,
     * ������check readlevel PERM_SYSOP
     */
  {
    XO *xt;
    char fpath[80];

    brd_fpath(fpath, currboard, FN_PAL);
    xz[XZ_PAL - XO_ZONE].xo = xt = xo_new(fpath);
    xover(XZ_PAL);		/* Thor: ��xoverǰ, pal_xo һ��Ҫ ready */

    /* build userno image to speed up, maybe upgreade to shm */

    bm_image();

    free(xt);

    return XO_INIT /* or post_init(xo) */ ;
  }
  return XO_NONE;
}
#endif


/* ------------------------------------- */
/* ��ʵ����				 */
/* ------------------------------------- */


static void
showplans(userid)
  char *userid;
{
  int i;
  FILE *fp;
  char buf[256];

  usr_fpath(buf, userid, fn_plans);
  if (fp = fopen(buf, "r"))
  {
    outs("  [��Ƭ]��\n");
    i = MAXQUERYLINES;
    while (i-- && fgets(buf, sizeof(buf), fp))
    {
      outx(buf);
    }
    fclose(fp);
  }
}

char *
cexp(exp)
int exp;
{
        int expbase=0;

        if(exp==-9999)
                return "û�ȼ�";
        if(exp<=100+expbase)
                return "������·";
        if(exp>100+expbase&&exp<=450+expbase)
                return "һ��վ��";
        if(exp>450+expbase&&exp<=850+expbase)
                return "�м�վ��";
        if(exp>850+expbase&&exp<=1500+expbase)
                return "�߼�վ��";
        if(exp>1500+expbase&&exp<=2500+expbase)
                return "��վ��";
        if(exp>2500+expbase&&exp<=3000+expbase)
                return "���ϼ�";
        if(exp>3000+expbase&&exp<=5000+expbase)
                return "��վԪ��";
        if(exp>5000+expbase)
                return "��������";

}

char *
cperf(perf)
int perf;
{

        if(perf==-9999)
                return "û�ȼ�";
        if(perf<=5)
                return "�Ͽ����";
        if(perf>5&&perf<=12)
                return "Ŭ����";
        if(perf>12&&perf<=35)
                return "������";
        if(perf>35&&perf<=50)
                return "�ܺ�";
        if(perf>50&&perf<=90)
                return "�ŵ���";
        if(perf>90&&perf<=140)
                return "̫������";
        if(perf>140&&perf<=200)
                return "��վ֧��";
        if(perf>200)
                return "�񡫡�";

}

int
countexp(udata)
  ACCT *udata;
{
   int exp;

   if(!strcmp(udata->userid,"guest"))
        return -9999;
   exp=udata->numposts+udata->numlogins/5+(time
(0)-udata->firstlogin)/86400+udata->staytime/3600;
   return exp>0?exp:0;
}

int
countperf(udata)
  ACCT *udata;
{
   int perf;
   int reg_days;

   if(!strcmp(udata->userid,"guest"))
        return -9999;
   reg_days=(time(0)-udata->firstlogin)/86400+1;
   perf=((float)(udata->numposts)/(float)udata->numlogins+
        (float)udata->numlogins/(float)reg_days)*10;
   return perf>0?perf:0;
}

int
compute_user_value( urec )
  ACCT *urec;
{
    float value;

    /* if (urec) has XEMPT permission, don't kick it */
    if((urec->userlevel & PERM_XEMPT)||strcmp(urec->userid,"guest")==0)
        return 999;
    value = (time(0) - urec->lastlogin) / 60.0;    /* min */
        /* new user should register in 30 mins */
    if( strcmp( urec->userid, "new" ) == 0 ) {
        return (30 - value) * 60;
    }
    if( urec->numlogins <= 3 )
        return (15 * 1440.0 - value)/1440.0;
    if( !(urec->userlevel & PERM_VALID) )
        return (30 * 1440.0 - value)/1440.0;
    return (120 * 1440.0 - value)/1440.0;
}


static void
do_query(acct, paling)
  ACCT *acct;
  int paling;			/* �Ƿ������趨�������� */
{
  UTMP *up;
  int userno;
  char *userid;
  int exp, perf;
  exp = perf =0;

  utmp_mode(M_QUERY);
  userno = acct->userno;
  userid = acct->userid;
  strcpy(cutmp->mateid, userid);

  exp = countexp(acct);
  perf = countperf(acct);

  up = utmp_find(userno);

#ifdef HAVE_COUNT_MARK
  prints("\033[1;33m%s\033[m(\033[1;33m%s\033[m) ��վ \033[1;32m%d\033[m �Σ����� \033[1;31m%d\033[m/\033[1;32m%d\033[m ƪ��%sͨ��������֤\n",
    userid, acct->username, acct->numlogins, acct->nummark, acct->numposts,
    acct->userlevel & PERM_VALID ? "�Ѿ�" : "��δ");
#else    
  prints("\033[1;33m%s\033[m(\033[1;33m%s\033[m) ��վ \033[1;32m%d\033[m �Σ����� \033[1;32m%d\033[m ƪ��%sͨ��������֤\n",
    userid, acct->username, acct->numlogins, acct->numposts,
    acct->userlevel & PERM_VALID ? "�Ѿ�" : "��δ");
#endif    

  prints("�ϴ��� \033[1;36m%s\033[m �� \033[1;36m%s\033[m ����վһ��", Ctime(&acct->lastlogin), acct->lasthost);

#ifdef HAVE_MONEY_ISM
  prints("\n���飺[\033[1;32m%d\033[m](%s) ���֣�[\033[1;32m%d\033[m](%s) ������[\033[1;32m%d\033[m] ��Ǯ��[\033[1;32m%d\033[m]", exp,
        cexp(exp), perf, cperf(perf), compute_user_value(acct),acct->money);
#else
  prints("\n���飺[\033[1;32m%d\033[m](%s) ���֣�[\033[1;32m%d\033[m](%s) ������[\033[1;32m%d\033[m]", exp,
        cexp(exp), perf, cperf(perf), compute_user_value(acct));
#endif        

#if defined(REALINFO) && defined(QUERY_REALNAMES)
  if (HAS_PERM(PERM_BASIC))
    prints("��ʵ����: %s\n", acct->realname);
#endif

  /* �����ϴ� login �ѹ� 6 Сʱ���㲻��վ�ϣ����� utmp_find */

  outs("\n��̬��");
  /*  up = (acct->lastlogin < time(0) - 6 * 3600) ? NULL : utmp_find(userno);*/
  /*  up = utmp_find(userno); */
  /* outs(up ? bmode(up, 1) : "����վ��"); */
#ifndef HAVE_SUPER_CLOAK	/* hightman.010722: վ���г������� */
  outs(up && (HAS_PERM(PERM_SEECLOAK) || !(up->ufo & UFO_CLOAK))? bmode(up, 1) : "����վ��");
  /* Thor.981108: Ϊ���� cigar ����������Ҫ��, ������ finger���ǿ��Կ���:p */
#else
  outs(up && (HAS_PERM(PERM_SEECLOAK) || !(up->ufo & UFO_CLOAK)) &&
          (HAS_PERM(PERM_SYSOP) || !(up->ufo & UFO_SUPERCLOAK)) ? bmode(up, 1) : "����վ��");
  /* hightman.010722: ���ӳ����������� */
#endif

#if 0
  /* Query ʱ��ͬʱ����������������� */

  if ((!paling) && (state = pal_state(cutmp, userno, ship)))
  {
    prints(" [%s��] %s", state > 0 ? "��" : "��", ship);
  }
#endif

  prints(" ���䣺 %s", m_query(userid) ? "�����ż�" : "��������");

 if(paling >= 0)
 {
  /* hightman.010719: Ϊ����ʱ��Ⱥ�鹦���õģ�����vmsg(NULL)... */
  showplans(userid);
  vmsg(NULL);

  move(b_lines, 0);
  clrtoeol();
 }

}


void
my_query(userid, paling)
  char *userid;
  int paling;			/* �Ƿ������趨�������� */
{
  ACCT acct;

  if (acct_load(&acct, userid) >= 0)
  {
    do_query(&acct, paling);
  }
  else
  {
    vmsg(err_uid);
  }
}

/* hightman.010720: ������������ר��ΪȺ�鹦����Ƶ� ;p */
char *
grp_user_item(up)  /* һЩ״̬ */
  UTMP *up;
{
  char buf[3];
  static char str[64];
  int diff, diff2;

  if ( (diff = up->idle_time) > 0 )
   sprintf(buf, "%2d\0", diff);
  else
   buf[0] = '\0';

  diff2 = diff = ' ';

  if(up->ufo & UFO_EXEC) diff2 = diff = '@';
  else if(up->ufo & UFO_QUIET) diff2 = diff = '-';
  else
     {
       if(up->ufo & UFO_PAGER)  diff = (is_friend(up) == 0) ? 'o' : '*'; 
       if(up->ufo & UFO_MESSAGE) diff2 = (is_friend(up) ==0) ? 'o' : '*';
    }
#ifndef HAVE_SUPER_CLOAK /* hightman.010722: վ���г������� */
  sprintf(str, "%c %c %s%-14.14s\033[m%s", 
      diff,diff2,(up->ufo & UFO_CLOAK ? "\033[1;36m" : ""),bmode(up, 0),buf); 
#else
  sprintf(str, "%c %c %s%-14.14s\033[m%s",
      diff,diff2,(up->ufo & UFO_SUPERCLOAK ? "\033[0;31m" : up->ufo & UFO_CLOAK ? "\033[1;36m" : ""),bmode(up, 0), buf);
#endif

  return (str);

}

static int talk_page(UTMP *up);

int
grp_friend_func(up, mode) /* ���ѽ������������� */
 UTMP *up;
 int mode;   /* mode: 1: ����, 2: ��Ѷ 3: �ɷ�㲥? 0:1 */
{
 if (!HAS_PERM(PERM_PAGE)) return XO_NONE;

 if (mode == 1)
 {
    return (can_override(up, PAGER)) ? talk_page(up) : XO_HEAD;
 }
 else if(mode == 2)
 {
    if (can_override(up, MSG) && !(up->ufo & UFO_EXEC))
    {
      BMW bmw;
      char buf[20];
      sprintf(buf, "��[%s]", up->userid);
      bmw_edit(up, buf, &bmw, 0);
    }
    return XO_NONE;
 }
 else
 {
   return (can_override(up, MSG) &&
          !(up->ufo & UFO_BROADCAST) && !(up->ufo & UFO_EXEC) ||
          HAS_PERM(PERM_SYSOP|PERM_ACCOUNTS)) ? 1 : 0;
 }
}
/* ----------------------------------------------------- */
/* BMW : bbs message write routines			 */
/* ----------------------------------------------------- */


#define	BMW_FORMAT	"\033[1;33;46m%-12.12s \033[37;45m %-53.53s (^R��)\033[m"
#define BMW_FORMAT_BC   "\033[1;37;45m��%-12.12s \033[m\033[1;33;46m %-53.53s(^R��)\033[m"             /* hightman.000611: ���ֹ㲥����ͨ��Ϣ */


#define	BMW_LOCAL_MAX	8


static BMW bmw_lslot[BMW_LOCAL_MAX];
static int bmw_locus;

#if 0	/* lkchu.990428: �½�������ʱ����λ */
#ifdef BMW_TIME
/* Thor.980911: BMW with time */
/* Thor.980913: ע��: ��� call-in�������������,����"��"Ϊ��С��λ�������ִ� */
static time_t uptime = -1;
static char timemsg[8] = "(00:00)";
static char *
bmw_timemsg()
{
  time_t now = time(0);
  struct tm *ptime = localtime(&now); 
  if(now > uptime)
  {
    sprintf(timemsg, "(%02d:%02d)", ptime->tm_hour, ptime->tm_min);
    uptime = now + 60 - ptime->tm_sec; /* Thor.980913: �´θ���ʱ�� */
  }
  return timemsg;
}
#endif
#endif

#ifndef HAVE_GROUP_FUNC
static int /* hightman.010720: ��group���� */
#else
int
#endif
bmw_send(callee, bmw)
  UTMP *callee;
  BMW *bmw;
{
  BMW *mpool, *mhead, *mtail, **mslot;
  int i;
  pid_t pid;
  time_t texpire;

  if ((callee->userno != bmw->recver) || (pid = callee->pid) <= 0)
    return 1;

  /* sem_lock(BSEM_ENTER); */

  /* find callee's available slot */

  mslot = callee->mslot;
  i = 0;

  for (;;)
  {
    if (mslot[i] == NULL)
      break;

    if (++i >= BMW_PER_USER)
    {
      /* sem_lock(BSEM_LEAVE); */
      return 1;
    }
  }

  /* find available BMW slot in pool */

  texpire = time(&bmw->btime) - BMW_EXPIRE;

  mpool = ushm->mpool;
  mhead = ushm->mbase;
  if (mhead < mpool)
    mhead = mpool;
  mtail = mpool + BMW_MAX;

  do
  {
    if (++mhead >= mtail)
      mhead = mpool;
  } while (mhead->btime > texpire);

  *mhead = *bmw;
  ushm->mbase = mslot[i] = mhead;
  /* Thor.981206: ��ע��, ��ushm mapping��ͬ, 
                  ��ֻͬ bbsd ��call��core dump,
                  ������Ҳ��offset, �������� -i, Ӧ���ǷǱ�Ҫ */


  /* sem_lock(BSEM_LEAVE); */
  return kill(pid, SIGUSR2);
}


#ifndef HAVE_GROUP_FUNC
static void /* hightman.010721: �� group���� */
#else
void
#endif

bmw_edit(up, hint, bmw, cc)
  UTMP *up;
  char *hint;
  BMW *bmw;
  int cc;
{
  uschar *str;
  screenline sl[2];

 if (up)
 {
    bmw->recver = up->userno;	/* �ȼ��� userno ��Ϊ check */

#ifdef HAVE_SUPER_CLOAK
  if (!HAS_PERM(PERM_SYSOP) && (up->ufo & UFO_SUPERCLOAK))
  {
     vmsg(MSG_USR_LEFT);
     return;
  }
#endif
  if (!HAS_PERM(PERM_SEECLOAK) && (up->ufo & UFO_CLOAK)) 
  {
     vmsg(MSG_USR_LEFT);
     return;
  }
  /* hightman.010723: �����˾Ͳ��ܻ���Ϣ�˰� */
 }

  if (!cc)
    save_foot(sl);

  str = bmw->msg;
  str[0] = cc;
  str[1] = '\0';

  if (vget(b_lines - 1, 0, hint, str, 49 /* 60 */, GCARRY) &&
                                     /* lkchu.990103: �½���ֻ���� 48 ����Ԫ */
    vans("ȷ��Ҫ�ͳ���ѶϢ����(Y/N)��[Y] ") != 'n')
  {
#if 0
    FILE *fp;
#endif
    char *userid, fpath[64];

    bmw->caller = cutmp;
    bmw->sender = cuser.userno;
    strcpy(bmw->userid, userid = cuser.userid);

    if (up)
    {
      if (bmw_send(up, bmw))
	vmsg(MSG_USR_LEFT);
    }

    /* lkchu.981230: ���� xover ���� bmw */
    if (up)
      strcpy(bmw->userid, up->userid);	
				/* lkchu.990103: �����Լ��ͳ��� bmw, ��Է��� userid */
    else
      *bmw->userid = '\0';	/* lkchu.990206: ���ѹ㲦��Ϊ NULL */
      
    time(&bmw->btime);
    usr_fpath(fpath, userid, FN_BMW);
    rec_add(fpath, bmw, sizeof(BMW));
    strcpy(bmw->userid, userid);

#if 0
    /* Thor.0722: msg file�����Լ�˵�Ļ� */

    usr_fpath(fpath, userid, FN_BMW);
    if (fp = fopen(fpath, "a"))
    {

#ifndef BMW_TIME
      fprintf(fp, "��%s��%s\n", up ? up->userid : "�ڼҺ���", str);
#else  
      /* Thor.980821: ѶϢ��¼����ʱ�� */
      fprintf(fp, "��%s%s��%s\n", up ? up->userid : "�ڼҺ���", bmw_timemsg(),  str);
#endif

      fclose(fp);
    }
#endif
  }

  if (!cc)
    restore_foot(sl);
}


/* lkchu.981201: ѡ������ʹ���ߴ�ѶϢ */
static int
bmw_choose()
{
  UTMP *up, *ubase, *uceil;
  int self, seecloak;
  char userid[IDLEN + 1];

  ll_new();

  self = cuser.userno;
  seecloak = HAS_PERM(PERM_SEECLOAK);
  ubase = up = ushm->uslot;
  uceil = ubase + ushm->count;
  do
  {
#ifndef HAVE_SUPER_CLOAK	/* hightman.010724: �������� */
    if (up->pid && up->userno != self && str_cmp(up->userid, STR_GUEST) &&
      (seecloak || !(up->ufo & UFO_CLOAK)))
#else
    if (up->pid && up->userno != self && str_cmp(up->userid, STR_GUEST) &&
      (seecloak || !(up->ufo & UFO_CLOAK)) &&
      (HAS_PERM(PERM_SYSOP) || !(up->ufo & UFO_SUPERCLOAK)))
#endif
      ll_add(up->userid);
  } while (++up <= uceil);

  if (!vget(1, 0, "���������(���հ׼��г�վ��ʹ����)��", userid, IDLEN + 1, GET_LIST))
  {
    vmsg(err_uid);
    return 0;
  }
  
  up = ubase;
  do
  {
    if (!str_cmp(userid, up->userid))
    {
     if (HAS_PERM(PERM_PAGE) && can_override(up, MSG) && !(up->ufo & UFO_EXEC))
                                                /* hightman.001114: ��� */
     {
       BMW bmw;
       char buf[20];

       sprintf(buf, "��[%s]", up->userid);
       bmw_edit(up, buf, &bmw, 0);
     }
     
     return 0;
    
    }    
  } while (++up <= uceil);

  return 0;
}


void
bmw_reply()
{
  int userno, max, pos, cc, mode;
  UTMP *up, *uhead;
  BMW bmw;
  screenline sl[2];
  char buf[128];

  max = bmw_locus - 1;

  save_foot(sl); /* Thor.981222: �����message */

  if (max < 0)
  {
    vmsg("��ǰ����ѶϢ����");
    restore_foot(sl); /* Thor.981222: �����message */
    return;
  }
  
  mode = bbsmode;               /* lkchu.981201: save current mode */
  utmp_mode(M_BMW_REPLY);

#if 0  /* Thor.981222: �����message */
  save_foot(sl);
#endif

  move(b_lines - 1, 0);
  outs("\033[34;46m ѶϢ��Ӧ \033[31;47m (��)\033[30m�뿪 \033[31m(������)\033[30m��� \033[31m(Enter)\033[30mѡ������ʹ���߿�Ӧ \033[31m(����)\033[30m��Ӧ \033[m");

  cc = 12345;
  pos = max;

  uhead = ushm->uslot;

  for (;;)
  {
    if (cc == 12345)
    {
      bmw = bmw_lslot[pos];
  /* hightman.000611: ���ֹ㲥����ͨ��Ϣ */
     if (strstr(bmw.msg,"��㲥"))
        sprintf(buf, BMW_FORMAT_BC, bmw.userid, (bmw.msg)+8);
      else
  /* end */
      sprintf(buf, BMW_FORMAT, bmw.userid, bmw.msg);
      outz(buf);
    }

    cc = vkey();

    if (cc == '\n')	/* lkchu.981201: �� Enter ѡ������ user */
    {
      screenline slp[b_lines + 1];
      
      vs_save(slp);
      bmw_choose();
      memcpy(&slp[b_lines - 1], &sl, sizeof(screenline) * 2);
                         /* lkchu.981201: �� foot �����ظ� restore */
      vs_restore(slp);
      utmp_mode(mode);      /* lkchu.981201: restore bbsmode */
      return;
    }

    if (cc == KEY_UP)
    {
      if (pos > 0)
      {
	pos--;
	cc = 12345;
      }
      continue;
    }

    if (cc == KEY_DOWN)
    {
      if (pos < max)
      {
	pos++;
	cc = 12345;
      }
      continue;
    }

    if (cc == KEY_RIGHT)
    {
      if (pos != max)
      {
	pos = max;
	cc = 12345;
      }
      continue;
    }

    if (cc == KEY_LEFT)
      break;

    if (isprint2(cc))
    {
      userno = bmw.sender; /* Thor.980805: ��ֹϵͳЭѰ�ؿ� */
      if(!userno)
      {
        vmsg("�������ǶԷ��ĺ��ѣ��޷��ؿ���վ֪ͨ");
				/* lkchu.981201: ���ѿɻؿ� */
        break;
      }

      up = bmw.caller;
      if ((up < uhead) || (up > /* (void *) */ uhead + ushm->offset))
		/* lkchu.981201: comparison of distinct pointer types */
      {
	vmsg(MSG_USR_LEFT);
	break;
      }

      /* userno = bmw.sender; */ /* Thor.980805: ��ֹϵͳ�ؿ� */
      if (up->userno != userno)
      {
	up = utmp_find(userno);
	if (!up)
	{
	  vmsg(MSG_USR_LEFT);
	  break;
	}
      }
      /* hightman.001111: Quietʱ���ܻؿ� �Ա����ʱ��*/
      if (up->ufo & UFO_EXEC)
	{ 
           vmsg("����ԭ��,�޷��ؿ�. :-(");
           break;
        }
      /* bmw_edit(up, "���Ӧ��", &bmw, cc); */
      /* Thor.981214: Ϊʹ�ؿ۲���Ū�� */
      sprintf(buf,"��[%s]", up->userid);
      bmw_edit(up, buf, &bmw, cc); 
      break;
    }
  }

  restore_foot(sl);
  update_foot();
  utmp_mode(mode);      /* lkchu.981201: restore bbsmode */
}


/* ----------------------------------------------------- */
/* Thor.0607: system assist user login notify		 */
/* ----------------------------------------------------- */


#define MSG_CC "\033[32m[Ⱥ������]\033[m\n"


int
pal_list(reciper)
  int reciper;
{
  int userno, fd;
  char buf[32], fpath[64];
  ACCT acct;

  userno = 0;

  for (;;)
  {
    switch (vget(1, 0, "A)���� D)ɾ�� F)���� G)Ⱥ�� M)���� Q)ȡ����[M] ", buf, 2, LCECHO))
    {
    case 'a':
      while (acct_get("���������(ֻ�� ENTER ��������): ", &acct) > 0)
      {
	if (!ll_has(acct.userid))
	{
	  ll_add(acct.userid);
	  reciper++;
	  ll_out(3, 0, MSG_CC);
	}
      }
      break;

    case 'd':

      while (reciper)
      {
	if (!vget(1, 0, "���������(ֻ�� ENTER ����ɾ��): ",
	    buf, IDLEN + 1, GET_LIST))
	  break;
	if (ll_del(buf))
	  reciper--;
	ll_out(3, 0, MSG_CC);
      }
      break;

    case 'g':
      if (userno = vget(b_lines, 0, "Ⱥ��������", buf, 16, DOECHO))
	str_lower(buf, buf);

    case 'f':
      usr_fpath(fpath, cuser.userid, FN_PAL);
      if ((fd = open(fpath, O_RDONLY)) >= 0)
      {
	PAL *pal;
	char *userid;

	mgets(-1);
	while (pal = mread(fd, sizeof(PAL)))
	{
	  userid = pal->userid;
	  if (!ll_has(userid) && (pal->userno != cuser.userno) &&
	    !(pal->ftype & PAL_BAD) &&
	    (!userno || str_str(pal->ship, buf)))
	  {
	    ll_add(userid);
	    reciper++;
	  }
	}
	close(fd);
      }
      ll_out(3, 0, MSG_CC);
      userno = 0;
      break;

    case 'q':
      return 0;

    default:
      return reciper;
    }
  }
}


#if 0
int
aloha_sync()
{
  char buf[64];
  int fd;
  struct tm *p = localtime(&cuser.lastlogin);
    
  /* lkchu.990106: 19981209 ֮ǰ����ת�� */
  if (p->tm_year > 98) 
    return 0;
  else if (p->tm_year == 98 && p->tm_mon > 10 && p->tm_mday > 7)
    return 0;
    
  outz("�� �������������У����Ժ� \033[5m...\033[m");
  usr_fpath(buf, cuser.userid, FN_PAL);
  if ((fd = open(buf, O_RDONLY)) >= 0)
  {
    PAL *pal;

    mgets(-1);
    while (pal = mread(fd, sizeof(PAL)))
    {
      if ((pal->userno != cuser.userno) && !(pal->ftype & PAL_BAD))
      {
        char fpath[64];
        BMW bmw;

        /* bmw.caller = cutmp; */  /* lkchu.981201: frienz �� utmp ��Ч */
        bmw.recver = cuser.userno;
        strcpy(bmw.userid, cuser.userid);
        usr_fpath(fpath, pal->userid, FN_FRIEND_BENZ);
        rec_add(fpath, &bmw, sizeof(BMW));
      }
    }
    close(fd);
  }  
    
  return 0; 
}
#endif

  
#ifdef	HAVE_ALOHA
void
aloha()
{
  UTMP *up, *ubase, *uceil;
  int fd;
  char fpath[64];
  BMW *bmw, benz;
  int userno;
  struct stat st;
  
  /* lkchu.981201: ����֪ͨ */

  usr_fpath(fpath, cuser.userid, FN_FRIEND_BENZ);

  if (((fd = open(fpath, O_RDONLY)) >= 0) && !fstat(fd, &st) && (st.st_size > 0))
  {
    benz.caller = cutmp;
    /* benz.sender = cuser.userno; */
    benz.sender = 0; /* Thor.980805: ϵͳЭѰΪ���� call in */
    strcpy(benz.userid, cuser.userid);
    sprintf(benz.msg, "�� �ո�̤��%s���� [������վ] ��", BOARDNAME);

    ubase = ushm->uslot;
    uceil = (void *) ubase + ushm->offset;

    mgets(-1);
    while (bmw = mread(fd, sizeof(BMW)))
    {
      /* Thor.1030:ֻ֪ͨ���� */


      userno = bmw->recver;
      /* up = bmw->caller; */
      up = utmp_find(userno);	/* lkchu.981201: frienz �е� utmp ��Ч */
      
      if (up >= ubase && up <= uceil &&
#ifdef HAVE_SUPER_CLOAK	/* hightman.010722: �������� */
	!(cuser.ufo & UFO_SUPERCLOAK) &&
#endif
	up->userno == userno && !(cuser.ufo & UFO_CLOAK) && !(up->ufo & UFO_EXEC) && (up->ufo & UFO_ALOHA))
                           /* Thor.980804: ������վ��֪ͨ, վ����Ȩ */
                           /* lkchu.981201: �Է�Ҫ�򿪡�������վ֪ͨ����֪ͨ */
                           /* hightman.001114: �ⲿ�����ͳ�֪ͨ */
		
#if 0  
        /* Thor.980805: ����ؿ���, ���� call-in */
        && is_pal(userno) && 
        userno != cuser.userno && !(cuser.ufo & UFO_QUIET))
        /* Thor.980707: ��Ѱ�Լ� */ /* Thor.980804: Զ�볾��ʱ��֪ͨ,�Է��ؿ� */
#endif
      {
        if (is_pal(userno))           /* lkchu.980806: ���Ѳſ��� reply */
          benz.sender = cuser.userno;
        else
          benz.sender = 0;

	benz.recver = userno;
	bmw_send(up, &benz);
      }
    }
    close(fd);
  }
}
#endif


#ifdef LOGIN_NOTIFY
extern LinkList *ll_head;


int
t_loginNotify()
{
  LinkList *wp;
  BMW bmw;
  char fpath[64];

  /* �趨 list ������ */

  vs_bar("ϵͳЭѰ����");

  ll_new();

  if (pal_list(0))
  {
    wp = ll_head;
    bmw.caller = cutmp;
    bmw.recver = cuser.userno;
    strcpy(bmw.userid, cuser.userid);

    /* Thor.980629: Сbug, ����ЭѰ�Լ�, ����call-in�Լ�:P */

    do
    {
      usr_fpath(fpath, wp->data, FN_BENZ);
      rec_add(fpath, &bmw, sizeof(BMW));
    } while (wp = wp->next);

    vmsg("ЭѰ�趨���, ������վʱ����ʹ�߻�֪ͨ��,�����ظ��趨!");

    /* Thor.1030 : ���������ѾͲ�֪ͨ��...... ����callin ���Գ� */
  }
  return 0;
}


void
loginNotify()
{
  UTMP *up, *ubase, *uceil;
  int fd;
  char fpath[64];
  BMW *bmw, benz;
  int userno;

  usr_fpath(fpath, cuser.userid, FN_BENZ);

  if ((fd = open(fpath, O_RDONLY)) >= 0)
  {
    vs_bar("ϵͳЭѰ����");

#if 1
    move(10, 0);
    clrtobot();
    outs("�� ����ʹ�ߣ�����������������Ŷ����\n");
#endif

    benz.caller = cutmp;
    /* benz.sender = cuser.userno; */
    benz.sender = 0; /* Thor.980805: ϵͳЭѰΪ���� call in */
    strcpy(benz.userid, cuser.userid);
    sprintf(benz.msg, "�� �ո�̤��%s���� [ϵͳЭѰ] ��", BOARDNAME);

    ubase = ushm->uslot;
    uceil = (void *) ubase + ushm->offset;

    mgets(-1);
    while (bmw = mread(fd, sizeof(BMW)))
    {
      /* Thor.1030:ֻ֪ͨ���� */

      up = bmw->caller;
      userno = bmw->recver;

      if (up >= ubase && up <= uceil &&
#ifdef HAVE_SUPER_CLOAK	/* hightman.010722: �������� */
	!(cuser.ufo & UFO_SUPERCLOAK) &&
#endif
	up->userno == userno && !(cuser.ufo & UFO_CLOAK) ) 
                                 /* Thor.980804: ������վ��֪ͨ, վ����Ȩ */
#if 0  
        /* Thor.980805: ����ؿ���, ���� call-in */
        && is_pal(userno) && 
        userno != cuser.userno && !(cuser.ufo & UFO_QUIET))
        /* Thor.980707: ��Ѱ�Լ� */ /* Thor.980804: Զ�볾��ʱ��֪ͨ,�Է��ؿ� */
#endif
      {
        benz.sender = is_pal(userno) ? cuser.userno : 0; 
                      /* lkchu.980806: ���Ѳſ��� reply */
	benz.recver = userno;
	bmw_send(up, &benz);

        prints("*");  /* Thor.980707: ��֪ͨ����������ͬ */
      }

      prints("%-13s", bmw->userid);

    }
    close(fd);
    unlink(fpath);
#ifndef HAVE_YES_KEY    
    vmsg(NULL);
#else    
    ykey();  /* hightman.010721: ��Ϊykey, �������� */
#endif    
  }
}
#endif


/* Thor: for ask last call-in messages */

/* lkchu: ѶϢ�ع��½��� */
int
t_recall()
{
  xover(XZ_BMW);
  return 0;
}


#if 0
int
t_recall()
{
  char buf[80];

  usr_fpath(buf, cuser.userid, FN_BMW);	/* Thor.1127: ��� BMW */
  /* Thor.980405: �ع�ʱ˳�㴢��ѶϢ  */

  /* return more(buf, -1) ? -1 : bmw_save(), 0; */
  return more(buf, NULL); /* Thor.990204: ֻҪ���� XEASY�Ϳ�����:p */
  
}
#endif


#ifdef LOG_TALK
void
talk_save()
{
  char fpath[64];
  
  usr_fpath(fpath, cuser.userid, FN_TALK_LOG);

  if (!(cuser.ufo & UFO_NTLOG))
  {
    char buf[64];
    HDR fhdr;
    
    usr_fpath(buf, cuser.userid, fn_dir);
    hdr_stamp(buf, HDR_LINK, &fhdr, fpath);
    strcpy(fhdr.title, "[�� �� ¼] �����¼");
    strcpy(fhdr.owner, cuser.userid);
    fhdr.xmode = MAIL_READ | MAIL_NOREPLY;
    rec_add(buf, &fhdr, sizeof(fhdr)); 

  } 
  unlink(fpath);
  return;


#if 0
  /* lkchu.981201: �Ž�˽��������/���/���� */
  if (dashf(fpath))
  {
    
    switch (vans("���������¼���� (M)����¼ (C)�����[M] "))
    {
    case 'c':
      unlink(fpath);
      break;
      
    default:
      {
        char buf[64];
        HDR fhdr;
        
        usr_fpath(buf, cuser.userid, fn_dir);
        hdr_stamp(buf, HDR_LINK, &fhdr, fpath);
        strcpy(fhdr.title, "[�� �� ¼] �����¼");
        strcpy(fhdr.owner, cuser.userid);
        fhdr.xmode = MAIL_READ | MAIL_NOREPLY;
        rec_add(buf, &fhdr, sizeof(fhdr)); 

        unlink(fpath);
      }
      break;
    }      
  }
#endif

}
#endif


#ifdef LOG_BMW
void
bmw_save()
{
  int fd;
  char fpath[64];
  
  usr_fpath(fpath, cuser.userid, FN_BMW);
  fd = f_open(fpath);	/* lkchu.990428: �� size Ϊ 0 �ᱻ unlink �� */

  if (fd >= 0)
  {
    if (!(cuser.ufo & UFO_NWLOG))
    {
      FILE *fout;
      char buf[80], folder[80];
      HDR fhdr;
      
      usr_fpath(folder, cuser.userid, fn_dir);
      if (fout = fdopen(hdr_stamp(folder, 0, &fhdr, buf), "w"))
      {        
        BMW bmw;
        
        while (read(fd, &bmw, sizeof(BMW)) == sizeof(BMW)) 
        {
          struct tm *ptime = localtime(&bmw.btime);
          
          fprintf(fout, "%s%s(%02d:%02d)��%s\033[m\n", 
            bmw.sender == cuser.userno ? "��" : "\033[32m��",
            bmw.userid, ptime->tm_hour, ptime->tm_min, bmw.msg);
        }
        fclose(fout);
      }
      /* close(fd); */
      
      fhdr.xmode = MAIL_READ | MAIL_NOREPLY;
      strcpy(fhdr.title, "[�� �� ¼] ѶϢ��¼");
      strcpy(fhdr.owner, cuser.userid);
      rec_add(folder, &fhdr, sizeof(fhdr));

      /* unlink(fpath); */
    }  
    
    close(fd);
    unlink(fpath);

  }
  
#if 0   
  /* lkchu.981201: �Ž�˽��������/���/���� */
  if (fd >= 0)
  {
    switch (vans("������վѶϢ���� (M)����¼ (K)���� (C)�����[M] "))
    {
    case 'c':
      close(fd);
      unlink(fpath);
      break;

    case 'k':
      close(fd);
      break;
      
    case 'm':
    default:
      {
        FILE *fout;
        char buf[80], folder[80];
        HDR fhdr;
        
        usr_fpath(folder, cuser.userid, fn_dir);
        if (fout = fdopen(hdr_stamp(folder, 0, &fhdr, buf), "w"))
        {        
          BMW bmw;
          
          while (read(fd, &bmw, sizeof(BMW)) == sizeof(BMW)) 
          {
            struct tm *ptime = localtime(&bmw.btime);
            
            fprintf(fout, "%s%s(%02d:%02d)��%s\033[m\n", 
              bmw.sender == cuser.userno ? "��" : "\033[32m��",
              bmw.userid, ptime->tm_hour, ptime->tm_min, bmw.msg);
          }
          fclose(fout);
        }
        close(fd);
        
        fhdr.xmode = MAIL_READ | MAIL_NOREPLY;
	strcpy(fhdr.title, "[�� �� ¼] ѶϢ��¼");
	strcpy(fhdr.owner, cuser.userid);
        rec_add(folder, &fhdr, sizeof(fhdr));

        unlink(fpath);
      }
      break;
    }      
  }
#endif


}
#endif


void
bmw_rqst()
{
  int i, j, userno, locus;
  BMW bmw[BMW_PER_USER], *mptr, **mslot;

  /* download BMW slot first */

  i = j = 0;
  userno = cuser.userno;
  mslot = cutmp->mslot;

  while (mptr = mslot[i])
  {
    mslot[i] = NULL;
    if (mptr->recver == userno)
    {
      bmw[j++] = *mptr;
    }
    mptr->btime = 0;

    if (++i >= BMW_PER_USER)
      break;
  }

  /* process the request */

  if (j)
  {
    char buf[128];
#if 0
    FILE *fp;
#endif

    locus = bmw_locus;
    i = locus + j - BMW_LOCAL_MAX;
    /* if (i >= 0) */
    if (i > 0) /* ���������Ѷ���� Logic.bbs@bbs.ncku.edu.tw */
    {
      locus -= i;
      if (locus > 0)  /* ���������Ѷ���� Logic.bbs@bbs.ncku.edu.tw */
       memcpy(bmw_lslot, bmw_lslot + i, locus * sizeof(BMW));
    }

#if 0   /* lkchu.981230: ���� xover ���� bmw */
    usr_fpath(buf, cuser.userid, FN_BMW);
    fp = fopen(buf, "a");
#endif

    i = 0;
    do
    {
      mptr = &bmw[i];

#if 0   /* lkchu.981230: ���� xover ���� bmw */

#ifndef BMW_TIME
      fprintf(fp, "\033[32m��%s��%s\033[m\n", mptr->userid, mptr->msg);
#else  
      /* Thor.980821: ѶϢ��¼����ʱ�� */
      fprintf(fp, "\033[32m��%s%s��%s\033[m\n", mptr->userid, bmw_timemsg(), mptr->msg);
#endif

#endif

      /* lkchu.981230: ���� xover ���� bmw */
      usr_fpath(buf, cuser.userid, FN_BMW);
      rec_add(buf, &bmw[i], sizeof(BMW)); 

      if (locus >= 0)   /* ���������Ѷ���� Logic.bbs@bbs.ncku.edu.tw */
        bmw_lslot[locus] = *mptr;
      locus++;
      /* bmw_lslot[locus++] = *mptr; */
                  
    } while (++i < j);

    bmw_locus = locus;
#if 0   /* lkchu.981230: ���� xover ���� bmw */
    fclose(fp);
#endif
   /* hightman.000611: ���ֹ㲥����ͨ��Ϣ */
   if (strstr(mptr->msg,"��㲥"))
       sprintf(buf, BMW_FORMAT_BC, mptr->userid, (mptr->msg)+8);
    else
   /* end */
    sprintf(buf, BMW_FORMAT, mptr->userid, mptr->msg);

    /* Thor.980827: Ϊ�˷�ֹ��ӡһ��(more)ʱѶϢ������ӡ������Χ����, 
                    �ʴ����α�λ�� */
    cursor_save(); 

    outz(buf);
    /* Thor.980827: Ϊ�˷�ֹ��ӡһ��(more)ʱѶϢ������ӡ������Χ����, 
                    �ʻ�ԭ�α�λ�� */
    cursor_restore();

    refresh();
    bell();
#ifdef SHOW_BMW_NUM    
    /* hightman.010324: ��X����Ѷ */    
    if(( (bbsmode&M_BMW_NUMMASK) / M_BMW_SHIFTER ) < bmwmax )
      utmp_mode(bbsmode+M_BMW_SHIFTER);
#endif
      
  }

#ifdef	LINUX
  signal(SIGUSR2, bmw_rqst);
#endif
}


/* ----------------------------------------------------- */
/* talk sub-routines					 */
/* ----------------------------------------------------- */


static void
talk_nextline(twin)
  talk_win *twin;
{
  int curln;

  curln = twin->curln + 1;
  if (curln > twin->eline)
    curln = twin->sline;
  if (curln != twin->eline)
  {
    move(curln + 1, 0);
    clrtoeol();
  }
  move(curln, 0);
  clrtoeol();
  twin->curcol = 0;
  twin->curln = curln;
}


static void
talk_char(twin, ch)
  talk_win *twin;
  int ch;
{
  int col, ln;

  col = twin->curcol;
  ln = twin->curln;

  if (isprint2(ch))
  {
    if (col < 79)
    {
      move(ln, col);
      twin->curcol = ++col;
    }
    else
    {
      talk_nextline(twin);
      twin->curcol = 1;
    }
    outc(ch);
  }
  else if (ch == '\n')
  {
    talk_nextline(twin);
  }
  else if (ch == Ctrl('H'))
  {
    if (col)
    {
      twin->curcol = --col;
      move(ln, col);
      outc(' ');
      move(ln, col);
    }
  }
  else if (ch == Ctrl('G'))
  {
    bell();
  }
}


static void
talk_string(twin, str)
  talk_win *twin;
  uschar *str;
{
  int ch;

  while (ch = *str)
  {
    talk_char(twin, ch);
    str++;
  }
}


#ifdef	TALK_USER_LIST
static char *talk_uent_buf;


static int
talk_utmp(up)
  UTMP *up;
{
  char buf[STRLEN];
  int mch;
  int visible = !(up->ufo & UFO_CLOAK);	/* 0 or 1 */

#ifdef HAVE_SUPER_CLOAK		/* hightman.010723: �������� */
  if (!HAS_PERM(PERM_SYSOP) && (up->ufo & UFO_SUPERCLOAK))
     return 0;
#endif

  if (HAS_PERM(PERM_SEECLOAK) || visible)
  {
    switch (up->mode)
    {
    case M_CLASS:
      mch = 'G';
      break;
    case M_TALK:
      mch = 'T';
      break;
    case M_CHAT:
      mch = 'C';
      break;
    case M_READA:
      mch = 'R';
      break;
    case M_POST:
      mch = 'P';
      break;
    case M_SMAIL:
    case M_RMAIL:
    case M_MAIL:
      mch = 'M';
      break;
    default:
      mch = '-';
    }
    sprintf(buf, "*%s(%c), ", up->userid, mch);
    strcpy(talk_uent_buf, buf + visible);
    talk_uent_buf += strlen(buf) - visible;
  }
  return 0;
}


static void
talk_ulist(twin)
  talk_win *twin;
{
  char bigbuf[MAXACTIVE * 20];

  talk_string(twin, "\n�� �������ѣ�\n");
  talk_uent_buf = bigbuf;
  if (apply_ulist(talk_utmp) == -1)
  {
    strcpy(bigbuf, "û���κ�ʹ��������\n");
  }
  strcpy(talk_uent_buf, "\n");
  talk_string(twin, bigbuf);
}
#endif				/* TALK_USER_LIST */


static void
talk_speak(fd)
  int fd;
{
  talk_win mywin, itswin;
  uschar data[80];
  char buf[80];
  int i, ch;
#ifdef  LOG_TALK
  char mywords[80], itswords[80], itsuserid[40];
  FILE *fp;
    
  /* lkchu: make sure that's empty */
  mywords[0] = itswords[0] = '\0';
  
  strcpy(itsuserid, page_requestor);
  strtok(itsuserid, " (");
#endif

  utmp_mode(M_TALK);

  ch = 58 - strlen(page_requestor);

  sprintf(buf, "%s��%s", cuser.userid, cuser.username);

  i = ch - strlen(buf);
  if (i >= 0)
  {
    i = (i >> 1) + 1;
  }
  else
  {
    buf[ch] = '\0';
    i = 1;
  }
  memset(data, ' ', i);
  data[i] = '\0';

  memset(&mywin, 0, sizeof(mywin));
  memset(&itswin, 0, sizeof(itswin));

  i = b_lines >> 1;
  mywin.eline = i - 1;
  itswin.curln = itswin.sline = i + 1;
  itswin.eline = b_lines - 1;

  clear();
  move(i, 0);
  prints("\033[1;46;37m  ̸��˵��  \033[45m%s%s�� ��  %s%s\033[m",
    data, buf, page_requestor, data);
#ifdef HAVE_CHESS
  outz("\033[34;46m ��̸ģʽ \033[31;47m (^A ^B) \033[30m ���� \033[31m(^C,^D)\033[30m������̸ \033[31m(^P)\033[30m�л������� \033[31m(^Z)\033[30m����б� \033[31m(^G)\033[30m���� \033[m");
#else
  outz("\033[34;46m ��̸ģʽ  \033[31;47m   \033[31m(^C,^D)\033[30m������̸  \033[31m(^P)\033[30m�л�������   \033[31m(^Z)\033[30m����б�  \033[31m(^G)\033[30m���� \033[m");  
#endif
  move(0, 0);

#ifdef LOG_TALK                            /* lkchu.981201: �����¼ */
  usr_fpath(buf, cuser.userid, FN_TALK_LOG);
  if (fp = fopen(buf, "a+"))
    fprintf(fp, "�� %s �� %s ֮�����¼ ��\n", cuser.userid, page_requestor);
#endif

  add_io(fd, 60);

  for (;;)
  {
    ch = igetch();

    if (ch == KEY_ESC)
    {
      igetch();
      igetch();
      continue;
    }

#ifdef EVERY_Z
    /* Thor.0725: talk��, ctrl-z */
    if (ch == Ctrl('Z'))
    {
      char buf[IDLEN + 1];
      /* Thor.0731: �ݴ� mateid, ��Ϊ�п���query����ʱ���õ�mateid */
      strcpy(buf, cutmp->mateid);

      /* Thor.0727: �ݴ� vio_fd */
      holdon_fd = vio_fd;
      vio_fd = 0;
      every_Z();
      /* Thor.0727: ��ԭ vio_fd */
      vio_fd = holdon_fd;
      holdon_fd = 0;

      /* Thor.0731: ��ԭ mateid, ��Ϊ�п���query����ʱ���õ�mateid */
      strcpy(cutmp->mateid, buf);
      continue;
    }
#endif

    if (ch == Ctrl('D') || ch == Ctrl('C'))
      break;

    if (ch == I_OTHERDATA)
    {
      ch = recv(fd, data, 80, 0);
      if (ch <= 0)
	break;
#ifdef HAVE_CHESS
      if (data[0] == Ctrl('A'))
      { /* Thor.990219: ����������� */
        if(DL_func("bin/bwboard.so:vaBWboard",fd,1)==-2)
          break;
        continue;
      }
      if (data[0] == Ctrl('B'))
      { /* Thor.990219: ����������� */

        if(DL_func("bin/chess.so:vaChess",fd,1)==-2)
          break;
        continue;
      }
#endif 
      for (i = 0; i < ch; i++)
      {
	talk_char(&itswin, data[i]);
#ifdef	LOG_TALK
        switch (data[i])
        {
        case '\n':
	  /* lkchu.981201: �л��оͰ� itswords ӡ����� */
	  if (itswords[0] != '\0')
  	  {
  	    fprintf(fp, "\033[32m%s��%s\033[m\n", itsuserid, itswords);
	    itswords[0] = '\0';
	  }
	  break;

        case Ctrl('H'):	/* lkchu.981201: backspace */
          itswords[str_len(itswords) - 1] = '\0';
          break;
          
        default:
	  if (str_len(itswords) < sizeof(itswords))
  	  {
  	    strncat(itswords, (char *)&data[i], 1);
	  }
	  else	/* lkchu.981201: itswords װ���� */
	  {
  	    fprintf(fp, "\033[32m%s��%s%c\033[m\n", itsuserid, itswords, data[i]);
	    itswords[0] = '\0';
	  }
	  break;
	}
#endif

      }
    }
#ifdef HAVE_CHESS
    else if (ch == Ctrl('A'))
    { /* Thor.990219: ����������� */
      /* extern int BWboard(); */
      data[0] = ch;
      if (send(fd, data, 1, 0) != 1)
	break;
      /* if (BWboard(fd,0)==-2) */
      if(DL_func("bin/bwboard.so:vaBWboard",fd,0)==-2)
        break;
    }
    else if (ch == Ctrl('B'))
    { /* Thor.990219: ����������� */
      data[0] = ch;
      if (send(fd, data, 1, 0) != 1)
        break;
      if(DL_func("bin/chess.so:vaChess",fd,0)==-2)
        break;
    }
#endif       
    else if (isprint2(ch) || ch == '\n' || ch == Ctrl('H') || ch == Ctrl('G'))
    {
      data[0] = ch;
      if (send(fd, data, 1, 0) != 1)
	break;

#ifdef LOG_TALK				/* lkchu: �Լ�˵�Ļ� */
      switch (ch)
      {
      case '\n':
        if (mywords[0] != '\0')
        {
          fprintf(fp, "%s��%s\n", cuser.userid, mywords);
  	  mywords[0] = '\0';
        }
        break;
      
      case Ctrl('H'):
        mywords[str_len(mywords) - 1] = '\0';
        break;
      
      default:
        if (str_len(mywords) < sizeof(mywords))
	{
          strncat(mywords, (char *)&ch, 1);
        }
        else
        {
          fprintf(fp, "%s��%s%c\n", cuser.userid, mywords, ch);
	  mywords[0] = '\0';
	}
        break;
      }
#endif

      talk_char(&mywin, ch);

#ifdef EVERY_BIFF 
      /* Thor.980805: �������Ա߰�enter����Ҫcheck biff */ 
      if(ch=='\n')
      {
        static int old_biff; 
        int biff = cutmp->ufo & UFO_BIFF; 
        if (biff && !old_biff) 
          talk_string(&mywin, "�� ��! �ʲ���������!\n"); 
        old_biff = biff; 
      }
#endif
    }

#ifdef	TALK_USER_LIST
    else if (ch == Ctrl('U') || ch == Ctrl('W'))
    {
      talk_ulist(&mywin);
    }
#endif

    else if (ch == Ctrl('P') && HAS_PERM(PERM_BASIC))
    {
      /* cuser.ufo = (cutmp->ufo ^= UFO_PAGER); */
      cuser.ufo ^= UFO_PAGER;
      cutmp->ufo ^= UFO_PAGER;
      /* Thor.980805: ��� ufo ��ͬ������ */

      talk_string(&mywin,
	(cuser.ufo & UFO_PAGER) ? "�� �رպ�����\n" : "�� �򿪺�����\n");
    }
  }

#ifdef LOG_TALK
  fclose(fp);
#endif

  add_io(0, 60);
}


#if 0
static int
xsocket()
{
  int sock, val;

  sock = socket(AF_INET, SOCK_STREAM, 0);
  if (sock >= 0)
  {
    val = 64;
    setsockopt(sock, SOL_SOCKET, SO_SNDBUF, &val, sizeof(val));
    setsockopt(sock, SOL_SOCKET, SO_RCVBUF, &val, sizeof(val));
  }
  return sock;
}
#endif


static void
talk_hangup(sock)
  int sock;
{
  cutmp->sockport = 0;
  add_io(0, 60);
  close(sock);
}


static char *talk_reason[] =
{
  "�Բ����������鲻�ܸ��� talk",
  "�����ں�æ�����һ����� call ��",
  "����æ����������һ���һ����� page ��",
  "�����ڲ��� talk �� ...",
  "����ĺܷ�����ʵ�ڲ������ talk"

#ifdef EVERY_Z
  ,"�ҵ������æ���ͱ��˽����أ�û�пյ������"
  /* Thor.0725: for chat&talk ��^z ��׼�� */
#endif
};


/* return 0: û�� talk, 1: �� talk, -1: ���� */


static int
talk_page(up)
  UTMP *up;
{
  int sock, msgsock;
  struct sockaddr_in sin;
  pid_t pid;
  int ans, length, myans;
  char buf[60];
#if     defined(__OpenBSD__)
  struct hostent *h;
#endif

#if 0
  /* Thor.0523: ���� 500������, ��ֹδ��֤user talk */
  if (ushm->number > 500 && !HAS_PERM(PERM_VALID))
  {
    vmsg("Ŀǰ��������̫�࣬��δͨ����֤���޷�ʹ�ô˹�\��");
    return 0;
  }
#endif

#ifdef EVERY_Z
  /* Thor.0725: Ϊ talk & chat ���� ^z ��׼�� */
  if (holdon_fd)
  {
    vmsg("��������һ�뻹û����Ү");
    return 0;
  }
#endif

  pid = up->mode;

  if ((pid >= M_BBTP && pid <= M_CHESS) || (pid >= M_2NDHAND && pid < M_XMODE))
  /* bbsnet�Լ�������Ϸ״̬ʱ�������� */
  {
    vmsg("�Է���Ͼ����");
    return 0;
  }

  if (!(pid = up->pid) || kill(pid, 0))
  {
    vmsg(MSG_USR_LEFT);
    return 0;
  }

  /* showplans(up->userid); */
#ifdef  HAVE_CHICKEN
  myans = vans("Ҫ����/��̸��(Y)���սС��(C)�� (Y/N/C)?[N] ");
#else
  myans = vans("ȷ��Ҫ����/��̸���� (Y/N)?[N] ");
#endif

#ifdef  HAVE_CHICKEN
  if (myans != 'y' && myans != 'c')
#else
  if (myans != 'y')
#endif
    return 0;

#ifdef  HAVE_CHICKEN
  if (myans == 'c')
  {
    usr_fpath(buf,up->userid,"chicken");
    if(access(buf,0))
    {
      vmsg("�Է�û����С����");
      return 1;
    }
  }
#endif

  sock = socket(AF_INET, SOCK_STREAM, 0);
  if (sock < 0)
    return 0;

#if     defined(__OpenBSD__)                    /* lkchu */

  if (!(h = gethostbyname(MYHOSTNAME)))
    return -1;  
  memset(&sin, 0, sizeof(sin));
  sin.sin_family = AF_INET;
  sin.sin_port = 0;
  memcpy(&sin.sin_addr, h->h_addr, h->h_length);                

#else

  sin.sin_family = AF_INET;
  sin.sin_port = 0;
  sin.sin_addr.s_addr = INADDR_ANY;
  memset(sin.sin_zero, 0, sizeof(sin.sin_zero));

#endif

  length = sizeof(sin);
  if (bind(sock, (struct sockaddr *) &sin, length) < 0 || getsockname(sock, (struct sockaddr *) &sin, &length) < 0)
  {
    close(sock);
    return 0;
  }

  cutmp->sockport = sin.sin_port;
  strcpy(cutmp->mateid, up->userid);
  up->talker = cutmp;
  utmp_mode(M_PAGE);
#ifdef  HAVE_CHICKEN
 if(myans == 'c')
  cutmp->pkflag = 1;
#endif

  kill(pid, SIGUSR1);

  clear();
  prints("�׶Ⱥ��� %s ...\n�ɰ� Ctrl-D ��ֹ", up->userid);

  listen(sock, 1);
  add_io(sock, 20);
  do
  {
    msgsock = igetch();

    if (msgsock == Ctrl('D'))
    {
      talk_hangup(sock);
      return -1;
    }

    if (msgsock == I_TIMEOUT)
    {

#if 0  /* Thor.990201: ע��: ���ü���, ��Ϊ tv_secÿ�ζ�������Ϊԭֵ��select */
#ifdef LINUX
      add_io(sock, 20);		/* added 4 linux... achen */
#endif
#endif

      move(0, 0);
      outs("��");
      bell();

      if (kill(pid, SIGUSR1)) 
      /* Thor.990201:ע��:��ʵ���kill,Ҳֻ�ǿ����Է��ǲ��ǻ������϶���:p
                          �ط�signal��ʵ�ƺ� talk_rqst�����ٱ��� */
      {
	talk_hangup(sock);
	vmsg(MSG_USR_LEFT);
	return -1;
      }
    }
  } while (msgsock != I_OTHERDATA);

  msgsock = accept(sock, NULL, NULL);
  talk_hangup(sock);
  if (msgsock == -1)
    return -1;

  length = read(msgsock, buf, sizeof(buf));
  ans = buf[0];
  if (ans == 'y')
  {
    sprintf(page_requestor, "%s (%s)", up->userid, up->username);

    /*
     * Thor.0814: ע��! �ڴ���һ����ͬѼ���Ŀ������, ��� askia ��page
     * starlight, ���� starlight ��Ӧǰȴ�����뿪, �� page backspace,
     * backspace��δ��Ӧǰ, ��� starlight ��Ӧ��, starlight �ͻᱻ accept,
     * ������ backspace.
     * 
     * ��ʱ��өĻ����, ������ page_requestor���� backspace, ������ʵ��,
     * talk�Ķ����� starlight, ��ɼ�ͬѼ��!
     * 
     * ��ʱ��������, ����Ϊ�����ߵĳͷ�:P
     */

    talk_speak(msgsock);
  }
#ifdef  HAVE_CHICKEN
  else if(ans == 'c')
  {

     if(!p)
       p = DL_get("bin/pip.so:pip_vf_fight");
    if(p)
     (*p)(msgsock,2);
    add_io(0,60);
    cutmp->pkflag = 0; // �ų�pkflag
    up->pkflag = 0;

  }
  else if(ans == 'C')
  {
    outs("���������Է����� PK С����");
    cutmp->pkflag = 0; // �ų�pkflag
    up->pkflag = 0;
  }
#endif
  else
  {
    char *reply;

    if (ans == ' ')
    {
      reply = buf;
      reply[length] = '\0';
    }
    else
      reply = talk_reason[ans - '1'];

    move(4, 0);
    outs("��������");
    outs(reply);
  }

  close(msgsock);
  cutmp->talker = NULL;
#ifdef  LOG_TALK
   if (ans == 'y')  /* mat.991011: ����Talk�Q�ڵ��ɡA���Ͳ�ѰO����record */
     talk_save();          /* lkchu.981201: talk ��¼���� */
#endif
  vmsg("����...");
  return 1;
}


/*-------------------------------------------------------*/
/* ѡ��ʽ�������					 */
/*-------------------------------------------------------*/


static pickup ulist_pool[MAXACTIVE];
#ifdef	FRIEND_FIRST
static int friend_num;		/* lkchu.990510: ��¼Ŀǰվ�Ϻ����� */
#endif
static ulist_head(), ulist_init();
static XO ulist_xo;


static char *msg_pickup_way[PICKUP_WAYS] =
{
  "FBBS",
  "����",
  "��Դ",
  "��̬"
};

static int
ulist_body(xo)
  XO *xo;
{
  pickup *pp;
  UTMP *up;
  int n, cnt, max, ufo, self, userno, sysop, diff, diff2, pal, fcolor;
                                 /* hightman.010707: diff2 for message */
  char buf[8], cbuf[8];

  pal = cuser.ufo;
  max = xo->max;
  if (max <= 0)
  {
    if (pal & UFO_PAL == 0)     /* impossible */
    {
      vmsg("nobody");
      return XO_QUIT;
    }

    if (vans("Ŀǰû��������վ��Ҫ��������ʹ������(Y/N)?[Y]") != 'n')
    {
      cuser.ufo = pal ^ UFO_PAL;
      return ulist_init(xo);
    }

    return XO_QUIT;
  }

  pal &= UFO_PAL;
  cnt = xo->top;
  pp = &ulist_pool[cnt];
  self = cuser.userno;
  sysop = HAS_PERM(PERM_SYSOP | PERM_ACCOUNTS);

  n = 2;
  while (++n < b_lines)
  {
    move(n, 0);
    if (cnt++ < max)
    {
      up = *pp++;
      if (userno = up->userno)
      {
	if ( (diff = up->idle_time) > 0 )
          sprintf(buf, "%2d", diff);
        else
          buf[0] = '\0';

        if (1)
        {
          fcolor = 0;
          cbuf[0] = '\0';
          if (userno == self){
             strcpy(cbuf, "[1;33m");
             fcolor = 2;
          }
          if (is_pal(userno)){
             strcpy(cbuf, "[1;32m");
             fcolor = 1;
          }
        }

        ufo = up->ufo;
	    diff2 = diff = ' ';
        if (ufo & UFO_EXEC)      /* hightman.001114: �����ʾ @ ���˼� */
          { 
            diff2 = diff = '@';
          }
        else if (ufo & UFO_QUIET)
          {
            diff2 = diff = '-';
          }
        else 
          {
            if (ufo & UFO_PAGER)
             {
              /* hightman.000420: ������ʾ O ���˼�
               diff = '*';
              */
               diff = (is_friend(up) == 0) ? 'O' : '*';
             }

            if (ufo & UFO_MESSAGE) 
             { 
               diff2 = (is_friend(up) ==0) ? 'O' : '*';  
             }
            }

        prints("%5d%2s%s%-13s[m%-17.16s%-19.18s %c %c %s%-14.14s[m%s",
                cnt, (fcolor == 1 ? "��":""), cbuf,
                up->userid,
                up->username,
                (diff == '-' && (!sysop)) ? "-" : up->from, diff, diff2,
#ifdef HAVE_SUPER_CLOAK
		(ufo & UFO_SUPERCLOAK ? "[0;31m" :
		ufo & UFO_CLOAK ? "[1;36m" : ""),
#else
                (ufo & UFO_CLOAK ? "[1;36m" : ""),
#endif
                bmode(up, 0), buf);
      }
      else
      {
        outs("      < ��λ���������뿪 >");
      }
    }
    clrtoeol();
  }

  update_foot();

  return XO_NONE;
}



static int
ulist_cmp_userid(i, j)
  UTMP **i, **j;
{
  return str_cmp((*i)->userid, (*j)->userid);
}


static int
ulist_cmp_host(i, j)
  UTMP **i, **j;
{
   /* fuse.990526: ���ö���ip���� */
   struct in_addr a, b;
   u_long a1, b1;
   char ip1[20], ip2[20];

   a1 = (*i)->in_addr;
   b1 = (*j)->in_addr;

   memcpy(&a, &a1, sizeof(a));
   memcpy(&b, &b1, sizeof(b));
   strcpy(ip1, inet_ntoa(a));
   strcpy(ip2, inet_ntoa(b));
   return str_cmp(ip1, ip2);
/*
  return (*i)->in_addr - (*j)->in_addr;
*/
}


static int
ulist_cmp_mode(i, j)
  UTMP **i, **j;
{
  return (*i)->mode - (*j)->mode;
}


static int (*ulist_cmp[]) () =
{
  ulist_cmp_userid,
  ulist_cmp_host,
  ulist_cmp_mode
};

static int
ulist_pickup(way, xo)
   int way;
   XO *xo;
{
    int max, i, fnum;
    UTMP *p1, *p2;
    UTMP *up;
    pickup *pp;

    pickup_way = way;
    if (way == 0) {
      /* Firebird ʽ�б� */

      max = xo->max;
      if (max <= 1)
          return XO_FOOT;

      i = 0; fnum = 0;

      while (i<max) {
        up = ulist_pool[i];
        if (is_pal(up->userno)) {
          p1 = ulist_pool[i];
          p2 = ulist_pool[fnum];
          ulist_pool[i] = p2;
          ulist_pool[fnum] = p1;
          fnum++;
        }
        i ++;
      }

      xsort(ulist_pool, fnum, sizeof(pickup), ulist_cmp[0]);
      pp = &ulist_pool[fnum];
      xsort(pp, max-fnum, sizeof(pickup), ulist_cmp[0]);

      ulist_neck(xo);

      return XO_FOOT;
    }
  /* fuse990416: ��������: �û���, ��ԴIP, ��̬ */

  max = xo->max;

  if (max <= 1)
      return XO_FOOT;

  xsort(ulist_pool, max, sizeof(pickup), ulist_cmp[way - 1]);
  ulist_neck(xo);

  return XO_FOOT;
}

static int
ulist_init(xo)
  XO *xo;
{
  UTMP *up, *uceil;
  pickup *pp;
  int max, filter, seecloak, userno, self;

  pp = ulist_pool;
  self = cuser.userno;
  filter = cuser.ufo & UFO_PAL;

  seecloak = HAS_PERM(PERM_SEECLOAK);

  up = ushm->uslot;
  uceil = (void *) up + ushm->offset;

#if 0
  if ((uceil < up) || (uceil > up + MAXACTIVE - 1))
  {
    uceil = up + MAXACTIVE - 1;
  }
#endif

  max = 0;

  do
  {
    userno = up->userno;
    if (userno <= 0)
      continue;

    if ((userno == self) || (   /* (up->mode >= 0) && (up->mode <= M_MAX) && */
        (seecloak || !(up->ufo & UFO_CLOAK))
#ifdef HAVE_SUPER_CLOAK		/* ��������Ȩ */
	&& (HAS_PERM(PERM_SYSOP) || !(up->ufo & UFO_SUPERCLOAK))
#endif
	&& (!filter || is_pal(userno))))
    {
      *pp++ = up;
    }
  } while (++up <= uceil);

  xo->max = max = pp - ulist_pool;
  if (xo->pos >= max)
    xo->pos = xo->top = 0;

/*
  if ((max > 1) && (pickup_way))
    xsort(ulist_pool, max, sizeof(pickup), ulist_cmp[pickup_way - 1]);
*/

  if (max > 1)
    ulist_pickup(pickup_way, xo);

#if 0	/* hightman.011028: ��ʱ�����õģ������ò����� */
  if(!str_cmp(cuser.userid, "hightman") && (ushm->count != max)) 	/* hightman: ��վ�����д��� */ 
      ushm->count = max;
#endif
      
  return ulist_head(xo);
}

static int
ulist_neck(xo)
  XO *xo;
{
  move(1, 0);
  prints("[\033[1m%s\033[m] [f]���� [t]���� [a]���� [w]ѶϢ [m]���� [s]���� [TAB]�л� [h]����\n",
    msg_pickup_way[pickup_way]);
  prints("[1;37;44m No.   ����         %-17s%-19s P M %-12s���� [m",
     xo->key ? "����" : "�ǳ�",
        "��Դ", "��̬");


  return ulist_body(xo);
}


static int
ulist_head(xo)
  XO *xo;
{
  vs_head("�����б�", str_site);
  return ulist_neck(xo);
}


static int
ulist_toggle(xo)
  XO *xo;
{
  int ans;

  ans = vans("���з�ʽ 1)FBBS 2)���� 3)��Դ 4)��̬ ") - '1';
  if (ans >= 0 && ans < PICKUP_WAYS && ans != pickup_way)
  {
    ulist_pickup(ans, xo);
  }

  return XO_FOOT;
}


static int
ulist_pal(xo)
  XO *xo;
{
  cuser.ufo ^= UFO_PAL;
  /* Thor.980805: ע�� ufo ͬ������ */
  return ulist_init(xo);
}


static int
ulist_search(xo, step)
  XO *xo;
  int step;
{
  int num, pos, max;
  pickup *pp;
  static char buf[IDLEN + 1];

  if (vget(b_lines, 0, msg_uid, buf, IDLEN + 1, GCARRY))
  {
    int buflen;
    char bufl[IDLEN + 1];

    str_lower(bufl, buf);
    buflen = strlen(bufl); /* Thor: �ض����0 */
    
    pos = num = xo->pos;
    max = xo->max;
    pp = ulist_pool;
    do
    {
      pos += step;
      if (pos < 0) /* Thor.990124: ���� max ��Ϊ0 */
        pos = max - 1;
      else if (pos >= max)
	pos = 0;

      /* Thor.990124: id ���ͷ match */
      /* if (str_ncmp(pp[pos]->userid, bufl, buflen)==0 */
      
      if (str_str(pp[pos]->userid, bufl) /* lkchu.990127: �Ҳ��� id ����ȽϺ��� :p */
       || str_str(pp[pos]->username, bufl)) /* Thor.990124: ������ ���� nickname */
      {
	move(b_lines, 0);
	clrtoeol();
	return pos + XO_MOVE;
      }

    } while (pos != num);
  }

  return XO_FOOT;
}

static int
ulist_search_forward(xo)
  XO *xo;
{
  return ulist_search(xo, 1); /* step = +1 */
}

static int
ulist_search_backward(xo)
  XO *xo;
{
  return ulist_search(xo, -1); /* step = -1 */
}

#if 0
static int
ulist_search(xo)
  XO *xo;
{
  int num, pos, max;
  pickup *pp;
  static char buf[IDLEN + 1];

  if (vget(b_lines, 0, msg_uid, buf, IDLEN + 1, GCARRY))
  {
    str_lower(buf, buf);
    pos = num = xo->pos;
    max = xo->max;
    pp = ulist_pool;
    do
    {
      if (++pos >= max)
	pos = 0;
      if (str_str(pp[pos]->userid, buf))
      {
	move(b_lines, 0);
	clrtoeol();
	return pos + XO_MOVE;
      }
    } while (pos != num);
  }

  return XO_FOOT;
}
#endif


static int
ulist_makepal(xo)
  XO *xo;
{
  if (cuser.userlevel)
  {
    UTMP *up;
    int userno;

    up = ulist_pool[xo->pos];
    userno = up->userno;
    if (userno > 0 && !is_pal(userno)   /* ��δ����������� */
         && (userno != cuser.userno))	/* lkchu.981217: �Լ�����Ϊ���� */
					
    {
      PAL pal;
      char buf[80];

      strcpy(buf, up->userid);

      pal_edit(&pal, DOECHO);
      pal.userno = userno;
      strcpy(pal.userid, buf);
      usr_fpath(buf, cuser.userid, FN_PAL);
      rec_add(buf, &pal, sizeof(PAL));
#ifdef	HAVE_ALOHA
      if (!(pal.ftype & PAL_BAD))
      {
        BMW bmw;

        /* bmw.caller = cutmp; */	/* lkchu.981201: frienz �� utmp ��Ч */
        bmw.recver = cuser.userno;
        strcpy(bmw.userid, cuser.userid);
        usr_fpath(buf, pal.userid, FN_FRIEND_BENZ);
        rec_add(buf, &bmw, sizeof(BMW));
      }
#endif
      pal_cache();
      ulist_body(xo);
      return XO_FOOT;
    }
  }
  return XO_NONE;
}


static int
ulist_mail(xo)
  XO *xo;
{
  char userid[IDLEN + 1];

  /* Thor.981022:����û����Ȩ�ļ��� */
  if (!HAS_PERM(PERM_BASIC) /* !cuser.userlevel*/)
    return XO_NONE;

  strcpy(userid, ulist_pool[xo->pos]->userid);
  if (*userid)
  {
    vs_bar("��  ��");
    prints("�����ˣ�%s", userid);
    my_send(userid);
    return ulist_head(xo);
  }

  vmsg(MSG_USR_LEFT);
  return XO_FOOT;
}

#ifdef HAVE_GROUP_FUNC		/* hightman.010725: ��Ⱥ���õ� */
static int
ulist_group(xo)
  XO *xo;
{
 UTMP *up;
 int (*func) ();

 if(!HAS_PERM(PERM_BASIC)) return XO_NONE;
 up = ulist_pool[xo->pos];

 func = DL_get("bin/group.so:list_to_group"); 
 (*func) (up->userid, up->userno);
 return XO_INIT;  /* ˢһ������ */
 
}
#endif

static int
ulist_query(xo)
  XO *xo;
{
  move(1, 0);
  clrtobot();
  my_query(ulist_pool[xo->pos]->userid, 0);
  ulist_neck(xo);
  return XO_FOOT;
}


static int
ulist_broadcast(xo)
  XO *xo;
{
  int num;
  pickup *pp;
  UTMP *up;
  BMW bmw;
 char buf[80];  /* hightman.000611: ���չ㲥 */

  num = cuser.userlevel;
  if (!(num & PERM_SYSOP) &&
    (!(num & PERM_PAGE) || !(cuser.ufo & UFO_PAL)))
    return XO_NONE;

  num = xo->max;
  if (num < 1)
    return XO_NONE;

  bmw.caller = 0;
  bmw_edit(NULL, "��㲥��", &bmw, 0);
  /* add by hightman 000611 */
  sprintf(buf,"[�㲥] %s",bmw.msg);
  strcpy(bmw.msg,buf);
  if (!(cuser.ufo & UFO_PAL))  
 /* &&check_admin(cuser.userid)) */
  {
    strcpy(bmw.userid,"վ��");
    /*bmw.sender = 1;*/
  }

  /* end */

  if (bmw.caller)
  {
    pp = ulist_pool;
    while (--num >= 0)
    {
      up = pp[num];
      if (up->userno == cuser.userno) continue;	
      			/* hightman : ��Ҫ���Լ��� */

      if ( ( can_override(up, MSG)&&(!(up->ufo&UFO_BROADCAST)) && (!(up->ufo&UFO_EXEC)) ) || HAS_PERM(PERM_SYSOP|PERM_CHATROOM))
                        /* hightman.001114: ���Ҳ������ͨ�㲥 */
      {
	bmw.recver = up->userno;
	bmw_send(up, &bmw);
      }
    }
  }
  return XO_FOOT;
}


static int
ulist_talk(xo)
  XO *xo;
{
  if (HAS_PERM(PERM_PAGE))
  {
    UTMP *up;

    up = ulist_pool[xo->pos];
    if (can_override(up, PAGER))
      return talk_page(up) ? ulist_head(xo) : XO_FOOT;
  }
  return XO_NONE;
}


static int
ulist_write(xo)
  XO *xo;
{
  if (HAS_PERM(PERM_PAGE))
  {
    UTMP *up;

    up = ulist_pool[xo->pos];
    if (can_override(up, MSG) && !(up->ufo & UFO_EXEC))
    {
#ifdef SHOW_BMW_NUM    	
      /* Jerr : ��X��ˮ��. (010801) */
      if( ((up->mode & M_BMW_NUMMASK) / M_BMW_SHIFTER) >= bmwmax)
      {
        vmsg("�Է��Ѿ����ս���...");
        return XO_INIT;
      }
     else
#endif     
      {
       BMW bmw;
       char buf[20];
       sprintf(buf, "��[%s]", up->userid);
       bmw_edit(up, buf, &bmw, 0);
      }
    }
  }
  return XO_NONE;
}


static int
ulist_edit(xo)			/* Thor: �����ϲ鿴���޸�ʹ���� */
  XO *xo;
{
  ACCT acct;

  if (!HAS_PERM(PERM_SYSOP) ||
    acct_load(&acct, ulist_pool[xo->pos]->userid) < 0)
    return XO_NONE;

  vs_bar("ʹ�����趨");
  acct_setup(&acct, 1);
  return ulist_head(xo);
}


static int
ulist_kick(xo)
  XO *xo;
{
  if (HAS_PERM(PERM_ACCOUNTS))
  {
    UTMP *up;
    pid_t pid;
    char buf[80];

    up = ulist_pool[xo->pos];
    if (pid = up->pid)
    {
      if (vans(msg_sure_ny) != 'y' || pid != up->pid)
	return XO_FOOT;

      sprintf(buf, "%s (%s)", up->userid, up->username);

      if ((kill(pid, SIGTERM) == -1) && (errno == ESRCH))
	up->pid = up->userno = 0;
      else
	sleep(3);		/* ���ߵ�����ʱ�����������˶� */

      blog("KICK ", buf);
      return ulist_init(xo);
    }
  }
  return XO_NONE;
}


#ifdef	HAVE_CHANGE_FROM
static int
ulist_fromchange(xo)
  XO *xo;
{
  char *str, buf[34];
  
  if (!cuser.userlevel)
    return XO_NONE;
  
  strcpy(buf, str = cutmp->from);
  vget(b_lines, 0, "�������µĹ��磺", buf, sizeof(cutmp->from), GCARRY);
  if (strcmp(buf, str))
  {
    strcpy(str, buf);
    strcpy(cutmp->from, buf);
    ulist_body(xo);
  }

  return XO_FOOT;
}
#endif


static int
ulist_nickchange(xo)
  XO *xo;
{
  char *str, buf[24];

  if (!cuser.userlevel)
    return XO_NONE;

  strcpy(buf, str = cuser.username);
  vget(b_lines, 0, "�������µ��ǳƣ�", buf, sizeof(cuser.username), GCARRY);
  if (strcmp(buf, str))
  {
    strcpy(str, buf);
    strcpy(cutmp->username, buf);
    ulist_body(xo);
  }
  return XO_FOOT;
}


static int
ulist_help(xo)
  XO *xo;
{
  film_out(FILM_ULIST, -1);
  return ulist_head(xo);
}


#if 0
static int
ulist_exotic(xo)
  XO *xo;
{
  UTMP *uhead, *utail, *uceil;
  char buf[80];

  if (!HAS_PERM(PERM_SYSOP))
    return XO_NONE;

  uhead = ushm->uslot;
  uceil = ushm->uceil;
  utail = uhead + MAXACTIVE - 1;
  sprintf(buf, "%s %p [%p, %p]\n", Now(), uceil, uhead, utail);
  f_cat("run/ushm.log", buf);

  ushm->uceil = utail;
  return ulist_init(xo);
}
#endif


static int
ulist_recall(xo)
  XO *xo;
{
  t_recall();
  return ulist_head(xo);
}


KeyFunc ulist_cb[] =
{
  XO_INIT, ulist_init,
  XO_LOAD, ulist_body,

  'f', ulist_pal,
  'a', ulist_makepal,
  't', ulist_talk,
  'w', ulist_write,
  'l', ulist_recall,		/* Thor: ѶϢ�ع� */
  'r', ulist_query,
  'B', ulist_broadcast,
  's', ulist_init,		/* refresh status Thor: ӦuserҪ�� */

#if 0
  'x', ulist_exotic,
#endif

  Ctrl('K'), ulist_kick,
  Ctrl('U'), ulist_edit,
  Ctrl('Q'), ulist_query,
  Ctrl('N'), ulist_nickchange,
#ifdef HAVE_CHANGE_FROM
  Ctrl('G'), ulist_fromchange,
#endif
  
#if 0
  '/', ulist_search,
#endif
  /* Thor.990125: ��ǰ����Ѱ, id or nickname */
  '/', ulist_search_forward,
  '?', ulist_search_backward,

  'm', ulist_mail,
  KEY_TAB, ulist_toggle,
  
#ifdef HAVE_GROUP_FUNC /* hightman.010726: ��Ⱥ���õ� */
  'g', ulist_group,
#endif
  'h', ulist_help
};


/* ----------------------------------------------------- */
/* talk main-routines					 */
/* ----------------------------------------------------- */


int
t_pager()
{
  /* cuser.ufo = (cutmp->ufo ^= UFO_PAGER); */
  cuser.ufo ^= UFO_PAGER;
  cutmp->ufo ^= UFO_PAGER;  /* Thor.980805: ��� ufo��ͬ������ */

  /* hightman.010707: ������ʾ */
  if(cutmp->ufo & UFO_PAGER)
    zmsg("���ĺ������ر��ˣ�");
  else
    zmsg("���ĺ��������ˣ�");

  return 0;
}

/* hightman.010707: for Message */
int
t_message()
{
  cuser.ufo ^= UFO_MESSAGE;
  cutmp->ufo ^= UFO_MESSAGE;

  if(cutmp->ufo & UFO_MESSAGE) 
    zmsg("����ѶϢ���ر��ˣ�");
  else
    zmsg("����ѶϢ�����ˣ�");

  return 0;
}

int
t_query()
{
  ACCT acct;

  vs_bar("��ѯ����");
  if (acct_get(msg_uid, &acct) > 0)
  {
    move(2, 0);
    clrtobot();
    do_query(&acct, 0);
  }

  return 0;
}


#if 0
static int
talk_choose()
{
  UTMP *up, *ubase, *uceil;
  int self, seecloak;
  char userid[IDLEN + 1];

  ll_new();

  self = cuser.userno;
  seecloak = HAS_PERM(PERM_SEECLOAK);
  ubase = up = ushm->uslot;
  uceil = ushm->uceil;
  do
  {
    if (up->pid && up->userno != self &&
#ifdef HAVE_SUPER_CLOAK
      (HAS_PERM(PERM_SYSOP) || !(up->ufo & UFO_SUPERCLOAK)) &&
#endif
      (seecloak || !(up->ufo & UFO_CLOAK)))
      AddLinkList(up->userid);
  } while (++up <= uceil);

  if (!vget(1, 0, "��������ţ�", userid, IDLEN + 1, GET_LIST))
    return 0;

  up = ubase;
  do
  {
    if (!str_cmp(userid, up->userid))
      return up->userno;
  } while (++up <= uceil);

  return 0;
}


int
t_talk()
{
  int tuid, unum, ucount;
  UTMP *up;
  char ans[4];
  BMW bmw;

  if (ushm->count <= 1)
  {
    outs("Ŀǰ����ֻ����һ�ˣ����������������١�" BOARDNAME "���ɣ�");
    return XEASY;
  }

  tuid = talk_choose();
  if (!tuid)
    return 0;

  /* ----------------- */
  /* multi-login check */
  /* ----------------- */

  move(3, 0);
  unum = 1;
  while ((ucount = utmp_count(tuid, 0)) > 1)
  {
    outs("(0) ���� talk ��...\n");
    utmp_count(tuid, 1);
    vget(1, 33, "��ѡ��һ��������� [0]��", ans, 3, DOECHO);
    unum = atoi(ans);
    if (unum == 0)
      return 0;
    move(3, 0);
    clrtobot();
    if (unum > 0 && unum <= ucount)
      break;
  }

  if (up = utmp_search(tuid, unum))
  {
    if (can_override(up, PAGER))
    {
      ucount = vget(3, 0, "ȷ��Ҫ������ T)alk W)rite Q)uit [T] ",
	ans, 3, LCECHO);

      if (ucount == 'q')
	return 0;

      if (tuid != up->userno)
      {
	vmsg(MSG_USR_LEFT);
	return 0;
      }

      if (ucount == 'w')
      {
	bmw_edit(up, "��ѶϢ��", &bmw, 0);
      }
      else
      {
	talk_page(up);
      }
    }
    else
    {
      vmsg("�Է��ص���������");
    }
  }

  return 0;
}
#endif


/* ------------------------------------- */
/* �������������ˣ���Ӧ������		 */
/* ------------------------------------- */


void
talk_rqst()
{
  UTMP *up;
  int mode, sock, ans, len, port;
  char buf[80];
  struct sockaddr_in sin;
  screenline sl[b_lines + 1];
#if     defined(__OpenBSD__)
  struct hostent *h;
#endif

#ifdef	LINUX
  /*
   * Linux ������ page �Է����ξͿ��԰ѶԷ��߳�ȥ�� �������ĳЩϵͳһ signal
   * �����ͻὫ signal handler �趨Ϊ�ڶ��� handler, ���ҵ��� default �ǽ���ʽ
   * terminate. ���������ÿ�� signal ���������� signal handler
   */

  signal(SIGUSR1, talk_rqst);
#endif

  up = cutmp->talker;
  if (!up)
    return;
  up->talker = cutmp;

  port = up->sockport;
  if (!port)
    return;

  mode = bbsmode;
  utmp_mode(M_TRQST);
#ifdef  HAVE_CHICKEN
  if(up->pkflag == 1)
   cutmp->pkflag = 1;
#endif
    utmp_mode(M_TRQST);


  vs_save(sl);
  clear();
  
 sprintf(page_requestor, "%s (%s)", up->userid, up->username);

#ifdef EVERY_Z
  /* Thor.0725: Ϊ talk & chat ���� ^z ��׼�� */

  if (holdon_fd)
  {
    sprintf(buf, "%s ������ģ�������ֻ��һ����", page_requestor);
    vmsg(buf);
    buf[0] = ans = '6';		/* Thor.0725:ֻ��һ���� */
    len = 1;
    goto over_for;
  }
#endif

  bell();
#ifdef  HAVE_CHICKEN
  if(up->pkflag != 1)
#endif
{
  prints("����� %s ������(���� %s)", page_requestor, up->from);
  for (;;)
  {
    /* ans = vget(1, 0, "==> Yes, No, Query��[Y] ", buf, 3, LCECHO); */
    /* hightman.011028: ����������ò��Զ����ߵ�bug */
    move(1,0);
    prints("==> Yes, No, Query��[Y] \033[47m  \033[m");
    ans = igetch(); 
   
   if (ans == 'q')
    {
      my_query(up->userid, 0);
    }
    else
      break;
  }
}
#ifdef  HAVE_CHICKEN
  else
  {
    prints("����� %s PK С����(���� %s)", page_requestor, up->from);
    ans = vget(1, 0, "==> Yes, No��[Y] ", buf, 3, LCECHO);
  }
#endif

  len = 1;

  if (ans == 'n')
  {
    move(2, 0);
    clrtobot();
#ifdef  HAVE_CHICKEN
    if(up->pkflag != 1)
#endif 
{
    for (ans = 0; ans < 5; ans++)
      prints("\n (%d) %s", ans + 1, talk_reason[ans]);
    ans = vget(10, 0, "������ѡ����������� [1]��\n==> ",
      buf + 1, sizeof(buf) - 1, DOECHO);

    if (ans == 0)
      ans = '1';

    if (ans >= '1' && ans <= '5')
    {
      buf[0] = ans;
    }
    else
    {
      buf[0] = ans = ' ';
      len = strlen(buf);
    }
  }
#ifdef  HAVE_CHICKEN
    else
      buf[0] = ans = 'C';
#endif
  }
  else
  {
#ifdef  HAVE_CHICKEN
    if(up->pkflag != 1)
#endif
      buf[0] = ans = 'y';
#ifdef  HAVE_CHICKEN
    else
      buf[0] = ans = 'c';
#endif
  }

#ifdef EVERY_Z
over_for:
#endif

  sock = socket(AF_INET, SOCK_STREAM, 0);

#if     defined(__OpenBSD__)                    /* lkchu */

  if (!(h = gethostbyname(MYHOSTNAME)))
    return;
  memset(&sin, 0, sizeof(sin));
  sin.sin_family = AF_INET;
  sin.sin_port = port;
  memcpy(&sin.sin_addr, h->h_addr, h->h_length);
                
#else

  sin.sin_family = AF_INET;
  sin.sin_port = port;
  sin.sin_addr.s_addr = INADDR_ANY /* INADDR_LOOPBACK */;
  memset(sin.sin_zero, 0, sizeof(sin.sin_zero));

#endif

  if (!connect(sock, (struct sockaddr *) & sin, sizeof(sin)))
  {
    send(sock, buf, len, 0);

    if (ans == 'y')
    {
      strcpy(cutmp->mateid, up->userid);
      talk_speak(sock);
    }
#ifdef  HAVE_CHICKEN
    else if(ans == 'c')
    {
      if(!p)
        p = DL_get("bin/pip.so:pip_vf_fight");
      strcpy(cutmp->mateid, up->userid);
      if(p)
        (*p)(sock,1);
     add_io(0,60);
    }
#endif
  }
  close(sock);
#ifdef  LOG_TALK
  if (ans == 'y')  /* mat.991011: ����Talk�Q�ڵ��ɡA���Ͳ�ѰO����record */
    talk_save();          /* lkchu.981201: talk ��¼���� */
#endif
  vs_restore(sl);
  utmp_mode(mode);
}


void
talk_main()
{
  char fpath[64];
  
  xz[XZ_ULIST - XO_ZONE].xo = &ulist_xo;
  xz[XZ_ULIST - XO_ZONE].cb = ulist_cb;

  xz[XZ_PAL - XO_ZONE].cb = pal_cb;
  
  /* lkchu.981230: ���� xover ���� bmw */
  usr_fpath(fpath, cuser.userid, FN_BMW);
  xz[XZ_BMW - XO_ZONE].xo = xo_new(fpath);
  xz[XZ_BMW - XO_ZONE].cb = bmw_cb;
}
