/*-------------------------------------------------------*/
/* xover.c	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : board/mail interactive reading routines 	 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#include "bbs.h"

#ifndef HAVE_GROUP_FUNC
#define	MSG_ZONE_SWITCH \
	"�����л���A)������ B)�����б� C)�����б� M)�ż� U)ʹ�������� W)�쿴ѶϢ��"
#else
#define	MSG_ZONE_SWITCH \
	"�ٻ���A)������ B)�����б� C)�����б� D)Ⱥ�� M)�ż� U)ʹ�������� W)�鿴ѶϢ ��"
#endif
/* Thor.0501: ����˵������Ӣ��...:p */
/* "Zone��A)nnounce B)oard C)lass M)ail U)ser��" */
/* static void delete_log(char* brd, int head, int tail); */

/* ----------------------------------------------------- */
/* keep xover record					 */
/* ----------------------------------------------------- */

#if 0
XO *class_xo;			/* �����б� */
XO *gem_xo;			/* ������ */
XO *mbox_xo;			/* ���� */
XO *pal_xo;			/* �������� */
XO ulist_xo;			/* ʹ�����б� */
XO *vote_xo;			/* ͶƱ */

XO *post_xo;			/* ���� */
#ifdef XZ_XPOST
XO *xpost_xo;			/* ���� */
#endif
#endif

static XO *xo_root;		/* root of overview list */

#ifdef HAVE_LOG_LBP		/* hightman: Last Board Position */
typedef struct
{
    char path[80];		/* data path */
    int  pos;			/* position  */          
}        LBP;
    
static LBP lbp_base[MAXBOARD];  /* allocated memory */
static int lbp_count;		/* ����? */

void lbp_load()  /* load the lbp */
{
 FILE *fp;
 int size,count;
 char folder[80];
 struct stat st;

 usr_fpath(folder, cuser.userid, FN_LBP);
 
 size = count = 0;
 if(!stat(folder, &st))
  size = st.st_size;
 
 lbp_count = count = size/sizeof(LBP);
  

 if(fp = fopen(folder, "r"))
   {
    fread(lbp_base, sizeof(LBP), count, fp);
    fclose(fp);
   }
}

void lbp_save()  /* save the lbp */
{
  LBP *tail,*base;
  int newcount, i;
  XO *xo;
  FILE *fp;
  char folder[80];

  usr_fpath(folder, cuser.userid, FN_LBP);

  newcount = lbp_count;
  tail  = lbp_base + lbp_count - 1;

  for(xo = xo_root; xo; xo = xo->nxt)
   {
     for(base = lbp_base, i = lbp_count; i > 0; base++, i--)
      {
        if(!strcmp(xo->dir, base->path)) 
         { 
           base->pos = xo->pos;
           break;
         }
       }
      if(i <= 0) 
        {
          tail++;
          newcount++;
          strcpy(tail->path, xo->dir);
          tail->pos = xo->pos;
      }
    }
 /* saveing... */
 if(fp = fopen(folder, "w"))
 {
  fwrite(lbp_base, sizeof(LBP), newcount, fp);
  fclose(fp);
 }
}

static int
lbp_get(fpath)  /* ��ȡfpath��λ�� */
 char *fpath;
{
 int count, pos;
 LBP *head;
 
 head = (LBP *) malloc(sizeof(LBP));
 pos = 0;

 count = lbp_count;

 for(head = lbp_base; count > 0; count --, head++)

  {
  if(!strcmp(head->path, fpath))
   {
    pos = head->pos;
    break;
 }
  }
 return pos;
}
#endif


XO *
xo_new(path)
  char *path;
{
  XO *xo;
  int len;

  len = strlen(path) + 1;

  xo = (XO *) malloc(sizeof(XO) + len);

  memcpy(xo->dir, path, len);

  return (xo);
}


XO *
xo_get(path)
  char *path;
{
  XO *xo;

  for (xo = xo_root; xo; xo = xo->nxt)
  {
    if (!strcmp(xo->dir, path))
      return xo;
  }

  xo = xo_new(path);
  xo->nxt = xo_root;
  xo_root = xo;
  xo->xyz = NULL;

  xo->pos = XO_TAIL;		/* ��һ�ν���ʱ�����α���������� */
 /* hightman.010412: first unread */
#ifdef HAVE_LOG_LBP
 xo->pos = lbp_get(xo->dir);
#endif

  return xo;
}


#if 0
void
xo_free(xo)
  XO *xo;
{
  char *ptr;

  if (ptr = xo->xyz)
    free(ptr);
  free(xo);
}
#endif


/* ----------------------------------------------------- */
/* interactive menu routines			 	 */
/* ----------------------------------------------------- */


char xo_pool[XO_TALL * XO_RSIZ];


void
xo_load(xo, recsiz)
  XO *xo;
  int recsiz;
{
  int fd, max;

  max = 0;
  if ((fd = open(xo->dir, O_RDONLY)) >= 0)
  {
    int pos, top;
    struct stat st;

    fstat(fd, &st);
    max = st.st_size / recsiz;
    if (max > 0)
    {
      pos = xo->pos;
      if (pos <= 0)
      {
	pos = top = 0;
      }
      else
      {
	top = max - 1;
	if (pos > top)
	  pos = top;
	top = (pos / XO_TALL) * XO_TALL;
      }
      xo->pos = pos;
      xo->top = top;

      lseek(fd, (off_t) (recsiz * top), SEEK_SET);
      read(fd, xo_pool, recsiz * XO_TALL);
    }
    close(fd);
  }

  xo->max = max;
}


/* static */
void inline
xo_fpath(fpath, dir, hdr)
  char *fpath;
  char *dir;
  HDR *hdr;
{
  if (hdr->xmode & HDR_URL)
    url_fpath(fpath, dir, hdr);
  else
    hdr_fpath(fpath, dir, hdr);
}


/* ----------------------------------------------------- */
/* nhead:						 */
/* 0 ==> ���� TagList ����ɾ��				 */
/* !0 ==> ���� range [nhead, ntail] ɾ��		 */
/* ----------------------------------------------------- */
/* notice : *.n - new file				 */
/* *.o - old file					 */
/* ----------------------------------------------------- */


int
hdr_prune(folder, nhead, ntail)
  char *folder;
  int nhead, ntail;
{
  int count, fdr, fsize, xmode, cancel, dmode;
  HDR *hdr;
  FILE *fpw;
  char fnew[80], fold[80];

  if ((fdr = open(folder, O_RDONLY)) < 0)
    return -1;

  if (!(fpw = f_new(folder, fnew)))
  {
    close(fdr);
    return -1;
  }

  xmode = *folder;
  cancel = (xmode == 'b');
  dmode = (xmode == 'u') ? 0 : (POST_CANCEL | POST_DELETE);

  fsize = count = 0;
  mgets(-1);
  while (hdr = mread(fdr, sizeof(HDR)))
  {
    xmode = hdr->xmode;
    count++;
    if (xmode & dmode)		/* ��ɾ�� */
	continue;

    if ((xmode & POST_MARKED) ||	/* ��� */
#ifdef HAVE_HOT_MODE
       (xmode & POST_HOT) ||  /* hot���²���Dɾ */
#endif
	(nhead && (count < nhead || count > ntail)) ||	/* range */
      (!nhead && Tagger(hdr->chrono, count - 1, TAG_NIN)))	/* TagList */
    {
      if ((fwrite(hdr, sizeof(HDR), 1, fpw) != 1))
      {
	close(fdr);
	fclose(fpw);
	unlink(fnew);
	return -1;
      }
      fsize++;
    }
    else
    {
      /* ��Ϊ��������߿��� */

      if (cancel)
	cancel_post(hdr);

      hdr_fpath(fold, folder, hdr);
      unlink(fold);
    }
  }
  close(fdr);
  fclose(fpw);

  sprintf(fold, "%s.o", folder);
  rename(folder, fold);
  if (fsize)
    rename(fnew, folder);
  else
    unlink(fnew);

  return 0;
}


int
xo_delete(xo)
  XO *xo;
{
  char buf[8];
  int head, tail;

  if ((bbsmode == M_READA) && !(bbstate & STAT_BOARD))
    return XO_NONE;

#ifdef HAVE_HOT_MODE
  if(xo->key == XZ_HOT)
  {
   zmsg("��������ժģʽ�������޷���ɡ������뿪");
   return XO_FOOT;
  }
#endif

#ifdef SECURE_SYSLOG	/* hightman: �߼���ȫ���� */
   if(!str_cmp(currboard, BRD_SYSLOG))
     return XO_NONE;
#endif     

  vget(b_lines, 0, "[�趨ɾ����Χ] ��㣺", buf, 6, DOECHO);
  head = atoi(buf);
  if (head <= 0)
  {
    zmsg("�������");
    return XO_FOOT;
  }

  vget(b_lines, 28, "�յ㣺", buf, 6, DOECHO);
  tail = atoi(buf);
  if (tail < head)
  {
    zmsg("�յ�����");
    return XO_FOOT;
  }

  if (vget(b_lines, 41, msg_sure_ny, buf, 3, LCECHO) == 'y')
  {
    /* delete_log(xo->dir, head, tail); */
    hdr_prune(xo->dir, head, tail);
    return XO_LOAD;
  }
  return XO_FOOT;
}

#if 0
/* log������������ô? :P hightman.010115 */
static void
delete_log(brd, head, tail)
  char *brd;
  int head;
  int tail;
{
  char buf[128];
  /* hightman: ��Dɾ����¼�ƺ�û������ */
  /* fuse: log������ */
  HDR hdr;
  char folder[128], fpath[128];
  int fd;
  FILE *fp;
  char board[] = "prune";
  char title[60];

  sprintf(folder, "brd/%s/.DIR", board);
  fd = hdr_stamp(folder, 'A', &hdr, fpath);
  if (fd < 0)
    return;

  sprintf(title, "[����ɾ����¼] %s (%s)", brd, cuser.userid);

  fp = fdopen(fd, "w");
  fprintf(fp, "����: SYSOP (����ʹ��)\n����: %s\nʱ��: %s\n",
    title, ctime(&hdr.chrono));

  sprintf(buf, "ɾ������ %d ---> %d \n", head, tail);
  fprintf(fp, buf);

  fclose(fp);
  close(fd);

  strcpy(hdr.title, title);
  strcpy(hdr.owner, "SYSOP");
  strcpy(hdr.nick, "����ʹ��");
  fd = open(folder, O_WRONLY | O_CREAT | O_APPEND, 0600);
  if (fd < 0)
  {
    unlink(fpath);
    return;
  }
  write(fd, &hdr, sizeof(HDR));
  close(fd);
}
#endif

/* ----------------------------------------------------- */
/* Tag List ��ǩ					 */
/* ----------------------------------------------------- */


int TagNum;			/* tag's number */
TagItem TagList[TAG_MAX];	/* ascending list */


int
Tagger(chrono, recno, op)
  time_t chrono;
  int recno;
  int op;			/* op : TAG_NIN / TOGGLE / INSERT */
/* ----------------------------------------------------- */
/* return 0 : not found	/ full				 */
/* 1 : add						 */
/* -1 : remove						 */
/* ----------------------------------------------------- */
{
  int head, tail, pos, cmp;
  TagItem *tagp;

  for (head = 0, tail = TagNum - 1, tagp = TagList, cmp = 1; head <= tail;)
  {
    pos = (head + tail) >> 1;
    cmp = tagp[pos].chrono - chrono;
    if (!cmp)
    {
      break;
    }
    else if (cmp < 0)
    {
      head = pos + 1;
    }
    else
    {
      tail = pos - 1;
    }
  }

  if (op == TAG_NIN)
  {
    if (!cmp && recno)		/* �����Ͻ����� recno һ��ȶ� */
      cmp = recno - tagp[pos].recno;
    return cmp;
  }

  tail = TagNum;

  if (!cmp)
  {
    if (op != TAG_TOGGLE)
      return NA;

    TagNum = --tail;
    memcpy(&tagp[pos], &tagp[pos + 1], (tail - pos) * sizeof(TagItem));
    return -1;
  }

  if (tail < TAG_MAX)
  {
    TagItem buf[TAG_MAX];

    TagNum = tail + 1;
    tail = (tail - head) * sizeof(TagItem);
    tagp += head;
    memcpy(buf, tagp, tail);
    tagp->chrono = chrono;
    tagp->recno = recno;
    memcpy(++tagp, buf, tail);
    return YEA;
  }

  /* TagList is full */

  bell();
  return 0;
}


void
EnumTagHdr(hdr, dir, locus)
  HDR *hdr;
  char *dir;
  int locus;
{
  rec_get(dir, hdr, sizeof(HDR), TagList[locus].recno);
}


int
AskTag(msg)
  char *msg;
/* ----------------------------------------------------- */
/* return value :					 */
/* -1	: ȡ��						 */
/* 0	: single article				 */
/* o.w.	: whole tag list				 */
/* ----------------------------------------------------- */
{
  char buf[80];
  /* Thor.990108: �²����� */
  /* char buf[100]; */
  int num;

  num = TagNum;
  sprintf(buf, "�� %s A)rticle T)ag Q)uit��[%c] ", msg, num ? 'T' : 'A');
  switch (vans(buf))
  {
  case 'q':
    return -1;

  case 'a':
    return 0;
  }
  return num;
}


/* ----------------------------------------------------- */
/* tag articles according to title / author		 */
/* ----------------------------------------------------- */


static int
xo_tag(xo, op)
  XO *xo;
  int op;
{
  int fsize, count;
  char *token, *fimage;
  HDR *head, *tail;

#ifdef SECURE_SYSLOG	/* hightman: �߼���ȫ���� */
  if(!str_cmp(currboard, BRD_SYSLOG))
   return XO_NONE;
#endif   

  fimage = f_map(xo->dir, &fsize);
  if (fimage == (char *) -1)
    return XO_NONE;

  head = (HDR *) xo_pool + (xo->pos - xo->top);
  if (op == Ctrl('A'))
  {
    token = head->owner;
    op = 0;
  }
  else
  {
    token = str_ttl(head->title);
    op = 1;
  }

  head = (HDR *) fimage;
  tail = (HDR *) (fimage + fsize);

  count = 0;

  do
  {
    if (!strcmp(token, op ? str_ttl(head->title) : head->owner))
    {
      if (!Tagger(head->chrono, count, TAG_INSERT))
	break;
    }
    count++;
  } while (++head < tail);

  munmap(fimage, fsize);
  return XO_BODY;
}


static int
xo_prune(xo)
  XO *xo;
{
  int num;
  char buf[80];

  if (!(num = TagNum) || ((bbsmode == M_READA) && !(bbstate & STAT_BOARD)))
    return XO_NONE;

#ifdef SECURE_SYSLOG	/* hightman: �߼���ȫ���� */
  if(!str_cmp(currboard, BRD_SYSLOG)) 
    return XO_NONE;
#endif    

  sprintf(buf, "ȷ��Ҫɾ�� %d ƪ��ǩ��(Y/N)��[N] ", num);
  if (vans(buf) != 'y')
    return XO_FOOT;

#if 1
  /* Thor.981122: ����ɾ����¼ */
  sprintf(buf,"(%d)%s",num, xo->dir);
  blog("PRUNE", buf);
#endif

  hdr_prune(xo->dir, 0, 0);

  TagNum = 0;
  return XO_LOAD;
}


/* ----------------------------------------------------- */
/* Tag's batch operation routines			 */
/* ----------------------------------------------------- */


extern BCACHE *bshm;    /* lkchu.981229 */


static int
xo_copy(xo)
  XO *xo;
{
  char fpath[128], *dir;
  HDR *hdr, xhdr;
  int tag, locus;
  FILE *fp;

  if (!cuser.userlevel)
    return XO_NONE;

#ifdef SECURE_SYSLOG	/* hightman: �߼���ȫ���� */
   if(!str_cmp(currboard, BRD_SYSLOG))
    return XO_NONE;
#endif

  /* lkchu.990428: mat patch ��������ĩѡ��������copy����ߵ����� */
  if (bbsmode == M_READA)
  {
    /* lkchu.981205: ���� tag ��ſ������� */
    tag = (bshm->bcache + brd_bno(currboard))->battr;
    if (!HAS_PERM(PERM_SYSOP) && (tag & BRD_NOFORWARD))
    {
      outz("�� �˰����²���ת��");
      return XO_NONE;
    } 
  }

  tag = AskTag("�������ݴ浵");
  if (tag < 0)
    return XO_FOOT;

  fp = tbf_open();
  if (fp == NULL)
    return XO_FOOT;

  if (tag)
    hdr = &xhdr;
  else
    hdr = (HDR *) xo_pool + xo->pos - xo->top;

  locus = 0;
  dir = xo->dir;

  do
  {
    if (tag)
    {
      fputs(STR_LINE, fp);
      EnumTagHdr(hdr, dir, locus++);
    }

    if (!(hdr->xmode & GEM_FOLDER))	/* �� hdr �Ƿ� plain text */
    {
      xo_fpath(fpath, dir, hdr);
      f_suck(fp, fpath);
    }
  } while (locus < tag);

  fclose(fp);
  zmsg("�������");

  return XO_FOOT;
}


#if 0
/* Thor.981027: �� mail.c�е� mail_externalȡ�� */
static inline int
rcpt_local(addr)
  char *addr;
{
  char *str;
  int cc;

  str = addr;
  while (cc = *str++)
  {
    if (cc == '@')
    {
      /* Thor.990125: MYHOSTNAME ͳһ���� str_host */
      if (str_cmp(str, str_host))
	return 0;
      str[-1] = '\0';
      if (str = strchr(addr, '.'))
	*str = '\0';
      break;
    }
  }
  return 1;
}
#endif


static inline int
deny_forward()
{
  usint level;

  /* Thor.980602: �뽫���ж�̬Ȩ�޵ĸı�ͳһ����login��, �о��Ƚϲ��� 
                  ͬʱ deny_mailϣ���ܵ�����Ϊ BAN mail������
                  ��ͳһ�� PERM_CHAT, PERM_PAGE, PERM_POST
                  �� �Զ������Ȩ��, ͳһ����, ���ֶ����Ȩ�޷ֱ� */

  level = cuser.userlevel;
  if ((level & (PERM_FORWARD | PERM_DENYMAIL)) != PERM_FORWARD)
  {
    if (level & PERM_DENYMAIL)
    {
      if ((cuser.numemail >> 4) < (cuser.numlogins + cuser.numposts))
      {
        cuser.userlevel = level ^ PERM_DENYMAIL;
	return 0;
      }
      outz("�� �����ع������£�����߾���ֵ����");
    }
    return -1;
  }
  return 0;
}


static int
xo_forward(xo)
  XO *xo;
{
  static char rcpt[64];
  char fpath[128], folder[80], *dir, *title, *userid;
  HDR *hdr, xhdr;
  int tag, locus, userno, cc;
  usint method;			/* �Ƿ� uuencode */

  if (deny_forward())
    return XO_NONE;

#ifdef SECURE_SYSLOG	/* hightman: �߼���ȫ���� */
   if(!str_cmp(currboard, BRD_SYSLOG))
    return XO_NONE;
#endif    

  /* lkchu.990428: mat patch ��������ĩѡ��������forward����ߵ����� */
  if (bbsmode == M_READA)
  {
    /* lkchu.981205: ���� method ��ſ������� */
    method = (bshm->bcache + brd_bno(currboard))->battr;
    if (!HAS_PERM(PERM_SYSOP) && (method & BRD_NOFORWARD))
    {
      outz("�� �˰����²���ת��");
      return XO_NONE;
    } 
  }
  
  tag = AskTag("ת��");
  if (tag < 0)
    return XO_FOOT;

  if (!rcpt[0])
    strcpy(rcpt, cuser.email);

  if (!vget(b_lines, 0, "Ŀ�ĵأ�", rcpt, sizeof(rcpt), GCARRY))
    return XO_FOOT;

  userid = cuser.userid;

  /* �ο� struct.h ֮ MQ_UUENCODE / MQ_JUSTIFY */

#define	MF_SELF	0x04
#define	MF_USER	0x08

  userno = 0;

#if 0
  if (rcpt_local(rcpt))    /* ��;���� */
  /* Thor.981027: �� mail.c�е� mail_external ȡ�� */
#endif
  if (!mail_external(rcpt))    /* ��;���� */
  {
    if (!str_cmp(rcpt, userid))
    {
      /* userno = cuser.userno; */ /* Thor.981027: �ľ�ѡ�����Լ���֪ͨ�Լ� */
      method = MF_SELF;
    }
    else
    {
      if ((userno = acct_userno(rcpt)) <= 0)
      {
	sprintf(fpath, "���޴��ˣ�%s", rcpt);
	zmsg(fpath);
	return XO_FOOT;
      }
      method = MF_USER;
    }

    usr_fpath(folder, rcpt, fn_dir);
  }
  else
  {
    if (not_addr(rcpt))
      return XO_FOOT;

    method = 0;

#if 0
    method = vans("�Ƿ���Ҫ uuencode(Y/N)��[N] ") == 'y' ?
      MQ_UUENCODE : 0;
#endif
  }

  hdr = tag ? &xhdr : (HDR *) xo_pool + xo->pos - xo->top;

  dir = xo->dir;
  title = hdr->title;
  locus = cc = 0;

  do
  {
    if (tag)
      EnumTagHdr(hdr, dir, locus++);

    if (!(hdr->xmode & GEM_FOLDER))	/* �� hdr �Ƿ� plain text */
    {
      xo_fpath(fpath, dir, hdr);

      if (method >= MF_SELF)
      {
	HDR mhdr;

	if ((cc = hdr_stamp(folder, HDR_LINK, &mhdr, fpath)) < 0)
	  break;

	if (method == MF_SELF)
	{
	  strcpy(mhdr.owner, "[�� ѡ ��]");
	  mhdr.xmode = MAIL_READ | MAIL_NOREPLY;
	}
	else
	{
	  strcpy(mhdr.owner, userid);
	}
	strcpy(mhdr.nick, cuser.username);
	strcpy(mhdr.title, title);
	if ((cc = rec_add(folder, &mhdr, sizeof(HDR))) < 0)
	  break;
      }
      else
      {
	/* if ((cc = bsmtp(fpath, title, rcpt, method)) < 0) */
#ifdef USE_SENDMAIL	
	cc = bbs_sendmail(fpath, title, rcpt, 0);
#else
	cc = bsmtp(fpath, title, rcpt, method);
#endif        
        if (cc < 0)
	  break;
      }
    }
  } while (locus < tag);

#undef	MF_SELF
#undef	MF_USER

  if (userno > 0)
    m_biff(userno);

  zmsg(cc < 0 ? "�����ż��޷��Ĵ�" : "�������");

  return XO_FOOT;
}


static void
z_download(fpath)
  char *fpath;
{
  static int num = 0;		/* ��ˮ�� */
  char buf[64];
  char zbuf[64];

  /* Thor.0728: �� refreshһ��, �ٿ����᲻�ᴫ */

  move(b_lines, 0);
  clrtoeol();
  refresh();
  move(b_lines, 0);
  outc('\n');
  refresh();

  sprintf(buf, "tmp/%.8s.%03d", cuser.userid, ++num);
  f_cp(fpath, buf, O_TRUNC);
  
#if 0	/* hightman: ����system() :P */
  if (pid = fork()&&pid!=1)
    waitpid(pid, &status, 0);
  else
  { 
#endif
    refresh();
    sprintf(zbuf,"/usr/bin/sz -a %s",buf);
    system(zbuf);
#if 0    
    execl("/usr/bin/sz", "-a", buf, NULL);
#endif    
    exit(1);
    refresh(); 
    sprintf(zbuf,"�������,����λ��C:/%.8s.%03d",cuser.userid,num);
    vmsg(zbuf);
#if 0    
  }
#endif
  unlink(buf);
}


static int
xo_zmodem(xo)
  XO *xo;
{
  char fpath[128], *dir;
  HDR *hdr, xhdr;
  int tag, locus;

  if (!HAS_PERM(PERM_FORWARD))
    return XO_NONE;

  tag = AskTag("Z-modem ����");
  if (tag < 0)
    return XO_FOOT;

  if (tag)
    hdr = &xhdr;
  else
    hdr = (HDR *) xo_pool + xo->pos - xo->top;

  locus = 0;
  dir = xo->dir;

  do
  {
    if (tag)
      EnumTagHdr(hdr, dir, locus++);

    if (!(hdr->xmode & GEM_FOLDER))	/* �� hdr �Ƿ� plain text */
    {
      xo_fpath(fpath, dir, hdr);
      z_download(fpath);
    }
  } while (locus < tag);

  return XO_HEAD;
}


/* ----------------------------------------------------- */
/* �������߲�ѯ��Ȩ���趨				 */
/* ----------------------------------------------------- */


int
xo_uquery(xo)
  XO *xo;
{
  HDR *hdr;
  char *userid;

  hdr = (HDR *) xo_pool + (xo->pos - xo->top);
  if (hdr->xmode & (GEM_GOPHER | POST_INCOME | MAIL_INCOME))
    return XO_NONE;

  userid = hdr->owner;
  if (strchr(userid, '.'))
    return XO_NONE;

  move(1, 0);
  clrtobot();
  move(2, 0);
  /* cpos = xo->pos;		/* chuan ���� xo->pos ��ֵ��֮��ش� */
  my_query(userid, 0);
  /* xo->pos = cpos; */
  return XO_HEAD;
}


int
xo_usetup(xo)
  XO *xo;
{
  HDR *hdr;
  char *userid;
  ACCT xuser;

  if (!HAVE_PERM(PERM_SYSOP | PERM_ACCOUNTS))
    return XO_NONE;

  hdr = (HDR *) xo_pool + (xo->pos - xo->top);
  userid = hdr->owner;
  if (strchr(userid, '.') || (acct_load(&xuser, userid) < 0))
    return XO_NONE;

  move(3, 0);
  acct_setup(&xuser, 1);
  return XO_HEAD;
}


/* ----------------------------------------------------- */
/* ����ʽ�Ķ�						 */
/* ----------------------------------------------------- */


#define RS_TITLE        0x001	/* author/title */
#define RS_FORWARD      0x002	/* backward */
#define RS_RELATED      0x004
#define RS_FIRST        0x008	/* find first article */
#define RS_CURRENT      0x010	/* match current read article */
#define RS_THREAD	0x020	/* search the first article */
#define RS_SEQUENT	0x040	/* sequential read */
#define RS_MARKED 	0x080	/* marked article */
#define RS_UNREAD 	0x100	/* unread article */

#define CURSOR_FIRST	(RS_RELATED | RS_TITLE | RS_FIRST)
#define CURSOR_NEXT	(RS_RELATED | RS_TITLE | RS_FORWARD)
#define CURSOR_PREV	(RS_RELATED | RS_TITLE)
#define RELATE_FIRST	(RS_RELATED | RS_TITLE | RS_FIRST | RS_CURRENT)
#define RELATE_NEXT	(RS_RELATED | RS_TITLE | RS_FORWARD | RS_CURRENT)
#define RELATE_PREV	(RS_RELATED | RS_TITLE | RS_CURRENT)
#define THREAD_NEXT	(RS_THREAD | RS_FORWARD)
#define THREAD_PREV	(RS_THREAD)

/* Thor: ǰ����mark����, ����֪����ʲ������δ���� */

#define MARK_NEXT	(RS_MARKED | RS_FORWARD | RS_CURRENT)
#define MARK_PREV	(RS_MARKED | RS_CURRENT)


typedef struct
{
  int key;			/* key stroke */
  int map;			/* the mapped threading op-code */
}      KeyMap;


static KeyMap keymap[] =
{
  /* search title / author */

  '/', RS_TITLE | RS_FORWARD,
  '?', RS_TITLE,
  'a', RS_FORWARD,
  'A', 0,

  /* thread : currtitle */

  '[', RS_RELATED | RS_TITLE | RS_CURRENT,
  ']', RS_RELATED | RS_TITLE | RS_FORWARD | RS_CURRENT,
  '=', RS_RELATED | RS_TITLE | RS_FIRST | RS_CURRENT,

  /* i.e. < > : make life easier */

  ',', RS_THREAD,
  '.', RS_THREAD | RS_FORWARD,

  /* thread : cursor */

  '-', RS_RELATED | RS_TITLE,
  '+', RS_RELATED | RS_TITLE | RS_FORWARD,
  '\\', RS_RELATED | RS_TITLE | RS_FIRST,

  /* Thor: marked : cursor */
  '\'', RS_MARKED | RS_FORWARD | RS_CURRENT,
  ';', RS_MARKED | RS_CURRENT,

  /* Thor: ��ǰ�ҵ�һƪδ�������� */
  /* Thor.980909: ��ǰ����ƪδ��, ��ĩƪ�Ѷ� */
  '`', RS_UNREAD /* | RS_FIRST */,

  /* sequential */

  ' ', RS_SEQUENT | RS_FORWARD,
  KEY_RIGHT, RS_SEQUENT | RS_FORWARD,
  KEY_PGDN, RS_SEQUENT | RS_FORWARD,
  KEY_DOWN, RS_SEQUENT | RS_FORWARD,
  /* Thor.990208: Ϊ�˷��㿴���¹�����, ������ƪ, ��Ȼ�ϲ㱻xover�Ե���:p */
  'j', RS_SEQUENT | RS_FORWARD,

  KEY_UP, RS_SEQUENT,
  KEY_PGUP, RS_SEQUENT,
  /* Thor.990208: Ϊ�˷��㿴���¹�����, ������ƪ, ��Ȼ�ϲ㱻xover�Ե���:p */
  'k', RS_SEQUENT,

  /* end of keymap */

  (char) NULL, -1
};


static int
xo_keymap(key)
  int key;
{
  KeyMap *km;
  int ch;

  km = keymap;
  while (ch = km->key)
  {
    if (ch == key)
      break;
    km++;
  }
  return km->map;
}


static int
xo_thread(xo, op)
  XO *xo;
  int op;
{
  static char s_author[16], s_title[32], s_unread[2]="0";
  char buf[80];

  char *tag, *query, *title;
  int pos, match, near, neartop, max;	/* Thor: neartop��near�ɶ��� */

  int fd, top, bottom, step, len;
  HDR *pool, *fhdr;

  match = XO_NONE;
  pos = xo->pos;
  top = xo->top;
  pool = (HDR *) xo_pool;
  fhdr = pool + (pos - top);
  step = (op & RS_FORWARD) - 1;

  if (op & RS_RELATED)
  {
    tag = fhdr->title;

    if (op & RS_CURRENT)
    {
      query = currtitle;
      if (op & RS_FIRST)
      {
	if (!strcmp(query, tag))/* Ŀǰ�ľ��ǵ�һ���� */
	  return XO_NONE;
	near = -1;
      }
    }
    else
    {
      title = str_ttl(tag);
      if (op & RS_FIRST)
      {
	if (title == tag)
	  return XO_NONE;
	near = -1;
      }
      query = buf;
      strcpy(query, title);
    }
  }
  else if (op & RS_UNREAD)	/* Thor: ��ǰ��Ѱ��һƪδ������,�� near */
  {
#define	RS_BOARD	0x1000	/* ��� RS_UNREAD����ǰ��Ĳ����ص� */
    /* Thor.980909: ѯ�� "��ƪδ��" �� "ĩƪ�Ѷ�" */
    if (!vget(b_lines, 0, "��ǰ��Ѱ 0)��ƪδ�� 1)ĩƪ�Ѷ� ", s_unread, sizeof(s_unread), GCARRY))
      return XO_FOOT; /* Thor.980911: �ҵ�ʱ, ��û��XO_FOOT, �ٿ�������� */

    if (*s_unread == '0') 
      op |= RS_FIRST;  /* Thor.980909: ��ǰ��Ѱ��ƪδ�� */

    near = xo->dir[0];
    if (near == 'b')		/* search board */
      op |= RS_BOARD;
    else if (near != 'u')	/* search user's mbox */
      return XO_NONE;

    near = -1;
  }
  else if (!(op & (RS_THREAD | RS_SEQUENT | RS_MARKED)))
  {
    if (op & RS_TITLE)
    {
      title = "����";
      tag = s_title;
      len = sizeof(s_title);
    }
    else
    {
      title = "����";
      tag = s_author;
      len = sizeof(s_author);
    }
    query = buf;
    sprintf(query, "��Ѱ%s(%s)��", title, (step > 0) ? "��" : "��");
    if (!vget(b_lines, 0, query, tag, len, GCARRY))
      return XO_FOOT;
    /* Thor.980911: Ҫע��, ���û�ҵ�, "��Ѱ"��ѶϢ�ᱻ��,
                    ����ҵ���, ��û����, �򴫻�ֵΪmatch, û���� XO_FOOT */

    str_lower(query, tag);
  }

  fd = -1;
  len = sizeof(HDR) * XO_TALL;
  bottom = top + XO_TALL;
  max = xo->max;
  if (bottom > max)
    bottom = max;

  for (;;)
  {
    if (step > 0)
    {
      if (++pos >= max)
	break;
    }
    else
    {
      if (--pos < 0)
	break;
    }

    /* buffer I/O : shift sliding window scope */

    if ((pos < top) || (pos >= bottom))
    {
      if (fd < 0)
      {
	fd = open(xo->dir, O_RDONLY);
	if (fd < 0)
	  return XO_QUIT;
      }

      if (step > 0)
      {
	top += XO_TALL;
	bottom = top + XO_TALL;
	if (bottom > max)
	  bottom = max;
      }
      else
      {
	bottom = top;
	top -= XO_TALL;
      }

      lseek(fd, (off_t) (sizeof(HDR) * top), SEEK_SET);
      read(fd, pool, len);

      fhdr = (step > 0) ? pool : pool + XO_TALL - 1;
    }
    else
    {
      fhdr += step;
    }

    /* ������ɾ������ */

    if (fhdr->xmode & (POST_CANCEL | POST_DELETE))
      continue;

    if (op & RS_SEQUENT)
    {
      match = -1;
      break;
    }

    /* Thor: ǰ�� search marked ���� */

    if (op & RS_MARKED)
    {
      if (fhdr->xmode & (POST_MARKED /* | POST_GEM */))
      {
	match = -1;
	break;
      }
      continue;
    }

    /* ��ǰ��Ѱ��һƪδ������ */

    if (op & RS_UNREAD)
    {
      /* Thor.980909: ��ƪδ��(RS_FIRST) �� ĩƪ�Ѷ�(!RS_FIRST) */
      if (op & RS_BOARD)
      {
        /* if (!brh_unread(fhdr->chrono)) */
        if (!(op & RS_FIRST) ^ !brh_unread(fhdr->chrono))
   	  continue;
      }
      else
      {
  	/* if ((fhdr->xmode & MAIL_READ) */
  	if (!(op & RS_FIRST) == !(fhdr->xmode & MAIL_READ))
	  continue;
      }

#undef	RS_BOARD
      /* Thor.980909: ĩƪ�Ѷ�(!RS_FIRST) */
      if (!(op & RS_FIRST))
      {
        match = -1;
        break;
      }

	near = pos;		/* Thor:������ӽ�����λ�� */
	neartop = top;
      continue;
    }

    /* ------------------------------------------------- */
    /* ������Ѱ title / author				 */
    /* ------------------------------------------------- */

    if (op & (RS_TITLE | RS_THREAD))
    {
      title = fhdr->title;	/* title ָ�� [title] field */
      tag = str_ttl(title);	/* tag ָ�� thread's subject */

      if (op & RS_THREAD)
      {
	if (tag == title)
	{
	  match = -1;
	  break;
	}
	continue;
      }
    }
    else
    {
      tag = fhdr->owner;	/* tag ָ�� [owner] field */
    }

    if (((op & RS_RELATED) && !strncmp(tag, query, 40)) ||
      (!(op & RS_RELATED) && str_str(tag, query)))
    {
      if (op & RS_FIRST)
      {
	if (tag != title)
	{
	  near = pos;		/* ������ӽ�����λ�� */
	  neartop = top;
	  continue;
	}
      }

#if 0
      if ((!(op & RS_CURRENT)) && (op & RS_RELATED) &&
	strncmp(currtitle, query, TTLEN))
      {
	str_ncpy(currtitle, query, TTLEN);
	match = XO_BODY;
      }
      else
#endif

	match = -1;
      break;
    }
  }

  bottom = xo->top;

  if (match < 0)
  {
    xo->pos = pos;
    if (bottom != top)
    {
      xo->top = top;
      match = XO_BODY;		/* �ҵ��ˣ�������Ҫ���»��� */
    }
  }				/* Thor: ���� RS_FIRST���� */
  else if ((op & RS_FIRST) && near >= 0)
  {
    xo->pos = near;
    if (top != neartop)		/* Thor.0609: top ΪĿǰ��buffer֮top */
    {
      lseek(fd, (off_t) (sizeof(HDR) * neartop), SEEK_SET);
      read(fd, pool, len);
    }
    if (bottom != neartop)	/* Thor.0609: bottomΪ����֮top */
    {
      xo->top = neartop;
      match = XO_BODY;		/* �ҵ��ˣ�������Ҫ���»��� */
    }
    else
      match = -1;
  }
  else if (bottom != top)
  {
    lseek(fd, (off_t) (sizeof(HDR) * bottom), SEEK_SET);
    read(fd, pool, len);
  }

  if (fd >= 0)
    close(fd);

  return match;
}


/* Thor.990204: Ϊ����more ����ֵ, �Ա㿴һ������� []... 
                ch Ϊ��ǰmore()��������key */   
int
xo_getch(xo, ch)
  XO *xo;
  int ch;
{
  int op;

  if (!ch)
    ch = vkey();

  op = xo_keymap(ch);
  if (op >= 0)
  {
    ch = xo_thread(xo, op);
    if (ch != XO_NONE)
      ch = XO_BODY;		/* ������� */
  }

#if 0
  else
  {
    if (ch == KEY_LEFT || ch == 'Q')
      ch = 'q';
  }
#endif

  return ch;
}


static int
xo_jump(pos)			/* �ƶ��α굽 number ���ڵ��ض�λ�� */
  int pos;
{
  char buf[6];

  buf[0] = pos;
  buf[1] = '\0';
  vget(b_lines, 0, "�����ڼ��", buf, sizeof(buf), GCARRY);
  move(b_lines, 0);
  clrtoeol();
  pos = atoi(buf);
  if (pos >= 0)
    return XO_MOVE + pos - 1;
  return XO_NONE;
}


/* ----------------------------------------------------- */
/* ----------------------------------------------------- */

#ifdef XZ_XPOST
/* Thor.990303: ����� XZ_XPOST�Ļ� */
extern KeyFunc xpost_cb[];
#endif
extern KeyFunc post_cb[];


XZ xz[] =
{
  {NULL, NULL, M_BOARD},	/* XZ_CLASS */
  {NULL, NULL, M_LUSERS},	/* XZ_ULIST */
  {NULL, NULL, M_PAL},		/* XZ_PAL */
  {NULL, NULL, M_VOTE},		/* XZ_VOTE */
  {NULL, NULL, M_BMW},          /* XZ_BMW */    /* lkchu.981230: BMW �½��� */
  {NULL, NULL, M_XMODE},        /* XZ_OTHER hightmna: ����������ʽ�б� */
#ifdef XZ_XPOST /* Thor.990303: ����� XZ_XPOST�Ļ� */
  {NULL, xpost_cb, M_READA},	/* XZ_XPOST */
#else
  {NULL, NULL, M_READA},	/* skip XZ_XPOST */
#endif
  {NULL, NULL, M_RMAIL},	/* XZ_MBOX */
  {NULL, post_cb, M_READA},	/* XZ_POST */
  {NULL, NULL, M_GEM},          /* XZ_GEM */
#ifdef HAVE_HOT_MODE
  {NULL, NULL, M_HOTMODE},	/* XZ_HOT */
#else
  {NULL, NULL, M_XMODE},	/* skip XZ_HOT */
#endif
  {NULL, NULL, M_XMODE}		/* XZ_XOTHER hightman: ��������ʽ�б� */
};


/* ----------------------------------------------------- */
/* interactive menu routines			 	 */
/* ----------------------------------------------------- */


void
xover(cmd)
  int cmd;
{
  int pos;
  int num;
  int zone;

  int sysmode;
  XO *xo;
  KeyFunc *xcmd;
  KeyFunc *cb;

#if 1
  /* Thor.0613: ����ѶϢ */
  static int msg = 0;
#endif

  for (;;)
  {
    while (cmd != XO_NONE)
    {
      if (cmd == XO_FOOT)
      {
	move(b_lines, 0);
	clrtoeol();

	/* Thor.0613: ����ѶϢ��� */
	msg = 0;

	break;
      }

      if (cmd >= XO_ZONE)
      {
	/* --------------------------------------------- */
	/* switch zone					 */
	/* --------------------------------------------- */

#if 0
	if (cmd & XZ_BACK)
	{
	}
#endif

	zone = cmd;
	cmd -= XO_ZONE;
	xo = xz[cmd].xo;
	xcmd = xz[cmd].cb;
	sysmode = xz[cmd].mode;

	TagNum = 0;		/* clear TagList */
	cmd = XO_INIT;
	utmp_mode(sysmode);
      }
      else if (cmd >= XO_MOVE - XO_TALL)
      {
	/* --------------------------------------------- */
	/* calc cursor pos and show cursor correctly	 */
	/* --------------------------------------------- */

	/* cmd >= XO_MOVE - XO_TALL so ... :chuan: ���� cmd = -1 ?? */

	/* fix cursor's range */

	num = xo->max - 1;
	pos = (cmd | XO_WRAP) - (XO_MOVE + XO_WRAP);
	cmd &= XO_WRAP;

	if (pos < 0)
	{
	  pos = cmd ? num : 0;
	  /* pos = 0; :chuan: */
	}
	else if (pos > num)
	{
	  pos = cmd ? 0 : num;
	  /* pos = num; :chuan: */
	}

	/* check cursor's range */

	cmd = xo->pos;

	if (cmd == pos)
	  break;

	xo->pos = pos;
	num = xo->top;
	if ((pos < num) || (pos >= num + XO_TALL))
	{
	  xo->top = (pos / XO_TALL) * XO_TALL;
	  cmd = XO_LOAD;	/* �������ϲ�������ʾ */
	}
	else
	{

#if 0
	  cursor_clear(3 + cmd - num, 0);
#endif

	  move(3 + cmd - num, 0);
	  outc(' ');

	  break;		/* ֻ�ƶ��α� */
	}
      }

      /* ----------------------------------------------- */
      /* ִ�� call-back routines			 */
      /* ----------------------------------------------- */

      cb = xcmd;
      num = cmd | XO_DL; /* Thor.990220: for dynamic load */
      for (;;)
      {
	pos = cb->key;
#if 1
        /* Thor.990220: dynamic load , with key | XO_DL */
        if (pos == num)
        {
          void *p = DL_get((char *) cb->func);
          if(p) 
          {
            cb->func = p;
            pos = cb->key = cmd;
          }
          else
          {
            cmd = XO_NONE;
            break;
          }
        }
#endif
	if (pos == cmd)
	{
	  cmd = (*(cb->func)) (xo);

	  if (cmd == XO_QUIT)
	    return;

	  break;
	}
	if (pos == 'h')
	  break;

	cb++;
      }

      if (pos == 'h')
	break;

#if 1
      if (pos >= XO_INIT && pos <= XO_BODY)
      {
	if (xo->top + XO_TALL == xo->max)
	{
	  outz("\033[44m �����ҿ������! ^O^ \033[m");	/* Thor.0616 */
	  msg = 1;
	}
	else if (msg)
	{
	  move(b_lines, 0);
	  clrtoeol();
	  msg = 0;
	}
      }
#endif

    } /* Thor.990220:ע��: end of while(cmd!=XO_NONE) */

    utmp_mode(sysmode); 
    /* Thor.990220:ע��:�����ظ� event handle routine �������ģʽ */

    pos = xo->pos;

    if (xo->max > 0)		/* Thor:�����޶����Ͳ�show�� */
    {
      num = 3 + pos - xo->top;

#if 0
      cursor_show(num, 0);
#endif

      move(num, 0);
      outc('>');
    }

    cmd = vkey();

    /* ------------------------------------------------- */
    /* switch Zone					 */
    /* ------------------------------------------------- */
    if (cmd == Ctrl('Z'))
    {
#if 0
      /* switch (vans(MSG_ZONE_SWITCH)) */
      /* Thor.980921: ��һ�������� */
      outz(MSG_ZONE_SWITCH);
      switch(vkey())
      {
      case 'a':
	cmd = XZ_GEM;
	break;

      case 'b':
	if (xz[XZ_POST - XO_ZONE].xo)
	{
	  cmd = XZ_POST;
	  break;
	}

      case 'c':
	cmd = XZ_CLASS;
	break;

#if 0
      case 'f':
	cmd = XZ_PAL;
	break;
#endif

      case 'm':
        /* Thor.981022: ����û����Ȩ�Ľ����� */
	if (HAS_PERM(PERM_BASIC) /*cuser.userlevel*/)
	  cmd = XZ_MBOX;
	else
	  cmd = zone;
	break;

      case 'u':
	cmd = XZ_ULIST;
	break;

#if 1
      /* lkchu.981230: ���� xover ���� bmw */
      case 'w':
        cmd = XZ_BMW;
        break;
#endif

      default:
	cmd = XO_FOOT;
	continue;
      }

      if (zone == cmd)		/* ��ԭ����һ�� */
      {
	cmd = XO_FOOT;
      }

#if 0
      else if (num & XZ_POST)	/* ������ */
      {
	post_xo = xo;
      }
      else if (num & XZ_GEM)	/* Thor: �� caller maintain, ����� */
      {
	gem_xo = xo;
      }
#endif
#endif
     every_Z();    /* hightman.010725: ��Every_zͳһ */
    }
    /* ------------------------------------------------- */
    /* �������α��ƶ� routines				 */
    /* ------------------------------------------------- */

    else if (cmd == KEY_LEFT || cmd == 'q')
    {
      /* cmd = XO_LAST; *//* try to load the last XO in future */
      return;
    }
    else if (xo->max <= 0)	/* Thor: �޶������޷����α� */
    {
      continue;
    }
    else if (cmd == KEY_UP || cmd == 'p' || cmd == 'k')
    {
      cmd = pos - 1 + XO_MOVE + XO_WRAP;
    }
    else if (cmd == KEY_DOWN || cmd == 'n' || cmd == 'j')
    {
      cmd = pos + 1 + XO_MOVE + XO_WRAP;
    }
    else if (cmd == ' ' || cmd == KEY_PGDN || cmd == 'N' || cmd == Ctrl('F'))
    {				       /* lkchu.990428: ������ʱ������Դ���� */
      cmd = pos + XO_MOVE + XO_TALL;
    }
    else if (cmd == KEY_PGUP || cmd == 'P' || cmd == Ctrl('B'))
    {
      cmd = pos + XO_MOVE - XO_TALL;
    }
    else if (cmd == KEY_HOME || cmd == '0')
    {
      cmd = XO_MOVE;
    }
    else if (cmd == KEY_END || cmd == '$')
    {
      /* cmd = xo->max + XO_MOVE; */
      cmd = XO_MOVE + XO_WRAP - 1;	/* force re-load */
    }
    else if (cmd >= '1' && cmd <= '9')
    {
      cmd = xo_jump(cmd);
    }
    else
    {
      /* ----------------------------------------------- */
      /* keyboard mapping				 */
      /* ----------------------------------------------- */

      if (cmd == KEY_RIGHT || cmd == '\n')
      {
	cmd = 'r';
      }
#ifdef XZ_XPOST
      else if (zone >= XZ_XPOST /* XZ_MBOX */ )
#else
      else if (zone >= XZ_MBOX )
#endif
      {
	/* --------------------------------------------- */
	/* Tag						 */
	/* --------------------------------------------- */

	if (cmd == 'C')
	{
	  cmd = xo_copy(xo);
	}
	else if (cmd == 'F')
	{
	  cmd = xo_forward(xo);
	}
	else if (cmd == 'Z')
	{
	  cmd = xo_zmodem(xo);
	}
	else if (cmd == Ctrl('C'))
	{
	  extern int TagNum;

	  if (TagNum)
	  {
	    TagNum = 0;
	    cmd = XO_BODY;
	  }
	  else
	    cmd = XO_NONE;
	}
	else if (cmd == Ctrl('A') || cmd == Ctrl('T'))
	{
	  cmd = xo_tag(xo, cmd);
	}
	else if (cmd == Ctrl('D') && zone < XZ_GEM)
	{
	  /* ������Ҫ��һɾ��, �Ա����� */

	  cmd = xo_prune(xo);
	}
	else if (cmd == 'g' && (bbstate & STAT_BOARD))
	{ /* Thor.980806: Ҫע��û������(δ������)ʱ, bbstate��û��STAT_BOARD
                          վ�����޷���¼���� */
	  cmd = gem_gather(xo);		/* ��¼���µ������� */
	}

	/* --------------------------------------------- */
	/* ����ʽ�Ķ�					 */
	/* --------------------------------------------- */

#ifdef XZ_XPOST
        if (zone == XZ_XPOST)
	  continue;
#endif

	pos = xo_keymap(cmd);
	if (pos >= 0)
	{
	  cmd = xo_thread(xo, pos);

#if 1
	  if (cmd == XO_NONE)
	  {			/* Thor.0612: ��û�л��� �Ѿ�����,�α겻�붯 */
	    outz("\033[44m ��û����Ү...:( \033[m");
	    msg = 1;
	  }
	  else if (msg)
	  {
	    move(b_lines, 0);
	    clrtoeol();
	    msg = 0;
	  }
#endif

	  if (cmd < 0)
	  {

#if 0
	    cursor_clear(num, 0);
#endif

	    move(num, 0);
	    outc(' ');
	    cmd = XO_NONE;
	  }
	}
      }

      /* ----------------------------------------------- */
      /* �����Ľ��� call-back routine ȥ����		 */
      /* ----------------------------------------------- */

    } /* Thor.990220:ע��: end of vkey() handling */
  }
}


/* ----------------------------------------------------- */
/* Thor.0725: ctrl Z everywhere				 */
/* ----------------------------------------------------- */


#ifdef	EVERY_Z

void
every_Z()
{
  int cmd, tmpmode;
  screenline sl[b_lines + 1];
  static int z_status = 0;


  /* gslin.000115: ��� every_Z 5�� */
  if (z_status >= 5)
    return;
  else
    z_status++; 

  save_foot(sl);
  cmd = 0;

  /* switch (vans(MSG_ZONE_SWITCH)) */
  /* Thor.980921: ��һ�������� */
  outz(MSG_ZONE_SWITCH);
  switch(vkey())
  {
  case 'a':
    cmd = XZ_GEM;
    break;

  case 'b':
    if (xz[XZ_POST - XO_ZONE].xo)
    {
      cmd = XZ_POST;
      break;
    }

  case 'c':
    cmd = XZ_CLASS;
    break;

  case 'm':
    /* Thor.981022: ����û����Ȩ�Ľ����� */
    if (HAS_PERM(PERM_BASIC) /*cuser.userlevel*/)
      cmd = XZ_MBOX;
    break;

  case 'u':
    cmd = XZ_ULIST;
    break;

#if 1
  /* lkchu.981230: ���� xover ���� bmw */
  case 'w':
    cmd = XZ_BMW;
    break;
#endif

#ifdef HAVE_GROUP_FUNC
  /* hightman.010725: ����everyZ����Ⱥ�� */
  case 'd':
    cmd = XZ_OTHER;
    break;         
#endif 

  default:
    break;
  }

  restore_foot(sl);

  if (cmd)
  {
    tmpmode = bbsmode;
    vs_save(sl);
    xover(cmd);
    vs_restore(sl);
    utmp_mode(tmpmode);
  }
   z_status--; /* hightman: ��ֹ̫��� */
}
#endif
