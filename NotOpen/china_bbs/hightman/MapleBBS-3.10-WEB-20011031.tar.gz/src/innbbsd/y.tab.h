typedef union {
    time_t		Number;
    enum _MERIDIAN	Meridian;
} YYSTYPE;
#define	tDAY	258
#define	tDAYZONE	259
#define	tMERIDIAN	260
#define	tMONTH	261
#define	tMONTH_UNIT	262
#define	tSEC_UNIT	263
#define	tSNUMBER	264
#define	tUNUMBER	265
#define	tZONE	266


extern YYSTYPE yylval;
