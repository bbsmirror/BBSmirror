/* ----------------------------------------------------- */
/* nhead:						 */
/* 0 ==> ���� TagList ����ɾ��				 */
/* !0 ==> ���� range [nhead, ntail] ɾ��		 */
/* ----------------------------------------------------- */
/* notice : *.n - new file				 */
/* *.o - old file				 */
/* ----------------------------------------------------- */


#include "dao.h"


int
hdr_prune(fpath, nhead, ntail)
  char *fpath;
  int nhead, ntail;
{
  HDR hdr;
  char fnew[80], fold[80];
  int count, fsize, xmode, cancel, dmode;
  FILE *fpr, *fpw;

  if (!(fpr = fopen(fpath, "r")))
    return -1;

  if (!(fpw = f_new(fpath, fnew)))
  {
    fclose(fpr);
    return -1;
  }

  xmode = *fpath;
  cancel = (xmode == 'b');
  dmode = (xmode == 'u') ? 0 : (POST_CANCEL | POST_DELETE);

  fsize = count = 0;
  while (fread(&hdr, sizeof(HDR), 1, fpr) == 1)
  {
    count++;
    xmode = hdr.xmode;
    if (xmode & dmode)		/* && *//* ��ɾ�� */
    {				/* Thor.0616: Ҫɾ�����ȿ�����˵,
				 * ����ܳ�cancel message */
      hdr_fpath(fold, fpath, &hdr);
      unlink(fold);
    }
    else if			/* δɾ�� */
	((xmode & POST_MARKED) ||	/* ��� */
	(nhead && (count < nhead || count > ntail)) ||	/* range */
      (!nhead && Tagger(hdr.chrono, count - 1, TAG_NIN)))	/* TagList */
    {
      if ((fwrite(&hdr, sizeof(HDR), 1, fpw) != 1))
      {
	fclose(fpw);
	unlink(fnew);
	fclose(fpr);
	return -1;
      }
      fsize++;
    }
    else
    {
      /* ��Ϊ��������߿��� */

      if (cancel)
	cancel_post(&hdr);

      hdr_fpath(fold, fpath, &hdr);
      unlink(fold);
    }
  }
  fclose(fpr);
  fclose(fpw);

  sprintf(fold, "%s.o", fpath);
  rename(fpath, fold);
  if (fsize)
    rename(fnew, fpath);
  else
    unlink(fnew);

  return 0;
}
