#include "bbs.h"

#ifdef HAVE_TTY_GAME
int
tetris()
{
  char buf[123];
  clear();
  utmp_mode(M_TETRIS);

  if(!(cutmp->ufo & UFO_EXEC))
  {
       cutmp->ufo ^= UFO_EXEC;
  }

  sprintf(buf,"bin/tetris %s %s",cuser.userid,fromhost);
  system(buf);
  cutmp->ufo ^= UFO_EXEC;
  return;
}
#endif	/* _HAVE_TTY_GAME_ */
