/*------------------------------------------------*/
/* chess.c      ( NTHU CS MapleBBS Ver 3.10 )     */
/*------------------------------------------------*/
/* target: ����,����                              */
/* author: weichung.bbs@bbs.ntit.edu.tw           */
/* update: 2000/05/02                             */
/* ���� M3 �� bwboard.c ֮д��                    */
/*------------------------------------------------*/

#include "bbs.h"

#ifdef HAVE_CHESS

#define MSG_BAR "\033[34;46m [%s\033[34m][%s] \033[31;47m TAB:\033[30m\
�л�����/���� \033[31;47m m:\033[30m��,�ƶ� \033[31mCtrl-S:\033[30m\
���� \033[31mCtrl-N:\033[30m���� \033[31mCtrl-C:\033[30m�뿪 \033[m"
#define MSG_BAR2 "\033[34;46m [%s]   \033[31;47m Ctrl-J:\033[30m\
����/���������� \033[m"
#ifdef EVERY_Z
extern int vio_fd, holdon_fd;
#endif
#ifdef CHESS_LOG
FILE *lfp;
char log_path[64];
#endif
extern char lastcmd[MAXLASTCMD][80];
static int cfd;
static int Rule;        /* ��������ʲ����: 0->����  1->���� */
static int Row, Col;
static int TotalStep;
static int msgline;
static int GameOver;
static int myColor;
static int Totalch; /* ������ :p */
static int Focus;
static int youreat_index;
static int myeat_index;
static int savemode;        /* �Ƿ񴢴����� */
static int Board[19][17];
static int MyEat[16], YourEat[16];
static int Appear[14];
static int key_win;
static int key_lose;
static int cmdCol, cmdPos;
static char talkBuf[42] = "T";
static char *cmdBuf = &talkBuf[1];
char *ruleStr[] = {"����", "����"};
char *icon[] = {"��", "��", "˧", "��", "��", "��", "��", "��", "��",
                "��", "ʿ", "��", "��", "��", "��", "��"};
char *color[] = {"\033[31m��", "\033[30m��"};
enum{DISCONNECT=-2, LEAVE=-1, NOTHING=0};
enum{Deny=-1, Empty=0, Cover=1};
enum{Red=0, Black=1};
static KeyFunc *mapTurn, *mapTalk;
extern KeyFunc Talk[], myTurn[], yourTurn[];
static char *
ch_brdline(int row)
{
  char *t, *str;
  static char buf[256];
  static char river[] = "\033[0;30;43m��\033[0;30m��      ��          ��\
      ��\033[0;30;43m��  \033[m";
  static char side[] = " A B C D E F G H I J ";
  int i;
  str = buf;
  *str = '\0';
  for(i = 0; i < 17; i++)
  {
    t = icon[Board[row][i]];
    if((Board[row][i] == Empty) || (Board[row][i] == Deny))
    {
      strcpy(str, "\033[0;30;43m");
      //str += 8;
        str += 10;
      if(row == 0)
      {
        if(i == 0)
          t = "��";
        else if(i == 16)
          t = "��";
        else if(i%2)
          t = "��";
        else
          t = "��";
      }
      else if(row == 18)
      {
        if(i == 0)
          t = "��";
        else if(i == 16)
          t = "��";
        else if(i%2)
          t = "��";
        else
          t = "��";
      }
      else if(row == 9)
      {
        strcpy(buf, river);
        return buf;
      }
      else if(row%2)
      {
        if(i%2)
          t = "  ";
        else
          t = "��";
      }
      else
      {
        if(i == 0)
          t = "��";
        else if(i == 16)
          t = "��";
        else if(i%2)
          t = "��";
        else
          t = "��";
      }
    }
    else
    {
      if(Board[row][i] == Cover)
      {
        strcpy(str, "\033[0;35;43m");
        //str += 8;
        str += 10;
      }
      else if((Board[row][i] > Cover) && (Board[row][i] < 9))
      {
        if(Focus && ((Focus%1000)/19 == row) && ((Focus%1000)%19 == i))
          strcpy(str, "\033[0;31;47m");
        else
      strcpy(str, "\033[0;31;43m");
        str += 10;
        //str += 8;
      }
      else
      {
    if(Focus && ((Focus%1000)/19 == row) && ((Focus%1000)%19 == i))
      strcpy(str, "\033[0;34;47m");
    else
          strcpy(str, "\033[0;34;43m");
    //str += 8;
     str += 10;
      }
    }
    strcpy(str, t);
    str += 2;
  } /* for loop */
  if(row != 9)
  {
    if(Rule)
    {
      if(row%2 == 1)
      {
        i = row/2;
        strcpy(str, "\033[0;30;43m");
        //str += 8;
         str += 10;
        strncpy(str, side+i*2, 2);
      }
      else
        strcpy(str, "  ");
    }
    else
    {
      if(row%2 == 0)
      {
        i = row/2;
        strcpy(str, "\033[0;30;43m");
        //str += 8;
         str += 10;
        strncpy(str, side+i*2, 2);
      }
      else
        strcpy(str, "  ");
    }
  }
  str += 2;
  strcpy(str, "\033[m");
 str -= 2;
  return buf;
}
static void
ch_printmsg(char *msg)
{
  move(msgline + 6, 0);
  outs(ch_brdline(msgline + 6 - 1)); outs(msg); clrtoeol();
  if((msgline += 1) > 10)
    msgline = 0;
  move(msgline + 6, 0);
  outs(ch_brdline(msgline + 6 - 1)); outs("��"); clrtoeol();
}
static void
ch_printeat()
{
  int i;
  char buf[80], *str;
  str = buf;
  if(myeat_index)
  {
    for(i = 0; i < myeat_index; i++)
    {
      strcpy(str, icon[MyEat[i]]);
      str += 2;
     //str += 4;
    }
  }
  move(2, 0); outs(ch_brdline(1)); outs(buf); clrtoeol();
  str = buf;
  *str = '\0';
  if(youreat_index)
  {
    for(i = 0; i < youreat_index; i++)
    {
      strcpy(str, icon[YourEat[i]]);
      str += 2;
      //str += 4;
    }
  }
  move(4, 0); outs(ch_brdline(3)); outs(buf); clrtoeol();
}
static void
overgame()
{
  if(GameOver == myColor)
  {
    ch_printmsg("�ҷ���ʤ!!");
    attr_step(cuser.userid, key_win, 0, +1);
  }
  else
  {
    ch_printmsg("�Է���ʤ!!");
    attr_step(cuser.userid, key_lose, 0, +1);
  }
#ifdef CHESS_LOG
  if(lfp)
  {
    int i;
    screenline sl[b_lines + 1];
    HDR fhdr;
    char buf[64];
    fputs("\n", lfp);
    if(GameOver != Deny)
      fprintf(lfp, "%s\n\n", GameOver == myColor ? "�� �ҷ���ʤ":"�� �Է���ʤ
");
    vs_save(sl);
    fprintf(lfp, "%88.88s\n\n", sl[0].data);
    for(i = 1; i < 20; i++)
    {
      fprintf(lfp, "%50.50s\n", sl[i].data);
    }
    fclose(lfp);
    if(savemode)
    {
      usr_fpath(buf, cuser.userid, fn_dir);
      hdr_stamp(buf, HDR_LINK, &fhdr, log_path);
      strcpy(fhdr.title, "[�� �� ¼] ��ս��¼");
      strcpy(fhdr.owner, cuser.userid);
      fhdr.xmode = MAIL_READ | MAIL_NOREPLY;
      rec_add(buf, &fhdr, sizeof(fhdr));
    }
    unlink(log_path);
  }
#endif
}
#define     CROSS_LINE  "----------"
static void
ch_draw()
{
  int i;
  char buf[256];
  for(i = 0; i < 19; i++)
  {
    move(1+i, 0);
    outs(ch_brdline(i));
  }
  move(1, 0);
  sprintf(buf, "\033[34;46m[�ҳԶԷ�]\033[m");outs(ch_brdline(0));
  outs(buf);clrtoeol();
  move(3, 0);
  sprintf(buf, "\033[34;46m[�Է�����]\033[m");outs(ch_brdline(2));
  outs(buf);clrtoeol();
  move(5, 0);
  sprintf(buf, CROSS_LINE);outs(ch_brdline(4));outs(buf);clrtoeol();
  move(19,0);
 sprintf(buf, "----------");
 outs(ch_brdline(18));
  outs(buf);
  clrtoeol();
 
  move(20, 0);
  if(Rule)
    outs("\033[0;30;43m  0   1   2   3   4   5   6   7     \033[m");
  else
    outs("\033[0;30;43m 0   1   2   3   4   5   6   7   8  \033[m");
  sprintf(buf, MSG_BAR, color[myColor],
    (mapTurn == myTurn) ? "������":"���Է�");
  move(21, 0);
  outs(buf);
  sprintf(buf, MSG_BAR2, savemode ? "��������" : "��������");
  move(22, 0);
  outs(buf);
}
static void
ch_init()
{
  char buf[256];
  int i, j;
  int my_win, my_lose, your_win, your_lose;
  Totalch = TotalStep = msgline = youreat_index = myeat_index = 0;
  Focus = my_win = my_lose = your_win = your_lose = 0;
  GameOver = Deny;
  savemode = 1;
  Row = Col = Rule;
  for(i = 0; i < 16; i++)
  {
    MyEat[i] = YourEat[i] = 0;
  }
  for(i = 0; i < 19; i++)
    for(j = 0; j < 17; j++)
      Board[i][j] = Empty;
  if(Rule)
  {
    for(i = 1; i < 9; i += 2)
      for(j = 1; j < 17; j += 2)
        Board[i][j] = Cover;
    for(i = 9; i < 19; i += 2)
      for(j = 1; j < 17; j+= 2)
    Board[i][j] = Deny;
    memset(Appear, 0, sizeof(Appear));
  }
  else
  {
    /* �췽 */
      Board[0][0] = Board[0][16] = 5;
      Board[0][2] = Board[0][14] = 6;
      Board[0][4] = Board[0][12] = 4;
      Board[0][6] = Board[0][10] = 3;
      Board[0][8] = Board[0][8] = 2;
      Board[4][2] = Board[4][14] = 7;
      Board[6][0] = Board[6][4] = Board[6][8] = Board[6][12] = Board[6][16]
        = 8;
    /* �ڷ� */
      Board[18][0] = Board[18][16] = 12;
      Board[18][2] = Board[18][14] = 13;
      Board[18][4] = Board[18][12] = 11;
      Board[18][6] = Board[18][10] = 10;
      Board[18][8] = Board[18][8] = 9;
      Board[14][2] = Board[14][14] = 14;
      Board[12][0] = Board[12][4] = Board[12][8] = Board[12][12] = Board[12]
[16]
        = 15;
  }
  mapTalk = Talk;
  if(myColor == Red)
    mapTurn = myTurn;
  else
    mapTurn = yourTurn;
  clear();
  attr_get(cuser.userid, key_win, &my_win);
  attr_get(cuser.userid, key_lose, &my_lose);
  attr_get(cutmp->mateid, key_win, &your_win);
  attr_get(cutmp->mateid, key_lose, &your_lose);
  sprintf(buf, "\033[1;33;44m�� ����%s ��  ��%s(%dʤ%d��) vs\
 ��%s(%dʤ%d��)     \033[m", ruleStr[Rule], cuser.userid, my_win, my_lose,
        cutmp->mateid, your_win, your_lose);
  outs(buf);
  sprintf(buf, "(sock:%d, %s V.S. %s)", cfd, cuser.userid, cutmp->mateid);
  blog("CHESS",buf);
  ch_draw();
  cmdCol = 0;
  *cmdBuf = 0;
  cmdPos = -1;
#ifdef CHESS_LOG
  usr_fpath(log_path, cuser.userid, "chess_log");
  lfp = fopen(log_path, "w");
  if(!Rule)
    fprintf(lfp, "�ҷ�ִ \033[43m%s\033[m ��\n", icon[myColor]);
#endif
}
static inline int
ch_send(char *buf)
{
  int len;
  len = strlen(buf) + 1;
  return (send(cfd, buf, len, 0) == len);
}
#ifdef EVERY_BIFF
static void check_biff()
{
      /* Thor.980805: �������Ա߰�enter����Ҫcheck biff */
      static int old_biff;
      int biff = cutmp->ufo & UFO_BIFF;
      if (biff && !old_biff)
        ch_printmsg("�� ��! �ʲ���������!");
      old_biff = biff;
}
#endif
static int
ch_recv()
{
  static char buf[128];
  char msg[80];
  int len, tmp, check;
  len  = sizeof(buf) + 1;
  if((len = recv(cfd, buf, len, 0)) <= 0)
  {
#ifdef CHESS_LOG
    fclose(lfp);
    unlink(log_path);
#endif
    return DISCONNECT;
  }
  switch(*buf)
  {
    case 'Q':
      return LEAVE;
    case 'N':
      ch_init();
      break;
    case 'D':
      tmp = atoi(buf+1);
      Board[(tmp%1000)/19][(tmp%1000)%19] = tmp / 1000;
      Appear[tmp/1000 - 2] += 1;
      Totalch += 1;
      mapTurn = myTurn;
      ch_draw();
      sprintf(msg, "���Է����� %s (%d, %c)", icon[tmp/1000],
        (tmp%1000%19-1)/2, tmp%1000/19/2 +'A');
#ifdef CHESS_LOG
      fputs(msg, lfp);
#endif
      ch_printmsg(msg);
      break;
    case 'E':
      tmp = atoi(strtok(buf+1, ":"));
      Board[(tmp%1000)/19][(tmp%1000)%19] = Empty;
      len = atoi(strtok(NULL, ":"));
      YourEat[youreat_index] = Board[len/19][len%19];
      youreat_index += 1;
      sprintf(msg, "���Է� %s(%d, %c) �Ե��ҷ� %s (%d, %c)",
    icon[tmp/1000], Rule?(tmp%1000%19-1)/2:tmp%1000%19/2,
    Rule?(tmp%1000/19-1)/2+'A':tmp%1000/19/2+'A',
    icon[Board[len/19][len%19]], Rule?(len%19-1)/2:(len%19)/2,
    Rule?(len/19-1)/2+'A':len/19/2+'A');
#ifdef CHESS_LOG
      fputs(msg, lfp);
#endif
      check = Board[len/19][len%19];
      Board[len/19][len%19] = tmp/1000;
      mapTurn = myTurn;
      ch_draw();
      ch_printmsg(msg);
      ch_printeat();
      if(Rule)
      {
    if(youreat_index == 16)
    {
      GameOver = !myColor;
      overgame();
    }
      }
      else
      {
    if(check == 2 || check == 9)
    {
      GameOver = !myColor;
      overgame();
    }
      }
      break;
   case 'M':
     tmp = atoi(strtok(buf+1, ":"));
     Board[(tmp%1000)/19][(tmp%1000)%19] = Empty;
     len = atoi(strtok(NULL, ":"));
     Board[len/19][len%19] = tmp/1000;
     mapTurn = myTurn;
     ch_draw();
     sprintf(msg, "���Է��� %s(%d, %c) ���� (%d, %c)",
     icon[tmp/1000], Rule?(tmp%1000%19-1)/2:tmp%1000%19/2,
     Rule?(tmp%1000/19-1)/2+'A':tmp%1000/19/2+'A',Rule?(len%19-1)/2:(len%19)
/2,
     Rule?(len/19-1)/2+'A':len/19/2+'A');
#ifdef CHESS_LOG
      fputs(msg, lfp);
#endif
     ch_printmsg(msg);
     break;
   case 'S':
     GameOver = myColor;
     overgame();
     break;
   case 'T':
     sprintf(msg, "\033[1;33m��%s\033[m", buf + 1);
     ch_printmsg(msg);
     break;
   case 'J':
     GameOver = myColor;
     overgame();
     break;
  }
  return NOTHING;
}
int ch_rand()
{
  int rd, i;
  char *index[] = {"1", "2", "2", "2", "2", "2", "5",
           "1", "2", "2", "2", "2", "2", "5"};
  if(Totalch == 31)   /* ����ʣ����һ��ʱ��Ҫ random */
  {
    for(i = 0; i < 14; i++)
    {
      if(Appear[i] < atoi(index[i]))
      {
        i += 2;
    return i;
      }
    }
  }
  for(;;)
  {
    rd = 0;
    srandom(time(NULL));
    rd = random() % 16;
    if(rd < 2)
      continue;
    if(Appear[rd - 2] < atoi(index[rd - 2]))
    {
      Appear[rd - 2] += 1;
      Totalch += 1;
      break;
    }
    else
      continue;
  }
  return rd;
}
static int
ch_count(int FoRow, int FoCol, int SoRow, int SoCol)
{
  int count, start, end;
  count = 0;
  if(SoRow == FoRow)
  {
    (SoCol > FoCol) ? (start = FoCol):(start = SoCol);
    (SoCol > FoCol) ? (end = SoCol):(end = FoCol);
    for(start+=2; start < end - 1; start+=2)
    {
      if(Board[SoRow][start] != Empty)
    count++;
    }
  }
  else if(SoCol == FoCol)
  {
    (SoRow > FoRow) ? (start = FoRow):(start = SoRow);
    (SoRow > FoRow) ? (end = SoRow):(end = FoRow);
    for(start+=2; start < end - 1; start+=2)
    {
      if(Board[start][SoCol] != Empty)
        count++;
    }
  }
  return count;
}
static int
ch_check()  /* ��ͬ:0   ��ͬ:1 */
{
  if(myColor == Red && (Board[Row][Col] < 9) && (Board[Row][Col] > Empty))
    return 0;
  else if(myColor == Black && Board[Row][Col] > 8)
    return 0;
  return 1;
}
static int
ch_Mv0()    /* for ���� */
{
  int mych, yourch, way;    /* way: 0. NOTHING  1.move  2.eat */
  int FoRow, FoCol, Rpos, Cpos; //, i;
  char buf[80];
  way = 0;
  FoRow = (Focus%1000)/19;
  FoCol = (Focus%1000)%19;
  if(Row == FoRow && Col == FoCol)
    return NOTHING;
  mych = Focus/1000;
  yourch = Board[Row][Col];
  Rpos = FoRow > Row?(FoRow - Row):(Row - FoRow);
  Cpos = FoCol > Col?(FoCol - Col):(Col - FoCol);
  switch(mych)
  {
    case 2:
    case 9:
      if((Col > 5 && Col < 11) && (((Rpos == 2) && !Cpos) ||
        ((Cpos == 2) && !Rpos)) && (Row < 5 || Row > 13))
      {
        if(yourch == Empty)
      way = 1;
        else if(ch_check())
          way = 2;
      }
      break;
    case 3:
    case 10:
      if((Col > 5 && Col < 11) && (Rpos == 2) && (Cpos == 2) &&
    (Row < 5 || Row > 13))
      {
        if(yourch == Empty)
      way = 1;
    else if(ch_check())
      way = 2;
      }
      break;
    case 4:
    case 11:
      if(((Row < 9 && myColor == Red) || (Row > 9 && myColor == Black)) &&
    Rpos == 4 && Cpos == 4 && Board[(Row+FoRow)/2][(Col+FoCol)/2] == Empty)
      {
    if(yourch == Empty)
      way = 1;
        else if(ch_check())
      way = 2;
      }
      break;
    case 5:
    case 12:
      if(!ch_count(FoRow, FoCol, Row, Col) && (FoRow == Row || FoCol == Col)
)
      {
    if(yourch == Empty)
      way = 1;
        else if(ch_check())
      way = 2;
      }
      break;
    case 6:
    case 13:
      if((Rpos == 4 && Cpos == 2 && Board[(Row+FoRow)/2][FoCol] == Empty) ||

    (Rpos == 2 && Cpos == 4 && Board[FoRow][(Col+FoCol)/2] == Empty))
      {
    if(yourch == Empty)
      way = 1;
    else if(ch_check())
      way = 2;
      }
      break;
    case 7:
    case 14:
      if(FoRow == Row || FoCol == Col)
      {
    if(ch_count(FoRow, FoCol, Row, Col) == 1 && ch_check())
      way = 2;
        else if(!ch_count(FoRow, FoCol, Row, Col) && Board[Row][Col] == Empty)

      way = 1;
      }
      break;
    case 8:
    case 15:
      if(myColor == Red)
      {
    if(Row < 9 && (Row - FoRow == 2) && FoCol == Col)
        {
      if(yourch == Empty)
        way = 1;
      else if(ch_check())
        way = 2;
        }
    else if(Row > 9 && ((Rpos == 2 && FoCol == Col) ||
        (Cpos == 2 && FoRow == Row)))
        {
      if(yourch == Empty)
        way = 1;
      else if(ch_check())
        way = 2;
        }
      }
      else
      {
    if(Row > 9 && (FoRow - Row == 2) && FoCol == Col)
    {
          if(yourch == Empty)
            way = 1;
          else if(ch_check())
            way = 2;
    }
    else if(Row < 9 && ((Rpos == 2 && FoCol == Col) ||
        (Cpos == 2 && FoRow == Row)))
    {
      if(yourch == Empty)
        way = 1;
      else if(ch_check())
        way = 2;
    }
      }
      break;
  }
  if(way)
  {
    if(way == 1)
    {
      Board[Row][Col] = mych;
      sprintf(buf, "M%d:%d", Focus, (Row * 19 + Col));
      if(!ch_send(buf))
        return DISCONNECT;
      Board[FoRow][FoCol] = Empty;
      mapTurn = yourTurn;
      ch_draw();
      sprintf(buf, "���ƶ� %s(%d, %c) �� (%d, %c)",
        icon[Focus/1000], Focus%1000%19/2, Focus%1000/19/2+'A',
    Col/2, Row/2+'A');
#ifdef CHESS_LOG
      fputs(buf, lfp);
#endif
      ch_printmsg(buf);
    }
    else
    {
      MyEat[myeat_index] = Board[Row][Col];
      myeat_index += 1;
      Board[Row][Col] = mych;
      sprintf(buf, "E%d:%d", Focus, (Row * 19 + Col));
      if(!ch_send(buf))
        return DISCONNECT;
      Board[FoRow][FoCol] = Empty;
      mapTurn = yourTurn;
      ch_draw();
      sprintf(buf, "���ƶ� %s(%d, %c) �Ե� %s(%d, %c)",
    icon[Focus/1000], Focus%1000%19/2, Focus%1000/19/2+'A', icon[yourch],
    Col/2, Row/2+'A');
#ifdef CHESS_LOG
      fputs(buf, lfp);
#endif
      ch_printmsg(buf);
      ch_printeat();
      if(yourch == 2 || yourch == 9)
      {
    GameOver = myColor;
    overgame();
      }
    }
    Focus = 0;
    if(!Rule)
    {
      int i, j, q;
      q = 0;
      for(j = 6; j < 11; j += 2)
      {
    for(i = 0; i < 5; i += 2)
    {
      if(Board[i][j] == 2)
      {
        q = 1;
        break;
      }
    }
    if(q)
      break;
      }
      if(q)
      {
    for(q = 14; q < 19; q += 2)
    {
      if((Board[q][j] == 9) && (!ch_count(i, j, q, j)))
      {
            if(!ch_send("J"))
              return DISCONNECT;
            GameOver = !myColor;
            overgame();
        break;
      }
    }
      }
    }
  }
  return NOTHING;
}
static int
ch_Mv1()    /* for ���� */
{
  int mych, yourch;
  int FoRow, FoCol;
  char buf[80];
  FoRow = (Focus%1000)/19;
  FoCol = (Focus%1000)%19;
  mych = Focus/1000;
  yourch = Board[Row][Col];
  if((yourch != Empty) && ((mych == 7) || (mych == 14)) && ch_check())
  {
    if(ch_count(FoRow, FoCol, Row, Col) == 1)
    {
      MyEat[myeat_index] = Board[Row][Col];
      myeat_index += 1;
      Board[Row][Col] = mych;
      sprintf(buf, "E%d:%d", Focus, (Row * 19 + Col));
      if(!ch_send(buf))
        return DISCONNECT;
      Board[FoRow][FoCol] = Empty;
      mapTurn = yourTurn;
      ch_draw();
      sprintf(buf, "���ƶ� %s(%d, %c) �Ե� %s(%d, %c)",
#ifdef CHESS_LOG
      fputs(buf, lfp),
#endif
      icon[Focus/1000], Focus%1000%19/2, Focus%1000/19/2+'A', icon[yourch],
      Col/2, Row/2+'A');
      ch_printmsg(buf);
      ch_printeat();
    }
    Focus = 0;
  }
  else if((((Row - FoRow == 2) || (FoRow - Row == 2)) && (Col == FoCol)) ||
    (((Col - FoCol == 2) || (FoCol - Col == 2)) && (Row == FoRow)))
  {
    if(yourch == Empty)
    {
      Board[Row][Col] = mych;
      sprintf(buf, "M%d:%d", Focus, (Row * 19 + Col));
      if(!ch_send(buf))
        return DISCONNECT;
      Board[FoRow][FoCol] = Empty;
      mapTurn = yourTurn;
      ch_draw();
      sprintf(buf, "���� %s(%d, %c) ���� (%d, %c)",
        icon[Focus/1000], (Focus%1000%19-1)/2, (Focus%1000/19-1)/2+'A',
        (Col-1)/2, (Row-1)/2+'A');
#ifdef CHESS_LOG
      fputs(buf, lfp);
#endif
      ch_printmsg(buf);
    }
    else if(ch_check())
    {
      if(myColor == Black)
    mych -= 7;
      else
        yourch -= 7;
      if(((mych == 8) && (yourch == 2)) || (mych <= yourch))
      {
    if((mych == 7) && (yourch == 7))
      return NOTHING;
        if((mych == 2) && (yourch == 8))
      return NOTHING;
    MyEat[myeat_index] = Board[Row][Col];
    myeat_index += 1;
    Board[Row][Col] = Focus/1000;
        sprintf(buf, "E%d:%d", Focus, (Row * 19 + Col));
    if(!ch_send(buf))
      return DISCONNECT;
    Board[FoRow][FoCol] = Empty;
    mapTurn = yourTurn;
    ch_draw();
        sprintf(buf, "���ƶ� %s(%d, %c) �Ե� %s(%d, %c)",
        icon[Focus/1000], Focus%1000%19/2, Focus%1000/19/2+'A',
        icon[MyEat[myeat_index-1]], Row/2, Col/2+'A');
#ifdef CHESS_LOG
      fputs(buf, lfp);
#endif
        ch_printmsg(buf);
        ch_printeat();
      }
    }
    Focus = 0;
  }
  if(myeat_index == 16)
  {
    GameOver = myColor;
    overgame();
  }
  return NOTHING;
}
static int ctkCtrlC()
{
  *cmdBuf = '\0';
  cmdCol = 0;
  move(b_lines - 3, 36);
  clrtoeol();
  return NOTHING;
}
static int ctkCtrlH()
{
  if (cmdCol)
  {
    int ch = cmdCol--;
    memcpy(&cmdBuf[cmdCol], &cmdBuf[ch], sizeof(talkBuf) - ch -1);
    move(b_lines - 3, cmdCol + 36);
    outs(&cmdBuf[cmdCol]);
    clrtoeol();
  }
  return NOTHING;
}
static int ctkEnter()
{
  char msg[80];
#ifdef EVERY_BIFF
  check_biff();
#endif
  if (*cmdBuf)
  {
    for (cmdPos = MAXLASTCMD - 1; cmdPos; cmdPos--)
      strcpy(lastcmd[cmdPos], lastcmd[cmdPos - 1]);
    strcpy(lastcmd[0], cmdBuf);
    if(!ch_send(talkBuf))
    {
      return DISCONNECT;
    }
    sprintf(msg,"\033[1;36m��%s\033[m",cmdBuf);
    ch_printmsg(msg);
    *cmdBuf = '\0';
    cmdCol = 0;
    cmdPos = -1;
    move(b_lines - 3, 36);
    clrtoeol();
  }
  return NOTHING;
}
static int ctkLEFT()
{
  if (cmdCol)
    --cmdCol;
  return NOTHING;
}
static int ctkRIGHT()
{
  if (cmdBuf[cmdCol])
    ++cmdCol;
  return NOTHING;
}
static int ctkUP()
{
  cmdPos++;
  cmdPos %= MAXLASTCMD;
  str_ncpy(cmdBuf, lastcmd[cmdPos], 41);
  move(b_lines - 3, 36);
  outs(cmdBuf);
  clrtoeol();
  cmdCol = strlen(cmdBuf);
  return NOTHING;
}
static int ctkDOWN()
{
  cmdPos += MAXLASTCMD - 2;
  return ctkUP();
}
static int ctkDefault(int ch)
{
  if(isprint2(ch))
  {
    if (cmdCol < 40)
    {
      if (cmdBuf[cmdCol])
      {                       /* insert */
        int i;
        for (i = cmdCol; cmdBuf[i] && i < 39; i++);
        cmdBuf[i + 1] = '\0';
        for (; i > cmdCol; i--)
          cmdBuf[i] = cmdBuf[i - 1];
      }
      else
      {                       /* append */
        cmdBuf[cmdCol + 1] = '\0';
      }
      cmdBuf[cmdCol] = ch;
      move(b_lines - 3, cmdCol + 36);
      outs(&cmdBuf[cmdCol++]);
    }
    return NOTHING;
  }
}
static int
chCtrlN()
{
  if(!ch_send("N"))
    return DISCONNECT;
  ch_init();
  return NOTHING;
}
static int
chCtrlC()
{
  if(!ch_send("Q"))
    return DISCONNECT;
  return LEAVE;
}
static int
chCtrlS()
{
  if(GameOver == Deny)
  {
    if(!ch_send("S"))
      return DISCONNECT;
    GameOver = !myColor;
    overgame();
  }
  return NOTHING;
}
static int
chCtrlJ()
{
  char buf[80];
  savemode = savemode ? 0 : 1;
  sprintf(buf, MSG_BAR2, savemode ? "��������" : "��������");
  move(22, 0);
  outs(buf);
  return NOTHING;
}
static int
chLEFT()
{
  if((Col - 2) > -1)
    Col -= 2;
  return NOTHING;
}
static int
chRIGHT()
{
  if((Col + 2) < 17)
    Col += 2;
  return NOTHING;
}
static int
chUP()
{
  if((Row - 2) > -1)
      Row -= 2;
  return NOTHING;
}
static int
chDOWN()
{
  if(Board[Row + 2][Col] != Deny)
    if((Row + 2) < 19)
      Row += 2;
  return NOTHING;
}
static int
chSpace()
{
  if(GameOver == Deny)
  {
    char buf[40];
    if(Board[Row][Col] == Cover)
    {
      Board[Row][Col] = ch_rand();
      sprintf(buf, "D%d", Board[Row][Col] * 1000 + Row * 19 + Col);
      if(!ch_send(buf))
        return DISCONNECT;
      mapTurn = yourTurn;
      Focus = Empty;
      ch_draw();
      sprintf(buf, "������ %s(%d, %c)",
    icon[Board[Row][Col]], (Col-1)/2, (Row-1)/2+'A');
      ch_printmsg(buf);
    }
    else
    {
      if(!ch_check())
      {
        int tmp;
        tmp = Focus;
        Focus = Board[Row][Col] * 1000 + Row * 19 + Col;
        move(tmp % 1000 / 19 + 1, 0);
        outs(ch_brdline(tmp % 1000 / 19));
        move(Row + 1, 0);
        outs(ch_brdline(Row));
      }
      else
      {
        return Rule?ch_Mv1():ch_Mv0();
      }
    }
  }
  return NOTHING;
}
static int cTAB()
{
  mapTalk = mapTalk ? NULL : Talk;
  return NOTHING;
}
static int
NoOp()
{
  return NOTHING;
}
static KeyFunc
Talk[] =
{
 Ctrl('C'), ctkCtrlC,
 Ctrl('H'), ctkCtrlH,
 '\n', ctkEnter,
 KEY_LEFT, ctkLEFT,
 KEY_RIGHT, ctkRIGHT,
 KEY_UP, ctkUP,
 KEY_DOWN, ctkDOWN,
 KEY_TAB, cTAB,
 0, ctkDefault
},
yourTurn[] =
{
 Ctrl('N'), chCtrlN,
 Ctrl('C'), chCtrlC,
 Ctrl('J'), chCtrlJ,
 KEY_LEFT, chLEFT,
 KEY_RIGHT, chRIGHT,
 KEY_UP, chUP,
 KEY_DOWN, chDOWN,
 KEY_TAB, cTAB,
 0, NoOp
},
myTurn[] =
{
 Ctrl('N'), chCtrlN,
 Ctrl('C'), chCtrlC,
 Ctrl('S'), chCtrlS,
 Ctrl('J'), chCtrlJ,
 KEY_LEFT, chLEFT,
 KEY_RIGHT, chRIGHT,
 KEY_UP, chUP,
 KEY_DOWN, chDOWN,
 KEY_TAB, cTAB,
 'm', chSpace,
 ' ', chSpace,
 0, NoOp
};
int MainChess(int sock, int later)
{
  screenline sl[b_lines + 1];
  int ch, tmpmode;
  char c;
  KeyFunc *k;
  vs_save(sl);
  cfd = sock;
  if(!later)
  {
    c = vans("����������? 0)ȡ�� 1)���� 2)���� [0]");

    if(c) c-='0';
    vs_restore(sl);
    if(send(cfd, &c, 1, 0) != 1)
      return -2;
    myColor = Red;
  }
  else
  {
    outz("�Է�Ҫ��������ģʽ,ѡ�������Ժ�.....");
    refresh();
    if(recv(cfd, &c, 1, 0) != 1)
      return -2;
    vs_restore(sl);
    myColor = Black;
  }
  if(c < 1 || c > 2)
    return -1;
  else
    c--;
  tmpmode = bbsmode;
  Rule = c;
  key_win = ATTR_GCHESS_WIN + ((unsigned)c << 8);
  key_lose = ATTR_GCHESS_LOSE + ((unsigned)c << 8);
  ch_init();
  for(;;)
  {
    if(mapTalk)
    {
      move(b_lines - 3, cmdCol + 36);
      k = mapTalk;
    }
    else
    {
      move(Row + 1, Col * 2);
      k = mapTurn;
    }
    ch = vkey();
    if(ch == I_OTHERDATA)
    {
      if((ch = ch_recv()) >= NOTHING)
    continue;
      vs_restore(sl);
      return ch;
    }
#ifdef EVERY_Z
    else if(ch == Ctrl('Z'))
    {
      char buf[IDLEN + 1];
      strcpy(buf, cutmp->mateid);
      holdon_fd = vio_fd;
      vio_fd = 0;
      every_Z();
      vio_fd = holdon_fd;
      holdon_fd = 0;
      strcpy(cutmp->mateid, buf);
      continue;
    }
#endif
    for(;;k++)
    {
      if(!k->key || ch == k->key)
    break;
    }
    if((ch = k->key ? (*k->func)() : (*k->func)(ch)) >= NOTHING)
      continue;
    vs_restore(sl);
    utmp_mode(tmpmode);
    return 0;
  }
}
#include<stdarg.h>
int vaChess(va_list pvar)
{
  int sock, later;
  utmp_mode (M_CHESS);
  sock = va_arg(pvar, int);
  later = va_arg(pvar, int);
  return MainChess(sock, later);
}
#endif /* _HAVE_CHESS_ */
