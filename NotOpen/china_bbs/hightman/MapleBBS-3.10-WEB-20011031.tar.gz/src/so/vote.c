/*-------------------------------------------------------*/
/* vote.c	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : boards' vote routines		 	 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/
/* brd/_/.VCH - Vote Control Header			 */
/* brd/_/@/@_ - vote description file			 */
/* brd/_/@/I_ - vote selection Items			 */
/* brd/_/@/V_ - Vote choice record			 */
/* brd/_/@/O_ - users' Opinions				 */
/*-------------------------------------------------------*/
/* usr/_/vote - users' vote record			 */
/*-------------------------------------------------------*/


#include "bbs.h"


extern BCACHE *bshm;
extern XZ xz[];
extern char radix32[32];


static int vote_add();


int
vote_result(xo)
  XO *xo;
{
  char fpath[80];

  setdirpath(fpath, xo->dir, "@/@vote");
  /* Thor.990204: Ϊ����more ����ֵ */   
  if (more(fpath, NULL) >= 0)
    return XO_HEAD;

  vmsg("Ŀǰû���κο�Ʊ�Ľ��");
  return XO_FOOT;
}


static void
vote_item(num, vch)
  int num;
  VCH *vch;
{
  prints("%6d %c%c %-9.8s%-12s %s\n",
    num, vch->vsort, vch->vpercent, vch->cdate,vch->owner,vch->title);
}


static int
vote_body(xo)
  XO *xo;
{
  VCH *vch;
  int num, max, tail;

  max = xo->max;
  if (max <= 0)
  {
    if (bbstate & STAT_BOARD)
    {
      if (vans("Ҫ�ٰ�ͶƱ��(Y/N)[N] ") == 'y')
	return vote_add(xo);
    }
    else
    {
      vmsg("Ŀǰ����ͶƱ����");
    }
    return XO_QUIT;
  }

  vch = (VCH *) xo_pool;
  num = xo->top;
  tail = num + XO_TALL;
  if (max > tail)
    max = tail;

  move(3, 0);
  do
  {
    vote_item(++num, vch++);
  } while (num < max);
  clrtobot();

  return XO_NONE;
}


static int
vote_head(xo)
  XO *xo;
{
  vs_head(currBM, "ͶƱ��"); 
  outs("\
[��]�뿪 [v]ͶƱ [R]��� [E]�޸� [^P]���� [^Q]��ѯ/��ֹ/���� [h]˵��\n\033[44m\
  ���     ��Ʊ��  ������       Ͷ  Ʊ  ��  ּ                                \033[m");
  return vote_body(xo);
}


static int
vote_init(xo)
  XO *xo;
{
  xo_load(xo, sizeof(VCH));
  return vote_head(xo);
}


static int
vote_load(xo)
  XO *xo;
{
  xo_load(xo, sizeof(VCH));
  return vote_body(xo);
}


static void
vch_edit(vch)
  VCH *vch;
{
  int num;
  char buf[4];

  vget(21, 0, "����ͶƱ���м��� (���٣���)��", buf, 3, DOECHO);
  num = atoi(buf);
  if (num < 1)
    num = 1;
  vch->vclose = vch->chrono + num * 86400;
  str_stamp(vch->cdate, &vch->vclose);

  vch->vsort = 
    (vget(22, 0, "��Ʊ����Ƿ�����(Y/N)[N] ", buf, 3, LCECHO) == 'y')
    ? 's' 
    : ' ';

  vch->vpercent = 
   (vget(23, 0, "��Ʊ����Ƿ���ʾ�ٷֱ���(Y/N)[N] ", buf, 3, LCECHO) == 'y')
    ? '%' 
    : ' ';
}


static int
vlist_edit(vlist)
  vitem_t vlist[];
{
  int item;
  char buf[80];

  /* Thor.980902: lkchu patch: ��λ�廭�� */
  move(0,0);
  clrtobot();

  outs("����������ѡ�� (��� 32 ��)���� ENTER ������");

  strcpy(buf, " ) ");
  for (;;)
  {
    item = 0;
    for (;;)
    {
      buf[0] = radix32[item];
      if (!vget((item & 15) + 3, (item / 16) * 40,
	  buf, vlist[item], sizeof(vitem_t), GCARRY) || (++item >= MAX_CHOICES))
	break;
    }
    if (vans("�Ƿ���������ѡ��(Y/N)[N] ") != 'y')
      break;
  }
  return item;
}


static int
vote_add(xo)
  XO *xo;
{
  VCH vch;
  int fd, item;
  char *dir, *str, fpath[80], buf[TTLEN + 1 -5]; /* Thor.981016: �³���өĻ */
  vitem_t vlist[MAX_CHOICES];
  BRD *brd;

  if (!(bbstate & STAT_BOARD))
    return XO_NONE;

  if (!vget(b_lines, 0, "ͶƱ���⣺", buf, sizeof(buf), DOECHO))
    return XO_FOOT;

  dir = xo->dir;
  fd = hdr_stamp(dir, 0, (HDR *)&vch, fpath);
  if (fd < 0)
  {
    vmsg("�޷�����ͶƱ˵����");
    blog("VOTE ", fpath);
    return XO_FOOT;
  }

  close(fd);
  vmsg("��ʼ�༭ [ͶƱ˵��]");
  fd = vedit(fpath, 0); /* Thor.981020: ע�ⱻtalk������ */
  if (fd)
  {
    unlink(fpath);
    vmsg("ȡ��ͶƱ");
    return XO_HEAD;
  }

  strcpy(vch.title, buf);
  str = strrchr(fpath, '@');

  /* --------------------------------------------------- */
  /* ͶƱѡ� : Item					 */
  /* --------------------------------------------------- */

  memset(vlist, 0, sizeof(vlist));
  item = vlist_edit(vlist);

  *str = 'I';
  fd = open(fpath, O_WRONLY | O_CREAT | O_TRUNC, 0600);
  if (fd < 0)
  {
    vmsg("�޷�����ͶƱѡ�");
    blog("VOTE ", fpath);
    return XO_HEAD;
  }
  write(fd, vlist, item * sizeof(vitem_t));
  close(fd);

  sprintf(buf + 3, "����ÿ������Ͷ��Ʊ��([1]��%d): ", item);
  vget(20, 0, buf + 3, buf, 3, DOECHO);
  fd = atoi(buf);
  if (fd < 1)
    fd = 1;
  else if (fd > item)
    fd = item;
  vch.maxblt = fd;

  vch_edit(&vch);

  strcpy(vch.owner, cuser.userid);

  brd = bshm->bcache + brd_bno(currboard);
  brd->bvote++;
  vch.bstamp = brd->bstamp;

  rec_add(dir, &vch, sizeof(vch));

  vmsg("��ʼͶƱ�ˣ�");
  return vote_init(xo);
}


static int
vote_edit(xo)
  XO *xo;
{
  int pos;
  VCH *vch, vxx;
  char *dir, fpath[80];

  /* Thor: for �޸�ͶƱѡ�� */
  int fd,item;
  vitem_t vlist[MAX_CHOICES];
  char *fname, buf[TTLEN+1];

  if (!(bbstate & STAT_BOARD))
    return XO_NONE;

  pos = xo->pos;
  dir = xo->dir;
  vch = (VCH *) xo_pool + (pos - xo->top);

  /* Thor: �޸�ͶƱ���� */
  vxx = *vch;

  if (!vget(b_lines, 0, "ͶƱ���⣺", vxx.title, TTLEN + 1 -5 /* sizeof(vxx.title) Thor.981020: �³���өĻ */ , GCARRY))
    return XO_FOOT;

  hdr_fpath(fpath, dir, (HDR *) vch);
  if(vedit(fpath, 0))  /* Thor.981020: ע�ⱻtalk������  */
    outs("��");  /* Thor.981020: ����Ǹ����??:P */

  /* Thor: �޸�ͶƱѡ�� */

  memset(vlist, 0, sizeof(vlist));
  fname = strrchr(fpath, '@');
  *fname = 'I';
  fd = open(fpath, O_RDONLY);

#if 0
  count = read(fd, vlist, sizeof(vlist)) / sizeof(vitem_t);
#endif 
  read(fd, vlist, sizeof(vlist));
  close(fd);

  item = vlist_edit(vlist);

  fd = open(fpath, O_WRONLY | O_CREAT | O_TRUNC, 0600);
  if (fd < 0)
  {
    vmsg("�޷�����ͶƱѡ�");
    blog("VOTE ", fpath);
    return XO_HEAD;
  }
  write(fd, vlist, item * sizeof(vitem_t));
  close(fd);

  /* Thor: �޸�ÿ�˿�ͶƱ�� */

  sprintf(buf + 3, "����ÿ������Ͷ��Ʊ��([1]��%d): ", item);
  sprintf(buf,"%d",vxx.maxblt);
  vget(20, 0, buf + 3, buf, 3, GCARRY);
  fd = atoi(buf);
  if (fd < 1)
    fd = 1;
  else if (fd > item)
    fd = item;
  vxx.maxblt = fd;

  vch_edit(&vxx);
  if (memcmp(&vxx, vch, sizeof(VCH)))
  {
    if (vans("ȷ��Ҫ�޸�����ͶƱ��(Y/N)[N]") == 'y')
    {
      *vch = vxx;
      rec_put(dir, vch, sizeof(VCH), pos);
    }
  }

  return vote_head(xo);
}


static int
vote_query(xo)
  XO *xo;
{
  char *dir, *fname, fpath[80], buf[80];
  VCH *vch;
  int cc, pos;

  if (!(bbstate & STAT_BOARD))
    return XO_NONE;

  pos = xo->pos;
  dir = xo->dir;
  vch = (VCH *) xo_pool + (pos - xo->top);

  hdr_fpath(fpath, dir, (HDR *) vch);
  more(fpath, (char *) -1);

  fname = strrchr(fpath, '@');
  *fname = 'V';
  sprintf(buf, "���� %d �˲μ�ͶƱ, A)���� B)ȡ�� Q>uit�� ", /* Thor:����� */
    rec_num(fpath, sizeof(int)));
  cc = vans(buf);

  if (cc == 'a')
  {
    vget(b_lines, 0, "����Ŀ�Ʊʱ��(-��ǰ/+����/0����)��", buf, 3, DOECHO);
    if (cc = atoi(buf))
    {
      vch->vclose = vch->vclose + cc * 86400;
      str_stamp(vch->cdate, &vch->vclose);
      rec_put(dir, vch, sizeof(VCH), pos);
    }
  }
  else if (cc == 'b')
  {
    if (vans("ȷ��Ҫȡ������ͶƱ��") == 'y')
    {
      char *list = "@IOV";

      while (*fname = *list++)
      {
	unlink(fpath); /* Thor: ȷ�����־Ϳ� */
      }

      cc = currchrono;
      currchrono = vch->chrono;
      rec_del(dir, sizeof(VCH), pos, cmpchrono, NULL);
      currchrono = cc;
      return vote_init(xo);
    }
  }

  return vote_head(xo); 
}


static int
vote_join(xo)
  XO *xo;
{
  VCH *vch;
  int count, choice, fd, fv;
  char *fname, fpath[80], buf[80], *slist[MAX_CHOICES];
  vitem_t vlist[MAX_CHOICES];

  vch = (VCH *) xo_pool + (xo->pos - xo->top);
  if (time(0) > vch->vclose)
  {
    vmsg("ͶƱ�Ѿ���ֹ�ˣ��뾲��Ʊ");
    return XO_FOOT;
  }

  /* --------------------------------------------------- */
  /* ����Ƿ��Ѿ�Ͷ��Ʊ					 */
  /* --------------------------------------------------- */

#define	FV_SZ	(sizeof(time_t) * 2)

  usr_fpath(buf, cuser.userid, "vote");
  fv = open(buf, O_RDWR | O_CREAT, 0600);

  /* flock(fv, LOCK_EX); */
  /* Thor.981205: �� fcntl ȡ��flock, POSIX��׼�÷� */
  f_exlock(fv);

  while (read(fv, buf, FV_SZ) == FV_SZ)
  {
    if (!memcmp(vch, buf, FV_SZ))
    {
      /* flock(fv, LOCK_UN); */
      /* Thor.981205: �� fcntl ȡ��flock, POSIX��׼�÷� */
      f_unlock(fv);

      close(fv);
      vmsg("���Ѿ�Ͷ��Ʊ�ˣ�");
      return XO_FOOT;
    }
  }

  /* --------------------------------------------------- */
  /* ��ʼͶƱ						 */
  /* --------------------------------------------------- */

  hdr_fpath(fpath, xo->dir, (HDR *) vch);
  more(fpath, NULL);

  /* --------------------------------------------------- */
  /* ����ͶƱѡ�					 */
  /* --------------------------------------------------- */

  fname = strrchr(fpath, '@');
  *fname = 'I';
  fd = open(fpath, O_RDONLY);
  count = read(fd, vlist, sizeof(vlist)) / sizeof(vitem_t);
  close(fd);

  for (fd = 0; fd < count; fd++)
  {
    slist[fd] = (char *) &vlist[fd];
  }

  /* --------------------------------------------------- */
  /* ����ͶƱ						 */
  /* --------------------------------------------------- */

  choice = 0;
  sprintf(buf,"Ͷ����ʥ�� %d Ʊ",vch->maxblt); /* Thor: ��ʾ��༸Ʊ */
  vs_bar(buf);
  outs("ͶƱ���⣺");
  *buf = '\0';
  for (;;)
  {
    choice = bitset(choice, count, vch->maxblt, vch->title, slist);
    vget(b_lines - 1, 0, "���л�Ҫ˵��", buf, 60, GCARRY);
    fd = vans("ͶƱ (Y)ȷ�� (N)���� (Q)ȡ����[Y] ");
    if (fd != 'n')
      break;
  }

  /* --------------------------------------------------- */
  /* ��¼�����һƱҲδͶ����� ==> �൱�Ͷ��Ʊ	 */
  /* --------------------------------------------------- */

  if (fd != 'q')
  {
    *fname = 'V';
    fd = open(fpath, O_WRONLY | O_CREAT | O_APPEND, 0600);
    if (fd >= 0)
    {
      write(fd, &choice, sizeof(choice));
      close(fd);

      /* Thor: д��ʹ������� */

      if (*buf)
      {
	FILE *fp;

	*fname = 'O';
	if (fp = fopen(fpath, "a"))
	{
	  fprintf(fp, "%-12s: %s\n", cuser.userid, buf);
	  fclose(fp);
	}
      }

      write(fv, vch, FV_SZ);
      vmsg("ͶƱ��ɣ�");
    }
  }

  /* flock(fv, LOCK_UN); */
  /* Thor.981205: �� fcntl ȡ��flock, POSIX��׼�÷� */
  f_unlock(fv);

  close(fv);

  return vote_head(xo);
}


static int
vote_help(xo)
  XO *xo;
{
  film_out(FILM_VOTE, -1);
  return vote_head(xo);
}


static KeyFunc vote_cb[] =
{
  XO_INIT, vote_init,
  XO_LOAD, vote_load,
  XO_HEAD, vote_head,
  XO_BODY, vote_body,

  'v', vote_join,
  'R', vote_result,

  'E', vote_edit,
  Ctrl('P'), vote_add,
  Ctrl('Q'), vote_query,

  'h', vote_help
};


int
XoVote(xo)
  XO *xo;
{
  char fpath[32];

  /* �� post Ȩ���Ĳ��ܲμ�ͶƱ */

  if (!(bbstate & STAT_POST) || !cuser.userlevel)
    return XO_NONE;

  setdirpath(fpath, xo->dir, ".VCH");
  if (!(bbstate & STAT_BOARD) && !rec_num(fpath, sizeof(VCH)))
  {
    vmsg("Ŀǰû��ͶƱ����");
    return XO_FOOT;
  }

  xz[XZ_VOTE - XO_ZONE].xo = xo = xo_new(fpath);
  xz[XZ_VOTE - XO_ZONE].cb = vote_cb;
  xover(XZ_VOTE);
  free(xo);

  return XO_INIT;
}

int
SystemVote()
{
  char fpath[80];
  XO *xo;

  /* �� post Ȩ���Ĳ��ܲμ�ͶƱ */
  XoPost(brd_bno("SYSOP"));

  sprintf(fpath, "brd/%s/.VCH", "SYSOP");
  if (!(bbstate & STAT_BOARD) && !rec_num(fpath, sizeof(VCH)))
  {
    vmsg("Ŀǰû��ͶƱ����");
    return 0;
  }

  xz[XZ_VOTE - XO_ZONE].xo = xo = xo_new(fpath);
  xz[XZ_VOTE - XO_ZONE].cb = vote_cb;
  xover(XZ_VOTE);
  free(xo);

  return 0;
}



#if 0
void
vote_sync()
{
  int fd, size;
  struct stat st;
  char fpath[64];

  usr_fpath(fpath, cuser.userid, "vote");

  if ((fd = open(fpath, O_RDWR, 0600)) < 0)
    return;

  outz("�� �������������У������� \033[5m...\033[m");
  refresh();

  if (!fstat(fd, &st) && (size = st.st_size) > 0)
  {
    time_t *base, *head, *tail;

    base = head = (time_t *) malloc(size);
    size = read(fd, base, size);
    if (size >= FV_SZ)
    {
      tail = (time_t *) ((char *) base + size);

outerLoop:
      while (head < tail)
      {
        int bno = bstamp2bno(head[1]);  /* Thor: head[1] : VCH.bstamp */
        
        if(bno>=0)
        {       
          int fv;

          brd_fpath(buf,bshm->bcache[bno].brdname,".VCH");
          fv = open(buf, O_RDONLY);
          if(fv >= 0)
          {
            VCH vch;
            while (read(fv, vch, sizeof vch) == sizeof vch)
            {
              if (!memcmp(&vch, head, FV_SZ))
              {
                head+=2;
                close(fv);
                goto outerLoop;/* continue;  outer while */
              }
            }
            close(fv);
          }
        }

        tail-=2;
        if (head >= tail)
          break;
        memcpy(head, tail, FV_SZ);
      }

      size = (char *) tail - (char *) base;
      if (size > 0)
      {
        lseek(fd, 0, SEEK_SET);
        write(fd, base, size);
        ftruncate(fd, size);
      }
    }
    else 
      size = 0;
    free(base);
  }
  close(fd);

  if (size <= 0)
  {
    unlink(fpath);
  }
}
#endif
