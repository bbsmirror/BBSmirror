#include "bbs.h"

#ifdef HAVE_MONEY_ISM

#define         LOVE_PAPER      FN_ETC_LOVEPAPER
#define		P_BEGIN		"@begin"
#define		L_BEGIN		(3)
#define		P_MID1		"@mid1"
#define		L_MID1		(2)
#define		P_MID2		"@mid2"
#define		L_MID2		(2)
#define		P_MID3		"@mid3"
#define		L_MID3		(2)
#define		P_END		"@end"
#define		L_END		(3)
#define		P_POEM		"@poem"

int 
lovepaper()
{
  FILE *fp,*fd;
  int line,page,mode,rpage,cpage,style;
  char buf[300];
  char *header[] = {P_BEGIN,P_MID1,P_MID2,P_MID3,P_END,P_POEM};
  int  h_line[] = {L_BEGIN,L_MID1,L_MID2,L_MID3,L_END};
  char fpath[128], folder[128];
  HDR	mhdr;
  int	rc;
  char userid[14];
  ACCT	xacct;
  
  if(cuser.money<100) { vmsg("���ֽ𻹲���100�����ܹ�������!");
                           return 0; }

  if(vans("�˴��ж�����ȥ�ֽ�100,��ȷ��Ӵ? [Y/n]") == 'n')
     { 
        vmsg("������ร�ȡ����...");
        return 0;
        }
  utmp_mode(M_LOVE);
  clear(); 
  vs_bar("����������");
 
  if((acct_get("Ҫд��˭��",&xacct)<1))
// if (!vget(1, 0, "д��˭?(���հ׼��г�վ��ʹ����)��", userid, IDLEN + 1, GET_USER))
   {
    vmsg(err_uid);
    return 0;
  }

  strcpy(userid,xacct.userid);
 
 vget(2, 0, "����:", ve_title, 60, 1);
 if(!ve_title) 
  strcpy(ve_title, "I Love You...");
  
  usr_fpath(fpath, cuser.userid, "lovepaper");
  unlink(fpath);
  if (!(fd = fopen(fpath, "w")))
    {vmsg("����ʧ��!"); return 0;}
  
  
  srand(time(0));
  if(fp = fopen(LOVE_PAPER,"r+"))
  {
    //clear();
    mode = 0;
    style = 0;
    while(fgets(buf,sizeof(buf),fp))
    {
      if(strstr(buf,"#"))
        continue;
      switch(mode)
      {
        case 0:
          if(strstr(buf,header[style]))
          {
            if(strstr(buf,P_POEM))
            {
              mode++;
              break;
            }
            fgets(buf,sizeof(buf),fp);
            page = atoi(buf);
            rpage = rand() % page;
          }
          else
            break;
          line = 0;
          for(cpage = 0;cpage < page;)
          {
            if(!fgets(buf,sizeof(buf),fp))
              break;
            if(cpage == rpage)
             { //prints("%s",buf);
              fprintf(fd,"%s",buf);
             }
            line++;
            if(line >= h_line[style])
            {
              cpage++;
              line = 0;
            }
          }
          style++;
          break;
        case 1:
          //prints("--\n");
          fprintf(fd,"--\n");
          page = atoi(buf);
          rpage = rand() % page;
          line = 0;
          for(cpage = 0;cpage < page;)
          {
            if(!fgets(buf,sizeof(buf),fp))
              break;
            if(strstr(buf,"$"))
            {
              line = 1;
            }
            else if(cpage == rpage)
              {//prints("%s",buf);
              fprintf(fd,"%s",buf);}
            if(line)
            {
              cpage++;
              line = 0;
            }
          }
          break;
      }
    }
    fclose(fp);
  }
    fclose(fd);
  curredit = EDIT_MAIL;         /* Thor.1105: ֱ��ָ��д�� */
  if (vedit(fpath, YEA) == -1)
  {
    unlink(fpath);
    clear();
    return -2;
  }
    clear();
    prints("���鼴���ĸ� %s\n����Ϊ��%s\nȷ��Ҫ�ĳ���? (Y/N) [Y]",
    userid, ve_title);
    switch (vkey())
    {
    case 'n':
    case 'N':
      outs("N\n�ż���ȡ��");
      refresh();
      rc = -2;
      break;

    default:
      outs("Y\n���Ժ�, �ż�������...\n");
      refresh();
      break;
 } 
      usr_fpath(folder, userid, fn_dir);
      hdr_stamp(folder, HDR_LINK, &mhdr, fpath);
      strcpy(mhdr.owner, cuser.userid);
      strcpy(mhdr.nick, cuser.username);        /* :chuan: ���� nick */
      strcpy(mhdr.title, ve_title);
      rc = rec_add(folder, &mhdr, sizeof(mhdr));
      unlink(fpath);
      vmsg("����ĳ�ȥඣ�");
      m_biff(xacct.userno);

      acct_load(&cuser,cuser.userid);
      cuser.money -= 100;
      acct_save(&cuser);

  return 0;  
}
#endif	/* _HAVE_MONEY_ISM_ */
