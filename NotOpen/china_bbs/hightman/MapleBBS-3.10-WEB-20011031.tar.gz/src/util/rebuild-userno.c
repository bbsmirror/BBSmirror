/*-------------------------------------------------------*/
/* util/makeuserno.c                                     */
/*-------------------------------------------------------*/
/* author : hightman.bbs@bbs.dot66.net         		 */
/* target : �Զ����� userno �ظ��ĳ�ʽ	                 */
/* create : 2001/07/08                                   */
/* update :                                              */
/*-------------------------------------------------------*/
/* syntax : makeuserno                                   */
/* NOTICE : ת������[������������Ѷ��¼]            	 */
/*          [������վ֪ͨ]                               */
/*-------------------------------------------------------*/
/* friend, bmw, frienz 					 */

#include "bbs.h"

#undef	FAKE_IO

typedef struct
{ 
  char userid[IDLEN+1];
}	MAP;
MAP map[70000];  /* ������ע���ʺŵ������< 60000 */


int total;
void pal_sync(char *fpath);

static int
int_cmp(a, b)
  int *a;
  int *b;
{
  return *a - *b;
}

static void
bimage(brd)
  char *brd;
{
  int fd;
  char fpath[128];

  brd_fpath(fpath, brd, "friend");
  if ((fd = open(fpath, O_RDONLY)) >= 0)
  {
    struct stat st;
    PAL *pal, *up;
    int count;

    fstat(fd, &st);
    if (pal = (PAL *) malloc(count = st.st_size))
    {
      count = read(fd, pal, count) / sizeof(PAL);
      if (count > 0)
      {
        int *userno;
        int c = count;

        userno = (int *) up = pal;
        do
        {
          *userno++ = up->userno; //(up->ftype == PAL_BAD) ? -(up->userno) : up->userno;
          up++;
        } while (--c);

        if (count > 1)
          xsort(pal, count, sizeof(int), int_cmp);

        brd_fpath(fpath,brd, "fimage");
#ifndef FAKE_IO        
        if ((count = open(fpath, O_WRONLY | O_CREAT | O_TRUNC, 0600)) >= 0)
        {
          write(count, pal, (char *) userno - (char *) pal);
          close(count);
        }
#endif
        printf("BRD : %s  OK~\n",brd);
      }
      else
      {
#ifndef FAKE_IO
        brd_fpath(fpath, brd, "fimage");
        unlink(fpath);
#endif
        printf("BRD : %s  UNLINK~\n",brd);
      }
      free(pal);
    }
    close(fd);
  }
  else
  {
#ifndef FAKE_IO
    brd_fpath(fpath, brd, "fimage");
    unlink(fpath);
#endif
    printf("BRD : %s  UNLINK~\n",brd);
  }
}

void
resetbrd()
{
  struct dirent *de;
  DIR *dirp;
  char buf[128],*ptr;

  if (!(dirp = opendir("brd")))
  {
    return;
  }

  while (de = readdir(dirp))
  {
    ptr = de->d_name;
    if (ptr[0] > ' ' && ptr[0] != '.')
    {
      sprintf(buf,"brd/%s/friend",ptr);
      pal_sync(buf);
      bimage(ptr);
    }
  }
  closedir(dirp);
}

static int 
finduserno(userid)
  char *userid;
{
  int i;
  for(i=1;i<=total;i++)
  {
    if(!strcmp(map[i].userid,userid))
      return i;
  }
  return 0;
}

void
bmw_sync(userid,userno)
  char *userid;
  int userno;
{
  int fd;
  char fpath[128];

  usr_fpath(fpath, userid, FN_BMW);
  fd = f_open(fpath);
  if (fd >= 0)
  {
        FILE *fout;
        char folder[80],buf[128];
        HDR fhdr;

        usr_fpath(folder, userid, ".DIR");
#ifndef FAKE_IO
        if (fout = fdopen(hdr_stamp(folder, 0, &fhdr, buf), "w"))
        {
          BMW bmw;

          while (read(fd, &bmw, sizeof(BMW)) == sizeof(BMW))
          {
            struct tm *ptime = localtime(&bmw.btime);

            fprintf(fout, "%s%s(%02d:%02d)��%s\033[m\n",
              bmw.sender == userno ? "��" : "\033[32m��",
              bmw.userid, ptime->tm_hour, ptime->tm_min, bmw.msg);
          }
          fclose(fout);
        }
        close(fd);

        fhdr.xmode = MAIL_READ | MAIL_NOREPLY;
        strcpy(fhdr.title, "[�� �� ¼] ��Ѷ��¼");
        strcpy(fhdr.owner, userid);
        rec_add(folder, &fhdr, sizeof(fhdr));
        unlink(fpath);
#endif        
  }
}

void
pal_sync(fpath)
  char *fpath;
{
  int fd, size=0;
  struct stat st;

  if ((fd = open(fpath, O_RDWR, 0600)) < 0)
    return;

  if (!fstat(fd, &st) && (size = st.st_size) > 0)
  {
    PAL *pbase, *phead, *ptail;
    int userno;

    pbase = phead = (PAL *) malloc(size);
    size = read(fd, pbase, size);
    if (size >= sizeof(PAL))
    {
      ptail = (PAL *) ((char *) pbase + size);
      while (phead < ptail)
      {
        if (userno = finduserno(phead->userid))
        {
          phead->userno = userno;
          phead++;
          continue;
        }

        ptail--;
        if (phead >= ptail)
          break;
        memcpy(phead, ptail, sizeof(PAL));
      }

      size = (char *) ptail - (char *) pbase;
      if (size > 0)
      {
        if (size > sizeof(PAL))
          xsort(pbase, size / sizeof(PAL), sizeof(PAL), str_cmp);
#ifndef	FAKE_IO
        lseek(fd, 0, SEEK_SET);
        write(fd, pbase, size);
        ftruncate(fd, size);
#endif
        printf("PATH : %s  PAL : %d\n",fpath,size/sizeof(PAL));
      }
    }
    free(pbase);
  }
  close(fd);
  
#ifndef FAKE_IO
  if (size <= 0)
    unlink(fpath);
#endif
}

void
frienz_sync(userid)
  char *userid;
{
  int fd;
  char fpath[128];

  usr_fpath(fpath, userid, FN_FRIEND_BENZ);
  if ((fd = open(fpath, O_RDONLY)) >= 0)
  {
    struct stat st;
    BMW *bmw, *up;
    int count;

    fstat(fd, &st);
    if (bmw = (BMW *) malloc(count = st.st_size))
    {
      count = read(fd, bmw, count) / sizeof(BMW);
  	  close(fd);
      if (count > 0)
      {
        int c = count;

        up = bmw;
        do
        {
		  up->recver = finduserno(up->userid);
		  up->sender = c;
          up++;
        } while (--c);

        if (count > 1)
          xsort(bmw, count, sizeof(int), int_cmp);		 
		if ((fd = open(fpath, O_WRONLY | O_CREAT | O_TRUNC, 0600)) >= 0)
        {
          write(fd, bmw, st.st_size);
          close(fd);
        }
        printf("User : %s  Frienz OK~\n",userid);
	  }
     }
	}

}

static void
reaper(userid)
  char *userid;
{
  int fd;

  char buf[256];
  ACCT acct;

  usr_fpath(buf, userid, FN_ACCT);
  fd = open(buf, O_RDWR, 0);
  if (fd < 0)
     return;

  if(read(fd, &acct, sizeof(acct))!=sizeof(acct))
  {
    close(fd);
    return;
  }
  bmw_sync(acct.userid,acct.userno);

  acct.userno = total;
  strcpy(map[total++].userid,acct.userid);

#ifndef FAKE_IO  
  lseek(fd, 0, SEEK_SET);
  write(fd, &acct, sizeof(ACCT));
#endif
  printf("%-14s : %d\n",acct.userid,acct.userno);

  close(fd);
}

static void
optimize(userid)
  char *userid;
{

  char buf[256];
  usr_fpath(buf, userid, FN_PAL);
  pal_sync(buf);
  frienz_sync(userid);
#ifndef FAKE_IO
  usr_fpath(buf, userid, FN_BENZ);
  unlink(buf);
#endif
}


static void
traverse(fpath,mode)
  char *fpath;
  int mode;
{
  DIR *dirp;
  struct dirent *de;
  char *fname;

  if (!(dirp = opendir(fpath)))
  {
    return;
  }

  while (de = readdir(dirp))
  {
    fname = de->d_name;
    if (fname[0] > ' ' && fname[0] != '.')
    {
      if(mode == 1)
        reaper(fname);
      else if(mode == 2)
        optimize(fname);
    }
  }
  closedir(dirp);
}

int 
main(void)
{
  int ch,mode;
  char *fname, fpath[256];

  setgid(BBSGID);
  setuid(BBSUID);
  chdir(BBSHOME);

  total = 1;

  strcpy(fname = fpath, "usr/@");
  fname = (char *) strchr(fname, '@');

  for(mode = 1 ; mode <= 2 ; mode++)
  {
    for (ch = 'a'; ch <= 'z'; ch++)
    {
      fname[0] = ch;
      fname[1] = '\0';
      traverse(fpath,mode);
    }
    for (ch = '0'; ch <= '9'; ch++)
    {
      fname[0] = ch;
      fname[1] = '\0';
      traverse(fpath,mode);
    }
    if(mode == 2)
      break;
    total--;
  }
  resetbrd();
#ifndef FAKE_IO  
  {
    SCHEMA slot;
    int fd,num;
    
    fd = open(".USR.new", O_CREAT | O_TRUNC | O_WRONLY, 0600);
    for(num = 1; num <= total; num++)
    {
      memset(&slot, 0, sizeof(SCHEMA));
      strcpy(slot.userid, map[num].userid);
      time(&slot.uptime);
      write(fd, &slot, sizeof(SCHEMA));
    }
    close(fd);
  }
#endif  
  
  printf("total user %d\n",total);
  return 0;
}
