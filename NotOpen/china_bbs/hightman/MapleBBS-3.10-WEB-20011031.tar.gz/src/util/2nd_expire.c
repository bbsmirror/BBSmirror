/*-------------------------------------------------------*/
/* util/2nd_expire.c	( NTHU CS MapleBBS Ver 3.10 )	 */
/*-------------------------------------------------------*/
/* target : �����г�����ɾ����ʽ			 */
/* create : 00/05/05				 	 */
/* update : 						 */
/*-------------------------------------------------------*/
/* author : Ernie.bbs@bbs.cs.nthu.edu.tw		 */
/*-------------------------------------------------------*/

#include "bbs.h" 
#define EXP 90 
void 
expire_grp() 
{ 
#ifdef HAVE_SEC_HAND	/* hightman.011028: ����в��б�Ҫ */	
int pos, fd; 
char fgrp[80], fold[80], fnew[80]; 
SLOT grp; 
pos = 0; 
sprintf(fgrp, "2nd/%s", FN_GRP); 
sprintf(fnew, "2nd/%s.new", FN_GRP); 
fd = open(fnew, O_CREAT | O_TRUNC, 0600); // touch a new file 
if(fd > 0) close(fd); 
while(rec_get(fgrp, &grp, sizeof(SLOT), pos) != -1) 
{ 
if(grp.prop & PROP_G_CANCEL) 
{ 
sprintf(fold, "2nd/%s", grp.fn); 
f_rm(fold); 
} 
else 
{ 
rec_add(fnew, &grp, sizeof(SLOT)); 
} 
pos++; 
} 
sprintf(fold, "2nd/%s.old", FN_GRP); 
f_cp(fgrp, fold, O_TRUNC); 
f_mv(fnew, fgrp);

#endif /* _HAVE_SEC_HAND_ */
return; 
} 
void 
expire_item() 
{ 
#ifdef HAVE_SEC_HAND	/* hightman.011028: ����в��б�Ҫ */	

int pos, pos1, fd; 
char fgrp[80], fitem[80], fname[80], fold[80], fnew[80]; 
time_t expire; 
SLOT grp, item; 
expire = time(0) - EXP * 86400; 
pos = pos1 = 0; 
sprintf(fgrp, "2nd/%s", FN_GRP); 
while(rec_get(fgrp, &grp, sizeof(SLOT), pos) != -1) 
{ 
sprintf(fitem, "2nd/%s/%s", grp.fn, FN_ITEM); 
sprintf(fnew, "2nd/%s/%s.new", grp.fn, FN_ITEM); 
fd = open(fnew, O_CREAT | O_TRUNC, 0600); // touch a new file 
if(fd > 0) close(fd); 
fd = 0; 
while(rec_get(fitem, &item, sizeof(SLOT), pos1) != -1) 
{ 
if((item.prop & PROP_I_CANCEL) || (item.chrono < expire)) 
{ 
sprintf(fname, "2nd/%s/%c/%s", grp.fn, item.fn[7], item.fn); 
f_rm(fname); 
} 
else 
{ 
fd++; 
rec_add(fnew, &item, sizeof(SLOT)); 
} 
pos1++; 
} 
sprintf(fold, "2nd/%s/%s.old", grp.fn, FN_ITEM); 
f_cp(fitem, fold, O_TRUNC); 
f_mv(fnew, fitem); 
grp.reply = fd; 
rec_put(fgrp, &grp, sizeof(SLOT), pos); 
pos++; 
}
#endif /* _HAVE_SEC_HAND_ */
return; 
} 
int 
main() 
{ 
expire_grp(); 
expire_item(); 
return 0; 
} 

