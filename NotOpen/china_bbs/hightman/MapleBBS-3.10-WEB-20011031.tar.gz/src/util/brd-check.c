/*-------------------------------------------------------*/
/* util/expire.c	( NTHU CS MapleBBS Ver 3.00 )	 */
/*-------------------------------------------------------*/
/* target : �Զ����Ź��߳�ʽ				 */
/* create : 95/03/29				 	 */
/* update : 97/03/29				 	 */
/*-------------------------------------------------------*/
/* syntax : expire [day] [max] [min]		 	 */
/*-------------------------------------------------------*/


#include <strings.h>


#include "bbs.h"


#define	DEF_DAYS	30
#define	DEF_MAXP	2200
#define	DEF_MINP	100


#define	EXPIRE_CONF	"etc/expire.conf"
#define	EXPIRE_LOG	"run/expire.log"


typedef struct
{
  char bname[16];		/* board ID */
  int days;			/* expired days */
  int maxp;			/* max post */
  int minp;			/* min post */
}      life;


/* ----------------------------------------------------- */
/* exclusively create file [*.n]			 */
/* ----------------------------------------------------- */


static int
x_open(fold, fnew)
  char *fold;
  char *fnew;
{
  register int fd, try;
  struct stat st;
  extern int errno;

  try = 0;
  sprintf(fnew, "%s.n", fold);

  for (;;)
  {
    fd = open(fnew, O_WRONLY | O_CREAT | O_EXCL, 0600);
    if ((fd >= 0) || (errno != EEXIST))
      break;

    if (!try++)
    {
      if (stat(fnew, &st) < 0)
	break;
      if (st.st_mtime < time(NULL) - 20 * 60)	/* ���� 20 ������Ӧ�ô����� */
	unlink(fnew);
    }
    else
    {
      if (try > 24)		/* �ȴ� 240 ���� */
	break;
      sleep(10);
    }
  }
  return fd;
}


static void
expire(flog, brd)
  FILE *flog;
  life *brd;
{
  HDR hdr;
  struct stat state;
  char fpath[128], fnew[128], index[128], *fname, *bname;
  int fdr, fdw, done, keep, total, xmode;

  int days, maxp, minp;
  int duetime;

  days = brd->days;
  maxp = brd->maxp;
  minp = brd->minp;
  bname = brd->bname;

  fprintf(flog, "%s\n", bname);

  sprintf(index, "%s/.DIR", bname);
  if ((fdr = open(index, O_RDONLY)) < 0)
  {
    fprintf(flog, "\tError open file: %s\n", index);
    return;
  }

  fdw = x_open(index, fnew);
  if (fdw < 0)
  {
    fprintf(flog, "\tExclusive lock: %s\n", fnew);
    close(fdr);
    return;
  }

  strcpy(fpath, index);
  bname = (char *) strrchr(fpath, '.');
  fname = bname + 1;
  *fname++ = '/';

  done = 1;
  duetime = time(NULL) - days * 24 * 60 * 60;

  fstat(fdr, &state);
  total = state.st_size / sizeof(hdr);

  while (read(fdr, &hdr, sizeof hdr) == sizeof hdr)
  {
    xmode = hdr.xmode;
    if (xmode & (POST_CANCEL | POST_DELETE))
      keep = 0;
    else if (xmode & POST_MARKED || total <= minp)
      keep = 1;
    else if (hdr.chrono < duetime || total > maxp)
      keep = 0;
    else
      keep = 1;

    if (keep)
    {
      if (write(fdw, &hdr, sizeof hdr) != sizeof hdr)
      {
	fprintf(flog, "\tError in write DIR.n: %s\n", hdr.xname);
	done = 0;
	break;
      }
    }
    else
    {
      *bname = hdr.xname[7];
      strcpy(fname, hdr.xname);
      unlink(fpath);
      fprintf(flog, "\t%s\n", fname);
      total--;
    }
  }
  close(fdr);
  close(fdw);

  if (done)
  {
    sprintf(fpath, "%s.o", index);
    if (!rename(index, fpath))
    {
      if (!rename(fnew, index))
	return;
      rename(fpath, index);		/* ������ */
    }
  }
  unlink(fnew);
}


main(argc, argv)
  int argc;
  char *argv[];
{
  FILE *fp;
  int number, count;
  life db, table[MAXBOARD], *key;
  struct dirent *de;
  DIR *dirp;
  char *ptr, *bname, buf[256];

  db.days = ((argc > 1) && (number = atoi(argv[1])) > 0) ? number : DEF_DAYS;
  db.maxp = ((argc > 2) && (number = atoi(argv[2])) > 0) ? number : DEF_MAXP;
  db.minp = ((argc > 3) && (number = atoi(argv[3])) > 0) ? number : DEF_MINP;

  /* --------------------------------------------------- */
  /* load expire.ctl					 */
  /* --------------------------------------------------- */


  setgid(BBSGID);
  setuid(BBSUID);
  chdir(BBSHOME);

  count = 0;
  if (fp = fopen(EXPIRE_CONF, "r"))
  {
    while (fgets(buf, sizeof(buf), fp))
    {
      if (buf[0] < '0')
	continue;

      bname = (char *) strtok(buf, " \t\r\n");
      if (bname && *bname)
      {
	ptr = (char *) strtok(NULL, " \t\r\n");
	if (ptr && (number = atoi(ptr)) > 0)
	{
	  key = &(table[count++]);
	  strcpy(key->bname, bname);
	  key->days = number;
	  key->maxp = db.maxp;
	  key->minp = db.minp;

	  ptr = (char *) strtok(NULL, " \t\r\n");
	  if (ptr && (number = atoi(ptr)) > 0)
	  {
	    key->maxp = number;

	    ptr = (char *) strtok(NULL, " \t\r\n");
	    if (ptr && (number = atoi(ptr)) > 0)
	    {
	      key->minp = number;
	    }
	  }
	}
      }
    }
    fclose(fp);
  }

  if (count > 1)
  {
    qsort(table, count, sizeof(life), strcasecmp);
  }

  /* --------------------------------------------------- */
  /* visit all boards					 */
  /* --------------------------------------------------- */

  fp = fopen(EXPIRE_LOG, "w");

  if (chdir("brd") || !(dirp = opendir(".")))
  {
    fprintf(fp, ":Err: unable to visit boards %s\n");
    fclose(fp);
    exit(-1);
  }

  while (de = readdir(dirp))
  {
    ptr = de->d_name;
    if (ptr[0] > ' ' && ptr[0] != '.')
    {
      if (count)
      {
	key = (life *) bsearch(ptr, table, count, sizeof(life), strcasecmp);
	if (!key)
	  key = &db;
      }
      else
      {
	key = &db;
      }
      strcpy(key->bname, ptr);
      expire(fp, key);
    }
  }
  closedir(dirp);
  fclose(fp);
  exit(0);
}
