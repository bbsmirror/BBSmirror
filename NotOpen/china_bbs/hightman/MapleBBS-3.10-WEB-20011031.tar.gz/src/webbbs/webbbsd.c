/*-------------------------------------------------------*/
/* webBBSD.c     ( ZJU Shanty MapleBBS Ver 3.10 )        */
/*-------------------------------------------------------*/
/* target : super WEB daemon for BBS server		 */
/* author : hightman.bbs@bbs.dot66.net			 */
/* create : 2001/09/20                                   */
/* update :                                              */
/*-------------------------------------------------------*/

/* _WEBBBSD_C_ */
#define _MAIN_C_

#include "bbs.h"
#include "dns.h"

#include <sys/wait.h>
#include <netinet/tcp.h>
#include <sys/resource.h>


extern UCACHE *ushm;
//char rusername[40];
u_long tn_addr;

/* ----------------------------------------------------- */
/* web_main program                                      */
/* ----------------------------------------------------- */
static int
web_main()
{
  int	(*func) ();		 
  if(func = wrc_func_get(&myWRC))
  {
   (*func) ();
   return 1;  	
  }
  else
  {
   www_printf("<html>�Ҳ�����Ӧ������</html>\n");
   return 0;
  }
}

/* ----------------------------------------------------- */
/* trap signals                                          */
/* ----------------------------------------------------- */

static void
tn_signals()
{
  struct sigaction act;

  sigemptyset(&act.sa_mask);
  act.sa_flags = 0;

  act.sa_handler = (void *) abort_bbs;
  sigaction(SIGBUS, &act, NULL);
  sigaction(SIGSEGV, &act, NULL);
  sigaction(SIGTERM, &act, NULL);
  sigaction(SIGXCPU, &act, NULL);
#ifdef SIGSYS
  sigaction(SIGSYS, &act, NULL);/* bad argument to system call */
#endif

  act.sa_handler = (void *) my_rqst;
  sigaction(SIGUSR1, &act, NULL);
  
  act.sa_handler = (void *) bmw_rqst;
  sigaction(SIGUSR2, &act, NULL);

/*  act.sa_handler = (void *) anti_idle;
  sigaction(SIGALRM, &act, NULL);
  */
  
  /* �ڴ˽��� sigset_t act.sa_mask */
  sigaddset(&act.sa_mask, SIGPIPE);
  sigprocmask(SIG_BLOCK, &act.sa_mask, NULL);
  
  /* �����������������PIPE signal */
  signal(SIGPIPE, SIG_IGN);
}


static inline void
tn_main()
{
  char buf[128], query[100], *ptr;
    
  if(www_gets(buf, 128) < 0) abort_bbs();
     
  
  ptr = strchr(buf, '?');
  
  if(!ptr) abort_bbs(); /* ����ĵ��÷��� */
  *ptr = '\0';  
  
  strcpy(myWRC.funckey, buf);  
  strcpy(query, ptr+1);
  
  ptr = query;
   
  myWRC.group = atoi(nextword(&ptr));
   
  if(myWRC.group < 0 || myWRC.group > G_MAX)
  {
   strcpy(myWRC.query, query);
   
   myWRC.group = G_LOGIN;
  }
  else
  strcpy(myWRC.query, ptr);
  
  tn_signals();
  web_main();			/* Main ProgRam */
  abort_bbs();                  /* to make sure it will terminate */
}



/* ----------------------------------------------------- */
/* stand-alone daemon                                    */
/* ----------------------------------------------------- */


static void
start_daemon(port)
  int port; /* Thor.981206: ȡ 0 ���� *û�в���* , -1 ���� -i (inetd) */
{
  int n;
  struct linger ld;
  struct sockaddr_in sin;
  struct rlimit rl;
  char buf[80], data[80];
  time_t val;

  /*
   * More idiot speed-hacking --- the first time conversion makes the C
   * library open the files containing the locale definition and time zone.
   * If this hasn't happened in the parent process, it happens in the
   * children, once per connection --- and it does add up.
   */

  time(&val);
  strftime(buf, 80, "%d/%b/%Y %H:%M:%S", localtime(&val));

  /* --------------------------------------------------- */
  /* adjust resource : 16 mega is enough                 */
  /* --------------------------------------------------- */

  rl.rlim_cur = rl.rlim_max = 16 * 1024 * 1024;
  setrlimit(RLIMIT_DATA, &rl);

#ifdef SOLARIS
#define RLIMIT_RSS RLIMIT_AS
  /* Thor.981206: port for solaris 2.6 */
#endif

  setrlimit(RLIMIT_RSS, &rl);

  rl.rlim_cur = rl.rlim_max = 0;
  setrlimit(RLIMIT_CORE, &rl);

  rl.rlim_cur = rl.rlim_max = 60 * 20;
  setrlimit(RLIMIT_CPU, &rl);

  /* --------------------------------------------------- */
  /* speed-hacking DNS resolve                           */
  /* --------------------------------------------------- */

  dns_init();

  /* --------------------------------------------------- */
  /* change directory to bbshome                         */
  /* --------------------------------------------------- */

  chdir(BBSHOME);
  umask(077);

  /* --------------------------------------------------- */
  /* detach daemon process                               */
  /* --------------------------------------------------- */

  close(1);
  close(2);

  if(port == -1) /* Thor.981206: inetd -i */
  {
    /* Give up root privileges: no way back from here    */
    setgid(BBSGID);
    setuid(BBSUID);
    
    n = sizeof(sin);
    if (getsockname(0, (struct sockaddr *) &sin, &n) >= 0)
     port = ntohs(sin.sin_port);

    sprintf(data, "%d\t%s\t%d\tinetd -i\n", getpid(), buf, port);
    f_cat(PID_FILE, data);
    return;
  }

  close(0);

  if (fork())
    exit(0);

  setsid();

  if (fork())
    exit(0);

  /* --------------------------------------------------- */
  /* fork daemon process                                 */
  /* --------------------------------------------------- */

  sin.sin_family = AF_INET;
  sin.sin_addr.s_addr = INADDR_ANY;

  if (port == 0) /* Thor.981206: port 0 ����û�в��� */
 
    port = WEB_PORT;

  n = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

  val = 1;
  setsockopt(n, SOL_SOCKET, SO_REUSEADDR, (char *) &val, sizeof(val));


  ld.l_onoff = ld.l_linger = 0;
  setsockopt(n, SOL_SOCKET, SO_LINGER, (char *) &ld, sizeof(ld));

  sin.sin_port = htons(port);
  if ((bind(n, (struct sockaddr *) &sin, sizeof(sin)) < 0) || (listen(n, QLEN) < 0))
    exit(1);

  /* --------------------------------------------------- */
  /* Give up root privileges: no way back from here      */
  /* --------------------------------------------------- */

  setgid(BBSGID);
  setuid(BBSUID);

  sprintf(data, "%d\t%s\t%d\n", getpid(), buf, port);
  f_cat(PID_FILE, data);
}


/* ----------------------------------------------------- */
/* reaper - clean up zombie children                     */
/* ----------------------------------------------------- */

static inline void
reaper()
{
  while (waitpid(-1, NULL, WNOHANG | WUNTRACED) > 0);
}

static void
main_term()
{
  exit(0);
}


static inline void
main_signals()
{
  struct sigaction act;

  sigemptyset(&act.sa_mask);      
  act.sa_flags = 0;

  act.sa_handler = reaper;
  sigaction(SIGCHLD, &act, NULL);

  act.sa_handler = main_term;
  sigaction(SIGTERM, &act, NULL);

/*
  act.sa_handler = SIG_IGN;
  sigaction(SIGHUP, &acct, NULL);
  sigaction(SIGPIPE, &acct, NULL);
  */

}


int
main(argc, argv)
  int argc;
  char *argv[];
{
  int csock;                    /* socket for Master and Child */
  int value, http_on=0;
  struct sockaddr_in sin;
  char *host;
  
  start_daemon(argc > 1 ? str_ncmp("-i",argv[1], 2) ? atoi(argv[1]) : -1 : 0); /* ͳһ��dao.p */
  main_signals();
  
  
  /* --------------------------------------------------- */
  /* attach shared memory & semaphore                    */
  /* --------------------------------------------------- */

#ifdef HAVE_SEM
  sem_init();
#endif
  ushm_init();
#if 0  
  bshm_init();
  fshm_init();
#endif  


  /* --------------------------------------------------- */
  /* main loop                                           */
  /* --------------------------------------------------- */


  for (;;)
  {
    value = 1;
    if (select(1, (fd_set *) & value, NULL, NULL, NULL) < 0)
      continue;

    value = sizeof(sin);
    csock = accept(0, (struct sockaddr *) &sin, &value);
    if (csock < 0)
    {
      reaper();
      continue;
    }

    /* ap_start++; */
    time(&ap_start); 

    if (fork())
    {
      close(csock);
      continue;
    }

    /* �ж��Ƿ���Ҫ�ͳ�HTTPͷ */
    {
    char buf[6];
    if(sock_gets(buf, 6, csock)<0) 
     {
     	close(csock); 
        continue;
     }
     if(!str_ncmp(buf, "GET /", 5)) /* ��Ҫ�ͳ�httpͷ, ��Ҫkeepalive */
     {
     	http_on=1;
     }      
    }
    
    dup2(csock, 0);
    close(csock);
    dup2(0, 1);
    dup2(0, 2);
    /* nice(3); */
    if(http_on) 
    {	
      www_printf("HTTP/1.1 200 OK\n");
      www_printf("Server: MapleBBS Web Ver 0.1 for ShantyBBS of ZJU\n");
      www_printf("Cache-Control: no-chache\n");
      www_printf("Pragma: no-cache\n");
      www_printf("Content-type: text/html\n\n");
      setsockopt(0, SOL_SOCKET, SO_KEEPALIVE, (char *) &http_on, sizeof(http_on));
      http_on = 0;
      
      tn_addr = sin.sin_addr.s_addr;
      host = inet_ntoa(sin.sin_addr);
      sprintf(fromhost, "!%s", host);      
    }
    /* ------------------------------------------------- */
    /* ident remote host / user name via RFC931          */
    /* ------------------------------------------------- */
    //tn_addr = sin.sin_addr.s_addr;
    /* Thor.990325: �޸�dns_ident����, ������if���� */
    //dns_ident(0, &sin, fromhost, rusername);    
    //tn_addr = sin.sin_addr.s_addr;
    //host = inet_ntoa(sin.sin_addr);
    //sprintf(fromhost, "!%s", host);
    //hightman: ����PHP�Ժ�����Ķ���ȫ������..:)
    tn_main();
  }
}
/* _WEBBBSD_C_ */
