/*-------------------------------------------------------*/
/* board.c      ( NTHU CS MapleBBS Ver 2.36 )            */
/*-------------------------------------------------------*/
/* target : ���塢Ⱥ�鹦��                               */
/* create : 95/03/29                                     */
/* update : 95/12/15                                     */
/*-------------------------------------------------------*/

/* _BOARD_C_ */

#include "bbs.h"

extern BCACHE *bshm;
char brd_bits[MAXBOARD];
static char *class_img;
static int mode_flag;	/* 0: ��ͨ 1: ��ժ */

#define	FN_FIMAGE	"fimage"
#undef	DEBUG


/* ----------------------------------------------------- */
/* �����Ķ���¼ .BRH (Board Reading History)             */
/* ----------------------------------------------------- */


typedef struct BoardReadingHistory
{
  time_t bstamp;                /* ���������ʱ��, unique */ /* Thor.brh_tail*/
  time_t bvisit;                /* �ϴ��Ķ�ʱ�� */ /* Thor.980902:û�õ�? */
                       		/* Thor.980904:δ��ʱ���ϴζ���ʱ��, ����ʱ�� bhno */
  int bcount;			/* Thor.980902:û�õ�? */
				/* Thor.980902:���Լ����� */
  /* --------------------------------------------------- */
  /* time_t {final, begin} / {final | BRH_SIGN}          */
  /* --------------------------------------------------- */
                           	/* Thor.980904:ע��: BRH_SIGN����final begin ��ͬ */
                           	/* Thor.980904:ע��: �ɴ�С����,����Ѷ�interval */
}                   BRH;


#define BRH_EXPIRE      180          /* Thor.980902:ע��:���������� */
#define BRH_MAX         200          /* Thor.980902:ע��:ÿ������м�����ǩ */
#define BRH_PAGE        2048         /* Thor.980902:ע��:ÿ�ζ�����, �ò����� */
#define BRH_MASK        0x7fffffff   /* Thor.980902:ע��:�����Ϊ2038��1����*/
#define BRH_SIGN        0x80000000   /* Thor.980902:ע��:zap��ѹfinalר�� */
#define BRH_WINDOW      (sizeof(BRH) + sizeof(time_t) * BRH_MAX * 2)


static int *brh_base;           /* allocated memory */
static int *brh_tail;           /* allocated memory */
static int brh_size;            /* allocated memory size */
static time_t brh_expire;


static int *
brh_alloc(tail, size)
  int *tail;
  int size;
{
  int *base, n;

  base = brh_base;
  n = (char *) tail - (char *) base;
  size += n;
  if (size > brh_size)
  {
    size += n >> 4;             /* ��ԤԼһЩ������ */
    base = (int *) realloc((char *) base, size);

    if (base == NULL)
      abort_bbs();

    brh_base = base;
    brh_size = size;
    tail = (int *) ((char *) base + n);
  }

  return tail;
}


static void
brh_put()
{
  int *list;

  /* compact the history list */

  list = brh_tail;

  if (*list)
  {
    int *head, *tail, n, item, chrono;

    n = *++list;   /* Thor.980904: ����ʱ��bhno */
    brd_bits[n] |= BRD_H_BIT;
    time((time_t *) list);    /* Thor.980904: ע��: bvisit time */

    item = *++list;
    head = ++list;
    tail = head + item;

    while (head < tail)
    {
      chrono = *head++;
      n = *head++;
      if (n == chrono) /* Thor.980904: ע��: ��ͬ��ʱ��ѹ���� */
      {
        n |= BRH_SIGN;
        item--;
      }
      else
      {
        *list++ = chrono;
      }
      *list++ = n;
    }

    list[-item - 1] = item;
    *list = 0;
    brh_tail = list;  /* Thor.980904:�µĿ�brh */
  }
}


static void
brh_get(bstamp, bhno)
  time_t bstamp;                /* board stamp */
  int bhno;
{
  int *head, *tail;
  int size, bcnt, item;
  char buf[BRH_WINDOW];

  if (bstamp == *brh_tail) /* Thor.980904:ע��:�ð����� brh_tail�� */
    return;

  brh_put();

  bcnt = 0;
  tail = brh_tail;

  if (brd_bits[bhno] & BRD_H_BIT)
  {
    head = brh_base;
    while (head < tail)
    {
      item = head[2];
      size = item * sizeof(time_t) + sizeof(BRH);

      if (bstamp == *head)
      {
        bcnt = item;
        memcpy(buf, head + 3, size);
        tail = (int *) ((char *) tail - size);
        if (item = (char *) tail - (char *) head)
          memcpy(head, (char *) head + size, item);
        break;
      }
      head = (int *) ((char *) head + size);
    }
  }

  brh_tail = tail = brh_alloc(tail, BRH_WINDOW);

  *tail++ = bstamp;
  *tail++ = bhno;

  if (bcnt)                     /* expand history list */
  {
    int *list;

    size = bcnt;
    list = tail;
    head = (int *) buf;

    do
    {
      item = *head++;
      if (item & BRH_SIGN)
      {
        item ^= BRH_SIGN;
        *++list = item;
        bcnt++;
      }
      *++list = item;
    } while (--size);
  }

  *tail = bcnt;
}


int
brh_unread(chrono)
  time_t chrono;
{
  int *head, *tail, item;

  if (chrono <= brh_expire)
    return 0;

  head = brh_tail + 2;
  if ((item = *head) > 0)
  {
    /* check {final, begin} history list */

    head++;
    tail = head + item;
    do
    {
      if (chrono > *head)
        return 1;

      head++;
      if (chrono >= *head)
        return 0;

    } while (++head < tail);
  }
  return 1;
}

void
brh_visit(mode)
  int mode;                     /* 0 : visit, 1: un-visit */
                                /* hightman.010412: ����chrono������������ */
{
  int *list;

  list = (int *) brh_tail + 2;
  *list++ = 2;
  if (mode)
  {
    *list = mode;
  }
  else
  {
    time((time_t *)list);
  }
  /* *++list = mode; */
   *++list = 0;
}

int
brh_add(prev, chrono, next)
  time_t prev, chrono, next;
{
  int *base, *head, *tail, item, final, begin;

  head = base = brh_tail + 2;
  item = *head++;
  tail = head + item;

  begin = BRH_MASK;

  while (head < tail)
  {
    final = *head;
    if (chrono > final)
    {
      if (prev <= final)
      {
        if (next < begin)       /* increase */
          *head = chrono;
        else
        {                       /* merge */
          *base = item - 2;
          base = head - 1;
          do
          {
            *base++ = *++head;
          } while (head < tail);
        }
        return;
      }

      if (next >= begin)
      {
        head[-1] = chrono;
        return;
      }

      break;
    }

    begin = *++head;
    head++;
  }

  /* insert or append */

  /* [21, 22, 23] ==> [32, 30] [15, 10] */

  if (item < BRH_MAX)
  {
    /* [32, 30] [22, 22] [15, 10] */

    *base = item + 2;
    tail += 2;
  }
  else
  {
    /* [32, 30] [22, 10] */  /* Thor.980923: how about [6, 7, 8] ? [15,7]? */

    tail--;
  }

  prev = chrono;
  for (;;)
  {
    final = *head;
    *head++ = chrono;

    if (head >= tail)
      return;

    begin = *head;
    *head++ = prev;

    if (head >= tail)
      return;

    chrono = final;
    prev = begin;
  }
}

/* ----------------------------------------------------- */
/* board permission check                                */
/* ----------------------------------------------------- */

static int
bm_belong(board)
  char *board;
{
  int fsize, count, result;
  char fpath[80];

  result = 0;

  brd_fpath(fpath, board, FN_FIMAGE);   /* Thor: fimageҪ�� sort��! */
  board = f_img(fpath, &fsize);

  if (board != NULL)
  {
    count = fsize / sizeof(int);
    if (count > 0)
    {
      int userno, *up;
      int datum, mid;

      userno = cuser.userno;
      up = (int *) board;

      while (count > 0)
      {
        datum = up[mid = count >> 1];
        if (userno == datum)
        {
          result = BRD_R_BIT | BRD_W_BIT;
          break;
        }
        if (userno > datum)
        {
          up += (++mid);
          count -= mid;
        }
        else
        {
          count = mid;
        }
      }
    }
    free(board);
  }
  return result;
}


static inline int
is_bm(list)
  char *list;                   /* ������BM list */
{
  int cc, len;
  char *userid;

  len = strlen(userid = cuser.userid);
  do
  {
    cc = list[len];
    if ((!cc || cc == '/') && !str_ncmp(list, userid, len))
    {
      return 1;
    }
    while (cc = *list++)
    {
      if (cc == '/')
        break;
    }
  } while (cc);

  return 0;
}


/*static inline */int
Ben_Perm(bhdr, ulevel)
  BRD *bhdr;
  usint ulevel;
{
  usint readlevel, postlevel, bits;
  char *blist, *bname;

  bname = bhdr->brdname;  
  if (!*bname)
    return 0;

  if (!str_cmp(bname, DEFAULT_BOARD))
    return (BRD_R_BIT | BRD_W_BIT);

  bits = 0;

  readlevel = bhdr->readlevel;
  if (!readlevel || (readlevel & ulevel))
  {
    bits = BRD_R_BIT;

    if (ulevel & PERM_POST)
    {
      postlevel = bhdr->postlevel;
      if (!postlevel || (postlevel & ulevel))
        bits |= BRD_W_BIT;
    }
  }

  /* (moderated) ���ܿ��壺�˶Կ���֮�������� */

#ifdef HAVE_MODERATED_BOARD
  if (readlevel == PERM_SYSOP)
  {
    /* extern int bm_belong(); */
    bits = bm_belong(bname);  /* Thor.980813: �����ܿ������, �������жϵ� */
  }
#endif

  /* Thor.980813: ע��: �ر�Ϊ BM ����, bm �иð������Ȩ�� */ 
  blist = bhdr->BM; 
  if ((ulevel & PERM_BM) && blist[0] > ' ' && is_bm(blist))
    return (BRD_R_BIT | BRD_W_BIT | BRD_X_BIT);

  return bits;
}


/* ----------------------------------------------------- */
/* ���� currboard ���������趨                           */
/* ----------------------------------------------------- */


int
bstamp2bno(stamp)
  time_t stamp;
{ 
  BRD *brd;
  int bno, max;

  bno = 0;
  brd = bshm->bcache;
  max = bshm->number;
  for (;;)
  {
    if (stamp == brd->bstamp)
      return bno;
    if (++bno >= max)
      return -1;
    brd++;
  }
}

static inline void
brh_load()
{
  BRD *brdp, *bend;
  usint ulevel;
  int n, cbno;
  char *bits;

  int size, *base;
  time_t expire;
  char fpath[64];

  ulevel = cuser.userlevel;
  n = (ulevel & PERM_ALLBOARD) ? (BRD_R_BIT | BRD_W_BIT | BRD_X_BIT) : 0;
  memset(bits = brd_bits, n, sizeof(brd_bits));

#ifdef DEBUG
  www_printf("DEBUG: brh_loading: ulevel->%d  n= %d\n", ulevel, n);
#endif 

  if (n == 0)
  {  	
    brdp = bshm->bcache;
    bend = brdp + bshm->number;
    do
    {    	
      *bits++ = Ben_Perm(brdp, ulevel);
    } while (++brdp < bend);
  }

#ifdef DEBUG
  www_printf("DEBUG: brh_loading: loading it to memory \n");
#endif 
  /* --------------------------------------------------- */
  /* �� .BRH ���� memory                                 */
  /* --------------------------------------------------- */

  size = 0;
  cbno = -1;
  brh_expire = expire = time(0) - BRH_EXPIRE * 86400;

  if (ulevel)
  {
    struct stat st;

    usr_fpath(fpath, cuser.userid, FN_BRH);
    if (!stat(fpath, &st))
      size = st.st_size;
  }
  /* --------------------------------------------------- */
  /* �ౣ�� BRH_WINDOW �������ռ�                        */
  /* --------------------------------------------------- */
  
  /* brh_size = n = ((size + BRH_WINDOW) & -BRH_PAGE) + BRH_PAGE; */
  brh_size = n = size + BRH_WINDOW;
  brh_base = base = (int *) malloc(n);                   

  
  if (size && ((n = open(fpath, O_RDONLY)) >= 0))
  {
    int *head, *tail, *list, bstamp, bhno;
  
    size = read(n, base, size);
    close(n);
    
    /* compact reading history : remove dummy/expired record */
    
    head = base;
    tail = (int *) ((char *) base + size);
    bits = brd_bits;
     	    
    while (head < tail)
    {
      bstamp = *head;
      if (bstamp & BRH_SIGN)    /* zap */
      {      	
        bstamp ^= BRH_SIGN;
        bhno = bstamp2bno(bstamp);        
        if (bhno >= 0)
        {
          bits[bhno] |= BRD_Z_BIT;
        }
        head++;
        continue;
      }

      bhno = bstamp2bno(bstamp);
           
      list = head + 2;
      n = *list;
      size = n + 3;

      /* ���������ڡ�û�б� zap �������� read */

      if (bhno >= 0 && (bits[bhno] & BRD_R_BIT))
      {     	
        bits[bhno] |= BRD_H_BIT;/* �����Ķ���¼ */         
        cbno = bhno;
        if (n > 0)
        {

          list += n;   /* Thor.980904: ע��: ����һ��tag */
          do
          {         	
            bhno = *list;
            if ((bhno & BRH_MASK) > expire)
              break;

            if (!(bhno & BRH_SIGN))
            {
              if (*--list > expire)
                break;
              n--;
            }

            list--;
            n--;
          } while (n > 0);

          head[2] = n;
        }
        n = n * sizeof(time_t) + sizeof(BRH);
        if (base != head)
          memcpy(base, head, n);
        base = (int *) ((char *) base + n);
      }     
      head += size;
    }
  }

  *base = 0;
  brh_tail = base;
#ifdef DEBUG
  www_printf("DEBUG: brh_loading: loading OK?\n");
#endif 
  /* --------------------------------------------------- */
  /* �趨 default board                                  */
  /* --------------------------------------------------- */
  strcpy(currboard, "��δѡ��");
}



void
brh_save()
{
  int *base, *head, *tail, bhno, size;
  BRD *bhdr, *bend;
  char *bits;

  /* Thor.980830: lkchu patch:  ��û load �Ͳ��� save */ 
  if(!(base = brh_base))
    return;

#if 0
  base = brh_base;
#endif

  brh_put();

  /* save history of un-zapped boards */

  bits = brd_bits;
  head = base;
  tail = brh_tail;
  while (head < tail)
  {
    bhno = bstamp2bno(*head);
    size = head[2] * sizeof(time_t) + sizeof(BRH);
    if (bhno >= 0 && !(bits[bhno] & BRD_Z_BIT))
    {
      if (base != head)
        memcpy(base, head, size);
      base = (int *) ((char *) base + size);
    }
    head = (int *) ((char *) head + size);
  }

  /* save zap record */

  tail = brh_alloc(base, sizeof(time_t) * MAXBOARD);

  bhdr = bshm->bcache;
  bend = bhdr + bshm->number;
  do
  {
    if (*bits++ & BRD_Z_BIT)
    {
      *tail++ = bhdr->bstamp | BRH_SIGN;
    }
  } while (++bhdr < bend);

  /* OK, save it */

  base = brh_base;
  if ((size = (char *) tail - (char *) base) > 0)
  {
    char fpath[64];
    int fd;

    usr_fpath(fpath, cuser.userid, FN_BRH);
    if ((fd = open(fpath, O_WRONLY | O_CREAT | O_TRUNC, 0600)) >= 0)
    {
      write(fd, base, size);
      close(fd);
    }
  }
}


/* ----------------------------------------------------- */
/* BoardClass [����Ⱥ��]                                 */
/* ----------------------------------------------------- */

static int class_flag;
#define	BFO_YANK	0x01


/* ���ݷ��������ҷ��� */
static int
class_find(name)
  char *name;
{
  short *cbase, *chead, *ctail;
  int pos, chn;

  if (!class_img)
    return -1;
  cbase = (short *) class_img; 
  chn = 0;
  ctail = (short *)(cbase[0] - ((short)sizeof(short)));
#ifdef DEBUG  
  www_printf("DEBUG: will find: %s\n", name);
#endif
  do
  {
    pos = cbase[chn];

    chead = (short *) ((char *) cbase + pos);
#ifdef DEBUG    
    www_printf("DEBUG: searching...: %s\n", chead);
#endif    
    
    if(!strncmp((char *)chead,name,strlen(name)))
    {
      /* strcpy(currtitle, chead);	*//* ����currtitle */
      
      if(chn > 1)
      {
        if(*((char *)(chead)+strlen(name)) == '/')
          return chn;
      }
      else
        return chn;
    }
    chn++;
  } while ((short *)(chn * sizeof(short)) < ctail);

  return -1;
}
    

/* load the basic Class */

static int
class_load(xo)
  XO *xo;
{
  short *cbase, *chead, *ctail;
  int chn;			/* ClassHeader number */
  int pos, max, val;
  BRD *brd;
  char *bits;   

  chn = CH_END - xo->key;
  
  cbase = (short *) class_img;
  chead = cbase + chn;
  
  strcpy(currtitle, (char *) ((char *) cbase + cbase[chn]));
  
  pos = chead[0] + CH_TTLEN;
  max = chead[1];

  chead = (short *) ((char *) cbase + pos);
  ctail = (short *) ((char *) cbase + max);

  max -= pos;

  if (cbase = (short *) xo->xyz)
    cbase = (short *) realloc(cbase, max);
  else
    cbase = (short *) malloc(max);
    
  xo->xyz = (char *) cbase;

  max = 0;
  brd = bshm->bcache;
  bits = brd_bits;
  
  do
  {
    chn = *chead++;
    if (chn >= 0)
    {
      val = bits[chn];
      if (!(val & BRD_R_BIT) || !(brd[chn].brdname[0]))
        continue;
    }

    max++;
    *cbase++ = chn;
  } while (chead < ctail);

  xo->max = max;
  if (xo->top >= max)
    xo->top = 0;

  return max;
}


/* class body */
static int
class_body(xo)
  XO *xo;
{

  char *img, *bits;
  short *chp;
  BRD *bcache;
  int cnt, max, tail, brdnew, page;

  img = class_img;

  bcache = bshm->bcache;
  brdnew = class_flag & UFO_BRDNEW;
  bits = brd_bits;

  max = xo->max;
  cnt = xo->top;
  page = xo->pos;
  
  tail = cnt + XO_TALL;
  if ((max > tail) && (page >= 0))
    max = tail;  
    
  chp = (short *) xo->xyz + cnt;

  /* ��ʾ��Ϣ */
  www_printf("result=OK&max=%d&page=%d&title=%s\n", xo->max, page, currtitle);

  while(++cnt <= max)
  {
   int chn;
   char *str;
   
   chn = *chp++;
   if (chn >= 0)
   {
    BRD *brd;
    int num;

    brd = bcache + chn;
    if (brdnew)
    {
     int fd, fsize;
     char folder[64];
     struct stat st;
     HDR hdr; /* hightman.010414: �����ƻ��� */

     brd_fpath(folder, brd->brdname, fn_dir);
     if ((fd = open(folder, O_RDONLY)) >= 0 && !fstat(fd, &st))
     {
      if ((fsize = st.st_size) >= sizeof(HDR))
      {
       brd->bpost = fsize / sizeof(HDR);
       lseek(fd, fsize - sizeof(HDR), SEEK_SET);
       read(fd, &hdr, sizeof(HDR));
       brh_get(brd->bstamp, chn);
       str = (brh_unread(hdr.chrono) && !(hdr.xmode & (POST_CANCEL | POST_DELETE))) ? "\033[1;32m��\033[m" : "��";
      }
      else
      {
       brd->bpost = 0;
       str = "  ";
      }
      close(fd);
     }
     else
     {
      brd->bpost = 0;
      str = " ";
     }
     num = brd->bpost;
    }
    else
    {
     num = cnt;
     str = "  ";
    }
    www_printf("num=%d&str=%s&zap=%c&bname=%s&btitle=%s&vote=%c&BM=%s\n", num, str,
          bits[chn] & BRD_Z_BIT ? '-' : ' ',
          brd->brdname, brd->title, brd->bvote ? 'V' : ' ', brd->BM);
   }
   else
   {
    short *chx;
    
    chx = (short *) img + (CH_END - chn);    
    www_printf("num=%d&title=%s&chn=%d\n", cnt, img + *chx, CH_END - chn);   /* ���������� */
   }
  }
 return XO_NONE;
}  
  
  

static int
XoClass(ClassName, page, chn)
 char *ClassName;
 int page;
 int chn;
{
 XO xo;
 /*int chn;*/
 
 page = page - 1;	/* ��1� */
 
 xo.pos = page;
 xo.top = xo.max = 0;
 
 if(chn < 0) /* û�д���chn�Ļ���ȥ�� ClassName �Լ��� :p */
 { 
#ifdef DEBUG
   www_printf("DEBUG: try to find chn by ClassName: %s...\n", ClassName);
#endif  	
   chn = class_find(ClassName);
 }
 
#ifdef DEBUG
  www_printf("DEBUG: chn = %d...\n", chn);
#endif 
 if(chn < 0)  return 0;
 
  
 xo.key = CH_END - chn;
 
 xo.xyz = NULL;
 if (!class_load(&xo))
 {
    free(xo.xyz);
    return 0;
 }
 
 utmp_mode(M_CLASS);
 if(page < 0 || (page * XO_TALL) >= xo.max)
    xo.top = 0;
 else
    xo.top = page * XO_TALL;
    
 return class_body(&xo);
}




int b_list()	/* pid, class ���class�ǿգ����г�ȫ��? */
	   	/* ��һ���ո�俪����class, һ����ռһ�� */
	   	/* @BBS	, chn?				 */
{
 char *ptr, *ClassName;
 pid_t pid;
 int page, chn;
 
 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);

 
 if(!cutmp) msg_quit("������������pid��Ч!"); 
 
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("��������, ��������!"); 
  
 ClassName = nextword(&ptr);
 page = atoi(nextword(&ptr));
 if(page < 0) page = 0;	/* pageΪ0ʱ��ʾȫ�� */
 
 chn = atoi(nextword(&ptr)); /* ����chn�Ļ� */
 /*if(chn < 0) chn = 0;*/
  
 /* Board Main */
 {
  int fsize;  
  struct stat st;
  
  if (stat(FN_BRD, &st) || st.st_size <= 0)
    unlink(CLASS_IMGFILE);

  class_img = f_img(CLASS_IMGFILE, &fsize);

  if (class_img == NULL)
  {
    blog("CACHE", "class.img");
  }

  if (!cuser.userlevel)         /* guest yank all boards */
  {
    class_flag = BFO_YANK;
  }
  else
  {
    class_flag = cuser.ufo & UFO_BRDNEW;
  } 
    
  bshm_init();	/* �����ڴ��ʼ�� */   	
  brh_load();	/* Board History Loading */
 }
 
 return XoClass(ClassName, page, chn); 
}


/* ----------------------------------------------------	*/
/* Post List						*/
/* ----------------------------------------------------	*/

/* ----------------------------------------------------- */
/* ���� innbbsd ת���ż������߿���֮��������             */
/* ----------------------------------------------------- */


static void
outgo_post(hdr, board)
  HDR *hdr;
  char *board;
{
  char *fpath, buf[256];

  if (board)
  {
    fpath = "innd/out.bntp";
  }
  else
  {
    board = currboard;
    fpath = "innd/cancel.bntp";
  }

  sprintf(buf, "%s\t%s\t%s\t%s\t%s\n",
    board, hdr->xname, hdr->owner, hdr->nick, hdr->title);
  f_cat(fpath, buf);
}


static void
cancel_post(hdr)
  HDR *hdr;
{
  if ((hdr->xmode & POST_OUTGO) &&      /* ��ת�ż� */
    (hdr->chrono > ap_start - 7 * 86400))       /* 7 ��֮����Ч */
  {
    outgo_post(hdr, NULL);
  }
}

extern char xo_pool[];
static int post_body();


static int
post_init(xo)
  SXO *xo;
{
  xo_load(xo, sizeof(HDR));
  return post_body(xo);
}

static int
post_attr(fhdr)
  HDR *fhdr;
{   
  int mode, attr;
  
  mode = fhdr->xmode;

  if (mode & POST_CANCEL)
    return 'c';

  if (mode & POST_DELETE)
    return 'd';

  attr = brh_unread(fhdr->chrono) ? 0 : 0x20;
  mode &= (bbstate & STAT_BOARD) ? ~0 : ~POST_GEM;
  /* Thor:һ��user������G */

#ifdef HAVE_HOT_MODE
  if(!(mode & POST_MARKED) && !(mode &  POST_GEM) && (mode & POST_HOT))
    attr |= 'H';
  else
#endif
  if (mode &= (POST_MARKED | POST_GEM))
    attr |= (mode == POST_MARKED ? 'M' : (mode == POST_GEM ? 'G' : 'B'));

  else if (!attr)
    attr = '+';

  return attr;
}


static void
post_item(num, hdr, dir)
  int num;
  HDR *hdr;
  char *dir;
{

  static char *type[2] = {"Re", "��"};
  int ch, len, i;
  char *title, *mark, *date, author[13], attr[13];
  char fpath[64];
  struct stat st;
  
  
  date = hdr->date + 3;
  
  /* ����author */
  mark = hdr->owner;
  len = 13;
  i = 0;

  while (ch = *mark)
  {
    if ((--len == 0) || (ch == '@'))
      ch = '.';
    author[i++] = ch;
    
    if (ch == '.')
      break;

    mark++;
  }
  
  author[i] = '\0';
  
  /* ����title */
  title = str_ttl(mark = hdr->title);
  ch = (title == mark); /* �Ƿ����������? */  

  /* ��� */
  
  hdr_fpath(fpath, dir, hdr);
  stat(fpath, &st);
  len = st.st_size;

#ifdef  HAVE_DECORATE
#ifdef HAVE_HOT_MODE
 sprintf(attr, hdr->xmode & POST_HOT ? "\033[1;31m%c\033[m" : (hdr->xmode & POST_MARKED ? "\033[1;36m%c\033[m" : "%c"), post_attr(hdr));
#else
 sprintf(attr, hdr->xmode & POST_MARKED ? "\033[1;36m%c\033[m" : "%c", post_attr(hdr));
#endif
#else
  sprintf(attr, "%c", post_attr(hdr));
#endif

www_printf("num=%d&attr=%s&date=%s&author=%s&type=%s&title=%s&size=%d\n", num, attr, date, author, type[ch], title, len);

}


static int
post_body(xo)
  SXO *xo;
{
  HDR *fhdr;
  int num, max, tail;

  max = xo->max;
  if (max <= 0)
  {
   www_printf("Ŀǰ����<%s>��û��%s�~\n", currboard, (xo->key == XZ_POST ? "����" : "��ժ"));
   return XO_NONE;
  }
  else
   www_printf("result=OK&max=%d&page=%d&bname=%s&btitle=%s&BM=%s&isbm=%d&anony=%d\n",
   		 xo->max, xo->page, currboard, currtitle, currBM,
   		 (bbstate & STAT_BOARD ? 1 : 0), (bbstate & BRD_ANONYMOUS ? 1 : 0));

  num = xo->top;
  fhdr = (HDR *) xo_pool;
  tail = num + XO_TALL;
  if (max > tail)
    max = tail;

  do
  {
    post_item(++num, fhdr++, xo->dir);
  } while (num < max);
  
  return XO_NONE;
}


#ifdef LOG_BRD_USIES	/* lkchu.981201: �����Ķ���¼ */
void
brd_usies(void)
{
  char buf[256];

  sprintf(buf, "%s %s (%s)\n", currboard, cuser.userid, Now());
  f_cat(FN_BRD_USIES, buf);
}
#endif

int p_list()
{
 char *ptr, *BrdName;
 pid_t pid;
 int page;
 
 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("������������pid��Ч!"); 
 
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("��������, ��������!"); 
  
 BrdName = nextword(&ptr);
 
 page = atoi(nextword(&ptr));
 
 /* Board Main */    
 
 bshm_init();	/* �����ڴ��ʼ�� */   	
 brh_load();	/* Board History Loading */
 
 {
  int bno, bits;
  BRD *brd;
  char fpath[80], *str;
  SXO *xo;
  
  utmp_mode(M_BOARD);  
   
  bno = brd_bno(BrdName);
  
  if(bno<0) msg_quit("����Ŀ�������!");
  
  str = &brd_bits[bno];
  bits = *str;

  brd = bshm->bcache + bno; 
  bbstate = brd->battr;
  
  if (!(bits & BRD_R_BIT)) 
    msg_quit("�Բ���, ��û���Ķ�Ȩ��!");    
  else if (bits & BRD_X_BIT)
    bbstate |= (STAT_BOARD | STAT_POST);
  else if (bits & BRD_W_BIT)
    bbstate |= STAT_POST;

#ifdef  HAVE_MODERATED_BOARD
  if (brd->readlevel == PERM_SYSOP)
    bbstate |= STAT_MODERATED;
#endif
     
  strcpy(currboard, brd->brdname);  
  strcpy(currtitle, brd->title);
  strcpy(currBM, brd->BM);
  brh_get(brd->bstamp, bno);
  
  brd_fpath(fpath, BrdName, fn_dir);
  
  xo = xo_new(fpath);
  xo->page = page;
  xo->key = XZ_POST;
 
  post_init(xo);
  
  free(xo);    
  
#ifdef LOG_BRD_USIES	/* lkchu.981201: �Ķ������¼ */
  brd_usies();
#endif   
}

 bbstate = 0;
 return 1;	
}


/* ----------------------------------------------------	*/
/* Post Read						*/
/* ----------------------------------------------------	*/

static void
post_history(fhdr, num)
  HDR *fhdr;
  int num;
{
  int prev, chrono, next, pos;
  char fpath[80];
  HDR buf;

  chrono = fhdr->chrono;
  if (!brh_unread(chrono))
    return;

  brd_fpath(fpath, currboard, fn_dir);
  pos = num - 1;

  if (!rec_get(fpath, &buf, sizeof(HDR), pos))
    prev = buf.chrono;
  else
    prev = chrono;

  pos += 2;
  if (!rec_get(fpath, &buf, sizeof(HDR), pos))
    next = buf.chrono;
  else
    next = chrono;

  brh_add(prev, fhdr->chrono, next);
}


static int
post_read(num)	/* �Ķ�currboard�ĵ�numƪ���� */
 int num;
{
 char fpath[80];
 int fd;
 
 if(mode_flag) 
  brd_fpath(fpath, currboard, FN_GEM);
 else
  brd_fpath(fpath, currboard, fn_dir);

 if ((fd = open(fpath, O_RDONLY)) >= 0)
 {
    int max;
    struct stat st;
    char folder[80];
    HDR fhdr;
    
    fstat(fd, &st);
    max = st.st_size / sizeof(HDR);
    if(max <=0) 
      msg_quit("��д���󣬱��沢û�����£�");
    
    if(num > max) num = max;
    
    num = num -1; /* ����-1 */
    
    memset(&fhdr, 0, sizeof(HDR));
            
    lseek(fd, (off_t) (sizeof(HDR) * num), SEEK_SET);
    read(fd, &fhdr, sizeof(HDR));
    close(fd);

    if(fhdr.xmode & (POST_CANCEL | POST_DELETE))
      msg_quit("�����²����Ķ�!");
          
    post_history(&fhdr, num); /* �Ķ���¼ */
    www_printf("result=OK&max=%d&reply=%d&isbm=%d&bname=%s&btitle=%s&BM=%s&anony=%d&title=%s\n", 
    	max, (bbstate & STAT_POST ? 1 : 0), (bbstate & STAT_BOARD ? 1 : 0), 
    	currboard, currtitle, currBM, (bbstate & BRD_ANONYMOUS ? 1 : 0), fhdr.title);
          
    hdr_fpath(folder, fpath, &fhdr);
    return article_show(folder);
  } 
  else
    msg_quit("�򿪰��������ļ�.DIRʱ��������!");
  
  return 1;  	
}


int p_read()
{
 char *ptr, *BrdName;
 pid_t pid;
 int num;
 
 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("������������pid��Ч!"); 
  
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("��������, ��������!"); 
  
 BrdName = nextword(&ptr);
 
 num = atoi(nextword(&ptr));
 if(num < 1) num = 1;
  
 mode_flag = atoi(nextword(&ptr));
 if(mode_flag < 0) mode_flag = 0;
 
#ifdef DEBUG 
 if(mode_flag) 
  www_printf("DEBUG: Ŀǰ����������ժ�����~\n");
#endif  
 
 bshm_init();	/* �����ڴ��ʼ�� */   	
 brh_load();	/* Board History Loading */
 
 {
  int bno, bits;
  BRD *brd;
  char *str;
  
  if(mode_flag)
   utmp_mode(M_HOTMODE);
  else  
   utmp_mode(M_READA);
   
  bno = brd_bno(BrdName);
  
  if(bno<0) msg_quit("����Ŀ�������!");
  
  str = &brd_bits[bno];
  bits = *str;
  
  brd = bshm->bcache + bno;  
    
  bbstate = brd->battr; 
  
  if (!(bits & BRD_R_BIT)) 
    msg_quit("�Բ���, ��û���Ķ�Ȩ��!");    
  else if (bits & BRD_X_BIT)
    bbstate |= (STAT_BOARD | STAT_POST);
  else if (bits & BRD_W_BIT)
    bbstate |= STAT_POST;

#ifdef  HAVE_MODERATED_BOARD
  if (brd->readlevel == PERM_SYSOP)
    bbstate |= STAT_MODERATED;
#endif
  
  strcpy(currboard, brd->brdname);
  strcpy(currtitle, brd->title);
  strcpy(currBM, brd->BM);  
  brh_get(brd->bstamp, bno);
  post_read(num);
}
 brh_save();
 bbstate = 0;
 return 1;	
}

/* ----------------------------------------------------	*/
/* Post Delete						*/
/* ----------------------------------------------------	*/
extern int cmpchrono();

static inline void
move_post(hdr, board, by_bm)    /* �� hdr �� currboard �ᵽ board */
  HDR *hdr;
  char *board;
  int by_bm;
{
  HDR post;
  char folder[80], fpath[80];

  brd_fpath(folder, currboard, fn_dir);
  hdr_fpath(fpath, folder, hdr);

  brd_fpath(folder, board, fn_dir);
  hdr_stamp(folder, HDR_LINK | 'A', &post, fpath);
  unlink(fpath);

  /* ֱ�Ӹ��� trailing data */

  memcpy(post.owner, hdr->owner, TTLEN + 140);

  if (by_bm)
    sprintf(post.title, "%-13s%.59s", cuser.userid, hdr->title);

  rec_add(folder, &post, sizeof(post));
  cancel_post(hdr);
}  


static int
lazy_delete(hdr)
  HDR *hdr;
{
  sprintf(hdr->title, "<< �����¾� %s ɾ�� >>", cuser.userid);
  hdr->xmode |= POST_DELETE;
  return 0;
}

static int
post_delete(num)
  int num;
{
  int pos, by_BM;
  HDR fhdr;
  char fpath[80], buf[80];
  ACCT xuser;      /* ɾˮ���¼�ȥ��ˮ������ */
  char xuserid[14];

#define BN_DELETED      "deleted"
#define BN_JUNK         "junk"
#define	BN_SYSLOG	BRD_SYSLOG

  if (!cuser.userlevel ||
  !strcmp(currboard, BN_DELETED) ||
  !strcmp(currboard, BN_JUNK) ||
  !strcmp(currboard, BN_SYSLOG))
  
  msg_quit("��û��Ȩ��ɾ���˰�����!");

  pos = num - 1;
  brd_fpath(fpath, currboard, fn_dir);  
  
  if(!rec_get(fpath, &fhdr, sizeof(HDR), pos))
  {
   if (fhdr.xmode & (POST_MARKED | POST_CANCEL | POST_DELETE))
     msg_quit("���Ĳ���ɾ��!");
   
   strcpy(xuserid, fhdr.owner);
   by_BM = (strcmp(fhdr.owner, cuser.userid) || (cuser.firstlogin > fhdr.chrono) );
   
   if (!(bbstate & STAT_BOARD) && by_BM)
    msg_quit("��û��Ȩ��ɾ��������!");

   currchrono = fhdr.chrono;
   
   if (!rec_del(fpath, sizeof(HDR), pos, cmpchrono, lazy_delete))
   {
      move_post(&fhdr, by_BM ? BN_DELETED : BN_JUNK, by_BM);	/* ת�� */
      if (!by_BM && !(bbstate & BRD_NOCOUNT))
      {
        if (cuser.numposts > 0)
         cuser.numposts--;
         acct_save(&cuser);
         sprintf(buf, "%s���������¼�Ϊ %d ƪ!", MSG_DEL_OK, cuser.numposts);
         www_printf("result=OK&msg=%s\n", buf);
      }
      else if(by_BM && !(bbstate & BRD_NOCOUNT))
      {
         acct_load(&xuser, xuserid);
         if (xuser.numposts > 0) xuser.numposts --;
         acct_save(&xuser);
         www_printf("result=OK&msg=%s\n", MSG_DEL_OK);
      }
      else
      {
      	 www_printf("result=OK&msg=%s\n", MSG_DEL_OK);
      }
      
#ifdef HAVE_HOT_MODE	/* ���hot��� */
    if(fhdr.xmode & POST_HOT)
     {
      char folder[64];
      str_folder(folder, fpath, FN_GEM);
      rec_del(folder, sizeof(HDR), 0, cmpchrono, NULL);
     }  
#endif
   }                                 
 }             
 else
 {
  msg_quit("�����ڵ�����!\n");
 }
#undef  BN_DELETED
#undef  BN_JUNK
#undef	BN_SYSLOG
  return XO_FOOT;
}
             

int p_delete()
{
 char *ptr, *BrdName;
 pid_t pid;
 int num;
 
 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("������������pid��Ч!"); 
 
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("��������, ��������!"); 
  
 BrdName = nextword(&ptr);
 
 num = atoi(nextword(&ptr));
 if(num < 1) num = 1;
 
 bshm_init();	/* �����ڴ��ʼ�� */   	
 brh_load();	/* Board History Loading */
 
 {
  int bno, bits;
  char *str;
  BRD *brd;
   
  bno = brd_bno(BrdName);
  
  if(bno<0) msg_quit("����Ŀ�������!");
  
  str = &brd_bits[bno];
  bits = *str;
  brd = bshm->bcache + bno; 
  
  strcpy(currboard, brd->brdname);  
    
  bbstate = brd->battr; 
      
  if (bits & BRD_X_BIT)
    bbstate |= STAT_BOARD;
      
  post_delete(num);
}

 bbstate = 0;
 return 1;	
}

/* ----------------------------------------------------	*/
/* Post Mark						*/
/* ----------------------------------------------------	*/

int p_mark()
{
 char *ptr, *BrdName;
 pid_t pid;
 int num;
 
 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("������������pid��Ч!"); 
 
 
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("��������, ��������!"); 
  
 BrdName = nextword(&ptr);
 
 num = atoi(nextword(&ptr));
 if(num < 1) num = 1;
 
 bshm_init();	/* �����ڴ��ʼ�� */   	
 brh_load();	/* Board History Loading */
 
 {
  int bno, bits;
  char *str, fpath[80];
  HDR fhdr;
   
  bno = brd_bno(BrdName);
  
  if(bno<0) msg_quit("����Ŀ�������!");
  
  strcpy(currboard, BrdName);
  
  str = &brd_bits[bno];
  bits = *str;
      
  if (!(bits & BRD_X_BIT)) msg_quit("�Բ���,�����ǰ���!");
  num = num - 1;
  
  brd_fpath(fpath, currboard, fn_dir);
  
  if(!rec_get(fpath, &fhdr, sizeof(HDR), num))
  {
    fhdr.xmode ^= POST_MARKED;
    rec_put(fpath, &fhdr, sizeof(HDR), num);  
  }
  www_printf("result=OK&msg=���Ѿ��ɹ��Ľ�<%s>���%dƪmark/unmark����!\n", currboard,num);
 }
 return 1;	
}


/* ----------------------------------------------------	*/
/* Post Add Post ��������				*/
/* ----------------------------------------------------	*/


#ifdef HAVE_ANONYMOUS
void
log_anonymous(fname)
  char *fname;
{
  char buf[512];
  time_t now = time(0);
  sprintf(buf, "%s %-13s(%s) %s %s %s\n", Etime(&now), cuser.userid, fromhost, currboard, ve_title, fname);
  f_cat(FN_ANONYMOUS_LOG, buf);
}
#endif


static int
do_post()
{
  HDR post;
  char fpath[80], folder[80], *nick, *rcpt, *title;
  int mode;
  
  
  article_edit();	/* �������±༭ */
  title = ve_title+7;	/* ��ȡ���� */
  
  usr_fpath(fpath, cuser.userid, ".tmp"); 
  
  brd_fpath(folder, currboard, fn_dir);
  hdr_stamp(folder, HDR_LINK | 'A', &post, fpath);
    
  rcpt = cuser.userid;
  nick = cuser.username;
  mode = 0;	/* ������ת�� */
  
#ifdef HAVE_ANONYMOUS
  if (curredit & EDIT_ANONYMOUS)
  {
    nick = "�²�����˭ ? ^o^";
    rcpt = "[��������]";
    log_anonymous(post.xname);    
  }
#endif

  post.xmode = mode;
  strcpy(post.owner, rcpt);
  strcpy(post.nick, nick);
  strcpy(post.title, title);

  if (!rec_add(folder, &post, sizeof(HDR)))
  {
		/* fuse: �Լ������¾Ͳ�Ҫ��+���� */

    if (!(bbstate & BRD_NOTRAN))
      outgo_post(&post, currboard);
    
    mode = post.chrono;
    brh_add(mode - 1, mode, mode + 1);

    if (bbstate & BRD_NOCOUNT)
    {
      www_printf("result=OK&msg=���²������¼�����������");
    }
    else
    {
      www_printf("result=OK&msg=�������ĵ�%dƪ���¡�", ++cuser.numposts);
      acct_save(&cuser);
    }
  }
  else
  {
    www_printf("���·���ʧ��!Ŀ¼: %s\n", folder);
  }
  unlink(fpath);
  return 1;
}

#ifdef HAVE_BM_DENYPOST
static int
belong(flist, key)
  char *flist;
  char *key;
{
  int fd, rc;

  rc = 0;
  fd = open(flist, O_RDONLY);
  if (fd >= 0)
  {
    mgets(-1);

    while (flist = mgets(fd))
    {
      str_lower(flist, flist);
      if (str_str(key, flist))
      {
        rc = 1;
        break;
      }
    }

    close(fd);
  }
  return rc;
}


static int
is_denyid(userid)
  char *userid;
{
 char fpath[80];
 brd_fpath(fpath, currboard, fn_deny);
 return (belong(fpath, userid));
}
#endif

int p_post()
{
 char *ptr, *BrdName;
 pid_t pid;
 int sign;
 
 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("������������pid��Ч!"); 
 
 
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("��������, ��������!"); 
  
 BrdName = nextword(&ptr);

 strcpy(currboard, BrdName);
 
#ifdef HAVE_BM_DENYPOST 
 if (is_denyid(cuser.userid))
 {
   msg_quit("�ܱ�Ǹ�������ڽ��ܴ�����,Ŀǰ�޷���������!");
 }
#endif 
 
 sign = atoi(nextword(&ptr));
 if(sign >=0 && sign < 4) cuser.numemail = sign; /* ����numemail��ǩ�� */
 
 bshm_init();	/* �����ڴ��ʼ�� */   	
 brh_load();	/* Board History Loading */
  
 
 {
  int bno, bits;
  char *str;
  BRD *brd;
   
  bno = brd_bno(BrdName);
  
  if(bno<0) msg_quit("����Ŀ�������!");
  
  str = &brd_bits[bno];
  bits = *str;
  brd = bshm->bcache + bno;  
  brh_get(brd->bstamp, bno);
  strcpy(currboard, brd->brdname);
   
  bbstate = brd->battr;
  
  if (!(bits & BRD_W_BIT)) 
   msg_quit("�Բ��𣬱�������Ψ����");
   
#ifdef HAVE_ANONYMOUS   
  if ((bbstate & BRD_ANONYMOUS) && atoi(nextword(&ptr)))
   curredit |= EDIT_ANONYMOUS;	/* ������� ~ */
#endif   
   
  utmp_mode(M_POST);
        
  do_post();
 }
 
 brh_save();
 bbstate = 0;
 return 1;
}

/* ----------------------------------------------------	*/
/* Post Reply �ظ�����					*/
/* ----------------------------------------------------	*/

static int
do_reply(num)
 int num;
{
 char fpath[80];
 HDR fhdr;
 
 if(mode_flag)
   brd_fpath(fpath, currboard, FN_GEM);
 else
   brd_fpath(fpath, currboard, fn_dir);

 num = num -1 ; /* �ǵü�1���������λ��� */
 memset(&fhdr, 0, sizeof(HDR));
 
 if(!rec_get(fpath, &fhdr, sizeof(HDR), num))
 {
 	
    if(fhdr.xmode & (POST_DELETE | POST_CANCEL)) 
     msg_quit("���󣬸����²��ܻظ�!");
         
    www_printf("result=OK&board=%s&title=%s\n\n", currboard, fhdr.title);
    quote_edit(fpath, &fhdr);
  } 
  else
    msg_quit("���󣬲����ڵ�����!");
  
  return 1;  	
}

int p_reply()
{
 char *ptr, *BrdName;
 pid_t pid;
 int num;
 
 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("������������pid��Ч!"); 
 
 
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("��������, ��������!"); 
  
 BrdName = nextword(&ptr);
 
 num = atoi(nextword(&ptr));
 if(num < 1) num = 1; 
 
 mode_flag = atoi(nextword(&ptr));
 if(mode_flag < 0) mode_flag = 0;

 strcpy(currboard, BrdName); // ����һ���  

#ifdef HAVE_BM_DENYPOST 
 if (is_denyid(cuser.userid))
 {
   msg_quit("�ܱ�Ǹ�������ڽ��ܴ�����,Ŀǰ�޷���������!");
 }
#endif 
 
 bshm_init();	/* �����ڴ��ʼ�� */   	
 brh_load();	/* Board History Loading */

 strcpy(currboard, BrdName); // ����һ���  
 
 {
  int bno, bits;
  char *str;
   
  bno = brd_bno(BrdName);
  
  if(bno<0) msg_quit("����Ŀ�������!");
  
  str = &brd_bits[bno];
  bits = *str;
  
  if (!(bits & BRD_W_BIT)) 
   msg_quit("�Բ��𣬱�������Ψ����");
 
  if (mode_flag) 
    utmp_mode(M_HOTMODE);
  else
    utmp_mode(M_POST); 
    
  do_reply(num);
 }

 bbstate = 0;
 return 1;	
}

/* ----------------------------------------------------	*/
/* ��ʾ�����ĵ�						*/
/* ----------------------------------------------------	*/
int p_file()
{
 char *ptr, *BrdName, *file;
  
 ptr = myWRC.query;
  
 BrdName = nextword(&ptr);
 file = nextword(&ptr);
  
 {
   char fpath[80];
   
   strcpy(currboard, BrdName);
   brd_fpath(fpath, currboard, file);
   www_printf("result=OK&board=%s&file=%s\n\n", currboard, file);
   article_show(fpath);
 }
 return 1;	
}

/* ----------------------------------------------------	*/
/* ת������						*/
/* ----------------------------------------------------	*/


int p_forward() /* pid, board, num, rcpt */
{
  char *ptr, *argStr, rcpt[64];
  pid_t pid;
  int num;
  usint level;
 
  ptr = myWRC.query;
  pid = atoi(nextword(&ptr));
  cutmp = utmp_find_by_pid(pid);
 
  if(!cutmp) msg_quit("������������pid��Ч!"); 
 
  if(acct_load(&cuser, cutmp->userid) < 0) 
   msg_quit("��������, ��������!"); 
   
  level = cuser.userlevel;
  
  if ((level & (PERM_FORWARD | PERM_DENYMAIL)) != PERM_FORWARD)
   msg_quit("��û��Ȩ��ת������!");  
  
  argStr = nextword(&ptr);
  strcpy(currboard, argStr);
  
  if(!strcmp(currboard, BRD_SYSLOG))
   msg_quit("ϵͳ��¼������ת��!");

  num = atoi(nextword(&ptr));
  if(num < 1) num = 1;
    
  argStr = nextword(&ptr);
  strcpy(rcpt, argStr);
  
  bshm_init();  
  {
   BRD *brd;
   int bno, userno, pos;
   char *userid, *title, bpath[80], fpath[80], folder[80];
   usint method;
   HDR hdr;
   
   bno = brd_bno(currboard);
   if(bno<0) msg_quit("����Ŀ�������!");
   
   brd = bshm->bcache + bno;   

   if (brd->readlevel && !(brd->readlevel & level))
      msg_quit("�� ��û��ת�����ĵ�Ȩ��!");
     
   bbstate = brd->battr;
   
   if (!HAS_PERM(PERM_SYSOP) && (bbstate & BRD_NOFORWARD))
      msg_quit("�� �˰����²���ת��");

   userid = cuser.userid;

  /* �ο� struct.h ֮ MQ_UUENCODE / MQ_JUSTIFY */
#define	MF_SELF	0x04
#define	MF_USER	0x08

   userno = 0;

   if (!mail_external(rcpt))    /* ��;���� */
   {
     if (!str_cmp(rcpt, userid))
     {
       method = MF_SELF;
     }
     else
     {
       if ((userno = acct_userno(rcpt)) <= 0)
       {
       	msg_quit("վ��û�и�ʹ����!");
       }
       method = MF_USER;
     }
     usr_fpath(folder, rcpt, fn_dir);
   }
   else
   {
     if (not_addr(rcpt))
       msg_quit("����ȷ���ʼ���ַ!");

     method = 0;
   }

   brd_fpath(bpath, currboard, fn_dir);
   pos = num - 1;
   if(rec_get(bpath, &hdr, sizeof(HDR), pos))
     msg_quit("�Ҳ���������!");
     
   title = hdr.title;

   if(hdr.xmode & (POST_CANCEL | POST_DELETE))
     msg_quit("�����Ѿ�ɾ�����޷�ת��!");
     
   hdr_fpath(fpath, bpath, &hdr);

   if (method >= MF_SELF)
   {
      HDR mhdr;

      if (hdr_stamp(folder, HDR_LINK, &mhdr, fpath) < 0)
          msg_quit("ת��ʧ��!!!");

      if (method == MF_SELF)
      {
        strcpy(mhdr.owner, "[�� ѡ ��]");
        mhdr.xmode = MAIL_READ | MAIL_NOREPLY;
      }
      else
      {
        strcpy(mhdr.owner, userid);
      }
      strcpy(mhdr.nick, cuser.username);
      strcpy(mhdr.title, title);
      if (rec_add(folder, &mhdr, sizeof(HDR)) < 0)
          msg_quit("ת��ʧ��!!!!");
   }
   else
   {
    int rc;
    
#ifdef USE_SENDMAIL 	
    rc = bbs_sendmail(fpath, title, rcpt, 0); /* bsmtp(fpath, title, rcpt, 0);*/
#else
    rc = bsmtp(fpath, title, rcpt, 0);
#endif
    if(rc < 0)       
      msg_quit("�ż��޷��Ĵ�!!!");
   }

#undef  MF_SELF
#undef  MF_USER

  if (userno > 0)
    m_biff(userno);
 }
  
  www_printf("result=OK&msg=�ż��ɹ�����<%s>", rcpt);
  return 1;
}

/* ----------------------------------------------------	*/
/* Post Hot mode					*/
/* ----------------------------------------------------	*/

#ifdef HAVE_HOT_MODE
int p_hot()
{
 char *ptr, *BrdName;
 pid_t pid;
 int num;
 
 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("������������pid��Ч!"); 
 
 
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("��������, ��������!"); 
  
 BrdName = nextword(&ptr);
 
 num = atoi(nextword(&ptr));
 if(num < 1) num = 1;
 
 bshm_init();	/* �����ڴ��ʼ�� */   	
 brh_load();	/* Board History Loading */

 {
  int bno, bits, xmode;
  char *str, fpath[80];
  HDR fhdr;
   
  bno = brd_bno(BrdName);
  
  if(bno<0) msg_quit("����Ŀ�������!");
  
  strcpy(currboard, BrdName);
  
  str = &brd_bits[bno];
  bits = *str;
      
  if (!(bits & BRD_X_BIT)) msg_quit("�Բ���,�����ǰ���!");
  num = num - 1;
  
  brd_fpath(fpath, currboard, fn_dir);
  
  if(!rec_get(fpath, &fhdr, sizeof(HDR), num))
  {
    char folder[80];
    
    xmode = fhdr.xmode;
    currchrono = fhdr.chrono;
    
    brd_fpath(folder, currboard, FN_GEM);
    if(xmode & POST_HOT)  /* �Ѿ����˵ľ�ȡ��,���ǵľ������ϡ� */
      rec_del(folder, sizeof(HDR), fhdr.xid, cmpchrono, NULL);
    else
    {
      fhdr.xmode = 0; /* ��� */
      rec_add(folder, &fhdr, sizeof(HDR));
    }    
    
    fhdr.xmode = xmode ^ POST_HOT;    
    rec_put(fpath, &fhdr, sizeof(HDR), num);  
  }
  www_printf("result=OK&msg=���Ѿ��ɹ��Ľ�<%s>���%dƪhot/unhot��!\n", currboard,num);
 }
 return 1;	
}


int ph_list()
{
 char *ptr, *BrdName;
 pid_t pid;
 int page;
 
 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("������������pid��Ч!"); 
  
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("��������, ��������!"); 
  
 BrdName = nextword(&ptr);

 page = atoi(nextword(&ptr));

 /* Board Main */    
 
 bshm_init();	/* �����ڴ��ʼ�� */   	
 brh_load();	/* Board History Loading */
 
 {
  int bno, bits;
  BRD *brd;
  char fpath[80], *str;
  SXO *xo;
  
  utmp_mode(M_HOTMODE);  
   
  bno = brd_bno(BrdName);
  
  if(bno<0) msg_quit("����Ŀ�������!");
  
  str = &brd_bits[bno];
  bits = *str;

  brd = bshm->bcache + bno; 
  bbstate = brd->battr;
  
  if (!(bits & BRD_R_BIT)) 
    msg_quit("�Բ���, ��û���Ķ�Ȩ��!");    
  else if (bits & BRD_X_BIT)
    bbstate |= (STAT_BOARD | STAT_POST);
  else if (bits & BRD_W_BIT)
    bbstate |= STAT_POST;

#ifdef  HAVE_MODERATED_BOARD
  if (brd->readlevel == PERM_SYSOP)
    bbstate |= STAT_MODERATED;
#endif
   
  strcpy(currboard, brd->brdname);
  strcpy(currtitle, brd->title);
  strcpy(currBM, brd->BM);
  brh_get(brd->bstamp, bno);
  
  brd_fpath(fpath, BrdName, FN_GEM);
  
  xo = xo_new(fpath);
  xo->page = page;
  xo->key = XZ_HOT;
 
  post_init(xo);
  
  free(xo);    
  
#ifdef LOG_BRD_USIES	/* lkchu.981201: �Ķ������¼ */
  brd_usies();
#endif   
}

 bbstate = 0;
 return 1;	
}

#endif

/* ------------------------------------------------------- */
/* �������� ����mmap��ʽ���� ��ֱ�����������Ҫ����php���� */
/* ------------------------------------------------------- */
static int totalMatch;

#define	MAX_MATCH	200

static 
int post_match(char *board, char *author, char *title, char *title2, char *title3, int day)
{
  int bno, bits, fsize, max, num, dt, sum;
  BRD *brd;
  char fpath[80], *str, *fimage;
  HDR *head, *tail;
  time_t now;
  
  bno = brd_bno(board);  	
  if(bno < 0) return -1; /* brd_flag ? continue : msg_quit(errBoard) */
    
  str = &brd_bits[bno];
  bits = *str;

  brd = bshm->bcache + bno; 
  brh_get(brd->bstamp, bno);
  
  if (!(bits & BRD_R_BIT)) return -1; /* ͬ�� */
  
  brd_fpath(fpath, board, fn_dir);
  
  fimage = f_map(fpath, &fsize);
  
  if (fimage == (char *) -1) return -1; /* the same as up */
  
  max = fsize / sizeof(HDR);
  
  head = (HDR *) fimage;
  tail = (HDR *) (fimage + fsize);
  
  time(&now);
  sum = 0;
  num = max+1;
  dt = day * 86400;
  //do /* ��β��ǰ�� */
  while (tail-- >= head) //++head < tail);  
  {
    char *thisTitle;
    num--;
    
    if(totalMatch > MAX_MATCH) break;
        
    if((dt > 0) && ((now - tail->chrono) > dt)) break;	/* ���� */
    
    if(tail->xmode & (POST_CANCEL | POST_DELETE))
      continue;
    
    if(*author && str_cmp(tail->owner, author))
      continue;
    
    thisTitle = tail->title;
    if (STR4(thisTitle) == STR4(STR_REPLY)) /* �Ȱ� Re: ���� */
      thisTitle += 4;
      
    if (*title && !str_str(thisTitle, title))
      continue;   
               
    if (*title2 && !str_str(thisTitle, title2))
      continue;         
    
    if (*title3 && str_str(thisTitle, title3))
      continue;
    
    totalMatch++;    
    sum++;
    
    post_item(num, tail, fpath);  	
  }
  munmap(fimage, fsize);  
  if(sum > 0)
   www_printf("������������<a href='postlist.php?board=%s'>%s %s</a> ����%dƪ \n", brd->brdname, brd->brdname, brd->title, sum);
  return 0;  	
}


int p_search()	/* pid, board, day, author, title, title2, !title3 */  
	 	/* board == "NULL" ʱΪ���п��� */
{
 char *ptr, *board, *author, *title, *title2, *title3;
 pid_t pid;
 int day, brd_flag = 0;
 
 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("������������pid��Ч!"); 
  
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("��������, ��������!"); 
  
 board = nextword(&ptr);
 if(!str_cmp(board, "NULL"))	/* ���а��� */
   brd_flag = 1;

 day = atoi(nextword(&ptr));

 author = nextword(&ptr);
 if(!strncmp(author, "NULL", 4))
   *author = '\0';

 title = nextword(&ptr);
 if(!strncmp(title, "NULL", 4))
  *title = '\0';

 title2 = nextword(&ptr);
 if(!strncmp(title2, "NULL", 4))
  *title2 = '\0';

 title3 = nextword(&ptr);
 if(!strncmp(title3, "NULL", 4))
  *title3 = '\0';
 
 /* Board Main */    
 totalMatch = 0;
 bshm_init();	/* �����ڴ��ʼ�� */   	
 brh_load();	/* Board History Loading */
 utmp_mode(M_XMODE);
  
 www_printf("result=OK&board=%s&author=%s&title=%s&title2=%s&title3=%s&day=%d\n",
		board, author, title, title2, title3, day);
  
 if(!brd_flag) { 
   	
   if(post_match(board, author, title, title2, title3, day))
     msg_quit("�����������");
     
   return 1;
 } else {   
   BRD *bhdr, *tail;
   
   bhdr = bshm->bcache;
   tail = bhdr + bshm->number;
   
   do
   {
     www_printf("num=%d&brd=%s\n", -1, bhdr->brdname);
     post_match(bhdr->brdname, author, title, title2, title3, day);
     if(totalMatch > MAX_MATCH) {
     	www_printf("��������Ѿ����� %d����ϵͳ��ֹ��������������Ӿ�ȷ�Ĺؼ���!!\n", MAX_MATCH);
     	break;
     }
   } while (++bhdr < tail); 	  	
 }
 
 www_printf("���ҵ���¼: %d ��!", totalMatch);
 return 1;
}


/* ------------------------------------------- */
/* ���Ұ���                                    */
/* ------------------------------------------- */
int b_search()
{
 char *ptr, *key;
 pid_t pid;
 
 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("������������pid��Ч!"); 
  
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("��������, ��������!"); 	
  
 key = nextword(&ptr);
 
 if(!key[0]) msg_quit("û������ؼ���!!");
 
 bshm_init();	/* �����ڴ��ʼ�� */   	
 brh_load();	/* Board History Loading */
 utmp_mode(M_XMODE);
 
 {   
   BRD *bhdr, *tail;
   int bno, max = 0;
   usint bits;
   char *str;
   
   bhdr = bshm->bcache;
   tail = bhdr + bshm->number;
   bno = 0;
   
   do
   {     
     str = &brd_bits[bno++];
     bits = *str;     
     if(!(bits & BRD_R_BIT)) continue;
     
     if(!str_str(bhdr->brdname, key) && !str_str(bhdr->title, key)) continue;
     
     max ++;
     www_printf("no=%d&bname=%s&btitle=%s\n", max, bhdr->brdname, bhdr->title);     
   } while (++bhdr < tail);
   
   www_printf("result=OK&max=%d", max);
 } 
 
 return 1;
}


/* ���ܼ����� */

WebKeyFunc board_cb[] =
{
  {"listbrd",	b_list},
  {"listpost",	p_list},
  {"readpost",	p_read},
  {"deletepost",p_delete},
  {"markpost",	p_mark},
  {"postpost",	p_post},
  {"replypost",	p_reply},
  {"postfile",	p_file},
  {"pforward",	p_forward},
  /* {"crosspost",	p_cross}, */
#ifdef HAVE_HOT_MODE  
  {"hotpost",	p_hot},
  {"listhot",	ph_list},
#endif  
  {"searchpost",p_search},
  {"searchbrd", b_search},
  {NULL,	NULL}
};
/* _BOARD_C_ */
