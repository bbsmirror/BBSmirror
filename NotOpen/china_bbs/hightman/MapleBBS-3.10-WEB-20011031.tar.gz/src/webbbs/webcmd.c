/*-------------------------------------------------------*/
/* webCMD.c     ( ZJU Shanty MapleBBS Ver 3.10 )         */
/*-------------------------------------------------------*/
/* target : super WEB daemon for BBS server		 */
/* author : hightman.bbs@bbs.dot66.net			 */
/* create : 2001/09/20                                   */
/* update :                                              */
/*-------------------------------------------------------*/

/* _WEBCMD_C_ */


#include "bbs.h"

static char rqstString[100];

/* �ź�USR1 �ļ�����, ��usr_path/�µ�.WWWCMD ��� */
void
my_rqst()
{
  char fpath[80];
  int fd;
  WebReqCmd wrc;
  int (*func) ();
  
  usr_fpath(fpath, cutmp->userid, FN_WEBCMD);
  fd = open(fpath, O_RDONLY);
  if(fd >= 0)
  {
    read(fd, &wrc, sizeof(WebReqCmd));
    close(fd);
    unlink(fpath); 
    
    memcpy(rqstString, wrc.query, 100);
    
    if(func = wrc_func_get(&wrc))
      (*func) ();
  }
}

int
chg_usr()
{
  char userid[IDLEN + 1];
  time_t now;
  int biff;
  usint level;

#ifdef UNVALID_RAND_NICK  /* hightman.011028: δ��֤�����nickname */
  char *guestname[GUESTNAME]={GUEST_NAMES};
#endif
	
  user_save(); /* �ȴ�����һ��ʹ���� */
  
  strcpy(userid, rqstString);
  
  if(acct_load(&cuser, userid)<0) 
    msg_quit("<script>alert('ϵͳ������������, �Ͽ�����! �����µ�¼!');top.window.close();</script>\n");
    
  cutmp->userno = cuser.userno;
  cutmp->ufo = cuser.ufo;
  cutmp->idle_time = -1;
  strcpy(cutmp->userid, cuser.userid);

#ifdef UNVALID_RAND_NICK  /* hightman.011028: δ��֤�����nickname */
  srand(time(0));
  strcpy(cutmp->username, (cuser.userlevel&PERM_VALID) ? cuser.username : guestname[rand()%GUESTNAME]);
#else
  strcpy(cutmp->username, cuser.username);
#endif
  
  cutmp->ufo |= UFO_PAGER;

  utmp_mode(M_LOGIN);
  bbstate = STAT_STARTED;
  
  time(&now);
  ap_start = now; /* �ı���*/
 
  /* ��վ��Ĵ��� */
  level = cuser.userlevel;
  if (level)			/* not guest */
  {
    /* ------------------------------------------------- */
    /* �˶� user level					 */
    /* ------------------------------------------------- */
    if (level & PERM_SYSOP)	/* hightman.011028: վ��ȡ������Ȩ */
      level = ~0 ^ (PERM_DENYMAIL | PERM_DENYTALK | PERM_DENYCHAT | PERM_DENYPOST);
      
#ifdef JUSTIFY_PERIODICAL
    if ((level & PERM_VALID) && !(level & PERM_SYSOP))
    {  /* Thor.980819: վ����������������֤, ex. SysOp  */
      if (cuser.tvalid + VALID_PERIOD < start)
      {
	level ^= PERM_VALID;
      }
    }
#endif

    if (!(level & PERM_SYSOP))
    {
#ifdef NEWUSER_LIMIT
      /* Thor.980825: lkchu patch: ��Ȼ�� NEWUSER_LIMIT, ���Ǽ�һ�º���,
      if (start - cuser.firstlogin < 3 * 86400)
      {
        /* if (!(level & PERM_VALID)) */
        level &= ~PERM_POST;    /* ��ʹ�Ѿ�ͨ����֤������Ҫ��ϰ���� */
      } else
#endif
      if(level & PERM_VALID) /* ͨ����֤��, ���������ˣ���ӵ����ЩȨ�� */
      {
      	level |= (PERM_DEFAULT | PERM_VALID );      	
      }

      /* Thor.980629: δ��������֤, ��ֹ chat/talk/write */
      if(!(level & PERM_VALID))
      {
        level &= ~(PERM_CHAT | PERM_PAGE);
      }

      if (level & PERM_DENYPOST)
	level &= ~PERM_POST;

      if (level & PERM_DENYTALK)
	level &= ~PERM_PAGE;

      if (level & PERM_DENYCHAT)
	level &= ~PERM_CHAT;

      if ((cuser.numemail >> 4) > (cuser.numlogins + cuser.numposts))
 	level |= PERM_DENYMAIL;
     }
  }  
 
  cuser.lastlogin = ap_start;
  str_ncpy(cuser.lasthost, cutmp->from, sizeof(cuser.lasthost));
  acct_save(&cuser);  
  
  biff = 0;
  if(str_cmp(cuser.userid, STR_GUEST)) /* not guest */
  {
  	biff = (m_query(cuser.userid) ? 1 : 0);
  }
  
  www_printf("<script>top.bmwFrame.msg_init();top.bottomFrame.update_userid('%s');top.bottomFrame.new_mail(%d);</script>\n", cuser.userid, biff);
  
  return 0;
}

int chg_mode() /* Զ��utmp_mode */
{
  pid_t pid;
  char *ptr;
  int mode;
  
  ptr = myWRC.query;
  pid = atoi(nextword(&ptr));  
    
  cutmp = utmp_find_by_pid(pid);
  
  if(cutmp) 
  {
    mode = atoi(nextword(&ptr));  	
    utmp_mode(mode);
  }
  
  return 1;
}


int show_film()
{
 char *ptr;
 pid_t pid;
 int tag;

 ptr = myWRC.query;
 pid = atoi(nextword(&ptr));
 cutmp = utmp_find_by_pid(pid);
 
 if(!cutmp) msg_quit("������������pid��Ч!");
 if(acct_load(&cuser, cutmp->userid) < 0) 
  msg_quit("��������, ��������!");
 
 tag = atoi(nextword(&ptr));
 
 if(tag <= 0) tag = FILM_MOVIE + 1;
 
 tag --;
 
 fshm_init(); 
 www_printf("result=OK&msg=��ʼ�\n");
 www_cache_init();
 film_out(tag);
 www_cache_refresh();
 return 1;
}

int get_file() //������ gem/@/@xxxx
{
 char *ptr, *fpath;

 ptr = myWRC.query;
 fpath = nextword(&ptr);
 
 if(!memcmp(fpath, "gem/@/@", 7) && !memcmp(fpath, "etc/", 4))
  www_printf("Permission Denied!\n");
  
 else if(article_show(fpath)<0)
  www_printf("ϵͳ�Ҳ�������: %s\n", fpath);
  
 return 1;
}

/* -------------------------------- */
/* chat say sth.                    */
/* -------------------------------- */
static inline int
chat_send(fd, buf)
  int fd;
  char *buf;
{
  int len;
  
  len = strlen(buf);
  return (send(fd, buf, len, 0) == len);
}

/* ------------------------------- */
/* Enter Chat room                 */
/* ------------------------------- */
static char chatroom[IDLEN];    /* Chat-Room Name */
static char chatopic[48];
static FILE *frec;


#if 1
static char *
str_next (str)
   char **str;
{
   char *head, *tail;
   int ch;

   head = *str;
   for (;;) {           

      ch = *head;
      if (!ch) {
         *str = head;
         return head;
      }
      if (ch != ';')
         break;
      head++;
   }

   tail = head + 1;
   while (ch = *tail) {

      if (ch == ';') {
         *tail++ = '\0';
         break;
      }
      tail++;
   }
   *str = tail;

   return head;
}

static char *
ansi2web(s) 
 char *s;
{
 int m, n, l, c, mode;
 char buf[256], *buf2, tmp[20], *ptr;
 char result[1024];
 
 l=strlen(s);
 if(l>1024) l = 1024;
 bzero(result, 1024);
 mode = 0;
 
 for(n=0; n<l; n++) {
   c=s[n];
   if(c=='&') strcat(result, "&amp;");
   else if(c==92) strcat(result, "\\\\"); /* ���� \ �� */
   else if(c==34) strcat(result, "\\\""); /* �������� */
   else if(c=='<') strcat(result, "&lt;");
   else if(c=='>') strcat(result, "&gt;");
   else if(c=='\n') strcat(result, "<br>");
   else if(c==' ') strcat(result, "&nbsp;");
   else if(c=='\t') strcat(result, "&nbsp;&nbsp;");
   else if(c==27) {
   	   if(s[n+1]!='[') continue;
   	   for(m=n+2; m<l && m<n+24; m++)
   	   if(!strchr("0123456789;", s[m])) break;
   	   
           str_ncpy(buf, &s[n+2], m-(n+2)+1);
           n=m;
           ptr=buf;
           if(s[m]!='m') continue;
           if(strlen(buf)==0) {  if(mode) mode=0; strcat(result, "</font>"); }
           
           while(1) {
           	buf2 = str_next(&ptr);
                if(strlen(buf2)==0) break;
                c=atoi(buf2);
                if(c==0) { if(mode) mode=0; strcat(result, "</font>"); }
		if(c==7) { 
			if(mode) { mode = 0; strcat(result, "</font>"); }
			strcat(result, "<font style='color: 000000; background: efefef'>"); /* ��ɫ */
			if(!mode) mode = 1;
		}
		if(c>=30 && c<=37) {
			if(mode) { mode = 0; strcat(result, "</font>"); }
			if(c == 30) c =37;
			if(c == 37) c =30;
			sprintf(tmp, "<font class=col0%d>", c);
			if(!mode) mode = 1;
			strcat(result, tmp);
		}
	   }   	
    }
    else { 
    	sprintf(tmp, "%c", c);
    	strcat(result, tmp);
    }    
 }
 
 if(mode) strcat(result, "</font>");
 strcat(result, "<br>");
 s = result;
 return s;
}

#endif

static inline int
timeout_recv(usec, fd, buf, maxlen)
  int usec, fd, maxlen;
  char *buf;
{
  fd_set rfds;
  struct timeval tv;
  
  tv.tv_sec = 0;
  tv.tv_usec = usec;
  
  FD_ZERO(&rfds);
  FD_SET(fd, &rfds);
  
  if (select(fd + 1, &rfds, (fd_set *) 0, (fd_set *) 0, &tv) == -1) 
  	return -1;
  if (FD_ISSET(fd, &rfds))
  	return recv(fd, buf, maxlen, 0);
  
  return -2;
}

static inline int
chat_recv(fd, chatid)
  int fd;
  char *chatid;
{
  static char buf[512];
  static int bufstart = 0;
  int cc, len;
  char *bptr, *str;

  bptr = buf;
  cc = bufstart;
  len = sizeof(buf) - cc - 1;
  len = timeout_recv(50000, fd, bptr + cc, len);
  if(len == -2) return 1;
  else if(len <= 0) return -1;

  cc += len;

  for (;;)
  {
    len = strlen(bptr);

    if (len >= cc)
    {                           /* wait for trailing data */
      memcpy(buf, bptr, len);
      bufstart = len;
      break;
    }
    if (*bptr == '/')
    {
      str = bptr + 1;
      fd = *str++;

      if (fd == 'c')
      {
        www_printf("<script>top.mainFrame.chat_clear();</script>\n");        
      }
      else if (fd == 'n')
      {
        str_ncpy(chatid, str, 9);         
        str_ncpy(cutmp->mateid, str, sizeof(cutmp->mateid));
        
        www_printf("<script>top.mainFrame.chat_nick(\"%s\");</script>\n", chatid);
      }
      else if (fd == 'r')
      {
      	str_ncpy(chatroom, str, sizeof(chatroom));      	
        www_printf("<script>top.mainFrame.chat_room(\"%s\");</script>\n", str);
      }
      else if (fd == 't')
      {
	str_ncpy(chatopic, str, sizeof(chatopic));
        www_printf("<script>top.mainFrame.chat_topic(\"%s\");</script>\n", str);
      }
    }
    else
    {
      if(frec) fprintf(frec, "%s\n", bptr);
      www_printf("<script>top.mainFrame.chat_msg(\"%s\");</script>\n", ansi2web(bptr));
    }

    cc -= ++len;
    if (cc <= 0)
    {
      bufstart = 0;
      break;
    }
    bptr += len;
  }

  return 1;
}


static void
chat_record()	/* ¼�� */
{
  FILE *fp;
  time_t now;
  char buf[80];

  if (!cuser.userlevel)
    return;

  time(&now);

  if (fp = frec)
  {
    fprintf(fp, "%s\n������%s\n", msg_seperator, Ctime(&now));
    fclose(fp);
    frec = NULL;
    www_printf("<script>top.mainFrame.chat_msg(\"�� ¼�����, �ڵ�3���ݴ浵��<br>\");</script>\n");
    www_printf("<script>top.mainFrame.chat_func(\"̸��\");</script>\n");
  }
  else
  {
    usr_fpath(buf, cuser.userid, "buf.3");
    		/* web��, �̶���buf.3 */
    		
    fp = fopen(buf, "a");
    if (fp)
    {
      fprintf(fp, "����: %s\n����: %s\n¼��: %s (%s)\n��ʼ: %s\n%s\n",
        chatopic, chatroom, cuser.userid, cuser.username,
        Ctime(&now), msg_seperator);
      www_printf("<script>top.mainFrame.chat_msg(\"�� ��ʼ¼����, ¼�ڵ�3���ݴ浵��<br>\");</script>\n");
      www_printf("<script>top.mainFrame.chat_func(\"¼��\");</script>\n");
      frec = fp;
    }
    else
    {
      www_printf("<script>top.mainFrame.chat_msg(\"�� ¼���������ˣ���֪ͨվ��ά��<br>\");</script>\n");
      frec = NULL;
    }
  }
}

static void
chat_pager()
{
  cuser.ufo ^= UFO_PAGER;
  cutmp->ufo ^= UFO_PAGER;
  www_printf("<script>top.mainFrame.chat_msg(\"�� ���ĺ������Ѿ�%s��!<br>\");</script>\n",
    cuser.ufo & UFO_PAGER ? "�ر�" : "��");
}

struct chat_command
{
  char *cmdname;                /* Char-room command length */
  void (*cmdfunc) ();           /* Pointer to function */
};


struct chat_command chat_cmdtbl[] = {
  {"pager", chat_pager},
  {"tape", chat_record},
  {NULL, NULL}
};

static inline int
chat_cmd_match(buf, str)
  char *buf;
  char *str;
{
  int c1, c2;

  for (;;)
  {
    c1 = *str++;
    if (!c1)
      break;

    c2 = *buf++;
    if (!c2 || c2 == ' ' || c2 == '\n')
      break;

    if (c2 >= 'A' && c2 <= 'Z')
      c2 |= 0x20;

    if (c1 != c2)
      return 0;
  }

  return 1;
}


static inline int
chat_cmd(buf)
  char *buf;
{
  struct chat_command *cmd;
  char *key;

  buf++;
  for (cmd = chat_cmdtbl; key = cmd->cmdname; cmd++)
  {
    if (chat_cmd_match(buf, key))
    {
      cmd->cmdfunc();
      return '/';
    }
  }
  return 0;
}

int 
enter_chat() /* G_CMD, pid, chatid , passbuf, */
{
 char *chatid, buf[128], *str;
 int chatfd, ch;
 struct sockaddr_in sin;
#if     defined(__OpenBSD__)
  struct hostent *h;
#endif
  
#ifdef CHAT_SECURE
  char *passwd;
#endif
 
 chatid = rqstString; 

#ifdef CHAT_SECURE 
 passwd = rqstString + 50;
#endif 
  signal(SIGPIPE, SIG_IGN);
  sleep(1); /* ��Ϣһ�� ����̫���� */
#if     defined(__OpenBSD__)

  if (!(h = gethostbyname(MYHOSTNAME)))
  {
    www_printf("<script>top.mainFrame.chat_err(\"������! ��������ʧ��: %s\");</script>\n", MYHOSTNAME);
    return -1;
  }

  memset(&sin, 0, sizeof(sin));
  sin.sin_family = AF_INET;
  sin.sin_port = htons(CHAT_PORT);
  memcpy(&sin.sin_addr, h->h_addr, h->h_length);
            
#else

  sin.sin_family = AF_INET;
  sin.sin_port = htons(CHAT_PORT);
  sin.sin_addr.s_addr = INADDR_ANY /* INADDR_LOOPBACK */;
  memset(sin.sin_zero, 0, sizeof(sin.sin_zero));
#endif

  chatfd = socket(AF_INET, SOCK_STREAM, 0);
  if (chatfd < 0)
  {
    www_printf("<script>top.mainFrame.chat_err(\"������! Socket() Fail!\");</script>\n");
    return -1;
  }
 
  if(connect(chatfd, (struct sockaddr *) & sin, sizeof sin))
  {
    close(chatfd);
    blog("CHAT ", "connect");
    www_printf("<script>top.mainFrame.chat_err(\"������! Connect() Fail!\");</script>\n");    
    return -1;
  }
  
#ifdef CHAT_SECURE
    sprintf(buf, "/! %s %s %s\n", cuser.userid, chatid, passwd);
#else
    sprintf(buf, "/! %d %d %s %s\n",
      cuser.userno, cuser.userlevel, cuser.userid, chatid);
#endif
    chat_send(chatfd, buf);
    if (recv(chatfd, buf, 3, 0) != 3)
      return 0;

    if (!strcmp(buf, CHAT_LOGIN_EXISTS))     
      str = "��������Ѿ���������";
    else if (!strcmp(buf, CHAT_LOGIN_INVALID))
      str = "��˵��������Ǵ����";
    else if (!strcmp(buf, CHAT_LOGIN_BOGUS))	/* Thor: ��ֹ��ͬ���˽��� */
      str = "������ǲ������������̸����";
    else 
      str = NULL;
      
    if(str != NULL)
    {
      close(chatfd);
      www_printf("<script>top.mainFrame.chat_err(\"������! %s!\");</script>\n", str);
      return -1;
    }
  
  memset(buf, 0, sizeof(buf));
  utmp_mode(M_CHAT);
  str_ncpy(cutmp->mateid, chatid, sizeof(cutmp->mateid));
  cutmp->sockport = 0;

  while(1) {
#if 1 	
    if(cutmp->sockport == -1) { /* �ж���Ҫд�� */
      FILE *fp;
      char folder[64], cbuf[100];
        
      cutmp->sockport = 0;
            
      usr_fpath(folder, cuser.userid, FN_WEBCMD);
      if(fp = fopen(folder, "r" )) {
      	fgets(cbuf, 100, fp);
      	fclose(fp);
      	unlink(folder);
      }
      if(cbuf[0] == '/')
       ch = chat_cmd(cbuf);
       	
      if (ch != '/')
      {
        strcat(cbuf, "\n");
        if (!chat_send(chatfd, cbuf)) break;
      }
      
      if (cbuf[0] == '/' && cbuf[1] == 'b') break;
      else if(cbuf[0] == '/' && cbuf[1] == 'z')
      {
      	utmp_mode(M_XMODE);
      	break;
      }
      
      if(cutmp->mode != M_CHAT)
      	utmp_mode(M_CHAT);
      
    }  else     
#endif 
    {
    	ch = chat_recv(chatfd, chatid); /* �����Ϣbug */
    	if(cutmp->mode == M_BMW) { utmp_mode(M_CHAT); continue; }
    	else if(ch == -1) break;
    }
  }            
  close(chatfd);

  if (frec)
    chat_record();
  
  if(cutmp->mode == M_CHAT) /* �Լ�����/���߳����İɣ����� */
  {
    utmp_mode(M_TMENU);
    www_printf("<script>top.mainFrame.forceLeave=0; top.mainFrame.document.location='talk.php';</script>\n");
  }
    
  cutmp->mateid[0] = '\0';
  return 1;	
}

WebKeyFunc cmd_cb[] =
{
  {"chgusr",	chg_usr},
  {"chgmode",	chg_mode}, /* ��ʱ��û������ */
  {"getmovie",	show_film}, /* �ŵ�Ӱ��,haha */
  {"getfile",	get_file}, /* ��ʾ�ļ� */
  {"enterchat", enter_chat}, /* Enter the chat room */
  {NULL,	NULL}
}; 

/* _WEBCMD_C_ */
