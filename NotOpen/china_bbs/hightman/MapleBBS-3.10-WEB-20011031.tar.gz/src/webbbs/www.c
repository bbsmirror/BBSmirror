/*-------------------------------------------------------*/
/* www.c      ( NTHU CS MapleBBS Ver 3.00 )              */
/*-------------------------------------------------------*/
/* target : Some Functions Only for WWW version		 */
/* author : hightman.bbs@bbs.dot66.net			 */
/* create : 2001/09/20                                   */
/* update :                                              */
/*-------------------------------------------------------*/

/* _WWW_C_ */

#include "bbs.h"

extern UCACHE *ushm;

/* ----------------------------------------------------- */
/* Loign LOG                                             */
/* ----------------------------------------------------- */

void
blog(mode, msg)
  char *mode, *msg;
{
  char buf[512], data[256];
  time_t now;

  time(&now);
  if (!msg)
  {
    msg = data;
    sprintf(data, "Stay: %d (%d)", (now - ap_start) / 60, currpid);
  }

  sprintf(buf, "%s %s %-13s%s\n", Etime(&now), mode, cuser.userid, msg);
  f_cat(FN_USIES, buf);
}


/* ----------------------------------------------------- */
/* Leave BBS                                             */
/* ----------------------------------------------------- */

void
ReleaseSocket()
{
  shutdown(0, 2);
  shutdown(1, 2);
}

void
user_save()
{
  int delta, fd;
  char fpath[80];
  ACCT tuser;
  
  blog("AXXED", NULL);
  
#ifdef LOG_BMW		/* lkchu.981201: ���� config.h �趨 */
  bmw_save ();		/* lkchu.981201: ��Ѷ��¼���� */      
#endif  

  usr_fpath(fpath, cuser.userid, fn_acct);
  fd = open(fpath, O_RDWR);
  if (fd >= 0)
  {/* ��������վʱ��ʹ��� */
    if (read(fd, &tuser, sizeof(ACCT)) == sizeof(ACCT))
    {
      delta = time(0) - ap_start;
      tuser.staytime += delta;
      if (delta > 3 * 60)
        tuser.numlogins++;    
      tuser.ufo = cuser.ufo;
      str_ncpy(tuser.username, cuser.username, sizeof(tuser.username));
      lseek(fd, (off_t) 0, SEEK_SET);
      write(fd, &tuser, sizeof(ACCT));
    }
    close(fd);
  } 
}

void
abort_bbs()
{
        if (bbstate & STAT_STARTED)
        {
          user_save();
          utmp_free();
        }
        ReleaseSocket();
        exit(0);
}

void
msg_quit(msg)
  char *msg;
{  
  bbstate = 0;
  www_printf("%s\n", msg);
  abort_bbs();  
}

/* ----------------------------------------------------- */
/* Web Request Command                                   */
/* ----------------------------------------------------- */

static int
IsSplitChar (ch)
     int ch;
{
   /* ���ӷ�&��ո��\t��\r��\n */	
   return (ch == '\t' || ch == 10 || ch == 13); 
   /* (ch == '&' || ch == ' ' || ch == '\t' || ch == 10 || ch == 13); */
}

char *
nextword (str)
     char **str;
{
   char *head, *tail;
   int ch;

   head = *str;
   for (;;) {

      ch = *head;
      if (!ch) {
         *str = head;
         return head;
      }
      if (!IsSplitChar (ch))
         break;
      head++;
   }

   tail = head + 1;
   while (ch = *tail) {

      if (IsSplitChar (ch)) {
         *tail++ = '\0';
         break;
      }
      tail++;
   }
   *str = tail;

   return head;
}      	

/* ----------------------------------------------------- */
/* Web Anti IDLE ������                                  */
/* ----------------------------------------------------- */

void
anti_idle()
{
  if(cutmp->ufo & UFO_BIFF)
  {
  	cutmp->ufo ^= UFO_BIFF;
  	www_printf("<script>top.bottomFrame.new_mail(1);</script>\n");  
  }
  if(www_printf("<script>top.bottomFrame.update_online('%d', '%d');</script>\n", 
  		ushm->count, get_web_online()) <= 0)
    abort_bbs();
  /*alarm(30);*/
}


/* more.c */

#define MORE_BUFSIZE    4096

static uschar more_pool[MORE_BUFSIZE];
static int more_base, more_size;

char *
mgets(fd)
  int fd;
{
  char *pool, *base, *head, *tail;
  int ch;

  if (fd < 0)
  {
    more_base = more_size = 0;
    return NULL;
  }

  pool = more_pool;
  base = pool + more_base;
  tail = pool + more_size;
  head = base;

  for (;;)
  {
    if (head >= tail)
    {
      if (ch = head - base)
        memcpy(pool, base, ch);

      head = pool + ch;
      ch = read(fd, head, MORE_BUFSIZE - ch);

      if (ch <= 0)
        return NULL;

      base = pool;
      tail = head + ch;
      more_size = tail - pool;
    }

    ch = *head;

    if (ch == '\n')
    {
      *head++ = '\0';
      more_base = head - pool;
      return base;
    }

    if (ch == '\r')
      *head = '\0';

    head++;
  }
}



void *
mread(fd, len)
  int fd, len;
{
  char *pool;
  int base, size;

  base = more_base;
  size = more_size;
  pool = more_pool;

  if (size < len)
  {
    if (size)
    {
      memcpy(pool, pool + base, size);
    }

    base = read(fd, pool + size, MORE_BUFSIZE - size);

    if (base <= 0)
      return NULL;

    size += base;
    base = 0;
  }

  more_base = base + len;
  more_size = size - len;

  return pool + base;
}

/* _WWW_C_ */
