/*----------------------------------------------------------*/
/*  tran/tranu.c			                    */
/*----------------------------------------------------------*/
/* ����: hightman@263.net                                   */
/* ��;: firebird 3.0 �� Maple 3.x ʹ����ת��               */
/*          .PASSWDS => .USR .ACCT  ���ż㣬ǩ����          */
/* ����: 00/11/22                                           */
/* �ο�: util/transusr.c        ernie@micro8.ee.nthu.edu.tw */
/*----------------------------------------------------------*/
/* syntax : tranu                                           */
/*----------------------------------------------------------*/ 

#include "tran.h"

#define NAMELEN              40

struct userec {                  /* Structure used to hold information in */
        char            userid[IDLEN+2];   /* PASSFILE */
        time_t          firstlogin;
        char            lasthost[16];
        unsigned int    numlogins;
        unsigned int    numposts;
        char            flags[2];
        char            passwd[PASSLEN];  /* MD5���ܣ��������޸� */
        char            username[NAMELEN];
        char            ident[NAMELEN];
        char            termtype[16];
        char            reginfo[STRLEN-16];
        unsigned int    userlevel;
        time_t          lastlogin;
        time_t          stay;
        char            realname[NAMELEN];
        char            address[STRLEN];
        char            email[STRLEN-12];

        unsigned int    nummails;
        time_t          lastjustify;
        char            gender;
        unsigned char   birthyear;
        unsigned char   birthmonth;
        unsigned char   birthday;
        int             signature;
        unsigned int    userdefine;
        time_t          notedate;
        int             noteline;
};
typedef struct userec userec;

struct fileheader {             /* This structure is used to hold data in */
        char filename[STRLEN];     /* the DIR files */
        char owner[STRLEN];
        char title[STRLEN];
        unsigned level;
        unsigned char accessed[ 12 ];   /* struct size = 256 bytes */
} ;
typedef struct fileheader fileheader;

struct override {
        char id[13];
        char exp[40];
};
typedef struct override override;

static char *table[] =  /* ��ͬ��ʽ�ĸ��� */
{
  "plans",  /* ˵���� */
  "signatures", /* ǩ�� */
  "buf.0",
  "buf.1",
  "buf.2",
  NULL
};

typedef struct _PERM
{
  int old;
  int new;
} PERM;

static PERM perm[] =
{
  {0x00000001, PERM_BASIC},             /* BASIC */
  {0x00000002, PERM_CHAT},              /* CHAT */
  {0x00000004, PERM_PAGE},              /* PAGE */
  {0x00000008, PERM_POST},              /* POST */
  {0x00000010, PERM_VALID},             /* LOGIN */
  {0x00000020, PERM_DENYPOST},          /* DENYPOST */
  {0x00000040, PERM_CLOAK},             /* CLOAK */
  {0x00000080, PERM_SEECLOAK},          /* SEECLOAK */
  {0x00000100, PERM_XEMPT},             /* XEMPT */
  {0x00000400, PERM_BM},                /* BM */
  {0x00000800, PERM_ACCOUNTS},          /* ACCOUNTS */
  {0x00001000, PERM_CHATROOM},          /* CHATROOM */
  {0x00002000, PERM_BOARD},             /* BOARD */
  {0x00004000, PERM_SYSOP}		/* SYSOP */
};

void    /* ��ĸת��Ϊ��д */
str_uper(dst, src)
  char *dst, *src;
{
  int ch;
  do
  {
    ch = *src++;
    if (ch >= 'a' && ch <= 'z')
      ch = ch - 32;
    *dst++ = ch;
  } while (ch);
}

void basedir()
{
  int fdw;
  char dir[32];

  mkdir("usr", 0700);
  fdw = 'a';
  for (;;)
  {
    sprintf(dir, "usr/%c", fdw);
    mkdir(dir, 0700);
    printf("\tMaking dir: %s", dir);
    if (fdw == 'v')
      fdw = '0';
     else if (fdw == '9')
       fdw='@';
     else if(fdw == '@')
         break;
    else
       fdw ++;
  }
}

int
tran(uno, rec)
  int uno;
  userec *rec;
{
  char pnew[256], pold[256], *nptr, *optr, *str, **list;
  FILE *fold, *fnew;
  struct stat st;
  PERM *p;
  int chrono, fd, len;
  int cold, cnew;
  fileheader xold;
  HDR xnew;
  ACCT acct;
  char *ptr, *owner, *ktr, *left, *right, buf[128], buf2[128];
  struct tm *ptime;
  int ret = 0;
  override ofriend;
  PAL nfriend;


  printf("\n%s\n", rec->userid);	/* report */

  str_lower(buf, rec->userid);

 if(buf[0]<'a'|| buf[0]>'z')
   {
     printf("\t#skip: bad user!\n");
     return 0;
   }


  str_uper(buf2, rec->userid);
  sprintf(pnew, "usr/%c/%s", *buf, buf);
  mkdir(pnew, 0700);

/* tran .ACCT */
   strcat(pnew, "/.ACCT");
   memset(&acct, 0, sizeof(ACCT));
   acct.userno = uno;                         /* unique positive code */
   strcpy(acct.userid, rec->userid);
   strcpy(acct.passwd, rec->passwd);
   acct.signature = rec->signature;		/* No.? ǩ�� */
   strcpy(acct.realname, rec->realname);
   strcpy(acct.username, rec->username);
   acct.userlevel = 0;		 	      /* userlevel */
   for(p=perm;p->old;p++)
   {
     if(rec->userlevel & p->old)
       acct.userlevel |= p->new;
   }
   acct.numlogins = rec->numlogins;
   acct.numposts = rec->numposts;
   acct.ufo = UFO_COLOR | UFO_MOVIE | UFO_BNOTE; /* ufo */
   acct.firstlogin = rec->firstlogin;
   if(acct.firstlogin <= 0)
     time(&acct.firstlogin);
   ret = acct.firstlogin;
     
   acct.lastlogin = rec->lastlogin;
   acct.staytime = rec->stay;			/* ͣ��ʱ�� */
   acct.tcheck = time(NULL);               	/* time to check mbox/pal */
   strcpy(acct.lasthost, rec->lasthost);
   acct.numemail = rec->nummails;         	/* �ķ� Inetrnet E-mail ���� */
   acct.tvalid = time(NULL) + 60*60*24*7;
                                  		/* ͨ����֤������ mail address ��ʱ�� */
   strcpy(acct.email, rec->email);
   strcpy(acct.address, rec->address);
   strcpy(acct.justify, "\0");			/* ��֤���� */

   strcpy(acct.ident,"\0");	
   acct.vtime = time(NULL);

#ifdef HAVE_MONEY_ISM
   acct.money = 1000;
#endif

#ifdef HAVE_COUNT_MARK
   acct.nummark = 0;
#endif   

  if((fnew = fopen(pnew, "w")) == NULL)
  {
    printf(".ACCT open fail : %s\n", rec->userid);
    return 0;
  }
  if(fwrite(&acct, sizeof(ACCT), 1, fnew) != 1)
  {
    printf(".ACCT write fail : %s\n", rec->userid);
    fclose(fnew);
    return 0;
  }
  fclose(fnew);  

/* תTable[] */
  sprintf(pold, "%s/home/%c/%s/.",FB, *buf2, rec->userid);

  optr = strchr(pold, '.');
  nptr = strchr(pnew, '.');

  for (list = table; str = *list; list++)
  {
    strcpy(optr, str);
    strcpy(nptr, str);
    if(!strcmp(optr,"signatures"))
      strcpy(nptr,"sign");
    link(pold, pnew);
  }

/* friend & black */
 
   strcpy(optr, "friends");
   strcpy(nptr, "friend");

  if(fold=fopen(pold,"r"))
   {
    while(fread(&ofriend, sizeof(override), 1, fold) == 1) 
     {
        memset(&nfriend, 0, sizeof(PAL));
        strcpy(nfriend.userid,ofriend.id);
        nfriend.userno=uno;
        strcpy(nfriend.ship,ofriend.exp);
        nfriend.ftype = 0  ;  /* ��� */       
                
         if((fnew = fopen(pnew, "a")) == NULL)
        {
           printf("friends open fail : %s\n", rec->userid);
           return 0;
          }
        if(fwrite(&nfriend, sizeof(PAL), 1, fnew) != 1)
          {
            printf("friend write fail : %s\n", rec->userid);
            fclose(fnew);
            return 0;
          }
         fclose(fnew);  
      }
     fclose(fold);
    }
     strcpy(optr,"rejects");
     if(fold=fopen(pold,"r"))
   {
    while(fread(&ofriend, sizeof(override), 1, fold) == 1)
     {
        memset(&nfriend, 0, sizeof(PAL));
        strcpy(nfriend.userid,ofriend.id);
        nfriend.userno=uno;
        strcpy(nfriend.ship,ofriend.exp);
        nfriend.ftype = PAL_BAD ;  /* ˱�� */

         if((fnew = fopen(pnew, "a")) == NULL)
        {
           printf("friends open fail : %s\n", rec->userid);
           return 0;
          }
        if(fwrite(&nfriend, sizeof(PAL), 1, fnew) != 1)
          {
            printf("friend write fail : %s\n", rec->userid);
            fclose(fnew);
            return 0;
          }
         fclose(fnew);
      }
     fclose(fold);
   }

/* mail */
  strcpy(nptr, "@");
  mkdir(pnew, 0700);   /* �ż�Ŀ¼ */

  sprintf(pold, "%s/mail/%c/%s/.", FB, *buf2, rec->userid);
  optr = strchr(pold, '.');

  strcpy(optr, ".DIR");

  fold = fopen(pold, "r");
  if (fold == NULL)
   { 
    printf("no mail\n");
    return ret;
    }

   if (fstat(fileno(fold), &st) || st.st_size < 0)
  {
    printf("fstat fail or size < 0\n");
    fclose(fold);
    return 0;
  }
  if(st.st_size == 0)
  {
    printf("no mail\n");
    fclose(fold);
    return ret;
  }

  strcpy(nptr, ".DIR");
  fnew = fopen(pnew, "w");
  if (fnew == NULL)
  {
    fclose(fold);
    printf("\tError: %s\n", pnew);
    return 0;
  }
    *nptr++ = '@';
  *nptr++ = '/';

  cold = cnew = 0;

  while (fread(&xold, sizeof xold, 1, fold) == 1)
  {
    cold++;
    chrono = 0;
   // if(chrono == 0)
    time((time_t *)&chrono);
    do
    {
      chrono++;
      archiv32m(chrono, nptr);
      *nptr = '@';
    }
    while(stat(pnew, &st) == 0);
    
    strcpy(optr, xold.filename);

    if (link(pold, pnew))
      continue;

    memset(&xnew, 0, sizeof(xnew));
    owner = xold.owner;
    if(stat(pnew, &st) < 0)
      st.st_size = 0;
    xnew.xid = st.st_size;			/* mail size */

    if( ktr = strchr(owner, ' '))   /* �����޷����� */
      *ktr = '\0';

    if (*owner == '(' || *owner == '[' || *owner == '.' || strchr(owner, '(') || strchr(owner, '['))
    {
      xnew.xmode = (xold.accessed[0]/4) | MAIL_HOLD | MAIL_NOREPLY;
      owner[3] = owner[6] = ' ';
    }
    else
    {
     fd = open(pnew, O_RDONLY);
      if (fd < 0)
      {
	unlink(pnew);
	printf("\tFile : %s\n", pnew);
	continue;
      }

       len = read(fd, buf, sizeof(buf) - 1);
       close(fd);

        if (len <= 0)
	continue;

      buf[len] = 0;

      if (ptr = strchr(buf, '\n'))
	*ptr = 0;

      if (strchr(owner, '.'))	/* smtp ==> mbox */
      {
	xnew.xmode = (xold.accessed[0]/4) | MAIL_INCOME;
	xnew.xid = 0;
      }
      else
      {
	xnew.xmode = xold.accessed[0]/4;
        xnew.xid = 0x80000000;
      }
 
 
      if (buf[4] == ':')
      {
	owner = buf + 6;

	if (ptr = strchr(owner, ' '))
	{
	  *ptr++ = '\0';

	  if (left = strchr(ptr, '('))
	  {
	    if (right = strrchr(++left, ')'))
	    {
	      *right = 0;
	      strcpy(xnew.nick, left);
	    }
	  }
	}
      }
    }

    xnew.chrono = chrono;
    strcpy(xnew.xname, nptr);
    strcpy(xnew.owner, owner);

    ptime = localtime(&st.st_mtime);
    sprintf(xnew.date, "%02d/%02d/%02d",
      ptime->tm_year%100, ptime->tm_mon + 1, ptime->tm_mday);

    strcpy(xnew.title, xold.title);

    fwrite(&xnew, sizeof xnew, 1, fnew);

    cnew++;
  }

  fclose(fnew);
  fclose(fold);

  if (!cnew)
  {
    strcpy(nptr - 2, ".DIR");
    unlink(pnew);
  }

  if(cold > cnew)
    printf("\tTran lost: %d ==> %d\n", cold, cnew);

  return ret;
}


main()
{
  int count;
  char buf[128];
  FILE *pwd, *usr;
  userec rec;
  SCHEMA schema;

  basedir();  /* ��������Ŀ¼ */
  printf("\n");

  count = 1;

  sprintf(buf,"%s/.PASSWDS",FB);
  if((pwd = fopen(buf, "r")) == NULL)
  {
    printf("can't open .PASSWDS\n");
    exit(1);
  }

  if((usr = fopen(".USR", "w")) == NULL)
  {
    printf("can't open .USR\n");
    exit(1);
  }

  while(fread(&rec, sizeof(rec), 1, pwd) == 1)
  {
    if(!isalnum(rec.userid[0]))    
      continue;

    memset(&schema, 0, sizeof(schema));
    schema.uptime = count;
    strcpy(schema.userid, rec.userid);
    
    if(!tran(count, &rec))
    {
      printf("trans fail: %s\n", rec.userid);
      ftruncate(fileno(usr), (count-1)*sizeof(schema));
      fseek(usr, 0, SEEK_END);
      continue;
    }
    else
      printf("ok!\n");

    if(fwrite(&schema, sizeof(schema), 1, usr) != 1)
    {
      printf(".USR fail: %s\n", rec.userid);
      continue;
    }

    count++;
  }

  printf("## %d users transformed\n", count-1);
  fclose(pwd);
  fclose(usr);
  exit(0);
}
