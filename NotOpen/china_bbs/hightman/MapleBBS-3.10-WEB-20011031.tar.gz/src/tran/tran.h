#include "bbs.h"

#define FB		"/home/fb"	/* ԭFireBird BBS��Ŀ¼,���/ ǰ�治����'.' */

#define	DATE	"98/10/02"	/* BBS��վʱ�� */

#define	SYSOP	"SYSOP"		/* BBSվ������ */

#define OPNICK	"վ��"		/* վ�����س� */

#define	NOBOARD	"1002"		/* ��û�����������ַ��� */

#define BM_LEN          60
#define STRLEN          80

#define	GEM_INIT	0x10000 /* ������� */

char fn_names[] = "/.Names";

/* ----------------------------------------------------- */
/* chrono ==> file name (32-based)                       */
/* 0123456789ABCDEFGHIJKLMNOPQRSTUV                      */
/* ----------------------------------------------------- */

void
archiv32(chrono, fname)
  register time_t chrono;       /* 32 bits */
  register char *fname;         /* 7 chars */
{
  register char *str;
  register int n;

  str = fname + 7;
  *str = '\0';
  do
  {
    n = chrono & 31;
    n += '0';
    if (n > '9')
      n += 'A' - '9' - 1;
    chrono >>= 5;
    *(--str) = n;
  } while (str > fname);
}

void
archiv32m(chrono, fname)
  register time_t chrono;	/* 32 bits */
  register char *fname;		/* 7 chars */
{
  register char *str;
  register int n;

  str = fname + 8;
  *str = '\0';
  *fname = 'A';
  while (--str > fname)
  {
    n = chrono & 31;
    n += '0';
    if (n > '9')
      n += 'A' - '9' - 1;
    *str = n;
    chrono >>= 5;
  }
}
