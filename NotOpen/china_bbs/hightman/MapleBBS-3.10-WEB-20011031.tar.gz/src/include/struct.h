/*-------------------------------------------------------*/
/* struct.h	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : all definitions about data structure	 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#ifndef _STRUCT_H_
#define _STRUCT_H_


#define STRLEN   80		/* Length of most string data */
#define BTLEN    48		/* Length of board title */
#define BMLEN    36		/* Length of board managers */
#define TTLEN    72		/* Length of title */
#define FNLEN    28		/* Length of filename  */
#define IDLEN	 12		/* Length of board / user id */
#define PASSLEN  14		/* Length of encrypted passwd field */


#define	BFLAG(n)	(1 << n)/* 32 bit-wise flag */


typedef char const *STRING;
typedef unsigned char uschar;	/* length = 1 */
typedef unsigned int usint;	/* length = 4 */
typedef struct UTMP UTMP;


/* ----------------------------------------------------- */
/* ʹ�����ʺ� .ACCT struct : 512 bytes			 */
/* ----------------------------------------------------- */

typedef struct
{
  int userno;			/* unique positive code */
  char userid[IDLEN + 1];
  char passwd[PASSLEN];
  uschar signature;
  char realname[20];
  char username[24];
  usint userlevel;
  int numlogins;
  int numposts;
  usint ufo;
  time_t firstlogin;
  time_t lastlogin;
  time_t staytime;		/* �ܹ�ͣ��ʱ�� */
  time_t tcheck;		/* time to check mbox/pal */
  char lasthost[32];
  int numemail;			/* �ķ� Inetrnet E-mail ���� */
  time_t tvalid;		/* ͨ����֤������ mail address ��ʱ�� */
  char email[60];
  char address[60];
  char justify[60];		/* FROM of replied justify mail */
  char vmail[60];		/* ͨ����֤֮ email */
#ifdef HAVE_MONEY_ISM  		/* hightman.011028: Ǯ���ƶ�? */
#ifdef HAVE_COUNT_MARK
  char ident[140 - 28];
  int nummark;			/* hightman.011028: ��������� 4bit */
#else  
  char ident[140 - 24];
#endif  
  int money;			/* hightman.011028: Ǯ���ƶ� 4bit */
#else
#ifdef HAVE_COUNT_MARK
  char ident[140 - 28];
  int nummark;			/* hightman.011028: ��������� 4bit */
  int unused;			/* hightman.0111028: ��Ϊunused, ������money���� :p */
#else  
  char ident[140 - 20];
#endif  
#endif  
  time_t vtime;			/* validate time */
}      ACCT;


typedef struct			/* 16 bytes */
{
  time_t uptime;
  char userid[IDLEN];
}      SCHEMA;


#ifdef	HAVE_REGISTER_FORM

typedef struct	/* ע����� (Register From) 256 bytes */
{
  int userno;
  time_t rtime;
  char userid[IDLEN + 1];
  char agent[IDLEN + 1];
  char realname[20];
  char career[50];
  char address[60];
  char phone[20];
  char reply[72];
}      RFORM;

#endif


/* ----------------------------------------------------- */
/* User Flag Option : flags in ACCT.ufo			 */
/* ----------------------------------------------------- */


#define	UFO_COLOR	BFLAG(0)	/* true if the ANSI color mode open */
#define	UFO_MOVIE	BFLAG(1)	/* true if show movie */
#define	UFO_BRDNEW	BFLAG(2)	/* ������ģʽ */
#define UFO_BNOTE	BFLAG(3)	/* ��ʾ���廭�� */
#define UFO_VEDIT	BFLAG(4)	/* �򻯱༭�� */

#define UFO_PAGER	BFLAG(5)	/* �رպ����� */
#define	UFO_QUIET	BFLAG(6)	/* ��®���˾������޳����� */
#define UFO_PAL		BFLAG(7)	/* true if show pals only */
#define	UFO_ALOHA	BFLAG(8)	/* ��վʱ����֪ͨ���� */
#define	UFO_MOTD	BFLAG(9)	/* �򻯽�վ���� */
#define	UFO_MPAGER	BFLAG(10)	/* lkchu.990428: �����ʼ����� */
#define	UFO_NWLOG	BFLAG(11)	/* lkchu.990510: ����Ի���¼ */
#define UFO_NTLOG	BFLAG(12)	/* lkchu.990510: ���������¼ */
#define	UFO_BROADCAST	BFLAG(13)	/* hightman.000611: ���չ㲥 */ 
#define	UFO_MESSAGE	BFLAG(14)	/* hightman.010707: �ر�ѶϢ�� */
#define	UFO_HIDEFROM	BFLAG(15)	/* hightman.010714: ������Դ */

#define UFO_CLOAK	BFLAG(19)	/* true if cloak was ON */
#define UFO_ACL		BFLAG(20)	/* true if ACL was ON */

#ifdef HAVE_SUPER_CLOAK /* hightman.010722: վ���г������� */
#define	UFO_SUPERCLOAK	BFLAG(21)	/* hightman.010723: �������� */
#endif

/* ----------------------------------------------------- */
/* bit 24-27 : client/server or telnet BBS		 */
/* ----------------------------------------------------- */
#define	UFO_BBTP	BFLAG(24)	/* ON : client/server */
#define	UFO_SPARE	BFLAG(25)	/* ready for connection */

/* these are flags in UTMP.ufo */

#define UFO_EXEC        BFLAG(26)
                                     	/* hightman.001113: 
					 * ִ���ⲿ����,˭���޷�����Ϣ,
             				 * վ���㲥��������� 
					 */

#define	UFO_BIFF	BFLAG(27)	/* �����ż� */
#define	UFO_SOCKET	BFLAG(28)	/* true if socket port active */
#define	UFO_REJECT	BFLAG(29)	/* true if reject any body */

/* special purpose */

#define	UFO_FCACHE	BFLAG(30)	/* �к��� */
#define	UFO_MQUOTA	BFLAG(31)	/* �������д�����֮�ż� */

#define UFO_UTMP_MASK	(UFO_BIFF)	
/* Thor.980805: ����ufo����utmp->ufoΪ�����flag, �����cuser.ufo��ͬ�������� */

#include "hdr.h"


/* ----------------------------------------------------- */
/* control of board vote : 256 bytes			 */
/* ----------------------------------------------------- */


typedef struct VoteControlHeader
{
  time_t chrono;		/* ͶƱ����ʱ�� */  /* Thor:Ϊ key */
 						/* ���� match HDR chrono */
  time_t bstamp;		/* �����ʶ���� */  /* Thor:Ϊ key */
  time_t vclose;		/* ͶƱ����ʱ�� */
  char xname[17];		/* ������ */ /* Thor: match HDR��xname */
  char vsort;			/* ��Ʊ����Ƿ����� */
  char vpercent;		/* �Ƿ���ʾ�ٷֱ��� */
  char cdate[9];		/* �������� */ /* Thor.990329: ֻ����ʾ, y2k */
  int maxblt;			/* ÿ�˿�Ͷ��Ʊ */
  char owner[130];		/* �ٰ��� */
  char date[9];			/* ��ʼ���� */ /* Thor: match HDR��date*/
  char title[TTLEN + 1];	/* ͶƱ���� */
}           VCH;


typedef char vitem_t[32];	/* ͶƱѡ�� */


/* filepath : brd/<board>/.VCH, brd/<board>/@/... */


/* ----------------------------------------------------- */
/* Mail-Queue struct : 256 bytes			 */
/* ----------------------------------------------------- */


typedef struct
{
  time_t mailtime;		/* ����ʱ�� */
  char method;
  char sender[IDLEN + 1];
  char username[24];
  char subject[TTLEN + 1];
  char rcpt[60];
  char filepath[77];
  char *niamod;			/* reverse domain */
}      MailQueue;


#define	MQ_UUENCODE	0x01	/* �� uuencode �ټĳ� */
#define	MQ_JUSTIFY	0x02	/* ������֤�ź� */


/* ----------------------------------------------------- */
/* PAL : friend struct : 64 bytes			 */
/* ----------------------------------------------------- */


typedef struct
{
  char userid[IDLEN + 1];
  char ftype;
  char ship[46];
  int userno;
}      PAL;


#define	PAL_BAD	0x02	/* ���� vs ���� */


/* ----------------------------------------------------- */
/* structure for call-in message : 100 bytes		 */
/* ----------------------------------------------------- */


typedef struct
{
  time_t btime;
  UTMP *caller;			/* who call-in me ? */
  int sender;			/* calling userno */
  int recver;			/* called userno */
  char userid[IDLEN + 1];
  char msg[71];			/* ��Ѷ */
}      BMW;			/* bbs message write */

#ifdef  HAVE_CHICKEN
typedef struct
{
        char name[20];
        int hp;         /*����*/
        int maxhp;      /*��������*/
        int mp;         /*����*/
        int maxmp;      /*��������*/
        int attack;     /*����*/
        int resist;     /*����*/
        int speed;      /*�ٶ�*/
        int mresist;    /*ħ������*/
        int resistmore; /*������̬*/
        int nodone;     /*���*/
        int leaving;    /*�뿪*/
        int pipmode;    /*״̬*/
        int money;      /*��Ǯ*/
        int msgcount;   /*ѶϢ����*/
        int chatcount;
        char msg[150];  /*ѶϢ����*/
        char chat[10][150]; /*��������*/
}       pipdata;
#endif


/* ----------------------------------------------------- */
/* Structure used in UTMP file : 148 bytes		 */
/* ----------------------------------------------------- */


struct UTMP
{
  pid_t pid;			/* process ID */
  int userno;			/* user number in .PASSWDS */

  time_t idle_time;		/* active time for last event */
  usint mode;			/* bbsmode */
  usint ufo;			/* the same as userec.ufo */
  u_long in_addr;		/* Internet address */
  int sockport;			/* socket port for talk */
  UTMP *talker;			/* who talk-to me ? */

  BMW *mslot[BMW_PER_USER];

  char userid[IDLEN + 1];	/* user's ID */
  char mateid[IDLEN + 1];	/* partner's ID */
  char username[24];

  char from[34];		/* remote host */

#ifdef	HAVE_MONEY_ISM
  int reward;			/* post_count */ 
#endif  
#ifdef	HAVE_CHICKEN
  pipdata pip;
  int pkflag;
#endif
#ifdef	PREFORK
  int bgen;			/* generation */
#endif
};


/* ----------------------------------------------------- */
/* BOARDS struct : 128 bytes				 */
/* ----------------------------------------------------- */


typedef struct BoardHeader
{
  char brdname[IDLEN + 1];	/* board ID */
  char title[BTLEN + 1];
  char BM[BMLEN + 1];		/* BMs' uid, token '/' */

  uschar bvote;			/* ���м���ͶƱ������ */

  time_t bstamp;		/* ���������ʱ��, unique */
  usint readlevel;		/* �Ķ����µ�Ȩ�� */
  usint postlevel;		/* �������µ�Ȩ�� */
  usint battr;			/* �������� */
  time_t btime;			/* .DIR �� st_mtime */
  int bpost;			/* ���м�ƪ post */
  time_t blast;			/* ����һƪ post ��ʱ�� */
}           BRD;


#define	BRD_NOZAP	0x01	/* ���� zap */
#define	BRD_NOTRAN	0x02	/* ��ת�� */
#define	BRD_NOCOUNT	0x04	/* �������·���ƪ�� */
#define	BRD_NOSTAT	0x08	/* ���������Ż���ͳ�� */
#define	BRD_NOVOTE	0x10	/* ������ͶƱ���� [sysop] �� */
#define	BRD_ANONYMOUS	0x20	/* �������� */
#define BRD_NOFORWARD   0x40    /* lkchu.981201: ����ת�� */


/* ----------------------------------------------------- */
/* Class image						 */
/* ----------------------------------------------------- */


#define CLASS_INIFILE   "Class"
#define CLASS_IMGFILE	"run/class.img"


#define	CH_END	-1
#define	CH_TTLEN	64


typedef	struct
{
  int count;
  char title[CH_TTLEN];
  short chno[0];
} ClassHeader;


/* ----------------------------------------------------- */
/* cache.c �����õ����Ͻṹ				 */
/* ----------------------------------------------------- */


typedef struct
{
  int shot[MOVIE_MAX]; /* Thor.980805: ���ܻ�Ҫ�ټ�1,�������ΧΪ0..MOVIE_MAX */
  char film[MOVIE_SIZE];
} FCACHE;

#define	FILM_SIZ	4000	/* max size for each film */


#define	FILM_WELCOME	0
#define	FILM_GOODBYE	1
#define	FILM_APPLY	2	/* new account */
#define	FILM_TRYOUT	3
#define	FILM_POST	4
#define	FILM_GEM	5	/* help message */
#define	FILM_BOARD	6
#define	FILM_CLASS	7
#define	FILM_PAL	8
#define	FILM_MAIL	9
#define	FILM_ULIST	10
#define	FILM_VOTE	11
#define	FILM_MORE	12
#define	FILM_EDIT	13
#define FILM_BMW        14
#define FILM_INCOME     15
#define	FILM_MOVIE	16	/* normal movies */


typedef struct
{
  UTMP uslot[MAXACTIVE];	/* UTMP slots */
  usint count;			/* number of active session */
  usint offset;			/* offset for last active UTMP */

  double sysload[3];
  int avgload;

  BMW *mbase;			/* sequential pointer for BMW */
  BMW mpool[BMW_MAX];

#if 0
  int cs_gen;			/* generation number for CS version */
  int tn_gen;			/* generation number for TN version */
#endif

} UCACHE;


typedef struct
{
  BRD bcache[MAXBOARD];
  int number;
  time_t uptime;
} BCACHE;


/* ----------------------------------------------------- */
/* screen.c �����õ����Ͻṹ				 */
/* ----------------------------------------------------- */


#define ANSILINELEN (255)	/* Maximum Screen width in chars */
/* ���� 160 ���͹����ˣ������Ե� 255 */


/* Screen Line buffer modes */


#define SL_MODIFIED	(1)	/* if line has been modifed, screen output */
#define SL_STANDOUT	(2)	/* if this line contains standout code */
#define SL_ANSICODE	(4)	/* if this line contains ANSI code */


typedef struct screenline
{
  uschar oldlen;		/* previous line length */
  uschar len;			/* current length of line */
  uschar width;			/* padding length of ANSI codes */
  uschar mode;			/* status of line, as far as update */
  uschar smod;			/* start of modified data */
  uschar emod;			/* end of modified data */
  uschar sso;			/* start of standout data */
  uschar eso;			/* end of standout data */
  uschar data[ANSILINELEN];
}          screenline;


typedef struct LinkList
{
  struct LinkList *next;
  char data[0];
}        LinkList;


/* ----------------------------------------------------- */
/* xover.c �����õ����Ͻṹ				 */
/* ----------------------------------------------------- */


typedef struct OverView
{
  int pos;			/* current position */
  int top;			/* top */
  int max;			/* max */
  int key;			/* key */
  char *xyz;			/* staff */
  struct OverView *nxt;		/* next */
  char dir[0];			/* data path */
}        XO;


typedef struct
{
  int key;
  int (*func) ();
}      KeyFunc;


typedef struct
{
  XO *xo;
  KeyFunc *cb;
  int mode;
} XZ;


typedef struct
{
  time_t chrono;
  int recno;
}      TagItem;


#ifdef MODE_STAT
typedef struct
{
  time_t logtime;
  time_t used_time[30];
} UMODELOG;


typedef struct
{
  time_t logtime;
  time_t used_time[30];
  int count[30];
  int usercount;
} MODELOG;
#endif


#if 0
/* ----------------------------------------------------- */
/* util/spamstat.c �����õ����Ͻṹ			 */
/* ----------------------------------------------------- */


typedef struct
{
  int count;
  int xfrom;		/* hash code of from */
  int xto;
  int xtitle;
  char from[80];
  char to[80];
  char title[80];
} SpamStat;
#endif

 /*----------------------------------------------------*/
 /* �����г����йض���                                 */
 /*----------------------------------------------------*/
 
 // SLOT propeties, put them in struct.h
 #define PROP_EMPTY  0x0000 // slot is empty, available
 #define PROP_G_GROUP  0x0001
 #define PROP_G_CANCEL  0x0002
 #define PROP_G_OPEN  0x0004
 #define PROP_I_SELL  0x0010
 #define PROP_I_WANT  0x0020
 #define PROP_I_CANCEL  0x0040 // if set, another prog will expire
      // this item.
 #define PROP_IS_GROUP  (PROP_G_GROUP | PROP_G_CANCEL)
 #define PROP_IS_ITEM  (PROP_I_SELL | PROP_I_WANT | PROP_I_CANCEL)
 #define PROP_IS_CANCEL  (PROP_G_CANCEL | PROP_I_CANCEL)
 typedef struct SLOT  // if is group, only prop/reply/title/fn
 {    // will be used
   time_t chrono;  // time stamp
   int prop;   // propety of this slot
   int reply;   // number of replied mail of this item
   char title[30];
   char userid[IDLEN + 1]; // userid for mail reply and owner del check
   char price[10];
   char contact[20];
   char date[6];   // only 6 bytes, not 9
   char fn[9];   // dirname or filename of item desc, max9 bytes
 } SLOT;    // 80 bytes totally
 typedef struct SLOT_DOUBLE_LINKLIST
 {
   struct SLOT_DOUBLE_LINKLIST *prev;
   SLOT slot;
   struct SLOT_DOUBLE_LINKLIST *next;
 } SDL;
 
/* ----------add by hightman 2000 ------------------------*/
#endif                        /* _STRUCT_H_ */
