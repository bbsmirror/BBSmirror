#include <string.h>
#include "bbs.h"

char    tname[STRLEN];
char    fname[STRLEN];
extern char currboard[STRLEN];

int
marked_all(int type)
{
        struct fileheader post;
        int     id = 1;
        char    dname[STRLEN],buf[STRLEN];
        struct stat st1, st2;

        sprintf(dname, "boards/%s/%s", currboard, DOT_DIR);
        sprintf(fname, "boards/%s/%s2", currboard, DOT_DIR);
	if(type)
		sprintf(tname, "boards/%s/%s", currboard, AUTHOR_DIR);
	else 
	        sprintf(tname, "boards/%s/%s", currboard, MARKED_DIR);

        if (stat(dname, &st1) == -1)
                return 1;
        if (stat(tname, &st2) != -1) {
                if (st2.st_mtime >= st1.st_mtime)
                        return 1;
        }
        unlink(tname);
        sprintf(buf, "cp %s %s", dname, fname);
        system(buf);

	while(1) {
                if(get_record(fname, &post, sizeof(post), id) == -1 ) break;
                if (type) {
			if(  strncmp(post.title,"Re:", 3) 
			  && strncmp(post.title,"RE:", 3)){
				append_record(tname, &post, sizeof(post));
			}
		} else {
			if( post.accessed[ 0 ] & FILE_MARKED )
		                append_record(tname, &post, sizeof(post));
		}
		id ++;
        }
	unlink(fname);
	return 0;
}
