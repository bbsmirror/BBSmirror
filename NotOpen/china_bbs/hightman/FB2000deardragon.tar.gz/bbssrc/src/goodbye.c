/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu
    Firebird Bulletin Board System
    Copyright (C) 1996, Hsien-Tsung Chang, Smallpig.bbs@bbs.cs.ccu.edu.tw
                        Peng Piaw Foong, ppfoong@csie.ncu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/
/*
$Id: goodbye.c,v 1.8 1999/07/31 12:30:47 edwardc Exp $
*/

#include "bbs.h"

extern char BoardName[];
typedef struct {
	char   *match;
	char   *replace;
}
        logout;

int
countlogouts(filename)
char    filename[STRLEN];
{
	FILE   *fp;
	char    buf[256];
	int     count = 0;
	if ((fp = fopen(filename, "r")) == NULL)
		return 0;

	while (fgets(buf, 255, fp) != NULL) {
		if (strstr(buf, "@logout@") || strstr(buf, "@login@"))
			count++;
	}
	return count + 1;
}


user_display(filename, number, mode)
char   *filename;
int     number, mode;
{
	FILE   *fp;
	char    buf[256];
	int     count = 1;
	clear();
	move(1, 0);
	if ((fp = fopen(filename, "r")) == NULL)
		return;

	while (fgets(buf, 255, fp) != NULL) {
		if (strstr(buf, "@logout@") || strstr(buf, "@login@")) {
			count++;
			continue;
		}
		if (count == number) {
			if (mode == YEA)
				showstuff(buf, 0);
			else {
				prints("%s", buf);
			}
		} else if (count > number)
			break;
		else
			continue;
	}
	refresh();
	fclose(fp);
	return;
}


char   *
cexp(exp)
int     exp;
{
	int     expbase = 0;

        if(exp==-9999)
                return "��ˮ�̿�";
        if(exp<=100+expbase)
                return "�¹���·";
        if(exp>100+expbase&&exp<=450+expbase)
                return "һ�����";
        if(exp>450+expbase&&exp<=850+expbase)
                return "�м�����";
        if(exp>850+expbase&&exp<=1500+expbase)
                return "�߼�����";
        if(exp>1500+expbase&&exp<=2500+expbase)
                return "�Ϲ���";
        if(exp>2500+expbase&&exp<=3000+expbase)
                return "���Ͽ���";
        if(exp>3000+expbase&&exp<=5000+expbase)
                return "��վ����";
        if(exp>5000+expbase&&exp<=10000+expbase)
                return "�������";
        if(exp>10000+expbase&&exp<=20000+expbase)
                return "��ˮ����";
        if(exp>20000+expbase&&exp<=50000+expbase)
                return "����֮��";
        if(exp>50000+expbase)
                return "�����޵�";

}

char *
cnumposts(num)
int num;
{

        if(num== 0 )
                return "�տ��ж���";
        if(num<=100)
                return "��ˮվ����";
        if(num>100&&num<=300)
                return "��ˮվ������ƾ";
        if(num>300&&num<=500)
                return "��ˮվ������ƾ";
        if(num>500&&num<=1000)
                return "��ˮվѧʿѧλ";
        if(num>1000&&num<=2000)
                return "��ˮվ˶ʿѧλ";
        if(num>2000&&num<=4000)
                return "��ˮվ��ʿѧλ";
        if(num>4000)
                return "��ˮվ��ʿ��";

}

char *
cnummedals(num)
int num;
{

        if(num== 0 )
                return "û�й���,�ٺ�";
        if(num<=300)
                return "�е������:)";
        if(num>300&&num<=1000)
                return "�нϴ�Ĺ���";
        if(num>1000&&num<=3000)
                return "��ˮվ������";
        if(num>3000)
                return "��ˮվ�Ĺ�ة";

}

char *
cmoney(num)
int num;
{

        if(num<= 20 )
                return "��⵰:P";
        if(num>20&&num<=1000)
                return "��ǿ����";
        if(num>1000&&num<=3000)
                return "С�вƸ�";
        if(num>3000&&num<=5000)
                return "��Ǯ�˼�";
        if(num>5000&&num<=10000)
                return "С��֮��";
        if(num>10000&&num<=30000)
                return "��Ԫ��!!";
        if(num>30000&&num<=100000)
                return "һ���ư�";
        if(num>100000)
                return "ˮվ����";

}

char   *
cperf(perf)
int     perf;
{

        if(perf== 0 )
                return "���޹���";
        if(perf<=300)
                return "���ֲ���";
        if(perf>300&&perf<=1000)
                return "��ˮ������";
        if(perf>1000&&perf<=2000)
                return "�ŵȹ���";
        if(perf>2000&&perf<=4000)
                return "��վ֧��";
        if(perf>4000&&perf<=6500)
                return "��ˮվ��ة";
        if(perf>6500&&perf<=10000)
                return "������";
        if(perf>10000)
                return "�񡫡�";

}

int
countexp(udata)
struct userec *udata;
{
	int     exp;
	if (!strcmp(udata->userid, "guest"))
		return -9999;
	exp = udata->numposts +
		udata->numlogins / 5 +
		(time(0) - udata->firstlogin) / 86400 +
		udata->stay / 3600;
	return exp > 0 ? exp : 0;
}

int
countperf(udata)
struct userec *udata;
{
	int     perf;
	int     reg_days;
	if (!strcmp(udata->userid, "guest"))
		return -9999;
	reg_days = (time(0) - udata->firstlogin) / 86400 + 1;
	/*
	 * 990530.edwardc ע��û�ɹ�����ע����˵��˻ᵼ�� reg_days = 0,
	 * Ȼ������������ SIGFPE, ����Ϊ��Ĵ��� ..
	 */
	if (reg_days <= 0)
		return 0;

	perf = ((float) udata->numposts / (float) udata->numlogins +
		(float) udata->numlogins / (float) reg_days) * 10;
	return perf > 0 ? perf : 0;
}

void countdays(year,month,day,now)
int *year,*month,*day;
time_t now;
{
        struct tm *GoodTime;
        time_t tmptime;
        GoodTime = localtime(&now);
        GoodTime->tm_year = *year - 1900;
        GoodTime->tm_mon = *month-1;
        GoodTime->tm_mday = *day;
        GoodTime->tm_hour = 0;
        GoodTime->tm_min = 0;
        tmptime = mktime(GoodTime);
        *year = (tmptime-now)/86400;
        *month = (tmptime-now-*year*86400)/3600;
        *day = (tmptime-now-*year*86400-*month*3600)/60;
}

showstuff(buf, limit)
char    buf[256];
int     limit;
{
	extern time_t login_start_time;
	int     frg, i, matchfrg, strlength, cnt, tmpnum,tyear,tmonth,tday;
	static char numlogins[10], numposts[10], nummails[10], rgtday[30], 
		lasttime[30],lastjustify[30], thistime[30], stay[10], 
	        alltime[20], ccperf[20],perf[10], exp[10], ccexp[20],
	        star[5],moneys[10],GoodDays[10],AllDays[10],
		GoodHours[10],GoodMins[10];
/* GoodDays һЩ����������Ӿ���������. ����Żع�, �´����վ��������.*/
/* AllDays �����յ���������� */
	char    buf2[STRLEN], *ptr, *ptr2;
	time_t  now;

	static logout loglst[] =
	{
		"gds",GoodDays,
                "ghs",GoodHours,
                "gms",GoodMins,
		"adays",AllDays,
		"userid", currentuser.userid,
		"username", currentuser.username,
		"realname", currentuser.realname,
		"address", currentuser.address,
		"email", currentuser.email,
		"termtype", currentuser.termtype,
		"realemail", currentuser.reginfo,
		"ident", currentuser.ident,
		"rgtday", rgtday,
		"login", numlogins,
		"post", numposts,
		"mail", nummails,
		"lastlogin", lasttime,
		"lasthost", currentuser.lasthost,
		"lastjustify", lastjustify,
		"now", thistime,
		"bbsname", BoardName,
		"stay", stay,
		"alltime", alltime,
		"exp", exp,
		"money",moneys,
		"cexp", ccexp,
		"perf", perf,
		"cperf", ccperf,
		"star", star,
		"pst", numposts,
		"log", numlogins,
		"bbsip", BBSIP,
		"bbshost", BBSHOST,
		NULL, NULL,
	};
	if (!strchr(buf, '$')) {
		if (!limit)
			prints("%s", buf);
		else
			prints("%.82s", buf);
		return;
	}
	now = time(0);
	/* for ansimore3() */

	if (currentuser.numlogins > 0) {
		tmpnum = countexp(&currentuser);
		sprintf(exp, "%d", tmpnum);
		strcpy(ccexp, cexp(tmpnum));
		tmpnum = countperf(&currentuser);
		sprintf(perf, "%d", tmpnum);
		strcpy(ccperf, cperf(tmpnum));
		sprintf(alltime, "%dСʱ%d����", currentuser.stay / 3600, (currentuser.stay / 60) % 60);
		getdatestring(currentuser.firstlogin,NA);
		sprintf(rgtday, "%s", datestring);
		getdatestring(currentuser.lastlogin,NA);
		sprintf(lasttime, "%s", datestring);
		getdatestring(now,NA);
		sprintf(thistime, "%s", datestring);
		getdatestring(currentuser.lastjustify,NA);
		sprintf(lastjustify, "%24.24s", datestring);
		sprintf(stay, "%d", (time(0) - login_start_time) / 60);
		sprintf(numlogins, "%d", currentuser.numlogins);
		sprintf(numposts, "%d", currentuser.numposts);
		sprintf(moneys,"%d",currentuser.money);
		sprintf(nummails, "%d", currentuser.nummails);
		sprintf(star, "%s", horoscope(currentuser.birthmonth, currentuser.birthday));
                tyear = 1999; tmonth = 12, tday = 20;
                countdays(&tyear,&tmonth,&tday,now);/*���Żع�*/
                sprintf(GoodDays,"%d",tyear>0?tyear:0);
                sprintf(GoodHours,"%d",tmonth>0?tmonth:0);
                sprintf(GoodMins,"%d",tday>0?tday:0);
                tyear = currentuser.birthyear+1900;
                tmonth = currentuser.birthmonth;
                tday = currentuser.birthday;
                countdays(&tyear,&tmonth,&tday,now);
                sprintf(AllDays,"%d",abs(tyear));
	}
	frg = 1;
	ptr2 = buf;
	do {
		if (ptr = strchr(ptr2, '$')) {
			matchfrg = 0;
			*ptr = '\0';
			prints("%s", ptr2);
			ptr += 1;
			for (i = 0; loglst[i].match != NULL; i++) {
				if (strstr(ptr, loglst[i].match) == ptr) {
					strlength = strlen(loglst[i].match);
					ptr2 = ptr + strlength;
					for (cnt = 0; *(ptr2 + cnt) == ' '; cnt++);
					sprintf(buf2, "%-*.*s", cnt ? strlength + cnt : strlength + 1, strlength + cnt, loglst[i].replace);
					prints("%s", buf2);
					ptr2 += (cnt ? (cnt - 1) : cnt);
					matchfrg = 1;
					break;
				}
			}
			if (!matchfrg) {
				prints("$");
				ptr2 = ptr;
			}
		} else {
			if (!limit)
				prints("%s", ptr2);
			else
				prints("%.82s", ptr2);
			frg = 0;
		}
	}
	while (frg);
	return;
}
