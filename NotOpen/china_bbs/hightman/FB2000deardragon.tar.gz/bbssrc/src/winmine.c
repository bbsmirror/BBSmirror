/* deardragon 1999.10.29  ����                                    */
/******************************************************************/ 
/* ɨ��ʱ��'h'���Եõ�������                                      */
/* ɨ��ͨ���� AutoPoster(�Զ�����ϵͳ)����notepad�汨������ʱ�䡣 */
/* Ŀǰ��¼��114�롣(30*16, 99��).                                */
/******************************************************************/
#include "bbs.h"
int a[32][18],gameover;/*add by zhch for winmine*/
int winmine()
{
        int x,y;
        do
        {
                clear();
                gameover=0;
                modify_user_mode(WINMINE);
                for (x=0;x<=31;x++)
                for (y=0;y<=17;y++)
                        a[x][y]=0;
                winrefresh();
                winloop();
                clear();
        }
        while(askyn("�Ƿ������?",NA,NA)==YEA);
        return;
}


int wininit(int x1,int y1)
{
        int n,x,y;
        randomize();
        for(n=1;n<=99;n++)
        {
                do
                {
                        x=rand()%30+1;
                        y=rand()%16+1;
                 }
                while(a[x][y]!=0||(abs(x-x1)<2&&abs(y-y1)<2));
                a[x][y]=100;
        }
         for (x=1;x<=30;x++)
         for (y=1;y<=16;y++)
                 if (a[x][y]==100)
                {
                        if (a[x-1][y-1]<100)a[x-1][y-1]++;
                        if (a[x-1][y]<100)a[x-1][y]++;
                        if (a[x-1][y+1]<100)a[x-1][y+1]++;
                        if (a[x][y-1]<100)a[x][y-1]++;
                        if (a[x][y+1]<100)a[x][y+1]++;
                        if (a[x+1][y-1]<100)a[x+1][y-1]++;
                        if (a[x+1][y]<100)a[x+1][y]++;
                                if (a[x+1][y+1]<100)a[x+1][y+1]++;
                        }
}
int dblclick(int x,int y)
{
        int s,c,dx,dy;
        if(x<1||x>30||y<1||y>16)return;
        c=a[x][y];
        if(c<=512)return;
        c-=512;
        s=0;
        for(dx=x-1;dx<=x+1;dx++)
        for(dy=y-1;dy<=y+1;dy++)
                if(a[dx][dy]>=256&&a[dx][dy]<512)s++;
        if(s==c)
         {
                windig(x-1,y-1);
                windig(x-1,y);
                windig(x-1,y+1);
                windig(x,y-1);
                windig(x,y+1);
                windig(x+1,y-1);
                windig(x+1,y);
                windig(x+1,y+1);
        }
}

int windig(int x,int y)
{
        int c;
        if(x<1||x>30||y<1||y>16)return;
        c=a[x][y];
        if(c>=256)return;
        a[x][y]+=512;
        winsh(x,y,1);
        if(c==100)
        {
                gameover=1;
                return;
        }
        if(c==0)
        {
                windig(x-1,y-1);
                windig(x-1,y);
                windig(x-1,y+1);
                windig(x,y-1);
                windig(x,y+1);
                windig(x+1,y-1);
                windig(x+1,y);
                windig(x+1,y+1);
        }
}

int winsh(int x, int y, int cc)
{
        int c,c1;
        c=a[x][y];
        if(cc!=0)move(y-1,x*2-2);
        if (c<256){prints("��");return;}
        if (c>=256&&c<512)prints("��");
        c-=512;
        c1=1;
        if(c==0)c1=0;
        if(c==0)prints("��");
        if(c==1)prints("��");
        if(c==2)prints("��");
        if(c==3)prints("��");
        if(c==4)prints("��");
        if(c==5)prints("��");
        if(c==6)prints("��");
        if(c==7)prints("��");
        if(c==8)prints("��");
        if(c==100)prints("%c[31;1m��%c[m",27,27);
}

int winloop()
{
        int x,y,c,marked,clicks,t0;
        x=10;
        y=8;
        marked=0;
        clicks=0;
        egetch();
        move(y-1,x*2-2);
        t0=time(0);
        while(1)
        {
                c=egetch();
                if(c==257&&y>1)y--;
                if(c==258&&y<16)y++;
                if(c==260&&x>1)x--;
                if(c==259&&x<30)x++;
                move(20,0);
                prints("ʱ��: %d ",time(0)-t0);
                        move(20,40);
                        prints("���: %d ",marked);
                        move(22,0);
                prints("����: %d,  %d    ",x,y);
                move(y-1,x*2-2);
                if(c=='h'||c=='H')winhelp();
                        if(c=='d'||c=='D')winrefresh();
                if(c=='f'||c=='F'){
                                clicks++;
                                if(clicks==1)wininit(x,y);
                                dig(x,y);
        }
        if((c=='s'||c=='S')&&a[x][y]<512)
        {
                if(a[x][y]>=256){a[x][y]-=256;marked--;}else{a[x][y]+=256;marked++;}
                        winsh(x,y,1);
        }
        if(c=='q'||c=='Q')return;
        if(checkwin()==1)
                {
                        move(22,0);
                        prints("You win!");
                        win_report(time(0)-t0);
                        gameover=0;
                        pressreturn();
                        return;
                }
                if(gameover==1)
        {
                move(22,0);
                prints("GAME OVER");
                        gameover=0;
                pressreturn();
                return;
        }
        move(y-1,x*2-2);
        }
}

int checkwin()
{
        int x,y,s;
        s=0;
        for(x=1;x<=30;x++)
        for(y=1;y<=16;y++)
                if(a[x][y]<512)s++;
        if(s==99)return 1;
        return 0;
}

int dig(int x,int y)
{
        if (a[x][y]<512) windig(x,y);else dblclick(x,y);
}

int winrefresh()
{
        int x,y;
        clear();
        prints("                                                               ɨ ��         \n");
        prints("                                                               ~~~~~         \n");
        move(23,0);
        prints("�����ɨ�ס�  ����: H �˳�: Q ��: F ����: S ");
        for(y=1;y<=16;y++)
        {
                move(y-1,0);
                for(x=1;x<=30;x++)
                winsh(x,y,0);
        }
}

int winhelp()
{
        clear();
        prints("==��ӭ�μӼ���ɨ����Ϸ==\n---------------------------------\n\n");
        prints("�淨�ܼ򵥣���windows�µ����ɨ�ײ��.\n");
        prints("  'F'���������൱�����������˫�������ã��������������λ��\n");
        prints("  �Զ��ж�Ҫ�������ֲ�����\n");
        prints("  'S'�����൱������Ҽ��Ĺ���, ����������.\n");
        prints("  'H'��������ʾ��������Ϣ.\n");
        prints("  'Q'���˳���Ϸ.\n");
        prints("  ����Ļ�ҵ�ʱ������'D'������ˢ����Ļ��\n");
        prints("������Netterm��cterm����(��ȻnjutermҲ����,:)),telnetЧ������̫��\n");
        prints("��һ�ε��һ���ῪһƬ��������ɡ�\n");
        prints("�������ٶȻ��Ǻܿ�ģ��������Դﵽ���ɨ�׵��ٶ�.\n");
        pressreturn();
        winrefresh();
}

int win_report(int dt)
{
                FILE *fn;
                char filename[STRLEN],buf1[40];
                sprintf(filename,"tmp/record.%s",currentuser.userid);
                sprintf(buf1,"%sɨ�׳ɹ���ʱ��Ϊ%d�롣",currentuser.userid,dt);
                if ((fn=fopen(filename,"w")) != NULL)
                {
                        fprintf(fn,"���⡣ף��%s.\n",currentuser.userid);
                        fclose(fn);
                        postfile(filename, "notepad", buf1,1);
                        unlink(filename);
                }
}
