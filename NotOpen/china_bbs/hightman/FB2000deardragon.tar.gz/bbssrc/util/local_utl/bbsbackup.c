#include <time.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void)
{
	time_t now;
	struct tm *tm;
	char dircomd[80];

	now=time(0);
        tm = localtime(&now);
	sprintf(dircomd,"tar vzcf /home/BBSbackup/FB3.0GB_dragon_%04d%02d%02d.tar.gz /home/bbssrc /home/bbs",tm->tm_year+1900,tm->tm_mon+1,tm->tm_mday); 
	system(dircomd); 
}
