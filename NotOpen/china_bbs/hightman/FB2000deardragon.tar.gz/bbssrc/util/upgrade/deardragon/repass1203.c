#include <time.h>
#include <string.h>
#include <stdio.h>
#define STRLEN	 80
#define PASSLEN    14
#define	IDLEN 12  
struct userec {                  /* Structure used to hold information in */
        char            userid[IDLEN+2];   /* PASSFILE */
        time_t          firstlogin;
        char            lasthost[16];
        unsigned int    numlogins;
        unsigned int    numposts;
        unsigned int    nummedals; /* ������ */
        unsigned int    money;   /* ��� */
        unsigned int    bet;     /* ���� */
        time_t          dateforbet;
        char            flags[2];
        char            passwd[PASSLEN];
        char            username[20];
        char            ident[40];
        char            termtype[16];
        char            reginfo[STRLEN-16];
        unsigned int    userlevel;
        time_t          lastlogin;
        time_t          lastlogout;/* �������ʱ�� */
        time_t          stay;
        char            realname[20];
        char            address[STRLEN];
        char            email[STRLEN-12];
        unsigned int    nummails;
        time_t          lastjustify;
        char            gender;
        unsigned char   birthyear;
        unsigned char   birthmonth;
        unsigned char   birthday;
        int             signature;
        unsigned int    userdefine;
        time_t          notedate;
        int             noteline;
} old;
struct newuserec {                  /* Structure used to hold information in */
        char            userid[IDLEN+2];   /* PASSFILE */
        time_t          firstlogin;
        char            lasthost[16];
        unsigned int    numlogins;
        unsigned int    numposts;
        unsigned int    nummedals; /* ������ */
        unsigned int    money;   /* ��� */
        unsigned int    bet;     /* ���� */
        time_t          dateforbet;
        char            flags[2];
        char            passwd[PASSLEN];
        char            username[40];
        char            ident[40];
        char            termtype[16];
        char            reginfo[STRLEN-16];
        unsigned int    userlevel;
        time_t          lastlogin;
        time_t          lastlogout;/* �������ʱ�� */
        time_t          stay;
        char            realname[40];
        char            address[STRLEN];
        char            email[STRLEN-12];
        unsigned int    nummails;
        time_t          lastjustify;
        char            gender;
        unsigned char   birthyear;
        unsigned char   birthmonth;
        unsigned char   birthday;
        int             signature;
        unsigned int    userdefine;
        time_t          notedate;
        int             noteline;
} new;
 
int
doit()
{
        int i, j;
        FILE *src, *dst;

        src = fopen(".PASSWDS", "rb");
        dst = fopen(".PASSWDS.new", "wb");

        j = 1;
        for ( i = 0 ; ; i++ ) {

                if ( fread(&old,sizeof(old),1,src) <= 0 )
                        break;
                if ( strlen(old.userid) <= 0 )
                        continue;       /* drop out! */

                printf("Processing #%d userid: %s\n", i+1, old.userid);
                memset( &new, 0, sizeof( new ) );
        memcpy( &new.userid, old.userid, sizeof(old.userid));
	memcpy( &new.firstlogin, &old.firstlogin, sizeof(old.firstlogin));
	memcpy( &new.lasthost, &old.lasthost, sizeof(old.lasthost));
	memcpy( &new.numlogins, &old.numlogins, sizeof(old.numlogins));
	memcpy( &new.numposts, &old.numposts, sizeof(old.numposts));
	new.nummedals = old.nummedals;
	new.money = old.money;
	new.bet = old.bet;
	memcpy( &new.dateforbet, &old.dateforbet, sizeof(old.dateforbet));
	memcpy( &new.flags, &old.flags, sizeof(old.flags));
	memcpy( &new.passwd, &old.passwd, sizeof(old.passwd));
	memcpy( &new.username, &old.username, sizeof(old.username));
	memcpy( &new.ident, &old.ident, sizeof(old.ident));
	memcpy( &new.termtype, &old.termtype, sizeof(old.termtype));
	memcpy( &new.reginfo, &old.reginfo, sizeof(old.reginfo));
	memcpy( &new.userlevel, &old.userlevel, sizeof(old.userlevel));
	memcpy( &new.lastlogin, &old.lastlogin, sizeof(old.lastlogin));
	memcpy( &new.lastlogout, &old.lastlogout, sizeof(old.lastlogout));
	memcpy( &new.stay, &old.stay, sizeof(old.stay));
	memcpy( &new.realname, &old.realname, sizeof(old.realname));
	memcpy( &new.address, &old.address, sizeof(old.address));
	memcpy( &new.email, &old.email, sizeof(old.email));
	new.nummails = 0;
	memcpy( &new.lastjustify, &old.lastjustify, sizeof(old.lastjustify));
	memcpy( &new.gender, &old.gender, sizeof(old.gender));
	new.birthyear = old.birthyear;
	new.birthmonth = old.birthmonth;
	new.birthday = old.birthday;
	memcpy( &new.signature, &old.signature, sizeof(old.signature));
	memcpy( &new.userdefine, &old.userdefine, sizeof(old.userdefine));
	memcpy( &new.notedate, &old.notedate, sizeof(old.notedate));
	memcpy( &new.noteline, &old.noteline, sizeof(old.noteline));
                printf("  writing, sizeof(old)=%d sizeof(new)=%d ..",
                                sizeof(old), sizeof(new));

                if ( !fwrite(&new, sizeof(new), 1, dst) ) {
                        printf("failed!!\n");
                        exit(0);
                } else {
                        printf("done.\n");
                }

                j++;
        }

        fclose(src);
        fclose(dst);

        printf("done. total %d of %d users transfeerd\n",j ,i+1);
        printf("remember clean shm before replace new PASSWDS file!\n");
        return 0;
}

int
main()
{
        doit();
	return 0;
}
