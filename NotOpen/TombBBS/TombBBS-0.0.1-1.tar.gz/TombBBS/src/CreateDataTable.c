/** 
@file CreateDataTable.c
@brief �إ߸�ƪ������禡��@�C

�o���ɮץ]�A�إ߸�ƪ����禡��@�C

@author  �j�ӼC�P(Brian Hsu) brianhsu@oldman.twbbs.org.tw
@version 0.0.1
@date    2002/07

Copyright (c) 2002 Brian Hsu ( �j�ӼC�P )
  
This file is part of TombBBS.

TombBBS is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

TombBBS is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with TombBBS; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
/**
@defgroup CreateDataTable ��l�� BBS ��Ʈw�禡

��l�� BBS ��Ʈw�禡

*/
#include "CreateDataTable.h"

/**
@brief   �إ� BBS ��ƪ��C
@ingroup CreateDataTable

�o�Ө�Ʒ|�إ� BBS �һݭn�ϥΨ쪺��ƪ��C

@author  �j�ӼC�P(Brian Hsu) brianhsu@oldman.twbbs.org.tw

@retval  TRUE  ���\
@retval  FALSE ����
*/
TBoolean CreateDataTable()
{
  char * Query;
  MYSQL DataBase;
  
  mysql_init ( &DataBase );
  
  if ( mysql_real_connect ( &DataBase , DataBaseAddr , DataBaseUser , 
       DataBasePass , DataBaseName , 0 , NULL , 0 ) == NULL )
  {
    fprintf ( stderr , _("�L�k�s���ܸ�Ʈw�G%s\n") , mysql_error(&DataBase) );
    mysql_close ( &DataBase );
    return FALSE;
  }

  printf ( _("���\\�s���ܸ�Ʈw�A�إ߸�ƪ���...\n") );
  
  Query = strdup("CREATE TABLE TombUser\n (\n UserSN INT NOT NULL AUTO_INCREMENT,\n UserName VARCHAR(12) NOT NULL,\n Password VARCHAR(35) NOT NULL,\n TitleSN INT NOT NULL,\n NickName VARCHAR(24) NOT NULL,\n EMail VARCHAR(255) NOT NULL,\n AcceptPager enum('Y','N'),\n AcceptTalk enum('Y','N'),\n LoginCount INT NOT NULL,\n PostCount INT NOT NULL,\n StayTime INT NOT NULL,\n LastLoginTime INT NOT NULL,\n RegisterTime INT NOT NULL,\n PRIMARY KEY( UserSN ),\n UNIQUE ( UserName )\n)\n ");
  
  printf ( _("�إߨϥΪ̦C����ƪ�...\n") );
  if ( mysql_query ( &DataBase , Query ) != 0 )
  {
    fprintf ( stderr , _("�L�k�إߨϥΪ̦C����ƪ��G%s\n") , 
              mysql_error(&DataBase) );
    mysql_close ( &DataBase );

    return FALSE;
  }
  free ( Query );


  Query = strdup(" CREATE TABLE TombUserFile\n (\n UserSN INT NOT NULL,\n Plan BLOB,\n Sign1 BLOB,\n Sign2 BLOB,\n Sign3 BLOB,\n Sign4 BLOB,\n Sign5 BLOB,\n Sign6 BLOB,\n UNIQUE ( UserSN )\n) ");
  printf ( _("�إߨϥέӤH�ɮ׸�ƪ�...\n") );
  if ( mysql_query ( &DataBase , Query ) != 0 )
  {
    fprintf ( stderr , _("�L�k�إߨϥΪ̭ӤH�ɮ׸�ƪ��G%s\n") , 
              mysql_error(&DataBase) );
    mysql_close ( &DataBase );

    return FALSE;
  }
  free ( Query );

  Query = strdup(" CREATE TABLE TombTitle\n (\n TitleSN INT NOT NULL AUTO_INCREMENT,\n Title VARCHAR(24) NOT NULL,\n Sex enum('M','F') NOT NULL,\n PRIMARY KEY( TitleSN )\n) ");

  printf ( _("�إߨ����C����ƪ�...\n") );
  if ( mysql_query ( &DataBase , Query ) != 0 )
  {
    fprintf ( stderr , _("�L�k�إߨ����C����ƪ��G%s\n") , 
              mysql_error(&DataBase) );
    mysql_close ( &DataBase );

    return FALSE;
  }
  free ( Query );

  Query = strdup(" CREATE TABLE TombWelcomeMessage\n (\n SN INT NOT NULL AUTO_INCREMENT,\n Message BLOB NOT NULL,\n AuthorUserSN INT NOT NULL,\n PostTime INT NOT NULL,\n UNIQUE ( SN )\n) ");
  printf ( _("�إ߶i���e����ƪ�...\n") );
  if ( mysql_query ( &DataBase , Query ) != 0 )
  {
    fprintf ( stderr , _("�L�k�إ߶i���e����ƪ��G%s\n") , 
              mysql_error(&DataBase) );
    mysql_close ( &DataBase );

    return FALSE;
  }
  free ( Query );


  Query = strdup(" CREATE TABLE TombRegExam \n (\n SN INT NOT NULL AUTO_INCREMENT,\n Question TEXT NOT NULL,\n Answer CHAR(1) NOT NULL,\n AnswerExplain TEXT NOT NULL,\n PRIMARY KEY(SN)\n) ");
  printf ( _("�إ߸ծw��ƪ�...\n") );
  if ( mysql_query ( &DataBase , Query ) != 0 )
  {
    fprintf ( stderr , _("�L�k�إ߸ծw��ƪ��G%s\n") , 
              mysql_error(&DataBase) );
    mysql_close ( &DataBase );

    return FALSE;
  }
  free ( Query );

  Query = strdup(" CREATE TABLE TombOnlineList\n (\n UserSN INT NOT NULL,\n OnlineHost VARCHAR(255) NOT NULL,\n Status VARCHAR(255) NOT NULL,\n IdleTime INT NOT NULL\n) ");
  printf ( _("�إߤW�u�C����ƪ�...\n") );
  if ( mysql_query ( &DataBase , Query ) != 0 )
  {
    fprintf ( stderr , _("�L�k�إߤW�u�C����ƪ��G%s\n") , 
              mysql_error(&DataBase) );
    mysql_close ( &DataBase );

    return FALSE;
  }
  free ( Query );
  
  Query = strdup ( "CREATE TABLE TombBoardMainClass\n (\nSN INT NOT NULL AUTO_INCREMENT,\n TableName VARCHAR(255) NOT NULL,\n ClassOrBoard enum('C','B'),\n PRIMARY KEY(SN)\n)\n ");
  printf ( _("�إ߬ݪO�D������ƪ�...\n") );
  if ( mysql_query ( &DataBase , Query ) != 0 )
  {
    fprintf ( stderr , _("�L�k�إ߬ݪO�D������ƪ��G%s\n") , 
              mysql_error(&DataBase) );
    mysql_close ( &DataBase );

    return FALSE;
  }
  free ( Query );
  mysql_close ( &DataBase );

  return TRUE;
}
