/**
@file I18N.h
@brief I18N �]�w���Y�C

�]�w I18N ���U�������C

@author  �j�ӼC�P(Brian Hsu) brianhsu@oldman.twbbs.org.tw
@version 0.0.1
@date    2002/07

Copyright (c) 2002 Brian Hsu ( �j�ӼC�P )
  
This file is part of TombBBS.

TombBBS is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

TombBBS is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with TombBBS; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
#ifndef __I18N_H__
#define __I18N_H__

#include <locale.h>
#include <libintl.h>

///�w�q _(STRING) �浹 GNU GetText �B�z
#define _(STRING)  gettext(STRING)
///�w�q PACKAGE ���o�ӵ{�����W�r "TombBBS"
#define PACKAGE    "TombBBS"

#endif
