/** 
@file CreateDataTable.h
@brief �إ߸�ƪ������禡���Y�C

�o���ɮץ]�إ߸�ƪ��ɥΪ��禡���Y�C

@author  �j�ӼC�P(Brian Hsu) brianhsu@oldman.twbbs.org.tw
@version 0.0.1
@date    2002/07

Copyright (c) 2002 Brian Hsu ( �j�ӼC�P )
  
This file is part of TombBBS.

TombBBS is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

TombBBS is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with TombBBS; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include <stdlib.h>
#include <stdio.h>
#include <mysql.h>
#include <string.h>
#include "Struct.h"
#include "I18N.h"
#include "Setup.h"

#ifndef __CREATE_DATABASE_H__
#define __CREATE_DATABASE_H__

/**
@brief    �إ� BBS ��ƪ��C

�o�Ө�Ʒ|�إ� BBS �һݭn�ϥΨ쪺��ƪ��C

@author  �j�ӼC�P(Brian Hsu) brianhsu@oldman.twbbs.org.tw

@retval  TRUE ���\
@retval  FALSE ����
*/
TBoolean CreateDataTable();

#endif

