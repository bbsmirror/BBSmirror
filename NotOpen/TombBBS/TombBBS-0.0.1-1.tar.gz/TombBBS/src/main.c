#include "Struct.h"
#include "DataBase.h"
int main()
{
  AddTitleToDataTable("���D",Female);
}
