/home/bbs/bin/camera
/home/bbs/bin/account
/home/bbs/bin/acpro
/home/bbs/bin/makefw
