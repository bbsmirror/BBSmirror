#include "bbs.h"

int
Get_Socket(site, sock)  /* site for hostname, sock for port & socket */
  char *site;
  int *sock;
{
  struct sockaddr_in sin;
  struct hostent *host;

  /* Getting remote-site data */

  (void) memset((char *) &sin, 0, sizeof(sin));
  sin.sin_family = AF_INET;
  sin.sin_port = htons(*sock);
  if((host = gethostbyname(site)) == NULL)
    sin.sin_addr.s_addr = inet_addr(site);

  else
    (void) memcpy(&sin.sin_addr.s_addr, host->h_addr, host->h_length);

  /* Getting a socket */

  if((*sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  {
    return -1;
  }

#ifdef	SET_ALARM
  signal(SIGALRM, timeout);
  alarm(SET_ALARM);
#endif

  /* perform connecting */

  if(connect(*sock, (struct sockaddr *) & sin, sizeof(sin)) < 0)
  {
    close(*sock);

#ifdef	SET_ALARM
  init_alarm();
#endif

    return -3;
  }

#ifdef	SET_ALARM
  init_alarm();
#endif

  return 0;
}



int
POP3_Check(site, account, passwd)
  char *site, *account, *passwd;
{
  FILE *fsock = NULL;
  int sock=110,old_sock = 0;
  char buf[512];

  if(Get_Socket(site, &sock))
    sock = 1;
  else
  if(!(fsock = fdopen(sock, "r+")))
  {
    close(sock);
    sock = 1;
  }
  else
  {
    old_sock = sock;
    sock = 2;
  }

  while(sock < 6)
  {
    switch(sock)
    {
      case 1:		/* Open Socket Fail */
        prints("\n�Ǧ^���~�� [1], �Э��մX���ݬ�\n");
        refresh();
        return sock;

      case 2:		/* Welcome Message */
        fgets(buf, 512, fsock);
        break;

      case 3:		/* Verify Account */
        fprintf(fsock, "user %s\r\n", account);
        fflush(fsock);
        fgets(buf, 512, fsock);
        break;
      
      case 4:		/* Verify Password */
        fprintf(fsock, "pass %s\r\n", passwd);
        fflush(fsock); 
        fgets(buf, 512, fsock);
        sock = -1;
        break;
      
      case 0:		/* Successful Verification */
      case 5:		/* Quit */
        fprintf(fsock, "quit\r\n");
        fclose(fsock);
        if(old_sock)
          close(old_sock);
        return sock;
    }
  
    if(strncmp(buf, "+OK", 3) || strstr(buf, ".bbs"))
    {
      prints("���ݨt�ζǦ^���~�T���p�U�G(�p�����հT���N��A�бN�T���i������)\n");
      prints("%s\n", buf);
      refresh();
/*      log_usies("POP3-MSG", buf, FN_VERIFY_LOG); */
      sock = 5;
    }
    else
      sock++;
  }
  return 1;
}
