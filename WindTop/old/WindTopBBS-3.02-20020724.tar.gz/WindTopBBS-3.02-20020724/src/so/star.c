/*-------------------------------------------------------*/
/* star.c    (YZU WindTopBBS Ver 3.02 )                  */
/*-------------------------------------------------------*/
/* author : verit.bbs@bbs.yzu.edu.tw			 */
/* target : */
/* create : 01/07/09                                     */
/*-------------------------------------------------------*/

#include "bbs.h"

#define mouts(y,x,s)    { move(y,x); outs(s); }

#define HTTP_PORT       80
#define SERVER_star	"mindcity.sina.com.tw"
#define	REF		"west/MC-12stars/"
#define LINE_WORD	50

char *tag_s[4] = {"!--START:HORO_TODAY--","!--START:HORO_TOMORROW--",
                  "!--START:WEEKLY--","!--START:WEEKLY--"};
char *tag_e[4] = {"!--END:HORO_TODAY--","!--END:HORO_TOMORROW--",
                  "!--END:WEEKLY--","!--END:WEEKLY--"};

char *star[12] = {"aries","taurus","gemini","cancer","leo","virgo",
                  "libra","scorpio","sagittarius","capricorn","aquarius","pisces"};

char *star_menu[8];

static int
http_conn(char *server, char *s,int kind)
{
  int sockfd, start_show,chinese=0,state=0;
  int cc, tlen,word=0;
  char *xhead, *xtail, tag[128], fname[50];
  static char pool[2048];
  FILE *fp;

  mouts(23, 0, "���b�s�����A���A�еy��..........");
  if ((sockfd = dns_open(server, HTTP_PORT)) < 0)
  {
    vmsg("�L�k�P���A�����o�s���A�d�ߥ���");
    return 0;
  }
  else
  {
    refresh();
  }

  write(sockfd, s, strlen(s));
  shutdown(sockfd, 1);

  /* parser return message from web server */
  xhead = pool;
  xtail = pool;
  tlen = 0;
  start_show = 0;
  sprintf(fname, "tmp/%s.star", cuser.userid);
  fp = fopen(fname, "w");
  for (;;)
  {
    if (xhead >= xtail)
    {
      xhead = pool;
      cc = read(sockfd, xhead, sizeof(pool));
      if (cc <= 0)
	break;
      xtail = xhead + cc;
    }
    cc = *xhead++;

    if ((tlen == strlen(tag_s[kind])+1) && (!str_ncmp(tag,tag_s[kind],strlen(tag_s[kind]))))
      start_show = 1;
    if ((tlen == strlen(tag_e[kind])+1) && (!str_ncmp(tag,tag_e[kind],strlen(tag_e[kind]))))
      break;

    if (cc == '<' || cc == '&')
    {
      tlen = 1;
      continue;
    }
    if (tlen)
    {
      if (cc == '>' || cc == ';')
      {
	if ((tlen == 3) && (!str_ncmp(tag, "br", 2)) && start_show == 1 && state == 0)
	{
 	   fputc('\n', fp);
 	   fputs("       \t",fp);
 	   state = 1;
 	}
 	else if ((tlen == 3) && (!str_ncmp(tag, "tr", 2)) && start_show == 1 && kind>1 && state == 0)
 	{
 	   fputc('\n', fp);
 	   fputs("       \t",fp);
 	   state =1;
 	}
	tlen = 0;
	word=0;
	continue;
      }
      if (tlen <= 128)
	tag[tlen - 1] = cc;
      tlen++;
      continue;
    }
    if (start_show)
    {
      if (word > LINE_WORD && cc<0 && chinese==0 && state == 0)
      {
        fputc('\n',fp);
        fputs("       \t",fp);
        state = 1;
        word = 0 ;
      }
      if (cc == ' ')
        chinese=0;
      else if (cc != '\r' && cc != '\n')
      {
        word++;
	fputc(cc, fp);
	state =0 ;
	chinese = (cc<0)?((chinese==1)?0:1):0;
      }
      else
      {
        word = 0;
      }
    }
  }
  close(sockfd);
  fputc('\n', fp);
  fclose(fp);
  more(fname, NULL);
  unlink(fname);
  return 0;
}

int draw_star(int top,int left)
{
  move(top,left);clrtoeol();
  prints("\033[32m�~�w��\033[m");
  move(top+1,left);clrtoeol();
  prints("\033[32m�x  �x\033[m");
  move(top+2,left);clrtoeol();
  prints("\033[32m���w��\033[m");
  move(top+3,left);clrtoeol();
  prints("\033[32m�x  �x\033[m");
  move(top+4,left);clrtoeol();
  prints("\033[32m���w��\033[m");
  move(top+5,left);clrtoeol();
  prints("\033[32m�~�s��\033[m");
  move(top+6,left);clrtoeol();
  prints("\033[32m�x�x�x\033[m");
  move(top+7,left);clrtoeol();
  prints("\033[32m�x�x�x\033[m");
  move(top+8,left);clrtoeol();
  prints("\033[32m  �x  \033[m");
  move(top+9,left);clrtoeol();
  prints("\033[32m  �x  \033[m");
  move(top+10,left);clrtoeol();
  prints("\033[32m�~�w��\033[m");
  move(top+11,left);clrtoeol();
  prints("\033[32m�x  �x\033[m");
  move(top+12,left);clrtoeol();
  prints("\033[32m�u�w�t\033[m");
  move(top+13,left);clrtoeol();
  prints("\033[32m�x  �x\033[m");
  move(top+14,left);clrtoeol();
  prints("\033[32m�x  �x\033[m");
  move(top+15,left);clrtoeol();
  prints("\033[32m�~�w��\033[m");
  move(top+16,left);clrtoeol();
  prints("\033[32m�x  �x\033[m");
  move(top+17,left);clrtoeol();
  prints("\033[32m�u�w��\033[m");
  move(top+18,left);clrtoeol();
  prints("\033[32m�x �@ \033[m");
  move(top+19,left);clrtoeol();
  prints("\033[32m�x  �x\033[m");
  /*�U���ƪ��� :p*//*
  move(top+20,left);clrtoeol();
  prints("\033[32m      \033[m");
  move(top+21,left);clrtoeol();
  prints("\033[32m      \033[m");
  move(top+22,left);clrtoeol();
  prints("\033[32m      \033[m");
  */
}

int draw_today(int top,int left)
{
   FILE *fp;
   char buf[128];
   int i=0;

   fp = fopen("etc/star", "r");
   while(fp && fgets(buf,sizeof(buf),fp))
   {
      move(top+i,left);
      prints("%s",buf);
      i++;
   }

   return i;
}

int draw_kind_menu(int top,int left)
{
   move(top,left);
   clrtoeol();
   prints("\033[36;1m�~��\033[35m�B��\033[36m������������������\033[m");
   move(top+1,left);
   clrtoeol();
   prints("\033[36;1m��    \033[33m(1)  ����B��\033[36m     ��\033[m");
   move(top+2,left);
   clrtoeol();
   prints("\033[36;1m��    \033[33m(2)  ����B��\033[36m     ��\033[m");
#if 0
   move(top+3,left);
   clrtoeol();
   prints("\033[36;1m��    \033[33m(3)  ���g�B��\033[36m     ��\033[m");
   move(top+4,left);
   clrtoeol();
   prints("\033[36;1m��    \033[33m(4)  ����B��\033[36m     ��\033[m");
#endif
   move(top+3,left);
   clrtoeol();
   prints("\033[36;1m��������������������������\033[m");
   move(top+5,left);
   clrtoeol();
   prints("\033[36;1m ������������\033[32mBy Verit\033[36m���� \033[m");

   return 1;
}

int draw_star_menu(int top,int left)
{
    move(top+0,left);clrtoeol();
    prints("\033[36;1m�~��\033[35m�P�y\033[36m����������������������������\033[m");
    move(top+1,left);clrtoeol();
    prints("\033[36;1m�� \033[33m(A)�d�Ϯy (E)��l�y (I) �g��y\033[36m ��\033[m");
    move(top+2,left);clrtoeol();
    prints("\033[36;1m�� \033[33m(B)�����y (F)�B�k�y (J) �]�~�y\033[36m ��\033[m");
    move(top+3,left);clrtoeol();
    prints("\033[36;1m�� \033[33m(C)���l�y (G)�ѯ��y (K) ���~�y\033[36m ��\033[m");
    move(top+4,left);clrtoeol();
    prints("\033[36;1m�� \033[33m(D)���ɮy (H)���Ȯy (L) �����y\033[36m ��\033[m");
    move(top+5,left);clrtoeol();
    prints("\033[36;1m������������������������������������\033[37m\033[37m\033[m");

    return 1;
}

int
main_star()
{
  int kind_now,star_now,line;
  char buf[128];

  clear();
  draw_star(1,1);
  line = draw_today(1,15);
  draw_star_menu(line+1,15);
  draw_kind_menu(line+1,71);

  do{
    buf[0] = 0;
    vget(21,15,"�п�ܧA���P�y [A-L] : ",buf,2,1);
    if((buf[0]<='l' && buf[0]>='a')||(buf[0]<='H' && buf[0]>='A'))
    {
       star_now = toupper(buf[0]) - 'A';
       break;
    }
    else if( !buf[0])
    {
       return 0;
    }
    else
    {
      vmsg("�п�J���T�d�� A-L !!");
    }
  }while(1);
  do
  {
    buf[0] = 0 ;
    vget(22,15,"�п�ܱ��d�ߤ������B�� [1-2] : ",buf,2,1);
    if(buf[0]>'0' && buf[0] < '3')
    {
      kind_now = buf[0] - '0';
      break ;
    }
    else if( !buf[0] )
    {
       return 0;
    }
    else
    {
      vmsg("�п�J���T�d�� 1-4 !!");
    }
  }while(1);

  sprintf(buf,"GET /west/MC-12stars/%s%d.html HTTP/1.0\n\n",star[star_now],kind_now);
  http_conn(SERVER_star,buf,kind_now-1);

  return 0;
}
