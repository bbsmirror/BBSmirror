/*-------------------------------------------------------*/
/* util/countage.c      ( NTHU CS MapleBBS Ver 3.00 )    */
/*-------------------------------------------------------*/
/* author : wsyfish.bbs@fpg.m4.ntu.edu.tw		 */
/* Modify : visor.bbs@bbs.yzu.edu.tw			 */
/* target : ���W�~�ֲέp                                 */
/* create : 97/09/05                                     */
/* update : 2000/07/27                                   */
/* ��: �ק� �ۭ쥻 yearsold.c                		 */
/*-------------------------------------------------------*/


#include "bbs.h"
#define MAX_LINE        16
#define OUTFILE     BBSHOME"/gem/@/@-yearsold"

void
fouts(fp, buf, mode)
  FILE *fp;
  char buf[], mode;
{
  static char state = '0';

  if (state != mode)
    fprintf(fp, "[3%cm", state = mode);
  if (buf[0])
  {
    fprintf(fp, buf);
    buf[0] = 0;
  }
}

int
main(void)
{
  int  i, j;
  char buf[256],c;
  FILE *fp;
  int  year, max, item, maxyear;
  int totalyear=0 ;
  int act[25];
  time_t now;
  struct tm *ptime;

  chdir(BBSHOME);

  now = time(NULL) ;
  ptime = localtime(&now);


  memset(act,0,sizeof(act));

  for (c = 'a'; c <= 'z'; c++)
  {
    char buf[64];
    struct dirent *de;
    DIR *dirp;

    sprintf(buf, BBSHOME "/usr/%c", c);

    if (!(dirp = opendir(buf)))
      continue;

    while (de = readdir(dirp))
    {
      ACCT cuser;
      USER_ATTR	attr;
      int fd;

      if (de->d_name[0] <= ' ' || de->d_name[0] == '.')
        continue;

      usr_fpath(buf,de->d_name,".ACCT"); 
      if ((fd = open(buf, O_RDONLY)) < 0)
        continue;

      read(fd, &cuser, sizeof(cuser));
      close(fd);
      memset(&attr,0,sizeof(USER_ATTR));
      if(attr_get(cuser.userid,ATTR_USER_KEY,&attr) < 0)
        continue;

    if(((ptime->tm_year - (attr.year -1900)) < 10) || ((ptime->tm_year - (attr.year-1900)) >33))
      continue;

    act[ptime->tm_year - (attr.year-1900) - 10]++;
    act[24]++;

     } /* while */
    closedir(dirp);
  } /* for */

  for (i = max  = totalyear = maxyear = 0; i < 24; i++)
  {
    totalyear += act[i] * (i + 10);
    if (act[i] > max)
    {
      max = act[i];
      maxyear = i;
    }
  }

  item = max / MAX_LINE + 1;

  if ((fp = fopen(OUTFILE, "w")) == NULL)
  {
    printf("cann't open gem/@/@-yearsold\n");
    return 0;
  }
  
  fprintf(fp, "\t\t\t [1;33;45m ������ �~�ֲέp [%02d/%02d/%02d] [m\n\n",
     (ptime->tm_year)%100,ptime->tm_mon+1,ptime->tm_mday);
  for (i = MAX_LINE + 1; i > 0; i--)
  {
    strcpy(buf, "   ");
    for (j = 0; j < 24; j++)
    {
      max = item * i;
      year = act[j];
      if (year && (max > year) && (max - item <= year))
      {
        fouts(fp, buf, '7');
        fprintf(fp, "%-3d", year);
      }
      else if (max <= year)
      {
        fouts(fp, buf, '4');
        fprintf(fp, "�i ");
      }
      else
        strcat(buf, "   ");
    }
    fprintf(fp, "\n");
  }

  fprintf(fp, "  [1;35m�������������������������������������������������������������������������� \n"
    "   [1;32m10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33\n"
    "\t\t      [36m���Ĳέp�H���G[37m%-9d[36m�����~�֡G[37m%d[40;0m\n"
    , act[24],(int) totalyear / (act[24] ? act[24] : 1));
  fclose(fp);
  return 0;
}
