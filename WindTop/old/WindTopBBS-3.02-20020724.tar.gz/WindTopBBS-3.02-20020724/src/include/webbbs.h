/*-------------------------------------------------------*/
/* include/webbbs.h	(YZU WindTopWebBBS 1.0)		 */
/*-------------------------------------------------------*/
/* author : visor.bbs@bbs.yzu.edu.tw			 */
/* target : 						 */
/* create : 						 */
/* update : 						 */
/*-------------------------------------------------------*/

#define	FN_TOP_LOGIN	"webbbs/top_logon.dat"
#define	FN_TOP_POST	"webbbs/top_post.dat" 
#define	FN_TOP_STAY	"webbbs/top_stay.dat"
