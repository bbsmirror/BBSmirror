#ifndef INNBBSD_H
#define INNBBSD_H
#include "daemon.h"

#ifndef ADMINUSER
# define ADMINUSER "program.bbs@bbs.yzu.edu.tw"
#endif

#endif
