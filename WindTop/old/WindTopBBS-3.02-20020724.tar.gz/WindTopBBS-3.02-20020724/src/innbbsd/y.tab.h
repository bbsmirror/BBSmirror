#ifndef BISON_Y_TAB_H
# define BISON_Y_TAB_H

#ifndef YYSTYPE
typedef union {
    time_t		Number;
    enum _MERIDIAN	Meridian;
} yystype;
# define YYSTYPE yystype
# define YYSTYPE_IS_TRIVIAL 1
#endif
# define	tDAY	257
# define	tDAYZONE	258
# define	tMERIDIAN	259
# define	tMONTH	260
# define	tMONTH_UNIT	261
# define	tSEC_UNIT	262
# define	tSNUMBER	263
# define	tUNUMBER	264
# define	tZONE	265


extern YYSTYPE yylval;

#endif /* not BISON_Y_TAB_H */
