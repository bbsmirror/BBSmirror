//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "main.h"
#include "txt2html.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

/* ----------------------------------------------------- */
/* Convert Maple gem to HTMLHelp Content file (.hcc)	 */
/* Modfied: 2000/03/12                                   */
/* ----------------------------------------------------- */

/* ----------------------------------------------------- */
/* DIR of post / mail struct : 256 bytes		 */
/* ----------------------------------------------------- */
TMainForm *MainForm;
//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BtnConvertClick(TObject *Sender)
{
        char buf[1024] = ".DIR";

        // change working directory

        chdir(ExtractFilePath(EditDIR->Text).c_str());
        if(Edit1->Text.Length() <= 0)
        {
           MessageDlg("Output file error!", mtInformation,TMsgDlgButtons() << mbYes, 0);
           return;
        }

	if ((fout = fopen("TOC.hhc", "wt")) == NULL)
        {
           MessageDlg("Open TOC.hhc error!", mtInformation,
                     TMsgDlgButtons() << mbYes, 0);
           return;
        }

	fprintf(fout, HHhead);
	bbs2hhc(buf);
	fprintf(fout, HHtail);
	fclose(fout);

        //  Generate HTMLHelp Project file (.hhp)

        strcpy(buf,Edit1->Text.c_str());
        strcat(buf,".hhp");

        if ((fout = fopen(buf, "wt")) == NULL)
        {
           sprintf(buf,"Open %s.hhp error!",Edit1->Text.c_str());
           MessageDlg(buf, mtInformation,TMsgDlgButtons() << mbYes, 0);
           return ;
        }

        fprintf(fout, "%s", HHProjectDesc);
        fprintf(fout, "title=%s\n", EditTitle->Text.c_str());  // ���D
        if (ChkFullTextSearch->Checked)                        // �����˯�
            fprintf(fout, "Full-text search=Yes\n");

        if (EditDefaultTopic->Text != "")                      // �w�]����
            fprintf(fout, "[FILES]\n%s \n", EditDefaultTopic->Text.c_str());

        fclose(fout);

        //  End of Generate HTMLHelp Project file (.hhp)

        sprintf(buf,"%s �w����!\n�Х� HTMLHelp WorkShop �sĶ�� .chm ���!",Edit1->Text.c_str());
        MessageDlg(buf,mtInformation, TMsgDlgButtons() << mbYes, 0);

}
//---------------------------------------------------------------------------
void __fastcall TMainForm::Button2Click(TObject *Sender)
{
   OpenDialog1->Title = "��� Mapple BBS .DIR ��";
   OpenDialog1->Filter = ".DIR ��|.DIR";
   OpenDialog1->FileName = "";
   if (OpenDialog1->Execute())
       EditDIR->Text = OpenDialog1->FileName;
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::Button3Click(TObject *Sender)
{
   OpenDialog1->Title = "��ܹw�]����";
   OpenDialog1->Filter = "HTML ���| *.htm; *.html";
   OpenDialog1->FileName = "";
   if (OpenDialog1->Execute())
       EditDefaultTopic->Text = OpenDialog1->FileName;
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::EditDIRChange(TObject *Sender)
{
   BtnConvert->Enabled = true;
}
//---------------------------------------------------------------------------

int __fastcall TMainForm::bbs2hhc(char *fd)
{
   HDR hdr;
   FILE *fptr;

    if ((fptr = fopen(fd, "rb")) == NULL)
	return -1;

    fd[1] = '\\';
    while (fread(&hdr, sizeof(HDR), 1, fptr) == 1)
    {
       if (hdr.xname[0] == '@' && !(hdr.xmode & GEM_FOLDER))
           continue;
       if (hdr.xname[0] != '@' && hdr.xname[0] != 'F' && hdr.xname[0] != 'A')
	   continue;  	        // skip index and log file

       if(hdr.xmode & (GEM_RESTRICT|GEM_RESERVED|GEM_LOCK))
           continue;

       if(hdr.xname[0] == '@')
           fd[0] = '@';
       else
           fd[0] = hdr.xname[7];

       strcpy(fd + 2, hdr.xname);
       if (hdr.xname[0] == 'A')
       {    // File
           char newname[256];

	   strcpy(newname, fd); strcat(newname, ".htm");
	   if (txt2html(fd, newname) == 0)
           {      // from txt2html.cpp
	      fprintf(fout, HHFileObject, hdr.title, newname);
              //DeleteFile(fd);          // unlink(fd), delete source file
           }
       }
       else if (hdr.xname[0] == 'F' || hdr.xname[0] == '@')
       { // Folder
	   fprintf(fout, HHFolderObject, hdr.title);
	   bbs2hhc(fd);
	   fprintf(fout, "</UL>\n");
       }
    }

    fclose(fptr);
    return 0;
}
