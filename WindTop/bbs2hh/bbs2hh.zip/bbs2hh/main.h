//---------------------------------------------------------------------------
#ifndef mainH
#define mainH
//---------------------------------------------------------------------------

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <dir.h>
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TMainForm : public TForm
{
__published:	// IDE-managed Components
        TButton *BtnConvert;
        TGroupBox *GroupBox1;
        TOpenDialog *OpenDialog1;
        TEdit *EditDIR;
        TButton *Button2;
        TGroupBox *GroupBox2;
        TCheckBox *ChkFullTextSearch;
        TEdit *EditDefaultTopic;
        TButton *Button3;
        TEdit *EditTitle;
        TLabel *Label1;
        TLabel *Label2;
        TEdit *Edit1;
        TLabel *Label3;
        void __fastcall BtnConvertClick(TObject *Sender);
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall Button3Click(TObject *Sender);
        void __fastcall EditDIRChange(TObject *Sender);
private:	// User declarations
        FILE *fout;
public:		// User declarations
        __fastcall TMainForm(TComponent* Owner);
        __fastcall bbs2hhc(char *fd);

};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------

typedef struct
{
  time_t chrono;		/* timestamp */
  int  xmode;
  long xid;			/* reserved */

  char xname[32];		/* �ɮצW�� */
  char owner[80];		/* �@�� (E-mail address) */
  char nick[50];		/* �ʺ� */

  char date[9];			/* [96/12/01] */
  char title[73];		/* �D�D (TTLEN + 1) */
}          HDR;

#define GEM_RESTRICT    0x00000800      /* ����ź�ذ� */
#define GEM_RESERVED    0x00001000      /* ����ź�ذ� */
#define GEM_LOCK        0x00002000      /* �W����šA�� sysop �~���� */

#define GEM_FOLDER      0x00010000      /* folder / article */

const char *HHhead =  // HtmlHelp Content File Header

  "<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML//EN\">\n"
  "<HTML>\n"
  "<HEAD></HEAD><BODY>\n"
  "<OBJECT type=\"text/site properties\">\n"
  "<param name=\"Window Styles\" value=\"0x800603\">\n"
  "</OBJECT>\n"
  "<UL>\n";

const char *HHtail =  // HtmlHelp Content File tail

  "</UL>\n"
  "</BODY></HTML>\n";

const char *HHFileObject =  // HtmlHelp Desription for a File

   "<LI> <OBJECT type=\"text/sitemap\">\n"
   "<param name=\"Name\" value=\"%s\">\n"
   "<param name=\"Local\" value=\"%s\">\n"
   "</OBJECT>\n";

const char *HHFolderObject = // HtmlHelp Description for a Folder

   "<LI> <OBJECT type=\"text/sitemap\">\n"
   "<param name=\"Name\" value=\"%s\">\n"
   "</OBJECT>\n"
   "<UL>\n";

const char *HHProjectDesc =  // Simple HtmlHelp Project Structure

   "[OPTIONS]\n"
   "Contents file=toc.hhc\n"
   "Language=0x404 Chinese (Taiwan)\n";
#endif
