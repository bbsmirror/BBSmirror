
char* escapestr(char*dstr,const char*sstr);
int txt2html(const char *file, const char *htmlfile);
