//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("bbs2hh.res");
USEFORM("main.cpp", MainForm);
USEUNIT("txt2html.cpp");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->Title = "WindTop BBS To HtmlHelp";
                 Application->CreateForm(__classid(TMainForm), &MainForm);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
