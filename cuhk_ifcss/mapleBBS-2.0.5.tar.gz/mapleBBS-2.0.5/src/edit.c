/* edit.c */

#include "bbs.h"

#define KEEP_EDITING	-2
#define	SCR_WIDTH	80

struct textline *firstline = NULL;
struct textline *lastline = NULL;
struct textline *currline = NULL;
struct textline *top_of_win = NULL;

extern int local_article;

int currpnt, currln, totaln;
int curr_window_line;
int redraw_everything;
int insert_character;
int my_ansimode;
int edit_margin;
int in_mail;

char *my_edit_mode[2] =
{"���N", "���J"};

char save_title[STRLEN];


void
indigestion(i)
{
  fprintf(stderr, "�Y������ %d\n", i);
}


struct textline *
back_line(pos, num)
  struct textline *pos;
{
  while (num-- > 0)
    if (pos && pos->prev)
    {
      pos = pos->prev;
      currln--;
    }
  return pos;
}


struct textline *
forward_line(pos, num)
  struct textline *pos;
{
  while (num-- > 0)
    if (pos && pos->next)
    {
      pos = pos->next;
      currln++;
    }
  return pos;
}


int
getlineno()
{
  int cnt = 0;
  struct textline *p = currline;

  while (p && (p != top_of_win))
  {
    cnt++;
    p = p->prev;
  }
  return cnt;
}


char *
killsp(s)
  char *s;
{
  while (*s == ' ')
    s++;
  return s;
}


struct textline *
alloc_line()
{
  extern void *malloc();
  register struct textline *p;

  p = (struct textline *) malloc(sizeof(*p));
  if (p == NULL)
  {
    indigestion(13);
    abort_bbs();
  }
  memset(p, 0, sizeof(struct textline));
  return p;
}


/*
 * Appends p after line in list.  keeps up with last line as well.
 */

void
append(p, line)
  register struct textline *p, *line;
{
  p->next = line->next;
  if (line->next)
    line->next->prev = p;
  else
    lastline = p;
  line->next = p;
  p->prev = line;
}


/*
 * delete_line deletes 'line' from the list and maintains the lastline, and
 * firstline pointers.
 */

void
delete_line(line)
  register struct textline *line;
{
  if (!line->next && !line->prev)
  {
    line->data[0] = line->len = 0;
    return;
  }
  if (line->next)
    line->next->prev = line->prev;
  else
    lastline = line->prev;
  if (line->prev)
    line->prev->next = line->next;
  else
    firstline = line->next;
  free(line);
  totaln--;
}


/*
 * split splits 'line' right before the character pos
 */

void
split(line, pos)
  register struct textline *line;
  register int pos;
{
  if (pos <= line->len)
  {
    register struct textline *p = alloc_line();
    totaln++;

    p->len = line->len - pos;
    line->len = pos;
    strcpy(p->data, (line->data + pos));
    *(line->data + pos) = '\0';
    append(p, line);
    if (line == currline && pos <= currpnt)
    {
      currline = p;
      currpnt -= pos;
      curr_window_line++;
      currln++;
    }
    redraw_everything = YEA;
  }
}


/* 1) lines were joined and one was deleted */
/* 2) lines could not be joined */
/* 3) next line is empty */
/* returns false if: */
/* 1) Some of the joined line wrapped */

int
join(line)
  register struct textline *line;
{
  register int ovfl;

  if (!line->next)
    return YEA;
  if (*killsp(line->next->data) == '\0')
    return YEA;
  ovfl = line->len + line->next->len - WRAPMARGIN;
  if (ovfl < 0)
  {
    strcat(line->data, line->next->data);
    line->len += line->next->len;
    delete_line(line->next);
    return YEA;
  }
  else
  {
    register char *s;
    register struct textline *p = line->next;

    s = p->data + p->len - ovfl - 1;
    while (s != p->data && *s == ' ')
      s--;
    while (s != p->data && *s != ' ')
      s--;
    if (s == p->data)
      return YEA;
    split(p, (s - p->data) + 1);
    if (line->len + p->len >= WRAPMARGIN)
    {
      indigestion(0);
      return YEA;
    }
    join(line);
    p = line->next;
    if (p->len >= 1 && p->len + 1 < WRAPMARGIN)
    {
      if (p->data[p->len - 1] != ' ')
      {
	strcat(p->data, " ");
	p->len++;
      }
    }
    return NA;
  }
}


void
insert_char(ch)
  register int ch;
{
  register int i;
  register char *s;
  register struct textline *p = currline;
  int wordwrap = YEA;

  if (currpnt > p->len)
  {
    indigestion(1);
    return;
  }
  if (currpnt < p->len && !insert_character)
  {
    p->data[currpnt++] = ch;
  }
  else
  {
    for (i = p->len; i >= currpnt; i--)
      p->data[i + 1] = p->data[i];
    p->data[currpnt++] = ch;
    p->len++;
  }
  if (p->len < WRAPMARGIN)
    return;
  s = p->data + (p->len - 1);
  while (s != p->data && *s == ' ')
    s--;
  while (s != p->data && *s != ' ')
    s--;
  if (s == p->data)
  {
    wordwrap = NA;
    s = p->data + (p->len - 2);
  }
  split(p, (s - p->data) + 1);
  p = p->next;
  if (wordwrap && p->len >= 1)
  {
    i = p->len;
    if (p->data[i - 1] != ' ')
    {
      p->data[i] = ' ';
      p->data[i + 1] = '\0';
      p->len++;
    }
  }
  while (!join(p))
  {
    p = p->next;
    if (p == NULL)
    {
      indigestion(2);
      break;
    }
  }
}


void
delete_char()
{
  if (currline->len)
  {
    register int i;

    if (currpnt >= currline->len)
    {
      indigestion(1);
      return;
    }
    for (i = currpnt; i != currline->len; i++)
      currline->data[i] = currline->data[i + 1];
    currline->len--;
  }
}


void
read_file(filename)
  char *filename;
{
  FILE *fp;
  int ch;

  currpnt = totaln = 0;
  if (currline == NULL)
    currline = firstline = lastline = alloc_line();

  if ((fp = fopen(filename, "r+")) == NULL)
  {
    if (fp = fopen(filename, "w+"))
    {
      close(fp);
      return;
    }
    indigestion(4);
    abort_bbs();
  }
  while ((ch = getc(fp)) != EOF)

#ifdef BIT8
    if (isprint2(ch) || ch == '')
#else
    if (isprint(ch))
#endif

    {
      insert_char(ch);
    }
    else if (ch == '\t')
    {
      do
      {
	insert_char(' ');
      }
      while (currpnt & 0x7);
    }
    else if (ch == '\n')
      split(currline, currpnt);
  fclose(fp);
}


#ifndef VEDITOR
void
write_header(fp)
  FILE *fp;
{
  time_t now;

  now = time(0);

  if (in_mail)
  {
    fprintf(fp, "From:      %s (%s)\n", cuser.userid,

#if defined(REALINFO) && defined(MAIL_REALNAMES)
      cuser.realname);
#else
      cuser.username);
#endif
  }

  else
  {
    fprintf(fp, "Posted By: %s (%s) on board '%s'\n", cuser.userid,

#if defined(REALINFO) && defined(POSTS_REALNAMES)
      cuser.realname
#else
      cuser.username
#endif

      ,currboard);
  }
  save_title[STRLEN - 10] = '\0';
  fprintf(fp, "Title:     %s\n", save_title);
  fprintf(fp, "Date:      %s\n", ctime(&now));
}


void
addsignature(fp)
  FILE *fp;
{
  FILE *sigfile;
  int i, j;
  char inbuf[WRAPMARGIN + 1];
  char fname[STRLEN];

  static char msg[] = "�п��ñ�W�� (1/2/3, 0=���[)[0]: ";
  char ch;

  clear();
  j = showsignature(fname);

  msg[29] = ch = '0' | (cuser.uflag & SIG_FLAG);
  getdata(0, 0, msg, inbuf, 4, DOECHO);

  if (ch != inbuf[0] && inbuf[0] >= '0' && inbuf[0] <= '3')
  {
    ch = inbuf[0];
    cuser.uflag = (cuser.uflag & ~SIG_FLAG) | (ch & SIG_FLAG);
  }

#ifdef	HAVE_ORIGIN
  fprintf(fp, "\n--\n�� Origin: %s\n", fromhost);
#endif

  if (ch == '0')
    return;
  fname[j] = ch;
  if (sigfile = fopen(fname, "r"))
  {
    fprintf(fp, "\n--\n");
    for (i = 0; i < MAXSIGLINES; i++)
    {
      if (fgets(inbuf, sizeof(inbuf), sigfile))
	fputs(inbuf, fp);
      else
	break;
    }
    fclose(sigfile);
  }
}
#endif


int
write_file(filename, saveheader)
  char *filename;
  int saveheader;
{
  FILE *fp;
  struct textline *p = firstline;
  struct textline *v;
  char abort[4];
  int aborted = 0;
  int ch;

  clear();

#ifndef VEDITOR
  {
    char *p_buf;

    if (uinfo.mode == SMAIL)
      p_buf = "(S)�x�s (A)��� (T)���ܼ��D (E)�ק� (R/W)Ū�g�Ȧs��? [S]: ";
    else if (local_article == 1)
      p_buf = "(L)�����H�� (S)�x�s (A)��� (T)���ܼ��D (E)�ק� (R/W)Ū�g�Ȧs��? [L]: ";
    else
      p_buf = "(S)�x�s (L)�����H�� (A)��� (T)���ܼ��D (E)�ק� (R/W)Ū�g�Ȧs��? [S]: ";
    getdata(0, 0, p_buf, abort, 3, DOECHO);
  }
#else
  abort[0] = 's';
#endif

  abort[0] |= 32;

  if (abort[0] == 'a')
  {
    struct stat stbuf;
    outs("�峹[1m �S�� [0m�s�J");
    sleep(1);
    if (stat(filename, &stbuf) || stbuf.st_size == 0)
      unlink(filename);
    aborted = -1;
  }
  else if (abort[0] == 'e')
    return KEEP_EDITING;
  else if (abort[0] == 'r')
  {
    char fn_editbuf[48];
    setuserfile(fn_editbuf, "editbuf");

    if (fp = fopen(fn_editbuf, "r"))
    {
      while ((ch = getc(fp)) != EOF)
      {

#ifdef BIT8
	if (isprint2(ch) || ch == '')
#else
	if (isprint(ch))
#endif

	{
	  insert_char(ch);
	}
	else if (ch == '\t')
	{
	  do
	  {
	    insert_char(' ');
	  }
	  while (currpnt & 0x7);
	}
	else if (ch == '\n')
	{
	  split(currline, currpnt);
	}
      }
      while (curr_window_line >= b_lines)
      {
	curr_window_line--;
	top_of_win = top_of_win->next;
      }
      fclose(fp);
    }
    return KEEP_EDITING;
  }
  else if (abort[0] == 'w')
  {
    FILE *fp;
    char fn_editbuf[48];
    setuserfile(fn_editbuf, "editbuf");

    if (fp = fopen(fn_editbuf, "r"))
    {
      getdata(2, 0, "�w�g���Ȧs�� (A)���[ (W)�мg (Q)���� [A]: ", abort, 2, DOECHO);
      fclose(fp);

      abort[0] |= 32;
      if (abort[0] == 'q')
	return KEEP_EDITING;
    }

    fp = fopen(fn_editbuf, (abort[0] == 'w' ? "w" : "a+"));
    while (p)
    {
      if (p->next || p->data[0] != '\0')
	fprintf(fp, "%s\n", p->data);
      v = p->next;
      p = v;
    }
    fclose(fp);
    return KEEP_EDITING;
  }
  else if (abort[0] == 't')
  {
    char buf[STRLEN];

    move(1, 0);
    prints("�¼��D: %s", save_title);
    getdata(2, 0, "�s���D: ", buf, TTLEN, DOECHO);
    if (buf[0])
      strcpy(save_title, buf);
    return KEEP_EDITING;
  }
  else if (abort[0] == 's')
    local_article = 0;

  if (!aborted && check_included())
    return KEEP_EDITING;

  if (!aborted)
  {
    if ((fp = fopen(filename, "w")) == NULL)
    {
      indigestion(5);
      abort_bbs();
    }

#ifndef VEDITOR
    if (saveheader)
      write_header(fp);
#endif
  }

  while (p)
  {
    v = p->next;
    if (!aborted)
      if (p->next || p->data[0])
	fprintf(fp, "%s\n", p->data);
    free(p);
    p = v;
  }

  if (!aborted)
  {

#ifndef	VEDITOR
    if (uinfo.mode == POSTING || uinfo.mode == SMAIL)
    {
      addsignature(fp);
    }
#endif

    fclose(fp);
  }

  currline = NULL;

#ifndef VEDITOR
  if ((abort[0] == 'l' || local_article == 1) && (uinfo.mode == POSTING))
  {
    return 1;
  }
#endif

  return aborted;
}


void
edit_msg(void)
{
  move(b_lines, 0);
  clrtoeol();
  prints("[1;46m  �s��峹  [45m  (Ctrl-Z) �u�W���U����   (^W,^X) �ɮ׳B�z     �� %s �� %3d:%3d  [40;0m",
    my_edit_mode[insert_character], currln + 1, currpnt + 1);
}


void
edit_outs(text)
  char *text;
{
  register int column = 0;
  register char ch;

  while ((ch = *text++) && (++column < SCR_WIDTH))
  {
    outch(ch == 27 ? '*' : ch);
  }
}


void
display_buffer()
{
  register struct textline *p;
  register int i;

  for (p = top_of_win, i = 0; i < b_lines; i++)
  {
    move(i, 0);
    clrtoeol();
    if (p)
    {
      if (my_ansimode)
	edit_outs(&p->data[edit_margin]);
      else
	outs(p->data);
      p = p->next;
    }
    else
      outch('~');
  }
  edit_msg();
}


static char *vedithelp[] =
{
  "\0�s�边���U�e��",
  "\01�@����O",
  "^w,^x    �ɮ׳B�z               ^G,^L    ���s��ܵe��",
  "^V       ���� ANSI �w���Ҧ�     ^Z       ��ܥ��D�U�e��",
  "\01��в��ʫ��O",
  "��,^R    ���Ჾ�ʤ@��           ^A,Home  ���즹��}�Y",
  "��       ���e���ʤ@��           ^E,End   ���즹�浲��",
  "��,^P    ���W���ʤ@��           ^S,^]    �����ɮ׶}�Y",
  "��,^N    ���U���ʤ@��           ^T       �����ɮ׵���",
  "^B,PgUp  ���W���ʤ@��           ^F,PgDn  ���U���ʤ@��",
  "\01�R�����J���O",
  "^O,Ins   ���ܼҦ��� insert/overwrite",
  "^H,BS    �R���e�@�Ӧr��",
  "^D,DEL   �R���ثe���r��         ANSI�x�¬�����ŵ��Q��",
  "^K       �R����Ф���ܦ��     �e���x[47;30;1m30[31m31[32m32[33m33[34m34[35m35[36m36[37m37[40;0m",
  "^Y       �R���ثe�o��           �I���x[40;33;1m40[41m41[42m42[43m43[44m44[45m45[46m46[47m47[40;37;0m\n",
  "\01�S�����O",
  "^U       ��J ESC �X(�H * ����)    ^C    �٭� ANSI ��m",
NULL};


void
show_help(helptext)
  char *helptext[];
{
  char *str;
  int i;

  clear();
  for (i = 0; (str = helptext[i]); i++)
  {
    if (*str == '\0')
      prints("[1m�i %s �j[m\n", str + 1);
    else if (*str == '\01')
      prints("\n[36m�i %s �j[m\n", str + 1);
    else
      prints("        %s\n", str);
  }
  pressanykey();
  clear();
}


int
vedit(filename, saveheader)
  char *filename;
  int saveheader;
{
  int ch, foo;
  int lastindent = -1;
  int last_margin;

  insert_character = my_ansimode = redraw_everything = 1;

  read_file(filename);
  currline = top_of_win = firstline;
  currpnt = currln = curr_window_line = edit_margin = last_margin = 0;

  while (1)
  {
    if (redraw_everything)
    {
      display_buffer();
      redraw_everything = NA;
    }
    move(curr_window_line, currpnt - edit_margin);
    ch = igetkey();

#ifdef BIT8
    if (ch < 0x100 && isprint2(ch))
#else
    if (ch < 0x100 && isprint(ch))
#endif

    {
      insert_char(ch);
      lastindent = -1;
    }
    else
    {
      if (ch == Ctrl('P') || ch == KEY_UP ||
	ch == Ctrl('N') || ch == KEY_DOWN)
      {
	if (lastindent == -1)
	  lastindent = currpnt;
      }
      else
	lastindent = -1;

      switch (ch)
      {
      case Ctrl('X'):		/* Save and exit */
      case Ctrl('W'):
	foo = write_file(filename, saveheader);
	if (foo != KEEP_EDITING)
	  return foo;
	redraw_everything = YEA;
	break;

#ifdef VEDITOR
      case Ctrl('C'):
      case Ctrl('Q'):		/* Quit without saving */
	ch = ask("���������x�s (Y/N)? [N]: ");
	if (ch == 'y' || ch == 'Y')
	{
	  ch = ask("�~��s��� (Y/N)? [Y]: ");
	  if (ch == 'n' || ch == 'N')
	  {
	    clear();
	    return 0;
	  }
	}
	redraw_everything = YEA;
	break;
#endif

      case Ctrl('C'):
	ch = insert_character;
	insert_character = 1;
#define	ptr redraw_everything
	for (ptr = 0; ptr < 10; ptr++)
	  insert_char(reset_color[ptr]);
#undef	ptr
	insert_character = ch;
	break;

      case Ctrl('U'):
	insert_char('');
	break;

      case Ctrl('I'):
	do
	{
	  insert_char(' ');
	}
	while (currpnt & 0x7);
	break;

      case '\r':
      case '\n':
	split(currline, currpnt);
	break;

      case Ctrl('Z'):
	show_help(vedithelp);
	redraw_everything = YEA;
	break;

      case Ctrl('V'):		/* Toggle ANSI color */
	my_ansimode ^= 1;

      case Ctrl('G'):
	clear();
	redraw_everything = YEA;
	break;

      case KEY_LEFT:
      case Ctrl('R'):
	if (currpnt)
	  currpnt--;
	else if (currline->prev)
	{
	  curr_window_line--;
	  currln--;
	  currline = currline->prev;
	  currpnt = currline->len;
	}
	break;

      case KEY_RIGHT:
	if (currline->len != currpnt)
	  currpnt++;
	else if (currline->next)
	{
	  currpnt = 0;
	  curr_window_line++;
	  currln++;
	  currline = currline->next;
	}
	break;

      case Ctrl('P'):
      case KEY_UP:
	if (currline->prev)
	{
	  curr_window_line--;
	  currln--;
	  currline = currline->prev;
	  currpnt = (currline->len > lastindent) ? lastindent : currline->len;
	}
	break;

      case Ctrl('N'):
      case KEY_DOWN:
	if (currline->next)
	{
	  currline = currline->next;
	  curr_window_line++;
	  currln++;
	  currpnt = (currline->len > lastindent) ? lastindent : currline->len;
	}
	break;

      case KEY_PGUP:
      case Ctrl('B'):
	redraw_everything = currln;
	top_of_win = back_line(top_of_win, 22);
	currln = redraw_everything;
	currline = back_line(currline, 22);
	curr_window_line = getlineno();
	if (currpnt > currline->len)
	  currpnt = currline->len;
	redraw_everything = YEA;
	break;

      case KEY_PGDN:
      case Ctrl('F'):
	redraw_everything = currln;
	top_of_win = forward_line(top_of_win, 22);
	currln = redraw_everything;
	currline = forward_line(currline, 22);
	curr_window_line = getlineno();
	if (currpnt > currline->len)
	  currpnt = currline->len;
	redraw_everything = YEA;
	break;

      case KEY_HOME:
      case Ctrl('A'):
	currpnt = 0;
	break;

      case KEY_END:
      case Ctrl('E'):
	currpnt = currline->len;
	break;

      case Ctrl('S'):		/* start of file */
      case Ctrl(']'):
	currline = top_of_win = firstline;
	currpnt = currln = curr_window_line = 0;
	redraw_everything = YEA;
	break;

      case Ctrl('T'):		/* tail of file */
	top_of_win = back_line(lastline, 23);
	currline = lastline;
	curr_window_line = getlineno();
	currpnt = 0;
	currln = totaln;
	redraw_everything = YEA;
	break;

      case KEY_INS:		/* Toggle insert/overwrite */
      case Ctrl('O'):
	insert_character ^= 1;
	/* edit_msg(); */
	break;

      case Ctrl('H'):
      case '\177':		/* backspace */
	if (currpnt == 0)
	{
	  struct textline *p;

	  if (!currline->prev)
	  {
	    break;
	  }
	  curr_window_line--;
	  currln--;
	  currline = currline->prev;
	  currpnt = currline->len;
	  redraw_everything = YEA;
	  if (*killsp(currline->next->data) == '\0')
	  {
	    delete_line(currline->next);
	    break;
	  }
	  p = currline;
	  while (!join(p))
	  {
	    p = p->next;
	    if (p == NULL)
	    {
	      indigestion(2);
	      abort_bbs();
	    }
	  }
	  break;
	}
	currpnt--;
	delete_char();
	break;

      case Ctrl('D'):
      case KEY_DEL:		/* delete current character */
	if (currline->len == currpnt)
	{
	  struct textline *p = currline;

	  while (!join(p))
	  {
	    p = p->next;
	    if (p == NULL)
	    {
	      indigestion(2);
	      abort_bbs();
	    }
	  }
	  redraw_everything = YEA;
	  break;
	}
	delete_char();
	break;

      case Ctrl('Y'):		/* delete current line */
	currpnt = 0;
	currline->len = 0;

      case Ctrl('K'):		/* delete to end of line */
	if (currline->len == 0)
	{
	  struct textline *p = currline->next;

	  if (!p)
	  {
	    p = currline->prev;
	    if (!p)
	    {
	      break;
	    }
	    if (curr_window_line > 0)
	    {
	      curr_window_line--;
	      currln--;
	    }
	  }
	  if (currline == top_of_win)
	    top_of_win = p;
	  delete_line(currline);
	  currline = p;
	  redraw_everything = YEA;
	  break;
	}

	if (currline->len == currpnt)
	{
	  struct textline *p = currline;

	  while (!join(p))
	  {
	    p = p->next;
	    if (p == NULL)
	    {
	      indigestion(2);
	      abort_bbs();
	    }
	  }
	  redraw_everything = YEA;
	  break;
	}
	currline->len = currpnt;
	currline->data[currpnt] = '\0';
      }

      if (currln < 0)
	currln = 0;
      if (curr_window_line < 0)
      {
	curr_window_line = 0;
	if (!top_of_win->prev)
	{
	  indigestion(6);
	}
	else
	{
	  top_of_win = top_of_win->prev;
	  rscroll();
	}
      }
      if (curr_window_line == b_lines)
      {
	curr_window_line = t_lines - 2;
	if (!top_of_win->next)
	{
	  indigestion(7);
	}
	else
	{
	  top_of_win = top_of_win->next;
	  move(b_lines, 0);
	  clrtoeol();
	  scroll();
	}
      }
    }
    edit_margin = currpnt < SCR_WIDTH - 1 ? 0 : currpnt / 72 * 72;

    if (!redraw_everything)
    {
      if (edit_margin != last_margin)
      {
	last_margin = edit_margin;
	redraw_everything = YEA;
      }
      else
      {
	move(curr_window_line, 0);
	clrtoeol();
	edit_outs(&currline->data[edit_margin]);
	edit_msg();
      }
    }
  }
}


/* -------------------- */
/* ���� user �ި����ϥ� */
/* -------------------- */

int
check_included()
{
  int post_line = 0;
  int included_line = 0;
  struct textline *p = firstline;
  char abort[4];

  while (p)
  {
    if (!strcmp(p->data, "--"))
      break;
    if ((p->data[0] == ':') || (p->data[0] == '>'))
    {
      included_line++;
    }
    else
    {
      int i = 0;
      while (p->data[i] == ' ' || p->data[i] == '\t')
	i++;
      if (p->data[i])
	post_line++;
    }
    p = p->next;
  }

  if (included_line > (post_line << 2))
  {
    move(4, 0);

    outs("\
        ���g�峹���ި���ҶW�L 80%�A�бz���ǷL���ץ��G\n\n\
         [1;33m1) �W�[�@�Ǥ峹 ��  2) �R�������n���ި�[0m");

    /* if (HAS_PERM(PERM_SYSOP)) */
    {
      getdata(12, 12, "(w)�j��g�J (E)�~��s�� ? [E]: ", abort, 4, DOECHO);
      if (abort[0] == 'w' || abort[0] == 'W')
	return 0;
    }
    return 1;
  }
  return 0;
}
