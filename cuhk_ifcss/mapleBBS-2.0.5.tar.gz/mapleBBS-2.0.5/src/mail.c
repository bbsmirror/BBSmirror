/* mail.c */

#include "bbs.h"

#ifdef HAVE_NAMEFILE
char *get_bbs_mail_domain();
char *get_bbs_english_name();
#endif				/* HAVE_NAMEFILE */

extern int del_range();
#define	mail_del_range	del_range

char currmaildir[32];
char *msg_cc = "[32m[���H�H][m\n";


#ifdef INTERNET_PRIVATE_EMAIL
int
m_internet()
{
  char receiver[60], title[TTLEN];

  modify_user_mode(SMAIL);
  getdata(20, 0, "���H�H: ", receiver, 60, DOECHO);
  getdata(21, 0, "�D  �D: ", title, TTLEN, DOECHO);
  if (strchr(receiver, '@') && *title)
  {
    *quote_file = '\0';
    do_send(receiver, title);
  }
  else
  {
    move(22, 0);
    outs("���H�H�ΥD�D�����T, �Э��s������O");
    pressanykey();
  }
  return 0;
}
#endif


void
m_init()
{
  sethomedir(currmaildir, cuser.userid);
}


int
chkmailbox(void)
{

  if (!HAVE_PERM(PERM_SYSOP))
  {
    int keep;

    m_init();
    if (keep = get_num_records(currmaildir, sizeof(fileheader)) > MAXKEEPMAIL)
    {
      move(b_lines, 0);
      clrtoeol();
      bell();
      prints("�z�O�s�H��ƥ� %d �W�X�W�� %d, �о�z�H��", keep, MAXKEEPMAIL);
      bell();
      refresh();
      igetch();
      return keep;
    }
  }
  return 0;
}


int
do_send(userid, title)
  char *userid, *title;
{
  struct fileheader newmessage;
  struct stat st;
  char filepath[STRLEN], *ip;
  int fp;

#ifdef INTERNET_PRIVATE_EMAIL
  int internet_mail = 0;
  char tmp_fname[40];

  if (strchr(userid, '@'))
  {
    internet_mail = 1;
    sprintf(tmp_fname, "/tmp/bbs-gw-%05d", getpid());
    strcpy(filepath, tmp_fname);
    goto edit_mail_file;
  }
#endif

  if (!getuser(userid))
    return -1;
  if (!(xuser.userlevel & PERM_READMAIL))
    return -3;

  sethomepath(newmessage.filename, userid);
  stampfile(filepath, &newmessage);

  if (title)
    strncpy(save_title, title, TTLEN);
  else
    getdata(2, 0, "�D�D�G", save_title, TTLEN, DOECHO);
  in_mail = YEA;

#if 0

#if defined(REALINFO) && defined(MAIL_REALNAMES)
  sprintf(genbuf, "%s (%s)", cuser.userid, cuser.realname);
#else
  sprintf(genbuf, "%s (%s)", cuser.userid, cuser.username);
#endif

#endif

  strcpy(newmessage.owner, cuser.userid);

#ifdef INTERNET_PRIVATE_EMAIL
edit_mail_file:
#endif

  if (*quote_file)
    do_quote(filepath);

#ifdef INTERNET_PRIVATE_EMAIL
  if (internet_mail)
  {
    int res, ch;
    if (vedit(filepath, NA) == -1)
    {
      unlink(filepath);
      clear();
      return -2;
    }
    clear();
    prints("�H��Y�N�H�� %s\n���D���G%s\n�T�w�n�H�X��? (Y/N) [Y]",
      userid, title);
    refresh();
    ch = igetch();
    switch (ch)
    {
    case 'N':
    case 'n':
      outs("N\n�H��w����");
      res = -2;
    default:
      outs("Y\n�еy��, �H��ǻ���...\n");
      res = bbs_sendmail(tmp_fname, title, userid);
      outs("�H��w�H�X");
      break;
    }
    unlink(tmp_fname);
    return res;
  }
  else
  {
#endif

    if (vedit(filepath, YEA) == -1)
    {
      unlink(filepath);
      clear();
      return -2;
    }
    clear();
    strncpy(newmessage.title, save_title, TTLEN);
    newmessage.savemode = '\0';
    sethomedir(genbuf, userid);
    if (append_record(genbuf, &newmessage, sizeof(newmessage)) == -1)
      return -1;

#ifdef	HAVE_REPORT
    sprintf(genbuf, "mailed %s", userid);
    report(genbuf);
#endif

    return 0;

#ifdef INTERNET_PRIVATE_EMAIL
  }
#endif
}


int
m_send()
{
  char uident[STRLEN];

  modify_user_mode(SMAIL);
  stand_title("�g�@�ʫH");
  usercomplete(msg_uid, uident);
  if (uident[0] == '\0')
  {
    return 0;
  }
  quote_file[0] = '\0';
  switch (do_send(uident, NULL))
  {
  case -1:
    outs(err_uid);
    break;
  case -2:
    outs(msg_cancel);
    break;
  case -3:
    prints("�ϥΪ� [%s] �L�k���H", uident);
    break;
  default:
    outs("���Q�H�X");
  }
  pressanykey();
  return 0;
}


/* ------------------------------------------------------------ */
/* �s�ձH�H�B�^�H : multi_send, multi_reply			 */
/* ------------------------------------------------------------ */

extern struct word *toplev;
extern char replytitle[];


void
multi_list(reciper)
  int *reciper;
{
  char uid[16];
  FILE *fp;
  int listing = 1;

  while (listing)
  {
    getdata(1, 0, "���H�H (A)�W�[ (D)�R�� (I)�ޤJ�n�ͦW�� (M)�g�H (Q)���? [M]: ",
      genbuf, 4, DOECHO);
    switch (genbuf[0])
    {
    case 'a':
    case 'A':
      while (1)
      {
	move(1, 0);
	usercomplete("�п�J�n�W�[���N��(�u�� ENTER �����s�W): ", uid);
	if (uid[0] == '\0')
	  break;

	move(2, 0);
	clrtoeol();
	if (!getuser(uid))
	{
	  outs(err_uid);
	}
	else if (!(xuser.userlevel & PERM_READMAIL))
	{
	  outs("���L�k���H");
	}
	else if (!InNameList(uid))
	{
	  AddNameList(uid);
	  (*reciper)++;
	}
	ShowNameList(3, 0, msg_cc);
      }
      break;

    case 'd':
    case 'D':
      while (*reciper)
      {
	move(1, 0);
	namecomplete("�п�J�n�R�����N��(�u�� ENTER �����R��): ", uid);
	if (uid[0] == '\0')
	  break;
	if (RemoveNameList(uid))
	{
	  (*reciper)--;
	}
	ShowNameList(3, 0, msg_cc);
      }
      break;

    case 'i':
    case 'I':
      setuserfile(genbuf, str_overrides);
      if ((fp = fopen(genbuf, "r")) == NULL)
      {
	outs(msg_no_override);
      }
      else
      {
	while (fgets(genbuf, STRLEN, fp))
	{
	  strtok(genbuf, " \n\r\t");
	  if (!InNameList(genbuf))
	  {
	    AddNameList(genbuf);
	    (*reciper)++;
	  }
	}
	fclose(fp);
	ShowNameList(3, 0, msg_cc);
      }
      break;

    case 'q':
    case 'Q':
      *reciper = 0;
      return;

    default:
      listing = 0;
    }
  }
}


int
multi_send()
{
  FILE *fp;
  struct word *p;
  struct fileheader newmessage;
  char filepath[TTLEN], *ptr;
  int reciper, listing;

  CreateNameList();

  listing = reciper = 0;

  if (*quote_file)
  {
    AddNameList(quote_user);
    reciper = 1;
    fp = fopen(quote_file, "r");
    while (fgets(genbuf, 256, fp))
    {
      if (strncmp(genbuf, "�� ", 3))
      {
	if (listing)
	  break;
      }
      else
      {
	if (listing)
	{
	  strtok(ptr = genbuf + 3, " \n\r");
	  do
	  {
	    if (!InNameList(ptr) && strcmp(cuser.userid, ptr))
	    {
	      AddNameList(ptr);
	      reciper++;
	    }
	  } while (ptr = (char *) strtok(NULL, " \n\r"));
	}
	else if (!strncmp(genbuf + 3, "[�q�i]", 6))
	  listing = 1;
      }
    }
    ShowNameList(3, 0, msg_cc);
  }

  multi_list(&reciper);
  move(1, 0);
  clrtobot();

  if (reciper)
  {
    modify_user_mode(SMAIL);

    if (*quote_file)
    {
      do_reply_title(2, save_title, replytitle);
    }
    else
    {
      getdata(2, 0, "�D�D�G", filepath, 64, DOECHO);
      sprintf(save_title, "[�q�i] %s", filepath);
    }

    setuserfile(filepath, "mux");
    if (fp = fopen(filepath, "w"))
    {
      fprintf(fp, "�� [�q�i] �@ %d �H����", reciper);
      listing = 80;

      for (p = toplev; p; p = p->next)
      {
	reciper = strlen(p->word) + 1;
	if (listing + reciper > 75)
	{
	  listing = reciper;
	  fprintf(fp, "\n��");
	}
	else
	  listing += reciper;

	fprintf(fp, " %s", p->word);
      }
      memset(genbuf, '-', 75);
      genbuf[75] = '\0';
      fprintf(fp, "\n%s\n\n", genbuf);
      fclose(fp);
    }

    in_mail = MAIL_LIST;
    if (*quote_file)
    {
      do_quote(filepath);
    }

    if (vedit(filepath, YEA) == -1)
    {
      unlink(filepath);
      in_mail = NA;
      outs(msg_cancel);
      pressanykey();
      return;
    }

    stand_title("�H�H��...");

    listing = 80;

    for (p = toplev; p; p = p->next)
    {
      reciper = strlen(p->word) + 1;
      if (listing + reciper > 75)
      {
	listing = reciper;
	outc('\n');
      }
      else
      {
	listing += reciper;
	outc(' ');
      }
      outs(p->word);

      sethomepath(newmessage.filename, p->word);
      stampfile(genbuf, &newmessage);
      if (fp = fopen(genbuf, "w"))
      {
	b_suckinfile(fp, filepath);
	fclose(fp);

	strcpy(newmessage.owner, cuser.userid);
	strcpy(newmessage.title, save_title);
	newmessage.savemode = 'M';	/* multi-send flag */
	sethomedir(genbuf, p->word);
	if (append_record(genbuf, &newmessage, sizeof(newmessage)) == -1)
	  outs(err_uid);
      }
    }
    unlink(filepath);
    in_mail = NA;
  }
  else
  {
    outs(msg_cancel);
  }
  pressanykey();
}


int
multi_reply(ent, fileinfo, direct)
  int ent;
  fileheader *fileinfo;
  char *direct;
{
  if (fileinfo->savemode != 'M')
    return mail_reply(ent, fileinfo, direct);
  strcpy(replytitle, fileinfo->title);
  strcpy(quote_user, fileinfo->owner);
  setuserfile(quote_file, fileinfo->filename);
  stand_title("�s�զ^�H");
  multi_send();
  return 0;
}


int
mail_list()
{
  stand_title("�s�ձH�H");
  quote_file[0] = '\0';
  multi_send();
  return 0;
}


int
m_forward(ent, fileinfo, direct)
  int ent;
  fileheader *fileinfo;
  char *direct;
{
  char uid[STRLEN];
  char title[STRLEN];
  char *t;
  FILE *fp;

  modify_user_mode(SMAIL);
  stand_title("��F�H��");
  usercomplete(msg_uid, uid);
  if (uid[0] == '\0')
  {
    return 0;
  }

  strcpy(quote_user, fileinfo->owner);
  setuserfile(quote_file, fileinfo->filename);
  sprintf(title, "%.64s (fwd)", fileinfo->title);
  move(1, 0);
  clrtobot();
  prints("��H��: %s\n���D  : %s\n", uid, title);

  switch (do_send(uid, title))
  {
  case -1:
    outs(err_uid);
    break;
  case -2:
    outs(msg_cancel);
    break;
  case -3:
    prints("�ϥΪ� [%s] �L�k���H", uid);
    break;
  default:
    outs("���Q�H�X");
  }
  pressanykey();
  return 0;
}


/* JhLin: At most 128 mail */

int delmsgs[128];
int delcnt;
int mrd;


int
read_new_mail(fptr)
  struct fileheader *fptr;
{
  static int idc;
  char done = NA, delete_it;
  char fname[256];

  if (fptr == NULL)
  {
    delcnt = 0;
    idc = 0;
    return 0;
  }
  idc++;
  if (fptr->filemode)
    return 0;
  prints("�z�nŪ�Ӧ�[%s]���T��(%s)�ܡH", fptr->owner, fptr->title);
  getdata(1, 0, msg_sure_yn, genbuf, 2, DOECHO);
  if (genbuf[0] == 'n' || genbuf[0] == 'N')
  {
    return 0;
  }

  setuserfile(fname, fptr->filename);
  fptr->filemode |= FILE_READ;
  if (substitute_record(currmaildir, fptr, sizeof(*fptr), idc))
    return -1;

  mrd = 1;
  delete_it = NA;
  while (!done)
  {
    more(fname, NA);
    move(b_lines, 0);
    outs(msg_mailer);
    clrtoeol();
    refresh();

    switch (egetch())
    {
    case 'r':
    case 'R':
      mail_reply(idc, fptr, currmaildir);
      break;
    case 'x':
      m_forward(idc, fptr, currmaildir);
      break;
    case 'y':
      multi_reply(idc, fptr, currmaildir);
      break;
    case 'd':
    case 'D':
      delete_it = YEA;
    default:
      done = YEA;
    }
  }
  if (delete_it)
  {
    clear();
    prints("�R���H��i %s �j", fptr->title);
    getdata(1, 0, msg_sure_ny, genbuf, 2, DOECHO);
    if (genbuf[0] == 'Y' || genbuf[0] == 'y')
    {
      unlink(fname);
      delmsgs[delcnt++] = idc;
    }
  }
  clear();
  return 0;
}


int
m_new()
{
  clear();
  mrd = 0;
  modify_user_mode(RMAIL);
  read_new_mail(NULL);
  clear();
  if (apply_record(currmaildir, read_new_mail, sizeof(struct fileheader)) == -1)
  {
    outs("�S���s�H��F");
    pressanykey();
    return -1;
  }
  if (delcnt)
  {
    while (delcnt--)
      delete_record(currmaildir, sizeof(struct fileheader), delmsgs[delcnt]);
  }
  outs(mrd ? "�H�w�\\��" : "�S���s�H��F");
  pressanykey();
  return -1;
}


void
mailtitle()
{
  showtitle("\0�l����", BoardName);
  outs("\
[��]���}  [��,��]���  [��,r]�\\Ū�H��  [R]�^�H   [x]��F  [y]�s�զ^�H  �D�U[h]\n[7m\
  �s��  ��诫�t      �� ��  �H �� �� �D                                      [m");
}


void
maildoent(num, ent)
  struct fileheader *ent;
{
  char b2[20];
  char *t;
  static char status[4] = "N Mm";

  strncpy(b2, ent->owner, 20);
  if (t = (char *) strchr(b2, ' '))
    *t = '\0';
  prints("  %3d %c %-14.14s%s  %.49s\n", num, status[ent->filemode],
    b2, ent->date, ent->title);
}


#ifdef POSTBUG
extern int bug_possible;
#endif


int
mail_read(ent, fileinfo, direct)
  int ent;
  struct fileheader *fileinfo;
  char *direct;
{
  char buf[64];
  char *t;
  char done, delete_it, replied;

  clear();
  setdirpath(buf, direct, fileinfo->filename);
  done = delete_it = replied = NA;
  while (!done)
  {
    more(buf, NA);
    move(b_lines, 0);
    clrtoeol();
    refresh();
    outs(msg_mailer);

    switch (egetch())
    {
    case 'r':
    case 'R':
      replied = YEA;
      mail_reply(ent, fileinfo, direct);
      break;
    case 'x':
      m_forward(ent, fileinfo, direct);
      break;
    case 'y':
      multi_reply(ent, fileinfo, direct);
      break;
    case 'd':
      delete_it = YEA;
    default:
      done = YEA;
    }
  }
  if (delete_it)
    mail_del(ent, fileinfo, direct);
  else
  {
    fileinfo->filemode |= FILE_READ;

#ifdef POSTBUG
    if (replied)
      bug_possible = YEA;
#endif

    substitute_record(currmaildir, fileinfo, sizeof(*fileinfo), ent);

#ifdef POSTBUG
    bug_possible = NA;
#endif
  }
  return FULLUPDATE;
}


/* ---------------------------------------------- */
/* JhLin: in boards/mail �^�H����@�̡A��H����i */
/* ---------------------------------------------- */

int
mail_reply(ent, fileinfo, direct)
  int ent;
  fileheader *fileinfo;
  char *direct;
{
  char uid[STRLEN];
  char title[STRLEN];
  char *t;
  FILE *fp;
  int orig_mode;

  /* indicate the quote file/user */

  strcpy(quote_user, fileinfo->owner);

  /* �P�_�O boards �� mail */

  if (orig_mode = in_mail)
    setuserfile(quote_file, fileinfo->filename);
  else
    setbfile(quote_file, currboard, fileinfo->filename);

  modify_user_mode(SMAIL);
  stand_title("�^  �H");

  /* find the author */

  if (strchr(quote_user, '.'))
  {
    genbuf[0] = '\0';
    if (fp = fopen(quote_file, "r"))
    {
      fgets(genbuf, 255, fp);
      fclose(fp);
    }

    t = strtok(genbuf, ":");
    if (strcmp(t, "�o�H�H") == 0 || strcmp(t, "Posted By") == 0)
    {
      strcpy(uid, strtok(NULL, " \r\t\n"));
    }
    else if (strcmp(t, "From") == 0)
    {
      strcpy(uid, strtok(genbuf + 11, " \r\t\n"));
    }
    else
    {
      outs("���~: �䤣��@�̡C");
      pressanykey();
    }
  }
  else
    strcpy(uid, quote_user);

  /* make the title */
  do_reply_title(3, title, fileinfo->title);
  prints("\n���H�H: %s\n���D  : %s\n", uid, title);

  /* edit, then send the mail */

  switch (do_send(uid, title))
  {
  case -1:
    outs(err_uid);
    break;
  case -2:
    outs(msg_cancel);
    break;
  case -3:
    prints("�ϥΪ� [%s] �L�k���H", uid);
    break;
  default:
    prints("�H��w���\\�a�H����@�� %s\n", uid);
  }
  in_mail = orig_mode;
  pressanykey();
  return FULLUPDATE;
}


int
mail_del(ent, fileinfo, direct)
  int ent;
  fileheader *fileinfo;
  char *direct;
{
  if (fileinfo->filemode & FILE_MARKED)
    return DONOTHING;

  getdata(b_lines, 0, msg_delete_ny, genbuf, 3, DOECHO);
  if (genbuf[0] == 'y' || genbuf[0] == 'Y')
  {
    char buf[STRLEN];
    char *t;
    extern int cmpfilename();

    strncpy(currfile, fileinfo->filename, FNLEN);
    if (!delete_file(direct, sizeof(*fileinfo), ent, cmpfilename))
    {
      setdirpath(genbuf, direct, fileinfo->filename);
      unlink(genbuf);
      return DIRCHANGED;
    }
  }
  return READ_REDRAW;
}


#ifdef INTERNET_EMAIL
int
mail_forward(ent, fileinfo, direct)
  int ent;
  struct fileheader *fileinfo;
  char *direct;
{
  char buf[STRLEN];
  char *p;
  if (!HAS_PERM(PERM_FORWARD))
  {
    return DONOTHING;
  }
  strncpy(buf, direct, sizeof(buf));
  if (p = strrchr(buf, '/'))
    *p = '\0';
  clear();
  switch (doforward(buf, fileinfo, 0))
  {
  case 0:
    outs(msg_fwd_ok);
    break;
  case -1:
    outs(msg_fwd_err1);
    break;
  case -2:
    outs(msg_fwd_err2);
  }
  pressanykey();
  clear();
  return FULLUPDATE;
}


int
mail_uforward(ent, fileinfo, direct)
  int ent;
  struct fileheader *fileinfo;
  char *direct;
{
  char buf[STRLEN];
  char *p;
  if (!HAS_PERM(PERM_FORWARD))
  {
    return DONOTHING;
  }
  strncpy(buf, direct, sizeof(buf));
  if (p = strrchr(buf, '/'))
    *p = '\0';
  clear();
  switch (doforward(buf, fileinfo, 1))
  {
  case 0:
    outs(msg_fwd_ok);
    break;
  case -1:
    outs(msg_fwd_err1);
    break;
  case -2:
    outs(msg_fwd_err2);
  }
  pressanykey();
  clear();
  return FULLUPDATE;
}
#endif


int
mail_mark(ent, fileinfo, direct)
  int ent;
  struct fileheader *fileinfo;
  char *direct;
{
  fileinfo->filemode ^= FILE_MARKED;
  substitute_record(currmaildir, fileinfo, sizeof(*fileinfo), ent);
  return (PARTUPDATE);
}


/* help for mail reading */

static char *mail_help[] =
{
  "\0�q�l�H�c�ާ@����",
  "\01�򥻩R�O",
  "[p][��]    �e�@�g�峹",
  "[n][��]    �U�@�g�峹",
  "[P][PgUp]  �e�@��",
  "[N][PgDn]  �U�@��",
  "[##][cr]   ����� ## ��",
  "[$]        ����̫�@��",
  "\01�i���R�O",
  "[r][��]    Ū�H",
  "[R]        �^�H",
  "[x]        ��F�H��",
  "[y]        �s�զ^�H",

#ifdef INTERNET_EMAIL
  "[F]        �N�H�ǰe�^�z���q�l�H�c",
#endif

  "[d]        �������H",
  "[D]        �������w�d�򪺫H",
  "[m]        �N�H�аO�A�H���Q�M��",
  NULL
};


int
mailreadhelp()
{
  show_help(mail_help);
  return FULLUPDATE;
}


struct one_key mail_comms[] = {
  'd', mail_del,
  'D', mail_del_range,
  'r', mail_read,
  'R', mail_reply,
  'm', mail_mark,
  'x', m_forward,
  'y', multi_reply,

#ifdef INTERNET_EMAIL
  'F', mail_forward,
  'U', mail_uforward,
#endif

  'h', mailreadhelp,
  '\0', NULL
};


int
m_read()
{
  if (get_num_records(currmaildir, sizeof(fileheader)))
  {
    in_mail = YEA;
    i_read(RMAIL, currmaildir, mailtitle, maildoent, mail_comms);
    in_mail = NA;
    return 0;
  }
  else
  {
    outs("�z�S���ӫH");
    return XEASY;
  }
}


#ifdef INTERNET_EMAIL
#include <netdb.h>
#include <pwd.h>
#include <time.h>
#define BBSMAILDIR "/usr/spool/mqueue"


int
invalidaddr(addr)
  char *addr;
{
  if (*addr == '\0')
    return 1;			/* blank */
  while (*addr)
  {
    if (!isalnum(*addr) && index("[].%!@:;-_", *addr) == NULL)
      return 1;
    addr++;
  }
  return 0;
}


void
spacestozeros(s)
  char *s;
{
  while (*s)
  {
    if (*s == ' ')
      *s = '0';
    s++;
  }
}


int
getqsuffix(s)
  char *s;
{
  struct stat stbuf;
  char qbuf[STRLEN], dbuf[STRLEN];
  char c1 = 'A', c2 = 'A';
  int pos = strlen(BBSMAILDIR) + 3;
  sprintf(dbuf, "%s/dfAA%5d", BBSMAILDIR, getpid());
  sprintf(qbuf, "%s/qfAA%5d", BBSMAILDIR, getpid());
  spacestozeros(dbuf);
  spacestozeros(qbuf);
  while (1)
  {
    if (stat(dbuf, &stbuf) && stat(qbuf, &stbuf))
      break;
    if (c2 == 'Z')
    {
      c2 = 'A';
      if (c1 == 'Z')
	return -1;
      else
	c1++;
      dbuf[pos] = c1;
      qbuf[pos] = c1;
    }
    else
      c2++;
    dbuf[pos + 1] = c2;
    qbuf[pos + 1] = c2;
  }
  strcpy(s, &(qbuf[pos]));
  return 0;
}


void
convert_tz(local, gmt, buf)
  int gmt, local;
  char *buf;
{
  local -= gmt;
  if (local < -11)
    local += 24;
  else if (local > 12)
    local -= 24;
  sprintf(buf, " %4d", abs(local * 100));
  spacestozeros(buf);
  if (local < 0)
    buf[0] = '-';
  else if (local > 0)
    buf[0] = '+';
  else
    buf[0] = '\0';
}


#if 0
createqf(title, qsuffix)
  char *title, *qsuffix;
{
  static int configured = 0;
  static char myhostname[STRLEN];
  static char myusername[20];
  char mytime[STRLEN];
  char idtime[STRLEN];
  char qfname[STRLEN];
  char t_offset[6];
  FILE *qfp;
  time_t timenow;
  int savehour;
  struct tm *gtime, *ltime;
  struct hostent *hbuf;
  struct passwd *pbuf;

  if (!configured)
  {
    /* get host name */
    gethostname(myhostname, STRLEN);
    hbuf = gethostbyname(myhostname);
    if (hbuf)
      strncpy(myhostname, hbuf->h_name, STRLEN);

    /* get bbs uident */
    pbuf = getpwuid(getuid());
    if (pbuf)
      strncpy(myusername, pbuf->pw_name, 20);
    if (hbuf && pbuf)
      configured = 1;
    else
      return -1;
  }

  /* get file name */
  sprintf(qfname, "%s/qf%s", BBSMAILDIR, qsuffix);
  if ((qfp = fopen(qfname, "w")) == NULL)
    return -1;

  /* get time */
  time(&timenow);
  ltime = localtime(&timenow);

#ifdef SYSV
  ascftime(mytime, "%a, %d %b %Y %T ", ltime);
#else
  strftime(mytime, sizeof(mytime), "%a, %d %b %Y %T ", ltime);
#endif

  savehour = ltime->tm_hour;
  gtime = gmtime(&timenow);
  strftime(idtime, sizeof(idtime), "%Y%m%d%y%H%M", gtime);
  convert_tz(savehour, gtime->tm_hour, t_offset);
  strcat(mytime, t_offset);
  fprintf(qfp, "P1000\nT%lu\nDdf%s\nS%s\nR%s\n", timenow, qsuffix,
    myusername, cuser.email);

  /* do those headers! */
  fprintf(qfp, "HReceived: by %s (" MYVERSION ")\n\tid %s; %s\n",
    myhostname, qsuffix, mytime);
  fprintf(qfp, "HReturn-Path: <%s@%s>\n", myusername, myhostname);
  fprintf(qfp, "HDate: %s\n", mytime);
  fprintf(qfp, "HMessage-Id: <%s.%s@%s>\n", idtime, qsuffix,
    myhostname);
  fprintf(qfp, "HFrom: %s@%s (%s in NCTU CSIE BBS)\n", myusername, myhostname, cuser.userid);
  fprintf(qfp, "HSubject: %s (fwd)\n", title);
  fprintf(qfp, "HTo: %s\n", cuser.email);
  fprintf(qfp, "HX-Forwarded-By: %s (%s)\n", cuser.userid,

#ifdef REALNAME
    cuser.realname);
#else
    cuser.username);
#endif

  fprintf(qfp, "HX-Disclaimer: %s �糧�H���e�����t�d�C\n", BoardName);
  fclose(qfp);
  return 0;
}
#endif


int
bbs_sendmail(fname, title, receiver)
  char *fname, *title, *receiver;
{
  static int configured = 0;
  static char myhostname[STRLEN];
  static char myusername[20];
  struct hostent *hbuf;
  struct passwd *pbuf;

  FILE *fin, *fout;

  /*
   * setup the hostname and username
   */
  if (!configured)
  {
    /* get host name */
    gethostname(myhostname, STRLEN);
    hbuf = gethostbyname(myhostname);
    if (hbuf)
      strncpy(myhostname, hbuf->h_name, STRLEN);

    /* get bbs uident */
    pbuf = getpwuid(getuid());
    if (pbuf)
      strncpy(myusername, pbuf->pw_name, 20);
    if (hbuf && pbuf)
      configured = 1;
    else
      return -1;
  }

  /*
   * Running the sendmail
   */

#ifdef INTERNET_PRIVATE_EMAIL
  if (fname == NULL)
  {
    sprintf(genbuf, "/usr/lib/sendmail %s ", receiver);
    fin = fopen("etc/confirm", "r");
  }
  else
  {
    sprintf(genbuf, "/usr/lib/sendmail -f %s%s %s ", cuser.userid, str_mail_address, receiver);
    fin = fopen(fname, "r");
  }
  fout = popen(genbuf, "w");
  if (fin == NULL || fout == NULL)
    return -1;

  if (fname)

    fprintf(fout, "Reply-To: %s%s\nFrom: %s <%s%s>\n",
      cuser.userid, str_mail_address, cuser.username, cuser.userid, str_mail_address);
#else
  sprintf(genbuf, "/usr/lib/sendmail %s ", receiver);
  fout = popen(genbuf, "w");
  fin = fopen(fname ? fname : "etc/confirm", "r");
  if (fin == NULL || fout == NULL)
    return -1;

  if (fname)

    fprintf(fout, "From: %s@%s (%s)\n",
      myusername, myhostname, BBSNAME);
#endif

  fprintf(fout, "To: %s\n", receiver);
  fprintf(fout, "Subject: %s\n", title);
  /* since "From " is the real user (not bbs), no X-Forwarded-By needed */

#ifdef 0
  fprintf(fout, "X-Forwarded-By: %s (%s)\n", cuser.userid,

#ifdef REALNAME
    cuser.realname);
#else
    cuser.username);
#endif

#endif

  /*
   * To keep the body for returned mail, drop the "Precendence: " chuan.
   * (6/20/95)
   */

#ifdef 0
  fprintf(fout, "X-Disclaimer: �M�ظ�T" BOARDNAME
    "�糧�H���e�����t�d�C\nPrecedence: junk\n\n");
#endif

  fprintf(fout, "X-Disclaimer: �M�ظ�T" BOARDNAME
    "�糧�H���e�����t�d�C\n\n");

  while (fgets(genbuf, 255, fin) != NULL)
  {
    if (genbuf[0] == '.' && genbuf[1] == '\n')
      fputs(". \n", fout);
    else
      fputs(genbuf, fout);
  }

  fprintf(fout, ".\n");

  fclose(fin);
  pclose(fout);
  return 0;
}


int
doforward(direct, fh, mode)
  char *direct;
  fileheader *fh;
  int mode;
{
  static char address[STRLEN];
  char fname[STRLEN];
  char tmp_buf[128];
  int return_no;

  clear();
  if (address[0] == '\0')
  {
    strcpy(address, cuser.email);
  }
  outs("�Ъ����� Enter �����A�������ܪ��a�}, �Ϊ̿�J��L�a�}\n");
  sprintf(genbuf, "��H����H�� [%s] ==> ", address);

  getdata(1, 0, genbuf, fname, 72, DOECHO);
  if (fname[0] == '\0')
  {
    sprintf(genbuf, "�T�w�N�峹�H�� %s ��? (Y/N) [Y]: ", address);
    getdata(2, 0, genbuf, fname, 2, DOECHO);
    if (fname[0] == 'n' || fname[0] == 'N')
      return 1;
  }
  else
  {
    strcpy(address, fname);
  }

  if (invalidaddr(address))
    return -2;

  prints("����H�H�� %s, �еy��...\n", address);

  if (mode == 0)
    sprintf(fname, "%s/%s", direct, fh->filename);
  else if (mode == 1)
  {
    sprintf(fname, "/tmp/file.uu%05d", getpid());
    sprintf(tmp_buf, "uuencode %s/%s uu.%05d > %s",
      direct, fh->filename, getpid(), fname);
    system(tmp_buf);
  }
  return_no = bbs_sendmail(fname, fh->title, address);

  if (mode == 1)
    unlink(fname);

  return (return_no);


  /*
   * The section is comment out by jjyang for direct mail delivery
   */

#if 0
  /* create data file */
  if (getqsuffix(qsuffix) == -1)
    return -1;
  sprintf(fname, "%s/%s", direct, fh->filename);
  sprintf(dfname, "%s/df%s", BBSMAILDIR, qsuffix);
  if (link(fname, dfname) != 0)
    return -1;
  return (createqf(fh->title, qsuffix));
#endif
}
#endif


#ifdef HAVE_NAMEFILE
char *
get_bbs_mail_domain()
{
  static char mail_domain[STRLEN];
  FILE *fh;

  fh = fopen("/etc/bbs_mail_domain", "r");
  if (fh == NULL)
  {
    strncpy(mail_domain, MYHOSTNAME, STRLEN);
  }
  else
  {
    fgets(mail_domain, STRLEN, fh);
    mail_domain[strlen(mail_domain) - 1] = '\0';
    fclose(fh);
  }

  return mail_domain;
}


char *
get_bbs_english_name()
{
  static char english_name[STRLEN];
  FILE *fh;

  fh = fopen("/etc/bbs_english_name", "r");
  if (fh == NULL)
  {
    strncpy(english_name, BBSNAME, STRLEN);
  }
  else
  {
    fgets(english_name, STRLEN, fh);
    english_name[strlen(english_name) - 1] = '\0';
    fclose(fh);
  }

  return english_name;
}
#endif				/* HAVE_NAMEFILE */


int
chkmail(rechk)
  short rechk;
{
  static long lasttime = 0;
  static ismail = 0;
  struct fileheader fh;
  struct stat st;
  int fd;
  register unsigned short numfiles;
  unsigned char ch;

  if (!HAS_PERM(PERM_BASIC))
  {
    return 0;
  }

  if ((fd = open(currmaildir, O_RDONLY)) < 0)
    return (ismail = 0);
  fstat(fd, &st);
  if ((lasttime >= st.st_mtime) && !rechk)
  {
    close(fd);
    return ismail;
  }
  lasttime = st.st_mtime;
  numfiles = st.st_size / sizeof(fileheader);
  if (numfiles <= 0)
  {
    close(fd);
    return (ismail = 0);
  }

  /* ------------------------------------------------ */
  /* �ݬݦ��S���H���٨SŪ�L�H�q�ɧ��^�Y�ˬd�A�Ĳv���� */
  /* ------------------------------------------------ */

  lseek(fd, st.st_size - 1, SEEK_SET);
  while (numfiles--)
  {
    read(fd, &ch, 1);
    if (!(ch & FILE_READ))
    {
      close(fd);
      /* bell(); */
      return (ismail = 1);
    }
    lseek(fd, -sizeof(fileheader) - 1, SEEK_CUR);
  }
  close(fd);
  return (ismail = 0);
}


void
mail_note()
{
  bell();
  move(t_lines - 3, 0);
  prints("\
�� ���F�z���v�q�A�ж�g�u�ꪺ E-mail address�A �H��T�{�դU�����C\n\n\
�� �p�G�z�u���S�� E-mail�A�ж�g [44m%s%s[m",
    cuser.userid, str_mail_address);
}


void
mail_justify()
{
  more("etc/justify", NA);
  if (valid_ident(cuser.email) && !invalidaddr(cuser.email))
  {
    char title[80], *ptr;
    unsigned short checksum;	/* 16 bits is enough */
    char ch;

    checksum = usernum;
    ptr = (char *) &cuser.email;
    while (ch = *ptr++)
    {
      checksum = (checksum << 1) ^ ch;
    }

    sprintf(title, "[MapleBridge]To %s(%d:%d) [BBS user Justify]",
      cuser.userid, usernum + 1234, checksum);
    if (bbs_sendmail(NULL, title, cuser.email) < 0)
      outs("[1m�����{�ҫH��L�k�H�X�A�бz��g�u�� E-mail address[m");
    else
      prints("\n%s(%s)�z�n�A�ѩ�z��s E-mail address ���]�w�A\n"
	"�бz���֨� [44m%s[m �Ҧb���u�@���^�Сy�����{�ҫH��z�C",
	cuser.userid, cuser.username, cuser.email);
  }
  else
  {
    prints("\n%s(%s)�z�n�A�ѩ�z�S���u�� E-mail address�A"
      "�N�|�l�������\\��A�бz�� [1;42m User��Register [m ��g���U����C",
      cuser.userid, cuser.username);
  }
  pressanykey();
}
