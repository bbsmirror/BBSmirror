#include "bbs.h"
#include <time.h>

#define MAXLEN		256
#define MAXITEMS	256
#define PATHLEN		128

enum
{
  NOBODY, MANAGER, SYSOP
};

#define ADDITEM		0
#define	ADDGROUP	1

typedef struct
{
  char title[63];
  char fdate[9];		/* [mm/dd/yy] */
  char fname[32];
}      ITEM;

typedef struct
{
  ITEM *item[MAXITEMS];
  char mtitle[STRLEN];
  char *path;
  int num, page, now;
  int level;
}      MENU;

ITEM copybuf;
char copyfile[MAXLEN];

char a_fmode = 0;
char *err_dup_fn = "�t�Τ��w���P�W�ɮצs�b�F�I";

static char mytitle[] = BOARDNAME "�G�i��";
static char inf_title[63] = "�� ";	/* A1BA/BB �� */


int
invalid_fname(str)
  char *str;
{
  char ch;

  while (ch = *str++)
  {
    if (!(isalnum(ch) || strchr("@[]-._/", ch)))
      return 1;
  }
  return 0;
}


void
a_additem(pm, myitem)
  MENU *pm;
  ITEM *myitem;
{
  ITEM *newitem;

  if (pm->num < MAXITEMS)
  {
    newitem = (ITEM *) malloc(sizeof(ITEM));
    memcpy(newitem, myitem, sizeof(ITEM));
    pm->item[(pm->num)++] = newitem;
  }
}


void
a_savenames(pm)
  MENU *pm;
{
  FILE *fn;
  ITEM *item;
  char fpath[PATHLEN];
  int n;

  sprintf(fpath, "%s%s", pm->path, str_mandex);
  if ((fn = fopen(fpath, "w")) == NULL)
    return;
  fprintf(fn, "# Title=%s\n\n", pm->mtitle);
  for (n = 0; n < pm->num; n++)
  {
    item = pm->item[n];
    fprintf(fn, "Name=%s\nDate=%s\nPath=%s\nNumb=%d\n\n", item->title, item->fdate, item->fname, n + 1);
  }
  fclose(fn);
  chmod(fpath, 0644);
}


int
a_loadnames(pm)
  MENU *pm;
{
  FILE *fn;
  char buf[MAXLEN], *ptr;
  ITEM item;
  int dirty;

  pm->num = dirty = 0;
  item.fdate[0] = '\0';
  sprintf(buf, "%s%s", pm->path, str_mandex);
  if ((fn = fopen(buf, "r")) == NULL)
    return 0;

  while (fgets(buf, sizeof(buf), fn))
  {
    if (ptr = strchr(buf, '\n'))
      *ptr = '\0';
    if (strncmp(buf, "Name=", 5) == 0)
    {
      strcpy(item.title, buf + 5);
    }
    else if (strncmp(buf, "Date=", 5) == 0)
    {
      strcpy(item.fdate, buf + 5);
    }
    else if (strncmp(buf, "Path=", 5) == 0)
    {
      strcpy(item.fname, buf + 5);
      if (item.fdate[0] == '\0')
      {
	struct stat st;
	sprintf(buf, "%s/%s", pm->path, item.fname);
	if (stat(buf, &st) == 0)
	{
	  struct tm *pt = localtime(&st.st_mtime);
	  sprintf(item.fdate, "%02d/%02d/%02d",
	    pt->tm_mon + 1, pt->tm_mday, pt->tm_year);
	  dirty = 1;
	}
      }
      a_additem(pm, &item);
      item.fdate[0] = '\0';
    }
    else if (strncmp(buf, "# Title=", 8) == 0)
    {
      /* if( pm->mtitle[0] == '\0' ) /* JhLin */
      strcpy(pm->mtitle, buf + 8);
    }
  }
  fclose(fn);

  /* JhLin */
  if (pm->mtitle[0] == '\0')
    strcpy(pm->mtitle, mytitle);
  if (dirty)
    a_savenames(pm);
}


void
a_showmenu(pm)
  MENU *pm;
{
  static char *mytype[] = {"��    ��", "�ɮצW��"};
  register char *title;
  int n;
  char ch;

  showtitle("��ؤ峹", pm->mtitle);

  prints("  [1;36m�s��    ��      �D%56s[0;37m\n", mytype[a_fmode]);

  if (pm->num == 0)
  {
    outs("  �m��ذϡn�|�b�l���Ѧa��������� :)");
  }

  for (n = pm->page; n < pm->page + p_lines && n < pm->num; n++)
  {
    title = pm->item[n]->title;
    if (a_fmode)
    {
      if (title[1] == (char) 0xbb)
	ch = '/';
      else
	ch = ' ';
      prints("%5d. %-51.51s %s%c\n", n + 1, title, pm->item[n]->fname, ch);
    }
    else
    {

#ifdef	INFO_COLOR
      if (title[1] == (char) 0xbb)	/* JhLin: directory */
	prints("%5d. [1;33m%s[37;0m\n", n + 1, title);
      else
#endif

	prints("%5d. %-60s[%s]\n", n + 1, title, pm->item[n]->fdate);
    }

  }

  move(b_lines, 1);
  outs(pm->level >= MANAGER ?
    "[1;46m �i�O  �D�j [45m  ���� h �x ���} q,�� �x �s�W�峹 a �x �s�W�ؿ� g �x �s���ɮ� e  [0m" :
    "[1;46m �i�\\����j [45m  ���� h �x ���} q,�� �x ���ʴ�� k��j�� �x Ū����� enter/��  [0m");

}


void
a_showhelp(level)
  int level;
{
  clear();
  outs("[36m�i " BOARDNAME "���G��ϥλ��� �j[m\n\n\
[��][q]         ���}��W�@�h�ؿ�\n\
[��][k]         �W�@�ӿﶵ\n\
[��][j]         �U�@�ӿﶵ\n\
[��][r][enter]  �i�J�ؿ���Ū���峹\n\
[^B][PgUp]      �W�����\n\
[^F][PgDn][Spc] �U�����\n\
[##]            ����ӿﶵ\n\n\
[F]             �N�峹�H�^ Internet �l�c\n\
[U]             �N�峹 uuencode ��H�^�l�c\n");

  if (level >= MANAGER)
  {
    outs("\n[36m�i �O�D�M���� �j[m\n\
[a/g]           ������ؤ峹/�}�P�ؿ�\n\
[m/d]           ����/�R���峹\n\
[t/e]           �ק�峹���D/���e\n\
[f/n]           �d��/����ɦW\n\
[c/p]           ����/�߶K�峹\n");
  }
  if (level >= SYSOP)
  {
    outs("\n[36m�i �����M���� �j[m\n\
[v]             �s�� .Name\n");
  }
  pressanykey();
}



void
a_newitem(pm, mode)
  MENU *pm;
{
  static char *mesg[2] = {
    "[�s�W�峹] �п�J�ɮצW��: ",	/* ADDITEM */
  "[�s�W�ؿ�] �п�J�ؿ��W��: "};	/* ADDGROUP */

  char fpath[PATHLEN];
  ITEM item;
  time_t dtime;
  struct tm *ptime;

  pm->page = 9999;
  if (getdata(t_lines - 2, 1, mesg[mode], item.fname, 32, DOECHO) == 0)
    return;
  if (invalid_fname(item.fname))
  {
    outs(err_filename);
    igetch();
  }
  else
  {
    sprintf(fpath, "%s/%s", pm->path, item.fname);
    if (dashf(fpath) || dashd(fpath))
    {
      clrtoeol();
      outs(err_dup_fn);
      igetch();
    }
    else
    {
      if (getdata(b_lines, 1, "�п�J���D�G", &inf_title[3], 60, DOECHO) == 0)
	return;
      if (mode)
      {				/* ADDGROUP */
	mkdir(fpath, 0755);
	inf_title[1] = 0xbb;
      }
      else
      {				/* ADDITEM */
	vedit(fpath, 0);
	chmod(fpath, 0644);
	inf_title[1] = 0xba;
      }
      strcpy(item.title, inf_title);
      time(&dtime);
      ptime = localtime(&dtime);
      sprintf(item.fdate, "%02d/%02d/%02d",
	ptime->tm_mon + 1, ptime->tm_mday, ptime->tm_year);
      a_additem(pm, &item);
      a_savenames(pm);
    }
  }
}


void
a_moveitem(pm)
  MENU *pm;
{
  ITEM *tmp;
  char newnum[4];
  int num, n;

  sprintf(genbuf, "�п�J�� %d �ﶵ���s����: ", pm->now + 1);
  if (getdata(b_lines - 1, 1, genbuf, newnum, 4, DOECHO) == 0)
    return;
  num = (newnum[0] == '$') ? 9999 : atoi(newnum) - 1;
  if (num >= pm->num)
    num = pm->num - 1;
  else if (num < 0)
    num = 0;
  tmp = pm->item[pm->now];
  if (num > pm->now)
  {
    for (n = pm->now; n < num; n++)
      pm->item[n] = pm->item[n + 1];
  }
  else
  {
    for (n = pm->now; n > num; n--)
      pm->item[n] = pm->item[n - 1];
  }
  pm->item[num] = tmp;
  pm->now = num;
  a_savenames(pm);
}


void
a_delete(pm)
  MENU *pm;
{
  ITEM *item;
  char fpath[PATHLEN];
  char ans[2];
  int n;

  item = pm->item[pm->now];
  sprintf(fpath, "%s/%s", pm->path, item->fname);

  if (dashf(fpath))
  {
    getdata(b_lines, 1, "�z�T�w�n�R�����ɮ׶�? [N]", ans, 2, DOECHO);
    if (ans[0] != 'y' && ans[0] != 'Y')
      return;
    unlink(fpath);
  }
  else if (dashd(fpath))
  {
    getdata(b_lines, 1, "�z�T�w�n�R����ӥؿ���? [N]",
      ans, 2, DOECHO);
    if (ans[0] != 'y' && ans[0] != 'Y')
      return;
    sprintf(genbuf, "/bin/rm -rf %s", fpath);
    system(genbuf);
  }

  free(item);
  (pm->num)--;
  for (n = pm->now; n < pm->num; n++)
    pm->item[n] = pm->item[n + 1];
  a_savenames(pm);
}


void
a_newname(pm)
  MENU *pm;
{
  ITEM *item;
  char fname[32];
  char fpath[PATHLEN];
  char *mesg;

  item = pm->item[pm->now];
  if (getdata(b_lines - 1, 1, "�s�ɦW�G", fname, 32, DOECHO) == 0)
    return;
  if (invalid_fname(fname))
  {
    mesg = err_filename;
  }
  else
  {
    sprintf(fpath, "%s/%s", pm->path, fname);
    if (dashf(fname) || dashd(fname))
    {
      mesg = err_dup_fn;
    }
    else
    {
      sprintf(genbuf, "%s/%s", pm->path, item->fname);
      if (rename(genbuf, fpath) == 0)
      {
	strcpy(item->fname, fname);
	a_savenames(pm);
	return;
      }
      mesg = "�ɦW��異�ѡI";
    }
  }
  outs(mesg);
  igetch();
}


void
a_copyitem(pm)
  MENU *pm;
{
  ITEM *item;

  item = pm->item[pm->now];
  memcpy(&copybuf, item, sizeof(ITEM));
  sprintf(copyfile, "%s/%s", pm->path, copybuf.fname);
  move(b_lines, 0);
  clrtoeol();
  outs("�ɮ׼аO�����C[�`�N] �߶K�峹��~��R�����!");
  igetch();
}


void
a_pasteitem(pm)
  MENU *pm;
{
  char newpath[PATHLEN];
  char ans[2];

  move(b_lines, 1);
  if (copyfile[0] == '\0')
  {
    outs("�Х����� copy �R�O��~�� paste");
    igetch();
  }
  else
  {
    sprintf(newpath, "%s/%s", pm->path, copybuf.fname);
    if (dashf(newpath) || dashd(newpath))
    {
      prints("�ɮ�/�ؿ��p�P�G%s", copybuf.fname);
      igetch();
    }
    else if (strstr(newpath, copyfile))
    {
      outs("�N�ؿ����i�ۤv���l�ؿ����A�|�y���L�a�j��I");
      igetch();
    }
    else
    {
      sprintf(genbuf, "�T�w�n�߶K[%s]��?(Y/N)[N] ", copybuf.title);
      getdata(b_lines - 1, 1, genbuf, ans, 2, DOECHO);
      if (ans[0] == 'y' || ans[0] == 'Y')
      {
	sprintf(genbuf, "/bin/cp -r %s %s", copyfile, newpath);
	system(genbuf);
	a_additem(pm, &copybuf);
	a_savenames(pm);
      }
    }
  }
}


void
a_forward(path, pitem, mode)
  char *path;
  ITEM *pitem;
  int mode;
{
  fileheader fhdr;

  strcpy(fhdr.filename, pitem->fname);
  strcpy(fhdr.title, pitem->title);
  switch (doforward(path, &fhdr, mode))
  {
  case 0:
    outs("�峹��H����!");
    break;
  case -1:
    outs("system error");
    break;
  case -2:
    outs("invalid address");
    break;
  default:
    outs("������H�ʧ@");
  }
}


void
a_menu(maintitle, path, lastlevel)
  char *maintitle;
  char *path;
  int lastlevel;
{
  MENU me;
  char fname[PATHLEN];
  int ch;

  modify_user_mode(ANNOUNCE);

  me.path = path;
  strcpy(me.mtitle, maintitle);
  a_loadnames(&me);

  if ((me.level = lastlevel) < MANAGER)
  {
    a_fmode = 0;
    if (strstr(me.mtitle, cuser.userid))
      me.level = MANAGER;
  }

  me.page = 9999;
  me.now = 0;
  while (1)
  {
    if (me.now >= me.num && me.num > 0)
    {
      me.now = me.num - 1;
    }
    else if (me.now < 0)
    {
      me.now = 0;
    }

    if (me.now < me.page || me.now >= me.page + p_lines)
    {
      me.page = me.now - (me.now % p_lines);
      a_showmenu(&me);
    }

    move(2 + me.now - me.page, 0);
    outs(str_cursor);
    move(2 + me.now - me.page, 1);
    ch = egetch();
    move(2 + me.now - me.page, 0);
    outs(str_uncur);

    if (ch == 'q' || ch == 'Q' || ch == KEY_LEFT)
      break;

    if (ch >= '0' && ch <= '9')
    {
      if ((ch = search_num(ch, me.num)) != -1)
	me.now = ch;
      me.page = 9999;
      continue;
    }


    switch (ch)
    {
    case KEY_UP:
    case 'k':
    case 'K':
      if (--me.now < 0)
	me.now = me.num - 1;
      break;
    case KEY_DOWN:
    case 'j':
    case 'J':
      if (++me.now >= me.num)
	me.now = 0;
      break;
    case KEY_PGUP:
    case Ctrl('B'):
      if (me.now >= p_lines)
	me.now -= p_lines;
      else if (me.now > 0)
	me.now = 0;
      else
	me.now = me.num - 1;
      break;
    case ' ':
    case KEY_PGDN:
    case Ctrl('F'):
      if (me.now < me.num - p_lines)
	me.now += p_lines;
      else if (me.now < me.num - 1)
	me.now = me.num - 1;
      else
	me.now = 0;
      break;
    case 'h':
    case 'H':
    case '?':
      a_showhelp(me.level);
      me.page = 9999;
      break;
    case '\n':
    case '\r':
    case KEY_RIGHT:
    case 'r':
    case 'R':
      if (me.now < me.num)
      {
	sprintf(fname, "%s/%s", path, me.item[me.now]->fname);
	if (dashf(fname))
	{
	  more(fname, YEA);
	}
	else if (dashd(fname))
	{
	  a_menu(me.item[me.now]->title, fname, me.level);
	}
	me.page = 9999;
      }
      break;
    case 'F':
    case 'U':
      sprintf(fname, "%s/%s", path, me.item[me.now]->fname);
      if (me.now < me.num && HAS_PERM(PERM_BASIC) && dashf(fname))
	a_forward(path, me.item[me.now], ch == 'U');
      else
      {
	move(b_lines - 1, 0);
	outs("�L�k��H������");
      }
      me.page = 9999;
      pressanykey();
      break;
    }

    if (me.level >= MANAGER)
    {
      switch (ch)
      {
      case 'a':
	a_newitem(&me, ADDITEM);
	break;
      case 'g':
	a_newitem(&me, ADDGROUP);
	break;
      case 'p':
	a_pasteitem(&me);
	me.page = 9999;
      }

      if (me.num)
	switch (ch)
	{
	case 'm':
	  a_moveitem(&me);
	  me.page = 9999;
	  break;
	case 'D':
	  me.page = -1;
	case 'd':
	  a_delete(&me);
	  me.page = 9999;
	  break;
	case 't':
	  if (getdata(b_lines - 1, 1, "�s���D�G", genbuf, 60, DOECHO) > 0)
	  {
	    char *p = &(me.item[me.now]->title[0]);
	    strcpy(p + 3, genbuf);
	    a_savenames(&me);
	    if (p[1] == (char) 0xbb)
	    {
	      FILE *fn;

	      sprintf(fname, "%s/%s%s",
		path, me.item[me.now]->fname, str_mandex);
	      if (fn = fopen(fname, "a+"))
	      {
		fprintf(fn, "\n# Title=%s\n", p);
		fclose(fn);
	      }
	    }
	  }
	  me.page = 9999;
	  break;
	case 'e':
	  sprintf(fname, "%s/%s", path, me.item[me.now]->fname);
	  if (dashf(fname))
	  {
	    vedit(fname, 0);
	    me.page = 9999;
	  }
	  break;
	case 'f':
	  a_fmode ^= 1;
	  me.page = 9999;
	  break;
	case 'n':
	  a_newname(&me);
	  me.page = 9999;
	  break;
	case 'c':
	  a_copyitem(&me);
	  me.page = 9999;
	  break;
	}
    }

    if ((me.level == SYSOP) && (ch == 'v'))
    {
      sprintf(fname, "%s%s", path, str_mandex);
      vedit(fname, 0);
      me.page = 9999;
    }
  }
  for (ch = 0; ch < me.num; ch++)
    free(me.item[ch]);
}


int
Announce()
{
  a_fmode = 0;
  a_menu(mytitle, "man", (HAS_PERM(PERM_SYSOP) ? SYSOP : NOBODY));
  return 0;
}
