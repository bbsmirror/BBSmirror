/* cache.c */

#include "bbs.h"
#include <sys/ipc.h>
#include <sys/shm.h>

#define BUSY_INT	799	/* busy interval */
#define BRDSHM_KEY	3893
#define UIDSHM_KEY	3896
#define UTMPSHM_KEY	3899

struct BCACHE *brdshm;
struct UCACHE *uidshm;
struct UTMPFILE *utmpshm;

userec xuser;
boardheader *bcache;
int usernumber;
int numboards = -1;


void
attach_err(shmkey, name)
  int shmkey;
  char *name;
{
  fprintf(stderr, "[%s error] key = %x\n", name, shmkey);
  exit(1);
}


void *
attach_shm(shmkey, shmsize)
  int shmkey, shmsize;
{
  void *shmptr;
  int shmid;

  shmid = shmget(shmkey, shmsize, 0);
  if (shmid < 0)
  {
    shmid = shmget(shmkey, shmsize, IPC_CREAT | 0600);
    if (shmid < 0)
      attach_err(shmkey, "shmget");
    shmptr = (void *) shmat(shmid, NULL, 0);
    if (shmptr == (void *) -1)
      attach_err(shmkey, "shmat");
    memset(shmptr, 0, shmsize);
  }
  else
  {
    shmptr = (void *) shmat(shmid, NULL, 0);
    if (shmptr == (void *) -1)
      attach_err(shmkey, "shmat");
  }
  return shmptr;
}


/* ------------------------------------------ */
/* .BOARDS cache			      */
/* ------------------------------------------ */

int
fillbcache(fptr)
  boardheader *fptr;
{
  if (numboards < MAXBOARD)
  {
    boardheader *bptr = &bcache[numboards++];
    memcpy(bptr, fptr, sizeof(boardheader));
  }
  return 0;
}


/* force re-caching */

void
touch_boards()
{
  time(&(brdshm->touchtime));
  numboards = -1;
}


void
resolve_boards()
{
  if (brdshm == NULL)
  {
    brdshm = attach_shm(BRDSHM_KEY, sizeof(*brdshm));
    if (brdshm->touchtime == NULL)
      brdshm->touchtime = 1;
    bcache = brdshm->bcache;
  }

  while (brdshm->uptime < brdshm->touchtime)
  {
    if (brdshm->busystate)
    {
      usleep(rand() % BUSY_INT);
    }
    else
    {
      brdshm->busystate = 1;
      log_usies("CACHE", "reload bcache");
      numboards = 0;
      apply_record(str_boards, fillbcache, sizeof(boardheader));
      brdshm->number = numboards;
      /* opus: ���Ҧ� boards ��Ƨ�s��A�]�w uptime */
      brdshm->uptime = brdshm->touchtime;
      brdshm->busystate = 0;
    }
  }
  numboards = brdshm->number;
}


int
apply_boards(func)
  int (*func) ();
{
  register int i;

  resolve_boards();
  for (i = 0; i < numboards; i++)
    if (Ben_Perm(&bcache[i]))
      if ((*func) (&bcache[i]) == QUIT)
	return QUIT;
  return 0;
}


boardheader *
getbcache(bname)
  char *bname;
{
  register int i;

  resolve_boards();
  for (i = 0; i < numboards; i++)
    if (Ben_Perm(&bcache[i]))
      if (!ci_strncmp(bname, bcache[i].brdname, IDLEN + 2))
	return &bcache[i];
  return NULL;
}


int
getbnum(bname)
  char *bname;
{
  register int i;

  resolve_boards();
  for (i = 0; i < numboards; i++)
    if (Ben_Perm(&bcache[i]))
      if (!ci_strncmp(bname, bcache[i].brdname, STRLEN))
	return i + 1;
  return 0;
}


int
haspostperm(bname)
  char *bname;
{
  register int i;

  if (strcmp(bname, DEFAULTBOARD) == 0)
    return 1;
  if (!HAS_PERM(PERM_POST))
    return 0;
  if ((i = getbnum(bname)) == 0)
    return 0;

  /* ���K�ݪO�S�O�B�z */
  if (bcache[i - 1].level == PERM_POSTMASK | PERM_SYSOP)
    return 1;

  return (HAS_PERM(bcache[i - 1].level & ~PERM_POSTMASK));
}


/* ------------------------------------------ */
/* .PASSWDS cache			      */
/* ------------------------------------------ */

int
fillucache(uentp)
  userec *uentp;
{
  if (usernumber < MAXUSERS)
  {
    strncpy(uidshm->userid[usernumber], uentp->userid, IDLEN + 1);
    uidshm->userid[usernumber++][IDLEN] = '\0';
  }
  return 0;
}


/* -------------------------------------- */
/* (1) �t�αҰʫ�A�Ĥ@�� BBS user ��i�� */
/* (2) .FLUSH �|���إ� �Τw�g��s         */
/* -------------------------------------- */

void
resolve_ucache()
{
  if (uidshm == NULL)
  {
    uidshm = attach_shm(UIDSHM_KEY, sizeof(*uidshm));
    if (uidshm->touchtime == NULL)
      uidshm->touchtime = 1;
  }

  while (uidshm->uptime < uidshm->touchtime)
  {
    if (uidshm->busystate)
    {
      /* ------------------------------------------ */
      /* ��L user ���b flushing ucache ==> CSMA/CD */
      /* ------------------------------------------ */

      usleep(rand() % BUSY_INT);
    }
    else
    {
      uidshm->busystate = 1;	/* enter busy state */

      log_usies("CACHE", "reload ucache");
      usernumber = 0;
      apply_record(str_passfile, fillucache, sizeof(userec));
      uidshm->number = usernumber;
      /* �� user ��Ƨ�s��A�]�w uptime */
      uidshm->uptime = uidshm->touchtime;

      uidshm->busystate = 0;	/* leave busy state */
    }
  }
}


void
setuserid(num, userid)
  int num;
  char *userid;
{
  if (num > 0 && num <= MAXUSERS)
  {
    if (num > uidshm->number)
      uidshm->number = num;
    strncpy(uidshm->userid[num - 1], userid, IDLEN + 1);
  }
}


int
searchnewuser(mode)
  int mode;
/* 0 ==> ��L���b�� */
/* 1 ==> �إ߷s�b�� */
{
  register int num, i;

  resolve_ucache();
  num = uidshm->number;
  i = 0;
  while (i < num)
    if (uidshm->userid[i++][0] == '\0')
      return i;
  if (mode && num < MAXUSERS)
    return (num + 1);
  return 0;
}


int
searchuser(userid)
  char *userid;
{
  register int i;

  resolve_ucache();
  for (i = 0; i < uidshm->number; i++)
    if (!ci_strncmp(userid, uidshm->userid[i], IDLEN + 1))
      return i + 1;
  return 0;
}


int
apply_users(func)
  void (*func) ();
{
  register int i;
  resolve_ucache();
  for (i = 0; i < uidshm->number; i++)
    (*func) (uidshm->userid[i], i + 1);
  return 0;
}


int
getuser(userid)
  char *userid;
{
  int uid = searchuser(userid);

  if (uid == 0)
    return 0;
  get_record(str_passfile, &xuser, sizeof(xuser), uid);
  return uid;
}


char *
u_namearray(buf, pnum, tag)
  char buf[][IDLEN + 1], *tag;
  int *pnum;
{
  register struct UCACHE *reg_ushm = uidshm;
  register char *ptr, tmp;
  register int n, total;
  char tagbuf[STRLEN];
  int ch, num = 0;

  resolve_ucache();
  if (*tag == '\0')
  {
    *pnum = reg_ushm->number;
    return reg_ushm->userid[0];
  }
  for (n = 0; tag[n] != '\0'; n++)
  {
    tagbuf[n] = chartoupper(tag[n]);
  }
  tagbuf[n] = '\0';
  ch = tagbuf[0];
  total = reg_ushm->number;
  for (n = 0; n < total; n++)
  {
    ptr = reg_ushm->userid[n];
    tmp = *ptr;
    if (tmp == ch || tmp == ch - 'A' + 'a')
      if (chkstr(tag, tagbuf, ptr))
	strcpy(buf[num++], ptr);
  }
  *pnum = num;
  return buf[0];
}


/* -------------------------------------------- */
/* .UTMP cache					 */
/* -------------------------------------------- */

void
resolve_utmp()
{
  if (utmpshm == NULL)
  {
    utmpshm = attach_shm(UTMPSHM_KEY, sizeof(*utmpshm));
    if (utmpshm->uptime == NULL)
      utmpshm->uptime = utmpshm->number = 1;
  }
}


int
getnewutmpent(up)
  user_info *up;
{
  static int utmpfd = 0;
  user_info *uentp;
  time_t now;
  int i, n;

  if (utmpfd == 0)
  {
    utmpfd = open(ULIST, O_RDWR | O_CREAT, 0600);
    if (utmpfd < 0)
      return -1;
  }
  resolve_utmp();
  flock(utmpfd, LOCK_EX);
  for (i = 0; i < USHM_SIZE; i++)
  {
    uentp = &(utmpshm->uinfo[i]);
    if (!uentp->active || !uentp->pid)
      break;
  }
  if (i >= USHM_SIZE)
  {
    flock(utmpfd, LOCK_UN);
    return -1;
  }
  utmpshm->uinfo[i] = *up;
  utmpshm->number++;
  flock(utmpfd, LOCK_UN);

  /* ----------------- */
  /* �C  60 ����s�@�� */
  /* ----------------- */

  now = time(NULL) - 60;
  while (now > utmpshm->uptime)
  {
    if (utmpshm->busystate)
    {
      usleep(rand() % BUSY_INT);
    }
    else
    {
      utmpshm->busystate = 1;
      time(&utmpshm->uptime);
      for (n = now = 0; n < USHM_SIZE; n++)
      {
	uentp = &(utmpshm->uinfo[n]);
	if (uentp->active && uentp->pid)
	{
	  if (kill(uentp->pid, 0) == -1)
	    memset(uentp, 0, sizeof(user_info));
	  else
	    now++;
	}
      }
      utmpshm->number = now;
      while (--n && utmpshm->uinfo[n].active == 0)
	;
      ftruncate(utmpfd, 0);
      write(utmpfd, utmpshm->uinfo, n * sizeof(user_info));
      utmpshm->busystate = 0;
    }
  }
  return i + 1;
}


int
apply_ulist(fptr)
  int (*fptr) ();
{
  user_info *uentp, utmp;
  int i, max;

  resolve_utmp();
  max = USHM_SIZE - 1;
  while (max > 0 && utmpshm->uinfo[max].active == 0)
    max--;
  for (i = 0; i <= max; i++)
  {
    uentp = &(utmpshm->uinfo[i]);
    utmp = *uentp;
    if ((*fptr) (&utmp) == QUIT)
      return QUIT;
  }
  return 0;
}


int
search_ulist(uentp, fptr, farg)
  user_info *uentp;
  int (*fptr) ();
  int farg;
{
  int i;

  resolve_utmp();
  for (i = 0; i < USHM_SIZE; i++)
  {
    *uentp = utmpshm->uinfo[i];
    if ((*fptr) (farg, uentp))
      return i + 1;
  }
  return 0;
}


int
search_ulistn(uentp, fptr, farg, unum)
  struct user_info *uentp;
  int (*fptr) ();
  int farg;
  int unum;
{
  int i, j;

  resolve_utmp();
  for (i = j = 0; i < USHM_SIZE; i++)
  {
    *uentp = utmpshm->uinfo[i];
    if ((*fptr) (farg, uentp))
    {
      if (++j == unum)
	return i + 1;
    }
  }
  return 0;
}


int
count_logins(uentp, fptr, farg, show)
  user_info *uentp;
  int (*fptr) ();
  int farg;
  int show;
{
  int i, j;

  resolve_utmp();
  for (i = j = 0; i < USHM_SIZE; i++)
  {
    *uentp = utmpshm->uinfo[i];
    if ((*fptr) (farg, uentp))
    {
      j++;
      if (show)
      {
	prints("(%d) �ثe���A��: %-17.16s(�Ӧ� %s)\n", j,
	  modestring(uentp->mode, uentp->destuid, 1,
	    uentp->in_chat ? uentp->chatid : NULL), uentp->from);
      }
    }
  }
  return j;
}


void
update_ulist(uentp, uent)
  user_info *uentp;
  int uent;
{
  resolve_utmp();
  if (uent > 0 && uent <= USHM_SIZE)
  {
    if (uentp->pid == 0)
      utmpshm->number--;
    utmpshm->uinfo[uent - 1] = *uentp;
  }
}


int
count_ulist()
{

#if 0
  int max, count;
  register user_info *uentp;

  resolve_utmp();
  for (max = count = 0; max < USHM_SIZE; max++)
  {
    uentp = &(utmpshm->uinfo[max]);
    if (uentp->active && uentp->pid && kill(uentp->pid, 0) != -1)
      count++;
  }
  return count;
#endif

  resolve_utmp();
  return utmpshm->number;
}
