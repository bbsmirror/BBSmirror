/* talk.c */

#define	_MODES_C_

#include "bbs.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#ifdef lint
#include <sys/uio.h>
#endif

#define M_INT 15		/* monitor mode update interval */
#define P_INT 20		/* interval to check for page req. in
				 * talk/chat */

struct talk_win
{
  int curcol, curln;
  int sline, eline;
};

extern int bind( /* int,struct sockaddr *, int */ );
extern char *ctime();

#ifdef REALINFO
uschar real_user_names = 0;
#endif

/* -------------------------- */
/* �O�� friend �� user number */
/* -------------------------- */

#define	MAX_FRIEND	128
ushort myfriends[MAX_FRIEND];
ushort friendcount;
ushort friends_number;
ushort override_number;
char *fcolor[4] = {"", "[1;32m", "[1;33m", "[1m"};


extern int t_columns;
char *talk_uent_buf;
char save_page_requestor[44];

int t_cmpuids();


int
ishidden(user)
  char *user;
{
  int tuid;
  struct user_info uin;

  if (!(tuid = getuser(user)))
    return 0;
  search_ulist(&uin, t_cmpuids, tuid);
  return (uin.invisible);
}


char *
modestring(mode, towho, complete, chatid)
  int mode, towho, complete;
  char *chatid;
{
  static char modestr[40];
  struct userec urec;

  if (chatid)
  {
    if (complete)
      sprintf(modestr, "%s (%s)", ModeTypeTable[mode], chatid);
    else
      return (ModeTypeTable[mode]);
    return (modestr);
  }
  if (mode != TALK && mode != PAGE && mode != QUERY)
    return (ModeTypeTable[mode]);
  if (get_record(str_passfile, &urec, sizeof(urec), towho) == -1)
    return (ModeTypeTable[mode]);

  if (mode != QUERY && !HAS_PERM(PERM_SEECLOAK) && ishidden(urec.userid))
    return (ModeTypeTable[TMENU]);
  if (complete)
    sprintf(modestr, "%s [%s]", ModeTypeTable[mode], urec.userid);
  else
    return (ModeTypeTable[mode]);
  return (modestr);
}


char
pagerchar(me, them, pager)
  char *me, *them;
  int pager;
{
  if (pager)
    return ' ';
  else if (can_override(them, me))
    return 'O';
  else
    return '*';
}


#ifdef SHOW_IDLE_TIME
char *
idle_str(uent)
  struct user_info *uent;
{
  static char hh_mm_ss[6];
  char tty[20];
  struct stat buf;
  time_t diff;

  strcpy(tty, uent->tty);

  if ((stat(tty, &buf)) || (strstr(tty, "tty") == NULL))
  {
    /* strcpy(hh_mm_ss, "����"); */
    hh_mm_ss[0] = '\0';
    return hh_mm_ss;
  };

  diff = time(0) - buf.st_atime;

#ifdef DOTIMEOUT
  /*
   * the 60 * 60 * 24 * 5 is to prevent fault /dev mount from kicking out all
   * users
   */

  if ((diff > IDLE_TIMEOUT) && (diff < 60 * 60 * 24 * 5))
    kill(uent->pid, SIGHUP);
#endif

  sprintf(hh_mm_ss, "%2d:%02d", diff / 3600, (diff / 60) % 60);
  return hh_mm_ss;
}
#endif


void
print_user_info_title()
{
  move(2, 0);
  clrtoeol();
  prints(
    "[7m �ϥΪ̥N��  %-17s%-20sP%c %-14s%-11s[0m\n",

#ifdef REALINFO
    real_user_names ? "�u��m�W" :
#endif

    "�ϥΪ̼ʺ�",

    "�Ӧ�", (HAS_PERM(PERM_SEECLOAK) ? 'C' : ' '), "�ʺA",

#ifdef SHOW_IDLE_TIME
    "���m ��:��"
#else
    ""
#endif

    );
}


int
is_friend(uid)
  char *uid;
{
  ushort unum, hit, j;

  /* �P�_���O�_���ڪ��B�� ? */

  unum = searchuser(uid);
  for (j = 0; hit = myfriends[j]; j++)
  {
    if (unum == hit)
    {
      hit = 1;
      friends_number++;
      break;
    }
  }

  /* �P�_�ڬO�_����誺�B�� ? */

  if (can_override(uid, cuser.userid))
  {
    override_number++;
    hit |= 2;
  }
  return hit;
}


int
printcuent(uentp)
  struct user_info *uentp;
{
  static int i;
  int state;

  if (uentp == NULL)
  {
    print_user_info_title();
    i = 3;
    return 0;
  }
  if (!uentp->active || !uentp->pid)
    return 0;
  if (!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
    return 0;

  state = is_friend(uentp->userid);

  if (uinfo.mode == FRIEND && !state)
    return 0;

  clrtoeol();
  if (i == b_lines)
  {
    int ch;

    outs(" [46;1m  �ϥα��ΦC��  [45m  -- �������� (�� Q ����) --  [0m");
    while ((ch = igetch()) != EOF)
    {
      if (strchr("\n\r qQ", ch))
	break;
    }
    if (strchr("Qq", ch))
      return QUIT;
    print_user_info_title();
    clrtobot();
    i = 3;
  }

  prints("%s%-13s%-17.16s%-20.19s%c%c %-19.18s%s%s\n",
    fcolor[state], uentp->userid,

#ifdef REALINFO
    real_user_names ? uentp->realname :
#endif

    uentp->username,

    (uentp->pager == YEA || HAS_PERM(PERM_SYSOP)) ? uentp->from : "*",
    pagerchar(cuser.userid, uentp->userid, uentp->pager),
    (uentp->invisible ? '#' : ' '),
    modestring(uentp->mode, uentp->destuid, 1,
      (uentp->in_chat ? uentp->chatid : NULL)),

#ifdef SHOW_IDLE_TIME
    idle_str(uentp),
#else
    "",
#endif

    state ? "[37;0m" : "");

  i++;
  return 0;
}


int
listcuent(uentp)
  user_info *uentp;
{
  if (uentp == NULL)
  {
    CreateNameList();
    return 0;
  }
  if (uentp->uid == usernum)
    return 0;
  if (!uentp->active || !uentp->pid)
    return 0;
  if (!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
    return 0;
  AddNameList(uentp->userid);
  return 0;
}


void
creat_list()
{
  listcuent(NULL);
  apply_ulist(listcuent);
}


int
t_users()
{
  modify_user_mode(LUSERS);
  printcuent(NULL);
  if (apply_ulist(printcuent) == -1)
    outs("�S������ϥΪ̤W�u");
  clrtobot();
  pressanykey();
  return 0;
}


#ifdef REALINFO
t_rusers()
{
  real_user_names = 1;
  t_users();
  real_user_names = 0;
}
#endif


int
t_pager()
{
  uinfo.pager ^= 1;
  if (!uinfo.in_chat)
  {
    prints("�z���I�s���w�g%s�F!", uinfo.pager ? "���}" : "����");
  }
  update_utmp();
  return XEASY;
}


int
t_query()
{
  char uident[STRLEN], inbuf[STRLEN * 2];
  extern char currmaildir[];
  int tuid, i;
  FILE *planfile;

  modify_user_mode(QUERY);
  stand_title("�d�ߺ���");
  usercomplete(msg_uid, uident);
  if (uident[0] == '\0')
  {
    return 0;
  }
  if (!(tuid = getuser(uident)))
  {
    move(2, 0);
    outs(err_uid);
    pressanykey();
    return -1;
  }
  uinfo.destuid = tuid;
  update_utmp();

  move(3, 0);

#ifdef	HAVE_REPORT
  sprintf(genbuf, "�d�� %s", xuser.userid);
  report(genbuf);
#endif

  prints("%s(%s) �@�W�� %d ��, ���U���: %s\n",
    xuser.userid, xuser.username, xuser.numlogins,
    Cdate(&xuser.firstlogin));

  prints("�W��(%s)�q[%s]�W��\n", Cdate(&xuser.lastlogin),
    (xuser.lasthost[0] ? xuser.lasthost : "(����)"));

#if defined(REALINFO) && defined(QUERY_REALNAMES)
  if (HAS_PERM(PERM_BASIC))
    prints("�u��m�W: %s\n", xuser.realname);
#endif

#if 0
  prints("�q�l�l��H�c�a�}: %s \n", xuser.email);
#endif

  sethomedir(currmaildir, xuser.userid);
  outs(chkmail(1) ? "���s�H���٨S��\n" : "�Ҧ��H�󳣬ݹL�F\n");
  sethomedir(currmaildir, cuser.userid);
  chkmail(1);

  showplans(xuser.userid);
  pressanykey();
  uinfo.destuid = 0;
  return 0;
}


int
t_cmpuids(uid, up)
  int uid;
  user_info *up;
{
  return (up->active && uid == up->uid);
}


int
t_talk()
{
  char uident[STRLEN];
  int tuid, unum, ucount;
  user_info uin;

  int sock, msgsock, length, ch;
  struct sockaddr_in server;
  char c;

  if (count_ulist() <= 1)
  {
    outs("�ثe�u�W�u���z�@�H�A���ܽЪB�ͨӥ��{�i" BOARDNAME "�j�a�I");
    return XEASY;
  }

  stand_title("���}�ܧX�l");
  creat_list();
  namecomplete(msg_uid, uident);
  if (uident[0] == '\0')
  {
    return 0;
  }

  move(3, 0);
  if (!(tuid = getuser(uident)) || tuid == usernum)
  {
    outs(err_uid);
    pressanykey();
    return 0;
  }

  /* ----------------- */
  /* multi-login check */
  /* ----------------- */

  unum = 1;
  while ((ucount = count_logins(&uin, t_cmpuids, tuid, 0)) > 1)
  {
    outs("(0) ���Q talk �F...\n");
    count_logins(&uin, t_cmpuids, tuid, 1);
    getdata(1, 33, "�п�ܤ@�Ӳ�ѹ�H [0]�G", genbuf, 4, DOECHO);
    unum = atoi(genbuf);
    if (unum == 0)
      return 0;
    move(3, 0);
    clrtobot();
    if (unum > 0 && unum <= ucount)
      break;
  }

  search_ulistn(&uin, t_cmpuids, tuid, unum);

  if (!HAS_PERM(PERM_SYSOP))
  {
    if (uin.pager == NA && !can_override(uin.userid, cuser.userid))
    {
      outs("��������I�s���F");
      pressanykey();
      return -1;
    }
  }

  if (uin.mode == POSTING || uin.mode == SMAIL || uin.mode == TALK)
  {
    outs("���L�v���");
    pressanykey();
    return -1;
  }

  if (!uin.active || (kill(uin.pid, 0) == -1))
  {
    outs(msg_usr_left);
    pressanykey();
    return -1;
  }

  showplans(uident);
  getdata(2, 0, "�T�w�n�M�L/�o�ͤѶ�?(Y/N) [N]: ", genbuf, 4, DOECHO);
  if (*genbuf != 'y' && *genbuf != 'Y')
  {
    return 0;
  }

#ifdef	HAVE_REPORT
  sprintf(genbuf, "�P'%s'���", uident);
  report(genbuf);
#endif

  sock = socket(AF_INET, SOCK_STREAM, 0);
  if (sock < 0)
  {
    perror("sock err");
    return -1;
  }

  server.sin_family = PF_INET;
  server.sin_addr.s_addr = INADDR_ANY;
  server.sin_port = 0;
  if (bind(sock, (struct sockaddr *) & server, sizeof server) < 0)
  {
    close(sock);
    perror("bind err");
    return -1;
  }
  length = sizeof server;
  if (getsockname(sock, (struct sockaddr *) & server, &length) < 0)
  {
    close(sock);
    perror("sock name err");
    return -1;
  }
  uinfo.sockactive = YEA;
  uinfo.sockaddr = server.sin_port;
  uinfo.destuid = tuid;
  modify_user_mode(PAGE);
  kill(uin.pid, SIGUSR1);
  clear();
  prints("���I�s %s.....\n��J Ctrl-D ����....", uident);

  listen(sock, 1);
  add_io(sock, 20);
  while (1)
  {
    ch = igetch();
    if (ch == I_TIMEOUT)
    {

#ifdef LINUX
      add_io(sock, 20);		/* added 4 linux... achen */
#endif

      move(0, 0);
      outs("�A");
      bell();
      if (kill(uin.pid, SIGUSR1) == -1)
      {

#ifdef LINUX
	add_io(sock, 20);	/* added 4 linux... achen */
#endif

	move(0, 0);
	outs(msg_usr_left);
	pressanykey();
	return -1;
      }
      continue;
    }
    if (ch == I_OTHERDATA)
      break;
    if (ch == '\004')
    {
      add_io(0, 0);
      close(sock);
      uinfo.sockactive = uinfo.destuid = 0;
      return 0;
    }
  }

  msgsock = accept(sock, (struct sockaddr *) 0, (int *) 0);
  if (msgsock == -1)
  {
    perror("accept");
    return -1;
  }
  add_io(0, 0);
  close(sock);
  uinfo.sockactive = NA;
  /* uinfo.destuid = 0 ; */
  read(msgsock, &c, sizeof c);

  if (c == 'y')
  {
    sprintf(save_page_requestor, "%s (%s)", uin.userid, uin.username);
    do_talk(msgsock);
  }
  else
  {
    move(9, 9);
    outs("�i�^���j ");
    switch (c)
    {
    case 'a':
      outs("�ڲ{�b�ܦ��A�е��@�|��A call ��, �n��?");
      break;
    case 'b':
      outs("�藍�_�A�ڦ��Ʊ������A talk....");
      break;
    case 'd':
      outs("�A�u���ܷСA�ڹ�b���Q��A talk....");
      break;
    case 'c':
      outs("�Ф��n�n�ڦn�ܡH");
      break;
    default:
      outs("�ڲ{�b���Q talk ��.....:)");
    }
    pressanykey();
  }
  close(msgsock);
  uinfo.destuid = 0;

  return 0;
}


extern int talkrequest;
struct user_info ui;
char page_requestor[44];
char page_requestorid[IDLEN + 2];


int
cmpunums(unum, up)
  int unum;
  user_info *up;
{
  if (up->active)
    return (unum == up->destuid);
  return 0;
}


int
setpagerequest()
{
  int tuid;

  tuid = search_ulist(&ui, cmpunums, usernum);
  if (tuid == 0)
    return 1;
  if (!ui.sockactive)
    return 1;
  uinfo.destuid = ui.uid;
  sprintf(page_requestor, "%s (%s)", ui.userid, ui.username);
  strcpy(page_requestorid, ui.userid);
  return 0;
}


int
servicepage(line, msg)
  int line;
  char *msg;
{
  static time_t last_check;
  time_t now;
  char buf[STRLEN];
  int tuid = search_ulist(&ui, cmpunums, usernum);

  if (tuid == 0 || !ui.sockactive)
    talkrequest = NA;
  if (!talkrequest)
  {
    if (page_requestor[0])
    {
      if (uinfo.mode == TALK)
      {
	move(line, 0);
	printdash(msg);
      }
      else
      {				/* a chat mode */
	sprintf(buf, "�� %s �w����I�s", page_requestor);
	printchatline(buf);
      }
      memset(page_requestor, 0, 44);
      last_check = 0;
    }
    return NA;
  }
  else
  {
    now = time(0);
    if (now - last_check > P_INT)
    {
      last_check = now;
      if (!page_requestor[0] && setpagerequest())
	return NA;
      else
      {
	sprintf(buf, "�� %s ���b�I�s�z", page_requestor);
	if (uinfo.mode == TALK)
	{
	  move(line, 0);
	  clrtoeol();
	  printdash(buf);
	}
	else			/* chat */
	  printchatline(buf);
      }
    }
  }
  return YEA;
}


void
talkreply()
{
  int a;
  struct hostent *h;
  char hostname[STRLEN], buf[4];
  struct sockaddr_in sin;
  int i;

  talkrequest = NA;
  if (setpagerequest())
    return;

  uinfo.mode = XINFO;		/* �קK�X�{�ʵe */

  clear();
  move(2, 0);
  outs("\
       (Y) ���ڭ� talk �a�I     (A) �ڲ{�b�ܦ��A�е��@�|��A call ��\n\
       (N) �ڲ{�b���Q talk      (B) �藍�_�A�ڦ��Ʊ������A talk\n\
       (C) �Ф��n�n�ڦn�ܡH     (D) �A�u���ܷСA�ڹ�b���Q��A talk\n\n");

  getuser(page_requestorid);
  prints("���Ӧ� [%s]�A�@�W�� %d ���A�峹 %d �g\n",
    ui.from, xuser.numlogins, xuser.numposts);
  showplans(page_requestorid);
  sprintf(genbuf, "�A�Q�� %s ���Ѷ�? �п��(Y/N/A/B/C/D) [Y]: ", page_requestor);
  getdata(0, 0, genbuf, buf, 4, DOECHO);

  strcpy(save_page_requestor, page_requestor);
  memset(page_requestor, 0, sizeof(page_requestor));
  memset(page_requestorid, 0, sizeof(page_requestorid));
  gethostname(hostname, STRLEN);

  if (!(h = gethostbyname(hostname)))
  {
    perror("gethostbyname");
    return;
  }
  memset(&sin, 0, sizeof sin);
  sin.sin_family = h->h_addrtype;
  memcpy(&sin.sin_addr, h->h_addr, h->h_length);
  sin.sin_port = ui.sockaddr;
  a = socket(sin.sin_family, SOCK_STREAM, 0);
  if ((connect(a, (struct sockaddr *) & sin, sizeof sin)))
  {
    perror("connect err");
    return;
  }
  if (!strchr("abcdn", buf[0] |= 0x20))
    buf[0] = 'y';
  write(a, buf, 1);
  if (buf[0] == 'y')
  {
    do_talk(a);
  }

#ifdef LINUX
  else
  {
    talkrequest = NA;		/* added 4 linux by achen.... */
  }
#endif

  close(a);
  clear();
}


int
dotalkent(uentp, buf)
  struct user_info *uentp;
  char *buf;
{
  char mch;

  if (!uentp->active || !uentp->pid)
    return -1;
  if (!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
    return -1;
  switch (uentp->mode)
  {
  case CLASS:
    mch = 'G';
    break;
  case TALK:
    mch = 'T';
    break;
  case CHATING:
    mch = 'C';
    break;

#if 0
  case IRCCHAT:
    mch = 'I';
    break;
  case FOURM:
    mch = '4';
    break;
  case BBSNET:
    mch = 'B';
    break;
#endif

  case READNEW:
  case READING:
    mch = 'R';
    break;
  case POSTING:
    mch = 'P';
    break;
  case SMAIL:
  case RMAIL:
  case MAIL:
    mch = 'M';
    break;
  default:
    mch = '-';
  }
  sprintf(buf, "%s%s(%c), ", uentp->invisible ? "*" : "", uentp->userid, mch);
  return 0;
}


int
dotalkuent(uentp)
  struct user_info *uentp;
{
  char buf[STRLEN];

  if (dotalkent(uentp, buf) != -1)
  {
    strcpy(talk_uent_buf, buf);
    talk_uent_buf += strlen(buf);
  }
  return 0;
}


void
do_talk_nextline(twin)
  struct talk_win *twin;
{
  int curln;

  curln = twin->curln + 1;
  if (curln > twin->eline)
    curln = twin->sline;
  if (curln != twin->eline)
  {
    move(curln + 1, 0);
    clrtoeol();
  }
  move(curln, 0);
  clrtoeol();
  twin->curcol = 0;
  twin->curln = curln;
}


void
do_talk_char(twin, ch)
  struct talk_win *twin;
  int ch;
{
  extern int dumb_term;

  if (isprint2(ch))
  {
    if (twin->curcol < 79)
      move(twin->curln, twin->curcol);
    else
      do_talk_nextline(twin);
    outc(ch);
    (twin->curcol)++;
    return;
  }
  switch (ch)
  {
  case Ctrl('H'):
  case '\177':
    if (dumb_term)
      ochar(Ctrl('H'));
    if (twin->curcol == 0)
    {
      return;
    }
    (twin->curcol)--;
    move(twin->curln, twin->curcol);
    if (!dumb_term)
      outc(' ');
    move(twin->curln, twin->curcol);
    return;
  case Ctrl('M'):
  case Ctrl('J'):
    if (dumb_term)
      outc('\n');
    do_talk_nextline(twin);
    return;
  case Ctrl('G'):
    bell();
  }
  return;
}


void
do_talk_string(twin, str)
  struct talk_win *twin;
  char *str;
{
  while (*str)
  {
    do_talk_char(twin, *str++);
  }
}


void
dotalkuserlist(twin)
  struct talk_win *twin;
{
  char bigbuf[MAXACTIVE * 20];
  int savecolumns;

  do_talk_string(twin, "\n*** �W�u���� ***\n");
  savecolumns = (t_columns > STRLEN ? t_columns : 0);
  talk_uent_buf = bigbuf;
  if (apply_ulist(dotalkuent) == -1)
  {
    strcpy(bigbuf, "�S������ϥΪ̤W�u\n");
  }
  strcpy(talk_uent_buf, "\n");
  do_talk_string(twin, bigbuf);
  if (savecolumns)
    t_columns = savecolumns;
}


do_talk(fd)
  int fd;
{
  struct talk_win mywin, itswin;
  char mid_line[128], data[80];
  int page_pending = NA;
  int i, ch, datac;

  modify_user_mode(TALK);

  sprintf(genbuf, "%s�i%s�j�� %s",
    cuser.userid, cuser.username, save_page_requestor);
  i = 33 - (strlen(genbuf) >> 1);
  memset(data, ' ', 31);
  data[i] = '\0';
  sprintf(mid_line, "[46;1m  �ͤѻ��a  [45m%s%s%s[0m",
    data, genbuf, data);

  memset(&mywin, 0, sizeof(mywin));
  memset(&itswin, 0, sizeof(itswin));
  i = b_lines >> 1;
  mywin.eline = i - 1;
  itswin.curln = itswin.sline = i + 1;
  itswin.eline = b_lines;

  clear();
  move(i, 0);
  outs(mid_line);
  move(0, 0);

  add_io(fd, 0);

  while (1)
  {
    ch = igetch();

    if (talkrequest)
      page_pending = YEA;
    if (page_pending)
    {
      page_pending = servicepage(b_lines >> 1, mid_line);
      move(mywin.curln, mywin.curcol);
    }

    if (ch == '')
    {
      igetch();
      igetch();
      continue;
    }
    if (ch == I_OTHERDATA)
    {
      datac = recv(fd, data, 80, 0);
      if (datac <= 0)
	break;
      for (i = 0; i < datac; i++)
	do_talk_char(&itswin, data[i]);
    }
    else
    {
      if (ch == Ctrl('D') || ch == Ctrl('C'))
	break;
      if (isprint2(ch) || ch == Ctrl('H') || ch == '\177'
	|| ch == Ctrl('G') || ch == Ctrl('M'))
      {
	data[0] = (char) ch;
	if (send(fd, data, 1, 0) != 1)
	  break;
	do_talk_char(&mywin, ch);
      }
      else if (ch == Ctrl('U') || ch == Ctrl('W'))
      {
	dotalkuserlist(&mywin);
      }
      else if (ch == Ctrl('P') && HAS_PERM(PERM_BASIC))
      {
	if (uinfo.pager)
	{
	  do_talk_string(&mywin, "�� �����I�s��\n");
	  uinfo.pager = NA;
	}
	else
	{
	  do_talk_string(&mywin, "�� ���}�I�s��\n");
	  uinfo.pager = YEA;
	}
	update_utmp();
      }
    }
  }
  add_io(0, 0);
  modify_user_mode(XINFO);
}


int
shortulist(uentp)
  struct user_info *uentp;
{
  static int lineno, fullactive, linecnt;
  static int moreactive, page, num;
  char uentry[50];
  int state;

  if (!lineno)
  {
    lineno = 3;
    page = moreactive ? (page + p_lines * 3) : 0;
    linecnt = num = moreactive = 0;
    move(1, 70);
    prints("Page: %d", page / (p_lines) / 3 + 1);
    move(lineno, 0);
  }

  if (uentp == NULL)
  {
    int finaltally;

    clrtoeol();
    move(++lineno, 0);
    clrtobot();
    finaltally = fullactive;
    lineno = fullactive = 0;
    return finaltally;
  }
  if (!uentp->active || !uentp->pid ||
    (!HAS_PERM(PERM_SEECLOAK) && uentp->invisible))
  {
    if (lineno >= b_lines)
      return 0;
    if (num++ < page)
      return 0;
    memset(uentry, ' ', 25);
    uentry[25] = '\0';
  }
  else
  {
    fullactive++;
    if (lineno >= b_lines)
    {
      moreactive = 1;
      return 0;
    }
    if (num++ < page)
      return 0;

    state = is_friend(uentp->userid);

    sprintf(uentry, "%s %-13s%c%-10s%s", fcolor[state],
      uentp->userid, uentp->invisible ? '#' : ' ',
      modestring(uentp->mode, uentp->destuid, 0, NULL),
      state ? "[37;0m" : "");
  }
  if (++linecnt < 3)
  {
    strcat(uentry, "�x");
    outs(uentry);
  }
  else
  {
    outs(uentry);
    linecnt = 0;
    clrtoeol();
    move(++lineno, 0);
  }
  return 0;
}


void
do_list(modestr)
  char *modestr;
{
  int count;

  showtitle(modestr, BoardName);
  if (uinfo.mode == MONITOR)
    prints("�C�j %d ����s�@���A�Ы�[Ctrl-C]��[Ctrl-D]���}", M_INT);

  outc('\n');
  outs(msg_shortulist);

  friends_number = override_number = 0;
  if (apply_ulist(shortulist) == -1)
  {
    outs(msg_nobody);
  }
  else
  {
    time_t thetime = time(NULL);
    count = shortulist(NULL);
    move(b_lines, 0);
    prints("[1;37;46m  �W���`�H�ơG%-7d[32m�ڪ��B�͡G%-6d"
      "[33m�P�ڬ��͡G%-8d[30m%-23s[37;40;0m",
      count, friends_number, override_number, Cdate(&thetime));
    refresh();
  }
}


int
t_list()
{

#ifdef	HAVE_REPORT
  report("�C�X�u�W�ϥΪ�");
#endif

  modify_user_mode(LUSERS);
  do_list("�ϥΪ̪��A");
  igetch();			/* pressanykey(); */
  return 0;
}


/* ------------------------------------- */
/* �ʬݨϥα���				 */
/* ------------------------------------- */

int idle_monitor_time;

void
sig_catcher()
{
  if (uinfo.mode != MONITOR)
  {

#ifdef DOTIMEOUT
    init_alarm();
#else
    signal(SIGALRM, SIG_IGN);
#endif

    return;
  }
  if (signal(SIGALRM, sig_catcher) == SIG_ERR)
  {
    perror("signal");
    exit(1);
  }

#ifdef DOTIMEOUT
  idle_monitor_time += M_INT;
  if (idle_monitor_time > MONITOR_TIMEOUT)
  {
    clear();
    fprintf(stderr, "timeout\n");
    kill(getpid(), SIGHUP);
  }
#endif

  do_list("�l�ܯ���");
  alarm(M_INT);
}


int
t_monitor()
{
  char c;
  int i;

  modify_user_mode(MONITOR);
  alarm(0);
  signal(SIGALRM, sig_catcher);
  idle_monitor_time = 0;

  do_list("�l�ܯ���");
  alarm(M_INT);
  while (YEA)
  {
    i = read(0, &c, 1);
    if (!i || c == Ctrl('D') || c == Ctrl('C'))
      break;
    else if (i == -1)
    {
      if (errno != EINTR)
      {
	perror("read");
	exit(1);
      }
    }
    else
      idle_monitor_time = 0;
  }
  return 0;
}


int
can_override(userid, whoasks)
  char *userid;
  char *whoasks;
{
  char buf[STRLEN];

  sethomefile(buf, userid, str_overrides);
  return belong(buf, whoasks);
}


int
listfriends()
{
  FILE *fp;
  int x, y, cnt, max, len;
  char u_buf[20], line[STRLEN], *nick;

  move(2, 0);
  clrtobot();
  move(3, 0);
  y = 3;
  x = cnt = max = 0;
  CreateNameList();
  setuserfile(genbuf, str_overrides);
  if ((fp = fopen(genbuf, "r")) == NULL)
  {
    outs(msg_no_override);
    return 0;
  }
  while (fgets(genbuf, STRLEN, fp))
  {
    strtok(genbuf, " \n\r\t");
    strcpy(u_buf, genbuf);
    AddNameList(u_buf);
    nick = (char *) strtok(NULL, "\n\r\t");
    if (nick)
    {
      while (*nick == ' ')
	nick++;
      if (*nick == '\0')
	nick = NULL;
    }
    if (nick == NULL)
      strcpy(line, u_buf);
    else
      sprintf(line, "%-12s%s", u_buf, nick);

    if ((len = strlen(line)) > max)
      max = len;
    if (x + len > 78)
      line[78 - x] = '\0';
    outs(line);
    cnt++;
    if ((++y) >= b_lines)
    {
      y = 3;
      x += max + 2;
      max = 0;
      if (x > 70)
	break;
    }
    move(y, x);
  }
  fclose(fp);
  if (cnt == 0)
    outs("�֨�" BOARDNAME "��B�ͧa�I");
  return cnt;
}


int
addtooverride(uident)
  char *uident;
{
  FILE *fp;
  int rc;
  char buf[40];

  if (can_override(cuser.userid, uident))
    return -1;
  getdata(2, 0, "�ͽ˴y�z: ", buf, 40, DOECHO);
  setuserfile(genbuf, str_overrides);
  if ((fp = fopen(genbuf, "a")) == NULL)
    return -1;
  flock(fileno(fp), LOCK_EX);
  rc = fprintf(fp, "%-12s %s\n", uident, buf);
  flock(fileno(fp), LOCK_UN);
  fclose(fp);
  return (rc == EOF ? -1 : 0);
}


int
deleteoverride(uident)
  char *uident;
{
  FILE *fp, *nfp;
  int deleted = NA;
  char fn[STRLEN], fnnew[STRLEN];

  setuserfile(fn, str_overrides);
  if ((fp = fopen(fn, "r")) == NULL)
    return -1;
  sprintf(fnnew, "%s.%d", fn, getuid());
  if ((nfp = fopen(fnnew, "w")) == NULL)
    return -1;
  while (fgets(genbuf, STRLEN, fp))
  {
    if (strncmp(genbuf, uident, strlen(uident)) && *genbuf > ' ')
      fputs(genbuf, nfp);
    else
      deleted = YEA;
  }
  fclose(fp);
  fclose(nfp);
  if (!deleted)
  {
    unlink(fnnew);
    return -1;
  }
  return (rename(fnnew, fn));
}


void
friend_load()
{
  FILE *fp;

  memset(myfriends, 0, sizeof(myfriends));
  friendcount = 0;
  setuserfile(genbuf, str_overrides);
  if (fp = fopen(genbuf, "r"))
  {
    ushort unum;
    while (fgets(genbuf, STRLEN, fp) && friendcount < MAX_FRIEND - 1)
    {
      if (strtok(genbuf, " \n\r\t"))
      {
	if (unum = searchuser(genbuf))
	{
	  myfriends[friendcount++] = unum;
	}
      }
    }
    fclose(fp);
  }
}


int
t_override()
{
  char uident[20];
  int count;

  stand_title("�s��n�ͦW��");

  while (1)
  {
    count = listfriends();
    getdata(1, 0, (count ? "(A)�W�[�n�� (D)�R���n�� (E)���}? [E]: " :
	"(A)�W�[�n�� (E)���}? [E]: "), uident, 4, DOECHO);
    if (*uident == 'a' || *uident == 'A')
    {
      move(1, 0);
      usercomplete("�W�[���n�ͩm�W: ", uident);
      if (uident[0] && searchuser(uident) && !InNameList(uident))
	addtooverride(uident);
    }
    else if ((*uident == 'D' || *uident == 'd') && count)
    {
      move(1, 0);
      namecomplete("�R�����l�ͩm�W: ", uident);
      if (uident[0] && InNameList(uident))
	deleteoverride(uident);
    }
    else
      break;
  }
  friend_load();
  return 0;
}


int
t_friends()
{
  time_t thetime = time(0);
  int count;

  modify_user_mode(FRIEND);

  if (friendcount)
  {
    friends_number = override_number = 0;

    printcuent(NULL);
    if (apply_ulist(printcuent) == -1)
      outs(msg_nobody);
    else
      clrtobot();

    if (friends_number == 0 && override_number == 0)
      outs("�A���@�U�a�A�]�\\�L�̫ݷ|��N�W�u�F�C");
  }
  else
  {
    outs("�ثe�٨S�]�w�n�ͦW��");
  }

  move(b_lines, 0);
  prints("[1;32;46m  �ڪ��B�͡G%-6d[33m�P�ڬ��͡G%-5d[45m  "
    "��[E]�s��n�ͦW��  [46;30m  %-23s[m",
    friends_number, override_number, Cdate(&thetime));

  count = igetch();
  if (count == 'e' || count == 'E')
    t_override();

  return 0;
}


int
t_kick()
{
  int id, ind;
  struct user_info uin;
  char kickuser[16];

  stand_title("��H");
  creat_list();
  namecomplete(msg_uid, kickuser);

  if (*kickuser == '\0')
  {
    return 0;
  }
  if (!(id = getuser(kickuser)))
  {
    move(3, 0);
    outs(err_uid);
    clrtoeol();
    pressanykey();
    return 0;
  }

  getdata(2, 0, msg_sure_ny, genbuf, 2, DOECHO);
  clrtoeol();
  if (genbuf[0] != 'Y' && genbuf[0] != 'y')
  {
    outs(msg_cancel);
    pressanykey();
    return 0;
  }

  ind = search_ulist(&uin, t_cmpuids, id);
  if (!ind || !uin.active || (kill(uin.pid, 0) == -1))
  {
    outs(msg_usr_left);
    pressanykey();
    return 0;
  }
  kill(uin.pid, 9);

  sprintf(genbuf, "%s (%s)", uin.userid, uin.username);
  log_usies("KICK ", genbuf);

  uin.invisible = YEA;
  uin.active = uin.pid = uin.sockactive = uin.sockaddr = uin.destuid = 0;
  update_ulist(&uin, ind);
  outs("��X�h�o");
  pressanykey();
  return 0;
}


#ifdef HAVE_GAME
t_game()			/* Bill Schwartz */
{
  int save_pager = uinfo.pager;
  uinfo.pager = NA;

#ifdef	HAVE_REPORT
  report("MJ-Game Enter");
#endif

  modify_user_mode(BBSNET);
  /* bbsnet.sh is a shell script that can be customized without */
  /* having to recompile anything.  If you edit it while someone */
  /* is in bbsnet they will be sent back to the xyz menu when they */
  /* leave the system they are currently in. */

  reset_tty();
  do_exec("game.sh", NULL);
  restore_tty();
  uinfo.pager = save_pager;
  report("BBSNet Exit");
  clear();
}
#endif				/* HAVE_GAME */


#ifdef HAVE_EXEC
exec_cmd(umode, pager, cmdfile, mesg)
  char *cmdfile, *mesg;
{
  char buf[64];
  int save_pager;

  if (!dashf(cmdfile))
  {
    move(2, 0);
    prints("�ܩ�p, ���������� %s (%s) �\\��.", mesg, cmdfile);
    return;
  }
  save_pager = uinfo.pager;
  if (pager == NA)
  {
    uinfo.pager = pager;
  }
  modify_user_mode(umode);
  sprintf(buf, "/bin/sh %s", cmdfile);
  reset_tty();
  do_exec(buf, NULL);
  restore_tty();
  uinfo.pager = save_pager;
  clear();
}
#endif


#ifdef IRC
t_irc()
{
  exec_cmd(IRCCHAT, NA, "bin/irc.sh", "IRC");
}
#endif				/* IRC */


#ifdef HAVE_TIN
t_tin()
{
  exec_cmd(CSIE_TIN, YEA, "bin/tin.sh", "TIN");
}
#endif

#ifdef HAVE_GOPHER
t_gopher()
{
  exec_cmd(CSIE_GOPHER, YEA, "bin/gopher.sh", "GOPHER");
}
#endif
