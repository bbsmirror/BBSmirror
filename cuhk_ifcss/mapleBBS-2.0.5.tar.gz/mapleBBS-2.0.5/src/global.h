/*
 * global.h
 */

#ifndef	_GLOBAL_H_
#define	_GLOBAL_H_


/* -------------------------------------------------------------- */
/* GLOBAL DEFINITION						  */
/* -------------------------------------------------------------- */

#define	MAXFNLEN	40	/* filename length */
#define QUIT	0x666		/* Return value to abort recursive functions */
#define XEASY	0x333		/* Return value to un-redraw screen */


/* �ɦW�]�w */

#define IDENTFILE	"etc/preach"
#define EMAILFILE	"etc/emailpost"
#define	PASSFILE	".PASSWDS"	/* User records */
#define ULIST		".UTMP"		/* stote utmp for active user */
#define BOARDS		".BOARDS"	/* File containing list of boards */
#define DOT_DIR		"/.DIR"		/* Directory info */
#define NAMEFILE	"BoardName"	/* File containing site name of bbs */


/* �ù��]�w */

#define str_cursor	"��"
#define str_uncur	"  "
#define SCREEN_SIZE	23	/* Used by read menu  */



/* ��L�]�w */

#ifndef EXTEND_KEY
#define EXTEND_KEY
#define KEY_TAB		9
#define KEY_ESC		27
#define KEY_UP		0x0101
#define KEY_DOWN	0x0102
#define KEY_RIGHT	0x0103
#define KEY_LEFT	0x0104
#define KEY_HOME	0x0201
#define KEY_INS		0x0202
#define KEY_DEL		0x0203
#define KEY_END		0x0204
#define KEY_PGUP	0x0205
#define KEY_PGDN	0x0206
#endif

#define Ctrl(c)		( c & 037 )

#ifdef SYSV
#undef CTRL			/* SVR4 CTRL macro is hokey */
#define CTRL(c) ('c'&037)	/* This gives ESIX a warning...ignore it! */
#endif


#define chartoupper(c)  ((c >= 'a' && c <= 'z') ? c+'A'-'a' : c)
#define char_lower(c)  ((c >= 'A' && c <= 'Z') ? c|32 : c)


/* -------------------------------------------------------------- */
/* External function declarations				  */
/* -------------------------------------------------------------- */

char *strdup();
char *bfile();
void pressanykey();
void showtitle();
void show_help();
void modify_user_mode();
void showplans();
void user_display();
void log_usies();
void stampfile();
void talkreply();
void uinfo_query();
void touch_boards();
void namecomplete();
void usercomplete();

#define	TRACE	log_usies
#define update_utmp()	update_ulist(&uinfo, utmpent);



#ifdef	_BBS_C_
/* -------------------------------------------------------------- */
/* GLOBAL VARIABLE						  */
/* -------------------------------------------------------------- */


FILE *ufp;
char genbuf[1024];
char quote_file[256] = "\0";
char quote_user[256] = "\0";
char related_title[50] = "\0";
char currfile[FNLEN];		/* current file name @ bbs.c mail.c */
char currboard[IDLEN + 2];
char currBM[IDLEN*3 + 10];
char reset_color[11] = "[40;37;0m";

/* GLOBAL MESSAGE */


char *msg_seperator = "\
�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w";

char *msg_mailer =
"[46;33;1m  �E������  [45m  (R)[36m�^�H  [33m(x)[36m��F  [33m(y)[36m�s�զ^�H  [33m(D)[36m�R��  [33m[G][36m�~�� ? [m";

char *msg_select =
"[1;46;33m �峹��Ū [45m (^R)[36m�^�H [33m(=[])[36m�����H�� [33m(/?)[36m�j�M���D [33m(aA)[36m�j�M�@�� [33m(x)[36m��� [33m(V)[36m�벼 [m";

char *msg_usrlist =
"[7m  �ϥΪ̥N��   %-25s   �W��  �峹 %4s   �̪���{���     [m\n";

char *msg_select_board =
"[1;45m ��ܰQ�װ� [m\n�п�J�ݪO�W��(���ť���۰ʷj�M):";

char *msg_shortulist = "[7m\
 �ϥΪ̥N��    �ثe���A  �x �ϥΪ̥N��    �ثe���A  �x �ϥΪ̥N��    �ثe���A [m";



char *msg_cancel = "����";
char *msg_working = "�B�z���A�еy��...";
char *msg_usr_left = "User �w�g���}�F";
char *msg_nobody = "�ثe�L�H�W�u";
char *msg_no_override = "�|���]�w�n�ͦW��";
char *msg_cloaked = "�����I�����ΰ_�ӤF";
char *msg_uncloak = "�ڭn���{����F....";

char *msg_delete_ok = "�R������";
char *msg_delete_cancel = "�����R��";
char *msg_delete_error = "�R�����~";
char *msg_delete_ny = "�нT�w�R��(Y/N) [N] ";

char *msg_fwd_ok = "�峹��H����!";
char *msg_fwd_err1 = "��H���~: system error";
char *msg_fwd_err2 = "��H���~: address error";

char *msg_sure_ny = "�бz�T�w(Y/N)? [N] ";
char *msg_sure_yn = "�бz�T�w(Y/N)? [Y] ";

char *err_board_open = ".BOARD �}�ҿ��~";
char *err_board_update = ".BOARD ��s���~";
char *err_passwd_open = ".PASSWDS �}�ҿ��~";
/* char *err_passwd_update = ".PASSWDS ��s���~"; */
char *err_bid = "���~���ݪO�W��";
char *err_uid = "���~���ϥΪ̥N��";
char *err_passwd = "�K�X��J���~";
char *err_filename = "�ɦW���X�k!";
char *msg_bid = "�п�J�ݪO�W�١G";
char *msg_uid = "�п�J�ϥΪ̥N���G";
char *ask_passwd = "�п�J�z���K�X: ";

char *str_vote_polling = "etc/lastpolling";
char *str_justify = "etc/justify";
char *str_note_ans = "note.ans";
char *str_day_issue = "etc/day";
char *str_plans = "plans";
char *str_overrides = "overrides";
char *str_notes = "notes";
char *str_mandex = "/.Names";

char *str_usies = "usies";
/*
#ifdef	WITHOUT_CHROOT
BBSHOME
#endif

"/usies";
*/


char *str_mail_address = ".bbs@" MYHOSTNAME;
char *str_guest = "guest";
char *str_new = "new";
char *str_reply = "Re: ";
char *str_def_board = DEFAULTBOARD;
char *str_passfile = PASSFILE;
char *str_boards = BOARDS;
char *BoardName = BOARDNAME;

#else				/* _BBS_C_ */


/* -------------------------------------------------------------- */
/* GLOBAL VARIABLE						  */
/* -------------------------------------------------------------- */


extern FILE *ufp;		/* External variable declarations */
extern char genbuf[1024];
extern char quote_file[256];
extern char quote_user[256];
extern char related_title[50];
extern char currfile[FNLEN];



/* GLOBAL MESSAGE */

extern char *msg_cancel;
extern char *msg_working;
extern char *msg_usr_left;
extern char *msg_nobody;
extern char *msg_no_override;
extern char *msg_cloaked;
extern char *msg_uncloak;

extern char *msg_sure_ny;
extern char *msg_sure_yn;

extern char *msg_seperator;
extern char *msg_mailer;
extern char *msg_select;
extern char *msg_usrlist;
extern char *msg_select_board;
extern char *msg_shortulist;

extern char *msg_delete_ok;
extern char *msg_delete_cancel;
extern char *msg_delete_error;
extern char *msg_delete_ny;

extern char *msg_fwd_ok;
extern char *msg_fwd_err1;
extern char *msg_fwd_err2;

extern char *err_board_open;
extern char *err_board_update;
extern char *err_passwd_open;
/* extern char *err_passwd_update; */
extern char *err_bid;
extern char *err_uid;
extern char *err_passwd;
extern char *err_filename;
extern char *msg_bid;
extern char *msg_uid;
extern char *ask_passwd;


extern char *str_vote_polling;
extern char *str_justify;
extern char *str_note_ans;
extern char *str_day_issue;
extern char *str_plans;
extern char *str_overrides;
extern char *str_notes;
extern char *str_mandex;
extern char *str_usies;
extern char *str_mail_address;
extern char *str_guest;
extern char *str_new;
extern char *str_reply;
extern char *str_def_board;
extern char *str_passfile;
extern char *str_ulist;
extern char *str_boards;
extern char *BoardName;


#ifdef XINU
extern int errno;
#endif

#endif				/* _BBS_C_ */


extern userec cuser;	/* current user structure */
extern userec xuser;	/* lookup user structure */

extern struct user_info uinfo;	/* Ditto above...utmp entry is stored here
				 * and written back to the utmp file when
				 * necessary (pretty darn often). */
extern int usernum;		/* Index into passwds file user record */
extern int utmpent;		/* Index into this users utmp file entry */

extern int t_lines, t_columns;	/* Screen size / width */
extern int b_lines;		/* Screen bottom line number: t_lines-1 */
extern int p_lines;		/* a Page of Screen line numbers: tlines-4 */

extern char currboard[];	/* name of currently selected board */
extern char currBM[];		/* BM of currently selected board */
extern char reset_color[];

extern int selboard;		/* THis flag is true if above is active */

extern jmp_buf byebye;		/* Used for exception condition like I/O
				 * error */

extern struct commands cmdlist[];
extern struct commands xyzlist[];
extern struct commands talklist[];
extern struct commands maillist[];
extern struct commands classlist[];
extern struct commands maintlist[];
extern struct commands userlist[];

extern char fromhost[];


extern char save_title[];	/* used by editor when inserting */
extern int in_mail;
extern int dumb_term;
#endif				/* _GLOBAL_H_ */
