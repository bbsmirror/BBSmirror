#include "bbs.h"


/* ------------------- */
/* password encryption */
/* ------------------- */

char *crypt();
static char pwbuf[14];

char *
genpasswd(pw)
  char *pw;
{
  if (pw[0])
  {
    char saltc[2], c;
    int i;

#ifndef lint
    i = 9 * getpid();
    saltc[0] = i & 077;
    saltc[1] = (i >> 6) & 077;
#endif

    for (i = 0; i < 2; i++)
    {
      c = saltc[i] + '.';
      if (c > '9')
	c += 7;
      if (c > 'Z')
	c += 6;
      saltc[i] = c;
    }
    strcpy(pwbuf, pw);
    return crypt(pwbuf, saltc);
  }
  return "";
}


int
checkpasswd(passwd, test)
  char *passwd, *test;
{
  char *pw;

  strncpy(pwbuf, test, 14);
  pw = crypt(pwbuf, passwd);
  return (!strcmp(pw, passwd));
}


int
simplepasswd(str, uid)
  char *str, *uid;
{
  char ch;

  if (strlen(str) > 3 && strcmp(str, uid))
  {
    while (ch = *str++)
    {
      if (!islower(ch))
	return 0;
    }
  }
  return 1;
}


/* ------------------ */
/* �ˬd user ���U���p */
/* ------------------ */

#define  NEWREGFILE     "etc/newuser"


int
bad_user_id(userid)
  char *userid;
{
  char ch;

  if (strlen(userid) < 2)
    return 1;

  if (!isalpha(*userid))
    return 1;

  if (!strcmp(userid, str_new))
    return 1;

  while (ch = *(++userid))
  {
    if (!isalnum(ch))
      return 1;
  }
  return 0;
}


/* -------------------------------- */
/* New policy for allocate new user */
/* (a) is the worst user currently  */
/* (b) is the object to be compared */
/* -------------------------------- */

time_t system_time;


int
compute_user_value(urec)
  struct userec *urec;
{
  int value;

  /* if (urec) has XEMPT permission, don't kick it */
  if (urec->userlevel & PERM_XEMPT)
    return 9999;

  value = (system_time - urec->lastlogin) / 60;	/* minutes */

  /* new user should register in 30 mins */
  if (strcmp(urec->userid, str_new) == 0)
    return (30 - value) * 60;

  if (urec->numlogins <= 3)	/* #login �֩�T�̡A�O�d 20 �� */
    return 20 * 24 * 60 - value;

  /* ���������U�̡A�O�d 60 �� */
  /* �@�뱡�p�A�O�d 90 �� */
  return (urec->userlevel & PERM_LOGINOK ? 90 : 60) * 24 * 60 - value;
}


int
getnewuserid()
{
  static char *cleanusr = "etc/cleanusr";
  extern struct UCACHE *uidshm;
  userec utmp, zerorec;
  struct stat st;
  int fd, val, i;

  memset(&zerorec, 0, sizeof(zerorec));

  /* -------------------------------------- */
  /* Lazy method : ����M�w�g�M�����L���b�� */
  /* -------------------------------------- */

  if ((i = searchnewuser(0)) == 0)
  {

    /* ------------------------------- */
    /* �C 1 �Ӥp�ɡA�M�z user �b���@�� */
    /* ------------------------------- */

    system_time = time(NULL);
    if (stat(cleanusr, &st) == -1 || st.st_mtime < system_time - 3600)
    {
      if ((fd = open(cleanusr, O_RDWR | O_CREAT, 0600)) == -1)
	return -1;
      write(fd, ctime(&system_time), 25);
      close(fd);
      log_usies("CLEAN", "dated users");

      printf("�M��s�b����, �еy�ݤ���...\n\r");
      if ((fd = open(str_passfile, O_RDWR | O_CREAT, 0600)) == -1)
	return -1;
      for (i = 0; i < MAXUSERS; i++)
      {
	if (read(fd, &utmp, sizeof(userec)) != sizeof(userec))
	  break;
	val = compute_user_value(&utmp);
	if (utmp.userid[0] && val < 0)
	{
	  sprintf(genbuf, "#%d %-12s %15.15s %d %d %d",
	    i + 1, utmp.userid, ctime(&(utmp.lastlogin)) + 4,
	    utmp.numlogins, utmp.numposts, val);
	  log_usies("KILL ", genbuf);
	  if (isalpha(utmp.userid[0]))
	  {
	    sprintf(genbuf, "/bin/rm -fr tmp/%s", utmp.userid);
	    system(genbuf);
	    sprintf(genbuf, "/bin/mv home/%s tmp", utmp.userid);
	    system(genbuf);
	  }
	  lseek(fd, -sizeof(userec), SEEK_CUR);
	  write(fd, &zerorec, sizeof(utmp));
	}
      }
      close(fd);
      time(&(uidshm->touchtime));
    }
  }
  if ((fd = open(str_passfile, O_RDWR | O_CREAT, 0600)) == -1)
    return -1;
  flock(fd, LOCK_EX);

  i = searchnewuser(1);
  sprintf(genbuf, "uid %d", i);
  log_usies("APPLY", genbuf);

  if (i <= 0 || i > MAXUSERS)
  {
    flock(fd, LOCK_UN);
    close(fd);
    if (more("etc/user_full", NA) == -1)
      printf("��p, �ϥΪ̱b���w�g���F, �L�k���U�s���b��\n\r");
    val = (st.st_mtime - system_time + 3660) / 60;
    printf("�е��� %d ������A�դ@��, ���A�n�B\n\r", val);
    sleep(2);
    exit(1);
  }

  strcpy(zerorec.userid, str_new);
  zerorec.lastlogin = time(NULL);
  if (lseek(fd, sizeof(zerorec) * (i - 1), SEEK_SET) == -1)
  {
    flock(fd, LOCK_UN);
    close(fd);
    return -1;
  }
  write(fd, &zerorec, sizeof(zerorec));
  setuserid(i, zerorec.userid);
  flock(fd, LOCK_UN);
  close(fd);
  return i;
}


void
new_register()
{
  userec newuser;
  char passbuf[STRLEN];
  int allocid, try;

#if 0
  time_t now;

  /* ------------------ */
  /* ���w�P���X������U */
  /* ------------------ */

  now = time(0);
  sprintf(genbuf, "etc/no_register_%3.3s", ctime(&now));
  if (more(genbuf, NA) != -1)
  {
    pressanykey();
    exit(1);
  }
#endif

  memset(&newuser, 0, sizeof(newuser));
  allocid = getnewuserid();
  if (allocid > MAXUSERS || allocid <= 0)
  {
    fprintf(stderr, "�����H�f�w�F���M�I\n");
    exit(1);
  }

  more("etc/register", NA);
  try = 0;
  while (1)
  {
    if (++try >= 6)
    {
      outs("\n�z���տ��~����J�Ӧh, �ФU���A�ӧa\n");
      refresh();
      longjmp(byebye, -1);
    }
    getdata(0, 0, msg_uid, newuser.userid, IDLEN + 1, DOECHO);

    if (bad_user_id(newuser.userid))
      outs("�L�k�����o�ӥN���A�Шϥέ^��r���A�åB���n�]�t�Ů�\n");
    else if (dosearchuser(newuser.userid))
      outs("���N���w�g���H�ϥ�\n");
    else
      break;
  }

  while (1)
  {
    getdata(0, 0, "�г]�w�K�X�G", passbuf, PASSLEN, NOECHO);
    if (simplepasswd(passbuf, newuser.userid))
    {
      outs("�K�X��²��A���D�J�I�A�ܤ֭n 4 �Ӧr�A�Э��s��J\n");
      continue;
    }
    strncpy(newuser.passwd, passbuf, PASSLEN);
    getdata(0, 0, "���ˬd�K�X�G", passbuf, PASSLEN, NOECHO);
    if (strncmp(passbuf, newuser.passwd, PASSLEN))
    {
      outs("�K�X��J���~, �Э��s��J�K�X.\n");
      continue;
    }
    passbuf[8] = '\0';
    strncpy(newuser.passwd, genpasswd(passbuf), PASSLEN);
    break;
  }

  getdata(0, 0, "�׺ݾ��κA [vt100]�G", newuser.termtype, 8, ECHO);
  if (newuser.termtype[0] == '\0')
    strcpy(newuser.termtype, "vt100");

  newuser.userlevel = PERM_DEFAULT;
  newuser.uflag = COLOR_FLAG | BRDSORT_FLAG;
  newuser.firstlogin = newuser.lastlogin = time(NULL);

  if (substitute_record(str_passfile, &newuser, sizeof(newuser), allocid) == -1)
  {
    fprintf(stderr, "�Ⱥ��F�A�A���I\n");
    exit(1);
  }
  setuserid(allocid, newuser.userid);
  if (!dosearchuser(newuser.userid))
  {
    fprintf(stderr, "�L�k�إ߱b��\n");
    exit(1);
  }

#ifdef	HAVE_REPORT
  report("new account");
#endif
}


void
check_register()
{
  stand_title("�иԲӶ�g�ӤH���");

  while (strlen(cuser.username) < 2)
    getdata(2, 0, "�︹�ʺ١G", cuser.username, 24, DOECHO);

  while (strlen(cuser.realname) < 4)
    getdata(4, 0, "�u��m�W�G", cuser.realname, 20, DOECHO);

  while (strlen(cuser.address) < 8)
    getdata(6, 0, "�p���a�}�G", cuser.address, 50, DOECHO);

  if (strchr(cuser.email, '@') == NULL)
  {
    mail_note();
    while (strchr(cuser.email, '@') == NULL)
      getdata(8, 0, "�q�l�H�c�G", cuser.email, 50, DOECHO);
    mail_justify();
  }

  cuser.userlevel |= PERM_DEFAULT;
  if (!HAS_PERM(PERM_SYSOP) && !(cuser.userlevel & PERM_LOGINOK))
  {
    /* �^�йL�����{�ҫH�� */

    setuserfile(genbuf, "justify");
    if (dashf(genbuf))
      cuser.userlevel |= PERM_LOGINOK;
    else
    {
      /* ���g E-mail post �L */

      setuserfile(genbuf, "email");
      if (dashf(genbuf))
	cuser.userlevel |= PERM_LOGINOK;

#ifdef	STRICT
      else
      {
	cuser.userlevel &= ~PERM_POST;
	more(str_justify, YEA);
      }
#endif

    }
  }

  if (cuser.lastlogin - cuser.firstlogin < 2 * 86400 && !HAS_PERM(PERM_SYSOP))
  {

#ifdef	STRICT
    cuser.userlevel &= ~PERM_POST;
#endif

    more(NEWREGFILE, YEA);
  }
}


#ifdef HAVE_SLOW_TYPE
slow_type(filename, delay_time)
  char *filename;
  int delay_time;
{
  char buf[255];
  int i;
  FILE *fp;

  fp = fopen(filename, "r");
  if (fp == NULL)
    return 0;

  while (fgets(buf, 255, fp) != NULL)
  {
    for (i = 0; i < strlen(buf); i++)
    {
      outc((char) buf[i]);
    }
    refresh();

#ifndef HP_UX
    if (delay_time)
      usleep(delay_time);
#endif
  }

  fclose(fp);
}
#endif
