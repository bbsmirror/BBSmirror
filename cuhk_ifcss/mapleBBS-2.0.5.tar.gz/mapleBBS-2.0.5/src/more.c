/* more.c */

#include "bbs.h"

int showansi = 1;


static char *more_help[] = {
  "\0�\\Ū�峹�\\����ϥλ���",
  "\01��в��ʥ\\����",
  "[��][Enter]         �U���@��",
  "[^B][PgUp]          �W���@��",
  "[��][PgDn][Space]   �U���@��",
  "[0] [Home]          �ɮ׶}�Y",
  "[$] [End]           �ɮ׵���",
  "\01��L�\\����",
  "[Q][��]             ����",
  "[h][H][?]           ���U�����e��",
NULL};


int
readln(fp, buf)
  FILE *fp;
  char *buf;
{
  register char ch;
  int len, bytes, in_esc, i;

  len = bytes = in_esc = i = 0;
  while ((ch = getc(fp)) != EOF && len < 80 && i < ANSILINELEN)
  {
    bytes++;
    if (ch == '\n')
    {
      break;
    }
    else if (ch == '\t')
    {
      do
      {
	buf[i++] = ' ';
      } while ((++len & 7) && len < 80);
    }
    else if (ch == '\033')
    {
      if (showansi)
	buf[i++] = ch;
      in_esc = 1;
    }
    else if (in_esc)
    {
      if (showansi)
	buf[i++] = ch;
      if (strchr("[0123456789;,", ch) == NULL)
      {
	in_esc = 0;
      }
    }
    else if (isprint2(ch))
    {
      len++;
      buf[i++] = ch;
    }
  }
  buf[i] = '\0';
  return bytes;
}


#define token1  "�o�H�H:"
#define token2  "�H��:"
#define token3  "��  �D:"
#define token4  "�o�H��:"
#define token5  "��H��:"
#define old1    "Posted By:"
#define old2    "on board"
#define old3    "Date:"
#define old4    "Title:    "
#define mail1   "From:     "
#define mail2   "Date:"
#define mail3   "Title:    "


int
more(filename, promptend)
  char *filename;
{
  static char *moretbl[4] = {"�@��", "���D", "�ӷ�", "���|"};
  static uschar offset[3] = {8, 11, 11};
  char moretype, tagline;

  struct stat st;
  FILE *fp;
  usint pagebreak[MAXPAGES], pageno, lino;
  char buf[256];
  int i, ch, viewed, pos, numbytes, tsize;

  if ((fp = fopen(filename, "r")) == NULL)
    return -1;

  if (fstat(fileno(fp), &st))
    return -1;

  tsize = st.st_size;
  pagebreak[0] = pageno = viewed = moretype = i = pos = 0;
  clear();

  while ((numbytes = readln(fp, buf)) || (i == t_lines))
  {
    if (numbytes)		/* �@���ƳB�z */
    {
      if (viewed == 0)		/* JhLin : begin of file */
      {
	lino = 0;
	if (strstr(buf, token1))/* type 1 */
	{
	  moretype = 0;
	  tagline = i = 4;
	}
	else if (strstr(buf, mail1))	/* type 3 */
	{
	  moretype = 2;
	  tagline = i = 3;
	}
	else if (strstr(buf, old1))	/* type 2 */
	{
	  moretype = 1;
	  tagline = i = 3;
	}

	while (pos < i)
	{
	  prints("[32;1m%s�G[37;0m%s\n",
	    (moretype && pos == 2 ? "�ɶ�" : moretbl[pos]),
	    buf + offset[moretype]);
	  viewed += numbytes;
	  numbytes = readln(fp, buf);
	  pos++;
	}
	lino = pos;
      }

      if (buf[0] == '�' && buf[1] == '�')	/* ���B�z�ޥΪ�ID���� */
	prints("[32m%s[0m\n", buf);
      else if (buf[0] == '>' || buf[0] == ':')	/* �B�z�ި����� */
	prints("[36m%s[0m\n", buf);
      else
	prints("%s\n", buf);

      if (i < b_lines)		/* �@����Ū�� */
	i++;

      if (pos == b_lines)	/* ���ʿù� */
	scroll();
      else
	pos++;

      if (++lino >= b_lines && pageno < MAXPAGES - 1)
      {
	pagebreak[++pageno] = viewed;
	lino = 1;
      }
      viewed += numbytes;	/* �֭pŪ�L��� */
    }
    else
    {				/* end of END */
      i = b_lines;
    }

    if (i == b_lines)
    {
      prints("[1;46;37m  �s�� P.%d(%d%%)  [45m  �D�U:[h]   [33m���:����[PgUp][PgDn][Home][End][37m   ����:��[q]  [0m", pageno, (viewed * 100) / tsize);
      while (i == b_lines)
      {
	switch (ch = egetch())
	{
	case 'q':
	case KEY_LEFT:
	case EOF:
	  fclose(fp);
	  return 0;

	case ' ':
	case KEY_PGDN:
	case KEY_RIGHT:
	  i = 1;
	  break;

	case '\r':
	case '\n':
	case KEY_DOWN:
	  i = t_lines - 2;
	  break;

	case '$':
	case KEY_END:
	  i = t_lines;
	  break;

	case '0':
	case KEY_HOME:
	  pageno = 0;
	  moretype = -1;
	  break;

	case 'h':
	case 'H':
	case '?':
	  show_help(more_help);
	  pageno--;
	  moretype = -1;
	  break;

	case KEY_PGUP:
	case Ctrl('B'):
	  if (pageno > 1)
	  {
	    pageno -= 2;
	    moretype = -1;
	  }
	  break;
	}

	if (moretype < 0)
	{
	  i = pos = 0;
	  fseek(fp, viewed = pagebreak[pageno], SEEK_SET);
	  clear();
	}
      }

      if (moretype >= 0)
      {
	move(b_lines, 0);
	clrtoeol();
	refresh();
      }
      moretype = 0;
    }
  }

  fclose(fp);
  if (promptend)
  {
    pressanykey();
    clear();
  }
  return 0;
}
