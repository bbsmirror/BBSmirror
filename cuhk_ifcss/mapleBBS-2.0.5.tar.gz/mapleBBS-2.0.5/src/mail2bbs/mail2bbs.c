/*
 * mail2bbs.c - �� InterNet �H�H�� BBS user �� mailbox
 * 
 * install -g bbs -o root -m 4750 mail2bbs /bin
 */

#define _BBS_UTIL_C_
#include "../record.c"

#define MYPASSFILE ".PASSWDS"
#define DOMAIN_NAME "bbs.cs.nthu.edu.tw"
#define BBSHOME		"/home/bbs"
#define BBSGID		99
#define BBSUID		9999

char *MAILDIR = "home/";

cmpuids(uid, up)
  char *uid;
  struct userec *up;
{
  if (!strncasecmp(uid, up->userid, sizeof(up->userid)))
  {
    strncpy(uid, up->userid, sizeof(up->userid));
    return 1;
  }
  else
  {
    return 0;
  }
}

int
dosearchuser(userid)
  char *userid;
{
  userec auser;
  return search_record(MYPASSFILE, &auser, sizeof(userec), cmpuids, userid);
}

append_mail(fin, sender, userid, title)
  FILE *fin;
  char *userid, *sender, *title;
{
  struct fileheader newmessage;

  char fname[80], genbuf[256];
  FILE *fout;
  struct stat st;
  time_t t;
  struct tm *ptime;

  /* check if the userid is in our bbs now */
  if (!dosearchuser(userid))
    return -1;

  /* check for the mail dir for the userid */
  sprintf(fname, "%s%s", MAILDIR, userid);

  if (stat(fname, &st) == -1)
  {
    if (mkdir(fname, 0755) == -1)
      return -1;
  }
  else
  {
    if (!(st.st_mode & S_IFDIR))
      return -1;
  }

  printf("dir: %s\n", fname);

  /* allocate a file for the new mail */

  stampfile(genbuf, fname);
  printf("file: %s\n", genbuf);

  /* copy the stdin to the specified file */

  if ((fout = fopen(genbuf, "w")) == NULL)
  {
    printf("Cannot open %s \n", genbuf);
    return -1;
  }
  else
  {
    time(&t);
    /* fprintf(fout, "From:      %-50s [Internet E-mail]\n", sender); */
    fprintf(fout, "From:      %s\n", sender);
    fprintf(fout, "Title:     %s\n", title);
    fprintf(fout, "Date:      %s\n", ctime(&t));

    while (fgets(genbuf, 255, fin))
      fputs(genbuf, fout);

    fclose(fout);
  }

  /* append the record to the MAIL control file */

  bzero(&newmessage, sizeof(newmessage));
  strcpy(newmessage.filename, fname);
  strncpy(newmessage.owner, sender, STRLEN);
  if (strtok(newmessage.owner, " .@\t\n\r"))
    strcat(newmessage.owner, ".");

  ptime = localtime(&t);
  sprintf(newmessage.date, "%2d/%2d", ptime->tm_mon + 1, ptime->tm_mday);

  if (title[0])
    strncpy(newmessage.title, title, 72);
  else
    sprintf(newmessage.title, "�Ӧ� %.64s", sender);


  sprintf(genbuf, "%s%s/%s", MAILDIR, userid, ".DIR");
  if (append_record(genbuf, &newmessage, sizeof(newmessage)) == -1)
    return 1;
  else
    return 0;
}


main(argc, argv)
  int argc;
  char *argv[];
{

  char sender[256];
  char username[256];
  char receiver[256];

  /* argv[ 1 ] is original sender */
  /* argv[ 2 ] is userid in bbs   */
  /* argv[ 3 ] is the mail title  */

  if (argc != 4)
  {
    char *p = (char *) rindex(argv[0], '/');

    printf("Usage: %s sender receiver title\n",
      p ? p + 1 : argv[0]);
    return 1;
  }

  if (chroot(BBSHOME) == 0)
  {
    chdir("/");

#ifdef DEBUG
    printf("Chroot ok!\n");
#endif
  }
  else
  {
    /* assume it is in chrooted in bbs */
    /* if it is not the case, append_main() will handle it */
    chdir(BBSHOME);
    printf("Already chroot\n");
  }

  setreuid(BBSUID, BBSUID);
  setregid(BBSGID, BBSGID);

#if 0
  if (strchr(argv[1], '@'))
  {
    strcpy(sender, argv[1]);
  }
  else
  {
    /* �q BBS ���o�X Internet E-mail �� local user */

    char *p, *l, *r;
    char buf[256];
    strcpy(buf, argv[1]);
    p = strtok(buf, " \t\n\r");
    l = strchr(argv[1], '(');
    r = strchr(argv[1], ')');
    if (l < r && l && r)
      strncpy(username, l, r - l + 1);
    sprintf(sender, "%s@%s %s", p, DOMAIN_NAME, username);
  }
#endif

  printf("mail received by: %s\n", argv[2]);
  strcpy(sender, argv[1]);
  strcpy(username, argv[2]);
  strcpy(receiver, argv[3]);
  return append_mail(stdin, sender, username, receiver);
}
