/*
 * These are the 16 basic permission bits. All but the last one are used in
 * comm_lists.c and help.c to control user access to priviliged functions.
 * The symbolic names are given to roughly correspond to their actual usage;
 * feel free to use them for different purposes though.
 */

#define	PERM_BASIC	000001
#define PERM_CHAT	000002
#define	PERM_PAGE	000004
#define PERM_POST	000010
#define	PERM_LOGINOK 	000020
#define PERM_EMAILOK	000040
#define PERM_CLOAK	000100
#define PERM_SEECLOAK	000200
#define PERM_XEMPT 	000400
#define PERM_WELCOME	001000
#define PERM_BM		002000
#define PERM_ACCOUNTS	004000
#define PERM_CHATROOM	010000
#define	PERM_BOARD	020000
#define PERM_SYSOP	040000
#define PERM_POSTMASK  0100000	/* means the rest is a post mask */

/* This is the default permission granted to all new accounts. */
#define PERM_DEFAULT 	(PERM_BASIC | PERM_CHAT | PERM_PAGE | PERM_POST)

/*
 * These permissions are bitwise ORs of the basic bits. They work that way
 * too. For example, anyone with PERM_SYSOP or PERM_BM or both has
 * PERM_SEEBLEVELS.
 */

#define PERM_ADMIN	(PERM_ACCOUNTS | PERM_SYSOP)
#define PERM_ALLBOARD	(PERM_SYSOP | PERM_BOARD)
#define PERM_LOGINCLOAK	(PERM_SYSOP | PERM_ACCOUNTS | PERM_BM)
#define PERM_SEEULEVELS	PERM_SYSOP
#define PERM_SEEBLEVELS	(PERM_SYSOP | PERM_BM)
#define PERM_NOTIMEOUT	PERM_SYSOP

#define PERM_READMAIL	PERM_BASIC

/* These are used only in Internet Mail Forwarding */
/*
 * You may want to be more restrictive than the default, especially for an
 * open access BBS.
 */

#define PERM_FORWARD	PERM_BASIC	/* to do the forwarding */


#define HAS_PERM(x)	((x)?cuser.userlevel&(x):1)
#define HAVE_PERM(x)	(cuser.userlevel&(x))

#ifndef _XYZ_C_
extern char *permstrings[];
#else

#define	NUMPERMS	15

char *permstrings[] = {
  "���v�O",			/* PERM_BASIC */
  "�i�J��ѫ�",			/* PERM_CHAT */
  "��H���",			/* PERM_PAGE */
  "�o���峹",			/* PERM_POST */
  "���U�{�ǻ{��",		/* PERM_LOGINOK */
  "�]�O�d�^"/*"Email �{��"*/,			/* PERM_EMAILOK */
  "�����N",			/* PERM_CLOAK */
  "�ݨ��Ԫ�",			/* PERM_SEECLOAK */
  "�ä[�O�d�b��",		/* PERM_XEMPT */
  "�s�� Welcome",		/* PERM_WELCOME */
  "�O�D",			/* PERM_BM */
  "�b���޲z��",			/* PERM_ACCOUNTS */
  "����޲z��",			/* PERM_CHATCLOAK */
  "�ݪO�޲z��",			/* PERM_BOARD */
  "����"			/* PERM_SYSOP */
  /* "Read/Post ����"	/* PERM_POSTMASK */
};
#endif
