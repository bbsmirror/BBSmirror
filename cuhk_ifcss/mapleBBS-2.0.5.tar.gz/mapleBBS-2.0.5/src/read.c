/* read.c */

#include "bbs.h"

extern int search_num();

#define PUTCURS   move(3+locmem->crs_line-locmem->top_line,0);outs(str_cursor);move(3+locmem->crs_line-locmem->top_line,1);
#define RMVCURS   move(3+locmem->crs_line-locmem->top_line,0);outs(str_uncur);

struct keeploc
{
  char *key;
  int top_line;
  int crs_line;
  struct keeploc *next;
};
typedef struct keeploc keeploc;


char currdirect[64];
fileheader *files = NULL;
int last_line;


keeploc *
getkeep(s, def_topline, def_cursline)
  char *s;
{
  static struct keeploc *keeplist = NULL;
  struct keeploc *p;
  void *malloc();

  for (p = keeplist; p; p = p->next)
  {
    if (!strcmp(s, p->key))
    {
      if (p->crs_line < 1)
	p->crs_line = 1;	/* DAMMIT! - rrr */
      return p;
    }
  }
  p = (keeploc *) malloc(sizeof(keeploc));
  p->key = (char *) malloc(strlen(s) + 1);
  strcpy(p->key, s);
  p->top_line = def_topline;
  p->crs_line = def_cursline;
  p->next = keeplist;
  return (keeplist = p);
}


void
fixkeep(s, first, last)
  char *s;
  int first, last;
{
  keeploc *k;
  k = getkeep(s, 1, 1);
  if (k->crs_line >= first)
  {
    k->crs_line = (first == 1 ? 1 : first - 1);
    k->top_line = (first < 11 ? 1 : first - 10);
  }
}


int
move_cursor_line(locmem, mode)
  struct keeploc *locmem;
  int mode;
{
  int top, crs;
  int reload = 0;

  top = locmem->top_line;
  crs = locmem->crs_line;
  if (mode == READ_PREV)
  {
    if (crs <= top)
    {
      top -= p_lines - 1;
      if (top < 1)
	top = 1;
      reload = 1;
    }
    crs--;
    if (crs < 1)
    {
      crs = 1;
      reload = -1;
    }
  }
  else if (mode == READ_NEXT)
  {
    if (crs + 1 >= top + p_lines)
    {
      top += p_lines - 1;
      reload = 1;
    }
    crs++;
    if (crs > last_line)
    {
      crs = last_line;
      reload = -1;
    }
  }
  locmem->top_line = top;
  locmem->crs_line = crs;
  return reload;
}


void
str_lower(t, s)
  char *t, *s;
{
  register uschar ch;

  while (ch = *s++)
    *t++ = char_lower(ch);
  *t = '\0';
}


int
strstr_lower(str, tag)
  char *str, *tag;		/* tag : lower-case string */
{
  char buf[STRLEN];

  str_lower(buf, str);
  return (int) strstr(buf, tag);
}


int
search_filestruct(locmem, stype)
  struct keeploc *locmem;
  int stype;
{
  static char a_ans[32], t_ans[32];
  char ans[32], s_pmt[64];
  char *query, *tag;
  struct fileheader fh;
  int now, match = 0;

  if (stype & RS_RELATED)
  {
    if (stype & RS_CURRENT)
    {
      query = related_title;
    }
    else
    {
      query = files[locmem->crs_line - locmem->top_line].title;
      if (!strncmp(query, str_reply, 4))
	query += 4;
    }
  }
  else
  {
    query = (stype & RS_TITLE) ? t_ans : a_ans;
    sprintf(s_pmt, "�j�M%s [%s] ", (stype & RS_TITLE) ? "���D" : "�@��", query);
    getdata(b_lines, 0, s_pmt, ans, 30, DOECHO);
    if (*ans)
    {
      strcpy(query, ans);
    }
    else
    {
      if (*query == '\0')
      {
	move(b_lines, 0);
	clrtoeol();
	return 0;
      }
    }
    str_lower(s_pmt, query);
    query = s_pmt;
  }

  now = (stype & RS_FIRST) ? 0 : locmem->crs_line;

  move(b_lines, 0);
  clrtoeol();
  outs(msg_working);
  refresh();
  tag = fh.owner;

  do
  {
    if (stype & RS_RELATED)
    {
      if (stype & RS_FORWARD)
      {
	if (++now > last_line)
	  return 0;
      }
      else
      {
	if (--now <= 0)
	  return 0;
      }
    }
    else
    {
      if (stype & RS_FORWARD)
      {
	if (++now > last_line)
	  now = 1;
      }
      else
      {
	if (--now <= 0)
	  now = last_line;
      }
    }
    get_record(currdirect, &fh, sizeof(fileheader), now);
    if (stype & RS_TITLE)
    {
      tag = fh.title;
      if (strncmp(tag, str_reply, 4) == NULL)
	tag += 4;
    }
    if (((stype & RS_RELATED) && !strncmp(tag, query, 40)) ||
      (!(stype & RS_RELATED) && strstr_lower(tag, query)))
    {
      match = cursor_pos(locmem, now, 10);
      if (stype & RS_CURRENT)
	return 1;
      if ((stype & RS_RELATED) && strncmp(related_title, query, 40))
      {
	strncpy(related_title, query, 40);
	match = 1;
      }
      break;
    }
  }
  while (now != locmem->crs_line);

  return match;
}


/* calc cursor pos and show cursor correctly -cuteyu */
int
cursor_pos(locmem, val, from_top)
  struct keeploc *locmem;
  int val;
  int from_top;
{
  if (val > last_line)
  {
    bell();
    val = last_line;
  }
  if (val <= 0)
  {
    bell();
    val = 1;
  }

  if (val >= locmem->top_line && val < locmem->top_line + p_lines)
  {
    RMVCURS;
    locmem->crs_line = val;
    PUTCURS;
    return 0;
  }
  locmem->top_line = val - from_top;
  if (locmem->top_line <= 0)
    locmem->top_line = 1;
  locmem->crs_line = val;
  return 1;
}


void
i_read(cmdmode, direct, dotitle, doentry, rcmdlist)
  char *direct;
  void (*dotitle) ();
  void *(*doentry) ();
  struct one_key *rcmdlist;
{
  extern int talkrequest;
  keeploc *locmem;
  char lbuf[11];
  int recbase, mode, ch;
  int num, entries;
  int i;

#define	ssize	sizeof(fileheader)

  if (!files)
    files = (fileheader *) calloc(p_lines, ssize);
  strcpy(currdirect, direct);
  mode = NEWDIRECT;

  do
  {
    /* -------------------------------------------------------- */
    /* �̾� mode ��� fileheader				 */
    /* -------------------------------------------------------- */

    modify_user_mode(cmdmode);

    switch (mode)
    {
    case NEWDIRECT:		/* �Ĥ@�����J���ؿ� */
    case DIRCHANGED:
      last_line = get_num_records(currdirect, ssize);

      if (mode == NEWDIRECT)
      {
	if (last_line == 0)
	{
	  if (in_mail)
	  {
	    outs("�S���ӫH");
	    igetch();
	  }
	  else
	  {
	    getdata(b_lines, 0, "���Q�װϨS���峹 (P)�o�� (Q)�h�X?[Q]�G",
	      genbuf, 10, DOECHO);
	    if (genbuf[0] == 'p' || genbuf[0] == 'P')
	      do_post();
	  }
	  return;
	}
	num = last_line - p_lines + 1;
	locmem = getkeep(currdirect, num < 1 ? 1 : num, last_line);
      }
      recbase = -1;

    case FULLUPDATE:
      (*dotitle) ();

    case PARTUPDATE:
      if (last_line < locmem->top_line + p_lines)
      {
	num = get_num_records(currdirect, ssize);
	if (last_line != num)
	{
	  last_line = num;
	  recbase = -1;
	}
      }

      if (last_line == 0)
      {
	return;
      }
      else if (recbase != locmem->top_line)
      {
	recbase = locmem->top_line;
	if (recbase > last_line)
	{
	  recbase = last_line - p_lines >> 1;
	  if (recbase < 1)
	    recbase = 1;
	  locmem->top_line = recbase;
	}
	entries = get_records(currdirect, files, ssize, recbase, p_lines);
      }
      if (locmem->crs_line > last_line)
	locmem->crs_line = last_line;

      move(3, 0);
      clrtobot();
      for (i = 0; i < entries; i++)
	(*doentry) (locmem->top_line + i, &files[i]);

    case READ_REDRAW:
      move(b_lines, 0);
      clrtoeol();
      outs(in_mail ? msg_mailer : msg_select);
      /* refresh(); */
      PUTCURS;
    }

    /* -------------------------------------------------------- */
    /* Ū����L�A�[�H�B�z�A�]�w mode 				 */
    /* -------------------------------------------------------- */

    ch = egetch();
    mode = DONOTHING;

    if (talkrequest)
    {
      talkreply();
      mode = FULLUPDATE;
    }
    else if (ch >= '0' && ch <= '9')
    {
      if ((i = search_num(ch, last_line)) != -1)
	if (cursor_pos(locmem, i + 1, 10))
	  mode = PARTUPDATE;
    }
    else
    {
      mode = i_read_key(rcmdlist, locmem, ch);

      while (mode == READ_NEXT || mode == READ_PREV ||
	mode == RELATE_NEXT || mode == RELATE_PREV)
      {
	int reload;

	if (mode == READ_NEXT || mode == READ_PREV)
	{
	  reload = move_cursor_line(locmem, mode);
	}
	else
	{
	  reload = search_filestruct(locmem, mode);
	  if (reload == 0)
	  {
	    mode = FULLUPDATE;
	    break;
	  }
	}

	if (reload == -1)
	{
	  mode = FULLUPDATE;
	  break;
	}
	else if (reload)
	{
	  recbase = locmem->top_line;
	  entries = get_records(currdirect, files, ssize, recbase, p_lines);
	  if (entries <= 0)
	  {
	    last_line = -1;
	    break;
	  }
	}

	num = locmem->crs_line - locmem->top_line;
	if (files[num].owner[0] != '-')
	  mode = i_read_key(rcmdlist, locmem, ch);
      }
    }
  } while (mode != DOQUIT);

#undef	ssize
}


int
i_read_key(rcmdlist, locmem, ch)
  struct one_key *rcmdlist;
  struct keeploc *locmem;
  int ch;
{
  int i, mode = DONOTHING;

  switch (ch)
  {
  case 'b':
    {
      char notes_buf[64];

      setbfile(notes_buf, currboard, str_notes);
      if (more(notes_buf, NA) == -1)
      {
	clear();
	move(3, 20);
	outs("���Q�װϩ|�L�u�Ƨѿ��v�C");
      }
      pressanykey();
      mode = FULLUPDATE;
      break;
    }
  case KEY_TAB:
    {
      char buf[32];
      setapath(buf, currboard);
      a_menu(currboard, buf, HAS_PERM(PERM_ALLBOARD) ? 2 :
	(strstr(currBM, cuser.userid) ? 1 : 0));
    }
    return FULLUPDATE;
  case 'q':
  case 'e':
  case KEY_LEFT:
    return DOQUIT;

  case Ctrl('L'):
    redoscr();
    break;

  case 'a':
    if (search_filestruct(locmem, RS_FORWARD))
      return PARTUPDATE;
    return READ_REDRAW;

  case 'A':
    if (search_filestruct(locmem, 0))
      return PARTUPDATE;
    return READ_REDRAW;

  case '/':
    if (search_filestruct(locmem, RS_TITLE | RS_FORWARD))
      return PARTUPDATE;
    return READ_REDRAW;

  case '?':
    if (search_filestruct(locmem, RS_TITLE))
      return PARTUPDATE;
    return READ_REDRAW;

    /* quick search title first */
  case '=':
    if (search_filestruct(locmem, RS_FIRST | RS_RELATED | RS_TITLE | RS_FORWARD))
      return PARTUPDATE;
    return READ_REDRAW;

    /* quick search title forword */
  case ']':
    if (search_filestruct(locmem, RS_RELATED | RS_TITLE | RS_FORWARD | RS_CURRENT))
      return PARTUPDATE;
    return READ_REDRAW;

  case '+':
    if (search_filestruct(locmem, RS_RELATED | RS_TITLE | RS_FORWARD))
      return PARTUPDATE;
    return READ_REDRAW;

    /* quick search title backword */
  case '[':
    if (search_filestruct(locmem, RS_RELATED | RS_TITLE | RS_CURRENT))
      return PARTUPDATE;
    return READ_REDRAW;

  case '-':
    if (search_filestruct(locmem, RS_RELATED | RS_TITLE))
      return PARTUPDATE;
    return READ_REDRAW;

  case 'p':
  case 'k':
  case KEY_UP:
    if (cursor_pos(locmem, locmem->crs_line - 1, p_lines - 2))
      return PARTUPDATE;
    break;

  case 'n':
  case 'j':
  case KEY_DOWN:
    if (cursor_pos(locmem, locmem->crs_line + 1, 1))
      return PARTUPDATE;
    break;

  case ' ':
  case KEY_PGDN:
  case Ctrl('F'):
    if (last_line >= locmem->top_line + p_lines)
    {
      locmem->top_line += p_lines - 1;
      locmem->crs_line = locmem->top_line;
      return PARTUPDATE;
    }
    RMVCURS;
    locmem->crs_line = last_line;
    PUTCURS;
    break;

  case KEY_PGUP:
  case Ctrl('B'):
  case 'P':
    if (locmem->top_line > 1)
    {
      locmem->top_line -= p_lines - 1;
      if (locmem->top_line <= 0)
	locmem->top_line = 1;
      locmem->crs_line = locmem->top_line;
      return PARTUPDATE;
    }
    break;

  case '$':
    if (last_line >= locmem->top_line + p_lines)
    {
      locmem->top_line = last_line - p_lines + 1;
      if (locmem->top_line <= 0)
	locmem->top_line = 1;
      locmem->crs_line = last_line;
      return PARTUPDATE;
    }
    RMVCURS;
    locmem->crs_line = last_line;
    PUTCURS;
    break;

  case '\n':
  case '\r':
  case 'l':
  case KEY_RIGHT:
    ch = 'r';

  default:
    for (i = 0; rcmdlist[i].fptr; i++)
    {
      if (rcmdlist[i].key == ch)
      {
	mode = (*(rcmdlist[i].fptr)) (locmem->crs_line,
	  &files[locmem->crs_line - locmem->top_line], currdirect);
	break;
      }
    }
  }
  return mode;
}
