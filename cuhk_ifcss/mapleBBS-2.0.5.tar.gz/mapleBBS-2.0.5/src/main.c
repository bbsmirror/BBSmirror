/* main.c */

#include "bbs.h"

jmp_buf byebye;

int talkrequest = NA;
static uschar enter_uflag;

user_info uinfo;

#ifdef SHOW_IDLE_TIME
/*
 * char dummy[128];
 */
char fromhost[STRLEN - 20];
char tty_name[20];
#else
char fromhost[STRLEN];
#endif

int utmpent = -1;
time_t login_start_time;
extern char *Cdate();
extern int showansi;

void check_register();


void
log_usies(mode, mesg)
  char *mode, *mesg;
{
  FILE *fp;

  if (fp = fopen(str_usies, "a"))
  {
    time_t now = time(0);
    fprintf(fp, cuser.userid[0] ? "%s %s %-12s %s\n" : "%s %s %s%s\n",
      Cdate(&now), mode, cuser.userid, mesg);
    fclose(fp);
  }
}


void
u_enter()
{
  enter_uflag = cuser.uflag;

  memset(&uinfo, 0, sizeof(uinfo));

  uinfo.active = YEA;
  uinfo.pid = getpid();

  if (enter_uflag & CLOAK_FLAG)
  {
    if (HAS_PERM(PERM_LOGINCLOAK))
      uinfo.invisible = YEA;
    else
      cuser.uflag ^= CLOAK_FLAG;
  }
  uinfo.mode = LOGIN;
  uinfo.pager = !(enter_uflag & PAGER_FLAG);
  uinfo.uid = usernum;

  strcpy(uinfo.userid, cuser.userid);
  strcpy(uinfo.realname, cuser.realname);
  strcpy(uinfo.username, cuser.username);
  strncpy(uinfo.from, fromhost, 28);

#ifdef SHOW_IDLE_TIME
  strcpy(uinfo.tty, tty_name);
#endif

  utmpent = getnewutmpent(&uinfo);
}


void
setflags(mask, value)
  int mask, value;
{
  if (((cuser.uflag & mask) && 1) != value)
  {
    if (value)
      cuser.uflag |= mask;
    else
      cuser.uflag &= ~mask;
  }
}


void
u_exit()
{
  setflags(PAGER_FLAG, !uinfo.pager);
  if (HAS_PERM(PERM_LOGINCLOAK))
    setflags(CLOAK_FLAG, uinfo.invisible);

  if (cuser.uflag != enter_uflag)
  {
    cuser.uflag &= (0xff ^ DIRTY_FLAG);
    substitute_record(str_passfile, &cuser, sizeof(userec), usernum);
  }

  uinfo.invisible = YEA;
  uinfo.active = uinfo.pid = uinfo.sockactive = uinfo.sockaddr = uinfo.destuid = 0;

#ifdef SHOW_IDLE_TIME
  strcpy(uinfo.tty, "NoTTY");
#endif

  update_utmp();
}


int
cmpuids(uid, up)
  char *uid;
  struct userec *up;
{
  return !ci_strncmp(uid, up->userid, sizeof(up->userid));
}


int
dosearchuser(userid)
  char *userid;
{
  int id;

  if (id = getuser(userid))
  {
    if (cmpuids(userid, &xuser))
    {
      memcpy(&cuser, &xuser, sizeof(cuser));
      return usernum = id;
    }
  }
  memset(&cuser, 0, sizeof(cuser));	/* phxx 4.0 */
  return usernum = 0;
}


int started = 0;

void
talk_request()
{

#ifdef	LINUX
  /*
   * Linux �U�s�� page ���⦸�N�i�H�����X�h�G �o�O�ѩ�Y�Ǩt�Τ@ nal
   * �i�ӴN�|�N signal handler �]�w�����w�� handler, �������O default �O�N�{
   * erminate. �ѨM��k�O�C�� signal �i�ӴN���] signal handler
   */

  signal(SIGUSR1, talk_request);
#endif

  talkrequest = YEA;
  bell();
  bell();
  bell();
  sleep(1);
  bell();
  bell();
  bell();
  bell();
}


void
abort_bbs()
{
  if (started)
  {
    sprintf(genbuf, "Stay: %d (%s)",
      (time(0) - login_start_time) / 60, cuser.username);
    log_usies("AXXED", genbuf);
    u_exit();
  }
  exit(0);
}


int
cmpuids2(unum, urec)
  int unum;
  user_info *urec;
{
  return (unum == urec->uid);
}


int
count_multi(uentp)
  struct user_info *uentp;
{
  static int count;

  if (uentp == NULL)
  {
    int num = count;
    count = 0;
    return num;
  }
  if (!uentp->active || !uentp->pid)
    return 0;
  if (uentp->uid == usernum)
    count++;
  return 1;
}


int
count_user()
{
  count_multi(NULL);
  apply_ulist(count_multi);
  return count_multi(NULL);
}


void
system_abort()
{
  time_t now;

  if (started)
  {
    log_usies("ABORT", cuser.username);
    u_exit();
  }
  clear();
  refresh();
  printf("���¥��{, �O�o�`�ӳ� !\n");
  sleep(1);
  exit(0);
}


void
multi_user_check()
{
  struct user_info uin;
  char buffer[40];

  if (HAS_PERM(PERM_SYSOP))
    return;			/* don't check sysops */

  if (cuser.userlevel)
  {
    if (!search_ulist(&uin, cmpuids2, usernum))
      return;			/* user isn't logged in */

    if (!uin.active || (kill(uin.pid, 0) == -1))
      return;			/* stale entry in utmp file */

    getdata(0, 0, "�z�Q�R����L���ƪ� login �� (Y/N)? [Y]", genbuf, 2, DOECHO);

    if (genbuf[0] != 'n' && genbuf[0] != 'N')
    {
      kill(uin.pid, 9);
      log_usies("KICK ", cuser.username);

#ifdef	HAVE_REPORT
      sprintf(buffer, "kicked (multi-login)");
      report(buffer);
#endif
    }
    else
    {
      if (count_user() >= 2)
	system_abort();		/* Goodbye(); */
    }
  }
  else
  {
    /* allow multiple guest user */
    if (count_user() > 16)
    {
      outs("��p�A�ثe�w���Ӧh guest, �еy��A�աC");
      pressanykey();
      oflush();
      exit(1);
    }
    return;
  }
}


int
belong(filelist, userid)
  char *filelist;
  char *userid;
{
  FILE *fp;

  if (fp = fopen(filelist, "r"))
  {
    char buf[STRLEN], *ptr;

    while (fgets(buf, STRLEN, fp))
    {
      ptr = strtok(buf, " \t\n");
      if (!strcasecmp(ptr, userid))
      {
	fclose(fp);
	return 1;
      }
    }
    fclose(fp);
  }
  return 0;
}


/* bad login */

char *str_badlogin = "logins.bad";


void
logattempt(uid, frm)
  char *uid, *frm;
{
  char fname[40];
  int fd, len;

  sprintf(genbuf, "%-12.12s[%s]%s\n", uid, Cdate(&login_start_time), frm);
  len = strlen(genbuf);
  if ((fd = open(str_badlogin, O_WRONLY | O_CREAT | O_APPEND, 0644)) > 0)
  {
    write(fd, genbuf, len);
    close(fd);
  }

  sethomefile(fname, uid, str_badlogin);
  if ((fd = open(fname, O_WRONLY | O_CREAT | O_APPEND, 0644)) > 0)
  {
    write(fd, genbuf, len);
    close(fd);
  }
}


void
login_query()
{
  char uid[IDLEN + 1], passbuf[PASSLEN];
  int curr_login_num;
  int attempts;

  curr_login_num = count_ulist();
  prints("�w����{�i[1;37;45m %s [m�j(�ثe�`�@�� %d �H�W�u)\n",
    BoardName, curr_login_num);
  if (curr_login_num >= MAXACTIVE)
  {
    outs("�ѩ�H�ƤӦh�A�бz�y��A�ӡC\n");
    oflush();
    sleep(1);
    exit(1);
  }

  attempts = 0;
  while (1)
  {
    if (attempts++ >= LOGINATTEMPTS)
    {
      more("etc/goodbye", NA);
      oflush();
      sleep(1);
      exit(1);
    }

    getdata(0, 0, "\n�п�J�N���A�ΥH[guest]���[�A�H[new]���U�G",
      uid, IDLEN + 1, DOECHO);
    if (strcmp(uid, str_new) == 0)
    {

#ifdef LOGINASNEW
      new_register();
      break;
#else
      outs("���t�Υثe�L�k�H new ���U, �Х� guest �i�J\n");
      continue;
#endif
    }
    else if (uid[0] == '\0' || !dosearchuser(uid))
    {
      outs(err_uid);
    }
    else if (strcmp(uid, str_guest))
    {
      getdata(0, 0, ask_passwd, passbuf, PASSLEN, NOECHO);
      passbuf[8] = '\0';

      if (!checkpasswd(cuser.passwd, passbuf))
      {
	logattempt(cuser.userid, fromhost);
	outs(err_passwd);
      }
      else
	break;
    }
    else
    {				/* guest */
      cuser.userlevel = 0;
      cuser.uflag = COLOR_FLAG | PAGER_FLAG;
      break;
    }
  }

  multi_user_check();
  if (!term_init(cuser.termtype))
  {
    outs("�׺ݾ����A���~�I�w�]�� [vt100]\n");
    term_init("vt100");
  }

  sethomepath(genbuf, cuser.userid);
  mkdir(genbuf, 0755);
}


int
valid_ident(ident)
  char *ident;
{
  static char *invalid[] = {"unknown@", "root@", "gopher@", "bbs@",
  "guest@", "@ppp", "@slip", NULL};
  int i;

  for (i = 0; invalid[i]; i++)
    if (strstr(ident, invalid[i]))
      return 0;
  return 1;
}


void
user_login()
{
  char ans[2];

#ifdef	HAVE_REMOTEUSERNAME
  char *ruser;

  ruser = getenv("REMOTEUSERNAME");
  sprintf(genbuf, "%s@%s", ruser ? ruser : "?", fromhost);
  log_usies("ENTER", genbuf);

  if (ruser)
  {
    if (valid_ident(genbuf))
      strncpy(cuser.ident, genbuf, NAMELEN);
    else if (!valid_ident(cuser.ident))
      cuser.ident[0] = '\0';
  }
#else
  log_usies("ENTER", fromhost);
#endif

  /* SYSOP gets all permission bits */
  if (strcmp(cuser.userid, "SYSOP") == 0)
    cuser.userlevel = ~0;

  u_enter();

#ifdef	HAVE_REPORT
  report("Enter");
#endif

  started = 1;
  initscr();
  more("Welcome", NA);

  ++cuser.numlogins;

  if (cuser.userlevel)		/* not guest */
  {
    move(t_lines - 3, 0);
    prints("     �w��z�� [1;33m%d[0;37m �׫��X�����A\
�W���z�O�q [1;33m%s[0;37m �s�������A\n\
     �ڰO�o���ѬO [1;33m%s[0;37m�C\n",
      cuser.numlogins, cuser.lasthost,
      Cdate(&cuser.lastlogin));
    pressanykey();

    setuserfile(genbuf, str_badlogin);
    if (more(genbuf, NA) != -1)
    {
      getdata(b_lines, 0, "�z�n�R���H�W���~���ժ��O����(Y/N)?[Y]",
	ans, 2, DOECHO);
      if (*ans != 'n' && *ans != 'N')
	unlink(genbuf);
    }

    strncpy(cuser.lasthost, fromhost, 16);
    cuser.lasthost[15] = '\0';
    check_register();
  }
  cuser.lastlogin = time(NULL);
  substitute_record(str_passfile, &cuser, sizeof(cuser), usernum);
  more(str_note_ans, YEA);
  more(str_day_issue, YEA);
}


void
main(argc, argv)
  int argc;
  char **argv;
{
  int getin;
  char *rhost;

  /* ----------- */
  /* system init */
  /* ----------- */

  srand(login_start_time = time(0));

  if (rhost = (char *) getenv("REMOTEHOSTNAME"))
    strncpy(fromhost, rhost, 60);
  else if (argc >= 3)
    strncpy(fromhost, argv[2], 60);
  else
    fromhost[0] = '\0';

#ifdef SHOW_IDLE_TIME
  if (argc >= 4)
    strncpy(tty_name, argv[3], 20);
  else
    tty_name[0] = '\0';
#endif

#ifndef lint
  signal(SIGHUP, abort_bbs);
  signal(SIGINT, SIG_IGN);
  signal(SIGQUIT, SIG_IGN);
  signal(SIGPIPE, SIG_IGN);

#ifdef DOTIMEOUT
  init_alarm();
#else
  signal(SIGALRM, SIG_IGN);
#endif

  signal(SIGTERM, SIG_IGN);
  signal(SIGURG, SIG_IGN);
  signal(SIGTSTP, SIG_IGN);
  signal(SIGTTIN, SIG_IGN);
  signal(SIGTTOU, SIG_IGN);
  signal(SIGUSR1, talk_request);
  signal(SIGUSR2, SIG_IGN);
#endif

  if (setjmp(byebye))
    system_abort();
  get_tty();
  init_tty();
  login_query();
  user_login();

  friend_load();
  m_init();

#ifdef	SIMPLE_VOTE
  if (HAVE_PERM(PERM_SYSOP))
#else
  if (HAVE_PERM(PERM_SYSOP | PERM_BM))
#endif

    b_closepolls();

  if (!(cuser.uflag & COLOR_FLAG))
    showansi = 0;

  domenu(MMENU, "�D�\\���", (chkmail(0) ? 'M' : 'C'), cmdlist);
}


Class()
{
  domenu(CLASS, "���հQ�װ�", '1', classlist);
  return 0;
}


Maintenance()
{
  domenu(ADMIN, "�t�κ��@��", 'I', maintlist);
  return 0;
}


User()
{
  domenu(UMENU, "�ϥΪ̳]�w��", 'I', userlist);
  return 0;
}


Xyz()
{
  domenu(XMENU, "�u��{����", 'N', xyzlist);
  return 0;
}


Talk()
{
  domenu(TMENU, "�𶢲�Ѱ�", 'U', talklist);
  return 0;
}


Mail()
{
  domenu(MAIL, "�q�l�l���", 'R', maillist);
  return 0;
}
