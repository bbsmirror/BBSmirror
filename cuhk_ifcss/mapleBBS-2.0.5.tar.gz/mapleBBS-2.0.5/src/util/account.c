/* static.c : �W���H���έp */

#include <stdio.h>
#define	MAX_LINE	16

struct
{
  int no[24];			/* ���� */
  int sum[24];			/* �`�X */
}      st;

main(argc, argv)
  char *argv[];
{
  char *progmode;
  FILE *fp;
  char buf[256], *p;
  char *mon, *day, *year;
  int hour, max = 0, item, total = 0;
  int totaltime = 0;
  int i, j;

  if ((fp = fopen("usies", "r")) == NULL)
  {
    printf("cann't open usies\n");
    return 1;
  }

  while (fgets(buf, 256, fp))
  {
    hour = atoi(buf+9);
    if (hour < 0 || hour > 23)
    {
       printf("%s", buf);
       continue;
    }
    if ( !strncmp(buf+22, "ENTER", 5))
    {
      st.no[hour]++;
      continue;
    }
    if ( p = (char *)strstr(buf+40, "Stay:"))
    {
      st.sum[hour] += atoi( p + 5);
      continue;
    }
  }
  fclose(fp);

  for (i = 0; i < 24; i++)
  {
    total += st.no[i];
    totaltime += st.sum[i];
    if (st.no[i] > max)
      max = st.no[i];
  }

  item = max / MAX_LINE + 1;

  if ((fp = fopen("etc/today", "w")) == NULL)
  {
    printf("cann't open countusr\n");
    return 1;
  }

  fprintf(fp, "\t\t\t[1;33;46m �C�p�ɤW���H���έp [%.8s] [40m\n\n", buf);
  for (i = MAX_LINE + 1; i > 0; i--)
  {
    fprintf(fp, "   [31m");
    for (j = 0; j < 24; j++)
    {
      if ((item * i > st.no[j]) && (item * (i - 1) <= st.no[j]) && st.no[j])
      {
	fprintf(fp, "[33m%-3d[31m", st.no[j]);
	continue;
      }
      fprintf(fp, (item * i <= st.no[j] ? "�i " : "   "));
    }
    fprintf(fp, "\n");
  }

  fprintf(fp, "   [32m"
    "0  1  2  3  4  5  6  7  8  9  10 11 12 13 14 15 16 17 18 19 20 21 22 23\n\n"
    "\t\t[34m�`�@�W���H���G[37m%-9d[34m�����ϥήɶ��G[37m%d[40;0m\n"
    ,total, totaltime / total + 1);
  fclose(fp);
}
