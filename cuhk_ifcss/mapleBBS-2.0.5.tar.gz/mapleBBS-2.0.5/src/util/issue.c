/* issue.c - �έp����Q�j�������D */

#include <stdio.h>
#include <time.h>


#define HASHSIZE 1024
#define TOPCOUNT 100

#define token1   "�H��:"
#define token2   "��  �D:"
#define token3   "�o�H��:"


struct postrec
{
  char *title;			/* title name */
  char *board;			/* board name */
  int postno;			/* post number */
  time_t postdate;		/* last post's date */
  struct postrec *next;		/* next rec */
}      *bucket[HASHSIZE];


struct gb
{
  char group[47];		/* group name */
  char board[13];		/* board name */
}  bag[200];


/* 88 bytes */
struct posttop
{
  char board[13];		/* board name */
  char title[67];		/* title name */
  int postno;			/* post number */
  time_t postdate;		/* last post's date */
}       top[TOPCOUNT];


char month[12][4] = {"Jan", "Feb", "Mar", "Apr", "May",
"Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};


int
hash(key)
  char *key;
{
  int i, value = 0;

  for (i = 0; key[i]&& i < 80 ; i++)
    value += key[i] < 0 ? -key[i] : key[i];

  value = value % HASHSIZE;
  return value;
}


/* ---------------------------------- */
/* hash structure : array + link list */
/* ---------------------------------- */

void
search(key, rec1, rec2)
  char *key;
  char *rec1;
  time_t rec2;
{
  struct postrec *p, *q, *s;
  int i, found = 0;

  i = hash(key);
  q = NULL;
  p = bucket[i];
  while (p && (!found))
  {
    if (!strcmp(p->title, key) && !strcmp(p->board, rec1))
      found = 1;
    else
    {
      q = p;
      p = p->next;
    }
  }
  if (found)
  {
    p->postno++;
    p->postdate = (p->postdate > rec2 ? p->postdate : rec2);
  }
  else
  {
    s = (struct postrec *) malloc(sizeof(struct postrec));
    s->title = (char *) malloc(strlen(key) + 1);
    s->board = (char *) malloc(strlen(rec1) + 1);
    strcpy(s->title, key);
    strcpy(s->board, rec1);
    s->postno = 1;
    s->postdate = rec2;
    s->next = NULL;
    if (q == NULL)
      bucket[i] = s;
    else
      q->next = s;
  }
}


#ifdef LINUX
time_t
cvtime(date)
  char *date;
{
  int i;
  int long mon, day, year, hour, min, sec;
  char buf[3];
  time_t result = 0;
  struct tm ltm;

  for (i = 0; i < 12; i++)
  {
    if (!strncmp(date + 4, month[i], 3))
      break;
  }
  ltm.tm_mon = i;
  buf[2] = NULL;
  strncpy(buf, date + 8, 2);
  ltm.tm_mday = atoi(buf);
  strncpy(buf, date + 11, 2);
  ltm.tm_hour = atoi(buf);
  strncpy(buf, date + 14, 2);
  ltm.tm_min = atoi(buf);
  strncpy(buf, date + 17, 2);
  ltm.tm_sec = atoi(buf);
  strncpy(buf, date + 22, 2);
  ltm.tm_year = atoi(buf);

#if 0
  result = (year - 70) * 365 * 86400;
  result += ((year - 70 + 2) / 4) * 86400;
  switch (mon)
  {
  case 12:
    result += 30 * 86400;
  case 11:
    result += 31 * 86400;
  case 10:
    result += 30 * 86400;
  case 9:
    result += 31 * 86400;
  case 8:
    result += 31 * 86400;
  case 7:
    result += 30 * 86400;
  case 6:
    result += 31 * 86400;
  case 5:
    result += 30 * 86400;
  case 4:
    result += 31 * 86400;
  case 3:
    result += 28 * 86400;
    if (year % 4 == 0)
      result += 86400;
  case 2:
    result += 31 * 86400;
  }
  result += (day - 1) * 86400;
  result += (hour - 8) * 3600;
  result += min * 60;
  result += sec;
#endif

  result = mktime(&ltm);
  return (result);
}
#endif


void
sort(pp)
  struct postrec *pp;
{
  int i, j;

  for (i = 0; i < TOPCOUNT; i++)
  {
    if (pp->postno > top[i].postno)
    {
      for (j = TOPCOUNT - 2; j >= i; j--)
	memcpy(&top[j + 1], &top[j], sizeof(struct posttop));

      strcpy(top[i].board, pp->board);
      strcpy(top[i].title, pp->title);
      top[i].postno = pp->postno;
      top[i].postdate = pp->postdate;
      break;
    }
  }
}


main(argc, argv)
  char *argv[];
{
  static char *logfile = "echomail.log";
  static char *oldfile = "echomail.old";

  FILE *fp;
  char buf[128], board[16], title[67], date[25], *p;
  time_t realdate;
  struct tm ltm;
  struct postrec *pp, *qq, *ss;
  struct gb *gbp;
  int i, j;

  if (argc < 2)
  {
    printf("Usage:\t%s bbshome [day]\n", argv[0]);
    exit();
  }

  chdir(argv[1]);

  /* ---------------------------------------------- */
  /* load newsgroups from innd/newsfeeds.bbs & sort */
  /* ---------------------------------------------- */

  if ((fp = fopen("innd/newsfeeds.bbs", "r")) == NULL)
  {
    printf("Cann't find newsfeeds.bbs\n");
    exit(-1);
  }

  i = 0;
  while (fgets(buf, 127, fp))
  {
    if (buf[0] != '#')
    {
      strcpy(bag[i].group, (char *)strtok(buf, " \t"));
      if (strcmp(buf, "tw.bbs.test") && strcmp(buf, "test"))
	strcpy(bag[i++].board, (char *)strtok(NULL, " \t"));
    }
  }
  qsort(bag, i, sizeof(struct gb), strcmp);

  /* ---------------------------------------------- */
  /* load echomail.log and statictic processing     */
  /* ---------------------------------------------- */

  if( argc > 2)
  {
    rename ( logfile, oldfile);
    fp = fopen(oldfile, "r");
  }
  else
    fp = fopen(logfile, "r");

  if (fp == NULL)
  {
    printf("Cann't find echomail.log\n");
    exit(-1);
  }

  while (fgets(buf, 127, fp))
  {
    if (p = (char *)strchr(buf, '\n'))
      *p = '\0';

    /* get board name */
    if (p = (char *) strstr(buf, token1))
    {
      if (gbp = (struct gb *) bsearch(p + 6, bag, i, sizeof(struct gb), strcmp))
	strcpy(board, gbp->board);
      else
	continue;

      if (fgets(buf, 127, fp))
      {
	/* get title */
	if (p = (char *)strchr(buf, '\n'))
	  *p = '\0';
	if (p = (char *) strstr(buf, token2))
	{
	  p += 8;
	  if (!strncmp(p, "Re:", 3))
	    p += 4;
	  strncpy(title, p, 66);

	  /* get date */
	  if (fgets(buf, 127, fp))
	  {
	    if (strstr(buf, token3))
	    {
	      p = (char *) strrchr(buf, '(');
	      strncpy(date, p + 1, 24);
	      date[24] = NULL;

#ifdef LINUX
	      realdate = cvtime(date);
#else
	      strptime(date, "%A %h %e %T %Y", &ltm);
	      realdate = timelocal(&ltm);
#endif

#ifdef	DEBUG
	      printf("%s\n", ctime(&realdate));
	      getchar();
#endif

	      search(title, board, realdate);
	    }
	  }
	}
      }
    }
  }
  fclose(fp);

  /* ---------------------------------------------- */
  /* sort top 100 issue and save results            */
  /* ---------------------------------------------- */

  for (i = 0; i < HASHSIZE; i++)
  {
    if ((pp = bucket[i]))
    {

#ifdef	DEBUG
      printf("Title : %s, Board: %s\nPostNo : %d, PostDate: %s\n"
	,pp->title
	,pp->board
	,pp->postno
	,ctime(&pp->postdate));
#endif

      sort(pp);
      pp = pp->next;
    }
  }

  if ((fp = fopen("etc/day", "w")) == NULL)
  {
    printf("cann't open day\n");
    exit();
  }
  fprintf(fp, "\t\t\t[1;34m-----[37m=====[41m ����Q�j�������D [40m=====[34m-----[37;0m\n\n");
  for (i = 0; i < 10; i++)
  {
    strcpy(buf, ctime(&top[i].postdate));
    buf[20] = NULL;
    p = buf + 4;
    fprintf(fp,
      "[1;31m%3d. [33m�H�� : [32m%-20s[35m�m %s�n\t\t[36m�@ %2d �g\n"
      "     [33m���D : [0;44;37m%-60.60s[40m\n"
      ,i + 1, top[i].board, p, top[i].postno, top[i].title);
  }
  fclose(fp);

  if ( argc > 2 && (fp = fopen("etc/day.0", "w")) != NULL)
  {
    unlink(oldfile);
    fwrite( top, sizeof(struct posttop), TOPCOUNT, fp);
    fclose(fp);
  }
}
