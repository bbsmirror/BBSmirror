/* topic.c - �έp week/month �������D */

#include <stdio.h>
#include <time.h>

char *myfile[] = { "day", "week", "month", "season", "year" };
int mycount[4] = { 7, 4, 3, 4 };
int mytop[4] = { 50, 100, 100, 100 };
char *mytitle[] = { "�g���Q", "���", "�u��", "�~�צ�"};


#define HASHSIZE 1024
#define TOPCOUNT 100


struct postrec
{
  char *title;			/* title name */
  char *board;			/* board name */
  int postno;			/* post number */
  time_t postdate;		/* last post's date */
  struct postrec *next;		/* next rec */
}      *bucket[HASHSIZE];


/* 88 bytes */
struct posttop
{
  char board[13];		/* board name */
  char title[67];		/* title name */
  int postno;			/* post number */
  time_t postdate;		/* last post's date */
}       top[TOPCOUNT];


int
hash(key)
  char *key;
{
  int i, value = 0;

  for (i = 0; key[i] && i < 80; i++)
    value += key[i] < 0 ? -key[i] : key[i];

  value = value % HASHSIZE;
  return value;
}


/* ---------------------------------- */
/* hash structure : array + link list */
/* ---------------------------------- */

void
search(t)
  struct posttop *t;
{
  struct postrec *p, *q, *s;
  int i, found = 0;

  i = hash(t->title);
  q = NULL;
  p = bucket[i];
  while (p && (!found))
  {
    if (!strcmp(p->title, t->title) && !strcmp(p->board, t->board))
      found = 1;
    else
    {
      q = p;
      p = p->next;
    }
  }
  if (found)
  {
    p->postno += t->postno;
    p->postdate = (p->postdate > t->postdate ? p->postdate : t->postdate);
  }
  else
  {
    s = (struct postrec *) malloc(sizeof(struct postrec));
    s->title = (char *) malloc(strlen(t->title) + 1);
    s->board = (char *) malloc(strlen(t->board) + 1);
    strcpy(s->title, t->title);
    strcpy(s->board, t->board);
    s->postno = t->postno;
    s->postdate = t->postdate;
    s->next = NULL;
    if (q == NULL)
      bucket[i] = s;
    else
      q->next = s;
  }
}


void
sort(pp)
  struct postrec *pp;
{
  int i, j;

  for (i = 0; i < TOPCOUNT; i++)
  {
    if (pp->postno > top[i].postno)
    {
      for (j = TOPCOUNT - 2; j >= i; j--)
	memcpy(&top[j + 1], &top[j], sizeof(struct posttop));

      strcpy(top[i].board, pp->board);
      strcpy(top[i].title, pp->title);
      top[i].postno = pp->postno;
      top[i].postdate = pp->postdate;
      break;
    }
  }
}


main(argc, argv)
  char *argv[];
{
  FILE *fp;
  char buf[40], curfile[40], *p;
  time_t realdate;
  struct tm ltm;
  struct postrec *pp, *qq, *ss;
  struct gb *gbp;
  int i, j, mytype;

  if (argc < 3)
  {
    printf("Usage:\t%s bbshome <week/month/season/year>\n", argv[0]);
    exit();
  }

  chdir(argv[1]);

  /* ---------------------------------------------- */
  /* load previous results and statictic processing */
  /* ---------------------------------------------- */

  mytype = atoi(argv[2]);
  
  i = mycount[mytype];
  p = myfile[mytype];
  while (i)
  {
    sprintf(buf, "etc/%s.%d", p, i);
    sprintf(curfile, "etc/%s.%d", p, --i);
    if (fp = fopen(curfile, "r"))
    {
      fread(top, sizeof(struct posttop), TOPCOUNT, fp);
      fclose(fp);
      rename(curfile, buf);
      for (j = 0; j < TOPCOUNT; j++)
	search(&top[j]);
    }
  }

  /* ---------------------------------------------- */
  /* sort top 100 issue and save results            */
  /* ---------------------------------------------- */

  for (i = 0; i < HASHSIZE; i++)
  {
    if ((pp = bucket[i]))
    {

#ifdef	DEBUG
      printf("Title : %s, Board: %s\nPostNo : %d, PostDate: %s\n"
	,pp->title
	,pp->board
	,pp->postno
	,ctime(&pp->postdate));
#endif

      sort(pp);
      pp = pp->next;
    }
  }

  p = myfile[mytype+1];
  sprintf(curfile, "etc/%s.0", p);
  if (fp = fopen(curfile, "w"))
  {
    fwrite(top, sizeof(struct posttop), TOPCOUNT, fp);
    fclose(fp);
  }

  sprintf(curfile, "etc/%s", p);
  if (fp = fopen(curfile, "w"))
  {
  fprintf(fp, "\t\t\t[1;34m-----[37m=====[41m ��%s�j�������D [40m=====[34m-----[37;0m\n\n", mytitle[mytype]);
  j = mytop[mytype];
  for (i = 0; i < j; i++)
  {
    strcpy(buf, ctime(&top[i].postdate));
    buf[20] = NULL;
    p = buf + 4;
    fprintf(fp,
      "[1;31m%3d. [33m�H�� : [32m%-20s[35m�m %s�n\t\t[36m�@ %2d �g\n"
      "     [33m���D : [0;44;37m%-60.60s[40m\n"
      ,i + 1, top[i].board, p, top[i].postno, top[i].title);
  }
  fclose(fp);
  }
}
