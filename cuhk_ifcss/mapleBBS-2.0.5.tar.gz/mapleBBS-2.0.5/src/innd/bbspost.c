/*
 * File: bbspost.c
 */

#include "bbs.h"

char *ProgramUsage = "\
bbspost (list|visit) bbs_home\n\
	post board_path < uid + title + Article...\n\
	digest board_path < uid + title + passwd + realfrom + Article...\n\
	mail board_path < uid + title + passwd + realfrom + Article...\n\
	verify bbbs_home < checksum + realfrom\n\
	cancel bbs_home board filename\n\
	expire bbs_home board days [max_posts] [min_posts]\n";

#define	MAXLEN	256

char *crypt();
char *homepath;
int visitflag;

#ifdef	DEBUG
FILE *fxx;
#endif

#define _BBS_UTIL_C_
#include "../record.c"


void
usage()
{
  printf(ProgramUsage);
  exit(0);
}


void
search_article(brdname)
  char *brdname;
{
  struct fileheader head;
  struct stat state;
  char index[80];
  int fd, num, step;
  char send, type;

  /* offset = (int) &(head.savemode) - (int) &head; /* opus */

#define	offset	FNLEN

  sprintf(index, "%s/boards/%s/.DIR", homepath, brdname);
  if ((fd = open(index, O_RDWR)) < 0)
  {
    return;
  }
  fstat(fd, &state);
  num = (state.st_size / sizeof(head)) - 1;

  /* �q�ɧ��f�V�ˬd��H�F�S */

  step = 0;
  while (num >= 0)
  {
    lseek(fd, num * sizeof(head) + offset, 0);
    if (read(fd, &send, 1) > 0 && send == '%')
      break;
    if (step <= 6)
      step++;
    num -= step;		/* opus: increase stripe */
  }

  if (step)
  {
    if (++num < 0)
      num = 0;
    lseek(fd, num * sizeof(head), 0);
    for (send = '%'; read(fd, &head, sizeof(head)) > 0; num++)
    {
      type = head.savemode;

      if (type != send && visitflag)
      {
	lseek(fd, num * sizeof(head) + offset, 0);
	write(fd, &send, 1);
	lseek(fd, (num + 1) * sizeof(head), 0);
      }
      if (type == '\0')
      {
	printf("%s\t%s\t%s\t%s\n", brdname,
	  head.filename, head.owner, head.title);
      }
    }
  }
  close(fd);
}


void
search_boards(visit)
{

  /* ----------------------------------- */
  /* �ª���k��� .BOARDS ����A�Ĳv���t */
  /* ----------------------------------- */

#ifdef	OLD_METHOD
  boardheader board;
  char boardlist[40];
  FILE *fn;

  visitflag = visit;
  sprintf(boardlist, "%s/.BOARDS", homepath);
  if ((fn = fopen(boardlist, "r")) == NULL)
  {
    printf(":Err: unable to open %s\n", boardlist);
    return;
  }
  printf("New article listed:\n");
  while (fread(&board, sizeof(board), 1, fn) > 0)
  {
    search_article(board.brdname);
  }
#endif

  struct dirent *de;
  DIR *dirp;
  char buf[80], *ptr;
  int fd, len;

  visitflag = visit;
  sprintf(buf, "%s/boards", homepath);

  if ((dirp = opendir(buf)) == NULL)
  {
    printf(":Err: unable to open %s\n", buf);
    return;
  }

  printf("New article listed:\n");

  while (de = readdir(dirp))
  {
    if (de->d_name[0] > ' ' && de->d_name[0] != '.')
      search_article(de->d_name);

    /* how about junk ? */
  }
  closedir(dirp);
}


void
check_password(record)
  struct userec *record;
{
  FILE *fn;
  char *pw;
  char passwd[20];
  char realfrom[80];
  char genbuf[MAXLEN];

  gets(passwd);
  pw = crypt(passwd, record->passwd);
  if (strcmp(pw, record->passwd))
  {
    printf(":Err: user [%s] password incorrect!!\n", record->userid);
    exit(0);
  }
  gets(realfrom);
  sprintf(genbuf, "home/%s/email", record->userid);
  if (fn = fopen(genbuf, "w"))
  {
    fprintf(fn, "%s\n", realfrom);
    fclose(fn);
  }
  if (!strstr(realfrom, "bbs@"))
  {
    strncpy(record->justify, realfrom, 43);
  }
  if (!strstr(homepath, "test"))
  {
    record->numposts++;
  }
  record->userlevel |= PERM_LOGINOK;
}


void
check_userec(record, name)
  struct userec *record;
  char *name;
{
  int fh;

  if ((fh = open(".PASSWDS", O_RDWR)) == -1)
  {
    printf(":Err: unable to open .PASSWDS file.\n");
    exit(0);
  }
  while (read(fh, record, sizeof *record) > 0)
  {
    if (strcasecmp(name, record->userid) == 0)
    {
      strcpy(name, record->userid);
      check_password(record);
      lseek(fh, -1 * sizeof *record, SEEK_CUR);
      write(fh, record, sizeof *record);
      close(fh);
      return;
    }
  }
  close(fh);
  printf(":Err: unknown userid %s\n", name);
  exit(0);
}


void
post_article(usermail)
{
  userec record;
  fileheader header;
  char userid[80], subject[80];
  char index[64], name[80], article[80];
  char buf[MAXLEN], *ptr;
  FILE *fidx;
  int fh;
  time_t now;
  struct tm *ptime;

  sprintf(index, "%s/.DIR", homepath);

#ifdef	VERBOSE
  if ((fidx = fopen(index, "r")) == NULL)
  {
    if ((fidx = fopen(index, "w")) == NULL)
    {
      printf(":Err: Unable to post in %s.\n", homepath);
      return;
    }
  }
  fclose(fidx);
#endif

  gets(userid);
  gets(subject);
  if (usermail)
  {
    check_userec(&record, userid);
  }

  now = time(NULL);
  ptime = localtime(&now);
  sprintf(name, "M.%d.A", now);

  ptr = strrchr(name, 'A');
  while (1)
  {
    sprintf(article, "%s/%s", homepath, name);
    fh = open(article, O_CREAT | O_EXCL | O_WRONLY, 0644);
    if (fh != -1)
      break;
    if (*ptr < 'Z')
      (*ptr)++;
    else
    {
      ptr++;
      *ptr = 'A';
      ptr[1] = '\0';
    }
  }

  printf("post to %s\n", article);
  if (usermail)
  {
    ptr = strrchr(homepath, '/');
    (ptr == NULL) ? (ptr = homepath) : (ptr++);
    sprintf(buf, "\
Posted By: %s (%s) on board '%s'\n\
Title:     %s\n\
Date:      %s\n",
      userid, record.username, ptr, subject, ctime(&now));
    write(fh, buf, strlen(buf));
  }

  while (fgets(buf, MAXLEN, stdin))
  {
    write(fh, buf, strlen(buf));
  }
  close(fh);

  bzero((void *) &header, sizeof(header));
  strcpy(header.filename, name);
  if (!usermail)
  {
    header.savemode = 'M';	/* opus: �N����i�H�� */
  }
  strncpy(header.owner, userid, IDLEN);
  sprintf(header.date, "%2d/%02d", ptime->tm_mon + 1, ptime->tm_mday);
  strncpy(header.title, subject, TTLEN);
  append_record(index, &header, sizeof(header));
}


/* �����峹���ذ� */

void
digest_article()
{
  userec record;
  fileheader header;
  char userid[80], subject[80];
  char index[80], name[80], article[80], *ptr;
  char buf[MAXLEN];
  FILE *fidx, *fh;
  time_t now;
  struct tm *ptime;

  sprintf(index, "%s/.Names", homepath);
  if ((fidx = fopen(index, "r")) == NULL)
  {
    printf(":Err: Unable to digest in %s.\n", homepath);
    return;
  }

  while (fgets(buf, MAXLEN, fidx))
  {
    if (strncmp(buf, "# Title=", 8) == 0)
      break;
  }
  fclose(fidx);

  gets(name);
  gets(userid);
  gets(subject);
  check_userec(&record, userid);

#ifdef	ONLY_ONE_BM
  sprintf(article, "(BM:%s)", userid);
  if (strstr(buf, article))
#else
  if (strstr(buf, userid))
#endif

  {
    /* truncate long lines */

    name[31] = subject[62] = '\0';
    if (ptr = (char *) strchr(name, ' '))
      *ptr = '\0';

    sprintf(article, "%s/%s", homepath, name);
    if (fh = fopen(article, "a+"))
    {
      printf("digest: %s\n", article);

      while (fgets(buf, MAXLEN, stdin))
	fputs(buf, fh);
      fclose(fh);

      now = time(NULL);
      ptime = localtime(&now);
      fidx = fopen(index, "a+");
      fprintf(fidx, "Name=�� %s\nDate=%02d/%02d/%02d\nPath=%s\n\n",
	subject, ptime->tm_mon + 1, ptime->tm_mday, ptime->tm_year, name);
      fclose(fidx);
    }
  }
}


/* ���ҨϥΪ̤��u�����{�ҫH��v */

void
verify_user()
{
  char reply[256], *ptr, *next, ch;
  unsigned short checksum, usrnum;
  userec record;
  int fh;

  gets(reply);
  if (ptr = (char *) strchr(reply, '('))
  {
    *ptr++ = '\0';
    if (next = (char *) strchr(ptr, ':'))
    {
      *next++ = '\0';
      usrnum = atoi(ptr) - 1234;
      if (ptr = (char *) strchr(next, ')'))
      {
	*ptr++ = '\0';
	checksum = atoi(next);

	if ((fh = open(".PASSWDS", O_RDWR)) == -1)
	{
	  printf(":Err: unable to open .PASSWDS file.\n");
	  exit(0);
	}
	lseek(fh, (usrnum - 1) * sizeof(record), SEEK_CUR);
	read(fh, &record, sizeof record);
	if (strcasecmp(reply, record.userid) == 0)
	{
	  ptr = record.email;
	  while (ch = *ptr++)
	  {
	    usrnum = (usrnum << 1) ^ ch;
	  }
	  if (usrnum == checksum)
	  {
	    FILE *fn;

	    sprintf(reply, "home/%s/justify", record.userid);
	    if (fn = fopen(reply, "w"))
	    {
	      gets(reply);
	      fprintf(fn, "%s\n", reply);
	      fclose(fn);
	    }
            strncpy(record.justify, reply, 43);
	    record.userlevel |= PERM_LOGINOK;
	    lseek(fh, -1 * sizeof record, SEEK_CUR);
	    write(fh, &record, sizeof record);
	  }
	}
	close(fh);
      }
    }
  }
}


void
cancel_article(board, file)
  char *board, *file;
{
  struct fileheader header;
  struct stat state;
  char dirname[80];
  char buf[80];
  long numents, size, time, now;
  int fd, lower, ent;

  if (file == NULL || file[0] != 'M' || file[1] != '.' ||
    (time = atoi(file + 2)) <= 0)
    return;
  size = sizeof(header);
  sprintf(dirname, "%s/boards/%s/.DIR", homepath, board);
  if ((fd = open(dirname, O_RDWR)) == -1)
    return;
  flock(fd, LOCK_EX);
  fstat(fd, &state);
  ent = ((long) state.st_size) / size;
  lower = 0;
  while (1)
  {
    ent -= 8;
    if (ent <= 0 || lower >= 2)
      break;
    lseek(fd, size * ent, SEEK_SET);
    if (read(fd, &header, size) != size)
    {
      ent = 0;
      break;
    }
    now = atoi(header.filename + 2);
    lower = (now < time) ? lower + 1 : 0;
  }
  if (ent < 0)
    ent = 0;
  while (read(fd, &header, size) == size)
  {
    if (strcmp(file, header.filename) == 0)
    {
      sprintf(buf, "-%s", header.owner);
      strncpy(header.owner, buf, IDLEN + 1);
      strcpy(header.title, "<< article canceled >>");
      lseek(fd, -size, SEEK_CUR);
      safewrite(fd, &header, size);
      break;
    }
    now = atoi(header.filename + 2);
    if (now > time)
      break;
  }
  flock(fd, LOCK_UN);
  close(fd);
}


void
expire_article(brdname, days_str, maxpost, minpost)
  char *brdname, *days_str;
{
  struct fileheader head;
  struct stat state;
  char lockfile[80], index[80];
  char tmpfile[80], delfile[80];
  int days, total;
  int fd, fdr, fdw, done, keep;
  int duetime, ftime;

  days = atoi(days_str);

#ifdef	VERBOSE
  if (days < 1)
  {
    printf(":Err: expire time must more than 1 day.\n");
    return;
  }
  else if (maxpost < 100)
  {
    printf(":Err: maxmum posts number must more than 100.\n");
    return;
  }
#endif

  sprintf(index, "%s/boards/%s/.DIR", homepath, brdname);
  sprintf(lockfile, "%s.lock", index);
  sprintf(tmpfile, "%s.new", index);
  sprintf(delfile, "%s.old", index);

  if ((fd = open(lockfile, O_RDWR | O_CREAT | O_APPEND, 0644)) == -1)
    return;
  flock(fd, LOCK_EX);
  unlink(tmpfile);

  duetime = time(NULL) - days * 24 * 60 * 60;
  done = 0;
  if ((fdr = open(index, O_RDONLY, 0)) > 0)
  {
    fstat(fdr, &state);
    total = state.st_size / sizeof(head);
    if ((fdw = open(tmpfile, O_WRONLY | O_CREAT | O_EXCL, 0644)) > 0)
    {
      while (read(fdr, &head, sizeof head) == sizeof head)
      {
	done = 1;
	ftime = atoi(head.filename + 2);
	if (head.owner[0] == '-')
	  keep = 0;
	else if (head.filemode & FILE_MARKED || total <= minpost)
	  keep = 1;
	else if (ftime < duetime || total > maxpost)
	  keep = 0;
	else
	  keep = 1;
	if (keep)
	{
	  if (safewrite(fdw, &head, sizeof head) == -1)
	  {
	    done = 0;
	    break;
	  }
	}
	else
	{
	  printf("Unlink %s\n", head.filename);
	  if (head.owner[0] == '-')
	    printf("Unlink %s.cancel\n", head.filename);
	  total--;
	}
      }
      close(fdw);
    }
    close(fdr);
  }
  if (done)
  {
    unlink(delfile);
    if (rename(index, delfile) != -1)
    {
      rename(tmpfile, index);
    }
  }
  flock(fd, LOCK_UN);
  close(fd);
}


main(argc, argv)
  char *argv[];
{
  char *progmode;
  int max, min;

#ifdef	DEBUG
  fxx = fopen("a.log", "a+");
  fprintf(fxx, "===%s\n%s\n%s\n%s\n",
    argv[1], argv[2], argv[3], argv[4]);
#endif

  if (argc < 3)
    usage();
  progmode = argv[1];
  homepath = argv[2];
  if (strcasecmp(progmode, "list") == 0)
  {
    search_boards(0);
  }
  else if (strcasecmp(progmode, "visit") == 0)
  {
    search_boards(1);
  }
  else if (strcasecmp(progmode, "post") == 0)
  {
    post_article(0);
  }
  else if (strcasecmp(progmode, "verify") == 0)
  {
    verify_user();
  }
  else if (strcasecmp(progmode, "digest") == 0)
  {
    digest_article();
  }
  else if (strcasecmp(progmode, "mail") == 0)
  {
    post_article(1);
  }
  else if (strcasecmp(progmode, "cancel") == 0)
  {
    if (argc < 5)
      usage();
    cancel_article(argv[3], argv[4]);
  }
  else if (strcasecmp(progmode, "expire") == 0)
  {
    if (argc < 5)
      usage();
    max = argc > 5 ? atoi(argv[5]) : 2400;
    min = argc > 6 ? atoi(argv[6]) : 20;
    expire_article(argv[3], argv[4], max, min);
  }

#ifdef	DEBUG
  fclose(fxx);
#endif
}
