/* xyz.c */

#define _XYZ_C_

#include "bbs.h"


void
modify_user_mode(mode)
{
  uinfo.mode = mode;
  update_ulist(&uinfo, utmpent);
}


unsigned
setperms(pbits)
  unsigned pbits;
{
  int i, done = NA;
  char choice[2];

  move(4, 0);
  for (i = 0; i < NUMPERMS; i++)
  {
    prints("%c. %-20s %s\n", 'A' + i, permstrings[i],
      ((pbits >> i) & 1 ? "��" : "��"));
  }
  clrtobot();
  while (!done)
  {
    getdata(b_lines, 0, "�Ы� [A-O] �����]�w�A�� [Return] ����: ",
      choice, 2, DOECHO);
    *choice = toupper(*choice);
    if (*choice == '\n' || *choice == '\0')
      done = YEA;
    else if (*choice < 'A' || *choice > 'A' + NUMPERMS - 1)
      bell();
    else
    {
      i = *choice - 'A';
      pbits ^= (1 << i);
      move(i + 4, 24);
      prints((pbits >> i) & 1 ? "��" : "��");
    }
  }
  return (pbits);
}


int
x_level()
{
  int id;
  int newlevel;

  stand_title("�]�w User �v��");
  usercomplete(msg_uid, genbuf);
  if (genbuf[0] == '\0')
  {
    return 0;
  }
  if (!(id = getuser(genbuf)))
  {
    move(3, 0);
    outs(err_uid);
    clrtoeol();
    pressanykey();
    return 0;
  }
  move(1, 0);
  clrtobot();
  prints("\nUser [%s] �v��\n", xuser.userid);
  newlevel = setperms(xuser.userlevel);

  move(2, 0);
  if (newlevel == xuser.userlevel)
    prints("User [%s] �v���å����", xuser.userid);
  else
  {
    xuser.userlevel = newlevel;
    substitute_record(str_passfile, &xuser, sizeof(struct userec), id);
    prints("User [%s] �v����粒��", xuser.userid);

#ifdef	HAVE_REPORT
    sprintf(genbuf, "changed permissions for %s", xuser.userid);
    report(genbuf);
#endif
  }
  pressanykey();
  return 0;
}


int
x_user()
{
  more("etc/topusr", YEA);
  return 0;
}

int
x_note()
{
  more(str_note_ans, YEA);
  return 0;
}

int
x_issue()
{
  more(str_day_issue, YEA);
  return 0;
}

int
x_week()
{
  more("etc/week", YEA);
  return 0;
}

int
x_today()
{
  more("etc/today", YEA);
  return 0;
}

int
x_yesterday()
{
  more("etc/yesterday", YEA);
  return 0;
}


#ifdef HAVE_INFO
x_program()
{
  more("Version.Info", YEA);
  return 0;
}
#endif


#ifdef HAVE_License
x_gpl()
{
  more("COPYING", YEA);
  return 0;
}
#endif


int
Welcome()
{
  more("Welcome", YEA);
  return 0;
}


int
EditWelcome()
{
  int aborted;
  char ans[4];

  getdata(b_lines, 0, "(E)�ק��w��e�� (Q)���} ? [E]: ", ans, 3, DOECHO);
  if (ans[0] == 'q' || ans[0] == 'Q')
  {
    return XEASY;
  }
  modify_user_mode(EDITWELC);
  aborted = vedit("Welcome", NA);
  if (aborted)
    outs("Welcome ������");
  else
    outs("��s Welcome");
  pressanykey();
  return 0;
}


#ifdef	HAVE_ADM_SHELL
x_csh()
{
  int save_pager;
  clear();
  refresh();
  reset_tty();
  save_pager = uinfo.pager;
  uinfo.pager = NA;
  update_utmp();

#ifdef	HAVE_REPORT
  report("shell out");
#endif

#ifdef SYSV
  do_exec("sh", NULL);
#else
  do_exec("csh", NULL);
#endif

  restore_tty();
  uinfo.pager = save_pager;
  update_utmp();
  clear();
  return 0;
}
#endif				/* NO_ADM_SHELL */


#ifdef BBSDOORS
ent_bnet()			/* Bill Schwartz */
{
  int save_pager = uinfo.pager;
  uinfo.pager = NA;

#ifdef	HAVE_REPORT
  report("BBSNet Enter");
#endif

  modify_user_mode(BBSNET);
  /* bbsnet.sh is a shell script that can be customized without */
  /* having to recompile anything.  If you edit it while someone */
  /* is in bbsnet they will be sent back to the xyz menu when they */
  /* leave the system they are currently in. */

  reset_tty();
  do_exec("bbsnet.sh", NULL);
  restore_tty();
  uinfo.pager = save_pager;

#ifdef	HAVE_REPORT
  report("BBSNet Exit");
#endif

  clear();
}
#endif
