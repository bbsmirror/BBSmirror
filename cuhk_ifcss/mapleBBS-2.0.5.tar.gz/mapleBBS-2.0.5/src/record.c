/* record.c */

#include "bbs.h"

/* opus: #define BUFSIZE (MAXUSERS + 244) */
#define BUFSIZE 256


#ifdef SYSV
int
flock(fd, op)
  int fd, op;
{
  switch (op)
  {
  case LOCK_EX:
    return lockf(fd, F_LOCK, 0);
  case LOCK_UN:
    return lockf(fd, F_ULOCK, 0);
  default:
    return -1;
  }
}
#endif


#ifdef	POSTBUG
char bigbuf[10240];
int numtowrite;
int bug_possible = 0;

saverecords(filename, size, pos)
  char *filename;
  int size, pos;
{
  int fd;
  if (!bug_possible)
    return 0;
  if ((fd = open(filename, O_RDONLY)) == -1)
    return -1;
  if (pos > 5)
    numtowrite = 5;
  else
    numtowrite = 4;
  lseek(fd, (pos - numtowrite - 1) * size, L_SET);
  read(fd, bigbuf, numtowrite * size);
}

restorerecords(filename, size, pos)
  char *filename;
  int size, pos;
{
  int fd;
  if (!bug_possible)
    return 0;
  if ((fd = open(filename, O_WRONLY)) == -1)
    return -1;
  flock(fd, LOCK_EX);
  lseek(fd, (pos - numtowrite - 1) * size, L_SET);
  safewrite(fd, bigbuf, numtowrite * size);

#ifdef	HAVE_REPORT
  report("post bug poison set out!");
#endif

  flock(fd, LOCK_UN);
  bigbuf[0] = '\0';
  close(fd);
}
#endif				/* POSTBUG */


#ifndef	_BBS_UTIL_C_
long
get_num_records(filename, size)
  char *filename;
{
  struct stat st;

  if (stat(filename, &st) == -1)
    return 0;
  return (st.st_size / size);
}


int
apply_record(filename, fptr, size)
  char *filename;
  int (*fptr) ();
  int size;
{
  char abuf[BUFSIZE];
  int fd;

  if ((fd = open(filename, O_RDONLY, 0)) == -1)
    return -1;

  while (read(fd, abuf, size) == size)
    if ((*fptr) (abuf) == QUIT)
    {
      close(fd);
      return QUIT;
    }
  close(fd);
  return 0;
}


int
get_record(filename, rptr, size, id)
  char *filename;
  char *rptr;
  int size, id;
{
  int fd;

  if ((fd = open(filename, O_RDONLY, 0)) == -1)
    return -1;
  if (lseek(fd, size * (id - 1), SEEK_SET) == -1)
  {
    close(fd);
    return -1;
  }
  if (read(fd, rptr, size) != size)
  {
    close(fd);
    return -1;
  }
  close(fd);
  return 0;
}


int
get_records(filename, rptr, size, id, number)
  char *filename;
  char *rptr;
  int size, id, number;
{
  int fd;
  int n;

  if ((fd = open(filename, O_RDONLY, 0)) == -1)
    return -1;
  if (lseek(fd, size * (id - 1), SEEK_SET) == -1)
  {
    close(fd);
    return 0;
  }
  if ((n = read(fd, rptr, size * number)) == -1)
  {
    close(fd);
    return -1;
  }
  close(fd);
  return (n / size);
}


int
substitute_record(filename, rptr, size, id)
  char *filename;
  char *rptr;
  int size, id;
{
  int fd;

#ifdef POSTBUG
  if (size == sizeof(struct fileheader) && (id > 1) && ((id - 1) % 4 == 0))
    saverecords(filename, size, id);
#endif

  if ((fd = open(filename, O_WRONLY | O_CREAT, 0644)) == -1)
    return -1;
  flock(fd, LOCK_EX);

#ifdef	HAVE_REPORT
  if (lseek(fd, size * (id - 1), SEEK_SET) == -1)
    report("substitute_record failed!!! (lseek)");
  if (safewrite(fd, rptr, size) != size)
    report("substitute_record failed!!! (safewrite)");
#else
  lseek(fd, size * (id - 1), SEEK_SET);
  safewrite(fd, rptr, size);
#endif

  flock(fd, LOCK_UN);
  close(fd);

#ifdef POSTBUG
  if (size == sizeof(fileheader) && (id > 1) && ((id - 1) % 4 == 0))
    restorerecords(filename, size, id);
#endif

  return 0;
}


/* ---------------------------- */
/* new/old/lock file processing */
/* ---------------------------- */

typedef struct
{
  char newfn[64];
  char oldfn[64];
  char lockfn[64];
}      nol;


void
nolfilename(n, filename)
  nol *n;
  char *filename;
{
  sprintf(n->newfn, "%s.new", filename);
  sprintf(n->oldfn, "%s.old", filename);
  sprintf(n->lockfn, "%s.lock", filename);
}


int
delete_record(filename, size, id)
  char *filename;
  int size, id;
{
  nol my;
  char abuf[BUFSIZE];
  int fdr, fdw, fd;
  int count;

  nolfilename(&my, filename);

  if ((fd = open(my.lockfn, O_RDWR | O_CREAT | O_APPEND, 0644)) == -1)
    return -1;
  flock(fd, LOCK_EX);

  if ((fdr = open(filename, O_RDONLY, 0)) == -1)
  {

#ifdef	HAVE_REPORT
    report("delete_record failed!!! (open)");
#endif

    flock(fd, LOCK_UN);
    close(fd);
    return -1;
  }
  if ((fdw = open(my.newfn, O_WRONLY | O_CREAT | O_EXCL, 0644)) == -1)
  {
    flock(fd, LOCK_UN);

#ifdef	HAVE_REPORT
    report("delete_record failed!!! (open tmpfile)");
#endif

    close(fd);
    close(fdr);
    return -1;
  }
  count = 1;
  while (read(fdr, abuf, size) == size)
    if (id != count++ && (safewrite(fdw, abuf, size) == -1))
    {

#ifdef	HAVE_REPORT
      report("delete_record failed!!! (safewrite)");
#endif

      unlink(my.newfn);
      close(fdr);
      close(fdw);
      flock(fd, LOCK_UN);
      close(fd);
      return -1;
    }
  close(fdr);
  close(fdw);
  if (rename(filename, my.oldfn) == -1 || rename(my.newfn, filename) == -1)
  {

#ifdef	HAVE_REPORT
    report("delete_record failed!!! (rename)");
#endif

    flock(fd, LOCK_UN);
    close(fd);
    return -1;
  }
  flock(fd, LOCK_UN);
  close(fd);
  return 0;
}


int
delete_range(filename, id1, id2)
  char *filename;
  int id1, id2;
{
  fileheader fhdr;
  nol my;
  char fullpath[STRLEN], *t;
  int fdr, fdw, fd;
  int count;

  nolfilename(&my, filename);

  if ((fd = open(my.lockfn, O_RDWR | O_CREAT | O_APPEND, 0644)) == -1)
    return -1;
  flock(fd, LOCK_EX);

  if ((fdr = open(filename, O_RDONLY, 0)) == -1)
  {
    flock(fd, LOCK_UN);
    close(fd);
    return -1;
  }

  if ((fdw = open(my.newfn, O_WRONLY | O_CREAT | O_EXCL, 0644)) == -1)
  {
    close(fdr);
    flock(fd, LOCK_UN);
    close(fd);
    return -1;
  }
  count = 1;
  strcpy(fullpath, filename);
  t = (char *) strrchr(fullpath, '/') + 1;

  while (read(fdr, &fhdr, sizeof(fileheader)) == sizeof(fileheader))
  {
    if (count < id1 || count > id2 || fhdr.filemode & FILE_MARKED)
    {
      if ((safewrite(fdw, &fhdr, sizeof(fileheader)) == -1))
      {
	close(fdr);
	close(fdw);
	unlink(my.newfn);
	flock(fd, LOCK_UN);
	close(fd);
	return -1;
      }
    }
    else
    {
      strcpy(t, fhdr.filename);
      unlink(fullpath);
    }
    count++;
  }
  close(fdr);
  close(fdw);
  if (rename(filename, my.oldfn) == -1 || rename(my.newfn, filename) == -1)
  {
    flock(fd, LOCK_UN);
    close(fd);
    return -1;
  }
  flock(fd, LOCK_UN);
  close(fd);
  return 0;
}


int
update_file(dirname, size, ent, filecheck, fileupdate)
  char *dirname;
  int size, ent;
  int (*filecheck) ();
  void (*fileupdate) ();
{
  char abuf[BUFSIZE];
  int fd;

  if ((fd = open(dirname, O_RDWR)) == -1)
    return -1;
  flock(fd, LOCK_EX);
  if (lseek(fd, size * (ent - 1), SEEK_SET) != -1)
  {
    if (read(fd, abuf, size) == size)
      if ((*filecheck) (abuf))
      {
	lseek(fd, -size, SEEK_CUR);
	(*fileupdate) (abuf);
	if (safewrite(fd, abuf, size) != size)
	{

#ifdef	HAVE_REPORT
	  report("update_file failed!!! (safewrite)");
#endif

	  flock(fd, LOCK_UN);
	  close(fd);
	  return -1;
	}
	flock(fd, LOCK_UN);
	close(fd);
	return 0;
      }
  }
  lseek(fd, 0, SEEK_SET);
  while (read(fd, abuf, size) == size)
  {
    if ((*filecheck) (abuf))
    {
      lseek(fd, -size, SEEK_CUR);
      (*fileupdate) (abuf);
      if (safewrite(fd, abuf, size) == size)
      {

#ifdef	HAVE_REPORT
	report("update_file failed!!! (safewrite)");
#endif

	flock(fd, LOCK_UN);
	close(fd);
	return 0;
      }
      break;
    }
  }
  flock(fd, LOCK_UN);
  close(fd);
  return -1;
}


int
delete_file(dirname, size, ent, filecheck)
  char *dirname;
  int size, ent;
  int (*filecheck) ();
{
  char abuf[BUFSIZE];
  int fd;
  struct stat st;
  long numents;

  if ((fd = open(dirname, O_RDWR)) == -1)
    return -1;
  flock(fd, LOCK_EX);
  fstat(fd, &st);
  numents = ((long) st.st_size) / size;
  if (((long) st.st_size) % size)
    fprintf(stderr, "align err\n");
  if (lseek(fd, size * (ent - 1), SEEK_SET) != -1)
  {
    if (read(fd, abuf, size) == size)
      if ((*filecheck) (abuf))
      {
	int i;
	for (i = ent; i < numents; i++)
	{
	  if (lseek(fd, (i) * size, SEEK_SET) == -1)
	    break;
	  if (read(fd, abuf, size) != size)
	    break;
	  if (lseek(fd, (i - 1) * size, SEEK_SET) == -1)
	    break;
	  if (safewrite(fd, abuf, size) != size)
	    break;
	}
	ftruncate(fd, (off_t) size * (numents - 1));
	flock(fd, LOCK_UN);
	close(fd);
	return 0;
      }
  }
  lseek(fd, 0, SEEK_SET);
  ent = 1;
  while (read(fd, abuf, size) == size)
  {
    if ((*filecheck) (abuf))
    {
      int i;
      for (i = ent; i < numents; i++)
      {
	if (lseek(fd, (i + 1) * size, SEEK_SET) == -1)
	  break;
	if (read(fd, abuf, size) != size)
	  break;
	if (lseek(fd, (i) * size, SEEK_SET) == -1)
	  break;
	if (safewrite(fd, abuf, size) != size)
	  break;
      }
      ftruncate(fd, (off_t) size * (numents - 1));
      flock(fd, LOCK_UN);
      close(fd);
      return 0;
    }
    ent++;
  }
  flock(fd, LOCK_UN);
  close(fd);
  return -1;
}
#endif				/* _BBS_UTIL_C_ */



/* �C���g�@�I�I�A�H���w�� */

int
safewrite(fd, buf, size)
  int fd;
  char *buf;
  int size;
{
  int cc, sz = size, origsz = size;
  char *bp = buf;

#ifdef POSTBUG
  if (size == sizeof(struct fileheader))
  {
    char foo[80];
    struct stat stbuf;
    struct fileheader *fbuf = (struct fileheader *) buf;
    setbpath(foo, fbuf->filename);
    if (!isalpha(fbuf->filename[0]) || stat(foo, &stbuf) == -1)
      if (fbuf->filename[0] != 'M' || fbuf->filename[1] != '.')
      {

#ifdef	HAVE_REPORT
	report("safewrite: foiled attempt to write bugged record\n");
#endif

	return origsz;
      }
  }
#endif

  do
  {
    cc = write(fd, bp, sz);
    if ((cc < 0) && (errno != EINTR))
    {

#ifdef	HAVE_REPORT
      report("safewrite failed!");
#endif

      return -1;
    }
    if (cc > 0)
    {
      bp += cc;
      sz -= cc;
    }
  }
  while (sz > 0);
  return origsz;
}


int
append_record(filename, record, size)
  char *filename;
  char *record;
  int size;
{
  int fd;

#ifdef POSTBUG
  int numrecs = (int) get_num_records(filename, size);
  bug_possible = 1;
  if (size == sizeof(struct fileheader) && numrecs && (numrecs % 4 == 0))
    saverecords(filename, size, numrecs + 1);
#endif

  if ((fd = open(filename, O_WRONLY | O_CREAT, 0644)) == -1)
  {
    perror("open");
    return -1;
  }
  flock(fd, LOCK_EX);
  lseek(fd, 0, SEEK_END);

#ifdef	HAVE_REPORT
  if (safewrite(fd, record, size) == -1)
    report("append record failed (safewrite)!!!!");
#else
  safewrite(fd, record, size);
#endif

  flock(fd, LOCK_UN);
  close(fd);

#ifdef POSTBUG
  if (size == sizeof(struct fileheader) && numrecs && (numrecs % 4 == 0))
    restorerecords(filename, size, numrecs + 1);
  bug_possible = 0;
#endif

  return 0;
}


int
search_record(filename, rptr, size, fptr, farg)
  char *filename;
  char *rptr;
  int size;
  int (*fptr) ();
  int farg;
{
  int fd;
  int id = 1;

  if ((fd = open(filename, O_RDONLY, 0)) == -1)
    return 0;
  while (read(fd, rptr, size) == size)
  {
    if ((*fptr) (farg, rptr))
    {
      close(fd);
      return id;
    }
    id++;
  }
  close(fd);
  return 0;
}


/* ------------------------------------------ */
/* mail / post �ɡA�̾ڮɶ��إ��ɮסA�[�W�l�W */
/* ------------------------------------------ */
/*
 * Input: fh->filename = directory; Output: fpath = full path;
 */

void
stampfile(fpath, fh)
  char *fpath;
  fileheader *fh;
{
  char *ip;
  time_t dtime;
  struct tm *ptime;
  int fp;

#if 0
  if (access(fh->filename, X_OK | R_OK | W_OK))
    mkdir(fh->filename, 0755);
#endif

  time(&dtime);
  sprintf(fpath, "%s/M.%d.A", fh->filename, dtime);
  ip = (char *) strrchr(fpath, 'A');

  while ((fp = open(fpath, O_CREAT | O_EXCL | O_WRONLY, 0644)) == -1)
  {
    if (*ip == 'Z')
    {
      ip++;
      *ip = 'A';
      *(ip + 1) = '\0';
    }
    else
      (*ip)++;
  }
  close(fp);
  memset(fh, 0, sizeof(fileheader));
  ip = (char *) strrchr(fpath, '/');
  strcpy(fh->filename, ip + 1);
  ptime = localtime(&dtime);
  sprintf(fh->date, "%2d/%02d", ptime->tm_mon + 1, ptime->tm_mday);
}
