#include "bbs.h"
#include <time.h>

long atol();
extern cmpbnames();
extern int numboards;


static char STR_bv_control[] = "control";
static char STR_bv_desc[] = "desc";
static char STR_bv_temp[] = "temp";
static char STR_bv_ballots[] = "ballots";
static char STR_bv_results[] = "results";
static char STR_bv_flags[] = "flags";


int
b_suckinfile(fp, fname)
  FILE *fp;
  char *fname;
{
  char inbuf[256];
  FILE *sfp;
  if ((sfp = fopen(fname, "r")) == NULL)
    return -1;
  while (fgets(inbuf, sizeof(inbuf), sfp))
    fputs(inbuf, fp);
  fclose(sfp);
  return 0;
}


int
b_closepolls()
{
  struct boardheader fh;
  struct stat st;
  FILE *cfp;
  char buf[80];
  time_t now;
  int fd;

  now = time(NULL);
  if (stat(str_vote_polling, &st) != -1 && st.st_mtime > now - 3600)
  {
    return 0;
  }
  if ((cfp = fopen(str_vote_polling, "w")) == NULL)
    return 0;
  fprintf(cfp, ctime(&now));
  fclose(cfp);

  resolve_boards();
  if ((fd = open(str_boards, O_RDWR)) == -1)
  {
    outs(err_board_open);
    return -1;
  }

  flock(fd, LOCK_EX);
  while (read(fd, &fh, sizeof(fh)) == sizeof(fh))
  {
    if (fh.bvote && b_close(&fh))
    {
      lseek(fd, -sizeof(boardheader), SEEK_CUR);	/* back up */
      if (write(fd, &fh, sizeof(fh)) != sizeof(fh))
	break;
    }
  }
  touch_boards();		/* vote flag changed */
  flock(fd, LOCK_UN);
  close(fd);
  return 0;
}


int
b_close(fh)
  struct boardheader *fh;
{
  FILE *cfp, *tfp;
  char *bname;
  char buf[STRLEN];
  char inchar, inbuf[80];
  int counts[10], fd;
  int total, num;
  char b_control[64];
  char b_newresults[64];
  time_t now;

  now = time(NULL);

  if (fh->bvote == 2)
  {
    if (fh->vtime < now - 7 * 86400)
    {
      fh->bvote = 0;
      return 1;
    }
    else
      return 0;
  }

  if (fh->vtime > now)
    return 0;

  fh->bvote = 2;
  bname = fh->brdname;
  setbfile(buf, bname, STR_bv_control);
  setbfile(b_control, bname, STR_bv_temp);
  if (rename(buf, b_control) == -1)
    return 1;

#ifdef	HAVE_REPORT
  b_report("CLOSE");
#endif

  memset(counts, 0, sizeof(counts));
  setbfile(buf, bname, STR_bv_flags);
  unlink(buf);
  setbfile(buf, bname, STR_bv_ballots);
  if ((fd = open(buf, O_RDONLY)) != -1)
  {
    while (read(fd, &inchar, 1) == 1)
      counts[(int) (inchar - '0')]++;
    close(fd);
  }
  unlink(buf);

  setbfile(b_newresults, bname, "newresults");
  if ((tfp = fopen(b_newresults, "w")) == NULL)
    return 1;

  fprintf(tfp, "%s\n�� �벼�����: %s\n�� �����D�شy�z:\n\n",
    msg_seperator, ctime(&fh->vtime));

  setbfile(buf, bname, STR_bv_desc);
  b_suckinfile(tfp, buf);
  unlink(buf);

  fprintf(tfp, "�� �벼���G:\n\n");
  total = 0;
  if (cfp = fopen(b_control, "r"))
  {
    fgets(inbuf, sizeof(inbuf), cfp);
    while (fgets(inbuf, sizeof(inbuf), cfp))
    {
      inbuf[(strlen(inbuf) - 1)] = '\0';
      inbuf[43] = '\0';		/* truncate */
      num = counts[inbuf[0] - '0'];
      fprintf(tfp, "    %-42s%3d ��\n", inbuf + 3, num);
      total += num;
    }
    fclose(cfp);
  }
  unlink(b_control);

  fprintf(tfp, "\n�� �`���� = %d ��\n\n", total);
  setbfile(buf, bname, STR_bv_results);
  b_suckinfile(tfp, buf);
  fclose(tfp);
  rename(b_newresults, buf);
  return 1;
}


int
vote_maintain(bname)
  char *bname;
{
  FILE *fp;
  char inbuf[STRLEN], buf[STRLEN];
  int num = 0, aborted;
  time_t closetime;
  int pos;
  struct boardheader fh;

  if (!HAS_PERM(PERM_SYSOP))
    if ((!HAS_PERM(PERM_BM)) || !strstr(currBM, cuser.userid))
      return 0;

  stand_title("�|��벼");

  setbfile(buf, bname, STR_bv_control);
  if ((fp = fopen(buf, "r")))
  {
    int counts[10], fd, total;
    char inchar;

    fgets(inbuf, sizeof(inbuf), fp);
    closetime = (time_t) atol(inbuf);
    prints("�P�ɶ����L�k�|���ӥH�W���벼�C\n�����벼�w�p������: %s",
      ctime(&closetime));

    memset(counts, 0, sizeof(counts));
    setbfile(buf, bname, STR_bv_ballots);
    if ((fd = open(buf, O_RDONLY)) != -1)
    {
      while (read(fd, &inchar, 1) == 1)
	counts[(int) (inchar - '0')]++;
      close(fd);
    }

    outs("\n�� �w���벼����:\n\n");
    total = 0;
    while (fgets(inbuf, sizeof(inbuf), fp))
    {
      inbuf[(strlen(inbuf) - 1)] = '\0';
      inbuf[43] = '\0';		/* truncate */
      num = counts[inbuf[0] - '0'];
      prints("   %-45s%3d ��\n", inbuf, num);
      total += num;
    }
    fclose(fp);

    prints("\n�� �ثe�`���� = %d ��", total);

    getdata(b_lines, 0, "(A)�����벼 (B)�����}�� [C]�~��G", genbuf, 4, DOECHO);
    if (genbuf[0] == 'a' || genbuf[0] == 'A')
    {
      setbfile(buf, bname, STR_bv_control);
      unlink(buf);
      setbfile(buf, bname, STR_bv_flags);
      unlink(buf);
      setbfile(buf, bname, STR_bv_ballots);
      unlink(buf);
      setbfile(buf, bname, STR_bv_desc);
      unlink(buf);

      pos = search_record(str_boards, &fh, sizeof(fh), cmpbnames, (int) bname);
      fh.bvote = 0;
      if (substitute_record(str_boards, &fh, sizeof(fh), pos) == -1)
	outs(err_board_update);
      touch_boards();		/* vote flag changed */
      resolve_boards();
    }
    else if (genbuf[0] == 'b' || genbuf[0] == 'B')
    {
      char b_newresults[80];
      FILE *tfp;

      setbfile(b_newresults, bname, "newresults");
      tfp = fopen(b_newresults, "w");

      fprintf(tfp, "%s\n�� �벼�����: %s\n�� �����D�شy�z:\n\n",
	msg_seperator, ctime(&closetime));

      setbfile(buf, bname, STR_bv_flags);
      unlink(buf);
      setbfile(buf, bname, STR_bv_ballots);
      unlink(buf);
      setbfile(buf, bname, STR_bv_desc);
      b_suckinfile(tfp, buf);
      unlink(buf);

      fprintf(tfp, "�� �벼���G:\n\n");
      total = 0;
      setbfile(buf, bname, STR_bv_control);
      if (fp = fopen(buf, "r"))
      {
	fgets(inbuf, sizeof(inbuf), fp);
	while (fgets(inbuf, sizeof(inbuf), fp))
	{
	  inbuf[(strlen(inbuf) - 1)] = '\0';
	  inbuf[43] = '\0';	/* truncate */
	  num = counts[inbuf[0] - '0'];
	  fprintf(tfp, "    %-42s%3d ��\n", inbuf + 3, num);
	  total += num;
	}
	fclose(fp);
      }
      unlink(buf);

      fprintf(tfp, "\n�� �`���� = %d ��\n\n", total);
      setbfile(buf, bname, STR_bv_results);
      b_suckinfile(tfp, buf);
      fclose(tfp);
      rename(b_newresults, buf);

      pos = search_record(str_boards, &fh, sizeof(fh), cmpbnames, (int) bname);
      fh.bvote = 2;
      if (substitute_record(str_boards, &fh, sizeof(fh), pos) == -1)
	outs(err_board_update);
      touch_boards();		/* vote flag changed */
      resolve_boards();
    }
    return FULLUPDATE;
  }

  outs("��������}�l�s�覹�� [�벼�v��]:");
  igetch();
  setbfile(buf, bname, STR_bv_desc);
  aborted = vedit(buf, NA);
  if (aborted)
  {
    clear();
    outs("���������벼");
    pressanykey();
    return FULLUPDATE;
  }
  setbfile(buf, bname, STR_bv_flags);
  unlink(buf);

  clear();
  getdata(0, 0, "�����벼�i��X�� (�ܤ֢���)? ", inbuf, 4, DOECHO);

  if (*inbuf == '\n' || !strcmp(inbuf, "0") || *inbuf == '\0')
    strcpy(inbuf, "1");

  time(&closetime);
  closetime += atol(inbuf) * 86400;
  setbfile(buf, bname, STR_bv_control);
  fp = fopen(buf, "w");
  fprintf(fp, "%lu\n", closetime);
  fflush(fp);

  outs("�Ш̧ǿ�J�ﶵ, �� ENTER �����]�w");
  num = 0;
  while (!aborted)
  {
    sprintf(buf, "%2d) ", num + 1);
    getdata(num + 2, 10, buf, inbuf, 40, DOECHO);
    if (*inbuf)
    {
      num = (num + 1) % 10;
      fprintf(fp, "%1d) %s\n", num, inbuf);
    }
    if (*inbuf == '\0' || num == 0)
      aborted = 1;
  }
  fclose(fp);

  pos = search_record(str_boards, &fh, sizeof(fh), cmpbnames, (int) bname);
  fh.bvote = 1;
  fh.vtime = closetime;
  if (substitute_record(str_boards, &fh, sizeof(fh), pos) == -1)
    outs(err_board_update);
  touch_boards();		/* vote flag changed */

#ifdef	HAVE_REPORT
  b_report("OPEN");
#endif

  outs("�}�l�벼�F�I");
  pressanykey();
  return FULLUPDATE;
}


int
vote_flag(bname, val)
  char *bname, val;
{
  char buf[256], flag;
  int fd, num, size;

  num = usernum - 1;
  setbfile(buf, bname, STR_bv_flags);
  if ((fd = open(buf, O_RDWR | O_CREAT, 0600)) == -1)
  {
    return -1;
  }
  size = lseek(fd, 0, SEEK_END);
  memset(buf, 0, sizeof(buf));
  while (size <= num)
  {
    write(fd, buf, sizeof(buf));
    size += sizeof(buf);
  }
  lseek(fd, num, SEEK_SET);
  read(fd, &flag, 1);
  if (flag == 0 && val != 0)
  {
    lseek(fd, num, SEEK_SET);
    write(fd, &val, 1);
  }
  close(fd);
  return flag;
}


int
user_vote(bname)
  char *bname;
{
  FILE *cfp;
  char buf[STRLEN];
  char inbuf[80], choices[10], vote[2];
  int fd, count = 0;
  time_t closetime;

  setbfile(buf, bname, STR_bv_control);
  move(3, 0);
  clrtobot();
  if ((cfp = fopen(buf, "r")) == NULL)
  {
    outs("\n�ثe�èS������벼�|��C");
    pressanykey();
    return FULLUPDATE;
  }

  if (vote_flag(bname, '\0'))
  {
    outs("\n�����벼, �A�w��L�F!�@�H�@��, �j�a�����C");
    fclose(cfp);
    pressanykey();
    return FULLUPDATE;
  }

  modify_user_mode(VOTING);
  setbfile(buf, bname, STR_bv_desc);
  more(buf, YEA);

  stand_title("�벼�c");
  fgets(inbuf, sizeof(inbuf), cfp);
  closetime = (time_t) atol(inbuf);
  prints("�벼�覡�G�T�w�n�z����ܫ�A��J��Ʀr�N�X�Y�i;\n"
    "����L������벼�C\n�����벼�N������G%s\n",
    ctime(&closetime));

  move(6, 0);
  memset(choices, 0, sizeof(choices));
  while (fgets(inbuf, sizeof(inbuf), cfp))
  {
    choices[count++] = inbuf[0];
    outs(inbuf);
  }
  fclose(cfp);
  vote[0] = vote[1] = '\0';
  getdata(count + 8, 0, "��J�z�����: ", vote, 2, DOECHO);
  move(count + 10, 0);
  if (vote[0] == '\0' || index(choices, vote[0]) == NULL)
    outs("���X�k�����, �Э��s�벼�C\n");
  else if (vote_flag(bname, vote[0]) != 0)
    prints("���Ч벼! �����p���C");
  else
  {
    setbfile(buf, bname, STR_bv_ballots);
    if ((fd = open(buf, O_WRONLY | O_CREAT | O_APPEND, 0600)) == 0)
      outs("�L�k��J���o\n");
    else
    {
      struct stat statb;

      flock(fd, LOCK_EX);
      write(fd, vote, 1);
      flock(fd, LOCK_UN);
      fstat(fd, &statb);
      close(fd);
      prints("�w�����벼�I(�ثe�w�벼��: %d)\n", statb.st_size);
      /* numboards = -1;  /* opus : un-necessary */

#ifdef	HAVE_REPORT
      b_report("VOTE");
#endif
    }
  }
  pressanykey();
  return FULLUPDATE;
}


int
vote_results(bname)
  char *bname;
{
  char buf[STRLEN];

  setbfile(buf, bname, STR_bv_results);
  if (more(buf, YEA) == -1)
  {
    move(3, 0);
    clrtobot();
    outs("\n�ثe�S������벼�����G�C");
    pressanykey();
  }
  return FULLUPDATE;
}



int
b_vote_maintain()
{
  return vote_maintain(currboard);
}


int
b_vote()
{
  return user_vote(currboard);
}


int
b_results()
{
  return vote_results(currboard);
}


#ifdef	SYS_VOTE
int
m_vote()
{
  return vote_maintain(str_def_board);
}


int
x_vote()
{
  return user_vote(str_def_board);
}


int
x_results()
{
  return vote_results(str_def_board);
}
#endif				/* SYS_VOTE */



#ifdef	HAVE_REPORT
b_report(s)
  char *s;
{
  static int disable = NA;
  int fd;

  if (disable)
    return;
  if ((fd = open("trace.bvote", O_WRONLY, 0644)) != -1)
  {
    char buf[512];
    char timestr[18], *thetime;
    time_t dtime;

    time(&dtime);
    thetime = ctime(&dtime);
    strncpy(timestr, &(thetime[4]), 15);
    timestr[15] = '\0';
    flock(fd, LOCK_EX);
    lseek(fd, 0, L_XTND);
    sprintf(buf, "%s %-12s %-20s %s\n", timestr, cuser.userid, currboard, s);
    write(fd, buf, strlen(buf));
    flock(fd, LOCK_UN);
    close(fd);
    return;
  }
  disable = YEA;
  return;
}
#endif				/* HAVE_REPORT */
