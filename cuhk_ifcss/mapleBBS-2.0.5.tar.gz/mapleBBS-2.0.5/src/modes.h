/* modes.h */

/* user �ާ@���A�P�Ҧ� */

#define IDLE		0
#define MMENU		1	/* menu mode */
#define ADMIN		2
#define MAIL		3
#define TMENU		4
#define UMENU		5
#define XMENU		6
#define CLASS		7

#define LOGIN		8	/* main menu */

#define ANNOUNCE	9	/* announce */

#define POSTING		10	/* boards & class */
#define READBRD		11
#define READING		12
#define READNEW		13
#define SELECT		14

#define RMAIL		15	/* mail menu */
#define SMAIL		16

#define CHATING		17	/* talk menu */
#define CHAT2		18
#define FRIEND		19
#define LAUSERS		20
#define LUSERS		21
#define MONITOR		22
#define PAGE		23
#define QUERY		24
#define TALK		25

#define EDITPLAN	26	/* user menu */
#define EDITSIG		27
#define VOTING		28
#define XINFO		29

#define CHAT3		0
#define CHAT4		0
#define IRCCHAT		0
#define BBSNET		0
#define FOURM		0
#define CSIE_GOPHER	0
#define CSIE_TIN	0
#define EDITWELC	0


#ifdef	_MODES_C_
static char *ModeTypeTable[] =
{
  "�o�b",			/* IDLE */
  "�D���",			/* MMENU */
  "�t�κ��@",			/* ADMIN */
  "�l����",			/* MAIL */
  "��Ϳ��",			/* TMENU */
  "�ϥΪ̿��",			/* UMENU */
  "XYZ ���",			/* XMENU */
  "���հQ�װ�",			/* CLASS */
  "�W���~��",			/* LOGIN */
  "���G��",			/* ANNOUNCE */
  "�o���峹",			/* POSTING */
  "�Q�װϦC��",			/* READBRD */
  "�\\Ū�峹",			/* READING */
  "�s�峹�C��",			/* READNEW */
  "��ܰQ�װ�",			/* SELECT */
  "Ū�H",			/* RMAIL */
  "�g�H",			/* SMAIL */
  "��ѫ�",			/* CHATING */
  "Chat-2",			/* CHAT2 */
  "�M��n��",			/* FRIEND */
  "�W�u�ϥΪ�",			/* LAUSERS */
  "�ϥΪ̦W��",			/* LUSERS */
  "�l�ܯ���",			/* MONITOR */
  "�I�s",			/* PAGE */
  "�d��",			/* QUERY */
  "���",			/* TALK	 */
  "�s��W����",			/* EDITPLAN */
  "�s��ñ�W��",			/* EDITSIG */
  "�벼��",			/* VOTING */
  "�]�w���"			/* XINFO */
};
#endif	/* _MODES_C_ */


/* read.c �����Ҧ� */


#define RS_FORWARD      0x01    /* backward */
#define RS_TITLE        0x02    /* author */
#define RS_RELATED      0x04
#define RS_FIRST        0x08	/* find first article */
#define RS_CURRENT      0x10	/* match current read article */


#define DONOTHING	0	/* Read menu command return states */
#define FULLUPDATE	1	/* Entire screen was destroyed in this oper */
#define PARTUPDATE	2	/* Only the top three lines were destroyed */
#define DOQUIT		3	/* Exit read menu was executed */
#define NEWDIRECT	4	/* Directory has changed, re-read files */
#define READ_NEXT	5	/* Direct read next file */
#define READ_PREV	6	/* Direct read prev file */
#define DIRCHANGED	8	/* Index file was changed */
#define READ_REDRAW	9
#define RELATE_NEXT	(RS_RELATED | RS_TITLE | RS_FORWARD | RS_CURRENT)
#define RELATE_PREV	(RS_RELATED | RS_TITLE | RS_CURRENT)

#define	MAIL_LIST	2
