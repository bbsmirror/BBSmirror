/* board.c */

#include "bbs.h"


#define BRC_MAXSIZE     32768
#define BRC_MAXNUM      60
#define BRC_STRLEN      15
#define BRC_ITEMSIZE    (BRC_STRLEN + 1 + BRC_MAXNUM * sizeof( int ))
#define UNREAD_TIME     (login_start_time - 30 * 86400)

char brc_buf[BRC_MAXSIZE];
int brc_size, brc_changed = 0;
char brc_name[BRC_STRLEN];
int brc_list[BRC_MAXNUM], brc_num;

extern time_t login_start_time;
extern int numboards;
extern boardheader *bcache;

struct newpostdata
{
  char *name, *title, *BM;
  int pos, total;
  char unread, zap, bvote;
}          *nbrd;

int *zapbuf;
int brdnum, yank_flag = 0;
char *boardprefix;


static char *str_local_board = "����";

static char *my_op2 = "[1;33;46m  ��ܬݪO  [45m  [c][36m�s�峹�Ҧ�  [33m[v][36m�аO�wŪ  [33m[y][36m�z��%s  [33m[z][36m�������  [0m";


/* --------------------------------------------- */
/* home/userid/.boardrc maintain		 */
/* --------------------------------------------- */

static char *str_boardrc = ".boardrc";


char *
brc_getrecord(ptr, name, pnum, list)
  char *ptr, *name;
  int *pnum, *list;
{
  int num;
  char *tmp;

  strncpy(name, ptr, BRC_STRLEN);
  ptr += BRC_STRLEN;
  num = (*ptr++) & 0xff;
  tmp = ptr + num * sizeof(int);
  if (num > BRC_MAXNUM)
  {
    num = BRC_MAXNUM;
  }
  *pnum = num;
  memcpy(list, ptr, num * sizeof(int));
  return tmp;
}


char *
brc_putrecord(ptr, name, num, list)
  char *ptr, *name;
  int num, *list;
{
  if (num > 0 && list[0] > UNREAD_TIME)
  {
    if (num > BRC_MAXNUM)
    {
      num = BRC_MAXNUM;
    }
    while (num > 1 && list[num - 1] < UNREAD_TIME)
    {
      num--;
    }
    strncpy(ptr, name, BRC_STRLEN);
    ptr += BRC_STRLEN;
    *ptr++ = num;
    memcpy(ptr, list, num * sizeof(int));
    ptr += num * sizeof(int);
  }
  return ptr;
}


void
brc_update()
{
  if (brc_changed)
  {
    char dirfile[STRLEN], *ptr;
    char tmp_buf[BRC_MAXSIZE - BRC_ITEMSIZE], *tmp;
    char tmp_name[BRC_STRLEN];
    int tmp_list[BRC_MAXNUM], tmp_num;
    int fd, tmp_size;

    ptr = brc_buf;
    if (brc_num > 0)
    {
      ptr = brc_putrecord(ptr, brc_name, brc_num, brc_list);
    }

    setuserfile(dirfile, str_boardrc);
    if ((fd = open(dirfile, O_RDONLY)) != -1)
    {
      tmp_size = read(fd, tmp_buf, sizeof(tmp_buf));
      close(fd);
    }
    else
    {
      tmp_size = 0;
    }

    tmp = tmp_buf;
    while (tmp < &tmp_buf[tmp_size] && (*tmp >= ' ' && *tmp <= 'z'))
    {
      tmp = brc_getrecord(tmp, tmp_name, &tmp_num, tmp_list);
      if (strncmp(tmp_name, currboard, BRC_STRLEN))
      {
	ptr = brc_putrecord(ptr, tmp_name, tmp_num, tmp_list);
      }
    }
    brc_size = (int) (ptr - brc_buf);

    if ((fd = open(dirfile, O_WRONLY | O_CREAT, 0644)) != -1)
    {
      ftruncate(fd, 0);
      write(fd, brc_buf, brc_size);
      close(fd);
    }
    brc_changed = 0;
  }
}


int
brc_initial(boardname)
  char *boardname;
{
  char dirfile[STRLEN], *ptr;
  int fd;

  if (strcmp(currboard, boardname) == 0)
  {
    return brc_num;
  }
  brc_update();
  strcpy(currboard, boardname);
  if (brc_buf[0] == '\0')
  {
    setuserfile(dirfile, str_boardrc);
    if ((fd = open(dirfile, O_RDONLY)) != -1)
    {
      brc_size = read(fd, brc_buf, sizeof(brc_buf));
      close(fd);
    }
    else
    {
      brc_size = 0;
    }
  }
  ptr = brc_buf;
  while (ptr < &brc_buf[brc_size] && (*ptr >= ' ' && *ptr <= 'z'))
  {
    ptr = brc_getrecord(ptr, brc_name, &brc_num, brc_list);
    if (strncmp(brc_name, currboard, BRC_STRLEN) == 0)
    {
      return brc_num;
    }
  }
  strncpy(brc_name, boardname, BRC_STRLEN);
  brc_num = brc_list[0] = 1;
  return 0;
}


void
brc_addlist(filename)
  char *filename;
{
  int ftime, n, i;

  ftime = atoi(&filename[2]);
  if (filename[0] != 'M' || filename[1] != '.' || ftime <= UNREAD_TIME)
  {
    return;
  }
  if (brc_num <= 0)
  {
    brc_list[brc_num++] = ftime;
    brc_changed = 1;
    return;
  }
  for (n = 0; n < brc_num; n++)
  {
    if (ftime == brc_list[n])
    {
      return;
    }
    else if (ftime > brc_list[n])
    {
      if (brc_num < BRC_MAXNUM)
	brc_num++;
      for (i = brc_num - 1; i > n; i--)
      {
	brc_list[i] = brc_list[i - 1];
      }
      brc_list[n] = ftime;
      brc_changed = 1;
      return;
    }
  }
  if (brc_num < BRC_MAXNUM)
  {
    brc_list[brc_num++] = ftime;
    brc_changed = 1;
  }
}


int
brc_unread(filename)
  char *filename;
{
  int ftime, n;

  ftime = atoi(&filename[2]);
  if (filename[0] != 'M' || filename[1] != '.' || ftime <= UNREAD_TIME)
    return 0;
  if (brc_num <= 0)
    return 1;
  for (n = 0; n < brc_num; n++)
  {
    if (ftime > brc_list[n])
      return 1;
    else if (ftime == brc_list[n])
      return 0;
  }
  return 0;
}


/* ------------------------------------- */
/* .bbsrc processing			 */
/* ------------------------------------- */

char *str_bbsrc = ".bbsrc";

void
load_zapbuf()
{
  char fname[60];
  int fd, size, n;

  /* opus: MAXBOARDS ==> �ܦh�ݪ����Q�ӷs�O */
  size = (numboards + 10) * sizeof(int);
  zapbuf = (int *) malloc(size);
  for (n = 0; n < numboards + 10; n++)
    zapbuf[n] = login_start_time;
  setuserfile(fname, str_bbsrc);
  if ((fd = open(fname, O_RDONLY, 0600)) != -1)
  {
    size = numboards * sizeof(int);
    read(fd, zapbuf, size);
    close(fd);
  }
}


void
save_zapbuf()
{
  char fname[60];
  int fd, size;

  setuserfile(fname, str_bbsrc);
  if ((fd = open(fname, O_WRONLY | O_CREAT, 0600)) != -1)
  {
    size = numboards * sizeof(int);
    write(fd, zapbuf, size);
    close(fd);
  }
}


int
Ben_Perm(bptr)
  boardheader *bptr;
{
  register char *p, ch;
  char buf[64], manager[IDLEN + 1];
  int i;

  if ((bptr->level & PERM_POSTMASK) || HAS_PERM(bptr->level))
    return 1;

  p = bptr->BM;
  if (p[0] <= ' ')
    return 0;

  if (strstr(p, cuser.userid))
    return 1;

  /* ���K�ݪO */

  for (i = 0; (ch = p[i]) != '/'; i++)
  {
    manager[i] = ch;
    if (ch == '\0')
      break;
  }
  sethomefile(buf, manager, "overrides");
  return (belong(buf, cuser.userid));
}


void
load_boards()
{
  boardheader *bptr;
  struct newpostdata *ptr;
  char brdclass[5];
  int n;

  resolve_boards();
  if (zapbuf == NULL)
  {
    load_zapbuf();
  }
  brdnum = 0;
  for (n = 0; n < numboards; n++)
  {
    bptr = &bcache[n];
    if (bptr->brdname[0] == '\0')
      continue;
    if (!Ben_Perm(bptr))
      continue;
    if (boardprefix)
    {
      if (boardprefix == str_local_board)
      {
	strncpy(brdclass, bptr->title + 4, 2);
	brdclass[2] = '\0';
      }
      else
      {
	strncpy(brdclass, bptr->title, 4);
	brdclass[4] = '\0';
      }
      if (strstr(boardprefix, brdclass) == NULL)
	continue;
    }
    if (yank_flag || zapbuf[n])
    {
      ptr = &nbrd[brdnum++];
      ptr->name = bptr->brdname;
      ptr->title = bptr->title;
      ptr->BM = bptr->BM;
      ptr->bvote = bptr->bvote;
      ptr->pos = n;
      ptr->total = -1;
      ptr->zap = (zapbuf[n] == 0);
    }
  }
}


int
search_board(num)
{
  int n;
  int len;

  move(b_lines);
  clrtoeol();
  getdata(b_lines, 0, "�п�J�n��M���G�i�W��:", genbuf, 12, DOECHO);
  len = strlen(genbuf);
  move(b_lines, 0);
  clrtoeol();

  if (genbuf[0])
  {
    n = num + 1;
    while (n != num)
    {
      if (!strncasecmp(nbrd[n].name, genbuf, len))
	return n;
      if (++n >= brdnum)
	n = 0;
    }
  }
  return -1;
}


int
check_newpost(ptr)
  struct newpostdata *ptr;
{
  struct fileheader fh;
  struct stat st;
  char filename[FNLEN];
  int fd, total;

  ptr->total = ptr->unread = 0;
  setbdir(genbuf, ptr->name);
  if ((fd = open(genbuf, O_RDWR)) < 0)
    return 0;
  fstat(fd, &st);
  total = st.st_size / sizeof(fh);
  if (total <= 0)
  {
    close(fd);
    return 0;
  }
  ptr->total = total;
  if (!brc_initial(ptr->name))
  {
    ptr->unread = 1;
  }
  else
  {
    lseek(fd, (total - 1) * sizeof(fh), SEEK_SET);
    if (read(fd, filename, FNLEN) > 0 && brc_unread(filename))
    {
      ptr->unread = 1;
    }
  }
  close(fd);
  return 1;
}


int
unread_position(dirfile, ptr)
  char *dirfile;
  struct newpostdata *ptr;
{
  struct fileheader fh;
  char filename[FNLEN];
  int fd, step, num;

  num = ptr->total + 1;
  if (ptr->unread && (fd = open(dirfile, O_RDWR)) > 0)
  {
    if (!brc_initial(ptr->name))
    {
      num = 1;
    }
    else
    {
      num = ptr->total - 1;
      step = 4;
      while (num > 0)
      {
	lseek(fd, num * sizeof(fh), SEEK_SET);
	if (read(fd, filename, FNLEN) <= 0 || !brc_unread(filename))
	  break;
	num -= step;
	if (step < 32)
	  step += step >> 1;
      }
      if (num < 0)
	num = 0;
      while (num < ptr->total)
      {
	lseek(fd, num * sizeof(fh), SEEK_SET);
	if (read(fd, filename, FNLEN) <= 0 || brc_unread(filename))
	  break;
	num++;
      }
    }
    close(fd);
  }
  if (num < 0)
    num = 0;
  return num;
}


int
search_num(ch, max)
{
  int clen = 1;
  int x, y;
  extern unsigned char scr_cols;

  move(b_lines, 0);
  clrtoeol();
  refresh();
  outs("[1;45m ���ܲĴX���G[m");
  outc(ch);
  genbuf[0] = ch;
  getyx(&y, &x);
  x--;
  while ((ch = igetch()) != '\r')
  {
    if (ch == 'q' || ch == 'e')
      return -1;
    if (ch == '\n')
      break;
    if (ch == '\177' || ch == Ctrl('H'))
    {
      if (clen == 0)
      {
	bell();
	continue;
      }
      clen--;
      move(y, x + clen);
      outc(' ');
      move(y, x + clen);
      continue;
    }
    if (!isdigit(ch))
    {
      bell();
      continue;
    }
    if (x + clen >= scr_cols || clen >= 6)
    {
      bell();
      continue;
    }
    genbuf[clen++] = ch;
    outc(ch);
  }
  genbuf[clen] = '\0';
  refresh();
  move(b_lines, 0);
  clrtoeol();
  if (genbuf[0] == '\0')
    return -1;
  clen = atoi(genbuf);
  if (clen == 0)
    return 0;
  if (clen > max)
    return max;
  return clen - 1;
}


void
show_brdlist(page, clsflag, newflag)
{
  static char vote_flags[3] = " VR";	/* �T�q���G�L�B�벼�B�}�� */
  struct newpostdata *ptr;
  int n, myrow;

  if (clsflag)
  {
    showtitle("�G�i�Q�װ�", BoardName);
    outs("�D���[��,e]  �\\Ū[��,r,<cr>]  ���[��,��]  �C�X[y]  �Ƨ�[s]  �j�M[/]  �D�U[h]\n");

    standout();
    prints("%s ��  �O %-32s�벼 �O    �D     ",
      newflag ? "�`�� ��Ū �Q�װϦW��" : "  �s��  �Q�װϦW��  ", "��   ��   ��   �z");
    standend();
    move(b_lines, 0);
    prints(my_op2, yank_flag ? "����" : "����");
  }

  if (brdnum > 0)
    for (n = page, myrow = 3; myrow < b_lines; n++)
    {
      move(myrow++, 0);
      clrtoeol();
      if (n < brdnum)
      {
	ptr = &nbrd[n];
	if (!newflag)
	  prints("%5d %c ", n + 1, ptr->zap ? '-' : ' ');
	else if (ptr->zap)
	{
	  ptr->total = ptr->unread = 0;
	  outs("   �� ��");
	}
	else
	{
	  if (ptr->total == -1)
	  {
	    refresh();
	    check_newpost(ptr);
	  }
	  prints("%6d%s", ptr->total, ptr->unread ? "�E" : "�C");
	}

	prints("%-13s%-42s%c %-13.13s\n",
	  ptr->name, ptr->title, vote_flags[ptr->bvote], ptr->BM);
      }
    }
  refresh();
}


char *choosebrdhelp[] = {
  "\0�ݪO��滲�U����",
  "\01�򥻫��O",
  "[p][��]        �W�@�ӰQ�װ�",
  "[n][��]        �U�@�ӰQ�װ�",
  "[P][^B][PgUp]  �W�@���Q�װ�",
  "[N][^F][PgDn]  �U�@���Q�װ�",
  "[$]            �̫�@�ӰQ�װ�",
  "[�Ʀr]         ���ܸӶ���",
  "\01�i�����O",
  "[r][��][Rtn]   �i�J�h�\\��\\Ū���",
  "[q][��]        �^��D���",
  "[z]            �q�\\/�ϭq�\\�Q�װ�",
  "[y]            �C�X/���C�X�Ҧ��Q�װ�",
  "[s]            �Q�װϫ��Ӧr��/�����Ƨ�",
  "[/]            �j�M�Q�װ�",
NULL};


/* �ھ� title / name �� sort */

int
cmpboard(brd, tmp)
  struct newpostdata *brd, *tmp;
{
  register int type = 0;

  if (!(cuser.uflag & BRDSORT_FLAG))
    type = strncmp(brd->title, tmp->title, 4);
  if (type == 0)
    type = strcasecmp(brd->name, tmp->name);
  return type;
}


void
choose_board(newflag)
{
  static int num;
  struct newpostdata newpost_buffer[MAXBOARD];
  struct newpostdata *ptr;
  int page, ch, tmp;
  extern time_t board_visit_time;

  if (!strcmp(cuser.userid, str_guest))
    yank_flag = 1;
  nbrd = newpost_buffer;
  modify_user_mode(newflag ? READNEW : READBRD);
  brdnum = 0;

  do
  {
    if (brdnum <= 0)
    {
      load_boards();
      if (brdnum <= 0)
	break;
      qsort(nbrd, brdnum, sizeof(nbrd[0]), cmpboard);
      page = -1;
    }

    if (num < 0)
      num = 0;
    if (num >= brdnum)
      num = brdnum - 1;

    if (page < 0)
    {
      if (newflag)
      {
	tmp = num;
	while (num < brdnum)
	{
	  ptr = &nbrd[num];
	  if (ptr->total == -1)
	    check_newpost(ptr);
	  if (ptr->unread)
	    break;
	  num++;
	}
	if (num >= brdnum)
	  num = tmp;
      }
      page = (num / p_lines) * p_lines;
      show_brdlist(page, 1, newflag);
    }
    if (num < page || num >= page + p_lines)
    {
      page = (num / p_lines) * p_lines;
      show_brdlist(page, 0, newflag);
    }

    /* opus : cursor position */

    move(3 + num - page, 0);
    outs(str_cursor);
    move(3 + num - page, 1);
    ch = egetch();
    move(3 + num - page, 0);
    outs(str_uncur);

    switch (ch)
    {
    case 'e':
    case KEY_LEFT:
    case EOF:
      ch = 'q';
    case 'q':
      break;
    case 'c':
      newflag = (newflag == 0 ? 1 : 0);
      show_brdlist(page, 1, newflag);
      break;
    case 'P':
    case 'b':
    case Ctrl('B'):
    case KEY_PGUP:
      if (num == 0)
	num = brdnum - 1;
      else
	num -= p_lines;
      break;
    case 'N':
    case ' ':
    case Ctrl('F'):
    case KEY_PGDN:
      if (num == brdnum - 1)
	num = 0;
      else
	num += p_lines;
      break;
    case 'p':
    case 'k':
    case KEY_UP:
      if (num-- <= 0)
	num = brdnum - 1;
      break;
    case 'n':
    case 'j':
    case KEY_DOWN:
      if (++num >= brdnum)
	num = 0;
      break;
    case '0':
      num = 0;
      break;
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
    case '6':
    case '7':
    case '8':
    case '9':
      if ((tmp = search_num(ch, brdnum)) >= 0)
	num = tmp;
      move(b_lines, 0);
      prints(my_op2, yank_flag ? "����" : "����");
      break;
    case '$':
      num = brdnum - 1;
      break;
    case 'h':
      show_help(choosebrdhelp);
      show_brdlist(page, 1, newflag);
      break;
    case '/':
      if ((tmp = search_board(num)) >= 0)
	num = tmp;
      move(b_lines, 0);
      prints(my_op2, yank_flag ? "����" : "����");
      break;
    case 's':
      cuser.uflag ^= BRDSORT_FLAG;
      qsort(nbrd, brdnum, sizeof(nbrd[0]), cmpboard);
      page = 999;
      break;
    case 'y':
      yank_flag ^= 1;
      brdnum = -1;
      break;
    case 'z':			/* opus: no perm check ? */
      if (HAS_PERM(PERM_BASIC))
      {
	ptr = &nbrd[num];
	ptr->zap = !ptr->zap;
	ptr->total = -1;
	zapbuf[ptr->pos] = (ptr->zap ? 0 : login_start_time);
	page = 999;
      }
      break;
    case 'v':
      ptr = &nbrd[num];
      brc_initial(ptr->name);
      ptr->unread = 0;
      zapbuf[ptr->pos] = time(&brc_list[0]);
      brc_num = brc_changed = newflag = 1;
      brc_update();
      show_brdlist(page, 1, 1);
      break;
    case 'r':
    case '\n':
    case '\r':
    case KEY_RIGHT:
      {
	char buf[STRLEN];

	ptr = &nbrd[num];
	brc_initial(ptr->name);

	if (newflag)
	{
	  setbdir(buf, currboard);
	  tmp = unread_position(buf, ptr);
	  page = tmp - t_lines / 2;
	  getkeep(buf, page > 1 ? page : 1, tmp + 1);
	}
	selboard = 1;
	board_visit_time = zapbuf[ptr->pos];
	time(&zapbuf[ptr->pos]);
	Read();

#if 0
	if (zapbuf[ptr->pos] > 0 && brc_num > 0)
	{
	  zapbuf[ptr->pos] = brc_list[0];
	}
#endif

	ptr->total = page = -1;
	modify_user_mode(newflag ? READNEW : READBRD);
      }
    }
  } while (ch != 'q');
  save_zapbuf();
}


int
board()
{
  choose_board(0);
  return 0;
}


int
local_board()
{
  boardprefix = str_local_board;
  choose_board(0);
  return 0;
}


int
Boards()
{
  boardprefix = NULL;
  choose_board(0);
  return 0;
}


int
New()
{
  boardprefix = NULL;
  choose_board(1);
  return 0;
}
