/* bbs.c */

#define	_BBS_C_

#include "bbs.h"

extern char *filemargin();
extern char *ctime();
extern int mail_reply();

void cancelpost();
void do_reply();
void note();
void mail_sysop();

extern struct UCACHE *uidshm;
extern time_t login_start_time;
time_t board_note_time;
time_t board_visit_time;

int continue_flag;
int local_article;
int selboard = 0;

int usercounter, totalusers;
userec cuser;
int usernum;
char *currTitle, currfile[FNLEN];

#ifndef NOREPLY
char replytitle[TTLEN + 1];
#endif

#define	UPDATE_USEREC	cuser.uflag |= DIRTY_FLAG
/* substitute_record(str_passfile, &cuser, sizeof(userec), usernum) */


/* ---------------------------------- */
/* set file path for boards/user home */
/* ---------------------------------- */

char *str_home_file = "home/%s/%s";
char *str_board_file = "boards/%s/%s";
char *str_dotdir = ".DIR";


char *
sethomepath(buf, userid)
  char *buf, *userid;
{
  sprintf(buf, "home/%s", userid);
  return buf;
}


char *
sethomedir(buf, userid)
  char *buf, *userid;
{
  sprintf(buf, str_home_file, userid, str_dotdir);
  return buf;
}


char *
sethomefile(buf, userid, filename)
  char *buf, *userid, *filename;
{
  sprintf(buf, str_home_file, userid, filename);
  return buf;
}


char *
setuserfile(buf, filename)
  char *buf, *filename;
{
  sprintf(buf, str_home_file, cuser.userid, filename);
  return buf;
}


char *
setapath(buf, boardname)
  char *buf, *boardname;
{
  sprintf(buf, "man/%s", boardname);
  return buf;
}


char *
setbpath(buf, boardname)
  char *buf, *boardname;
{
  sprintf(buf, "boards/%s", boardname);
  return buf;
}


char *
setbdir(buf, boardname)
  char *buf, *boardname;
{
  sprintf(buf, str_board_file, boardname, str_dotdir);
  return buf;
}


char *
setbfile(buf, boardname, filename)
  char *buf, *boardname, *filename;
{
  sprintf(buf, str_board_file, boardname, filename);
  return buf;
}


void
setdirpath(buf, direct, fname)
  char *buf, *direct, *fname;
{
  strcpy(buf, direct);
  direct = strrchr(buf, '/');
  strcpy(direct + 1, fname);
}


char
uleveltochar(lvl)
  unsigned lvl;
{
  if (lvl == PERM_DEFAULT)
    return ' ';
  if (lvl < PERM_DEFAULT)
    return '-';
  if (lvl & PERM_SYSOP)
    return 'S';
  if (lvl & PERM_ACCOUNTS)
    return 'A';
  if (lvl & PERM_BM)
    return 'B';
  if (lvl & PERM_WELCOME)
    return 'W';
  if (lvl & PERM_XEMPT)
    return 'X';
  if (lvl & PERM_EMAILOK)
    return 'E';
  if (lvl & PERM_POSTMASK)
    return 'M';

  return '+';
}


char *
Cdate(clock)
  time_t *clock;
{
  static char foo[22];
  struct tm *mytm = localtime(clock);

  strftime(foo, 22, "%D %T %a", mytm);
  return (foo);
}


#ifdef  HAVE_CTIME
char *
Ctime(clock)
  time_t *clock;
{
  char *foo;
  char *ptr = ctime(clock);
  if (foo = strrchr(ptr, '\n'))
    *foo = '\0';
  return (ptr);
}
#endif


int
printuent(uentp)
  struct userec *uentp;
{
  static int i;
  char *ptr;

#if defined(REALINFO) && defined(ACTS_REALNAMES)
#define	field2	"�u��m�W"
#else
#define	field2	"�︹�ʺ�"
#endif

  if (uentp == NULL)
  {
    move(2, 0);
    prints(msg_usrlist, field2, HAS_PERM(PERM_SEEULEVELS) ? "����" : "");
    i = 2;
    return 0;
  }
  if (uentp->userid[0] == '\0')
    return 0;
  if (i == t_lines - 2)
  {
    int ch;
    prints("[46;1m  �w��� %d/%d �H(%d%%)  [45m  (Space) �ݤU�@��  (Q) ���}  [40;0m",
      usercounter, totalusers, usercounter * 100 / totalusers);
    clrtoeol();
    refresh();

    ch = igetch();
    if (ch == 'q' || ch == 'Q')
      return QUIT;

    move(2, 0);
    clrtobot();
    prints(msg_usrlist, field2, HAS_PERM(PERM_SEEULEVELS) ? "����" : "");
    i = 2;
  }
  clrtoeol();
  ptr = Cdate(&uentp->lastlogin);
  ptr[18] = '\0';
  prints("%-14s %-27.27s%5d %5d  %c %s\n",
    uentp->userid,

#if defined(REALINFO) && defined(ACTS_REALNAMES)
    uentp->realname,
#else
    uentp->username,
#endif

    uentp->numlogins, uentp->numposts,
    HAS_PERM(PERM_SEEULEVELS) ? uleveltochar(uentp->userlevel) : ' ', ptr);
  i++;
  usercounter++;
  return 0;
}


int
Users()
{
  modify_user_mode(LAUSERS);
  usercounter = 0;
  totalusers = uidshm->number;
  printuent((struct userec *) NULL);
  if (apply_record(str_passfile, printuent, sizeof(struct userec)) == -1)
  {
    outs(msg_nobody);
    return XEASY;
  }
  clrtobot();
  move(b_lines, 0);
  prints("[46;1m  �w��� %d/%d ���ϥΪ�(�t�γ̤j�e�q�� %d �H)�C  [45m  (�Ы����N���~��)  [0m",
    usercounter, totalusers, MAXUSERS);
  egetch();
  return 0;
}


int
g_board_names(fhdrp)
  boardheader *fhdrp;
{
  AddNameList(fhdrp->brdname);
  return 0;
}


void
make_blist()
{
  CreateNameList();
  apply_boards(g_board_names);
}


int
Select()
{
  modify_user_mode(SELECT);
  do_select(0, NULL, genbuf);
  return 0;
}


int
Post()
{
  if (selboard)
  {

#ifndef NOREPLY
    *replytitle =
#endif

    *quote_file = *quote_user = '\0';
    do_post();
    return 0;
  }
  outs("���� (S)elect �h��ܤ@�ӰQ�װϡC");
  return XEASY;
}


void
set_board()
{
  boardheader *bp;
  boardheader *getbcache();

  bp = getbcache(currboard);
  sprintf(currBM, "�O�D�G%s", bp->BM[0] > ' ' ? bp->BM : "�x�D��");
  currTitle = (bp->bvote == 1 ? "���Q�װ϶i��벼��" : bp->title + 7);
  board_note_time = bp->bupdate;
}


void
readtitle()
{
  showtitle(currBM, currTitle);
  outs("\
[��]���} [����]��� [��]�\\Ū [^P]�o���峹 [d]��H [b]�Ƨѿ� [TAB]��ذ� [h]elp\n\
[7m  �s��   �Z �n ��    �� ��  ��        �D                                      [m");
}


void
readdoent(num, ent)
  struct fileheader *ent;
{
  static char *mytag[2] = {"�� ", ""};
  int filetime;
  int len, i, j;
  char *related;
  char type;

  /* read BOARDRC */
  type = brc_unread(ent->filename) ? 'N' : ' ';

  /* if ((ent->filemode & FILE_MARKED) && HAS_PERM(PERM_BM))  /* opus */
  if (ent->filemode & FILE_MARKED)
    type = (type == ' ') ? 'm' : 'M';

  /* ------------------------------ */
  /* opus : at most 9999 articles   */
  /* ------------------------------ */

  related = (char *) ent->title;
  if (!strncmp(ent->title, str_reply, 4))
  {
    related += 4;
    i = 1;
    j = 3;
  }
  else
    i = j = 0;

  len = strlen(ent->title);
  if (len > 47 + j)
    strcpy(ent->title + 44 + j, " �K");	/* ��h�l�� string �屼 */

  if (*related && !strncmp(related_title, related, 40))
    prints("%6d %c %-12.12s%s  [1;%dm%s%s[0m\n", num, type,
      ent->owner, ent->date, 32 + i, mytag[i], ent->title);
  else
    prints("%6d %c %-12.12s%s  %s%s\n", num, type,
      ent->owner, ent->date, mytag[i], ent->title);
}


int
cmpfilename(fhdr)
  struct fileheader *fhdr;
{
  if (strncmp(fhdr->filename, currfile, FNLEN))
    return 0;
  return 1;
}


#ifndef NOREPLY
void
do_reply(title)
  char *title;
{
  strcpy(replytitle, title);
  do_post();
  replytitle[0] = '\0';
}
#endif


int
read_post(ent, fileinfo, direct)
  int ent;
  fileheader *fileinfo;
  char *direct;
{
  char *t;
  char ans[4];
  int ch, owned;
  char *related;

  if (fileinfo->owner[0] == '-')
    return DONOTHING;

  clear();
  setdirpath(genbuf, direct, fileinfo->filename);

  related = (char *) fileinfo->title;
  if (!strncmp(fileinfo->title, str_reply, 4))
    related += 4;
  strncpy(related_title, related, 40);

#ifndef NOREPLY
  more(genbuf, NA);
#else
  more(genbuf, YEA);
#endif

  strncpy(currfile, fileinfo->filename, FNLEN);
  brc_addlist(fileinfo->filename);

#ifndef NOREPLY
  move(b_lines, 0);
  clrtoeol();
  outs("[1;33;46m �H��B�z [45m ");
  if (haspostperm(currboard))
    outs("(R)[36m�^�H [33m");
  outs("(����)[36m�W�U�� [33m(��)[36m���} [33m([])[36m���� [m");
  refresh();

#if 0				/* opus: list phxx for reference */
  if (ch != KEY_RIGHT || ch != KEY_UP && ch != KEY_PGUP)
#endif

    ch = egetch();

  switch (ch)
  {
  case 'q':
  case 'Q':
  case KEY_LEFT:
    break;
  case ' ':
  case KEY_RIGHT:
  case KEY_DOWN:
    return READ_NEXT;
  case KEY_UP:
  case 'p':
    return READ_PREV;
  case ']':
    return RELATE_NEXT;
  case '[':
    return RELATE_PREV;
  case 'r':
  case 'R':
  case 'y':
  case 'Y':
    strcpy(quote_file, genbuf);
    quote_file[255] = fileinfo->savemode;
    strcpy(quote_user, fileinfo->owner);
    do_reply(fileinfo->title);
    break;

  case Ctrl('R'):		/* opus : �����H�H����@�̵o�H�a�} */
    mail_reply(ent, fileinfo, direct);
  }
#endif

  return FULLUPDATE;
}


int
do_select(ent, fileinfo, direct)
  int ent;
  struct fileheader *fileinfo;
  char *direct;
{
  char bname[20];
  char bpath[60];
  struct stat st;
  extern char currdirect[64];

  move(0, 0);
  clrtoeol();
  make_blist();
  namecomplete(msg_select_board, bname);
  setbpath(bpath, bname);
  if ((*bname == '\0') || (stat(bpath, &st) == -1))
  {
    move(1, 0);
    clrtoeol();
    outs(err_bid);
    pressanykey();
    return FULLUPDATE;
  }

  selboard = 1;
  board_visit_time = 0x7fffffff;
  brc_initial(bname);
  set_board();
  setbdir(direct, currboard);

  move(0, 0);
  clrtoeol();
  move(1, 0);
  clrtoeol();
  return NEWDIRECT;
}


/* -------------- */
/* quote deletion */
/* -------------- */

int
garbage_line(str)
  char *str;
{
  int qlevel = 0;

  while (*str == ':' || *str == '>')
  {
    str++;
    if (*str == ' ')
      str++;
    if (qlevel++ >= 1)
      return 1;
  }
  while (*str == ' ' || *str == '\t')
    str++;
  if (qlevel >= 1)
  {
    if (!strncmp(str, "�� ", 3) || !strncmp(str, "==>", 3) ||
      strstr(str, ") ����:\n"))
      return 1;
  }
  return (*str == '\n');
}


/* ----------------------------- */
/* �ޥΤ峹			 */
/* ----------------------------- */

void
do_quote(filepath)
  char *filepath;
{
  char ans[2], op;

  getdata(b_lines, 0, "�аݭn�ޥέ���(Y/N/All/Repost)?[Y]: ",
    ans, 2, DOECHO);
  op = toupper(ans[0]);

  if (op != 'N')
  {
    FILE *inf, *outf;

    inf = fopen(quote_file, "r");
    outf = fopen(filepath, "a");
    if (inf && outf)
    {
      char buf[256], *ptr;

      fgets(buf, 256, inf);
      if (ptr = strrchr(buf, ')'))
	ptr[1] = '\0';
      else if (ptr = strrchr(buf, '\n'))
	ptr[0] = '\0';

      if (ptr = strchr(buf, ':'))
	ptr++;
      else
	ptr = quote_user;
      while (*ptr == ' ')
	ptr++;
      fprintf(outf, "�� �ޭz�m%s�n���ʨ��G\n", ptr);

      if (op == 'A')
      {
	while (fgets(buf, 256, inf))
	  fprintf(outf, ": %s", buf);
      }
      else if (op == 'R')
      {
	while (fgets(buf, 256, inf))
	  if (buf[0] == '\n')
	    break;
	while (fgets(buf, 256, inf))
	  fprintf(outf, "%s", buf);
      }
      else
      {
	while (fgets(buf, 256, inf))
	{
	  if (buf[0] == '\n')
	    break;
	}
	if (in_mail == MAIL_LIST)
	{
	  while (fgets(buf, 256, inf))
	  {
	    if (strncmp(buf, "�� ", 3))
	      break;
	  }
	}
	while (fgets(buf, 256, inf))
	{
	  if (strcmp(buf, "--\n") == 0)
	    break;
	  if (buf[WRAPMARGIN - 2])
	    strcpy(buf + WRAPMARGIN - 2, "\n");
	  if (!garbage_line(buf))
	    fprintf(outf, ": %s", buf);
	}
      }
      fclose(inf);
      fclose(outf);
    }
  }
  *quote_file = *quote_user = '\0';
}


/* opus: get title */

void
do_reply_title(row, reply, title)
  int row;
  char *reply, *title;
{
  if (ci_strncmp(title, str_reply, 4))
    sprintf(reply, "Re: %s", title);
  else
    strcpy(reply, title);
  reply[TTLEN - 1] = '\0';
  sprintf(genbuf, "�ĥέ���D [%.60s] ��(Y/n)? ", reply);
  getdata(row, 0, genbuf, genbuf + 512, 3, DOECHO);
  if (genbuf[512] == 'n' || genbuf[512] == 'N')
    getdata(++row, 0, "���D: ", reply, TTLEN, DOECHO);
}


int
do_post()
{
  fileheader postfile;
  char filepath[64], fname[64], ans[4], buf[128];
  char *ip;
  int fp, aborted;

  clear();
  if (!haspostperm(currboard))
  {
    move(5, 10);
    outs("���Q�װϬO��Ū��, �п�ܨ�L�Q�װ�.");
    pressanykey();
    return FULLUPDATE;
  }

  more("etc/post.note", NA);
  prints("�o���峹��i %s �j�Q�װ�\n\n", currboard);

#ifndef NOREPLY
  if (replytitle[0])
  {
    do_reply_title(20, postfile.title, replytitle);
  }
  else
#endif

    getdata(21, 0, "���D: ", postfile.title, TTLEN, DOECHO);
  strcpy(save_title, postfile.title);
  if (save_title[0] == '\0')
  {
    return FULLUPDATE;
  }

  /* opus: build filename */

  setbpath(postfile.filename, currboard);
  stampfile(filepath, &postfile);
  strcpy(postfile.owner, cuser.userid);

  local_article = 0;
  if (quote_file[0] && quote_file[255] == 'L')
    local_article = 1;

  in_mail = NA;
  modify_user_mode(POSTING);

  if (quote_file[0])
    do_quote(filepath);

  aborted = vedit(filepath, YEA);
  if (aborted == -1)
  {
    unlink(filepath);
    pressanykey();
    clear();
    return FULLUPDATE;
  }

  strcpy(postfile.title, save_title);
  if (aborted == 1)		/* local save */
  {
    postfile.savemode = 'L';
    postfile.filemode = FILE_LOCAL;
  }

  setbdir(buf, currboard);
  if (append_record(buf, &postfile, sizeof(postfile)) == -1)
  {

#ifdef	HAVE_REPORT
    sprintf(buf, "posting '%s' on '%s': append_record failed!",
      postfile.title, currboard);
    report(buf);
#endif

    pressanykey();
    clear();
    return FULLUPDATE;
  }

  /* write BOARDRC */
  brc_addlist(postfile.filename);

#ifdef	HAVE_REPORT
  sprintf(buf, "posted '%s' on '%s'", postfile.title, currboard);
  report(buf);
#endif

  outs("���Q�K�X�G�i\n");
  if (strcmp(currboard, "test"))
  {
    prints("�o�O�z���� %d �g�G�i", ++cuser.numposts);
    UPDATE_USEREC;
  }
  else
    outs("���իH�󤣦C�J����, �q�Х]�[");

  pressanykey();
  return FULLUPDATE;
}


int
reply_post(ent, fileinfo, direct)
  int ent;
  struct fileheader *fileinfo;
  char *direct;
{
  if (!haspostperm(currboard))
    return DONOTHING;

  setdirpath(quote_file, direct, fileinfo->filename);
  quote_file[255] = fileinfo->savemode;
  strcpy(quote_user, fileinfo->owner);
  do_reply(fileinfo->title);
  return FULLUPDATE;
}


int
edit_post(ent, fileinfo, direct)
  int ent;
  struct fileheader *fileinfo;
  char *direct;
{
  if (!HAS_PERM(PERM_SYSOP) && strcmp(fileinfo->owner, cuser.userid))
    return DONOTHING;

  setdirpath(genbuf, direct, fileinfo->filename);
  vedit(genbuf, NA);
  return FULLUPDATE;
}


int
cross_post(ent, fileinfo, direct)
  int ent;
  struct fileheader *fileinfo;
  char *direct;
{
  char xboard[20], fname[80], xfpath[80];
  fileheader xfile;
  FILE *xptr;

  move(1, 0);
  clrtoeol();
  make_blist();
  namecomplete("������峹��ݪO�G", xboard);
  if (*xboard == '\0' || !haspostperm(xboard))
    return FULLUPDATE;
  sprintf(xfpath, "����i%.40s�j[S]ave (L)ocal (Q)uit ? ", fileinfo->title);
  getdata(1, 0, xfpath, genbuf, 3, DOECHO);
  if (genbuf[0] == 'q' || genbuf[0] == 'Q')
    return FULLUPDATE;

  setbpath(xfile.filename, xboard);
  stampfile(xfpath, &xfile);
  strcpy(xfile.owner, cuser.userid);
  sprintf(xfile.title, "[���]%.60s", fileinfo->title);
  if (genbuf[0] == 'l' || genbuf[0] == 'L')
  {
    xfile.savemode = 'L';
    xfile.filemode = FILE_LOCAL;
  }
  if (xptr = fopen(xfpath, "w"))
  {
    strcpy(save_title, xfile.title);
    strcpy(xfpath, currboard);
    strcpy(currboard, xboard);
    write_header(xptr);
    strcpy(currboard, xfpath);

    fprintf(xptr, "�� [��������� %s �Q�װ�]\n\n", currboard);

    setbfile(fname, currboard, fileinfo->filename);
    b_suckinfile(xptr, fname);
    addsignature(xptr);
    fclose(xptr);

    setbdir(fname, xboard);
    append_record(fname, (char *) &xfile, sizeof(xfile));
    cuser.numposts++;
    UPDATE_USEREC;
    outs("�峹�������");
    pressanykey();
  }
  return FULLUPDATE;
}


/* �Ķ���ذ� */

int
cite_post(ent, fileinfo, direct)
  int ent;
  fileheader *fileinfo;
  char *direct;
{
  if (HAS_PERM(PERM_ALLBOARD) ||
    (HAS_PERM(PERM_BM) && strstr(currBM, cuser.userid)))
  {
    extern char *err_filename;
    char title[64] = "�� ";
    char fname[60], ans[2];
    FILE *fp;
    int existed;

    /* opus: fname �i�H�]�t�ؿ����| */

    getdata(b_lines, 0, "�п�J�ɦW�G", fname, 60, DOECHO);
    sprintf(genbuf, "man/%s/%s", currboard, fname);
    if (invalid_fname(fname) || dashd(genbuf))
    {
      move(b_lines, 0);
      clrtoeol();
      outs(err_filename);
      egetch();
      return READ_REDRAW;
    }
    if (existed = dashf(genbuf))
    {
      getdata(b_lines, 0, "�ۦP�ɦW�w�g�s�b�A�O�_���[�i�h(Y/N)?[Y]: ",
	ans, 2, DOECHO);
      if (ans[0] == 'n' || ans[0] == 'N')
	return READ_REDRAW;
    }
    else
    {
      getdata(b_lines, 0, "�п�J���D�G", title + 3, 60, DOECHO);
      /* opus : �۰ʳ] title */
      if (title[3] == NULL || title[3] == '\n')
	strcpy(title + 3, fileinfo->title);
    }

    if ((fp = fopen(genbuf, "a+")) == NULL)
      return READ_REDRAW;
    if (existed)
    {
      memset(genbuf + 512, '-', 78);
      genbuf[512 + 78] = '\0';
      fprintf(fp, "\n\n%s\n\n", genbuf + 512);
    }
    setbfile(genbuf + 512, currboard, fileinfo->filename);
    b_suckinfile(fp, genbuf + 512);
    fclose(fp);

    if (!existed)
    {
      direct = strrchr(genbuf, '/');
      strcpy(direct, str_mandex);
      if (fp = fopen(genbuf, "a+"))
      {
	if (direct = strrchr(fname, '/'))
	  direct++;
	else
	  direct = fname;
	direct[30] = '\0';
	fprintf(fp, "Name=%s\nPath=%s\n", title, direct);
	fclose(fp);
      }
    }
    return READ_REDRAW;
  }
  return DONOTHING;
}


int
edit_title(ent, fileinfo, direct)
  int ent;
  struct fileheader *fileinfo;
  char *direct;
{

  if (HAS_PERM(PERM_SYSOP))
  {
    char buf[TTLEN];

    getdata(b_lines, 0, "�s�峹���D: ", buf, TTLEN, DOECHO);
    if (buf[0])
    {
      strcpy(fileinfo->title, buf);
      substitute_record(direct, fileinfo, sizeof(*fileinfo), ent);
    }
    return PARTUPDATE;
  }
  return DONOTHING;
}


int
mark_post(ent, fileinfo, direct)
  int ent;
  struct fileheader *fileinfo;
  char *direct;
{
  if (HAS_PERM(PERM_ALLBOARD) ||
    (HAS_PERM(PERM_BM) && strstr(currBM, cuser.userid)))
  {
    fileinfo->filemode ^= FILE_MARKED;
    substitute_record(direct, fileinfo, sizeof(*fileinfo), ent);
    return PARTUPDATE;
  }
  return DONOTHING;
}


int
del_range(ent, fileinfo, direct)
  int ent;
  struct fileheader *fileinfo;
  char *direct;
{
  char num1[10], num2[10];
  int inum1, inum2;

  if (uinfo.mode == READING && !HAS_PERM(PERM_SYSOP) &&
    (!HAS_PERM(PERM_BM) || !strstr(currBM, cuser.userid)))
  {
    return DONOTHING;
  }
  stand_title("�]�w�R���d��");
  getdata(1, 0, "���g�峹�s��: ", num1, 10, DOECHO);
  inum1 = atoi(num1);
  if (inum1 <= 0)
  {
    outs("�_�I���~");
    pressanykey();
    return FULLUPDATE;
  }
  getdata(2, 0, "���g�峹�s��: ", num2, 10, DOECHO);
  inum2 = atoi(num2);
  if (inum2 < inum1)
  {
    outs("���I���~");
    pressanykey();
    return FULLUPDATE;
  }
  getdata(3, 0, msg_sure_ny, num1, 10, DOECHO);
  if (*num1 == 'Y' || *num1 == 'y')
  {
    delete_range(direct, inum1, inum2);
    fixkeep(direct, inum1, inum2);

#ifdef	HAVE_REPORT
    sprintf(genbuf, "delete range %d-%d on %s", inum1, inum2, currboard);
    report(genbuf);
#endif

    outs(msg_delete_ok);
    pressanykey();
    return DIRCHANGED;
  }
  outs(msg_delete_cancel);
  pressanykey();
  return FULLUPDATE;
}


void
lazy_delete(fhdr)
  struct fileheader *fhdr;
{
  char buf[80];

  sprintf(buf, "-%s", fhdr->owner);
  strncpy(fhdr->owner, buf, IDLEN + 1);
  /* sprintf(buf, "<< article canceled by %s >>", cuser.userid); */
  sprintf(buf, "<< article deleted >>");
  strcpy(fhdr->title, buf);
  fhdr->savemode = 'L';
}


int
del_post(ent, fileinfo, direct)
  int ent;
  struct fileheader *fileinfo;
  char *direct;
{
  char buf[80];
  char *t;
  int not_owned;

  if ((fileinfo->filemode & FILE_MARKED) || (fileinfo->owner[0] == '-'))
    return DONOTHING;

  not_owned = strcmp(fileinfo->owner, cuser.userid);
  if ((!HAS_PERM(PERM_SYSOP)) && (not_owned))
    if ((!HAS_PERM(PERM_BM)) || !strstr(currBM, cuser.userid))
    {
      return DONOTHING;
    }

  getdata(b_lines, 0, msg_delete_ny, genbuf, 3, DOECHO);
  if (genbuf[0] == 'y' || genbuf[0] == 'Y')
  {
    strncpy(currfile, fileinfo->filename, FNLEN);

    if (!update_file(direct, sizeof(fileheader), ent, cmpfilename, lazy_delete))
    {
      /* add by mfchen, cancel tin's post */
      cancelpost(currboard, currfile, cuser.userid);
      /* add by mfchen, cancel tin's post */
      setdirpath(genbuf, direct, currfile);
      unlink(genbuf);
      if (!not_owned && strcmp(currboard, "test"))
      {
	if (cuser.numposts)
	  cuser.numposts--;
	UPDATE_USEREC;
	move(b_lines, 0);
	clrtoeol();
	prints("%s�A�z���峹� %d �g", msg_delete_ok, cuser.numposts);
	refresh();
	sleep(1);
      }
      lazy_delete(fileinfo);
      return PARTUPDATE;
    }
  }
  return READ_REDRAW;
}



/* -------------------------------------------- */
/* �̧�Ū�s�峹                                 */
/* -------------------------------------------- */

static int sequent_ent;


int
sequent_messages(fptr)
  struct fileheader *fptr;
{
  static int idc;
  char ans[6];
  if (fptr == NULL)
    return (idc = 0);

  if (++idc < sequent_ent)
    return 0;

  if (!brc_unread(fptr->filename))
    return 0;

  if (continue_flag)
  {
    genbuf[0] = 'y';
  }
  else
  {
    prints("Ū���峹��: [%s] ���D:\n[%s] �@�̬�: %s",
      currboard, fptr->title, fptr->owner);
    getdata(3, 0, "(Y/N/Quit) [Y]: ", genbuf, 2, DOECHO);
  }

  if (genbuf[0] != 'y' && genbuf[0] != 'Y' && genbuf[0] != '\0')
  {
    clear();
    if (genbuf[0] == 'q' || genbuf[0] == 'Q')
      return QUIT;
    return 0;
  }
  setbfile(genbuf, currboard, fptr->filename);
  strcpy(quote_file, genbuf);
  strcpy(quote_user, fptr->owner);

#ifdef NOREPLY
  more(genbuf, YEA);
#else
  more(genbuf, NA);
  move(b_lines, 1);
  outs(" [45m (R)�^�H  (��,n)�U�@��  (��,q)���}  [40m");
  continue_flag = 0;
  switch (egetch())
  {
  case 'Q':
  case 'e':
  case 'q':
  case KEY_LEFT:
    break;
  case 'Y':
  case 'R':
  case 'y':
  case 'r':
    do_reply(fptr->title);
  case ' ':
  case '\n':
  case KEY_DOWN:
  case 'n':
    continue_flag = 1;
    break;
  case Ctrl('R'):
    /* post_reply uses only ftpr as argument! */
    in_mail = NA;
    mail_reply(0, fptr, (char *) NULL);
  }
#endif

  clear();
  setbdir(genbuf, currboard);
  brc_addlist(fptr->filename);
  return 0;
}


int
sequential_read(ent, fileinfo, direct)
  int ent;
  struct fileheader *fileinfo;
  char *direct;
{
  char buf[40];

  clear();
  sequent_messages((struct fileheader *) NULL);
  sequent_ent = ent;
  continue_flag = 0;
  setbdir(buf, currboard);
  apply_record(buf, sequent_messages, sizeof(fileheader));
  return FULLUPDATE;
}


int
cmpbnames(bname, brec)
  char *bname;
  struct fileheader *brec;
{
  if (ci_strncmp(bname, brec->filename, sizeof(brec->filename)))
    return 0;
  else
    return 1;
}


int
b_notes_edit()
{
  if (HAS_PERM(PERM_SYSOP) ||
    (HAS_PERM(PERM_BM) && strstr(currBM, cuser.userid)))
  {
    struct stat st;
    char buf[64];
    int aborted;

    setbfile(buf, currboard, str_notes);
    aborted = vedit(buf, NA);
    if (aborted)
    {
      clear();
      outs(msg_cancel);
      pressanykey();
    }
    else
    {
      struct boardheader fh;
      int pos;

      getdata(3, 0, "�г]�w���Ĵ��� (0 - 9999)? ", buf, 5, DOECHO);
      aborted = atol(buf);
      pos = search_record(str_boards, &fh, sizeof(fh), cmpbnames, currboard);
      fh.bupdate = aborted ? time(0) + aborted * 86400 : 0;
      substitute_record(str_boards, &fh, sizeof(fh), pos);
      touch_boards();
    }
    return FULLUPDATE;
  }
  return 0;
}


/* help for board reading */

static char *board_help[] =
{
  "\0���\\��ݪO�ާ@����",
  "\01�򥻩R�O",
  "[p][��]   �W���@�g�峹          [^P]    �o���峹",
  "[n][��]   �U���@�g�峹          [d]     �R���峹",
  "[P][PgUp] �W���@��              [S]     �`�Ǿ\\Ū�s�峹",
  "[N][PgDn] �U���@��              [##]    ���� ## ���峹",
  "[r][��]   �\\Ū���g�峹          [$]     ����̫�@�g�峹",
  "\01�i���R�O",
  "[tab]     �i�J��ذ�            [a][A]  ��M�@��",
  "[b]       �iŪ�Ƨѿ�            [?][/]  ��M���D",
  "[V,R]     �벼/�d�ߧ벼���G     [1m -[]+   ��M�����峹[0m",
  "[x]       ����峹���L�ݪO    [=]     ��M���g�峹",

#ifdef INTERNET_EMAIL
  "[F]       �N�峹�H�^ Internet �l�c",
  "[U]       �N�峹 uuencode ��H�^�l�c",
  "[1m[^R]      �����^�H���@�̡m��H����i�n[0m",
#endif

  "\01�O�D�R�O",
  "[m]       �O�d���g�峹          [W]     �s��Ƨѿ�",
  "[M]       �|��벼              [c]     ����峹���ذ�",
  "[D]       �R���@�q�d�򪺤峹    [E/t]   ���s�峹/���D",

  NULL
};


boardreadhelp()
{
  show_help(board_help);
  return FULLUPDATE;
}



#ifdef INTERNET_EMAIL
extern int mail_forward();
extern int mail_uforward();
#define	forward_post	mail_forward
#define	forward_u_post	mail_uforward
#endif

extern int b_vote();
extern int b_results();
extern int b_vote_maintain();

struct one_key read_comms[] = {
  'r', read_post,
  'c', cite_post,
  'x', cross_post,
  'y', reply_post,
  'd', del_post,
  'D', del_range,
  'm', mark_post,
  'E', edit_post,
  'T', edit_title,
  's', do_select,
  Ctrl('P'), do_post,
  'S', sequential_read,

#ifdef INTERNET_EMAIL
  'F', forward_post,
  'U', forward_u_post,
  Ctrl('R'), mail_reply,
#endif

  'R', b_results,
  'V', b_vote,
  'M', b_vote_maintain,
  'W', b_notes_edit,
  'h', boardreadhelp,
  '\0', NULL
};


Read()
{
  char buf[40];

  if (!selboard)
  {
    outs("�Х���(S)elect ��ܤ@�ӰQ�װ�");
    return XEASY;
  }

  in_mail = NA;

  set_board();

  if (board_visit_time < board_note_time)
  {
    setbfile(buf, currboard, str_notes);
    more(buf, YEA);
  }

  setbdir(buf, currboard);
  i_read(READING, buf, readtitle, readdoent, read_comms);
  brc_update();
  return 0;
}


int
Goodbye()
{
  extern int started;
  extern void movie();

  getdata(b_lines, 0, "�z�T�w�n���}�i " BOARDNAME " �j�� (Y/N)? [N] ",
    genbuf, 3, DOECHO);

  if (*genbuf != 'y' && *genbuf != 'Y')
    return (XEASY + 1);

  movie(999);
  if (cuser.userlevel)
  {
    getdata(b_lines, 0, "(G)�A�O���� (M)���i���� (N)�Ĳ��W���d���O [G]�G",
      genbuf, 3, DOECHO);
    if (genbuf[0] == 'm' || genbuf[0] == 'M')
      mail_sysop();
    else if (genbuf[0] == 'n' || genbuf[0] == 'N')
      note();
  }
  clear();

  prints("[1;36m�˷R�� [33m%s(%s)[36m�A�O�ѤF�A�ץ��{[45;33m"
    " %s [40;36m�A�A�|��!\n�H�U�O�z�b���������U���:[m\n",
    cuser.userid, cuser.username, BoardName);

  user_display(&cuser, 0);

  if (started)
  {
    sprintf(genbuf, "Stay: %d (%s)",
      (time(NULL) - login_start_time) / 60, cuser.username);
    log_usies("EXIT ", genbuf);
    u_exit();
  }

  pressanykey();
  sleep(1);
  reset_tty();
  exit(0);
}


/* ------------------------------------ */
/* ���� trace file                      */
/* ------------------------------------ */


#ifdef	HAVE_REPORT
void
report(s)
  char *s;
{
  static int disable = NA;
  int fd;

  if (disable)
    return;
  if ((fd = open("trace", O_WRONLY, 0644)) != -1)
  {
    char buf[256];
    char *thetime;
    time_t dtime;

    time(&dtime);
    thetime = Cdate(&dtime);
    flock(fd, LOCK_EX);
    lseek(fd, 0, L_XTND);
    sprintf(buf, "%s %s %s\n", cuser.userid, thetime, s);
    write(fd, buf, strlen(buf));
    flock(fd, LOCK_UN);
    close(fd);
    return;
  }
  disable = YEA;
  return;
}
#endif


void
cancelpost(board, file, userid)
  char *board, *file, *userid;
{
  FILE *fh;
  char from[STRLEN], path[STRLEN];
  char *ptr;
  int len;

  setbfile(genbuf, board, file);
  if (fh = fopen(genbuf, "r"))
  {
    from[0] = path[0] = '\0';
    while (fgets(genbuf, sizeof(genbuf), fh))
    {
      len = strlen(genbuf) - 1;
      genbuf[len] = '\0';
      if (len <= 8)
      {
	break;
      }
      else if (strncmp(genbuf, "�o�H�H: ", 8) == 0)
      {
	if (ptr = strrchr(genbuf, ','))
	  *ptr = '\0';
	strcpy(from, genbuf + 8);
      }
      else if (strncmp(genbuf, "��H��: ", 8) == 0)
      {
	strcpy(path, genbuf + 8);
      }
    }
    fclose(fh);
    sprintf(genbuf, "%s\t%s\t%s\t%s\t%s\n",
      board, file, userid, from, path);
    if ((fh = fopen("cancelpost.lst", "a")) != NULL)
    {
      fputs(genbuf, fh);
      fclose(fh);
    }
  }
}


#define	MAX_NOTE	5
void
note()
{
  static char *str_note_tmp = "note.tmp";
  static char *str_note_dat = "note.dat";
  int total, i, j = 1;
  struct stat st;
  char buf[256], buf2[80], *p;
  int fd, fx;
  FILE *fp;

  struct notedata
  {
    time_t date;
    char userid[IDLEN + 1];
    char username[19];
    char buf[3][80];
  };
  struct notedata myitem;

  do
  {
    myitem.buf[0][0] = myitem.buf[1][0] = myitem.buf[2][0] = NULL;
    move(12, 0);
    clrtobot();
    outs("\n�Яd�� (�ܦh�T��)�A��[Enter]����\n");
    for (i = 0; i < 3; i++)
    {
      getdata(16 + i, 0, "�G", myitem.buf[i], 78, DOECHO);
      if (myitem.buf[i][0] == NULL)
	break;
    }
    getdata(b_lines, 0, "(S)�x�s (E)���s�ӹL (A)��� ? [S]�G", buf, 2, DOECHO);
    if (buf[0] == 'a' || buf[0] == 'A' || (myitem.buf[0][0] == NULL))
      return;
  }
  while (buf[0] == 'e' || buf[0] == 'E');

  strcpy(myitem.userid, cuser.userid);
  strncpy(myitem.username, cuser.username, 18);
  myitem.username[18] = '\0';
  time(&(myitem.date));

  /* begin load file */

  if ((fp = fopen(str_note_ans, "w")) == NULL)
    return;

  if ((fx = open(str_note_tmp, O_WRONLY | O_CREAT)) == 0)
    return;

  if ((fd = open(str_note_dat, O_RDONLY)) == -1)
  {
    total = 1;
  }
  else if (stat(str_note_dat, &st) != -1)
  {
    total = st.st_size / sizeof(struct notedata) + 1;
    if (total > MAX_NOTE)
      total = MAX_NOTE;
  }

  fputs("\t\t\t[37;45m �� �� �� �W �� �d �� �O �� \n\n", fp);

  while (total)
  {
    sprintf(buf, "[1;37;46m�W[47;34m %s [33m(%s)",
      myitem.userid, myitem.username);
    if (strlen(buf) & 1)
      strcat(buf, " ");
    strcat(buf, "[37;46m");

    for (i = strlen(buf) >> 1; i < 45; i++)
      strcat(buf, "�e");
    sprintf(buf2, "[47;34m %.14s [37;46m�W[40;0m\n",
      Cdate(&(myitem.date)));
    strcat(buf, buf2);
    fputs(buf, fp);
    sprintf(buf, "%s\n%s\n%s\n", myitem.buf[0], myitem.buf[1], myitem.buf[2]);
    fputs(buf, fp);

    write(fx, &myitem, sizeof(myitem));

    if (--total)
      read(fd, (char *) &myitem, sizeof(myitem));
  }
  fclose(fp);
  close(fd);
  close(fx);
  rename(str_note_tmp, str_note_dat);
  more(str_note_ans, YEA);
}


void
mail_sysop()
{
  FILE *fp;

  if (fp = fopen("etc/sysop", "r"))
  {
    int i, j;

    struct SYSOPLIST
    {
      char userid[IDLEN + 1];
      char duty[40];
    }         sysoplist[9];

    j = 0;
    while (fgets(genbuf, 128, fp))
    {
      if (genbuf[0] == '#' || genbuf[0] == '\n')
	continue;
      strcpy(sysoplist[j].userid, (char *) strtok(genbuf, "\t"));
      strcpy(sysoplist[j++].duty, (char *) strtok(NULL, "\t\n"));
    }

    move(12, 0);
    clrtobot();
    prints("%-16s�s��   %-18s�v�d����\n", "", "���� ID");
    printdash(NULL);

    for (i = 0; i < j; i++)
    {
      prints("%19d.   [1;%dm%-16s%s[m\n",
	i + 1, 31 + i % 6, sysoplist[i].userid, sysoplist[i].duty);
    }
    prints("%-18s0.   [1;%dm���}[37;40;0m", "", 31 + j % 6);
    getdata(b_lines - 1, 20, "�п�J�N�X[0]�G", genbuf, 4, DOECHO);
    i = genbuf[0] - '0' - 1;
    if (i >= 0 && i < j)
    {
      clear();
      do_send(sysoplist[i].userid, NULL);
    }
  }
}
