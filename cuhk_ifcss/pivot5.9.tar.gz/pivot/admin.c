/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    SccsId[] = "@(#)admin.c	1.2	7/26/95";
#endif

#include "bbs.h"

extern	int	t_lines,
		numboards;
extern	userec	muser,
		cuser;
extern	permin	permstrings[];

extern	usint	setperms();

int	count_exper(info, dble)
userec	*info;
int	*dble;
{
	int	exper;

	*dble = VACATION + ((info->userlevel & PERM_TRUE) ? 1 : 0);
	exper = (info->numposts + (info->numlogins / 5)) * (*dble);

	return	exper;
}

int	clean_user(info)
userec	*info;
{
	time_t	now,
		idle,
		exper,
		history;
	int	dble;

	if (info->userid[0] == '\0' || info->userlevel & PERM_NOCLEAN)
		return NA;
	(void)time(&now);

	exper = (int)count_exper(info, &dble) + 1;
	history = (now - info->reg_date)/600;
	idle = (now - info->lastlogin)/86400;

	if (!strcasecmp(info->userid, "new") && history > 1)
		return -1;

	if ((now - info->reg_date)/86400 <= dble*14)
		return NA;

	if ((!(info->userlevel & PERM_TRUE) && (idle > dble*7)) ||
		(exper < 30 && (idle > exper*2 || idle > 30)) ||
		(exper < 60 && idle > 45) || (exper < 120 && idle > 60) ||
		(exper < 240 && idle > 75) || (exper >= 240 && idle > 90))
		return YEA;

	return NA;
}

int	del_unused()
{
	userec	info;
	int	id,
		cleaned = 0;
	char	reg_date[10],
		last[10],
		genbuf[STRLEN];

	for (id = 1; id <= MAXUSERS; id++)
	{
		if (get_record(PASSFILE, (char *)&info, sizeof(userec), id))
			return 0;
		if (clean_user(&info))
		{
			if (strcasecmp(info.userid, "new"))
			{
				++cleaned;
				sprintf(reg_date, "%6.6s",
					ctime(&info.reg_date) + 4);
				sprintf(last, "%6.6s",
					ctime(&info.lastlogin) + 4);
				logit(LOG_CLEAN,
					"%s, p:%3d, l:%3d, r:%6.6s, l:%6.6s",
					info.userid, info.numposts,
					info.numlogins, reg_date, last);
				sprintf(genbuf, PATH_USER, info.userid);
				if (!access(genbuf, R_OK))
				{
					sprintf(genbuf, PATH_DUSER, info.userid);
					system(genbuf);
				}
			}
			bzero(&info, sizeof(userec));
			substitute_passwd(PASSFILE, &info, YEA, id);
		}
	}
	return cleaned;
}

int	m_uclean()
{
	move(2, 0);
	prints(NA, "�M���L�����ϥΪ��b����, �еy��..");
	refresh();
	move(2, 0);
	clrtoeol();
	prints(NA, "�`�@�M��: %d ��L�����ϥΪ�����", del_unused());
	return 0;
}

int	cmpname(rlname, nbuf)
char	*rlname;
userec	*nbuf;
{
	return	!strcmp(rlname, nbuf->realname);
}

int	m_info()
{
	int	ans,
		id = 0;
	char	uidbuf[20],
		genbuf[STRLEN];
	userec	initial;

	changemode(MINFO, NA);
	clear();
	prints(YEA, "��s���W USER ���");
	ans = getans(1, 0, "�п�� (1)�b�� (2)�Ǹ� (3)�m�W (4)�^�W�h: [4]", '4');
	move(1, 0);
	clrtoeol();

	switch(ans)
	{
		case '1':
			move(1, 3);
			if (!(id = init_namelist(genbuf)))
				return 0;
			break;

		case '2':
			getdata(1, 0, "�ѧǸ���� ", uidbuf, 20, DOECHO,
				YEA);
			id = atoi(uidbuf);
			break;

		case '3':
			getdata(1, 0, "��J�u��m�W: ", uidbuf, 20, DOECHO,
				YEA);
			id = search_record(PASSFILE, (char *)&muser,
				sizeof(muser), cmpname, (int)uidbuf);
			break;

		default:
			break;
	}

	if (id > 0 && id <= MAXUSERS)
	{
		get_record(PASSFILE, (char *)&initial, sizeof(userec), id);
		modify_info(&initial, id, YEA);
	}
	changemode(MADMIN, NA);
	clear();
    	return 0;
}

int	m_plan()
{
	char	bname[STRLEN],
		bpath[STRLEN*2];
	int	pos;
	bhd	fh;

	make_blist();
	clear();
	prints(YEA, "Change Board Info");

	move(1, 0);
	namecomplete("Enter board name: ", bname);
	if (*bname == '\0')
	{
		move(2, 0);
		prints(NA, "Invalid Board Name");
		pressreturn();
		clear();
		return -1;
	}

	if (!(pos = search_board(&fh, bname)))
	{
		move(2, 0);
		prints(NA, "Invalid Board Name");
		pressreturn();
		clear();
		return -1;
	}

	changemode(BOARDINFO, NA);

	sprintf(bpath, "boards/%s/.plan", bname);
	pos = vedit(bpath, NA);
	clear();
	if (!pos)
		prints(NA, "Board Plan Updated");

	pressreturn();

	changemode(MADMIN, NA);
	return 0;
}

int	edit_board(brd, create)
bhd	*brd;
int	create;
{
	char	genbuf[STRLEN],
		buf1[STRLEN], buf2[STRLEN];
	bhd	dh;
	int	ans,
		i;

	i = (create) ? 1 : 11;
	move(i++, 0);
	clrtoeol();
	for(;;)
	{
		getdata(i, 0, "�s�Q�װϦW: ", genbuf, 18, DOECHO, YEA);
		if (genbuf[0] == '\0')
		{
			if (create)
				return -1;
			else
				break;
		}

		if (search_board(&dh, genbuf))
		{
			move(i+1, 0);
			prints(NA, "Error! Board already exists\n");
			bell(1);
			move(11, 0);
			clrtobot();
			continue;
		}

		if (create)
		{
			sprintf(buf1, "boards/%s", genbuf);
			mkdir(buf1, 0750);
		}
		else
		{
			sprintf(buf1, "boards/%s", brd->filename);
			sprintf(buf2, "boards/%s", genbuf);
			rename(buf1 , buf2);
		}
		strncpy(brd->filename, genbuf, sizeof(brd->filename));
		break;
	}

	getdata(++i, 0, "�Q�װϥD�D�]�w: ", genbuf, 60, DOECHO, YEA);
	if (genbuf[0])
		strcpy(brd->title, genbuf);
	ans = getans(++i, 0, "�ѥ[��H(Y/N): [N]", 'n');
	if (ans == 'y')
		brd->flag |= BHD_BBSNEWS;
	else
  		brd->flag = 0;

	getdata(++i, 0, "�Ĥ@��O�N�z: ", genbuf, 60, DOECHO, YEA);
       	if (*genbuf != 0)
       	        strncpy(brd->mngs[0], genbuf, sizeof(brd->mngs[0]));

	getdata(++i, 0, "�ĤG��O�N�z: ", genbuf, 60, DOECHO, YEA);
	if (*genbuf != 0)
                strncpy(brd->mngs[1], genbuf, sizeof(brd->mngs[1]));

	getdata(++i, 0, "�ĤT��O�N�z: ", genbuf, 60, DOECHO, YEA);
	if (*genbuf != 0)
                strncpy(brd->mngs[2], genbuf, sizeof(brd->mngs[2])); 

	if (create)
	{
		brd->readlevel = ~0;
		brd->postlevel = PERM_TRUE;
	}
	move(3, 0);
	prints(NA, "��� %s �i�i�K�j�v��\n", brd->filename);
	brd->postlevel = setperms(brd->postlevel, permstrings);

	move(3, 0);
	prints(NA, "��� %s �iŪ���j�v��\n", brd->filename);
	brd->readlevel = setperms(brd->readlevel, permstrings);

	ans = gain_group();
	if (ans != 0)
		brd->group = ans;
	return 0;
}

int	Create()
{
	bhd	new;
	char	genbuf[STRLEN];
	int	ans = NA;

	clear();

	changemode(CREATE, NA);
	bzero(&new, sizeof(bhd));
	prints(NA, "�W�]�Q�װ�:");

	if (edit_board(&new, YEA) == -1)
	{
		prints(NA, "\n���]�߰Q�װ�\n");
		changemode(MADMIN, NA);
		pressreturn();
		return -1;
	}

	ans = getans(t_lines-2, 0, "�O�_���ߦ��Q�װ�(Y/N)? [Y]: ", 'y');
	if (ans == 'n')
	{
		sprintf(genbuf, PATH_DBOARD, new.filename);
		system(genbuf);
		prints(NA, "\n���]�߰Q�װ�\n");
		changemode(MADMIN, NA);
		pressreturn();
		return -1;
	}

	if (append_record(BOARDS, (char *)&new, sizeof(new)) == -1)
	{
		changemode(MADMIN, NA);
		pressreturn();
		clear();
		return -1;
	}

	numboards = -1;
	prints(NA, "\n�s�Q�װϤw�g�]�w����\n");
	logit(LOG_MODBRD, "%s create %s", cuser.userid, new.filename);
	pressreturn();
	changemode(MADMIN, NA);
	clear();

	return 0;
}

int	m_editbrd()
{
	char	bname[STRLEN];
	int	pos,
		ans;
	bhd	fh,
		newfh;

	make_blist();
	clear();
	prints(YEA, "Change Board Info");

	move(1, 0);
	namecomplete("Enter board name: ", bname);
	if (*bname == '\0')
	{
		move(2, 0);
		prints(NA, "Invalid Board Name");
		pressreturn();
		clear();
		return -1;
	}

	if (!(pos = search_board(&fh, bname)))
	{
		move(2, 0);
		prints(NA, "Invalid Board Name");
		pressreturn();
		clear();

		return -1;
	}

	move(3, 0);
	bcopy(&fh, &newfh, sizeof(bhd));
	prints(NA, "�Q�װϦW��: %s\n", fh.filename);
	prints(NA, "�Q�װϻ���: %s\n", fh.title);
        prints(NA, "�ѥ[��H:   %c\n", (fh.flag & BHD_BBSNEWS)? 'Y' : 'N');
	prints(NA, "���s�s��:   %d\n", fh.group);
        prints(NA, "�N�z�t�d�H: %-13s: %-13s: %-13s\n", fh.mngs[0],
                fh.mngs[1], fh.mngs[2]);

	ans = getans(9, 0, "�O�_���]�w? (Yes or No) [N]: ", 'n');

	if (ans == 'y')
		edit_board(&newfh, NA);
	else
		return -1;
	ans = getans(t_lines-2, 0, "�T�w���W�z�]�w(Y/N)? [Y]: ", 'y');
	if (ans != 'n')
	{
		if (substitute_record(BOARDS, (char *)&newfh, sizeof(bhd), pos)
			== -1)
		{
			return -1;
		}
		numboards = -1;
	}
	clear();
	return 0;
}
