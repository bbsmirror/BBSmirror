/*
 * @(#)common.h	1.2	7/2/95
 */

#define	MESSAGE 	1
#define	CHG_NICK	2
#define	CHG_ROOM	3
