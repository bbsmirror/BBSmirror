/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

    @(#)bbs.h	1.3	7/7/95
*/

#ifndef _BBS_H_
#define _BBS_H_

#ifdef HP_UX
/* kludge for TIOCNOTTY in sys/ioctl.h, must defined before include
   of <sys/ioctl.h>  */
#define notdef
#endif   

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <setjmp.h>
#include <stdio.h>
#ifndef	 LINUX
#include <sgtty.h>
#endif
#include <strings.h>
#include <string.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/dir.h>
#include <sys/time.h>
#include <errno.h>
#include <time.h>
#include <sys/resource.h>
#include <pwd.h>
#include <varargs.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <utmp.h>
#include <netdb.h>

#ifdef lint
#include <sys/uio.h>
#endif

#ifndef XINU
#include <sys/stat.h>
#endif

#ifdef SYSV
#include <sys/ipc.h>
#include <sys/sem.h>
#endif

#ifdef AIX
#include <sys/select.h>
#include <arpa/nameser.h>
#endif

#include "config.h"             /* User-configurable stuff */
#include "define.h"
#include "struct.h"
#include "msg.h"

#endif /* _BBS_H_ */
