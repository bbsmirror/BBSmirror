/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef lint
static  char    SccsId[] = "@(#)stuff.c	1.1	7/8/95";
#endif

#include "bbs.h"

int	switch_bit(byte, bit)
int	*byte,
	bit;
{
	if ((*byte)& bit )
		(*byte) &= ~bit;
	else
		(*byte) |= bit;
	return (*byte)& bit;
}

int	cantpage(mode)
int	mode;
{
	if (mode > 150)
		return 1;

	return 0;
}

void	bell(i)
int	i;
{
	int	j;

	for (j=0; j<i; j++)
	{
		usleep(100);
		fprintf(stderr,"%c",CTRL('G'));
	}
}

char	*strtolow(buf1)
char	*buf1;
{
	int	i;
	static	char	buf2[STRLEN*2];

	bzero(buf2, STRLEN);
        for (i = 0; i < strlen(buf1); i++)
                buf2[i] = (isalpha(buf1[i])?buf1[i]|0x20:buf1[i]);

	return buf2;
}

char	*Ctime(clock)
time_t	*clock;
{
	char	*foo,
		*ptr = ctime(clock);

	if ((int)(foo = (char *)rindex(ptr, '\n')))
                *foo = '\0';

	return (ptr);
}

int	strncmpi(s1,s2,n)
char	*s1,
	*s2;
int	n;
{
	for (; n; s1++, s2++, n--)
	{
		int	ret;

		if (*s1=='\0' && *s2 == '\0')
			break;
		if ((ret = (isalpha(*s1)?*s1|0x20:*s1) -
			(isalpha(*s2)?*s2|0x20:*s2)) != 0)
			return ret;
	}

	return 0;
}

char	*buildfile(fname)
char	*fname;
{
	char	path[STRLEN],
		genbuf[STRLEN];
        time_t	dtime;
	int	fp;

	if (access(fname, X_OK|R_OK|W_OK))
		mkdir(fname, 0755);
	strcpy(path, fname);

	(void)time(&dtime);

	while (1)
	{
		sprintf(fname, "P.%d.T", dtime);
		sprintf(genbuf, "%s/%s", path, fname);
		if ((fp = open(genbuf, O_CREAT|O_EXCL|O_WRONLY, 0644)) != -1)
			break;
		dtime += 5;
	}
	close(fp);
	return fname;
}

int 	logit(file, va_alist)
char	*file;
va_dcl
{
	va_list	args;
	char	*fmt;
        time_t  ti;
        FILE    *fp;

	if ((fp = fopen(file, "a+")) == NULL)
		return -1;
	(void)time(&ti);
	va_start(args);
	fmt = va_arg(args, char *);
	fprintf(fp, "[%12.12s] ", Ctime(&ti)+4);
	(void)vfprintf(fp, fmt, args);
	fputs("\n", fp);
	va_end(args);
	fclose(fp);
	return 0;
}
