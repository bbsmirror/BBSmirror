/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
			Guy Vega, gtvega@seabass.st.usm.edu
			Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"

void
standhelp( mesg )
char	*mesg;
{
    standout();
    prints( mesg ) ;
    standend();
}

int
mainreadhelp()
{
    clear() ;
    standhelp( txt_help_menu_prompt );
    standhelp( txt_help_basic );
    prints( txt_help_menu_basic );

    if( HAS_PERM( PERM_POST ) ) prints( txt_help_menu_post);

    prints( "\n" );
    standhelp( txt_help_other );
    prints( txt_help_menu_other );

    if( HAS_PERM( PERM_BOARDS ) ) prints( txt_help_menu_bm );
    if( HAS_PERM( PERM_SYSOP ) ) prints( txt_help_menu_sysop );
    if( HAS_PERM( PERM_FORWARD ) ) prints( txt_help_menu_forward );

    prints( txt_help_menu_redraw );

    pressreturn() ;
    clear() ;
    return FULLUPDATE ;
}

int
mailreadhelp()
{
    clear() ;
    standhelp( txt_help_mail_prompt );
    standhelp( txt_help_cursor );
    prints( txt_help_mail_cursor );

    standhelp( txt_help_basic );
    prints( txt_help_mail_basic );

    if( HAS_PERM( PERM_FORWARD ) ) prints( txt_help_mail_forward );

    prints( txt_help_mail_other );

    pressreturn() ;
    clear() ;
    return FULLUPDATE ;
}

void
Help()
{
    currentuser.flags[0] ^= CURSOR_FLAG;
}

