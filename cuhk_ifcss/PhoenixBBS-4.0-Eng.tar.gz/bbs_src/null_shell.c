#include <stdio.h>

int
main()
{
    printf("It is not a good idea to shell out in BBS\n");
    return 0;
}
