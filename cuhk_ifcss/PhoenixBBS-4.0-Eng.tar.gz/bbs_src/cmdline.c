/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
			Guy Vega, gtvega@seabass.st.usm.edu
			Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"
#include <ndbm.h>

#define HISTORY		"history"
#define HISTORY_OLD	"history.old"
#define HISTORY_TIME	(86400 * 14)

datum
makedatum( data )
char	*data;
{
    datum entry;

    entry.dsize = strlen( data ) + 1; 
    entry.dptr = data;
    return entry; 
}

char *
fetch_entry( db, key )
DBM	*db;
char	*key;
{
    datum	dbm_key, dbm_content;

    dbm_key = makedatum( key );
    dbm_content = dbm_fetch( db, dbm_key );
    return dbm_content.dptr;
}

int
insert_entry( db, key, content )
DBM	*db;
char	*key, *content;
{
    datum dbm_key, dbm_content;

    dbm_key = makedatum( key );
    dbm_content = makedatum( content );
    dbm_store( db, dbm_key, dbm_content, DBM_INSERT );
    return dbm_error( db );
}

char *
fetch_history( msgid )
char	*msgid;
{
    DBM		*db; 
    char	*ptr;

    ptr = NULL;
    db = dbm_open( HISTORY, O_RDWR|O_CREAT, 0644 );
    if( db != NULL ) {
	ptr = fetch_entry( db, msgid );
	dbm_close( db );
    }
    if( ptr == NULL ) {
	db = dbm_open( HISTORY_OLD, O_RDONLY, 0 );
	if( db != NULL ) {
	    ptr = fetch_entry( db, msgid );
	    dbm_close( db );
	}
    }
    return ptr;
}

int
insert_history( msgid, flist )
char	*msgid, *flist;
{
    DBM		*db;

    db = dbm_open( HISTORY, O_RDWR|O_CREAT, 0644 );
    if( db == NULL ) {
	printf( "dbm_open error: %s\n", HISTORY );
	return -1;
    }
    insert_entry( db, msgid, flist );
    dbm_close( db );
    return 0;
}

int
expire_history()
{
    struct stat	fst, bst;
    char	fname[ STRLEN ];
    char	bname[ STRLEN ];

    sprintf( fname, "%s.pag", HISTORY );
    sprintf( bname, "%s.pag", HISTORY_OLD );
    if( stat( fname, &fst ) == -1 )
	return -1;
    if( stat( bname, &bst ) != -1 &&
	bst.st_mtime > fst.st_mtime - HISTORY_TIME ) {
	return -1;
    }
    rename( fname, bname );
    sprintf( fname, "%s.dir", HISTORY );
    sprintf( bname, "%s.dir", HISTORY_OLD );
    rename( fname, bname );
    return 0;
}

char *
fget_line( buf, bsize )
char	*buf;
int	bsize;
{
    char	*ptr;
    int		len;

    if( fgets( buf, bsize, stdin ) == NULL )
	return NULL;
    len = strlen( buf ) - 1;
    while( len >= 0 && (buf[ len ] == '\n' || buf[ len ] == '\r') )
	buf[ len-- ] = '\0';
    if( buf[0] == '.' && buf[1] == '\0' )
	return NULL;
    return buf;
}

/* ----------------------------------------------------------------- */
/* ----------------------------------------------------------------- */
/* ----------------------------------------------------------------- */
/* ----------------------------------------------------------------- */
/* ----------------------------------------------------------------- */

int
cmd_reply( msg )
char	*msg;
{
    printf( "%s\r\n", msg );
}

int
cmd_replymsg( fmt, arg1, arg2 )
char	*fmt, *arg1, *arg2;
{
    char	format[ 256 ];

    sprintf( format, "%s\r\n", fmt );
    printf( format, arg1, arg2 );
}

int
cmd_spooling( flist, flags, uname, title, blist, fname )
char	*flist, *flags, *uname, *title, *blist, *fname;
{
    char	dst[ STRLEN ], *fptr;
    char	bpath[ STRLEN ], *brd;
    int		local, active;

    active = 0;
    fptr = flist;
    local = (*flags == '0' ? 0 : *flags);
    brd = strtok( blist, ", " );
    while( brd != NULL && fptr < flist + (1024 - STRLEN) ) {
	setbpath( bpath, brd );
	if( dashd( bpath ) &&
	    spooling_file( bpath, dst, fname, uname, title, local ) == 0 ) {
	    active = 1;
	    sprintf( fptr, ",%s/%s", brd, dst );
	    fptr += strlen( fptr );
	}
	brd = strtok( NULL, ", " );
    }
    return active;
}

int
cmd_post( fname )
char	*fname;
{
    char	flags[ 80 ];
    char	uname[ 256 ];
    char	msgid[ 256 ];
    char	title[ 256 ];
    char	blist[ 1024 ];
    FILE	*fp;
    char	buf[ 10240 ];

    if( fget_line( flags, sizeof(flags) ) == NULL ||
	fget_line( uname, sizeof(uname) ) == NULL ||
	fget_line( msgid, sizeof(msgid) ) == NULL ||
	fget_line( title, sizeof(title) ) == NULL ||
	fget_line( blist, sizeof(blist) ) == NULL ) {
	cmd_reply( "437 article without header" );
	return -1;
    }
    fp = fopen( fname, "w");
    while( fgets( buf, sizeof(buf), stdin ) != NULL ) {
	if( buf[0] == '.' && (buf[1] == '\n' || buf[1] == '\r') )
	    break;
	fprintf( fp, "%s", buf );
    }
    fclose( fp );

    if( *msgid != '<' || fetch_history( msgid ) != NULL ) {
	cmd_reply( "435 article not wanted" );
    } else if( cmd_spooling( buf, flags, uname, title, blist, fname ) ) {
	insert_history( msgid, buf+1 );
	cmd_replymsg( "235 post %s to %s.", msgid, buf+1 );
    } else {
	cmd_reply( "437 article rejected" );
    }
    unlink( fname );
    return 0;
}

int
cmd_delete()
{
    char	msgid[ 256 ];
    char	ufrom[ 256 ];
    FILE	*fp;
    char	buf[ 256 ], *ptr;
    char	fpath[ 256 ], *fname;
    int		len, active;

    if( fget_line( msgid, sizeof(msgid) ) == NULL ||
	fget_line( ufrom, sizeof(ufrom) ) == NULL ) {
	cmd_reply( "437 delete without header" );
	return -1;
    }
    while( fgets( buf, sizeof(buf), stdin ) != NULL ) {
	if( buf[0] == '.' && (buf[1] == '\n' || buf[1] == '\r') )
	    break;
    }
    if( (ptr = fetch_history( msgid )) == NULL ) {
	cmd_reply( "435 delete unknown msgid" );
	return -1;
    }
    active = 0;
    len = strlen( ufrom );
    fname = strtok( ptr, ", " );
    while( len > 0 && fname != NULL ) {
	if( strncmp( fname, "boards/", 7 ) != 0 ) {
	    sprintf( fpath, "boards/%s", fname );
	    fname = fpath;
	}
	if( (fp = fopen( fname, "r" )) != NULL ) {
	    if( fgets( buf, sizeof(buf), fp ) != NULL &&
		(ptr = strchr( buf, ':' )) != NULL ) {
		ptr++;
		while( *ptr == ' ' )  ptr++;
		if( strncmp( ptr, ufrom, len ) == 0 ) {
		    active = 1;
		    unlink( fname );
		    cache_out( fname, 0 );
		}
	    }
	    fclose( fp );
	}
	fname = strtok( NULL, ", " );
    }
    if( active ) {
	cmd_replymsg( "235 delete %s", msgid, NULL );
    } else {
	cmd_replymsg( "437 file_not_found %s", msgid, NULL );
    }
    expire_history();
    return 0;
}

int
cmd_epost( fname )
char	*fname;
{
    char	flags[ 80 ];
    char	uname[ 256 ];
    char	paswd[ 256 ];
    char	title[ 256 ];
    char	blist[ 1024 ];
    char	rfrom[ 256 ];
    FILE	*fp;
    char	buf[ 10240 ];
    int		now;

    if( fget_line( flags, sizeof(flags) ) == NULL ||
	fget_line( uname, sizeof(uname) ) == NULL ||
	fget_line( paswd, sizeof(paswd) ) == NULL ||
	fget_line( title, sizeof(title) ) == NULL ||
	fget_line( blist, sizeof(blist) ) == NULL ||
	fget_line( rfrom, sizeof(rfrom) ) == NULL ) {
	cmd_reply( "437 email-post without header" );
	return -1;
    }
    if( getuser( uname ) && checkpasswd( lookupuser.passwd, paswd ) ) {
	sprintf( buf, "tmp/email_%s", uname );
	if( (fp = fopen( buf, "w" )) != NULL ) {
	    fprintf( fp, "%s\n", rfrom );
	    fclose( fp );
	}
	now = time( NULL );
	fp = fopen( fname, "w");
	fprintf( fp, txt_cmdline_epost_header_1,
			uname, lookupuser.username, blist );
	fprintf( fp, txt_cmdline_epost_header_2, title ) ;
	fprintf( fp, txt_cmdline_epost_header_3, ctime(&now) ) ;
    } else {
	fp = NULL;
    }
    while( fgets( buf, sizeof(buf), stdin ) != NULL ) {
	if( buf[0] == '.' && (buf[1] == '\n' || buf[1] == '\r') )
	    break;
	if( fp != NULL )
	    fprintf( fp, "%s", buf );
    }
    if( fp == NULL ) {
	cmd_reply( "435 email-post auth error" );
	return -1;
    }
    fclose( fp );

    if( cmd_spooling( buf, flags, uname, title, blist, fname ) ) {
	cmd_replymsg( "235 email-post '%s' to %s.", uname, buf+1 );
    } else {
	cmd_reply( "437 email-post rejected" );
    }
    unlink( fname );
    return 0;
}

int
cmd_mail( fname )
char	*fname;
{
    char	uname[ 256 ];
    char	title[ 256 ];
    char	ulist[ 256 ];
    FILE	*fp;
    char	buf[ 10240 ], *fptr;
    char	mpath[ STRLEN ], *uptr;
    char	dst[ STRLEN ];
    int		active;

    if( fget_line( uname, sizeof(uname) ) == NULL ||
	fget_line( title, sizeof(title) ) == NULL ||
	fget_line( ulist, sizeof(ulist) ) == NULL ) {
	cmd_reply( "437 mail without header" );
	return -1;
    }
    fp = fopen( fname, "w");
    while( fgets( buf, sizeof(buf), stdin ) != NULL ) {
	if( buf[0] == '.' && (buf[1] == '\n' || buf[1] == '\r') )
	    break;
	fprintf( fp, "%s", buf );
    }
    fclose( fp );

    active = 0;
    fptr = buf;
    uptr = strtok( ulist, ", " );
    while( uptr != NULL ) {
	sethomepath( mpath, uptr );
	if( dashd( mpath ) ) {
	    active = 1;
	    sprintf( mpath, "mail/%s", uptr );
	    spooling_file( mpath, dst, fname, uname, title, 0 );
	    sprintf( fptr, ",%s/%s", mpath, dst );
	    fptr += strlen( fptr );
	}
	uptr = strtok( NULL, ", " );
    }
    if( active ) {
	cmd_replymsg( "235 mail '%s' to %s.", uname, buf+1 );
    } else {
	cmd_reply( "437 mail rejected" );
    }
    unlink( fname );
    return 0;
}

int
cmd_expire( fname, command )
char	*fname, *command;
{
    char	*para[5], *ptr;
    char	bpath[ STRLEN ], *brd;
    char	btmp[ STRLEN ];
    int		val[5], n;
    int		days, max, min;
    int		fd, ftmp;

    ptr = strtok( command, " \t\n\r" );
    for( n = 0; n < 5; n++ ) {
	para[n] = ptr;
	val[n] = (ptr ? atoi( ptr ) : 0);
	if( ptr != NULL ) {
	    ptr = strtok( NULL, " \t\n\r" );
	}
    }
    if( (brd = para[1]) == NULL ) {
	cmd_reply( "437 usage: xpire board (days max min)" );
	return -1;
    }
    if( (days = val[2]) < 1 )  days = 60;
    if( (max = val[3]) < 10 )  max = 3000;
    min = val[4];
    setbdir( bpath, brd );
    if( (fd = open( bpath, O_RDONLY, 0 )) < 0 ) {
	cmd_replymsg( "435 expire board unknown: %s, %s", brd, bpath );
	return -1;
    }

/*
    setbpath( btmp, ".tmpfile" );
    if( (ftmp = open( btmp, O_WRONLY|O_CREAT|O_EXCL, 0644 )) > 0 ) {
	flock( 
	close( ftmp );
    }
*/
    close( fd );

    sprintf( bpath, "%d %d %d", days, max, min );
    cmd_replymsg( "235 xpire %s %s", brd, bpath );
    return 0;
}

int
cmdline_main()
{
    char	tmpfile[ 80 ];
    char	buf[ 256 ];

    sprintf( tmpfile, "/tmp/cmdline.%d", getpid() );
    cmd_reply( "200 bbs cmdline (Aug 95')" );
    while( fgets( buf, sizeof(buf), stdin ) != NULL ) {
	switch( buf[0] ) {
	    case 'q':	/* quit */
		cmd_reply( "205 closing connection" );
		return 0;
	    case 'h':	/* help */
		cmd_reply( "100 Command List:" );
		cmd_reply( "  post   + mode user msgid title brds ..." );
		cmd_reply( "  delete + msgid from ." );
		cmd_reply( "  epost  + mode user paswd title brds real ..." );
		cmd_reply( "  mail   + from title ulist" );
		cmd_reply( "  xpire board days max min" );
		cmd_reply( "  quit" );
		cmd_reply( "." );
		break;
	    case 'p':	/* post + flags uname msgid title blist */
		cmd_post( tmpfile );
		break;
	    case 'd':	/* delete + msgid from */
		cmd_delete();
		break;
	    case 'e':	/* epost + flags uname paswd title blist rfrom */
		cmd_epost( tmpfile );
		break;
	    case 'm':	/* mail + uname title ulist */
		cmd_mail( tmpfile );
		break;
	    case 'x':	/* xpire + board days max min */
		cmd_expire( tmpfile, buf );
		break;
	    case '\n':	/* nop */
		break;
	    default:
		cmd_reply( "500 What?" );
	}
    }
    return 0;
}

