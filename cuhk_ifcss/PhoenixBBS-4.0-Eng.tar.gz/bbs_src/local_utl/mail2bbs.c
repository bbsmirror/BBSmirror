/*
 * called by bbsmail inside sendmail
 *
 */

#include	"bbs.h"
#include	<string.h>

#define		DOMAIN_NAME 	"csie.nctu.edu.tw"
#define		BBSHOME		"/home/bbs"
#define		BBSGID		99
#define		BBSUID		9999

char		genbuf[ 1024 ];

int
report()	{}

int	
check_dir (userid)
char	*userid;
{
        struct	stat	st;

        /* check for the home dir for the userid */
        sprintf(genbuf, "%s/home/%s", BBSHOME, userid);
        if (stat(genbuf, &st) == -1) {
            printf("No such user: %s\n", userid );
            return 0;
        } else {
            if(!(st.st_mode & S_IFDIR)) {
                printf("Internal error, no home directory for %s\n", userid );
                return 0;
            }
	}

        /* check for the mail dir for the userid */

	sprintf(genbuf, "%s/mail/%s", BBSHOME, userid);
        if (stat(genbuf, &st) == -1) {
            mkdir( genbuf, 0755 );
	    /* duno why, In some automounted bbs home, 
               mkdir() return -1 even if it successfully
               make the dir. Therefore, call stat() again
               instead of using mkdir()'s return value.
	    */
            if (stat(genbuf, &st) == -1) {
	        printf("Cannot make %s for %s\n", genbuf, userid);
	        return 0;
	    }
        } else {
            if(!(st.st_mode & S_IFDIR)) {
                printf("Internal error, mail directory for %s is bad\n", 
			userid );
                return 0;
	    }
	}

	printf("OK, Mail dir for %s is %s", userid, genbuf );
	return 1;
}


int	
append_mail(fin, sender, userid, title)
FILE	*fin;
char	*sender, *userid, *title;
{
	struct	fileheader newmessage ;
	FILE	*fout;
	char	fname[ 512 ], buf[ 256 ], genbuf[ 256 ] ;
	char	mail_dir[ 512 ];
	char	*ip ;
	int	fp ;

	if (!check_dir( userid )) {
            printf("No such user or something wrong with the user\n");
	    return -1;
	}

	sprintf(mail_dir, "%s/mail/%s", BBSHOME, userid);
/* allocate a record for the new mail */
	memset( &newmessage, '\0', sizeof(newmessage)) ;
	sprintf(fname, "M.%d.A", time(0)) ;
	sprintf(genbuf, "%s/%s", mail_dir, fname) ;
	ip = strrchr(fname,'A') ;
	while((fp = open(genbuf,O_CREAT|O_EXCL|O_WRONLY,0644)) == -1) {
		if(*ip == 'Z')
		  ip++,*ip = 'A', *(ip + 1) = '\0' ;
		else
		  (*ip)++ ;
		sprintf(genbuf,"%s/%s",mail_dir, fname) ;
	}
	close(fp) ;

/* setup the header */
	strcpy(newmessage.filename, fname) ;
	strncpy(newmessage.title, title, STRLEN) ;
	strncpy(newmessage.owner, sender, STRLEN) ;

        printf("Ok, the mail file is %s\n", genbuf );

/* copy the stdin to the specified file */
	sprintf(genbuf,"%s/%s", mail_dir, fname) ;
        if ( (fout = fopen( genbuf, "w" )) == NULL) {
            printf("Cannot open file to write %s \n", genbuf );
            return -1;
        } else {
            time_t tmp_time;
            time( &tmp_time );
            fprintf( fout, "From:      %s via BBS mail gateway\n", sender );
            fprintf( fout, "Title:     %s\n", title );
            fprintf( fout, "Date:      %s\n", ctime( &tmp_time ) );

            while (fgets( genbuf, 255, fin ) != NULL) {
                fputs( genbuf, fout );
            }
            fclose( fout );
        }

/* append the record to the MAIL control file */
	sprintf(genbuf, "%s/%s", mail_dir, DOT_DIR) ;
	if( append_record( genbuf, &newmessage, sizeof(newmessage)) == -1)
	     return 1 ;
        else return 0;
}


int
main(argc, argv) 
int argc;
char *argv[];
{
    char	sender[ 256 ];
    char	username[ 256 ];
    char	*receiver;
    char	*title;	

    if (argc != 4) {
        char *p = strrchr( argv[ 0 ], '/' );

        printf("Usage: %s sender receiver_in_bbs mail_title\n",
             p ? p+1 : argv[ 0 ]);
        return 1;
    }

    receiver = argv[ 2 ];
    title = argv[ 3 ];
    
    if (strchr( argv[ 1 ], '@' )) {
        strcpy(sender, argv[ 1 ]);
    } else {
        char *p, *l, *r;
        char buf[ 256 ];

        strcpy( buf, argv[ 1 ] ); 
        p = strtok( buf , " \t\n\r" );
        l = strchr( argv[ 1 ], '(');
        r = strchr( argv[ 1 ], ')');
        if (l < r && l && r ) strncpy( username, l, r - l + 1 ); 
        sprintf(sender, "%s@%s %s", p, DOMAIN_NAME, username );
    }

    /*
         do NOT use setreuid(), setregid() --- freedom
    */
    setuid( BBSUID );
    setgid( BBSGID );

    return append_mail( stdin, sender, receiver, title);
}
