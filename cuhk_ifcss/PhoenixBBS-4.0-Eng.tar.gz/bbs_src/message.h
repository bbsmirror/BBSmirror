
#ifndef __MESSAGE_H_
#define __MESSAGE_H_

extern char* choosebrdhelp[];
extern char* vedithelp[];
extern char* more_help[];

#ifdef Chinese

    #include "chinese.msg"

#else
  #ifdef English

    #include "english.msg"

  #endif /* end of English */

#endif /* end of Language selection */

#endif /* end of __MESSAGE_H */