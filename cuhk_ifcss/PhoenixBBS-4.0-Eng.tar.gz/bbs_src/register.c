/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
			Guy Vega, gtvega@seabass.st.usm.edu
			Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"

#define  EMAIL		0x0001 
#define  NICK		0x0002 
#define  REALNAME	0x0004 
#define  ADDR		0x0008
#define  REALEMAIL	0x0010
#define  BADEMAIL	0x0020
#define  NEWREG		0x0040

char	*sysconf_str();
char	*genpasswd();
char	*Ctime();

extern char	fromhost[ 60 ];
extern time_t	login_start_time;
time_t		system_time;

int
bad_user_id( userid )
char	*userid;
{
    FILE	*fp;
    char	buf[STRLEN];
    char	*ptr, ch;

    ptr = userid;
    while( (ch = *ptr++) != '\0' ) {
        if( (ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') ||
	    (ch >= '0' && ch <= '9') || ch == '_' ) {
	    ;
	} else {
	    return 1;
	}
    }
    if( (fp = fopen( ".badname", "r" )) != NULL ) {
	while( fgets( buf, STRLEN, fp ) != NULL ) {
	    ptr = strtok( buf, " \n\t\r" );
	    if( ptr != NULL && *ptr != '#' && strcmp( ptr, userid ) == 0 ) {
		fclose( fp );
		return 1;
	    }
	}
	fclose(fp);
    }
    return 0;
}

int 
compute_user_value( urec )
struct userec *urec;
{
    int 	value;

    /* if (urec) has XEMPT permission, don't kick it */
    if( urec->userlevel & PERM_XEMPT )
	return 9999;
    value = (system_time - urec->lastlogin) / 60;    /* min */
	/* new user should register in 30 mins */
    if( strcmp( urec->userid, "new" ) == 0 ) {
	return (30 - value) * 60;
    }
    if( urec->numlogins <= 3 )
	return 10 * 24 * 60 - value;
    if( !(urec->userlevel & PERM_LOGINOK) )
	return 60 * 24 * 60 - value;
    return 90 * 24 * 60 - value;
}

int
getnewuserid()
{
    struct userec utmp, zerorec;
    struct stat	st;
    int		fd, size, val, i;

    system_time = time( NULL );
    if( stat( "tmp/killuser", &st )== -1 || st.st_mtime < system_time-3600 ) {
	if( (fd = open( "tmp/killuser", O_RDWR|O_CREAT, 0600 )) == -1 )
	    return -1;
	write( fd, ctime( &system_time ), 25 );
	close( fd );
	log_usies( "CLEAN", "dated users." );
	printf( txt_reg_search_new );
	memset( &zerorec, 0, sizeof( zerorec ) );
	if( (fd = open( PASSFILE, O_RDWR|O_CREAT, 0600 )) == -1 )
	    return -1;
	size = sizeof( utmp );
	for( i = 0; i < MAXUSERS; i++ ) {
	    if( read( fd, &utmp, size ) != size )
		break;
	    val = compute_user_value( &utmp );
	    if( utmp.userid[0] != '\0' && val < 0 ) {
		sprintf( genbuf, "#%d %-12s %15.15s %d %d %d",
			i+1, utmp.userid, ctime( &(utmp.lastlogin) )+4,
			utmp.numlogins, utmp.numposts, val );
		log_usies( "KILL ", genbuf );
		if( !bad_user_id( utmp.userid ) ) {
		    sprintf( genbuf, "/bin/rm -fr mail/%s", utmp.userid );
		    system( genbuf );
		    sprintf( genbuf, "/bin/rm -fr home/%s", utmp.userid );
		    system( genbuf );
		}
		lseek( fd, -size, SEEK_CUR );
		write( fd, &zerorec, sizeof( utmp ) );
	    }
	}
	close( fd );
	touchnew();
    }
    if( (fd = open( PASSFILE, O_RDWR|O_CREAT, 0600 )) == -1 )
	return -1;
    flock( fd, LOCK_EX );

    i = searchnewuser();
    sprintf( genbuf, "uid %d from %s", i, fromhost );
    log_usies( "APPLY", genbuf );

    if( i <= 0 || i > MAXUSERS ) {
	flock(fd,LOCK_UN) ;
	close(fd) ;
	if( dashf( "etc/user_full" ) ) {
	    ansimore( "etc/user_full", NA );
	    oflush();
	} else {
	    printf( txt_reg_account_full );
	}
	val = (st.st_mtime - system_time + 3660) / 60;
	printf( txt_reg_try_again, val );
	sleep( 2 );
	exit( 1 );
    }
    memset( &utmp, 0, sizeof( utmp ) );
    strcpy( utmp.userid, "new" );
    utmp.lastlogin = time( NULL );
    if( lseek( fd, sizeof(utmp) * (i-1), SEEK_SET ) == -1 ) {
	flock( fd, LOCK_UN );
	close( fd );
	return -1;
    }
    write( fd, &utmp, sizeof(utmp) );
    setuserid( i, utmp.userid );
    flock( fd, LOCK_UN );
    close( fd );
    return i;
}

void
new_register()
{
    struct userec	newuser;
    char	passbuf[ STRLEN ];
    int		allocid, try;

    if( 1 ) {
	time_t  now;

	now = time( 0 );
	sprintf( genbuf, "etc/no_register_%3.3s", ctime( &now ) );
	if( dashf( genbuf ) ) {
	    ansimore( genbuf, NA );
	    pressreturn();
	    exit( 1 );
	}
    }
    memset( &newuser, 0, sizeof(newuser) );
    allocid = getnewuserid()  ;
    if(allocid > MAXUSERS || allocid <= 0) {
	printf("No space for new users on the system!\n\r") ;
	exit(1) ;
    }

    ansimore("etc/register", NA);
    try = 0;
    while( 1 ) {
	if( ++try >= 10 ) {
	    prints("\nBye Bye, 10 <Enter> makes you leave.\n");
	    refresh();
	    longjmp( byebye, -1 );
	}
	getdata(0,0,txt_reg_set_uid,newuser.userid,IDLEN+1,DOECHO,NULL) ;

        if ( (*newuser.userid == '\0') || bad_user_id( newuser.userid ) ) {
	    prints( txt_reg_uid_unacceptable );
	} else if( dosearchuser( newuser.userid ) ) { 
            prints(txt_reg_uid_been_used) ;
        } else {
	    break;
	}
    }

    while( 1 ) {
	getdata(0,0,txt_reg_set_pwd,passbuf,PASSLEN,NOECHO,NULL) ;
	if( strlen( passbuf ) < 4 || !strcmp( passbuf, newuser.userid ) ) {
            prints(txt_reg_short_pwd) ;
	    continue;
	}
	strncpy( newuser.passwd, passbuf, PASSLEN );
	getdata(0,0,txt_reg_chk_pwd,passbuf,PASSLEN,NOECHO,NULL);
	if( strncmp( passbuf, newuser.passwd, PASSLEN ) != 0 ) {
	    prints(txt_reg_chk_pwd_fail) ;
	    continue;
        }
	passbuf[8] = '\0' ;
	strncpy( newuser.passwd, genpasswd( passbuf ), PASSLEN );
	break;
    }
    getdata(0,0,txt_reg_set_termtype,newuser.termtype,16,DOECHO,NULL);
    if( newuser.termtype[0] == '\0' ) {
	strcpy(newuser.termtype, "vt100");
    }
    newuser.userlevel = PERM_DEFAULT;
    newuser.flags[0] = CURSOR_FLAG;
    newuser.flags[1] = 0;
    newuser.firstlogin = newuser.lastlogin = time(NULL) ;

    if( substitute_record(PASSFILE,&newuser,sizeof(newuser),allocid) == -1 ) {
	fprintf(stderr,"too much, good bye!\n") ;
	exit(1) ;
    }
    setuserid( allocid, newuser.userid );
    if( !dosearchuser(newuser.userid) ) {
	fprintf(stderr,"User failed to create\n") ;
	exit(1) ;
    }
    report( "new account" );
}

char *
trim( s )
char *s;
{
    static char buf[ 256 ];
    char *l, *r;

    buf[ 0 ] = '\0' ;
    r = s + strlen( s ) - 1;

    for (l = s ; strchr(" \t\r\n", *l) && *l; l++);

    /* if all space, *l is null here, we just return null */
    if (*l != '\0') {   
        for ( ; strchr(" \t\r\n", *r) && r >= l ; r-- );
        strncpy( buf, l, r - l + 1 );
    }
    return buf;
}

int
invalid_realmail( userid, email, msize )
char	*userid, *email;
int	msize;
{
    FILE	*fn;
    char	*emailfile, ans[2];
    int		now;

    if( (emailfile = sysconf_str( "EMAILFILE" )) == NULL )
	return 0;
    if( strchr( email, '@' ) && valid_ident( email ) )
	return 0;
    ansimore( emailfile, NA );
    getdata(t_lines-1,0,txt_reg_sure_epos,
	ans,2,DOECHO,NULL);
    while( *ans != 'n' && *ans != 'N' ) {
	sprintf( genbuf, "tmp/email_%s", userid );
	if( (fn = fopen( genbuf, "r" )) != NULL ) {
	    fgets( genbuf, STRLEN, fn );
	    fclose( fn );
	    strtok( genbuf, "\n" );
	    if( !valid_ident( genbuf ) ) {
		move( t_lines-2, 0 );
		clrtoeol();
		prints( txt_reg_err_addr, genbuf );
	    } else if( strchr( genbuf, '@' ) != NULL ) {
		strncpy( email, genbuf, msize );
		move( t_lines-1, 0 );
		prints( txt_reg_got_epos );
		return 0;
	    }
	}
	now = time( NULL );
	sprintf( genbuf,txt_reg_not_get_epos_yet,
		Ctime(&now) );
	getdata( t_lines-1,0,genbuf,ans,2,DOECHO,NULL );
    }
    return 1;
}

void
check_register_info()
{
    struct userec *urec = &currentuser;
    char	*newregfile;
    int		perm;

    clear();
    if( !(urec->userlevel & PERM_BASIC) ) {
	urec->userlevel = 0;
	return;
    }
    urec->userlevel |= PERM_DEFAULT;
    perm = PERM_DEFAULT & sysconf_eval( "AUTOSET_PERM" );

    if( sysconf_str( "IDENTFILE" ) != NULL ) {
	while( strlen( urec->username ) < 2 ) {
	    move( 1, 0 );
	    prints( txt_reg_set_nickname );
	    getdata( 2, 0, "> ", urec->username, NAMELEN,DOECHO,NULL );
	}
	while( strlen( urec->realname ) < 3 ) {
	    move( 3, 0 );
	    prints( txt_reg_set_realname );
	    getdata( 4, 0, "> ", urec->realname, NAMELEN,DOECHO,NULL );
	}
	while( strlen( urec->address ) < 10 ) {
	    move( 5, 0 );
	    prints( txt_reg_set_fulladdr );
	    getdata( 6, 0, "> ", urec->address, NAMELEN,DOECHO,NULL );
	}
	while( strchr( urec->email, '@' ) == NULL ) {
	    move( 7, 0 );
	    prints( txt_reg_set_email_addr,
		urec->userid, email_domain() );
	    getdata( 8, 0, "> ", urec->email, STRLEN,DOECHO,NULL );
	}
    }

    if( !HAS_PERM( PERM_SYSOP ) &&
	invalid_realmail( urec->userid, urec->termtype+16, STRLEN-16 ) ) {
	urec->userlevel &= ~(perm);
    }

    newregfile = sysconf_str( "NEWREGFILE" );
    if( urec->lastlogin - urec->firstlogin < 3*86400 &&
	!HAS_PERM( PERM_SYSOP) && newregfile != NULL ) {
	urec->userlevel &= ~(perm);
	ansimore( newregfile, YEA );
    }

    if( HAS_PERM( PERM_DENYPOST ) && !HAS_PERM( PERM_SYSOP ) )
        currentuser.userlevel &= ~PERM_POST;
}

