/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
			Guy Vega, gtvega@seabass.st.usm.edu
			Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"

extern time_t	login_start_time;
char *genpasswd() ;

void
user_display( u, real )
struct userec *u ;
int	real;
{
    struct stat st;
    int		num, diff;

    move(3,0);
    clrtobot();
    prints(txt_usrinfo_uid, u->userid);
    prints(txt_usrinfo_nickname, u->username);
    prints(txt_usrinfo_realname, u->realname);
    prints(txt_usrinfo_live_addr, u->address);
    prints(txt_usrinfo_email_box, u->email);
    if( real ) {
	prints(txt_usrinfo_real_email_addr, u->termtype + 16 );
	prints(txt_usrinfo_id_info, u->ident );
    }
    prints(txt_usrinfo_term_type, u->termtype );
    prints(txt_usrinfo_reg_date, ctime( &u->firstlogin));
    prints(txt_usrinfo_last_date, ctime( &u->lastlogin));
    if( real ) {
	prints(txt_usrinfo_last_machine, u->lasthost );
    }
    prints(txt_usrinfo_login_times, u->numlogins);
    if( real ) {
	prints(txt_usrinfo_posts_count,
           u->numposts, post_in_tin( u->userid ));
    }

    sprintf( genbuf, "mail/%s/%s", u->userid, DOT_DIR );
    if( stat( genbuf, &st ) >= 0 )
	num = st.st_size / (sizeof( struct fileheader ));
    else
	num = 0;
    prints(txt_usrinfo_personal_email, num );

    if( real ) {
	strcpy( genbuf, "bTCPRp#@XWBA#VS-" );
	for( num = 0; num < 16; num++ )
	    if( !(u->userlevel & (1 << num)) )
		genbuf[num] = '-';
	genbuf[num] = '\0';
	prints(txt_usrinfo_usr_right, genbuf );
    } else {
	diff = (time(0) - login_start_time) / 60;
	prints(txt_usrinfo_stay_time, diff / 60, diff % 60 );
	prints(txt_usrinfo_screen_size, t_lines, t_columns );
    }
    prints("\n");
    if( u->userlevel & PERM_LOGINOK ) {
	prints(txt_usrinfo_reg_ok);
    } else if( u->lastlogin - u->firstlogin < 3 * 86400 ) {
	prints(txt_usrinfo_new_usr );
    } else {
	prints(txt_usrinfo_reg_not_done);
    }
}

int
uinfo_query( u, real, unum )
struct userec *u ;
int	real, unum;
{
    struct userec	newinfo;
    char	ans[2], buf[ STRLEN ];
    int		i, fail = 0;

    memcpy( &newinfo, u, sizeof(currentuser));
    getdata( t_lines-1, 0, real ?
	txt_usrinfo_select_1 : txt_usrinfo_select_2,
	ans, 2, DOECHO, NULL );
    clear();
    refresh();

    i = 3;
    move( i++, 0 );
    prints(txt_usrinfo_uid_2, u->userid );

    switch( ans[0] ) {
	case '1':
	    move( 1, 0 );
	    prints(txt_usrinfo_modify_raws);

	    sprintf( genbuf, txt_usrinfo_nickname_2, u->username );
	    getdata( i++, 0, genbuf, buf, NAMELEN, DOECHO, NULL );
	    if( buf[0] ) strncpy( newinfo.username, buf, NAMELEN );

	    sprintf( genbuf, txt_usrinfo_realname_2, u->realname );
	    getdata( i++, 0, genbuf, buf, NAMELEN, DOECHO, NULL );
	    if( buf[0] ) strncpy( newinfo.realname, buf, NAMELEN );

	    sprintf( genbuf, txt_usrinfo_live_addr_2, u->address );
	    getdata( i++, 0, genbuf, buf, STRLEN, DOECHO, NULL );
	    if( buf[0] ) strncpy( newinfo.address, buf, NAMELEN );

	    sprintf( genbuf, txt_usrinfo_email_box_2, u->email );
	    getdata( i++, 0, genbuf, buf, STRLEN, DOECHO, NULL );
	    if( buf[0] ) strncpy( newinfo.email, buf, STRLEN );

	    sprintf( genbuf, txt_usrinfo_term_type_2, u->termtype );
	    getdata( i++, 0, genbuf, buf, 16, DOECHO, NULL );
	    if( buf[0] ) strncpy( newinfo.termtype, buf, 16 );

	if( real ) {
	    sprintf( genbuf, txt_usrinfo_real_email_addr_2, u->termtype+16 );
	    getdata( i++, 0, genbuf, buf, STRLEN, DOECHO, NULL );
	    if( buf[0] ) strncpy( newinfo.termtype+16, buf, STRLEN-16 );

	    sprintf( genbuf, txt_usrinfo_login_times_2, u->numlogins );
	    getdata( i++, 0, genbuf, buf, 16, DOECHO, NULL );
	    if( atoi( buf ) > 0 ) newinfo.numlogins = atoi( buf );

	    sprintf( genbuf, txt_usrinfo_post_count_2, u->numposts );
	    getdata( i++, 0, genbuf, buf, 16, DOECHO, NULL );
	    if( atoi( buf ) > 0 ) newinfo.numposts = atoi( buf );
	}

	    break;
	case '2':
	    if( ! real ) {
		getdata(i++,0,txt_usrinfo_enter_org_psswd,buf,PASSLEN,NOECHO,NULL);
		if( *buf == '\0' || !checkpasswd( u->passwd, buf )) {
		    prints(txt_usrinfo_psswd_failed);
		    fail++;
		    break;
		}
	    }
	    getdata(i++,0,txt_usrinfo_enter_new_psswd,buf,PASSLEN,NOECHO,NULL);
	    if( buf[0] == '\0' ) {
		prints(txt_usrinfo_psswd_unchange);
		fail++;
		break;
	    }
	    strncpy(genbuf,buf,PASSLEN) ;

	    getdata(i++,0,txt_usrinfo_reenter_new_passwd,buf,PASSLEN,NOECHO,NULL);
	    if(strncmp(buf,genbuf,PASSLEN)) {
		prints(txt_usrinfo_new_psswd_failed);
		fail++;
		break;
	    }
	    buf[8] = '\0';
	    strncpy( newinfo.passwd, genpasswd( buf ), PASSLEN );
	    break;
	case '3':
	    if( ! real ) {
		clear();
		return 0;
	    }
	    getdata(i++,0,txt_usrinfo_new_uid,genbuf,IDLEN,DOECHO,NULL);
	    if(*genbuf != '\0') {
		if(getuser(genbuf)) {
		    prints(txt_usrinfo_new_uid_exist) ;
		    fail++;
		} else {
		    strncpy(newinfo.userid, genbuf,IDLEN+2) ;
		}
	    }
	    break;
	default:
	    clear();
	    return 0;
    }
    if( fail != 0 ) {
	pressreturn();
	clear();
	return 0;
    }
    getdata(t_lines-1,0,txt_usrinfo_sure_change,ans,2,DOECHO,NULL);
    if( *ans == 'y' || *ans == 'Y' ) {
	if( strcmp( u->userid, newinfo.userid ) ) {
	    char src[ STRLEN ], dst[ STRLEN ];

	    sprintf( src, "mail/%s", u->userid );
	    sprintf( dst, "mail/%s", newinfo.userid );
	    rename( src, dst );
	    sethomepath( src, u->userid );
	    sethomepath( dst, newinfo.userid );
	    rename( src, dst );
	    setuserid( unum, newinfo.userid );
	}
	memcpy( u, &newinfo, sizeof(newinfo) );
	substitute_record( PASSFILE, &newinfo, sizeof(newinfo), unum );
    }
    clear();
    return 0;
}

void
x_info()
{
    user_display( &currentuser, 0 );
    if (!strcmp("guest", currentuser.userid)) {
        pressreturn();
        return;
    }
    uinfo_query( &currentuser, 0, usernum );
}

void
getfield( line, info, desc, buf, len )
int	line, len;
char	*info, *desc, *buf;
{
    char	prompt[ STRLEN ];

    sprintf( genbuf, txt_usrinfo_was_set, buf, info );
    move( line, 0 );
    prints( genbuf );
    sprintf( prompt, "  %s: ", desc );
    getdata( line+1, 0, prompt, genbuf, len, DOECHO, NULL );
    if( genbuf[0] != '\0' ) {
	strncpy( buf, genbuf, len );
    }
    move( line, 0 );
    clrtoeol();
    prints( "  %s: %s\n", desc, buf );
    clrtoeol();
}

void
x_fillform()
{
    char	rname[ NAMELEN ], addr[ STRLEN ];
    char	phone[ STRLEN ], career[ STRLEN ];
    char	ans[3], *mesg, *ptr;
    FILE	*fn;
    time_t	now;

    move( 3, 0 );
    clrtobot();
    if (!strcmp("guest", currentuser.userid)) {
	prints( txt_usrinfo_new_before_reg );
        pressreturn();
        return;
    }
    if( currentuser.userlevel & PERM_LOGINOK ) {
	prints( txt_usrinfo_reg_identified );
        pressreturn();
        return;
    }
    if( (fn = fopen( "new_register", "r" )) != NULL ) {
	while( fgets( genbuf, STRLEN, fn ) != NULL ) {
	    if( (ptr = strchr( genbuf, '\n' )) != NULL )
		*ptr = '\0';
	    if( strncmp( genbuf, "userid: ", 8 ) == 0 &&
		strcmp( genbuf + 8, currentuser.userid ) == 0 ) {
		fclose( fn );
		prints( txt_usrinfo_reg_form_wait );
		pressreturn();
		return;
	    }
	}
	fclose( fn );
    }
    getdata(3,0,txt_usrinfo_sure_fill_reg_form,ans,3,DOECHO,NULL);
    if( ans[0] != 'Y' && ans[0] != 'y' )
	return;
    strncpy( rname, currentuser.realname, NAMELEN );
    strncpy( addr,  currentuser.address,  STRLEN  );
    career[0] = phone[0] = '\0';
    while( 1 ) {
	move( 3, 0 );
	clrtoeol();
	prints( txt_usrinfo_fill_reg, currentuser.userid ); 
	getfield(  6, txt_usrinfo_use_pr_lang, txt_usrinfo_fill_realname, rname, NAMELEN );
	getfield(  8, txt_usrinfo_fill_institute, txt_usrinfo_fill_program, career,STRLEN );
	getfield( 10, txt_usrinfo_fill_roomnum, txt_usrinfo_fill_curaddr, addr,  STRLEN );
	getfield( 12, txt_usrinfo_fill_daytime, txt_usrinfo_fill_dayphone, phone, STRLEN );
	mesg = txt_usrinfo_sure_done_form;
	getdata(t_lines-1,0,mesg,ans,3,DOECHO,NULL);
	if( ans[0] == 'Q' || ans[0] == 'q' )
	    return;
	if( ans[0] == 'Y' || ans[0] == 'y' )
	    break;
    }
    strncpy( currentuser.realname, rname,  NAMELEN );
    strncpy( currentuser.address,  addr,   STRLEN  );
    if( (fn = fopen( "new_register", "a" )) != NULL ) {
	now = time( NULL );
	fprintf( fn, "usernum: %d, %s",	usernum, ctime( &now ) );
	fprintf( fn, "userid: %s\n",	currentuser.userid );
	fprintf( fn, "realname: %s\n",	rname );
	fprintf( fn, "career: %s\n",	career );
	fprintf( fn, "addr: %s\n",	addr );
	fprintf( fn, "phone: %s\n",	phone );
	fprintf( fn, "----\n" );
	fclose( fn );
    }
}

