#include <stdlib.h>
#include <string.h>

void
printdash( mesg )
char    *mesg;
{
    char        buf[ 80 ], *ptr;
    int         len;

    memset( buf, '-', 79 );
    buf[ 79 ] = '\0';
    if( mesg != NULL ) {
        len = strlen( mesg );
        if( len > 76 )  len = 76;
        ptr = &buf[ 40 - len / 2 ];
        ptr[ -1  ] = ' ';
        ptr[ len ] = ' ';
        strncpy( ptr, mesg, len );
    }
    prints( "%s\n", buf );
}

