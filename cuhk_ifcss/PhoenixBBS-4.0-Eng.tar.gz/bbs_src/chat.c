/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
			Guy Vega, gtvega@seabass.st.usm.edu
			Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"
#include "chat.h"
#ifdef lint
#include <sys/uio.h>
#endif
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

int chatroom;
int chatline;
int echatwin;
extern char page_requestor[];
extern char BoardName[];
extern int talkrequest;
extern char *modestring();
extern char pagerchar();
extern char *Ctime();

int
x_read(sock, buf, size)
int   sock;
char  *buf;
int   size;
{
    int  i, ret;
 
    ret = read(sock, buf, size);
    for ( i = 0; i < size; i++) 
        if (buf[ i ]) buf[ i ] ^= 0xff; 
    return ret;
}

int
x_write(sock, buf, size)
int  sock;
char *buf;
int  size;
{
    int i, ret;

    for ( i = 0; i < size; i++) 
    if (buf[ i ]) buf[ i ] ^= 0xff;
    ret = write(sock, buf, size);
    return ret; 
}

void
fixchatid(chatid)
char *chatid;
{
    while (*chatid != '\0' && *chatid != '\n') {
	if (strchr(BADCIDCHARS, *chatid)) *chatid = '_';
	chatid++;
    }
}

char *
advance(ptr)
char *ptr;
{
    while (*ptr != ' ' && *ptr != '\n' && *ptr != '\t') {
	if (*ptr == '\0') return ptr;
	else ptr++;
    }
    while (*ptr == ' ' || *ptr == '\n' || *ptr == '\t')
	ptr++;
    *(ptr-1) = '\0';
    return ptr;
}

void
printprivmsg(to_ptr)
char *to_ptr;
{
    char *fromptr = advance(to_ptr);
    char *msgptr = advance(fromptr);

    if (!ci_strncmp(to_ptr, currentuser.userid, sizeof(currentuser.userid))) {
	char buf[STRLEN];
	sprintf(buf, "*%s* %s", fromptr, msgptr);
	standout();
	printchatline(buf);
	standend();
    }
}

void
printinfoline(cmd)  /* re-written slightly by !DK! */
char *cmd;
{
    char *nextarg;
    char buf[STRLEN];

    nextarg = advance(cmd);
    if ((!strcmp(cmd, "sysopin") && HAS_PERM(PERM_SYSOP)) ||
	(!strcmp(cmd, "cloakin") && HAS_PERM(PERM_SEECLOAK)) ) {
	sprintf(buf, txt_chat_cloak_in, nextarg);
	printchatline(buf);
    } else if ((!strcmp(cmd, "sysopout") && HAS_PERM(PERM_SYSOP)) ||
	    (!strcmp(cmd, "cloakout") && HAS_PERM(PERM_SEECLOAK)) ) {
	sprintf(buf, txt_chat_cloak_out, nextarg);
	printchatline(buf);
    } else if (!strcmp(cmd, "to")) {
            printprivmsg(nextarg);
    } else if (!strcmp(cmd, "nick") ||
		(!strcmp(cmd, "inick") && HAS_PERM(PERM_SEECLOAK)) ||
		(!strcmp(cmd, "snick") && HAS_PERM(PERM_SYSOP))) {
	sprintf(buf, txt_chat_rename, nextarg, advance(nextarg));
	printchatline(buf);
    }
}

int
printchatent(uentp)
struct user_info *uentp;
{
    static char uline[80];
    static int	cnt;
    char	pline[30];
    int		mymode;

    switch (chatroom) {
	case '1': mymode = CHAT1; break;
	case '2': mymode = CHAT2; break; 
	case '3': mymode = CHAT3; break;
	case '4': mymode = CHAT4; break;
	default:  mymode = CHAT1; break;
    }
    if (!uentp) {
	if (cnt) printchatline(uline);
	memset(uline, 0, 80);
	cnt = 0;
	return 0;
    }
    if (!uentp->active || !uentp->pid) return 0;
    if (uentp->mode != mymode) return 0;
    if (!HAS_PERM(PERM_SEECLOAK) && uentp->invisible) return 0;
    sprintf(pline, "%-10s %c%-12s", uentp->chatid, uentp->invisible?'#':' ',
		uentp->userid);
    if (cnt < 2) strcat(pline, "   ");
    strcat(uline, pline);
    if (++cnt == 3) {
	cnt = 0;
	printchatline(uline);
	memset(uline, 0, 80);
    }
    return 0;
}

int
t_chat()
{
    extern int dumb_term ;
    struct hostent *h ;
    struct sockaddr_in sin ;
    char	chatid[STRLEN] ;
    char	hostname[STRLEN] ;
    char	chatstr[80];
    char	inbuf[80] ;
    char	*colon;
    int		a, currchar, chatport;
    int		pline;
    int		newmail = 0;
    int page_pending = NA;

    inbuf[0]='\0'; 
    chatline = 0 ;
    currchar = 0 ;
    strcpy(chatid,currentuser.userid) ;
    chatid[8] = '\0' ;
    fixchatid(chatid);
    strcat(chatid, ":           ") ; /* shortened by !DK! */
    chatid[10] = '\0' ;
    strcpy(inbuf,chatid) ;
    gethostname(hostname,STRLEN) ;
    if (!(h = gethostbyname(hostname))) {
	perror("gethostbyname");
	return -1;
    }
    memset(&sin, 0,sizeof sin) ;
    sin.sin_family = h->h_addrtype ;
    memcpy( &sin.sin_addr, h->h_addr, h->h_length) ;
    chatport = CHATPORT_BASE + chatroom;
    sin.sin_port = chatport;
    a = socket(sin.sin_family, SOCK_STREAM, 0); 
    if((connect(a, (struct sockaddr *)&sin, sizeof sin))) {
	move(2,0) ;
	prints(txt_chat_open_chatroom) ;
	refresh() ;
	close(a) ;
	sprintf(chatstr, "bin/bbs.chatd %d", chatport );
	system(chatstr);
	sleep(2) ;
	a = socket(sin.sin_family, SOCK_STREAM, 0); 
	if((connect(a, (struct sockaddr *)&sin, sizeof sin))) {
	    perror("connect err") ;
	    return -1 ;
	}
    }
    switch(chatroom) {
	case '1': uinfo.mode = CHAT1; break;
	case '2': uinfo.mode = CHAT2; break;
	case '3': uinfo.mode = CHAT3; break;
	case '4': uinfo.mode = CHAT4; break;
	default:  uinfo.mode = CHAT1; break;
    }
    uinfo.in_chat = YEA;
    strncpy(uinfo.chatid, chatid, 10);
    if( (colon = strrchr(uinfo.chatid, ':')) != NULL )
	*colon = '\0';
    update_utmp();
    if (uinfo.invisible) {
	if (HAS_PERM(PERM_SYSOP))
	    sprintf(inbuf, "/sysopin %s", uinfo.chatid);
	else sprintf(inbuf, "/cloakin %s", uinfo.chatid);
    } else
	sprintf(inbuf, "%sWelcome!", chatid);
    x_write(a,inbuf,strlen(inbuf)+1) ;
    clear() ;
    sprintf(inbuf, txt_chat_help_chatroom, BoardName);
    printchatline(inbuf);
    printchatline("  ");
    strcpy(inbuf,chatid) ;
    pline = t_lines - 1 ;
    echatwin = t_lines - 2 ;
    move(echatwin,0) ;
    printdash( NULL );
    move(pline,0) ;
    if(!dumb_term)
	prints("%s",inbuf) ;
    currchar = strlen(inbuf) ;
    add_io(a,0) ;
    while(YEA) {
	int ch = igetch();

	if (talkrequest) page_pending = YEA;
	if (page_pending)
	    page_pending = servicepage( 0, NULL );	
	if (!newmail && chkmail()) {
	    newmail = 1;
	    move(echatwin,0);
	    printdash( txt_chat_new_mail );
	}
	if(ch == I_OTHERDATA) {
	    static int cnt  = 0;
	    int cc ;
	    static char buf[512] ;
			
	    if((cc = x_read(a,buf+cnt,sizeof buf)) > 0) {
		int processed = 0 ;

		while(cc > 0) {
		    register int i ;
		    for(i=processed;buf[i] != '\0' && i != sizeof buf;i++)
                          /* NULL STATEMENT */ ;
		    if(i==sizeof buf && buf[i] != '\0') {
			memcpy(buf,buf+processed,processed-sizeof(buf)) ;
			cnt = processed - sizeof(buf) ;
			break ;
		    }
		    cnt = 0 ;
		    if (*(buf+processed) == '/')
			printinfoline(buf+processed+1);
		    else 
			printchatline(buf+processed);
		    i++ ;
		    cc -= (i - processed) ;
		    processed = i ;
		    if(i == sizeof buf)
                        break ;
		}
	    } else {  /* trap for chat daemon death */
		sprintf(buf, "char read err %d, no %d\n", cc, errno);
		report(buf);
		break;
	    }
	    move(pline,currchar) ;
	    continue ;
	}
	if(isprint2(ch)) {
	    if(currchar == 78) {
		continue ;
	    }
	    inbuf[currchar] = ch ;
	    currchar++ ;
	    inbuf[currchar] = '\0' ;
	    move(pline,currchar-1) ;
	    prints("%c",ch) ;
	    continue ;
	}
	if(ch == '\n' || ch == '\r') {
	    char buf[STRLEN] ;
	    int i,j ;
            
	    if(dumb_term) prints("\n") ;
	    for(i=10,j=0;i<STRLEN;i++) {
		if(inbuf[i] == '\0') {
		    buf[j] = '\0' ;
		    break ;
		}
		if(inbuf[i] != ' ')
		    buf[j++] = inbuf[i] ;
	    }
	    if(buf[0] == '\0')
		continue ;
	    if(!strcmp(buf,"Goodbye!")) {
		report("exit chat!");
		if (uinfo.invisible) {
		    if (HAS_PERM(PERM_SYSOP))
			sprintf(inbuf, "/sysopout %s", uinfo.chatid);
		    else sprintf(inbuf, "/cloakout %s", uinfo.chatid);
		} else
		    sprintf(inbuf,"%sGoodbye!",chatid) ;
		x_write(a,inbuf,strlen(inbuf)+1) ;
		break ;
	    }
	    if (inbuf[10] == '/') {
		int action = dochatcommand(&inbuf[11], a);

		if (action == 1) {
		    strcpy(chatid, uinfo.chatid);
		    chatid[8] = '\0' ;
		    strcat(chatid,":                      ") ;
		    chatid[10] = '\0' ;
		} else if (action == -1) {
		    sprintf(buf, "chat write err -1, no %d\n", errno);
		    report(buf);
		    break;
		}
	    } else if (x_write(a,inbuf,strlen(inbuf)+1) == -1) {
		sprintf(buf, "chat write err -1, no %d\n", errno);
		report(buf);
		break;
	    }
	    move(pline,0) ;
	    strcpy(inbuf,chatid) ;
	    currchar = strlen(inbuf) ;
	    if(!dumb_term) prints("%s",inbuf) ;
	    clrtoeol() ;
	    move(pline,currchar) ;
	    continue ;
	}
	if(ch == Ctrl('H') || ch == '\177') {
	    if(currchar == 10) {
		continue ;
	    }
	    currchar-- ;
	    move(pline,currchar) ;
	    if(dumb_term)
		ochar(Ctrl('H')) ;
	    else
		prints(" ") ;
	    move(pline,currchar) ;
	    inbuf[currchar] = '\0' ;
	    continue ;
	}
	if(ch == Ctrl('C') || ch == Ctrl('D')) {
	    if (uinfo.invisible) {
		if (HAS_PERM(PERM_SYSOP))
		    sprintf(inbuf, "/sysopout %s", uinfo.chatid);
		else sprintf(inbuf, "/cloakout %s", uinfo.chatid);
	    } else
		sprintf(inbuf,"%sGoodbye!",chatid) ;
	    x_write(a,inbuf,strlen(inbuf)+1) ;
	    break ;
	}
    }
    add_io(0,0) ;
    close(a) ;
    uinfo.in_chat = NA;
    uinfo.chatid[0] = '\0';
    clear() ;
    return  0;
}

int
printchatline(str)
char *str;
{
    move(chatline++,0) ;
    clrtoeol() ;
    prints("%s\n",str) ;
    if(chatline == echatwin)
	chatline = 0 ;
    move(chatline,0) ;
    clrtoeol() ;
    if(!dumb_term)
	prints("-->") ;
    return 0;
}

void
chat_userhead( mesg, fmt, f1, f2 )
char	*mesg, *fmt, *f1, *f2;
{
    char buf[ STRLEN ], tmp[ STRLEN ];

    printchatline(" ");
    sprintf( buf, txt_chat_friend_list, mesg );
    printchatline( buf );
    sprintf( tmp, fmt, f1, f2 );
    sprintf( buf, "%s   %s   %s", tmp, tmp, tmp );
    printchatline( buf );
    sprintf( tmp, fmt, "------", "------" );
    sprintf( buf, "%s   %s   %s", tmp, tmp, tmp );
    printchatline( buf );
}

int
dowho()
{
    chat_userhead( txt_chat_in_chat, "%-10s  %-12s", "Chatid", "Userid" );
    if (apply_ulist( printchatent ) == -1) {
	printchatline("(nobody)");
	return 0;
    }
    printchatent(NULL);
    return 0;
}

int
printuserent(uentp)
struct user_info *uentp;
{
    static char uline[80];
    static int	cnt;
    char	pline[30];

    if (!uentp) {
	if (cnt) printchatline(uline);
	memset(uline, 0, 80);
	cnt = 0;
	return 0;
    }
    if (!uentp->active || !uentp->pid) return 0;
    if (!HAS_PERM(PERM_SEECLOAK) && uentp->invisible) return 0;
    sprintf(pline, "%-12s %c%-10s", uentp->userid, uentp->invisible?'#':' ',
		modestring(uentp->mode, uentp->destuid, 0, NULL));
    if (cnt < 2) strcat(pline, "   ");
    strcat(uline, pline);
    if (++cnt == 3) {
	cnt = 0;
	printchatline(uline);
	memset(uline, 0, 80);
    }
    return 0;
}

int
dousers()
{
    chat_userhead( txt_chat_log_on, "%-12s  %-10s", "Userid", "Mode" );
    if (apply_ulist( printuserent ) == -1) {
	printchatline("(nobody)");
	return 0;
    }
    printuserent(NULL);
    return 0;
}

int chat_real_names = 0;

int
printlongent(uentp)
struct user_info *uentp;
{
    char	*fmt = "%-12s %-22s %-16.16s %c %c %s";
    char	buf[80];
    char	*field2;

    field2 = "User Name";
    if (chat_real_names) field2 = "Real Name";
    if (uentp == NULL) {
	printchatline(" ");
	printchatline(txt_chat_users_list);
	sprintf( buf, fmt, "User ID", field2, "From", 'P',
		 HAS_PERM(PERM_SEECLOAK) ? 'C' : ' ', "Mode" );
	printchatline(buf);
	sprintf( buf, fmt, "-------", "---------", "----", '-',
		 HAS_PERM(PERM_SEECLOAK) ? '-' : ' ', "----" );
	printchatline(buf);
	return(0);
    }
    if (!uentp->active || !uentp->pid)
	return 0;
    if (!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
	return 0;
    sprintf(buf, fmt, uentp->userid,
	(chat_real_names ? uentp->realname : uentp->username),
	uentp->from, pagerchar(currentuser.userid,uentp->userid,uentp->pager),
	uentp->invisible?'#':' ', modestring(uentp->mode, uentp->destuid, 1,
	uentp->in_chat ? uentp->chatid : NULL));
    printchatline(buf);
    return 0;
}

void
dolong()
{
    printlongent(NULL);
    if (apply_ulist( printlongent ) == -1)
	printchatline("(nobody)");
}

void
doreal()
{
    chat_real_names = 1;
    dolong();
    chat_real_names = 0;
}

char *msgto;
char *umsgto;

int
chatlookup(uin)
struct user_info *uin;
{
    static int matchcnt, exact;
    static char fullid[10], userid[15];
    int umatch, cmatch;

    if (!uin) {
	int final = (matchcnt > 1 ? -1 : matchcnt);
	msgto = fullid;
	umsgto = userid;
	matchcnt = exact = 0;
	return final;
    }
    if (uin->mode != uinfo.mode) return 0;
    if (!uin->active || !uin->pid) return 0;
    if (uin->invisible && !HAS_PERM(PERM_SEECLOAK)) return 0;
    cmatch = !ci_strncmp(msgto, uin->chatid, strlen(msgto));
    umatch = !ci_strncmp(msgto, uin->userid, strlen(msgto));
    if (umatch || cmatch) {
	int isexact = (cmatch ? (strlen(msgto) == strlen(uin->chatid)) :
				(strlen(msgto) == strlen(uin->userid)));
	if (matchcnt > 0) {
	    if (exact && isexact) {
		matchcnt = exact = 0;
		return QUIT;
	    } else if (exact && !isexact) return 0;
	    else if (!exact && isexact) matchcnt = 0;
	}
	matchcnt++;
	if (isexact) exact++;
	strcpy(fullid, uin->chatid);
	strcpy(userid, uin->userid);
    }
    return 0;
}

int
domsg(id, fd)
char *id;
int fd;
{
    char *text;
    char buf2[STRLEN], buf[STRLEN];
    int verdict, retval = -1;

    while (*id == ' ' || *id == '\t' || *id == '\n') id++;
    if (*id == '\0') {
	printchatline(txt_chat_users_assign);
	return 0;
    }
    text = advance(id);
    msgto = id;
    if (*text == '\0') {
	printchatline(txt_chat_input_msg);
	return 0;
    }
    if (apply_ulist( chatlookup ) == QUIT)
	verdict = -1;
    else verdict = chatlookup(NULL);
    switch (verdict) {
	case 0: printchatline(txt_chat_no_such_user);
		break;
	case -1: printchatline(txt_chat_nickname_dup );
		break;
	default: sprintf(buf, "/to %s %s %s", umsgto, uinfo.chatid, text);
		 buf[STRLEN-1] = '\0';
     		 retval = x_write(fd, buf, strlen(buf)+1);
		 sprintf(buf2, "%s> %s", msgto, text);
		 printchatline(buf2);
    }
    msgto = NULL;
    if (retval > -1) retval = 0;
    return retval;
}

int
donick(newname, fd)
char *newname;
int fd;
{
    char *p;
    char buf[40];
    int retval;
    while (*newname == ' ' || *newname == '\t' || *newname == '\n')
	newname++;
    if (*newname == '\0') {
	printchatline(txt_chat_nickname_assign );
	return 0;
    }
    for (p = newname; *p && *p!=' ' && *p!='\t' && *p!='\n'; p++);
    *p = '\0';
    if (strlen(newname) > 8) newname[8] = '\0';
    fixchatid(newname);
    if (!uinfo.invisible)
	sprintf(buf, "/nick %s %s", uinfo.chatid, newname);
    else {
	if (HAS_PERM(PERM_SYSOP))
	    sprintf(buf, "/snick %s %s", uinfo.chatid, newname);
	else sprintf(buf, "/inick %s %s", uinfo.chatid, newname);
    }
    retval = x_write(fd, buf, strlen(buf)+1);
    strcpy(uinfo.chatid, newname);
    update_utmp();
    if (retval > -1) retval = 1;  /* cause t_chat to update chatid */
    return retval;
}

void
chathelp( cmd, desc )
char	*cmd, *desc;
{
    char	buf[ STRLEN ];

    sprintf( buf, "  %-14s - %s.", cmd, desc );
    printchatline( buf );
}

int
dochatcommand(cmd, fd)
char *cmd;
int fd;
{
    char *endcmd;
    int retval = 0, cmdlen;
    while (*cmd == ' ') cmd++;
    endcmd = cmd;
    while (*endcmd != ' ' && *endcmd != '\n' && *endcmd) endcmd++;
    if (*endcmd == '\0') *(endcmd+1) = '\0';
    else *endcmd = '\0';
    cmdlen = strlen(cmd);
    if (!ci_strncmp(cmd, "help",cmdlen)) {
	printchatline(txt_chat_special_cmd);
	chathelp( "/help",		txt_chat_help_usage );
	chathelp( "/who",		txt_chat_chatter_list );
	chathelp( "/users",		txt_chat_logon_users_list );
	chathelp( "/long",		txt_chat_logon_users_detail );
      if( HAS_PERM(PERM_SYSOP) )
	chathelp( "/real",		txt_chat_user_realname );
	chathelp( txt_chat_prompt_msg,	txt_chat_deliver_msg );
      if (HAS_PERM(PERM_BASIC))
	chathelp( "/pager",		txt_chat_pager );
	chathelp( txt_chat_prompt_nick, txt_chat_nickname_change );
	chathelp( txt_chat_prompt_act,	txt_chat_do_act );
	chathelp( "/clear",		txt_chat_clrscr );
	chathelp( "/date",		txt_chat_display_date );
      if(HAS_PERM(PERM_CHATCLOAK) && HAS_PERM(PERM_CLOAK))
	chathelp( "/cloak",		txt_chat_switch_cloak );
	chathelp( "ctrl-d",		txt_chat_exit );
    } else if (!ci_strncmp(cmd, "who", cmdlen))
	dowho();
    else if (!ci_strncmp(cmd, "users", cmdlen))
	dousers();
    else if (!ci_strncmp(cmd, "long", cmdlen))
	dolong();
    else if (!ci_strncmp(cmd, "real", cmdlen)) {
	if( HAS_PERM(PERM_SYSOP) )
	    doreal();
	else
	    printchatline(txt_chat_err_cmd) ;
    } else if (!ci_strncmp(cmd, "msg", cmdlen))
	retval = domsg(endcmd+1, fd);
    else if (!ci_strncmp(cmd, "nick", cmdlen))
	retval = donick(endcmd+1, fd);
    else if (!ci_strncmp(cmd, "pager",cmdlen)) {
	t_pager() ;
	if( uinfo.pager )
	    printchatline( txt_chat_pager_on );
	else
	    printchatline( txt_chat_pager_off );
    } else if (!ci_strncmp(cmd, "me", cmdlen)) {
	char actionbuf[80], *firstlet = endcmd + 1;
	while (*firstlet == ' ' || *firstlet == '\n' || *firstlet == '\t')
	    firstlet++;
	if (*firstlet != '\0') {
	    sprintf(actionbuf, "%s %s", uinfo.chatid, endcmd+1);
	    x_write(fd, actionbuf, strlen(actionbuf)+1);
	} else
	    printchatline( txt_chat_input_act );
    } else if (!ci_strncmp(cmd, "clear", cmdlen)) {
	char bufr[80];
	clear();
        move(echatwin,0) ;
	printdash( NULL );
	chatline = 0;
	sprintf(bufr, txt_chat_help_chatroom, BoardName);
	printchatline(bufr);
        printchatline("  ");
    } else if (!ci_strncmp(cmd,"date", cmdlen)) {
	char bufr[80];
	time_t thetime;
	time(&thetime);
	sprintf(bufr, txt_chat_now_date, Ctime(&thetime));
	printchatline(bufr);
    } else if (!ci_strncmp(cmd,"cloak", cmdlen)) {
	if (HAS_PERM(PERM_CHATCLOAK) && HAS_PERM(PERM_CLOAK)) {
	    x_cloak() ;
	    if (uinfo.invisible)
		printchatline(txt_chat_cloak_start);
	    else
		printchatline(txt_chat_cloak_stop) ;
	} else
	    printchatline(txt_chat_err_cmd) ;
    } else
	printchatline(txt_chat_err_cmd);
    return retval;
}

void
ent_chat( cmd )
char	*cmd;
{
    int savecloak = uinfo.invisible;

    if (!HAS_PERM(PERM_CHATCLOAK)) uinfo.invisible = NA;
    chatroom = cmd[0];
    if( chatroom < '0' || chatroom > 'z' )
	chatroom = '0';
    sprintf( genbuf, "Chat-%c", chatroom );
    report( genbuf );
    t_chat();
    if (!HAS_PERM(PERM_CHATCLOAK)) uinfo.invisible = savecloak;
}

