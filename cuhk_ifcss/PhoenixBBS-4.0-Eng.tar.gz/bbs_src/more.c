/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
			Guy Vega, gtvega@seabass.st.usm.edu
			Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"

#define MORE_BUFSIZE	4096

unsigned char	more_databuf[ MORE_BUFSIZE + 1 ];
unsigned char	*more_buf;
int		more_size, more_num;
int		showansi = 0;

/*
char *more_help[] = {
    "\02�\\Ū�峹�\\����ϥλ���",
    "",
    "\01��в��ʥ\\����",
    "�� �� k             �W���@��",
    "�� �� j �� Enter    �U���@��",
    "PgUp �� ^B          �W���@��",
    "PgDn �� ^F          �U���@��", 
    "�� �� �ť���        �U���@��",
    "",
    "\01��L�\\����",
    "�� �� Q             ����",
    "h �� H �� ?         ���U�����e��",
    NULL };

*/

int
readln( fd, buf )
int	fd;
char	*buf;
{
    int		num, len, bytes, in_esc, ch;

    num = more_num;
    len = bytes = in_esc = 0;
    while( 1 ) {
	if( num >= more_size ) {
	    if( fd < 0 )  break;
	    num = read( fd, more_buf, MORE_BUFSIZE );
	    if( num == 0 )  break;
	    more_buf[ num ] = '\0';
	    more_size = num;
	    num = 0;
	}
	ch = more_buf[ num++ ];
	bytes++;
	if( ch == '\n' ) {
	    break;
	} else if( len >= 80 || bytes >= 119 ) {
	    num--;
	    bytes--;
	    break;
	} else if( in_esc ) {
	    if( showansi )  *buf++ = ch;
	    if( isalpha( ch ) )  in_esc = 0;
	} else if( ch >= ' ' ) {
	    *buf++ = ch;
	    len++;
	    while( (ch = more_buf[ num ]) >= ' ' &&
		   len < 80 && bytes < 119 ) {
		num++;
		bytes++;
		*buf++ = ch;
		len++;
	    }
	    in_esc = 0;
	} else if( ch == '\033' ) {
	    if( showansi )  *buf++ = ch;
	    in_esc = 1;
	} else if( ch == '\t' ) {
	    do {
		*buf++ = ' '; len++;
	    } while( (len & 7) != 0 );
	}
    }
    *buf++ = '\n';
    *buf = '\0';
    more_num = num;
    return bytes;
}

int
morekey()
{
    while( 1 ) {
	switch( egetch() ) {
	    case 'q':  case KEY_LEFT:  case EOF:
		return KEY_LEFT;
	    case ' ':  case KEY_RIGHT: 
	    case KEY_PGDN: case Ctrl('F'):
		return KEY_RIGHT;
	    case KEY_PGUP : case Ctrl('B'):
		return KEY_PGUP;
	    case '\r': case KEY_DOWN: case 'j':
		return KEY_DOWN;
	    case 'k' : case KEY_UP:
		return KEY_UP;
	    case 'h': case 'H': case '?':
		return 'H';
	    default:	;
	}
    }
}

int seek_nth_line(fd, no)
int fd, no;
{
    char	buf[ 256 ];
    int		viewed;

    if( fd > 0 ) {
	lseek( fd, 0, SEEK_SET );
	more_size = 0;
    }
    more_num = viewed = 0;
    while( no-- > 0 ) {
	viewed += readln( fd, buf );
    }
    return viewed;
}

int
rawmore(filename,promptend)
char	*filename;
int	promptend;
{
    extern int	t_lines ;
    struct stat st ;
    int		fd, tsize;
    char	buf[ 256 ] ;
    int		i, ch, viewed, pos ;
    int 	numbytes ;
    int		curr_row = 0;

    if( filename[0] == 'b' &&
	(more_buf = (void *)cache_getfile( filename, &more_size )) != NULL ) {
	fd = -1;
	tsize = more_size;
    } else {
	if( (fd = open(filename,O_RDONLY)) == -1 || fstat( fd, &st ) )
	    return -1;
	tsize = st.st_size ;
	more_buf = more_databuf;
	more_size = 0;
    }

    clear() ;
    more_num = viewed = i = pos = 0 ;
    numbytes = readln(fd,buf) ;  curr_row++;
    while( numbytes ) {
	viewed += numbytes ;
	prints( "%s", buf ) ;
	i++ ;
	pos++ ;
	if(pos == t_lines) {
	    scroll() ;
	    pos-- ;
	}
	numbytes = readln(fd,buf) ; curr_row++;
	if( numbytes == 0 )
	    break ;
	if( i == t_lines -1 ) {
	    if( showansi ) {
		move( t_lines-1, 0 ) ;
		prints( "\033[37;40;0m\033[m" );
		refresh();
	    }
	    move( t_lines-1, 0 ) ;
	    standout() ;
	    prints("--More-- (%d%%)", (viewed*100)/tsize) ;
	    standend() ;
	    prints(txt_more_foot);
	    ch = morekey();
	    move( t_lines-1, 0 );
	    clrtoeol();
	    refresh();
	    if( ch == KEY_LEFT ) {
		close( fd );
		return ch;
	    } else if( ch == KEY_RIGHT ) {
		i = 1;
	    } else if( ch == KEY_DOWN ) {
		i = t_lines-2 ;
	    } else if(ch == KEY_PGUP || ch == KEY_UP) {
		clear(); i = pos = 0;
		curr_row -= (ch == KEY_PGUP) ? (2*t_lines - 2) : (t_lines+1);
		if (curr_row < 0) { close( fd ); return ch; }
        	viewed = seek_nth_line(fd, curr_row);        
                numbytes = readln(fd,buf) ;  curr_row++;
	    } else if(ch == 'H') {
		show_helpmenu( more_help );
		i = pos = 0;
		curr_row -= (t_lines);
		if (curr_row < 0) curr_row = 0;
        	viewed = seek_nth_line(fd, curr_row);        
                numbytes = readln(fd,buf) ;  curr_row++;
            }
	}
    }

    close( fd ) ;
    if( promptend ) {
	pressanykey();
    }
    return 0 ;
}

int
more(filename,promptend)
char	*filename ;
int	promptend;
{
    showansi = 0;
    return rawmore( filename, promptend );
}

int
ansimore(filename,promptend)
char	*filename ;
int	promptend;
{
    int ans;

    showansi = 1;
    if( (ans = rawmore( filename, promptend )) != -1 ) {
	move( t_lines-1, 0 );
	prints( "\033[37;40;0m\033[m" );
	refresh();
    }
    showansi = 0;
    return ans;
}

