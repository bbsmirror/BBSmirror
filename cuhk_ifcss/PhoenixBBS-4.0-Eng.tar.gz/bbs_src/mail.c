/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
			Guy Vega, gtvega@seabass.st.usm.edu
			Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"
#define		INTERNET_PRIVATE_EMAIL

char	*sysconf_str();
char	currmaildir[ STRLEN ] ;

char *email_domain()
{
    char	*domain;

    domain = sysconf_str( "BBSDOMAIN" );
    if( domain == NULL )  domain = "unknown.BBSDOMAIN";
    return domain;
}

char *get_bbs_english_name()
{
    char	*name;

    name = sysconf_str( "BBSID" );
    if( name == NULL )  name = "unknown.BBSID";
    return name;
}

int
chkmail()
{
    static long lasttime = 0;
    static ismail = 0 ;
    struct fileheader fh ;
    struct stat st ;
    int fd ;
    register int i, offset ;
    register long numfiles ;
    unsigned char ch ;
    extern char currmaildir[ STRLEN ] ;

    if( !HAS_PERM( PERM_BASIC ) ) {
	return 0;
    }
    offset = (int)((char *)&(fh.accessed[0]) - (char *)&(fh)) ;
    if((fd = open(currmaildir,O_RDONLY)) < 0)
      return (ismail = 0) ;
    fstat(fd,&st) ;
    if(lasttime >= st.st_mtime) {
        close(fd) ;
        return ismail ;
    }
    lasttime = st.st_mtime ;
    numfiles = st.st_size ;
    numfiles = numfiles/sizeof(fh) ;
    if(numfiles <= 0) {
      close(fd) ;
      return (ismail = 0) ;
    }
    lseek(fd,offset,SEEK_SET) ;
    for(i = 0 ; i < numfiles ; i++,lseek(fd,offset+i*sizeof(fh),SEEK_SET)) {
        read(fd,&ch,1) ;
        if(!(ch & FILE_READ)) {
            close(fd) ;
            return(ismail = 1) ;
        }
    }
    close(fd) ;
    return(ismail = 0) ;
}

void
m_internet()
{
    char receiver[ STRLEN ], title[ STRLEN ] ;

    getdata(1, 0, txt_mail_receiver, receiver, STRLEN, DOECHO, NULL) ;
    getdata(2, 0, txt_mail_subject, title, STRLEN, DOECHO, NULL ); 
    if ( strchr(receiver, '@') && strlen( title ) > 0 ) {
        do_send( receiver, title, NULL, NULL );
    } else {
        move(3, 0);
        prints(txt_mail_sub_rec_err);
        pressreturn();
    }
    clear();
    refresh();
}

void
m_init()
{
	sprintf(currmaildir,"mail/%s/%s",currentuser.userid, DOT_DIR) ;
}

int
do_send( userid, title, qfile, quser )
char *userid, *title ;
{
    struct stat st ;
    char	filepath[STRLEN], fname[STRLEN], *ip;
    char	poster[STRLEN], buf[ STRLEN ];
    int		res, ch, localmail = NA;

    if( strchr(userid, '@') == NULL ) {
	localmail = YEA;
	if(!getuser(userid))
	    return -1 ;
	if (!(lookupuser.userlevel & PERM_READMAIL))
	    return -3;
    }
    if( title == NULL ) {
	getdata( 2, 0, "Title: ", save_title, STRLEN, DOECHO, NULL );
    } else {
	strncpy( save_title, title, STRLEN );
    }
    sprintf( fname, "tmp/vedit_%d", getpid() );
    do_quote( fname, qfile, quser, 1 );

    in_mail = YEA;
    if (vedit(fname, localmail) == -1) {
	unlink( fname );
	clear();
	return -2;
    }
    clear() ;

    if( localmail ) {
#if defined(MAIL_REALNAMES)
	sprintf(genbuf,"%s (%s)",currentuser.userid,currentuser.realname) ;
#else
	sprintf(genbuf,"%s (%s)",currentuser.userid,currentuser.username) ;
#endif
	strncpy( poster, genbuf, STRLEN );
	sprintf( filepath, "mail/%s", userid );
        res = spooling_file( filepath, buf, fname, poster, save_title, 0 );
	if( res == 0 ) {
	    sprintf( genbuf, "%s '%s'", userid, save_title );
	    log_usies( "MAIL ", genbuf );
	}
    } else {
	prints(txt_mail_sending, userid);
	prints(txt_mail_title, save_title );
	prints(txt_mail_sure_send);
	refresh();
	ch = egetch();
	switch ( ch ) {
	    case 'N': case 'n': 
		prints("%c\n", 'N');
		prints(txt_mail_cancel);
		res = -2;
		break;
	    default: 
		prints("%c\n", 'Y');
		prints(txt_mail_processing); refresh();
		res = bbs_sendmail( fname, save_title, userid ); 
		prints(txt_mail_sent);
		sprintf( genbuf, "%s '%s'", userid, save_title );
		log_usies( "MAIL ", genbuf );
		break;
	}
    }

    unlink( fname ); 
    return res;
}

int
m_send()
{
    char uident[STRLEN] ;

    move(2,0) ;
    prints("<Enter Userid>\n") ;
    move(1,0) ;
    clrtoeol() ;
    usercomplete("To: ",uident) ;
    if(uident[0] == '\0') {
	clear() ;
	return 0 ;
    }
    modify_user_mode( SMAIL );
    switch ( do_send( uident, NULL, NULL, NULL ) ) {
	case -1: prints("Bad UserId\n") ; break;
	case -2: prints("Mail Aborted\n"); break;
	case -3: prints("User '%s' cannot receive mail\n", uident); break;
	default: prints("File Sent\n") ;
    }
    pressreturn() ;
    return 0 ;
}

int
read_mail(fptr)
struct fileheader *fptr ;
{
    sprintf(genbuf,"mail/%s/%s",currentuser.userid,fptr->filename) ;
    ansimore(genbuf,NA) ;
    fptr->accessed[0] |= FILE_READ;
    return 0 ;
}

int mrd ;

int delmsgs[1024] ;
int delcnt ;

int
read_new_mail(fptr)
struct fileheader *fptr ;
{
	static int idc ;
	char done = NA, delete_it;
	char fname[256];

	if(fptr == NULL) {
		delcnt = 0 ;
		idc = 0 ;
		return 0;
	}
	idc++ ;
	if(fptr->accessed[0])
	  return 0 ;
	prints("Read message titled '%s' from: %s?\n",fptr->title,fptr->owner) ;
	prints("(Yes, or No): ") ;
	getdata(1,0,"(Yes, or No) [Y]: ",genbuf,4,DOECHO,NULL) ;
	if(genbuf[0] != 'y' && genbuf[0] != 'Y' && genbuf[0] != '\0') {
		clear() ;
		return 0 ;
	}
	read_mail(fptr) ;
	strcpy(fname, genbuf);
	mrd = 1 ;
	if(substitute_record(currmaildir,fptr,sizeof(*fptr),idc))
	  return -1 ;
	delete_it = NA;
    while (!done) {
	move(t_lines-1, 0);
        prints("(R)eply, (D)elete, or (G)o on? [G]: ");
	switch ( egetch() ) {
	    case 'R': case 'r': 
	      mail_reply(idc, fptr, currmaildir);
	      break;
	    case 'D': case 'd': delete_it = YEA;
	    default: done = YEA;
	}
        if (!done) ansimore(fname, NA);  /* re-read */
    }
    if (delete_it) {
        clear() ;
        prints("Delete Message '%s' ",fptr->title) ;
	getdata(1,0,"(Yes, or No) [N]: ",genbuf,STRLEN,DOECHO,NULL) ;
        if(genbuf[0] == 'Y' || genbuf[0] == 'y') { /* if not yes quit */
	  sprintf(genbuf,"mail/%s/%s",currentuser.userid,fptr->filename) ;
	  unlink(genbuf) ;
	  delmsgs[delcnt++] = idc ;
	}
    }
    clear() ;
    return 0 ;
}

int
m_new()
{
    clear() ;
    mrd = 0 ;
    modify_user_mode( RMAIL );
    read_new_mail(NULL) ;
    if(apply_record(currmaildir,read_new_mail,sizeof(struct fileheader)) == -1) {
	clear() ;
	move(0,0) ;
	prints("No new messages\n\n\n") ;
	return -1 ;
    }
    if(delcnt) {
	while(delcnt--)
 	delete_record(currmaildir,sizeof(struct fileheader),delmsgs[delcnt]) ;
    }
    clear() ;
    move(0,0) ;
    if(mrd)
	prints("No more messages.\n\n\n") ;
    else
	prints("No new messages.\n\n\n") ;
    return -1 ;
}

extern char BoardName[];

void
mailtitle()
{
    showtitle( txt_mail_menu, BoardName );
    prints(txt_mail_head);

    prints(" ENT   %-20s %s\n","From","Header") ;
    clrtobot() ;
}

char *
maildoent(num,ent)
int	num;
struct fileheader *ent ;
{
	static char buf[512] ;
	char b2[512] ;
	char status;
	char *t ;

	strncpy(b2,ent->owner,STRLEN) ;
	if( (t = strchr(b2,' ')) != NULL )
	  *t = '\0' ;
	if (ent->accessed[0] & FILE_READ) {
	  if (ent->accessed[0] & FILE_MARKED) status = 'm';
	  else status = ' ';
	}
	else {
	  if (ent->accessed[0] & FILE_MARKED) status = 'M';
	  else status = 'N';
	}
	sprintf(buf," %3d %c %-20.20s %s",num,status,b2,ent->title) ;
	return buf ;
}

#ifdef POSTBUG
extern int bug_possible;
#endif

int
mail_read(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
	char buf[512], notgenbuf[128];
	char *t ;
	char done = NA, delete_it, replied;

	clear() ;
	strcpy(buf,direct) ;
	if( (t = strrchr(buf,'/')) != NULL )
	  *t = '\0' ;
	sprintf(notgenbuf, "%s/%s",buf,fileinfo->filename) ;
	delete_it = replied = NA;
	while (!done) {
	    ansimore(notgenbuf, NA) ;
	    move(t_lines-1, 0);
            prints("(R)eply, (D)elete, or (G)o on? [G]: ");
	    switch (egetch()) {
		case 'R': case 'r': 
		  replied = YEA;
		  mail_reply(ent,fileinfo, direct);
		  break;
		case 'D': case 'd': delete_it = YEA;
	        default: done = YEA;
	    }
	} 
	if (delete_it) mail_del(ent, fileinfo, direct);
	else {
	  fileinfo->accessed[0] |= FILE_READ;
#ifdef POSTBUG
	  if (replied) bug_possible = YEA;
#endif
	  substitute_record(currmaildir, fileinfo, sizeof(*fileinfo),ent) ;
#ifdef POSTBUG
	  bug_possible = NA;
#endif
	}
	return FULLUPDATE ;
}

/*ARGSUSED*/
int
mail_reply(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char	uid[STRLEN], title[STRLEN];
    char	qfile[STRLEN], quser[STRLEN];
    char	*t ;

    modify_user_mode( SMAIL );
    strncpy(uid,fileinfo->owner,STRLEN) ;
    if( (t = strchr(uid,' ')) != NULL )
	*t = '\0' ;
    if (toupper(fileinfo->title[0]) != 'R' || fileinfo->title[1] != 'e' ||
	fileinfo->title[2] != ':') strcpy(title,"Re: ") ;
    else title[0] = '\0';
    strncat(title,fileinfo->title,STRLEN-5) ;

    sprintf( qfile,"mail/%s/%s",currentuser.userid,fileinfo->filename);
    strncpy( quser, fileinfo->owner, STRLEN );
    switch ( do_send( uid, title, qfile, quser )) {
	case -1: prints("Could not send\n"); break;
	case -2: prints("Reply Aborted\n"); break;
	case -3: prints("User '%s' cannot receive mail\n", uid); break;
	default: prints("File Sent\n");
    }
    pressreturn() ;
    return FULLUPDATE ;
}

int
mail_del(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
	struct stat	st;
	char buf[512] ;
	char *t ;
	extern int cmpfilename() ;
	extern char currfile[] ;

	clear() ;
	prints("Delete Message '%s' ",fileinfo->title) ;
	getdata(1,0,"(Yes, or No) [N]: ",genbuf,STRLEN,DOECHO,NULL) ;
	if(genbuf[0] != 'Y' && genbuf[0] != 'y') { /* if not yes quit */
		move(2,0) ;
		prints("Quitting Delete Mail\n") ;
		pressreturn() ;
		clear() ;
		return FULLUPDATE ;
	}		
	strcpy(buf,direct) ;
	if( (t = strrchr(buf,'/')) != NULL )
	  *t = '\0' ;
	strncpy(currfile,fileinfo->filename,STRLEN) ;
	if(delete_file(direct,sizeof(*fileinfo),ent,cmpfilename)) {
		move(2,0) ;
		prints("Delete failed\n") ;
		pressreturn() ;
		clear() ;
		return FULLUPDATE ;
	}
	sprintf(genbuf,"%s/%s",buf,fileinfo->filename) ;
	unlink(genbuf) ;
	if( lstat(direct,&st) == 0 && st.st_size == 0 ) {
		unlink( direct );
		rmdir( buf );
	}
	return DIRCHANGED ;
}

#ifdef INTERNET_EMAIL

int
mail_forward(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
	char buf[STRLEN];
	char *p;
	if (!HAS_PERM(PERM_FORWARD)) {
	    return DONOTHING;
	}
	strncpy(buf, direct, sizeof(buf));
	if ((p = strrchr(buf, '/')) != NULL)
	    *p = '\0';
	clear();
	switch (doforward(buf, fileinfo, 0)) {
	  case 0:  
                   prints(txt_mail_forward_done);
/* comment out by jjyang for direct mail delivery */
		   sprintf(genbuf, "forwarded file to %s", currentuser.email);
		   report(genbuf);
/* comment out by jjyang for direct mail delivery */

		   break;
	  case -1: prints("Forward failed: system error.\n");
		   break;
	  case -2: prints("Forward failed: missing or invalid address.\n");
	}
	pressreturn();
	clear();
	return FULLUPDATE;
}

int
mail_uforward(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
	char buf[STRLEN];
	char *p;
	if (!HAS_PERM(PERM_FORWARD)) {
	    return DONOTHING;
	}
	strncpy(buf, direct, sizeof(buf));
	if ((p = strrchr(buf, '/')) != NULL)
	    *p = '\0';
	clear();
	switch (doforward(buf, fileinfo, 1)) {
	  case 0:  
                   prints(txt_mail_forward_done);
/* comment out by jjyang for direct mail delivery */
		   sprintf(genbuf, "forwarded file to %s", currentuser.email);
		   report(genbuf);
/* comment out by jjyang for direct mail delivery */

		   break;
	  case -1: prints("Forward failed: system error.\n");
		   break;
	  case -2: prints("Forward failed: missing or invalid address.\n");
	}
	pressreturn();
	clear();
	return FULLUPDATE;
}

#endif

int
mail_del_range(ent, fileinfo, direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
    return(del_range(ent, fileinfo, direct));
}

int
mail_mark(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
	if (fileinfo->accessed[0] & FILE_MARKED)
	   fileinfo->accessed[0] &= ~FILE_MARKED;
	else fileinfo->accessed[0] |= FILE_MARKED;
	substitute_record(currmaildir, fileinfo, sizeof(*fileinfo),ent) ;
	return(PARTUPDATE);	
}

extern int mailreadhelp();

struct one_key  mail_comms[] = {
	'd',        mail_del,
	'D',	    mail_del_range,
	'r',        mail_read,
	'R',        mail_reply,
	'm',	    mail_mark,
#ifdef INTERNET_EMAIL
	'F',	    mail_forward,
	'U',	    mail_uforward,
#endif
	'h',        mailreadhelp,
	Ctrl('J'),  mailreadhelp,
	'\0',       NULL
} ;

int
m_read()
{
    in_mail = YEA;
    i_read( RMAIL, currmaildir,mailtitle,maildoent,&mail_comms[0]) ;
    in_mail = NA;
    return 0 ;
}

#ifdef INTERNET_EMAIL

#include <netdb.h>
#include <pwd.h>
#include <time.h>
#define BBSMAILDIR "/usr/spool/mqueue"
extern char BoardName[];

int
invalidaddr(addr)
char *addr;
{
	if (*addr == '\0') return 1;   /* blank */
	while (*addr) {
	    if (!isalnum(*addr) && strchr("[].%!@:;-_", *addr) == NULL)
		return 1;
	    addr++;
	}
	return 0;
}

void
spacestozeros(s)
char *s;
{
	while (*s) {
	    if (*s == ' ') *s = '0';
	    s++;
	}
}

int
getqsuffix(s)
char *s;
{
	struct stat stbuf;
	char qbuf[STRLEN], dbuf[STRLEN];
	char c1 = 'A', c2 = 'A';
	int pos = strlen(BBSMAILDIR) + 3;
	sprintf(dbuf, "%s/dfAA%5d", BBSMAILDIR, getpid());
	sprintf(qbuf, "%s/qfAA%5d", BBSMAILDIR, getpid());
	spacestozeros(dbuf);
	spacestozeros(qbuf);
	while (1) {
	    if (stat(dbuf, &stbuf) && stat(qbuf, &stbuf)) break;
	    if (c2 == 'Z') {
		c2 = 'A';
		if (c1 == 'Z') return -1;
		else c1++;
		dbuf[pos] = c1;
		qbuf[pos] = c1;
	    }
	    else c2++;
	    dbuf[pos+1] = c2;
	    qbuf[pos+1] = c2;	    	    
	}
	strcpy(s, &(qbuf[pos]));
	return 0;
}

void
convert_tz(local, gmt, buf)
int gmt, local;
char *buf;
{
	local -= gmt;
	if (local < -11) local += 24;
	else if (local > 12) local -= 24;
	sprintf(buf, " %4d", abs(local * 100));
	spacestozeros(buf);
	if (local < 0) buf[0] = '-';
	else if (local > 0) buf[0] = '+';
	else buf[0] = '\0';	
}

#if 0
int
createqf(title, qsuffix)
char *title, *qsuffix;
{
	static int configured = 0;
        static char myhostname[STRLEN];
        static char myusername[20];
        char mytime[STRLEN];
        char idtime[STRLEN];
	char qfname[STRLEN];
	char t_offset[6];
	FILE *qfp;
        time_t timenow;
	int savehour;
	struct tm *gtime, *ltime;
        struct hostent *hbuf;
        struct passwd *pbuf;

	if (!configured) {
            /* get host name */
            gethostname(myhostname, STRLEN);
            hbuf = gethostbyname(myhostname);
            if (hbuf) strncpy(myhostname, hbuf->h_name, STRLEN);

            /* get bbs uident */
            pbuf = getpwuid(getuid());
            if (pbuf) strncpy(myusername, pbuf->pw_name, 20);
	    if (hbuf && pbuf) configured = 1;
	    else return -1;
	}

	/* get file name */
	sprintf(qfname, "%s/qf%s", BBSMAILDIR, qsuffix);
	if ((qfp = fopen(qfname, "w")) == NULL) return -1;
	
        /* get time */
        time(&timenow);
	ltime = localtime(&timenow);
#ifdef SYSV
	ascftime(mytime, "%a, %d %b %Y %T ", ltime);
#else
        strftime(mytime, sizeof(mytime), "%a, %d %b %Y %T ", ltime);
#endif
	savehour = ltime->tm_hour;
	gtime = gmtime(&timenow);
        strftime(idtime, sizeof(idtime), "%Y%m%d%y%H%M", gtime); 
	convert_tz(savehour, gtime->tm_hour, t_offset);
	strcat(mytime, t_offset);
        fprintf(qfp, "P1000\nT%lu\nDdf%s\nS%s\nR%s\n", timenow, qsuffix,
                myusername, currentuser.email);
#ifdef ERRORS_TO
	fprintf(qfp, "E%s\n", ERRORS_TO);
#endif
	/* do those headers! */
        fprintf(qfp, "HReceived: by %s (%s)\n\tid %s; %s\n",
                myhostname, VERSION_ID, qsuffix, mytime);
	fprintf(qfp, "HReturn-Path: <%s@%s>\n", myusername, myhostname);
        fprintf(qfp, "HDate: %s\n", mytime);
        fprintf(qfp, "HMessage-Id: <%s.%s@%s>\n", idtime, qsuffix,
                myhostname);
        fprintf(qfp, "HFrom: %s@%s (%s in NCTU CSIE BBS)\n", myusername, myhostname, currentuser.userid);
        fprintf(qfp, "HSubject: %s (fwd)\n", title);
        fprintf(qfp, "HTo: %s\n", currentuser.email);
	fprintf(qfp, "HX-Forwarded-By: %s (%s)\n", currentuser.userid,
#ifdef REALNAME
		currentuser.realname);
#else
		currentuser.username);
#endif
	fprintf(qfp, txt_mail_HX_Disclaimer, BoardName);
	fclose(qfp);
	return 0;
}
#endif

int
bbs_sendmail(fname, title, receiver)
char *fname, *title, *receiver;
{
    static int configured = 0;
    static char myhostname[STRLEN];
    static char myusername[20];
    struct hostent *hbuf;
    struct passwd *pbuf;

    FILE *fin, *fout;

    /*
     *  setup the hostname and username 
     */
    if (!configured) {
            /* get host name */
            gethostname(myhostname, STRLEN);
            hbuf = gethostbyname(myhostname);
            if (hbuf) strncpy(myhostname, hbuf->h_name, STRLEN);

            /* get bbs uident */
            pbuf = getpwuid(getuid());
            if (pbuf) strncpy(myusername, pbuf->pw_name, 20);
            if (hbuf && pbuf) configured = 1;
            else return -1;
    }

    /*
     *  Running the sendmail 
     */
    sprintf( genbuf, "/usr/lib/sendmail -f %s.bbs@%s %s ", 
        currentuser.userid, email_domain(), receiver );
    fout = popen( genbuf, "w" );
    fin  = fopen( fname, "r" );
    if (fin == NULL || fout == NULL) return -1;
    
#ifdef INTERNET_PRIVATE_EMAIL
    fprintf( fout, "Reply-To: %s.bbs@%s\n", currentuser.userid, email_domain());
    fprintf( fout, "From: %s.bbs@%s\n", currentuser.userid, email_domain() ); 
#else
    fprintf( fout, "From: %s@%s (%s)\n", 
        myusername, myhostname, get_bbs_english_name()); 
#endif
    fprintf( fout, "To: %s\n", receiver);
    fprintf( fout, "Subject: %s\n", title);
    fprintf( fout, "X-Forwarded-By: %s (%s)\n", 
        currentuser.userid, 
#ifdef REALNAME
	currentuser.realname);
#else
	currentuser.username);
#endif

    fprintf(fout, txt_mail_X_Disclaimer, BoardName);
    fprintf(fout, "Precedence: junk\n"); 
    fprintf(fout, "\n");

    while (fgets( genbuf, 255, fin ) != NULL ) {
        if (genbuf[0] == '.' && genbuf[ 1 ] == '\n')
            fputs( ". \n", fout );
        else fputs( genbuf, fout );
    }
   
    fprintf(fout, ".\n");
    
    fclose( fin );
    pclose( fout );
    return 0;
}

int
doforward(direct, fh,mode)
char *direct;
struct shortfile *fh;
int mode;
{
    static char	address[ STRLEN ];
    char	fname[STRLEN];
    char	receiver[STRLEN];
    int		return_no;
    char	tmp_buf[200];

    clear();
    if( address[0] == '\0' ) {
	strncpy( address, currentuser.email, STRLEN );
    }
    prints(txt_mail_forward_prompt); 
    prints(txt_mail_forward_default, address );

    getdata(2, 0, "==> ", receiver, STRLEN, DOECHO, NULL);
    if( receiver[0] == '\0' ) {
	sprintf( genbuf, txt_mail_sure_forward, address );
	getdata( 2, 0, genbuf, receiver, STRLEN, DOECHO, NULL );
	if( receiver[0] == 'n' || receiver[0] == 'N' )
	    return 1;
	strncpy( receiver, address, STRLEN );
    } else {
	strncpy( address, receiver, STRLEN );
    }
    if (invalidaddr(receiver)) return -2;

    prints(txt_mail_forward_processing, receiver);
    refresh();

    if ( mode == 0 )
	sprintf(fname, "%s/%s", direct, fh->filename);
    else if ( mode == 1) {
	sprintf(fname, "/tmp/file.uu%05d", getpid() );
	sprintf( tmp_buf, "uuencode %s/%s csie.bbs.%05d > %s",
 			direct, fh->filename, getpid(), fname ); 
	system( tmp_buf );
    }
    return_no = bbs_sendmail(fname, fh->title, receiver);

    if ( mode == 1 ) {
	sprintf( tmp_buf, "/bin/rm -r -f %s", fname );
	system( tmp_buf );
    }
    return ( return_no );	

/*
 *      The section is comment out by jjyang for direct mail delivery
 */
#if 0 
    {
	char	dfname[STRLEN];

	/* create data file */
	if (getqsuffix(qsuffix) == -1) return -1;
	sprintf(fname, "%s/%s", direct, fh->filename);
	sprintf(dfname, "%s/df%s", BBSMAILDIR, qsuffix);
	if (link(fname, dfname) != 0) return -1;
	return(createqf(fh->title, qsuffix));
    }
#endif
}

#endif

