/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
			Guy Vega, gtvega@seabass.st.usm.edu
			Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/file.h>

#define CACHE_SIZE	16384
#define CACHE_PAGESIZE	1024
#define CACHE_KEYSIZE	(48 - 12)
#define HASH_SIZE	8192
#define HASH_MASK	(HASH_SIZE - 1)
#define CACHE_MAXSIZE	(CACHE_PAGESIZE * 4)
/*
#define CACHE_TRACE
*/
struct s_tblentry
{
    char	key[ CACHE_KEYSIZE ];
    int		len, next, refcnt;
};

struct s_cache
{
    struct s_tblentry	entry[ CACHE_SIZE ];
    int			hash_tbl[ HASH_SIZE ];
    char		spool[ CACHE_SIZE ][ CACHE_PAGESIZE ];
} *cache_buf;

char	*sysconf_str();
int	cache_fd;

int
cache_init()
{
    struct stat	st;
    char	*mapfile;
    char	buf[ STRLEN ];

    if( (mapfile = sysconf_str( "CACHEFILE" )) == NULL ) {
	cache_fd = 0;
	cache_buf = NULL;
	return -1;
    }
    if( !cache_fd ) {
	if( (cache_fd = open( mapfile, O_RDWR|O_CREAT, 0600 )) < 0 ) {
	    cache_buf = NULL;
	    return -1;
	}
	if( fstat( cache_fd, &st ) || st.st_size != sizeof(struct s_cache) ) {
	    close( cache_fd );
	    sprintf( buf, "%s.old", mapfile );
	    rename( mapfile, buf );
	    if( (cache_fd = open( mapfile, O_RDWR|O_CREAT, 0600 )) < 0 ) {
		cache_buf = NULL;
		return -1;
	    }
	    ftruncate( cache_fd, sizeof( struct s_cache ) );
	}
	cache_buf = (void *) mmap( NULL, sizeof( struct s_cache ),
			PROT_READ|PROT_WRITE, MAP_SHARED, cache_fd, 0 );
	if( (int)cache_buf == -1 ) {
	    cache_buf = NULL;
	    return -1;
	}
	if( cache_buf->entry[0].next == 0 ) {
	    strcpy( cache_buf->entry[0].key, "FIFO-ptr" );
	    cache_buf->entry[0].next = 1;
	}
    }
    return 0;
}

int
cache_exit()
{
    if( cache_fd ) {
	if( cache_buf ) {
	    munmap( cache_buf, sizeof( struct s_cache ) );
	}
	close( cache_fd );
    }
}

int
cache_hashval( key )
char	*key;
{
    int		val;

    val = *key++;
    while( *key )
	val = val * 613 + *key++;
    return (val & HASH_MASK);
}

int
cache_out( filename, pos )
char	*filename;
int	pos;
{
    struct s_cache	*cbuf;
    struct s_tblentry	*tb;
    int		hash;
    int		*ptr, base;
/*
#ifdef CACHE_TRACE
    char	buf[ 256 ];

    sprintf( buf, "'%s' cache_out from %x", filename, pos );
    report( buf );
#endif
*/
    if( (cbuf = cache_buf) == NULL )
	return -1;
    hash = cache_hashval( filename );
    ptr = &(cbuf->hash_tbl[ hash ]);
    while( (base = *ptr) != 0 ) {
	tb = &(cbuf->entry[ base ]);
	if( base == pos || (pos <= 0 && strcmp( tb->key, filename ) == 0) ) {
	    *ptr = tb->next;
	    tb->key[0] = '\0';
	    tb->len = 0;
	    tb->next = 0;
	    tb->refcnt = 0;
	    return 0;
	}
	ptr = &(tb->next);
    }
    return -1;
}

int
cache_in( cbuf, filename )
struct s_cache	*cbuf;
char	*filename;
{
    struct stat		st;
    struct s_tblentry	*tb;
    char	buf[ 256 ];
    int		fd, hash, base, pages, n;

    hash = cache_hashval( filename );
/* check existing cache */
    base = cbuf->hash_tbl[ hash ];
    while( base != 0 ) {
	tb = &(cbuf->entry[ base ]);
	if( strncmp( tb->key, filename, CACHE_KEYSIZE ) == 0 ) {
	    tb->refcnt++;
#ifdef CACHE_TRACE
	    sprintf( buf, "'%s' cached %x(%d).", filename, base, tb->refcnt );
	    report( buf );
#endif
	    return base;
	}
	base = tb->next;
    }

    if( (fd = open( filename, O_RDONLY, 0 )) < 0 )
	return -1;
    if( fstat( fd, &st ) || st.st_size > CACHE_MAXSIZE || st.st_size <= 0 ) {
	close( fd );
	return -1;
    }

    flock( cache_fd, LOCK_EX );
/* check existing cache */
    base = cbuf->hash_tbl[ hash ];
    while( base != 0 ) {
	tb = &(cbuf->entry[ base ]);
	if( strncmp( tb->key, filename, CACHE_KEYSIZE ) == 0 ) {
	    tb->refcnt++;
#ifdef CACHE_TRACE
	    sprintf( buf, "'%s' cached %x(%d).", filename, base, tb->refcnt );
	    report( buf );
#endif
	    flock( cache_fd, LOCK_UN );
	    close( fd );
	    return base;
	}
	base = tb->next;
    }

    pages = (st.st_size - 1) / CACHE_PAGESIZE + 1;
    base = cbuf->entry[0].next;
    while( base < CACHE_SIZE && cbuf->entry[ base ].refcnt > 0 ) {
	tb = &(cbuf->entry[ base ]);
#ifdef CACHE_TRACE
	sprintf( buf, "'%s' ----- skip %x(%d)", tb->key, base, tb->refcnt );
	report( buf );
#endif
	tb->refcnt = 0;
	base += (tb->len - 1) / CACHE_PAGESIZE + 1;
    }
    if( base + pages > CACHE_SIZE )
	base = 1;

/* un-cache files at page [base, base+pages-1] */
    for( n = base; n < base + pages; n++ ) {
	tb = &(cbuf->entry[ n ]);
	if( tb->key[0] != '\0' ) {
	    cache_out( tb->key, n );
	}
    }

/* cache-in file */
#ifdef CACHE_TRACE
    sprintf( buf, "'%s' cache_in [%x], hash[%x]", filename, base, hash );
    report( buf );
#endif
    tb = &(cbuf->entry[ base ]);
    strncpy( tb->key, filename, CACHE_KEYSIZE );
    tb->len = st.st_size;
    tb->next = cbuf->hash_tbl[ hash ];
    tb->refcnt = 0;
    cbuf->hash_tbl[ hash ] = base;
    read( fd, cbuf->spool[ base ], st.st_size );

    cbuf->entry[0].next = base + pages;
    flock( cache_fd, LOCK_UN );
    close( fd );

    return base;
}

char *
cache_getfile( filename, plen )
char	*filename;
int	*plen;
{
    struct s_cache	*cbuf;
    int		num;

    cbuf = cache_buf;
    if( cbuf != NULL && (num = cache_in( cbuf, filename )) > 0 ) {
	*plen = cbuf->entry[ num ].len;
	return cbuf->spool[ num ];
    }
    *plen = 0;
    return NULL;
}

