/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
			Guy Vega, gtvega@seabass.st.usm.edu
			Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/* rrr - This is separated so I can suck it into the IRC source for use
   there too */

#include "modes.h"

char *
ModeType(mode)
int	mode;
{
    switch(mode) {
	case IDLE:	return "" ;
	case NEW:	return txt_mode_newuser ;
	case LOGIN:	return txt_mode_login;
        case CSIE_ANNOUNCE:	return txt_mode_announce;
        case CSIE_TIN:		return txt_mode_tin;
        case CSIE_GOPHER:	return txt_mode_gopher;
	case MMENU:	return txt_mode_mmenu;
	case ADMIN:	return txt_mode_admin;
	case SELECT:	return txt_mode_select;
	case READBRD:	return txt_mode_board;
	case READNEW:	return txt_mode_new;
	case  READING:	return txt_mode_read;
	case  POSTING:	return txt_mode_post;
	case MAIL:	return txt_mode_mail;
	case  SMAIL:	return txt_mode_smail; 
	case  RMAIL:	return txt_mode_rmail; 
	case TMENU:	return txt_mode_tmenu;
	case  LUSERS:	return txt_mode_lusers;  
	case  FRIEND:	return txt_mode_friend;
	case  MONITOR:	return txt_mode_monitor;
	case  QUERY:	return txt_mode_query;
	case  TALK:	return txt_mode_talk;
	case  PAGE:	return txt_mode_page;
	case  CHAT1:	return txt_mode_chat1;
	case  CHAT2:	return txt_mode_chat2;
	case  CHAT3:	return txt_mode_chat3; 
	case  CHAT4:	return txt_mode_chat4; 
	case  IRCCHAT:	return txt_mode_ircchat;
	case LAUSERS:	return txt_mode_lausers; 
	case XMENU:	return txt_mode_xmenu;
	case  VOTING:	return txt_mode_vote;
        case  BBSNET:	return txt_mode_bbsnet;
	case  EDITWELC:	return txt_mode_editwelc;
	case  EDITSIG:	return txt_mode_editsig;
	case  EDITPLAN:	return txt_mode_editplan;
	case ZAP:	return txt_mode_zap;

	case FOURM:	return txt_mode_4mchat;
	case ULDL:	return txt_mode_uldl;
	default: return "Undefined" ;
    }
}

