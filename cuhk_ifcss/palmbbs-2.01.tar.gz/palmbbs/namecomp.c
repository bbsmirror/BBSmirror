/*
   modified version of Eagles BBS 3.0   name.c + complete.c

   implement the namelist as arrays to improve performance,
   especially when build namelist of all accts.

   by joechen@cc.ntu.edu.tw 
    
   note: every argument 'name' must be no longer than NAMELEN. 

   (reference: ncku csie bbs namecomplete.c, by lindj)
*/

#include "common.h"
#include <malloc.h>
#define DEFAULT_MAXSIZE 100    /* default maximum name list size */

NAMELIST *NameList;
register int NameListNum = 0;
int MaxNameListNum = 0;

void
free_namelist(list)
NAMELIST *list;
{
    if(*list) free(*list);
    NameList = NULL;
}

create_huge_namelist(list, size)    /* additional function for compability */
NAMELIST *list;
int size;
{
  if( !NameList ) exit(0); 	/* free namelist must have been done, */
  free_namelist(*list);		/* or it will eat too many memory. */
  MaxNumListNum = size;
  NameListNum = 0;
  *list = (NAME *) malloc( (size+1) * sizeof(NAME));
  memset(*list, 0, size * sizeof(NAME));
}

void
create_namelist(list)
NAMELIST *list;
{
  if( !NameList ) exit(0); 	/* free namelist must have been done, */
  free_namelist(*list);		/* or it will eat too many memory. */
  MaxNumListNum = DEFAULT_MAXSIZE;
  NameListNum = 0;
  *list = (NAME *) malloc( (MaxNumListNum + 1)* sizeof(NAME));
  memset(*list, 0, size * sizeof(NAME));
}

add_namelist(list, name, name_before)
NAMELIST *list;
char *name;
char *name_before;    /* name_before is not supported here */
{
   register NAMELIST _list = *list;   

   if( NameListNum >= MaxNameListNum ) return S_SYSERR;
   strcpy( _list[NameListNum++], name);
   return 0;
}

remove_namelist(list, name)
NAMELIST *list;
char *name;
{
   register int i=0;
   register NAMELIST _list = *list;

   for(i=0; i < NameListNum; i++)
	if(!strcasecmp(_list[i], name)) break ;
   if(i == NameListNum) return S_NOTFOUND ;
   for(; i<NameListNum-1; i++) strcpy( _list[i], _list[i+1]) ;
   _list[i][0] = '\0';
   NameListNum-- ;
}            

is_in_namelist(list, name)
NAMELIST list;
char *name;
{
   register int i=0;
   register NAMELIST _list = list;

   for(i=0; i<NameListNum; i++)
	if(!strcmp(_list[i], name)) return 1;
   return 0;
}
            
apply_namelist(list, fptr, arg)
NAMELIST list;
int (*fptr)();
void *arg;
{
  register int i=0;
  register NAMELIST _list = list;

  for(i=0; i < NameListNum; i++)
    (*fptr)(i, _list[i], arg);
  return NameListNum;
}

/*ARGSUSED*/
_write_list_element(indx, name, fp)
int indx;
char *name;
FILE *fp;
{
  fprintf(fp, "%s\n", name);
  return S_OK;
}

write_namelist(fname, list)
char *fname;
NAMELIST list;
{
  FILE *fp;
  if (list == NULL) unlink(fname);
  else {
    if ((fp = fopen(fname, "w")) == NULL) {
      return S_SYSERR;
    }
    apply_namelist(list, _write_list_element, fp);
    fclose(fp);
  }
  return S_OK;
}

/*ARGSUSED*/
_read_list_element(indx, rec, list)
int indx;
char *rec;
NAMELIST *list;
{
  rec[NAMELEN] = '\0';
  strip_trailing_space(rec);
  if (!isspace(*rec) && !is_in_namelist(*list, rec)) {
    add_namelist(list, rec, NULL);
  }
  return S_OK;
}

read_namelist(fname, list) 
char *fname;
NAMELIST *list;
{
  create_namelist(list);
  _record_enumerate(fname, 0, _read_list_element, list);
  return S_OK;
}

#define WORDSIZE NAMELEN+1

NumInList(list)
NAMELIST list;
{
  register int i=0;
  register NAMELIST _list = list;

  if(_list == NULL) return 0;
  while(_list[i][0]) i++;
  return i;
}

ListMaxLen(list, lines)
NAMELIST list;
int lines;
{
  register int i=0;
  register NAMELIST _list = list;

  int len, max = 0;
  for (i=0; i<lines; i++) {
    len = strlen(_list[i]);
    if (len > max) max = len;
  }
  return max;
}

chkstr(tag,name)
char *tag, *name;
{
  while(*tag != '\0') {
    if(toupper(*tag++) != toupper(*name++))
      return 0;
  }
  return 1;
}

NAMELIST
GetSubList(tag, list)
register char *tag ;
register NAMELIST list;
{
  register int i=0,j=0;
  register NAMELIST _list = list;
  NAMELIST wlist;
  int num;
  
  num = NumInList(_list); 
  wlist = (NAME *) malloc( (num+1) * sizeof(NAME));
  memset(wlist, 0, sizeof(NAME) * (num+1));
  for(i=0, j=0; i < num; i++) 
    if(chkstr(tag, _list[i]) strcpy(wlist[j++], _list[i]);

  if(!j) {
     free(wlist);
     return NULL; 
  }
  return wlist ;
}

ClearSubList(list)
NAMELIST list;
{
  if(list) free(list);
}

#define NUMLINES (t_lines-5)

namecomplete(list, prompt, data)
NAMELIST list;
char *prompt, *data ;
{
  NAME dummynode;
  char *temp;
  int ch ;
  int count = 0 ;
  int clearbot = 0;
  
  if(scrint) {
    NAMELIST cwlist, morelist ;
    int x,y ;
    int origx, origy;
    
    if(prompt != NULL) {
      prints("%s",prompt) ;
      clrtoeol() ;
    }
    temp = data ;
    
    if (list == NULL) {
      dummynode[0]='\0';
      list = &dummynode;
    }    
    cwlist = GetSubList("", list) ;
    morelist = NULL ;
    getyx(&y,&x) ;
    getyx(&origy, &origx);
    
    while((ch = igetch()) != EOF)
      {
	if(ch == '\n' || ch == '\r') {
	  *temp = '\0' ;
	  prints("\n") ;
	  if(NumInList(cwlist) == 1 && temp != data)
	    strncpy(data,cwlist[0],WORDSIZE) ;
	  ClearSubList(cwlist) ;
	  break ;
	}
	if(ch == ' ') {
	  int col,len ;
	  if(NumInList(cwlist) == 1) {
	    strncpy(data,cwlist[0],WORDSIZE) ;
	    move(origy,origx) ;
	    prints("%s",data) ;
	    count = strlen(data) ;
	    temp = data + count ;
	    getyx(&y,&x) ;
	    continue ;
	  }
	  clearbot = 1 ;
	  col = 0 ;
	  if(!morelist)
	    morelist = cwlist ;
	  len = ListMaxLen(morelist,NUMLINES) ;
	  move(3,0) ;
	  clrtobot() ;
	  standout() ;
	  prints(
		 "----------------------- �X�G�z�ܥثe�ҿ�J�r�����@���� ------------------------") ;
	  standend() ;
	  while(len+col < 80) {
	    int i ;
	    for(i=NUMLINES;(morelist[0][0])&&(i>0);i--,morelist++) {
	      move(4+(NUMLINES - i),col) ;
	      prints("%s",morelist[0]) ;
	    }
	    col += len+2 ;
	    if(!morelist[0][0])
	      break ;
	    len = ListMaxLen(morelist,NUMLINES) ;
	  }
	  if(morelist) {
	    move(23,0) ;
	    standout() ;
	    prints("-- ���� --") ;
	    standend() ;
	  }
	  move(y,x) ;
	  continue ;
	}
	if(ch == '\177' || ch == '\010') {
	  if(temp == data)
	    continue ;
	  temp-- ;
	  count-- ;
	  *temp = '\0' ;
	  ClearSubList(cwlist) ;
	  cwlist = GetSubList(data,list) ;
	  morelist = NULL ;
	  x-- ;
	  move(y,x) ;
	  addch(' ') ;
	  move(y,x) ;
	  continue ;
	}
	if(count < WORDSIZE) {
	  NAMEE *node ;
	  *temp++ = ch ;
	  count++ ;
	  *temp = '\0' ;
	  node = GetSubList(data,cwlist) ;
	  if(node == NULL) {
	    bell() ;
	    temp-- ;
	    *temp = '\0' ;
	    count-- ;
	    continue ;
	  }
	  ClearSubList(cwlist) ;
	  cwlist = node ;
	  morelist = NULL ;
	  move(y,x) ;
	  addch(ch) ;
	  x++ ;
	}
      }
    if(ch == EOF)
      generic_abort() ;
    if (*data) {
      move(origy,origx);
      prints("%s", data);
    }
    prints("\n") ;
    refresh() ;
    if(clearbot) {
      move(3,0) ;
      clrtobot() ;
    }
    return 0 ;
  }
  if(prompt != NULL) {
    printf("%s",prompt) ;
    fflush(stdout) ;
  }
  if(!fgets(data,WORDSIZE,stdin))
    generic_abort() ;
  data[WORDSIZE] = '\0';
  if(temp = strchr(data,'\n'))
    *temp = '\0' ;
  return 0 ;
}
