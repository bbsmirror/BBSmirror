#include "server.h"
#include <time.h>

extern char *optarg;
extern int optind;

extern USERDATA user_params;
extern SERVERDATA server;

#ifndef DETAILED_USERMODE
extern char *ModeToString __P((SHORT));
#else
extern char *ModeToString __P((SHORT, char *));
#endif

usage(prog)
char *prog;
{
  fprintf(stderr, 
	  "Usage: %s [-d bbs-dir]\n", prog);
}

/*ARGSUSED*/
one_line_display(indx, urec, count)
int indx;
USEREC *urec;
int *count;
{
  printf("%-12s    %-20s %-20s   %s\n", urec->userid, 
	 urec->username, urec->fromhost, 
#ifndef DETAILED_USERMODE
         ModeToString(urec->mode));
#else
         ModeToString(urec->mode, urec->add_str));
#endif

  (*count)++;
  return S_OK;
}

mode_display(indx, urec)
int indx;
USEREC urec;
{
  printf("�ثe���A: %s\n\n", ModeToString(urec.mode, urec.add_str));
  return S_OK;
}

_query_if_logged_in(indx, urec, loggedin)
int indx;
USEREC *urec;
int *loggedin;
{
  (*loggedin)++;
  return ENUM_QUIT;
}


main(argc, argv)
int argc;
char *argv[];
{
    char *bbshome = NULL;
    int c, count = 0;
    ACCOUNT acct;
    int in_now;

    dont_allow_ansi();
    while ((c = getopt(argc, argv, "d:?")) != -1)
      {
	switch (c)
	  {
	  case 'd':
	    bbshome = optarg;
	    break;
	  case '?':
	    usage(argv[0]);
	    return 2;
	  }
      }

    if (home_bbs(bbshome) == -1) {
        fprintf(stderr, "%s: Cannot chdir to %s\n", argv[0], bbshome);
        return 1;
    }

    if (local_bbs_initialize() != S_OK) {
        fprintf(stderr, "%s: local_bbs_initialize failed\n", argv[0]);
	return 1;
    }

    /* Identify ourself for the log file, just in case */
    strcpy(user_params.u.userid, "[bbfinger]");
    /* assume lowest possible priviliges */    
    user_params.perms = 0;

    /* Do it! */
    if (argv[1]) {
      if (local_bbs_query(argv[1], &acct) != S_OK) {
        printf("\n�䤣�� %s �o�ӤH�@.\n\n", argv[1]);
        return 0;
      }
      local_bbs_enum_users(20, acct.userid, _query_if_logged_in, &in_now);
      printf("\n%s (%s), �w�W�u %s ��, �o���L %s �g�峹.\n", acct.userid, acct.username, acct.numlogins, acct.numposts);
      if (acct.lastlogin == 0)
      printf("Never logged in.\n");
      else printf("%s�Ӧ� %s %s %s", in_now ? "�ثe���b�u�W: " : "�W���W�u",
             acct.fromhost, in_now ? "�W�u�ɶ�" : "�ɶ���",
             ctime((time_t *)&acct.lastlogin));
      if (in_now) {
        local_bbs_enum_users(20, acct.userid, mode_display, NULL);
      }
      else printf("\n");
    }
    else {
      printf("[%s]\n\n", server.name);
      printf("%-12s    %-20s %-20s   %s\n",
           "User Id", "User Name", "From", "Mode");
      local_bbs_enum_users(50, NULL, one_line_display, &count);
      printf("\n�ثe�@�� %d ��ϥΪ̦b�u�W\n\n", count);
    }


    local_bbs_disconnect();

    return 0;
}    

