
/*
Eagles Bulletin Board System
Copyright (C) 1994, Ray Rocker, rrrocker@rock.b11.ingr.com
                                rock@seabass.st.usm.edu
                                72673.2105@compuserve.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "client.h"
#include <sys/types.h>

/* Flags for Read New */
#define NEW_READ	001
#define NEW_PASS	002
#define NEW_SKIP	004
#define NEW_VISIT       010
#define NEW_QUIT	020

/* Are we reading mail or posts? */
#define FILE_TYPE_MAIL	1
#define FILE_TYPE_POST	2

extern int OpenMailbox(), CloseMailbox(), MailDisplay();
extern int CloseMailbox(), CloseBoard(), PostDisplay();
extern char *Ctime();

int read_same_thread;

struct readnewstruct {
  int nummsgs;
  int numread;
  int openflags;
  int dispflags;
  int excode;
  char *thread;
};

ReadNewMessage(type, hptr, numleft, options, openflags)
int type;
HEADER *hptr;
int numleft;
int options;
int openflags;
{
  char promptstr[80];
/*  char ans[10]; */
  int ans;
  clear();
  if (numleft > 0) {
    if (type == FILE_TYPE_MAIL)
      prints("[�z�٦� %d �ʷs�H�|���\\Ū]\n", numleft);
    else 
      prints("[�b '%s' �Q�װϱz�٦� %d �g�峹�S���\\Ū�L]\n", 
	     currboard, numleft);
  }
  prints("�{�b�o�@%s�O %s �b %s �ҵo\n", 
	 (type == FILE_TYPE_MAIL ? "�ʫH��" : "�g�峹"),
	 hptr->owner, Ctime((time_t *)&hptr->mtime));
  prints("���D: %s\n", hptr->title);
  
  strcpy(promptstr, "[m(R)�\\Ū, (P)���L���g, ");
  if (BITISSET(options, NEW_SKIP)) strcat(promptstr, "(S)���L����, ");
  if (BITISSET(options, NEW_VISIT)) strcat(promptstr, "(V)�N���Ϥ峹���Хܬ��wŪ, ");
  strcat(promptstr, "(Q)���}? [R]: ");
  if (!read_same_thread) {
    prints("%s", promptstr);
    ans = igetch();
  }
  
  if (ans == 'Q' || ans == 'q' || ans == KEY_LEFT)
    return NEW_QUIT;
  if (ans == 'P' || ans == 'p')
    return NEW_PASS;
  if (BITISSET(options, NEW_SKIP) && (ans == 'S' || ans == 's'))
    return NEW_SKIP;
  if (BITISSET(options, NEW_VISIT) && (ans == 'V' || ans == 'v'))
    return NEW_VISIT;
  
  if (type == FILE_TYPE_MAIL) MailDisplay(hptr, 0, 0, openflags);
  else if (type == FILE_TYPE_POST) {
    if (PostDisplay(hptr, 0, 0, openflags)==FULLUPDATE && read_same_thread)
      return NEW_QUIT;
  }
  return NEW_READ;
}

NewMailReadfn(indx, hdr, info)
int indx;
HEADER *hdr;
struct readnewstruct *info;
{
  info->excode = ReadNewMessage(FILE_TYPE_MAIL, hdr, info->nummsgs,
                                  0,info->openflags);
  if (info->nummsgs > 0) info->nummsgs--;
  if (info->excode == NEW_QUIT) return ENUM_QUIT;
  return S_OK;
}  

ReadNewMail()
{
  struct readnewstruct rns;
  int servresp;
  clear();
  bbs_set_mode(M_MAIL);
  rns.nummsgs = OpenMailbox(&rns.openflags, 1, &servresp);
  if (servresp != S_OK) {
    prints("Error opening mailbox!\n");
    pressreturn();
  }
  else if (rns.nummsgs == 0) {
    prints("�z�{�b�èS����Ū�L���s�H��.\n");
    pressreturn();
    CloseMailbox();
  }
  else {
    bbs_enum_headers(10, 0, 1, NewMailReadfn, &rns);
    CloseMailbox();
  }
  bbs_set_mode(M_UNDEFINED);
  return FULLUPDATE;
}

IsSameThread(title1, title2)
char *title1;
char *title2;
{
  /* Function to see if two posts are in the same thread */
  if (!strncasecmp(title1, "Re: ", 4)) title1 += 4;
  if (!strncasecmp(title2, "Re: ", 4)) title2 += 4;
  return (!strcasecmp(title1, title2));
}    

NewPostReadfn(indx, hdr, info)
int indx;
HEADER *hdr;
struct readnewstruct *info;
{
  if (info->thread != NULL && !IsSameThread(info->thread, hdr->title)) {
    info->excode = NEW_PASS;      
  }
  else {
    info->excode = ReadNewMessage(FILE_TYPE_POST, hdr, info->nummsgs,
                                info->dispflags, info->openflags);
    if (info->nummsgs > 0) info->nummsgs--;
  }

  if (info->excode == NEW_READ) (info->numread)++;
  if (info->excode == NEW_QUIT || info->excode == NEW_VISIT ||
      info->excode == NEW_SKIP) return ENUM_QUIT;

  return S_OK;
}  

/*ARGSUSED*/
SequentialRead(hptr, currmsg, numrecs, openflags)
HEADER *hptr;
int currmsg, numrecs, openflags;
{
  char ans[7];
  TITLE threadtitle;
  struct readnewstruct rns;
  rns.nummsgs = -1;
  rns.numread = 0;
  rns.openflags = openflags;
  rns.dispflags = NEW_VISIT;
  clear();
  if (getdata(0, 0, "�̧Ǿ\\Ū (N)��Ū���s�峹 �� (F)�P�ثe�P���D���峹? [F]: ",
          ans, sizeof ans, DOECHO, 1) == -1) return FULLUPDATE;
    
  if (*ans == 'N' || *ans == 'n') 
    rns.thread = NULL;
  else {
    strncpy(threadtitle, hptr->title, sizeof threadtitle);
    rns.thread = threadtitle;
    read_same_thread=1;
  }

  if (currmsg) currmsg--;
  bbs_enum_headers(10, currmsg, rns.thread==NULL?1:0, NewPostReadfn, &rns);
  if (rns.excode == NEW_VISIT) {
    rns.numread++;  /* to force FETCHNEW */
    bbs_visit_board(currboard);
  }
  if (read_same_thread) read_same_thread=0;
  return (rns.numread ? (FULLUPDATE | FETCHNEW) : FULLUPDATE);
}

/*ARGSUSED*/
ReadNewPosts(indx, board, disp)
int indx;
BOARD *board;
int *disp;
{
  int openflags, newmsgs;
  struct readnewstruct rns;
  char msgbuf[80];
/*  char ans[4]; */
  int ans;

#ifdef DETAILED_USERMODE
  bbs_set_mode(READNEW);
#endif

  clear();
  sprintf(msgbuf, "�{�b���b�ˬd %s �Q�װ�...\n", board->name);
  move(t_lines/2, t_columns/2-16);
  prints(msgbuf);
  refresh();
  strncpy(currboard, board->name, sizeof currboard);
  newmsgs = OpenBoard(&openflags, 1, NULL);
  if (newmsgs > 0) {
    rns.nummsgs = newmsgs;
    rns.numread = 0;
    rns.openflags = openflags;
    rns.dispflags = NEW_SKIP | NEW_VISIT;
    rns.thread = NULL;
    bbs_enum_headers(10, 0, 1, NewPostReadfn, &rns);
     *disp = rns.excode;
    if (*disp == NEW_VISIT) {
      bbs_visit_board(currboard);
    }
    if ((rns.excode != NEW_VISIT && rns.excode != NEW_SKIP && 
        rns.excode != NEW_QUIT) && (openflags & OPEN_POST)) {
      sprintf(msgbuf, "�{�b�b '%s'�Q�װϪ��峹��Ū���F. �z�Q�o���峹�� (Y/N)? [N]: ", board->name);
/*      getdata(t_lines-1, 0, msgbuf, ans, sizeof ans, DOECHO, 0);  */
      move(t_lines-1,0);
      prints("%s", msgbuf);
      ans=igetch();
      if (ans == 'Y' || ans == 'y') {
	GenericPost(0);
      }
    }
  }   
  CloseBoard();
  return (*disp == NEW_QUIT ? ENUM_QUIT : S_OK);
}

ReadNew()
{
  NAME savecurr;
  int disp = NEW_READ;
  
  bbs_set_mode(M_READING);  

  /* Save the currboard, 'cuz we're gonna meddle with it */
  strcpy(savecurr, currboard);
  
  /* Now read the unzapped boards in sequence */
  bbs_enum_boards(10, BE_UNZAPPED, ReadNewPosts, &disp);

  clear();
  if (disp == NEW_QUIT) prints("���}���\\Ū�Ҧ�.\n");
  else prints("�z�w�g�N�Ҧ���Ū�L���峹���\\Ū���F.\n");

  /* restore currbrd */
  strcpy(currboard, savecurr);
  bbs_set_mode(M_UNDEFINED);
  pressreturn();
  return FULLUPDATE;
}	            
