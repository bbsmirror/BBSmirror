
/*
Eagles Bulletin Board System
Copyright (C) 1994, Ray Rocker, rrrocker@rock.b11.ingr.com
                                rock@seabass.st.usm.edu
                                72673.2105@compuserve.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "server.h"
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include <unistd.h>

extern char *optarg;
extern int optind;

extern USERDATA user_params;

match_expirerule(inactive, logins)
time_t inactive;
int logins;
{    int days = inactive / 86400;
     if(logins <= 3 && days >=15) return 1;
     if(logins <= 10 && days >=20) return 1;
     else if(logins <=100 && days >=30) return 1;
     else if(days >=50) return 1; 
     else return 0;
}

struct userclean {
  time_t cutoff;
  time_t age;
  int inactives;
  int nologins;
  int really;
};

do_delete(acct, really)
ACCOUNT *acct;
int really;
{
  int rc;
  if (really) {
    rc = local_bbs_delete_account(acct->userid);
    if (rc == S_OK) 
      printf("DELETED %s logins=%d, posts=%d, last login=%s\n", 
	acct->userid, atoi(acct->numlogins), atoi(acct->numposts), 
	Ctime(&acct->lastlogin));
    else printf("ERROR %d deleting %s\n", rc, acct->userid);
  }
  else printf("would have DELETED %s logins=%d, posts=%d, last login=%s\n", 
	acct->userid, atoi(acct->numlogins), atoi(acct->numposts), 
	Ctime(&acct->lastlogin));
}

user_clean_func(indx, userid, info)
int indx;
char *userid;
struct userclean *info;
{
  ACCOUNT acct;
  time_t lastlog;
  
  if (local_bbs_get_userinfo(userid, &acct) != S_OK) return 0;

  if (acct.flags & FLG_EXEMPT) {
      return 0;
  }
  if (acct.perms & PERM_SYSOP) {
      return 0;
  }

  if (acct.lastlogin == 0) {
    /* Never logged in, so go by creation time of home directory */
    /* I wish I was saving creation time somewhere besides the log */
    PATH buf;
    struct stat stbuf;
    get_home_directory(acct.userid, buf);
    if (stat(buf, &stbuf) == 0) acct.lastlogin = (LONG)stbuf.st_mtime;
    else return 0;  /* directory lost, maybe a filesystem error */
  }

  if(match_expirerule(info->cutoff - acct.lastlogin, atoi(acct.numlogins)))
    do_delete(&acct, info->really);

  return 0;
}

main(argc, argv)
int argc;
char *argv[];
{
    struct userclean info;
    char *homedir = NULL;
    NAMELIST names;
    int c, cflg = 0;
    int fromshell;

    info.age = 30;          /* 30 days default */
    fromshell = (isatty(0) || isatty(1));
    if(fromshell) info.really = 0;
    else info.really=1;
    info.inactives = 0;

    /* I should copy the passfile somewhere for safety */
 
    if(fromshell) {
          printf("To prevent from accidents, if this program were run\n");
          printf("manually from shell, it just prints out inactive users\n");
          printf("for test & debug.\n");
    }
 

    if (home_bbs(homedir) == -1) {
      fprintf(stderr, "%s: Cannot chdir to %s\n", argv[0], homedir);
      return -1;
    }

    if (local_bbs_initialize() != S_OK) {
        fprintf(stderr, "%s: local_bbs_initialize failed\n", argv[0]);
	return 1;
    }

    /* Identify ourself for the log file */
    strcpy(user_params.u.userid, "[userclean]");
    user_params.perms = ~0;

    /* Delete all inactive accounts */
    names = NULL;
    info.inactives++;
    local_bbs_acctnames(&names);

    time(&info.cutoff);
    info.age *= 86400;   /* convert to seconds */

    apply_namelist(names, user_clean_func, &info);
    
    free_namelist(&names);
    local_bbs_disconnect();
    return 0;
}

