#include <sys/mman.h>
#include <utime.h>
typedef struct _CFNODE {   /* cached file node */
  SHORT fileid;
  SHORT flags;
  LONG size;
  time_t mtime;
} CFNODE;

typedef struct _CFNODE *CFLIST;  /* implemented as array */
#define BCACHE_DIR ".bcache"

#define MMAP_READ   1
#define MMAP_WRITE  0 
#define WAIT_LOCK 15    /* wait lock for most 15 seconds */
READINFO *newrdinfo;
int extern_util=0;

cflist_to_filelist(clist, list, count)
CFLIST clist;
FILELIST *list;
int count;
{
    register FILENODE *node, *prev;
    register int i;
     

    if(count<=0) return ;
    if(count > BBS_MAX_FILES) count = BBS_MAX_FILES;

    free_filelist(list);

    for(i=0; i<count; i++) {
	node = (FILENODE *) malloc(sizeof(*node));	    
	memcpy(node, &(clist[i]), sizeof(CFNODE)); 
	node->next = NULL;

	if( *list == NULL) *list = node;
	else prev->next = node;

	if( newrdinfo ) {
  	    _currbrd.oi.totalmsgs++;	 /* hardcode the _msg_tally */ 
  	    if ( node->mtime < (time_t)_currbrd.ri.stamp && 
      	    	(_currbrd.ri.bits[node->fileid-1] == '1')) {
    	    	newrdinfo->bits[node->fileid-1]='1';
    	    	node->flags &= ~FILE_UNREAD;
  		}
  	    else {
		node->flags |= FILE_UNREAD;
		_currbrd.oi.newmsgs++;
	    }
	}

	prev = node;
    }
}

filelist_to_cflist(list, clist)
FILELIST *list;
CFLIST clist;
{
    int count = 0;
    FILENODE *curr;

    curr = *list;

    for(; curr!=NULL; curr=curr->next) {
	memcpy(&(clist[count]), curr, sizeof(CFNODE));
	count++;
    }
    return count;
} 

get_cachefile(bname, buf)
char *bname, *buf;
{   struct stat stbuf;
    if(stat(BCACHE_DIR, &stbuf)==-1) mkdir(BCACHE_DIR, 0755);
    sprintf(buf, "%s/%s", BCACHE_DIR, bname);
    if(stat(buf, &stbuf)==-1) return S_NOTFOUND;
    else return S_OK;
}

get_cachefile_size(cachename)
char *cachename;
{   
    struct stat stbuf;
    if(stat(cachename, &stbuf)==-1) return 0;
    else return stbuf.st_size / sizeof(CFNODE);
}

update_bcache(cachename, list)
char *cachename;
FILELIST *list;
{   
    char *cache;
    int fd, count, size;
    CFNODE tmpclist[BBS_MAX_FILES];
    
    count = filelist_to_cflist(list, tmpclist);
    size = count * sizeof(CFNODE);

    fd = open(cachename, O_RDWR | O_CREAT | O_TRUNC, 0600);
    if(fd<0) {
	local_logout();
	exit(-1);
    }

#if MMAP_WRITE
    lseek(fd, size-1, SEEK_SET);
    cache = (char *) mmap(NULL,  size , PROT_READ | PROT_WRITE, 
			MAP_FILE | MAP_SHARED, fd, 0);
    if(cache == (void *)-1) {
	perror("mmap");
	sleep(3);
	bbslog(0, "mmap error %s reading %s\n", my_userid(), cachename);
	local_logout();
	exit(-1);
    }
    memcpy(cache, tmpclist, size);
    munmap(cache, size);
#else
    write(fd, tmpclist, size);
#endif
    close(fd);
}

read_bcache(cachename, list)
char *cachename;
FILELIST *list;
{
    char *cache;
    int fd, count, size;
    CFNODE tmpclist[BBS_MAX_FILES];

    count = get_cachefile_size(cachename); 
    size = count * sizeof(CFNODE);
    if(count == 0) return -1;

    fd = open(cachename, O_RDONLY);
    if(fd<0) { 
	local_logout();
	exit(-1);
    }

#if MMAP_READ
    cache = (char *) mmap(NULL,  size , PROT_READ, MAP_PRIVATE, fd, 0);
    if(cache == (void *)-1) {
	perror("mmap");
	sleep(3);
	bbslog(0, "mmap error %s reading %s\n", my_userid(), cachename);
	local_logout();
	exit(-1);
    }
    memcpy(tmpclist, cache, size);
    munmap(cache, size);
#else
    read(fd, tmpclist, size);
#endif

    cflist_to_filelist(tmpclist, list, count); 
    close(fd);
}

lock_bcache(cachename)
char *cachename;
{
   PATH cache_lock;
   PATH tmp_lock;
   FILE *fp;
   int i, diff;

   struct stat stbuf;
   sprintf(cache_lock, "%s.lock", cachename);
   sprintf(tmp_lock, "%s.lock%d", cachename, getpid());
   fp = (FILE *)fopen(tmp_lock, "w");
   if(fp) fclose(fp);				/* toche tmp lock file */
   if(stat(cache_lock, &stbuf)==-1) {
	rename(tmp_lock, cache_lock);
	return S_OK;
   }
   else if( (diff = time(NULL) - stbuf.st_mtime) > WAIT_LOCK ) {
	rename(tmp_lock, cache_lock);		/* lock too old */
	return S_EXISTS;
   }
   
   while(1) {
	sleep(1);
	if(stat(cache_lock, &stbuf)==-1) {
	    rename(tmp_lock, cache_lock);	/* lock dissapeared */
	    return S_OK;
	}
        if(time(NULL) - stbuf.st_mtime >= diff) {
	    diff=time(NULL)-stbuf.st_mtime;
            if(diff > WAIT_LOCK) {               /* lock too long */
	        rename(tmp_lock, cache_lock);
	        return S_EXISTS;
            }
	}
	else diff = time(NULL) - stbuf.st_mtime;
   }
}

unlock_bcache(cachename)
char *cachename;
{
   PATH cache_lock;
   sprintf(cache_lock, "%s.lock", cachename);
   unlink(cache_lock);
}
   

cached_build_filelist(bname, arg)
char *bname;
void *arg;
{
    PATH bcache;
    FILELIST *list;
    struct stat stcache, stdir;
    
    list = &_currbrd.bcache;
    if(get_cachefile(bname, bcache)==S_NOTFOUND) {
        lock_bcache(bcache);
	build_filelist(_currbrd.bdir, &_currbrd.bcache, _msg_tally, arg);
	update_bcache(bcache, list);
	unlock_bcache(bcache);
    }
    else {
	stat(bcache, &stcache);
	stat(_currbrd.bdir, &stdir);
	if(stdir.st_mtime > stcache.st_mtime || stcache.st_size == 0) {
            lock_bcache(bcache);
	    build_filelist(_currbrd.bdir, &_currbrd.bcache, _msg_tally, arg);
	    update_bcache(bcache, list);
	    unlock_bcache(bcache);
	}
	else {
	    newrdinfo = arg;
	    read_bcache(bcache, list);
	}
    }
}

delete_filelist(list, node)
FILELIST *list;
FILENODE *node;
{
    FILENODE *curr = *list, *prev = NULL;
    while(curr) { 
	if(curr->fileid == node->fileid) {
	    if(prev == NULL) *list = curr->next;
	    else prev->next = curr->next; 
	    free(curr);
	    break;
	}
	else {
	    prev = curr;
	    curr = curr->next;
	}
    }
}

notify_new_post(bname, incr, fileid, dirmtime)
char *bname;
int incr;	/* 1 means post, -1 means delete, 0 means mark/unmark */
SHORT fileid;
time_t dirmtime;
{
    PATH bcache, filename, bdir;
    FILELIST *list, tmplist = NULL;
    FILENODE *node;
    struct stat stcache, stfile;

    get_board_directory(bname, bdir);
    fileid_to_fname(bdir, fileid, filename);
    list = &_currbrd.bcache;
    node = (FILENODE *) malloc(sizeof(FILENODE));

    newrdinfo = NULL;
    node->fileid = fileid;
    if(incr!=-1) {
	if(stat(filename, &stfile)==-1) return -1;
    	node->flags = FILE_UNREAD;
    	if ((stfile.st_mode & 0770) == MARKED_FILE_MODE) 
		node->flags |= FILE_MARKED;
	else node->flags &= ~FILE_MARKED;
    	node->size = stfile.st_size;
    	node->mtime = stfile.st_mtime;
    	node->next = NULL;
    }

    get_cachefile(bname, bcache);
    memset(&stcache, 0, sizeof(stcache));
    stat(bcache, &stcache);
    if(!extern_util) {
	if((incr && dirmtime>stcache.st_mtime) ||  stcache.st_size == 0) {
	    unlink(bcache);  /* cache out of date, destroy it, rebuild later */
	    return 0;
	}
        else if(stcache.st_mtime > _currbrd.bsync) {
	    read_bcache(bcache, list);
	}
    }
    else {  /* in case of bbspost, emailpost */
        if(dirmtime>stcache.st_mtime ||  stcache.st_size == 0) {
	    lock_bcache(bcache);
	    build_filelist(bdir, &tmplist, NULL, NULL);   /* rebuild */
	    update_bcache(bcache, &tmplist);
	    unlock_bcache(bcache);
            return 0;
        }
	else {
	    read_bcache(bcache, &tmplist);
	    list = &tmplist;
	}
    }
    switch(incr) {
	case 1:
	    insert_filelist(list, node);
	    break;
	case -1:
	    delete_filelist(list, node);
	    free(node);
	    break;
	case 0:
	    utime(bdir, NULL);
	    free(node);
	    break;
    }
    lock_bcache(bcache);
    update_bcache(bcache, list);
    unlock_bcache(bcache);
    if(tmplist) free_filelist(&tmplist);
}
