/*
 * File: scanboard.c
 */
/*
 * NOTE: if the mode of a file is  rw-rw-r-- or rw-r--r--
 *                                      ^^^          ^^^
 * then it is considered visited
 *
 * but if USE_OVERVIEW if defined, it reads the ~bbs/new_article
 *
 * to get unvisited files quickly
 *
 */
/*  original version: 	mfchen@csie.nctu.edu.tw 
 *			for BBS based on Eagles BBS 2.x	
 *
 *  modified version: 	joechen@cc.ntu.edu.tw
 *			for Eagles BBS 3.0
 */
char *ProgramUsage = "\
bbspost (list|visit) bbs_home\n\
        post board_path < uid + title + Article...\n\
	cancel bbs_home board filename\n\
	expire bbs_home board days [max_posts]\n";

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <dirent.h>
#include "server.h"
struct _node {
	PATH fname;
	NAME fbasename;
	time_t mtime;
	mode_t mode;
        SHORT fileid;
  }; 
#define MAXLEN 1023

int visitflag;
char *homepath;
#ifdef CACHED_OPENBOARD
extern int extern_util;
time_t dirmtime;
#endif

usage()
{
    printf( ProgramUsage );
    exit( 0 );
}

int
mtime_cmp(p1,p2)
void *p1,*p2;
{	time_t a,b;
	a=((struct _node *)p1)->mtime;
	b=((struct _node *)p2)->mtime;
	if(a<b) return -1;
	else if(a==b) return 0;
	else return 1;
}

#ifndef USE_OVERVIEW

void 
search_article( brdname )
char	*brdname;
{
  DIR *dp;
  struct dirent *dent;
  PATH fname,dir;
  char *fnamebase;
  struct stat stbuf;
  SHORT fileid;
  HEADER head;
  int i=0,count=0;
  struct _node node[BBS_MAX_FILES];

  sprintf(dir,"%s/boards/%s",homepath,brdname);
  sprintf(fname,"%s/boards/%s/",homepath,brdname);
  fnamebase = fname+strlen(fname);
  if ((dp = opendir(dir)) == NULL) {
	printf("Can't open board %s",brdname);
	return;
  }
  while ((dent = readdir(dp)) != NULL) {
    strcpy(fnamebase, dent->d_name);
    fileid = hex2SHORT(dent->d_name);
    if (fileid > 0 && fileid <= BBS_MAX_FILES && stat(fname, &stbuf) == 0) {
      if (stbuf.st_size == 0) continue;
      else if(stbuf.st_mode & 0007) continue; /* already visited */
      else {
	strcpy(node[count].fname, fname);
	strcpy(node[count].fbasename, fnamebase);
        node[count].mtime = stbuf.st_mtime;
	node[count].mode = stbuf.st_mode;
	node[count].fileid = fileid;
	count++;
      }
    }
  }
  closedir(dp);
  qsort(node, count, sizeof(struct _node), mtime_cmp); /* sort! by mtime */

#ifdef CACHED_HEADERS
  open_headerfile( brdname);
#endif
  for(i=0; i<count; i++)
  {	
	head.mtime = node[i].mtime;
#ifdef CACHED_HEADERS
	cached_read_headers(brdname, node[i].fileid, &head);
#else
	read_headers(node[i].fname, &head);
#endif
        printf( "%s\t%s\t%s\t%s\n", 
		brdname, node[i].fbasename, head.owner, head.title );
	if(visitflag)
		chmod(node[i].fname, node[i].mode | S_IROTH); /* 00004 */
  }
#ifdef CACHED_HEADERS
  close_headerfile();
#endif
  
}

void 
search_boards( visit )
{
    DIR *dp;
    struct dirent *dent;
    PATH boarddir;

    visitflag = visit;
    sprintf(boarddir,"%s/boards",homepath); 
    if((dp=opendir(boarddir))==NULL) {
	printf("Can't open the boards directory!");
	exit(-1);
    }
    printf( "New article listed:\n" );
    while((dent=readdir(dp))!=NULL) 
	if(strcmp(dent->d_name, ".") && strcmp(dent->d_name, ".."))
            search_article( dent->d_name );
}

#else /* USE_OVERVIEW */

void 
search_article()
{
  char ovfile[20], buf[255];
  FILE *fp;
  struct stat stbuf;
  PATH fname, msgfile;
  NAME brdname, owner;
  char *fbasename, *title;
  time_t mtime=0;

  printf("New article listed:\n");
  if(visitflag) {
	strcpy(ovfile, "new_article.tmp");
	rename("new_article", ovfile);
  }
  else strcpy(ovfile, "new_article");
  fp = (FILE *)fopen(ovfile, "r");
  if(!fp) return;

  while(fgets(buf, 255, fp)) {
     sscanf(buf, "%s %s %s %d", 
		brdname, msgfile, owner, &mtime); 
     sprintf(fname,"%s/%s",homepath, msgfile);

     if(stat(fname, &stbuf)==-1) continue;
     else if(stbuf.st_mode & 0007 == 0004) continue;  /* already visited */
     else if(mtime && stbuf.st_mtime != mtime) continue;

     title = strchr(buf, ' ');
     title = strchr(++title, ' ');
     title = strchr(++title, ' ');
     title = strchr(++title, ' ');
     title++;
     strip_trailing_space(title); 
     fbasename = strrchr(msgfile, '/'); fbasename++;

     printf( "%s\t%s\t%s\t%s\n", 
	brdname, fbasename, owner, title );
     if(visitflag)
	chmod(fname, stbuf.st_mode | S_IROTH); /* 00004 */
  }
  fclose(fp);
  if(visitflag) unlink(ovfile);
}

void 
search_boards( visit )
{
    visitflag = visit;
    search_article();
}

#endif /* USE_OVERVIEW */

post_article( usermail )
{
    PATH  msgdir,msgfile;
    READINFO readinfo;
    SHORT fileid;
    char buf[MAXLEN];
    struct stat stbuf;
    int fh;


  strcpy(msgdir, homepath);
  if (stat(msgdir, &stbuf) == -1 || !S_ISDIR(stbuf.st_mode)) {
    /* A directory is missing! */
    printf(":Err: Unable to post in %s.\n", msgdir);
    return;
  }
  get_filelist_ids(msgdir, &readinfo);


  gets( buf );  /* userid */ 
  gets( buf );  /* subject */
		/* the userid & subject are not neccesary */

  for (fileid = 1; fileid <= BBS_MAX_FILES; fileid++) {
    if (test_readbit(&readinfo, fileid)) continue;
    fileid_to_fname(msgdir, fileid, msgfile);
    printf("post to %s\n",msgfile);
    fh = open( msgfile, O_CREAT | O_EXCL | O_WRONLY, 0664 );
    while( fgets( buf, MAXLEN, stdin ) != NULL ) {
	write( fh, buf, strlen( buf ) );
    }
    close( fh );
    break;
 }
#ifdef CACHED_OPENBOARD
  {  char *bname;
     bname = strrchr(msgdir, '/');
     if(bname) notify_new_post(++bname, 1, fileid, stbuf.st_mtime);
   }
#endif
  return 0;

}

cancel_article( board, file )
char	*board, *file;
{
	PATH fname;
#ifdef  CACHED_OPENBOARD
        PATH bdir;
	struct stat stbuf;

	sprintf(bdir, "%s/boards/%s", homepath, board);
	stat(bdir, &stbuf);
#endif
	sprintf(fname,"%s/boards/%s/%s",homepath,board,file);
	unlink(fname); 
	/* kill it now! the function is far small then original..  :) */
	/* because it won't make system load heavy like before */ 
#ifdef CACHED_OPENBOARD
	notify_new_post(board, -1, hex2SHORT(file), stbuf.st_mtime);
#endif 
}

expire_article( brdname, days_str, max_str )
char	*brdname, *days_str, *max_str;
{
    int days, maxpost, total, keep, i=0, count=0;
    time_t duetime;
    DIR *dp;
    struct dirent *dent;
    PATH fname,dir;
    char *fnamebase;
    struct stat stbuf;
    SHORT fileid;
    struct _node node[BBS_MAX_FILES];

    days = atoi( days_str );
    if( days < 1 ) {
        printf( ":Err: expire time must more than 1 day.\n" );
        return;
    }
    maxpost = (max_str == NULL) ? 9999 : atoi( max_str );
    if( maxpost < 100 ) {
        printf( ":Err: maxmum posts number must more than 100.\n" );
        return;
    }
    duetime = time(NULL) - days*24*60*60;

  sprintf(dir,"%s/boards/%s",homepath,brdname);
  sprintf(fname,"%s/boards/%s/",homepath,brdname);
  fnamebase = fname+strlen(fname);
  if ((dp = opendir(dir)) == NULL) {
	printf("Can't open board %s",brdname);
	return;
  }
  while ((dent = readdir(dp)) != NULL) {
    strcpy(fnamebase, dent->d_name);
    fileid = hex2SHORT(dent->d_name);
    if (fileid > 0 && fileid <= BBS_MAX_FILES && stat(fname, &stbuf) == 0) {
      if (stbuf.st_size == 0) continue;
      else {
	strcpy(node[count].fname, fname);
	strcpy(node[count].fbasename, fnamebase);
        node[count].mtime = stbuf.st_mtime;
	node[count].mode = stbuf.st_mode;
	count++;
      }
    }
  }
  closedir(dp);
  qsort(node, count, sizeof(struct _node), mtime_cmp); /* Sort! by mtime */

  for(i=0,total=count; i<count; i++)
  {	if((node[i].mode & 0770)==0640)  keep=1; /* POST MARKED: 0640 */
	else if(node[i].mtime < duetime  || total > maxpost) keep=0;  
	else keep=1;
	if(!keep) {
	     printf("Unlink %s\n", node[i].fbasename);
	    /* unlink(node[i].fname);*/  /* kill it now! */
	     total--;
	}
  }

}

main( argc, argv )
char	*argv[];
{
    char	*progmode;

#ifdef CACHED_OPENBOARD
    extern_util = 1;
#endif
    umask(0003);
    if( argc < 3 )  usage();
    progmode = argv[1];
    homepath = argv[2];
    home_bbs(homepath);
    if( strcasecmp( progmode, "list" ) == 0 ) {
	search_boards( 0 );
    } else if( strcasecmp( progmode, "visit" ) == 0 ) {
	search_boards( 1 );
    } else if( strcasecmp( progmode, "post" ) == 0 ) {
	post_article( 0 );
    } else if( strcasecmp( progmode, "cancel" ) == 0 ) {
	if( argc < 5 )  usage();
	cancel_article( argv[3], argv[4] );
    } else if( strcasecmp( progmode, "expire" ) == 0 ) {
	if( argc < 5 )  usage();
	expire_article( argv[3], argv[4], argv[5] );
    }
}

