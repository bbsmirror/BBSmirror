
/*
Eagles Bulletin Board System
Copyright (C) 1994, Ray Rocker, rrrocker@rock.b11.ingr.com
                                rock@seabass.st.usm.edu
                                72673.2105@compuserve.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/*
   Adapted from Pirates BBS 1.8 "read.c"
   Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
*/

#include "client.h"
#include <malloc.h>

#define MAIL_KEEP_NAME " $MAIL "

int BoardType;
#ifdef VOTE
int please_vote=0;
#endif

#ifdef SEARCH_POSTS
char find_str[40];
#endif

extern READMENUITEM mailreadlist[], mainreadlist[], filereadlist[];

extern OpenMailbox(), CloseMailbox();
extern OpenBoard(), CloseBoard();
#ifndef STRIP_OUT
extern OpenFileBoard(), CloseFileBoard();
#endif

#define PUTCURS   move(4+locmem->crs_line-locmem->top_line,0);prints(">");
#define RMVCURS   move(4+locmem->crs_line-locmem->top_line,0);prints(" ");

HEADER *headers = NULL;

struct keeploc {
    int btype;
    char *key ;
    int top_line ;
    int crs_line ;
    struct keeploc *next ;
} ;

struct keeploc *
getkeep(btype,s,def_topline,def_cursline)
char *s ;
LONG def_topline, def_cursline;
{
  static struct keeploc *keeplist = NULL ;
  struct keeploc *p ;

  for(p = keeplist; p!= NULL; p = p->next) {
    if(p->btype == btype && !strcmp(s,p->key))
      return p ;
  }
  p = (struct keeploc *) malloc(sizeof (*p)) ;
  p->btype = btype;
  p->key = (char *) malloc(strlen(s)+1) ;
  strcpy(p->key,s) ;
  p->top_line = def_topline ;
  p->crs_line = def_cursline ;
  p->next = keeplist ;
  keeplist = p ;
  return p ;
}

void
fixkeep(locmem, maxline, def_lines)
struct keeploc *locmem;
int maxline;
int def_lines;
{
  if (maxline < locmem->top_line) {
    if ((locmem->top_line = maxline - def_lines) < 1)
      locmem->top_line = 1;
  }
  if (maxline < locmem->crs_line) locmem->crs_line = maxline;
}

MailMenuTitle()
{
  clear();
  move(0,0);
  prints("�q�l�l��Ū�H�t��\n") ;
  prints("(��/��)�e/�U�@�ʫH (r)Ū�H (W)�^�H (d)�R�H (F)��H (m)�аO (P/N)�e/�U�� (e)���}\n");  
  prints("(##<cr>)���##�� ($)��̫�@�� (D/T)�@�d��R�H/��H (G)�^�H���@�s�H (h)���U����\n");
  standout();
  prints(" �s��    ���    %-24s %-38s\n","�o�H�H","�H����D") ;
  standend();
  clrtobot();
}

ReadMenuTitle()
{
  int i;
#ifdef SHOW_BM
  NAMELIST mgrlist = NULL;
#endif
  clear();
  move(0,0);
  prints("                                                      �ثe�Q�װ� '%s'\n",currboard) ;
   prints("(��)�\\Ū (��)���} (?,/,[,],=)�W/�U�j�M [TAB]�O�D���� (x)��ذ� (V)�벼 (F)��H\n"); 
  prints("(##<cr>)���##�g <CTRL-P>�o���峹 (S)�̧Ǿ\\Ū (E/d)�s��/�R���峹 (h)���U����\n");
  standout();
  prints(" �s��    ���    %-16s %-46s\n","�o�H�H","�峹���D") ;
  standend();
  clrtobot() ;

#ifdef SHOW_BM
  move(0,0); 
  if( bbs_get_boardmgrs(currboard, &mgrlist) == S_OK) {
    if(mgrlist==NULL || !mgrlist[0][0]) prints("���O�L�O�D");
    else {
      prints("�O�D�G");
#ifndef NAMELIST_IN_ARRAY 
        for(; mgrlist != NULL; mgrlist=mgrlist->next) {
          prints(" %s",mgrlist->word);
        }
#else
        i = 0;
        while(mgrlist[i][0]) {
  	  prints(" %s", mgrlist[i]);
	  i++;
        }
    }
#endif
  }
  else prints("���O�L�O�D");
  free_namelist(&mgrlist);
#endif

  if( bbs_check_mail()) {
    move(0, t_columns/3);
    prints("�e���A���H��f");
  }
#ifdef VOTE
  else if(please_vote && !is_public_acct()) {
   move(0, t_columns/3);
   prints("[�Q�װϧ벼��]");
 }
#endif
}

#ifndef STRIP_OUT
FileMenuTitle()
{
    clear();
    move(0,0);
    prints("Interactive Download Menu                          Current Board '%s'\n",currfileboard) ;
    prints("(n)ext File      (p)revious File      (v)iew File      (e)xit Download Menu\n");
    prints("##<cr> go to file ##          (r)ecieve file          (h) Get a HELP screen\n");
    standout();
    prints("  ENT T  SIZE  %s\n","Filename") ;
    standend();
    clrtobot() ;
}
#endif

struct get_recs_struct {
  SHORT want;
  SHORT got;
};

GetRecsFunc(indx, hdr, info)
int indx;
HEADER *hdr;
struct get_recs_struct *info;
{
  if (info->got >= info->want) return ENUM_QUIT;
  memcpy(&headers[info->got], hdr, sizeof(HEADER));
  info->got++;
  return S_OK;
}  

MenuGetRecords(first_line, num_lines)
int first_line, num_lines;
{
  int result;
  struct get_recs_struct gr;
  gr.want = (SHORT)num_lines;
  gr.got = 0;
  first_line--;
  result = bbs_enum_headers(gr.want, (SHORT)first_line, 0, GetRecsFunc, &gr);
  return (result == S_OK ? (int)gr.got : 0);
}

MenuDrawScreen(first_line, num_lines)
int first_line, num_lines;
{
  int i,k;
  char c;
  char buf[TITLELEN+40];
  char mtime[30];
  move(4,0) ;
  for (i=0; i<num_lines; i++) {
    if (BoardType == BOARD_FILE) {
      c = (BITISSET(headers[i].flags, FILE_BINARY) ? 'B' : 'A');
    }
    else {
      if (headers[i].flags & FILE_MARKED)
	c = (BITISSET(headers[i].flags, FILE_UNREAD) ? 'M' : 'm');
      else
	c = (BITISSET(headers[i].flags, FILE_UNREAD) ? 'N' : ' ');
    }

    k = (headers[i].size + 512) / 1024;
    strcpy(mtime, (char *)(ctime(&headers[i].mtime) + 4));
    mtime[6]='\0';
    if (BoardType == BOARD_FILE)
      sprintf(buf, " %4d %c %4dk  %s", first_line+i, c, k, headers[i].title);
    else if(BoardType == BOARD_MAIL)
      sprintf(buf, " %4d %c %6.6s   %-24s %s", first_line+i, c,
         mtime,headers[i].owner, headers[i].title);
    else {
      ADDR ownerbuf;
      char *at;
      char *point;
      memset(ownerbuf, 0, sizeof(ownerbuf));
      strncpy(ownerbuf, headers[i].owner, ADDRLEN);
      if((at=strchr(ownerbuf, '@'))!=NULL) {
        *at = '\0';
	point = strchr(ownerbuf, '.');
	if(point) *(point+1)='\0';
	else strcat(ownerbuf, ".");
      }
#ifdef SEARCH_POSTS_________UNCERTAINED
/* �[�j�G�סF���ɦ����D */
      if( strlen( find_str) > 1 && strstr(headers[i].title, find_str))
        sprintf(buf, " %4d %c %6.6s   [32m%-16s[m %s", first_line+i, c,
           mtime,ownerbuf, headers[i].title);
      else
        sprintf(buf, " %4d %c %6.6s   %-16s %s", first_line+i, c,
           mtime,ownerbuf, headers[i].title);
#else
      if(!strncmp(headers[i].title, "Re:", 3))
      sprintf(buf, " %4d %c %6.6s   %-16s %s", first_line+i, c,
         mtime,ownerbuf, headers[i].title);
      else
      sprintf(buf, " %4d %c %6.6s   %-16s �� %s", first_line+i, c,
         mtime,ownerbuf, headers[i].title);
#endif
    }

    if(strlen(buf) >= 79) {
      buf[78] = '^' ;
      buf[79] = '\0' ;
    }
    dont_allow_ansi();
    prints("%s\n", buf) ;
    allow_ansi();
  }
}

NoHeaders()
{
  switch (BoardType) {
  case BOARD_MAIL:
    prints("�z���H�c�̥ثe�S������H��.\n");
    break;
  case BOARD_FILE:
    prints("No files on this board\n");
    break;
  default:
    move (6,0);
    prints("�ثe�b���Q�װϩ|�����峹�o��.\n");
    prints("�Y�n�o���峹�ЦܥD���ϥ� (P)ost �\\��o��.\n");
  }
  pressreturn();
}

ReadMenu(openfn, closefn, fetchfn, titlefn, drawfn, keepname, rcmdlist)
int (*openfn)();
int (*closefn)();
int (*fetchfn)();
int (*titlefn)();
int (*drawfn)();
char *keepname;
READMENUITEM *rcmdlist;
{
  char lbuf[11];
  int lbc, i, ch;
  struct keeploc *locmem;
  int screen_len = t_lines - 5;
  int num_entries;
  int last_line;
  int openflags;
  int mode = DONOTHING;
  int prevch;
#ifdef SEARCH_POSTS
  char buf[80], tmpstr[40];
  struct keeploc saveloc;
  int first=0;
#endif

  
  if (!headers)
    headers = (HEADER *)calloc(screen_len, sizeof(*headers));
  
  (*titlefn)();
  last_line = (*openfn)(&openflags, 0, NULL);
  if (last_line == -1) {
    prints("Cannot access this board\n");
    return 0;
  }
  if(last_line == 0) {
    NoHeaders();
    (*closefn)();
    return 0;
  }
  
  locmem = getkeep(BoardType, keepname,
	   (last_line-screen_len+1 < 1)?1:last_line-screen_len+1,last_line) ;
  
  fixkeep(locmem, last_line, screen_len-3);
  num_entries = (*fetchfn)(locmem->top_line, screen_len);
  (*drawfn)(locmem->top_line, num_entries);
  
  PUTCURS ;
  lbc = 0 ;
  while((ch = igetch()) != EOF) {
    if (PagePending()) {
      Answer();
      mode = FULLUPDATE;
      goto endofloop;
    }
    if(isdigit(ch)) {
      if(lbc < 9)
	lbuf[lbc++] = ch ;
      goto endofloop ;
    }
    if(ch != '\n' && ch != '\r')
      lbc = 0 ;

    prevch = 0;
redo:
    switch(ch) {
      int val ;
#ifdef VOTE
    case 'V':
#ifdef PUB_ACCT_CANT_VOTE
        if (is_public_acct()) {
          bell();
          break;
        }
#endif
        if(BoardType == BOARD_POST) { 
	    BoardVote(currboard);
            if(check_polls(currboard, NULL, NULL)) please_vote=1;
	    else please_vote=0;
	}
        mode = FULLUPDATE;
        break;
    case 'R':
	if(BoardType == BOARD_POST) {
	    ShowResults(currboard);
            if(check_polls(currboard, NULL, NULL)) please_vote=1;
	    else please_vote=0;
	}

	mode = FULLUPDATE;
	break;
    case 'v':
	if(_has_perms(PERM_SYSOP) && BoardType == BOARD_POST) {
	    EditResults(currboard);
	    mode = FULLUPDATE;
	} else bell();
	break;
#endif
#ifdef SEARCH_POSTS
    case '/':
    case '?':
    case '[':
    case ']':
    case '=':
       if (ch == '=') first=1;
       else first=0;
       if( ch =='/' || ch == '?' ) {
          if (ch == '/')
            sprintf(buf, "�п�J����j�M�r�� [%s]: ", find_str);
          else
            sprintf(buf, "�п�J���e�j�M�r�� [%s]: ", find_str);
          getdata(t_lines-1, 0, buf, tmpstr, 40, DOECHO, 0);
          if(tmpstr[0]) strcpy(find_str, tmpstr);
          move(t_lines-1, 0);
          clrtoeol();
       } else {
          if (ch==']') { 
            ch = '/';
            strcpy(find_str,headers[locmem->crs_line - locmem->top_line].title);
          } else if(*(headers[locmem->crs_line - locmem->top_line].title + 2) == ':') {
            ch = '?';
            strcpy(find_str, headers[locmem->crs_line - locmem->top_line].title+4);
          } else 
             break;
       }

       if(find_str[0]) {
            prevch = ch;
            if(ch=='/') ch = KEY_DOWN;
            else ch = KEY_UP;
            memset(&saveloc, 0, sizeof(saveloc));
            saveloc.crs_line = locmem->crs_line;
            saveloc.top_line = locmem->top_line;
            goto redo;
       } else mode = PARTUPDATE;
       break;
#endif
    case 'q':
    case 'e':
    case KEY_LEFT:
      mode = EXITMENU;
      break ;
    case '\n':
    case '\r':
    case 'l':
    case KEY_RIGHT:
/*
      if(lbc == 0)
	break ;
*/
      if(lbc==0) { ch='r'; goto redo; }
      lbuf[lbc] = '\0' ;
      val = atoi(lbuf) ;
      lbc = 0 ;
      if(val > last_line)
	val = last_line ;
      if(val <= 0)
	val = 1 ;
      if(val >= locmem->top_line && val < locmem->top_line+screen_len) {
	RMVCURS ;
	locmem->crs_line = val ;
	PUTCURS ;
	continue ;
      }
      locmem->top_line = val - 10 ;
      if(locmem->top_line <= 0)
	locmem->top_line = 1 ;
      locmem->crs_line = val ;
      mode = PARTUPDATE | FETCHNEW;
      goto endofloop ;
    case 'p':
    case 'k':
    case KEY_UP:
      if(locmem->crs_line == locmem->top_line) {
	if(locmem->crs_line == 1) {
	  bell() ;
#ifdef SEARCH_POSTS
       if(prevch == '?') {
           prevch = 0;
           locmem->crs_line = saveloc.crs_line;
           locmem->top_line = saveloc.top_line;
           mode = FETCHNEW | PARTUPDATE;
       }
#endif
	  break ;
	}
	locmem->top_line -= screen_len - 2 ;
	if(locmem->top_line <= 0)
	  locmem->top_line = 1 ;
	locmem->crs_line-- ;
	mode = PARTUPDATE | FETCHNEW;
	break ;
      }
#ifdef SEARCH_POSTS
      if(prevch == 0)
#endif
      { RMVCURS } 
      locmem->crs_line-- ;
#ifdef SEARCH_POSTS
      if(prevch == 0)
#endif
      { PUTCURS } 
      break ;
    case CTRL('L'):
      redoscr() ;
      break ;
    case 'n':
    case 'j':
    case KEY_DOWN:
      if(locmem->crs_line == last_line) {
	bell() ;
#ifdef SEARCH_POSTS
       if(prevch == '/') {
           prevch = 0;
           locmem->crs_line = saveloc.crs_line;
           locmem->top_line = saveloc.top_line;
           mode = FETCHNEW | PARTUPDATE;
       }
#endif
	break ;
      }
      if(locmem->crs_line+1 == locmem->top_line+screen_len) {
	locmem->top_line += screen_len - 2 ;
	locmem->crs_line++ ;
	mode = PARTUPDATE | FETCHNEW;
	break ;
      }
#ifdef SEARCH_POSTS
      if(prevch == 0)
#endif
      { RMVCURS }
      locmem->crs_line++ ;
#ifdef SEARCH_POSTS
      if(prevch == 0)
#endif
      { PUTCURS }
      break ;
    case 'N':
    case ' ':
    case KEY_PGDN:
      if(locmem->top_line + screen_len - 1 >= last_line) {
	bell() ;
	break ;
      }
      locmem->top_line += screen_len - 1 ;
      locmem->crs_line = locmem->top_line ;
      mode = PARTUPDATE | FETCHNEW;
      break ;
    case 'P':
    case KEY_PGUP:
      if(locmem->top_line == 1) {
	bell() ;
	break ;
      }
      locmem->top_line -= screen_len - 1 ;
      if(locmem->top_line <= 0)
	locmem->top_line = 1 ;
      locmem->crs_line = locmem->top_line ;
      mode = PARTUPDATE | FETCHNEW;
      break ;
    case '$':
      if(last_line < locmem->top_line + screen_len) {
	RMVCURS ;
	locmem->crs_line = last_line ;
	PUTCURS ;
	break ;
      }
      locmem->top_line = last_line - screen_len + 1 ;
      if(locmem->top_line <= 0)
	locmem->top_line = 1 ;
      locmem->crs_line = last_line ;
      mode = PARTUPDATE | FETCHNEW;
      break ;
    default:
      for(i = 0; rcmdlist[i].cmdfunc != NULL; i++) {
	if(rcmdlist[i].cmdkey == ch && 
           HasReadMenuPerm(rcmdlist[i].openaccess, openflags) &&
	   HasPerm(rcmdlist[i].permaccess)) {
	  mode = (*(rcmdlist[i].cmdfunc))
	    (&headers[locmem->crs_line - locmem->top_line],
	     locmem->crs_line, last_line, openflags);
#ifdef VOTE
	  if( ch == 's') {
	     if(check_polls(currboard, NULL, NULL))  please_vote = 1;
	     else please_vote = 0;
	 } 
#endif
          if( mode == KEY_UP ) {
		if(locmem->crs_line == 1) { mode=FULLUPDATE; break; }
                else prevch=KEY_UP;
      		if(locmem->crs_line == locmem->top_line) {
	  	    locmem->top_line -= screen_len - 2 ;
	  	    if(locmem->top_line <= 0)
	      	        locmem->top_line = 1 ;
	  	    locmem->crs_line-- ;
	  	    mode = PARTUPDATE | FETCHNEW;
	  	    break ;
                }
                locmem->crs_line-- ;
                break ;
	  }
          if( mode == KEY_DOWN ) {
		if(locmem->crs_line == last_line) { mode=FULLUPDATE; break; }
                else prevch=KEY_DOWN;
      		if(locmem->crs_line+1 == locmem->top_line+screen_len) {
	  	    locmem->top_line += screen_len - 2 ;
	  	    locmem->crs_line++ ;
	  	    mode = PARTUPDATE | FETCHNEW;
	  	    break ;
                }
                locmem->crs_line++ ;
                break ;
	  }
	  break ;
	}
      }
      if(rcmdlist[i].cmdfunc == NULL)
	bell();
      break ;
    }
  endofloop:
    if (mode & (FETCHNEW | NEWDIRECT)) {
      if (mode & NEWDIRECT) (*closefn)();
      last_line = (*openfn)(&openflags, 0, NULL);
      if (mode & NEWDIRECT)
	locmem = getkeep(BoardType, keepname,
			 (last_line-screen_len < 1)?1:last_line-screen_len+1,
			 last_line) ;
      fixkeep(locmem, last_line, screen_len-3);
      num_entries = (*fetchfn)(locmem->top_line, screen_len);
    }
    if(prevch == KEY_UP || prevch == KEY_DOWN) {
	ch = 'r';
        prevch = 0;
	goto redo;
    }
#ifdef SEARCH_POSTS
    if(prevch == '/' || prevch == '?') {
     int searched = abs(locmem->crs_line - saveloc.crs_line) - 1;
     if((searched % 20) == 0) {
       move(t_lines-1, 0);
       prints("�j�M��.... /");
       refresh();
     }
     else if((searched % 20) == 10) {
       move(t_lines-1, 0);
       prints("�j�M��.... \\");
       refresh();
     }
     if (first) {
       if (strcmp(headers[locmem->crs_line - locmem->top_line].title,find_str))
        goto redo;
       else first=0;
     } else {
       if(!strstr(headers[locmem->crs_line - locmem->top_line].title, find_str)
       && !strstr(headers[locmem->crs_line - locmem->top_line].owner, find_str))
        goto redo;
     }
       move(t_lines-1, 0);
       clrtoeol();
       prevch = 0;
       mode |= PARTUPDATE;
   }
#endif

    if (mode & (FULLUPDATE | PARTUPDATE)) {
      if (mode & FULLUPDATE) {
	clear() ;
	(*titlefn)();
      }
      if(last_line <= 0) {
	NoHeaders();
	num_entries = 0 ;
	break;
      }
      (*drawfn)(locmem->top_line, num_entries);
      if(locmem->crs_line > last_line)
	locmem->crs_line = last_line ;
      clrtobot() ;
      PUTCURS ;
    }
    if(mode == EXITMENU || num_entries == 0)
      break ;
    mode = DONOTHING ;
  }
  (*closefn)();
  clear() ;
#ifdef MAX_MAILS
  if(BoardType==BOARD_MAIL) {
  }
#endif
  return 0;
}

MailRead()
{
  BoardType = BOARD_MAIL;
#ifdef DETAILED_USERMODE
  bbs_set_mode(RMAIL);
#else
  bbs_set_mode(M_MAIL);
#endif
  ReadMenu(OpenMailbox, CloseMailbox, MenuGetRecords, MailMenuTitle, 
	   MenuDrawScreen, MAIL_KEEP_NAME, mailreadlist);
  bbs_set_mode(M_UNDEFINED);  
  return PARTUPDATE;
}

MainRead()
{
  if (*currboard == '\0') {
    move(3,0);
    clrtobot();
    prints("�Х���ܤ@�ӰQ�װ�.\n");
    pressreturn();
  }
  else {
    BoardType = BOARD_POST;
    bbs_set_mode(M_READING);
#ifdef VOTE
    if(check_polls(currboard, NULL, NULL)) please_vote=1;
#endif
    ReadMenu(OpenBoard, CloseBoard, MenuGetRecords, ReadMenuTitle,
    	     MenuDrawScreen, currboard, mainreadlist);
#ifdef VOTE
    please_vote=0;
#endif
    bbs_set_mode(M_UNDEFINED);
  }
  return FULLUPDATE;
}

#ifndef STRIP_OUT

FileDownload()
{
  if (*currfileboard == '\0') {
    move(3,0);
    prints("Use (S)elect to select a file board first.\n");
  }
  else {
    BoardType = BOARD_FILE;
    ReadMenu(OpenFileBoard, CloseFileBoard, MenuGetRecords, FileMenuTitle,
    	     MenuDrawScreen, currfileboard, filereadlist);
  }
  return PARTUPDATE;
}
#endif
