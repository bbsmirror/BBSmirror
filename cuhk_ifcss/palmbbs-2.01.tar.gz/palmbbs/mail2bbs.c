#define MAILDIR  "home/mail/"
#define DOMAIN_NAME "palm1.ntu.edu.tw"

#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include "server.h"

append_mail( fin, sender, userid, title)
FILE *fin;
char *userid, *sender, *title ;
{
	FILE *fout;
	ACCOUNT acct;
        time_t tmp_time;
	PATH msgdir,msgfile;
	char genbuf[255];
	struct stat stbuf;
	READINFO readinfo;
	SHORT fileid;

/* check if the userid is in our bbs now */
	if(_lookup_account(userid, &acct)!=S_OK) return -1;

/* check for the mail dir for the userid */
	get_mail_directory(acct.userid, msgdir);
        if (stat(msgdir, &stbuf) == -1 || !S_ISDIR(stbuf.st_mode))  return -1;
						/* directory missing */
        printf("Ok, dir is %s\n", msgdir);

  	get_filelist_ids(msgdir, &readinfo);
  	for (fileid = 1; fileid <= BBS_MAX_FILES; fileid++) {
    	    if (test_readbit(&readinfo, fileid)) continue;
    	    fileid_to_fname(msgdir, fileid, msgfile);
            printf("Ok, the file is %s\n", msgfile );
	    if( (fout = fopen(msgfile, "w")) == NULL)  return -1;
            time( &tmp_time );
            fprintf( fout, "From:      %s via BBS mail gateway\n", sender );
            fprintf( fout, "Title:     %s\n", title );
            fprintf( fout, "Date:      %s", ctime( &tmp_time ) );
 	    fprintf( fout, "To:        %s\n\n",acct.userid);

            while (fgets( genbuf, 255, fin ) != NULL) {
                fputs( genbuf, fout );
            }
            fclose( fout );
	    notify_new_mail(acct.userid, 1); 
   	    return 0;
 	}
}

main(argc, argv)
int argc;
char *argv[];
{
    
    char sender[ 256 ];
    char username[ 256 ];
    char receiver[ 256 ];

    /* argv[ 1 ] is original sender */
    /* argv[ 2 ] is userid in bbs   */
    /* argv[ 3 ] is the mail title  */

    if (argc != 4) {
        char *p = strrchr( argv[ 0 ], '/' );

        printf("Usage: %s sender receiver_in_bbs mail_title\n",
             p ? p+1 : argv[ 0 ]);
        return 1;
    }


  home_bbs(BBSHOME);
  open_bbslog("emaillog",1);  /* open a log file or the bbslog() will fail */
  set_log_header("E-mail post:");
  umask(0007);


    setreuid( BBSUID, BBSUID );
    setregid( BBSGID, BBSGID );

    if (strchr( argv[ 1 ], '@' )) {
        strcpy(sender, argv[ 1 ]);
    } else {
        char *p, *l, *r;
        char buf[ 256 ];
        strcpy( buf, argv[ 1 ] ); 
        p = strtok( buf , " \t\n\r" );
        l = strchr( argv[ 1 ], '(');
        r = strchr( argv[ 1 ], ')');
        if (l < r && l && r ) strncpy( username, l, r - l + 1 ); 
        sprintf(sender, "%s@%s %s", p, DOMAIN_NAME, username );
    }

    strcpy( receiver, argv[ 2 ] );
    return append_mail( stdin, sender, receiver, argv[ 3 ]);
}


