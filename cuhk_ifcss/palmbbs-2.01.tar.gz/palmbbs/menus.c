
/*
Eagles Bulletin Board System
Copyright (C) 1994, Ray Rocker, rrrocker@rock.b11.ingr.com
                                rock@seabass.st.usm.edu
                                72673.2105@compuserve.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "client.h"

char permtab[MAX_CLNTCMDS];
char *currentboard = currboard;

/*
   Read menus are still hardcoded. We should fix this one day.
*/

int MainReadHelp(), MailReadHelp();
int MailDisplay(), MailDelete(), MailDelRange();
#ifdef MAIL_FORWARD_RANGE
int MailFwdRange();
#endif
int MailReply(), GroupReply(), Forward(), SequentialRead();
int FileMenu(), FileHelp(), FileReadHelp();
int ReadMenuSelect();
int PostDisplay(), PostDelete(), PostMessage(), PostDelRange(), PostMark();
int PostEdit();
#ifdef CAN_CROSSPOST
int crosspost();
#endif
#ifndef STRIP_OUT
int FileDownload(), FileView(), FileReadMenuProto();
int FileReceive(), FileReadMenuSelect(), FileForward();
#endif
int BvoteMaintain(),BoardVote();
#ifdef CSIE_ANNOUNCE
int digest(); int bmnote(); int copy2digest();
#endif

READMENUITEM mainreadlist[] = {
        'r',             PostDisplay,       0,           C_READMSG,
        "?,/     ���e/����j�M        [,]     ���e/����j�M�P���D�峹\n",
        CTRL('P'),       PostMessage,       OPEN_POST,   C_POST,
        "CTRL-P  �i�K�@�g�峹         =       �j�M�P���D���Ĥ@�g�峹\n",
        's',             ReadMenuSelect,    0,           C_BNAMES,
        "s       ����t�@�ӰQ�װ�     S       �̧Ǿ\\Ū�峹\n",
        'S',             SequentialRead,    0,           C_ENUMHDRS,
        "V       �벼                 R       �ݿ��|�����G\n",
        'd',             PostDelete,        0,           C_DELMSG,
        "d       �R���ӤH�i�K���峹   E       �s��ۤv���峹\n",
#ifdef CAN_EDIT_POST
        'E',             PostEdit,          OPEN_POST,  C_REPLACEMSG,
#else
        'E',             PostEdit,          OPEN_MANAGE, C_REPLACEMSG,
#endif
        NULL,
        'F',             Forward,           0,           C_FORWARDMSG,
        "F       ��H�峹\n",
        'D',             PostDelRange,      OPEN_MANAGE, C_DELRANGE,
        "D       �R���@�d�򤧤峹     m       �аO�峹�A����'D'���R��\n",
        'm',             PostMark,          OPEN_MANAGE, C_MARKMSG,
        NULL,
#ifdef VOTE
        'M',             BvoteMaintain,     OPEN_MANAGE, C_BVOTEMAINTAIN,
        "M       ��z�벼�B���|\n",
#endif
#ifdef CAN_CROSSPOST
        'X',             crosspost,         OPEN_MANAGE, C_POST,
        NULL,
#endif
#ifdef CSIE_ANNOUNCE
        'x',             digest,            0,           0,
        NULL,
        KEY_TAB,         bmnote,            0,           0,
        NULL,
        'c',             copy2digest,    OPEN_MANAGE, 0,
        "c       �ƻs�峹�ܺ�ذϤ��Y�@�g�峹��\n",
#endif
        'h',             MainReadHelp,      0,           0,
        NULL,
        CTRL('J'),       MainReadHelp,      0,           0,
        NULL,
        '\0',            NULL,              0,           0,
        NULL
};

READMENUITEM mailreadlist[] = {
        'r',             MailDisplay,       0,           C_READMSG,
        "r       �\\Ū��ЩҦb��m�H��\n",
        'W',             MailReply,         OPEN_POST,   C_MAIL,
        "W       �^�H���o�H�H\n",
        'G',             GroupReply,        OPEN_POST,   C_MAIL,
        "G       �^�H���o�H�H�M��L���쥻�H�󪺤H\n",
        'd',             MailDelete,        OPEN_MANAGE, C_DELMSG,
        "d       �R����ЩҦb��m�H��\n",
        'D',             MailDelRange,      OPEN_MANAGE, C_DELRANGE,
        "D       �R���@�d�򤧫H��\n",
        'F',             Forward,           0,           C_FORWARDMSG,
        "F       ��H���ʫH��\n",
#ifdef MAIL_FORWARD_RANGE
        'T',             MailFwdRange,      OPEN_POST,   C_FORWARDMSG,
        "T       ��H�@�d�򤧫H��\n",
#endif
#ifdef MARK_MAIL
        'm',             PostMark,          OPEN_POST,   C_MARKMSG,
        "m       �N���ʫH��аO�_��(�קK'D'���R��)\n",
#endif
        'h',             MailReadHelp,      0,           0,
        "h       �����U����\n",
        CTRL('J'),       MailReadHelp,      0,           0,
        NULL,
        '\0',            NULL,              0,           0,
        NULL
};

#ifndef STRIP_OUT
READMENUITEM filereadlist[] = {
        't',             FileReadMenuProto, 0,           C_SETPROTO,
        "t               Set download protocol\n",
#if !REMOTE_CLIENT
        'v',             FileView,          0,           C_DOWNLOAD,
        "v               View a text file\n",
#endif
        'r',             FileReceive,       0,           C_DOWNLOAD,
        "r               Recieve (download) selected file\n",
        'F',             FileForward,       0,           C_FORWARDFILE,
        "F               Mail file to yourself -- uuencodes if binary\n",
        's',             FileReadMenuSelect, 0,          C_FBNAMES,
        "s               Select a new file board\n",
        'h',             FileReadHelp,      0,           0,
        "h               Get this help screen\n",
        CTRL('J'),       FileReadHelp,      0,           0,
        NULL,
        '\0',            NULL,              0,           0,
        NULL
};
#endif

DoReadHelp(p, flags)
READMENUITEM *p ;
int flags;
{
  while(p->cmdkey) {
    if (HasReadMenuPerm(p->openaccess, flags) &&
        HasPerm(p->permaccess) && p->helpstr)
      prints(p->helpstr);
    p++ ;
  }
}

MovementReadHelp()
{
  standout();
  prints("���ʫ��O\n");
  standend();
  prints("p,k     �W�@�ʤ峹           n,j     �U�@�ʤ峹\n");
  prints("P,      �W�@��               N,Space �U�@��\n");
  prints("##<cr>  ����� ## �g�峹     $       ����̫�@�g�峹\n");
}

MiscReadHelp()
{
  prints("CTRL-L  ��ø�ù�             e       ���}�\\Ū����\n");
}

ReadMenuHelp(title, list, flags)
char *title;
READMENUITEM *list;
int flags;
{
  clear();
  standout();
  prints(title);
  standend();
  move(2,0);
  MovementReadHelp();
  prints("\n");
  standout();
  prints("��L���O\n");
  standend();
  DoReadHelp(list, flags);
  MiscReadHelp();
  pressreturn();
  clear();
  return FULLUPDATE;
}

/*ARGSUSED*/
MailReadHelp(hptr, curr, num, flags)
void *hptr;
LONG curr, num, flags;
{
  return (ReadMenuHelp("�q�l�l��\\Ū�t�λ��U����\n", mailreadlist, flags));
}

/*ARGSUSED*/
MainReadHelp(hptr, curr, num, flags)
void *hptr;
LONG curr, num, flags;
{
  return (ReadMenuHelp("�\\Ū�峹���U����\n", mainreadlist, flags));
}

#ifndef STRIP_OUT
/*ARGSUSED*/
FileReadHelp(hptr, curr, num, flags)
void *hptr;
LONG curr, num, flags;
{
  return (ReadMenuHelp("Download Menu Help Screen\n", filereadlist, flags));
}
#endif

NotImpl()
{
  clear();
  prints("This function is not yet implemented.\n");
  pressreturn();
  return FULLUPDATE;
}

EndMenu()
{
  return EXITMENU;
}

SetPermTable()
{
  memcpy(permtab, myinfo.access, MAX_CLNTCMDS);
}

HasPerm(perm)
int perm;
{
  if (perm == 0) return 1;
  else if (perm < 0 || perm >= MAX_CLNTCMDS) return 0;
  else return (permtab[perm]-'0');
}

HasReadMenuPerm(perm, flags)
int perm, flags;
{
  if (perm == 0) return 1;
  else return (perm & flags);
}

int
MenuGetch()
{
  int c;
  while (1) {
    c = igetch();
    if (isprint(c) || KEY_ARROW(c)) break;
    if (c == '\r' || c == '\n' || c == '\010' || c == '\177') {
      c = '\n';
      break;
    }
    if (c == CTRL('L')) {
      redoscr() ;
    }
  }
  return c;
}

