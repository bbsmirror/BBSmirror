/*
Eagles Bulletin Board System
Copyright (C) 1994, Ray Rocker, rrrocker@rock.b11.ingr.com
                                rock@seabass.st.usm.edu
                                72673.2105@compuserve.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "client.h"
#include <malloc.h>
#include <time.h>

ChangeInfo(acct, authorized)
ACCOUNT *acct;
int authorized;
{
  NAME userid;
  ACCOUNT nr;
  int rc, grok, fail=0;
/* if (fail == TRUE), then there will be a "Press Enter to continue" prompt */
  
  SHORT flags = 0;
  PASSWD passcfm;
  int x, y;
  char genbuf[256], ans[4];
  
  memset(&nr, 0, sizeof nr);
  getdata(t_lines-2, 0, "(0) ���} (1) ���ܸ�� (2) �]�w�K�X ==> [0] ", ans,sizeof(ans),DOECHO, 0);

  if ( ans[0]=='0' || ans[0]=='\0' )
      return (0);

  clear();
  refresh();
  move(3,0);
  getyx(&y, &x);  

    switch( ans[0] ) {
        case '1':
           prints("�e%s�f, �гv���ק�,������ <ENTER> �N���ϥ� [] ������ơC\n",acct->userid);
            y+=2;

            if (authorized)
            {
                sprintf(genbuf, "userid [%s]: ", acct->userid);
                do {
                    getdata(y++, 0, genbuf, nr.userid, sizeof(nr.userid), DOECHO, 0);
                    if (!nr.userid[0])
                        break;
                    if (grok = CheckUserid(nr.userid)) {
                        move(y, 0);
                        prints("���X�k ID, �άO�� ID �w�s�b, �Э���J.\n");
                        pressreturn();
                        move(y, 0);
                        clrtobot();
                        y--; 
                    }
                    else BITSET(flags, MOD_USERID);
                } while (grok);
            }

#ifndef USER_CHANGE_REALNAME 
            if ( authorized )
#endif
            {
                sprintf(genbuf, "�u��m�W [%s]: ", acct->realname);
                getdata(y++, 0, genbuf, nr.realname, sizeof(nr.realname), DOECHO, 0);
                if (nr.realname[0]) BITSET(flags, MOD_REALNAME);
            }

            sprintf( genbuf, "�ʺ� [%s]: ", acct->username );
            getdata(y++, 0, genbuf, nr.username, sizeof(nr.username), DOECHO,0);
            if (nr.username[0]) BITSET(flags, MOD_USERNAME);
 
            sprintf( genbuf, "�~���a�} [%s]: ", acct->address );
            getdata(y++, 0, genbuf, nr.address, sizeof(nr.address), DOECHO, 0);
            if (nr.address[0]) BITSET(flags, MOD_ADDRESS);
            
	    sprintf( genbuf, "Email ���} (��J n/a ���ܵL) [%s]: ", acct->email );
            getdata(y++, 0, genbuf, nr.email, sizeof(nr.email), DOECHO, 0);
            if (nr.email[0]) BITSET(flags, MOD_EMAIL);
            if (!strcmp(nr.email, "n/a")) nr.email[0] = '\0';

            do {
                sprintf( genbuf, "�׺ݾ��κA [%s]: ", acct->terminal );
                getdata(y++, 0, genbuf, nr.terminal, sizeof(nr.terminal), DOECHO, 0);
                if( nr.terminal[0] ) {
                    if((grok = 
                        ((authorized) ? 
                         term_ok(nr.terminal)-1 : /* term_ok : 0 for bad
                                                               1 for ok */ 
                         term_init(nr.terminal))) 
                                                 == -1) {
                        prints("�o�Ӳ׺ݾ������O���~��.\n");
                        pressreturn();
                        move(y,0);
                        prints(" �q�`�O�]�w�� vt100, �t�� ansi, vt102, dumb...");
                        y--;
                    }
                    else {
                        move(y,0);
                        clrtobot(); 
                        BITSET(flags, MOD_TERMINAL);
                    }
                }

            } while (nr.terminal[0] && grok == -1);

#ifdef NUM_LOGN_POST

          if( authorized ) {

            getdata(y++, 0, "�M���ϥΪ̾\\Ū�O�� [N](�Фp�ߨϥ�): ", genbuf, sizeof(genbuf), DOECHO, 0 );
            if(genbuf[0] == 'Y' || genbuf[0] == 'y') {
              sprintf(genbuf,"home/%s/readbits",acct->userid);
              unlink(genbuf);
            }

            sprintf( genbuf, "�W�u���� [%s]: ", acct->numlogins );
            getdata(y++, 0, genbuf, nr.numlogins, sizeof(nr.numlogins), DOECHO, 0 );
            if( nr.numlogins[0] ) BITSET(flags, MOD_LOGNNUM);

            sprintf( genbuf, "�峹�ƥ� [%s]: ", acct->numposts );
            getdata(y++, 0, genbuf, nr.numposts, sizeof(nr.numposts), DOECHO, 0 );
            if( nr.numposts[0] ) BITSET(flags, MOD_POSTNUM);
          }
#endif

          break;

      case '2':
/*
          if (bbs_owninfo(acct) != S_OK) {
              prints("Can't retrieve your passfile record!\n");
              fail++;
              break;
          }
*/
          prints("���e%s�f�ӤH�K�X.\n", acct->userid);
          y++;
          if (!authorized)
          {  
             if (-1 == getdata(y++,0,"�п�J��Ӫ��K�X: ",nr.passwd,sizeof(nr.passwd),NOECHO,1))
             {
                 prints ("�K�X������.\n");
                 fail++;
                 break;
             }
             else if (nr.passwd[0] == '\0' || !is_passwd_good(acct->passwd, nr.passwd)) {
                 prints("\n�K�X��J���~.\n");
                 fail++;
                 break;
             }
          }
          
          getdata(y++,0,"�п�J�s�K�X: ",nr.passwd, sizeof(nr.passwd),NOECHO,0);
          if(!is_valid_password(nr.passwd)) {
              prints("\n�z�ҿ�J���K�X�O���X�k��\n");
              fail++;
          }
          else {
              getdata(y++,0,"�ЦA��J�@���T�{: ",passcfm,sizeof(nr.passwd),NOECHO,0);
              if(strcmp(nr.passwd,passcfm)) {
                  prints("\n�⦸�K�X��J���ۦP,��K�X����.\n");
                  fail++;
              }
              else
                  BITSET(flags, MOD_PASSWD); 
          }

          break;

     default:
         fail++;
         break; 
    }

    if(!fail)
    {
        getdata(t_lines-2, 0, "�T�w���ܶ� (Y/N)? [N]: ", ans, sizeof(ans), DOECHO, 0);
        if (ans[0] == 'Y' || ans[0] == 'y') {    
            rc = bbs_modify_account(acct->userid, &nr, flags);
            if (rc != S_OK) {
                prints("��ƵL�k����.\n");
                fail++;
            }
        }
    } 
    if (fail) 
        pressreturn();
    return (0);

}
