
/*
Eagles Bulletin Board System
Copyright (C) 1994, Ray Rocker, rrrocker@rock.b11.ingr.com
                                rock@seabass.st.usm.edu
                                72673.2105@compuserve.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "oldconfig.h"
#include <sys/types.h>

/* These were in permissions.h of EBBS 2.x */
#define OPERM_SYSOP	040000
#define OPERM_POSTMASK	0100000     /* means the rest is a post mask */

#define OSTRLEN   80    /* Length of most string data */
#define OIDLEN    12    /* Length of userids */
#define OPASSLEN  14    /* Length of encrypted passwd field */

#define OPASSFILE ".PASSWDS"      /* Name of file User records stored in */
#define OBOARDS   ".ALLBOARDS"       /* File containing list of boards */
#define ODIR      "/.DIR"         /* Name of Directory file info */
#define ONAMEFILE "BoardName"     /* File containing site name of bbs */

#define OFILE_READ  0x1        /* Ownership flags in fileheader structure */
#define OFILE_OWND  0x2        /* accessed array */
#define OFILE_VISIT 0x4
#define OFILE_MARKED 0x8

#define OZAPPED	0x1           /* For boards...tells if board is Zapped */

/* these are flags in userec.flags[0] */
#define OPAGER_FLAG 0x1   /* true if pager was OFF last session */
#define OCLOAK_FLAG 0x2   /* true if cloak was ON last session */
#define OVOTE_FLAG 0x4    /* for controlling Votes */
#define OSIG_FLAG 0x8     /* true if sig was turned OFF last session */
#define ONOCLEAN_FLAG 0x10 /* true is user is immune from User Clean */

struct ouserec {                  /* Structure used to hold information in */
	char userid[OIDLEN+2] ;   /* PASSFILE */
	char filler[34];
	char lasthost[16];
	unsigned int numlogins;
	unsigned int numposts;
	char flags[2];
	char passwd[OPASSLEN] ;
	char username[OSTRLEN] ;
	char termtype[OSTRLEN] ;
	unsigned userlevel ;
	time_t lastlogin ;
	int protocol ;
#ifdef REALINFO
	char realname[OSTRLEN-40];
	char address[OSTRLEN];
#endif
	char email[OSTRLEN];
} ;

struct ofileheader {             /* This structure is used to hold data in */
	char filename[OSTRLEN] ;  /* the BOARDS and DIR files               */
	char owner[OSTRLEN] ;
	char title[OSTRLEN] ;
	unsigned level;
	unsigned char accessed[MAXUSERS] ;
} ;
