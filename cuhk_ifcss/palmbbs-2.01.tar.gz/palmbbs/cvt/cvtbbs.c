
/*
Eagles Bulletin Board System
Copyright (C) 1994, Ray Rocker, rrrocker@rock.b11.ingr.com
                                rock@seabass.st.usm.edu
                                72673.2105@compuserve.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "oldbbs.h"
#include "server.h"
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>
#include <grp.h>
#ifdef NeXT
# include <sys/dir.h>
# include <sys/dirent.h>
struct utimbuf {
  time_t  actime;
  time_t  modtime;
};
#else
# include <dirent.h>
# include <utime.h>
#endif
#include <sys/stat.h>
#ifdef NeXT
# define S_ISDIR(mode)   (((mode) & (_S_IFMT)) == (_S_IFDIR))
#endif

/* These are private in files.c, but we need them. */
#define MAIL_READBITS_NAME "$MAIL$"
#define UNMARKED_FILE_MODE  0660
#define MARKED_FILE_MODE    0640

extern char *optarg;
extern int optind;

extern USERDATA user_params;

int mflg;
int tflg;
char *bbsuser = "bbs";
char *bbsgroup = "bbs";
uid_t bbsuid;
gid_t bbsgid;
char *oldroot;
struct ouserec *accts;
struct ofileheader *brds;
int numusers;
int numboards;
char **rbmap;


copy_file(opath, npath, mode)
char *opath;
char *npath;
int mode;
{
  FILE *ofp, *nfp;
  char buf[1024];
  struct stat statb;
  struct utimbuf utbuf;
  ofp = fopen(opath, "r");
  if (ofp == NULL) return -1;
  nfp = fopen(npath, "w");
  if (nfp == NULL) {
    fclose(ofp);
    return -1;
  }
  fstat(fileno(ofp), &statb);
  utbuf.actime = statb.st_atime;
  utbuf.modtime = statb.st_mtime;
  while (fgets(buf, sizeof buf, ofp) != NULL) {
    fputs(buf, nfp);
  }
  fclose(ofp);
  fclose(nfp);
  chmod(npath, mode);
  utime(npath, &utbuf);
  return 0;
}

read_accounts()
{
  PATH opasswds;
  int fd, recnum;
  struct ouserec acctbuf;
  
  numusers = 0;
  recnum = 0;
  sprintf(opasswds, "%s/%s", oldroot, OPASSFILE);
  if ((fd = open(opasswds, O_RDONLY)) == -1) {
    fprintf(stderr, "ERROR: Cannot open passwd file %s\n", opasswds);
    return -1;
  }

  while (read(fd, &acctbuf, sizeof acctbuf) == sizeof acctbuf) {
    if (acctbuf.userid[0] != '\0') {
      if (recnum >= MAXUSERS) {
        fprintf(stderr, "WARNING: too many accounts: %s NOT converted\n", 
                acctbuf.userid);
        continue;
      }
      memcpy(&accts[recnum], &acctbuf, sizeof(accts[recnum]));
      numusers++;
    }
    recnum++;
  }

  close(fd);
  printf("Converting %d accounts\n", numusers);
  return 0;
}

read_boards()
{
  PATH oboards;
  int fd;
  struct ofileheader brdbuf;
  
  numboards = 0;
  sprintf(oboards, "%s/%s", oldroot, OBOARDS);
  if ((fd = open(oboards, O_RDONLY)) == -1) {
    fprintf(stderr, "ERROR: Cannot open boards file %s\n", oboards);
    return -1;
  }

  while (read(fd, &brdbuf, sizeof brdbuf) == sizeof brdbuf) {
    if (brdbuf.filename[0] != '\0') {
      if (numboards >= MAXBOARD) {
        fprintf(stderr, "WARNING: too many boards: %s NOT converted\n", 
                brdbuf.filename);
        continue;
      }
      memcpy(&brds[numboards++], &brdbuf, sizeof(brds[numboards]));
    }
  }

  close(fd);
  printf("Converting %d boards\n", numboards);
  return 0;
}

create_account_extra(oacct, nacct)
struct ouserec *oacct;
ACCOUNT *nacct;
{
  char path[1024];
  PATH newpath;
  int rc;
  struct utimbuf utbuf;
  
  strcpy(user_params.u.userid, "[cvtbbs]");

  if (oacct->userlevel & OPERM_SYSOP) {
    if (tflg) rc = S_OK;
    else rc = local_bbs_modify_perms(nacct->userid, 0x3ff);
    if (rc == S_OK) 
      printf("All permissions given to %s\n", nacct->userid);
    else fprintf(stderr, "ERROR: bbs_modify_perms for %s failed\n", 
		 nacct->userid);
  }    
  
  if (oacct->flags[0] & ONOCLEAN_FLAG) {
    if (tflg) rc = S_OK;
    else rc = local_bbs_toggle_exempt(nacct->userid);
    if (rc == S_OK) 
      printf("%s exempted from userclean\n", nacct->userid);
    else fprintf(stderr, "ERROR: bbs_toggle_exempt for %s failed\n", 
		 nacct->userid);
  }    
    
  if (oacct->flags[0] & OPAGER_FLAG) {
    nacct->flags = FLG_NOPAGE;
    if (tflg) rc = S_OK;
    else rc = _set_account(nacct->userid, nacct, _TOGGLE_FLAGS);
    if (rc == S_OK)
      printf("Pager turned off for %s\n", nacct->userid);
    else fprintf(stderr, "ERROR: bbs_set_pager for %s failed\n", 
		 nacct->userid);
  }    

  strcpy(user_params.u.userid, nacct->userid);

  if (oacct->numlogins > 0) {
    if (tflg) rc = S_OK;
    else {
      HOST lasthost;
      memset(lasthost, 0, sizeof lasthost);
      strncpy(lasthost, oacct->lasthost, 16);
      rc = set_lastlog(nacct->userid, lasthost);
      if (rc == S_OK) {
	get_lastlog_file(nacct->userid, newpath);
	utbuf.actime = utbuf.modtime = oacct->lastlogin;
	utime(newpath, &utbuf);
      }
    }
  }

  sprintf(path, "%s/plans/%s", oldroot, oacct->userid);
  if (access(path, R_OK) == 0) {
    if (tflg) rc = 0;
    else {
      local_bbs_get_plan(nacct->userid, newpath);
      rc = copy_file(path, newpath, 0660);
    }
    if (rc == 0) printf("Plan copied for %s\n", nacct->userid);
    else fprintf(stderr, "ERROR: %s plan copy failed\n", nacct->userid);
  }

  sprintf(path, "%s/signatures/%s", oldroot, oacct->userid);
  if (!(oacct->flags[0] & OSIG_FLAG) && access(path, R_OK) == 0) {
    if (tflg) rc = 0;
    else {
/*      local_bbs_get_signature(newpath);  for M_SIG*/
      local_bbs_get_signature(newpath,1); 
      rc = copy_file(path, newpath, 0660);
    }
    if (rc == 0) printf("Signature copied for %s\n", nacct->userid);
    else fprintf(stderr, "ERROR: %s sig copy failed\n", nacct->userid);
  }

  sprintf(path, "%s/overrides/%s", oldroot, oacct->userid);
  if (access(path, R_OK) == 0) {
    if (tflg) rc = 0;
    else {
      get_override_file(nacct->userid, newpath);
      rc = copy_file(path, newpath, 0660);
    }
    if (rc == 0) printf("Overrides copied for %s\n", nacct->userid);
    else fprintf(stderr, "ERROR: %s overrides copy failed\n", nacct->userid);
  }
  
  return 0;
}      

create_mail(oacct, nacct)
struct ouserec *oacct;
ACCOUNT *nacct;
{
  char maildir[1024];
  char mailindex[1024];
  PATH newmaildir;
  char mailfile[1024];
  PATH newmailfile;
  struct ofileheader oldheader;
  READINFO readinfo;
  int rc, fd, mailcount;

  /* set_readbit_ent requires this */
  strcpy(user_params.u.userid, nacct->userid);

  sprintf(maildir, "%s/mail/%s", oldroot, oacct->userid);
  get_mail_directory(nacct->userid, newmaildir);
  strcpy(mailindex, maildir);
  strcat(mailindex, ODIR);

  mailcount = 0;
  clear_all_readbits(&readinfo);
  
  fd = open(mailindex, O_RDONLY);
  if (fd != -1) {
    while (read(fd, &oldheader, sizeof oldheader) == sizeof oldheader) {
      /* 
	 For simplicity's sake we don't monkey with the mail headers.
         This means the old mail won't have the "To:" header.
         I *think* this will not be a problem.
      */
   /*   if ( !(oldheader.accessed[0] & OFILE_READ) || 
         (!mflg && (oldheader.accessed[0] & OFILE_MARKED))) */ {
	if (mailcount == BBS_MAX_FILES) {
          fprintf(stderr, 
		  "WARNING: %s has too much mail -- excess mail deleted\n",
		  nacct->userid);
	  break;
	}
        sprintf(mailfile, "%s/%s", maildir, oldheader.filename);
        sprintf(newmailfile, "%s/%04x", newmaildir, mailcount+1);
        if (tflg) rc = 0;
        else rc = copy_file(mailfile, newmailfile, UNMARKED_FILE_MODE);
        if (rc == 0) {
          if (oldheader.accessed[0] & OFILE_READ) {
	    set_readbit(&readinfo, (SHORT)(mailcount+1));
          }
          mailcount++;
        }
        else fprintf(stderr, 
		     "ERROR: mail copy of %s to %s failed -- not saved\n",
		     mailfile, newmailfile);
      }
    }
  }
 
  close(fd);

  if (mailcount == 0) 
    printf("No mail messages copied for %s.\n", nacct->userid);
  else
    printf("%d mail messages copied for %s.\n", mailcount, nacct->userid);
  
  readinfo.stamp = (LONG)(time(NULL)+1);

  if (tflg) rc = S_OK;
  else rc = set_bitfile_ent(MAIL_READBITS_NAME, &readinfo);
  if (rc != S_OK) {
    fprintf(stderr, 
	    "ERROR: %s mail : cannot set readbits -- mail will be unread\n",
	    nacct->userid);
  }

  return 0;
}      

create_accounts()
{
  ACCOUNT acct;
  int i, rc;
  for (i=0; i<MAXUSERS; i++) {
    if (accts[i].userid[0] == '\0') continue;
    memset(&acct, 0, sizeof acct);
    strncpy(acct.userid, accts[i].userid, NAMELEN);
    strncpy(acct.passwd, accts[i].passwd, PASSLEN);
    strncpy(acct.username, accts[i].username, UNAMELEN);
    strncpy(acct.terminal, accts[i].termtype, TERMLEN);
    strncpy(acct.email, accts[i].email, MAILLEN);
#if REALINFO
    strncpy(acct.realname, accts[i].realname, RNAMELEN);
    strncpy(acct.address, accts[i].address, ADDRLEN);
#endif
#ifdef NUM_LOGN_POST
    sprintf(acct.numlogins, "%d", accts[i].numlogins);
    sprintf(acct.numposts, "%d", accts[i].numposts);
#endif
    if (tflg) rc = S_OK;
    else rc = local_bbs_add_account(&acct, 1);
    switch (rc) {
    case S_OK:
      printf("Account for %s created\n", acct.userid);
      create_account_extra(&accts[i], &acct);
      create_mail(&accts[i], &acct);
      break;
    case S_INVALID:
      fprintf(stderr, "ERROR: %s: invalid userid or password\n", acct.userid);
      break;
    case S_EXISTS:
      fprintf(stderr, "ERROR: %s: userid already exists\n", acct.userid);
      break;
    case S_SYSERR:
      fprintf(stderr, "ERROR: %s: error creating account\n", acct.userid);
      fprintf(stderr, "       Wrong -d argument or $BBSHOME?\n");
      fprintf(stderr, "       Exiting create_accounts!\n");
      return 1;
    }
    /* If account add failed, take it out of the list for when we go to
       set the readbits for everybody */

    if (rc != S_OK) {
      accts[i].userid[0] = '\0';
    }
  }
}

create_posts(obrd, nbrd)
struct ofileheader *obrd;
BOARD *nbrd;
{
  char boarddir[1024];
  char boardindex[1024];
  PATH newboarddir;
  char postfile[1024];
  PATH newpostfile;
  struct ofileheader oldheader;
  int rc, fd, postcount, filemode;
  int pi, ui, count;
  READINFO readinfo;  

  sprintf(boarddir, "%s/boards/%s", oldroot, obrd->filename);
  get_board_directory(nbrd->name, newboarddir);
  strcpy(boardindex, boarddir);
  strcat(boardindex, ODIR);

  postcount = 0;
  
  fd = open(boardindex, O_RDONLY);
  if (fd != -1) {
    while (read(fd, &oldheader, sizeof oldheader) == sizeof oldheader) {
      if (postcount == BBS_MAX_FILES) {
	fprintf(stderr, 
		"WARNING: %s has too many posts -- excess posts deleted\n",
		nbrd->name);
	break;
      }
      sprintf(postfile, "%s/%s", boarddir, oldheader.filename);
      sprintf(newpostfile, "%s/%04x", newboarddir, postcount+1);
      if (oldheader.accessed[0] & OFILE_MARKED)
	filemode = MARKED_FILE_MODE;
      else filemode = UNMARKED_FILE_MODE;

      if (tflg) rc = 0;
      else rc = copy_file(postfile, newpostfile, filemode);
      if (rc == 0) {
	if (rbmap[postcount] == NULL) {
	  if ((rbmap[postcount] = (char *)calloc(MAXUSERS, 1)) == NULL) {
	    fprintf(stderr, "ERROR: %s: not enough memory for all readbits\n",
		    nbrd->name);
	  }
	}
	if (rbmap[postcount] != NULL) 
	  memcpy(rbmap[postcount], oldheader.accessed, MAXUSERS);

	postcount++;
      }
      else {
	fprintf(stderr, 
		"ERROR: post copy of %s to %s failed -- not saved\n",
		postfile, newpostfile);
      }
    }
  }
 
  close(fd);

  if (postcount == 0) 
    printf("No posts copied for %s.\n", nbrd->name);
  else
    printf("%d posts copied for %s.\n", postcount, nbrd->name);
  
  /*
     Here, take our big ass matrix and read it by columns, setting
     the readbits for each user with what we find. Also do the zap thing.
     This will be really slow.
  */
  
  printf("Setting readbits for board '%s'.\n", nbrd->name);
    
  /* 
     EBBS 2.x bug: read bits and zap bits are not set properly for the
     last user in the userlist. So they will just have to do a Visit.
  */
  for (ui=0; ui<(MAXUSERS-1); ui++) {
    if (accts[ui].userid[0] == '\0') continue;
    strncpy(user_params.u.userid, accts[ui].userid, NAMELEN);
    clear_all_readbits(&readinfo);
    count = 0;
    for (pi=0; pi<=postcount; pi++) {
      if (rbmap[pi] != NULL && rbmap[pi][ui+1] & OFILE_READ) {
        set_readbit(&readinfo, (SHORT)(pi+1));
	count++;
      }
    }
    if (tflg || !count) rc = S_OK;
    else {
      readinfo.stamp = (LONG)(time(NULL)+1);
      rc = set_bitfile_ent(nbrd->name, &readinfo);
    }
    if (rc != S_OK) {
      fprintf(stderr, 
              "ERROR: %s board : cannot set readbits for %s\n",
	      nbrd->name, user_params.u.userid);
    }
    if ((ui != MAXUSERS-1) && (obrd->accessed[ui+1] & OZAPPED)) {
      if (tflg) rc = S_OK;
      else rc = local_bbs_zap_board(nbrd->name, 1);
      if (rc == S_OK)
        printf("%s has board %s zapped\n", user_params.u.userid, nbrd->name);
      else
        fprintf(stderr, "ERROR: zap %s for %s failed\n", nbrd->name,
		user_params.u.userid);
    }
  }

  return 0;
}      

create_boards()
{
  int i, rc, postp;
  BOARD brd;
  for (i=0; i<numboards; i++) {
    memset(&brd, 0, sizeof brd);
    strncpy(brd.name, brds[i].filename, NAMELEN);
    strncpy(brd.description, brds[i].title, TITLELEN);

    postp = brds[i].level & OPERM_POSTMASK;
    brds[i].level &= ~OPERM_POSTMASK;
    if (brds[i].level) {
      if (postp) {
        printf("Board %s post restricted to Sysops\n", brd.name);
        brd.postmask = PERM_SYSOP;
      }
      else {
	printf("Board %s read restricted to Sysops\n", brd.name);
        brd.readmask = PERM_SYSOP;
      }
    }

    if (tflg) rc = S_OK;
    else rc = local_bbs_add_board(&brd);
    switch (rc) {
    case S_OK:
      printf("Board %s created\n", brd.name);
      create_posts(&brds[i], &brd);
      break;
    case S_INVALID:
      fprintf(stderr, "ERROR: %s: invalid board name\n", brd.name);
      break;
    case S_EXISTS:
      fprintf(stderr, "ERROR: %s: board already exists\n", brd.name);
      break;
    case S_SYSERR:
      fprintf(stderr, "ERROR: %s: error creating board\n", brd.name);
      fprintf(stderr, "       Wrong -d argument or $BBSHOME?\n");
      fprintf(stderr, "       Exiting create_boards!\n");
      return 1;
    }
  }
}

miscellaneous()
{
  int rc, ui;
  char oldf[1024], buf[256];
  NAME userid;
  PATH stats, newf;
  FILE *fp;

  memset(userid, 0, sizeof userid);
  strcpy(stats, "etc/userstats");
  if (tflg) rc = 0;
  else rc = ((fp = fopen(stats, "w")) == NULL);

  if (rc != 0) {
    fprintf(stderr, "ERROR: cannot open %s to save stats\n", stats);
  }
  else {
    for (ui=0; ui<=MAXUSERS; ui++) {
      if (accts[ui].userid[0] == '\0') continue;
      strncpy(userid, accts[ui].userid, NAMELEN);
      if (!tflg) fprintf(fp, "%s %d %d\n", userid, 
              accts[ui].numlogins, accts[ui].numposts);
    }
    if (!tflg) fclose(fp);
    chmod(stats, 0644);
    printf("Login/post stats saved to %s\n", stats);
  }

  sprintf(oldf, "%s/Welcome", oldroot);
  if (access(oldf, R_OK) == 0) {
    strcpy(newf, "etc/welcome");
    if (tflg) rc = S_OK;
    else rc = copy_file(oldf, newf, 0644);
    if (rc == S_OK) 
      printf("Welcome screen copied to %s.\n", newf);
    else 
      fprintf(stderr, "ERROR: could not copy Welcome to etc.\n");
  }

  sprintf(oldf, "%s/etc/issue", oldroot);
  if (access(oldf, R_OK) == 0) {
    strcpy(newf, "etc/issue");
    if (tflg) rc = S_OK;
    else rc = copy_file(oldf, newf, 0644);
    if (rc == S_OK) 
      printf("Issue file copied to %s.\n", newf);
    else 
      fprintf(stderr, "ERROR: could not copy issue file to etc.\n");
  }

  sprintf(oldf, "%s/vote/results", oldroot);
  if (access(oldf, R_OK) == 0) {
    strcpy(newf, "etc/vote.results");
    if (tflg) rc = S_OK;
    else rc = copy_file(oldf, newf, 0644);
    if (rc == S_OK) 
      printf("Vote results copied to %s.\n", newf);
    else 
      fprintf(stderr, "ERROR: could not copy vote/results to etc.\n");
  }

  return 0;
}

usage(prog)
char *prog;
{
  fprintf(stderr, "Usage: %s [-d bbs-dir] [-u user] [-g group] [-m] [-t] old-bbs-root\n", prog);
  fprintf(stderr, "       -d bbs-dir specifies new bbs home directory\n");
  fprintf(stderr, "       -u user specifies the bbs username (default bbs)\n");
  fprintf(stderr, "       -g group specifies the bbs group (default bbs)\n");
  fprintf(stderr, "       -m causes marked+read mail to be thrown out\n");
  fprintf(stderr, "       -t is test mode: only shows what would be done\n");
}

recursive_chown(dir)
char *dir;
{
  PATH fname;
  DIR *dp;
  struct dirent *dent;
  struct stat stbuf;

  if ((dp = opendir(dir)) == NULL) {
    return -1;
  }
              
  while ((dent = readdir(dp)) != NULL) {
    if (!strcmp(dent->d_name, ".") || !strcmp(dent->d_name, ".."))
      continue;
    sprintf(fname, "%s/%s", dir, dent->d_name);
    if (stat(fname, &stbuf) == 0) {
      if (S_ISDIR(stbuf.st_mode)) recursive_chown(fname);
      else chown(fname, bbsuid, bbsgid);
    }
  }

  closedir(dp);
  chown(dir, bbsuid, bbsgid);
  return 0;
}

main(argc, argv)
int argc;
char *argv[];
{
  char *bbshome = NULL;
  struct passwd *pw;
  struct group *gr;
  int c;

  while ((c = getopt(argc, argv, "d:g:mtu:?")) != -1)
    {
      switch (c)
	{
	case 'd':
	  bbshome = optarg;
	  break;
	case 'g':
	  bbsgroup = optarg;
	  break;
	case 'm':
	  mflg++;
	  break;
	case 't':
	  tflg++;
	  break;
	case 'u':
	  bbsuser = optarg;
	  break;
	case '?':
	  usage(argv[0]);
	  return 2;
	}
    }

  if (optind > argc-1) {
    usage(argv[0]);
    return 2;
  }

  oldroot = argv[optind];

  if (getuid() != 0) {
    fprintf(stderr, "%s: Must be superuser to run this program\n", argv[0]);
    return 1;
  }

  if ((pw = getpwnam(bbsuser)) == NULL) {
    fprintf(stderr, "%s: User '%s' does not exist (see -u flag)\n",
	    argv[0], bbsuser);
    return 1;
  }
  bbsuid = pw->pw_uid;

  if ((gr = getgrnam(bbsgroup)) == NULL) {
    fprintf(stderr, "%s: Group '%s' does not exist (see -g flag)\n",
	    argv[0], bbsgroup);
    return 1;
  }
  bbsgid = gr->gr_gid;

  if (home_bbs(bbshome) == -1) {
    fprintf(stderr, "%s: Cannot chdir to %s\n", argv[0], bbshome);
    return 1;
  }

  accts = (struct ouserec *)calloc(MAXUSERS, sizeof(struct ouserec));
  if (accts == NULL) {
    fprintf(stderr, "%s: Not enough memory!\n", argv[0]);
    return 1;
  }

  brds = (struct ofileheader *)calloc(MAXBOARD, sizeof(struct ofileheader));
  if (brds == NULL) {
    fprintf(stderr, "%s: Not enough memory!\n", argv[0]);
    return 1;
  }

  rbmap = (char **)calloc(BBS_MAX_FILES, sizeof(char *));
  if (rbmap == NULL) {
    fprintf(stderr, "%s: Not enough memory!\n", argv[0]);
    return 1;
  }

  user_params.perms = ~0;
  umask(007);

  if (tflg) {
    printf("TEST MODE -- the new bbs will not be created\n");
  }
  if (mflg) {
    printf("MAIL -- marked, read mail will NOT be saved\n");
  }
  printf("ALL FILES will by owned by user '%s', group '%s'\n", 
	 bbsuser, bbsgroup);  

  read_accounts();
  create_accounts();
  read_boards();
  create_boards();

  miscellaneous();
  recursive_chown(".");

  printf("BBS CONVERSION COMPLETE\n");
  return 0;
}    
