main()
{    int i; 
     char buf[80];
     for(i=2000;i<2500;i++) {
         sprintf(buf,"addacct -i %c%d -p nopasswd",i%26+'a',i);
         system(buf);
     }
}
