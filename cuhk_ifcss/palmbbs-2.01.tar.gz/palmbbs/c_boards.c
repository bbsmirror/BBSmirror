
/*
Eagles Bulletin Board System
Copyright (C) 1994, Ray Rocker, rrrocker@rock.b11.ingr.com
                                rock@seabass.st.usm.edu
                                72673.2105@compuserve.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "client.h"
#include <time.h>
#include <stdlib.h>

#ifdef SHOW_BM
static char Show_BM = 0;
#endif

#ifdef B_GROUP
long EGroupStat;
char EGroupMode;
#endif

/* The currently selected board */
NAME currboard;
NAMELIST boardlist;
#ifdef CSIE_ANNOUNCE
TITLE currbtitle;
#endif


/* stuff in c_users.c for the permission mask setting */
extern LONG SetPermMenu __P((LONG));

CheckBoardName(bname)
char *bname;
{
  BOARD buf;
  if (bname[0] == '\0') return 1;
  if (!is_valid_boardname(bname)) return 3;
  if (bbs_get_board(bname, &buf) != S_NOTFOUND) return 2; 
  return 0;
}

#ifndef STRIP_OUT

/*ARGSUSED*/
AllBoardsFunc(indx, board, info)
int indx;
BOARD *board;
struct enum_info *info;
{
  if (info->topline == info->currline) {
    move(info->topline-1, 0);
    prints(" %-16s   %-58s\n", "Name", "Description");
  }

  prints("%c%-15s %c%c %d %d %s\n", 
	 BITISSET(board->flags, BOARD_ZAPPED) ? '*' : ' ',
	 board->name, 
	 board->readmask ? 'R' : ' ',
	 board->postmask ? 'P' : ' ',

	board->bgroupmask,
	EGroupStat,

	 board->description);

  info->currline++;
  info->count++;

  if (info->currline > info->bottomline) {
    int ch;
    standout();
    prints("--MORE--");
    standend();
    clrtoeol();
    while((ch = igetch()) != EOF) {
      if(ch == '\n' || ch == '\r' || ch == ' ')
	break;
      if(toupper(ch) == 'Q') {
	move(info->currline, 0);
	clrtoeol();
	return ENUM_QUIT;
      }
      else bell();
    }
    info->currline = info->topline;
  }
  return S_OK;
}

#endif /* not STRIPOUT */

#ifdef CURSOR_BOARDS
int numboards;
BOARD *bcache[200];

Boards()
{
#define RMVCSR { move(4+nthboard%pagesize,0); prints("   "); }
  struct enum_info info;
  static int yank=0;
  int nthboard,i,pagenum=0,redraw=1,pagesize=(t_lines-5); 
  int ch;
  int j;
#ifdef SEARCH_BOARD
  char buf[20];
#endif

#ifdef SHOW_BM
  NAMELIST mgrlist = NULL;
#endif

#ifdef DETAILED_USERMODE
  bbs_set_mode(SHOW);
#endif

#ifdef GUEST_NO_PASSWORD
  if( !_has_perms(PERM_BASIC1)) yank=1;
#endif

read_again:

  pagenum=0;
  nthboard=0;
  numboards=0;
  redraw=1;
  if(yank) bbs_cursor_enum_boards(BE_ALL);
  else bbs_cursor_enum_boards(BE_UNZAPPED);

#ifdef VOTE
  for(i=0; i<numboards; i++) {
     if( exist_polls(bcache[i]->name))
	bcache[i]->flags |= BOARD_VOTE;
     else
	bcache[i]->flags &= ~BOARD_VOTE;
  }
#endif

#ifdef B_GROUP
  if(numboards == 0) {
     clear();
     move(10,25);
     prints("�����s�եثe�L�Q�װϥi�\\Ū��");
     pressreturn();
            i=0;
            while(bcache[i])
            {   free(bcache[i]); /* free allocated memory */
                bcache[i]=0;
                i++;
            }
     return FULLUPDATE;
   }
#endif

  while(redraw!=-1) {
    if(redraw) {
         extern BBSINFO serverinfo ;
	 clear();
         prints("%s",serverinfo.boardname) ;
         move(0, t_columns/3*2);
         if (currboard[0] == '\0') prints("�ثe�|����ܰQ�װ�");
         else prints("�ثe�Q�װ�: %s", currboard);
	 move(2,0); clrtoeol();
	 move(1,0); clrtoeol();
	 move(1,0); prints("�ХΡ��B���� [ENTER] ��ܤ@�ӰQ�װϡA�Υ�'/'�M��");
         if (bbs_check_mail()) {
             move(0, t_columns/3);
             prints("�e���A���H��f");
         }
    }
  
    if(redraw || (nthboard / pagesize != pagenum)) {
	 move(3,0); clrtobot();
	 standout();
/*
#ifdef SHOW_BM
	 if( Show_BM)
	     prints("     %-16s   %s\n", "�Q�װϦW��", "�Q�װϪA�ȥ�");
	 else 
#endif
*/
    	 prints("     %-12s   %-34s %s %-17s\n", "�Q�װϦW��", "�Q�װ�²��","�벼","�Q�װϪA�ȥ�");
	 standend();
	 pagenum=nthboard/pagesize;

         for(i=pagenum*pagesize; i<(pagenum+1)*pagesize && i<numboards; i++) {

/*
#ifdef SHOW_BM
  if( Show_BM) {
             prints("    %c%-13s %c%c",
                BITISSET(bcache[i]->flags, BOARD_ZAPPED) ? '*' : ' ',
                bcache[i]->name,
                bcache[i]->readmask ? 'R' : ' ',
                bcache[i]->postmask ? 'P' : ' ');
      if (bbs_get_boardmgrs(bcache[i]->name, &mgrlist) == S_OK) {
         for(; mgrlist!=NULL; mgrlist=mgrlist->next) {
	     prints(" %s",mgrlist->word);
         }
      }
      free_namelist(&mgrlist);
      prints("\n");
  } else
#endif
*/
             prints("   %c%-12s %c%c %-38s",
      	     	BITISSET(bcache[i]->flags, BOARD_ZAPPED) ? '*' : ' ',
       	     	bcache[i]->name,
             	bcache[i]->readmask ? 'R' : ' ',
             	bcache[i]->postmask ? 'P' : ' ',
             	bcache[i]->description);
#ifdef VOTE
            prints("%c ", BITISSET(bcache[i]->flags, BOARD_VOTE) ? 'V' : ' ');
/*	    if( check_polls(bcache[i]->name, NULL, NULL))
		prints("V ");
	    else
		prints("  "); */
#endif
#ifdef SHOW_BM
	     if (bbs_get_boardmgrs(bcache[i]->name, &mgrlist) == S_OK) {
		Show_BM = 0;
#ifndef NAMELIST_IN_ARRAY
		for(; mgrlist!=NULL; mgrlist=mgrlist->next) {
		   Show_BM += strlen(mgrlist->word)+1;
		   if( Show_BM > 18) {
		      prints(" ��");
		      break;
		   }
		   prints(" %s",mgrlist->word);
		}
#else
		j=0;
		while(mgrlist[j][0]) {
		   Show_BM += strlen(mgrlist[j])+1;
                   if( Show_BM > 18) {
                      prints(" ��");
                      break;
                   }
                   prints(" %s",mgrlist[j]);
		   j++;
                }
#endif
	     }
	     free_namelist(&mgrlist);
	     prints("\n");
#endif
	 }
	 move(t_lines-1,0);
	 if(i<numboards) 
	 {   standout();
	     prints("-- ���� --");
	     standend();
	 }
	 else clrtoeol();
    }
    redraw=0;

    move(4+nthboard%pagesize,0); prints(" ��");
    move(0,79);

    ch = igetch();
    switch(ch) {
#ifdef SEARCH_BOARD
	case 's':
	case '/':
	    RMVCSR
	    getdata( 2,0,"�п�J�n�䪺�Q�װϦW�١G", buf, 19, DOECHO, NULL);
	    move(2,0); clrtoeol();
	    if( buf[0] != '\0') {
	       if( nthboard+1 < numboards ) i=nthboard+1; else i=0;
	       while( i!= nthboard) {
		  if( strncasecmp(bcache[i]->name,buf,strlen(buf)) == 0) {
	             nthboard=i;
		     break;
		  }
	          if(++i >= numboards) i=0;
	       }
	    }
	    break;
#endif

#ifdef SHOW_BM
	case KEY_TAB:
	    Show_BM = !Show_BM;
	    redraw=1;
	    break;
#endif
	case 'p':
	case 'k':
	case KEY_UP:
	    RMVCSR
	    if(nthboard==0) nthboard=numboards-1;
	    else nthboard--;
	    break;
	case 'n':
	case 'j':
	case KEY_DOWN:
	    RMVCSR
	    if(nthboard==numboards-1) nthboard=0;
	    else nthboard++;
	    break;
	case '\n':
	case '\r':
	case KEY_RIGHT:
	    strcpy( currboard, bcache[nthboard]->name);
#ifdef CSIE_ANNOUNCE
            strcpy(currbtitle,bcache[nthboard]->description);
#endif
	    MainRead();
#ifdef DETAILED_USERMODE
           bbs_set_mode(SHOW);
#endif
	    redraw=1;
	    break;
	case 'q':
	case 'e':
	case KEY_LEFT:
	    i=0;
	    while(bcache[i]) 
	    {	free(bcache[i]); /* free allocated memory */
		bcache[i]=0;
		i++;
	    }
	    redraw=-1; /* means end the while loop */
	    break;
        case ' ':
	case 'N':
	case KEY_PGDN:
	    RMVCSR
	    if(pagenum==(numboards-1)/pagesize) {  /* in the last page */
		nthboard%=pagesize;           /* to the first page */
	    } 
	    else {
	 	nthboard+=pagesize;
	    	if(nthboard>=numboards) nthboard=numboards-1;
	    }
	    break;
	case 'P':
	case KEY_PGUP:
	    RMVCSR
	    if(nthboard<pagesize)   /* in the first page */
	    {	nthboard=(numboards/pagesize)*pagesize+nthboard; /* the */
		if(nthboard>=numboards) nthboard=numboards-1; /* last page */
	    }
	    else nthboard-=pagesize;
	    break;
	case 'y':
	    yank= !yank;
	    goto read_again;
	    break;
	case 'z':
	    {	int notzapped;
 		notzapped = !BITISSET(bcache[nthboard]->flags, BOARD_ZAPPED);
  		if(bbs_zap_board(bcache[nthboard]->name, notzapped) == S_OK)
		{    BITTOGGLE(bcache[nthboard]->flags,BOARD_ZAPPED); 
	 	     move(4+nthboard%pagesize,0);
		     prints("   %c", notzapped ? '*':' ');
		}
	    }
	    break;
      }
    }
  free_namelist(&mgrlist);
  return FULLUPDATE;
}
#else  /* CURSOR_BOARDS */

Boards()
{
  struct enum_info info;
  info.count = 0;
  info.topline = info.currline = 4;
  info.bottomline = t_lines-2;
  move(3,0);
  clrtobot();    
  bbs_enum_boards(t_lines-5, BE_ALL, AllBoardsFunc, &info);
  clrtobot();
  move(t_lines-1, 0);
  prints("�@��ܤF %d �ӰQ�װ�", info.count);
  keep_prev_display();
  return PARTUPDATE;
}
#endif /* CURSOR_BORDS */

#ifdef B_GROUP
EGroup( BoardGroup)
char* BoardGroup;
{
  EGroupMode = 1;
  EGroupStat = hex2LONG(BoardGroup);

  Boards();

  EGroupMode = 0;
  return FULLUPDATE;
}

EBoards( BoardGroup)
char* BoardGroup;
{
  EGroupStat = hex2LONG(BoardGroup);

  return Boards();
}
#endif /* B_GROUP */

/*ARGSUSED*/
BoardCountsFunc(indx, board, info)
int indx;
BOARD *board;
struct enum_info *info;
{
  if (info->topline == info->currline) {
    move(info->topline-1, 0);
    prints(" %-16s   %6s %6s   %-30s\n", "Board", 
           "Total", "Unread", "Last Post");
  }

  prints("%c%-16s   %6d %6d   %s", 
	 BITISSET(board->flags, BOARD_ZAPPED) ? '*' : ' ',
	 board->name, 
	 board->totalposts,
       	 board->newposts,
	 (board->lastpost == 0 ? "\n" : ctime((time_t *)&board->lastpost)));

  info->currline++;
  info->count++;
  info->totals[0] += board->totalposts;
  info->totals[1] += board->newposts;

  if (info->currline > info->bottomline) {
    int ch;
    standout();
    prints("--MORE--");
    standend();
    clrtoeol();
    while((ch = igetch()) != EOF) {
      if(ch == '\n' || ch == '\r' || ch == ' ')
	break;
      if(toupper(ch) == 'Q') {
	move(info->currline, 0);
	clrtoeol();
	return ENUM_QUIT;
      }
      else bell();
    }
    info->currline = info->topline;
  }
  return S_OK;
}

BoardCounts()
{
  struct enum_info info;
  SHORT flags;
  char ans[9];
  info.count = 0;
  info.topline = info.currline = 4;
  info.bottomline = t_lines-2;
  info.totals[0] = info.totals[1] = 0;
    
#ifdef DETAILED_USERMODE
  bbs_set_mode(CNTBRDS);
#endif

  move(3,0);
  clrtobot();
  if (getdata(3, 0, "(U)nzapped only, (Z)apped only, or (A)ll? [U]: ",
          ans, sizeof ans, DOECHO, 1) == -1) return FULLUPDATE;

  if (*ans == 'Z' || *ans == 'z') flags = BE_ZAPPED;
  else if (*ans == 'A' || *ans == 'a') flags = BE_ALL;
  else flags = BE_UNZAPPED;

  flags |= BE_DO_COUNTS;
  bbs_enum_boards(t_lines-5, flags, BoardCountsFunc, &info);
  
  clrtobot();
  move(info.currline, 0);

  prints(" %-16s   %6d %6d\n", "*** TOTALS ***", 
         info.totals[0], info.totals[1]);

  keep_prev_display();
  return PARTUPDATE;
}

SelectBoard()
{
  NAME newboard;
#ifdef DETAILED_USERMODE
  bbs_set_mode(SELECT);
#endif
  move(2,0);
  clrtobot();
  bbs_boardnames(&boardlist);
  if (boardlist == NULL) {
    prints("�S���i�ѿ�ܪ��Q�װ�.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&boardlist);
#endif
    return FULLUPDATE;
  }
  namecomplete(boardlist, "�п�J�Q�װϦW��: ", newboard);
  if (newboard[0] == '\0') return FULLUPDATE;
  else if (!is_in_namelist(boardlist, newboard)) {
    move(4,0);
    prints("�o�ӰQ�װϦW�٬O���~��.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&boardlist);
#endif
    return FULLUPDATE;
  }
  strcpy(currboard, newboard);
#ifdef CSIE_ANNOUNCE
  {  BOARD board;
     if( bbs_get_board(currboard, &board) != S_NOTFOUND)
        strcpy(currbtitle, board.description);
   }
#endif
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&boardlist);
#endif
  return (FULLUPDATE | NEWDIRECT);
}

Zap()
{
  NAME zapboard;
  BOARD brec;
  SHORT notzapped;
  move(2,0);
  bbs_boardnames(&boardlist);
  namecomplete(boardlist, "�п�J���]�w Ū/��Ū ���Q�װϦW��: ", zapboard);
  if (zapboard[0] == '\0') return PARTUPDATE;
  if (!is_in_namelist(boardlist, zapboard) || 
      bbs_get_board(zapboard, &brec) != S_OK) {
    move(4,0);
    prints("�o�ӰQ�װϦW�٬O���~��.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&boardlist);
#endif
    return FULLUPDATE;
  }
  notzapped = !BITISSET(brec.flags, BOARD_ZAPPED);
  if (bbs_zap_board(brec.name, notzapped) == S_ILLEGAL) {
    move(3,0);
    prints("'%s' ���Q�װϵL�k�Q�]�w.\n", brec.name);
  }
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&boardlist);
#endif
  return PARTUPDATE;
}

Visit()
{
  NAME visitboard;
  char ans[4];
  int code;
  move(2,0);
  clrtobot();
  bbs_boardnames(&boardlist);
  add_namelist(&boardlist, "*", NULL);
  namecomplete(boardlist, "�п�J�Q�װϦW�� (* = �Ҧ��ثe�iŪ���Q�װ�): ", visitboard);
  remove_namelist(&boardlist, "*");
  if (visitboard[0] == '\0') return FULLUPDATE;
  else if (visitboard[0] != '*' && !is_in_namelist(boardlist, visitboard)) {
    move(4,0);
    prints("�o�ӰQ�װϦW�٬O���~��.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&boardlist);
#endif
    return FULLUPDATE;
  }
  getdata(3,0,"�T�w�� (Y/N)? [N]: ", ans, sizeof(ans), DOECHO, 0);
  move(4,0);
  if (*ans != 'Y' && *ans != 'y') {
    prints("�����Х�.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&boardlist);
#endif
    return FULLUPDATE;
  }
  /* this can take a while, so...*/
  prints("�{�b���b�Хܤ�...");
  refresh();
  code = bbs_visit_board(visitboard);
  if (code == S_OK) prints("�Хܧ���!\n");
  else prints("�䤣�� '%s' ���Q�װ� (?).\n", visitboard);
  pressreturn();
#ifdef NAMELIST_IN_ARRAY
  free_namelist(&boardlist);
#endif
  return FULLUPDATE;
}

SetBoardPerms(brec, postp)
BOARD *brec;
int postp;
{
  LONG newperms;
  move(2,0);
  clrtobot();
  prints("Set the %s permissions for board '%s'\n", 
	 (postp ? "post" : "read"), brec->name);
  newperms = SetPermMenu(postp ? brec->postmask : brec->readmask);	
  clear();
  if (newperms != (postp ? brec->postmask : brec->readmask)) {
    if (postp) brec->postmask = newperms;
    else brec->readmask = newperms;
    return 0;
  }
  else return -1;
}

AddBoard()
{
#ifdef B_GROUP
  char BoardGroup[10];
#endif
  BOARD board;
  int y, grok;
  int rc;
  char ans[4];
  move(3,0);
  clrtobot();
  memset(&board, 0, sizeof(BOARD));
  do {
    if (getdata(3,0,"�п�J�Q�װϦW��: ",board.name,NAMELEN+1,DOECHO,1)==-1)
      return FULLUPDATE;

    grok = CheckBoardName(board.name);
    switch (grok) {
    case 1: prints("�z������J�@�ӰQ�װϦW��, �Э��s��J.\n");
      break;
    case 2: prints("���Q�װϦW�٭���, �Э��s��J.\n");
      break;
    case 3: prints("���Q�װϦW�٬O���~��, �Э��s��J.\n");
    }
  } while (grok);
  getdata(4,0,"�п�J�Q�װ�²��: ", board.description, TITLELEN+1, DOECHO, 0);
#ifdef B_GROUP
  move(3,0);
  prints("�� 1 �� bit �� 2 �ɬ��x�j�Q�װϡA 2�B3 bit ���|����\n");
  getdata(4,0,"E-Group? [10000000]: ", BoardGroup, 9, DOECHO, 0);
  if( BoardGroup[0] == '\0' || (board.bgroupmask=hex2LONG(BoardGroup)) == 0)
     board.bgroupmask = 0x010000000;
#endif
  getdata(6,0,"�]�w�\\Ū���Q�װϪ����� (Y/N)? [N]: ",ans,sizeof(ans),DOECHO,0);
  if (*ans == 'Y' || *ans == 'y') {
    SetBoardPerms(&board, 0);
    y = 0;
  }
  else y = 7;
  getdata(y,0,"�]�w�b���Q�װϵo���峹������ (Y/N)? [N]: ",ans,sizeof(ans),DOECHO,0);
  if (*ans == 'Y' || *ans == 'y') {
    SetBoardPerms(&board, 1);
    y = 0;
  }
  else y = 8;
  getdata(y,0,"�T�w�n�W�[���Q�װ� (Y/N)? [N]: ",ans,sizeof(ans),DOECHO,0);
  if (*ans != 'Y' && *ans != 'y') {
    prints("���W�[���Q�װ�.\n");
  }
  else {
    if ((rc = bbs_add_board(&board)) == S_OK) {
      prints("'%s' �Q�װϤw�g�Q�[�J�F.\n", board.name);
    }
    else prints("�W�[���Q�װϥ���.\n");
  }
  pressreturn();
  return FULLUPDATE;
}

DeleteBoard()
{
  NAME namebuf;
  char ans[4];
  move(2,0);
  clrtobot();
  bbs_boardnames(&boardlist);
  namecomplete(boardlist, "�п�J�n�R�����Q�װϦW��: ", namebuf);        
  if (namebuf[0] == '\0') return FULLUPDATE;
  else if (!is_in_namelist(boardlist, namebuf)) {
    prints("���Q�װϦW�ٿ��~.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&boardlist);
#endif
    return FULLUPDATE;
  }
  prints("'%s' �Q�װϱN�Q�R��.\n", namebuf);
  getdata(5,0,"�T�w�n�R���� (Y/N)? [N]: ",ans,sizeof(ans), DOECHO, 0);    
  if (ans[0] != 'Y' && ans[0] != 'y') {
    prints("���R�����Q�װ�.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&boardlist);
#endif
    return FULLUPDATE;
  }
  if (bbs_delete_board(namebuf) == S_OK)
    prints("'%s' �Q�װϤw�g�Q�R���F.\n", namebuf);
  else
    prints("�R�����Q�װϥ���.\n");
  pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&boardlist);
#endif
  return FULLUPDATE;
}

ChangeBoard()
{
#ifdef B_GROUP
  char BoardGroup[10];
#endif
  NAME namebuf, oldname;
  BOARD brec;
  int rc;
  int y, grok;
  SHORT flags = 0;
  char ans[4];
  move(2,0);
  clrtobot();
  bbs_boardnames(&boardlist);
  namecomplete(boardlist, "�п�J�n��諸�Q�װϦW��: ", namebuf);
  if (namebuf[0] == '\0') return FULLUPDATE;
  else if (!is_in_namelist(boardlist, namebuf)) {
    prints("���Q�װϦW�ٿ��~.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&boardlist);
#endif
    return FULLUPDATE;
  }
  if ((rc = bbs_get_board(namebuf, &brec)) != S_OK) {
    prints("���Q�װϦW�ٿ��~.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&boardlist);
#endif
    return FULLUPDATE;
  }
  strncpy(oldname, brec.name, NAMELEN);
  move(3,0);
  clrtobot();
  move(4,0);
  prints("�Q�װϦW��: %s\n", brec.name);
  prints("�Q�װ�²��: %s\n", brec.description);
  prints("�Х� (M)anagers �d��/��惡�Q�װϪO�D�W��.\n");
  if (brec.readmask) prints("���Q�װϦ��]�w�\\Ū������.\n");
  if (brec.postmask) prints("���Q�װϦ��]�w�o���峹������.\n");

#ifdef CACHED_OPENBOARD
  getdata(9,0,"�O�_���s�״_�Q�װ�[N]: ", ans, sizeof ans, DOECHO, 0);
  if (*ans == 'Y' || *ans == 'y') {
    char tmpcachepath[40];
    sprintf(tmpcachepath,".bcache/%s",brec.name);
    unlink(tmpcachepath);
#ifdef CACHED_HEADERS
    sprintf(tmpcachepath,".headers/%s",brec.name);
    unlink(tmpcachepath);
#endif
  }
#endif
  do {
    getdata(9,0,"�s�Q�װϦW��(�� ENTER �������): ", 
	    namebuf, NAMELEN+1, DOECHO, 0);
    grok = CheckBoardName(namebuf);
    switch (grok) {
    case 0: BITSET(flags, MOD_BNAME);
      strncpy(brec.name, namebuf, sizeof(brec.name));
      break;
    case 1: grok = 0;
      break;
    case 2: prints("���Q�װϦW�٭���, �Э��s��J.\n");
      break;
    case 3: prints("���Q�װϦW�ٿ��~, �Э��s��J.\n");
    }
  } while (grok);
  getdata(10,0,"�s�Q�װ�²��(�� ENTER �������): ", brec.description, TITLELEN,
	  DOECHO, 0);
  if (brec.description[0] != '\0') BITSET(flags, MOD_BOARDDESC);
#ifdef B_GROUP
  move(11,0);
  prints("�� 1 �� bit �� 2 �ɬ��x�j�Q�װϡA 2�B3 bit ���|����\n");
  getdata(12,0,"�s E-Group(�� ENTER �������): ", BoardGroup, 9, DOECHO, 0);
  if( BoardGroup[0] != '\0' && hex2LONG(BoardGroup) != 0) {
     brec.bgroupmask = hex2LONG(BoardGroup);
     BITSET(flags, MOD_BGROUPMASK);
  }
#endif
  getdata(13,0,"�]�w�\\Ū���Q�װϪ����� (Y/N)? [N]: ",
          ans,sizeof(ans),DOECHO,0);
  if (*ans == 'Y' || *ans == 'y') {
    if (SetBoardPerms(&brec, 0) != -1)
      BITSET(flags, MOD_READMASK);
    y = 0;
  }
  else y = 14;
  getdata(y,0,"�]�w�b���Q�װϵo���峹������ (Y/N)? [N]: ",
          ans,sizeof(ans),DOECHO,0);
  if (*ans == 'Y' || *ans == 'y') {
    if (SetBoardPerms(&brec, 1) != -1)
      BITSET(flags, MOD_POSTMASK);
    y = 0;
  }
  else y = 16;
  getdata(y,0,"�T�w�n���H�W����� (Y/N)? [N]: ",ans,sizeof(ans),
	  DOECHO,0);
  if (*ans != 'Y' && *ans != 'y') {
    prints("����惡�Q�װ�.\n");
  }
  else {
    rc = bbs_modify_board(oldname, &brec, flags);
    if (rc == S_OK) prints("'%s' �Q�װϤw�g�Q���F.\n", oldname);
    else prints("��惡�Q�װϥ���.\n");
  }
  pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&boardlist);
#endif
  return FULLUPDATE;
}

