/*
Eagles Bulletin Board System
Copyright (C) 1994, Ray Rocker, rrrocker@rock.b11.ingr.com
                                rock@seabass.st.usm.edu
                                72673.2105@compuserve.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "client.h"
#include <malloc.h>
#include <signal.h>
#include <time.h>

NAMELIST acctlist;
extern LOGININFO myinfo;     /* for idle timeout in Monitor */

CheckUserid(userid)
char *userid;
{
  ACCOUNT acct;
  if (userid[0] == '\0') return 1;
  if (!is_valid_userid(userid)) return 3;
#ifdef DISABLED_ACCOUNT
  if (is_disabled_userid(userid)) return 4;
#endif
  if (bbs_query(userid, &acct) != S_NOTFOUND) return 2; 
  return 0;
}

PromptForAccountInfo(acct, for_self)
ACCOUNT *acct;
int for_self;
{
  PASSWD passcfm;
  char ans[4];
  int lineno, userok = 0, passok, cfm = 1;
  memset(acct, 0, sizeof(*acct));
  if (for_self) {
    Cat("etc/newuser",0);
    lineno = 0;
  }
else lineno = 3;
  while (!userok) {
    if (getdata(lineno,0,"�Ь��ۤv��@�ӥN�� : ",acct->userid,NAMELEN+1,DOECHO,1) == -1)
      return -1;

    switch (CheckUserid(acct->userid)) {
    case 0: userok = 1;
      break;
    case 1: if (!for_self) return -1;   /* bail out */
      break;
    case 2: prints("�o�ӥN���w�g���H�ϥΤF. �ЦA���@��.\n");
      break;
    case 3: prints("�z�ҿ諸�N���O���~��. �ЦA�դ@��.\n");
      break;
#ifdef DISABLED_ACCOUNT
    case 4: prints("�z�ҿ諸�N���t���������r��. �ЦA�դ@��.\n");
#endif
      break;
    }
  }
  if (lineno) lineno++;
  while (cfm) {
    do {
      getdata(lineno,0,"�п�ܱK�X: ", acct->passwd, PASSLEN+1, NOECHO, 0);
      passok = is_valid_password(acct->passwd);
      if (!passok) prints("�z�ҿ�J���O�t�εL�k�������K�X.\n");
    } while (!passok);
    getdata(lineno+1,0,"�ЦA��J�@���T�{: ", passcfm, PASSLEN+1, NOECHO, 0);
    if (cfm = strcmp(acct->passwd, passcfm))
      prints("\n�z�⦸�ҿ�J���K�X�ä��ۦP! �ЦA�դ@��.\n");
  }
  if (lineno) lineno++;
  getdata(lineno,0,"�z���ʺ�: ", acct->username, UNAMELEN+1, DOECHO, 0);
  if (lineno) lineno++;
  getdata(lineno,0,"�z���׺ݾ����� (�w�]�O vt100): ",
	  acct->terminal, TERMLEN+1, DOECHO, 0);
  if (!term_ok(acct->terminal) ) {
    prints("�׺ݾ������]�w���~, �ϥιw�]�� vt100.\n");
    strcpy(acct->terminal, "vt100");
    if (lineno) lineno++;  
  }
/*  if (!for_self) */ {
    if (lineno) lineno++;
    getdata(lineno,0,"�z���u��m�W: ", acct->realname, RNAMELEN+1,DOECHO,0);
    if (lineno) lineno++;
    getdata(lineno,0,"�z�����}: ", acct->address, ADDRLEN+1,DOECHO,0);
  }
  if (lineno) lineno++;
  getdata(lineno,0,"�p�G�z�� E-mail ���}����, �п�J: ",acct->email,MAILLEN+1,DOECHO,0);
  prints("\n [7m���еy�ԡ�[m \n");
  return 0;
}

/*ARGSUSED*/
AllUsersFunc(indx, acct, info)
int indx;
ACCOUNT *acct;
struct enum_info *info;
{
  if (info->topline == info->currline) {
    move(info->topline-1, 0);
#ifndef NUM_LOGN_POST
    prints("%-14s %-30s   %s\n","�ϥΪ̥N��", "�ϥΪ̼ʺ�", "�e���W�u�ɶ�");
#else
    prints("%-14s %-20s %8s %6s %-6s %-12s\n","�ϥΪ̥N��", "�ϥΪ̼ʺ�",
	"�W�u����", "�峹��", " ", "�e���W�u�ɶ�");
#endif    
  }

#ifndef NUM_LOGN_POST
  prints("%-14s %-30s %c %s", acct->userid, acct->username,
   BITISSET(acct->flags, FLG_EXEMPT) ? 'X': ' ',
   (acct->lastlogin == 0) ? "\n":ctime((time_t *)&acct->lastlogin));
#else
  prints("%-14s %-20s %8d %6d  %-3s %-16s %c\n", acct->userid, 
	acct->username, atoi(acct->numlogins), atoi(acct->numposts), 
   " ", (acct->lastlogin == 0) ? "":ctime((time_t *)&acct->lastlogin),
   BITISSET(acct->flags, FLG_EXEMPT) ? 'X': ' ');
#endif


  info->currline++;
  info->count++;

  if (info->currline > info->bottomline) {
    int ch;
    standout();
    prints("--����--");
    standend();
    clrtoeol();
    while((ch = igetch()) != EOF) {
      if(ch == '\n' || ch == '\r' || ch == ' ' || ch == KEY_DOWN)
	break;
      if(toupper(ch) == 'Q' || ch == KEY_LEFT) {
	move(info->currline, 0);
	clrtoeol();
	return ENUM_QUIT;
      }
      else bell();
    }
    info->currline = info->topline;
  }
  return S_OK;
}

AllUsers()
{
  struct enum_info info;
#ifdef DETAILED_USERMODE
  bbs_set_mode(LAUSERS);
#endif
  info.count = 0;
  info.topline = info.currline = 4;
  info.bottomline = t_lines-2;
  move(3,0);
  clrtobot();
  bbs_enum_accounts(t_lines-5, AllUsersFunc, &info);
  clrtobot();
  move(t_lines-1, 0);
  prints("�`�@��ܤF %d / %d ��w�b�������U���ϥΪ�\n", info.count, 
          num_totalusers());
  keep_prev_display();
  return PARTUPDATE;
}

/*ARGSUSED*/
OnlineUsersFunc(indx, urec, info)
int indx;
USEREC *urec;
struct enum_info *info;
{
  if (info->topline == info->currline) {
    move(info->topline-1, 0);
    prints("%-12s  %-20s %-20s %s %s\n", 
	   "�ϥΪ̥N��", "�ϥΪ̼ʺ�", "�Ӧ�", "P", "�ثe���A");
  }

  prints("%-12s %c%-20s %-20s %c %s\n", urec->userid, 
	 BITISSET(urec->flags, FLG_CLOAK) ? '#': ' ', 
	 urec->username, urec->fromhost, 
	 BITISSET(urec->flags, FLG_NOPAGE) ? 'N': ' ', 
#ifndef DETAILED_USERMODE
          ModeToString(urec->mode));
#else
         ModeToString(urec->mode, urec->add_str));
#endif


  info->currline++;
  info->count++;

  if (info->currline > info->bottomline) {
    int ch;
    standout();
    prints("--����--");
    standend();
    clrtoeol();
    while((ch = igetch()) != EOF) {
      if(ch == '\n' || ch == '\r' || ch == ' ')
	break;
      if(toupper(ch) == 'Q') {
	move(info->currline, 0);
	clrtoeol();
	return ENUM_QUIT;
      }
      else bell();
    }
    info->currline = info->topline;
  }
  return S_OK;
}

OnlineUsers()
{
  struct enum_info info;
#ifdef DETAILED_USERMODE
  bbs_set_mode(LUSERS);
#endif
  info.count = 0;
  info.topline = info.currline = 4;
  info.bottomline = t_lines-2;
  move(3,0);
  clrtobot();
  dont_allow_ansi();
  bbs_enum_users(t_lines-5, NULL, OnlineUsersFunc, &info);
  allow_ansi();
  clrtobot();
  move(t_lines-1, 0);
  prints("�`�@��ܤF %d / %d ��u�W���ϥΪ�\n", info.count,
           online_users());
  keep_prev_display();
  return PARTUPDATE;
}

#ifdef LIST_FRIENDS
/*ARGSUSED*/
FriendsFunc(indx, urec, info)
int indx;
USEREC *urec;
struct enum_info *info;
{
  if (info->topline == info->currline) {
    move(info->topline-1, 0);
    prints("%-12s  %-20s %-20s %s %s\n", 
	   "�ϥΪ̥N��", "�ϥΪ̼ʺ�", "�Ӧ�", "P", "�ثe���A");
  }

if( is_on_my_override_list(urec->userid)) {
  prints("%-12s %c%-20s %-20s %c %s\n", urec->userid, 
	 BITISSET(urec->flags, FLG_CLOAK) ? '#': ' ', 
	 urec->username, urec->fromhost, 
	 BITISSET(urec->flags, FLG_NOPAGE) ? 'N': ' ', 
#ifndef DETAILED_USERMODE
          ModeToString(urec->mode));
#else
         ModeToString(urec->mode, urec->add_str));
#endif

  info->currline++;
  info->count++;
 }

  if (info->currline > info->bottomline) {
    int ch;
    standout();
    prints("--����--");
    standend();
    clrtoeol();
    while((ch = igetch()) != EOF) {
      if(ch == '\n' || ch == '\r' || ch == ' ')
	break;
      if(toupper(ch) == 'Q') {
	move(info->currline, 0);
	clrtoeol();
	return ENUM_QUIT;
      }
      else bell();
    }
    info->currline = info->topline;
  }
  return S_OK;
}

Friends()
{ 
  FILE *fp;
  PATH buf;
  struct enum_info info;
#ifdef DETAILED_USERMODE
  bbs_set_mode(FRIENDS);
#endif
  get_override_file(my_userid(), buf);
  if ((fp=fopen(buf, "r")) == NULL) {
    move (3,0);
    clrtobot();
    prints("  �z���S�O�W��ثe�O�ťժ��A�Х��]�w�z���S�O�W��\n");
    pressreturn();
  }
  else {
    info.count = 0;
    info.topline = info.currline = 4;
    info.bottomline = t_lines-2;
    move(3,0);
    clrtobot();
    dont_allow_ansi();
    bbs_enum_users(t_lines-5, NULL, FriendsFunc, &info);
    allow_ansi();
    clrtobot();
    move(t_lines-1, 0);
    prints("�`�@��ܤF %d ��u�W���ϥΪ�\n", info.count);
    keep_prev_display();
  }
  fclose(fp);
  return PARTUPDATE;
}
#endif

struct shorturec {
  NAME userid;
  LONG pid;
  SHORT flags;
  SHORT mode;
  short wasfound;
  short found;
  short active;
} *global_ulist;

int global_ulist_sz;

SetupGlobalList()
{
  global_ulist_sz = (t_lines - 4) * 4;
  global_ulist = 
    (struct shorturec *)calloc(global_ulist_sz, sizeof(struct shorturec));
  if (global_ulist == NULL)
    {
      move(3,0);
      prints("Not enough memory to fetch user list!\n");
      return -1;
    }
  return 0;
}

/*ARGSUSED*/
FillShortUserList(indx, urec, arg)
int indx;
USEREC *urec;
void *arg;
{
  int i;
  for (i=0; i<global_ulist_sz; i++)
    if (global_ulist[i].pid == urec->pid) {
      global_ulist[i].flags = urec->flags;
      global_ulist[i].mode = urec->mode;
      global_ulist[i].found = 1;
      break;
    }
  if (i >= global_ulist_sz)
    for (i=0; i<global_ulist_sz; i++)
      if (!global_ulist[i].active)
	{
	  strcpy(global_ulist[i].userid, urec->userid);
	  global_ulist[i].pid = urec->pid;
	  global_ulist[i].flags = urec->flags;
	  global_ulist[i].mode = urec->mode;
	  global_ulist[i].active = global_ulist[i].found = 1;
	  break;
	}

  return S_OK;
}

DoShortUserList()
{
  int i, y = 3, x = 0, ucount = 0;
  time_t now;

  for (i=0; i<global_ulist_sz; i++) {
    global_ulist[i].wasfound = global_ulist[i].found;
    global_ulist[i].found = 0;
  }
  move(y, x);
  clrtobot();
  time(&now);
  bbs_enum_users(global_ulist_sz, NULL, FillShortUserList, NULL);
  for (i=0; i<global_ulist_sz; i++)
    {
      if (global_ulist[i].found)
	{
	  prints("[%c]%s%-14s", ModeToChar(global_ulist[i].mode), 
                 BITISSET(global_ulist[i].flags, FLG_CLOAK) ? " #" : " ",
		 global_ulist[i].userid);
	  ucount++;
	}
      else if (global_ulist[i].wasfound) prints("%18s", " ");

      x+=18;
      if ((x+18) > t_columns)
	{
	  x=0; y++;
	}
      move(y, x);
    }
  move(t_lines-1, 0);
/* prints("%d user%s online at %s", ucount, (ucount==1?"":"s"), ctime(&now)); */
  prints("�`�@�� %d ��ϥΪ̥��b�u�W, �ثe�ɨ�: %s",online_users(), ctime(&now));
  refresh();
  return ucount;
}

ShortList()
{
  int i;
  if (global_ulist == NULL) {
    if (SetupGlobalList() == -1) return PARTUPDATE;
  }
  DoShortUserList();
  memset(global_ulist, 0, global_ulist_sz * sizeof(*global_ulist));
  keep_prev_display();
  return PARTUPDATE;
}

struct shorturec *monitor_data;
int monitor_max;
int monitor_idle;

void
monitor_refresh(sig)
{
  int i, boottime;
  if (sig) signal(sig, SIG_IGN);
  boottime = myinfo.idletimeout*120;
  if (boottime && ((monitor_idle += MONITOR_REFRESH) > boottime)) {
    disconnect(EXIT_TIMEDOUT);
  }
  if (bbs_check_mail()) {
    move(0, t_columns/3);
    prints("�e���A���H��f");
  }
  DoShortUserList();
  for (i=0; i<global_ulist_sz; i++)
    if (!global_ulist[i].found) global_ulist[i].active = 0;

  signal(SIGALRM, monitor_refresh);
  alarm(MONITOR_REFRESH);
}

Monitor()
{
  void (*asig)();
  char ch;
  int saved_alarm;
  clear();
  prints("�ʬݽu�W�ϥΪ�                                 �i�� CTRL-C \
�� CTRL-D ���}.   \n");
  prints("Key: [C]��ѫ� [T]��� [R]�\\Ū [P]�i�K [M]�l�� [m]�ʬ� \
[U]=�u�W�H [p]�n�D���\n");
  prints("-----------------------------------------------------------\
------------------\n");
  if (global_ulist == NULL) {
    if (SetupGlobalList() == -1) return PARTUPDATE;
  }
  monitor_idle = 0;
  bbs_set_mode(M_MONITOR);
  saved_alarm = alarm(0);
  asig = signal(SIGALRM, SIG_IGN);
  monitor_refresh(0);
  while (1)
    {
      ch = igetch();
      monitor_idle = 0;
      if (ch == CTRL('C') || ch == CTRL('D')) break;
    }
  alarm(0);
  signal(SIGALRM, asig);
  if (saved_alarm) alarm(saved_alarm);
  bbs_set_mode(M_UNDEFINED);
  memset(global_ulist, 0, global_ulist_sz * sizeof(*global_ulist));
  keep_prev_display();
  return PARTUPDATE;
}

SetPasswd()
{
  ACCOUNT acct;
  int rc;
  PASSWD passbuf, passcfm;
  move(3,0);
  clrtobot();
  if (bbs_owninfo(&acct) != S_OK) {
    move(4,0);
    prints("Can't retrieve your passfile record!\n");
    return PARTUPDATE;
  }
  if (getdata(3,0,"�п�J�±K�X: ",passbuf,sizeof passbuf,NOECHO,1) == -1)
    return FULLUPDATE;

  if (passbuf[0] == '\0' || !is_passwd_good(acct.passwd, passbuf)) {
    move(4,0);
    prints("\n�K�X��J���~.\n");
    pressreturn();
    return PARTUPDATE;
  } 
  getdata(4,0,"�п�J�s�K�X: ",passbuf,sizeof passbuf,NOECHO,0);
  if(!is_valid_password(passbuf)) {
    move(5,0);
    prints("\n�z�ҿ�J���K�X�O���X�k��\n");
    pressreturn();
    return PARTUPDATE;
  }
  getdata(5,0,"�ЦA��J�@���T�{: ",passcfm,sizeof passbuf,NOECHO,0);
  move(6,0);
  if(strcmp(passbuf,passcfm)) {
    prints("�⦸�K�X��J���ۦP.\n");
    pressreturn();
    return PARTUPDATE;		
  }
  rc = bbs_set_passwd(passbuf);
  if (rc == S_OK)
    prints("���K�X����.\n");
  else 
    prints("�K�X��異��.\n");
  pressreturn();
  return PARTUPDATE;
}

SetUsername()
{
  UNAME username;
  int rc;
  move(3,0);
  clrtobot();
  if (getdata(3,0,"�п�J�z���ʺ�: ",username,sizeof username,DOECHO,1)==-1)
    return FULLUPDATE;
  rc = bbs_set_username(username);    
  if (rc == S_OK)
    prints("���ʺ٧���.\n");
  else 
    prints("���ʺ٥���.\n");
  pressreturn();
  return PARTUPDATE;
}

SetAddress()
{
  MAIL email;
  int rc;
  move(3,0);
  clrtobot();
  if (getdata(3, 0, "�п�J�z�� E-mail ���}: ", email,
      sizeof email,DOECHO,1) == -1) return FULLUPDATE;
  rc = bbs_set_email(email);
  if (rc == S_OK)
    prints("E-mail ���}��粒��.\n");
  else 
    prints("E-mail ���}��異��.\n");
  pressreturn();
  return PARTUPDATE;
}

SetTermtype()
{
  TERM terminal;
  int rc;
  move(3,0);
  clrtobot();
  if (getdata(3,0, "�п�J�s���׺ݾ�����: ", terminal, 
      sizeof terminal, DOECHO, 1) == -1) return FULLUPDATE;
  if(terminal[0] == '\0')
    return PARTUPDATE;
  if(term_init(terminal) == -1) {
    prints("�o�Ӳ׺ݾ������O���~��.\n");
    pressreturn();
#if !REMOTE_CLIENT
    return PARTUPDATE;
#endif
  }
  else {
    initscr();
    clear();
  }
  rc = bbs_set_terminal(terminal);
  if (rc == S_OK)
    prints("���׺ݾ���������.\n");
  else 
    prints("�׺ݾ������S���Q���.\n");
  pressreturn();
  return FULLUPDATE;
}

UserDisplay(acct)
ACCOUNT *acct;
{
  prints("[%s] %c\n", acct->userid,BITISSET(acct->flags, FLG_EXEMPT) ? 'X':' ');
  if (*acct->realname) 
    prints("�u��m�W:     %s\n", acct->realname);
    prints("�ϥΪ̼ʺ�:   %s\n", acct->username);
  if (*acct->address)
    prints("���}:         %s\n", acct->address);
  if (*acct->email)
    prints("E-mail ���}:  %s\n", acct->email);
  if (*acct->terminal) 
    prints("�׺ݾ�����:   %s\n", acct->terminal);
  if (*acct->numlogins)
    prints("�W������:     %s\n", acct->numlogins);
  if (*acct->numposts)
    prints("Post ��:      %s\n", acct->numposts);
  if (*acct->fromhost)
    prints("�̫�W�u�Ӧ�: %s\n", acct->fromhost);
  if (acct->lastlogin)
    prints("�̫�W�u�ɶ�: %s\n", Ctime((time_t *)&acct->lastlogin));
  else prints("Never logged in.\n");
  if (_has_perms(PERM_SYSOP)) {
    time_t firsttime;
    get_firstlog_time(acct->userid, &firsttime);
    prints("���U�ɶ�:     %s\n", Ctime((time_t *)&firsttime));
  }
  clrtobot();
}        

ShowOwnInfo()
{
  ACCOUNT acct;
  int rc;

  if (confirm_passwd() != S_OK) {
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&acctlist);
#endif
    return FULLUPDATE;
  }
  move(3,0);
  clrtobot();
  rc = bbs_owninfo(&acct);
  if (rc != S_OK) {
    prints("Can't retrieve your passfile record!\n");
    pressreturn();
  }
  else {
    UserDisplay(&acct);
    ChangeInfo(&acct,0); /* where 0 means not authorized (ie. normal) change */
  }
#ifdef NAMELIST_IN_ARRAY
  free_namelist(&acctlist);
#endif
  return FULLUPDATE;
}


AddAccount()
{
  int rc;
  ACCOUNT acct;
  char ans[4];
  move(3,0);
  clrtobot();
  if (PromptForAccountInfo(&acct, 0) == -1) {
    return PARTUPDATE;
  }
  getdata(12, 0, "�T�w�n�W�[���N���� (Y/N)? [N]: ", ans, sizeof ans, DOECHO, 0);
  move(13,0);
  if (ans[0] != 'Y' && ans[0] != 'y') {
    prints("���W�[���N��.\n");
    return PARTUPDATE;
  }
  rc = bbs_add_account(&acct, 0);  
  switch (rc) {
  case S_OK:
    prints("���N���w�g�Q�[�J.\n");
    break;
  case S_DENIED:
    prints("��? �z�S���W�[�N�����v�O?!\n");
    break;
  case S_FULL:
    prints("�S���e�Ƿs�N�����Ŷ��F.\n");
    break;
  default:
    prints("Something unexpected happened. BUG!\n");
  }
  return PARTUPDATE;
}

DeleteAccount()
{
  NAME namebuf;
  int rc;
  char ans[4];
  ACCOUNT acct;

  move(2,0);
  clrtobot();
  bbs_acctnames(&acctlist);
  namecomplete(acctlist, "�п�J�n�R�����N��: ", namebuf);        
  if (namebuf[0] == '\0' || !is_in_namelist(acctlist, namebuf)) {
    prints("���~���N��.\n");
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&acctlist);
#endif
    pressreturn();
    return FULLUPDATE;
  }
  if (bbs_get_userinfo(namebuf, &acct) != S_OK) {
    prints("���N�����~�Τ��s�b.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&acctlist);
#endif
    return FULLUPDATE;
  } else {
  move(3,0);
  clrtobot();
  prints("'%s' �o�ӥN���N�Q�R��.\n", namebuf);
  UserDisplay(&acct);
  }
  getdata(15,0,"�T�w�n�R���� (Y/N)? [N]: ",ans,sizeof(ans),DOECHO,0);    
  if (ans[0] != 'Y' && ans[0] != 'y') {
    prints("���R�����N��.\n");
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&acctlist);
#endif
    pressreturn();
    return FULLUPDATE;
  }
  rc = bbs_delete_account(namebuf);
  if (rc == S_OK)
    prints("���N���w�g�Q�R���F.\n");
  else
    prints("�R�����N������.\n");
  pressreturn();
#ifdef NAMELIST_IN_ARRAY
  free_namelist(&acctlist);
#endif
  return FULLUPDATE;
}

SetUserData()
{
  NAME userid;
  ACCOUNT acct;

  move(2,0);
  clrtobot();
  bbs_acctnames(&acctlist);
  namecomplete(acctlist, "�п�J�n�]�w���N��: ", userid); 
  if (userid[0] == '\0' || !is_in_namelist(acctlist, userid)) {
    prints("���~���N��.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&acctlist);
#endif
    return FULLUPDATE;
  }
  if (bbs_get_userinfo(userid, &acct) != S_OK) {
    prints("�N�����~�Τ��s�b.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&acctlist);
#endif
    return FULLUPDATE;
  } else {
  move(3,0);
  clrtobot();
  UserDisplay(&acct);
  ChangeInfo(&acct,1);   /* where 1 means authorized change */ 
  }

#ifdef NAMELIST_IN_ARRAY
  free_namelist(&acctlist);
#endif
  return FULLUPDATE;
}

char *global_permstrs[32];

#define PERMMENULETTER(i) ((i)<26?('A'+(i)):('1'+(i)-26))
#define PERMMENUNUMBER(c) ((c)>='A'?((c)-'A'):((c)-'1'+26))
#define PBITSET(m,i)       (((m)>>(i))&1)

LONG
SetPermMenu(pbits)
LONG pbits;
{
  int i, done = 0;
  char buf[80], choice[2];
  move(4,0);

  if (global_permstrs[0] == NULL)
    if (bbs_get_permstrings(global_permstrs) != S_OK) {
      move(3,0);
      prints("Can't get the permission names.\n");
      pressreturn();
      return pbits;
    }

  prints("�п�J�r���μƦr�����Ӷ��v��, �� ENTER �����]�w.\n");
  move(6,0);
  for (i=0; i<16; i++) {
    sprintf(buf, "%c. %-20s %3s      %c. %-20s %3s\n", 
	    PERMMENULETTER(i), global_permstrs[i], 
            PBITSET(pbits,i) ? "YES" : "NO",
	    PERMMENULETTER(i+16), global_permstrs[i+16], 
            PBITSET(pbits,i+16) ? "YES" : "NO");
    prints(buf);
  }
  clrtobot(); 
  while (!done) {
    getdata(t_lines-1, 0, "�п�J����(�� ENTER ����): ",choice,2,DOECHO,0);
    *choice = toupper(*choice);
    if (*choice == '\n' || *choice == '\0') done = 1;
    else if (!isalnum(*choice) || (*choice>='7' && *choice<='9') ||
	     *choice == '0') bell();
    else {
      i = PERMMENUNUMBER(*choice);
      if (PBITSET(pbits,i))
	BITCLR(pbits,1<<i);
      else BITSET(pbits,1<<i);
      i%=16;
      sprintf(buf, "%c. %-20s %3s      %c. %-20s %3s\n", 
   	      PERMMENULETTER(i), global_permstrs[i], 
              PBITSET(pbits,i) ? "YES" : "NO",
	      PERMMENULETTER(i+16), global_permstrs[i+16], 
              PBITSET(pbits,i+16) ? "YES" : "NO");
      move(i+6,0);
      prints(buf);
    }
  }				
  return (pbits);
}

SetUserPerms()
{
  int rc;
  NAME namebuf;
  LONG newperms;
  ACCOUNT acct;
  move(2,0);
  clrtobot();
  bbs_acctnames(&acctlist);
  namecomplete(acctlist, "�п�J�n�����v�����N��: ", namebuf);
  if (namebuf[0] == '\0' || !is_in_namelist(acctlist, namebuf)) {
    prints("���~���N��.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&acctlist);
#endif
    return FULLUPDATE;
  }
  if ((rc = bbs_get_userinfo(namebuf, &acct)) != S_OK) {
    prints("�N�����~�Τ��s�b.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&acctlist);
#endif
    return FULLUPDATE;
  }
  move(2,0);
  clrtobot();
  prints("�]�w '%s' ���ϥΪ��v��\n", acct.userid);
  newperms = SetPermMenu(acct.perms);	
  move(2,0);
  if (newperms == acct.perms)
    prints("'%s' ���ϥΪ��v���S������.\n", acct.userid);
  else {
    rc = bbs_modify_perms(acct.userid, newperms);
    if (rc == S_OK) {
      prints("'%s' ���ϥΪ��v���w�g�Q���ܤF.\n", acct.userid);
    }
    else {
      prints("Permission change failed. That shouldn't happen!\n");
    }
  }
  pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&acctlist);
#endif
  return FULLUPDATE;
}

QueryEdit()
{
  PATH planfile;
  char ans[7];
#ifdef DETAILED_USERMODE
  bbs_set_mode(EDITPLAN);
#endif
  move(3,0);
  clrtobot();
  if (getdata(4,0,"�z�Q�n [E]�s�� �� [D]�R���W����? [E]: ",ans,sizeof(ans),DOECHO,1)==-1)
    return FULLUPDATE;

  if (*ans == 'D' || *ans == 'd') {
    bbs_set_plan(NULL);
    move(6,0);
    prints("�z���W���ɤw�g�Q�R���F.\n");
    return PARTUPDATE;
  }
  bbs_get_plan(myinfo.userid, planfile);    
  if (Edit(planfile)) {
    clear();
    prints("�z���W���ɸ��Ӥ@��, �S������.\n");
  }
  else {
    clear();
    if (bbs_set_plan(planfile) == S_OK) prints("�z�{�b�֦��s���W���ɤF.\n");
    else prints("Problem at server! Plan not updated.\n");
  }
  pressreturn();
  return FULLUPDATE;
}

#ifdef NOTE_EDIT
NoteEdit()
{
  PATH notefile;
  char ans[7];
#ifdef DETAILED_USERMODE
  bbs_set_mode(NOTEEDIT);
#endif
  move(3,0);
  clrtobot();
  if (getdata(4,0,"�z�Q�n [R]�d�� [E]�s�� �� [D]�M�� �Ƨѿ�? [R]: ",ans,sizeof(ans),DOECHO,1)==-1)
    return FULLUPDATE;

  if( *ans != 'D' && *ans != 'd' && *ans != 'E' && *ans != 'e') *ans = 'R';
  bbs_get_note(myinfo.userid, notefile);    
  if (*ans == 'R' || *ans == 'r') {
    if (More( notefile,1) == -1) { 
      move(6,0);
      prints("�z�ثe�S���Ƨѿ�, �Х��s��.\n");
      pressreturn();
    }
    return FULLUPDATE;
  } else if (*ans == 'D' || *ans == 'd') {
    bbs_set_note(NULL);
    move(6,0);
    prints("�z���Ƨѿ��w�g�Q�M���F.\n");
    pressreturn();
    return PARTUPDATE;
  }
  if (Edit(notefile)) {
    clear();
    prints("�z���Ƨѿ����Ӥ@��, �S������.\n");
  }
  else {
    clear();
    if (bbs_set_note(notefile) == S_OK) prints("�z�{�b�֦��s���Ƨѿ��F.\n");
    else prints("Problem at server! Note not updated.\n");
  }
  pressreturn();
  return FULLUPDATE;
}
#endif

/*ARGSUSED*/
_query_if_logged_in(indx, urec, loggedin)
int indx;
USEREC *urec;
int *loggedin;
{
  (*loggedin)++;
  return ENUM_QUIT;
}

show_mode(indx, urec, number)
int indx;
USEREC *urec;
int *number;
{
  prints("%s%s", (*number)? ", " : "�ثe���A: ",
#ifdef DETAILED_USERMODE
                         ModeToString(urec->mode, urec->add_str));
#else
                         ModeToString(urec->mode));
#endif
  (*number)++;
  return S_OK;
}


Query()
{
  NAME namebuf;
  ACCOUNT acct;
  PATH planfile;
  char buf[80];
  FILE *fp;
  int i, in_now = 0, firstsig = 6;
  int number=0;
#ifdef DETAILED_USERMODE
  bbs_set_mode(QUERY);
  set_add_str("");
#endif
  bbs_acctnames(&acctlist);
  move(3,0);
  clrtobot();
  prints("<�п�J�ϥΪ̥N��>\n");    move(2,0);
  namecomplete(acctlist, "�d�߽֩O: ", namebuf);
  move(2,0);
  clrtoeol();
  move(3,0);
  if (namebuf[0] == '\0' || !is_in_namelist(acctlist, namebuf)) {
    if (namebuf[0]) {
      prints("�o�ӨϥΪ̥N���O���~��.\n");
    }
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&acctlist);
#endif
    return PARTUPDATE;
  }

#ifdef DETAILED_USERMODE
 set_add_str(namebuf);
#endif

  if (bbs_query(namebuf, &acct) != S_OK) {
    prints("�䤣��o�ӤH�C.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&acctlist);
#endif
    return PARTUPDATE;
  }

  bbs_enum_users(20, acct.userid, _query_if_logged_in, &in_now);

#ifdef NUM_LOGN_POST
  prints("%s (%s), �w�W�u %s ��, �o���L %s �g�峹.\n", acct.userid, acct.username,acct.numlogins, acct.numposts);
#else
  prints("%s (%s):\n", acct.userid, acct.username);
#endif
  if (acct.lastlogin == 0)
    prints("�S���W�u�O��.\n");
/*
  else prints("%s�Ӧ� %s %s %s", in_now ? "�ثe���b�u�W: " : "�W���W�u", 
               acct.fromhost, in_now ? "�W�u�ɶ�" : "�ɶ���", 
               ctime((time_t *)&acct.lastlogin));
*/
  else prints("%s�W�u�Ӧ� %s, �ɶ��� %s", in_now? "����" : "�̫�",
               acct.fromhost, ctime((time_t *)&acct.lastlogin));
 

  if (acct.realname[0] != '\0') {
    prints("�u��m�W: %s\n", acct.realname);
    firstsig++;
  }


#ifdef QUERY_CHECK_MAIL
  if (query_check_new_mail(acct.userid)) 
    prints("�H�c�����s���H��. ");
  else
    prints("�H�c�����H��Ū�L�F. ");
#endif

  if (in_now) bbs_enum_users(20, acct.userid, show_mode, &number);
  else prints("�ثe���b�u�W");
  prints("\n");

  if (bbs_get_plan(acct.userid, planfile) != S_OK) {
    prints("�S���W����.\n");
  }
  else {
    /* For now, just print one screen of the plan. In the future maybe
       prompt to ask if they want to page thru the whole plan, since
       we have it. */
    if (fp = fopen(planfile, "r")) {
      prints("�W����:\n");
      for (i=firstsig; i<t_lines; i++) {
	if (!fgets(buf, sizeof buf, fp)) break;
	prints("%s", buf);
      }
      fclose(fp);
    }
    else prints("�S���W����.\n");
  }
  keep_prev_display();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&acctlist);
#endif
  return PARTUPDATE;
}

#ifdef QUERY_CHECK_MAIL
QueryOpenMailbox(userid)
char *userid;
{
  int code;
  OPENINFO openinfo;
  code = query_bbs_open_mailbox(userid, &openinfo);
  if (code != S_OK) return -1;
  return ((int)openinfo.newmsgs);
}

QueryCloseMailbox()
{
  int code;
  code = query_bbs_close_board();
  return (code == S_OK ? 0 : -1);
}

query_check_new_mail(userid)
char *userid;
{
  int rc;
  rc = QueryOpenMailbox(userid);
  QueryCloseMailbox();
  return rc;
}
#endif


ToggleCloak()
{
  int rc;
  move(3,0);
  clrtobot();
  rc = bbs_toggle_cloak();
  if (rc != S_OK) {
    prints("Cloak toggle failed. (do what?)\n");
    return PARTUPDATE;
  }
  prints("Cloak has been toggled.\n");
  pressreturn();
  return PARTUPDATE;
}

ToggleExempt()
{
  int rc;
  NAME namebuf;
  ACCOUNT acct;
  move(2,0);
  bbs_acctnames(&acctlist);
  namecomplete(acctlist, "Enter userid to exempt/unexempt: ", namebuf);
  if (namebuf[0] == '\0' || !is_in_namelist(acctlist, namebuf)) {
    prints("Invalid userid.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&acctlist);
#endif
    return FULLUPDATE;
  }
  if ((rc = bbs_get_userinfo(namebuf, &acct)) != S_OK) {
    prints("Invalid or nonexistent userid.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&acctlist);
#endif
    return FULLUPDATE;
  }
  rc = bbs_toggle_exempt(acct.userid);
  move (3,0);
  clrtoeol();
  if (rc == S_OK) {
    if (BITISSET(acct.flags, FLG_EXEMPT))
      prints("User '%s' is now subject to user clean.\n", acct.userid);
    else 
      prints("User '%s' is now exempt from user clean.\n", acct.userid);
  }
  else {
    prints("Exempt toggle failed.\n");
  }
  pressreturn() ;
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&acctlist);
#endif
  return FULLUPDATE;
}

SetPager()
{
  int rc;
  char ans[3], buf[40];
  ACCOUNT acct;
  SHORT setting = 1, pageroff = 0, overrideoff = 0;
  move(3,0);
  clrtobot();
  if (bbs_owninfo(&acct) != S_OK) {
    prints("Can't retrieve your account information!\n");
    return PARTUPDATE;
  }    
  if (acct.flags & FLG_NOPAGE) setting += 1;
  if (acct.flags & FLG_NOOVERRIDE) setting += 2;  
  prints("�z�ثe���I�s���A (pager) �O: %d. �Q�n�����U�C���@�ةO?\n", setting);
  prints("1) ����H�i�H�I�s\n");
  prints("2) �u���b�S�O�W�椺���H�i�H�I�s\n");
  prints("3) �u�����b�S�O�W�椺���H�i�H�I�s\n");
  prints("4) �S���H�i�H�n�z\n");
  sprintf(buf, "�п�J�z����� (1-4)? [%d]: ", setting);
  if (getdata(8, 0, buf, ans, sizeof ans, DOECHO, 1)==-1)
    return FULLUPDATE;
  if (*ans != '1' && *ans != '2' && *ans != '3' && *ans != '4') {
    prints("�I�s���A�S������.\n");
    return PARTUPDATE;
  }
  if (*ans == '2' || *ans == '4') pageroff = 1;
  if (*ans == '3' || *ans == '4') overrideoff = 1;  
  rc = bbs_set_pager(pageroff, overrideoff);
  if (rc != S_OK) {
    prints("�I�s���A�]�w����. (�гq�� SYSOP)\n");
    return PARTUPDATE;
  }
  prints("�I�s���A�]�w����.\n");
  pressreturn();
  return PARTUPDATE;
}

#ifdef MSIG
extern int signum;
#endif

SignatureEdit()
{
  PATH sigfile;
  char ans[7];
#ifdef MSIG
  char buf[80];
#endif
#ifdef DETAILED_USERMODE
  bbs_set_mode(EDITSIG);
#endif
  move(3,0);
  clrtobot();
#ifdef MSIG
  show_all_signature();
  sprintf(buf,"���ĴX��ñ�W��('0'���ܨ���)�H[%d]�G",signum);
  getdata(2,0,buf,ans, 2, DOECHO, 1);
  if( ans[0] == '\0') ;
  else if( ans[0] > '0' && ans[0] < '4') signum = (int)(ans[0]-'0');
  else return FULLUPDATE;
#endif
  if (getdata(2,0,"�z�Q�n [E]�s�� �� [D]�R�� ��ñ�W��? [E]: ", 
      ans, sizeof(ans), DOECHO, 1) == -1) return FULLUPDATE;

  if (*ans == 'D' || *ans == 'd') {
#ifdef MSIG
    bbs_set_signature(NULL, signum);
#else
    bbs_set_signature(NULL);
#endif
    move(22,0);
    prints("�z���o��ñ�W�ɤw�g�Q�R���F�C\n");
    clrtoeol();
    pressanykey();
    return PARTUPDATE;
  }
#ifdef MSIG
  bbs_get_signature(sigfile, signum);
#else
  bbs_get_signature(sigfile);    
#endif
  if (Edit(sigfile)) {
    clear();
    prints("�z���o��ñ�W�ɨS������.\n");
  }
  else {
    clear();
#ifdef MSIG
    if (bbs_set_signature(sigfile, signum) == S_OK) prints("ñ�W�� [%d] �w�g�Q��s�F.\n", signum);
#else
    if (bbs_set_signature(sigfile) == S_OK) prints("ñ�W�ɤw�g�Q��s�F.\n");
#endif
    else prints("Problem at server! Signature not updated.\n");
  }
  pressreturn();
  return FULLUPDATE;
}

#ifdef LOCK_SCREEN
LockScreen()
{
  ACCOUNT acct;
  PASSWD passwd;

#ifdef DETAILED_USERMODE
  bbs_set_mode(LOCKSCRN);
#endif
  bbs_owninfo(&acct);
  clear();
  move(1,20);
  prints("�x�j�p�� �����L������ BBS\n");
  prints("�ù���w�Ҧ�\n");
  prints("�ϥΪ�: %s(%s)", my_userid(), my_username());
prompt_passwd:
  move(5,0);
  clrtobot();
  getdata(5,0,"�п�J�K�X: ", passwd, sizeof passwd, NOECHO, 0);
  if (is_passwd_good(acct.passwd, passwd)) {
    prints("\n�Ѱ��ù���w�Ҧ�!\n");
    pressreturn();
    return PARTUPDATE;
  }
  else {
    prints("\n�K�X��J���~!\n");
    pressreturn();
    goto prompt_passwd;
  }
}
#endif

confirm_passwd()
{
  ACCOUNT acct;
  PASSWD passwd;

  bbs_owninfo(&acct);
  move(3,0);
  clrtobot();
  getdata(3,0,"�п�J�z���K�X�T�{: ", passwd, sizeof passwd, NOECHO, 0);
  if (is_passwd_good(acct.passwd, passwd)) return S_OK;
  else {
    prints("\n�K�X���~!\n");
    pressreturn();
    return S_SYSERR;
  }
}
