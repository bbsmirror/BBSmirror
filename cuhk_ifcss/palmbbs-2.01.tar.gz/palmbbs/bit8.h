#ifdef isspace
#undef isspace
#endif

#ifdef isdigit
#undef isdigit
#endif

#ifdef isalpha
#undef isalpha
#endif

#ifdef toupper
#undef touuper
#endif

#ifdef tolower
#undef tolower
#endif

#ifdef isalnum
#undef isalnum
#endif

#ifdef isprint
#undef isprint
#endif

#define isspace bit8_isspace
#define isdigit bit8_isdigit 
#define isalpha bit8_isalpha 
#define toupper bit8_toupper
#define tolower bit8_tolower 
#define isalnum bit8_isalnum 
#define isprint bit8_isprint
