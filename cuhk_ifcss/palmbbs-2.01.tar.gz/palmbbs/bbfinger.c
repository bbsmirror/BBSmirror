#include "server.h"
#include <time.h>

#ifdef OUT_FINGER

#define whitespace(c) ((c) == ' ' || (c) == '\t' || (c) == '\n' || (c) == '\r')

int getline(char**, int*, FILE*);

char *arguments = NULL;
char arg[20];
int arg_size = 0;

ACCOUNT acct;
int in_now;

#endif

extern char *optarg;
extern int optind;

extern USERDATA user_params;
extern SERVERDATA server;

#ifndef DETAILED_USERMODE
extern char *ModeToString __P((SHORT));
#else
extern char *ModeToString __P((SHORT, char *));
#endif

#ifdef OUT_FINGER

mode_display(indx, urec)
int indx;
USEREC urec;
{
  printf("�ثe���A: %s\n", ModeToString(urec.mode, urec.add_str));
  return S_OK;
}

_query_if_logged_in(indx, urec, loggedin)
int indx;
USEREC *urec;
int *loggedin;
{
  (*loggedin)++;
  return ENUM_QUIT;
}


FingerQuery() 
{
  char *plan;
  char buf[80];
  FILE *fp;
  int i;

  if (strstr(arg,"home/")) return 0;
    if (local_bbs_query(arg, &acct) != S_OK) {
        printf("\n�䤣�� %s �o�ӤH�@.\n\n", arg);
        return 0;
    }
    in_now = 0;
    local_bbs_enum_users(20, acct.userid, _query_if_logged_in, &in_now);
    printf("\n%s (%s), �w�W�u %s ��, �o���L %s �g�峹.\n", acct.userid, acct.username, acct.numlogins, acct.numposts);
    if (acct.lastlogin == 0)
        printf("Never logged in.\n");
    else printf("%s�Ӧ� %s %s %s", in_now ? "�ثe���b�u�W: " : "�W���W�u",
        acct.fromhost, in_now ? "�W�u�ɶ�" : "�ɶ���",
        ctime((time_t *)&acct.lastlogin));
    if (in_now) {
        local_bbs_enum_users(20, acct.userid, mode_display, NULL);
    }

    strcpy(plan,"home/"); strcat(plan,acct.userid); strcat(plan,"/plan");
    if ((fp = fopen(plan, "r")) != NULL) {
      printf("�W����:\n");
      for (i=0; i<16; i++) {
        if (!fgets(buf, sizeof buf, fp)) break;
        printf("%s", buf);
      }
      fclose(fp);
    }
    else printf("�S���W����.\n");

    printf("\n");
    return 0;
}

char*
next_argument (curr)
int* curr;
{
  register int i;
  int start, end;

  i = *curr;

  while (arguments[i] && (whitespace(arguments[i]) || arguments[i] == ','))
    i++;
  start = i;

  while (arguments[i] && !(whitespace(arguments[i])) && arguments[i] != ',' && arguments[i] != '.')
    i++;
  end = i;

  *curr = end;

  if (start == end || end - start > 19)
    { arg[0] = '\0'; return ((char *)NULL);}

  strncpy (arg, &arguments[start], 20);
  arg[19] = '\0';
  arg[end - start] = '\0';

  return arg;
}
#endif

usage(prog)
char *prog;
{
  fprintf(stderr, 
	  "Usage: %s [-d bbs-dir]\n", prog);
}

/*ARGSUSED*/
one_line_display(indx, urec, count)
int indx;
USEREC *urec;
int *count;
{
  printf("%-12s    %-20s[m %-20s   %s\n", urec->userid, 
	 urec->username, urec->fromhost, 
#ifndef DETAILED_USERMODE
         ModeToString(urec->mode));
#else
         ModeToString(urec->mode, urec->add_str));
#endif

  (*count)++;
  return S_OK;
}

main(argc, argv)
int argc;
char *argv[];
{
    char *bbshome = NULL;
    int c, curr = 0, count = 0;

    dont_allow_ansi();
    while ((c = getopt(argc, argv, "d:?")) != -1)
      {
	switch (c)
	  {
	  case 'd':
	    bbshome = optarg;
	    break;
	  case '?':
	    usage(argv[0]);
	    return 2;
	  }
      }

    if (home_bbs(bbshome) == -1) {
        fprintf(stderr, "%s: Cannot chdir to %s\n", argv[0], bbshome);
        return 1;
    }

    if (local_bbs_initialize() != S_OK) {
        fprintf(stderr, "%s: local_bbs_initialize failed\n", argv[0]);
	return 1;
    }

    /* Identify ourself for the log file, just in case */
    strcpy(user_params.u.userid, "[bbfinger]");
    /* assume lowest possible priviliges */    
    user_params.perms = 0;


#ifdef OUT_FINGER
    if (getline (&arguments, &arg_size, stdin) < 0)
        local_bbs_disconnect();

    if(!whitespace(arguments[0])) {
        while(next_argument(&curr)) {
            FingerQuery();
        }
    } else {
#endif

    /* Do it! */
    printf("[%s]\n\n", server.name);
    printf("%-12s    %-20s %-20s   %s\n", 
	   "User Id", "User Name", "From", "Mode");
    local_bbs_enum_users(50, NULL, one_line_display, &count);
    printf("\n%d %s displayed\n\n", count, count==1?"user":"users");

#ifdef OUT_FINGER
    }
    free(arguments);
#endif

    local_bbs_disconnect();

    return 0;
}    

/* getline.c -- Replacement for GNU C library function getline ()

   Copyright (C) 1992 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */


#define MAX_CANON 64

/* Read up to (and including) a newline from STREAM into *LINEPTR
   (and NUL-terminate it). *LINEPTR is a pointer returned from malloc (or
   NULL), pointing to *N characters of space.  It is realloc'd as
   necessary.  Returns the number of characters read (not including the
   null terminator), or -1 on error or EOF.  */

int
getline (lineptr, n, stream)
  char **lineptr;
  int *n;
  FILE *stream;
{
  int nchars_avail;
  char *read_pos;
  extern char *malloc (), *realloc ();


  if (!lineptr || !n || !stream)
    return -1;

  nchars_avail = *n;

  if (!*lineptr)
    {
      if (!(*lineptr = malloc (MAX_CANON)))
	return -1;

      *n = nchars_avail = MAX_CANON;
    }

  read_pos = *lineptr;

  for (;;)
    {
      register char c = getc (stream);

      /* We always want at least one char left in buffer since we
	 always (unless we get an error while reading the first char)
	 NUL-terminate the line buffer. */

      if (nchars_avail < 1)
	{
	  if (*n > MAX_CANON)
	    {
	      nchars_avail = *n;
	      *n *= 2;
	    }
	  else
	    {
	      nchars_avail = MAX_CANON;
	      *n += MAX_CANON;
	    }

	  *lineptr = realloc (*lineptr, *n);
	  read_pos = *lineptr + (*n - nchars_avail);
	}

      /* EOF or error */
      if (feof (stream) || ferror (stream))

	/* Return partial line, if any */
	if (read_pos == *lineptr)
	  return -1;
	else
	  break;

      *read_pos++ = c;
      nchars_avail--;

      /* Return line if NL */
      if (c == '\n')
	break;
    }

  /* Done - NUL terminate and return number of chars read */
  *read_pos = '\0';
  return (*n - nchars_avail);
}

