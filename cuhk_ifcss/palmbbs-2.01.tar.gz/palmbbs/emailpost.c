#include "server.h"
#include <sys/stat.h>

extern USERDATA user_params;

int 
dosearchuserid(userid,passwd)
char *userid,*passwd;
{
	ACCOUNT acct;

	if (_lookup_account(userid, &acct) != S_OK) {
	    bbslog(1, "BADUSERID %s \n", acct.userid);
	    exit(-1);
	} 
        if(!BITISSET(acct.flags, FLG_SHARED))
	    if (!is_passwd_good(acct.passwd, passwd)) {
                bbslog(1, "BADPASSWORD %s \n", acct.userid);
	        exit(-1);
  	    }
  	if (acct.flags & FLG_DISABLED) {
	    bbslog(1, "ID DISABLED %s \n",  acct.userid);
	    exit(-1);
	}
	init_perm_strs();	/* load permssion settings 	*/
	init_perms();		/* see if has post permission 	*/
  	_determine_access(acct.perms, user_params.access);
/*	utable_get_record(NULL, &user_params);*/
	strcpy(user_params.u.userid, acct.userid);
	strcpy(user_params.u.username, acct.username);
	user_params.perms=acct.perms;
	return 1;
}

dosearchboard(bname,board)
char *bname;
BOARD *board;
{	if(_lookup_board(bname,board)!=S_OK) {
	    bbslog(1, "NO SUCH BOARD %s board: %s\n"
			,my_userid(), bname);
	    exit(-1);
	}
	else if(!_has_read_access(board)) {
	    bbslog(1, "NO READ PERM  %s on board: %s\n"
			,my_userid(), board->name);
	    exit(-1);
	}
	else if(!_has_post_access(board)) {
	    bbslog(1, "NO POST PERM  %s on board: %s\n"
			,my_userid(), board->name);
	    exit(-1);
	}
/*
	else if(!_has_manager_access(board)) {
	    bbslog(1, "NOT BM %s of board: %s\n"
			,my_userid(), board->name);
	    exit(-1);
	}
*/
}

bbs_emailpost(bname, subject, fname)
char *bname;
char *subject;
char *fname;
{
  struct _sendmsgstruct sm;
  
  sm.btype = BOARD_POST;
  memset(&sm.hdr, 0, sizeof sm.hdr);
  strncpy(sm.hdr.owner, my_userid() , sizeof sm.hdr.owner);
  strncpy(sm.username, my_username(), sizeof sm.username);
  strncpy(sm.hdr.title, subject, TITLELEN);
  sm.to_list = NULL;
  sm.srcfile = fname;
  sm.destfile[0] = '\0';
  _do_message(0, bname, &sm);
  bbslog(1, "%s POST '%s' in '%s'\n", my_userid(), subject, bname);
#ifdef NUM_LOGN_POST
  if( sm.hdr.size == 0) local_bbs_add_numposts(1);
#endif
  return (sm.hdr.size == 0 ? S_OK : S_SYSERR);
}


main(argc, argv)
int argc;
char *argv[];
{
  NAME userid;
  NAME newboard;
  PASSWD passwd;
  BOARD curboard;
  ACCOUNT acct;
  TITLE subject;
  char *tmp;
  char a[4096];
  FILE *fptr;
  PATH tempfile;
#ifdef CACHED_OPENBOARD
  extern int extern_util;

  extern_util = 1;
#endif
  home_bbs(BBSHOME);
  open_bbslog("emaillog",1);  /* open a log file or the bbslog() will fail */
  set_log_header("E-mail post:");
  umask(0007);
  sprintf(tempfile, "tmp/bbl%05d", getpid());
  while(gets(a)!=NULL && a[0]!='#') ;   /* skip the header */
  if(a[0]=='#')
  {	sscanf(strchr(a,':')+1,"%s",userid);
        gets(a);
        sscanf(strchr(a,':')+1,"%s",passwd);
	dosearchuserid(userid,passwd);

        gets(a);
        sscanf(strchr(a,':')+1,"%s",newboard);
	dosearchboard(newboard,&curboard);

	gets(a);
        if(a[0]=='#') {
            tmp=strchr(a,':');
            do { tmp++; } while(*tmp==' ' && *tmp!='\0');
            strcpy(subject,tmp);
        }
        else  subject[0]='\0'; 

       	if((fptr = fopen(tempfile,"w")) == NULL) {
            fclose(fptr) ;
	    perror("fopen");
	    bbslog(1, "%s can't open tempfile %s \n"
			,my_userid(), tempfile);
	    exit(-1);
        }

        while(gets(a)!=NULL) fprintf(fptr,"%s\n",a);
	fprintf(fptr,"\n");  /* to ensure not zero size */
	fclose(fptr);

	bbs_emailpost(curboard.name, subject ,tempfile);
	unlink(tempfile);
    }
    return 0;
}
