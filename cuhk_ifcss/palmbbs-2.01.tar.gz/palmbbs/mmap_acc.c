#define PASSFILE "passwds"
#include "server.h"
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>

struct _pent {
    char userid[NAMELEN];
    char del1;
    char passwd[PASSLEN];
    char del2;
    char perms[8];
    char del3;
    char flags[4];
    char del5;
    char username[UNAMELEN];
    char del6;
    char newline;
};

fatal(s)
char *s;
{   perror(s);
    exit(0);
}

get_size(fname)
char *fname;
{   struct stat stbuf;
    stat(fname, &stbuf);
    return stbuf.st_size;
}

skip_header(fd)
int fd;
{   int pos=0;
    char ch;
    read(fd, &ch, 1);
    while(ch=='#') {
      	pos++;

	do {
	    read(fd, &ch, 1);
	    pos ++;
	} while(ch!='\n');

 	read(fd, &ch, 1);	
    }
    return pos;
}

void
strip_trailing_space(str)
char *str;
{
  char *eos;
  if (str == NULL || *str == '\0') return;
  eos = str+strlen(str)-1;
  while (eos >= str && *eos == ' ')
    *eos-- = '\0';
}

main()
{   int fd, off, size, count, i;
    struct _pent *pasentry;
    NAME *id;
    char *fimage;

    size = get_size(PASSFILE);
    if((fd = open(PASSFILE, O_RDONLY))==-1) fatal("open"); 
    off = skip_header(fd);
    count = (size - off) / sizeof(struct _pent);
    fimage = mmap(NULL, size, PROT_READ, MAP_FILE | MAP_SHARED, fd, 0);

    if( fimage == (char *)-1) fatal("mmap");

    pasentry = (struct _pent *)(fimage + off);
    close(fd);
    id = (NAME *) malloc(count * sizeof(NAME));
    memset(id, 0, count * sizeof(NAME));
    printf("size = %d, header offset = %d, count = %d\n", size, off, count);
    for(i=0; i< count; i++) {
	memcpy(id[i], &pasentry[i], NAMELEN);
	strip_trailing_space(id[i]);
    }
    munmap(fimage, size);
/*
    for(i=0; i< count; i++) {
	printf("%s\n",id[i]);
    }
*/
}
