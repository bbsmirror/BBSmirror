#define HCACHE_DIR ".headers"
#include <unistd.h>
#include <sys/mman.h>

typedef struct _SMALL_HEADER {
    ADDR owner;
    TITLE title;
    LONG mtime;
} SMALL_HEADER;

SMALL_HEADER *hlist=NULL;
int numhdrs=0, size=0;

get_headerfile(bname, buf)
char *bname, *buf;
{
   struct stat stbuf;
   if(stat(HCACHE_DIR, &stbuf)==-1) mkdir(HCACHE_DIR, 0755);
   sprintf(buf, "%s/%s", HCACHE_DIR, bname);
   if(stat(buf, &stbuf)==-1) return -1;
   else size=stbuf.st_size;
   return S_OK;
}

open_headerfile(bname)
char *bname;
{
   PATH hdrfile;
   int fd;

   get_headerfile(bname, hdrfile);
   if(size == 0) return;
   fd = open(hdrfile, O_RDONLY);
   if(fd > 0) { 
       hlist = (SMALL_HEADER *) mmap(NULL, size, PROT_READ, 
					MAP_PRIVATE, fd, 0);
       close(fd);
       numhdrs = size / sizeof(SMALL_HEADER);
       if(hlist == (void *) -1) { perror("mmap"); exit(-1); }
   }
}

close_headerfile()
{
   if(hlist) munmap((caddr_t)hlist, size);
   hlist = NULL;
   numhdrs = 0;
   size = 0;
}

cached_read_headers(bname, fileid, hdr)
char *bname;
SHORT fileid;
HEADER *hdr;
{
   int i = (fileid -1 );
   if(fileid <= numhdrs && hlist[i].mtime == hdr->mtime) {
	strncpy(hdr->owner, hlist[i].owner, ADDRLEN);
	strncpy(hdr->title, hlist[i].title, TITLELEN);
   }
   else {
	PATH bdir, fname, hcache;
        SMALL_HEADER buf;
        int fd;

        get_headerfile(bname, hcache);
	get_board_directory(bname, bdir);
        fileid_to_fname(bdir, fileid, fname);
	read_headers(fname, hdr);
	strncpy(buf.owner, hdr->owner, ADDRLEN);
	strncpy(buf.title, hdr->title, TITLELEN);
	buf.mtime = hdr->mtime;

        if((fd = open(hcache, O_RDWR | O_CREAT, 0600))<0) exit(-1);
	lseek(fd, i * sizeof(SMALL_HEADER), SEEK_SET);
	write(fd, &buf, sizeof(SMALL_HEADER));
	close(fd);
   }
}

update_hcache(bname, fileid, mtime)
char *bname;
SHORT fileid;
time_t mtime;
{
    PATH hcache, bdir, fname;
    SMALL_HEADER buf;
    HEADER hdr;
    int fd;

    memset(&buf, 0, sizeof(buf));
    memset(&hdr, 0, sizeof(hdr));
    get_board_directory(bname, bdir);
    fileid_to_fname(bdir, fileid, fname);
    read_headers(fname, &hdr);
    strncpy(buf.owner, hdr.owner, ADDRLEN);
    strncpy(buf.title, hdr.title, TITLELEN);

    get_headerfile(bname, hcache);
    if((fd = open(hcache, O_RDWR | O_CREAT, 0600))<0) exit(-1);
    lseek(fd, (fileid - 1)* sizeof(SMALL_HEADER), SEEK_SET);
    write(fd, &buf, sizeof(buf));
    close(fd);
}
