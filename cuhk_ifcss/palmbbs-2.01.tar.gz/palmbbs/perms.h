
/*
Eagles Bulletin Board System
Copyright (C) 1994, Ray Rocker, rrrocker@rock.b11.ingr.com
                                rock@seabass.st.usm.edu
                                72673.2105@compuserve.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/


/* 
   Defines the bits that correspond to each permission. The permission bits
   used by the system are defined here, and their names are in the permstrs
   file.
*/

#define PERMBIT(n)	(1 << n)
#define PERMBIT_MAX     31

#define PERM_NONE       0
#define PERM_ALL        ~0

/* PERM_DEFAULT is given to each new account upon creation */
#define PERM_DEFAULT    PERMBIT(0) | PERMBIT(1) | PERMBIT(2) | PERMBIT(13)

/* The bit to denote Sysop permission */
#define PERM_SYSOP	PERMBIT(4)
#define GENERAL_POST    PERMBIT(3)

#define PERM_LOGINS30	PERMBIT(15)
#define PERM_BASIC1	PERMBIT(0)
#define PERM_3DAYS	PERMBIT(3)
#define PERM_BOARDMGR	PERMBIT(6)
#define PERM_BM 	PERMBIT(10)
#define PERM_BASIC3     PERMBIT(2)
