#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 
#define MAXLEN		1024
#define MAXITEMS	256
#define PAGESIZE	18
#define STRLEN 		80

enum { NOBODY, MANAGER, SUBSYSOP, SYSOP };
enum { ADDITEM, ADDGROUP, ADDMAIL };

typedef struct {
    char	title[ STRLEN ];
    char	fname[ STRLEN ];
    int		date;
} ITEM; 

typedef struct {
    ITEM	*item[ MAXITEMS ];
    char	mtitle[ STRLEN ];
    char	pwd[ MAXLEN ];
    int		num, page, now;
    int		level;
} MENU;

char	*SYSOPLIST[] = { "JoeChen", "Muyi",
			 NULL };

char	*SUBSYSOPLIST[] = { "Alpha", "heboy", "Palmarama", NULL};



dashf( fname )
char    *fname;
{
    struct stat st;

    return ( stat( fname, &st ) == 0 && S_ISREG( st.st_mode ) );
}

dashd( fname )
char    *fname;
{
    struct stat st;

    return ( stat( fname, &st ) == 0 && S_ISDIR( st.st_mode ) );
}


checksysop()
{
    char	*uname;
    int		n;

	strcpy( curruserid, uname );
	for( n = 0; SYSOPLIST[n] != NULL; n++ )
	    if( strcmp( curruserid, SYSOPLIST[n] ) == 0 )
		return SYSOP;
	for( n = 0; SUBSYSOPLIST[n] != NULL; n++ )
	    if( strcmp( curruserid, SUBSYSOPLIST[n] ) == 0 )
		return SUBSYSOP;
    return NOBODY;
}

valid( str )
char	*str;
{
    char	ch;

    while( (ch = *str++) != '\0' ) {
	if( (ch >= 'A' && ch <= 'Z') ||
	    (ch >= 'a' && ch <= 'z') ||
	    (ch >= '0' && ch <= '9') ||
	    strchr( "@[]-._", ch ) != NULL ) {
	    ;
	} else {
	    return 0;
	}
    }
    return 1;
}

additem( pm, title, fname )
MENU	*pm;
char	*title, *fname;
{
    ITEM	*newitem;

    if( pm->num < MAXITEMS ) {
	newitem = (ITEM *) malloc( sizeof(ITEM) );
	strcpy( newitem->title, title );
	strcpy( newitem->fname, fname );
	newitem->date = 0;
	pm->item[ (pm->num)++ ] = newitem;
    }
}  

loadnames( pm )
MENU	*pm;
{
    FILE	*fn;
    char	title[ STRLEN ], fname[ STRLEN ];
    char	buf[ MAXLEN ], *ptr;

    pm->num = 0;
    if( (fn = fopen( ".Names", "r" )) == NULL )
	return 0;
    while( fgets( buf, sizeof(buf), fn ) != NULL ) {
	if( (ptr = strchr( buf, '\n' )) != NULL )
	    *ptr = '\0';
	if( strncmp( buf, "Name=", 5 ) == 0 ) {
	    strcpy( title, buf + 5 );
	} else if( strncmp( buf, "Path=~/", 7 ) == 0 ) {
	    strcpy( fname, buf + 7 );
	    additem( pm, title, fname );
	} else if( strncmp( buf, "# Title=", 8 ) == 0 ) {
	    if( pm->mtitle[0] == '\0' )
		strcpy( pm->mtitle, buf + 8 );
	}
    }
    fclose( fn );
}

savenames( pm )
MENU	*pm;
{
    FILE	*fn;
    ITEM	*item;
    int		n;

    if( (fn = fopen( ".Names", "w" )) == NULL )
	return;
    fprintf( fn, "#\n" );
    fprintf( fn, "# Title=%s\n", pm->mtitle );
    fprintf( fn, "#\n" );
    for( n = 0; n < pm->num; n++ ) {
	item = pm->item[ n ];
	fprintf( fn, "Name=%s\n",	item->title );
	fprintf( fn, "Path=~/%s\n",	item->fname );
	fprintf( fn, "Numb=%d\n",	n+1 );
	fprintf( fn, "#\n" );
    }
    fclose( fn );
    system( "chmod 0644 .Names" );
}

output_to(filename)
char *filename;
{	FILE *fp;
	char a[4096];
	if((fp=fopen(filename,"w"))==NULL)
	{ bbslog(1,"can't open %s for write by %s\n" ,filename, curruserid);
	  printf("\n\ncan't open %s for write\n\n", filename);
	  exit(-1);
	}
	while(gets(a)!=NULL) fprintf(fp,"%s\n",a);
	fclose(fp);
}



addnewitem( pm, mode )
MENU	*pm;
{
    ITEM	*new;
    char	board[ STRLEN ], *mesg;
    int		len;

    if( !valid( save_filename ) ) {
        bbslog(1,  "filename invalid chars by %s\n", curruserid );
	  exit(-1);
    } else if( dashf( save_filename ) ) {
      bbslog(1 , "file %s already exists by %s\n", save_filename, curruserid );
      printf("\n\nfile already exits\n\n");
	  exit(-1);
    } else if( dashd( save_filename ) ) {
	bbslog(1, "dir %s already exists by %s\n", save_filename, curruserid );
        printf("\n\ndir already exits\n\n");
	  exit(-1);
    } else {
	switch( mode ) {
	    case ADDITEM:
		sprintf( genbuf, " -- %s ��z", curruserid );
		strcat( save_title, genbuf );
		output_to(save_filename);
		sprintf(genbuf,"chmod 0644 %s",save_filename);
		system( genbuf );
		break;
	}
	additem( pm, save_title, save_filename );
	savenames( pm );
    }
}


domenu()
{
    MENU        me;
    char        *fname, *title;
    int         ch;

    me.level = MANAGER;
    loadnames( &me );
    getcwd( me.pwd, sizeof( me.pwd ) );
    me.page = 9999;
    me.now = 0;
    addnewitem( &me, ADDITEM );
    me.page = 9999;
    for( ch = 0; ch < me.num; ch++ )
	free( me.item[ ch ] );
}


