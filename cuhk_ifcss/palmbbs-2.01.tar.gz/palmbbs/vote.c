/*
 * vote.c for Eagles BBS 3.0 
 * by joechen@cc.ntu.edu.tw 
 * the program is not well constructed, sorry for it  :-) 
 * maybe it should be spilt into server & client parts.
 */

#include "client.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>

#ifdef VOTE

#define POLL_LIST 	"poll_list"
#define DESCRIPTION 	"desc"
#define CONTROL 	"control"
#define BALLOTS 	"ballots"
#define PEOPLE 		"people"
#define MAXIMUM         "max"
#define NO_NEW          "no_new"
#define RESULTS		"results"
#define BBS_MAX_POLLS   10
#define MAX_SELECTIONS  24 
#define HAS_VOTED      "voted"
#define VOTED		0x1
#define NEW_CANT	0x2
#define CANT_VOTE	0x4

typedef struct _poll {
	TITLE title;
	NAME voteid;
	time_t closetime;
	TITLE choice_item[MAX_SELECTIONS];
	SHORT max_peruser;
	SHORT numselections;
	SHORT mode;
} POLL;
	

#ifdef NO_FLOCK
#define LOCK(fd)   lockf(fd, F_LOCK, 0)
#define UNLOCK(fd) lockf(fd, F_ULOCK, 0)
#else
#include <sys/file.h>
#define LOCK(fd)   flock(fd, LOCK_EX)
#define UNLOCK(fd) flock(fd, LOCK_UN)
#endif
 

make_dir(path)
char *path;
{   struct stat stbuf;
    if(stat(path, &stbuf)==-1) {
       if(mkdir(path, 0755) == -1) {
	   perror(path);
	   return -1;
       }
    } 
    else if(!S_ISDIR(stbuf.st_mode)) return -1;
    return 0;
}

exist_file(file)
char *file;
{   struct stat stbuf;
    if(stat(file, &stbuf)==-1) return 0;
    else return 1;
}

touch_file(file)
char *file;
{    FILE *fp;
     fp = fopen(file, "w"); 
     if(fp==NULL) return -1;
     else {
	fclose(fp);
	return 0;
     } 
}

suckinfile(fp, fname)
FILE *fp;
char *fname;
{
        char inbuf[256];
        FILE *sfp;
        if ((sfp = fopen(fname, "r")) == NULL) return -1;
        while (fgets(inbuf, sizeof(inbuf), sfp) != NULL)
            fputs(inbuf, fp);
        fclose(sfp);
        return 0;
}

closepoll(bname, poll, need_result)
char *bname;
POLL *poll;
int need_result;
{
    PATH newresult, results, poll_list, tmp, ballots, people, desc;
    PATH workdir;
    char buf[80];
    FILE *file, *tmpfile;
    NAME id;
    int i;

    sprintf(poll_list, "vote/%s/%s", bname, POLL_LIST);
    sprintf(results, "vote/%s/%s", bname, RESULTS);
    sprintf(newresult, "vote/%s/newresult", bname );
    sprintf(tmp, "vote/%s/tmplist", bname, POLL_LIST);
    sprintf(workdir, "vote/%s/%s", bname, poll->voteid);
    sprintf(ballots, "%s/%s", workdir , BALLOTS);
    sprintf(people, "%s/%s", workdir, PEOPLE);
    sprintf(desc, "%s/%s", workdir, DESCRIPTION);

    if( !exist_file(poll_list) ) return 0;
    if( rename(poll_list, tmp) == -1 ) return -1;
    tmpfile = fopen(tmp, "r");
    file = fopen(poll_list, "w");
    if(tmpfile==NULL || poll_list==NULL) return -1;
    while( fgets(buf, sizeof(buf), tmpfile) ) {   /* delete the entry */
	sscanf(buf, "%s", id);
	if(strcmp(id, poll->voteid)) { 
	    strip_trailing_space(buf);
	    fprintf(file, "%s\n", buf);
	}
    }
    fclose(file);
    fclose(tmpfile);
    unlink(tmp);
    if(need_result && exist_file(people) && exist_file(ballots)) {
      FILE *tfp, *cfp;
      int bfd;
      char inchar;
      int counts[MAX_SELECTIONS];
      struct stat stbuf;
      int totvotes=0, totusers=0;
      

      if(stat(people, &stbuf)==-1) return -1; 
      totusers = stbuf.st_size;
      for (i = 0; i < MAX_SELECTIONS; i++) counts[i] = 0;
      if ((bfd = open(ballots, O_RDONLY)) != -1) {
         while (read(bfd, &inchar, 1) == 1) {
             counts[(int)(inchar - 'A')]++;
             totvotes++;
	 }
         close(bfd);
      }
      if(poll->max_peruser==1) totusers = totvotes;
 
      if(tfp = fopen(newresult, "w")) {
	  time_t starttime = atol(poll->voteid);
	  time_t now;
	  time(&now);
          fprintf(tfp, "------------------------------------------------------\n\n");
	  fprintf(tfp, "** �벼�}�l�ɶ�: %s\n", ctime(&starttime));
	  if(now < poll->closetime) {
            fprintf(tfp, "** �벼�w�w�����ɶ�: %s\n", ctime(&poll->closetime));
            fprintf(tfp, "** �벼��ڵ����ɶ�: %s\n", ctime(&now));
	    fprintf(tfp, "** �� %s ����\n\n", my_userid());
          }
	  else  
	    fprintf(tfp, "** �벼�����ɶ�: %s\n", ctime(&poll->closetime));

	  if(poll->mode & NEW_CANT) 
	      fprintf(tfp, "** �����~�H���L�벼�v. \n\n");
	  fprintf(tfp, "** �C�ӤH�̦h�� %d ��\n\n", poll->max_peruser); 
          fprintf(tfp, "** �벼����:\n\n");
          suckinfile(tfp, desc);
          fprintf(tfp, "\n** ���G:\n\n");
  	  for(i=0; i<poll->numselections; i++) {
  	    poll->choice_item[i][23]='\0'; 
            fprintf(tfp,"    %-20s  %3d (%d.%d%%)\n", 
		  poll->choice_item[i]+3, counts[i], counts[i]*100/totusers,
			(((counts[i]*10000+5)/totusers)/10) % 10);
  	  }
 
	  if(poll->max_peruser!=1)
		fprintf(tfp, "\n�`�벼�H��= %d", totusers);
          fprintf(tfp, "\n�`����= %d", totvotes);
	  fprintf(tfp, "\n\n"); 
          suckinfile(tfp, results);
          fclose(tfp);
	  unlink(results);
	  rename(newresult, results);
	  bbslog(1, "close polls of board %s '%s' by %s\n", 
		bname,  poll->title, my_userid());
        }
	else return -1; /*  couldn't write out the results! */
     }

     recursive_rmdir(workdir);
}

get_pollinfo(bname, poll)
char *bname;
POLL *poll;
{
     PATH workpath, description,  control, maximum, no_new; 
     FILE *file;
     time_t now;
     char buf[80];

     sprintf(workpath, "vote/%s/%s", bname, poll->voteid);
     sprintf(control, "%s/%s", workpath, CONTROL);
     sprintf(maximum, "%s/%s", workpath, MAXIMUM);
     sprintf(no_new, "%s/%s", workpath, NO_NEW);

     file = fopen(control, "r");
     fgets(buf, sizeof(buf), file);
     poll->closetime = (time_t)atol(buf);
     while(fgets(buf, sizeof(buf), file)!=NULL) {
	strip_trailing_space(buf);
       	strcpy(poll->choice_item[poll->numselections++],buf);
     }
     fclose(file);

#ifdef FIRSTLOGIN_TIME
     if(exist_file(no_new)) {
	time_t firsttime;
	poll->mode|=NEW_CANT; 
	get_firstlog_time(my_userid(), &firsttime);
	if(firsttime > atol(poll->voteid)) poll->mode |= CANT_VOTE;
     }
#endif
     if(exist_file(maximum)) {
         file = fopen(maximum, "r");
         fgets(buf, sizeof(buf), file);
         poll->max_peruser = atoi(buf);
         fclose(file);
      }
      if(poll->max_peruser == 0) poll->max_peruser=1;
      else if(poll->max_peruser > poll->numselections) 
	   poll->max_peruser = poll->numselections;
      time(&now);
      if(now > poll->closetime) {
	   closepoll(bname, poll, 1);
	   return S_NOTFOUND;
      }
      return S_OK;
}
 
find_polls(bname,list)
char *bname;
POLL *list;
{    PATH summary;
     FILE *file;
     char buf[80], *space;
     TITLE tmpname;
     int i=0;

     sprintf(summary,"vote/%s/%s",bname,POLL_LIST); 
     file = fopen(summary, "r");
     if(file) {
         while( fgets(buf, sizeof(buf), file) && i< BBS_MAX_POLLS ) {
	     memset(&list[i], 0, sizeof(POLL));
	     if(buf[0]=='\0') break;
	     strip_trailing_space(buf);
             sscanf(buf, "%s", list[i].voteid);
	     if((space=strchr(buf,' '))!=NULL)
		strncpy(list[i].title, space+1, sizeof(TITLE));
	     if(get_pollinfo(bname, &list[i])==S_OK) i++;
	 }	
         fclose(file);
     }
     return i;
}

#if 0
check_polls(bname, count, list)
char *bname;
int *count;
POLL *list;
{   int release=0, total, ava, i;
    PATH has_voted, tmp, poll_list;
    FILE *file, *tmpfile;
    char buf[80];

    if(list == NULL) { 
	    list = (POLL *) calloc(BBS_MAX_POLLS, sizeof(POLL));
	    release = 1;
    }

    total = find_polls(bname, list);
    if(count) *count = total; 

    sprintf(has_voted, "home/%s/%s", my_userid(), HAS_VOTED);
    sprintf(tmp, "home/%s/tmpvote", my_userid());
    sprintf(poll_list, "vote/%s/%s", bname, POLL_LIST);
    if((tmpfile = fopen(tmp, "w"))==NULL) {
         prints("System error!\n");
         pressreturn();
         return -1;
    }
    file = fopen(has_voted, "r");
     /* check if voted and clean expired polls */
    if(file) {
       while( fgets(buf, sizeof(buf), file) ) {
         if(buf[0]=='\0') break;
         if(!strncmp(buf, bname, strlen(bname))) {
            char *space;
            if((space=strchr(buf,' '))==NULL) continue;
            for(i=0; i<total; i++) {
              if(!strncmp(space+1, list[i].voteid, strlen(list[i].voteid))){
       		    list[i].mode|=VOTED;
       		    break;
              }
            }
            if(i==total) continue;  /* the poll no longer exists, skip it */
          }
          strip_trailing_space(buf);
          fprintf(tmpfile, "%s\n", buf);
       }
       fclose(file);
    }
    fclose(tmpfile);
    if(rename(tmp, has_voted)==-1) return -1;
    ava = total;
    for(i=0; i<total; i++)
 	if((list[i].mode & VOTED) || (list[i].mode & CANT_VOTE)) ava--;
    if(release) free((void *)list);
    return ava;
}
#endif
 
check_polls(bname, count, list)
char *bname;
int *count;
POLL *list;
{   int release=0, total, ava, i;
    PATH has_voted, poll_list;
    FILE *file;
    char buf[80];

    if(list == NULL) { 
	    list = (POLL *) calloc(BBS_MAX_POLLS, sizeof(POLL));
	    release = 1;
    }

    total = find_polls(bname, list);
    if(count) *count = total; 

    sprintf(has_voted, "home/%s/%s", my_userid(), HAS_VOTED);
    sprintf(poll_list, "vote/%s/%s", bname, POLL_LIST);
    file = fopen(has_voted, "r");
     /* check if voted and clean expired polls */
    if(file) {
       while( fgets(buf, sizeof(buf), file) ) {
         if(buf[0]=='\0') break;
         if(!strncmp(buf, bname, strlen(bname))) {
            char *space;
            if((space=strchr(buf,' '))==NULL) continue;
            for(i=0; i<total; i++) {
              if(!strncmp(space+1, list[i].voteid, strlen(list[i].voteid))){
       		    list[i].mode|=VOTED;
       		    break;
              }
            }
            if(i==total) continue;  /* the poll no longer exists, skip it */
          }
          strip_trailing_space(buf);
       }
       fclose(file);
    }
    ava = total;
    for(i=0; i<total; i++)
 	if((list[i].mode & VOTED) || (list[i].mode & CANT_VOTE)) ava--;
    if(release) free((void *)list);
    return ava;
}

/*
int
check_system_polls()
{
	check_polls("_SYSTEM_,,NULL)
}
*/

char *
mode_str(mode)
{	if(mode & CANT_VOTE) return "(can't vote)";
	else if(mode & VOTED) return "(voted)";
	else return "";
}

vote_maintain(bname)
char *bname;
{
   POLL polls[BBS_MAX_POLLS];
   int count,ch,i, value;
   PATH vpath, poll_list;
   char ans[4];

   if(make_dir("vote")==-1) return S_SYSERR;
   sprintf(vpath, "vote/%s", bname);
   if(make_dir(vpath)==-1) return S_SYSERR;

   check_polls(bname, &count, polls);
   sprintf(poll_list, "vote/%s/%s", bname, POLL_LIST);

   while(1) {
     clear();
     move(3,0);
     
     if( count ) {
	prints("�ثe�w���U�C�U�벼���b�i��G\n");
	for(i=0; i<count; i++) 
		prints("    %d). %s\n", i+1, polls[i].title);
     }
     else prints("�ثe�õL�벼�b�i��C \n");

     prints("\n\n���U�C�\\��i���:\n");
     prints("    A) ��@�ӷs���벼\n"); 
     prints("    B) �����@�ӥ��b�|�檺�벼�A�ðO�����G\n");
     prints("    C) �����@�ӥ��b�|�檺�벼�A�����O�����G\n");
/*
     prints("    D) �M���Ҧ����벼���G\n");
*/
     prints("    Q) ���}\n");
     getdata(count+12, 0, "\n�z�����? [Q]: ", ans, 3, DOECHO, 0);

     switch(ans[0]) {
       case 'A': case 'a':
         clear();
	 standout();
	 prints("�}�l�@�ӷs���벼");
	 standend(); 
         if( count == BBS_MAX_POLLS ) {
	    prints("\n\n�藍�_�A�P�ɳ̦h�u�঳ %d �ӧ벼�C", count);
	    pressreturn();
	    break;
	 }
         else {
	   TITLE title;
	   NAME vid;
           PATH workpath, control, description, maximum, no_new;

	   prints("\n\n�`�N�G�p�G�z�X�F���A�u���⥦�����A\n");
	   prints("      �A���Ӥ@���C�Фp�߿�z�C\n"); 

	   getdata(5,0,"���벼���W�١G", title, sizeof(title), DOECHO, 0); 
           if(title[0]=='\0') break;
	   prints("\n�Ы����N��}�l��J�����벼�������G\n");
	   igetch();

	   sprintf(vid,"%lu",time(NULL));

	   sprintf(workpath, "vote/%s/%s", bname, vid);
	   make_dir(workpath);
	   sprintf(control, "%s/%s", workpath, CONTROL);
	   sprintf(description, "%s/%s", workpath, DESCRIPTION);
	   sprintf(maximum, "%s/%s", workpath, MAXIMUM);
	   sprintf(no_new, "%s/%s", workpath, NO_NEW);
     	   if(Edit(description)) {
		prints("\n\n������벼\n");
		pressreturn();
		unlink(description);
		rmdir(workpath); 
		pressreturn();
		break; 
	   }
	   else {
	     char inbuf[80];
	     NAME max, new;
	     int numselections=0;
	     FILE *fp;
	     int aborted=0;
	     int x,y;
		
	     if( (fp=fopen(control,"w"))==NULL) return 1;

	     getdata(0, 0, "���벼�w�p�|��X��? ",inbuf,
						 4, DOECHO, 0);
	     fprintf(fp, "%lu\n", atol(vid)+atol(inbuf)*86400);
             while (!aborted) {
	       TITLE promptbuf;
	       if(numselections==12) {
		    move(2,0);
		    clrtobot();
	       } 
	       sprintf(promptbuf, "��J %c �ﶵ�]��J[ENTER]�����^: ", 
			numselections+'A');
               getdata(numselections%12+2,0,promptbuf, inbuf, 30, DOECHO, NULL);
               if (*inbuf) {
                   fprintf(fp, "%c) %s\n", numselections+'A', inbuf);
                   numselections++;
                   if (numselections == MAX_SELECTIONS) aborted = 1;
               }
	       else {
		 numselections--;
		 aborted = 1;
               }
             }
	     getyx(&y, &x);
	     if(numselections < MAX_SELECTIONS) y--;
             fclose(fp);
	     if(numselections == -1 ) {
		    unlink(control);
		    unlink(description);
		    rmdir(workpath);
		    prints("\n\n������벼\n");
		    pressreturn();
		    break;
	     }
	     move(y,0); clrtoeol();
             getdata(y+1, 0, "�C�H�̦h���X���H [1]: ", max,
			4, DOECHO, 0);
             if(max[0]) {
		int value;
		value = atoi(max);
		if( value <= 0 ) value=1;
		else if(value > numselections+1 ) value=numselections+1;
		if(value!=1) {
		    fp = fopen(maximum, "w");
		    fprintf(fp, "%d\n", value);
		    fclose(fp);
                }
             }
#ifdef FIRSTLOGIN_TIME
	     getdata(y+3, 0, "�O�_����s�����ͤ���벼(�H������F�H�f) ? [Y]: ",
			new, 2, DOECHO, 0);
	     if( new[0]!='n' && new[0]!='N' ) touch_file(no_new);
#endif
	     fp=fopen(poll_list, "a");
	     fprintf(fp, "%s %s\n", vid, title);
	     fclose(fp);
	     bbslog(2,"Opened the polls of %s by %s\n",bname, my_userid() );
	     prints("\n�벼�c�}�ҤF�I\n");
	     pressreturn();
	     clear();
	     return FULLUPDATE;
           }
         }
         break;

       case 'b': case 'B':
	     getdata(count+13, 0, "����ӧ벼�H", ans, 3, DOECHO, 0);
	     if(ans[0]) {
	         value = atoi(ans) - 1;
	         if(value < 0 || value >= count ) {
			prints("�L���ﶵ�I");
			pressreturn();
		 }
		 else {
		     closepoll(bname, &polls[value], 1);
		     prints("\n�����C");
		     pressreturn();
		     return FULLUPDATE;
		 }
	     }
	     break;

       case 'c': case 'C':
	     getdata(count+13, 0, "�������ӧ벼�H", ans, 3, DOECHO, 0);
	     if(ans[0]) {
	         value = atoi(ans) - 1;
	         if(value < 0 || value >= count ) { 
			prints("�L���ﶵ�I");
			pressreturn();
		 }
		 else {
		     closepoll(bname, &polls[value], 0);
		     prints("\n�����C");
		     pressreturn();
		     return FULLUPDATE;
		 }
	     }
	     break;

/*
       case 'd': case 'D':
	    {   PATH results;
		sprintf(results, "vote/%s/%s", bname, RESULTS);
		unlink(results);
		prints("\n�����C\n");
		pressreturn();
		return FULLUPDATE;
	    }
	     break;
*/

       default:
	     return FULLUPDATE;
     } 
   }
}

BvoteMaintain(hptr, currmsg, numinbox, openflags)
HEADER *hptr;
int currmsg, numinbox, openflags;
{
  extern NAME currboard;
  if (!BITISSET(openflags, OPEN_MANAGE)) {
    bell();
    return DONOTHING;
  }
  else vote_maintain(currboard);
  return FULLUPDATE;
}

BoardVote(bname)
char *bname;
{  
   POLL polls[BBS_MAX_POLLS];
   int i,count;
   PATH lockfile;
   int ava;
   char ans[4];

   ava = check_polls(bname, &count, polls);
   clear();
   if( count == 0) {
	prints("��p�A�ثe�å��|��벼�C\n");
        pressreturn();
	clear();
	return 0;
   }
 
   if(count==1 && ava==0 )
     if(polls[0].mode & VOTED) {
          prints("�藍�_�A�����벼�z�w�g��L�F�C\n");
          prints("�C�ӤH�u���@�����|�C\n");
	  pressreturn();
	  return 0;
     } 

   sprintf(lockfile,"home/%s/.votelock",my_userid()); 

   if( my_total_logins() == 1 ) unlink(lockfile); 

   if( exist_file(lockfile) ) {
	prints("�藍�_�A�z�ثe���b�O���������벼�C\n");
	prints("���i�H�R���B�@���B�����C\n");
	pressreturn();
        return 0;
   }
  
   while(1) {
     int value;
     clear();
     move(3,0);
     prints("�H�U���벼���b�i��:\n");
     for(i=0; i<count; i++)
       prints("    %d). %s %s\n", i+1, polls[i].title, 
		mode_str(polls[i].mode) );
     if(count==1) strcpy(ans, "1");
     else getdata(count+5, 0, "�z�n���먺�@�ӧ벼�G", ans, 3, DOECHO,  0);
     if(ans[0]=='\0') {
	 unlink(lockfile);
	 return 0;
     }
     value =  atoi(ans); 
     value--;
     if(value < 0 || value >= count ) { 
	prints("\n�L���ﶵ�I");
	pressreturn();
	continue;
     } else if(polls[value].mode & VOTED) {
	prints("\n�o���벼�z�w�g��L�F\n");
        prints("�j�a�����A�@�H�@�����|\n");
	pressreturn();
	continue;
     } else {
        char selected[MAX_SELECTIONS];
	char inbuf[80];
	int aborted=0;
	PATH desc;
	POLL *poll = &polls[value]; 

        touch_file(lockfile);
           
	sprintf(desc, "vote/%s/%s/%s", bname, poll->voteid, DESCRIPTION);
        More(desc, 1);
	clear();
	move(0,0);
	standout();
	prints("[1m�벼��[m\n");
	standend();
        prints("�п�J�z���ﶵ, �� RETURN �����벼\n");
	prints("�벼�N������: %s", ctime(&poll->closetime));
#ifdef FIRSTLOGIN_TIME
	if(poll->mode & NEW_CANT) {
	    time_t starttime = atol(poll->voteid);
	    prints("** �藍�_�A�b %s ������U���ϥΪ̵L�벼�v **\n", 
		Ctime(&starttime));
	}
#endif
	move(5,0);
	for(i=0; i<poll->numselections; i++) {
	    move(5+i%12, 40*(i/12));
	    prints("   %s\n", poll->choice_item[i]);
	}
#ifdef FIRSTLOGIN_TIME
	if(poll->mode & CANT_VOTE) {
	    time_t firsttime;
	    get_firstlog_time(my_userid(), &firsttime);
	    prints("\n�藍�_�A���벼�A�S���벼�v�C\n");
	    prints("�z�� %s ���U�A�|�����~", Ctime(&firsttime)); 
	    prints("\n\n�벼����");
	    break;
	}
#endif
	i=0;
        memset(selected, 0, sizeof(selected));
	while(i<poll->max_peruser && !aborted) {
	  if(poll->max_peruser==1)
	    sprintf(inbuf,"�z�u�঳�@�ӿ��");
	  else
	    sprintf(inbuf,"�C�ӤH�̦h %d ��, �ӱz�{�b�ٳ� %d ��",
			poll->max_peruser, poll->max_peruser-i);
	  move(t_lines-6,0);
	  prints("%s\n",inbuf);
	  getdata(t_lines-5, 0, "��ܱz���t���@���A�� [ENTER] �����G", 
		ans, 2, DOECHO, 0);
	  if(ans[0]=='\0') {
	    if(i==0) aborted=1;
	    else {
		i--;
		break;
	    }
	  }
	  else {
	    value = toupper(ans[0])-'A';
	    if(value>=0 && value<poll->numselections && selected[value]==0){
	      selected[value]=toupper(ans[0]);
	      move(5+value%12,40*(value/12));
	      prints(" o");
	      refresh();
	      i++;
	    }
	  }
	}
        if(aborted) {
	   prints("\n�U���A��\n");
	   break;
	}
	else {
	  PATH ballots, people, has_voted;
	  struct stat statp, statb;
	  int fdb, fdp;
	  FILE *file;
	  
	  sprintf(ballots, "vote/%s/%s/%s", bname, poll->voteid, BALLOTS);
	  sprintf(people, "vote/%s/%s/%s", bname, poll->voteid, PEOPLE);
	  sprintf(has_voted, "home/%s/%s", my_userid(), HAS_VOTED);
	  if( (fdb=open(ballots, O_WRONLY|O_CREAT|O_APPEND, 0600))==-1) {
	    prints("�L�k�}�Ҳ��c�I�гq�� SYSOP �C");
	    break;
	  }
	  if( (fdp=open(people, O_WRONLY|O_CREAT|O_APPEND, 0600))==-1) {
	    prints("�L�k�}�Ҳ��c�I�гq�� SYSOP �C");
	    break;
	  }

	  LOCK(fdb);
	  for(i=0; i<poll->numselections; i++) 
	    if(selected[i]) write(fdb, selected+i, 1);
	  UNLOCK(fdb);
	  fstat(fdb, &statb);
	  close(fdb);

	  LOCK(fdp);
	  write(fdp, "0", 1);
	  UNLOCK(fdp);
	  fstat(fdp, &statp);
	  close(fdp);

          file = fopen(has_voted, "a");
	  fprintf(file, "%s %s\n", bname, poll->voteid); 
	  fclose(file);
          move(t_lines-3, 0);
	  if(poll->max_peruser==1)
	     prints("�벼�����C (�ثe�w�� %d �i���Ĳ�)\n", statb.st_size);
	  else
	     prints("�벼�����C (�ثe�w�� %d �H�벼 �A%d ���Ĳ�)\n",
		statp.st_size, statb.st_size);
	  break;
        }
      }
    }
    unlink(lockfile);
    pressreturn();
    return FULLUPDATE;
}

ShowResults(bname)
{	PATH results;
	check_polls(bname, NULL, NULL);
	sprintf(results, "vote/%s/%s", bname, RESULTS);
	if(More(results, 1)==-1) {
	     clear();
	     prints("�ثe�L�벼���G�C\n");
	     pressreturn();
	}
	return FULLUPDATE;
}

EditResults(bname)
{	PATH results;
	check_polls(bname, NULL, NULL);
	sprintf(results, "vote/%s/%s", bname, RESULTS);
	if(Edit(results)==-1) {
	     clear();
	     prints("���s��벼���G�C\n");
	     pressreturn();
	}
	return FULLUPDATE;
}

SysvoteMaintain()
{
    vote_maintain("_SYSTEM_");
    return FULLUPDATE;
}

SystemVote()
{
    BoardVote("_SYSTEM_");
    return FULLUPDATE;
}

SysVoteResults()
{  ShowResults("_SYSTEM_");
   return FULLUPDATE;
}

exist_polls(bname)
char *bname;
{
   PATH poll_list;
   struct stat stbuf;
   sprintf(poll_list, "vote/%s/%s", bname, POLL_LIST);
   if(stat(poll_list, &stbuf)==-1) return 0;
   else if(stbuf.st_size==0) return 0;
   else return 1;
}

#endif /* VOTE */
