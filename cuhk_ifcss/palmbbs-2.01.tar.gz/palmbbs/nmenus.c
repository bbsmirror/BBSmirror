
/*
Eagles Bulletin Board System
Copyright (C) 1994, Ray Rocker, rrrocker@rock.b11.ingr.com
                                rock@seabass.st.usm.edu
                                72673.2105@compuserve.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "client.h"
#include <malloc.h>

extern LOGININFO myinfo;
extern char *currentboard;
#ifdef CURSOR_MODE
int showhelpmenu=1;
#endif
keep_prev_display()
{
#ifdef CURSOR_MODE
    showhelpmenu = 2; 

    /*
     * This function isn't the same with pressreturn().
     * Sometimes we hope that some information kept on screen. 
     * eg. after I list users on line, maybe I'll query someone
     * later, and then maybe I'll try to talk to him. In such
     * case, I hope that the information about him still on screen
     * in order for later operations.
     *
     * When CURSOR_MODE is disable, this will become a dummy
     * function. But I think no one will disable it  :-) 
     *
     */

#endif
}


/* New Menu Function */

int GetMenuIndex(t)
unsigned int t ;
{
    t = (t | 0x20) - 'a' ;
    return t % MAXMENUSZ ;
}

char InterpretMenuAction(action) 
char *action;
{
  if(action[0] != '$')
    return action[0] ;
  if(bbs_check_mail())
    return action[2] ;
  return action[1] ;
}

extern NMENU *bigMenuList ;

NMENU *menuEnt[MAXMENUDEPTH] ;
int currMenuEnt = -1 ;

#ifdef DETAILED_USERMODE
set_menu_mode(s)
char *s;
{    if(!strcmp(s, "Main")) bbs_set_mode(MAINMENU);
     if(!strcmp(s, "Mail")) bbs_set_mode(MAILMENU);
     if(!strcmp(s, "Xyz")) bbs_set_mode(XMENU);
     if(!strcmp(s, "Talk")) bbs_set_mode(TMENU);
     if(!strcmp(s, "Admin")) bbs_set_mode(ADMIN);
}
#endif



/*ARGSUSED*/
int 
NDoMenu(menu_name)
char *menu_name ;
{
  int found, update = FULLUPDATE;
  int fieldsz = t_columns/3;
  int oldcmd = 'h', cmd ;
  int comm_loc;
  int cmdnamelen=0; 
  NMENU *msp ;
  NMENUITEM *item = NULL ;
#ifdef CURSOR_MODE
  int menusize,oldpos=-1,newpos,i;
  NMENU *mp;
  NMENUITEM *mip;
#endif

  if( !strcmp(menu_name,"Admin"))
    if( confirm_passwd() != S_OK) {
      return FULLUPDATE;
  }
#ifdef MAX_MAILS
  if (!strcmp(menu_name, "Mail")) {
    total_mails=msgs_in_mailbox(0);
    CheckMailbox();
  }
#endif

  for(msp = bigMenuList;msp;msp=msp->next)
    if(!strcmp(menu_name,msp->menu_id))
      break ;
  if(!msp || currMenuEnt == MAXMENUDEPTH)
    return 0 ;
  currMenuEnt++ ;
  menuEnt[currMenuEnt] = msp ;
  if (myinfo.lastlogin == 0 || BITISSET(myinfo.flags, FLG_SHARED)) cmd = 'H';
  else cmd = InterpretMenuAction(msp->menu_default) ;
  while (update != EXITMENU) {
      if (PagePending()) {
          if (Answer()) update = FULLUPDATE;
      }
      if (update == FULLUPDATE || update == PARTUPDATE) {
          update == FULLUPDATE ? clear() : move(0,0);
          if(!strcmp(msp->menu_title,"*")) {
              extern BBSINFO serverinfo ;
              prints("%s",serverinfo.boardname) ;
          } else
            prints("%s",msp->menu_title);
          clrtoeol();
          move(0, fieldsz*2);
          if (currentboard[0] == '\0')
            prints("�ثe�|����ܰQ�װ�");
          else
            prints("�ثe�Q�װ�: %s", currentboard);
          move(2,0);
          clrtoeol();
          move(1,0);
          prints("%s",msp->menu_prompt);
          comm_loc = strlen(msp->menu_prompt) ;
          clrtoeol();
      }
      if (bbs_check_mail()) {
          move(0, fieldsz);
          prints("�e���A���H��f");
      }
#ifdef VOTE
      else {
         if( check_polls("_SYSTEM_",NULL,NULL) && !is_public_acct()){
            move(0, fieldsz);
            prints("�i�t�Χ벼���j");
         }
      }
#endif
#ifdef CURSOR_MODE
      if(showhelpmenu == 1) do_help();
      mp= menuEnt[currMenuEnt];
      for(menusize=0,mip=mp->commlist;mip;mip=mip->next)
             if(HasPerm(mip->enabled)) menusize++;
#endif
#ifdef DETAILED_USERMODE
      set_menu_mode(mp->menu_id);
#endif
      while(cmd != '\n' && cmd != KEY_RIGHT) {
          item = msp->menucommands[GetMenuIndex(cmd)] ;
          if(item != NULL && HasPerm(item->enabled)) {
              move(1,comm_loc);
              standout();
              prints("%s", item->name) ;
	      cmdnamelen = strlen(item->name);
              standend();
              clrtoeol();
          } else {
              bell();
              cmd = oldcmd;
          }
#ifdef CURSOR_MODE
          if(showhelpmenu == 1) {
              if(oldcmd!=cmd) {
                   if(oldpos!=-1) { move(4+oldpos,0); prints("   "); }
                   for(newpos=0,mip=mp->commlist;mip;mip=mip->next)
                   {    if( toupper(cmd) == toupper(mip->name[0])) break;
                        else if(HasPerm(mip->enabled)) newpos++;
                   }
                   oldpos=newpos;
              }
              move(4+newpos,0); prints(" ��");
              move(1,comm_loc+cmdnamelen); 
          }
#endif

          oldcmd = cmd;
          cmd = MenuGetch();
#ifdef CURSOR_MODE
          if(showhelpmenu)
          switch(cmd) {
                case KEY_UP:
                     if (showhelpmenu ==2) {
			showhelpmenu = 1;
			oldcmd='h';
                        cmd='\n'; 
			break;
		     }
                     if(oldpos==0) newpos=menusize-1;
                     else newpos=oldpos-1;
                     for(i=0,mip=mp->commlist;i<=newpos;mip=mip->next)
                     {  cmd=mip->name[0];
                        if(HasPerm(mip->enabled)) i++;
                     }
                     break;
                case KEY_DOWN:
                     if (showhelpmenu ==2) {
			showhelpmenu = 1;
			oldcmd='h';
                        cmd='\n'; 
			break;
		     }
                     if(oldpos==menusize-1) newpos=0;
                     else newpos=oldpos+1;
                     for(i=0,mip=mp->commlist;i<=newpos;mip=mip->next)
                     {  cmd=mip->name[0];
                        if(HasPerm(mip->enabled)) i++;
                     }
                     break;
                case KEY_RIGHT:
                     cmd='\n';
                     break;
                case KEY_LEFT:
                     if (showhelpmenu ==2) {
			showhelpmenu = 1;
			oldcmd='h';
                        cmd='\n'; 
			break;
		     }
		     if(!strcmp(mp->menu_id,"Main")) cmd='g';
                     else { 
			 oldcmd='e';
                         cmd='\n'; 
		     }
                     break;
           }
#endif
          if (!isalpha(cmd) && cmd != '\n') {
              bell();
              cmd = oldcmd;
          }
      }
      item = msp->menucommands[GetMenuIndex(oldcmd)] ;
      if (item != NULL) {
#ifdef CURSOR_MODE
          showhelpmenu=1;
#endif
          update = (item->action_func)(item->action_arg);
          BITCLR(update, FETCHNEW | NEWDIRECT);     
          if (update & MENUERROR) 
            cmd = InterpretMenuAction(item->error_action);
          else 
            cmd = InterpretMenuAction(item->default_action) ;
      }
  }
  currMenuEnt-- ;
  return FULLUPDATE;
}


do_help()
{
    NMENU *mp ;
    NMENUITEM *mip ;
    
    if(currMenuEnt < 0)
      return ;
    mp = menuEnt[currMenuEnt] ;
    move(3,0) ;
    clrtoeol() ;
    standout() ;
    prints("%s �����O�C��\n", mp->menu_id) ;
    standend() ;
    for(mip=mp->commlist;mip;mip=mip->next)
      if(HasPerm(mip->enabled))
#ifdef ANSIMENU
	prints("    ([1m%c[m%s\n",(mip->help)[1],(mip->help)+2);
#else
        prints("    %s\n",mip->help) ;
#endif
    clrtobot() ;
    return PARTUPDATE;
}

do_echo(s)
char *s ;
{
    clear() ;
    prints("%s",s) ;
    pressreturn() ;
    return FULLUPDATE ;
}

exec_func(s)
char *s ;
{
    int i ;
    char buf[4096] ;
    char *p ;
    
    parse_default() ;
    strncpy(buf,s,sizeof(buf)) ;
    p=strchr(buf,':') ;
    if(p) {
        *p='\0' ;
        parse_environment(p+1) ;
    }
      
    clear() ;
    refresh() ;
    i = do_exec(buf,NULL) ;
    clear() ;
    return FULLUPDATE ;
}
 
exec_func_w_pause(s)
char *s ;
{
    int i ;
    
    char buf[4096] ;
    char *p ;
    
    parse_default() ;
    strncpy(buf,s,sizeof(buf)) ;
    p=strchr(buf,':') ;
    if(p) {
        *p='\0' ;
        parse_environment(p+1) ;
    }
      
    clear() ;
    refresh() ;
    i = do_exec(buf,NULL) ;
    pressreturn() ;
    clear() ;
    return FULLUPDATE ;
}

int do_pipe_more() ;

int revised_pipe_more(s)
char *s ;
{
    char buf[4096] ;
    char *p ;
    
    parse_default() ;
    strncpy(buf,s,sizeof(buf)) ;
    p=strchr(buf,':') ;
    if(p) {
        *p='\0' ;
        parse_environment(p+1) ;
    }
      
    do_pipe_more(buf) ;
}

struct funcs {
    char *funcname ;
    int (*funcptr)() ;
} ;


int NotImpl(), EndMenu(), XyzMenu(), AdminMenu(), MailMenu(), TalkMenu();
int MainHelp(), XyzHelp(), AdminHelp(), MailHelp(), TalkHelp();
int ShowDate(), Welcome(), BoardInfo(), GnuInfo(), EditWelcome();
int MainReadHelp(), MailReadHelp();
int FileMenu(), FileHelp(), FileReadHelp();
int AllUsers(), OnlineUsers(), SetPasswd(), SetUsername(), SetAddress();
int ShortList(), Monitor();
int SetTermtype(), ShowOwnInfo(), AddAccount(), DeleteAccount();
int SetUserData(), SetUserPerms(), ToggleCloak(), ToggleExempt();
int Query(), QueryEdit();
int MailSend(), GroupSend(), ReadNewMail(), MailRead();
int MailDisplay(), MailDelete(), MailDelRange();
#ifdef MAIL_FORWARD_RANGE
int MailFwdRange();
#endif
int MailReply(), GroupReply(), Forward();
int Visit(), BoardCounts(), Zap(), ReadNew(), SequentialRead();
int Boards(), SelectBoard(), AddBoard(), DeleteBoard(), ChangeBoard();
int SetBoardMgrs();
int Post(),  MainRead(), ReadMenuSelect();
int PostDisplay(), PostDelete(), PostMessage(), PostDelRange(), PostMark();
int PostEdit();
#ifdef CAN_CROSSPOST
int crosspost();
#endif
#ifndef STRIP_OUT
int FileBoards(), FileSelect(), FileDownload(), FileView();
int SelectProtocol(), FileReadMenuProto();
int FileUpload(), FileReceive(), FileReadMenuSelect();
#endif
int Chat(), Kick(), Talk(), SetPager(), SetOverrides();
int SelectEditor(), SignatureEdit();
#ifdef INTERNET_EMAIL
int InternetEmail();
#endif
#ifdef VOTE
int SystemVote(), SysvoteMaintain(), SysVoteResults();
#endif
#ifdef LIST_FRIENDS
int Friends();
#endif
#ifdef NOTE_EDIT
int NoteEdit();
#endif

#ifdef B_GROUP
int EGroup(), EBoards();
#endif

#ifdef BBS_NET
int BBSNet();
#endif

#ifdef DEP_BOARDS
int general_boards(),dep_boards(); 
#endif

#ifdef CSIE_ANNOUNCE
int Digest();
#endif

#ifdef OVERRIDE_SEND_MAIL
int OverrideSend();
#endif

#ifdef LIST_SEND_MAIL
int ListSend();
int ModifyList();
#endif

#ifdef LOCK_SCREEN
int LockScreen();
#endif

int Goodbye();

struct funcs funclist[] = {
    "exec", exec_func,
    "exec.pause", exec_func_w_pause,
    "exec.more", revised_pipe_more,
    "echo", do_echo,
    "NotImpl",NotImpl,
    "EndMenu",EndMenu,
    "Help",do_help,
    "Menu",NDoMenu,
    "ShowDate",ShowDate,
    "Welcome", Welcome,
    "BoardInfo",BoardInfo,
    "GnuInfo",GnuInfo,
    "EditWelcome",EditWelcome,
    "AllUsers",AllUsers,
    "OnlineUsers",OnlineUsers,
    "SetPasswd",SetPasswd,
    "SetUsername",SetUsername,
    "SetAddress",SetAddress,
    "ShortList",ShortList,
    "Monitor",Monitor,
    "SetTermtype",SetTermtype,
    "ShowOwnInfo",ShowOwnInfo,
    "AddAccount",AddAccount,
    "DeleteAccount",DeleteAccount,
    "SetUserData",SetUserData,
    "SetUserPerms",SetUserPerms,
    "ToggleCloak",ToggleCloak,
    "ToggleExempt",ToggleExempt,
    "Query",Query,
    "QueryEdit",QueryEdit,
    "MailSend",MailSend,
    "GroupSend",GroupSend,
    "ReadNewMail",ReadNewMail,
    "MailRead",MailRead,
    "Visit",Visit,
    "BoardCounts",BoardCounts,
    "Zap",Zap,
    "ReadNew",ReadNew,
    "Boards",Boards,
    "SelectBoard",SelectBoard,
    "AddBoard",AddBoard,
    "DeleteBoard",DeleteBoard,
    "ChangeBoard",ChangeBoard,
    "SetBoardMgrs",SetBoardMgrs,
    "Post",Post,
    "MainRead",MainRead,
#ifndef STRIP_OUT
    "FileBoards",FileBoards,
    "FileSelect",FileSelect,
    "FileDownload",FileDownload,
    "SelectProtocol",SelectProtocol,
    "FileUpload",FileUpload,
#endif
    "Chat",Chat,
    "Kick",Kick,
    "Talk",Talk,
    "SetPager",SetPager,
    "SetOverrides",SetOverrides,
    "SelectEditor",SelectEditor,
    "SignatureEdit",SignatureEdit,
#ifdef B_GROUP
    "EGroup",EGroup,
    "EBoards",EBoards,
#endif
#ifdef DEP_BOARDS
    "YNTU",dep_boards,
    "ZGeneral",general_boards,
#endif
    "BBSNet", BBSNet,
#ifdef INTERNET_EMAIL
    "InternetEmail", InternetEmail,
#endif
#ifdef VOTE
    "SystemVote", SystemVote,
    "SysvoteMaintain", SysvoteMaintain,
    "SysVoteResults", SysVoteResults,
#endif
#ifdef LIST_FRIENDS
    "Friends", Friends,
#endif
#ifdef CSIE_ANNOUNCE
    "Digest", Digest,
#endif
#ifdef OVERRIDE_SEND_MAIL
    "OverrideSend", OverrideSend,
#endif
#ifdef LIST_SEND_MAIL
    "ListSend", ListSend,
    "ModifyList", ModifyList,
#endif
#ifdef LOCK_SCREEN
    "LockScreen", LockScreen,
#endif
#ifdef NOTE_EDIT
    "NoteEdit", NoteEdit,
#endif
    "Goodbye", Goodbye,
    NULL,NULL
} ;

    
int (*findfunc(s))()
char *s ;
{
    int i ;
    
    for(i=0;funclist[i].funcname;i++)
      if(!strcmp(funclist[i].funcname,s))
        return funclist[i].funcptr ;
    return NULL ;
}

/* NOTE: This MUST agree with ACCESSFILE location in init.c */
#define ACCESSFILE "etc/access" 

char *funcstrings[MAX_CLNTCMDS];

form_function_list()
{
    FILE *fp;
    int i;
    char buf[1024], *equals;
    for (i=0; i<MAX_CLNTCMDS; i++) funcstrings[i] = NULL;
    i = 0;
    if ((fp = fopen(ACCESSFILE, "r")) != NULL) {
      while (i<MAX_CLNTCMDS && fgets(buf, sizeof buf, fp) != NULL) {
        if (*buf == '#' || isspace(*buf)) continue;
        if ((equals = strchr(buf, '=')) != NULL) {
          *equals = '\0';
          if ((funcstrings[i] = (char *)malloc(strlen(buf)+1)) != NULL)
	    strcpy(funcstrings[i], buf);
	}
	i++;
      }
      fclose(fp);
    }
}

free_function_list()
{
    int i;
    for (i=0; i<MAX_CLNTCMDS; i++)
      if (funcstrings[i] != NULL) free(funcstrings[i]);
}

convert_cmd_to_int(s) 
char *s;
{
    int i ;
    
    for (i=0; i<MAX_CLNTCMDS; i++) {
      if (funcstrings[i] == NULL) continue;
      if (!strcmp(funcstrings[i], s)) return i;
    }
    fprintf(stderr, "does not grok '%s'\n", s);
    sleep(2);
    return -1;
}

int line_num ;

ParseMenu()
{
    FILE *fp ;
    extern FILE *yyin ;
    
    if((fp = fopen("etc/menu.desc","r")) == NULL) {
        perror("open etc/menu.desc") ;
        return -1 ;
    }
    form_function_list();    
    yyin = fp ;
    line_num = 1 ;
    yyparse() ;
    fclose(fp) ;
    free_function_list();
    return 0;
}

yywrap()
{
    return 1 ;
}

yyerror()
{
    char buf[512] ;
    sprintf(buf,"syntax error in 'etc/menu.desc' %d.\n",line_num) ;
    do_echo(buf) ;
}
