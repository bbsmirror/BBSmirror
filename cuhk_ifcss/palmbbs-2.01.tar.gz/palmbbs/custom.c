
/*
Eagles Bulletin Board System
Copyright (C) 1994, Ray Rocker, rrrocker@rock.b11.ingr.com
                                rock@seabass.st.usm.edu
                                72673.2105@compuserve.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "server.h"
#include <time.h>
#include <stdlib.h>
#include <sys/stat.h>

#ifdef CURSOR_BOARDS
extern PATH BOARDFILE;
extern long EGroupStat;
extern char EGroupMode;
extern BOARD *bcache[200];
extern int numboards;
_cursor_enum_boards(indx,rec,en)
int indx;
char *rec;
struct enumstruct *en;
{	
  BOARD board;
  SHORT order;
  int zapped;
 
  if(indx==0) numboards=0;  /* re read */
  memset(&board, '\0', sizeof board);
  boardent_to_board(rec, &board);
  if (!_has_read_access(&board)) return S_OK;

  get_read_order(board.name, &order);

#ifdef B_GROUP
  if( !(board.bgroupmask==EGroupStat))
  if( !((board.bgroupmask)&EGroupStat&0x0f0000000) ||
      ( EGroupMode &&!(((board.bgroupmask)&0x0ff00000)==(EGroupStat&0x0ff00000)))) return S_OK;
#endif

  if (order == READ_ORDER_ZAPPED) {		/* a zapped board */
    if (en->flags == BE_UNZAPPED) return S_OK; /* see only unzapped */
    board.flags |= BOARD_ZAPPED;
  }

  if(bcache[numboards]==NULL) {   /* not allocated yet */
	bcache[numboards]=(BOARD *)malloc(sizeof(BOARD));
	if(bcache[numboards]==NULL) 
  	{	bbslog(0,"Insufficient memory");
		local_bbs_disconnect();
  	}
  }
  hide_priv_board_fields(&board);
  memcpy(bcache[numboards],&board,sizeof(BOARD));
  numboards++;
}

dashd( fname)
char* fname;
{
  struct stat st;
  return( stat( fname, &st) == 0 && S_ISDIR( st.st_mode));
}
dashf( fname)
char* fname;
{
  struct stat st;
  return( stat( fname, &st) == 0 && S_ISREG( st.st_mode));
}

local_bbs_cursor_enum_boards(flags)
SHORT flags;
{
  struct enumstruct en;
  en.flags = flags;
  _record_enumerate(BOARDFILE, 0, _cursor_enum_boards, &en);
  return S_OK;
}

#endif /* CURSOR_BOARDS */

#ifdef CSIE_ANNOUNCE
#include "clientui.h"

digest(hptr, currmsg, numinbox, openflags)
HEADER *hptr;
int currmsg, numinbox, openflags;
{
  char buf[80];
  extern NAME currboard, currbtitle;
  PATH path;
  int i;
  int rc;

  NAMELIST mgrlist = NULL;

  extern char* genbufptr;
  extern int a_fmode;

#ifdef DETAILED_USERMODE
  local_bbs_set_mode(ANNOUNCE);
#endif

  sprintf(path,"0Announce/%s",currboard);
  mkdir(path,0755);

  if ( local_bbs_get_boardmgrs(currboard, &mgrlist) != S_OK) {
	prints("�L�k���o�O�D�W��F�гq������");
	pressreturn();
  	free_namelist(&mgrlist);
	return FULLUPDATE;
  }

#ifndef INLINE_DIGEST
  if( mgrlist != NULL) {
        sprintf(buf, "../../bin/viewer %s (BM:", currbtitle);
#ifndef NAMELIST_IN_ARRAY
	for(; mgrlist != NULL; mgrlist=mgrlist->next) {
	   sprintf(buf, "%s %s", buf, mgrlist->word);
	}
#else
	i=0;
	while(mgrlist[i][0]) {
	    sprintf(buf, "%s %s", buf, mgrlist[i]);
	    i++;
	}
#endif
	strcat(buf," )");
  }
  else
        sprintf(buf, "../../bin/viewer %s", currbtitle);
  free_namelist(&mgrlist);

  rc = do_exec(buf, path);

#else /* INLINE_DIGEST */

  if( mgrlist != NULL) {
        sprintf(buf, "%s (BM:", currbtitle);
#ifndef NAMELIST_IN_ARRAY
	for(; mgrlist != NULL; mgrlist=mgrlist->next) {
	   sprintf(buf, "%s %s", buf, mgrlist->word);
	}
#else
	i=0;
	while(mgrlist[i][0]) {
	    sprintf(buf, "%s %s", buf, mgrlist[i]);
	    i++;
	}
#endif
	strcat(buf," )");
  }
  else
        sprintf(buf, "%s", currbtitle);
  free_namelist(&mgrlist);

  genbufptr = malloc(256);
  a_menu( buf, path, _has_perms(PERM_BOARDMGR) ? PERM_BM:0);
  free(genbufptr);

#endif /* INLINE_DIGEST */

#ifdef DETAILED_USERMODE
  local_bbs_set_mode(READING);
#endif
  return FULLUPDATE;
}

#ifndef INLINE_DIGEST
Digest()
{
#ifdef DETAILED_USERMODE
  local_bbs_set_mode(ANNOUNCE);
#endif
  do_exec("bin/run", NULL);
#ifdef DETAILED_USERMODE
  local_bbs_set_mode(MAINMENU);
#endif
  return FULLUPDATE;
}
#endif

bmnote(hptr, currmsg, numinbox, openflags)
HEADER *hptr;
int currmsg, numinbox, openflags;
{
  char buf[80];
  extern NAME currboard, currbtitle;

  chdir(BBSHOME);
  sprintf(buf,"0Announce/%s",currboard);
  if( !dashd(buf)) mkdir(buf,0755);
  sprintf(buf,"0Announce/%s/bmnote",currboard);
  if( !dashf(buf)) {
	clear();
	move(10,24);
	prints("���Q�װϩ|�L�y�O�D���ܡz");
  } else More(buf, NA);
  pressreturn();
  redoscr();
  return FULLUPDATE;
}

copy2digest(hptr, currmsg, numinbox, openflags)
HEADER *hptr;
int currmsg, numinbox, openflags;
{
  static char copypost[40];
  char buf[80],buf2[160],buf3[80];
  extern NAME currboard, currbtitle;

  fileid_to_fname(currboard, hptr->fileid, buf);
  sprintf( buf2,"[�ƻs�ܺ�ذ�]�п�J�ت��ɦW[%s]: ",copypost);
  getdata(23,0,buf2,buf2,80,DOECHO,NULL);
  if( buf2[0] == '\0') strcpy( buf2, copypost);

  chdir(BBSHOME);
  sprintf( buf3, "0Announce/%s/%s", currboard, buf2);
  move(23,0);
  clrtobot();
  refresh();

  if( buf2[0] == '\0' || buf2[0] == '/' || buf2[0] == '.' || !dashf( buf3)) {
    prints("[���~]���ˬd���ɦW�O�_�w�s�b�A�Τw�إ߸��ɮ�");
    if( buf2[0] == ' ') strcpy( copypost, "");
    refresh();
    bell(); bell(); return DONOTHING;
  }

  if( buf2[0] != '\0') strcpy( copypost, buf2);

  sprintf(buf2,"/bin/cat boards/%s >> %s", buf, buf3);
  system( buf2);

  return FULLUPDATE;
}
#endif

#ifdef CAN_CROSSPOST
extern int signum;
add_crosspost_msg(hptr, currmsg, numinbox, openflags)
HEADER *hptr;
int currmsg, numinbox, openflags;
{
  char filename[80], command[160];
  FILE *fp;
  extern NAME currboard;

  fileid_to_fname(currboard, hptr->fileid, filename);
  if ((fp=fopen(c_tempfile,"w")) == NULL) return -1;
  fprintf(fp, "[���峹�� %s �� �����L������ '%s' �Q�װ���K]\n",
               my_userid(), currboard);
  fprintf(fp, "[���峹����@�̬� %s]\n", hptr->owner);
  {
    time_t now;
    time(&now);
    fprintf(fp, "[��K�ɶ��� %s]\n\n", Ctime((time_t *)&now));
  }
  fclose(fp);
  sprintf(command, "/usr/bin/cat boards/%s >> %s", filename, c_tempfile);
  system(command);

  return 0;
}

crosspost(hptr, currmsg, numinbox, openflags)
HEADER *hptr;
int currmsg, numinbox, openflags;
{
  NAME bname;
  NAMELIST boards=NULL;
  TITLE title;

  if (!_has_perms(PERM_SYSOP)) {
    bell();
    return FULLUPDATE;
  }
  move(3,0);
  clrtobot();
  local_bbs_boardnames(&boards);
  namecomplete(boards,"�п�J�n��K�ܭ��@�ӰQ�װ�: ",bname);
  if (bname[0] == '\0') return FULLUPDATE;
  else if (!is_in_namelist(boards, bname)) {
    prints("���Q�װϦW�ٿ��~.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&boards);
#endif
    return FULLUPDATE;
  }
  if (!strcasecmp(currboard, bname)) {
    prints("������K�ܥثe�Q�װ�!\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&boards);
#endif
    return FULLUPDATE;
  }
  {
    SHORT flags;
    if (local_bbs_test_board(bname, &flags) != S_OK) {
      prints("'%s' �Q�װϵo�Ͱ��D, �гq������!\n", bname);
      pressreturn();
#ifdef NAMELIST_IN_ARRAY
      free_namelist(&boards);
#endif
      return FULLUPDATE;
    }
    if (!BITISSET(flags, OPEN_POST)) {
      prints("�z�ثe�S���b '%s' �o�ӰQ�װϵo���峹���v�O.\n", bname);
      pressreturn();
#ifdef NAMELIST_IN_ARRAY
      free_namelist(&boards);
#endif
      return FULLUPDATE;
    }
  }

  if (add_crosspost_msg(hptr, currmsg, numinbox, openflags) == -1) {
    clear();
    prints("�L�k��K���g�峹.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&boards);
#endif
    return FULLUPDATE;
  }

  {
    char buf[80];
    char ans[4];
    int local_save_flag=0;

    if (!_has_perms(PERM_BASIC3)) local_save_flag = 1;
    ans[0] = ' ';
    while( ans[0] != '\0') {
      move(0,0);
      clrtobot();
#ifdef BBSINND
      sprintf(buf, "(L) �N���峹 %s\n",(local_save_flag==1)? "�u�o���b������"
: "�o���b�����ΦU��H��");
    prints(buf);
#endif
#ifdef MSIG
      sprintf(buf, "(S,0-3) ���ϥΤ�ñ�W��(�ثe���� [%d] ��)\n", signum);
      prints(buf);
#endif
      getdata(3,0, "�п�J�n��諸���ةΫ� [ENTER] �i�K�峹: ", ans, 3, DOECHO
, 0);
      switch (ans[0]) {
#ifdef BBSINND
        case 'L': case 'l':
              if (!_has_perms(PERM_BASIC3)) break;
              local_save_flag = !local_save_flag;
        break;
#endif
#ifdef MSIG
        case 'S': case 's':
              if (is_public_acct()) break;
              clear();
              select_signature();
        break;
        case '0': case '1':
        case '2': case '3':
              if (is_public_acct()) break;
              active_signature((int)(ans[0]-'0'));
        break;
#endif
        case '\0':
              break;
        default:
              bell();
        break;
      }
    } /* end of while */

#ifdef BBSINND
     if(local_save_flag) local_bbs_post_localsave();
#endif
  }

  strcpy(title, "[��K] ");
  strcat(title, hptr->title);
  if (local_bbs_post(bname, title, c_tempfile) != S_OK) {
    clear();
    prints("��K���g�峹����.\n");
    pressreturn();
  }
  else {
    clear();
    prints("���g�峹�w�g�Q��K�L�h�F.\n");
    pressreturn();
  }
  unlink(c_tempfile);
#ifdef NAMELIST_IN_ARRAY
  free_namelist(&boards);
#endif
  return FULLUPDATE;
}
#endif

#ifdef ANSI_CAT
int
Cat(fname)
char* fname;
{
  FILE *fp = fopen(fname, "r");
  char buf[80];
  if( !fp) return -1;
  if(fp) {
    while( fgets(buf, sizeof(buf), fp)) 
      prints(buf);
    fclose(fp);
  }
  prints("\n");
  return 0;
}
#endif
