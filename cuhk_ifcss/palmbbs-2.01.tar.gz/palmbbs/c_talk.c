/*
Eagles Bulletin Board System
Copyright (C) 1994, Ray Rocker, rrrocker@rock.b11.ingr.com
                                rock@seabass.st.usm.edu
                                72673.2105@compuserve.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "client.h"
#include <signal.h>

#define TALK_MAX_COLS 128

NAMELIST userlist;
int g_page_pending;
int g_page_need_notify;

struct talkwin {
  int firstln;
  int lastln;
  int currln;
  int firstcol;
  int lastcol;
  int currcol;
  char line[TALK_MAX_COLS];
};

#define MAX_HANDLED_LOGINS 20

struct usertopid {
  USEREC saved_urec;
  LONG pids[MAX_HANDLED_LOGINS];
  int count;
};

void
page_handler(sig)
int sig;
{
  bell();
  bell();
  g_page_pending = 1;
  g_page_need_notify = 1;
  signal(sig, page_handler);  
}

PagePending()
{
  return g_page_pending;
}

/* We need this function to handle page requests in talk and chat mode.
   We only want to notify once, but need to keep the page request 
   around in case we want to go off and answer it. */

NewPagePending()
{
  if (g_page_need_notify) {
    g_page_need_notify = 0;
    return 1;
  }
  return 0;
}

PrintLoginEntry(num, urec)
int num;
USEREC *urec;
{
  prints("[%2d] %-12s  %-20s %-20s %s\n", num, urec->userid, 
#ifndef DETAILED_USERMODE
       urec->username, urec->fromhost, ModeToString(urec->mode));
#else
       urec->username, urec->fromhost, ModeToString(urec->mode, urec->add_str));
#endif
}

/*ARGSUSED*/
PickLogin(indx, urec, info)
int indx;
USEREC *urec;
struct usertopid *info;
{
  if (info->count >= MAX_HANDLED_LOGINS) return ENUM_QUIT;
  info->pids[info->count++] = urec->pid;
  if (info->count == 1) {
    memcpy(&info->saved_urec, urec, sizeof(info->saved_urec));
    return S_OK;
  }        
  if (info->count == 2) {
    clear();
    PrintLoginEntry(1, &info->saved_urec);
  }
  PrintLoginEntry(info->count, urec);
  return S_OK;
}  

LONG
UseridToPid(userid)
char *userid;
{
  struct usertopid u2p;
  int x, y, indx;
  char ans[3];
  memset(&u2p, 0, sizeof u2p);
  bbs_enum_users(MAX_HANDLED_LOGINS, userid, PickLogin, &u2p);
  if (u2p.count == 0) return (LONG)-1;
  else if (u2p.count == 1) return u2p.pids[0];
  /* Else, more than one. We must decide. */
  getyx(&y, &x);
  getdata(y, x, "���N���ثe�b�u�W���@�ӥH�W�� login, �ЬD��@��[1]: ", ans, sizeof ans, DOECHO, 0);
  indx = atoi(ans);    
  if (indx < 1 || indx > u2p.count) indx = 1;
  return (u2p.pids[indx-1]);
}

Kick()
{
  NAME namebuf;
  LONG pid;
  char ans[4];
  move(2, 0);
  clrtobot();
  bbs_usernames(&userlist);
  namecomplete(userlist, "Kick whom: ", namebuf);
  if (namebuf[0] == '\0') {
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&userlist);
#endif
    return FULLUPDATE;
  }
  else if (!is_in_namelist(userlist, namebuf)) {
    prints("Invalid userid.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&userlist);
#endif
    return FULLUPDATE;
  }
  pid = UseridToPid(namebuf);
  if (pid == (LONG)-1) {
    prints("User is no longer logged in.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&userlist);
#endif
    return FULLUPDATE;
  }
  getdata(3, 0, "Are you sure (Y/N)? [N]: ", ans, sizeof ans, DOECHO, 0);
  if (*ans != 'Y' && *ans != 'y') {
    prints("User NOT kicked.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&userlist);
#endif
    return FULLUPDATE;
  }
  switch (bbs_kick_user(pid)) {
  case S_DENIED:
    prints("Permission denied.\n");
    break;
  case S_NOTFOUND:
  case S_SYSERR:
    prints("User has logged out.\n");
    break;
  case S_OK:
    prints("User has been kicked.\n");
    break;
  }
  pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&userlist);
#endif
  return FULLUPDATE;
}

void
TalkAdvanceLine(ts)
struct talkwin *ts;
{
  if (++ts->currln > ts->lastln) ts->currln = ts->firstln;
  move((ts->currln == ts->lastln ? ts->firstln : ts->currln+1), 0);
  clrtoeol();
  move(ts->currln, 0);
  clrtoeol();
}

DoTalkChar(ch, ts)
char ch;
struct talkwin *ts;
{
  /* This function handles backspaces, newlines, and printables. */
  move(ts->currln, ts->currcol);
  if (ch == CTRL('H') || ch == 127) {
    if (ts->currcol == 0) return -1;
    move(ts->currln, --ts->currcol);
    addch(' ');
    ts->line[ts->currcol] = '\0';
    move(ts->currln, ts->currcol);
  }
  else if (ch == '\n' || ch == '\r') {
    ts->currcol = 0;
    TalkAdvanceLine(ts);
    memset(ts->line, 0, sizeof ts->line);
  }
  else if (isprint(ch)) {
    if (ts->currcol < ts->lastcol) {
      ts->line[ts->currcol++] = ch;
      addch(ch);
    }
    else {
      char save[TALK_MAX_COLS];
      int i = ts->currcol;
      ts->line[i] = ch;
      memcpy(save, ts->line, sizeof save);
      while (i && save[i] != ' ') i--;
      if (i == 0) {
	memset(ts->line, 0, sizeof(ts->line));
	ts->currcol = 1;
	TalkAdvanceLine(ts);
	addch(ch);
      }
      else {
	move(ts->currln, i);
	clrtoeol();
	ts->currcol -= i;
	memset(ts->line, 0, sizeof(ts->line));
	memcpy(ts->line, &save[i+1], ts->currcol);
	TalkAdvanceLine(ts);
	prints(ts->line);
      }
    }
  }
  else return -1;

  refresh();
  return 0;
}

DoTalkString(s, tw)
char *s;
struct talkwin *tw;
{
  for (; s && *s; s++) DoTalkChar(*s, tw);
  return 0;
}

talk_show_page_request(ln)
int ln;
{
  USEREC urec;
  char buf[80];
  if (bbs_get_talk_request(&urec, NULL, NULL) != S_OK) {
    /* Whoever was paging stopped. */
    return 0;
  }
  sprintf(buf, " ���� %s (%s) ���b�I�s�A", urec.userid, urec.username);
  move(ln, 3);
  clrtoeol();
  prints(buf);
  move(ln, t_columns-24);  
  prints("[�� CTRL-R �������T��]");
  return 0;
}

_talk_enum_users(count, urec, tw)
int count;
USEREC *urec;
struct talkwin *tw;
{
  char buf[NAMELEN+10];
  sprintf(buf, ",%s%s [%c]", BITISSET(urec->flags, FLG_CLOAK) ? " #" : " ",
          urec->userid, ModeToChar(urec->mode));
  DoTalkString((tw->currcol == 0 ? buf+2 : buf), tw);
  return S_OK;
}
    
talk_user_list(tw)
struct talkwin *tw;
{
  DoTalkString("\n*** �ثe���b�u�W���ϥΪ� ***\n", tw);
  bbs_enum_users(10, NULL, _talk_enum_users, tw);
  DoTalkChar('\n', tw);
  return 0;
}    

DrawDivider(ln, hisid, hisname, myid, myname)
int ln;
char *hisid, *hisname, *myid, *myname;
{
  int i;
  int len;
  len=strlen(hisid)+strlen(hisname)+strlen(myid)+strlen(myname)+14;
  move(ln, 0);
  for (i=0; i<((t_columns-len)/2)-1; i++) {
    addch('-');
  }
  prints("��%s (%s) VS %s (%s)��", hisid, hisname, myid, myname);
  for (i=((t_columns-len)/2)+len+1; i<t_columns; i++) {
    addch('-');
  }
  refresh();
}

DoTalk(sock, hisid, hisname)
int sock;
char *hisid, *hisname;
{
  int i, ch, cc;
  int divider;
  char c;  
  char incoming[80];
  struct talkwin me, them;

  divider = (t_lines-1) / 2;
  me.currln = me.firstln = 0;
  me.lastln = divider - 1;
  them.currln = them.firstln = divider + 1;
  them.lastln = t_lines - 1;
  me.currcol = me.firstcol = them.currcol = them.firstcol = 0;
  me.lastcol = them.lastcol = 
    (t_columns > TALK_MAX_COLS ? TALK_MAX_COLS : t_columns - 1);
  memset(me.line, 0, sizeof me.line);
  memset(them.line, 0, sizeof them.line);

  clear();
  DrawDivider(divider, hisid, hisname, my_userid(), my_username());
  move(0, 0);
  add_io(sock, 0);
  while (1) {
    ch = igetch();
    if( FUNCTION_KEY(ch) ) continue;   /* filter extended keys */ 
    if (NewPagePending()) {
      talk_show_page_request(divider);
      move(me.currln, me.currcol);
    }
    if (ch == -1) {
      /* error in igetch! */
      break;
    }
    if (ch == I_OTHERDATA) {
      /* pending input on sock */
      cc = recv(sock, incoming, sizeof incoming, 0);
      if (cc <= 0) {
	/* other side closed connection */
	break;
      }
      for (i=0; i<cc; i++) {
	DoTalkChar(incoming[i], &them);
      }
    }
    else {
      /* something we typed */
      c = (char)ch;
      if (DoTalkChar(c, &me) == 0) {
	if (send(sock, &c, 1, 0) != 1) {
	  /* connection broken */
	  break;
	}
      }
      else if (c == CTRL('C') || c == CTRL('D')) {
	/* we're ending the talk */
	break;
      }
      else if (c == CTRL('R')) {
	/* clear message on divider line */
	DrawDivider(divider, hisid, hisname, my_userid(), my_username());
	move(me.currln, me.currcol);
      }
      else if (c == CTRL('U')) {
	/* show a brief user list */
	talk_user_list(&me);
      }
      else {
	/* a character we don't like, at this time */
	bell();
      }
    }
  }
  add_io(0,0);

  bbs_exit_talk();
  close(sock);
  do_help();
  return 0;
}

Talk()
{
  NAME namebuf;
  LONG pid;
  LONG sock;
  int rc;
  ACCOUNT acct;

  move(2, 0);
  clrtobot();
  bbs_usernames(&userlist);
  namecomplete(userlist, "�I�s��: ", namebuf);
  if (namebuf[0] == '\0') {
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&userlist);
#endif
    return FULLUPDATE;
  }
  else if (!is_in_namelist(userlist, namebuf)) {
    prints("�z��J���N���O���~��.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&userlist);
#endif
    return FULLUPDATE;
  }
  pid = UseridToPid(namebuf);
  if (pid == (LONG)-1) {
    prints("���w�g���b�u�W�F.\n");
    pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&userlist);
#endif
    return FULLUPDATE;
  }
  clear();
  prints("���b�I�s %s ��. �i�� CTRL-D ���I�s.\n", namebuf);
  move (2,0);
  show_his_plan(namebuf, 5);
  move (1,0);
  refresh();
  switch (rc = bbs_talk(pid, 0, &sock)) {
  case S_DISABLED:
    return FULLUPDATE;
  case S_INVALID:
    prints("��誺�I�s���A�O���۪�.\n");
    break;    
  case S_DENIED:
    prints("����i�o�z�A...  :(\n");
    break;
#ifdef TALK_DENY_REASON
  case S_DENIED1:
    prints("��軡�G�y���b���A���ƽХ��ӫH�n�ܡH�z\n");
    break;
  case S_DENIED2:
    prints("��軡�G�y�߱����n�K�K���n�z�ڡK�K :~( �z\n");
    break;
  case S_DENIED3:
    prints("��軡�G�y�A�O�֡H�I�Х��ӫH�ۧڤ��Цn�ܡH�z\n");
    break;
  case S_DENIED4:
    prints("��褣���D�����򤣲z�A�K�K\n");
    break;
#endif
  case S_NOTFOUND:
    prints("���w�g���u�F.\n");
    break;
  case S_SYSERR:
    prints("�L�k�s��������ͼҦ�.\n");
    break;
  case S_EXISTS:
    prints("�x? �z�Q�ۨ��ۻy��? �γ\\�z�i�H�ոլݲ�Ѽs��.\n");
    break;
  case S_ILLEGAL:
    prints("�z�ثe�L�k�M�H���.\n");
    break;
  case S_TEMPFAIL:
    prints("���ثe�L�k�Q�I�s.\n");
    break;
  case S_OK:
    bbs_query(namebuf, &acct);
    DoTalk((int)sock, namebuf, acct.username);
    break;
  }
  if (rc != S_OK) pressreturn();
#ifdef NAMELIST_IN_ARRAY
    free_namelist(&userlist);
#endif
  return FULLUPDATE;
}

Answer()
{
  USEREC urec;
  LONG addr, sock;
  SHORT port;
  char ans[4];
 
  g_page_pending = g_page_need_notify = 0;

  if (bbs_get_talk_request(&urec, &addr, &port) != S_OK) {
    /* Whoever was paging stopped. */
    return 0;
  }

  clear();
  prints("��!�ڬO %s(%s) �Ӧ� %s �����?", urec.userid, urec.username,
                                             urec.fromhost);

#ifdef TALK_DENY_REASON
  move(1,0);
  prints("[Y]�y�ڭ̲��a�I�z[1]�y���b���A���ƽШӫH�z[2]�y�߱����n�A���n�z�ڡK�K�z\n");
  prints("[N]�y���z�A�K�K�z  [3]�y�A�O�֡H�Х��ӫH�z  [4]���z�Ѽx�D���A�Ц� Chat �O���W\n");
  move (5,0);
  show_his_plan(urec.userid, 6);
  getdata(3, 0, "�� �z���^���� Yes, No or 1,2,3,4? [Y]: ", ans, sizeof ans, DOECHO, 0);
  if (*ans == 'n' || *ans == 'N' || (*ans < '6' && *ans > '0')) {
    bbs_refuse_page(*ans, addr, port);
    return 1;
  }
#else
  move (3,0);
  show_his_plan(urec.userid, 5);
  getdata(1, 0, "Yes or No [Y]: ", ans, sizeof ans, DOECHO, 0);
  if (*ans == 'n' || *ans == 'N') {
    bbs_refuse_page(addr, port);
    return 1;
  }
#endif

  if (bbs_accept_page(addr, port, &sock) != S_OK) {
    prints("���w�g����I�s�z�F.\n");
    pressreturn();
    return 1;
  }

#ifdef DETAILED_USERMODE
  set_real_mode(M_TALK);
  set_add_str(urec.userid);
#endif
  
  DoTalk((int)sock, urec.userid, urec.username);

#ifdef DETAILED_USERMODE
  set_real_mode(M_UNDEFINED);
#endif
  return 1;
}

show_his_plan(hisid, firstsig)
char *hisid;
int firstsig;
{
  int i;
  char buf[80];
  FILE *fp;
  PATH planfile;

  if (bbs_get_plan(hisid, planfile) != S_OK) {
    prints("�� %s �S���W����.", hisid);
  }
  else {
    if (fp = fopen(planfile, "r")) {
      prints("�� %s ���W����: ��\n", hisid);
      for (i=firstsig; i<t_lines; i++) {
        if (!fgets(buf, sizeof buf, fp)) break;
        prints("%s", buf);
      }
      fclose(fp);
    }
    else prints("%s �S���W����.", hisid);
  }
}  

