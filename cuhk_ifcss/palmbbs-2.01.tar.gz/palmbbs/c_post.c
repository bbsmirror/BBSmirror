/*
Eagles Bulletin Board System
Copyright (C) 1994, Ray Rocker, rrrocker@rock.b11.ingr.com
                                rock@seabass.st.usm.edu
                                72673.2105@compuserve.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "client.h"
#include <stdlib.h>
#include <sys/stat.h>

#ifdef MSIG

extern int signum;

int
show_all_signature()
{
  FILE *fp;
  char buf[81];
  PATH sigfile;
  int signum,i=0;
  for( signum=1; signum<4; signum++) {
    local_bbs_get_signature(sigfile, signum);
    if((fp=fopen(sigfile, "r")) != NULL) {
       prints("������ �� [%d] ��ñ�W�� ������\n",signum);
       for( i=0; i<6; i++) {
          if( fgets( buf, sizeof(buf), fp)) {
              prints("%s",buf);
          }
       }
       fclose(fp);
    }
  }
  return i;
}

select_signature()
{
  char buf[80],ans[3];
  move(2,0);
  clrtobot();
  if( show_all_signature() ) {
    sprintf( buf, "�ϥΨ��@��ñ�W�� ('0'���ܤ���)? [%d]: ", signum );
    getdata( 1,0, buf, ans, 2, 1, 1);
    if( ans[0] == '\0') ;
    else if( ans[0] > '0' && ans[0] < '4') active_signature((int)( ans[0]-'0'));
    else active_signature(0);
  } else active_signature(0);

}
#endif

#ifdef CSIE_ANNOUNCE
BMNote(firstline)
int firstline;
{
  FILE* fp;
  char bmnotefile[40];
  char buf[81];
  int i;

  sprintf(bmnotefile,"0Announce/%s/bmnote",currboard);
  if ((fp = fopen(bmnotefile, "r")) == NULL) {
    if ((fp = fopen("etc/nobmnote", "r")) == NULL) return 0;
  }
  prints("[�Q�װϪA�ȥͪ���]\n");
  for (i=firstline; i<t_lines; i++) {
    if (!fgets(buf, sizeof buf, fp)) break;
    prints("%s", buf);
  }
  fclose(fp);
}
#endif

int
OpenBoard(openflags, newonly, resp)
int *openflags;
int newonly;
int *resp;
{
  int code;
  OPENINFO openinfo;
  code = bbs_open_board(currboard, &openinfo);    
  if (resp) *resp = code;
  if (code != S_OK) return -1;
  if (openflags) *openflags = openinfo.flags;
  return (newonly ? openinfo.newmsgs : openinfo.totalmsgs);
}

CloseBoard()
{
  int code;
  code = bbs_close_board();
  return (code == S_OK ? 0 : -1);
}

/* 
   Return codes for DoPostSend:
   0 == success
   -1 == posting failed
   -2 == post was manually aborted
   -3 == post is zero length -- aborted
*/

/*
#ifdef MSIG
extern int signum;
#endif
*/

DoPostSend(subject, textfile, doedit)
char *subject;    /* subject string */
char *textfile;   /* file to send: if NULL invoke editor */
int doedit;       /* edit even if textfile != NULL */
{
  int rc = 0;
  struct stat stbuf;
  
  if (textfile == NULL || doedit) {
    if (textfile == NULL) textfile = c_tempfile;
    if (Edit(textfile)) { 
      if (textfile == c_tempfile) unlink(c_tempfile);
      return -2;
    }
  }
  if (stat(textfile, &stbuf) != 0 || stbuf.st_size == 0) {
    rc = -3;
  }
  else 
/* Abbriviate Version */
    {
    char buf[80];
    char ans[4];
    int local_save_flag = 0;

    if (!_has_perms(PERM_BASIC3)) local_save_flag = 1;
    ans[0] = ' ';
    while( ans[0] != '\0') {
        move(0,0);
        clrtobot();
#ifdef MODIFY_TITLE
        sprintf(buf, "(T) ���峹���D '%s'\n",subject);
        prints(buf);
#endif
#ifdef BBSINND
        sprintf(buf, "(L) �N���峹 %s\n",(local_save_flag==1)? "�u�o���b������" : "�o���b�����ΦU��H��");
        prints(buf);
#endif
#ifdef MSIG
        sprintf(buf, "(S,0-3) ���ϥΤ�ñ�W��(�ثe���� [%d] ��)\n", signum);
        prints(buf);
#endif
        getdata(4,0, "�п�J�n��諸���ةΫ� [ENTER] �i�K�峹: ", ans, 3, DOECHO, 0);
        switch( ans[0]) {
#ifdef MODIFY_TITLE
          case 'T': case 't':
          {   TITLE newtt;
              sprintf(buf, "�s���D(����Ы�[ENTER])? : ");
              getdata(6, 0, buf, newtt, sizeof(newtt), DOECHO, 0);
              if( newtt[0] ) strcpy(subject, newtt);
          }
          break;
#endif
#ifdef BBSINND
          case 'L': case 'l':
              if (!_has_perms(PERM_BASIC3)) break;
              local_save_flag = !local_save_flag;
          break;
#endif
#ifdef MSIG
          case 'S': case 's':
              if (is_public_acct()) break;
              clear();
              select_signature();
          break;
          case '0': case '1':
          case '2': case '3':
              if (is_public_acct()) break;
              active_signature((int)(ans[0]-'0'));
          break; 
#endif
          case '\0':
              break;
          default:
              bell();
          break;
        }
     } /* end of while */

#ifdef BBSINND
     if(local_save_flag) bbs_post_localsave();
#endif
     if (bbs_post(currboard, subject, textfile) != S_OK) {
          rc = -1;
     }
  }
/* End of Abbriviate Version */

/* Original Version */
/*
#ifdef MODIFY_TITLE
  {   TITLE newtt;
      char buf[80];
      sprintf(buf, "�O�_���峹���D '%s'(Y/N) [N]: ",subject);
      getdata(0, 0, buf, newtt, sizeof(newtt), DOECHO, 0);
      if( newtt[0] == 'y' || newtt[0] == 'Y') {
         sprintf(buf, "�s���D(����Ы�[ENTER])? : ");
         getdata(1, 0, buf, newtt, sizeof(newtt), DOECHO, 0);
         if( newtt[0] ) strcpy(subject, newtt);
      }
#endif   
#ifdef BBSINND
      {   char ans[4];
          getdata(2, 0, "�N���峹�u�o���b���� (Y/N)? [N]: ", ans, sizeof(ans), DOECHO, 0);
          if(ans[0]=='Y' || ans[0]=='y') bbs_post_localsave();
#endif

#ifdef MSIG
	  select_signature();
#endif
          if (bbs_post(currboard, subject, textfile) != S_OK) {
    	      rc = -1;
          }    
#ifdef BBSINND
      }
#endif
#ifdef MODIFY_TITLE
  }
#endif
*/
/* End of Original Version */
  if (textfile == c_tempfile) unlink(c_tempfile);
  return rc;
}            

GenericPost(docheck)
int docheck;
{
  int rc;
  LONG retcode = FULLUPDATE;
  TITLE subject;
  clear();
  if (docheck) {
    SHORT flags;
    if (currboard[0] == '\0') {
      prints("�Х���ܤ@�ӰQ�װ�.\n");
      pressreturn();
      return FULLUPDATE;
    }
    if (bbs_test_board(currboard, &flags) != S_OK) {
      prints("Can't access the '%s' board!\n", currboard);
      pressreturn();
      return FULLUPDATE;
    }
    if (!BITISSET(flags, OPEN_POST)) {
      prints("�z�ثe�S���b '%s' �o�ӰQ�װϵo���峹���v�O.\n", currboard);
      pressreturn();
      return FULLUPDATE;
    }
  }
  bbs_set_mode(M_POSTING);
#ifdef CSIE_ANNOUNCE
  move(3,0);
  BMNote(5);
  move(0,0);
#endif
  prints("�b '%s' �Q�װϵo���峹\n", currboard);
  getdata(1, 0, "�峹���D: ", subject, sizeof(subject), DOECHO, 0);
  if( *subject == '\0') rc = -3;
  else rc = DoPostSend(subject, (char *)NULL, 0);
  clear();
  move(0,0);
  switch (rc) {
  case -3:
    prints("����o���L���D�Τ��e�ťժ��峹.\n");
    break;
  case -2:        
    prints("���o�����g�峹.\n");
    break;
  case -1:
    prints("Error saving post -- board or disk full?\n");
    break;
  case 0:
    prints("�峹�o�����\\!\n");
#ifdef NUM_LOGN_POST
    bbs_add_numposts(1);
#endif
    retcode |= FETCHNEW;
    break;
  }
  if( rc < 0 ) pressreturn();
  /* If docheck is true,  we came in from the main menu -- else, read menu */
  bbs_set_mode(docheck ? M_UNDEFINED : M_READING);
  return retcode;
}

Post()
{
  return (GenericPost(1));
}

/*ARGSUSED*/
PostMessage(hptr, currmsg, numrecs, openflags)
HEADER *hptr;
int currmsg, numrecs, openflags;
{
  if (!BITISSET(openflags, OPEN_POST)) {
    bell();
    return DONOTHING;
  }
  return (GenericPost(0));   /* no need to check post privilege -- we do */
}

/*ARGSUSED*/
ReadMenuSelect(hptr, currmsg, numrecs, openflags)
HEADER *hptr;
int currmsg, numrecs, openflags;
{
  return (SelectBoard());
}

GenericPostReply(hptr, msgsrc)
HEADER *hptr;
char *msgsrc;
{
  TITLE subject,tmp;
  char ans[4];
  int rc, retcode = FULLUPDATE;
  PATH msgfile;
  char genbuf[80];

  /* clear(); */

  if (msgsrc == NULL) {
    if (bbs_read_message(hptr->fileid, msgfile) != S_OK) {
      prints("Can't get the message to followup to!\n");      
      return retcode;
    }
  }
  else strcpy(msgfile, msgsrc);

  move(2,0);
  bbs_set_mode(M_POSTING);
  if (strncasecmp(hptr->title, "Re:", 3)) {
      strcpy(subject, "Re: ");
      strncat(subject, hptr->title, TITLELEN-5);
  }
  else strncpy(subject, hptr->title, TITLELEN-1);
/*
  sprintf(genbuf, "�ϥμ��D '%s' �� (Y/N)? [Y]: ",subject);
  getdata(5, 0, genbuf, ans, 2, DOECHO, 0);
  if(ans[0]=='n' || ans[0]=='N') 
      getdata(6, 0, "�s���D: ", subject, TITLELEN, DOECHO, 0);
*/

  move(3,0); clrtobot(); move(4,0);
  prints("�p�G�z�n�ޥΥ��g�峹�����e�A���קK�L�����ި��y���L�H�\\Ū���K�A\n");
  prints("�Ы� Ctrl-Y ���������n���ި��A���¡C\n");
  getdata(7, 0, "�ޥΥ��g�峹�����e�� (Y/N)? [Y]: ",
	  ans, sizeof(ans), DOECHO, 0);
  if (*ans != 'N' && *ans != 'n') {
    AnnotateMessageBody(c_tempfile, msgfile);
  }

/*  if (BITISSET(hptr->flags, FILE_LOCAL)) bbs_post_localsave();  */

  rc = DoPostSend(subject, c_tempfile, 1);
  clear();
  move(0,0);
  switch (rc) {
  case -3:
    prints("����o�����e�����ťժ��峹.\n");
    break;
  case -2:        
    prints("���o�����g�峹.\n");
    break;
  case -1:
    prints("Error saving post -- board or disk full?\n");
    break;
  case 0:
    prints("�峹�o�����\\!\n");
#ifdef NUM_LOGN_POST
    bbs_add_numposts(1);
#endif
    retcode |= FETCHNEW;
    break;
  }
  if (rc < 0) pressreturn(); 
  bbs_set_mode(M_READING);
  return retcode;
}    

/*ARGSUSED*/
PostReply(hptr, currmsg, numrecs, openflags)
HEADER *hptr;
LONG currmsg, numrecs, openflags;
{
  return (GenericPostReply(hptr, NULL));
}

/*ARGSUSED*/
PostDelete(hptr, currmsg, numrecs, openflags)
HEADER *hptr;
int currmsg, numrecs, openflags;
{
  int rc = FULLUPDATE;
  char ans[4];
  if (strcmp(myinfo.userid,hptr->owner) && !BITISSET(openflags,OPEN_MANAGE)) {
    bell();
    return DONOTHING;
  }
  clear();
  prints("���g���D�� '%s' ���峹�N�Q�R��\n", hptr->title);
  getdata(2,0,"�T�w�n�R���� (Y/N)? [N]: ",ans,sizeof(ans),DOECHO, 0);
  move(4,0);
  if (*ans != 'Y' && *ans != 'y') {
    prints("���R�����g�峹.\n");
  }        
  else {
    if (bbs_delete_message(hptr->fileid) == S_OK) {
      prints("�o�g�峹�w�g�Q�R���F.\n");
#ifdef NUM_LOGN_POST
      if(!strcmp(myinfo.userid,hptr->owner)) bbs_add_numposts(-1);
#endif
      rc |= FETCHNEW;
    }
    else {
      prints("�_��? �R������?\n");
    }
  }
  pressreturn();
  return rc;
}

/*ARGSUSED*/
PostDelRange(hptr, currmsg, numinbox, openflags)
HEADER *hptr;
int currmsg, numinbox, openflags;
{
  int rc = FULLUPDATE;
  char ans[5];
  SHORT n1 = 0, n2 = 0, deleted;
  if (!BITISSET(openflags, OPEN_MANAGE)) {
    bell();
    return DONOTHING;
  }
  clear();
  if (numinbox <= 0) {
    prints("�ثe�S���峹�i�R��!\n");
    pressreturn();
    return rc;
  }
  prints("�R���@�ӽd�򪺤峹\n");
  prints("[�`�N: �Q�ХܹL(marked)���峹�N \"���|\" �Q�R��]\n");
  do {
    if (getdata(2,0,"�п�J���R�����Ĥ@�g�峹�s��: ",
	    ans,sizeof(ans),DOECHO,1) == -1) return rc;
    n1 = atoi(ans);
    if (n1 <= 0 || n1 > numinbox) {
      bell();
      move(3,0);
      prints("�s�����~! �s�����Ӧb 1-%d �o�ӽd��.\n", numinbox);
      pressreturn();
      return rc;
    }        
  } while (n1 <= 0 || n1 > numinbox);
  do {
    if (getdata(3,0,"�п�J���R�����̫�@�g�峹�s��: ",
	    ans,sizeof(ans),DOECHO,1) == -1) return rc;
    n2 = atoi(ans);
    if (n2 < n1 || n2 > numinbox) {
      bell();
      move(4,0);
      prints("�s�����~! �s�����Ӧb %d-%d �o�ӽd��.\n", n1, numinbox);
      pressreturn();
      return rc;
    }        
  } while (n2 < n1 || n2 > numinbox);
  
  move(4,0);
  clrtobot();
  getdata(4,0,"�T�w�n�R���� (Y/N)? [N]: ",ans,sizeof(ans),DOECHO,0);
  move(6,0);
  if (*ans != 'Y' && *ans != 'y') {
    prints("���R�����d�򪺤峹.\n");
  }        
  else {
    if (bbs_delete_range(n1, n2, &deleted) == S_OK) {
      prints("%d �g�峹���\\���Q�R���F.\n", deleted);
      rc |= FETCHNEW;
    }
    else prints("�R�����d�򪺤峹����.\n");
  }
  pressreturn();
  return rc;
}

/*ARGSUSED*/
PostMark(hptr, currmsg, numrecs, openflags)
HEADER *hptr;
int currmsg, numrecs, openflags;
{
  SHORT ismarked = BITISSET(hptr->flags, FILE_MARKED);
  if (bbs_mark_message(hptr->fileid, !ismarked) != S_OK) return DONOTHING;
  if (ismarked) BITCLR(hptr->flags, FILE_MARKED);
  else BITSET(hptr->flags, FILE_MARKED);
  return PARTUPDATE;
}            

/*ARGSUSED*/
PostEdit(hptr, currmsg, numrecs, openflags)
HEADER *hptr;
int currmsg, numrecs, openflags;
{
  struct stat stbuf;
  PATH msgfile;
#ifdef CAN_EDIT_POST
  if (strcmp(myinfo.userid,hptr->owner) && !BITISSET(openflags,OPEN_MANAGE)) {
    bell();
    return DONOTHING;
  }
#else
  if (!BITISSET(openflags, OPEN_MANAGE)) {
    bell();
    return DONOTHING;
  }
#endif

  if (bbs_read_message(hptr->fileid, msgfile) != S_OK) {
    prints("Can't retrieve the post for editing!\n");
    pressreturn();
    return FULLUPDATE;
  }
#ifdef CAN_EDIT_POST
  split_edit_post(c_tempfile, msgfile);
  bbs_set_mode(M_POSTING);
  if (Edit(c_tempfile)) {
    clear();
    prints("�����s�覹�g�峹.\n");
    unlink(c_tempfile);
    pressreturn();
    return FULLUPDATE;
  }
#else
  if (Edit(msgfile)) { 
    prints("�����s�覹�g�峹.\n");
    return FULLUPDATE;
  }
#endif
#ifdef CAN_EDIT_POST
  if (stat(c_tempfile, &stbuf) !=0 || stbuf.st_size == 0) {
    clear();
    prints("�z�s��L���s�峹���e�����ť� -- ���������s��.\n");
    unlink(c_tempfile);
    pressreturn();
    return FULLUPDATE;
  }
#else
  if (stat(msgfile, &stbuf) != 0 || stbuf.st_size == 0) {
    prints("�s��L���s�峹���e�����ť� -- ���������s��.\n");
    return FULLUPDATE;
  }
#endif

  finish_edit_post(msgfile, c_htempfile, c_tempfile);

  switch (bbs_update_message(hptr->fileid, msgfile)) {
  case S_OK:
    clear();
    prints("�峹�s�觹��!\n");
    pressreturn();
    break;
  default:
    clear();
    prints("�峹�s�襢��.\n");
    pressreturn();
  }
#ifdef CAN_EDIT_POST
  unlink(c_htempfile);
  unlink(c_tempfile);
#endif
  return FULLUPDATE;
}            

/*ARGSUSED*/
PostDisplay(hptr, currmsg, numrecs, openflags)
HEADER *hptr;
int currmsg, numrecs, openflags;
{
  char promptstr[80];
  int ans;
  PATH msgfile;
  int rc = FULLUPDATE;
  int done = 0, replied = 0, marked = 0;
  int cant=0;
#if !NO_POST_FOLLOWUP
  int posted = 0;
#endif
#if REMOTE_CLIENT
  int saved = 0;
#endif
  if (bbs_read_message(hptr->fileid, msgfile) != S_OK) {
    prints("Error accessing file.\n");
    pressreturn();
    return rc;
  }
  BITCLR(hptr->flags, FILE_UNREAD);
  clear();
  More(msgfile, 0);
  while (!done) {
    promptstr[0] = '\0';
    if (!replied && HasPerm(C_MAIL)) 
      strcat(promptstr, "(M)�^�Цܧ@�̫H�c ");
#if !NO_POST_FOLLOWUP
    if (!posted && BITISSET(openflags, OPEN_POST))
      strcat(promptstr, "(P)�^�Цb���Q�װ� ");
#endif
#if REMOTE_CLIENT
    if (!saved) strcat(promptstr, "Save ");
#endif

    if (!marked && BITISSET(openflags, OPEN_MANAGE))
      strcat(promptstr, 
	     BITISSET(hptr->flags, FILE_MARKED) ? "(K)�����аO " : "(K)�аO ");

    if (BITISSET(openflags, OPEN_MANAGE) || 
             !strcmp(hptr->owner, myinfo.userid))
      strcat(promptstr, "(D)�R�� ");

    if (!BITISSET(openflags, OPEN_POST)) {
/*
    if (promptstr[0] == '\0') {
      pressreturn();
      break;
*/
    cant = 1;
    }
    else strcat(promptstr, "(C)�~��? [C]: ");
    move(t_lines-1, 0);
/*
    prints(promptstr);
*/
    if(cant) 
      prints("[37;40;0m(��)�U�@�g (��)�e�@�g (F)��H (C,��)�~��? [C]:");
    else
      prints("[37;40;0m(R,��)�^�� (��)�U�@�g (��)�e�@�g (F)��H (C,��)�~��? [C]:");
    ans = igetch();
    switch (ans) {
/*
    case 'm': case 'M': 
      if (replied) done = 1;
      else {
	rc |= MailReply(hptr, currmsg, numrecs, openflags);
	replied = 1;
      }
      break;
#if !NO_POST_FOLLOWUP
    case 'p': case 'P':
      if (posted) done = 1;
      else {
	rc |= GenericPostReply(hptr, msgfile);
	posted = 1;
      }
      break;
#endif
*/
#if REMOTE_CLIENT
    case 's': case 'S':
      if (saved) done = 1;
      else {
	SaveFile(tempfile);
	saved = 1;
      }
      break;
#endif

    case 'F':
      Forward(hptr, currmsg, numrecs, openflags);
      clear();
      break;

/*
    case 'k': case 'K': 
      if (marked) done = 1;
      else {
	PostMark(hptr, currmsg, numrecs, openflags);
	marked = 1;
      }
      break;
    case 'd': case 'D': 
      if (marked) done = 1;
      else rc |= PostDelete(hptr, currmsg, numrecs, openflags);
*/
    case 'R': case 'r': case 'Y': case 'y': case KEY_RIGHT:
	if(!cant) {
	  int ans_r;
	  clear();
#ifdef CSIE_ANNOUNCE
          move(3,0);
          BMNote(5);
          move(0,0);
#endif
          prints("��@��: %s \n����D: %s \n",hptr->owner,hptr->title);
#ifdef BOTH_REPLY
          move(2,0);
          prints("�^�Ш� (M)�@�̫H�c, (F)���Q�װ�, (B)�H�W���, �άO (Q,��)���^�H? [F]: ");
#else
          move(2,0);
          prints("�аݱz�n�^�Ш� (M)�@�̫H�c, (F)���Q�װ�, �άO (Q,��)���^�H? [F]: ");
#endif
          ans_r = igetch();
          switch(ans_r) {
            case 'Q': case 'q': case KEY_LEFT:
             done = 0;
             break;
            case 'M': case 'm':
             prints("M\n");
	     rc |= MailReply(hptr, currmsg, numrecs, openflags);
             break;
#ifdef BOTH_REPLY
            case 'B': case 'b':
             prints("B\n");
             rc |= ReplyToBoth(hptr, currmsg, numrecs, openflags);
             break;
#endif
            default:
             prints("F\n");
             rc |= GenericPostReply(hptr, msgfile);
	  }
	}
	done=1;
	break;
    case KEY_UP:
	rc = KEY_UP;
	done = 1;
        break;
    case KEY_DOWN:
    case ' ':
	rc = KEY_DOWN;
	done = 1;
        break;
      /* fall through */
    default:
      done = 1;
      break;
    }
  }
  return rc;
}

#ifdef BOTH_REPLY
ReplyToBoth(hptr, currmsg, numrecs, openflags)
HEADER *hptr;
int currmsg, numrecs, openflags;
{
  NAMELIST recips=NULL;
  TITLE subject, tmp;
  char an[4];
  PATH msgfile;
  char genbuf[80];
  LONG rcode=FULLUPDATE;

#ifdef MAX_MAILS
  if (CheckMailbox() != S_OK) return FULLUPDATE;
#endif
  if (bbs_read_message(hptr->fileid, msgfile) != S_OK) {
    prints("Ū�����~, �L�k�^�Ц��g�峹!\n");
    pressreturn();
    return FULLUPDATE;
  }
  bbs_set_mode(M_POSTING);
  if (!strchr(hptr->owner, '@'))   /* This is a local mail */
    add_namelist(&recips, hptr->owner, NULL);
  if (strncasecmp(hptr->title, "Re:", 3)) {
    strcpy(subject, "Re: ");
    strncat(subject, hptr->title, TITLELEN-5);
  }
  else strncpy(subject, hptr->title, TITLELEN-1);

  clear();
  prints("�^�Х��g�峹�� '%s' �Q�װϤ� %s ���H�c\n", currboard, hptr->owner);
  prints("�峹���D: %s\n\n", subject);
  prints("�L���Τ��A�����ި��N�y���L�H�\\Ū�W�����K,\n");
  prints("�Ы� Ctrl-Y ���������n���ި�, ����.\n");
  getdata(6,0,"�ޥΥ��g�峹�������e�� (Y/N)? [Y]: ",an,sizeof an,DOECHO,0);
  if (*an != 'N' && *an != 'n') AnnotateMessageBody(c_tempfile, msgfile);
  if (Edit(c_tempfile)) {
    clear();
    prints("���^�Х��g�峹.\n");
    pressreturn();
    unlink(c_tempfile);
    if (recips) free_namelist(&recips);
    return FULLUPDATE;
  }
  else {
    struct stat stbuf;
    if (stat(c_tempfile, &stbuf) != 0 || stbuf.st_size == 0) {
      clear();
      prints("�L�k�^�Ф��e�����ťժ��峹.\n");
      pressreturn();
      unlink(c_tempfile);
      if (recips) free_namelist(&recips);
      return FULLUPDATE;
    }
    else {
      char buf[80];
      char ans[4];
      int local_save_flag = 0;
      int encode = 0;
      LONG retcode=~0;

      ans[0] = ' ';
      while( ans[0] != '\0') {
        move(0,0);
        clrtobot();
#ifdef MODIFY_TITLE
        sprintf(buf, "(T) ���峹���D '%s'\n",subject);
        prints(buf);
#endif
#ifdef BBSINND
        sprintf(buf, "(L) �N���峹 %s\n",(local_save_flag==1)? "�u�o���b������"
: "�o���b�����ΦU��H��");
        prints(buf);
#endif
#ifdef MSIG
        sprintf(buf, "(S,0-3) ���ϥΤ�ñ�W��(�ثe���� [%d] ��)\n", signum);
        prints(buf);
#endif
#ifdef INTERNET_EMAIL
        if (strchr(hptr->owner, '@'))  /* Internet E-mail, ask if uuencode */
          sprintf(buf, "(U) Uuencode? [%c]\n", encode? 'Y' : 'N');
        else
          sprintf(buf, "\n");
        prints(buf);
#endif
        getdata(5,0,"�п�J�n��諸���ةΫ� [ENTER] �i�K�峹: ",ans,3,DOECHO,0);
        switch( ans[0]) {
#ifdef MODIFY_TITLE
          case 'T': case 't':
          {   TITLE newtt;
              sprintf(buf, "�s���D(����Ы�[ENTER])? : ");
              getdata(6, 0, buf, newtt, sizeof(newtt), DOECHO, 0);
              if( newtt[0] ) strcpy(subject, newtt);
          }
          break;
#endif
#ifdef BBSINND
          case 'L': case 'l':
              local_save_flag = !local_save_flag;
          break;
#endif
#ifdef MSIG
          case 'S': case 's':
              if (is_public_acct()) {
                bell();
                break;
              }
              clear();
              select_signature();
          break;
          case '0': case '1':
          case '2': case '3':
              if (is_public_acct()) {
                bell();
                break;
              }
              active_signature((int)(ans[0]-'0'));
          break;
#endif
#ifdef INTERNET_EMAIL
          case 'U': case 'u':
              encode = !encode;
          break;
#endif
          case '\0':
              break;
          default:
              bell();
          break;
        }
      } /* end of while */

#ifdef BBSINND
      if(local_save_flag) bbs_post_localsave();
#endif
      clear();
      if (bbs_post(currboard, subject, c_tempfile) != S_OK)
        prints("�L�k�^�Цb���Q�װ�.\n");
      else {
        prints("�峹�o�����\\.\n");
#ifdef NUM_LOGN_POST
        bbs_add_numposts(1);
#endif
        rcode |= FETCHNEW;
      }
#ifdef INTERNET_EMAIL
      if (!strchr(hptr->owner, '@')) {  /* Local mail */
#endif
        if (bbs_mail(recips, subject, c_tempfile, &retcode) != S_OK)
          prints("�L�k�H�X�^�H.\n");
        else
          prints("���\\���H�X���ʦ^�H.\n");
#ifdef INTERNET_EMAIL
      }
      else {
        if (mail_file_to_outside(c_tempfile, subject, encode, hptr->owner)
            != S_OK)
          prints("�L�k�H�X���ʦ^�H�ܯ��~.\n");
        else
          prints("���\\���N���ʦ^�H�H�X���~.\n");
      }
#endif
      pressreturn();
    }
  }
  if (recips) free_namelist(&recips);
  unlink(c_tempfile);
  return rcode;
}
#endif

