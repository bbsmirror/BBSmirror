
/*
Eagles Bulletin Board System
Copyright (C) 1994, Ray Rocker, rrrocker@rock.b11.ingr.com
                                rock@seabass.st.usm.edu
                                72673.2105@compuserve.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "server.h"
#include <sys/types.h>
#include <time.h>

#define HEADER_TAG_SIZE 11
#define HEADERSIZE      80  /* must be greater than HEADER_TAG_SIZE+TITLELEN */

read_headers(fname, hdr)
char *fname;
HEADER *hdr;
{
  char buf[HEADERSIZE],linecount=0;
  FILE *fp;
  char *hdrdata, *space;
  char *at;

  memset(hdr->owner, '\0', sizeof(hdr->owner));
  memset(hdr->title, '\0', sizeof(hdr->title));
  
  fp = fopen(fname, "r");
  if (fp == NULL) return S_SYSERR;

  hdrdata = buf+HEADER_TAG_SIZE;
  while (fgets(buf, sizeof buf, fp)) {
    strip_trailing_space(buf);
    if (buf[0] == '\0' && ++linecount > 2) break;
    else if( hdr->owner[0] == '\0') {
      if (!strncmp(buf, "From: ", 6)) {
        if (space = strchr(hdrdata, ' ')) *space = '\0';
        strncpy(hdr->owner, hdrdata, ADDRLEN);   /* maybe from Internet :) */
      }
      else if (!strncmp(buf, "Posted By: ", 11)) {
        if (space = strchr(hdrdata, ' ')) *space = '\0';
        strncpy(hdr->owner, hdrdata, NAMELEN);
      }
      else if (!strncmp(buf, "�o�H�H: ", 8)) {
        if (space = strchr(buf+8, ' ')) *space = '\0';
        if(( at = strchr(buf+8, '@')) && !strcmp(at+1, BBSID)) *at='\0';
        strncpy(hdr->owner, buf+8, ADDRLEN);
      }
    } else if( hdr->title[0] == '\0') {
      if (!strncmp(buf, "Title: ", 7))
        strncpy(hdr->title, hdrdata, TITLELEN);
      else if (!strncmp(buf, "��  �D: ", 8))
        strncpy(hdr->title, buf+8, TITLELEN);
      else if (!strncmp(buf, "Subject: ", 9))
        strncpy(hdr->title, hdrdata, TITLELEN);
    }
  }

  fclose(fp);
  return S_OK;
}

struct writetostruct {
  int fd;
  char *buf;
};

write_to_header(indx, userid, info)
int indx;
char *userid;
struct writetostruct *info;
{
  int i;
  int len = strlen(info->buf);
  int needed = strlen(userid)+3;
  if ((HEADERSIZE - len) < needed) {
    strcat(info->buf, ",\n");
    write(info->fd, info->buf, len+2);
    for (i=0; i<HEADER_TAG_SIZE; i++) info->buf[i] = ' ';
    info->buf[HEADER_TAG_SIZE] = '\0';
  }
  else if (len > HEADER_TAG_SIZE) strcat(info->buf, ", ");
  strcat(info->buf, userid);
  return S_OK;
}  

/* What a mess. I should use stdio. */

write_mail_headers(fd, hdr, username, list)
int fd;
HEADER *hdr;
char *username;
NAMELIST list;
{
  char fmt[40];
  char hdrline[HEADERSIZE];
  time_t now = time(NULL);
  struct writetostruct tostruct;
  
  sprintf(fmt, "%%-%ds", HEADER_TAG_SIZE);

  sprintf(hdrline, fmt, "From:");
  strcat(hdrline, hdr->owner);
  strcat(hdrline, " (");
  strcat(hdrline, username);         /* hdrline is big enough */
  strcat(hdrline, ")\n");
  write(fd, hdrline, strlen(hdrline));

  sprintf(hdrline, fmt, "Subject:");
  strcat(hdrline, hdr->title);       /* again, hdrline is big enough */
  strcat(hdrline, "\n");
  write(fd, hdrline, strlen(hdrline));

  sprintf(hdrline, fmt, "Date:");
  strcat(hdrline, ctime(&now));
  write(fd, hdrline, strlen(hdrline));

  sprintf(hdrline, fmt, "To:");
  tostruct.fd = fd;
  tostruct.buf = hdrline;
  apply_namelist(list, write_to_header, &tostruct);
  if (strlen(hdrline) > HEADER_TAG_SIZE) {
    strcat(hdrline, "\n");
    write(fd, hdrline, strlen(hdrline));
  }
  write(fd, "\n", 1);
}

write_post_headers(fd, hdr, username, bname)
int fd;
HEADER *hdr;
char *username;
char *bname;
{
  char fmt[40];
  char hdrline[HEADERSIZE];
  time_t now = time(NULL);
  struct writetostruct tostruct;
  
  sprintf(fmt, "%%-%ds", HEADER_TAG_SIZE);

  sprintf(hdrline, fmt, "Posted By:");
  strcat(hdrline, hdr->owner);
  strcat(hdrline, " (");
  strcat(hdrline, username);         /* hdrline is big enough */
  strcat(hdrline, ") on '");
  strcat(hdrline, bname);
  strcat(hdrline, "'\n");
  write(fd, hdrline, strlen(hdrline));

  sprintf(hdrline, fmt, "Title:");
  strcat(hdrline, hdr->title);       /* again, hdrline is big enough */
  strcat(hdrline, "\n");
  write(fd, hdrline, strlen(hdrline));

  sprintf(hdrline, fmt, "Date:");
  strcat(hdrline, ctime(&now));
  write(fd, hdrline, strlen(hdrline));

  write(fd, "\n", 1);
}

/* This one is used by the client side */

parse_to_list(list, fname, myname)
NAMELIST *list;
char *fname;
char *myname;
{
  FILE *fp;
  char header[HEADERSIZE];
  char *ptr, *id;
  int gotit = 0;

  if ((fp = fopen(fname, "r")) == NULL) return;
  while (fgets(header, sizeof header, fp) && header[0] != '\n') {
    if (!gotit && strncmp(header, "To: ", 4)) continue;
    if (gotit && strncmp(header, "    ", 4)) break;
    gotit = 1;
    ptr = header+4;
    while (id = strtok(ptr, " \t\n,")) {
      ptr = NULL;
      if (strcmp(id, myname) && !is_in_namelist(*list, id))
        add_namelist(list, id, NULL);
    }
  }
  fclose(fp);
}

#ifdef CAN_EDIT_POST
split_edit_post(outfile, infile)
char *outfile, *infile;
{
  FILE *bfp, *ifp;
  char buf[80];
  int ch, lastch=0;
  int i=0, inbody=0;

  if ((bfp = fopen(outfile, "w")) == NULL) return -1; 
  if ((ifp = fopen(infile, "r")) == NULL) {
    fclose(bfp);
    return -1;
  }

  memset(buf, 0, 80);
  while ((ch = fgetc(ifp)) != EOF) {
    if (!inbody) {
      if (ch=='\n') {
        if (lastch=='\n') inbody=1;
        i=0;
      }
    lastch=ch;
    }
    else {
      buf[i++]=ch;
      if (ch=='\n') {
        fprintf(bfp, "%s", buf);
        memset(buf, 0, 80);
        i=0;
      }
    }
  }
  fclose(bfp);
  fclose(ifp);
  return 0;
}

finish_edit_post(srcfile, hfile, bfile)
char *srcfile, *hfile, *bfile;
{
  char buf[80];
  int ch, lastch=0, i=0;
  FILE *ofp, *hfp, *bfp;

  if ((ofp = fopen(srcfile, "r")) == NULL) return -1;
  if ((hfp = fopen(hfile, "w")) == NULL) {
    fclose(ofp);
    return -1;
  }
  memset(buf, 0, 80);
  while ((ch = fgetc(ofp)) != EOF) {
    buf[i++]=ch;
    if (ch=='\n') {
      if (lastch=='\n') break;
      fprintf(hfp, "%s", buf);
      memset(buf, 0, 80);
      i=0;
    }
    lastch=ch;
  }
  fclose(ofp);
  fclose(hfp);

  if ((ofp = fopen(srcfile, "w")) == NULL) return -1;
  if ((hfp = fopen(hfile, "r")) == NULL) {
    fclose(ofp);
    return -1;
  } 
  if ((bfp = fopen(bfile, "r")) == NULL) {
    fclose(ofp);
    fclose(hfp);
    return -1;
  }
  
  i=0;
  lastch=0;
  memset(buf, 0, 80);
  while ((ch=fgetc(hfp)) != EOF) {
    buf[i++]=ch;
    if (ch=='\n') {
      fprintf(ofp, "%s", buf);
      memset(buf, 0, 80);
      i=0;
    }
  }
  fprintf(ofp, "%s", "\n");
  {
    time_t now;
    time(&now);
    fprintf(ofp, "[���峹�g %s �� %s �s��]\n\n", my_userid(),
             Ctime((time_t *)&now));
  } 
  memset(buf, 0, 80);
  while ((ch=fgetc(bfp)) != EOF) {
    buf[i++]=ch;
    if (ch=='\n') {
      fprintf(ofp, "%s", buf);
      memset(buf, 0, 80);
      i=0;
     }
  }
  fclose(ofp);
  fclose(hfp);
  fclose(bfp);
  return 0;
}

  
#endif 
      
  
