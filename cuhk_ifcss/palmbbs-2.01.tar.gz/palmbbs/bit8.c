#include <ctype.h>
#include "keydefs.h"

int allow_esc=1;

bit8_isprint(ch)
int ch;
{
   if( FUNCTION_KEY(ch) ) return 0;
   else return ((ch & 0x80) || (ch==KEY_ESC && allow_esc)) ? 1: isprint(ch);
}

allow_ansi()
{	allow_esc=1;
}

dont_allow_ansi()
{	allow_esc=0;
}

is_allow_ansi()
{	return allow_esc;
}

bit8_isdigit(ch)
{    if(ch>='0' && ch<='9') return 1;
     else return 0;
}

bit8_isalpha(ch)
{    if((ch>='a' && ch<='z') || (ch>='A' && ch<='Z')) return 1;
     else return 0;
}

bit8_isspace(ch)
{    if(ch==' ' || ch=='\n' || ch=='\r' || ch=='\t') return 1;
     else return 0;
}

bit8_isalnum(ch)
{   return (isdigit(ch) || isalpha(ch));
}

bit8_toupper(ch)
{	if(isalpha(ch))
	    return (ch & ~0x20);
	else return ch;
}

bit8_tolower(ch)
{      if(isalpha(ch))
	    return (ch | 0x20);
       else return ch;
}
