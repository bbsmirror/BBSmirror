typedef union {
  int ival ;
  char * sval ;
  NMENUITEM *mival ;
  NMENU *mval ;
} YYSTYPE;
#define	ENVIRONMENT	258
#define	MENU	259
#define	STRING	260
#define	COMMAND	261
#define	OBRACE	262
#define	CBRACE	263
#define	COMMA	264
#define	OPAREN	265
#define	CPAREN	266
#define	ID_NAME	267
#define	INTEGER	268
#define	ERROR	269


extern YYSTYPE yylval;
