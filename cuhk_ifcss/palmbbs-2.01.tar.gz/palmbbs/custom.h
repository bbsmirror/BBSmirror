#ifndef CUSTOM_DEFINED

#define CUSTOM_DEFINED

#define BBSUID 9999
#define BBSGID 99
#define BBSID "Palmarama"
#if SOLARIS
#define BBSHOME "/archive/ebbs"
#endif
#if SUNOS 
#define BBSHOME "/home/ebbs"
#endif
#if LINUX
#define BBSHOME "/home/ebbs"
#endif

/* define this for a chinese 8-bit clean BBS */
#define BIT8

#ifdef BIT8
#include "bit8.h"
#else
#include <ctype.h>
#endif

/* define this to strip out the unneccesary codes of EBBS 3.0 */
/* by muyi */
#define STRIP_OUT

/* define this to enabled cursor menu */
#define CURSOR_MODE

/* define this make users can choose board by cursor */
#define CURSOR_BOARDS

/* define this to have modes of online users like EBBS 2.x */
#define DETAILED_USERMODE

/* defines it makes you keep track of number of logins and posts.
 * To make it work, the cvtbbs must be also recompiled with
 * NUM_LOGN_POST defined in custom.h */
/* Remember it's LOGN instead of LOGIN! */
#define NUM_LOGN_POST

#ifdef NUM_LOGN_POST
#define LOGNNUM_LEN 7
#define POSTNUM_LEN 5
#endif

/* define this makes guest id can post only in certain boards */
#define GUEST_CAN_POST

/* define this makes all guest ids login without password */
#define GUEST_NO_PASSWORD

/* if you would like to run the bbs <-> innd programs of nctu csie
   to exchange posts, this must be defined */
#define BBSINND

/* define this if you use the 'viewer' of nctu csie for digest */
#define CSIE_ANNOUNCE

/* define this if you want to enable Internet E-mail */
#define INTERNET_EMAIL

/* define this to show ANSI mode menu */
#define ANSIMENU

/* define this to keep the first login time */
#define FIRSTLOGIN_TIME

/* define this to enable vote */
#define VOTE

/* define this to show mutiple BM name lists */
/* by muyi */
#define SHOW_BM

/* define this to use group boards */
/* by muyi */
#define B_GROUP

/* define this to collect deleted post to another board */
#define COLLECT_DELETED
#ifdef COLLECT_DELETED
#define DELETED "Deleted"
#endif

/* define this to enable crosspost to another board */
/* not yet implemented */
#define CROSSPOST

/* sub topic of boards, for BM */
/* not yet implemented */
/* by muyi */
/* #define SUBTOP */

/* 3 signatures */
/* by muyi */
#define MSIG

#define MODIFY_TITLE    	/* enable modifying title after Edit */
#define SEARCH_POSTS   	/* search title & author of posts */
#define PROMPT_NUMUSERS /* see number of online people when login */
#define KICK_SELFLOGIN  /* allow users kill self multi-logins */

#if !SUNOS
/* #define GET_LOADAVG     /* get load information */
#endif

/* if ~bbs/etc/nologin exists, all logins denied except from HOST_ALLOW */
/* it's the easiet way to temporarily stop the bbs */
#define ETC_NOLOGIN
#ifdef ETC_NOLOGIN
#define HOST_ALLOW "bbs.ntu.edu.tw"
#endif

/* define this to use select on board menu */
/* by muyi */
#define SEARCH_BOARD

/* ha, bbs address but no net... :) */
/* by muyi */
#define BBS_NET

/* define this to enable friends function */
#define LIST_FRIENDS

/* define this for ansi Cat */
#define ANSI_CAT

/* cache file list to disk to speed up while reading board */
#define CACHED_OPENBOARD

/* define this to enable send group mail by override list */
#define OVERRIDE_SEND_MAIL 

/* get remote host if not login with /bin/login */
#define NO_BINLOGIN

/* implemented NAMELIST as array for performance */
#define NAMELIST_IN_ARRAY

/* check home dirctory every login, if lost then auto make it, */
/* and send a mail to tell the user */
#define LOGIN_CHECK_HOMEDIR

/* forward mail of sysop to someone */
#define MAIL_TO_SYSOP "Muyi"

/* define this to check mailbox when querying */
#define QUERY_CHECK_MAIL

/* define this to do some modify for users' convinient */
/* by muyi */
#define CHAT_MODIFY

/* define this to have multiple talk request deny reason */
/* by muyi */
#define TALK_DENY_REASON

/* define this to enable to reply to both board and author's mailbox */
#define BOTH_REPLY 
/* �������g�L�F�A���լݬ� -- jjshen */

/* cache the headers to disk to improve performance */
/* by joechen */
#define CACHED_HEADERS

/* lock screen until entering correct password */
#define LOCK_SCREEN

/* can user change her/his realname in XYZ/INFO menu? */
/* by samlee */
/* i think it's a good evidence to proove the id's owner, so it's 
   better not to let user be able to modify it */
/* #define USER_CHANGE_REALNAME  */

/* make the included messages display in a different color */
#define COLOR_INCLUDED_MSG

/* can use cursor keys when read mails */
#define READ_MAIL_USE_CURSOR 

/* guest doesn't need to check new mail */
#define GUEST_DONT_CHECK_MAIL

/* let the owner and BM be able to edit posts */
#define CAN_EDIT_POST

/* system full, auto logout */
#define FULL_LOGOUT

/* limit users' mail box number */
#define MAX_MAILS 100

/* public accounts can't vote on boards */
#define PUB_ACCT_CANT_VOTE

/* personal note book */
#define NOTE_EDIT

/* bbs system load limit */
/* #define LOAD_LIMIT 20.00 */

/* forward a range of mails */
#define MAIL_FORWARD_RANGE 

/* can mark mail */
#define MARK_MAIL 

/* check the percentage of included article body */
#define CHECK_INCLUDED 

/* for finger from other hosts */
#define OUT_FINGER

/* for inline nctu csie announce */
#define INLINE_DIGEST

/* for id change unstable */
#define FIX_ID

/* for cross-post to another board */
/* press X when readmenu */
/* just for sysop to test so far */
#define CAN_CROSSPOST

/* for unwelcomed users */
#define DISABLED_ACCOUNT "etc/disabled"

/* set up 3 mail lists to send mail */
#define LIST_SEND_MAIL

#endif /* the whole custom.h */
