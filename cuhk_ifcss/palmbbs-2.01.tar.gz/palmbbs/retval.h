
/*
Eagles Bulletin Board System
Copyright (C) 1994, Ray Rocker, rrrocker@rock.b11.ingr.com
                                rock@seabass.st.usm.edu
                                72673.2105@compuserve.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/


/*
   Return values for the bbs library functions. Used all over in the server.
*/

#define S_OK		0
#define S_SYSERR	1
#define S_DENIED	2
#define S_NOTFOUND	3
#define S_EXISTS	4
#define S_INVALID       5
#define S_FULL          6
#define S_NOUPDATE      7
#define S_DISABLED      8
#define S_UNAVAILABLE   9
#define S_ILLEGAL       10
#define S_TEMPFAIL      11

#ifdef TALK_DENY_REASON
#define S_DENIED1	101
#define S_DENIED2	102
#define S_DENIED3	103
#define S_DENIED4	104
#endif

/* 
   ENUM_QUIT is never returned by the library functions, but is to be
   returned by the functions called by the enumeration-type library
   functions when they want to quit enumerating.
*/

#define ENUM_QUIT	666


