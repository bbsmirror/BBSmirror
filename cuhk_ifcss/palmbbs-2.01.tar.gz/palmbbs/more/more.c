#include <stdio.h>
#include "osdeps.h"
#include "pbbs/io.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
int input_active;

generic_abort()
{   exit(-1);
}

int
main(argc, argv)
int argc;
char **argv;
{
    int promptend=0;
    char termtype[80];
    extern int t_lines;
    
    if(argc==1) {
	printf("Usage: %s filename\n", argv[0]);
        exit(-1);
    }

  if (get_tty() == -1) {
    perror("tty");
    fprintf(stderr, "�L�k���o�z���׺ݾ������]�w!\n");
    return 1;
  }

  init_tty();
 
    strcpy(termtype, getenv("TERM"));
    if(term_init(termtype)==-1) term_init("dumb");
    initscr();

    more(argv[1], 0);
    move(t_lines-2, 0);
    refresh();
}
