 
/*
Eagles Bulletin Board System
Copyright (C) 1994, Ray Rocker, rrrocker@rock.b11.ingr.com
                                rock@seabass.st.usm.edu
                                72673.2105@compuserve.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "osdeps.h"
#include "modes.h"

#ifndef DETAILED_USERMODE

char *
ModeToString(mode)
SHORT mode;
{
  switch (mode) {
  case M_MAIL: return("Mail");
  case M_READING: return("Reading");
  case M_POSTING: return("Posting");
  case M_ULDL: return("UL/DL");
  case M_CHAT: return("Chat");
  case M_MONITOR: return("Monitor");
  case M_TALK: return("Talk");
  case M_PAGE: return("Page");
  default: return("");
  }
}

char
ModeToChar(mode)
SHORT mode;
{
  switch (mode)
    {
    case M_MAIL: return('M');
    case M_READING: return('R');
    case M_POSTING: return('P');
    case M_ULDL: return('U');
    case M_CHAT: return('C');
    case M_MONITOR: return('m');
    case M_TALK: return('T');
    case M_PAGE: return('p');
    default: return(' ');
    }
}

#else

char *
ModeToString(mode, s)
SHORT mode;
char *s;
{
   static char buf[24] ; 
   char str[20]; 

   if(s[0]) sprintf(str, "'%s'", s);
   else sprintf(str, "");

   switch(mode)
  {
	case IDLE: return "�o�b��" ;
	case NEW: return "�s�٦���U��" ;
	case LOGIN: return "�w��e��";
        case ANNOUNCE: return "��ذ�";

	case MAINMENU: return "�D���";
	  case CNTBRDS: return "Count";
	  case VISIT: return "�N�峹�Ь��wŪ";
	  case ZAP: return "�]�w�Q�װ�";
	  case LAUSERS: return "�C�X���������ϥΪ�"; 
	  case SELECT: return "��ܰQ�װ�";
          case READNEW: return "�\\Ū�s�峹" ;
	  case ADMIN: return "�B�z����";
	  case SHOW: return "��ܰQ�װ�";
	    case POSTING: return "�o���峹" ;
	    case READING: return "�\\Ū�峹";
          case MAILMENU: return "�H����" ;
	    case SMAIL: return "�H�H��"; 
	    case RMAIL: return "Ū�H��"; 
	  case TMENU: return "�ͤѻ��a���";
	    case TALK: sprintf(buf, "�M%s�ͤ�", str); return buf;
            case LUSERS: return "�ݽ֦b�u�W";  
	    case FRIENDS: return "�M��u�W�n��";
	    case CHAT: sprintf(buf, "%s��ѫ�", str); return buf;
	    case PAGE: sprintf(buf, "�I�s %s", str); return buf;
	    case MONITOR: return "�ʬݤ�";
	    case QUERY: sprintf(buf, "�d�� %s", str); return buf;
	    case IRCCHAT: return "IRC Chat";
	  case XMENU: return "�u��c";
	    case EDITWELC: return "�s���w��e��";
	    case EDITSIG: return "�s��ñ�W��";
	    case EDITPLAN: return "�s��W����";
	    case VOTING: return "�벼��";
            case BBSNET: return "BBS �C��";
        case NTUMENU: return "�x�j�t�ҿ��"; 
	case ULDL: return "UL/DL" ;
#ifdef LOCK_SCREEN
        case LOCKSCRN: return "���}�@�U�U";
#endif
#ifdef NOTE_EDIT
	case NOTEEDIT: return "�s��Ƨѿ�";
#endif
	default: return "�����D�b��ԣ" ;
   }
}


char
ModeToChar(mode)
SHORT mode;
{
   switch(mode)
  {

	case SMAIL: 
	case RMAIL: 
        case MAILMENU: 
		return 'M' ;

	case READING:
		return 'R' ;

        case POSTING: 
		return 'P' ;

/*
	case ULDL:
*/
	case LAUSERS:
        case LUSERS:
		return 'U' ;

	case CHAT:
		return 'C' ;

	case MONITOR:
		return 'm' ;
	
	case TALK:
		return 'T' ;

	case PAGE:
		return 'P' ;

	case IDLE:
	case NEW:
        case READNEW:
	case MAINMENU:
	case XMENU:
	case TMENU:
	case ADMIN:
	case LOGIN:
	case SHOW:
	case SELECT:
	case EDITWELC:
	case ZAP:
	case EDITSIG:
	case EDITPLAN:
	case QUERY:
	case CNTBRDS:
	case VOTING:
	case VISIT:
	case IRCCHAT:
        case BBSNET:
        case NTUMENU:
	case ANNOUNCE:
#ifdef LOCK_SCREEN
        case LOCKSCRN:
#endif
#ifdef NOTE_EDIT
	case NOTEEDIT:
#endif
	default:
		return ' ';
   }
}

#endif
