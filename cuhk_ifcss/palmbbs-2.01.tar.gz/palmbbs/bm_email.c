#include "server.h"
#include <sys/stat.h>

extern USERDATA user_params;
NAME curruserid;
TITLE save_title;
char genbuf[1024];
TITLE save_filename;

#include "bmviewer.c"

int 
dosearchuserid(userid,passwd)
char *userid,*passwd;
{
	ACCOUNT acct;

	if (_lookup_account(userid, &acct) != S_OK) {
	    bbslog(1, "BADUSERID %s \n", acct.userid);
	    printf("\n\nBad userid.\n\n");
	    exit(-1);
	} 
	if (!is_passwd_good(acct.passwd, passwd)) {
            bbslog(1, "BADPASSWORD %s \n", acct.userid);
	    printf("\n\nBad password.\n\n");
	    exit(-1);
  	}
  	if (acct.flags & FLG_DISABLED) {
	    bbslog(1, "ID DISABLED %s \n",  acct.userid);
	    printf("\n\nID disabled.\n\n");
	    exit(-1);
	}
	init_perm_strs();	/* load permssion settings 	*/
	init_perms();		/* see if has post permission 	*/
  	_determine_access(acct.perms, user_params.access);
	strcpy(curruserid, acct.userid);
	strcpy(user_params.u.userid, acct.userid);
	user_params.perms=acct.perms;
	return 1;
}

dosearchboard(bname,board)
char *bname;
BOARD *board;
{	if(_lookup_board(bname,board)!=S_OK) {
	    bbslog(1, "NO SUCH BOARD %s board: %s\n"
			,curruserid, bname);
	    printf("\n\nNo such board\n\n");
	    exit(-1);
	}
	else if(!_has_read_access(board)) {
	    bbslog(1, "NO READ PERM  %s on board: %s\n"
			,curruserid, board->name);
	    printf("\n\nNo such board\n\n");
	    exit(-1);
	}
	else if(!_has_post_access(board)) {
	    bbslog(1, "NO POST PERM  %s on board: %s\n"
			,curruserid, board->name);
	    printf("\n\nPost restricted\n\n");
	    exit(-1);
	}
	else if(!_has_manager_access(board)) {
	    bbslog(1, "NOT BM %s of board: %s\n"
			,curruserid, board->name);
	    printf("\n\nNot BM\n\n");
	    exit(-1);
	}
}

main(argc, argv)
int argc;
char *argv[];
{
  NAME userid;
  NAME newboard;
  PASSWD passwd;
  BOARD curboard;
  ACCOUNT acct;
  TITLE subject;
  char *tmp;
  char a[4096];
  FILE *fptr;
  PATH tmppath;
#ifdef CACHED_OPENBOARD
  extern int extern_util;

  extern_util = 1;
#endif
  home_bbs(BBSHOME);
  open_bbslog("emaillog",1);  /* open a log file or the bbslog() will fail */
  set_log_header("BM E-mail post:");
  umask(0007);
  while(gets(a)!=NULL && a[0]!='#') ;   /* skip the header */
  if(a[0]=='#')
  {	sscanf(strchr(a,':')+1,"%s",userid);
        gets(a);
        sscanf(strchr(a,':')+1,"%s",passwd);
	dosearchuserid(userid,passwd);

        gets(a);
        sscanf(strchr(a,':')+1,"%s",newboard);
	dosearchboard(newboard,&curboard);
	chdir("0Announce");
	chdir(curboard.name);

	gets(a);
        if(a[0]=='#') {
            tmp=strchr(a,':');
            do { tmp++; } while(*tmp==' ' && *tmp!='\0');
            strcpy(subject,tmp);
        }
        else  subject[0]='\0'; 
        strncpy(save_title, subject, TITLELEN);
	save_title[TITLELEN]='\0';

        gets(genbuf);
        sscanf(strchr(genbuf,':')+1,"%s",a);
        tmp=strrchr(a,'/');
        if(tmp!=NULL)
        {       char tmppath[STRLEN];
                strcpy(tmppath,a);
                tmppath[tmp-a]='\0';
                if(!dashd(tmppath))
                {   bbslog(1,"bad path %s by %s\n",tmppath, curruserid);
		    printf("\n\nbad path %s\n", tmppath);
		    printf("please check if it exists\n\n");
		    exit(-1);
                }
                else
                {  if(chdir(tmppath)==-1)
                       bbslog(1, "can't chdir %s by %s\n", tmppath, curruserid);
                   else strcpy(save_filename,tmp+1);
                }
        }
        else strcpy(save_filename,a);
	domenu();
        bbslog(1, "post '%s' on '%s' by %s\n", save_title, curboard.name,
			curruserid);
        return 0;
    }
    else {
	bbslog(1, "can't find begin line \n");
	printf("\nCan't find begin line!\n");
	printf("Please check if the format is correct!\n\n");
	return -1;
    }
}
