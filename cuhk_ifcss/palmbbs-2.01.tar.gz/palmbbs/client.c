
/*
Eagles Bulletin Board System
Copyright (C) 1994, Ray Rocker, rrrocker@rock.b11.ingr.com
                                rock@seabass.st.usm.edu
                                72673.2105@compuserve.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/* #define NEED_CORE */

#include "client.h"
#include <signal.h>
#include <time.h>

BBSINFO serverinfo;		/* server's info structure */
LOGININFO myinfo;               /* user's info structure */

PATH c_tempfile;                /* work file for the client side */
#ifdef CAN_EDIT_POST
PATH c_htempfile;
#endif
int input_active;               /* for the idle timer */
#ifdef MAX_MAILS
int total_mails;
#endif

extern PromptForAccountInfo();
extern SetPermTable();
extern DoMenu();
extern MENUITEM cmdlist[];
extern void page_handler __P((int));
extern char *Ctime __P((time_t *));
#ifdef NO_BINLOGIN
extern HOST myfromhost;
#endif

disconnect(status)
int status;
{
  unlink(c_tempfile);
  if (status != EXIT_LOSTCONN) bbs_disconnect();
  if (fullscreen()) {
    clear();
    refresh();
  }
  else oflush();
  reset_tty();
  printf("\n");
  switch (status) {
  case EXIT_LOGOUT:
#ifdef AUX
    clear();
#endif
    printf("Goodbye!\n");
    break;
  case EXIT_CLIERROR:
    printf("Something's wrong. Exiting.\n");
    break;
  case EXIT_LOSTCONN:
    printf("Server closed connection. Exiting.\n");
    break;
  case EXIT_TIMEDOUT:
    printf("�z�b�t�Τ����m�L�[. ���� BBS..\n");
    break;
  default:     /* assumed to be a signal */
    if (g_child_pid != -1) {
      kill(g_child_pid, status);
    }
    switch (status) {
    case SIGHUP: 
    case SIGINT: 
      printf("Interrupt signal received. Goodbye!\n");
      break;
    case SIGQUIT: 
      printf("Quit signal received. Goodbye!\n");
      break;
    case SIGTERM: 
      printf("Terminate signal received. Goodbye!\n");
      break;
    default: 
      printf("Bad news: signal %d received. Run! Flee!\n", status);
#ifdef NEED_CORE
      abort();
#endif
      break;
    }
    break;
  } 
  exit(status);
}

generic_abort()		/* general "bail and exit" */
{
  disconnect(EXIT_CLIERROR);
}

void
sig_handler(sig)
int sig;
{
  disconnect(sig == SIGALRM ? EXIT_TIMEDOUT : sig);
}

void
hit_alarm_clock()
{
  if (!input_active) {
    disconnect(EXIT_TIMEDOUT);
  }
  input_active = 0;
  signal(SIGALRM, hit_alarm_clock);
  if (myinfo.idletimeout) alarm((int)myinfo.idletimeout*60);
}

set_idle_alarm()
{
  if (myinfo.idletimeout != 0) {
    signal(SIGALRM, hit_alarm_clock);
    alarm((int)myinfo.idletimeout*60);
  }
}

cancel_idle_alarm()
{
  alarm(0);
}

void
InitializeTerminal()
{
  ACCOUNT acct;
  if (bbs_owninfo(&acct) != S_OK) {
    prints("�L�k���o�z���b�����!\n");
    prints("�׺ݾ������]�w�� 'dumb'.\n");
    term_init("dumb");
    return;
  }
  if (term_init(acct.terminal) == -1) {
    prints("�t�εL�k�A�ѱz�ҳ]�w���׺ݾ�: '%s' !\n", acct.terminal);
    prints("�׺ݾ������]�w�� 'dumb'.\n");
    term_init("dumb");
  }
}

Login(newok)
SHORT newok;
{
  ACCOUNT acct;
  int rc;
  int new=0;
  int repeat_count=0;

  char *ustr = (newok ? "�s�ϥΪ̽п�J 'new' ���U\n�п�J�N��: " : "�п�J�N�� (�ΥH 'guest' ���[, Ctrl-C to leave): ");

  alarm(60);   /* You get one minute to log in succesfully */

#ifdef PROMPT_NUMUSERS
    prints("�ثe�u�W�H�� [%d/%d] �H\n\n", online_users(), system_maxusers());
#endif

#ifdef FULL_LOGOUT
    {  HOST host;
       get_remote_host(host);
       if((online_users() > system_maxusers()) && strcmp(host,HOST_ALLOW) &&
        strcmp(host,"palm1.ntu.edu.tw") && strcmp(host, "localhost")) {
          prints("\nBBS �t�Υثe�W�u�H���B��. �еy��A��.\n\n");
	  refresh();
	  sleep(3);
          disconnect(EXIT_LOGOUT);
       }
    }
#endif

  do {

    if (getdata(0, 0, ustr, acct.userid, sizeof(acct.userid), DOECHO, 1) == -1)
      disconnect(EXIT_LOGOUT);
    if (acct.userid[0] == '\0') {
      rc = S_INVALID;
      goto login_switch;
    }

    if (newok && !strcmp(acct.userid, "new")) {
      /* Give them five minutes to enter new user data */
      new = 1;
      alarm(300);
      PromptForAccountInfo(&acct, 1);
      rc = bbs_newlogin(&acct, &myinfo);
    }
    else {
#ifdef GUEST_NO_PASSWORD
      rc = bbs_guestid(acct.userid);
      if( rc != S_OK ) {
#endif
      getdata(0, 0, "�п�J�K�X: ", acct.passwd, sizeof(acct.passwd), NOECHO, 0);
#ifdef GUEST_NO_PASSWORD
     }
#endif
	rc = bbs_login(acct.userid, acct.passwd, 0, &myinfo);
	if( rc == S_FULL && _has_perms(PERM_SYSOP)) rc = S_OK; 
    }
login_switch:
    if (++repeat_count == 3 && rc == S_INVALID) {
      prints("\n+-=-=-=-=-=-= [1;37;44mbbs.ntu.edu.tw[0m -=-=-=-=-=-=-+\n");
      prints("| ��p, �z�w�g�s�� %d �� login ���~, �A��! |\n", repeat_count);
      prints("| �p���ðݥi mail ���H�U���@�H:           |\n");
      prints("|     SYSOP.bbs@bbs.ntu.edu.tw            |\n");
      prints("|     Muyi.bbs@bbs.ntu.edu.tw             |\n");
      prints("|     jjshen.bbs@bbs.ntu.edu.tw           |\n");
      prints("+-=-=-=-=-=-=- [1;33;46m140.112.1.6[0m -=-=-=-=-=-=-=-+\n\n");
      disconnect(EXIT_LOGOUT);
    }
    switch (rc) {
    case S_OK:
#ifdef KICK_SELFLOGIN
      if(!(myinfo.flags & FLG_SHARED)) {
         int ans;
         if(my_total_logins() > 1) {
               prints("\nWould you like to kill your other login? [Y]: ");
               ans = igetch();
               if( ans != 'n' && ans != 'N') kick_otherlogin();
         }
#ifdef VOTE
         else {
               char *bbshome,votelock[80];
               home_bbs( bbshome);
               sprintf(votelock,"home/%s/.votelock",acct.userid);
               if( dashf( votelock)) {
                   unlink(votelock);
               }
         }
#endif
      }
#endif
      break;
    case S_INVALID:
      prints("\n�N���αK�X���~.\n\n");
      break;
    case S_FULL:
      prints("\nBBS �t�Υثe�W�u�H���B��. �еy��A��.\n\n");
      sleep(3);
      disconnect(EXIT_LOGOUT);
      break;
    case S_DISABLED:
      prints("\n���N�������Υثe�L�k�ϥΡA���ðݽХ� guest �� SYSOP �O�ӶD�C\n\n");
      disconnect(EXIT_LOGOUT);
      break;
    case S_DENIED:
    case S_TEMPFAIL:
      prints("\n��p, ���N���w�g��F�W�u���ƭ���.\n\n");
      if (rc == S_TEMPFAIL) {
        char ans[4];
        getdata(0,0,"�����z�b�t�Τ���L���W�u (Y/N)? [Y]: ",ans,sizeof ans,DOECHO,0);
        if (*ans == 'N' || *ans == 'n') disconnect(EXIT_LOGOUT);
        rc = bbs_login(acct.userid, acct.passwd, 1, &myinfo);
	goto login_switch;
      }
      else disconnect(EXIT_LOGOUT);
      break;
    default: prints("\nLogin Abort.\n\n");
    }          
  } while (rc != S_OK);
  alarm(0);
  set_idle_alarm();
#ifdef DETAILED_USERMODE
  if(new) bbs_set_mode(NEW);
  else bbs_set_mode(LOGIN);
#endif
  return 0;
}

main(argc, argv)
int argc;
char *argv[];
{
  int rc;
  PATH fname;

#ifdef NO_BINLOGIN
  setgid(BBSGID);
  setuid(BBSUID);
  if(argc>1) strncpy(myfromhost, argv[1], HOSTLEN);
  else myfromhost[0]='\0';
#endif

  if (get_tty() == -1) {
    perror("tty");
    fprintf(stderr, "�L�k���o�z���׺ݾ������]�w!\n");
    return 1;
  }
  
#ifdef NO_BINLOGIN
  home_bbs(BBSHOME);
#else
  home_bbs(NULL);
#endif

  if ((rc = bbs_initialize()) != S_OK) {
    switch (rc) {
    case S_NOTFOUND:
      printf("Cannot open bbs config file!\n");
      printf("Make sure BBSHOME points to the bbs home directory.\n");
      break;
    default:
      printf("bbs initialize failed!\n");
    }
    return 1;
  }

  sprintf(c_tempfile, "tmp/bbl%05d", getpid());
#ifdef CAN_EDIT_POST
  sprintf(c_htempfile, "tmp/bbh%05d", getpid());
#endif

  bbs_connect(&serverinfo);
    
  signal(SIGHUP, sig_handler);
  signal(SIGINT, sig_handler);
  signal(SIGQUIT, sig_handler);
  signal(SIGILL, sig_handler);
#ifndef NEED_CORE
  signal(SIGIOT, sig_handler);
#endif
#ifdef SIGEMT
  signal(SIGEMT, sig_handler);
#endif
  signal(SIGFPE, sig_handler);
#ifdef SIGBUS
  signal(SIGBUS, sig_handler);
#endif
  signal(SIGSEGV, sig_handler);
#ifdef SIGSYS
  signal(SIGSYS, sig_handler);
#endif
  signal(SIGPIPE, sig_handler);
  signal(SIGTERM, sig_handler);
  signal(SIGALRM, sig_handler);
  signal(SIGCHLD, SIG_DFL);
  signal(SIGIO, SIG_IGN);
  signal(SIGURG, SIG_IGN);
#ifdef SIGPWR
  signal(SIGPWR, sig_handler);
#endif

  /* This is how the local client gets paged -- via SIGUSR1. */
  signal(SIGUSR1, page_handler);

#ifdef ETC_NOLOGIN
    {   HOST host;
       char buf[80];
       FILE *fp = fopen("etc/nologin", "r");
       get_remote_host(host);
        if(strcmp(host,HOST_ALLOW) && strcmp(host, "localhost")) {
           if (fp) {
               fprintf(stderr, "\n");
               while (fgets(buf, sizeof(buf), fp)) fprintf(stderr,buf);
               fclose(fp);
                fprintf(stderr, "\n");
               sleep(3);
               exit(0);
           }
       }
    }
#endif

  init_tty();
  
#ifdef GET_LOADAVG
  {  double load[3]={01.23,45.67,89.10};
     char buf[80];

     get_load(load);

#ifdef LOAD_LIMIT
     sprintf(buf, "�t�Υ����t��: %.2f %.2f %.2f [�t�ΤW�� %.2f]", load[0], load[1], load[2], LOAD_LIMIT);
     prints("\n%s\n", buf);
     if( load[2] > LOAD_LIMIT)
     {  HOST host;
        get_remote_host(host);
        if( strcmp(host,HOST_ALLOW) && strcmp(host, "localhost")
           && strcmp(host,"palm1.ntu.edu.tw")) {
           prints("\nBBS �t�Υثe�t���q�L���C\n���F�j�a�ϥΪ���K�A�еy��A�աC���¡I\n\n");
 	   refresh();
	   sleep(3);
           disconnect(EXIT_LOGOUT);
        }
     }
#else
     sprintf(buf, "�t�Υ����t��: %.2f %.2f %.2f", load[0], load[1], load[2]);
     prints("\n%s\n", buf);
#endif
     refresh();
  }
#endif

  prints("\n[1;34m�w[35m��[33m�Y[31m�{ [37m%s[m\n", serverinfo.boardname);
  if (bbs_get_issue(fname) == S_OK) 
	Cat(fname);
  
  Login(serverinfo.newok);
  SetPermTable();

  if (ParseMenu() == -1) {
    disconnect(EXIT_LOGOUT);
  }

  if(Cat("etc/welcome.ntu")!=-1) pressreturn();
  InitializeTerminal();
  initscr();
  clear();
  if (bbs_get_welcome(fname) == S_OK) {
    if (myinfo.lastlogin == 0) More(fname, 1);
    else {
      More(fname, 0);
#ifdef VOTE
      {
         if( check_polls("_SYSTEM_",NULL,NULL) && !is_public_acct()){
            move(0, 0);
            prints("[1m[�t�Χ벼��][m [7m�Ц� (X)yz/(V)ote �U��U�z���t�@��[m");
         }
      }
#endif
    }
  }
  
#ifdef NUM_LOGN_POST
  bbs_add_numlogins();

  {
    ACCOUNT acct;
    _lookup_account((char *)my_userid(), &acct);

    if(!(acct.perms & PERM_3DAYS) && !BITISSET(acct.flags, FLG_SHARED)) {
	time_t now, firsttime;
	time(&now);
	get_firstlog_time(my_userid(), &firsttime);
	if((now-firsttime)/86400 >= 3) {
	    bbs_modify_perms( acct.userid, acct.perms | PERM_3DAYS);
	}
    }
  }
#endif

    {
      char buf[80], host[21], ans;
      memset(host, '\0', sizeof host);
      strncpy(host, myinfo.fromhost, sizeof(host)-1);
      if (myinfo.lastlogin)
        sprintf(buf, "�e���W�u %s �Ӧ� %s [RETURN]: ",
              Ctime((time_t *)&myinfo.lastlogin), host);
      else
        sprintf(buf, "�����W�u���z�Ĥ@�����{���� [RETURN]: ");
      getdata(t_lines-1, 0, buf, &ans, 1, NOECHO, 0);
    }
    if( is_public_acct()) {
	clear();
	More("etc/intro.guest", 1);
    } else if (!_has_perms(PERM_3DAYS)) {
      clear();
      More("etc/intro", 1);
    }
#ifdef MAX_MAILS
  total_mails=msgs_in_mailbox(1);
  CheckMailbox();
#endif    

  NDoMenu("Main") ; /* Start at the Main Menu */
  disconnect(EXIT_LOGOUT);
}


Goodbye()
{
  ACCOUNT acct;
  char ans[4];
  int day=0, hour=0, min=0, sec=0;

  getdata(2,0,"�z�M�w�n���} �����L������ �F? [N]: ", ans, sizeof(ans),
               DOECHO, 0);
  if (*ans == 'Y' || *ans == 'y') {
    bbs_query((char *)my_userid(), &acct);
    {
      time_t now;
      int totaltime=0;
      
      time(&now);
      totaltime=now-acct.lastlogin;
      day=totaltime/86400;
      hour=(totaltime-day*86400)/3600;
      min=(totaltime-day*86400-hour*3600)/60;
      sec=totaltime-day*86400-hour*3600-min*60;
    }
    clear();
    move (0,0);
    prints("�A���F, �˷R�� %s (%s)!\n\n", acct.userid, acct.username);
    prints("    �z�`�@���X�L���� %s ��\n", acct.numlogins);
    prints("    �z�`�@�b�����o���L�峹 %s �g\n", acct.numposts);
    prints("    �z�����W�u�O�Ӧ۩� %s\n", acct.fromhost);
    prints("    �z�����W�u�ɶ��� %s\n", Ctime((time_t *)&acct.lastlogin));
    prints("    �z�������d�ɶ��� ");
    if (day) prints("%d �� ", day);
    if (hour) prints("%d �p�� ", hour);
    prints("%d �� %d ��\n", min, sec);
    prints("\n�x�j�p�� [1m�����L������[m BBS �w��z�~��Y�{����\n");
/*    pressanykey(); */ /* delayed by telnetd */
#ifdef NUM_LOGN_POST
/*
    _lookup_account((char *)my_userid(), &acct);
    if( !(acct.perms & PERM_LOGINS30) && (atoi(acct.numlogins) > 29)
	&& !BITISSET(acct.flags, FLG_SHARED)) {
	bbs_modify_perms( acct.userid, acct.perms | PERM_LOGINS30);
    }
*/
    if (!_has_perms(PERM_LOGINS30)) {
      _lookup_account((char *)my_userid(), &acct);
      if ((atoi(acct.numlogins) > 29) && !BITISSET(acct.flags, FLG_SHARED)
          && _has_perms(PERM_BASIC3))
        bbs_modify_perms(acct.userid, acct.perms | PERM_LOGINS30);
    }
#endif

/* this part will clear the old 17th perm for 3DAYS */
/* begin to clear on Apr 3 and i think it should work for 60 days */
/* it can be removed after Jun 3 */
    if ((acct.perms & PERMBIT(16)) && !_has_perms(PERM_SYSOP))
      bbs_modify_perms(acct.userid, acct.perms ^ PERMBIT(16));

    pressanykey();
    return (EndMenu()); 
  }
  else {
    move (2,0);
    clrtoeol();
    return 0;
  } 
}  
