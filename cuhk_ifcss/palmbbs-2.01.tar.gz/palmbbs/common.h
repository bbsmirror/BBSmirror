/*
Eagles Bulletin Board System
Copyright (C) 1994, Ray Rocker, rrrocker@rock.b11.ingr.com
                                rock@seabass.st.usm.edu
                                72673.2105@compuserve.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/


#include <stdio.h>
#include <string.h>
#include "osdeps.h"
#include "modes.h"
#include "retval.h"
#include "clntcmds.h"

/* 
   Common header file for all pieces of the bbs, client and server.
*/

/* Exit values for lbbs. */

#define EXIT_LOGOUT	0
#define EXIT_LOSTCONN	-1
#define EXIT_CLIERROR   -2
#define EXIT_TIMEDOUT   -3
#define EXIT_KICK	-4

/* Lengths for string data items. */

#define BBSNAMELEN      39
#define NAMELEN		12
#define PASSLEN		14
#define UNAMELEN	20
#define HOSTLEN		20
#define TERMLEN		11
#define RNAMELEN	29
#define ADDRLEN		99
#define MAILLEN		79
/*
#define PATHLEN		255
*/
#define PATHLEN		80	
#define TITLELEN	63

/* I like typedefs. */

typedef char BBSNAME[BBSNAMELEN+1];
typedef char NAME[NAMELEN+1];
typedef char PASSWD[PASSLEN+1];
typedef char UNAME[UNAMELEN+1];
typedef char HOST[HOSTLEN+1];
typedef char TERM[TERMLEN+1];
typedef char RNAME[RNAMELEN+1];
typedef char ADDR[ADDRLEN+1];
typedef char MAIL[MAILLEN+1];
typedef char PATH[PATHLEN+1];
typedef char TITLE[TITLELEN+1];
typedef char ACCESSCODES[MAX_CLNTCMDS];

/* Structures used in the bbs library functions. */

typedef struct _BBSINFO {
  BBSNAME boardname;
  SHORT majver;
  SHORT minver;
  SHORT newok;
} BBSINFO;

typedef struct _LOGININFO {
  NAME userid;
  SHORT flags;
  LONG idletimeout;
  LONG lastlogin;
  HOST fromhost;
  ACCESSCODES access;
} LOGININFO;

typedef struct _ACCOUNT {
  /* in the passwds file */ 
  NAME userid;
  PASSWD passwd;
  UNAME username;
  LONG perms;
  SHORT flags;
  /* in home/<userid>/lastlogin */
  LONG lastlogin;
  HOST fromhost;
  /* in home/<userid>/profile */
  TERM terminal;
  RNAME realname;
  ADDR address;
  MAIL email;
  NAME protocol;
  NAME editor;
#ifdef NUM_LOGN_POST
  char numlogins[LOGNNUM_LEN];
  char numposts[POSTNUM_LEN];
#endif
} ACCOUNT;

typedef struct _USEREC {
  NAME userid;
  UNAME username;
  HOST fromhost;
  LONG pid;
  SHORT flags;
  SHORT mode;
#ifdef DETAILED_USERMODE
  NAME add_str;        /* additonal string to indicate whom you are paging, */
#endif                /* or whom you are talking to, or in which chat room */
} USEREC;

/* Account and userec flags. */
#define FLG_CLOAK	0x001     /* Invisibility */
#define FLG_EXEMPT	0x002     /* For use by user clean utilities */
#define FLG_DISABLED    0x004     /* Account is temporarily disabled */
#define FLG_SHARED      0x008     /* Account does not belong to one user */
#define FLG_NOPAGE      0x010     /* User not accepting page requests... */
#define FLG_NOOVERRIDE  0x020     /* ...not even friends! */

/* Flags for bbs_modify_account */
#define MOD_USERID      0x001
#define MOD_PASSWD      0x002
#define MOD_USERNAME    0x004
#define MOD_TERMINAL    0x008
#define MOD_REALNAME    0x010
#define MOD_ADDRESS     0x020
#define MOD_EMAIL       0x040
#define MOD_PROTOCOL    0x080
#define MOD_EDITOR      0x100
#ifdef NUM_LOGN_POST
#define MOD_LOGNNUM	0x200
#define MOD_POSTNUM	0x400
#endif

/* Max number of recipients for a mail message */
#ifdef OVERRIDE_SEND_MAIL
#define BBS_MAX_MAILRECIPS 100 
#else
#define BBS_MAX_MAILRECIPS 32
#endif

typedef struct _OPENINFO {
  NAME name;
  SHORT flags;
  LONG totalmsgs;
  LONG newmsgs;
} OPENINFO;

/* Flags for OPENINFO */
#define OPEN_POST       0x001
#define OPEN_MANAGE     0x002
#define OPEN_REOPEN     0x004

typedef struct _HEADER {
  SHORT fileid;
/*
  NAME owner;
*/
  ADDR owner;    /* maybe the owner is not local user */
  TITLE title;
  SHORT flags;
  LONG size;
  LONG mtime;
} HEADER;

/* flags for HEADER structures */
#define FILE_UNREAD	0x1
#define FILE_MARKED	0x2
#define FILE_BINARY     0x4
#define FILE_LOCAL      0x8    /* local save articel */
 
/* General-purpose board type constants */
#define BOARD_NONE      0
#define BOARD_MAIL      1
#define BOARD_POST      2
#define BOARD_FILE      3
#if defined(COLLECT_DELETED) || defined(CROSSPOST)
#define BOARD_APPEND	4
#endif

typedef struct _BOARD {
    NAME name;
    TITLE description;
#ifdef SUBTOP
    char subtopic[21];
#endif
    LONG readmask;
    LONG postmask;
#ifdef B_GROUP
    LONG bgroupmask;
#endif
    SHORT flags;
    LONG totalposts;
    LONG newposts;
    LONG ownedposts;     /* not supported at the moment! */
    LONG lastpost;
#ifdef B_GROUP
    int group;
#endif
} BOARD;

/* Flags for BOARD structs */
#define BOARD_ZAPPED    0x001
#define BOARD_NOZAP     0x002
#ifdef VOTE
#define BOARD_VOTE	0x004
#endif

/* Flags for bbs_modify_board. */
#define MOD_BNAME       0x001
#define MOD_BOARDDESC   0x002
#define MOD_READMASK    0x004
#define MOD_POSTMASK    0x008
#ifdef B_GROUP
#define MOD_BGROUPMASK  0x010
#endif
#ifdef SUBTOP
#define MOD_SUBTOPIC	0x011
#endif

/* Flags for bbs_enum_boards. */
#define BE_UNZAPPED     0x001
#define BE_ZAPPED       0x002
#define BE_ALL          (BE_ZAPPED | BE_UNZAPPED)
#define BE_UNDEFINED    0x004
#define BE_DO_COUNTS    0x008

/* Common stuff for chat. */
#define CHATID_MAX         8
typedef char CHATID[CHATID_MAX+1];

#define CHATLINE_MAX       255  /* Text plus /cmd at beginning */
#define CHATLINE_TEXT_MAX  200  /* Max size of test only */
typedef char CHATLINE[CHATLINE_MAX+1];

#define CHAT_CTRL_CHATID "**C"  /* Chatd-->client control message */

/* Namelists are very useful. */

#ifndef NAMELIST_IN_ARRAY
typedef struct _NAMENODE {
  char *word;
  struct _NAMENODE *next;
} NAMENODE;

typedef NAMENODE *NAMELIST;
#else
typedef NAME *NAMELIST;
#endif

/* Useful bit-manipulation macros. */

#define BITISSET(mask,bit)     ((mask)&(bit))
#define BITSET(mask,bit)       ((mask)|=(bit))
#define BITCLR(mask,bit)       ((mask)&=~(bit))
#define BITTOGGLE(mask,bit)    ((mask)^=(bit))

/* Prototypes. */

void strip_trailing_space __P((char *));
int recursive_rmdir __P((char *));
int is_valid_userid __P((char *));
int is_valid_password __P((char *));
int is_valid_boardname __P((char *));
LONG hex2LONG __P((char *));
SHORT hex2SHORT __P((char *));
char *LONGcpy __P((char *, LONG));
char *SHORTcpy __P((char *, SHORT));
int is_text_file __P((char *));

int is_passwd_good __P((char *, char *));
void encrypt_passwd __P((char *, char *));

void free_namelist __P((NAMELIST *));
void create_namelist __P((NAMELIST *));
int add_namelist __P((NAMELIST *, char *, char *));
int remove_namelist __P((NAMELIST *, char *));
int is_in_namelist __P((NAMELIST, char *));
int apply_namelist __P((NAMELIST, int(), void *));
int read_namelist __P((char *, NAMELIST *));
int write_namelist __P((char *, NAMELIST));
#ifdef NAMELIST_IN_ARRAY
int create_huge_namelist __P((NAMELIST *, int));
int add_huge_namelist __P((NAMELIST *, char *)); 
#endif

int read_headers __P((char *, HEADER *));
int write_mail_headers __P((int, HEADER *, char *, NAMELIST));
int write_post_headers __P((int, HEADER *, char *, char *));
int parse_to_list __P((NAMELIST *, char *, char *));

#define UUENCODE 0x01
#define FORWARD  0x02
