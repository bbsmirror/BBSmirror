#define KEY_UP 512
#define KEY_DOWN KEY_UP+'b'-'a'
#define KEY_RIGHT KEY_UP+'c'-'a'
#define KEY_LEFT KEY_UP+'d'-'a'
#define KEY_TAB 9
#define KEY_ESC 27
#define KEY_HOME 0x0401
#define KEY_INS KEY_HOME+1
#define KEY_DEL KEY_HOME+2
#define KEY_END  KEY_HOME+3
#define KEY_PGUP KEY_HOME+4
#define KEY_PGDN KEY_HOME+5
#define KEY_ARROW(k) (k>=KEY_UP && k<=KEY_LEFT)
#define KEY_EDIT(k) (k>=KEY_HOME && k<=KEY_PGDN)
#define FUNCTION_KEY(k) (KEY_ARROW(k) || KEY_EDIT(k))
