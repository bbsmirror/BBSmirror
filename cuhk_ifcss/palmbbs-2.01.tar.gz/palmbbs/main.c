#include "common.h"
main()
{  printf("%d\n",sizeof(ACCOUNT));
}
