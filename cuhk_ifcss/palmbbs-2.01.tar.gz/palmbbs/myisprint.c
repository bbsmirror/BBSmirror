int myisprint(ch)
char ch;
{
   return( (ch & 0x80) ?1:isprint(ch));
}
