
#include <stdio.h>
#include "config.h"

void
Mail2user(char c)
{
	extern struct BBS bbs[BBS_Max];
	extern char     Mailer[35];

	char            buffer[30];
	char            command[80];
	char            subject[50];
	char           *edit_name;

	umask(077);

	ansi_clear;

	printf("�`�N: �ϥΥ��\\��e�Х��T�w %s BBS ���䴩 Internet Mail to User\n\n", bbs[c].name);

	printf("\n�п�J�z�n�H�� %s BBS �������@��ϥΪ�\n", bbs[c].name);
	do {
		printf("\nMail to: ");
		fflush(stdout);
		gets(buffer);

		printf("\n�T�w�H�� %s ��? [Y] ", buffer);
		fflush(stdout);
		gets(command);

	} while ((command[0] != '\0') && (command[0] != 'y')
		 && (command[0] != 'Y'));

	printf("\n�H�󪺼��D�O: ", buffer);
	fflush(stdout);
	gets(subject);

	edit_name = Edit();

	/* Mail post */
	if (!isdigit(bbs[c].hostname[0]))
		sprintf(command, "%s -s \"%s\" %s.bbs@%s < %s\000", Mailer, subject, buffer, bbs[c].hostname, edit_name);
	else
		sprintf(command, "%s -s \"%s\" %s.bbs@[%s]. < %s\000", Mailer, subject, buffer, bbs[c].hostname, edit_name);

	/* printf("\n�H�H�� %s BBS ���� %s\n", bbs[c].name, buffer); */

	system(command);

	Delete();
}
