
#include <stdio.h>
#include "config.h"

extern struct BBS bbs[BBS_Max];
extern long     loc[11];
extern int      hosttype;

int
read_section(long foff)
{

	char            buffer[Rec_Len + 1];
	int             s, i;
	int             port;
	char            type[15];
	extern FILE    *fp;

	fseek(fp, foff, SEEK_SET);

	fgets(buffer, Rec_Len, fp);
	sscanf(buffer, "* [Section] %s", type);

	if (isdigit(type[0]))	/* for forward compatiable */
		sscanf(buffer, "* [Section] %d %s", &i, type);

	if (!strncmp(type, "BBS", 3))
		hosttype = Host_BBS;
	else if (!strncmp(type, "GOPHER", 6))
		hosttype = Host_GOPHER;
	else if (!strncmp(type, "MUD", 3))
		hosttype = Host_MUD;
	else if (!strncmp(type, "LIB", 3))
		hosttype = Host_LIB;
	else if (!strncmp(type, "TEL", 3))
		hosttype = Host_TEL;
	else if (!strncmp(type, "WWW", 3))
		hosttype = Host_WWW;
	else if (!strncmp(type, "FTP", 3))
		hosttype = Host_FTP;

	port = i = 0;
	s = 1;
	while (fgets(buffer, Rec_Len, fp) != NULL) {
		switch (buffer[0]) {
		case '\0':
		case '#':
		case ' ':
		case '\t':
		case '\n':
		case '\r':
			break;
		case '*':
			if (!strncmp(&buffer[3], "End", 3))
				s = 0;
			break;
		default:
			sscanf(buffer, "%s %s %s %d",
			 bbs[i].name, bbs[i].alias, bbs[i].hostname, &port);
			bbs[i].port = (port == 0) ? 23 : port;
			i++;
		}

		if (s == 0)
			break;
		if (i == BBS_Max)
			break;
	}

	return (i);
}
