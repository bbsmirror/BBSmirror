
#include "config.h"

void
DrawBox1(int x1, int y1, int x2, int y2)
{
	int             i;

	ansi_print_xy(y1, x1, "0;37", "�~");
	ansi_print_xy(y1, x2 - 1, "0;37", "��");
	ansi_print_xy(y2, x1, "0;37", "��");
	ansi_print_xy(y2, x2 - 1, "0;37", "��");

	for (i = x1 + 2; i < x2 - 1; i += 2) {
		ansi_print_xy(y1, i, "0;37", "�w");
		ansi_print_xy(y2, i, "0;37", "�w");
	}

	for (i = y1 + 1; i < y2; i++) {
		ansi_print_xy(i, x1, "0;37", "�x");
		ansi_print_xy(i, x2 - 1, "0;37", "�x");
	}

}
void
DrawBox2(int x1, int y1, int x2, int y2)
{
	int             i;

	ansi_print_xy(y1, x1, "0;37", "��");
	ansi_print_xy(y1, x2 - 1, "0;37", "��");
	ansi_print_xy(y2, x1, "0;37", "��");
	ansi_print_xy(y2, x2 - 1, "0;37", "��");

	for (i = x1 + 2; i < x2 - 1; i += 2) {
		ansi_print_xy(y1, i, "0;37", "��");
		ansi_print_xy(y2, i, "0;37", "��");
	}

	for (i = y1 + 1; i < y2; i++) {
		ansi_print_xy(i, x1, "0;37", "��");
		ansi_print_xy(i, x2 - 1, "0;37", "��");
	}

}
