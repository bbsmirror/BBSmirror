
#include <stdio.h>
#include "config.h"

extern char     Title[10][20];

void
HelpBar(char *color, char *str)
{
	ansi_print_xy_n(LINES - 1, 0, color, str, "-68");
}

void
PutTitle(int no, int all)
{
	char            buf[50];
	sprintf(buf, "  �� %s ��\0", Title[no]);
	ansi_print_xy(0, 0, "1;37", buf);
}

extern struct BBS bbs[BBS_Max];
extern unsigned char x[BBS_Max];
extern unsigned char y[BBS_Max];
extern char     label[3];
extern char     symbol[62];
extern int      H, n;

void
Menu(void)
{

	int             i;

	H = LINES - 7;

	for (i = 0; i < n; i++) {
		x[i] = 2 + i % H;
		y[i] = 4 + 20 * ((int) (i / H));
		label[0] = symbol[i];
		ansi_print_xy(x[i], y[i], "1;32", label);
		ansi_print_xy(x[i], y[i] + 2, "0;37", bbs[i].name);
	}
	fflush(stdin);
}

void
MainMenu(int s, int a)
{
	int             i;
	int             y;
	char            buff[35];

	y = 6;
	for (i = 1; i <= a; i++) {
		sprintf(buff, " %1d. %-9s\000", i, Title[i]);
		if (i == s)
			ansi_print_xy(y++, 62, "1;37;44", buff);
		else
			ansi_print_xy(y++, 62, "1;32", buff);
	}

	DrawBox1(60, 5, COLS - 3, y);
}
