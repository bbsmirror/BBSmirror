/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
			Guy Vega, gtvega@seabass.st.usm.edu
			Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/* rrr - This is separated so I can suck it into the IRC source for use
   there too */

#include "modes.h"

char *
ModeType(mode)
int	mode;
{
    switch(mode) {
	case IDLE:	return "" ;
	case NEW:	return "�s�ϥΪ�" ;
	case LOGIN:	return "�i���e��";
        case CSIE_ANNOUNCE:	return "�������G��";
        case CSIE_TIN:		return "TIN �Q�װ�";
        case CSIE_GOPHER:	return "Gopher�d��";
	case MMENU:	return "�D���";
	case ADMIN:	return "�t�κ��@";
	case SELECT:	return "��ܰQ�װ�";
	case READBRD:	return "�Q�װϦC��";
	case READNEW:	return "�s�峹�C��";
	case  READING:	return "�\\Ū�峹";
	case  POSTING:	return "�o���峹" ;
	case MAIL:	return "�l����" ;
	case  SMAIL:	return "�g�H"; 
	case  RMAIL:	return "Ū���H��"; 
	case TMENU:	return "��ѿ��";
	case  LUSERS:	return "�W�u�ϥΪ�";  
	case  FRIEND:	return "�M��n��";
	case  MONITOR:	return "�ʬݨϥΪ�";
	case  QUERY:	return "�d�ߨϥΪ�";
	case  TALK:	return "���" ;
	case  PAGE:	return "�I�s";
	case  CHAT1:	return "Chat-1" ;
	case  CHAT2:	return "Chat-2";
	case  CHAT3:	return "Chat-3"; 
	case  CHAT4:	return "Chat-4"; 
	case  IRCCHAT:	return "�������";
	case LAUSERS:	return "�ϥΪ̦C��"; 
	case XMENU:	return "XYZ ���";
	case  VOTING:	return "�벼��";
        case  BBSNET:	return "BBSNet";
	case  EDITWELC:	return "�s�� Welc";
	case  EDITSIG:	return "�s��ñ�W��";
	case  EDITPLAN:	return "�s��p�e��";
	case ZAP:	return "�q�\\�Q�װ�";

	case FOURM:	return "4m Chat";
	case ULDL:	return "UL/DL" ;
	default: return "Undefined" ;
    }
}

