/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
			Guy Vega, gtvega@seabass.st.usm.edu
			Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"

#define MAXITEMS	1024
#define PATHLEN		256
#define A_PAGESIZE	(t_lines - 6)

#define ADDITEM		0
#define	ADDGROUP	1
#define ADDMAIL		2

char	*email_domain();
void	a_menu();

extern char	BoardName[];

typedef struct {
    char	title[ 72 ];
    char	fname[ 40 ];
} ITEM;

int	a_fmode;

typedef struct {
    ITEM	*item[ MAXITEMS ];
    char	mtitle[ STRLEN ];
    char	*path;
    int		num, page, now;
    int		level;
} MENU;

int
valid_fname( str )
char	*str;
{
    char	ch;

    while( (ch = *str++) != '\0' ) {
	if( (ch >= 'A' && ch <= 'Z' ) || (ch >= 'a' && ch <= 'z' ) ||
	    strchr( "0123456789@[]-._", ch ) != NULL ) {
	    ;
	} else {
	    return 0;
	}
    }
    return 1;
}

int
move_file( dest, src )
char	*dest, *src;
{
    int		fi, fo, len;

    if( (fi = open( src, O_RDONLY )) < 0 )
	return -1;
    if( (fo = open( dest, O_WRONLY|O_CREAT, 0644 )) < 0 )
	return -1;
    while( (len = read( fi, genbuf, sizeof( genbuf ) )) > 0 )
	write( fo, genbuf, len );
    close( fo );
    close( fi );
    unlink( src );
    return 0;
}

void
a_showmenu( pm )
MENU	*pm;
{
    struct stat st;
    struct tm	*pt;
    char	title[ STRLEN ];
    char	fname[ STRLEN ];
    char	ch;
    time_t	mtime;
    int		n;

    clear();
    prints( "        %s\n", pm->mtitle );
    printdash( NULL );
    prints( " �s��  ��    �D" );
    if( a_fmode )
	prints( "%52s", a_fmode == 1 ? "�ɮצW��" : "��  ��" );
    prints( "\n" );
    if( pm->num == 0 )
	prints( "       No article in this group !!\n" );
    for( n = pm->page; n < pm->page + 18 && n < pm->num; n++ ) {
	strcpy( title, pm->item[n]->title );
	if( a_fmode ) {
	    strcpy( fname, pm->item[n]->fname );
	    sprintf( genbuf, "%s/%s", pm->path, fname );
	    if( a_fmode == 1 ) {
		ch = (dashf( genbuf ) ? ' ' : (dashd( genbuf ) ? '/' : '^'));
	    } else {
		if( dashf( genbuf ) ) {
		    stat( genbuf, &st );
		    mtime = st.st_mtime;
		    pt = localtime( &mtime );
		    sprintf( fname, "[%02d/%02d/%02d]",
				pt->tm_mon+1, pt->tm_mday, pt->tm_year );
		} else if( dashd( genbuf ) ) {
		    strcpy( fname, "[��    ��]" );
		} else {
		    strcpy( fname, "[���~�ɦW]" );
		}
		ch = ' ';
	    }
	    title[ 50 ] = '\0';
	    sprintf( genbuf, "%-50s  %s%c", title, fname, ch );
	    strcpy( title, genbuf );
	}
	title[ 72 ] = '\0';
	prints( "  %3d  %s\n", n+1, title );
    }
    clrtobot();
    move( t_lines-2, 0 );
    prints( "%s", (pm->level & PERM_BOARDS) ?
"[�O  �D] ���� h �x ���} q,�� �x �s�W�峹 a �x �s�W�ؿ� g �x �s���ɮ� e" :
"[�\\����] ���� h �x ���} q,�� �x ���ʴ�� k,��,j,�� �x Ū����� Rtn,��" );
}

void
a_showhelp( level )
int	level;
{
    clear();
    prints( "        ��ذϤ��G�� v2.0 �ϥλ���\n" );
    printdash( NULL );
    prints( "\
[����]        [����]\n\
h           ���ϥλ���\n\
q ��        ���}��W�@�h�ؿ�\n\
k ��        ����e�@�ӿﶵ\n\
j ��        �����@�ӿﶵ\n\
^B PgUp     ���ܫe�@�����\n\
^F PgDn     ���ܫ�@�����\n\
r Rtn ��    �i�J�U�@�h�ؿ� / Ū���峹\n\
/           �j�M�S�w�Q�װ�\n" );
    if( HAS_PERM( PERM_BASIC ) )
	prints( "\
F           �N�峹�H�^�z�� Internet �l�c\n\
U           �N�峹 uuencode ��H�^�z���l�c\n\
Z           �Q�� Z-Modem �ǰe�峹\n" );
    if( level & PERM_BOARDS ) {
	prints( "\n----< �O�D�S������ >----\n\
a/g         ������ؤ峹/�}�P�l���\n\
m/d         ����/�R���峹\n\
t/e         �ק�峹���D/���e\n\
i           Ū�� E-Mail ���峹\n\
f/n         �d���ɮצW��/����ɮצW��\n\
c/p         ����/�߶K�@�g�峹\n" );
    }
    pressanykey();
}

void
a_additem( pm, title, fname )
MENU    *pm;
char    *title, *fname;
{
    ITEM        *newitem;

    if( pm->num < MAXITEMS ) {
	newitem = (ITEM *) malloc( sizeof(ITEM) );
	strcpy( newitem->title, title );
	strcpy( newitem->fname, fname );
	pm->item[ (pm->num)++ ] = newitem;
    }
}

int
a_loadnames( pm )
MENU	*pm;
{
    FILE	*fn;
    ITEM	litem;
    char	buf[ PATHLEN ], *ptr;

    pm->num = 0;
    sprintf( buf, "%s/.Names", pm->path );
    if( (fn = fopen( buf, "r" )) == NULL )
	return 0;
    while( fgets( buf, sizeof(buf), fn ) != NULL ) {
	if( (ptr = strchr( buf, '\n' )) != NULL )
	    *ptr = '\0';
	if( strncmp( buf, "Name=", 5 ) == 0 ) {
	    strncpy( litem.title, buf + 5, sizeof(litem.title) );
	} else if( strncmp( buf, "Path=~/", 7 ) == 0 ) {
	    strncpy( litem.fname, buf + 7, sizeof(litem.fname) );
	    a_additem( pm, litem.title, litem.fname );
	} else if( strncmp( buf, "# Title=", 8 ) == 0 ) {
	    if( pm->mtitle[0] == '\0' )
		strcpy( pm->mtitle, buf + 8 );
	}
    }
    fclose( fn );
    return 1;
}

void
a_savenames( pm )
MENU	*pm;
{
    FILE	*fn;
    ITEM	*item;
    char	fpath[ PATHLEN ];
    int		n;

    sprintf( fpath, "%s/.Names", pm->path );
    if( (fn = fopen( fpath, "w" )) == NULL )
	return;
    fprintf( fn, "#\n" );
    fprintf( fn, "# Title=%s\n", pm->mtitle );
    fprintf( fn, "#\n" );
    for( n = 0; n < pm->num; n++ ) {
	item = pm->item[n];
	fprintf( fn, "Name=%s\n",	item->title );
	fprintf( fn, "Path=~/%s\n",	item->fname );
	fprintf( fn, "Numb=%d\n",	n+1 );
	fprintf( fn, "#\n" );
    }
    fclose( fn );
    chmod( fpath, 0644 );
}

void
a_prompt( bot, pmt, buf )
int	bot;
char	*pmt, *buf;
{
    getdata( t_lines+bot, 0, pmt, buf, 80, DOECHO, NULL );
}

int
a_menusearch( path, key, level )
char	*path, *key;
int	level;
{
    FILE	*fn;
    char	bname[ STRLEN ];
    char	buf[ PATHLEN ], *ptr;
    int		len;

    if( key == NULL ) {
	key = bname;
	a_prompt( -1, "��J���j�M���Q�װϦW��: ", key );
    }
    len = strlen( key );
    sprintf( buf, "%s/.Search", path );
    if( len > 0 && (fn = fopen( buf, "r" )) != NULL ) {
	while( fgets( buf, sizeof( buf ), fn ) != NULL ) {
	    if( strncmp( buf, key, len ) == 0 && buf[len] == ':' &&
		(ptr = strtok( &buf[ len+1 ], " \t\n" )) != NULL ) {
		sprintf( bname, "%s/%s", path, ptr );
		fclose( fn );
		a_menu( "", bname, level );
		return 1;
	    }
	}
	fclose( fn );
    }
    return 0;
}

void
a_forward( path, pitem, mode )
char	*path;
ITEM	*pitem;
int	mode;
{
    struct shortfile	fhdr;
    char	fname[ PATHLEN ], *mesg;

    sprintf( fname, "%s/%s", path, pitem->fname );
    if( dashf( fname ) ) {
	strncpy( fhdr.title,    pitem->title, STRLEN );
	strncpy( fhdr.filename, pitem->fname, STRLEN );
	switch( doforward( path, &fhdr, mode ) ) {
	    case  0: mesg = "�峹��H����!\n";		break;
	    case -1: mesg = "system error!!.\n";	break;
	    case -2: mesg = "invalid address.\n";	break;
	    default: mesg = "������H�ʧ@.\n";
	}
	prints( mesg );
    } else {
	move( t_lines-1, 0 );
	prints( "�L�k��H������.\n" );
    }
    pressanykey();
}

void
a_download( fname )
char	*fname;
{
    char	ans[ STRLEN ], *ptr;

    move( t_lines-1, 0 );
    if( dashf( fname ) ) {
	ptr = fname;
	if( (ptr = strrchr( fname, '/' )) != NULL )
	    ptr++;
	sprintf( genbuf, "�ϥ� Z-Modem �ǰe %s �ɮ׶�? (Y/N) [N]: ", ptr );
	a_prompt( -2, genbuf, ans );
	if( *ans == 'y' || *ans == 'Y' ) {
	    sprintf( genbuf, "bin/sz -ve %s", fname );
	    system( genbuf );
	}
    } else {
	prints( "�L�k�ǰe������.\n" );
	egetch();
    }
}

void
a_newitem( pm, mode )
MENU	*pm;
int	mode;
{
    char	board[ STRLEN ], title[ STRLEN ];
    char	fname[ STRLEN ], fpath[ PATHLEN ];
    char	*mesg, *domain;

    pm->page = 9999;
    switch( mode ) {
	case ADDITEM:
	    mesg = "[�s�W�峹] �п�J�ɮצW��: ";	break;
	case ADDGROUP:
	    mesg = "[�s�W�ؿ�] �п�J�ؿ��W��: ";	break;
	case ADDMAIL:
	    domain = email_domain();
	    sprintf( title, "�п�J�Q�װϦW�� (???.bm@%s): ", domain );
	    a_prompt( -2, title, genbuf );
	    sprintf( board, "tmp/bm.%s", genbuf );
	    if( !dashf( board ) ) {
		prints( "�d�L���H, �бN�峹�H�� %s.bm@%s. ", genbuf, domain );
		egetch();
		return;
	    }
	    mesg = "[Ū���l��] �п�J�ɮצW��: ";	break;
    }
    a_prompt( -2, mesg, fname );
    if( *fname == '\0' )  return;
    sprintf( fpath, "%s/%s", pm->path, fname );
    if( !valid_fname( fname ) ) {
	prints( "[���~] �W�٥u��]�t�^��μƦr ..." );
	egetch();
    } else if( dashf( fpath ) || dashd( fpath ) ) {
	prints( "Warning: �t�Τ��w�g�� %s �o���ɮצs�b�F !", fname );
	egetch();
    } else {
	mesg = "           �п�J�ﶵ����: ";
	a_prompt( -1, mesg, title );
	if( *title == '\0' )  return;
	switch( mode ) {
	    case ADDITEM:
		vedit( fpath, 0 );
		chmod( fpath, 0644 );
		break;
	    case ADDGROUP:
		mkdir( fpath, 0755 );
		chmod( fpath, 0755 );
		break;
	    case ADDMAIL:
		move_file( fpath, board );
		chmod( fpath, 0644 );
		break;
	}
	if( mode != ADDGROUP ) {
	    sprintf( genbuf, " -- %s ��z", currentuser.userid );
	    strcat( title, genbuf );
	}
	a_additem( pm, title, fname );
	a_savenames( pm );
    }
}

void
a_moveitem( pm )
MENU	*pm;
{
    ITEM	*tmp;
    char	newnum[ STRLEN ];
    int		num, n;

    sprintf( genbuf, "�п�J�� %d �����s����: ", pm->now+1 );
    a_prompt( -2, genbuf, newnum );
    num = (newnum[0] == '$') ? 9999 : atoi( newnum ) - 1;
    if( num >= pm->num )  num = pm->num-1;
    else if( num < 0 )  num = 0;
    tmp = pm->item[ pm->now ];
    if( num > pm->now ) {
	for( n = pm->now; n < num; n++ )
	    pm->item[ n ] = pm->item[ n+1 ];
    } else {
	for( n = pm->now; n > num; n-- )
	    pm->item[ n ] = pm->item[ n-1 ];
    }
    pm->item[ num ] = tmp;
    pm->now = num;
    a_savenames( pm );
}

void
a_copypaste( pm, paste )
MENU	*pm;
int	paste;
{
    static char	title[ STRLEN ], filename[ STRLEN ], fpath[ PATHLEN ];
    ITEM	*item;
    char	ans[ STRLEN ], newpath[ PATHLEN ];

    move( t_lines-1, 0 );
    if( !paste ) {
	item = pm->item[ pm->now ];
	strncpy( title, item->title, STRLEN );
	strncpy( filename, item->fname, STRLEN );
	sprintf( genbuf, "%s/%s", pm->path, filename );
	strncpy( fpath, genbuf, PATHLEN );
	prints( "�ɮ׼��ѧ���. (�`�N! �߶K�峹��~��N�峹 delete!)" );
	egetch();
    } else {
	sprintf( newpath, "%s/%s", pm->path, filename );
	if( *title == '\0' || *filename == '\0' ) {
	    prints( "�Х��ϥ� copy �R�O�A�ϥ� paste �R�O. " );
	    egetch();
	} else if( dashf( newpath ) || dashd( newpath ) ) {
	    prints( "%s �ɮ�/�ؿ��w�g�s�b. ", filename );
	    egetch();
	} else if( strstr( newpath, fpath ) != NULL ) {
	    prints( "�L�k�N�ؿ��h�i�ۤv���l�ؿ���, �|�y�����j��. " );
	    egetch();
	} else {
	    sprintf( genbuf, "�z�T�w�n�߶K %s �ɮ�/�ؿ���? ", filename );
	    a_prompt( -2, genbuf, ans );
	    if( ans[0] == 'Y' || ans[0] == 'y' ) {
		sprintf( genbuf, "/bin/cp -r %s %s", fpath, newpath );
		system( genbuf );
		a_additem( pm, title, filename );
		a_savenames( pm );
	    }
	}
    }
    pm->page = 9999;
}

void
a_delete( pm )
MENU	*pm;
{
    ITEM	*item;
    char	fpath[ PATHLEN ];
    char	ans[ STRLEN ];
    int		n;

    item = pm->item[ pm->now ];
    move( t_lines-2, 0 );
    prints( "%5d  %-50s %s\n", pm->now+1, item->title, item->fname );
    sprintf( fpath, "%s/%s", pm->path, item->fname );
    if( dashf( fpath ) ) {
	a_prompt( -1, "�z�T�w�n�R�����ɮ׶�? ", ans );
	if( ans[0] != 'Y' && ans[0] != 'y' )
	    return;
	unlink( fpath );
    } else if( dashd( fpath ) ) {
	a_prompt( -1, "�z�T�w�n�R��''��ӥؿ�''��?? ", ans );
	if( ans[0] != 'Y' && ans[0] != 'y' )
	    return;
	sprintf( genbuf, "/bin/rm -rf %s", fpath );
	system( genbuf );
    }
    free( item );
    (pm->num)--;
    for( n = pm->now; n < pm->num; n++ )
	pm->item[n] = pm->item[n+1];
    a_savenames( pm );
}

void
a_newname( pm )
MENU	*pm;
{
    ITEM	*item;
    char	fname[ STRLEN ];
    char	fpath[ PATHLEN ];
    char	*mesg;

    item = pm->item[ pm->now ];
    a_prompt( -2, "�s�ɦW: ", fname );
    if( *fname == '\0' )  return;
    sprintf( fpath, "%s/%s", pm->path, fname );
    if( !valid_fname( fname ) ) {
	mesg = "���X�k�ɮצW��.";
    } else if( dashf( fpath ) || dashd( fpath ) ) {
	mesg = "�t�Τ��w�����ɮצs�b�F.";
    } else {
	sprintf( genbuf, "%s/%s", pm->path, item->fname );
	if( rename( genbuf, fpath ) == 0 ) {
	    strcpy( item->fname, fname );
	    a_savenames( pm );
	    return;
	}
	mesg = "�ɦW��異�� !!";
    }
    prints( mesg );
    egetch();
}

void
a_manager( pm, ch )
MENU	*pm;
int	ch;
{
    ITEM	*item;
    char	fpath[ PATHLEN ];

    if( pm->num > 0 ) {
	item = pm->item[ pm->now ];
	sprintf( fpath, "%s/%s", pm->path, item->fname );
    }
    switch( ch ) {
	case 'a':  a_newitem( pm, ADDITEM );	break;
	case 'g':  a_newitem( pm, ADDGROUP );	break;
	case 'i':  a_newitem( pm, ADDMAIL );	break;
	case 'p':  a_copypaste( pm, 1 );	break;
    }
    if( pm->num > 0 )  switch( ch ) {
	case 'f':  if( ++a_fmode >= 3 )	a_fmode = 0;
		   pm->page = 9999;	break;
	case 'm':  a_moveitem( pm );
		   pm->page = 9999;	break;
	case 'd':  a_delete( pm );
		   pm->page = 9999;	break;
	case 't':  a_prompt( -2, "�s���D: ", genbuf );
		   if( *genbuf )  strcpy( item->title, genbuf );
		   a_savenames( pm );
		   pm->page = 9999;	break;
	case 'e':  if( dashf( fpath ) )  vedit( fpath, 0 );
		   pm->page = 9999; break;
	case 'n':  a_newname( pm );
		   pm->page = 9999;	break;
	case 'c':  a_copypaste( pm,0);	break;
    }
}

void
a_menu( maintitle, path, lastlevel )
char	*maintitle, *path;
int	lastlevel;
{
    MENU	me;
    char	fname[ PATHLEN ];
    int		ch;

    modify_user_mode( CSIE_ANNOUNCE );
    me.path = path;
    strcpy( me.mtitle, maintitle );
    me.level = lastlevel;
    a_loadnames( &me );
    if( HAS_PERM( PERM_BOARDS ) ) {
	sprintf( genbuf, "(BM: %s)", currentuser.userid );
	if( strstr( me.mtitle, genbuf ) || HAS_PERM( PERM_SYSOP ) )
	    me.level |= PERM_BOARDS;
    }
    me.page = 9999;
    me.now = 0;
    while( 1 ) {
	if( me.now >= me.num && me.num > 0 ) {
	    me.now = me.num - 1;
	} else if( me.now < 0 ) {
	    me.now = 0;
	}
	if( me.now < me.page || me.now >= me.page + A_PAGESIZE ) {
	    me.page = me.now - (me.now % A_PAGESIZE);
	    a_showmenu( &me );
	}
	move( 3 + me.now - me.page, 0 );	prints( "->" );
	ch = egetch();
	move( 3 + me.now - me.page, 0 );	prints( "  " );
	if( ch == 'Q' || ch == 'q' || ch == KEY_LEFT || ch == EOF )
	    break;
	switch( ch ) {
	    case KEY_UP: case 'K': case 'k':
		if( --me.now < 0 )  me.now = me.num-1;
		break;
	    case KEY_DOWN: case 'J': case 'j':
		if( ++me.now >= me.num )  me.now = 0;
		break;
	    case KEY_PGUP: case Ctrl( 'B' ):
		if( me.now >= A_PAGESIZE )	me.now -= A_PAGESIZE;
		else if( me.now > 0 )		me.now = 0;
		else				me.now = me.num - 1;
		break;
	    case KEY_PGDN: case Ctrl( 'F' ): case ' ':
		if( me.now < me.num-A_PAGESIZE)	me.now += A_PAGESIZE;
		else if( me.now < me.num - 1 )	me.now = me.num - 1;
		else				me.now = 0;
		break;
	    case 'h':
		a_showhelp( me.level );
		me.page = 9999;
		break;
	    case 'R': case 'r':
	    case '\n': case '\r': case KEY_RIGHT:
		if( me.now < me.num ) {
		    sprintf( fname, "%s/%s", path, me.item[ me.now ]->fname );
		    if( dashf( fname ) ) {
			ansimore( fname, YEA );
		    } else if( dashd( fname ) ) {
			a_menu( me.item[ me.now ]->title, fname, me.level );
		    }
		    me.page = 9999;
		}
		break;
	    case '/':
		if( a_menusearch( path, NULL, me.level ) )
		    me.page = 9999;
		break;
	    case 'F':
	    case 'U':
		if( me.now < me.num && HAS_PERM( PERM_BASIC ) ) {
		    a_forward( path, me.item[ me.now ], ch == 'U' );
		    me.page = 9999;
		}
		break;
	    case 'Z':
		if( me.now < me.num && HAS_PERM( PERM_BASIC ) ) {
		    sprintf( fname, "%s/%s", path, me.item[ me.now ]->fname );
		    a_download( fname );
		    me.page = 9999;
		}
		break;
	}
	if( me.level & PERM_BOARDS )
	    a_manager( &me, ch );
    }
    for( ch = 0; ch < me.num; ch++ )
	free( me.item[ ch ] );
}

void
Announce()
{
    sprintf( genbuf, "%s ��ذϤ��G��", BoardName );
    a_menu( genbuf, "0Announce", HAS_PERM(PERM_SYSOP) ? PERM_BOARDS : 0 );
}

