/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
			Guy Vega, gtvega@seabass.st.usm.edu
			Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"

int mot ;
static int quiting ;
int continue_flag;
int scrint = 0 ;
int local_article;

struct userec currentuser ;
int usernum ;
char currboard[STRLEN-BM_LEN] ;
char currBM[BM_LEN] ;
int selboard = 0 ;

char	*filemargin() ;
void	report();
void	cancelpost();

extern int	numboards;
extern time_t	login_start_time;
extern char	BoardName[];
extern int	cmpbnames();

char genbuf[ 1024 ];
char quote_file[ 256 ], quote_user[ 256 ];
#ifndef NOREPLY
char replytitle[STRLEN];
#endif

int totalusers, usercounter;

char *
sethomepath( buf, userid )
char	*buf, *userid;
{
    sprintf( buf, "home/%s", userid );
    return buf;
}

char *
sethomefile( buf, userid, filename )
char	*buf, *userid, *filename;
{
    sprintf( buf, "home/%s/%s", userid, filename );
    return buf;
}

char *
setuserfile( buf, filename )
char	*buf, *filename;
{
    sprintf( buf, "home/%s/%s", currentuser.userid, filename );
    return buf;
}

char *
setbpath( buf, boardname )
char *buf, *boardname;
{
    strcpy( buf, "boards/" );
    strcat( buf, boardname );
    return buf;
}

char *
setbdir( buf, boardname )
char *buf, *boardname;
{
    sprintf( buf, "boards/%s/%s", boardname, DOT_DIR );
    return buf;
}

char *
setbfile( buf, boardname, filename )
char *buf, *boardname, *filename;
{
    sprintf( buf, "boards/%s/%s", boardname, filename );
    return buf;
}

int
uleveltochar( buf, lvl )
char	*buf;
unsigned lvl;
{
    lvl &= currentuser.userlevel;
    if( !(lvl & PERM_BASIC) ) {
	strcpy( buf, "----" );
	return 1;
    }
    if( lvl <= PERM_DEFAULT )
	return 0;
    buf[0] = (lvl & (PERM_CLOAK|PERM_SEECLOAK|PERM_CHATCLOAK)) ? 'C' : ' ';
    buf[1] = (lvl & (PERM_XEMPT)) ? 'X' : ' ';
    buf[2] = (lvl & (PERM_BOARDS)) ? 'B' : ' ';
    buf[3] = (lvl & (PERM_DENYPOST)) ? 'p' : ' ';
    if( lvl & PERM_ACCOUNTS ) buf[3] = 'A';
    if( lvl & PERM_SYSOP ) buf[3] = 'S';
    buf[4] = '\0';
    return 1;
}

char *
Ctime(clock)
time_t *clock;
{
    char *foo;
    char *ptr = ctime(clock);
    if( (foo = strrchr(ptr, '\n')) != NULL ) *foo = '\0';
    return (ptr);
}

void
printutitle()
{
    move(2,0) ;
    standout() ;
    prints("�ϥΪ̥N��     %-25s  #�W�� #�峹 %4s   �̪���{���\n",
#if defined(ACTS_REALNAMES)
	"�u��m�W",
#else
	"�ϥΪ̼ʺ�",
#endif
	HAS_PERM(PERM_SEEULEVELS)?"����":"" ) ;
    standend() ;
}

int
printuent(uentp)
struct userec *uentp ;
{
    static int i ;
    char permstr[10]; 

    if(uentp == NULL) {
	printutitle();
	i = 2 ;
	return 0;
    }
    if( uentp->numlogins == 0 ||
	uleveltochar( permstr, uentp->userlevel ) == 0 )
	return 0;
    if(i == t_lines-2) {
	int ch ;
	standout() ;
	prints("�w��� %d �H, ���U�H�� %d �H [�� Q ���}]",
		usercounter, totalusers );
	standend() ;
	clrtoeol();
	while((ch = igetch()) != EOF) {
	    if(ch == '\n' || ch == '\r' || ch == ' ')
		break ;
	    if(ch == 'q' || ch == Ctrl('C')) {
		move(t_lines-1,0) ;
		clrtoeol() ;
		return QUIT ;
	    }
	}
	printutitle();
	i = 2 ;
	clrtobot() ;
    }
    prints("%-14s %-25s  %5d %5d %4s %-16s\n",uentp->userid,
#if defined(ACTS_REALNAMES)
	uentp->realname,
#else
	uentp->username,
#endif 
	uentp->numlogins, uentp->numposts,
	HAS_PERM(PERM_SEEULEVELS) ? permstr : "",
	Ctime(&uentp->lastlogin) );
    i++ ;
    usercounter++;
    return 0 ;
}

int
countusers( userid, unum )
char	*userid;
int	unum;
{
    if( userid[0] != '\0')  totalusers++;
    return 0;
}

int
Users()
{
    totalusers = 0;
    apply_users( countusers );

    usercounter = 0;
    report("User List");
    modify_user_mode( LAUSERS );
    printuent((struct userec *)NULL) ;
    if(apply_record(PASSFILE,printuent,sizeof(struct userec)) == -1) {
	prints("No Users Exist") ;
	pressreturn() ;
	return 0;
    }
    clrtobot() ;
    move(t_lines-1,0);
    prints("�@��� %d �H, ���U�H�� %d/%d �H�C[�Ы����N���~��]", 
                usercounter, totalusers, MAXUSERS);
    egetch();
    move(2,0);
    clrtoeol();
    return 0;
}

int
g_board_names(fhdrp)
struct boardheader *fhdrp ;
{
    if ((fhdrp->level & PERM_POSTMASK) || HAS_PERM(fhdrp->level))
	AddNameList(fhdrp->filename) ;
    return 0 ;
}

void
make_blist()
{
    CreateNameList() ;
    apply_boards(g_board_names) ;
}

int
Select()
{
    modify_user_mode( SELECT );
    do_select( 0, NULL, genbuf );
    return 0 ;
}

int
junkboard()
{
    return( strcmp( currboard, "test" ) == 0 ||
	    strcmp( currboard, "newscast" ) == 0 );
}

int
Post()
{
    if(!selboard) {
	prints("\n\n���� (S)elect �h��ܤ@�ӰQ�װϡC\n") ;
	pressreturn() ;
	clear() ;
	return 0 ;
    }
#ifndef NOREPLY
    *replytitle = '\0';
#endif
    do_post();
    return 0 ;
}

void
readtitle()
{
    struct shortfile	*bp;
    struct shortfile	*getbcache();
    char	header[ STRLEN ], title[ STRLEN ];

    bp = getbcache( currboard );
    memcpy( currBM, bp->BM, BM_LEN );
    if( currBM[0] == '\0' || currBM[0] == ' ' ) {
	strcpy( header, "�ثe�L�O�D" );
	prints( header );
    } else {
	sprintf( header, "�O�D: %s", currBM );
	prints( "�O�D: " );
	standout();
	prints( currBM );
	standend();
    }

    if ( chkmail() )
	strcpy( title, "[�A���H��]" );
    else if ( currBM[ BM_LEN - 1 ] )
	strcpy( title, "[�Q�װϧ벼��]" );
    else
	strcpy( title, BoardName );

    showtitle( header, title );
    prints("���}[��,e] ���[��,��] �\\Ū[��,r] �o���峹[Ctrl-P] ��H[d] �Ƨѿ�[TAB] �D�U[h]\n" );
    standout();
    prints("�s��   %-12s %6s  %-50s \n", "�Z �n ��", "��  ��", " ��  �D") ;
    standend();
    clrtobot();
}

char *
readdoent(num,ent)
int	num;
struct fileheader *ent ;
{
    static char buf[512] ;
    time_t	filetime;
    char	*date;
    int		type;

    type = brc_unread( ent->filename ) ? 'N' : ' ';
    if ((ent->accessed[0] & FILE_MARKED) && HAS_PERM(PERM_MARKPOST))
    {
       if (type == ' ') type = 'm';
       else type = 'M';
    }
    filetime = atoi( ent->filename + 2 );
    if( filetime > 740000000 ) {
	date = ctime( &filetime ) + 4;
    } else {
	date = "";
    }
    sprintf(buf," %3d %c %-12.12s %6.6s  %s", num, type,
		ent->owner, date, ent->title) ;
    return buf ;
}

char currfile[STRLEN] ;

int
cmpfilename(fhdr)
struct fileheader *fhdr ;
{
    if(!strncmp(fhdr->filename,currfile,STRLEN))
	return 1 ;
    return 0 ;
}

int
cpyfilename(fhdr)
struct fileheader *fhdr ;
{
    char	buf[ STRLEN ];

    if( fhdr->owner[0] != '-' ) {
	sprintf( buf, "-%s", fhdr->owner );
	strncpy( fhdr->owner, buf, IDLEN );
	sprintf( buf, "<< article canceled by %s >>", currentuser.userid );
	strncpy( fhdr->title, buf, STRLEN );
    }
    fhdr->filename[ STRLEN - 1 ] = 'L';
    fhdr->filename[ STRLEN - 2 ] = 'L';
    return 0;
}

int
cancelheader( fhdr )
struct fileheader *fhdr ;
{
    char        buf[ STRLEN ];

    if( fhdr->owner[0] != '-' ) {
	sprintf( buf, "-%s", fhdr->owner );
	strncpy( fhdr->owner, buf, IDLEN );
	sprintf( buf, "<< article canceled >>" );
        strncpy( fhdr->title, buf, STRLEN );
    }
    return 0;
}

int
read_post(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char *t ;
    char buf[512];
    int  ch;

    clear() ;
    strcpy(buf,direct) ;
    if( (t = strrchr(buf,'/')) != NULL )
	*t = '\0' ;
    sprintf(genbuf,"%s/%s",buf,fileinfo->filename) ;
    strcpy( quote_file, genbuf );
    quote_file[255] = fileinfo->filename[STRLEN-2];
    strcpy( quote_user, fileinfo->owner );
#ifndef NOREPLY
    ch = ansimore(genbuf,NA) ;
#else
    ch = ansimore(genbuf,YEA) ;
#endif
    brc_addlist( fileinfo->filename ) ;
    if( ch == -1 ) {
	strncpy(currfile,fileinfo->filename,STRLEN) ;
	update_file(direct,sizeof(struct fileheader),ent,cmpfilename,
			cancelheader);
	return -1;
    }
#ifndef NOREPLY
    move(t_lines-1, 0);
     
    if (haspostperm(currboard)) {
	prints("[�\\Ū�峹] �^�H R �x ���� Q,�� �x�W�@�� ���x�U�@�� <Space>,<Enter>,�� ");
    } else {
	prints("[�\\Ū�峹] ���� Q,�� �x�W�@�� ���x�U�@�� <Space>,<Enter>,�� ");
    }

    refresh();
    sleep(1);
    if (!( ch == KEY_RIGHT || ch == KEY_UP || ch == KEY_PGUP )) 
        ch = egetch();

    switch( ch ) {
	case 'N': case 'Q':
	case 'n': case 'q': case KEY_LEFT:
		break; 
	case ' ':
	case 'j': case KEY_RIGHT: case KEY_DOWN: case KEY_PGDN:
		return READ_NEXT;
	case KEY_UP: case KEY_PGUP: 
		return READ_PREV;
	case 'Y' : case 'R':
	case 'y' : case 'r':
		do_reply(fileinfo->title);
		break;
	case Ctrl('R'):
		post_reply( ent, fileinfo, direct );
		break;
	default : break;
    }
#endif
    return FULLUPDATE ;
}

int
skip_post( ent, fileinfo, direct )
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    brc_addlist( fileinfo->filename ) ;
    return GOTO_NEXT;
}

int
do_select( ent, fileinfo, direct )
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char bname[STRLEN], bpath[ STRLEN ];
    struct stat st ;

    move(0,0) ;
    clrtoeol();
    prints("��ܤ@�ӰQ�װ� (�^��r���j�p�g�ҥi)\n") ;
    prints("��J�Q�װϦW (���ť���۰ʷj�M): ") ;
    clrtoeol() ;
	
    make_blist() ;
    namecomplete((char *)NULL,bname) ;
    setbpath( bpath, bname );
    if((*bname == '\0') || (stat(bpath,&st) == -1)) {
	move(2,0);
	prints("�����T���Q�װ�.\n");
	pressreturn();
	return FULLUPDATE ;
    }
    if(!(st.st_mode & S_IFDIR)) {
	move(2,0) ;
	prints("�����T���Q�װ�.\n") ;
	pressreturn() ;
	return FULLUPDATE ;
    }

    selboard = 1;
    brc_initial( bname );

    move(0,0);
    clrtoeol();
    move(1,0);
    clrtoeol();
    setbdir( direct, currboard );
    return NEWDIRECT ;
}

#ifndef NOREPLY
int
do_reply(title)
char *title;
{
    strcpy(replytitle, title);
    post_article();
    replytitle[0] = '\0';
    return FULLUPDATE;
}
#endif

int
garbage_line( str )
char *str;
{
    int qlevel = 0;

    while( *str == ':' || *str == '>' ) {
	str++;
	if( *str == ' ' )  str++;
	if( qlevel++ >= 1 )  return 1;
    }
    while( *str == ' ' || *str == '\t' )  str++;
    if( qlevel >= 1 )
	if( strstr( str, ") ����:\n" ) || strncmp( str, "==>", 3 ) == 0 )
	    return 1;
    return( *str == '\n' );
}

/* When there is an old article that can be included -jjyang */        
void
do_quote( filepath )
char	*filepath;
{
    FILE	*inf, *outf;
    char	*qfile, *quser;
    char	buf[256], *ptr;
    char	ans[4], op;
    int		bflag;

    qfile = quote_file;
    quser = quote_user;
    bflag = strncmp( qfile, "mail", 4 );
    outf = fopen( filepath, "w" );
    if( *qfile != '\0' && (inf = fopen( qfile, "r" )) != NULL ) {
	if( bflag ) ptr = "�ޥέ�峹�� (Y/N/All/Repost)? [Y]: ";
	else ptr = "�аݭn�ޥέ�H�ܡS (Y/N/All)? [Y]: ";
	getdata( t_lines-1, 0, ptr ,ans, 4, DOECHO, NULL );
	op = toupper( ans[0] );
	if( op != 'N' ) {
	    fgets( buf, 256, inf );
	    if( (ptr = strrchr( buf, ')' )) != NULL ) {
		ptr[1] = '\0';
		if( (ptr = strchr( buf, ':' )) != NULL ) {
		    quser = ptr + 1;
		    while( *quser == ' ' )  quser++;
		}
	    }

	    if( bflag ) fprintf( outf, "==> �b %s ���峹������:\n", quser );
	    else fprintf( outf, "==> �b %s ���ӫH������:\n", quser );

	    if( op == 'A' ) {
		while( fgets( buf, 256, inf ) != NULL )
		    fprintf( outf, ": %s", buf );
	    } else if( op == 'R' ) {
		while (fgets( buf, 256, inf ) != NULL)
		    if( buf[0] == '\n' )  break;
		while( fgets( buf, 256, inf ) != NULL )
		    fprintf( outf, "%s", buf );
	    } else {
		while (fgets( buf, 256, inf ) != NULL)
		    if( buf[0] == '\n' )  break;
		while (fgets( buf, 256, inf ) != NULL) {
		    if( strcmp( buf, "--\n" ) == 0 )
			break;
		    if( buf[ 76 ] != '\0' )
			strcpy( buf+76, "\n" );
		    if( !garbage_line( buf ) )
			fprintf( outf, ": %s", buf );
		}
	    }
	}
	fclose( inf ); 
    }
    *quote_file = '\0';
    *quote_user = '\0';

    if( !(currentuser.flags[0] & SIG_FLAG) )
	addsignature(outf,1);
    fclose(outf);
}

int
do_post()
{
    *quote_file = '\0';
    *quote_user = '\0';
    return post_article();
}

/*ARGSUSED*/
int
post_reply(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char        uid[STRLEN] ;
    char        title[STRLEN] ;
    char        *t ;
    FILE	*fp;

    modify_user_mode( SMAIL );

/* indicate the quote file/user */
    setbfile( quote_file, currboard, fileinfo->filename );
    strcpy( quote_user, fileinfo->owner );

/* find the author */
    if (strchr(quote_user, '.')) { 
	uid[0] = '\0';
	fp = fopen( quote_file, "r" );
	if (fp != NULL) {
	    fgets( genbuf, 255, fp );
	    fclose( fp ); 
	    if( strtok( genbuf, " \t\n\r" ) != NULL )
		if( (t = strtok( NULL, " \t\n\r" )) != NULL )
		    strcpy( uid, t );
	}
	if( uid[0] == '\0' ) {
	    move( t_lines-1, 0 );
	    prints("Error: Cannot find Author ... \n");
	    egetch();
	    return FULLUPDATE ;
        }
    } else
	strcpy( uid, quote_user );

/* make the title */
    if (toupper(fileinfo->title[0]) != 'R' || fileinfo->title[1] != 'e' ||
        fileinfo->title[2] != ':') strcpy(title,"Re: ") ;
    else title[0] = '\0';
    strncat(title,fileinfo->title,STRLEN-5) ;

    clear();
    prints("�^�H����@��: %s\n", uid );
    prints("        ���D: %s\n", title );

/* edit, then send the mail */
    switch (do_send(uid,title)) {
        case -1: prints("�t�εL�k�e�H\n"); break;
        case -2: prints("�e�H�ʧ@�w�g����\n"); break;
        case -3: prints("�ϥΪ� '%s' �L�k���H\n", uid); break;
        default: prints("�H��w���\\�a�H����@�� %s\n", uid);
    }
    pressreturn() ;
    return FULLUPDATE ;
}

int
post_article()
{
    struct fileheader postfile ;
    char	filepath[STRLEN], fname[STRLEN], *ip;
    char	ans[4], buf[256];
    int		fp, aborted;

    if (!haspostperm(currboard)) 
    {
	move( 3, 0 );
	clrtobot();
   	prints("\n\n        ���Q�װϬO��Ū��, ����ܨ�L�Q�װ�.\n");
	pressreturn();
	clear();
	return FULLUPDATE;
    }

    memset(&postfile,0,sizeof(postfile)) ;
    clear() ;
    sprintf( buf, "vote/%s/notes", currboard );
    if( dashf( buf ) ) {
	ansimore( buf, NA );
    } else if( dashf( "vote/notes" ) ) {
	ansimore( "vote/notes", NA );
    }
    move( t_lines - 3, 0 );
    prints("�o���峹�� '%s' �Q�װ�\n\n",currboard) ;

#ifndef NOREPLY
    if( replytitle[0] != '\0' ) {
	if( ci_strncmp( replytitle, "Re:", 3 ) == 0 )
	    strcpy(buf, replytitle);
	else 
	    sprintf(buf,"Re: %s", replytitle);
	buf[50] = '\0';
	sprintf(replytitle, "�ϥμ��D: \"%s\" �� (Y/N)? [Y]: ", buf);
	getdata(t_lines-2,0, replytitle,ans, 4, DOECHO, NULL);
	if (!(ans[0] == 'N' || ans[0] == 'n'))
	    strcpy(postfile.title, buf);
	else 
	    getdata(t_lines-2,0,"���D: ",postfile.title,STRLEN,DOECHO,NULL) ;
    } else
#endif
    	getdata(t_lines-2,0,"���D: ",postfile.title,STRLEN,DOECHO,NULL);
    strncpy(save_title,postfile.title,STRLEN) ;
    strncpy(save_filename,fname,4096) ;
    if( save_title[0] == '\0' ) {
	return FULLUPDATE;
    }

    sprintf(fname,"M.%d.A",time(NULL)) ;
    setbfile( filepath, currboard, fname );
    ip = strrchr(fname,'A') ;
    while((fp = open(filepath,O_CREAT|O_EXCL|O_WRONLY,0644)) == -1) {
	if(*ip == 'Z')
  	    ip++,*ip = 'A', *(ip + 1) = '\0' ;
	else
	    (*ip)++ ;
	setbfile( filepath, currboard, fname );
    }
    close(fp) ;
    strcpy(postfile.filename,fname) ;

    in_mail = NA ;
    strncpy(postfile.owner,currentuser.userid,STRLEN) ;
    setbfile( filepath, currboard, postfile.filename );

    local_article = 0;
    if ( !strcmp( postfile.title, buf ) && quote_file[0] != '\0' )
	if ( quote_file[255] == 'L' )
	    local_article = 1;

    modify_user_mode( POSTING );

    do_quote( filepath );

    aborted = vedit(filepath,YEA) ;
    strncpy( postfile.title, save_title, STRLEN );
    if ( aborted == 1 ) /* local save */
    {
	postfile.filename[ STRLEN - 1 ] = 'L';
	postfile.filename[ STRLEN - 2 ] = 'L';
    }

    if (aborted  == -1) {
	unlink( filepath );
    	pressreturn() ;
        clear() ;
        return FULLUPDATE ;
    }
    setbdir( buf, currboard );
    if (append_record( buf, &postfile, sizeof(postfile)) == -1) {
	sprintf(buf, "posting '%s' on '%s': append_record failed!",
      		postfile.title, currboard);
	report(buf);
	pressreturn() ;
	clear() ;
	return FULLUPDATE ;
    }
    brc_addlist( postfile.filename ) ;

    sprintf(buf,"posted '%s' on '%s'", postfile.title, currboard) ;
    report(buf) ;
    if ( !junkboard() ) {
        currentuser.numposts++;
	substitute_record(PASSFILE, &currentuser, sizeof(currentuser), usernum);
    }
    return FULLUPDATE ;
}

/*ARGSUSED*/
int
edit_post(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char buf[512] ;
    char *t ;

    if(!HAS_PERM(PERM_SYSOP)) {
	return DONOTHING ;
    }
    clear() ;
    strcpy(buf,direct) ;
    if( (t = strrchr(buf,'/')) != NULL )
	*t = '\0' ;
    sprintf(genbuf,"%s/%s",buf,fileinfo->filename) ;
    vedit(genbuf,NA) ;
    sprintf(genbuf, "edited post '%s' on %s", fileinfo->title, currboard);
    report(genbuf);
    return FULLUPDATE ;
}

int
edit_title(ent,fileinfo,direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
    char	buf[ STRLEN ];

    if(!HAS_PERM(PERM_SYSOP)) {
	return DONOTHING ;
    }
    getdata(t_lines-1,0,"�s�峹���D: ",buf,STRLEN,DOECHO,NULL) ;
    if( buf[0] != '\0' ) {
	strcpy(fileinfo->title,buf);
	substitute_record(direct, fileinfo, sizeof(*fileinfo), ent);
    }
    return PARTUPDATE;
}

int
mark_post(ent,fileinfo,direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
    if( !HAS_PERM(PERM_SYSOP) )
	if( (!HAS_PERM(PERM_BOARDS)) || strcmp( currBM, currentuser.userid ) )
	{
	    return DONOTHING;
	}
    if (fileinfo->accessed[0] & FILE_MARKED)
	fileinfo->accessed[0] &= ~FILE_MARKED;
    else fileinfo->accessed[0] |= FILE_MARKED;
    substitute_record(direct, fileinfo, sizeof(*fileinfo), ent);
    return PARTUPDATE;
}

int
del_range(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char num1[10],num2[10] ;
    int inum1, inum2 ;
    
    if(uinfo.mode == READING && !HAS_PERM(PERM_SYSOP)) {
        return DONOTHING ;
    }
    clear() ;
    prints("�ϰ�R��\n") ;
    getdata(1,0,"���g�峹�s��: ",num1,10,DOECHO,NULL) ;
    inum1 = atoi(num1) ;
    if(inum1 <= 0) {
        prints("���~�s��\n") ;
        pressreturn() ;
        return FULLUPDATE ;
    }
    getdata(2,0,"���g�峹�s��: ",num2,10,DOECHO,NULL) ;
    inum2 = atoi(num2) ;
    if(inum2 <= inum1) {
        prints("���~�s��\n") ;
        pressreturn() ;
        return FULLUPDATE ;
    }
    getdata(3,0,"�T�w�R�� (Y/N)? [N]: ",num1,10,DOECHO,NULL) ;
    if(*num1 == 'Y' || *num1 == 'y') {
        delete_range(direct,inum1,inum2) ;
	fixkeep(direct, inum1, inum2);
	sprintf(genbuf, "del %d-%d on %s", inum1, inum2, currboard);
	report(genbuf);
        prints("�R������\n") ;
        pressreturn() ;
        return DIRCHANGED ;
    }
    prints("Delete Aborted\n") ;
    pressreturn() ;
    return FULLUPDATE ;
}

int
del_post(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    FILE	*fn;
    char	buf[512];
    char	*t ;
    int		owned, keep, fail;

    keep = sysconf_eval( "KEEP_DELETED_HEADER" );
    if( fileinfo->owner[0] == '-' && keep > 0 ) {
	clear();
	prints( "���峹�w�R��.\n" );
	pressreturn();
	clear();
	return FULLUPDATE;
    }
    owned = ! strcmp( fileinfo->owner, currentuser.userid );
    if( !(owned) && !HAS_PERM(PERM_SYSOP) )
	if( (!HAS_PERM(PERM_BOARDS)) || strcmp( currBM, currentuser.userid ) )
	{
	    return DONOTHING ;
	}
    clear() ;
    prints("�R���峹 '%s'.",fileinfo->title) ;
    getdata(1,0,"(Y/N) [N]: ",genbuf,STRLEN,DOECHO,NULL) ;
    if(genbuf[0] != 'Y' && genbuf[0] != 'y') { /* if not yes quit */
	move(2,0) ;
	prints("����\n") ;
	pressreturn() ;
	clear() ;
	return FULLUPDATE ;
    }		
    strcpy(buf,direct) ;
    if( (t = strrchr(buf,'/')) != NULL )
	*t = '\0' ;
    sprintf(genbuf,"Del '%s' on '%s'",fileinfo->title,currboard) ;
    report(genbuf) ;
    strncpy(currfile,fileinfo->filename,STRLEN) ;
    if( keep <= 0 ) {
	fail = delete_file(direct,sizeof(struct fileheader),ent,cmpfilename);
    } else {
	fail = update_file(direct,sizeof(struct fileheader),ent,cmpfilename,
			  cpyfilename);
    }
    if( !fail ) {
	cancelpost( currboard, currentuser.userid, fileinfo, owned );
	sprintf(genbuf,"%s/%s",buf,fileinfo->filename) ;
	unlink( genbuf );
	if (owned) {
	    if (currentuser.numposts > 0) currentuser.numposts--;
	    substitute_record( PASSFILE, &currentuser,
				sizeof(currentuser), usernum);		
	}
	return DIRCHANGED;
    }
    move(2,0) ;
    prints("�R������\n") ;
    pressreturn() ;
    clear() ;
    return FULLUPDATE ;
}

static int sequent_ent ;

int
sequent_messages(fptr)
struct fileheader *fptr ;
{
    static int idc;

    if(fptr == NULL) {
	idc = 0 ;
	return 0 ;
    }
    idc++ ;
    if(idc < sequent_ent)
	return 0;
    if( !brc_unread( fptr->filename ) )  return 0;
    mot = 1 ;

    if (continue_flag != 0) {
	genbuf[ 0 ] = 'y';
    } else {
	prints("�Q�װ�: '%s' ���D:\n\"%s\" posted by %s.\n",
		 currboard,fptr->title,fptr->owner) ;
	getdata(3,0,"Ū�� (Y/N/Quit) [Y]: ",genbuf,5,DOECHO,NULL) ;
    }

    if(genbuf[0] != 'y' && genbuf[0] != 'Y' && genbuf[0] != '\0') {
	if(genbuf[0] == 'q' || genbuf[0] == 'Q') {
	    clear() ;
	    return QUIT ;
	}
	clear() ;
	return 0;
    }
    setbfile( genbuf, currboard, fptr->filename );
    strcpy( quote_file, genbuf );
    strcpy( quote_user, fptr->owner );
#ifdef NOREPLY
    more(genbuf,YEA);
#else
    more(genbuf,NA) ;
    move(t_lines-1, 0); 
    prints("[�s��Ū�H] �^�H R �x ���� Q,�� �x�U�@�� ' ',�� ");
    continue_flag = 0;
    switch( egetch() ) {
	case 'N': case 'Q':
	case 'n': case 'q':
	case KEY_LEFT: 
	    break;
	case 'Y' : case 'R':
	case 'y' : case 'r':
	    do_reply(fptr->title);
	case ' ': case '\n':
	case KEY_DOWN:
	    continue_flag = 1; break;
        case Ctrl('R'):
            /* post_reply uses only ftpr as argument! */
	    post_reply( 0, fptr, (char *)NULL );
	    break;
	default : break;
    }
#endif
    clear() ;
    setbdir( genbuf, currboard );
    brc_addlist( fptr->filename ) ;
    return 0;
}

/*ARGSUSED*/
int
sequential_read(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char	buf[ STRLEN ];
    clear() ;
    sequent_messages((struct fileheader *)NULL) ;
    sequent_ent = ent ;
    quiting = NA ;
    continue_flag = 0;
    setbdir( buf, currboard );
    apply_record( buf,sequent_messages,sizeof(struct fileheader)) ;
    return FULLUPDATE ;
}

#ifdef INTERNET_EMAIL
int
forward_post(ent,fileinfo,direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
    if( strcmp( "guest", currentuser.userid) == 0 )
	return DONOTHING;
    return(mail_forward(ent, fileinfo, direct));
}

int
forward_u_post(ent,fileinfo,direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
    if( strcmp( "guest", currentuser.userid) == 0 )
	return DONOTHING;
    return(mail_uforward(ent, fileinfo, direct));
}

#endif

extern int mainreadhelp() ;
extern int b_vote();
extern int b_results();
extern int b_vote_maintain();
extern int b_notes_edit();

struct one_key  read_comms[] = {
    'r',	read_post,
    'K',	skip_post,
    'd',	del_post,
    'D',	del_range,
    'm',	mark_post,
    'E',	edit_post,
    'T',	edit_title,
    's',	do_select,
    Ctrl('P'),	do_post,
    'S',	sequential_read,
#ifdef INTERNET_EMAIL
    'F',	forward_post,
    'U',	forward_u_post,
    Ctrl('R'),	post_reply,
#endif
    'R',	b_results,
    'V',	b_vote,
    'M',	b_vote_maintain,
    'W',	b_notes_edit,
    'h',	mainreadhelp,
    Ctrl('J'),	mainreadhelp,
    '\0',	NULL
  } ;

int
Read()
{
    char	buf[ STRLEN ];

    if(!selboard) {
	move(2,0) ;
	prints("�Х���ܰQ�װ�\n") ;
	pressreturn() ;
	move(2,0) ;
	clrtoeol() ;
	return -1 ;
    }
    in_mail = NA;
    brc_initial( currboard );
    setbdir( buf, currboard );
    i_read( READING, buf,readtitle,readdoent,&read_comms[0]) ;
    brc_update();
    return 0 ;
}

int
Goodbye()
{
    extern int	started ;
    time_t	stay;

    move(2,0);
    getdata(2,0, "�A�T�w�n���} BBS ��? (Yes/No) [N]: ",
			genbuf, 4, DOECHO, NULL );
    if ( *genbuf != 'y' && *genbuf != 'Y' ) {
	clear();
	return 0;
    }

    clear() ;
    prints("�˷R�� %s (%s)�A�O�ѤF�A�ץ��{ ", 
	currentuser.userid, currentuser.username);
    standout();
    prints("%s", BoardName);
    standend();
    prints(" �A�A�|��!\n\n");

    prints("�H�U�O�z�b���������U���:\n");
    user_display( &currentuser, 0 );
    report("exit") ;

    stay = time(NULL) - login_start_time; 
    if(started) {
	sprintf( genbuf, "Stay:%3ld (%s)", stay / 60, currentuser.username );
	log_usies( "EXIT ", genbuf );
	u_exit() ;
    }

    pressreturn();
    sleep(1);
    reset_tty() ;
    exit(0) ;
    return -1;
}

void
report(s)
char *s ;
{
    static int disable = NA ;
    int fd ;

    if(disable)
	return ;
    if((fd = open("trace",O_WRONLY,0644)) != -1 ) {
	char buf[512] ;
	char timestr[10], *thetime;
	time_t dtime;
	time(&dtime);
	thetime = ctime(&dtime);
	strncpy(timestr, &(thetime[11]), 8);
	timestr[8] = '\0';
	flock(fd,LOCK_EX) ;
	lseek(fd,0,SEEK_END) ;
	sprintf(buf,"%s %s %s\n",currentuser.userid, timestr, s) ;
	write(fd,buf,strlen(buf)) ;
	flock(fd,LOCK_UN) ;
	close(fd) ;
	return ;
    }
    disable = YEA ;
    return ;
}

int
Info()
{
    ansimore("Version.Info",YEA) ;
    clear() ;
    return 0 ;
}

int
Conditions()
{
    ansimore("COPYING",YEA) ;
    clear() ;
    return 0 ;
}

int
Welcome()
{
    ansimore( "Welcome", YEA );
    clear() ;
    return 0 ;
}

int
EditWelcome()
{
    int aborted;
    char ans[7];
    move(3,0);
    clrtoeol();
    clrtobot();
    getdata(3,0,"(E)�s�� or (D)�R�� Welcome? [E]: ",ans,7,DOECHO,NULL);
    if (ans[0] == 'D' || ans[0] == 'd') {
	unlink("Welcome");
	move(5,0);
	prints("�w�R��!\n");
	pressreturn();
	clear();
	report( "del welcome" ) ;
	return 0;
    }
    modify_user_mode( EDITWELC );
    aborted = vedit("Welcome", NA);		
    clear() ;
    if (aborted)
	prints("�����s��.\n");
    else {
	report("edit Welcome") ;
	prints("�ק粒��.\n") ;
    }
    pressreturn() ;
    return 0 ;
}

int
cmpbnames( bname, brec)
char *bname;
struct fileheader *brec;
{
    if (!ci_strncmp( bname, brec->filename, sizeof(brec->filename)))
	return 1;
    else
	return 0;
}

void
cancelpost( board, userid, fh, owned )
char	*board, *userid;
struct fileheader *fh;
int	owned;
{
    struct fileheader	postfile;
    FILE	*fin, *fout;
    char	from[ STRLEN ], path[ STRLEN ];
    char	fname[ STRLEN ], *ptr, *brd;
    int		len;

    setbfile( genbuf, board, fh->filename );
    if( (fin = fopen( genbuf, "r" )) != NULL ) {
	brd = owned ? "junk" : "deleted";
	sprintf( fname, "M.%d.A", time(NULL) );
	setbfile( genbuf, brd, fname );
	if( (fout = fopen( genbuf, "w" )) != NULL ) {
	    memset(&postfile,0,sizeof(postfile)) ;
	    sprintf( genbuf, "%-35.35s - %s", fh->title, userid );
	    strcpy( postfile.filename, fname );
	    strncpy( postfile.owner, fh->owner, IDLEN );
	    strncpy( postfile.title, genbuf, STRLEN );
	    postfile.filename[ STRLEN - 1 ] = 'D';
	    postfile.filename[ STRLEN - 2 ] = 'D';
	}
	while( fgets( genbuf, sizeof( genbuf ), fin ) != NULL ) {
	    if( fout != NULL ) {
		fputs( genbuf, fout );
	    }
	    len = strlen( genbuf ) - 1;
	    genbuf[ len ] = '\0';
	    if( len <= 8 ) {
		break;
	    } else if( strncmp( genbuf, "�o�H�H: ", 8 ) == 0 ) {
		if( (ptr = strrchr( genbuf, ',' )) != NULL )
		    *ptr = '\0';
		strcpy( from, genbuf + 8 );
	    } else if( strncmp( genbuf, "��H��: ", 8 ) == 0 ) {
		strcpy( path, genbuf + 8 );
	    }
	}
	if( fout != NULL ) {
	    while( fgets( genbuf, sizeof( genbuf ), fin ) != NULL )
		fputs( genbuf, fout );
	}
	fclose( fin );
	if( fout != NULL ) {
	    fclose( fout );
	    setbdir( genbuf, brd );
	    append_record( genbuf, &postfile, sizeof(postfile) );
	}
	sprintf( genbuf, "%s\t%s\t%s\t%s\t%s\n",
		 board, fh->filename, userid, from, path );
	if( (fin = fopen( "cancelpost.lst", "a" )) != NULL ) {
	    fputs( genbuf, fin );
	    fclose( fin );
	}
    }
}

