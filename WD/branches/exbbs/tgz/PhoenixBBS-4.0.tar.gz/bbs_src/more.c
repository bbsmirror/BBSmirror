/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
			Guy Vega, gtvega@seabass.st.usm.edu
			Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"

#define MORE_BUFSIZE	4096

char	more_buf[ MORE_BUFSIZE ];
int	more_size, more_num;
int	showansi = 0;

char *more_help[] = {
    "\02�\\Ū�峹�\\����ϥλ���",
    "",
    "\01��в��ʥ\\����",
    "�� �� k             �W���@��",
    "�� �� j �� Enter    �U���@��",
    "PgUp �� ^B          �W���@��",
    "PgDn �� ^F          �U���@��", 
    "�� �� �ť���        �U���@��",
    "",
    "\01��L�\\����",
    "�� �� Q             ����",
    "h �� H �� ?         ���U�����e��",
    NULL };


int
readln(fd,buf)
int fd ;
char *buf ;
{
    int len, bytes, in_esc, ch;

    len = bytes = in_esc = 0;
    while( 1 ) {
	if( more_num >= more_size ) { 
	    more_size = read( fd, more_buf, MORE_BUFSIZE );
	    if( more_size == 0 ) {
		break;
	    }
	    more_num = 0;
	}
	ch = more_buf[ more_num++ ];
	bytes++;
	if( ch == '\n' || len >= 79 || bytes > 250 ) {
	    break;
	} else if( ch == '\t' ) {
	    do {
		len++, *buf++ = ' ';
	    } while( (len % 8) != 0 );
	} else if( ch == '\033' ) {
	    if( showansi )  *buf++ = ch;
	    in_esc = 1;
	} else if( in_esc ) {
	    if( showansi )  *buf++ = ch;
	    if( strchr( "[0123456789;,", ch ) == NULL ) {
		in_esc = 0;
	    }
	} else if( isprint2( ch ) ) {
	    len++, *buf++ = ch;
	}
    }
    *buf++ = ch;
    *buf = '\0';
    return bytes;
}

int
morekey()
{
    while( 1 ) {
	switch( egetch() ) {
	    case 'q':  case KEY_LEFT:  case EOF:
		return KEY_LEFT;
	    case ' ':  case KEY_RIGHT: 
	    case KEY_PGDN: case Ctrl('F'):
		return KEY_RIGHT;
	    case KEY_PGUP : case Ctrl('B'):
		return KEY_PGUP;
	    case '\r': case KEY_DOWN: case 'j':
		return KEY_DOWN;
	    case 'k' : case KEY_UP:
		return KEY_UP;
	    case 'h': case 'H': case '?':
		return 'H';
	    default:	;
	}
    }
}

int seek_nth_line(fd, no)
int fd, no;
{
   int	n_read, line_count, viewed;
   char *p, *end;

   lseek(fd, 0, SEEK_SET );
   line_count = viewed = 0;
   if ( no > 0 ) while ( 1 ) {
       n_read = read( fd, more_buf, MORE_BUFSIZE );
       p = more_buf; end = p + n_read;
       for ( ; p < end && line_count < no; p++) 
           if (*p == '\n') line_count++;
       if (line_count >= no) {
           viewed += ( p - more_buf ); 
           lseek(fd, viewed, SEEK_SET);
           break; 
       } else viewed += n_read;
   }  
    
   more_num = MORE_BUFSIZE + 1;  /* invalidate the readln()'s buffer */
   return viewed;
}

int
rawmore(filename,promptend)
char	*filename;
int	promptend;
{
    extern int	t_lines ;
    struct stat st ;
    int		fd, tsize;
    char	buf[ 256 ] ;
    int		i, ch, viewed, pos ;
    int 	numbytes ;
    int		curr_row = 0;

    if( (fd = open(filename,O_RDONLY)) == -1 ) {
        return -1;
    }
    if( fstat( fd, &st ) ) {
        return -1;
    }
    tsize = st.st_size ;
    more_size = more_num = 0;

    clear() ;
    i = pos = viewed = 0 ;
    numbytes = readln(fd,buf) ;  curr_row++;
    while( numbytes ) {
	viewed += numbytes ;
	prints( "%s", buf ) ;
	i++ ;
	pos++ ;
	if(pos == t_lines) {
	    scroll() ;
	    pos-- ;
	}
	numbytes = readln(fd,buf) ; curr_row++;
	if( numbytes == 0 )
	    break ;
	if( i == t_lines -1 ) {
	    if( showansi ) {
		move( t_lines-1, 0 ) ;
		prints( "\033[37;40;0m\033[m" );
		refresh();
	    }
	    move( t_lines-1, 0 ) ;
	    standout() ;
	    prints("--More-- (%d%%)", (viewed*100)/tsize) ;
	    standend() ;
	    prints("�x���� �� <q> �x��/��/PgUp/PgDn ���ʢx? ���U�����x ");
	    ch = morekey();
	    move( t_lines-1, 0 );
	    clrtoeol();
	    refresh();
	    if( ch == KEY_LEFT ) {
		close( fd );
		return ch;
	    } else if( ch == KEY_RIGHT ) {
		i = 1;
	    } else if( ch == KEY_DOWN ) {
		i = t_lines-2 ;
	    } else if(ch == KEY_PGUP || ch == KEY_UP) {
		clear(); i = pos = 0;
		curr_row -= (ch == KEY_PGUP) ? (2 * t_lines - 2) : (t_lines + 1);
		if (curr_row < 0) { close( fd ); return ch; }
        	viewed = seek_nth_line(fd, curr_row);        
                numbytes = readln(fd,buf) ;  curr_row++;
	    } else if(ch == 'H') {
		show_helpmenu( more_help );
		i = pos = 0;
		curr_row -= (t_lines);
		if (curr_row < 0) curr_row = 0;
        	viewed = seek_nth_line(fd, curr_row);        
                numbytes = readln(fd,buf) ;  curr_row++;
            }
	}
    }

    close( fd ) ;
    if( promptend ) {
	pressanykey();
    }
    return 0 ;
}

int
more(filename,promptend)
char	*filename ;
int	promptend;
{
    showansi = 0;
    return rawmore( filename, promptend );
}

int
ansimore(filename,promptend)
char	*filename ;
int	promptend;
{
    int ch;

    showansi = 1;
    if( (ch = rawmore( filename, promptend )) != -1 ) {
	move( t_lines-1, 0 );
	prints( "\033[37;40;0m\033[m" );
	refresh();
    }
    showansi = 0;
    return ch;
}

