/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
			Guy Vega, gtvega@seabass.st.usm.edu
			Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"
#ifdef lint
#include <sys/uio.h>
#endif
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#define M_INT 8 	/* monitor mode update interval */
#define P_INT 20        /* interval to check for page req. in talk/chat */

struct talk_win {
    int		curcol, curln;
    int		sline, eline;
};

int	bind(/*int,struct sockaddr *, int*/) ;
char	*sysconf_str();

int	real_user_names = 0;
char	*friends_list = NULL;
int	friends_number = 0;

#include "modetype.c"

extern int t_columns;
char	*talk_uent_buf;

/* begin - jjyang */
char save_page_requestor[STRLEN];
/* end - jjyang */

int t_cmpuids();

int
ishidden(user)
char *user;
{
    int tuid;
    struct user_info uin;

    if (!(tuid = getuser(user))) return 0;
    search_ulist( &uin, t_cmpuids, tuid );
    return( uin.invisible );
}

char *
modestring(mode, towho, complete, chatid)
int mode, towho, complete;
char *chatid;
{
    static char modestr[STRLEN];
    struct userec urec;

    if (chatid) {
	if (complete) sprintf(modestr, "%s as '%s'", ModeType(mode), chatid);
	else return (ModeType(mode));
	return (modestr);
    }
    if (mode != TALK && mode != PAGE && mode != QUERY)
	return (ModeType(mode));
    if (get_record(PASSFILE, &urec, sizeof(urec), towho) == -1)
	return (ModeType(mode));

    if (mode != QUERY && !HAS_PERM(PERM_SEECLOAK) && 
	ishidden(urec.userid)) return (ModeType(TMENU));	
    if (complete)
	sprintf(modestr, "%s '%s'", ModeType(mode), urec.userid);
    else
	return (ModeType(mode));
    return (modestr);
}

char
pagerchar(me, them, pager)
char *me, *them;
int pager;
{
    if (pager) return ' ';
    else if( can_override( them, me ) ) return 'O';
    else return '*';
}

#ifdef SHOW_IDLE_TIME
char *
idle_str( uent )
struct user_info *uent ;
{
    static char hh_mm_ss[ 32 ];
    struct stat buf;
    char	tty[ 128 ];
    time_t	now, diff;
    int		hh, mm;

    strcpy( tty, uent->tty );

    if ( (stat( tty, &buf ) != 0) || 
         (strstr( tty, "tty" ) == NULL)) {
	strcpy( hh_mm_ss, "����");
	return hh_mm_ss;
    };

    now = time( 0 );

    diff = now - buf.st_atime;

#ifdef DOTIMEOUT
    /* the 60 * 60 * 24 * 5 is to prevent fault /dev mount from
       kicking out all users */

    if ((diff > IDLE_TIMEOUT) && 
        (diff < 60 * 60 * 24 * 5 )) kill( uent->pid, SIGHUP );
#endif

    hh = diff / 3600;
    mm = (diff / 60) % 60;
    
    if ( hh > 0 ) 
        sprintf( hh_mm_ss, "%d:%02d", hh, mm );
    else if ( mm > 0 ) 
        sprintf( hh_mm_ss, "%d", mm );
    else sprintf ( hh_mm_ss, "   ");

    return hh_mm_ss;
}
#endif

int
print_user_info_title()
{
    char title_str[ 512 ];
    char *field_2 ;

    field_2 = "�ϥΪ̼ʺ�";
    if (real_user_names) field_2 = "�u��m�W  ";
    sprintf( title_str, 
	"%-12.12s %-16.16s %-16.16s %c %c %-16.16s %10s\n",
	"�ϥΪ̥N��", field_2, "�Ӧ�", 'P',
	(HAS_PERM(PERM_SEECLOAK) ? 'C' : ' '), "�ʺA",
#ifdef SHOW_IDLE_TIME
	"���m ��:��" );
#else
	"" );
#endif
    prints( "%s", title_str );
    return 0;
}

int
printcuent(uentp)
struct user_info *uentp ;
{
    static int i ;
    char user_info_str[ 128 ];
    char *field_2;

    if( uentp == NULL ) {
	move(3,0);
	print_user_info_title();
	i = 3;
	return 0;
    }
    if( !uentp->active || !uentp->pid )
	return 0;
    if(!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
	return 0;
    if( friends_list != NULL ) {
	sprintf( user_info_str, " %s ", uentp->userid );
	if( strstr( friends_list, user_info_str ) == NULL )
	    return 0;
	friends_number++;
    }
    if( i == t_lines - 2 ) {
	int ch ;

	standout() ;
	prints("-- �~�� (�� Q ����) --") ;
	standend() ;
	clrtoeol();
	while((ch = igetch()) != EOF) {
	    if(strchr ("\n\r qQ", ch)) break ;
	}
	if (strchr("Qq", ch)) return QUIT;
	move(3,0) ;
	print_user_info_title();
	i = 3 ;
	clrtobot() ;
    }

    field_2 = uentp->username;
    if (real_user_names) field_2 = uentp->realname;

    sprintf( user_info_str, 
	"%-12.12s %-16.16s %-16.16s %c %c %-16.16s %10.10s\n",
	uentp->userid, field_2,
	(uentp->pager == YEA || HAS_PERM(PERM_SYSOP))? uentp->from : "*", 
	pagerchar(currentuser.userid, uentp->userid, uentp->pager),
	(uentp->invisible ? '#' : ' '), 
	modestring(uentp->mode, uentp->destuid, 1,
		(uentp->in_chat ? uentp->chatid : NULL)),
#ifdef SHOW_IDLE_TIME
	idle_str( uentp ) );
#else
	"" );
#endif
    prints( "%s", user_info_str );
    i++ ;
    return 0 ;
}

int
listcuent(uentp)
struct user_info *uentp ;
{
    if(uentp == NULL) {
	CreateNameList() ;
	return 0;
    }
    if(uentp->uid == usernum)
	return 0;
    if(!uentp->active || !uentp->pid)
	return 0;
    if(uentp->mode == ULDL)
	return 0;
    if(!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
	return 0;
    AddNameList( uentp->userid );
    return 0 ;
}

void
creat_list()
{
    listcuent(NULL) ;
    apply_ulist( listcuent );
}

int
t_users()
{
    modify_user_mode( LUSERS );
    printcuent( NULL ) ;
    if ( apply_ulist( printcuent ) == -1 ) 
	prints("�S������ϥΪ̤W�u\n") ;
    clrtobot() ;
    pressreturn();
    return 0;
}

void
t_rusers()
{
    real_user_names = 1;
    t_users();
    real_user_names = 0;
}

int
t_pager()
{
    uinfo.pager = (uinfo.pager) ? NA : YEA;
    update_utmp();
    if ( !uinfo.in_chat ) {
	move( 2, 0 );
	prints( "�z���I�s�� (pager) �w�g%s�F!",
		uinfo.pager ? "���}" : "����" );
	pressreturn();
    }
    return 0 ;

}

int
t_query()
{
    char	uident[STRLEN], inbuf[STRLEN*2], *newline ;
    int		tuid, i;
    FILE	*planfile;
	
    modify_user_mode( QUERY );
    move(2,0);
    prints("<��J�ϥΪ̥N��, ���ť���i�C�X�ŦX�r��>\n");
    move(1,0);
    clrtoeol();
    prints("�d�߽�: ");
	
    usercomplete(NULL,uident);
    if(uident[0] == '\0') {
	clear() ;
	return 0 ;
    }
    if(!(tuid = getuser(uident))) {
	move(2,0) ;
	prints("�����T���ϥΪ̥N��\n") ;
	pressreturn() ;
	move(2,0) ;
	clrtoeol() ;
	return -1 ;
    }
    uinfo.destuid = tuid ;
    update_utmp();

    move(3,0);
    clrtobot();
    sprintf(genbuf, "�d�� %s", lookupuser.userid);
    report(genbuf);
    prints( "%s (%s). �@�W�� %d ��, ���U���: %s",
	lookupuser.userid, lookupuser.username, lookupuser.numlogins,
	ctime( &lookupuser.firstlogin ) );

    strcpy(genbuf, ctime(&(lookupuser.lastlogin)));
    if( (newline = strchr(genbuf, '\n')) != NULL )
	*newline = '\0';
    prints( "�W�� login %s �q %s\n", genbuf, 
	(lookupuser.lasthost[0] == '\0' ? "(����)" : lookupuser.lasthost));

#if defined(QUERY_REALNAMES)
    if (HAS_PERM(PERM_BASIC))	
	prints("Real Name: %s \n",lookupuser.realname);
#endif
    sethomefile( genbuf, lookupuser.userid, "plans" );
    if ((planfile = fopen(genbuf, "r")) == NULL)
	prints("�ثe�L����p��.\n");
    else {
	prints("�p��:\n");
	for (i=1; i<=MAXQUERYLINES; i++) {
	    if (fgets(inbuf, sizeof(inbuf), planfile))
		prints("%s", inbuf);
	    else break;
	}
	fclose(planfile);
    }
    pressreturn();
    uinfo.destuid = 0;
    return 0;
}		

int
count_active(uentp)
struct user_info *uentp ;
{
    static int count ;

    if(uentp == NULL) {
	int c = count;
	count = 0;
	return c;
    }
    if(!uentp->active || !uentp->pid)
	return 0 ;
    count++ ;
    return 1 ;
}

int
num_active_users()
{
    count_active(NULL) ;
    apply_ulist( count_active ) ;
    return count_active(NULL) ;
}

int
t_cmpuids(uid,up)
int uid ;
struct user_info *up ;
{
    return (up->active && uid == up->uid) ;
}

int
t_talk()
{
    char uident[STRLEN] ;
    int tuid ;
    struct user_info uin ;

    move(2,0) ;
    prints("<��J�ϥΪ̥N��>\n") ;
    move(1,0) ;
    clrtoeol() ;
    prints("��ֲ��: ") ;
    creat_list() ;
    namecomplete(NULL,uident) ;
    if(uident[0] == '\0') {
	clear() ;
	return 0 ;
    }
    if(!(tuid = getuser(uident)) || tuid == usernum) {
	move(2,0) ;
	prints("���~�N��\n") ;
	pressreturn() ;
	move(2,0) ;
	clrtoeol() ;
	return -1 ;
    }
    search_ulist( &uin, t_cmpuids, tuid );
    /*  check if pager on/off       --gtv */
    if (!HAS_PERM(PERM_SYSOP)) {
	if( uin.pager == NA &&
	    !can_override(uin.userid, currentuser.userid)) {
	    move(2,0) ;
	    prints("���I�s���w����.\n") ;
	    pressreturn() ;
	    move(2,0) ;
	    clrtoeol() ;
	    return -1 ;
	}
    }
    if(uin.mode == ULDL || uin.mode == IRCCHAT || 
	uin.mode == BBSNET || uin.mode == FOURM) {
	move(2,0) ;
	prints("�ثe�L�k�I�s.\n") ;
	pressreturn() ;
	move(2,0) ;
	clrtoeol() ;
	return -1 ;
    }
    if(!uin.active || (kill(uin.pid,0) == -1)) {
	move(2,0) ;
	prints("���w���}\n") ;
	pressreturn() ;
	move(2,0) ;
	clrtoeol() ;
	return -1 ;
    } else {
	int sock, msgsock, length ;
	struct sockaddr_in server ;
	char c ;
	char buf[512] ;
	FILE *planfile;

	move( 3, 0 );
	clrtobot();
	sethomefile( genbuf, uident, "plans" );
	if ( ( planfile = fopen( genbuf, "r" ) ) == NULL ) {
	     prints( "%s �S������p��.\n", uident );
	} else {
	     prints( "%s ���p��:\n\n", uident );
	     for ( length = 0; length < MAXQUERYLINES; length++ ) {
                 if( fgets( genbuf, sizeof(genbuf), planfile ) )
                     prints( "%s", genbuf );
                 else 
                     break;
             }
	     fclose( planfile );
	}
	getdata( 2, 0, "�T�w�n�M�L/�o�ͤѶ�? (Y/N) [N]: ", genbuf, 4, DOECHO, NULL );
	if ( *genbuf != 'y' && *genbuf != 'Y' ) {
	    clear();
	    return 0;
	}

	sprintf(buf,"Talk to '%s'",uident) ;
	report(buf) ;
	sock = socket(AF_INET, SOCK_STREAM, 0) ;
	if(sock < 0) {
	    perror("socket err\n") ;
	    return -1 ;
	}

	server.sin_family = AF_INET ;
	server.sin_addr.s_addr = INADDR_ANY ;
	server.sin_port = 0 ;
	if(bind(sock, (struct sockaddr *) & server, sizeof server ) < 0) {
	    perror("bind err") ;
	    return -1 ;
	}
	length = sizeof server ;
	if(getsockname(sock, (struct sockaddr *) &server, &length) < 0) {
	    perror("socket name err") ;
	    return -1 ;
	}
	uinfo.sockactive = YEA ;
	uinfo.sockaddr = server.sin_port ;
	uinfo.destuid = tuid ;
	modify_user_mode( PAGE );
	kill(uin.pid,SIGUSR1) ;
	clear() ;
	prints("�I�s %s ��...\n��J Ctrl-D ����\n", uident) ;

	listen(sock,1) ;
	add_io(sock,20) ;
	while(YEA) {
	    int ch ;
	    ch = igetch() ;
	    if(ch == I_TIMEOUT) {
		move(0,0) ;
		prints("�A���I�s.\n") ;
		bell() ;
		if(kill(uin.pid,SIGUSR1) == -1) {
		    move(0,0) ;
		    prints("���w���u\n") ;
		    pressreturn() ;
		    return -1 ;
		}
		continue ;
	    }
	    if(ch == I_OTHERDATA)
		break ;
	    if(ch == '\004') {
		add_io(0,0) ;
		close(sock) ;
		uinfo.sockactive = NA ;
		uinfo.destuid = 0 ;
		clear() ;
		return 0 ;
	    }
	}

	msgsock = accept(sock, (struct sockaddr *)0, (int *) 0) ;
	if(msgsock == -1) {
	    perror("accept") ;
	    return -1 ;
	}
        add_io(0,0) ;
	close(sock) ;
	uinfo.sockactive = NA ;
/*	uinfo.destuid = 0 ;*/
	read(msgsock,&c,sizeof c) ;

/* BEGIN -- by jjyang */
	if(c == 'y') {
	    sprintf( save_page_requestor, "%s (%s)", uin.userid, uin.username);
	    do_talk(msgsock) ;
/* BEGIN -- by jjyang */
	} else {
	    clear() ;
	    prints("�I�s����.\n") ;
	    pressreturn() ;
	}
	close(msgsock) ;
	clear() ;
	uinfo.destuid = 0;
    }
    return 0 ;
}

extern int talkrequest ;
extern int ntalkrequest ;
struct user_info  ui ;
char page_requestor[STRLEN];
char page_requestorid[STRLEN];

int
cmpunums(unum,up)
int unum ;
struct user_info *up ;
{
    if(!up->active)
      return 0 ;
	return (unum == up->destuid) ;
}

int
setpagerequest()
{
    int tuid;

    tuid = search_ulist( &ui, cmpunums, usernum );
    if(tuid == 0)
	return 1;
    if(!ui.sockactive)
	return 1;
    uinfo.destuid = ui.uid;
    sprintf(page_requestor, "%s (%s)", ui.userid, ui.username);
    strcpy( page_requestorid, ui.userid );
    return 0;
}

int
servicepage( line, mesg )
int	line;
char	*mesg;
{
    static time_t last_check;
    time_t now;
    char buf[STRLEN];
    int tuid = search_ulist( &ui, cmpunums, usernum );

    if(tuid == 0 || !ui.sockactive) talkrequest = NA;
    if (!talkrequest) {
	if (page_requestor[0]) {
	    switch (uinfo.mode) {
		case TALK:
		    move(line, 0);
		    printdash( mesg );
		    break;
		default: /* a chat mode */
		    sprintf(buf, "** %s �w����I�s.", page_requestor);
		    printchatline(buf);
	    }
	    memset(page_requestor, 0, STRLEN);
	    last_check = 0;
	}
	return NA;
    } else {
	now = time(0);
	if (now - last_check > P_INT) {
	    last_check = now;
	    if (!page_requestor[0] && setpagerequest())
		return NA;
            else switch (uinfo.mode) {
		case TALK:
		    move(line, 0);
		    sprintf(buf, "** %s ���b�I�s�A", page_requestor);
		    printdash( buf );
		    break;
		default: /* chat */
		    sprintf(buf, "** %s ���b�I�s�A", page_requestor);
                    printchatline(buf);
	    }
	}
    }
    return YEA;
}

static char npage_requestor[STRLEN];

int
setnpagerequest()
{
    char tmp_buf[STRLEN + 128];
    FILE *getpager;

    if (sysconf_str("GETPAGER") == NULL) return 1;

    sprintf(tmp_buf,"%s %s", sysconf_str("GETPAGER"),currentuser.userid);
    getpager = popen(tmp_buf,"r"); 
    if (getpager == NULL) 
       return 1;
    fgets(npage_requestor, STRLEN, getpager);
    if ( *npage_requestor == '\0')
       return 1;
    return 0;
}

void
ndo_talk(pager,reject)
char *pager ;
int reject;
{
    char tmp_buf[STRLEN + 128];

    if (reject) {
     sprintf(tmp_buf,"/bin/sh %s %s", sysconf_str("REJECTCALL"),pager);
    } else {
     sprintf(tmp_buf,"/bin/sh %s %s", sysconf_str("NTALK"),pager);
     modify_user_mode( TALK );
    }
    reset_tty() ;
    do_exec(tmp_buf,NULL) ;
    restore_tty() ;
    /*clear();*/
}

int
ntalkreply()
{
    char buf[512] ;
    char inbuf[STRLEN*2];

    talkrequest = NA ;
    ntalkrequest = NA ;

    if (setnpagerequest()) return 0;	
    clear() ;

    sprintf( inbuf, "�A�Q�� %s ���Ѷ�? (Yes or No) [Y]: ", npage_requestor );
    getdata(2,0, inbuf ,buf,STRLEN,DOECHO,NULL) ;

    if(buf[0] != 'n' && buf[0] != 'N') buf[0] = 'y';
    if(buf[0] != 'y') {
	report("page refused");
	ndo_talk(npage_requestor,1) ;
	clear() ;
	return 0 ;
    }
    report("page accepted");
    ndo_talk(npage_requestor,0) ;
    clear() ;
    return 0 ;
}

int
talkreply()
{
    int a ;
    struct hostent *h ;
    char buf[512] ;
    char hostname[STRLEN] ;
    struct sockaddr_in sin ;
    FILE *planfile;
    char inbuf[STRLEN*2];
    int i;
                
    talkrequest = NA ;
#ifdef BBSNTALKD
    ntalkrequest = NA ;
#endif
    if (setpagerequest()) return 0;	
    clear() ;

/* to show plan -cuteyu */

    move( 3, 0 );
    clrtobot();
    sethomefile( genbuf, page_requestorid, "plans" );
    report( genbuf );
    if ( ( planfile = fopen( genbuf, "r" ) ) == NULL ) {
	prints( "%s �S������p��.\n", page_requestorid );
    } else {
	prints( "%s ���p��:\n\n", page_requestorid );
	for ( i = 1; i <= MAXQUERYLINES; i++ ) {
	    if ( fgets( inbuf, sizeof(inbuf), planfile ) )
		prints( "%s", inbuf );
	    else 
		break;
	}
	fclose( planfile );
    } 
    sprintf( inbuf, "�A�Q�� %s ���Ѷ�? (Y/N) [Y]: ", page_requestor );
    strcpy(save_page_requestor, page_requestor);
    memset(page_requestor, 0, sizeof(page_requestor));
    memset(page_requestorid, 0, sizeof(page_requestorid));
    getdata(2,0, inbuf ,buf,STRLEN,DOECHO,NULL) ;
    gethostname(hostname,STRLEN) ;
    if(!(h = gethostbyname(hostname))) {
	perror("gethostbyname") ;
	return -1 ;
    }
    memset(&sin, 0, sizeof sin) ;
    sin.sin_family = h->h_addrtype ;
    memcpy( &sin.sin_addr, h->h_addr, h->h_length) ;
    sin.sin_port = ui.sockaddr ;
    a = socket(sin.sin_family,SOCK_STREAM,0) ;
    if((connect(a, (struct sockaddr *)&sin, sizeof sin))) {
	perror("connect err") ;
	return -1 ;
    }
    if(buf[0] != 'n' && buf[0] != 'N') buf[0] = 'y';
    write(a,buf,1) ;
    if(buf[0] != 'y') {
	close(a) ;
	report("page refused");
  	clear() ;
	return 0 ;
    }
    report("page accepted");
    do_talk(a) ;
    close(a) ;
    clear() ;
    return 0 ;
}

int
dotalkent(uentp, buf)
struct user_info *uentp;
char *buf;
{
    char mch;
    if (!uentp->active || !uentp->pid) return -1;
    if(!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
	return -1;
    switch(uentp->mode) {
	case ULDL: mch = 'U'; break;
	case TALK: mch = 'T'; break;
	case CHAT1:
	case CHAT2:
	case CHAT3:
	case CHAT4: mch = 'C'; break;
	case IRCCHAT: mch = 'I'; break;
	case FOURM: mch = '4'; break;
	case BBSNET: mch = 'B'; break;
	case READNEW:
	case READING: mch = 'R'; break;
	case POSTING: mch = 'P'; break;
	case SMAIL:
	case RMAIL:
	case MAIL: mch = 'M'; break;
	default: mch = '-';
    }
    sprintf(buf, "%s%s(%c), ", uentp->invisible?"*":"", uentp->userid, mch);
    return 0;
}
 
int
dotalkuent(uentp)
struct user_info *uentp;
{
    char	buf[ STRLEN ];

    if( dotalkent( uentp, buf ) != -1 ) {
	strcpy( talk_uent_buf, buf );
	talk_uent_buf += strlen( buf );
    }
    return 0;
}
 
void
do_talk_nextline( twin )
struct talk_win *twin;
{
    int		curln;

    curln = twin->curln + 1;
    if( curln > twin->eline )
	curln = twin->sline;
    if( curln != twin->eline ) {
	move( curln + 1, 0 );
	clrtoeol();
    }
    move( curln, 0 );
    clrtoeol();
    twin->curcol = 0;
    twin->curln  = curln;
}
 
void
do_talk_char( twin, ch )
struct talk_win	*twin;
int		ch ;
{
    extern int dumb_term ;

    if(isprint2(ch)) {
	if( twin->curcol < 79) {
	    move( twin->curln, (twin->curcol)++ );
	    prints( "%c",ch );
	    return;
	}
	do_talk_nextline( twin );
	twin->curcol++;
	prints( "%c", ch );
	return;
    }
    switch(ch) {
	case Ctrl('H'):
	case '\177':
	    if(dumb_term) ochar(Ctrl('H')) ;
	    if( twin->curcol == 0 ) {
		return;
	    }
	    (twin->curcol)-- ;
	    move( twin->curln, twin->curcol );
	    if(!dumb_term) prints(" ") ;
	    move( twin->curln, twin->curcol );
	    return ;
	case Ctrl('M'):
	case Ctrl('J'):
	    if(dumb_term) prints("\n") ;
	    do_talk_nextline( twin );
	    return ;
	case Ctrl('G'):
	    bell() ;
	    return ;
	default:
	    break ;
    }
    return ;
}

void
do_talk_string( twin, str )
struct talk_win	*twin;
char		*str;
{
    while( *str ) {
	do_talk_char( twin, *str++ );
    }
}

void
dotalkuserlist( twin )
struct talk_win	*twin;
{
    char	bigbuf[ MAXACTIVE * 20 ];
    int		savecolumns;

    do_talk_string( twin, "\n*** �W�u���� ***\n" );
    savecolumns = (t_columns > STRLEN ? t_columns : 0);
    talk_uent_buf = bigbuf;
    if( apply_ulist( dotalkuent ) == -1 ) {
	strcpy( bigbuf, "�S������ϥΪ̤W�u\n" );
    }
    strcpy( talk_uent_buf, "\n" );
    do_talk_string( twin, bigbuf );
    if (savecolumns) t_columns = savecolumns;        
}

char talkobuf[80] ;
int talkobuflen ;
int talkflushfd ;

void
talkflush()
{
    if(talkobuflen) 
      write(talkflushfd,talkobuf,talkobuflen) ;
    talkobuflen = 0 ;
}

int
do_talk(fd)
int fd ;
{
    struct talk_win	mywin, itswin;
    char	mid_line[ 256 ];
    int		page_pending = NA;
    int		i;

    clear() ;
    modify_user_mode( TALK );
    sprintf( mid_line, " %s (%s) v.s. %s ", 
	currentuser.userid, currentuser.username, save_page_requestor );

    memset( &mywin,  0, sizeof( mywin ) );
    memset( &itswin, 0, sizeof( itswin ) );
    i = (t_lines-1) / 2;
    mywin.eline = i - 1;
    itswin.curln = itswin.sline = i + 1;
    itswin.eline = t_lines - 1;
    move( i, 0 );
    printdash( mid_line );
    move( 0, 0 );

    talkobuflen = 0 ;
    talkflushfd = fd ;
    add_io(fd,0) ;
    add_flush(talkflush) ;

    while(YEA) {
	int ch ;
	if (talkrequest) page_pending = YEA;
	if (page_pending)
	    page_pending = servicepage( (t_lines-1) / 2, mid_line );
	ch = igetch() ;
	if ( ch == '' ) 
	{
	   igetch();
	   igetch();	
  	   continue;
	}
	if(ch == I_OTHERDATA) {
            char data[80] ;
            int datac ;
            register int i ;

            datac = read(fd,data,80) ;
            if(datac<=0) 
		break ;
	    for(i=0;i<datac;i++)
		do_talk_char( &itswin, data[i] );
	} else {
            if(ch == Ctrl('D') || ch == Ctrl('C'))
		break ;
	    if(isprint2(ch) || ch == Ctrl('H') || ch == '\177'
		|| ch == Ctrl('G') || ch == Ctrl('M') ) {
		talkobuf[talkobuflen++] = ch ;
		if(talkobuflen == 80) talkflush() ;
		do_talk_char( &mywin, ch );
	    } else if (ch == '\n') {
                talkobuf[talkobuflen++] = '\r';
                talkflush();
		do_talk_char( &mywin, '\r' );
	    } else if (ch == Ctrl('U') || ch == Ctrl('W')) {
		dotalkuserlist( &mywin );
	    } else if (ch == Ctrl('P') && HAS_PERM(PERM_BASIC)) {
		if( uinfo.pager ) {
		    do_talk_string( &mywin, "** �����I�s��\n" );
		    uinfo.pager = NA;
		} else {
		    do_talk_string( &mywin, "** ���}�I�s��\n" );
		    uinfo.pager = YEA;
		}
		update_utmp();
	    }
	}
    }
    add_io(0,0) ;
    talkflush() ;
    add_flush(NULL) ;
    return 0;
}

int
shortulist(uentp)
struct user_info *uentp;
{
    static int lineno, fullactive, linecnt;
    static int moreactive, page, num;
    char uentry[30];

    if (!lineno) {
	lineno = 3;
	page = moreactive ? (page + (t_lines-4) * 3) : 0;
	linecnt = num = moreactive = 0;
	move( 1, 67 );
	prints( "Page: %-3d", page / (t_lines-4) / 3 + 1 );
	move(lineno, 0);
    }
    if( uentp == NULL ) {
	int	finaltally;

	clrtoeol();
	move(++lineno, 0);
	clrtobot();
	lineno = 0;
	finaltally = fullactive;
	fullactive = 0;
	return finaltally;
    }
    if( !uentp->active || !uentp->pid ||
	(!HAS_PERM(PERM_SEECLOAK) && uentp->invisible) ) {
	if( lineno >= t_lines-1 )  return 0;
	if( num++ < page )  return 0;
	memset( uentry, ' ', 24 );
	uentry[ 24 ] = '\0';
    } else {
	fullactive++;
	if( lineno >= t_lines-1 ) {
	    moreactive = 1;
	    return 0;
	}
	if( num++ < page )  return 0;
	sprintf(uentry,"%-12s %c%-10s", uentp->userid,
		uentp->invisible ? '#' : ' ',
		modestring(uentp->mode, uentp->destuid, 0, NULL));
    }
    if( ++linecnt < 3 ) {
	strcat(uentry, " | ");
	prints(uentry);
    } else {
	prints(uentry);
	linecnt = 0;
	clrtoeol();
	move(++lineno, 0);
    }
    return 0;
}

int
do_list( modestr )
char *modestr;
{       
    extern char BoardName[];
    char	buf[ STRLEN ];
    int		count;

    move(0,0);
    prints("%-30s%s", modestr, chkmail() ? "[�z���H��]" : BoardName );
    move(2,0);
    standout();
    sprintf( buf, "%-14s%-10s", "User ID", "Mode" );
    prints( "%s | %s | %s", buf, buf, buf );
    standend();

    if(apply_ulist( shortulist ) == -1) {
	prints("No Users Exist\n") ;
	return 0;
    }
    count = shortulist(NULL);
    if (uinfo.mode == MONITOR) {
	time_t thetime = time(0);		
	move(t_lines-1, 0);
	prints("�ثe�� %d �ӨϥΪ̤W�u, �{�b�ɨ�: %s",count, Ctime(&thetime));
    }
    refresh();
    return 0;
}

int
t_list()
{
    modify_user_mode( LUSERS );
    report("t_list");
    do_list("�ϥΪ̪��A");
    pressreturn();
    clear();
    return 0;
}

int idle_monitor_time;

void
sig_catcher()
{
    if (uinfo.mode != MONITOR) {
#ifdef DOTIMEOUT
	init_alarm();
#else
	signal(SIGALRM, SIG_IGN);
#endif
	return;
    }		
    if (signal(SIGALRM, sig_catcher)==SIG_ERR) {
	perror("signal");
	exit(1);
    }
#ifdef DOTIMEOUT
    idle_monitor_time += M_INT;
    if (idle_monitor_time > MONITOR_TIMEOUT) {
	clear();
	fprintf(stderr, "timeout ...\n");
	kill(getpid(), SIGHUP);
    }
#endif
    do_list("�ʬݨϥΪ�");
    alarm(M_INT);
}

int
t_monitor()
{
    char c;
    int i;

    alarm(0);
    signal(SIGALRM, sig_catcher);
    idle_monitor_time = 0;
    report("monitor");
    modify_user_mode( MONITOR );
    move(1,0);
    prints("�C�j %d ����s�@��, �Ы� Ctrl-C �� Ctrl-D ���}.",M_INT);
    do_list("�ʬݨϥΪ�");
    alarm(M_INT);
    while (YEA) {
	i = read(0,&c,1);
	if (!i || c == Ctrl('D') || c == Ctrl('C')) break;
	else if (i == -1) {
	    if (errno != EINTR) { perror("read"); exit(1); }
	} else idle_monitor_time = 0;
    }
    move(2,0);
    clrtoeol();
    return 0;
}

void
exec_cmd( umode, pager, cmdfile )
int	umode, pager;
char	*cmdfile;
{
    char buf[512] ;
    int save_pager;

    if( ! dashf( cmdfile ) ) {
        move(2,0);
	prints( "no %s\n", cmdfile );
	pressreturn();
	return;
    }
    save_pager = uinfo.pager;
    if( pager == NA ) {
	uinfo.pager = pager;
    }
    modify_user_mode( umode );
    sprintf( buf, "/bin/sh %s", cmdfile );
    reset_tty() ;
    do_exec(buf,NULL) ;
    restore_tty() ;
    uinfo.pager = save_pager;
    clear();
}

#ifdef IRC
void
t_irc() {
    exec_cmd( IRCCHAT, NA, "bin/irc.sh" );
}
#endif /* IRC */

void
t_announce() {
    exec_cmd( CSIE_ANNOUNCE, YEA, "bin/faq.sh" );
}

void
t_tin() {
    exec_cmd( CSIE_TIN, YEA, "bin/tin.sh" );
}

void
t_gopher() {
    exec_cmd( CSIE_GOPHER, YEA, "bin/gopher.sh" );
}

/* rrr -- stuff for providing pager override lists follows */

int
can_override( userid, whoasks )
char *userid;
char *whoasks;
{
    FILE *fp;
    char buf[STRLEN];
    char *namep;

    sethomefile( buf, userid, "overrides" );
    if ((fp = fopen(buf, "r")) == NULL)
	return 0;
    while (fgets(buf, STRLEN, fp) != NULL) {
	namep = (char *)strtok( buf, " \n\r\t" );
        if (namep != NULL && ci_strcmp(namep, whoasks) == 0 ) {
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}

int
listfriends()
{
    FILE *fp;
    int x = 0, y = 3, cnt = 0, max = 0, len;
    char u_buf[20], line[STRLEN], *nick;

    move(y,x);
    CreateNameList();
    setuserfile( genbuf, "overrides" );
    if ((fp = fopen(genbuf, "r")) == NULL) {
	prints("(none)\n");
	return 0;
    }
    while(fgets(genbuf, STRLEN, fp) != NULL) {
	strtok( genbuf, " \n\r\t" );
	strcpy( u_buf, genbuf );
	AddNameList( u_buf );
	nick = (char *) strtok( NULL, "\n\r\t" );
	if( nick != NULL ) {
	    while( *nick == ' ' )  nick++;
	    if( *nick == '\0' )  nick = NULL;
	}
	if( nick == NULL ) {
	    strcpy( line, u_buf );
	} else {
	    sprintf( line, "%-12s%s", u_buf, nick );
	}
	if( (len = strlen( line )) > max )  max = len;
	if( x + len > 78 )  line[ 78 - x ] = '\0';
	prints( "%s", line );
	cnt++;
        if ((++y) >= t_lines-1) {
	    y = 3;
	    x += max + 2;
	    max = 0;
	    if( x > 70 )  break;
	}
	move(y,x);
    }
    fclose(fp);
    if (cnt == 0) prints("(none)\n");
    return cnt;
}

int
addtooverride(uident)
char *uident;
{
    FILE *fp;
    int rc;
    char buf[50];

    if( can_override( currentuser.userid, uident ) )
	return -1;
    getdata(2,0,"��J����: ", buf,40,DOECHO,NULL);
    setuserfile( genbuf, "overrides" );
    if ((fp = fopen(genbuf, "a")) == NULL)
	return -1;
    flock(fileno(fp), LOCK_EX);
    rc = fprintf( fp, "%-12s %s\n", uident, buf );
    flock(fileno(fp), LOCK_UN);
    fclose(fp);
    return(rc == EOF ? -1 : 0);
}		

int
deleteoverride(uident)
char *uident;
{
    FILE *fp, *nfp;
    int deleted = NA;
    char fn[STRLEN], fnnew[STRLEN];

    setuserfile( fn, "overrides" );
    if ((fp = fopen(fn, "r")) == NULL) return -1;
    sprintf( fnnew, "%s.%d", fn, getuid());
    if ((nfp = fopen(fnnew, "w")) == NULL) return -1;
    while(fgets(genbuf, STRLEN, fp) != NULL) {
	if( strncmp(genbuf, uident, strlen(uident)) == 0 )
	    deleted = YEA;
	else if( *genbuf > ' ' )
	    fputs(genbuf, nfp);
    }
    fclose(fp);
    fclose(nfp);
    if (!deleted) return -1;
    return(rename(fnnew, fn));
}

void
t_override()
{
    char uident[STRLEN];
    char ans[8];
    int count;

/*
    uinfo.mode = 
    update_utmp();
*/
    while (1) {
	clear();
	prints("�]�w�n�ͦW��\n");
	count = listfriends();
	if (count)
	    getdata(1,0,"(A)�W�[ (D)�R�� or (E)���} [E]: ",ans,7,DOECHO,NULL);
	else 
	    getdata(1,0,"(A)�W�[ or (E)���} [E]: ", ans, 7, DOECHO, NULL);
	if (*ans == 'A' || *ans == 'a') {
	    move(1,0);
	    usercomplete("Add userid: ", uident);
	    if( *uident != '\0' )
		addtooverride(uident);
	} else if ((*ans == 'D' || *ans == 'd') && count) {
	    move(1,0);
	    namecomplete("Delete userid: ", uident);
	    move(1,0);
	    clrtoeol();
	    if (uident[0] != '\0')
		deleteoverride(uident);
	} else break;
    }
    clear();
    return;
}		

int
t_friends()
{
    FILE	*fp;
    char	friends_buffer[ 0x1000 ];

    modify_user_mode( FRIEND );
    setuserfile( genbuf, "overrides" );
    if ((fp = fopen(genbuf, "r")) == NULL) {
	move( 3, 0 );
	clrtobot();
	prints("�ЧQ�� Talk->Override �]�w�n�ͦW��\n");
	pressreturn();
	clear();
	return 0;
    }
    friends_list = friends_buffer;
    friends_number = 0;

    strcpy( friends_list, " " );
    while (fgets(genbuf, STRLEN, fp) != NULL) {
	if ( strtok( genbuf, " \n\r\t") != NULL) {
	    strcat( friends_list, genbuf );
	    strcat( friends_list, " " );
	}
    }
    fclose( fp );

    printcuent( NULL ) ;
    if ( apply_ulist( printcuent ) == -1 ) 
	prints("�S������ϥΪ̤W�u\n") ;

    if( friends_number == 0 ) {
	move( 3, 0 );
	clrtobot();
	prints( "�ثe�L�n�ͤW�u\n");
    }
    clrtobot() ;
    pressreturn();
    friends_list = NULL;
    return 0;
}

