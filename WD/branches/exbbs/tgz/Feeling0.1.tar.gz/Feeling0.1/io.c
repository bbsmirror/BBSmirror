/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char	SccsId[] = "@(#)io.c	2.1	12/24/95";
#endif

#include "bbs.h"
#include <sys/types.h>
#include <sys/time.h>
#include <errno.h>

extern	userec	cuser;
extern	int	dumb_term;
extern	uschar	dsk_cols;
extern	jmp_buf	byebye;

char	outbuf[OBUFSIZE], 
	inbuf[IBUFSIZE];
int	obufsize = 0, 
	ibufsize = 0, 
	icurrchar = 0, 
	i_newfd  = 0;
struct	timeval	i_to, 
		*i_top = NULL;
int	(*flushf)() = NULL;

static	int	i_mode = INPUT_ACTIVE;

void	init_alarm();

void	hit_alarm_clock()
{
	if (HAS_PERM(PERM_NOTIMEOUT))
		return;
	if (i_mode == INPUT_IDLE)
		goodbye();
	i_mode = INPUT_IDLE;
	init_alarm(NA);
}

void	warnning_alarm()
{
	if (HAS_PERM(PERM_NOTIMEOUT))
		return;
	if (i_mode == INPUT_IDLE)
	{
		bell(10);
		init_alarm(YEA);
	}
	i_mode = INPUT_IDLE;
	init_alarm(NA);
}

void	init_alarm(lazy_bbser)
int	lazy_bbser;
{
	if (HAS_PERM(PERM_NOTIMEOUT))
		return;
	if (lazy_bbser)
	{
		(void)signal(SIGALRM, hit_alarm_clock);
		(void)alarm(WARN_TIMEOUT);
	}
	else
	{
		(void)signal(SIGALRM, warnning_alarm);
		(void)alarm(IDLE_TIMEOUT-WARN_TIMEOUT);
	}
}

void	oflush()
{
	if (obufsize)
	(void)write(1, outbuf, obufsize);
		obufsize = 0;
}

void	output(s, len)
char	*s;
{
	if (obufsize+len > OBUFSIZE)
	{
		(void)write(1, outbuf, obufsize);
		obufsize = 0;
	}
	(void)memcpy(outbuf+obufsize, s, len);
	obufsize+=len;
}

int	ochar(c)
{
	if (obufsize > OBUFSIZE-1)
	{
		(void)write(1, outbuf, obufsize);
		obufsize = 0;
	}
	outbuf[obufsize++] = c;
}

void	add_io(fd, timeout)
int	fd, 
	timeout;
{
	i_newfd = fd;
	if (timeout)
	{
		i_to.tv_sec = timeout;
		i_to.tv_usec = 0;
		i_top = &i_to;
	}
	else
		i_top = NULL;
}

void	add_flush(flushfunc)
int	(*flushfunc)();
{
	flushf = flushfunc;
}

int	num_in_buf()
{
	return icurrchar - ibufsize;
}

int	kbhit()
{
	fd_set	readfds;
	struct	timeval	to;
	char	buf;

	to.tv_sec = 0;
	to.tv_usec = 1;

	FD_ZERO(&readfds);
	FD_SET(0, &readfds);

	if (select(2, &readfds, NULL, NULL, &to) < 0)
		return -1;

	if (FD_ISSET(0, &readfds))
	{
		(void)read(0, &buf, 1);
		return buf;
	}
	else
		return -1;
}

int	igetch()
{
    while (1)
    {
	if (ibufsize == icurrchar)
	{
		fd_set	readfds;
		struct	timeval	to;
		int	sr;

		to.tv_sec = 0;
		to.tv_usec = 0;
		FD_ZERO(&readfds);
		FD_SET(0, &readfds);
		if (i_newfd)
			FD_SET(i_newfd, &readfds);
		if ((sr = select(getdtablesize(), &readfds, NULL, NULL, 
			&to)) <= 0)
		{
			if (flushf)
				(*flushf)();
			if (dumb_term)
				oflush();
			else
				refresh();
			FD_ZERO(&readfds);
			FD_SET(0, &readfds);
			if (i_newfd)
				FD_SET(i_newfd, &readfds);
			while ((sr = select(getdtablesize(), &readfds, 
				NULL, NULL, i_top)) <0)
			{
				if (errno == EINTR)
					continue;
				else
				{
					perror("select");
					(void)fprintf(stderr, 
						"abnormal select conditions\n");
					return -1;
				}
			}
			if (sr == 0)
				return I_TIMEOUT;
		}
		if (i_newfd && FD_ISSET(i_newfd, &readfds))
			return I_OTHERDATA;
		while ((ibufsize = read(0, inbuf, IBUFSIZE)) <= 0)
		{
			if (ibufsize == 0)
				longjmp(byebye, -1);
			if (ibufsize < 0 && errno != EINTR)
				longjmp(byebye, -1);
		}
		icurrchar = 0;
	}
	i_mode = INPUT_ACTIVE;
	switch(inbuf[icurrchar])
	{
		case CTRL('Q'):
			SWITCH_SET(SET_ANSIMODE);
		case CTRL('L'):
			redodsk();
			icurrchar++;
			continue;
		default:
			break;
	}
	return inbuf[icurrchar++];
    }
}

int	getdata(line, col, prompt, buf, len, echo, cflag)
int	line, 	col, 	len, 	echo,	cflag;
char	*prompt, 	*buf;
{
	int	ch,	clen = 0,	curr = 0,
		x,	y,	i;
	char	tmp[STRLEN];

	if (cflag)
		(void)memset(buf, 0, sizeof(buf));
	y = line;
	if (prompt == NULL || *prompt == '\0')
		x = col;
	else
		x = col + strlen(prompt) - o_shift(prompt, strlen(prompt));
	clen = strlen(buf);
	curr = clen = (clen > len) ? len : clen;
	buf[curr] = '\0';
	move(line, col);
	if (prompt)
		prints(NA, "%s", prompt);
	if (!cflag)
		prints(NA, "%s", buf);
	refresh();

	if (dumb_term)
	{
		while ((ch = igetch()) != '\r')
		{
			if (ch == '\n')
				break;
			if (ch == '\177' || ch == CTRL('H'))
			{
				if (clen == 0)
				{
					bell(1);
					continue;
				}
				clen--;
				ochar(CTRL('H'));
				ochar(' ');
				ochar(CTRL('H'));
				continue;
			}
			if (!ISPRINT(ch))
			{
				bell(1);
				continue;
			}
			if (clen >= len-1)
			{
				bell(1);
				continue;
			}
			buf[clen++] = ch;
			if (echo)
				ochar(ch);
			else
/* �o�ӬO���passwd echo������ */
				ochar(' '); 
		}
		buf[clen] = '\0';
		prints(NA, "\n");
		oflush();
		return clen;
	}

	clrtoeol();

	while ((ch = igetkey()) != '\r')
	{
		if (ch == '\n')
			break;
		if (ch == '\177' || ch == CTRL('H'))
		{
			if (curr == 0)
			{
				bell(1);
				continue;
			}
			(void)strcpy(tmp, &buf[curr]);
			buf[--curr] = '\0';
			(void)strcat(buf, tmp);
			clen--;
			move(y, x);
			if (echo)
				prints(NA, "%s", buf);
			else
			{
				for (i = 0; i < strlen(buf); i++)
					prints(NA, "*");
			}
			clrtoeol();
			move(y, x + curr);
			continue;
		}
		if (ch == KEY_LEFT)
		{
			if (curr == 0)
			{
				bell(1);
				continue;
			}
			curr--;
			move(y, x + curr);
			continue;
		}
		if (ch == KEY_RIGHT)
		{
			if (curr >= clen)
			{
				curr = clen;
				bell(1);
				continue;
			}
			curr++;
			move(y, x + curr);
			continue;
		}
		if (!ISPRINT(ch))
		{
			bell(1);
			continue;
		}

		if (clen >= len -1 || clen + x > dsk_cols)
		{
			bell(1);
			continue;
		}

		if (!buf[curr])
		{
			buf[curr + 1] = '\0';
			buf[curr] = ch;
		}
		else
		{
			(void)strncpy(tmp, &buf[curr], len);
			buf[curr] = ch;
			buf[curr + 1] = '\0';
			(void)strncat(buf, tmp, len - curr);
		}
		curr++;
		clen++;
		if (echo)
		{
			move(y, x);
			prints(NA, "%s", buf);
			move(y, x + curr);
		}
		else
			prints(NA, "*");
	}
	buf[clen] = '\0';
	prints(NA, "\n");
	refresh();
	return clen;
}

int	igetkey()
{
	int	mode, 
		ch, 
		last;

	mode = last = 0;

	for (;;)
	{
		ch = igetch();
		if (ch == KEY_ESC)
			mode = 1;
		else if (mode == 0)
			return ch;
		else if (mode == 1)
		{
			if (ch == '[' || ch == 'O')
				mode = 2;
			else if (ch == '1' || ch == '4')
				mode = 3;
			else 
				return ch;
		}
		else if (mode == 2)
		{
			if (ch >= 'A' && ch <= 'D')   
				return KEY_UP + (ch - 'A');
			else if (ch >= '1' && ch <= '6')
				mode = 3;
			else
				return ch;
		}
		else if (mode == 3)
		{
			if (ch == '~')
				return KEY_HOME + (last - '1');
			else
				return ch;
		}
		last = ch;
	}
}

int	reply(x, y, prompt, flag)
int	x, 
	y, 
	flag;
char	*prompt;
{
	int	ch;

	move(x, y);
	prints((flag) ? YEA : NA, "%s", prompt);
	clrtoeol();
	ch = igetkey();

	return(ch);
}
