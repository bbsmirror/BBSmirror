/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static	char	SccsId[] = "@(#)read.c	2.1	12/24/95";
#endif

#include "bbs.h"

#define	FIXTOP(x)	(((x-1)/SCRLN)*SCRLN+1)

extern	usinfo  uinfo;

extern	char	match[],
		currtitle[];

extern	int	t_lines,
		talkrequest;

static	keeploc	*keeplist = NULL;

int	delkeep(s)
char	*s;
{
	keeploc	*p;

	for (p = keeplist; p != NULL; p = p->next)
	{
		if (!strcpy(s, p->key))
		{
			free(p->key);
			free(p);
			return YEA;
		}
	}
	return NA;
}

keeploc *getkeep(s, def_cursline, newflag)
char	*s;
int	def_cursline,
	newflag;
{
	keeploc	*p;
	for(p = keeplist; p!= NULL; p = p->next)
	{
		if (!strcmp(s,p->key))
		{
			if (newflag)
				p->crs_line = def_cursline;

			if (p->crs_line < 1)
				p->crs_line = 1;
			p->top_line = FIXTOP(p->crs_line);
			(void)strcpy(match, p->match);
			(void)strcpy(currtitle, p->ctitle);
			return p;
		}
	}
	p = (keeploc *)malloc(sizeof(keeploc));
	p->key = (char *)malloc(strlen(s) + 1);
	(void)strcpy(p->key, s);
	p->crs_line = def_cursline;
	p->top_line = FIXTOP(p->crs_line);
	(void)memset(p->match, 0, sizeof(p->match));
	(void)memset(p->ctitle, 0, sizeof(p->ctitle));
	p->next = keeplist;
	keeplist = p;
	return p;
}

void	fixkeep(s, first)
char	*s;
int	first;
{
	keeploc	*k;

	k = getkeep(s, 1, 0);
	if (k->crs_line >= first)
	{
		k->crs_line = (first <= 1 ? 1 : first-1);
		k->top_line = FIXTOP(k->crs_line);
	}
}

/* ARGSUSED */
int	r_upper(last, loc)
int	last;
keeploc	*loc;
{
	if (loc->crs_line <= loc->top_line)
	{
		if (loc->crs_line <= 1)
		{
			loc->crs_line = last;
			loc->top_line = FIXTOP(last);

			return PARTUPDATE;
		}
		loc->crs_line--;
		loc->top_line = FIXTOP(loc->crs_line);
		if (loc->top_line <= 0)
			loc->top_line = 1;
		return PARTUPDATE;
	}
	RMVCURS;
	loc->crs_line--;
	PUTCURS;

	return DONOTHING;
}

/* ARGSUSED */
int	r_down(last, loc)
int	last;
keeploc	*loc;
{
	if (loc->crs_line >= last)
	{
		loc->crs_line = 1;
		loc->top_line = 1;

		return PARTUPDATE;
	}
	if (loc->crs_line + 1 >= loc->top_line + SCRLN)
	{
		loc->crs_line++;
		loc->top_line = FIXTOP(loc->crs_line);
		return PARTUPDATE;
	}
	RMVCURS;
	loc->crs_line++;
	PUTCURS;

	return DONOTHING;
}

/* ARGSUSED */
int	r_pgup(last, loc)
int	last;
keeploc	*loc;
{
	if ( loc->top_line - SCRLN < 1)
	{
		RMVCURS;
		loc->crs_line = 1;
		PUTCURS;

	return DONOTHING;
	}
	loc->crs_line -= SCRLN;
	loc->top_line = FIXTOP(loc->crs_line);

	return PARTUPDATE;
}

/* ARGSUSED */
int	r_end(last, loc)
int	last;
keeploc	*loc;
{
	if (last < loc->top_line + SCRLN)
	{
		RMVCURS;
		loc->crs_line = last;
		PUTCURS;

		return DONOTHING;
	}
	loc->crs_line = last;
	loc->top_line = FIXTOP(loc->crs_line);

	return PARTUPDATE;
}

/* ARGSUSED */
int	r_quit(last, loc)
int	last;
keeploc	*loc;
{
	return	DOQUIT;
}

/* ARGSUSED */
int	r_pgdn(last, loc)
int	last;
keeploc	*loc;
{
	if (last < loc->top_line + SCRLN)
	{
		RMVCURS;
		loc->crs_line = last;
		PUTCURS;

		return DONOTHING;
	}
	loc->crs_line+=SCRLN;
	loc->top_line = FIXTOP(loc->crs_line);

	return PARTUPDATE;
}

/* ARGSUSED */
int	r_redraw(last, loc)
int	last;
keeploc	*loc;
{
	redodsk();
	return DONOTHING;
}

/* ARGSUSED */
int	r_home(last, loc)
int	last;
keeploc	*loc;
{
	int	redraw = YEA;

	if(loc->top_line < SCRLN)
	{
		redraw = NA;
		RMVCURS;
	}
	loc->top_line = 1;
	loc->crs_line = 1;
	if(!redraw)
	{
		PUTCURS;
		return DONOTHING;
	}
	else
		return PARTUPDATE;
}

one_key	readcmd[] =
{
	'q',		r_quit,
	'e',		r_quit,
	KEY_LEFT,	r_quit,
	'p',		r_upper,
	'k',		r_upper,
	KEY_UP,		r_upper,
	CTRL('L'),	r_redraw,
	'n',		r_down,
	'j',		r_down,
	KEY_DOWN,	r_down,
	' ',		r_pgdn,
	'N',		r_pgdn,
	CTRL('F'),	r_pgdn,
	KEY_PGDN,	r_pgdn,
	'P',		r_pgup,
	CTRL('B'),	r_pgup,
	KEY_PGUP,	r_pgup,
	'$',		r_end,
	KEY_END,	r_end,
	'!',		r_home,
	KEY_HOME,	r_home,
	'\0',		NULL,
};

/* ARGSUSED */
int	rs_part(entn, last, size, dbuf, loc, point, doent, dottl, gnum, grec)
int	*entn,	size,	*last,	(*grec)();
long	(*gnum)();
keeploc	*loc;
char	*dbuf,	*point,	*(*doent)(),	(*dottl)();
{
	int i;

	*last = (*gnum)(dbuf, size);

	if (loc->crs_line > (*last))
		loc->crs_line = (*last);
	loc->top_line = FIXTOP(loc->crs_line);
	if (*last == 0)
	{
		prints(NA, "No Messages\n");
		*entn = 0;

		return READ_SLEEP;
	}
	*entn = (*grec)(dbuf, point, size, loc->top_line, SCRLN);

	move(3, 0);
	for(i=0; i < *entn; i++)
	{
		(*doent)(loc->top_line + i, &point[i*size]);
	}

	(void)strcpy(loc->match, match);
	(void)strcpy(loc->ctitle, currtitle);
	clrtobot();
	PUTCURS;
	refresh();
	return DONOTHING;
}

/* ARGSUSED */
int	rs_full(entn, last, size, dbuf, loc, point, doent, dottl, gnum, grec)
int	*entn,	size,	*last,	(*gnum)(),	(*grec)();
keeploc	*loc;
char	*dbuf,	*point,	*(*doent)(),	(*dottl)();
{
	move(0,0);
	clrtobot();
	(*dottl)();

	return rs_part(entn, last, size, dbuf, loc, point, doent, dottl, gnum,
		grec);
}

/* ARGSUSED */
int	rs_prev(entn, last, size, dbuf, loc, point, doent, dottl, gnum, grec)
int	*entn,	size,	*last,	(*gnum)(),	(*grec)();
keeploc	*loc;
char	*dbuf,	*point,	*(*doent)(),	(*dottl)();
{
	if (loc->crs_line <= loc->top_line)
	{
		loc->top_line -= SCRLN - 2;
		*entn = (*grec)(dbuf, point, size, loc->top_line, SCRLN);
	}

	if (loc->top_line < 1)
		loc->top_line = 1;

	loc->crs_line--;
	if (loc->crs_line < 1)
	{
		loc->crs_line = 1; 
		return rs_full(entn, last, size, dbuf, loc, point, doent,
			dottl, gnum, grec);
	}

	return READ_LOOP;
}

/* ARGSUSED */
int	rs_next(entn, last, size, dbuf, loc, point, doent, dottl, gnum, grec)
int	*entn,	size,	*last,	(*gnum)(),	(*grec)();
keeploc	*loc;
char	*dbuf,	*point,	*(*doent)(),	(*dottl)();
{
	if (loc->crs_line >= *last)
	{
		return rs_full(entn, last, size, dbuf, loc, point, doent,
			dottl, gnum, grec);
	}
	else if (++loc->crs_line == loc->top_line + SCRLN)
	{
		loc->top_line = FIXTOP(loc->crs_line);
		*entn = (*grec)(dbuf, point, size, loc->top_line, SCRLN);
	}

	return READ_LOOP;
}

/* ARGSUSED */
int	rs_loop(entn, last, size, dbuf, loc, point, doent, dottl, gnum, grec)
int	*entn,	size,	*last,	(*gnum)(),	(*grec)();
keeploc	*loc;
char	*dbuf,	*point,	*(*doent)(),	(*dottl)();
{
	loc->top_line = FIXTOP(loc->crs_line);
	(void)rs_part(entn, last, size, dbuf, loc, point, doent, dottl,
		gnum, grec);
	return READ_LOOP;
}

/* ARGSUSED */
int	rs_match(entn, last, size, dbuf, loc, point, doent, dottl, gnum, grec)
int	*entn,	size,	*last,	(*gnum)(),	(*grec)();
keeploc	*loc;
char	*dbuf,	*point,	*(*doent)(),	(*dottl)();
{
	(void)strcpy(loc->match, match);
	return DONOTHING;
}

/* ARGSUSED */
int	rs_reld(entn, last, size, dbuf, loc, point, doent, dottl, gnum, grec)
int	*entn,	size,	*last,	(*gnum)(),	(*grec)();
keeploc	*loc;
char	*dbuf,	*point,	*(*doent)(),	(*dottl)();
{
	loc->top_line = FIXTOP(loc->crs_line);
	(void)rs_part(entn, last, size, dbuf, loc, point, doent, dottl,
		gnum, grec);
	return DONOTHING;	
}

one_key	modecmd[] =
{
	FULLUPDATE,	rs_full,
	READ_NEXT,	rs_next,
	READ_PREV,	rs_prev,
	PARTUPDATE,	rs_part,
	LOOPUPDATE,	rs_loop,
	RESET_MATCH,	rs_match,
	READ_RELOAD,	rs_reld,
	0,		NULL,
};

int	i_read(direct, dottl, doent, rcmd, fcmd, size, gnum, grec)
char	*direct;	/*  ��ƨӷ��ؿ�	*/
void	(*dottl)(),	/*  �W���T��		*/
	(*doent)();     /*  ��ܸ�Ƥ��e        */
one_key *rcmd;		/*  command table	*/
int	fcmd,		/*  first command	*/
	size,		/*  ��ƪ� size		*/
	(*gnum)(),	/*  �p��i�θ�Ƶ���	*/
	(*grec)();	/*  ���o���		*/
{
	int	num_entries,
		i,
		ch = 0,
		mode = DONOTHING,
		lbc = 0,
		val,
		last;
	char	*point,
		lbuf[10],
		dbuf[STRLEN];
	keeploc	*loc;

	point = (char *)calloc(SCRLN, size);
	(void)strcpy(dbuf, direct);
        move(0, 0);
        (*dottl)();
        clrtobot();

        last = (*gnum)(dbuf, size);

	if (last == 0)
	{
		if (fcmd)
		{
			ch = fcmd;
		}
		else
		{
			move(4, 0);
			prints(NA, "�ثe�L����i�HŪ�������");
			pressreturn();
			cfree(point);
			return -1;
		}
	}

        loc = getkeep(dbuf, last, 0);

        if (loc->crs_line > last)
                loc->crs_line = last;
	if (last == 0)
		loc->crs_line = 1;
	loc->top_line = FIXTOP(loc->crs_line);
        num_entries = (*grec)(dbuf, point, size, loc->top_line, SCRLN);
        move(3, 0);
	for (i = 0; i < num_entries; i++)
		(*doent)(loc->top_line+i, &point[i*size]);
        PUTCURS;
        lbc = 0;
	if(mode != DONOTHING)
	{
		ch = igetkey();
		mode = DONOTHING;
	}

	do
	{
		move(t_lines-1, 0);
		clrtoeol();
		PUTCURS;

		if (talkrequest)
		{
			talkreply();
			mode = FULLUPDATE;
			ch = '\0';
		}

		if (ch < 0x100 && isdigit(ch))
		{
			if (lbc < 9)
				lbuf[lbc++] = ch;
			continue;
		}

		if (ch != '\n' && ch != '\r')
			lbc = 0;
		else if(lbc != 0)
		{
			lbuf[lbc] = '\0';
			val = atoi(lbuf);
			lbc = 0;
			if (val > last)
			val = last;
			if (val <= 0)
				val = 1;
			if (val >= loc->top_line && val < loc->top_line+SCRLN)
			{
				RMVCURS;
				loc->crs_line = val;
				PUTCURS;
				continue;
			}
			loc->crs_line = val;
			loc->top_line = FIXTOP(loc->crs_line);
			mode = PARTUPDATE;
			ch = 0;
		}

		for(i = 0; ch != '\0' && rcmd[i].fptr != NULL; i++)
		{
			if (rcmd[i].key == ch)
			{
				mode = (*(rcmd[i].fptr))(&loc->crs_line,
					&point[(loc->crs_line -
					loc->top_line)*size], dbuf);
				break;
			}
		}

		for(i = 0; ch != '\0' && readcmd[i].fptr != NULL; i++)
		{
			if(readcmd[i].key == ch)
			{
				mode = (*readcmd[i].fptr)(last, loc);
				PUTCURS;
				break;
			}
		}

		for(i = 0; (*modecmd[i].fptr) != NULL; i++)
		{
			if(modecmd[i].key == mode)
			{
				mode = (*modecmd[i].fptr)(&num_entries, &last,
					size, dbuf, loc, point, doent, dottl,
					gnum, grec);
				break;
			}
		}

		switch (mode)
		{
			case	NEWDIRECT:
			case	REDOIREAD:
				cfree(point);
				return REDOIREAD;
			case	DOQUIT:
				cfree(point);
				clear();
				return DOQUIT;
		}

		if (num_entries == 0)
			break;
	}
	while ((mode == READ_LOOP) || (ch = igetkey()) != EOF);
	clear();
	cfree(point);
	return 0;
}
