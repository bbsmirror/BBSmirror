#define BBSGID          99
#define BBSUID          9999
#define MYNAME          "�ԯq�u�ӱM�� BBS"
#define MYENAME         "ncit BBS"
#define MYNICKNAME      "ncitbbs"
#define MAILSERVER      "eesp.ncit.edu.tw"
#define MYHOSTNAME      "eesp.ncit.edu.tw"
#define ADMIN           "SYSOP"
#define JUNK            "junk"
#define BBSHOME		"/home/bbs"
#define DAEMON          "�t�Ψ����T�{�۰��ˬd"
#define MYPASSFILE      "/.PASSWDS"
#define MYCRCIDX        "/.CRCIDX"
#define BUFLEN          256
#define BRDPATH         "boards/%s"
#define BRDDIR          "boards/%s/%s"

