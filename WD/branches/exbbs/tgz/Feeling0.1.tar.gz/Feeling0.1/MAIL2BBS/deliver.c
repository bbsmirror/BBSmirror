/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw
 
    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/
 
#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/types.h>
/* #include <sys/uio.h> */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
 
#include "define.h"
#include "struct.h"
 
#include "mail2bbs.h"
 
char    work[STRLEN];
 
int     strncmpi(s1,s2,n)
char    *s1,
        *s2;
int     n;
{
        for (; n; s1++, s2++, n--)
        {
                int     ret;
 
                if (*s1=='\0' && *s2 == '\0')
                        break;
 
                if ((ret = (isalpha(*s1)?*s1|0x20:*s1) -
                        (isalpha(*s2)?*s2|0x20:*s2)) != 0)
                {
                        return ret;
                }
        }
        return 0;
}
 
int     uidcmp(uid,up)
char    *uid;
userec  *up;
{
        if (!strncmpi(uid, up->userid, sizeof(up->userid)))
        {
                strncpy( uid, up->userid, sizeof( up->userid ));
                return -1;
        }
        else
        {
                return 0;
        }
}
 
int     exist(passfl, userid)
char    *passfl,
        *userid;
{
        userec  auser;
 
        if (access(passfl, R_OK) != 0)
        {
                printf("cannot find file: %s\n", MYPASSFILE);
                system("pwd");
                exit(-1);
        }
        return search_record(passfl, &auser, sizeof(userec),
                uidcmp, userid);
}
 
char    *buildfile(fname)
char    *fname;
{
        char    path[STRLEN],
                idxpoint[STRLEN],
                genbuf[STRLEN];
        int     fp,
                curr;
        struct  stat    st;
 
        if (access(fname, X_OK|R_OK|W_OK))
                mkdir(fname, 0755);
        strcpy(path, fname);
        sprintf(idxpoint, "%s/%s", path, FHDIR);
        if (stat(idxpoint, &st) == -1 || st.st_size == 0)
                curr = 1;
        else
        {
                fhd     last;
                int     size = sizeof(fhd);
 
                get_record(idxpoint, &last, size, st.st_size/size);
                curr = atoi(last.filename + 2) + 1;
        }
 
        while (1)
        {
                sprintf(fname, "S.%010d.A", curr);
                sprintf(genbuf, "%s/%s", path, fname);
                if ((fp = open(genbuf, O_CREAT|O_EXCL|O_WRONLY, 0644)) != -1)
                        break;
                if (errno != EEXIST)
                {
                        close(fp);
                        return NULL;
                }
                curr++;
        }
        close(fp);
        return fname;
}
 
 
int     readport(fd, buf)
int     fd;
char    *buf;
{
        int     i,
                l = 0;
        char    *s = buf;
 
        while ((i = read(fd, s, 1)) > 0)
        {
                l += i;
                if (*s == '\n')
                        break;
                if (*s != '\r')
                        s++;
        }
        *s = 0;
        return l;
}
/*
 * �e�X�ӥ��T�{�H
 */
int     deliver(userid, email, date, checksum, modify)
char    *userid,
        *email,
        *date;
int     checksum,
        modify;
{
        struct  sockaddr_in     sin;
        struct  hostent *host;
        int     mfd;
        char    buf[256],
                tmpbuf[256];
 
        printf("send out identify mail to: %s in %s as %d\n", userid, email,
                checksum);
        sin.sin_family = AF_INET;
        sin.sin_port = htons(25);
        host = gethostbyname(MAILSERVER);
        memcpy(&sin.sin_addr.s_addr, host->h_addr_list[0],
                host->h_length);
        mfd = socket(AF_INET, SOCK_STREAM, 0);
        if (mfd < 0)
                return -2;
        if (connect(mfd, (struct sockaddr *)&sin, sizeof(sin)) < 0)
                return -2;
        sprintf(buf, "HELO %s\n", MYHOSTNAME);
        write(mfd, buf, strlen(buf));
        while (1)
        {
                readport(mfd, tmpbuf);
                if (atoi(tmpbuf) ==  250)
                        break;
                if (atoi(tmpbuf) > 400)
                {
                        close(mfd);
                        return -1;
                }
        }
        sprintf(buf, "MAIL From:<%s.reg@%s>\n", userid, MYHOSTNAME);
        write(mfd, buf, strlen(buf));
        readport(mfd, tmpbuf);
        if (strstr(tmpbuf, "250") != tmpbuf)
        {
                close(mfd);
                return -1;
        }
        sprintf(buf, "RCPT To:<%s>\n", email);
        write(mfd, buf, strlen(buf));
        readport(mfd, tmpbuf);
        if (strstr(tmpbuf, "250") != tmpbuf)
        {
                close(mfd);
                return -1;
        }
        sprintf(buf, "DATA\n");
        write(mfd, buf, strlen(buf));
        readport(mfd, tmpbuf);
        if (strstr(tmpbuf, "354") != tmpbuf)
        {
                close(mfd);
                return -1;
        }
        sprintf(buf, "To: %s\n", email);
        write(mfd, buf, strlen(buf));
        sprintf(buf, "Subject: [%d] BBS account E-mail Identify\n\n", checksum);
        write(mfd, buf, strlen(buf));
        sprintf(buf, "%s(%s), �z�n:\n\n", email, userid);
        write(mfd, buf, strlen(buf));
        if (modify)
        {
        sprintf(buf, "    You modified your e-mail at %s in %s.\n",date, MYENAME);
        write(mfd, buf, strlen(buf));
        sprintf(buf, "    �z�b %s ��� E-mail Address �]�w\n\n", date);
        write(mfd, buf, strlen(buf));
        }
        else
        {
        sprintf(buf, "    You registered an account at %s in %s.\n",date, MYENAME);
        write(mfd, buf, strlen(buf));
        sprintf(buf, "    �z�b %s �ӽ� %s �b��\n\n", date, MYNAME);
        write(mfd, buf, strlen(buf));
        }
        sprintf(buf, "    Please Reply this E-mail to identify\n");
        write(mfd, buf, strlen(buf));
        sprintf(buf, "    �Ы� r ��^�H,�b�� ctrl + d �s�� �H�i��T�{�z������\n\n");
        write(mfd, buf, strlen(buf));
        sprintf(buf, "    PLEASE KEEP THE SUBJECT OF THIS MAIL\n");
        write(mfd, buf, strlen(buf));
        sprintf(buf, "    �аȥ��O�d���H�� \"Subject:\" ����\n\n");
        write(mfd, buf, strlen(buf));
        sprintf(buf, "    PS: please read �ԯqBBS SYSOP BOARD for more\n");
        write(mfd, buf, strlen(buf));
        sprintf(buf, "    PS: �i�@�B�����T��, �Ц� %s SYSOP �O�d��\n", MYNAME);
        write(mfd, buf, strlen(buf));
        sprintf(buf, "\n.\n");
        write(mfd, buf, strlen(buf));
        readport(mfd, tmpbuf);
        if (strstr(tmpbuf, "250") != tmpbuf)
        {
                close(mfd);
                return -1;
        }
 
        sprintf(buf, "QUIT\n");
        write(mfd, buf, strlen(buf));
        readport(mfd, tmpbuf);
        if (strstr(tmpbuf, "221") != tmpbuf)
        {
                close(mfd);
                return -1;
        }
        close(mfd);
}
 
char    *Ctime(clock)
time_t  *clock;
{
        char    *foo,
                *ptr = ctime(clock);
 
        if ((int)(foo = (char *)rindex(ptr, '\n')))
                *foo = '\0';
 
        return (ptr);
}
 
/*
 * �B�z�L�k���e email address �� modem user �q������
 */
int     host_error(userid, email)
char    *userid,
        *email;
{
        fhd     info;
        char    fname[STRLEN],
                genbuf[STRLEN];
        FILE    *fp;
        time_t  ti;
 
        printf("cannot deliver to: %s (%s)\n", email, userid);
        time(&ti);
        strcpy(info.sender, ADMIN);
        strcpy(info.title, "E-mail Address ERROR");
        info.date=time(NULL);
        info.flag=0x00;
        sprintf(fname, "%s/%s/%s/mail/", work, MYHOME, userid);
        buildfile(fname);
        strcpy(info.filename,fname);
        sprintf(genbuf, "%s/%s/%s/mail/%s", work, MYHOME, userid, fname);
 
        if ((fp = fopen(genbuf, "w")) == NULL)
                return -1;
        fprintf(fp, "�H��H: %s@%s (%s)\n", ADMIN, MYNICK, DAEMON);
        fprintf(fp, "��  �D: %s\n", info.title);
        fprintf(fp, "�o�H��: %s (%s)\n\n", MYNAME, Ctime(&ti));
 
        fprintf(fp, "%s, �z�n:\n\n", userid);
 
        fprintf(fp, "    [�`�N] �L�ױz���S���q�L�ͯ����T�{,�b�ԯqbbs�W \n");
        fprintf(fp, "    �ү�ϥ� �� �\ �� �� �� .                           \n");
        fprintf(fp, "    �g�L�t�άd��, �z�� E-mail Address �L�k���e�H��.\n");
        fprintf(fp, "    �]�w�p�U: %s\n\n", email);
        fprintf(fp, "    �Y�z�O�ϥ� IP Address, �p: 111.222.333.444 ���A,\n");
        fprintf(fp, "    �г]�w�z�� E-mail Address �p�P�H�U����.\n");
        fprintf(fp, "    ==> account@[111.222.333.444]\n\n");
        fprintf(fp, "    �Ъ`�N, �b IP-ADDRESS �e����O�[�W '[' ']'\n\n");
        fprintf(fp, "    �_�h�i��O�z�� HOSTNAME �L�k��{, �гq���z�Ҧb�t��\n");
        fprintf(fp, "    ���޲z�H��, �ШD��U. ���±z���X�@.\n\n");
        fprintf(fp, "    PS: ���H��Ѩt�Φ۰ʵo�X, �����D�Ь� SYSOP �O\n");
        fclose(fp);
 
        sprintf(genbuf, "%s/%s/mail/%s", MYHOME, userid, FHDIR);
        if (append_record(genbuf, (char *)&info, sizeof(info)) == -1)
                return -1;
        return 0;
}
 
int     modem_user(userid)
char    *userid;
{
        fhd     info;
        char    fname[STRLEN],
                genbuf[STRLEN];
        FILE    *fp;
        time_t  ti;
 
        printf("modem user: %s\n", userid);
        time(&ti);
 
        strcpy(info.sender, ADMIN);
        strcpy(info.title, "MODEM BBS USER");
        info.date=time(NULL);
        info.flag=0x00;
        sprintf(fname, "%s/%s/%s/mail/", work, MYHOME, userid);
        buildfile(fname);
        strcpy(info.filename,fname);
        sprintf(genbuf, "%s/%s/%s/mail/%s", work, MYHOME, userid, fname);
 
        if ((fp = fopen(genbuf, "w")) == NULL)
                return -1;
        fprintf(fp, "�H��H: %s@%s (%s)\n", ADMIN, MYNICK, DAEMON);
        fprintf(fp, "��  �D: %s\n", info.title);
        fprintf(fp, "�o�H��: %s (%s)\n\n", MYNAME, Ctime(&ti));
 
        fprintf(fp, "%s, �z�n:\n\n", userid);
        fprintf(fp, "    �g�T�{, �ѩ�z����Ʀ��X�k�� E-mail Address\n");
        fprintf(fp, "    �����ثe�������T�{���G :      \n\n");
        fprintf(fp, "     1. ��E-mail address �� �ШϥΨt�εo���T�{�H�T�{\n");
        fprintf(fp, "     2. �LE-mail address �� �N���νT�{�F\n\n");
        fprintf(fp, "    �L�צ��S���q�L�����T�{,�b�ԯqbbs�W�ү�ϥΪ��\��\n");
        fprintf(fp, "    �ҬۦP. \n\n");
 
        fprintf(fp, "    PS: ���H��Ѩt�Φ۰ʵo�X, ������ðݽЦ� SYSOP �O�߰�.\n");
        fclose(fp);
 
        sprintf(genbuf, "%s/%s/%s/mail/%s", work, MYHOME, userid, FHDIR);
        if (append_record(genbuf, (char *)&info, sizeof(info)) == -1)
                return -1;
 
        return 0;
}
 
/*
 * �ˬd email-address �O�_���T
 * return: -1 �����~�o��
 * return:  0 ���`, �i�e�H
 */
int     check_host(email)
char    *email;
{
        char    tmp[BUFLEN];
        int     i,
                ip = TRUE;
        struct  hostent *host;
 
        if (strstr(email, "modem.bbs.user"))
                return -2;
 
        if (strchr(email, '@') == email)
                return -1;
        if (strchr(email, '@'))
                strcpy(tmp, (char *)strchr(email, '@')+1);
 
        for (i = 0; i < strlen(tmp); i++)
        {
                if (isalpha(tmp[i]))
                {
                        ip = FALSE;
                        break;
                }
        }
 
        if (tmp[0] == '[' && tmp[strlen(tmp)-1] == ']')
                return (ip == TRUE) ? 0 : -1;
 
        return (gethostbyname(tmp) ? 0 : -1);
}
 
/*
 * �N�����T�{�H��e�X
 */
void    identify(userid, email, date, checksum, modify)
char    *userid,
        *email,
        *date;
int     checksum,
        modify;
{
        switch (check_host(email))
        {
                case -1:
                        host_error(userid, email);
                        break;
                case -2:
                        modem_user(userid);
                        break;
                default:
                        deliver(userid, email, date, checksum, modify);
                        break;
        }
}
 
/*
 * �N�O���q log file �����X, �ä����o�� userid, email, checksum, �ε��U�ɶ�
 * �ñN�����T�{ mail �e�X
 */
int     prase_log(passfl, file)
char    *passfl,
        *file;
{
        FILE    *fp;
        char    buffer[BUFLEN],
                userid[STRLEN],
                email[STRLEN],
                date[STRLEN],
                *p;
        int     checksum,
                modify;
 
        if ((fp = fopen(file, "r")) == NULL)
                return -1;                      /* cannot open file */
 
        while (fgets(buffer, sizeof(buffer), fp) != NULL)
        {
                if (strstr(buffer, "modify"))
                        modify = TRUE;
                if ((p = (char *)strtok(buffer, "]")) == NULL)
                        continue;
                strcpy(date, p+1);
                if (strtok(NULL, ":") == NULL)
                        continue;
                if ((p = (char *)strtok(NULL, " ")) == NULL)
                        continue;
                strcpy(userid, p);
                if ((p = (char *)strtok(NULL, " ")) == NULL)
                        continue;
                strcpy(email, p);
                if ((p = (char *)strtok(NULL, " ")) == NULL)
                        continue;
                checksum = atoi(p);
                if (exist(passfl, userid))
                        identify(userid, email, date, checksum, modify);
        }
        fclose(fp);
        return 0;
}
 
/*
 * �N�ª� file �ন�s�� filename, ���s�ӽбb���� user �i�H
 * �N�L���s�b���g�J��Ӫ� filename, ���|�]�����b�B�z�Ӥ��_
 * �ο򥢱b���T�{�u�@.
 */
void    main(argc, argv)
int     argc;
char    *argv[];
{
        FILE    *fp;
        char    REG_ORI[STRLEN],
                REG_SRC[STRLEN],
                PASSFLE[STRLEN];
 
        if (argc != 3)
        {
                printf("Usage: %s bbs_home reg_file\n", argv[0]);
                exit(-1);
        }
 
        strcpy(REG_ORI, argv[2]);
        strcpy(work, argv[1]);
        sprintf(REG_SRC, "%s.%d", REG_ORI, getpid());
        sprintf(PASSFLE, "%s/%s", work, MYPASSFILE);
 
        if (access(REG_ORI, R_OK))
                exit(0);                /* Cannot Access File */
 
        rename(REG_ORI, REG_SRC);
 
        if (prase_log(PASSFLE, REG_SRC))
                exit(-2);
 
        unlink(REG_SRC);
        exit(0);
}
