/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef	lint
static	char	sccsid[] = "@(#)averun.c   2.0 3/19/95 (C) 1993 University of \
NCHU, Computer Center and Tseng Kuo-Feng";
#endif

#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define	AVEFLE	"/home/bbs/reclog/ave.src"
#define	AVEPIC	"/home/bbs/etc/welcome/welcome.Tony"

char	*Ctime(date)
time_t	*date;
{
	static char buf[80];

	strcpy(buf, (char *)ctime(date));
	buf[strlen(buf)-1] = '\0';
	return buf;
}

char	*blk[10] =
{
	"��", "��", "�b", "�c", "�d",
	"�e", "�f", "�g", "�h", "�i",
};

int	draw_pic()
{
	FILE	*fp;
	int	max = 0,
		cr = 0,
		tm,
		flag,
		i, c,
		j, d;
	int	pic[24];
	char	buf[80];
	time_t	now;

	time(&now);
	if ((fp = fopen(AVEFLE, "r")) == NULL)
		return -1;
	else
	{
                memset(pic, 0, sizeof(pic));
                while (fgets(buf, 50, fp) != NULL)
		{
                        cr = atoi(strchr(buf, ':')+1);
			tm = atoi(buf);
			pic[tm] = cr;
			max = (max > cr) ? max : cr;
		}
		fclose(fp);
	}

	if ((fp = fopen(AVEPIC, "w")) == NULL)
		return -1;

	d = ((max / 100) > 0) ? (max/100) : 1;
	c = d * 10;

	for (i = 15; i > max / c; i--)
		fprintf(fp, "\n");
	for (i = max/c + 1; i >= 0; i--)
	{
		fprintf(fp, "[1;33m%3d [34m�x", i*c);
		flag = -1;
		for (j = 0; j < 24; j++)
		{
			if (pic[j]/c+1 == i && pic[j] > 0)
			{
				if (flag != 1)
				{
					flag = 1;
					fprintf(fp, "[33m");
				}
				fprintf(fp, "%3d", pic[j]);
			}
			else if (pic[j]/c == i && pic[j]-i*c-1 > 0)
			{
				if (flag != 2)
				{
					flag = 2;
					fprintf(fp, "[32m");
				}
				fprintf(fp, " %2s", blk[(pic[j]-i*c-1)/d]);
			}
			else if (pic[j]/c+1 < i || pic[j]-(i+1)*c < 0)
				fprintf(fp, "   ");
			else
			{
				if (flag != 2)
				{
					flag = 2;
					fprintf(fp, "[32m");
				}
				fprintf(fp, " �i");
			}
		}
		fprintf(fp, "[m\n");
	}
	time(&now);
	fprintf(fp, "    [1;34m�|�w�w�w[35m�ԯq�u�Ӹֱ��e�NBBS�t���H�Ʋέp[34m�w");
	fprintf(fp, "�w[35m%s[34m�w�w�w[m\n", Ctime(&now));
	fprintf(fp, "        [1;33m0  1  2  3  4  5  6  7  8  9 10 11 12 13 14");
	fprintf(fp, " 15 16 17 18 19 20 21 22 23[m\n");

	fclose(fp);
}

int	parse_ave(time, ave)
int	time,
	ave;
{
	FILE	*fp;

	if ((fp = fopen(AVEFLE, "a+")) == NULL)
		return -1;
	fprintf(fp, "%d:%d\n", time, ave);
	fclose(fp);
}

int	gain_hour(buf)
char	*buf;
{
	int	retm;

	retm = atoi(buf);
	if (strstr(buf, "pm") && retm != 12)
		retm +=12;
	if (strstr(buf, "am") && retm == 12)
		retm = 0;
	return retm;
}

int	init_base(file, time)
char	*file;
int	*time;
{
	FILE	*fp;
	char	buf[80],
		*p;
	int	ave = 0,
		tmp = 0,
		i;

	if ((fp = fopen(file, "r")) == NULL)
	{
		printf("File: %s cannot be opened\n", file);
		exit(-2);
	}

	for (i = 0; i < 12; i++)
	{
		int	once = 0;

		if (fgets(buf, 99, fp) == NULL)
			break;
		if (strstr(buf, "day"))
			once = 1;
		if (i == 0)
			*time = gain_hour(buf);
		strtok(buf, ",");
		if (once)
			strtok(NULL, ",");
		p = strtok(NULL, ",");
		ave = ave + atoi(p);
	}
	tmp = ave/i;
	if (tmp*i != ave)
		tmp++;
	fclose(fp);
	return tmp;
}

void	main(argc, argv)
int	argc;
char	**argv;
{
	FILE	*fp;
	char	file[80],
		buf[100],
		start[10],
		end[10],
		*p;
	int	i,
		tmp,
		ave,
		time;

	if (argc < 2)
	{
		printf("Usage: %s crontab_output_filename\n", argv[0]);
		exit(-1);
	}
	ave = init_base(argv[1], &time);
	parse_ave(time, ave);
	draw_pic(time);
}
