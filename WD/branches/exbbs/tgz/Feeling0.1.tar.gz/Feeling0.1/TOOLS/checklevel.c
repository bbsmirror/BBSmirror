#include <stdio.h>
#include <time.h>
#include "/home/oocat/src/maple/perm.h"
#include "/home/oocat/src/maple/struct.h"

#define	IDLEN	(12)
#define	STRLEN	(80)
#define PASSLEN	(14)
#define	PASS	"/home/bbs/.PASSWDS"

typedef	unsigned int	usint;

typedef struct                          /* PASSFILE struct */
{
char userid[IDLEN + 1];
    char realname[20];
        char username[24];
            char passwd[PASSLEN];
                uschar dummy;           
                    usint userlevel;
                        ushort numlogins;
                            ushort numposts;
                                time_t firstlogin;
                                    time_t lastlogin;
                                        char lasthost[16];
                                            char termtype[8];
                                                char email[48];
                                                    ushort uflag;
                                                        char address[50];
                                                            char justify[44];
}                                                            
userec;

void main(argc, argv)
int	argc;
char	**argv;
{
	userec	cuser;
	FILE	*fp;

	fp = fopen(PASS, "r");
	if (fp == NULL)
	{
		puts(".PASSWDS file not found!");
		exit(1);
	}

	while ( fread(&cuser, sizeof(userec), 1, fp) != NULL)
		if (cuser.userlevel & PERM_SYSOP)
			printf("%-12.12s %-20.20s %s\n", cuser.userid, cuser.realname, cuser.email);
	fclose(fp);
}