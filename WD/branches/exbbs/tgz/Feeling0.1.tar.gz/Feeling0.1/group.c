/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef	lint
static  char    SccsId[] = "@(#)group.c	2.1	12/24/95";
#endif

#include "bbs.h"

extern	int	numboards,
		t_lines;
extern	bhd	*bcache;
extern	userec	cuser;

extern	char	*boardmargin();
extern	int	group_read_help(),
		get_records(),
		get_num_records();

int	currgroup = -1;

int	gain_group()
{
	ghd	gcache[MAXGROUPS];
	int	i = 1,
		size,
		fd,
		num;
	char	buf[3];

	move(0,0);
	clrtobot();
	prints(YEA, "�]�w Group �s��\n");
	size = sizeof(ghd);

	if ((fd = open(GROUPS, O_RDONLY, 0)) == -1)
		return 0;

	while (read(fd, (char *)&gcache[i], size) == size)
	{
		move(i%6+2, i/6*19);
		prints(NA, "(%d) %s", i, gcache[i].filename);
		i++;
	}

	while(1)
	{
		getdata(10, 0, "��J�Q�׸s�s��: ", buf, 3, DOECHO, YEA);
		num = atoi(buf);
		if(num == 0)
			return 0;
		if (num > 0 && num < i)
			return gcache[num].groupnum;
		move(11, 0);
		prints(NA, "�Q�׸s�s�����~\n");
	}
}

int	cmpgroup(first, second)
int	first;
ghd	*second;
{
	return !strcasecmp((char *)first, second->filename);
}

int	getgnum(gname)
char	*gname;
{
	ghd	buf;

	return search_record(GROUPS, (char *)&buf, sizeof(ghd), cmpgroup,
		(int)gname);
}

int	getbnum(bname)
char	*bname;
{
	int	i;
	resolve_boards();
	for(i = 0; i < numboards; i++)
	{
      		if (!strncmpi(bname,(bcache[i]).filename,
			sizeof((bcache[i]).filename)))
		{
        		return i+1;
		}
	}
	return 0;
}

int	groupcheck(fptr, buf)
ghd	*fptr;
char	*buf;
{
	return !strcasecmp(fptr->filename, buf);
}

void	groupdoent(num, ent)
int	num;
ghd	*ent;
{
	prints(NA, " %4d  %-15.15s %-54.54s\n", num, ent->filename,
		ent->title);
}


void	grouptitle()
{
        clrtobot();
        menu_draw("[�Q�װϳB�z]", boardmargin);
        prints(NA, "%s   %s   %s   %s\n",
		"[[1;33m��[m,[1;33me[m]�^�W�@�e��",
        	"[[1;33mh[m]�D�U",
		"[[1;33m��[m,[1;33mr[m,[1;33m<cr>[m]��ܥثe�Q�׸s",
		"[[1;33m��[m,[1;33m��[m]�W,�U�@�ϰQ�׸s");

	prints(YEA, "[1;36;44m �s��  %-15.15s %-56.56s[m\n",
		"�Q�׸s�W��", "�Q�׸s����");
	refresh();
}

int	m_groupadd()
{
	ghd	newgroup;

	clear();

	changemode(GCREATE);

	(void)memset(&newgroup, 0, sizeof(newgroup));
	prints(NA, "�إ߰Q�פ���:");
	while (1)
	{
		getdata(3, 0, "�Q�׸s�W�١G",
			newgroup.filename, 18, DOECHO, YEA);
		if (!strcasecmp(newgroup.filename, "new") ||
			!strcasecmp(newgroup.filename, "quit"))
			return -1;
		if (checkid(newgroup.filename))
		{
			prints(NA, "���X�k���Q�װϦW��\n");
			continue;
		}
		if (getgnum(newgroup.filename))
		{
			prints(NA, "Error: Bad Group Name\n");
			continue;
		}
		break;
	}
	getdata(4, 0, "�Q�׸s�����G", newgroup.title, 60, DOECHO, YEA);
	(void)time((time_t *)&newgroup.groupnum);

	if (append_record(GROUPS, (char *)&newgroup, sizeof(newgroup)) == -1)
	{
		pressreturn();
		clear();
		changemode(MADMIN);

		return -1;
	}

	prints(NA, "\n�s�W�Q�׸s����\n");
	pressreturn();

	changemode(MADMIN);

	clear();
	return 0;
}

int	modify_group(gname)
char	*gname;
{
	int	pos,
		ans;
	ghd	fh,
		newfh;
	char	genbuf[STRLEN];

	pos = search_record(GROUPS, (char *)&fh, sizeof(fh), cmpgroup,
		(int)gname);
	if (!pos)
	{
		move(t_lines-1, 0);
		prints(NA, "�O�W��ܿ��~, �Ы����N��..");
		egetch();
		clear();
		return FULLUPDATE;
	}
	move(3,0);
	clrtobot();
	(void)memcpy(&newfh, &fh, sizeof(newfh));
	prints(NA, "�Q�׸s�W�١G %s\n", fh.filename);
	prints(NA, "�Q�׸s�����G %s\n", fh.title);
	prints(NA, "�Q�׸s�Ǹ��G %d\n", fh.groupnum);

	for(;;)
	{
		getdata(11, 0, "�s�Q�׸s�W�١G ", genbuf, 18, DOECHO,
			YEA);
		if (*genbuf != 0)
		{
			ghd dh;

			if (search_record(GROUPS, (char *)&dh, sizeof(dh),
				cmpgroup, (int)genbuf))
			{
				move(3,0);
				prints(NA, "Error! Board already exists\n");
				bell(1);
				move(11,0);
				clrtobot();
				continue;
			}
			(void)strncpy(newfh.filename, genbuf, sizeof(newfh.filename));
		}
		break;
	}

	getdata(12, 0, "�s�Q�s�����G ", genbuf, 60, DOECHO, YEA);
	if (*genbuf != 0)
		(void)strncpy(newfh.title, genbuf, sizeof(newfh.title));

	ans = getans(19, 0, "�x�s���]�w? (Yes or No) [N]: ", 'n');
	if (ans == 'y')
		switch_record(GROUPS, (char *)&newfh, sizeof(newfh), pos);

	return FULLUPDATE;
}

int	m_chgroup()
{
	char	gname[STRLEN];

	move(0, 0);
	clrtobot();
	prints(YEA, "���Q�׸s�]�w");

	move(1,0);
	getdata(1, 0, "�Q�׸s�W��: ", gname, STRLEN, DOECHO, YEA);
	if (*gname == '\0')
	{
		move(2,0);
		prints(NA, "���X�W�w���Q�׸s�W��");
		pressreturn();
		clear();
		return;
	}
	(void)modify_group(gname);
}

int	m_groupdelete(gname)
char	*gname;
{
        ghd	ginfo;
        int	gid,
		ans;
	char	buff[STRLEN];

        gid = getgnum(gname);

        if (get_record(GROUPS, (char *)&ginfo, sizeof(ginfo), gid) == -1)
	{
                move(t_lines-1, 0);
                prints(NA, "�Q�׸s %s ���s�b.\n", gname);
		pressreturn();
                clear();
                return FULLUPDATE;
        }

	(void)sprintf(buff, "�R���Q�׸s '%s' (Y/N)? [N]: ", ginfo.filename);
        ans = getans(t_lines-1, 0, buff, 'n');

        if (ans != 'y')
	{
                move(t_lines-1,0);
		clrtoeol();
		prints(YEA, "[1;32;44m%s                      [m",
		"                     ...���R���Q�׸s..�Ы����N�����}...");
                return 0;
        }

        ans = delete_file(GROUPS, sizeof(ginfo), gid, groupcheck,
		ginfo.filename);

        move(t_lines-1, 0);
	if (!ans) 
		prints(YEA, "[1;32;44m%s                      [m",
		"                     ...�Q�׸s�w�g�R��..�Ы����N�����}...");
	else
		prints(YEA, "[1;32;44m%s                      [m",
		"                     ...�R���Q�׸s����..�Ы����N�����}...");
	egetch();
        move(t_lines-1, 0);
	clrtoeol();
	return 0;
}

/* ARGSUSED */
int	group_read(ent, info, direct)
int	*ent;
ghd	*info;
char	*direct;
{
	currgroup = info->groupnum;
	Boards();
	currgroup = -1;
	return REDOIREAD;
}

/* ARGSUSED */
int	group_new(ent, info, direct)
int	*ent;
ghd	*info;
char	*direct;
{
	currgroup = info->groupnum;
	New();
	currgroup = -1;

	return REDOIREAD;
}

/* ARGSUSED */
int	group_add(ent, info, direct)
int	*ent;
ghd	*info;
char	*direct;
{
	if(!HAS_PERM(PERM_BOARDS))
		return 0;
	(void)m_groupadd();

	return FULLUPDATE;
}

/* ARGSUSED */
int	group_delete(ent, info, direct)
int	*ent;
ghd	*info;
char	*direct;
{
        if(!HAS_PERM(PERM_BOARDS))
                return 0;
	(void)m_groupdelete(info->filename);

	return FULLUPDATE;
}

/* ARGSUSED */
int	group_modify(ent, info, direct)
int	*ent;
ghd	*info;
char	*direct;
{
        if(!HAS_PERM(PERM_BOARDS))
                return 0;
	(void)modify_group(info->filename);

        return FULLUPDATE;
}

one_key group_comms[] =
{
	'r',		group_read,
	'\n',		group_read,
	'\r',		group_read,
	KEY_RIGHT,	group_read,
	'h',		group_read_help,
	'a',		group_add,
	'd',		group_delete,
	'm',		group_modify,
	'\0',		NULL,
};

one_key kind_comms[] =
{
	'r',		group_new,
	'\n',		group_new,
	'\r',		group_new,
	' ',		group_new,
	KEY_RIGHT,	group_new,
	'h',		group_read_help,
	'a',		group_add,
	'd',		group_delete,
	'm',		group_modify,
	'\0',		NULL,
};

int	Group()
{
	changemode(GROUP);

	while (i_read(GROUPS, grouptitle, groupdoent, &group_comms[0], 'Z',
		sizeof(ghd), get_num_records, get_records) == REDOIREAD);

	changemode(MPOST);
	move(2, 0);
	clrtoeol();
	return 0;
}

int	Kind()
{
        changemode(KIND);
	while (i_read(GROUPS, grouptitle, groupdoent, &kind_comms[0], 'Z',
		sizeof(ghd), get_num_records, get_records) == REDOIREAD);
        changemode(MPOST);
	move(2, 0);
	clrtoeol();
        return 0;
}
