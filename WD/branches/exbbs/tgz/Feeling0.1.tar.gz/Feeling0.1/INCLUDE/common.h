/*
 * @(#)common.h	2.1	12/24/95
 */

#define	MESSAGE 	1
#define	CHG_NICK	2
#define	CHG_ROOM	3
