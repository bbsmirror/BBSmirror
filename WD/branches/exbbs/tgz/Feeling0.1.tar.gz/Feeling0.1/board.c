/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef	lint
static  char    SccsId[] = "@(#)board.c	2.2	12/26/95";
#endif

#include "bbs.h"

extern	int	usernum,
		t_lines,
		currgroup,
		numboards,
		selboard;
extern	char	currboard[];
extern	userec	cuser;
extern	usinfo	uinfo;
extern	char	boardmargin(),
		*msgtemp;
extern	int	cmpbname(),
		make_blist();
extern	acc	acclist[];
extern	int	numaccs;

int	num_new = 0;
bhd	*brdlist[MAXBOARD];
int	boardnum;

int	cmprcbid(bid, key)
int	bid;
bbsrc	*key;
{
	return (bid == key->b_flow);
}

int	check_setting(boardname, setting)
char	*boardname;
int	setting;
{
	bhd	fh;

	search_board(&fh, boardname, cmpbname);

	return	( fh.flag & setting );
}

int	count_newpost(ptr)
newhd	*ptr;
{
	struct	stat	st;
	char	genbuf[STRLEN];
	int	fd,
		total,
		num;
	bbsrc	record;
	fhd	file;

	(void)sprintf(genbuf, PATH_BRDDIR, ptr->name, FHDIR);
	if((fd = open(genbuf, O_RDWR)) < 0)
		return 0;
	(void)fstat(fd, &st);
	ptr->total = total = num = st.st_size / sizeof(fhd);
	(void)lseek(fd, (num - 1) * sizeof(fhd), L_SET);
	(void)read(fd, (char *)&file, sizeof(fhd));
	bbsrc_init(&record, ptr->flownum);
	if (record.vname > abs(record.keys[MAXRECS-1]))
	{
		num -= atoi(file.filename + 2) - record.vname;
		if (num < 0)
			num = 0;
		while (num > 0)
		{
			(void) lseek(fd, num * sizeof(fhd), L_SET);
			if (read(fd, (char *)&file, sizeof(fhd)) <= 0)
				break;
			if (file.date <= record.visit)
				break;
			num--;
		}
	}
	else
		num -= atoi(file.filename + 2) - abs(record.keys[MAXRECS-1]);
	if (num < 0)
		num = 0;
	while (num < total)
	{
		(void)lseek(fd, num * sizeof(fhd), L_SET);
		if (read(fd, (char *)&file, sizeof(fhd)) <= 0)
			break;
		if (!bbsrc_ifread(atoi(file.filename + 2)) &&
			(file.date > record.visit))
			break;
		num++;
	}

	ptr->post = total - num;
	(void)close(fd);
	return 0;
}

/*
 * ���s POST �^�ǭȬ��y�����ӪO�`�g�ơz
 * �_�h���y�t�ȡz�� 0
 */
int	has_new_post(ptr)
bhd	*ptr;
{
	struct	stat	st;
	char	genbuf[STRLEN];
	int	fd,
		num;
	bbsrc	record;
	inner	*curr;
	fhd	file;

	(void)sprintf(genbuf, PATH_BBSRC, cuser.userid);
	if (search_record(genbuf, (char *)&record, sizeof(bbsrc),
		cmprcbid, ptr->flownum) <= 0)
	{
		(void)memset((char *)&record, 0, sizeof(bbsrc));
	}
	(void)sprintf(genbuf, PATH_BRDDIR, ptr->filename, FHDIR);
	if((fd = open(genbuf, O_RDWR)) < 0)
		return 0;
	(void)fstat(fd, &st);
	num = st.st_size / sizeof(fhd);
	while (num > 0)
	{
		if (lseek(fd, (num - 1) * sizeof(fhd), L_SET) == -1 ||
			read(fd, (char *)&file, sizeof(fhd)) <= 0)
		{
			num--;
			continue;
		}
		(void)close(fd);
		if ((atoi(file.filename+2) > abs(record.keys[MAXRECS-1])) &&
			(file.date > record.visit))
		{
			return num;
		}
		return -num;
	}
	(void)close(fd);
	return 0;
}

void	brdttl()
{
/*	clear();
*/	menu_draw("[�Q�װϦC��]", boardmargin);
	move(1, 0);
	clrtoeol();
	prints(NA, "%-20s   %-11s   %-27s   %-20s\n",
		"[[1;33m��[m, [1;33me[m]�^�Q�װϿ��",
		"[[1;33mh[m]�D�U",
		"[[1;33m��[m, [1;33mr[m,[1;33m<cr>[m]�i�J�\\Ū�e��",
		"[[1;33m��[m,[1;33m��[m]�W,�U�@�Q�װ�");
	prints(YEA, "[1;36;44m %-5s%5s %-18s%-18s %30s[m\n", "�s��",
		"Z V B", "�Q�װϦW��", "�Q�װϻ���", "�t�d�H");
}

void	newttl()
{
/*	clear();
*/	menu_draw("[�Q�װϦC��]", boardmargin);
	move(1, 0);
	clrtoeol();
	prints(NA, "%-20s   %-11s   %-27s   %-20s\n",
		"[[1;33m��[m, [1;33me[m]�^�Q�װϿ��",
		"[[1;33mh[m]�D�U",
		"[[1;33m��[m, [1;33mr[m,[1;33m<cr>[m]�i�J�\\Ū�e��",
		"[[1;33m��[m,[1;33m��[m]�W,�U�@�Q�װ�");
	prints(YEA, "[1;36;44m %-5s%14s %-18s%-18s%22s[m\n", "�s��",
		"[ �s:�� ]  V B", "�Q�װϦW��", "�Q�װϻ���", "�t�d�H");
}

void	brdent(num, nphd)
int	num;
newhd	*nphd;
{
	prints(NA, " %4d %c %c %c %-18.18s%-36.36s %12s\n", num,
		(is_zapped(nphd->flownum) && 
		!((*nphd->flag) & BHD_NOZAP)) ? 'z' : ' ',
		((*nphd->flag) & BHD_VOTEING) ? 'V' : ' ',
		((*nphd->flag) & BHD_BBSNEWS) ? '#' : ' ',
		nphd->name, nphd->title, nphd->mngs[0]);
}

void	newent(num, ptr)
int	num;
newhd	*ptr;
{
	if (is_zapped(ptr->flownum) && !((*ptr->flag) & BHD_NOZAP))
		prints(NA, " %4d %9s", num, "--- z ---");
	else
	{
#ifndef	SPEED_FIRST
		if (HAS_SET(SET_COUNTNEW))
		{
			if (ptr->total <= 0)
				(void)count_newpost(ptr);
			prints(NA, " %4d %4d:%4d", num, ptr->post, ptr->total);
		}
		else
#endif
		{
			bhd	tmp;

			(void)strcpy(tmp.filename, ptr->name);
			tmp.flownum = ptr->flownum;

			ptr->post = has_new_post(&tmp);
			ptr->total = abs(ptr->post);
			prints(NA, " %4d %4s:%4d", num, (ptr->post > 0) ?
				"��" : "��", ptr->total);
		}
	}
	prints(NA, "  %c %c %-18.18s%-26.26s  %12s\n",
		(*ptr->flag & BHD_VOTEING) ? 'V' : ' ',
		(*ptr->flag & BHD_BBSNEWS) ? '#' : ' ',
		ptr->name, ptr->title, ptr->mngs[0]);
}

int	visit_board(bptr)
bhd	*bptr;
{
	int	pos = 0,
		fd;
	bbsrc	record;
	fhd	frec;
	char	rcpath[STRLEN],
		genbuf[STRLEN];
	struct	stat	fst;

	(void)sprintf(rcpath, PATH_BBSRC, cuser.userid);
	if ((pos = search_record(rcpath, (char *)&record, sizeof(bbsrc),
		cmprcbid, bptr->flownum)) <= 0)
	{
		(void)memset(&record, 0, sizeof(bbsrc));
		record.b_flow = bptr->flownum;
	}
	(void)sprintf(genbuf, PATH_BRDDIR, bptr->filename, FHDIR);
	while ((fd = open(genbuf, O_RDONLY)) >= 0)
	{
		if (fstat(fd, &fst) < 0)
		{
			close(fd);
			break;
		}
		(void)lseek(fd, ((fst.st_size/sizeof(fhd))-1)*sizeof(fhd),
			L_SET);
		(void)read(fd, (char *)&frec, sizeof(fhd));
		record.vname = atoi(frec.filename+2);
		close(fd);
		break;
	}
	record.visit = time(NULL);
	if (pos <= 0)
		return append_record(rcpath, (char *)&record, sizeof(bbsrc));
	else
		return switch_record(rcpath, (char *)&record, sizeof(bbsrc),
			pos);
}

int	visit_boards(fptr)
bhd	*fptr;
{
	bhd	fh;

	move(1,0);
	prints(YEA, "�ثe Visit �� Board ��: %.20s\n", fptr->filename);

	search_board(&fh, fptr->filename, cmpbname);
	if (visit_board(&fh) == QUIT)
		return QUIT;
	return 0;
}

int	Visit()
{
	int	ans;
	char	bname[STRLEN];
	bhd	fh;

	clear();
	refresh();
	move(0,0);

	changemode(VISIT);

	prints(NA, "Visit Board(s)\n");
	ans = getans(1,0,"(A)ll boards, (1) board, or (Q)uit? [Q]: ",'q');
	move(1,0);
	clrtoeol();

	switch(ans)
	{
		case 'a':
			apply_boards(visit_boards, -1, NA);
			break;
		case '1':
			prints(NA, "Select board: ");
			name_query(NULL, bname, make_blist);
			move(5,0);
			if (*bname == '\0' || !search_board(&fh, bname,
				cmpbname))
			{
				prints(NA, "Invalid board name.\n");
				break;
			}
			prints(NA, "�ثe���b�N %s �O�Ь�Ū�L.. �еy��",
				fh.filename);
			(void)visit_board(&fh);
			move(5, 0);
			clrtoeol();
			break;
		default:
			move(5,0);
			prints(NA, "Visit aborted.\n");
	}
	pressreturn();
	clear();

	changemode(MPOST);

	return -1;
}

/* ARGSUSED */
int	brd_select(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	static	int	i = 0,
			find = YEA;
	static	char	bname[STRLEN];
	int	j,
		ch;

	if (find == YEA)
	{
		(void)memset(bname, 0, sizeof(bname));
		find = NA;
		i = 0;
	}

	while (1)
	{
		move(t_lines-1, 0);
		clrtoeol();
		prints(YEA, "�п�J�j�M���W ==> ");
		prints(NA, "%s", bname);
		ch = egetch();

		if (ISPRINT(ch))
		{
			bname[i++] = ch;

			for (j = 0; j < num_new; j++)
			{
				if (!strncmpi(brdlist[j]->filename, bname, i))
				{
					*ent = j+1;
					return LOOPUPDATE;
				}
			}

			if (find == NA)
			{
				bname[--i] = '\0';
				bell(1);
			}
			continue;
		}
		else if (ch == CTRL('H') || ch == KEY_LEFT || ch == KEY_DEL ||
			ch == '\177')
		{
			i--;
			if (i < 0)
			{
				find = YEA;
				break;
			}
			else
			{
				bname[i] = '\0'; 
				continue;
			}
		}
		else if (ch == '\t')
		{
			find = YEA;
			break;
		}
		else if (ch == '\n' || ch == '\r' || ch == KEY_RIGHT)
		{
			find = YEA;
			break;
		}
		bell(1);
	}
	if (find)
	{
 		move(t_lines-1, 0);
		clrtoeol();
		return PARTUPDATE;
	}
	return LOOPUPDATE;
}

/* ARGSUSED */
int	brd_zap(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	bhd	bh;

	if (!search_board(&bh, brdinfo->name, cmpbname))
	{
		numboards = -1;
		return -1;
	}

	if (!check_setting(brdinfo->name, BHD_NOZAP))
		tog_zapflag(brdinfo->flownum);

	return PARTUPDATE;
}

/* ARGSUSED */
int	brd_faqview(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	faqview(brdinfo->name);
	return FULLUPDATE;
}

/* ARGSUSED */
int	brd_yank(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	SWITCH_SET(SET_YANKIN);
	return FULLUPDATE;
}

/* ARGSUSED */
int	brd_help(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	extern	hlpinfo	BoardSelect[];

	clear();
	do_the_help(BoardSelect);
	pressreturn();
	clear();

	return FULLUPDATE;
}

/* ARGSUSED */
int	brd_read(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	(void)strcpy(currboard, brdinfo->name);
	selboard = YEA;
	Read();
	return	FULLUPDATE;
}

/* ARGSUSED */
int	new_read(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	char	buf[STRLEN];
	int	tmp;

	(void)strcpy(currboard, brdinfo->name);
	(void)sprintf(buf, PATH_BRDDIR, currboard, FHDIR);
#ifndef	SPEED_FIRST
	if (!HAS_SET(SET_COUNTNEW))
#endif
		(void)count_newpost(brdinfo);
	tmp = brdinfo->total - brdinfo->post + 1;
	getkeep(buf, tmp, 1);
	selboard = YEA;
	Read();
	return HAS_SET(SET_NEWYANKIN) ? REDOIREAD : FULLUPDATE;
}

void	show_board_info(boardname)
char	*boardname;
{
	char	buf[WRAPMARGIN];
	FILE	*info;
	int	i;
	time_t	now;
	char	genbuf[STRLEN];
	struct stat st;

	(void)sprintf(buf, "boards/%s/.INFO", boardname);	
	if ((info = fopen(buf, "r")) == NULL)
		prints(NA, "\n�ثe�|�L�Q�װ�²��.\n");
	else if ( stat(buf, &st) != -1 && st.st_size == 0 )
		prints(NA, "\n�ثe�|�L�Q�װ�²��.\n");
	else
	{
/* Added by Seiya */
		(void)time(&now);
		acclist[boardnum].date = now;
		(void)sprintf(genbuf, PATH_ACCESS, cuser.userid);
		switch_record(genbuf, (char *)&acclist[boardnum],
				sizeof(acc), boardnum+1);

		prints(NA, "[1;37m²���p�U:[m\n");
		for(i = 1; i <= 18; i++)
		{
			if (fgets(buf, sizeof(buf), info))
				prints(NA, "%s", buf);
			else
				break;
		}
		(void)fclose(info);
	}
}

/* ARGSUSED */
int	brd_info(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	int	i;
	char	buf[STRLEN];

	clear();
	move(0,0);
	prints(NA, "�Q�װ� %s �D�D��: %s\n", brdinfo->name, brdinfo->title);

	for (i = 0; i < 3; i++)
	{
		if (brdinfo->mngs[i][0])
		{
			(void)strcat(buf, brdinfo->mngs[i]);
			(void)strcat(buf, " ");
		}
	}

	if (buf[0])
		prints(NA, "�Q�װϥN�z�H����: %s\n", buf);
	else
		prints(NA, "�ثe�L�Q�װϥN�z�H����¾\n");

	prints(NA, "�o�ӰQ�װ�%s�P��L�� BBS �� News �洫�H��\n",
		(*brdinfo->flag & BHD_BBSNEWS) ? "��" : "�S��");
	prints(NA, "�z%s�w�\\���Q�װ�\n",
		is_zapped(brdinfo->flownum) ? "�|��" : "�w");

	for (i = 1; i < 80; i++)
		prints(NA, "-");

	move(5, 0);
	show_board_info(brdinfo->name);

	pressreturn();

	return FULLUPDATE;
}

void	edit_board_info(board)
char	*board;
{
	char	buf[STRLEN];
	int	ans;

	clear();
	(void)sprintf(buf,"boards/%s/.INFO", board);
	ans = getans(1,0,"(E)dit board info, (D)elete board info, or (Q)uit? [Q]: ",'q');
	switch(ans)
	{
		case 'e':(void)vedit(buf, NA);
			break;
		case 'd':
			ans = getans(2, 0, "Really want to delete board info? (Y/N) [N]:", 'n');
			if (ans == 'y')
			(void)unlink(buf);
			break;
		dafault:
			break;
	}
}

/* ARGSUSED */
int	brd_edinfo(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	int	bdeputy = NA;

	if (!strcasecmp(cuser.userid, brdinfo->mngs[0]) ||
		!strcasecmp(cuser.userid, brdinfo->mngs[1]) ||
		!strcasecmp(cuser.userid, brdinfo->mngs[2])) 
		bdeputy = YEA;

	if (HAS_PERM(PERM_BOARDS) || (HAS_PERM(PERM_LOCALBM) && bdeputy))
	{
		edit_board_info(brdinfo->name);
		return FULLUPDATE;
	}
	else 
		bell(1);

	return DONOTHING;
}

/* ARGSUSED */
int	brd_visit(ent, brdinfo, direct)
int	*ent;
newhd	*brdinfo;
char	*direct;
{
	bhd	bh;

	if (brdinfo->name[0] == '\0' || !search_board(&bh, brdinfo->name,
		cmpbname))
		return DONOTHING;

	(void)visit_board(&bh);

	return PARTUPDATE;
}

int	talk_preview()
{
	if (msgtemp!=NULL)
		t_listmsg();
	return PARTUPDATE;
}
	
one_key	brdcmd[] =
{
	'y',		brd_yank,
	'h',		brd_help,
	'z',		brd_zap,
	'v',		brd_visit,
	'x',		brd_faqview,
	'\n',		brd_read,
	'\r',		brd_read,
	'r',		brd_read,
	KEY_RIGHT,	brd_read,
	'i',		brd_info,
	'W',		brd_edinfo,
	's',		brd_select,
	'S',		brd_select,
/* Add by TonyCheng */	
	CTRL('r'),	talk_preview,
	'\t',		brd_select,
	'\0',		NULL,
};

one_key	newcmd[] =
{
	'y',		brd_yank,
	'h',		brd_help,
	'z',		brd_zap,
	'v',		brd_visit,
	'x',		brd_faqview,
	'\n',		new_read,
	'\r',		new_read,
	'r',		new_read,
	KEY_RIGHT,	new_read,
	'i',		brd_info,
	'W',		brd_edinfo,
	's',		brd_select,
	'S',		brd_select,
	CTRL('r'),	talk_preview,
	'\t',		brd_select,
	'\0',		NULL,
};

int	build_board_list(ptr)
bhd	*ptr;
{
	brdlist[num_new++] = ptr;
	return 0;
}

/* ARGSUSED */
int	brdnum(direct, size)
char	*direct;
int	size;
{
	num_new = 0;
	(void)memset(brdlist, 0, sizeof(brdlist));
	apply_boards(build_board_list, currgroup, HAS_SET(SET_YANKIN));
	return num_new;	
}

int	newpost_board(ptr)
bhd	*ptr;
{
	if (HAS_SET(SET_YANKIN) || has_new_post(ptr) > 0)
		brdlist[num_new++] = ptr;
	return 0;
}

/* ARGSUSED */
int	numnew(direct, size)
char	*direct;
int	size;
{
	num_new = 0;
	(void)memset(brdlist, 0, sizeof(brdlist));
	apply_boards(newpost_board, currgroup, HAS_SET(SET_YANKIN));
	return num_new;	
}

/* ARGSUSED */
int	brdrec(dirbuf, ptr, size, topln, nument)
char	*dirbuf;
newhd	*ptr;
int	size,
	topln,
	nument;
{
	int	i = 0,
		curr;
	newhd	*lst;

	for (i = 0; i < nument; i++)
	{
		curr = i + topln - 1;
		if (!brdlist[curr] || !brdlist[curr]->filename[0])
			break;
		lst = &ptr[i];
		lst->name = brdlist[curr]->filename;
		lst->flownum = brdlist[curr]->flownum;
		lst->mngs[0] = brdlist[curr]->mngs[0];
		lst->mngs[1] = brdlist[curr]->mngs[1];
		lst->mngs[2] = brdlist[curr]->mngs[2];
		lst->title = brdlist[curr]->title;
		lst->total = lst->post = -1;
		lst->flag = &brdlist[curr]->flag;
/*		lst->zap = */
	}
	return i;
}

int	Boards()
{
	int	savemode;
	static	int	first = 1;

	if (first)
	{
		getkeep(BOARDS, 1, 1);
		first = 0;
	}
	savemode = uinfo.mode;
	changemode(SHOW);
	while (i_read(BOARDS, brdttl, brdent, brdcmd, 'y', sizeof(newhd),
		brdnum, brdrec) == REDOIREAD);
	changemode(savemode);
	move(2, 0);
	clrtoeol();
	return FULLUPDATE;
}

int	Digest()
{
	faqview(currboard);
	return 0;
}

int	new_alloc_search(num)
int	num;
{
	int	j;

	for (j = num-1; j < num_new; j++)
	{
		if (has_new_post(brdlist[j]) > 0)
		{
			num = j+1;
			return num;
		}
	}
	return NA;
}

int	New()
{
	int	savemode,
		ent;

	savemode = uinfo.mode;
	changemode(READNEW);
	if (HAS_SET(SET_NEWYANKIN))
	{
		(void)brdnum(BOARDS, sizeof(newhd));
		do
		{
			ent = 1;
			if (ent = new_alloc_search(ent))
				getkeep(BOARDS, ent, 1);
		}
		while (i_read(BOARDS, newttl, newent, newcmd, '\0',
			sizeof(newhd), brdnum, brdrec) == REDOIREAD);
	}
	else
	{
		while (i_read(BOARDS, newttl, newent, newcmd, '\0',
			sizeof(newhd), numnew, brdrec) == REDOIREAD);
	}
	changemode(savemode);
	move(2, 0);
	clrtoeol();
	return FULLUPDATE;
}
