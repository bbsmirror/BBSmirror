int	show_issue()
{
	char   issue[256];
	time_t now = time(NULL);
	sprintf(issue, PATH_ISSUE, ((now/60) % MAX_ISSUE_NO));
	if (access(issue, R_OK) == -1)
	{
	    sprintf(issue, PATH_ISSUE, 0);
	}
	if (access(issue, R_OK) == -1)
	{
	    clear();
	    prints(NA, "NOTICE: ISSUE %s ���s�b\n ",
		issue);
	    pressreturn();
	    return -1;
	}
	more(issue, NA);

	return 0;
}
