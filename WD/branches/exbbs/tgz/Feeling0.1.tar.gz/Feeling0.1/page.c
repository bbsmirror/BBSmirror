/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw
			   ���崼, Alen@music.nsysu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    SccsId[] = "%W%	%G%";
#endif

#include "bbs.h"

extern	userec	cuser;
extern	UTCACHE	*utmpshm;
extern	int	t_lines;
extern  usinfo  uinfo;

extern	char	boardmargin();
extern	int	ApplyToLinkList(),
		mail_do_send();
extern	void	prints();

static	int	totalfriends,
		userlist = 0,	/* 0: �i����H��, 1: t->user, 2: t->friend */
		user_real_series = 0;

hlpinfo	TALK_Help[] = {
     0,  0, HIGH, 0,            "[1;36;44m                                ��ѿ��  �ާ@����                             [m\n\n",
    -1, -1, HIGH, 0,            "[1;36;44m                                  ��в��ʻ���                                 [m\n",
    -1, -1,  LOW, 0,            "p �� n �� �ť���    �W �U�@�����\n",
    -1, -1,  LOW, 0,            "P PgUp N PgDn       �W/�U�@��\n",
    -1, -1,  LOW, 0,            "##<cr>              ����J�@�ӼƦr�A��J Enter ��, ���##�����\n",
    -1, -1,  LOW, 0,            "$                   �̫�@�����\n",
    -1, -1,  LOW, 0,            "\n",
    -1, -1, HIGH, 0,            "[1;36;44m                                ��L�`�Ϊ��\\����                               [m\n",
    -1, -1,  LOW, PERM_SYSOP,   "        CTRL-K      ��X���~\n",
    -1, -1,  LOW, 0,            "        Q           �d�ݭp����\n",
    -1, -1,  LOW, PERM_TRUE,	"        a           �ǰe�T��\n",
    -1, -1,  LOW, PERM_PAGE,    "        t           ������\n",
    -1, -1,  LOW, PERM_PAGE,    "        o           �W�[��B�ͦW�椤\n",
    -1, -1,  LOW, PERM_PAGE,    "        d           �ѪB�ͦW�椤�R��\n",
    -1, -1,  LOW, PERM_PAGE,    "        f           ���W�W��ΪB�ͦW��Ҧ�����\n",
    -1, -1,  LOW, PERM_POST,	"        m           �H�H������\n",
    -1, -1,  LOW, PERM_LOCAL,   "        u           �d�ݯ��ͪ��ʺ�\n",
    -1, -1,  LOW, PERM_LOCAL,   "        v           �d�ݯ��ͪ��Ǹ�\n",
/*    -1, -1,  LOW, PERM_ACCOUNTS,"        r           �d�ݯ��ͪ��u��m�W\n", */
    -1, -1,  LOW, 0,	        "        h           �����U�e��\n",
    -1, -1,  LOW, 0,	        NULL,
};

/*** TITLE ����� *********************************************************/

void	talk_menu_draw(header)
char	*header;
{
	char	*FIELD,
		*BUF[3] = { "�ʦW�ٸ�", "�u��m�W", "�b���ǽX", };

	FIELD = BUF[user_real_series];

/*	clear();
	move(1, 0);
	clrtoeol();
	move(2, 0);
	clrtoeol();
*/	menu_draw(header, boardmargin);
	prints(NA, "%s  %s  %s\n",
		"[[1;33m��[0m, [1;33me[0m]�^�W�@�h���  [[1;33mh[m]�D�U",
		"[[1;33m��[m, [1;33mr[m,[1;33m<cr>[m]��w�ثe����",
		"[[1;33m��[m]�W�@��  [[1;33m��[m]�U�@��");
	prints(YEA, "[1;36;44m%s%s%s%c%s[m\n", " �s�� �ϥαb��     ", FIELD,
		"             �Ӧۦ��        P ",
		HAS_PERM(PERM_SEECLOAK) ? 'C' : ' ', " �ثe�ʺA      ���m ");
}

/*
 * ���ܤ譫�� login �߰ݭn�M���@�� process talk �� title
 */
int	request_title()
{
	talk_menu_draw("[��ܥ�ͪ���V]");
}

/*
 * login �W�L�@����, multi-login �ˬd�n logout ���@�� login �� title
 */
int	multi_title()
{
	talk_menu_draw("[�ϥΪ��p�C��]");
}

/*
 * �C�X user ���A�� TITLE.
 */
void	page_title()
{
	talk_menu_draw("[���W�ϥΪ̦C��]");
}

/*
 * �C�X friends ���A�� TITLE
 */
void	friend_title()
{
	talk_menu_draw("[�ثe���W�B�ͪ��A]");
}

/*
 * �C�X override �����A�ϥΪ� title
 */
void	override_title()
{
/*	clear();	*/
	menu_draw("[�B�ͳ]�w�C��]");
	prints(NA, "%s  %s  %s\n",
		"[[1;33m��[m, [1;33me[m]�^�W�@�h���  [[1;33mh[m]�D�U",
		"[[1;33m��[m, [1;33mr[m,[1;33m<cr>[m]��w�ثe�B��",
		"[[1;33m��[m]�W�@��  [[1;33m��[m],�U�@��");
}

/*** �浧�����ܳ��� *******************************************************/

/*
 * �C�X user �ާ@���A, �� User/Friend/Shutdown �ϥ�
 */
char	pagerchar(me, inf)
char	*me;
usinfo	*inf;
{
	if (!inf->allpager)
		return '#';
	return inf->pager ? ' ' :
		(can_override(inf->userid, me, "override") ? 'O' : '*');
}

#ifdef LIST_IDLE_TIME
char	*list_idle(uentp)
usinfo	*uentp;
{
	time_t	now,
		diff;
	struct	stat	buf;
	static	char	buff[STRLEN];

	if ((stat(uentp->ttyname, &buf) != 0) ||
#ifndef SOLARIS
		strstr(uentp->ttyname, "tty") == NULL)
#else
		strstr(uentp->ttyname, "pts") == NULL)
#endif
		return "����";

	(void)time(&now);
	diff = now - buf.st_atime;
#ifdef DOTIMEOUT
	if (!(uentp->userlevel & PERM_NOTIMEOUT))
	{
		if ((diff > USER_TIMEOUT) && (diff < 60*60*24*5))
			(void)kill(uentp->pid, SIGHUP);
	}
#endif
	if ((diff /= 60) < 60)
		(void)sprintf(buff, "%5d", (diff%60));
	else
		(void)sprintf(buff, "%4dh", (diff/60));
	return buff;
}
#endif

char	*itoa(num)
int	num;
{
	static	char	buffer[10];

	(void)sprintf(buffer, "%d", num);
	return buffer;
}

/* ARGSUSED */
int	page_ent(num, inf)
int	num;
usinfo	*inf;
{
#ifdef	LIST_IDLE_TIME
	prints(NA, "  %3d %-12.12s %-20.20s %-15.15s %c %c %-12.12s %4s\n",
		num, inf->userid, ((user_real_series == 0) ? inf->username :
		((user_real_series == 1) ? inf->realname : itoa(inf->uid))),
		inf->from, pagerchar(cuser.userid, inf->userid, inf->pager,
		inf->allpager),	HAS_PERM(PERM_SEECLOAK) ? (inf->invisible ?
		'#' : ' ') : ' ', modestring(inf->mode, inf->ptcb),
		list_idle(inf));
#else
	prints(NA, "  %3d %-12.12s %-20.20s %-15.15s %c %c %-12.12s\n",	num,
		inf->userid, ((user_real_series == 0) ? inf->username :
		((user_real_series == 1) ? inf->realname : itoa(inf->uid))),
		inf->from, pagerchar(cuser.userid, inf->userid, inf->pager,
		inf->allpager),	HAS_PERM(PERM_SEECLOAK) ? (inf->invisible ?
		'#' : ' ') : ' ', modestring(inf->mode, inf->ptcb));
#endif
}

/*
 * �C�X override �W��.
 */
int	override_ent()
{
}

/*** �D�{������ *************************************************************/

/* ARGSUSED */
int	talk_do_mail(ent, finfo, direct)
int	*ent;
usinfo	*finfo;
char	*direct;
{
	if (!HAS_PERM(PERM_POST))	return	DONOTHING;
	clear();
	prints(NA, "�H�H��: %s\n", finfo->userid);
	mail_do_send(finfo->userid);
	return FULLUPDATE;
}

/* ARGSUSED */
int	talk_override(ent, finfo, direct)
int	*ent;
usinfo	*finfo;
char	*direct;
{
	move(t_lines-1, 0);
	if (addtooverride(finfo->userid, "override"))
		prints(NA, "�i%s�j��ӴN�b override �W�椧��", finfo->userid);
	else
		prints(NA, "�i%s�j�w�g�[�J override �W�椤'", finfo->userid);
	prints(NA, "...�Ы����N���~��...");
	egetch();
	move(t_lines-1, 0);
	clrtoeol();
	return PARTUPDATE;
}

/* ARGSUSED */
int	talk_query(ent, finfo, direct)
int	*ent;
usinfo	*finfo;
char	*direct;
{
	clear();
	show_plan(NA, finfo->userid, prints);
	move(t_lines-1, 0);
	clrtoeol();
	prints(NA, " [�\\Ū�p����]  %s%s%s",
		"[[1;33mm[m]�H�H [[1;33mo[m]�[�J�B�� [[1;33mq[m|",
		"[1;33m��[m]���� [[1;33mSpace[m|[1;33m��[m|",
		"[1;33m��[m]�U�@�� [[1;33m��[m] �W�@�� ");

	switch (tolower(egetch()))
	{
		case 'm':
			(void)talk_do_mail(ent, finfo, direct);
			return READ_LOOP;
		case 'o':
			(void)talk_override(ent, finfo, direct);
			return READ_LOOP;
		case ' ':
		case KEY_DOWN:
		case KEY_RIGHT:
			return READ_NEXT;
		case KEY_UP:
			return READ_PREV;
	}
	return FULLUPDATE;
}

/* ARGSUSED */
int	talk_help(ent, finfo, direct)
int	*ent;
usinfo	*finfo;
char	*direct;
{
	clear();
	do_the_help(TALK_Help);
	pressreturn();
	return FULLUPDATE;
}

/* ARGSUSED */
int	talk_del_override(ent, finfo, direct)
int	*ent;
usinfo	*finfo;
char	*direct;
{
	move(t_lines-1, 0);
	if (deleteoverride(finfo->userid, "override"))
		prints(NA, "�i%s�j���b override �W�椤", finfo->userid);
	else
		prints(NA, "�i%s�j�w�q override �W�椤����", finfo->userid);
	prints(NA, "...�Ы����N���~��...");
	egetch();
	move(t_lines-1, 0);
	clrtoeol();
	return PARTUPDATE;
}

/* ARGSUSED */
int	talk_dotalk(ent, finfo, direct)
int	*ent;
usinfo	*finfo;
char	*direct;
{
	int	tuid;

	if (!HAS_PERM(PERM_PAGE) || !strcasecmp(finfo->userid, cuser.userid)
		|| (finfo->invisible && !HAS_PERM(PERM_SEECLOAK)))
	{
		bell(1);
		return DONOTHING;
	}
	tuid = getuser(finfo->userid);
	talk_connect(tuid, finfo->userid, finfo);
	return FULLUPDATE;
}

/* ARGSUSED */
int	talk_multi_dotalk(ent, finfo, direct)
int	*ent;
usinfo	*finfo;
char	*direct;
{
	if (!HAS_PERM(PERM_PAGE))
	{
		bell(1);
		return DONOTHING;
	}
	(void)talk_dotalk(ent, finfo, direct);
	return DOQUIT;
}

/* ARGSUSED */
int	talk_username(ent, finfo, direct)
int	*ent;
usinfo	*finfo;
char	*direct;
{
	user_real_series = 0;
	return FULLUPDATE;
}

/* ARGSUSED */
/*pass by Chars*/
/*
int	talk_realname(ent, finfo, direct)
int	*ent;
usinfo	*finfo;
char	*direct;
{
	if (!HAS_PERM(PERM_ACCOUNTS))
		return DONOTHING;
	user_real_series = 1;
	return FULLUPDATE;
}
*/
/* ARGSUSED */
int	talk_series(ent, finfo, direct)
int	*ent;
usinfo	*finfo;
char	*direct;
{
	if (!HAS_PERM(PERM_LOCAL))
		return DONOTHING;
	user_real_series = 2;
	return FULLUPDATE;
}

/* ARGSUSED */
int	talk_self_kick(ent, finfo, direct)
int	*ent;
usinfo	*finfo;
char	*direct;
{
	char	be_kicked[STRLEN],
		ans[5];
	time_t	now;

	now = time(NULL);
	(void)sprintf(be_kicked, "�N %s ��X���~ (Y/N): [N]? ", finfo->userid);
	getdata(t_lines-1, 0, be_kicked, ans, 4, DOECHO, YEA);
	logit(PATH_USIES, "%-15s KICKED %-15s %-20s %s", cuser.userid,
		finfo->userid, finfo->username, Ctime(&now));
	if (ans[0] == 'y' || ans[0] == 'Y')
	{
		(void)kill(finfo->pid, SIGHUP);
		return FULLUPDATE;
	}
	return PARTUPDATE;
}

/* ARGSUSED */
int	talk_kick(ent, finfo, direct)
int	*ent;
usinfo	*finfo;
char	*direct;
{
	if (!HAS_PERM(PERM_SYSOP))
		return DONOTHING;
	return talk_self_kick(ent, finfo, direct);
}

/* ARGSUSED */
int	talk_switch(ent, finfo, direct)
int	*ent;
usinfo	*finfo;
char	*direct;
{
	userlist = userlist % 2 + 1;
	return REDOIREAD;
}

int     talk_read_message(ent,finfo,direct)
int     *ent;
usinfo  *finfo;
char    *direct;
{
	int	tuid;

	if (!HAS_PERM(PERM_TRUE))	return	0;
   	if (!strcasecmp(finfo->userid, cuser.userid))   return  0;
     	tuid = getuser(finfo->userid);
/*
        if(finfo->allpager == NA || (finfo->pager == NA &&
        	!can_override(finfo->userid, cuser.userid, "override")))	 
        {								  
        	move(2,0);
		clrtoeol();
        	prints(NA, TALK_MSGOFF);
        	return 0;				
        }
*/       								 	
        msg_connect(tuid, finfo->userid, finfo, NULL);
        return  FULLUPDATE;
}

one_key	multi_talk_cmd[] =
{
	CTRL('K'),	talk_kick,
	KEY_RIGHT,	talk_multi_dotalk,
	'\n',		talk_multi_dotalk,
	'\r',		talk_multi_dotalk,
	'a',		talk_read_message,
	't',		talk_multi_dotalk,
	'Q',		talk_query,
	'o',		talk_override,
	'd',		talk_del_override,
	'v',		talk_series,
	'm',		talk_do_mail,
/*	'r',		talk_realname,*//*pass by chars*/
	'u',		talk_username,
	'h',		talk_help,
	'\0',		NULL,
};

one_key	multi_send_cmd[] =
{
	CTRL('K'),	talk_kick,
	KEY_RIGHT,	talk_read_message,
	'\n',		talk_read_message,
	'\r',		talk_read_message,
	'a',		talk_read_message,
	't',		talk_multi_dotalk,
	'Q',		talk_query,
	'o',		talk_override,
	'd',		talk_del_override,
	'v',		talk_series,
	'm',		talk_do_mail,
/*	'r',		talk_realname,*//*pass by chars*/
	'u',		talk_username,
	'h',		talk_help,
	'\0',		NULL,
};

one_key	multi_kick_cmd[] =
{
	CTRL('K'),	talk_self_kick,
	KEY_RIGHT,	talk_self_kick,
	'\n',		talk_self_kick,
	'\r',		talk_self_kick,
	'a',		talk_read_message,
	't',		talk_dotalk,
	'Q',		talk_query,
	'o',		talk_override,
	'd',		talk_del_override,
	'v',		talk_series,
	'm',		talk_do_mail,
/*	'r',		talk_realname,*//*pass by chars */
	'u',		talk_username,
	'h',		talk_help,
	'\0',		NULL,
};

one_key	page_cmd[] =
{
	CTRL('K'),	talk_kick,
	KEY_RIGHT,	talk_query,
	'\n',		talk_query,
	'\r',		talk_query,
	'Q',		talk_query,
	'd',		talk_del_override,
	'f',		talk_switch,
	'h',		talk_help,
	'm',		talk_do_mail,
	'o',		talk_override,
/*	'r',		talk_realname,*//*pass by chars*/
	'v',		talk_series,
	'a',		talk_read_message,
	't',		talk_dotalk,
	'u',		talk_username,
	'\0',		NULL,
};

int	active(uentp)
usinfo	*uentp;
{
	if (uentp == NULL || !uentp->active || !uentp->pid ||
		(!HAS_PERM(PERM_SEECLOAK) && uentp->invisible) ||
		kill(uentp->pid, 0) == -1 || uentp->userid[0] == '\0')
	{
		return NA;
	}
	return YEA;
}

int	count_active(uentp)
usinfo	*uentp;
{
	static	int	count;

	if (uentp == NULL) 
	{
      		int	c = count;
      		count = 0;

      		return c;
    	}

    	if (!uentp->active || !uentp->pid || kill(uentp->pid, 0) == -1)
	{
		(void)memset(uentp, 0, sizeof(usinfo));
      		return 0;
	}

	if (userlist && (!HAS_PERM(PERM_SEECLOAK) && uentp->invisible))
		return 0;

#ifdef	NOCOUNT_MULTI
    	if (uentp->userlevel & PERM_MULTILOG)
		return 0; /* don't count multiloggers */
#endif
    	count++;

    	return 1;
}

int	num_active_users()
{
	(void)count_active(NULL);
	(void)apply_ulist(count_active);
	return count_active(NULL);
}

/* ARGSUSED */
int	page_num_recs(buf, size)
char	*buf;
int	size;
{
	userlist = 1;
	return num_active_users();
}

/* ARGSUSED */
int	page_get_rec(dirbuf, ptr, size, topln, nument)
char	*dirbuf;
usinfo	*ptr;
int	size,
	topln,
	nument;
{
	int	i,	j,	k;
	usinfo	*curr;

	for (i = j = k = 0; i < UTMP_SIZE && j < 20; i++)
	{
		if (active(&(utmpshm->utc[i])))
		{
			if (++k >= topln)
			{
				curr = &ptr[j++];
				(void)memcpy(curr, &(utmpshm->utc[i]), size);
			}
		}
	}
	return j;
}

/*
 * �C�X�Ҧ��� users, ���N�� User();
 */
int	page_user_list()
{
	char	genbuf[STRLEN];

	changemode(LUSERS);
	user_real_series = 0;
	(void)sprintf(genbuf, "TALK_%d", UTMP_SHMKEY);
	getkeep(genbuf, 1, YEA);
	return i_read(genbuf, page_title, page_ent, page_cmd, '\0',
		sizeof(usinfo), page_num_recs, page_get_rec);
	move(2, 0);
	clrtoeol();
	return 0;
}

int	cmpfid(source, target)
char	*source;
usinfo	*target;
{
	if (!strcasecmp(source, target->userid))
		return QUIT;
	return 0;
}

int	cmpfriend(buf)
usinfo	*buf;
{
	if (!active(buf))
		return;
	if (ApplyToLinkList(cmpfid, buf))
		totalfriends++;
}

/* ARGSUSED */
int	friend_num_recs(buf, size)
char	*buf;
int	size;
{
	totalfriends = 0;
	userlist = 2;
	(void)apply_ulist(cmpfriend);
	return totalfriends;
}

int	friend_get_rec(dirbuf, ptr, size, topln, nument)
char	*dirbuf;
usinfo	*ptr;
int	size,
	topln,
	nument;
{
	int	i,	j,	k;
	usinfo	*curr;

	for (i = j = k = 0; i < UTMP_SIZE && j < 20; i++)
	{
		if (active(&(utmpshm->utc[i])) &&
			ApplyToLinkList(cmpfid, utmpshm->utc[i].userid))
		{
			if (++k >= topln)
			{
				curr = &ptr[j++];
				(void)memcpy(curr, &(utmpshm->utc[i]), size);
			}
		}
	}
	return j;
}

/*
 * �C�X�Ҧ��� friends, ���N��Ӫ� Friend();
 */
int	page_friend_list()
{
	FILE	*fp;
	char	genbuf[STRLEN],
		*nl;
	int	ret = 0,
		ans;

	changemode(FRIENDS);
	CreateLinkList();
	(void)sprintf(genbuf, PATH_OVERRIDE, cuser.userid, "override");
	if ((fp = fopen(genbuf, "r")) == NULL) 
	{
/*		clear();	*/
		move(1, 0);
		clrtobot();
		friend_title();
		move(4, 0);
		prints(NA, "�ثe�L�B�ͦC��, �Х� override �]�w");
		ret = -1;
	}
	else
	{
		while (fgets(genbuf, STRLEN, fp) != NULL) 
		{
			if (nl = (char *)strrchr(genbuf, '\n')) 
				*nl = '\0';
		    	AddLinkList(genbuf, strlen(genbuf));
		}
		(void)fclose(fp);
		(void)sprintf(genbuf, "TALK_%d", UTMP_SHMKEY);
		getkeep(genbuf, 1, YEA);

		ret = i_read(genbuf, friend_title, page_ent, page_cmd, '\0',
			sizeof(usinfo), friend_num_recs, friend_get_rec);
	}
	if (ret == -1)
	{
		ans = getans(6, 0, "���������W�W��C���Ҧ�(Y/N)? [y]: ", 'y');
		if (ans == 'n')
			return QUIT;
		userlist = 1;
		return REDOIREAD;
	}
	return ret;
}

void	page_list()
{
	int	ret = 0;

	do
	{
		ret = (userlist == 1 ? page_user_list() : page_friend_list());
	}
	while (ret == REDOIREAD);
	changemode(TMENU);
	move(2, 0);
	clrtoeol();
}

int	page_user()
{
	userlist = 1;
	page_list();
}

int	page_friend()
{
	userlist = 2;
	page_list();
}

/*
 * �����ܤ� login ���u�@����, �C�X�L�����A
 */
int	page_multi_select(uid, fcmd)
char	*uid;
one_key	*fcmd;
{
	char	genbuf[STRLEN];

	CreateLinkList();
	AddLinkList(uid, strlen(uid));
	(void)sprintf(genbuf, "TALK_%d", UTMP_SHMKEY);
	getkeep(genbuf, 1, YEA);
	i_read(genbuf, request_title, page_ent, fcmd, '\0',
		sizeof(usinfo), friend_num_recs, friend_get_rec);
	move(2, 0);
	clrtoeol();
	return QUIT;
}

/*
 * �s�� override �C�X�覡
 */
int	page_override()
{
}

/*** End of File ************************************************************/
