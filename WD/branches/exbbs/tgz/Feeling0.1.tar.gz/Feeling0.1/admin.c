/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    SccsId[] = "@(#)admin.c	2.1	12/24/95";
#endif

#include "bbs.h"

extern	int	t_lines,
		numboards;
extern	userec	muser,
		cuser;
extern	permin	permstr[],
		brdstr[];
extern	usint	setperms();
extern	int	cmpbname(),
		make_blist();

int	count_exper(info, dble)
userec	*info;
int	*dble;
{
	int	exper;

	*dble = VACATION + ((info->userlevel & PERM_TRUE) ? 1 : 0);
	exper = (info->numposts + (info->numlogins / 5)) * (*dble);

	return	exper;
}

int	clean_user(info)
userec	*info;
{
	time_t	now,
		idle,
		exper,
		history;
	int	dble;

	if (info->userid[0] == '\0' || info->userlevel & PERM_NOCLEAN)
		return NA;
	(void)time(&now);

	exper = (int)count_exper(info, &dble) + 1;
	history = (now - info->reg_date)/600;
	idle = (now - info->lastlogin)/86400;

	if (!strcasecmp(info->userid, "new") && history > 1)
		return -1;

	if ((now - info->reg_date)/86400 <= dble*15)
		return NA;

	if ((!(info->userlevel & PERM_TRUE) && (idle > dble*14)) ||
		(exper < 30 && (idle > exper*2 || idle > 30)) ||
		(exper < 60 && idle > 90) || (exper < 120 && idle > 120) ||
		(exper < 240 && idle > 150) || (exper >= 240 && idle > 180))
		return YEA;

	return NA;
}

int	del_unused()
{
	userec	info;
	int	id,
		cleaned = 0;
	char	reg_date[10],
		last[10],
		genbuf[STRLEN];

	for (id = 1; id <= MAXUSERS; id++)
	{
		if (get_record(PASSFILE, (char *)&info, sizeof(userec), id))
			return 0;
		if (clean_user(&info))
		{
			if (strcasecmp(info.userid, "new"))
			{
				++cleaned;
				sprintf(reg_date, "%6.6s",
					ctime(&info.reg_date) + 4);
				sprintf(last, "%6.6s",
					ctime(&info.lastlogin) + 4);
				logit(LOG_CLEAN,
					"%s, p:%3d, l:%3d, r:%6.6s, l:%6.6s",
					info.userid, info.numposts,
					info.numlogins, reg_date, last);
				sprintf(genbuf, PATH_USER, info.userid);
				if (!access(genbuf, R_OK))
				{
					sprintf(genbuf, PATH_DUSER, info.userid);
					system(genbuf);
				}
			}
			memset(&info, 0, sizeof(userec));
			substitute_passwd(PASSFILE, &info, YEA, id);
		}
	}
	return cleaned;
}

int	m_uclean()
{
	char	ans;

	ans = getans(2, 0, "�T�w�n�M���L�����ϥΪ��b���ܡH(Y/N) [N]:",'n');
	if (ans != 'y')
		return 0;
	move(2, 0);
	prints(NA, "�M���L�����ϥΪ��b����, �еy��..");
	refresh();
	move(2, 0);
	clrtoeol();
	prints(NA, "�`�@�M��: %d ��L�����ϥΪ�����", del_unused());
	return 0;
}

int	m_sortbrd()
{
	char	genbuf[160];

	sprintf(genbuf, "%s/bin/sort_board %s/.BOARDS %s/.BOARDS.BAK >> /dev/null",
		BBSHOME, BBSHOME, BBSHOME);
	system(genbuf);
	sprintf(genbuf, "/usr/bin/cp %s/.BOARDS.BAK %s/.BOARDS", BBSHOME, BBSHOME);
	system(genbuf);
	move(2, 0);
	prints(NA, "�Q�װϱƧǧ���");
	return 0;
}

int	cmpname(rlname, nbuf)
char	*rlname;
userec	*nbuf;
{
	return	!strcmp(rlname, nbuf->realname);
}

int	cmpemail(email, nbuf)
char	*email;
userec	*nbuf;
{
	return !strcmp(email, nbuf->email );
}

int	m_info()
{
	int	ans,
		id = 0;
	char	uidbuf[STRLEN],
		genbuf[STRLEN];
	userec	initial;

	changemode(MINFO);
	clear();
	prints(YEA, "��s���W USER ���");
	ans = getans(1, 0, "�п�� (1)�b�� (2)�Ǹ� (3)�m�W (4)E-mail (5)�^�W�h: [5]", '5');
	move(1, 0);
	clrtoeol();

	switch(ans)
	{
		case '1':
			move(1, 3);
			if (!(id = init_namelist(genbuf)))
				return 0;
			break;

		case '2':
			getdata(1, 0, "�ѧǸ���� ", uidbuf, 20, DOECHO,
				YEA);
			id = atoi(uidbuf);
			break;

		case '3':
			getdata(1, 0, "��J�u��m�W: ", uidbuf, 20, DOECHO,
				YEA);
			id = search_record(PASSFILE, (char *)&muser,
				sizeof(muser), cmpname, (int)uidbuf);
			break;

		case '4':
			getdata(1, 0, "��J E-mail address: ", uidbuf, STRLEN, DOECHO,
				YEA);
			id = search_record(PASSFILE, (char *)&muser,
				sizeof(muser), cmpemail, (int)uidbuf);
			break;

		default:
			break;
	}

	if (id > 0 && id <= MAXUSERS)
	{
		get_record(PASSFILE, (char *)&initial, sizeof(userec), id);
		modify_info(&initial, id, YEA);
	}
	changemode(MADMIN);
	clear();
    	return 0;
}

int	check_board_id(bname)
char	*bname;
{
	char	*c;

	for (c = bname; *c != '\0'; c++)
	{
		if ((*c < 0) || (*c > 125) ||
			!(isalnum(*c) || strchr("-_=+", *c)))
			return -1;
	}
	return 0;
}

int	edit_board(brd, create)
bhd	*brd;
int	create;
{
	char	genbuf[STRLEN],
		buf1[STRLEN], buf2[STRLEN];
	bhd	dh;
	int	ans,
		i;

	i = (create) ? 1 : 11;
	move(i++, 0);
	clrtoeol();

	for(;;)
	{
		getdata(i, 0, "�s�Q�װϦW: ", genbuf, 18, DOECHO, YEA);

		if (genbuf[0] == '\0')
		{
			if (create)
				return -1;
			else
				break;
		}

		if (search_board(&dh, genbuf, cmpbname) ||
			check_board_id(genbuf))
		{
			move(i+1, 0);
			prints(NA, "�Q�װϤw�g�s�b�Χt�����X�k���r��\n");
			bell(1);
			move(11, 0);
			clrtobot();
			continue;
		}

		if (create)
		{
			sprintf(buf1, "boards/%s", genbuf);
			mkdir(buf1, 0750);
		}
		else
		{
			sprintf(buf1, "boards/%s", brd->filename);
			sprintf(buf2, "boards/%s", genbuf);
			rename(buf1 , buf2);
		}
		strncpy(brd->filename, genbuf, sizeof(brd->filename));
		break;
	}

	if (create)
	{
		brd->flag = 0;
		brd->readlevel = 0;
		brd->postlevel = PERM_TRUE;
		time(&brd->flownum);
	}

	getdata(++i, 0, "�Q�װϥD�D�]�w: ", genbuf, 60, DOECHO, YEA);
	if (genbuf[0])
		strcpy(brd->title, genbuf);

	getdata(++i, 0, "�Ĥ@��O�N�z: ", genbuf, 60, DOECHO, YEA);
       	if (*genbuf != 0)
       	        strncpy(brd->mngs[0], genbuf, sizeof(brd->mngs[0]));
	if (genbuf[0] == ' ')
		memset(brd->mngs[0], 0, sizeof(brd->mngs[0]));

	getdata(++i, 0, "�ĤG��O�N�z: ", genbuf, 60, DOECHO, YEA);
	if (*genbuf != 0)
                strncpy(brd->mngs[1], genbuf, sizeof(brd->mngs[1]));
	if (genbuf[1] == ' ')
		memset(brd->mngs[1], 0, sizeof(brd->mngs[0]));

	getdata(++i, 0, "�ĤT��O�N�z: ", genbuf, 60, DOECHO, YEA);
	if (*genbuf != 0)
                strncpy(brd->mngs[2], genbuf, sizeof(brd->mngs[2])); 
	if (genbuf[2] == ' ')
		memset(brd->mngs[2], 0, sizeof(brd->mngs[0]));

	move(3, 0);
	prints(NA, "��� %s ���]�w\n", brd->filename);
	brd->flag = setperms(brd->flag, brdstr);

	move(3, 0);
	prints(NA, "��� %s �i�i�K�j�v��\n", brd->filename);
	brd->postlevel = setperms(brd->postlevel, permstr);

	move(3, 0);
	prints(NA, "��� %s �iŪ���j�v��\n", brd->filename);
	brd->readlevel = setperms(brd->readlevel, permstr);

	ans = gain_group();
	if (ans != 0)
		brd->group = ans;
	return 0;
}

int	Create()
{
	bhd	new;
	char	genbuf[STRLEN];
	int	ans = NA;

	clear();

	changemode(CREATE);
	memset(&new, 0, sizeof(bhd));
	prints(NA, "�W�]�Q�װ�:");

	if (edit_board(&new, YEA) == -1)
	{
		prints(NA, "\n���]�߰Q�װ�\n");
		changemode(MADMIN);
		pressreturn();
		return -1;
	}

	ans = getans(t_lines-2, 0, "�O�_���ߦ��Q�װ�(Y/N)? [Y]: ", 'y');
	if (ans == 'n')
	{
		sprintf(genbuf, PATH_DBOARD, new.filename);
		system(genbuf);
		prints(NA, "\n���]�߰Q�װ�\n");
		changemode(MADMIN);
		pressreturn();
		return -1;
	}

	if (append_record(BOARDS, (char *)&new, sizeof(new)) == -1)
	{
		changemode(MADMIN);
		pressreturn();
		clear();
		return -1;
	}

	numboards = -1;
	prints(NA, "\n�s�Q�װϤw�g�]�w����\n");
	logit(LOG_MODBRD, "%s create %s", cuser.userid, new.filename);
	pressreturn();
	changemode(MADMIN);
	clear();

	return 0;
}

int	m_editbrd()
{
	char	bname[STRLEN];
	int	pos,
		ans;
	bhd	fh,
		newfh;

	clear();
	prints(YEA, "Change Board Info");

	move(1, 0);
	name_query("��ܰQ�װ�: ", bname, make_blist);
	if (*bname == '\0')
	{
		move(2, 0);
		prints(NA, "Invalid Board Name");
		pressreturn();
		clear();
		return -1;
	}

	if (!(pos = search_board(&fh, bname, cmpbname)))
	{
		move(2, 0);
		prints(NA, "Invalid Board Name");
		pressreturn();
		clear();

		return -1;
	}

	move(3, 0);
	memcpy(&newfh, &fh, sizeof(bhd));
	prints(NA, "�Q�װϦW��: %s\n", fh.filename);
	prints(NA, "�Q�װϻ���: %s\n", fh.title);
	prints(NA, "���s�s��:   %d\n", fh.group);
        prints(NA, "�N�z�t�d�H: %-13s: %-13s: %-13s\n", fh.mngs[0],
		fh.mngs[1], fh.mngs[2]);

	ans = getans(9, 0, "�O�_���]�w? (Yes or No) [N]: ", 'n');

	if (ans == 'y')
		edit_board(&newfh, NA);
	else
		return -1;
	ans = getans(t_lines-2, 0, "�T�w���W�z�]�w(Y/N)? [Y]: ", 'y');
	if (ans != 'n')
	{
		if (switch_record(BOARDS, (char *)&newfh, sizeof(bhd), pos)
			== -1)
		{
			return -1;
		}
		numboards = -1;
	}
	clear();
	return 0;
}

int	m_ident()
{
	int	ans,
		id = 0;
	char	uidbuf[20],
		genbuf[STRLEN];

	changemode(MINFO);
	clear();
	prints(YEA, "��s���W USER ���");
	ans = getans(1, 0, "�п�� (1)�b�� (2)�Ǹ� (3)�m�W (4)�^�W�h: [4]", '4');
	move(1, 0);
	clrtoeol();

	switch(ans)
	{
		case '1':
			move(1, 3);
			if (!(id = init_namelist(genbuf)))
				return 0;
			break;

		case '2':
			getdata(1, 0, "�ѧǸ���� ", uidbuf, 20, DOECHO,
				YEA);
			id = atoi(uidbuf);
			break;

		case '3':
			getdata(1, 0, "��J�u��m�W: ", uidbuf, 20, DOECHO,
				YEA);
			id = search_record(PASSFILE, (char *)&muser,
				sizeof(muser), cmpname, (int)uidbuf);
			break;

		default:
			break;
	}

	if (id > 0 && id <= MAXUSERS)
	{
		get_record(PASSFILE, (char *)&muser, sizeof(userec), id);
		user_display(&muser, id);
		ans = getans(14, 0, "�]�w�q�L��������(Y/N): [N] ", 'n');
		if (ans == 'y')
		{
			switch_bit(&(muser.userlevel), PERM_TRUE);
			substitute_passwd(PASSFILE, &muser, YEA, id);
		}
		prints(NA, "��%s�� %s �q�L�����T�{\n", muser.userid,
			(muser.userlevel & PERM_TRUE) ? "�w�g" : "�|��");
		pressreturn();
 	}
	changemode(MADMIN);
	clear();
    	return 0;
}
