/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    sccsid[] = "@(#)editor.c	2.1	12/24/95";
#endif

#include <sys/types.h>
#include <stdio.h>
#include <setjmp.h>
#include "define.h"
#include "struct.h"

userec	cuser;
usinfo	uinfo;
jmp_buf byebye;
int	dumb_term;

void	bell(int i)
{
	(void)fprintf(stderr, "%c", 0x7);
}

void	goodbye()
{
	exit(0);
}

char	getans(x, y, prompt, def)
int	x,
	y,
	def;
char	*prompt;
{
	int	ch;

	ch = reply(x, y, prompt, NA);

	switch(ch)
	{
		case KEY_RIGHT:
		case ' ':
		case '\n':
		case '\r':
	   		ch = def;
			break;

		default:
			break;
	}
	prints(NA, "%c\n", ch);
	refresh();

	return tolower(ch);
}

void	abort_bbs()
{
	(void)fprintf(stderr, "fatal error has occured\n");
	reset_tty();
	exit(-1);
}

void	main(ac, av)
int	ac;
char	*av[];
{
	char	*term,
		*getenv();
	extern	int	dumb_term;    /* this comes in from term_init */
    
	uinfo.mode =0;
	cuser.userset |= SET_ANSIMODE;
	if (ac != 2)
	{
		(void)fprintf(stderr, "Usage: %s <filename>\n", av[0]);
		exit(-1);
	}

	get_tty();               /* get tty port mode settings */
	init_tty();              /* set up mode for NOECHO and RAW */

	if (setjmp(byebye))
	{
		(void)fprintf(stderr, "Goodbye\n");
		reset_tty();
		exit(-1);
	}

	term = getenv("TERM");   /* Get term type from unix environment */

	if (term == NULL)
	{
		(void)fprintf(stderr, "No Terminal environment type!\n");
		reset_tty();
		exit(-1);
	}

	/* Load up strings used to control terminal type 'term'*/
	(void)term_init(term);

	if (dumb_term)
	{
		(void)fprintf(stderr, "Terminal type cannot support editor\n");
		reset_tty();
		exit(-1);
	}
	initdsk();         /* Initialize screen interface */
	vedit_init();      /* Initialize editor */
	vedit(av[1], NA);   /* Start editor on file, do not save header */
	clear();           /* clear screen */
	redodsk();         /* make clear() happen */
	reset_tty();    

	exit(0);
}

int	write_header()
{
	/* nothing here */
}

int	pressreturn()
{
	move(23, 0);
	clrtoeol();
	prints(YEA, "[1;36;44m%s                            [m",
		"                             [<] �Ы����@���~�� [>]");
	refresh();
	igetkey();
	return 0;
}

int	switch_bit(byte, bit)
int	*byte,
	bit;
{
	if ((*byte)& bit )
		(*byte) &= ~bit;
	else
		(*byte) |= bit;
	return (*byte)& bit;
}
