/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    SccsId[] = "@(#)delete.c	2.1	12/24/95";
#endif

#include <string.h>
#include "bbs.h"

extern	char	genbuf[],
		currboard[];
extern	int	numboards;
extern	userec	cuser,
		muser;
extern	usinfo	uinfo;

extern	void	update_utmp();
extern	int	make_blist();

int	delusernum;

int	d_exit()
{
/* Mark by Seiya
	clear();
*/
	return QUIT;
}

int	boardcheck(fptr, genbuf)
bhd	*fptr;
char	*genbuf;
{
	return !strcmp(fptr->filename, genbuf);
}

int	d_board()
{
	bhd	binfo;
	int	bid, 
		ans;

	move(3, 0);
	clrtobot();
	move(0, 0);
	prints(YEA, "DELETE BOARD DELETE BOARD DELETE BOARD");
	clrtoeol();
	move(1, 0);
	name_query("��J�n�Q�R�����O�W: ", genbuf, make_blist);
	bid = getbnum(genbuf);

	if (get_record(BOARDS, (char *)&binfo, sizeof(binfo), bid) == -1)
	{
		move(2, 0);
		prints(NA, "Invalid Board Name\n");
		pressreturn();
		clear();

		return 0;
	}

	move(1, 0);
	prints(NA, "Delete board '%s'.", binfo.filename);
	clrtoeol();

	ans = getans(2, 0, "(Yes, or No) [N]: ", 'n');

	if (ans != 'y')
	{
		move(2, 0);
		prints(NA, "Quitting delete board\n");
		pressreturn();
		clear();
		return 0;
	}

	if (!isalpha(binfo.filename[0]))
		return -1;

	(void)sprintf(genbuf, "/bin/rm -fr boards/%s", binfo.filename);
	(void)system(genbuf);
	delete_file(BOARDS, sizeof(binfo), bid, boardcheck, binfo.filename);
	move(2, 0);
        numboards = -1;
	logit(LOG_MODBRD, "%s delete %s", cuser.userid, binfo.filename);
	prints(NA, "Board Deleted\n");
	pressreturn();
	clear();

	return 0;
}

int	delete_range(filename, id1, id2)
char	*filename;
int	id1,
	id2;
{
	int	fd,
		fdr,
		fdw,
		count;
	char	gb[STRLEN],
		lock[STRLEN],
		tmp[STRLEN],
		*t,
		del[STRLEN],
		dir[STRLEN];
	fhd	fhdr;

        (void)strcpy(dir, filename);
        if (t = strrchr(dir, '/'))
		*t = '\0';
	(void)sprintf(lock, "%s/%s", dir, ".dellock");
	(void)sprintf(tmp, "%s/%s", dir, ".tmpfile");
	(void)sprintf(del, "%s/%s", dir, ".deleted");

	if ((fd = open(lock, O_RDWR|O_CREAT|O_APPEND, 0644)) == -1)
		return -1;
	(void)flock(fd, LOCK_EX);

	if ((fdr = open(filename, O_RDONLY, 0)) == -1)
	{
		(void)flock(fd, LOCK_UN);
		(void)close(fd);
		return -1;
	}

	if ((fdw = open(tmp, O_WRONLY|O_CREAT|O_EXCL, 0644)) == -1)
	{
		(void)flock(fd, LOCK_UN);
		(void)close(fd);
		(void)close(fdr);
		return -1;
	}
	count = 1;

	while (read(fdr, &fhdr, sizeof fhdr) == sizeof(fhdr))
	{
		if (count < id1 || count > id2 || fhdr.flag & FILE_MARKED)
		{
			if ((safewrite(fdw, (char *)&fhdr, sizeof fhdr) == -1))
			{
				(void)unlink(tmp);
				(void)close(fdr);
				(void)close(fdw);
				(void)flock(fd, LOCK_UN);
				(void)close(fd);
				return -1;
			}
		}
		else
		{
			char	buf[256];

			(void)strcpy(buf, filename);
			if (t = strrchr(buf, '/'))
				*t = '\0';
			(void)sprintf(gb, "%s/%s", buf, fhdr.filename);
			(void)unlink(gb);
		}
		count++;
	}

	(void)close(fdr);
	(void)close(fdw);
	(void)flock(fd, LOCK_UN);
	(void)close(fd);

	if (rename(filename, del) == -1)
		return -1;

	if (rename(tmp, filename) == -1)
		return -1;

	(void)unlink(del);
	(void)unlink(lock);

	return 0;
}

int	d_user()
{
	int	id, 
		ans;
	
	clear();
	prints(YEA, "DELETE USER DELETE USER DELETE USER");
        ans = getans(1, 0, "�п�� (1) �H Login ID (2) �H UserNum (3) �^�W�h: [3] ", 
                '3');
        move(1, 0);   
        clrtoeol();  
        switch (ans)
	{
		case '1':
			move(1, 3);
			if (!(id = init_namelist(genbuf)))
				return 0;
			break;
		case '2':
		        getdata(1, 0, "Input Usernum: ", genbuf, STRLEN, DOECHO, 
				YEA);
			id = atoi(genbuf);
        		break;
		default:
			return 0;
        }

	get_record(PASSFILE, (char *)&muser, sizeof(muser), id);
	delusernum = id;
	move(1, 0);
	prints(NA, "Delete User '%s'.", muser.userid);
	clrtoeol();

	ans = getans(2, 0, "(Yes, or No) [N]: ", 'n');
	if (ans != 'y')
	{
		move(2, 0);
		prints(NA, "Aborting delete User\n");
		pressreturn();
		clear();
		return 0;
	}
	(void)sprintf(genbuf, PATH_USER, muser.userid);
	if (!access(genbuf, R_OK))
	{
		(void)sprintf(genbuf, PATH_DUSER, muser.userid);
		if (genbuf[strlen(genbuf)-1] != '/')
			(void)system(genbuf);
	}

	update_utmp();
	logit(LOG_OFFLINE, "%s delete %s", cuser.userid, muser.userid);
	(void)memset(&muser, 0, sizeof(muser));
	substitute_passwd(PASSFILE, &muser, YEA, id);

	move(2, 0);
	prints(NA, "User Deleted\n");
	resolve_ucache(1);
	pressreturn();
	clear();
	return 0;
}
