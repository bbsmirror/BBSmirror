/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    SccsId[] = "@(#)record.c	2.1	12/24/95";
#endif

#include "bbs.h"

#ifdef SYSV
#include <sys/ipc.h>
#include <sys/sem.h>

int	semid;

int	get_semaphore()
{
	if ((semid = semget(SEM_KEY, 1, 600)) == -1)
	{
		if ((semid = semget(SEM_KEY, 1, 600 | IPC_CREAT)) == -1)
			return -1;

		semctl(semid, 0, SETVAL, 1);
	}

	return 0;
}

int	flock(fd, op)
int	fd,
	op;
{
	struct	sembuf	sops;

	sops.sem_num = 0;
	sops.sem_flg = SEM_UNDO;

	switch (op)
	{
		case LOCK_EX:
			sops.sem_op = -1;
			break;
		case LOCK_UN:
			sops.sem_op = 1;
			break;
		default:
			return -1;
	}
	semop(semid, &sops, 1);

	return 0;
}
#endif

#ifdef POSTBUG
int	numtowrite,
	bug_possible = 0;
char	*bigbuf;

void	saverecords(filename, size, pos)
char	*filename;
int	size,
	pos;
{
	int	fd;

	if (!bug_possible)
		return 0;

	if ((fd = open(filename, O_RDONLY)) == -1)
		return -1;

	numtowrite = (pos > 5)? 5 : 4;
	(void)lseek(fd, (pos-numtowrite-1)*size, L_SET);
	bigbuf = (char *)malloc(size * numtowrite);
	read(fd, bigbuf, numtowrite*size);
}

int	restorerecords(filename, size, pos)
char	*filename;
int	size,
	pos;
{
	int	fd;

	if (!bug_possible)
		return 0;
	if ((fd = open(filename, O_WRONLY)) == -1)
		return -1;
	(void)flock(fd, LOCK_EX);
	(void)lseek(fd, (pos - numtowrite - 1) * size, L_SET);
	safewrite(fd, (char *)bigbuf, numtowrite * size);
	(void)flock(fd, LOCK_UN);
	free(bigbuf);
	(void)close(fd);
}
#endif

int	safewrite(fd, buf, size)
int	fd;
char	*buf;
int	size;
{
	int	cc,
		sz = size,
		origsz = size;
	char	*bp = buf;

	do
	{
		cc = write(fd, bp, sz);
		if ((cc < 0) && (errno != EINTR))
		{
			return -1;
		}
		if (cc > 0)
		{
			bp += cc;
			sz -= cc;
		}
	}
	while (sz > 0);

	return origsz;
}

int	get_num_records(filename, size)
char	*filename;
int	size;
{
	struct	stat	st;

	if (stat(filename, &st) == -1)
		return 0;

	return (st.st_size/size);
}

int	append_record(filename, record, size)
char	*filename,
	*record;
int	size;
{
	int	fd;

#ifdef POSTBUG
	int numrecs = (int)get_num_records(filename, size);
	bug_possible = 1;
	if (size == sizeof(fhd) && numrecs && (numrecs % 4 == 0))
		saverecords(filename, size, numrecs+1);
#endif

	if ((fd = open(filename, O_WRONLY|O_CREAT, 0644)) == -1)
	{
		perror("open");
		return -1;
	}

	(void)flock(fd, LOCK_EX);
	(void)lseek(fd, 0, L_XTND);
	if (safewrite(fd, record, size) == -1);
	(void)flock(fd, LOCK_UN);
	(void)close(fd);
#ifdef POSTBUG
        if (size == sizeof(fhd) && numrecs && (numrecs % 4 == 0))
		restorerecords(filename, size, numrecs+1);
	bug_possible = 0;
#endif
	return 0;
}

int	apply_record(filename, fptr, size)
char	*filename;
int	(*fptr)();
int	size;
{
	char	*abuf;
	int	fd;

	if ((fd = open(filename, O_RDONLY, 0)) == -1)
		return -1;

	abuf = (char *)malloc(size);
	while (read(fd, abuf, size) == size)
	{
		if ((*fptr)(abuf) == QUIT)
		{
			(void)close(fd);
			free(abuf);
			return QUIT;
		}
	}
	(void)close(fd);
	free(abuf);
	return 0;
}

int	search_record(filename, rptr, size, fptr, farg)
char	*filename,
	*rptr;
int	size,
	farg,
	(*fptr)();
{
	int	fd,
		id = 1;

	if ((fd = open(filename, O_RDONLY, 0)) == -1)
		return 0;

	while (read(fd, rptr, size) == size)
	{
		if ((*fptr)(farg, rptr))
		{
			(void)close(fd);
			return id;
		}
		id++;
	}
	(void)close(fd);
	return 0;
}

int	get_record(filename, rptr, size, id)
char	*filename,
	*rptr;
int	size,
	id;
{
	int	fd;

	if (*filename == '\0')
		return -1;

	if ((fd = open(filename, O_RDONLY, 0)) == -1)
		return -1;

	if (lseek(fd, size*(id-1), L_SET) == -1)
	{
		(void)close(fd);
		return -1;
	}
	if (read(fd, rptr, size) != size)
	{
		(void)close(fd);
		return -1;
	}
	(void)close(fd);

	return 0;
}

int	get_records(filename, rptr, size, id, number)
char	*filename,
	*rptr;
int	size,
	id,
	number;
{
	int	fd,
		n;

	if (*filename == '\0')
		return -1;

	if ((fd = open(filename, O_RDONLY, 0)) == -1)
		return -1;

	if (lseek(fd, size*(id-1), L_SET) == -1)
	{
		(void)close(fd);
		return 0;
	}

	if ((n = read(fd, rptr, size*number)) == -1)
	{
		(void)close(fd);
		return -1;
	}
	(void)close(fd);
	return (n/size);
}

int	switch_record(filename, rptr, size, id)
char	*filename,
	*rptr;
int	size,
	id;
{
	int	fd;

#ifdef POSTBUG
	if (size == sizeof(fhd) && (id > 1) && ((id - 1) % 4 == 0))
		saverecords(filename, size, id);
#endif
	if ((fd = open(filename, O_WRONLY|O_CREAT, 0644)) == -1)
		return -1;

	(void)flock(fd, LOCK_EX);

	if (lseek(fd, size*(id-1), L_SET) == -1);

	if (safewrite(fd, rptr, size) != size);

	(void)flock(fd, LOCK_UN);
	(void)close(fd);

#ifdef POSTBUG
	if (size == sizeof(fhd) && (id > 1) && ((id - 1) % 4 == 0))
		restorerecords(filename, size, id);
#endif
	return 0;
}

int	delete_record(filename, size, id)
char	*filename;
int	size,
	id;
{
	int	fdr,
		fdw,
		fd,
		count;
	char	*gb;

	if ((fd = open(".dellock", O_RDWR|O_CREAT|O_APPEND, 0644)) == -1)
		return -1;
	(void)flock(fd, LOCK_EX);

	if ((fdr = open(filename, O_RDONLY, 0)) == -1)
	{
		(void)flock(fd, LOCK_UN);
		(void)close(fd);

		return -1;
	}
	if ((fdw = open(".tmpfile", O_WRONLY|O_CREAT|O_EXCL, 0644)) == -1)
	{
		(void)flock(fd, LOCK_UN);
		(void)close(fd);
		(void)close(fdr);

		return -1;
	}
	count = 1;
	gb = (char *)malloc(size);
	while (read(fdr, gb, size) == size)
	{
		if (id != count++ && (safewrite(fdw, gb, size) == -1))
		{
			(void)unlink(".tmpfile");
			(void)close(fdr);
			(void)close(fdw);
			(void)flock(fd, LOCK_UN);
			(void)close(fd);
			free(gb);
			return -1;
		}
	}

	(void)close(fdr);
	(void)close(fdw);

	if (rename(filename, ".deleted") == -1)
	{
		(void)flock(fd, LOCK_UN);
		(void)close(fd);
		free(gb);
		return -1;
	}
	if (rename(".tmpfile", filename) == -1)
	{
		(void)flock(fd, LOCK_UN);
		(void)close(fd);
		free(gb);
		return -1;
	}
	(void)flock(fd, LOCK_UN);
	(void)close(fd);
	free(gb);
	return 0;
}

int	delete_file(dirname, size, ent, filecheck, buf)
char	*dirname,
	*buf;
int	size,
	ent,
	(*filecheck)();
{
	int	fd;
	struct	stat	st;
	long	numents;
	char	*abuf;
	extern	char	genbuf[];

	if ((fd = open(dirname, O_RDWR)) == -1)
		return -1;

	(void)flock(fd, LOCK_EX);
	(void)fstat(fd, &st);
	numents = ((long)st.st_size)/size;

	if (((long)st.st_size) % size != 0)
		(void)fprintf(stderr, "Irregular File Size, Truncating\n");

	abuf = (char *)malloc(size);
	if (lseek(fd, size*(ent-1), L_SET) != -1)
	{
		if (read(fd, abuf, size) == size)
		{
			if ((*filecheck)(abuf, buf))
			{
				int i;

				for(i = ent; i < numents; i++)
				{
					if (lseek(fd, i*size, L_SET) == -1)
						break;
					if (read(fd, abuf, size) != size)
						break;
					if (lseek(fd, (i-1)*size, L_SET) == -1)
						break;
					if (safewrite(fd, abuf, size) != size)
						break;
				}
				(void)ftruncate(fd, size*(numents-1));
				(void)flock(fd, LOCK_UN);
				(void)close(fd);
				free(abuf);
				return 0;
			}
		}
	}

	(void)lseek(fd, 0, L_SET);
	ent = 1;

	while (read(fd, abuf, size) == size)
	{
		if ((*filecheck)(abuf, buf))
		{
			int i;
			for(i = ent; i < numents; i++)
			{
				if (lseek(fd, (i+1)*size, L_SET) == -1)
					break;
				if (read(fd, abuf, size) != size)
					break;
				if (lseek(fd, (i)*size, L_SET) == -1)
					break;
				if (safewrite(fd, abuf, size) != size)
					break;
			}
			(void)ftruncate(fd, size*(numents-1));
			(void)flock(fd, LOCK_UN);
			(void)close(fd);
			free(abuf);
			return 0;
		}
		ent++;
	}
	(void)flock(fd, LOCK_UN);
	(void)close(fd);
	free(abuf);
	return -1;
}
