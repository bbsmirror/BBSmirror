/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw
			   ���崼, Alen@music.nsysu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    SccsId[] = "@(#)chat.c	1.12	10/19/95";
#endif
#include "command.h"
#include "bbs.h"
#include "common.h"

extern	userec	cuser;
extern	usinfo	uinfo;
extern  UTCACHE  *utmpshm;
extern	int	t_lines,
		dumb_term,
		talkrequest,
		active;
extern	char	BoardName[];

extern	void	update_utmp();

static	char 	inbuf[STRLEN];
char	*msgto,
	sendbuf[STRLEN + 40],
	chatid[STRLEN],
	roomname[20];

int	chatroom,
	chatline,
	echatwin,
	newmail = 0,
	debug = 0;

#ifdef REALINFO
int	chat_real_names = 0;
#endif

void	printchatmsg()
{
	prints(NA, "======= [%20.20s] === [%10.10s] === %18.18s =========",
				BoardName,roomname,
		(newmail) ? "[�z���s�H��Ū��]" : "use /help for help");
}

void	printchatline(std, va_alist)
int	std;
va_dcl
{
        va_list args;
        char    buff[240],
                *fmt;

        va_start(args);
        fmt = va_arg(args, char *);
        (void)vsprintf(buff, fmt, args); 
        va_end(args);

	(void)strcat(buff, "\n");
        move(chatline++,0);
        clrtoeol();
	if (std)
		standout();
	outs(buff);
	if (std)
		standend();

	if (chatline == echatwin)
	{
/*		if (HAS_SET(SET_CHATSCROLL))
		{
			move(echatwin+1,0);
			printchatmsg();
			scroll();
			outs(inbuf);
			
			chatline--;
		}
		else */
			chatline = 0;
	}
        move(chatline,0);
        clrtoeol();

        if (!dumb_term)
		outs("-->");

	return ;
}

int	show_help(p)
permin	*p;
{
	while(**p)
	{
		printchatline(NA, "%s", p++);
	}		
	return 1;
}


int do_mudhelp()
{
	permin	mudhelp[]=
{	
 "                      <<  ��     �@     ��  >>",
 "  �y�k://�ʧ@�W��+���W��  �p: //kiss ET",
 " kick   �}��   nod       �I�Y   bless   ����   laugh   �j��   hug   ����",
 " kiss   �˧k   bearhug   ����   bow     ���`   caress  ���N   clap  ���x",
 " zap    ����   comfort   ����   cry     ���_   curtsy  �U��   dance ���R",
 " giggle �̯�   glare     ���   grin    �S��   growl   �H�S   jab   �W��",
 " nibble ���r   handshake ����   nudge   ���y   pinch   ����   punch �~��",
 " shrug  �q��   massage   ����   sigh    �ۮ�   slap    �x�Q   smooch�֧k",
 " squeeze���   snicker   �ѯ�   tickle  ���o   wave    �n��   wink  �w��",
NULL
};
return(show_help(mudhelp));

}






int	do_help()
{
	permin	chathelp[] = 
{
        " [1;33m  [�@��ϥλ���][0m",
        "  //                     - MUD-link ����ʵ�                ",
        "  /[a]dvance             - �i���D�U                         ",
        "  /[w]ho                 - �ݬݦ��֦b�a                     ",
        "  /whos <channel>        - �C�X�Y��ѫǪ��H               ",
        "  /[q]uery <ID>          - �d�ߺ���                         ",
        "  /[m]sg <nick><text>    - ��������                         ",
        "  /[p]ager               - �����I�s��                       ",
/*        "  /[t]opic <text>        - �󴫥D�D                         ", */
        "  /me <action>           - ���@�Ӱʧ@                       ",
        "  /[n]ick <name>         - ����ѥN��                     ",
        "  /[c]lear               - �M�M�ù�                         ",
/*      "  /[d]ate                - �ݤ��                           ",  */
        "  /[e]xit (CTRL-d)       - �^�a��ı                         ",
/*      "  /[k]ick <nick>         - ���a�H (�Ѥj�M��)                ",  */
        "  /[l]ist                - �C�X�u�W�Ҧ� chat room           ",
        "  /[j]oin <room>         - �}�ж��ζi�J�ж�                 ",
/*      "  /[i]nvite <nick>       - �ܽФH�a�[�J�A                   ",
        "  /[b]an  <nick>         - �T��Y�H�i�J                     ",
        "  /[s]et [+|-][P|S|T]    - �M�w���ΩΨp�H�֦�               ",
        "============================================================", */




	NULL
};	


	return (show_help(chathelp));
}

int     do_adv_hlp()   
{
	permin	advhlp[] = {

        "  [�ͤѫǺ޲z���M�λ���] ",
        "  /[s]et  +/-[pst]    - �M�w���ΩΨp�H�֦� �p:/s +p �p�H   ",
        "  /oper  <nick>       - ��Ѥj�v�����Y�H (�Ѥj�M��)        ",
        "  /[i]nvite <nick>    - �ܽ� <id> �[�J�ͤѫ�               ",
        "  /[b]an  <nick>      - �T��Y�H�i�J                     ",
        "  /[k]ick <nick>      - ���a�H (�Ѥj�M��)                ",
        "  /[t]opic <text>     - �󴫥D�D                         ",
/*      "  /rmop               - ��O�H���޲z�v������               ",  */
        "  /ignore <nick>      - �����Y�H���T��                     ",
        "  /lign               - �C�X�Ҧ��Q������                   ",
        "  /rmign <nick>       - �N�Y�H�q�����W�椤���h             ",
        "  /linv               - �C�X�ܽЦW��                       ",
        "  /rminv <nick>       - �N�Y�H�q�n�ЦW�椤���h             ",
        "  /lban               - �C�X�Ҧ��Q�T��i�J���W��           ",
        "  /rmban <nick>       - �N�Y�H�q���T��W�椤���h           ",
        "  /cloak              - �����N,���n���v��                  ",
/*      "============================================================", */



	NULL
};	
	return (show_help(advhlp));

}
int	dochatcommand(cmd, fd)
char	*cmd;
int 	fd;
{
	char	*endcmd;
	int	retval = 0,
		cmdlen;

	while (*cmd == ' ')
		cmd++;

	endcmd = cmd;

	while (*endcmd != ' ' && *endcmd != '\n' && *endcmd)
		endcmd++;

	if (*endcmd == '\0')
		*(endcmd+1) = '\0';
	else
		*endcmd = '\0';

	cmdlen = strlen(cmd);

         if(cmd[0]=='/')
         {
         char *temp=endcmd+1;  
         char buf2[80];
	sprintf(buf2,"%s %s",cmd,temp);         
        
/*        (void)strcat(cmd," ");
        (void)strcat(cmd,temp);   */
/*         printf(" cmd2=%s\n",buf2);  */
        
        
        if(cmd[1]=='\0')
        {
/*        clear();
		move(echatwin,0);
		printchatmsg(); */
		retval = do_mudhelp();
	} 
        else {
         send_to_server(MSG_ACT, fd, buf2+1,YEA);
	   retval = 1;
	   }
	   }
	   



        if (!strncmpi(cmd, "help",cmdlen))
	{
		retval = do_help();
        }
        if (!strncmpi(cmd, "advance",cmdlen))
	{
		retval = do_adv_hlp();
        }
	else if (!strncmpi(cmd, "list",cmdlen))
	{
		retval = send_to_server(MSG_ROOM_LST, fd, endcmd+1, NA);
	}
        else if (!strncmpi(cmd, "query",cmdlen))
	{
		retval = do_query(endcmd+1);
        }
	else if (!strncmpi(cmd, "topic", cmdlen))
	{
		retval = send_to_server(MSG_TOPIC , fd, endcmd+1,
			(*(endcmd+1) ? YEA : NA));
	}
	else if (!strncmpi(cmd, "oper", cmdlen))
	{
		retval = send_to_server(MSG_OPER, fd , endcmd+1,YEA);
	}
	else if (!strncmpi(cmd, "invite", cmdlen))
	{
		retval = send_to_server(MSG_INV , fd , endcmd+1,YEA);
	}
	else if (!strncmpi(cmd, "ban", cmdlen))
	{
		retval = send_to_server(MSG_BAN , fd, endcmd+1,YEA);
	}

	else if (!strncmpi(cmd, "set", cmdlen))
	{
		retval = send_to_server(MSG_SET_ROOM,fd,endcmd+1,YEA);
	}
	else if (!strncmpi(cmd, "ignore",cmdlen))
	{
		retval = send_to_server(MSG_IGNORE,fd , endcmd+1,YEA);
	}
        else if (!strncmpi(cmd, "lign",cmdlen))
	{
                retval = send_to_server(MSG_LST_IGN,fd , endcmd+1,NA);
        }
        else if (!strncmpi(cmd, "rmign",cmdlen))
	{
                retval = send_to_server(MSG_RM_IGN,fd , endcmd+1,YEA);
        }
	else if (!strncmpi(cmd, "join",cmdlen))
	{
		retval = send_to_server(MSG_JOIN, fd, endcmd+1 , YEA);
	}
        else if (!strncmpi(cmd, "lban",cmdlen))
	{
                retval = send_to_server(MSG_LST_BAN, fd, endcmd+1, NA);
	}
        else if (!strncmpi(cmd, "linv",cmdlen))
	{
                retval = send_to_server(MSG_LST_INV, fd, endcmd+1, NA);
	}
        else if (!strncmpi(cmd, "rminv",cmdlen))
	{
                retval = send_to_server(MSG_RM_INV, fd, endcmd+1, YEA);
        }
        else if (!strncmpi(cmd, "rmban",cmdlen))
	{
                retval = send_to_server(MSG_RM_BAN, fd, endcmd+1, YEA);
        }
        else if (!strncmpi(cmd, "who", cmdlen))
	{
		retval = send_to_server(MSG_WHO,  fd, endcmd+1, NA);
	}
        else if (!strncmpi(cmd, "whos", cmdlen))
	{
		if (*(endcmd+1) == '\0')
			strcpy(endcmd+1, roomname);
		retval = send_to_server(MSG_WHOS,  fd, endcmd+1, YEA);
	}
        else if (!strncmpi(cmd, "msg", cmdlen))
	{
		retval = domsg(endcmd+1, fd);	
	}
	else if (!strncmpi(cmd, "kick", cmdlen))
	{
		retval = send_to_server(MSG_KICK, fd, endcmd+1, YEA);
	}
        else if (!strncmpi(cmd, "nick", cmdlen))
	{
		send_to_server(MSG_NICK, fd, endcmd+1, YEA);
		retval = 1;
	}
        else if (!strncmpi(cmd, "pager",cmdlen))
	{
		if (HAS_PERM(PERM_BASIC))
		{
			t_pager();
	        	printchatline(NA, " ");
	        	if (!uinfo.pager) 
	        		printchatline(NA, "[44;1m==> �z���I�s���w���� [m");
			else
				printchatline(NA, "[44;1m==> �z���I�s���w�}�� [m");
		} else
			printchatline(NA, "[41;1m*** �ШϥΥ��T�����O ***[m");
        }
	else if (!strncmpi(cmd, "me", cmdlen))
	{
		char	*firstlet = endcmd + 1;

		while (*firstlet == ' ' || *firstlet == '\n' ||
			*firstlet == '\t')
			firstlet++;

		if (*firstlet != '\0')
		{
			sprintf(sendbuf, "%2d:%s %s",MSG_PUB, uinfo.ptcb,
				endcmd+1);
			send(fd, sendbuf, strlen(sendbuf)+1,0);
		}
		else
			printchatline(NA, "[41;1m*** ���~: �ʧ@������ ***[m");
	}
	else if (!strncmpi(cmd, "clear", cmdlen))
	{
		clear();
		move(echatwin,0);
		printchatmsg();
		chatline = 0;
		printchatline(NA, "  "); 
	}
		else if (!strncmpi(cmd, "cloak",cmdlen))
	{
		retval = send_to_server(MSG_DO_CLO, fd,endcmd+1,NA);
	}                                        
	else if (!strncmpi(cmd,"date", cmdlen))
	{
		time_t	thetime;

		(void)time(&thetime);

		printchatline(NA, "*** �ثe������P�ɶ��O: %s",Ctime(&thetime));
	}
	else if (!strncmpi(cmd,"exit",cmdlen))
	{
		sprintf(sendbuf,"%2d:NONE",MSG_QUIT);
		send(fd,sendbuf,strlen(sendbuf),0);
		retval = -1;
	}	
	else if (!strncmpi(cmd,"user",cmdlen))
	{
	    active;
	    
	   /* apply_chat_ulist(active); */
	}
		
	return retval;
}

int	t_chat()
{
	char 	hostname[STRLEN],
		lastcmd[MAXLASTCMD][80],
		chatstr[80],
		*colon;
	struct	hostent	*h;
	struct	sockaddr_in	sin;
	int	a,
		ch,
		i,
		currchar,
		chatport,
		pline,
		page_pending = NA,
		cmdpos=0;

	newmail = 0;
	memset(inbuf, 0, sizeof(inbuf));

	chatline = currchar = 0;
	clear();
	more(CHATWELCOME,YEA);
	clear();

	move(2,0);
	prints(NA, "<�п�J�z�Q�ϥΪ��O��(�̦h�K�Ӧr��)>\n");
	getdata(1, 0, "Enter Chat id: ", chatid, 9, DOECHO, YEA);
	if (chatid[0] == '\0' || chatid[0] == '/'|| chatid[0]==' ')
		strcpy(chatid, cuser.userid);
	chatid[8] = '\0';
	(void)strcat(chatid, ":           ");
	chatid[10] = '\0';

       	for(i = 0; i <= MAXLASTCMD; i++)
               	sprintf(lastcmd[i], "%s%i", chatid, i);

	strcpy(inbuf, chatid);
	gethostname(hostname, STRLEN);

	if (!(h = gethostbyname(hostname)))
	{
		perror("gethostbyname");
		return -1;
	}

	memset(&sin, 0, sizeof sin);
	sin.sin_family = h->h_addrtype;
	memcpy(&sin.sin_addr, h->h_addr, h->h_length);

	switch(chatroom)
	{
		case 1:
			chatport = CHATPORT1;
			break;
		case 2:
			chatport = CHATPORT2;
			break;
		case 3:
			chatport = CHATPORT3;
			break;
		case 4:
			chatport = CHATPORT4;
			break;
	}

	sin.sin_port = chatport;
	a = socket(sin.sin_family, SOCK_STREAM, 0); 

	if ((connect(a, (struct sockaddr *)&sin, sizeof sin)))
	{
		move(2,0);
		prints(NA, "�}�Ҳ�ѫ�\n");
		refresh();
		close(a);
		sprintf(chatstr, "%s %d",CHATD_PATH,chatroom);
		system(chatstr);

		sleep(2);
		a = socket(sin.sin_family, SOCK_STREAM, 0); 

		if ((connect(a, (struct sockaddr *)&sin, sizeof sin)))
		{

			perror("connect failed");
			return -1;
		}
	}
	switch(chatroom)
	{
		case 1:
			uinfo.mode = CHAT1;
			break;
		case 2:
			uinfo.mode = CHAT2;
			break;
		case 3:
			uinfo.mode = CHAT3;
			break;
		case 4:
			uinfo.mode = BMCHAT;
			break;
	}
	strncpy(uinfo.ptcb, chatid, 10);
        if (colon = strrchr(uinfo.ptcb, ':'))
		*colon = '\0';
	update_utmp();
	strcpy(roomname , "ROOT");	

        sprintf(sendbuf, "%2d:%d:%d:%d:%s:%s", MSG_NEW_USER, getpid(),
		cuser.userlevel, cuser.userset, cuser.userid, chatid);

	send(a,sendbuf,strlen(sendbuf)+1,0);

	clear();
	printchatline(NA, "  ");

	strcpy(inbuf,chatid);
	pline = t_lines - 1;
	echatwin = t_lines - 2;
	move(echatwin,0);
	printchatmsg();
	move(pline,0);

	if (!dumb_term)
		prints(NA, "%s",inbuf);
	currchar = strlen(inbuf);
	add_io(a,0);

	while (ch = igetkey())
	{
               	switch(ch)
		{
                        case KEY_UP:
			case KEY_DOWN:
			/*        ���\��w����  */
			        continue;
                        /*      strcpy(inbuf, lastcmd[0]);
                               	cmdpos = (cmdpos + ((ch == KEY_UP) ? 1 : -1)
					+ MAXLASTCMD) % MAXLASTCMD;
                      		if (cmdpos < 0)
				cmdpos = 1;
				move(pline, 0);
                               	clrtoeol();
                               	if (!dumb_term)
                               		prints(NA, "%s", lastcmd[cmdpos]);
                               	strcpy(inbuf, lastcmd[cmdpos]);
                               	currchar = strlen(inbuf);
                               	continue;                             */
                       	case KEY_LEFT:
				if (currchar!=10)
                                       	move(pline, --currchar);
                       		continue;
                       	case KEY_RIGHT:
				if (inbuf[currchar])
                                       	move(pline, ++currchar);
                               	continue;
                       	default:
				break;
            	}

		if (talkrequest)
			page_pending = YEA;

		if (page_pending)
			page_pending = servicepage(0, NULL);

		if (newmail = chkmails(cuser,NA))
		{
			move(echatwin,0);
			printchatmsg();
		}

		if (ch == I_OTHERDATA)
		{
			static int cnt  = 0;
			int cc;
			static char buf[512];

			memset(buf, 0, sizeof(buf));
			if ((cc = recv(a, buf+cnt, sizeof buf, 0)) > 0)
			{
				int 	processed = 0,
					ret;

				while (cc > 0)
				{
					for(i=processed;buf[i] != '\0' &&
						i != sizeof buf;i++);

					if (i == sizeof buf && buf[i] != '\0')
					{
						memcpy(buf, buf + processed,
							processed-sizeof(buf));
						cnt = processed - sizeof(buf);
						break;
					}
					cnt = 0;

					ret = proc_server_cmd(buf + processed);

					if (ret == CHG_NICK)
					{
						move(pline, 0);
						strcpy(inbuf, chatid);
						if (!dumb_term)
							prints(NA, "%s", inbuf);
						currchar = strlen(inbuf);
					}
					else if (ret == CHG_ROOM)
					{
				                clear();
        				        move(echatwin,0);
        				        printchatmsg();
        				        chatline = 0;
        				        printchatline(NA, "  ");
						move(echatwin,0);
						printchatmsg();
						move(pline,0);
					        if (!dumb_term)
        					        prints(NA, "%s",inbuf);
      						  currchar = strlen(inbuf);
					}	

					i++;
					cc -= (i - processed);
					processed = i;

					if (i == sizeof buf)
						break;
				}
			}
			else
			{
				sprintf(buf, "%s %d, errno = %d\n",
					"CHAT FAILURE: read returned", cc,
					errno);
				break;
			}
/* mark */
                        move(pline,currchar);
			continue;
		}

		if (ISPRINT(ch))
		{
	                if (currchar == 78)
			{
                		bell(1);
                		continue;
                	}
                	if (!inbuf[currchar])
			{
                		inbuf[currchar+1] = '\0';
                		inbuf[currchar] = ch;
                	}	
               		else
			{
                		int	j;

        			for(i = currchar; inbuf[i]; i++);
					inbuf[i+1] = '\0';
        	        	for(j = i; j > currchar; j--)
				inbuf[j] = inbuf[j-1];
        	        	inbuf[j] = ch;
                	}
                	currchar++;
                	move(pline,currchar-1);
                	prints(NA,"%s",&inbuf[currchar-1]);
                	strcpy(lastcmd[0],inbuf);
                	move(pline,currchar);
                	continue;
            	}

		if (ch == '\n' || ch == '\r')
		{
			char	buf[STRLEN];
			int	j;
            
			if (dumb_term)
				prints(NA, "\n");

			for(i=10, j=0; i<STRLEN; i++)
			{
				if (inbuf[i] == '\0')
				{
					buf[j] = '\0';
					break;
				}
				if (inbuf[i] != ' ')
				buf[j++] = inbuf[i];
			}
                	if (inbuf[10])
			{
                        	for(i = MAXLASTCMD-1; i > 0; i--)
                                	strcpy(lastcmd[i], lastcmd[i-1]);
                        	strcpy(lastcmd[0],inbuf);  
                	}
                	cmdpos=0;                        

			if (buf[0] == '\0')
				continue;

			if (inbuf[10] == '/')
			{
				int action = dochatcommand(&inbuf[11], a);

				if (action == -2)
				{
			/*		ch = CINTR; */
					break;
				}
				else if (action == -1)
				{
					sprintf(buf, "%s -1, errno = %d\n",
						"CHAT FAILURE: write returne",
						 errno);
					break;
				}
			}
			else 
			{
				sprintf(sendbuf,"%2d:%s",MSG_PUB,inbuf);
				if (send(a, sendbuf, strlen(sendbuf) +1,0) == -1) {
					sprintf(buf, "%s -1, errno = %d\n",
						"CHAT FAILURE: write returned", errno);
					break;
	        		}
			}
/* mark may not useful */
	                move(pline, 0);
        	        strcpy(inbuf, chatid);
                	currchar = strlen(inbuf);

			if (!dumb_term)
				prints(NA, "%s", inbuf);
			clrtoeol();
			move(pline,currchar);
			continue;
		}

		if (ch == CTRL('H') || ch == '\177')
		{
			char	tmp[STRLEN];

			if (currchar == 10)
			{
				bell(1);
				continue;
			}

			strcpy(tmp, &inbuf[currchar]);
			inbuf[--currchar] = '\0';
			(void)strcat(inbuf, tmp);
			move(pline, 0);
			prints(NA, "%s", inbuf);
			clrtoeol();
	                move(pline, currchar);
			inbuf[strlen(inbuf)] = '\0';
	                continue;
		}

		if (ch == CTRL('C') || ch == CTRL('D'))
		{
			sprintf(sendbuf, "%2d:NONE", MSG_QUIT);
        	        send(a, sendbuf, strlen(sendbuf)+1,0);
                	break;
		}
        }

        add_io(0,0);
	shutdown(a, 2);
	close(a);

	memset(uinfo.ptcb, 0, sizeof(uinfo.ptcb));
	changemode(TMENU);

	clear();

	return 0;
}

int	send_to_server(cmd, fd, action, flag)
int 	cmd,
	fd,
	flag;
char	*action;
{

	int 	retval;

	if (flag && *action == '\0')
	{
		printchatline(NA,"[41;1m*** �ШϥΥ��T�����O ***[m");
		return 0;
	
	}
	
	sprintf(sendbuf,"%2d:%s", cmd, (flag) ? action : "NONE");
	
	retval = send(fd, sendbuf, strlen(sendbuf) + 1,0);
	if (retval > -1)
		retval = 0;

	return 	retval;
}
	
char	*advance(ptr)
char	*ptr;
{
	while (*ptr != ' ' && *ptr != '\n' && *ptr != '\t')
	{
		if (*ptr == '\0')
			return ptr;
		else
			ptr++;
	}

	while (*ptr == ' ' || *ptr == '\n' || *ptr == '\t')
		ptr++;

	*(ptr-1) = '\0';

	return ptr;
}

int	domsg(id,fd)
char	*id;
int	fd;
{
	char	*text,
	        buf[STRLEN];
	int     retval;


        while (*id == ' ' || *id == '\t' || *id == '\n')
                        id++;
        if (*id == '\0')
	{
        	printchatline(NA, "[41;1m*** ���~: ��H������ ***[m");
                return 0;
        }
        text = advance(id);
        msgto = id;

        if (*text == '\0')
        {
                printchatline(NA, "[41;1m ���~: �ťհT���O���Q������ ***[m");
                return 0;
        }
	sprintf(buf,"%2d:%s %s",MSG_PRIV,id,text);
	retval = send(fd,buf, strlen(buf)+1,0);
	sprintf(buf, "%s> %s", msgto, text);
        printchatline(NA, buf);
        msgto = NULL;

        if (retval > -1)
                retval = 0;

        return retval;
}

int	proc_server_cmd(ptr)
char	*ptr;
{
	int  	cmd;
	char	*cptr;

	cptr = ptr;
	ptr[1] = '\0';
	cmd = atoi(cptr);
	if (cmd == MESSAGE)
	{
		printchatline(NA, &ptr[2]);
		return 0;
	} else 	
	if (cmd == CHG_NICK)
	{
		strcpy(uinfo.ptcb, &ptr[2]);
		update_utmp();
		strcpy(chatid, uinfo.ptcb);
		chatid[8] = '\0';
		(void)strcat(chatid, ":                      ");
		chatid[10] = '\0';
		return cmd;
	}
	else if (cmd == CHG_ROOM)
	{
		strncpy(roomname, &ptr[2], 10);
		return cmd;
	} 

	return 0;
}

int	do_query(id)
char	*id;
{

        while (*id == ' ' || *id == '\t' || *id == '\n')
                        id++;
        if (*id == '\0')
	{
                printchatline(NA, "[41;1m*** ���~: ��H������ ***[m");
                return 0;
        }

	if (!getuser(id))
	{
		printchatline(NA, "*** [ĵ�i]: �d�L���H %s", id);
		return 0;
	}
	show_plan(NA, id, printchatline);
	return 0;
}

/*************************************************************************/
int	ent_chat1()
{
	int	savecloak = uinfo.invisible;

	if (!HAS_PERM(PERM_CHATCLOAK))
		uinfo.invisible = NA;

	chatroom = 1;
	t_chat();

	if (!HAS_PERM(PERM_CHATCLOAK))
 		uinfo.invisible = savecloak;
}

int	ent_chat2()
{
	int	savecloak = uinfo.invisible;

	if (!HAS_PERM(PERM_CHATCLOAK))
		uinfo.invisible = NA;

	chatroom = 2;
	t_chat();

	if (!HAS_PERM(PERM_CHATCLOAK))
 		uinfo.invisible = savecloak;
}

#ifdef USE_CHAT3
#ifdef CHAT3_CLOAKED
int	ent_chat3()
{
	int savecloak = uinfo.invisible;

	uinfo.invisible = YEA;
	chatroom = 3;
	t_chat();
	uinfo.invisible = savecloak;
}
#else
int	ent_chat3()
{
	int	savecloak = uinfo.invisible;

	if (!HAS_PERM(PERM_CHATCLOAK))
		uinfo.invisible = NA;
	chatroom = 3;
	t_chat();
	if (!HAS_PERM(PERM_CHATCLOAK))
 		uinfo.invisible = savecloak;
}
#endif
#endif

int     ent_chatbm()
{
        int     savecloak = uinfo.invisible;

        if (!HAS_PERM(PERM_CHATCLOAK))
                uinfo.invisible = NA;

        chatroom = 4;
        t_chat();

        if (!HAS_PERM(PERM_CHATCLOAK))
                uinfo.invisible = savecloak;
}

int     apply_chat_ulist(fptr)
int     (*fptr)();
{
        int     i,
                j,
                ch;
        usinfo  *inf;

        resolve_utmp();
        for (i=0, j = 0; i < UTMP_SIZE; i++)
        {
                if (j%21 == 20)
                {
                        ch = igetch();
                        if  (ch == 'Q' || ch == 'q')
                                 return QUIT;
                }
                if ((*fptr)(&(utmpshm->utc[i])) == NA)
                        continue;
                inf = &(utmpshm->utc[i]);
                j++;

#ifdef LIST_IDLE_TIME
     printchatline(NA, " %-12.12s %-20.20s %15.15s %c %c %-12.12s %4s",
                    inf->userid, inf->username,
                    inf->from, pagerchar(cuser.userid, inf->userid, 
inf->pager,
                    inf->allpager), HAS_PERM(PERM_SEECLOAK) ? 
(inf->invisible ?
                        '#' : ' ') : ' ', modestring(inf->mode, inf->ptcb),
                        list_idle(inf));
#else
     printchatline(NA, " %-12.12s %-20.20s %-15.15s %c %c %-12.12s",
                   inf->userid, inf->username,
                   inf->from, pagerchar(cuser.userid, inf->userid, 
inf->pager,
                   inf->allpager), HAS_PERM(PERM_SEECLOAK) ? 
(inf->invisible ?
                   '#' : ' ') : ' ', modestring(inf->mode, inf->ptcb));
#endif
        }
}
/* end of file */

