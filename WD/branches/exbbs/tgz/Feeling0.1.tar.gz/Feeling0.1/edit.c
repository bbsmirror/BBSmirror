/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef	lint
static  char    SccsId[] = "@(#)edit.c	2.1	12/24/95";
#endif

#include "bbs.h"

extern	char	currboard[];

extern	int	t_columns,
		t_lines,
		newmail;

#ifndef	EDITOR
extern	int	talkrequest;
extern	char	page_requestor[];
#endif

extern	userec	cuser;
extern	usinfo	uinfo;

extern	void	abort_bbs();

txtln	*firstline = NULL,
	*lastline = NULL,
	*currline = NULL,
	*top_of_win = NULL;
char	save_title[STRLEN],
	bkupfile[STRLEN];
int	currpnt = 0,
	currln = 0,
	currwinln = 0,
	totaln = 0,
	curr_window_line,
	redraw_everything,
	insert_character = 1,
	in_mail;
static	int	lastindent = -1;

void	indigestion(i)
int	i;
{
	(void)fprintf(stderr,"SERIOUS INTERNAL INDIGESTION CLASS %d\n",i);
}

void    edit_out(str)
char    *str;
{
	int	outnum = 0;

        while ((*str != '\0') && (++outnum < t_columns))
        {
                if (*str == KEY_ESC)
                {
                        outc('^');
                        str++;
                        continue;
                }
                outc(*str++);
        }
}

txtln	*back_line(pos,	num)
txtln	*pos;
int	num;
{
	while (num-- > 0)
	{
		if (pos && pos->prev)
		{
			pos = pos->prev;
			currln--;
		}
	}
	return pos;
}

txtln	*forward_line(pos, num)
txtln	*pos;
int	num;
{
	while (num-- > 0)
	{
		if (pos->next == lastline)
			break;
		if (pos && pos->next)
		{
			pos = pos->next;
			currln++;
		}
	}
	return pos;
}

int	getlineno()
{
	int	cnt = 0;
	txtln	*p = currline;

	while (p != top_of_win) 
	{
        	if (p == NULL)
        		break;
        	cnt++;
        	p = p->prev;
    	}
    	return cnt;
}

char	*killsp(s)
char	*s;
{
	while (*s == ' ')
		s++;
	return s;
}

txtln	*alloc_line()
{
	txtln	*p;

	p = (txtln *)malloc(sizeof(*p));
	(void)memset(p, 0, sizeof(p));

	if (p == NULL)
	{
        	indigestion(13);
        	abort_bbs();
    	}
	p->next = NULL;
	p->prev = NULL;
	p->data[0] = '\0';
	p->len = 0;

	return p;
}

/*
  Appends p after line in list.  keeps up with last line as well.
 */

void	append(p, line)
txtln	*p,
	*line;
{
	p->next = line->next;

	if (line->next)
		line->next->prev = p;
	else
		lastline = p;

	line->next = p;
	p->prev = line;
}

/*
  delete_line deletes 'line' from the list and maintains the lastline, and 
  firstline pointers.
 */

void	delete_line(line)
txtln	*line;
{
	if (!line->next && !line->prev)
	{
		(void)memset(line->data, 0, sizeof(line->data));
        	line->len = 0;
		return;
	}

	if (line->next)
		line->next->prev = line->prev;
	else
		lastline = line->prev;

	if (line->prev)
		line->prev->next = line->next;
	else
		firstline = line->next;

	free(line);
}

/*      
  split splits 'line' right before the character pos
 */

void    split(line, pos)
txtln   *line;
int     pos;
{
        txtln   *p = alloc_line();

        if (pos > line->len)
        {
                free(p);
                return;
        }
        p->len = line->len - pos;
        line->len = pos;
        (void)strcpy(p->data,(line->data + pos));
        *(line->data + pos) = '\0';
        append(p, line);
        if (line == currline && pos <= currpnt)
        {
                currline = p;  
                currpnt -= pos;
                curr_window_line++;
                currln++;
		totaln++;
        }
        redraw_everything = YEA; 
}

/*
  join connects 'line' and the next line.  It returns true if:
  
  1) lines were joined and one was deleted
  2) lines could not be joined
  3) next line is empty

  returns false if:

  1) Some of the joined line wrapped
 */

int	join(line)
txtln	*line;
{
	int	ovfl;
        char	*s;
        txtln	*p = line->next;

	if (!line->next)
		return YEA;
	if (*killsp(line->next->data) == '\0')
      		return YEA;
	ovfl = line->len + line->next->len - WRAPMARGIN;
	if (ovfl < 0)
	{
        	(void)strcat(line->data, line->next->data);
        	line->len += line->next->len;
        	delete_line(line->next);
        	return YEA;
	}
	else
	{
	        s = p->data + p->len - ovfl -1;
	        while (s!=p->data && *s == ' ')
			s--;
        	while (s!=p->data && *s != ' ')
        		s--;
       		if (s == p->data)
        		return YEA;
        	split(p,(s - p->data) + 1);
        	if (line->len + p->len >= WRAPMARGIN)
		{
        		indigestion(0);
       			return YEA;
		}
        	(void)join(line);
        	p = line->next;
        	if (p->len >= 1 && p->len+1 < WRAPMARGIN)
		{
           		if (p->data[p->len-1] != ' ')
			{
                		(void)strcat(p->data," ");
                		p->len++;
			}
        	}
        	return NA;
    	}
}

void 	insert_char(ch)
int	ch;
{
	int	i,
		wordwrap = YEA;
	char	*s;
	txtln	*p = currline;

	if (currpnt > p->len)
	{
        	indigestion(1);
		return;
	}
	if (currpnt < p->len && !insert_character)
		p->data[currpnt++] = ch;
	else
	{
		for (i = p->len; i >= currpnt; i--)
        		p->data[i+1] = p->data[i];
        	p->data[currpnt] = ch;
        	p->len++;
        	currpnt++;
    	}
    	if (p->len < WRAPMARGIN)
      		return;
    	s = p->data + (p->len - 1);
    	while (s!=p->data && *s == ' ')
      		s--;
    	while (s!=p->data && *s != ' ')
      		s--;
    	if (s==p->data)
	{
        	wordwrap = NA;
        	s = p->data + (p->len -2);
    	}
    	split(p,(s - p->data) + 1);
    	p = p->next;
    	if (wordwrap && p->len >= 1)
	{
        	i = p->len;
        	if (p->data[i-1] != ' ')
		{
        		p->data[i] = ' ';
            		p->data[i+1] = '\0';
            		p->len++;
        	}
    	}
    	while (!join(p))
	{
        	p = p->next;
        	if (p == NULL)
		{
            		indigestion(2);
            		break;
        	}
    	}
}

void	delete_char()
{
	int	i;

	if (currline->len == 0)
		return;
	if (currpnt >= currline->len)
	{
        	indigestion(1);
        	return;
    	}
    	for (i=currpnt; i!=currline->len; i++)
    		currline->data[i] = currline->data[i+1];
	currline->len--;
}

void	vedit_init()
{
	txtln	*p = alloc_line();

	firstline = lastline = currline = top_of_win = p;
	top_of_win->next = NULL;
	currpnt = curr_window_line = currln = totaln = 0;
	redraw_everything = NA;
	(void)sprintf(bkupfile, PATH_BACKUP, cuser.userid);
}

void 	read_file(filename)
char 	*filename;
{
	FILE	*fp;
	int	ch;

	if (currline == NULL)
		vedit_init();

	if ((fp = fopen(filename,"r+")) == NULL)
	{
        	if ((fp = fopen(filename,"w+")) != NULL)
		{
        		(void)fclose(fp);
            		return;
        	}
		(void)fprintf(stderr, "cannot open file: %s\n", filename);
        	indigestion(4);
        	abort_bbs();
    	}
    	while ((ch = getc(fp)) != EOF)
	{
		if (ISPRINT(ch) || ch == KEY_ESC)
		{
			if (currpnt < WRAPMARGIN -2)
				insert_char(ch);
			else if (currpnt < WRAPMARGIN -1)
				insert_char('.');
		}
		else if (ch == CTRL('I'))
		{
        		do
			{
				insert_char(' ');
      			}
			while (currpnt & 0x7);
      		}
		else if (ch == '\n')
        		split(currline,currpnt);
	}
	(void)fclose(fp);
}

void	addsignature(fp)
FILE	*fp;
{
        FILE	*sigfile;
        int	i,
		j,
		brk=NA;
        char	inbuf[MAXSIGLINES][WRAPMARGIN],
        	fname[STRLEN];

	(void)fputs("--\n", fp);

	if (!HAS_SET(SET_NOSIG))
	{
	        (void)sprintf(fname, PATH_SIG, cuser.userid);

	        if ((sigfile = fopen(fname, "r"))!= NULL)
		{
		        for (i=0; i<=cuser.signum; i++)
			{
		                for (j=0; j<MAXSIGLINES; j++)
				{
		                        if (!fgets(inbuf[j], sizeof(inbuf[j]),
						sigfile))
					{
		                                brk = YEA;
						break;
					}
				}
				if (brk)
					break;
		        }

		        for (i=0; i<j; i++)
			{
				if (strstr(inbuf[i], "--\n") != inbuf[i])
			                (void)fputs(inbuf[i], fp);
			}
		        (void)fclose(sigfile);
		}
	}
	(void)fprintf(fp, "[1;31m�Q Origin:[32m�E�ԯq�u�Ӹֱ��e�N BBS ���E[0m <%s> [FROM: %s]\n", 
		MYHOSTNAME, /* (uinfo.mode == POSTING &&
				check_setting(currboard, BHD_ANONYMOUS)) ?
		"Anonymous" :*/ cuser.lasthost);
}   

int	write_file(filename, saveheader)
char	*filename;
int	saveheader;
{
	FILE	*fp;
	txtln	*v,
		*p = firstline;
	int	ans,
		aborted = 0;
        struct	stat	stbuf;
	char	*msg;

	if (uinfo.mode == POSTING)
		msg = "(S)ave, (A)bort, (L)ocal save, or (E)dit? [S]: ";
	else
		msg = "(S)ave, (A)bort, or (E)dit? [S]: ";
	move(t_lines-1, 0);
#ifdef	EDITOR
	prints(NA, "[1;36;44m %-79s[m", msg);
#else
	prints(NA, "[1;36;44m %-62s �ϥ�ñ�W��[%2d] [m", msg,
		(cuser.signum + 1)%100);
#endif
	ans = tolower(igetkey());
	if (ans == 'a')
	{
		clear();
		prints(NA, "File NOT saved\n");
		refresh();
		sleep(2);
		if (stat(filename, &stbuf) || stbuf.st_size == 0) 
        		(void)unlink(filename);
		aborted = -1;
	}
	else if (ans == 'e' || ans == 'E')
		return KEEP_EDITING;

	firstline = NULL;

	if (!aborted)
	{
		if ((fp = fopen(filename,"w")) == NULL)
		{
			indigestion(5);
			abort_bbs();
		}
		if (saveheader)
			(void)write_header(fp);
	}

	while (p != NULL)
	{
		v = p->next;
		if (!aborted)
			if (p->next != NULL || p->data[0] != '\0')
				(void)fprintf(fp,"%s\n",p->data);
			free(p);
		p = v;
	}
#ifndef MAKEVE
	if (!aborted && (uinfo.mode == POSTING || uinfo.mode == SMAIL))
	{ 
		addsignature(fp);
	}
#endif
	if (!aborted)
		(void)fclose(fp);

	currline = lastline = firstline = NULL;

	if ((ans == 'L' || ans == 'l') && (uinfo.mode == POSTING))
		return LOCALSAVE;

	return aborted;
}

#ifndef EDITOR
void edit_msg()
{
	static	int	oline = 0;

	move(t_lines-1, 0);
	prints(NA, "[1;36;44m >= %-22.22s =< [%2.2d] < %-15.15s ���Ƨ�z > [%3.3s][m ",
		(newmail) ? "�z���s�H��|��Ū��" : "�� CTRL-Z ����u�W��U",
		(cuser.signum + 1) % 100, (talkrequest) ? page_requestor :
		"�ثe�S���H", insert_character ? "Ins" : "Rep");

	if (HAS_SET(SET_ONLYLINE))
	{
		if (oline != currln)
		{
			prints(NA, "[%7d]", currln+1);
			oline = currln;
		}
	}
	else
		prints(NA, "[%3d:%3d]", (currln+1)%1000, (currpnt+1)%1000);
}
#else
void edit_msg()
{
	static	int	oline = 0;

        move(t_lines-1, 0);
	prints(NA, "[1;36;44m >=  %-25s     %25s <= [%3s] [m",
		BOARDNAME, "�� CTRL-Z ����u�W��U",
		insert_character ? "Ins" : "Rep");
	if (HAS_SET(SET_ONLYLINE))
	{
		if (oline != currln)
		{
			prints(NA, "[%7d]", currln+1);
			oline = currln;
		}
	}
	else
		prints(NA, "[%3d:%3d]", (currln+1)%1000, (currpnt+1)%1000);
}
#endif

void	edit_preview()
{
	txtln	*p;
	int	i = 0,
		ch;
	char	*msg = "�w����ܽs�赲�G��, �Ы����N���~��, �� 'q' ����";

	clear();

	for(p = firstline; p != (txtln *)NULL; p = p->next)
	{
		move(i, 0);
		clrtoeol();
		prints(NA, "%s\n", p->data);
		if (i++ >= 22)
		{
			i = 0;
			ch = strlen(msg);
			prints(NA, "[1;36;44m%16s%s%16s[m", "", msg, "");
			if ((ch = igetkey()) == 'Q' || ch == 'q')
				break;
			clear();
		}
	}
	clrtobot();
	pressreturn();
	clear();
	redraw_everything = YEA;
	return;
}

void	display_buffer()
{
	txtln	*p;
	int	i,
		shift;

	for (p = top_of_win, i = 0; i < t_lines-1; i++)
	{
		move(i, 0);

		shift = (currpnt >= t_columns) ?
			(currpnt / (t_columns - 10)) * (t_columns - 10) : 0;
		if (p)
		{
			if (shift <= strlen(p->data))
				edit_out(p->data + shift);
			p = p->next;
		}
		else
			prints(NA, "~\n");
		clrtoeol();
	}
	edit_msg();
	move(t_lines-1, 70);
	if (HAS_SET(SET_ONLYLINE))
		prints(NA, "[%7d]", currln+1);
	else
		prints(NA, "[%3d:%3d]", currln+1, currpnt+1);

	return;
}

int	change_sig()
{
#ifdef	EDITOR
	return 0;
#else
	char	buf[5],
		str[80];
	int	sig;

	move(t_lines-1, 0);
	prints(NA, "[1;36;44m %23s [%2.2d]: [m",
		"�ϥβĴX��ñ�W��(1~..)?", cuser.signum+1);
	clrtoeol();
	refresh();
	getdata(t_lines-1, 32, NULL, buf, 4, DOECHO, YEA);
	sig = atoi(buf);
	if (sig != 0)
		cuser.signum = sig -1;
#endif
}

void	e_pageup()
{
	int	oline = currln;

	top_of_win = back_line(top_of_win, 22);
	currln = oline;
	currline = back_line(currline, 22);
	currwinln = curr_window_line;
	curr_window_line = getlineno();
	if (currpnt > currline->len)
		currpnt = currline->len;
	redraw_everything = YEA;
}

void	e_pagedown()
{
	int	oline = currln;

	top_of_win = forward_line(top_of_win, 22);
	currln = oline;
	currline = forward_line(currline, 22);
	currwinln = curr_window_line;
	curr_window_line = getlineno();
	if (currpnt > currline->len)
		currpnt = currline->len;
	redraw_everything = YEA;
}

void	e_left()
{
	if (currpnt > 0)
		currpnt--;
	else if (currline->prev)
	{
		curr_window_line--;
		currln--;
		currline = currline->prev;
		currpnt = currline->len;
	}
	else
		bell(1);
}

void	e_right()
{
	if (currline->len != currpnt)
		currpnt++;
	else if (currline->next)
	{
		currpnt = 0;
		curr_window_line++;
		currln++;
		currline = currline->next;
	}
	else
		bell(1);
}

void	e_up()
{
	if (currline->prev)
	{
		curr_window_line--;
		currln--;
		currline = currline->prev;
		currpnt = (currline->len>lastindent) ? lastindent :
			currline->len;
	}
	else
		bell(1);
}

void	e_down()
{
	if (currline->next)
	{
		currline = currline->next;
		curr_window_line++;
		currln++;
		currpnt = (currline->len>lastindent) ? lastindent :
			currline->len;
	}
	else
		bell(1);
}

void	e_head()
{
	top_of_win = firstline;
	currline = top_of_win;
	currpnt = 0;
	currln = 0;
	curr_window_line = 0;
	redraw_everything = YEA;
}

void	e_tail()
{
	top_of_win = back_line(lastline, 23);
	currline = lastline;
	currwinln = curr_window_line;
	curr_window_line = getlineno();
	currpnt = 0;
	currln = totaln;
	redraw_everything = YEA;
}

void	e_backspace()
{
	if (currpnt == 0) 
	{
		txtln	*p;

		if (!currline->prev)
		{
			bell(1);
			return;
		}
		curr_window_line--;
		currln--;
		totaln--;
		currline = currline->prev;
		currpnt = currline->len;
		if (*killsp(currline->next->data) == '\0')
		{
			delete_line(currline->next);
			redraw_everything = YEA;
			return;
		}
		p = currline;
		while (!join(p))
		{
			p = p->next;
			if (p == NULL) 
			{
				indigestion(2);
				abort_bbs();
			}
		}
		redraw_everything = YEA;
		return;
	}
	currpnt--;
	delete_char();
}

void	e_del()
{
	if (currline->len == currpnt) 
	{
		txtln	*p = currline;

		while (!join(p))
		{
			p = p->next;
			if (p == NULL) 
			{
				indigestion(2);
				abort_bbs();
			}
		}
		redraw_everything = YEA;
		return;
	}
	delete_char();
}

void	e_delafter()
{
	if (currline->len == 0) 
	{
		txtln *p = currline->next;
		if (!p)
		{
			p = currline->prev;
			if (!p)
			{
				bell(1);
				return;
			}
			if (curr_window_line > 0)
			{
				curr_window_line--;
				currln--;
				totaln--;
			}
		}
		if (currline == top_of_win)
			top_of_win = p;
		delete_line(currline);
		currline = p;
		redraw_everything = YEA;
		return;
	}
	if (currline->len == currpnt) 
	{
		txtln *p = currline;

		while (!join(p)) 
		{
			p = p->next;
			if (p == NULL) 
			{
				indigestion(2);
				abort_bbs();
			}
		}
		redraw_everything = YEA;
		return;
	}
	currline->len = currpnt;
	currline->data[currpnt] = '\0';
}

void	e_cleanline()
{
	currpnt = 0;
	currline->len = 0;
	currline->data[currpnt] = '\0';
	e_delafter();
	redraw_everything = YEA;
}

void	e_tab()
{
	do
	{
		insert_char(' ');
	}
	while (currpnt & 0x7);
}

void	edk_block_start()
{}

void	edk_block_end()
{}

void	edk_block_copy()
{}

void	edk_block_del()
{}

void	edk_savetmp()
{
	FILE	*fp;
	txtln	*p;

	if (!(fp = fopen(bkupfile, "w+")))
		return;
	for(p = firstline; p != NULL; p = p->next)
	{
		(void)fprintf(fp, "%s\n", p->data);
	}
	(void)fclose(fp);
	return;
}

void	edk_readtmp()
{
	read_file(bkupfile);
	e_tail();
	return;
}

void	extern_key_c()
{
	int	x,
		y;
	char	ext;

	getyx(&x, &y);
	move(t_lines-1, 0);
	clrtoeol();
	prints(NA, "�i�ҥνƦX�� CTRL-C �\\��j�п�J������G");
	ext = igetkey();
	switch (tolower(ext))
	{
		case 'p':
			edit_preview();
			break;
		case 'b':
			edk_block_start();
			break;
		case 'k':
			edk_block_end();
			break;
		case 'c':
			edk_block_copy();
			break;
		case 'y':
			edk_block_del();
			break;
		case 'd':
			edk_savetmp();
			break;
		case 'r':
			edk_readtmp();
			break;
		case 'V':
		case 'v':
		        e_head();
		        break;	
		case 'i':
			e_tab();
			redraw_everything = NA;
			break;
		case 's':
			change_sig();
			break;
		default:
			redraw_everything = NA;
			break;
	}
	edit_msg();
	move(x, y);
}


char 	*helptxt[] = 
{
	"\01�s����O",
	"^W, ^X   �s�ɫᵲ���s��         ^L, ^G    ��ø�ù�",
	"^U       ��J Escap �r��        ^Z        ��ܻ��U�e��",
	"^I, TAB  8 �r���w�챱��",
	"",
	"\01��в��ʫ��O",
	"^P, ��   �V�W                   ^R, ��    �V��",
	"^N, ��   �V�U                   ^V, ��    �V�k",
	"^B, PgUp �W�@��                 ^A, Home  �ܦ歺",
	"^F, PgDn �U�@��                 ^E, End   �ܦ楽",
	"^T       �ɮ׵���",
	"",
	"\01�R����O",
	"^O, Ins  �������J/�m���Ҧ�      ^H, BS    �R������r��",
	"^Y       �R���@��               ^D, DEL   �R���ثe�r��",
	"^K       �Ѵ�ж}�l�R������ ",
	"",
	"\01�ƦX�� CTRL-C",
#ifdef	EDITOR
	"P        ��X�w���\\��",
#else
	"S        ��ñ�W��             P         ��X�w���\\��",
	"R        Ū�J�Ȧs��             D         �ƥ��ثe�s����",
	"V        �����ɮ׶}�Y",
#endif
	NULL,
};

void	vedit_help()
{
	int	i,
		off = 0,
		pos = 2;

	clear();
	prints(YEA, "<<=== Editor Help Screen ===>>");
	for (i = 0; helptxt[i]; i++) 
	{
        	move(pos, off);
        	if (helptxt[i][0] == '\01') 
		{
        		prints(YEA, "%s",&helptxt[i][1]);
        	} 
		else 
			prints(NA, "%s",helptxt[i]);
        	clrtoeol();
        	pos++;
    	}
	pressreturn();
    	clear();
    	redraw_everything = YEA;
}

void	vedit_key(ch)
int	ch;
{
	static	int	osht = 0;
	int	shift,
		oline = currln;

	if (ch == CTRL('P') || ch == 0x100+'A' || ch == CTRL('N') ||
		ch == 0x100+'B')
	{
		if (lastindent == -1)
			lastindent = currpnt;
	}
	else
		lastindent = -1;
    	if (ch < 0x100 && ISPRINT(ch))
	{
		insert_char(ch);
	}
	else
	{
		switch(ch)
		{
        		case CTRL('U'):
        			insert_char(KEY_ESC);
        			break;
			case '\r':
			case '\n':
				split(currline, currpnt);
#ifndef EDITOR
				newmail = chkmails(cuser, NA);
#endif
				break;
			case CTRL('G'): /* redraw screen */
				clear();
	    			redraw_everything = YEA;
	    			break;
			case CTRL('Z'): /* call help screen */
				vedit_help();
				break;
			case CTRL('R'):
			case KEY_LEFT:
				e_left();
				break;
			case CTRL('V'):
			case KEY_RIGHT:
				e_right();
	    			break;
			case CTRL('P'):
			case KEY_UP:
				e_up();
				break;
			case CTRL('N'):
			case KEY_DOWN:
				e_down();
				break;
			case CTRL('B'):
			case KEY_PGUP:
				e_pageup();
				break;
			case CTRL('F'):
			case KEY_PGDN:
				e_pagedown();
				break;
			case CTRL('A'):
			case KEY_HOME:
				currpnt = 0;
				break;
			case CTRL('E'):
			case KEY_END:
				currpnt = currline->len;
				break;
			case CTRL('T'): /* tail of file */
				e_tail();
	    			break;
			case CTRL('O'):
			case KEY_INSERT:
	    			insert_character = !insert_character;
	    			edit_msg();
				break;
			case CTRL('H'): 
			case '\177': /* backspace */
				e_backspace();
	    			break;
			case CTRL('D'): 
			case KEY_DEL: /* delete current character */
				e_del();
	    			break;
			case CTRL('Y'): /* delete current line */
				e_cleanline();
	    			break;
			case CTRL('I'): /* delete to end of line */
				e_tab();
				redraw_everything = NA;
	    			break;
			case CTRL('K'):
				e_delafter();
				break;
			case CTRL('C'):
				extern_key_c();
				break;
			default:
	    			bell(1);
	    			break;
    		}
	}
	if (currln < 0)
		currln = 0;
    	if (curr_window_line < 0)
	{
		curr_window_line = 0;
		if (!top_of_win->prev) 
		{
			indigestion(6);
			bell(1);
		} 
		else 
		{
			top_of_win = top_of_win->prev;
			rscroll();
			edit_msg();
		}
    	}
    	if (curr_window_line == t_lines-1) 
	{
		curr_window_line = t_lines-2;
		if (!top_of_win->next) 
		{
			indigestion(7);
			bell(1);
		} 
		else 
		{
			top_of_win = top_of_win->next;
			move(t_lines-1, 0);
			clrtoeol();
			scroll();
			edit_msg();
		}
    	}

	if (HAS_SET(SET_ONLYLINE))
	{
		if (currln != oline)
		{
			move(t_lines-1, 71);
			prints(NA, "%7d", currln+1);
		}
	}
	else
	{
		move(t_lines-1, 71);
		prints(NA, "%3d:%3d", currln+1, currpnt+1);
	}

/*	edit_msg();*/
    	move(curr_window_line, 0);

	shift = (currpnt >= t_columns) ?
		(currpnt/(t_columns-10))*(t_columns-10) : 0;
	if (shift == osht)
	{
    		edit_out(currline->data+shift);
    		clrtoeol();
	}
	else
	{
		display_buffer();
		osht = shift;
	}
}

void	vedit_abort()
{
	edk_savetmp();
	exit(0);
}

int	vedit(filename, saveheader)
char	*filename;
int	saveheader;
{
	int	ch,
		foo,
		shift;

	(void)signal(SIGHUP, (void *)vedit_abort);
#ifndef	EDITOR
	newmail = chkmails(cuser,NA);    
#endif
	read_file(filename);
	top_of_win = currline = firstline;
	curr_window_line = currpnt = currln =  0;

	clear();
	display_buffer();
	move(0, 0);

	while ((ch = igetkey())!= EOF)
	{
#ifndef EDITOR
		if (talkrequest)
			edit_msg();
#endif
		switch(ch)
		{
			case CTRL('W'):
			case CTRL('X'):/* Save and exit */
				foo = write_file(filename, saveheader);
                		if (foo != KEEP_EDITING)
				{
					(void)unlink(bkupfile);
					(void)strcat(bkupfile, ".INI");
					(void)unlink(bkupfile);
					signal(SIGHUP, (void *)abort_bbs);
					return foo;
                		}
                		redraw_everything = YEA;
                		break;
	    		default:
				vedit_key(ch);
		}
		if (redraw_everything)
	    		display_buffer();
		redraw_everything = NA;
		shift = (currpnt >= t_columns) ?
			(currpnt/(t_columns-10))*(t_columns-10) : 0;
		move(curr_window_line, currpnt-shift);
    	}
	signal(SIGHUP, (void *)abort_bbs);
	return 0;
}
