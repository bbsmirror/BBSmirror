/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw
			   ���i�g, u8121142@ccunix.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    SccsId[] = "@(#)post.c	2.1	12/24/95";
#endif

#include "bbs.h"

extern	int	selboard,
		usernum,
		in_mail,
		t_lines;
extern	char	currboard[],
		save_title[];
extern	acc	acclist[];
extern	userec	cuser;
extern	usinfo	uinfo;

extern	char	*Ctime(),
		*strtolow();
extern	List	*L_head,
		*L_tail;
extern	int	get_num_records(),
		make_blist(),
		get_records(),
		cmprcbid(),
		load_acclist(),
		search_acc(),
		cmpbname();
extern	void	show_board_info(),
		edit_board_info(),
		prints();

static	int	sequent_ent,
		quiting;
static	time_t	visit_date;
char	currtitle[STRLEN],
	match[STRLEN];

char match_flag=TRUE;


hlpinfo MainRead[] = {
     0,  0, HIGH, 0,           "[1;36;44m                      Ū�峹�ާ@���� Main Read Menu Help Screen                [m\n\n",
    -1, -1, HIGH, 0,           "[1;36;44m                                  ��в��ʻ���                                 [m\n",
    -1, -1,  LOW, 0,           "p�� n��        �W �U�@�����          P N         �W/�U�@��\n",
    -1, -1,  LOW, 0,           "##<num>        ���##�����           $           �̫�@�����\n",
    -1, -1,  LOW, 0,           "\n",
    -1, -1, HIGH, 0,           "[1;36;44m                                ��L�`�Ϊ��\\����                               [m\n",
    -1, -1,  LOW, 0,           "r              Ū�����               O           �ݧ벼���G\n",
    -1, -1,  LOW, PERM_POST,   "CTRL-P         �i�K�s�峹             R           �^�Ф峹\n",
    -1, -1,  LOW, PERM_POST,   "x              ��K�峹���L�O       T           �󴫤峹�D�D\n",
    -1, -1,  LOW, 0,           "e              �^�D���               TAB         �ݥثe�Ҧb���� FAQ\n",
    -1, -1,  LOW, 0,           "- +            ���e�Ϋ�j�M�۳]�r��   / ?         �]�w�M��D�D�εo�H�H\n",
    -1, -1,  LOW, PERM_BMS,    "D              �R���d�򤺪��峹       m           �۰ʲM���O�@�Х�\n",
    -1, -1,  LOW, PERM_BMS,    "A              �}�벼�c               CTRL-C , c  �R���벼�c, ���벼�p���e��\n",
    -1, -1,  LOW, 0,           "s              ��Q�װ�               S           Ū��ХH�U�s�峹\n",
    -1, -1,  LOW, PERM_POST,   "M              �N�峹�h���L�O       V           �ѥ[�ثe�|�椤���벼\n",
    -1, -1,  LOW, 0,           "CTRL-L         �ù���ø               v           �N�峹���ƼЬ�Ū�L\n",
    -1, -1,  LOW, 0,           "z              �Ь���Ū               f           ����Ū���O��\n",
    -1, -1,  LOW, PERM_BMS,    "W              �s�g�Q�װ�²��         a           �m�J�Ȧs��\n",
    -1, -1,  LOW, PERM_BASIC,  "d              �R���w�o���峹         i           �[�ݰQ�װ�²��\n",
    -1, -1,  LOW, PERM_BASIC,  "E              ���g�w�o���峹         [1;33m[ ]         Ū�������D�D���峹\n[0m",
    -1, -1,  LOW, PERM_FORWARD,"F              �H�^�ۤw�b��\n",
    -1, -1,  LOW, 0,           "h              �����U�e��             Q           ��ݧ@�̪����\n",
    -1, -1,  LOW, 0,           NULL,
};

void	show_linklist()
{
	List	*loc;
	int	pos = 0;
	inner	*a;
	extern	List	*L_head;

	prints(NA, "=========================\n");
	for (loc = L_head; loc != NULL; loc = loc->next)
	{
		a = (inner *)loc->info;
		prints(NA, "[%2d] (%d-%d) %x %x %x\n", ++pos, a->begin, a->final,
			loc->prev, loc, loc->next);
	}
	prints(NA, "=========================\n");
}

int	bbsrc_comp(rec, key)
inner	*rec;
int	key;
{
	if ((rec->begin <= key) && (rec->final >= key))
		return YEA;
	return NA;
}

int	bbsrc_ifread(key)
int	key;
{
	if (SearchLinkList(bbsrc_comp, key) == NULL)
		return FILE_UNREAD;
	return FILE_READ;
}

void	bbsrc_update(key, flag)
int	key,
	flag;
{
	inner	*a,
		*b,
		tag;
	List	*p;

	if (key <= 0)
		return;
	if (L_head == NULL || (a = (inner *)L_head->info, key < a->begin))
	{
		if (flag != FILE_READ)
			return;
		tag.begin = tag.final = key;
		InsertLinkList((char *)&tag, 1, sizeof(inner));
		p = L_head;
	}
	else
	{
		for (p = L_tail; p != NULL; p = p->prev)
		{
			a = (inner *)p->info;

			if (key == a->begin && key == a->final)
			{
				if (flag != FILE_READ)
				{
					if (p == L_head)
						L_head = p->next;
					if (p == L_tail)
						L_tail = p->prev;
					DropFromLinkList(p);
				}
				return;
			}
			if (key == a->begin)
			{
				if (flag != FILE_READ)
					a->begin = key + 1;
				return;
			}
			if (key == a->final)
			{
				if (flag != FILE_READ)
					a->final = key - 1;
				return;
			}
			if (key > a->begin && key < a->final)
			{
				if (flag == FILE_READ)
					return;
				SplitLinkList(p, sizeof(inner));
				a->final = key-1;
				b = (inner *)p->next->info;
				b->begin = key+1;
				if (p == L_tail)
					L_tail = p->next;
				break;
			}
			if (key > a->final)
			{
				if (p->next == NULL)
					b = NULL;
				else
					b = (inner *)p->next->info;
				if (b == NULL || key < b->begin)
				{
					if (flag != FILE_READ)
						return;
					SplitLinkList(p, sizeof(inner));
					p = p->next;
					b = (inner *)p->info;
					b->begin = b->final = key;
					if (p->prev == L_tail)
					L_tail = p;
				}
				break;
			}
		}
	}
	if (p->prev != NULL)
	{
		a = (inner *)p->info;
		b = (inner *)p->prev->info;
		if (a->begin <= b->final + 1)
		{
			b->final = a->final;
			if (p == L_tail)
				L_tail = p->prev;
			p = p->prev;
			DropFromLinkList(p->next);
		}
	}
	if (p->next != NULL)
	{
		a = (inner *)p->info;
		b = (inner *)p->next->info;
		if (a->final >= b->begin - 1)
		{
			b->begin = a->begin;
			if (p == L_head)
				L_head = p->next;
			p = p->next;
			DropFromLinkList(p->prev);
		}
	}
}

void	bbsrc_init(tag, board)
bbsrc	*tag;
int	board;
{
	int	pos = 0;
	inner	key;
	char	genbuf[STRLEN];

	(void)sprintf(genbuf, PATH_BBSRC, cuser.userid);
	if (search_record(genbuf, (char *)tag, sizeof(bbsrc),
		cmprcbid, board) <= 0)
	{
		(void)memset((char *)tag, 0, sizeof(bbsrc));
	}
	CreateLinkList();
	visit_date = tag->visit;
	if (tag->keys[0])
	{
		key.begin = 1;
		if (tag->keys[1] < 0)
		{
			pos = 2;
			key.final = abs(tag->keys[1]);
		}
		else
		{
			pos = 1;
			key.final = abs(tag->keys[0]);
		}
		AddLinkList(&key, sizeof(bbsrc));
	}
	for ( ; pos < MAXRECS; pos++)
	{
		if (tag->keys[pos] == 0)
			continue;
		if (tag->keys[pos] > 0 || pos == 0)
			key.begin = key.final = tag->keys[pos];		
		if (tag->keys[pos+1] < 0)
			key.final = - (tag->keys[++pos]);
		AddLinkList(&key, sizeof(bbsrc));
	}
	return;
}

void	bbsrc_restore()
{
	List	*loc;
	int	pos,
		num;
	bbsrc	record;
	inner	*curr;
	bhd	cbhd;
	char	genbuf[STRLEN];
	extern	List	*L_tail;

	sprintf(genbuf, PATH_BBSRC, cuser.userid);
	if (search_board(&cbhd, currboard, cmpbname) <= 0)
	{
		if ((pos = search_record(genbuf, (char *)&record, sizeof(bbsrc),
			cmprcbid, cbhd.flownum)) > 0)
		{
			delete_record(genbuf, sizeof(bbsrc), pos);
		}
		return;
	}
	pos = search_record(genbuf, (char *)&record, sizeof(bbsrc), cmprcbid,
		cbhd.flownum);
	(void)memset(&record, 0, sizeof(bbsrc));
	record.b_flow = cbhd.flownum;
	record.visit = visit_date;
	for (loc = L_tail, num = MAXRECS - 1; loc != NULL && num >= 0;
		loc = loc->prev)
	{
		curr = (inner *)loc->info;
		if (curr->begin == curr->final)
		{
			record.keys[num--] = curr->begin;
		}
		else
		{
			record.keys[num--] = -(curr->final);
			record.keys[num--] = curr->begin;
		}
	}
	if (pos <= 0)
		append_record(genbuf, (char *)&record, sizeof(bbsrc));
	else
		switch_record(genbuf, (char *)&record, sizeof(bbsrc), pos);
};

/* ARGSUSED */
int	read_help(ent, fileinfo, direct)
int	ent;
fhd	*fileinfo;
char	*direct;
{
	clear();
	do_the_help(MainRead);
	pressreturn();
	clear();
	return FULLUPDATE;
}

int	save_backinfo(type, subject, sendto, writeheader)
int	type,
	writeheader;
char	*subject,
	*sendto;
{
	backup	bkrec;
	char	bkinfo[STRLEN];
	int	fd;
	
	(void)sprintf(bkinfo, PATH_BKINFO, cuser.userid);
	if((fd = open(bkinfo, O_WRONLY | O_CREAT, 0600)) == -1)
	{
		prints(NA, "cann't record backup info. !! \n");
		return  -1;
	}
	(void)memset(&bkrec, 0, sizeof(backup)); 
	(void)strcpy(bkrec.sendto, sendto);
	(void)strcpy(bkrec.subject, subject);
	bkrec.type = type;
	bkrec.writehd = writeheader;
	(void)write(fd, (char *)&bkrec, sizeof(backup));
	(void)close(fd);
	return ;
}

int	Post()
{
	fhd	postfile;
	char	fname[STRLEN],
		genbuf[STRLEN];
	int	aborted;


	if (!selboard)
	{
		move(2, 0);
		prints(NA, POST_NOCURRBRD);
		return 0;
	}

	if (!haspostperm(currboard))
	{
		move(2, 0);
		prints(NA, POST_NOLEVEL, currboard);
		return 0;
	}

	(void)memset(&postfile, 0, sizeof(postfile));
/*
	�令�]�w��Ū�L
	postfile.accessed[usernum] = FILE_READ|FILE_OWND;
*/
        clear();

	move(3, 0);
        show_board_info(currboard);

	prints(NA, POST_CURRBRD_POST, currboard);

        if (get_title(NULL, postfile.title) == QUITPOST)
		return 0;

        (void)strncpy(save_title, postfile.title, STRLEN-1);
	in_mail = NA;

	if (check_setting(currboard, BHD_ANONYMOUS))
	{
		(void)strcpy(postfile.sender, "Anonymous");
		postfile.flag |= FILE_LOCAL;
	}
	else
		(void)strncpy(postfile.sender, cuser.userid, 76);

	(void)sprintf(fname, "boards/%s/", currboard);
	buildfile(fname);
	postfile.date = time(NULL);
	(void)strncpy(postfile.filename, fname, 20);
	(void)sprintf(genbuf, PATH_BRDDIR, currboard, fname);
	if (!check_setting(currboard, BHD_MYSTERY))
	(void)strncpy(uinfo.ptcb, currboard, 20);
	changemode(POSTING);
	(void)save_backinfo('P', save_title, currboard, YEA);
	aborted = vedit(genbuf, YEA);
	(void)memset(uinfo.ptcb, 0, sizeof(uinfo.ptcb));
	changemode(MPOST);
	clear();
	if (aborted == LOCALSAVE)
	{
		postfile.flag |= FILE_LOCAL;
		aborted = 0;
	}
	if (!aborted)
	{
		sprintf(genbuf, PATH_BRDDIR, currboard, FHDIR);
		if (append_record(genbuf, (char *)&postfile, sizeof(postfile))
			== -1)
		{
			prints(NA, POST_POSTERROR, ADMIN);
			pressreturn();
			clear();
			return -1;
		}
		prints(NA, POST_POSTSUCCESS, currboard);
		if (!check_setting(currboard, BHD_NOCOUNT))
			cuser.numposts++;
		UPDATE;
	}
	pressreturn();
	return 0;
}

void	readtitle()
{
	char	bmlist[50];
	bhd	fh;

	search_board(&fh, currboard, cmpbname);
/*	clear();
*/	move(0, 0);
	clrtoeol();
	move(1, 0);
	clrtoeol();
	if (fh.flag & BHD_VOTEING)
		(void)sprintf(bmlist, "�i���O�벼���j�Ы��j�g�� 'V' �ѥ[");
	else
		(void)sprintf(bmlist, "�i�O�D�j %s %s %s", 
			(fh.mngs[0][0]) ? fh.mngs[0] : "", 
	                (fh.mngs[1][0]) ? fh.mngs[1] : "", 
	                (fh.mngs[2][0]) ? fh.mngs[2] : "");
	move(0, 0);
	prints(NA, "[1;36m%-50s[m%29s\n", bmlist, boardmargin());
	prints(NA, "%s   %s%s   %s\n", "[[1;33m��[m,[1;33me[m]�^�W�@�e��",
		"[[1;33mh[m]�D�U   [[1;33m��[m,[1;33mr[m",
		" [1;33m<cr>[m]Ū����ЩҦb�峹",
		"[[1;33m��[m,[1;33m��[m]�W,�U�@�g�峹");

	prints(YEA, "[1;36;44m �s��   %-15s %-6s  %-47s[m\n",
		"�@��", "���", "���D");
}

void	readdoent(num, ent)
int	num;
fhd	*ent;
{
	char	userid[80],
		*date;
	int	type;

	(void)strcpy(userid, ent->sender);
	(void)strtok(userid, ". @");

	if (strchr(ent->sender, '@'))
		(void)strcat(userid, ".");

        if (ent->date > (time_t)740000000)
                date = Ctime(&ent->date) + 4;
        else
                date = Ctime(&ent->date) + 20;

/*
 * �w�w�N struct fileheader ���� filename (char *) �令 filenum (int)
 */
	if (bbsrc_ifread(atoi(ent->filename+2)))
		type = ' ';
	else if (ent->date < visit_date)
		type = 'U';
	else
		type = 'N';

	if ((ent->flag & FILE_MARKED) &&
		(HAS_PERM(PERM_BMS) || HAS_PERM(PERM_ANNOUNBM)))
	{
		if (type == ' ')
			type = 'm';
		else
			type = 'M';
	}

	if (strstr(ent->title, "Re: ") == ent->title)
	{
		if (!strcmp(ent->title+4, currtitle))
        		prints(NA, " %4d %c %-15.15s %6.6s  [1;33m%-.47s[m\n", 
				num, type, userid, date, ent->title);
		else
	        	prints(NA, " %4d %c %-15.15s %6.6s  %-47.47s\n", 
				num, type, userid, date, ent->title);
	}
	else
	{
		if (!strcmp(ent->title, currtitle))
        		prints(NA, " %4d %c %-15.15s %6.6s  [1;32m�� %-.40s ��[m\n", 
				num, type, userid, date, ent->title);
		else
	        	prints(NA, " %4d %c %-15.15s %6.6s  �� %-.40s ��\n", 
				num, type, userid, date, ent->title);
	}
}

int	cmpfilename(fhdr, buf)
fhd	*fhdr;
char	*buf;
{
	return !strncmp(fhdr->filename, buf, 20);
}

/*
    ����, �令 bbsrc_update
void	updatefile(fhdr)
fhd	*fhdr;
{
	fhdr->accessed[usernum] |= FILE_READ;
	fhdr->accessed[usernum] &= ~FILE_VISIT;
}
*/

int	do_select()
{
	List	*t_head,
		*t_tail;

	t_head = L_head;
	t_tail = L_tail;
	bbsrc_restore();
	L_head = L_tail = NULL;

	if (Select())
	{
		L_head = t_head;
		L_tail = t_tail;
		return FULLUPDATE;
	}
	else
		if (!check_setting(currboard, BHD_MYSTERY))
		(void)strncpy(uinfo.ptcb, currboard, 20);

	L_head = t_head;
	L_tail = t_tail;
	CreateLinkList();
	return NEWDIRECT;
}

void	convert_mail(finfo, mailinfo)
fhd	*finfo;
fhd	*mailinfo;
{
	(void)memset(mailinfo, 0, sizeof(fhd));
	(void)strcpy(mailinfo->sender, finfo->sender);
	(void)strncpy(mailinfo->filename, finfo->filename, 20);
	if (!finfo->title[0])
		(void)strcpy(finfo->title, "Re: ");
	(void)strcpy(mailinfo->title, finfo->title);
}

int	do_reply_auth(oldfile)
fhd	*oldfile;
{
	fhd	maildata;
	char	bufdir[STRLEN];

	(void)sprintf(bufdir, PATH_BRDDIRECT, currboard);
	convert_mail(oldfile, &maildata);
	return mail_reply(0, &maildata, bufdir);
}

int	do_reply_forward(oldfile, email)
fhd	*oldfile;
int	email;
{
	char	namebuf[STRLEN],
		bufdir[STRLEN];
	fhd	mailbuf;

	if (email && HAS_PERM(PERM_TRUE))
	{
		getdata(0, 0, ASK_RECEIVER, namebuf, STRLEN, DOECHO, YEA);
		if (namebuf[0] == '\0')
			return -1;
	}
	else
	{
		List	*t_head = L_head,
			*t_tail = L_tail;

		bbsrc_restore();
		L_head = L_tail = NULL;
		if (!init_namelist(namebuf))
		{
			L_head = t_head;
			L_tail = t_tail;
			return -1;
		}
		L_head = t_head;
		L_tail = t_tail;
	}
	(void)sprintf(bufdir, PATH_BRDDIRECT, currboard);
	convert_mail(oldfile, &mailbuf);
	(void)strcpy(mailbuf.sender, namebuf);
	return mail_reply(0, &mailbuf, bufdir);
}

#ifdef	BBSTONEWS
int	append_transform(file)
fhd	*file;
{
	usenet	info;

	memset(&info, 0, sizeof(usenet));
	strcpy(info.filename, file->filename);
	strcpy(info.board, currboard);
	if (check_setting(currboard, BHD_ANONYMOUS))
		strcpy(info.poster, "Anonymous");
	else
		strcpy(info.poster, cuser.userid);
	strcpy(info.title, file->title);
	return append_record(PATH_BBSNEWS, &info, sizeof(info));
}
#endif

int	do_post(oldfile)
fhd	*oldfile;
{
	fhd	postfile;
	struct	stat	st;
	char	fname[STRLEN], 
		buf[256], 
		oldbuf[STRLEN],
		saveptcb[20],
		genbuf[STRLEN];
	int	aborted, 
		ans, 
		savemode;

	if (!haspostperm(currboard))
	{
		move(2, 0);
		prints(NA, POST_NOLEVEL, currboard);
		return 0;
	}

	(void)memset(&postfile, 0, sizeof(postfile));

/*
	�令 bbsrc_update(file_number);

	if (check_setting(currboard, BHD_ANONYMOUS))
		postfile.accessed[usernum] = FILE_READ;
	else
		postfile.accessed[usernum] = FILE_READ|FILE_OWND;
*/
	clear();

	move(3, 0);
	show_board_info(currboard);

	move(0, 0);
	prints(NA, POST_CURRBRD_POST, currboard);

	(void)sprintf(fname, "boards/%s/", currboard);
	in_mail = NA;
	buildfile(fname);
	(void)strncpy(postfile.filename, fname, 20);
	postfile.date = time(NULL);
	(void)sprintf(genbuf, "boards/%s/%s", currboard, fname);

/* oocat */
        if(strcmp(currboard,"talk"))
        {
        }
        else
        bbsrc_update(atoi(postfile.filename+2),FILE_READ);
        
	if (oldfile->title[0])
	{
		if (strstr(oldfile->title, "Re: ") == oldfile->title)
			(void)strcpy(buf, oldfile->title);
		else
			(void)sprintf(buf, "Re: %s", oldfile->title);
	    	if (get_title(buf, postfile.title) == QUITPOST)
	      		return 0;

		ans = getans(1, 0, POST_ASK_ORIG, 'y');

		if (ans == 'y' || ans == 'a')
		{
			(void)sprintf(oldbuf, "boards/%s/%s", currboard, 
				oldfile->filename);
			include_old(genbuf, oldbuf, ans);
	    	}
	}
	else if (get_title(NULL, postfile.title) == QUITPOST)
/*	{        unlink(genbuf); */
		return 0;
/*		} */
	(void)strncpy(save_title, postfile.title, STRLEN);
	in_mail = NA;

	if (check_setting(currboard, BHD_ANONYMOUS))
	{
		(void)strcpy(postfile.sender, "Anonymous");
		postfile.flag |= FILE_LOCAL;
	}
	else
		(void)strncpy(postfile.sender, cuser.userid, 76);

	savemode = uinfo.mode;
	BACKUP(uinfo.ptcb, saveptcb);
	changemode(POSTING);
	(void)save_backinfo('P', save_title, currboard, YEA);
	aborted = vedit(genbuf, YEA);
	RESTORE(uinfo.ptcb, saveptcb);
	changemode(savemode);
	clear();
        if (aborted == LOCALSAVE)
		postfile.flag |= FILE_LOCAL;

	if (aborted && aborted != LOCALSAVE)
	{
		if (stat(genbuf, &st) != -1)
	      		(void)unlink(genbuf);
/*		clear();
*/		return FULLUPDATE;
	}
	sprintf(genbuf, PATH_BRDDIR, currboard, FHDIR);
	if (append_record(genbuf, (char *)&postfile, sizeof(postfile)) == -1)
	{
		(void)unlink(postfile.filename);
		prints(NA, POST_POSTERROR, ADMIN);
		pressreturn();
		clear();
		return FULLUPDATE;
	}
#ifdef	BBSTONEWS
	if (aborted != LOCALSAVE)
	{
		if (append_transform(&postfile) == -1)
		{
			prints(NA, POST_ERRTRANSFORM, ADMIN);
			pressreturn();
			clear();
		}
	}
#endif
	prints(NA, POST_POSTSUCCESS, currboard);
	if (!check_setting(currboard, BHD_NOCOUNT))
		cuser.numposts++;
	UPDATE;
	pressreturn();
	return FULLUPDATE;
}

int	do_reply(oldfile)
fhd	*oldfile;
{
	char 	ans;

	clear();
	ans = getans(1, 0, "�^�H ([1;33mB[m)�Q�װ�, ([1;33mA[m)�@��, ([1;33mF[m)����, ([1;33mE[m)���~, ([1;33mQ[m)���? [[1;34mB[m]: ",
		'b');
	
	switch(ans)
	{
		case 'b':
			return do_post(oldfile);
		case 'a':
			return do_reply_auth(oldfile);
		case 'f':
			return do_reply_forward(oldfile, NA);
		case 'e':
			return do_reply_forward(oldfile, YEA);
		default:
			return 0;
	}
}

#ifdef BBSTONEWS
void	cancelpost(board, file, userid)
char	*board, 
	*file, 
	*userid;
{
	FILE	*fh;
	char	from[STRLEN], 
		path[STRLEN], 
		genbuf[256],
		*ptr;
	int	len;

	(void)sprintf(genbuf, "boards/%s/%s", board, file);
	if ((fh = fopen(genbuf, "r")) != NULL)
	{
		from[0] = path[0] = '\0';

		while (fgets(genbuf, sizeof(genbuf), fh) != NULL)
		{
			len = strlen(genbuf) - 1;
			genbuf[len] = '\0';

            		if (len <= 8)
			{
                		break;
            		}
			else if (strncmp(genbuf, "�o�H�H: ", 8) == 0)
			{
				if ((ptr = strrchr(genbuf, ',')) != NULL)
					*ptr = '\0';
				(void)strcpy(from, genbuf + 8);
			}
			else if (strncmp(genbuf, "��H��: ", 8) == 0)
			{
				(void)strcpy(path, genbuf + 8);
			}
		}

		(void)fclose(fh);
		(void)sprintf(genbuf, "%s\t%s\t%s\t%s\t%s\n", board, file, userid, 
			 from, path);

		if ((fh = fopen("cancelpost.lst", "a")) != NULL)
		{
			(void)fputs(genbuf, fh);
			(void)fclose(fh);
		}
	}
}
#endif /* BBSTONEWS */

int	sequent_messages(fptr)
fhd	*fptr;
{
	static	int	idc;
	int	ans;
	char	genbuf[STRLEN];

	if (fptr == NULL)
	{
		idc = 0;
		return 0;
	}
	idc++;
	if (idc < sequent_ent)
		return 0;
	if (bbsrc_ifread(atoi(fptr->filename+2)) && (fptr->date > visit_date))
		return 0;

	prints(NA, "Read Message on board '%s' entitled:\n\"%s\" posted by %s.\n", 
		currboard, fptr->title, fptr->sender);

	ans = getans(3, 0, "(Yes or No or Quit) [Y]: ", 'y');
	if (ans != 'y')
	{
		clear();
		if (ans == 'q')
			return QUIT;
		return 0;
	}
	(void)sprintf(genbuf, "boards/%s/%s", currboard, fptr->filename);
	bbsrc_update(atoi(fptr->filename+2), FILE_READ);
#ifdef NOREPLY
	more(genbuf, YEA);
#else
	more(genbuf, NA);

	if (haspostperm(currboard))
	{
		ans = getans(t_lines-1, 0, "Reply (Y/N)? [N]: ", 'n');
		if (ans == 'y')
			(void)do_reply(fptr);
	}
	else
		pressreturn();
#endif
	clear();
	return 0;
}

/* ARGSUSED */
int	read_faq(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	List	*t_head = L_head,
		*t_tail = L_tail;

	L_head = L_tail = NULL;
	faqview(currboard);
	L_head = t_head;
	L_tail = t_tail;

	return FULLUPDATE;
}

/* ARGSUSED */
int	read_edinfo(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	if (!islocalbm())
	{
		bell(1);
		return DONOTHING;
	}
	edit_board_info(currboard);
	return FULLUPDATE;
}

/* ARGSUSED */
int	read_fullvisit(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	bhd	cboard;
	fhd	file;
	bbsrc	record;
	inner	tag;
	struct	stat	fst;
	char	genbuf[STRLEN];
	int	pos;

	if (search_board(&cboard, currboard, cmpbname) <= 0)
		return DONOTHING;

	sprintf(genbuf, "boards/%s/.DIR", currboard);
	if (stat(genbuf, &fst) < 0)
		return DONOTHING;
	get_record(genbuf, &file, sizeof(fhd), (fst.st_size/sizeof(fhd)));
	sprintf(genbuf, PATH_BBSRC, cuser.userid);
	pos = search_record(genbuf, (char *)&record, sizeof(bbsrc), cmprcbid,
		cboard.flownum);
	memset(&record, 0, sizeof(bbsrc));
	record.visit = file.date;
	record.vname = atoi(file.filename + 2);
	record.b_flow = cboard.flownum;
	record.keys[MAXRECS-2] = 1;
	record.keys[MAXRECS-1] = - (atoi(file.filename + 2));
	if (pos > 0)
		switch_record(genbuf, (char *)&record, sizeof(bbsrc), pos);
	else
		append_record(genbuf, (char *)&record, sizeof(bbsrc));
	bbsrc_init(&record, cboard.flownum);
	return PARTUPDATE;
}

int	read_visit(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	bhd	cboard;
	bbsrc	record;

	if (search_board(&cboard, currboard, cmpbname))
	{
		bbsrc_restore();
		visit_board(&cboard);
		bbsrc_init(&record, cboard.flownum);
		visit_date = record.visit;
		return PARTUPDATE;
	}
	return DONOTHING;
}

/* ARGSUSED */
int	read_info(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	move(3, 0);
	clrtobot();
	show_board_info(currboard);
	pressreturn();
	return FULLUPDATE;
}

/* ARGSUSED */
int	read_do_post(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
       fhd	oldfile;

       (void)memset(&oldfile, 0, sizeof(oldfile));
       (void)do_post(&oldfile);

       return FULLUPDATE;
}

/* ARGSUSED */
int	cook_announce(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	char	*t, 
		buf[STRLEN], 
		buf1[STRLEN],
		genbuf[STRLEN],
		filebuf[STRLEN];
	struct	stat	st;

	if (HAS_PERM(PERM_LOCALBM) && (islocalbm() || uinfo.mode == RMAIL))
	{
        	(void)strcpy(buf, direct);

        	if (t = strrchr(buf, '/'))
          		*t = '\0';

        	(void)sprintf(genbuf, "%s/%s", buf, finfo->filename);
		(void)strcpy(buf1, "test");
		getdata(t_lines-1, 0, "��J�ɦW�G", buf1, 20, DOECHO, NA);
		buf1[strlen(buf1)] = '\0';
		(void)sprintf(filebuf, "tmp/bd.%s.%s",cuser.userid, buf1);

		if ((buf1[0] == '\0') ||(stat(filebuf, &st) != -1))
		{
			move(t_lines-1, 0);
			prints(NA, "�ɮפw�g�s�b, �Э��s�]�w filename..%s", 
				" �����N���~��..");
			egetch();
			move(t_lines-1, 0);
			clrtoeol();

			return PARTUPDATE;
		}
		(void)sprintf(buf, "cp %s %s", genbuf, filebuf);
		(void)system(buf);
		move(t_lines-1, 0);
       		clrtoeol();

		return PARTUPDATE;
	}
	else
	{
       		bell(1);

        	return DONOTHING;
	}
}

/* ARGSUSED */
int	read_post(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	char	*t, 
		buf[STRLEN],
		genbuf[STRLEN];

/*	clear();
	clrtoeol();
	refresh();
*/	(void)strcpy(buf, direct);

	if (t = strrchr(buf, '/'))
		*t = '\0';

	(void)sprintf(genbuf, "%s/%s", buf, finfo->filename);

	if (strstr(finfo->title, "Re: ") == finfo->title)
		(void)strcpy(currtitle, finfo->title+4);
	else
		(void)strcpy(currtitle, finfo->title);
	bbsrc_update(atoi(finfo->filename+2), FILE_READ);

#ifndef NOREPLY
	more(genbuf, NA);
#else
        more(genbuf, YEA);
#endif
#ifndef NOREPLY
	move(t_lines-1, 0);
	clrtoeol();
	prints(NA, "\[�\\Ū�峹]  %s  %s  %s",
		"[[1;33mR[m] �^�H  [[1;33mQ[m|[1;33mEnter[m|[1;33m��[m] ����",
		"[[1;33m��[m] �W�@��   [[1;33mSpace[m|[1;33m��[m|[1;33m��[m]",
		"�U�@�� ");

	switch(egetch())
	{
        	case ' ':	case 'j':
		case KEY_RIGHT:	case KEY_DOWN:
			return READ_NEXT;
        	case KEY_UP:
			return READ_PREV;
		case 'Y':	case 'R':
		case 'y':	case 'r':
			if (haspostperm(currboard))
			{
				(void)do_reply(finfo);
				break;
			}
			else break;
        	default:
			break;
	}
	prints(NA, "\n");
#endif

	return FULLUPDATE;
}

/* ARGSUSED */
int	edit_post(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	char	buf[512],
		genbuf[STRLEN],
		*t;
	int	owned;

	owned = p_owned(finfo->sender, cuser.userid);

	if (!owned && !islocalbm())
	{
		bell(1);
		return DONOTHING;
	}
	(void)strcpy(buf, direct);
	if (t = strrchr(buf, '/'))
		*t = '\0';
	(void)sprintf(genbuf, "%s/%s", buf, finfo->filename);
	(void)save_backinfo('P', finfo->title ,currboard, NA);
	(void)vedit(genbuf, NA);
	return FULLUPDATE;
}

/* ARGSUSED */
int	mark_post(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	char	genbuf[STRLEN];
	struct	stat	st;

	if (!islocalbm())
	{
		bell(1);
		return DONOTHING;
	}

	sprintf(genbuf, PATH_BRDDIR, currboard, finfo->filename);
	stat(genbuf, &st);
	if (finfo->flag & FILE_MARKED)
	{
		st.st_mode |= S_IRGRP;
		finfo->flag &= ~FILE_MARKED;
	}
	else
	{
		st.st_mode &= ~S_IRGRP;
		finfo->flag |= FILE_MARKED;
	}
	chmod(genbuf, st.st_mode);
    	switch_record(direct, (char *)finfo, sizeof(*finfo), *ent);

    	return PARTUPDATE;
}

/* ARGSUSED */
int	del_range(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	char	num1[10], 
		num2[10];
	int	inum1, 
		inum2, 
		ans;

	if ((uinfo.mode == READING) && !islocalbm())
	{
		bell(1);
		return DONOTHING;
    	}

	clear();
	prints(NA, "Delete RANGE(�]�w�R���ɭ�)\n");
	getdata(1, 0, "���R���_�l�峹�s��: ", num1, 10, 
		DOECHO, YEA);
	inum1 = atoi(num1);
	if (inum1 <= 0)
	{
		prints(NA, "Invalid Low range number �_�l�峹�s���]�w���~\n");
		pressreturn();
		return FULLUPDATE;
	}
	getdata(2, 0, "���R�������峹�s��: ", num2, 10, 
		DOECHO, YEA);

	inum2 = atoi(num2);
	if (inum2 <= inum1)
	{
		prints(NA, "Invalid High range number �����峹�s���]�w���~\n");
		pressreturn();
		return FULLUPDATE;
	}

	ans = getans(3, 0, "Are You Sure? �T�{ (Yes, or No) [N]: ", 'n');
	if (ans == 'y')
	{
		delete_range(direct, inum1, inum2);
		fixkeep(direct, inum1);
		prints(NA, "Delete Complete\n");
		pressreturn();
		return FULLUPDATE;
	}

	prints(NA, "Delete Aborted\n");
	pressreturn();

	return FULLUPDATE;
}

/* ARGSUSED */
int	move_post(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	char	ans, 
		newboard[512], 
		movefrom[STRLEN], 
		moveto[STRLEN], 
		fname[STRLEN], 
		genbuf[STRLEN];
	int	owned;
	fhd	newfile;
	List	*t_head,
		*t_tail;

	owned = p_owned(finfo->sender, cuser.userid);

	if (!owned && !islocalbm())
	{
		bell(1);
		return DONOTHING;
	}

	{
	move(0, 0);
	clrtobot();
	prints(NA, "Move Message '%s' on Board %s.", finfo->title, currboard);
	genbuf[0] = 'n';
	ans = getans(1, 0, "(Yes, or No) [N]: ", 'n');

	if (ans != 'y')
	{
		move(2, 0);
		prints(NA, "Quitting Move Post\n");
		pressreturn();
		clear();
		return FULLUPDATE;
	}
	move(1, 0);
	clrtoeol();
	}
	newboard[0] = '\0';

	t_head = L_head;
	t_tail = L_tail;
	L_head = L_tail = NULL;
	name_query("��J�h�E�ت��Q�װ�: ", newboard, make_blist);
	L_head = t_head;
	L_tail = t_tail;

	if ((*newboard == '\0') || (!strcmp(newboard, currboard)) ||
		!haspostperm(newboard))
	{
		move(2, 0);
		clrtoeol();
		prints(NA, "�h�E�ت����s�b, �άO�L POST �v��\n");
		pressreturn();

		return FULLUPDATE;
	}

	(void)memcpy(&newfile, finfo, sizeof(fhd));
	(void)sprintf(fname, "boards/%s/", newboard);
	buildfile(fname);
	(void)strncpy(newfile.filename, fname, 20);
	newfile.date = time(NULL);
	(void)sprintf(movefrom, "boards/%s/%s", currboard, finfo->filename);
	(void)sprintf(moveto, "boards/%s/%s", newboard, fname);

	sprintf(genbuf, PATH_BRDDIR, newboard, FHDIR);
	if (append_record(genbuf, (char *)&newfile, sizeof(newfile)) == -1)
	{
		move(3, 0);
		prints(NA, "Updating board %s cache Error\n", newboard);
		pressreturn();
		return FULLUPDATE;
	}

        if (!delete_file(direct, sizeof(fhd), *ent, cmpfilename,
		finfo->filename))
	{
#ifdef	BBSTONEWS
		cancelpost(currboard, finfo->filename, cuser.userid);
#endif
		copyto(movefrom, moveto);
		(void)unlink(movefrom);
	}
	else
	{
                move(3, 0);
                prints(NA, "Delete Source Cache Failure\n");
		prints(NA, "Press use 'd' to delete it\n");
        }
	pressreturn();
	return FULLUPDATE;
}

/* ARGSUSED */
int	del_post(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	char	buf[512],
		genbuf[STRLEN],
		*t;
	int	owned,
		ans;
	struct	stat	pst;

	owned = p_owned(finfo->sender, cuser.userid);

        if (!owned && !islocalbm())
	{
		bell(1);
		return DONOTHING;
	}

	clear();
	prints(NA, "Delete Message '%s'.", finfo->title);
	ans = getans(1, 0, "(Yes, or No) [N]: ", 'n');

	if (ans != 'y')
	{
		move(2, 0);
		prints(NA, "Quitting Delete Post\n");
		pressreturn();
		clear();
		return FULLUPDATE;
	}

#ifdef DELETE_AS_MOVE
	if (strcmp(REMOVEDBRD, currboard))
	{
		(void)sprintf(genbuf, "boards/%s", REMOVEDBRD);
		if (stat(genbuf, &pst) != -1 && S_ISDIR(pst.st_mode))
		{
			fhd	newfh;
			char	fname[STRLEN],
				from[STRLEN],
				to[STRLEN];

			(void)memset(&newfh, 0, sizeof(newfh));
			(void)sprintf(fname, "boards/%s/", REMOVEDBRD);
			buildfile(fname);
			newfh.date = time(NULL);
			(void)sprintf(from, "boards/%s/%s", currboard, finfo->filename);
			(void)sprintf(to, "boards/%s/%s", REMOVEDBRD, fname);
			(void)sprintf(newfh.title, "deleted by: %s", cuser.userid);

			newfh.flag |= FILE_LOCAL;
			(void)strncpy(newfh.filename, fname, 20);
			(void)strcpy(newfh.sender, finfo->sender);
			sprintf(genbuf, PATH_BRDDIR, REMOVEDBRD, FHDIR);
			if (!append_record(genbuf, (char *)&newfh,
				sizeof(newfh)))
			{
				copyto(from, to);
			}
		}
	}
#endif	/* DELETE_AS_MOVE */

	(void)strcpy(buf, direct);
	if (t = strrchr(buf, '/'))
		*t = '\0';

	if (!delete_file(direct, sizeof(fhd), *ent, cmpfilename,
		finfo->filename))
	{
#ifdef	BBSTONEWS
		cancelpost(currboard, finfo->filename, cuser.userid);
#endif
		(void)sprintf(genbuf, "boards/%s/%s", currboard, finfo->filename);
		(void)unlink(genbuf);
		pressreturn();

		if (owned)
		{
			if (cuser.numposts > 0)
			if (!check_setting(currboard, BHD_NOCOUNT))
				cuser.numposts--;
			UPDATE;
		}

		return FULLUPDATE;
	}

	move(2, 0);
	prints(NA, "Delete failed\n");
	pressreturn();
	clear();

	return FULLUPDATE;
}

/* ARGSUSED */
int	sequential_read(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	char	genbuf[STRLEN];

	clear();
	(void)sequent_messages(finfo);
	sequent_ent = *ent;
	quiting = NA;
	sprintf(genbuf, PATH_BRDDIR, currboard, FHDIR);
	apply_record(genbuf, sequent_messages, sizeof(fhd));

	return FULLUPDATE;
}

/* ARGSUSED */
int	title_change(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{    
	char	buf[STRLEN];
	int	owned;

	owned = p_owned(finfo->sender, cuser.userid);

	if (!owned && !islocalbm())
	{
        	bell(1);
        	return DONOTHING;
	}
	if (!strcmp(cuser.userid, GUEST)) 
        	return DONOTHING;

	(void)strcpy(buf, finfo->title);
	getdata(t_lines-1, 0, "�]�w�s�D�D�G", buf, STRLEN, DOECHO, NA);
	if (buf[0])
        	(void)strcpy(finfo->title, buf);

	switch_record(direct, (char *)finfo, sizeof(*finfo), *ent);

	return PARTUPDATE;
}

/* ARGSUSED */
int	unread_post(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	if (bbsrc_ifread(atoi(finfo->filename+2)))
		bbsrc_update(atoi(finfo->filename+2), FILE_UNREAD);
	else
		bbsrc_update(atoi(finfo->filename+2), FILE_READ);

	return PARTUPDATE;
}

/* ARGSUSED */
int	cross_post(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	fhd	xfile;
	char	fname[STRLEN],
		xboard[STRLEN],
		xfname[STRLEN],
		saveptcb[20],
		linebuf[STRLEN];
	int	ignore = YEA,
		aborted,
		ans,
		savemode;
	FILE	*fileptr,
		*xptr;
	char	*date;
	time_t	filetime;
	List	*t_head,
		*t_tail;

	if (!HAS_PERM(PERM_POST))
	{
        	bell(1);
        	move(2, 0);
        	prints(NA,"�A�|�L�v��, �b���O��K");
        /*	return DONOTHING;*/
     		return -1;
     	}

	move(1, 0);
	clrtoeol();

	t_head = L_head;
	t_tail = L_tail;
	L_head = L_tail = NULL;
	name_query("�ƻs��K�Q�װϡG", xboard, make_blist);
	L_head = t_head;
	L_tail = t_tail;
	if (*xboard == '\0' || !haspostperm(xboard))
		return FULLUPDATE;
	(void)memset(&xfile, 0, sizeof(xfile));
	(void)sprintf(xfname, POST_CROSSPOST,	finfo->title);
	ans = getans(2, 0, xfname, 'n');
	if (ans == 'n')
		return FULLUPDATE;
	if (ans == 'l')
		xfile.flag |= FILE_LOCAL;
        (void)sprintf(fname, "boards/%s/%s", currboard, finfo->filename);
	if ((fileptr = fopen(fname, "r")) == NULL)
		return FULLUPDATE;
/*
	�令 bbsrc_update() �]�w���wŪ
       	xfile.accessed[usernum] = FILE_READ|FILE_OWND;
 */
	(void)sprintf(xfname, "boards/%s/", xboard);
	buildfile(xfname);
	(void)strncpy(xfile.filename, xfname, 20);
	(void)sprintf(xfname, "boards/%s/%s", xboard, xfile.filename);
	xfile.date = time(NULL);

	if (check_setting(currboard, BHD_ANONYMOUS))
	{
		(void)strcpy(xfile.sender, "Anonymous");
		xfile.flag |= FILE_LOCAL;
	}
	else
		(void)strncpy(xfile.sender, cuser.userid, STRLEN);
	(void)sprintf(xfile.title, "%s", finfo->title);
	(void)strcpy(save_title, xfile.title);

	if ((xptr = fopen(xfname, "w")) == NULL)
	{
		(void)fclose(fileptr);
		return FULLUPDATE;
	}

        if (ans != 'e')
	{
		(void)strcpy(linebuf, currboard);
		(void)strcpy(currboard, xboard);
		(void)write_header(xptr);
		(void)strcpy(currboard, linebuf);
	}

	filetime = finfo->date;
	date = Ctime(&filetime);

	(void)fprintf(xptr, "[ ��������� %s �Q�װ� ]\n", currboard);
	(void)fprintf(xptr, "[ �����@�̬O: %s ]\n", finfo->sender);
	(void)fprintf(xptr, "[ �o���ɶ���: %s ]\n\n", date);

        while (fgets(linebuf, sizeof(linebuf), fileptr) != NULL) 
	{
		if (ignore)
		{
			if (strstr(linebuf, "\n") == linebuf)
				ignore = NA;
			continue;
		}
		(void)fprintf(xptr, "%s", linebuf);
	}

        (void)fclose(fileptr);
	(void)fclose(xptr);
   	in_mail = NA;
	savemode = uinfo.mode;
	BACKUP(uinfo.ptcb, saveptcb);
	changemode(POSTING);
	if (ans=='E' || ans=='e')
	{
		(void)save_backinfo('P', save_title, xboard, YEA);
		aborted = vedit(xfname, YEA);
	}
	else
		aborted = NA;
	RESTORE(uinfo.ptcb, saveptcb);
	changemode(savemode);
	clear();

	xfile.date = time(NULL);
/* oocat */

         if(aborted != LOCALSAVE)
         {
            if (append_transform(&xfile)==-1)
            {
              prints(NA,POST_ERRTRANSFORM,ADMIN);
              pressreturn();
              clear();
            }
            
         }     



	if (aborted == LOCALSAVE)
	{
		xfile.flag |= FILE_LOCAL;
		aborted = NA;
	}

	if (aborted)
	{
		pressreturn();
/*		clear();
*/		return FULLUPDATE;
	}

	sprintf(linebuf, PATH_BRDDIR, xboard, FHDIR);
	if (append_record(linebuf, (char *)&xfile, sizeof(xfile)) == -1)
	{
		pressreturn();
/*		clear();
*/		return FULLUPDATE;
	}
	prints(NA, "File Posted\n");
	if (!check_setting(currboard, BHD_NOCOUNT))
		cuser.numposts++;
	UPDATE;
	pressreturn();

	return FULLUPDATE;
}

/* ARGSUSED */
int	reply_post(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
        clear();
	bbsrc_update(atoi(finfo->filename+2), FILE_READ);
        (void)do_reply(finfo);

        return FULLUPDATE;
}

/* ARGSUSED */
int	read_match_auth(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	(void)strcpy(match, finfo->sender);
	move(t_lines-1, 0);
	prints(NA, "�]�w�M��G%s", match);
	return RESET_MATCH;
}

/* ARGSUSED */
int	read_match_title(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	if (strstr(finfo->title, "Re: ") == finfo->title)
		(void)strcpy(match, finfo->title + 4);
	else
		(void)strcpy(match, finfo->title);
	move(t_lines-1, 0);
	prints(NA, "�]�w�M��G%s", match);
	return RESET_MATCH;
}

/* oocat add */

int del_vote_res()
{
int ans;
char genbuf[STRLEN];

	if(!islocalbm())
	{
	   bell(1);
	   return DONOTHING;
	}

   (void)sprintf(genbuf,PATH_VOTE_RES,currboard);
   move(3,0);
   clrtobot();
   ans=getans(3,0," �n�R���벼�p���e����?? (y/n) :",'n');
   
   if(ans=='y')
   {
      (void)unlink(genbuf);
      move(5,0);
      prints(NA,"�w�R������\n");
      pressreturn();
      return FULLUPDATE;
    }
    pressreturn();
    return FULLUPDATE;
}         


/* ARGSUSED */



int	read_vote_open(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	if (!islocalbm())
	{
		bell(1);
		return DONOTHING;
	}

	vote_open(currboard);
	return	FULLUPDATE;
}

/* ARGSUSED */
int	read_vote_result(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	char	genbuf[STRLEN];

	(void)sprintf(genbuf, PATH_VOTE_RES, currboard);
	more(genbuf);
	return	FULLUPDATE;
}

/* ARGSUSED */
int	read_vote_follow(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	vote_join(currboard);
	return	FULLUPDATE;
}

/* ARGSUSED */
int	read_search_backward(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	int	curr,
		top,
		i,
		tmp;
	char	author[STRLEN],
		title[STRLEN],
		sbuf[STRLEN],
		genbuf[STRLEN];
	fhd	fhbuf[SCRLN];

	if (*ent <= 1)
		return DONOTHING;

  	(void)strcpy(genbuf, match);
  	 if(match_flag)
	getdata(t_lines-1, 0, "���e�M��G", genbuf, 70, DOECHO, NA); 

	if (genbuf[0] == '\0')
	{
		move(t_lines-1, 0);
		clrtoeol();
		return DONOTHING;
	}
	(void)strcpy(match, genbuf);
	(void)strcpy(sbuf, strtolow(genbuf));
	tmp = (*ent)--;

	move(t_lines-1, 0);
	clrtoeol();

	while (1)
	{
		curr = *ent - 1;
		if (curr <= 0)
			break;
		top = (curr/SCRLN)*SCRLN;
		if (top < 0)
			top = 0;
		get_records(direct, fhbuf, sizeof(fhd), top+1, curr-top+1);
		for (i = curr; i >= top; i--)
		{
			(void)strcpy(author, strtolow(fhbuf[i-top].sender));
			(void)strcpy(title, strtolow(fhbuf[i-top].title));
			move(t_lines-1, 0);
			
			if(!match_flag)
			 prints(NA,"��M��Ƥ�.....");
			else
			{prints(NA, "�ثe����� %4d �����", i+1);
			refresh(); 
			if (kbhit() == 'q')
			{
				*ent = tmp;
				return PARTUPDATE;
			}
			}
			
			if (strstr(author, sbuf) || strstr(title, sbuf))
			{
				*ent = i + 1;
				return READ_RELOAD;
			}
		}
		*ent = i + 1;
	}
	*ent = tmp;
	return PARTUPDATE;
}

/* ARGSUSED */
int	read_query(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	if (strchr(finfo->sender, '@') || !searchuser(finfo->sender))
		return DONOTHING;
	clear();
	show_plan(YEA, finfo->sender, prints);
	pressreturn();
	return FULLUPDATE;
}

/* ARGSUSED */
int	read_search_forward(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	int	curr,
		bottom,
		i,
		total,
		tmp;
	char	author[STRLEN],
		title[STRLEN],
		sbuf[STRLEN],
		genbuf[STRLEN];
	fhd	fhbuf[SCRLN];

	total = get_num_records(direct, sizeof(fhd));

	if (*ent >= total)
		return DONOTHING;
	(void)strcpy(genbuf, match);
	
	if(match_flag)
	getdata(t_lines-1, 0, "����M��G", genbuf, 70, DOECHO, NA);
	if (genbuf[0] == '\0')
	{
		move(t_lines-1, 0);
		clrtoeol();
		return DONOTHING;
	}
	(void)strcpy(match, genbuf);
	(void)strcpy(sbuf, strtolow(genbuf));
	tmp = *ent;

	move(t_lines-1, 0);
	clrtoeol();

	while (1)
	{
		curr = *ent;
		if (curr >= total)
			break;
		bottom = (curr / SCRLN + 1) * SCRLN;
		if (bottom >= total)
			bottom = total;
		get_records(direct, fhbuf, sizeof(fhd), curr+1, bottom-curr);
		for (i = curr;  i < bottom; i++)
		{
			move(t_lines-1, 0);
			(void)strcpy(author, strtolow(fhbuf[i-curr].sender));
			(void)strcpy(title, strtolow(fhbuf[i-curr].title));
			if(!match_flag)
			prints(NA, "��M���ing ...");
			else {
			prints(NA, "�ثe����� %4d �����", i+1);
			refresh();
			if (kbhit() == 'q')
			{
				*ent = tmp;
				return PARTUPDATE;
			}
			}
			if (strstr(author, sbuf) || strstr(title, sbuf))
			{
				*ent = i + 1;
				return READ_RELOAD;
			}
		}
		*ent = i;
	}
	*ent = tmp;
	return PARTUPDATE;
}


int     read_search_title_forward(ent, finfo, direct)
int     *ent;
fhd     *finfo;
char    *direct;
{
        int save_return,total;
 
        total = get_num_records(direct, sizeof(fhd));
 
        if (*ent >= total)
                return DONOTHING;
 
        read_match_title(ent,finfo,direct);
/*      move(t_lines-1, 0);
        clrtoeol();  ��n�ڭ̦bsearch function �̦��@�w�M�����@�q,���B�i�� */
        match_flag=FALSE;
        save_return=read_search_forward(ent,finfo,direct);
        match_flag=TRUE; /*��_ */
        return save_return;
}
 
int     read_search_title_backward(ent, finfo, direct)
int     *ent;
fhd     *finfo;
char    *direct;
{
        int save_return;
 
        if (*ent <= 1)
                return DONOTHING;
/* �o�Ө��i�H���L�� read_search_backward�̦A��,���L...
   ���@�ٮ�! ,�`�N�o�̸� forward ���P,(�@�Ӧb�B�z�Ĥ@�ʨҥ~
   �@�Ӧb�B�z�̫�@�ʨҥ~! */
 
        read_match_title(ent,finfo,direct);
/*        move(t_lines-1, 0);
        clrtoeol();  ��n�ڭ̦bsearch function �̦��@�w�M�����@�q,���B�i�� */
        match_flag=FALSE;
        save_return=read_search_backward(ent,finfo,direct);
        match_flag=TRUE; /*��_ */
        return save_return;
}
 
 
 










#ifdef INTERNET_EMAIL
/* ARGSUSED */
int	forward_post(ent, finfo, direct)
int	*ent;
fhd	*finfo;
char	*direct;
{
	fhd	mailinfo;

	convert_mail(finfo, &mailinfo);
	return(mail_forward(ent, &mailinfo, direct));
}
#endif

one_key	read_comms[] =
{
	'?',		read_match_auth,
	'/',		read_match_title,
	'+',		read_search_forward,
	'-',		read_search_backward,
	'[',		read_search_title_backward,
	']',		read_search_title_forward,
	CTRL('P'), 	read_do_post, 
	'A', 		read_vote_open, 
	'D', 		del_range, 
	'c', 		del_vote_res,
	'E', 		edit_post, 
#ifdef INTERNET_EMAIL
	'F', 		forward_post, 
#endif
	'W',		read_edinfo,
	'M', 		move_post, 
	'O', 		read_vote_result,
	'Q',		read_query,
	'R', 		reply_post, 
	'S', 		sequential_read, 
	'T', 		title_change, 
	'V', 		read_vote_follow,
	'a', 		cook_announce, 
	'd', 		del_post, 
	'f',		read_fullvisit,
	'h', 		read_help, 
	'i',		read_info,
	'm', 		mark_post, 
	'r', 		read_post,
	'\n',		read_post,
	'\r',		read_post,
	KEY_RIGHT,	read_post,
	's', 		do_select, 
	'v',		read_visit,
	'x', 		cross_post, 
	'z', 		unread_post, 
	'\t', 		read_faq, 
	'\0', 		NULL, 
};

int	Read()
{
	int	savemode,
		looping = 0,
		pos;
	bhd	cbhd;
	acc	bacc;
	bbsrc	readmark;
	char	genbuf[STRLEN];
	struct	stat	bst;

	if (!selboard)
	{
		move(2, 0);
		prints(NA, "�Х���ܰQ�װ�");
		return -1;
	}

	savemode = uinfo.mode;
	if (!check_setting(currboard, BHD_MYSTERY))
	(void)strncpy(uinfo.ptcb, currboard, 20);
	changemode(READING);
	in_mail = NA;

	do
	{
		search_board(&cbhd, currboard, cmpbname);
		pos = search_acc(&bacc, cbhd.flownum);
		(void)sprintf(genbuf, PATH_BRDDIR, currboard, ".INFO");
		if (pos && stat(genbuf, &bst) != -1 &&
			bacc.date < bst.st_mtime)
		{
			bacc.date = acclist[pos-1].date = bst.st_mtime;
			load_acclist(YEA);
			(void)sprintf(genbuf, PATH_ACCESS, cuser.userid);
			switch_record(genbuf, (char *)&bacc, sizeof(acc), pos);
			clear();
			move(3, 0);
			show_board_info(currboard);
			pressreturn();
		}
/*		if (looping)
			bbsrc_restore();
		else
			looping = YEA;
*/		(void)sprintf(genbuf, PATH_BBSRC, cuser.userid);
		if ((pos = search_record(genbuf, (char *)&readmark,
			sizeof(bbsrc), cmprcbid, cbhd.flownum)) <= 0)
		{
			(void)memset((char *)&readmark, 0, sizeof(bbsrc));
		}
		bbsrc_init(&readmark, cbhd.flownum);
		(void)sprintf(genbuf, PATH_BRDDIR, currboard, FHDIR);
	}
	while (i_read(genbuf, readtitle, readdoent, &read_comms[0],
		CTRL('P'), sizeof(fhd), get_num_records, get_records) ==
		REDOIREAD);
	bbsrc_restore();
	(void)memset(uinfo.ptcb, 0, sizeof(uinfo.ptcb));
	changemode(savemode);
	move(2, 0);
	clrtoeol();
	return 0;
}
