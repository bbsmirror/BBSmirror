#include "stdafx.h"

int Cbbs::LoadFile ( char* szFilename )
{
FILE** fp;
int i = 0;

	fp = GetFreeFP();
	if( !fp )
		return 0;

	*fp = fopen(szFilename, "r");

	if( *fp )
		for( ; i < 1000, fgets(szBuffer[i], 120, *fp); i++ )
			StripNewLine(szBuffer[i]);

	ReleaseFP(fp);

	return i;
}

bool Cbbs::SaveToFile ( char* szFilename, int nTotal, bool bAppend )
{
FILE** fp;

	fp = GetFreeFP();
	if( !fp )
		return false;

bool bRet = false;

	if( *fp = fopen(szFilename, bAppend ? "a" : "w") )
	{
		for( int i = 0; i <= nTotal; i++ )
		{
			fprintf(*fp, "%s", szBuffer[i]);
			if( i != nTotal )
				fprintf(*fp, "\n");
		}
		bRet = true;
	}

	ReleaseFP(fp);

	return bRet;
}

void Cbbs::ReplyFile ( char* szIn, char* szOut, int nMode, char* szOwner, char* szNickname )
// 0 Y 2 All 3 Repost
{
	if( nMode == 1 )
		return ;

FILE** fpin;
FILE** fpout;
char szTemp[DATASIZE];
int i = -1;

	fpin = GetFreeFP();
	if( !fpin )
		return ;
	*fpin = fopen(szIn, "r");

	fpout = GetFreeFP();
	if( !fpout )
		return ;
	*fpout = fopen(szOut, "w");

	if( *fpin && *fpout )
	{
		fprintf(*fpout, "�� �ޭz�m%s (%s)�n���ʨ��G\n", szOwner, szNickname);

	bool bBreak = false;
		while( fgets(szTemp, 120, *fpin) && !bBreak )
		{
			i++;
			StripNewLine(szTemp);

			switch( nMode )
			{
				case 2:
					::InsertChar(szTemp, 0, ' ');
					::InsertChar(szTemp, 0, ':');
					break;

				case 3:
					break;

				default:
					if( !strcmp(szTemp, "--") )
						bBreak = true;
					if( !strncmp(szTemp, ": �� ", 5) || !strncmp(szTemp, ": : ", 4) || !strlen(szTemp) )
						continue;
					if( i == 0 && !strncmp(szTemp, "�@��: ", 6) )
						continue;
					if( i == 1 && !strncmp(szTemp, "���D: ", 6) )
						continue;
					if( i == 2 && !strncmp(szTemp, "�ɶ�: ", 6) )
						continue;
					else
						::InsertChar(szTemp, 0, ' ');
						::InsertChar(szTemp, 0, ':');
			}

			if( !bBreak )
			{
				szTemp[80] = 0;
				fprintf(*fpout, "%s\n", szTemp);
			}
		}
	}

	ReleaseFP(fpin);
	ReleaseFP(fpout);
}

static void EditOuts ( Cbbs* bbs, char* sz, int nMax = 79, bool bNewLine = false )
{
char szTemp[DATASIZE];

	strcpy(szTemp, sz);
	for( int i = 0; i < DATASIZE, szTemp[i]; i++ )
		if( szTemp[i] == '\033' )
			szTemp[i] = '*';
	szTemp[nMax + 1] = 0;
	strcpy(strchr(szTemp, 0), "\033[K");

	if( bNewLine )
		strcpy(strchr(szTemp, 0), "\r\n");

	bbs->outs(szTemp);
}

int Cbbs::Edit ( char* szFilename, int nMode, char* szTitle )
{
int c;
static char *szFileCmd[] = {"S�x�s", "A���", "T����D", "E�~��", "B�Ȧs��"};
static char *szBufCmd[] = {"Q���}", "RŪ��", "W�g�J", "D�R��"};

bool bInsert = false;

int i;

char szTemp[DATASIZE];

bool bToBreak = false;
int nRet = 0;

int nUpdateStartLine = -1;
bool bUpdate = true;
int nTotal = 0;
int nStartLine = 0;
int nLine = 0, nOldLine = 0;
int nPos = 0, nOldPos = 0;

	online->in_edit = true;

	memset(szBuffer, 0, 1000 * 120);

	if( szFilename )
		nTotal = LoadFile(szFilename);

	while(1)
	{
		if( bUpdate )
		{
			if( nUpdateStartLine == -1 )
			{
				clear();
				nUpdateStartLine = nStartLine;
			} else
				move(nUpdateStartLine - nStartLine, 0);
			for( i = nUpdateStartLine - nStartLine; i < 23; i++ )
			{
				if( (i + nStartLine) >= nTotal + 1)
				{
					outs("~\033[K\r\n");
				} else {
					EditOuts(this, szBuffer[i + nStartLine], 79, true);
				}
			}
			bUpdate = false;
			nUpdateStartLine = -1;
			move(23, 0);
			outs("\033[1;37;44m  �s��峹  \033[46m  (Ctrl+Z)���U���� (Ctrl+X)�ɮ׳B�z ��\033[m");
		}

		nOldLine = nLine;
		nOldPos = nPos;

		move(23, 50);
		prints("\033[1;37;46m %3d:%3d \033[m", nPos, nLine);

		move(nLine - nStartLine, nPos);

		c = igetkey();

		switch(c)
		{
			case KEY_LEFT:
				if( nPos )
					nPos--;
				else if( nLine )
					nPos = strlen(szBuffer[--nLine]);
				break;

			case KEY_RIGHT:
				if( !szBuffer[nLine][nPos] )
				{
					if( nLine < nTotal )
					{
						nLine++; nPos = 0;
					}
				} else nPos++;
				break;

			case KEY_UP:
				if( nLine )
					nLine--;

				if( nPos > strlen(szBuffer[nLine]) )
					nPos = strlen(szBuffer[nLine]);
				break;

			case KEY_DOWN:
				if( nLine < nTotal )
					nLine++;

				if( nPos > strlen(szBuffer[nLine]) )
					nPos = strlen(szBuffer[nLine]);
				break;

			case KEY_PGUP:
				nLine -= 23;
				if( nLine < 0 )
					nLine = 0;
				break;

			case KEY_PGDN:
				nLine += 23;
				break;

			case KEY_TAB:
				c = (nPos / 8 + 1) * 8 - nPos;
				for( i = 0; i < c; i++ )
					::InsertChar(szBuffer[nLine], nPos, ' ');

				strcpy(szTemp, szBuffer[nLine] + nPos);
				EditOuts(this, szTemp, 79 - nPos);// clrtoeol();

				nPos += c;
				break;

			case '\177':
			case Ctrl('H'):
				if( nPos )
				{
					::DeleteChar(szBuffer[nLine], nPos - 1);
					nPos--;
					move(nLine - nStartLine, nPos);
					EditOuts(this, &szBuffer[nLine][nPos], 79 - nPos);
					clrtoeol();
				} else if( !nLine )
					break;
				else {
					nLine--;
				int l = strlen(szBuffer[nLine]);

					nPos = l;
					strncpy(&szBuffer[nLine][nPos], szBuffer[nLine + 1], 119 - nPos);

					for( i = nLine + 1; i < nTotal; i++ )
						strcpy(szBuffer[i], szBuffer[i + 1]);

					nTotal--;

					nUpdateStartLine = nLine;
					bUpdate = true;
				}
				break;

			case Ctrl('A'):
				nPos = 0;
				break;

			case Ctrl('E'):
				nPos = strlen(szBuffer[nLine]);
				break;

			case Ctrl('C'):
				::InsertChar(szBuffer[nLine], nPos, 'm');
				::InsertChar(szBuffer[nLine], nPos, '[');
				::InsertChar(szBuffer[nLine], nPos, '\033');
				strcpy(szTemp, szBuffer[nLine] + nPos);
				EditOuts(this, szTemp, 79 - nPos);// clrtoeol();
				nPos += 3;
				break;

			case Ctrl('U'):
				::InsertChar(szBuffer[nLine], nPos, '\033');
				strcpy(szTemp, szBuffer[nLine] + nPos);
				EditOuts(this, szTemp, 79 - nPos);// clrtoeol();
				nPos++;
				break;

			case Ctrl('D'):
				if( szBuffer[nLine][nPos] )
				{
					::DeleteChar(szBuffer[nLine], nPos);
					EditOuts(this, &szBuffer[nLine][nPos], 79 - nPos);
					clrtoeol();
				} else if( nLine >= nTotal )
					break;
				else {
				int l = strlen(szBuffer[nLine]);

					strncpy(&szBuffer[nLine][nPos], szBuffer[nLine + 1], 120 - l);

					for( i = nLine + 1; i < nTotal; i++ )
						strcpy(szBuffer[i], szBuffer[i + 1]);

					nTotal--;

					nUpdateStartLine = nLine;
					bUpdate = true;
				}
				break;

			case Ctrl('K'):
				szBuffer[nLine][nPos] = 0;
				clrtoeol();
				break;

			case Ctrl('X'):
				clear();
				prints("%s�G%s",
							szTitle ? "���D" : "�ɮ�",
							szTitle ? szTitle : szFilename);
				switch ( SelectData(2, 0, "�ɮ׳B�z�Q", szFileCmd, 5) )
				{
					case 0:
						bToBreak = true;
						nRet = 1;

						if( szFilename )
							strcpy(szTemp, szFilename);
						else
							::SetUserFile(szTemp, cuser.userid, EDITBUF);

						SaveToFile(szTemp, nTotal);
						break;

					case 1:
						::SetUserFile(szTemp, cuser.userid, EDITBUF);
						::DeleteFile(szTemp);
						bToBreak = true;
						nRet = 0;
						break;

					case 2:
						if( szTitle )
							getdata(3, 0, "�s���D�G", szTitle, TTLEN, DOECHO, szTitle);
						break;

					case 4:
						switch( SelectData(5, 0, "�Ȧs�ɡG", szBufCmd, 4) )
						{
							case 1:
								break;

							case 2:
								break;

							case 3:
								break;
						}
						break;
				}
				bUpdate = true;
				break;

			case Ctrl('Y'):
				if( !nTotal )
					break;

				for( i = nLine + 1; i <= nTotal; i++ )
					strcpy(szBuffer[i - 1], szBuffer[i]);
				nPos = 0;
				nTotal--;

				nUpdateStartLine = nLine;
				bUpdate = true;
				break;

			case '\r':
			case '\n':
				// Beware of the line limit..
				for( i = nTotal; i > nLine; i-- )
					strcpy(szBuffer[i + 1], szBuffer[i]);

				strcpy(szBuffer[nLine + 1], &szBuffer[nLine][nPos]);
				szBuffer[nLine][nPos] = 0; clrtoeol();

				nLine++; nPos = 0;
				nTotal++;

				nUpdateStartLine = nLine - 1;
				bUpdate = true;
				break;

			default:
				if( GlobalKeys(c) )
				{
					bUpdate = true;
				} else if( ::IsValidKey(c) )
				{
					::InsertChar(szBuffer[nLine], nPos, c);
					strcpy(szTemp, szBuffer[nLine] + nPos);
					EditOuts(this, szTemp, 79 - nPos);// clrtoeol();
					nPos++;
				}
		}

		if( nLine > nTotal )
			nLine = nTotal;

		if( nPos > 80 )
			nPos = 80;

		if( nLine > (nStartLine + 22) )
		{
			nStartLine += nLine - nStartLine - 22;
			nUpdateStartLine = nStartLine;
			bUpdate = true;
		} else if( nLine < nStartLine )
		{
			nStartLine = nLine;
			nUpdateStartLine = nStartLine;
			bUpdate = true;
		}

		if( bToBreak )
			break;
	}

	online->in_edit = false;

	return nRet;
}
