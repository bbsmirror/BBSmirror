#include "stdafx.h"

void Cbbs::PutEvent ( int nEventNo, bool bSet )
{
	::EnterCriticalSection(&cs);
	EventQueue.push(nEventNo);

	if( bSet )
		::SetEvent(hKeyEvent);

	::LeaveCriticalSection(&cs);
}

void Cbbs::DoReceive ( char* sz )
{
int i = 0;
static char lastopt, lastarg;
bool bFirst = true;

	while(sz[i])
	{
		switch(sz[i])
		{
			case 27:	// ESC
				lastopt = 27;
				i++;
				break;

			case (IAC - 256):
				i += DoIAC(&sz[i]);
				break;

			case '\n':
				lastopt = '\n';
				PutEvent('\n');
				i++;
				break;

			default:
				switch(lastopt)
				{
					case 27:
						if( lastarg )
						{
						int n;

							if( (n = DoESC(lastarg, sz[i])) )
								PutEvent(n, bFirst);
							if( n >= KEY_HOME )
								i++;

							lastarg = lastopt = 0;
						} else lastarg = sz[i];
						break;

					case '\n':
						lastopt = 0;
						if( sz[i] == 0 || sz[i] == '\a' )
							continue;
						else
							PutEvent(sz[i]);
						break;

					default:
						PutEvent(sz[i]);
				}
				i++;
		}
	}
}

int Cbbs::DoIAC ( char* sz )
{
//char szTemp[256];

	switch( sz[1] )
	{
		case WILL - 256://WILL:
//			wsprintf(szTemp, "%c%c%c\0", IAC, DO, sz[2]); 
//			outs(szTemp);
//			SendMessage(hLog, LB_ADDSTRING, 0, (LPARAM)"WILL");
			return 3;

		case WONT - 256://WONT:
//			wsprintf(szTemp, "%c%c%c\0", IAC, DONT, sz[2]); 
//			outs(szTemp);
//			SendMessage(hLog, LB_ADDSTRING, 0, (LPARAM)"WONT");
			return 3;

		case DO - 256://DO:
//			wsprintf(szTemp, "%c%c%c", IAC, WILL, sz[2]);
//			Send(szTemp, 4);
//			SendMessage(hLog, LB_ADDSTRING, 0, (LPARAM)"DO");
			return 3;

		case DONT - 256://DONT:
//			wsprintf(szTemp, "%c%c%c", IAC, WONT, sz[2]);
//			Send(szTemp, 4);
//			SendMessage(hLog, LB_ADDSTRING, 0, (LPARAM)"DONT");
			return 3;

		case SB - 256:
		int i = 1;
			while( sz[++i] == (SE - 256) )
				;
			return i + 1;
	}

	return 1;
}

int Cbbs::DoESC ( char ch1, char ch2 )
{
int i = 0;

	if( ch1 == 'O' || ch1 == '[' )
	{
		if( ch2 >= 'A' && ch2 <= 'D' )
			return (KEY_UP + ch2 - 'A');
		else if( ch2 >= '1' && ch2 <= '6' )
			return (KEY_HOME + ch2 - '1');
	}

	return 0;
}

CDir** Cbbs::GetFreeDir (  )
{
	::EnterCriticalSection(&dircs);

	for( int i = 0; i < 16; i++ )
		if( !dirs[i] )
		{
			dirs[i] = (CDir*)-1;
			::LeaveCriticalSection(&dircs);
			return &dirs[i];
		}

	::LeaveCriticalSection(&dircs);
	return 0;
}

bool Cbbs::ReleaseDir ( CDir** dir)
{
	::EnterCriticalSection(&dircs);

	for( int i = 0; i < 16; i++ )
		if( dir == &dirs[i] )
		{
			delete dirs[i];
			dirs[i] = 0;
			::LeaveCriticalSection(&dircs);
			return true;
		}

	::LeaveCriticalSection(&dircs);
	return false;
}

FILE** Cbbs::GetFreeFP (  )
{
	::EnterCriticalSection(&fpcs);

	for( int i = 0; i < 16; i++ )
		if( !fps[i] )
		{
			fps[i] = (FILE*)-1;
			::LeaveCriticalSection(&fpcs);
			return &fps[i];
		}

	::LeaveCriticalSection(&fpcs);
	return 0;
}

bool Cbbs::ReleaseFP ( FILE** pfp )
{
	::EnterCriticalSection(&fpcs);

	for( int i = 0; i < 16; i++ )
		if( pfp == &fps[i] )
		{
			::FCLOSE(fps[i]);
			fps[i] = 0;
			::LeaveCriticalSection(&fpcs);
			return true;
		}

	::LeaveCriticalSection(&fpcs);
	return false;
}
