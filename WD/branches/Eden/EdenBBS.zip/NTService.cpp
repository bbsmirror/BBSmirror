#include <stdafx.h>

// Forward declarations
extern HINSTANCE _hInstance;

bool CheckBBSUser (  ) ;

void InstallService (  ) ;
bool IsServiceInstalled (  ) ;
void UninstallService (  ) ;

void RunService ( HINSTANCE hInstance ) ;
void InitService ( HINSTANCE hInstance ) ;

void WINAPI ServiceMain ( DWORD, LPSTR* ) ;
void WINAPI ServiceHandler ( DWORD dwCode ) ;

// Implementation Begins
bool ProcessCommandLine ( LPSTR lpszCmdLine )
{
char* lpszTemp;

	lpszTemp = strchr(lpszCmdLine, '/');
	if( !lpszTemp )
		lpszTemp = strchr(lpszCmdLine, '-');
	if( !lpszTemp )
		return false;

	if( strchr(lpszTemp, ' ') )
		*(strchr(lpszTemp, ' ')) = '\0';

	lpszTemp++;

	if( !_stricmp(lpszTemp, "Standalone") )
	{
		bRunAsService = false;
		return !CheckBBSUser();
	} else if( !_stricmp(lpszTemp, "RegServer") || !_stricmp(lpszTemp, "Install") )
	{
		InstallService();
		return true;
	} else if( !_stricmp(lpszTemp, "UnregServer") || !_stricmp(lpszTemp, "Uninstall") )
	{
		UninstallService();
		return true;
	}

	return false;
}

bool CheckBBSUser (  )
{
int n;

	n = GetPrivateProfileInt("BBS Users", "BBSUSERS", 0, "EdenBBS.INI");
	if( n )
	{
	int i;
	char szBBSUser[10];
	char szTheUser[DATASIZE];
	char szTemp[DATASIZE];
	bool IsTheUser = false;
	DWORD dwSize = DATASIZE;

		for( i = 0; i < n; i++ )
		{
			wsprintf(szBBSUser, "BBSUSER%d", i + 1);
			GetPrivateProfileString("BBS Users", szBBSUser, "bbs", szTemp, DATASIZE, "EdenBBS.INI");
			GetUserName(szTheUser, &dwSize);
			if( !_stricmp(szTheUser, szTemp) )
				return true;
		}

		wsprintf(szTemp, "Current user(%s)\nis now allowed to run EdenBBS!", szTheUser);
		MessageBox(0, szTemp, "EdenBBS", MB_OK|MB_ICONSTOP);

		return false;
	}

	return true;
}

void InstallService (  )
{
SC_HANDLE hSCM, hService;

	UninstallService();
	hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	hService =
		CreateService(hSCM, szServiceName, szServiceName,
					  SERVICE_ALL_ACCESS, SERVICE_WIN32_OWN_PROCESS,
					  SERVICE_DEMAND_START, SERVICE_ERROR_NORMAL,
					  szServicePath, NULL, NULL, NULL,
					  NULL, NULL);

	int i = GetLastError();
	CloseServiceHandle(hService);
	CloseServiceHandle(hSCM);
}

void UninstallService (  )
{
SC_HANDLE hSCM, hService;

	hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if( hService = OpenService(hSCM, szServiceName, SERVICE_STOP | DELETE) )
	{
		DeleteService(hService);
		CloseServiceHandle(hService);
	}
	CloseServiceHandle(hSCM);
}

void InitService ( HINSTANCE hInstance )
{
SERVICE_TABLE_ENTRY st[] =
{
	{ szServiceName, ServiceMain },
	{ 0, 0 }
};

	if( bRunAsService && !StartServiceCtrlDispatcher(st) )
	{
		bRunAsService = false;
	}

	if( !bRunAsService )
		RunService(hInstance);
}

void WINAPI ServiceMain ( DWORD, LPSTR* )
{
	Status.dwServiceType		= SERVICE_WIN32;
	Status.dwCurrentState		= SERVICE_START_PENDING;
	Status.dwControlsAccepted	= SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_PAUSE_CONTINUE;
	Status.dwWin32ExitCode		= 0;
	Status.dwServiceSpecificExitCode = 0;
	Status.dwCheckPoint			= 0;
	Status.dwWaitHint			= 0;

 	hStatus = RegisterServiceCtrlHandler(szServiceName, ServiceHandler);

	SetServiceStatus(hStatus, &Status);

	Status.dwCurrentState = SERVICE_RUNNING;
	SetServiceStatus(hStatus, &Status);

	RunService(_hInstance);

	Status.dwCurrentState = SERVICE_STOPPED;
	SetServiceStatus(hStatus, &Status);
}

void WINAPI ServiceHandler ( DWORD dwCode )
{
    switch( dwCode )
    {
	    case SERVICE_CONTROL_SHUTDOWN:
		case SERVICE_CONTROL_STOP:
		    Status.dwCurrentState = SERVICE_STOP_PENDING;
			SetServiceStatus(hStatus, &Status);
			PostThreadMessage(dwMainThreadId, WM_QUIT, 0, 0);
			break;
		case SERVICE_CONTROL_PAUSE:
		    Status.dwCurrentState = SERVICE_PAUSE_PENDING;
			SetServiceStatus(hStatus, &Status);
			bNoLogin = true;
		    Status.dwCurrentState = SERVICE_PAUSED;
			SetServiceStatus(hStatus, &Status);
			break;
		case SERVICE_CONTROL_CONTINUE:
		    Status.dwCurrentState = SERVICE_CONTINUE_PENDING;
			SetServiceStatus(hStatus, &Status);
			bNoLogin = false;
		    Status.dwCurrentState = SERVICE_RUNNING;
			SetServiceStatus(hStatus, &Status);
		    break;
	    case SERVICE_CONTROL_INTERROGATE:
			break;
    }
}
