#include "stdafx.h"

// Base record file
CbbsRecordFile::CbbsRecordFile ( char* pszFilename, int pnSize, bool bAllowMulti )
{
char szTemp[256];

	bOpened = false;

	strcpy(szFilename, pszFilename);
	nSize = pnSize;
	::GetLongPathName(szFilename, szFilename, MAX_PATH);

	hFile =
		::CreateFile(szFilename, GENERIC_READ|GENERIC_WRITE,
					FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_ALWAYS,
					FILE_FLAG_RANDOM_ACCESS, NULL);
int i = ::GetLastError();
	wsprintf(szTemp, "EdenBBS_RecordFile: %s", szFilename);
	hMutex =
		::CreateMutex(NULL, false, szTemp);

	if( ::GetLastError() == ERROR_ALREADY_EXISTS )
	{
		if( bAllowMulti )
		{
			bOpened = true;
		} else
			delete this;
	}
}

CbbsRecordFile::~CbbsRecordFile ( void )
{
	::CloseHandle(hMutex);
	::CloseHandle(hFile);
}

int CbbsRecordFile::GetNum ( void )
{
DWORD dwSize;

	dwSize = ::GetFileSize(hFile, NULL);

	return dwSize / GetSize();
}

int CbbsRecordFile::GetSize ( void ) const
{
	return nSize;
}

bool CbbsRecordFile::Get ( int p, void* data )
{
int n;
DWORD dwRead;

	::WaitForSingleObject(hMutex, INFINITE);

	if( p != -1 )		// Get the current data
		::SetFilePointer(hFile, p * nSize, NULL, FILE_BEGIN);
	n = ::ReadFile(hFile, data, nSize, &dwRead, NULL);
	::ReleaseMutex(hMutex);

	if( !n || !dwRead )
		return false;

	return true;
}

bool CbbsRecordFile::Append ( void* data )
{
int n;
DWORD dwWritten;

	::WaitForSingleObject(hMutex, INFINITE);

	::SetFilePointer(hFile, 0, 0, FILE_END);
	n = ::WriteFile(hFile, data, nSize, &dwWritten, NULL);

	::ReleaseMutex(hMutex);

	if( !n || !dwWritten )
		return false;

	return true;
}

bool CbbsRecordFile::Delete ( int p )
{
void* data;

	data = new char[nSize];
	memset(data, 0, nSize);

	return Modify(p, data);
}

bool CbbsRecordFile::DeleteAll (  )
{
	return ::SetEndOfFile(hFile) ? true : false;
}

bool CbbsRecordFile::Modify ( int p, void* data )
{
int n;
DWORD dwWritten;

	::WaitForSingleObject(hMutex, INFINITE);

	if( p != -1 )		// Modify the current data
		::SetFilePointer(hFile, p * nSize, NULL, FILE_BEGIN);
	n = ::WriteFile(hFile, data, nSize, &dwWritten, NULL);

	::ReleaseMutex(hMutex);

	if( !n || !dwWritten )
		return false;

	return true;
}

// BBS Online Class
COnlines::COnlines ( int pnMaxActive )
{
char szTemp[DATASIZE];

	nMaxActive = pnMaxActive + 4;
	nActive = 0;

	onlines = new COnlineInfo[nMaxActive];
	memset(onlines, 0, sizeof(COnlineInfo) * nMaxActive);

	wsprintf(szTemp, "EdenBBSOnlinesMutex%d", this);
	::InitializeCriticalSection(&cs);
}

COnlines::~COnlines (  )
{
	delete [] onlines;
	::DeleteCriticalSection(&cs);
}

COnlineInfo* COnlines::Add ( Cbbs* bbs )
{
int i;

	if( IsFull() )
		return false;

	::EnterCriticalSection(&cs);

	for( i = 0; i < nMaxActive; i++ )
		if( !onlines[i].bbs )
		{
			onlines[i].bbs = bbs;
			nActive++;
			::LeaveCriticalSection(&cs);
			return &onlines[i];
		}

	::LeaveCriticalSection(&cs);

	return 0;
}

bool COnlines::Delete ( Cbbs* bbs )
{
int i;

	::EnterCriticalSection(&cs);

	for( i = 0; i < nMaxActive; i++ )
		if( onlines[i].bbs == bbs)
		{
			onlines[i].active = 0;
			onlines[i].bbs = 0;

			nActive--;
			::LeaveCriticalSection(&cs);
			return true;
		}

	::LeaveCriticalSection(&cs);

	return false;
}

int COnlines::Get ( CTalkMenu::CUserPick* target, Cbbs* bbs, bool bFriend )
{
int i, n;
time_t now;

	::EnterCriticalSection(&cs);

	time(&now);

	for( i = 0, n = 0; i < nMaxActive; i++ )
	{
		if( !onlines[i].active )
			continue;

		// Check if I can see this guy here..
		if( _stricmp(onlines[i].userid, bbs->GetUserId())  )
		{
			if( onlines[i].bbs->IsRejected(bbs->online->uid) && !HAS_PERM1(PERM_ACCOUNTS) )
				continue;
			if( onlines[i].invisible && !HAS_PERM1(PERM_SEECLOAK) )
				continue;
			if( PERM_HIDE(onlines[i].userlevel) && !PERM_HIDE(bbs->online->userlevel) )
				continue;
		}
		// Should I just pass the pointer or copy the whole data?

		target[n].oi		= &onlines[i];
		target[n].nIdle		= ( now - onlines[i].lastact );

		if( bbs->IsRejected(onlines[i].uid) )
			target[n].nFriend = -1;
		else {
			target[n].nFriend = 0;
			if( bbs->IsFriend(onlines[i].uid) )
				target[n].nFriend += 1;
			if( onlines[i].bbs->IsFriend(bbs->online->uid) )
				target[n].nFriend += 2;
		}

		if( bFriend && (target[n].nFriend < 1) )
			continue;	// Get friends only

		n++;
	}

	::LeaveCriticalSection(&cs);

	return n;
}

int COnlines::GetActive ( void ) const
{
	return nActive;
}

int COnlines::GetMaxActive ( void ) const
{
	return nMaxActive;
}

bool COnlines::IsFull ( void ) const
{
	return ( nActive >= nMaxActive ) ;
}

COnlineInfo* COnlines::IsOnline ( char* szUserId )
{
int i;

	::EnterCriticalSection(&cs);

	for( i = 0; i < nMaxActive; i++ )
		if( onlines[i].active )
			if( !_stricmp(szUserId, onlines[i].userid) )
			{
				LeaveCriticalSection(&cs);
				return &onlines[i];
			}

	::LeaveCriticalSection(&cs);

	return 0;
}

void COnlines::UpdateNote (  )
{
int i;

	for( i = 0; i < nMaxActive; i++ )
		if( onlines[i].bbs )
			onlines[i].bbs->PutEvent(UPDATENOTE);
}

bool COnlines::Select ( Cbbs* bbs, char* szOut )
{
CbbsNameList l(0, MAXACTIVE);

	::EnterCriticalSection(&cs);

	for( int i = 0; i < nMaxActive; i++ )
	{
		if( !onlines[i].active )
			continue;
		if( &onlines[i] == bbs->online )
			continue;
		if( onlines[i].bbs->IsRejected(bbs->online->uid) && !HAS_PERM1(PERM_ACCOUNTS) )
			continue;
		if( onlines[i].invisible && !HAS_PERM1(PERM_SEECLOAK) )
			continue;
		if( PERM_HIDE(onlines[i].userlevel) && !PERM_HIDE(bbs->online->userlevel) )
			continue;
		l.Add(onlines[i].userid);
	}

	::LeaveCriticalSection(&cs);

/*	if( !l.Get(0, 0) )
	{
		szOut = 0;
		return 0;
	}*/

	return l.Select(bbs, "�п�J�ϥΪ̦W�١G", szOut);
}
