//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by EdenBBS.rc
//
#define IDC_MYICON                      2
#define IDD_EDENBBS_DIALOG              102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDM_OPEN                        106
#define IDS_HELLO                       106
#define IDI_EDENBBS                     107
#define IDI_SMALL                       108
#define IDC_EDENBBS                     109
#define IDS_WINSOCK                     110
#define IDS_GLOBALSHM                   111
#define IDS_SERVICENAME                 111
#define IDR_MAINFRAME                   128
#define IDI_NOLOGIN                     148
#define IDM_OPENCONN                    32771
#define IDM_CLOSECONN                   32772
#define IDM_BBSCONFIG                   32773
#define IDM_NOLOGIN                     32774
#define IDM_FLUSHLOGS                   32775
#define IDM_RELOADCONFIG                32776
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        150
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
