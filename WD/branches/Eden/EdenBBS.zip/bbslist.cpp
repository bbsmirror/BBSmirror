#include "stdafx.h"

CbbsNameList::CbbsNameList ( char* pszFilename, int pnMax )
{
	nMax = pnMax;

	items = new CbbsNameItem[nMax];

	if( pszFilename )
	{
		strcpy(szFilename, pszFilename);
		Reload();
	} else {
		szFilename[0] = NULL;
		memset(items, 0, sizeof(CbbsNameItem) * nMax);
	}
}

CbbsNameList::~CbbsNameList (  )
{
	delete [] items;
}

bool CbbsNameList::Add ( char* szName, char* szDesc )
{
	if( InList(szName) >= 0 )
		return false;

int n = GetEmpty();

	if( n < 0 )
		return false;

	strcpy(items[n].szName, szName);

	if( szDesc )
		strcpy(items[n].szDesc, szDesc);
	else items[n].szDesc[0] = 0;

	return true;
}

bool CbbsNameList::Add ( CbbsNameItem* item )
{
	return Add(item->szName, item->szDesc);
}

bool CbbsNameList::Delete ( char* szName )
{
int i;

	for( i = 0; i < nMax; i++ )
		if( !_stricmp(szName, items[i].szName) )
		{
			memset(&items[i], 0, sizeof(CbbsNameItem));
			return true;
		}

	return false;
}

int CbbsNameList::GetEmpty (  )
{
int i;

	for( i = 0; i < nMax; i++ )
		if( !items[i].szName[0] )
			return i;

	return -1;
}

int CbbsNameList::InList ( char* szName )
{
int i;

	for( i = 0; i < nMax; i++ )
		if( !_stricmp(szName, items[i].szName) )
			return i;

	return -1;
}

bool CbbsNameList::IsEmpty (  )
{
	for( int i = 0; i < nMax; i++ )
		if( items[i].szName[0] )
			return false;

	return true;
}

bool CbbsNameList::Save (  )
{
	if( !szFilename[0] )
		return false;

CbbsRecordFile file(szFilename, sizeof(CbbsNameItem), true);
int i;

	file.DeleteAll();

	for( i = 0; i < nMax; i++ )
		if( items[i].szName[0] )
			file.Append(&items[i]);

	return true;
}

bool CbbsNameList::Reload (  )
{
	if( !szFilename[0] )
		return false;

	memset(items, 0, sizeof(CbbsNameItem) * nMax);

	CbbsRecordFile file(szFilename, sizeof(CbbsNameItem), true);
int i;

	for( i = 0; i < nMax; i++ )
		if( !file.Get(i, &items[i]) )
			break;

	memset(&items[i], 0, sizeof(CbbsNameItem));

	return true;
}

bool CbbsNameList::Get ( int n, char* szOut )
{
	if( n > nMax )
	{
		szOut = 0;
		return false;
	}

	if( items[n].szName[0] && szOut)
	{
		strcpy(szOut, items[n].szName);
		return true;
	}

	return false;
}

int CbbsNameList::GetMax (  ) const
{
	return nMax;
}

int CbbsNameList::GetNum (  )
{
int i, n;

	for( i = 0, n = 0; i < nMax; i++ )
		if( items[i].szName[0] )
			n++;

	return n;
}

bool CbbsNameList::Select ( Cbbs* bbs, char *szPrompt, char* szOut )
{
char szSelect[IDLEN + 1];
char szTemp[20];
int c;
int n = 0;
int i;
int nNextSection = 0;
int l = bbs->realstrlen(szPrompt);

	bbs->move(23, 0);
	bbs->outs("�п�J�W�١A�Ϋ�[SPACE]�j�M");
	bbs->move(2, 22);

	szSelect[0] = 0;
	bbs->outs(szPrompt);

	while(1)
	{
		c = bbs->igetkey();

		switch(c)
		{
			case '\177':
			case Ctrl('H'):
				if( n )
				{
					szSelect[n--] = 0;
					bbs->outs("\010 \010");
				}
				break;

			case ' ':
				bbs->move(3, 0);
				bbs->outs(MSG_SEPERATOR"\r\n");
				//bbs->clrtobot();

				for( i = nNextSection, c = 0; i < nMax; i++ )
					if( !_strnicmp(szSelect, items[i].szName, n) && strlen(items[i].szName) )
					{
						wsprintf(szTemp, "%-16s", items[i].szName);
						bbs->outs(szTemp);
						c++;

						if( c == (20 * 5) )
						{
							nNextSection = i;
							break;
						}
					}

				if( ( c + nNextSection ) == 1 )		// Only one left
				{
					for( i = 0; i < 15; i++ )
						if( szTemp[i] == ' ' )
						{
							szTemp[i] = 0;
							break;
						}

					strcpy(szSelect, szTemp);
					bbs->move(2, 22 + l);
					bbs->outs(szSelect);
					n = strlen(szSelect);
				} else
					bbs->move(2, 22 + n + l);
				break;

			case '\r':
			case '\n':
				i = InList(szSelect);
				if( i < 0 || n == 0)
				{
					szOut = 0;
					return false;
				} else
				{
					strcpy(szOut, items[i].szName);
					return true;
				}
				break;

			default:
				if( ::IsValidKey(c) )
				{
//					bbs->move(2, l + 22 + n);
					nNextSection = 0;
					szSelect[n] = c;
					szSelect[++n] = 0;
					for( i = 0; i < nMax; i++ )
						if( !_strnicmp(szSelect, items[i].szName, n) )
						{
							bbs->o_char(c);
							break;
						} else if( i == (nMax - 1) )
						{
							bbs->beep();
							szSelect[--n] = 0;
						}
				}
		}
	}

	return false;
}

bool CbbsNameList::Edit ( Cbbs* bbs, char* szDesc )
{
char szTemp[DATASIZE];
int c;
int i;
int nPos = 0, nOldPos = 0;
int nStart = 0, nOldStart;
int nTotal;
int nReal;
int s, t;
bool bUpdate = true, bReload;
bool bModified = false;
int nOldMode;
static char* szInput[] = { "0���}", "1�n�ͦW��", "2�a�H�W��", "3�ɫH�W��"};
static char* szInputFile[] = {"Friends", "Rejects", "MailRejects"};

	while(1)
	{
		if( bUpdate )
		{
			bbs->clear();
			bbs->ShowTitle("�s��W��");
			bbs->move(1, 0);

			nTotal = GetNum();

			nOldMode = bbs->SetMode(EDITLIST);
			bbs->outs("\033[0m \033[1m[��]\033[0m���} \033[1m[��]\033[0m�d��"
					  " \033[1m[����]\033[0m��� \033[1m[S]\033[0m�x�s"
					  " \033[1m[/]\033[0m�j�M \033[1m[Ctrl+Z]\033[0m����\r\n");

			bbs->prints("\033[1;46m �s��  �N    ��      %-20s                                      \033[m",
						szDesc ? szDesc : "");

			bUpdate = false;
			bReload = true;
		}

		if( bReload )
		{
			if( !nTotal )
			{
				bbs->move(3, 0);
				bbs->outs("  << �Ū��W��A�Ы�[a]�s�W >>");
				// clrtobot();
			} else {
				s = 0; t = 0;
				for( i = 0; i < 20; i++ )
					if( LightBar(bbs, nStart + i, false, &s, &t) < 0 )
						break;
			}

			bbs->move(23, 0);
			bbs->outs("\033[44;1m  �W��s��  \033[46m  \033[33m(a)\033[37m�s�W"
					  "  \033[33m(d)\033[37m�R��  \033[33m(i)\033[37m�ޤJ�W��"
					  "  \033[33m(E/s)\033[37m�s��y�z  \033[33m(m)\033[37m�H�H  \033[m");
			bReload = false;
		}

		if( nTotal )
		{
			if( nOldPos != nPos )
			{
				LightBar(bbs, nOldPos, false);
			}
			nReal = LightBar(bbs, nPos, true);
		}

		nOldStart = nStart;
		nOldPos = nPos;
		c = bbs->igetkey();

		switch(c)
		{
			case 'e':
			case KEY_LEFT:
				bbs->SetMode(nOldMode);
				return bModified;
				break;

			case KEY_UP:
				if( !nTotal )
					break;

				if( nPos )
					nPos--;
				else bbs->beep();
				break;

			case KEY_DOWN:
				if( !nTotal )
					break;

				if( nPos < nTotal - 1 )
					nPos++;
				else bbs->beep();
				break;

			case KEY_PGUP:
				if( nPos == 0 )
				{
					nPos = nTotal - 1;
					break;
				}

				nPos -= 20;
				if( nPos < 0 )
					nPos = 0;
				break;

			case KEY_PGDN:
			case ' ':
				if( nPos == nTotal - 1)
				{
					nPos = 0;
					break;
				}

				nPos += 20;
				if( nPos > (nTotal - 1) )
					nPos = nTotal - 1;
				break;

			case 'a':
				bbs->stand_title("�s�W�ܦW�椤");
				if( passwds->Select(bbs, szTemp) )
				{
				char szTemp2[21];

					szTemp2[0] = 0;

					if( InList(szTemp) >= 0 )
						break;

					if( szDesc )
						bbs->getdata(3, 0, szDesc, szTemp2, 21);
					Add(szTemp, szTemp2);
					bModified = true;
					nTotal++;
				}

				bUpdate = true;
				break;

			case 'd':
				wsprintf(szTemp, "�T�w�q�W�椤���� [%s]�H", items[nReal].szName);
				if( !bbs->SelectData(1, 0, szTemp, c_yesno, 2, 1) )
				{
					Delete(items[nReal].szName);
					bModified = true;
					nTotal--;
				}

				bUpdate = true;
				break;

			case 'i':
				if( szDesc )
					break;

				bbs->stand_title("�ޤJ�W��");
				if( int n = bbs->SelectData(3, 0, "�z�n�ޤJ�G", szInput, 4) )
					if( !bbs->SelectData(5, 0, "�T�w�ޤJ�H", c_yesno, 2) )
					{
					int nListMax[] = { MAX_FRIEND, MAX_REJECT, MAX_REJECT * 2 } ;

						n--;
						::SetUserFile(szTemp, bbs->GetUserId(), szInputFile[n]);
					CbbsNameList list(szTemp, nListMax[n]);

						for( i = 0; i < nMax && i < nListMax[n]; i++ )
							if( list.Get(i, szTemp) )
								Add(szTemp);
						bModified = true;
					}

				bUpdate = true;
				break;

			case 'm':
				if( !nTotal )
					break;

				MailMenu->DoMailTo(bbs, items[nReal].szName);
				break;

			case 'E':
			case 's':	// Modify Description
				if( !nTotal )
					break;

				if( !szDesc )
					break;

				if( bbs->getdata(1, 0, szDesc, szTemp, 21, DOECHO, items[nReal].szDesc) )
				{
					strcpy(items[nReal].szDesc, szTemp);
					bModified = true;
				}

				bUpdate = true;
				break;

			case 'S':
				if( szFilename[0] )
					Save();
				break;

			case 'q':
			case '\r':
			case '\n':
			case KEY_RIGHT:
				if( !nTotal )
					break;

				TalkMenu->DoQuery(bbs, items[nReal].szName);
				bUpdate = true;
				break;

			default:
				if( bbs->GlobalKeys(c) )
				{
					bUpdate = true;
				} else if( c >= '0' && c <= '9' )
				{
					if( (i = bbs->GetNumber(c)) )
						nPos = i - 1;
					if( nPos >= nTotal )
						nPos = nTotal - 1;
					nOldPos = nPos;
					bUpdate = true;
				}
		}

		if( nPos > nTotal - 1 && nTotal )
			nOldPos = nPos = nTotal - 1; 

		nStart = nPos / 20 * 20;
		if( nStart != nOldStart )
			bReload = true;
	}

	return false;
}

int CbbsNameList::LightBar ( Cbbs* bbs, int nPos, bool bOn, int* s, int* r )
// s = start, r = blanks
{
int i;
int n;

	i = ( s ? *s : 0 ) - 1;
	n = ( r ? *r : 0 );
	do
	{
		i++;
		if( !items[i].szName[0] )
			n++;
	} while( ( i - n ) != nPos && i < nMax );

	if( s )
		*s = i;
	if( r )
		*r = n;

	if( i == nMax )
		return -1;

	bbs->move(nPos % 20 + 3, 0);
	bbs->prints(" %4d %c\033[%c;37;4%cm%-12s\033m%c %s ",
				nPos + 1,
				bOn ? '[' : ' ',
				bOn ? '1' : '0',
				bOn ? '4' : '0',
				items[i].szName,
				bOn ? ']' : ' ',
				items[i].szDesc
				);

	return i - n;
}

// User->List SubMenu
void CListSubMenu::InitElement (  )
{
CbbsMenuItem temp[6]= {
	PERM_LOGINOK,	"FFriends      [�n�ͦW��]", "�s��z���n�ͦW��",
	PERM_LOGINOK,	"RRejects      [�a�H�W��]", "�s��z���a�H�W��",
	PERM_LOGINOK,	"AAlohas       [�W���q��]", "�s��z���W���q���W��",
	PERM_LOGINOK,	"MMailRejects  [�ɫH�W��]", "�]�w�H�󪺩ڵ����Ӥ�:X",
	PERM_LOGINOK,	"OOthers       [��L�W��]", "�s��z�ӤH���W��",
	0,0,0};

	this->menu = new CbbsMenuItem[6];

	memcpy((void*)this->menu, (void*)temp, sizeof(CbbsMenuItem) * 6);
}

int CListSubMenu::ExecMenu ( int nIndex, Cbbs* bbs )
{
	switch( nIndex )
	{
		case 0:
			return Friends(bbs);
		case 1:
			return Rejects(bbs);
		case 2:
			return Alohas(bbs);
		case 3:
			return MailMenu->Reject(bbs);
		case 4:
			return Others(bbs);
	}

	return 0;
}

int CListSubMenu::Friends ( Cbbs* bbs )
{
	if( bbs->Friends->Edit(bbs, "�n�ʹy�z ") )
	{
		bbs->Friends->Save();
		bbs->Friends->Reload();
		bbs->ReloadFriends();
	}

	return FULLUPDATE;
}

int CListSubMenu::Rejects ( Cbbs* bbs )
{
	if( bbs->Rejects->Edit(bbs, "�c��c�� ") )
	{
		bbs->Rejects->Save();
		bbs->Rejects->Reload();
		bbs->ReloadRejects();
	}

	return FULLUPDATE;
}

int CListSubMenu::Alohas ( Cbbs* bbs )
{
	return FULLUPDATE;
}

int CListSubMenu::Others ( Cbbs* bbs )
{
char szTemp[DATASIZE];
static char* szLists[] = { "0���}", "1", "2", "3", "4", "5" };
int n;

	bbs->stand_title("�s��ӤH�W��");

	if( n = bbs->SelectData(3, 0, "�п�ܦW��G", szLists, 6) )
	{
		::SetUserFile(szTemp, bbs->GetUserId(), "list.");
		strcpy(strchr(szTemp, '\0'), szLists[n]);

	CbbsNameList list(szTemp, MAX_FRIEND * 1.5);

		if( list.Edit(bbs, 0) && !bbs->SelectData(23, 0, "�W��w��ʡA�n�x�s�W��ܡH", c_yesno, 2) )
			list.Save();
	}
	return FULLUPDATE;
}
