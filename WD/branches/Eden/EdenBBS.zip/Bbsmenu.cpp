#include "stdafx.h"

int Cbbs::Goodbye (  )
{
char szTemp[DATASIZE];

	wsprintf(szTemp, "�z�T�w�n���}\033[1;37;44m[%s]\033[m�ܡH", BBSNAME);
	if( !SelectData(23, 0, szTemp, c_yesno, 2, 1) )
	{
	char *szSel[] = {"R�����F��><", "N����p�����d�n��", "M�H�H���������", "G�H���ӳu.."};

		clear();
		
		switch( SelectData(23, 0, 0, szSel, 4, 3) )
		{
			case 1:
				LeaveNote();
				break;

			case 2:
				 MailMenu->MailSYSOP(this);
				break;

			case 0:
				return FULLUPDATE;
		}

		pressanykey();

		ExitBBS(EXIT_GRACEFULLY);
	}

	return FULLUPDATE;	// Just to prevent warnings
}

// Main Menu
void CMainMenu::InitElement (  )
{
CbbsMenuItem temp[11] =
{
	PERM_ADMIN,		"00Admin       [�t�κ޲z]", "����/���ȸs�޲z�\���",
	PERM_LOGINOK,	"FFavorite     [�ڪ��̷R]", "�ڪ��̷R�ݪO",
	0,				"BBoards       [�ݪO�\��]", "�C�X�Ҧ��ݪO",
	0,				"CClass        [�����ݪO]", "�C�X�������ݪO",
	PERM_BASIC,		"MMail         [�q�l�l��]", "�ӤH�l��\��",
	0,				"TTalk         [�𶢲��]", "���/���",
	PERM_BASIC,		"UUser         [�ӤH�]�w]", "�]�w�ӤH�򥻸��/ñ�W��/�W����...",
	0,				"IInfo         [�t�θ�T]", "�[�ݨt�ά���/�t�Τ��i/�d���O...",
	PERM_LOGINOK,	"SService      [�[�ȪA��]", "�@���B�~���A��(�n$$��:p)",
	0,				"XGoodbye      [-ByeBye-]", "���}[���������p��]",
	0, 0, 0};

	menu = new CbbsMenuItem[11];

	memcpy(menu, temp, sizeof(CbbsMenuItem) * 11);
}

int CMainMenu::ExecMenu ( int nIndex, Cbbs* bbs )
{
	switch( nIndex )
	{
		case 0:	// Admin
			return AdminMenu->Show(bbs);

		case 1:
			boards->ShowBoards(bbs, BLIST | BFAVORITE);
			return FULLUPDATE;

		case 2:	// Boards
			boards->ShowBoards(bbs, BLIST | BNEW);
			return FULLUPDATE;

		case 3:	// Class
			boards->ShowBoards(bbs, BLIST | BCLASS);
			return FULLUPDATE;

		case 4:	// Mail
			return MailMenu->Show(bbs);

		case 5:	// Talk
			return TalkMenu->Show(bbs);

		case 6:	// User
			return UserMenu->Show(bbs);

		case 7:	// Info
			return Info(bbs);

		case 8:	// Service
			return ServiceMenu->Show(bbs);

		case 9:	// Goodbye
			return bbs->Goodbye();
	}

	return FULLUPDATE;
}

int CMainMenu::Info ( Cbbs* bbs )
{
CDir** dir;

	dir = bbs->GetFreeDir();
	if( !dir )
		return FULLUPDATE;

	*dir = new CDir("Info\\_DIR");
	(*dir)->ReadAnnounce(bbs, "�t�θ�T", "Info", HAVE_PERM1(PERM_SYSOP) ? RA_SYSOP : RA_NORMAL);
	bbs->ReleaseDir(dir);

	return FULLUPDATE;
}

// BBS Menu
CbbsMenu::CbbsMenu ( int pnMode, char pcDef, char* pszTitle, bool pbDoNote )
{
	menu	= NULL;
	nMode	= pnMode;
	cDef	= pcDef;
	bDoNote	= pbDoNote;

	if( pszTitle )
		strcpy(szTitle, pszTitle);
	else
		strcpy(szTitle, ModeStr[nMode]);
}

CbbsMenu::~CbbsMenu (  )
{
	if( menu )
		delete [] menu;
}

int CbbsMenu::Show ( Cbbs* bbs )
{
int nTotal;
int c = cDef;
int nPos = 0, nOldPos = 0, nReal = 0;
bool bUpdate = false;

	bbs->clear();
	bbs->ShowTitle(szTitle);
	bbs->ShowStatus();
	bbs->GetOnlineInfo()->do_note = bDoNote;

	if( bDoNote )
		bbs->ShowNote();

	if( !( nTotal = ShowMenu(bbs) ) )
		return 0;

	while(1)
	{
		nOldPos = nPos;

		switch(c)
		{
			case KEY_UP:
				if( nPos )
					nPos --;
				else
					nPos = nTotal - 1;
				break;

			case KEY_DOWN:
				nPos++;
				if( nPos >= nTotal )
					nPos = 0;
				break;

			case KEY_LEFT:
				if( nMode == MMENU )	// In main menu
				{
					c = 'g';
					continue;
				}
				bbs->GetOnlineInfo()->do_note = false;
				return FULLUPDATE;

			case '\n':
			case '\r':
			case KEY_RIGHT:
				bbs->GetOnlineInfo()->do_note = false;
				if( ExecMenu(nReal, bbs) )
					bUpdate = true;
				else
					bbs->online->do_note = bDoNote;
				// SetUTMP
				break;

			case '/':
				if( nMode == MMENU )	// In main menu
				{
					bbs->online->do_note = false;
					boards->SearchBoard(bbs);
				}
				bbs->GetOnlineInfo()->do_note = bDoNote;
				bUpdate = true;
				break;

			default:
				bbs->GetOnlineInfo()->do_note = false;
				if( bbs->GlobalKeys(c) )
				{
					bUpdate = true;
					bbs->SetMode(nMode);
					break;
				}

				bbs->GetOnlineInfo()->do_note = bDoNote;
				if( (c >= 'a' && c <= 'z') )
					c -= 32;

				int i, j;

					for( i = 0, j = 0;
						menu[i].nLevel || menu[i].szDesc || menu[i].szPrompt;
						i++ )
					{
						if( !HAS_PERM1(menu[i].nLevel) )
							continue;
						else {
							if( menu[i].szDesc[1] == c )
							{
								nPos = j;
								break;
							}
							j++;
						}
					}
		}

		if( bUpdate )
		{
			bbs->clear();
			bbs->ShowTitle(szTitle);
			bbs->ShowStatus();
			bbs->GetOnlineInfo()->do_note = bDoNote;

			if( bDoNote )
				bbs->ShowNote();

			ShowMenu(bbs);

			bUpdate = false;
		}

		// Draw Lightbar
		if( nOldPos != nPos )
			LightBar(bbs, nOldPos, false);
		nReal = LightBar(bbs, nPos, true);

		// Draw Menu Prompts
		bbs->move(23, 11);
		bbs->outs(menu[nReal].szPrompt);
		bbs->clrtoeol(); bbs->o_char(' ');

		bbs->SetMode(nMode);

		c = bbs->igetkey();
	}

	return 0;
}

int CbbsMenu::ShowMenu ( Cbbs* bbs )
{
int i, n;

	if( !menu )
		this->InitElement();

	bbs->move(MENUROW, 0);

	for( i = 0, n = 0;
		menu[i].nLevel || menu[i].szDesc || menu[i].szPrompt;
		i++ )
	{
		if( !HAS_PERM1( menu[i].nLevel ) )
			continue;

		LightBar(bbs, n, false);
		n++;
	}

	bbs->move(23, 0);
	bbs->outs("\033[1;33;46m[��满��]\033[m ");
	bbs->clrtoeol();

	return n;
}

int CbbsMenu::LightBar ( Cbbs* bbs, int nPos, bool bOn )
{
int i, n;

	for( i = 0, n = 0;
		menu[i].nLevel || menu[i].szDesc || menu[i].szPrompt;
		i++ )
		if( HAS_PERM1( menu[i].nLevel ) )
		{
			if( n == nPos )
				break;
			n++;
		}

	bbs->move(MENUROW + nPos, 0);
	if( bOn )
		bbs->prints("  \033[1;37;44m> [\033[1;37;44m%c\033[1;37;44m]\033[1;37;44m%s \033[1m<\033[m",
					menu[i].szDesc[1], menu[i].szDesc + 2);
	else
		bbs->prints("  \033[1;37;40m  [\033[1;36;40m%c\033[1;37;40m]\033[0;37;40m%s \033[1m \033[m",
					menu[i].szDesc[1], menu[i].szDesc + 2);


	return i;
}
