#include "stdafx.h"

void Cbbs::BBSMainThread (  )
{
	InitTelnet();

	ShowSystemInfo();
	Login();
	InitOnlineInfo();
	SpecialUser();
	DoOnlineShows();
	DoHabits();

	MainMenu->Show(this);

	Sleep(2000);
}

void Cbbs::ShowSystemInfo (  )
{
OSVERSIONINFO osi;

	prints("\033[1;37;44m  EdenBBS  \033[40m System: \033[36m%s/%s\r\n\033[37mOn a \033[46m",
		 BBSDN, BBSIP);

	osi.dwOSVersionInfoSize = sizeof(osi);
	GetVersionEx(&osi);
	outs(" Windows ");
	switch( osi.dwPlatformId )
	{
		case VER_PLATFORM_WIN32_WINDOWS:
			prints("9%c", osi.dwMinorVersion ? '8' : '5');
			break;

		case VER_PLATFORM_WIN32_NT:
			if( osi.dwMajorVersion == 5 )
				outs("2000");
			else
				prints("NT %d.%d", osi.dwMajorVersion, osi.dwMinorVersion);
			break;
	}

	// �L�᪺���Y:p
	outs(" \033[40m Platform.\r\n\r\n�s�u��.");
	for( int i = 0; i < 4; i++ )
	{
		Sleep(500);
		outs(".");
	}

	outs("\033[m");
}

void Cbbs::Login (  )
{
char szTemp[DATASIZE];
int nAttempt;
CUserInfo u;
char szFrom[100];

	if( conn->IsFull() )
	{
		outs("\r\n\r\n��p�I�H�Ƥw���A�еy��A�ӡC");
		ExitBBS(EXIT_GRACEFULLY);
	} else
		conn->Add();

	if( bNoLogin )
	{
		outs("\r\n\r\n��p�I�t���������A�еy��A�ӡC");
		ExitBBS(EXIT_GRACEFULLY);
	}

	strcpy(szFrom, inet_ntoa(stRemote.sin_addr));

	clear();

	prints("�w����{\033[1;37;44m %s \033[m�A�{�b�u�W�� %d/\033[1;37m%d\033[m �H\r\n",
		BBSNAME, onlines->GetActive(), MAXACTIVE);

	showfile("Settings\\banner.1");

	beep();	// �����ϥΪ̤w�i�Hlogin

	for( nAttempt = MAXATTEMPT; nAttempt; nAttempt-- )
	{
	char szUser[IDLEN + 1], szPasswd[PASSLEN];

		getdata(ACCOUNTY, ACCOUNTX, "", szUser, IDLEN + 1, DOECHO, 0);
		if( !_stricmp(szUser, "new") )
		{
			if( !bCanNew )
			{
				pressanykey("��p�I�����ثe���}��H new ���U�C");
				continue;
			}

			memset(&u, 0, sizeof(CUserInfo));
			NewUser(&u);
			break;
		} else if( passwds->Search(szUser, &u) >= 0 && szUser[0] )
		{
			if( !_stricmp(szUser, "guest") )
				break;

			getdata(PASSWDY, PASSWDX, "", szPasswd, MAXPASS, PASS, 0);
			char* psz = crypt(szPasswd, u.passwd);
			if( strcmp(u.passwd, crypt(szPasswd, u.passwd)) )
			{
				BadLogins->Log("[%-12s]  %s", szUser, szFrom);
				pressanykey(ERR_PASSWD);
				continue;
			}
			break;
		} else {
			pressanykey(ERR_UID);
			continue;
		}
	}

	if( !nAttempt )
	{
		pressanykey("���~�Ӧh���I�U���A�ӧa�I");
		ExitBBS(EXIT_GRACEFULLY);
	}

	memcpy(&cuser, &u, sizeof(CUserInfo));

	nMaxIdle = MAX_IDLE;
	nRemainIdle = nMaxIdle;

	if( !BoardRC )
		BoardRC = new CBoardRC(this);

	if( !cuser.numlogins )
	{
		FillUserInfo(&cuser, true);
		DoNewUserShow();
	}

	time(&cuser.lastlogin);
	cuser.numlogins++;
	strcpy(cuser.lasthost, szFrom);

	passwds->ModifyS(cuser.userid, &cuser);

	// Reload Lists
	::SetUserFile(szTemp, cuser.userid, "Friends");
	Friends = new CbbsNameList(szTemp, MAX_FRIEND);
	online->friends = new int[MAX_FRIEND];
	ReloadFriends();

	::SetUserFile(szTemp, cuser.userid, "Rejects");
	Rejects = new CbbsNameList(szTemp, MAX_REJECT);
	online->rejects = new int[MAX_REJECT];
	ReloadRejects();

	// Initialize Message Logs
	//::SetUserFile(szTemp, cuser.userid, "writelog");
	//MessageLog = new CbbsRecordFile(szTemp, sizeof(CMessageStruct), false);

	// Log usies
	Usies->Log("ENTER   %-12s  %s",
			   cuser.userid, cuser.lasthost);

	// Edit Buffer
	::SetUserFile(szTemp, cuser.userid, EDITBUF);
	::DeleteFile(szTemp);
}

void Cbbs::SpecialUser (  )
{
	if( !_stricmp(cuser.userid, "guest") )
	{
		cuser.userlevel = 0;
		cuser.habit = HABIT_MOVIE | HABIT_BELL | HABIT_ALARM | HABIT_COLORDATE;
	} else if ( !_stricmp(cuser.userid, "SYSOP") )
	{
		cuser.userlevel = ~0;
	}

	passwds->ModifyS(cuser.userid, &cuser);
}

void Cbbs::InitOnlineInfo (  )
{
//	memset(&cuser, 0, sizeof(CUserInfo));
//	onlines->Add(this);

	online->active		= true;
	online->bbs			= this;
	online->destuip		= 0;
	strcpy(online->feeling, cuser.feeling);
	online->feelingcolor= cuser.feelingcolor;
	strcpy(online->from, cuser.lasthost);
	online->habit		= cuser.habit;
	online->in_edit		= false;
	online->in_gd		= false;
	online->do_note		= false;
	online->invisible	= false;
	online->isbirthday	= false;	//
	time(&online->lastact);
	online->mode		= LOGIN;
	online->pager		= cuser.pagermode;
	online->privacy		= cuser.privacy;
	strcpy(online->realname, cuser.realname);

	online->msgcount	= 0;
	online->currmsg		= 0;
	memset(online->msgs, 0, sizeof(CMessageQueue) * 10);

	online->turn		= 0;
	online->uid			= passwds->Search(cuser.userid);
	time(&online->uptime);
	strcpy(online->userid, cuser.userid);
	online->userlevel	= cuser.userlevel;
	strcpy(online->username, cuser.username);

	strcpy(szCurrBoard, "SYSOP");
	strcpy(szCurrTitle, "NOTITLE:D");
	curx = cury = 0;
	nCurrReply = nMaxMsg = 0;
	xCurr = yCurr = xDest = yDest = 0;
}

void Cbbs::DoOnlineShows (  )
{
CBoardInfo t;

	if( !HAS_PERM(PERM_GENERAL)
	&&	_stricmp(cuser.userid, "guest")
	&&	_stricmp(cuser.justify, REGISTERED) )
		UserMenu->Register(this);

	while( (boards->Search("0Announce", &t) && BoardRC->IsUnread("0Announce") ) )
		boards->ReadBoard(this, &t);

	more("Settings\\Announce");
}

void Cbbs::DoHabits (  )
{
	if( HAVE_HABIT(HABIT_CLOAKATLOGIN) )
		ServiceMenu->Cloak(this);

	if( HAVE_HABIT(HABIT_NOTEATLOGIN) )
		ViewNote();

	if( HAVE_HABIT(HABIT_INFOATLOGIN) )
		MainMenu->Info(this);

	if( HAVE_HABIT(HABIT_FEELATLOGIN) )
		UserMenu->Feeling(this);

	if( HAVE_HABIT(HABIT_ULISTATLOGIN) )
		TalkMenu->UserList(this);

	if( HAVE_HABIT(HABIT_SETATLOGIN) )
		UserMenu->Habits(this);
}

// BBS misc functions
Cbbs::Cbbs ( SOCKET s, sockaddr_in st )
{
TCHAR szWSProcClass[256];
char szTemp[256];

	DebugLog->Log("BBS Object(%d) Created.", this);
	::SetCurrentDirectory(BBSDIR);

	::LoadString(_hInstance, IDS_WINSOCK, szWSProcClass, 256);

	hSocket = s;
	::memcpy(&stRemote, &st, sizeof(stRemote));

	hDependWnd =
		::CreateWindow(szWSProcClass, "", WS_POPUP,
					   0, 0, 0, 0, NULL, NULL, _hInstance, 0);
	::SetWindowLong(hDependWnd, 0, (LONG)this);
	::WSAAsyncSelect(hSocket, hDependWnd, WM_WSASYNC,
					 FD_READ|FD_WRITE|FD_CLOSE);

	::InitializeCriticalSection(&cs);
	::InitializeCriticalSection(&msgcs);
	::InitializeCriticalSection(&dircs);
	::InitializeCriticalSection(&fpcs);

	for( int i = 0; i < 16; i++ )
	{
		dirs[i] = 0; fps[i] = 0;
	}

	nMaxIdle = MAX_IDLE1;
	nRemainIdle = nMaxIdle;

	curx = cury = 0;

	nMaxMsg = 0;

	nCurrLGD = 0;
	nMaxLGD = 0;

	BoardRC = 0;

	online = onlines->Add(this);

	Rejects = 0;
	Friends = 0;
	MessageLog = 0;

	srand(time(0));

	::wsprintf(szTemp, "EDENBBS_KEY_EVENT_%d", this);
	hKeyEvent =
		::CreateEvent(NULL, true, false, szTemp);

	hBBSThread =
		::CreateThread(NULL, 0, EnterBBSThread, (LPVOID)this,
					   NULL, &dwThreadId);
}

Cbbs::~Cbbs (  )
{
	ExitBBS(EXIT_FORCE);
}

void Cbbs::ExitBBS ( int nReason )
{
	// Put bbslog->Append("reason..."); here
	// Check if stayed longer than 1 min
	if( online->active )
	{
		//passwds->ModifyS(cuser.userid, &cuser);
		if( online->destuip && online->destuip->active )
			online->destuip->bbs->PutEvent(TALKTERM);
	}

	if( MessageLog )
		delete MessageLog;

	if( Friends )
	{
		Friends->Save();
		delete Friends;
	}

	if( Rejects )
	{
		Rejects->Save();
		delete Rejects;
	}

	onlines->Delete(this);

	if( !conn->IsFull() )
		conn->Delete();

	::DeleteCriticalSection(&cs);
	::DeleteCriticalSection(&msgcs);
	::DeleteCriticalSection(&dircs);
	::DeleteCriticalSection(&fpcs);

	delete BoardRC;

	for( int i = 0; i < 16; i++ )
	{
		if( dirs[i] )
			delete dirs[i];
		if( fps[i] )
			::FCLOSE(fps[i]);
	}

	::closesocket(hSocket);
	::DestroyWindow(hDependWnd);
	::CloseHandle(hKeyEvent);

	if( nReason < 0 )	// EXIT_FORCE
	{
		beep();
		::TerminateThread(hBBSThread, nReason);
	} else
		::ExitThread(nReason);
}
