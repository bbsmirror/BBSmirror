#ifndef _BBSTRUCT_H_
#define _BBSTRUCT_H_

using namespace std ;

// BBS Message Class
class CMessageQueue
{
public:
	char szReplyTo[IDLEN + 1];
	int uid;
	char szMessage[81];
	char szReplied[81];
};

// Online user info
class COnlineInfo
{
public:
	int uid;						/* Used to find user name in passwd file */
	Cbbs* bbs;						/* Pointer to the bbs body */
	//int sockaddr;					/* (I think this one can be obselete */
	COnlineInfo* destuip;			/* talk uses this to identify who called */
	uschar active;					/* When allocated this field is true */
	uschar invisible;				/* Used by cloaking function in Xyz menu */
	usint userlevel;
	uschar mode;					/* UL/DL, Talk Mode, Chat Mode, ... */
	uschar pager;					/* pager toggle, YEA, or NA */
	bool in_edit;
	bool in_gd;
	bool do_note;
	char userid[IDLEN + 1];
	char chatid[11];				/* chat id, if in chat mode */
	char realname[20];
	char username[24];
	char from[29];					/* machine name the user called in from */
	int *friends;
	int *rejects;
	time_t uptime;
	time_t lastact;
	uschar msgcount;
	ushort currmsg;
	CMessageQueue msgs[10];
	ushort feelingcolor;
	char feeling[5];
	int turn;
	short isbirthday;
	usint habit;
	usint privacy;
};

// Detailed user info
class CUserInfo
{
public:
	char userid[IDLEN + 1];
	char realname[20];
	char username[24];
	char passwd[PASSLEN];
	usint userlevel;
	uschar pagermode;
	ushort numlogins;
	ushort numposts;
	time_t firstlogin;
	time_t lastlogin;
	time_t totalonline;
	char lasthost[16];
	char email[50];
	char address[50];
	char justify[REGLEN + 1];
	uschar month;
	uschar day;
	uschar year;
	uschar sex;
	unsigned long silvermoney;
	unsigned long goldmoney;
	usint habit;
	usint privacy;
	long exmailbox;
	char feeling[5];
	uschar feelingcolor;
};

// Detailed board info
class CBoardInfo
{
public:
	char name[IDLEN + 1];
	char brdclass[5];
	char title[BTLEN + 1];
	char BM[IDLEN + 1];
	char SubBM[2][IDLEN + 1];
	ushort type;	// 0 - board, 1- dir, 2 - class
	ushort votenum;
	usint flags;
	usint rlevel;
	usint wlevel;
	char Desc[5][80];
};

class CDirIndex
{
public:
	char filename[FNLEN];		/* M.9876543210.A */
	int mode;					/* M D + r */
	char owner[IDLEN + 2];		/* uid[.] */
	char year[5];
	char date[6];				/* [02/02] or space(5) */
	char title[TTLEN + 1];
};

// Mainframe of EdenBBS
class Cbbs
{
	public:
		Cbbs ( SOCKET hSocket, sockaddr_in stRemote ) ;
		~Cbbs (  ) ;

	public:
		// Miscellaneous functions
		static DWORD WINAPI EnterBBSThread ( LPVOID param ) ;
		void InitTelnet (  ) ;
		int Send ( char *buf, int nSize ) ;
		int realstrlen ( char* buf ) ;

		friend LRESULT CALLBACK WSProc ( HWND, UINT, WPARAM, LPARAM ) ;

		// Low-level BBS control functions
		void PutEvent ( int nEventNo, bool bSet = true ) ;
		void DoReceive ( char* szRecv ) ;
		int DoIAC ( char* szRecv ) ;
		int DoESC ( char ch1, char ch2 ) ;

		CDir** GetFreeDir (  ) ;
		bool ReleaseDir ( CDir** dir ) ;

		FILE** GetFreeFP (  ) ;
		bool ReleaseFP ( FILE** fp ) ;

	public:
		// BBS I/O functions
		void outs ( char *buf ) ;
		void prints ( char* szFormat, ... ) ;
		void o_char ( char c ) ;
		void beep (  ) ;
		void do_move ( int y, int x ) ;
		void move ( int y, int x ) ;
		void clear (  ) ;
		void clrtobot (  ) ;
		void clrtoeol (  ) ;

		int igetkey (  ) ;
		int getdata ( int y, int x, char* prompt, char* data,
					  usint max, int mode = DOECHO, char* def = 0 ) ;
		int SelectData ( int y, int x, char* szPrompt, char** data,
						 int num, int def = 0, int nStyle = SD_HORZ|SD_HOTKEY|SD_CLEAR ) ;

		bool GlobalKeys ( int c ) ;
		int GetNumber ( char cFirst ) ;

		// BBS Stuff functions
		usint GetPerm (  ) const ;
		COnlineInfo* GetOnlineInfo (  ) const ;
		char* GetUserId (  ) const ;
		CUserInfo* GetUser (  ) ;

		// BBS Main functions
		void ShowSystemInfo (  ) ;
		void BBSMainThread (  ) ;
		void Login (  ) ;
		void SpecialUser (  ) ;
		void InitOnlineInfo (  ) ;
		void DoOnlineShows (  ) ;
		void DoHabits (  ) ;
		void ExitBBS ( int nReason ) ;

		// BBS User Registeration functions
		void NewUser ( CUserInfo* u ) ;
		void DoNewUserShow (  ) ;
		void DoRegister (  ) ;

		// BBS File Showing functions
		void ShowTitle ( char* szCmd, char* pszTitle = 0 ) ;
		void ShowStatus (  ) ;
		bool showfile ( char* szFilename, int nLimit = 0 ) ;
		int more ( char* szFilename, int mode = 0 ) ;
		int pressanykey ( char* szMessage = 0 ) ;
		void stand_title ( char* szMessage ) ;
		void ShowNote (  ) ;

		void AppendBBSInfo ( FILE* fp ) ;

		bool GlobalHelp (  ) ;

		void LeaveNote (  ) ;
		void GenerateNote (  ) ;
		void ViewNote (  ) ;

		// BBS Editor functions
		int LoadFile ( char* szFilename ) ;
		bool SaveToFile ( char* szFilename, int nTotal, bool bAppend = false ) ;
		void ReplyFile ( char* szIn, char* szOut, int nMode, char* szOwner = 0, char* szNickname = 0) ;
		int Edit ( char* szFilename, int nMode, char* szTitle = 0 ) ;

		// BBS Talk functions
		bool IsRejected ( int ) ;
		bool IsFriend ( int ) ;

		void ShowMessages ( short nMode = 0 ) ;

		bool WriteMessage ( COnlineInfo* oi, char* szMessage ) ;
		void DoWriteRequest (  ) ;

		void Talk ( COnlineInfo* oi ) ;
		void DoTalkRequest (  ) ;
		void DoTalk ( bool bStarter ) ;
		void TalkShow ( bool bMySelf, int c, int* y, int* x, FILE* fp = 0 ) ;
		void TalkString ( bool bMySelf, int c, int* y, int* x ) ;

		// BBS Mail functions
		bool CheckMail ( char* szUser = 0 ) ;

		// BBS Money functions
		bool HaveGold ( int n ) ;
		void InGold ( int n ) ;
		bool DeGold ( int n ) ;

		bool HaveSilver ( int n ) ;
		void InSilver ( int n ) ;
		bool DeSilver ( int n ) ;

		// BBS User functions
		void UserInfo ( CUserInfo* u = 0, bool bIsSYSOP = false ) ;
		void FillUserInfo ( CUserInfo* u, bool bIsNew = false ) ;
		void SetFeeling ( CUserInfo* user, int y ) ;
		unsigned int SetPerms( unsigned int pnBits, char* szTitle = "�]�w�ϥΪ��v��" ) ;

		bool ConfirmPassword ( int y = 2 ) ;
		bool CheckPassword ( char* szInput ) ;

		void ReloadFriends (  ) ;
		void ReloadRejects (  ) ;

		int SetMode ( int nMode ) ;
		char* GetSignature (  ) ;

		// BBS Main Menu functions
		int Goodbye (  ) ;

	private:
		typedef queue<int> KEYQUEUE;
		// Miscellaneous
		HWND hDependWnd;

		SOCKET hSocket;
		sockaddr_in stRemote;
		int nDataSize;
		int nBytesSent;
		bool bSendOK;
		char szData[DATASIZE];
		char szReceived[DATASIZE];

		// For BBS Control
		HANDLE		hBBSThread;
		DWORD		dwThreadId;
		HANDLE		hKeyEvent;
		KEYQUEUE	EventQueue;
		CRITICAL_SECTION	cs;
		CRITICAL_SECTION	msgcs;
		int			nRemainIdle, nMaxIdle;

	private:
		// BBS data
		CUserInfo cuser;
		int curx, cury;

		char szLastGetData[5][80];
		short nCurrLGD;
		short nMaxLGD;

		short nCurrReply;
		short nMaxMsg;

		// For talk
		int xCurr, yCurr;
		char CurrData[10][81];
		int xDest, yDest;
		char DestData[10][81];

		// For Editor
		char szBuffer[1000][120];

		// For Garbage Collection
		CRITICAL_SECTION dircs;
		CDir* dirs[16];

		CRITICAL_SECTION fpcs;
		FILE* fps[16];

	public:
		COnlineInfo	*online;

		char szCurrBoard[IDLEN + 1];
		char szCurrTitle[TTLEN + 1];

		char szToCopy[MAX_PATH];
		char szToCopyTitle[TTLEN];

		CBoardRC*	BoardRC;

		// Name Lists
		CbbsNameList* Friends;
		CbbsNameList* Rejects;

		// Message Log
		CbbsRecordFile* MessageLog;
};

#define BOARDRCSIZE	5 * 1024
#define NEWTEXT		"[/-/\\N\\e\\w\\B\\o\\a\\r\\d\\R\\C\\1\\2\\3\\4\\5\\-\\]"

class CBoardRC
{
	public:
		CBoardRC ( Cbbs* pbbs ) ;
		~CBoardRC (  ) ;

	public:
		bool IsUnread ( char* szBoard, char* szFilename = 0 ) ;
		void SetUnread ( char* szBoard ) ;
		void SetRead ( char* szBoard, char* szFilename = 0 ) ;

		void Flush (  ) ;

		void OptimizeBlock ( char* szBoard, CDir* dir ) ;

	private:
		char* InitBlock ( char* szBoard, time_t t = 2592000 ) ;	// A month
		void DeleteBlock ( char* szBoard ) ;
		char* SearchBlock ( char* szBoard, int* nSize ) ;

	private:
		Cbbs* bbs;
		HANDLE hBoardRC;
		HANDLE hBoardRCMap;
		char* lpBoardRC;

		char szLastBoard[IDLEN + 1];
		char* lpLastBRC;
		int nLastSize;

		CRITICAL_SECTION cs;
};

#define REGISTERED	"[REGISTERED]"

class CRegister
{
public:
	char szUser[IDLEN + 1];
	char szNickname[24];
	char szRealName[20];
	char szTel[17];
	char szAddress[50];
	char szEMail[50];
};

class CConn
{
	public:
		CConn ( int pnMax ) ;
		~CConn (  ) ;

	public:
		void Add (  ) ;
		void Delete (  ) ;
		bool IsFull (  ) ;

	private:
		HANDLE hMutex;
		int nMax;
		int nOccupied;
};

// Class which stores online users
class COnlines
{
	public:
		COnlines ( int pnMaxActive ) ;
		~COnlines (  ) ;

	public:
		COnlineInfo* Add ( Cbbs* bbs ) ;
		bool Delete ( Cbbs* bbs ) ;

		int GetActive (  ) const ;
		int GetMaxActive (  ) const ;

		int Get ( CTalkMenu::CUserPick* target, Cbbs* bbs, bool bFriend = false ) ;

		bool IsFull (  ) const;

		COnlineInfo* IsOnline ( char* szUserId ) ;

		void UpdateNote (  ) ;

		bool Select ( Cbbs* bbs, char* szOut ) ;

	protected:
		int nMaxActive;
		int nActive;
		COnlineInfo *onlines;

		CRITICAL_SECTION cs;
};

// Base record file
class CbbsRecordFile
{
	public:
		CbbsRecordFile ( char* pszFilename, int pnSize, bool bAllowMulti = false) ;
		~CbbsRecordFile (  ) ;

	public:
		bool Get ( int p, void* data ) ;
		bool Modify ( int p, void* data ) ;
		bool Delete ( int p ) ;
		bool Append ( void* data ) ;

		bool DeleteAll (  ) ;

		virtual int Search ( char* name, void* data ) { return 0; } // = 0;
		virtual int ModifyS ( char* name, void* data ) { return 0; } //= 0;
		virtual int DeleteS ( char* name ) { return 0; } //= 0;
		virtual int SearchNew (  ) { return 0; } //= 0;

		bool Select ( Cbbs* bbs, char* szOut ) { return 0; };

		int GetNum (  ) ;

	protected:
		int GetSize (  ) const ;

	protected:
		HANDLE hFile;
		HANDLE hMutex;

	private:
		char szFilename[MAX_PATH];
		int nSize;
		bool bOpened;
};

// File which stores all boards' info
class CBoards : public CbbsRecordFile
{
	public:
		CBoards ( char* pszFilename )
		:
		CbbsRecordFile( pszFilename, sizeof(CBoardInfo), false )
		{
		}

	public:
		int Search ( char* name, void* data = 0) ;
		int ModifyS ( char* name, void* data ) ;
		int DeleteS ( char* name ) ;
		int SearchNew (  ) ;

	public:
		void ShowBoards ( Cbbs* bbs, int nMode = 0, char* szFilter = 0 ) ;
		void ReadBoard ( Cbbs* bbs, CBoardInfo* t, bool bNewFlag = false ) ;
		bool EditBoard ( Cbbs* bbs, char* szName ) ;
		bool SetBoard ( Cbbs* bbs, CBoardInfo* bi, int i, bool IsNew = false) ;

		void SearchBoard ( Cbbs* bbs ) ;

		void ReadDir ( Cbbs* bbs, CBoardInfo* bi, bool bNew = false ) ;

		void BoardTitle ( Cbbs* bbs, CBoardInfo* bi ) ;

		bool Select ( Cbbs* bbs, char* szOut, int nToShow = 2 ) ;
		// Default - Show boards & Directories

	private:
		void LightBar( Cbbs* bbs, int n, CBoardInfo* bi, bool bUnread, bool bOn = true, DWORD dwSize = 0xFFFFFFFF) ;
};

// File which stores all users' info
class CPasswds : public CbbsRecordFile
{
	public:
		CPasswds ( char* pszFilename )
		:
		CbbsRecordFile( pszFilename, sizeof(CUserInfo), false )
		{
		}

	public:
		int Search ( char* name, void* data = 0 ) ;
		int ModifyS ( char* name, void* data ) ;
		int DeleteS ( char* name ) ;
		int SearchNew (  ) ;

	public:
		int SetHabits ( Cbbs* bbs, CUserInfo* u ) ;
		int SetPrivacy ( Cbbs* bbs, CUserInfo* u ) ;

		bool Select ( Cbbs* bbs, char* szOut ) ;

		// Money methods
		bool HaveUGold ( char* szUser, int n ) ;
		void InUGold ( char* szUser, int n ) ;
		bool DeUGold ( char* szUser, int n ) ;

		bool HaveUSilver ( char* szUser, int n ) ;
		void InUSilver ( char* szUser, int n ) ;
		bool DeUSilver ( char* szUser, int n ) ;
};

// Index file for boards, personal mailbox
class CDir : public CbbsRecordFile
{
	public:
		CDir ( char* pszFilename )
		:
		CbbsRecordFile( pszFilename, sizeof(CDirIndex), true )
		{
		}

	public:
		void ReadBoard ( Cbbs* bbs, CBoardInfo* bi ) ;
		void PostArticle ( Cbbs* bbs, CBoardInfo* bi, CDirIndex* r = 0 ) ;
		void DoPostRecord ( Cbbs* bbs, CBoardInfo* bi, char* szFilename, time_t start, time_t end ) ;
		void DoCrossPost ( Cbbs* bbs, CDirIndex* a, char* szSourcePath, char* szShow ) ;

		void ReadMail ( Cbbs* bbs ) ;

		void ReadAnnounce ( Cbbs* bbs, char* szTitle, char* szPath, int nMode = RA_NORMAL ) ;
		bool IsValidLink ( char* szPath ) ;
		bool GetLink ( Cbbs* bbs, char* szPath, char* szLink ) ;

		int DoSearch ( char* szKeyword, int nMode, bool bMatchWhole, int* nData ) ;

		bool DoDelete (  ) ;

	private:
		void BLightBar ( Cbbs* bbs, int n, CDirIndex* di, bool bOn = false ) ;
		void MLightBar ( Cbbs* bbs, int n, CDirIndex* di, bool bOn = false ) ;
		void ALightBar ( Cbbs* bbs, int n, CDirIndex* di, bool bOn = false ) ;
};

// BBS Name List Item
class CbbsNameItem
{
public:
	char szName[IDLEN + 1];
	char szDesc[21];
};

class CbbsNameList
{
	public:
		CbbsNameList ( char* pszFilename, int pnMax ) ;
		~CbbsNameList (  ) ;

	public:
		bool Add ( CbbsNameItem* item ) ;
		bool Add ( char* szName, char* szDesc = 0 ) ;

		bool Delete ( char* szName ) ;

		bool Get ( int n, char* szOut ) ;
		bool IsEmpty (  ) ;

		int InList ( char* szName ) ;

		bool Save (  ) ;
		bool Reload (  ) ;

		bool Edit ( Cbbs* bbs, char* szDesc ) ;
		bool Select ( Cbbs* bbs, char* szPrompt, char* szOut ) ;

		int GetMax (  ) const ;
		int GetNum (  ) ;

	private:
		int LightBar ( Cbbs* bbs, int nPos, bool bOn = false, int* s = 0, int* r = 0 ) ;
		int GetEmpty (  ) ;

	private:
		char szFilename[MAX_PATH];
		int nMax;

		CbbsNameItem* items;
};

// BBS Miscellaneous Log
class CbbsLog
{
	public:
		CbbsLog ( char* pszFilename, bool pbLogTime = true ) ;
		~CbbsLog (  ) ;

	public:
		void Log ( char* szFormat, ... ) ;
		void Rotate (  ) ;
		void LogToBoard ( char* szBoard, char* szUser, char* szTitle ) ;

	private:
		CRITICAL_SECTION cs;
		char szFilename[30];
		char szFullPath[MAX_PATH];
		bool bLogTime;
};

// BBS NoteBoard
class CNoteData
{
public:
char szUser[IDLEN + 1];
char szNickName[24];
char szDate[20];
char szNote[3][80];
};

// BBS Fromhost
class CFromHost
{
public:
	char szFrom[21];
	char szShow[17];
};

// BBS Holidays
class CHoliday
{
public:
	short nMon, nDay;
	char szShow[20];
};

#endif