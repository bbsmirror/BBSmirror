#include "stdafx.h"

// BBS Configuration functions
void InitBBSConfig (  )
{
FILE* fp;
char szTemp[DATASIZE];
int i;
static char* INIFile = "EdenBBS.INI";

	// BBS Environment
	GetPrivateProfileString("EdenBBS", "BBSDIR", "C:\\EdenBBS", BBSDIR, sizeof(BBSDIR), INIFile);
	GetPrivateProfileString("EdenBBS", "BBSNAME", "���R�W��BBS", BBSNAME, sizeof(BBSNAME), INIFile);
	GetPrivateProfileString("EdenBBS", "BBSDN", "untitled.twbbs.org", BBSDN, sizeof(BBSDN), INIFile);
	GetPrivateProfileString("EdenBBS", "BBSIP", "127.0.0.1", BBSIP, sizeof(BBSIP), INIFile);

	// BBS Login
	ACCOUNTX	= GetPrivateProfileInt("BBS Login", "AccountX",  0, INIFile);
	ACCOUNTY	= GetPrivateProfileInt("BBS Login", "AccountY", 20, INIFile);
	PASSWDX		= GetPrivateProfileInt("BBS Login", "PasswdX",  0, INIFile);
	PASSWDY		= GetPrivateProfileInt("BBS Login", "PasswdY", 21, INIFile);
	MAXATTEMPT	= GetPrivateProfileInt("BBS Login", "MaxAttempt", 3, INIFile);

	// BBS Configuration
	MAXUSERS		= GetPrivateProfileInt("BBS Configuration", "MaxUsers", 10000, INIFile);
	MAXBOARD		= GetPrivateProfileInt("BBS Configuration", "MaxBoard", 200, INIFile);
	MAXACTIVE		= GetPrivateProfileInt("BBS Configuration", "MaxActive", 100, INIFile);

	MAX_FRIEND		= GetPrivateProfileInt("BBS Configuration", "MaxFriend", 100, INIFile);
	MAX_REJECT		= GetPrivateProfileInt("BBS Configuration", "MaxReject", 32, INIFile);
	MAX_FAVORITE	= GetPrivateProfileInt("BBS Configuration", "MaxFavorite", 20, INIFile);

	MAX_IDLE		= GetPrivateProfileInt("BBS Configuration", "MaxIdle", 20, INIFile) * 60;
	MAX_IDLE1		= GetPrivateProfileInt("BBS Configuration", "MaxIdle1", 30, INIFile);

	bCanNew = GetPrivateProfileInt("BBS Configuration", "CanNew", true, INIFile) ? true : false;

	// Load from host database
	memset(hosts, 0, sizeof(CFromHost) * 200);
	wsprintf(szTemp, "%s\\Settings\\Fromhosts.dat", BBSDIR);
	fp = fopen(szTemp, "r");
	if( fp )
	{
	char* t;

		i = 0;
		while( fgets(szTemp, DATASIZE, fp) )
		{
			if( szTemp[0] == ';' || szTemp[0] == ' ' || !szTemp[9] )
				continue;
			StripNewLine(szTemp);

			t = strchr(szTemp, ' ');

			if( t )
			{
				strncpy(hosts[i].szFrom, szTemp, t - szTemp);
				strncpy(hosts[i].szShow, t + 1, 17);
				i++;
			}
		}

		fclose(fp);
	}

	// Load holiday database
	memset(holidays, 0, sizeof(CHoliday) * 120);
	wsprintf(szTemp, "%s\\Settings\\Holidays.dat", BBSDIR);
	fp = fopen(szTemp, "r");
	if( fp )
	{
		i = 0;
		while( fgets(szTemp, DATASIZE, fp) )
		{
			if( szTemp[0] == ';' || szTemp[0] == ' ' || !szTemp[9] )
				continue;
			StripNewLine(szTemp);

			holidays[i].nMon = (szTemp[0] - '0') * 10 + (szTemp[1] - '0');
			holidays[i].nDay = (szTemp[2] - '0') * 10 + (szTemp[3] - '0');
			strncpy(holidays[i].szShow, szTemp + 5, 20);
			i++;
		}

		fclose(fp);
	}
}

void CheckDirectories (  )
{
static char* szDirectories[] = {
	"Announce",
	"Binary",
	"Boards",
	"Home",
	"Info",
	"InfoFiles",
	"Logs",
	"Logs\\Old",
	"Settings",
	"Temp",
	"XFile",
	0
};

	CreateDirectory(BBSDIR, 0);

	SetCurrentDirectory(BBSDIR);

	for( int i = 0; szDirectories[i]; i++ )
		CreateDirectory(szDirectories[i], 0);
}

void LoadMenus (  )
{
	MainMenu	= new CMainMenu();
	AdminMenu	= new CAdminMenu();
	TalkMenu	= new CTalkMenu();
	UserMenu	= new CUserMenu();
	MailMenu	= new CMailMenu();
	ServiceMenu	= new CServiceMenu();

	ListSubMenu	= new CListSubMenu();
}

void DeleteMenus (  )
{
	delete MainMenu;
	delete AdminMenu;
	delete TalkMenu;
	delete UserMenu;
	delete MailMenu;
	delete ServiceMenu;

	delete ListSubMenu;
}

void LoadLogs (  )
{
	Usies		= new CbbsLog("Usies");
	BadLogins	= new CbbsLog("BadLogins");
	DebugLog	= new CbbsLog("Debug");
}

void DeleteLogs (  )
{
	delete Usies;
	delete BadLogins;
	delete DebugLog;
}

DWORD Cbbs::EnterBBSThread ( LPVOID param )
{
Cbbs* bbs = (Cbbs*)param;

	bbs->BBSMainThread();

	delete bbs;

	return 0;
}

void Cbbs::InitTelnet ( void )
{
char szTelnet[51];

	wsprintf(szTelnet, "%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",
		IAC, DO, TELOPT_TTYPE,
		IAC, SB, TELOPT_TTYPE, TELQUAL_SEND, IAC, SE,
		IAC, WILL, TELOPT_ECHO,
		IAC, WILL, TELOPT_SGA);

	outs(szTelnet);
}

int Cbbs::Send ( char *buf, int nSize )
{
int nRet;

	bSendOK = false;

	nDataSize = nSize;

	nRet = ::send(hSocket, buf, nSize, 0);

	if( nRet == SOCKET_ERROR )
	{
		nRet = ::WSAGetLastError();
		if( nRet != WSAEWOULDBLOCK )
			return -1;
		else
			return 0;
	} else {
		nBytesSent += nRet;
		if( nDataSize = nBytesSent )
			bSendOK = true;
	}
	return nBytesSent;
}

int Cbbs::realstrlen ( char* buf )
{
int i, n;
bool bInANSI = false;

	for( i = 0, n = 0; buf[i]; i++ )
	{
		if( bInANSI )
		{
			if( buf[i] == 'm' )
				bInANSI = false;
			else if( !strchr("[0123456789;,", buf[i]) )
			{
				bInANSI = false;
				n++;
			}
		} else if( buf[i] == '\033' )
			bInANSI = true;
		else
			n++;
	}

	return n;
}

// Connection management functions
CConn::CConn ( int pnMax )
{
	nMax		= pnMax;
	nOccupied	= 0;

	hMutex =
		::CreateMutex(NULL, false, "EdenBBSConnMutex_1101");
}

CConn::~CConn (  )
{
	::CloseHandle(hMutex);
}

void CConn::Add (  )
{
	::WaitForSingleObject(hMutex, INFINITE);
	if( nOccupied < nMax )
		nOccupied++;
	::ReleaseMutex(hMutex);
}

void CConn::Delete (  )
{
	::WaitForSingleObject(hMutex, INFINITE);
	if( nOccupied )
		nOccupied--;
	::ReleaseMutex(hMutex);
}

bool CConn::IsFull (  )
{
	::WaitForSingleObject(hMutex, INFINITE);
	if( nOccupied >= nMax )
	{
		::ReleaseMutex(hMutex);
		return true;
	}
	::ReleaseMutex(hMutex);
	return false;
}
