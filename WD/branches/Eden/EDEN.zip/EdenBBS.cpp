// EdenBBS.cpp : Defines the entry point for the application.
//

#include "stdafx.h"

#include <tchar.h>

// Global Variables:
TCHAR szTitle[MAX_LOADSTRING];				// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];		// The title bar text
TCHAR szWSProcClass[MAX_LOADSTRING];

// Global BBS Objects
CBoards* boards;
CPasswds* passwds;
COnlines* onlines;

CDir* Notes;
CbbsRecordFile* RegData;
CbbsRecordFile* NoteBoard;

// Global BBS Menus
CMainMenu*		MainMenu;
CAdminMenu*		AdminMenu;
CTalkMenu*		TalkMenu;
CUserMenu*		UserMenu;
CMailMenu*		MailMenu;
CServiceMenu*	ServiceMenu;

CListSubMenu*	ListSubMenu;

// Global BBS Logs
CbbsLog*	Usies;
CbbsLog*	BadLogins;
CbbsLog*	DebugLog;

// Global BBS Environment Variables
char BBSDIR[MAX_PATH];
char BBSNAME[31];
char BBSDN[31];
char BBSIP[25];
int ACCOUNTX, ACCOUNTY;
int PASSWDX, PASSWDY;
short MAXATTEMPT;

CFromHost hosts[200];
CHoliday holidays[120];

bool bNoLogin;
char szNoLogin[50];

// Global BBS Configuration Variables
int MAXUSERS;
int MAXBOARD;
int MAXACTIVE;
int MAX_FRIEND;
int MAX_REJECT;
int MAX_FAVORITE;

int MAX_IDLE;
int MAX_IDLE1;

bool bCanNew;

CConn *conn;

// EdenBBS Server Properties
HINSTANCE _hInstance;

// Windows Service Properties
bool bRunAsService;
SERVICE_STATUS Status;
SERVICE_STATUS_HANDLE hStatus;
TCHAR szServiceName[MAX_LOADSTRING];
TCHAR szServicePath[MAX_PATH];
DWORD dwMainThreadId;

// Forward declarations of functions included in this code module:
ATOM				MyRegisterClass ( HINSTANCE hInstance ) ;
ATOM				RegisterWSProcClass ( HINSTANCE hInstance ) ;
BOOL				InitInstance ( HINSTANCE ) ;
LRESULT CALLBACK	WndProc ( HWND, UINT, WPARAM, LPARAM ) ;
LRESULT CALLBACK	WSProc ( HWND, UINT, WPARAM, LPARAM ) ;

void InitBBS (  ) ;
void UninitBBS (  ) ;

bool ProcessCommandLine ( LPSTR lpszCmdLine ) ;
bool CheckBBSUser (  ) ;

void InstallService (  ) ;
void UninstallService (  ) ;

void RunService ( HINSTANCE hInstance ) ;
void InitService ( HINSTANCE hInstance ) ;

void WINAPI ServiceMain ( DWORD, LPSTR* ) ;
void WINAPI ServiceHandler ( DWORD dwCode ) ;

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	_hInstance = hInstance;
	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_EDENBBS, szWindowClass, MAX_LOADSTRING);
	LoadString(hInstance, IDS_WINSOCK, szWSProcClass, MAX_LOADSTRING);
	LoadString(hInstance, IDS_SERVICENAME, szServiceName, MAX_LOADSTRING);

	bRunAsService = true;
	GetModuleFileName(NULL, szServicePath, MAX_PATH);

	if( ProcessCommandLine(lpCmdLine) )
	{
		WSACleanup();
		return 0;
	}

	InitService(hInstance);

	return 1;
}

void RunService ( HINSTANCE hInstance )
{
MSG msg;
WSADATA wsaData;

	dwMainThreadId = GetCurrentThreadId();

	// Use WinSock 1.1
	WSAStartup(MAKEWORD(1, 1), &wsaData);

	MyRegisterClass(hInstance);
	RegisterWSProcClass(hInstance);

	// Perform application initialization:
	if ( !InitInstance(hInstance) )
	{
		WSACleanup();
		return ;
	}

	InitBBS();

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
		DispatchMessage(&msg);

	WSACleanup();
}

ATOM MyRegisterClass ( HINSTANCE hInstance )
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_EDENBBS);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= GetSysColorBrush(COLOR_3DFACE);
	wcex.lpszMenuName	= 0;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

ATOM RegisterWSProcClass ( HINSTANCE hInstance )
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= 0;
	wcex.lpfnWndProc	= (WNDPROC)WSProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 4;			// Stores pointer to bbs
	wcex.hInstance		= hInstance;
	wcex.hIcon			= 0;
	wcex.hCursor		= 0;
	wcex.hbrBackground	= 0;
	wcex.lpszMenuName	= 0;
	wcex.lpszClassName	= szWSProcClass;
	wcex.hIconSm		= 0;

	return RegisterClassEx(&wcex);
}

BOOL InitInstance( HINSTANCE hInstance )
{
HWND hWnd;

	hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
						CW_USEDEFAULT, 0, CW_USEDEFAULT, 0,
						NULL, NULL, hInstance, NULL);

	if( !hWnd )
	{
		return FALSE;
	}

	return TRUE;
}

void InitBBS (  )
{
char szTemp[DATASIZE];

	InitBBSConfig();

	conn = new CConn(MAXACTIVE);

	::SetCurrentDirectory(BBSDIR);

	// Initialize BBS Objects
	wsprintf(szTemp, "%s\\"BOARDS, BBSDIR);
	boards = new CBoards(szTemp);

	wsprintf(szTemp, "%s\\"PASSWDS, BBSDIR);
	passwds = new CPasswds(szTemp);

	onlines = new COnlines(MAXACTIVE);

	SetAFile(szTemp, "Note", DIRFILE);
	Notes = new CDir(szTemp);

	wsprintf(szTemp, "%s\\Register.dat", BBSDIR);
	RegData = new CbbsRecordFile(szTemp, sizeof(CRegister), false);

	wsprintf(szTemp, "%s\\InfoFiles\\Note.dat", BBSDIR);
	NoteBoard = new CbbsRecordFile(szTemp, sizeof(CNoteData), false);

	// Initialize BBS Menus
	LoadMenus();

	// Initialize BBS Logs
	LoadLogs();
}

void UninitBBS (  )
{
	delete conn;

	// Delete BBS Objects
	delete boards;
	delete passwds;
	delete onlines;

	delete Notes;
	delete RegData;

	// Delete BBS Menus
	DeleteMenus();

	// Delete BBS Logs
	DeleteLogs();
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
static SOCKET	hSockServer;
static sockaddr_in	stServer;
static int nPort;
SOCKET hSockClient;
sockaddr_in	stClient;
int len;
int nRet;
Cbbs* bbs;

	switch ( message )
	{
		case WM_CREATE:
			// Initialize Tray Icon
			bNoLogin = false;

			InitBBSConfig();
			CheckDirectories();

			nPort = GetPrivateProfileInt("EdenBBS", "BBSPORT", 23, "EdenBBS.INI");

			if( GetPrivateProfileInt("EdenBBS", "AutoNologin", 0, "EdenBBS.INI") )
				bNoLogin = true;

			if( GetPrivateProfileInt("EdenBBS", "HighPriority", 1, "EdenBBS.INI") )
				SetPriorityClass( GetCurrentProcess(), HIGH_PRIORITY_CLASS);
			else
				SetPriorityClass( GetCurrentProcess(), NORMAL_PRIORITY_CLASS);

			hSockServer = socket(PF_INET, SOCK_STREAM, 0);
			stServer.sin_addr.s_addr	= 0;
			stServer.sin_family			= AF_INET;
			stServer.sin_port			= htons(nPort);
			bind(hSockServer, (sockaddr*)&stServer, sizeof(stServer));

			WSAAsyncSelect(hSockServer, hWnd, WM_WSASYNC, FD_ACCEPT);
			listen(hSockServer, 5);

			// Initialize Note Timer
			SetTimer(hWnd, NOTE_TIMER, MOVIE_INT * 1000, NULL);
			break;

		case WM_TIMER:
			if( wParam == NOTE_TIMER )
			{
				onlines->UpdateNote();
			}
			break;

		case WM_WSASYNC:
			if( nRet = WSAGETSELECTERROR(lParam) )
			{
				break;
			}

			switch( WSAGETSELECTEVENT(lParam) )
			{
				case FD_ACCEPT:
					len = sizeof(stClient);
					hSockClient = accept(hSockServer, (sockaddr*)&stClient, &len);
					DebugLog->Log("Socket(%d) Accepted.", hSockClient);
					bbs = new Cbbs(hSockClient, stClient);
					break;
			}
			break;

		case WM_CLOSE:
		case WM_DESTROY:
			closesocket(hSockServer);
			KillTimer(hWnd, NOTE_TIMER);
			break;

		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

LRESULT CALLBACK WSProc ( HWND hWnd, UINT uMsgId, WPARAM wParam, LPARAM lParam )
{
LRESULT lResult = 0;
int nRet;
Cbbs* bbs = (Cbbs*)GetWindowLong(hWnd, 0);
SOCKET hSock;

	switch(uMsgId)
	{
		case WM_CREATE:
			break;

		case WM_WSASYNC:
			hSock = wParam;
			if( nRet = WSAGETSELECTERROR(lParam) )
			{
				// wslog->log();
				delete bbs;
				break;
			}

			switch( WSAGETSELECTEVENT(lParam) )
			{
				case FD_READ:
					nRet = recv(bbs->hSocket, bbs->szReceived, DATASIZE, 0);
					bbs->szReceived[nRet] = 0;
					bbs->DoReceive(bbs->szReceived);
					break;

				case FD_WRITE:
					nRet =
						send(bbs->hSocket,
							 &bbs->szData[bbs->nBytesSent],
							 bbs->nDataSize - bbs->nBytesSent, 0);

					if( nRet == SOCKET_ERROR )
					{
						nRet = WSAGetLastError();
						if( nRet != WSAEWOULDBLOCK )
							return -1;
						else
							return 0;
					} else {
						bbs->nBytesSent += nRet;
						if( bbs->nDataSize <= bbs->nBytesSent )
							bbs->bSendOK = true;
					}
					break;

				case FD_CLOSE:
					delete bbs;
					break;
			}
			break;

		case WM_DESTROY:
			break;

		default:
			lResult = DefWindowProc(hWnd, uMsgId, wParam, lParam);
	}

	return lResult;
}
