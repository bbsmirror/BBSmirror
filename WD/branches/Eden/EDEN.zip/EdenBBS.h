//	EdenBBS System v0.5
//			Misc definition/declarations

#if !defined(AFX_EDENBBS_H__E61B95D9_2112_4BD4_90ED_9C7EDB973DF3__INCLUDED_)
#define AFX_EDENBBS_H__E61B95D9_2112_4BD4_90ED_9C7EDB973DF3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Misc definitions
#define	WM_WSASYNC		WM_USER + 0x100

#define MAX_LOADSTRING 100

// Types definitions
typedef long time_t;

// BBS Environment Variables(external declaration)
extern char BBSDIR[MAX_PATH];
extern char BBSNAME[31];
extern char BBSDN[31];
extern char BBSIP[25];
extern int ACCOUNTX, ACCOUNTY;
extern int PASSWDX, PASSWDY;
extern short MAXATTEMPT;

extern CFromHost hosts[200];
extern CHoliday holidays[120];

extern bool bNoLogin;
extern char szNoLogin[50];

// BBS Configuration Variables(external declaration)
extern int MAXUSERS;
extern int MAXBOARD;
extern int MAXACTIVE;
extern int MAX_FRIEND;
extern int MAX_REJECT;
extern int MAX_FAVORITE;

#define MAXKEEPMAIL     (100)           /* �̦h�O�d�X�� MAIL�H */
#define MAX_NOTE        (20)            /* �̦h�O�d�X�g�d���H */
#define	MAX_SYSNOTE		(8)				/* �̦h�O�d�X�g�������i	*/
#define MAXSIGLINES     (6)             /* ñ�W�ɤޤJ�̤j��� */
#define MAXQUERYLINES   (16)            /* ��� Query/Plan �T���̤j��� */
#define MAXPAGES        (1000)          /* more.c ���峹���ƤW�� (lines/22) */
#define MOVIE_INT       (20)            /* �����ʵe���g���ɶ��G20�� */

// max idles
extern int MAX_IDLE;
extern int MAX_IDLE1;

extern bool bCanNew;

// BBS System constants
#define NOTE_TIMER		1

// BBS Exit Reasons
#define EXIT_FORCE		-1
#define EXIT_GRACEFULLY	0
#define EXIT_TIMEOUT	1

// System default color
#define COLOR1  "\033[44;37m"
#define COLOR2  "\033[46;37m"

// Global function declaration
void InitBBSConfig (  ) ;
void CheckDirectories (  ) ;

void LoadMenus (  ) ;
void DeleteMenus (  ) ;

void LoadLogs (  ) ;
void DeleteLogs (  ) ;

// Stuff functions declaration
bool IsValidId ( char* id ) ;
bool IsValidBoard ( char* name ) ;
bool IsValidEMail ( char* email ) ;
bool IsValidKey ( int c ) ;
short GetHoroscope( int mon, int day ) ;

void SetUserDir ( char* buf, char* username ) ;
void SetUserFile ( char* buf, char* username, char* filename ) ;
void SetBDir ( char* buf, char* boardname ) ;
void SetBFile ( char* buf, char* boardname, char* filename ) ;
void SetADir ( char* buf, char* boardname ) ;
void SetAFile ( char* buf, char* boardname, char* filename ) ;
void SetVFile ( char* buf, char* boardname, char* filename, char* extfile ) ;

time_t StampFile ( char *buf, char type ) ;
bool AppendToFile ( FILE* fpDest, FILE* fpSource ) ;
void StripNewLine ( char* sz ) ;

void AppendAutorInfo ( FILE* fp,  char* szAuthor, char* szNickname, char* szTitle, time_t* t, char* szBoard ) ;

void Cdate ( time_t *clock, char* buf ) ;

int FCLOSE ( FILE* pfp ) ;

void InsertChar ( char* s, int pos, char c ) ;
void DeleteChar ( char* s, int pos ) ;

bool MailTo ( Cbbs* bbs, char* szUser, char* szOwner, char* szTitle, char* szFilename, bool bSetUnread = true ) ;
bool PutToBoard ( Cbbs* bbs, char* szBoard, char* szOwner, char* szTitle, char* szFilename ) ;

char* GetFromHost ( char* szIP ) ;
char* GetHoliday ( int nMon, int nDay ) ;

void GeneratePassword ( char* szPassword, char* szOut ) ;

// From static LIBs
BOOL WINAPI DeleteDirectory ( LPSTR lpszTarget ) ;
char* crypt (char *passwd, char *salt) ;

// Windows Service Properties
extern bool bRunAsService;
extern SERVICE_STATUS Status;
extern SERVICE_STATUS_HANDLE hStatus;
extern TCHAR szServiceName[MAX_LOADSTRING];
extern TCHAR szServicePath[MAX_PATH];
extern DWORD dwMainThreadId;

// Global Objects
extern CBoards* boards;
extern CPasswds* passwds;
extern COnlines* onlines;

extern CDir* Notes;
extern CbbsRecordFile* RegData;
extern CbbsRecordFile* NoteBoard;

// Global Menus
extern CMainMenu*		MainMenu;
extern CAdminMenu*		AdminMenu;
extern CTalkMenu*		TalkMenu;
extern CUserMenu*		UserMenu;
extern CMailMenu*		MailMenu;
extern CServiceMenu*	ServiceMenu;
extern CListSubMenu*	ListSubMenu;

// Global BBS Logs
extern CbbsLog*		Usies;
extern CbbsLog*		BadLogins;
extern CbbsLog*		DebugLog;

// Global variables
extern HINSTANCE _hInstance;
extern CConn* conn;

// Global selectdata() selections
static char *szSex[4] = {"�ڬO�k�� ^^", "�ڬO�k�� *^^*", "�ڬO�Ӫ��� :D", "�q���]���ʧO�� ^O^"};
static char *szSign[4] = {"��", "��", "�U", "��"};
static char *szStar[] = {"�d��", "����", "���l", "����", "��l", "�B�k",
						 "�ѯ�", "����", "�g��", "�]�~", "���~", "����"};
static char *szWeek[] = {"��", "�@", "�G", "�T", "�|", "��", "��"};

static char *e_yesno[] = {"Yes", "No", "Cancel"};
static char *c_yesno[] = {"Y�O", "N�_", "C����"};
static char *e_onoff[] = {"On", "Off"};
static char *c_onoff[] = {"�}", "��"};
static char *e_editdel[] = {"Edit", "Delete", "Quit"};
static char *c_editdel[] = {"E�s��", "D�R��", "Q���}"};

#endif // !defined(AFX_EDENBBS_H__E61B95D9_2112_4BD4_90ED_9C7EDB973DF3__INCLUDED_)
