#include "stdafx.h"

void CDir::ReadAnnounce ( Cbbs* bbs, char* szTitle, char* szPath, int nMode )
{
int c;
int i;
int o;
int nPos = 0, nOldPos = 0, nStart = 0;
int nTotal = 0;
char szTemp[DATASIZE];
CDirIndex t[20];
CDirIndex a;
bool bUpdate = true;
bool bReload;

	while(1)
	{
		if( bUpdate )
		{
			bbs->clear();
			bbs->ShowTitle("��ؤ峹", szTitle);
			bbs->outs("\r\n \033[1;37m[��]\033[0m���} \033[1m[��]\033[0m�\Ū"
					  " \033[1m[d]\033[0m�R��"
					  " \033[1m[Ctrl+Z]����\033[0m\r\n");
			bbs->outs("\033[1;37;46m  �s��     ��         �D                                  �s    ��     ��  ��  \033[m");

			bbs->SetMode(ANNOUNCE);

		DWORD dwSize = ::GetFileSize(hFile, NULL);

			if( dwSize == 0xFFFFFFFF )
				dwSize = 0;

			nTotal = dwSize / sizeof(CDirIndex);

			if( nPos >= nTotal && nTotal )
				nPos = nTotal - 1;

			bUpdate = false;
			bReload = true;
		}

		if( bReload )
		{
			if( !nTotal )
			{
				bbs->outs("\r\n  �m��ذϡn�|�b�l���Ѧa��������ؤ�... :)\r\n");
				bbs->clrtobot();
			} else {
				for( i = 0; i < 20; i++ )
				{
					if( !Get(nStart + i, &t[i]) )
						break;

					ALightBar(bbs, nStart + i, &t[i]);
				}
			}

			bReload = false;
		}

		if( nTotal )
		{
			if( nPos != nOldPos )
				ALightBar(bbs, nOldPos, &t[nOldPos - nStart]);

			ALightBar(bbs, nPos, &t[nPos - nStart], true);
		}

		nOldPos = nPos;
		c = bbs->igetkey();

		switch(c)
		{
			case 'e':
			case KEY_LEFT:
				return ;
				break;

			case '\r':
			case '\n':
			case 'r':
			case KEY_RIGHT:
Redo:
				if( !nTotal )
					break;

				if( Get(nPos, &a) && nPos >= 0 )
				{
				int n;

					o = nPos;
					wsprintf(szTemp, "%s\\%s", szPath, a.filename);
					if( a.filename[0] == 'D' )
					{
					char szDir[DATASIZE];

						wsprintf(szDir, "%s\\_DIR", szTemp);

					CDir** dir;

						dir = bbs->GetFreeDir();
						if( !dir )
							break;

						*dir = new CDir(szDir);
						(*dir)->ReadAnnounce(bbs, a.title + 3, szTemp, nMode);
						bbs->ReleaseDir(dir);

						bUpdate = true;
						break;
					} else if( a.filename[0] == 'L' )
					{
					char szLink[DATASIZE];
						if( GetLink(bbs, szTemp, szLink) )
							n = bbs->more(szLink, MOREREAD);
						else break;
					} else
						n = bbs->more(szTemp, MOREREAD);

					switch( n )
					{
						case LAST:
							if( nPos )
							{
								nPos--;
								goto Redo;
							}
							break;

						case NEXT:
							nPos++;
							goto Redo;
							break;
					}
				} else
					nPos = o;
				bUpdate = true;
				break;

			case KEY_UP:
				if( !nTotal )
					break;

				if( nPos )
					nPos--;
				else
					nPos = nTotal - 1;
				break;

			case KEY_DOWN:
				if( !nTotal )
					break;

				if( nPos < nTotal - 1 )
					nPos++;
				else
					nPos = 0;
				break;

			case KEY_PGUP:
				if( nPos == 0 )
				{
					nPos = nTotal - 1;
					break;
				}

				nPos -= 20;
				if( nPos < 0 )
					nPos = 0;
				break;

			case KEY_PGDN:
			case ' ':
				if( nPos == nTotal - 1)
				{
					nPos = 0;
					break;
				}

				nPos += 20;
				if( nPos > (nTotal - 1) )
					nPos = nTotal - 1;
				break;

			case Ctrl('F'):
				if( nMode == RA_SYSOP )
				{
					wsprintf(szTemp, "���g�峹�ɦW���G%s\\%s", szPath, t[nPos - nStart].filename);
					bbs->pressanykey(szTemp);

					if( t[nPos - nStart].filename[0] == 'L' )
					{
					char szBuf[100];
						GetLink(bbs, szTemp + 16, szTemp + 16);
						wsprintf(szBuf, "�� Link ���V�G%s", szTemp + 16);
						bbs->pressanykey(szBuf);
					}

					bUpdate = true;
				}
				break;

			case 'c':
				if( !nTotal )
					break;

				if( t[nPos - nStart].filename[0] == 'L' )
				{
					wsprintf(szTemp, "%s\\%s", szPath, t[nPos - nStart].filename);
					GetLink(bbs, szTemp, bbs->szToCopy);
				} else
					wsprintf(bbs->szToCopy, "%s\\%s", szPath, t[nPos - nStart].filename);
				strcpy(bbs->szToCopyTitle, t[nPos - nStart].title + 3);
				bbs->pressanykey("�ɮ׼аO�����C[�`�N] ������~��R�����!");
				break;

			case 'd':
				if( !nMode || !nTotal )
					break;

				if( !bbs->SelectData(1, 0, "�T�w�R���H", c_yesno, 2, 1) )
				{
					Delete(nPos);
					wsprintf(szTemp, "%s\\%s", szPath, t[nPos - nStart].filename);
					if( t[nPos - nStart].filename[0] == 'D' )
						::DeleteDirectory(szTemp);
					else
						::DeleteFile(szTemp);
					DoDelete();
				}
				bUpdate = true;
				break;

			case 'g':
				if( !nMode )
					break;

				if( bbs->getdata(1, 0, "�s�W�ؿ����D�G", szTemp, 51) )
				{
				time_t now;
				struct tm* tm;

					time(&now);
					tm = localtime(&now);

					wsprintf(a.title, "�� %s", szTemp);
					::StampFile(a.filename, 'D');
					wsprintf(a.date, "%2d/%02d", tm->tm_mon + 1, tm->tm_mday);
					wsprintf(a.year, "%d", tm->tm_year);
					strcpy(a.owner, bbs->GetUserId());
					a.mode = 0;

					Append(&a);

					wsprintf(szTemp, "%s\\%s", szPath, a.filename);
					::CreateDirectory(szTemp, NULL);
				}
				bUpdate = true;
				break;

			case 'l':
				if( !nMode )
					break;

				bUpdate = true;

				if( bbs->getdata(22, 0, "�ت��ɮסG", szTemp, 61) )
				{
				FILE** fp;
				char szFile[DATASIZE];

					fp = bbs->GetFreeFP();
					if( !fp )
					{
						bbs->pressanykey("�L�k�}���ɮסI");
						break;
					}

					if( !IsValidLink(szTemp) || !(*fp = fopen(szTemp, "r") ) )
					{
						bbs->pressanykey(ERR_FILENAME);
					} else if( bbs->getdata(23, 0, "���D�G", a.title + 3, 61) )
					{
					time_t now;
					struct tm* tm;

						time(&now);
						tm = localtime(&now);

						memcpy(a.title, "�� ", 3);
						::StampFile(a.filename, 'L');
						wsprintf(a.date, "%2d/%02d", tm->tm_mon + 1, tm->tm_mday);
						wsprintf(a.year, "%d", tm->tm_year);
						strcpy(a.owner, bbs->GetUserId());
						a.mode = 0;
						Append(&a);

						wsprintf(szFile, "%s\\%s", szPath, a.filename);
						fclose(*fp);

						*fp = fopen(szFile, "w");
						if( *fp )
							fprintf(*fp, szTemp);
						else
							bbs->pressanykey("�L�k�إ߳s���C");
					}
					bbs->ReleaseFP(fp);
				}
				break;

			case 'm':
				if( !nMode )
					break;

				if( bbs->getdata(1, 0, "�N�������ܡG", szTemp, 5) )
				{
				int n = atoi(szTemp);

					if( !n )
						break;

					if( n >= nTotal )
					{
						bbs->pressanykey("�����T����m�C");
						break;
					}

					DoMove(nPos, n - 1);
				}
				bUpdate = true;
				break;

			case 'n':
				if( !nMode )
					break;

				if( bbs->getdata(1, 0, "�s�W�峹���D�G", szTemp, 51) )
				{
				time_t now;
				struct tm* tm;

					time(&now);
					tm = localtime(&now);

					wsprintf(a.title, "�� %s", szTemp);
					::StampFile(a.filename, 'M');
					wsprintf(a.date, "%2d/%02d", tm->tm_mon + 1, tm->tm_mday);
					wsprintf(a.year, "%d", tm->tm_year);
					strcpy(a.owner, bbs->GetUserId());
					a.mode = 0;

					Append(&a);
				}
				bUpdate = true;
				break;

			case 'p':
				if( !nMode )
					break;

				if( !bbs->szToCopy[0] || !bbs->szToCopyTitle[0])
					break;

				bUpdate = true;
				if( !bbs->SelectData(1, 0, "�T�w�K�W�峹�H", c_yesno, 2) )
				{
				time_t now;
				struct tm* tm;

					time(&now);
					tm = localtime(&now);

					a.mode = 0;
					::StampFile(a.filename, 'M');
					wsprintf(a.title, "�� %s", bbs->szToCopyTitle);
					wsprintf(a.date, "%2d/%02d", tm->tm_mon + 1, tm->tm_mday);
					wsprintf(a.year, "%d", tm->tm_year);
					strcpy(a.owner, bbs->GetUserId());

					Append(&a);

					wsprintf(szTemp, "%s\\%s", szPath, a.filename);
					::CopyFile(bbs->szToCopy, szTemp, false);

					bbs->szToCopy[0] = bbs->szToCopyTitle[0] = 0;
				}
				break;

			case 'T':
			case 't':
				if( !nMode || !nTotal )
					break;

				if( bbs->getdata(1, 0, "�����D�G", szTemp, 51, DOECHO, t[nPos - nStart].title + 3) )
				{
					strcpy(t[nPos - nStart].title + 3, szTemp);
					Modify(nPos, &t[nPos - nStart]);
				}
				bUpdate = true;
				break;

			case 'E':
				if( !nMode || !nTotal )
					break;

				wsprintf(szTemp, "%s\\%s", szPath, t[nPos - nStart].filename);

				if( t[nPos - nStart].filename[0] == 'D' )
					break;
				else if( t[nPos - nStart].filename[0] == 'L' )
				{
				char szLink[DATASIZE];

					if( GetLink(bbs, szTemp, szLink) )
						bbs->Edit(szLink, 0, t[nPos - nStart].title + 3);
				} else 
					bbs->Edit(szTemp, 0, t[nPos - nStart].title + 3);

				bUpdate = true;
				break;

			default:
				if( bbs->GlobalKeys(c) )
					bUpdate = true;
				else if( c >= '0' && c <= '9' )
				{
					if( (i = bbs->GetNumber(c)) )
						nPos = i - 1;
					if( nPos >= nTotal )
						nPos = nTotal - 1;
					nOldPos = nPos;
					bUpdate = true;
				}
		}
	}
}

void CDir::ALightBar ( Cbbs* bbs, int n, CDirIndex* di, bool bOn )
{

	bbs->move(3 + n % 20, 0);
	bbs->prints(" \033[%c;37;4%cm%c%4d%c\033[m  %-48s %-12s %s",
			 bOn ? '1' : '0',
			 bOn ? '4' : '0',
			 bOn ? '[' : ' ',
			 n + 1,
			 bOn ? ']' : ' ',
			 di->title,
			 di->owner,
			 di->date
			);
	bbs->clrtoeol();
}

void CDir::DoMove ( int nSource, int nTarget )
{
CDirIndex* s;
CDirIndex t;
HANDLE hFileMap;
char szTemp[DATASIZE];
int l = sizeof(CDirIndex);
int p = ( nSource > nTarget ) ? -1 : 1;
int i;
int n = ( nTarget - nSource ) * p;

	::WaitForSingleObject(hMutex, INFINITE);
	
	Get(nSource, &t, false);

	wsprintf(szTemp, "_DIRMOVEFILEMAPPING%d", this);
	hFileMap =
		::CreateFileMapping(hFile, NULL, SEC_COMMIT|PAGE_READWRITE,
							0, ::GetFileSize(hFile, NULL), szTemp);
	s = (CDirIndex*)::MapViewOfFile(hFileMap, FILE_MAP_ALL_ACCESS, 0, 0, 0);

	for( i = 0; i < n; i++ )
	{
		memcpy(s + nSource + i * p, s + nSource + i * p + p, l);
	}

	memcpy(s + nTarget, &t, l);

	::UnmapViewOfFile((LPCVOID)s);
	::CloseHandle(hFileMap);

	::ReleaseMutex(hMutex);
}

bool CDir::IsValidLink ( char* szPath )
{
	if( szPath[0] == '\\' || strchr(szPath, ':') || strstr(szPath, "..") )
		return false;

	return true;
}

bool CDir::GetLink ( Cbbs* bbs, char* szPath, char* szLink )
{
FILE **fp;

	fp = bbs->GetFreeFP();
	if( !fp )
		return false;

	*fp = fopen(szPath, "r");

	if( *fp )
	{
	char szTemp[DATASIZE];

		fgets(szTemp, DATASIZE, *fp);
		::StripNewLine(szTemp);
		strcpy(szLink, szTemp);
	} else {
		bbs->ReleaseFP(fp);
		return false;
	}

	bbs->ReleaseFP(fp);
	return true;
}
