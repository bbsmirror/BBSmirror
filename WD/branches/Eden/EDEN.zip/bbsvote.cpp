#include "stdafx.h"

static char* szVote_Desc	= ".Desc";
static char* szVote_Comment	= ".Comment";
static char* szVote_Items	= ".Items";
static char* szVote_UserVote= ".UserVote";
static char* szVote_Result	= ".Result";
 
static char* szVoteTypes[] = { "1���", "2�ݵ�" };
static char* szKeys = "ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^";

static char* szVote[] = { "Q���}", "1", "2", "3", "4", "5", "6", "7", "8", "9" };

void CDir::DoVote ( Cbbs* bbs, CBoardInfo* bi )
{
int n, c;
CVote *v;

CVoteRec t;
char szTemp[DATASIZE];

	::SetBFile(szTemp, bi->name, VOTERC);
	v = new CVote(szTemp);

	while(1)
	{
		bbs->clear();
		bbs->outs("\033[1;37m  ��  �~                    \r\n"
				  "\033[44m  �x  ��                    \r\n"
				  "\033[40m  ��  �x�~�������q�w�~����  \r\n"
				  "\033[44m  ��  �x�x  ��  ��  ��w��  \r\n"
				  "\033[40m  ���������w��  �������w��  \r\n\033[m");

		n = v->ShowVotes(bbs);
		c = bbs->SelectData(23, 0, "�п�ܧ벼���ءG", szVote, n + 1);

		if( !c )
			break;
		else {
		int i, j;
			for( i = 0, j = -1; j != c - 1; i++ )
			{
				if( !v->Get(i, &t) )
					break;
				if( t.filename[0] )
					j++;
			}
			c = i - 1;

			v->DoVote(bbs, bi, c);
		}
	}
}

void CDir::VoteManager ( Cbbs* bbs, CBoardInfo* bi )
{
static char* szSel[] = { "N�|��s�벼", "V�d�ݧ벼", "C�����}��", "D�R���벼", "Q���}" };
int c, n;
char szTemp[DATASIZE];

CVote *v;

	::SetBFile(szTemp, bi->name, VOTERC);
	v = new CVote(szTemp);

	do
	{
		bbs->stand_title("��U�z���t���@��");
		bbs->move(2, 0);
		bbs->outs("\033[1;37m  ��  �~                    \r\n"
				  "\033[44m  �x  ��                    \r\n"
				  "\033[40m  ��  �x�~�������q�w�~����  \r\n"
				  "\033[44m  ��  �x�x  ��  ��  ��w��  \r\n"
				  "\033[40m  ���������w��  �������w��    Manager.");
		// Show all available votes
		n = v->ShowVotes(bbs, 8);

		c = bbs->SelectData(23, 0, "", szSel, 5, 4);

		if( c == 1 || c == 2 || c == 3 )
		{
		CVoteRec t;
		int i, j;

			n = bbs->SelectData(23, 0, "�п�ܧ벼���ءG", szVote, n + 1);
			if( !n )
				continue;
			for( i = 0, j = -1; j != n - 1; i++ )
			{
				if( !v->Get(i, &t) )
					break;
				if( t.filename[0] )
					j++;
			}
			n = i - 1;
		}

		switch( c )
		{
			case 0:
				c = v->New(bbs, bi);

				if( c )
					bbs->pressanykey("�i�H�}�l�벼�F!");
				else
					bbs->pressanykey(MSG_CANCEL);
				break;

			case 1:
				v->View(bbs, bi, n);
				break;

			case 2:
				v->Close(bbs, bi, n);
				break;

			case 3:
				v->Close(bbs, bi, n, true);
				break;
		}
	} while( c != 4 ) ;

	delete v;
}

void CBoards::CloseVotes ( Cbbs* bbs )
{
CBoardInfo bi;
CVote* v;
CVoteRec t;

char szTemp[DATASIZE];
int i, j;

time_t now;

	time(&now);

	for( i = 0; i < MAXBOARD; i++ )
		if( !Get(i, &bi) )
			break;
		else if( !bi.votenum )
			continue;
		else {
			::SetBFile(szTemp, bi.name, VOTERC);
			v = new CVote(szTemp);
			for( j = 0; j < 10; j++ )
				if( !v->Get(j, &t) )
					break;
				else {
					if( t.end <= now )
					{
						v->Close(bbs, &bi, j);
						if( bi.votenum )
							bi.votenum--;
					}
				}
			delete v;

			ModifyS(bi.name, &bi);
		}
}

bool CVote::New ( Cbbs* bbs, CBoardInfo* bi )
{
CVoteRec v;
char szTemp[DATASIZE];
int i, n;
FILE** fp;

	memset(&v, 0, sizeof(CVoteRec));

	::StampFile(v.filename, 'V');
	strcpy(v.holder, bbs->GetUserId());

	bbs->stand_title("�|��s���벼");

	if( GetNum() >= 9 )
	{
		bbs->pressanykey("��p�I�@�ӬݪO�P�ɳ̦h�u�঳ 9 �ӧ벼�|��I");
		return false;
	}

	if( !bbs->getdata(3, 0, "��J�����벼���D�D�G", v.title, 36) )
		return false;

	bbs->pressanykey("�Ы����N��s�覹����[�벼����]...");

	::SetVFile(szTemp, bi->name, v.filename, szVote_Desc);

	if( !bbs->Edit(szTemp, 0, "[�벼����]") )
	{
		DeleteVoteFiles(bi, v.filename);
		return false;
	}

	v.type = bbs->SelectData(4, 0, "�п�ܧ벼�����G", szVoteTypes, 2);

	do
	{
		bbs->getdata(6, 0, "�п�ܧ벼�|��Ѽ�(�ܤ� 1 ��)�G", szTemp, 3);
		i = atoi(szTemp);
	} while( i < 1 ) ;

	time(&v.start);
	v.end = v.start + i * 86400;

	if( v.type == 0 )
	{
	char szItem[4];

		bbs->clear();
		bbs->move(0, 0); bbs->outs("�Ш̧ǿ�J�벼���ءA��[Enter]�����C");

		::SetVFile(szTemp, bi->name, v.filename, szVote_Items);
		fp = bbs->GetFreeFP();
		*fp = fopen(szTemp, "w");

		for( i = 0; i < 30; i++ )
		{
			wsprintf(szItem, "%c) ", szKeys[i]);
			bbs->getdata(2 + i % 15, 40 * (i / 15), szItem, szTemp, 36);
			if( !szTemp[0] )
				break;

			fprintf(*fp, "%s\n", szTemp);
		}

		bbs->ReleaseFP(fp);

		if( !i )
		{
			DeleteVoteFiles(bi, v.filename);
			return false;
		}

		wsprintf(szTemp, "�̦h�벼��(1��%d)�H", i);

		do
		{
			bbs->getdata(17, 0, szTemp, szItem, 3);
			n = atoi(szItem);
		} while( n < 1 || n > i );

		v.num = n;
	}

	n = SearchNew();

	if( !Modify(n, &v) )
		return false;

	bi->votenum++;
	return !(boards->ModifyS(bi->name, bi) < 0);
}

bool CVote::Close ( Cbbs* bbs, CBoardInfo* bi, int n, bool bCancel )
{
CVoteRec v;
char szTemp[MAX_PATH];

	if( !Get(n, &v) )
		return false;

	if( !bCancel )
	{
	FILE** fpin;
	FILE** fpout;
	time_t now;

		::SetVFile(szTemp, bi->name, v.filename, szVote_Result);
		fpout = bbs->GetFreeFP();
		*fpout = fopen(szTemp, "w");

		wsprintf(szTemp, "%s\\Settings\\VoteResult.note", BBSDIR);
		fpin = bbs->GetFreeFP();
		*fpin = fopen(szTemp, "r");
		if( *fpin )
			::AppendToFile(*fpout, *fpin);
		bbs->ReleaseFP(fpin);

		time(&now);
		Cdate(&now, szTemp);
		fprintf(*fpout, "\n�� �벼�D�D�G%s\n\n", v.title);
		fprintf(*fpout, "�� �벼�����G%s\n\n", szTemp);
		fprintf(*fpout, "�� �����D�شy�z�G\n\n");

		::SetVFile(szTemp, bi->name, v.filename, szVote_Desc);
		fpin = bbs->GetFreeFP();
		*fpin = fopen(szTemp, "r");
		::AppendToFile(*fpout, *fpin);
		bbs->ReleaseFP(fpin);

		fprintf(*fpout, "\n\n�� �벼���G�G\n\n");

		if( v.type == 0 )
		{
		int nVotes[30];
		bool bVotes[30];
		int i, j;

			memset(&nVotes, 0, sizeof(int) * 30);
			::SetVFile(szTemp, bi->name, v.filename, szVote_UserVote);
			fpin = bbs->GetFreeFP();
			*fpin = fopen(szTemp, "r");
			if( *fpin )
				while( fgets(szTemp, DATASIZE, *fpin) )
				{
					memcpy(&bVotes, strchr(szTemp, ':') + 1, sizeof(bool) * 30);
					for( j = 0; j < 30; j++ )
						if( bVotes[j] )
							nVotes[j]++;
				}
			bbs->ReleaseFP(fpin);

			::SetVFile(szTemp, bi->name, v.filename, szVote_Items);
			fpin = bbs->GetFreeFP();
			*fpin = fopen(szTemp, "r");
			for( i = 0, j = 0; i < 30; i++ )
			{
				if( !fgets(szTemp, DATASIZE, *fpin) )
					break;

				::StripNewLine(szTemp);
				fprintf(*fpout, "    %-36s  %4d ��\n", szTemp, nVotes[i]);
				j += nVotes[i];
			}
			bbs->ReleaseFP(fpin);

			fprintf(*fpout, "\n�� �`���� = %d ��\n", j);
			fprintf(*fpout, "\n�� �ϥΪ̫�ĳ�G\n\n");
		}

		::SetVFile(szTemp, bi->name, v.filename, szVote_Comment);
		fpin = bbs->GetFreeFP();
		*fpin = fopen(szTemp, "r");
		if( *fpin )
			::AppendToFile(*fpout, *fpin);
		bbs->ReleaseFP(fpin);

		bbs->ReleaseFP(fpout);

		::SetVFile(szTemp, bi->name, v.filename, szVote_Result);

	char szTitle[DATASIZE];

		wsprintf(szTitle, "[%s]�O�벼���G", bi->name);
		::PutToBoard(bbs, bi->name, "-�p���ﱡ��-", szTitle, szTemp);
		::PutToBoard(bbs, "VoteRecord", "-�p���ﱡ��-", szTitle, szTemp);

		::DeleteFile(szTemp);
	}

	DeleteVoteFiles(bi, v.filename);
	Delete(n);

	if( bi )
		bi->votenum--;
	boards->ModifyS(bi->name, bi);

	return true;
}

void CVote::View ( Cbbs* bbs, CBoardInfo* bi, int n )
{
char szTemp[DATASIZE];
CVoteRec v;
int nVotes[30];
bool bVotes[30];
int i, j;
FILE** fpin;

	if( !Get(n, &v) )
	{
		bbs->pressanykey("�L�k�d�ݧ벼�I");
		return ;
	}

	if( v.type == 0 )
	{
		bbs->stand_title("�d�ݧ벼");

		bbs->move(2, 0);
		bbs->prints("�벼�D�D�G%s\r\n", v.title);
		bbs->prints("�|��̡G%s  �C�H���ơG%d�� �����G���\r\n", v.holder, v.num);
		bbs->prints("�����벼�N������G");
		::Cdate(&v.end, szTemp); bbs->prints(szTemp);

		memset(&nVotes, 0, sizeof(int) * 30);
		::SetVFile(szTemp, bi->name, v.filename, szVote_UserVote);
		fpin = bbs->GetFreeFP();
		*fpin = fopen(szTemp, "r");

		if( *fpin )
			while( fgets(szTemp, DATASIZE, *fpin) )
			{
				memcpy(&bVotes, strchr(szTemp, ':') + 1, sizeof(bool) * 30);
				for( j = 0; j < 30; j++ )
					if( bVotes[j] )
						nVotes[j]++;
			}
		bbs->ReleaseFP(fpin);

		::SetVFile(szTemp, bi->name, v.filename, szVote_Items);
		fpin = bbs->GetFreeFP();
		*fpin = fopen(szTemp, "r");
		for( i = 0; i < 30; i++ )
		{
			if( !fgets(szTemp, DATASIZE, *fpin) )
				break;

			::StripNewLine(szTemp);
			bbs->move(6 + (i % 15), 40 * (i / 15));
			bbs->prints("%c) %-30s %d��", szKeys[i], szTemp, nVotes[i]);
		}
		bbs->ReleaseFP(fpin);

		bbs->pressanykey();
	} else {
		::SetVFile(szTemp, bi->name, v.filename, szVote_Comment);
		bbs->more(szTemp);
	}
}

bool CVote::DoVote ( Cbbs* bbs, CBoardInfo* bi, int n )
{
CVoteRec v;
bool bComment;
char szTemp[DATASIZE];
FILE** fp;
int nVoted = 0;

	if( !Get(n, &v) )
		return false;

	::SetVFile(szTemp, bi->name, v.filename, szVote_UserVote);
	fp = bbs->GetFreeFP();
	*fp = fopen(szTemp, "r");
	if( *fp )
	{
		if( v.type == 0 )
			while( fgets(szTemp, DATASIZE, *fp) )
			{
				*(strchr(szTemp, ':')) = '\0';
				if( !_stricmp(szTemp, bbs->GetUserId()) )
				{
					bbs->ReleaseFP(fp);
					bbs->pressanykey("�����벼�A�A�w��L�F�I�@�H�@���A�j�a�����C");
					return false;
				} else
					nVoted++;
			}
		else
			while( fgets(szTemp, DATASIZE, *fp) )
			{
				::StripNewLine(szTemp);
				if( !_stricmp(szTemp, bbs->GetUserId()) )
				{
					bbs->ReleaseFP(fp);
					bbs->pressanykey("�����벼�A�A�w��L�F�I�@�H�@���A�j�a�����C");
					return false;
				} else
					nVoted++;
			}
	}

	bbs->ReleaseFP(fp);

	bbs->clear();

	::SetVFile(szTemp, bi->name, v.filename, szVote_Desc);
	bbs->more(szTemp);

	bbs->stand_title("�벼�c");

	if( v.type == 0 )
	{
	int n, c;
	int nTotal;
	bool bVoted[30];

		bbs->move(1, 0);
		bbs->prints("�벼�覡�G�T�w�n�z����ܫ�A��J��N�X(A, B, C...)�Y�i�C\r\n");
		bbs->prints("�����벼�A�i�H�� %d ���C �� 0 �����벼  �� 1 �����벼\r\n", v.num);
		bbs->prints("�����벼�N������G");
		::Cdate(&v.end, szTemp); bbs->prints(szTemp);

		::SetVFile(szTemp, bi->name, v.filename, szVote_Items);
		fp = bbs->GetFreeFP();
		if( !fp )
			return false;
		*fp = fopen(szTemp, "r");
		if( !*fp )
		{
			bbs->ReleaseFP(fp);
			return false;
		}

		for( n = 0; n < 30; n++ )
		{
			if( !fgets(szTemp, DATASIZE, *fp) )
				break;

			::StripNewLine(szTemp);
			bbs->move(4 + (n % 15), 40 * (n / 15));
			bbs->prints("   %c) %s", szKeys[n], szTemp);
		}
		nTotal = n;

		bbs->ReleaseFP(fp);

		n = v.num;
		memset(bVoted, 0, sizeof(bool) * 30);

		while(1)
		{
			bbs->getdata(21, 0, "�п�ܧ벼���ءG", szTemp, 2);

			if( szTemp[0] == '0' )
				return false;
			else if( szTemp[0] == '1' )
				break;
			else {
				c = szTemp[0];
				if( c >= 'a' && c <= 'z' )
					c -= 'a';
				else
					c -= 'A';

				if( (c + 1) > nTotal || c < 0 )
				{
					bbs->beep();
					continue ;
				}

				if( !n && !bVoted[c] )
				{
					bbs->beep();
					continue ;
				}

				bVoted[c] = !bVoted[c];

				bbs->move(4 + (c % 15), 40 * (c / 15));
				if( bVoted[c] )
				{
					bbs->outs("��");
					n--;
				} else {
					bbs->outs("  ");
					n++;
				}

				bbs->move(23, 0);
				bbs->prints("�z�٥i�H�� %d ���C", n);
			}
		}

		if( n >= v.num )
			return false;

		::SetVFile(szTemp, bi->name, v.filename, szVote_UserVote);
		fp = bbs->GetFreeFP();
		*fp = fopen(szTemp, "a");
		fprintf(*fp, "%s:", bbs->GetUserId());
		fwrite(bVoted, sizeof(bool), 30, *fp);
		fprintf(*fp, "\n");
		bbs->ReleaseFP(fp);

		bComment =
			!bbs->SelectData(23, 0, "�z��o�����벼�������_�Q�N���ܡH", c_yesno, 2, 1);
		if( bComment )
			bbs->clear();
	} else
		bComment = true;

	if( bComment )
	{
	char szComment[3][80];

		memset(szComment, 0, 80 * 3);
		bbs->move(16, 0);
		bbs->outs("�п�J�z���N��( 3 ��)�G");
		for( n = 0; n < 3; n++ )
		{
			szComment[n][0] = '\0';
			if( !bbs->getdata(17 + n, 0, "�G", szComment[n], 77) )
				break;
		}

		if( n )
		{
			::SetVFile(szTemp, bi->name, v.filename, szVote_Comment);
			fp = bbs->GetFreeFP();
			*fp = fopen(szTemp, "a");
			fprintf(*fp, "�ϥΪ� %s ���N���G\n", bbs->GetUserId());
			for( n = 0; n < 3; n++ )
				fprintf(*fp, "%s\n", szComment[n]);
			fprintf(*fp, "\n");
			bbs->ReleaseFP(fp);

			if( v.type == 1 )
			{
				::SetVFile(szTemp, bi->name, v.filename, szVote_UserVote);
				fp = bbs->GetFreeFP();
				*fp = fopen(szTemp, "a");
				fprintf(*fp, "%s\n", bbs->GetUserId());
				bbs->ReleaseFP(fp);
			}
		}
	}

	wsprintf(szTemp, "�벼�����I�ثe�w�벼�ơG%d", nVoted + 1);
	bbs->pressanykey(szTemp);

	return true;
}

int CVote::SearchNew (  )
{
int i;
CVoteRec t;

	::WaitForSingleObject(hMutex, INFINITE);

	for( i = 0;  ; i++ )
	{
		if( !Get(i, &t, false) )
			break;
		if( !t.filename[0] )
		{
			::ReleaseMutex(hMutex);
			return i;
		}
	}

	::ReleaseMutex(hMutex);
	return i;
}

int CVote::ShowVotes ( Cbbs* bbs, int nBeginLine )
{
CVoteRec v;
int i, n;

	bbs->move(nBeginLine, 0);
	bbs->prints("\033[1;37;46m  No. ���  ���D                                 ����  �|���        �I����\r\n\033[m");
	for( i = 0, n = 0; i < 9; i++ )
	{
		if( !Get(i, &v) || !v.filename[0] )
			continue;

		bbs->prints("  %2d %2d/%2d  %-36s %4s  %-12s %s\r\n",
					n + 1, 2, 12, v.title, v.type ? "�ݵ�" : "���", v.holder, " 3/14");
		n++;
	}

	return n;
}

void CVote::DeleteVoteFiles ( CBoardInfo* bi, char* szVoteName )
{
char szTemp[MAX_PATH];

	::SetVFile(szTemp, bi->name, szVoteName, szVote_Desc);
	::DeleteFile(szTemp);

	::SetVFile(szTemp, bi->name, szVoteName, szVote_Comment);
	::DeleteFile(szTemp);

	::SetVFile(szTemp, bi->name, szVoteName, szVote_Items);
	::DeleteFile(szTemp);

	::SetVFile(szTemp, bi->name, szVoteName, szVote_UserVote);
	::DeleteFile(szTemp);
}
