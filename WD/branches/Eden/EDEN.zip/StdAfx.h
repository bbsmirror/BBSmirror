// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_)
#define AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers


// Windows Header Files
#include <windows.h>
#include <shellapi.h>
#include <winsock.h>

// C RunTime Header Files
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cstdarg>
#include <tchar.h>

//#include <memory>

// C++ Header Files
#include <queue>
#include <deque>
#include <vector>

// BBS Proto Header File
#include "bbsproto.h"

// BBS Header Files
#include "bbsdefine.h"
#include "bbsperm.h"
#include "bbshabit.h"
#include "bbsmodes.h"
#include "bbsmenu.h"
#include "bbstruct.h"

// Local Header Files
#include "EdenBBS.h"
#include "resource.h"
#include "telnet.h"

// TODO: reference additional headers your program requires here

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_)
