#include "stdafx.h"

// Gold
bool Cbbs::HaveGold ( int n )
{
	passwds->Search(cuser.userid, &cuser);
	return (cuser.goldmoney >= n);
}

void Cbbs::InGold ( int n )
{
	passwds->Search(cuser.userid, &cuser);
	cuser.goldmoney += n;
	passwds->ModifyS(cuser.userid, &cuser);
}

bool Cbbs::DeGold ( int n )
{
	if( !HaveGold(n) )
		return false;

	cuser.goldmoney -= n;
	passwds->ModifyS(cuser.userid, &cuser);
	return true;
}

bool CPasswds::HaveUGold ( char* szUser, int n )
{
CUserInfo u;

	passwds->Search(szUser, &u);
	return (u.goldmoney >= n);
}

void CPasswds::InUGold ( char* szUser, int n )
{
CUserInfo u;

	passwds->Search(szUser, &u);
	u.goldmoney += n;
	passwds->ModifyS(szUser, &u);
}

bool CPasswds::DeUGold ( char* szUser, int n )
{
CUserInfo u;

	if( !HaveUGold(szUser, n) )
		return false;

	passwds->Search(szUser, &u);
	u.goldmoney -= n;
	passwds->ModifyS(szUser, &u);
	return true;
}

// Silver
bool Cbbs::HaveSilver ( int n )
{
	passwds->Search(cuser.userid, &cuser);
	return (cuser.silvermoney >= n);
}

void Cbbs::InSilver ( int n )
{
	passwds->Search(cuser.userid, &cuser);
	cuser.silvermoney += n;
	passwds->ModifyS(cuser.userid, &cuser);
}

bool Cbbs:: DeSilver ( int n )
{
	if( !HaveSilver(n) )
		return false;

	cuser.silvermoney -= n;
	passwds->ModifyS(cuser.userid, &cuser);
	return true;
}

bool CPasswds::HaveUSilver ( char* szUser, int n )
{
CUserInfo u;

	passwds->Search(szUser, &u);
	return (u.silvermoney >= n);
}

void CPasswds::InUSilver ( char* szUser, int n )
{
CUserInfo u;

	passwds->Search(szUser, &u);
	u.silvermoney += n;
	passwds->ModifyS(szUser, &u);
}

bool CPasswds::DeUSilver ( char* szUser, int n )
{
CUserInfo u;

	if( !HaveUGold(szUser, n) )
		return false;

	passwds->Search(szUser, &u);
	u.silvermoney -= n;
	passwds->ModifyS(szUser, &u);
	return true;
}

