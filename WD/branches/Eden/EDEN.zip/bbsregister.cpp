#include "stdafx.h"

void Cbbs::NewUser ( CUserInfo* u )
{
int nAttempt;
char szTemp[DATASIZE];

	clear();
	showfile("Settings\\newuser.note");

	for( nAttempt = MAXATTEMPT; nAttempt; nAttempt-- )
	{
		getdata(14, 0, MSG_UID, u->userid, IDLEN + 1, DOECHO, 0);//u->userid
		if( !::IsValidId(u->userid) )
		{
			pressanykey("�L�k�����o�ӥN���A�Шϥέ^��r���A�åB���n�]�t�Ů�");
			continue;
		}

		if( passwds->Search(u->userid) < 0)
			break;
		pressanykey(ERR_UINUSE);
	}

	if( !nAttempt )
	{
		pressanykey("���~�Ӧh���I�U���A�ӧa�I");
		ExitBBS(EXIT_GRACEFULLY);
	}

	for( nAttempt = MAXATTEMPT; nAttempt; nAttempt-- )
	{
	char confirm[MAXPASS];

		getdata(15, 0, MSG_PASSWD, szTemp, MAXPASS, PASS, 0);
		if( strlen(szTemp) < 4)
		{
			pressanykey("�K�X�ӵu�A�ܤ֭n�|�Ӧr�I");
			continue;
		}
		if( !_stricmp(szTemp, u->userid) )
		{
			pressanykey("�K�X�ФŻP id �p�P�I");
			continue;
		}

		getdata(16, 0, MSG_CONFIRM, confirm, MAXPASS, PASS, 0);

		if( !strcmp(szTemp, confirm) )
			break;
		pressanykey("�K�X���šA�Э��s��J�C");
	}

	::GeneratePassword(szTemp, u->passwd);

	if( !nAttempt )
	{
		pressanykey("���~�Ӧh���I�U���A�ӧa�I");
		ExitBBS(EXIT_GRACEFULLY);
	}

	::SetUserDir(szTemp, u->userid);
	::CreateDirectory(szTemp, NULL);

	u->userlevel = PERM_NEWUSER;

	passwds->Modify(passwds->SearchNew(), u);
}

void Cbbs::DoNewUserShow (  )
{
CBoardInfo bi;
char szTemp[DATASIZE];

	if( boards->Search("NewUser", &bi) )
	{
	CDir** dir;
		dir = GetFreeDir();

		pressanykey("�s�Ӫ���I�ۧڤ��Ф@�U�a�I");

		::SetBFile(szTemp, "NewUser", DIRFILE);
		*dir = new CDir(szTemp);
		(*dir)->PostArticle(this, &bi);

		ReleaseDir(dir);
	}

	DoRegister();

	UserMenu->Privacy(this);
}

void Cbbs::DoRegister (  )
{
	if( !SelectData(23, 0, "�z�|����g���U��A�аݭn�{�b��g�ܡH", c_yesno, 2) )
	{
	CRegister regform;

		memset(&regform, 0, sizeof(CRegister));
		while(1)
		{
			stand_title("��g���U��");

			move(2, 0); prints("�ϥΪ̦W�١G%s(%s)\r\n�п�J�z���G", cuser.userid, cuser.username);
			strcpy(regform.szUser, cuser.userid);
			strcpy(regform.szNickname, cuser.username);
			getdata(4, 0, "�u��m�W�G", regform.szRealName, 20, DOECHO, cuser.realname);
			getdata(5, 0, "�p���a�}�G", regform.szAddress, 50, DOECHO, cuser.address);
			getdata(6, 0, "�p���q�ܡG", regform.szTel, 20, DOECHO, regform.szTel);
			getdata(7, 0, "E-Mail�a�}�G", regform.szEMail, 50, DOECHO, cuser.email);

		int n = SelectData(23, 0, "�H�W��ƬO�_���T�H", c_yesno, 3, 1);

			if( n == 0 )
			{
			int i, nTotal;
			bool bLast = true;
			CRegister t;

				nTotal = RegData->GetNum();
				for( i = 0; i < nTotal; i++ )
				{
					RegData->Get(i, &t);
					if( !t.szUser[0] )
					{
						bLast = false;
						break;
					}
				}

				if( bLast )
					RegData->Append(&regform);
				else
					RegData->Modify(i, &regform);

				strcpy(cuser.justify, REGISTERED);
				passwds->ModifyS(cuser.userid, &cuser);
				::MailTo(this, cuser.userid, "SYSOP", "[���U����]", "Settings\\Register.Note", true);
				break;
			} else if( n == 2 )
				break;
		}
	}
}
