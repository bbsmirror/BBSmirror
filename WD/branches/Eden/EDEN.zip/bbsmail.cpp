#include "stdafx.h"

bool Cbbs::CheckMail ( char* szUser )
{
char szTemp[DATASIZE];

	::SetUserFile(szTemp, szUser ? szUser : cuser.userid, DIRFILE);
CDir** dir;
	dir = GetFreeDir();
	if( !dir )
		return false;

	*dir = new CDir(szTemp);

int i = (*dir)->GetNum() - 1;
bool r = false;
CDirIndex t;

	for( ; i >= 0; i-- )
	{
		(*dir)->Get(i, &t);
		if( t.mode & DI_UNREAD )
		{
			r = true;
			break;
		}
	}

	ReleaseDir(dir);

	return r;
}

void CMailMenu::InitElement (  )
{
CbbsMenuItem temp[10] = {
	PERM_BASIC,		"RNew          [�\Ū�s�H]", "�ݬݱz�s���H���P^o^",
	PERM_BASIC,		"RRead         [�p�H�H�c]", "�ݬݱz�Ҧ��ӤH���H��:)",
	PERM_BASIC,		"SSend         [�����H�H]", "�H�H����L������",
	PERM_BASIC,		"LList         [�s�ձH�H]", "�H�H���@�ﯸ���o!",
	PERM_BASIC,		"IInternet     [�����l��]", "�H�H���D�������H�c:)",
	PERM_LOGINOK,	"FForward      [�۰���H]", "�]�w�۰���H���\��",
	PERM_LOGINOK,	"MMailRejects  [�ɫH�W��]", "�]�w�H�󪺩ڵ����Ӥ�:X",
	PERM_BASIC,		"YYes, sir!    [�ԴA����]", "������Q�򯸤u�������N�ӳo�a�I",
	PERM_ACCOUNTS,	"AAll          [�t�γq�i]", "�H�H���Ҧ������ͭ�(�S�ƧO�å�)",
	0, 0, 0};

	this->menu = new CbbsMenuItem[10];

	memcpy((void*)menu, (void*)temp, sizeof(CbbsMenuItem) * 10);
}

int CMailMenu::ExecMenu ( int nIndex, Cbbs* bbs )
{
	switch( nIndex )
	{
		case 0:
			return New(bbs);
		case 1:
			return Read(bbs);
		case 2:
			return Send(bbs);
		case 3:
			return MailList(bbs);
		case 4:
			return Internet(bbs);
		case 5:
			return Forward(bbs);
		case 6:
			return Reject(bbs);
		case 7:
			return MailSYSOP(bbs);
		case 8:
			return MailAll(bbs);
	}

	return 0;
}

void CDir::ReadMail ( Cbbs* bbs )
{
CDirIndex t[20];
CDirIndex a;
int nPos, nOldPos;
int nStart;
int nTotal;
bool bUpdate = true;	// Update the whole screen
bool bReload;			// Just update the posts

bool bInSearch = false;
int *nForSearch;
int nSearchTotal;
int nPosBeforeSearch;

char szTemp[DATASIZE];
char szPath[DATASIZE];
int i;
//int n;
int c;

	for( i = -1; Get(i + 1, &t[0]); i++ )
		if( t[0].mode & DI_UNREAD )
			break;

	if( i < 0 )
		i = 0;

	nPos = i;
	nStart = nPos / 20 * 20;

	while(1)
	{
		if( bUpdate )
		{
			if( bInSearch )
			{
				nPosBeforeSearch = nPos;
				nPos = nStart = 0;
				nTotal = nSearchTotal;
			} else {
			unsigned long d = ::GetFileSize(hFile, NULL);

				if( !d || d == 0xFFFFFFFF )		// Is empty or does not exist
				{
					bbs->pressanykey("�z�S���ӫH�C");
					return ;
				}

				nTotal = d / sizeof(CDirIndex);
			}

			if( nPos >= nTotal )
			{
				nStart = nPos / 20 * 20;
				nOldPos = nPos = nTotal - 1;
			}

			bbs->SetMode(RMAIL);

			bbs->clear();
			bbs->ShowTitle("�ӤH�l��");

			bbs->move(1, 0);
			bbs->outs(" \033[1;37m[��]\033[0m���} \033[1m[��]\033[0m�\Ū \033[1m[Ctrl+P]\033[0m�o���峹"
					  " \033[1m[b]\033[0m�i�O�e�� \033[1m[d]\033[0m�R�� \033[1m[z]\033[0m��ذ�"
					  " \033[1m[Ctrl+Z]����\033[0m\r\n");
			bbs->outs("\033[1;37;46m �s��   �� �� �ϥζq �@  ��        ��    �D                                    \033[m");

			bReload = true;
			bUpdate = false;
		}

		if( bReload )
		{
			if( bInSearch )
			{
				for( i = 0; i < 20; i++ )
				{
					Get(nForSearch[nStart + i], &t[i]);
					if( (nStart + i) >= nTotal )
						break;

					MLightBar(bbs, nStart + i, &t[i]);
				}
			} else
				for( i = 0; i < 20; i++ )
				{
					if( !Get(nStart + i, &t[i]) )
						break;

					MLightBar(bbs, nStart + i, &t[i]);
				}

			nOldPos = nPos;

			bbs->outs("\r\n");
			bbs->clrtobot();

			bbs->move(23, 0);
			bbs->outs("\033[1;37;44m  �\Ū�峹  \033[46m"
					  "  \033[33m(R/Y)\033[37m�^�H \033[33m(a)\033[37m�j�M�@��"
					  " \033[33m(=[]<>)\033[37m�����D�D \033[33m(����)\033[37m�W�U��"
					  " \033[33m(��)\033[37m���}  \033[m");

			bReload = false;
		}

		if( bInSearch && !nTotal )
		{
			delete [] nForSearch;
			bInSearch = false;
			nPos = nPosBeforeSearch;
			nPosBeforeSearch = -1;
			bUpdate = true;
			continue ;
		}

		if( nOldPos != nPos )
			MLightBar(bbs, nOldPos, &t[nOldPos - nStart]);

		MLightBar(bbs, nPos, &t[nPos - nStart], true);
		nOldPos = nPos;

		c = bbs->igetkey();

		switch(c)
		{
			case 'e':
			case KEY_LEFT:
				if( bInSearch )
				{
					delete [] nForSearch;
					bInSearch = false;
					nPos = nPosBeforeSearch;
					bUpdate = true;
					break;
				} else
					return ;

			case '\r':
			case '\n':
			case 'r':
			case KEY_RIGHT:
			int o;
Redo:

				if( nPos < nTotal && Get( bInSearch ? nForSearch[nPos] : nPos, &a) && nPos >= 0 )
				{
					if( a.mode & DI_UNREAD )
						a.mode &= ~(DI_UNREAD);
					Modify(nPos, &a);

					o = nPos;
					::SetUserFile(szTemp, bbs->GetUserId(), a.filename);
					strcpy(bbs->szCurrTitle, a.title + (_strnicmp(a.title, "R: ", 3) ? 0 : 3));
					switch( bbs->more(szTemp, MOREREAD) )
					{
						case REPLYPOST:
							goto DoReply;
							break;

						case LAST:
							if( nPos )
							{
								nPos--;
								goto Redo;
							}
							break;

						case NEXT:
							nPos++;
							goto Redo;
							break;

						case FIRSTPOST:
							for( i = nPos - 1; i >= 0; i-- )
							{
								Get( bInSearch ? nForSearch[i] : i, &a);
								if( !strcmp(a.title, bbs->szCurrTitle) )
								{
									nPos = i;
									goto Redo;
								}
							}
							break;

						case LASTPOST:
							for( i = nPos - 1; i >= 0; i-- )
							{
								Get( bInSearch ? nForSearch[i] : i, &a);
								if( !strcmp(a.title + (strncmp(a.title, "R: ", 3) ? 0 : 3), bbs->szCurrTitle) )
								{
									nPos = i;
									goto Redo;
								}
							}
							break;

						case NEXTPOST:
							for( i = nPos + 1; i <= nTotal; i++ )
							{
								Get( bInSearch ? nForSearch[i] : i, &a);
								if( !strcmp(a.title + (strncmp(a.title, "R: ", 3) ? 0 : 3), bbs->szCurrTitle) )
								{
									nPos = i;
									goto Redo;
								}
							}
							break;
					}
				} else
					nPos = o;
				bUpdate = true;
				break;

			case KEY_UP:
				if( nPos )
					nPos--;
				else
					bbs->beep();
				break;

			case 't':
				t[nPos - nStart].mode ^= DI_TAGGED;
				Modify( bInSearch ? nForSearch[nPos] : nPos, &t[nPos - nStart]);

			case KEY_DOWN:
				if( nPos >= (nTotal - 1) )
					bbs->beep();
				else
					nPos++;
				break;

			case KEY_PGUP:
				if( nPos == 0 )
					nPos = nTotal - 1;
				nPos -= 20;
				if( nPos < 0 )
					nPos = 0;
				break;

			case KEY_PGDN:
			case ' ':
				nPos += 20;
				if( nPos > (nTotal - 1) )
					nPos = nTotal - 1;
				break;

			case '/':
				if( bInSearch )
					break;

				if( bbs->getdata(23, 0, "�j�M���D�G", szTemp, 41) )
				{
					nForSearch = new int[nTotal];
					memset(nForSearch, 0, sizeof(int) * nTotal);
					nSearchTotal = DoSearch(szTemp, 0, false, nForSearch);
					if( !nSearchTotal )
						delete [] nForSearch;
					else
						bInSearch = true;
				}
				bUpdate = true;
				break;

			case '$':
				nPos = nTotal - 1;
				break;

			case Ctrl('D'):
				if( !bbs->SelectData(1, 0, "�T�w�аO�R���l��H", c_yesno, 2) )
				{
				int n;
					for( i = 0, n = 0; Get(i, &a); i++ )
						if( a.mode & DI_TAGGED )
						{
							Delete(i);
							::SetUserFile(szTemp, bbs->GetUserId(), a.filename);
							::DeleteFile(szTemp);
							n = 1;
						}

					if( n )
						DoDelete();
				}

				bUpdate = true;
				break;

			case Ctrl('F'):
				if( HAS_PERM1(PERM_SYSOP) )
				{
					wsprintf(szTemp, "���ʫH���ɦW���G%s", t[nPos - nStart].filename);
					bbs->pressanykey(szTemp);
					bUpdate = true;
				}
				break;

			case 'a':
				if( bInSearch )
					break;

				if( bbs->getdata(23, 0, "�j�M�@�̡G", szTemp, IDLEN + 1) )
				{
					nForSearch = new int[nTotal];
					memset(nForSearch, 0, sizeof(int) * nTotal);
					nSearchTotal = DoSearch(szTemp, 1, false, nForSearch);
					if( !nSearchTotal )
						delete [] nForSearch;
					else
						bInSearch = true;
				}
				bUpdate = true;
				break;

			case 'c':
				::SetUserFile(bbs->szToCopy, bbs->GetUserId(), t[nPos - nStart].filename);
				strcpy(bbs->szToCopyTitle, t[nPos - nStart].title);
				bbs->pressanykey("�ɮ׼аO�����C[�`�N] ������~��R�����!");
				break;

			case 'd':
				if( !(t[nPos - nStart].mode & DI_MARKED) )
				{
					if( !bbs->SelectData(1, 0, "�T�w�n�R�����g�峹�H", c_yesno, 2, 1) )
					{
						Delete(bInSearch ? nForSearch[nPos] : nPos);
						::SetUserFile(szTemp, bbs->GetUserId(), t[nPos - nStart].filename);
						::DeleteFile(szTemp);
						DoDelete();
					}
					bUpdate = true;
				}
				break;

			case 'm':
				t[nPos - nStart].mode ^= DI_MARKED;
				Modify(bInSearch ? nForSearch[nPos] : nPos, &t[nPos - nStart]);
				break;

			case 'x':	// Cross-post
				::SetUserDir(szPath, bbs->GetUserId());
				wsprintf(szTemp, "[%s]�H�c", bbs->GetUserId());
				DoCrossPost(bbs, &t[nPos - nStart], szPath, szTemp);
				bUpdate = true;
				break;

			case 'y':
DoReply:
				if( !MailMenu->DoReply(bbs, &t[nPos - nStart]) )
				{
					t[nPos - nStart].mode |= DI_REPLIED;
					Modify(nPos, &t[nPos - nStart]);
				}
				bUpdate = true;
				break;

			case 'z':
				if( HAVE_PERM1(PERM_MAILLIMIT) || HAVE_PERM1(PERM_SYSOP) )
				{
				CDir** dir;

					dir = bbs->GetFreeDir();
					if( !dir )
						break;

					::SetUserFile(szTemp, bbs->GetUserId(), "Gem\\"DIRFILE);
					::SetUserFile(szPath, bbs->GetUserId(), "Gem");

					::CreateDirectory(szPath, NULL);
					*dir = new CDir(szTemp);
					wsprintf(szTemp, "[%s]���H�c", bbs->GetUserId());
					(*dir)->ReadAnnounce(bbs, szTemp, szPath,
						HAVE_PERM1(PERM_SYSOP) ? RA_SYSOP : RA_BM);
					bbs->ReleaseDir(dir);

					bUpdate = true;
				}
				break;

			case 'D':
			int nBegin, nEnd;

				bUpdate = true;

				bbs->getdata(1, 0, "[�R���d��]�_�I�G", szTemp, 6);
				nBegin = atoi(szTemp) - 1;
				if( nBegin < 0 || nBegin > nTotal )
				{
					bbs->pressanykey("�_�I���~�C");
					break;
				}

				if( !bbs->getdata(1, 26, "���I�G", szTemp, 6) )
				{
					bbs->pressanykey("���I���~�C");
					break;
				}
				nEnd = atoi(szTemp) - 1;

				if( nEnd > nTotal )
					nEnd = nTotal;

				if( !bbs->SelectData(1, 40, "�T�w�H", c_yesno, 2, 1) )
				{
					for( i = nBegin; i <= nEnd; i++ )
						Delete(bInSearch ? nForSearch[i] : i);
					DoDelete();
				}
				break;

			case 'E':
				::SetUserFile(szTemp, bbs->GetUserId(), t[nPos - nStart].filename);
				bbs->Edit(szTemp, 0, t[nPos - nStart].title);
				bUpdate = true;
				break;

			case 'S':
				if( bInSearch )
					break;

				nForSearch = new int[nTotal];
				memset(nForSearch, 0, sizeof(int) * nTotal);
				nSearchTotal =
					DoSearch(t[nPos - nStart].title + (strncmp(t[nPos - nStart].title, "R: ", 3) ? 0 : 3),
							 0, true, nForSearch);
				if( !nSearchTotal )
					delete [] nForSearch;
				else
					bInSearch = true;
				bUpdate = true;
				break;

			case 'T':
				if( HAVE_PERM1(PERM_SYSOP) )
				{
					memcpy(&a, &t[nPos - nStart], sizeof(CDirIndex));
					bbs->getdata(22, 0, "���D�G", a.title, 60, DOECHO, a.title);
					bbs->getdata(22, 0, "�@�̡G", a.owner, IDLEN + 1, DOECHO, a.owner);
					bbs->getdata(22, 0, "����G", a.date, 6, DOECHO, a.date);
					if( !bbs->SelectData(22, 0, "�T�w�H", c_yesno, 2, 1) )
					{
						Modify(nPos, &a);
					}
					bUpdate = true;
				}
				break;

			case 'Q':
				// Query user
				TalkMenu->DoQuery(bbs, t[nPos - nStart].owner);
				bUpdate = true;
				break;

			case Ctrl('B'):
				break;

			default:
				if( bbs->GlobalKeys(c) )
				{
					bUpdate = true;
					break;
				} else if( c >= '0' && c <= '9' )
				{
					if( (i = bbs->GetNumber(c)) )
						nPos = i - 1;
					if( nPos >= nTotal )
						nPos = nTotal - 1;
					nOldPos = nPos;
					bUpdate = true;
				}
		}

		if( (nPos / 20) != (nOldPos / 20) )
		{
			bReload = true;
			nStart = nPos / 20 * 20;
		}
	}
}

void CDir::MLightBar ( Cbbs* bbs, int n, CDirIndex* di, bool bOn )
{
char szTemp[DATASIZE];
int nPos = n % 20;
char m;

	if( di->mode & DI_TAGGED )
		m = 't';
	else if( di->mode & DI_MARKED )
		m = 'm';
	else if( di->mode & DI_REPLIED )
		m = 'r';
	else if( di->mode & DI_UNREAD )
		m = '+';
	else
		m = ' ';

	wsprintf(szTemp, " %4d %c %-5s %4d  %c\033[%c;37;4%cm%-12s\033[m%c %s%s ",
			 n + 1, m, di->date,
			 0,
			 bOn ? '[' : ' ',
			 bOn ? '1' : '0',
			 bOn ? '4' : '0',
			 di->owner,
			 bOn ? ']' : ' ',
			 strncmp(di->title, "R: ", 3) ? "�� " : "",
			 di->title);
	szTemp[80] = 0;

	bbs->move(3 + nPos, 0);
	bbs->outs(szTemp);
	bbs->clrtoeol();
}

void CMailMenu::DoMailTo ( Cbbs* bbs, char* szUser )
{
	if( passwds->Search(szUser) < 0 )
	{
		bbs->pressanykey(ERR_UID);
		return ;
	}

char szTitle[TTLEN];
char szTemp[DATASIZE];
int nOldMode = bbs->SetMode(SMAIL);

	wsprintf(szTemp, "�H�H�� %s", szUser);
	bbs->stand_title(szTemp);
	if( !bbs->getdata(3, 0, "�H��D�D�G", szTitle, 60) )
		strcpy(szTitle, "[�S�D�D]");

	if( bbs->Edit(0, 0, szTitle) )
	{
		DoMailBuf(bbs, szTitle);
		switch( DoSend(bbs, szUser, szTitle) )
		{
			case -1:
				bbs->pressanykey(ERR_UID);
				break;

			case -2:
				break;

			case -3:
				wsprintf(szTemp, "�ϥΪ� [%s] �L�k���H�C", szUser);
				bbs->pressanykey(szTemp);
				break;

			default:
				break;
			}
	} else
		bbs->pressanykey(MSG_CANCEL);

	bbs->SetMode(nOldMode);

	::SetUserFile(szTemp, bbs->GetUserId(), EDITBUF);
	::DeleteFile(szTemp);
	::SetUserFile(szTemp, bbs->GetUserId(), MAILBUF);
	::DeleteFile(szTemp);
}

int CMailMenu::DoSend ( Cbbs* bbs, char* szUser, char* szTitle )
{
char szTemp[DATASIZE];

	::SetUserFile(szTemp, szUser, "MailReject");
CbbsNameList list(szTemp, 50);

	if( list.InList(bbs->GetUserId()) >= 0 && !HAVE_PERM1(PERM_SYSOP) )
	{
		return -3;
	}

	::SetUserFile(szTemp, bbs->GetUserId(), MAILBUF);

	return ::MailTo(bbs, szUser, bbs->GetUserId(), szTitle, szTemp, true) - 1;
}

int CMailMenu::DoReply ( Cbbs* bbs, CDirIndex* r )
{
char szTemp[DATASIZE];
char szSource[DATASIZE];
char szTitle[TTLEN];
CUserInfo u;

	bbs->clear();
	bbs->move(18, 0);
	wsprintf(szTemp, "�^�H�� [%s]�G", r->owner);
	bbs->outs(szTemp);

	if( !strncmp(szTitle, "R: ", 3) )
		strcpy(szTitle, r->title);
	else
	{
		wsprintf(szTitle, "R: %s", r->title);
		szTitle[70] = 0;
	}

	if( bbs->SelectData(20, 0, "�O�_�ĥέ���D�H", c_yesno, 2) )
		if( !bbs->getdata(21, 0, "���D�G", szTitle, 70, DOECHO, szTitle) )
			strcpy(szTitle, "[�L�D�D]");

char* szReplyMode[] = {"Y�O", "N�_", "A����", "Repost"};
int nReplyMode = bbs->SelectData(22, 0, "�^�мҦ��G", szReplyMode, 4);

	::SetUserFile(szTemp, bbs->GetUserId(), EDITBUF);
	::SetUserFile(szSource, bbs->GetUserId(), r->filename);
	passwds->Search(r->owner, &u);

	bbs->ReplyFile(szSource, szTemp, nReplyMode, r->owner, u.username);

int nOldMode = bbs->SetMode(SMAIL);

	if( bbs->Edit(szTemp, 0, szTitle) )
	{
		DoMailBuf(bbs, szTitle);
		bbs->SetMode(nOldMode);
		return DoSend(bbs, r->owner, szTitle);
	} else
		bbs->pressanykey(MSG_CANCEL);

	bbs->SetMode(nOldMode);
	return -1;
}

void CMailMenu::DoMailBuf ( Cbbs* bbs, char* szTitle )
{
FILE** fpin;
FILE** fpout;
time_t now;
struct tm* tm;
char szTemp[DATASIZE];
char szTarget[DATASIZE];

	time(&now);
	tm = localtime(&now);

	::SetUserFile(szTarget, bbs->GetUserId(), MAILBUF);
	::SetUserFile(szTemp, bbs->GetUserId(), EDITBUF);

	fpin = bbs->GetFreeFP();
	if( !fpin )
		return ;
	*fpin = fopen(szTemp, "r");

	fpout = bbs->GetFreeFP();
	if( !fpout )
		return ;
	*fpout = fopen(szTarget, "w");

	if( *fpin && *fpout )
	{
		::AppendAutorInfo(*fpout, bbs->GetUserId(), bbs->GetUser()->username, szTitle, &now, NULL);
		::AppendToFile(*fpout, *fpin);
	}

	// Signature file
	bbs->ReleaseFP(fpin);

	fpin = bbs->GetFreeFP();
	if( fpin )
	{
	char* szSig = bbs->GetSignature();

		if( szSig )
		{
			*fpin = fopen(szSig, "r");
			if( *fpin && *fpout )
			{
				fprintf(*fpout, "\n--\n\n");
				::AppendToFile(*fpout, *fpin);
			}
		}
		bbs->ReleaseFP(fpin);
	}

	if( *fpout )
		bbs->AppendBBSInfo(*fpout);

	bbs->ReleaseFP(fpout);
}

int CMailMenu::DoListSend ( Cbbs* bbs, CbbsNameList* list )
{
char szTitle[TTLEN];
int nTotal = list->GetNum();

	list->Reload();
	bbs->stand_title("�H�H���@��H");

	if( !bbs->getdata(3, 0, "�H��D�D�G", szTitle, 60) )
		strcpy(szTitle, "[�S�D�D]");

	if( bbs->Edit(0, 0, szTitle) )
	{
	char szUser[IDLEN + 1];
	int i, n;

		DoMailBuf(bbs, szTitle);

		bbs->stand_title("�s�ձH�H");
		bbs->move(23, 0);
		bbs->outs("���b�H�H��");

		for( i = 0, n = 0; i < nTotal; i++ )
		{
			bbs->move(23, 11);
			list->Get(i, szUser);
			bbs->prints(" %-12s \033[m %d/\033[1;37m%d\033[m...",
						szUser, i + 1, nTotal);

			if( DoSend(bbs, szUser, szTitle) >= 0 )
				n++;
		}

		return n;
	} else return 0;
}

int CMailMenu::DoInternetSend ( Cbbs* bbs, char* szTarget, char* szTitle )
{
	return 1;
}

int CMailMenu::SendMail ( Cbbs* bbs, char* szTarget, char* szTitle )
{
	if( ::IsValidId(szTarget) )
		return DoSend(bbs, szTarget, szTitle);
	else if( ::IsValidEMail(szTarget) )
		return DoInternetSend(bbs, szTarget, szTitle);
	else
		return -1;
}

int CMailMenu::New ( Cbbs* bbs )
{
CDir** dir;
char szTemp[DATASIZE];
bool bHaveNew = false;
bool bBreak = false;
CDirIndex t;

	dir = bbs->GetFreeDir();

	if( !dir )
		return FULLUPDATE;

	::SetUserFile(szTemp, bbs->GetUser()->userid, DIRFILE);
	*dir = new CDir(szTemp);

	for( int i = 0; (*dir)->Get(i, &t); i++ )
		if( t.mode & DI_UNREAD )
		{
			bHaveNew = true;
			bbs->clear();
			bbs->move(10, 0);
			bbs->prints("�z�nŪ���Ӧ�[%s]���H��(%s)�ܡH",
						t.owner, t.title);
			switch(bbs->SelectData(11, 0, "�бz�T�w�G", c_yesno, 3))
			{
				case 0:
					::SetUserFile(szTemp, bbs->GetUserId(), t.filename);
					bbs->more(szTemp, MOREREAD);
					break;

				case 2:
					bBreak = true;
					break;
			}

			if( bBreak )
				break;
		}

	bbs->ReleaseDir(dir);

	bbs->pressanykey( bHaveNew ? "�H�w�\���C" : "�z�S���s�H��C" );

	return FULLUPDATE;
}

int CMailMenu::Read ( Cbbs* bbs )
{
CDir** dir;
char szTemp[DATASIZE];

	::SetUserFile(szTemp, bbs->GetUserId(), DIRFILE);

	dir = bbs->GetFreeDir();
	if( !dir )
		return FULLUPDATE;

	*dir = new CDir(szTemp);
	(*dir)->ReadMail(bbs);

	bbs->ReleaseDir(dir);

	return FULLUPDATE;
}

int CMailMenu::Send ( Cbbs* bbs )
{
char szUser[IDLEN + 1];

	bbs->stand_title("�g�H");

	if( passwds->Select(bbs, szUser) )
	{
		DoMailTo(bbs, szUser);
	} else
		bbs->pressanykey(ERR_UID);

	return FULLUPDATE;
}

int CMailMenu::MailList ( Cbbs* bbs )
{
char szTemp[DATASIZE];
static char* szLists[] = { "0���}", "1", "2", "3", "4", "5" };
int n;

	bbs->stand_title("�s�ձH�H");

	if( n = bbs->SelectData(3, 0, "�п�ܦW��G", szLists, 6) )
	{
		bbs->pressanykey("���}�W��s�边��Y�i�}�l�g�H�C");

		::SetUserFile(szTemp, bbs->GetUserId(), "list.");
		strcpy(strchr(szTemp, '\0'), szLists[n]);

	CbbsNameList list(szTemp, MAX_FRIEND * 1.5);

		if( list.Edit(bbs, 0) )
			list.Save();

		if( bbs->SelectData(23, 0, "�}�l�H�H�H", c_yesno, 2) )
			return FULLUPDATE;

		if( n = DoListSend(bbs, &list) )
		{
			wsprintf(szTemp, "�s�ձH�H�����A�@ %d/%d ���\�H�X�C", n, list.GetNum);
			bbs->pressanykey(szTemp);
		} else
			bbs->pressanykey(MSG_CANCEL);
	}

	return FULLUPDATE;
}

int CMailMenu::Internet ( Cbbs* bbs )
{
	return FULLUPDATE;
}

int CMailMenu::Forward ( Cbbs* bbs )
{
	return FULLUPDATE;
}

int CMailMenu::Reject ( Cbbs* bbs )
{
char szTemp[DATASIZE];

	::SetUserFile(szTemp, bbs->GetUserId(), "MailReject");
CbbsNameList list(szTemp, MAX_REJECT * 2);

	if( list.Edit(bbs, 0) )
		list.Save();

	return FULLUPDATE;
}

int CMailMenu::MailSYSOP ( Cbbs* bbs )
{
FILE** fp;
char szOPs[6][IDLEN + 1];
char szDuty[6][20];
int nTotal;
int i;
char szTemp[DATASIZE];

	fp = bbs->GetFreeFP();
	if( !fp )
		return FULLUPDATE;

	*fp = fopen("Settings\\SYSOP.list", "r");
	if( *fp )
	{
	char* t;

		nTotal = 0;
		while( fgets(szTemp, DATASIZE, *fp) )
		{
			::StripNewLine(szTemp);
			t = strchr(szTemp, ':');
			if( t )
			{
				*t = 0;
				strcpy(szOPs[nTotal], szTemp);
				strcpy(szDuty[nTotal], t + 1);
				nTotal++;
			}
		}
	}
	bbs->ReleaseFP(fp);

	bbs->move(13, 39);
	bbs->outs("�ССССССССССССССССССС�");
	bbs->move(14, 39);
	bbs->outs("�s��  ID            ¾�d");

	for( i = 0; i < nTotal; i++ )
	{
		bbs->move(15 + i, 39);
		bbs->prints("\033[1;3%dm%2d  %-12s  %s\033[m",
					i + 1, i + 1, szOPs[i], szDuty[i]);
	}

	bbs->move(15 + i, 39);
	bbs->outs("\033[1;37m 0  ���}\033[m");
	bbs->getdata(16 + i, 39, "�п�ܡG", szTemp, 3, DOECHO, "0");

	i = szTemp[0] - '0';

	if( i > 0 && i <= nTotal )
	{
		DoMailTo(bbs, szOPs[i - 1]);
	}

	return FULLUPDATE;
}

int CMailMenu::MailAll ( Cbbs* bbs )
{
CbbsNameList list(0, MAXUSERS);
CUserInfo t;
int i;

	bbs->move(23, 0);
	bbs->outs("�H�H�W��إߤ�...�еy��...");
	bbs->clrtoeol();

	::Sleep(500);

	for( i = 0; i < MAXUSERS; i++ )
	{
		passwds->Get(i, &t);
		if( t.userid[0] )
			list.Add(t.userid);
	}

	this->DoListSend(bbs, &list);

	return FULLUPDATE;
}
