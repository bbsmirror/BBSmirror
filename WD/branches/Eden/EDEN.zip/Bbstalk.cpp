#include "stdafx.h"

void CTalkMenu::InitElement (  )
{
CbbsMenuItem temp[5] = {
	0,				"UUserList   [�ϥΪ̦W��]", "�ݬݲ{�b�b���W�����ͭ�^^",
	0,				"QQuery      [�d�ߨϥΪ�]", "�d�ߨ�L���ͪ����^^",
	PERM_BASIC,		"PPager      [�����I�s��]", "�����z���I�s�����A",
	PERM_BASIC,		"MMessage      [���u����]", "�d�ݱz�����y����:D",
	0, 0, 0};

	this->menu = new CbbsMenuItem[5];

	memcpy((void*)menu, (void*)temp, sizeof(CbbsMenuItem) * 5);
}

int CTalkMenu::ExecMenu ( int nIndex, Cbbs* bbs )
{
	switch( nIndex )
	{
		case 0:
			return UserList(bbs);

		case 1:
			return Query(bbs);

		case 2:
			return Pager(bbs);

		case 3:
			return Message(bbs);
	}

	return 0;
}

int CTalkMenu::LightBar ( Cbbs* bbs, int nPos, CUserPick* up, bool bOn )
{
int pos = nPos % 20;
char Color, Highlight;
static char *Pagers = " f*-";

	if( bOn )
	{
		Color = '7'; Highlight = '1';
	} else {
		if( PERM_HIDE( up->oi->userlevel ) )
		{
			Color = '5'; Highlight = '1';
		} else if( bbs == up->oi->bbs )
		{
			Color = '6'; Highlight = '1';
		} else
			switch( up->nFriend )
			{
				case -1:	// Rejected
					Color = '1'; Highlight = '0';
					break;

				case 0:		// Normal
					Color = '7'; Highlight = '0';
					break;

				case 1:
					Color = '2'; Highlight = '1';
					break;

				case 2:
					Color = '3'; Highlight = '1';
					break;

				case 3:
					Color = '7'; Highlight = '1';
					break;
			}
	}

	up->oi->username[16] = 0;
	bbs->move(nPos + 3, 0);
	bbs->prints("%4d%c%c %c\033[%c;3%c;4%cm%-12s\033[m%c %-16s %-16s %-12s \033[1;3%cm%-4s\033[m ",
			 nPos + 1,
			 up->oi->invisible ? ')' : ' ',
			 Pagers[up->oi->pager],	// Pager
			 bOn ? '[' : ' ',
			 Highlight, Color, bOn ? '4' : '0',
			 up->oi->userid,
			 bOn ? ']' : ' ',
			 up->oi->username,
			 ::GetFromHost(up->oi->from),
			 ModeString(up->oi),
			 up->oi->feelingcolor + '1',
			 up->oi->feeling);

	if( up->nIdle )
		bbs->prints("%2d'%02d", up->nIdle / 60, up->nIdle % 60);
	return 0;
}

char* CTalkMenu::ModeString ( COnlineInfo* oi )
{
static char *szNum[] = {"�@", "�G", "�T", "�|", "��", "��", "�C", "�K", "�E"};
static char szOut[DATASIZE];
int n;

	switch( oi->mode )
	{
		case HIT:
			n = oi->msgcount - 1;
			if( n >= 9 )
				strcpy(szOut, "����F@_@");
			else
				wsprintf(szOut, "��%s�����y", szNum[n]);
			break;

		default:
			if( oi->in_edit )
				wsprintf(szOut, "E:%s", ModeStr[oi->mode]);
			else
				strcpy(szOut, ModeStr[oi->mode]);
			szOut[17] = 0;
	}

	return szOut;
}

static int UserSort0 ( CTalkMenu::CUserPick* s1, CTalkMenu::CUserPick* s2 )
{
int n;

	n = (s1->nFriend == s2->nFriend);

	if( n )
		return strcmp(s1->oi->userid, s2->oi->userid);
	else 
		return s1->nFriend < s2->nFriend;
}

static int UserSort1 ( CTalkMenu::CUserPick* s1, CTalkMenu::CUserPick* s2 )
{
	return strcmp(s1->oi->userid, s2->oi->userid);
}

static int UserSort2 ( CTalkMenu::CUserPick* s1, CTalkMenu::CUserPick* s2 )
{
int n;

	n = strcmp(s1->oi->from, s2->oi->from);

	if( !n )
		return strcmp(s1->oi->userid, s2->oi->userid);
	else 
		return n;
}

static int UserSort3 ( CTalkMenu::CUserPick* s1, CTalkMenu::CUserPick* s2 )
{
int n;

	n = (s1->nIdle == s2->nIdle);

	if( n )
		return strcmp(s1->oi->userid, s2->oi->userid);
	else 
		return s1->nIdle > s2->nIdle;
}

static QSPROC SortCmps[] =
{
	(QSPROC)UserSort0,
	(QSPROC)UserSort1,
	(QSPROC)UserSort2,
	(QSPROC)UserSort3
};

int CTalkMenu::UserList ( Cbbs* bbs )
{
char szTemp[DATASIZE];
int nPos = 0, nOldPos = 0, nStart = 0;
int nTotal;
int c;
int i;
CUserPick *up;
CUserInfo *u;
bool bUpdate = true;
bool bBreak = false;
bool bFriend = false;

static char *szSort[] =
{
	"0����",
	"1�١I�B��",
	"2�ϥΪ�ID",
	"3�Ӧۦ��",
	"4�o�b�ɶ�"
};

short nPickMode = 0;

	up = new CUserPick[MAXACTIVE];

	while(1)
	{
		bbs->SetMode(LUSERS);

		if( bUpdate )
		{
			nTotal = onlines->Get(up, bbs, bFriend);
			if( !nTotal )
			{
				if( bFriend )
				{
					bbs->pressanykey("�ثe�|�L�n�ͤW���C");
					nTotal = onlines->Get(up, bbs);
					bFriend = false;
				} else return FULLUPDATE;
			}

			if( nPos >= nTotal )
			{
				nStart = nPos / 20 * 20;
				nOldPos = nPos = nTotal - 1;
			}

			qsort(up, nTotal, sizeof(CUserPick), ::SortCmps[nPickMode]);

			bbs->clear();
			bbs->ShowTitle( bFriend ? "�n�ͦC��" : "�ϥΪ̦W��");
			bbs->move(1, 0);

			bbs->prints("  �ƧǤ覡�G[\033[1;37m%s\033[m]  �W���H�ơG%-4d",
						szSort[nPickMode + 1] + 1,
						nTotal);

			for( i = 0, c = 0; i < nTotal; i++ )
				if( up->nFriend > 0 && (up->nFriend % 2) )
					c++;

			bbs->prints(" \033[1;32m�ڪ��B�͡G%-3d", c);

			for( i = 0, c = 0; i < nTotal; i++ )
				if( up->nFriend >= 2 )
					c++;

			bbs->prints(" \033[33m�P�ڬ��͡G%-3d", c);

			for( i = 0, c = 0; i < nTotal; i++ )
				if( up->nFriend == -1 )
					c++;

			bbs->prints(" \033[31m�a�H�G%-2d\r\n", c);

			bbs->outs("\033[1;37;46m�s��   �ϥΪ̥N��     �ʺ�             �G�m             �ʺA         �߱�  �o�b\033[m");

			for( i = 0; i < 20 && ((nStart + i) < nTotal); i++ )
			{
				LightBar(bbs, nStart + i, &up[nStart + i], false);
			}

			bbs->move(23, 0);
			bbs->outs("\033[1;33;46m(TAB/f)\033[37m�Ƨ�/�n�� \033[33m(t)\033[37m���"
					  " \033[33m(a/d/o)\033[37m���\033[37m \033[33m(q)\033[37m�d��"
					  " \033[33m(w)\033[37m���� \033[33m(m)\033[37m�H�H \033[33m(Ctrl+Z)\033[37m����  \033[m");
		}

		if( nOldPos != nPos )
			LightBar(bbs, nOldPos, &up[nOldPos], false);
		LightBar(bbs, nPos, &up[nPos], true);

		nOldPos = nPos;

		c = bbs->igetkey();

		bUpdate = true;

		switch(c)
		{
			case KEY_UP:
				if( nPos )
					nPos--;
				else
					nPos = nTotal - 1;
				bUpdate = false;
				break;

			case KEY_DOWN:
				if( nPos >= (nTotal - 1) )
					nPos = 0;
				else
					nPos++;
				bUpdate = false;
				break;

			case KEY_LEFT:
				bBreak = true;
				break;

			case 't':			// Talk
			case KEY_RIGHT:
				if( !HAS_PERM1(PERM_SYSOP) )
					break;

				if( up[nPos].oi->bbs == bbs )
					break;

				bbs->Talk(up[nPos].oi);
				break;

			case KEY_PGUP:
				if( nPos == 0 )
				{
					nPos = nTotal - 1;
					break;
				}

				nPos -= 20;
				if( nPos < 0 )
					nPos = 0;
				break;

			case KEY_PGDN:
			case ' ':
				if( nPos == nTotal - 1)
				{
					nPos = 0;
					break;
				}

				nPos += 20;
				if( nPos > (nTotal - 1) )
					nPos = nTotal - 1;
				break;

			case '$':
				nPos = nTotal - 1;
				break;

			case KEY_TAB:
				if( i = bbs->SelectData(1, 0, "�ƧǤ覡�G", szSort, 5) )
					nPickMode = i - 1;
				bUpdate = true;
				break;

			case 'a':			// Add Friend
			case 'd':			// Delete Friend
				if( !HAS_PERM1(PERM_LOGINOK) )
					break;

				if( c == 'a' )
				{
					if( bbs->Friends->InList(up[nPos].oi->userid) >= 0 )
					{
						bbs->pressanykey("���ϥΪ̤w�b�z���n�ͦW�椤�C");
						break;
					}
					bbs->getdata(1, 0, "�n�ʹy�z�G", szTemp, 21);
					bbs->Friends->Add(up[nPos].oi->userid, szTemp);
				} else if( c == 'd' )
				{
					if( bbs->Friends->InList(up[nPos].oi->userid) < 0)
						break;
					bbs->Friends->Delete(up[nPos].oi->userid);
				}

				bbs->Friends->Save();
				bbs->Friends->Reload();
				bbs->ReloadFriends();
				break;

			case 'b':
				break;

			case 'f':
				bFriend = !bFriend;
				break;

			case 'm':
				if( HAS_PERM1(PERM_BASIC) )
					MailMenu->DoMailTo(bbs, up[nPos].oi->userid);
				break;

			case 'o':
				if( !HAS_PERM1(PERM_LOGINOK) )
					break;

				ListSubMenu->Friends(bbs);
				break;

			case 'p':			// Switch Pager
				if( !HAS_PERM1(PERM_PAGE) )
					break;

				Pager(bbs);
				break;

			case 'q':			// Query
				DoQuery(bbs, up[nPos].oi->userid);
				break;

			case 'r':			// Read Mail
				if( !HAS_PERM1(PERM_BASIC) )
					break;

				MailMenu->Read(bbs);
				break;

			case 'w':			// Send message
				if( !HAS_PERM1(PERM_LOGINOK) )
					break;

				if( up[nPos].oi->bbs == bbs )
					break;

				bbs->SetMode(DBACK);
				if( !bbs->getdata(23, 0, "���y��L�h�G", szTemp, 61) )
				{
					bbs->pressanykey("��F! ��A�@��...");
					break;
				}

				if( bbs->SelectData(0, 0, "����y�H", c_yesno, 2, 0, SD_HORZ|SD_HOTKEY|SD_CLEAR) )
					break;

				if( !up[nPos].oi->active )
				{
					bbs->pressanykey("�V�|! ���w���]�F(���b���W)! ~>_<~");
					break;
				}

				if( !up[nPos].oi->bbs )
					break;

				bbs->SetMode(LUSERS);
				if( !up[nPos].oi->bbs->WriteMessage(bbs->online, szTemp) )
					bbs->pressanykey("�c, ���Q�{���աI:D");
				else
					bbs->pressanykey("���y�{�L�h��:D");
				break;

			case 'x':
			case 'M':
				u = bbs->GetUser();
				bbs->SetFeeling(u, 1);
				passwds->ModifyS(u->userid, u);
				strcpy(bbs->online->feeling, u->feeling);
				bbs->online->feelingcolor = u->feelingcolor;
				break;

			case 'A':			// Add Rejected
			case 'D':			// Delete Rejected
				if( c == 'A' )
				{
					if( bbs->Rejects->InList(up[nPos].oi->userid) >= 0 )
					{
						bbs->pressanykey("���ϥΪ̤w�z���b�a�H�W�椤�C");
						break;
					}
					bbs->getdata(1, 0, "�c��c���G", szTemp, 21);
					bbs->Rejects->Add(up[nPos].oi->userid, szTemp);
				} else if( c == 'D' )
				{
					if( bbs->Rejects->InList(up[nPos].oi->userid) < 0 )
						break;
					bbs->Rejects->Delete(up[nPos].oi->userid);
				}

				bbs->Rejects->Save();
				bbs->Rejects->Reload();
				bbs->ReloadRejects();
				break;

			case 'C':
				if( !HAVE_PERM1(PERM_SYSOP) )
					break;

				if( bbs->getdata(1, 0, "�N���G", szTemp, 13, DOECHO, bbs->online->userid) )
					strcpy(bbs->online->userid, szTemp);
				else
					strcpy(bbs->online->userid, bbs->GetUser()->userid);
				break;

			case 'F':
				if( !HAVE_PERM1(PERM_SYSOP) )
					break;

				if( bbs->getdata(1, 0, "�G�m�G", szTemp, 17, DOECHO, bbs->online->from) )
					strcpy(bbs->online->from, szTemp);
				else
					strcpy(bbs->online->from, bbs->GetUser()->lasthost);
				break;

			case 'H':
				if( HAVE_PERM1(PERM_SYSOP) )
					bbs->online->userlevel ^= PERM_DENYPOST;
				break;

			case 'N':
				if( !HAVE_PERM1(PERM_BASIC) )
					break;

				if( bbs->getdata(1, 0, "�ʺ١G", szTemp, 17, DOECHO, bbs->online->username) )
					strcpy(bbs->online->username, szTemp);
				else
					strcpy(bbs->online->username, bbs->GetUser()->username);
				break;

			case Ctrl('K'):
			case 'K':
				if( HAVE_PERM1(PERM_SYSOP) )
				{
					wsprintf(szTemp, "�T�w�n��[%s]�H", up[nPos].oi->userid);
					if( !bbs->SelectData(1, 0, szTemp, c_yesno, 2, 1) )
					{
						up[nPos].oi->bbs->ExitBBS(EXIT_FORCE);
						bbs->pressanykey("�A���a�_���I:D");
					}
				}
				break;

			case Ctrl('U'):		// To prevent user-list re-entry
				break;

			default:
				if( bbs->GlobalKeys(c) )
				{
					bUpdate = true;
				} else if( c >= '0' && c <= '9' )
				{
					if( (i = bbs->GetNumber(c)) )
						nPos = i - 1;
					if( nPos >= nTotal )
						nPos = nTotal - 1;
					nOldPos = nPos;
					bUpdate = true;
				}
		}

		if( (nOldPos / 20) != (nPos / 20) )		// Page Changed
		{
			nStart = nPos / 20;
			nStart *= 20;
		}

		if( bBreak )
			break;
	}

	delete [] up;

	return FULLUPDATE;
}

int CTalkMenu::Query ( Cbbs* bbs )
{
char szTemp[20];

	bbs->stand_title("�d�ߨϥΪ�");

	passwds->Select(bbs, szTemp);
	DoQuery(bbs, szTemp);

	return FULLUPDATE;
}

int CTalkMenu::Pager ( Cbbs* bbs )
{
static char *pagermodes[] = {"1�}", "2��", "3��", "4��"};
CUserInfo* u = bbs->GetUser();

	bbs->move(23, 0); bbs->clrtoeol();
	u->pagermode =
		bbs->SelectData(23, 0, "�п�ܩI�s�����A�G", pagermodes, 4, u->pagermode);

	passwds->ModifyS(u->userid, u);
	bbs->online->pager = u->pagermode;

	return FULLUPDATE;
}

void Cbbs::Talk ( COnlineInfo* oi )
{
	clear();
	// Show his/her Query
	if( SelectData(2, 0, "�A�T�w�n��L/�o��ѶܡH", c_yesno, 2, 1) )
		return ;

	if( oi->in_edit
	||	oi->in_gd
	||	oi->mode == TALK
	||	oi->mode == DBACK
	||	oi->destuip
	)
	{
		pressanykey("�H�a�b���աI");
		return ;
	}

	online->destuip = oi;
	oi->destuip = online;

	oi->bbs->PutEvent(TALKREQUEST);

	DoTalk(true);

	online->destuip = 0;
}

void Cbbs::DoTalkRequest (  )
{
char szTemp[DATASIZE];
char *szSel[] = {
	"Y���ڭ� talk �a",	
	"N�ڲ{�b���Q talk",
	"A�ڲ{�b�ܦ��A�е��@�|��A call ��",
	"B�藍�_�A�ڦ��Ʊ������A talk",
	"C�Ф��n�n�ڦn�ܡH",
	"D���ƶܡH�Х��ӫH"
};
int nOldMode;
int n;

	clear();
	beep();

	nOldMode = SetMode(REPLY);

	move(0, 0);
	prints("�A�Q�� %s(%s) ��ѶܡH",
		online->destuip->userid, online->destuip->username);

	// Show User Info here
	move(10, 0);
	::SetUserFile(szTemp, cuser.userid, "plans");
	showfile(szTemp);

	n = SelectData(2, 0, "�п�ܡG", szSel, 6, 0, SD_VERT|SD_HOTKEY);

	if( online->destuip->mode != PAGE )
	{
		pressanykey("���w����I�s�C");
	} else if( n )
	{
		online->destuip->bbs->PutEvent(n + TALKREPLY);
	} else {
		online->destuip->bbs->PutEvent(n + TALKREPLY);
		DoTalk(false);
	}

	online->destuip = 0;
	SetMode(nOldMode);

	PutEvent(Ctrl('L'));
}

void Cbbs::TalkString ( bool bMySelf, int c, int* y, int* x )
{
//char **szBuf = ;

	switch(c)
	{
		case Ctrl('A'):
			*x = 0;
			break;

		case Ctrl('E'):
			*y = strlen(bMySelf ? CurrData[*y] : DestData[*y]) - 1;
			break;

		case Ctrl('\177'):
		case Ctrl('H'):
			(*x)--;
			::DeleteChar(bMySelf ? CurrData[*y] : DestData[*y], *x);
			break;

		case '\n':
		case '\r':
			(*y)++;
			(*y) %= 11;
			bMySelf ? CurrData[*y][0] : DestData[*y][0] = 0;
			*x = 0;
 			break;

		case KEY_UP:
			if( (*y) )
				(*y)--;
			else
				*y = 10;
			break;

		case KEY_DOWN:
			if( (*x) )
				(*x)--;
			break;

		default:
			if( ::IsValidKey(c) )
			{
				::InsertChar(bMySelf ? CurrData[*y] : DestData[*y], *x, c);
				(*x)++;
			}
	}
}

void Cbbs::TalkShow ( bool bMySelf, int c, int* y, int* x, FILE* fp )
{
int n;

	TalkString(bMySelf, c, y, x);

	switch(c)
	{
		case Ctrl('\177'):
		case Ctrl('H'):
			n = *y;
			n += (bMySelf) ? 0 : 12;
			move(n, *x);
//			outs(bMySelf ? &CurrData[*y][*x - 1] : &DestData[*y][*x - 1]); clrtoeol();
			break;

		case KEY_UP:
		case KEY_DOWN:
		case Ctrl('A'):
		case Ctrl('E'):
		case '\n':
		case '\r':
			n = *y;
			n += (bMySelf) ? 0 : 12;
			move(n, *x);
 			break;

		default:
			if( ::IsValidKey(c) )
			{
				o_char(c);
			}
	}
}

void Cbbs::DoTalk ( bool bStarter )
{
int c;
int nOldMode;
char szTemp[DATASIZE];

	if( bStarter )
	{
		nOldMode = SetMode(PAGE);

		while(1)
		{
			move(23, 0);
			prints("�I�s %s ��...", online->destuip->userid);
			clrtoeol();

			c = igetkey();

			if( c == Ctrl('D') || c == Ctrl('C') )
			{
				SetMode(nOldMode);
				return ;
			} else if( c >= TALKREPLY && c <= TALKREPLY + 6 )
			{
			int n;

				n = c - TALKREPLY;

				if( n )
				{
				char *szMsg[] = {
					"�ڲ{�b���Q talk",
					"�ڲ{�b�ܦ��A�е��@�|��A call ��",
					"�藍�_�A�ڦ��Ʊ������A talk",
					"�Ф��n�n�ڦn�ܡH",
					"���ƶܡH�Х��ӫH"
				};

					SetMode(nOldMode);
					wsprintf(szTemp, "�^�� from %s: %s....:)",
							 online->destuip->userid,
							 szMsg[n - 1]);
					pressanykey(szTemp);
					return ;
				} else break;
			} else beep();
		}

//		wsprintf(szTemp, "Home\\%s\\talk-%d%d", online, online->destuip);
//		*fpCurr = fopen(szTemp, "w");
	}

	SetMode(TALK);

bool bUpdate = true;
bool bBreak = false;
bool bTalkWait = false;
bool bMyTurn = false;
bool bFirst = true;

COnlineInfo* curr = online;
COnlineInfo* dest = curr->destuip;

	xCurr = yCurr = xDest = yDest = 0;

	for( c = 0; c < 11; c++ )
		CurrData[c][0] = DestData[c][0] = 0;

	while(1)
	{
		if( bUpdate )
		{
			clear();
			for( c = 0; c < 11; c++ )
			{
				if( strlen(CurrData[c]) )
					outs(CurrData[c]);
				outs("\r\n");
			}

			prints("\033[1;37;46m  �ͤѻ��a  \033[44m              %12s vs. %-12s                        \033[m\r\n",
				curr->userid, dest->userid);

			for( c = 0; c < 11; c++ )
			{
				if( strlen(DestData[c]) )
					outs(DestData[c]);
				outs("\r\n");
			}

			move(yCurr, xCurr);

			bUpdate = false;
		}

		c = igetkey();

		switch(c)
		{
			case Ctrl('C'):
			case Ctrl('D'):
				dest->bbs->PutEvent(TALKTERM);
				bBreak = true;
				break;

			case Ctrl('W'):
				bTalkWait = true;
				break;

			case KEY_UP:
			case KEY_DOWN:
			case KEY_LEFT:
			case KEY_RIGHT:
			case Ctrl('A'):
			case Ctrl('E'):
			case '\177':
			case Ctrl('H'):
			case '\r':
			case '\n':
				TalkShow(true, c, &yCurr, &xCurr, 0);//*fpCurr);
				dest->bbs->PutEvent( c + TALKKEY );
				break;

			default:
				if ( c < 0 )
					c += 256;

				if( GlobalKeys(c) )
				{
					bUpdate = true;
				} else if( c == TALKTERM )
					bBreak = true;
				else if( c >= TALKKEY )
				{
					if( bTalkWait )
					{
						beep();
						bTalkWait = false;
					}

					if( bMyTurn || bFirst)
					{
						bMyTurn = false;
						move(yDest + 12, xDest);
					}

					TalkShow(false, c - TALKKEY, &yDest, &xDest, 0);
				} else if( ::IsValidKey(c) ) {
					dest->bbs->PutEvent( c + TALKKEY );

					if( !bMyTurn )
					{
						bMyTurn = true;
						move(yCurr, xCurr);
					}

					TalkShow(true, c, &yCurr, &xCurr, 0);//*fpCurr);
				}
		}

		bFirst = false;
		if( bBreak )
			break;
	}

//	::FCLOSE(fpCurr);
	return ;
}

void CTalkMenu::DoQuery ( Cbbs* bbs, char* szUserId )
{
CUserInfo t;
char szTemp[DATASIZE];
char* szSel[] = { "0���}", "1�ݥL/�o���W��", "2�g�H���L/�o", "3�d�ݸԲӨϥΪ̸��" };
bool bShowSecret = ( !_stricmp(bbs->GetUserId(), szUserId) || HAS_PERM1(PERM_ACCOUNTS) );
int nOldMode = bbs->SetMode(QUERY);

	if( passwds->Search(szUserId, &t) < 0 )
	{
		bbs->pressanykey(ERR_UID);
		return ;
	}

	bbs->clear();

	bbs->outs("\033[1;37m������\r\n");
	bbs->outs("\033[44m��  ��  ��  �������� ���~ ��  ��\r\n");
	bbs->outs("\033[40m����������  ������   �ࢣ ��  ��\r\n");
	bbs->outs("\033[44m������  ������������ ��   ������\r\n");
	bbs->outs("\033[40m                            ����\033[m\r\n");

	bbs->prints("\033[1;37;44m[ �N  �� ]\033[40m %-12s           \033[44m[ ��  �� ]\033[40m %s\r\n",
				t.userid, t.username);
	
	if( bShowSecret )
		bbs->prints("\033[44m[�u��m�W]\033[40m %s\r\n", t.realname);

	bbs->prints("\033[44m[ ��  �� ]\033[3%c;40m %-4s\033[37m                   \033[44m[ ��  �O ]\033[40m %s\r\n",
				t.feelingcolor + '1', t.feeling,
				(t.privacy & PRIVACY_SEX) || bShowSecret ? szSex[t.sex] : "[�O�K]");

COnlineInfo* oi = onlines->IsOnline(t.userid);

	bbs->prints("\033[44m[�ثe�ʺA]\033[40m %-12s           \033[44m[�s�H��Ū]\033[40m %s\r\n",
				oi ? ModeString(oi) : "���b���W", bbs->CheckMail(t.userid) ? "��" : "�L" );
	bbs->outs(MSG_SEPERATOR"\r\n");

char szLast[30];
	::Cdate(&t.lastlogin,  szLast);
	bbs->prints("\033[44m[�W���a�I]\033[40m %-20s   \033[44m[�W���ɶ�]\033[40m %s\r\n",
				(t.privacy & PRIVACY_LASTHOST) || bShowSecret ? (HAVE_PERM1(PERM_SYSOP) ? t.lasthost : ::GetFromHost(t.lasthost)) : "[�O�K]",
				(t.privacy & PRIVACY_LASTLOGIN) || bShowSecret ? szLast : "[�O�K]");

	bbs->prints("\033[44m[�峹�g��]\033[40m %-6d                 \033[44m[�W������]\033[40m %d\r\n",
				t.numposts, t.numlogins);

	if( (t.privacy & PRIVACY_MONEY) || bShowSecret )
	{
		bbs->prints("\033[44m[�Ҧ�����]\033[40m %-10ld             \033[44m[�Ҧ��ȹ�]\033[40m %ld\r\n",
					t.goldmoney, t.silvermoney);
	}
	bbs->outs(MSG_SEPERATOR"\r\n");

	if( (t.privacy & PRIVACY_STAR) || bShowSecret )
	{
		bbs->prints("\033[44m[ �P  �y ]\033[40m %-4s                   ",
					szStar[::GetHoroscope(t.month, t.day)]);
	} 

	if( (t.privacy & PRIVACY_BIRTHDAY) || bShowSecret )
	{
		bbs->prints("\033[44m[ ��  �� ]\033[40m %4d/%02d/%02d\r\n",
					1900 + t.year, t.month, t.day);
	}

	if( (t.privacy & PRIVACY_EMAIL) || bShowSecret )
	{
		bbs->prints("\033[44m[ E-Mail ]\033[40m %s",
					t.email);
	}

	switch( bbs->SelectData(23, 0, "�z�n�G", szSel,
			HAS_PERM1(PERM_ACCOUNTS) ? 4 : HAS_PERM1(PERM_BASIC) ? 3 : 1) )
	{
		case 1:
			bbs->clear();
			bbs->outs("\033[1;37m������\r\n");
			bbs->outs("\033[44m��  ��  ��  �������� ���~ ��  ��\r\n");
			bbs->outs("\033[40m����������  ������   �ࢣ ��  ��\r\n");
			bbs->outs("\033[44m������  ������������ ��   ������\r\n");
			bbs->outs("\033[40m                            ����\033[m\r\n");
			
			bbs->prints("[%s] ���W����^^\r\n\r\n", t.userid);

			::SetUserFile(szTemp, t.userid, "plans");
			if( !bbs->showfile(szTemp) )
			{
				wsprintf(szTemp, "%s �ثe�S���W����", t.userid);
				bbs->pressanykey(szTemp);
			} else
				bbs->pressanykey();
			break;

		case 2:
			MailMenu->DoMailTo(bbs, t.userid);
			break;

		case 3:
			bbs->UserInfo(&t, true);
			break;
	}

	bbs->SetMode(nOldMode);
}

int CTalkMenu::Message ( Cbbs* bbs )
{
	return FULLUPDATE;
}

bool Cbbs::IsFriend ( int uid )
{
int i;

	for( i = 0; i < MAX_FRIEND; i++ )
		if( online->friends[i] == uid )
			return true;

	return false;
}

bool Cbbs::IsRejected ( int uid )
{
int i;

	for( i = 0; i < MAX_REJECT; i++ )
		if( online->rejects[i] == uid )
			return true;

	return false;
}

void Cbbs::ShowMessages ( short nMode )
{
int nNowSelect;
int nCurr = online->currmsg - 1;
int i;

	if( !nMode ) 
	{
	bool bCurr = false;

		move(1, 0);
		outs("\033[1;36;40m �w�w�w�w�w�w�w�w���w�y�w�^�w�U�w�w�w�w�w�w�w�w�w \033[33;44m[Ctrl-R]\033[36;40m���U���� �w�w�w�w�w�w\033[m");

		for( i = nCurr; i >= 0; i-- )
		{
			bCurr = ( nCurrReply == i ); //(nCurr - i) );

			prints("\r\n%c \033[1;37;4%cm %s \033[40m %s",
					bCurr ? '>' : ' ',
					bCurr ? '4' : '0',
					online->msgs[i].szReplyTo,
					online->msgs[i].szMessage);
			clrtoeol();

			if( bCurr )
			{
				nNowSelect = i;
			}
		}

		for( i = (nMaxMsg - 1); i > nCurr; i-- )
		{
			bCurr = ( nCurrReply == i );//(nCurr + i + 1) );

			prints("\r\n%c \033[1;37;4%cm %s \033[40m %s",
					bCurr ? '>' : ' ',
					bCurr ? '4' : '0',
					online->msgs[i].szReplyTo,
					online->msgs[i].szMessage);
			clrtoeol();

			if( bCurr )
			{
				nNowSelect = i;
			}
		}
		outs("\033[1;36;40m\r\n �w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w \033[33;44m[Ctrl-T]\033[36;40m���W���� �w�w�w�w�w�w\033[m");
	} else {
	int n = nCurr - nCurrReply;

		move(n + 2, 0); 
		prints("\r\n> \033[1;37;44m %s \033[40m %s",
				online->msgs[nCurrReply].szReplyTo,
				online->msgs[nCurrReply].szMessage);
		clrtoeol();

		n += nMode; i = nCurrReply + nMode;
		if( n < 0 )
			n += 10;

		if( i < 0 )
			i += 10;

		move(n + 2, 0); 
		prints("\r\n  \033[1;37;40m %s \033[40m %s",
				online->msgs[i].szReplyTo,
				online->msgs[i].szMessage);
		clrtoeol();
	}

	move(0, 0); clrtoeol();
	outs("\033[1;37;44m");
	if( online->msgs[nNowSelect].szReplied[0] )
	{
		outs("�� ");
		outs(online->msgs[nNowSelect].szReplied);
	} else
		outs(" [�o�����y�z�٨S�^�L��I] ");
	outs("\033[m");
}
