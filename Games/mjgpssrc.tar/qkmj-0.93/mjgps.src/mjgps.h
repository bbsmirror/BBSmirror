#ifndef __MJGPS_H__
#define __MJGPS_H__

#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/resource.h>
#include <string.h>
#include <netdb.h>
#include <sys/errno.h>
#include <termio.h>
#include <fcntl.h>
#include <sys/param.h>
#include <sys/file.h>
#include <pwd.h>
#include <ctype.h>
#include <unistd.h>


#define DEFAULT_GPS_PORT 6666
#define DEFAULT_GPS_IP "140.113.17.163"
#define MAX_PLAYER 300
#define MAX_LOGIN  40
#define ASK_MODE 1
#define CMD_MODE 2

#define RECORD_FILE "/usr/local/games/lib/qkmj/qkmj.rec"
#define INDEX_FILE "/usr/local/games/lib/qkmj/qkmj.inx"
#define NEWS_FILE "/usr/local/games/lib/qkmj/news.txt"
#define BADUSER_FILE "/usr/local/games/lib/qkmj/baduser.txt"
#define LOG_FILE "/usr/local/games/lib/qkmj/qkmj.log"

#define DEFAULT_RECORD_FILE "/usr/local/games/lib/qkmj/qkmj.rec"
#define DEFAULT_MONEY 20000

#define QKMJ_ADMIN umlin000@cc.umanitoba.ca

struct player_record
{
    unsigned int id;
    char name[20];
    char password[15];
    long money;
    int level;
    int login_count;
    int game_count;
    long regist_time;
    long last_login_time;
    char last_login_from[60];
};

struct player_info
{
    int sockfd;
    int login;
    unsigned int id;
    char name[20];
    char username[30];
    long money;
    int serv;
    int join;
    int type;
    char note[80];
    int input_mode;
    int prev_request;
    struct sockaddr_in addr;
    int port;
    char version[10];
};

struct record_index_type
{
    char name[20];
    unsigned int id;
};


char *lookup (struct sockaddr_in *);
char *genpasswd (char *);
int checkpasswd (char *, char *);

int check_user (int);
void write_record ();
void close_id (int);
void close_connection (int);
void shutdown_server (void);


void gps_processing (int);

void core_dump (int);
void bus_err (int);
void broken_pipe (int);
void time_out (int);


#endif
