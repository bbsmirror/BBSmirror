#include "mjgps.h"

void
core_dump (int n)
{
    err ("CORE DUMP!\n");
    exit (0);
}

void
bus_err (int n)
{
    err ("BUS ERROR!\n");
    exit (0);
}

void
broken_pipe (int n)
{
    err ("Broken PIPE!!\n");
}

void
time_out (int n)
{
    extern int timeup;

    timeup = 1;
}
