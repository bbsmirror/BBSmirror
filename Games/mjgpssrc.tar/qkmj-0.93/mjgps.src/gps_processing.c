#include "mjgps.h"
#include "global.h"


void
gps_processing (int gps_sockfd)
{
    int alen;
    int fd, nfds = getdtablesize ();
    int player_id;
    int player_num = 0;
    int i, j;
    int msg_id;
    int read_code;
    char tmp_buf[80];
    char msg_buf[255];
    unsigned char buf[256];
    struct hostent *hp;
    int id;
    struct timeval tm;
    long current_time;
    struct tm *tim;
    struct fd_set rfds;
    
    
    printf ("FD_SIZE=%d\n", nfds);

    FD_ZERO (&afds);
    FD_SET (gps_sockfd, &afds);

    bcopy ((char *) &afds, (char *) &rfds, sizeof (rfds));
    tm.tv_sec = 0;
    tm.tv_usec = 0;
    /*
     * Waiting for connections 
     */
    for (;;)
    {
	bcopy ((char *) &afds, (char *) &rfds, sizeof (rfds));
	if (select (nfds, &rfds, (fd_set *) 0, (fd_set *) 0, 0) < 0)
	{
	    sprintf (msg_buf, "select: %d %s\n", errno, sys_errlist[errno]);
	    err (msg_buf);
	    continue;
	}
	if (FD_ISSET (gps_sockfd, &rfds))
	{
	    for (player_num = 1; player_num < MAX_PLAYER; player_num++)
		if (!player[player_num].login)
		    break;
	    if (player_num == MAX_PLAYER - 1)
		err ("Too many users");
	    player_id = player_num;
	    alen = sizeof (player[player_num].addr);
	    player[player_id].sockfd = accept (gps_sockfd, (struct sockaddr *)
					   &player[player_num].addr, &alen);
	    FD_SET (player[player_id].sockfd, &afds);
	    fcntl (player[player_id].sockfd, F_SETFL, FNDELAY);
	    player[player_id].login = 1;
	    strcpy (climark, lookup (&(player[player_id].addr)));
	    sprintf (msg_buf, "Connectted with %s\n", climark);
	    err (msg_buf);

	    time (&current_time);
	    tim = localtime (&current_time);
/*
 * if(tim->tm_hour>=2 && tim->tm_hour<6)
 * {
 * for(i=1;i<MAX_PLAYER;i++)
 * {
 * if(player[i].login)
 * {
 * print_news(player[i].sockfd,"opentime.lst");
 * close_id(i);
 * }
 * }
 * }
 */
	    if (player_id > MAX_LOGIN)
	    {
		if (strcmp (climark, "ccsun34") != 0)
		{
		    write_msg (player[player_id].sockfd, "101�藍�_,�ثe�ϥΤH�ƶW�L�W��, �еy��A�i��.");
		    print_news (player[player_id].sockfd, "server.lst");
		    close_id (player_id);
		}
	    }
	}
	for (player_id = 1; player_id < MAX_PLAYER; player_id++)
	{
	    if (player[player_id].login)
		if (FD_ISSET (player[player_id].sockfd, &rfds))
		{
		    /*
		     * Processing the player's information 
		     */
		    read_code = read_msg (player[player_id].sockfd, buf);
		    if (!read_code)
		    {
			close_id (player_id);
		    }
		    else if (read_code == 1)
		    {
			msg_id = convert_msg_id (player_id, buf);
			switch (msg_id)
			{
			case 99:	/*
					 * get username 
					 */
			    buf[15] = 0;
			    strcpy (player[player_id].username, buf + 3);
			    break;
			case 100:	/*
					 * check version 
					 */
			    *(buf + 6) = 0;
			    strcpy (player[player_id].version, buf + 3);
			    break;
			case 101:	/*
					 * user login 
					 */
			    buf[13] = 0;
			    strcpy (player[player_id].name, buf + 3);
			    for (i = 0; i < strlen (buf) - 3; i++)
			    {
				if (buf[3 + i] <= 32 && buf[3 + i] != 0)
				{
				    write_msg (player[player_id].sockfd, "101Invalid username!");
				    close_id (player_id);
				    break;
				}
			    }
			    for (i = 1; i < MAX_PLAYER; i++)
			    {
				if (player[i].login == 2 && strcmp (player[i].name, buf + 3) == 0)
				{
				    write_msg (player[player_id].sockfd, "006");
				    goto multi_login;
				}
			    }
			    if (read_user_name (player[player_id].name))
			    {
				write_msg (player[player_id].sockfd, "002");
			    }
			    else
			    {
				write_msg (player[player_id].sockfd, "005");
			    }
			  multi_login:;
			    break;
			case 102:	/*
					 * Check password 
					 */
			    if (read_user_name (player[player_id].name))
			    {
				*(buf + 11) = 0;
				if (checkpasswd (record.password, buf + 3))
				{
				    for (i = 1; i < MAX_PLAYER; i++)
				    {
					if (player[i].login == 2 &&
					    strcmp (player[i].name, player[player_id].name) == 0)
					{
					    close_id (i);
					    break;
					}
				    }
				    time (&record.last_login_time);
				    record.last_login_from[0] = 0;
				    if (player[player_id].username[0] != 0)
				    {
					sprintf (record.last_login_from, "%s@",
						 player[player_id].username);
				    }
				    strcat (record.last_login_from,
					    lookup (&player[player_id].addr));
				    record.login_count++;
				    write_record ();
				    if (check_user (player_id))
					welcome_user (player_id);
				    else
					close_id (player_id);
				}
				else
				{
				    write_msg (player[player_id].sockfd, "004");
				}
			    }
			    break;
			case 103:	/*
					 * Create new account 
					 */
			    *(buf + 11) = 0;
			    if (!add_user (player_id, player[player_id].name, buf + 3))
			    {
				close_id (player_id);
				break;
			    }
			    welcome_user (player_id);
			    break;
			case 104:	/*
					 * Change password 
					 */
			    *(buf + 11) = 0;
			    read_user_name (player[player_id].name);
			    strcpy (record.password, genpasswd (buf + 3));
			    write_record ();
			    break;
			case 2:
			    list_player (player[player_id].sockfd);
			    break;
			case 3:
			    list_table (player[player_id].sockfd, 1);
			    break;
			case 4:
			    strcpy (player[player_id].note, buf + 3);
			    break;
			case 5:
			    list_stat (player[player_id].sockfd, buf + 3);
			    break;
			case 6:
			    who (player[player_id].sockfd, buf + 3);
			    break;
			case 7:
			    broadcast (player_id, buf + 3);
			    break;
			case 8:
			    invite (player_id, buf + 3);
			    break;
			case 9:
			    send_msg (player_id, buf + 3);
			    break;
			case 10:
			    lurker (player[player_id].sockfd);
			    break;
			case 11:
			    /*
			     * Check for table server  
			     */
			    for (i = 1; i < MAX_PLAYER; i++)
			    {
				if (player[i].login == 2 && player[i].serv)
				{
				    /*
				     * Find the name of table server 
				     */
				    if (strcmp (player[i].name, buf + 3) == 0)
				    {
					if (player[i].serv >= 4)
					{
					    write_msg (player[player_id].sockfd, "101����H�Ƥw��!");
					    goto full;
					}
					sprintf (msg_buf, "120%5d%ld", player[player_id].id,
						 player[player_id].money);
					write_msg (player[i].sockfd, msg_buf);
					sprintf (msg_buf, "211%s", player[player_id].name);
					write_msg (player[i].sockfd, msg_buf);
					sprintf (msg_buf, "0110%s %d",
						 inet_ntoa (player[i].addr.sin_addr), player[i].port);
					write_msg (player[player_id].sockfd, msg_buf);
					player[player_id].join = i;
					player[player_id].serv = 0;
					player[i].serv++;
					break;
				    }
				}
			    }
			    if (i == MAX_PLAYER)
				write_msg (player[player_id].sockfd, "0111");
			  full:;
			    break;
			case 12:
			    player[player_id].port = atoi (buf + 3);
			    if (player[player_id].join)
			    {
				if (player[player[player_id].join].serv > 0)
				    player[player[player_id].join].serv--;
				player[player_id].join = 0;
			    }
			    /*
			     * clear all client 
			     */
			    for (i = 1; i < MAX_PLAYER; i++)
			    {
				if (player[i].join == player_id)
				    player[i].join = 0;
			    }
			    player[player_id].serv = 1;
			    break;
			case 13:
			    list_table (player[player_id].sockfd, 2);
			    break;
			case 20:
			    strcpy (msg_buf, buf + 3);
			    *(msg_buf + 5) = 0;
			    id = atoi (msg_buf);
			    read_user_id (id);
			    record.money = atol (buf + 8);
			    record.game_count++;
			    write_record ();
			    for (i = 1; i < MAX_PLAYER; i++)
			    {
				if (player[i].login == 2 && player[i].id == id)
				{
				    player[i].money = record.money;
				    break;
				}
			    }
			    break;
			case 21:	/*
					 * FIND 
					 */
			    find_user (player[player_id].sockfd, buf + 3);
			    break;
			case 111:
/*
 * player[player_id].serv++;
 */
			    break;
			case 200:
			    close_id (player_id);
			    break;
			case 202:
			    if (strcmp (player[player_id].name, "candle") != 0)
				break;
			    id = find_user_name (buf + 3);
			    if (id >= 0)
			    {
				write_msg (player[id].sockfd, "200");
				close_id (id);
			    }
			    break;
			case 205:
			    if (player[player_id].serv)
			    {
				/*
				 * clear all client 
				 */
				for (i = 1; i < MAX_PLAYER; i++)
				{
				    if (player[i].join == player_id)
					player[i].join = 0;
				}
				player[player_id].serv = 0;
				player[player_id].join = 0;
			    }
			    else if (player[player_id].join)
			    {
				if (player[player[player_id].join].serv > 0)
				    player[player[player_id].join].serv--;
				player[player_id].join = 0;
			    }
			    break;
			case 500:
			    if (strcmp (player[player_id].name, "candle") == 0)
				shutdown_server ();
			    break;
			default:
			    sprintf (msg_buf, "### cmd=%d player_id=%d sockfd=%d ###\n", msg_id, player_id, player[player_id].sockfd);
			    err (msg_buf);
			    close_connection (player_id);
			    sprintf (msg_buf, "Connection to %s error, closed it\n",
				     lookup (&(player[player_id].addr)));
			    err (msg_buf);
			    break;
			}
			buf[0] = '\0';
		    }
		}
	}
    }
}
