extern int errno;
extern char *sys_errlist[];
extern struct fd_set rfds, afds;

extern char climark[30];

extern struct player_info player[MAX_PLAYER];

extern struct player_record record;

extern struct record_index_type record_index;

extern FILE *fp;

