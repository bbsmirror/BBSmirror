/* 
   Li-te Huang, lthuang@cc.nsysu.edu.tw, 10/29/97
*/

#include "bbs.h"
#include "tsbbs.h"


/*
   �Хܤ峹�wŪ
 */
void
readed_article(ent, finfo, direct)
int ent;
FILEHEADER *finfo;
char *direct;
{
	if (in_mail)
	{
		register int fd;

		if (finfo->accessed & FILE_READ)
			return;
		if (ent > BRC_REALMAXNUM)	/* debug */
			return;
		if ((fd = open(direct, O_RDWR)) > 0)
		{
			finfo->accessed |= FILE_READ;

			/* no file lock to speed-up processing */
			if (lseek(fd, (off_t) ((ent - 1) * FH_SIZE), SEEK_SET) != -1)
				write(fd, finfo, FH_SIZE);
			close(fd);
		}
	}
	else if (in_board)
	{
		if (ReadRC_UnRead(finfo->artno))
			ReadRC_Addlist(finfo->artno);
	}
}


/*
   �ק�峹���D
 */
int
title_article(ent, finfo, direct)
int ent;
FILEHEADER *finfo;
char *direct;
{
	char title[TTLEN + 1];
	FILEHEADER *fhr = &fhGol;


	if (finfo->accessed & FILE_DELE)
		return R_NO;
	if (!HAS_PERM(PERM_SYSOP))
	{
		/* 
		   1. �@��Ϥ峹, ����@�̥i
		   2. ��ذϤ峹, ���O�D, �O�D�U��i
		   3. �������b����
		 */
		if ((in_board && strcmp(curuser.userid, finfo->owner)) ||
		    (!in_mail && !in_board && !hasBMPerm))
		{
			return R_NO;
		}
	}

	if (!getdata(b_line, 0, _msg_ent_new_title, title, sizeof(title), DOECHO, NULL))
		return R_LINE;
	if (get_record(direct, fhr, FH_SIZE, ent) == -1)
		return R_LINE;
	strcpy(fhr->title, title);
	if (substitute_record(direct, fhr, FH_SIZE, ent) == -1)
		return R_LINE;

	if (finfo->accessed & FILE_TREA)
		return R_NEW;
	else
	{
		char fn_r[PATHLEN], fn_w[PATHLEN];
		FILE *fpr, *fpw;
		BOOL bIsHeader = TRUE;


		setdotfile(fn_r, direct, finfo->filename);
		sprintf(fn_w, "tmp/TITLE_ART.%s", curuser.userid);
		if ((fpr = fopen(fn_r, "r")) == NULL)
			return R_LINE;
		if ((fpw = fopen(fn_w, "w")) == NULL)
		{
			fclose(fpr);
			return R_LINE;
		}
		while (fgets(genbuf, sizeof(genbuf), fpr))
		{
			if (bIsHeader)
			{
				if (genbuf[0] == '\n')
					bIsHeader = FALSE;
				else
				{
					if (!strncmp(genbuf, _str_header_title, 7))
					{
						fprintf(fpw, "%s%s\n", _str_header_title, title);
						continue;
					}
				}
			}
			fprintf(fpw, "%s", genbuf);
		}
		fclose(fpw);
		fclose(fpr);
		chmod(fn_w, 0600);
		myrename(fn_w, fn_r);

		return R_NEW;
	}
	return R_LINE;
}


/*
   �ק�峹
 */
int
edit_article(ent, finfo, direct)
int ent;			/* unused */
FILEHEADER *finfo;
char *direct;
{
	char fnori[PATHLEN];


	if ((finfo->accessed & FILE_DELE) || (finfo->accessed & FILE_TREA))
		return R_NO;
	if (!HAS_PERM(PERM_SYSOP))
	{
		/* 
		   1. �@��Ϥ峹, ����@�̥i
		   2. ��ذϤ峹, ���O�D, �O�D�U��i
		   3. �������b����
		 */
		if ((in_board && strcmp(finfo->owner, curuser.userid))
		    || (!in_mail && !in_board && !hasBMPerm))
		{
			return R_NO;
		}
	}

	update_umode(MODIFY);

	setdotfile(fnori, direct, finfo->filename);
	if (vedit(fnori, NULL))
	{
		outs(_msg_fail);
		pressreturn();
		return R_FULL;
	}
	sprintf(genbuf, "\n--\n* Origin: %s * From: %s\n",
		BBSNAME, uinfo.from);
	append_record(fnori, genbuf, strlen(genbuf));

	outs(_msg_finish);
	pressreturn();
	return R_FULL;
}


/*
   �аO�峹�O�d
 */
int
reserve_article(ent, finfo, direct)
int ent;
FILEHEADER *finfo;
char *direct;
{
	if ((finfo->accessed & FILE_DELE) || (finfo->accessed & FILE_TREA))
		return R_NO;
	/* 
	   1. ��ذϤ峹�Ҥ��i
	   2. �ӤH�H�c�ҥi
	   3. �@��Ϥ峹, �����O�D, �O�D�U��, �����i
	 */
	if ((!in_mail && !in_board)
	    || (!in_mail && !HAS_PERM(PERM_SYSOP) && !hasBMPerm))
	{
		return R_NO;
	}
	/*
	msg(_msg_reserve_article);
	*/

/*wnlee*/
	
	reserve_one_article(ent, finfo, direct);
/*
	switch (igetkey())
	{
	case 'm':
		if (!(finfo->accessed & FILE_RESRV))
			reserve_one_article(ent, finfo, direct, 'm');
		break;
	case 'u':
		if (finfo->accessed & FILE_RESRV)
			reserve_one_article(ent, finfo, direct, 'u');
		break;
	default:
		break;
	}
*/
	return R_LINE;
}


/*
   �妸�Ϭq�аO�R���峹
 */
int
range_delete_article(ent, finfo, direct)
int ent;			/* unused */
FILEHEADER *finfo;		/* unused */
char *direct;
{
	int n1, n2;


	/* 
	   1. ��ذϤ峹�Ҥ��i
	   2. �ӤH�H�c�ҥi
	   3. �@��Ϥ峹, �����O�D, �O�D�U��, �����i
	 */
	if ((!in_mail && !in_board)
	    || (!in_mail && !HAS_PERM(PERM_SYSOP) && !hasBMPerm))
	{
		return R_NO;
	}

	clear();
	outs(_msg_article_1);
	getdata(1, 0, _msg_article_2, genbuf, 6, ECHONOSP, NULL);
	n1 = atoi(genbuf);
	getdata(2, 0, _msg_article_3, genbuf, 6, ECHONOSP, NULL);
	n2 = atoi(genbuf);
	if (n1 <= 0 || n2 <= 0 || n2 < n1)
		return R_FULL;
	outs(_msg_not_sure);
	if (igetkey() != 'y')
		return R_FULL;

	if (delete_articles(direct, n1, n2, curuser.userid, 'd') == -1)
	{
		outs("\n");
		outs(_msg_fail);
	}
	else
	{
		if (in_mail)
			uinfo.ever_delete_mail = TRUE;
		/* pack index file of treasure immediately */
		else if (!in_board && !in_mail)
			pack_article(direct);
		outs(_msg_finished);
	}
	pressreturn();
	return R_NEW;
}


/*
   Reply mail, post (two way and both provided for user)
 */
int
reply_article(finfo, direct)
FILEHEADER *finfo;
char *direct;
{
	char fn_src[PATHLEN], title[STRLEN], strTo[STRLEN];
	int result;
	int mail_ok = in_mail;
	int post_ok = mail_ok ^ 1;	/* excusive with mail_ok */

	if (!in_board && !in_mail)
		return R_FULL;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return R_FULL;
#endif		
		
	clear();
	if (!in_mail)
	{
		int ch;
		
		outs(_msg_mailpost_reply);
		ch = getkey();
		if (ch == '2')
		{
			post_ok = FALSE;
			mail_ok = TRUE;
		}
		else if (ch == '3')
		{
			mail_ok = TRUE;
		}
	}
	else
		post_ok = FALSE;

	if (mail_ok)
	{
		/*
		   the field of owner may like:
		   #uuuu@xxxx.yyyy.zzzz
		 */
		if (finfo->owner[0] == '#')
			strcpy(strTo, finfo->owner + 1);
		else
			strcpy(strTo, finfo->owner);
	}

	setdotfile(fn_src, direct, finfo->filename);

	/* copy to title as have Re: */
	title[0] = '\0';
	if (strncmp(finfo->title, STR_REPLY, REPLY_LEN))
		strcpy(title, STR_REPLY);
	strcat(title, finfo->title);

	if (mail_ok)
	{
		/* postpath: NULL */
		result = PrepareMailPost(fn_src, strTo, title, NULL, mail_ok, post_ok);
	}
	else
	{
		/* to: NULL, postpath: NULL */
		result = PrepareMailPost(fn_src, NULL, title, NULL, mail_ok, post_ok);
	}

	move(b_line - 2, 0);
	clrtobot();
	if (result == -1)
	{
		if (post_ok)
			outs(_msg_post_fail);
		outs("\n");
		if (mail_ok)
			outs(_msg_mail_fail);
	}
	else if (result == -2)
	{
		outs(_msg_mail_fail);
	}
	else if (result == -3)
	{
		outs(_msg_post_fail);
	}
	else
	{
		if (post_ok)
			outs(_msg_post_finish);
		outs("\n");
		if (mail_ok)
			outs(_msg_mail_finish);
	}
	pressreturn();

	return R_NEW;
}


/* 
   prompt, when article display done 
 */
int
read_article(ent, finfo, direct)
int ent;
FILEHEADER *finfo;
char *direct;
{
	static int updown = CAREYDOWN;
	char fname[PATHLEN];


	if (finfo->accessed & FILE_DELE)
		return updown;

	setdotfile(fname, direct, finfo->filename);
	if (!dashf(fname))	/* debug */
		return R_FULL;
	more(fname, FALSE);

	readed_article(ent, finfo, direct);

	msg(_msg_article_5);
	/*
	   If cursor at the right side of two-bit word, 
	   some system would send BackSpace or Del key twice.
	   To avoid this problem, move cursor to first word.
	 */
	move(b_line, 0);

	switch (igetkey())
	{
	case KEY_RIGHT:
	case KEY_DOWN:
	case SP:
	case 'n':
		return (updown = CAREYDOWN);
	case KEY_UP:
	case 'p':
		return (updown = CAREYUP);
	case 'r':
	case 'y':
		return reply_article(finfo, direct);
	case 'm':
		mail_article(ent, finfo, direct);
		return updown;
	case 'd':
		delete_article(ent, finfo, direct);
		return updown;
	case 'q':
	case KEY_LEFT:
	default:
		break;
	}
	return R_FULL;
}


/*
   �R����ذϥؿ�
 */
static int
delete_direct(ent, finfo, direct)
int ent;
FILEHEADER *finfo;
char *direct;
{
	if (in_mail || in_board || (!HAS_PERM(PERM_SYSOP) && !hasBMPerm))
		return R_NO;
	if (delete_record(direct, FH_SIZE, ent) == 0)
	{
		setdotfile(genbuf, direct, finfo->filename);
		myunlink(genbuf);
		msg(_msg_finish);
		getkey();
		return R_NEW;
	}
	msg(_msg_fail);
	getkey();
	return R_LINE;
}


/*
   �аO�R���峹
 */
int
delete_article(ent, finfo, direct)
int ent;
FILEHEADER *finfo;
char *direct;
{
	if (in_mail)
	{
		strcpy(genbuf, _msg_article_6);
	}
	else if (in_board)
	{
#ifdef GUEST_ACCOUNT
		if (!strcmp(curuser.userid, GUEST_ACCOUNT))
			return R_NO;
#endif
		if (HAS_PERM(PERM_SYSOP) || hasBMPerm)
			strcpy(genbuf, _msg_article_7);
		else if (!strcmp(finfo->owner, curuser.userid))
			strcpy(genbuf, _msg_article_8);
		else
			return R_NO;
	}
	else
	{
		if (!HAS_PERM(PERM_SYSOP) && !hasBMPerm)
			return R_NO;
		if (finfo->accessed & FILE_TREA)
		{
			msg(_msg_article_9, finfo->title);
			if (igetkey() != 'y')
				return R_LINE;
			return delete_direct(ent, finfo, direct);
		}
		strcpy(genbuf, _msg_article_10);
	}

	msg(genbuf);

	switch (igetkey())
	{
	case 'r':
		if (!strchr(finfo->owner, '@'))
		{
			setdotfile(genbuf, direct, finfo->filename);
			SendMail_Local(genbuf, curuser.userid, finfo->owner, _msg_article_11, curuser.ident);
		}
	case 'y':
	case 'm':
		if (!(finfo->accessed & FILE_RESRV) && !(finfo->accessed & FILE_DELE))
		{
			if (delete_one_article(ent, finfo, direct, curuser.userid, 'd') == 0)
			{
				if (in_mail)
					uinfo.ever_delete_mail = TRUE;
				else if (in_board)
				{
					if (finfo->owner[0] != '#' && (CurBList->brdtype & BRDTYPE_NEWS))
#if EMAIL_LIMIT
						if (finfo->ident == 7)
#endif
							append_news(CurBList->name, finfo->filename, 'D');
				}
				else
				{
					/* pack index file of treasure immediately */
					pack_article(direct);
					return R_NEW;
				}
			}
		}
		break;
	case 'u':
		if (finfo->accessed & FILE_DELE)
		{
			char *delby = finfo->title + sizeof(finfo->title) - IDLEN;
			
			if (HAS_PERM(PERM_SYSOP) || !strcmp(delby, curuser.userid)
			    || (in_board && isBM && strcmp(delby, finfo->owner)))
			{
				delete_one_article(ent, finfo, direct, curuser.userid, 'u');
			}
		}
		break;
	case 'n':
	default:
		break;
	}
	return R_LINE;
}


/* 
   ask email address 
 */
static int
AskEmailTo(addr)
char addr[];
{
	if (addr[0] == '\0')	/* default e-mail */
		strcpy(addr, curuser.email);
	if (addr[0] != '\0')
	{
		msg(_msg_article_12, addr);
		if (igetkey() == 'n')
			addr[0] = '\0';
	}
	if (addr[0] == '\0')
	{
		if (!getdata(b_line, 0, _msg_article_13, addr, STRLEN - 10, ECHONOSP, NULL))
			return -1;
	}
	return 0;
}


/* 
   mail article to someone in batch mode 
 */
int
mail_articles(direct, from, to, ident, uuencode, wtop)
char *direct;
char *from, *to;
char ident;
int uuencode;
struct word *wtop;
{
	char fname[PATHLEN], uuname[PATHLEN];
	int fd, ms;
	FILEHEADER *fhr = &fhGol;
	int sentout;

	if ((fd = open(direct, O_RDONLY)) < 0)
		return -1;
	if ((ms = CreateMailSocket()) < 0)
	{
		close(fd);
		return -1;
	}

	sentout = is_emailaddr(to);
	
	while (read(fd, fhr, FH_SIZE) == FH_SIZE)
	{
		if (fhr->accessed & FILE_DELE || fhr->accessed & FILE_TREA)
			continue;
		if (!cmp_wlist(wtop, fhr->filename, strcmp))
			continue;
		uuname[0] = '\0';
		setdotfile(fname, direct, fhr->filename);
		if (sentout)
		{
			if (uuencode)
			{
				uuencode_file(fname, uuname);
				SendMail_Internet(ms, uuname, from, to, fhr->title);
			}
			else
				SendMail_Internet(ms, fname, from, to, fhr->title);
		}
		else
			SendMail_Local(fname, from, to, fhr->title, ident);
		if (uuname[0])
			unlink(uuname);
	}
	CloseMailSocket(ms);
	close(fd);
	return 0;
}


/*
   ��H�峹
 */
int
mail_article(ent, finfo, direct)
int ent;			/* unused */
FILEHEADER *finfo;
char *direct;
{
	char buf[PATHLEN];
	static char DefEmailAddr[STRLEN] = "\0";


	if (finfo->accessed & FILE_DELE || finfo->accessed & FILE_TREA)
		return R_NO;
#if EMAIL_LIMIT
	if (curuser.ident != 7)
	{
		msg(_msg_sorry_email);
		getkey();
		return R_LINE;
	}
#endif

	msg(_msg_article_14);

	switch (igetkey())
	{
	case 'm':
		if (!cmp_wlist(artwtop, finfo->filename, strcmp))
			artwtop = add_wlist(artwtop, finfo->filename, malloc_str);
		break;
	case 'u':
		if (artwtop)
			cmpd_wlist(&artwtop, finfo->filename, strcmp, free);
		break;
	case 'n':
		setdotfile(buf, direct, finfo->filename);
		if (AskEmailTo(DefEmailAddr) == 0)
		{
			register int result;

			if (is_emailaddr(DefEmailAddr))
			{
				char fnameNew[PATHLEN];

				msg(_msg_ask_uuencode);
				if (igetkey() == 'y')
					uuencode_file(buf, fnameNew);
				else
					strcpy(fnameNew, buf);
				result = SendMail_Internet(-1, fnameNew, curuser.userid, DefEmailAddr, finfo->title);
			}
			else
				result = SendMail_Local(buf, curuser.userid, DefEmailAddr, finfo->title, curuser.ident);
			if (result == -1)
				msg(_msg_fail);
			else
				msg(_msg_finish);
			getkey();
		}
		break;
	case 't':
		if (!artwtop)
		{
			msg(_msg_article_15);
			getkey();
			break;
		}
		msg(_msg_article_16);
		if (igetkey() == 'n')
			break;
		if (AskEmailTo(DefEmailAddr) == 0)
		{
			BOOL bUUencode;


			msg(_msg_article_17);
			if (igetkey() == 'y')
				bUUencode = TRUE;
			else
				bUUencode = FALSE;
			if (mail_articles(direct, curuser.userid, DefEmailAddr,
				    curuser.ident, bUUencode, artwtop) == -1)
			{
				msg(_msg_fail);
			}
			else
			{
				msg(_msg_finish);
			}
			getkey();
		}
		break;
	default:
		break;
	}
	return R_LINE;
}


/*
   ��K�峹
 */
int
cross_article(ent, finfo, direct)
int ent;			/* unused */
FILEHEADER *finfo;
char *direct;
{
	char bname[BNAME_LEN + 1];
	char fnori[PATHLEN], title[STRLEN] = "\0";
	int result;
	int tonews = FALSE;
	struct BoardList *cb;
	extern struct BoardList *search_board_list();

	if (!in_board && !in_mail)
		return R_NO;


	if (in_mail)
	{
		if (MakeBoardList() == -1)
			return R_NO;
	}
		
	if (!getdata(b_line, 0, _msg_cross_which_board, bname, sizeof(bname), ECHONOSP, NULL))
		return R_LINE;
	if ((!in_mail && in_board && !strcmp(CurBList->name, bname))
	    || !(cb = (struct BoardList *) search_board_list(bname)))
	{
		msg(_msg_err_boardname);
		getkey();
		return R_LINE;
	}

	clear();

	prints(_msg_post_on_normal, cb->name);
	if (has_postperm(cb) == -1)
		return R_FULL;

	if (strncmp(finfo->title, _str_crosspost, 6))
		sprintf(title, "%s %s", _str_crosspost, finfo->title);
	else
		sprintf(title, "%s", finfo->title);

	setdotfile(fnori, direct, finfo->filename);

	if (!in_mail && in_board && (cb->brdtype & BRDTYPE_NEWS))
	{
#if EMAIL_LIMIT
		/* do not send the post to news, if user is not identified */
		if (curuser.ident != 7)
			outs(_msg_no_ident_send_tonews);
		else
#endif
		{
			/* by default, send post to news */
			outs(_msg_send_tonews_yesno);
			if (igetkey() != 'n')
				tonews = TRUE;
		}
	}

	/* 
	   �i�K�ܤ@���  postpath: NULL 
	 */
	result = PublishPost(fnori, curuser.userid, bname, title,
			     curuser.ident, uinfo.from, FALSE, NULL);

	move(b_line - 1, 0);
	if (result == -1)
		outs(_msg_fail);
	else
	{
		outs(_msg_finish);
	}
	pressreturn();
	return R_FULL;
}


char srchbword[] = "A>]/";
char srchassoc[] = "[]=";
char srchauthor[] = "aA";

#define SCMP_AUTHOR	    0x01
#define SCMP_ASSOC	    0x04
#define SCMP_BACKWARD	0x20

/*
   �j�M�峹
 */
int
search_article(direct, ent, cmps_str, op, srchwtop)
register char *direct, *cmps_str, op;
register int ent;
register struct word **srchwtop;
{
	FILEHEADER *fhr = &fhGol;
	char author[STRLEN];
	int fd;
	register char *takestr;
	register int cmps_kind = 0;
	register int total_target = 0;


	if (cmps_str == NULL || cmps_str[0] == '\0')
		return -1;

	if (strchr(srchbword, op))
		cmps_kind = SCMP_BACKWARD;
	if (strchr(srchauthor, op))
		cmps_kind |= SCMP_AUTHOR;
	else if (strchr(srchassoc, op))
		cmps_kind |= SCMP_ASSOC;

	if (cmps_kind & SCMP_BACKWARD)
	{
		if (++ent > get_num_records(direct, FH_SIZE))
			return -1;
	}
	else
	{
		if (--ent < 1)
			return -1;
	}

	if (cmps_kind & SCMP_ASSOC)
	{
		/* make cmps_str as no Re: */
		if (!strncmp(cmps_str, STR_REPLY, REPLY_LEN))
			strcpy(cmps_str, cmps_str + REPLY_LEN);
	}

	if ((fd = open(direct, O_RDONLY)) < 0)
		return -1;

	lseek(fd, (off_t) ((ent - 1) * FH_SIZE), SEEK_SET);

	while (read(fd, fhr, FH_SIZE) == FH_SIZE)
	{
		if (cmps_kind & SCMP_AUTHOR)
		{
			xstrncpy(author, fhr->owner, sizeof(author));
			strtok(author, ".@");
			takestr = author;
			if (takestr[0] == '#')
				takestr++;
			if (!strcmp(takestr, cmps_str))		/* compare */
			{
				if (srchwtop)
				{
					*srchwtop = add_wlist(*srchwtop, fhr->filename, malloc_str);
					total_target++;
				}
				else
				{
					close(fd);
					return ent;
				}
			}
		}
		else
		{
			if (!(fhr->accessed & FILE_DELE))
			{
				takestr = fhr->title;
				if (op == '=')
				{
					if (!strcmp(takestr, cmps_str))
					{
						close(fd);
						return ent;
					}
				}
				else
				{
					if (strstr(takestr, cmps_str))	/* compare */
					{
						if (srchwtop)	/* found it */
						{
							*srchwtop = add_wlist(*srchwtop, fhr->filename, malloc_str);
							total_target++;
						}
						else
						{
							close(fd);
							return ent;
						}
					}

				}
			}
		}

		if (cmps_kind & SCMP_BACKWARD)
			ent++;
		else
		{
			if (--ent < 1)	/* abort search */
				break;
			lseek(fd, -2 * ((off_t) FH_SIZE), SEEK_CUR);
		}
	}
	close(fd);
	if (srchwtop)
		return total_target;
	return -1;
}


/*
   �洫��ذϤ峹�Υؿ�
 */
int
xchg_treasure(ent, finfo, direct)
int ent;
FILEHEADER *finfo;		/* unused */
char *direct;
{
	int newpos;
	FILEHEADER newhr;

	if (in_mail || in_board || (!HAS_PERM(PERM_SYSOP) && !hasBMPerm))
		return R_NO;

	if (!getdata(b_line, 0, _msg_article_18, genbuf, 6, ECHONOSP, NULL))
		return R_LINE;

	newpos = atoi(genbuf);

	if (get_record(direct, &newhr, FH_SIZE, newpos) == 0)
	{
		/* must be the same type, post or sub-directory */
		if (finfo->accessed == newhr.accessed)
		{
			/* no file lock to speed-up processing */
			if (substitute_record(direct, finfo, FH_SIZE, newpos) == 0
			    && substitute_record(direct, &newhr, FH_SIZE, ent) == 0)
			{
				msg(_msg_finish);
				getkey();
				return R_NEW;
			}
		}
	}
	msg(_msg_fail);
	getkey();
	return R_LINE;
}


int
do_article_title(title)
char title[];
{
	if (title[0])
	{
		printxy(3, 0, _msg_article_19, title);
		if (igetkey() == 'n')
			title[0] = '\0';
	}
	if (title[0] == '\0')
	{
		if (!getdata(3, 0, _msg_title, title, TTLEN, DOECHO, NULL))
			return -1;
	}
	return 0;
}


void
uuencode_file(fname, uuname)
char *fname, *uuname;
{
	char cmd[PATHLEN + 30], buf[PATHLEN];


	sprintf(buf, "tmp/UUENCODE.%s.%d", getpid(), time(0));
	sprintf(cmd, "uuencode \"%s\" bbs.uu > \"%s\"", fname, buf);
	outdoor(cmd, UNDEFINE, TRUE);
	strcpy(uuname, buf);
}
