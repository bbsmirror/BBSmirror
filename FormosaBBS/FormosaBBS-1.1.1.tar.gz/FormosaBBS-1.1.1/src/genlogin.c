/*
   Li-te Huang, lthuang@cc.nsysu.edu.tw, 03/10/98
 */

#include "bbs.h"


extern char *genpasswd();


usage(prog)
char *prog;
{
	fprintf(stderr, "Usage: %s \
-u uid -c username -p password -l userlevel   userid\n", prog);
	fflush(stderr);
}


int
main(argc, argv)
int argc;
char *argv[];
{
	struct userec urec;
	struct useridx uidx;
	int fd, fdidx;
	char buf[80];
	char userid[IDLEN], username[UNAMELEN], password[PASSLEN];
	char path[80], idxpath[80];
	unsigned int uid;
	unsigned int userlevel;
	int c;
	int uflag = 0, cflag = 0, pflag = 0, lflag = 0;


	while ((c = getopt(argc, argv, "u:c:p:l:")) != -1)
	{
		switch (c)
		{
			case 'u':
				uid = atoi(optarg);
				uflag = 1;
				break;
			case 'c':
				xstrncpy(username, optarg, sizeof(username));
				cflag = 1;
				break;
			case 'p':
				xstrncpy(password, optarg, PASSLEN);
				pflag = 1;
				break;
			case 'l':
				userlevel = atoi(optarg);
				lflag = 1;
				break;
			case '?':
			default:
				usage(argv[0]);
				exit(-1);
		}
	}

	if (!uflag || !cflag || !pflag || !lflag)
	{
		usage(argv[0]);
		exit(-1);
	}

	if (optind == argc || !*argv[optind])
	{
		fprintf(stderr, "\nmissing userid\n");
		usage(argv[0]);
		exit(-1);
	}

	if (strlen(argv[optind]) >= IDLEN)
	{
		fprintf(stderr, "\nuserid too long\n");
		usage(argv[0]);
		exit(-1);
	}
	strcpy(userid, argv[optind]);

	init_bbsenv();

	sethomefile(path, userid, NULL);
	if (!dashd(path))
	{
		if (mkdir(path, 0700) == -1)
		{
			fprintf(stderr, "cannot mkdir: %s", path);
			return -2;
		}
		chown(path, BBS_UID, BBS_GID);
	}

	sethomefile(path, userid, UFNAME_PASSWDS);
	if ((fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0600)) < 0)
	{
		perror(argv[0]);
		return 1;
	}

	if ((fdidx = open(USERIDX, O_WRONLY | O_CREAT, 0600)) < 0)
	{
		perror(argv[0]);
		return 1;
	}
	flock(fdidx, LOCK_EX);
	if (lseek(fdidx, (uid - 1) * sizeof(uidx), SEEK_SET) == -1)
	{
		flock(fdidx, LOCK_UN);
		perror(argv[0]);
		return 1;
	}

	memset(&urec, 0, sizeof(urec));

	urec.uid = uid;
	strcpy(urec.userid, userid);
	strcpy(buf, genpasswd(userid));
	strncpy(urec.passwd, buf, PASSLEN);
	strcpy(urec.username, username);
	urec.userlevel = userlevel;
	urec.firstlogin = time(0);

	write(fd, &urec, sizeof(urec));
	close(fd);
	chown(path, BBS_UID, BBS_GID);

	memset(&uidx, 0, sizeof(uidx));
	strncpy(uidx.userid, urec.userid, sizeof(uidx.userid) - 1);
	write(fdidx, &uidx, sizeof(uidx));
	close(fdidx);
	chown(USERIDX, BBS_UID, BBS_GID);

	return 0;
}
