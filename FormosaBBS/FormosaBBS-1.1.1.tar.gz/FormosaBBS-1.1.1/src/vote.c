   
#include "bbs.h"
#include "tsbbs.h"

static void printvote();
int save_in_board;

#ifdef USE_VOTE

#define PUTCURS(c)   {move(c, 3); outs(_str_cursor);}

#define SYSVOTE      "vote/sys/"
#define BOARDVOTE    "vote/boards/"
#define NEWVOTEMSG   "vote/NEWMSG"
#define VOTETIME     "vote/sys/time_limit"
#define VOTEMEN 	 "VoteMen"
#define VOTENEW 	 "VoteNew"


enum
{
	NC1 = 0,		/* t */
	NC2,			/* e */
	NC3,			/* i */
	NC4,			/* m */
	NC5,			/* d */
	NC6,			/* n */
	NC7,			/* p */
	NC9 = 7,		/* l */
	NC8 = 8			/* s */
};


#define VLEN		41
#define WRITTEN 	"[Written]"
#define NONE 		"[None]"
#define MAXITEM 	25

static int votetitle(), voteip(), votemax(), VTC_candidate(), VTC_doc(), VTC_limit(),
  VTC_start(), VTC_end(), VTC_save();

typedef struct
{
	int order;		/* order */
	char dirname[12];	/* directory (M.XXXXXXXXX.A)  */
	char title[VLEN];	/* title */
	char TotalCandidate;	/* total candidates */
	char MaxTicket;		/* max tickets */
	long StartTime;		/* �}�l�벼�ɶ� */
	long EndTime;		/* �벼�I��ɶ� */
	char AllowIP[20];	/* �ѥ[�벼���W���ӷ����� */
	unsigned int userlevel;	/* �ѥ[�벼�����ŭ���� */
}
voteheader;

struct VLink
{
	voteheader vword;
	struct VLink *prev;
	struct VLink *next;
};

typedef struct VLink VLink;

VLink *curlink, *votetop, *scrtop;

typedef struct
{
	int hkey;
	int prow;
	int row;
	int nrow;
	char *desc;
	char context[VLEN];
	int (*func) ();
}
VCommand;

char voteitems[MAXITEM + 1][31] =
{
	NONE, NONE, NONE, NONE,
	NONE, NONE, NONE, NONE,
	NONE, NONE, NONE, NONE,
	NONE, NONE, NONE, NONE,
	NONE, NONE, NONE, NONE,
	NONE, NONE, NONE, NONE,
	NONE, NONE,
};

VCommand holdlist[] =
{
	't', 11, 4, 5, _msg_vote_holdlist1, "", votetitle,
	'c', 4, 5, 6, _msg_vote_holdlist2, "", VTC_doc,
	'i', 5, 6, 7, _msg_vote_holdlist3, "", VTC_candidate,
	'm', 6, 7, 8, _msg_vote_holdlist4, "", votemax,
	'd', 7, 8, 9, _msg_vote_holdlist5, "", VTC_start,
	'n', 8, 9, 10, _msg_vote_holdlist6, "", VTC_end,
	'p', 9, 10, 11, _msg_vote_holdlist7, "", voteip,
	'l', 10, 11, 12, _msg_vote_holdlist8, "", VTC_limit,
	's', 11, 12, 4, _msg_vote_holdlist9, "", VTC_save,
	255, 10, 10, 10, NULL, "", NULL
};

VCommand *vcmds;
BOOL redraw = FALSE;
int order, curpos;
long StartTime, EndTime;
int TotalItem, totalvote;
char choice;
char path[40], dirtname[IDLEN];
char VSrchUserid[IDLEN];
char filename[PATHLEN];		/* general filename buffer */


static int
IsMultiLogin()
{
	if (multi > 1)
	{
		clear();
		outs(_msg_vote_1);
		pressreturn();
		return 1;
	}
	return 0;
}


static void
DispCandidateList(kind)
int kind;
{
	int l = 0;

	clear();
	prints(_msg_vote_2,
	       MENU_TITLE_COLOR,
	       "",
	       (CurBList) ? CurBList->name : _msg_not_choose_board);
	switch (kind)
	{
	case 1:
		msg(_msg_vote_3, MENU_BTITLE_COLOR);
		while (vcmds[l].hkey != 255)
		{
			sprintf(genbuf, "%-32s%-40s", vcmds[l].desc, vcmds[l].context);
			printxy(vcmds[l].row, 8, genbuf);
			l++;
		}
		break;
	case 2:
		msg(_msg_vote_4, MENU_BTITLE_COLOR);
		for (l = 0; l <= TotalItem; l++)
		{
			sprintf(genbuf, _msg_vote_5, l + 1, voteitems[l]);
			printxy(l + 3, 9, genbuf);
		}
		break;
	}
}


#define VOTEHELP1    "vote/VoteHelp1"
#define VOTEHELP2    "vote/VoteHelp2"
#define VOTEHELP3    "vote/VoteHelp3"

int
v_help1()
{
	more(VOTEHELP1, TRUE);
	return M_FULL;
}


int
v_help2()
{
	more(VOTEHELP2, TRUE);
	return M_FULL;
}


int
v_help3()
{
	more(VOTEHELP3, TRUE);
	return M_FULL;
}


static void
inputitem(pos)
int *pos;
{
	if (*pos != 22)
	{
		if (uinfo.mode != EDITVOTE || strcmp(voteitems[*pos - 3], NONE))
		{
			if (getdata(1, 0, _msg_vote_6, genbuf, 31, DOECHO, NULL))
			{
				if (!strcmp(voteitems[*pos - 3], NONE))
					TotalItem++;
				strncpy(voteitems[*pos - 3], genbuf, 30);
			}
			move(1, 0);
			clrtoeol();
		}
	}
	redraw = FALSE;		/* Redraw */
}


static int
IsVoted(filename)
char *filename;
{
	int fd;

	if ((fd = open(filename, O_RDONLY)) > 0)
	{
		while (read(fd, VSrchUserid, IDLEN) == IDLEN)
		{
			if (!strcmp(VSrchUserid, curuser.userid))
			{
				close(fd);
				return 1;
			}
		}
		close(fd);
		return 0;
	}
	return 1;
}


static int
IncreaseBallot(filename)
char *filename;
{
	int fd;
	int BallotCounts = 0;
	struct stat st;
	int newfile = 0;

	if (stat(filename, &st) == 0)
	{
		if (st.st_size == 0)
			newfile = 1;
	}
	if ((fd = open(filename, O_RDWR)) > 0)
	{
		flock(fd, LOCK_EX);
		if (!newfile)
		{
			if (read(fd, &BallotCounts, sizeof(BallotCounts)) == sizeof(BallotCounts))
			{
				if (lseek(fd, 0, SEEK_SET) != -1)
				{
					BallotCounts++;
					if (write(fd, &BallotCounts, sizeof(BallotCounts)) == sizeof(BallotCounts))
					{
						flock(fd, LOCK_UN);
						close(fd);
						return 0;
					}
				}
			}
		}
		else
		{
			if (lseek(fd, 0, SEEK_SET) != -1)
			{
				BallotCounts++;
				if (write(fd, &BallotCounts, sizeof(BallotCounts)) == sizeof(BallotCounts))
				{
					flock(fd, LOCK_UN);
					close(fd);
					return 0;
				}
			}
		}
		flock(fd, LOCK_UN);
		close(fd);
	}
	return -1;
}


static int
SeenVote(filename)
char *filename;
{
	int fd;

	if ((fd = open(filename, O_APPEND | O_CREAT | O_WRONLY, 0600)) > 0)
	{			/* Sign to show you have read */
		if (write(fd, curuser.userid, IDLEN) == IDLEN)
		{
			close(fd);
			CurBList->vote_flag = 0;
			return 0;
		}
		close(fd);
	}
	return -1;
}


static int
CastBallot(filename)
char *filename;
{
	int fd;

	if ((fd = open(filename, O_APPEND | O_CREAT | O_WRONLY, 0600)) > 0)
	{			/* Sign to show you have read */
		if (write(fd, curuser.userid, IDLEN) == IDLEN)
		{
			close(fd);
			return 0;
		}
		close(fd);
	}
	return -1;
}


static int
countvote(pos, vpath)
int pos;
char *vpath;
{
	char filename[PATHLEN];

	if (curlink->vword.MaxTicket <= choice)
	{
		printxy(1, 0, _msg_vote_7, curlink->vword.MaxTicket);
		getkey();
	}
	else
	{
		printxy(1, 0, _msg_vote_8);
		if (igetkey() == 'y')
		{
			sprintf(filename, "%s%s/item%d", vpath, curlink->vword.dirname, pos - 2);
			if (IsVoted(filename))
			{
				move(1, 0);
				clrtoeol();
				return -1;
			}
			CastBallot(filename);

			printxy(pos, 6, _msg_vote_9);
			choice++;

			sprintf(filename, "%s%s/itemcount%d", vpath, curlink->vword.dirname, pos - 2);
			IncreaseBallot(filename);

			sprintf(filename, "%s%s/%s", vpath, curlink->vword.dirname, VOTEMEN);
			if (!IsVoted(filename))
			{
				CastBallot(filename);
				sprintf(filename, "%s%s/countmen", vpath, curlink->vword.dirname);
				IncreaseBallot(filename);
			}
		}
	}
	move(1, 0);
	clrtoeol();
	return -1;
}


static int
checkkey2(pos, cond, vpath)	/* Use to select item */
int *pos;
int cond;
char *vpath;
{
	switch (igetkey())
	{
	case KEY_UP:
	case 'p':
		printxy(*pos, 3, _str_uncurs);
		if (*pos == 3)
			*pos = TotalItem + 3;
		else
			(*pos)--;
		printxy(*pos, 3, _str_cursor);
		break;
	case KEY_DOWN:
	case 'n':
		printxy(*pos, 3, _str_uncurs);
		if (*pos == TotalItem + 3)
			*pos = 3;
		else
			(*pos)++;
		printxy(*pos, 3, _str_cursor);
		break;
	case KEY_RIGHT:
	case '\n':
	case '\r':
		if (cond == 1)
			inputitem(pos);
		if (cond == 2)
			countvote(*pos, vpath);
		break;
	case KEY_LEFT:
		clear();
		return -1;
	case 'd':
		if (cond == 2)
			break;
		if (uinfo.mode == EDITVOTE)
			break;

		if (strcmp(voteitems[*pos - 3], NONE) == 0)
			break;
		TotalItem--;
		bcopy(voteitems[*pos - 2], voteitems[*pos - 3], 31 * (TotalItem - *pos + 4));
		sprintf(genbuf, "%s %d", WRITTEN, TotalItem);
		genbuf[12] = '\0';
		strcpy(vcmds[NC3].context, (TotalItem > 0) ? genbuf : "[None]");
		redraw = FALSE;
		break;
	case 45:
		if (cond == 1)
			inputitem(pos);
		if (cond == 2)
			countvote(*pos, vpath);
		break;
	case 'e':
		clear();
		return -1;
	default:
		break;
	}
	return 0;
}


static int
voteexit()
{
	printxy(2, 0, _msg_vote_10);
	if (igetkey() == 'y')
		return -1;
	move(2, 0);
	clrtoeol();
	return 0;
}


static int
checkkey(pos, cond)
int *pos;
BOOL cond;
{
	int l, key;

	switch ((key = igetkey()))
	{
	case KEY_UP:
	case 'p':
		if (cond == TRUE)
			printxy(*pos, 3, _str_uncurs);
		*pos = vcmds[*pos - 4].prow;
		if (cond == TRUE)
			printxy(*pos, 3, _str_cursor);
		return 0;
	case KEY_DOWN:
	case 'n':
		if (cond == TRUE)
			printxy(*pos, 3, _str_uncurs);
		*pos = vcmds[*pos - 4].nrow;
		if (cond == TRUE)
			printxy(*pos, 3, _str_cursor);
		return 0;
	case KEY_RIGHT:
	case '\n':
	case '\r':
		vcmds[*pos - 4].func();
		move(2, 0);
		clrtoeol();
		redraw = FALSE;
		return 0;
	case KEY_LEFT:
		if (voteexit() == -1)
			return -1;
	default:
		l = 0;
		while (vcmds[l].hkey != 255)
		{
			if (key == vcmds[l].hkey)
			{
				if (cond == TRUE)
					printxy(*pos, 3, _str_uncurs);
				*pos = l + 4;
				if (cond == TRUE)
					printxy(*pos, 3, _str_cursor);
				return 0;
			}
			l++;
		}
		switch (key)
		{
		case 45:
			vcmds[*pos - 4].func();
			move(2, 0);
			clrtoeol();
			redraw = FALSE;
			return 0;
		case 'e':
			if (voteexit() == -1)
				return -1;
		}
	}
	return -1;
}


static void
freelink()
{				/* Free vote link list */
	if (votetop)
	{
		VLink *temp;

		curlink = votetop;

		do
		{
			temp = curlink;
			curlink = curlink->next;
			free(temp);
		}
		while (curlink != NULL);
	}
}

static int
select_ok(pos, vpath)		/* vote select ok , start choose items */
int pos;
char *vpath;
{
	int f;
	int l = 0;
	int position = 3;
	VLink *temp;
	long tmp;

	choice = 0;

	if (strncmp(curlink->vword.AllowIP, uinfo.from, strlen(curlink->vword.AllowIP)) != 0)
	{
		if (strcmp(curlink->vword.AllowIP, "[None]") != 0)
		{
			l = 1;
			sprintf(genbuf, _msg_vote_11, curlink->vword.AllowIP);
		}
	}

	tmp = time(0);		/* check time */
	if (curlink->vword.StartTime > tmp)
	{
		l = 1;
		strcpy(genbuf, _msg_vote_12);
	}
	if (curlink->vword.EndTime < tmp)
	{
		l = 1;
		strcpy(genbuf, _msg_vote_13);
	}
	if (curlink->vword.userlevel > curuser.userlevel)
	{
		l = 1;
		sprintf(genbuf, _msg_vote_14, curlink->vword.userlevel);
	}
	if (l == 1)
	{			/* �����~�T���~���� */
		printxy(2, 0, "[1;37;42m%s[m", genbuf);
		getkey();
		move(2, 0);
		clrtoeol();
		return 0;
	}

	TotalItem = curlink->vword.TotalCandidate;

	sprintf(genbuf, "%s%s/itemlist", vpath, curlink->vword.dirname);
	f = open(genbuf, O_RDONLY);	/* Add check */
	read(f, (void *) voteitems, 31 * TotalItem);

	close(f);

	redraw = FALSE;
	TotalItem--;
	while (1)
	{
		if (!redraw)
		{
			DispCandidateList(2);
			redraw = TRUE;
			printxy(position, 3, _str_cursor);
			/* Show �� */
			for (l = 0; l <= TotalItem; l++)
			{
				sprintf(filename, "%s%s/item%d", vpath, curlink->vword.dirname, l + 1);
				if (IsVoted(filename))
				{
					printxy(l + 3, 6, _msg_vote_9);
					choice++;
				}
			}
		}
		if (checkkey2(&position, 2, vpath) == -1)
			break;
	}

	temp = curlink;
	curlink = scrtop;
	printvote(pos);
	curlink = temp;

	return 0;
}

static int
readresult(pos, vpath)
int pos;
char *vpath;
{
	int f;
	int l;
	int tmp;
	long tp;
	VLink *temp;

	tp = time(0);
	if (tp < curlink->vword.EndTime)
		if (!HAS_PERM(PERM_SYSOP))
		{
			move(2, 0);
			clrtoeol();
			outs(_msg_vote_15);
			getkey();
			move(2, 0);
			clrtoeol();
			return -1;
		}

	clear();

	TotalItem = curlink->vword.TotalCandidate;

	sprintf(genbuf, "%s%s/itemlist", vpath, curlink->vword.dirname);
	l = open(genbuf, O_RDONLY);	/* Add check */
	read(l, (void *) voteitems, 31 * TotalItem);

	close(l);

	prints(_msg_vote_16, MENU_TITLE_COLOR, curlink->vword.title);
	prints(_msg_vote_17);

	for (l = 1; l <= TotalItem; l++)
	{
		sprintf(genbuf, "%s%s/itemcount%d", vpath, curlink->vword.dirname, l);
		tmp = 0;
		if ((f = open(genbuf, O_RDONLY)) != -1)
		{
			read(f, &tmp, sizeof(int));

			close(f);
		}
		prints("     %2d : %7d    %s\n", l, tmp, voteitems[l - 1]);
	}

	sprintf(filename, "%s%s/countmen", vpath, curlink->vword.dirname);
	if ((f = open(filename, O_RDONLY)) > 0)
	{
		read(f, &tmp, sizeof(int));
		close(f);
	}
	move(b_line - 1, 0);
	clrtoeol();
	prints(_msg_vote_18, tmp);
	pressreturn();

	temp = curlink;
	curlink = scrtop;
	printvote(pos);
	curlink = temp;
	return 0;
}


static void
showdata(pos)
int pos;
{
	VLink *temp;
	long tmp;

	clear();
	tmp = time(0);		/* Get time */

	prints(_msg_vote_19,
	       curlink->vword.title,
	       ctime(&curlink->vword.StartTime),
	       ctime(&curlink->vword.EndTime),
	       curlink->vword.AllowIP,
	       curlink->vword.userlevel,
	       curlink->vword.MaxTicket,
	       ctime(&tmp));
	pressreturn();

	temp = curlink;
	curlink = scrtop;
	printvote(pos);
	curlink = temp;
}


static int
checkkey3(pos, func, vpath)	/* ��ܧ벼 */
int *pos;
int (*func) ();
char *vpath;
{
	int l;
	VLink *temp;

	switch (igetkey())
	{
	case KEY_UP:
	case 'p':
		printxy(*pos, 3, _str_uncurs);
		if ((*pos) == 3)
		{
			if (curlink->vword.order != 1)
			{
				*pos = 21;
				for (l = 0; l < 19; l++)
					curlink = curlink->prev;
				printvote(*pos);
			}
		}
		else
		{
			(*pos)--;
			curlink = curlink->prev;
		}
		printxy(*pos, 3, _str_cursor);
		return 0;
	case KEY_DOWN:
	case 'n':
		printxy(*pos, 3, _str_uncurs);
		if ((*pos) == 21)
		{
			if (curlink->vword.order != totalvote)
			{
				*pos = 3;
				curlink = curlink->next;
				printvote(*pos);
				curlink = scrtop;
			}
		}
		else
		{
			if (curlink->vword.order != totalvote)
			{
				(*pos)++;
				curlink = curlink->next;
			}
		}
		printxy(*pos, 3, _str_cursor);
		return 0;
	case KEY_RIGHT:
	case '\n':
	case '\r':
		return func(*pos, vpath);
	case KEY_LEFT:
		return -1;
	case 45:
		return func(*pos, vpath);
	case 'c':
		sprintf(genbuf, "%s%s/votedoc", vpath, curlink->vword.dirname);
		more(genbuf, TRUE);
		temp = curlink;
		curlink = scrtop;
		printvote(*pos);
		curlink = temp;
		return 0;
	case 'r':		/* �ݵ��G */
		readresult(*pos, vpath);
		return 0;
	case 'a':		/* ��ܳ�����T */
		showdata(*pos);
		return 0;
	case 'e':
		return -1;
	default:
		break;
	}
	return 0;
}


static void
printvote(pos)
int pos;
{
	int l = 0;

	clear();

	prints(_msg_vote_20,
	       MENU_TITLE_COLOR,
	       (CurBList) ? CurBList->name : _msg_not_choose_board);

	msg(_msg_vote_21, MENU_BTITLE_COLOR);

	printxy(3, 0, "");
	scrtop = curlink;

	do
	{
		prints("%7s%3d  %s\n", "", curlink->vword.order, curlink->vword.title);
		if (l != 18)
			curlink = curlink->next;
		l++;
	}
	while (l < (SCREEN_SIZE - 4) && curlink != NULL);

	printxy(pos, 3, _str_cursor);
}


static int
del_vote(pos, vpath)
int pos;
char *vpath;
{
	int f;
	voteheader tmp;

	totalvote--;
	if (totalvote == 0)
	{
		myunlink(vpath);	/* lthuang */
	}
	else
	{
		sprintf(genbuf, "%s/.DIR", vpath);
		f = open(genbuf, O_RDWR);
		lseek(f, (long) (totalvote * sizeof(voteheader) + sizeof(int)), SEEK_SET);
		read(f, &tmp, sizeof(voteheader));

		tmp.order = curlink->vword.order;
		lseek(f, 0, SEEK_SET);
		write(f, &totalvote, sizeof(int));
		lseek(f, (long) ((tmp.order - 1) * sizeof(voteheader)), SEEK_CUR);
		write(f, &tmp, sizeof(voteheader));

		close(f);

		sprintf(genbuf, "%s/%s/", vpath, curlink->vword.dirname);
		myunlink(genbuf);
	}
	printxy(2, 0, _msg_vote_22);
	pressreturn();
	return -1;
}


static int
edit_vote(pos, vpath)
int pos;
char *vpath;
{
	int f;
	char temp[80];

	vcmds = &(holdlist[0]);

	strcpy(vcmds[NC1].context, curlink->vword.title);
	sprintf(vcmds[NC4].context, "%d", curlink->vword.MaxTicket);
	strcpy(vcmds[NC7].context, curlink->vword.AllowIP);
	strcpy(vcmds[NC5].context, ctime(&curlink->vword.StartTime));
	strcpy(vcmds[NC6].context, ctime(&curlink->vword.EndTime));
	sprintf(vcmds[NC9].context, "%d", curlink->vword.userlevel);
	sprintf(vcmds[NC3].context, "%s %d", WRITTEN, curlink->vword.TotalCandidate);
	strcpy(vcmds[NC2].context, "[None]");

	sprintf(genbuf, "%s%s/votedoc", vpath, curlink->vword.dirname);
	if ((f = open(genbuf, O_RDONLY)) != -1)
	{
		strcpy(vcmds[NC2].context, WRITTEN);
		sprintf(genbuf, "%s%s/votedoc", vpath, curlink->vword.dirname);
		sprintf(temp, "tmp/%svotedoc", curuser.userid);
		mycp(genbuf, temp);
		close(f);
	}

	TotalItem = curlink->vword.TotalCandidate;

	sprintf(genbuf, "%s%s/itemlist", vpath, curlink->vword.dirname);
	f = open(genbuf, O_RDONLY);	/* Add check */
	read(f, (void *) voteitems, 31 * TotalItem);

	close(f);

	StartTime = curlink->vword.StartTime;
	EndTime = curlink->vword.EndTime;
	order = curlink->vword.order;
	strcpy(dirtname, curlink->vword.dirname);
	return -1;
}


static int
vote_choose(vpath)
char vpath[];
{
	int f;
	int pos = 3;
	VLink *temp = NULL;
	int l;

	clear();
	order = 0;

	sprintf(genbuf, "%s.DIR", vpath);	/* BOARDVOTE or SYSVOTE */
	if ((f = open(genbuf, O_RDONLY)) == -1)
	{
		outs(_msg_vote_23);
		pressreturn();
		redraw = FALSE;
		return -1;
	}
/* Create Link List */
	read(f, &totalvote, sizeof(int));
	curlink = (VLink *) malloc(sizeof(VLink));

	votetop = curlink;
	votetop->prev = NULL;
	votetop->next = NULL;
	for (l = 0; l < totalvote; l++)
	{
		if (curlink == NULL)
		{
			curlink = (VLink *) malloc(sizeof(VLink));

			curlink->prev = NULL;
			curlink->next = NULL;
			temp->next = curlink;
		}
		curlink->prev = temp;
		read(f, &curlink->vword, sizeof(voteheader));

		temp = curlink;
		curlink = curlink->next;
	}
	close(f);

	sprintf(filename, "%s/%s", vpath, VOTENEW);
	if (!IsVoted(filename))
		SeenVote(filename);

	curlink = votetop;
	printvote(pos);
	curlink = votetop;

/* Condition check */

	switch (uinfo.mode)
	{
	case DELVOTE:
		while (1)
		{
			printxy(1, 0, _msg_vote_24, curlink->vword.title);
			if (checkkey3(&pos, del_vote, vpath) == -1)
				break;
		}
		return -1;	/* �R���벼�S�� */
	case EDITVOTE:
		while (1)
		{
			printxy(1, 0, _msg_vote_24, curlink->vword.title);
			if (checkkey3(&pos, edit_vote, vpath) == -1)
				break;
		}
		break;
	default:
		while (1)
		{
			printxy(1, 0, _msg_vote_24, curlink->vword.title);
			if (checkkey3(&pos, select_ok, vpath) == -1)
				break;
		}
		break;
	}

	redraw = FALSE;
	freelink();		/* free vote tree */
	if (uinfo.mode == EDITVOTE && order == 0)
		return -1;
	return 0;
}

#define CONTAINS 	8

int
v_hold()
{
	int f;
	char *listcon[CONTAINS] =
	{			/* �|��벼����� */
		"[None]",
		"[None]",
		"[None]",
		"1",
		"[None]",
		"[None]",
		"[None]",
		"0"
	};

	redraw = FALSE;		/* init */

	vcmds = &(holdlist[0]);
	StartTime = 0;
	EndTime = 0;
	strcpy(dirtname, "");

	for (curpos = 0; curpos < CONTAINS; curpos++)
		strcpy(vcmds[curpos].context, listcon[curpos]);
	for (curpos = 0; curpos < MAXITEM; curpos++)
		strcpy(voteitems[curpos], NONE);

	TotalItem = 0;
	curpos = 4;
	sprintf(genbuf, "tmp/%svotedoc", curuser.userid);	/* delete doc */
	myunlink(genbuf);

	if (HAS_PERM(PERM_SYSOP))
	{			/* system mananger */
		move(1, 0);
		clrtoeol();
		outs(_msg_vote_25);
		if (igetkey() != 'n')
		{
			save_in_board = in_board;
			in_board = TRUE;
			Boards('0');
			in_board = save_in_board;
			sprintf(genbuf, "%s%s/", BOARDVOTE, CurBList->name);
			strncpy(path, genbuf, 39);	/* Path */
			sprintf(vcmds[NC9].context, "%d",
				(CurBList) ? CurBList->level : 1);	/* This is the answer above */
		}
		else
			strcpy(path, SYSVOTE);
	}
	else
	{
		if (curuser.userlevel < PERM_BM)
			return (M_FULL | R_FULL);
		if (!CurBList || strcmp(curuser.userid, CurBList->owner) != 0)
		{
			printxy(2, 0, _msg_vote_26);
			getkey();
			return M_FULL;
		}
		sprintf(genbuf, "%s%s/", BOARDVOTE, CurBList->name);
		strncpy(path, genbuf, 39);	/* Path */
	}

	sprintf(genbuf, "%s.DIR", path);
	if ((f = open(genbuf, O_RDONLY)) != -1)
	{
		read(f, &totalvote, sizeof(int));

		totalvote++;
		close(f);
	}
	else
		totalvote = 1;

	while (1)
	{
		if (!redraw)
		{
			DispCandidateList(1);
			redraw = TRUE;
			printxy(curpos, 3, _str_cursor);
		}
		move(1, 0);
		clrtoeol();
		prints(_msg_vote_24, vcmds[curpos - 4].desc);
		if (checkkey(&curpos, TRUE) == -1)
			break;
	}
	return M_FULL;
}


int
v_edit()
{
	int f;
	int curpos = 4;

	for (f = 0; f < MAXITEM; f++)
		strcpy(voteitems[f], NONE);

	if (HAS_PERM(PERM_SYSOP))
	{
		if (uinfo.mode < VOTING)
			return M_FULL;
		move(1, 0);
		clrtoeol();
		outs(_msg_vote_27);
		if (igetkey() == 'y')
		{
			save_in_board = in_board;
			in_board = TRUE;			
			Boards('0');
			in_board = save_in_board;
			sprintf(genbuf, "%s%s/", BOARDVOTE, CurBList->name);
			strncpy(path, genbuf, 39);	/* Path */
			if (vote_choose(path) == -1)
				return M_FULL;
		}
		else
		{
			strcpy(path, SYSVOTE);
			if (vote_choose(SYSVOTE) == -1)
				return M_FULL;
		}
	}
	else
	{			/* Board Manager */
		if (curuser.userlevel < PERM_BM)
			return M_FULL;
		if (!CurBList || strcmp(curuser.userid, CurBList->owner) != 0)
		{
			printxy(2, 0, _msg_vote_26);
			getkey();
			return M_FULL;
		}
		sprintf(genbuf, "%s%s/", BOARDVOTE, CurBList->name);
		strncpy(path, genbuf, 39);	/* Path */
		if (vote_choose(path) == -1)
			return M_FULL;
	}

	redraw = FALSE;		/* init */
	vcmds = &(holdlist[0]);

	while (1)
	{
		if (!redraw)
		{
			DispCandidateList(1);
			redraw = TRUE;
			printxy(curpos, 3, _str_cursor);
		}
		move(1, 0);
		clrtoeol();
		prints(_msg_vote_24, vcmds[curpos - 4].desc);
		if (checkkey(&curpos, TRUE) == -1)
			break;
	}

	return M_FULL;
}


int
v_board()
{				/* �O�벼 */
#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return (M_FULL | R_FULL);
#endif
	if (IsMultiLogin())
		return (M_FULL | R_FULL);

	if (uinfo.mode == VOTING)
	{
		save_in_board = in_board;
		in_board = TRUE;		
		Boards('0');
		in_board = save_in_board;
	}
	sprintf(genbuf, "%s%s/", BOARDVOTE, CurBList->name);
	strncpy(path, genbuf, 39);	/* Path */

	vote_choose(path);

	return (M_FULL | R_FULL);
}


static int
votetitle()
{
	getdata(2, 0, _msg_vote_28, genbuf, VLEN, DOECHO, NULL);
	printxy(2, 0, "%-80s", "");	/* clean */
	if (genbuf[0] == '\0')
		return -1;
	strncpy(vcmds[NC1].context, genbuf, VLEN);
	return 0;
}


static int
voteip()
{
	getdata(2, 0, _msg_vote_29, genbuf, VLEN, ECHONOSP, NULL);
	printxy(2, 0, "%-80s", "");
	if (genbuf[0] == '\0')
		strcpy(genbuf, "[None]");
	strncpy(vcmds[NC7].context, genbuf, VLEN);
	return 0;
}


static int
votemax()
{
	getdata(2, 0, _msg_vote_30, genbuf, VLEN, ECHONOSP, NULL);
	printxy(2, 0, "%-80s", "");
	if (genbuf[0] == '\0')
		return -1;
	if (atoi(genbuf) < 1)
		strcpy(genbuf, "1");
	strncpy(vcmds[NC4].context, genbuf, VLEN);
	return 0;
}


static void
save_doc(vpath)
char *vpath;
{
	int f;
	char temp[80];

	sprintf(genbuf, "tmp/%svotedoc", curuser.userid);
	if ((f = open(genbuf, O_RDONLY)) != -1)
	{
		close(f);
		sprintf(genbuf, "tmp/%svotedoc", curuser.userid);
		sprintf(temp, "%s/votedoc", vpath);
		mycp(genbuf, temp);
	}
}


static int
fill_data(tmp)
voteheader *tmp;
{
	tmp->order = totalvote;
	tmp->StartTime = StartTime;
	tmp->EndTime = EndTime;
	strcpy(tmp->title, vcmds[NC1].context);
	strcpy(tmp->AllowIP, vcmds[NC7].context);
	tmp->userlevel = atoi(vcmds[NC9].context);
	tmp->MaxTicket = atoi(vcmds[NC4].context);
	tmp->TotalCandidate = TotalItem;
}


static int
VTC_save()
{
	int f, f2;
	int l = 0;		/* Loop (error check) */
	char itemdir[32];
	voteheader tmp;

/* check if complete */
	if (TotalItem < 2)
	{
		l = 1;
		outs(_msg_vote_31);
	}

	if (StartTime == 0 || EndTime == 0)
	{
		l = 1;
		outs(_msg_vote_32);
	}

	if (strcmp(vcmds[NC1].context, "[None]") == 0)
	{
		l = 1;
		outs(_msg_vote_33);
	}

	if (l == 1)
	{
		move(2, 0);
		clrtoeol();
		outs(_msg_vote_34);
		getkey();
		return;
	}

	if (!dashd(path))
	{
		if (mkdir(path, 0700) == -1)
			return -1;
	}
	sprintf(genbuf, "%s.DIR", path);
	if ((f = open(genbuf, O_CREAT | O_RDWR, 0600)) == -1)
		return -1;
	if (uinfo.mode == ADDVOTE)
	{

		write(f, &totalvote, sizeof(int));

		fill_data(&tmp);

		if (dirtname[0] == '\0')
		{
			do
			{
				sprintf(dirtname, "M.%d", time(0));
				sprintf(itemdir, "%s%s", path, dirtname);
			}
			while (mkdir(itemdir, 0700) != 0);

			sprintf(filename, "%s/%s", itemdir, VOTEMEN);	/* Use for Count People */
			if ((f2 = open(filename, O_CREAT | O_TRUNC, 0600)) > 0)
			{
				close(f2);
			}
			sprintf(filename, "%s/%s", path, VOTENEW);	/* Use New Vote */
			if ((f2 = open(filename, O_CREAT | O_TRUNC, 0600)) > 0)
			{
				close(f2);
			}
			sprintf(filename, "%s/countmen", itemdir);
			if ((f2 = open(filename, O_CREAT | O_TRUNC, 0600)) > 0)
			{
				close(f2);
			}
		}
		else
			sprintf(itemdir, "%s%s", path, dirtname);

		for (l = 1; l <= TotalItem; l++)
		{		/* Save Items to Disk */
			sprintf(filename, "%s/item%d", itemdir, l);
			if ((f2 = open(filename, O_CREAT | O_TRUNC, 0600)) > 0)		/* add check */
				close(f2);
			sprintf(filename, "%s/itemcount%d", itemdir, l);
			if ((f2 = open(filename, O_CREAT | O_TRUNC, 0600)) > 0)		/* add check */
				close(f2);
		}

		sprintf(genbuf, "%s/itemlist", itemdir);
		f2 = open(genbuf, O_CREAT | O_WRONLY, 0600);	/* add check */
		write(f2, voteitems, 31 * TotalItem);

		close(f2);

		strcpy(tmp.dirname, dirtname);
		lseek(f, (long) (sizeof(tmp) * (tmp.order - 1)), SEEK_CUR);	/* Write Vote Data chang */
		write(f, &tmp, sizeof(voteheader));

		close(f);

		save_doc(itemdir);
	}
	else
	{			/* Edit Vote Save ( Writed in this way is
				   more clear ) */

		fill_data(&tmp);

		strcpy(tmp.dirname, dirtname);
		lseek(f, (long) (sizeof(tmp) * (order - 1) + sizeof(int)), SEEK_SET);
		write(f, &tmp, sizeof(voteheader));

		close(f);

		sprintf(genbuf, "%s%s/itemlist", path, dirtname);
		f2 = open(genbuf, O_WRONLY);	/* add check */
		write(f2, voteitems, 31 * TotalItem);

		close(f2);

		sprintf(itemdir, "%s%s", path, dirtname);
		save_doc(itemdir);
	}

	move(2, 0);
	clrtoeol();
	outs(_msg_vote_35);
	getkey();
	CurBList->vote_flag = 1;
	return;
}


int
v_boardhold()
{
	if (curuser.userlevel >= PERM_BM)
	{
		uinfo.mode = ADDVOTE;
		v_hold();
		uinfo.mode = READING;
	}
	return R_FULL;
}


static int
VTC_limit()
{
	if (getdata(2, 0, _msg_vote_36, genbuf, VLEN, ECHONOSP, NULL))
		strncpy(vcmds[NC9].context, genbuf, VLEN);
	return;
}


static int
VTC_start()
{
	int day;
	time_t now = time(0);
	
	getdata(2, 0, _msg_vote_37, genbuf, 4, DOECHO, NULL);
	if (genbuf[0] != '\0' && (day = atol(genbuf)) > 0)
		StartTime = now + day * 86400;	
	else
		StartTime = now;
	strncpy(vcmds[NC5].context, ctime(&StartTime), VLEN);
	return 0;
}


static int
VTC_end()
{
	int day;
	time_t now = time(0);

	getdata(2, 0, _msg_vote_38, genbuf, 4, DOECHO, NULL);
	if (genbuf[0] != '\0' && (day = atol(genbuf)) > 0)
	{
		EndTime = now + day * 86400;	
		strncpy(vcmds[NC6].context, ctime(&EndTime), VLEN);			
		return 0;
	}
	return -1;
}


static int
VTC_doc()
{
	char fn_votedoc[PATHLEN];


	sprintf(fn_votedoc, "tmp/%s.votedoc", curuser.userid);
	if (vedit(fn_votedoc, NULL) != -1)
		strncpy(vcmds[NC2].context, WRITTEN, 8);
	return;
}


int
v_delete()			/* �R�� */
{
	if (HAS_PERM(PERM_SYSOP))
	{
		move(2, 0);
		clrtoeol();
		outs(_msg_vote_39);
		if (igetkey() == 'y')
		{
			save_in_board = in_board;
			in_board = TRUE;			
			Boards('0');
			in_board = save_in_board;
			sprintf(genbuf, "%s%s/", BOARDVOTE, CurBList->name);
		}
		else
		{
			sprintf(genbuf, "%s", SYSVOTE);
		}
		strncpy(path, genbuf, 39);	/* Path */

	}
	else
	{			/* Board Manager */
		if (!CurBList || strcmp(curuser.userid, CurBList->owner))
		{
			printxy(2, 0, _msg_vote_26);
			getkey();
			return M_FULL;
		}
		sprintf(genbuf, "%s%s/", BOARDVOTE, CurBList->name);
		strncpy(path, genbuf, 39);	/* Path */
	}
	vote_choose(path);
	return M_FULL;
}


int
v_system()			/* �t�Χ벼 */
{
#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return M_FULL;
#endif

	if (!IsMultiLogin())
		vote_choose(SYSVOTE);
	return M_FULL;
}


static int
VTC_candidate()
{
	int pos;

	pos = 3;
	redraw = FALSE;

	do
	{
		if (!redraw)
		{
			DispCandidateList(2);
			redraw = TRUE;
			PUTCURS(pos);
		}
	}
	while (checkkey2(&pos, 1, path) != -1);

	if (TotalItem > 0)
	{
		sprintf(genbuf, "%s %d", WRITTEN, TotalItem);
		strncpy(vcmds[NC3].context, genbuf, 12);
	}
	return;
}


int
UnSeenVote(vpath)
char *vpath;
{
	int fd;
	char fname[PATHLEN];

	sprintf(fname, "%s/%s", vpath, VOTENEW);
	if ((fd = open(fname, O_RDONLY)) < 0)
		return 0;
	while (read(fd, &fname, IDLEN) == IDLEN)
	{
		if (!strncmp(fname, curuser.userid, IDLEN))	/* -ToDo- uid */
		{
			close(fd);
			return 0;
		}
	}
	close(fd);
	return 1;
}


void
CheckNewSysVote()
{
	static BOOL sysvote_flag = FALSE;

	if (!sysvote_flag)	/* ? */
	{
		if (UnSeenVote(SYSVOTE))
			sysvote_flag = TRUE;
	}
	if (sysvote_flag)
		more(NEWVOTEMSG, TRUE);
}


void
DisplayNewVoteMesg()
{
	more(NEWVOTEMSG, TRUE);
}


void
SetVotePath(path_buf, bname)
char path_buf[], bname[];
{
	sprintf(path_buf, "%s/%s/", BOARDVOTE, bname);
}


int
inVoting()
{
	if (uinfo.mode >= VOTING && uinfo.mode <= ADDVOTE)
		return 1;
	return 0;
}

#endif /* USE_VOTE */
