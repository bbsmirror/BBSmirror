/*
   Li-te Huang, lthuang@cc.nsysu.edu.tw, 03/10/98
   This file was derived from MapleBBS's, powerful talk menu.
*/   

#include "bbs.h"
#include "tsbbs.h"

struct pickup
{
	USER_INFO *ui;
	short friend;
	time_t mtime;
};

#define PICKUP_WAYS     (5)

int friends_number = 0;
int p_lines = 20;
BOOL refscreen = FALSE;

short pickup_way = 0;

char *fcolor[] = {"", "[1;36m", "[1;33m", "[1;37m"};

BOOL list_friend = FALSE;
BOOL friend_mode = FALSE;

extern struct UTMPFILE *utmpshm;


int
my_send(userid)			/* mail to someone */
char *userid;
{
	char to[STRLEN], title[TTLEN];
	int result;

	clear();

	strcpy(to, userid);
	title[0] = '\0';

	/* fn_src: NULL, postpath: NULL, mail_ok: TRUE, post_ok: FALSE */
	result = PrepareMailPost(NULL, to, title, NULL, TRUE, FALSE);
	move(b_line - 1, 0);
	clrtoeol();
	if (result != 0)
		outs(_msg_list_1);
	else
		outs(_msg_list_2);
	pressreturn();
	return 0;
}



void
t_showhelp()
{
	clear();
	outs(_msg_list_6);
	if (curuser.userlevel > PERM_PAGE || curuser.ident == 7)
		outs(_msg_list_7);
	if (HAS_PERM(PERM_SYSOP))
		outs(_msg_list_8);
	pressreturn();;
}


void
str_lower(t, s)
char *t, *s;
{
	register unsigned char ch;

	do
	{
		ch = *s++;
		*t++ = tolower(ch);
	}
	while (ch);
}


int
strstr_lower(str, tag)
char *str, *tag;		/* tag : lower-case string */
{
	char buf[STRLEN];

	str_lower(buf, str);
	return (int) strstr(buf, tag);
}


static int
pickup_cmp(i, j)
struct pickup *i, *j;
{
	switch (pickup_way)
	{
	case 1:
		{
			register int friend;

			if (friend = j->friend - i->friend)
				return friend;
		}
	case 2:
		return strcasecmp(i->ui->userid, j->ui->userid);
	case 3:
		return (i->ui->mode - j->ui->mode);
	case 4:
		return strcasecmp(i->ui->from, j->ui->from);
	}
}


#define	US_PICKUP	1234
#define	US_RESORT	1233
#define	US_ACTION	1232
#define	US_REDRAW	1231

void
pickup_user()
{
	static int num = 0;

	register USER_INFO *uentp;
	register int state = US_PICKUP, ch;
	register int actor, head, foot;
	register int tmp;	/* lthuang */
/* 
	time_t freshtime;
*/	
	struct pickup pklist[USHM_SIZE];
	char pagerchar[] = "* O ";
	char *msg_pickup_way[PICKUP_WAYS] =
	{
		_msg_pickup_way_1,
		_msg_pickup_way_2,
		_msg_pickup_way_3,
		_msg_pickup_way_4,
		_msg_pickup_way_5
	};
	BOOL save_list_friend = list_friend;
	int rval;
	time_t now;


	if (friend_mode)
		list_friend = TRUE;

	while (1)
	{
		if (state == US_PICKUP)
/*		
			freshtime = 0;

		if (utmpshm->mtime > freshtime)
*/		
		{
/*		
			time(&freshtime);
*/			
			friends_number = actor = ch = foot = 0;

			time(&now);
			while (ch < USHM_SIZE)
			{
				uentp = &(utmpshm->uinfo[ch++]);
				if (uentp->pid > 2 && uentp->userid[0])
				{
					if (!HAS_PERM(PERM_CLOAK) && uentp->invisible)
						continue;
					tmp = MyFriend(uentp->userid);
					if (tmp)
						friends_number++;
					else if (!tmp && list_friend)
						continue;
					pklist[actor].friend = tmp;
					pklist[actor].ui = uentp;
					pklist[actor].mtime = now;
/*                                      
   pklist[actor].friend |= (can_override(uentp->userid, curuser.userid) ? 2 : 0);
 */
					actor++;
				}
			}

			state = US_PICKUP;
			if (!actor)
			{
				if (friend_mode)
				{
					move(3, 0);
					clrtobot();
					outs(_msg_list_10);
					pressreturn();
					list_friend = save_list_friend;
				}
				else if (list_friend)
				{
					getdata(b_line, 0, _msg_list_11, genbuf, 2, ECHONOSP|LOWCASE, NULL);
					if (genbuf[0] != 'n')
					{
						list_friend = FALSE;
						continue;
					}
				}
				return;
			}
		}
		
		if (pickup_way > 0 && state >= US_RESORT)	/* lthuang */
			qsort(pklist, actor, sizeof(struct pickup), pickup_cmp);

		if (state >= US_ACTION)
		{
			clear();
			prints(_msg_list_5, MENU_TITLE_COLOR, 
			       list_friend ? _msg_list_12 : _msg_list_13,
			       check_newmail(curuser.userid) ? _msg_you_have_mail : BBSNAME,
	    		   (uinfo.pager) ? _msg_on : _msg_off);
			prints(_msg_list_14,
			       msg_pickup_way[pickup_way], curuser.userid,
			       actor, friends_number,
			       _msg_list_16, _msg_list_17,
			       HAS_PERM(PERM_CLOAK) ? 'C' : ' ',
			       _msg_list_18);
		}
		else
		{
			move(3, 0);
			clrtobot();
		}

		if (num < 0)
			num = 0;
		else if (num >= actor)
			num = actor - 1;

		head = (num / p_lines) * p_lines;
		foot = head + p_lines;
		if (foot > actor)
			foot = actor;

		time(&now);
		for (ch = head; ch < foot; ch++)
		{
			uentp = pklist[ch].ui;
/*			
			if (!uentp->pid)
			{
				state = US_PICKUP;
				break;
			}
*/

			if (uentp->userid[0] && uentp->pid > 2)
			{
				if (pklist[ch].friend && uentp->login_time > pklist[ch].mtime)
				{
					if (!HAS_PERM(PERM_CLOAK) && uentp->invisible)
						continue;
					tmp = MyFriend(uentp->userid);
					if (!tmp)
					{
						friends_number--;
						if (list_friend)
							continue;
						pklist[ch].friend = tmp;
						pklist[ch].mtime = now;
					}
				}	
				
				state = pklist[ch].friend;	/* lthuang */			
				prints("  %5d %s%-13s%-20.19s[m%-16.16s %c%c %-17.17s\n",
				       ch + 1,
				       fcolor[state], uentp->userid,
				       uentp->username,
				       uentp->from,
				       (uentp->invisible ? 'C' : ' '),
				       pagerchar[(state & 2) | (uentp->pager)],
				       modestring(uentp, 1));
			}
			else
				prints("  %5d %s\n", ch + 1, _msg_list_19);
		}

		if (state == US_PICKUP)
			continue;

		move(b_line, 0);
		prints(_msg_list_20, MENU_BTITLE_COLOR);

		state = 0;
		while (!state)
		{
			move(num + 3 - head, 0);
			outs(_str_cursor);
			move(num + 3 - head, 2);

			while (1)
			{
				rval = igetkey();
				if (talkrequest)
				{
					talkreply();
					refscreen = TRUE;	/* lthuang */
					ch = rval;
					break;
				}
				if (writerequest)
				{
					writereply();
					refscreen = TRUE;	/* lthuang */
					ch = rval;
					break;
				}

				if (rval != CTRL('L'))
				{
					ch = rval;
					break;
				}
				redoscr();
			}

			move(num + 3 - head, 0);
			outs(_str_uncurs);

			if (refscreen)	/* lthuang */
			{
				state = US_REDRAW;
				refscreen = FALSE;
				continue;
			}
			switch (ch)
			{
			case KEY_LEFT:
			case 'e':
				if (friend_mode)
					list_friend = save_list_friend;
				return;
			case TAB:
				if (getdata(b_line, 0, _msg_list_4, genbuf, 2, ECHONOSP, NULL))
				{
					tmp  = atoi(genbuf);
					if (tmp > 0 && tmp < PICKUP_WAYS)
					{
						pickup_way = tmp;
						state = US_RESORT;
						num = 0;
					}
				}
				break;
			case KEY_DOWN:
			case 'n':
				if (++num < actor)
				{
					if (num >= foot)
						state = US_REDRAW;
					break;
				}

			case '^':
			case KEY_HOME:
				num = 0;
				if (head)
					state = US_REDRAW;
				break;
			case ' ':
			case KEY_PGDN:
			case CTRL('F'):
				if (foot < actor)
				{
					num += p_lines;
					state = US_REDRAW;
				}
				else if (head)
				{
					num = 0;
					state = US_REDRAW;
				}
				break;
			case KEY_UP:
			case 'p':
				if (--num < head)
				{
					if (num < 0)
					{
						num = actor - 1;
						if (actor == foot)
							break;
					}
					state = US_REDRAW;
				}
				break;
			case KEY_PGUP:
			case CTRL('B'):
				if (head)
				{
					num -= p_lines;
					state = US_REDRAW;
					break;
				}

			case KEY_END:
			case '$':
				num = actor - 1;
				if (foot < actor)
					state = US_REDRAW;
				break;
			case CTRL('P'):
				uinfo.pager = (uinfo.pager) ? FALSE : TRUE;
				update_ulist(cutmp, &uinfo);
				state = US_ACTION;
				break;
			case '/':
				getdata(b_line, 0, _msg_list_9, genbuf, 20, DOECHO, NULL);
				move(b_line, 0);
				clrtoeol();

				if (genbuf[0])
				{
					int n = (num + 1) % actor;

					str_lower(genbuf, genbuf);
					while (n != num)
					{
						if (strstr_lower(pklist[n].ui->userid, genbuf))
						{
							num = n;
							break;
						}
						if (strstr_lower(pklist[n].ui->from, genbuf))
						{
							num = n;
							break;
						}
						if (++n >= actor)
							n = 0;
					}
				}
				state = US_REDRAW;
				break;
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
				genbuf[0] = ch;
				genbuf[1] = '\0';
				if (getdata(b_line, 0, _msg_to_nth, genbuf, 5, ECHONOSP, genbuf))
				{
					tmp = atoi(genbuf) - 1;
					if (tmp >= 0 && tmp < actor)
						num = tmp;
				}
				state = US_REDRAW;
				break;
			case 'k':	
				if (HAS_PERM(PERM_SYSOP))
				{
					uentp = pklist[num].ui;	
					state = US_ACTION;
					if (uentp->userid[0] 
					    && uentp->pid > 2 && kill(uentp->pid, 0) != -1)
					{
						if (uentp->userid[0] != '\0'
						    && strcmp(uentp->userid, curuser.userid))
						{
							if (uentp->pid > 2)
								kill(uentp->pid, SIGKILL);
							/* do not write back user data */
							purge_ulist(uentp);
							log_usies("KICK", "'%s'", uentp->userid);					
							state = US_PICKUP;
						}
					}
				}
				break;
			case 'h':
				state = US_ACTION;
				t_showhelp();				
				break;		
			case 'q':
			case '\r':
			case '\n':
			case KEY_RIGHT:
				state = US_ACTION;				
				uentp = pklist[num].ui;
				if (uentp->userid[0])
					QueryUser(uentp->userid);
				break;
			case CTRL('R'):
			case 'l':
				ReplyLastCall();
				state = US_REDRAW;
				break;
			case 's':	/* refresh user state */
				state = US_PICKUP;
				break;
			case 'a':
				if (curuser.userlevel)		/* guest �u�� query */
				{
					uentp = pklist[num].ui;				
					if (uentp->userid[0])
					{
						friend_add(uentp->userid);
						friends_number++;
						load_friend_cache();
						pklist[num].friend = 1;
						state = US_ACTION;
					}
				}
				break;				
			case 'd':
				if (curuser.userlevel)		/* guest �u�� query */
				{
					uentp = pklist[num].ui;			
					if (uentp->userid[0])
					{
						friend_delete(uentp->userid);
						friends_number--;
						load_friend_cache();
						pklist[num].friend = 0;						
						state = US_ACTION;						
					}
				}
				break;
			case 'f':
				if (curuser.userlevel)		/* guest �u�� query */
				{
					list_friend = (list_friend) ? FALSE : TRUE;
					state = US_PICKUP;
				}
				break;			
			case 'm':
				if (curuser.userlevel)		/* guest �u�� query */			
				{
					uentp = pklist[num].ui;
					if (uentp->userid[0])
					{
						state = US_ACTION;				
						my_send(uentp->userid);	
					}
				}
				break;
			case 'x':	/* Xshadow : for read mail hot key */
				if (curuser.userlevel)
				{
					state = US_ACTION;								
					m_read();				
				}
				break;
			case 't':
			case 'w':
			case 'b':
				if (!curuser.userlevel)		/* guest �u�� query */
					break;
				if (curuser.userlevel < PERM_PAGE && curuser.ident != 7)
				{
					msg(_msg_list_21);
					getkey();
					state = US_REDRAW;
					continue;
				}
				if (ch == 'w')
				{
					uentp = pklist[num].ui;	
					if (uentp->userid[0])
					{
						if (PrepareMesgContent(uentp->userid) == 0)
							SendMesgToSomeone(uentp->userid);
						state = US_REDRAW;
					}
				}
				else if (ch == 't')
				{
					uentp = pklist[num].ui;
					if (uentp->userid[0])
					{
						state = US_ACTION;
						if (strcmp(uentp->userid, curuser.userid))
						{
							talk_user(uentp);
							state = US_PICKUP;
						}
					}
				}
				else if (ch == 'b')
				{
					t_fsendmsg();
					state = US_REDRAW;
				}
				break;
			} /* switch */
		} /* while */
	} /* while */
}


int
t_list()
{
	pickup_user();
	return M_FULL;
}


int
t_friends()
{
	friend_mode = TRUE;
	pickup_user();
	friend_mode = FALSE;
	return M_FULL;
}
