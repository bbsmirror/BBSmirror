
#include "bbs.h"
#include "tsbbs.h"
#include <pwd.h>
#include <varargs.h>
#include <sys/wait.h>


void
pressreturn()
{
	move(b_line, 0);
	clrtoeol();
	outs(_msg_press_enter);
	getkey();
}


#define LOOKFIRST  (0)
#define LOOKLAST   (1)
#define QUOTEMODE  (2)
#define MAXCOMSZ   (1024)
#define MAXARGS    (40)
#define MAXENVS    (20)
#define BINDIR "bin/"		/* lthuang */

char *bbsenv[MAXENVS];
int numbbsenvs = 0;

bbssetenv(env, val)
char *env, *val;
{
	register int i, len;

	if (numbbsenvs == 0)
		bbsenv[0] = NULL;
	len = strlen(env);
	for (i = 0; bbsenv[i]; i++)
		if (!strncasecmp(env, bbsenv[i], len))
			break;
	if (i >= MAXENVS)
		return -1;
	if (bbsenv[i])
		free(bbsenv[i]);
	else
		bbsenv[++numbbsenvs] = NULL;
	bbsenv[i] = (char *) malloc(strlen(env) + strlen(val) + 2);
	if (!bbsenv[i])		/* lthuang */
		return -1;
	strcpy(bbsenv[i], env);
	strcat(bbsenv[i], "=");
	strcat(bbsenv[i], val);
	return 0;
}

pid_t child_pid;

#ifndef MAXPATHLEN
#define MAXPATHLEN 	(256)
#endif

int
do_exec(com, wd)
char *com, *wd;
{
	char path[MAXPATHLEN];
	char pcom[MAXCOMSZ];
	char *arglist[MAXARGS];
	register int i, len;
	register int argptr;
	pid_t pid;
	int pmode;
	void (*isig) (), (*qsig) ();
	struct passwd *passid;

#if defined(SYSV) || defined(LINUX) || defined(BSD44)
	int status;

#else
	union wait status;

#endif

	passid = getpwuid(BBS_UID);
	strncpy(path, BINDIR, MAXPATHLEN);
	strncpy(pcom, com, MAXCOMSZ);
	len = MIN(strlen(com) + 1, MAXCOMSZ);
	pmode = LOOKFIRST;
	for (i = 0, argptr = 0; i < len; i++)
	{
		if (pcom[i] == '\0')
			break;
		if (pmode == QUOTEMODE)
		{
/* del by lthuang                
   if (pcom[i] == '\001')
 */
			if (pcom[i] == '"')
			{
				pmode = LOOKFIRST;
				pcom[i] = '\0';
				continue;
			}
			continue;
		}
/* del by lthuang                
   if (pcom[i] == '\001')
 */
		if (pcom[i] == '"')
		{
			pmode = QUOTEMODE;
			arglist[argptr++] = &pcom[i + 1];
			if (argptr + 1 == MAXARGS)
				break;
			continue;
		}
		if (pmode == LOOKFIRST)
			if (!isspace(pcom[i]))
			{
				arglist[argptr++] = &pcom[i];
				if (argptr + 1 == MAXARGS)
					break;
				pmode = LOOKLAST;

			}
			else
				continue;
		if (isspace(pcom[i]))
		{
			pmode = LOOKFIRST;
			pcom[i] = '\0';
		}
	}
	arglist[argptr] = NULL;
	if (argptr == 0)
		return -1;
	if (*arglist[0] == '/')
		strncpy(path, arglist[0], MAXPATHLEN);
	else
		strncat(path, arglist[0], MAXPATHLEN);
	reset_tty();
	if ((pid = fork()) == 0)
	{
		if (wd)
			if (chdir(wd))
			{
				fprintf(stderr, "Unable to chdir to '%s'\n", wd);
				exit(-1);
			}
/*---
	bbssetenv("PATH", "/bin:/usr/lib:/etc:/usr/ucb:/usr/local/bin:/usr/local/lib:.");
*/
		bbssetenv("PATH", "/bin:/usr/lib:/etc:/usr/ucb:/usr/local/bin:/usr/local/lib");
		bbssetenv("TERM", "vt100");
		bbssetenv("USER", passid->pw_name);
		bbssetenv("USERNAME", curuser.username);
		bbssetenv("HOME", passid->pw_dir);
		if (numbbsenvs == 0)
			bbsenv[0] = NULL;
		signal(SIGCHLD, SIG_IGN);	/* lthuang: ignore SIGCHLD */
		execve(path, arglist, bbsenv);
		fprintf(stderr, "EXECV FAILED... path = '%s'\n", path);
		exit(-1);
	}
	isig = signal(SIGINT, SIG_IGN);
	qsig = signal(SIGQUIT, SIG_IGN);
	child_pid = pid;

#if	defined(SOLARIS) || defined(AIX)
	while (1)
	{
		if (waitpid(pid, &status, 0) == -1 && errno == EINTR)
			continue;
		break;
	}
#else
	while (waitpid(child_pid, &status, 0) != child_pid)
		/* empty */ ;
#endif

	signal(SIGINT, isig);
	signal(SIGQUIT, qsig);
	child_pid &= ~child_pid;
	restore_tty();
	return 0;
}


/* 
   execute oudoor program 
*/
int
outdoor(cmd_file, umode, dotimeout)	
char *cmd_file;
int umode;
BOOL dotimeout;
{
	int save_pager = uinfo.pager;
	char filename[PATHLEN], *ptr;
	int save_umode = uinfo.mode;

	strncpy(filename, cmd_file, PATHLEN - 1);
	if ((ptr = strchr(filename, ' ')))
		*ptr = '\0';
	if (access(filename, X_OK) == -1)
	{
		char buf[PATHLEN];	/* lthuang */

		sprintf(buf, "%s/%s", BINDIR, filename);
		if (access(buf, X_OK) == -1)
		{
			outs("\nThis option is disable");
			pressreturn();
			return -1;
		}
	}
	uinfo.pager = FALSE;
	uinfo.mode = umode;
	update_ulist(cutmp, &uinfo);
/*
   clear();
   refresh();
 */
	if (!dotimeout)
		signal(SIGALRM, SIG_IGN);	/* lthuang */
/*
   sprintf(buf, "/bin/sh %s", cmdfile);
   do_exec(buf,NULL);
 */
	do_exec(cmd_file, NULL);
	if (!dotimeout)
		init_alarm(IDLE_TIMEOUT);
	uinfo.pager = save_pager;
	uinfo.mode = save_umode;
	update_ulist(cutmp, &uinfo);
	return 0;
}


void
show_byebye(idle)
BOOL idle;
{
	time_t now = time(0);

	printxy(4, 15, _msg_stuff_1);
	printxy(5, 15, _msg_stuff_2, curuser.numposts);
	printxy(6, 15, _msg_stuff_3, curuser.numlogins);
	printxy(7, 15, _msg_stuff_4, Ctime(&curuser.lastlogin));
	printxy(8, 15, _msg_stuff_5, curuser.lasthost);
	printxy(9, 15, _msg_stuff_6, Ctime(&uinfo.login_time));
	printxy(10, 15, _msg_stuff_7, uinfo.from);
	printxy(11, 15, _msg_stuff_8, Ctime(&now));
	if (idle)
		printxy(12, 26, _msg_stuff_9);
	else
		printxy(12, 26, _msg_stuff_10);
}


void
log_usies(mode, va_alist)
char *mode;

va_dcl
{
	va_list args;
	time_t now;
	int fd;
	char msgbuf[80], buf[140], *fmt, timestr[22];

	va_start(args);
	fmt = va_arg(args, char *);

	vsprintf(msgbuf, fmt, args);
	va_end(args);

	time(&now);
	strftime(timestr, sizeof(timestr), "%x %X", localtime(&now));
	sprintf(buf, "%s %-12.12s %-10.10s %s\n",
	        timestr, curuser.userid, mode, msgbuf);
	if ((fd = open(PATH_BBSLOG, O_APPEND | O_CREAT | O_WRONLY, 0600)) > 0)
	{
		write(fd, buf, strlen(buf));
		close(fd);
	}
}




static void
left_note()			/* Seraph */
{
	char ftmp[] = "log/note.tmp";
	char fdat[] = "log/note.dat";
	int i, fd, fp;
	char choice[3];
	time_t now = time(0);
	NOTEDATA mynote, notetmp;


	clear();
	outs(_msg_stuff_15);
	do
	{
		move(2, 0);
		clrtobot();
		outs(_msg_stuff_16);
		for (i = 0; i < 3; i++)
		{
			getdata(4 + i, 0, ": ", mynote.buf[i], 77, DOECHO, NULL);
			strcat(mynote.buf[i], "\n");
		}
		getdata(10, 0, _msg_stuff_17, choice, 3, DOECHO | LOWCASE, NULL);
		if (choice[0] == 'q' || i == 0)
			return;
	}
	while (choice[0] == 'e');

	strcpy(mynote.userid, curuser.userid);
	strcpy(mynote.username, curuser.username);
	time(&(mynote.date));

/* We cannot prevent the users leave their note,
   so the file may be open or write in the same time,
   opening the file with exclusive lock is better.
 */

	if ((fd = open(ftmp, O_CREAT | O_RDWR, 0664)) == -1)
		return;
	if ((fp = open(fdat, O_CREAT | O_APPEND | O_RDONLY)) == -1)
	{
		close(fd);
		return;
	}
	sprintf(mynote.buf[3], _msg_stuff_18, mynote.userid, mynote.username, 80 - 24 - strlen(mynote.userid) - strlen(mynote.username) - 19, "                                    ", Ctime(&now));
	write(fd, &mynote, sizeof(mynote));
	while (read(fp, &notetmp, sizeof(notetmp)) == sizeof(notetmp))
	{
		if (now - notetmp.date < 14400)	/* 14400�� */
			write(fd, &notetmp, sizeof(notetmp));	/* �����ɰ¶i�� */
	}
	close(fd);
	close(fp);
	rename(ftmp, fdat);	/* ��tmp��W��dat */

	x_viewnote();
}


int
Goodbye()			/* quit bbs */
{
	move(b_line, 0);
	clrtoeol();
	refresh();
	printxy(b_line, 24, _msg_stuff_11);
	if (igetkey() != 'y')
		return M_FULL;

	move(b_line, 0);
	clrtoeol();
	if (!(curuser.flags[1] & NOTE_FLAG) && curuser.userlevel > 5)
	{
		printxy(b_line, 24, _msg_stuff_19);
		if (igetkey() == 'y')
			left_note();
	}

	clear();
	show_byebye(FALSE);
	refresh();
	user_logout(cutmp, &curuser);
	getkey();
	exit(0);
}


/* 
   switch color or black-white mode 
*/
int
Switch_scr()			
{
	clear();
	if (curuser.flags[0] & COLOR_FLAG)
	{
		show_ansi = TRUE;
		outs(_msg_stuff_12);
	}
	else
	{
		show_ansi = FALSE;
		outs(_msg_stuff_13);
	}
	curuser.flags[0] ^= COLOR_FLAG;	
	pressreturn();
	return M_FULL;
}


char *
Ctime(clock)
register time_t *clock;
{
	static char tibuf[40];

	strftime(tibuf, 40, "%D %T %a", localtime(clock));
	return tibuf;
}


void
bell()
{
	fprintf(stderr, "%c", CTRL('G'));
}


int
isprint2(ch)
unsigned char ch;
{
	return (((ch & 0x80) || ch == 0x1B) ? 1 : isprint(ch));
}


#define NUMLINES (19)

/*******************************************************************
 * ������J, �P���w�� link list ���
 *******************************************************************/
namecomplete(toplev, prompt, data)
struct word *toplev;
char *prompt;
char data[];
{
	char *temp;
	int ch;
	int count = 0;
	BOOL clearbot = FALSE;
	struct word *cwlist, *morelist;
	int x, y, origx, origy;

	if (prompt)
	{
		prints("%s", prompt);
		clrtoeol();
	}
	temp = data;

	cwlist = get_subwlist(NULL, toplev);
	morelist = NULL;
	getyx(&origy, &origx);
	y = origy;
	x = origx;
	while ((ch = getkey()) != EOF)
	{
		if (ch == '\n' || ch == '\r')
		{
			*temp = '\0';
			prints("\n");
			/* lthuang */
			if (data[0] && (num_wlist(cwlist) == 1 || !strcmp(data, cwlist->word)))
				strcpy(data, cwlist->word);
			else
			{
				data[0] = '\0';
				move(b_line - 1, 0);
				clrtoeol();
				outs(_msg_stuff_14);
				pressreturn();
			}
			cwlist = free_wlist(cwlist, NULL);
			break;
		}
		else if (isspace(ch))
		{
			int col, len;

			if (num_wlist(cwlist) == 1)
			{
				strcpy(data, cwlist->word);
				move(y, x);
				prints("%s", data + count);
				count = strlen(data);
				temp = data + count;
				getyx(&y, &x);
				continue;
			}
			clearbot = TRUE;
			col = 0;
			if (!morelist)
				morelist = cwlist;
			len = maxlen_wlist(morelist, NUMLINES);
			move(3, 0);
			clrtobot();
			standout();
			prints("------------------------------- Completion List -------------------------------");
			standend();
			while (len + col < 80)
			{
				int i;

				for (i = NUMLINES; (morelist) && (i > 0); i--, morelist = morelist->next)
				{
					move(4 + (NUMLINES - i), col);
					prints("%s", morelist->word);
				}
				col += len + 2;
				if (!morelist)
					break;
				len = maxlen_wlist(morelist, NUMLINES);
			}
			if (morelist)
			{
				move(23, 0);
				standout();
				prints("-- More --");
				standend();
			}
			move(y, x);
			continue;
		}
		else if (ch == '\177' || ch == '\010')
		{
			if (temp == data)
				continue;
			temp--;
			count--;
			*temp = '\0';
			cwlist = free_wlist(cwlist, NULL);
			cwlist = get_subwlist(data, toplev);
			morelist = NULL;
			x--;
			move(y, x);
			outc(' ');
			move(y, x);
			continue;
		}
		else if (count < STRLEN)
		{
			struct word *node;

			*temp++ = ch;
			count++;
			*temp = '\0';
			node = get_subwlist(data, cwlist);
			if (node == NULL)
			{
				bell();
				temp--;
				*temp = '\0';
				count--;
				continue;
			}
			cwlist = free_wlist(cwlist, NULL);
			cwlist = node;
			morelist = NULL;
			move(y, x);
			outc(ch);
			x++;
		}
	}
	if (ch == EOF)		/* lthuang */
	{
		shutdown(0, 2);
		exit(0);
	}
	prints("\n");
	refresh();
	if (clearbot)
	{
		move(3, 0);
		clrtobot();
	}
	if (data[0] != '\0')
	{
		move(origy, origx);
		prints("%s\n", data);
	}
	return 0;
}




/*
   update the mode of online user_info 
*/   
void
update_umode(mode)
int mode;
{
	uinfo.mode = mode;
	update_ulist(cutmp, &uinfo);
}
