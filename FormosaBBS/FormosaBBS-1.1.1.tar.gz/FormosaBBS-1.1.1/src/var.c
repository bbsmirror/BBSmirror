
#include "bbs.h"


USEREC curuser;
USER_INFO uinfo;
FILEHEADER fhGol;

struct word *artwtop = NULL;	/* for tagging articles or mail */
struct BoardList *CurBList = NULL;


char genbuf[1024];			/* generally used global buffer */

BOOL in_board = TRUE;
BOOL in_mail = FALSE;
BOOL dumb_term = 1;
BOOL talkrequest = FALSE;
BOOL writerequest = FALSE;
BOOL show_ansi = TRUE;
int multi = 1;				/* multi_login */
int maxkeepmail = MAX_KEEP_MAIL;

char ufile_overrides[PATHLEN];
char ufile_write[PATHLEN];
char ufile_mail[PATHLEN];

struct array *friend_cache = NULL;

char _str_cursor[] = "=>";
char _str_uncurs[] = "  ";

BOOL isBM = FALSE, hasBMPerm = FALSE;

USER_INFO *cutmp = NULL;
