/*
    Li-te Huang, lthuang@cc.nsysu.edu.tw, 03/10/98
*/    

#include "bbs.h"
#include "tsbbs.h"




static int Mail_Send();
static int Mail_Help();
extern int mail_article();
extern int delete_article();
extern int edit_article();
extern int title_article();
extern int range_delete_article();
extern int reserve_article();
extern int cross_article();

struct one_key mail_comms[] =
{
	CTRL('P'), Mail_Send,
	'h', Mail_Help,
	'm', mail_article,
	'd', delete_article,
	'E', edit_article,
	'i', title_article,
	'T', range_delete_article,
	'g', reserve_article,
	'x', cross_article,
	'\0', NULL
};

BOOL MailToAllFriend;


/*******************************************************************
 * �ˬd�H�c���L�s�H
 *******************************************************************/
check_newmail(name)
char *name;
{
	static long lasttime = 0;
	static BOOL ismail = FALSE;
	struct stat st;
	int fd;
	long numfiles;
	char fnameTmp[PATHLEN];
	BOOL oismail = FALSE, isme = FALSE;
	

#ifdef GUEST_ACCOUNT
	if (!strcmp(GUEST_ACCOUNT, name))
		return FALSE;
#endif
	if (!strcmp(name, curuser.userid))
		isme = TRUE;
	setmailfile(fnameTmp, name, DIR_REC);
	if (stat(fnameTmp, &st) == -1)
		return (isme ? (ismail = FALSE) : (oismail = FALSE));
	if (isme)
	{
		if (lasttime >= st.st_mtime)
			return ismail;
		lasttime = st.st_mtime;
	}
	numfiles = st.st_size / FH_SIZE;
	if (numfiles > 0)
	{
		if ((fd = open(fnameTmp, O_RDONLY)) > 0)
		{
			lseek(fd, (off_t) (st.st_size - FH_SIZE), SEEK_SET);
			while (numfiles-- > 0)
			{
				read(fd, &fhGol, sizeof(fhGol));
				if (!(fhGol.accessed & FILE_READ) && !(fhGol.accessed & FILE_DELE))
				{
					close(fd);
					return (isme ? (ismail = TRUE) : (oismail = TRUE));
				}
				lseek(fd, -((off_t) (2 * FH_SIZE)), SEEK_CUR);
			}
			close(fd);
		}
	}
	return (isme ? (ismail = FALSE) : (oismail = FALSE));
}


struct array *mgatop = NULL;

/**************************************************************
 * ��ܸs�ձH�H�W��
 **************************************************************/
static void
DisplayGroup()
{
	move(4, 0);
	clrtobot();
	if (mgatop)
	{
		int i;

		for (i = 0; i < mgatop->number; i++)
		{
			if (mgatop->datap[i])
				prints("%s\n", mgatop->datap[i]);
		}
	}
}


/**************************************************************
 * �߰� Mail Groups �W�� �Ǧ^�H��
 **************************************************************/
static int
AskGroup()
{
	char strName[STRLEN - 10];
	

	clear();
	outs(_msg_max_group);
	prints("%d", MAX_MAILGROUPS);
	MailToAllFriend = FALSE;
	while (1)
	{
		DisplayGroup();
		if (MailToAllFriend)
		{
			outs(_msg_mail_to_all_friend);
			getdata(2, 0, _msg_ask_group_del, genbuf, 2, ECHONOSP|LOWCASE, NULL);
		}
		else
			getdata(2, 0, _msg_ask_group_add, genbuf, 2, ECHONOSP|LOWCASE, NULL);
		switch (genbuf[0])
		{
		case 'a':
			if (num_array(mgatop) >= MAX_MAILGROUPS)
			{
				outs(_msg_mail_group_max_prompt);
				prints("%d", MAX_MAILGROUPS);
				getkey();
				continue;
			}
			if (getdata(2, 0, _msg_receiver, strName, sizeof(strName), ECHONOSP, NULL))
			{
#if EMAIL_LIMIT
				if (curuser.ident != 7 && strchr(strName, '@'))
				{
					prints("\n%s", _msg_sorry_email);
					clrtoeol();
					getkey();
					continue;
				}
#endif
				if (strchr(strName, '@') || get_passwd(NULL, strName) > 0)
					add_array(mgatop, strName, malloc_str);
			}
			break;
		case 'f':
			MailToAllFriend ^= 1;
			break;
		case 'd':
			if (getdata(2, 0, _msg_delete, genbuf, IDLEN, ECHONOSP, NULL))
				mgatop = cmpd_array(mgatop, genbuf, strcmp);
			break;
		case 'q':
			mgatop = free_array(mgatop);
			return -1;
		case 'e':
		default:
			if (!MailToAllFriend && num_array(mgatop) <= 0)
				return -1;
			return 0;
		}
	}
}


/**************************************************************
 * ��峹�H�� Mail Groups 
 **************************************************************/
static int
MailGroup(fname, title)
char *fname, *title;
{
	int i, msNew;
	char uuname[PATHLEN], strTo[STRLEN];


	if ((msNew = CreateMailSocket()) < 0)
		return -1;

	uuname[0] = '\0';

	msg(_msg_ask_uuencode);
	if (igetkey() == 'y')
		uuencode_file(fname, uuname);

	for (i = 0; i < mgatop->number; i++)
	{
		char *s;

		s = mgatop->datap[i];
		if (s && s[0])
		{
			strcpy(strTo, s);
			if (is_emailaddr(strTo))
				SendMail_Internet(msNew, (uuname[0] ? uuname : fname), curuser.userid, strTo, title);
			else
				SendMail_Local(fname, curuser.userid, strTo, title, curuser.ident);
		}
	}
	if (MailToAllFriend)
	{
		char *s;

		load_friend_cache();
		for (i = 0; i < friend_cache->number; i++)
		{
			s = friend_cache->datap[i];
			if (s && s[0])
			{
				strcpy(strTo, s);
				/* my friend must be in local */
				SendMail_Local(fname, curuser.userid, strTo, title, curuser.ident);
			}
		}
	}

	if (uuname[0])
		unlink(uuname);
	CloseMailSocket(msNew);

	return 0;
}


/**************************************************************
 * �ǳƱH�H���@�s�H
 **************************************************************/
static int
PrepareGroupMail()
{
	int save_mmode = in_mail, result;
	char strTitle[STRLEN], fnameTmp[PATHLEN];


	mgatop = malloc_array(MAX_MAILGROUPS);
	if (AskGroup() == -1)
		return -1;
	if (do_article_title(strTitle) == -1)
	{
		mgatop = free_array(mgatop);
		return -1;
	}

	sprintf(fnameTmp, "tmp/bbs%05d", getpid());

	update_umode(SMAIL);

	in_mail = TRUE;		/* lthuang */
	if (vedit(fnameTmp, strTitle))
		result = -1;
	else
		result = MailGroup(fnameTmp, strTitle);
	in_mail = save_mmode;

	mgatop = free_array(mgatop);
	unlink(fnameTmp);
	return result;
}


/**************************************************************
 * �ˬd�ӤH�H�c Mail �ƶq 
 **************************************************************/
static BOOL
check_mail_num()
{
	int cnt;


	if (HAS_PERM(PERM_SYSOP))
		return FALSE;
		
	cnt = get_num_records(ufile_mail, FH_SIZE);
	if (cnt > maxkeepmail && uinfo.ever_delete_mail)
	{
		int fd;

		if ((fd = open(ufile_mail, O_RDONLY)) > 0)
		{
			while (read(fd, &fhGol, sizeof(fhGol)) == sizeof(fhGol))
				if ((fhGol.accessed & FILE_DELE))
					cnt--;
			close(fd);
		}
	}
	if (cnt > maxkeepmail)
	{
		clear();
		prints(_msg_max_mail_warning, cnt, maxkeepmail);
		pressreturn();
		return TRUE;
	}
	if (uinfo.ever_delete_mail)	/* lthuang */
		pack_article(ufile_mail);
	return FALSE;
}


/**************************************************************
 * �H�H���@�s�H
 **************************************************************/
m_group()
{
	int result;

	clear();

	result = PrepareGroupMail();

	in_mail = FALSE;

	move(b_line - 1, 0);
	clrtoeol();
	if (result == -1)
		outs(_msg_fail);
	else
		outs(_msg_finish);
	pressreturn();
	return M_FULL;
}


/**************************************************************
 * �H�H���@�ӤH
 **************************************************************/
m_send()
{
	char strTo[STRLEN] = "\0", strTitle[STRLEN] = "\0";
	int result;

	clear();

	/* fn_src: NULL, postpath: NULL, mail_ok: TRUE, post_ok: FALSE */
	result = PrepareMailPost(NULL, strTo, strTitle, NULL, TRUE, FALSE);

	move(b_line - 1, 0);
	clrtoeol();
	if (result != 0)
		outs(_msg_fail);
	else
		outs(_msg_finish);
	pressreturn();
	return M_FULL;
}


/*******************************************************************
 * �uŪ�s���H
 *******************************************************************/
m_new()
{
	int fd, cnt = 0;


	do
	{
		in_mail = TRUE;	/* lthuang */
		if ((fd = open(ufile_mail, O_RDWR)) < 0)
			return M_FULL;
		update_umode(RMAIL);
		while (read(fd, &fhGol, sizeof(fhGol)) == sizeof(fhGol))
		{
			if (++cnt > maxkeepmail && !HAS_PERM(PERM_SYSOP))
			{
				clear();
				outs(_msg_m_new_full);
				pressreturn();
				close(fd);
				return M_FULL;
			}
			if (fhGol.accessed & FILE_READ)
				continue;
			clear();
			prints(_msg_m_new_read_prompt,
			       (fhGol.owner[0] == '#') ? (fhGol.owner + 1) : (fhGol.owner), fhGol.title);
			if (igetkey() == 'n')
				continue;
			setdotfile(genbuf, ufile_mail, fhGol.filename);
			more(genbuf, FALSE);
			fhGol.accessed |= FILE_READ;
			if (lseek(fd, -((off_t) FH_SIZE), SEEK_CUR) != -1)
				write(fd, &fhGol, FH_SIZE);
			msg(_msg_m_new_command_prompt);
			switch (igetkey())
			{
			case 'r':
				reply_article(&fhGol, ufile_mail);
				break;
			case 'd':
				fhGol.accessed |= FILE_DELE;
				if (lseek(fd, -((off_t) FH_SIZE), SEEK_CUR) != -1)
					write(fd, &fhGol, FH_SIZE);
				break;
			case 'e':
				close(fd);
				return M_FULL;
			case 'n':
			default:
				break;
			}
		}
		close(fd);
		move(2, 0);
		clrtobot();
		outs(_msg_m_new_nomore);
		pressreturn();
	}
	while (check_mail_num());
	in_mail = FALSE; 	/* lthuang */

	return M_FULL;
}


/*******************************************************************
 * Read Mail Menu �ӤH�H�c  �C���\Ū
 *******************************************************************/
m_read()
{
	do
	{
		in_mail = TRUE;	/* debug */
		i_read(ufile_mail, mail_comms, IREAD_MAIL);
	}
	while (check_mail_num());

	in_mail = FALSE;

	return M_FULL;
}


/**************************************************************
 * �ˬd�O�_���X�k�� forward email address
 **************************************************************/
CheckFwdEmailaddr(addr)
char *addr;
{
	if (addr[0] == '\0')
		outs(_msg_checkfwdemailaddr);
	else if (strstr(addr, MYHOSTNAME) || strstr(addr, MYHOSTIP))
		outs(_msg_checkfwdemailaddr_fail);
	else
		return 0;
	return -1;
}


/**************************************************************
 * �]�w Auto-forward �ӤH�H��۰���H�A��
 **************************************************************/
m_forward()
{
	move(2, 0);
	clrtobot();
	if (curuser.flags[0] & FORWARD_FLAG)
	{
		curuser.flags[0] &= ~FORWARD_FLAG;
		outs(_msg_m_forward_finish);
	}
	else
	{
		prints(_msg_m_forward_desc_1, curuser.email);
		getdata(10, 0, _msg_m_forward_desc_2, genbuf, 2, ECHONOSP, NULL);
		switch(genbuf[0])
		{
			case '2':
				prints(_msg_xyz_8, curuser.email);
				/* change e-mail address */
				getdata(7, 14, "\0", genbuf, sizeof(curuser.email), ECHONOSP, curuser.email);
				if (CheckFwdEmailaddr(genbuf) == -1)
				{
					outs(_msg_xyz_42);
					getkey();
				}
				else
					strcpy(curuser.email, genbuf);
				break;
			case '3':
				if (CheckFwdEmailaddr(curuser.email) != -1)
				{
					curuser.flags[0] |= FORWARD_FLAG;
					outs(_msg_m_forward_desc_2);
					outs(curuser.email);
				}
				break;	
			case '1':
			default:
				outs(_msg_abort);			
				pressreturn();
				return M_FULL;
		}
	}
	update_user(&curuser);	/* ensure starting auto-forward now */
	pressreturn();
	return M_FULL;
}


/**************************************************************
 * �H�H
 **************************************************************/
static int
Mail_Send(ent, finfo, direct)
int ent;			/* unused */
FILEHEADER *finfo;		/* unused */
char *direct;			/* unused */
{
	m_send();
	return R_FULL;
}


/**************************************************************
 * �\Ū�ӤH�H�� ��� Help
 **************************************************************/
static int
Mail_Help()
{
	more(MAIL_HELP, TRUE);
	return R_FULL;
}


int
do_article_to(to)
char to[];
{
	if (to[0])
	{
		printxy(1, 0, _msg_mail_1, to);
		if (igetkey() == 'n')
			to[0] = '\0';
	}
	if (to[0] == '\0')
	{
		if (!getdata(1, 0, _msg_mail_2, to, STRLEN, ECHONOSP, NULL))
			return -1;
	}
	return 0;
}
