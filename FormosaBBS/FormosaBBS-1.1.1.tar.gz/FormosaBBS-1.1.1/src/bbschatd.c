
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/file.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <netdb.h>
#ifdef LINUX
#include <sys/time.h>
#endif


#if	defined(AIX)
#include <sys/select.h>
#include <sys/pathname.h>
#endif

#include "config.h"
#include "struct.h"
#include "chat.h"
#include "msginfo.h"


#define DEBUG

#define MAXCHANS	20	/* max. channel */

#define TOASCNUM(n)	((n)+'0')

char *mycrypt();
void Answer();
void EndProt();


int seat;
char chbuf[254];
int numports;
char *idpassstr;
char gbuf[256];

struct Respond
{
	int num;
	char *desc;
};

struct prot
{
	int num;
	char *keyword;
	int (*func) ();
};

int chat_join(), chat_msg(),
#ifdef HAVE_CHATMSGALL
  chat_msgall(),
#endif
  chat_who(), chat_who(), chat_whoall(), chat_nickname(), chat_listchan(),
  chat_user(), chat_topic(), chat_passwd(), chat_logout(), chat_ignore();

struct prot fp[] =
{
	{CHAT_JOIN, "JOIN", chat_join},
	{CHAT_USRID, "USRID", chat_user},
	{CHAT_QUIT, "QUIT", chat_logout},

 /* Operator Instruction */

	{CHAT_TOPIC, "TOPIC", chat_topic},
	{CHAT_PASSWD, "PASSWD", chat_passwd},
	{CHAT_IGNORE, "IGNORE", chat_ignore},

 /* Ordinary User Instruction */

	{CHAT_MSG, "MSG", chat_msg},
#ifdef HAVE_CHATMSGALL
	{CHAT_MSGALL, "MSGALL", chat_msgall},
#endif
	{CHAT_WHO, "WHO", chat_who},
	{CHAT_WHOALL, "WHOALL", chat_whoall},
	{CHAT_NICKNAME, "NICKNAME", chat_nickname},
	{CHAT_LISTCHAN, "LISTCHAN", chat_listchan},
	{CHAT_SPEAK, "SPEAK", NULL}
};

struct Respond rep_err[] =
{
	{OK_CMD, "OK !!"},
	{WORK_FAIL, _msg_bbschatd_1},
	{PASS_FAIL, _msg_bbschatd_2},
	{USR_FAIL, _msg_bbschatd_3},
	{NAME_FAIL, _msg_bbschatd_4},
	{CMD_ERROR, _msg_bbschatd_5}
};


struct Usr
{
	int sock;		/* socket */
	char userid[IDLEN];	/* userid */
	char nick[IDLEN];	/* user's nickname */
	int chid;		/* current channel id number */
	char from[16];		/* from host */
	BOOL bmop;		/* boardmanager or not */
	int bad[5];		/* channel id which not allowed to enter */
}

Usrec[MAXPORTS];


struct Chan
{
	char chname[CHANLEN];
	char topic[TOPICLEN];
/*      int     attrib; */
	char op[IDLEN];	/* op userid */
	char passwd[8];		/* private channel password */
	int members;		/* number of users in the channel */
}

Chanrec[MAXCHANS];


void
report(s)
char *s;
{
	static int disable = 0;
	int fd;
	char buf[256], timestr[31];
	time_t now;

	if (!disable)
	{
		sprintf(buf, "%s/log/trace.chatd", HOMEBBS);
		if ((fd = open(buf, O_APPEND | O_CREAT | O_WRONLY, 0644)) < 0)
		{
			disable = 1;
			return;
		}
		now = time(0);
		sprintf(timestr, "%D %T", 30, localtime(&now));
		sprintf(buf, "%s Room %d: %s\n", timestr, Usrec[seat].chid, s);
		write(fd, buf, strlen(buf));
		close(fd);
	}
}


void
get_client_name(cli_addr, peer_name, len)	/* ? */
struct sockaddr_in *cli_addr;
char *peer_name;
int len;
{
/*
   struct hostent host_info;

   host_info = gethostbyaddr((char *) &cli_addr.sin_addr,
   sizeof(cli_addr.sin_addr), AF_INET); strncpy(peer_name,
   host_info.h_name, len);
 */
	strncpy(peer_name, inet_ntoa(cli_addr->sin_addr), len);
}


int
get_chatuid(userid)
char *userid;
{
	register int i;

	for (i = 0; i < MAXPORTS; i++)
	{
		if (Usrec[i].sock > 0)
		{
			if (!strcmp(Usrec[i].userid, userid))
				return i;
		}
	}
	return -1;
}


int
get_chid(chname)
char *chname;
{
	register int i;

	for (i = 0; i < MAXCHANS; i++)
	{
		if (Chanrec[i].members > 0)
		{
			if (!strcmp(Chanrec[i].chname, chname))
				return i;
		}
	}
	return -1;
}


int
create_channel(chname)		/* �إ߷s���W�D */
char *chname;
{
	register int i;

	for (i = 0; i < MAXCHANS; i++)
	{
		if (*(Chanrec[i].chname) == '\0')
		{
			strncpy(Chanrec[i].chname, chname, CHANLEN - 1);
			strncpy(Chanrec[i].topic, chname, TOPICLEN - 1);
			strcpy(Chanrec[i].op, Usrec[seat].userid);
			return i;
		}
	}
	return -1;
}

#if defined(AIX) && defined(BAD)
#undef BAD
#endif

int
BAD(badnums, chid)
int badnums[];
int chid;
{
	register int i;

	if (chid < 0)		/* debug */
		return 1;
	for (i = 0; i < 5; i++)
	{
		if (badnums[i] == TOASCNUM(chid))
			return 1;
	}
	return 0;
}


int
send_to_channel(chid, msg)
int chid;
char *msg;
{
	register int i;

/*      
   int    invis = (Usrec[seat].perm & PERM_CLOAK);
 */
	int len = strlen(msg);

	if (chid < 0)		/* debug */
	{
		Answer(PASS_FAIL);
		return -1;
	}

	if (BAD(Usrec[seat].bad, chid))
	{
		Answer(PASS_FAIL);
		return -1;
	}

	for (i = 0; i < MAXPORTS; i++)
	{
/*
   if (invis && !(Usrec[i].perm & PERM_CLOAK))
   continue;
 */
		if (*(Usrec[i].userid) == '\0')
			continue;
		if (i == seat)	/* lthuang */
			continue;
		if (Usrec[i].sock == -1)
			continue;
		if (Usrec[i].chid == chid)
		{
			register int again = 0;


			while (write(Usrec[i].sock, msg, len) != len)
			{
				if (errno == EAGAIN)
				{
					sleep(1);
					if (again++ > 3)
						break;
				}
				else
					break;
			}
		}
	}
	return 0;
}


void
send_to_user(chatuid, msg)
int chatuid;
char *msg;
{
	if (*(Usrec[chatuid].userid) != '\0')
	{
		if (Usrec[chatuid].sock > 0)
			write(Usrec[chatuid].sock, msg, strlen(msg));
	}
}


void
Answer(respno)
int respno;
{
	register int i;

	for (i = 0; i < (sizeof(rep_err) / sizeof(struct Respond)); i++)

	{
		if (rep_err[i].num == respno)
		{
			sprintf(gbuf, "%d\t%s \r\n", rep_err[i].num, rep_err[i].desc);
			send_to_user(seat, gbuf);
		}
	}
}


void
EndProt()
{
	sprintf(gbuf, ".\r\n");
	send_to_user(seat, gbuf);
}


void
leave_channel()			/* ? */
{
	int oldchid = Usrec[seat].chid;

	Usrec[seat].chid = 0;	/* lthuang */

	if (oldchid > 0)
	{
		if (--(Chanrec[oldchid].members) > 0)
		{
			register int i;

			if (!BAD(Usrec[seat].bad, oldchid))
			{
				sprintf(chbuf, _msg_bbschatd_6, Usrec[seat].nick);
				send_to_channel(oldchid, chbuf);
			}

			if (!strcmp(Usrec[seat].userid, Chanrec[oldchid].op))
			{
				Chanrec[oldchid].op[0] = '\0';
				for (i = 0; i < MAXPORTS; i++)
				{
					if (*(Usrec[i].userid) == '\0')
						continue;
					if (i == seat)
						continue;
					if (Usrec[i].sock == -1)
						continue;
					if (Usrec[i].chid == oldchid)	/* ���� op ���� */
					{
						if (!BAD(Usrec[i].bad, oldchid))
						{
							strcpy(Chanrec[oldchid].op, Usrec[i].userid);
							if (*(Chanrec[oldchid].passwd) != '\0')
								sprintf(chbuf, _msg_bbschatd_7, Chanrec[oldchid].passwd);
							else
								sprintf(chbuf, _msg_bbschatd_8);
							send_to_user(i, chbuf);
							break;
						}
					}
				}
			}
		}
		else
		{
			/* close channel */
			Chanrec[oldchid].chname[0] = '\0';
			Chanrec[oldchid].topic[0] = '\0';
			Chanrec[oldchid].op[0] = '\0';
			Chanrec[oldchid].members = 0;
			Chanrec[oldchid].passwd[0] = '\0';
		}
	}
/*      
   else
   {
   if (!BAD(Usrec[seat].bad, oldchid))
   {
   sprintf(chbuf, "�ϥΪ� %s ���}���W�D\r\n", Usrec[seat].nick);
   send_to_channel(oldchid, chbuf);
   }
   }    
 */
}


int
chat_passwd(password)
char *password;
{
	int mychid = Usrec[seat].chid;

	if (mychid > 0)
	{
		if (!strcmp(Chanrec[mychid].op, Usrec[seat].userid))
		{
			password = PhaseSpace(password);
			if (!strcmp(password, NOPASSWORD))
				Chanrec[mychid].passwd[0] = '\0';
			else
				strncpy(Chanrec[mychid].passwd, password, 7);
			Answer(OK_CMD);
			return 0;
		}
	}
	Answer(PASS_FAIL);
	return -1;
}


int
chat_topic(topic)
char *topic;
{
	int mychid = Usrec[seat].chid;

	if (mychid > 0)
	{
		if (!strcmp(Chanrec[mychid].op, Usrec[seat].userid))
		{
			topic = PhaseSpace(topic);
			strncpy(Chanrec[mychid].topic, topic, TOPICLEN - 1);
			Answer(OK_CMD);
			return 0;
		}
	}
	Answer(PASS_FAIL);
	return -1;
}


int
chat_logout(u)
int u;
{
	leave_channel();

	close(Usrec[u].sock);
	Usrec[u].userid[0] = '\0';
	Usrec[u].nick[0] = '\0';
	Usrec[u].sock = -1;
/*      Usrec[u].chid = 0;      */
	Usrec[u].from[0] = '\0';

	memset(Usrec[u].bad, 0, 5);

	numports--;		/* lthuang */
	return 0;
}


int
chat_join(NextPass)
char *NextPass;
{
	int newchid;
	char chname[CHANLEN];

	if (*(Usrec[seat].userid) == '\0')	/* debug */
	{
		Answer(WORK_FAIL);
		return -1;
	}

	NextPass = GetPass(NextPass, chname, CHANLEN);
	NextPass = PhaseSpace(NextPass);
	if (chname[0] == '\0')
	{
		Answer(WORK_FAIL);
		return -1;
	}

	if (!strcmp(chname, DEF_CHANNAME))	/* ? */
	{
		Answer(OK_CMD);
		leave_channel();
		return 0;
	}

	if ((newchid = get_chid(chname)) < 0)
	{
		if ((newchid = create_channel(chname)) < 0)
		{
			Answer(WORK_FAIL);
			return -1;
		}
	}

	if (newchid > 0 && Usrec[seat].chid == newchid)		/* lthuang */
	{
		Answer(WORK_FAIL);
		return -1;
	}

	if (*(Chanrec[newchid].passwd) == '\0' || !strcmp(Chanrec[newchid].passwd, NextPass))
	{
		Answer(OK_CMD);
		leave_channel();
		Usrec[seat].chid = newchid;
		Chanrec[newchid].members++;
		if (!BAD(Usrec[seat].bad, newchid))
		{
			sprintf(chbuf, _msg_bbschatd_9, Usrec[seat].nick);
			send_to_channel(newchid, chbuf);
		}
		return 0;
	}
	Answer(PASS_FAIL);
	return -1;
}


int
chat_msg(Token)			/* -ToDo- allow to use the nickname or userid as target */
char *Token;
{
	char user[IDLEN];
	int chatuid;

	if (BAD(Usrec[seat].bad, Usrec[seat].chid))
	{
		Answer(PASS_FAIL);
		return -1;
	}

	Token = GetPass(Token, user, IDLEN);
	Token = PhaseSpace(Token);

	chatuid = get_chatuid(user);
	/* debug */
	if (chatuid >= 0 && Usrec[seat].chid >= 0
	    && Usrec[seat].chid == Usrec[chatuid].chid)		/* lthuang ? */
	{
		Answer(OK_CMD);
		sprintf(chbuf, _msg_bbschatd_10,
			Usrec[seat].userid, Usrec[seat].nick, Token);
		send_to_user(chatuid, chbuf);
		sprintf(chbuf, _msg_bbschatd_11, user, Token);	/* lthuang */
		send_to_user(seat, chbuf);	/* lthuang */
		return 0;
	}
	Answer(USR_FAIL);
	return -1;
}


#ifdef HAVE_CHATMSGALL
chat_msgall(msg)
char *msg;
{
	int i;
	char buf[80];

	msg = PhaseSpace(msg);
	sprintf(buf, _msg_bbschatd_14, Usrec[seat].nick, msg);
	Answer(OK_CMD);

	for (i = 0; i < MAXPORTS; i++)
	{
		if (Usrec[i].sock == -1)
			continue;

		send_to_user(i, buf);
	}
}

#endif


int
chat_who(chname)
char *chname;
{
	register int i;
	int mychid;

	chname = PhaseSpace(chname);
	if (!strcmp(chname, DEF_CHANNAME))
	{
		mychid = Usrec[seat].chid;

		Answer(OK_CMD);
		if (mychid >= 0)	/* debug */
		{
			for (i = 0; i < MAXPORTS; i++)
			{
				if (*(Usrec[i].userid) == '\0')
					continue;
				if (Usrec[i].sock == -1)
					continue;
				if (Usrec[i].chid == mychid)
				{
					sprintf(chbuf, "%s\t%s\t%s\r\n", Usrec[i].userid, Usrec[i].nick, Usrec[i].from);
					send_to_user(seat, chbuf);
				}
			}
		}
	}
	else
	{
		if ((mychid = get_chid(chname)) < 0)
		{
			Answer(WORK_FAIL);
			return -1;
		}

		Answer(OK_CMD);

		for (i = 0; i < MAXPORTS; i++)
		{
			if (*(Usrec[i].userid) == '\0')
				continue;
			if (Usrec[i].sock == -1)
				continue;
			if (Usrec[i].chid == mychid)
			{
				sprintf(chbuf, "%s\t%s\t%s\r\n", Usrec[i].userid, Usrec[i].nick, Usrec[i].from);
				send_to_user(seat, chbuf);
			}
		}
	}
	EndProt();
	return 0;
}


int
chat_whoall()
{
	register int i;
	int chid;

	Answer(OK_CMD);

	for (i = 0; i < MAXPORTS; i++)
	{
		if (*(Usrec[i].userid) == '\0')
			continue;
		if (Usrec[i].sock == -1)
			continue;

		chid = Usrec[i].chid;
		if (chid > 0)
			sprintf(chbuf, "%s\t%s\t%s\r\n", Usrec[i].userid, Usrec[i].nick, Chanrec[chid].chname);
		else if (chid == 0)
			sprintf(chbuf, "%s\t%s\t \r\n", Usrec[i].userid, Usrec[i].nick);	/* lthuang */
		else
			continue;	/* debug */
		send_to_user(seat, chbuf);
	}
	EndProt();
	return 0;
}


int
chat_user(userpass)
char *userpass;
{
	char user[IDLEN];
	int i;
	long password, idpass;

	if (*(Usrec[seat].userid) != '\0')
	{
		Answer(WORK_FAIL);
		return -1;
	}

	userpass = GetPass(userpass, user, IDLEN);
	userpass = PhaseSpace(userpass);

	password = atol(userpass);
	idpass = atol(idpassstr);

	if (password != idpass)	/* lthuang */
	{
		Answer(WORK_FAIL);
		return -1;
	}

	for (i = 0; i < MAXPORTS; i++)
	{
		if (*(Usrec[i].userid) == '\0')
			continue;
		if (Usrec[i].sock == -1)
			continue;
		if (!strcmp(Usrec[i].userid, user))
		{
			Answer(NAME_FAIL);
			return -1;
		}
	}
	strcpy(Usrec[seat].nick, user);
	strcpy(Usrec[seat].userid, user);	/* lthuang */
	Usrec[seat].bmop = FALSE;	/* lthuang */
	Usrec[seat].chid = 0;	/* lthuang */
	memset(Usrec[seat].bad, 0, 5);

	Answer(OK_CMD);
	return 0;
}


int
chat_nickname(nick)
char *nick;
{
	int i;

	nick = PhaseSpace(nick);
	if (*nick == '\0')
	{
		Answer(NAME_FAIL);
		return -1;
	}

	for (i = 0; i < MAXPORTS; i++)
	{
		if (*(Usrec[i].userid) == '\0')
			continue;
		if (Usrec[i].sock == -1)
			continue;
		if (!strcmp(Usrec[i].nick, nick))
		{
			Answer(NAME_FAIL);
			return -1;
		}
	}

	strncpy(Usrec[seat].nick, nick, IDLEN);
	Answer(OK_CMD);

	if (!BAD(Usrec[seat].bad, Usrec[seat].chid))
	{
		sprintf(chbuf, _msg_bbschatd_12, Usrec[seat].userid, nick);
		send_to_channel(Usrec[seat].chid, chbuf);
	}
	return 0;
}


int
chat_listchan()
{
	register int i;
	register char c;

	Answer(OK_CMD);

	for (i = 0; i < MAXCHANS; i++)
	{
		if (Chanrec[i].members == 0)	/* debug */
			continue;

		if (*(Chanrec[i].chname) == '\0')
			continue;
		if (*(Chanrec[i].passwd) == '\0')
			c = 'N';
		else
			c = 'S';

		sprintf(chbuf, "%s\t%s\t%s\t%d\t%c\r\n", Chanrec[i].chname, Chanrec[i].topic, Chanrec[i].op, Chanrec[i].members, c);
		send_to_user(seat, chbuf);
	}
	EndProt();
	return 0;
}


int
chat_ignore(bad)		/* -ToDo- allow to use the nickname or userid as target */
char *bad;
{
	register int i;
	int chatuid, mychid;

	bad = PhaseSpace(bad);

	mychid = Usrec[seat].chid;
	if (mychid > 0)
	{
		if (strcmp(Chanrec[mychid].op, Usrec[seat].userid))
		{
			Answer(PASS_FAIL);
			return -1;
		}
	}
	else if (mychid == 0)
	{
		if (!Usrec[seat].bmop)
		{
			Answer(PASS_FAIL);
			return -1;
		}
	}
	else
		/* debug */
	{
		Answer(PASS_FAIL);
		return -1;
	}

	chatuid = get_chatuid(bad);
	/* debug */
	if (chatuid >= 0 && Usrec[seat].chid >= 0
	    && Usrec[seat].chid == Usrec[chatuid].chid)
	{
		for (i = 0; i < 5; i++)
		{
			if (Usrec[chatuid].bad[i] == 0)
			{
/*              strncpy(Usrec[chatuid].bad[i], Chanrec[mychid].chname, CHANLEN - 1); */
				Usrec[chatuid].bad[i] = TOASCNUM(mychid);
				break;
			}
		}
		if (i == 5)	/* lthuang */
		{
			memset(Usrec[chatuid].bad, 0, 5);
			/* strncpy(Usrec[chatuid].bad[0], Chanrec[mychid].chname, CHANLEN - 1); */
			Usrec[chatuid].bad[0] = TOASCNUM(mychid);
		}
		Answer(OK_CMD);
		return 0;
	}
	Answer(WORK_FAIL);
	return -1;
}


int
main()
{
	int sock, length, flen, i;
	struct sockaddr_in server, client;
	char hostname[80];
	long seed;

	signal(SIGHUP, SIG_IGN);
	signal(SIGINT, SIG_IGN);
	signal(SIGQUIT, SIG_IGN);
	signal(SIGPIPE, SIG_IGN);
	signal(SIGALRM, SIG_IGN);
	signal(SIGTERM, SIG_IGN);
	signal(SIGURG, SIG_IGN);
	signal(SIGTSTP, SIG_IGN);
	signal(SIGTTIN, SIG_IGN);
	signal(SIGTTOU, SIG_IGN);
	signal(SIGCHLD, SIG_IGN);	/* lthuang */
	if ((i = fork()) == -1)
		exit(-1);
	if (i)
		exit(0);
	{
		int s, ndescriptors = getdtablesize();

		for (s = 0; s < ndescriptors; s++);
		(void) close(s);
	}
	(void) open("/dev/null", O_RDONLY);
	(void) dup2(0, 1);
	(void) dup2(0, 2);
#if	defined(SYSV)
	setsid();
#else
	{
		int tt = open("/dev/tty", O_RDWR);

		if (tt > 0)
		{
			ioctl(tt, TIOCNOTTY, (char *) 0);
			(void) close(tt);
		}
	}
#endif /* !SYSV */

	report("starting up");
	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock < 0)
	{
		report("socket");
		return -1;
	}
	i = 1;
	setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char *) &i, sizeof(i));
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_port = htons((u_short) CHATPORT);
	if (bind(sock, (struct sockaddr *) &server, sizeof server) < 0)
	{
		report("bind() failed: exiting");
		return -1;
	}
	length = sizeof server;
	if (getsockname(sock, (struct sockaddr *) &server, &length) < 0)
	{
		report("getsockname() failed: exiting");
		return -1;
	}
	listen(sock, 128);

	numports = 0;

	for (i = 0; i < MAXCHANS; i++)
	{
		Chanrec[i].chname[0] = '\0';
		Chanrec[i].topic[0] = '\0';
		Chanrec[i].op[0] = '\0';
		Chanrec[i].members = 0;
		Chanrec[i].passwd[0] = '\0';
	}

	strncpy(Chanrec[0].chname, DEF_CHANNAME, CHANLEN - 1);	/* lthuang */

	for (i = 0; i < MAXPORTS; i++)
	{
		Usrec[i].userid[0] = '\0';
		Usrec[i].nick[0] = '\0';
		Usrec[i].from[0] = '\0';
		Usrec[i].sock = -1;
		Usrec[i].chid = -1;
		Usrec[i].bmop = FALSE;
		memset(Usrec[i].bad, 0, 5);
	}

	while (1)
	{
		fd_set readfds;
		int sr;

		FD_ZERO(&readfds);
		FD_SET(sock, &readfds);
		for (i = 0; i < MAXPORTS; i++)
			if (Usrec[i].sock != -1)
				FD_SET(Usrec[i].sock, &readfds);
		if ((sr = select(getdtablesize(), &readfds, NULL, NULL, NULL)) < 0)
		{
			if (errno == EINTR)	/* lthuang */
				continue;
			report("select() failed: exiting");
			exit(-1);
		}
		if (sr == 0)	/* ? */
			continue;
		if (FD_ISSET(sock, &readfds))
		{
			int s;
			char seedstr[20];

			flen = sizeof(client);
			s = accept(sock, (struct sockaddr *) &client, &flen);
			if (s == -1)	/* lthuang */
				continue;
				
			seed = rand();
			sprintf(gbuf, "Formosa Chatroom Server Version. 1.0.0 by NSYSU\r\n");
			write(s, gbuf, strlen(gbuf));
			sprintf(gbuf, "%ld\r\n", seed);
			write(s, gbuf, strlen(gbuf));
			sprintf(seedstr, "%d", seed);
			idpassstr = mycrypt(seedstr);
			
			if (numports == MAXPORTS)
			{
				report("reach max port number");	/* lthuang */
				close(s);
			}
			else
			{
				for (i = 0; i < MAXPORTS; i++)
				{
					if (Usrec[i].sock == -1)
					{
						int aha = 1;
						Usrec[i].sock = s;
						Usrec[i].chid = 0;
						strncpy(Usrec[i].from, hostname, 15);
/* lmj */
						ioctl(s, O_NONBLOCK, &aha);
						ioctl(s, O_NDELAY, &aha);
						break;
					}
				}
				numports++;
				if (sr == 1)
					continue;
			}
		}

		for (seat = 0; seat < MAXPORTS; seat++)
		{
			int keynum;
			char *NextPass;
			char keypass[PROTOLEN];

			if (Usrec[seat].sock == -1)
				continue;
			if (FD_ISSET(Usrec[seat].sock, &readfds))
			{
				char rcvbuf[512];
				int cc;

			      re_read:
				memset(rcvbuf, '\0', sizeof(rcvbuf));
				cc = read(Usrec[seat].sock, rcvbuf, sizeof(rcvbuf) - 1);
				if (cc == 0)
				{
					chat_logout(seat);
					if (numports == 0)
					{
						report("normal termination");
/* last person closed connection
   exit(0) ;
 */
						break;	/* lthuang */
					}
					continue;
				}
				memset(keypass, '\0', sizeof(keypass));
				NextPass = GetPass(rcvbuf, keypass, PROTOLEN);
				keynum = GetPassNum(keypass);

				if (*(Usrec[seat].userid) == '\0')
				{
					if (keynum == CHAT_QUIT)
					{
						close(Usrec[seat].sock);
						Usrec[seat].sock = -1;
						Usrec[seat].from[0] = '\0';
						numports--;	/* lthuang */
						continue;
					}
					if (keynum != CHAT_USRID)
					{
						Answer(WORK_FAIL);
						continue;
					}
				}

				switch (keynum)
				{
				case CHAT_JOIN:
					chat_join(NextPass);
					break;
				case CHAT_USRID:
					if (chat_user(NextPass) == -1)
						chat_logout(seat);	/* lthuang */
					else
					{
						sprintf(chbuf, _msg_bbschatd_13, Usrec[seat].nick);
						if (Usrec[seat].chid >= 0)	/* debug */
							send_to_channel(Usrec[seat].chid, chbuf);
					}
					break;
				case CHAT_QUIT:
					sprintf(chbuf, _msg_bbschatd_15, Usrec[seat].nick);
					if (Usrec[seat].chid >= 0)	/* debug */
						send_to_channel(Usrec[seat].chid, chbuf);
					chat_logout(seat);
					break;
				case CHAT_TOPIC:
					chat_topic(NextPass);
					break;
				case CHAT_PASSWD:
					chat_passwd(NextPass);
					break;
				case CHAT_IGNORE:
					chat_ignore(NextPass);
					break;
				case CHAT_WHO:
					chat_who(NextPass);
					break;
				case CHAT_WHOALL:
					chat_whoall();
					break;
				case CHAT_MSG:
					chat_msg(NextPass);
					break;
#ifdef HAVE_CHATMSGALL
				case CHAT_MSGALL:
					chat_msgall(NextPass);
					break;
#endif
				case CHAT_NICKNAME:
					chat_nickname(NextPass);
					break;
				case CHAT_LISTCHAN:
					chat_listchan();
					break;
				case CHAT_SPEAK:	/* send all data to user */
					if (Usrec[seat].userid[0])
					{
						if (!BAD(Usrec[seat].bad, Usrec[seat].chid))
						{
							NextPass = PhaseSpace(NextPass);
							strncpy(gbuf, Usrec[seat].nick, IDLEN);
							gbuf[IDLEN-1] = '\0';
							strcat(gbuf, ":");
							sprintf(chbuf, "%-s:%-12.12s %.64s\r\n",
								Usrec[seat].userid, gbuf, NextPass);
							send_to_channel(Usrec[seat].chid, chbuf);
						}
					}
					/*
					   all complete messages end in
					   newline
					 */
					if (rcvbuf[cc - 1] == '\n' || rcvbuf[cc - 1] == '\r' || rcvbuf[cc - 1] == '\0')
						continue;

					goto re_read;
					break;
				case -1:
				default:
					Answer(CMD_ERROR);
				}
			}	/* if */
		}		/* for loop */
	}			/* while loop */
}

int
GetPassNum(keyword)
char *keyword;
{
	register int i;

	for (i = 0; i < (sizeof(fp) / sizeof(struct prot)); i++)

	{
		if (!strcmp(keyword, fp[i].keyword))
			return fp[i].num;
	}
	return -1;
}
