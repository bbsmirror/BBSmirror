/* 
   Li-te Huang, lthuang@cc.nsysu.edu.tw, 02/25/98
*/

#include "bbs.h"
#include "tsbbs.h"


char useridEdit[IDLEN];



int
a_info()
{
	USEREC urcEdit;

	if (!getdata(1, 0, _msg_ent_userid, useridEdit, sizeof(useridEdit), ECHONOSP, NULL))
		return M_FULL;
	if (get_passwd(&urcEdit, useridEdit) <= 0)
	{
		outs(_msg_err_userid);
		pressreturn();
		return M_FULL;
	}


	show_user_info(&urcEdit);
	if (!strcmp(urcEdit.userid, curuser.userid))
	{
		modify_user(&urcEdit, TRUE);	/* sysop modify by himself */
	}
	else
	{
		if (modify_user(&urcEdit, FALSE) == 1)	/* modify the others */
			log_usies("MODUSER", "'%s'", useridEdit);
	}
	return M_FULL;
}


#define MAX_BRDTYPE 6

char *brdtype[MAX_BRDTYPE] =
{
	_str_brdtype_ident,
	_str_brdtype_news,
	_str_brdtype_unzap,
	_str_brdtype_nopostnum,
	_str_brdtype_announce,
	_str_brdtype_invisible
};

static void
DisplayBoardRec(brdhr)
BOARDHEADER *brdhr;
{
	int i, j;
	unsigned char *pbits = &(brdhr->brdtype);


	move(2, 0);
	clrtobot();
	outs("======================================================================");
	prints("\n(1) %s %s", _msg_admin_2, brdhr->filename);
	prints("\n(2) %s %s", _msg_admin_bdesc, brdhr->title);
	prints("\n(3) %s %d", _msg_admin_blevel, brdhr->level);
	prints("\n(4) %s %c", _msg_admin_class, brdhr->class);
	prints("\n(5) %s %s", _msg_admin_owner, brdhr->owner);

	for (i = 0, j = 1; i < MAX_BRDTYPE; i++)
	{
		move(3 + i, 50);
		prints("(%c) %-10.10s : %s", 'A' + i, brdtype[i], (*pbits & j ? "Yes" : "No "));
		j <<= 1;
	}
	outs("\n======================================================================\n");
}


static int
SetBoardRec(brdhr, bCreate)
BOARDHEADER *brdhr;
BOOL bCreate;
{
	char choice[2];
	char inbuf[STRLEN];
	int i, j;
	unsigned char *pbits = &(brdhr->brdtype);
	char pathname[PATHLEN];


	while (1)
	{
		DisplayBoardRec(brdhr);
		if (!getdata(b_line - 1, 0, _msg_admin_1, choice, 2, ECHONOSP|LOWCASE, NULL))
			break;
		switch (choice[0])
		{
			/* board name */
		case '1':
			xstrncpy(inbuf, brdhr->filename, BNAME_LEN);
			if (getdata(15, 0, _msg_admin_2, inbuf, BNAME_LEN, ECHONOSP, brdhr->filename))
			{
				if (bCreate || strcmp(inbuf, brdhr->filename))
				{
					setboardfile(pathname, inbuf, NULL);
					if (invalid_bname(inbuf) || dashd(pathname)
					    || get_board(NULL, inbuf) > 0)
					{
						outs(_msg_admin_3);
						pressreturn();
						break;
					}
					xstrncpy(brdhr->filename, inbuf, BNAME_LEN);
				}
			}
			break;
		case '2':
			if (getdata(15, 0, _msg_admin_bdesc, inbuf, CBNAME_LEN + 1, DOECHO, brdhr->title))
			{
				xstrncpy(brdhr->title, inbuf, CBNAME_LEN + 1);
			}
			break;
		case '3':
			if (getdata(15, 0, _msg_admin_5, inbuf, 4, ECHONOSP, NULL))
				brdhr->level = atoi(inbuf);
			break;
		case '4':
			if (getdata(15, 0, _msg_admin_class, inbuf, 2, ECHONOSP, NULL))
				brdhr->class = inbuf[0];
			break;
		case '5':
			if (getdata(15, 0, _msg_admin_owner, inbuf, IDLEN, ECHONOSP, brdhr->owner))
				xstrncpy(brdhr->owner, inbuf, IDLEN);
			else
			{
				if (!bCreate)
				{
					getdata(16, 0, _msg_admin_8, inbuf, 2, ECHONOSP, NULL);
					if (inbuf[0] == 'y')
						brdhr->owner[0] = '\0';
				}
			}
			break;
		default:
			i = choice[0] - 'a';
			if (i >= 0 && i < MAX_BRDTYPE)
			{
				j = 1 << i;
				*pbits ^= j;
			}
			break;
		}
	}

	if (brdhr->filename[0] == '\0' || brdhr->title[0] == '\0'
	    || brdhr->class == '\0')
	{
		move(b_line - 1, 0);
		clrtoeol();
		outs(_msg_admin_9);
		pressreturn();
		return -1;
	}

	move(b_line - 1, 0);
	clrtoeol();
	outs(_msg_admin_10);
	if (igetkey() != 'y')
		return -1;

	if (brdhr->owner[0] != '\0')
	{
		USEREC urcNewBM;

		if (get_passwd(&urcNewBM, brdhr->owner) > 0)
		{
			if (urcNewBM.userlevel < PERM_BM)
			{
				urcNewBM.userlevel = PERM_BM;
				/* -ToDo- buggy when the user is online */
				update_user(&urcNewBM);
				log_usies("NEWBM", "'%s'", brdhr->owner);
			}
		}
	}
	else
	{
		if (!bCreate)
		{
			setboardfile(pathname, brdhr->filename, BM_ASSISTANT);
			unlink(pathname);
		}
	}
	DelBoardList();
	return 0;
}


int
a_modifybrd()
{
	char bname[BNAME_LEN];
	BOARDHEADER old_brdh, new_brdh;
	int ent;
	char pathname[PATHLEN];

	if (CompleteBoardName(bname) == -1)
		return M_FULL;

	setboardfile(pathname, bname, NULL);
	if (!dashd(pathname) || (ent = get_board(&old_brdh, bname)) <= 0)
	{
		outs("\n");
		outs(_msg_err_boardname);
		pressreturn();
		return M_FULL;
	}

	DisplayBoardRec(&old_brdh);

	outs("\n");
	outs(_msg_not_sure_modify);
	if (igetkey() != 'y')
		return M_FULL;

	memcpy(&new_brdh, &old_brdh, sizeof(new_brdh));

	if (SetBoardRec(&new_brdh, FALSE) == -1)
	{
		move(b_line - 1, 0);
		clrtoeol();
		outs(_msg_fail);
		pressreturn();
		return M_FULL;
	}

	if (strcmp(new_brdh.filename, old_brdh.filename))
	{
		char brd1[PATHLEN], trea1[PATHLEN], brd2[PATHLEN], trea2[PATHLEN];

#ifdef USE_VOTE
		char vote1[PATHLEN], vote2[PATHLEN];

		SetVotePath(vote1, old_brdh.filename);
		SetVotePath(vote2, new_brdh.filename);
#endif
		setboardfile(brd1, old_brdh.filename, NULL);
		setboardfile(brd2, new_brdh.filename, NULL);
		settreafile(trea1, old_brdh.filename, NULL);
		settreafile(trea2, new_brdh.filename, NULL);

		if (myrename(brd1, brd2) == 0)
		{
			if (myrename(trea1, trea2) == 0)
			{
#ifdef USE_VOTE
				if (!dashd(vote1))
					goto finish_modify_board;
				if (myrename(vote1, vote2) == 0)
#endif
					goto finish_modify_board;
				myrename(trea2, trea1);
			}
			myrename(brd2, brd1);
		}
		log_usies("ERR", "cannot rename board directory");
		move(b_line - 1, 0);
		clrtoeol();
		outs(_msg_fail);
		outs(_msg_admin_11);
		pressreturn();
		return M_FULL;
	}

  finish_modify_board:
	move(b_line - 1, 0);
	clrtoeol();
	if (substitute_record(BOARDS, &new_brdh, sizeof(new_brdh), ent) == -1)
	{
		log_usies("ERR", "cannot write board '%s'", new_brdh.filename);
		outs(_msg_fail);
	}
	else
	{
		if (strcmp(new_brdh.filename, old_brdh.filename))
			log_usies("MODBOARD", "'%s' => '%s'",
				  old_brdh.filename, new_brdh.filename);
		else
			log_usies("MODBOARD", "'%s'", old_brdh.filename);
		outs(_msg_finish);
		rebuild_brdshm();		
	}
	pressreturn();
	return M_FULL;
}


/* 
   pack the board, prune the articles marked deleted
 */
int
a_pack1brd()
{
	char bname[BNAME_LEN];
	char cmd[STRLEN];

	if (CompleteBoardName(bname) == -1)
		return M_FULL;
	if (get_board(NULL, bname) <= 0)
		outs(_msg_admin_12);
	else
	{
		sprintf(cmd, "packbbs -b \"%s\"", bname);
		outdoor(cmd, ADMIN, FALSE);
	}
	pressreturn();
	return M_FULL;
}


/* 
   append one new board record notn BOARDS
 */
static int
AppendNewBoardRec(bhr)
BOARDHEADER *bhr;
{
	int fd;
	unsigned int maxbid = 0;
	BOARDHEADER max_brdh;


	if ((fd = open(BOARDS, O_RDWR | O_CREAT, 0644)) > 0)
	{
		flock(fd, LOCK_EX);
		while (read(fd, &max_brdh, sizeof(max_brdh)) == sizeof(max_brdh))
		{
			if (max_brdh.filename[0] == '\0' || max_brdh.bid <= 0)
				continue;
			if (max_brdh.bid > maxbid)
				maxbid = max_brdh.bid;
		}
		if (maxbid <= 0)
			bhr->bid = 1;
		else
			bhr->bid = maxbid + 1;
		if (lseek(fd, 0, SEEK_END) != -1)
		{
			if (write(fd, bhr, BH_SIZE) == BH_SIZE)
			{
				flock(fd, LOCK_UN);
				close(fd);
				return bhr->bid;
			}
		}
		flock(fd, LOCK_UN);
		close(fd);
	}
	return 0;
}


int
a_newbrd()
{
	BOARDHEADER new_brdh;
	char new_treapath[PATHLEN], new_brdpath[PATHLEN];

	memset(&new_brdh, 0, sizeof(new_brdh));
	if (SetBoardRec(&new_brdh, TRUE) == -1)
	{
		move(b_line - 1, 0);
		clrtoeol();
		outs(_msg_fail);
		pressreturn();
		return M_FULL;
	}

	setboardfile(new_brdpath, new_brdh.filename, NULL);
	settreafile(new_treapath, new_brdh.filename, NULL);

	move(b_line - 1, 0);

	if (mkdir(new_brdpath, 0700) || mkdir(new_treapath, 0700))
	{
		outs(_msg_admin_13);
		log_usies("ERR", "create board '%s' path", new_brdh.filename);
		pressreturn();
		return M_FULL;
	}

	if (AppendNewBoardRec(&new_brdh) <= 0)
	{
		myunlink(new_brdpath);
		myunlink(new_treapath);
		log_usies("ERR", "write board '%s' record", new_brdh.filename);
		outs(_msg_failed);
	}
	else
	{
		char cmd[255];
		
		sprintf(cmd, "sortbrd %s", BOARDS);
		outdoor(cmd, ADMIN, FALSE);
		log_usies("NEWBOARD", "'%s'", new_brdh.filename);
		outs(_msg_finished);
		rebuild_brdshm();		
	}
	pressreturn();
	return M_FULL;
}


int
a_delbrd()
{
	char bname[BNAME_LEN];
	int ent;
	char pathname[PATHLEN];


	if (CompleteBoardName(bname) == -1)
		return M_FULL;
	if ((ent = get_board(NULL, bname)) <= 0)
	{
		outs("\n");
		outs(_msg_err_boardname);
		pressreturn();
		return M_FULL;
	}
	prints(_msg_admin_14, bname);
	if (igetkey() != 'y')
	{
		outs(_msg_aborted);
		pressreturn();
		return M_FULL;
	}

	if (delete_record(BOARDS, BH_SIZE, ent) == -1)
	{
		log_usies("ERR", "delete record of board '%s'", bname);
		outs(_msg_failed);
	}
	else
	{
		/* remove board */
		setboardfile(pathname, bname, NULL);
		myunlink(pathname);
		/* remove treasure */
		settreafile(pathname, bname, NULL);
		myunlink(pathname);
		/* remove vote */
		SetVotePath(pathname, bname);
		myunlink(pathname);

		log_usies("DELBOARD", "'%s'", bname);
		DelBoardList();
		rebuild_brdshm();		
		outs(_msg_finished);
	}
	pressreturn();
	return M_FULL;
}


#ifdef HAVE_DELUSER
int
a_deluser()
{
	char useridDel[IDLEN];
	char cmd[80];

	if (getdata(2, 0, _msg_ent_userid, useridDel, sizeof(useridDel), ECHONOSP, NULL))
	{
		sprintf(cmd, "deluser -u \"%s\"", useridDel);
		outdoor(cmd, ADMIN, FALSE);
		log_usies("DELUSER", "'%s'", useridDel);
		pressreturn();
	}
	return M_FULL;
}
#endif


int
a_welcome()
{
	if (vedit(WELCOME, NULL) < 0)
		outs("\nWelcome NOT changed.");
	else
		outs("\nWelcome updated.");
	pressreturn();
	return M_FULL;
}


/*
   edit the config file of bbs-news
 */
int
a_bbsnews()
{
	if (vedit(BBS_NEWS_CONF, NULL) < 0)
		outs("\nBBS-NEWS.conf NOT changed.");
	else
		outs("\nBBS-NEWS.conf updated.");
	pressreturn();
	return M_FULL;
}


int
a_classconf()
{
	if (vedit(CLASS_CONFILE, NULL) < 0)
		outs("\nCLASS.conf NOT changed.");
	else
	{
		outs("\nCLASS.conf updated.");
/*		
		rebuild_classhm();
*/		
	}
	pressreturn();
	return M_FULL;
}


int
a_cloak()
{
	uinfo.invisible = (uinfo.invisible) ? FALSE : TRUE;
	update_ulist(cutmp, &uinfo);
	move(2, 0);
	clrtoeol();
	prints(_msg_admin_15, (uinfo.invisible) ? _msg_on : _msg_off);
	pressreturn();
	return M_FULL;
}


char kiuserid[IDLEN];
int kick_cnt;

int 
kick_user(upent)
USER_INFO *upent;
{
	if (!upent || upent->userid[0] == '\0')
		return -1;
	if (strcmp(upent->userid, kiuserid))
		return -1;
	if (upent->pid > 2)
		kill(upent->pid, SIGKILL);
	/* do not write back user data */
	purge_ulist(upent);
	kick_cnt++;
	return 0;
}


int
a_kick()
{
	if (CompleteOnlineUser(kiuserid) == 0)
	{
		prints(_msg_admin_16, kiuserid);
		if (igetkey() != 'y')
		{
			outs(_msg_aborted);
			pressreturn();
			return M_FULL;
		}
		kick_cnt = 0;
		apply_ulist(kick_user);
		log_usies("KICK", "'%s'", kiuserid);
		prints(_msg_admin_17, kiuserid, kick_cnt);
		pressreturn();
	}
	return M_FULL;
}


static int
broadcast(upent)
USER_INFO *upent;
{
	if (!upent || upent->userid[0] == '\0')
		return -1;
	if (!strcmp(upent->userid, curuser.userid))
		return -1;
	if (InOutdoor(upent))
		return -1;
	DoMessageUser(upent);
	return 0;
}


/*
   broadcast to all of the users online
 */
int
a_broadcast()
{
	if (PrepareMesgContent(_msg_admin_18) == 0)
	{
		apply_ulist(broadcast);
		msg(_msg_message_finish);
		getkey();
	}
	return M_FULL;
}


int
invalid_bname(bname)
char *bname;
{
	register unsigned char ch;
	register int i;

	if (!bname || bname[0] == '\0')
		return 1;
	if (strlen(bname) >= BNAME_LEN)
		return 1;
	for (i = 0; (ch = bname[i]); i++)
	{
		if (!isalnum(ch) && ch != '-' && ch != '_')
			return 1;
	}
	return 0;
}
