
#include "bbs.h"
#include "tsbbs.h"


#define PUTCURS   move(c+4,0);prints(_str_cursor);
#define RMVCURS   move(c+4,0);prints(_str_uncurs);

/* big fileheader buffer for read folder entry */
FILEHEADER *fheads = NULL;

/* the postion of cursor in treausre folder */
int t_top[TREASURE_DEPTH], t_cur[TREASURE_DEPTH];	

/* the postion of cursor in mail folder */
int mailtop, mailcur;	

int nowdepth = 1;

char memtitle[STRLEN];


/*******************************************************************
 * �N DIR_REC �����Ū�J�}�C��, �Ǧ^Ū��X��
 *******************************************************************/
int
get_list(direct, top)
char *direct;
int top;
{
	int fd;
	register int total = 0;

	/* limit the number of articles showed in mail folder */
	if (!HAS_PERM(PERM_SYSOP) && in_mail && top > maxkeepmail)
		return 0;

	if ((fd = open(direct, O_RDONLY)) > 0)
	{
		if (lseek(fd, (off_t) (FH_SIZE * (top - 1)), SEEK_SET) != -1)
		{
			total = read(fd, &(fheads[total]), FH_SIZE * (SCREEN_SIZE - 4));
			if (total != -1 && total % FH_SIZE == 0)
			{
				close(fd);
				return (total / FH_SIZE);
			}
		}
		close(fd);
	}
	return 0;
}


/*
   show title in mail folder menu
*/    
void
mail_title()
{
	outs(_msg_read_1);
}


/*
   show title in board/treasure folder menu
*/
void
post_title()
{
	prints(_msg_read_2, READ_TITLE_COLOR, CurBList->owner, READ_TITLE_COLOR2,
	       (in_board ? _msg_board_normal : _msg_board_treasure), CurBList->name);
	outs(_msg_read_3);
}


void
chk_str(str)
char str[];
{
	static char t[STRLEN];
	register char *p = str;
	register int j;

	for (j = 0; p && *p && j < STRLEN; j++)
	{
		if (*p == ESC && *(p + 1) == '[')
		{
			if (*(p + 2) == '\0')
				break;
			p += 3;
		}
		else if (*p == NL || *p == 0x0d || *p == TAB)	/* 0x0d is cr */
			p += 1;
		t[j] = *p++;
	}
	t[j] = '\0';
	strcpy(str, t);
}


/*******************************************************************
 * �C�LŪ Post �ɪ� Index List Lines
 *******************************************************************/
void
read_ent(ent, c, total, num)
FILEHEADER ent[];
int c, total;
int num;
{
	register int i;
	register BOOL chkcolor;	/* Check If colorful */
	static char testtitle[STRLEN] = STR_REPLY;
	char chdate[9], sname[IDLEN + 3], buf[128] = "";
	time_t date;
	struct tm *tm;

	/* make memtitle as no Re: */
	if (!strncmp(memtitle, STR_REPLY, REPLY_LEN))
		strcpy(memtitle, memtitle + REPLY_LEN);

	/* make testtitle as have Re: */
	strcpy(testtitle + REPLY_LEN, memtitle);

	move(c, 0);
	for (i = 0; i < total; i++)
	{
		chkcolor = TRUE;	/* assume have color */
		chk_str(ent[i].title);
		chk_str(ent[i].owner);

		date = atol((ent[i].filename) + 2);
		tm = localtime(&date);			/* by lmj */
		sprintf(chdate, "%02d.%02d.%02d",
			tm->tm_year - 11, tm->tm_mon + 1, tm->tm_mday);

		/* if treausure sub-folder */
		if (ent[i].accessed & FILE_TREA)
			sprintf(buf, "  %4d    [1;36m%s[m         %s  %s",
				num++, _msg_read_4, chdate, ent[i].title);
		else
		{
			register char type;
			
			if (ent[i].accessed & FILE_DELE)
				type = 'D';
			else if (cmp_wlist(artwtop, ent[i].filename, strcmp))
				type = '*';
			else if (in_mail)
			{
				if (ent[i].accessed & FILE_RESRV)
					type = (ent[i].accessed & FILE_READ) ? 'g' : 'G';
				else
					type = (ent[i].accessed & FILE_READ) ? ' ' : 'N';
			}
			else if (in_board)
			{
				if (ent[i].accessed & FILE_RESRV)
					type = (ReadRC_UnRead(ent[i].artno)) ? 'G' : 'g';
				else
					type = (ReadRC_UnRead(ent[i].artno)) ? 'N' : ' ';
			}
			else
			{
				/* �Y����ذ�, �h�ҵ����wŪ�L */
				type = ' ';
			}

			if (ent[i].owner[0] == '#' || strchr(ent[i].owner, '@') || strchr(ent[i].owner, '.'))
			{
				register char *name_end, *name_st, c;
				
				name_st = name_end = ent[i].owner;
				while ((c = *name_end) != '\0')
				{
					if (c == '.' || c == '@' || c == ' ')
						break;
					name_end++;
				}
				strcpy(sname, " #");
				if (*name_st == '#')
					name_st++;
				strncat(sname, name_st, MIN(name_end - name_st, 12));
			}
			else
			{
				sprintf(sname, "  %-12.12s", ent[i].owner);
#if HAVE_IDENT
				if (curuser.ident == 7 && ent[i].ident == 7)
					memcpy(sname, _str_marker, 2);
#endif
			}
			if (type == 'D')
			{
				sprintf(buf, _msg_read_7, num++, type, sname, chdate, ent[i].title + sizeof(ent[i].title) - IDLEN);
				chkcolor = 0;
			}
			else if (type == 'F')
			{
				sprintf(buf, "  %4d %c %-14s  %s  %s",
				   num++, type, sname, chdate, _msg_read_8);
				chkcolor = 0;
			}
			else if (type == 'A')
			{
				sprintf(buf, "  %4d %c %-14s  %s  %s",
				   num++, type, sname, chdate, _msg_read_9);
				chkcolor = 0;
			}
			else if (!strcmp(ent[i].title, memtitle))
				sprintf(buf, "  %4d %c %-14s  %s [1;32m#%s", num++, type, sname, chdate, ent[i].title);
			else if (!strcmp(ent[i].title, testtitle))
				sprintf(buf, "  %4d %c %-14s  %s [1;33m#%s", num++, type, sname, chdate, ent[i].title);
			else
			{
				sprintf(buf, "  %4d %c %-14s  %s  %s", num++, type, sname, chdate, ent[i].title);
				chkcolor = 0;
			}
		}
		if (chkcolor)	/* check string length */
		{		
			if (strlen(buf) > 86)
				sprintf(buf + 85, "%s", "[m");
			else
				strcat(buf, "[m");
		}
		else
			buf[78] = '\0';
		outs(buf);
		outs("\n");
	}
}


int
select_item(direct, stop, scur, total, the_num)
char *direct;
int *stop, *scur;
int *total;
int the_num;
{
	int i, itop = *stop;

	while (the_num - itop >= (SCREEN_SIZE - 4))
		itop += (SCREEN_SIZE - 4);
	while (the_num < itop)
		itop -= (SCREEN_SIZE - 4);
	if (itop < 1)
		itop = 1;
	if ((i = get_list(direct, itop)) > 0)
	{
		*total = i;	/* �u���s�J */
		*scur = the_num;
		if (itop != *stop)
		{
			*stop = itop;
			return R_PART;
		}
		*stop = itop;
	}
	return R_LINE;
}


quit_iread(direct)
char *direct;
{
	artwtop = free_wlist(artwtop, free);
/* �h�ƴ�@ */
	if (!in_mail && !in_board)
	{
		if (nowdepth > 1)
		{
			*(strrchr(direct, '/')) = '\0';
			strcpy(strrchr(direct, '/') + 1, DIR_REC);
			nowdepth--;
			return -1;
		}
	}
	else if (in_board)
	{
		memset(t_top, 0, sizeof(t_top));
		memset(t_cur, 0, sizeof(t_cur));
	}
	return 0;
}


/*******************************************************************
 * Cursor Reading Menu
 *******************************************************************/
int 
i_read(direct, comm, action)
char *direct;
struct one_key *comm;
char action;
{
	void (*ireadtitle) () = NULL;
	void (*ireadent) () = NULL;

	int total, c = 0, last = 0, mode, i, ch = 0;
	int *stop = NULL, *scur = NULL;
	char cmps_owner[31], cmps_title[STRLEN], *cmps_str;
	int srchno;
	char spattern[STRLEN];	

	if (fheads == NULL)
	{
		fheads = (FILEHEADER *) malloc(FH_SIZE * (SCREEN_SIZE - 4));
		if (fheads == NULL)
			return -1;
	}

	cmps_owner[0] = '\0';
	cmps_title[0] = '\0';

	mode = R_NEW;

	while (1)
	{
		if (talkrequest)
		{
			talkreply();
			mode = R_FULL;
		}
		else if (writerequest)
		{
			writereply();
			mode = R_FULL;
		}
		switch (mode)
		{
		case CAREYDOWN:
			if (ch != 'r')
				RMVCURS;
			*scur = *stop + c;
			if (c == total - 1)
			{
				if (*scur == last)
				{
					mode = (ch == 'r') ? R_FULL : R_NO;
				}
				else
				{
					if ((total = get_list(direct, *scur + 1)) <= 0)
					{
						bell();
						if (quit_iread(direct) == 0)
							return 0;
						mode = R_NEW;
					}
					else
					{
						c = 0;
						(*scur)++;
						*stop = *scur;
						mode = R_PART;
						if (ch == 'r')
						{
							strcpy(memtitle, fheads[c].title);
							mode = read_article(*stop + c, &(fheads[c]), direct);
						}
					}
				}
				continue;
			}
			c++;
			(*scur)++;
			if (ch == 'r')
			{
				strcpy(memtitle, fheads[c].title);
				mode = read_article(*stop + c, &(fheads[c]), direct);
				continue;
			}
			break;
		case CAREYUP:
			if (ch != 'r')
				RMVCURS;
			*scur = *stop + c;
			if (c == 0)
			{
				if (*scur == 1)
				{
					mode = (ch == 'r') ? R_FULL : R_NO;
				}
				else
				{
					if (*stop > (SCREEN_SIZE - 4))
						*stop -= (SCREEN_SIZE - 4);
					else
						*stop = 1;
					if ((total = get_list(direct, (*stop))) <= 0)
					{
						if (quit_iread(direct) == 0)
							return 0;
						mode = R_NEW;
					}
					else
					{
						c = total - 1;
						(*scur)--;
						mode = R_PART;
						if (ch == 'r')
						{
							if (fheads[c].accessed & FILE_TREA)
								mode = R_FULL;
							else
							{
								strcpy(memtitle, fheads[c].title);
								mode = read_article(*stop + c, &(fheads[c]), direct);
							}
						}
					}
				}
				continue;
			}
			c--;
			(*scur)--;
			if (ch == 'r')
			{
				if (fheads[c].accessed & FILE_TREA)
					mode = R_FULL;
				else
				{
					strcpy(memtitle, fheads[c].title);
					mode = read_article(*stop + c, &(fheads[c]), direct);
				}
				continue;
			}
			break;
		case R_NEW:
			clear();
			last = get_num_records(direct, FH_SIZE);
			if (!in_mail && !in_board)
			{
				if (last == 0)
				{
					outs(_msg_read_10);
					pressreturn();
					if (nowdepth == 1)
					{
						in_board = 1;
						setboardfile(direct, CurBList->name, DIR_REC);
					}
					else
					{
						/* �^��W�h��ذ� * */
						nowdepth--;
						*(strrchr(direct, '/')) = '\0';
						strcpy(strrchr(direct, '/') + 1, DIR_REC);
					}
					mode = R_NEW;
					continue;
				}
				ireadtitle = post_title;
				ireadent = read_ent;
				stop = &(t_top[nowdepth - 1]);
				scur = &(t_cur[nowdepth - 1]);
			}
			else if (in_mail)
			{
				nowdepth = 1;
				if (last == 0)
				{
#if HAVE_IDENT
					if (action == IREAD_ICHECK || action == IREAD_IFIND)
						outs(_msg_read_11);
					else
#endif
						outs(_msg_read_12);
					pressreturn();
					return 0;
				}
				stop = &mailtop;
				scur = &mailcur;
				ireadtitle = mail_title;
				ireadent = read_ent;
			}
			else
			{
				if (last == 0)
				{
					outs(_msg_read_13);
					if (igetkey() == 'n')
						return 0;
					do_post(0, NULL, NULL);		/* lthuang */
					last = get_num_records(direct, FH_SIZE);
					if (last == 0)
						return 0;
				}
				setboardfile(genbuf, CurBList->name, BM_WELCOME);
				if (CurBList->visit_flag < 2)
				{
					more(genbuf, TRUE);
					clear();
					if (display_bmas() > 0)
						pressreturn();
					clear();
				}
				stop = &(CurBList->btop);
				scur = &(CurBList->bcur);
				ireadtitle = post_title;
				ireadent = read_ent;
			}
			if (*stop <= 0 || *scur <= 0 || *scur > last || *stop > *scur)
			{
				if (in_board || in_mail)
				{
					if (last > (SCREEN_SIZE - 4))
						*stop = last - (SCREEN_SIZE - 4) + 1;
					else
						*stop = 1;
					*scur = last;
				}
				else
				{
					*stop = *scur = 1;
				}
			}
			total = get_list(direct, *stop);	/* ? */
/* del by lthuang
   c = *scur - *stop;
 */
		case R_FULL:
			clear();
			ireadtitle();
		case R_PART:
			c = *scur - *stop;	/* lthuang ? */
			move(4, 0);
			clrtobot();
			ireadent(&(fheads[0]), 4, total, *stop);
			move(b_line, 0);
			prints(_msg_read_14, READ_BTITLE_COLOR);
			break;
		case R_LINE:
			RMVCURS;	/* lthuang ? */
			c = *scur - *stop;	/* lthuang ? */
			move(4 + c, 0);
			clrtoeol();
			ireadent(&(fheads[c]), c + 4, 1, *stop + c);
			move(b_line, 0);
			prints(_msg_read_14, READ_BTITLE_COLOR);
			break;
		default:
			break;
		}

		PUTCURS;

		mode = R_NO;	/* lthuang */
		ch = getkey();
		if (isdigit(ch))
		{
			int nbuf_num;
			char nbuf[6];

			nbuf[0] = ch;
			nbuf[1] = '\0';

			getdata(b_line, 0, _msg_read_15, nbuf, sizeof(nbuf), ECHONOSP, nbuf);
			nbuf_num = atoi(nbuf);
			if (nbuf_num > last || nbuf_num < 1)
			{
				bell();
				mode = R_LINE;
			}
			else
				mode = select_item(direct, stop, scur, &total, nbuf_num);
			continue;
		}
		switch (ch)
		{
		case KEY_DOWN:
		case 'n':
			mode = CAREYDOWN;
			break;
		case KEY_HOME:
			mode = select_item(direct, stop, scur, &total, 1);
			break;
		case '$':
		case KEY_END:
			mode = select_item(direct, stop, scur, &total, last);
			break;
		case '\n':
		case '\r':
		case KEY_RIGHT:
			ch = 'r';
		case 'r':
#if	HAVE_IDENT
#if defined(SYSOP_BIN)
			if (action == IREAD_IFIND)
			{
				char file1[PATHLEN];

				setuserfile(file1, fheads[c].filename, BBSPATH_REALUSER);
				more(file1, TRUE);
				mode = R_FULL;
				continue;
			}
#endif			
#endif
			if (fheads[c].accessed & FILE_TREA)
			{
				artwtop = free_wlist(artwtop, free);
				sprintf(strrchr(direct, '/'), "/%s/%s", fheads[c].filename, DIR_REC);
				nowdepth++;
				mode = R_NEW;
			}
			else
			{
				strcpy(memtitle, fheads[c].title);
				mode = read_article(*stop + c, &(fheads[c]), direct);
			}
			break;
		case KEY_UP:
		case 'p':
			mode = CAREYUP;
			break;
		case KEY_LEFT:
		case 'q':
		case 'e':
			if (quit_iread(direct) == 0)
				return 0;
			mode = R_NEW;
			break;
		case KEY_PGDN:
		case ' ':
		case 'N':
		case CTRL('F'):
			RMVCURS;	/* lthuang */
			c = total - 1;
			mode = CAREYDOWN;
			break;
		case KEY_PGUP:
		case 'P':
		case CTRL('B'):
			RMVCURS;	/* lthuang */
			c = 0;
			mode = CAREYUP;
			break;
		case CTRL('L'):
			redoscr();
			break;
		case CTRL('T'):
			if (getdata(b_line, 0, _msg_read_18, genbuf, 2, ECHONOSP, NULL))
			{
				int total_target;

				artwtop = free_wlist(artwtop, free);
				switch (genbuf[0])
				{
				case '1':
					strcpy(cmps_title, fheads[c].title);
					getdata(b_line, 0, _msg_title, cmps_title, sizeof(cmps_title), DOECHO, cmps_title);
					cmps_str = cmps_title;
					ch = '>';
					break;
				case '2':
					strcpy(cmps_owner, fheads[c].owner);
					getdata(b_line, 0, _msg_read_20, cmps_owner, sizeof(cmps_owner), ECHONOSP, cmps_owner);
					cmps_str = cmps_owner;
					ch = 'A';
					break;
				}
				if (cmps_str[0])
				{
					msg(_msg_read_21);
					refresh();
					total_target = search_article(direct, 0, cmps_str, ch, &artwtop);
					msg(_msg_read_22, total_target);
					getkey();
					mode = R_FULL;
					continue;
				}
			}
			mode = R_LINE;
			break;
		case 'a':
		case 'A':
			sprintf(genbuf, _msg_read_16,
				(ch == 'A') ? _msg_forward : _msg_backward, cmps_owner);
			if (getdata(b_line, 0, genbuf, spattern, 15, ECHONOSP, NULL))
				strcpy(cmps_owner, spattern);
			cmps_str = cmps_owner;
			goto search_label;

		case '?':
		case '/':
		case '<':
		case '>':
			sprintf(genbuf, _msg_read_17,
				(ch == '>' || ch == '/') ? _msg_forward : _msg_backward, cmps_title);
			if (getdata(b_line, 0, genbuf, spattern, 40, DOECHO, NULL))
				strcpy(cmps_title, spattern);
			cmps_str = cmps_title;
			goto search_label;
			
		case '=':	/* by ming */
			if (!strncmp(STR_REPLY, fheads[c].title, REPLY_LEN))
			{
				strcpy(cmps_title, fheads[c].title + REPLY_LEN);
				cmps_str = cmps_title;
				goto search_label;
			}
			break;
		case '[':
		case ']':
			if (fheads[c].accessed & FILE_DELE)
				continue;
			if (ch == '['
			    && strncmp(fheads[c].title, STR_REPLY, REPLY_LEN))
			{
				continue;
			}
			strcpy(cmps_title, fheads[c].title);
			cmps_str = cmps_title;
		      search_label:
			if (cmps_str[0] == '\0')
			{
				mode = R_LINE;
				continue;
			}
			msg(_msg_read_21);
			refresh();
			if ((srchno = search_article(direct, *stop + c, cmps_str, ch, NULL)) < 0)
			{
				msg(_msg_read_23,
				    (strchr("A>]", ch)) ? _msg_forward : _msg_backward);
				getkey();
				mode = R_LINE;
				continue;
			}
			*scur = srchno;
			mode = select_item(direct, stop, scur, &total, srchno);
			break;
		case 'U':
			if (fheads[c].owner[0] != '#' && !strchr(fheads[c].owner, '.') &&
			    !strchr(fheads[c].owner, '@'))
			{
				if (QueryUser(fheads[c].owner) == -1)
					mode = R_NO;
				else
					mode = R_FULL;
			}
			break;
		case CTRL('R'):
			ReplyLastCall();
			mode = R_FULL;
			break;
		default:
			for (i = 0; comm[i].fptr; i++)
			{
				if (comm[i].key == ch)
				{
					mode = (*(comm[i].fptr)) (*stop + c, &(fheads[c]), direct);
					break;;
				}
			}
			break;
		}
	}
}
