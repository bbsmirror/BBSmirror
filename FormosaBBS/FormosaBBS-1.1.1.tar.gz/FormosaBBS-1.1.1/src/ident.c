
#include "bbs.h"
#include "tsbbs.h"

#if HAVE_IDENT

#ifdef SYSOP_BIN


extern int a_find_user();
extern int a_level();


struct one_key find_comms[] =
{
	'f', a_find_user,
	'l', a_level,
	'\0', NULL
};


struct one_key check_comms[] =
{
	'd', delete_article,
	'T', range_delete_article,	/* lthuang */
	'\0', NULL
};




int
a_level()
{
	char name[IDLEN], num[2];
	USEREC initial;

	clear();
	getdata(0, 0, _msg_ident_1, name, sizeof(name), ECHONOSP, NULL);
	if (get_passwd(&initial, name) <= 0)
	{
		outs(_msg_err_userid);
		return M_FULL;
	}
	getdata(1, 0, _msg_ident_2, num, sizeof(num), ECHONOSP, NULL);
	initial.ident = atoi(num);
	if (initial.ident > 7 || initial.ident < 0)
		initial.ident = 0;
	outs(_msg_not_sure_modify);
	if (igetkey() == 'y')
		update_user(&initial);
	return M_FULL;
}


int
a_find_user()
{
	char name[IDLEN], file1[PATHLEN];

	if (!getdata(b_line, 0, _msg_ident_3, name, sizeof(name), ECHONOSP, NULL))
		return M_FULL;

	setuserfile(file1, name, BBSPATH_REALUSER);
	if (more(file1, TRUE) == -1)
	{
		msg(_msg_ident_4);
		return M_FULL;
	}
	return M_FULL;
}


int
a_find()
{
	char tmp_direct[PATHLEN];


	in_mail = TRUE;
	setuserfile(tmp_direct, DIR_REC, BBSPATH_REALUSER);
	i_read(tmp_direct, &find_comms[0], IREAD_IFIND);
	in_mail = FALSE;
}


int
a_check()
{
	char save_bname[BNAME_LEN];
	char tmp_direct[PATHLEN];


	if (!CurBList || !CurBList->name)
		return M_FULL;

	strcpy(save_bname, CurBList->name);
	strcpy(CurBList->name, "ID");

	in_board = TRUE;

	setboardfile(tmp_direct, "ID", DIR_REC);
	i_read(tmp_direct, &check_comms[0], IREAD_ICHECK);

	strcpy(CurBList->name, save_bname);

	return M_FULL;
}


int
a_ok(name, cond)		/* write check level */
char name[15];
char cond;
{
	USEREC initial;

	if (get_passwd(&initial, name) <= 0)
		return M_FULL;
	initial.ident = cond;
	update_user(&initial);
}
#endif /* SYSOP_BIN */


int
id_num_check(num)		/* �����Ҧr���ˬd */
char *num;
{
	char *p, LEAD[] = "ABCDEFGHJKLMNPQRSTUVXYWZIO";
	int x, i;

	if (strlen(num) != 10 || (p = strchr(LEAD, toupper(*num))) == NULL)
		return 0;
	x = p - LEAD + 10;
	x = (x / 10) + (x % 10) * 9;
	p = num + 1;
	if (*p != '1' && *p != '2')
		return 0;
	for (i = 1; i < 9; i++)
	{
		if (!isdigit(*p))
			return 0;
		x += (*p++ - '0') * (9 - i);
	}
	x = 10 - x % 10;
	x = x % 10;
	return (x == *p - '0');
/*
   x += *p - '0';
   return ( x % 10 == 0);
 */
}


int
send_checkmail(email, buf)
char email[];
char buf[];
{
	char *id, *p, tmp[128];
	int ms;
	FILE *fp;

	if ((p = strchr(email, '.')) != NULL)
		if (strchr(p, '@') != NULL)
			return;
	if ((ms = CreateMailSocket()) < 0)
	{
		msg(_msg_ident_8);
		getkey();
		return;
	}
	if ((fp = fopen("doc/ID_Check_Doc", "r")) == NULL)
		return;
	outs(_msg_ident_9);
	id = strstr(buf, "M.");
	sprintf(tmp, "MAIL FROM: syscheck@%s\n", MYHOSTNAME);
	net_printf(ms, tmp);
	if (!net_gets(ms, genbuf, sizeof(genbuf)))
		return;
	net_printf(ms, "RCPT TO: %-s\n", email);
	if (!net_gets(ms, genbuf, sizeof(genbuf)))
		return;
	net_printf(ms, "DATA\n");
	if (!net_gets(ms, genbuf, sizeof(genbuf)))
		return;
	sprintf(tmp, "From: syscheck@%s\n", MYHOSTNAME);
	net_printf(ms, tmp);
	net_printf(ms, "To: %-s\n", email);
	net_printf(ms, "Subject: FORMOSA_BBS ( %s %s )\n\n", curuser.userid, id);
	while (fgets(genbuf, sizeof(genbuf), fp))
		net_printf(ms, "%s", genbuf);
	fclose(fp);
	net_printf(ms, "\n.\n");
	if (!net_gets(ms, genbuf, sizeof(genbuf)))
		return;
	CloseMailSocket(ms);
	log_usies("SENDCKM", "'%s'", email);	/* lthuang */
}


/*
 * Check Chinese string
 */
int
check_cname(name)
unsigned char name[];
{
	int i = strlen(name);

	if (i == 0 || (i % 2) == 1)
		return -1;
	while ((i = i - 2) >= 0)
		if (name[i] < 128)
			return -1;
	return 0;
}


do_post_ident()
{
	char title[STRLEN], *p, buf[STRLEN], stamp[14];
	FILE *fp_udata, *fp_ckdoc;
	char email[80];

	char *check_item[] =
	{
		_msg_ident_item1,
		_msg_ident_item2,
		_msg_ident_item3,
		_msg_ident_item4,
		_msg_ident_item5,
		_msg_ident_item6,
		_msg_ident_item7,
		_msg_ident_item8,
		_msg_ident_item9,
		NULL
	};
	char fn_ckdoc[] = "doc/Check_Doc0", idcard[30], loop;
	time_t now;
	BOOL is_postcard = FALSE;
	char identfile[PATHLEN];
	int errflag = 0;

	/* wnlee :�U���ܼƬO�ڵ��ΦW�D�����U�ŧi�� */

	char path[] = "conf/deny_email_host";
	char buf_host[50];
	char *ptr;
	register int counter = 1, compare = 1;
	FILE *fp_deny_email_host, *fp_create;

	sprintf(identfile, "tmp/ident_%s", curuser.userid);

	clear();
	outs(_msg_ident_10);
	if (igetkey() != 'y')
		return M_FULL;
	if ((fp_udata = fopen(identfile, "w")) == NULL)
	{
		outs(_msg_ident_11);
		pressreturn();
		return M_FULL;
	}
	clear();
	outs(_msg_ident_12);

	/* Input User Data */
	for (loop = 0; check_item[loop] != NULL; loop++)
	{
		/* �C�L���� */
		fn_ckdoc[13]++;
		if ((fp_ckdoc = fopen(fn_ckdoc, "r")) != NULL)
		{
			move(11, 0);
			clrtobot();
			while (fgets(buf, 80, fp_ckdoc) != NULL)
				outs(buf);
			fclose(fp_ckdoc);
		}
		/* ���� */
		switch (*check_item[loop])
		{
		case '1':
			do
			{
				move(2 + loop, 0);
				clrtoeol();
				getdata(2 + loop, 0, check_item[loop] + 1, buf, STRLEN - 12, ECHONOSP, NULL);
			}
			while (check_cname(buf));
			strcat(buf, "  (");
			strcat(buf, curuser.userid);
			strcat(buf, ")");
			break;
		case '2':
		case '4':
		case '6':
		case '7':
		case '9':
			do
			{
				move(2 + loop, 0);
				clrtoeol();
				getdata(2 + loop, 0, check_item[loop] + 1, buf, STRLEN - 12, DOECHO, NULL);
			}
			while (buf[0] == '\0');
			break;
		case '3':
			move(2 + loop, 0);
			clrtoeol();
			getdata(2 + loop, 0, check_item[loop] + 1, buf, STRLEN - 12, DOECHO, NULL);
			break;
		case '5':
			do
			{
				move(2 + loop, 0);
				clrtoeol();
				getdata(2 + loop, 0, check_item[loop] + 1, buf, STRLEN - 12, ECHONOSP, NULL);
				if (buf[0] != '\0' && !id_num_check(buf))
				{
					move(3 + loop, 0);
					outs(_msg_ident_13);
					if (igetkey() == 'y')
						is_postcard = TRUE;
					else
					{
						errflag++;
					}
				}
			}
			while (buf[0] == '\0');
			strcpy(idcard, buf);
			break;
		case '8':
		/* wnlee : deny the anonymous e-mail account */

			/* test if the file "deny_email_host" exist.
			 * if not, use fopen with arguement "a" to 
			 * creat :)
			 */
			fp_deny_email_host = fopen(path, "r");
			if ( fp_deny_email_host == NULL)
			{
				fp_create = fopen(path, "a");
				fclose(fp_create);
				fclose(fp_deny_email_host);
			}
			else
			{
				fclose( fp_deny_email_host);
			}

			counter = 1;
			do
			{
				buf[0] = '\0';
				do
				{
					move(2 + loop, 0);
					clrtoeol();
					getdata(2 + loop, 0, check_item[loop] + 1, buf, STRLEN - 12, ECHONOSP, NULL);
					if ((p = strchr(buf, '@')) != NULL)
					{
						for (p++; !isalpha(*p) && *p != '\0'; p++)
							/* NULL STATEMENT */ ;
						if (*p != '\0')
							break;
					}
				}
				while (1);


				p = strstr(buf, "@") + 1;
				if ( counter > 1 )
				{
					fclose( fp_deny_email_host );
				}
				fp_deny_email_host = fopen(path, "r");
				if( fp_deny_email_host == NULL )
				{
					outs(_msg_ident_21);
					pressreturn();
					return M_FULL;
				}


				while( fgets(buf_host, sizeof(buf_host), fp_deny_email_host) )
					/* �p�G�w�g��缾�ΦW�D�������C�@�����
					 * �N���X while �^��
 					 */
				{
					ptr = strchr(buf_host, '\n');
					ptr[0] = '\0';

					compare = strcmp(p, buf_host);
					
					if ( !compare )
					/* �p�G���D���W�ٲŦX�A
					 * �h�������X do-while
					 */
					{
						break;
					}
				}
				counter++; 
			}
			while(!compare);
			fclose(fp_deny_email_host);
		

			strcpy(email, buf);
			if (is_postcard)
			{
				outs(_msg_ident_14);
				pressreturn();
			}
/*                      
   else if ((p = strchr(buf, '.')) != NULL
   && strchr(p, '@') != NULL)
 */
			else if (strstr(buf, ".bbs@"))	/* lthuang */
			{
				outs(_msg_ident_15);
				pressreturn();
			}
			break;
		}
		fprintf(fp_udata, "%s%s\n\n", check_item[loop] + 1, buf);
	}
	now = time(0);
	fprintf(fp_udata, _msg_ident_16, ctime(&now));
	fclose(fp_udata);
	outs(_msg_ident_17);
	if (igetkey() != 'y')
	{
		unlink(identfile);
		return M_FULL;
	}
	if (errflag)
	{
		outs(_msg_ident_18);
		pressreturn();
		return M_FULL;
	}

	if (id_num_check(idcard) == -1 && !is_postcard)
	{
		unlink(identfile);
		pressreturn();
		return M_FULL;
	}
	setboardfile(buf, "ID", NULL);
	sprintf(title, _msg_ident_19, curuser.userid);
	if (append_article(identfile, buf, curuser.userid, title, 0, stamp, TRUE) == -1)
	{
		unlink(identfile);
		outs(_msg_ident_20);
		pressreturn();
		return M_FULL;
	}
	if (!is_postcard)
	{
		setboardfile(buf, "ID", stamp);
		send_checkmail(email, buf);
	}
	unlink(identfile);
	pressreturn();
	return M_FULL;
}


/*******************************************************************
 *  ��g�����{�ҥӽЮ�
 *******************************************************************/
CheckID()
{
#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return M_FULL;
#endif

	return do_post_ident();
}

#endif /* HAVE_IDENT */
