
#ifndef _BBS_TSBBS_H_
#define _BBS_TSBBS_H_


#include "linklist.h"
#include "var.h"		/* global variables */
#include "msginfo.h"	/* message text definition, for different languages */
#include "../lib/proto.h"	/* function prototype of library */


/*******************************************************************
 *	general define
 *******************************************************************/

/* Flags to getdata input function */
#define DOECHO 	      0x01
#define NOECHO 	      0x02
#define NOSPACE       0x10
#define LOWCASE       0x20 
#define ECHONOSP 	  (DOECHO|NOSPACE)

/* Option to i_read() powerful readmenu function */
#define IREAD_BOARD	  0x01 
#define IREAD_MAIL    0x02    
#define IREAD_ICHECK  0x03
#define IREAD_IFIND   0x04


#define R_FULL  0x01    /* Entire screen was destroyed in this operation */
#define R_NO	0x02	/* Nothing to do */
#define R_PART  0x04	/* Part of screen was destroyed in this operaion */
#define R_LINE	0x08
#define R_NEW   0x40    /* Directory has changed, re-read files */

#define B_FULL	0x01
#define B_NO	0x02
#define B_PART	0x04
#define B_LINE  0x08
#define B_NEW   0x40

#define M_FULL	0x01
#define M_NO	0x02
#define M_LINE	0x08
#define M_NEW   0x40

#if 0
#define C_FULL  0x01
#define C_NO    0x02
#define C_PART  0x04
#define C_NEW   0x40
#define C_QUIT  0x80
#endif

#define CAREYUP		0x10
#define CAREYDOWN	0x20

/* Used for the getchar routine select call */
#define I_TIMEOUT   (0x180)	
#define I_OTHERDATA (0x181)

#define SCREEN_SIZE 	(23)    

#define TTLEN	60        /* -ToDo- Length of article title */

/*******************************************************************
 *	structure define
 *******************************************************************/
struct commands {		
	char key;
	unsigned int level;
	struct commands *comm;
	int (*cfunc)() ;
	int mode;
	char *ehelp;
	char *chelp;
} ;

struct one_key {           /* Used to pass commands to the readmenu */
	int key ;
	int (*fptr)() ;
} ;


/*******************************************************************
 *	key define
 *******************************************************************/
#define KEY_UP		0x0101
#define KEY_DOWN	0x0102
#define KEY_RIGHT	0x0103
#define KEY_LEFT	0x0104

#define KEY_HOME	0x0201
#define KEY_INS		0x0202
#define KEY_DEL		0x0203
#define KEY_END		0x0204
#define KEY_PGUP	0x0205
#define KEY_PGDN	0x0206


/*******************************************************************
 * 	other define or macro
 *******************************************************************/
#define b_line    (t_lines-1)

#define HAS_PERM(x)	  CHECK_PERM(curuser.userlevel, x) 	/* -ToDo- */

extern int t_lines, t_columns;  /* Screen size, hieght, width */
extern int (*outc) ();

#include "proto.h"		/* other function prototype */

#endif /* _BBS_TSBBS_H_ */

