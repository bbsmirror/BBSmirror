/* 
   Li-te Huang, lthuang@cc.nsysu.edu.tw, 03/09/98
*/

#include "bbs.h"
#include "tsbbs.h"

extern char *genpasswd();

char myfromhost[HOSTLEN];
char myuserid[IDLEN], mypasswd[PASSLEN];

unsigned int newreg_number = 0;


void
abort_bbs(s)
int s;
{
	if (newreg_number)
	{
		struct useridx uidx;

		memset(&uidx, 0, sizeof(uidx));
		substitute_record(USERIDX, &uidx, sizeof(uidx), newreg_number);
	}
	else
		user_logout(cutmp, &curuser);
	shutdown(0, 2);
	exit(0);
}


void
warn_bell()
{
	bell(); bell(); bell(); bell();
}


void
talk_request(s)
int s;
{
#if	defined(LINUX) || defined(SOLARIS)
/*
   Reset signal handler for SIGUSR1, when signal received, 
   some OS set the handler to default, SIG_DFL. The SIG_DFL
   usually is terminating the process. So, when user was paged
   twice, he will be terminated.
 */
	signal(SIGUSR1, talk_request);
#endif
	talkrequest = TRUE;
	warn_bell();
}


void
write_request(s)
int s;
{
#if	defined(LINUX) || defined(SOLARIS)
	signal(SIGUSR2, write_request);
#endif
	writerequest = TRUE;
	warn_bell();
}



static void
user_init()
{
	setmailfile(ufile_mail, curuser.userid, DIR_REC);
	sethomefile(ufile_overrides, curuser.userid, UFNAME_OVERRIDES);
	setuserfile(ufile_write, curuser.userid, UFNAME_WRITE);

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
	{
		curuser.flags[1] &= ~PICTURE_FLAG;
		return;
	}
#endif


	if (PERM_SYSOP == curuser.userlevel)
		maxkeepmail = 1000;	/* debug */
	else if (PERM_BM == curuser.userlevel)
		maxkeepmail = SPEC_MAX_KEEP_MAIL;
	else 
		maxkeepmail = MAX_KEEP_MAIL;
	if (curuser.flags[0] & COLOR_FLAG)
		show_ansi = FALSE;
	else
		show_ansi = TRUE;

#if HAVE_IDENT
	if (curuser.ident > 7 || curuser.ident < 0)	/* debug */
	{
		curuser.ident = 0;
		update_user(&curuser);
	}
#endif

	ReadRC_Expire();

	if (multi == 1)
		unlink(ufile_write);	/* lthuang */
	if ((curuser.numlogins % 5) == 0)	/* lthuang */
		pack_article(ufile_mail);
}


static void
new_register(nu)
USEREC *nu;
{
	int attempt = 0;

	memset(nu, 0, sizeof(USEREC));

	if (dashf(NONEWUSER) || (nu->uid = new_user(NULL)) <= 0)
	{
		more(NONEWUSER, FALSE);
		oflush();
		shutdown(0, 2);
		exit(1);
	}
	newreg_number = nu->uid;	/* lthuang */
	/* determine what userid used for newuser */
	outs(_msg_formosa_1);
	while (1)
	{
		if (attempt++ >= 3)
		{
			outs(_msg_formosa_4);
			abort_bbs(0);
		}
	
		getdata(0, 0, _msg_formosa_2, nu->userid, IDLEN, ECHONOSP, NULL);
		if (invalid_userid(nu->userid))
		{
			prints(_msg_formosa_3, LEAST_IDLEN);
			continue;
		}
		if (get_passwd(NULL, nu->userid) > 0)
		{
			outs(_msg_formosa_5);
			continue;
		}
		strcpy(myuserid, nu->userid);
		break;
	}

	/* determine what the password and userdata is */
	while (1)
	{
		getdata(0, 0, _msg_formosa_6, mypasswd, sizeof(mypasswd), NOECHO, NULL);
		if (strlen(mypasswd) < 4)
		{
			outs(_msg_formosa_7);
			continue;
		}
		if (!strcmp(mypasswd, nu->userid))
		{
			outs(_msg_formosa_8);
			continue;
		}
		getdata(0, 0, _msg_formosa_9, genbuf, sizeof(mypasswd), NOECHO, NULL);
		if (strcmp(genbuf, mypasswd))
		{
			outs(_msg_formosa_10);
			continue;
		}
		break;
	}

	getdata(0, 0, _msg_formosa_11, nu->username, sizeof(nu->username), DOECHO, NULL);
	getdata(0, 0, _msg_formosa_12, nu->email, sizeof(nu->email), DOECHO, NULL);

	nu->firstlogin = time(0);	/* lthuang */
	nu->lastlogin = nu->firstlogin;
	uinfo.login_time = nu->firstlogin;	/* lthuang */
	xstrncpy(nu->lasthost, myfromhost, sizeof(nu->lasthost));
	xstrncpy(uinfo.from, myfromhost, sizeof(uinfo.from));
	xstrncpy(nu->passwd, genpasswd(mypasswd), PASSLEN);	
	nu->userlevel = PERM_DEFAULT;
	nu->userlevel = 1;	/* lthuang */
	nu->numlogins = 1;	/* lthuang */

	/* write back to the pre-determined seat in password file */
	if (new_user(nu) > 0)
		newreg_number = 0;
	else
	{
		outs(_msg_formosa_13);
		abort_bbs(0);
	}
}


static void
login_query()
{
	int act, attempt = 0;	
	FILE *fp;
	int n;


	if ((fp = fopen(BBSSRV_WELCOME, "r")) != NULL)
	{
		while (fgets(genbuf, sizeof(genbuf), fp))
			outs(genbuf);
		fclose(fp);
	}

#ifdef ACTFILE
	if ((fp = fopen(ACTFILE, "r")) != NULL)
	{
		while (fgets(genbuf, sizeof(genbuf), fp))
			outs(genbuf);
		fclose(fp);
	}
#endif

	act = ask_online_user();
	prints(_msg_formosa_14, BBSNAME, act, MAXACTIVE);

#ifdef SHOW_UPTIME
	if ((fp = fopen(SHOW_UPTIME, "r")) != NULL)
	{
		if (fgets(genbuf, sizeof(genbuf), fp))
		{
			char *ptr;

			if ((ptr = strrchr(genbuf, ':')) != NULL)
				prints(_msg_formosa_15, ++ptr);
		}
		fclose(fp);
	}
#endif

	if (act > MAXACTIVE)
	{
		prints(_msg_formosa_16, MAXACTIVE);
		oflush();
		shutdown(0, 2);
		exit(0);
	}

	for (;;)
	{
		if (attempt++ >= LOGINATTEMPTS)
		{
			prints(_msg_formosa_17, LOGINATTEMPTS);
			oflush();
			shutdown(0, 2);
			exit(0);
		}

#if	defined(LOGINASNEW)
		outs(_msg_formosa_18);
  #ifdef GUEST_ACCOUNT
		prints(_msg_formosa_19, GUEST_ACCOUNT);
  #endif /* GUEST_ACCOUNT */
#else /* LOGINASNEW */
  #ifdef GUEST_ACCOUNT
		prints(_msg_formosa_20, GUEST_ACCOUNT);
  #endif
#endif /* !LOGINASNEW */

		if (!getdata(3, 0, _msg_formosa_21, myuserid, sizeof(myuserid), ECHONOSP, NULL))
		{
			outs(_msg_err_userid);
			continue;
		}
		
		if (!strcmp(myuserid, "new"))
		{
#if	!defined(LOGINASNEW)
			if (dashf(NONEWUSER))
			{
				more(NONEWUSER, FALSE);
				oflush();
			}
			else
				printf(_msg_formosa_22);
  #ifdef GUEST_ACCOUNT
			printf(_msg_formosa_23);
  #endif
  			oflush();
			shutdown(0, 2);
			exit(1);
#else
			if (dashf(NONEWUSER))
			{
				printf(_msg_formosa_24);						
				more(NONEWUSER, FALSE);
				oflush();
				shutdown(0, 2);
				exit(1);
			}
			new_register(&curuser);
			if (user_login(&cutmp, &curuser, CTYPE_TSBBS, myuserid, mypasswd, myfromhost) == ULOGIN_OK)
			{
				memcpy(&uinfo, cutmp, sizeof(USER_INFO));						
				break;
			}
#endif				
		}
		else
		{
#ifdef GUEST_ACCOUNT
			if (!strcmp(myuserid, GUEST_ACCOUNT))
			{
				getdata(4, 0, _msg_formosa_25, mypasswd, sizeof(mypasswd), NOECHO, NULL);
				if (user_login(&cutmp, &curuser, CTYPE_TSBBS, myuserid, mypasswd, myfromhost) == ULOGIN_OK)
				{
					memcpy(&uinfo, cutmp, sizeof(USER_INFO));				
					break;
				}
			}
			else
#endif
			if (getdata(4, 0, _msg_formosa_26, mypasswd, sizeof(mypasswd), NOECHO, NULL))
			{
				n = user_login(&cutmp, &curuser, CTYPE_TSBBS, myuserid, mypasswd, myfromhost);
				if (n == ULOGIN_OK)
				{
					memcpy(&uinfo, cutmp, sizeof(USER_INFO));				
					break;
				}
				else if (n == ULOGIN_PASSFAIL)
				{
					outs(_msg_formosa_27);
					continue;
				}
			}
			outs(_msg_formosa_44);
		}
	}
}


void
log_visitor()
{
	struct visitor v;
	int fd;

	strcpy(v.userid, uinfo.userid);
	strcpy(v.from, uinfo.from);
	v.when = uinfo.login_time;
	if ((fd = open(PATH_VISITOR, O_WRONLY | O_CREAT | O_APPEND, 0600)) > 0)
	{
		write(fd, &v, sizeof(v));
		close(fd);
	}
}


int 
Announce()
{
	more(WELCOME, TRUE);
	return M_FULL;
}


/* 
   wnlee : check whether user has bakfile to edit
*/
static void
bakfiletest()
{
	FILE *fp;

	setuserfile(genbuf, curuser.userid, UFNAME_EDIT);
	if ((fp = fopen(genbuf, "r")) != NULL)
	{
		clear();
		printxy(12, 26, _msg_formosa_42);
		printxy(13, 26, _msg_formosa_43);
		fclose(fp);
		pressreturn();
	}
}


/*
   list all registered user
 */
int 
Users()
{
	int fd, ch, i = 3;
	int sysop = 0, bm = 0, total = 0, spec = 0;
	unsigned int levelSpec = 0;
	BOOL bShow = TRUE;
	USEREC urcAll;	
#if  HAVE_IDENT
	int idented = 0;
#endif

	if (getdata(1, 0, _msg_formosa_28, genbuf, 4, ECHONOSP, NULL))
		levelSpec = atoi(genbuf);

	if ((fd = open(PASSFILE, O_RDONLY)) < 0)
		return -1;

	move(1, 0);
	clrtobot();
	prints("%-12s %-20s %6s %6s %4s",
	       _msg_formosa_29, _msg_formosa_30, _msg_formosa_31,
	       _msg_formosa_32, _msg_formosa_33);
	outs("\n------------------------------------------------------------------------------\n");

	while (read(fd, &urcAll, sizeof(USEREC)) == sizeof(USEREC))
	{
		if (urcAll.userid[0] == '\0' || !strcmp(urcAll.userid, "new"))
			continue;
			
		total++;
		if (urcAll.userlevel == PERM_SYSOP)
			sysop++;
		else if (urcAll.userlevel >= PERM_BM)
			bm++;

		if (urcAll.userlevel < levelSpec)
			continue;
		spec++;
#if  HAVE_IDENT
		if (urcAll.ident == 7)
			idented++;
#endif
		if (bShow)
		{
			prints("%-12s %-20.20s %6d %6d %4d\n",
			       urcAll.userid, urcAll.username, urcAll.numlogins,
			       urcAll.numposts, urcAll.userlevel);
			if (++i == b_line)
			{
				outs(_msg_formosa_34);
				ch = igetkey();
				if (ch == KEY_LEFT || ch == 'q')
				{
					bShow = FALSE;
					continue;
				}
				i = 3;
				move(i, 0);
				clrtobot();
			}
		}
	}
	clrtobot();
	move(b_line, 0);
	if (levelSpec == 0)
		prints(_msg_formosa_35, total);
	else
		prints(_msg_formosa_36, spec, total);
	prints(_msg_formosa_37, sysop, bm);
#if HAVE_IDENT
	prints(_msg_formosa_38, idented);
#endif
	outs("[0m");
	close(fd);
	getkey();
	return M_FULL;
}


#ifdef USE_BBSNET
/*
   BBSNET, provide menu for telnet other bbs
 */
int
BBSNet()
{
	outdoor("door", UNDEFINE, TRUE);
	return M_FULL;
}
#endif


/*
  check multi-logins for current user
*/   
#ifdef MAX_GUEST_LOGINS
BOOL bCountGuest = FALSE;
#endif

int
count_multi_login(upent)
USER_INFO *upent;
{
	static int short i = 0;


	if (upent->pid <= 2 || uinfo.pid <= 2)	/* debug */
		return -1;

	if (!strcmp(upent->userid, uinfo.userid))	/* -ToDo- compare uid */
	{
		i++;
		if (upent->pid != uinfo.pid)
		{
			multi++;
#ifdef MAX_GUEST_LOGINS
			if (bCountGuest)
			{
				if (multi > MAX_GUEST_LOGINS)
				{
					outs(_msg_formosa_39);
					oflush();
					shutdown(0, 2);
					exit(0);
				}
				return 0;
			}
#endif
			/* prevent user multi-login many many times */
			if (multi > MULTILOGINS + 1 && !HAS_PERM(PERM_SYSOP))
				goto force_leave;
			prints(_msg_formosa_40, i, upent->pid, upent->from);
			if (igetkey() == 'y')
			{
				if (upent->pid > 2)	/* debug */
					kill(upent->pid, SIGKILL);
				purge_ulist(upent);
				multi--;
			}
			if (multi > MULTILOGINS && !HAS_PERM(PERM_SYSOP))
			{
force_leave:
				prints(_msg_formosa_41, multi);
				oflush();
				shutdown(0, 2);
				exit(0);
			}
		}
	}
	return 0;
}


void
multi_user_check()
{
#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
	{
#if	defined(MAX_GUEST_LOGINS)
		bCountGuest = TRUE;
#else
		return;
		/* UNREACHED */
#endif
	}
#endif /* GUEST_ACCOUNT */

	apply_ulist(count_multi_login);
}


/*
   Main function of BBS
*/
void
Formosa(host, term)
char *host, *term;
{
	signal(SIGHUP, abort_bbs);
	signal(SIGBUS, abort_bbs);
	signal(SIGTERM, abort_bbs);
	signal(SIGCHLD, SIG_IGN);
	signal(SIGINT, SIG_IGN);
	signal(SIGQUIT, SIG_IGN);
	signal(SIGPIPE, SIG_IGN);

	signal(SIGURG, SIG_IGN);
	signal(SIGTSTP, SIG_IGN);
	signal(SIGTTIN, SIG_IGN);
	signal(SIGTTOU, SIG_IGN);

	signal(SIGUSR1, talk_request);
	signal(SIGUSR2, write_request);


	init_tty();

	xstrncpy(myfromhost, (host ? host : "local"), sizeof(myfromhost));
	login_query();

	term_init("vt100");
	initscr();

	log_visitor();
	multi_user_check();
	user_init();
	more(WELCOME0, TRUE);
	
	if (curuser.userlevel <= 1)
		more(NEWGUIDE, TRUE);

	Announce();

	bakfiletest();
	
	/* wnlee: to see if users wanna see note board */
	if (!(curuser.flags[1] & NOTE_FLAG))
		x_viewnote();

#if	defined(TIMEOUT)
	init_alarm(IDLE_TIMEOUT);
#else
	signal(SIGALRM, SIG_IGN);
#endif

	domenu();
	/* NOT REACHED */
}
