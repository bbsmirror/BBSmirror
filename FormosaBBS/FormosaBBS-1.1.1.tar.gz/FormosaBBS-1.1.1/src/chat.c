
#include "bbs.h"
#include "tsbbs.h"
#include "chat.h"


#ifdef lint
#include <sys/uio.h>
#endif
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>


struct array *iglist;

int max_users = 0;

#define MAX_IGNORE_USER  40

int chatline;

#define ECHATWIN	(t_lines - 2)
#define PLINE		(t_lines - 1)

/* 
   #define BADCIDCHARS " %*$`\"\\;:|[{]},./?=~!@#^()<>"
 */
#define BADCIDCHARS " *`\"\\;:|,./=~'!"

char MyChanname[CHANLEN];


char *mycrypt();


static void
fixchatid(chatid)
unsigned char *chatid;
{
	char *p;

	if ((p = strstr(chatid, "�@")))		/* lthuang */
		memcpy(p, "__", 2);
	while (*chatid)
	{
		if (*chatid == '\n')
			break;
		if (strchr(BADCIDCHARS, *chatid))
			*chatid = '_';
		chatid++;
	}
}


int ac;
char chatid[STRLEN];


#define CHATIDLEN		(8)
#define SAYWORD_POINT	(13)

#define CHAT_SERVER		"127.0.0.1"


t_chat()
{
	char *colon;
	int currchar;
	char inbuf[120];
	BOOL page_pending = FALSE;
	int ch;
	char seedstr[STRLEN];
	long seed;
	char rcvbuf[512];
	int chatport;


	chatport = CHATPORT;

	/* initialize */
	inbuf[0] = '\0';
	currchar = 0;
	chatline = 0;
	strcpy(MyChanname, DEF_CHANNAME);	/* lthuang */

	if (!getdata(1, 0, "Enter Chat id: ", chatid, CHATIDLEN, ECHONOSP, NULL))
		strncpy(chatid, curuser.userid, CHATIDLEN);
	chatid[CHATIDLEN] = '\0';
	if (chatid[0] == '\0')
		strcpy(chatid, curuser.userid);
	fixchatid(chatid);

	strcat(chatid, ":                      ");	/* ? */
	chatid[SAYWORD_POINT] = '\0';
	strcpy(inbuf, chatid);

	if ((ac = ConnectServer(CHAT_SERVER, chatport)) < 0)
	{
		move(2, 0);
		outs(_msg_chat_3);
		refresh();
		DisconnectServer(ac);
		sprintf(genbuf, "bbschatd");
		outdoor(genbuf, UNDEFINE, TRUE);
		sleep(2);
		if ((ac = ConnectServer(CHAT_SERVER, chatport)) < 0)
		{
			perror("connect failed");
			pressreturn();
			return M_FULL;
		}
	}

	/* initial ignore list */
	iglist = malloc_array(MAX_IGNORE_USER);
	if (!iglist)
	{
		return M_FULL;
	}

	/* receive ChatServer Hello Welcome VersionInfo */
	net_gets(ac, genbuf, sizeof(genbuf));
	/* receive Random Number for Checksum */
	net_gets(ac, seedstr, sizeof(seedstr));
	seed = atol(mycrypt(seedstr));
	net_printf(ac, "USRID\t%s\t%ld\r\n", curuser.userid, seed);
	if (!net_gets(ac, genbuf, sizeof(genbuf)))	/* lthuang */
	{
		iglist = free_array(iglist);
		return M_FULL;
	}

	if (GetRespNo(genbuf) != OK_CMD)	/* lthuang */
	{
		outs(_msg_chat_4);
		pressreturn();
		iglist = free_array(iglist);
		return M_FULL;
	}
/* lthuang */
	{
		char *foo;

		strcpy(genbuf, chatid);
		genbuf[CHATIDLEN] = '\0';
		if ((foo = strchr(genbuf, ':')))
			*foo = '\0';
	}

	net_printf(ac, "NICKNAME\t%s\r\n", genbuf);
	net_gets(ac, genbuf, sizeof(genbuf));

/* lthuang */
	{
		int total = 0;

		net_printf(ac, "WHOALL\r\n");
		net_gets(ac, genbuf, sizeof(genbuf));
		max_users = 0;
		while (1)
		{
			if (++max_users > MAXPORTS)	/* debug */
				break;
			genbuf[0] = '\0';
			net_gets(ac, genbuf, sizeof(genbuf));
			if (genbuf[0] != '.')
			{
				total++;
				continue;
			}
			break;
		}
		clear();
		sprintf(genbuf, _msg_chat_5, total);
		printchatline(genbuf);
	}
	uinfo.mode = CHATROOM;

	strncpy(uinfo.chatid, chatid, SAYWORD_POINT);	/* ? */
	if ((colon = strrchr(uinfo.chatid, ':')))
		*colon = '\0';

	update_ulist(cutmp, &uinfo);



	printchatline(_msg_chat_6);
	move(ECHATWIN, 0);
	prints("--------------------------------------------------------------------------------");
	move(PLINE, 0);
	strcpy(inbuf, chatid);
	prints("%s", chatid);
	currchar = strlen(inbuf);
	add_io(ac, 0);

	/* Chat Main */
	while (1)
	{
		if (writerequest)
		{
			save_screen();
			writereply();
		      redraw:
			restore_screen();
			continue;
		}
		ch = getkey();
		if (talkrequest)
			page_pending = TRUE;
		if (page_pending)
			page_pending = servicepage(0);
		if (ch == I_OTHERDATA)
		{
			if (!net_gets(ac, rcvbuf, sizeof(rcvbuf)))
				break;
			rcvbuf[strlen(rcvbuf) - 1] = '\0';	/* lthuang */				
			
			if (strchr(rcvbuf, ':'))
			{
				char name[IDLEN], *ptr;
				register int i = 0;

				ptr = rcvbuf;
				while (*ptr != ':')
					name[i++] = *ptr++;
				name[i] = '\0';
				if (cmp_array(iglist, name, strcmp))
					continue;
				printchatline(++ptr);
			}
			else if (!strncmp(rcvbuf, "*** ", 4))
			{
				sprintf(genbuf, "[1;37m%s[0m", rcvbuf);
				printchatline(genbuf);
			}
			else
				printchatline(rcvbuf);
		}
		else if (isprint2(ch))
		{
			if (currchar == 75)	/* ? */
			{
				bell();
				continue;
			}
			inbuf[currchar++] = ch;
			inbuf[currchar] = '\0';
			move(PLINE, currchar - 1);
			prints("%c", ch);
		}
		else if (ch == '\n' || ch == '\r')
		{
			int i, j;
			char no_spcs[80];

			for (i = SAYWORD_POINT, j = 0; i < 80; i++)
			{
				if (inbuf[i] == '\0')
				{
					no_spcs[j] = '\0';
					break;
				}
				if (!isspace(inbuf[i]))
					no_spcs[j++] = inbuf[i];
			}
			if (no_spcs[0] == '\0')
				continue;
			if (inbuf[SAYWORD_POINT] == '/')
			{
				int action = dochatcommand(&inbuf[SAYWORD_POINT + 1]);

				if (action == 1)
				{
					strcpy(chatid, uinfo.chatid);
					chatid[CHATIDLEN] = '\0';
					strcat(chatid, ":                      ");	/* ? */
					chatid[SAYWORD_POINT] = '\0';
				}
				else if (action == -1)
					break;
			}
			else
			{
				printchatline(inbuf);	/* lthuang */
				net_printf(ac, "SPEAK\t%s\r\n", inbuf + SAYWORD_POINT);
			}

			strcpy(inbuf, chatid);
			currchar = strlen(chatid);
			move(PLINE, 0);
			outs(inbuf);
			move(23, 10);
			clrtoeol();
		}
		else if (ch == CTRL('H') || ch == '\177')
		{
			if (currchar == SAYWORD_POINT)
			{
				bell();
				continue;
			}
			move(PLINE, --currchar);
			prints(" ");
			inbuf[currchar] = '\0';
		}
		else if (ch == CTRL('C') || ch == CTRL('D'))
		{
			net_printf(ac, "QUIT\r\n");	/* lthuang */
			break;
		}
		else if (ch == CTRL('R'))
		{
			save_screen();		
			ReplyLastCall();
			goto redraw;
		}
		move(PLINE, currchar);
	}
	add_io(0, 0);
	close(ac);
	uinfo.chatid[0] = '\0';
	update_ulist(cutmp, &uinfo);
	iglist = free_array(iglist);
	return M_FULL;
}


void
printchatline(str)
char *str;
{
	move(chatline, 0);
	clrtoeol();

	while (*str)
	{
		if (*str == '\n')
		{
			chatline++;
			if (chatline == ECHATWIN)
				chatline = 0;
			move(chatline, 0);
			clrtoeol();
		}
		else
			outc(*str);
		str++;
	}
	chatline++;
	if (chatline == ECHATWIN)
		chatline = 0;
	move(chatline, 0);
	clrtoeol();
	standout();
	outs("-->");
	standend();
}



int
GetRespNo(str)
char *str;
{
	char keypass[PROTOLEN];

	GetPass(str, keypass, PROTOLEN);
	return atoi(keypass);
}


static int
dowho(channame, fd)
char *channame;
int fd;
{
	char buf[80];
	char chatid[80], userid[80], fromip[80];
	int cnt = 0;
	char uline[80], pline[30];


	channame = PhaseSpace(channame);
	if (*channame)
		net_printf(fd, "WHO\t%s\r\n", channame);
	else
		net_printf(fd, "WHO\t%s\r\n", MyChanname);	/* lthuang */

	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) != OK_CMD)
	{
		printchatline(_msg_chat_44);
		return -1;
	}

	printchatline(_msg_chat_7);
	sprintf(buf, "%-10s  %-12s   %-10s  %-12s   %-10s  %-12s",
		_msg_chat_8, _msg_chat_9,
		_msg_chat_8, _msg_chat_9,
		_msg_chat_8, _msg_chat_9);
	printchatline(buf);
	sprintf(buf, "%-10s  %-12s   %-10s  %-12s   %-10s  %-12s",
		"------", "------", "------", "------", "------", "------");
	printchatline(buf);

	memset(uline, 0, sizeof(uline));
	max_users = 0;
	do
	{
		if (++max_users > MAXPORTS)	/* debug */
			break;
		net_gets(fd, buf, sizeof(buf));
		if (buf[0] == '.')
			break;
		sscanf(buf, "%s\t%s\t%s\r\n", userid, chatid, fromip);
		sprintf(pline, "%-10s  %-12s", chatid, userid);
		if (cnt < 2)
			strcat(pline, "   ");
		strcat(uline, pline);
		if (++cnt == 3)
		{
			cnt = 0;
			printchatline(uline);
			memset(uline, 0, sizeof(uline));
		}
	}
	while (buf[0] != '.');
	if (cnt < 3)
		printchatline(uline);
	return 0;
}


static int
dowhoall(fd)
int fd;
{
	char buf[80];
	char chatid[80], userid[80], channame[80];
	char *NextPass;


	printchatline(_msg_chat_10);
	sprintf(genbuf, "%-10s  %-12s   %-15s",
		_msg_chat_8, _msg_chat_9, _msg_chat_11);
	printchatline(genbuf);
	sprintf(genbuf, "%-10s  %-12s   %-15s", "------", "------", "------");
	printchatline(genbuf);
	net_printf(fd, "WHOALL\r\n");

	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) != OK_CMD)
		return -1;
	max_users = 0;
	do
	{
		if (++max_users > MAXPORTS)	/* debug */
			break;
		net_gets(fd, buf, sizeof(buf));
		if (buf[0] == '.')
			break;
		NextPass = GetPass(buf, userid, sizeof(userid));
		NextPass = GetPass(NextPass, chatid, sizeof(userid));
		NextPass = GetPass(NextPass, channame, sizeof(userid));
		sprintf(genbuf, "%-10s  %-12s   %-15s", chatid, userid, channame);
		printchatline(genbuf);
	}
	while (buf[0] != '.');
	return 0;
}


static int
domsg(Token, fd)
char *Token;
int fd;
{
	char user[IDLEN];

	Token = GetPass(Token, user, IDLEN);
	Token = PhaseSpace(Token);

	if (*Token && *user)
	{
		net_printf(fd, "MSG\t%s\t%s\r\n", user, Token);
		net_gets(fd, genbuf, sizeof(genbuf));
		if (GetRespNo(genbuf) == OK_CMD)
			return 0;
		else if (GetRespNo(genbuf) == USR_FAIL)
			printchatline(_msg_chat_12);
		else
			return -1;
	}
	return 0;
}


#ifdef HAVE_CHATMSGALL
static int
domsgall(msg, fd)
char *msg;
int fd;
{
	net_printf(fd, "MSGALL\t%s\r\n", msg);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
		return 0;
	else
		return -1;
}
#endif




static int
dolist(fd)
int fd;
{
	char buf[80];
	char channame[80], topic[80], op[80], members[80], secret[80];


	printchatline(_msg_chat_16);
	sprintf(buf, "%-15s  %-20s  %-12s  %-6s  %-4s",
		_msg_chat_17, _msg_chat_18, _msg_chat_19,
		_msg_chat_20, _msg_chat_21);
	printchatline(buf);
	sprintf(buf, "%-15s  %-20s  %-12s  %-6s  %-4s",
		"------", "------", "------", "------", "------");
	printchatline(buf);
	net_printf(fd, "LISTCHAN\r\n");

	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) != OK_CMD)
		return -1;
	max_users = 0;
	do
	{
		if (++max_users > MAXPORTS)	/* debug */
			break;
		net_gets(fd, buf, sizeof(buf));
		if (buf[0] == '.')
			break;
		sscanf(buf, "%s\t%s\t%s\t%s\t%s\r\n", channame, topic, op, members, secret);
		sprintf(genbuf, "%-15s  %-20s  %-12s  %-6s  %-4s",
			channame, topic, op, members, secret);
		printchatline(genbuf);
	}
	while (buf[0] != '.');
	return 0;
}


static int
dojoin(Token, fd)
char *Token;
int fd;
{
	char channame[CHANLEN];


	Token = GetPass(Token, channame, CHANLEN);
	Token = PhaseSpace(Token);
	if (*channame == '\0')
	{
		printchatline(_msg_chat_22);
		return 0;
	}
	if (!strcmp(channame, MyChanname))
	{
		printchatline(_msg_chat_23);
		return 0;
	}
	net_printf(fd, "JOIN\t%s\t%s\r\n", channame, Token);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
	{
		strncpy(MyChanname, channame, CHANLEN - 1);
		sprintf(genbuf, _msg_chat_24, channame);
		printchatline(genbuf);
	}
	else if (GetRespNo(genbuf) == PASS_FAIL)
	{
		sprintf(genbuf, _msg_chat_25, channame);
		printchatline(genbuf);
	}
	return 0;
}




static int
dotopic(Token, fd)
char *Token;
int fd;
{
	char topic[TOPICLEN];


	GetPass(Token, topic, TOPICLEN);
	if (*topic == '\0')
	{
		printchatline(_msg_chat_26);
		return -1;
	}
	net_printf(fd, "TOPIC\t%s\r\n", topic);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
	{
		sprintf(genbuf, _msg_chat_27, topic);
		printchatline(genbuf);
		net_printf(fd, "SPEAK\t%s\r\n", genbuf);
	}
	else if (GetRespNo(genbuf) == PASS_FAIL)
		printchatline(_msg_chat_28);
	else
		return -1;
	return 0;
}


static int
dopasswd(Token, fd)
char *Token;
int fd;
{
	char pass[8];


	GetPass(Token, pass, 8);
	if (*pass == '\0')
	{
		printchatline(_msg_chat_29);
		return -1;
	}
	net_printf(fd, "PASSWD\t%s\r\n", pass);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
	{
		sprintf(genbuf, _msg_chat_30, pass);
		printchatline(genbuf);
		net_printf(fd, "SPEAK\t%s\r\n", _msg_chat_31);
	}
	else if (GetRespNo(genbuf) == PASS_FAIL)
		printchatline(_msg_chat_32);
	else
		return -1;
	return 0;
}


static int
donopasswd(pass, fd)
char *pass;
int fd;
{
	net_printf(fd, "PASSWD\t%s\r\n", NOPASSWORD);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
	{
		printchatline(_msg_chat_33);
		net_printf(fd, "SPEAK\t%s\r\n", _msg_chat_34);
	}
	else if (GetRespNo(genbuf) == PASS_FAIL)
		printchatline(_msg_chat_35);
	else
		return -1;
	return 0;
}


static int
dounignore(dest, fd)
char *dest;
int fd;
{
	dest = PhaseSpace(dest);
	if (*dest)
	{
		dest[IDLEN - 1] = '\0';
		if (cmp_array(iglist, dest, strcmp))
		{
			sprintf(genbuf, _msg_chat_36, dest);
			printchatline(genbuf);
			cmpd_array(iglist, dest, strcmp);
		}
	}
}


static int
doignore(dest, fd)
char *dest;
int fd;
{
	dest = PhaseSpace(dest);
	if (*dest)
	{
		dest[IDLEN - 1] = '\0';
		if (!cmp_array(iglist, dest, strcmp))
		{
			sprintf(genbuf, _msg_chat_37, dest);
			printchatline(genbuf);
			add_array(iglist, dest, malloc_str);
		}
	}
	return 0;
}


static int
donick(newname, fd)
char *newname;
int fd;
{
	newname = PhaseSpace(newname);
	if (*newname == '\0')
	{
		printchatline(_msg_chat_38);
		return -1;
	}
	newname[IDLEN - 1] = '\0';	/* degbug */
	fixchatid(newname);
	net_printf(fd, "NICKNAME\t%s\r\n", newname);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
	{
		sprintf(genbuf, _msg_chat_39, newname);
		printchatline(genbuf);
		strncpy(uinfo.chatid, newname, sizeof(uinfo.chatid));
		uinfo.chatid[sizeof(uinfo.chatid) - 1] = '\0';
		update_ulist(cutmp, &uinfo);
		return 1;	/* cause t_chat to update chatid */
	}
	else if (GetRespNo(genbuf) == NAME_FAIL)
	{
		printchatline(_msg_chat_40);
		return 0;
	}
	else
		return -1;
}


int
dochatcommand(cmd)
char *cmd;
{
	char *endcmd;
	int retval = 0;


	while (isspace(*cmd))
		cmd++;
	for (endcmd = cmd; *endcmd; endcmd++)
	{
		if (isspace(*endcmd) || *endcmd == '\n')	/* ? */
			break;
	}
	if (*endcmd == '\0')
		*(endcmd + 1) = '\0';	/* ? */
	else
		*endcmd = '\0';
	if (*cmd == 'h')
	{
		printchatline(_msg_chat_41);
#ifdef HAVE_CHATMSGALL
		printchatline(_msg_chat_42);
#endif
		printchatline(_msg_chat_43);
	}
	else if (!strcmp(cmd, "who") || !strcmp(cmd, "w"))
		retval = dowho(endcmd + 1, ac);
	else if (!strcmp(cmd, "ws") || !strcmp(cmd, "whoall"))
		dowhoall(ac);
	else if (!strcmp(cmd, "join") || !strcmp(cmd, "j"))
		retval = dojoin(endcmd + 1, ac);
	else if (!strcmp(cmd, "list") || !strcmp(cmd, "l"))
		retval = dolist(ac);
	else if (!strcmp(cmd, "msg") || !strcmp(cmd, "m"))
		retval = domsg(endcmd + 1, ac);
#ifdef HAVE_CHATMSGALL
	else if (!strcmp(cmd, "msgall") || !strcmp(cmd, "ma"))
		retval = domsgall(endcmd + 1, ac);
#endif
	else if (!strcmp(cmd, "topic") || !strcmp(cmd, "t"))
		retval = dotopic(endcmd + 1, ac);
	else if (!strcmp(cmd, "passwd") || !strcmp(cmd, "ps"))
		retval = dopasswd(endcmd + 1, ac);
	else if (!strcmp(cmd, "nopasswd") || !strcmp(cmd, "nps"))
		retval = donopasswd(endcmd + 1, ac);
	else if (!strcmp(cmd, "nick") || !strcmp(cmd, "n"))
		retval = donick(endcmd + 1, ac);
	else if (!strcmp(cmd, "me"))
	{
		char actionbuf[80], *firstlet = endcmd + 1;

		while (isspace(*firstlet) || *firstlet == '\n' || *firstlet == '\t')
			firstlet++;
		if (*firstlet)
		{
			sprintf(actionbuf, "*** %s ***", endcmd + 1);
			net_printf(ac, "SPEAK\t%s\r\n", actionbuf);
			printchatline(actionbuf);
		}
		else
			printchatline(_msg_chat_45);
	}
	else if (!strcmp(cmd, "pager") || !strcmp(cmd, "p"))
	{
		uinfo.pager = (uinfo.pager) ? FALSE : TRUE;
		update_ulist(cutmp, &uinfo);
		printchatline(" ");
		if (!uinfo.pager)
			printchatline("*** Pager turned off");
		else
			printchatline("*** Pager turned on");
	}
	else if (!strcmp(cmd, "clear") || !strcmp(cmd, "c"))
	{
		clear();
		move(ECHATWIN, 0);
		prints("--------------------------------------------------------------------------------");
		chatline = 0;	/* reset */
		printchatline(_msg_chat_46);
	}
	else if (!strcmp(cmd, "ignore") || !strcmp(cmd, "i"))
		doignore(endcmd + 1, ac);
	else if (!strcmp(cmd, "unignore") || !strcmp(cmd, "ui"))
		dounignore(endcmd + 1, ac);
	else
		printchatline("*** ERROR: unknown special chat command");
	return retval;
}
