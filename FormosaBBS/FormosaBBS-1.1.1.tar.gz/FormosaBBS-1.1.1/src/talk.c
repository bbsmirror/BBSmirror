#include "bbs.h"
#include "tsbbs.h"

#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>


#define P_INT	(20)		/* interval to check for page requency */

char out_mesg[68];

struct word *talkwtop = NULL;

extern USER_INFO *search_ulist();

void do_talk();

extern short two_enter;


int
GetNumFileLine(filename)
char *filename;
{
	FILE *fp;
	char buf[256];
	int line = 0, lastch;;

	if ((fp = fopen(filename, "r")) == NULL)
		return 0;
	while (fgets(buf, sizeof(buf), fp))
	{
		lastch = strlen(buf) - 1;
		if (buf[lastch] == '\n')
			line++;
	}
	fclose(fp);
	return line;
}


int
load_friend_cache()		/* -ToDo- conver string compare to uid
				   compare */
{
	int my_friend_num = 0;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return 0;
#endif

	if (friend_cache == NULL)
	{
		FILE *fp;
		register int friend_no;
		register char *ptr;

		my_friend_num = GetNumFileLine(ufile_overrides);
		friend_cache = malloc_array(my_friend_num);
		if (friend_cache == NULL)
		{
			my_friend_num = 0;
			return 0;
		}

		if ((fp = fopen(ufile_overrides, "r")) != NULL)
		{
			friend_no = 0;
			while (friend_no++ < my_friend_num && fgets(genbuf, sizeof(genbuf), fp))
			{
				if ((ptr = strchr(genbuf, ' ')))
					*ptr = '\0';	/* lthuang */
				if ((ptr = strchr(genbuf, '\n')))
					*ptr = '\0';
				if (genbuf[0])
					add_array(friend_cache, genbuf, malloc_str);
			}
			fclose(fp);
		}
	}
	return my_friend_num;
}


int
MyFriend(whoasks)		/* -ToDo- convert string compare to uid
				   compare */
char *whoasks;
{
#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return 0;
#endif

	load_friend_cache();
	return cmp_array(friend_cache, whoasks, strcmp);
}


static int
can_override(upent, whoasks)
USER_INFO *upent;
char *whoasks;
{
	FILE *fp;


	if (upent == NULL || upent->userid[0] == '\0')
		return 0;
		
	sethomefile(genbuf, upent->userid, UFNAME_OVERRIDES);
	if ((fp = fopen(genbuf, "r")) != NULL)
	{
		register char *ptr;
		
		while (fgets(genbuf, sizeof(genbuf), fp))
		{
			ptr = genbuf;
		    while (*ptr)
		    	ptr++;
		    if (*--ptr == '\n')
		    	*ptr = '\0';
			if (!strcmp(genbuf, whoasks))
			{
				fclose(fp);
				return 1;
			}
		}
		fclose(fp);
	}
	return 0;
}


void
friend_add(ident)
char *ident;
{
	FILE *fp;

	if (ident == NULL || ident[0] == '\0')
		return;
	if (get_passwd(NULL, ident) <= 0 || seek_in_file(ufile_overrides, ident))
		return;

	if ((fp = fopen(ufile_overrides, "a")) != NULL)
	{
		fprintf(fp, "%s\n", ident);
		fclose(fp);
		friend_cache = free_array(friend_cache);
	}
}


void
friend_delete(ident)
char *ident;
{
	FILE *fp, *fpnew;
	char fnnew[PATHLEN];
	int delete = FALSE;
	char *ptr;

	sprintf(fnnew, "tmp/%-s.overridse_new", curuser.userid);	/* lthuang ? */
	if ((fp = fopen(ufile_overrides, "r")) != NULL)
	{
		if ((fpnew = fopen(fnnew, "w")) != NULL)
		{
			while (fgets(genbuf, sizeof(genbuf), fp))
			{
				if ((ptr = strchr(genbuf, ' ')) != NULL)	/* lthuang */
					*ptr = '\0';
				if ((ptr = strchr(genbuf, '\n')) != NULL)
					*ptr = '\0';
				if (!strcmp(genbuf, ident))
					delete = TRUE;
				else
					fprintf(fpnew, "%s\n", genbuf);
			}
			fclose(fpnew);
			if (delete)
			{
				if (myrename(fnnew, ufile_overrides) == 0)
				{
					friend_cache = free_array(friend_cache);
					return;
				}
			}
			unlink(fnnew);
		}
		fclose(fp);
	}
}


static int
listcuent(upent)		/* for list all online userid */
USER_INFO *upent;
{
	if (upent == NULL || upent->userid[0] == '\0')
		return -1;
	if (!strcmp(upent->userid, curuser.userid))
		return -1;
	if (!HAS_PERM(PERM_CLOAK) && upent->invisible)
		return -1;
	talkwtop = add_wlist(talkwtop, upent->userid, malloc_str);
	return 0;
}


int
t_pager()
{
	for (;;)
	{
		move (3, 0);
		clrtoeol();
		if (uinfo.pager)
			outs(_msg_talk_4);
		else
		{
			if (!uinfo.chk)
				outs(_msg_talk_3);	
			else
				outs(_msg_talk_56);
		}
		getdata(b_line, 0, _msg_talk_2, genbuf, 2, ECHONOSP, NULL);
		switch(genbuf[0])
		{
			case '1':
				uinfo.pager = TRUE;
				break;
			case '2':
				uinfo.pager = FALSE;
				uinfo.chk = FALSE;
				break;
			case '3':
				uinfo.pager = FALSE;
				uinfo.chk = TRUE;
				break;
			default:
				update_ulist(cutmp, &uinfo);
				return M_FULL;
		}
	}
}


static int
cmp_userid(userid, upent)
char *userid;
USER_INFO *upent;
{
	if (upent == NULL || upent->userid[0] == '\0')
		return 0;
	if (userid == NULL || userid[0] == '\0')	/* debug */
		return 0;
	return (!strcmp(userid, upent->userid));
}


int
QueryUser(ident)
char *ident;
{
	FILE *planfile;
	USEREC qurc;
	USER_INFO *quinf;
	int save_umode = uinfo.mode;

	if (ident == NULL || ident[0] == '\0')
		return -1;

	move(1, 0);
	clrtobot();

	if (get_passwd(&qurc, ident) <= 0)
	{
		outs(_msg_err_userid);
		pressreturn();
		return 0;
	}

	xstrncpy(uinfo.destid, qurc.userid, IDLEN);	/* lthuang */
	update_umode(QUERY);

	outs(_msg_talk_5);
	prints(_msg_talk_6, qurc.userid, qurc.username, qurc.userlevel);
#if HAVE_IDENT
	if (qurc.ident == 7)
		outs(_msg_talk_7);
	else
		outs(_msg_talk_8);
#endif
	prints(_msg_talk_9, qurc.numlogins, qurc.numposts);
	prints(_msg_talk_10,
	       (qurc.lastlogin) ? Ctime(&(qurc.lastlogin)) : "(unknown)",
	       (qurc.lasthost[0]) ? qurc.lasthost : "(unknown)");
	outs("\n");
	move(5, 0);
	if (qurc.flags[0] & FORWARD_FLAG)
		outs(_msg_talk_13);
	else if (check_newmail(qurc.userid))
		outs(_msg_talk_14);
	else
		outs(_msg_talk_15);
	if ((quinf = search_ulist(cmp_userid, qurc.userid)))
	{
		prints(_msg_talk_16,
		       modestring(quinf, 1),
		       (quinf->pager) ? _msg_on : _msg_off);
#ifdef HAVE_CHK
		if (quinf->chk)
			outs(_str_marker);		      
#endif			
	}
	else
		outs(_msg_talk_17);

	sethomefile(genbuf, qurc.userid, UFNAME_PLANS);
	if ((planfile = fopen(genbuf, "r")) != NULL)
	{
		register int i = 0;

		move(b_line, 0);
		clrtoeol();
		outs(_msg_talk_18);
		igetkey();
		move(1, 0);
		clrtobot();
		while (++i <= MAX_QUERY_LINES && fgets(genbuf, sizeof(genbuf), planfile))
			outs(genbuf);
		fclose(planfile);
	}
	else
	{
		outs(_msg_talk_19);
	}
	pressreturn();
	uinfo.destid[0] = '\0';	/* lthuang */
	update_umode(save_umode);
	return 0;
}


int
t_query()
{
	char userid[IDLEN];

	move(2, 0);
	clrtoeol();
	outs(_msg_talk_20);
	move(1, 0);
	clrtoeol();
	if (getdata(1, 0, _msg_talk_21, userid, sizeof(userid), ECHONOSP, NULL))
		QueryUser(userid);
	return M_FULL;
}


int
CompleteOnlineUser(data)
char *data;
{
	if (ask_online_user() < 2)
		return -1;
	move(1, 0);
	clrtobot();
	move(2, 0);
	outs(_msg_talk_22);
	move(1, 0);
	outs(_msg_talk_23);
	apply_ulist(listcuent);
	namecomplete(talkwtop, NULL, data);
	talkwtop = free_wlist(talkwtop, free);
	if (data[0] == '\0')
		return -1;
	return 0;
}


int
talk_user(tkuinf)
USER_INFO *tkuinf;
{
#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return -1;
#endif

	if (tkuinf == NULL || tkuinf->userid[0] == '\0')
		return -1;

#ifdef GUEST_ACCOUNT
	if (!strcmp(tkuinf->userid, GUEST_ACCOUNT))
		return -1;
#endif

	if (!strcmp(tkuinf->userid, curuser.userid))
		return 0;

	if (!HAS_PERM(PERM_SYSOP) && !tkuinf->pager 
	    && !can_override(tkuinf, curuser.userid))	
	{
#ifdef HAVE_CHK	
		if ((tkuinf->chk && curuser.ident != 7)
		    || !tkuinf->chk)
#endif		    
		{
			msg(_msg_talk_25);
			getkey();
			return -1;
		}
	}

	if (InOutdoor(tkuinf))
	{
		msg(_msg_talk_26);
		getkey();
		return -1;
	}
	else
	{
		int sock, msgsock, length;
		struct sockaddr_in server;
		char reponse;

		if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		{
			perror("opening stream socket\n");
			return -1;
		}
		server.sin_family = AF_INET;
		server.sin_addr.s_addr = INADDR_ANY;
		server.sin_port = 0;
		if (bind(sock, (struct sockaddr *) &server, sizeof server) < 0)
		{
			perror("binding stream socket");
			return -1;
		}
		length = sizeof server;
		if (getsockname(sock, (struct sockaddr *) &server, &length) < 0)
		{
			perror("getting socket name");
			return -1;
		}
		if (tkuinf->pid <= 2)	/* lthuang */
			return -1;
		uinfo.sockactive = TRUE;	/* ? */
		uinfo.sockaddr = server.sin_port;
		xstrncpy(uinfo.destid, tkuinf->userid, IDLEN);	/* lthuang */
		uinfo.mode = PAGE;
		update_ulist(cutmp, &uinfo);
		if (tkuinf->pid <= 2)	/* lthuang */
		{
			uinfo.sockactive = FALSE;
			uinfo.destid[0] = '\0';
			uinfo.mode = TMENU;
			update_ulist(cutmp, &uinfo);
			return -1;
		}
		else
			kill(tkuinf->pid, SIGUSR1);
		clear();
		prints(_msg_talk_27, tkuinf->userid);
		listen(sock, 1);
		add_io(sock, 20);
		while (1)
		{
			int ch;

			ch = getkey();
			if (ch == I_TIMEOUT)
			{
				move(0, 0);
				outs(_msg_talk_28);
				bell();
				if (tkuinf->pid <= 2)	/* lthuang */
				{
					outs(_msg_talk_29);
					pressreturn();
					return -1;
				}
				if (kill(tkuinf->pid, SIGUSR1) == -1)
				{
					outs(_msg_talk_29);
					pressreturn();
					return -1;
				}
			}
			else if (ch == I_OTHERDATA)
				break;
			else if (ch == '\004')	/* CTRL-D */
			{
				add_io(0, 0);
				close(sock);
				uinfo.sockactive = FALSE;
				uinfo.destid[0] = '\0';		/* lthuang */
				update_ulist(cutmp, &uinfo);
				return -1;
			}
		}
		if ((msgsock = accept(sock, (struct sockaddr *) 0, (int *) 0)) < 0)
		{
			perror("accept");
			return -1;
		}
		add_io(0, 0);
		close(sock);
		uinfo.sockactive = FALSE;
		read(msgsock, &reponse, sizeof reponse);
		if (reponse == 'y')
			do_talk(msgsock);
		else
		{
			outs("\n");
			do
			{
				read(msgsock, &reponse, sizeof(reponse));
				prints("%c", reponse);
			}
			while (reponse != '\n');
			pressreturn();
		}
		close(msgsock);
		uinfo.destid[0] = '\0';
		update_ulist(cutmp, &uinfo);
	}
	return 0;
}


int
t_talk()
{
	char userid[IDLEN];
	USER_INFO *talk_uinfo;

	if (curuser.userlevel < PERM_PAGE && curuser.ident != 7)
	{
		msg(_msg_sorry_newuser);
		getkey();
		return M_FULL;
	}

	if (CompleteOnlineUser(userid) == 0)
	{
		if (!(talk_uinfo = search_ulist(cmp_userid, userid)))
		{
			msg(_msg_talk_24);
			getkey();
		}
		else
			talk_user(talk_uinfo);
	}
	return M_FULL;
}




static int
cmp_destid(ident, up)
char *ident;
register USER_INFO *up;
{
	if (up == NULL || up->userid[0] == '\0')
		return 0;
	return !strcmp(ident, up->destid);
}



USER_INFO ui;			/* partner's online info */
char page_requestor[STRLEN];	/* partner's personal description */

static int
searchuserlist(ident)
char *ident;
{
	register USER_INFO *up;

	if ((up = search_ulist(cmp_destid, ident)))	/* -ToDo- uid compare */
	{
		memcpy(&ui, up, sizeof(USER_INFO));
		return 1;
	}
	return 0;
}


static int
setpagerequest()
{
	if (searchuserlist(curuser.userid) == 0)
		return 1;
	if (!ui.sockactive)
		return 1;
	xstrncpy(uinfo.destid, ui.userid, IDLEN);	/* lthuang */
	sprintf(page_requestor, "%s (%s)", ui.userid, ui.username);	/* lthuang */
	return 0;
}


BOOL
servicepage(arg)
int arg;
{
	static time_t last_check;
	time_t now;
	char buf[STRLEN];

	if (searchuserlist(curuser.userid) == 0 || !ui.sockactive)
		talkrequest = FALSE;
	if (!talkrequest)
	{
		if (page_requestor[0])
		{
			switch (uinfo.mode)
			{
			case TALK:
				move(arg, 0);
				prints("-----------------------------------------------------------");	/* ?? */
				prints("");
				break;
			default:	/* a chat mode */
				sprintf(buf, "** INFO: no longer paged by %s", page_requestor);
				printchatline(buf);
			}
			memset(page_requestor, 0, sizeof(page_requestor));
			last_check = 0;
		}
		return FALSE;
	}
	else
	{
		now = time(0);
		if (now - last_check > P_INT)
		{
			last_check = now;
			if (!page_requestor[0] && setpagerequest())
				return FALSE;
			switch (uinfo.mode)
			{
			case TALK:
				move(arg, 0);
				prints(_msg_talk_30, page_requestor);
				break;
			default:	/* chat */
				sprintf(buf, "** INFO: being paged by %s", page_requestor);
				printchatline(buf);
			}
		}
	}
	return TRUE;
}


int
talkreply()
{
	int a;
	int ch;
	char save_destid[IDLEN];	/* lthuang */

	talkrequest = FALSE;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return -1;
#endif

	if (setpagerequest() != 0)
		return 0;
	xstrncpy(save_destid, uinfo.destid, IDLEN);	/* lthuang */
	do
	{
		char ans[2];

		clear();
		/*QueryUser(ui.userid); */
		sprintf(genbuf, _msg_talk_31, ui.from, page_requestor);
		if (getdata(0, 0, genbuf, ans, sizeof(ans), DOECHO|LOWCASE, NULL))
		{
			if (ans[0] == 'y' || ans[0] == 'n')
			{
				ch = ans[0];
				break;
			}
		}
		QueryUser(ui.userid);
	}
	while (1);

	xstrncpy(uinfo.destid, save_destid, IDLEN);
	memset(page_requestor, 0, sizeof(page_requestor));

	if ((a = ConnectServer("127.0.0.1", ntohs((u_short) ui.sockaddr))) < 0)
	{
		outs(_msg_talk_32);
		pressreturn();
		return -1;
	}
	if (ch == 'y')		/* lthuang */
		write(a, "y", 1);
	else
		write(a, "n", 1);
	if (ch != 'y')
	{
		char *talkrefuse[] =
		{
			_msg_talk_refuse_1,
			_msg_talk_refuse_2,
			_msg_talk_refuse_3,
			_msg_talk_refuse_4,
			_msg_talk_refuse_5,
			_msg_talk_refuse_6,
			_msg_talk_refuse_7,
			_msg_talk_refuse_8,
			NULL
		};
		char buf[STRLEN];
		int i, maxrefused;

		clear();
		for (i = 0; talkrefuse[i]; i++)
			prints("[%d] %s\n", i + 1, talkrefuse[i]);
		maxrefused = i;
		outs(_msg_talk_33);
		i = (getkey() - '0');
		if (i < 1 || i > maxrefused)
			i = 1;
		strcpy(buf, talkrefuse[i - 1]);
		if (i == maxrefused)
			getdata(maxrefused + 2, 0, _msg_talk_34, buf, sizeof(buf), DOECHO, NULL);
		strcat(buf, "\n");
		write(a, buf, strlen(buf));
	}
	else
		do_talk(a);
	close(a);
	return 0;
}


void
do_talk_char(sline, eline, curln, curcol, wordbuf, wordbuflen, ch)
int sline, eline;
int *curln, *curcol;
char *wordbuf;
int *wordbuflen;
int ch;
{
#if	defined(BIT8)
	if (isprint2(ch))
#else
	if (isprint(ch))
#endif
	{
		if (*curcol != 79)
		{
			wordbuf[(*wordbuflen)++] = ch;
			if (ch == ' ')
				*wordbuflen = 0;
			move(*curln, (*curcol)++);
			prints("%c", ch);
			return;
		}
		if (ch == ' ' || *wordbuflen >= 78)
		{
			(*curln)++;
			*curcol = 0;
			if (*curln > eline)
				*curln = sline;
			if ((*curln) != eline)
			{
				move((*curln) + 1, 0);
				clrtoeol();
			}
			move(*curln, *curcol);
			clrtoeol();
			*wordbuflen = 0;
			return;
		}
		move(*curln, (*curcol) - *wordbuflen);
		clrtoeol();
		(*curln)++;
		*curcol = 0;
		if (*curln > eline)
			*curln = sline;
		if ((*curln) != eline)
		{
			move((*curln) + 1, 0);
			clrtoeol();
		}
		move(*curln, *curcol);
		clrtoeol();
		wordbuf[*wordbuflen] = '\0';
		prints("%s%c", wordbuf, ch);
		*curcol = (*wordbuflen) + 1;
		*wordbuflen = 0;
		return;
	}
	switch (ch)
	{
	case CTRL('H'):
	case '\177':
		if (*curcol == 0)
		{
			if (sline == 0)
				bell();
			return;
		}
		(*curcol)--;
		move(*curln, *curcol);
		prints(" ");
		move(*curln, *curcol);
		if (*wordbuflen)
			(*wordbuflen)--;
		return;
	case CTRL('M'):
	case CTRL('J'):
		(*curln)++;
		*curcol = 0;
		if (*curln > eline)
			*curln = sline;
		if ((*curln) != eline)
		{
			move((*curln) + 1, 0);
			clrtoeol();
		}
		move(*curln, *curcol);
		clrtoeol();
		*wordbuflen = 0;
		return;
	case CTRL('G'):
		bell();
		return;
	default:

		break;
	}
}


void
do_talk_string(sline, eline, curln, curcol, wordbuf, wordbuflen, s)
int sline, eline;
int *curln, *curcol;
char *wordbuf;
int *wordbuflen;
char *s;
{
	while (*s)
	{
		do_talk_char(sline, eline, curln, curcol, wordbuf, wordbuflen, *s);
		s++;
	}
}


unsigned char talkobuf[80];
unsigned int talkobuflen;
int talkflushfd;

talkflush()
{
	if (talkobuflen)
		write(talkflushfd, talkobuf, talkobuflen);
	talkobuflen = 0;
}


void
do_talk(fd)
int fd;
{
	USEREC user;
	int myln, mycol, myfirstln, mylastln;
	int itsln, itscol, itsfirstln, itslastln;
	char itswordbuf[80], mywordbuf[80];
	int itswordbuflen, mywordbuflen;
	int page_pending = FALSE;

	itswordbuflen = 0;
	mywordbuflen = 0;
	talkobuflen = 0;
	talkflushfd = fd;

	update_umode(TALK);

	get_passwd(&user, uinfo.destid);

	clear();
	myfirstln = 0;
	mylastln = (b_line / 2) - 1;
	move(mylastln + 1, 0);
	prints(_msg_talk_35, curuser.userid, user.userid, user.username);
	itsfirstln = mylastln + 2;
	itslastln = (t_lines - 1);
	myln = myfirstln;
	mycol = 0;
	itsln = itsfirstln;
	itscol = 0;
	move(myln, mycol);
	add_io(fd, 0);
	add_flush(talkflush);
	while (1)
	{
		int ch;

		if (talkrequest)
			page_pending = TRUE;
		if (page_pending)
			page_pending = servicepage(mylastln + 1);
		if (writerequest)	/* lthuang */
		{
			int x, y;

			getyx(&y, &x);
			writereply();
			move(mylastln + 1, 0);
			prints(_msg_talk_35, curuser.userid, user.userid, user.username);
			move(y, x);
			continue;
		}
		ch = getkey();
		if (ch == I_OTHERDATA)
		{
			char data[80];
			int datac;
			register int i;

			datac = read(fd, data, 80);
			if (datac <= 0)
			{
				break;
			}
			for (i = 0; i < datac; i++)
				do_talk_char(itsfirstln, itslastln, &itsln, &itscol, itswordbuf,
					     &itswordbuflen, data[i]);
		}
		else
		{
			if (ch == CTRL('D') || ch == CTRL('C'))
			{
				int x, y;

				getyx(&y, &x);
				move(mylastln + 1, 0);
				outs(_msg_talk_36);
				clrtoeol();
				if (igetkey() == 'y')
					break;
				move(mylastln + 1, 0);
				prints(_msg_talk_35, curuser.userid, user.userid, user.username);
				move(y, x);
			}
			else if (
#ifdef BIT8			
			         isprint2(ch) 
#else
			         isprint(ch)
#endif			         
			         || ch == CTRL('H') || ch == '\177' || ch == CTRL('G')
			         || ch == '\n' || ch == '\r' || ch == CTRL('M'))
			{
				talkobuf[talkobuflen++] = ch;
				if (talkobuflen >= 80)
					talkflush();
				do_talk_char(myfirstln, mylastln, &myln, &mycol, mywordbuf,
					     &mywordbuflen, ch);
			}
			else if (ch == CTRL('P'))
			{
				if (uinfo.pager == TRUE)
				{
					do_talk_string(myfirstln, mylastln, &myln, &mycol, mywordbuf, &mywordbuflen, "*** Pager turned off ***\n");
					uinfo.pager = FALSE;
				}
				else
				{
					do_talk_string(myfirstln, mylastln, &myln, &mycol, mywordbuf, &mywordbuflen, "*** Pager turned on ***\n");
					uinfo.pager = TRUE;
				}
				update_ulist(cutmp, &uinfo);
			}
			else if (ch == CTRL('R'))
			{
				int y, x;

				getyx(&y, &x);
				ReplyLastCall();
				move(mylastln + 1, 0);
				prints(_msg_talk_35, curuser.userid, user.userid, user.username);
				move(y, x);
			}
			else
				bell();
		}
	}
	add_io(0, 0);
	talkflush();
	add_flush(NULL);
}


int
t_irc()
{
	if (curuser.userlevel < PERM_PAGE && curuser.ident != 7)
	{
		msg(_msg_sorry_newuser);
		getkey();
		return M_FULL;
	}

	sprintf(genbuf, "ircc \"%s\" %s %d",
		curuser.userid, curuser.lasthost, two_enter);
	outdoor(genbuf, IRCCHAT, TRUE);		/* ? */

	return M_FULL;
}


#ifdef USE_LOCALIRC
int
t_ircl()
{
	if (curuser.userlevel < PERM_PAGE && curuser.ident != 7)
	{
		msg(_msg_sorry_newuser);
		getkey();
		return M_FULL;
	}

	sprintf(genbuf, "ircl \"%s\" %s %d chat5",
		curuser.userid, curuser.lasthost, two_enter);
	outdoor(genbuf, LOCALIRC, TRUE);	/* ? */

	return M_FULL;
}

#endif


int
DoMessageUser(upent)
USER_INFO *upent;
{
	char buf[PATHLEN];
	FILE *fp;
	time_t now = time(0);
	short lines = 0;
	char timestr[8], save_destid[IDLEN];
	struct stat st;

	if (upent->userid == NULL || upent->userid[0] == '\0')
		return -1;
#ifdef GUEST_ACCOUNT
	if (!strcmp(upent->userid, GUEST_ACCOUNT))
		return -1;
#endif

	setuserfile(buf, upent->userid, UFNAME_WRITE);
	if (stat(buf, &st) == 0 && st.st_size > 0)
		lines = 1;
	if ((fp = fopen(buf, "a+")) == NULL)
		return -1;

	xstrncpy(save_destid, uinfo.destid, IDLEN);	/* lthuang */
	xstrncpy(uinfo.destid, upent->userid, IDLEN);	/* lthuang */
	update_ulist(cutmp, &uinfo);	/* lthuang */

	if (lines)		/* lthuang */
		fprintf(fp, "\n");
	strftime(timestr, 6, "%R", localtime(&now));
	fprintf(fp, "%s\t%s\t%s\t%s\t",
		curuser.userid, (curuser.username[0]) ? curuser.username : " ", out_mesg, timestr);
	fclose(fp);
	if (upent->pid > 2)	/* lthuang */
		kill(upent->pid, SIGUSR2);
	xstrncpy(uinfo.destid, save_destid, IDLEN);
	update_ulist(cutmp, &uinfo);
	return 0;
}


char LastCaller[IDLEN] = "\0";


int
ParseMesgStr(string, fillinstr)
char *string, *fillinstr;
{
	char *timestr, *id, *name, *ReadedMesg, *ptr;
	char format[80], SpaceFormat[80];
	unsigned int avail_len;

	if ((id = strtok(string, "\t")) == NULL)
		return -1;
	if ((name = strtok(NULL, "\t")) == NULL)
		return -1;
	if ((ReadedMesg = strtok(NULL, "\t")) == NULL)
		return -1;
	if ((timestr = strtok(NULL, "\t")) == NULL)
		return -1;
	if ((ptr = strchr(timestr, '\n')))
		*ptr = '\0';
	strncpy(LastCaller, id, IDLEN);

	avail_len = 75 - strlen(timestr) - strlen(id) - MIN(UNAMELEN - 1, strlen(name));
	sprintf(format, "[1;37;45m%%s [33m%%s(%%.%ds):[36m %%.%ds",
		UNAMELEN - 1, avail_len);

	if (strlen(ReadedMesg) < avail_len)
	{
		sprintf(SpaceFormat, "%%%ds[m", avail_len - strlen(ReadedMesg));
		strcat(format, SpaceFormat);
	}
	else
		strcat(format, "[m");

	sprintf(fillinstr, format, timestr, id, name, ReadedMesg, "\0");
	return 0;
}


int
PrepareMesgContent(who)
char *who;
{
	if (ask_online_user() < 2)
		return -1;
	if (getdata(b_line, 0, _msg_talk_37, out_mesg, sizeof(out_mesg), DOECHO, NULL))
	{
		msg(_msg_talk_38, who);
		if (igetkey() != 'n')
			return 0;
	}
	msg(_msg_abort);
	getkey();
	return -1;
}


int
SendMesgToSomeone(ident)
char *ident;
{
	USER_INFO *quinf;

#ifdef GUEST_ACCOUNT
	if (!strcmp(ident, GUEST_ACCOUNT))
	{
		msg(_msg_talk_39);
		getkey();
		return -1;
	}
#endif
	if (!strcmp(ident, curuser.userid))
	{
		msg(_msg_talk_40);
		getkey();
		return -1;
	}

	if (!(quinf = search_ulist(cmp_userid, ident))
	    || (!HAS_PERM(PERM_CLOAK) && quinf->invisible))
	{
		msg(_msg_talk_41);
		getkey();
		return -1;
	}
	if (!HAS_PERM(PERM_SYSOP) && !quinf->pager
	    && !can_override(quinf, curuser.userid))
	{
#ifdef HAVE_CHK	
		if ((quinf->chk && curuser.ident != 7)
		    || !quinf->chk)
		{
			msg(_msg_talk_42);
			getkey();
			return -1;
		}
#endif		
	}
	
	if (InOutdoor(quinf))
	{
		msg(_msg_talk_43);
		getkey();
		return -1;
	}

	if (DoMessageUser(quinf) == -1)
	{
		msg(_msg_message_fail);
		getkey();
		return -1;
	}
	msg(_msg_message_finish);
	getkey();
	return 0;
}


int
ReplyLastCall()			/* lthuang */
{
	FILE *fp;
	int my_newfd;		/* lthuang */
	extern int i_newfd;


#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return -1;
#endif

	my_newfd = i_newfd;
	i_newfd = 0;

	if ((fp = fopen(ufile_write, "r")) != NULL)
	{
		char LastReadedMesg[128], ShowedMesg[128];

		while (fgets(LastReadedMesg, sizeof(LastReadedMesg), fp))
			/* NULL STATEMENT */ ;
		fclose(fp);
		if (ParseMesgStr(LastReadedMesg, ShowedMesg) == 0)
		{
			msg(ShowedMesg);
			move(b_line - 1, 0);
			clrtoeol();
			outs(_msg_talk_46);
			if (igetkey() == 'y')
			{
				if (PrepareMesgContent(LastCaller) == 0)
					SendMesgToSomeone(LastCaller);
			}
			i_newfd = my_newfd;
			return 0;
		}
	}
	msg(_msg_talk_47);
	getkey();
	i_newfd = my_newfd;
	return 0;
}


int
writereply()			/* lthuang */
{
	FILE *fp;
	int my_newfd;		/* lthuang */

	extern int i_newfd;

	writerequest = FALSE;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return -1;
#endif

	my_newfd = i_newfd;
	i_newfd = 0;

	if ((fp = fopen(ufile_write, "r")) != NULL)
	{
		char new_message[128], show_message[128];
		int ch;

		while (fgets(new_message, sizeof(new_message), fp))
			/* NULL STATEMENT */ ;
		fclose(fp);
		if (ParseMesgStr(new_message, show_message) == 0)
		{
			msg(show_message);
			move(b_line - 1, 0);	/* avoid screen scroll */
			clrtoeol();
			outs(_msg_talk_48);
			warn_bell();
			while ((ch = getkey()) != EOF)
			{
				if (ch == CTRL('R'))
				{
					if (PrepareMesgContent(LastCaller) == 0)
						SendMesgToSomeone(LastCaller);
					break;
				}
				else if (ch == '\r' || ch == '\n')
					break;
			}
		}
	}
	i_newfd = my_newfd;	/* lthuang */
	return 0;
}


int
t_review()
{
	FILE *fp;
	int lines;
	int count = 0;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return M_FULL;
#endif
	if ((fp = fopen(ufile_write, "r")) != NULL)
	{
		char one_message[STRLEN + 40], show_message[STRLEN + 60];

		clear();
		prints("[7m%-5s %-35s %-36s[m\n",
		       _msg_talk_49, _msg_talk_50, _msg_talk_51);
		lines = 1;
		while (fgets(one_message, sizeof(one_message), fp))
		{
			if (ParseMesgStr(one_message, show_message) == 0)
			{
				prints("%s\n", show_message);
				count++;
				if (++lines == b_line)
				{
					lines = 1;
					outs(_msg_talk_52);
					if (igetkey() == 'q')
					{
						fclose(fp);
						return M_FULL;
					}
					move(1, 0);
					clrtobot();
				}
			}
		}
		fclose(fp);
		pressreturn();
	}
	if (count == 0)
	{
		msg(_msg_talk_47);
		getkey();
	}
	return M_FULL;
}


int
t_message()
{
	char userid[IDLEN];

	if (curuser.userlevel < PERM_PAGE && curuser.ident != 7)
	{
		msg(_msg_sorry_newuser);
		getkey();
		return M_FULL;
	}

	if (CompleteOnlineUser(userid) == 0)
	{
		if (PrepareMesgContent(userid) == 0)
			SendMesgToSomeone(userid);
	}
	return M_FULL;
}


#ifdef USE_FRIEND_BROADCAST
static int
BroadcastFriend(upent)
USER_INFO *upent;
{
	if (!upent || upent->userid[0] == '\0')
		return -1;
#ifdef GUEST_ACCOUNT
	if (!strcmp(upent->userid, GUEST_ACCOUNT))
		return -1;
#endif
	if (!strcmp(upent->userid, curuser.userid))
		return -1;

	if (!HAS_PERM(PERM_CLOAK) && upent->invisible)
		return -1;
	if (!HAS_PERM(PERM_SYSOP) && !upent->pager
	    && !can_override(upent, curuser.userid))
	{
		return -1;
	}
	if (InOutdoor(upent))
		return -1;

	if (MyFriend(upent->userid))
		DoMessageUser(upent);
	return 0;
}


int
t_fsendmsg()
{
	if (curuser.userlevel < PERM_PAGE && curuser.ident != 7)
	{
		msg(_msg_sorry_newuser);
		getkey();
		return M_FULL;
	}

	if (PrepareMesgContent(_msg_talk_57) == 0)
	{
		apply_ulist(BroadcastFriend);
		msg(_msg_message_finish);
		getkey();
	}
	return M_FULL;
}

#endif


/* 
   test whether the user is running outdoor event or not,
   usually he cannot receive signal from others
 */
int
InOutdoor(uinfo_ent)
USER_INFO *uinfo_ent;
{
#ifdef USE_LOCALIRC
	if (uinfo_ent->mode == LOCALIRC)
		return 1;
#endif
#ifdef USE_IRC
	if (uinfo_ent->mode == IRCCHAT)
		return 1;
#endif
	return 0;
}


