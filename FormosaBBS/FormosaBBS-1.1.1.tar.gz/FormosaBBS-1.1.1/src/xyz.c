/* 
 *  Li-te Huang, lthuang@cc.nsysu.edu.tw, 03/11/98
 *  Last updated: 04/22/98
 *  Todo: ARGUSED part
 */   

#include "bbs.h"
#include "tsbbs.h"


extern char *genpasswd();


void
show_user_info(urcPerson)
USEREC *urcPerson;
{
	char *prefix = "\n   ";
	
	move(1, 0);
	clrtobot();		
	if (HAS_PERM(PERM_SYSOP))
		prints(_msg_xyz_1, urcPerson->uid);
	else
		outs(_msg_xyz_2);

	prints(prefix);
	prints(_msg_xyz_3, urcPerson->userid);
#if HAVE_IDENT
	outs((urcPerson->ident == 7) ? _msg_xyz_4 : _msg_xyz_5);
#endif

	prints(prefix);
	prints(_msg_xyz_6, 
	       (urcPerson->firstlogin) ? Ctime(&urcPerson->firstlogin) : "unknown");
	
	prints("\n1) ");
	prints(_msg_xyz_7, urcPerson->username);

	prints("\n2) ");	
	prints(_msg_xyz_8, urcPerson->email);

	prints(HAS_PERM(PERM_SYSOP)	? "\n3) " : prefix);
	prints(_msg_xyz_11, urcPerson->userlevel);	

	prints(HAS_PERM(PERM_SYSOP)	? "\n4) " : prefix);	
	prints(_msg_xyz_9, urcPerson->numlogins);
	
	prints(HAS_PERM(PERM_SYSOP)	? "\n5) " : prefix);		
	prints(_msg_xyz_10, urcPerson->numposts);


	outs("\n=======================================================\n");
}


int
x_info()
{
	int tries = 0;
	char opass[PASSLEN];

	for (;;)
	{
		move(1, 0);
		clrtobot();
		if (getdata(1, 0, _msg_xyz_13, opass, sizeof(opass), NOECHO, NULL))
		{
			if (checkpasswd(curuser.passwd, opass))
				break;
		}
		if (++tries == 3)
		{
			outs(_msg_xyz_14);
			pressreturn();
			abort_bbs(0);
			/* NOT REACHED */
		}
		outs(_msg_xyz_15);
		pressreturn();
	}
	show_user_info(&curuser);
	modify_user(&curuser, TRUE);	/* modify by myself */
	return M_FULL;
}


int
x_date()
{
	time_t now = time(0);

	move(1, 0);
	clrtoeol();
	prints(_msg_xyz_16, Ctime(&now));
	pressreturn();
	return M_FULL;
}


int
x_signature()
{
	struct stat st;
	char filename[PATHLEN];

	sethomefile(filename, curuser.userid, UFNAME_SIGNATURES);
	move(1, 0);
	clrtobot();

	if (curuser.flags[0] & SIG_FLAG)
		getdata(1, 0, _msg_xyz_17, genbuf, 2, ECHONOSP|LOWCASE, NULL);
	else
		getdata(1, 0, _msg_xyz_18, genbuf, 2, ECHONOSP|LOWCASE, NULL);

	/* let user edit or delete nth signature more easily */
	if (genbuf[0] == 'd' || genbuf[0] == 'e')
	{
		char path_new[PATHLEN];
		int ch, num;
		FILE *fp_new, *fp_sig;
		int i;

		ch = genbuf[0];
		
		if ((fp_sig = fopen(filename, "r")) == NULL)
		{
			if ((fp_sig = fopen(filename, "w+")) == NULL)
				return M_FULL;
		}

		move(2, 0);
		outs("\n");
		num = 0;
		for (i = 0; i < (MAX_SIG_LINES * MAX_SIG_NUM) && fgets(genbuf, sizeof(genbuf), fp_sig); i++)
		{
			if (i % MAX_SIG_LINES == 0)
				prints("[1;36m[%s #%d][m\n", _msg_signature, ++num);
			outs(genbuf);
		}
	
		getdata(2, 0, _msg_xyz_57, genbuf, 2, ECHONOSP, NULL);
		num = genbuf[0] - '0';
		if (num < 1 || num > 3)
		{
			fclose(fp_sig);
			move(b_line - 1, 0);
			clrtoeol();
			outs(_msg_abort);
			pressreturn();
			return M_FULL;
		}

		sprintf(path_new, "tmp/%s.signew", curuser.userid);
		if ((fp_new = fopen(path_new, "w")) == NULL)
		{
			fclose(fp_sig);
			move(b_line - 1, 0);
			clrtoeol();
			outs(_msg_xyz_60);
			pressreturn();
			return M_FULL;
		}
			
		fseek(fp_sig, 0, SEEK_SET);
		/* �ɤJ�e����ñ�W�� */
		i = 1 + (num - 1) * MAX_SIG_LINES;
		while (i-- > 1 && fgets(genbuf, sizeof(genbuf), fp_sig))
			fputs(genbuf, fp_new);
		
		if (ch == 'd')
		{
			i = MAX_SIG_LINES;
			while (i-- > 0 && fgets(genbuf, sizeof(genbuf), fp_sig))
				/* NULL STATEMENT */;
		}
		else 
		{
			FILE *fp_edit;
			char path_edit[PATHLEN];
			
			sprintf(path_edit, "tmp/%s.sigedit", curuser.userid);
			if ((fp_edit = fopen(path_edit, "w")) != NULL)
			{
				i = MAX_SIG_LINES;
				while (i-- > 0 && fgets(genbuf, sizeof(genbuf), fp_sig))
					fputs(genbuf, fp_edit);
				fclose(fp_edit);
			}

			i = MAX_SIG_LINES;			
			if (!vedit(path_edit, NULL))
			{
				if ((fp_edit = fopen(path_edit, "r")) != NULL)				
				{
					while (i > 0 && fgets(genbuf, sizeof(genbuf), fp_edit))
					{
						fputs(genbuf, fp_new);
						i--;
					}
					fclose(fp_edit);
				}
			}
			while (i-- > 0)
				fputs("\n", fp_new);
			unlink(path_edit);
		}

		while (fgets(genbuf, sizeof(genbuf), fp_sig))
			fputs(genbuf, fp_new);

		fclose(fp_sig);
		fclose(fp_new);
		move(b_line - 1, 0);
		clrtoeol();
		if (myrename(path_new, filename) == 0)
			outs(_msg_finish);
		else
			outs(_msg_fail);
/*
		unlink(filename);
		clrtobot();		
		outs(_msg_xyz_19);
*/
	}
	else if (genbuf[0] == 't')
	{
		if (curuser.flags[0] & SIG_FLAG)
			outs(_msg_xyz_20);
		else
			outs(_msg_xyz_21);
		curuser.flags[0] ^= SIG_FLAG;			
	}

	if (stat(filename, &st) == 0)
	{
		if (st.st_size == 0)
			unlink(filename);
#ifdef MAX_SIG_SIZE			
		else if (st.st_size > MAX_SIG_SIZE)
		{
			prints(_msg_xyz_22, MAX_SIG_SIZE);
			truncate(filename, MAX_SIG_SIZE);
		}
#endif		
	}
	pressreturn();
	return M_FULL;
}


int
x_ircrc()
{
	char filename[PATHLEN];
	struct stat st;

	sethomefile(filename, curuser.userid, UFNAME_IRCRC);
	move(1, 0);
	clrtobot();
	getdata(1, 0, _msg_xyz_23, genbuf, 2, ECHONOSP|LOWCASE, NULL);
	if (genbuf[0] == 'd')
	{
		unlink(filename);
		outs(_msg_xyz_24);
	}
	else
	{
		if (!vedit(filename, NULL))
			outs(_msg_finished);

		if (stat(filename, &st) == 0)
		{
			if (st.st_size == 0)
				unlink(filename);
#ifdef MAX_IRCRC_SIZE		
			else if (st.st_size > MAX_IRCRC_SIZE)
			{
				prints(_msg_xyz_25, MAX_IRCRC_SIZE);
				truncate(filename, MAX_IRCRC_SIZE);
			}
#endif			
		}
	}
	pressreturn();
	return M_FULL;
}


int
x_plan()
{
	char filename[PATHLEN];
	struct stat st;

	sethomefile(filename, curuser.userid, UFNAME_PLANS);
	move(1, 0);
	clrtobot();
	getdata(1, 0, _msg_xyz_26, genbuf, 2, ECHONOSP|LOWCASE, NULL);
	if (genbuf[0] == 'd')
	{
		unlink(filename);
		outs(_msg_xyz_27);
	}
	else
	{
		if (!vedit(filename, NULL))
			outs(_msg_finished);

		if (stat(filename, &st) == 0)
		{
			if (st.st_size == 0)
				unlink(filename);
#ifdef MAX_PLAN_SIZE		
			else if (st.st_size > MAX_PLAN_SIZE)
			{
				prints(_msg_xyz_28, MAX_PLAN_SIZE);
				truncate(filename, MAX_PLAN_SIZE);
			}
#endif		
		}
	}
	pressreturn();
	return M_FULL;
}


static int
friend_display()
{
	int x = 0, y = 3, cnt = 0;

	load_friend_cache();

	move(2, 0);
	clrtobot();
	while (cnt < friend_cache->number)
	{
		move(y, x);
		outs(friend_cache->datap[cnt++]);
		if (++y >= b_line)
		{
			y = 3;
			x = x + 16;
			if (x >= 80)
			{
				pressreturn();
				x = 0;
				move(y, x);
				clrtobot();
			}
		}
	}
	if (cnt == 0)
	{
		move(y, x);
		outs(_msg_talk_1);
	}
	return cnt;
}


int
x_override()
{
	int nFriend;
	char usFriend[IDLEN];

	outs(_msg_xyz_29);
	for (;;)
	{
		nFriend = friend_display();
		if (nFriend)
			getdata(1, 0, _msg_xyz_32, genbuf, 2, ECHONOSP|LOWCASE, NULL);
		else
			getdata(1, 0, _msg_xyz_33, genbuf, 2, ECHONOSP|LOWCASE, NULL);

		if (genbuf[0] == 'a')
		{
			if (getdata(2, 0, _msg_ent_userid, usFriend, sizeof(usFriend), ECHONOSP, NULL))
				friend_add(usFriend);
		}
		else if (genbuf[0] == 'd' && nFriend)
		{
			if (getdata(2, 0, _msg_ent_userid, usFriend, sizeof(usFriend), ECHONOSP, NULL))
				friend_delete(usFriend);
		}
		else
			break;
	}
	return M_FULL;
}


int
modify_user(urcOld, myself)
USEREC *urcOld;
int myself;
{
	char buf[STRLEN];
	USEREC urcNew;
	char temp[40];

	if (!urcOld || urcOld->userid[0] == '\0')
		return 0;

	outs(_msg_not_sure_modify);
	getdata(0, 0, NULL, buf, 2, ECHONOSP|LOWCASE, NULL);
	if (buf[0] != 'y')
		return 0;

	memcpy(&urcNew, urcOld, sizeof(urcNew));
	
	for (;;)
	{
		show_user_info(&urcNew);
		if (!getdata(b_line - 1, 0, _msg_xyz_36, buf, 2, ECHONOSP|LOWCASE, NULL))
			break;

		switch(buf[0])
		{
			case '0':
				/* change password */
				if (getdata(15, 0, _msg_xyz_37, buf, PASSLEN, NOECHO, NULL))
				{
					char npass[PASSLEN];

					getdata(16, 0, _msg_xyz_38, npass, sizeof(npass), NOECHO, NULL);
					if (!strcmp(npass, buf))
						strncpy(urcNew.passwd, genpasswd(npass), PASSLEN);
					else
					{
						outs(_msg_xyz_39);
						getkey();
					}
				}
				break;
			case '1':
				/* change username */
				getdata(4, 21, "\0", buf, sizeof(urcNew.username), DOECHO, urcNew.username);
				strcpy(urcNew.username, buf);
				break;
			case '2':
				/* change e-mail address */
				getdata(5, 14, "\0", buf, sizeof(urcNew.email), ECHONOSP, urcNew.email);
				move(13, 0);				
				if (CheckFwdEmailaddr(buf) == -1)
				{
					outs(_msg_xyz_42);
					getkey();
				}
				else
					strcpy(urcNew.email, buf);
				break;
			case '3':
				/* change userlevel */
				if (HAS_PERM(PERM_SYSOP))
				{
					sprintf(temp, "%d", urcNew.userlevel);
					getdata(6, 14, "\0", buf, 4, ECHONOSP, temp);
					urcNew.userlevel = atoi(buf);
				}
				break;
			case '4':
				/* change numlogins */
				if (HAS_PERM(PERM_SYSOP))	
				{
					sprintf(temp, "%d", urcNew.numlogins);
					getdata(7, 14, "\0", buf, 6, ECHONOSP, temp);
					urcNew.numlogins = atoi(buf);
				}
				break;
			case '5':
				/* change numposts */
				if (HAS_PERM(PERM_SYSOP))
				{
					sprintf(temp, "%d", urcNew.numposts);
					getdata(8, 14, "\0", buf, 6, ECHONOSP, temp);
					urcNew.numposts = atoi(buf);
				}
				break;
			default:
				break;
			}
	}
	
	move(b_line - 4, 0);
	clrtobot();
	if (myself)
		prints(_msg_xyz_47);
	else
		prints(_msg_xyz_55, urcOld->userid);
	getdata(b_line - 3, 0, _msg_not_sure_modify, buf, 4, ECHONOSP|LOWCASE, NULL);
	move(b_line - 1, 0);
	clrtoeol();
	if (buf[0] != 'y')
	{
		outs(_msg_abort);
		pressreturn();
		return 0;
	}
	
	if (myself)
	{
		/* immediately update user online data */
		memcpy(&curuser, &urcNew, sizeof(USEREC));
		xstrncpy(uinfo.username, urcNew.username, sizeof(uinfo.username));
		update_ulist(cutmp, &uinfo);
	}
	
	if (update_user(&urcNew) > 0)
	{
		outs(_msg_finish);
		pressreturn();
		return 1;
	}
	outs(_msg_fail);
	pressreturn();
	return -1;
}


/* 
   picture menu switch 
*/   
int
x_picture()			/* by lmj */
{
	move(3, 0);
	if (curuser.flags[1] & PICTURE_FLAG)
		outs(_msg_xyz_48);
	else
		outs(_msg_xyz_49);
	curuser.flags[1] ^= PICTURE_FLAG;	
	pressreturn();
	return M_FULL;
}


int
x_noteswitch()			/* by wnlee */
{
	move(3, 0);
	if (curuser.flags[1] & NOTE_FLAG)
		outs(_msg_xyz_50);
	else
		outs(_msg_xyz_51);
	curuser.flags[1] ^= NOTE_FLAG;	
	pressreturn();
	return M_FULL;
}


/*ARGUSED*/
int
x_viewnote()			/* by Seraph */
{
	NOTEDATA curnote;
	struct stat statbuf;
	FILE *fp;
	int fd;
	int i = 1, ch;

	if ((fd = open("log/note.dat", O_RDONLY)) == -1)
		return M_FULL;
	if ((fp = fopen("log/note.dat", "r") )== NULL)
		return M_FULL;
	stat("log/note.dat", &statbuf);
	fclose(fp);
	clear();
	outs(_msg_xyz_52);
	while (read(fd, &curnote, sizeof(curnote)) == sizeof(curnote))
	{
		outs(curnote.buf[3]);
		outs("\n");
		outs(curnote.buf[0]);
		outs(curnote.buf[1]);
		outs(curnote.buf[2]);
		if (++i == 6)
		{
			i = 1;
			msg(_msg_xyz_53);
			ch = igetkey();
			if (ch == 'q' || ch == KEY_LEFT)
			{
				close(fd);
				return M_FULL;
			}
			else if (ch == 'x')
			{
				curuser.flags[1] |= NOTE_FLAG;
				close(fd);
				return M_FULL;
			}
			move(2, 0);
			clrtobot();
		}
	}
	close(fd);	
	msg(_msg_xyz_54, statbuf.st_size, NOTE_SIZE);
	getkey();
	return M_FULL;
}
