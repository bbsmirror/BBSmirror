
#include "bbs.h"
#include "tsbbs.h"


struct BoardList *board_list = NULL, *cb, *cb_end;
unsigned int maxbid/*, lastbid*/;
int total_board = 0;


int
malloc_board(bhentp)
BOARDHEADER *bhentp;
{
	if (can_see_board(bhentp, curuser.userlevel))
	{
		if ((bhentp->brdtype & BRDTYPE_UNZAP)
		    || !(ZapRC_IsZapped(bhentp->bid) && (curuser.flags[0] & YANK_FLAG)))
		{
			cb->name = (char *)malloc(BNAME_LEN);	
			strcpy(cb->name, bhentp->filename);

			cb->owner = (char *)malloc(IDLEN);
			strcpy(cb->owner, bhentp->owner);

			cb->title = (char *)malloc((CBNAME_LEN+4)*sizeof(char));
			strcpy(cb->title, bhentp->title);

			cb->level = bhentp->level;
			cb->class = bhentp->class;
			cb->bid = bhentp->bid;
			cb->brdtype = bhentp->brdtype;
			cb->rewind_time = bhentp->rewind_time;
			cb->firstartno = bhentp->firstartno;
			cb->visit_flag = 0;	/* lthuang */
#ifdef USE_VOTE
			SetVotePath(genbuf, bhentp->filename);
			cb->vote_flag = UnSeenVote(genbuf);
#endif
			total_board++;
/*			
			cb->num = total_board;
*/			
			/* for class menu */
			cb->clist = NULL;
			cb++;
			if (bhentp->bid > maxbid)
				maxbid = bhentp->bid;
		}
	}
}


/*
 * check board list, if board list is null, then make a new one
 */
int
MakeBoardList()
{
	if (!board_list)
	{
		board_list = (struct BoardList *)malloc(MAXBOARD * sizeof(struct BoardList));
		if (!board_list)
			return -1;
			
		total_board = 0;
		cb = board_list;
		cb_end = board_list;
		ZapRC_Init(curuser.userid);
		
		apply_brdshm(malloc_board);

		if (total_board > 0)
		{
			CurBList = board_list;
			cb_end = board_list	+ total_board - 1;
/*			lastbid = (maxbid > 20) ? maxbid - 20 : 0; */
		}
		else
		{
			free(board_list);
			board_list = (struct BoardList *)NULL;
		}
	}
	return (total_board > 0) ? 0 : -1;
}


struct word *bwtop = NULL;

void
DelBoardList()
{
	bwtop = free_wlist(bwtop, NULL);

	if (board_list)
	{
		for (cb = board_list; cb <= cb_end; cb++)
		{
			if (cb->name)
				free(cb->name);
			if (cb->name)			
				free(cb->owner);
			if (cb->name)			
				free(cb->title);
		}
		free(board_list);
		board_list = (struct BoardList *)NULL;
	}
	total_board = 0;
}


/*
 * Print Board Title
 */
static void
board_title()
{
	move(0, 0);
	clrtoeol();
	prints(_msg_board_1,
	       BOARD_TITLE_COLOR, BBSNAME, BOARD_TITLE_COLOR2,
	       (in_board ? _msg_board_normal : _msg_board_treasure),
	       CurBList->name);
	outs(_msg_board_2);
}


int
CompleteBoardName(data)
char *data;
{
	if (MakeBoardList() == -1)
		return -1;
	move(1, 0);
	clrtobot();
	move(2, 0);
	outs(_msg_board_5);
	move(1, 0);
	outs(_msg_board_6);
	if (!bwtop)
	{
		for (cb = board_list; cb <= cb_end; cb++)
			bwtop = add_wlist(bwtop, cb->name, NULL);
	}
	namecomplete(bwtop, NULL, data);
	if (data[0] == '\0')
		return -1;
	return 0;
}


/*
 * Initialize board
 */
static void
init_board()
{
	ReadRC_Init(CurBList->name, CurBList->bid, curuser.userid);
	if (!CurBList->visit_flag++)
		ReadRC_Refresh(CurBList->name, CurBList->rewind_time, CurBList->firstartno);

	hasBMPerm = FALSE;
	isBM = FALSE;
	
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))	/* debug */
		return;
	
	if (!strcmp(curuser.userid, CurBList->owner))
	{
		hasBMPerm = TRUE;
		isBM = TRUE;
	}
	else
	{
		setboardfile(genbuf, CurBList->name, BM_ASSISTANT);
		if (seek_in_file(genbuf, curuser.userid))
			hasBMPerm = TRUE;
	}
}


int
choose_board()
{
	char bname[BNAME_LEN];

	if (CompleteBoardName(bname) == -1)
		return -1;
	for (cb = board_list; cb <= cb_end; cb++)
	{
		if (!strcasecmp(cb->name, bname))
		{
			CurBList = cb;
			init_board();
			return 0;
		}
	}
	return -1;
}


/*
 * Select in Main Menu 
 */
int
Select()
{
	if (choose_board() == 0)
		Read();
	return M_FULL;
}


/*
 * Search borad from board list by boardname
 */
struct BoardList *
search_board_list(bname)
char *bname;
{
	for (cb = board_list; cb <= cb_end; cb++)
	{
		if (!strcmp(cb->name, bname))
			return cb;
	}
	return (struct BoardList *)NULL;
}


/*
 * Boards/Class Menu
 */
#define PUTCURS   {move(4 + c_cur, 0);outs(_str_cursor);}
#define RMVCURS   {move(4 + c_cur, 0);outs(_str_uncurs);}

#define BRDMENU_ROW	(SCREEN_SIZE-4)
#define MAX_BSLIST  20
#define MAX_CLASS_LEVEL 8

int
Boards(class)
char class;			/* board class, also is 'key press' in menu */
{
	char nbuf[BNAME_LEN];
	int c_top = 0, c_cur = 0, c_bot = 0;
	int mode = B_NEW, ch, nbuf_len = 0, i, brdcnt;
/*	unsigned int lastbid; */
	struct BoardList *cb_list[MAXBOARD];

	/* for classmenu */
	struct BoardList bslist[MAX_BSLIST];
	int save_c_top[MAX_CLASS_LEVEL], save_c_cur[MAX_CLASS_LEVEL];
	struct class_t *save_cs[MAX_CLASS_LEVEL];
	struct class_t *cslist, *cur_cs, *mycs;
	extern struct CLASSHM *classhm;
	int cur_cn;
	
	cur_cn = 0;
	resolve_classhm();
	cslist = classhm->cslist;
	cur_cs = cslist;

	while (1)
	{
		switch (mode)
		{
		case CAREYDOWN:
			RMVCURS;
			if (++c_cur > c_bot)
			{
				c_top += c_cur;
				if (c_top >= brdcnt)
					c_top = 0;
				c_cur = 0;
				mode = B_PART;
				continue;
			}
			break;
		case CAREYUP:
			RMVCURS;
			if (--c_cur < 0)
			{
				if (c_top <= 0)
				{
					c_cur = ((brdcnt-1) % BRDMENU_ROW);
					c_top = ((brdcnt-1) / BRDMENU_ROW) * BRDMENU_ROW;
				}
				else
				{
					c_top -= BRDMENU_ROW;
					c_cur = BRDMENU_ROW - 1;
				}
				mode = B_PART;
				continue;
			}
			break;
		case B_NEW:
			if (MakeBoardList() == -1)
			{
				clear();
				outs(_msg_no_board_exist);
				pressreturn();
				return M_FULL;
			}
			
			if (class == 'c')
			{
				int num_of_bs = 0;
				struct BoardList *tmpcb;
				
				brdcnt = 0;	
				for (mycs = cur_cs; mycs; mycs = mycs->sibling)
				{
					if (mycs->cn[0] == '+')
					{
						if (num_of_bs < MAX_BSLIST) /* lthuang */
						{
							bslist[num_of_bs].clist = mycs;
							cb_list[brdcnt++] = bslist + num_of_bs++;
						}
					}
					else if (mycs->cn[0] == '-')
					{
						tmpcb = search_board_list(mycs->bn);
						if (tmpcb)
						{
							cb->clist = (struct class_t *)NULL;
							cb_list[brdcnt++] = tmpcb;
						}
					}
				}
				if (brdcnt == 0)
				{
					if (cur_cn > 0)
					{
						cur_cn--;
						mode = B_NEW;
						continue;
					}
					return M_FULL;
				}
				mode = B_FULL;
				continue;
			}

			brdcnt = 0;
			for (cb = board_list; cb <= cb_end; cb++)
			{
/*			
				if (class == '0' || cb->class == class
				    || (class == 'n' && cb->bid > lastbid))
*/				    
				{
					cb_list[brdcnt++] = cb;
				}
			}
			if (brdcnt == 0)
			{
				clear();
				outs(_msg_no_board_exist);
				pressreturn();
				return M_FULL;
			}			
				
		case B_FULL:
			clear();
			board_title();

		case B_PART:
			RMVCURS;
		
			c_bot = (brdcnt-1) - c_top;
			if (c_bot >= BRDMENU_ROW)
				c_bot = BRDMENU_ROW - 1;

			move(4, 0);
			clrtobot();
			for (i = 0; i <= c_bot; i++)
			{
				cb = cb_list[c_top + i];

				/* for class menu */
				if (class == 'c' && cb->clist)
					prints("    %3d %s/\n", c_top+i+1, cb->clist->bn);
				else
				prints("  %c %3d %-16.16s %s %2s%s%3d %-28.28s %-12.12s\n",
				       ZapRC_IsZapped(cb->bid) ? '*' : ' ',
				       c_top+i+1,
				       cb->name,
				       (cb->brdtype & BRDTYPE_NEWS) ? _msg_board_3 : "    ",
#if HAVE_IDENT
				       (cb->brdtype & BRDTYPE_IDENT) ? _str_marker :
#endif
				       "",
#ifdef USE_VOTE
				       (cb->vote_flag) ? "[1;36mV[m" :
#endif
				       " ",
				       cb->level,
				       cb->title,
				       cb->owner);
			}
			
		case B_LINE:
			move(b_line, 0);
			prints(_msg_board_4, BOARD_BTITLE_COLOR);
			break;
		default:
			break;
		}

		move(1, 13);
		clrtoeol();
		/* for class menu */
		if (nbuf_len > 0)
			prints("%s", nbuf);
		else
			prints("%-.20s", cb_list[c_top + c_cur]->clist ? 
			       cb_list[c_top + c_cur]->clist->bn : 
			       cb_list[c_top + c_cur]->name);

		PUTCURS;
		
		mode = B_NO;

		if (talkrequest)
		{
			talkreply();
			mode = B_FULL;
			continue;
		}
		else if (writerequest)
		{
			writereply();
			mode = B_FULL;
			continue;
		}

		ch = getkey();
		switch (ch)
		{
		case '$':
			c_top = 0;
		
		case CTRL('B'):
		case KEY_PGUP:
		case 'P':
			c_cur = 0;

		case KEY_UP:
			mode = CAREYUP;
			break;
		case CTRL('F'):
		case KEY_PGDN:
		case 'N':
		case ' ':
			c_cur = c_bot;

		case KEY_DOWN:
			mode = CAREYDOWN;
			break;
		case '\n':
		case '\r':
		case KEY_RIGHT:
			/* for class menu */
			if ((cb_list[c_top + c_cur])->clist)
			{
				if (cur_cn < MAX_CLASS_LEVEL)
				{
					save_c_top[cur_cn] = c_top;
					save_c_cur[cur_cn] = c_cur;
					save_cs[cur_cn] = cb_list[0]->clist;
					cur_cs = (cb_list[c_top + c_cur])->clist->child;
					++cur_cn;
					c_top = 0;
					c_cur = 0;
					mode = B_NEW;
				}
				continue;
			}

			CurBList = cb_list[c_top + c_cur];
#ifdef USE_VOTE
			if (inVoting()) /* In voting, administrator choose his board */
				return;
#endif
			init_board();
			Read();			/* Enter to Read menu */
			update_umode(BOARDS_MENU);	/* lthuang */
			mode = B_FULL;
			break;
		case 'Q':
		case KEY_LEFT:
			/* for class menu */
			if (class == 'c')
			{
				if (cur_cn > 0)
				{
					cur_cs = save_cs[--cur_cn];
					c_top = save_c_top[cur_cn];
					c_cur = save_c_cur[cur_cn];
					mode = B_NEW;
					continue;
				}
				return M_FULL;
			}
			CurBList = cb_list[c_top + c_cur];
			return M_FULL;
		case 'H':
			more(BOARD_HELP, TRUE);
			mode = B_FULL;
			break;
		case 'O':
			if (!curuser.userlevel) /* guest cannot zap board */
				continue;
		
			curuser.flags[0] |= YANK_FLAG;
			DelBoardList();
			MakeBoardList();
			c_top = 0;
			c_cur = 0;
			mode = B_NEW;
			break;
		case 'I':
			if (!curuser.userlevel) /* guest cannot zap board */
				continue;
		
			curuser.flags[0] &= ~YANK_FLAG;
			DelBoardList();	
			MakeBoardList();
			c_top = 0;
			c_cur = 0;
			mode = B_NEW;
			break;			
		case '^':
			c_top = 0;
			c_cur = 0;
			mode = B_PART;
			break;
		case 'Z':
			if (!curuser.userlevel) /* guest cannot zap board */
				continue;
				
			/* for class menu */
			if ((cb_list[c_top + c_cur])->clist)
				continue;
				
			move(c_cur + 4, 2);		
			CurBList = cb_list[c_top + c_cur];
			if (ZapRC_ValidBid(CurBList->bid))
			{
				if (ZapRC_IsZapped(CurBList->bid))
				{
					prints(" ");				
					ZapRC_DoUnZap(CurBList->bid);
				}
				else
				{
					ZapRC_DoZap(CurBList->bid);
					prints("*");					
				}
				ZapRC_Update(curuser.userid);
			}
			break;
		case TAB:
			in_board ^= 1;
			board_title();
			break;
		case CTRL('R'):
			ReplyLastCall();
			mode = B_FULL;
			break;
		case '/':
			if (!getdata(b_line, 0, _msg_board_7, nbuf, sizeof(nbuf), ECHONOSP, NULL))
			{
				mode = B_LINE;
				break;
			}

			nbuf_len = strlen(nbuf) - 1;
			ch = nbuf[nbuf_len];
			
		default:
			if (nbuf_len == 0 && ch >= '1' && ch <= '9')
			{
				nbuf[0] = ch;
				nbuf[1] = '\0';
				mode = B_LINE;
				if (getdata(b_line, 0, "���ܲĴX��: ", nbuf, 4, ECHONOSP, nbuf))
				{			
					i = atoi(nbuf);
					if (i >= 1 && i <= brdcnt)
					{
						c_cur = ((i-1) % BRDMENU_ROW);
						c_top = ((i-1) / BRDMENU_ROW) * BRDMENU_ROW;
						mode = B_PART;
					}
				}
			}
			else
			{
				nbuf[nbuf_len] = ch;
				nbuf[nbuf_len + 1] = '\0';

				if (!invalid_bname(nbuf + nbuf_len))
				{
					int cnt = c_top + c_cur;
					
					nbuf_len++;

					for (i = 0; i < brdcnt; i++)
					{
						cb = cb_list[cnt];
						if (!cb->clist && !strncasecmp(cb->name, nbuf, nbuf_len))
						{
							RMVCURS;
							c_cur = (cnt % BRDMENU_ROW);
							if (cnt >= c_top && cnt <= c_top + c_bot)
							{
								mode = B_NO;
							}
							else
							{
								c_top = (cnt / BRDMENU_ROW) * BRDMENU_ROW;
								mode = B_PART;
							}
							break;
						}
						if (++cnt == brdcnt)
							cnt = 0;
					}
					if (i == brdcnt)
						nbuf[--nbuf_len] = '\0';
					continue;
				}
			}
			break;
		}	/* case */
		nbuf_len = 0;
	}		/* while */
	return M_FULL;
}
