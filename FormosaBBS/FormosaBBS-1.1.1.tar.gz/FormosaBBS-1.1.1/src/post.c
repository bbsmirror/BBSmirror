/* 
   Re-written and comment by 
   Li-te Huang, lthuang@cc.nsysu.edu.tw, 12/05/97
*/

#include "bbs.h"
#include "tsbbs.h"


/* function prototype for read_comms[]
 */
int do_post();
extern int delete_article();
extern int range_delete_article();
extern int mail_article();
extern int edit_article();
extern int title_article();
int read_help();
int bm_manage_file();
extern int cross_article();
extern int reserve_article();
int treasure_article();
int mkdir_treasure();
int xchg_treasure();
int select_board();
int switch_boardtrea();
int display_bmwel();
int visit_article();

#ifdef USE_VOTE
extern int v_boardhold();
extern int v_board();
#endif

struct one_key read_comms[] =
{
	CTRL('P'), do_post,
	'd', delete_article,
	'T', range_delete_article,
	'm', mail_article,
	'E', edit_article,
	'i', title_article,
	'h', read_help,
	'w', bm_manage_file,
	'x', cross_article,
	'g', reserve_article,
	't', treasure_article,
	CTRL('G'), mkdir_treasure,
	'c', xchg_treasure,
	's', select_board,
	'b', display_bmwel,
	TAB, switch_boardtrea,
	'k', visit_article,
#ifdef USE_VOTE
	'v', v_board,
	'l', v_boardhold,
#endif
	0, NULL
};


int
visit_article(ent, finfo, direct)
int ent;				/* unused */
FILEHEADER *finfo;		/* unused */
char *direct;			/* unused */
{
	if (!in_board)
		return R_NO;

	getdata(b_line, 0, _msg_post_9, genbuf, 2, ECHONOSP|LOWCASE, NULL);
	if (genbuf[0] == 'y')
		ReadRC_Visit(CurBList->name, CurBList->bid, curuser.userid, 0xFF);	
	else if (genbuf[0] == 'n')
		ReadRC_Visit(CurBList->name, CurBList->bid, curuser.userid, 0x00);		
	else
		return R_LINE;
	return R_NEW;
}	


extern int t_top[TREASURE_DEPTH], t_cur[TREASURE_DEPTH];	
extern int nowdepth;

void
change_board(direct)		/* by lthuang */
char **direct;
{
	artwtop = free_wlist(artwtop, free);
	if (in_board)
		setboardfile(*direct, CurBList->name, DIR_REC);
	else
	{
		settreafile(*direct, CurBList->name, DIR_REC);
		nowdepth = 1;
		memset(t_top, 0, sizeof(t_top));
		memset(t_cur, 0, sizeof(t_cur));
	}
}


int
switch_boardtrea(ent, finfo, direct)
int ent;				/* unused */
FILEHEADER *finfo;		/* unused */
char *direct;
{
	in_board ^= 1;	/* board/treausre tag switch */
	change_board(&direct);
	return R_NEW;
}


int 
display_bmwel(ent, finfo, direct)
int ent;				/* unused */
FILEHEADER *finfo;		/* unused */
char *direct;			/* unused */
{
	setboardfile(genbuf, CurBList->name, BM_WELCOME);
	more(genbuf, TRUE);
	clear();
	if (display_bmas() > 0)
		pressreturn();
	clear();
	return R_FULL;
}


int
select_board(ent, finfo, direct)
int ent;				/* unused */
FILEHEADER *finfo;		/* unused */
char *direct;
{
	if (choose_board() == 0)
	{
		change_board(&direct);
		return R_NEW;
	}
	return R_FULL;
}


int
display_bmas()
{
	FILE *fp;
	int cnt = 0;
	char *p;

	move(3, 0);
	setboardfile(genbuf, CurBList->name, BM_ASSISTANT);
	if ((fp = fopen(genbuf, "r")) != NULL)
	{
		while (fgets(genbuf, sizeof(genbuf), fp))
		{
			if ((p = strchr(genbuf, '\n')))
				*p = '\0';
			if (cnt == 0)
				outs(_msg_post_8);
			outs(genbuf);
			outs("\n");
			cnt++;
		}
		fclose(fp);
	}
	if (cnt == 0)
		outs(_msg_none);
	return cnt;
}


void
add_bmas(Uident)
char *Uident;
{
	FILE *fp;

	setboardfile(genbuf, CurBList->name, BM_ASSISTANT);
	if (!seek_in_file(genbuf, Uident))
	{
		if ((fp = fopen(genbuf, "a")) != NULL)
		{
			fprintf(fp, "%s\n", Uident);
			fclose(fp);
		}
	}
}


void
delete_bmas(Uident)
char *Uident;
{
	FILE *fp, *fpnew;
	char fn[PATHLEN], fnnew[PATHLEN];
	BOOL deleted = FALSE;
	char *p;

	setboardfile(fn, CurBList->name, BM_ASSISTANT);
	sprintf(fnnew, "tmp/-%s.bm_assistant.new", curuser.userid);	/* lthuang ? */
	if ((fp = fopen(fn, "r")) == NULL)
		return;
	if ((fpnew = fopen(fnnew, "w")) == NULL)
	{
		fclose(fp);
		return;
	}
	while (fgets(genbuf, sizeof(genbuf), fp))
	{
		if ((p = strchr(genbuf, '\n')) != NULL)
			*p = '\0';
		if (!strcmp(genbuf, Uident))
			deleted = TRUE;
		else
			fprintf(fpnew, "%s\n", genbuf);
	}
	fclose(fpnew);
	fclose(fp);
	if (deleted)
	{
		if (myrename(fnnew, fn) == 0)
			return;
	}
	unlink(fnnew);
}


/*  Provided for bm to manage affairs of the board, 
 *  including
 *
 *  - edit/delete the board welcome
 *  - edit the bmas list
 *  
 *  We allow sysop and board owner has the full permission, 
 *  but bmas cannot edit the bmas lists
 *  
 *  Note: 1. For security, check whether current user is guest
 *           (when GUEST_ACCOUNT defined)
 *        2. Through this program source, we define
 *           (sysop =)bm +--- board owner
 *                       |
 *                       +--- bmas
 */
int
bm_manage_file()
{
	BOOL full_perm = FALSE;
	char fname[PATHLEN];

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return R_NO;
#endif

	/* not sysop and do not has the permission of bm, 
	 * including board owner and bmas
	 */
	if (HAS_PERM(PERM_SYSOP) || isBM)
		full_perm = TRUE;
	else if (hasBMPerm)
		full_perm = FALSE;
	else
		return R_NO;

	clear();

	if (full_perm)
		getdata(1, 0, _msg_bm_manage_cmd_full, genbuf, 2, ECHONOSP | LOWCASE, NULL);
	else
		getdata(1, 0, _msg_bm_manage_cmd_part, genbuf, 2, ECHONOSP | LOWCASE, NULL);

	if (genbuf[0] == 'd')
	{
		getdata(2, 0, _msg_not_sure, genbuf, 2, ECHONOSP | LOWCASE, NULL);
		if (genbuf[0] == 'y')
		{
			setboardfile(fname, CurBList->name, BM_WELCOME);
			unlink(fname);
			outs(_msg_finished);
		}
		else
		{
			outs(_msg_aborted);
		}
	}
	else if (genbuf[0] == 'm' && full_perm)
	{
		int num_bmas;
		char bmas[IDLEN];

		while (1)
		{
			clear();
			outs(_msg_bm_manage_edit_bmas);

			num_bmas = display_bmas();
			if (num_bmas)
				getdata(1, 0, _msg_choose_add_delete, genbuf, 2, ECHONOSP | LOWCASE, NULL);
			else
				getdata(1, 0, _msg_choose_add, genbuf, 2, ECHONOSP | LOWCASE, NULL);
			if (genbuf[0] == 'a')
			{
				if (getdata(2, 0, _msg_ent_userid, bmas, sizeof(bmas), ECHONOSP, NULL))
				{
					if (get_passwd(NULL, bmas) > 0)
						add_bmas(bmas);
				}
			}
			else if (genbuf[0] == 'd' && num_bmas)
			{
				if (getdata(2, 0, _msg_ent_userid, bmas, sizeof(bmas), ECHONOSP, NULL))
					delete_bmas(bmas);
			}
			else
				break;
		}
	}
	else
	{
		setboardfile(fname, CurBList->name, BM_WELCOME);
		if (vedit(fname, NULL))
			outs(_msg_aborted);
		else
			outs(_msg_finished);
	}
	pressreturn();
	return R_FULL;
}


/* Online help of the post menu (normal/treasure)
 */
int
read_help()
{
	more(READ_HELP, TRUE);
	return R_FULL;
}


/*
 * Whether one has the post permission or not,
 * and show the reason on the screen
 *
 * Limit:
 *        level, ident (BRDTYPE_IDENT)
 * 
 * Who can post on treaure:
 *     (1) sysop
 *     (2) that has bm permission, including owner and bmas 
 *     (2) if owner of the board is absent, any one whose level is PERM_BM
 *   
 * Note: guest can only post on the board _STR_BOARD_GUEST
 *       [refer strhct.h for detail]
 *       (when GUEST_ACCOUNT define)
 */
int
has_postperm(blistent)
struct BoardList *blistent;
{
#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
	{
		if (!match_in_multistr(blistent->name, _STR_BOARD_GUEST))
		{
			outs(_msg_postperm_reason_guest);
			pressreturn();
			return -1;
		}
	}
#endif

	if (!HAS_PERM(PERM_SYSOP))
	{
		if (curuser.userlevel < blistent->level)
		{
			prints(_msg_postperm_reason_level,
			       curuser.userlevel, blistent->name, blistent->level);
			pressreturn();
			return -1;
		}
		if ((blistent->brdtype & BRDTYPE_IDENT) && curuser.ident != 7)
		{
			outs(_msg_postperm_reason_ident);
			pressreturn();
			return -1;
		}
	}

	if (!in_board)
	{
		if (!HAS_PERM(PERM_SYSOP))
		{
			if ((blistent->owner[0] != '\0' || !HAS_PERM(PERM_BM)) &&
			    !hasBMPerm)
			{
				outs(_msg_postperm_reason_treasure);
				pressreturn();
				return -1;
			}
		}
	}
	return 0;
}


/* 
   Note:
   . only the post on board (normal, but not treausre) be send to news
   and

   (1) Do not send the post to news, if the user is not identified.
   (when EMAIL_LIMIT defined)
   (2) By default, all the post send to news. 
   Users can have theris own choice.

   . only the post on board (normal) will be added to postnum,
   but BRDTYPE_NOPOSTNUM excluded

 */
int
PrepareMailPost(fn_src, to, title, postpath, mail_ok, post_ok)
char *fn_src, *to, *title, *postpath;
int mail_ok, post_ok;
{
	int save_umode = uinfo.mode, save_mmode = in_mail;
	char tempfile[PATHLEN];
	int save_mail_ok = mail_ok;
	int save_post_ok = post_ok;


	if (post_ok)
	{
		if (in_board)
			prints(_msg_post_on_normal, CurBList->name);
		else
			prints(_msg_post_on_treasure, CurBList->name);
		if (has_postperm(CurBList) == -1)
			post_ok &= ~post_ok;
	}

	if (mail_ok)
	{
		if (do_article_to(to) == -1)
			mail_ok &= ~mail_ok;
	}

	if (!mail_ok & !post_ok)
	{
		return -1;
	}

	if (do_article_title(title))
	{
		return -1;
	}

	sprintf(tempfile, "tmp/mailpost%05d", getpid());
	if (fn_src)
	{
		outs(_msg_include_ori);
		if (igetkey() != 'n')
			include_ori(fn_src, tempfile);
	}

	if (mail_ok && !post_ok)
	{
		in_mail = TRUE;	/* lthuang: debug */
		update_umode(SMAIL);
	}
	else
	{
		in_mail = FALSE;	/* lthuang: debug */
		update_umode(POSTING);
	}
	
	if (vedit(tempfile, title))
	{
		update_umode(save_umode);
		in_mail = save_mmode;
		return -1;
	}

	if (post_ok)
	{
		int artno, tonews = FALSE;

		if (in_board && (CurBList->brdtype & BRDTYPE_NEWS))
		{
#if EMAIL_LIMIT
			/* do not send the post to news, if user is not identified */
			if (curuser.ident != 7)
				outs(_msg_no_ident_send_tonews);
			else
#endif
			{
				/* by default, send post to news */
				outs(_msg_send_tonews_yesno);
				if (igetkey() != 'n')
					tonews = TRUE;
			}
		}

		/* 
		   do not add postnum, when post on treasure, 
		   or the brdtype of the board is BRDTYPE_NOPOSTNUM
		 */
		if (!postpath && !(CurBList->brdtype & BRDTYPE_NOPOSTNUM))
			curuser.numposts++;

		/* wirte the post file on the board directory immediately */
		artno = PublishPost(tempfile, curuser.userid, CurBList->name, title,
			                curuser.ident, uinfo.from, tonews, postpath);

		if (artno == -1)
		{
			post_ok &= ~post_ok;
		}
		else
		{
			if (in_board)
				/* the author of post should have read the post obviously */
				ReadRC_Addlist(artno);
		}
	}

	if (mail_ok)
	{
		if (is_emailaddr(to))
		{
#if EMAIL_LIMIT
			if (curuser.ident != 7)
			{
				outs("\n");
				outs(_msg_sorry_email);
				clrtoeol();
				getkey();
				mail_ok &= ~mail_ok;
			}
#endif
		}
		else if (get_passwd(NULL, to) <= 0)
		{
			outs(_msg_err_userid);
			mail_ok &= ~mail_ok;
		}

		if (mail_ok)
		{
			int result;


			if (is_emailaddr(to))
			{
				char fnameNew[PATHLEN];


				msg(_msg_ask_uuencode);
				if (igetkey() == 'y')
					uuencode_file(tempfile, fnameNew);
				else
					strcpy(fnameNew, tempfile);
				result = SendMail_Internet(-1, fnameNew, curuser.userid, to, title);
			}
			else
				result = SendMail_Local(tempfile, curuser.userid, to, title, curuser.ident);
			if (result == -1)
				mail_ok &= ~mail_ok;
		}
	}

	update_umode(save_umode);
	in_mail = save_mmode;
	unlink(tempfile);
	if (mail_ok != save_mail_ok && post_ok != save_post_ok)
		return -1;
	else if (mail_ok != save_mail_ok)
		return -2;
	else if (post_ok != save_post_ok)
		return -3;
	return 0;
}


/*
   Do post on board (normal/treasure)
 */
int
do_post(ent, finfo, direct)
int ent;			/* unused */
FILEHEADER *finfo;		/* unused */
char *direct;
{
	char postpath[PATHLEN], title[STRLEN];
	int result;


	title[0] = '\0';

	clear();

	if (!in_board)
	{
		setdotfile(postpath, direct, NULL);
		/* fn_src: NULL, to: NULL, mail_ok: FALSE, post_ok: TRUE */
		result = PrepareMailPost(NULL, NULL, title, postpath, FALSE, TRUE);
	}
	else
	{
		/* fn_src: NULL, to: NULL, postpath: NULL, mail_ok: FALSE, post_ok: TRUE */
		result = PrepareMailPost(NULL, NULL, title, NULL, FALSE, TRUE);
	}

	move(b_line - 1, 0);
	clrtoeol();
	if (result != 0)
		outs(_msg_post_fail);
	else
		outs(_msg_post_finish);
	pressreturn();

	return R_NEW;
}


/*
   Post (this function exected standalone without read menu)
 */
Post()
{
	clear();

	if (MakeBoardList() == -1)
	{
		outs(_msg_no_board_exist);
		pressreturn();
		return M_FULL;
	}
	if (!in_board)
	{
		outs(_msg_cannot_post_in_treasure);
		pressreturn();
		return M_FULL;
	}

	do_post(0, NULL, NULL);

	return M_FULL;
}


/*
   By this function, user enter powerful read menu,
   when reading the list of post, treasure 
 */
Read()
{
	char tmp_direct[PATHLEN];


	if (MakeBoardList() == -1)
	{
		outs(_msg_no_board_exist);
		pressreturn();
		return M_FULL;
	}

	update_umode(READING);

#ifdef USE_VOTE
	if (CurBList->vote_flag)
		DisplayNewVoteMesg();
#endif

	if (in_board)
		setboardfile(tmp_direct, CurBList->name, DIR_REC);
	else
		settreafile(tmp_direct, CurBList->name, DIR_REC);

	/* read the post/treasure in board (normal/treasure) */
	i_read(tmp_direct, read_comms, IREAD_BOARD);

	/* if have read post, update the record of readrc */
	ReadRC_Update();

	return M_FULL;
}



/*
   process the treasure:

   . copy/move the post to treausre
   . copy/move the treausre between different level of directory

 */
int
treasure_article(ent, finfo, direct)
int ent;			/* unused */
FILEHEADER *finfo;
char *direct;
{
	int ch, fd;
	char fname[255], tpath[255];
	FILEHEADER fhbuf, *fhr = &fhbuf;	/* lthuang ? */
	extern int nowdepth;
	BOOL combin = FALSE;
	char fn_comb[PATHLEN];
	struct word *artwtmp;


	if (finfo->accessed & FILE_DELE)
		return R_NO;
	if (!HAS_PERM(PERM_SYSOP))
	{
		if ((CurBList->owner[0] != '\0' || !HAS_PERM(PERM_BM)) && !hasBMPerm)
			return R_NO;
	}

	if (in_board)
	{
		settreafile(tpath, CurBList->name, NULL);
		msg(_msg_treasure_cnvt);
	}
	else
	{
		setdotfile(tpath, direct, finfo->filename);
		msg(_msg_treasure_cnvt_dir);
	}

	switch ((ch = igetkey()))
	{
	case 'm':
		if (!(finfo->accessed & FILE_TREA))
			artwtop = add_wlist(artwtop, finfo->filename, malloc_str);
		break;
	case 'u':
		if (artwtop)
			cmpd_wlist(&artwtop, finfo->filename, strncmp, free);
		break;
	case 'n':
		if (in_board)
		{
			setdotfile(fname, direct, finfo->filename);
			/* stamp: NULL, artmode: FALSE */
			if (append_article(fname, tpath, finfo->owner, finfo->title, finfo->ident, NULL, FALSE) == -1)
				msg(_msg_fail);
			else
				msg(_msg_finish);
			getkey();
		}
		break;
	case '.':
		if (nowdepth < 2)
			return R_LINE;
		*(strrchr(tpath, '/')) = '\0';	/* current directory */
		*(strrchr(tpath, '/')) = '\0';	/* parent directory */
	case 't':
		if (!artwtop)
		{
			msg(_msg_no_tag_found);
			getkey();
			return R_LINE;
		}
		else if (!in_board && !(finfo->accessed & FILE_TREA) && ch == 't')
		{
			msg(_msg_post_1);
			getkey();
			return R_LINE;
		}
		if ((fd = open(direct, O_RDWR)) < 0)
			return R_LINE;
		if (!in_board)
			msg(_msg_post_2);
		else
			msg(_msg_post_3);
		ch = (igetkey() == 'm') ? 'T' : 't';
		msg(_msg_post_4);
		if (igetkey() != 'y')
			combin = FALSE;
		else
			combin = TRUE;
		if (ch == 'T')
			flock(fd, LOCK_EX);
		if (combin)
		{
			int fdr, fdw;
			long size;

			sprintf(fn_comb, "tmp/%s.comb", curuser.userid);
			if ((fdw = open(fn_comb, O_WRONLY | O_CREAT | O_APPEND, 0644)) > 0)
			{
				artwtmp = artwtop;
				for (artwtmp = artwtop; artwtmp; artwtmp = artwtmp->next)
				{
					setdotfile(genbuf, direct, artwtmp->word);
					if ((fdr = open(genbuf, O_RDONLY)) > 0)
					{
						while ((size = read(fdr, genbuf, sizeof(genbuf))) > 0)
						{
							if (write(fdw, genbuf, size) != size)
								break;
						}
						close(fdr);
					}
					write(fdw, "\n", 1);
				}
				close(fdw);
			}
			if (append_article(fn_comb, tpath, curuser.userid, _str_combined_treasure_title, curuser.ident, NULL, FALSE) == -1)
			{
				if (ch == 'T')
					flock(fd, LOCK_UN);
				close(fd);
				msg(_msg_fail);
				getkey();
				unlink(fn_comb);
				return R_LINE;
			}
			if (ch == 'T')
			{
				while (read(fd, fhr, FH_SIZE) == FH_SIZE)
				{
					if (!cmp_wlist(artwtop, fhr->filename, strcmp))
						continue;
					fhr->accessed |= FILE_DELE;
					xstrncpy(fhr->title + sizeof(fhr->title) - IDLEN,
						curuser.userid, IDLEN);
					if (lseek(fd, -((off_t) FH_SIZE), SEEK_CUR) == -1)
						break;
					if (write(fd, fhr, FH_SIZE) != FH_SIZE)
						break;
				}
			}
			unlink(fn_comb);
		}
		else
		{
			while (read(fd, fhr, FH_SIZE) == FH_SIZE)
			{
				if (!cmp_wlist(artwtop, fhr->filename, strcmp))
					continue;
				setdotfile(fname, direct, fhr->filename);
				if (append_article(fname, tpath, fhr->owner, fhr->title, fhr->ident, NULL, FALSE) == -1)
				{
					if (ch == 'T')
						flock(fd, LOCK_UN);
					close(fd);
					msg(_msg_fail);
					getkey();
					return R_LINE;
				}
				if (ch == 'T')
				{
					fhr->accessed |= FILE_DELE;
					xstrncpy(fhr->title + sizeof(fhr->title) - IDLEN,
						curuser.userid, IDLEN);
					lseek(fd, -((off_t) FH_SIZE), SEEK_CUR);
					write(fd, fhr, FH_SIZE);
				}
			}
		}
		if (ch == 'T')
			flock(fd, LOCK_UN);
		close(fd);
		msg(_msg_finish);
		getkey();
		if (ch == 'T')
		{
			if (!in_board)
				pack_article(direct);	/* treasure need deleted immediately */
			return R_NEW;
		}
		break;
	default:
		break;
	}
	return R_LINE;
}


int
mkdir_treasure(ent, finfo, direct)	/* make directory in treasure */
int ent;			/* unused */
FILEHEADER *finfo;		/* unused */
char *direct;
{
	char title[STRLEN], path[PATHLEN], new[PATHLEN];
	char *stamp;
	int fd, fdnew, insert_ok;
	FILEHEADER *fhr = &fhGol, th;
	int result;

	extern int nowdepth;

	if (in_board || (!HAS_PERM(PERM_SYSOP) && !hasBMPerm))
		return R_NO;

	sprintf(new, "%s.new", direct);

	if (nowdepth >= TREASURE_DEPTH)
	{
		msg(_msg_post_5, TREASURE_DEPTH);
		getkey();
		return R_LINE;
	}
	if (!getdata(b_line, 0, _msg_post_6, title, STRLEN, DOECHO, NULL))
		return R_LINE;

	msg(_msg_post_7, title);
	if (igetkey() != 'y')
		return R_LINE;

	setdotfile(path, direct, NULL);		/* ���o direct ���Ҧb�ؿ� */
	stamp = path + strlen(path);
	do
	{
		sprintf(stamp, "M.%d.A", time(0));	/* -ToDo- T.XXXXXXX.A */
	}
	while (mkdir(path, 0700) == -1);

	memset(&th, 0, sizeof(th));
	strcpy(th.title, title);
	strcpy(th.filename, stamp);
	th.accessed |= FILE_TREA;

	if ((fd = open(direct, O_RDWR)) < 0)
	{
		rmdir(path);
		msg(_msg_fail);
		getkey();
		return R_LINE;
	}
	if ((fdnew = open(new, O_WRONLY | O_CREAT | O_TRUNC, 0644)) < 0)
	{
		close(fd);
		rmdir(path);
		msg(_msg_fail);
		getkey();
		return R_LINE;
	}

	result = 0;
	insert_ok = FALSE;
	flock(fd, LOCK_EX);
	while (read(fd, fhr, FH_SIZE) == FH_SIZE)
	{
		if (!insert_ok && !(fhr->accessed & FILE_TREA))
		{
			if (write(fdnew, &th, sizeof(th)) != sizeof(th))
			{
				result = -1;
				break;
			}
			insert_ok = TRUE;
		}
		if (write(fdnew, fhr, FH_SIZE) != FH_SIZE)
		{
			result = -1;
			break;
		}
	}
	if (result == 0 && !insert_ok)
	{
		if (write(fdnew, &th, sizeof(th)) != sizeof(th))
			result = -1;
	}
	close(fdnew);
	flock(fd, LOCK_UN);
	close(fd);
	if (result == 0)
	{
		if (rename(new, direct) == 0)
		{
			msg(_msg_finish);
			getkey();
			return R_NEW;
		}
	}
/*      
   unlink(new);
 */
	rmdir(path);
	msg(_msg_fail);
	getkey();
	return R_LINE;
}
