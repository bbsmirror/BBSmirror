
#ifndef _BBS_VAR_H_
#define _BBS_VAR_H_


#include "bbs.h"


extern USEREC curuser;
extern USER_INFO uinfo;
extern FILEHEADER fhGol;

extern struct word *artwtop ;
extern struct BoardList *CurBList;

#if 0
extern jmp_buf byebye;				/* Used for exception condition like I/O error */
#endif

extern char genbuf[1024];			/* generally used global buffer */

extern BOOL in_board ;
extern BOOL in_mail ;
extern BOOL dumb_term ;
extern BOOL talkrequest ;
extern BOOL writerequest ;
extern BOOL show_ansi ;
extern int multi ;
extern int maxkeepmail;

extern char ufile_overrides[PATHLEN];
extern char ufile_write[PATHLEN];
extern char ufile_mail[PATHLEN];

extern struct array *friend_cache ;

extern char _str_cursor[] ;
extern char _str_uncurs[] ;

extern BOOL isBM, hasBMPerm;

extern USER_INFO *cutmp;


#endif /* _BBS_VAR_H_ */
