
#ifndef _BBS_MSGINFO_H_
#define _BBS_MSGINFO_H_


/*
   BBS Message Text define for multi-language version
*/


/* msginfo/admin */
extern char _msg_a_info_show_bm_yesno[] ;
extern char _msg_admin_1[] ;
extern char _msg_admin_10[] ;
extern char _msg_admin_11[] ;
extern char _msg_admin_12[] ;
extern char _msg_admin_13[] ;
extern char _msg_admin_14[] ;
extern char _msg_admin_15[] ;
extern char _msg_admin_16[] ;
extern char _msg_admin_17[] ;
extern char _msg_admin_18[] ;
extern char _msg_admin_2[] ;
extern char _msg_admin_3[] ;
extern char _msg_admin_5[] ;
extern char _msg_admin_8[] ;
extern char _msg_admin_9[] ;
extern char _msg_admin_bdesc[] ;
extern char _msg_admin_blevel[] ;
extern char _msg_admin_class[] ;
extern char _msg_admin_owner[] ;
extern char _str_brdtype_announce[] ;
extern char _str_brdtype_ident[] ;
extern char _str_brdtype_invisible[] ;
extern char _str_brdtype_news[] ;
extern char _str_brdtype_nopostnum[] ;
extern char _str_brdtype_unzap[] ;


/* msginfo/article */
extern char _msg_article_1[] ;
extern char _msg_article_10[] ;
extern char _msg_article_11[] ;
extern char _msg_article_12[] ;
extern char _msg_article_13[] ;
extern char _msg_article_14[] ;
extern char _msg_article_15[] ;
extern char _msg_article_16[] ;
extern char _msg_article_17[] ;
extern char _msg_article_18[] ;
extern char _msg_article_19[] ;
extern char _msg_article_2[] ;
extern char _msg_article_3[] ;
extern char _msg_article_4[] ;
extern char _msg_article_5[] ;
extern char _msg_article_6[] ;
extern char _msg_article_7[] ;
extern char _msg_article_8[] ;
extern char _msg_article_9[] ;
extern char _msg_cross_which_board[] ;
extern char _msg_ent_new_title[] ;
extern char _msg_reserve_article[] ;
extern char _str_crosspost[] ;
extern char _str_header_title[] ;


/* msginfo/bbschatd */
extern char _msg_bbschatd_10[] ;
extern char _msg_bbschatd_11[] ;
extern char _msg_bbschatd_12[] ;
extern char _msg_bbschatd_13[] ;
extern char _msg_bbschatd_14[] ;
extern char _msg_bbschatd_15[] ;
extern char _msg_bbschatd_1[] ;
extern char _msg_bbschatd_2[] ;
extern char _msg_bbschatd_3[] ;
extern char _msg_bbschatd_4[] ;
extern char _msg_bbschatd_5[] ;
extern char _msg_bbschatd_6[] ;
extern char _msg_bbschatd_7[] ;
extern char _msg_bbschatd_8[] ;
extern char _msg_bbschatd_9[] ;


/* msginfo/board */
extern char _msg_board_1[] ;

extern char _msg_board_2[] ;

extern char _msg_board_3[] ;
extern char _msg_board_4[] ;
extern char _msg_board_5[] ;
extern char _msg_board_6[] ;
extern char _msg_board_7[] ;


/* msginfo/chat */
extern char _msg_chat_1[] ;
extern char _msg_chat_10[] ;
extern char _msg_chat_11[] ;
extern char _msg_chat_12[] ;
extern char _msg_chat_13[] ;
extern char _msg_chat_14[] ;
extern char _msg_chat_15[] ;
extern char _msg_chat_16[] ;
extern char _msg_chat_17[] ;
extern char _msg_chat_18[] ;
extern char _msg_chat_19[] ;
extern char _msg_chat_2[] ;
extern char _msg_chat_20[] ;
extern char _msg_chat_21[] ;
extern char _msg_chat_22[] ;
extern char _msg_chat_23[] ;
extern char _msg_chat_24[] ;
extern char _msg_chat_25[] ;
extern char _msg_chat_26[] ;
extern char _msg_chat_27[] ;
extern char _msg_chat_28[] ;
extern char _msg_chat_29[] ;
extern char _msg_chat_3[] ;
extern char _msg_chat_30[] ;
extern char _msg_chat_31[] ;
extern char _msg_chat_32[] ;
extern char _msg_chat_33[] ;
extern char _msg_chat_34[] ;
extern char _msg_chat_35[] ;
extern char _msg_chat_36[] ;
extern char _msg_chat_37[] ;
extern char _msg_chat_38[] ;
extern char _msg_chat_39[] ;
extern char _msg_chat_4[] ;
extern char _msg_chat_40[] ;
extern char _msg_chat_41[] ;

extern char _msg_chat_42[] ;
extern char _msg_chat_43[] ;

extern char _msg_chat_44[] ;
extern char _msg_chat_45[] ;
extern char _msg_chat_46[] ;
extern char _msg_chat_5[] ;
extern char _msg_chat_6[] ;
extern char _msg_chat_7[] ;
extern char _msg_chat_8[] ;
extern char _msg_chat_9[] ;


/* msginfo/edit */
extern char _msg_edit_1[] ;
extern char _msg_edit_2[] ;
extern char _msg_edit_3[] ;
extern char _msg_edit_4[] ;
extern char _msg_edit_5[] ;
extern char _msg_edit_6[] ;
extern char _msg_edit_7[] ;
extern char _msg_edit_8[] ;
extern char _msg_edit_9[] ;
extern char _msg_include_which_sig[] ;
extern char _msg_no_include_sig[] ;
extern char _msg_no_use_sig[] ;
extern char _msg_signature[] ;


/* msginfo/faxans */
extern char _msg_faxans_1[] ;
extern char _msg_faxans_10[] ;

extern char _msg_faxans_11[] ;
extern char _msg_faxans_12[] ;
extern char _msg_faxans_13[] ;

extern char _msg_faxans_14[] ;
extern char _msg_faxans_15[] ;
extern char _msg_faxans_16[] ;

extern char _msg_faxans_17[] ;
extern char _msg_faxans_18[] ;
extern char _msg_faxans_2[] ;
extern char _msg_faxans_3[] ;
extern char _msg_faxans_5[] ;
extern char _msg_faxans_6[] ;
extern char _msg_faxans_7[] ;

extern char _msg_faxans_8[] ;
extern char _msg_faxans_9[] ;


/* msginfo/formosa */
extern char _msg_formosa_1[] ;
extern char _msg_formosa_10[] ;
extern char _msg_formosa_11[] ;
extern char _msg_formosa_12[] ;
extern char _msg_formosa_13[] ;
extern char _msg_formosa_14[] ;
extern char _msg_formosa_15[] ;
extern char _msg_formosa_16[] ;
extern char _msg_formosa_17[] ;
extern char _msg_formosa_18[] ;
extern char _msg_formosa_19[] ;
extern char _msg_formosa_2[] ;
extern char _msg_formosa_20[] ;
extern char _msg_formosa_21[] ;
extern char _msg_formosa_22[] ;
extern char _msg_formosa_23[] ;
extern char _msg_formosa_24[] ;
extern char _msg_formosa_25[] ;
extern char _msg_formosa_26[] ;
extern char _msg_formosa_27[] ;
extern char _msg_formosa_28[] ;
extern char _msg_formosa_29[] ;
extern char _msg_formosa_3[] ;
extern char _msg_formosa_30[] ;
extern char _msg_formosa_31[] ;
extern char _msg_formosa_32[] ;
extern char _msg_formosa_33[] ;
extern char _msg_formosa_34[] ;
extern char _msg_formosa_35[] ;
extern char _msg_formosa_36[] ;
extern char _msg_formosa_37[] ;
extern char _msg_formosa_38[] ;
extern char _msg_formosa_39[] ;
extern char _msg_formosa_4[] ;
extern char _msg_formosa_40[] ;
extern char _msg_formosa_41[] ;
extern char _msg_formosa_42[] ;
extern char _msg_formosa_43[] ;
extern char _msg_formosa_44[] ;
extern char _msg_formosa_5[] ;
extern char _msg_formosa_6[] ;
extern char _msg_formosa_7[] ;
extern char _msg_formosa_8[] ;
extern char _msg_formosa_9[] ;


/* msginfo/ident */
extern char _msg_ident_1[] ;
extern char _msg_ident_10[] ;

extern char _msg_ident_11[] ;
extern char _msg_ident_12[] ;
extern char _msg_ident_13[] ;
extern char _msg_ident_14[] ;
extern char _msg_ident_15[] ;
extern char _msg_ident_16[] ;
extern char _msg_ident_17[] ;
extern char _msg_ident_18[] ;
extern char _msg_ident_19[] ;
extern char _msg_ident_2[] ;
extern char _msg_ident_20[] ;
extern char _msg_ident_21[] ;
extern char _msg_ident_3[] ;
extern char _msg_ident_4[] ;
extern char _msg_ident_5[] ;
extern char _msg_ident_6[] ;
extern char _msg_ident_7[] ;
extern char _msg_ident_8[] ;
extern char _msg_ident_9[] ;
extern char _msg_ident_item1[] ;
extern char _msg_ident_item2[] ;
extern char _msg_ident_item3[] ;
extern char _msg_ident_item4[] ;
extern char _msg_ident_item5[] ;
extern char _msg_ident_item6[] ;
extern char _msg_ident_item7[] ;
extern char _msg_ident_item8[] ;
extern char _msg_ident_item9[] ;


/* msginfo/list */
extern char _msg_list_1[] ;
extern char _msg_list_10[] ;
extern char _msg_list_11[] ;
extern char _msg_list_12[] ;
extern char _msg_list_13[] ;
extern char _msg_list_14[] ;

extern char _msg_list_16[] ;
extern char _msg_list_17[] ;
extern char _msg_list_18[] ;
extern char _msg_list_19[] ;
extern char _msg_list_2[] ;
extern char _msg_list_20[] ;
extern char _msg_list_21[] ;
extern char _msg_list_4[] ;
extern char _msg_list_5[] ;
extern char _msg_list_6[] ;

extern char _msg_list_7[] ;

extern char _msg_list_8[] ;

extern char _msg_list_9[] ;
extern char _msg_pickup_way_1[] ;
extern char _msg_pickup_way_2[] ;
extern char _msg_pickup_way_3[] ;
extern char _msg_pickup_way_4[] ;
extern char _msg_pickup_way_5[] ;


/* msginfo/mail */
extern char _msg_ask_group_add[] ;
extern char _msg_ask_group_del[] ;
extern char _msg_checkfwdemailaddr[] ;

extern char _msg_checkfwdemailaddr_fail[] ;

extern char _msg_checkfwdemailaddr_nsysu[] ;

extern char _msg_delete[] ;
extern char _msg_m_forward_desc_1[] ;

extern char _msg_m_forward_desc_2[] ;
extern char _msg_m_forward_finish[] ;
extern char _msg_m_new_command_prompt[] ;

extern char _msg_m_new_full[] ;
extern char _msg_m_new_nomore[] ;
extern char _msg_m_new_read_prompt[] ;

extern char _msg_mail_1[] ;
extern char _msg_mail_2[] ;
extern char _msg_mail_group_max_prompt[] ;
extern char _msg_mail_to_all_friend[] ;
extern char _msg_max_group[] ;
extern char _msg_max_mail_warning[] ;

extern char _msg_receiver[] ;


/* msginfo/main */
extern char _msg_main_1[] ;
extern char _msg_main_2[] ;


/* msginfo/menu */
extern char _msg_menu_1[] ;
extern char _msg_menu_2[] ;
extern char _msg_menu_3[] ;


/* msginfo/more */
extern char _msg_more_1[] ;


/* msginfo/other */
extern char _msg_abort[] ;
extern char _msg_aborted[] ;
extern char _msg_ask_uuencode[] ;
extern char _msg_board_normal[] ;
extern char _msg_board_treasure[] ;
extern char _msg_chkoff[] ;
extern char _msg_chkon[] ;
extern char _msg_ent_userid[] ;
extern char _msg_err_boardname[] ;
extern char _msg_err_userid[] ;
extern char _msg_fail[] ;
extern char _msg_failed[] ;
extern char _msg_finish[] ;
extern char _msg_finished[] ;
extern char _msg_in_processing[] ;
extern char _msg_include_ori[] ;
extern char _msg_message_fail[] ;
extern char _msg_message_finish[] ;
extern char _msg_no_board_exist[] ;
extern char _msg_not_choose_board[] ;
extern char _msg_not_sure[] ;
extern char _msg_not_sure_modify[] ;
extern char _msg_off[] ;
extern char _msg_on[] ;
extern char _msg_press_enter[] ;
extern char _msg_sorry_email[] ;
extern char _msg_sorry_newuser[] ;
extern char _msg_title[] ;
extern char _msg_to_nth[] ;
extern char _msg_you_have_mail[] ;
extern char _str_marker[] ;


/* msginfo/post */
extern char _msg_bm_manage_cmd_full[] ;
extern char _msg_bm_manage_cmd_part[] ;
extern char _msg_bm_manage_edit_bmas[] ;
extern char _msg_cannot_check_board_list[] ;
extern char _msg_cannot_post_in_treasure[] ;
extern char _msg_choose_add[] ;
extern char _msg_choose_add_delete[] ;
extern char _msg_display_assistant[] ;
extern char _msg_mail_fail[] ;
extern char _msg_mail_finish[] ;
extern char _msg_mailpost_reply[] ;
extern char _msg_no_ident_send_tonews[] ;
extern char _msg_no_tag_found[] ;
extern char _msg_none[] ;
extern char _msg_post_1[] ;
extern char _msg_post_10[] ;
extern char _msg_post_11[] ;
extern char _msg_post_12[] ;
extern char _msg_post_2[] ;
extern char _msg_post_3[] ;
extern char _msg_post_4[] ;
extern char _msg_post_5[] ;
extern char _msg_post_6[] ;
extern char _msg_post_7[] ;
extern char _msg_post_8[] ;
extern char _msg_post_9[] ;
extern char _msg_post_fail[] ;
extern char _msg_post_finish[] ;
extern char _msg_post_on_normal[] ;
extern char _msg_post_on_treasure[] ;
extern char _msg_postperm_reason_guest[] ;
extern char _msg_postperm_reason_ident[] ;
extern char _msg_postperm_reason_level[] ;
extern char _msg_postperm_reason_treasure[] ;
extern char _msg_send_tonews_yesno[] ;
extern char _msg_treasure_cnvt[] ;
extern char _msg_treasure_cnvt_dir[] ;
extern char _str_combined_treasure_title[] ;


/* msginfo/read */
extern char _msg_backward[] ;
extern char _msg_forward[] ;
extern char _msg_read_1[] ;

extern char _msg_read_10[] ;
extern char _msg_read_11[] ;
extern char _msg_read_12[] ;
extern char _msg_read_13[] ;
extern char _msg_read_14[] ;
extern char _msg_read_15[] ;
extern char _msg_read_16[] ;
extern char _msg_read_17[] ;
extern char _msg_read_18[] ;
extern char _msg_read_2[] ;
extern char _msg_read_20[] ;
extern char _msg_read_21[] ;
extern char _msg_read_22[] ;
extern char _msg_read_23[] ;
extern char _msg_read_3[] ;

extern char _msg_read_4[] ;
extern char _msg_read_5[] ;
extern char _msg_read_6[] ;
extern char _msg_read_7[] ;
extern char _msg_read_8[] ;
extern char _msg_read_9[] ;


/* msginfo/stuff */
extern char _msg_stuff_1[] ;
extern char _msg_stuff_10[] ;
extern char _msg_stuff_11[] ;
extern char _msg_stuff_12[] ;
extern char _msg_stuff_13[] ;
extern char _msg_stuff_14[] ;
extern char _msg_stuff_15[] ;
extern char _msg_stuff_16[] ;
extern char _msg_stuff_17[] ;
extern char _msg_stuff_18[] ;
extern char _msg_stuff_19[] ;
extern char _msg_stuff_2[] ;
extern char _msg_stuff_3[] ;
extern char _msg_stuff_4[] ;
extern char _msg_stuff_5[] ;
extern char _msg_stuff_6[] ;
extern char _msg_stuff_7[] ;
extern char _msg_stuff_8[] ;
extern char _msg_stuff_9[] ;


/* msginfo/talk */
extern char _msg_talk_1[] ;
extern char _msg_talk_10[] ;
extern char _msg_talk_11[] ;
extern char _msg_talk_12[] ;
extern char _msg_talk_13[] ;
extern char _msg_talk_14[] ;
extern char _msg_talk_15[] ;
extern char _msg_talk_16[] ;
extern char _msg_talk_17[] ;
extern char _msg_talk_18[] ;
extern char _msg_talk_19[] ;
extern char _msg_talk_2[] ;
extern char _msg_talk_20[] ;
extern char _msg_talk_21[] ;
extern char _msg_talk_22[] ;
extern char _msg_talk_23[] ;
extern char _msg_talk_24[] ;
extern char _msg_talk_25[] ;
extern char _msg_talk_26[] ;
extern char _msg_talk_27[] ;
extern char _msg_talk_28[] ;
extern char _msg_talk_29[] ;
extern char _msg_talk_3[] ;
extern char _msg_talk_30[] ;
extern char _msg_talk_31[] ;
extern char _msg_talk_32[] ;
extern char _msg_talk_33[] ;
extern char _msg_talk_34[] ;
extern char _msg_talk_35[] ;
extern char _msg_talk_36[] ;
extern char _msg_talk_37[] ;
extern char _msg_talk_38[] ;
extern char _msg_talk_39[] ;
extern char _msg_talk_4[] ;
extern char _msg_talk_40[] ;
extern char _msg_talk_41[] ;
extern char _msg_talk_42[] ;
extern char _msg_talk_43[] ;
extern char _msg_talk_46[] ;
extern char _msg_talk_47[] ;
extern char _msg_talk_48[] ;
extern char _msg_talk_49[] ;
extern char _msg_talk_5[] ;
extern char _msg_talk_50[] ;
extern char _msg_talk_51[] ;
extern char _msg_talk_52[] ;
extern char _msg_talk_53[] ;
extern char _msg_talk_54[] ;
extern char _msg_talk_55[] ;
extern char _msg_talk_56[] ;
extern char _msg_talk_57[] ;
extern char _msg_talk_6[] ;
extern char _msg_talk_7[] ;
extern char _msg_talk_8[] ;
extern char _msg_talk_9[] ;
extern char _msg_talk_refuse_1[] ;
extern char _msg_talk_refuse_2[] ;
extern char _msg_talk_refuse_3[] ;
extern char _msg_talk_refuse_4[] ;
extern char _msg_talk_refuse_5[] ;
extern char _msg_talk_refuse_6[] ;
extern char _msg_talk_refuse_7[] ;
extern char _msg_talk_refuse_8[] ;


/* msginfo/vote */
extern char _msg_vote_1[] ;
extern char _msg_vote_10[] ;
extern char _msg_vote_11[] ;
extern char _msg_vote_12[] ;
extern char _msg_vote_13[] ;
extern char _msg_vote_14[] ;
extern char _msg_vote_15[] ;
extern char _msg_vote_16[] ;
extern char _msg_vote_17[] ;
extern char _msg_vote_18[] ;
extern char _msg_vote_19[] ;

extern char _msg_vote_2[] ;
extern char _msg_vote_20[] ;
extern char _msg_vote_21[] ;
extern char _msg_vote_22[] ;
extern char _msg_vote_23[] ;
extern char _msg_vote_24[] ;
extern char _msg_vote_25[] ;
extern char _msg_vote_26[] ;
extern char _msg_vote_27[] ;
extern char _msg_vote_28[] ;
extern char _msg_vote_29[] ;
extern char _msg_vote_3[] ;
extern char _msg_vote_30[] ;
extern char _msg_vote_31[] ;
extern char _msg_vote_32[] ;
extern char _msg_vote_33[] ;
extern char _msg_vote_34[] ;
extern char _msg_vote_35[] ;
extern char _msg_vote_36[] ;
extern char _msg_vote_37[] ;
extern char _msg_vote_38[] ;
extern char _msg_vote_39[] ;
extern char _msg_vote_4[] ;
extern char _msg_vote_5[] ;
extern char _msg_vote_6[] ;
extern char _msg_vote_7[] ;
extern char _msg_vote_8[] ;
extern char _msg_vote_9[] ;
extern char _msg_vote_holdlist1[] ;
extern char _msg_vote_holdlist2[] ;
extern char _msg_vote_holdlist3[] ;
extern char _msg_vote_holdlist4[] ;
extern char _msg_vote_holdlist5[] ;
extern char _msg_vote_holdlist6[] ;
extern char _msg_vote_holdlist7[] ;
extern char _msg_vote_holdlist8[] ;
extern char _msg_vote_holdlist9[] ;


/* msginfo/xyz */
extern char _msg_xyz_1[] ;
extern char _msg_xyz_10[] ;
extern char _msg_xyz_11[] ;
extern char _msg_xyz_12[] ;
extern char _msg_xyz_13[] ;
extern char _msg_xyz_14[] ;
extern char _msg_xyz_15[] ;
extern char _msg_xyz_16[] ;
extern char _msg_xyz_17[] ;
extern char _msg_xyz_18[] ;
extern char _msg_xyz_2[] ;
extern char _msg_xyz_20[] ;
extern char _msg_xyz_21[] ;
extern char _msg_xyz_22[] ;
extern char _msg_xyz_23[] ;
extern char _msg_xyz_24[] ;
extern char _msg_xyz_25[] ;
extern char _msg_xyz_26[] ;
extern char _msg_xyz_27[] ;
extern char _msg_xyz_28[] ;
extern char _msg_xyz_29[] ;
extern char _msg_xyz_3[] ;
extern char _msg_xyz_32[] ;
extern char _msg_xyz_33[] ;
extern char _msg_xyz_36[] ;
extern char _msg_xyz_37[] ;
extern char _msg_xyz_38[] ;
extern char _msg_xyz_39[] ;
extern char _msg_xyz_4[] ;
extern char _msg_xyz_40[] ;
extern char _msg_xyz_41[] ;
extern char _msg_xyz_42[] ;
extern char _msg_xyz_47[] ;
extern char _msg_xyz_48[] ;
extern char _msg_xyz_49[] ;
extern char _msg_xyz_5[] ;
extern char _msg_xyz_50[] ;
extern char _msg_xyz_51[] ;
extern char _msg_xyz_52[] ;
extern char _msg_xyz_53[] ;
extern char _msg_xyz_54[] ;
extern char _msg_xyz_55[] ;
extern char _msg_xyz_57[] ;
extern char _msg_xyz_58[] ;
extern char _msg_xyz_6[] ;
extern char _msg_xyz_60[] ;
extern char _msg_xyz_7[] ;
extern char _msg_xyz_8[] ;
extern char _msg_xyz_9[] ;

/* end of file */

#endif /* _BBS_MSGINFO_H_ */
