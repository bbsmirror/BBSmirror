/*
   Virtual TTY, Standalone BBS Daemon.
   ���{���ΨӨ��N Telnetd, �æ��� Server, �ϢТТᤣ�ݭn TTY   
   Ming-Jang Liang, lmj@cc.nsysu.edu.tw, 10/03/96
*/   

#include <sys/param.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/file.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <netdb.h>
#include <syslog.h>
#include <pwd.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/telnet.h>

#ifdef AIX
#include <sys/select.h>
#endif

#ifdef  SOLARIS
#include <fcntl.h>
#endif

#include "config.h"

#define	PATH_DEVNULL	"/dev/null"
#define PATH_BINBBS		"bin/bbsd"
#define INIT_TIMEOUT	240
#define RERUN			20

extern int errno;

char *telnet();


/*
   reaper - clean up zombie children
*/
static void
reaper()
{
#if	defined(SYSV)
	int status;
#else
	union wait status;
#endif

	while (wait3(&status, WNOHANG, (struct rusage *) 0) > 0)
		/* empty */ ;
	(void) signal(SIGCHLD, reaper);
}


/*
   Idle Timeout
 */
void
saybyebye()
{
	int fd = getdtablesize();


	while(fd)
		close(--fd);
	shutdown(0, 2);
	close(0);
	exit(0);
}


int
main(argc, argv)
int argc;
char *argv[];
{
	int aha, on = 1, maxs = 0;
	fd_set ibits;
	struct sockaddr_in from, sin;
	int s, ns;
	short check = 0, rerun = 0, port23 = 0;
	struct timeval wait;
	char buf[1024];
	extern int utmp_semid;
	
	if (argc < 2)
	{
		printf("Usage: %s PortNumber [check]\n", argv[0]);
		exit(1);
	}

	if (fork() != 0)
		exit(0);

	if (argc > 2 && !strcmp(argv[2], "check"))
	{
		check++;
		host_deny((char *) NULL);	/* init host deny table */
	}

	aha = getdtablesize();
	while (aha)
		close(--aha);

	if ((aha = open(PATH_DEVNULL, O_RDONLY)) < 0)
		exit(1);
	if (aha)
	{
		dup2(aha, 0);
		close(aha);
	}
	dup2(0, 1);
	dup2(0, 2);

	signal(SIGHUP, SIG_IGN);
	signal(SIGCHLD, reaper);

	if ((s = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		exit(1);

	setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (char *) &on, sizeof(on));
   
#if defined(IP_OPTIONS) && defined(IPPROTO_IP)
	setsockopt(s, IPPROTO_IP, IP_OPTIONS, (char *) NULL, 0);
#endif

	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = INADDR_ANY;
	sin.sin_port = htons((u_short) atoi(argv[1]));

	if (atoi(argv[1]) == 23)
		port23++;

	if (bind(s, (struct sockaddr *) &sin, sizeof sin) < 0 ||
	    listen(s, 256) < 0)
		exit(1);

	sprintf(buf, "/tmp/formosa.%-s", argv[1]);
	if ((aha = open(buf, O_WRONLY | O_CREAT | O_TRUNC, 0644)) > 0)
	{
		sprintf(buf, "%-d\n", getpid());
		write(aha, buf, strlen(buf));
		close(aha);
	}
	
	init_bbsenv();
	utmp_semid = sem_init(UTMPSEM_KEY);	
	
	aha = sizeof(from);
	wait.tv_sec = 5;
	wait.tv_usec = 0;
	maxs = s + 1;

	while (1)
	{
		FD_ZERO(&ibits);
		FD_SET(s, &ibits);
		if ((on = select(maxs, &ibits, 0, 0, &wait)) < 1)
		{
/*		
#ifndef SYSV
			if (port23 && ++rerun > RERUN)
			{
				shutdown(s, 2);
				close(s);
				if (fork())
					exit(0);
				else
					execv(PATH_BINBBS, &(argv[0]));
			}
#endif
*/
			if (!on || errno == EINTR)
				continue;
			else
			{
				sleep(5);
				shutdown(s, 2);
				close(s);
				if (fork())
					exit(0);
				else
					execv(PATH_BINBBS, &(argv[0]));
				continue;
			}
		}
		if (!FD_ISSET(s, &ibits))
			continue;
		if ((ns = accept(s, (struct sockaddr *) &from, (int *) &aha)) < 0)
			continue;
		else
		{
			switch (fork())
			{
			case -1:
				close(ns);
				break;
			case 0:
				{
					char *host, term[8];

					close(s);
					signal(SIGCHLD, SIG_IGN);
					signal(SIGALRM, saybyebye);
					alarm(INIT_TIMEOUT);
					dup2(ns, 0);
					close(ns);
					dup2(0, 1);
					dup2(0, 2);
					on = 1;
					setsockopt(0, SOL_SOCKET, SO_KEEPALIVE,
						   (char *) &on, sizeof(on));
					host = inet_ntoa(from.sin_addr);
					if (check && host_deny(host))
					{
						printf("\r\n\r\nSorry, connection from [%s] rejected\r\n", host);
						fflush(stdout);
						sleep(3);
						shutdown(0, 2);
						exit(0);
					}
					Formosa(host, telnet(&term[0]));
					shutdown(0, 2);
					exit(0);
				}
			default:
				close(ns);
				rerun &= ~rerun;
			}
		}
	}
}



char *
telnet(term)
char *term;
{
	int aha;
	unsigned ibuf[80], *p;
	unsigned char o1[] =
	{IAC, DO, TELOPT_TTYPE};
	unsigned char o2[] =
	{IAC, WILL, TELOPT_ECHO};
	unsigned char o3[] =
	{IAC, WILL, TELOPT_SGA};
	unsigned char o4[] =
	{IAC, DO, TELOPT_ECHO};
	unsigned char o5[] =
	{IAC, DO, TELOPT_BINARY};


	aha = 1;
	*term = '\0';

#ifdef SO_OOBINLINE
	setsockopt(0, SOL_SOCKET, SO_OOBINLINE, (char *) &aha, sizeof aha);
#endif

	ibuf[0] = 0;

	sprintf((char *)(ibuf + 1), "\r\n\r\n�� %s ��\r\n\r\r\n\r", BBSNAME);
	write(1, ibuf, strlen((char *)(ibuf + 1)) + 1);
	write(1, o1, sizeof(o1));
	fflush(stdout);

	for (aha = 0; aha < 3; aha++)
	{
		ibuf[aha] = igetch();
	}
	if (ibuf[0] == IAC && ibuf[1] == WILL && ibuf[2] == TELOPT_TTYPE)
	{
		unsigned char oo[] =
		{IAC, SB, TELOPT_TTYPE, TELQUAL_SEND, IAC, SE};

		write(1, oo, sizeof(oo));
		for (aha = 0; aha < 4; aha++)
			ibuf[aha] = igetch();
		if (ibuf[0] == IAC && ibuf[3] == TELQUAL_IS)
		{
			p = ibuf;
			while (1)
			{
				*p = igetch();
				if (*p == IAC)
				{
					*p = '\0';
					igetch();
					break;
				}
				else
					p++;
			}
			strncpy(term, (char *) &ibuf[0], 8);
		}
	}

	write(1, o2, sizeof(o2));
	write(1, o3, sizeof(o3));
	write(1, o4, sizeof(o4));
	write(1, o5, sizeof(o5));
	return term;
}
