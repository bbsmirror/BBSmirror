/*
   Li-te Huang, lthuang@cc.nsysu.edu.tw, 03/15/98
   Last updated: 03/17/98
*/   

#include "bbs.h"
#include "tsbbs.h"


#if	defined(LINUX)
#include <bsd/sgtty.h>
#else
#include <sgtty.h>
#endif

#if	defined(TERMIOS)
#include <termios.h>
struct termios tty_state, tty_new;

#else
struct sgttyb tty_state, tty_new;

#endif

#ifndef TANDEM
#define TANDEM  0x00000001
#endif

#ifndef PASS8
#define PASS8   0x08000000
#endif

#ifndef CBREAK
#define CBREAK  0x00000002
#endif


int
gtty(fd, tstate)
int fd;

#if	defined(TERMIOS)
struct termios *tstate;
#else
struct sgttyb *tstate;
#endif
{
#if	defined(TERMIOS)
/* vt100 setting */
	tstate->c_iflag = 0x500;
	tstate->c_oflag = 0x5;
	tstate->c_cflag = 0xbd;
	tstate->c_lflag = 0x8a3b;
	tstate->c_line = 0x00;
	tstate->c_lflag &= ~(ICANON | ECHO | ECHOE | ECHOK | ISIG);
	tstate->c_cc[VMIN] = 1;
	tstate->c_cc[VTIME] = 0;
#ifdef LINUX			/* lthuang ? */
	/* Hopefully temporary workaround for buggy login program. */
	tty_state.c_oflag |= OPOST;
	tty_state.c_iflag |= BRKINT;
	tty_state.c_lflag |= ISIG;
#endif

#else /* !TERMIOS */
/* vt100 setting */
	tstate->sg_ispeed = 0x0f;
	tstate->sg_ospeed = 0x0f;
	tstate->sg_erase = 0x7f;
	tstate->sg_kill = 0x15;
	tstate->sg_flags = 0x0cd8;
#endif
	return 0;
}


int
stty(fd, tty_state)
int fd;

#if	defined(TERMIOS)
struct termios *tty_state;
#else
struct sgttyb *tty_state;

#endif
{
	return 0;
}


void
init_tty()
{
	if (gtty(1, &tty_state) < 0)
	{
		fprintf(stderr, "gtty failed\n");
		exit(-1);
	}
	memcpy(&tty_new, &tty_state, sizeof(tty_new));

#if	defined(TERMIOS)
	tty_new.c_lflag &= ~(ICANON | ECHO | RAW | ISIG);
	tty_new.c_iflag &= IXANY;
	tty_new.c_oflag &= ~(OPOST | OLCUC | OCRNL);
	tty_new.c_lflag &= ~(XCASE);
	tty_new.c_lflag |= TOSTOP;
#else

	tty_new.sg_flags |= (RAW | PASS8);
#ifdef HP_UX
	tty_new.sg_flags &= ~(HUPCL | XTABS | LCASE | ECHO | CRMOD);
#else
	tty_new.sg_flags &= ~(TANDEM | CBREAK | LCASE | ECHO | CRMOD);
#endif
#endif /* !TERMIOS */
	stty(1, &tty_new);
}


void
reset_tty()
{
	stty(1, &tty_state);
}


void
restore_tty()
{
	stty(1, &tty_new);
}


#define TERMCOMSIZE (24)

char clearbuf[TERMCOMSIZE];
int clearbuflen;

char cleolbuf[TERMCOMSIZE];
int cleolbuflen;

char cursorm[TERMCOMSIZE];
char *cm;

char scrollrev[TERMCOMSIZE];
int scrollrevlen;

char strtstandout[TERMCOMSIZE];
int strtstandoutlen;

char endstandout[TERMCOMSIZE];
int endstandoutlen;

int t_lines = 24;
int t_columns = 80;

int automargins;

char *outp;
int *outlp;

static void
outcf(ch)
char ch;
{
	if (*outlp < TERMCOMSIZE)
	{
		(*outlp)++;
		*outp++ = ch;
	}
}


int
term_init(term)
char *term;
{
	extern char PC, *UP, *BC;	
	extern short ospeed ;		
	static char UPbuf[TERMCOMSIZE];
	static char BCbuf[TERMCOMSIZE];
	static char buf[1024];
	char sbuf[2048];
	char *sbp, *s;
	char *tgetstr();

#if	defined(TERMIOS)
	ospeed = cfgetospeed(&tty_state);
#else
	ospeed = tty_state.sg_ospeed;
#endif

	if (tgetent(buf, term) != 1)
		return 0;
	sbp = sbuf;
	s = tgetstr("pc", &sbp);	/* get pad character */
	if (s)
		PC = *s;
	t_lines = tgetnum("li");
	t_columns = tgetnum("co");
	automargins = tgetflag("am");
	
	outp = clearbuf;	/* fill clearbuf with clear screen command */
	outlp = &clearbuflen;
	clearbuflen = 0;
	sbp = sbuf;
	s = tgetstr("cl", &sbp);
	if (s)
		tputs(s, t_lines, outcf);

	outp = cleolbuf;	/* fill cleolbuf with clear to eol command */
	outlp = &cleolbuflen;
	cleolbuflen = 0;
	sbp = sbuf;
	s = tgetstr("ce", &sbp);
	if (s)
		tputs(s, 1, outcf);

	outp = scrollrev;
	outlp = &scrollrevlen;
	scrollrevlen = 0;
	sbp = sbuf;
	s = tgetstr("sr", &sbp);
	if (s)
		tputs(s, 1, outcf);

	outp = strtstandout;
	outlp = &strtstandoutlen;
	strtstandoutlen = 0;
	sbp = sbuf;
	s = tgetstr("so", &sbp);
	if (s)
		tputs(s, 1, outcf);

	outp = endstandout;
	outlp = &endstandoutlen;
	endstandoutlen = 0;
	sbp = sbuf;
	s = tgetstr("se", &sbp);
	if (s)
		tputs(s, 1, outcf);

	sbp = cursorm;
	cm = tgetstr("cm", &sbp);
	if (cm)
		dumb_term &= ~dumb_term;
	else
		dumb_term |= ~dumb_term;

	sbp = UPbuf;
	UP = tgetstr("up", &sbp);
	sbp = BCbuf;
	BC = tgetstr("bc", &sbp);
	return 1;
}


void
do_move(destcol, destline, outc)
int destcol, destline;
int (*outc) ();
{
	tputs(tgoto(cm, destcol, destline), 0, outc);
}
