#include "linklist.h"

/* admin.c */
int a_info(void);
int a_modifybrd(void);
int a_pack1brd(void);
int a_newbrd(void);
int a_delbrd(void);
int a_welcome(void);
int a_bbsnews(void);
int a_cloak(void);
int a_kick(void);
int a_broadcast(void);
int invalid_bname(char *bname);
/* article.c */
void readed_article(int ent, FILEHEADER *finfo, char *direct);
int title_article(int ent, FILEHEADER *finfo, char *direct);
int edit_article(int ent, FILEHEADER *finfo, char *direct);
int reserve_article(int ent, FILEHEADER *finfo, char *direct);
int range_delete_article(int ent, FILEHEADER *finfo, char *direct);
int read_article(int ent, FILEHEADER *finfo, char *direct);
int delete_article(int ent, FILEHEADER *finfo, char *direct);
int mail_articles(char *direct, char *from, char *to, int ident, int uuencode, struct word *wtop);
int mail_article(int ent, FILEHEADER *finfo, char *direct);
int cross_article(int ent, FILEHEADER *finfo, char *direct);
int search_article(register char *direct, register int ent, register char *cmps_str, int op, register struct word **srchwtop);
int xchg_treasure(int ent, FILEHEADER *finfo, char *direct);
int do_article_title(char title[]);
void uuencode_file(char *fname, char *uuname);
/* board.c */
void free_board_list(struct BoardList *blist);
int board_list_cmp(struct BoardList *bname, char *name);
int check_board_list(void);
int Boards(int cls);
int MakeBoardList(void);
void DelBoardList(void);
int CompleteBoardName(char *data);
int choose_board(void);
int Select(void);
int isAssistant(char *s);
/* chat.c */
char *mycrypt(char *pw);
char *PhaseSpace(char *str);
char *GetPass(char *str, char *token, int maxlen);
int t_chat(void);
void printchatline(char *str);
int GetRespNo(char *str);
int dochatcommand(char *cmd);
/* edit.c */
int vedit(const char *filename, const char *saveheader);
/* formosa.c */
void abort_bbs(int s);
void warn_bell(void);
void talk_request(int s);
void write_request(int s);
void log_visitor(void);
int xgrep(char *pattern, char *filename);
int invalid_userid(char *userid);
int Announce(void);
int Users(void);
int count_multi_login(USER_INFO *upent);
void multi_user_check(void);
void Formosa(char *host, char *term);
/* ident.c */
int id_num_check(char *num);
int send_checkmail(char email[], char buf[]);
int check_cname(unsigned char name[]);
int do_post_ident(void);
int CheckID(void);
/* io.c */
void idle_timeout(int s);
void init_alarm(int type);
void oflush(void);
void output(char *s, int len);
int ochar(int c);
void add_io(int fd, int timeout);
void add_flush(int (*flushfunc)());
int num_in_buf(void);
int igetch(void);
int getkey(void);
int igetkey(void);
int getdata(int line, int col, char *prompt, char *buf, int len, int echo, char *prefix);
/* list.c */
int my_send(char *userid);
int my_kick(USER_INFO *upent);
int search_num(int ch, int max);
void showtitle(char *title, char *mid);
void str_lower(char *t, char *s);
int strstr_lower(char *str, char *tag);
void t_showhelp(void);
void pickup_user(void);
int t_list(void);
int t_friends(void);
/* mail.c */
int do_faxans_title(char title[], int option);
int do_article_tofax(char to[]);
int PrepareFaxAns(char *fname, char *to, char *title, int option);
int m_sendfax(void);
int m_vmachine(void);
int haveNo(void);
int readResult(int fd);
void getResult(int fd);
void mod_telepass(void);
int ChangeNTPass(long *idno, char *newpass);
int check_newmail(char *name);
int m_group(void);
int m_send(void);
int m_new(void);
int m_read(void);
int CheckFwdEmailaddr(char *addr);
int m_forward(void);
int do_article_to(char to[]);
/* main.c */
void saybyebye(void);
void main(int argc, char *argv[]);
char *telnet(char *term);
/* menu.c */
void domenu(void);
/* more.c */
int readln(FILE *fp, char *buf);
int more(char *filename, int promptend);
/* msginfo.c */
/* post.c */
int display_bmas(void);
void add_bmas(char *Uident);
void delete_bmas(char *Uident);
int bm_manage_file(void);
int read_help(void);
int has_postperm(struct BoardList *blistent);
int PrepareMailPost(char *fn_src, char *to, char *title, char *postpath, int mail_ok, int post_ok);
int ReplyMailPost(FILEHEADER *finfo, char *direct, int mail_ok, int post_ok);
int do_post(int ent, FILEHEADER *finfo, char *direct);
int Post(void);
int Read(void);
int treasure_article(int ent, FILEHEADER *finfo, char *direct);
int mkdir_treasure(int ent, FILEHEADER *finfo, char *direct);
/* read.c */
int get_list(char *direct, int top);
void mail_title(void);
void post_title(void);
void chk_str(char str[]);
void read_ent(FILEHEADER ent[], int c, int total, int num);
int select_item(char *direct, int *stop, int *scur, int *total, int the_num);
int quit_iread(char *direct);
void change_board(char **direct);
int i_read(char *direct, struct one_key *comm, int action);
/* screen.c */
void initscr(void);
void rel_move(int was_col, int was_ln, int new_col, int new_ln);
void standoutput(char *buf, int ds, int de, int sso, int eso);
void redoscr(void);
void refresh(void);
void clear(void);
void clrtoeol(void);
void clrtobot(void);
void move(int y, int x);
void getyx(int *y, int *x);
int coutc(int c);
void outs(register char *str);
void scroll(void);
void rscroll(void);
void standout(void);
void standend(void);
void save_screen(void);
void restore_screen(void);
/* stuff.c */
void pressreturn(void);
int bbssetenv(char *env, char *val);
int do_exec(char *com, char *wd);
int outdoor(char *cmd_file, int umode, int dotimeout);
void show_byebye(int idle);
int Goodbye(void);
int Switch_scr(void);
char *Ctime(time_t *clock);
void bell(void);
int isprint2(int ch);
int isprint3(int ch);
int namecomplete(struct word *toplev, char *prompt, char data[]);
int GetNumFileLine(char *filename);
void subject(char *title);
void update_umode(int mode);
/* talk.c */
int FriendLoadCache(void);
int MyFriend(char *whoasks);
int FriendDisplay(void);
void FriendAdd(char *ident);
void FriendDelete(char *ident);
int t_pager(void);
int QueryUser(char *ident);
int t_query(void);
int CompleteOnlineUser(char *data);
int talk_user(USER_INFO *tkuinf);
int t_talk(void);
BOOL servicepage(int arg);
int talkreply(void);
void do_talk_char(int sline, int eline, int *curln, int *curcol, char *wordbuf, int *wordbuflen, int ch);
void do_talk_string(int sline, int eline, int *curln, int *curcol, char *wordbuf, int *wordbuflen, char *s);
int talkflush(void);
void do_talk(int fd);
int t_irc(void);
int t_ircl(void);
int DoMessageUser(USER_INFO *upent);
int ParseMesgStr(char *string, char *fillinstr);
int PrepareMesgContent(char *who);
int SendMesgToSomeone(char *ident);
int ReplyLastCall(void);
int writereply(void);
int t_review(void);
int t_message(void);
int t_fsendmsg(void);
int InOutdoor(USER_INFO *uinfo_ent);
/* term.c */
void init_tty(void);
void reset_tty(void);
void restore_tty(void);
int term_init(char *term);
void do_move(int destcol, int destline, int (*outc)());
/* var.c */
/* vote.c */
int v_help1(void);
int v_help2(void);
int v_help3(void);
int v_hold(void);
int v_edit(void);
int v_board(void);
int v_boardhold(void);
int v_delete(void);
int v_system(void);
int UnSeenVote(char *vpath);
void CheckNewSysVote(void);
void DisplayNewVoteMesg(void);
void SetVotePath(char path_buf[], char bname[]);
int inVoting(void);
/* xyz.c */
void show_user_info(USEREC *urcPerson);
int x_info(void);
int x_date(void);
int x_signature(void);
int x_ircrc(void);
int x_plan(void);
int x_override(void);
int modify_user(USEREC *urcOld, int myself);
int x_picture(void);
int x_noteswitch(void);
int x_viewnote(void);
