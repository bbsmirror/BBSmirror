
#include "bbs.h"
#include "tsbbs.h"


extern struct commands MainMenu[];


/*******************************************************************
 * Admin Menu
 *******************************************************************/
extern int a_info(), a_newbrd(), a_delbrd(), a_modifybrd(), a_welcome(),
  a_bbsnews(), a_cloak(), a_kick(), a_pack1brd(), Users(), a_broadcast(),
  a_classconf();

#ifdef HAVE_DELUSER
extern int a_deluser();
#endif

#if HAVE_IDENT
#if defined(SYSOP_BIN)
extern int a_check(), a_find();
#endif
#endif


struct commands AdminMenu[] =
{
    'i', PERM_SYSOP, NULL, a_info, ADMIN, "(\033[1;36mi\033[m) User Info", "���ϥΪ̸��",
#ifdef HAVE_DELUSER
    'd', PERM_SYSOP, NULL, a_deluser, ADMIN, "(\033[1;36md\033[m) Delete User", "�R���@��ϥΪ�",
#endif
    'n', PERM_SYSOP, NULL, a_newbrd, ADMIN, "(\033[1;36mn\033[m) New Board", "�إ߷s�ݪO",
    'b', PERM_SYSOP, NULL, a_delbrd, ADMIN, "(\033[1;36mb\033[m) Board Delete", "�R���ݪO",
    'm', PERM_SYSOP, NULL, a_modifybrd, ADMIN, "(\033[1;36mm\033[m) Modify Board", "���ݪO�]�w",
    '1', PERM_SYSOP, NULL, a_pack1brd, ADMIN, "(\033[1;36m1\033[m) Pack One Boards", "����S�w�G�i��",
    'w', PERM_SYSOP, NULL, a_welcome, ADMIN, "(\033[1;36mw\033[m) Welcome Edit", "�s���w��e��",
    'c', PERM_SYSOP, NULL, a_bbsnews, ADMIN, "(\033[1;36mc\033[m) Config BBS-News", "�s�� BBS-News ��H�]�w��",
    's', PERM_SYSOP, NULL, a_classconf, ADMIN, "(\033[1;36ms\033[m) Config ClassMenu", "�s�� Class �ݪO�������]�w��",
    'o', PERM_SYSOP, NULL, a_cloak, ADMIN, "(\033[1;36mo\033[m) Cloak", "����",
    'u', PERM_SYSOP, NULL, Users, LAUSERS, "(\033[1;36mu\033[m) List All Users", "�C�X�Ҧ��ϥΪ�",
    'k', PERM_SYSOP, NULL, a_kick, ADMIN, "(\033[1;36mk\033[m) Kick User", "�N�u�W�ϥΪ��_�u",
    'a', PERM_SYSOP, NULL, a_broadcast, SENDMSG, "(\033[1;36ma\033[m) BroadCast", "�����s��",

#if HAVE_IDENT
#if defined(SYSOP_BIN)
    'f', PERM_SYSOP, NULL, a_find, ADMIN, "(\033[1;36mf\033[m) Show Real Data", "�˵��ϥΪ̯u����",
    't', PERM_SYSOP, NULL, a_check, ADMIN, "(\033[1;36mt\033[m) Set ID Check", "�d�ݨϥΪ̻{�ҥӽ�",
#endif    
#endif
    'a', PERM_SYSOP, MainMenu, NULL, ADMIN, "Admin Menu", "�޲z�̿줽��",
    0, PERM_SYSOP, NULL, NULL, 0, NULL, NULL

};


/*******************************************************************
 * Xyz Menu
 *******************************************************************/
extern int x_info(), x_override(), x_signature(), x_plan(), x_ircrc(),
  x_date(), Switch_scr(), t_pager(), x_viewnote(), x_noteswitch(), 
  Announce();

#ifdef USE_BBSNET
extern int BBSNet();
#endif

#if HAVE_IDENT
extern int CheckID();
#endif

#ifdef USE_MENUSHOW
extern int x_picture();
#endif

struct commands XyzMenu[] =
{
#ifdef USE_BBSNET
    'b', 1, NULL, BBSNet, 0, "(\033[1;36mb\033[m) BBS Net", "BBS Net",
#endif
    'd', 1, NULL, x_info, 0, "(\033[1;36md\033[m) Personal Data", "��ܻP�ק�ӤH�򥻸��",
    'p', 1, NULL, t_pager, PAGE, "(\033[1;36mp\033[m) Pager Switch", "���}/������ѩI��a",
    'o', 1, NULL, x_override, OVERRIDE, "(\033[1;36mo\033[m) Override Edit", "�s��n�B�ͦW��",
    's', 1, NULL, x_signature, EDITSIG, "(\033[1;36ms\033[m) Signature Edit", "�s��ñ�W��",
    'n', 1, NULL, x_plan, EDITPLAN, "(\033[1;36mn\033[m) Plan Edit", "�s��W����",
    'i', 1, NULL, x_ircrc, 0, "(\033[1;36mi\033[m) Ircrc Edit", "�s�� .ircrc �]�w��",
    'a', 0, NULL, Announce, READING, "(\033[1;36ma\033[m) Announce", "�i�����i",
    't', 0, NULL, x_date, 0, "(\033[1;36mt\033[m) Time Now", "��ܲ{�b�t�ήɶ�",
    'w', 0, NULL, Switch_scr, 0, "(\033[1;36mw\033[m) Color/BW Switch", "���/�m����ܼҦ�����",
#ifdef USE_MENUSHOW
    'u', 0, NULL, x_picture, 0, "(\033[1;36mu\033[m) Picture Menu Switch", "���}/�����q�ϼҦ�",
#endif
    'v', 0, NULL, x_viewnote, 0, "(\033[1;36mv\033[m) View Note", "�d�\\�d��",
    'm', 0, NULL, x_noteswitch, 0, "(\033[1;36mm\033[m) Note Board Switch", "�����O�_�[�ݯd���O",
#if HAVE_IDENT
    'c', 1, NULL, CheckID, 0, "(\033[1;36mc\033[m) ID Check", "�i�樭���T�{",
#endif
    'x', 0, MainMenu, NULL, XMENU, "Xyz Menu", "�ӤH��ƺ��@�u��c",
    0, 0, NULL, NULL, 0, NULL, NULL
};


/*******************************************************************
 * Mail Menu
 *******************************************************************/
extern int m_new(), m_read(), m_send(), m_forward(), m_group();


struct commands MailMenu[] =
{
    'n', 1, NULL, m_new, RMAIL, "(\033[1;36mn\033[m) New Mails", "�uŪ�s���H",
    'r', 1, NULL, m_read, RMAIL, "(\033[1;36mr\033[m) Read Mails", "�˵��Ҧ��H��",
    's', 1, NULL, m_send, SMAIL, "(\033[1;36ms\033[m) Send Mail", "�H�H",
    'g', 1, NULL, m_group, SMAIL, "(\033[1;36mg\033[m) Mail to Group", "�H�H���h�H",
    'a', 0, NULL, m_forward, MAIL, "(\033[1;36ma\033[m) Auto-Forward", "�H��۰���H�A��",
    'm', 0, MainMenu, NULL, MAIL, "Mail Menu", "�ӤH�H�c",
    0, 0, NULL, NULL, 0, NULL, NULL
};


/*******************************************************************
 * Talk Menu
 *******************************************************************/
extern int t_query(), t_talk(), t_chat(), t_irc(), x_override(), t_list(),
  t_friends(), t_message(), t_fsendmsg(), t_review();

#ifdef USE_LOCALIRC
extern int t_ircl();
#endif



struct commands TalkMenu[] =
{
    'u', 0, NULL, t_list, LUSERS, "(\033[1;36mu\033[m) Online Users", "���C�X���b�u�W���ϥΪ�",
    'f', 1, NULL, t_friends, LFRIENDS, "(\033[1;36mf\033[m) Friends Online", "�C�X���b�u�W���ѪB��",
#ifndef USE_MENUSHOW
    'o', 1, NULL, x_override, OVERRIDE, "(\033[1;36mo\033[m) Override Edit", "�s��n�B�ͦW��",
#endif
    'q', 0, NULL, t_query, QUERY, "(\033[1;36mq\033[m) Query User", "�d�ߨϥΪ̭ӤH��ƲӶ�",
#ifndef USE_MENUSHOW
    'p', 1, NULL, t_pager, PAGE, "(\033[1;36mp\033[m) Pager Switch", "���}/������ѩI��a",
#endif
    't', 1, NULL, t_talk, PAGE, "(\033[1;36mt\033[m) Talk", "���H�ͤ߶���",
    'w', 1, NULL, t_message, SENDMSG, "(\033[1;36mw\033[m) Send Message", "�u�W�e�T��",
#ifdef USE_FRIEND_BROADCAST
'b', 1, NULL, t_fsendmsg, SENDMSG, "(\033[1;36mb\033[m) BroadCast", "�e�T�����n��",
#endif
    'r', 1, NULL, t_review, SENDMSG, "(\033[1;36mr\033[m) Review Message", "�^�U�u�W�T��",
    'c', 1, NULL, t_chat, CHATROOM, "(\033[1;36mc\033[m) BBS Chat Room", "������Ѽs��",
#ifdef USE_LOCALIRC
    'l', 1, NULL, t_ircl, LOCALIRC, "(\033[1;36ml\033[m) Local IRC", "�h���p�X��Ѽs��",
#endif
    'i', 1, NULL, t_irc, IRCCHAT, "(\033[1;36mi\033[m) IRC", "��ڲ�Ѽs��",
    't', 0, MainMenu, NULL, TMENU, "Talk Menu", "�𶢲�Ѷ�a",
    0, 0, NULL, NULL, 0, NULL, NULL
};


#ifdef USE_VOTE

extern struct commands VoteMenu[];
extern struct commands VoteAdminMenu[];

/*******************************************************************
 * VOTE Menu Help
 *******************************************************************/
extern int v_help1(), v_help2(), v_help3();

struct commands VoteHelpMenu[] =
{
    '1', 0, NULL, v_help1, VOTING, "[\033[1;33m1\033[m]  About Voting", "�p��ϥΧ벼",
    '2', 0, NULL, v_help2, VOTING, "[\033[1;33m2\033[m]  Hold a Vote", "�p��ӽЧ벼��",
    '3', 0, NULL, v_help3, VOTING, "[\033[1;33m3\033[m]  Notice", "�`�N�ƶ�",
    'l', 0, &(VoteMenu[0]), NULL, VOTING, "Vote Menu", "�p��ϥΧ벼",
    0, 0, NULL, NULL, 0, NULL, NULL
};


/*******************************************************************
 * VOTE Menu
 *******************************************************************/
extern int v_edit(), v_delete(), v_hold();

struct commands VoteAdminMenu[] =
{
    '1', PERM_BM, NULL, v_hold, ADDVOTE, "[\033[1;33m1\033[m]  Add Vote", "�W�[�벼",
    '2', PERM_BM, NULL, v_edit, EDITVOTE, "[\033[1;33m2\033[m]  Edit Vote", "�ק�벼",
    '3', PERM_BM, NULL, v_delete, DELVOTE, "[\033[1;33m3\033[m]  Delete Vote", "�R���벼",
    'a', PERM_BM, &(VoteMenu[0]), NULL, VOTING, "Vote Menu", "�벼�u��c",
    0, PERM_BM, NULL, NULL, 0, NULL, NULL
};


extern int v_system(), v_board();

struct commands VoteMenu[] =
{
    's', 1, NULL, v_system, VOTING, "(\033[1;36ms\033[m)  System Vote", "�t�Χ벼��",
    'b', 1, NULL, v_board, VOTING, "(\033[1;36mb\033[m)  Board Vote", "�U�O�벼��",
    'l', 0, &(VoteHelpMenu[0]), NULL, VOTING, "(\033[1;36ml\033[m)  Help", "�벼�ϥλ���",
    'a', PERM_BM, &(VoteAdminMenu[0]), NULL, VOTING, "(\033[1;36ma\033[m)  Vote Admin", "�벼�u��c",
    'v', 0, MainMenu, NULL, VOTING, "Vote Menu", "BBS �벼��",
    0, 0, NULL, NULL, 0, NULL, NULL
};

#endif /* USE_VOTE */


/*******************************************************************
 * Main Menu
 *******************************************************************/
extern int Select(), Read(), Post(), Goodbye(), Boards();


struct commands MainMenu[] =
{
    'c', 0, NULL, Boards, CLASS_MENU, "(\033[1;32mc\033[m) Class", "�������G�i����",
    '0', 0, NULL, Boards, BOARDS_MENU, "(\033[1;32m0\033[m) Boards", "��Ц��G�i����",
    's', 0, NULL, Select, SELECT, "(\033[1;32ms\033[m) Select", "��J���G�i����",
    'r', 0, NULL, Read, READING, "(\033[1;32mr\033[m) Read", "Ū���G�i",
    't', 0, &(TalkMenu[0]), NULL, TMENU, "(\033[1;32mt\033[m) Talk Menu", "�𶢲�Ѷ�a",
    'm', 1, &(MailMenu[0]), NULL, MAIL, "(\033[1;32mm\033[m) Mail Menu", "�ӤH�l��H�c",
#ifdef HAVE_LISTALLUSER
    'u', 0, NULL, Users, LAUSERS, "(\033[1;32mu\033[m) List All Users", "�C�X�Ҧ��ϥΪ̸��",
#endif
    'x', 0, &(XyzMenu[0]), NULL, XMENU, "(\033[1;32mx\033[m) Xyz Utilities", "�ӤH��ƺ��@�u��c",
#ifdef USE_VOTE
   'v', 1, &(VoteMenu[0]), NULL, VOTING, "(\033[1;32mv\033[m) Vote", "�i�J�벼��",
#endif
    'g', 0, NULL, Goodbye, 0, "(\033[1;32mg\033[m) Goodbye", "�A���A�ڪ��B��",
    'a', PERM_SYSOP, &(AdminMenu[0]), NULL, ADMIN, "(\033[1;32ma\033[m) Admin Menu", "�޲z�̿줽��",
    '0', 0, NULL, NULL, MMENU, "Main Menu", BBSTITLE,
    0, 0, NULL, NULL, 0, NULL, NULL
};


/*******************************************************************
 * Menu Operation
 *******************************************************************/
#define PUTCURS   move(c+4,3);outs(_str_cursor);
#define RMVCURS   move(c+4,3);outs(_str_uncurs);

char auto_key = '\0';	/* lthuang */

#ifdef USE_MENUSHOW
char pict_path[PATHLEN];
int pict_no = 0;
struct MenuShowShm *msshm;
#endif


void
domenu()
{
	/*
	   c: index of current item (0 ~ total - 1) 
	   total: total number of current menu
	*/
	int c = 0, total = 0, i;
	int mode = M_NEW, key = '\0';
	unsigned int realc[20];
	int realtotal = 0;
	int menulayer = 1;	/* layer of menu */
	struct commands *comm = &(MainMenu[0]);

#ifdef USE_VOTE
	CheckNewSysVote();
#endif

	while (1)
	{
		switch (mode)
		{
		case CAREYDOWN:
			RMVCURS;
			if (c == total - 1)
				c = 0;
			else
				c++;
			break;
		case CAREYUP:
			RMVCURS;
			if (c == 0)
				c = total - 1;
			else
				c--;
			break;
		case M_NEW:
			for (realtotal = 0; comm[realtotal + 1].key; realtotal++)
				/* NULL STATEMENT */ ;
			for (i = 0, total = 0; i < realtotal && total < realtotal; i++)
			{
#if HAVE_IDENT
				if (comm[i].cfunc == CheckID && curuser.ident == 7)
					continue;
#endif
				if (curuser.userlevel < comm[i].level)
					continue;
				realc[total++] = i;
			}
			update_umode(comm[realtotal].mode);

			/* if new mail available, key move to the function automatically */
			if (menulayer == 1 && check_newmail(curuser.userid))	
				auto_key = 'm';
				
			for (c = 0; c < total; c++)
			{
				if (auto_key == comm[realc[c]].key)
					break;
			}
			if (c == total)		/* auto key set wrong */
				c = 0;
		case M_FULL:
			clear();
			move(4, 0);
			clrtobot();
			for (i = 0; i < total; i++)
			{
				prints("       %-40s %s\n",
				       comm[realc[i]].ehelp, comm[realc[i]].chelp);
			}
#ifdef USE_MENUSHOW
			if (!(curuser.flags[1] & PICTURE_FLAG))
			{
				if (msshm == NULL)
					msshm = (struct MenuShowShm *) attach_shm(MENUSHOW_KEY, sizeof(struct MenuShowShm));
				if (msshm && msshm->flag && msshm->number)
				{
					int j;
					char *p1, *p2;
					unsigned char chs;
					static long randomseed = 1;

					/*  
					   This is a simple linear congruential random number
					   generator.  Hence, it is a bad random number
					   generator, but good enough for most randomized
					   geometric algorithms. modify by lthuang
					*/					   
					randomseed = (randomseed * 1366l + 150889l) % 714025l;
					pict_no = randomseed / (714025l / msshm->number + 1);
/*                
					pict_no = (time(0) % msshm->number);
*/					
					j = i + 5;
					move(j++, 0);
					outs(msshm->list[pict_no].header);
					p1 = msshm->list[pict_no].body;					

					move(j, 0);
					while (j++ < b_line)
					{
						if (p2 = strchr(p1, '\n'))
							p1 = ++p2;
						else
							break;
					}
					/* 
					 * Direct output the content in shared memory,
					 * for better performance. by lthuang
					 */
					j = p1 - msshm->list[pict_no].body;
					p1 = msshm->list[pict_no].body;
					while (j-- > 0 && (chs = *p1++) != '\0')
						outc(chs);
				}
			}
#endif /* USE_MENUSHOW */
			printxy(0, 0, "%s%-30s%s  %10s            ",
				MENU_TITLE_COLOR, comm[realtotal].chelp, MENU_TITLE_COLOR2,
				(check_newmail(curuser.userid) ? _msg_you_have_mail : "          "));
			if (menulayer == 1)	/* lthuang */
			{
				prints(_msg_menu_1,
				       (CurBList ? CurBList->name : _msg_not_choose_board));
			}
			else
				prints("%23s \033[m", "");

			if (comm[realc[c]].cfunc != Goodbye)	/* lthuang */
			{
				move(2, 0);
				clrtoeol();
			}
			printxy(b_line, 0, _msg_menu_2, MENU_BTITLE_COLOR);	/* lthuang */
			break;
		default:
			break;
		}
		move(1, 0);
		clrtoeol();
		prints(_msg_menu_3, comm[realc[c]].ehelp);
		mode = M_NO;	/* ? */
		PUTCURS;	/* ? */
		if (talkrequest)
		{
			talkreply();
			mode = M_FULL;
			continue;
		}
		else if (writerequest)	/* lthuang */
		{
			writereply();
			mode = M_FULL;
			continue;
		}
		if (auto_key == '\0')
			key = igetkey();
		else
		{
			key = auto_key;
			auto_key = '\0';
		}
		switch (key)
		{
		case KEY_UP:
			mode = CAREYUP;
			break;
		case KEY_DOWN:
			mode = CAREYDOWN;
			break;
		case 'e':
		case KEY_LEFT:
			if (menulayer == 1)
			{
				Goodbye();
				mode = M_FULL;
				continue;
			}
			menulayer--;	/* �h�^�W�h��� */
			auto_key = comm[realtotal].key;
			comm = comm[realtotal].comm;
			mode = M_NEW;
			break;
		case '\n':
		case '\r':
		case KEY_RIGHT:
			if (comm[realc[c]].comm)
			{
				comm = comm[realc[c]].comm;	/* �i�J�l��� */
				mode = M_NEW;
				menulayer++;
				continue;
			}
			printxy(0, 54, "%s\033[m", MENU_TITLE_COLOR, comm[realc[c]].chelp);	/* lthuang */
			if (comm[realc[c]].cfunc != Goodbye)	/* lthuang */
			{
				move(2, 0);
				clrtobot();
			}
			update_umode(comm[realc[c]].mode);
			mode = (*(comm[realc[c]].cfunc)) (comm[realc[c]].key);
			update_umode(comm[realtotal].mode);	/* �^�_�U��檺 umode ���A */
			break;
#ifdef USE_MENUSHOW
		case TAB:
			if (!(curuser.flags[1] & PICTURE_FLAG))		
			{
				strncpy(pict_path, msshm->list[pict_no].path, sizeof(pict_path));		
				more(pict_path, TRUE);
				mode = M_NEW;
			}
			break;
#endif
		case CTRL('R'):
			ReplyLastCall();
			mode = M_FULL;
			break;
		default:
			if (isalnum(key))
			{
				for (i = 0; i < total; i++)
					if (key == comm[realc[i]].key)
					{
						RMVCURS;
						c = i;
						PUTCURS;
						break;
					}
			}
			break;
		}
	}			/* while */
}
