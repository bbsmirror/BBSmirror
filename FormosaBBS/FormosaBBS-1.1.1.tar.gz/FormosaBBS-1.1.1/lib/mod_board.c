
#include "bbs.h"


/*******************************************************************
 * �ϥΪ̬O�_�i�ݨ��Y�O�s�b
 *******************************************************************/
int 
can_see_board(bhr, userlevel)
BOARDHEADER *bhr;
unsigned int userlevel;
{
/*
	if (bhr->level >= PERM_BM && userlevel < bhr->level)
		return 0;
*/		
	if ((bhr->brdtype & BRDTYPE_PRIVATE) && userlevel < bhr->level)
		return 0;
	return 1;
}

