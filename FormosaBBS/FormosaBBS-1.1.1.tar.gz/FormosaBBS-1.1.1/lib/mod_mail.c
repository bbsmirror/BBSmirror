
/* FormosaBBS 1.0.0 Multi-Language */

#include "bbs.h"

char _msg_x_disclaimer[] = "�糧�H���e�����t�d";


/**************************************************************
 * �O�_�����X�k�� email address
 **************************************************************/
static int
InvalidEmailAddr(addr)
char *addr;
{
	unsigned char ch, lastch = '\0';
	short mode;

	mode = -1;
	while ((mode <= 0) && (ch = *addr))
	{
		if (ch == '@')
		{
			if (lastch == '\0')
				return 1;
			mode++;
		}
		else if (!isalnum(ch) && !strchr("[].%!:-_<>\"{}", ch))
			return 1;
		lastch = ch;
		addr++;
	}
	if (mode > 0)
		return 1;
	return mode;
}


/**************************************************************
 * �H�H�����W�ϥΪ�
 **************************************************************/
SendMail_Local(fname, from, to, title, ident)
char *fname, *from, *to, *title;
char ident;
{
	USEREC urcTmp;
	char pathTmp[PATHLEN];

	if (get_passwd(&urcTmp, to) <= 0)
		return -1;

	/* Auto-Forward */
	if ((urcTmp.flags[0] & FORWARD_FLAG) && !InvalidEmailAddr(urcTmp.email)
	    && !strstr(urcTmp.email, MYHOSTIP) && !strstr(urcTmp.email, MYHOSTNAME))
	{
		if (SendMail_Internet(-1, fname, from, urcTmp.email, title) == 0)
			return 0;
	}
	setmailfile(pathTmp, to, NULL);
	if (!dashd(pathTmp))
	{
		if (mkdir(pathTmp, 0700) == -1)
			return -1;
	}

/* lasehu */
#ifdef LIMIT_MBOX_NUM
	{
		char dotdir[PATHLEN];
		int total;

		setmailfile(dotdir, to, DIR_REC);
		if ((total = get_num_records(dotdir, FH_SIZE)) >= MAX_KEEP_MAIL)
		{
			bbslog("bbsmail", "<%s> Mailbox full, total [%d]", minfo.name, total);
			return -1;
		}
	}
#endif
#ifdef LIMIT_MAIL_SIZE
	{
		struct stat st;

		if (stat(fname, &st) == 0 && st.st_size > MAX_MAIL_SIZE)
		{
			bbslog("bbsmail", "Mail size [%d] too big, Mail from [%s] to [%s]", st.st_size, minfo.from, minfo.name);
/* lasehu
	return -1;
*/
		}
	}
#endif

	if (append_article(fname, pathTmp, from, title, ident, NULL, FALSE) == -1)
		return -1;
	return 0;
}


/**************************************************************
 * �����P SMTP Port �s��
 **************************************************************/
int
DirectSMTPMail(ms, fname, from, to, title)
int ms;
char *fname, *from, *to, *title;
{
	FILE *fp;
	char gbufTmp[512];

	if (fname != NULL)
	{
		if ((fp = fopen(fname, "r")) == NULL)
			return -1;
	}

	sleep(1);		/* lasehu: wait for mail server response */

	net_printf(ms, "MAIL FROM:<%s>\n", from);
	if (!net_gets(ms, gbufTmp, sizeof(gbufTmp)))
		return -1;
	if (strncmp(gbufTmp, "250 ", 4))
		return -1;
	net_printf(ms, "RCPT TO:<%s>\n", to);
	if (!net_gets(ms, gbufTmp, sizeof(gbufTmp)))
		return -1;
	if (strncmp(gbufTmp, "250 ", 4))
		return -1;
	net_printf(ms, "DATA\n");
	if (!net_gets(ms, gbufTmp, sizeof(gbufTmp)))
		return -1;
	if (strncmp(gbufTmp, "354 ", 4))
		return -1;

	net_printf(ms, "From: %s\n", from);
	net_printf(ms, "To: %-s\n", to);
	net_printf(ms, "Subject: %-s\n", title);
	net_printf(ms, "X-Disclaimer: [%s] %s\n\n", BBSTITLE, _msg_x_disclaimer);
	
	if (fname != NULL)
	{
		while (fgets(gbufTmp, sizeof(gbufTmp), fp))
			net_printf(ms, "%s", gbufTmp);
		fclose(fp);
	}
	
	net_printf(ms, "\n.\n");
	if (!net_gets(ms, gbufTmp, sizeof(gbufTmp)))
		return -1;

	if (strncmp(gbufTmp, "250 ", 4))
		return -1;
	net_printf(ms, "RSET\n");
	if (!net_gets(ms, gbufTmp, sizeof(gbufTmp)))
		return -1;

#ifdef BBSLOG_MAIL
	{
		time_t now;
		int fd;
		char timestr[22];

		time(&now);
		strftime(timestr, sizeof(timestr), "%x %X", localtime(&now));
		sprintf(gbufTmp, "%s %-12.12s %s\n", timestr, from, to);
		if ((fd = open(PATH_MAILLOG, O_APPEND | O_CREAT | O_WRONLY, 0600)) > 0)
		{
			write(fd, gbufTmp, strlen(gbufTmp));
			close(fd);
		}
	}
#endif

	return 0;
}


/**************************************************************
 * �H�H�ܯ��~
 **************************************************************/
SendMail_Internet(ms, fname, from, to, title)
int ms;
char *fname, *from, *to, *title;
{
	int msTmp, result;
	char fromTmp[STRLEN];

	if (ms > 0)
		msTmp = ms;
	else
	{
		if ((msTmp = CreateMailSocket()) < 0)
		{
			return -1;
		}
	}
	if (!strstr(from, MYHOSTNAME) && !strchr(from, '@')) /* lasehu */
		sprintf(fromTmp, "%-s.bbs@%s", from, MYHOSTNAME);
	else
		strcpy(fromTmp, from);
	if (DirectSMTPMail(msTmp, fname, fromTmp, to, title) == -1)
		result = -1;
	else
		result = 0;
	if (ms <= 0)
		CloseMailSocket(msTmp);
	return result;
}


#define SMTPPORT	25

int
CreateMailSocket()		/* open socket to mail server */
{
	char *s[2];
	int ms;
	char buffer[512];

	s[0] = MAILSERVER1;
	ms = ConnectServer(*s, SMTPPORT);
	if (ms < 0)
	{
		s[0] = MAILSERVER2;
		ms = ConnectServer(*s, SMTPPORT);
	}
	if (ms > 0)
	{
		if (!net_gets(ms, buffer, sizeof(buffer)))
		{
			CloseMailSocket(ms);
			return -1;
		}
		if (strncmp(buffer, "220", 3))
		{
			CloseMailSocket(ms);
			return -1;
		}
		if (!strncmp(buffer, "220-", 4))
		{
			if (!net_gets(ms, buffer, sizeof(buffer)))
			{
				CloseMailSocket(ms);
				return -1;
			}
		}
		net_printf(ms, "HELO %s\n", MYHOSTNAME);
		if (!net_gets(ms, buffer, sizeof(buffer)))
		{
			CloseMailSocket(ms);
			return -1;
		}
		if (strncmp(buffer, "250 ", 4))
		{
			CloseMailSocket(ms);
			return -1;
		}
	}
	return ms;
}


int
CloseMailSocket(ms)		/* close socket to mail server */
int ms;
{
	char buffer[512];

	net_printf(ms, "\nQUIT\n");
	net_gets(ms, buffer, sizeof(buffer));
	DisconnectServer(ms);
	return 0;
}
