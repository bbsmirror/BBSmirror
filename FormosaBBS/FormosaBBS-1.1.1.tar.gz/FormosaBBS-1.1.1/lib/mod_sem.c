
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>


static int mysemid;

int
sem_init(key)
key_t key;
{
	int semid;
#if	!defined(LINUX) && !defined(BSD44)
	/* ref. semctl() */
	union semun
	{
		int     val;
		struct semid_ds *buf;
		ushort *array;
	};
#endif
	union semun arg =
	{
		1
	};

	semid = semget(key, 1, 0);
	if (semid == -1)
	{
		semid = semget(key, 1, IPC_CREAT | 0600);
		if (semid == -1)
			attach_err(key, "semget");
		semctl(semid, 0, SETVAL, (union semun)arg);
	}
	return semid;
}


void
sem_lock(semid, op)
int semid;
int op;
{
	struct sembuf sops;

	sops.sem_num = 0;
	sops.sem_flg = SEM_UNDO;
	sops.sem_op = op;
	semop(semid, &sops, 1);
}
