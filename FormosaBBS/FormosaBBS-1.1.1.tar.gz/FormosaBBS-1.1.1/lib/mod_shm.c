/*
 * Shared Memory function
 */

#include "bbs.h"

#include <sys/ipc.h>
#include <sys/shm.h>


void
attach_err(shmkey, name)
int shmkey;
char *name;
{
	fprintf(stderr, "[%s error] key = %d\n", name, shmkey);
	fflush(stderr);
	exit(1);
}


void *
attach_shm(shmkey, shmsize)
key_t shmkey;
int shmsize;
{
	void *shmptr;
	int shmid;

	shmid = shmget(shmkey, shmsize, 0);
	if (shmid < 0)
	{
		shmid = shmget(shmkey, shmsize, IPC_CREAT | 0600);
		if (shmid < 0)
			attach_err(shmkey, "shmget");
		shmptr = (void *) shmat(shmid, NULL, 0);
		if (shmptr == (void *) -1)
			attach_err(shmkey, "shmat");
		memset(shmptr, 0, shmsize);
	}
	else
	{
		shmptr = (void *) shmat(shmid, NULL, 0);
		if (shmptr == (void *) -1)
			attach_err(shmkey, "shmat");
	}
	return (void *) shmptr;
}


struct UTMPFILE *utmpshm = NULL;	/* pointer to user_info shared memory */

#define UTMPSHM_KEY	1218	/* shared memory key, should be unique */

int utmp_semid = 0;

void
resolve_utmp()
{
	if (utmpshm == NULL)
	{
		utmpshm = attach_shm(UTMPSHM_KEY, sizeof(struct UTMPFILE));
		if (!utmpshm->mtime)
		{
			utmpshm->mtime = 1;	/* ? */
			utmpshm->number = 0;
		}
	}
}


USER_INFO *
search_ulist(fptr, farg)
register int (*fptr) ();
register char *farg;
{
	register USER_INFO *uentp;
	register int i;

	resolve_utmp();
	uentp = utmpshm->uinfo;
	for (i = 0; i < USHM_SIZE; i++, uentp++)
	{
		if (uentp->pid <= 2)
			continue;
		if ((*fptr) (farg, uentp))
			return uentp;
	}
	return NULL;
}


int
apply_ulist(fptr)
register int (*fptr) ();
{
	register USER_INFO *uentp;
	register int i;

	resolve_utmp();
	uentp = utmpshm->uinfo;
	for (i = 0; i < USHM_SIZE; i++, uentp++)
	{
		if (uentp->pid <= 2)
			continue;
		if ((*fptr) (uentp) == QUIT_LOOP)
			break;
	}
	return 0;
}


int
ask_online_user()
{
	resolve_utmp();
	return utmpshm->number;
}


void
purge_ulist(upent)
USER_INFO *upent;
{
	sem_lock(utmp_semid, SEM_ENTER);
	
	resolve_utmp();
	if (upent)
		memset(upent, 0, sizeof(USER_INFO));

	if (--utmpshm->number < 0)
		utmpshm->number = 0;	

	sem_lock(utmp_semid, SEM_EXIT);
}


void
update_ulist(cutmp, upent)
USER_INFO *cutmp, *upent;
{
	if (cutmp && upent)
		memcpy(cutmp, upent, sizeof(USER_INFO));
}


USER_INFO *
new_utmp()
{
	USER_INFO *uentp;
	register int i;

	sem_lock(utmp_semid, SEM_ENTER); 

	resolve_utmp();
	uentp = utmpshm->uinfo;
	for (i = 0; i < USHM_SIZE; i++, uentp++)
	{
		if (!uentp->pid)
		{
			uentp->pid = getpid();
			utmpshm->number++;
			time(&utmpshm->mtime);
			sem_lock(utmp_semid, SEM_EXIT); 
			return uentp;
		}
	}
	
	sem_lock(utmp_semid, SEM_EXIT); 
	exit(-1);
}


#define BRDSHM_KEY	2911

struct BRDSHM *brdshm = NULL;	/* pointer to boardheader shared memory */

void
resolve_brdshm()
{
	int fd;
	int n;
	
	if (!brdshm)
	{
		brdshm = attach_shm(BRDSHM_KEY, sizeof(struct BRDSHM));
	}
	
	if (!brdshm->mtime)
	{
		if ((fd = open(BOARDS, O_RDONLY)) > 0)
		{
			n = read(fd, brdshm->brdhr, MAXBOARD * BH_SIZE);
			if (n < 0)
				n = 0;
			else
				n /= BH_SIZE;
			brdshm->number = n;
			time(&brdshm->mtime);

			close(fd);
		}
	}
}


BOARDHEADER *
search_brdshm(fptr, farg)
register int (*fptr) ();
register char *farg;
{
	register BOARDHEADER *bhentp;
	register int i;

	resolve_brdshm();
	bhentp = brdshm->brdhr;
	for (i = 0; i < MAXBOARD; i++, bhentp++)
	{
		if (bhentp->filename[0])
		{
			if ((*fptr) (farg, bhentp))
				return bhentp;
		}
	}
	return NULL;
}


void
apply_brdshm(fptr)
int (*fptr)();
{
	BOARDHEADER *bhentp;
	register int i;

	resolve_brdshm();
	bhentp = brdshm->brdhr;
	for (i = 0; i < brdshm->number; i++, bhentp++)
	{
		if (bhentp->filename[0])
			(*fptr)(bhentp);
	}
}	

		
unsigned int
get_board(bhead, bname)
BOARDHEADER *bhead;
char *bname;
{
	register int i;
	BOARDHEADER *bhentp;

	if (!bname || bname[0] == '\0')
		return 0;
	resolve_brdshm();
	bhentp = brdshm->brdhr;
	for (i = 0; i < brdshm->number; i++, bhentp++)
	{
		if (!strcasecmp(bname, bhentp->filename))
		{
			if (bhead)
				memcpy(bhead, bhentp, BH_SIZE);
			return (i+1);
		}
	}
	return 0;
}
		

void		
rebuild_brdshm()
{
	brdshm->mtime = 0;
	resolve_brdshm();
}


int
cmp_bname(bname, bhentp)
char *bname;
BOARDHEADER *bhentp;
{
	if (bhentp)
	{
		if (!strcmp(bname, bhentp->filename))
			return 1;
	}
	return 0;
}


int
cmp_class(cs1, cs2)
struct class_t *cs1, *cs2;
{
	if (cs1->cn[0] == '+')
	{
		if (cs2->cn[0] == '+')
			return strcasecmp(cs1->cn, cs2->cn);
		return -1;
	}
	else if (cs2->cn[0] == '+')
		return 1;
	return strcasecmp(cs1->bn, cs2->bn);
}	


struct CLASSHM *classhm = NULL;

#define CLASSHM_KEY	1134

int
resolve_classhm()
{
	FILE *fp;
	char img_buf[128], *ptr;
	int i, n, j, len;
	struct class_t *cslist;

	if (!classhm)
	{
		classhm = attach_shm(CLASSHM_KEY, sizeof(struct CLASSHM));
	}

	if (classhm->mtime)
		return 0;
		
	time(&classhm->mtime);
	
	cslist = classhm->cslist;
	for (i = 0; i < CLASS_MAXNUM; i++)
	{
		cslist[i].cn[0] = '\0';
		cslist[i].bn[0] = '\0';
		cslist[i].sibling = NULL;
		cslist[i].child = NULL;
	}

	n = 0;		
	if ((fp = fopen(CLASS_CONFILE, "r")) != NULL)
	{
		while (fgets(img_buf, sizeof(img_buf), fp))
		{
			if (img_buf[0] == '#')
				continue;
			if ((ptr = strchr(img_buf, '\n')) != NULL)
				*ptr = '\0';

			ptr = img_buf;
			while (*ptr == ' ' || *ptr == '\t')
				ptr++;

			if (*ptr != '-' && *ptr != '+')
				continue;
			
			i = 0;
			while (*ptr && *ptr != '.')
				cslist[n].cn[i++] = *ptr++;
			cslist[n].cn[i] = '\0';
				
			if (*ptr != '.')
				continue;
			ptr++;
			
			i = 0;
			if (cslist[n].cn[0] == '-')
			{
				while (*ptr && *ptr != ' ')
					cslist[n].bn[i++] = *ptr++;
			}
			else
			{
				while (*ptr)
					cslist[n].bn[i++] = *ptr++;
			}
			cslist[n].bn[i] = '\0';			
				
			n++;
		}
		fclose(fp);
	}
	
	qsort(cslist, n, sizeof(struct class_t), cmp_class);
	
	for (i = 0; i < n; i++)
	{
		if (cslist[i].cn[0] == '+')
		{
			len = strlen(cslist[i].cn+1);
			for (j = i+1; j < n; j++)
			{
				if (!strncmp(cslist[j].cn+1, cslist[i].cn+1, len)
				    && strlen(cslist[j].cn+1) == len + 1)
				{
					cslist[i].child = &(cslist[j]);
					break;
				}
			}
			if (j == n)
				cslist[i].child = NULL;
		}

		len = strlen(cslist[i].cn+1);		
		for (j = i+1; j < n; j++)
		{
			if (!strncmp(cslist[j].cn+1, cslist[i].cn+1, len-1)
			    && strlen(cslist[j].cn+1) == len)
			{
				cslist[i].sibling = &(cslist[j]);
				break;
			}
		}
		if (j == n)
			cslist[i].sibling = NULL;
	}
	return 1;
}	
	

/*
void		
rebuild_classhm()
{
	classhm->mtime = 0;
	resolve_classhm();
}
*/