
#include "bbs.h"


/* 
 * bname    �O�W
 * fname    ���i�����G�i�ɦW
 * title    ���D
 * ident    �i�K�̪��{�ҵ���
 * tonews   �O�_�e�W news
 * postpath �i�K�ؿ����| (�Y�i�K�b��ذ�)
 *
 */
int
PublishPost(fname, userid, bname, title, ident, fromhost, tonews, postpath)
char *fname, *userid, *bname, *title, *fromhost, *postpath;
char ident;
short tonews;
{
	char timestamp[14];
	int artno;
	char buffer[512], tempfile[PATHLEN], pathTmp[PATHLEN];
	int artmode;


	sprintf(tempfile, "tmp/bbs%05d", getpid());
	mycp(fname, tempfile);
	if (fromhost)
	{
#if HAVE_IDENT
		sprintf(buffer, "\n--\n* Origin: %s * From: %s [%s�q�L�{��]\n",
			BBSNAME, fromhost, (ident == 7) ? "�w" : "��");
#else
		sprintf(buffer, "\n--\n* Origin: %s * From: %s\n", BBSNAME, fromhost);
#endif
		if (append_record(tempfile, buffer, strlen(buffer)) == -1)
		{
			unlink(tempfile);
			return -1;
		}
	}
	if (postpath)
		strcpy(pathTmp, postpath);
	else
		setboardfile(pathTmp, bname, NULL);

	if ((artno = append_article(tempfile, pathTmp, userid, title, ident, 
	                            timestamp, (postpath) ? FALSE : TRUE)) == -1)
	{
		unlink(tempfile);
		return -1;
	}

	if (!postpath)
	{
#if EMAIL_LIMIT
		if (ident != 7)
		{
			unlink(tempfile);
			return artno;
		}
		else
#endif
		{
			if (tonews)
				append_news(bname, timestamp, 'S');
		}
		if (artno == 1)
			rewind_board(bname);
	}
	unlink(tempfile);
	return artno;
}
