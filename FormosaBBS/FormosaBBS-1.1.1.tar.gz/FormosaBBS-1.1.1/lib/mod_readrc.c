
#include "bbs.h"


unsigned int rrc_changed = FALSE;
struct readrc rrc_buf, myrrc;
short new_visit = FALSE;

char fname_readrc[PATHLEN];
char currentuserid[IDLEN + 2] = "\0";

#define RRC_SIZE    sizeof(struct readrc)
#define RRC_EXPTIME (10*86400)


void
ReadRC_Update()
{
	time_t now;
	char fn_new[PATHLEN];
	short found, fail = FALSE;
	int fdr, fdw;

	if (currentuserid[0] == '\0')
		return;
#ifdef GUEST_ACCOUNT
	if (!strcmp(currentuserid, GUEST_ACCOUNT))
		return;
#endif
	if (!rrc_changed)
		return;

	sethomefile(fname_readrc, currentuserid, UFNAME_READRC);
	sprintf(fn_new, "%s.new", fname_readrc);
	if ((fdr = open(fname_readrc, O_RDWR | O_CREAT, 0644)) > 0)
	{
		if ((fdw = open(fn_new, O_WRONLY | O_CREAT, 0644)) > 0)
		{
			found = FALSE;
			time(&now);
			while (read(fdr, &rrc_buf, RRC_SIZE) == RRC_SIZE)
			{
				if (!found)
				{
					if (rrc_buf.bid == myrrc.bid)
					{
						found = TRUE;
						if (write(fdw, &myrrc, RRC_SIZE) != RRC_SIZE)
						{
							fail = TRUE;
							break;
						}
						continue;
					}
				}
				if (rrc_buf.mtime >= now - RRC_EXPTIME)
				{
					if (write(fdw, &rrc_buf, RRC_SIZE) != RRC_SIZE)
					{
						fail = TRUE;
						break;
					}
				}
			}
			if (!found)
			{
				if (write(fdw, &myrrc, RRC_SIZE) != RRC_SIZE)
					fail = TRUE;
			}
			close(fdw);
		}
		close(fdr);
	}
	rrc_changed = FALSE;

	if (!fail)
	{
		if (myrename(fn_new, fname_readrc) == -1)
			fail = -1;
	}
	if (fail)
		unlink(fn_new);
}


void
ReadRC_Expire()
{
	time_t now;
	char fn_new[PATHLEN];
	short fail = FALSE, update = FALSE;
	int fdr, fdw;

	if (!currentuserid[0])
		return;
	sethomefile(fname_readrc, currentuserid, UFNAME_READRC);
	sprintf(fn_new, "%s.new", fname_readrc);
	if ((fdr = open(fname_readrc, O_RDWR | O_CREAT, 0644)) > 0)
	{
		if ((fdw = open(fn_new, O_WRONLY | O_CREAT, 0644)) > 0)
		{
			time(&now);
			while (read(fdr, &rrc_buf, RRC_SIZE) == RRC_SIZE)
			{
				if (rrc_buf.mtime >= now - RRC_EXPTIME)
				{
					if (write(fdw, &rrc_buf, RRC_SIZE) != RRC_SIZE)
					{
						fail = TRUE;
						break;
					}
				}
				else
					update = TRUE;
			}
			close(fdw);
		}
		close(fdr);
		if (!fail && update)
		{
			if (myrename(fn_new, fname_readrc) == -1)
				fail = -1;
		}
		if (fail)
			unlink(fn_new);
	}
}


void
ReadRC_Init(boardname, bid, userid)
char *boardname;
unsigned int bid;
char *userid;
{
	int fd;

	if (bid < 0)
		return;
	if (myrrc.bid == bid)
		return;

	strncpy(currentuserid, userid, IDLEN);
	currentuserid[IDLEN + 1] = '\0';

	new_visit = FALSE;		/* lasehu */

	ReadRC_Update();

	sethomefile(fname_readrc, currentuserid, UFNAME_READRC);
	if ((fd = open(fname_readrc, O_RDONLY)) > 0)
	{
		while (read(fd, &rrc_buf, RRC_SIZE) == RRC_SIZE)
		{
			if (rrc_buf.bid == bid)
			{
				memcpy(&myrrc, &rrc_buf, RRC_SIZE);
				close(fd);
				new_visit = TRUE;
				return;
			}
		}
		close(fd);
	}
	memset(&myrrc, 0, RRC_SIZE);
	myrrc.bid = bid;
	myrrc.mtime = time(0);

	new_visit = TRUE;	/* lasehu */
}


unsigned char rrc_readbit;
int rrc_readid;

void
ReadRC_Addlist(artno)
int artno;
{

	if (artno <= 0 || artno > BRC_REALMAXNUM)
		return;

	mymod(artno, BRC_MAXNUM, &rrc_readid, &rrc_readbit);
	myrrc.rlist[rrc_readid] |= rrc_readbit;
	rrc_changed = TRUE;
}


int
ReadRC_UnRead(artno)
int artno;
{
	mymod(artno, BRC_MAXNUM, &rrc_readid, &rrc_readbit);
	return (myrrc.rlist[rrc_readid] & rrc_readbit) ? 0 : 1;
}


#define DIRECTION_INC	1
#define DIRECTION_DEC	0


static void
ReadRC_Mod(no, max, rbyte, rbit, direction)
unsigned int no;
int max, *rbyte;
unsigned char *rbit;
int direction;
{
	unsigned char onebit = 0x1;
	int shift;

	shift = (no - 1) % 8;
	onebit = onebit << shift;
	*rbit = onebit;
	if (direction == DIRECTION_INC)
		shift = 7 - shift;
	while (shift--)
	{
		if (direction == DIRECTION_INC)
			onebit = onebit << 1;
		else if (direction == DIRECTION_DEC)
			onebit = onebit >> 1;
		*rbit |= onebit;
	}
	*rbit &= ~(*rbit);
	*rbyte = ((no - 1) / 8) % max;
}


static void
ReadRC_Clean(startno, endno)
int startno, endno;
{
	int size;
	int startbyte, endbyte;
	unsigned char startbit, endbit;
	unsigned char oribit;

	ReadRC_Mod(startno, BRC_MAXNUM, &startbyte, &startbit, DIRECTION_INC);
	ReadRC_Mod(endno, BRC_MAXNUM, &endbyte, &endbit, DIRECTION_DEC);
	size = endbyte - startbyte;
	if (size >= 1)
	{
		memcpy(&oribit, myrrc.rlist + startbyte, 1);
		oribit &= (~startbit);
		startbit |= oribit;
		memset(myrrc.rlist + startbyte, startbit, 1);

		if (size >= 2)
			memset(myrrc.rlist + startbyte + 1, 0, size - 1);

		memcpy(&oribit, myrrc.rlist + endbyte, 1);
		oribit &= (~endbit);
		endbit |= oribit;
		memset(myrrc.rlist + endbyte, endbit, 1);

		myrrc.mtime = time(0);
		if (!new_visit)
			rrc_changed = TRUE;
	}
}


void
ReadRC_Refresh(boardname, rewind_time, firstartno)
char *boardname;
time_t rewind_time;
int firstartno;
{
	time_t new_rtime;
	int lastno, firstno;
	int total;
	char fname[STRLEN];
	FILEHEADER gfhbuf;

	new_rtime = rewind_time;
	if (new_rtime < 0)
		new_rtime = 0;
	if (myrrc.mtime < new_rtime)
	{
		memset(myrrc.rlist, 0, (BRC_MAXNUM / 2));
		myrrc.mtime = new_rtime;
		rrc_changed = 1;
	}
	setboardfile(fname, boardname, DIR_REC);
	total = get_num_records(fname, FH_SIZE);
	firstno = firstartno;	/* lasehu */
	if (firstno < 0)
	{
		if (get_record(fname, &gfhbuf, FH_SIZE, 1) == 0)
			firstno = gfhbuf.artno;
		else
			firstno = 1;
	}
	if (get_record(fname, &gfhbuf, FH_SIZE, total) == 0)
		lastno = gfhbuf.artno;
	else
		lastno = firstno;

	if (firstno >= 1 && firstno <= BRC_REALMAXNUM
	    && lastno >= 1 && lastno <= BRC_REALMAXNUM)
	{
		if (firstno > lastno)
		{
			ReadRC_Clean(lastno + 1, firstno - 1);
		}
		else
		{
			if (firstno > 1)
				ReadRC_Clean(1, firstno - 1);
			if (lastno < BRC_REALMAXNUM)
				ReadRC_Clean(lastno + 1, BRC_REALMAXNUM);
		}
	}
}


void
ReadRC_Visit(boardname, bid, userid, bitset)
char *boardname;
unsigned int bid;
char *userid;
int bitset;
{
	ReadRC_Init(boardname, bid, userid);
	if (bitset)
	{
		myrrc.mtime = time(0);	
		memset(myrrc.rlist, 0xFF, BRC_MAXNUM);
	}
	else
	{
		myrrc.mtime = 0;
		memset(myrrc.rlist, 0x00, BRC_MAXNUM);
	}
	

	if (!new_visit)
		rrc_changed = TRUE;
}