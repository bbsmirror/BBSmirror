/*
   BBS Library 
*/    

#include "bbs.h"



#ifdef SYSV
int
flock(fd, op)
int fd, op;
{
	switch (op)
	{
	case LOCK_EX:
		return lockf(fd, F_LOCK, 0);
	case LOCK_UN:
		return lockf(fd, F_ULOCK, 0);
	default:
		return -1;
	}
}
#endif


/*******************************************************************
 * �����ɮ� - �|�N�ت����|�R��
 *******************************************************************/
mycp(from, to)
char *from, *to;
{
	char cpbuf[8192];	/* copy buffer size: 8192 */
	int fdr, fdw, cc;

	if ((fdr = open(from, O_RDONLY)) > 0)
	{
		if ((fdw = open(to, O_WRONLY | O_CREAT | O_TRUNC, 0644)) > 0)
		{
			while ((cc = read(fdr, cpbuf, sizeof(cpbuf))) > 0)
				write(fdw, cpbuf, cc);
			close(fdw);
			close(fdr);
			return 0;
		}
		close(fdr);
	}
	return -1;
}


/*******************************************************************
 * �R���ɮשΥؿ�
 *******************************************************************/
myunlink(name)
char name[];
{
	DIR *dirp;
#if defined(NO_DIRENT)
	struct direct *dirlist;
#else
	struct dirent *dirlist;
#endif
	char path[MAXNAMLEN], *s;
	struct stat st;

	if (!name || name[0] == '\0' || stat(name, &st) == -1)
		return -1;
	if (!S_ISDIR(st.st_mode))
	{
		unlink(name);
		return 0;
	}
	if ((dirp = opendir(name)) == NULL)
		return -1;
	sprintf(path, "%s/", name);
	s = path + strlen(path);;
	readdir(dirp);
	readdir(dirp);
	while ((dirlist = readdir(dirp)) != NULL)
	{
		if (dirlist->d_name[0])
		{
			strcpy(s, dirlist->d_name);
			if (stat(path, &st) == 0)
			{
				if (S_ISDIR(st.st_mode))
					myunlink(path);
				else
					unlink(path);
			}
		}
	}
	closedir(dirp);
	*(--s) = '\0';
	if (rmdir(path) == -1)
		return -1;
	return 0;
}


/*
 * rename() but support cross different file system
 */
myrename(from, to)
const char *from, *to;
{
	if (rename(from, to) == -1)	/* �p�G rename() ���� */
	{
		/* ���ܤ��P filesystem, �A�� mycp() */
		if (mycp(from, to) == -1)
			return -1;
		unlink(from);
	}
	return 0;
}


void
sethomefile(buf, userid, filename)
char *buf, *userid, *filename;
{
	unsigned char c;

	c = userid[0];
	if (isupper(c))
		c = tolower(c);
	else if (!islower(c))
		c = '0';
	if (filename == NULL)
		sprintf(buf, "home/%c/%s", c, userid);
	else
		sprintf(buf, "home/%c/%s/%s", c, userid, filename);
}


void
setuserfile(buf, userid, filename)
char *buf, *userid, *filename;
{
	sprintf(buf, "%s/%s", filename, userid);
}


void
setboardfile(buf, bname, filename)
char *buf, *bname, *filename;
{
	if (filename)
		sprintf(buf, "%s/%s/%s", BBSPATH_BOARDS, bname, filename);
	else
		sprintf(buf, "%s/%s", BBSPATH_BOARDS, bname);
}


void
settreafile(buf, bname, filename)
char *buf, *bname, *filename;
{
	if (filename)
		sprintf(buf, "%s/%s/%s", BBSPATH_TREASURE, bname, filename);
	else
		sprintf(buf, "%s/%s", BBSPATH_TREASURE, bname);
}


void
setmailfile(buf, userid, filename)
char *buf, *userid, *filename;
{
	unsigned char c;

	c = userid[0];
	if (isupper(c))
		c = tolower(c);
	else if (!islower(c))
		c = '0';
	if (filename == NULL)
		sprintf(buf, "%s/%c/%-s", UFNAME_MAIL, c, userid);
	else
		sprintf(buf, "%s/%c/%-s/%s", UFNAME_MAIL, c, userid, filename);
}


/*******************************************************************
 * �b���w���ؿ��U���o�ߤ@�� M.xxxxxxxx.? �ɦW
 *******************************************************************/
void
get_only_name(dir, fname)
char dir[], fname[];
{
	char *t, tmpbuf[256];
	int fd;

	sprintf(fname, "M.%d.A", time(0));
	t = fname + strlen(fname) - 1;
	sprintf(tmpbuf, "%-s/%-s", dir, fname);
	while ((fd = open(tmpbuf, O_RDONLY)) != -1)
	{
		close(fd);
		if (*t == 'Z')
		{
			*(++t) = 'A';
			*(t + 1) = '\0';
		}
		else
			(*t)++;
		sprintf(tmpbuf, "%-s/%-s", dir, fname);
	}
	if ((fd = open(tmpbuf, O_WRONLY | O_CREAT, 0644)) != -1)
		close(fd);
}


int
append_news(board, fname, option)
char *board, *fname, option;
{
	FILE *fp;
	char nbuf[PATHLEN], bbuf[PATHLEN];

	sprintf(nbuf, "news/output/%-s", board);
	if ((fp = fopen(nbuf, "a+")) == NULL)
		return -1;
	flock(fileno(fp), LOCK_EX);
	if (option == 'D')
		fprintf(fp, "-%-s\n", fname);
	else
		fprintf(fp, "%-s\n", fname);
	flock(fileno(fp), LOCK_UN);
	fclose(fp);
	if (option == 'D')
	{
		sprintf(nbuf, "news/cancel/%-s.%-s", board, fname);
		setboardfile(bbuf, board, fname);
		mycp(bbuf, nbuf);	/* lthuang */
	}
	return 0;
}


int
dashf(fname)
char *fname;
{
	struct stat st;

	return (stat(fname, &st) == 0 && S_ISREG(st.st_mode));
}


int
dashd(fname)
char *fname;
{
	struct stat st;

	return (!stat(fname, &st));
}


void
close_all_ftable()
{
	int fd = getdtablesize();

	while (fd)
		(void) close(--fd);
}


#include <varargs.h>

void
bbslog(mode, va_alist)
char *mode;

va_dcl
{
	va_list args;
	time_t now;
	int fd;
	char msgbuf[128], buf[128], *fmt;
	char timestr[22];

	va_start(args);
	fmt = va_arg(args, char *);
	vsprintf(msgbuf, fmt, args);
	va_end(args);

	time(&now);
	strftime(timestr, sizeof(timestr), "%x %X", localtime(&now));

	sprintf(buf, "%s %.10s: %s\n", timestr, mode, msgbuf);
	if ((fd = open(PATH_BBSLOG, O_APPEND | O_CREAT | O_WRONLY, 0600)) > 0)
	{
		write(fd, buf, strlen(buf));
		close(fd);
	}
}


int
rewind_board(bname)
char *bname;
{
	int fd;
	BOARDHEADER sbh;

	if ((fd = open(BOARDS, O_RDWR)) > 0)
	{
		flock(fd, LOCK_EX);
		while (read(fd, &sbh, sizeof(sbh)) == sizeof(sbh))
		{
			if (strcmp(sbh.filename, bname))
				continue;
			sbh.rewind_time = time(0);
			if (lseek(fd, -((off_t) sizeof(sbh)), SEEK_CUR) != -1)
			{
				if (write(fd, &sbh, sizeof(sbh)) == sizeof(sbh))
				{
					flock(fd, LOCK_UN);
					close(fd);
					return 0;
				}
			}
			break;
		}
		flock(fd, LOCK_UN);
		close(fd);
	}
	return -1;
}


int
get_only_artno(dotdir)
char *dotdir;
{
	int fd;
	int number = 1;

	if ((fd = open(dotdir, O_RDONLY)) > 0)
	{
		FILEHEADER lastf;
		struct stat st;

		fstat(fd, &st);
		if ((st.st_size % FH_SIZE == 0) && st.st_size > FH_SIZE)
			lseek(fd, st.st_size - FH_SIZE, SEEK_SET);
		if (read(fd, &lastf, sizeof(lastf)) == sizeof(lastf))
		{
			if (lastf.artno >= BRC_REALMAXNUM)
				number = 1;	/* reset the artno. */
			else if (lastf.artno > 0)
				number = lastf.artno + 1;
		}
		close(fd);
	}
	return number;
}


void
mymod(id, maxu, pp, qq)		/* pp: readid, qq: readbit */
unsigned int id;
int maxu, *pp;
unsigned char *qq;
{
	*pp = (id - 1) % 8;
	*qq = 0x1;
	*qq = *qq << *pp;
	*pp = ((id - 1) / 8) % maxu;
}


void
init_bbsenv()
{
	if (chdir(HOMEBBS) == -1)
	{
		fprintf(stderr, "\ncannot chdir: %s", HOMEBBS);
		fflush(stderr);
		exit(-2);
	}
	if (getuid() != BBS_UID)
	{
#ifdef CHROOT_BBS	
		if (chroot(HOMEBBS) == -1 || chdir("/") == -1)
		{
			fprintf(stderr, "\ncannot chroot: %s\n", HOMEBBS);
			fflush(stderr);
			exit(-1);
		}
#endif		
		if (setgid(BBS_GID) == -1 || setuid(BBS_UID) == -1)
		{
			fprintf(stderr, "\nplease run this program in bbs!\n");
			fflush(stderr);
			exit(-1);
		}
	}
}


/*
   host_deny  - �ˬd�ϥΪ̨ӳB, �Ǧ^ 0 ���� allow, 1 ���� deny
*/

struct HostDeny {
	char *host;
	short len;
};

struct HostDeny *host_deny_init(fname)
char *fname;
{
	FILE *fp;
	struct HostDeny *table = (struct HostDeny *) NULL;

	if(fp = fopen(fname, "r"))
	{
		char genbuf[80], *buf, *p1, *p2, *hosts;
		short i = 0, num;

		p2 = buf = (char *) malloc(4096);
		p1 = genbuf;
		memset(buf, 0, 4096);
		memset(genbuf, 0, sizeof(genbuf));
		while(fgets(genbuf, sizeof(genbuf), fp))
		{
			if(*genbuf == '#' || *genbuf == '\n')
				continue;
			while(*p1 && (*p1 < '0' || *p1 > '9'))
				p1++;
			if(*p1)
			{
				i++;
				while((*p1 >= '0' && *p1 <= '9') || *p1 == '.' || *p1 == '*')
					*p2++ = *p1++;
				*p2++ = '\n';
			}
			memset(genbuf, 0, sizeof(genbuf));
			p1 = genbuf;
		}
		num = i;
		table = (struct HostDeny *) malloc((++i)*sizeof(struct HostDeny));
		memset(table, 0, i*sizeof(struct HostDeny));
		i = strlen(buf);
		hosts = (char *) malloc(++i);
		memset(hosts, 0, i);
		strcpy(hosts, buf);
		free(buf);
		for(i = 0, p1 = hosts; i < num; i++)
		{
			table[i].host = p1;
			p1 = strchr(p1, '\n');
			if(*(p1 - 1) == '*')
				table[i].len = p1 - table[i].host - 1;
			*p1++ = '\0';
		}
		fclose(fp);
	}
	return table;
}


static struct HostDeny *dhost = (struct HostDeny *)NULL;
static struct HostDeny *ahost = (struct HostDeny *)NULL;
static struct HostDeny hostnull[1];

int host_deny(host)
char *host;
{
	int deny_login = 0;

	if(ahost)
	{
		short i;

		if(ahost[0].host)
		{/* �Y host.allow �s�b�A�� deny all */
			deny_login++;	/* deny all */
			for(i = 0; ahost[i].host; i++)
			{
				if(ahost[i].len)
				{
					if(!strncmp(ahost[i].host, host, ahost[i].len))
					{
						deny_login = 0;
						break;
					}
				}
				else
				{
					if(!strcmp(ahost[i].host, host))
					{
						deny_login = 0;
						break;
					}
				}
			}
		}
		if(dhost[0].host && !deny_login)
		{
			for(i = 0; dhost[i].host; i++)
			{
				if(dhost[i].len)
				{
					if(!strncmp(dhost[i].host, host, dhost[i].len))
					{
						deny_login++;
						break;
					}
				}
				else
				{
					if(!strcmp(dhost[i].host, host))
					{
						deny_login++;
						break;
					}
				}
			}
		}
	}
	else
	{
		memset(hostnull, 0, sizeof(hostnull));
		ahost = host_deny_init(HOST_ALLOW);
		if(!ahost)
			ahost = hostnull;
		dhost = host_deny_init(HOST_DENY);
		if(!dhost)
			dhost = hostnull;
	}
	return deny_login;
}


void
setdotfile(buf, dotfile, fname)
char *buf, *dotfile, *fname;
{
	register char *ptr;

	strcpy(buf, dotfile);
	if ((ptr = strrchr(buf, '/')) == NULL)
	{
		bbslog("ERROR", "setdotfile: (%s) (%s)", dotfile, fname);
		return;
	}
	while (ptr > buf && *(ptr - 1) == '/')
		*ptr-- = '\0';
	if (fname == NULL)
		*(ptr + 1) = '\0';
	else
		strcpy(ptr + 1, (fname[0] == '/') ? fname + 1 : fname);
}


/*ARGUSED*/
int
append_file(afile, rfile)
char *afile, *rfile;
{
	size_t size;
	char buf[512];
	int fdr, fdw;
	
	if ((fdr = open(rfile, O_RDONLY)) < 0)
		return -1;
	if ((fdw = open(afile, O_WRONLY | O_APPEND | O_CREAT, 0600)) < 0)
	{
		close(fdr);
		return -1;
	}
	while((size = read(fdr, buf, sizeof(buf))) > 0)
	{
		if (write(fdw, buf, size) != size)
		{
			close(fdr);
			close(fdw);
			return -1;
		}
	}
	close(fdr);
	close(fdw);
	return 0;
}


int
seek_in_file(filename, seekstr)
char filename[], seekstr[];
{
	FILE *fp;
	char buf[STRLEN];
	char *ptr;

	if ((fp = fopen(filename, "r")) != NULL)
	{
		while (fgets(buf, sizeof(buf), fp))
		{
			if ((ptr = strchr(buf, '\n')) == NULL)	/* debug */
				continue;
			if ((ptr = strchr(buf, '#')))
				*ptr = '\0';
			if (buf[0] == '\0')
				continue;
			if ((ptr = strtok(buf, ": \n\r\t")) && !strcmp(ptr, seekstr))
			{
				fclose(fp);
				return 1;
			}
		}
		fclose(fp);
	}
	return 0;
}


int
is_emailaddr(to)
char *to;
{
	register char *ptr;

	if (!(ptr = strchr(to, '@')))
		return 0;
	if (!strcmp(ptr + 1, MYHOSTNAME) || !strcmp(ptr + 1, MYHOSTIP))
	{
		/* userid@mymachine, consider as internet email */
		*ptr = '\0';
		if ((ptr = strchr(to, '.')))
		{
			*ptr = '\0';
			return 0;
		}
	}
	return 1;
}


/*
  Note: 
       s2 is a multi-string, seprated by tab character,
       whether s1 is found in s2 
*/       
int
match_in_multistr(s1, s2)
register char *s1, *s2;
{
	register char *foo;
	register char *st;
	register int len;
	
	if (*s2 == '\0')
		return 0;
	st = s2;
	while (1)
	{
		if ((foo = strchr(st, '\t')) == NULL)
			len = strlen(st);
		else
			len = foo - st;
	
		if (!strncmp(s1, st, len))
			return 1;
		st = st + len;
		if (*st == '\0')
			break;
		st++;
	}
	return 0;
}


/*
   xstrncpy() - similar to strncpy(3) but terminates string
   always with '\0' if n != 0, and doesn't do padding
*/
char *
xstrncpy(char *dst, const char *src, size_t n)
{
    if (n == 0)
		return dst;
    if (src == NULL)
		return dst;
    while (--n != 0 && *src != '\0')
		*dst++ = *src++;
    *dst = '\0';
    return dst;
}


int
xgrep(pattern, filename)
char *pattern, *filename;
{
	FILE *fp;
	char buf[512];
	char *ptr;


	if ((fp = fopen(filename, "r")) != NULL)
	{
		while (fgets(buf, sizeof(buf), fp))
		{
			if ((ptr = strchr(buf, '\n')) == NULL)	/* debug */
				continue;
			if ((ptr = strchr(buf, '#')))
				*ptr = '\0';
			if (buf[0] == '\0')
				continue;
			if ((ptr = strtok(buf, ": \n\r\t")) && strstr(pattern, ptr))
			{
				fclose(fp);
				return 1;
			}
		}
		fclose(fp);
	}
	return 0;
}


int
invalid_userid(userid)
char *userid;
{
	char buf[IDLEN + 1];
	int i;
	unsigned char ch;


	if (!userid || userid[0] == '\0')
		return 1;
	i = strlen(userid);
	if (i < LEAST_IDLEN || i > IDLEN)
		return 1;
	for (i = 0; i < sizeof(buf) && (ch = userid[i]); i++)
	{
		if (!isalpha(ch))
			return 1;
		buf[i] = tolower(ch);
	}
	buf[i] = '\0';
	if (!strcmp(buf, "new") || strstr(buf, "sysop")
	    || xgrep(buf, BADUSERID))
	{
		return 1;
	}
	return 0;
}
