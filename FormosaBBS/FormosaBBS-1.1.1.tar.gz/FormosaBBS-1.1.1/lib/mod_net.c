 
/* FormosaBBS 1.0.0 */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <varargs.h>

#include <netdb.h>

/* for connect() function call */
#include <sys/types.h>
#include <sys/socket.h>

/* for inet_addr() function call */
#include <netinet/in.h>
#include <arpa/inet.h>

#ifdef AIX
#include <sys/select.h>
#endif

#include <sys/time.h>

#include "bbs.h"


#define NET_IOTIMEOUT	600
#ifndef MAXBSIZE
#define MAXBSIZE	8192
#endif


/*
 * �إ� socket connect �� host �� port
 * example: SocketID = ConnectServer("140.117.11.2", CHATPORT)
 */
int
ConnectServer(host, port)
char *host;			/* �`�N�o�ӰѼƸ��¨禡���P */
int port;
{
	struct sockaddr_in sin;
	int s;

	if (!host || !(*host))
		return -1;
	memset(&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_port = htons((u_short) port);

	/* check host is ip address or hostname */
	if (*host < '0' || *host > '9')
	{
		struct hostent *phe;

		if ((phe = gethostbyname(host)))
			memcpy((char *) &sin.sin_addr, phe->h_addr, phe->h_length);
		else
			return -1;
	}
	else
		sin.sin_addr.s_addr = inet_addr(host);

	/* alloc a socket */
	/* here only support SOCK_STREAM */
	if ((s = socket(PF_INET, SOCK_STREAM, 0)) < 0)
		return -1;

	/* connect the socket to server port */
	if (connect(s, (struct sockaddr *) &sin, sizeof(sin)) < 0)
		return -1;
	else
		return s;
}


void
DisconnectServer(s)		/* lasehu */
int s;
{
/*     shutdown(s, 2) */
	close(s);
}




/***************************************************************
 * send out messages with the customed format
 * �� printf �Ϊk�ۦP, �u�O output �� socket
 ***************************************************************/
net_write(sd, buf, nbytes)
int sd;
char *buf;
int nbytes;
{
	int bytes_written;

	if ((bytes_written = write(sd, buf, nbytes)) == -1)
		return 0;
	return (bytes_written);
}


/***************************************************************
 * send out messages with the customed format
 * �� printf �Ϊk�ۦP, �u�O output �� socket
 ***************************************************************/
net_printf(sd, format, va_alist)
int sd;
char *format;

va_dcl
{
	va_list args;
	char str[MAXBSIZE];

	va_start(args);
	vsprintf(str, format, args);
	va_end(args);

	return (net_write(sd, str, strlen(str)));
}


/*****************************************************************
 * �q socket Ū�J�@��, �J��s��r������.
 * �Ѽ� newline : 1 --> ��s��r���d�b�r���.
 *                0 --> �h���s��r��.
 *****************************************************************/

static char ibuf[4096];
static char *begin = ibuf, *to = ibuf;

char *
net_gets(sd, buf, buf_size)
int sd;
char buf[];
int buf_size;
{
	struct timeval wait;
	static fd_set ibits;
	int times, cc, maxs = sd + 1;
#ifdef LINUX	
	int imp;
#endif	
	char *w = buf, *we = buf + buf_size, *p;
	

	wait.tv_sec = NET_IOTIMEOUT;
	wait.tv_usec = 0;
	if (begin != to)
	{
		for (; begin < to && w < we; w++, begin++)
		{
			*w = *begin;
			if (*w == '\n')
			{
				begin++;
				if (w > buf && *(w - 1) == '\r')
				{
					*w-- = '\0';
					*w = '\n';
				}
				else
					*(++w) = '\0';
				return buf;
			}
		}
		if (w == we)
		{
			*w = '\0';
			if ((p = strchr(begin, '\n')))
				begin = ++p;
			else
				begin = to = ibuf;
			return buf;
		}
	}
	begin = to = ibuf;
#ifdef LINUX	
	imp = 0;
#endif	
	for (times = 0; times < 256; times++)
	{
		FD_ZERO(&ibits);
		FD_SET(sd, &ibits);
		if ((cc = select(maxs, &ibits, 0, 0, &wait)) < 1)
		{
			if (cc < 0 && errno == EINTR)
				continue;
			begin = to = ibuf;
			*buf = '\0';
			return (char *) NULL;
		}
#if defined(LINUX)
		else if(imp++ > IMPOSSIBLE_NUMBER)
			exit(1);
#endif
		if (!FD_ISSET(sd, &ibits))
			continue;
/* lasehu			
		memset(ibuf, '\0', sizeof(ibuf));
*/		
		ibuf[0] = '\0';
/* lasehu
		if ((cc = read(sd, ibuf, sizeof(ibuf))) < 1)
*/		
		if ((cc = read(sd, ibuf, sizeof(ibuf)-1)) < 1)
		{
			begin = to = ibuf;
			*buf = '\0';
			return (char *) NULL;
		}
		
		for (to += cc, *to = '\0'; begin < to && w < we; w++, begin++)
		{
			*w = *begin;
			if (*w == '\n')
			{
				begin++;
				if (w > buf && *(w - 1) == '\r')
				{
					*w-- = '\0';
					*w = '\n';
				}
				else
					*(++w) = '\0';
				return buf;
			}
		}
		if (w == we)
		{
			*w = '\0';
			if ((p = strchr(begin, '\n')))
				begin = ++p;
			else
				begin = to = ibuf;
			return buf;
		}
		else
			begin = to = ibuf;
	}
	begin = to = ibuf;
	*buf = '\0';
	return (char *) NULL;
}
