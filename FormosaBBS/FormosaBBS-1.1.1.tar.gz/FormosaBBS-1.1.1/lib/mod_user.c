
/* FormosaBBS 1.0.0 */

/* dependency: sethomefile */

#include "bbs.h"


/*
 * ���o�ϥΪ̸��
 */
unsigned int
get_passwd(urcp, userid)
USEREC *urcp;
char *userid;
{
	int fd;
	char fn_passwd[PATHLEN];
	USEREC urcTmp, *u = (urcp) ? urcp : &urcTmp;

/* �Y urcTmp �� NULL, �h�u�d�� userid �O�_�s�b */


	if (userid == NULL || userid[0] == '\0')
		return 0;
	sethomefile(fn_passwd, userid, UFNAME_PASSWDS);
	if ((fd = open(fn_passwd, O_RDONLY)) > 0)
	{
		if (read(fd, u, sizeof(USEREC)) == sizeof(USEREC))
			{
				close(fd);
				return u->uid;
			}
		close(fd);
	}
	return 0;
}


/*
 * ���ϥΪ̪����
 *
 */
unsigned int
update_user(urcp)
USEREC *urcp;
{
	int fd;
	char fn_passwd[PATHLEN];
	USEREC urcTmp;


	if (urcp == NULL || urcp->userid[0] == '\0')
		return 0;
	sethomefile(fn_passwd, urcp->userid, UFNAME_PASSWDS);
	if ((fd = open(fn_passwd, O_RDWR)) > 0)
	{
		flock(fd, LOCK_EX);	/* �ѩ�@�ΨϥΪ̸��, ���T�O�g�J���T */
			if (write(fd, urcp, sizeof(USEREC)) == sizeof(USEREC))
			{
				flock(fd, LOCK_UN);
				close(fd);
				return urcp->uid;
			}
		flock(fd, LOCK_UN);
		close(fd);
	}
	return 0;
}


/*
 * ���ϥΪ̪�����`�� PASSFILE
 */
unsigned int
update_user_passfile(urcp)
USEREC *urcp;
{
	int fd;

	if (urcp == NULL || urcp->userid[0] == '\0')
		return -1;

	if ((fd = open(PASSFILE, O_WRONLY | O_CREAT, 0600)) > 0)
	{
/* �٥h lock �ʧ@, �[�ֳB�z */
		if (lseek(fd, (off_t) ((urcp->uid - 1) * sizeof(USEREC)), SEEK_SET) != -1)
		{
			if (write(fd, urcp, sizeof(USEREC)) == sizeof(USEREC))
			{
				close(fd);
				return 0;
			}
		}
		close(fd);
	}
	return -1;
}


/*******************************************************************
 * ���U�@��ϥΪ�
 * �Ѽ�: ubuf -> if NULL, ���d�@�ӪŦ�N�n
 *               else �N�s user ��� (ubuf) �g�J���e���Ŧ�
 * �Ǧ^: �ϥΪ̽s�� (unsigned int).
 *******************************************************************/
unsigned int
new_user(ubuf)
USEREC *ubuf;
{
	int fd, fdp;
	char fname[PATHLEN];
	struct useridx uidx;
	char homepath[PATHLEN];
	unsigned int cnt;


	if (ubuf)
	{
		if (ubuf->userid[0] == '\0')
		{
			return 0;
		}
		if (get_passwd(NULL, ubuf->userid) > 0)
		{
			return 0;
		}
		sethomefile(homepath, ubuf->userid, NULL);
		if (mkdir(homepath, 0755) == -1)
		{
			return 0;
		}
		sethomefile(fname, ubuf->userid, UFNAME_PASSWDS);
		if ((fdp = open(fname, O_WRONLY | O_CREAT, 0600)) < 0)
		{
			rmdir(homepath);
			return 0;
		}
		if (write(fdp, ubuf, sizeof(USEREC)) != sizeof(USEREC))
		{
			close(fdp);
			unlink(fname);
			rmdir(homepath);
			return 0;
		}
		close(fdp);

		if ((fd = open(USERIDX, O_RDWR)) > 0)
		{
			flock(fd, LOCK_EX);
			if (lseek(fd, (off_t)((ubuf->uid - 1)*sizeof(uidx)), SEEK_SET) != -1
			    && read(fd, &uidx, sizeof(uidx)) == sizeof(uidx)
			    && !strcmp(uidx.userid, "new")
			    && lseek(fd, -((off_t) sizeof(uidx)), SEEK_CUR) != -1)
			{
				memset(&uidx, 0, sizeof(uidx));
				strcpy(uidx.userid, ubuf->userid);
				if (write(fd, &uidx, sizeof(uidx)) == sizeof(uidx))
				{
					flock(fd, LOCK_UN);
					close(fd);
					return ubuf->uid;
				}
			}
			flock(fd, LOCK_UN);
			close(fd);
		}
		unlink(fname);
		rmdir(homepath);
		return 0;
	}

	if ((fd = open(USERIDX, O_RDWR | O_CREAT, 0644)) < 0)
		return 0;
	flock(fd, LOCK_EX);
	cnt = 1;
	while (read(fd, &uidx, sizeof(uidx)) == sizeof(uidx))
	{
		if (uidx.userid[0] == '\0')
			break;
		cnt++;
	}
	if (lseek(fd, ((off_t) ((cnt - 1) * sizeof(uidx))), SEEK_SET) != -1)
	{
		memset(&uidx, 0, sizeof(uidx));
		strcpy(uidx.userid, "new");
		if (write(fd, &uidx, sizeof(uidx)) == sizeof(uidx))
		{
			flock(fd, LOCK_UN);
			close(fd);
			return cnt;
		}
	}
	flock(fd, LOCK_UN);
	close(fd);
	return 0;
}


int
user_login(cutmp, urcp, ctype, userid, passwd, fromhost)
USER_INFO **cutmp;
USEREC *urcp;
char ctype;
char *userid, *passwd, *fromhost;
{
	FILE *fp;
	time_t now;
	USER_INFO *upent;
	extern USER_INFO *new_utmp();	

	if ((*cutmp = new_utmp()) == NULL)
		return ULOGIN_NOSPC;
	upent = *cutmp;
	
	if (get_passwd(urcp, userid) <= 0)
	{
		purge_ulist(upent);
		*cutmp = NULL;
		return ULOGIN_NOENT;
	}
		
#ifdef GUEST_ACCOUNT
	if (strcmp(urcp->userid, GUEST_ACCOUNT))
	{
#endif
		if (urcp->passwd[0] == '\0')
		{
			purge_ulist(upent);		
			*cutmp = NULL;			
			return ULOGIN_ACCDIS;
		}
/*
			passwd[CRYPTLEN] = '\0';
*/
		if (!checkpasswd(urcp->passwd, passwd))
		{
			purge_ulist(upent);		
			*cutmp = NULL;			
			return ULOGIN_PASSFAIL;
		}
#ifdef GUEST_ACCOUNT
	}
#endif

	strcpy(upent->userid, userid);
	xstrncpy(upent->from, fromhost, sizeof(upent->from));
	xstrncpy(upent->username, urcp->username, UNAMELEN);	/* lasehu */	
	upent->pid = getpid();
	upent->uid = urcp->uid;
	upent->ctype = ctype;
	upent->mode = LOGIN;
	if ((urcp->flags[0] & CLOAK_FLAG) && urcp->userlevel >= PERM_CLOAK)
		upent->invisible = TRUE;
	else
		upent->invisible = FALSE;
	if (urcp->flags[0] & PAGER_FLAG)
		upent->pager = FALSE;
	else
		upent->pager = TRUE;
#ifdef HAVE_CHK		
	if (urcp->flags[0] & CHKONLY_FLAG)
		upent->chk = TRUE;
	else
		upent->chk = FALSE;
#endif		

	strcpy(urcp->userid, userid); /* debug */
	now = time(0);
	if ((now - urcp->lastlogin) > 3 * 60)	/* lasehu */
		urcp->numlogins++;
	upent->login_time = now;
#ifdef GUEST_ACCOUNT
	if (!strcmp(urcp->userid, GUEST_ACCOUNT)) /* debug */
		urcp->userlevel = 0;
	else
#endif
	{
		if (urcp->userlevel < PERM_NORMAL)
		{
			if (urcp->numlogins < PERM_NORMAL)
				urcp->userlevel = urcp->numlogins;
			else
				urcp->userlevel = PERM_NORMAL;
		}
	}

/*
	update_user(&curuser);	
    */

#ifdef GUEST_ACCOUNT
	if (strcmp(urcp->userid, GUEST_ACCOUNT))
#endif	
	{
		char pathRec[PATHLEN];

		sethomefile(pathRec, userid, UFNAME_RECORDS);		
		if ((fp = fopen(pathRec, "a")) != NULL)
		{
			fprintf(fp, "%s %s", fromhost, ctime(&(upent->login_time)));
			fclose(fp);
		}
	}
	return ULOGIN_OK;
}



void
user_logout(upent, urcp)
USER_INFO *upent;
USEREC *urcp;
{
	USEREC usrbuf;

	/*      unlink (tempfile); *//* �M���ϥΪ̩󦹦��W�����Ȧs�γ~�� */
#ifdef GUEST_ACCOUNT
	if (!strcmp(urcp->userid, GUEST_ACCOUNT))
	{
		if (upent)
			purge_ulist(upent);
		return;
	}
#endif

	if (upent->ever_delete_mail)
	{
		char fn_mailbox[PATHLEN];
		
		setmailfile(fn_mailbox, urcp->userid, DIR_REC);
		pack_article(fn_mailbox);
	}
	if (upent->pager)
		urcp->flags[0] &= ~PAGER_FLAG;
	else
		urcp->flags[0] |= PAGER_FLAG;	
	if (get_passwd(&usrbuf, urcp->userid) > 0)
	{
#if HAVE_IDENT
			if (usrbuf.ident > urcp->ident)
				urcp->ident = usrbuf.ident;
#endif
	}
	strcpy(urcp->lasthost, upent->from);
	urcp->lastlogin = upent->login_time;
	urcp->lastctype = upent->ctype;

	update_user(urcp);
	update_user_passfile(urcp);

	if (upent)
		purge_ulist(upent);
}
