
#include <unistd.h>
#include "linklist.h"


/*******************************************************************
 * �ǤJ string, malloc �@�� memory �s�U�r��
 * �Ǧ^ �� MEMORY Pointer
 *******************************************************************/
char *
malloc_str(str)
char *str;
{
	char *new;

	if (str && *str)
	{
		new = (char *) malloc(strlen(str) + 1);
		strcpy(new, str);
		return new;
	}
	return (char *) NULL;
}


/*******************************************************************
 * �ǤJ link list �����I, ������ Link list space
 * ���p link data �O�«���, �h freefunc ������ NULL �i��
 * �Ǧ^ NULL pointer
 *******************************************************************/
struct word *
free_wlist(wtop, freefunc)
struct word *wtop;
void (*freefunc) ();
{
	struct word *wcur;

	while (wtop)
	{
		wcur = wtop->next;
		if (freefunc)
			(*freefunc) (wtop->word);
		free(wtop);
		wtop = wcur;
	}
	return (struct word *) NULL;
}


/*******************************************************************
 * �[�W�@����ƨ���w�� link list ���
 * ���p link data �O�«���, �h addfunc ������ NULL �i��
 * �Ǧ^�s link list �� pointer (�e��)
 *******************************************************************/
struct word *
add_wlist(wtop, str, addfunc)
struct word *wtop;
char *str;
char *(*addfunc) ();
{
	struct word *new, *tmp;

	if (!str || !(*str))
		return wtop;

	new = (struct word *) malloc(sizeof(struct word));

	if (addfunc)
		new->word = (*addfunc) (str);
	else
		new->word = str;
	new->last = (struct word *) NULL;
	new->next = (struct word *) NULL;
	if (!wtop)
		return new;
	tmp = wtop;
	while (tmp->next)	/* lasehu */
		tmp = tmp->next;
	new->last = tmp;
	tmp->next = new;
	return wtop;
}


/*******************************************************************
 * ��� link list ���O�_���P word �ۦP�����.
 * --del by lasehu�Y wcur �� NULL, �h�q�Y��_, �_�h�q wcur �}�l��--
 * �Ǧ^��쪺 --del by lasehu�Υثe�Ҧb�� link pointer--
 * �䤣��h�Ǧ^ NULL
 *******************************************************************/
struct word *
cmp_wlist(wtop, str, cmpfunc)
struct word *wtop;
char *str;
int (*cmpfunc) ();
{
/* lasehu
   int    len = strlen(str);
 */
	struct word *wcur;

	for (wcur = wtop; wcur; wcur = wcur->next)
/* lasehu
   if (!(*cmpfunc) (wcur->word, str, len))
 */
		if (!(*cmpfunc) (wcur->word, str))
			break;
	return wcur;
}


/*******************************************************************
 * ��� link list ���O�_���P word �ۦP�����.
 * �Y wcur �� NULL, �h�q�Y��_, �_�h�q wcur �}�l��.
 * �p�G��, ���K��� link data �R�
 * ���p link data �O�«���, �h freefunc ������ NULL �i��
 * �Ǧ^��쪺�Υثe�Ҧb�� link pointer
 * �䤣��h�Ǧ^ NULL
 *******************************************************************/
struct word *
cmpd_wlist(pwtop, str, cmpfunc, freefunc)
struct word **pwtop;
char *str;
int (*cmpfunc) ();
void (*freefunc) ();
{
/* lasehu
   int    len = strlen(str);
 */
	struct word *wcur;

	if (!pwtop)
		return NULL;
	for (wcur = *pwtop; wcur; wcur = wcur->next)
	{
/* lasehu
   if (!(*cmpfunc) (wcur->word, str, len))
 */
		if (!(*cmpfunc) (wcur->word, str))
		{
/* del by lasehu
   if (wcur == *pwtop)
   {
   *pwtop = (*pwtop)->next;
   if (*pwtop)
   (*pwtop)->last = NULL;
   }
   else
   {
   wcur->last->next = wcur->next;
   if (wcur->next)
   wcur->next->last = wcur->last;
   }
 */
			if (wcur->last)
				wcur->last->next = wcur->next;
			if (wcur->next)
				wcur->next->last = wcur->last;
			if (wcur == *pwtop)
				*pwtop = (*pwtop)->next;
			if (freefunc)
				(*freefunc) (wcur->word);
			free(wcur);
			break;
		}
	}
	return wcur;
}


/*******************************************************************
 * �p����w�� link list �����X�� link.
 * �Y wcur �� NULL, �h�q�Y��_, �_�h�q wcur �}�l��.
 * �Ǧ^����
 *******************************************************************/
int
num_wlist(wtop /* , wcur */ )
struct word *wtop;

/* struct word *wcur; */
{
	int i = 0;
	struct word *wcur;

/*
   if(!wtop)
   return 0;
   if(!wcur)
   wcur = wtop;
 */
	for (wcur = wtop; wcur; wcur = wcur->next)
		i++;
	return i;
}


/*******************************************************************
 * ���� link list �l���X
 *******************************************************************/
struct word *
get_subwlist(tag, list)
register char tag[];
register struct word *list;
{
	struct word *wtop = NULL;
	int len = (tag) ? strlen(tag) : 0;

	while (list && list->word)
	{
		if (tag && strncmp(list->word, tag, len))
			/* NULL STATEMENT */ ;
		else
			wtop = add_wlist(wtop, list->word, NULL);
		list = list->next;
	}
	return wtop;
}


/*******************************************************************
 * �d�X�̤j�r��
 *******************************************************************/
int
maxlen_wlist(list, count)
struct word *list;
int count;
{
	int len = 0, t;

	while (list && count)
	{
		t = strlen(list->word);
		if (t > len)
			len = t;
		list = list->next;
		count--;
	}
	return len;
}

/*******************************************************************
 * Use Arrary Implement Link-List
 *******************************************************************/
int
cmp_array(atop, str, cmpfunc)
struct array *atop;
char *str;
int (*cmpfunc) ();
{
	if (atop)
	{
		register int i, num;
		register char *s;

		num = atop->number;
		for (i = 0; i < num; i++)
		{
			s = atop->datap[i];
			if (s)
			{
				if (!(*cmpfunc) (s, str))
					return 1;
			}
		}
	}
	return 0;
}


struct array *
free_array(atop)
struct array *atop;
{
	register int i, num;
	register char **s;

	if (atop)
	{
		num = atop->number;
		for (i = 0; i < num; i++)
		{
			s = &(atop->datap[i]);
			if (*s)
			{
				free(*s);
				*s = NULL;
			}
		}
		free(atop);
	}
	return (struct array *) NULL;
}


struct array *
add_array(atop, str, addfunc)
struct array *atop;
char *str;
char *(*addfunc) ();
{
	register char **s;
	register int i, num;

	if (!str || !(*str))
		return atop;
	num = atop->number;
	for (i = 0; i < num; i++)
	{
		s = &(atop->datap[i]);
		if (!(*s))
			break;
	}
	if (i < num)
	{
		if (addfunc)
			*s = (*addfunc) (str);
		else
			*s = str;
	}
	return atop;
}


struct array *
malloc_array(numpointer)
int numpointer;
{
	struct array *top;
	register int i;

	top = (struct array *) malloc(sizeof(struct array));

	if (!top)
		return (struct array *) NULL;
	top->datap = (char **) malloc(sizeof(char *) * numpointer);

	if (!(top->datap))
	{
		free(top);
		return (struct array *) NULL;
	}
	for (i = 0; i < numpointer; i++)
		top->datap[i] = (char *) NULL;
	top->number = numpointer;
	return top;
}


struct array *
cmpd_array(atop, str, cmpfunc)
struct array *atop;
char *str;
int (*cmpfunc) ();
{
	register int i, num;
	register char **s;

	if (atop)
	{
		num = atop->number;
		for (i = 0; i < num; i++)
		{
			s = &(atop->datap[i]);
			if (*s)
			{
				if (!(*cmpfunc) (*s, str))
				{
					free(*s);
					*s = (char *) NULL;
					break;
				}
			}
		}
	}
	return atop;
}


int
num_array(atop)
struct array *atop;
{
	register int i, num, total = 0;

	if (atop)
	{
		num = atop->number;
		for (i = 0; i < num; i++)
		{
			if (atop->datap[i])
				total++;
		}
	}
	return total;
}
