/*
 *  Like tin news reader, subscribe or unsubscribe, for zaprc.
 *  Through zaprc, user can customize which board is shown on list or not
 *
 *  Li-te Huang, lthuang@cc.nsysu.edu.tw, 04/23/98
 *  Module: can be used as library
 */

#include "bbs.h"


#define ZAPRC_MAXSIZE   (512)
#define ZAPRC_MAXNUM    (ZAPRC_MAXSIZE * 8)

static unsigned char zapped[ZAPRC_MAXSIZE];


int
ZapRC_Init(userid)
char *userid;
{
	char filename[PATHLEN];
	int fd;

	memset(zapped, 0, ZAPRC_MAXSIZE);

	sethomefile(filename, userid, UFNAME_ZAPRC);
	if ((fd = open(filename, O_RDONLY)) > 0)
	{
		if (read(fd, zapped, ZAPRC_MAXSIZE) == ZAPRC_MAXSIZE)
		{
			close(fd);
			return 0;
		}
		close(fd);
	}
	return -1;
}


int
ZapRC_Update(userid)
char *userid;
{
	char filename[PATHLEN];
	int fd;

	sethomefile(filename, userid, UFNAME_ZAPRC);
	if ((fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644)) > 0)
	{
		if (write(fd, zapped, ZAPRC_MAXSIZE) == ZAPRC_MAXSIZE)
		{
			close(fd);
			return 0;
		}
		close(fd);
	}
	return -1;
}


static int zaprc_readid;
static unsigned char zaprc_readbit;

ZapRC_IsZapped(bid)
register int bid;
{
	if (bid <= 0 || bid > ZAPRC_MAXNUM)
		return 0;
	mymod(bid, ZAPRC_MAXSIZE, &zaprc_readid, &zaprc_readbit);
	if (zapped[zaprc_readid] & zaprc_readbit)
		return 1;
	return 0;
}


void
ZapRC_DoZap(bid)
register unsigned int bid;
{
	mymod(bid, ZAPRC_MAXSIZE, &zaprc_readid, &zaprc_readbit);
	zapped[zaprc_readid] |= zaprc_readbit;
}


void
ZapRC_DoUnZap(bid)
register unsigned int bid;
{
	mymod(bid, ZAPRC_MAXSIZE, &zaprc_readid, &zaprc_readbit);
	zapped[zaprc_readid] &= ~zaprc_readbit;
}


int
ZapRC_ValidBid(bid)
register unsigned int bid;
{
	if (bid <= 0 || bid > ZAPRC_MAXNUM)
		return 0;
	return 1;
}
