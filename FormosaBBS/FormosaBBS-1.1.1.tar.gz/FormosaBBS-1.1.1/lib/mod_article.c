
#include "bbs.h"


static FILEHEADER genfhbuf;

int
pack_article(direct)		/* really remove article which were mark deleted */
char *direct;
{
	int fdr, fdw;
	FILEHEADER fhTmp, *fhr = &fhTmp;
	char fn_dirty[PATHLEN], fn_new[PATHLEN], fn_del[PATHLEN];
	short result = 0;

	sprintf(fn_new, "%s.new", direct);
	sprintf(fn_del, "%s.del", direct);
/* lasehu
   tempfile(fnnew);
   tempfile(fndel);
 */
	if ((fdr = open(direct, O_RDONLY)) < 0)
		return -1;
	if ((fdw = open(fn_new, O_WRONLY | O_CREAT | O_TRUNC, 0644)) < 0)
	{
		close(fdr);
		return -1;
	}
	flock(fdr, LOCK_EX);
	while (read(fdr, fhr, FH_SIZE) == FH_SIZE)
	{
		if (fhr->accessed & FILE_DELE)
		{
			setdotfile(fn_dirty, direct, fhr->filename);
			unlink(fn_dirty);
		}
		else
		{
			if (write(fdw, fhr, FH_SIZE) != FH_SIZE)
			{
				result = -1;
				break;
			}
		}
	}
	close(fdw);
	flock(fdr, LOCK_UN);
	close(fdr);
	if (result == 0)
	{
		if (myrename(direct, fn_del) == 0)
		{
			if (myrename(fn_new, direct) == 0)
			{
				unlink(fn_del);
				return 0;
			}
			myrename(fn_del, direct);
		}
	}
	unlink(fn_new);
	return -1;
}


/* 
 * append one record to article index file, 
 *   stamp: M.87654321.A
 * return artno 
 */
int
append_article(fname, path, author, title, ident, stamp, artmode)	/* ? */
char *fname, *path, *author, *title;
char *stamp;
char ident;
BOOL artmode;
{
	char dotdir[PATHLEN], fn_stamp[PATHLEN];
	char stampbuf[14];	/* M.987654321.A */
	FILEHEADER fhbuf, *fhr = &fhbuf;
	struct stat st;
	int fd;

	if (stat(path, &st) == -1 || !S_ISDIR(st.st_mode))
		return -1;
	get_only_name(path, stampbuf);
	sprintf(fn_stamp, "%s/%s", path, stampbuf);
	if (mycp(fname, fn_stamp) == -1)
	{
		unlink(fn_stamp);	/* debug */
		return -1;
	}
	memset(fhr, 0, FH_SIZE);
	xstrncpy(fhr->filename, stampbuf, sizeof(fhr->filename));
	xstrncpy(fhr->owner, author, sizeof(fhr->owner));
	xstrncpy(fhr->title, title, sizeof(fhr->title));
	fhr->ident = ident;
	sprintf(dotdir, "%s/%s", path, DIR_REC);
	if (artmode)
		fhr->artno = get_only_artno(dotdir);
	if (stamp)
		strcpy(stamp, stampbuf);

	if ((fd = open(dotdir, O_WRONLY | O_APPEND | O_CREAT, 0644)) < 0)
	{
		unlink(fn_stamp);	/* debug */
		return -1;
	}
	flock(fd, LOCK_EX);
	if (write(fd, fhr, FH_SIZE) != FH_SIZE)
	{
		flock(fd, LOCK_UN);
		close(fd);
		unlink(fn_stamp);	/* debug */
		return -1;
	}
	flock(fd, LOCK_UN);
	close(fd);
	if (artmode)
		return fhr->artno;
	return 0;
}


/*
   �ޤJ��� 
*/
void
include_ori(rfile, wfile)
char *rfile, *wfile;
{
	FILE *fpr, *fpw;
	char *author = NULL, *name = NULL;
	char *foo, *hptr;
	char inbuf[512];
	

	if ((fpw = fopen(wfile, "w")) == NULL)
		return;
	if ((fpr = fopen(rfile, "r")) == NULL)
	{
		fclose(fpw);
		return;
	}

	/* get header From */
	fgets(inbuf, sizeof(inbuf), fpr);
	if ((foo = strchr(inbuf, '\n')))
		*foo = '\0';
	if ((!strncmp(inbuf, _str_original, strlen(_str_original)) && (hptr = inbuf + strlen(_str_original)))
/*	
	    || (!strncmp(inbuf, "�o�H�H:", 7) && (hptr = inbuf + 7))
	    || (!strncmp(inbuf, "By:", 3) && (hptr = inbuf + 3))
	    || (!strncmp(inbuf, "From:", 5) && (hptr = inbuf + 5))
*/	    )
	{
		char **token, delim;
		short i;
		
		for (i = 0; i < 2 && *hptr; i++)
		{
			while (isspace(*hptr))
				hptr++;
			if (*hptr == '"')
			{
				token = &name;
				hptr++;
				delim = '"';
			}
			else if (*hptr == '(')			
			{
				token = &name;
				hptr++;
				delim = ')';
			}
			else if (*hptr == '<')
			{
				token = &author;
				hptr++;
				delim = '>';
			}
			else
			{
				token = &author;
				delim = ' ';
			}
			if ((foo = strchr(hptr, delim)) != NULL)
			{
				*foo = '\0';
				*token = hptr;
				hptr = foo + 1;
			}
		}
		if (author != NULL && name != NULL)
			fprintf(fpw, "==> %s (%s) %s:\n", author, name, _msg_quote_said);
		else if (author != NULL)
			fprintf(fpw, "==> %s %s:\n", author, _msg_quote_said);
	}

	/* skip header line */
	while (fgets(inbuf, sizeof(inbuf), fpr)) 
	{
		if (inbuf[0] == '\n')
			break;;	
	}

	while (fgets(inbuf, sizeof(inbuf), fpr))
	{
		/* skip blank line */
		if (inbuf[0] == '\n') 
			continue;
		if ((inbuf[0] == '>' && inbuf[INCLUDE_DEPTH - 1] == '>')
		  || (inbuf[0] == ':' && inbuf[INCLUDE_DEPTH - 1] == ':'))
		{
			continue;
		}
		/* skip signature */
		if (!strcmp(inbuf, "--\n"))	
			break;
		/* add quote character */
		fprintf(fpw, ">%s", inbuf);	
	}
	fclose(fpw);
	fclose(fpr);
	chmod(wfile, 0600);
}


/*
   �аO�R����g�峹
*/
int
delete_one_article(ent, finfo, direct, delby, option)
int ent;
FILEHEADER *finfo;
char *direct;
char *delby;
char option;
{
	int fd;
	FILEHEADER *fhr = &genfhbuf;


	if ((fd = open(direct, O_RDWR)) < 0)
		return -1;
	/* no file lock to speed-up processing */
	if (lseek(fd, (off_t) ((ent - 1) * FH_SIZE), SEEK_SET) != -1
	    && read(fd, fhr, FH_SIZE) == FH_SIZE)
	{
		if (option == 'd')
		{
			fhr->accessed |= FILE_DELE;
			finfo->accessed |= FILE_DELE;
			xstrncpy(fhr->title + sizeof(fhr->title) - IDLEN, delby, IDLEN);
			xstrncpy(finfo->title + sizeof(finfo->title) - IDLEN, delby, IDLEN);
		}
		else
		{
			fhr->accessed &= ~FILE_DELE;
			finfo->accessed &= ~FILE_DELE;
			memset(fhr->title + sizeof(fhr->title) - IDLEN, 0, IDLEN);
			memset(finfo->title + sizeof(finfo->title) - IDLEN, 0, IDLEN);
		}
		if (lseek(fd, -((off_t) FH_SIZE), SEEK_CUR) != -1)
		{
			if (write(fd, fhr, FH_SIZE) == FH_SIZE)
			{
				close(fd);
				return 0;
			}
		}
	}
	close(fd);
	return -1;
}


/*
   �Ϭq�ХܧR���峹
*/
int
delete_articles(direct, n1, n2, delby, option)
char *direct;
int n1, n2;
char *delby;
char option;
{
	int fd;
	FILEHEADER *fhr = &genfhbuf;
	

	if ((fd = open(direct, O_RDWR)) < 0)
		return -1;
	if (lseek(fd, (off_t) ((n1 - 1) * FH_SIZE), SEEK_SET) == -1)
	{
		close(fd);
		return -1;
	}
	flock(fd, LOCK_EX);
	while (n1++ <= n2 && read(fd, fhr, FH_SIZE) == FH_SIZE)
	{
		if (fhr->accessed & FILE_RESRV)
			continue;
		if (option == 'd')
		{
			fhr->accessed |= FILE_DELE;
			xstrncpy(fhr->title + sizeof(fhr->title) - IDLEN, delby, IDLEN);			
		}
		else
		{
			fhr->accessed &= ~FILE_DELE;
			memset(fhr->title + sizeof(fhr->title) - IDLEN, 0, IDLEN);
		}
		/* note the article was deleted by who */

		if (lseek(fd, -((off_t) FH_SIZE), SEEK_CUR) == -1)
		{
			flock(fd, LOCK_UN);
			close(fd);
			return -1;
		}
		if (write(fd, fhr, FH_SIZE) != FH_SIZE)
		{
			flock(fd, LOCK_UN);
			close(fd);
			return -1;
		}
	}
	flock(fd, LOCK_UN);
	close(fd);
	return 0;
}


/*
   �ХܫO�d�峹
*/   
int
reserve_one_article(ent, finfo, direct)
int ent;
FILEHEADER *finfo;
char *direct;
{
	int fd;
	FILEHEADER *fhr = &genfhbuf;

	if ((fd = open(direct, O_RDWR)) < 0)
		return -1;
	/* no file lock to speed-up processing */
	if (lseek(fd, (off_t) ((ent - 1) * FH_SIZE), SEEK_SET) != -1
	    && read(fd, fhr, FH_SIZE) == FH_SIZE)
	{

		if (finfo->accessed & FILE_RESRV)
		{
			fhr->accessed &= ~FILE_RESRV;
			finfo->accessed &= ~FILE_RESRV;
		}
		else
		{
			fhr->accessed |= FILE_RESRV;
			finfo->accessed |= FILE_RESRV;
		}
		if (lseek(fd, -((off_t) FH_SIZE), SEEK_CUR) != -1)
		{
			if (write(fd, fhr, FH_SIZE) == FH_SIZE)
			{
				close(fd);
				return 0;
			}
		}
	}
	close(fd);
	return -1;
}


void
write_article_header(fpw, userid, username, bname, timestr, title, origin)
FILE *fpw;
char *userid, *username, *bname, *timestr;
char *title, *origin;
{
	if (bname)
		fprintf(fpw, "�o�H�H: %s (%s)    �ݪO: %s\n", userid, username, bname);
	else
		fprintf(fpw, "�o�H�H: %s (%s)\n", userid, username);	
	fprintf(fpw, "���: %s\n", timestr);
	fprintf(fpw, "���D: %s\n", title);
	if (origin)
		fprintf(fpw, "�ӷ�: %s\n", origin);
	fflush(fpw);
}
