#include "linklist.h"

/* bbslib.c */
int flock(int fd, int op);
int mycp(char *from, char *to);
int myunlink(char name[]);
int myrename(const char *from, const char *to);
void sethomefile(char *buf, char *userid, char *filename);
void setuserfile(char *buf, char *userid, char *filename);
void setboardfile(char *buf, char *bname, char *filename);
void settreafile(char *buf, char *bname, char *filename);
void setmailfile(char *buf, char *userid, char *filename);
void get_only_name(char dir[], char fname[]);
int append_news(char *board, char *fname, int option);
int dashf(char *fname);
int dashd(char *fname);
void close_all_ftable(void);
int rewind_board(char *bname);
int get_only_artno(char *dotdir);
void mymod(unsigned int id, int maxu, int *pp, unsigned char *qq);
void init_bbsenv(void);
struct HostDeny *host_deny_init(char *fname);
int host_deny(char *host);
void setdotfile(char *buf, char *dotfile, char *fname);
int append_file(char *afile, char *rfile);
int seek_in_file(char filename[], char seekstr[]);
int is_emailaddr(char *to);
int match_in_multistr(register char *s1, register char *s2);
char *xstrncpy(char *dst, const char *src, size_t n);
int xgrep(char *pattern, char *filename);
int invalid_userid(char *userid);
/* mod_article.c */
int pack_article(char *direct);
int append_article(char *fname, char *path, char *author, char *title, int ident, char *stamp, int artmode);
void include_ori(char *rfile, char *wfile);
int delete_one_article(int ent, FILEHEADER *finfo, char *direct, char *delby, int option);
int delete_articles(char *direct, int n1, int n2, char *delby, int option);
int reserve_one_article(int ent, FILEHEADER *finfo, char *direct);
void write_article_header(FILE *fpw, char *userid, char *username, char *bname, char *timestr, char *title, char *origin);
/* mod_board.c */
int can_see_board(BOARDHEADER *bhr, unsigned int userlevel);
/* mod_linklist.c */
char *malloc_str(char *str);
struct word *free_wlist(struct word *wtop, void (*freefunc)(void));
struct word *add_wlist(struct word *wtop, char *str, char *(*addfunc)(void));
struct word *cmp_wlist(struct word *wtop, char *str, int (*cmpfunc)(void));
struct word *cmpd_wlist(struct word **pwtop, char *str, int (*cmpfunc)(void), void (*freefunc)(void));
int num_wlist(struct word *wtop);
struct word *get_subwlist(register char tag[], register struct word *list);
int maxlen_wlist(struct word *list, int count);
int cmp_array(struct array *atop, char *str, int (*cmpfunc)(void));
struct array *free_array(struct array *atop);
struct array *add_array(struct array *atop, char *str, char *(*addfunc)(void));
struct array *malloc_array(int numpointer);
struct array *cmpd_array(struct array *atop, char *str, int (*cmpfunc)(void));
int num_array(struct array *atop);
/* mod_mail.c */
int SendMail_Local(char *fname, char *from, char *to, char *title, int ident);
int DirectSMTPMail(int ms, char *fname, char *from, char *to, char *title);
int SendMail_Internet(int ms, char *fname, char *from, char *to, char *title);
int CreateMailSocket(void);
int CloseMailSocket(int ms);
/* mod_net.c */
int ConnectServer(char *host, int port);
void DisconnectServer(int s);
int net_write(int sd, char *buf, int nbytes);
char *net_gets(int sd, char buf[], int buf_size);
/* mod_pass.c */
char *genpasswd(char *pw);
int checkpasswd(char *passwd, char *test);
/* mod_post.c */
int PublishPost(char *fname, char *userid, char *bname, char *title, int ident, char *fromhost, int tonews, char *postpath);
/* mod_readrc.c */
void ReadRC_Update(void);
void ReadRC_Expire(void);
void ReadRC_Init(char *boardname, unsigned int bid, char *userid);
void ReadRC_Addlist(int artno);
int ReadRC_UnRead(int artno);
void ReadRC_Refresh(char *boardname, time_t rewind_time, int firstartno);
void ReadRC_Visit(char *boardname, unsigned int bid, char *userid, int bitset);
/* mod_record.c */
int safewrite(int fd, char *buf, int size);
long get_num_records(char filename[], int size);
int append_record(char filename[], void *record, size_t size);
int get_record(char *filename, void *rptr, size_t size, unsigned int id);
int delete_record(char *filename, size_t size, unsigned int id);
int substitute_record(char *filename, void *rptr, size_t size, unsigned int id);
/* mod_sem.c */
int sem_init(key_t key);
void sem_lock(int semid, int op);
/* mod_shm.c */
void attach_err(int shmkey, char *name);
void *attach_shm(key_t shmkey, int shmsize);
void resolve_utmp(void);
USER_INFO *search_ulist(register int (*fptr)(void), register char *farg);
int apply_ulist(register int (*fptr)(void));
int ask_online_user(void);
void purge_ulist(USER_INFO *upent);
void update_ulist(USER_INFO *cutmp, USER_INFO *upent);
USER_INFO *new_utmp(void);
void resolve_brdshm(void);
BOARDHEADER *search_brdshm(register int (*fptr)(void), register char *farg);
void apply_brdshm(int (*fptr)(void));
unsigned int get_board(BOARDHEADER *bhead, char *bname);
void rebuild_brdshm(void);
int cmp_bname(char *bname, BOARDHEADER *bhentp);
int cmp_class(struct class_t *cs1, struct class_t *cs2);
int resolve_classhm(void);
/* mod_user.c */
unsigned int get_passwd(USEREC *urcp, char *userid);
unsigned int update_user(USEREC *urcp);
unsigned int update_user_passfile(USEREC *urcp);
unsigned int new_user(USEREC *ubuf);
int user_login(USER_INFO **cutmp, USEREC *urcp, int ctype, char *userid, char *passwd, char *fromhost);
void user_logout(USER_INFO *upent, USEREC *urcp);
/* mod_zap.c */
int ZapRC_Init(char *userid);
int ZapRC_Update(char *userid);
int ZapRC_IsZapped(register int bid);
void ZapRC_DoZap(register unsigned int bid);
void ZapRC_DoUnZap(register unsigned int bid);
int ZapRC_ValidBid(register unsigned int bid);
/* modetype.c */
char *ModeType(int mode);
char *modestring(USER_INFO *upent, int complete);
