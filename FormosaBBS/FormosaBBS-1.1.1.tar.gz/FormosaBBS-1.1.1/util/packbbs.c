/*
  Prune the articles in the boards or mail boxs, 
  which were marked delete.
*/  

#include "bbs.h"


int firstartno;


/*
  Prune the articles which were marked delete 
*/   
pack_article (direct)
char *direct;
{
	int fr, fw;
	FILEHEADER fh;
	FILEHEADER *fhr = &fh;
	char fname[PATHLEN], new[PATHLEN], del[PATHLEN];
	char *stampfn;

	sprintf (new, "%s.new", direct);
	sprintf (del, "%s.del", direct);
/* lasehu 
   tempfile(new); 
   tempfile(del);
 */
 	firstartno = -1;
 	
	if ((fr = open (direct, O_RDONLY)) < 0)
		return -1;
	if ((fw = open (new, O_WRONLY | O_CREAT | O_TRUNC, 0644)) < 0)
	{
		close (fr);
		return -1;
	}
	strcpy (fname, direct);	
	stampfn = strrchr(fname, '/') + 1;
	flock (fr, LOCK_EX);
	while (read (fr, fhr, FH_SIZE) == FH_SIZE)
	{
		if (fhr->accessed & FILE_DELE)
		{
			strcpy(stampfn, fhr->filename);
			unlink (fname);
		}
		else if (fhr->accessed & FILE_RESRV)
		{
			if (write (fw, fhr, FH_SIZE) != FH_SIZE)
			{
				close (fw);			
				flock (fr, LOCK_UN);
				close (fr);
				unlink (new);
				return -1;
			}
		}
		else
		{
			if (write (fw, fhr, FH_SIZE) != FH_SIZE)
			{
				close (fw);			
				flock (fr, LOCK_UN);
				close (fr);
				unlink (new);
				return -1;
			}
			if (firstartno == -1)
				firstartno = fhr->artno;
		}
	}
	close (fw);
	flock (fr, LOCK_UN);
	close (fr);
	if (rename (direct, del) == 0)
	{
		if (rename (new, direct) == 0)
		{
			unlink (del);
			return 0;
		}
		rename (del, direct);
	}
	unlink (new);
	return -1;
}


/*
   Update the field 'firstartno' in struct boardheader (.BOARDS).
   By this step, we can use 'readrc' more efficiently and precisely.
*/   
int
fill_in_firstartno(bname, firstartno)
char *bname;
int firstartno;
{
	int fd;
	BOARDHEADER bhbuf;
	
	if ((fd = open (BOARDS, O_RDWR)) > 0)
	{
		flock(fd, LOCK_EX);
		while (read (fd, &bhbuf, BH_SIZE) == BH_SIZE)
		{
			/* compare board name in case-insensitive */
			if (!strcasecmp (bname, bhbuf.filename))	
			{
				bhbuf.firstartno = firstartno;
				if (lseek(fd, -((off_t)BH_SIZE), SEEK_CUR) != -1)
				{
					if (write(fd, &bhbuf, BH_SIZE) == BH_SIZE)
					{
						flock(fd, LOCK_UN);
						close(fd);					
						return 0;
					}
				}
				break;
			}
		}
		flock(fd, LOCK_UN);
		close(fd);
	}
	return -1;
}


int
main (argc, argv)
int argc;
char *argv[];
{
	char path[PATHLEN];
	int fd;
	char id[STRLEN];
	BOARDHEADER bh;
	int c, mode;

	extern char *optarg;

	init_bbsenv();

	if (argc < 2)
	{
		fprintf (stderr, "Usage: packbbs [-a] [-b boardname] [-m userid]\r\n");
		exit (0);
	}

	while ((c = getopt (argc, argv, "ab:m:")) != -1)
	{
		switch (c)
		{
		case 'a':
			mode = 'a';
			break;
		case 'b':
			mode = 'b';
			strcpy (id, optarg);
			break;
		case 'm':
			mode = 'm';
			strcpy (id, optarg);
			break;
		case '?':
		default:
			fprintf (stderr, "Usage: packbbs [-a] [-b boardname] [-m userid]\r\n");
			break;
		}
	}

	switch (mode)
	{
	case 'a':		/* pack all boards */
		if ((fd = open (BOARDS, O_RDONLY)) > 0)
		{
			while (read (fd, &bh, sizeof (bh)) == sizeof (bh))
			{
				setboardfile(path, bh.filename, DIR_REC);
				printf (" Pack '%s' board ...\r\n", bh.filename);
				if (pack_article (path) == -1)
					printf (" Pack '%s' board ...failed!!\r\n", bh.filename);
				else
				{
					fill_in_firstartno(bh.filename, firstartno);
					printf (" Pack '%s' board ...finished!!\r\n", bh.filename);
				}
			}
			printf (" Pack All Boards ... done!!\r\n");
		}
		break;
	case 'b':
		setboardfile(path, id, DIR_REC);
		printf (" Pack '%s' board ...\r\n", id);
		if (pack_article (path) == -1)
			printf (" Pack '%s' board ...failed!!\r\n", id);
		else
		{
			if (fill_in_firstartno(id, firstartno) == 0)
				printf (" Pack '%s' board ...finished!!\r\n", id);
			else
				printf (" Pack '%s' board ...failed!!\r\n", id);			
		}
		break;
	case 'm':
		setmailfile (path, id, DIR_REC);
		printf (" Pack '%s' mailbox...\r\n", id);
		if (pack_article (path) == -1)
			printf (" Pack '%s' mailbox ...failed!!\r\n", id);
		else
			printf (" Pack '%s' mailbox ...finished!!\r\n", id);
		break;
	default:
		return -1;
	}
	return 0;
}
