
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <errno.h>

#include <unistd.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bbs.h"
#include "../src/msginfo.h"


FILE *fout, *fin;
void finger_main();
USER_INFO *search_ulist();


int
main()
{
	struct sockaddr_in sin, from;
	fd_set ibits;
	int on;
	int len, ns;
	int sock, maxs;


	if (fork () != 0)
		exit (0);

	chdir (HOMEBBS);

	if ((on = open ("/dev/null", O_RDONLY)) < 0)
		exit (1);

	if ((sock = socket (AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror ("socket");
		exit (-1);
	}

	setsockopt (sock, SOL_SOCKET, SO_REUSEADDR, (char *) &on, sizeof (on));

	sin.sin_family = PF_INET;
	sin.sin_addr.s_addr = INADDR_ANY;
	sin.sin_port = htons ((u_short) 79);
	if (bind (sock, (struct sockaddr *) &sin, sizeof (sin)) < 0)
	{
		perror ("bind");
		exit (-2);
	}
	if (listen (sock, 10) < 0)
	{
		perror ("listen");
		exit (-3);
	}

	maxs = 10;
	len = sizeof (from);

	while (1)
	{
		FD_ZERO (&ibits);
		FD_SET (sock, &ibits);
		if ((on = select (maxs, &ibits, 0, 0, NULL)) < 1)
		{
			if ((on < 0 && errno == EINTR) || on == 0)
				continue;
			else
			{
				shutdown (sock, 2);
				close (sock);
				exit (-1);
			}
		}
		if (!FD_ISSET (sock, &ibits))
			continue;
		if ((ns = accept (sock, (struct sockaddr *) &from, &len)) < 0)
			continue;
		else
		{
			char *foo, inbuf[128];
			
			if ((fout = fdopen (ns, "w")) == NULL)
			{
				close (ns);
				continue;
			}
			if ((fin = fdopen (ns, "r")) == NULL)
			{
				fclose(fout);
				close (ns);
				continue;
			}
			
			fgets(inbuf, sizeof(inbuf), fin);
			if ((foo = strstr(inbuf, ".bbs")) != NULL)
			{
				*foo = '\0';
				query_user(inbuf);
				bbslog("fingerd",  "%s %s", inet_ntoa(from.sin_addr), inbuf);
			}
			else
			{
				finger_main();
				bbslog("fingerd",  "%s", inet_ntoa(from.sin_addr));				
			}
			close (ns);
		}
	}
}


FILEHEADER fhGol;

/*******************************************************************
 * �ˬd�H�c���L�s�H
 *******************************************************************/
check_newmail(name)
char *name;
{
	struct stat st;
	int fd;
	long numfiles;
	char fnameTmp[PATHLEN];
	

#ifdef GUEST_ACCOUNT
	if (!strcmp(GUEST_ACCOUNT, name))
		return FALSE;
#endif
	setmailfile(fnameTmp, name, DIR_REC);
	if (stat(fnameTmp, &st) == -1)
		return FALSE;
	numfiles = st.st_size / FH_SIZE;
	if (numfiles > 0)
	{
		if ((fd = open(fnameTmp, O_RDONLY)) > 0)
		{
			lseek(fd, (off_t) (st.st_size - FH_SIZE), SEEK_SET);
			while (numfiles-- > 0)
			{
				read(fd, &fhGol, sizeof(fhGol));
				if (!(fhGol.accessed & FILE_READ) && !(fhGol.accessed & FILE_DELE))
				{
					close(fd);
					return TRUE;
				}
				lseek(fd, -((off_t) (2 * FH_SIZE)), SEEK_CUR);
			}
			close(fd);
		}
	}
	return FALSE;
}


char *
Ctime(clock)
register time_t *clock;
{
	static char tibuf[40];

	strftime(tibuf, 40, "%D %T %a", localtime(clock));
	return tibuf;
}


static int
cmp_userid(userid, upent)
char *userid;
USER_INFO *upent;
{
	if (upent == NULL || upent->userid[0] == '\0')
		return 0;
	if (userid == NULL || userid[0] == '\0')	/* debug */
		return 0;
	return (!strcmp(userid, upent->userid));
}


char genbuf[512];

query_user(ident)
char *ident;
{
	FILE *planfile;
	USEREC qurc;
	USER_INFO *quinf;

	if (ident == NULL || ident[0] == '\0')
		return -1;

	if (get_passwd(&qurc, ident) <= 0)
	{
		fprintf(fout, _msg_err_userid);
		return 0;
	}

	fprintf(fout, _msg_talk_5);
	fprintf(fout, _msg_talk_6, qurc.userid, qurc.username,
	       qurc.userlevel);
#if HAVE_IDENT
	if (qurc.ident == 7)
		fprintf(fout, _msg_talk_7);
	else
		fprintf(fout, _msg_talk_8);
#endif
	fprintf(fout, _msg_talk_9, qurc.numlogins, qurc.numposts);
	fprintf(fout, _msg_talk_10,
	       (qurc.lastlogin) ? Ctime(&(qurc.lastlogin)) : "(unknown)",
	       (qurc.lasthost[0]) ? qurc.lasthost : "(unknown)");
	fprintf(fout, "\n");

	if (qurc.flags[0] & FORWARD_FLAG)
		fprintf(fout, _msg_talk_13);
	else if (check_newmail(qurc.userid))
		fprintf(fout, _msg_talk_14);
	else
		fprintf(fout, _msg_talk_15);
	if ((quinf = search_ulist(cmp_userid, qurc.userid)))
	{
		fprintf(fout, _msg_talk_16,
		       modestring(quinf, 1),
		       (quinf->pager) ? _msg_on : _msg_off);
#ifdef HAVE_CHK
		if (quinf->chk)
			fprintf(fout, _str_marker);		      
#endif			
	}
	else
		fprintf(fout, _msg_talk_17);

	sethomefile(genbuf, qurc.userid, UFNAME_PLANS);
	if ((planfile = fopen(genbuf, "r")) != NULL)
	{
		register int i = 0;

		while (++i <= MAX_QUERY_LINES && fgets(genbuf, sizeof(genbuf), planfile))
			fprintf(fout, genbuf);
		fclose(planfile);
	}
	else
	{
		fprintf(fout, _msg_talk_19);
	}
	fprintf(fout, "\n");
	fflush(fout);
	return 0;
}


/* 
 *  finger
 */  
void
finger_main()
{
	register USER_INFO *uentp;
	register int i, user_num;
	extern struct UTMPFILE *utmpshm;	

	fprintf(fout, "\nMax Online User = [%d]\n\n", USHM_SIZE);

	fprintf(fout, "%-12.12s %-20.20s %-16.16s %-26.26s\n",
	        "UserID", "Nickname", "From", "Mode");
	fprintf(fout, "%-12.12s %-20.20s %-16.16s %-26.26s\n",
	        "============", "====================", 
	        "================", "==========================");

	resolve_utmp ();

	for (i = user_num = 0, uentp = utmpshm->uinfo; i < USHM_SIZE; i++, uentp++)
	{
		if (uentp->userid[0])
		{
			fprintf(fout, "%-12.12s %-20.20s %-16.16s %-26.26s\n",
			        uentp->userid, uentp->username, uentp->from,
			        ModeType(uentp->mode));
			user_num++;
		}
	}

	fprintf(fout, "%-12.12s %-20.20s %-16.16s %-26.26s\n",
	        "============", "====================", 
	        "================", "==========================");

	fprintf (fout, "\n[" BBSNAME "] Total users = %d\n", user_num);
	fflush (fout);
}
