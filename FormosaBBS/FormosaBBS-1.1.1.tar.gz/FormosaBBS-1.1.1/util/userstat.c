
#include "bbs.h"


#define PATH_SMODESTAT_RPT	"log/smodestat.rpt"
#define PATH_SMODESTAT_LST	"log/smodestat.lst"
#define PATH_VISITOR_RPT    "log/visitor.rpt"
#define PATH_LOGINS_AVE     "log/logins.ave"
#define PATH_LOGINS_PIC     "log/logins.pic"
#define	PATH_ONLINES_AVE    "log/onlines.ave"
#define PATH_ONLINES_PIC    "log/onlines.pic"


#define MAX_SMODE  8

enum
{
	S_TALK, S_TMENU, S_USER, S_CHAT, S_POST, S_MAIL, S_CSBBS, S_OTHER
};

char *descSmode[MAX_SMODE] =
{
	"�ͤ߶���", "�͸ܿ��", "�d�u�W�H", "��ѫ�", "�G�i�\\��",
	"�H��\\��", "�D�q���\\����", "�䥦"
};

int prune_flag = 0;

int Smode[MAX_SMODE];

int
CountStat(upent)
USER_INFO *upent;
{
	int n;

	if (upent->pid < 2)
		return -1;

	switch (upent->mode)
	{
	case CLIENT:
		n = S_CSBBS;
		break;
	case TALK:
	case PAGE:
		n = S_TALK;
		break;
	case LUSERS:
	case LFRIENDS:
		n = S_USER;
		break;
	case TMENU:
		n = S_TMENU;
		break;
	case SMAIL:
	case RMAIL:
	case MAIL:
		n = S_MAIL;
		break;
	case READING:
	case POSTING:
	case MODIFY:
	case SELECT:
	case BOARDS_MENU:
	case CLASS_MENU:
		n = S_POST;
		break;
	case CHATROOM:
	case IRCCHAT:
	case LOCALIRC:
		n = S_CHAT;
		break;
	default:
		if (upent->ctype == CTYPE_CSBBS)
			n = S_CSBBS;
		else
			n = S_OTHER;
		break;
	}
	Smode[n]++;
	return 0;
}


int
DoStatistics()
{
	FILE *fp;
	register int i;
	time_t now;
	char buf[3];

	if ((fp = fopen(PATH_SMODESTAT_LST, "a")) == NULL)
		return -1;
	memset(Smode, 0, sizeof(Smode));
	resolve_utmp();
	apply_ulist(CountStat);
	
	time(&now);
	strftime(buf, 3, "%H", localtime(&now));
	fprintf(fp, "%s:", buf);
	
	for (i = 0; i < MAX_SMODE; i++)
		fprintf(fp, " %d", Smode[i]);
	fprintf(fp, "\n");
	fclose(fp);
	return 0;
}


void
logins_stat()
{
	int fd;
	int hr;
	int counter[24];
	FILE *fp;

	memset(counter, 0, sizeof(counter));
		
	if ((fd = open(PATH_VISITOR, O_RDONLY)) > 0)
	{	
		struct tm *tm;	
		struct visitor vis;		
		
		while (read(fd, &vis, sizeof(vis)) == sizeof(vis))
		{
			if (vis.userid[0] == '\0')
				continue;
			tm = localtime(&(vis.when));
			if (tm)
			{
				hr = tm->tm_hour;
				if (hr >= 0 && hr <= 23)
					counter[hr] += 1;
/*
				printf("%02d: %ld\n", hr, vis.when);
*/				
			}
		}
		close(fd);
	}
	
	if (prune_flag)
		unlink(PATH_VISITOR);

	if ((fp = fopen(PATH_VISITOR_RPT, "w")) != NULL)
	{
		int cnt = 0;
		char timestr[40];	
		int start;
		time_t past = time(0) - 86400;
		
		time(&past);				
		strftime(timestr, 9, "%y/%m/%d", localtime(&past));	
		fprintf(fp, "\n\n %s �W���H���έp", timestr);
		for (start = 0; start < 24; start += 12)
		{
			fprintf(fp, "\n\n");
			for (hr = start; hr < start + 12; hr++)
				fprintf(fp, "   %02d ", hr);
			fprintf(fp, "\n");
			for (hr = start; hr < start + 12; hr++)
				fprintf(fp, "  ----");
			fprintf(fp, "\n");
			for (hr = start; hr < start + 12; hr++)
			{
				cnt += counter[hr];
				fprintf(fp, "%6d", counter[hr]);
			}
		}
		fprintf(fp, "\n\n  �W���`�H��: %d\n", cnt);
		fclose(fp);
	}

	if ((fp = fopen(PATH_LOGINS_AVE, "w")) != NULL)
	{
		for (hr = 0; hr < 24; hr++)
			fprintf(fp, "%d:%d\n", hr, counter[hr]);
		fclose(fp);
	}
}


int
PostStatistics(bname)
char *bname;
{
	char fname[STRLEN], title[STRLEN], postpath[STRLEN];
	time_t past = time(0) - 86400;
	FILE *fpr, *fpw;
	char inbuf[80], timestr[20];
	int i;
	
	strcpy(fname, "tmp/userstat.post");
	if ((fpw = fopen(fname, "w")) != NULL)
	{
		fprintf(fpw, "�o�H�H:  SYSOP (�t�κ޲z��)    �ݪO: %s", bname);
		fprintf(fpw, "\n���:  %s", ctime(&past));
		fprintf(fpw, "���D:  %s �έp��T", BBSNAME);
		strftime(timestr, 9, "%y/%m/%d", localtime(&past));
		fprintf(fpw, "\n\n\n[%s]\n\n %s �u�W�ϥΪ��A�έp\n", BBSNAME, timestr);

		if ((fpr = fopen(PATH_SMODESTAT_RPT, "r")) != NULL)
		{
			i = 0;
			while (fgets(inbuf, sizeof(inbuf), fpr))
			{
				i++;
				fprintf(fpw, "%s", inbuf);
			}
			fclose(fpr);
		}
		
		for (i %= 24; i > 0 && i < 15; i++)
			fprintf(fpw, "\n");
		i = 0;
		
		if ((fpr = fopen(PATH_VISITOR_RPT, "r")) != NULL)
		{
			while (fgets(inbuf, sizeof(inbuf), fpr))
			{
				i++;
				fprintf(fpw, "%s", inbuf);
			}
			fclose(fpr);
		}

		for (i %= 24; i > 0 && i < 24; i++)
			fprintf(fpw, "\n");
		i = 0;

		if ((fpr = fopen(PATH_ONLINES_PIC, "r")) != NULL)
		{
			while (fgets(inbuf, sizeof(inbuf), fpr))
			{
				i++;
				fprintf(fpw, "%s", inbuf);
			}
			fclose(fpr);
		}

		for (i %= 24; i > 0 && i < 24; i++)
			fprintf(fpw, "\n");
		i = 0;

		if ((fpr = fopen(PATH_LOGINS_PIC, "r")) != NULL)
		{
			while (fgets(inbuf, sizeof(inbuf), fpr))
			{
				i++;
				fprintf(fpw, "%s", inbuf);
			}
			fclose(fpr);
		}
		
		fclose(fpw);
	}
	sprintf(title, "[�έp] %s %s �u�W�έp", BBSNAME, timestr);
	sprintf(postpath, "%s/%s", BBSPATH_BOARDS, bname);
	
/*
   unlink(PATH_SMODESTAT_LST);
 */
	return PublishPost(fname, "SYSOP", bname, title, 7, "localhost", 
	                   FALSE, NULL);
}


int
onlines_stat()
{
	int maxSmode[MAX_SMODE], totalSmode[MAX_SMODE];
	int nTmp;
	int TotalLines = 0;
	int maxOnlineUsers = 0, tmpOnlineUsers;
	int totalLogins = 0;
	FILE *fpr, *fpw;
	char inbuf[512];
	int i;
	char *ptr;
	int Hr, Hr_Logins[24], Hr_lines[24];

	if ((fpr = fopen(PATH_SMODESTAT_LST, "r")) == NULL)
		return -1;
	if ((fpw = fopen(PATH_SMODESTAT_RPT, "w")) == NULL)
	{
		fclose(fpr);
		return -1;
	}

	memset(maxSmode, 0, sizeof(maxSmode));
	memset(totalSmode, 0, sizeof(totalSmode));
	memset(Hr_Logins, 0, sizeof(Hr_Logins));
	memset(Hr_lines, 0, sizeof(Hr_lines));	

	while (fgets(inbuf, sizeof(inbuf), fpr))
	{
		if ((ptr = strrchr(inbuf, '\n')) != NULL)
			*ptr = '\0';

		if ((ptr = strtok(inbuf, " :")) == NULL)
			continue;
		Hr = atoi(ptr);
		
		tmpOnlineUsers = 0;		
		for (i = 0; i < MAX_SMODE; i++)
		{
			if ((ptr = strtok(NULL, " ")) == NULL)
				break;
			nTmp = atoi(ptr);
			if (nTmp > maxSmode[i])
				maxSmode[i] = nTmp;
			totalSmode[i] += nTmp;
			tmpOnlineUsers += nTmp;
		}
		if (tmpOnlineUsers > maxOnlineUsers)
			maxOnlineUsers = tmpOnlineUsers;
		Hr_Logins[Hr] += tmpOnlineUsers;
		Hr_lines[Hr] += 1;
		totalLogins += tmpOnlineUsers;
		TotalLines++;
	}
	fclose(fpr);	
	
	if (prune_flag)
		unlink(PATH_SMODESTAT_LST);

	if (TotalLines == 0)
		TotalLines = 1;
	for (i = 0; i < 24; i++)
	{
		if (Hr_lines[i] == 0)
			Hr_lines[i] = 1;
	}

	fprintf(fpw, "\n   %-12s   Avg.  Max.  Pct.", "");
	for (i = 0; i < MAX_SMODE; i++)
	{
		fprintf(fpw, "\n   %-12s   %3d   %3d   %.2f%%",
		       descSmode[i], totalSmode[i] / TotalLines,
		       maxSmode[i],
		       (float) (totalSmode[i] / TotalLines) * 100 / (totalLogins / TotalLines));
	}
	fprintf(fpw, "\n -------------------------------------");
	fprintf(fpw, "\n   %-12s   %3d   %3d   100%%\n",
	       "�`�p", totalLogins / TotalLines, maxOnlineUsers);
	fclose(fpw);
	
	if ((fpw = fopen(PATH_ONLINES_AVE, "w")) != NULL)
	{
		for (i = 0; i < 24; i++)
			fprintf(fpw, "%d:%d\n", i, Hr_Logins[i]/Hr_lines[i]);
		fclose(fpw);
	}
}	


void
usage(prog)
char *prog;
{
/*
	printf("Usage: %s -c time_sec -p boardname \n\
\t-s report the statistics of logins till now
\t-c run as daemon, record the status of online user every [time_sec] sec\n\
\t-p post the statistics report on specified board\n", prog);
*/
	printf("Usage: %s -c -s -k -p boardname \n\
\t-s report the statistics of logins till now
\t-c record the status of online user\n\
\t-p post the statistics report on specified board\n\
\t-k with pruning the log record\n", prog);

}


int
main(argc, argv)
int argc;
char *argv[];
{
	int ch;
	extern char *optarg;

	if (argc < 2)
	{
		usage(argv[0]);
		exit(0);
	}

	init_bbsenv();
	

/*
	while ((ch = getopt(argc, argv, "c:p:s")) != EOF)
*/	
	while ((ch = getopt(argc, argv, "cp:sk")) != EOF)
	{
		switch (ch)
		{
		case 'c':
			DoStatistics();		
/*		
			{
				unsigned timer;
				
				if (fork())
					exit(0);
				{
					int s, ndescriptors = 64;
	
					for (s = 0; s < ndescriptors; s++);
					(void) close(s);
					s = open("/dev/null", O_RDONLY);
					dup2(s, 0);
					dup2(0, 1);
					dup2(0, 2);
					for (s = 3; s < ndescriptors; s++);
					(void) close(s);
				}
				timer = atoi(optarg);
				if (timer < 3)
					timer = 3;
				timer *= 60;
				while (1)
				{
					DoStatistics();
					sleep(timer);
				}
			}
*/			
			break;
		case 's':
			logins_stat();
			onlines_stat();
/*
			draw_pic(PATH_LOGINS_AVE, "�W���H��");
			draw_pic(PATH_ONLINES_AVE, "�t���H��");	
*/
			break;			
		case 'p':
			logins_stat();
			onlines_stat();
/*
			draw_pic(PATH_LOGINS_AVE, "�W���H��");
			draw_pic(PATH_ONLINES_AVE, "�t���H��");				
*/
			PostStatistics(optarg);
			break;
		case 'k':
			prune_flag = 1;
			break;
		case '?':
		default:
			usage(argv[0]);
			break;
		}
	}
	exit(0);
}


char *blk[10] =
{
	"��", "��", "�b", "�c", "�d",
	"�e", "�f", "�g", "�h", "�i",
};

int
draw_pic(filename, title)
char *filename;
char *title;
{
	FILE *fp;
	int max = 0, cr = 0, tm, flag, i, c, j, d;
	int pic[24];
	char buf[80];
	time_t past = time(0) - 86400;
	int degree;
	char *foo;

	if ((fp = fopen(filename, "r")) == NULL)
		return -1;

	memset(pic, 0, sizeof(pic));

	while (fgets(buf, sizeof(buf), fp) != NULL)
	{
		if ((foo = strchr(buf, ':')) == NULL)
			continue;
		*foo = '\0';
		cr = atoi(foo + 1);
		tm = atoi(buf);
		pic[tm] = cr;
		if (cr > max)
			max = cr;
	}
	fclose(fp);

	strcpy(buf, filename);
	if ((foo = strrchr(buf, '.')) != NULL)
		strcpy(foo, ".pic");
	else
		strcat(buf, ".pic");

	if ((fp = fopen(buf, "w")) == NULL)
		return -1;

	for (degree = 1, i = max; i > 0; degree *= 10)
	{
		if (i < 10)
			break;
		i = i / 10;
	}

	d = ((max / degree) > 0) ? (max / degree) : 1;

/*      
	c = d * 1;
*/
					
	c = (degree > 1) ? (degree / 15 / d) : d;
	printf("\nmax, degree, d, c = (%d, %d, %d, %d)\n", max, degree, d, c);
/*	
	c = d * 10;	
	c = max / 10;
*/	

	for (i = max / c + 1; i >= 0; i--)
	{
		fprintf(fp, "[1;33m%4d [34m|", i * c);
		flag = -1;
		for (j = 0; j < 24; j++)
		{
			if (pic[j] / c + 1 == i && pic[j] > 0)
			{
				if (flag != 1)
				{
					flag = 1;
/*					
					fprintf(fp, "[33m");
*/					
				}
				if (pic[j] >= 1000) /* lasehu */
					fprintf(fp, "[36m%3d", pic[j]/10);
				else
					fprintf(fp, "[31m%3d", pic[j]);
			}
			else if (pic[j] / c == i && pic[j] - i * c - 1 > 0)
			{
				if (flag != 2)
				{
					flag = 2;
					fprintf(fp, "[32m");
				}
				fprintf(fp, " %2s", blk[(pic[j] - i * c - 1) / d]);
			}
			else if (pic[j] / c + 1 < i || pic[j] - (i + 1) * c < 0)
				fprintf(fp, "   ");
			else
			{
				if (flag != 2)
				{
					flag = 2;
					fprintf(fp, "[32m");
				}
				fprintf(fp, " �i");
			}
		}
		fprintf(fp, "[m\n");
	}
	
	strftime(buf, 9, "%y/%m/%d", localtime(&past));	
	
	fprintf(fp, "    [1;34m�|�w�w�w[35m%s%s�έp[34m�w", BBSNAME, title);
	fprintf(fp, "�w[35m%s[34m�w�w�w[m\n", buf);
	fprintf(fp, "        [1;33m0  1  2  3  4  5  6  7  8  9 10 11 12 13 14");
	fprintf(fp, " 15 16 17 18 19 20 21 22 23[m\n");

	fclose(fp);
}
