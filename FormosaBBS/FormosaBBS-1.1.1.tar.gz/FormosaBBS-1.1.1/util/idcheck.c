
#include "bbs.h"


#define PGP_EXEC            "bin/pgp"
#define PATH_IDCHECK_HEADER "tmp/idcheck_header"
#define PATH_IDCHECK_TMP    "tmp/idcheck_tmp"

#define  DEBUG


#define first_word_nc(s,w) (strncmp(s,w, strlen(w)) == 0)

#define   dprintf(n,x)		{ if (debug >= n) printf x ; }

int debug;


int
a_encode(file1, file2, file3)
char *file1, *file2, *file3;
{
	char gbuf[128];

	if (mycp(file1, file2) == -1)
		return -1;
	dprintf(2, ("nopgp: %s\n", file2));
	if (rename(file2, file3) == -1)
	{
		unlink(file2);
		return -1;
	}
	return 0;
}


int
a_ok(name, cond)		/* write check level */
char name[15];
char cond;
{
	struct userec usr;

	dprintf(4, ("cond: %d\n", cond));
	if (get_passwd(&usr, name) <= 0)
		return;
	dprintf(2, ("user: %s\n", usr.userid));
	usr.ident = cond;
	update_user(&usr);
}


int
do_article(fname, path, owner, title)
char *fname, *path, *owner, *title;
{
	char *p;
	int fd;
	struct fileheader fh;

	if (mycp(fname, path))
		return -1;
	p = strrchr(path, '/') + 1;
	bzero(&fh, sizeof(fh));
	strcpy(fh.filename, p);
	strcpy(fh.owner, owner);
	strcpy(fh.title, title);
	strcpy(p, DIR_REC);
	if ((fd = open(path, O_WRONLY | O_CREAT | O_APPEND, 0644)) > 0)
	{
		flock(fd, LOCK_EX);
		strcpy(p, fh.filename);
		write(fd, &fh, sizeof(fh));
		flock(fd, LOCK_UN);
		close(fd);
		return 0;
	}
	return -1;
}


int
del_ident_article(stamp_fn)
char *stamp_fn;
{
	int fd;
	FILEHEADER fh, *fhr = &fh;
	char filename[PATHLEN];

	sprintf(filename, "ID/%s", DIR_REC);
	if ((fd = open(filename, O_RDWR)) < 0)
		return -1;
	flock(fd, LOCK_EX);
	while (read(fd, fhr, FH_SIZE) == FH_SIZE)
	{
		if (!strcmp(fhr->filename, stamp_fn))
		{
			fhr->accessed |= FILE_DELE;
			if (lseek(fd, -((off_t) FH_SIZE), SEEK_CUR) != -1)
			{
				if (write(fd, fhr, FH_SIZE) == FH_SIZE)
				{
					flock(fd, LOCK_UN);
					close(fd);
					return 0;
				}
			}
		}
	}
	flock(fd, LOCK_UN);
	close(fd);
	return -1;
}


int
process_ident(filename, subject)
char *filename, *subject;
{
	FILE *fps;
	char stamp_fn[PATHLEN], srcfile[PATHLEN], destfile[PATHLEN];
	char title[STRLEN], userid[STRLEN], *tmp, buf[512], realuserid[IDLEN+1];
	int i;
	

	dprintf(1, ("==> process_ident: %s\n", subject));
	append_file(PATH_IDENTLOG, filename);
	
	if ((tmp = strchr(subject, '(')) == NULL)
		return -1;
	tmp++;
	while (isspace(*tmp))
		tmp++;
	i = 0;
	while (*tmp && !isspace(*tmp))
		userid[i++] = *tmp++;
	userid[i] = '\0';
	if (*tmp == '\0')
		return -1;
	tmp++;
	i = 0;
	while (*tmp && !isspace(*tmp))
		stamp_fn[i++] = *tmp++;
	stamp_fn[i] = '\0';
	if (*tmp == '\0')
		return -1;
	
	dprintf(3, ("==> stamp_fn: %s\n", stamp_fn));
	dprintf(2, ("==> userid: %s\n", userid));

	sprintf(srcfile, "%s/%s", BBSPATH_IDENT, stamp_fn);
	if ((fps = fopen(srcfile, "r")) == NULL)
		return -1;

	if (!fgets(buf, sizeof(buf), fps))
	{
		fclose(fps);
		return -1;
	}
	fclose(fps);

	if ((tmp = strchr(buf, '\n')))
		*tmp = '\0';
	if (!(tmp = strrchr(buf, '(')))
		return -1;
	tmp++;
	i = 0;
	while (*tmp && *tmp != ')')
		realuserid[i++] = *tmp++;
	realuserid[i] = '\0';
	
	dprintf(2, ("===> realuserid: [%s]\n", realuserid));
	if (strcmp(realuserid, userid))
		return -1;

	sethomefile(buf, userid, UFNAME_IDENT);	
	if (append_file(buf, filename) == -1)
		return -1;

	dprintf(2, ("==> a_ok\n"));	
	a_ok(userid, 7);

	sprintf(destfile, "%s/%s", BBSPATH_REALUSER, userid);
	sprintf(title, "�����T�{: %s", userid);
	dprintf(4, ("===> do_article\n"));
	do_article(srcfile, destfile, userid, title);
	
	sprintf(buf, "tmp/%sPGP", userid);
	dprintf(3, ("==> a_encode\n"));
	a_encode(srcfile, buf, destfile);

	dprintf(4, ("=====> del_ident_article [%s]\n", stamp_fn));
	del_ident_article(stamp_fn);

	return 0;
}


int
main(argc, argv)
int argc;
char *argv[];
{
	FILE *fpr;
	int fdw;
	char buf[1024];
	char fn_idcktmp[PATHLEN], fn_idckori[PATHLEN];
	char from[512] = "\0", dot_from[512] = "\0", subject[512] = "\0";
	short invalid = FALSE, in_header = FALSE, first_line = TRUE;
	long content_length = 0L, mail_size = 0L, mail_start = 0L, line_size = 0L;
	char one_mail[PATHLEN] = "/tmp/one_mail", *ptr;
	int number = 0;
	time_t now;	


	time(&now);

	sprintf(fn_idckori, "%s/syscheck", SPOOL_MAIL);
	sprintf(fn_idcktmp, "%s/%s.%d", HOMEBBS, PATH_IDCHECK_TMP, now);
	if (!dashf(fn_idckori))
		exit(0);
		
	if (myrename(fn_idckori, fn_idcktmp) == -1)
	{
		fprintf(stderr, "\ncannot rename %s to %s\n", fn_idckori, fn_idcktmp);
		fflush(stderr);
		exit(-1);
	}
	chown(fn_idcktmp, BBS_UID, BBS_GID);	

	init_bbsenv();

	if ((fpr = fopen(fn_idcktmp, "r")) == NULL)
	{
		fprintf(stderr, "\ncannot open file: %s", fn_idcktmp);
		exit(-1);
	}

	while (1)
	{
		if (fgets(buf, sizeof(buf), fpr))
		{
			line_size = strlen(buf);
			if (buf[0] != '\n' && first_line)
				first_line = FALSE;
		}
		else
			line_size = 0;

		if (in_header)
		{
			if (buf[0] == '\n')
			{
				if (!first_line)
					in_header = FALSE;
			}
			else if (first_word_nc(buf, "From: "))
			{
				xstrncpy(dot_from, buf + 6, sizeof(dot_from));
			}
			else if (first_word_nc(buf, "Subject: "))
			{
				xstrncpy(subject, buf + 9, sizeof(subject));
			}
		}
		else
		{
			if (line_size == 0 || first_word_nc(buf, "From "))
			{
				if (from[0])
				{
					dprintf(1, ("\n==> [%d] From %s", ++number, from));
					dprintf(1, ("==> From: %s", dot_from));
					dprintf(1, ("==> Subject: %s", subject));
					dprintf(1, ("==> Mail_Start: %d\n", mail_start));
					dprintf(1, ("==> Mail-Size: %d\n", mail_size));	
					dprintf(1, ("==> Content-Length: %d\n\n", content_length));
					if ((fdw = open(one_mail, O_WRONLY | O_CREAT| O_TRUNC, 0600)) > 0)
					{
						size_t r_cc = mail_size, w_cc = mail_size - content_length;
						size_t r_size, w_size, size;
						
						
						fseek(fpr, mail_start, SEEK_SET);
						
						while (r_cc > 0)
						{
							r_size = MIN(r_cc, sizeof(buf));	
							if (read(fileno(fpr), buf, r_size) != r_size)
							{
								printf("\nerror: r_size");
								break;
							}
							r_cc -= r_size;
							
							w_size = MIN(r_size, w_cc);
							if (write(fdw, buf, w_size) != w_size)
							{
								printf("\nerror: r_size");							
								break;
							}
							w_cc -= w_size;
						}
						
						fgets(buf, sizeof(buf), fpr);						
						close(fdw);
						
						process_ident(one_mail, subject);
					}
					if (!strncmp("MAILER-DAEMON", from, 13)
					    || strstr(from, "postmaster")
					    || ((ptr = strchr(from, '.')) && strchr(ptr, '@')))
					{
						dprintf(1, ("===> Invalid From %s\n", from));
						invalid = TRUE;
					}
					else
						invalid = FALSE;
				}
				xstrncpy(from, buf + 5, sizeof(from));

				if (line_size == 0)
					break;
				mail_start += mail_size;
				mail_size = 0;
				dot_from[0] = '\0';
				subject[0] = '\0';
				content_length = 0;
				
				in_header = TRUE;
			}
			else
			{
/*				if (!invalid) */
					content_length += line_size;
			}
		}

		mail_size += line_size;
	}
	fclose(fpr);

	unlink(fn_idcktmp);
}
