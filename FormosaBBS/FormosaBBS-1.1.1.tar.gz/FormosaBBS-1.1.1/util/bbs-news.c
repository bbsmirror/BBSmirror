/*******************************************************************
 * ���s�j�� NSYSU BBS <--> News Server �H���y�{��  v1.0
 *
 * �\��G
 *     1. �@�� bbs board ��h�� news groups ���ǫH��.
 *     2. �@�� news group ��h�� bbs boards ���ǫH��.
 *
 * Coder: �����    lmj@cc.nsysu.edu.tw
 *                  (wind.bbs@bbs.nsysu.edu.tw)
 *
 *******************************************************************/
/*
   BBS <--> News Server Mail Exchange Gateway 
   
   Features:
   
       1. One BBS Board <--> More than one Newsgroup
       2. One Newsgroup <--> More than one BBS Board
   
   Author: ����� lmj@cc.nsysu.edu.tw     (wind.bbs@bbs.nsysu.edu.tw)
           ���߼w lthuang@cc.nsysu.edu.tw (lthuang.bbs@bbs.nsysu.edu.tw)
*/    

/* 
   02/28/97 lasehu
   	- Remove the region option in the configuration file
	- Support the protocol of NNTP 'XHDR NNTP-POSTING-HOST' in replacement of
	  'STAT', speeding-up the performance of program.
*/    

#undef DEBUG

#define NEWS_LOG

#include "bbs.h"
#include <varargs.h>

#define PATH_NEWSLOG 	"news/bbs-news.log"
#define B_N_PID_FILE	"news/bbs-news.pid"
#define FN_LINE			"news/current/line"
#define FN_INDEX		"news/current/index"
#define FN_FILENAME		"news/current/filename"
#define FN_TMPFILE		"news/input/tmpfile"


struct	Config	{
	int		port;
	int		io_timeout;
	int		retry_sec;
	int		rest_sec;
	short	esc_filter;
	char	myip[16];
	char	myhostname[80];
	char	mynickname[80];
	char	server[16];
	char	organ[80];
};

struct	BNLink	{
	char	board[80];
	char	newsgroup[160];
	char	type;
	char	get;
	char	expire;
	char	cancel;
	int     num;
	BOOL	enable;
	struct	BNLink	*next;
};

typedef struct BNLink bnlink_t;


char genbuf[4096];
int sd;
FILE *nntpin, *nntpout;		/* inport, outport of NNTP connection */
short booting = 0, can_post;
struct Config conf;
bnlink_t *bntop, *bnend, *bncur;
int io_timeout_sec;
time_t srv_start, srv_end;
int num_of_bnlink;


void
news_log (va_alist)
va_dcl
{
	va_list args;
	time_t now;
	int fd;
	char msgbuf[1024], logstr[1024], *fmt;


	va_start (args);
	fmt = va_arg (args, char *);
	vsprintf (msgbuf, fmt, args);
	va_end (args);

	time (&now);
	strftime (logstr, sizeof (logstr), "%x %X ", localtime (&now));
	strcat(logstr, msgbuf);
	if ((fd = open (PATH_NEWSLOG, O_APPEND | O_CREAT | O_WRONLY, 0600)) > 0)
	{
		write (fd, logstr, strlen (logstr));
		close (fd);
	}
}


/* 
   Like fgets(), but strip '\r' in the buffer readed.
*/   
char *
xfgets (buf, bsize, fp)
char *buf;
int bsize;
FILE *fp;
{
	register char *p;


	if (fgets (buf, bsize, fp))
	{
		if ((p = strrchr (buf, '\n')) && p > buf && *(--p) == '\r')
		{
			*p++ = '\n';
			*p = '\0';
		}
		return buf;
	}
	return (char *)NULL;
}


/*
   Initialize all of the configuration
*/    
void
init_conf ()
{
	bntop = (bnlink_t *) malloc (sizeof (bnlink_t));
	bnend = (bnlink_t *) malloc (sizeof (bnlink_t));
	bntop->next = bnend->next = bnend;
	bncur = bntop;

	memset (&conf, 0, sizeof (conf));
	num_of_bnlink = 0;
}


/*
   Reset and clean the configuration
*/   
void
clean_conf ()
{
	for (bncur = bntop->next; bncur && bncur != bnend; bncur = bncur->next)
		free (bncur);
	free (bntop);
	free (bnend);
}


/*
   Fetch a sub-string from a string, taking the character '\n' or '\0'
   as seprator. 
*/   
char *
get_str (begin, buf, len)
register char *begin, *buf;
register int len;
{
	register char *p;

	if (!begin)
		return (char *) NULL;
	while (isspace(*begin) || *begin == '\t')
		begin++;
	if (*begin == '\n' || *begin == '\0')
		return (char *) NULL;
	strncpy (buf, begin, len - 1);
	buf[len - 1] = '\0';
	if ((p = strchr (buf, '\n')) != NULL)
		*p = '\0';
	return buf;
}


/*
   Fetch a sub-string from a string, if 'buf' == NULL, then return
   the address of sub-string, else return the address of reminder string.
*/
char *
get_var (begin, buf, len)
register char *begin, *buf;
register int len;
{
	register char *end, *bend;


	if (!begin)
		return (char *) NULL;
	while (isspace(*begin) || *begin == '\t')
		begin++;
	if (*begin == '\n' || *begin == '\0')
		return (char *) NULL;
	end = begin;
	while (!isspace(*end) && *end != '\t' && *end != '\n' && *end != '\0')
		end++;
	if (begin == end)
		return (char *) NULL;
	if (!buf)
	{
		buf = (char *) malloc (end - begin + 1);
		*end = '\0';
		strcpy (buf, begin);
		return buf;
	}
	bend = buf + len - 1;
	while (begin < end && buf < bend)
		*buf++ = *begin++;
	*buf = '\0';
	return end;
}


/*
   Get a value from a string.
*/    
long
get_vul (begin)
char *begin;
{
	char *end;

	if (!begin)
		return (long)0;
	while (*begin != '\0' && (*begin < '0' || *begin > '9'))
		begin++;
	if (*begin == '\0')
		return 0;
	end = begin;
	while (*end > 0x29 && *end < 0x40)
		end++;
	*end = '\0';
	if (begin == end)
		return 0;
	return atol (begin);
}


/*******************************************************************
 * ���R conf file �� board <--> newsgroup ���������Y
 *******************************************************************/
bnlink_t *
make_bnlink (line)
char line[];
{
	char *p;
	bnlink_t *new;
	char buffer[1024];

	new = (bnlink_t *) malloc (sizeof (bnlink_t));

	p = get_var (line, new->board, 80);
	p = get_var (p, new->newsgroup, 160);
	p = get_var (p, buffer, 10);
	if (!strcmp (buffer, "both"))
		new->type = 'B';
	else if (!strcmp (buffer, "input"))
		new->type = 'I';
	else if (!strcmp (buffer, "output"))
		new->type = 'O';
	else
		new->type = 'B';

	p = get_var (p, buffer, 10);
	if (!strcmp (buffer, "yes"))
		new->get = 'Y';
	else
		new->get = 'N';
	p = get_var (p, buffer, 10);
	if (!strcmp (buffer, "yes"))
		new->expire = 'Y';
	else
		new->expire = 'N';
/*		
	p = get_var (p, buffer, 10);
*/	
	get_var (p, buffer, 10);
	if (!strcmp (buffer, "yes"))
		new->cancel = 'Y';
	else
		new->cancel = 'N';
/*		
	new->num = get_vul (p);
*/	
	new->num = ++num_of_bnlink;
	new->next = bncur->next;
	bncur->next = new;
	bncur = new;
	return new;
}




/*******************************************************************
 * Ū�J�ä��R news/bbs-news.conf ���U�����ҳ]�w
 *******************************************************************/
int
read_conf ()
{
	FILE *fp;
	char boot_run[8];


	if ((fp = fopen (BBS_NEWS_CONF, "r")) == NULL)
		return -1;
	init_conf ();
	while (xfgets (genbuf, sizeof (genbuf), fp))
	{
		if (genbuf[0] == '#' || genbuf[0] == '\n')
			continue;
		if (conf.myip[0] == '\0' && !strncmp (genbuf, "myip", 4))
			get_var (genbuf + 4, conf.myip, sizeof (conf.myip));
		else if (conf.myhostname[0] == '\0' && !strncmp (genbuf, "myhostname", 10))
			get_var (genbuf + 10, conf.myhostname, sizeof (conf.myhostname));
		else if (conf.mynickname[0] == '\0' && !strncmp (genbuf, "mynickname", 10))
			get_var (genbuf + 10, conf.mynickname, sizeof (conf.mynickname));
		else if (conf.server[0] == '\0' && !strncmp (genbuf, "server", 6))
			get_var (genbuf + 6, conf.server, sizeof (conf.server));
		else if (conf.port == 0 && !strncmp (genbuf, "port", 4))
			conf.port = (int) get_vul (genbuf + 4);
		else if (conf.organ[0] == '\0' && !strncmp (genbuf, "organ", 5))
			get_var (genbuf + 5, conf.organ, sizeof (conf.organ));
		else if (conf.io_timeout == 0 && !strncmp (genbuf, "io_timeout", 10))
			io_timeout_sec = conf.io_timeout = (int) get_vul (genbuf + 10);
		else if (conf.retry_sec == 0 && !strncmp (genbuf, "retry_sec", 9))
			conf.retry_sec = (int) get_vul (genbuf + 9);
		else if (conf.rest_sec == 0 && !strncmp (genbuf, "rest_sec", 8))
			conf.rest_sec = (int) get_vul (genbuf + 8);
		else if (!strncmp (genbuf, "esc_filter", 10))
		{
			get_var (genbuf + 10, boot_run, 8);
			if (!strcmp (boot_run, "yes"))
				conf.esc_filter = 1;
		}
		else if (!strncmp (genbuf, "[bnlink]", 8))
			break;
		if (!strncmp (genbuf, "boot_run", 8))
		{
			get_var (genbuf + 8, boot_run, 8);
/* lasehu: �Y�쥻�Y�H BBS ���楻�{��, �h����ä����� */
			if (strcmp (boot_run, "yes") && booting)
				exit (0);
		}
	}
	while (xfgets (genbuf, sizeof (genbuf), fp))
	{
		if (genbuf[0] == '#' || genbuf[0] == '\n')
			continue;
		make_bnlink (genbuf);
	}
	fclose (fp);
	return 0;
}


/***************************************************************
 * ���ɦW�[�J�R����C��, ���ݳB�z
 ***************************************************************/
int
del_post (filename)
char *filename;
{
	int fd, cc;
	char fname[PATHLEN];
	FILEHEADER fh;


	if ((fd = open (filename, O_RDONLY)) < 0)
		return -1;
	if ((cc = read (fd, fname, STRLEN)) < 1)
	{
		close (fd);
		return -1;
	}
	close (fd);
	fname[cc] = '\0';
	sprintf (genbuf, "boards/%-s/%s", bncur->board, DIR_REC);
	if ((fd = open (genbuf, O_RDWR)) < 0)
		return -1;
	while (read (fd, &fh, sizeof (fh)) == sizeof (fh))
	{
		if (!strcmp (fh.filename, fname))
		{
			if (lseek (fd, (long) (-sizeof (fh)), SEEK_CUR) != -1)
			{
				fh.accessed |= FILE_DELE;	/* lasehu */
				unlink (filename);
				close (fd);
				return 0;
			}
			break;
		}
	}
	close (fd);
	return -1;
}


/***************************************************************
 * �N news article �Ȧs�� post �� board
 ***************************************************************/
int
do_post (cur)
unsigned long cur;
{
	FILE *fr, *fw;
	int fb;
	char *p, from[STRLEN], name[STRLEN], group[STRLEN], 
	         title[STRLEN],	date[STRLEN], organ[STRLEN], 
	         msgid[STRLEN], board[STRLEN], nntphost[STRLEN];
	FILEHEADER fhead;
	char pathname[PATHLEN];


	memset (&fhead, 0, sizeof (fhead));
	from[0] = name[0] = group[0] = title[0] = date[0] = organ[0] 
	        = msgid[0] = board[0] = nntphost[0] = '\0';
	if ((fr = fopen (FN_TMPFILE, "r")) == NULL)
		return -1;
	while (xfgets (genbuf, sizeof (genbuf), fr))
	{
		if (from[0] == '\0' && !strncmp (genbuf, "From: ", 6))
		{
/* del by lasehu
   p = get_var(genbuf + 6, from, STRLEN);
 */
			p = genbuf + 6;
			while (isspace(*p))
				p++;
			if (*p == '"')
			{
				int name_index = 0;

				p++;
				while (*p && *p != '"')
					name[name_index++] = *p++;
				name[name_index] = '\0';
				p++;
				while (isspace(*p))
					p++;
				p++;
				get_var (p, from, sizeof (from));
				if (from[strlen (from) - 1] == '>')
					from[strlen (from) - 1] = '\0';
			}
			else
			{
				p = get_var (genbuf + 6, from, sizeof (from));
				while (isspace(*p))
					p++;
				p++;
				get_str (p, name, sizeof (name));
				if (name[strlen (name) - 1] == ')')
					name[strlen (name) - 1] = '\0';
			}
/* del by lasehu
   get_str(p, name, STRLEN);
   if ((p = strchr(name, ')')) != NULL)
   *(++p) = '\0';
 */
		}
		else if (group[0] == '\0' && !strncmp (genbuf, "Newsgroups: ", 12))
			get_var (genbuf + 12, group, STRLEN);
		else if (title[0] == '\0' && !strncmp (genbuf, "Subject: ", 9))
			get_str (genbuf + 8, title, STRLEN);	/* debug */
		else if (date[0] == '\0' && !strncmp (genbuf, "Date: ", 6))
			get_str (genbuf + 6, date, STRLEN);
		else if (organ[0] == '\0' && !strncmp (genbuf, "Organization: ", 14))
			get_str (genbuf + 13, organ, STRLEN);	/* debug */
		else if (msgid[0] == '\0' && !strncmp (genbuf, "Message-ID: ", 12))
			get_var (genbuf + 12, msgid, STRLEN);
		else if (nntphost[0] == '\0' && !strncmp (genbuf, "NNTP-Posting-Host: ", 19))
			get_str (genbuf + 19, nntphost, STRLEN);			
		else if (board[0] == '\0' && !strncmp (genbuf, "X-Filename: ", 12))
		{
			if ((p = strstr (genbuf + 12, "/M.")) != NULL)
				*p = '\0';
			get_var (genbuf + 12, board, STRLEN);
		}
		else if (genbuf[0] == '\n')
			break;
	}
	if (from[0] == '\0')
	{
		fclose (fr);
		return -2;
	}
	sprintf (pathname, "boards/%-s", bncur->board);
	get_only_name (pathname, fhead.filename);
	sprintf (pathname, "boards/%-s/%-s", bncur->board, fhead.filename);
	if ((fw = fopen (pathname, "w")) == NULL)
	{
		fclose (fr);
		return -3;
	}
	chmod (pathname, 0644);
	fprintf (fw, "�o�H�H: %s (%s)\n", from, name);	/* lasehu */
	fprintf (fw, "���: %s\n", date);
	fprintf (fw, "���D: %s\n", title);
	fprintf (fw, "�H�s: %s    �ݪO: %s\n", group, board);
	fprintf (fw, "�ӷ�: %s, %s\n", msgid, nntphost);
	fprintf (fw, "��´: %s\n\n", organ);
	while (xfgets (genbuf, sizeof (genbuf), fr))
		fprintf (fw, "%s", genbuf);
	fclose (fw);
	fclose (fr);
	if ((p = strchr (from, '@')))
		p++;
	else
		p = from;
	sprintf (fhead.owner, "#%-s", from);
	sprintf (fhead.title, "%-s", title);
	sprintf (pathname, "boards/%-s/%s", bncur->board, DIR_REC);
	fhead.artno = get_only_artno (pathname);	/* lasehu */
	if (fhead.artno == 1)	/* lasehu */
		rewind_board (bncur->board);
	if ((fb = open (pathname, O_WRONLY | O_CREAT | O_APPEND, 0600)) < 0)
	{
		sprintf (pathname, "boards/%-s/%-s", bncur->board, fhead.filename);
		unlink (pathname);
		return -4;
	}
	flock (fb, LOCK_EX);
	write (fb, &fhead, sizeof (fhead));
	flock (fb, LOCK_UN);
	close (fb);

	sprintf (pathname, "news/record/%s.%-s/%-d", bncur->board, bncur->newsgroup, cur);
	if ((fb = open (pathname, O_WRONLY | O_CREAT, 0644)) < 0)
	{
		p = strrchr (pathname, '/');
		*p = '\0';
		mkdir (pathname, 0755);
		chmod (pathname, 0755);
		sprintf (pathname, "news/record/%s.%-s/%-d", bncur->board,
			 bncur->newsgroup, cur);
		if ((fb = open (pathname, O_WRONLY | O_CREAT, 0644)) < 0)
			return 0;
	}
	write (fb, fhead.filename, strlen (fhead.filename));
	close (fb);
	return 0;
}


/***************************************************************
 * ��s�̫� news article �O��
 ***************************************************************/
int
update_lastnews (bname, newsgroup, last)
char *bname, *newsgroup;
unsigned long last;
{
	FILE *fp;
	char buf[PATHLEN];
	

	sprintf (buf, "news/input/%-s.%-s", bname, newsgroup);
	if ((fp = fopen (buf, "w")) != NULL)
	{
		chmod (buf, 0644);
		fprintf (fp, "%-d", last);
		fclose (fp);
		return 0;
	}
	return -1;
}


/***************************************************************
 * ���o�̫� news article �O��
 ***************************************************************/
unsigned long
get_lastnews (board, newsgroup)
char *board, *newsgroup;
{
	FILE *fn;
	register unsigned long d = 0;

	sprintf (genbuf, "news/input/%-s.%-s", board, newsgroup);
	if ((fn = fopen (genbuf, "r")) != NULL)
	{
		if (xfgets (genbuf, sizeof (genbuf), fn))
			d = atol(genbuf);
		fclose(fn);		
	}
	return d;
}


int
cmp_int(a, b)
int *a, *b;
{
	if (*a > *b)
		return 1;
	else if (*a == *b)
		return 0;
	return -1;
}


#define MAX_RANGE	(32767)

unsigned long range[MAX_RANGE], range_cnt;



/***************************************************************
 * �}�l�B�z news article to bbs post ���u�@.
 * �óB�z cancel and expire
 ***************************************************************/
int
news2bbs ()
{
	int total;
	FILE *fpw;
	unsigned long first, last, cur = 0;
	unsigned int getpostnum = 0;
	unsigned long i;
	int rc;

	fprintf (nntpout, "GROUP %s\n", bncur->newsgroup);
	fflush(nntpout);
	xfgets (genbuf, sizeof (genbuf), nntpin);
	
	if (strncmp (genbuf, "211 ", 4))
	{
		news_log ("ERR: group %s: %s", bncur->newsgroup, genbuf);
		return -1;
	}
	
	sscanf(genbuf + 4, "%d %d %d ", &total, &first, &last);

	if (total == 0)
	{
		update_lastnews (bncur->board, bncur->newsgroup, (unsigned long) 0);
		return 0;
	}
	
	cur = get_lastnews (bncur->board, bncur->newsgroup);
	
	if (cur < first)
		cur = first;	/* lasehu: ��s���аO�� */
	else if (cur == last)
		return 0;
	else if (cur > last)	/* debug */
	{
		update_lastnews (bncur->board, bncur->newsgroup, last);	
		return 0;
	}
	else
		cur++;


#ifdef NEWS_LOG
	news_log ("%s <--- %s %d - %d\n", bncur->board, bncur->newsgroup, cur, last);
#endif

	

	if (bncur->get)
	{
		fprintf(nntpout, "XHDR NNTP-POSTING-HOST %d-%d\n", cur, last);
		fflush(nntpout);
		xfgets(genbuf, sizeof(genbuf), nntpin);
		if (strncmp (genbuf, "221 ", 4))
		{
			news_log ("ERR: xhdr header error: %s", genbuf);
			return -1;
		}
	
		memset(range, 0, sizeof(range));
		range_cnt = 0;
	
		while (range_cnt < MAX_RANGE && xfgets(genbuf, sizeof(genbuf), nntpin))
		{
			if (!strncmp(genbuf, ".\n", 2))	/* debug */
				break;
			if (strstr(genbuf, MYHOSTNAME) || strstr(genbuf, MYHOSTIP))
				continue;
			range[range_cnt++] = (unsigned long)get_vul(genbuf);
		}
		if (range_cnt >= MAX_RANGE)	/* debug */
			news_log("ERR: increse the value of MAX_RANGE\n");

		for (i = 0; i < range_cnt; i++)
		{
			if ((fpw = fopen (FN_TMPFILE, "w")) == NULL)
				return -1;
			chmod (FN_TMPFILE, 0644);
	
			fprintf (nntpout, "ARTICLE %-d\n", range[i]);
			fflush(nntpout);
			xfgets (genbuf, sizeof (genbuf), nntpin);
			if (strncmp(genbuf, "220 ", 4))
			{
				fclose (fpw);
				news_log("ERR: article error: %s", genbuf);
				continue;
			}
			while (xfgets (genbuf, sizeof (genbuf), nntpin))
			{
				if (!strncmp(genbuf, ".\n", 2))	/* debug */
					break;
				fprintf (fpw, "%s", genbuf);
			}
			fclose (fpw);

			getpostnum++;
			rc = do_post (range[i]);
			if (rc < 0)
				news_log("ERR: do_post: %d\n", rc);
			update_lastnews (bncur->board, bncur->newsgroup, range[i]);
		}
		news_log ("log: ARTICLE %s-%s %d\n",
		        bncur->board, bncur->newsgroup, getpostnum);
	}
	else
	{
		update_lastnews (bncur->board, bncur->newsgroup, last);
		news_log ("log: only update last: %d\n", last);
	}
	return 0;
}


/*******************************************************************
 * �Ψ��o���ɮפ��� Esc ����ǦC
 *******************************************************************/
char *
myfgets (buf, len, fr, esc_filter)
char buf[];
int len;
FILE *fr;
int esc_filter;
{
	if (esc_filter)
	{
		char *p = buf, *end = buf + len - 1;
		int esc_begin = 0;
		int fd = fileno (fr);

		while (p < end && read (fd, p, 1) == 1)
		{
			if (*p == ESC)
			{
				esc_begin++;
				continue;
			}
			if (esc_begin && *p == 'm')
			{
				esc_begin = 0;
				continue;
			}
			if (esc_begin)
				continue;
			if (*p == '\n')
			{
				*(++p) = '\0';
				return buf;
			}
			else if (*p == '\0')
			{
				if (p == buf)
					return (char *) NULL;
				else
					return buf;
			}
			p++;
		}
		*end = '\0';
		if (p == buf)
			return (char *) NULL;
		else
			return buf;
	}
	else
		return (xfgets (buf, len, fr));
}


/*
 *  Connect to news server
 */     
int
connect_news_server ()
{
	while (1)
	{
		if ((sd = ConnectServer (conf.server, conf.port)) > 0)
			break;
		sleep (conf.retry_sec);
	}
	if ((nntpin = fdopen(sd, "r")) == NULL 
	    || (nntpout = fdopen(sd, "w")) == NULL)
	{
		news_log("ERR: fdopen\n");
		exit(-1);		
	}
/*	
	alarm(io_timeout_sec);	
*/	
	
	xfgets (genbuf, sizeof (genbuf), nntpin);
	if (!strncmp (genbuf, "200 ", 4))
		can_post = 1;
	else if (!strncmp (genbuf, "201 ", 4))
		can_post = 0;
	news_log ("connect server: %s", genbuf);
	time (&srv_start);	
	return sd;
}


/***************************************************************
 * �����P News Server ���� socket
 ***************************************************************/
int
close_news_server ()
{
	fprintf (nntpout, "QUIT\n");
	fflush(nntpout);
	close (sd);
/*	
	alarm(0);		
*/	
	news_log ("close_news_server\n");
	{
		char start[STRLEN], end[STRLEN];

		time (&srv_end);
		strftime(start, sizeof(start), "%x %X",localtime(&srv_start));
		strftime(end, sizeof(end), "%x %X",localtime(&srv_end));
		news_log ("log: %s ~ %s\n", start, end);		
	}
	return 0;
}


/***************************************************************
 * ��s�ثe�ҳB�z�� filename �O��
 ***************************************************************/
int
update_currfile (fname)
char *fname;
{
	FILE *ff;


	if ((ff = fopen (FN_FILENAME, "w")) == NULL)
		return -1;
	chmod (FN_FILENAME, 0644);
	fprintf (ff, "%s", fname);
	fclose (ff);
	return 0;
}


/***************************************************************
 * �}�l�B�z bbs posts to news article ���u�@.
 ***************************************************************/
int
bbs2news ()
{
	char currfile[STRLEN - 2], name[STRLEN], uname[STRLEN], title[STRLEN],
	  date[STRLEN], *p;
	FILE *fi, *ff;
	BOOL c_flag;
	unsigned int postnum = 0, cancelnum = 0;

	if ((fi = fopen (FN_INDEX, "r")) == NULL)
		return -1;
	if (fscanf (fi, "%s\n", currfile) != 1)
	{
		fclose (fi);
		news_log("ERR: %s for %s is empty\n", FN_INDEX, bncur->board);
		return -1;
	}
	if ((ff = fopen (FN_FILENAME, "r+")) != NULL)
	{
		if (xfgets (genbuf, sizeof(genbuf), ff) && strcmp (currfile, genbuf))
		{
			while (fscanf (fi, "%s\n", currfile) == 1)
			{
				if (!strcmp (currfile, genbuf))
					break;
			}
			if (strcmp (currfile, genbuf))
			{
				rewind (fi);
				fscanf (fi, "%s\n", currfile);
			}
		}
		fclose (ff);
	}

	do
	{
		update_currfile (currfile);
		if (currfile[0] == '-')
			c_flag = TRUE;
		else
			c_flag = FALSE;
		if (c_flag)
			sprintf (genbuf, "news/cancel/%-s.%-s", bncur->board, currfile + 1);
		else
			sprintf (genbuf, "boards/%-s/%-s", bncur->board, currfile);
		if ((ff = fopen (genbuf, "r")) == NULL)
		{
			news_log("ERR: cannot open %s for %s output\n", genbuf, bncur->board);
			continue;
		}

		if (can_post == 0)
		{
			news_log ("ERR: cannot post so close server\n");
			fclose (ff);
			continue;
		}
		
		fprintf (nntpout, "POST\n");
		fflush(nntpout);
		xfgets (genbuf, sizeof (genbuf), nntpin);
		if (strncmp(genbuf, "340 ", 4))
		{
			news_log ("ERR: cannot post\n");
			fclose (ff);
			continue;
		}
		
		name[0] = uname[0] = title[0] = date[0] = '\0';
		
		while (myfgets (genbuf, sizeof (genbuf), ff, conf.esc_filter))
		{
			if (name[0] == '\0' && (!strncmp (genbuf, "�o�H�H: ", 8) 
			    ||!strncmp (genbuf, "�o�H�H�G", 8)))
			{
				p = get_var (genbuf + 8, name, STRLEN);
				get_str (p, uname, STRLEN);
				if ((p = strrchr (uname, ')')) != NULL)
					*(++p) = '\0';
			}
			else if (date[0] == '\0' && (!strncmp (genbuf, "���: ", 6)
			         || !strncmp (genbuf, "����G", 6)))
				get_str (genbuf + 6, date, STRLEN);
			else if (title[0] == '\0' && (!strncmp (genbuf, "���D: ", 6)
			         || !strncmp (genbuf, "���D�G", 6)))
				get_str (genbuf + 6, title, STRLEN);
			else if (genbuf[0] == '\n')
				break;
		}
		
		fprintf (nntpout, "Newsgroups: %-s\n", bncur->newsgroup);
		fflush(nntpout);	/* debug */
		fprintf (nntpout, "Path: %-s\n", conf.mynickname);
		fprintf (nntpout, "From: %-s.bbs@%-s %-s\n", name, conf.myhostname, uname);
		fflush(nntpout);	/* debug */
		if (c_flag)
		{
			fprintf (nntpout, "Subject: cmsg cancel <%-s.%-d@%-s>\n", 
			            currfile + 1, bncur->num, conf.myhostname);
			fflush(nntpout);	/* debug */
			/* ? */
			fprintf (nntpout, "Message-ID: <del.%-s.%-d@%-s>\n", 
			            currfile + 1, bncur->num, conf.myhostname);
			fflush(nntpout);	/* debug */
		}
		else
		{
			fprintf (nntpout, "Subject: %-s\n", title);
			fflush(nntpout);	/* debug */
/*  debug
   fprintf(nntpout, "Date: %-s\n",date);
 */
			fprintf (nntpout, "Message-ID: <%-s.%-d@%-s>\n", 
			            currfile, bncur->num, conf.myhostname);
		}
		fprintf (nntpout, "Organization: %-s\n", conf.organ);
		if (c_flag)
		{
			fprintf (nntpout, "X-Filename: %-s/%-s\n", 
			            bncur->board, currfile + 1);
			/* ? */
			fprintf (nntpout, "Control: cancel <%-s.%-d@%-s>\n\n", 
			            currfile + 1, bncur->num, conf.myhostname);
			fprintf (nntpout, "Article be deleted by <%-s.bbs@%-s> %-s\n",
			            name, conf.myhostname, uname);
			fflush(nntpout);	/* debug */
		}
		else
		{
			fprintf (nntpout, "X-Filename: %-s/%-s\n\n", 
			            bncur->board, currfile);
			while (myfgets (genbuf, sizeof (genbuf), ff, conf.esc_filter))
			{
				fprintf (nntpout, "%s", genbuf);
			}
			fflush(nntpout);	/* debug */			
		}
		fclose (ff);		
		fprintf (nntpout, "\n.\n");
		fflush(nntpout);
		xfgets (genbuf, sizeof (genbuf), nntpin);
		if (strncmp(genbuf, "240 ", 4))
		{
			news_log("ERR: post: %s", genbuf);
			continue;
		}

		if (c_flag)
		{
			sprintf (genbuf, "news/cancel/%-s.%-s", bncur->board, currfile + 1);
			unlink (genbuf);
		}

		if (c_flag)
			cancelnum++;
		else
			postnum++;

		sleep (2);
	}
	while (fscanf (fi, "%s\n", currfile) == 1);
	fclose (fi);
	if (postnum > 0)
		news_log("log: POST %s %d\n", bncur->newsgroup, postnum);
	if (cancelnum > 0)
		news_log("log: cancel %s %d\n", bncur->newsgroup, cancelnum);
	return 0;
}


bnlink_t *
match_mailex_pair()
{
	char bnames[MAXBOARD][BNAME_LEN + 1];
	int cnt = 0;
	bnlink_t *first_enable_node = (bnlink_t *)NULL;
	int i;
	BOARDHEADER *bhentp;
	extern struct BRDSHM *brdshm;

	memset(bnames, 0, sizeof(bnames));
	
	resolve_brdshm();
	bhentp = brdshm->brdhr;
	for (i = 0; i < brdshm->number; i++, bhentp++)
	{
		if (bhentp->filename[0] != '\0')
			xstrncpy(bnames[cnt++], bhentp->filename, BNAME_LEN + 1);
	}

	qsort(bnames, cnt, BNAME_LEN+1, (void *)strcmp);
	
	for (bncur = bntop->next; bncur != bnend; bncur = bncur->next)
	{
		if (bsearch(bncur->board, bnames, cnt, BNAME_LEN+1, (void *)strcmp))
		{
			if (!first_enable_node)
				first_enable_node = bncur;
			bncur->enable = TRUE;
		}
		else
			bncur->enable = FALSE;
	}
	return (first_enable_node) ? first_enable_node : bnend;
}		


bnlink_t *
next_enable_node(bn1)
bnlink_t *bn1;
{
	bnlink_t *cur;


	for (cur = bn1; cur != bnend; cur = cur->next)
	{
		if (cur->enable)
			break;	
	}
	return cur;
}	


BOOL
find_match_node(bname, newsgroup, bnlink)
char *bname, *newsgroup;
bnlink_t **bnlink;
{
	bnlink_t *bnTmp;
	
	
	for (bnTmp = bntop->next; bnTmp != bnend; bnTmp = bnTmp->next)
	{
		if (!strcmp (bnTmp->board, bname)
		    && !strcmp (bnTmp->newsgroup, newsgroup))
		{
			break;
		}
	}
	if (bnTmp != bnend)
	{
		*bnlink = bnTmp;
		return TRUE;
	}
	return FALSE;
}


/***************************************************************
 * �}�l�B�z bnlink ���u�@.
 ***************************************************************/
int
access_bnlink ()
{
	char bname[80], *newsgroup;
	BOOL restore = FALSE;
	FILE *fpi, *fpl;

	news_log ("log: starting work\n");

	/* make assiocation between board and newsgroup */
	match_mailex_pair();
	
	/* restore and continue the unfinished mail exchange last time */
	if ((fpl = fopen (FN_LINE, "r")) != NULL)
	{
		bname[0] = '\0';
		if (xfgets (bname, sizeof (bname), fpl) 
		    && (newsgroup = strchr (bname, '#')) != NULL
		    && *(newsgroup + 1) != '\n' && *(newsgroup + 1) != '\0')
		{
			*newsgroup++ = '\0';
			
			/* find the match node with boardname and newsgroup */
			if (find_match_node(bname, newsgroup, &bncur))
			{
#ifdef NEWS_LOG			
				news_log("restore: %s#%s\n", bncur->board, bncur->newsgroup);
#endif				
				restore = TRUE;
			}
		}
		fclose (fpl);		
	}

	if (!restore)
	{
		bncur = next_enable_node(bntop->next);

		unlink (FN_LINE);
		unlink (FN_INDEX);
		unlink (FN_FILENAME);
		sprintf (genbuf, "news/output/%-s", bncur->board);
		myrename (genbuf, FN_INDEX);
	}

	if ((fpl = fopen (FN_LINE, "w")) != NULL)
	{
		chmod (FN_LINE, 0644);
		fprintf (fpl, "%-s#%-s", bncur->board, bncur->newsgroup);
		fclose (fpl);
	}
	/* Prepare send out-going mail to news. */
	if ((fpi = fopen (FN_INDEX, "r")) != NULL)
	{
		if (fscanf (fpi, "%s\n", genbuf) > 0)
		{
			FILE *fpf;		
			
			if ((fpf = fopen (FN_FILENAME, "w")) != NULL)
			{
				chmod (FN_FILENAME, 0644);
				fprintf (fpf, "%s", genbuf);
				fclose (fpf);
			}
		}
		fclose (fpi);
	}

	connect_news_server ();

	while (1)
	{
		if (bncur->type == 'B' || bncur->type == 'I')
		{
			news2bbs (); /* Process incoming mail of the current newsgroup */
		}
		if (bncur->type == 'B' || bncur->type == 'O')
		{
#ifdef NEWS_LOG
			news_log ("%s ---> %s\n", bncur->board, bncur->newsgroup);
#endif
			bbs2news (); /* Process outgoing mail of the current board */
		}

		bncur = next_enable_node(bncur->next);
		if (bncur == bnend)
		{
			close_news_server ();
			return 0;
		}

		unlink (FN_LINE);
		unlink (FN_INDEX);
		unlink (FN_FILENAME);
		sprintf (genbuf, "news/output/%-s", bncur->board);
		myrename (genbuf, FN_INDEX);
	}
}


/*******************************************************************
 * ������ read or write �Ӥ[��, ���P�_�u, ���s�s�� server
 *******************************************************************/
/* 
void
io_timeout ()
{
	close_all_ftable ();
	clean_conf ();
	execl ("bin/bbs-news", "bbs-news", NULL);
}
*/


int
main ()
{
	int fd, pid;

	init_bbsenv();

	if (fork ())
		exit (0);
/*		
	signal (SIGALRM, io_timeout);
*/	

	if ((fd = open (B_N_PID_FILE, O_RDWR | O_CREAT, 0644)) > 0)
	{
		genbuf[0] = '\0';
		if (read (fd, genbuf, 10) == 10 && (pid = atoi (genbuf)) > 2)
		{
			if (kill (pid, 0) == 0)
			{
				fprintf(stderr, "Another process exist, pid: %d\n", pid);
				fflush(stderr);
				exit (0);
			}
		}
		lseek (fd, 0, SEEK_SET);
		sprintf (genbuf, "%10d", getpid ());
		write (fd, genbuf, 10);
		close (fd);
	}
	else
	{
		fprintf (stderr, "cannot write to pid file\n");
		fflush(stderr);
		exit (-1);
	}
	
	close_all_ftable ();	
	for (;;)
	{
		if (read_conf ())
		{
			fprintf (stderr, "config file error!\n");
			fflush(stderr);
			exit (-1);
		}
		access_bnlink ();
		clean_conf ();
		sleep (conf.rest_sec);
	}
}
