/*
 * NSYSU BBS ���� bbsmail program  v1.0
 *
 *  �� bbsmail �{�����U�C�\��G
 *
 *     1. ���� userid.bbs@bbs...... �� E-mail ����J BBS Users ���ӤH�H�c.
 *     2. ���� mail bbs@bbs...... < post.file �� E-mail To Post ��@���.
 *     3. ���� Board Manager �H E-mail To Post ���覡 Post ���ذ�.
 *
 *  �@���{���P�ɥ]�t�T���γ~. Header Lines Rule �аѾ\���s BBS Announce.
 *
 *  Coder: �����    lmj@cc.nsysu.edu.tw
 *                   wind.bbs@bbs.nsysu.edu.tw
 */

#undef DEBUG
#define ANTISPAM

#include "bbs.h"
#include <varargs.h>


#undef LIMIT_MBOX_NUM		/* lthuang */


int debug = 0;

char genbuf[1024];
time_t now;

char sContentType[1024], received[4096];


struct mail_info
{
	char type;
	char from[STRLEN];
	char to[IDLEN + 2];
	char subject[STRLEN];
	char name[IDLEN + 2];
	char passwd[PASSLEN];
	char board[STRLEN];
	char title[STRLEN];
};

struct mail_info minfo;



void
log_bbsmail(va_alist)
va_dcl
{
	va_list args;
	time_t now;
	int fd;
	char msgbuf[1024], buf[1024], *fmt;
	char timestr[22];

	va_start(args);
	fmt = va_arg(args, char *);
	vsprintf(msgbuf, fmt, args);
	va_end(args);

	time(&now);
	strftime(timestr, sizeof(timestr), "%x %X", localtime(&now));

	sprintf(buf, "%s %.10s: %s\n", timestr, msgbuf);
	if ((fd = open(PATH_BBSMAIL_LOG, O_APPEND | O_CREAT | O_WRONLY, 0600)) > 0)
	{
		write(fd, buf, strlen(buf));
		close(fd);
	}
}


#define GET_NEXTONE	0
#define GET_NEXTALL	1
#define GET_HEADER	2
#define GET_PASSWD	3


char *
mygets(buf, bsize, fp)
char *buf;
int bsize;
FILE *fp;
{
	register char *p;

	if (fgets(buf, bsize, fp))
	{
		if ((p = strrchr(buf, '\n')) && p > buf && *(--p) == '\r')
		{
			*p++ = '\n';
			*p = '\0';
		}
		return buf;
	}
	return NULL;
}


/* if type == 0 �u��X�U�@��
 *    type == 1 �ĤG���H�᪺����
 *    type == 2 ���o���Y�Ʀ�᪺���
 *    type == 3 ���o password
 */
int
next_arg(from, to, len, type)
register char *from, *to;
register int len, type;
{
	register int i = 0, j = 0;
	register char ccc;

	if (type == GET_NEXTONE)
		ccc = ' ';
	else
		ccc = ':';

	while (from[i] != ccc)
		if (from[i] == '\n' || from[i] == '\0')
			return -1;
		else
			i++;
	if (type != GET_NEXTONE)
		i++;
	while (isspace(from[i]))
		i++;
	i--;
	switch (type)
	{
	case GET_NEXTONE:
		while (from[++i] != SP && from[i] != '\0' && j < len - 1)
		{
			if (from[i] == ESC || from[i] == TAB || from[i] == NL)
				to[j++] = SP;
			else
				to[j++] = from[i];
		}
		break;
	case GET_NEXTALL:
		while (from[++i] != NL && from[i] != '\0' && j < len - 1)
		{
			if (from[i] == ESC || from[i] == TAB)
				to[j++] = SP;
			else
				to[j++] = from[i];
		}
		break;
	case GET_HEADER:
		while (from[++i] != NL && from[i] != SP && from[i] != '\0' && j < len - 1)
		{
			if (from[i] == ESC || from[i] == TAB)
				to[j++] = SP;
			else
				to[j++] = from[i];
		}
		break;
	case GET_PASSWD:
		while (from[++i] != NL && from[i] != '\0' && j < len - 1)
			to[j++] = from[i];
	}
	to[j] = '\0';
	return 0;
}


int
read_uudecode(w_file)
char w_file[];
{
	char r_file[STRLEN], rbuf[2048], *s;
	FILE *rfs, *wfs;
	int ok_num = 0;

	sprintf(r_file, "tmp/BMAIL.%d.UUDECODE", now);
	if (minfo.to[0] != '\0')
	{
		rename(r_file, w_file);
		return 0;
	}
	if ((rfs = fopen(r_file, "r")) == NULL || (wfs = fopen(w_file, "w")) == NULL)
	{
		fclose(rfs);
		fclose(wfs);
		return -1;
	}
	chmod(w_file, 0644);

	while (mygets(rbuf, sizeof(rbuf), rfs) != NULL)
	{
		if (ok_num >= 5)
		{
			fputs(rbuf, wfs);
			continue;
		}

		if (minfo.type == '\0' && (s = strstr(rbuf, "#type:")) != NULL)
		{
			ok_num++;
			if (strstr(s, "mail"))
				minfo.type = 'm';
			else
				minfo.type = 'p';
		}
		else if (minfo.name[0] == '\0' && (s = strstr(rbuf, "#name:")) != NULL)
		{
			ok_num++;
			next_arg(s, minfo.name, sizeof(minfo.name), GET_HEADER);
		}
		else if (minfo.passwd[0] == '\0' && (s = strstr(rbuf, "#password:")) != NULL)
		{
			ok_num++;
			next_arg(s, minfo.passwd, sizeof(minfo.passwd), GET_PASSWD);
		}
		else if (minfo.board[0] == '\0' && (s = strstr(rbuf, "#board:")) != NULL)
		{
			ok_num++;
			next_arg(s, minfo.board, sizeof(minfo.board), GET_HEADER);
		}
		else if (minfo.title[0] == '\0' &&
			 ((s = strstr(rbuf, "#title:")) != NULL || (s = strstr(rbuf, "#subject:")) != NULL))
		{
			ok_num++;
			next_arg(s, minfo.title, sizeof(minfo.title), GET_NEXTALL);
		}
		else
		{
			if (minfo.name[0] != '\0' && minfo.passwd[0] != '\0' &&
			    minfo.board[0] != '\0' && minfo.title[0] != '\0')
			{
				ok_num = 5;
			}
			fputs(rbuf, wfs);
		}
	}
	fclose(rfs);
	fclose(wfs);
	unlink(r_file);
	return 0;
}


int
increase_user_postnum(userid)
char userid[];
{
	int fd;
	USEREC urc;

	sethomefile(genbuf, userid, UFNAME_PASSWDS);
	if ((fd = open(genbuf, O_RDWR)) > 0)
	{
		if (read(fd, &urc, sizeof(urc)) == sizeof(urc))
		{
			urc.numposts++;
			if (lseek(fd, 0, SEEK_SET) != -1)
			{
				if (write(fd, &urc, sizeof(urc)) == sizeof(urc))
				{
					close(fd);
					return 0;
				}
			}
		}
		close(fd);
	}
	return -1;
}


USEREC user;

int
do_sign(r_file)
char r_file[];
{
	FILE *fpr, *fpw;
	int line;
	char filename[PATHLEN];

	sethomefile(filename, minfo.name, UFNAME_SIGNATURES);
	if ((fpr = fopen(r_file, "r")) == NULL)
		return -1;
	if ((fpw = fopen(filename, "w")) == NULL)
	{
		fclose(fpr);
		return -1;
	}

	line = 0;
	while (line < (MAX_SIG_LINES * MAX_SIG_NUM) 
	       && mygets(genbuf, sizeof(genbuf), fpr))
	{
		if (line == 0)
		{
			if (genbuf[0] == '\n')
				continue;
		}
		fputs(genbuf, fpw);
		line++;
	}
	fclose(fpr);
	fclose(fpw);
	chmod(filename, 0644);	
	return 0;
}


int
do_plan(r_file)
char r_file[];
{
	FILE *fpr, *fpw;
	int line;
	char filename[PATHLEN];

	sethomefile(filename, minfo.name, UFNAME_PLANS);
	if ((fpr = fopen(r_file, "r")) == NULL)
		return -1;
	if ((fpw = fopen(filename, "w")) == NULL)
	{
		fclose(fpr);
		return -1;
	}

	line = 0;
	while (line < MAX_QUERY_LINES && mygets(genbuf, sizeof(genbuf), fpr))
	{
		if (line == 0)
		{
			if (genbuf[0] == '\n')
				continue;
		}
		fputs(genbuf, fpw);
		line++;
	}
	fclose(fpr);
	fclose(fpw);
	chmod(filename, 0644);	
	return 0;
}


int
do_post(r_file)
char r_file[];
{
	char path[PATHLEN], fname[PATHLEN];
	FILE *fpr, *fpw;
	char *title, *postpath;
	int treasure;
	char str[STRLEN];
	BOARDHEADER bhead;	
	char *timestr;

	if (minfo.board[0] == '\0')
		return -1;
		
	if (minfo.board[0] == '#')
	{
		strcpy(str, minfo.board + 1);
		strcpy(minfo.board, str);
		treasure = TRUE;
	}
	else
		treasure = FALSE;

	if (get_board(&bhead, minfo.board) <= 0)
		return -1;
	if (!can_see_board(&bhead, user.userlevel) 
		|| ((bhead.brdtype & BRDTYPE_IDENT) && user.ident != 7))
	{
		return -1;
	}
	if (treasure == TRUE && strcmp(minfo.name, bhead.owner))
		return -1;
		
	strcpy(minfo.board, bhead.filename);				
		
	sprintf(fname, "tmp/bbsmail_post.%d", getpid());
	if ((fpr = fopen(r_file, "r")) == NULL)
		return -1;		
	if ((fpw = fopen(fname, "w")) == NULL)
	{
		fclose(fpr);
		return -1;
	}

	if (minfo.title[0] != '\0')
		title = minfo.title;
	else if (minfo.subject[0] != '\0')
		title = minfo.subject;
	else
		title = "(no subject)";
		
	timestr = ctime(&now);	             
	*(timestr + strlen(timestr) - 1) = '\0';

	write_article_header(fpw, minfo.name, user.username, minfo.board, timestr,
	                     title, NULL);
	fputs("\n", fpw);
	while (mygets(genbuf, sizeof(genbuf), fpr))
		fputs(genbuf, fpw);
	fclose(fpr);
	
	sethomefile(genbuf, minfo.name, UFNAME_SIGNATURES);
	if ((fpr = fopen(genbuf, "r")) != NULL)
	{
		int line = 0;
		
		fputs("\n--\n", fpw);
		while (line++ < MAX_SIG_LINES && mygets(genbuf, sizeof(genbuf), fpr))
			fputs(genbuf, fpw);
		fclose(fpr);
	}
	fprintf(fpw, "[m\n");
	fclose(fpw);
	chmod(fname, 0644);

	if (treasure == TRUE)
	{
		setboardfile(path, minfo.board, NULL);
		postpath = path;
	}
	else
		postpath = NULL;

	if (PublishPost(fname, minfo.name, minfo.board, title, user.ident, 
                    NULL, TRUE, postpath) == -1)
	{
		return -1;
	}                   
	
	if (!(bhead.brdtype & BRDTYPE_NOPOSTNUM))
		increase_user_postnum(minfo.name);
		
	return 0;
}


#ifdef ANTISPAM

#define RULE  3			/* rule 2 .... 10 (����ĳ�W�L 10 ) */
#define SPAM_POOL_SIZE  512


struct spam
{
	int     hs_a;
	int     hs_b;
	int     hs_c;
	int     val;
};

struct SPAMSHM
{
	struct spam pool[SPAM_POOL_SIZE];
	time_t  mtime;	/* unused */
};


struct SPAMSHM *spamshm = NULL;

#define SPAMSHM_KEY 5123


void
resolve_spamshm()
{
	if (!spamshm)
	{
		spamshm = (void *) attach_shm(SPAMSHM_KEY, sizeof(struct SPAMSHM));
		memset(spamshm, 0, sizeof(spamshm));
	}
}


int
search_spamshm(hs_a, hs_b, hs_c)
int     hs_a;
int     hs_b;
int     hs_c;
{
	register int i;
	struct spam *sentp;

	if (hs_a == 0 && hs_b == 0 && hs_c == 0)
		return 0;
	
	resolve_spamshm();
	sentp = spamshm->pool;
	for (i = 0; i < SPAM_POOL_SIZE; i++, sentp++)
	{
		if (sentp->hs_a == hs_a && sentp->hs_b == hs_b && sentp->hs_c == hs_c)
		{
			if (sentp->val++ < 5)
				return 0;
			else
				return 1;
		}
	}
	
	for (i = 0; i < SPAM_POOL_SIZE; i++)
	{
		if (sentp->val == 0)
		{
			sentp->hs_a = hs_a;
			sentp->hs_b = hs_b;
			sentp->hs_c = hs_c;
			sentp->val = 1;
			return 0;
		}
	}

	for (i = 0; i < SPAM_POOL_SIZE; i++)
	{
		if (sentp->val <= 3)
		{
			sentp->val = 0;
			sentp->hs_a = 0;
			sentp->hs_b = 0;
			sentp->hs_c = 0;
		}
	}
	return 0;
}


int
spam_filehash(filename, hs_a, hs_b, hs_c)
char *filename;
int *hs_a, *hs_b, *hs_c;
{
	FILE *fp;
	char buf[4096];
	
	if ((fp = fopen(filename, "r")) == NULL)
		return -1;

	*hs_a = 0;
	*hs_b = 0;
	*hs_c = 0;	
	while (fgets(buf, sizeof(buf), fp))
	{
		*hs_b++;
		*hs_a = *hs_a + buf[strlen(buf) / (*hs_b % RULE)+1];
		*hs_c = *hs_c + buf[strlen(buf) / RULE];
	}
	fclose(fp);
	return 0;
}
#endif /* ANTISPAM */


int
do_mail(r_file)
char r_file[];
{
	char fn_new[PATHLEN];
	FILE *fpr, *fpw;
	int result;
	char *timestr, *title;

	sprintf(fn_new, "%s.new", r_file);
	
	if ((fpr = fopen(r_file, "r")) == NULL)
		return -1;
		
#ifdef ANTISPAM
	{
		int a, b, c;
		
		spam_filehash(r_file, &a, &b, &c);
		if (search_spamshm(a, b, c))
		{
			return -1;
		}
	}  
#endif	

	if ((fpw = fopen(fn_new, "w")) == NULL)
	{
		fclose(fpr);
		return -1;
	}

	if (minfo.title[0] != '\0')
		title = minfo.title;
	else if (minfo.subject[0] != '\0')
		title = minfo.subject;
	else
		title = "(no subject)";

	timestr = ctime(&now);
	*(timestr + strlen(timestr) - 1) = '\0';
	
	write_article_header(fpw, minfo.from, "", NULL, timestr, title, NULL);
	if (sContentType[0])	/* lthuang */
		fprintf(fpw, "%s\n", sContentType);

	fputs("\n", fpw);
	while (mygets(genbuf, sizeof(genbuf), fpr))
		fputs(genbuf, fpw);
	fputs("[m\n", fpw);
	fclose(fpr);
	fclose(fpw);
	chmod(fn_new, 0644);

	log_bbsmail("from=<%s>, to=<%s>, path=<%s>", 
	            minfo.from, minfo.name, received);	/* lthuang */
	result = SendMail_Local(fn_new, minfo.from, minfo.name, 
	                        title,  user.ident);

	unlink(fn_new);

	return result;
}


int
access_mail(r_file)
char r_file[];
{
	struct stat st;
	
	memset(&user, 0, sizeof(user));
	if (minfo.to[0] != '\0')
		strcpy(minfo.name, minfo.to);
	if (get_passwd(&user, minfo.name) <= 0)
	{
		unlink(r_file);
		return -1;
	}

	if (debug)
	{
		printf("\nMtype: [%c] Mfrom: %s Mto: %s", minfo.type, minfo.from, minfo.to);
		printf("\nMsubject: %s", minfo.subject);
		printf("\nMname: %s, Mboard: %s Mpasswd: %s", minfo.name, minfo.board, minfo.passwd);
		printf("\nMtitle: %s", minfo.title);
	}
	
	if (stat(r_file, &st) == 0 && st.st_size > MAX_MAIL_SIZE)
	{
		log_bbsmail("Err: from=<%s>, to=<%s>, size too big: %d", 
		       minfo.from, minfo.name, st.st_size);
	}		
	
	if (minfo.type == 's' && checkpasswd(user.passwd, minfo.passwd))
		do_sign(r_file);
	else if (minfo.type == 'l' && checkpasswd(user.passwd, minfo.passwd))
		do_plan(r_file);
	else if (minfo.type != 'm' && minfo.passwd[0] != '\0' &&
		 minfo.name[0] != '\0' && checkpasswd(user.passwd, minfo.passwd))
	{
		do_post(r_file);
	}
	else
		do_mail(r_file);
	unlink(r_file);
	return 0;
}


int
readin_mail(filename)
char *filename;
{
	int i, ok_num;
	char rbuf[1024], w_file[PATHLEN], *s;
	BOOL uudecode, in_header, do_uudecode, get_received = FALSE;
	FILE *fp, *fp_sys;
	int rec_len, save_rec_len;

	if ((fp_sys = fopen(filename, "r")) == NULL)
		return -1;

	i = 0;
	ok_num = 0;
	in_header = 1;
	while (mygets(rbuf, sizeof(rbuf), fp_sys))
	{
		if (in_header)
		{
			if (!strncmp(rbuf, "Received: ", 10))
			{
				char *path;

gt_rec:				
				if ((path = strstr(rbuf, "from")) != NULL)
				{
					path+= 5;

					rec_len = save_rec_len;
					received[rec_len++] = '!';

					while (*path != '\0' && *path != '\n')
					{
/*					
						if (*path == 'b' && *(path+1) == 'y')
						{
							if (*(path-1) == ' ')
								rec_len--;
							break;
						}
*/						
						received[rec_len++] = *path++;
					}
					received[rec_len] = '\0';
					if (save_rec_len == 0)
						save_rec_len = rec_len;
				}
			}
			else if (!strncmp(rbuf, "Subject: ", 9))
				next_arg(rbuf, minfo.subject, sizeof(minfo.subject), GET_NEXTALL);
			else if (!strncmp(rbuf, "Content-Type: ", 14))
				strcpy(sContentType, rbuf);
			continue;
		
		
	
		if (!strncmp(rbuf, "From ", 5))
		{
			if (ok_num != 0)
			{
				fclose(fp);
				if (do_uudecode == TRUE)
				{
					sprintf(genbuf, "bin/uudecode %s", w_file);
					system(genbuf);
					unlink(w_file);
					read_uudecode(w_file);
				}
				access_mail(w_file);
				ok_num = 0;
			}

			sprintf(w_file, "%s-%d", filename, ++i);
			if ((fp = fopen(w_file, "w")) == NULL)
			{
				fclose(fp_sys);
				return -1;
			}
			chmod(w_file, 0600);

			bzero(&minfo, sizeof(minfo));
			in_header = FALSE;
			uudecode = TRUE;			
			do_uudecode = FALSE;
			received[0] = '\0';
			rec_len = 0;
			save_rec_len = 0;
			sContentType[0] = '\0'; /* lthuang */			

			next_arg(rbuf, minfo.from, sizeof(minfo.from), GET_NEXTONE);
			continue;
		}
		else if (do_uudecode == TRUE || ok_num == 5)
		{
			fprintf(fp, "%s", rbuf);
			continue;
		}
		else if (rbuf[0] == NL && in_header == FALSE)
		{
			in_header = TRUE;
			if (minfo.to[0] == '\0')	/* lthuang */
				log_bbsmail("Err: from [%s], header 'To: ' not found", minfo.from);
			continue;
		}


		if (in_header == FALSE)
		{
			if (!strncmp(rbuf, "Received: ", 10))
			{
				if (!strncmp(rbuf, "\tfor <", 6)
				    && (s = strstr(rbuf, ".bbs@")) != NULL)
				{
					*(s--) = '\0';
					while ((*s != '<'))
						s--;
					s++;
					strncpy(minfo.to, s, sizeof(minfo.to));
					get_received = FALSE;
					continue;
				}
			
				get_received = TRUE;
				goto gt_rec;
			}
			else if ((!strncmp(rbuf, "To: ", 4)
			          || !strncmp(rbuf, "Apparently-To: ", 15))
			         && (s = strstr(rbuf, ".bbs@")) != NULL)
			{
				*(s--) = '\0';
				while (!isspace(*s))
						s--;
					s++;
					if (*s == '<')	/* lthuang */
						s++;
					strncpy(minfo.to, s, sizeof(minfo.to));
				}
			}
		}
		else if (uudecode == TRUE && !strncmp(rbuf, "begin ", 6))
		{
			do_uudecode = TRUE;
			uudecode = FALSE;
/* del by lthuang
   sprintf(rbuf, "begin 0600 %s/tmp/BMAIL.%d.UUDECODE\n", HOMEBBS, now);
 */
			sprintf(rbuf, "begin 0600 tmp/BMAIL.%d.UUDECODE\n", now);
			fprintf(fp, "%s", rbuf);
			continue;
		}
		else if (minfo.to[0] != '\0')
		{
			if (uudecode == TRUE && strlen(rbuf) > 2)
				uudecode = FALSE;
			fprintf(fp, "%s", rbuf);
			minfo.type = 'm';
			continue;
		}
		else if (minfo.type == '\0' && (s = strstr(rbuf, "#type:")) != NULL)
		{
			uudecode = FALSE;
			ok_num++;
			if (strstr(s, "mail"))
				minfo.type = 'm';
			else if (strstr(s, "sign"))
				minfo.type = 's';
			else if (strstr(s, "plan"))
				minfo.type = 'l';
			else
				minfo.type = 'p';
			continue;
		}
		else if (minfo.name[0] == '\0' && (s = strstr(rbuf, "#name:")) != NULL)
		{
			uudecode = FALSE;
			ok_num++;
			next_arg(s, minfo.name, sizeof(minfo.name), GET_HEADER);
			continue;
		}
		else if (minfo.passwd[0] == '\0' && (s = strstr(rbuf, "#password:")) != NULL)
		{
			uudecode = FALSE;
			ok_num++;
			next_arg(s, minfo.passwd, sizeof(minfo.passwd), GET_PASSWD);
			continue;
		}
		else if (minfo.board[0] == '\0' && (s = strstr(rbuf, "#board:")) != NULL)
		{
			uudecode = FALSE;
			ok_num++;
			next_arg(s, minfo.board, sizeof(minfo.board), GET_HEADER);
			continue;
		}
		else if (minfo.title[0] == '\0' && (s = strstr(rbuf, "#title:")) != NULL)
		{
			uudecode = FALSE;
			ok_num++;
			next_arg(s, minfo.title, sizeof(minfo.title), GET_NEXTALL);
			continue;
		}

		if (minfo.name[0] != '\0' && minfo.passwd[0] != '\0' && minfo.board[0] != '\0' && minfo.title[0] != '\0')
			ok_num = 5;
		fprintf(fp, "%s", rbuf);
	}
	fclose(fp);
	if (do_uudecode == TRUE)
	{
		sprintf(genbuf, "bin/uudecode %s", w_file);
		system(genbuf);
		unlink(w_file);
		read_uudecode(w_file);
	}
	access_mail(w_file);
	fclose(fp_sys);
	return 0;
}


int
main(argc, argv)
int argc;
char *argv[];
{
	char spool_tmp[PATHLEN], bbsmail_box[PATHLEN];
	struct stat st;

	if (argc == 2)
	{
		if (!strcmp(argv[1], "debug"))
			debug = 1;
	}

	sprintf(bbsmail_box, "%s/bbs", SPOOL_MAIL);
	if (stat(bbsmail_box, &st) != 0 || st.st_size == 0)
	{
		/* bbs mail spool is empty */
		exit(0);
	}
		
	now = time(0);
	
	sprintf(spool_tmp, "%s/tmp/.bbsmail.%d", HOMEBBS, now);
	if (myrename(bbsmail_box, spool_tmp) == -1)
	{
		printf("cannot rename: from %s to %s\n", bbsmail_box, spool_tmp);
		exit(1);
	}
	
	chown(spool_tmp, BBS_UID, BBS_GID);

	init_bbsenv();
	
	readin_mail(spool_tmp);
	unlink(spool_tmp);
}
