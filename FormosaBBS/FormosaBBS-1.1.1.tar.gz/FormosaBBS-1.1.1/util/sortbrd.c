/*
   Sort all of the board records in the file '.BOARDS'
   
   Li-te Huang, lthuang@cc.nsysu.edu.tw, 03/15/98
*/   

#include	"bbs.h"


int
cmp_bname(bh1, bh2)
BOARDHEADER *bh1, *bh2;
{
	return strcasecmp(bh1->filename, bh2->filename);
}


/*
  Return the number of boards
*/  
int
sortboard(filename)
char filename[];
{
	int fd, fdw;
	char fn_new[PATHLEN], fn_del[PATHLEN];
	BOARDHEADER *bhp, allbhs[MAXBOARD];
	int cnt, i;
		
	sprintf(fn_del, "%s.del", filename);
	sprintf(fn_new, "%s.new", filename);
	if ((fdw = open(fn_new, O_WRONLY | O_CREAT | O_TRUNC, 0644)) < 0)
		return -1;
		
	flock(fdw, LOCK_EX);
	if ((fd = open(filename, O_RDONLY)) < 0)
	{
		flock(fdw, LOCK_UN);
		close(fdw);
		unlink(fn_new);
		return -1;
	}
	
	bhp = allbhs;
	cnt = 0;
	while (cnt < MAXBOARD && read(fd, bhp, BH_SIZE) == BH_SIZE)
	{
		cnt++;
		bhp++;
	}
	close(fd);
	
	qsort(allbhs, cnt, BH_SIZE, cmp_bname);
	
	bhp = allbhs;
	for (i = 0; i < cnt; i++)
	{
		if (write(fdw, bhp, BH_SIZE) != BH_SIZE)
		{
			flock(fdw, LOCK_UN);
			close(fdw);
			close(fd);
			unlink(fn_new);			
			return -1;
		}
		bhp++;
	}
	flock(fdw, LOCK_UN);
	close(fdw);
	close(fd);
	if (rename(filename, fn_del) == 0)
	{
		if (rename(fn_new, filename) == 0)
			return cnt;
		rename(fn_del, filename);
	}
	unlink(fn_new);
	return -1;
}


int
main(argc, argv)
int argc;
char *argv[];
{
	int nBoards;
	char filename[PATHLEN];
	
	if (argc != 2)
	{
		fprintf(stderr, "Usage: sortbrd filename\r\n");
		exit(1);
	}
    
    xstrncpy(filename, argv[1]);
	nBoards = sortboard(filename);
	if (nBoards == -1)
	{
		fprintf(stderr, "error: sort board failed\r\n");
		exit(-1);
	}
    
    printf("\r\n%d Boards sorted.\r\n", nBoards);
    return 0;
}
