/*********************************************************/
/*                                                       */
/*  Author: �L��� gcl@cc.nsysu.edu.tw                   */
/*              �L�C�y Cauchy@cc.nsysu.eud.tw                            */
/*                                                       */
/*********************************************************/
#include "bbs.h"
#include "csbbs.h"

char MyBuffer[MAX_BUF_SIZE];
char *NextToken;
char CurrentBoard[BNAME_LEN];
/*
short talkrequest2 = FALSE;
*/
time_t start_time;

#define CATCH_CRACKER		/* by gcl, 5/28/96 */

#define CRACKFILE2 "conf/.CSBBS-CRACK-CMD"


extern DoAnnounce(), DoGetMailNumber(), DoGetMailHead(), DoGetMail(), DoSendMail(),
  DoKillMail(), DoListBoard(), DoZap(), DoGetPostNumber(), DoGetPostHead(),
  DoGetPost(), DoSendPost(), DoMailPost(), DoKillPost(), DoGetPlan(), DoSendPlan(),
  DoKillPlan(), DoGetSign(), DoSendSign(), DoKillSign(), DoChangePassword(),
  DoGetUserData(), DoChangeUserName(), DoChangeEMail(), DoMailMail(), DoListOnlineUser(),
  DoQuery(), DoPage(), DoTalk(), DoGetBoardWelcome(), DoPutBoardWelcome(),
  DoKillBoardWelcome(), DoTreasurePost(), DoTalkReply(), DoMailGroup(),
  DoListOnlineFriend(), DoGetFriend(), DoSendFriend(), DoUserCheck(), DoCheckNewMail(),
  DoUnkillPost(), DoEditPostTitle(), DoEditPost(), DoUnkillMail(),
  DoSendPostToBoards(), DoMakeDirect(), DoVersionCheck(), DoSendMsg(),
  DoAllMsg(), 
  DoMultiLogin(), DoKill(), 
  DoForward(), DoChkAnnounce(),
  DoChkBoardWelcome(), DoPostImp();

struct ProtocolJob job_table[] =
{
	{_ANNOUNCE, DoAnnounce},
	{CHKANNOUNCE, DoChkAnnounce},
	{LOGINNUM, DoMultiLogin},
	{KILLPID, DoKill},
	{MAILNUM, DoGetMailNumber},
	{MAILHEAD, DoGetMailHead},
	{MAILGET, DoGetMail},
	{MAILPUT, DoSendMail},
	{MAILKILL, DoKillMail},
	{MAILGROUP, DoMailGroup},
	{MAILNEW, DoCheckNewMail},
	{MAILUKILL, DoUnkillMail},
	{MAILMAIL, DoMailMail},
	{FORWARD, DoForward},

	{LIST, DoListBoard},
	{_ZAP, DoZap},
	{BRDWELCHK, DoChkBoardWelcome},
	{BRDWELGET, DoGetBoardWelcome},
	{BRDWELPUT, DoPutBoardWelcome},
	{BRDWELKILL, DoKillBoardWelcome},

	{POSTIMP, DoPostImp},
	{POSTNUM, DoGetPostNumber},
	{POSTHEAD, DoGetPostHead},
	{POSTGET, DoGetPost},
	{POSTPUT, DoSendPost},
	{POSTKILL, DoKillPost},
	{POSTMAIL, DoMailPost},
	{POSTTRE, DoTreasurePost},
	{POSTUKILL, DoUnkillPost},
	{POSTETITLE, DoEditPostTitle},
	{POSTEDIT, DoEditPost},
	{POSTMPUT, DoSendPostToBoards},

	{PLANGET, DoGetPlan},
	{PLANPUT, DoSendPlan},
	{PLANKILL, DoKillPlan},
	{SIGNGET, DoGetSign},
	{SIGNPUT, DoSendSign},
	{SIGNKILL, DoKillSign},
	{CHGPASSWD, DoChangePassword},
	{USERGET, DoGetUserData},
	{CHGNAME, DoChangeUserName},
	{CHGEMAIL, DoChangeEMail},

	{LISTUSER, DoListOnlineUser},
	{_PAGE, DoPage},
	{_QUERY, DoQuery},
	{TALKTO, DoTalk},
	{TALKREP, DoTalkReply},
	{TALKSTOP, NULL},
	{TALKREP, NULL},
	{ISAY, NULL},
	{IKEY, NULL},
	{LISTFUSER, DoListOnlineFriend},
	{SENDMESG, DoSendMsg},
	{ALLMESG, DoAllMsg},

	{FRIENDGET, DoGetFriend},
	{FRIENDPUT, DoSendFriend},

	{CHATSAY, NULL},
	{CHATSTOP, NULL},

	{USERCHK, DoUserCheck},
	{VERCHK, DoVersionCheck},
	{MAKEDIR, DoMakeDirect},
	};


FormosaExit()
{
	close_all_ftable();
	if (ifPass)
		user_logout(cutmp, &curuser);
	ReleaseSocket();
	exit(0);
}

short get_message = FALSE;

Formosa()
{
	char keyword[MAX_KEYWORD_LEN + 1], *cert_name, *cert_passwd;
	int keyno;
	int i, para_num;
	time_t idle_time, now_time, lmj_idle;


	SayHello();
	time(&start_time);

	while (1)
	{
		time(&now_time);
		idle_time = now_time - start_time;
		if (idle_time > 1800)
			FormosaExit();
/* �o�Ӧ����D�A��� net_gets --- lmj
   i = my_read(0, MyBuffer, sizeof(MyBuffer), 1800);
   if (i <= 0)
 */
		if (net_gets(0, MyBuffer, sizeof(MyBuffer)))	/* lmj */
			lmj_idle = time(0);
		else
		{
/*************************************
			if (talkrequest2 == TRUE)
			{
				talkreply();
				time(&start_time);
			}
			else if (get_message = TRUE)
			{
				send_message();
			}
****************************************/
			if (time(0) - lmj_idle > 1800)	/* �o�� idle timeout ���n *lmj */
				FormosaExit();
			continue;
		}

		NextToken = GetToken(MyBuffer, keyword, MAX_KEYWORD_LEN);
		if (keyword[0] == '\0')
			continue;
		keyno = GetKeywordNo(keyword);
		SetParameter(NextToken);	/* �]�w�ѼƦ�linklist */
		switch (keyno)
		{
		case -1:
			if (!debug)
				AppendError(0);		/* maybe cracker */
			else
				RespondProtocol(UNKNOW_CMD);
			break;
		case HELLO:
			DoHello();
			break;
		case VERCHK:
			if (!ifSayHello)
				RespondProtocol(NOT_SAY_HELLO);
			else
			{
				DoVersionCheck();
			}
			break;
		case _BBSNAME:
			DoBBSName();
			break;
		case USERLOG:
			if (!ifSayHello)
				RespondProtocol(NOT_SAY_HELLO);
			else if (ifPass)
				RespondProtocol(WORK_ERROR);
			else
				DoUserLogin();
			ifCert = FALSE;
			break;
		case CERTILOG:
			if (!ifSayHello)
				RespondProtocol(NOT_SAY_HELLO);
			else if (ifCert)
				RespondProtocol(WORK_ERROR);
			else
			{
				para_num = Get_paras();
				if (para_num < 2)
					RespondProtocol(WORK_ERROR);
				else
				{
					cert_name = Get_para_string(1);
					cert_passwd = Get_para_string(2);
					if (!DoCertiLogin(cert_name, cert_passwd))
					{
						RespondProtocol(PASSWORD_ERROR);
						FormosaExit();
					}
					else
					{
						RespondProtocol(OK_CMD);
						ifCert = TRUE;
					}
				}
			}
			break;
		case ALOWNEW:
			if (ifSayHello)
				DoAllowNew();
			else
				RespondProtocol(NOT_SAY_HELLO);
			break;
		case USERCHK:
			if (ifSayHello)
				DoUserCheck();
			else
				RespondProtocol(NOT_SAY_HELLO);
			break;
		case USERNEW:
			if (!ifSayHello)
				RespondProtocol(NOT_SAY_HELLO);
			else if (ifPass)
				RespondProtocol(WORK_ERROR);
			else
				DoNewLogin();
			break;
		case BBSINFO:
			if (!ifSayHello)
				RespondProtocol(NOT_SAY_HELLO);
			else
			{
				DoAskBBSInformation();
			}
			break;
		case _QUIT:
			FormosaExit();
			break;
		default:
			if (ifPass || ifCert)	/* lthuang */
			{
				for (i = 0; i < sizeof(job_table) / sizeof(struct ProtocolJob); i++)
				{
					if (job_table[i].KeyNo == keyno)
					{
						if (job_table[i].FunPtr != NULL)
							job_table[i].FunPtr();
						break;
					}
				}
				if (i >= sizeof(job_table) / sizeof(struct ProtocolJob))
					  RespondProtocol(UNKNOW_CMD);
				time(&start_time);
			}
			else
				RespondProtocol(USER_NOT_LOGIN);
		}
	}
}

void 
TalkPage()
{
	talkreply();
	signal(SIGUSR1, TalkPage);
	time(&start_time);
/**
	talkrequest = TRUE;
	talkrequest2 = TRUE;
**/
}

void 
write_request()
{
	send_message();
	signal(SIGUSR2, write_request);
/*
   get_message = TRUE;
 */
}

send_message()
{
	FILE *fp;
	char buffer[100];
	char callin_rmesg[100];

	get_message = FALSE;
	sprintf(buffer, "write/%s", curuser.userid);	/* lasehu */
	if (fp = fopen(buffer, "r"))
	{
		for (;;)
		{
			if (fgets(buffer, sizeof(buffer), fp) == NULL)
				break;
			strcpy(callin_rmesg, buffer);
		}
		fclose(fp);
		inet_printf("%d\t%s\r\n", MSG_REQUEST, callin_rmesg);
	}
}


AppendError(int State)
{
	FILE *fp;
	time_t t;

	if (State == 0)
	{
		if ((fp = fopen(CRACKFILE, "a")) == NULL)
			return;
		t = time(0);
		fprintf(fp, "Cracker from %s at %s \n", from, ctime(&t));
		fclose(fp);
		FormosaExit();
	}
}

AppendCrackerRecord(char *Cmd)
{
	FILE *fp;
	time_t t;
	char buf[80];

	if ((fp = fopen(CRACKFILE2, "a")) == NULL)
		return;
	t = time(0);
	strncpy(buf, Cmd, 80);
	buf[79] = '\0';
	fprintf(fp, "%s (%s) %s\n", curuser.userid, ctime(&t), buf);
	fclose(fp);
}
