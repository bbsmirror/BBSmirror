
#include "bbs.h"
#include "csbbs.h"

int trea_level = 1;

struct BoardList *search_board(char *);

/***************************************************************
*		POSTIMP boardname postnum
*			�аO�����n�G�i �u���@��ϻݭn
****************************************************************/
DoPostImp()
{
	int idx, num;
	int fd;
	FILEHEADER fileinfo;

	if (!SelectBoard(Get_para_string(1), 0))
		return;

	idx = Get_para_number(2);
	if (idx < 1)
	{
		RespondProtocol(POST_NOT_EXIST);
		return;
	}

	num = get_num_records(boarddirect, FH_SIZE);	/* get post count */
	if (idx > num)
	{
		RespondProtocol(POST_NOT_EXIST);
		return;
	}

	if (strcmp(CurBList->owner, curuser.userid) && curuser.userlevel < 255)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}


	if ((fd = open(boarddirect, O_RDWR)) < 0)
	{			/*�}�ҧG�i�ϸ����.DIR */
		RespondProtocol(WORK_ERROR);
		return;
	}

	if (lseek(fd, (long) (FH_SIZE * (idx - 1)), SEEK_SET) == -1)
	{
		RespondProtocol(WORK_ERROR);
		close(fd);
		return;
	}

	if (read(fd, &fileinfo, FH_SIZE) == FH_SIZE)
	{
		if (fileinfo.accessed == FILE_RESRV)
			fileinfo.accessed = 0;
		else
			fileinfo.accessed = FILE_RESRV;
	}

	if (lseek(fd, -(FH_SIZE), SEEK_CUR) == -1)
	{
		RespondProtocol(WORK_ERROR);
		close(fd);
		return;
	}

	if (write(fd, &fileinfo, FH_SIZE) == FH_SIZE)
	{
		RespondProtocol(OK_CMD);
		close(fd);
		return;
	}
	RespondProtocol(WORK_ERROR);
	close(fd);
}

/***************************************************************
*		POSTNUM boardname type [PATH level1 level2 .. ]
*			���o�G�i�� �G�i�W�� �]0 �@���  1 ��ذϡ^	
****************************************************************/
DoGetPostNumber()
{
	int num;
	char *BoardName;
	struct BoardList *blist;

	BoardName = Get_para_string(1);
	if (!SelectBoard(BoardName, Get_para_number(2)))
		return;

	if (!(blist = search_board(BoardName)))
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}

	ReadRC_Init(BoardName, blist->bid, curuser.userid);
	strcpy(CurrentBoard, BoardName);
	ReadRC_Refresh(CurrentBoard, blist->rewind_time, blist->firstartno);
	num = get_num_records(boarddirect, FH_SIZE);	/* get post count */

	inet_printf("%d\t%d\r\n", POST_NUM_IS, num);
}


/*****************************************************
 *   Syntax: POSTHEAD boardname type startnum [endnum]
 *
 *  Respond: PostNum State-Condition Owner Date Subject
 *
 *****************************************************/
DoGetPostHead()
{
	int start, end, num, fd, c, i, accessed;
	FILEHEADER fileinfo;
	char post_state, chdate[6];
	time_t date;

	if (!SelectBoard(Get_para_string(1), Get_para_number(2)))
		return;

	start = Get_para_number(3);
	if (start < 1)
	{
		RespondProtocol(POST_NOT_EXIST);
		return;
	}

	end = Get_para_number(4);
	if (end == 0)
		end = start;
	else if (end < start)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	num = get_num_records(boarddirect, FH_SIZE);	/* get post count */

	if (start > (num) || end > (num))
	{
		RespondProtocol(POST_NOT_EXIST);
		return;
	}

	if ((fd = open(boarddirect, O_RDWR)) < 0)
	{			/*�}�ҧG�i�ϸ����.DIR */
		RespondProtocol(WORK_ERROR);
		return;
	}

	if (lseek(fd, (long) (FH_SIZE * (start - 1)), SEEK_SET) == -1)
	{
		RespondProtocol(WORK_ERROR);
		close(fd);
		return;
	}

	RespondProtocol(OK_CMD);
	net_cache_init();
	for (i = start; i <= end; i++)
	{
		if (read(fd, &fileinfo, FH_SIZE) == FH_SIZE)
		{
			accessed = ReadRC_UnRead(i);
			if (fileinfo.accessed & FILE_DELE)
				post_state = 'D';	/* deleted post */
			else if (fileinfo.accessed & FILE_TREA)
				post_state = 'T';
			else if (fileinfo.accessed & FILE_RESRV)
				post_state = 'E';
			else if (!ReadRC_UnRead(fileinfo.artno))
				post_state = 'R';	/* readed post */
			else
				post_state = 'N';	/* new post */

			if (post_state == 'T')
			{
				c = '0';
				strcpy(fileinfo.owner, "�m�ؿ��n");
				strcpy(chdate, "00/00");
			}
			else
			{
				c = (curuser.ident == 7) ? fileinfo.ident + '0' : '*';
				date = atol((fileinfo.filename) + 2);
				strftime(chdate, 6, "%m/%d", localtime(&date));
				if (post_state == 'D')
					strcpy(fileinfo.title, "");
			}

			sprintf(MyBuffer, "%d\t%c\t%c\t%s\t%s\t%s\r\n",
				i, post_state, c, fileinfo.owner, chdate, fileinfo.title);
			net_cache_write(MyBuffer, strlen(MyBuffer));
		}
		else
			break;
	}
	close(fd);
	net_cache_write(".\r\n", 3);	/* end */
	net_cache_refresh();
}

int
get_trea_number(void)
{
	int fd, t_num;
	FILEHEADER fileinfo;

	if ((fd = open(boarddirect, O_RDWR)) < 0)
		return 0;

	t_num = 0;
	for (;;)
	{
		read(fd, &fileinfo, FH_SIZE);
		if (fileinfo.accessed == FILE_TREA)
			t_num++;
		else
			break;
	}
	close(fd);
	return t_num;
}

/*****************************************************
 *  Syntax: POSTGET boardname type postnum
 *****************************************************/
DoGetPost()
{
	int idx, num, fd, t_num;
	char *p, genbuf[STRLEN];
	FILEHEADER fileinfo;


	if (!SelectBoard(Get_para_string(1), Get_para_number(2)))
		return;

	idx = Get_para_number(3);
	if (idx < 0)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	num = get_num_records(boarddirect, FH_SIZE);	/* get post count */
	t_num = get_trea_number();

	if (idx > num)
	{
		RespondProtocol(POST_NOT_EXIST);
		return;
	}

	if (idx <= t_num)
	{
		RespondProtocol(NOT_POST);
		return;
	}
	else
	{
		if ((fd = open(boarddirect, O_RDWR)) < 0)
		{
			RespondProtocol(WORK_ERROR);
			return;
		}

		if (lseek(fd, (long) (FH_SIZE * (idx - 1)), SEEK_SET) == -1)
		{
			RespondProtocol(WORK_ERROR);
			close(fd);
			return;
		}

		if (read(fd, &fileinfo, FH_SIZE) != FH_SIZE)
		{
			close(fd);
			RespondProtocol(WORK_ERROR);
			return;
		}
		if (fileinfo.accessed & FILE_DELE)
		{
			close(fd);
			RespondProtocol(POST_NOT_EXIST);
			return;
		}
		if (lseek(fd, -sizeof(fileinfo), SEEK_CUR) == -1)
		{
			close(fd);
			RespondProtocol(WORK_ERROR);
			return;
		}

		ReadRC_Addlist(fileinfo.artno);
		ReadRC_Update();
		write(fd, &fileinfo, FH_SIZE);
		close(fd);

		strcpy(genbuf, boarddirect);
		p = strrchr(genbuf, '/') + 1;
		strcpy(p, fileinfo.filename);
		SendArticle(genbuf, TRUE);
	}
}

/*****************************************************
 *		POSTPUT boardname type   sign    news title
 *		�e�X�G�i �G�i�W�� ��ذ� ñ�W�� 
 *			              0/1    0-3	
 *****************************************************/
DoSendPost()
{
	char *bname, *title, *p, *news;
	struct BoardList *blist;
	char fname[STRLEN], path[PATHLEN];
	int type, sign;


	bname = Get_para_string(1);
	if (bname == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
	{			/* �p�G�ϥΪ̬� guest �n�� */
		if (strcmp(bname, "sysop") && strcmp(bname, "test"))
		{
			RespondProtocol(WORK_ERROR);
			return;
		}
	}

	if (!check_board_list())
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}
	if ((blist = search_board(bname)) == NULL)
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}
	if (!can_post_board(blist))
	{
		RespondProtocol(POST_NOT_ALLOW);
		return;
	}

	type = Get_para_number(2);
	if ((type != 0) && (type != 1))
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}
	if (!SelectBoard(bname, type))
		return;

	if (type == 1 && strcmp(blist->owner, curuser.userid) != 0
	    && curuser.userlevel < 255)
	{
		RespondProtocol(POST_NOT_ALLOW);
		return;
	}

	sign = Get_para_number(3);
	if ((sign < 0) || (sign > 3))
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	news = Get_para_string(4);
	if ((*news != 'Y') && (*news != 'N'))
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	title = Get_para_string(5);
	if (title != NULL)
		chk_str2(title);
	else
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	sprintf(fname, "tmp/%-s.%-d", curuser.userid, time(0));
	if (RecvArticle(fname, FALSE, bname, title) == 0)
	{
		if ((sign >= 1) && (sign <= 3))
			include_sig(curuser.userid, fname, sign);

		include_tag(fname);	/* �bpost�᭱�[�W�ӷ�... */
		strcpy(path, boarddirect);
		p = strrchr(path, '/');
		*p = '\0';

		if (do_article(fname, path, curuser.userid, title, FALSE))
			RespondProtocol(WORK_ERROR);
		else
		{
			if (type != 1 && *news == 'Y' &&	/* send to news */
/*            
   (blist->type=='B' || blist->type=='O') &&
 */
			    (blist->brdtype & BRDTYPE_NEWS) &&
			    curuser.numlogins >= LOGIN_NUMBER)
			{
				p = strrchr(path, '/') + 1;
				append_news(bname, p, 'S');
			}
			if (strstr(path, "test") == NULL)
				curuser.numposts++;
			unlink(fname);
			RespondProtocol(OK_CMD);
		}
	}
	else
		RespondProtocol(WORK_ERROR);
}

/*****************************************************
 *  Syntax: POSTMAIL  boardname type postnum  to
 *****************************************************/
DoMailPost()
{
	int idx, num, fd, ms, ch;
	char *to, fname[STRLEN], *p;
	FILEHEADER fileinfo;

	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
	{			/* �p�G�ϥΪ̬� guest �n�� */
		RespondProtocol(WORK_ERROR);
		return;
	}

	if (!SelectBoard(Get_para_string(1), Get_para_number(2)))
		return;

	idx = Get_para_number(3);
	if (idx < 1)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	to = Get_para_string(4);
	if (to == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	num = get_num_records(boarddirect, FH_SIZE);	/* get post count */

	if (idx > num)
	{
		RespondProtocol(POST_NOT_EXIST);
		return;
	}

	if ((fd = open(boarddirect, O_RDWR)) < 0)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	if (lseek(fd, (long) (FH_SIZE * (idx - 1)), SEEK_SET) == -1)
	{
		RespondProtocol(WORK_ERROR);
		close(fd);
		return;
	}

	if (read(fd, &fileinfo, FH_SIZE) != FH_SIZE)
	{
		close(fd);
		RespondProtocol(WORK_ERROR);
		return;
	}
	close(fd);

	if (fileinfo.accessed == FILE_DELE)
	{
		RespondProtocol(POST_NOT_EXIST);
		return;
	}

	strcpy(fname, boarddirect);
	p = strrchr(fname, '/') + 1;
	strcpy(p, fileinfo.filename);

	if ((ms = create_mail_socket()) > 0)
	{
		char fromTmp[STRLEN];

		sprintf(fromTmp, "%-s.bbs@%-s", curuser.userid, MYHOSTNAME);
		ch = DirectSMTPMail(ms, fname, fromTmp, to, fileinfo.title);
		close_mail_socket(ms);
	}
	else
		ch = -1;

	if (ch)
		RespondProtocol(WORK_ERROR);
	else
		RespondProtocol(OK_CMD);
}

/*****************************************************
 *  Syntax: POSTKILL  boardname type postnum
 *****************************************************/
DoKillPost()
{
	int idx, num, t_num, fd, ftemp, i;
	FILEHEADER fileinfo;
	char temp_name[STRLEN], *p;
	char buf[FH_SIZE];

	if (!SelectBoard(Get_para_string(1), Get_para_number(2)))
		return;

	idx = Get_para_number(3);
	if (idx < 1)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	num = get_num_records(boarddirect, FH_SIZE);	/* get post count */
	t_num = get_trea_number();

	if (idx > num)
	{
		RespondProtocol(POST_NOT_EXIST);
		return;
	}

	if (!BoardHelper(CurBList->name) && !in_board && strcmp(CurBList->owner, curuser.userid) && curuser.userlevel < 255)
	{
		RespondProtocol(KILL_NOT_ALLOW);
		return;
	}

	if (!can_post_board(CurBList))
	{
		RespondProtocol(KILL_NOT_ALLOW);
		return;
	}

	if (idx > t_num)	/* �R���G�i */
	{
		if ((fd = open(boarddirect, O_RDWR)) < 0)
		{
			RespondProtocol(WORK_ERROR);
			return;
		}

		if (lseek(fd, (long) (FH_SIZE * (idx - 1)), SEEK_SET) == -1)
		{
			RespondProtocol(WORK_ERROR);
			close(fd);
			return;
		}

		if (read(fd, &fileinfo, FH_SIZE) != FH_SIZE)
		{
			close(fd);
			RespondProtocol(WORK_ERROR);
			return;
		}
		close(fd);

		if (strcmp(fileinfo.owner, curuser.userid) &&
		    !BoardHelper(CurBList->name) &&
		    strcmp(CurBList->owner, curuser.userid) && curuser.userlevel < 255)
		{
			RespondProtocol(KILL_NOT_ALLOW);
			return;
		}

		if (fileinfo.accessed & FILE_DELE)
		{
			RespondProtocol(OK_CMD);
			return;
		}

		if (!delete_one_article(idx, &fileinfo, boarddirect, curuser.userid, 'd'))
			RespondProtocol(OK_CMD);
		else
			RespondProtocol(WORK_ERROR);
	}
	else
		/* �R���ؿ� */
	{
		if ((fd = open(boarddirect, O_RDWR)) < 0)
		{
			RespondProtocol(WORK_ERROR);
			return;
		}
		strcpy(temp_name, boarddirect);
		strcat(temp_name, ".tmp");
		if ((ftemp = open(temp_name, O_WRONLY | O_CREAT, 0644)) < 0)
		{
			RespondProtocol(WORK_ERROR);
			return;
		}
		for (i = 1; i < idx; i++)
		{
			read(fd, buf, FH_SIZE);
			write(ftemp, buf, FH_SIZE);
		}
		if (read(fd, &fileinfo, FH_SIZE) != FH_SIZE)
		{
			RespondProtocol(WORK_ERROR);
			close(fd);
			close(ftemp);
			return;
		}
		for (i = idx + 1; i <= num; i++)
		{
			read(fd, buf, FH_SIZE);
			write(ftemp, buf, FH_SIZE);
		}
		close(fd);
		close(ftemp);
		rename(temp_name, boarddirect);
		strcpy(buf, boarddirect);
		p = strrchr(buf, '/');
		*p = '\0';
		sprintf(temp_name, "%s%s", buf, fileinfo.filename);
		myunlink(temp_name);
		RespondProtocol(OK_CMD);
	}

}

/*****************************************************
 *  Syntax: POSTTRE  boardname postnum
 *****************************************************/
DoTreasurePost()
{
	int num, idx;
	int fd;
	char fname[STRLEN], tpath[STRLEN];
	char *p;
	FILEHEADER fileinfo;

	if (!SelectBoard(Get_para_string(1), 0))
		return;

	if (!in_board)
	{
		RespondProtocol(POST_NOT_ALLOW);
		return;
	}

	if (strcmp(curuser.userid, CurBList->owner) &&
	    curuser.userlevel < 255 && !BoardHelper(CurBList->name))
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	idx = Get_para_number(2);
	if (idx < 1)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	num = get_num_records(boarddirect, FH_SIZE);	/* get post count */

	if (idx > num)
	{
		RespondProtocol(POST_NOT_EXIST);
		return;
	}

	if ((fd = open(boarddirect, O_RDWR)) < 0)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}
	if (lseek(fd, (long) (FH_SIZE * (idx - 1)), SEEK_SET) == -1)
	{
		RespondProtocol(WORK_ERROR);
		close(fd);
		return;
	}

	if (read(fd, &fileinfo, FH_SIZE) != FH_SIZE)
	{
		close(fd);
		RespondProtocol(WORK_ERROR);
		return;
	}

	if (fileinfo.accessed & FILE_DELE)
	{
		close(fd);
		RespondProtocol(POST_NOT_EXIST);
		return;
	}

	close(fd);
	strcpy(fname, boarddirect);
	SelectBoard(Get_para_string(1), 1);
	strcpy(tpath, boarddirect);
	p = strrchr(tpath, '/');
	*p = '\0';
	p = strrchr(fname, '/') + 1;
	strcpy(p, fileinfo.filename);
	if (do_article(fname, tpath, fileinfo.owner, fileinfo.title, FALSE))
		RespondProtocol(WORK_ERROR);
	else
		RespondProtocol(OK_CMD);
}

/*****************************************************
 *  Syntax: POSTUKILL  boardname type postnum
 *****************************************************/
DoUnkillPost()
{
	int num, idx, t_num = 0;
	int fd;
	FILEHEADER fileinfo;
	char post_state;

	if (!SelectBoard(Get_para_string(1), Get_para_number(2)))
		return;

	idx = Get_para_number(3);
	if (idx < 1)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	num = get_num_records(boarddirect, FH_SIZE);	/* get post count */

	/* get treasure count */
	t_num = get_trea_number();

	if (idx > num)
	{
		RespondProtocol(POST_NOT_EXIST);
		return;
	}

	if (!in_board && strcmp(CurBList->owner, curuser.userid) &&
	    curuser.userlevel < 255 && !BoardHelper(CurBList->name))
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	if (!can_post_board(CurBList))
	{
		RespondProtocol(WORK_ERROR);
		return;
	}


	if ((fd = open(boarddirect, O_RDWR)) < 0)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	if (lseek(fd, (long) (FH_SIZE * (idx - 1)), SEEK_SET) == -1)
	{
		RespondProtocol(WORK_ERROR);
		close(fd);
		return;
	}

	if (read(fd, &fileinfo, FH_SIZE) != FH_SIZE)
	{
		close(fd);
		RespondProtocol(WORK_ERROR);
		return;
	}
	close(fd);

	if (strcmp(CurBList->owner, curuser.userid) && curuser.userlevel < 255 &&
	    !BoardHelper(CurBList->name))
	{
		RespondProtocol(KILL_NOT_ALLOW);
		return;
	}

	if (fileinfo.accessed & FILE_READ)
		post_state = 'R';	/* readed post */
	else
		post_state = 'N';	/* new post */

	if (!(fileinfo.accessed & FILE_DELE))
	{
		inet_printf("%d\t%c\t%s\r\n", OK_CMD, post_state, fileinfo.title);	/* respond title */
		return;
	}

	if (!delete_one_article(idx, &fileinfo, boarddirect, curuser.userid, 'u'))
	{
		inet_printf("%d\t%c\t%s\r\n", OK_CMD, post_state, fileinfo.title);	/* respond title */
	}
	else
		RespondProtocol(WORK_ERROR);

}

/*****************************************************
 *  Syntax: POSTETITLE  boardname type postnum postowner newtitle
 *****************************************************/
DoEditPostTitle()
{
	int num, idx, t_num;
	int fd;
	FILEHEADER fileinfo;
	char *title, *owner;

	if (!SelectBoard(Get_para_string(1), Get_para_number(2)))
		return;

	idx = Get_para_number(3);
	if (idx < 1)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	/* get post count */
	num = get_num_records(boarddirect, FH_SIZE);	/* get post count */

	/* get treasure count */
	t_num = get_trea_number();

	if (idx > num)		/* idx�j���`�G�i�� */
	{
		RespondProtocol(POST_NOT_EXIST);
		return;
	}

	owner = Get_para_string(4);
	if (curuser.userlevel != 255)	/* Only sysop can change owner */
		*owner = '\0';

	title = Get_para_string(5);
	if (title != NULL)	/* get title */
		chk_str2(title);
	else
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}
	if ((fd = open(boarddirect, O_RDWR)) < 0)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	if (lseek(fd, (long) (FH_SIZE * (idx - 1)), SEEK_SET) == -1)
	{
		RespondProtocol(WORK_ERROR);
		close(fd);
		return;
	}
	if (read(fd, &fileinfo, FH_SIZE) != FH_SIZE)
	{
		close(fd);
		RespondProtocol(WORK_ERROR);
		return;
	}
	if (strcmp(curuser.userid, fileinfo.owner) &&
	    curuser.userlevel < 100 && !BoardHelper(CurBList->name))
	{
		close(fd);
		RespondProtocol(WORK_ERROR);
		return;
	}
	if (*owner)
		strcpy(fileinfo.owner, owner);
	strcpy(fileinfo.title, title);
	if (lseek(fd, (long) (FH_SIZE * (idx - 1)), SEEK_SET) == -1)
	{
		RespondProtocol(WORK_ERROR);
		close(fd);
		return;
	}
	flock(fd, LOCK_EX);
	write(fd, &fileinfo, FH_SIZE);
	flock(fd, LOCK_UN);
	close(fd);
	inet_printf("%d\t%s\r\n", OK_CMD, title);

}

/*****************************************************
 *  Syntax: POSTEDIT  boardname postnum treasure-sign
 *                                       (Y/N)
 *		POSTEDIT boardname type postnum sign
 *****************************************************/
DoEditPost()
{
	char *bname, fname[STRLEN], path[STRLEN];
	int t_num;		/* t_num  ���h���ؿ��� */
	struct BoardList *blist;
	char *p;
	int num, idx, type, sign;
	int fd;
	FILEHEADER fileinfo;

	bname = Get_para_string(1);
	if (bname == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}
	if (!check_board_list())
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}
	if ((blist = search_board(bname)) == NULL)
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}

	if (!can_post_board(blist))
	{
		RespondProtocol(POST_NOT_ALLOW);
		return;
	}

	type = Get_para_number(2);
	if ((type != 0) && (type != 1))
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}
	SelectBoard(bname, type);

	idx = Get_para_number(3);
	if (idx < 1)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	sign = Get_para_number(4);
	if ((sign < 0) || (sign > 3))
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	if (type == 1 && strcmp(blist->owner, curuser.userid) != 0
	    && curuser.userlevel < 255)
	{
		RespondProtocol(POST_NOT_ALLOW);
		return;
	}

	t_num = get_trea_number();

	if ((fd = open(boarddirect, O_RDWR)) < 0)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	if (lseek(fd, (long) (FH_SIZE * (idx - 1)), SEEK_SET) == -1)
	{
		RespondProtocol(WORK_ERROR);
		close(fd);
		return;
	}

	if (read(fd, &fileinfo, FH_SIZE) != FH_SIZE)
	{
		close(fd);
		RespondProtocol(WORK_ERROR);
		return;
	}

	if ((curuser.userlevel < 255) &&
	    ((strcmp(blist->owner, curuser.userid) != 0) &&
	     (strcmp(fileinfo.owner, curuser.userid) != 0)))
	{
		close(fd);
		RespondProtocol(WORK_ERROR);
		return;
	}
	close(fd);

	num = get_num_records(boarddirect, FH_SIZE);	/* get post count */

	if (idx > num)
	{
		RespondProtocol(POST_NOT_EXIST);
		return;
	}

	sprintf(fname, "tmp/%-s.%-d", curuser.userid, time(0));

	if (RecvArticle(fname, FALSE, NULL, NULL) == 0)
	{
		if ((sign >= 1) && (sign <= 3))
			include_sig(curuser.userid, fname, sign);
		strcpy(path, boarddirect);
		p = strrchr(path, '/');
		*p = '\0';
		sprintf(path, "%s/%s", path, fileinfo.filename);

		unlink(path);
		if (mycp(fname, path) < 0)
		{
			RespondProtocol(WORK_ERROR);
			return;
		}
		unlink(fname);
		RespondProtocol(OK_CMD);
	}
	else
		RespondProtocol(WORK_ERROR);
}

/*****************************************************
 *		POSTMPUT sign news title
 *****************************************************/
DoSendPostToBoards()
{
	char bname[STRLEN], *title, fname[STRLEN], path[STRLEN];
	struct BoardList *blist;
	char *p, *news;
	char *mboards[MAX_MULTI_BOARDS];
	int mcount, i, sign;

	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
	{			/* �p�G�ϥΪ̬� guest �n�� */
		RespondProtocol(WORK_ERROR);
		return;
	}

	sign = Get_para_number(1);
	if ((sign < 0) || (sign > 3))
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	news = Get_para_string(2);
	if ((*news != 'Y') && (*news != 'N'))
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	title = Get_para_string(3);
	if (title != NULL)
		chk_str2(title);
	else
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	mcount = 0;
	for (i = 0; i < MAX_MULTI_BOARDS; i++)
		mboards[i] = (char *) NULL;

	RespondProtocol(OK_CMD);
	make_blist();
	while (1)
	{
		if (inet_gets(bname, STRLEN - 1) < 0)
			FormosaExit();

		if (bname[0] == '.' && bname[1] == '\0')	/* if end */
			break;

		if (mcount < MAX_MULTI_BOARDS && *bname != 0)
		{
			if ((blist = search_board(bname)) == NULL)
			{
				for (i = 0; i < mcount; i++)
					free(mboards[i]);
				RespondProtocol(BOARD_NOT_EXIST);
				return;
			}
			else if (!can_post_board(blist))
			{
				for (i = 0; i < mcount; i++)
					free(mboards[i]);
				RespondProtocol(POST_NOT_ALLOW);
				return;
			}
			else
			{
				mboards[mcount] = (char *) malloc(strlen(bname) + 1);
				strcpy(mboards[mcount], bname);
				mcount++;
				RespondProtocol(OK_CMD);
			}
		}
		else
		{
			for (i = 0; i < mcount; i++)
				free(mboards[i]);
			RespondProtocol(WORK_ERROR);
			return;
		}
	}

	if (mcount == 0)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}


	sprintf(fname, "tmp/%-s.%-d", curuser.userid, time(0));
	if (RecvArticle(fname, FALSE, bname, title) == 0)
	{
		if ((sign >= 1) && (sign <= 3))
			include_sig(curuser.userid, fname, sign);

		for (i = 0; i < mcount; i++)
		{
			blist = search_board(mboards[i]);
			sprintf(path, "boards/%s", mboards[i]);
			sprintf(boarddirect, "%s/%s", path, DIR_REC);
			do_article(fname, path, curuser.userid, title, FALSE);
/*            
   if(*news=='Y' && (blist->type=='B' || blist->type=='O') &&
 */
			if (*news == 'Y' && (blist->brdtype & BRDTYPE_NEWS) &&
			    curuser.numlogins >= LOGIN_NUMBER)
			{
				p = strrchr(path, '/') + 1;
				append_news(bname, p, 'S');
			}
			curuser.numposts++;
		}
		unlink(fname);
		RespondProtocol(OK_CMD);
	}
	else
		RespondProtocol(WORK_ERROR);

	for (i = 0; i < mcount; i++)
		free(mboards[i]);
}
