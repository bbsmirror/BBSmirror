
#ifndef _BBS_CSBBS_H_
#define _BBS_CSBBS_H_

#include "bbs.h"
#include "protocol.h"
#include "../lib/proto.h"

#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <netdb.h>


/*************************************************************************
 *	�����Өt�Ϊ��w�q
 *************************************************************************/

#define	LOGIN_NUMBER	60	/* login �X���~�� post �� news server */
#define READ_BUF	1024	/* �@��Ū����ƪ��j�p */


#define FILES		"FTP"
#define HOSTLIMIT       "/Hostlimit"
#define MAX_MULTI_BOARDS 	200		/* �@���̦h�i�H�P�ɶK���O�� */

/***************************************************************************
 *	���� IDLE Time Out ���w�q
 ***************************************************************************/
#define	IDLE_DONT_KILL	255	/* �o�ӵ��ťH�W���H�������� */
#define	IDLE_SIGNAL	0	/* �P�_�{�b monitor or �@�몬�A */
# define CS_IDLE_TIMEOUT	1800	/* Idle �X���� Time Out */


struct ftpheader {
	char ori_filename[STRLEN];	/* ��l�ɦW */
	char ftp_site[STRLEN];		/* �����ɮצ�m */
	char place[STRLEN];			/* �����ɮ׸��| */
};

#define FTPSIZE	sizeof(struct ftpheader)

struct FileList {
	char *filename;				/* �ɮװO���b�w�Ъ��W�� */
    char owner_ident;           /* ���� */
    char *owner;
    char *title;
	char *ori_filename;
};


struct fword {
	struct fword *last;
	struct FileList *word;
	struct fword *next;
};


struct Paradata			
{
	char *parameter;
	struct Paradata *next;
};

extern char passfile[IDLEN+20];

extern int io_timeout_sec;
extern char boarddirect[STRLEN];
extern char treasuredirect[STRLEN]; /*��ذϸ���ɦ�m*/
extern char CurrentBoard[BNAME_LEN];
extern char *host;


#define CSBBS_SERVER_PORT       7716


#define CLIENT_READ_TIMEOUT     1800  /* 30 mins */
#define CLIENT_WRITE_TIMEOUT    300   /* 5 mins */

#define MAX_BUF_SIZE 4096

#define VERSION_NEWEST 310 		/* u10 �̷s Client ���� */
#define VERSION_LEAST  25  		/* 2.5 �ܤ֨ϥΪ� Client �O�� */
  
#define KEYWORD_DELIMITER	" \t\r\n"
#define KEYWORD_SEPARATE	"\t\r\n"

#define CRACKFILE "/conf/.CSBBS-CRACK"

struct ProtocolJob {
        int     KeyNo;
        int     (* FunPtr)();
};

extern int debug;

extern int     client_version;	/* default 2.0 */

extern int ifSayHello;
extern int ifPass;
extern int ifCert;
extern char MyBuffer[MAX_BUF_SIZE];
extern char *NextToken;
extern struct BoardList *CurBList;

char *GetToken(char *,char *,int);
char *Get_para_string(int);

extern short talkrequest;

extern struct userec curuser, user;
extern struct user_info uinfo;

extern char    genbuf[4096];
extern int     io_timeout_sec;
extern char   *maildirect;
extern short   in_board;


extern char    from[16];
extern char    oldpass[PASSLEN];

#define FACE0		0x18 /* Talking Smile */
#define FACE1		0x19 /* Talking Cry   */
#define	FACE2		0x1a /* Talking Angry */
#define FACE3		0x1b
#define FACE4		0x1c
#define FACE5		0x1d
#define FACE6		0x1e

extern int multi;
#define WRITE_BUF               (1024)
#define MAX_FILE_SIZE    (1*1024*1024)
#define MAIL_GROUPS		(100)

#define ULIST	".UTMP"	/* COMMENT */


struct	bword	{
	struct	bword	*last;
	struct	BoardList	*word;
	struct	bword	*next;
};

extern USER_INFO *cutmp;

#endif /* _BBS_CSBBS_H_ */

