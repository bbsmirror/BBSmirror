
#include "bbs.h"
#include "csbbs.h"

char SeverHello[] = "Formosa Client/Server BBS version 3.25 12/16";

SayHello()
{
	inet_printf("%d\t%s %s \r\n", OK_CMD, BBSNAME, SeverHello);
}

/**************************************************
*		HELLO
*			�s�u��P�t�Υ��۩I
***************************************************/
DoHello()
{
	extern int deny;
	
	if (!ifSayHello)
	{
		if (deny)
		{
			RespondProtocol(NOT_WELCOME);	/* not welcome!! */
			FormosaExit();	/* banned!! */
		}
		ifSayHello = TRUE;
	}
	RespondProtocol(OK_CMD);
}
