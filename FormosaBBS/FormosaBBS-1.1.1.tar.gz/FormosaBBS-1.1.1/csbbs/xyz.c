
#include "bbs.h"
#include "csbbs.h"
/* Last modified by lthuang */


/***********************************************************
*		PLANGET
*			���o�{�buser���W����
************************************************************/
DoGetPlan()
{
	char buf[STRLEN];
	struct stat st;

	sethomefile(buf, curuser.userid, UFNAME_PLANS);
	if (stat(buf, &st) == -1 || st.st_size == 0)
		RespondProtocol(NO_PLAN);
	else
		SendArticle(buf);
}


/************************************************************
*		PLANKILL
*			�R��user�W����
*************************************************************/
DoKillPlan()
{
	char buf[STRLEN];
	struct stat st;

	sethomefile(buf, curuser.userid, UFNAME_PLANS);
	if (stat(buf, &st) == 0 && unlink(buf) == -1)
		RespondProtocol(WORK_ERROR);
	else
		RespondProtocol(OK_CMD);
}


/**************************************************************
*		PLANPUT
*			�e�XUSER���W����
***************************************************************/
DoSendPlan()
{
	char buf[STRLEN], fname[STRLEN];

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
	{			/* �p�G�ϥΪ̬� guest �n�� */
		RespondProtocol(WORK_ERROR);
		return;
	}
#endif

	sethomefile(buf, curuser.userid, UFNAME_PLANS);
	sprintf(fname, "tmp/%-s.%-d", curuser.userid, time(0));
	/* mycp will delete destination file first */
	if (!RecvArticle(fname, FALSE, NULL, NULL) && mycp(fname, buf) == 0)
		RespondProtocol(OK_CMD);
	else
		RespondProtocol(WORK_ERROR);
}


/**************************************************************
*		SIGNGET
*			���o�ϥΪ�ñ�W��
***************************************************************/
DoGetSign()
{
	char buf[STRLEN];
	struct stat st;

	sethomefile(buf, curuser.userid, UFNAME_SIGNATURES);
	if (stat(buf, &st) == -1 || st.st_size == 0)
		RespondProtocol(NO_SIGN);
	else
		SendArticle(buf);
}


/*************************************************************
*		SIGNKILL
*			�R���ϥΪ�ñ�W��
**************************************************************/
DoKillSign()
{
	char buf[STRLEN];
	struct stat st;

	sethomefile(buf, curuser.userid, UFNAME_SIGNATURES);
	if (stat(buf, &st) == 0 && unlink(buf) == -1)
		RespondProtocol(WORK_ERROR);
	else
		RespondProtocol(OK_CMD);
}


/****************************************************************
*		SIGNPUT
*			�e�XUSERñ�W��
*****************************************************************/
DoSendSign()
{
	char buf[STRLEN], fname[STRLEN];

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
	{			/* �p�G�ϥΪ̬� guest �n�� */
		RespondProtocol(WORK_ERROR);
		return;
	}
#endif

	sethomefile(buf, curuser.userid, UFNAME_SIGNATURES);
	sprintf(fname, "tmp/%-s.%-d", curuser.userid, time(0));
	if (!RecvArticle(fname, FALSE, NULL, NULL) && !mycp(fname, buf))
		RespondProtocol(OK_CMD);
	else
		RespondProtocol(WORK_ERROR);
}


/*************************************************************
*		CHGPASSWD newpass
*			�ק�ϥΪ̱K�X
**************************************************************/
DoChangePassword()
{
	char *passbuf;
	char *pass;
	extern char *genpasswd();

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
	{			/* �p�G�ϥΪ̬� guest �n�� */
		RespondProtocol(WORK_ERROR);
		return;
	}
#endif

	passbuf = Get_para_string(1);
	if (passbuf == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}
	passbuf[8] = '\0';
	pass = genpasswd(passbuf);
	strncpy(curuser.passwd, pass, PASSLEN);
	update_user(&curuser);
/*      
   update_user_passfile(&curuser);
 */
	strcpy(oldpass, passbuf);
	RespondProtocol(OK_CMD);
}


/******************************************************************
*		USERGET
*			���o�ϥΪ̸��
*******************************************************************/
DoGetUserData()
{
	char *nickname, *E_mail, *term_type, *lastlogin;

	lastlogin = ctime(&curuser.lastlogin);
	lastlogin[strlen(lastlogin) - 1] = '\0';

	if (curuser.username[0] == '\0' || curuser.username[0] == ' ')
		nickname = "#";
	else
		nickname = curuser.username;

	if (curuser.email[0] == '\0')
		E_mail = "#";
	else
		E_mail = curuser.email;

	/* strcpy(term_type, curuser.termtype); */
	term_type = "#";

	RespondProtocol(OK_CMD);
	inet_printf("%s\t%s\t", nickname, E_mail);
	inet_printf("%s\t%d\t%d\t%d\t%d\t",
		    term_type, curuser.numlogins, curuser.numposts,
		    curuser.userlevel, curuser.uid);
	inet_printf("%s\t%s\t%c\t",
		    curuser.lasthost, lastlogin,
		    (curuser.flags[0] & 1) ? '1' : '0');	/* pager flag */
	inet_printf("%c\t%c\r\n", curuser.ident + '0',
		    (curuser.flags[0] & FORWARD_FLAG) ? '1' : '0');
}


/******************************************************************
*		CHGNAME name
*			�ק�USER�ʺ
*******************************************************************/
DoChangeUserName()
{
	char *name;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
	{			/* �p�G�ϥΪ̬� guest �n�� */
		RespondProtocol(WORK_ERROR);
		return;
	}
#endif

	name = Get_para_string(1);
	if (name != NULL)
	{
		strcpy(curuser.username, name);
		chk_str2(curuser.username);
	}
	else
		curuser.username[0] = '\0';

	update_user(&curuser);
/*      
   update_user_passfile(&curuser);
 */
	RespondProtocol(OK_CMD);
}


/************************************************************
*		CHGMAIL
*			�ק�E-mail�b��
*************************************************************/
DoChangeEMail()
{
	char *email;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
	{			/* �p�G�ϥΪ̬� guest �n�� */
		RespondProtocol(WORK_ERROR);
		return;
	}
#endif

	email = Get_para_string(1);
	strcpy(curuser.email, email);
	update_user(&curuser);
/*      
   update_user_passfile(&curuser);
 */
	RespondProtocol(OK_CMD);
}
