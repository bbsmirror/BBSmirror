
#include "bbs.h"
#include "csbbs.h"

#define SMTPPORT	(25)


/*******************************************************************
 * �]�t�i�K�G�i���ӷ��H�άO�_�q�L�{��
 *      wfile   �ɮצW�
 *******************************************************************/
int
include_tag(wfile)
char *wfile;
{
	FILE *fp;

	if ((fp = fopen(wfile, "a")) == NULL && (fp = fopen(wfile, "w")) == NULL)
		return FALSE;

	chmod(wfile, 0644);
	fputs("\n--\n", fp);
	if (curuser.ident == 7)
		sprintf(genbuf, "* %s * From: %s [�w�q�L�{��] �D�q���\\����\r\n", BBSNAME, uinfo.from);
	else
		sprintf(genbuf, "* %s * From: %s [���q�L�{��] �D�q���\\����\r\n", BBSNAME, uinfo.from);
	fputs(genbuf, fp);
	fclose(fp);
	return TRUE;
}

/*******************************************************************
 * �]�tñ�W��
 *		name	user ID
 *		wfile	�ɮצW�
 *		num		ñ�W�ɽs��
 *******************************************************************/
int
include_sig(name, wfile, num)	/* �ץ�!! gcl ,Cauchy */
char *name, *wfile;
int num;
{
	FILE *fpr, *fpw;
	char rfile[STRLEN];
	int ch, i;

	sethomefile(rfile, name, UFNAME_SIGNATURES);
	if ((fpr = fopen(rfile, "r")) == NULL)
		return -1;
	if ((fpw = fopen(wfile, "a")) == NULL && (fpw = fopen(wfile, "w")) == NULL)
	{
		fclose(fpr);
		return -1;
	}
	chmod(wfile, 0644);
	fputs("\n\n--\n", fpw);
	for (i = 0; i < (num - 1) * 4; i++)
		fgets(genbuf, 4096, fpr);
	ch = 0;
	while (ch++ < MAX_SIG_LINES && fgets(genbuf, 4096, fpr))
		fputs(genbuf, fpw);
	fputs("[m\n", fpw);
	fclose(fpr);
	fclose(fpw);
	return 0;
}

/*******************************************************************
 * �� mail server �إ� socket
 * return: socket number
 *******************************************************************/
int
create_mail_socket()
{
	char *s[2];
	int ms;

	s[0] = MAILSERVER1;
	ms = ConnectServer(*s, SMTPPORT);
	if (ms < 0)
	{
		s[0] = MAILSERVER2;
		ms = ConnectServer(*s, SMTPPORT);
	}

	if (ms > 0)
	{
		io_timeout_sec = CS_IDLE_TIMEOUT;
		alarm(IDLE_SIGNAL);
		net_gets(ms, genbuf, sizeof(genbuf));
		net_printf(ms, "HELO helo\n");
		net_gets(ms, genbuf, sizeof(genbuf));
	}
	return ms;
}


/*******************************************************************
 * ���� mail socket
 *******************************************************************/
int
close_mail_socket(ms)
int ms;
{
	net_printf(ms, "\nQUIT\n");
	net_gets(ms, genbuf, sizeof(genbuf));
	close(ms);
	if (curuser.userlevel < IDLE_DONT_KILL)
		alarm(IDLE_SIGNAL);
	else
		alarm(0);
	return 0;
}


/*******************************************************************
 * �� article �u���a append �W�h
 *******************************************************************/
/*ARGUSED */
int
do_article(fname, path, owner, title, in_mail)	/* �ץ�!! gcl */
char *fname, *path, *owner, *title;
int in_mail;
{
	char *p;
	int fd;
	struct stat st;
	struct fileheader fh;
	struct fileheader lastfile;

	if (!in_mail)
	{
		stat(boarddirect, &st);
		if ((fd = open(boarddirect, O_RDWR)) < 0)
		{
			RespondProtocol(WORK_ERROR);
			return;
		}

		if (lseek(fd, (long) (st.st_size - FH_SIZE), SEEK_SET) == -1)
		{
			RespondProtocol(WORK_ERROR);
			close(fd);
			return;
		}

		if (read(fd, &lastfile, FH_SIZE) != FH_SIZE)
		{
			close(fd);
			RespondProtocol(WORK_ERROR);
			return;
		}
		close(fd);
	}

	if (stat(path, &st))
	{
		if (!(in_mail && !mkdir(path, 0700)))
			return -1;
	}
	get_only_name2(path);
	if (mycp(fname, path))
		return -1;
	p = strrchr(path, '/') + 1;

	bzero(&fh, sizeof(fh));

	if (!in_mail)
	{
		if (lastfile.artno >= BRC_REALMAXNUM)
			fh.artno = 1;
		else if (lastfile.artno > 0)
			fh.artno = lastfile.artno + 1;

		if (fh.artno == 1)
		{
			int fd2;
			struct boardheader sbh;

			if ((fd2 = open(BOARDS, O_RDWR)) > 0)
			{
				flock(fd2, LOCK_EX);
				while (read(fd2, &sbh, sizeof(sbh)) == sizeof(sbh))
				{
					if (!strcmp(sbh.filename, CurrentBoard))
					{
						sbh.rewind_time = time(0);
						if (lseek(fd2, -(sizeof(sbh)), SEEK_CUR) != -1)
							write(fd2, &sbh, sizeof(sbh));
						break;
					}
				}
				flock(fd2, LOCK_UN);
				close(fd2);
			}
		}
	}


	fh.accessed = 0;
	strcpy(fh.filename, p);
	strcpy(fh.owner, owner);
	strcpy(fh.title, title);
	fh.ident = curuser.ident;
	ReadRC_Addlist(fh.artno);

	strcpy(p, ".DIR");
	fd = open(path, O_WRONLY | O_CREAT | O_APPEND, 0644);
	strcpy(p, fh.filename);
	if (fd < 0)
	{
		unlink(path);
		return -1;
	}
	flock(fd, LOCK_EX);
	write(fd, &fh, sizeof(fh));
	flock(fd, LOCK_UN);
	close(fd);
	return 0;
}


/* �h�� uuencode ���� */
/*******************************************************************
 * ��峹�H�� Mail Groups
 *******************************************************************/
int
mail_group(ms, mgroup, fname, from, title)
int ms;
char *mgroup[], *fname, *from, *title;
{
	short i;
	char path[STRLEN];

	if (!mgroup || !fname || !from)
		return -1;
	for (i = 0; i < MAIL_GROUPS; i++)
	{
		if (mgroup[i] == NULL)
			continue;
		if (strchr(mgroup[i], '@'))
		{
			char fromTmp[STRLEN];

			sprintf(fromTmp, "%-s.bbs@%-s", from, MYHOSTNAME);
			DirectSMTPMail(ms, fname, fromTmp, mgroup[i], title);
		}
		else
		{
			setmailfile(path, mgroup[i], NULL);
			do_article(fname, path, from, title, TRUE);
		}
		free(mgroup[i]);
	}

	return 0;
}
