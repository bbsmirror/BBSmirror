
#include "bbs.h"
#include "csbbs.h"
/* last modified by lthuang */


struct bword *topb = NULL, *lastb = NULL;

/*******************************************************
*	�P�_�O�_�� �����U��
*	parament
*		char *board		���W
*	return
*		TRUE or FALSE
********************************************************/
int
BoardHelper(board)
char *board;
{
	char filename[STRLEN];

	setboardfile(filename, board, BM_ASSISTANT);
	if (seek_in_file(filename, curuser.userid))
		return TRUE;
	return FALSE;
}


addto_blist(fh)
struct boardheader *fh;
{
	struct BoardList *new;
	struct bword *bnew;
/*	
	char type;
*/	

	bnew = (struct bword *) malloc(sizeof(struct bword));
	bzero(bnew, sizeof(struct bword));
	new = (struct BoardList *) malloc(sizeof(struct BoardList));
	bzero(new, sizeof(struct BoardList));

	bnew->word = new;
	bnew->next = NULL;
	if (topb == NULL)
		topb = bnew;
	bnew->last = lastb;
	if (lastb != NULL)
		lastb->next = bnew;
	lastb = bnew;

	new->name = (char *) malloc(strlen(fh->filename) + 1);
	strcpy(new->name, fh->filename);


	if (fh->owner[0] == '\0')
	{
		new->owner = (char *) malloc(2);
		strcpy(new->owner, "#");
	}
	else
	{
		new->owner = (char *) malloc(strlen(fh->owner) + 1);
		strcpy(new->owner, fh->owner);
	}
	StrDelR(fh->owner);	

	new->title = (char *) malloc(strlen(fh->title) + 1);
	strcpy(new->title, fh->title);

/*
   type = fh->type;
   if (type != 'B' && type != 'I' && type != 'O')
   type = '#';
   new->type = type;
 */
	new->bid = fh->bid;

	new->level = fh->level;
	new->class = fh->class;
	new->brdtype = fh->brdtype;
	new->rewind_time = fh->rewind_time;
	new->firstartno = fh->firstartno;
	new->rewind_time = fh->rewind_time;
}


make_blist()
{
	extern struct BRDSHM *brdshm;
	BOARDHEADER *bhentp;
	register int i;
	
	resolve_brdshm();
	bhentp = brdshm->brdhr;
	for (i = 0; i < brdshm->number; i++, bhentp++)
	{
		if (bhentp->filename[0] == '\0')	/* NULL board name */
			continue;
		if (can_see_board(bhentp, curuser.userlevel))
			addto_blist(bhentp);
	}
}


struct bword *
check_board_list()
{
	if (!topb)		/* �S���@�L!! */
		make_blist();
	return topb;
}


struct BoardList *
search_board(bname)
char *bname;
{
	struct bword *bp;
	struct BoardList *blist;

	if (bname[0] == '\0')
		return NULL;

	bp = topb;
	while (bp)
	{
		blist = bp->word;
		if (!strcmp(blist->name, bname))
			return blist;	/* find it!! */
		bp = bp->next;
	}
	return NULL;
}


int
can_post_board(blist)
struct BoardList *blist;
{
	int ret = TRUE;

	if (curuser.userlevel < blist->level)
		ret = FALSE;
	else if ((blist->brdtype & BRDTYPE_IDENT) && (curuser.ident != 7))
		ret = FALSE;

	return ret;
}


/*****************************************************
 *   function boardname type
 *
 *          type=0 board
 *               1 treasure
 *				��ܧG�i
 *****************************************************/
/*ARGUSED*/ 
SelectBoard(bname, type)
char *bname;
int type;
{
	struct BoardList *blist;
	int para_num, path_data[10], paths, i, ifpath = FALSE;
	char *check, *p;
	int fp;
	struct fileheader fileinfo;

	if (bname == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return FALSE;
	}

	if (type != 0 && type != 1)
	{
		RespondProtocol(SYNTAX_ERROR);
		return 0;
	}

	if (check_board_list() == NULL)
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return 0;
	}

	blist = search_board(bname);
	if (!blist)
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return 0;
	}

	if (type)
	{
		para_num = Get_paras();
		ifpath = FALSE;
		for (i = para_num; i >= 1; i--)
		{
			check = Get_para_string(i);
			if ((strcmp(check, "PATH") == 0) || (strcmp(check, "path") == 0))
			{
				ifpath = TRUE;
				break;
			}
		}
	}

	if (i == para_num - 1)
		ifpath = FALSE;

	CurBList = blist;
	sprintf(boarddirect, "%s/%s/%s",
		(type) ? "treasure" : "boards", bname, DIR_REC);
	if (ifpath)
	{
		paths = 0;
		for (i = i + 1; i < para_num; i++)
		{
			path_data[paths] = Get_para_number(i);
			if (path_data[paths] == 0)
			{
				RespondProtocol(WORK_ERROR);
				return FALSE;
			}
			paths++;
		}

		for (i = 0; i < paths; i++)
		{
			if ((fp = open(boarddirect, O_RDWR)) < 0)
			{
				RespondProtocol(WORK_ERROR);
				return FALSE;
			}
			lseek(fp, FH_SIZE * (path_data[i] - 1), SEEK_SET);
			read(fp, &fileinfo, FH_SIZE);
			close(fp);
			if (!(fileinfo.accessed & FILE_TREA))
			{
				RespondProtocol(WORK_ERROR);
				return FALSE;
			}
			p = strrchr(boarddirect, '/');
			sprintf(p, "/%s/%s", fileinfo.filename, DIR_REC);
		}
	}
	return TRUE;
}


/*****************************************************
 *  Syntax: LIST [type]
 *
 *          type=0 all
 *               1 none zap only
 *
 *  Respond Type:  boardname zap ifpost news level manager title
 *
 *****************************************************/

DoListBoard()
{
	int type;
	struct bword *bp;
	struct BoardList *blist;
	int ifzap, ifpost;

	type = Get_para_number(1);
	if (type != 0 && type != 1)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	if (check_board_list() == NULL)
	{
		RespondProtocol(NO_ANY_BOARD);
		return;
	}

	RespondProtocol(OK_CMD);
	bp = topb;
	net_cache_init();
	ZapRC_Init(curuser.userid);
	while (bp)
	{
		blist = bp->word;
		ifzap = ZapRC_IsZapped(blist->bid);
		ifpost = can_post_board(blist);

		if (!(ifzap && type))
		{
			sprintf(MyBuffer, "%s\t%d\t%d\t%c\t%d\t%s\t%s\r\n",
				blist->name, ifzap, ifpost,
/*                              
   blist->type, blist->level,
 */
				(blist->brdtype & BRDTYPE_NEWS) ? 'B' : '#', blist->level,
				blist->owner, blist->title);
			net_cache_write(MyBuffer, strlen(MyBuffer));
		}
		bp = bp->next;
	}
	net_cache_write(".\r\n", 3);
	net_cache_refresh();
}

/*****************************************************
 *  Syntax: ZAP boardname
 *
 *****************************************************/

DoZap()
{
	char *bname;
	struct BoardList *blist;

	bname = Get_para_string(1);
	if (bname == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	if (check_board_list() == NULL)
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}

	if (!(blist = search_board(bname)))
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}

	if (!ZapRC_ValidBid(blist->bid))
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}
	if (ZapRC_IsZapped(blist->bid))
		ZapRC_DoUnZap(blist->bid);
	else
		ZapRC_DoZap(blist->bid);
	ZapRC_Update(curuser.userid);
	RespondProtocol(OK_CMD);
}


/***********************************************************
*		BRDWELCHK boardname
*			�i���e���̫�����
************************************************************/
DoChkBoardWelcome()
{
	char *bname;
	char path[STRLEN];
	struct stat st;

	bname = Get_para_string(1);
	if (bname == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	setboardfile(path, bname, BM_WELCOME);
	if (stat(path, &st) < 0)
		inet_printf("%d\t0\r\n", ANN_TIME);
	else
		inet_printf("%d\t%ld\r\n", ANN_TIME, st.st_mtime);
}


/***********************************************************
*		BRDWELGET boardname
*			���o�i���e��
************************************************************/
DoGetBoardWelcome()
{
	char *bname;
	char path[STRLEN];
	struct BoardList *blist;
	struct stat st;

	bname = Get_para_string(1);
	if (bname == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	if (check_board_list() == NULL)
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}

	blist = search_board(bname);
	if (!blist)
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}

	setboardfile(path, blist->name, BM_WELCOME);
	if (stat(path, &st) || st.st_size == 0)
		RespondProtocol(NO_BOARD_WELCOME);
	else
		SendArticle(path);
}


/**************************************************************
*		BRDWELPUT boardname
*			�e�X�i���e��
***************************************************************/
DoPutBoardWelcome()
{
	char *bname;
	struct BoardList *blist;
	char path[STRLEN], temp[STRLEN];

	bname = Get_para_string(1);
	if (bname == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	if (!check_board_list())
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}

	blist = search_board(bname);
	if (!blist)
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}

	if (strcmp(curuser.userid, blist->owner) &&
	    (curuser.userlevel != 255) && !BoardHelper(bname))
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	setboardfile(path, blist->name, BM_WELCOME);
	sprintf(temp, "tmp/%-s.%-d", curuser.userid, time(0));
	if (!RecvArticle(temp, FALSE, NULL, NULL) && !mycp(temp, path))
		RespondProtocol(OK_CMD);
	else
		RespondProtocol(WORK_ERROR);
}


/***********************************************************
*		BRDWELKILL boardname
*			�R���i���e��
************************************************************/
DoKillBoardWelcome()
{
	char *bname;
	struct BoardList *blist;
	char path[STRLEN];
	struct stat st;

	bname = Get_para_string(1);
	if (bname == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	if (!check_board_list())
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}

	blist = search_board(bname);
	if (!blist)
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}

	if (strcmp(curuser.userid, blist->owner) &&
	    (curuser.userlevel != 255) && !BoardHelper(bname))
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	setboardfile(path, blist->name, BM_WELCOME);
	if (stat(path, &st) == 0 && unlink(path) == -1)
		RespondProtocol(WORK_ERROR);
	else
		RespondProtocol(OK_CMD);
}

	