
#include "bbs.h"
#include "csbbs.h"


/**************************************************************
*		VERCHK num
*				�]�w�ҨϥΪ�Client�����s��
*				�t�Τ��w�Ȭ�20
***************************************************************/
DoVersionCheck()
{
	int ver;

	ver = Get_para_number(1);
	if (ver <= 0)
		RespondProtocol(SYNTAX_ERROR);
	else
	{
		client_version = ver;
		if (ver >= VERSION_NEWEST)
			RespondProtocol(VER_OK);
		else if (ver >= VERSION_LEAST)
			RespondProtocol(VER_GETNEW);
		else
			RespondProtocol(VER_NOT);
	}
/*-------------------------------------------
    NextToken=GetToken(NextToken,tmp,10);
    if(tmp[0]=='\0')
        RespondProtocol(SYNTAX_ERROR);
    else
		{
        ver=atoi(tmp);
        client_version=ver;
        if(ver>=VERSION_NEWEST)
            RespondProtocol(VER_OK);
        else if(ver>=VERSION_LEAST)
            RespondProtocol(VER_GETNEW);
        else
            RespondProtocol(VER_NOT);
    	}
----------------------------------------------*/

}

DoBBSName()
{
	inet_printf("%d %s\r\n", BBSNAME_IS, BBSNAME);
}

/***********************************************************
*		CHKANNOUNCE
*			���o���i�̫�ק���
************************************************************/
DoChkAnnounce()
{
	struct stat st;

	if (stat(WELCOME, &st) < 0)
		RespondProtocol(NO_ANNOUNCE);
	else
		inet_printf("%d\t%ld\r\n", ANN_TIME, st.st_mtime);
}

/***********************************************************
*		ANNOUNCE
*			���o�񯸤��i
************************************************************/
DoAnnounce()
{
	struct stat st;

	if (stat(WELCOME, &st) < 0)
		RespondProtocol(NO_ANNOUNCE);
	else
		SendArticle(WELCOME, TRUE);
}

/************************************************************
*		BBSINFO
*			���oBBS name�ATerminal��Client���H��
*************************************************************/
DoAskBBSInformation()
{
	int t_user, c_user, w_user;

	MyAskOnlineUser(&t_user, &c_user, &w_user);
	RespondProtocol(OK_CMD);
	inet_printf("BBSNAME:\t%s\r\nT-USER:\t%d\r\nC-USER:\t%d\r\nW-USER:\t%d\r\n.\r\n", BBSNAME, t_user, c_user, w_user);
}

int
MyAskOnlineUser(int *t_user, int *c_user, int *w_user)
{
	int csbbs, webbbs, total, i;
	extern struct UTMPFILE *utmpshm;
	USER_INFO *u;

	total = csbbs = webbbs = 0;
	resolve_utmp();
	u = utmpshm->uinfo;
	for (i = 0; i < MAXACTIVE; i++, u++)
	{
		if (u->pid > 2)
		{
			if (kill(u->pid, 0))
				u->pid = 0;
			else
			{
				if (u->ctype == CTYPE_CSBBS)
					csbbs++;
				else if (u->ctype == CTYPE_WEBBBS)
					webbbs++;
				total++;
			}
		}
	}
	*t_user = total;
	*c_user = csbbs;
	*w_user = webbbs;
}

void
chk_str2(str)
char str[];
{
	char t[STRLEN];
	int i = -1, j = 0;

	if (str)
	{
		while (str[++i] != '\0')
		{
			if (str[i] == ESC && str[i++] == '[')
				i += 3;
			t[j] = str[i];
			j++;
		}
	}
	t[j] = '\0';
	strcpy(str, t);
	return;
}


/*******************************************************************
 * �b���w���ؿ��U���o�ߤ@�� M.xxxxxxxx.A �ɦW
 *******************************************************************/
get_only_name2(fname)
char fname[];
{
	char *p;
	int fd;

	p = fname + strlen(fname);
	do
	{
		sprintf(p, "/M.%d.A", time(0));
	}
	while ((fd = open(fname, O_WRONLY | O_CREAT | O_EXCL, 0644)) < 0);
	close(fd);
}
