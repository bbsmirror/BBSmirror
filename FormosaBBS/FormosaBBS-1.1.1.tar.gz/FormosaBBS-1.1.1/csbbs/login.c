
#include "bbs.h"
#include "csbbs.h"


char *genpasswd();
int kill_pid;

int
kill_login(upent)
struct user_info *upent;
{
	if (upent->pid == kill_pid)
	{
		if (uinfo.userid[0] != '\0' && !strcmp(upent->userid, uinfo.userid))
		{
			kill(upent->pid, SIGKILL);
			upent->ctype = CTYPE_CSBBS;	/* lasehu: debug */
			purge_ulist(upent);
			RespondProtocol(OK_CMD);
			kill_pid = -1;
			return 0;
		}
	}
	return -1;
}

/***********************************************************
*		KILLPID pid
*				�屼�ۤv�h�l��login
************************************************************/
DoKill()
{
	kill_pid = Get_para_number(1);

	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
	{			/* �p�G�ϥΪ̬� guest �n�� */
		RespondProtocol(WORK_ERROR);
		return;
	}

	if (apply_ulist(kill_login) == -1)
	{
		RespondProtocol(PID_NOT_EXIST);
		return;
	}

	if (kill_pid != -1)
		RespondProtocol(PID_NOT_EXIST);
}


/*******************************************************************
 *
 * �ˬd���� login
 * ��Ҧ���login�q�X��	
 *******************************************************************/
/*ARGUSED */
int
count_multi_login(upent)
struct user_info *upent;
{

	if (upent->pid <= 2 || uinfo.pid <= 2)	/* debug */
		return -1;

	if (!strcmp(upent->userid, uinfo.userid))	/* -ToDo- should compare uid */
	{
		if (upent->pid != uinfo.pid)
		{
			multi++;
			inet_printf("%d\t%s\r\n", upent->pid, upent->from);
/*
   if (multi > MULTILOGINS)
   {
   if (uinfo.userlevel < PERM_SYSOP)
   {
   kill(upent->pid, SIGKILL);
   purge_ulist(upent);
   multi--;
   }
   }
 */
		}
	}
/*
   static int i = 0;

   if (uentp->uid != uinfo.uid)
   return;
   i++;
   if (uentp->pid != uinfo.pid && uentp->userid[0] != '\0')
   {
   multi++;
   if (multi > MULTILOGINS)
   {
   if (uentp->pid > 2)  
   kill(uentp->pid, SIGKILL);
   multi--;
   }
   }
 */
 	return 0;
}


void
multi_user_check()
{
	multi = 0;
	RespondProtocol(OK_CMD);
	if (apply_ulist(count_multi_login) == -1)
	{
		inet_printf(".\r\n");
		return;
	}
	inet_printf(".\r\n");
}


/***********************************************************
*		LOGINNUM
*				���o�{�b�ۤv�Ҧ���login
************************************************************/
DoMultiLogin()
{
	multi_user_check();
}

/***********************************************************
*		USERLOG name passwd [client]
*			name	�ϥΪ�ID
*			passwd	�ϥΪ̱K�X
************************************************************/
DoUserLogin()
{
	char *name, *passwd, *client, client_type;
	int rep = PASSWORD_ERROR;
	int pass_err = 0;

	if (ifPass)
		return;

	name = Get_para_string(1);

	if (name[0] != '\0' && strcmp(name, "new"))
	{
		passwd = Get_para_string(2);
		client = Get_para_string(3);
		if (passwd != NULL)
		{
			if (!strcmp(client, "WEBBBS"))
				client_type = CTYPE_WEBBBS;
			else
				client_type = CTYPE_CSBBS;

			if (user_login(&cutmp, &curuser, client_type, name, passwd, from) == ULOGIN_OK)
			{
				memcpy(&uinfo, cutmp, sizeof(USER_INFO));
				rep = OK_CMD;
				ifPass = TRUE;
			}
			else
				rep = PASSWORD_ERROR;
		}
	}

	if (ifPass)
	{
		/* �R���ª�message�� */
		sprintf(genbuf, "write/%s", curuser.userid);	/* lasehu */
		unlink(genbuf);

		if (!maildirect)
		{
			setmailfile(genbuf, curuser.userid, DIR_REC);
			maildirect = (char *) malloc(strlen(genbuf) + 1);
			strcpy(maildirect, genbuf);
		}
		strcpy(oldpass, passwd);
		/* brc_initial("test"); */
		if (!strcmp(client, "WEBBBS"))
			uinfo.mode = WEBBBS;
		else
			uinfo.mode = CLIENT;
		update_ulist(cutmp, &uinfo);
	}
	else
	{
		pass_err++;
	}

	if (pass_err >= LOGINATTEMPTS)
	{
		RespondProtocol(PASSWORD_3_ERROR);
		FormosaExit();
	}
	else
		RespondProtocol(rep);
}


/**********************************************************
*		CERTILOG name passwd
*			�Hcertification�覡login
***********************************************************/
int
DoCertiLogin(name, passwd)
char *name, *passwd;
{
	bzero(&curuser, sizeof(curuser));
	bzero(&uinfo, sizeof(uinfo));

	if (!get_passwd(&curuser, name)
	    || !checkpasswd(curuser.passwd, passwd))
		return 0;

	if (*curuser.passwd == '\0')	/* �űK�X */
		return 0;

	strcpy(curuser.userid, name);
	strcpy(uinfo.userid, name);
	strcpy(uinfo.from, from);
	strcpy(uinfo.username, curuser.username);
	uinfo.pid = getpid();
	uinfo.uid = curuser.uid;
	uinfo.ctype = CTYPE_CSBBS;
	uinfo.mode = LOGIN;
	if ((curuser.flags[0] & CLOAK_FLAG) && curuser.userlevel >= PERM_CLOAK)
		uinfo.invisible = TRUE;
	else
		uinfo.invisible = FALSE;
	if (curuser.flags[0] & PAGER_FLAG)
		uinfo.pager = FALSE;
	else
		uinfo.pager = TRUE;
	sethomefile(passfile, curuser.userid, UFNAME_PASSWDS);

	uinfo.sockactive = FALSE;
	uinfo.sockaddr = 0;

	if (!maildirect)
	{
		setmailfile(genbuf, curuser.userid, DIR_REC);
		maildirect = (char *) malloc(strlen(genbuf) + 1);
		strcpy(maildirect, genbuf);
	}
	strcpy(oldpass, passwd);

	return 1;

}


/**********************************************************
*		ALLOWNEW
*			�߰ݬO�_�i���U�s�b��
***********************************************************/
DoAllowNew()
{
	int fd;

	if ((fd = open(NONEWUSER, O_RDONLY)) > 0)
	{
		close(fd);
		RespondProtocol(NOT_ALLOW_NEW);
		return;
	}
	RespondProtocol(OK_CMD);
}


/***********************************************************
*		USERCHK name
*			name �ϥΪ�ID
************************************************************/
DoUserCheck()
{
	char *userid;

	userid = Get_para_string(1);
	if (userid[0] == '\0')
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	if (invalid_userid(userid) || get_passwd(NULL, userid))
		RespondProtocol(USERID_EXIST);	/* userid already exist */
	else
		RespondProtocol(USERID_NOT_EXIST);
}


/************************************************************
*		USERNEW name passwd e-mail [user_name]
*			name		�ϥΪ�ID
*			passwd		�K�X
*			e-mail		E-mail �b��
*			user_name	�ΦW
*************************************************************/
DoNewLogin()
{
	USEREC *nu = &curuser;
	char name[IDLEN + 2], *passwd;
	char *tmp;

	bzero(nu, sizeof(curuser));

	strcpy(nu->userid, Get_para_string(1));
	if (invalid_userid(nu->userid))
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	if (invalid_userid(nu->userid) || get_passwd(NULL, nu->userid))
	{
		RespondProtocol(USERID_EXIST);	/* userid already exist */
		return;
	}

	strcpy(name, nu->userid);

	passwd = Get_para_string(2);	/* PASSWORD */
	if (passwd[0] == '\0')
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}
	passwd[8] = '\0';
	strncpy(nu->passwd, genpasswd(passwd), PASSLEN);

	tmp = Get_para_string(3);	/* E-MAIL */
	if (tmp[0] == '0')
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}
	else if (tmp[0] == '#')	/* ignore */
		tmp[0] = '\0';
	strcpy(nu->email, tmp);

	if ((tmp = Get_para_string(4)) != NULL)
	{
		strcpy(nu->username, tmp);
		chk_str2(nu->username);
	}
	else
		nu->username[0] = '\0';

	nu->firstlogin = time(0);
	nu->lastlogin = nu->firstlogin;
	uinfo.login_time = nu->firstlogin;
	strcpy(nu->lasthost, from);
	nu->userlevel = 0;
	nu->numlogins = 1;

	if ((nu->uid = new_user(NULL)) <= 0)
	{
		RespondProtocol(NEWUSER_FAIL);
		return;
	}

	if (new_user(nu)
	    && user_login(&cutmp, &curuser, CTYPE_CSBBS,
			  name, passwd, from) == ULOGIN_OK)
	{
		memcpy(&uinfo, cutmp, sizeof(USER_INFO));
		ifPass = TRUE;
		if (!maildirect)
		{
			setmailfile(genbuf, curuser.userid, DIR_REC);
			maildirect = (char *) malloc(strlen(genbuf) + 1);
			strcpy(maildirect, genbuf);
		}

		strcpy(oldpass, passwd);
		uinfo.mode = CLIENT;
		update_ulist(cutmp, &uinfo);

		RespondProtocol(OK_CMD);
		return;
	}
	RespondProtocol(NEWUSER_FAIL);
	FormosaExit();
}
