/******************************************************************
	misc libiary for Formosa Web Server
*******************************************************************/


#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "bbs.h"
#include "webbbs.h"


/*****************************************************
*       �[�Jñ�W��
******************************************************/
int
include_sig(name, wfile, num)
char *name, *wfile;
int num;
{
	FILE *fpr, *fpw;
	char rfile[STRLEN];
	int ch, i;

	sethomefile(rfile, name, UFNAME_SIGNATURES);
	if ((fpr = fopen(rfile, "r")) == NULL)
		return FALSE;
	if ((fpw = fopen(wfile, "a")) == NULL && (fpw = fopen(wfile, "w")) == NULL)
	{
		fclose(fpr);
		return FALSE;
	}
	chmod(wfile, 0644);
	fputs("\n\n--\n", fpw);
	for (i = 0; i < (num - 1) * 4; i++)
		fgets(pbuf, 4096, fpr);
	ch = 0;
	while (ch++ < MAX_SIG_LINES && fgets(pbuf, 4096, fpr))
		fputs(pbuf, fpw);
	fputs("\n", fpw);
	fclose(fpr);
	fclose(fpw);
	return TRUE;
}


/*******************************************************************
*	�ഫpost�e�W�Ӫ���Ƭ����T���榡
********************************************************************/
void 
Convert(from, to)
char *from, *to;
{
	char *p, buffer[10];
	int index;
	long word;

	p = from;
	index = 0;
	for (;;)
	{
		if (*p == '%')
		{
			strncpy(buffer, p + 1, 2);
			buffer[2] = '\0';
			word = strtol(buffer, NULL, 16);
			if (word != (long) '\r')
				to[index++] = (char) word;
			p += 3;
		}
		else if (*p == '\0')
		{
			to[index] = '\0';
			break;
		}
		else if (*p == '+')
		{
			to[index] = ' ';
			p++;
			index++;
		}
		else
		{
			to[index] = *p;
			p++;
			index++;
		}
	}
}


/*************************************************************
*   �qData���M��O�_��Name���Ѽ� �����ܧ�ѼƤ��e����Para
*   �ѼƤ����H & or ? or ; �@���j
*	�Ҧp Name=Para&...
*
*   Para        �s��ҨD���Ѽƭ�
*   Name        �ѼƦW��
*   Data        ��l���
*   len         �i�H�s�񪺰ѼƳ̤j����
*	def			Para�Ѽƪ�default��
**************************************************************/
void 
GetPara2(Para, Name, Data, len, def)
char *Para, *Name, *Data, *def;
int len;
{
	char *p;

	p = strstr(Data, Name);
	if (p == NULL)
	{
		strcpy(Para, def);
		return;
	}
	strncpy(Para, p + strlen(Name) + 1, len);

	p = Para;
	while (*p)		/* bug fixed by lthuang */
	{
/* buggy    
   if (strchr(" ;&?\r\n", *p))
 */
		if (strchr(";&?\r\n", *p))	/* bug fixed by lthuang */
		{
			*p = '\0';
			break;
		}
		p++;
	}
/*      buggy
   p = strtok(Para, " ;&?\r\n");
 */

}


/*************************************************************
*   �qData���M��O�_��Name���Ѽ� �����ܧ�ѼƤ��e����Para
**************************************************************/
void
GetPara(Para, Name, Data)
char *Para, *Name, *Data;
{
	char *start, *end;
	char buffer[255];

	if ((start = strstr(Data, Name)) != NULL)
	{
		start += strlen(Name) + 2;
		if (*start != '"')
		{
			strcpy(Para, start);
			start = Para;
			for (;;)
			{
				end = strchr(start, '"');
				if ((*(end - 1)) != '\\')
					break;
				else
				{
					strcpy(buffer, end);
					strcpy(end - 1, buffer);
					start = end + 1;
				}
			}
			*end = '\0';
		}
		else
			*Para = 0;
	}
	else
		*Para = 0;
}


/******************************************************************
*	�T�{�ϥΪ̨���
*		username		�ϥΪ�id
*		password		�K�X
*	
*	RETURN:
*		curuser			�ӤH��ƪ�structure
*******************************************************************/
int
CheckUser(username, password, curuser)
char *username, *password;
struct userec *curuser;
{
	bzero(curuser, sizeof(curuser));
	if (!get_passwd(curuser, username)
	    || !checkpasswd(curuser->passwd, password))
		return FALSE;
	return TRUE;
}
