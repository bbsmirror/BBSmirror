/*********************************************************
			Nation Sun-Yat Sen Unversity
			Formosa WEB Server
			Start Develop at 1997.7.12 by Cauchy
**********************************************************/

/*
 * �t�A�ɰ�
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/time.h>

#ifdef AIX
#include <sys/select.h>
#endif


#include "config.h"
#include "struct.h"
#include "webbbs.h"

#define WEBLOG

/*
 * �Ѧ��ɸ��|�w�q
 */
#define PID_FILE        "/tmp/web.pid"
#define PATH_DEVNULL    "/dev/null"
#define HTML_PATH       "HTML/"
#define WEB_TIMEOUT     600
#define BBSWEB_LOG		"log/web.log"
#define VERSION			"1.0.20"

int isHTML;
char pbuf[CONTENT_LENGTH];
char URLPara[255];
struct stat st;
int URLParaType;
struct userec curuser;
char fromhost[HOSTLEN];
char username[IDLEN], password[PASSLEN];
char WEBBBS_ERROR_MESSAGE[STRLEN];

enum
{
	None, BoardName, ReadPost, ReadTrea, ReadMail
};

#define OK_CMD "HTTP/1.0 200 OK"

void SendFile(char *FileName);
void SendArticle(char *filename, char *attach);


#ifdef WEBLOG
void
weblog(msg)
char *msg;
{
	time_t now;
	FILE *fp;
	char timestr[22];

	time(&now);
	strftime(timestr, sizeof(timestr), "%x %X", localtime(&now));
	
	if ((fp = fopen(BBSWEB_LOG, "a+")) != NULL)
	{
		fprintf(fp, "%s %s\n", timestr, msg);
		fclose(fp);
	}
}
#endif
	

char *genpasswd();

/*******************************************************************
 * �� WEB-BBS �s�W�@�ϥΪ�
 *******************************************************************/
int
do_newuser()
{
	FILE *fp;
	char n_userid[IDLEN];
	char n_userpasswd[PASSLEN];
	char n_usernickname[STRLEN];
	char n_usermail[STRLEN];
	USEREC *newuser = &curuser;
    time_t now;
	char timestr[22];
            
	time(&now);
	strftime(timestr, sizeof(timestr), "%x %X", localtime(&now));
                    
	bzero(newuser, sizeof(curuser));

	gets(pbuf);

#ifdef WEBLOG
	fp = fopen("log/new_user.tmp", "w");
	fprintf(fp, "%s\n", pbuf);
	fclose(fp);
#endif

	/* ���XFORM����USER��� */
	GetPara2(n_userid, "ID", pbuf, IDLEN, "");
	GetPara2(n_userpasswd, "PASSWD", pbuf, PASSLEN, "");
	GetPara2(n_usernickname, "NICKNAME", pbuf, STRLEN, "");
	GetPara2(n_usermail, "EMAIL", pbuf, STRLEN, "");

	strcpy(newuser->userid, n_userid);
	strncpy(newuser->passwd, genpasswd(n_userpasswd), PASSLEN);
	Convert(n_usernickname,newuser->username);
	strcpy(newuser->email, n_usermail);
	strcpy(newuser->lasthost, fromhost);

	if ((strlen(n_userid) < 2) || (strlen(n_userpasswd) < 4))
	{
		strcpy(WEBBBS_ERROR_MESSAGE, "�b���αK�X�ӵu");
		return FALSE;
	}

	if (invalid_userid(newuser->userid))
	{
		strcpy(WEBBBS_ERROR_MESSAGE, "BAD USER ID<br>�ФŨϥίS���Ÿ��A�ťաA�Ʀr�A�����r��");
		return FALSE;
	}

	if (get_passwd(NULL, newuser->userid))
	{
		strcpy(WEBBBS_ERROR_MESSAGE, "�b���w�s�b�A�д��@�ӱb��");
		return FALSE;
	}
	
	newuser->firstlogin = time(0);
	newuser->lastlogin = newuser->firstlogin;
	newuser->userlevel = 0;
	newuser->numlogins = 1;

	if ((newuser->uid = new_user(NULL)) <= 0)
	{
		strcpy(WEBBBS_ERROR_MESSAGE, "New User Error #2");
		return FALSE;
	}

	if (new_user(newuser) <= 0)
	{
		strcpy(WEBBBS_ERROR_MESSAGE, "New User Error #3");
		return FALSE;
	}

#ifdef WEBLOG
	fp = fopen("log/new_user.log", "a");
	fprintf(fp, "========= NewUser at [%s] =========================\n",timestr);
	fprintf(fp, "ID=%s\n", newuser->userid);
	fprintf(fp, "PASSWORD=%s\n", newuser->passwd);
	fprintf(fp, "NICKANME=%s\n", newuser->username);
	fprintf(fp, "E-MAIL=%s\n", newuser->email);
	fprintf(fp, "From=%s\n",fromhost);
	fclose(fp);
#endif

	return TRUE;

}


/*------------------------------------------------------------------------
 * reaper - clean up zombie children
 *------------------------------------------------------------------------
 */
static void
reaper()
{
#if	defined(SOLARIS) || defined(AIX) || defined(LINUX)
	int status;
#else
	union wait status;
#endif /* SOLARIS */

	while (wait3(&status, WNOHANG, (struct rusage *) 0) > 0)
		/* empty */ ;
	(void) signal(SIGCHLD, reaper);
}


/*
 * �L�X�䤣���ɮת����~�T��
 */
void
print_nofile()
{
	printf("HTTP/1.0 404 File Not Found\r\n");
	printf("Connection: close\r\n");
	printf("Content-Type: text/html\r\n");
	printf("\r\n");
	fflush(stdout);
	SendFile("FileNotFound.html");
}


/************************************************************
*		filename ����ɮװe�X�h
*		��䤤��ansi color�ରhtml��tag�榡
*************************************************************/
void
SendArticle(filename, attach)
char *filename, *attach;
{
	FILE *fp;
	char *p, *data;

	char *AnsiColor[] =
	{"30", "31", "32", "33", "34", "35", "36", "37"};

	char *HTMLColor[] =
	{"000000", "8f0000", "008f00", "8f8f00", "00008f", "8f008f", "008f8f", "cfcfcf"};

	char *HiColor[] =
	{"8f8f8f", "ff0000", "00ff00", "ffff00", "0000ff", "ff00ff", "00ffff", "ffffff"};

	char ANSI[4];
	char FontStr[20];
	char buffer[512];
	int colorindex, text, pid, i, bright = 0, fontcount = 0;
	char *paras[5];
	char para1[80], para2[80], para3[80], para4[80];

	sprintf(ANSI, "%c[", 27);
	if ((fp = fopen(filename, "r")) == NULL)
	{
		print_nofile();
		return;
	}

	text = TRUE;
	while (fgets(pbuf, 512, fp))
	{
		p = strchr(pbuf, '\n');
		if (p != NULL)
			*p = '\0';

		buffer[0] = '\0';
		data = pbuf;

		/* Get attach file name */
		if ((attach != NULL) && (strstr(pbuf, "Content-Type:") != NULL))
		{
			sprintf(attach, "tmp/%d.tif", time(0));
			if ((p = strstr(pbuf, "name=")) != NULL)
			{
				p += strlen("name=") + 1;
				strcpy(attach, "tmp/");
				strcat(attach, p);
				if (*(p + 1) == '"')
					sprintf(attach, "tmp/%d.tif", time(0));
				p = strchr(attach, '"');
				*p = '\0';
				for (i = 0; i < strlen(attach); i++)
					if (isupper(attach[i]))
						attach[i] = tolower(attach[i]);
			}
		}

		/* text plain */
		if (strstr(data, "Content-Type:") != NULL)
		{
			if (strstr(data, "text/plain") != NULL)
				text = TRUE;
		}		/* base 64 start */
		else if ((strstr(data, "Content-Transfer-Encoding:") != NULL) &&
			 (strstr(data, "base64") != NULL))
		{
			text = FALSE;

			if (attach != NULL)
			{
#if FLASE
				sprintf(attach, "tmp/%d.tif", time(0));
				while (fgets(pbuf, 512, fp) != NULL)
				{
					if (strstr(pbuf, "Content-Type:") != NULL)
					{
						if ((p = strstr(pbuf, "name=")) != NULL)
						{
							p += strlen("name=") + 1;
							strcpy(attach, "tmp/");
							strcat(attach, p);
							if (*(p + 1) == '"')
								sprintf(attach, "tmp/%d.tif", time(0));
							p = strchr(attach, '"');
							*p = '\0';
							for (i = 0; i < strlen(attach); i++)
								if (isupper(attach[i]))
									attach[i] = tolower(attach[i]);
							break;
						}
					}
				}
#endif

				sprintf(para1, "metamail");
				sprintf(para2, "%s", filename);
				sprintf(para3, "-t");
				sprintf(para4, "%s", attach);
				paras[0] = para1;
				paras[1] = para2;
				paras[2] = para3;
				paras[3] = para4;
				paras[4] = NULL;

				pid = fork();
				if (pid == 0)
					execv("bin/metamail", paras);
				else if (pid < 0)
					return;
				else
					/* waitpid(pid, 0, WNOHANG); */
					wait(0);

				if ((strstr(attach, ".jpg") != NULL) ||
				    (strstr(attach, ".gif") != NULL))
					printf("<img src=/%s border=0><br>", attach);
				else if ((strstr(attach, ".avi") != NULL) ||
					 (strstr(attach, ".mov") != NULL) ||
					 (strstr(attach, ".mpg") != NULL) ||
					 (strstr(attach, ".wav") != NULL))
					printf("<embed src=\"/%s\" autostart=true><br>", attach);
				else
					printf("<p><a href=\"/%s\">%s</a></p>\r\n", attach, attach);
			}
		}

		if (!text)
			continue;

		while (p = strstr(data, ANSI))
		{
			*p = '\0';
			p++;
			strcat(buffer, data);

			if ((*(p + 2) == ';'))	/* this function modified by asuka */
			{
				for (colorindex = 0; colorindex < 8; colorindex++)
				{


					/* if (strstr ((p+2), AnsiColor[colorindex]) != NULL) */
					if ((int) (*(p + 4)) == colorindex + 48)
					{
						if (*(p + 1) == '1' || *(p + 1) == '2')		/* hi color display */
						{
							bright = 1;
							sprintf(FontStr, "<FONT COLOR=\"#%s\">", HiColor[colorindex]);
							fontcount++;
						}
						else if (*(p + 1) == '5')	/* blink display */
						{
							sprintf(FontStr, "<FONT COLOR=\"#%s\">", HTMLColor[colorindex]);
						}
						else
						{
							data = strchr(p, 'm') + 1;
							break;
						}

						strcat(buffer, FontStr);
						data = strchr(p, 'm') + 1;
						break;
					}
				}

				if (colorindex >= 8)
				{
					data = strchr(p, 'm') + 1;
				}
			}

			else if (*(p + 3) == 'm')
			{

				for (colorindex = 0; colorindex < 8; colorindex++)
				{
					/* if (strstr (p, AnsiColor[colorindex]) != NULL) */
					if ((int) (*(p + 2)) == colorindex + 48)
					{
						if (bright == 0)
							sprintf(FontStr, "<FONT COLOR=\"#%s\">", HTMLColor[colorindex]);
						else
							sprintf(FontStr, "<FONT COLOR=\"#%s\">", HiColor[colorindex]);

						fontcount++;
						strcat(buffer, FontStr);
						data = strchr(p, 'm') + 1;
						break;
					}
				}
				if (colorindex >= 8)
				{
					data = strchr(p, 'm') + 1;
				}
			}

			else if (strstr(p, "[1m") != NULL)
			{

				bright = 1;
				data = strchr(p, 'm') + 1;
			}

			else if ((strstr(p, "[0m") != NULL) || (strstr(p, "[m") != NULL))
			{
				bright = 0;
				if (fontcount > 0)
				{
					strcat(buffer, "</FONT>");
					fontcount--;
				}
				data = strchr(p, 'm') + 1;
			}

			else
				/* discard other ansi control */
			{
				data = strchr(p, 'm') + 1;
			}
		}

		printf("%s%s\r\n", buffer, data);
		/*fflush (stdout); */
	}


	for (fontcount; fontcount >= 0; fontcount--)
		printf("</FONT>");

	fflush(stdout);

	fclose(fp);
}


/****************************************************
		<BBS_Announce>
		���Jbbs�i�����i
*****************************************************/
void
ShowAnnounce()
{
	SendArticle(WELCOME, NULL);
}

/*********************************************************
	�e�X�@����
	data		���
**********************************************************/
void 
SendLine(data)
char *data;
{
	char *p, *p2;
	char buffer[255], tag[255];

	if ((p = strstr(data, "<BBS_Announce>")) != NULL)
	{
		*p = '\0';
		printf("%s\r\n", data);
		p += sizeof("<BBS_Announce>") - 1;
		strcpy(buffer, p);
		ShowAnnounce();
		printf("%s\r\n", buffer);
	}
	else if((p = strstr(data, "<BBS_ERROR_MESSAGE>")) != NULL)
	{
		*p = '\0';
		printf("%s", data);
		p += sizeof("<BBS_ERROR_MESSAGE>") - 1;
		printf("%s", WEBBBS_ERROR_MESSAGE);
		printf("%s", p);
	
	}
	else if (((p = strstr(data, "<BBS_BoardList_E-name")) != NULL) ||
		 ((p = strstr(data, "<BBS_BoardList_C-name")) != NULL) ||
		 ((p = strstr(data, "<BBS_BoardList_BM-name")) != NULL))
	{
		*p = '\0';
		printf("%s\r\n", data);
		p++;
		p2 = strstr(p, "\">");
		p2++;
		*p2 = '\0';
		strcpy(tag, p);
		strcpy(buffer, ++p2);
		ShowBoardList(tag);
		printf("%s\r\n", buffer);
	}
	else if ((p = strstr(data, "<BBS_MailList")) != NULL)
	{
		*p = '\0';
		printf("%s\r\n", data);
		p++;
		p2 = strstr(p, "\">");
		p2++;
		*p2 = '\0';
		strcpy(tag, p);
		strcpy(buffer, ++p2);
		ShowMailList(tag);
		printf("%s\r\n", buffer);
	}
	else if ((p = strstr(data, "<BBS_MailGet")) != NULL)
	{
		*p = '\0';
		printf("%s\r\n", data);
		p++;
		p2 = strchr(p, '>');
		*p2 = '\0';
		strcpy(tag, p);
		strcpy(buffer, ++p2);

		if (URLParaType == ReadMail)
		{
			ShowMail(tag);
		}

		printf("%s\r\n", buffer);
	}
	else if ((p = strstr(data, "<BBS_Head")) != NULL)
	{
		*p = '\0';
		printf("%s", data);
		p++;
		p2 = strchr(p, '>');
		p2++;
		strcpy(buffer, p2);
		*p2 = '\0';
		strcpy(tag, p);

		if (URLParaType == BoardName)
			ShowBoardHead(tag);

		printf("%s\r\n", buffer);
	}
	else if ((p = strstr(data, "<BBS_Trea")) != NULL)
	{
		*p = '\0';
		printf("%s\r\n", data);
		p++;
		p2 = strstr(p, "\">");
		p2++;
		*p2 = '\0';
		strcpy(tag, p);
		strcpy(buffer, ++p2);

		if (URLParaType == BoardName)
		{
			ShowTreasureHead(tag);
		}

		printf("%s\r\n", buffer);
	}
	else if ((p = strstr(data, "<BBS_Post")) != NULL)
	{
		*p = '\0';
		printf("%s", data);
		p++;
		p2 = strchr(p, '>');
		p2++;
		strcpy(buffer, p2);
		*p2 = '\0';
		strcpy(tag, p);

		if (URLParaType == ReadPost)
			ShowPost(tag);
		else if (URLParaType == ReadTrea)
			ShowTrea(tag);

		printf("%s\r\n", buffer);
	}
	else
		printf("%s\r\n", data);
}

/**********************************************************
*	target		��l�r��
*	Para		�ѼƦW
*	num			�ҭn�a�J���Ʀr
*	�Ndata��Para�ܼƥN����num
***********************************************************/
void 
replace(target, Para, num)
char *Para, *target;
int num;
{
	char ParaName[80], *p;
	char buffer[255], number[10];
	int i;

	strcpy(ParaName, "%");
	strcat(ParaName, Para);
	sprintf(number, "%d", num);

	if (strstr(target, ParaName) == NULL)
		return;

	while ((p = strstr(target, ParaName)) != NULL)
	{
		strcpy(buffer, p + strlen(ParaName));
		*p = '\0';
		strcat(target, number);
		strcat(target, buffer);
	}

}

/**********************************************************
*		FileName �n�e�X�h���ɮצW��
*		�|���R�Xtag�N��N�J�A�������
***********************************************************/

#define LINE_IN_FOR	200

void
SendFile(FileName)
char *FileName;
{
	int fp;
	FILE *fp2;
	char *p, *p2;
	int size, lines, i, j;
	char *forData[LINE_IN_FOR];

	strcpy(pbuf, HTML_PATH);
	strcat(pbuf, FileName);

	if (!isHTML)
	{
		if ((fp = open(pbuf, O_RDONLY)) == -1)
		{
			if (strcmp(pbuf, "FileNotFound.html"))	/* bug fixed */
				print_nofile();
			return;
		}

		while ((size = read(fp, pbuf, 512)) != 0)
		{
			fwrite(pbuf, 1, size, stdout);
			fflush(stdout);
		}
		fflush(stdout);
		close(fp);
	}
	else
	{
		if ((fp2 = fopen(pbuf, "r")) == NULL)
		{
			if (strcmp(pbuf, "FileNotFound.html"))	/* bug fixed */
				print_nofile();
			return;
		}

		while (fgets(pbuf, 512, fp2) != NULL)
		{
			p = strchr(pbuf, '\n');
			if (p != NULL)
				*p = '\0';

			if (strstr(pbuf, "%MAILNUM%") != NULL)
				replace(pbuf, "MAILNUM%", GetMailNum(1));
			else if (strstr(pbuf, "%FAXNUM%") != NULL)
				replace(pbuf, "FAXNUM%", GetMailNum(2));
			else if (strstr(pbuf, "%VOICENUM%") != NULL)
				replace(pbuf, "VOICENUM%", GetMailNum(3));

			if (strstr(pbuf, "<BBS_FOR") != NULL)
			{
				char ParaName[80], buffer[80], convert[255];
				int start, end;

				GetPara(ParaName, "Para", pbuf);
				GetPara(buffer, "Start", pbuf);
				start = atoi(buffer);
				GetPara(buffer, "End", pbuf);
				end = atoi(buffer);

				lines = 0;
				while (fgets(pbuf, 512, fp2) != NULL)
				{
					p = strchr(pbuf, '\n');
					if (p != NULL)
						*p = '\0';
					if (strstr(pbuf, "<BBS_FOR_END>") != NULL)
					{
						for (j = start; j <= end; j++)
						{
							for (i = 0; i < lines; i++)
							{
								strcpy(convert, forData[i]);
								replace(convert, ParaName, j);
								SendLine(convert);
							}
						}
						strcpy(pbuf, "");
						for (i = 0; i < lines; i++)
							free(forData[i]);
						break;
					}
					forData[lines] = (char *) malloc(strlen(pbuf) + 10);
					strcpy(forData[lines++], pbuf);
				}
			}
			SendLine(pbuf);
			fflush(stdout);
		}
		fclose(fp2);
		fflush(stdout);
	}
}


#define MAX_EXTENSION	(9)

void
print_Head(filename, refresh)
char *filename;
int refresh;
{
	struct stat fstat;
	time_t ntime;
	struct tm *stime;
	char *p, Expire[2];
	char buffer[80];
	int typeindex;
	char *extensions[] =
	{"txt", "html", "htm", "gif", "jpg", "cdf", "ocx", "cab", "ccr"};
	char *types[] =
	{"text/plain", "text/html", "text/html", "image/gif",
	 "image/jpeg", "application/x-netcdf", "application/octet-stream",
	 "application/octet-stream", "application/octet-stream"};

	strcpy(pbuf, HTML_PATH);
	strcat(pbuf, filename);
	stat(pbuf, &fstat);

	printf("%s\r\n", OK_CMD);

	/* �ھ�url�P�_�O�n�e�{�b�ɶ��٬O�ɮ׭ק�����Last-Modified */
	GetPara2(Expire, "Expire", URLPara, 1, "0");
	if (Expire[0] == '1')
		refresh = TRUE;
	if ((strstr(URLPara, "BoardName") != NULL) || (refresh) ||
	    (strstr(URLPara, "ReadMail") != NULL))
	{
		printf("Expires: 0\r\n");
		time(&ntime);
	}
	else
		ntime = fstat.st_mtime;

	stime = localtime(&ntime);
	strftime(pbuf, sizeof(pbuf), "%A, %d %b %y %H:%M:%S GMT", stime);
	printf("Last-Modified: %s\r\n", pbuf);
	printf("Server: Formosa Web Server %s\r\n", VERSION);

	strcpy(buffer, filename);
	p = strrchr(buffer, '.');
	if (p != NULL)
	{
		p++;
		typeindex = 0;
		while (strcmp(extensions[typeindex], p))
		{
			if (++typeindex >= MAX_EXTENSION)
			{
				typeindex = 0;
				break;
			}
		}
		printf("Content-type: %s\r\n", types[typeindex]);
		if ((typeindex == 1) || (typeindex == 2))
			isHTML = TRUE;
		else
		{
			isHTML = FALSE;
			printf("Content-Length: %d\r\n", fstat.st_size);
		}
	}
	printf("\r\n");
	fflush(stdout);
}


void
CheckPara(URL)
char *URL;
{
	if (strstr(URL, "BoardName") != NULL)
		URLParaType = BoardName;
	else if (strstr(URL, "ReadPost") != NULL)
		URLParaType = ReadPost;
	else if (strstr(URL, "unique") != NULL)
		URLParaType = ReadPost;
	else if (strstr(URL, "ReadTrea") != NULL)
		URLParaType = ReadTrea;
	else if (strstr(URL, "ReadMail") != NULL)
		URLParaType = ReadMail;
	else
		URLParaType = None;
}


/*
 * Parse Input String to Command
 */
int
ParseCommand(inbuf)
char *inbuf;
{
	char *p, *p2, temp[255], *unique_p;
	struct stat st;

	if (*inbuf == '\0' || *inbuf == '\r' || *inbuf == '\n')
		return -1;

	p = strtok(inbuf, " \t\n");
	if (!strcmp(p, "GET"))
	{
		p = strtok(NULL, " \t\n");
		/* Ū�� header */
#if defined(DEBUG)
		fp = fopen(BBSWEB_LOG, "w");
		fprintf(fp, "%s\n", p);
		for (;;)
		{
			gets(debug_buf);
			if (strlen(debug_buf) == 1)
				break;
			fprintf(fp, "%s\n", debug_buf);
			if (strstr(temp, "Cookie:") != NULL)
			{
				GetPara2(username, "Name", temp, IDLEN, "");
				GetPara2(password, "Password", temp, PASSLEN, "");
			}
		}
		fclose(fp);
#else
		for (;;)
		{
			gets(temp);
#ifdef WEBLOG
			weblog(temp);
#endif					
			if (strlen(temp) == 1)
				break;
			if (strstr(temp, "Cookie:") != NULL)
			{
				GetPara2(username, "Name", temp, IDLEN, "");
				GetPara2(password, "Password", temp, PASSLEN, "");
			}
		}
#endif
		if (strlen(p) == 1)
			strcpy(p, "index.html");

		/*�ҤU���ѼƬ�unique url */
		if ((unique_p = strstr(p, "/unique/")) != NULL)
		{
			char url_path[255], url_para[255], *start_para;

			*unique_p = '\0';
			strcpy(url_path, p);
			start_para = unique_p + 1;
			unique_p = strchr(unique_p + 1, '/');
			unique_p = strchr(unique_p + 1, '/');
			unique_p = strchr(unique_p + 1, '/');
			*unique_p = '\0';
			strcpy(url_para, start_para);
			strcat(url_path, "/");
			strcat(url_path, unique_p + 1);
			sprintf(p, "%s?%s", url_path, url_para);
		}
		else
			sprintf(temp, "HTML%s", p);	/* ? */
		if (!stat(temp, &st) && S_ISDIR(st.st_mode))
			strcat(p, "/index.html");

		/* �O�_��?�s�b �����ܧ�᭱�������Ѽ� , ��ѼƳ������URLPara */
		if ((p2 = strchr(p, '?')) != NULL)
		{
			*p2 = '\0';
			p2++;
			strcpy(URLPara, p2);
			CheckPara(URLPara);
		}

		strcpy(pbuf, HTML_PATH);
		strcat(pbuf, p);

		if (stat(pbuf, &st) == -1)
			print_nofile();
		else
		{
			print_Head(p, FALSE);
			SendFile(p);
		}
	}
	else if (!strcmp(p, "HEAD"))
	{
		p = strtok(NULL, " \t\n");
		if (strlen(p) == 1)
			strcpy(p, "index.html");
		print_Head(p, FALSE);
	}
	else if (!strcmp(p, "POST"))
	{

		p = strtok(NULL, " \t\n");
#if defined(DEBUG)
		fp = fopen(BBSWEB_LOG, "w");
		fprintf(fp, "%s\n", p);
		for (;;)
		{
			gets(debug_buf);
			if (strlen(debug_buf) == 1)
				break;
			fprintf(fp, "%s\n", debug_buf);
			if (strstr(debug_buf, "Cookie:") != NULL)
			{
				GetPara2(username, "Name", debug_buf, IDLEN, "");
				GetPara2(password, "Password", debug_buf, PASSLEN, "");
			}
		}
		fclose(fp);
#else
		for (;;)
		{
			gets(temp);
#ifdef WEBLOG			
			weblog(temp);					
#endif			
			if (strlen(temp) == 1)
				break;
			if (strstr(temp, "Cookie:") != NULL)
			{
				GetPara2(username, "Name", temp, IDLEN, "");
				GetPara2(password, "Password", temp, PASSLEN, "");
			}
		}
#endif
		{		/* lmj */
			char *pp;

			if (!(pp = strrchr(p, '/')))
				pp = p;

			if (!strcmp(pp, "/postput"))	/* �n�K�G�i */
			{
				if (PostPut())
					SendFile("PostSucceed.html");
				else
					SendFile("PostError.html");
			}

			else if (!strcmp(pp, "/new_user"))	/* �s�W USER */
			{
				if (do_newuser())
					SendFile("NewUserSucceed.html");
				else
				{
					isHTML = TRUE;
					SendFile("WebbbsError.html");
				}
			}

			else
				SendFile("ErrorCommand.html");
		}		/*lmj */
	}
	else
		SendFile("ErrorCommand.html");

	return 1;
}


/*
 * Idle Timeout
 */

int idles = FALSE;

void
timeout_check()
{
	if (idles)
	{
		shutdown(0, 2);
		exit(0);
	}
	idles = TRUE;
	signal(SIGALRM, timeout_check);
	alarm(WEB_TIMEOUT);
}


/*
 * Main Function
 */
void
Web()
{
	char inbuf[256];

	init_bbsenv();

	signal(SIGALRM, timeout_check);
	alarm(WEB_TIMEOUT);

	if (gets(inbuf))
	{
#ifdef WEBLOG
		weblog(inbuf);
#endif			
		switch (ParseCommand(inbuf))
		{
			case 1:	/* Normal Command */
				break;
			case 0:	/* No Such Command */
				printf("-ERR no such command\r\n");
				break;
			default:	/* Error */
				printf("-ERR no command\r\n");
				break;
		}
	}
	fflush(stdout);
}


void
usage(prog)
char *prog;
{
	fprintf(stderr, "Usage: %s [-p port] [-d] [-c]\n\
-p Specify server port for binding\n\
-d Enable debug mode\n\
-c Enable allow/deny mode\n", prog);
	fflush(stderr);
}


/*
 * Main
 *
 */

int
main(argc, argv)
int argc;
char *argv[];
{
	int aha, on = 1, maxs;
	fd_set ibits;
	struct sockaddr_in from, sin;
	int s, ns;
	char debug = 0, check = 0;
	struct timeval wait;
	int c;
	int port = 80;

	while ((c = getopt(argc, argv, "p:cd")) != -1)
	{
		switch (c)
		{
			case 'p':
				port = atoi(optarg);
				break;
			case 'd':
				debug++;
				break;
			case 'c':
				check++;
				break;
			default:
				usage(argv[0]);
				exit(-1);
				break;
		}
	}

	if (debug)
		printf("\nEnable debuge mode.\n");
	if (check)
		host_deny((char *) NULL);

	if (fork() != 0)
		exit(0);

	if (debug)
		for (aha = 64; aha > 2; aha--)
			close(aha);
	else
	{
		for (aha = 64; aha >= 0; aha--)
			close(aha);
		if ((aha = open(PATH_DEVNULL, O_RDONLY)) < 0)
		{
			printf("Open %s fail\r\n", PATH_DEVNULL);
			exit(1);
		}
		if (aha)
		{
			dup2(aha, 0);
			close(aha);
		}
		dup2(0, 1);
	}

	signal(SIGHUP, SIG_IGN);
	signal(SIGCHLD, reaper);

	if ((s = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		exit(1);

	if (debug)
		printf("Get Socket [%d]\n", s);

	setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (char *) &on, sizeof(on));
#if defined(IP_OPTIONS) && defined(IPPROTO_IP)
	setsockopt(s, IPPROTO_IP, IP_OPTIONS, (char *) NULL, 0);
#endif

	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = INADDR_ANY;
#if defined(KGHSBBS)
	/* only consider about MYHOSTIP, for running with normal http server */
	sin.sin_addr.s_addr = inet_addr(MYHOSTIP);
#endif
	sin.sin_port = htons((u_short) port);

	if (debug)
		printf("MyIp: %s\n", MYHOSTIP);

	if (bind(s, (struct sockaddr *) &sin, sizeof sin) < 0)
	{
		perror("bind");
		exit(1);
	}

#if	defined(SOLARIS) || defined(AIX)
	if (listen(s, 256) < 0)
#else
	if (listen(s, 5) < 0)
#endif
	{
		perror("listen");
		exit(1);
	}

	if (debug)
		printf("PID [%d] BIND socket [%d] OK!\n", getpid(), s);
	else
	{
		FILE *fp;

		unlink(PID_FILE);
		if (fp = fopen(PID_FILE, "w"))
		{
			fprintf(fp, "%-d", getpid());
			fclose(fp);
			chmod(PID_FILE, 0644);
		}
	}

	aha = sizeof(from);
	maxs = s + 1;
	wait.tv_sec = 5;
	wait.tv_usec = 0;

	while (1)
	{
		FD_ZERO(&ibits);
		FD_SET(s, &ibits);
		if ((on = select(maxs, &ibits, 0, 0, &wait)) < 1)
		{
			if ((on < 0 && errno == EINTR) || on == 0)
				continue;
			else
			{
				sleep(5);
				continue;
			}
		}
		if (!FD_ISSET(s, &ibits))
			continue;
		if ((ns = accept(s, (struct sockaddr *) &from, &aha)) < 0)
			continue;
		else
		{
			switch (fork())
			{
				case -1:
					close(ns);
					break;
				case 0:
					{
						char *host;
#ifdef	RESOLVE_HOSTNAME
						struct hostent *hp;
#endif

						signal(SIGCHLD, SIG_IGN);
						close(s);
						dup2(ns, 0);
						close(ns);
						dup2(0, 1);
						dup2(0, 2);
						on = 1;
						setsockopt(0, SOL_SOCKET, SO_KEEPALIVE,
						  (char *) &on, sizeof(on));
#ifdef	RESOLVE_HOSTNAME
						if ((hp = gethostbyaddr((char *) &(from.sin_addr),
									sizeof(struct in_addr), from.sin_family)))
							  host = hp->h_name;
						else
#endif
							host = inet_ntoa(from.sin_addr);

						if (debug)
							printf("Connect From: [%s]\n", host);

						if (check && host_deny(host))
						{
							shutdown(0, 2);
							exit(0);
						}

						xstrncpy(fromhost, host, sizeof(fromhost));

						Web();

						shutdown(0, 2);
						exit(0);
					}
				default:
					close(ns);
			}
		}
	}
}
