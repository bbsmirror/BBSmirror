
#define CONTENT_LENGTH  5*1024

extern char username[IDLEN], password[PASSLEN];
extern char URLPara[255];
extern struct userec curuser;
extern char pbuf[CONTENT_LENGTH];
extern char fromhost[HOSTLEN];
