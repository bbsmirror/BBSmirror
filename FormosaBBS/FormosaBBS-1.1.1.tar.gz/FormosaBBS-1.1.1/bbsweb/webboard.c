/*************************************************
*		Web-BBS functions about Board
**************************************************/

#include <stdio.h>
#include <sys/types.h>
#include <time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

#include "config.h"
#include "struct.h"
#include "webbbs.h"


/*************************************************************
*   �i�K�G�i
**************************************************************/
int 
PostPut()
{
	char bname[BNAME_LEN];
	char subject[STRLEN], subject_new[STRLEN];
	char content[CONTENT_LENGTH], content_new[CONTENT_LENGTH];
	char sign[3], fname[STRLEN], buffer[10];
	int sign_num;
	char *p;
	long word;
	FILE *fp;
	struct boardheader bh;
	BOOL tonews = FALSE;
	time_t now;

	gets(pbuf);

	/* ���o�Ѽ� */
	GetPara2(bname, "BOARD", pbuf, BNAME_LEN, "");
	GetPara2(subject, "SUBJECT", pbuf, STRLEN, "");
	GetPara2(sign, "SIGN", pbuf, 3, "");

	if ((strlen(username) == 0) || (strlen(password) == 0) || (strlen(bname) == 0) ||
	    (strlen(subject) == 0) || (strlen(sign) == 0))
		return FALSE;

	sign_num = atoi(sign);
	if ((sign_num < 0) || (sign_num > 3))
		return FALSE;

	GetPara2(content, "CONTENT", pbuf, CONTENT_LENGTH, "");
	if (strlen(content) == 0)
		return FALSE;

	/* �P�_�K�X�O�_���T */
	if (!CheckUser(username, password, &curuser))
		return FALSE;

	/* �P�_�ҿ�J���O�O�_�s�b */
	if (get_board(&bh, bname) <= 0)
		return FALSE;

	if (bh.filename[0] == '\0')	/* NULL board name */
		return FALSE;
	/* ���Ť��� or ����{�Ҧ��|���{�� */
	if ((curuser.userlevel < bh.level) || ((bh.brdtype & BRDTYPE_IDENT) && (curuser.ident != 7)))
		return FALSE;

	sprintf(fname, "tmp/WEBUSER.%-d", time(0));
	if ((fp = fopen(fname, "w")) == NULL)
	{
		fclose(fp);
		return FALSE;
	}
	chmod(fname, 0644);

	Convert(subject, subject_new);
	

	now = time(0);
	p = ctime(&now);
	*(p + strlen(p) - 1) = '\0';
	sprintf(buffer, "%s WEB BBS", BBSNAME);
	write_article_header(fp, username, curuser.username, bname, p,
	                     subject_new, buffer);
	fputs("\n", fp);	                    

	Convert(content, content_new);
	
	fwrite(content_new, strlen(content_new), 1, fp);

	fclose(fp);

	if ((sign_num >= 1) && (sign_num <= 3))
		include_sig(username, fname, sign_num);
	if ((bh.brdtype & BRDTYPE_NEWS) && curuser.ident == 7)
		tonews = TRUE;
	else
		tonews = FALSE;

	if (PublishPost(fname, username, bname, subject_new, curuser.ident,
			fromhost, tonews, NULL) == -1)
	{
		unlink(fname);
		return FALSE;
	}
	unlink(fname);
	return TRUE;
}


#define RE_EBNAME	1
#define RE_CBNAME	2
#define RE_BMNAME	3

int request, id;
char boardhtml[255], before[255], after[255];
int haveBoardhtml;

int
show_board(bhentp)
BOARDHEADER *bhentp;
{
	if (can_see_board(bhentp, 0))
	{
		if (bhentp->class == id)
		{
			char *show;

			switch (request)
			{
				case RE_EBNAME:
					show = bhentp->filename;
					break;
				case RE_CBNAME:
					show = bhentp->title;
					break;
				case RE_BMNAME:
					show = bhentp->owner;
					break;
				default:
					show = "";
					break;
			}
			if (haveBoardhtml)
				printf("%s<A HREF=\"%s?BoardName=%s\">%s</A><br>%s\r\n",
				       before, boardhtml, show, show, after);
			else
				printf("%s%s<br>%s\r\n", before, show, after);
		}
	}
}


/***********************************************************
* BBS_BoardList_E-name BBS_BoardList_C-name BBS_BoardList_BM-name
*
* tag �e�i�ӨϥΪ̭쥻�ҤU���Ѽ�
* �q�X�^�� ���媩�W�άO���D�m�W
************************************************************/
ShowBoardList(tag)
char *tag;
{
	char *p;

	p = tag;
	/*�C�X�^�媩�W */
	if (strstr(tag, "BBS_BoardList_E-name") != NULL)
	{
		request = RE_EBNAME;
		p += strlen("BBS_BoardList_E-name") + 1;
		id = *p;
	}			/* �C�X���媩�W */
	else if (strstr(tag, "BBS_BoardList_C-name") != NULL)
	{
		request = RE_CBNAME;
		p += strlen("BBS_BoardList_C-name") + 1;
		id = *p;
	}			/* �C�X���D�m�W */
	else if (strstr(tag, "BBS_BoardList_BM-name") != NULL)
	{
		request = RE_BMNAME;
		p += strlen("BBS_BoardList_BM-name") + 1;
		id = *p;
	}

	/* �P�_�O�_�ݭn�[�Jhyperlink */
	GetPara(boardhtml, "boardhtml", tag);
	if (*boardhtml != 0)
		haveBoardhtml = TRUE;
	else
		haveBoardhtml = FALSE;

	GetPara(before, "before", tag);
	GetPara(after, "after", tag);

	resolve_brdshm();
	apply_brdshm(show_board);

	fflush(stdout);
}

/***********************************************************
*       BBS_Post_Sender 	BBS_Post_Date
*       BBS_Post_Subject 	BBS_Post_Content
*		BBS_Post_Num		BBS_Post_Boarname
*		BBS_Post_NextNum	BBS_Post_NextFileName
*       tag �e�i�ӨϥΪ̭쥻�ҤU���Ѽ�
*       �q�X�G�i���e
************************************************************/
void
ShowPost(tag)
char *tag;
{
	char BoardName[STRLEN], *p, *p2, boarddirect[STRLEN], askFileName[STRLEN];
	int idx, num, fd, haveFileName;
	struct fileheader fileinfo;
	char PostName[STRLEN];
	time_t date;

	if ((p = strstr(URLPara, "ReadPost")) != NULL)
	{
		p += strlen("ReadPost=");
		strcpy(BoardName, p);
		p2 = strrchr(BoardName, '/');
		*p2 = '\0';
		p2++;
		idx = atoi(p2);

		if (strstr(URLPara, "Last") != NULL)
			idx--;
		else if (strstr(URLPara, "Next") != NULL)
			idx++;
		haveFileName = FALSE;
	}
	else
	{
		p = strchr(URLPara, '/') + 1;
		strcpy(BoardName, p);
		p2 = strchr(BoardName, '/');
		*p2 = '\0';
		strcpy(askFileName, p2 + 1);
		haveFileName = TRUE;
	}

	setboardfile(boarddirect, BoardName, DIR_REC);
	num = get_num_records(boarddirect, FH_SIZE);	/* get post count */

	if (!haveFileName)
	{
		if (idx > num)
			idx = num;
		else if (idx < 1)
			idx = 1;
	}

	if ((fd = open(boarddirect, O_RDWR)) < 0)
		return;

	if (!haveFileName)
	{
		if (lseek(fd, (long) (FH_SIZE * (idx - 1)), SEEK_SET) == -1)
		{
			close(fd);
			return;
		}

		if (read(fd, &fileinfo, FH_SIZE) != FH_SIZE)
		{
			close(fd);
			return;
		}
	}
	else
	{
		idx = 0;
		while (read(fd, &fileinfo, FH_SIZE) == FH_SIZE)
		{
			idx++;
			if (!strcmp(fileinfo.filename, askFileName))
				break;
		}
		if ((strstr(tag, "BBS_Post_NextFileName") != NULL) ||
		    (strstr(tag, "BBS_Post_LastFileName") != NULL))
		{
			struct fileheader datainfo;
			if (strstr(tag, "BBS_Post_LastFileName") != NULL)
			{
				if (lseek(fd, -(FH_SIZE * 2), SEEK_CUR) == -1)
				{
					printf("%s", fileinfo.filename);
					fflush(stdout);
					close(fd);
					return;
				}
			}
			if (read(fd, &datainfo, FH_SIZE) == FH_SIZE)
				printf("%s", datainfo.filename);
			else
				printf("%s", fileinfo.filename);

			fflush(stdout);
			close(fd);
			return;
		}

	}

	close(fd);

	if (fileinfo.accessed & FILE_DELE)
	{
		printf("<form name=\"ReadPost\">\r\n");
		printf("<Input type=\"hidden\" name=\"boardname\" value=\"%s\">\r\n",
		       BoardName);
		printf("<Input type=\"hidden\" Name=\"number\" value=\"%d\">\r\n",
		       idx);
		printf("</form>\r\n");
		return;
	}

	strcpy(PostName, boarddirect);
	p = strrchr(PostName, '/') + 1;
	strcpy(p, fileinfo.filename);

	if (strstr(tag, "BBS_Post_Sender") != NULL)
		printf("%s", fileinfo.owner);
	else if (strstr(tag, "BBS_Post_Date") != NULL)
	{
		date = atol((fileinfo.filename) + 2);
		printf("%s", ctime(&date));
	}
	else if (strstr(tag, "BBS_Post_Subject") != NULL)
		printf("%s", fileinfo.title);
	else if (strstr(tag, "BBS_Post_Num") != NULL)
		printf("%d", idx);
	else if (strstr(tag, "BBS_Post_NextNum") != NULL)
		printf("%d", idx + 1);
	else if (strstr(tag, "BBS_Post_LastNum") != NULL)
		printf("%d", idx - 1);
	else if (strstr(tag, "BBS_Post_Boardname") != NULL)
		printf("%s", BoardName);
	else if (strstr(tag, "BBS_Post_Content") != NULL)
	{
		SendArticle(PostName, NULL);
		printf("<form name=\"ReadPost\">\r\n");
		printf("<Input type=\"hidden\" name=\"boardname\" value=\"%s\">\r\n",
		       BoardName);
		printf("<Input type=\"hidden\" Name=\"number\" value=\"%d\">\r\n",
		       idx);
		printf("</form>\r\n");

	}
}


/***********************************************************
*       BBS_Head_Num BBS_Head_Sender
*       BBS_Head_Date BBS_Head_Title
*		BBS_Head_BoardName
*       tag �e�i�ӨϥΪ̭쥻�ҤU���Ѽ�
*       �q�X�G�i�s�� �@�� ��� ���D
************************************************************/
/*ARGUSED */
void
ShowBoardHead(tag)
char *tag;
{
	char BoardName[BNAME_LEN], *p, boarddirect[STRLEN];
	int Start, End, num, fd, i, haveBoardhtml, defnum, direction;
	struct fileheader fileinfo;
	struct boardheader bh;
	char *request, chdate[6];
	time_t date;
	char boardhtml[255], before[255], after[255];
	char buffer[255];

	/* ��url�����o�Ѽ� */
	GetPara2(BoardName, "BoardName", URLPara, BNAME_LEN, "test");
	GetPara2(buffer, "start", URLPara, 4, "-1");
	Start = atoi(buffer);
	GetPara2(buffer, "end", URLPara, 4, "-1");
	End = atoi(buffer);
	GetPara2(buffer, "defnum", URLPara, 4, "40");
	defnum = atoi(buffer);
	GetPara2(buffer, "direction", URLPara, 3, "-1");
	direction = atoi(buffer);

	resolve_brdshm();

	if (get_board(&bh, BoardName) <= 0)
		return;

	if (!can_see_board(&bh, 0))
		return;

	/* ��tag���P�_�ҨD���� */
	if (strstr(tag, "BBS_Head_Sender") != NULL)
		request = fileinfo.owner;
	else if (strstr(tag, "BBS_Head_Title") != NULL)
		request = fileinfo.title;
	else if (strstr(tag, "BBS_Head_BoardName") != NULL)
	{
		printf("%s", BoardName);
		return;
	}

	GetPara(boardhtml, "boardhtml", tag);
	if (*boardhtml != 0)
		haveBoardhtml = TRUE;
	else
		haveBoardhtml = FALSE;

	GetPara(before, "before", tag);
	GetPara(after, "after", tag);

	setboardfile(boarddirect, BoardName, DIR_REC);
	num = get_num_records(boarddirect, FH_SIZE);	/* get post count */
	if (Start == -1)	/* �S���� Start �Ѽƭ� */
	{
		Start = num - defnum + 1;
		if (Start < 1)
			Start = 1;
		End = num;
	}
	else
	{
		if (End < Start)
			End = Start;
		if (Start < 1)
			Start = 1;
		if (End > num)
			End = num;
	}

	if ((direction == 1) && (End < Start))	/* ���W */
	{
		i = End;
		End = Start;
		Start = i;
	}
	else if ((direction == -1) && (Start < End))	/*���� */
	{
		i = End;
		End = Start;
		Start = i;
	}


	if ((fd = open(boarddirect, O_RDWR)) > 0)
	{

		if (lseek(fd, (long) (FH_SIZE * (Start - 1)), SEEK_SET) != -1)
		{

			for (i = Start; i != ((direction == 1) ? End + 1 : End - 1); i += direction)
			{
				lseek(fd, (FH_SIZE * (i - 1)), SEEK_SET);
				if (read(fd, &fileinfo, FH_SIZE) == FH_SIZE)
				{
					if ((p = strchr(fileinfo.owner, '@')) != NULL)
						*p = '\0';
					if (!(fileinfo.accessed & FILE_DELE))
					{
						if (haveBoardhtml)
						{
							if (strstr(tag, "BBS_Head_Num") != NULL)
								/*printf ("%s<A HREF=\"%s?ReadPost=%s/%d\">%d</A><br>%s\r\n", before, boardhtml, BoardName, i, i, after); */
								printf("%s<A HREF=\"unique/%s/%s/%s\">%d</A><br>%s\r\n", before, BoardName, fileinfo.filename, boardhtml, i, after);
							else if (strstr(tag, "BBS_Head_Date") != NULL)
							{
								date = atol((fileinfo.filename) + 2);
								strftime(chdate, 6, "%m/%d", localtime(&date));
								/*printf ("%s<A HREF=\"%s?ReadPost=%s/%d\">%s</A><br>%s\r\n" ,before, boardhtml, BoardName, i, chdate, after); */
								printf("%s<A HREF=\"unique/%s/%s/%s\">%s</A><br>%s\r\n", before, BoardName, fileinfo.filename, boardhtml, chdate, after);
							}
							else
								/*printf ("%s<A HREF=\"%s?ReadPost=%s/%d\">%s</A><br>%s\r\n", before, boardhtml, BoardName, i, request, after); */
								printf("%s<A HREF=\"unique/%s/%s/%s\">%s</A><br>%s\r\n", before, BoardName, fileinfo.filename, boardhtml, request, after);
						}
						else
						{
							if (strstr(tag, "BBS_Head_Num") != NULL)
							{
								printf("%s%d<br>%s\r\n", before, i, after);
							}
							else if (strstr(tag, "BBS_Head_Date") != NULL)
							{
								date = atol((fileinfo.filename) + 2);
								strftime(chdate, 6, "%m/%d", localtime(&date));
								printf("%s%s<br>%s\r\n", before, chdate, after);
							}
							else
								printf("%s%s<br>%s\r\n", before, request, after);
						}
					}
				}
			}
		}
		close(fd);
	}

	if (strstr(tag, "BBS_Head_Num") != NULL)
	{
		printf("<td>\r\n");
		printf("<form name=\"PostNum\">\r\n");
		printf("<input type=\"hidden\" name=\"boardname\" value=\"%s\">\r\n", BoardName);
		printf("<Input type=\"hidden\" Name=\"start\" value=\"%d\">\r\n", Start);
		printf("<Input type=\"hidden\" Name=\"end\" value=\"%d\">\r\n", End);
		printf("</form>\r\n");
		printf("</td>\r\n");
	}

	fflush(stdout);
}

/***********************************************************
*       BBS_Tera_Sender BBS_Tera_Date
*       BBS_Tera_Subject BBS_Tera_Content
*       tag �e�i�ӨϥΪ̭쥻�ҤU���Ѽ�
*       �q�X�G�i���e
************************************************************/
void
ShowTrea(tag)
char *tag;
{
	char BoardName[STRLEN], *p, *p2, boarddirect[STRLEN];
	int idx, num, fd;
	struct fileheader fileinfo;
	char PostName[STRLEN];
	time_t date;
	char oripath[255], realpath[255];	/* lasehu */

	p = strstr(URLPara, "ReadTrea");
	p += strlen("ReadTrea=");
	strcpy(BoardName, p);
	p2 = strrchr(BoardName, '/');
	*p2 = '\0';
	p2++;
	idx = atoi(p2);

	if (strstr(URLPara, "Last") != NULL)
		idx--;
	else if (strstr(URLPara, "Next") != NULL)
		idx++;
	strcpy(oripath, BoardName);
	sprintf(realpath, "%s/", BBSPATH_TREASURE);
	if ((p = strtok(oripath, "/")) != NULL)
	{
		strcat(realpath, p);
		while ((p = strtok(NULL, "/")) != NULL)
		{
			int fd;
			char fname[255];
			int i = atol(p);

			sprintf(fname, "%s/%s", realpath, DIR_REC);
			if ((fd = open(fname, O_RDONLY)) < 0)
				return;
			if (lseek(fd, (off_t) ((i - 1) * FH_SIZE), SEEK_SET) == -1)
			{
				close(fd);
				return;
			}
			if (read(fd, &fileinfo, FH_SIZE) != FH_SIZE)
			{
				close(fd);
				return;
			}
			strcat(realpath, "/");
			strcat(realpath, fileinfo.filename);
			close(fd);
		}
	}
	else
	{
		strcat(realpath, oripath);
	}

	sprintf(boarddirect, "%s/%s", realpath, DIR_REC);	/* lasehu */
	num = get_num_records(boarddirect, FH_SIZE);	/* get post count */
	if (idx > num)
		return;

	if ((fd = open(boarddirect, O_RDONLY)) < 0)
		return;

	if (lseek(fd, (long) (FH_SIZE * (idx - 1)), SEEK_SET) == -1)
	{
		close(fd);
		return;
	}

	if (read(fd, &fileinfo, FH_SIZE) != FH_SIZE)
	{
		close(fd);
		return;
	}

	if (fileinfo.accessed & FILE_DELE)
	{
		close(fd);
		return;
	}

	close(fd);
	strcpy(PostName, boarddirect);
	p = strrchr(PostName, '/') + 1;
	strcpy(p, fileinfo.filename);

	if (strstr(tag, "BBS_Post_Sender") != NULL)
		printf("%s\r\n", fileinfo.owner);
	else if (strstr(tag, "BBS_Post_Date") != NULL)
	{
		date = atol((fileinfo.filename) + 2);
		printf("%s\r\n", ctime(&date));
	}
	else if (strstr(tag, "BBS_Post_Subject") != NULL)
		printf("%s\r\n", fileinfo.title);
	else if (strstr(tag, "BBS_Post_Content") != NULL)
	{
		SendArticle(PostName, NULL);
		printf("<form name=\"ReadTrea\">\r\n");
		printf("<Input type=\"hidden\" name=\"boardname\" value=\"%s\">\r\n",
		       BoardName);
		printf("<Input type=\"hidden\" Name=\"number\" value=\"%d\">\r\n",
		       idx);
		printf("</form>\r\n");
	}
}

/***********************************************************
*       BBS_Head_Num BBS_Head_Sender
*       BBS_Head_Date BBS_Head_Title
*       tag �e�i�ӨϥΪ̭쥻�ҤU���Ѽ�
*       �q�X�G�i�s�� �@�� ��� ���D
************************************************************/
/*ARGUSED */
void
ShowTreasureHead(tag)
char *tag;
{
	char CurPath[255], *p, treadirect[STRLEN];
	int fd, i, haveTreahtml, haveBoardhtml;
	struct fileheader fhinfo;
	char *request, chdate[6];
	time_t date;
	char boardhtml[255], treahtml[255], before[255], after[255];
	char buffer[255], oripath[255], realpath[255], CurTitle[100];

	/* ��url�����o�Ѽ� */
	strcpy(buffer, URLPara);
	strcpy(CurPath, buffer + strlen("BoardName="));		/* ? */

	/* ��tag���P�_�ҨD���� */
	if (strstr(tag, "BBS_Trea_Sender") != NULL)
		request = fhinfo.owner;
	else if (strstr(tag, "BBS_Trea_Title") != NULL)
		request = fhinfo.title;

	GetPara(boardhtml, "boardhtml", tag);
	if (*boardhtml != 0)
		haveBoardhtml = TRUE;
	else
		haveBoardhtml = FALSE;
	GetPara(treahtml, "treahtml", tag);
	if (*treahtml != 0)
		haveTreahtml = TRUE;
	else
		haveTreahtml = FALSE;

	GetPara(before, "before", tag);
	GetPara(after, "after", tag);

	strcpy(oripath, CurPath);
	sprintf(realpath, "%s/", BBSPATH_TREASURE);
	if ((p = strtok(oripath, "/")) != NULL)
	{
		strcat(realpath, p);
		while ((p = strtok(NULL, "/")) != NULL)
		{
			int fd;
			char fname[255];
			int i = atol(p);

			sprintf(fname, "%s/%s", realpath, DIR_REC);
			if ((fd = open(fname, O_RDONLY)) < 0)
				return;
			if (lseek(fd, (off_t) ((i - 1) * FH_SIZE), SEEK_SET) == -1)
			{
				close(fd);
				return;
			}
			if (read(fd, &fhinfo, FH_SIZE) != FH_SIZE)
			{
				close(fd);
				return;
			}
			strcat(realpath, "/");
			strcat(realpath, fhinfo.filename);

			strcpy(CurTitle, fhinfo.title);
			close(fd);
		}
	}
	else
	{
		CurTitle[0] = '\0';	/* lasehu */
		strcat(realpath, CurPath);
	}
	sprintf(treadirect, "%s/%s", realpath, DIR_REC);

	if ((fd = open(treadirect, O_RDWR)) > 0)
	{
		for (i = 1; read(fd, &fhinfo, FH_SIZE) == FH_SIZE; i++)
		{
			if ((p = strchr(fhinfo.owner, '@')) != NULL)
				*p = '\0';
			if ((fhinfo.accessed & FILE_DELE))
				continue;
			if (fhinfo.accessed & FILE_TREA)
			{
				if (haveTreahtml)
				{
					if (strstr(tag, "BBS_Trea_Num") != NULL)
					{
						printf("%s<A HREF=\"%s?BoardName=%s/%d\">%d</A><br>%s\r\n",
						       before, treahtml, CurPath, i, i, after);
					}
					else if (strstr(tag, "BBS_Trea_Date") != NULL)
					{
						date = atol((fhinfo.filename) + 2);
						strftime(chdate, 6, "%m/%d", localtime(&date));
						printf("%s<A HREF=\"%s?BoardName=%s/%d\">%s</A><br>%s\r\n",
						       before, treahtml, CurPath, i, chdate, after);
					}
					else if (strstr(tag, "BBS_Trea_Sender") != NULL)
						printf("%s%s<br>%s\r\n", before, "[�ؿ�]", after);
					else
						printf("%s<A HREF=\"%s?BoardName=%s/%d\">%s</A><br>%s\r\n",
						       before, treahtml, CurPath, i, request, after);
				}
				else
				{
					if (strstr(tag, "BBS_Trea_Num") != NULL)
					{
						printf("%s%d<br>%s\r\n", before, i, after);
					}
					else if (strstr(tag, "BBS_Trea_Date") != NULL)
					{
						date = atol((fhinfo.filename) + 2);
						strftime(chdate, 6, "%m/%d", localtime(&date));
						printf("%s%s<br>%s\r\n", before, chdate, after);
					}
					else
						printf("%s%s<br>%s\r\n", before, request, after);
				}
			}
			else
			{
				if (haveBoardhtml)
				{
					if (strstr(tag, "BBS_Trea_Num") != NULL)
					{
						printf("%s<A HREF=\"%s?ReadTrea=%s/%d\">%d</A><br>%s\r\n",
						       before, boardhtml, CurPath, i, i, after);
					}
					else if (strstr(tag, "BBS_Trea_Date") != NULL)
					{
						date = atol((fhinfo.filename) + 2);
						strftime(chdate, 6, "%m/%d", localtime(&date));
						printf("%s<A HREF=\"%s?ReadTrea=%s/%d\">%s</A><br>%s\r\n",
						       before, boardhtml, CurPath, i, chdate, after);
					}
					else
					{
						printf("%s<A HREF=\"%s?ReadTrea=%s/%d\">%s</A><br>%s\r\n",
						       before, boardhtml, CurPath, i, request, after);
					}
				}
				else
				{
					if (strstr(tag, "BBS_Trea_Num") != NULL)
					{
						printf("%s%d<br>%s\r\n", before, i, after);
					}
					else if (strstr(tag, "BBS_Trea_Date") != NULL)
					{
						date = atol((fhinfo.filename) + 2);
						strftime(chdate, 6, "%m/%d", localtime(&date));
						printf("%s%s<br>%s\r\n", before, chdate, after);
					}
					else
						printf("%s%s<br>%s\r\n", before, request, after);
				}
			}
		}
		close(fd);
	}

	if (strstr(tag, "BBS_Trea_Num"))
	{
		printf("<td>\r\n");
		printf("<form name=\"PostNum\">\r\n");
		printf("<input type=\"hidden\" name=\"boardname\" value=\"%s\">\r\n",
		       CurPath);
		printf("<input type=\"hidden\" name=\"treatitle\" value=\"%s\">\r\n",
		       CurTitle);
/*--- lasehu
        printf ("<Input type=\"hidden\" Name=\"start\" value=\"%d\">\r\n", Start
);
        printf ("<Input type=\"hidden\" Name=\"end\" value=\"%d\">\r\n", End);
*/
		printf("</form>\r\n");
		printf("</td>\r\n");
	}
	fflush(stdout);
}
