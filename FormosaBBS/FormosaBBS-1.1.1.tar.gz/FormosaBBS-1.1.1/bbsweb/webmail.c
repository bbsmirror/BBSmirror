/*****************************************************
	Formosa Web Server ������ mail ������
	Author: Cauchy		�L�C�y SongChin Lin
******************************************************/

#include "bbs.h"
#include "webbbs.h"



/***********************************************************
*	���o�ӤH�H�c�H��ƥ�
*	type	�n���o�X�������ƥ�
*			1 -- �@��H��
*			2 -- FAX
*			3 -- VOICE
************************************************************/
int 
GetMailNum(type)
int type;
{
	char maildirect[STRLEN];
	int num;
	struct stat st;

	if (strlen(username) == 0)
		return 0;

	setmailfile(maildirect, username, DIR_REC);

	if (type == 1)
	{
		if (stat(maildirect, &st) == 0 && st.st_size > 0)
			num = st.st_size / FH_SIZE;
		else
			num = 0;
	}
	return num;
}

/***********************************************************
* BBS_MailList_Read BBS_MailList_num BBS_MailList_Sender
* BBS_MailList_Date BBS_MailList_Subject
*
* tag �e�i�ӨϥΪ̭쥻�ҤU���Ѽ�
* �ӤH�H�c�C��
************************************************************/
/*ARGUSED */
ShowMailList(tag)
char *tag;
{
	int fd, number, mailindex;
	struct fileheader fh;
	char *request, mail_state, ReadFlag[255], buffer[10];
	char boardhtml[255], before[255], after[255], maildirect[STRLEN],
	  chdate[6];
	int haveBoardhtml, index;
	time_t date;

	/* �P�_�K�X�O�_���T */
	if (!CheckUser(username, password, &curuser))
		return FALSE;

	setmailfile(maildirect, curuser.userid, DIR_REC);

	/* p = tag; */
	/* �C�X�H��̩m�W */
	if (strstr(tag, "BBS_MailList_Sender") != NULL)
	{
		request = fh.owner;
		/* p += strlen ("BBS_MailList_Sender") + 1; */
	}			/* �C�X�H����D */
	else if (strstr(tag, "BBS_MailList_Subject") != NULL)
	{
		request = fh.title;
		/* p += strlen ("BBS_MailList_Subject") + 1; */
	}

	/* �P�_�O�_�ݭn�[�Jhyperlink */
	GetPara(boardhtml, "boardhtml", tag);
	if (*boardhtml != 0)
		haveBoardhtml = TRUE;
	else
		haveBoardhtml = FALSE;

	GetPara(before, "before", tag);
	GetPara(after, "after", tag);
	GetPara(buffer, "number", tag);
	number = atoi(buffer);


	if ((fd = open(maildirect, O_RDWR)) < 0)
		return;
	index = 1;

	/* �����wnumber�Ѽ� */
	if (number > 0)
	{
		mailindex = 0;
		while (read(fd, &fh, FH_SIZE) == FH_SIZE)
		{
				mailindex++;
			if (mailindex == number)
			{
				if (lseek(fd, -FH_SIZE, SEEK_CUR) == -1)
				{
					close(fd);
					return;
				}
				break;
			}
		}
		index = number;
	}

	while (read(fd, &fh, FH_SIZE) == FH_SIZE)
	{
		{
			if (strstr(tag, "BBS_MailList_Num") != NULL)
			{
				if (haveBoardhtml)
					printf("%s<A HREF=\"%s?ReadMail=%d\">%d</A><br>%s\r\n",
					       before, boardhtml, index, index, after);
				else
					printf("%s%d<br>%s\r\n", before, index, after);
			}
			else if (strstr(tag, "BBS_MailList_Date") != NULL)
			{
				date = atol((fh.filename) + 2);
				strftime(chdate, 6, "%m/%d", localtime(&date));
				if (haveBoardhtml)
					printf("%s<A HREF=\"%s?ReadMail=%d\">%s</A><br>%s\r\n",
					       before, boardhtml, index, chdate, after);
				else
					printf("%s%s<br>%s\r\n", before, chdate, after);
			}
			else if (strstr(tag, "BBS_MailList_Read") != NULL)
			{
				if (fh.accessed & FILE_DELE)
					NULL;
				else if (fh.accessed & FILE_READ)
					GetPara(ReadFlag, "old", tag);
				else
					GetPara(ReadFlag, "new", tag);
				if (haveBoardhtml)
					printf("%s<A HREF=\"%s?ReadMail=%d\">%s</A><br>%s\r\n",
					       before, boardhtml, index, ReadFlag, after);
				else
					printf("%s%s<br>%s\r\n", before, ReadFlag, after);
			}
			else
			{
				if (haveBoardhtml)
					printf("%s<A HREF=\"%s?ReadMail=%d\">%s</A><br>%s\r\n",
					       before, boardhtml, index, request, after);
				else
					printf("%s%s<br>%s\r\n", before, request, after);
			}
		}
		if (number > 0)
			break;
		index++;
	}
	fflush(stdout);
	close(fd);
}


/***********************************************************
*       BBS_MailGet_Sender BBS_MailGet_Date
*       BBS_MailGet_Subject BBS_MailGet_Content
*       tag �e�i�ӨϥΪ̭쥻�ҤU���Ѽ�
*       �q�X�H�󤺮e
************************************************************/
void
ShowMail(tag)
char *tag;
{
	char buffer[256], *p, *p2, maildirect[256];
	int idx, num, fd, mailindex;
	struct fileheader fileinfo;
	char MailName[STRLEN];
	time_t date;
	struct userec curuser;
	char attach[256];

	/* �P�_�K�X�O�_���T */
	if (!CheckUser(username, password, &curuser))
		return;

	setmailfile(maildirect, curuser.userid, DIR_REC);

	p = strstr(URLPara, "ReadMail");
	p += strlen("ReadMail=");
	strcpy(buffer, p);
	p2 = strrchr(buffer, '/');
	if (p2 != NULL)
		*p2 = '\0';
	idx = atoi(p);

	if (strstr(URLPara, "Last") != NULL)
		idx--;
	else if (strstr(URLPara, "Next") != NULL)
		idx++;

	/* num = get_num_records (maildirect, FH_SIZE);    get mail count */
	num = GetMailNum(1);
	if (idx > num)
		return;

	if ((fd = open(maildirect, O_RDWR)) < 0)
		return;


	mailindex = 0;
	while (read(fd, &fileinfo, FH_SIZE) == FH_SIZE)
	{
			mailindex++;
		if (mailindex == idx)
			break;
	}


	if (fileinfo.accessed & FILE_DELE)
	{
		close(fd);
		printf("<form name=\"ReadPost\">\r\n");
		printf("<Input type=\"hidden\" Name=\"number\" value=\"%d\">\r\n",
		       idx);
		printf("</form>\r\n");
		return;
	}

	if (lseek(fd, -FH_SIZE, SEEK_CUR) == -1)
	{
		close(fd);
		return;
	}

	fileinfo.accessed |= FILE_READ;
	write(fd, &fileinfo, FH_SIZE);
	close(fd);

	strcpy(MailName, maildirect);
	p = strrchr(MailName, '/') + 1;
	strcpy(p, fileinfo.filename);

	if (strstr(tag, "BBS_MailGet_Sender") != NULL)
		printf("%s\r\n", fileinfo.owner);
	else if (strstr(tag, "BBS_MailGet_Date") != NULL)
	{
		date = atol((fileinfo.filename) + 2);
		printf("%s\r\n", ctime(&date));
	}
	else if (strstr(tag, "BBS_MailGet_Subject") != NULL)
		printf("%s\r\n", fileinfo.title);
	else if (strstr(tag, "BBS_MailGet_Content") != NULL)
	{
		SendArticle(MailName, attach);
		/* printf("<a href=\"%s\">attach file</a>\r\n", attach); */

		printf("<form name=\"ReadMail\">\r\n");
		printf("<Input type=\"hidden\" Name=\"number\" value=\"%d\">\r\n",
		       idx);
		printf("</form>\r\n");

	}
}
