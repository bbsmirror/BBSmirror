#ifndef _BBS_CHAT_H
#define _BBS_CHAT_H

#define MAXPORTS	60	/* max. chatroom user */

#define CHATPORT        5177      /* port numbers for the chat rooms */

#define PROTOLEN        12

/* Protocol Define */

#define CHAT_JOIN       0010
#define CHAT_USRID      0011
#define CHAT_TOPIC      0012
#define CHAT_PASSWD     0013
#define CHAT_QUIT       0014
#define CHAT_MSG        0020
#define CHAT_WHO        0030
#define CHAT_WHOALL     0040
#define CHAT_NICKNAME   0050
#ifdef HAVE_CHATMSGALL
#define CHAT_MSGALL     0060
#endif
#define CHAT_LISTCHAN   0070
#define CHAT_SPEAK      0075
#define CHAT_IGNORE     0076

/* Error Message Define */
#define OK_CMD      700
#define WORK_FAIL   710
#define PASS_FAIL   720
#define USR_FAIL    730
#define NAME_FAIL   740
#define CMD_ERROR   750

#define DEF_CHANNAME    "DefChannel"	/* -ToDo */

#define NOPASSWORD      "nopass"

#define CHANLEN	    (15)
#define TOPICLEN    (20)


char *GetPass(), *PhaseSpace();


char *
mycrypt (pw)
     char *pw;
{
	static char saltc[14];

	sprintf (saltc, "%ld", atol (pw) + 1);
	return saltc;
}


#define KEYWORD_DELIMITER     " \t\r\n"
#define KEYWORD_SEPARATE      " \t\r\n"

char *
PhaseSpace (str)
     char *str;
{
	register int i, j = 0;

	if (*str == '\0')
		return str;
	while (strchr (KEYWORD_DELIMITER, str[j]))
		j++;

	i = strlen (str) - 1;
	while (i >= 0 && strchr (KEYWORD_DELIMITER, str[i]))
		i--;
	str[i + 1] = '\0';

	return &str[j];
}


char *
GetPass (str, token, maxlen)
     char *str;
     char *token;
     int maxlen;
{
	register int i = 0, j;
	char *tmp;
	int len = strlen(str);

	while (strchr (KEYWORD_DELIMITER, str[i]))	/* �h���e�����ť� */
	{
		if (str[i] == '\0')
		{
			token[0] = '\0';
			return &str[i];
		}
		i++;
	}
	tmp = &str[i];
	len -= i;
	j = 1;
	while (j < len && !strchr (KEYWORD_SEPARATE, tmp[j]))	/* �Htab�����j�A��X�Ѽ� */
		j++;

	if (j >= maxlen)
	{			/* token too large */
/* del by lasehu
   token[0] = '\0';
 */
		j = maxlen - 1;	/* lasehu */
	}
/* del by lasehu
   else
   {
 */
	strncpy (token, tmp, j);
	token[j] = '\0';	/* important */
/*
   }
 */
	return &tmp[j];
}

#endif	/* _BBS_CHAT_H */
