
#ifndef _BBS_STRUCT_H_
#define _BBS_STRUCT_H_


#define PATHLEN    255	/* max # of characters in a path name */

#define STRLEN		80	/* Length of most string data */
#define IDLEN		13	/* Length of userids */
#define UNAMELEN	21	/* Length of username */
#define HOSTLEN		16	/* Length of from host */


struct useridx {	/* Structure used in .USERIDX */
	char userid[IDLEN+1];
};


#define PASSLEN		14	/* Length of encrypted passwd field */

/* these are flags in userec.flags[0] */
#define PAGER_FLAG      0x01    /* true if pager was OFF last session */
#define CLOAK_FLAG      0x02    /* true if cloak ON */
#define FORWARD_FLAG    0x04    /* true if auto-forward personal's mail */
#define SIG_FLAG        0x08    /* true if sig was turned OFF last session */
#define CHKONLY_FLAG    0x10	/* true is unaccept checked ID calling */
#define	YANK_FLAG       0x40    /* the board list yank flag, true if yank out */
#define	COLOR_FLAG      0x80    /* color mode or black/white mode, ture is b/w*/

#define PICTURE_FLAG	0x01    /* true if use motive picture mode */
#define NOTE_FLAG       0x02    /* true if view note when login */

/* used in ctype */
#define CTYPE_CSBBS     0
#define CTYPE_TSBBS     1
#define CTYPE_WEBBBS    2

struct userec {		/* Structure used to hold information in PASSFLE */
	char userid[IDLEN+1];
	char unused_filler[30];		/* unused */
	time_t firstlogin;			/* When first time user registered */
	char lasthost[HOSTLEN];		/* Where user is from last time */
	unsigned int numlogins;		/* Number of user ever logins */
	unsigned int numposts;		/* Number of user ever post */
	unsigned char flags[2];
	char passwd[PASSLEN];		/* Encryption of password */
	char username[UNAMELEN+7];	/* nickname */
	char unused_str11[60];
	char lastctype;				/* By which way user login */
	char unused_str2[STRLEN-10];
	char ident;					/* user identification */
	unsigned int userlevel;
	time_t lastlogin;
	unsigned int telecomm;		/* unique number for TeleComm */
	unsigned int uid;			/* unique uid */
	char email[STRLEN-44];
	char unused_str3[44];
};

typedef struct userec USEREC;


struct user_info {	
	int active;				/* When allocated this field is true */
	unsigned int uid;		/* Used to find user name entry in passwd file */
	pid_t pid;				/* kill() is used to notify user of talk request */
	int invisible;			/* Used by cloaking function in Xyz menu */
	int sockactive;			/* Used to coordinate talk requests */
	int sockaddr;			/* Notify talk client-peer where server port is */
	int mode;				/* Talk Mode, Chat Mode, ... */
	int pager;				/* pager toggle, TRUE, or FALSE */
#ifdef HAVE_CHK	
	int chk;				/* true is unaccept checked ID calling */
#endif	
	int ever_delete_mail;	/* Ever delete mail this time ? */
	time_t login_time;		/* time when entry was made */
	char destid[IDLEN];		/* talk parner user's id name */	
	char userid[IDLEN];
	char username[UNAMELEN];	/* user nickname */
	char from[HOSTLEN];		/* machine name the user called in from */
	char chatid[16];		/* chat id, if in chat mode */
	char ctype;				/* By which way user login */
};

typedef struct user_info USER_INFO;


#define USHM_SIZE	(MAXACTIVE+4)

struct UTMPFILE {	/* Shared Memory, for unix-like utmp */
    time_t mtime;
    int number;
    USER_INFO uinfo[USHM_SIZE];
};


/* 
 * semaphore
 */
#define SEM_ENTER	-1	/* Enter semaphore, lock for exclusive use */
#define SEM_EXIT	1	/* Exit semaphore, unlock a previously locked region */
#define SEM_RESET	0	/* Reset semaphore */


/* Flags used in fileheader accessed */
#define FILE_READ   0x01	/* readed, only used in mail folder */
#define FILE_DELE   0x02	/* mark article as deleted */
#define FILE_TREA   0x04	/* treasure directiory */
#define FILE_RESRV  0x08	/* article is reserved */
#if 0
#define FILE_IN     0x10	/* �����ɮ� */
#define FILE_OUT    0x20	/* ���~�ɮ� */
#endif
#ifdef HAVE_TELECOMM
#define FILE_FAX    0x40	/* virtual fax */
#define FILE_ANS    0x80    /* virtual voice answer */
#endif

struct fileheader {	  
	char filename[STRLEN-4-4];
	int  artno;				/* no. of article */
	char ident;				/* the identification of owner */
	char unused_str1[3];
	char owner[STRLEN];
	char title[STRLEN];
	unsigned int level;
	unsigned char accessed;
};

typedef struct fileheader FILEHEADER;

#define FH_SIZE    (sizeof(struct fileheader))


#define BNAME_LEN   17
#define CBNAME_LEN  36
#define BMASLEN		(5*IDLEN)   /* Length of bmas totally */

/* the attrib of board */
#define BRDTYPE_IDENT       0x01   /* �w�q�L�{�Ҥ~�i�i�K */
#define BRDTYPE_NEWS		0x02   /* ��H */
#define BRDTYPE_UNZAP       0x04   /* �L�k ZAP �� */
#define BRDTYPE_NOPOSTNUM   0x08   /* ���p�i�K�� */
#define BRDTYPE_ANNOUNCE	0x10   /* ���i�� */
#define BRDTYPE_PRIVATE		0x20   /* ���êO */
#if 0
#define BRDTYPE_ADM	        0x40   /* ���D�P�U��i�i�K */
#define BRDTYPE_ANONY       0x20   /* �ΦW�i�K */
#define BRDTYPE_VOTING      0x80   /* ���b�벼 */
#endif

struct boardheader {
	char filename[BNAME_LEN+3];
	time_t	rewind_time;      /* lasehu: last refresh boardrc time */
	unsigned int bid;         /* lasehu: board unique number, always increasing */
	int  firstartno;          /* lasehu: the first article's artno, excluding reserved articles */
	char unused1[STRLEN-BNAME_LEN-18];
	char class;               /* �O������ */
	char unused_type;         /* ��H���O  */
	unsigned char brdtype;    /* �ݪO�ݩʺX�� */
	char owner[BMASLEN+15];      /* There are several userids in the field,
	                             the each length is IDLEN */
	char title[CBNAME_LEN+4];	/* description of board */
	char unused2[STRLEN-CBNAME_LEN-4] ; 
	unsigned int level;	
#ifdef OLD_BOARDHEADER
	unsigned char accessed[10000]; /* -ToDo- remove this big array */
#endif	
};

typedef struct boardheader BOARDHEADER;

#define BH_SIZE	(sizeof(struct boardheader))


struct BRDSHM {
	int number;
	BOARDHEADER brdhr[MAXBOARD];
	time_t mtime;
};


#define BRC_MAXNUM      (500)
#define BRC_REALMAXNUM	(BRC_MAXNUM*8)

struct readrc {	/* record of board post whether is readed or not */
	unsigned int  bid;
    unsigned char rlist[BRC_MAXNUM]; 
    time_t	mtime;
	time_t  unused;
};	/* size: 512 bytes */


/* 
 * record of user which ever visit our site 
 */
struct visitor {
    char userid[IDLEN];
    time_t when;
    char from[HOSTLEN];
};


/* 
 * dynamic advertisement - MenuShow 
 */
#define MENUSHOW_KEY       1812	   /* share memory key */
#define MENUSHOW_SIZE      500	   /* �n���X�g post �� share memory */
#define MENUSHOW_FILE      "conf/menushow"
#define MENUSHOW_DEFAULT   "treasure/main-menu" /* if no MENUSHOW_FILE */
#define MENUSHOW_BODY      1792    /* ���h�j������q���� share memory */
 
struct MSList {
	char path[128];
	char header[128];
	char body[MENUSHOW_BODY];
};

struct MenuShowShm {
	char flag;
	int number;
	struct MSList list[MENUSHOW_SIZE];
};


/* 
 * notepad 
 */
#define NOTE_SIZE   200 /* �d�����g�ƭ��� */
 
struct notedata
{
	time_t date;                /* ��L�ªv�� */
	struct tm *tt;              /* �ɶ����c */
	char userid[IDLEN];         /* �ϥΪ�ID */
	char username[UNAMELEN];    /* �ϥΪ̼ʺ� */
	char buf[4][80];            /* ���Y�B���� */
};

typedef struct notedata NOTEDATA;


/* 
 * used in user_login() 
 */
enum ULOGIN { 
	ULOGIN_OK       = 0,
    ULOGIN_NOSPC    = -1,
    ULOGIN_NOENT    = -2,
    ULOGIN_ACCDIS   = -3,
    ULOGIN_PASSFAIL = -4
};


/* 
 * keyword of personal files 
 */
#define UFNAME_IRCRC	    "ircrc"
#define UFNAME_OVERRIDES	"overrides"
#define UFNAME_PASSWDS      "passwds"
#define UFNAME_PLANS        "plans"
#define UFNAME_READRC       "readrc"
#define UFNAME_RECORDS      "records"
#define UFNAME_SIGNATURES	"signatures"
#define UFNAME_ZAPRC        "zaprc"
#define UFNAME_IDENT        "ident"

#define UFNAME_EDIT         "edit"
#define UFNAME_MAIL         "mail"
#define UFNAME_WRITE        "write"


#define STR_REPLY        "Re: "
#define REPLY_LEN        (4)
#define _str_original    "�o�H�H: "
#define _msg_quote_said  "���峹������"


/* 
 * �t�θ���ɮפl�ؿ� 
 */
#define BBSPATH_DELUSER  "deluser"   /*�s��Q�R�����b���K�X�ɥؿ� */
#define BBSPATH_BOARDS   "boards"    /* �O���ؿ� */
#define BBSPATH_TREASURE "treasure"  /* ��ذϥؿ� */
#define BBSPATH_REALUSER "realuser"  /* User�{�ҽs�X��ƥؿ� */
#define BBSPATH_IDENT    "ID"


/*
 * ���|�P�ɦW�w�q��
 */
#define DIR_REC      ".DIR"
#define PASSFILE     "conf/.PASSWDS"
#define BOARDS       "conf/.BOARDS"
#define USERIDX      "conf/.USERIDX"

#define BM_WELCOME   ".bm_welcome"
#define BM_ASSISTANT ".bm_assistant"    

#define BOARD_HELP   "doc/BOARD_HELP"
#define READ_HELP    "doc/READ_HELP"
#define MAIL_HELP    "doc/MAIL_HELP"
#define EDIT_HELP    "doc/EDIT_HELP"
#define WELCOME0     "doc/Welcome0"
#define WELCOME      "doc/Welcome"
#define NEWGUIDE     "doc/NewGuide"

#define BBSSRV_WELCOME "conf/welcome"   /* �i���e�� */
#define BADUSERID      "conf/baduserid" /* ������ Login ���ϥΪ̱b���r�� */
#define NONEWUSER      "conf/nonewuser" /* �Y���ɦs�b, �h�������s�ϥΪ̵��U */
#define BOARDLIMIT     "conf/expire.cf"
#define MENUSHOW	   "conf/menushow"  /* ���ɨ�w menushow ���ѦҬݪO���| */
#define BBS_NEWS_CONF  "news/bbs-news.conf" /* bbs-news �]�w�� */

#define PATH_VISITOR     "log/visitor"      /* �W���H���ɶ��O�� */
#define PATH_VISITOR_LOG "log/visitor.log"
#define PATH_BBSLOG      "log/bbslog"       /* �t�ΰO���� */
#define PATH_BBSMAIL_LOG "log/bbsmail.log"  /* �����~�H��O�� */
#define PATH_IDENTLOG    "log/identlog"     /* �{�Ҧ^�H�O�� */
#define PATH_USIES       "log/usies"        /* �t�ΰO���� */


/* other define */
#define NL	0x0a	        /* new line char */
#define SP	0x20            /* space cchar */
#define ESC	0x1b            /* Esc char */
#define TAB	0x09            /* TAB char */

/*
typedef int BOOL;
*/
typedef short BOOL;

#ifndef TRUE
#define TRUE  (1)
#define FALSE (0)
#endif


#define CLASS_CONFILE	"conf/class.cf"

struct class_t {
	char cn[8];
	char bn[72];
	struct class_t *child;
	struct class_t *sibling;
};

#define CLASS_MAXNUM	(MAXBOARD + 256)

struct CLASSHM {
	time_t mtime;
	struct class_t cslist[CLASS_MAXNUM];
};
	

#define QUIT_LOOP 0x666


#endif /* _BBS_STRUCT_H_ */

