
#ifndef _BBS_BBS_H_
#define _BBS_BBS_H_

/*******************************************************************
 * 	�t�Χt�A��
 *******************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>
#include <signal.h>
#include <fcntl.h>
#include <ctype.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#ifdef	NO_DIRENT
#include <sys/dir.h>
#else
#include <dirent.h>
#endif

#ifdef  AIX
#include <sys/select.h>
#endif


/*******************************************************************
 *	�C���w�q
 *******************************************************************/

#ifndef LOCK_EX
# define LOCK_EX               F_LOCK     /* exclusive lock */
# define LOCK_UN               F_ULOCK    /* unlock */
#endif

#ifdef  SYSV
# define getdtablesize()        (64)
# define bzero(tgt, len)        memset( tgt, 0, len )
# define bcopy(src, tgt, len)   memcpy( tgt, src, len)
#endif

#ifndef AIX
#define index(buf, ch)          strchr( buf, ch )
#define rindex(buf, ch)         strrchr( buf, ch )
#endif

#ifndef CTRL
#define CTRL(c) (c&037)
#endif

#if 0
# ifdef SYSV
# undef CTRL                    /* SVR4 CTRL macro is hokey */
# define CTRL(c) ('c'&037)      /* This gives ESIX a warning...ignore it! */
# endif 
#endif

#ifndef	MIN
#define MIN(a,b)                (((a)<(b))?(a):(b))
#define MAX(a,b)                (((a)>(b))?(a):(b))
#endif


/*******************************************************************
 *	�۩w�t�A��
 *******************************************************************/
#include "config.h"
#include "common.h"


#endif /* _BBS_BBS_H_ */

