
#ifndef _BBS_LINKLIST_H
#define _BBS_LINKLIST_H


struct array {
	int number;
	char **datap;
};	
struct	word	{
	struct	word	*last;
	char	*word;
	struct	word	*next;
};

#endif	/* _BBS_LINLIST_H */
