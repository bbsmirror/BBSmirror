#ifndef _BBS_STRUCT_H_
#define _BBS_STRUCT_H_


/*
   ��Ƶ��c
*/   
#define STRLEN    80    	/* Length of most string data */
#define IDLEN	  12    	/* Length of userids */
#define UNAMELEN  20	    /* Length of username */
#define HOSTLEN   16	/* xxx.xxx.xxx.xxx */

/* don't modify ! */
#define CRYPTLEN  8      /* �� 8 �Ӧr���g crypt �s�X�L�Უ�� 13 �Ӧr�� */
#define PASSLEN   14    	/* Length of encrypted passwd field */


struct useridx {        /* Structure used in .USERIDX */
	char userid[IDLEN+2];
};

struct userec {         /* Structure used to hold information in PASSFLE */
	char userid[IDLEN+2] ;	
	char filler[30];           /* lasehu: unused */
	time_t firstlogin;         /* lasehu: user new register time */	
	char lasthost[HOSTLEN];
	unsigned int numlogins;
	unsigned int numposts;
	unsigned char flags[2];	   /* lasehu: flags[1] unused */
	char passwd[PASSLEN] ;
	char username[STRLEN-52] ; /* -ToDo- limit username length */
	char unused_str1[52];
	char termtype[8];		   /* lasehu: unused */
	char lastctype ;           /* CSBBS or TSBBS */
	char unused_str2[STRLEN-10] ;	
	char ident;
	unsigned int userlevel ;
	time_t lastlogin ;
	int protocol ;          /* lasehu: unused */
	unsigned int uid;      
	char email[STRLEN-44]; 
	char unused[44];
} ;

typedef struct userec USEREC;

/* these are flags in userec.flags[0] */
#define PAGER_FLAG      0x01    /* true if pager was OFF last session */
#define CLOAK_FLAG      0x02    /* true : cloak ON */
#if 0
# define VOTE_FLAG      0x04    /* for controlling Votes */
#endif
#define FORWARD_FLAG    0x04    /* true if auto-forward personal's mail */
#define SIG_FLAG        0x08    /* true if sig was turned OFF last session */
#if 0
# define OVERRIDES_FLAG 0x10
# define NOCLEAN_FLAG   0x10    /* true is user is immune from User Clean */
#define	CURSOR_FLAG     0x20 	/* the cursor menu flag, true if use cursor */
#endif
#define	YANK_FLAG       0x40    /* the board list yank flag, true if yank out */
#define	COLOR_FLAG      0x80    /* color mode or black/white mode, ture is b/w  */

#define PICTURE_FLAG	0x01    /* true if use motive picture mode */


struct user_info {	
	int active ;             /* When allocated this field is true */
	unsigned int uid ;       /* Used to find user name entry in passwd file */
	pid_t pid ;              /* kill() is used to notify user of talk request */
	int invisible ;          /* Used by cloaking function in Xyz menu */
	int sockactive ;         /* Used to coordinate talk requests */
	int sockaddr ;          
	unsigned int destuid;
	char destid[IDLEN+2];    /* talk parner user's id name */
	int mode ;               /* Talk Mode, Chat Mode, ... */
	int pager ;              /* pager toggle, YEA, or NA          */
	int in_chat ;            /* lasehu: unused */
	int sysuid ;             /* lasehu: unused */
	char userid[IDLEN+2];
	char username[UNAMELEN]; /* user nickname */
	char from[HOSTLEN] ;          /* machine name the user called in from */
	char chatid[16];         /* chat id, if in chat mode */
	time_t time;             /* lasehu: unused */
	char c_type;             /* connect type : CTYPE_CSBBS CTYPE_TSBBS */
} ;

typedef struct user_info USER_INFO;


/*
  Shaed Memory, For Online User Static File
*/
#define UTMPSHM_KEY     1219	/* shared memory key: should be unique */
#define USHM_SIZE       (MAXACTIVE + 4)

struct UTMPFILE 
{
    USER_INFO uinfo[USHM_SIZE];
    time_t uptime;           /* lasehu: unused */
    int number;
    int busystate;           /* lasehu: unused */
};


struct fileheader {	  
    char filename[STRLEN-4-4];
    int  artno;              /* lasehu: �G�i�s�� */
	char owner_ident;        /* Record if pass ident verify */
	char unused[3];          /* lasehu: unused */
	char owner[STRLEN] ;
	char title[STRLEN] ;
	unsigned int level;	     
	unsigned char accessed ;
} ;

typedef struct fileheader FILEHEADER;

#define FH_SIZE		(sizeof(struct fileheader))

/* the following used in fileheader accessed */
#define FILE_READ  0x01      /* �wŪ�L */
#define FILE_DELE  0x02      /* mark article as deleted */
#define FILE_TREA  0x04	     /* ��ذϥؿ� */
#define FILE_RESRV 0x08      /* �峹�O�d */
#define FILE_IN    0x10      /* �����ɮ� */
#define FILE_OUT   0x20      /* ���~�ɮ� */


#define BNAME_LEN	16
#define CBNAME_LEN	36


struct boardheader {
	char filename[BNAME_LEN+4];
	time_t	rewind_time;      /* lasehu: last refresh boardrc time */
	unsigned int bid;         /* board unique number, always increasing */
	char unused1[STRLEN-BNAME_LEN-15];
	char class;               /* �O������ */
	char type;                /* ��H���O  */
	unsigned char attrib;     /* �ݪO�ݩʺX�� */
	char owner[STRLEN];
	char title[CBNAME_LEN+4];	
	char unused2[STRLEN-CBNAME_LEN-4] ; 
	unsigned int level;	
	unsigned char accessed[10000]; /* -ToDo- remove this big array */
} ;

typedef struct boardheader BOARDHEADER;

#define BH_SIZE	(sizeof(struct boardheader))


/* -ToDo- the attrib of board */
#define IDENT_ATTRIB       0x01   /* �w�q�L�{�Ҥ~�i�i�K */
#if 0
#define UNZAP_ATTRIB       0x02   /* �L�k ZAP �� */
#define NONPOSTNUM_ATTRIB  0x04   /* ���p�i�K�� */
#define SECRET_ATTRIB      0x08   /* �K���O */
#define ANONYMOUS_ATTRIB   0x10   /* �ΦW�i�K */
#define VOTING_ATTRIB      0x20   /* ���b�벼 */
#endif

#define CTYPE_CSBBS 		0
#define CTYPE_TSBBS 		1


/*
   �W�u�H���O��
 */
struct visitor {
    char userid[IDLEN+2];
    time_t when;
    char from[HOSTLEN];
};


/* each keyword of personal files */
#define UFNAME_BOARDRC		"boardrc"
#define UFNAME_EDIT		"edit"
#define UFNAME_IRCRC		"ircrc"
#define UFNAME_MAIL		"mail"
#define UFNAME_OVERRIDES	"overrides"
#define UFNAME_PASSWDS		"passwds"
#define UFNAME_PLANS		"plans"
#define UFNAME_RECORDS		"records"
#define UFNAME_SIGNATURES	"signatures"
#define UFNAME_WRITE		"write"
#define UFNAME_ZAPRC		"zaprc"


/*******************************************************************
 * �ݪO�G�i�\Ū�O���O�����c
 * 	Total size = BRC_ITEMSIZE = 515 Bytes 
 *******************************************************************/

#if 0
struct readrc {
	short	bid;
    unsigned char rlist[BRC_MAXNUM]; 
    time_t	mtime;
	time_t  atime;
};
#endif

 
#define BRC_MAXSIZE   (20 * BRC_ITEMSIZE)
#define BRC_MAXNUM    (495)
#define BRC_STRLEN    BNAME_LEN

#define BRC_ITEMSIZE    \
  (BRC_STRLEN + BRC_MAXNUM * sizeof(unsigned char) + 1 * sizeof(time_t))
#define BRC_REALMAXNUM	(BRC_MAXNUM*8)


/* 
   other define
 */
#define NL	0x0a	        /* new line char */
#define SP	0x20            /* space cchar */
#define ESC	0x1b            /* Esc char */
#define TAB	0x09            /* TAB char */

#define YEA (1)        	        /* Booleans  (Yep, for true and false) */
#define NA  (0) 
#define YES 'Y'	                /* a char Yes or No */
#define NO  'N'

#define QUIT_LOOP 0x666         /* Return value to abort apply_xxxxx functions */

#define PATHLEN  128	        /* max # of characters in a path name */

#define STR_REPLY	"Re: "


#endif /* _BBS_STRUCT_H_ */
