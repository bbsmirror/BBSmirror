/*
 * NSYSU BBS ���� bbsmail program  v1.0
 *
 *  �� bbsmail �{�����U�C�\��G
 *
 *     1. ���� userid.bbs@bbs...... �� E-mail ����J BBS Users ���ӤH�H�c.
 *     2. ���� mail bbs@bbs...... < post.file �� E-mail To Post ��@���.
 *     3. ���� Board Manager �H E-mail To Post ���覡 Post ���ذ�.
 *
 *  �@���{���P�ɥ]�t�T���γ~. Header Lines Rule �аѾ\���s BBS Announce.
 *
 *  Coder: �����    lmj@cc.nsysu.edu.tw
 *                   wind.bbs@bbs.nsysu.edu.tw
 */

#undef DEBUG

#include "bbs.h"

#if	defined(NSYSUBBS) || defined(KHBBS)
#define BBSMAIL_SECURE
#endif

#undef LIMIT_MBOX_NUM		/* lasehu */
#define LIMIT_MAIL_SIZE		/* lasehu */


int     debug = 0;


char    genbuf[4096], treasure;
time_t  now;
struct boardheader bhead;


struct mail_info
{
	char    type;
	char    from[STRLEN];
	char    to[IDLEN + 2];
	char    subject[STRLEN];
	char    name[IDLEN + 2];
	char    passwd[PASSLEN];
	char    board[STRLEN];
	char    title[STRLEN];
};

struct mail_info minfo;
USEREC  user;


#define GET_NEXTONE	0
#define GET_NEXTALL	1
#define GET_HEADER	2
#define GET_PASSWD	3


char   *
mygets(buf, bsize, fp)
char   *buf;
int     bsize;
FILE   *fp;
{
	char   *p;

	if (fgets(buf, bsize, fp))
	{
		if ((p = strrchr(buf, '\n')) && p > buf && *(--p) == '\r')
		{
			*p++ = '\n';
			*p = '\0';
		}
		return buf;
	}
	else
		return NULL;
}




/* if type == 0 �u��X�U�@��
 *    type == 1 �ĤG���H�᪺����
 *    type == 2 ���o���Y�Ʀ�᪺���
 *    type == 3 ���o password
 */
int
next_arg(from, to, len, type)
char    from[], to[];
int     len, type;
{
	int     i = 0, j = 0;
	char    ccc;

	if (type == GET_NEXTONE)
		ccc = ' ';
	else
		ccc = ':';

	while (from[i] != ccc)
		if (from[i] == '\n' || from[i] == '\0')
			return -1;
		else
			i++;
	if (type != GET_NEXTONE)
		i++;
	while (from[i] == ' ')
		i++;
	i--;
	switch (type)
	{
		case GET_NEXTONE:
			while (from[++i] != SP && from[i] != '\0' && j < len - 1)
			{
				if (from[i] == ESC || from[i] == TAB || from[i] == NL)
					to[j++] = SP;
				else
					to[j++] = from[i];
			}
			break;
		case GET_NEXTALL:
			while (from[++i] != NL && from[i] != '\0' && j < len - 1)
			{
				if (from[i] == ESC || from[i] == TAB)
					to[j++] = SP;
				else
					to[j++] = from[i];
			}
			break;
		case GET_HEADER:
			while (from[++i] != NL && from[i] != SP && from[i] != '\0' && j < len - 1)
			{
				if (from[i] == ESC || from[i] == TAB)
					to[j++] = SP;
				else
					to[j++] = from[i];
			}
			break;
		case GET_PASSWD:
			while (from[++i] != NL && from[i] != '\0' && j < len - 1)
				to[j++] = from[i];
	}
	to[j] = '\0';
	return 0;
}


int
read_uudecode(w_file)
char    w_file[];
{
	char    r_file[STRLEN], rbuf[2048], *s;
	FILE   *rfs, *wfs;
	int     ok_num = 0;

	sprintf(r_file, "tmp/BMAIL.%d.UUDECODE", now);
	if (minfo.to[0] != '\0')
	{
		rename(r_file, w_file);
		return 0;
	}
	if ((rfs = fopen(r_file, "r")) == NULL || (wfs = fopen(w_file, "w")) == NULL)
	{
		fclose(rfs);
		fclose(wfs);
		return -1;
	}
	chmod(w_file, 0644);

	while (mygets(rbuf, sizeof(rbuf), rfs) != NULL)
	{
		if (ok_num >= 5)
		{
			fputs(rbuf, wfs);
			continue;
		}

		if (minfo.type == '\0' && (s = strstr(rbuf, "#type:")) != NULL)
		{
			ok_num++;
			if (strstr(s, "mail"))
				minfo.type = 'm';
			else
				minfo.type = 'p';
		}
		else if (minfo.name[0] == '\0' && (s = strstr(rbuf, "#name:")) != NULL)
		{
			ok_num++;
			next_arg(s, minfo.name, sizeof(minfo.name), GET_HEADER);
#ifdef DEBUG
			printf("\nname: [%s]", minfo.name);
#endif
		}
		else if (minfo.passwd[0] == '\0' && (s = strstr(rbuf, "#password:")) != NULL)
		{
			ok_num++;
			next_arg(s, minfo.passwd, sizeof(minfo.passwd), GET_PASSWD);
#ifdef DEBUG
			printf("\npasswordd: [%s]", minfo.passwd);
#endif
		}
		else if (minfo.board[0] == '\0' && (s = strstr(rbuf, "#board:")) != NULL)
		{
			ok_num++;
			next_arg(s, minfo.board, sizeof(minfo.board), GET_HEADER);
#ifdef DEBUG
			printf("\nboard: [%s]", minfo.board);
#endif
		}
		else if (minfo.title[0] == '\0' &&
			 ((s = strstr(rbuf, "#title:")) != NULL || (s = strstr(rbuf, "#subject:")) != NULL))
		{
			ok_num++;
			next_arg(s, minfo.title, sizeof(minfo.title), GET_NEXTALL);
#ifdef DEBUG
			printf("\ntitle: [%s]", minfo.title);
#endif
		}
		else
		{
			if (minfo.name[0] != '\0' && minfo.passwd[0] != '\0' &&
			    minfo.board[0] != '\0' && minfo.title[0] != '\0')
			{
				ok_num = 5;
			}
			fputs(rbuf, wfs);
		}
	}
	fclose(rfs);
	fclose(wfs);
	unlink(r_file);
	return 0;
}


int
increase_user_postnum(userid)
char    userid[];
{
	int     fd;
	USEREC  urc;

	sethomefile(genbuf, userid, UFNAME_PASSWDS);
	if ((fd = open(genbuf, O_RDWR)) > 0)
	{
		if (read(fd, &urc, sizeof(urc)) == sizeof(urc))
		{
			urc.numposts++;
			if (lseek(fd, 0, SEEK_SET) != -1)
			{
				if (write(fd, &urc, sizeof(urc)) == sizeof(urc))
				{
					close(fd);
					return 0;
				}
			}
		}
		close(fd);
	}
	return -1;
}


int
check_board()
{
	int     fd;
	char   *s, str[STRLEN];

	if (minfo.board[0] == '#')
	{
		s = &(minfo.board[1]);
		strcpy(str, s);
		strcpy(minfo.board, str);
		treasure = YES;
	}
	else
		treasure = NO;

	if ((fd = open(BOARDS, O_RDONLY)) < 0)
		return 0;
	while (read(fd, &bhead, sizeof(bhead)) == sizeof(bhead))
		if (!strcasecmp(bhead.filename, minfo.board))

/* del by lasehu
   && (user.numlogins >= bhead.level || user.numlogins >= 50))
 */
		{
			if (user.userlevel >= bhead.level &&
			    (!(bhead.attrib & IDENT_ATTRIB) || ((bhead.attrib & IDENT_ATTRIB) && user.ident == 7)))
			{
				close(fd);
				strcpy(minfo.board, bhead.filename);
				if (treasure == YES && strcmp(minfo.name, bhead.owner))
					return 0;
				else
					return 1;
			}
		}
	close(fd);
	return 0;
}


int
check_dir(path)
char    path[];
{
	struct stat st;

	if (stat(path, &st) == -1)
	{
		if (mkdir(path, 0700) == -1)
			return -1;
/* del by lasehu
   chown(path, BBS_UID, BBS_GID);
 */
	}
	else
	{
		if (!(st.st_mode & S_IFDIR))
			return -1;
	}
	return 0;
}


int
do_sign(r_file)
char    r_file[];
{
	FILE   *fr, *fw;
	int     i = 0;

	sethomefile(genbuf, minfo.name, "signatures");
	if ((fr = fopen(r_file, "r")) && (fw = fopen(genbuf, "w")))
	{
		chmod(genbuf, 0644);
/* del by lasehu
   chown(genbuf, BBS_UID, BBS_GID);
 */
/*      while (i < MAX_SIG_LINES && mygets(genbuf, 4096, fr)) */
		while (i < (MAX_SIG_LINES * MAX_SIG_NUM) && mygets(genbuf, 4096, fr))	/* lasehu */
		{
			if (*genbuf == '\n')
				continue;
			fprintf(fw, "%s", genbuf);
			i++;
		}
	}
	fclose(fr);
	fclose(fw);
	return;
}


int
do_plan(r_file)
char    r_file[];
{
	FILE   *fr, *fw;
	int     i = 0;

	sethomefile(genbuf, minfo.name, "plans");
	if ((fr = fopen(r_file, "r")) && (fw = fopen(genbuf, "w")))
	{
		chmod(genbuf, 0644);
/* del by lasehu
   chown(genbuf, BBS_UID, BBS_GID);
 */
		while (i < MAX_QUERY_LINES && mygets(genbuf, sizeof(genbuf), fr))
		{
			if (*genbuf == '\n')
				continue;
			fprintf(fw, "%s", genbuf);
			i++;
		}
	}
	fclose(fr);
	fclose(fw);
	return;
}


int
do_post(r_file)
char    r_file[];
{
	char    path[STRLEN], fname[STRLEN], dotdir[STRLEN];
	int     ccc;
	FILE   *fdr, *fdw;
	FILEHEADER fhead;

	memset(&fhead, 0, sizeof(fhead));

	if (treasure == NO)
		sprintf(path, "boards/%s", minfo.board);
	else
		sprintf(path, "treasure/%s", minfo.board);
	if (check_dir(path) == -1)
		return -1;	/* lasehu */
	get_only_name(path, fhead.filename);
	sprintf(fname, "%s/%s", path, fhead.filename);
	if ((fdw = fopen(fname, "w")) == NULL || (fdr = fopen(r_file, "r")) == NULL)
	{
		fclose(fdr);
		fclose(fdw);
		return -1;
	}

	if (minfo.title[0] != '\0')
		strcpy(fhead.title, minfo.title);
	else
		strcpy(fhead.title, minfo.subject);
	strcpy(fhead.owner, minfo.name);
/* del by lasehu
   fhead.level = 0;
 */
	fhead.owner_ident = user.ident;
	fprintf(fdw, "�o�H�H�G%s (%-20.20s)    �ݪO�G%s\n", fhead.owner, user.username, minfo.board);	/* lasehu */
	fprintf(fdw, "����G%s", ctime(&now));
	fprintf(fdw, "���D�G%s\n\n", fhead.title);
	while (mygets(genbuf, sizeof(genbuf), fdr))
		fprintf(fdw, "%s", genbuf);
	fclose(fdr);
	sethomefile(genbuf, minfo.name, "signatures");
	if ((fdr = fopen(genbuf, "r")) != NULL)
	{
		fprintf(fdw, "\n--\n");
		ccc = 0;
		while (ccc++ < MAX_SIG_LINES && mygets(genbuf, sizeof(genbuf), fdr))
			fprintf(fdw, "%s", genbuf);
		fclose(fdr);
	}
	fprintf(fdw, "[m\n");
	fclose(fdw);
	chmod(fname, 0644);
/* del by lasehu
   chown(fname, BBS_UID, BBS_GID);
 */
	if (treasure == NO)
		sprintf(dotdir, "boards/%s/%s", minfo.board, DIR_REC);
	else
		sprintf(dotdir, "treasure/%s/%s", minfo.board, DIR_REC);
	fhead.artno = get_only_artno(dotdir);	/* lasehu */
	if (fhead.artno == 1)	/* lasehu */
		rewind_board(minfo.board);
	if (append_record(dotdir, &fhead, sizeof(fhead)) == -1)
	{
		unlink(fname);
		return -1;
	}
	increase_user_postnum(minfo.name);
	if (treasure == NO)
	{
		if (bhead.type == 'B' || bhead.type == 'O')
		{
#ifdef EMAIL_LIMIT
			if (user.ident == 7)
#endif
				append_news(bhead.filename, fhead.filename, 'S');	/* lasehu */
		}
	}
	return 0;
}


int
do_mail(r_file)
char    r_file[];
{
	char    path[STRLEN], fname[STRLEN], dotdir[STRLEN];
	FILE   *fdr, *fdw;
	struct stat st;
	FILEHEADER fhead;

#ifdef LIMIT_MBOX_NUM
	int     total;

#endif

	memset(&fhead, 0, sizeof(fhead));

	setmailfile(path, minfo.name, NULL);
	if (check_dir(path) == -1)
		return -1;	/* lasehu */
#ifdef DEBUG
	printf("\nr_file: [%s]", r_file);
#endif

/* lasehu */
#ifdef LIMIT_MBOX_NUM
	setmailfile(dotdir, minfo.name, DIR_REC);
	if ((total = get_num_records(dotdir, FH_SIZE)) >= MAX_KEEP_MAIL)
	{
		if (debug)
			printf("\nMailBoxFull: [%s]", minfo.name);
		bbslog("bbsmail", "<%s> Mailbox full, total [%d]", minfo.name, total);
		return -1;
	}
#endif
#ifdef LIMIT_MAIL_SIZE
	if (stat(r_file, &st) == 0 && st.st_size > MAX_MAIL_SIZE)
	{
		if (debug)
			printf("\nMailSizeTooBig: [%s] SIZE: [%d]", minfo.name, st.st_size);
		bbslog("bbsmail", "Mail size [%d] too big, Mail from [%s] to [%s]", st.st_size, minfo.from, minfo.name);
/*-- lasehu
	return -1;
*/
	}
#endif

	get_only_name(path, fhead.filename);
	sprintf(fname, "%s/%s", path, fhead.filename);
	if ((fdw = fopen(fname, "w")) == NULL || (fdr = fopen(r_file, "r")) == NULL)
	{
		fclose(fdr);
		fclose(fdw);
		return -1;
	}
	if (minfo.title[0] != '\0')
		strcpy(fhead.title, minfo.title);
	else
		strcpy(fhead.title, minfo.subject);
	strcat(fhead.owner, "#");
	strncat(fhead.owner, minfo.from, sizeof(fhead.owner) - 2);
	fhead.level = 0;
	fprintf(fdw, "�o�H�H�G%s\n", minfo.from);
	fprintf(fdw, "����G%s", ctime(&now));
	fprintf(fdw, "���D�G%s\n\n", fhead.title);
	while (mygets(genbuf, sizeof(genbuf), fdr))
		fprintf(fdw, "%s", genbuf);
	fprintf(fdw, "[m\n");
	fclose(fdr);
	fclose(fdw);
	chmod(fname, 0644);
/* del by lasehu
   chown(fname, BBS_UID, BBS_GID);
 */
	setmailfile(dotdir, minfo.name, DIR_REC);
	if (append_record(dotdir, &fhead, sizeof(fhead)) == -1)
	{
		unlink(fname);
		return -1;
	}
	return 0;
}

int
access_mail(r_file)
char    r_file[];
{
	if (minfo.to[0] != '\0')
		strcpy(minfo.name, minfo.to);
	if (get_passwd(&user, minfo.name) <= 0)
		return -1;

	if (debug)
	{
		printf("\nMtype: [%c] Mfrom: %s Mto: %s", minfo.type, minfo.from, minfo.to);
		printf("\nMsubject: %s", minfo.subject);
		printf("\nMname: %s, Mboard: %s Mpasswd: %s", minfo.name, minfo.board, minfo.passwd);
		printf("\nMtitle: %s", minfo.title);
	}
	if (minfo.type == 's' && checkpasswd(user.passwd, minfo.passwd))
		do_sign(r_file);
	else if (minfo.type == 'l' && checkpasswd(user.passwd, minfo.passwd))
		do_plan(r_file);
	else if (minfo.type != 'm' && minfo.passwd[0] != '\0' &&
		 minfo.name[0] != '\0' && minfo.board[0] != '\0' &&
		 checkpasswd(user.passwd, minfo.passwd) &&
		 check_board())
	{
		do_post(r_file);
	}
	else
		do_mail(r_file);
	unlink(r_file);
	return 0;
}


void
init()
{
	bzero(&minfo, sizeof(minfo));
	bzero(&user, sizeof(user));
}


int
readin_mail(filename)
char   *filename;
{
	int     i, ok_num = 0;
	char    rbuf[1024], w_file[STRLEN], *s, do_uudecode;
	char    uudecode, begin;
	FILE   *fd;
	FILE   *fs_sys;

	init();
	begin = do_uudecode = NO;
	uudecode = YES;
	i = 0;

	if ((fs_sys = fopen(filename, "r")) == NULL)
		exit(-1);
	if (mygets(rbuf, sizeof(rbuf), fs_sys) == NULL)
	{
		fclose(fs_sys);
		return -1;
	}
	sprintf(w_file, "tmp/BMAIL_ORI.%d.%d", now, i++);
	if ((fd = fopen(w_file, "w")) == NULL)
	{
		fclose(fs_sys);
		return -1;
	}
	chmod(w_file, 0600);

	if (!strncmp(rbuf, "From ", 5))
		next_arg(rbuf, minfo.from, sizeof(minfo.from), GET_NEXTONE);
#ifdef DEBUG
	printf("\nfrom: [%s]", minfo.from);
#endif
	while (mygets(rbuf, sizeof(rbuf), fs_sys) != NULL)
	{
		if (!strncmp(rbuf, "From ", 5))
		{
			fclose(fd);
			if (do_uudecode == YES)
			{
				sprintf(genbuf, "bin/uudecode %s", w_file);
				system(genbuf);
				unlink(w_file);
				read_uudecode(w_file);
			}
			access_mail(w_file);
			init();
			begin = NO;
			uudecode = YES;
			do_uudecode = NO;
			ok_num = 0;
			sprintf(w_file, "tmp/BMAIL_ORI.%d.%d", now, i++);
			if ((fd = fopen(w_file, "w")) == NULL)
			{
				fclose(fs_sys);
				return;
			}
			chmod(w_file, 0600);
			next_arg(rbuf, minfo.from, sizeof(minfo.from), GET_NEXTONE);
#ifdef DEBUG
			printf("\nfrom: [%s]", minfo.from);
#endif
			continue;
		}
		else if (do_uudecode == YES || ok_num == 5)
		{
			fprintf(fd, "%s", rbuf);
			continue;
		}
		else if (rbuf[0] == NL && begin == NO)
		{
			begin = YES;
#ifdef DEBUG
			printf("\nHeader to: [%s]", minfo.to);
			printf("\nHeader subject: [%s]", minfo.subject);
#endif
			if (minfo.to[0] == '\0')	/* lasehu */
				bbslog("bbsmail", "Header 'To: ' not found, from [%s]", minfo.from);
			continue;
		}

		if (begin == NO)
		{
			if ((!strncmp(rbuf, "To: ", 4) || !strncmp(rbuf, "Apparently-To: ", 15)) && (s = strstr(rbuf, ".bbs@")) != NULL)
			{
				*(s--) = '\0';
				while ((*s != 32))
					s--;
				s++;
				if (*s == '<')	/* lasehu */
					s++;
				strncpy(minfo.to, s, sizeof(minfo.to));
			}
			else if (!strncmp(rbuf, "Subject: ", 9))
				next_arg(rbuf, minfo.subject, sizeof(minfo.subject), GET_NEXTALL);
			continue;
		}
		else if (uudecode == YES && !strncmp(rbuf, "begin ", 6))
		{
			do_uudecode = YES;
			uudecode = NO;
/* del by lasehu
   sprintf(rbuf, "begin 0600 %s/tmp/BMAIL.%d.UUDECODE\n", HOMEBBS, now);
 */
			sprintf(rbuf, "begin 0600 tmp/BMAIL.%d.UUDECODE\n", now);
			fprintf(fd, "%s", rbuf);
			continue;
		}
		else if (minfo.to[0] != '\0')
		{
			if (uudecode == YES && strlen(rbuf) > 2)
				uudecode = NO;
			fprintf(fd, "%s", rbuf);
			minfo.type = 'm';
			continue;
		}
		else if (minfo.type == '\0' && (s = strstr(rbuf, "#type:")) != NULL)
		{
			uudecode = NO;
			ok_num++;
			if (strstr(s, "mail"))
				minfo.type = 'm';
			else if (strstr(s, "sign"))
				minfo.type = 's';
			else if (strstr(s, "plan"))
				minfo.type = 'l';
			else
				minfo.type = 'p';
			continue;
		}
		else if (minfo.name[0] == '\0' && (s = strstr(rbuf, "#name:")) != NULL)
		{
			uudecode = NO;
			ok_num++;
			next_arg(s, minfo.name, sizeof(minfo.name), GET_HEADER);
			continue;
		}
		else if (minfo.passwd[0] == '\0' && (s = strstr(rbuf, "#password:")) != NULL)
		{
			uudecode = NO;
			ok_num++;
			next_arg(s, minfo.passwd, sizeof(minfo.passwd), GET_PASSWD);
			continue;
		}
		else if (minfo.board[0] == '\0' && (s = strstr(rbuf, "#board:")) != NULL)
		{
			uudecode = NO;
			ok_num++;
			next_arg(s, minfo.board, sizeof(minfo.board), GET_HEADER);
			continue;
		}
		else if (minfo.title[0] == '\0' && (s = strstr(rbuf, "#title:")) != NULL)
		{
			uudecode = NO;
			ok_num++;
			next_arg(s, minfo.title, sizeof(minfo.title), GET_NEXTALL);
			continue;
		}
		if (minfo.name[0] != '\0' && minfo.passwd[0] != '\0' && minfo.board[0] != '\0' && minfo.title[0] != '\0')
			ok_num = 5;
		fprintf(fd, "%s", rbuf);
	}
	fclose(fd);
	if (do_uudecode == YES)
	{
		sprintf(genbuf, "bin/uudecode %s", w_file);
		system(genbuf);
		unlink(w_file);
		read_uudecode(w_file);
	}
#ifdef DEBUG
	printf("\nw_file: [%s]", w_file);
#endif
	access_mail(w_file);
	fclose(fs_sys);
	return 0;
}


void
main(argc, argv)
int     argc;
char   *argv[];
{
	char    spool_tmp[STRLEN], bbsmail_box[PATHLEN];

	sprintf(bbsmail_box, "%s/bbsmail", SPOOL_MAIL);
#ifdef BBSMAIL_SECURE
	if (getuid() != 0)
	{
		printf("\n\n!!! �Х� root �Ӱ��楻�{�� !!!\n");
		exit(0);
	}
#else
	if (getuid() != BBS_UID)
	{
		if (setgid(BBS_GID) == -1 || setuid(BBS_UID) == -1)
		{
			printf("\n\n!!! �Х� bbs �Ӱ��楻�{�� !!!\n");
			exit(0);
		}
	}
#endif

	if (argc == 2)
	{
		if (!strcmp(argv[1], "debug"))
			debug = 1;
	}

	if (!dashf(bbsmail_box))	/* lasehu */
		exit(0);

	if (chdir(HOMEBBS) == -1)
		exit(2);
	now = time(0);
	sprintf(spool_tmp, "tmp/bbsmail_box.%-d", now);
	if (myrename(bbsmail_box, spool_tmp) == -1)
	{
		printf("\nCannot rename [%s] to [%s]\n", bbsmail_box, spool_tmp);
		exit(1);
	}
#ifdef BBSMAIL_SECURE
	if (chroot(HOMEBBS) == -1 || chdir("/") == -1)
		exit(-1);
	chown(spool_tmp, BBS_UID, BBS_GID);
	setgid(BBS_GID);
	setuid(BBS_UID);
#endif
	readin_mail(spool_tmp);
	unlink(spool_tmp);
}
