/*
 * ���{���ΨӼ��� pop3 server
 *									-- lmj@cc.nsysu.edu.tw
 */

/*
 * �t�A�ɰ�
 */
#include <sys/param.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/file.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <netdb.h>
#include <syslog.h>
#include <pwd.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
/*
#if	defined(AIX) 
# include <sys/select.h>
#else
# include <sys/pathname.h>
#endif
*/

#include "config.h"
#include "struct.h"

/*
 * �Ѧ��ɸ��|�w�q
 */
#define PID_FILE "/tmp/pop3.pid"
#define PATH_DEVNULL "/dev/null"
#define POP3_TIMEOUT 600
#define CHROOT_BBS

#define POP_HOME 0
#define POP_MAIL 1
#define TRUE 1
#define FALSE 0

char pbuf[512];
struct stat st;
struct userec Popuser;
struct userec *popuser;
char maildirect[STRLEN];
char ever_del_mail=FALSE;



/*
 * �~����ƫŧi
 */
extern int errno;


/*------------------------------------------------------------------------
 * reaper - clean up zombie children
 *------------------------------------------------------------------------
 */
static void
reaper()
{
#if	defined(SOLARIS) || defined(AIX) || defined(LINUX)
    int status;
#else
    union wait  status;
#endif  /* SOLARIS */

    while (wait3(&status, WNOHANG, (struct rusage *)0) > 0)
        /* empty */;
	(void) signal(SIGCHLD, reaper);
}





/************************************************************************
 * Pop Lib Function
 ************************************************************************/

void SendArticle(filename)
char *filename;
{
	FILE *fp;
	char buffer[100];

	if ((fp = fopen(filename, "r")) == NULL)
    {
		printf("-ERR open mail error\r\n");
        return;
    }

	while (fgets(buffer, 100, fp) != NULL)
		printf("%s", buffer);

}

void PopSetPath(buf, type, name, sub)
char *buf, type, *name, *sub;
{
	char c;

	if(*name >= 'A' && *name <= 'Z')
		c = *name + 0x20;
	else if(*name >= '0' && *name <= '9')
		c = '0';
	else
		c = *name;
	if(sub)
		sprintf(buf, "%s/%c/%s/%s", (type == POP_HOME) ? "home" : "mail",
				c, name, sub);
	else
		sprintf(buf, "%s/%c/%s", (type == POP_HOME) ? "home" : "mail",
				c, name);
}


int PopHaveUser(name)
char *name;
{
	int state;

	PopSetPath(pbuf, POP_HOME, name, "passwds");
	state = stat(pbuf, &st);
	if (state == 0)
		return TRUE;
	else
		return FALSE;
}


int PopGetUser(name)
char *name;
{
	int fd;

	PopSetPath(pbuf, POP_HOME, name, "passwds");
	if ((fd = open(pbuf, O_RDONLY)) > 0)
    {
        if (read(fd, &Popuser, sizeof(Popuser)) == sizeof(Popuser))
            if (Popuser.uid >= 1)
            {
				popuser = &Popuser;
                close(fd);
                return TRUE;
            }
        close(fd);
    }
	return FALSE;
}

void PopSTAT(void)
{
    struct stat st;
    int num, fd, size=0, i;
    struct fileheader fh;
    char filename[STRLEN], *p;

    /* Get mail number */
    num = (stat(maildirect, &st)<0) ? 0 : (st.st_size/sizeof(fh));

    if (num == 0)
        {
        printf("+OK 0 0\r\n");
        return;
        }

    strcpy(filename, maildirect);
    p = strrchr(filename, '.');

    if((fd = open(maildirect, O_RDWR)) < 0) 
	{
		printf("-ERR Can't get mail number.\r\n");
        return;
    }

    for (i = 0; i < num; i++)
    {
        if(read(fd, &fh, sizeof(fh))!=sizeof(fh))
        {
            close(fd);
			printf("-ERR Can't get mail number.\r\n");
            return;
        }

        strcpy(p, fh.filename);
        if (stat(filename, &st)<0)
        {
			printf("-ERR Can't get mail number.\r\n");
            return;
        }
        else
            size += (st.st_size);
    }


    printf("+OK %d %d\r\n", num, size);
}

void PopLIST(list_num)
int list_num;
{
    struct stat st;
    int List_all;
    int num, fd, i;
    char filename[STRLEN], *p, tmp[5];
    struct fileheader fh;

    if(list_num == 0)
        List_all = TRUE;
    else
        List_all = FALSE;

    /* Get mail number */
    num = (stat(maildirect, &st)<0) ? 0 : (st.st_size/sizeof(fh));

    if (list_num > num)
    {
        printf("-ERR no such message\r\n");
        return;
    }

    strcpy(filename, maildirect);
    p = strrchr(filename, '.');

    if((fd = open(maildirect, O_RDWR)) < 0)
    {
		printf("-ERR open mailbox ERROR\r\n");
        return;
    }

    if (List_all)
    {
        printf("+OK sending messages\r\n");
        for (i = 0; i < num; i++)
        {
            if(read(fd, &fh, sizeof(fh))!=sizeof(fh))
            {
                close(fd);
				printf("-ERR read mailbox ERROR\r\n");
                return;
            }
            if (fh.filename[0] != 'D')
            {
                strcpy(p, fh.filename);
                if (stat(filename, &st)<0)
                {
					printf("-ERR read mail file ERROR\r\n");
                    return;
                }
                else
                    printf("%d %d\r\n", i+1, st.st_size);
            }
        }
        printf(".\r\n");
    }
    else
    {
        if(lseek(fd, (long)sizeof(fh)*(list_num-1),SEEK_SET) == -1)
        {
            close(fd);
			printf("-ERR no such message\r\n");
            return;
        }
        if(read(fd, &fh, sizeof(fh))!=sizeof(fh))
        {
            close(fd);
			printf("-ERR read mail ERROR\r\n");
            return;
        }
        if (fh.filename[0] == 'D')
            printf("-ERR mail %d has been marked for deletion\r\n", list_num);
        else
        {
            strcpy(p, fh.filename);
            if (stat(filename, &st) < 0)
            {
				printf("-ERR read file ERROR\r\n");
                return;
            }
            else
                printf("+OK %d %d\r\n", list_num, st.st_size);
        }
    }
    close(fd);
}

void PopRETR(idx)
int idx;
{
    struct stat st;
    int num;
    char tmp[10];
    int fd;
    char genbuf[256];
    char *p;
    struct fileheader fh2;


    if(idx<1) 
	{
		printf("-ERR remember to input idx\r\n");
        return;
    }

    if(stat(maildirect, &st)<0)           /* get mail count */
        num=0;
    else
        num=(st.st_size / sizeof(struct fileheader));

    if(idx>num) 
	{
		printf("-ERR no such message\r\n");
        return;
    }

    if((fd = open(maildirect, O_RDWR)) < 0) 
	{
		printf("-ERR open mail index file error\r\n");
        return;
    }

    if(lseek(fd, (long)(sizeof(fh2) * (idx-1)), SEEK_SET) == -1) 
	{
		printf("-ERR seek mail error\r\n");
        close(fd);
        return;
    }

    if(read(fd, &fh2, sizeof(fh2))!=sizeof(fh2)) 
	{
        close(fd);
		printf("-ERR read mail error\r\n");
        return;
    }

    if(fh2.filename[0]=='D') 
	{
        close(fd);
		printf("-ERR mail not exist\r\n");
        return;
    }

    if(lseek(fd, (long)(sizeof(fh2) * (idx-1)), SEEK_SET) == -1) 
	{
		printf("-ERR seek mail error\r\n");
        close(fd);
        return;
    }

    fh2.accessed = 1;
    write(fd,&fh2,sizeof(fh2));
    close(fd);

    strcpy(genbuf, maildirect);
    p = (char *)rindex(genbuf,'/') + 1;
    strcpy(p, fh2.filename);

	printf("+OK message follows\r\n");
    SendArticle(genbuf);
	printf(".\r\n");
}

void PopDELE(idx)
int idx;
{
    struct stat st;
    int num;
    char tmp[10];
    int fd;
    char *p;
    struct fileheader fileinfo;


    if(idx<1) 
	{
		printf("-ERR syntax error\r\n");
        return;
    }
    if(stat(maildirect, &st)<0)           /* get mail count */
        num=0;
    else
        num=(st.st_size / sizeof(struct fileheader));

    if(idx>num) 
	{
		printf("-ERR mail not exist\r\n");
        return;
    }

    if((fd = open(maildirect, O_RDWR)) < 0) 
	{
		printf("-ERR open mail index error\r\n");
        return;
    }

    if(lseek(fd, (long)(sizeof(struct fileheader) * (idx-1)), SEEK_SET) == -1) 
	{
		printf("-ERR seek mail error\r\n");
        close(fd);
        return;
    }

    if(read(fd, &fileinfo, sizeof(fileinfo))!=sizeof(fileinfo)) 
	{
        close(fd);
		printf("-ERR read mail error\r\n");
        return;
    }

    if(fileinfo.filename[0]=='D') 
	{
		printf("+OK message deleted\r\n");
        return;
    }


	fileinfo.filename[0] = 'D';
	if (lseek(fd, -((long)sizeof(fileinfo)), SEEK_CUR) == -1)
	{
		printf("-ERR seek mail header error\r\n");
		close(fd);
		return;
	}
	write(fd, &fileinfo, sizeof(struct fileheader));
	close(fd);
	ever_del_mail = TRUE;
	printf("+OK message deleted\r\n");
	
}


/*
 * Parse Input String to Command
 */

char popname[IDLEN+2];

int ParseCommand(inbuf)
char *inbuf;
{
	char *p = inbuf;
	int i;

	if(*inbuf == '\0' || *inbuf == '\r' || *inbuf == '\n')
		return -1;
	if(popuser)
	{
		switch(*p)
		{
			case 'R':	/* RETR , RSET */
			case 'r':
				p++;
				if(*p == 'E' || *p == 'e')	/* RETR */
				{
					p += 4;
					PopRETR(atoi(p));
					return 1;
				}
				else if(*p == 'S' || *p == 's')	/* RSET */
				{
					/* PopRSET(); */
					return 1;
				}
				else
					return 0;
			case 'L':	/* LIST */
			case 'l':
				if(strlen(p) < 7)
					PopLIST(0);
				else
					PopLIST(atoi(p+5));
				return 1;
			case 'U':	/* UIDL */
			case 'u':
				p++;
				if(*p == 'I' || *p == 'i')
				{
					if(strlen(p) < 7)
						NULL;
						/* PopUIDL(0); */
					else
						/* PopUIDL(atoi(p+4)); */
					return 1;
				}
				return 0;
			case 'S':	/* STAT */
			case 's':
				PopSTAT();
				return 1;
			case 'D':
			case 'd':
				if(strncmp(p, "DELE ", 5) && strncmp(p, "dele ", 5))
					return 0;
				if(strlen(p) < 7)
				{
					printf("-ERR give me message number\r\n");
					return 1;
				}
				PopDELE(atoi(p+5));
				return 1;
			case 'N':
			case 'n':
				printf("+OK hello, I am alive\r\n");
				return 1;
			case 'Q':
			case 'q':
				printf("+OK sayonala\r\n");
				shutdown(0, 2);
				/* PopPurge(); */
				exit(0);
			default:
				return 0;
		}
	}
	else
	{
		if(*popname)
		{
			if(strncmp(p, "PASS ", 5) && strncmp(p, "pass ", 5))
			{
				printf("-ERR send PASS first\r\n");
				return 1;
			}
			p += 5;
			for(i = 0; i < sizeof(inbuf) - 5; i++)
			{
				if(p[i] == '\r' || p[i] == '\n')
				{
					p[i] = '\0';
					if(PopGetUser(popname))
					{
						if(checkpasswd(popuser->passwd, p))
						{
							printf("+OK %s login successful\r\n", popname);
							PopSetPath(maildirect, POP_MAIL, popuser->userid, NULL);
							strcat(maildirect, "/.DIR");
							return 1;
						}
						else
						{
							printf("-ERR %s passwd incorrect\r\n", popname);
							popuser = NULL;
							return 1;
						}
					}
					printf("-ERR %s no such user\r\n", popname);
					memset(popname, 0, sizeof(popname));
					return 1;
				}
			}
			printf("-ERR passwd is too long\r\n");
			return 1;
		}
		else
		{
			if(strncmp(p, "USER ", 5) && strncmp(p, "user ", 5))
			{
				printf("-ERR send USER first\r\n");
				return 1;
			}
			p += 5;
			for(i = 0; i < sizeof(popname); i++)
			{
				if(p[i] == '\r' || p[i] == '\n')
				{
					p[i] = '\0';
					strcpy(popname, p);
					if(PopHaveUser(popname))
						printf("+OK %s welcome, send PASS now\r\n", popname);
					else
					{
						printf("-ERR %s no such user\r\n", popname);
						memset(popname, 0, sizeof(popname));
					}
					return 1;
				}
			}
		}
		printf("-ERR your user name is incorrect\r\n");
		return 1;
	}
}



/*
 * Idle Timeout
 */
int times;
char pop3_idle;

void timeout_check()
{
	if(pop3_idle)
	{
		shutdown(0, 2);
		exit(0);
	}
	pop3_idle = 1;
	signal(SIGALRM, timeout_check);
	alarm(POP3_TIMEOUT);
}


/*
 * POP3 Main Function
 */
void Pop3()
{
	char inbuf[256];

#if defined(CHROOT_BBS)
	if(chroot(HOMEBBS) || chdir("/"))
		return;
#endif
	signal(SIGALRM, timeout_check);
	alarm(POP3_TIMEOUT);
	times = 0;
	pop3_idle = 0;
	memset(popname, 0, sizeof(popname));
	popuser = (struct userec *) NULL;
	printf("+OK NSYSU BBS POP3 Server Ready, Send USER and PASS\r\n");
	fflush(stdout);
	while(times < (int) IMPOSSIBLE_NUMBER)
	{
		if(gets(inbuf))
		{
			if ((strncmp(inbuf, "quit", 4)==0)||(strncmp(inbuf, "QUIT", 4)==0))
				return;
			switch(ParseCommand(inbuf))
			{
				case 1:	/* Normal Command */
					times = 0;
					pop3_idle = 0;
					break;
				case 0: /* No Such Command */
					times = 0;
					pop3_idle = 0;
					printf("-ERR %-4s no such command\r\n", inbuf);
					break;
				default: /* Error */
					printf("-ERR no command\r\n");
					times++;
					break;
			}
		}
		else
			times++;
		fflush(stdout);
	}
}
	
	


/*
 * Main
 *
 */

void main(argc, argv)
int argc;
char *argv[];
{
	int aha, on = 1, maxs;
	fd_set ibits;
    struct sockaddr_in from, sin;
    int s, ns;
    char debug = 0;
    struct timeval wait;

    if(argc == 2 && !strcmp(argv[1], "debug"))
		debug++;

	if(fork() != 0)
		exit(0);

	if(debug)
		for(aha = 64; aha > 2; aha--)
			close(aha);
	else
	{
		for(aha = 64; aha >= 0; aha--)
			close(aha);
		if((aha = open(PATH_DEVNULL, O_RDONLY)) < 0)
			{
			printf("Open %s fail\r\n", PATH_DEVNULL);
			exit(1);
			}
		if(aha) 
		{
			dup2(aha, 0);
			close(aha);
		}
		dup2(0, 1);
		dup2(0, 2);
	}

    signal(SIGHUP, SIG_IGN);
    signal(SIGCHLD,reaper);

    if((s = socket(AF_INET, SOCK_STREAM, 0)) < 0)
        exit(1);

    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on));
#if defined(IP_OPTIONS) && defined(IPPROTO_IP)
    setsockopt(s, IPPROTO_IP, IP_OPTIONS, (char *)NULL, 0);
#endif

    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = INADDR_ANY;
    sin.sin_port = htons((u_short) 110);

    if (bind(s, (struct sockaddr *)&sin, sizeof sin) < 0 ||
#if	defined(SOLARIS) || defined(AIX)
        listen(s, 256) < 0)
#else
        listen(s, 5) < 0)
#endif
        exit(1);

	if(debug)
		printf("PID [%d] BIND socket [%d] OK!\n", getpid(), s);
	else
	{
		FILE *fp;

		unlink(PID_FILE);
		if(fp = fopen(PID_FILE, "w"))
		{
			fprintf(fp, "%-d", getpid());
			fclose(fp);
			chmod(PID_FILE, 0644);
		}
	}

    aha = sizeof(from);
    maxs = s + 1;
    wait.tv_sec = 5;
    wait.tv_usec = 0;

    while(1) 
	{
        FD_ZERO(&ibits);
        FD_SET(s, &ibits);
        if ((on = select(maxs, &ibits, 0, 0, &wait)) < 1) 
		{
            if((on < 0 && errno == EINTR) || on == 0)
                continue;
            else 
			{
				sleep(5);
				continue;
            }
        }
        if(!FD_ISSET(s, &ibits))
            continue;
        if((ns = accept(s, (struct sockaddr *)&from, &aha)) < 0)
            continue;
        else 
		{
            switch(fork()) 
			{
                case -1:
                    close(ns);
                    break;

                case 0:
                {
                    char *host, *inet_ntoa();
#ifdef	RESOLVE_HOSTNAME
                    struct hostent *hp;
#endif

                    signal(SIGCHLD,SIG_IGN);
                    close(s);
                    dup2(ns, 0);
                    close(ns);
                    dup2(0, 1);
                    dup2(0, 2);
                    on = 1;
                    setsockopt(0, SOL_SOCKET, SO_KEEPALIVE,
                                (char *) &on, sizeof (on));
#ifdef	RESOLVE_HOSTNAME
                    if((hp = gethostbyaddr((char *) &(from.sin_addr),
                                        sizeof (struct in_addr),
                                        from.sin_family)))
                        host = hp->h_name;
                    else
#endif
                        host = inet_ntoa(from.sin_addr);

                    if(debug)
						printf("Connect From: [%s]\n", host);

					Pop3();

                    shutdown(0, 2);
					exit(0);
                }
                default:
                    close(ns);
            }
        }
    }
}

