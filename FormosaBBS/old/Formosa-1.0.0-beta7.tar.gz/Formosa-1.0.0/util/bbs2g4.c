/*******************************************************************
 *  BBS Gopher Server
 *					changiz@cc.nsysu.edu.tw
 *					Cauchy@cc.nsysu.edu.tw
 *******************************************************************/

#include "bbs.h"

#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>

#include <sys/wait.h>
#include <sys/time.h>
#include <sys/resource.h>


#define PATH_DEVNULL 	"/dev/null"
/*
   #define USERNUM      "bbs2g4/G4USER"
 */
#define BBS2G4_PID 	"/tmp/BBS2G4.pid"

#if 0
#define PATH_DEBUG	"bbs2g4/DEBUG"
#endif

char    host[] = MYHOSTIP;	/* lmj */

#define TRUE	1
#define FALSE	0


/*******************************************************************
 * �����ܼƫŧi��  DATA
 *******************************************************************/
char    debug = 1;

int     sock, s, port, idlesec;
char    genbuf[4096];

/*
   int    totaluser = 0;
   int    ppid;
 */
int     Plus = FALSE;
int     Check_file = FALSE;

#if 0
FILE   *efp;
#endif

/*
void rpt_err(msg)
char *msg;
{
	FILE *fp;
return;
	if((fp = fopen(PATH_DEBUG, "a")))
	{
		fprintf(fp, "%s\n", msg);
		fclose(fp);
	}
}
*/
/*******************************************************************
 * �T�����u
 *******************************************************************/
void
autoexit()
{
	int     i;

/*   kill(ppid,SIGCLD); */
	for (i = getdtablesize(); i > 2; i--)
		close(i);
	exit(0);
}

#ifdef 0
int
net_puts(sd, buf)
char    buf[];
int     sd;
{
	(void) signal(SIGALRM, autoexit);
	alarm(idlesec);
	write(sd, buf, strlen(buf));
	alarm(0);
	return 0;
}


char   *
net_gets(sd, buf)		/* --Cauchy */
char    buf[];
int     sd;
{
	char   *p, *end;

/*
   FILE *fd;
 */
	(void) signal(SIGALRM, autoexit);
	alarm(idlesec);

	end = buf + sizeof(genbuf) - 1;
	p = buf;
	Plus = FALSE;
/*  fd = fopen("./Gopher.read", "w+"); */
	while (p < end && read(sd, p, 1) == 1)
	{
	/* fprintf(fd,"%c", *p); */
		if (*p == '\r')
			continue;
		else if (*p == '\t')
			continue;
		else if (*p == '$')
		{
			Plus = TRUE;
			continue;
		}
		else if (*p == '!')
		{
			Check_file = TRUE;
			continue;
		}
		else if (*p == '+')
		{
			Plus = TRUE;
			*p = '\0';
			break;
		}
		else if (*p == '\n')
		{
			*(++p) = '\0';
			break;
		}
		else if (*p == '\0')
			break;
		p++;
	}
/*  fclose(fd); */
	alarm(0);
	return ((p > buf) ? buf : (char *) NULL);
}

#endif				/* 0 lmj */

#define CHROOT 1
#define NFILE 2


void
Print_Error(mode)
int     mode;
{
	switch (mode)
	{
		case CHROOT:
			net_printf(1, "Chroot failure..");
			break;
		case NFILE:
			net_printf(1, "Path error..");
			break;
	}
	net_printf(1, "	error.host	1\n.\n");
}


int
file(name)
char    name[];
{
	FILE   *fp;
	char    buf[160];

	if (Check_file)
	{
		net_printf(1, "+-1\r\n");
		net_printf(1, "+INFO: title\t%s\t%s\t70\t+\r\n", name, host);
		net_printf(1, "+VIEWS:\r\n");
		net_printf(1, " Text/plain: <10k>\r\n");
		net_printf(1, ".\r\n");
		return;
	}

	if ((fp = fopen(name, "r")) == NULL)
	{
		Print_Error(NFILE);
		return -1;
	}
	if (Plus)
		net_printf(1, "+-1\r\n");

	while (fgets(buf, sizeof(buf), fp))
		net_printf(1, "%s", buf);

	fclose(fp);
	net_printf(1, ".\n");
}


/*
   void
   save_option(buffer)
   char buffer[];
   {
   FILE *fd;
   int len, i;

   fd = fopen("./Gopher.dat", "w+");
   len = strlen(buffer);
   fprintf(fd, "Recived: ");
   for (i = 0; i < len; i++)
   fprintf(fd, "%x ", buffer[i]);
   fprintf(fd, "\r\n         ");
   for (i = 0; i < len; i++)
   fprintf(fd, "%c", buffer[i]);
   fprintf(fd, "\r\n");
   fclose(fd);
   }
 */


int
dir(path)
char    path[];
{
	struct boardheader bh;
	struct fileheader fh;
	char    buf[240];
	int     f;

	if (!strcmp(path, "/"))	/* �̤W�h */
	{
		if (Plus)
		{
			net_printf(1, "+-1\r\n");
			net_printf(1, "+INFO: ");
		}
		net_printf(1, "1��BBS�t�Τ@��Ϣ�\t1/boards\t%s\t70\t+\r\n", host);
		if (Plus)
			net_printf(1, "+INFO: ");

		net_printf(1, "1��BBS�t�κ�ذϢ�\t1/treasure\t%s\t70\t+\r\n", host);
		net_printf(1, ".\r\n");
		return 0;
	}
	else if (!strcmp(path, "/boards"))
	{
		if ((f = open(BOARDS, O_RDONLY)) < 0)
		{
			Print_Error(NFILE);
			return -1;
		}
		if (Plus)
			net_printf(1, "+-1\r\n");

		while (read(f, &bh, sizeof(bh)) == sizeof(bh))
		{
			if (bh.filename[0] == '\0')
				continue;
			if (bh.level == ADMIN_BOARD_LEVEL || bh.level == INVISIBLE_BOARD_LEVEL)
				continue;
			if (Plus)
				net_printf(1, "+INFO: ");

			net_printf(1, "1��%s��--%s\t1/boards/%s\t%s\t70\t+\r\n",
				   bh.title, bh.filename, bh.filename, host);
		}
		close(f);
		net_printf(1, ".\r\n");
		return 0;
	}
	else if (!strcmp(path, "/treasure"))
	{
		if ((f = open(BOARDS, O_RDONLY)) < 0)
		{
			Print_Error(NFILE);
			return -1;
		}
		if (Plus)
			net_printf(1, "+-1\r\n");

		while (read(f, &bh, sizeof(bh)) == sizeof(bh))
		{
			if (bh.filename[0] == 0)
				continue;
			if (bh.level == ADMIN_BOARD_LEVEL || bh.level == INVISIBLE_BOARD_LEVEL)
				continue;
			if (Plus)
				net_printf(1, "+INFO: ");

			net_printf(1, "1��%s��--%s\t1/treasure/%s\t%s\t70\t+\r\n", bh.title, bh.filename, bh.filename, host);
		}
		close(f);
		net_printf(1, ".\r\n");
		return 0;
	}

	sprintf(buf, "%s/%s", path, DIR_REC);
	if ((f = open(buf, O_RDONLY)) > 0)
	{
		if (strstr(buf, "/boards/"))
			if (Plus)
				net_printf(1, "+-1\r\n");
			else if (strstr(buf, "/treasure/"))
				if (Plus)
					net_printf(1, "+-1\r\n");
		while (read(f, &fh, sizeof(fh)) == sizeof(fh))
		{
			if ((fh.accessed & FILE_IN) || (fh.accessed & FILE_OUT))
				continue;
			else if (fh.accessed & FILE_DELE)
				continue;
			else if (fh.accessed & FILE_TREA)
			{
				if (fh.filename[0] == '\0')
					continue;
				if (Plus)
					net_printf(1, "+INFO: ");
				net_printf(1, "1���u�ؿ��v%s��\t1%s/%s\t%s\t70\t+\n",
					 fh.title, path, fh.filename, host);
			}
			else
			{
				net_printf(1, "0��%s��\t0%s/%s\t%s\t70\t+\r\n",
					 fh.title, path, fh.filename, host);
				if (Plus)
				{
					net_printf(1, "+VIEWS:\r\n");
					net_printf(1, " Text/plain: <1k>\r\n");
				}
			}
		}
		close(f);
	}
	net_printf(1, ".\n");
}


void
bbs2g4()			/* main action */
{
	char   *ptr;
	char    buf[240];
	int     len;

	char    isDIR;

	net_gets(0, buf, sizeof(buf));

/*
    sscanf(buf, "%s %s", genbuf, buf2);
    if (!strcmp("", genbuf))
		strcpy(genbuf, "/");
    if (strncmp("/boards", ptr, 7)
		&& strncmp("/treasure", ptr, 9)
		&& strcmp("/", ptr))
    	{
		Print_Error(NFILE);
		return;
    	}
*/

	if (buf[0] == '\n')
	{
		isDIR = TRUE;
		strcpy(buf, "/");
	}
	else if (buf[0] == '1')
		isDIR = TRUE;
	else if (buf[0] == '0')
		isDIR = FALSE;
	else
		isDIR = FALSE;

	len = strlen(buf);
	if (buf[len - 1] == 10)
		buf[len - 1] = '\0';
	ptr = strchr(buf, '/');

	if (isDIR)
		dir(ptr);
	else
		file(ptr);
}


/*-----------------------------------*/
/* reaper - clean up zombie children */
/*-----------------------------------*/
static void
reaper()
{
#if defined(SYSV)
    int     status;
#else
    union wait status;
#endif

    while (wait3(&status, WNOHANG, (struct rusage *) 0) > 0)
         /* empty */ ;
    (void) signal(SIGCHLD, reaper);
}




void
create_server(sock, fd, server)
int    *sock, *fd;
struct sockaddr_in *server;
{
	while (1)
	{
		*fd = 1;
		if ((*sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		{
			exit(-1);
		}
		else
		{
			if (setsockopt(*sock, SOL_SOCKET, SO_REUSEADDR, (char *) fd, sizeof(*fd)) < 0)
			{
				close(*sock);
			}
			else
				break;
		}
	}
	server->sin_family = PF_INET;
	server->sin_addr.s_addr = INADDR_ANY;
	server->sin_port = htons((u_short)port);
	if (bind(*sock, (struct sockaddr *) server, sizeof(*server)) < 0)
		exit(-1);
	if (listen(*sock, 10) < 0)
		exit(-1);
}


#if 0
void
Add_User()
{
	FILE   *f;

	signal(SIGUSR1, SIG_IGN);
/*   signal(SIGCLD,SIG_IGN); */
	totaluser++;
	if ((f = fopen(USERNUM, "w")) != NULL)
	{
		flock(fileno(f), LOCK_EX);
		fprintf(f, "%d\n", totaluser);
		flock(fileno(f), LOCK_UN);
		fclose(f);
	}
	signal(SIGUSR1, Add_User);
}

#endif


void
main(argc, argv)
int     argc;
char   *argv[];
{
	int     s, i, flen, fd, tsize = getdtablesize();
	struct sockaddr_in server, client;
	int     retry_select = 0;
	fd_set  readfds;
	FILE   *f;

	if (argc < 3)
	{
		fprintf(stderr, "Usage: bbs2g4 [port] [timeout second]\n");
		fprintf(stderr, "  Exp: bbs2g4 70 60\n");
		exit(-1);
	}
	if ((argc == 4) && (!strcmp("debug", argv[3])))
		debug = 1;

	if ((i = fork()) == -1)
		exit(-1);
	if (i)
		exit(0);

/*    nice(-5); */

/*
   (void) signal(SIGUSR1, Add_User);
 */

	if ((f = fopen(BBS2G4_PID, "w")) != NULL)
	{
		fprintf(f, "%d", getpid());
		fclose(f);
	}

	if (chroot(HOMEBBS) == -1 || chdir("/") == -1)
	{
		Print_Error(CHROOT);
		unlink(BBS2G4_PID);
		autoexit();
	}

	fd = open(PATH_DEVNULL, O_RDWR, 0);
	if (fd != -1)
	{
		(void) dup2(fd, STDIN_FILENO);
		(void) dup2(fd, STDOUT_FILENO);
		(void) dup2(fd, STDERR_FILENO);
		if (fd > 2)
			(void) close(fd);
	}

	port = atoi(argv[1]);
	idlesec = atoi(argv[2]);

	for (i = 3; i < tsize; i++)
		close(i);
	(void) signal(SIGCHLD, reaper);
	flen = sizeof(client);
	sock = -1;

	while (1)
	{			/* Main Loop */
		if (-1 == sock)
			create_server(&sock, &fd, &server);
		FD_ZERO(&readfds);

		FD_SET(sock, &readfds);
		if (!FD_ISSET(sock, &readfds))
			continue;
		FD_CLR(sock, &readfds);
		retry_select = 0;
		s = accept(sock, (struct sockaddr *) & client, &flen);
		alarm(0);
		if (s < 0)
			continue;
		switch (fork())
		{
			case 0:
				(void) close(sock);
				dup2(s, 0);
				close(s);
				dup2(0, 1);
				dup2(0, 2);
#if 0
				ppid = getppid();
				kill(ppid, SIGUSR1);	/* count people */
#endif
				setuid(BBS_UID);
				setgid(BBS_GID);
#if 0				
				efp = fopen(PATH_DEBUG, "a");
#endif				
				bbs2g4();
#if 0				
				fclose(efp);
#endif				
				autoexit(0);
				break;
			default:
				(void) close(s);
#if 0
				if (debug)
					exit(0);	/* debug mode */
#endif
				break;
		}
	}			/* Main Loop */
}
