
#include "bbs.h"


#define PGP_EXEC 	"bin/pgp"
#define PATH_IDCHECK_HEADER	"tmp/idcheck_header"

#undef  DEBUG
#define SAVE_HEADER


#ifdef DEBUG
int     debug = 1;

#else
int     debug = 0;

#endif


int
a_encode(file1, file2, file3)
char   *file1, *file2, *file3;
{
	char    gbuf[128];

	mycp(file1, file2);
	sprintf(gbuf, "%s -e %s \"%s\"", PGP_EXEC, file2, PUBLIC_KEY);
#ifdef DEBUG
	printf("file: %s\n", file2);
#endif
#if 0
	if (debug)
		printf("command: %s\n", gbuf);
	system(gbuf);
	sprintf(gbuf, "%s.pgp", file2);
#ifdef DEBUG
	printf("pgp: %s\n", file2);
#endif
#endif
#if 1
	sprintf(gbuf, "%s", file2);
#endif
	if (dashf(gbuf))
		rename(gbuf, file3);
	unlink(file2);

	return;
}


int
a_ok(name, cond)		/* write check level */
char    name[15];
char    cond;
{
	struct userec usr;

#ifdef DEBUG
	printf("cond: %d\n", cond);
#endif
	if (get_passwd(&usr, name) <= 0)
		return;
#ifdef DEBUG
	printf("user: %s\n", usr.userid);
#endif
	usr.ident = cond;
#ifdef MULTIBBS
	net_update_user(&usr, usr.passwd);
#endif
	update_user(&usr);
}


int
do_article(fname, path, owner, title)
char   *fname, *path, *owner, *title;
{
	char   *p;
	int     fd;
	struct fileheader fh;

	if (mycp(fname, path))
		return -1;
	p = strrchr(path, '/') + 1;
	bzero(&fh, sizeof(fh));
	strcpy(fh.filename, p);
	strcpy(fh.owner, owner);
	strcpy(fh.title, title);
	strcpy(p, DIR_REC);
	if ((fd = open(path, O_WRONLY | O_CREAT | O_APPEND, 0644)) > 0)
	{
		flock(fd, LOCK_EX);
		strcpy(p, fh.filename);
		write(fd, &fh, sizeof(fh));
		flock(fd, LOCK_UN);
		close(fd);
		return 0;
	}
	return -1;
}


del_ident_article(stamp_fn)
char   *stamp_fn;
{
	int     fd;
	FILEHEADER fh, *fhr = &fh;
	char    filename[PATHLEN];

	sprintf(filename, "ID/%s", DIR_REC);
	if ((fd = open(filename, O_RDWR)) < 0)
		return -1;
	flock(fd, LOCK_EX);
	while (read(fd, fhr, FH_SIZE) == FH_SIZE)
	{
		if (!strcmp(fhr->filename, stamp_fn))
		{
			fhr->accessed |= FILE_DELE;
			if (lseek(fd, -((off_t) FH_SIZE), SEEK_CUR) != -1)
			{
				if (write(fd, fhr, FH_SIZE) == FH_SIZE)
				{
					flock(fd, LOCK_UN);
					close(fd);
					return 0;
				}
			}
		}
	}
	flock(fd, LOCK_UN);
	close(fd);
	return -1;
}


int
process_ident(subject)
char   *subject;
{
	FILE   *fps;
	char    stamp_fn[20], srcfile[80], destfile[80], title[80], userid[20],
	       *tmp, buf[256];
	struct stat st;
	int     i;

	if (!(tmp = strchr(subject, '(')))
		return -1;
	tmp++;
	while (*tmp && *tmp == ' ')
		tmp++;
	i = 0;
	while (*tmp && *tmp != ' ')
		userid[i++] = *tmp++;
	userid[i] = '\0';
	if (*tmp == '\0')
		return -1;
	tmp++;
	i = 0;
	while (*tmp && *tmp != ' ' && *tmp != ')')
		stamp_fn[i++] = *tmp++;
	stamp_fn[i] = '\0';
#ifdef DEBUG
	printf("\n==> stamp_fn: %s", stamp_fn);
#endif
	if (debug)
		printf("\n==> userid: %s", userid);
	sprintf(srcfile, "ID/%s", stamp_fn);
	if ((fps = fopen(srcfile, "r")) == NULL)
		return -1;

	if (!fgets(buf, sizeof(buf), fps))
	{
		fclose(fps);
		return -1;
	}
	fclose(fps);

	if ((tmp = strchr(buf, '\n')))
		*tmp = '\0';
	if (!(tmp = strrchr(buf, '(')))
		return -1;
	tmp++;
	tmp[strlen(tmp) - 1] = '\0';

	if (debug)
		printf("tmp: [%s]\n", tmp);
	if (strcmp(tmp, userid))
		return -1;

	if (debug)
		printf("\n==================\n==> userid: %s\n", userid);
	a_ok(userid, 7);
#ifdef DEBUG
	printf("==> a_ok\n");
#endif
	sprintf(destfile, "realuser/%s", userid);
	sprintf(title, "�����T�{: %s", userid);
#ifdef DEBUG
	printf("do_article\n");
#endif
	if (stat(destfile, &st) == -1)
		do_article(srcfile, destfile, userid, title);
	sprintf(buf, "tmp/%sPGP", userid);
#ifdef DEBUG
	printf("==> a_encode\n");
#endif
	a_encode(srcfile, buf, destfile);
#ifdef DEBUG
	printf("=====> markd [%s]", stamp_fn);
#endif
	del_ident_article(stamp_fn);
	return 0;
}


void
main(argc, argv)
int     argc;
char   *argv[];
{
	FILE   *fp, *fphead;
	char    buf[200], ckmailtmp[PATHLEN], chk_mail[PATHLEN];
	char    from[200], dot_from[200], subject[200];
	int     invalid, header, lines, end_of_onemail;

	if (argc > 1)
	{
		if (!strcmp(argv[1], "debug"))
			debug = 1;
	}

#ifdef NSYSUBBS
	if (getuid() != 0)
	{
		fprintf(stderr, "\n\n!!! �Х� root �Ӱ��楻�{�� !!!\n");
		exit(0);
	}
#else
	if (getuid() != BBS_UID)
	{
		if (setgid(BBS_GID) == -1 || setuid(BBS_UID) == -1)
		{
			fprintf(stderr, "\n\n!!! �Х� bbs �Ӱ��楻�{�� !!!\n");
			exit(0);
		}
	}
#endif

	if (chdir(HOMEBBS) == -1)
	{
		fprintf(stderr, "\ncannot chdir: %s", HOMEBBS);
		exit(-2);
	}
	
	sprintf(ckmailtmp, "tmp/SYSCHECK_ORI.%d", time(0));
	sprintf(chk_mail, "%s/syscheck", SPOOL_MAIL);
	if (mymv(chk_mail, ckmailtmp) == -1)
	{
		fprintf(stderr, "\ncannot rename %s to %s\n", chk_mail, ckmailtmp);
		exit(-1);
	}
#ifdef NSYSUBBS
	if (chroot(HOMEBBS) == -1 || chdir("/") == -1)
		exit(-1);
	chown(ckmailtmp, BBS_UID, BBS_GID);
	setgid(BBS_GID);
	setuid(BBS_UID);
#endif

	if ((fp = fopen(ckmailtmp, "r")) == NULL)
	{
		fprintf(stderr, "\ncannot open file: %s", ckmailtmp);
		exit(-1);
	}
	if ((fphead = fopen(PATH_IDCHECK_HEADER, "w")) == NULL)
	{
		
		fprintf(stderr, "\ncannot open file: %s", PATH_IDCHECK_HEADER);
		exit(-2);
	}

	from[0] = '\0';
	dot_from[0] = '\0';
	subject[0] = '\0';
	header = NA;
	invalid = NA;
	end_of_onemail = NA;
	lines = 0;

	while (fgets(buf, sizeof(buf), fp))
	{
		if (!strncmp(buf, "From ", 5))
		{
			char   *ptr;

			if (end_of_onemail)
			{
#ifdef DEBUG
				printf("==> From %s", from);
				printf("==> From: %s", dot_from);
#endif
				if (debug)
					printf("==> Subject: %s\n", subject);
				fclose(fphead);
				process_ident(subject);
			}
			lines = 0;
			header = YEA;
			end_of_onemail = NA;;
			from[0] = '\0';
			dot_from[0] = '\0';
			subject[0] = '\0';
			invalid = NA;
			strncpy(from, buf + 5, sizeof(from) - 1);
			from[sizeof(from) - 1] = '\0';

			if ((fphead = fopen(PATH_IDCHECK_HEADER, "w")) == NULL)
			{
				fprintf(stderr, "\ncannot open file: %s", PATH_IDCHECK_HEADER);
				exit(-3);
			}
			
			if (!strncmp("MAILER-DAEMON", from, 13)
			    || strstr(from, "postmaster")
			    || ((ptr = strchr(from, '.')) && strchr(ptr, '@')))
			{
				if (debug)
					printf("===> Invalid From %s\n", from);
				invalid = YEA;
			}
		}

		if (invalid)
			continue;
		if (!header)
		{
			lines++;
			continue;
		}
#ifdef SAVE_HEADER
		if (header)
			fprintf(fphead, "%s", buf);
#endif
		if (buf[0] == '\n')
		{
			header = NA;
			end_of_onemail = YEA;
			continue;
		}

		if (!strncmp(buf, "From: ", 6))
		{
			strncpy(dot_from, buf + 6, sizeof(dot_from) - 1);
			dot_from[sizeof(dot_from) - 1] = '\0';
		}
	       /* step (3) */
		else if (!strncmp(buf, "Subject: ", 9))
		{
			strncpy(subject, buf + 9, sizeof(subject) - 1);
			subject[sizeof(subject) - 1] = '\0';
		}
	}
	fclose(fp);

	if (lines > 0)
	{
#ifdef DEBUG
		printf("==> From %s", from);
		printf("==> From: %s", dot_from);
#endif
		if (debug)
			printf("==> Subject: %s\n", subject);
		fclose(fphead);
		process_ident(subject);
	}

	sprintf(buf, "%s.tmp", chk_mail);
	unlink(buf);
}
