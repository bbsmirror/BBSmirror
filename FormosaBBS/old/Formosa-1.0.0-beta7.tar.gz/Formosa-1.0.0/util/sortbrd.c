/*
 * NSYSU BBS ���� sortbrd program : boards �Ƨǵ{��
 *
 *                         Coder: lmj@cc.nsysu.edu.tw �����
 */

#include	"bbs.h"


struct node
{
    struct node *last;
    struct boardheader *bhead;
    struct node *next;
};

struct node *otop, *oz, *ntop, *nz;

void 
init()
{
    otop = (struct node *) malloc(sizeof(struct node));
    oz = (struct node *) malloc(sizeof(struct node));
    ntop = (struct node *) malloc(sizeof(struct node));
    nz = (struct node *) malloc(sizeof(struct node));

    otop->last = otop;
    otop->next = oz;
    oz->last = otop;
    oz->next = oz;
    ntop->last = ntop;
    ntop->next = nz;
    nz->last = ntop;
    nz->next = nz;
    return;
}



int 
mystrcmp(str1, str2)
char   str1[], str2[];
{
    int    i = 0;

    while (1)
	if (str1[i] == '\0' && str2[i] == '\0')
	    return 0;
	else if (str1[i] == '\0')
	    return 1;
	else if (str2[i] == '\0')
	    return -1;
	else if (str1[i] < str2[i])
	    return 1;
	else if (str1[i] > str2[i])
	    return -1;
	else
	    i++;
}


int 
sortbbs(ori_file)
char   ori_file[];
{
    int    fr, fw, rtotal = 0, wtotal = 0, size = sizeof(struct boardheader);
    char   new_file[STRLEN], buf[STRLEN];
    struct node *str1, *str2;

    sprintf(new_file, "%s.new", ori_file);
    if ((fr = open(ori_file, O_RDONLY)) == -1 ||
	(fw = open(new_file, O_WRONLY | O_CREAT, 0644)) == -1)
	return -1;
    init();
    str1 = (struct node *) malloc(sizeof(struct node));

    str1->bhead = (struct boardheader *) malloc(size);
    while (read(fr, str1->bhead, size) == size)
    {
	rtotal++;
	str1->last = otop;
	str1->next = otop->next;
	otop->next->last = str1;
	otop->next = str1;
	str1 = (struct node *) malloc(sizeof(struct node));

	str1->bhead = (struct boardheader *) malloc(size);
    }
    free(str1->bhead);
    free(str1);
    close(fr);
    str1 = otop->next;
    while (str1 != oz)
    {
	otop->next = str1->next;
	str1->next->last = otop;
	str2 = ntop->next;
	while (str2 != nz)
#if 0	
	    if (mystrcmp(str1->bhead->filename, str2->bhead->filename) > 0)
		break;
#endif		
	    if (strcasecmp(str1->bhead->filename, str2->bhead->filename) < 0)
		break;
	    else
		str2 = str2->next;
	str1->last = str2->last;
	str1->next = str2;
	str2->last->next = str1;
	str2->last = str1;
	str1 = otop->next;
    }
    str1 = ntop->next;
    while (str1 != nz)
    {
	wtotal++;
	write(fw, str1->bhead, size);
	str1 = str1->next;
    }
    close(fw);
    fprintf(stdout, "\r\nRead %d lines, Write %d lines\n\r", rtotal, wtotal);
    sprintf(buf, "%s.ori", ori_file);
    unlink(buf);
    if (rtotal != wtotal || rename(ori_file, buf) == -1)
    {
	unlink(new_file);
	return -1;
    }
    else if (rename(new_file, ori_file) == -1)
    {
	rename(buf, ori_file);
	unlink(new_file);
	return -1;
    }
    else
	return 0;
}


void 
main()
{
    if (getuid() != BBS_UID)
    {
	if (chroot(HOMEBBS) || chdir("/"))
	    exit(-1);
	setgid(BBS_GID);
	setuid(BBS_UID);
    }
    
    if (sortbbs(BOARDS) == -1)	/* lasehu */
    {
	fprintf(stderr, "Error: sort failed !\n\r");
	exit(-1);
    }
    
    printf("\nSort Boards Success\n\r");
}
