
#include "bbs.h"
#include "csbbs.h"

#define SMTPPORT	(25)

/*******************************************************************
 * �R���Q�аO���峹
 * �ǤJ .DIR �����|, buf pointer, buf size
 * �Ǧ^: 0 ����, -1 ����
 *******************************************************************/
int
pack_article(direct, if_mail)
char   *direct;
int     if_mail;
{
	int     fl, fr, fw;
	struct fileheader bh;
	struct fileheader mh;
	char    fname[STRLEN], temp[STRLEN], deleted[STRLEN], locked[STRLEN], *p;

	strcpy(locked, direct);
	strcat(locked, ".lock");
	if ((fl = open(locked, O_CREAT | O_WRONLY, 0644)) < 0)
		return -1;
	flock(fl, LOCK_EX);
	strcpy(fname, direct);
	strcpy(temp, direct);
	strcpy(deleted, direct);
	strcat(temp, ".tmp");
	strcat(deleted, ".del");
	unlink(temp);
	unlink(deleted);
	if ((fr = open(direct, O_RDONLY)) < 0 ||
	    (fw = open(temp, O_WRONLY | O_CREAT, 0644)) < 0)
	{
		flock(fl, LOCK_UN);
		close(fl);
		close(fr);
		return -1;
	}
	p = rindex(fname, '/') + 1;
	if (if_mail)
	{
		while (read(fr, &mh, FH_SIZE) == FH_SIZE)
		{
		/* if(!strncmp(mh.filename,"D.",2))  */
			if (mh.accessed == FILE_DELE)
			{
				strcpy(p, mh.filename);
				unlink(fname);
			}
			else
				write(fw, &mh, sizeof(mh));
		}
	}
	else
	{
		while (read(fr, &bh, sizeof(bh)) == sizeof(bh))
		{
			if (!strncmp(bh.filename, "D.", 2))
			{
				strcpy(p, bh.filename);
				unlink(fname);
			}
			else
				write(fw, &bh, sizeof(bh));
		}
	}
	close(fr);
	close(fw);
	if (!rename(direct, deleted))
	{
		if (rename(temp, direct))
			rename(deleted, direct);
		else
			p = (char) NULL;
	}
	unlink(temp);
	unlink(deleted);
	flock(fl, LOCK_UN);
	close(fl);
	return ((p) ? -1 : 0);
}

/*******************************************************************
 * �]�tñ�W��
 *		name	user ID
 *		wfile	�ɮצW�
 *		num		ñ�W�ɽs��
 *******************************************************************/
int
include_sig(name, wfile, num)	/* �ץ�!! gcl ,Cauchy */
char   *name, *wfile;
int     num;
{
	FILE   *fpr, *fpw;
	char    rfile[STRLEN];
	int     ch, i;

	sethomefile(rfile, name, UFNAME_SIGNATURES);
	if ((fpr = fopen(rfile, "r")) == NULL)
		return -1;
	if ((fpw = fopen(wfile, "a")) == NULL && (fpw = fopen(wfile, "w")) == NULL)
	{
		fclose(fpr);
		return -1;
	}
	chmod(wfile, 0644);
	fputs("\n\n\n--\n", fpw);
	for (i = 0; i < (num - 1) * 4; i++)
		fgets(genbuf, 4096, fpr);
	ch = 0;
	while (ch++ < MAX_SIG_LINES && fgets(genbuf, 4096, fpr))
		fputs(genbuf, fpw);
	fputs("[m\n", fpw);
	fclose(fpr);
	fclose(fpw);
	return 0;
}

/*******************************************************************
 * �� mail server �إ� socket
 * return: socket number
 *******************************************************************/
int
create_mail_socket()
{
	char   *s[2];
	int     ms;

	s[0] = MAILSERVER1;
#if 0
	ms = create_client_socket(s, SMTPPORT);
#endif
	ms = ConnectServer(*s, SMTPPORT, TCP);
	if (ms < 0)
	{
		s[0] = MAILSERVER2;
#if 0
		ms = create_client_socket(s, SMTPPORT);
#endif
		ms = ConnectServer(*s, SMTPPORT, TCP);
	}

	if (ms > 0)
	{
		io_timeout_sec = CS_IDLE_TIMEOUT;
		alarm(IDLE_SIGNAL);
		net_printf(ms, "HELO helo\n");
		net_gets(ms, genbuf, sizeof(genbuf));
	}
	return ms;
}

/*******************************************************************
 * �H�X�@�g�ɮ�
 *******************************************************************/
int
mail_file(ms, fname, from, to, title)
int     ms;
char   *fname, *from, *to, *title;
{
	FILE   *fs;

	if ((fs = fopen(fname, "r")) == NULL)
		return -1;
	net_printf(ms, "MAIL FROM:%-s.bbs@%-s\n", from, MYHOSTNAME);
	net_gets(ms, genbuf, sizeof(genbuf));
	net_printf(ms, "RCPT TO:%-s\n", to);
	net_gets(ms, genbuf, sizeof(genbuf));
	net_printf(ms, "DATA\n");
	net_gets(ms, genbuf, sizeof(genbuf));
	net_printf(ms, "From: %-s.bbs@%-s\n", from, MYHOSTNAME);
	net_printf(ms, "To: %-s\n", to);
	net_printf(ms, "Subject: %-s\n\n", title);
	while (fgets(genbuf, 4096, fs))
		net_printf(ms, "%s", genbuf);
	fclose(fs);
	net_printf(ms, "\n.\n");
	net_gets(ms, genbuf, sizeof(genbuf));
	net_printf(ms, "RSET\n");
	net_gets(ms, genbuf, sizeof(genbuf));
	return 0;
}

/*******************************************************************
 * ���� mail socket
 *******************************************************************/
int
close_mail_socket(ms)
int     ms;
{
	net_printf(ms, "\nQUIT\n");
	net_gets(ms, genbuf, sizeof(genbuf));
	close(ms);
	if (curuser.userlevel < IDLE_DONT_KILL)
		alarm(IDLE_SIGNAL);
	else
		alarm(0);
	return 0;
}


/*******************************************************************
 * �� article �u���a append �W�h
 *******************************************************************/
int
do_article(fname, path, owner, title, in_mail)	/* �ץ�!! gcl */
char   *fname, *path, *owner, *title;
int     in_mail;
{
	char   *p;
	int     fd;
	struct stat st;
	struct fileheader fh;
	struct fileheader lastfile;

	if (!in_mail)
	{
		stat(boarddirect, &st);
		if ((fd = open(boarddirect, O_RDWR)) < 0)
		{
			RespondProtocol(WORK_ERROR);
			return;
		}

		if (lseek(fd, (long) (st.st_size - FH_SIZE), SEEK_SET) == -1)
		{
			RespondProtocol(WORK_ERROR);
			close(fd);
			return;
		}

		if (read(fd, &lastfile, FH_SIZE) != FH_SIZE)
		{
			close(fd);
			RespondProtocol(WORK_ERROR);
			return;
		}
		close(fd);
	}

	if (stat(path, &st))
	{
		if (!(in_mail && !mkdir(path, 0700)))
			return -1;
	}
	get_only_name2(path);
	if (mycp(fname, path))
		return -1;
	p = rindex(path, '/') + 1;

	bzero(&fh, sizeof(fh));

	if (!in_mail)
	{
		if (lastfile.artno >= BRC_REALMAXNUM)
			fh.artno = 1;
		else if (lastfile.artno > 0)
			fh.artno = lastfile.artno + 1;

		if (fh.artno == 1)
		{
			int     fd2;
			struct boardheader sbh;

			if ((fd2 = open(BOARDS, O_RDWR)) > 0)
			{
				flock(fd2, LOCK_EX);
				while (read(fd2, &sbh, sizeof(sbh)) == sizeof(sbh))
				{
					if (!strcmp(sbh.filename, CurrentBoard))
					{
						sbh.rewind_time = time(0);
						if (lseek(fd2, -(sizeof(sbh)), SEEK_CUR) != -1)
							write(fd2, &sbh, sizeof(sbh));
						break;
					}
				}
				flock(fd2, LOCK_UN);
				close(fd2);
			}
		}
	}


	fh.accessed = 0;
	strcpy(fh.filename, p);
	strcpy(fh.owner, owner);
	strcpy(fh.title, title);
	fh.owner_ident = curuser.ident;
	brc_addlist(fh.artno);

	strcpy(p, ".DIR");
	fd = open(path, O_WRONLY | O_CREAT | O_APPEND, 0644);
	strcpy(p, fh.filename);
	if (fd < 0)
	{
		unlink(path);
		return -1;
	}
	flock(fd, LOCK_EX);
	write(fd, &fh, sizeof(fh));
	flock(fd, LOCK_UN);
	close(fd);
	return 0;
}


/*******************************************************************
 * �����R���@�g�峹
 *******************************************************************/
int
del_one_article(ent, fileinfo, direct, option, in_mail)
int     ent;
struct fileheader *fileinfo;
char   *direct, option;
int     in_mail;
{
	int     fd;
	struct fileheader *bfh;

	bfh = malloc(FH_SIZE);
	if ((fd = open(direct, O_RDWR)) < 0)
		return -1;
	lseek(fd, (long) (FH_SIZE * (ent - 1)), SEEK_SET);
	read(fd, bfh, FH_SIZE);
	if (lseek(fd, (long) (-FH_SIZE), SEEK_CUR) != -1)
	{
		if (option == 'd')
		{
			bfh->accessed = FILE_DELE;
			write(fd, bfh, FH_SIZE);
		}
		else if (option == 'u')
		{
			bfh->accessed = FILE_READ;
			write(fd, bfh, FH_SIZE);
		}
		if (option == 'd' && !in_mail && in_board
		    && (CurBList->type == 'B' || CurBList->type == 'O')
		    && fileinfo->owner[0] != '#'
		    && curuser.numlogins >= LOGIN_NUMBER)
		{
			append_news(CurBList->name, fileinfo->filename, 'D');
		}
		close(fd);
		return 0;
	}
	close(fd);
	return -1;
}

/* �h�� uuencode ���� */
/*******************************************************************
 * ��峹�H�� Mail Groups
 *******************************************************************/
int
mail_group(ms, mgroup, fname, from, title)
int     ms;
char   *mgroup[], *fname, *from, *title;
{
	short   i;
	char    path[STRLEN];

	if (!mgroup || !fname || !from)
		return -1;
	for (i = 0; i < MAIL_GROUPS; i++)
	{
		if (mgroup[i] == NULL)
			continue;
		if (index(mgroup[i], '@'))
		{
			mail_file(ms, fname, from, mgroup[i], title);
		}
		else
		{
			sprintf(path, "mail/%c/%-s", tolower(*mgroup[i]), mgroup[i]);
			do_article(fname, path, from, title, YEA);
		}
		free(mgroup[i]);
	}

	return 0;
}
