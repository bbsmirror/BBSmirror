
#include "bbs.h"
#include "csbbs.h"


#define FORMOSABBS1 "140.117.11.2"
#define FORMOSABBS2 "140.117.11.4"
#define FORMOSABBS3 "140.117.11.6"

/**************************************************************
*		VERCHK num
*				�]�w�ҨϥΪ�Client�����s��
*				�t�Τ��w�Ȭ�20
***************************************************************/
DoVersionCheck()
{
	int     ver;

	ver = Get_para_number(1);
	if (ver <= 0)
		RespondProtocol(SYNTAX_ERROR);
	else
	{
		client_version = ver;
		if (ver >= VERSION_NEWEST)
			RespondProtocol(VER_OK);
		else if (ver >= VERSION_LEAST)
			RespondProtocol(VER_GETNEW);
		else
			RespondProtocol(VER_NOT);
	}
/*-------------------------------------------
    NextToken=GetToken(NextToken,tmp,10);
    if(tmp[0]=='\0')
        RespondProtocol(SYNTAX_ERROR);
    else
		{
        ver=atoi(tmp);
        client_version=ver;
        if(ver>=VERSION_NEWEST)
            RespondProtocol(VER_OK);
        else if(ver>=VERSION_LEAST)
            RespondProtocol(VER_GETNEW);
        else
            RespondProtocol(VER_NOT);
    	}
----------------------------------------------*/

}

DoBBSName()
{
	inet_printf("%d %s\r\n", BBSNAME_IS, BBSNAME);
}

/***********************************************************
*		CHKANNOUNCE
*			���o���i�̫�ק���
************************************************************/
DoChkAnnounce()
{
	struct stat st;

	if (stat(WELCOME, &st) < 0)
		RespondProtocol(NO_ANNOUNCE);
	else
		inet_printf("%d\t%ld\r\n", ANN_TIME, st.st_mtime);
}

/***********************************************************
*		ANNOUNCE
*			���o�񯸤��i
************************************************************/
DoAnnounce()
{
	struct stat st;

	if (stat(WELCOME, &st) < 0)
		RespondProtocol(NO_ANNOUNCE);
	else
		SendArticle(WELCOME, YEA);
}

/************************************************************
*		BBSINFO
*			���oBBS name�ATerminal��Client���H��
*************************************************************/
DoAskBBSInformation()
{
	int     t_user, c_user;

	MyAskOnlineUser(&t_user, &c_user);
	RespondProtocol(OK_CMD);
	inet_printf("BBSNAME:\t%s\r\nT-USER:\t%d\r\nC-USER:\t%d\r\n.\r\n", BBSNAME, t_user, c_user);
}

int 
MyAskOnlineUser(int *t_user, int *c_user)
{
	void   *shmptr;
	int     shmid, csbbs, total, i;
	struct UTMPFILE *utmpshm;
	USER_INFO *u;

	total = csbbs = 0;
	shmid = shmget(UTMPSHM_KEY, sizeof(struct UTMPFILE), 0);
	if (shmid >= 0)
	{
		shmptr = (void *) shmat(shmid, NULL, 0);
		if (shmptr != (void *) -1)
		{
			utmpshm = (struct UTMPFILE *) shmptr;
			u = utmpshm->uinfo;
			for (i = 0; i < MAXACTIVE; i++, u++)
			{
				if (u->pid > 2)
				{
					if (kill(u->pid, 0))
						u->pid = 0;
					else
					{
						if (u->c_type == CTYPE_CSBBS)
							csbbs++;
						total++;
					}
				}
			}
		}
	}

	*t_user = total;
	*c_user = csbbs;
}

void 
chk_str2(str)
char    str[];
{
	char    t[STRLEN];
	int     i = -1, j = 0;

	if (str)
	{
		while (str[++i] != '\0')
		{
			if (str[i] == ESC && str[i++] == '[')
				i += 3;
			t[j] = str[i];
			j++;
		}
	}
	t[j] = '\0';
	strcpy(str, t);
	return;
}


int
chk_alpha(str)
unsigned char *str;
{
	while (str && *str)
		if (!isalpha(*str++))	/* not alpha character */
			return 0;
	return 1;
}


/*******************************************************************
 * �b���w���ؿ��U���o�ߤ@�� M.xxxxxxxx.A �ɦW
 *******************************************************************/
get_only_name2(fname)
char    fname[];
{
	char   *p;
	int     fd;

	p = fname + strlen(fname);
	do
	{
		sprintf(p, "/M.%d.A", time(0));
	}
	while ((fd = open(fname, O_WRONLY | O_CREAT | O_EXCL, 0644)) < 0);
	close(fd);
}

