
#include "bbs.h"
#include "csbbs.h"


/*****************************************************
 *  Syntax: FORWARD
 *				�۰���H�H��}��
 *****************************************************/
DoForward()
{
	char    strbuf[80];

	if (curuser.flags[0] & FORWARD_FLAG)	/* �w�}�� */
		curuser.flags[0] &= ~FORWARD_FLAG;
	else
	{
		sprintf(strbuf, "%s.bbs@%s", curuser.userid, MYHOSTNAME);
		if (!strcmp(strbuf, curuser.email))
		{
			RespondProtocol(WORK_ERROR);
			return;
		}
		curuser.flags[0] |= FORWARD_FLAG;
	}

	RespondProtocol(OK_CMD);
}

/*****************************************************
 *  Syntax: MAILNUM
 *				���o�H��ƥ�
 *****************************************************/
DoGetMailNumber()
{
	int     num;

	num = get_num_records(maildirect, FH_SIZE);

	inet_printf("%d\t%d\r\n", MAIL_NUM_IS, num);
}

/*****************************************************
 *   Syntax: MAILHEAD startnum [endnum]
 *				���o�H����
 *  Respond: MailNum State-Condition Owner Date Title
 *				���o�H����
 *****************************************************/
DoGetMailHead()
{
	int     start, end, num, fd, i;
	struct fileheader fh;
	char    mail_state, chdate[6], c;
	time_t  date;

	start = Get_para_number(1);
	if (start < 1)
	{
		RespondProtocol(MAIL_NOT_EXIST);
		return;
	}

	end = Get_para_number(2);
	if (end < 1)
		end = start;
	else if (end < start)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	num = get_num_records(maildirect, FH_SIZE);	/* get mail count */

	if (start > num || end > num)
	{
		RespondProtocol(MAIL_NOT_EXIST);
		return;
	}

	if ((fd = open(maildirect, O_RDWR)) < 0)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	if (lseek(fd, FH_SIZE * (start - 1), SEEK_SET) == -1)
	{
		RespondProtocol(WORK_ERROR);
		close(fd);
		return;
	}

	RespondProtocol(OK_CMD);
	net_cache_init();
	for (i = start; i <= end; i++)
	{
		if (read(fd, &fh, FH_SIZE) == FH_SIZE)
		{
			if (fh.accessed == FILE_DELE)
				mail_state = 'D';	/* deleted mail */
			else if (fh.accessed == FILE_READ)
				mail_state = 'R';	/* readed mail */
			else
				mail_state = 'N';	/* new mail */

			date = atol((fh.filename) + 2);
			strftime(chdate, 6, "%m/%d", localtime(&date));
			chk_str2(fh.owner);
			chk_str2(fh.title);

			if (curuser.ident == 7)
				c = fh.owner_ident + '0';
			else
				c = '*';
			if (mail_state != 'D')
				sprintf(MyBuffer, "%d\t%c\t%c\t%s\t%s\t%s\r\n", i, mail_state, c, fh.owner, chdate, fh.title);
			else
				sprintf(MyBuffer, "%d\t%c\t%c\t%s\t%s\r\n", i, mail_state, c, fh.owner, chdate);
			net_cache_write(MyBuffer, strlen(MyBuffer));
		}
		else
			break;
	}
	close(fd);
	net_cache_write(".\r\n", 3);	/* end */
	net_cache_refresh();
}

/*****************************************************
 *  Syntax: MAILGET mailnum
 *			���o�H�󤺮e
 *****************************************************/
DoGetMail()
{
	int     idx, fd, num;
	struct fileheader fh;
	char   *p;

	idx = Get_para_number(1);
	if (idx < 1)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	num = get_num_records(maildirect, FH_SIZE);	/* get mail count */

	if (idx > num)
	{
		RespondProtocol(MAIL_NOT_EXIST);
		return;
	}

	if ((fd = open(maildirect, O_RDWR)) < 0)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	if (lseek(fd, FH_SIZE * (idx - 1), SEEK_SET) == -1)
	{
		RespondProtocol(WORK_ERROR);
		close(fd);
		return;
	}

	if (read(fd, &fh, FH_SIZE) != FH_SIZE)
	{
		close(fd);
		RespondProtocol(WORK_ERROR);
		return;
	}

	if (fh.accessed == FILE_DELE)
	{
		close(fd);
		RespondProtocol(MAIL_NOT_EXIST);
		return;
	}

	if (lseek(fd, FH_SIZE * (idx - 1), SEEK_SET) == -1)
	{
		RespondProtocol(WORK_ERROR);
		close(fd);
		return;
	}

	fh.accessed = FILE_READ;
	write(fd, &fh, FH_SIZE);
	close(fd);

	strcpy(genbuf, maildirect);
	p = rindex(genbuf, '/') + 1;
	strcpy(p, fh.filename);

	SendArticle(genbuf, YEA);
}

/*****************************************************
 *  Syntax: MAILPUT to sign title
 *				to		����H
 *              sign	ñ�W�ɽs��
 *				title	�H����D
 *****************************************************/
DoSendMail()
{
	char   *to, *title, fname[STRLEN], path[STRLEN];
	int     sign, ms, ch;
	struct userec lookupuser;

	to = Get_para_string(1);
	if (to == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	if (index(to, '@') == NULL && get_passwd(&lookupuser, to) == 0)
	{
		RespondProtocol(USERID_NOT_EXIST);
		return;
	}

	if (lookupuser.flags[0] & FORWARD_FLAG)
		to = lookupuser.email;

	sign = Get_para_number(2);
	if (sign < 0)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	title = Get_para_string(3);
	if (title != NULL)
		chk_str2(title);
	else
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	sprintf(fname, "/tmp/%-sM.%-d", curuser.userid, time(0));
	if (RecvArticle(fname, YEA, to, title) == 0)
	{
		if ((sign >= 1) && (sign <= 3))
			include_sig(curuser.userid, fname, sign);	/* include sign */

		if (index(to, '@'))
		{
			if ((ms = create_mail_socket()) > 0)
			{
				ch = mail_file(ms, fname, curuser.userid, to, title);
				close_mail_socket(ms);
			}
			else
				ch = -1;
		}
		else
		{
			sprintf(path, "mail/%c/%-s", tolower(to[0]), to);
			ch = do_article(fname, path, curuser.userid, title, YEA);
		}

		unlink(fname);
		if (ch)
			RespondProtocol(WORK_ERROR);
		else
			RespondProtocol(OK_CMD);
	}
	else
		RespondProtocol(WORK_ERROR);
}

/*****************************************************
 *  Syntax: MAILKILL  mailtnum
 *****************************************************/
DoKillMail()
{
	int     idx, num, fd;
	struct fileheader fileinfo;

	idx = Get_para_number(1);
	if (idx < 1)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	num = get_num_records(maildirect, FH_SIZE);	/* get mail count */

	if (idx > num)
	{
		RespondProtocol(MAIL_NOT_EXIST);
		return;
	}

	if ((fd = open(maildirect, O_RDWR)) < 0)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	if (lseek(fd, FH_SIZE * (idx - 1), SEEK_SET) == -1)
	{
		RespondProtocol(WORK_ERROR);
		close(fd);
		return;
	}

	if (read(fd, &fileinfo, FH_SIZE) != FH_SIZE)
	{
		close(fd);
		RespondProtocol(WORK_ERROR);
		return;
	}
	close(fd);

	if (fileinfo.accessed == FILE_DELE)
	{
		RespondProtocol(OK_CMD);
		return;
	}

	if (!del_one_article(idx, fileinfo, maildirect, 'd', YEA))
	{
		RespondProtocol(OK_CMD);
		ever_del_mail = YEA;
	}
	else
		RespondProtocol(WORK_ERROR);
}

/*****************************************************
 *  Syntax: MAILGROUP sign title
 *
 *  Step: C> MAILGROUP [sign] [title]
 *        S> OK_CMD
 *        C> [username]
 *        S> OK_CMD or USERID_NOT_EXIST
 *        C> .        { end }
 *        S> OK_CMD
 *        C> [article body]
 *        S> OK_CMD or...
 *
 ******************************************************/
DoMailGroup()
{
	char   *title, fname[STRLEN], to[STRLEN];
	char   *mgroup[MAIL_GROUPS];
	int     sign;
	int     ms, ch;
	int     i, mgcount;

	sign = Get_para_number(1);
	if (sign < 0)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	title = Get_para_string(2);
	if (title != NULL)
		chk_str2(title);
	else
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	mgcount = 0;
	for (i = 0; i < MAIL_GROUPS; i++)
		mgroup[i] = (char *) NULL;

	RespondProtocol(OK_CMD);
	while (1)
	{
		if (inet_gets(to, STRLEN - 1) < 0)
			FormosaExit();

		if (to[0] == '.' && to[1] == '\0')	/* if end */
			break;

		if (mgcount < MAIL_GROUPS && to[0] != 0)
		{
			if (!index(to, '@') && !get_passwd(NULL, to))
			{
				for (i = 0; i < mgcount; i++)
					free(mgroup[i]);
				RespondProtocol(USERID_NOT_EXIST);
				return;
			}
			else
			{
				mgroup[mgcount] = (char *) malloc(strlen(to) + 1);
				strcpy(mgroup[mgcount], to);
				mgcount++;
				RespondProtocol(OK_CMD);
			}
		}
		else
		{
			for (i = 0; i < mgcount; i++)
				free(mgroup[i]);
			RespondProtocol(WORK_ERROR);
			return;
		}
	}

	if (mgcount == 0)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	sprintf(fname, "/tmp/%-s.%-d", curuser.userid, time(0));
	if (RecvArticle(fname, YEA, to, title) == 0)
	{
		if ((sign >= 1) && (sign <= 3))
			include_sig(curuser.userid, fname, sign);	/* include sign */

		if ((ms = create_mail_socket()) > 0)
		{
			ch = mail_group(ms, mgroup, fname, curuser.userid, title);
			close_mail_socket(ms);
		}
		else
		{
			for (i = 0; i < mgcount; i++)
				free(mgroup[i]);
			ch = -1;
		}

		unlink(fname);
		if (ch)
			RespondProtocol(WORK_ERROR);
		else
			RespondProtocol(OK_CMD);
	}
	else
		RespondProtocol(WORK_ERROR);
}

/*****************************************************
*		MAILNEW
*			�ˬd�O�_���s�H
******************************************************/
DoCheckNewMail()
{
	if (chkmail())
		RespondProtocol(HAVE_NEW_MAIL);
	else
		RespondProtocol(OK_CMD);
}

/*****************************************************
 *  Syntax: MAILUKILL  mailtnum
 * 				�����R���H
 *****************************************************/
DoUnkillMail()
{
	int     idx, num, fd;
	struct fileheader fileinfo;
	char    mail_state;

	idx = Get_para_number(1);
	if (idx < 1)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	num = get_num_records(maildirect, FH_SIZE);	/* get mail count */

	if (idx > num)
	{
		RespondProtocol(MAIL_NOT_EXIST);
		return;
	}

	if ((fd = open(maildirect, O_RDWR)) < 0)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	if (lseek(fd, (long) (FH_SIZE * (idx - 1)), SEEK_SET) == -1)
	{
		RespondProtocol(WORK_ERROR);
		close(fd);
		return;
	}

	if (read(fd, &fileinfo, FH_SIZE) != FH_SIZE)
	{
		close(fd);
		RespondProtocol(WORK_ERROR);
		return;
	}
	close(fd);

	mail_state = (fileinfo.accessed == FILE_READ) ? 'R' : 'N';

	if (fileinfo.accessed != FILE_DELE)
	{
		inet_printf("%d\t%c\t%s\r\n", OK_CMD, mail_state, fileinfo.title);
		return;
	}

	if (!del_one_article(idx, fileinfo, maildirect, 'u', YEA))
		inet_printf("%d\t%c\t%s\r\n", OK_CMD, mail_state, fileinfo.title);
	else
		RespondProtocol(WORK_ERROR);
}

/*****************************************************
 *  Syntax: MAILMAIL  mailtnum to
 *				�H����H
 *****************************************************/
DoMailMail()
{
	int     idx, num, fd, ms, ch;
	char   *to, fname[STRLEN], *p;
	struct fileheader fileinfo;

	idx = Get_para_number(1);
	if (idx < 1)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	to = Get_para_string(2);
	if (to == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	num = get_num_records(maildirect, FH_SIZE);	/* get mail count */

	if (idx > num)
	{
		RespondProtocol(MAIL_NOT_EXIST);
		return;
	}

	if ((fd = open(maildirect, O_RDWR)) < 0)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	if (lseek(fd, (long) (FH_SIZE * (idx - 1)), SEEK_SET) == -1)
	{
		RespondProtocol(WORK_ERROR);
		close(fd);
		return;
	}

	if (read(fd, &fileinfo, FH_SIZE) != FH_SIZE)
	{
		close(fd);
		RespondProtocol(WORK_ERROR);
		return;
	}
	close(fd);

	if (fileinfo.accessed == FILE_DELE)
	{
		RespondProtocol(MAIL_NOT_EXIST);
		return;
	}

	strcpy(fname, maildirect);
	p = rindex(fname, '/') + 1;
	strcpy(p, fileinfo.filename);

	if ((ms = create_mail_socket()) > 0)
	{
		ch = mail_file(ms, fname, curuser.userid, to, fileinfo.title);
		close_mail_socket(ms);
	}
	else
		ch = -1;

	if (ch)
		RespondProtocol(WORK_ERROR);
	else
		RespondProtocol(OK_CMD);
}

/*******************************************************************
 * �d�ۤv���S���s�i�Ӫ��H
 *******************************************************************/
chkmail()
{
	int     fd, numfiles, i;
	struct fileheader *ch;
	static  ismail = 0;

	ch = malloc(FH_SIZE);
	if ((fd = open(maildirect, O_RDONLY)) < 0)
		return (ismail = 0);

	numfiles = get_num_records(maildirect, FH_SIZE);	/* get mail count */

	if (numfiles <= 0)
	{
		close(fd);
		return (ismail = 0);
	}

	lseek(fd, 0, SEEK_END);
	for (i = 0; i < numfiles; i++)
	{
		lseek(fd, -FH_SIZE, SEEK_CUR);
		read(fd, ch, FH_SIZE);
		lseek(fd, -FH_SIZE, SEEK_CUR);
		if (!ch->accessed)
		{
			close(fd);
			return (ismail = 1);
		}
	}
	close(fd);
	return (ismail = 0);
}




/*******************************************************************
 * �d�O�H���S���٨SŪ���H
 *******************************************************************/
int 
chk_others_mail(name)
char   *name;
{
	long    lasttime = 0;
	short   oismail = 0;
	struct stat st;
	int     fd;
	register int i, offset;
	register long numfiles;
	unsigned char ch;

	offset = ((int)&(tmp_fh.accessed) - (int)&(tmp_fh)) ;
	sprintf(genbuf, "mail/%c/%-s/.DIR", tolower(name[0]), name);
	if ((fd = open(genbuf, O_RDONLY)) < 0)
		return (oismail = 0);
	fstat(fd, &st);
	if (lasttime >= st.st_mtime)
	{
		close(fd);
		return oismail;
	}
	lasttime = st.st_mtime;
	numfiles = st.st_size;
	numfiles = numfiles / sizeof(tmp_fh);
	if (numfiles <= 0)
	{
		close(fd);
		return (oismail = 0);
	}
	lseek(fd, (long) offset, L_SET);
	for (i = 0; i < numfiles; i++, lseek(fd, offset + i * sizeof(tmp_fh), L_SET))
	{
		read(fd, &ch, 1);
		if (!(ch & FILE_READ))
		{
			close(fd);
			return (oismail = 1);
		}
	}
	close(fd);
	return (oismail = 0);
}
