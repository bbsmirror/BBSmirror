/**************************************************************
 *            		���ɬO�����ɮ׶ǿ骺function
 **************************************************************/
#include "bbs.h"
#include "csbbs.h"


struct fword *link_start = NULL, *link_last = NULL;

SendFile(filename, type)
char   *filename;
char    type;
{
	int     fp;
	char    buf[WRITE_BUF];
	int     len;
	struct ftpheader fullname;
	struct stat statbuf;

	if ((fp = open(filename, O_RDONLY)) == -1)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	read(fp, &fullname, sizeof(struct ftpheader));

	if (type == FILE_IN)
	{
		RespondProtocol(FILE_IN_SITE);
		inet_printf("%d\t%s\r\n", ORI_FILENAME, fullname.ori_filename);
		RespondProtocol(OK_CMD);
	}
	else
	{
		RespondProtocol(FILE_OUT_SITE);
		inet_printf("%d\t%s\t%s\t%s\r\n", OUT_FILE, fullname.ori_filename,
			    fullname.ftp_site, fullname.place);
		RespondProtocol(OK_CMD);
		while (read(0, buf, 1) > 0);
		FormosaExit();
	}


 /* net_cache_init();  */

	while ((len = read(fp, buf, WRITE_BUF)))
	{			/* start send article */
		if (len <= 0)
			break;

	/* net_cache_write(buf,len);  */
		write(1, buf, len);

	/*
	   for (;;) { inet_gets(chk_buf, STRLEN); chk_num = atoi(chk_buf); if
	   (chk_num > 0) break; } Deleted by Carey --> No Use anymore
	*/

	}
	stat(filename, &statbuf);
	if ((statbuf.st_size - FTPSIZE) < 2048)
		sleep(2);

	close(fp);
	FormosaExit();
 /* net_cache_refresh();  */
}

int 
write_fileinfo(fp, fullname)
int     fp;
struct ftpheader *fullname;
{
	write(fp, fullname, FTPSIZE);

}


int 
RecvFile(filename, fullname, type)
char   *filename;
struct ftpheader *fullname;
int     type;
{
	int     fp;
	char    buf[READ_BUF];
	long    words;
	long    size;

	if ((fp = open(filename, O_WRONLY | O_CREAT)) == -1)
	{
		close(fp);
		return -1;
	}
	chmod(filename, 0644);
	if (type)		/* �p�G�O���~�� */
	{
		RespondProtocol(OK_CMD);
		inet_gets(fullname->ftp_site, STRLEN);
		inet_gets(fullname->place, STRLEN);
		if ((strlen(fullname->ftp_site) == 0) ||
		    (strlen(fullname->place) == 0))
		{
			close(fp);
			unlink(filename);
			return -1;
		}
		write_fileinfo(fp, fullname);
		close(fp);
		return 0;
	}
	write_fileinfo(fp, fullname);
	RespondProtocol(OK_CMD);

/*
	size = 0;
    while(1)
        {
		words = recv(0, buf, READ_BUF, 0);
		write(fp, buf, words);
		if (words != READ_BUF)
			break;
		size += words;
        if(size>MAX_FILE_SIZE)
            {
            close(fp);
            unlink(filename);
            FormosaExit();
            }
        }
*/

	size = 0;
	while ((words = read(0, buf, READ_BUF)) > 0)
	{
		inet_printf("%d\r\n", words);
		if (write(fp, buf, words) != words)
		{
			close(fp);
			unlink(filename);
			FormosaExit();
		}
		size += words;
		if (size > MAX_FILE_SIZE)
		{
			close(fp);
			unlink(filename);
			FormosaExit();
		}
	/*
	   if (words != READ_BUF) break;
	*/
	}
	close(fp);
	return 0;
}

/*****************************************************
 *  Syntax: FILEKILL  postnum [PATH level1 level2 ..]
 *****************************************************/
DoKillFile()
{
	int     idx, num, t_num, fd;
/*	int ftemp, i;*/
	struct fileheader fileinfo;
/*	
	char    temp_name[STRLEN], *p;
*/	

	if (!SelectBoard(FILES, 1))
		return;

	idx = Get_para_number(1);
	if (idx < 1)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	num = get_num_records(boarddirect, FH_SIZE);	/* get post count */
	t_num = get_trea_number();

	if (idx > num)
	{
		RespondProtocol(FILE_NOT_EXIST);
		return;
	}

	if (!in_board && strcmp(CurBList->owner, curuser.userid) &&
	    curuser.userlevel < 255)
	{
		RespondProtocol(KILL_NOT_ALLOW);
		return;
	}

	if (!can_post_board(CurBList))
	{
		RespondProtocol(KILL_NOT_ALLOW);
		return;
	}
	if (idx > t_num)	/* �R���G�i */
	{
		if ((fd = open(boarddirect, O_RDWR)) < 0)
		{
			RespondProtocol(WORK_ERROR);
			return;
		}

		if (lseek(fd, (long) (FH_SIZE * (idx - 1)), SEEK_SET) == -1)
		{
			RespondProtocol(WORK_ERROR);
			close(fd);
			return;
		}

		if (read(fd, &fileinfo, FH_SIZE) != FH_SIZE)
		{
			close(fd);
			RespondProtocol(WORK_ERROR);
			return;
		}
		close(fd);

		if (strcmp(fileinfo.owner, curuser.userid) &&
		    strcmp(CurBList->owner, curuser.userid) &&
		    curuser.userlevel < 255)
		{
			RespondProtocol(KILL_NOT_ALLOW);
			return;
		}

		if (fileinfo.accessed == FILE_DELE)
		{
			RespondProtocol(OK_CMD);
		/* while (read(0, temp_name, 1) > 0); */
			FormosaExit();
		}

		if (!del_one_article(idx, fileinfo, boarddirect, 'd', NA))
		{
			RespondProtocol(OK_CMD);
		}
		else
			RespondProtocol(WORK_ERROR);
	}
	else			/* �R���ؿ� */
	/*
	   if((fd = open(boarddirect, O_RDWR)) < 0) {
	   RespondProtocol(WORK_ERROR); return; } strcpy(temp_name,
	   boarddirect); strcat(temp_name, ".tmp"); if((ftemp =
	   open(temp_name, O_WRONLY|O_CREAT, 0644)) < 0) {
	   RespondProtocol(WORK_ERROR); return; } for (i = 1; i < idx; i++) {
	   read(fd, buf, FH_SIZE); write(ftemp, buf, FH_SIZE); } if (read(fd,
	   &fileinfo, FH_SIZE) != FH_SIZE) { RespondProtocol(WORK_ERROR);
	   close(fd); close(ftemp); return; } for (i = idx+1; i <= num; i++)
	   { read(fd, buf, FH_SIZE); write(ftemp, buf, FH_SIZE); } close(fd);
	   close(ftemp); rename(temp_name, boarddirect); strcpy(buf,
	   boarddirect); p = strrchr(buf, '/'); p = '\0'; sprintf(temp_name,
	   "%s%s", buf, fileinfo.filename); myunlink(temp_name);
	   RespondProtocol(OK_CMD); } /* while (read(0, temp_name, 1) > 0);
	*/
		FormosaExit();
}


/*****************************************************
 *  Syntax: FILEGET filenum filename [PATH level1 level2 ..]
 *****************************************************/
DoGetFile()
{
	int     idx, num, fd, t_num;
	char   *p, genbuf[STRLEN], type, *filename;
	struct fileheader fileinfo;


	if (!SelectBoard(FILES, 1))
		return;

	idx = Get_para_number(1);
	if (idx < 0)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	filename = Get_para_string(2);
	if (filename == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	num = get_num_records(boarddirect, FH_SIZE);	/* get post count */
	t_num = get_trea_number();

	if (idx > num)
	{
		RespondProtocol(FILE_NOT_EXIST);
		return;
	}

	if (idx <= t_num)
	{
		RespondProtocol(FILE_NOT_EXIST);
		return;
	}
	else
	{
		if ((fd = open(boarddirect, O_RDWR)) < 0)
		{
			RespondProtocol(WORK_ERROR);
			return;
		}

		if (lseek(fd, (long) (FH_SIZE * (idx - 1)), SEEK_SET) == -1)
		{
			RespondProtocol(WORK_ERROR);
			close(fd);
			return;
		}

		for (;;)
		{
			if (read(fd, &fileinfo, FH_SIZE) != FH_SIZE)
			{
				close(fd);
				RespondProtocol(WORK_ERROR);
				return;
			}
			if ((strcmp(filename, fileinfo.filename) != 0) &&
			    (strcmp(filename, "NONAME") != 0))
			{
				lseek(fd, -(sizeof(fileinfo) * 2), SEEK_CUR);
				continue;
			}
			else
				break;
		}
		if (fileinfo.accessed == FILE_DELE)
		{
			close(fd);
			RespondProtocol(POST_NOT_EXIST);
			return;
		}

		if (lseek(fd, -sizeof(fileinfo), SEEK_CUR) == -1)
		{
			close(fd);
			RespondProtocol(WORK_ERROR);
			return;
		}
		type = fileinfo.accessed;
		close(fd);

		strcpy(genbuf, boarddirect);
		p = rindex(genbuf, '/') + 1;
		strcpy(p, fileinfo.filename);
		SendFile(genbuf, type);
	}
}


/*****************************************************
 *      FILEPUT type filename title [PATH level1 lebel2 ..]
 *      �e�X�ɮ� ���O ��l�ɦW ����
 *
 *****************************************************/
DoFilePut()
{
	char   *title, *p;
	char    fname[STRLEN], path[PATHLEN], *buffer, backname[STRLEN];
	int     type, fd, num;
	struct ftpheader fullname;
	struct fileheader fh;

	if (curuser.userlevel < 50)
	{
		RespondProtocol(UPLOAD_NOT_ALLOW);
		return;
	}

	type = Get_para_number(1);
	if ((type != 0) && (type != 1))
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}
	if (!SelectBoard(FILES, 1))
		return;

	buffer = Get_para_string(2);
	if (buffer == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	title = Get_para_string(3);
	if (title == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	bzero(&fullname, sizeof(struct ftpheader));
	strcpy(fullname.ori_filename, buffer);
	sprintf(fname, "/tmp/%-s.%-d", curuser.userid, time(0));

	strcpy(path, boarddirect);
	p = strrchr(path, '/');
	*p = '\0';
	get_only_name2(path);

	p = strrchr(path, '/');
	inet_printf("%s\r\n", p + 1);


	if (RecvFile(fname, fullname, type) == 0)
	{
	/*
	   strcpy(path, boarddirect); p = strrchr(path, '/'); p = '\0';
	   get_only_name2(path);
	*/

		strcpy(backname, path);

		if (mycp(fname, path))
		{
			RespondProtocol(WORK_ERROR);
			return -1;
		}

		p = rindex(path, '/') + 1;
		bzero(&fh, sizeof(fh));
		fh.accessed = (type) ? FILE_OUT : FILE_IN;
		strcpy(fh.filename, p);
		strcpy(fh.owner, curuser.userid);
		strcpy(fh.title, title);
		fh.owner_ident = curuser.ident;

		strcpy(p, ".DIR");
		fd = open(path, O_WRONLY | O_CREAT | O_APPEND, 0644);
		strcpy(p, fh.filename);
		if (fd < 0)
		{
			unlink(path);
			RespondProtocol(WORK_ERROR);
			return -1;
		}

		flock(fd, LOCK_EX);
		write(fd, &fh, sizeof(fh));
		flock(fd, LOCK_UN);
		close(fd);

		unlink(fname);
		if (type)
			RespondProtocol(OK_CMD);
		num = get_num_records(boarddirect, FH_SIZE);	/* get post count */
		p = strrchr(backname, '/');
	/* inet_printf("%d\t%s\t%d\r\n", END_FILE, p+1, num); */
		FormosaExit();	/* ���ɧ����K�_�u */
	}
	else
		RespondProtocol(WORK_ERROR);

}

/***************************************************************
*       FILENUM [PATH level1 level2 .. ]
*        ��Ū�ɮװϼƥ�
****************************************************************/
DoGetFileNumber()
{
	int     num;

 /* char buf[1]; */

	if (!SelectBoard(FILES, 1))
		return;

	num = get_num_records(boarddirect, FH_SIZE);	/* get post count */

	inet_printf("%d\t%d\r\n", POST_NUM_IS, num);
	FormosaExit();
}

/*****************************************************
 *   Syntax: FILEHEAD startnum [endnum]
 *
 *  Respond: PostNum State Condition Owner Date Subject filesize
 *
 *****************************************************/
DoGetFileHead()
{
	int     start, end, num, fd, c, i;
	struct fileheader fileinfo;
	char    post_state, chdate[6], buffer[STRLEN], *p;
	time_t  date;
	struct stat fbuf;
	long    filesize;

	if (!SelectBoard(FILES, 1))
		return;

	start = Get_para_number(1);
	if (start < 1)
	{
		RespondProtocol(FILE_NOT_EXIST);
		return;
	}

	end = Get_para_number(2);
	if (end == 0)
		end = start;
	else if (end < start)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	num = get_num_records(boarddirect, FH_SIZE);	/* get post count */

	if (start > (num) || end > (num))
	{
		RespondProtocol(FILE_NOT_EXIST);
		return;
	}

	if ((fd = open(boarddirect, O_RDWR)) < 0)
	{			/* �}�ҧG�i�ϸ����.DIR */
		RespondProtocol(WORK_ERROR);
		return;
	}

	if (lseek(fd, (long) (FH_SIZE * (start - 1)), SEEK_SET) == -1)
	{
		RespondProtocol(WORK_ERROR);
		close(fd);
		return;
	}

	RespondProtocol(OK_CMD);
	net_cache_init();
	for (i = start; i <= end; i++)
	{
		if (read(fd, &fileinfo, FH_SIZE) == FH_SIZE)
		{
			filesize = 0;
			if (fileinfo.accessed == FILE_DELE)
				post_state = 'D';	/* deleted post */
			else if (fileinfo.accessed == FILE_TREA)
				post_state = 'T';
			else if (fileinfo.accessed == FILE_OUT)
				post_state = 'O';
			else if (fileinfo.accessed == FILE_IN)
				post_state = 'I';
			else
				post_state = 'N';	/* new post */

			if (post_state == 'T')
			{
				c = '0';
				strcpy(fileinfo.owner, "�m�ؿ��n");
				strcpy(chdate, "00/00");
			}
			else
			{
				strcpy(buffer, boarddirect);
				p = strrchr(buffer, '/');
				strcpy(p, fileinfo.filename);
				stat(buffer, &fbuf);
				filesize = fbuf.st_size - FTPSIZE;
				c = (curuser.ident == 7) ?
					fileinfo.owner_ident + '0' : '*';
				date = atol((fileinfo.filename) + 2);
				strftime(chdate, 6, "%m/%d", localtime(&date));
				if (post_state == 'D')
					strcpy(fileinfo.title, "");
			}

			sprintf(MyBuffer, "%d\t%c\t%c\t%s\t%s\t%s\t%ld\r\n",
				i, post_state, c, fileinfo.owner, chdate, fileinfo.title
				,filesize);
			net_cache_write(MyBuffer, strlen(MyBuffer));
		}
		else
			break;
	}
	close(fd);
	net_cache_write(".\r\n", 3);	/* end */
	net_cache_refresh();
	while (read(0, buffer, 1) > 0);
	FormosaExit();
}
