
#include "bbs.h"
#include "csbbs.h"


void
update_utmp()
{
	update_ulist(&uinfo);
}


void
update_umode(mode)
int     mode;
{
	uinfo.mode = mode;
	update_utmp();		/* lasehu */
}


/*******************************************************************
 *
 * �ˬd���� login
 *		�W�L����N�屼�@��
 *******************************************************************/
int
count_multi_login(uentp)
struct user_info *uentp;
{
	static int i = 0;

	if (uentp->uid != uinfo.uid)
		return;
	i++;
	if (uentp->pid != uinfo.pid && uentp->userid[0] != '\0')
	{
		multi++;
		if (multi > MULTILOGINS)
		{
			if (uentp->pid > 2)	/* lasehu */
			{
				kill(uentp->pid, SIGKILL);
				/* purge_utmp(uentp); */
			}
			multi--;
		}
	}
}


void
multi_user_check()
{
	if (apply_ulist(count_multi_login) == -1)
		return;
}
