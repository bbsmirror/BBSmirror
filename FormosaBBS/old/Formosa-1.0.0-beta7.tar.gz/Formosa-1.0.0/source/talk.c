#include "bbs.h"
#include "tsbbs.h"

#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>


#define P_INT	(20)		/* interval to check for page requency */

char    out_mesg[68];

struct word *talkwtop = NULL;

extern struct user_info *search_ulist();

void do_talk();

char *ModeType();


int
FriendLoadCache()		/* -ToDo- conver string compare to uid
				   compare */
{
	int     my_friend_num = 0;
	
#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return 0;
#endif

	if (friend_cache == NULL)
	{
		FILE   *fp;
		register int friend_no;
		register char *ptr;

		my_friend_num = GetNumFileLine(ufile_overrides);
		friend_cache = malloc_array(my_friend_num);
		if (friend_cache == NULL)
		{
			my_friend_num = 0;
			return 0;
		}

		if ((fp = fopen(ufile_overrides, "r")) != NULL)
		{
			friend_no = 0;
			while (friend_no++ < my_friend_num && fgets(genbuf, sizeof(genbuf), fp))
			{
				if ((ptr = strchr(genbuf, ' ')))
					*ptr = '\0';	/* lasehu */
				if ((ptr = strchr(genbuf, '\n')))
					*ptr = '\0';
				if (genbuf[0])
					add_array(friend_cache, genbuf, malloc_str);
			}
			fclose(fp);
		}
	}
	return my_friend_num;
}


int
MyFriend(whoasks)		/* -ToDo- convert string compare to uid
				   compare */
char   *whoasks;
{
#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return 0;
#endif

	FriendLoadCache();
	return cmp_array(friend_cache, whoasks, strcmp);
}


int
can_override(userid, whoasks)
char   *userid;
char   *whoasks;
{
	FILE   *fp;
	char   *ptr;

	sethomefile(genbuf, userid, UFNAME_OVERRIDES);
	if ((fp = fopen(genbuf, "r")) != NULL)
	{
		while (fgets(genbuf, sizeof(genbuf), fp))
		{
			if ((ptr = strchr(genbuf, ' ')) != NULL)	/* lasehu */
				*ptr = '\0';
			if ((ptr = strchr(genbuf, '\n')) != NULL)
				*ptr = '\0';
			if (!strcmp(genbuf, whoasks))
			{
				fclose(fp);
				return 1;
			}
		}
		fclose(fp);
	}
	return 0;
}


int
FriendDisplay()
{
	int     x = 0, y = 3, cnt = 0;

	FriendLoadCache();

	move(2, 0);
	clrtobot();
	while (cnt < friend_cache->number)
	{
		move(y, x);
		outs(friend_cache->datap[cnt]);
		if (++y == b_line)
		{
			y = 3;
			x = x + 16;
			if (x >= 80)
			{
				pressreturn();
				x = 0;
				move(y, x);
				clrtobot();
			}
		}
		cnt++;
	}
	if (cnt == 0)
	{
		move(y, x);
		outs("(�S�H)");
	}
	return cnt;
}


void
FriendAdd(ident)
char   *ident;
{
	FILE   *fp;

	if (ident == NULL || ident[0] == '\0')
		return;
	if (get_passwd(NULL, ident) <= 0)
		return;
	if (can_override(curuser.userid, ident))
		return;

	if ((fp = fopen(ufile_overrides, "a")) != NULL)
	{
		fprintf(fp, "%s\n", ident);
		fclose(fp);
		friend_cache = free_array(friend_cache);
	}
}


void
FriendDelete(ident)
char   *ident;
{
	FILE   *fp, *fpnew;
	char    fnnew[PATHLEN];
	int     delete = NA;
	char   *ptr;

	sprintf(fnnew, "tmp/%-s.overridse_new", curuser.userid);	/* lasehu ? */
	if ((fp = fopen(ufile_overrides, "r")) != NULL)
	{
		if ((fpnew = fopen(fnnew, "w")) != NULL)
		{
			while (fgets(genbuf, sizeof(genbuf), fp))
			{
				if ((ptr = strchr(genbuf, ' ')) != NULL)	/* lasehu */
					*ptr = '\0';
				if ((ptr = strchr(genbuf, '\n')) != NULL)
					*ptr = '\0';
				if (!strcmp(genbuf, ident))
					delete = YEA;
				else
					fprintf(fpnew, "%s\n", genbuf);
			}
			fclose(fpnew);
			if (delete)
			{
				if (mymv(fnnew, ufile_overrides) == 0)
				{
					friend_cache = free_array(friend_cache);
					return;
				}
			}
			unlink(fnnew);
		}
		fclose(fp);
	}
}


char   *
modestring(upent, complete)
USER_INFO *upent;
int     complete;
{
	static char modestr[40];
	register int mode = upent->mode;

	if (upent->chatid && upent->chatid[0])
	{
		if (complete)
			sprintf(modestr, "%s as '%s'", ModeType(mode), upent->chatid);
		else
			return (ModeType(mode));
		return (modestr);
	}
	if (mode != TALK && mode != PAGE && mode != QUERY)
		return (ModeType(mode));
/*---		
	else if (mode != QUERY && !HAS_PERM(PERM_CLOAK) && upent->invisible) 
*/
	else if (!HAS_PERM(PERM_CLOAK) && upent->invisible)
		return (ModeType(TMENU));
	if (complete && upent->destid[0])
		sprintf(modestr, "%s '%s'", ModeType(mode), upent->destid);
	else
		return (ModeType(mode));
	return (modestr);

}



int
listcuent(upent)		/* for list all online userid */
USER_INFO *upent;
{
	if (upent == NULL || upent->userid[0] == '\0')
		return -1;
	if (!strcmp(upent->userid, curuser.userid))
		return -1;
	if (!HAS_PERM(PERM_CLOAK) && upent->invisible)
		return -1;
	talkwtop = add_wlist(talkwtop, upent->userid, malloc_str);
	return 0;
}


int
t_pager()
{
	uinfo.pager = (uinfo.pager) ? NA : YEA;
	update_utmp();
	move(2, 0);
	clrtoeol();
	prints("�O�H%s��A�͸ܤF.", (uinfo.pager) ? "�i�H" : "���i");
	pressreturn();
	return M_FULL;
}


int
cmp_userid(userid, upent)
char   *userid;
USER_INFO *upent;
{
	if (upent == NULL || upent->userid[0] == '\0')
		return 0;
	if (userid == NULL || userid[0] == '\0')	/* debug */
		return 0;
	return (!strcmp(userid, upent->userid));
}


#if 0
int
cmp_uid(uid, upent)
unsigned int uid;
USER_INFO *upent;
{
#if 0
	if (!upent || !upent->active)
#endif
		if (!upent)
			return 0;
	return (uid == upent->uid);
}

#endif


int
QueryUser(ident)
char   *ident;
{
	FILE   *planfile;
	USEREC  lookup_userec;
	USER_INFO *lookup_uinfo;
	int     save_umode = uinfo.mode;

	if (ident == NULL || ident[0] == '\0')
		return -1;

	move(1, 0);
	clrtobot();

	if (get_passwd(&lookup_userec, ident) <= 0)
	{
		outs(_msg_err_userid);
		pressreturn();
		return -1;
	}
	strncpy(uinfo.destid, lookup_userec.userid, IDLEN);	/* lasehu */
	update_umode(QUERY);

	outs("�ӤH��Ƭd�ߡG\n");
	prints("%s (%s), ���� %d", lookup_userec.userid, lookup_userec.username, lookup_userec.userlevel);
#ifdef IDENT
	prints(", %s���������{�� [m", (lookup_userec.ident == 7) ? "[1;36m�w" : "[1;33m��");
#endif
	prints("\n�W�� %d ��, �i�K�L %d �g.\n", lookup_userec.numlogins, lookup_userec.numposts);
	prints("�W���ɶ� %s �Ӧ� %s",
	       (lookup_userec.lastlogin) ? Ctime(&(lookup_userec.lastlogin)) : "����",
	(lookup_userec.lasthost[0]) ? lookup_userec.lasthost : "(unknown)");
	prints("\n�q�l�l��H�c: %s \n", lookup_userec.email);
	move(6, 0);
	if (lookup_userec.flags[0] & FORWARD_FLAG)
		outs("---- �ӤH�H��۰���H�}��.");
	else if (check_newmail(lookup_userec.userid))
		outs("---- �H�c�����s�H���٨S��.");
	else
		outs("---- �H�c�����H�󳣬ݹL�F.");
	if ((lookup_uinfo = search_ulist(cmp_userid, lookup_userec.userid)))
		prints("  �u�W���A: %s. �I��a: %s", modestring(lookup_uinfo, 1), (lookup_uinfo->pager) ? "�}��" : "����");
	else
		outs("  �ثe���b�u�W. ");

	sethomefile(genbuf, lookup_userec.userid, UFNAME_PLANS);
	if ((planfile = fopen(genbuf, "r")) != NULL)
	{
		short   i = 0;

		outs("\n�W���ɤ��e:\n");
		while (++i <= MAX_QUERY_LINES && fgets(genbuf, sizeof(genbuf), planfile))
			outs(genbuf);
		fclose(planfile);
	}
	else
	{
		outs("\n�S���W����.");
	}
	pressreturn();
	uinfo.destid[0] = '\0';	/* lasehu */
	update_umode(save_umode);
	return 0;
}


int
t_query()
{
	char    userid[IDLEN + 1];

	move(2, 0);
	clrtoeol();
	outs("<�п�J�ϥΪ̥N��>");
	move(1, 0);
	clrtoeol();
	if (getdata(1, 0, "�n�d�߽� ? ", userid, sizeof(userid), ECHONOSP, NULL))
		QueryUser(userid);
	return M_FULL;
}


int
CompleteOnlineUser(data)
char   *data;
{
	if (ask_online_user() < 2)
		return -1;
	move(1, 0);
	clrtobot();
	move(2, 0);
	outs("<�п�J�^��N�W> (���ť���i��ܨùL�o�u�W�ϥΪ�)\n");
	move(1, 0);
	outs("��H�O: ");
	apply_ulist(listcuent);
	namecomplete(talkwtop, NULL, data);
	talkwtop = free_wlist(talkwtop, free);
	if (data[0] == '\0')
		return -1;
	return 0;
}


int
t_talk()
{
	char    userid[IDLEN + 1];
	struct user_info *talk_uinfo;

	if (CompleteOnlineUser(userid) == 0)
	{
		if (!(talk_uinfo = search_ulist(cmp_userid, userid)))
		{
			msg("��褣�b�u�W.");
			getkey();
		}
		else
			talk_user(talk_uinfo);	
	}
	return M_FULL;
}


int
talk_user(talk_uinfo)
USER_INFO *talk_uinfo;
{
#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return -1;
#endif

	if (talk_uinfo == NULL || talk_uinfo->userid[0] == '\0')
		return -1;

#ifdef GUEST_ACCOUNT
	if (!strcmp(talk_uinfo->userid, GUEST_ACCOUNT))
		return -1;
#endif

	if (!strcmp(talk_uinfo->userid, curuser.userid))
		return 0;
	
	if (!HAS_PERM(PERM_SYSOP) && !talk_uinfo->pager
	    && !can_override(talk_uinfo->userid, curuser.userid))
	{
		msg("��褣�Ʊ�Q���Z.");
		getkey();
		return -1;
	}
	if (is_in_outdoor(talk_uinfo))
	{
		msg("��西�B�󤣯౵���͸ܪ����A.");
		getkey();
		return -1;
	}
	else
	{
		int     sock, msgsock, length;
		struct sockaddr_in server;
		char    reponse;

		if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		{
			perror("opening stream socket\n");
			return -1;
		}
		server.sin_family = AF_INET;
		server.sin_addr.s_addr = INADDR_ANY;
		server.sin_port = 0;
		if (bind(sock, (struct sockaddr *) &server, sizeof server) < 0)
		{
			perror("binding stream socket");
			return -1;
		}
		length = sizeof server;
		if (getsockname(sock, (struct sockaddr *) &server, &length) < 0)
		{
			perror("getting socket name");
			return -1;
		}
		if (talk_uinfo->pid <= 2)	/* lasehu */
			return -1;
		uinfo.sockactive = YEA;		/* ? */
		uinfo.sockaddr = ntohs((u_short) server.sin_port);
		strncpy(uinfo.destid, talk_uinfo->userid, IDLEN);	/* lasehu */
		uinfo.mode = PAGE;
		update_utmp();
		if (talk_uinfo->pid <= 2)	/* lasehu */
		{
			uinfo.sockactive = NA;
			uinfo.destid[0] = '\0';
			uinfo.mode = TMENU;
			update_utmp();
			return -1;
		}
		else
			kill(talk_uinfo->pid, SIGUSR1);
		clear();
		prints("���b�� %s �n�a�o, �еy�ݤ���..\n�� CTRL-D �i�H���_\n", talk_uinfo->userid);
		listen(sock, 1);
		add_io(sock, 20);
		while (1)
		{
			int     ch;

			ch = igetch();
			if (ch == I_TIMEOUT)
			{
				move(0, 0);
				outs("�A�n�@���a.\n");
				bell();
				if (talk_uinfo->pid <= 2)	/* lasehu */
				{
					outs("���w���u.");
					pressreturn();
					return -1;
				}
				if (kill(talk_uinfo->pid, SIGUSR1) == -1)
				{
					outs("���w���u.");
					pressreturn();
					return -1;
				}
			}
			else if (ch == I_OTHERDATA)
				break;
			else if (ch == '\004')	/* CTRL-D */
			{
				add_io(0, 0);
				close(sock);
				uinfo.sockactive = NA;
				uinfo.destid[0] = '\0';		/* lasehu */
				update_utmp();
				return -1;
			}
		}
		if ((msgsock = accept(sock, (struct sockaddr *) 0, (int *) 0)) < 0)
		{
			perror("accept");
			return -1;
		}
		add_io(0, 0);
		close(sock);
		uinfo.sockactive = NA;
		read(msgsock, &reponse, sizeof reponse);
		if (reponse == 'y')
			do_talk(msgsock);
		else
		{
			outs("\n");
			do
			{
				read(msgsock, &reponse, sizeof(reponse));
				prints("%c", reponse);
			}
			while (reponse != '\n');
			pressreturn();
		}
		close(msgsock);
		uinfo.destid[0] = '\0';
		update_utmp();
	}
	return 0;
}


#if 0
int
cmp_destuid(unum, up)
register unsigned int unum;
register USER_INFO *up;
{
	return (up->active && unum == up->destuid);
}

#endif


int
cmp_destid(ident, up)
char   *ident;
register USER_INFO *up;
{
	if (up == NULL || up->userid[0] == '\0')
		return 0;
#if 0
	if (up->active <= 0)
		return 0;
#endif
	return (!strcmp(ident, up->destid));
}



USER_INFO ui;			/* partner's online info */
char    page_requestor[STRLEN];	/* partner's personal description */

int
#if 0
searchuserlist(unum)
unsigned int unum;

#endif
searchuserlist(ident)
char   *ident;
{
	register USER_INFO *up;

#if 0
	if ((up = search_ulist(cmp_destuid, unum)))
#endif
		if ((up = search_ulist(cmp_destid, ident)))
		{
			memcpy(&ui, up, sizeof(USER_INFO));
			return 1;
		}
	return 0;
}

setpagerequest()
{
#if 0
	USEREC  au;

	if (searchuserlist(curuser.uid) == 0)
#endif
		if (searchuserlist(curuser.userid) == 0)
			return 1;
	if (!ui.sockactive)
		return 1;
	strncpy(uinfo.destid, ui.userid, IDLEN);	/* lasehu */
#if 0
	uinfo.destuid = ui.uid;
	get_passwd(&au, ui.userid);
	strncpy(uinfo.destid, au.userid, sizeof(uinfo.destid));
	sprintf(page_requestor, "%s (%s)", au.userid, au.username);
#endif
	sprintf(page_requestor, "%s (%s)", ui.userid, ui.username);	/* lasehu */

	return 0;
}

int
servicepage(arg)
int     arg;
{
	static time_t last_check;
	time_t  now;
	char    buf[STRLEN];

#if 0
	if (searchuserlist(curuser.uid) == 0 || !ui.sockactive)
#endif
		if (searchuserlist(curuser.userid) == 0 || !ui.sockactive)
			talkrequest = NA;
	if (!talkrequest)
	{
		if (page_requestor[0])
		{
			switch (uinfo.mode)
			 {
			 case TALK:
				 move(arg, 0);
				 prints("-----------------------------------------------------------");		/* ?? */
				 prints("");
				 break;
			 default:	/* a chat mode */
				 sprintf(buf, "** INFO: no longer paged by %s", page_requestor);
				 printchatline(buf);
			 }
			memset(page_requestor, 0, sizeof(page_requestor));
			last_check = 0;
		}
		return NA;
	}
	else
	{
		now = time(0);
		if (now - last_check > P_INT)
		{
			last_check = now;
			if (!page_requestor[0] && setpagerequest())
				return NA;
			switch (uinfo.mode)
			 {
			 case TALK:
				 move(arg, 0);
				 prints("--- ** �T��: %s �Q��z���", page_requestor);
				 break;
			 default:	/* chat */
				 sprintf(buf, "** INFO: being paged by %s", page_requestor);
				 printchatline(buf);
			 }
		}
	}
	return YEA;
}


int
talkreply()
{
	int     a;
	int     ch;

	talkrequest = NA;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return -1;
#endif

	if (setpagerequest() != 0)
		return 0;
	do
	{
		clear();
		prints("�z�Q�P�Ӧ� %s �� %s ���� ?\n(Yes or No or Query) [Q]: ", ui.from, page_requestor);
		ch = igetkey();
		prints("%c", ch);
		if (ch != 'y' && ch != 'n')
			QueryUser(ui.userid);
		else
			break;
	}
	while (YEA);

	memset(page_requestor, 0, sizeof(page_requestor));

	if ((a = ConnectServer(MYHOSTIP, ui.sockaddr, TCP)) < 0)
	{
		perror("connect failed");
		pressreturn();
		return -1;
	}
	if (ch == 'y')		/* lasehu */
		write(a, "y", 1);
	else
		write(a, "n", 1);
	if (ch != 'y')
	{
		char   *talkrefuse[] =
		{
			"��p, �{�b������, ��ѦA��n�� ?",
			"��p, �ݷ|�A��z��, O.K ?",
			"��p, ���M�Y�H��Ѥ�....",
			"��p, �ڪ����r�t�פӺC, �ȧA�ε�....",
			"��p, �ڤ��ӳ��w TALK �� !!",
			"�䥦",
			NULL
		};
		char    buf[STRLEN];
		int     i, maxrefused;

		clear();
		for (i = 0; talkrefuse[i]; i++)
			prints("[%d] %s\n", i + 1, talkrefuse[i]);
		maxrefused = i;
		outs("�z�n�ڧi�D�L���z�ѬO[1]:");
		i = (igetch() - '0');
		if (i < 1 || i > maxrefused)
			i = 1;
		strcpy(buf, talkrefuse[i - 1]);
		if (i == maxrefused)
			getdata(maxrefused + 2, 0, "[�z���^��]: ", buf, sizeof(buf), DOECHO, NULL);
		strcat(buf, "\n");
		write(a, buf, strlen(buf));
	}
	else
		do_talk(a);
	close(a);
	return 0;
}


void
do_talk_char(sline, eline, curln, curcol, wordbuf, wordbuflen, ch)
int     sline, eline;
int    *curln, *curcol;
char   *wordbuf;
int    *wordbuflen;
int     ch;
{
#ifdef BIT8
	if (isprint3(ch))
#else
	if (isprint(ch))
#endif
	{
		if (*curcol != 79)
		{
			wordbuf[(*wordbuflen)++] = ch;
			if (ch == ' ')
				*wordbuflen = 0;
			move(*curln, (*curcol)++);
			prints("%c", ch);
			return;
		}
		if (ch == ' ' || *wordbuflen >= 78)
		{
			(*curln)++;
			*curcol = 0;
			if (*curln > eline)
				*curln = sline;
			if ((*curln) != eline)
			{
				move((*curln) + 1, 0);
				clrtoeol();
			}
			move(*curln, *curcol);
			clrtoeol();
			*wordbuflen = 0;
			return;
		}
		move(*curln, (*curcol) - *wordbuflen);
		clrtoeol();
		(*curln)++;
		*curcol = 0;
		if (*curln > eline)
			*curln = sline;
		if ((*curln) != eline)
		{
			move((*curln) + 1, 0);
			clrtoeol();
		}
		move(*curln, *curcol);
		clrtoeol();
		wordbuf[*wordbuflen] = '\0';
		if (dumb_term)
			prints("\n");
		prints("%s%c", wordbuf, ch);
		*curcol = (*wordbuflen) + 1;
		*wordbuflen = 0;
		return;
	}
	switch (ch)
	 {
	 case CTRL('H'):
	 case '\177':
		 if (dumb_term)
			 ochar(CTRL('H'));
		 if (*curcol == 0)
		 {
			 if (sline == 0)
				 bell();
			 return;
		 }
		 (*curcol)--;
		 move(*curln, *curcol);
		 if (!dumb_term)
			 prints(" ");
		 move(*curln, *curcol);
		 if (*wordbuflen)
			 (*wordbuflen)--;
		 return;
	 case CTRL('M'):
	 case CTRL('J'):
		 if (dumb_term)
			 prints("\n");
		 (*curln)++;
		 *curcol = 0;
		 if (*curln > eline)
			 *curln = sline;
		 if ((*curln) != eline)
		 {
			 move((*curln) + 1, 0);
			 clrtoeol();
		 }
		 move(*curln, *curcol);
		 clrtoeol();
		 *wordbuflen = 0;
		 return;
	 case CTRL('G'):
		 bell();
		 return;
#if 0
	 case CTRL('X'):	/* smile */
	 case CTRL('Y'):	/* cry */
	 case CTRL('Z'):	/* angry */
#endif
	 default:

		 break;
	 }
}


void
do_talk_string(sline, eline, curln, curcol, wordbuf, wordbuflen, s)
int     sline, eline;
int    *curln, *curcol;
char   *wordbuf;
int    *wordbuflen;
char   *s;
{
	while (*s)
	{
		do_talk_char(sline, eline, curln, curcol, wordbuf, wordbuflen, *s);
		s++;
	}
}


unsigned char talkobuf[80];
unsigned int talkobuflen;
int     talkflushfd;

talkflush()
{
	if (talkobuflen)
		write(talkflushfd, talkobuf, talkobuflen);
	talkobuflen = 0;
}


void
do_talk(fd)
int     fd;
{
	USEREC  user;
	int     myln, mycol, myfirstln, mylastln;
	int     itsln, itscol, itsfirstln, itslastln;
	char    itswordbuf[80], mywordbuf[80];
	int     itswordbuflen, mywordbuflen;
	int     page_pending = NA;

	itswordbuflen = 0;
	mywordbuflen = 0;
	talkobuflen = 0;
	talkflushfd = fd;

	update_umode(TALK);

	get_passwd(&user, uinfo.destid);

	clear();
	myfirstln = 0;
	mylastln = (b_line / 2) - 1;
	move(mylastln + 1, 0);
	prints("[7m<<< �ͤ߶��� >>> �� %s and �� %s (%-20.20s)[m",
	       curuser.userid, user.userid, user.username);
	itsfirstln = mylastln + 2;
	itslastln = (t_lines - 1);
	myln = myfirstln;
	mycol = 0;
	itsln = itsfirstln;
	itscol = 0;
	move(myln, mycol);
	add_io(fd, 0);
	add_flush(talkflush);
	while (1)
	{
		int     ch;

		if (talkrequest)
			page_pending = YEA;
		if (page_pending)
			page_pending = servicepage(mylastln + 1);
		if (writerequest)	/* lasehu */
		{
			int     x, y;

			getyx(&y, &x);
			writereply();
			move(mylastln + 1, 0);
			prints("[7m<<< �ͤ߶��� >>> �� %s and �� %s (%-20.20s)[m",
			       curuser.userid, user.userid, user.username);
			move(y, x);
			continue;
		}
		ch = igetch();
		if (ch == I_OTHERDATA)
		{
			char    data[80];
			int     datac;
			register int i;

			datac = read(fd, data, 80);
			if (datac <= 0)
			{
#if 0
				strcpy(data, "���w���������͸�.");
				i = strlen(data) - 1;
				for (i = 0; i < datac; i++)
					do_talk_char(itsfirstln, itslastln, &itsln, &itscol, itswordbuf,
						   &itswordbuflen, data[i]);
#endif
				break;
			}
			for (i = 0; i < datac; i++)
				do_talk_char(itsfirstln, itslastln, &itsln, &itscol, itswordbuf,
					     &itswordbuflen, data[i]);
		}
		else
		{
			if (ch == CTRL('D') || ch == CTRL('C'))
			{
				int     x, y;

				getyx(&y, &x);
				move(mylastln + 1, 0);
				outs("�z�T�w�n�����͸ܶ� (y/n) ? [N]: ");
				clrtoeol();
				if (igetkey() == 'y')
					break;
				move(mylastln + 1, 0);
				prints("[7m<<< �ͤ߶��� >>> �� %s and �� %s (%-20.20s)[m",
				curuser.userid, user.userid, user.username);
				move(y, x);
			}
			else if (isprint3(ch) || ch == CTRL('H') || ch == '\177' || ch == CTRL('G')
			     || ch == '\n' || ch == '\r' || ch == CTRL('M'))
			{
				talkobuf[talkobuflen++] = ch;
				if (talkobuflen >= 80)
					talkflush();
				do_talk_char(myfirstln, mylastln, &myln, &mycol, mywordbuf,
					     &mywordbuflen, ch);
			}
			else if (ch == CTRL('P'))
			{
				if (uinfo.pager == YEA)
				{
					do_talk_string(myfirstln, mylastln, &myln, &mycol, mywordbuf, &mywordbuflen, "*** Pager turned off ***\n");
					uinfo.pager = NA;
				}
				else
				{
					do_talk_string(myfirstln, mylastln, &myln, &mycol, mywordbuf, &mywordbuflen, "*** Pager turned on ***\n");
					uinfo.pager = YEA;
				}
				update_utmp();
			}
			else if (ch == CTRL('R'))
			{
				int     y, x;

				getyx(&y, &x);
				ReplyLastCall();
				move(mylastln + 1, 0);
				prints("[7m<<< �ͤ߶��� >>> �� %s and �� %s (%-20.20s)[m",
				curuser.userid, user.userid, user.username);
				move(y, x);
			}
#if 0
			else if (ch == CTRL('X') || ch == CTRL('Y') || ch == CTRL('Z'))
			{
				switch (ch)
				 {
					 case
				 }
				talkobuf[talkobuflen++] = ch;
				if (talkobuflen >= 80)
					talkflush();
				do_talk_char(myfirstln, mylastln, &myln, &mycol, mywordbuf,
					     &mywordbuflen, ch);
			}
#endif
			else
				bell();
		}
	}
	add_io(0, 0);
	talkflush();
	add_flush(NULL);
}


int
t_irc()
{
	sprintf(genbuf, "ircc %s %s %d",
		curuser.userid, curuser.lasthost, two_enter);
	outdoor(genbuf, IRCCHAT, YEA);	/* ? */

	return M_FULL;
}


#ifdef USE_LOCALIRC
int
t_ircl()
{
	sprintf(genbuf, "ircl %s %s %d chat5",
		curuser.userid, curuser.lasthost, two_enter);
	outdoor(genbuf, LOCALIRC, YEA);		/* ? */

	return M_FULL;
}

#endif


int
MessageUser(upent)
USER_INFO *upent;
{
	char    buf[80];
	FILE   *fp;
	struct stat st;
	time_t  now = time(0);
	short   lines = 0;
	char    timestr[8];

	if (upent->userid == NULL || upent->userid[0] == '\0')
		return -1;
#ifdef GUEST_ACCOUNT
	if (!strcmp(upent->userid, GUEST_ACCOUNT))
		return -1;
#endif	

	setuserfile(buf, upent->userid, UFNAME_WRITE);
	if (stat(buf, &st) == 0)
	{
		lines = 1;
		if (st.st_mtime < now - 86400)	/* lasehu */
		{
#ifdef DEBUG
			prints("\nunlink [%s]", buf);
			getkey();
#endif
			unlink(buf);
		}
	}
	if ((fp = fopen(buf, "a+")) == NULL)
		return -1;

	strncpy(uinfo.destid, upent->userid, sizeof(uinfo.destid) - 1);		/* lasehu */
	update_utmp();		/* lasehu */
	if (lines)		/* lasehu */
		fprintf(fp, "\n");
	strftime(timestr, 6, "%R", localtime(&now));
	fprintf(fp, "%s\t%s\t%s\t%s\t",
		curuser.userid, (curuser.username[0]) ? curuser.username : " ", out_mesg, timestr);
	fclose(fp);
	if (upent->pid > 2)	/* lasehu */
		kill(upent->pid, SIGUSR2);
	uinfo.destid[0] = '\0';	/* lasehu */
	update_utmp();
	return 0;
}


char    LastCaller[IDLEN + 1] = "\0";


int
ParseMesgStr(string, fillinstr)
char   *string, *fillinstr;
{
	char   *timestr, *id, *name, *ReadedMesg, *ptr;
	char    format[80], SpaceFormat[80];
	unsigned int     avail_len;

	if ((id = strtok(string, "\t")) == NULL)
		return -1;
	if ((name = strtok(NULL, "\t")) == NULL)
		return -1;
	if ((ReadedMesg = strtok(NULL, "\t")) == NULL)
		return -1;
	if ((timestr = strtok(NULL, "\t")) == NULL)
		return -1;
	if ((ptr = strchr(timestr, '\n')))
		*ptr = '\0';
	strncpy(LastCaller, id, IDLEN);

	avail_len = 75 - strlen(timestr) - strlen(id) - MIN(UNAMELEN - 1, strlen(name));
	sprintf(format, "[1;37;45m%%s [33m%%s(%%.%ds):[36m %%.%ds",
		UNAMELEN - 1, avail_len);

	if (strlen(ReadedMesg) < avail_len)
	{
		sprintf(SpaceFormat, "%%%ds[m", avail_len - strlen(ReadedMesg));
		strcat(format, SpaceFormat);
	}
	else
		strcat(format, "[m");

	sprintf(fillinstr, format, timestr, id, name, ReadedMesg, "\0");
	return 0;
}


int
PrepareMesgContent()
{
	if (ask_online_user() < 2)
		return -1;
	if (getdata(b_line, 0, "�T�����e�O: ", out_mesg, sizeof(out_mesg), DOECHO, NULL))
	{
		msg("�T�w�n�e�X�T���� (y/n) ? [y]: ");
		if (igetkey() != 'n')
			return 0;
	}
	msg(_msg_abort);
	getkey();
	return -1;
}


int
SendMesgToSomeone(ident)
char   *ident;
{
	USER_INFO *lookup_uinfo;

#ifdef GUEST_ACCOUNT
	if (!strcmp(ident, GUEST_ACCOUNT))
	{
		msg("���[�αb���������e�T��.");
		getkey();
		return -1;
	}
#endif
	if (!strcmp(ident, curuser.userid))
	{
		msg("�����H�ۤv�e�T�����ۤv��.");
		getkey();
		return -1;
	}

	if (!(lookup_uinfo = search_ulist(cmp_userid, ident))
	    || (!HAS_PERM(PERM_CLOAK) && lookup_uinfo->invisible))
	{
		msg("���H���b�u�W.");
		getkey();
		return -1;
	}
	if (!HAS_PERM(PERM_SYSOP) && !lookup_uinfo->pager &&
	    !can_override(lookup_uinfo->userid, curuser.userid))
	{
		msg("��褣�Ʊ�Q���Z.");
		getkey();
		return -1;
	}
	if (is_in_outdoor(lookup_uinfo))
	{
		msg("��西�B�󤣯౵���e�T�������A.");
		getkey();
		return -1;
	}

	if (MessageUser(lookup_uinfo) == -1)
	{
		msg("�e�X�T������.");
		getkey();
		return -1;
	}
	msg("�e�X�T������.");
	getkey();
	return 0;
}


int
ReplyLastCall()			/* lasehu */
{
	FILE   *fp;
	int     my_newfd;	/* lasehu */

	extern int i_newfd;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return -1;
#endif

	my_newfd = i_newfd;
	i_newfd = 0;

	if ((fp = fopen(ufile_write, "r")) != NULL)
	{
		char    LastReadedMesg[128], ShowedMesg[128];

		while (fgets(LastReadedMesg, sizeof(LastReadedMesg), fp))
		       /* NULL STATEMENT */ ;
		fclose(fp);
		if (ParseMesgStr(LastReadedMesg, ShowedMesg) == 0)
		{
			msg(ShowedMesg);
			move(b_line - 1, 0);
			clrtoeol();
			outs("�H�U�O�̪�@���Ҧ���T��, �{�b�n�^�� (y/n) ? [n]: ");
			if (igetkey() == 'y')
			{
				if (PrepareMesgContent() == 0)
					SendMesgToSomeone(LastCaller);
			}
			i_newfd = my_newfd;
			return 0;
		}
	}
	i_newfd = my_newfd;
	msg("-�|���������T��-");
	getkey();
	return 0;
}


int
writereply()			/* lasehu */
{
	FILE   *fp;
	int     my_newfd;	/* lasehu */

	extern int i_newfd;

	writerequest = NA;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return -1;
#endif

	my_newfd = i_newfd;
	i_newfd = 0;

	if ((fp = fopen(ufile_write, "r")) != NULL)
	{
		char    new_message[128], show_message[128];
		int     ch;

		while (fgets(new_message, sizeof(new_message), fp))
		       /* NULL STATEMENT */ ;
		fclose(fp);
		if (ParseMesgStr(new_message, show_message) == 0)
		{
#if 0
			unlink(ufile_write);
#endif
			msg(show_message);
			move(b_line - 1, 0);	/* avoid screen scroll */
			clrtoeol();
			outs("�� [Ctrl]+[R] �i�^�T��, �Ϋ� ENTER ���^.");
			warn_bell();
			while ((ch = getkey()) != EOF)
			{
				if (ch == CTRL('R'))
				{
					if (PrepareMesgContent() == 0)
						SendMesgToSomeone(LastCaller);
					break;
				}
				else if (ch == '\r' || ch == '\n')
					break;
			}
		}
	}
	i_newfd = my_newfd;	/* lasehu */
	return 0;
}


int
t_review()
{
	FILE   *fp;
	int     lines = 0;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return M_FULL;
#endif
	clear();
	outs("[7m  �����W�u�z�Ҧ��쪺�Ҧ��T��:  [m\n");
	if ((fp = fopen(ufile_write, "r")) != NULL)
	{
		char    one_message[STRLEN + 40], show_message[STRLEN + 60];

		while (fgets(one_message, sizeof(one_message), fp))
		{
			if (ParseMesgStr(one_message, show_message) == 0)
			{
				if (lines == b_line)
				{
					lines = 0;
					standout();
					outs("--�٦��@-- �Ы����N��½�U��");
					standend();
					getkey();
					move(1, 0);
					clrtobot();
				}
				lines++;
				prints("%s\n", show_message);
			}
		}
		fclose(fp);
	}
	if (lines == 0)
		outs("-�|���������T��-");
	pressreturn();
	return M_FULL;
}


int
t_message()
{
	char    userid[IDLEN + 1];

	if (CompleteOnlineUser(userid) == 0)
	{
		if (PrepareMesgContent() == 0)
			SendMesgToSomeone(userid);
	}
	return M_FULL;
}


#ifdef HAVE_FRIEND_BROADCAST
int
BroadcastFriend(upent)
USER_INFO *upent;
{
	if (!upent || upent->userid[0] == '\0')
		return -1;
#ifdef GUEST_ACCOUNT
	if (!strcmp(upent->userid, GUEST_ACCOUNT))
		return -1;
#endif
	if (!strcmp(upent->userid, curuser.userid))
		return -1;

	if (!HAS_PERM(PERM_CLOAK) && upent->invisible)
		return -1;
	if (!HAS_PERM(PERM_SYSOP) && !upent->pager
	    && !can_override(upent->userid, curuser.userid))
	{
		return -1;
	}
	if (is_in_outdoor(upent))
		return -1;

	if (MyFriend(upent->userid))
		MessageUser(upent);
	return 0;
}


int
t_fsendmsg()
{
	if (PrepareMesgContent() == 0)
	{
		apply_ulist(BroadcastFriend);
		msg("�T���w�e�X");
		getkey();
	}
	return M_FULL;
}

#endif

