
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>


#ifndef LOCK_EX
#define LOCK_EX        F_LOCK	/* exclusive lock */
#define LOCK_UN        F_ULOCK	/* unlock */
#endif

#ifndef MAXPATHLEN
#define MAXPATHLEN	256
#endif


/*******************************************************************
 * ����w���� write function, �����n���^�g�i�ϥΤ�.
 *******************************************************************/
safewrite(fd, buf, size)
int     fd;
char   *buf;
int     size;
{

#if 0
	int     cc, sz = size;
	char   *bp = buf;

	do
	{
		cc = write(fd, bp, sz);
		if ((cc <= 0) && (errno != EINTR))
			return -1;
		else if (cc == sz)
			sz = 0;
		else
		{
			bp += cc;
			sz -= cc;
		}
	}
	while (sz > 0);
	return size;
#endif

	return write(fd, buf, size);

}


/*******************************************************************
 * �ǤJ "�ɦW" �P record length,
 * �Ǧ^���ɤ��@���X�� records.
 *******************************************************************/
long
get_num_records(filename, size)
char    filename[];
int     size;
{
	struct stat st;

	if (stat(filename, &st) == -1)
		return 0;
	return (st.st_size / size);
}


/*******************************************************************
 * �ǤJ "�ɦW" , record �P record length,
 * �N�� record ���[���ɧ�.
 *******************************************************************/
append_record(filename, record, size)
char    filename[];
char   *record;
int     size;
{
	int     fd;

	if ((fd = open(filename, O_WRONLY | O_CREAT, 0644)) > 0)
	{
		flock(fd, LOCK_EX);
		if (lseek(fd, 0, SEEK_END) != -1)
		{
			if (safewrite(fd, record, size) != -1)
			{
				flock(fd, LOCK_UN);
				close(fd);
				return 0;
			}
		}
		flock(fd, LOCK_UN);
		close(fd);
	}
	return -1;
}




/*******************************************************************
 * �ǤJ "�ɦW", buf record, record length, record number(�ĴX��)
 * Ū�X�ɤ��� id �� record �� rptr buffer
 *******************************************************************/
get_record(filename, rptr, size, id)
char   *filename;
char   *rptr;
int     size;
unsigned int id;
{
	int     fd;

	if ((fd = open(filename, O_RDONLY, 0)) > 0)
	{
		if (lseek(fd, (off_t) ((id - 1) * size), SEEK_SET) != -1)
		{
			if (read(fd, rptr, size) == size)
			{
				close(fd);
				return 0;
			}
		}
		close(fd);
	}
	return -1;
}


/*******************************************************************
 * �ǤJ "�ɦW", record length, �ĴX��.
 * �R�����ɲ� id �� record.
 *******************************************************************/
delete_record(filename, size, id)
char   *filename;
int     size;
unsigned int id;
{
	int     fdr, fdw, fd;
	unsigned int     count;
	char    fn_lock[MAXPATHLEN], fn_new[MAXPATHLEN], fn_old[MAXPATHLEN];
	char    gbuffer[16384];

	if (size > sizeof(gbuffer))
	{
		bbslog("ERROR", "delete_record(): size too big in [%s]", filename);
		return -1;
	}

	sprintf(fn_lock, "%s.lock", filename);
	sprintf(fn_new, "%s.new", filename);
	sprintf(fn_old, "%s.old", filename);
#if 0
	tempfile(fn_new);
	tempfile(fn_old);
#endif
	if ((fd = open(fn_lock, O_WRONLY | O_CREAT, 0644)) == -1)
		return -1;
	if ((fdr = open(filename, O_RDONLY)) == -1)
	{
		close(fd);
		return -1;
	}
	if ((fdw = open(fn_new, O_WRONLY | O_CREAT | O_TRUNC, 0644)) == -1)
	{
		close(fd);
		close(fdr);
		return -1;
	}

	flock(fd, LOCK_EX);
	for (count = 1; read(fdr, gbuffer, size) == size; count++)
	{
		if (count == id)
			continue;
		if (safewrite(fdw, gbuffer, size) == -1)
		{
			close(fdr);
			close(fdw);
#if 0
			unlink(fn_new);
#endif
			flock(fd, LOCK_UN);
			close(fd);
			return -1;
		}
	}
	close(fdr);
	close(fdw);
	if (rename(filename, fn_old) == 0)
	{
		if (rename(fn_new, filename) == 0)
		{
			unlink(fn_old);
			flock(fd, LOCK_UN);
			close(fd);
			return 0;
		}
		rename(fn_old, filename);
	}
	unlink(fn_new);
	flock(fd, LOCK_UN);
	close(fd);
	return -1;
}


/*******************************************************************
 * �ǤJ "�ɦW", record, record length, �ĴX��.
 * �N�ǤJ�� record �g�J��� id �� record.
 *******************************************************************/
substitute_record(filename, rptr, size, id)
char   *filename;
char   *rptr;
int     size;
unsigned int id;
{
	int     fd;

#if 0
	if ((fd = open(filename, O_WRONLY | O_CREAT, 0644)) > 0)
#endif
		if ((fd = open(filename, O_WRONLY)) > 0)
		{
			if (lseek(fd, (off_t) ((id - 1) * size), SEEK_SET) != -1)
			{
				if (safewrite(fd, rptr, size) == size)
				{
					close(fd);
					return 0;
				}
			}
			close(fd);
		}
	return -1;
}



#if 0

char    gbuffer[16384];		/* general buffer for record.c */

/*******************************************************************
 * �ǤJ "�ɦW" , process function,  �P record length,
 * Ū�X�ɤ��C�@�� record,
 * �åB��C�@�� record �e�� process function �B�z.
 *******************************************************************/
apply_record(filename, fptr, size)
char   *filename;
int     (*fptr) ();
int     size;
{
	int     fd;

	if (size > sizeof(gbuffer))
	{
#if 0
		bbslog("ERROR", "apply_record(): size too big in [%s]", filename);
#endif
		return -1;
	}

	if ((fd = open(filename, O_RDONLY)) < 0)
		return -1;
	while (read(fd, gbuffer, size) == size)
	{
		if ((*fptr) (gbuffer) == QUIT_LOOP)
		{
			close(fd);
			return QUIT_LOOP;
		}
	}
	close(fd);
	return 0;
}


/*******************************************************************
 * �ǤJ "�ɦW", buf record, record length, process function, ����.
 * Ū�X�ɤ��C�@�� record,
 * �åB��C�@�� record �e�� process function ����Ȱ����, �Ψӷj�M
 *******************************************************************/
search_record(filename, rptr, size, fptr, farg)
char   *filename;
char   *rptr;
int     size;
int     (*fptr) ();
unsigned int farg;
{
	int     fd, id;

	if ((fd = open(filename, O_RDONLY, 0)) > 0)
	{
		for (id = 1; read(fd, rptr, size) == size; id++)
		{
			if ((*fptr) (farg, rptr))
			{
				close(fd);
				return id;
			}
		}
		close(fd);
	}
	return 0;
}


/*******************************************************************
 * �u�R���� ent �� record, ent ���᪺ records �H shift �覡�ɤW
 *******************************************************************/
delete_file(dirname, size, ent, filecheck, ckname)
char   *dirname;
int     size, ent;
int     (*filecheck) ();
{
	int     fd;
	struct stat st;
	long    numents;

	if (size > sizeof(gbuffer))
	{
		bbslog("ERROR", "delete_file(): size too big in [%s]", dirname);
		return -1;
	}

	if ((fd = open(dirname, O_RDWR)) == -1)
		return -1;

	flock(fd, LOCK_EX);
	fstat(fd, &st);
	numents = ((long) st.st_size) / size;
	if (st.st_size % size)
	{
		bbslog("ERROR", "align err: %s", dirname);
		flock(fd, LOCK_UN);
		close(fd);
		return -1;
	}

	if (lseek(fd, (off_t) ((ent - 1) * size), SEEK_SET) != -1)
	{
		if (read(fd, gbuffer, size) == size)
			if ((*filecheck) (gbuffer, ckname))
			{
				int     i;

				for (i = ent; i < numents; i++)
				{
					if (lseek(fd, (off_t) ((i + 1) * size), SEEK_SET) == -1)
						break;
					if (read(fd, gbuffer, size) != size)
						break;
					if (lseek(fd, -((off_t) (2 * size)), SEEK_CUR) == -1)
						break;
					if (safewrite(fd, gbuffer, size) != size)
						break;
				}
				ftruncate(fd, size * (numents - 1));
				flock(fd, LOCK_UN);
				close(fd);
				return 0;
			}
	}


#if 0
	lseek(fd, 0, SEEK_SET);

	for (ent = 1; read(fd, gbuffer, size) == size; ent++)
	{
		if ((*filecheck) (gbuffer, ckname))
		{
			int     i;

			flock(fd, LOCK_EX);
			for (i = ent; i < numents; i++)
			{
				if (lseek(fd, (off_t) ((i + 1) * size), SEEK_SET) == -1)
					break;
				if (read(fd, gbuffer, size) != size)
					break;
				if (lseek(fd, -((off_t) (2 * size)), SEEK_CUR) == -1)
					break;
				if (safewrite(fd, gbuffer, size) != size)
					break;
			}
			ftruncate(fd, size * (numents - 1));
			flock(fd, LOCK_UN);
			close(fd);
			return 0;
		}
	}
#endif

	flock(fd, LOCK_UN);
	close(fd);
	return -1;
}

#endif
