
/* FormosaBBS 1.0.0 */

#include <stdio.h>
#include <sys/fcntl.h>
#include <unistd.h>
#include "config.h"
#include "struct.h"


extern char *genpasswd();


int
main(argc, argv)
int     argc;
char   *argv[];
{
	struct userec urec;
	struct useridx uidx;
	int     fd, fdidx;
	char    buf[80];
	char    userid[80], username[80], password[80], path[80], 
	        fullpath[80], idxpath[80];
	unsigned int uid, userlevel;

	if (argc < 6)
	{
		fprintf(stderr, "Usage: %s <userid> <username> <uid> <password> <userlevel>\n", argv[0]);
		return 2;
	}

	strcpy(userid, argv[1]);
	strcpy(username, argv[2]);
	uid = atoi(argv[3]);
	strcpy(password, argv[4]);
	userlevel = atoi(argv[5]);

	sethomefile(path, userid, "\0");
	sprintf(fullpath, "%s/%s", HOMEBBS, path);
	if (!dashd(fullpath))
	{
		if (mkdir(fullpath, 0700) == -1)
		{
			fprintf(stderr, "cannot mkdir: %s", fullpath);
			return -2;
		}
		chown(fullpath, BBS_UID, BBS_GID);
	}

	sethomefile(path, userid, UFNAME_PASSWDS);
	sprintf(fullpath, "%s/%s", HOMEBBS, path);
	if ((fd = open(fullpath, O_WRONLY | O_CREAT | O_TRUNC, 0600)) < 0)
	{
		perror(argv[0]);
		return 1;
	}

	sprintf(idxpath, "%s/%s", HOMEBBS, USERIDX);
	if ((fdidx = open(idxpath,O_WRONLY | O_CREAT, 0600)) < 0)
	{
		perror(argv[0]);
		return 1;
	}
	if (lseek(fdidx, (uid - 1) * sizeof(uidx), SEEK_SET) == -1)
	{
		perror(argv[0]);
		return 1;
	}


	memset(&urec, 0, sizeof(urec));

	urec.uid = uid;
/*
   #ifdef IDENG
   urec.ident = 7;
   #endif            
 */
	strcpy(urec.userid, userid);
	strcpy(buf, genpasswd(userid));
	strncpy(urec.passwd, buf, PASSLEN);
	strcpy(urec.username, username);
/*---    
    strcpy(urec.termtype, "vt100");
*/
	urec.userlevel = userlevel;
	urec.firstlogin = time(0);

	write(fd, &urec, sizeof(urec));
	close(fd);
	
	memset(&uidx, 0, sizeof(uidx));
	strncpy(uidx.userid, urec.userid, sizeof(uidx.userid) - 1);
	write(fdidx, &uidx, sizeof(uidx));
	close(fdidx);

	chown(fullpath, BBS_UID, BBS_GID);
	chown(idxpath, BBS_UID, BBS_GID);	

	return 0;
}
