
#include "bbs.h"
#include "tsbbs.h"


extern struct commands MainMenu[];
extern struct commands ClassMenu[];

#ifdef USE_VOTE
extern struct commands VoteMenu[];
extern struct commands VoteAdminMenu[];

#endif


/*******************************************************************
 * Admin Menu
 *******************************************************************/
#ifndef CSBBS
extern int a_info(), a_newbrd(), a_delbrd(), a_modifybrd(), a_welcome(),
        a_bbsnews(), a_cloak(), a_kick(), a_pack1brd(), Users();

#ifdef HAVE_DELONEUSER
extern int a_deloneuser();

#endif

extern int a_broadcast();

#if	defined(IDENT)
extern int a_check(), a_find(), a_chgpgp();

#endif

struct commands AdminMenu[] =
{

 'i', 255, NULL, a_info, ADMIN, "([1;36mi[m) User Info", "���ϥΪ̸��",

#ifdef HAVE_DELONEUSER
	'd', 255, NULL, a_deloneuser, ADMIN, "([1;36md[m) Delete User", "�R���@��ϥΪ�",
#endif

   'n', 255, NULL, a_newbrd, ADMIN, "([1;36mn[m) New Board", "�إ߷s�ݪO",
  'b', 255, NULL, a_delbrd, ADMIN, "([1;36mb[m) Board Delete", "�R���ݪO",
	'm', 255, NULL, a_modifybrd, ADMIN, "([1;36mm[m) Modify Board", "���ݪO�]�w",
	'1', 255, NULL, a_pack1brd, ADMIN, "([1;36m1[m) Pack One Boards", "����S�w�G�i��",
	'w', 255, NULL, a_welcome, ADMIN, "([1;36mw[m) Welcome Edit", "�s���w��e��",
	'c', 255, NULL, a_bbsnews, ADMIN, "([1;36mc[m) Config BBS-News", "�s�� BBS-News ��H�]�w��",
	'o', 255, NULL, a_cloak, ADMIN, "([1;36mo[m) Cloak", "����",
	'u', 255, NULL, Users, LAUSERS, "([1;36mu[m) List All Users", "�C�X�Ҧ��ϥΪ�",
'k', 255, NULL, a_kick, ADMIN, "([1;36mk[m) Kick User", "�N�u�W�ϥΪ��_�u",
'a', 255, NULL, a_broadcast, SENDMSG, "([1;36ma[m) BroadCast", "�����s��",

#if	defined(IDENT)
	'p', 255, NULL, a_chgpgp, ADMIN, "([1;36mp[m) Modify Key", "���{�� Secure Key",
	'f', 255, NULL, a_find, ADMIN, "([1;36mf[m) Show Real Data", "�˵��ϥΪ̯u����",
	't', 255, NULL, a_check, ADMIN, "([1;36mt[m) Set ID Check", "�d�ݨϥΪ̻{�ҥӽ�",
#endif

	'a', 255, MainMenu, NULL, ADMIN, "Admin Menu", "�޲z�̿줽��",
	0, 255, NULL, NULL, 0, NULL, NULL

};


/*******************************************************************
 * Xyz Menu
 *******************************************************************/
extern int x_info(), x_override(), x_signature(), x_plan(), x_ircrc(),
        x_date(), Switch_scr(), t_pager();
extern int Announce();

#ifdef USE_BBSNET
extern int BBSNet();
#endif

#ifdef IDENT
extern int CheckID();

#endif
#if defined(PICTURE_MENU)
extern int x_picture();

#endif

struct commands XyzMenu[] =
{
#ifdef USE_BBSNET
	'b', 1, NULL, BBSNet, 0, "([1;36mb[m) BBS Net", "BBS Net",
#endif	
	'd', 1, NULL, x_info, 0, "([1;36md[m) Personal Data", "��ܻP�ק�ӤH�򥻸��",
	'p', 1, NULL, t_pager, PAGE, "([1;36mp[m) Pager Switch", "���}/������ѩI��a",
	'o', 1, NULL, x_override, OVERRIDE, "([1;36mo[m) Override Edit", "�s��n�B�ͦW��",
	's', 1, NULL, x_signature, EDITSIG, "([1;36ms[m) Signature Edit", "�s��ñ�W��",
    'n', 1, NULL, x_plan, EDITPLAN, "([1;36mn[m) Plan Edit", "�s��W����",
 'i', 1, NULL, x_ircrc, 0, "([1;36mi[m) Ircrc Edit", "�s�� .ircrc �]�w��",
      'a', 0, NULL, Announce, READING, "([1;36ma[m) Announce", "�i�����i",
      't', 0, NULL, x_date, 0, "([1;36mt[m) Time Now", "��ܲ{�b�t�ήɶ�",
	'w', 0, NULL, Switch_scr, 0, "([1;36mw[m) Color/BW Switch", "���/�m����ܼҦ�����",
#if defined(PICTURE_MENU)
	'u', 0, NULL, x_picture, 0, "([1;36mu[m) Picture Menu Switch", "���}/�����q�ϼҦ�",
#endif

#ifdef IDENT
	'c', 1, NULL, CheckID, 0, "([1;36mc[m) ID Check", "�i�樭���T�{",
#endif

	'x', 0, MainMenu, NULL, XMENU, "Xyz Menu", "�ӤH��ƺ��@�u��c",
	0, 0, NULL, NULL, 0, NULL, NULL

};

#endif /* !CSBBS */

/*******************************************************************
 * Mail Menu
 *******************************************************************/
extern int m_new(), m_read(), m_send(), m_forward(), m_group();

/*
 * extern int         m_fix();
 */

struct commands MailMenu[] =
{

	'n', 1, NULL, m_new, RMAIL, "([1;36mn[m) New Mails", "�uŪ�s���H",
	'r', 1, NULL, m_read, RMAIL, "([1;36mr[m) Read Mails", "Ū���H��",
	's', 1, NULL, m_send, SMAIL, "([1;36ms[m) Send Mail", "�H�H",
  'g', 1, NULL, m_group, SMAIL, "([1;36mg[m) Mail to Group", "�H�H���h�H",
	'a', 0, NULL, m_forward, MAIL, "([1;36ma[m) Auto-Forward", "�H��۰���H�A��",
/*
   'f', 0,        NULL, m_fix,  MAIL,  "([1;36mf[m) Fix MailBox", "�״_�H�c",
 */
	'm', 0, MainMenu, NULL, MAIL, "Mail Menu", "�ӤH�H�c",
	0, 0, NULL, NULL, 0, NULL, NULL
};


/*******************************************************************
 * Talk Menu
 *******************************************************************/
#if 0
extern int t_users();
#endif
extern int t_query(), t_talk(), t_chat(), t_irc(),
        x_override(), t_list(), t_friends();

extern int t_message(), t_fsendmsg(), t_review();

#ifdef USE_LOCALIRC
extern int t_ircl();

#endif

#if 0
extern int t_monitor();

#endif

struct commands TalkMenu[] =
{

#if 0
	'u', 0, NULL, t_users, LUSERS, "([1;36mu[m) Online Users", "�C�X���b�u�W���ϥΪ�",
#endif	
	'u', 0, NULL, t_list, LUSERS, "([1;36mu[m) Online Users", "���C�X���b�u�W���ϥΪ�",	
	'f', 1, NULL, t_friends, LFRIENDS, "([1;36mf[m) Friends Online", "�C�X���b�u�W���ѪB��",
#if !defined(PICTURE_MENU)
	'o', 1, NULL, x_override, OVERRIDE, "([1;36mo[m) Override Edit", "�s��n�B�ͦW��",
#endif

#if 0
	'm', 0, NULL, t_monitor, MONITOR, "([1;36mm[m) Monitor", "�ʬݽu�W�ϥΪ̪��A",
#endif

	'q', 0, NULL, t_query, QUERY, "([1;36mq[m) Query User", "�d�ߨϥΪ̭ӤH��ƲӶ�",
#ifndef CSBBS
#if !defined(PICTURE_MENU)
	'p', 1, NULL, t_pager, PAGE, "([1;36mp[m) Pager Switch", "���}/������ѩI��a",
#endif
	't', PERM_PAGE, NULL, t_talk, PAGE, "([1;36mt[m) Talk", "���H�ͤ߶���",
#endif
'w', 20, NULL, t_message, SENDMSG, "([1;36mw[m) Send Message", "�u�W�e�T��",
#ifdef HAVE_FRIEND_BROADCAST
'b', 20, NULL, t_fsendmsg, SENDMSG, "([1;36mb[m) BroadCast", "�e�T�����n��",
#endif
	'r', 1, NULL, t_review, SENDMSG, "([1;36mr[m) Review Message", "�^�U�u�W�T��",
#ifndef CSBBS
	'c', PERM_CHAT, NULL, t_chat, CHATROOM, "([1;36mc[m) BBS Chat Room", "������Ѽs��",
#endif

#ifndef CSBBS
#ifdef USE_LOCALIRC
	'l', PERM_CHAT, NULL, t_ircl, LOCALIRC, "([1;36ml[m) Local IRC", "�h���p�X��Ѽs��",
#endif
	'i', PERM_CHAT, NULL, t_irc, IRCCHAT, "([1;36mi[m) IRC", "��ڲ�Ѽs��",
#endif

	't', 0, MainMenu, NULL, TMENU, "Talk Menu", "�𶢲�Ѷ�a",
	0, 0, NULL, NULL, 0, NULL, NULL
};

#ifdef USE_VOTE
/*******************************************************************
 * VOTE Menu Help
 *******************************************************************/
extern int v_help1(), v_help2(), v_help3();

struct commands VoteHelpMenu[] =
{

'1', 0, NULL, v_help1, VOTING, "[[1;33m1[m]  About Voting", "�p��ϥΧ벼",
	'2', 0, NULL, v_help2, VOTING, "[[1;33m2[m]  Hold a Vote", "�p��ӽЧ벼��",
	'3', 0, NULL, v_help3, VOTING, "[[1;33m3[m]  Notice", "�`�N�ƶ�",
	'l', 0, &(VoteMenu[0]), NULL, VOTING, "Vote Menu", "�p��ϥΧ벼",
	0, 0, NULL, NULL, 0, NULL, NULL

};

#endif

extern int Boards();



struct commands ClassMenu[] =
{

   '1', 0, NULL, Boards, BOARDS_MENU, "[[1;33m1[m]  �t�λP���ȰQ�װ�", "",
	'2', 0, NULL, Boards, BOARDS_MENU, "[[1;33m2[m]  �q���A�����ά����޳N�Q�װ�", "",
   '3', 0, NULL, Boards, BOARDS_MENU, "[[1;33m3[m]  ���N�P��ưQ�װ�", "",
	'4', 0, NULL, Boards, BOARDS_MENU, "[[1;33m4[m]  �籡�Ѧa�A�ͬ���T�Q�װ�", "",
'5', 0, NULL, Boards, BOARDS_MENU, "[[1;33m5[m]  ��|�P�𶢮T�ְQ�װ�", "",
   '6', 0, NULL, Boards, BOARDS_MENU, "[[1;33m6[m]  �H��P���|�Q�װ�", "",
   '7', 0, NULL, Boards, BOARDS_MENU, "[[1;33m7[m]  ��ǻP�޳N�Q�װ�", "",
   '8', 0, NULL, Boards, BOARDS_MENU, "[[1;33m8[m]  �����Y�ɷs�D�M��", "",
   'n', 0, NULL, Boards, BOARDS_MENU, "[[1;33mn[m]  �̪�s�W�]�Q�װ�", "",
	'l', 'c', MainMenu, NULL, CLASS_MENU, "Class Menu", "�ݪO�������",
	0, 0, NULL, NULL, 0, NULL, NULL

};



#ifdef USE_VOTE
/*******************************************************************
 * VOTE Menu
 *******************************************************************/
extern int v_edit(), v_del(), v_hold();

struct commands VoteAdminMenu[] =
{

     '1', 100, NULL, v_hold, ADDVOTE, "[[1;33m1[m]  Add Vote", "�W�[�벼",
   '2', 100, NULL, v_edit, EDITVOTE, "[[1;33m2[m]  Edit Vote", "�ק�벼",
   '3', 100, NULL, v_del, DELVOTE, "[[1;33m3[m]  Delete Vote", "�R���벼",
	'a', 100, &(VoteMenu[0]), NULL, VOTING, "Vote Menu", "�벼�u��c",
	0, 100, NULL, NULL, 0, NULL, NULL

};


/*******************************************************************
 * VOTE Menu
 *******************************************************************/
extern int v_sys(), v_board();

struct commands VoteMenu[] =
{

    's', 1, NULL, v_sys, VOTING, "([1;36ms[m)  System Vote", "�t�Χ벼��",
   'b', 1, NULL, v_board, VOTING, "([1;36mb[m)  Board Vote", "�U�O�벼��",
	'l', 0, &(VoteHelpMenu[0]), NULL, VOTING, "([1;36ml[m)  Help", "�벼�ϥλ���",
	'a', 100, &(VoteAdminMenu[0]), NULL, VOTING, "([1;36ma[m)  Vote Admin", "�벼�u��c",
	'v', 0, MainMenu, NULL, VOTING, "Vote Menu", "BBS �벼��",
	0, 0, NULL, NULL, 0, NULL, NULL

};

#endif


/*******************************************************************
 * Main Menu
 *******************************************************************/
extern int Select(), Read(), Post(), Goodbye();

#if !defined(PICTURE_MENU)

extern int Switch_scr(), Announce();

struct commands MainMenu[] =
{

    'n', 0, NULL, Announce, READING, "([1;32mn[m) Announce", "�t�Τ��i��",
	'0', 0, NULL, Boards, BOARDS_MENU, "([1;32m0[m) Boards", "��Ц��G�i����",
	'l', 0, &(ClassMenu[0]), NULL, CLASS_MENU, "([1;32ml[m) Class", "�������G�i����",
   's', 0, NULL, Select, SELECT, "([1;32ms[m) Select", "��J���G�i����",
	'r', 0, NULL, Read, READING, "([1;32mr[m) Read", "Ū���G�i",
/*	
	'p', 0, NULL, Post, POSTING, "([1;32mp[m) Post", "�i�K�G�i",
*/	
	't', 0, &(TalkMenu[0]), NULL, TMENU, "([1;32mt[m) Talk Menu", "�𶢲�Ѷ�a",
	'm', 0, &(MailMenu[0]), NULL, MAIL, "([1;32mm[m) Mail Menu", "�ӤH�l��H�c",

#ifdef HAVE_LISTALLUSER
	'u', 0, NULL, Users, LAUSERS, "([1;32mu[m) List All Users", "�C�X�Ҧ��ϥΪ̸��",
#endif

#ifndef CSBBS
	'x', 0, &(XyzMenu[0]), NULL, XMENU, "([1;32mx[m) Xyz Utilities", "�ӤH��ƺ��@�u��c",
/*
   '1', 0, &(GameMenu[0]), NULL, GMENU, "([1;32m1[m) Games Menu", "�����C�ֳ�",
 */
#endif
	'w', 0, NULL, Switch_scr, 0, "([1;32mw[m) Color/BW Switch", "���/�m����ܼҦ�����",

#ifdef USE_VOTE
   'v', 0, &(VoteMenu[0]), NULL, VOTING, "([1;32mv[m) Vote", "�i�J�벼��",
#endif

	'g', 0, NULL, Goodbye, 0, "([1;32mg[m) Goodbye", "�A���A�ڪ��B��",
#ifndef CSBBS
	'a', 255, &(AdminMenu[0]), NULL, ADMIN, "([1;32ma[m) Admin Menu", "�޲z�̿줽��",
#endif
	'0', 0, NULL, NULL, MMENU, "Main Menu", bbstitle,
	0, 0, NULL, NULL, 0, NULL, NULL

};


#else


struct commands MainMenu[] =
{

	'0', 0, NULL, Boards, BOARDS_MENU, "([1;32m0[m) Boards", "��Ц��G�i����",
	'c', 0, &(ClassMenu[0]), NULL, CLASS_MENU, "([1;32mc[m) Class", "�������G�i����",
   's', 0, NULL, Select, SELECT, "([1;32ms[m) Select", "��J���G�i����",
	'r', 0, NULL, Read, READING, "([1;32mr[m) Read", "Ū���G�i",
	't', 0, &(TalkMenu[0]), NULL, TMENU, "([1;32mt[m) Talk Menu", "�𶢲�Ѷ�a",
	'm', 0, &(MailMenu[0]), NULL, MAIL, "([1;32mm[m) Mail Menu", "�ӤH�l��H�c",

#ifdef HAVE_LISTALLUSER
	'u', 0, NULL, Users, LAUSERS, "([1;32mu[m) List All Users", "�C�X�Ҧ��ϥΪ̸��",
#endif

#ifndef CSBBS
	'x', 0, &(XyzMenu[0]), NULL, XMENU, "([1;32mx[m) Xyz Utilities", "�ӤH��ƺ��@�u��c",
/*
   '1', 0, &(GameMenu[0]), NULL, GMENU, "([1;32m1[m) Games Menu", "�����C�ֳ�",
 */
#endif

#ifdef USE_VOTE
   'v', 0, &(VoteMenu[0]), NULL, VOTING, "([1;32mv[m) Vote", "�i�J�벼��",
#endif

	'g', 0, NULL, Goodbye, 0, "([1;32mg[m) Goodbye", "�A���A�ڪ��B��",
#ifndef CSBBS
	'a', 255, &(AdminMenu[0]), NULL, ADMIN, "([1;32ma[m) Admin Menu", "�޲z�̿줽��",
#endif
	'0', 0, NULL, NULL, MMENU, "Main Menu", bbstitle,
	0, 0, NULL, NULL, 0, NULL, NULL

};

#endif


/*******************************************************************
 * �H�U�O �����ާ@������
 *                                          lmj@cc.nsysu.edu.tw
 *******************************************************************/

#define PUTCURS   move(c+4,3);prints(_str_cursor);
#define RMVCURS   move(c+4,3);prints(_str_uncurs);

char    auto_key = '\0';	/* lasehu ? */

#if 0
void
set_menu_autokey(ckey)
char    ckey;
{
	auto_key = ckey;
}
#endif


/*******************************************************************
 * ���ާ@ (bbs �{�����D�[�c)
 *******************************************************************/

int     picture_number;
short   pict_no;


domenu()
{
/*
 * c: �ثe�Ҧb�諸���@�� (0 ~ total - 1) total: �ثe�Ҧb��@���X��
 */
	int     c = 0, total = 0, i;
	int     mode = NEWDIRECT, key = '\0';

/* int *realc = NULL; */
	unsigned int realc[20];
	int     realtotal = 0;
	int     menulayer = 1;	/* ���h�� */
	char	menu_title_color[] = MENU_TITLE_COLOR;
	char	menu_btitle_color[] = MENU_BTITLE_COLOR;	
	char	*mptr = menu_title_color + strlen(menu_title_color) - 2;
	char	*bmptr = menu_btitle_color + strlen(menu_btitle_color) - 2;

	struct commands *comm = &(MainMenu[0]);

#ifdef USE_VOTE
	if (check_vote(SYSVOTE))	/* ? */
		more(NEWVOTEMSG, YEA);
#endif

	while (1)
	{
/*	
		if (*mptr >= '9')
			*mptr = '0';
		else
			(*mptr)++;				
		if (*bmptr >= '9')
			*bmptr = '0';
		else
			(*bmptr)++;				
*/			
		switch (mode)
		 {
		 case CAREYDOWN:
			 RMVCURS;
			 if (c == total - 1)
				 c = 0;
			 else
				 c++;
			 break;
		 case CAREYUP:
			 RMVCURS;
			 if (c == 0)
				 c = total - 1;
			 else
				 c--;
			 break;
		 case NEWDIRECT:
			 for (realtotal = 0; comm[realtotal + 1].key; realtotal++)
				/* NULL STATEMENT */ ;
			/*
			   if (realc != NULL) free(realc); realc = (int *)
			   malloc (sizeof(int) * realtotal);
			 */
			 for (i = 0, total = 0; i < realtotal && total < realtotal; i++)
			 {
#ifdef IDENT
/*
   if (comm[i].level == -1 && curuser.ident == 7)
 */
				 if (comm[i].cfunc == CheckID && curuser.ident == 7)
					 continue;
#endif
				 if (curuser.userlevel < comm[i].level)
					 continue;
				 realc[total++] = i;
			 }
			 update_umode(comm[realtotal].mode);
			/* �Y���s�H��, �۰ʱN��в��ܫH�c�ﶵ */
			 if (menulayer == 1 && check_newmail(curuser.userid))
				 auto_key = 'm';
			 for (c = 0; c < total; c++)
				 if (auto_key == comm[realc[c]].key)
					 break;
			 if (c == total)	/* bug fixed */
				 c = 0;
		 case M_FULL:
			 clear();
			 move(4, 0);
			 clrtobot();
			 for (i = 0; i < total; i++)
				 prints("       %-40s %s\n",
				 comm[realc[i]].ehelp, comm[realc[i]].chelp);
#if defined(PICTURE_MENU)
			 if (!(curuser.flags[1] & PICTURE_FLAG))
			 {
				 FILE   *fp;
				 char    path[STRLEN];

				 pict_no = (time(0) % picture_number) + 1;	/* lasehu */
				 sprintf(path, "%s/%-d", PICTURE_PATH, pict_no);
				 if (fp = fopen(path, "r"))
				 {
					 int     j;

					 j = i + 5;
					 move(j++, 0);
					 for (; j < t_lines; j++)
					 {
						 if (fgets(genbuf, sizeof(genbuf), fp))
							 outs(genbuf);
						 else
							 break;
					 }
					 fclose(fp);
					 outs("[m");	/* lasehu */
				 }
			 }
#endif /* PICTURE_MENU */
#if 0
		 case M_LINE:
#endif
			 printxy(0, 0, "%s%-40s%s    ",
				 menu_title_color, comm[realtotal].chelp,
				 (check_newmail(curuser.userid) ? "(���z���H)" : "          "));
			 if (menulayer == 1)	/* lasehu */
			 {
				 prints("�ݪO : %-16.16s [m",
				  (topb ? curb->word->name : _msg_not_choose_board));
			 }
			 else
			 {
				 prints("%23s [m", "");
			 }

			 if (comm[realc[c]].cfunc != Goodbye)	/* lasehu */
			 {
				 move(2, 0);
				 clrtoeol();
			 }
			 printxy(b_line, 0, "%s (��)(��)��� (��)(Enter)��� (��)(e)�W�h (�G�r)���� (Ctrl-L)���e�ù� (Tab)�q��[m", menu_btitle_color);
			 break;
		 default:
			 break;
		 }
		move(1, 0);
		clrtoeol();
		prints("[�z�����] : %s", comm[realc[c]].ehelp);
		mode = M_NO;	/* ? */
		PUTCURS;	/* ? */
		if (talkrequest)
		{
			talkreply();
/*---			pressreturn(); */
			mode = M_FULL;
			continue;
		}
		else if (writerequest)	/* lasehu */
		{
			writereply();
			mode = M_FULL;
			continue;
		}
		if (auto_key == '\0')
			key = igetkey();
		else
			key = auto_key;
		switch (key)
		 {
		 case KEY_UP:
			 mode = CAREYUP;
			 break;
		 case KEY_DOWN:
			 mode = CAREYDOWN;
			 break;
		 case 'e':
		 case KEY_LEFT:
			 if (menulayer == 1)
			 {
				 Goodbye();
#if 0
				 mode = M_LINE;
#endif
				 mode = M_FULL;
				 continue;
			 }
			 menulayer--;
			/* �h�^�W�h��� */
			 auto_key = comm[realtotal].key;
			 comm = comm[realtotal].comm;
			 mode = NEWDIRECT;
			 break;
		 case '\n':
		 case '\r':
		 case KEY_RIGHT:
			 if (comm[realc[c]].comm)
			 {	/* �i�J�l��� */
				 comm = comm[realc[c]].comm;
				 mode = NEWDIRECT;
				 menulayer++;
				 continue;
			 }
			 printxy(0, 54, "%s[m", menu_title_color, comm[realc[c]].chelp);	/* lasehu */
			 if (comm[realc[c]].cfunc != Goodbye)
			 {
				 move(2, 0);
				 clrtobot();	/* lasehu */
			 }
			 update_umode(comm[realc[c]].mode);
			 mode = (*(comm[realc[c]].cfunc)) (comm[realc[c]].key);
/*---
				if (mode == AUTOKEY)
					mode = M_FULL;
*/
#if 0
			 else
			 if (mode != M_LINE && mode != M_NO)
				 mode = M_FULL;
#endif
			/* �^�_�U��檺 umode ���A */
			 update_umode(comm[realtotal].mode);
			 break;
			/*
			   case 'h': for(i = 0; i < total; i++)
			   printxy(i+4,7,"%-30s %s",
			   comm[realc[i]].ehelp,comm[realc[i]].chelp); break;
			 */
#if defined(PICTURE_MENU)
		 case TAB:
			 {
				 char    buf[STRLEN];

				 sprintf(buf, "%s/%-d", PICTURE_PATH, pict_no);
				 more(buf, YEA);
				 mode = NEWDIRECT;
				 auto_key = '\0';
				 break;
			 }
#endif
			 break;
		 case CTRL('R'):
			 ReplyLastCall();
			 mode = M_FULL;
			 break;
		 default:
			 if (isalnum(key))
			 {
				 for (i = 0; i < total; i++)
					 if (key == comm[realc[i]].key)
					 {
						 RMVCURS;
						 c = i;
						 PUTCURS;
						 break;
					 }
			 }
			 auto_key = '\0';
			 break;
		 }
	}			/* while */
}
