
#ifndef _BBS_TSBBS_H_
#define _BBS_TSBBS_H_


#define MAX_GROUPS	15

/*******************************************************************
 *	�N�W���w�q��
 *******************************************************************/

/* Flags to getdata input function */
#define DOECHO 	      0x01	
#define NOECHO 	      0x02
#define UNSPACE       0x10
#define ECHONOSP 	  (DOECHO|UNSPACE)

/* Option to i_read() powerful readmenu function */
#define IREAD_BOARD	  0x11 
#define IREAD_MAIL    0x12    
#define IREAD_ICHECK  0x13
#define IREAD_IFIND   0x14

#define ONLINEUP      0x1
#define OFFLINEUP     0x2

#define B_FULL	0x01     /* Entire screen was destroyed in this operation */
#define B_NO	0x02
#define B_PART	0x04

#define R_FULL  0x01
#define R_NO	0x02
#define R_PART  0x04
#define R_LINE	0x08

#define M_FULL	0x01
#define M_NO	0x02
#define M_LINE	0x08

#define CAREYUP		0x10
#define CAREYDOWN	0x20
#define NEWDIRECT	0x40    /* Directory has changed, re-read files */
#define NEWBOARD	0x80    /* lasehu: change board */


/* Used for the getchar routine select call */
#define I_TIMEOUT   (0x180)	
#define I_OTHERDATA (0x181)

#define SCREEN_SIZE 	(23)    

#define SMTPPORT	25

#define ASK_UUENCODE	1
#define NOASK_UUENCODE	0

#define TTLEN	60        /* -ToDo- ���D���� */


/*******************************************************************
 *	��Ƶ��c�w�q��
 *******************************************************************/
struct commands {		
	char key;
	unsigned int level;
	struct commands *comm;
	int (*cfunc)() ;
	int mode;
	char *ehelp;
	char *chelp;
} ;


struct one_key {           /* Used to pass commands to the readmenu */
	int key ;
	int (*fptr)() ;
} ;

#if 0
struct artinfo {
    char *from;
    char *to;    
    char *filename;
    char *title;
    char ident;        
};
#endif

struct array {
	int number;
	char **datap;
};	


/*******************************************************************
 * Global variables
 *******************************************************************/
#ifdef _BBS_GLOBAL_VAR_

USEREC curuser;
USER_INFO uinfo; 
FILEHEADER tmp_fh; 

struct bword    *topb = NULL, *curb;
struct word     *artwtop = NULL;	/* �Ω�аO�峹�ΫH�� */

#if 0
jmp_buf byebye;            /* Used for exception condition like I/O error*/
#endif

char genbuf[512];          /* generally used global buffer */

unsigned int numposts = 0;

time_t prev_lastlogin ;
char prev_from[HOSTLEN] ;

char maildirect[PATHLEN];

short in_board = 1, in_mail = 0;
short dumb_term = YEA;
short talkrequest = NA, writerequest = NA;
short ever_del_mail = NA;
short show_ansi = YEA;
short multi = 1;           /* multi_login */
short maxkeepmail;

char ufile_overrides[PATHLEN];
char ufile_boardrc[PATHLEN];
char ufile_write[PATHLEN];
 
char bbstitle[STRLEN]; 
 
char tempfile[PATHLEN];
char curbmfile[PATHLEN];

short MailToAllFriend = NA;

struct array *mgatop = NULL;
struct array *friend_cache = NULL;

unsigned int maxbid;

/*******************************************************************
 * 	BBS �T���w�q
 *******************************************************************/

/* -ToDo- multi language version message define */
char *_str_header_title = "���D�G "; 
char *_str_crosspost = "[��K]";
char *_str_cursor = "=>";
char *_str_uncurs = "  ";

char *_msg_abort = "���.";
char *_msg_aborted = "\n���.";
char *_msg_finish = "����."; 
char *_msg_finished = "\n����.";
char *_msg_fail = "����.";
char *_msg_failed  = "\n����.";

char *_msg_err_userid = "\n�ϥΪ̥N�����~.";
char *_msg_err_boardname = "�ݪO�W�ٿ��~";
char *_msg_in_processing = "�B�z��, �еy�� ...";

char *_msg_not_sure_modify = "\n==>> �T�w�n�ק�� (y/n) ? [n] : ";

char *_msg_sorry_email = "��p, �ثe�����ѥ��{�ҨϥΪ̪����� e-mail �A��.";
char *_msg_ent_userid = "��J�^��N�W: ";
char *_msg_quote_said = "���峹������";
char *_msg_ent_new_title = "�s���D: ";
char *_msg_no_use_sig = "\n�����z: �z�w�]�w���A�ϥ�ñ�W��!";
char *_msg_signature = "ñ�W��";
char *_msg_include_which_sig = "�ޤJ�ĴX��ñ�W��";
char *_msg_no_include_sig = "���ޤJ";
char *_msg_has_edit_art = "�ק�L���g���e";
char *_msg_include_ori = "�O�_�ޤJ���";
char *_msg_cross_which_board = "�N���g��K�ܭ��ӪO: ";
char *_msg_reserve_article = "<<�O�d�峹>> (m)�аO���O�d (u)�����O�d (c)������ [c]: ";

char *_msg_not_choose_board = "�|����w�ݪO";

#else

extern USEREC curuser; 	
extern USER_INFO uinfo; 
extern FILEHEADER tmp_fh;

extern struct  bword	*topb, *curb;
extern struct  word   *artwtop;

#if 0
extern jmp_buf byebye ;        	
#endif

extern char genbuf[512];	

extern unsigned int numposts;

extern time_t prev_lastlogin ;
extern char prev_from[] ;

extern char maildirect[];

extern short in_mail, in_board;
extern short dumb_term ;
extern short talkrequest, writerequest;
extern short ever_del_mail;
extern short show_ansi;
extern short multi;
extern short maxkeepmail;

/* for NO-TTY BBS Server */
extern short init_enter, two_enter, press_enter;
extern pid_t child_pid;           

extern char ufile_overrides[PATHLEN];
extern char ufile_boardrc[PATHLEN];
extern char ufile_write[PATHLEN];

extern char bbstitle[STRLEN];

extern char tempfile[PATHLEN];
extern char curbmfile[PATHLEN];

extern short MailToAllFriend;

extern struct array *mgatop;
extern struct array *friend_cache;

extern unsigned int maxbid;

/*******************************************************************
 * 	BBS �T���ŧi
 *******************************************************************/
extern char *_str_header_title;
extern char *_str_crosspost;
extern char *_str_cursor;
extern char *_str_uncurs;


extern char *_msg_sorry_email;
extern char *_msg_ent_userid;
extern char *_msg_abort;
extern char *_msg_aborted;
extern char *_msg_finish;
extern char *_msg_finished;
extern char *_msg_err_userid;

extern char *_msg_quote_said;
extern char *_msg_ent_new_title;
extern char *_msg_no_use_sig;
extern char *_msg_signature;
extern char *_msg_include_which_sig;
extern char *_msg_no_include_sig;
extern char *_msg_has_edit_art;
extern char *_msg_include_ori;

extern char *_msg_err_boardname;
extern char *_msg_cross_which_board;

extern char *_msg_reserve_article;

extern char *_msg_fail;
extern char *_msg_failed;
extern char *_msg_in_processing;

extern char *_msg_not_sure_modify;
extern char *_msg_not_choose_board;

#endif /* _BBS_GLOBAL_VAR_ */


/*******************************************************************
 *	����w�q
 *******************************************************************/
#define KEY_UP		0x0101
#define KEY_DOWN	0x0102
#define KEY_RIGHT	0x0103
#define KEY_LEFT	0x0104

#define KEY_HOME	0x0201
#define KEY_INS		0x0202
#define KEY_DEL		0x0203
#define KEY_END		0x0204
#define KEY_PGUP	0x0205
#define KEY_PGDN	0x0206


/*******************************************************************
 *	�禡 prototype �ŧi					
 *******************************************************************/ 
extern char *Ctime();

extern int voteboardhold();
extern int mail_article(), del_article(), edit_article(), 
	   title_article(), batch_del_article(), reserve_article();

extern void init_alarm();
extern int (*outc)();

extern int cmp_userid();
extern int cmp_uid();
extern int cmp_bname();

extern int board_list_cmp();
extern int board_list_ncmp();


/* linklist function prototype	*/
extern struct word *make_wlist(/* wtop, prompt, data */);
extern char *malloc_str(/* str */);
extern struct word *free_wlist(/* wtop */);
extern struct word *add_wlist();
extern struct word *cmp_wlist(/* wtop, wcur, name, cmp_func */);
extern struct word *cmpd_wlist(/* wtop, wcur, name, cmp_func */);
struct word *get_subwlist(/* chat tag, struct word *list*/);

void move(int y, int x);

int 	cmp_array(struct array *atop, char *str, int (*cmpfunc)());
struct array *free_array(struct array *atop);
struct array *add_array(struct array *atop, char *str, char *(*addfunc)());
struct array *malloc_array(int numpointer);
struct array *cmpd_array(struct array *atop, char *str, int (*cmpfunc)());
int 	num_array(struct array *atop);

void show_byebye();
void pressreturn();
void bell();
void chk_str();
void setdotfile();
void get_only_name();
void setboardfile(), setmailfile();
void close_all_ftable();
void MakeBoardList();
void DelBoardList();
void refresh_brc(), brc_initial();
void uuencode_file();
void initscr(), redoscr(), refresh(), clear(), clrtoeol(), clrtobot();
void getyx();
void set_menu_aotokey();
void do_move();
void user_logout();
void DisconnectServer();


char *GetPass(), *PhaseSpace();

/*******************************************************************
 * 	�䥦�w�q�Υ���
 *******************************************************************/
 /* -ToDo- */
#define isBM    (!strcmp(curuser.userid, curb->word->owner) || seek_in_file(curbmfile, curuser.userid))
#define b_line  (t_lines-1)

#define HAS_PERM(x)	  CHECK_PERM(curuser.userlevel, x) /* -ToDo-*/

#define HAS_FLAG(x)   (curuser.flags[0] & x)           /* -ToDo */
#define SET_FLAG(x)   (curuser.flags[0] |= x)
#define UNSET_FLAG(x) (curuser.flags[0] &= ~x)


extern int t_lines, t_columns;  /* Screen size, width */
#define STR_CURSOR "=>"
#define STR_UNCURS "  "


#endif /* _BBS_TSBBS_H_ */
