
#include "bbs.h"
#include "tsbbs.h"

#ifdef IDENT


extern int reply_user();
extern int a_find_user();
extern int a_level();


struct one_key find_comms[] =
{
	'f', a_find_user,
	'l', a_level,
	'\0', NULL
};


struct one_key check_comms[] =
{
	'd', del_article,
	'm', reply_user,
	'T', batch_del_article,	/* lasehu */
	'\0', NULL
};


int
a_encode(srcfile, pgpfile)
char   *srcfile, pgpfile;
{
	char    buf[PATHLEN];

	sprintf(buf, "tmp/%sPGP", curuser.userid);
	mycp(srcfile, buf);
	sprintf(genbuf, "pgp -e \"%s\" \"%s\"", buf, PUBLIC_KEY);
	outdoor(genbuf, ADMIN, YEA);
	sprintf(buf, "tmp/%sPGP.pgp", curuser.userid);
	rename(buf, pgpfile);
	unlink(buf);		/* delete temp file */

	return M_FULL;
}


int
a_decode(pgpfile, srcfile, privatekey)
char    pgpfile[], srcfile[], privatekey[];
{
	if (privatekey[0])
		sprintf(genbuf, "pgp \"%s\" \"%s\" \"%s\"", pgpfile, srcfile, privatekey);
	else
		sprintf(genbuf, "pgp \"%s\" \"%s\"", pgpfile, srcfile);
	outdoor(genbuf, ADMIN, YEA);

	return M_FULL;
}


int
reply_user(ent, finfo, direct)
int     ent;
FILEHEADER *finfo;
char   *direct;
{
	reply_mail(finfo, direct);
	return R_FULL;
}


int
a_level()
{
	char    name[IDLEN + 1], num[2];
	USEREC  initial;

	clear();
	getdata(0, 0, "�z�n�ק�֪��T�{���šG", name, sizeof(name), ECHONOSP, NULL);
	if (get_passwd(&initial, name) <= 0)
	{
		outs(_msg_err_userid);
		return M_FULL;
	}
	getdata(1, 0, "�п�J�{�ҵ��� (0 or 7) ? [0]: ", num, sizeof(num), ECHONOSP, NULL);
	initial.ident = atoi(num);
	if (initial.ident > 7 || initial.ident < 0)
		initial.ident = 0;
	outs("\n����H�W�ק�� (y/n) ? [n]: ");
	if (igetkey() == 'y')
	{
		update_user(&initial);
	}
	return M_FULL;
}


int
a_find_user()
{
	char    name[IDLEN + 1];
	char    file1[IDLEN + 12], file2[IDLEN + 12];

	msg("�z�n�d�߽֪��u���� [ID]�G", name, sizeof(name), DOECHO, NULL);

	setuserfile(file1, name, BBSPATH_REALUSER);
	sprintf(file2, "tmp/%sPGP", name);

	a_decode(file1, file2, "\0");
	if (more(file2, YEA) == -1)
	{
		msg("�d�L���H���....");
		return M_FULL;
	}
	unlink(file2);

	return M_FULL;
}


int
a_find()
{
	char    tmp_direct[PATHLEN];

	if (!dashf("bin/secring.pgp") || !dashf("bin/pubring.pgp"))
		return M_FULL;

	in_mail = 1;
	setuserfile(tmp_direct, DIR_REC, BBSPATH_REALUSER);
	i_read(tmp_direct, &find_comms[0], IREAD_IFIND);
	in_mail = 0;
}


int
a_check()
{
	char    save_bname[STRLEN];
	char    tmp_direct[PATHLEN];

	if (!dashf("bin/secring.pgp") || !dashf("bin/pubring.pgp"))
		return M_FULL;

	if (!curb || !curb->word || !curb->word->name)
		return M_FULL;

	strcpy(save_bname, curb->word->name);
	strcpy(curb->word->name, "ID");

	in_board = 1;

	setboardfile(tmp_direct, "ID", DIR_REC);
	i_read(tmp_direct, &check_comms[0], IREAD_ICHECK);

	strcpy(curb->word->name, save_bname);

	return 0;
}


int
a_ok(name, cond)		/* write check level */
char    name[15];
char    cond;
{
	USEREC  initial;

	if (get_passwd(&initial, name) <= 0)
		return M_FULL;
	initial.ident = cond;
	update_user(&initial);
}


int
a_chgpgp()
{
	int     save_pager;
	DIR    *dir;
	struct dirent *tmp;
	char    gbuf1[30], gbuf2[30], pass[60];

	if (strcmp(curuser.userid, PGPUSER))
		return M_FULL;
	clear();
	outs("\n���n��Ķ�Ҧ���ƶ�?[N]");
	if (igetkey() == 'y')
	{
		clear();
		getdata(2, 0, "What is SECURE KEY: ", pass, 59, DOECHO, NULL);
		reset_tty();
		dir = opendir(BBSPATH_REALUSER);
		while ((tmp = readdir(dir)) != NULL)
		{
			if (!strcmp(tmp->d_name, ".") || !strcmp(tmp->d_name, "..")
			    || !strcmp(tmp->d_name, DIR_REC))
			{
				continue;
			}
			setuserfile(gbuf1, tmp->d_name, BBSPATH_REALUSER);
			sprintf(gbuf2, "tmp/%sPGP", tmp->d_name);
			a_decode(gbuf1, gbuf2, pass);
			mycp(gbuf2, gbuf1);
			unlink(gbuf2);
		}
		closedir(dir);
		restore_tty();
		pressreturn();
	}

	clear();
	outs("\n���n���٢��B��?[N]");
	if (igetkey() == 'y')
	{
		sprintf(genbuf, "pgp -kg");
		outdoor(genbuf, ADMIN, YEA);
		pressreturn();
	}

	move(1, 0);
	outs("���n�Ҧ���ƽs�X��?[N]");
	if (igetkey() == 'y')
	{
		clear();
		dir = opendir(BBSPATH_REALUSER);
		sprintf(gbuf2, "tmp/%sPGP", curuser.userid);
		while ((tmp = readdir(dir)) != NULL)
		{
			if (!strcmp(tmp->d_name, ".") || !strcmp(tmp->d_name, "..")
			    || !strcmp(tmp->d_name, DIR_REC))
			{
				continue;
			}
			setuserfile(gbuf1, tmp->d_name, BBSPATH_REALUSER);
			a_encode(gbuf1, gbuf1);
		}
		closedir(dir);
	}
	uinfo.pager = save_pager;
	update_utmp();

	return M_FULL;
}


/* �����Ҧr���ˬd */
int
id_num_check(num)
char   *num;
{
	int     x1, x2, d[9], y, l;
	struct pair
	{
		int     x1;
		int     x2;
	};
	struct pair pairs[26] =
	{
		1, 0, 1, 1, 1, 2, 1, 3, 1, 4,
		1, 5, 1, 6, 1, 7, 3, 4, 1, 8,
		1, 9, 2, 0, 2, 1, 2, 2, 3, 5,
		2, 3, 2, 4, 2, 5, 2, 6, 2, 7,
		2, 8, 2, 9, 3, 2, 3, 0, 3, 1,
		3, 3,
	};

	if (strlen(num) != 10)
		return -1;
	*num |= 32;		/* Chang all to small character */
	if (*num < 'a' || *num > 'z')
		return -1;
	x1 = pairs[(*num) - 97].x1;
	x2 = pairs[(*num) - 97].x2;
	for (l = 0; l < 9; l++)
	{
		d[l] = *(num + l + 1) - 48;
		if (d[l] > 9 || d[l] < 0)
			return -1;
	}
	y = 3 * (3 * x2 + 2 * d[2] + d[5]) + 4 * (2 * d[0] + d[4]) + 2 * d[6] + 7 * d[1] + 5 * d[3] + x1 + d[7] + d[8];
	if (y % 10 == 0)
		return 0;	/* correct */
	return -1;
}


send_checkmail(email, buf)
char    email[];
char    buf[];
{
	char   *id, *p, tmp[128];
	int     ms;
	FILE   *fp;

	if ((p = strchr(email, '.')) != NULL)
		if (strchr(p, '@') != NULL)
			return;
	if ((ms = create_mail_socket()) < 0)
	{
		msg("<< �L�k�s�� Mail Server >>");
		igetch();
		return;
	}
	if ((fp = fopen("doc/ID_Check_Doc", "r")) == NULL)
		return;
	outs("\n�t�αH�e�{�Ҩ� ...");
	id = strstr(buf, "M.");
	sprintf(tmp, "MAIL FROM: syscheck@%s\n", MYHOSTNAME);
	net_printf(ms, tmp);
	if (!net_gets(ms, genbuf, sizeof(genbuf)))
		return;
	net_printf(ms, "RCPT TO: %-s\n", email);
	if (!net_gets(ms, genbuf, sizeof(genbuf)))
		return;
	net_printf(ms, "DATA\n");
	if (!net_gets(ms, genbuf, sizeof(genbuf)))
		return;
	sprintf(tmp, "From: syscheck@%s\n", MYHOSTNAME);
	net_printf(ms, tmp);
	net_printf(ms, "To: %-s\n", email);
	net_printf(ms, "Subject: NSYSU_BBS ( %s %s )\n\n", curuser.userid, id);
	while (fgets(genbuf, sizeof(genbuf), fp))
		net_printf(ms, "%s", genbuf);
	fclose(fp);
	net_printf(ms, "\n.\n");
	if (!net_gets(ms, genbuf, sizeof(genbuf)))
		return;
	close_mail_socket(ms);
}


/*
 * Check Chinese string
 */
int
check_cname(name)
unsigned char name[];
{
	int     i = strlen(name);

	if (i == 0 || (i % 2) == 1)
		return -1;
	while ((i = i - 2) >= 0)
		if (name[i] < 128)
			return -1;
	return 0;
}


do_post_ident()
{
	char    title[STRLEN], *p, buf[STRLEN], stamp[14];
	FILE   *fp_udata, *fp_ckdoc;
	char    email[80];

	char   *check_item[] =
	{
		"1 �m�W(����)�G",
		"2 �a�̹q�ܡG",
		"3 �Ǯդ��q�q�ܡG",
		"4 �q�T�a�}�G",
		"5 �����Ҧr���G",
		"6 ���y�ӳ��a�G",
		"7 �ͤ�(yy/mm/dd)�G",
		"8 �q�l�l��H�c�G",
		"9 ²�u���СG",
		NULL
	};
	char    fn_ckdoc[] = "doc/Check_Doc0", idcard[30], loop;
	time_t  now;
	int     is_postcard = NA;
	char    identfile[PATHLEN];

	sprintf(identfile, "tmp/ident_%s", curuser.userid);

	clear();
	outs("�бz����Announce�O�h�J�ӬݲM�����������{�Ҫ��|�g�G�i,\
�A�������{��\n������{�Ҹ�Ƶ���O�K; �z�n�������{�Ҷ�[N]?");
	if (igetkey() != 'y')
		return M_FULL;
	if ((fp_udata = fopen(identfile, "w")) == NULL)
	{
		outs("\n�}�ҷs�ɮץ���");
		pressreturn();
		return M_FULL;
	}
	clear();
	outs("�ж�J�U�C���: ");

/*
 * Input User Data
 */
	for (loop = 0; check_item[loop] != NULL; loop++)
	{
/*
 * �C�L����
 */
		fn_ckdoc[13]++;
		if ((fp_ckdoc = fopen(fn_ckdoc, "r")) != NULL)
		{
			move(11, 0);
			clrtobot();
			while (fgets(buf, 80, fp_ckdoc) != NULL)
				outs(buf);
			fclose(fp_ckdoc);
		}
/*
 * ����
 *
 */
		switch (*check_item[loop])
		 {
		 case '1':
			 do
			 {
				 move(2 + loop, 0);
				 clrtoeol();
				 getdata(2 + loop, 0, check_item[loop] + 1, buf, STRLEN - 12, ECHONOSP, NULL);
			 }
			 while (check_cname(buf));
			 strcat(buf, "  (");
			 strcat(buf, curuser.userid);
			 strcat(buf, ")");
			 break;
		 case '2':
		 case '4':
		 case '6':
		 case '7':
		 case '9':
			 do
			 {
				 move(2 + loop, 0);
				 clrtoeol();
				 getdata(2 + loop, 0, check_item[loop] + 1, buf, STRLEN - 12, DOECHO, NULL);
			 }
			 while (buf[0] == '\0');
			 break;
		 case '3':
			 move(2 + loop, 0);
			 clrtoeol();
			 getdata(2 + loop, 0, check_item[loop] + 1, buf, STRLEN - 12, DOECHO, NULL);
			 break;
		 case '5':
			 do
			 {
				 move(2 + loop, 0);
				 clrtoeol();
				 getdata(2 + loop, 0, check_item[loop] + 1, buf, STRLEN - 12, ECHONOSP, NULL);
				 if (buf[0] != '\0' && id_num_check(buf) == -1)
				 {
					 move(3 + loop, 0);
					 outs(" �аݱz�Ҷ񪺬��@�Ӹ��X�� (Y/N) ? : [N]");
					 if (igetkey() == 'y')
						 is_postcard = YEA;
				 }
			 }
			 while (buf[0] == '\0');
			 strcpy(idcard, buf);
			 break;
		 case '8':
			 do
			 {
				 move(2 + loop, 0);
				 clrtoeol();
				 getdata(2 + loop, 0, check_item[loop] + 1, buf, STRLEN - 12, ECHONOSP, NULL);
				 if ((p = strchr(buf, '@')) != NULL)
				 {
					 for (p++; !isalpha(*p) && *p != '\0'; p++)
						/* NULL STATEMENT */ ;
					 if (*p != '\0')
						 break;
				 }
			 }
			 while (1);
			 strcpy(email, buf);
			 if (is_postcard)
			 {
				 outs("[1;36m ��g�@�Ӹ��X, ���H�@�Ӽv��, �Ь� system-report �O��ذϻ���[m");
				 pressreturn();
			 }
			 else if ((p = strchr(buf, '.')) != NULL
				  && strchr(p, '@') != NULL)
			 {
				 outs("[1;36m ��g xxx.bbs@[hostname], ���H�����Ҽv��, �Ь� system-report �O��ذϻ���[m");
				 pressreturn();
			 }
			 break;
		 }
		fprintf(fp_udata, "%s%s\n\n", check_item[loop] + 1, buf);
	}
	now = time(0);
	fprintf(fp_udata, "�ӽФ���G%s\n", ctime(&now));
	fclose(fp_udata);
	outs("�H�W��Ƴ����T�� [N] ?");
	if (igetkey() != 'y')
		return M_FULL;
	if (id_num_check(idcard) == -1 && !is_postcard)
	{
		pressreturn();
		return M_FULL;
	}
	setboardfile(buf, "ID", "\0");
	sprintf(title, "�����T�{: %s", curuser.userid);
	if (append_article(identfile, buf, curuser.userid, title, 0, stamp, YEA) == -1)
	{
		outs("\n�n������\n");
		pressreturn();
		return M_FULL;
	}
	if (!is_postcard)
	{
		setboardfile(buf, "ID", stamp);
		send_checkmail(email, buf);
	}
	unlink(identfile);
	pressreturn();
	return M_FULL;
}


#if 0

check_email(path)
char    path[];
{
	FILE   *f;
	char    gbuf[160], buf[160];
	struct sockaddr_in sa;
	struct hostent *hp;
	int     s, l;
	long    addr;
	char   *name;
	char   *host;

	f = fopen(path, "r");

	do
	{
		fscanf(f, "%s", gbuf);
	}
	while (strncmp(&gbuf[7], "�q", 2) != 0 && strncmp(gbuf, "�q", 2) != 0);
	fclose(f);

	l = strlen(gbuf);
	name = strchr(gbuf, 'G') + 1;
	if (*name == '')
		name = name + 3;
	if ((host = strchr(name, '@')) == NULL)
		return l;
	*host = 0;
	host++;
	if (*name == 0)
		return l;

	memset(&sa, 0, sizeof(sa));
	if ((addr = inet_addr(host)) != -1)
	{
		bcopy(&addr, (char *) &sa.sin_addr, sizeof(addr));	/* set address */
		sa.sin_family = AF_INET;
	}
	else
	{
		if ((hp = gethostbyname(host)) == NULL)
			return l;
		host = hp->h_name;
		bcopy(hp->h_addr, (char *) &sa.sin_addr, hp->h_length);
		sa.sin_family = hp->h_addrtype;
	}
	sa.sin_port = htons((u_short) SMTPPORT);
	if ((s = socket(sa.sin_family, SOCK_STREAM, 0)) < 0)	/* get socket */
		return l;
	if (connect(s, (struct sockaddr *) &sa, sizeof(sa)) < 0)
	{			/* connect */
		close(s);
		return l;
	}

	do
	{
		net_gets(s, buf, sizeof(buf));
	}
	while (buf[3] == '-');
	sprintf(buf, "expn %s\n", name);
	net_printf(s, buf);
	net_gets(s, buf, sizeof(buf));
	net_printf(s, "quit\n");
	net_gets(s, genbuf, sizeof(genbuf));
	close(s);
	if (strncmp(buf, "25", 2) == 0)
		return -1;
	return l;
}

#endif


/*******************************************************************
 *  ��g�����{�ҥӽЮ�
 *******************************************************************/
CheckID()
{
#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return M_FULL;
#endif

	return do_post_ident();
}

#endif