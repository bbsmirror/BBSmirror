
#include "bbs.h"
#include "tsbbs.h"


/* ��榡��Ѥ��� from MapleBBS */


typedef struct
{
	USER_INFO *ui;
	short friend;
}
pickup;


#define my_kick kick_user


#define PICKUP_WAYS     5

int friends_number = 0;
int p_lines = 20;
short refscreen = NA;

short pickup_way = 0;

char *fcolor[] =
{"", "[1;36m", "[1;33m", "[1;37m"};

short list_friend = NA;
short friend_mode = NA;

extern struct UTMPFILE *utmpshm;


int
my_send(userid)			/* mail to someone */
     char *userid;
{
	char to[STRLEN], title[STRLEN];
	int result;

	clear();

	strcpy(to, userid);
	title[0] = '\0';

	result = PrepareMail(NULL, to, title, NA);
	move(b_line - 1, 0);
	clrtoeol();
	if (result == -1)
		outs("�H�H����.");
	else
		outs("�H�H����.");

	in_mail = 0;

	pressreturn();
	return 0;
}


int
my_write(upent)
     USER_INFO *upent;
{
	if (PrepareMesgContent() == 0)
		SendMesgToSomeone(upent->userid);
	return 0;
}


int
search_num(ch, max)
{
	int clen = 1;
	int x, y;
	extern unsigned char scr_cols;

	msg("���ܲĴX��: ");
	outc(ch);
	genbuf[0] = ch;
	getyx(&y, &x);
	x--;
	while ((ch = igetch()) != '\r')
	{
		if (ch == 'q' || ch == 'e')
			return -1;
		if (ch == '\n')
			break;
		if (ch == '\177' || ch == CTRL('H'))
		{
			if (clen == 0)
			{
				bell();
				continue;
			}
			clen--;
			move(y, x + clen);
			outc(' ');
			move(y, x + clen);
			continue;
		}
		if (!isdigit(ch))
		{
			bell();
			continue;
		}
		if (x + clen >= scr_cols || clen >= 6)
		{
			bell();
			continue;
		}
		genbuf[clen++] = ch;
		outc(ch);
	}
	genbuf[clen] = '\0';
	move(b_line, 0);
	clrtoeol();
	if (genbuf[0] == '\0')
		return -1;
	clen = atoi(genbuf);
	if (clen == 0)
		return 0;
	if (clen > max)
		return max;
	return clen - 1;
}

/* opus : cursor position */

void
cursor_show(row, column)
     int row, column;
{
	move(row, column);
	outs(STR_CURSOR);
	move(row, column + 2);
}


int
cursor_key(row, column)
     int row, column;
{
	int ch;

	cursor_show(row, column);
	ch = egetch();
	move(row, column);
	outs(STR_UNCURS);
	return ch;
}


int
egetch()
{
	int rval;

	while (1)
	{
		rval = getkey();
		if (talkrequest)
		{
			talkreply();
			refscreen = YEA;	/* lasehu */
			return rval;
		}
		if (writerequest)
		{		/* lasehu */
			writereply();
			refscreen = YEA;	/* lasehu */			
			return rval;
		}

		if (rval != CTRL('L'))
			return rval;
		redoscr();
	}
}


void
showtitle(title, mid)
     char *title, *mid;
{
	char buf[40];
	int spc, pad;

	spc = strlen(mid);
	if (title[0] == 0)
		title++;
	else if (check_newmail(curuser.userid))
	{
		mid = "[1;44m (���z���H) [0;1;44m";
		spc = 15;
	}

	spc = 60 - strlen(title) - spc;

	pad = 1 - spc & 1;
	memset(buf, ' ', spc >>= 1);
	buf[spc] = '\0';

	clear();
	prints("[1;44;36m %s  %s[33m%s%s%s �I��a: %s [0m\n",
	       title, buf, mid, buf, " " + pad, (uinfo.pager) ? "�}��" : "����");
}


void
str_lower(t, s)
     char *t, *s;
{
	register unsigned char ch;

	do
	{
		ch = *s++;
		*t++ = tolower(ch);
	}
	while (ch);
}


int
strstr_lower(str, tag)
     char *str, *tag;		/* tag : lower-case string */
{
	char buf[STRLEN];

	str_lower(buf, str);
	return (int) strstr(buf, tag);
}


#define	US_PICKUP	1234
#define	US_RESORT	1233
#define	US_ACTION	1232
#define	US_REDRAW	1231


void
t_showhelp()
{
	clear();
	outs(" ��ѿ��ϥλ���\n\
-----------------------------------------------------------------------------\n\
 �򥻥\\����\n\
   [��] [p]     ���W���@��     [CTRL+B] [PgUp]      ½�W�@��\n\
   [��] [n]     ���U���@��     [CTRL+F] [PgDn] [Sp] ½�U�@��\n\
   [��] [e]     ���}��ѿ��   [##]                 ����ĴX��\n\
   [Home]       ����Ĥ@��     [$]  [End]           ���쥽�@��\n\n\
 �S���\\����\n\
   [s]          ���s��ܦC��   [f]                  �C�X�u�W�n��/��������\n\
   [m]          �H�H������     [q]  [Enter][��]     �d�ߺ��͸��\n\
   [/]          ��M           [TAB]                �����ƧǤ覡\n\
   [x]          �\\Ū�ӤH�H��   [a/d]                �W�[/�R���n�ͦW��\n");

/*
   if (HAS_PERM(PERM_PAGE))
*/   
   if (curuser.userlevel > PERM_PAGE)
	{
		outs("\n ��ͱM����\n\
   [t]          ��L���o���\n\
   [l]          �^�U�u�W�T��\n\
   [w]          �u�W�e�T��\n\
   [CTRL+P]     �����I��a�}��\n");
/*
   [b]          ��n�ͼs��");
 */
	}

	if (HAS_PERM(PERM_SYSOP))
	{
/*      
   outs ("\n �����M����\n\
   [u]          �]�w�ϥΪ̸��\n\
   [r]          �d�ߨϥΪ̪��u��m�W\n\
   [k]         ���a�J��X�h");
 */
		outs("\n �����M����\n\
   [k]          ���a�J��X�h");
	}
	pressreturn();;
}


int
search_pickup(num, actor, pklist)
     int num;
     int actor;
     pickup pklist[];
{

	getdata(b_line, 0, "�п�J�j�M�r��G", genbuf, 20, DOECHO, NULL);
	move(b_line, 0);
	clrtoeol();

	if (genbuf[0])
	{
		int n = (num + 1) % actor;
		str_lower(genbuf, genbuf);
		while (n != num)
		{
			if (strstr_lower(pklist[n].ui->userid, genbuf))
				return n;
			if (strstr_lower(pklist[n].ui->from, genbuf))
				return n;
			if (++n >= actor)
				n = 0;
		}
	}
	return -1;
}


int
pickup_cmp(i, j)
     pickup *i, *j;
{
	switch (pickup_way)
	{
	case 1:
		{
			register int friend;

			if (friend = j->friend - i->friend)
				return friend;
		}
	case 2:
		return strcasecmp(i->ui->userid, j->ui->userid);
	case 3:
		return (i->ui->mode - j->ui->mode);
	case 4:
		return strcasecmp(i->ui->from, j->ui->from);
	}
}


void
pickup_user()
{
/*
	static int real_name = 0;
*/	
	static int num = 0;

	register USER_INFO *uentp;
	register int state = US_PICKUP, ch;
	register int actor, head, foot;
	register int tmp;	/* lasehu */
/*      
   int savemode = uinfo.mode;
 */
	time_t diff, freshtime;
	pickup pklist[USHM_SIZE];

	char buf[20];
	char pagerchar[] = "* O ";
	char *msg_pickup_way[PICKUP_WAYS] =
	{
		"���N�ƦC",
		"�u�W�n��",
		"�^��N�W",
		"�u�W���A",
		"�W���a�I"
	};

	short save_list_friend = list_friend;
	
	if (friend_mode)
		list_friend = YEA;

	while (1)
	{
		if (state == US_PICKUP)
		{
			freshtime = 0;
		}

		if (utmpshm->uptime > freshtime)
		{
			time(&freshtime);
			friends_number = actor = ch = foot = 0;

			while (ch < USHM_SIZE)
			{
				uentp = &(utmpshm->uinfo[ch++]);
				if (uentp->pid > 3 && uentp->userid[0])
				{
					if (!HAS_PERM(PERM_CLOAK) && uentp->invisible)
							continue;	
					tmp = MyFriend(uentp->userid); 
					if (tmp)
						friends_number++;
					else if (!tmp && list_friend)
						continue;
					pklist[actor].friend = tmp;	
					pklist[actor].ui = uentp;						
/*					
					pklist[actor].friend |= (can_override(uentp->userid, curuser.userid) ? 2 : 0);
*/					
					actor++;
				}
			}

			state = US_PICKUP;
			if (!actor)
			{
				if (friend_mode)
				{
					move(2, 0);
					clrtobot();
					outs("�A���B���٨S�W��");
					pressreturn();
					list_friend = save_list_friend;
				}
				else if (list_friend)				
				{
					getdata(b_line, 0, "�A���B���٨S�W���A�n�ݬݤ@����Ͷ�(y/n) ? [y]: ", genbuf, 4, ECHONOSP, NULL);
					if ((genbuf[0] | 32) != 'n')
					{
/*        
   curuser.uflag &= ~FRIEND_FLAG;
 */
						list_friend = NA;
						continue;
					}
				}
				return;
			}
		}

		if (pickup_way > 0 && state >= US_RESORT)	/* lasehu */
			qsort(pklist, actor, sizeof(pickup), pickup_cmp);

		if (state >= US_ACTION)
		{
			showtitle(list_friend ? "�n�ͦC��" : "�𶢲��", BBSNAME);
			prints(" �ƧǤ覡: [%s]  �X��: %s  �u�W�`�H�ơG%-6d[1;32m�u�W�n�͡G%-5d [0m\n"
			       "[7m   �s�� �^��N�W     %-20s%-16s %cP %-13s    [0m\n",
			       msg_pickup_way[pickup_way], curuser.userid,
			       actor, friends_number,
			       "����N��", "�Ӧ�",
			       HAS_PERM(PERM_CLOAK) ? 'C' : ' ',
			       "���A");
		}
		else
		{
			move(3, 0);
			clrtobot();
		}

		if (num < 0)
			num = 0;
		else if (num >= actor)
			num = actor - 1;

		head = (num / p_lines) * p_lines;
		foot = head + p_lines;
		if (foot > actor)
			foot = actor;

		for (ch = head; ch < foot; ch++)
		{
			uentp = pklist[ch].ui;

			if (!uentp->pid)
			{
				state = US_PICKUP;
				break;
			}

			state = pklist[ch].friend;	/* lasehu */
			if (uentp->userid[0])
			{
				prints("  %5d %s%-13s%-20.19s[m%-16.16s %c%c %-17.17s\n",
				       ch + 1,
				       fcolor[state], uentp->userid,
#if 0
				       uentp->username, state ? "[0m" : "",
#endif
				       uentp->username,
/*                                      
   (diff || HAS_PERM (PERM_SYSOP)) ? uentp->from : "*",
 */
				       uentp->from,
				       (uentp->invisible ? 'C' : ' '),
				       pagerchar[(state & 2) | (uentp->pager)],
				       modestring(uentp, 1));
			}
			else
				prints("     --- �����ͤw���u ---\n");
		}
		if (state == US_PICKUP)
			continue;

		move(b_line, 0);
		prints("[37;44m (��)���� (f)�n�� (t)��� (a/d)��� (q)�d�� (w/l)�e/�^�T�� (m)�H�H (h)����   [0m", curuser.userid);

		state = 0;
		while (!state)
		{
			ch = cursor_key(num + 3 - head, 0);
			if (ch == KEY_RIGHT || ch == '\n' || ch == '\r')
				ch = 'q';
			else if (ch >= 'A' && ch <= 'Z')
				ch |= 32;

			if (refscreen)	/* lasehu */
			{
				state = US_REDRAW;
				refscreen = NA;
				continue;
			}
			switch (ch)
			{
			case KEY_LEFT:
			case 'e':
				if (friend_mode)
					list_friend = save_list_friend;
				return;
			case TAB:
				if (++pickup_way >= PICKUP_WAYS)
					pickup_way = 0;
				state = US_RESORT;
				num = 0;
				break;
			case KEY_DOWN:
			case 'n':
				if (++num < actor)
				{
					if (num >= foot)
						state = US_REDRAW;
					break;
				}

			case '0':
			case KEY_HOME:
				num = 0;
				if (head)
					state = US_REDRAW;
				break;

			case ' ':
			case KEY_PGDN:
			case CTRL('F'):
				if (foot < actor)
				{
					num += p_lines;
					state = US_REDRAW;
				}
				else if (head)
				{
					num = 0;
					state = US_REDRAW;
				}
				break;

			case KEY_UP:
			case 'p':
				if (--num < head)
				{
					if (num < 0)
					{
						num = actor - 1;
						if (actor == foot)
							break;
					}
					state = US_REDRAW;
				}
				break;

			case KEY_PGUP:
			case CTRL('B'):
				if (head)
				{
					num -= p_lines;
					state = US_REDRAW;
					break;
				}

			case KEY_END:
			case '$':
				num = actor - 1;
				if (foot < actor)
					state = US_REDRAW;
				break;
			case CTRL('P'):
				uinfo.pager = (uinfo.pager) ? NA : YEA;
				update_utmp();
				state = US_PICKUP;
				break;
			case '/':
				{
					if ((tmp = search_pickup(num, actor, pklist)) >= 0)
						num = tmp;
					state = US_REDRAW;
				}
				break;

			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
				{
					if ((tmp = search_num(ch, actor - 1)) >= 0)
						num = tmp;
					state = US_REDRAW;
				}
				break;
#if 0
#ifdef	REALINFO
			case 'r':	/* ��ܯu��m�W */
				if (HAS_PERM(PERM_SYSOP))
				{
					real_name ^= 1;
					state = US_REDRAW;
				}
				break;
#endif
#endif
#if 0
			case 'b':	/* broadcast */

				if ((actor > 1) && (list_friend || (ch = HAS_PERM(PERM_SYSOP))))
				{
					int actor_pos = actor;
					uentp = pklist[--actor_pos].ui;
/*        
   if (currutmp == uentp)
   uentp = pklist[--actor_pos].ui;
   my_write(uentp, "�s���T���G");
 */
					if (*genbuf)
					{
						pid_t pid;
						char fpath[80];

						while (actor_pos)
						{
							uentp = pklist[--actor_pos].ui;
							if ((currutmp != uentp) && (ch || !is_rejected(uentp)) &&
							    (pid = uentp->pid) && (kill(pid, 0) != -1))
							{
								sethomefile(fpath, uentp->userid, fn_write);
								/* Thor: �S�O�`�N, �Y ���P�W�r, �B link ���Ѫ����� !! */
								unlink(fpath);
								link(genbuf, fpath);
								kill(pid, SIGUSR2);
							}
						}
						state = US_PICKUP;
					}
					else
						state = US_REDRAW;
				}
				break;
#endif

			case 'k':	/* ���a�J��X�h */
/*          case 'u':        �u�W�ק� user data */
				if (!HAS_PERM(PERM_SYSOP))
					continue;

			case 't':
			case 'w':
/*      
   if (!HAS_PERM(PERM_PAGE))
*/   
				if (curuser.userlevel < 20)
					continue;
			case 'a':
			case 'd':
			case 'f':
			case 'm':
/*                      
   case 'o':
 */
			case 'x':	/* Xshadow : for read mail hot key */

				if (!curuser.userlevel)		/* guest �u�� query ? */
					break;
				if (ch == 'f')
				{
/*      
   curuser.uflag ^= FRIEND_FLAG;
 */
					list_friend = (list_friend) ? NA : YEA;
					state = US_PICKUP;
					break;
				}


			case 'l':
			case 'q':
				uentp = pklist[num].ui;

			case 'h':
				state = US_ACTION;
				break;

			case 's':	/* refresh user state */
				state = US_PICKUP;
			}
		}

		if (state != US_ACTION)
			continue;

		if (ch == 'w')
		{
			cursor_show(num + 3 - head, 0);
			my_write(uentp);
			state = US_REDRAW;
			continue;
		}
		else if (ch == 'l')
		{		
			ReplyLastCall();
			state = US_REDRAW;
			continue;
		}
		else
		{
			move(1, 0);
			clrtobot();
			move(2, 0);

			switch (ch)
			{
			case 'x':
				m_read();
				break;

			case 'a':
				FriendAdd(uentp->userid);
				friends_number = FriendLoadCache();
				state = US_PICKUP;
				break;

			case 'd':
				FriendDelete(uentp->userid);
				friends_number = FriendLoadCache();
				state = US_PICKUP;
				break;

/*
   case 'o':
   t_override();
   state = US_PICKUP;
   break;
 */

			case 'k':
				if (uentp->pid && (kill(uentp->pid, 0) != -1))
				{
					my_kick(uentp);
					state = US_PICKUP;
				}
				break;

#if 0
			case 'u':	/* Thor: �i�u�W�d�ݤέק�ϥΪ� */
				{
					int id;
					userec muser;
					stand_title("�ϥΪ̳]�w");
					move(1, 0);
					if (id = getuser(uentp->userid))
					{
						memcpy(&muser, &xuser, sizeof(muser));
						user_display(&muser, 1);
						uinfo_query(&muser, 1, id);
					}
				}
				break;
#endif

			case 'm':
				clear();	/* lasehu */
				prints("���H�H�G%s", uentp->userid);
				my_send(uentp->userid);
				break;

			case 'h':
				t_showhelp();
				break;

			case 'q':
				QueryUser(uentp->userid);
				break;

			case 't':
				if (strcmp(uentp->userid, curuser.userid))
				{
					talk_user(uentp);
					state = US_PICKUP;
				}
			}
		}
/*              
   setutmpmode (savemode);
 */
	}
}


int
t_list()
{
	pickup_user();

	return M_FULL;
}


int
t_friends()
{
	friend_mode = YEA;
	pickup_user();
	friend_mode = NA;

	return M_FULL;
}


#if 0
char
pagerchar(ident, them, pager)	/* pager-char imply whether others accept my
				   paging */
     char *ident, *them;
     int pager;
{
	if (pager)
		return ' ';
	else if (can_override(them, ident))
		return 'O';
	else
		return '*';
}


int
printcuent(upent)
     USER_INFO *upent;
{
	short is_friend = NA;
	static int lineno;

	if (upent == NULL)
	{
		lineno = 2;
		move(lineno, 0);
		prints("%-12s %-20s %-15s %c %c %-20s\n",
		       "�^��N�W", "����W��", "�Ӧ�", 'P',
		       HAS_PERM(PERM_CLOAK) ? 'C' : ' ', "���A");

		lineno++;
		return 0;
	}
	if (lineno == b_line)
	{
		int ch;		/* ? */

		standout();
		outs("--�٦��@-- [q] or [��] : exit , [��] : ��U��");
		standend();
		while ((ch = igetkey()) != EOF)
		{
			if (ch == SP || ch == '\n' || ch == '\r' || ch == KEY_RIGHT || ch == KEY_PGDN)
				break;
			else if (ch == 'q' || ch == KEY_LEFT)
				return QUIT_LOOP;
		}
		lineno = 3;
		move(lineno, 0);
		clrtobot();
	}
	if (upent->userid[0] == '\0')	/* lasehu */
		return -1;
	is_friend = MyFriend(upent->userid);
	if (is_friend || !list_friend)
	{
		prints("%s%-12s %-20.20s %-15.15s %c %c %-20.20s[m\n",
		       (is_friend && !list_friend) ? "[1;36m" : "\0",
		       upent->userid, upent->username, upent->from,
		     pagerchar(curuser.userid, upent->userid, upent->pager),
		       (upent->invisible) ? '#' : ' ',
		       modestring(upent, 1));
		lineno++;
	}
	return 0;
}

int
t_users()
{
	list_friend = NA;
	printcuent(NULL);
	apply_ulist(printcuent);
	clrtobot();
	pressreturn();
	return M_FULL;
}


int
t_friends()
{
	struct stat st;

	if (stat(ufile_overrides, &st) || !st.st_size)
	{
		move(2, 0);
		clrtoeol();
		outs("-�|���]�w�n�ͦW��-");
	}
	else
	{
		list_friend = YEA;
		printcuent(NULL);
		apply_ulist(printcuent);
		clrtobot();
	}
	pressreturn();
	return M_FULL;
}
#endif


#if 0
int
t_talk()
{
	char uident[16];
	int tuid, unum, ucount;
	USER_INFO *uentp;

	if (count_ulist() <= 1)
	{
		outs("�ثe�u�W�u���z�@�H�A���ܽЪB�ͨӥ��{�i" BOARDNAME "�j�a�I");
		return XEASY;
	}
	stand_title("���}�ܧX�l");
	creat_list();
	namecomplete(msg_uid, uident);
	if (uident[0] == '\0')
		return 0;

	move(3, 0);
	if (!(tuid = searchuser(uident)) || tuid == usernum)
	{
		outs(err_uid);
		pressreturn();;
		return 0;
	}

	/* ----------------- */
	/* multi-login check */
	/* ----------------- */

	unum = 1;
	while ((ucount = count_logins(cmpuids, tuid, 0)) > 1)
	{
		outs("(0) ���Q talk �F...\n");
		count_logins(cmpuids, tuid, 1);
		getdata(1, 33, "�п�ܤ@�Ӳ�ѹ�H [0]�G", genbuf, 4, DOECHO);
		unum = atoi(genbuf);
		if (unum == 0)
			return 0;
		move(3, 0);
		clrtobot();
		if (unum > 0 && unum <= ucount)
			break;
	}

	if (uentp = (USER_INFO *) search_ulistn(cmpuids, tuid, unum))
		my_talk(uentp);

	return 0;
}


/* ------------------------------------- */
/* ���H�Ӧ���l�F�A�^���I�s��            */
/* ------------------------------------- */


USER_INFO *uip;


static int
setpagerequest()
{
	uip = (USER_INFO *) search_ulist(cmpunums, usernum);
	if (uip && uip->sockactive)
	{
		if (uinfo.mode != TALK)
			currutmp->destuid = uip->uid;
		sprintf(page_requestor, "%s (%s)", uip->userid, uip->username);
		return 0;
	}
	return 1;
}


int
servicepage(line, msg)
     int line;
     char *msg;
{
	static time_t last_check;
	time_t now;
	char buf[STRLEN];

	uip = (USER_INFO *) search_ulist(cmpunums, usernum);
	if (!uip || !uip->sockactive)
		talkrequest = NA;
	if (!talkrequest)
	{
		if (page_requestor[0])
		{
			if (uinfo.mode == TALK)
			{
				move(line, 0);
				clrtoeol();
				outs(msg);
			}
			else
			{	/* a chat mode */
				sprintf(buf, "�� %s �w����I�s", page_requestor);
				printchatline(buf);
			}
			memset(page_requestor, 0, sizeof(page_requestor));
			last_check = 0;
		}
		return NA;
	}
	else
	{
		now = time(0);
		if (now - last_check > P_INT)
		{
			last_check = now;
			if (!page_requestor[0] && setpagerequest())
				return NA;
			else
			{
				sprintf(buf, "�� %s ���b�I�s�z", page_requestor);
				if (uinfo.mode == TALK)
				{
					move(line, 0);
					clrtoeol();
					outs(buf);
				}
				else	/* chat */
					printchatline(buf);
			}
		}
	}
	return YEA;
}


void
talkreply()
{
	int a;
	struct hostent *h;
	char hostname[STRLEN], buf[4], msgbuf[60];
	struct sockaddr_in sin;
	int i;

	talkrequest = NA;
	if (setpagerequest())
		return;

	uinfo.mode = XMODE;	/* �קK�X�{�ʵe */

	clear();
	outs("\n\n\
       (Y) ���ڭ� talk �a�I   (2) �ڲ{�b�ܦ��A�е��@�|��A call ��\n\
       (N) �ڲ{�b���Q talk    (3) �藍�_�A�ڦ��Ʊ������A talk\n\
       (1) [1;33m�ڦ��ܭn�� ....[0m    (4) �A�u���ܷСA�ڹ�b���Q��A talk\n\n");

	getuser(uip->userid);
	prints("���Ӧ� [%s]�A�@�W�� %d ���A�峹 %d �g\n",
	       uip->from, xuser.numlogins, xuser.numposts);
	showplans(uip->userid);
	sprintf(genbuf, "�A�Q�� %s ���ѶܡH�п��(Y/N/1/2/3/4)[Y] ", page_requestor);
	getdata(0, 0, genbuf, buf, 4, LCECHO);

	strcpy(save_page_requestor, page_requestor);
	memset(page_requestor, 0, sizeof(page_requestor));
	gethostname(hostname, STRLEN);

	if (!(h = gethostbyname(hostname)))
	{
		perror("gethostbyname");
		return;
	}
	memset(&sin, 0, sizeof sin);
	sin.sin_family = h->h_addrtype;
	memcpy(&sin.sin_addr, h->h_addr, h->h_length);
	sin.sin_port = uip->sockaddr;
	a = socket(sin.sin_family, SOCK_STREAM, 0);
	if ((connect(a, (struct sockaddr *) &sin, sizeof sin)))
	{
		perror("connect err");
		return;
	}
	if (!buf[0] || !strchr("1234n", buf[0]))
		buf[0] = 'y';

	write(a, buf, 1);

	if (buf[0] == '1')
	{
		if (!getdata(b_line, 0, "���� talk ����]�G", msgbuf, 60, DOECHO))
			strcpy(msgbuf, "���i�D�A�� !! ^o^");
		write(a, msgbuf, 60);
	}

	if (buf[0] == 'y')
	{
		do_talk(a);
	}

#ifdef LINUX
	else
	{
		talkrequest = NA;	/* added 4 linux by achen.... */
	}
#endif

	close(a);
	clear();
}


int
shortulist(uentp)
     USER_INFO *uentp;
{
	static int lineno, fullactive, linecnt;
	static int moreactive, page, num;
	char uentry[50];
	int state;

	if (!lineno)
	{
		lineno = 3;
		page = moreactive ? (page + p_lines * 3) : 0;
		linecnt = num = moreactive = 0;
		move(1, 70);
		prints("Page: %d", page / (p_lines) / 3 + 1);
		move(lineno, 0);
	}
	if (uentp == NULL)
	{
		int finaltally;

		clrtoeol();
		move(++lineno, 0);
		clrtobot();
		finaltally = fullactive;
		lineno = fullactive = 0;
		return finaltally;
	}
	if (!HAS_PERM(PERM_CLOAK) && uentp->invisible)
	{
		if (lineno >= b_line)
			return 0;
		if (num++ < page)
			return 0;
		memset(uentry, ' ', 25);
		uentry[25] = '\0';
	}
	else
	{
		fullactive++;
		if (lineno >= b_line)
		{
			moreactive = 1;
			return 0;
		}
		if (num++ < page)
			return 0;

		state = is_friend(uentp);

		sprintf(uentry, "%s %-13s%c%-10s%s", fcolor[state],
			uentp->userid, uentp->invisible ? '#' : ' ',
			modestring(uentp, 1), state ? "[0m" : "");
	}
	if (++linecnt < 3)
	{
		strcat(uentry, "�x");
		outs(uentry);
	}
	else
	{
		outs(uentry);
		linecnt = 0;
		clrtoeol();
		move(++lineno, 0);
	}
	return 0;
}


static void
do_list(modestr)
     char *modestr;
{
	int count;

	showtitle(modestr, BoardName);
	if (uinfo.mode == MONITOR)
		prints("�C�j %d ����s�@���A�Ы�[Ctrl-C]��[Ctrl-D]���}", M_INT);

	outc('\n');
	outs(msg_shortulist);

	friends_number /* = override_number */  = 0;
	if (apply_ulist(shortulist) == -1)
	{
		outs(msg_nobody);
	}
	else
	{
		time_t thetime = time(NULL);

		count = shortulist(NULL);
		move(b_line, 0);
/*    
   prints("[1;37;46m  �W���`�H�ơG%-7d[32m�ڪ��B�͡G%-6d"
   "[33m�P�ڬ��͡G%-8d[30m%-23s[37;40;0m",
   count, friends_number, override_number, Cdate(&thetime));
 */
		prints("[1;37;46m  �W���`�H�ơG%-7d[32m�ڪ��B�͡G%-6d"
		       "                  %-23s[37;40;0m",
		       count, friends_number, Cdate(&thetime));

		refresh();
	}
}



int idle_monitor_time;

static void
sig_catcher()
{
	if (uinfo.mode != MONITOR)
	{

#ifdef DOTIMEOUT
		init_alarm();
#else
		signal(SIGALRM, SIG_IGN);
#endif

		return;
	}
	if (signal(SIGALRM, sig_catcher) == SIG_ERR)
	{
		perror("signal");
		exit(1);
	}

#ifdef DOTIMEOUT
	idle_monitor_time += M_INT;
	if (idle_monitor_time > MONITOR_TIMEOUT)
	{
		clear();
		fprintf(stderr, "timeout\n");
		abort_bbs();
	}
#endif

	do_list("�l�ܯ���");
	alarm(M_INT);
}



/* ------------------------------------- */
/* �n�ͦW��B�¦W��                      */
/* ------------------------------------- */


static int
load_uid_list(ulist, fname, max)
     ushort ulist[];
     char *fname;
     int max;
{
	FILE *fp;
	int count;

	count = 0;
	setuserfile(genbuf, fname);
	if (fp = fopen(genbuf, "r"))
	{
		int unum;

		while (fgets(genbuf, STRLEN, fp))
		{
			if (strtok(genbuf, str_space))
			{
				if (unum = searchuser(genbuf))
				{
					ulist[count] = (ushort) unum;
					if (++count >= max)
						break;
				}
			}
		}
		fclose(fp);
	}
	ulist[count] = 0;
	return count;
}


#endif
