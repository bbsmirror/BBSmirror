
#include "bbs.h"

#define DEL_USER0	(30)	/* �� */
#define DEL_USER50	(90)	/* �� */
#define DEL_USER100	(365)	/* �� */

#define DEL_HOME	"home/.del"
#define DEL_MAIL	"mail/.del"
#define RPT_BOARD	"user-stat"

#define RPT_DELUSER	"log/rpt.deluser"
#define RPT_BM		"log/rpt.bm"
#define RPT_SYSOP	"log/rpt.sysop"

char *bbshome;
time_t now, duser0, duser50, duser100;
int total_user, total_bm, total_sysop, total_del, total_ident;


int CheckDir()
{
	struct stat st;
	if(stat(DEL_HOME, &st))
	{
		if(mkdir(DEL_HOME, 0700) || chown(DEL_HOME, BBS_UID, BBS_GID))
			return -1;
	}
	else if(!S_ISDIR(st.st_mode))
		return -1;
	if(stat(DEL_MAIL, &st))
	{
		if(mkdir(DEL_MAIL, 0700) || chown(DEL_MAIL, BBS_UID, BBS_GID))
			return -1;
	}
	else if(!S_ISDIR(st.st_mode))
		return -1;
	return 0;
}



int IsExpire(u)
struct userec *u;
{
	if(u->lastlogin > duser0)
		return 0;
	else if(u->userlevel == 255)
		return 0;
	else if(u->userlevel >= 100)
	{
		if(u->lastlogin < duser100)
			return 1;
	}
	else if(u->userlevel >= 50)
	{
		if(u->lastlogin < duser50)
			return 1;
	}
	else
	{
		if(u->lastlogin < duser0)
			return 1;
	}
	return 0;
}



int DelUser()
{
	char aha[] = "0abcdefghijklmnopqrstuvwxyz";
	DIR *dirp;
	struct dirent *dent;
	char id[IDLEN+2];
	char path[512], path2[512];
	char upath[80], ppath[80];
	int i, fd, fdi, fdp, expire;
	FILE *fpr, *fpbm, *fpsys;
	struct userec user;

	for(i = 0; i < 27; i++)
	{
		sprintf(path, "%s/%c", DEL_HOME, aha[i]);
		mkdir(path, 0700);
		chown(path, BBS_UID, BBS_GID);
		sprintf(path, "%s/%c", DEL_MAIL, aha[i]);
		mkdir(path, 0700);
		chown(path, BBS_UID, BBS_GID);
	}

	sprintf(upath, "%s.new", USERIDX);
	sprintf(ppath, "%s.new", PASSFILE);
	unlink(upath);
	unlink(ppath);
	if((fdi = open(upath, O_WRONLY|O_CREAT, 0644)) < 0)
		return -1;
	if((fdp = open(ppath, O_WRONLY|O_CREAT, 0644)) < 0)
	{
		close(fdi);
		return -1;
	}
	fpr = fopen(RPT_DELUSER, "w");
	fpbm = fopen(RPT_BM, "w");
	fpsys = fopen(RPT_SYSOP, "w");
	fprintf(fpr, "Date: %s", ctime(&now));
	fprintf(fpbm, "Date: %s", ctime(&now));
	fprintf(fpsys, "Date: %s", ctime(&now));
	for(i = 0; i < 27; i++)
	{
		memset(path, '\0', sizeof(path));
		sprintf(path, "home/%c", aha[i]);
		if(!(dirp = opendir(path)))
			continue;
		readdir(dirp);	/* skip . & .. */
		readdir(dirp);
		while(dent = readdir(dirp))
		{
			if(dent->d_name[0])
			{
				expire = 0;
				memset(id, '\0', sizeof(id));
				strncpy(id, dent->d_name, sizeof(id) - 1);
				memset(path, '\0', sizeof(path));
				sprintf(path, "home/%c/%s/passwds", aha[i], id);
				if((fd = open(path, O_RDONLY)) < 0)
				{
					fprintf(fpr, "Error:[%s] no file\n", id);
					expire = 2;
				}
				else
				{
					if(read(fd, &user, sizeof(user)) != sizeof(user))
					{
						fprintf(fpr, "Error:[%s] size err\n", id);
						expire = 3;
					}
					else
					{
						if((expire = IsExpire(&user)) == 0)
						{
							total_user++;
							if(user.ident == 7)
								total_ident++;
						}
					}
					close(fd);
				}
				if(expire)
				{
					sprintf(path, "home/%c/%s", aha[i], id);
					sprintf(path2, "%s/%c/%s", DEL_HOME, aha[i], id);
					if(rename(path, path2))
						fprintf(fpr, "Error:[%s] rename\n", id);
					else
					{
						sprintf(path, "mail/%c/%s", aha[i], id);
						sprintf(path2, "%s/%c/%s", DEL_MAIL, aha[i], id);
						rename(path, path2);
						if(expire == 1)
							fprintf(fpr, "[%s] level:[%d]  %s", id,
								user.userlevel, ctime(&(user.lastlogin)));
						else
							fprintf(fpr, "[%s] clean err.%d\n", id, expire);
						total_del++;
						continue;
					}
				}
				if(user.userlevel >= 255)
				{
					total_sysop++;
					fprintf(fpsys, "%s %d\n", id, user.userlevel);
				}
				else if(user.userlevel >= 100)
				{
					total_bm++;
					fprintf(fpbm, "%s %d\n", id, user.userlevel);
				}
				write(fdi, user.userid, sizeof(user.userid));
				write(fdp, &user, sizeof(user));
			}
		}
		closedir(dirp);
	}
	close(fdi);
	close(fdp);
	fprintf(fpr, "\n������������������������������\n");
	fprintf(fpr, "�R���H��: %d\n", total_del);
	fprintf(fpr, "�{�b�H��: %d\n", total_user);
	fprintf(fpr, "�{�ҤH��: %d\n", total_ident);
	fprintf(fpr, "���D�H��: %d\n", total_bm);
	fprintf(fpr, "�����H��: %d\n", total_sysop);
	fclose(fpr);
	fclose(fpbm);
	fclose(fpsys);
	chown(upath, BBS_UID, BBS_GID);
	chown(ppath, BBS_UID, BBS_GID);
	unlink(USERIDX);
	rename(upath, USERIDX);
	unlink(PASSFILE);
	rename(ppath, PASSFILE);
	return 0;
}



int PostRpt()
{
	struct fileheader fh;
	char path[80], today[40], buf[4096], *p;
	struct stat st;
	int lastnum, fd, fd2, fd3, cc;
	char star[] = "������������������������������";

	sprintf(path, "boards/%s", RPT_BOARD);
	if(stat(path, &st))
		return -1;
	p = strlen(path) + path;
	*p++ = '/';
	strcpy(p, ".DIR");
	if((fd = open(path, O_RDWR|O_CREAT, 0644)) < 0)
		return -1;
	if(lseek(fd, -sizeof(fh), SEEK_END) > 0
			&& read(fd, &fh, sizeof(fh)) == sizeof(fh))
		lastnum = fh.artno + 1;
	else
	{
		lastnum = 1;
		chown(path, BBS_UID, BBS_GID);
	}
	memset(&fh, '\0', sizeof(fh));
	sprintf(fh.filename, "M.%d.A", time(0));
	fh.artno = lastnum++;
	fh.owner_ident = 7;
	strcpy(fh.owner, "SYSOP");
	sprintf(today, "%s", ctime(&now));
	today[strlen(today) - 1] = '\0';
	sprintf(fh.title, "�ϥΪ̧R�����i  %s", today);
	lseek(fd, 0, SEEK_END);
	write(fd, &fh, sizeof(fh));
	close(fd);
	strcpy(p, fh.filename);
	if((fd2 = open(path, O_WRONLY|O_CREAT, 0644)) > 0)
	{
		chown(path, BBS_UID, BBS_GID);
		sprintf(buf, "�o�H�H�G SYSOP (�t�κ޲z��)    �ݪO�G%s\n", RPT_BOARD);
		write(fd2, buf, strlen(buf));
		sprintf(buf, "����G %s\n", today);
		write(fd2, buf, strlen(buf));
		sprintf(buf, "���D�G %s\n\n", fh.title);
		write(fd2, buf, strlen(buf));
		if((fd3 = open(RPT_DELUSER, O_RDONLY)) > 0)
		{
			while((cc = read(fd3, buf, sizeof(buf))) > 0)
				write(fd2, buf, cc);
			close(fd3);
		}
		sprintf(buf, "\n%s\n���D���i�G\n", star);
		write(fd2, buf, strlen(buf));
		if((fd3 = open(RPT_BM, O_RDONLY)) > 0)
		{
			while((cc = read(fd3, buf, sizeof(buf))) > 0)
				write(fd2, buf, cc);
			close(fd3);
		}
		sprintf(buf, "\n%s\n�������i�G\n", star);
		write(fd2, buf, strlen(buf));
		if((fd3 = open(RPT_SYSOP, O_RDONLY)) > 0)
		{
			while((cc = read(fd3, buf, sizeof(buf))) > 0)
				write(fd2, buf, cc);
			close(fd3);
		}
		close(fd2);
		return 0;
	}
	return -1;
}




void main(argc, argv)
int argc;
char *argv[];
{
	if(argc == 1)
	{
		printf("Usage: %s [BBSHomeDir] [��(50�ťH�U)] [��(50��)] [��(100��)]\n",argv[0]);
		printf("Default: %s /apps/bbs 30 90 365\n", argv[0]);
		exit(0);
	}
	if(getuid())
	{
		printf("Please run me as SuperUser\n");
		exit(0);
	}
	if(argc > 1)
		bbshome = argv[1];
	else
		bbshome = HOMEBBS;
	if(argc > 2)
		duser0 = atoi(argv[2]);
	else
		duser0 = DEL_USER0;
	if(argc > 3)
		duser50 = atoi(argv[3]);
	else
		duser50 = DEL_USER50;
	if(argc > 4)
		duser100 = atoi(argv[4]);
	else
		duser100 = DEL_USER100;
	now = time(0);
	if((duser0 = now - (duser0 * 24 * 60 * 60)) <= 0)
		exit(-1);
	if((duser50 = now - (duser50 * 24 * 60 * 60)) <= 0)
		exit(-1);
	if((duser100 = now - (duser100 * 24 * 60 * 60)) <= 0)
		exit(-1);
	if(chroot(bbshome) || chdir("/"))
		exit(-1);
	if(CheckDir())
		exit(-1);
	total_user = total_bm = total_sysop = total_del = total_ident = 0;
	DelUser();
	PostRpt();
	return;
}
