/*******************************************************************
 * ���s�j�� NSYSU BBS <--> News Server �H���y�{��  v1.0
 *
 * �\��G
 *     1. �@�� bbs board ��h�� news groups ���ǫH��.
 *     2. �@�� news group ��h�� bbs boards ���ǫH��.
 *
 * Coder: �����    lmj@cc.nsysu.edu.tw
 *                  (wind.bbs@bbs.nsysu.edu.tw)
 *
 *******************************************************************/

#ifndef BUF_SIZE
#define BUF_SIZE		6400
#endif

struct	Config	{
	int		port;
	int		io_timeout;
	int		retry_sec;
	int		rest_sec;
	short	esc_filter;
	short	update_board;
	char	myip[16];
	char	myhostname[80];
	char	mynickname[80];
	char	server[16];
	char	sister[32];
	char	organ[80];
	char	deltime[80];
};

struct	BNLink	{
	char	board[80];
	char	newsgroup[160];
	char	type;
	char	region;
	char	get;
	char	expire;
	char	cancel;
	long	num;
	struct	BNLink	*next;
};


struct  NameList    {
	char    *list;
	struct  NameList    *next;
};
