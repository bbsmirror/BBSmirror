
#include "bbs.h"


int 
menushow_parsefile (path, list)
     char *path;
     struct MSList *list;
{
	FILE *fp;
	char *p1, *p2, line[512];
	char owner[80], title[80];
	char buf[sizeof(list->body)];

	if ((fp = fopen (path, "r")) == (FILE *) NULL)
		return -1;
	memset (list, '\0', sizeof (struct MSList));
	memset (owner, '\0', sizeof (owner));
	memset (title, '\0', sizeof (title));
	while (fgets (line, sizeof (line), fp))
	{
		if (line[0] == '\n' || line[0] == '\r')
			break;
		else if (!(*owner) && !strncmp (line, "�o�H�H�G", 8))
		{
			p1 = line + 8;
			if (p2 = strchr (p1, ')'))
				*(++p2) = '\0';
			else if (p2 = strrchr (p1, '\n'))
			{
				*p2-- = '\0';
				if (*p2 == '\r')
					*p2 = '\0';
			}
			strncpy (owner, p1, sizeof (owner));
		}
		else if (!(*title) && !strncmp (line, "���D�G", 6))
		{
			p1 = line + 6;
			if (p2 = strrchr (p1, '\n'))
			{
				*p2-- = '\0';
				if (*p2 == '\r')
					*p2 = '\0';
			}
			strncpy (title, p1, sizeof (title));
		}
	}
	fread (buf, sizeof(buf), 1, fp);
	for (p1 = buf + sizeof(buf) - 1; *p1 != '\n'; p1--)
		*p1 = '\0';
	for (p1 = buf; *p1 == '\n' || *p1 == '\r'; p1++)
		/* empty line */ ;
	strncpy (list->body, p1, sizeof(list->body));
	strncpy (list->path, path, sizeof (list->path));
	sprintf (buf, "�m�@�̡n%s  �m���D�n%s", owner, title);
	sprintf (list->header, "[7m%-78.78s [m", buf);
	fclose (fp);
	return 0;
}




int 
menushow_dir (path, msshm, list)
     char *path;
     struct MenuShowShm *msshm;
     struct MSList *list;
{
	int fd;
	char *p, in_board = 0;
	struct fileheader fh;

	if (strstr (path, "boards/"))
		in_board++;
	p = path + strlen (path);
	strcpy (p, "/.DIR");
	p++;
	if ((fd = open (path, O_RDONLY)) < 0)
		return -1;
	while (read (fd, &fh, sizeof (fh)) == sizeof (fh))
	{
		if (in_board)
		{
			if (!(fh.accessed & FILE_RESRV) || (fh.accessed & FILE_DELE))
				continue;
		}
		else if (fh.accessed & FILE_TREA)
			continue;
		strcpy (p, fh.filename);
		if (menushow_parsefile (path, list))
			continue;
		list++;
		msshm->number++;
		if (msshm->number == MENUSHOW_SIZE)
			break;
	}
	close (fd);
	return 0;
}


struct MenuShowShm *msshm = NULL;

int 
menushow (msfile)
     char *msfile;
{
	FILE *fp;
	char *p, path[128];

	if (!msshm)
		msshm = (struct MenuShowShm *) attach_shm (MENUSHOW_KEY, sizeof (struct MenuShowShm));
	memset (msshm, '\0', sizeof (struct MenuShowShm));
	if ((fp = fopen (msfile, "r")) == (FILE *) NULL)
	{
		int i = menushow_dir (MENUSHOW_DEFAULT, msshm, &(msshm->list[0]));
		if (i == 0)
			msshm->flag = 1;
		return i;
	}
	memset (path, '\0', sizeof (path));
	while (fgets (path, sizeof (path), fp))
	{
		if (p = strrchr (path, '\n'))
		{
			*(p--) = '\0';
			if (*p == '\r')
				*p = '\0';
		}
		menushow_dir (path, msshm, &(msshm->list[msshm->number]));
		memset (path, '\0', sizeof (path));
	}
	fclose (fp);
	msshm->flag = 1;
	return 0;
}




void 
main (argc, argv)
     int argc;
     char *argv[];
{
	int fdd, timer;

	if (argc < 2)
	{
		printf ("Usage: %s RefleshSeconds\n", argv[0]);
		printf ("Example: %s 600 (�C 600 ���۰ʧ�s�ARun as Daemon)\n", argv[0]);
		printf ("Example: %s 0   (��s�@���ᵲ���ACall by Crontab)\n", argv[0]);
		exit (0);
	}
	if ((timer = atoi (argv[1])) < 300 && timer != 0)
	{
		printf ("The %d seconds timer is too fast!!\n", timer);
		exit (0);
	}
	if (timer)
	{
		if (fork ())
			exit (0);
		for (fdd = 64; fdd >= 0; fdd--)
			close (fdd);
		if ((fdd = open ("/dev/null", O_RDWR)) > 0)
		{
			if (fdd != 0)
			{
				dup2 (fdd, 0);
				close (fdd);
			}
			dup2 (0, 1);
			dup2 (0, 2);
		}
	}
#ifdef CHROOT_BBS
	if (chroot (HOMEBBS) || chdir ("/"))
#else
	if (chdir (HOMEBBS))
#endif
		exit (1);
	setgid (BBS_GID);
	setuid (BBS_UID);
	while (1)
	{
		if (menushow (MENUSHOW_FILE))
			exit (2);
		if (timer)
			sleep (timer);
		else
			break;
	}
	return;
}
