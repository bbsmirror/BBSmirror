
/*******************************************************************
 * NSYSU BBS <--> News Server �H���y�{��  v1.0
 *
 * �\��G
 *     1. �@�� bbs board ��h�� news groups ���ǫH��.
 *     2. �@�� news group ��h�� bbs boards ���ǫH��.
 *
 * Coder: �����    lmj@cc.nsysu.edu.tw
 *                  (wind.bbs@bbs.nsysu.edu.tw)
 *
 *******************************************************************/

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/file.h>
#include "config.h"
#include "struct.h"
#include "bbs-news.h"
#include "net.h"

#include <signal.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>
#include <varargs.h>


#ifndef LOCK_EX   
# define LOCK_EX               F_LOCK     /* exclusive lock */
# define LOCK_UN               F_ULOCK    /* unlock */
#endif

#define B_N_PID_FILE		"/news/bbs-news.pid"

#undef DEBUG

/*******************************************************************
 * �ɤ��ܼƫŧi
 *******************************************************************/
char    genbuf[4096], genbuf2[4096];
int     sd;
short   booting = 0, can_post;
struct Config conf;
struct BNLink *bntop, *bnend, *bncur;
struct NameList *badstop, *badsend, *badscur, *bbsstop, *bbssend, *bbsscur, *badutop,
       *baduend, *baducur;

int     sisterlen;

int     io_timeout_sec;



char   *
mygets(buf, bsize, fp)
char   *buf;
int     bsize;
FILE   *fp;
{
	char   *p;

	if (fgets(buf, bsize, fp))
	{
		if ((p = strrchr(buf, '\n')) && p > buf && *(--p) == '\r')
		{
			*p++ = '\n';
			*p = '\0';
		}
		return buf;
	}
	else
		return NULL;
}


/*******************************************************************
 * ��l�� conf �]�w
 *******************************************************************/
void
init_conf()
{
	bntop = (struct BNLink *) malloc(sizeof(struct BNLink));
	bnend = (struct BNLink *) malloc(sizeof(struct BNLink));
	bntop->next = bnend->next = bnend;
	bncur = bntop;

	badstop = (struct NameList *) malloc(sizeof(struct NameList));
	badsend = (struct NameList *) malloc(sizeof(struct NameList));
	badstop->next = badsend->next = badsend;
	badscur = badstop;

	bbsstop = (struct NameList *) malloc(sizeof(struct NameList));
	bbssend = (struct NameList *) malloc(sizeof(struct NameList));
	bbsstop->next = bbssend->next = bbssend;
	bbsscur = bbsstop;

	badutop = (struct NameList *) malloc(sizeof(struct NameList));
	baduend = (struct NameList *) malloc(sizeof(struct NameList));
	badutop->next = baduend->next = baduend;
	baducur = badutop;

	bzero(&conf, sizeof(conf));
}


/*******************************************************************
 * �M�� conf ������ƻP�}�C
 *******************************************************************/
void
clean_conf()
{
	for (bncur = bntop->next; bncur != bnend; bncur = bncur->next)
		free(bncur);
	free(bntop);
	free(bnend);
	for (badscur = badstop->next; badscur != badsend; badscur = badscur->next)
	{
		free(badscur->list);
		free(badscur);
	}
	free(badstop);
	free(badsend);
	for (bbsscur = bbsstop->next; bbsscur != bbssend; bbsscur = bbsscur->next)
	{
		free(bbsscur->list);
		free(bbsscur);
	}
	free(bbsstop);
	free(bbssend);
	for (baducur = badutop->next; baducur != baduend; baducur = baducur->next)
	{
		free(baducur->list);
		free(baducur);
	}
	free(badutop);
	free(baduend);
}


/*******************************************************************
 * ���X bad_site, bbs_site, bad_user ���U�ئC��
 *******************************************************************/
struct NameList *
make_list(curr, line)
struct NameList *curr;
char    line[];
{
	struct NameList *new;
	int     i = 0;

	new = (struct NameList *) malloc(sizeof(struct NameList));

	while (line[i] != TAB && line[i] != SP && line[i] != NL && line[i] != '\0')
		i++;
	line[i++] = '\0';
	new->list = (char *) malloc(i);
	strcpy(new->list, line);
	new->next = curr->next;
	curr->next = new;
	return new;
}


/*******************************************************************
 * �q�@�q�r�ꤤ���X�@�r��, ���� '\n' or '\0':
 * �p�G buf == NULL, �Ǧ^�l�r���}
 *******************************************************************/
char   *
get_str(begin, buf, len)
char   *begin, *buf;
int     len;
{
	char   *p;

	if (!begin)
		return (char *) NULL;
	while (*begin == SP || *begin == TAB)
		begin++;
	if (*begin == NL || *begin == '\0')
		return (char *) NULL;
	if (buf)
	{
		bzero(buf, len);
		strncpy(buf, begin, len - 1);
	}
	else
	{
		buf = (char *) malloc(strlen(begin) + 1);
		strcpy(buf, begin);
	}
	if ((p = strchr(buf, '\n')) != NULL)
		*p = '\0';
	return buf;
}


/*******************************************************************
 * �q�@�q�r�ꤤ���X�@���l�r��:
 * �p�G buf == NULL, �Ǧ^�l�r���}
 * �_�h�Ǧ^�U�@���l�r�ꪺ�_�I
 *******************************************************************/
char   *
get_var(begin, buf, len)
char   *begin, *buf;
int     len;
{
	char   *end, *bend;

	if (!begin)
		return (char *) NULL;
	while (*begin == SP || *begin == TAB)
		begin++;
	if (*begin == NL || *begin == '\0')
		return (char *) NULL;
	end = begin;
	while (*end != SP && *end != TAB && *end != NL && *end != '\0')
		end++;
	if (begin == end)
		return (char *) NULL;
	if (!buf)
	{
		buf = (char *) malloc(end - begin + 1);
		*end = '\0';
		strcpy(buf, begin);
		return buf;
	}
	bend = buf + len - 1;
	while (begin < end && buf < bend)
		*buf++ = *begin++;
	*buf = '\0';
	return end;
}


/*******************************************************************
 * �q�@�Ӧr�ꤤ���o�@���ƭ�
 *******************************************************************/
long
get_vul(begin)
char   *begin;
{
	char   *end;

	if (!begin)
		return 0;
	while (*begin != '\0' && (*begin < 0x30 || *begin > 0x39))
		begin++;
	if (*begin == '\0')
		return 0;
	end = begin;
	while (*end > 0x29 && *end < 0x40)
		end++;
	*end = '\0';
	if (begin == end)
		return 0;
	return atol(begin);
}


/*******************************************************************
 * ���R conf file �� board <--> newsgroup ���������Y
 *******************************************************************/
struct BNLink *
make_bnlink(line)
char    line[];
{
	char   *p;
	struct BNLink *new;

	new = (struct BNLink *) malloc(sizeof(struct BNLink));

	p = get_var(line, new->board, 80);
	p = get_var(p, new->newsgroup, 160);
	p = get_var(p, genbuf2, 10);
	if (!strcmp(genbuf2, "both"))
		new->type = 'B';
	else if (!strcmp(genbuf2, "input"))
		new->type = 'I';
	else if (!strcmp(genbuf2, "output"))
		new->type = 'O';
	else
		new->type = 'B';
	p = get_var(p, genbuf2, 10);
	p = get_var(p, genbuf2, 10);
	if (!strcmp(genbuf2, "yes"))
		new->get = 'Y';
	else
		new->get = 'N';
	p = get_var(p, genbuf2, 10);
	if (!strcmp(genbuf2, "yes"))
		new->expire = 'Y';
	else
		new->expire = 'N';
	p = get_var(p, genbuf2, 10);
	if (!strcmp(genbuf2, "yes"))
		new->cancel = 'Y';
	else
		new->cancel = 'N';
	new->num = get_vul(p);
	new->next = bncur->next;
	bncur->next = new;
	bncur = new;
	return new;
}


/*******************************************************************
 * �̷� bbs-news.conf �����e��� .BOARDS ���]�w.
 *******************************************************************/
int
update_board()
{
	struct boardheader bhead;
	int     fd;
	char    oldtype;


	if ((fd = open(BOARDS, O_RDWR)) < 0)
		return -1;
	while (read(fd, &bhead, sizeof(bhead)) == sizeof(bhead))
	{
		oldtype = bhead.type;
		bhead.type = '\0';
		for (bncur = bntop->next; bncur != bnend; bncur = bncur->next)
		{
			if (!strcmp(bhead.filename, bncur->board))
			{
				if (bncur->type == 'B')
					bhead.type = 'B';
				else if (bncur->type == 'I' && bhead.type != 'B')
				{
					if (bhead.type == '\0')
						bhead.type = 'I';
					else if (bhead.type == 'O')
						bhead.type = 'B';
				}
				else if (bncur->type == 'O' && bhead.type != 'B')
				{
					if (bhead.type == '\0')
						bhead.type = 'O';
					else if (bhead.type == 'I')
						bhead.type = 'B';
				}
			}
		}
		if ((bhead.type != oldtype
		     )
		    && lseek(fd, (long) (-sizeof(bhead)), SEEK_CUR) != -1)
		{
			write(fd, &bhead, sizeof(bhead));
		}
	}
	close(fd);
	return 0;
}


/*******************************************************************
 * Ū�J�ä��R /news/bbs-news.conf ���U�����ҳ]�w
 *******************************************************************/
int
read_conf()
{
	FILE   *fp;
	char    boot_run[8];

	if ((fp = fopen(B_N_CONFIG_FILE, "r")) == NULL)
		return -1;
	init_conf();
	while (mygets(genbuf, sizeof(genbuf), fp))
	{
		if (genbuf[0] == '#' || genbuf[0] == NL)
			continue;
		if (conf.myip[0] == '\0' && !strncmp(genbuf, "myip", 4))
			get_var(genbuf + 4, conf.myip, sizeof(conf.myip));
		else if (conf.myhostname[0] == '\0' && !strncmp(genbuf, "myhostname", 10))
			get_var(genbuf + 10, conf.myhostname, sizeof(conf.myhostname));
		else if (conf.mynickname[0] == '\0' && !strncmp(genbuf, "mynickname", 10))
			get_var(genbuf + 10, conf.mynickname, sizeof(conf.mynickname));
		else if (conf.server[0] == '\0' && !strncmp(genbuf, "server", 6))
			get_var(genbuf + 6, conf.server, sizeof(conf.server));
		else if (conf.sister[0] == '\0' && !strncmp(genbuf, "sister", 6))
		{
			get_var(genbuf + 6, conf.sister, sizeof(conf.sister));
			sisterlen = strlen(conf.sister);
		}
		else if (conf.port == 0 && !strncmp(genbuf, "port", 4))
			conf.port = (int) get_vul(genbuf + 4);
		else if (conf.organ[0] == '\0' && !strncmp(genbuf, "organ", 5))
			get_var(genbuf + 5, conf.organ, sizeof(conf.organ));
		else if (conf.io_timeout == 0 && !strncmp(genbuf, "io_timeout", 10))
			io_timeout_sec = conf.io_timeout = (int) get_vul(genbuf + 10);
		else if (conf.retry_sec == 0 && !strncmp(genbuf, "retry_sec", 9))
			conf.retry_sec = (int) get_vul(genbuf + 9);
		else if (conf.rest_sec == 0 && !strncmp(genbuf, "rest_sec", 8))
			conf.rest_sec = (int) get_vul(genbuf + 8);
		else if (!strncmp(genbuf, "esc_filter", 10))
		{
			get_var(genbuf + 10, boot_run, 8);
			if (!strcmp(boot_run, "yes"))
				conf.esc_filter = 1;
		}
		else if (!strncmp(genbuf, "update_board", 12))
		{
			get_var(genbuf + 12, boot_run, 8);
			if (!strcmp(boot_run, "yes"))
				conf.update_board = 1;
		}
		else if (conf.deltime[0] == '\0' && !strncmp(genbuf, "deltime", 7))
			get_str(genbuf + 7, conf.deltime, sizeof(conf.deltime));
		else if (!strncmp(genbuf, "[bnlink]", 8))
			break;
		if (!strncmp(genbuf, "boot_run", 8))
		{
			get_var(genbuf + 8, boot_run, 8);
/* lasehu: �Y�쥻�Y�H BBS ���楻�{��, �h����ä����� */
			if (strcmp(boot_run, "yes") && booting)
				exit(0);
		}
	}
	while (mygets(genbuf, sizeof(genbuf), fp))
	{
		if (genbuf[0] == '#' || genbuf[0] == NL)
			continue;
		if (!strncmp(genbuf, "[bad_site]", 10))
			break;
		make_bnlink(genbuf);
	}
	badscur = (struct NameList *) malloc(sizeof(struct NameList));

	badscur->list = (char *) malloc(strlen(conf.myhostname) + 1);
	strcpy(badscur->list, conf.myhostname);
	badscur->next = badsend;
	badstop->next = badscur;
	while (mygets(genbuf, sizeof(genbuf), fp))
	{
		if (genbuf[0] == '#' || genbuf[0] == NL)
			continue;
		if (!strncmp(genbuf, "[bbs_site]", 10))
			break;
		badscur = make_list(badscur, genbuf);
	}
	while (mygets(genbuf, sizeof(genbuf), fp))
	{
		if (genbuf[0] == '#' || genbuf[0] == NL)
			continue;
		if (!strncmp(genbuf, "[bad_user]", 10))
			break;
		bbsscur = make_list(bbsscur, genbuf);
	}
	while (mygets(genbuf, sizeof(genbuf), fp))
	{
		if (genbuf[0] == '#' || genbuf[0] == NL)
			continue;
		baducur = make_list(baducur, genbuf);
	}
	fclose(fp);
	if (conf.update_board)
	{
		update_board();
	}
	return 0;
}


/***************************************************************
 * �ֹ� news article �� from & sender
 ***************************************************************/
int
check_list(top, end, from)
struct NameList *top, *end;
char    from[];
{
	struct NameList *cur;
	int     lenf, lens;
	short   found = 0;

	lenf = strlen(from);
	for (cur = top->next; cur != end; cur = cur->next)
	{
		if ((lens = strlen(cur->list)) > lenf)
			continue;
		if (from[0] > 0x29 && from[0] < 0x40
		    && cur->list[0] > 0x29 && cur->list[0] < 0x40)
		{
			if (!strncmp(cur->list, from, lens))
			{
				found = 1;
				break;
			}
		}
		else if ((from[0] < 0x30 || from[0] > 0x39)
			 && (cur->list[0] < 0x30 || cur->list[0] > 0x39))
		{
			if (!strcasecmp(cur->list, (from + lenf - lens)))
			{
				found = 1;
				break;
			}
		}
	}
	return found;
}


/***************************************************************
 * ���ɦW�[�J�R����C��, ���ݳB�z
 ***************************************************************/
int
del_post(fnum)	
unsigned long fnum;
{
	int     fd, cc;
	char    fname[STRLEN], to[STRLEN];
	FILEHEADER fh;


	sprintf(genbuf2, "/news/record/%s.%-s/%-d",
		bncur->board, bncur->newsgroup, fnum);
	if ((fd = open(genbuf2, O_RDONLY)) < 0)
		return -1;
	if ((cc = read(fd, fname, STRLEN)) < 1)
	{
		close(fd);
		return -1;
	}
	close(fd);
	fname[cc] = '\0';
	sprintf(to, "/boards/%-s/%-s", bncur->board, fname);
	sprintf(genbuf, "/boards/%-s/%s", bncur->board, DIR_REC);
	if ((fd = open(genbuf, O_RDWR)) < 0)
		return -1;
	while (read(fd, &fh, sizeof(fh)) == sizeof(fh))
		if (!strcmp(fh.filename, fname))
		{
			if (lseek(fd, (long) (-sizeof(fh)), SEEK_CUR) != -1)
			{
				fh.accessed |= FILE_DELE;	/* lasehu */
				unlink(genbuf2);
				close(fd);
				return 0;
			}
			break;
		}
	close(fd);
	return -1;
}


/***************************************************************
 * ���� news server �O�_���«H�����, �Y���h�O�� Local Delete
 ***************************************************************/
int
check_cancel(first, last, cur)
unsigned long first, last, cur;
{
	DIR    *dirp;

#ifdef	NO_DIRENT
	struct direct *dirlist;

#else
	struct dirent *dirlist;

#endif
	unsigned long d, f = first;
	char   *p;
	struct stat st;

	if (first > cur)
		return -1;
	if (bncur->expire == YES)
	{
		sprintf(genbuf2, "/news/record/%s.%-s", bncur->board, bncur->newsgroup);
		if ((dirp = opendir(genbuf2)) != NULL)
		{
			readdir(dirp);
			readdir(dirp);
			while ((dirlist = readdir(dirp)) != NULL)
			{
				if (dirlist->d_name[0] == '\0')
					continue;
				if ((d = atol(dirlist->d_name)) >= first)
					continue;
				if (d < f)
					f = d;
				del_post(d);
			}
			closedir(dirp);
		}
		sprintf(genbuf2, "/news/record/%s.%-s/", bncur->board, bncur->newsgroup);
		p = strrchr(genbuf2, '/') + 1;
		for (; f < first; f++)
		{
			sprintf(p, "%-d", f);
			unlink(genbuf2);
		}
	}
	if (bncur->cancel != YES)
		return 0;
	for (; first <= cur; first++)
	{
		net_printf(sd, "STAT %-d\n", first);
		net_gets(sd, genbuf, sizeof(genbuf));
		if (strncmp(genbuf, "223", 3))
		{
			sprintf(genbuf2, "/news/record/%s.%-s/%-d",
				bncur->board, bncur->newsgroup, first);
			if (stat(genbuf2, &st) == 0)
			{
				del_post(first);
				unlink(genbuf2);
			}
		}
	}
	return 0;
}


/***************************************************************
 * �N news article �Ȧs�� post �� board
 ***************************************************************/
int
do_post(cur)
unsigned long cur;
{
	FILE   *fr, *fw;
	int     fb;
	char   *p, from[STRLEN], name[STRLEN], group[STRLEN], title[STRLEN], date[STRLEN],
	        organ[STRLEN], msgid[STRLEN], board[STRLEN];
	FILEHEADER fhead;

	bzero(&fhead, sizeof(fhead));
	from[0] = name[0] = group[0] = title[0] = date[0] = organ[0] = msgid[0] = board[0] = '\0';
	if ((fr = fopen("/news/input/tmpfile", "r")) == NULL)
		return -1;
	while (mygets(genbuf, sizeof(genbuf), fr))
	{
		if (from[0] == '\0' && !strncmp(genbuf, "From: ", 6))
		{
			p = genbuf + 6;
			while (*p == SP)
				p++;
			if (*p == '"')
			{
				int name_index = 0;
				
				p++;
				while (*p && *p != '"')
					name[name_index++] = *p++;
				name[name_index] = '\0';
				p++;
				while (*p == SP)
					p++;
				p++;
				get_var(p, from, sizeof(from));
				if (from[strlen(from) - 1] == '>')
					from[strlen(from) - 1] = '\0';
			}
			else
			{
				p = get_var(genbuf + 6, from, sizeof(from));
				while (*p == SP)
					p++;
				p++;
				get_str(p, name, sizeof(name));
				if (name[strlen(name) - 1] == ')')
					name[strlen(name) - 1] = '\0';
			}
			if (check_list(badutop, baduend, from))
			{
				fclose(fr);
				return 0;
			}
		}
		else if (group[0] == '\0' && !strncmp(genbuf, "Newsgroups: ", 12))
			get_var(genbuf + 12, group, STRLEN);
		else if (title[0] == '\0' && !strncmp(genbuf, "Subject: ", 9))
			get_str(genbuf + 9, title, STRLEN);
		else if (date[0] == '\0' && !strncmp(genbuf, "Date: ", 6))
			get_str(genbuf + 6, date, STRLEN);
		else if (organ[0] == '\0' && !strncmp(genbuf, "Organization: ", 14))
			get_str(genbuf + 14, organ, STRLEN);
		else if (msgid[0] == '\0' && !strncmp(genbuf, "Message-ID: ", 12))
			get_var(genbuf + 12, msgid, STRLEN);
		else if (board[0] == '\0' && !strncmp(genbuf, "X-Filename: ", 12))
		{
			if ((p = strstr(genbuf + 12, "/M.")) != NULL)
				*p = '\0';
			get_var(genbuf + 12, board, STRLEN);
		}
		else if (genbuf[0] == '\n')
			break;
	}
	if (from[0] == '\0')
	{
		fclose(fr);
		return -1;
	}
	sprintf(genbuf, "/boards/%-s", bncur->board);
	get_only_name(genbuf, fhead.filename);
	sprintf(genbuf, "/boards/%-s/%-s", bncur->board, fhead.filename);
	if ((fw = fopen(genbuf, "w")) == NULL)
	{
		fclose(fr);
		return -1;
	}
	chmod(genbuf, 0644);
	fprintf(fw, "�o�H�H�G%s (%s)\n", from, name);	/* lasehu */
	fprintf(fw, "����G%s\n", date);
	fprintf(fw, "���D�G%s\n", title);
	fprintf(fw, "�H�s�G%s    �ݪO�G%s\n", group, board);
	fprintf(fw, "�N���G%s\n", msgid);
	fprintf(fw, "��´�G%s\n\n", organ);
	while (mygets(genbuf, sizeof(genbuf), fr))
	{
		fprintf(fw, "%s", genbuf);
	}
	fclose(fw);
	fclose(fr);
	if ((p = strchr(from, '@')))
		p++;
	else
		p = from;
/* add by lasehu */
	if (conf.sister[0] == '\0' || strncmp(p, conf.sister, sisterlen))
	{
		sprintf(fhead.owner, "#%-s", from);
	}
	else
	{

		if ((p = strchr(from, '.')))
			*p = '\0';
		strcpy(fhead.owner, from);
	}
	sprintf(fhead.title, "%-s", title);
	sprintf(genbuf, "/boards/%-s/%s", bncur->board, DIR_REC);
	fhead.artno = get_only_artno(genbuf);	/* lasehu */
	if (fhead.artno == 1)	/* lasehu */
		rewind_board(bncur->board);
	if ((fb = open(genbuf, O_WRONLY | O_CREAT | O_APPEND, 0600)) < 0)
	{
		sprintf(genbuf, "/boards/%-s/%-s", bncur->board, fhead.filename);
		unlink(genbuf);
		return -1;
	}
	flock(fb, LOCK_EX);
	write(fb, &fhead, sizeof(fhead));
	flock(fb, LOCK_UN);
	close(fb);

	sprintf(genbuf, "/news/record/%s.%-s/%-d", bncur->board, bncur->newsgroup, cur);
	if ((fb = open(genbuf, O_WRONLY | O_CREAT, 0644)) < 0)
	{
		p = strrchr(genbuf, '/');
		*p = '\0';
		mkdir(genbuf, 0755);
		chmod(genbuf, 0755);
		sprintf(genbuf, "/news/record/%s.%-s/%-d", bncur->board,
			bncur->newsgroup, cur);
		if ((fb = open(genbuf, O_WRONLY | O_CREAT, 0644)) < 0)
			return 0;
	}
	write(fb, fhead.filename, strlen(fhead.filename));
	close(fb);
	return 0;
}


/***************************************************************
 * ��s�̫� news article �O��
 ***************************************************************/
int
update_lastnews(board, newsgroup, last)
char   *board, *newsgroup;
unsigned long last;
{
	FILE   *fn;

	sprintf(genbuf2, "/news/input/%-s.%-s", board, newsgroup);
	if ((fn = fopen(genbuf2, "w")) == NULL)
		return -1;
	chmod(genbuf2, 0644);
	fprintf(fn, "%-d", last);
	fclose(fn);
	return 0;
}


/***************************************************************
 * ���o�̫� news article �O��
 ***************************************************************/
unsigned long
get_lastnews(board, newsgroup)
char   *board, *newsgroup;
{
	FILE   *fn;

	sprintf(genbuf2, "/news/input/%-s.%-s", board, newsgroup);
	if ((fn = fopen(genbuf2, "r")) == NULL)
		return (unsigned long) 0;
	if (mygets(genbuf2, sizeof(genbuf2), fn))
	{
		fclose(fn);
		return (atol(genbuf2));
	}
	else
	{
		fclose(fn);
		return (unsigned long) 0;
	}
}


/***************************************************************
 * �}�l�B�z news article to bbs post ���u�@.
 ***************************************************************/
int
news2bbs()
{
	char   *begin, *end;
	int     total;
	FILE   *fw;
	unsigned long first, last, cur = 0;

	net_printf(sd, "GROUP %s\n", bncur->newsgroup);
	net_gets(sd, genbuf, sizeof(genbuf));
	if (strncmp(genbuf, "211", 3))
		return -1;
	end = begin = genbuf + 4;
	while (*end != SP)
		end++;
	*end = '\0';
	total = atoi(begin);
	begin = ++end;
	while (*end != SP)
		end++;
	*end = '\0';
	first = atol(begin);
	begin = ++end;
	while (*end != SP)
		end++;
	*end = '\0';
	last = atol(begin);


	if (total == 0)
	{
		update_lastnews(bncur->board, bncur->newsgroup, (unsigned long) 0);
		return 0;
	}
	cur = get_lastnews(bncur->board, bncur->newsgroup);
	check_cancel(first, last, cur);
	cur++;
	if (cur < first)
		cur = first;	/* lasehu: ��s���аO�� */
	else if (cur > last)
		return 0;


	for (; cur <= last; cur++)
	{
		update_lastnews(bncur->board, bncur->newsgroup, cur);
		if (bncur->get == NO)
			continue;
		net_printf(sd, "STAT %-d\n", cur);
		net_gets(sd, genbuf, sizeof(genbuf));
		if (strncmp(genbuf, "223", 3))
			continue;
		if ((begin = strchr(genbuf, '@')) == NULL)
		{
			continue;
		}
		begin++;
		end = strchr(begin, '>');
		*end = '\0';
			if (check_list(badstop, badsend, begin))
			{
				continue;
			}
		if ((fw = fopen("/news/input/tmpfile", "w")) == NULL)
			return -1;
		chmod("/news/input/tmpfile", 0644);
		net_printf(sd, "ARTICLE %-d\n", cur);
		net_gets(sd, genbuf, sizeof(genbuf));
		if (genbuf[0] != '2')
		{
			fclose(fw);
			continue;
		}

		while (net_gets(sd, genbuf, sizeof(genbuf)))
		{
			if (genbuf[0] == '.' && genbuf[1] == '\n')
				break;
			fprintf(fw, "%s", genbuf);
		}
		fclose(fw);
		do_post(cur);
		update_lastnews(bncur->board, bncur->newsgroup, cur);
	}
	return 0;
}



/*******************************************************************
 * �Ψ��o���ɮפ��� Esc ����ǦC
 *******************************************************************/
char   *
myfgets(buf, len, fr, esc_filter)
char    buf[];
int     len;
FILE   *fr;
int     esc_filter;
{
	if (esc_filter)
	{
		char   *p = buf, *end = buf + len - 1;
		int     esc_begin = 0;
		int     fd = fileno(fr);

		while (p < end && read(fd, p, 1) == 1)
		{
			if (*p == ESC)
			{
				esc_begin++;
				continue;
			}
			if (esc_begin && *p == 'm')
			{
				esc_begin = 0;
				continue;
			}
			if (esc_begin)
				continue;
			if (*p == '\n')
			{
				*(++p) = '\0';
				return buf;
			}
			else if (*p == '\0')
			{
				if (p == buf)
					return (char *) NULL;
				else
					return buf;
			}
			p++;
		}
		*end = '\0';
		if (p == buf)
			return (char *) NULL;
		else
			return buf;
	}
	else
		return (mygets(buf, len, fr));
}


/*******************************************************************
 * �� News Server �إ� socket
 *******************************************************************/
int
connect_server()
{
	char   *s[2];

	s[0] = conf.server;
	sd = -1;
	while (sd < 0)
	{
		sd = ConnectServer(*s, conf.port, TCP);
		if (sd < 0)
			sleep(conf.retry_sec);
	}
	net_gets(sd, genbuf, sizeof(genbuf));
	if (!strncmp(genbuf, "200", 3))
		can_post = 1;
	else if (!strncmp(genbuf, "201", 3))
		can_post = 0;
	return sd;
}


/***************************************************************
 * �����P News Server ���� socket
 ***************************************************************/
int
close_server()
{
	net_printf(sd, "QUIT\n");
	close(sd);
	return 0;
}


/***************************************************************
 * ��s�ثe�ҳB�z�� filename �O��
 ***************************************************************/
int
update_currfile(fname)	
char   *fname;
{
	FILE   *ff;

	if ((ff = fopen("/news/current/filename", "w")) == NULL)
		return -1;
	chmod("/news/current/filename", 0644);
	fprintf(ff, "%s", fname);
	fclose(ff);
	return 0;
}


/***************************************************************
 * �}�l�B�z bbs posts to news article ���u�@.
 ***************************************************************/
int
bbs2news()
{
	char    currfile[STRLEN - 2], name[STRLEN], uname[STRLEN], title[STRLEN], date[STRLEN],
	       *p;
	FILE   *fi, *ff;
	short   c_flag, i;

	if ((fi = fopen("/news/current/index", "r")) == NULL)
		return -1;
	if (fscanf(fi, "%s\n", currfile) != 1)
	{
		fclose(fi);
		return -1;
	}
	if ((ff = fopen("/news/current/filename", "r+")) != NULL
	    && mygets(genbuf, 1024, ff))
	{
		if (strcmp(currfile, genbuf))
		{
			while (fscanf(fi, "%s\n", currfile) == 1)
			{
				if (!strcmp(currfile, genbuf))
					break;
			}
			if (strcmp(currfile, genbuf))
			{
				rewind(fi);
				fscanf(fi, "%s\n", currfile);
			}
		}
		fclose(ff);
	}

	do
	{
		update_currfile(currfile);
		if (currfile[0] == '-')
			c_flag = 1;
		else
			c_flag = 0;
		if (c_flag)
			sprintf(genbuf, "/news/cancel/%-s.%-s", bncur->board, currfile + 1);
		else
			sprintf(genbuf, "/boards/%-s/%-s", bncur->board, currfile);
		if ((ff = fopen(genbuf, "r")) == NULL)
			continue;
		connect_server();
		if (can_post == 0)
		{
			close_server();
			fclose(ff);
			continue;
		}
		net_printf(sd, "POST\n");
		net_gets(sd, genbuf, sizeof(genbuf));
		if (genbuf[0] == '4')
		{
			close_server();
			fclose(ff);
			continue;
		}
		name[0] = uname[0] = title[0] = date[0] = '\0';
		while (myfgets(genbuf, sizeof(genbuf), ff, conf.esc_filter))
		{
			if (name[0] == '\0' && !strncmp(genbuf, "�o�H�H�G", 8))
			{
				p = get_var(genbuf + 8, name, STRLEN);
				get_str(p, uname, STRLEN);
				if ((p = strchr(uname, ')')) != NULL)
					*(++p) = '\0';
			}
			else if (date[0] == '\0' && !strncmp(genbuf, "����G", 6))
				get_str(genbuf + 6, date, STRLEN);
			else if (title[0] == '\0' && !strncmp(genbuf, "���D�G", 6))
				get_str(genbuf + 6, title, STRLEN);
			else if (genbuf[0] == '\n')
				break;
			else if (genbuf[0] == ' ')
			{
				i = 0;
				while (genbuf[++i] == ' ')
					 /* */ ;
				if (genbuf[i] == '\n')
					break;
			}
		}
		net_printf(sd, "Newsgroups: %-s\n", bncur->newsgroup);
		net_printf(sd, "Path: %-s\n", conf.mynickname);
		net_printf(sd, "From: %-s.bbs@%-s %-s\n", name, conf.myhostname, uname);
		if (c_flag)
		{
			net_printf(sd, "Subject: cmsg cancel <%-s.%-d@%-s>\n", currfile + 1,
				   bncur->num, conf.myhostname);
			net_printf(sd, "Message-ID: <del.%-s.%-d@%-s>\n", currfile + 1,
				   bncur->num, conf.myhostname);
		}
		else
		{
			net_printf(sd, "Subject: %-s\n", title);
			net_printf(sd, "Message-ID: <%-s.%-d@%-s>\n", currfile,
				   bncur->num, conf.myhostname);
		}
		net_printf(sd, "Organization: %-s\n", conf.organ);
		if (c_flag)
		{
			net_printf(sd, "X-Filename: %-s/%-s\n", bncur->board, currfile + 1);
			net_printf(sd, "Control: cancel <%-s.%-d@%-s>\n\n", currfile + 1,
				   bncur->num, conf.myhostname);
			net_printf(sd, "Article be deleted by <%-s.bbs@%-s> %-s\n"
				   ,name, conf.myhostname, uname);
		}
		else
		{
			net_printf(sd, "X-Filename: %-s/%-s\n\n", bncur->board, currfile);
			while (myfgets(genbuf, sizeof(genbuf), ff, conf.esc_filter))
			{
				net_printf(sd, "%s", genbuf);
			}
		}
		net_printf(sd, "\n.\n");
		net_gets(sd, genbuf, sizeof(genbuf));
		sleep(2);
		fclose(ff);
		if (c_flag)
		{
			sprintf(genbuf, "/news/cancel/%-s.%-s", bncur->board, currfile + 1);
			unlink(genbuf);
		}
		close_server();
	}
	while (fscanf(fi, "%s\n", currfile) == 1);
	fclose(fi);
	return 0;
}




/***************************************************************
 * �}�l�B�z bnlink ���u�@.
 ***************************************************************/
int
access_bnlink()	
{
	char   *s, found, restore = NO, first = YES;
	int     fb;
	FILE   *fdi, *fdl, *fdf;
	struct boardheader bhead;

	bzero(genbuf, sizeof(genbuf));
	if ((fdl = fopen("/news/current/line", "r")) == NULL)
		restore = NO;
	else if (mygets(genbuf, sizeof(genbuf), fdl))
	{
		if ((s = strchr(genbuf, '#')) != NULL)
		{
			fclose(fdl);
			*s++ = '\0';
			for (bncur = bntop->next; bncur != bnend; bncur = bncur->next)
				if (!strcmp(bncur->board, genbuf)
				    && !strcmp(bncur->newsgroup, s))
				{
					restore = YES;
					break;
				}
		}
	}
	else
		fclose(fdl);
	if (restore == YES)
	{
		if ((fb = open(BOARDS, O_RDONLY)) < 0)
			return -1;
		found = NO;
		while (found == NO && bncur != bnend)
		{
			lseek(fb, 0, SEEK_SET);
			while (read(fb, &bhead, sizeof(bhead)) == sizeof(bhead))
				if (!strcmp(bhead.filename, bncur->board))
				{
					found = YES;
					break;
				}
			if (found == NO)
				bncur = bncur->next;
		}
		close(fb);
	}
	if (restore == NO || found == NO)
	{
		unlink("/news/current/line");
		unlink("/news/current/index");
		unlink("/news/current/filename");
		if ((fb = open(BOARDS, O_RDONLY)) < 0)
			return -1;
		found = NO;
		while (found == NO && read(fb, &bhead, sizeof(bhead)) == sizeof(bhead))
			for (bncur = bntop->next; bncur != bnend; bncur = bncur->next)
				if (!strcmp(bhead.filename, bncur->board))
				{
					found = YES;
					break;
				}
		sprintf(genbuf, "/news/output/%-s", bncur->board);
		myrename(genbuf, "/news/current/index");
		if ((fdl = fopen("/news/current/line", "w")) != NULL)
		{
			chmod("/news/current/line", 0644);
			fprintf(fdl, "%-s#%-s", bncur->board, bncur->newsgroup);
			fclose(fdl);
		}
		if ((fdi = fopen("/news/current/index", "r")) != NULL
		    && fscanf(fdi, "%s\n", genbuf) > 0)
		{
			if ((fdf = fopen("/news/current/filename", "w")) != NULL)
			{
				chmod("/news/current/filename", 0644);
				fprintf(fdf, "%s", genbuf);
				fclose(fdf);
			}
			fclose(fdi);
		}
	}
	while (1)
	{
		while (1)
		{
			if (first == NO)
			{
				if ((fdl = fopen("/news/current/line", "w")) != NULL)
				{
					chmod("/news/current/line", 0644);
					fprintf(fdl, "%-s#%-s", bncur->board, bncur->newsgroup);
					fclose(fdl);
				}
				if ((fdi = fopen("/news/current/index", "r")) != NULL
				    && fscanf(fdi, "%s\n", genbuf) > 0)
				{
					if ((fdf = fopen("/news/current/filename", "w")) != NULL)
					{
						chmod("/news/current/filename", 0644);
						fprintf(fdf, "%s", genbuf);
						fclose(fdf);
					}
					fclose(fdi);
				}
			}
			else
				first = NO;
			if (bncur->type == 'B' || bncur->type == 'I')
			{
				connect_server();
				news2bbs();
				close_server();
			}
			if (bncur->type == 'B' || bncur->type == 'O')
			{
				bbs2news();
			}
			if (bncur->next == bnend)
				break;
			for (bncur = bncur->next; bncur != bnend; bncur = bncur->next)
				if (!strcmp(bhead.filename, bncur->board))
					break;
			if (bncur == bnend)
				break;
		}
		unlink("/news/current/line");
		unlink("/news/current/index");
		unlink("/news/current/filename");
		found = NO;
		while (found == NO && read(fb, &bhead, sizeof(bhead)) == sizeof(bhead))
			for (bncur = bntop->next; bncur != bnend; bncur = bncur->next)
				if (!strcmp(bhead.filename, bncur->board))
				{
					found = YES;
					break;
				}
		if (found == NO)
		{
			close(fb);
			return 0;
		}
		sprintf(genbuf2, "/news/output/%-s", bncur->board);
		myrename(genbuf2, "/news/current/index");
	}
}


/*******************************************************************
 * ������ read or write �Ӥ[��, ���P�_�u, ���s�s�� server
 *******************************************************************/
void
io_timeout()
{
	close_all_ftable();
	clean_conf();
	execl("/bin/bbs-news", "bbs-news", NULL);
}


void
main()
{
	int     fd, pid;

	if (getuid() != BBS_UID)
	{
		if (chroot(HOMEBBS) || chdir("/"))
		{
			printf("\n\n!!! �Х� root �� bbs �Ӱ��楻�{�� !!!\n");
			exit(-1);
		}
		setgid(BBS_GID);
		setuid(BBS_UID);
		booting = 1;
	}
	else
	{
		if (chdir(HOMEBBS) == -1)
		{
			printf("\n\n!!! BBS Home Directory not exist !!!\n");
			exit(-1);
		}
	}


	if (fork())
		exit(0);
	signal(SIGUSR1, io_timeout);
	signal(SIGALRM, io_timeout);
	if ((fd = open(B_N_PID_FILE, O_RDWR | O_CREAT, 0644)) >= 0)
	{
		bzero(genbuf, 11);
		if (read(fd, genbuf, 10) == 10 && (pid = atoi(genbuf)) > 2)
		{
			if (kill(pid, 0) == 0)
			{
				exit(0);
			}
		}
		lseek(fd, 0, SEEK_SET);
		sprintf(genbuf, "%10d", getpid());
		write(fd, genbuf, 10);
		close(fd);
	}
	else
	{
		printf("\n\n!!! �L�k�O�� pid file !!!\n");
		exit(-1);
	}
	while (1)
	{
		close_all_ftable();
		if (read_conf())
		{
			printf("\n\n!!! �]�w�ɿ��~ !!!\n");
			exit(-1);
		}
		access_bnlink();
		sleep(conf.rest_sec);
		clean_conf();
	}
}
