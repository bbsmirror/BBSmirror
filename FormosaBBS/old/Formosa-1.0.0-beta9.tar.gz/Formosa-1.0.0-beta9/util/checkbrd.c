
#include "bbs.h"


#undef DEBUG


#define DEFPOST		(3500)	/* �G�i�W�� */
#define DEFRANGE	(500)	/* �R���G�i�� */
#define PROPORTION	(4)	/* �R�����: �X�����@ */

int     DefPost, DefRange;

char    genbuf[1024];


#ifdef SYSV
int
flock(fd, op)
int     fd, op;
{
        switch (op)
        {
                case LOCK_EX:
                        return lockf(fd, F_LOCK, 0);
                case LOCK_UN:
                        return lockf(fd, F_ULOCK, 0);
                default:
                        return -1;
        }
}

#endif


void
Check_Limit(bname, post, range)
char    bname[];
int    *post;
int    *range;
{
    char    entbname[STRLEN], *ptr;
    int     entpost, entrange;
    FILE   *fp;

    if ((fp = fopen(BOARDLIMIT, "r")) != NULL)
    {
	while (fgets(genbuf, sizeof(genbuf), fp) != NULL)
	{
	    if ((ptr = strchr(genbuf, '#')) != NULL)
		*ptr = '\0';
	    if (genbuf[0] == '\0')
		continue;
	    sscanf(genbuf, "%s %d %d", entbname, &entpost, &entrange);
	    if (!strcmp(entbname, bname))
	    {
		    if (entpost > 0)
			*post = entpost;
		if (*post > entrange)
		    *range = entrange;
		else
		    *range = (*post) / PROPORTION;
		fclose(fp);
		return;
	    }
	}
	fclose(fp);
    }
}


void
Delete_Post(bname, num)
char    bname[];
int     num;
{
    int     fd;
    FILEHEADER fh;

    sprintf(genbuf, "%s/%s/%s", BBSPATH_BOARDS, bname, DIR_REC);
    if ((fd = open(genbuf, O_RDWR)) > 0)
    {
	flock(fd, LOCK_EX);
	while (num-- > 0)
	{
	    if (read(fd, &fh, sizeof(fh)) == sizeof(fh))
	    {
		if (fh.accessed & FILE_RESRV)	/* lasehu */
		    continue;			    
		fh.accessed |= FILE_DELE;
		if (lseek(fd, -((off_t) sizeof(fh)), SEEK_CUR) != -1)
		{
		    if (write(fd, &fh, sizeof(fh)) == sizeof(fh))
			continue;
		}
	    }
	    break;
	}
	flock(fd, LOCK_UN);
	close(fd);
    }
}


void
Check_Board(bname)
char    bname[];
{
    struct stat st;
    int     post, range, total;
    char    path[STRLEN];

    post = DefPost;
    range = DefRange;

    sprintf(path, "%s/%s/%s", BBSPATH_BOARDS, bname, DIR_REC);
    if (stat(path, &st) == -1)
	return;


    Check_Limit(bname, &post, &range);
    total = st.st_size / sizeof(FILEHEADER);


    if (total > post)
	Delete_Post(bname, total - post + range);
}


main(argc, argv)
int     argc;
char   *argv[];
{
    int     fd;
    struct boardheader bhead;

    DefPost = DEFPOST;
    DefRange = DEFRANGE;

    if (argc != 3)
    {
	printf("syntax:\n   %s [posts] [range]
\n  First [posts] - [range] posts will be deleted.\n", argv[0]);
	exit(0);
    }

    DefPost = atoi(argv[1]);        
    DefRange = atoi(argv[2]);

    if (getuid() != BBS_UID)
    {
	if (chroot(HOMEBBS) == -1 || chdir("/") == -1)
	{
	    printf("\n\n!!! �Х� root �� bbs �Ӱ��楻�{�� !!!\n");
	    exit(-1);
	}
	setgid(BBS_GID);
	setuid(BBS_UID);
    }
    else
    {
	if (chdir(HOMEBBS) == -1)
	{
	    printf("\n\n!!! BBS Home Directory not exist !!!\n");
	    exit(-1);
	}
    }


    if (DefRange > DefPost)
	DefRange = DefPost / PROPORTION;

    if ((fd = open(BOARDS, O_RDONLY)) < 0)
    {
	printf("\nError: cannot open [%s] !!\n", BOARDS);
	exit(-1);
    }

    while (read(fd, &bhead, sizeof(bhead)) == sizeof(bhead))
    {
	Check_Board(bhead.filename);
    }

    close(fd);
    exit(0);
}
