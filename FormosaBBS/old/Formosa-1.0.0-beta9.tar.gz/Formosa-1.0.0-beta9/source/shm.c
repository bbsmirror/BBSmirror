
/* FormosaBBS 1.0.0 */

/*******************************************************************
 * Shared Memory function
 *******************************************************************/

#include "bbs.h"

#include <sys/ipc.h>
#include <sys/shm.h>


void
attach_err(shmkey, name)
int     shmkey;
char   *name;
{
	fprintf(stderr, "[%s error] key = %d\n", name, shmkey);
	exit(1);
}


void   *
attach_shm(shmkey, shmsize)
key_t   shmkey;
int     shmsize;
{
	void   *shmptr;
	int     shmid;

	shmid = shmget(shmkey, shmsize, 0);
	if (shmid < 0)
	{
		shmid = shmget(shmkey, shmsize, IPC_CREAT | 0600);
		if (shmid < 0)
			attach_err(shmkey, "shmget");
		shmptr = (void *) shmat(shmid, NULL, 0);
		if (shmptr == (void *) -1)
			attach_err(shmkey, "shmat");
		memset(shmptr, 0, shmsize);
	}
	else
	{
		shmptr = (void *) shmat(shmid, NULL, 0);
		if (shmptr == (void *) -1)
			attach_err(shmkey, "shmat");
	}
	return (void *) shmptr;
}


struct UTMPFILE *utmpshm = NULL;	/* �����ϥΪ� USER_INFO ���� */

void
resolve_utmp()
{
	if (utmpshm == NULL)
	{
		utmpshm = attach_shm(UTMPSHM_KEY, sizeof(*utmpshm));
		if (utmpshm->uptime == 0)
		{
			utmpshm->uptime = 1;
			utmpshm->number = 0;
		}
	}
}


USER_INFO *
search_ulist(fptr, farg)
register int (*fptr) ();
register char *farg;
{
	register USER_INFO *uentp;
	register int i;

	resolve_utmp();
	uentp = utmpshm->uinfo;
	for (i = 0; i < USHM_SIZE; i++, uentp++)
	{
		if (uentp->pid <= 2)
			continue;
		if ((*fptr) (farg, uentp))
			return uentp;
	}
	return NULL;
}


int
apply_ulist(fptr)
register int (*fptr) ();
{
	register USER_INFO *uentp;
	register int i;

	resolve_utmp();
	uentp = utmpshm->uinfo;
	for (i = 0; i < USHM_SIZE; i++, uentp++)
	{
		if (uentp->pid <= 2)
			continue;
		if ((*fptr) (uentp) == QUIT_LOOP)	/* interrupt the loop */
			return QUIT_LOOP;
	}
	return 0;
}


int
ask_online_user()
{
	resolve_utmp();
	return utmpshm->number;
}


void
update_ulist(upent)
USER_INFO *upent;
{
	register int actent;

	if (!upent)
	{
		bbslog("DEBUG", "update_ulist() fatal empty");
		exit(-1);
	}

	actent = (upent->active) - 1;
	if (actent < 0 || actent >= USHM_SIZE)
	{
		bbslog("DEBUG", "update_ulist() fatal range");
		exit(-1);
	}
	memcpy((utmpshm->uinfo) + actent, upent, sizeof(USER_INFO));
}


void
purge_ulist(upent)
USER_INFO *upent;
{
	register int actent;

	if (!upent)
	{
		bbslog("DEBUG", "purge_ulist() fatal empty");
		exit(-1);
	}

	actent = (upent->active) - 1;
	if (actent < 0 || actent >= USHM_SIZE)
	{
		bbslog("DEBUG", "purge_ulistshm() fatal range");
		exit(-1);
	}
	memset((utmpshm->uinfo) + actent, 0, sizeof(USER_INFO));
#if !defined(NSYSUBBS) || defined(ULTRABBS)
	if (utmpshm->number > 0)
		utmpshm->number--;
	else
		utmpshm->number = 0;
#endif
}


int
new_utmp()
{
	extern int errno;
	register time_t now;
	register int i;
	register pid_t pid;
	register USER_INFO *uentp;

	resolve_utmp();
	pid = getpid();		/* lasehu */	
	
	now = time(NULL) - 228;
	if (now > utmpshm->uptime)
		utmpshm->busystate = 0;

	while (utmpshm->busystate)
	{
		sleep(1);
	}
	utmpshm->busystate = 1;

	/* for ���F�ǻ�: �C 228 ����s�@�� */
	if (now > utmpshm->uptime)
	{
		uentp = utmpshm->uinfo;
		for (i = now = errno = 0; i < USHM_SIZE; i++, uentp++)
		{
			if (uentp->pid > 2)
			{
				if ((kill(uentp->pid, 0) == -1) && (errno == ESRCH))
				{
				       /* don't need reset struct, just pid only -- lmj
				          memset(uentp, 0, sizeof(USER_INFO));
				        */
					uentp->pid = 0;
					uentp->userid[0] = '\0';	/* lasehu */
					errno = 0;
				}
				else
					now++;
			}
		}
		utmpshm->number = now;
		time(&utmpshm->uptime);
	}
	uentp = utmpshm->uinfo;
	for (i = 0; i < USHM_SIZE; i++, uentp++)
	{
		if (uentp->pid < 3)	/* lmj */
		{
			uentp->pid = pid;
			utmpshm->number++;
			utmpshm->busystate = 0;
			return (i + 1);		/* lasehu */
		}
	}
	utmpshm->busystate = 0;
	sleep(1);
	exit(1);
}

