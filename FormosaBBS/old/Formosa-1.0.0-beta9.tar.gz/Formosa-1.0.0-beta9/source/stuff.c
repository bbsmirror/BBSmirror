
#include "bbs.h"
#include "tsbbs.h"
#include <pwd.h>
#include <varargs.h>
#include <sys/wait.h>


#ifndef MAXPATHLEN
#define MAXPATHLEN 	(256)
#endif


void
pressreturn()
{
	move(b_line, 0);
	clrtoeol();
	outs("[1;37;40m�Ы� [Enter] ���~��[m");
	getkey();
}


#define LOOKFIRST  (0)
#define LOOKLAST   (1)
#define QUOTEMODE  (2)
#define MAXCOMSZ (1024)
#define MAXARGS (40)
#define MAXENVS (20)
#define BINDIR "bin/"		/* lasehu */

char   *bbsenv[MAXENVS];
int     numbbsenvs = 0;

bbssetenv(env, val)
char   *env, *val;
{
	register int i, len;

	if (numbbsenvs == 0)
		bbsenv[0] = NULL;
	len = strlen(env);
	for (i = 0; bbsenv[i]; i++)
		if (!strncasecmp(env, bbsenv[i], len))
			break;
	if (i >= MAXENVS)
		return -1;
	if (bbsenv[i])
		free(bbsenv[i]);
	else
		bbsenv[++numbbsenvs] = NULL;
	bbsenv[i] = (char *) malloc(strlen(env) + strlen(val) + 2);
	if (!bbsenv[i])		/* lasehu */
		return -1;
	strcpy(bbsenv[i], env);
	strcat(bbsenv[i], "=");
	strcat(bbsenv[i], val);
	return 0;
}

pid_t   child_pid;

int
do_exec(com, wd)
char   *com, *wd;
{
	char    path[MAXPATHLEN];
	char    pcom[MAXCOMSZ];
	char   *arglist[MAXARGS];
	register int i, len;
	register int argptr;
	pid_t   pid;
	int     w;
	int     pmode;
	void    (*isig) (), (*qsig) ();
	struct passwd *passid;

#if defined(SYSV) || defined(LINUX)
	int     status;

#else
	union wait status;

#endif

	passid = getpwuid(BBS_UID);
	strncpy(path, BINDIR, MAXPATHLEN);
	strncpy(pcom, com, MAXCOMSZ);
	len = MIN(strlen(com) + 1, MAXCOMSZ);
	pmode = LOOKFIRST;
	for (i = 0, argptr = 0; i < len; i++)
	{
		if (pcom[i] == '\0')
			break;
		if (pmode == QUOTEMODE)
		{
			if (pcom[i] == '\001')
			{
				pmode = LOOKFIRST;
				pcom[i] = '\0';
				continue;
			}
			continue;
		}
		if (pcom[i] == '\001')
		{
			pmode = QUOTEMODE;
			arglist[argptr++] = &pcom[i + 1];
			if (argptr + 1 == MAXARGS)
				break;
			continue;
		}
		if (pmode == LOOKFIRST)
			if (pcom[i] != ' ')
			{
				arglist[argptr++] = &pcom[i];
				if (argptr + 1 == MAXARGS)
					break;
				pmode = LOOKLAST;
			}
			else
				continue;
		if (pcom[i] == ' ')
		{
			pmode = LOOKFIRST;
			pcom[i] = '\0';
		}
	}
	arglist[argptr] = NULL;
	if (argptr == 0)
		return -1;
	if (*arglist[0] == '/')
		strncpy(path, arglist[0], MAXPATHLEN);
	else
		strncat(path, arglist[0], MAXPATHLEN);
	reset_tty();
	if ((pid = fork()) == 0)
	{
		if (wd)
			if (chdir(wd))
			{
				fprintf(stderr, "Unable to chdir to '%s'\n", wd);
				exit(-1);
			}
		bbssetenv("PATH", "/bin:/usr/lib:/etc:/usr/ucb:/usr/local/bin:/usr/local/lib");
		bbssetenv("TERM", "vt100");
		bbssetenv("USER", passid->pw_name);
		bbssetenv("USERNAME", curuser.username);
		bbssetenv("HOME", passid->pw_dir);
		if (numbbsenvs == 0)
			bbsenv[0] = NULL;
		signal(SIGCHLD, SIG_IGN);	/* lasehu: ignore SIGCHLD */
		execve(path, arglist, bbsenv);
		fprintf(stderr, "EXECV FAILED... path = '%s'\n", path);
		exit(-1);
	}
	isig = signal(SIGINT, SIG_IGN);
	qsig = signal(SIGQUIT, SIG_IGN);
	child_pid = pid;

#if	defined(SOLARIS) || defined(AIX)
	while (1)
	{
		if (waitpid(pid, &status, 0) == -1 && errno == EINTR)
			continue;
		break;
	}
#else
	while (waitpid(child_pid, &status, 0) != child_pid)
		/* empty */ ;
#endif		

	signal(SIGINT, isig);
	signal(SIGQUIT, qsig);
	child_pid &= ~child_pid;
	restore_tty();
	return 0;
}


int
outdoor(cmd_file, umode, dotimeout)	/* execute oudoor program */
char   *cmd_file;
int     umode;
int     dotimeout;
{
	int     save_pager = uinfo.pager;
	char    filename[PATHLEN], *ptr;
	int     save_umode = uinfo.mode;

	strncpy(filename, cmd_file, PATHLEN - 1);
	if ((ptr = strchr(filename, ' ')))
		*ptr = '\0';
	if (access(filename, X_OK) == -1)
	{
		char    buf[PATHLEN];	/* lasehu */

		sprintf(buf, "%s/%s", BINDIR, filename);
		if (access(buf, X_OK) == -1)
		{
			outs("\nThis option is disable");
			pressreturn();
			return -1;
		}
	}
	uinfo.pager = NA;
	uinfo.mode = umode;
	update_utmp();
	if (!dotimeout)
		signal(SIGALRM, SIG_IGN);	/* lasehu */
	do_exec(cmd_file, NULL);
	if (!dotimeout)
		init_alarm(IDLE_TIMEOUT);
	uinfo.pager = save_pager;
	uinfo.mode = save_umode;
	update_utmp();
	return 0;
}


void
show_byebye(idle)
int     idle;
{
	time_t  now = time(0);

	printxy(4, 15, "[31;42m------------(���i�ӤH�p�ɮסj��)-------------[m");
	printxy(5, 15, "[1;37;44m       �`�i�K�� == [33m%-6d                    [m", curuser.numposts);
	printxy(6, 15, "[1;37;44m       �W������ == [33m%-6d                    [m", curuser.numlogins);
	printxy(7, 15, "[1;37;44m   �W���Ӫ��ɨ� == [33m%-26s[m", Ctime(&prev_lastlogin));
	printxy(8, 15, "[1;37;44m   �W���Ӫ��a�� == [33m%-26s[m", prev_from);
	printxy(9, 15, "[1;37;44m   �o���Ӫ��ɨ� == [33m%-26s[m", Ctime(&curuser.lastlogin));
	printxy(10, 15, "[1;37;44m   �o���Ӫ��a�� == [33m%-26s[m", curuser.lasthost);
	printxy(11, 15, "[31;42m (�� �{�b�ɶ��O %-24s ��) [m", Ctime(&now));
	if (idle)
		printxy(12, 26, "[1;33;45m �z�b�m�L�[, �w�۰����u [m\n");
	else
		printxy(12, 26, "[1;36;45m  �Ы� [33m<Enter>[36m �������u  [m\n");
}


void
log_usies(mode, va_alist)
char   *mode;

va_dcl
{
	va_list args;
	time_t  now;
	int     fd;
	char    msgbuf[STRLEN], buf[STRLEN + 60], *fmt, timestr[22];

	va_start(args);
	fmt = va_arg(args, char *);

	vsprintf(msgbuf, fmt, args);
	va_end(args);

	time(&now);
	strftime(timestr, sizeof(timestr), "%x %X", localtime(&now));
	sprintf(buf, "%s %-12.12s %-10.10s %s\n",
		timestr, curuser.userid, mode, msgbuf);
	if ((fd = open(PATH_BBSLOG, O_APPEND | O_CREAT | O_WRONLY, 0600)) > 0)
	{
		write(fd, buf, strlen(buf));
		close(fd);
	}
}


int
Goodbye()			/* quit bbs */
{
	bell();
	move(b_line, 0);
	clrtoeol();
	refresh();
	printxy(b_line, 24, "[1;33;45m   �� �O�_���}���t�� (Y/N) :   [m");
	if (igetkey() != 'y')
		return M_FULL;

	clear();
	show_byebye(NA);
	refresh();
	user_logout();
	igetch();
	exit(0);
}


int
Switch_scr()			/* switch color or black-white mode */
{
	clear();
	if (HAS_FLAG(COLOR_FLAG))
	{
		show_ansi = YEA;
		outs("[1;37;40m�������m����ܼҦ�\n[m");
		UNSET_FLAG(COLOR_FLAG);
	}
	else
	{
		show_ansi = NA;
		outs("�����������ܼҦ�\n");
		SET_FLAG(COLOR_FLAG);
	}
	pressreturn();
	return M_FULL;
}


char   *
Ctime(clock)
time_t *clock;
{
	char   *foo;
	char   *ptr = ctime(clock);

	if ((foo = strrchr(ptr, '\n')))
		*foo = '\0';
	return (ptr);
}


void
bell()
{
	fprintf(stderr, "%c", CTRL('G'));
}


int
seek_in_file(filename, seekstr)
char    filename[], seekstr[];
{
	FILE   *fp;
	char    buf[STRLEN];
	char   *ptr;

	if ((fp = fopen(filename, "r")) != NULL)
	{
		while (fgets(buf, sizeof(buf), fp))
		{
			if ((ptr = strchr(buf, '\n')) == NULL)	/* debug */
				continue;
			if ((ptr = strchr(buf, '#')))
				*ptr = '\0';
			if (buf[0] == '\0')
				continue;
			if ((ptr = strtok(buf, ": \n\r\t")) && !strcmp(ptr, seekstr))
			{
				fclose(fp);
				return 1;
			}
		}
		fclose(fp);
	}
	return 0;
}




void
chk_str(str)
char    str[];
{
	char    t[STRLEN], *p = str;
	int     j;

	for (j = 0; p && *p && j < STRLEN; j++)
	{
		if (*p == ESC && *(p + 1) == '[')
		{
			if (*(p + 2) == '\0')
				break;
			p += 3;
		}
		else if (*p == NL || *p == 0x0d || *p == TAB)	/* 0x0d is cr */
			p += 1;
		t[j] = *p++;
	}
	t[j] = '\0';
	strcpy(str, t);
}


int
isprint2(ch)
unsigned char ch;
{
	return (((ch & 0x80) || ch == 0x1B) ? 1 : isprint(ch));
}


int
isprint3(ch)			/* chang */
unsigned char ch;
{
	if (ch == 0x1B)
	{
		igetch();
		igetch();
		return 0;
	}
	return ((ch & 0x80) ? 1 : isprint(ch));
}


int
is_in_outdoor(uinfo_ent)
USER_INFO *uinfo_ent;
{
#ifdef USE_LOCALIRC
	if (uinfo_ent->mode == LOCALIRC)
		return 1;
#endif
#ifdef USE_IRC
	if (uinfo_ent->mode == IRCCHAT)
		return 1;
#endif
	return 0;
}


void
trim(buf)			/* remove trailing space */
char   *buf;
{
	char   *p = buf;

	if (p)
	{
		while (*p)
			p++;
		p--;
		if (p >= buf && *p == '\n')	/* lasehu */
			*p = ' ';
		while (p >= buf && *p == ' ')
			*p-- = '\0';
	}
}


#define NUMLINES (19)

/*******************************************************************
 * ������J, �P���w�� link list ���
 *******************************************************************/
namecomplete(toplev, prompt, data)
struct word *toplev;
char   *prompt;
char    data[];
{
	char   *temp;
	int     ch;
	int     count = 0;
	int     clearbot = NA;
	struct word *cwlist, *morelist;
	int     x, y, origx, origy;

	if (prompt)
	{
		prints("%s", prompt);
		clrtoeol();
	}
	temp = data;

	cwlist = get_subwlist(NULL, toplev);
	morelist = NULL;
	getyx(&origy, &origx);
	y = origy;
	x = origx;
	while ((ch = getkey()) != EOF)
	{
		if (ch == '\n' || ch == '\r')
		{
			*temp = '\0';
			prints("\n");
		       /* lasehu */
			if (data[0] && (num_wlist(cwlist) == 1 || !strcmp(data, cwlist->word)))
				strcpy(data, cwlist->word);
			else
			{
				data[0] = '\0';
				move(b_line - 1, 0);
				clrtoeol();
				outs("��ܿ��~. �S�����ŦX��.");
				pressreturn();
			}
			cwlist = free_wlist(cwlist, NULL);
			break;
		}
		else if (ch == ' ')
		{
			int     col, len;

			if (num_wlist(cwlist) == 1)
			{
				strcpy(data, cwlist->word);
				move(y, x);
				prints("%s", data + count);
				count = strlen(data);
				temp = data + count;
				getyx(&y, &x);
				continue;
			}
			clearbot = YEA;
			col = 0;
			if (!morelist)
				morelist = cwlist;
			len = maxlen_wlist(morelist, NUMLINES);
			move(3, 0);
			clrtobot();
			standout();
			prints("------------------------------- Completion List -------------------------------");
			standend();
			while (len + col < 80)
			{
				int     i;

				for (i = NUMLINES; (morelist) && (i > 0); i--, morelist = morelist->next)
				{
					move(4 + (NUMLINES - i), col);
					prints("%s", morelist->word);
				}
				col += len + 2;
				if (!morelist)
					break;
				len = maxlen_wlist(morelist, NUMLINES);
			}
			if (morelist)
			{
				move(23, 0);
				standout();
				prints("-- More --");
				standend();
			}
			move(y, x);
			continue;
		}
		else if (ch == '\177' || ch == '\010')
		{
			if (temp == data)
				continue;
			temp--;
			count--;
			*temp = '\0';
			cwlist = free_wlist(cwlist, NULL);
			cwlist = get_subwlist(data, toplev);
			morelist = NULL;
			x--;
			move(y, x);
			outc(' ');
			move(y, x);
			continue;
		}
		else if (count < STRLEN)
		{
			struct word *node;

			*temp++ = ch;
			count++;
			*temp = '\0';
			node = get_subwlist(data, cwlist);
			if (node == NULL)
			{
				bell();
				temp--;
				*temp = '\0';
				count--;
				continue;
			}
			cwlist = free_wlist(cwlist, NULL);
			cwlist = node;
			morelist = NULL;
			move(y, x);
			outc(ch);
			x++;
		}
	}
	if (ch == EOF)		/* lasehu */
	{
		shutdown(0, 2);
		exit(0);
	}
	prints("\n");
	refresh();
	if (clearbot)
	{
		move(3, 0);
		clrtobot();
	}
	if (data[0] != '\0')
	{
		move(origy, origx);
		prints("%s\n", data);
	}
	return 0;
}


int
GetNumFileLine(filename)
char   *filename;
{
	FILE   *fp;
	char    buf[256];
	int     line = 0, lastch;;

	if ((fp = fopen(filename, "r")) == NULL)
		return 0;
	while (fgets(buf, sizeof(buf), fp))
	{
		lastch = strlen(buf) - 1;
		if (buf[lastch] == '\n')
			line++;
	}
	fclose(fp);
	return line;
}

