/*******************************************************************
 * ����D�{���P���ݤu��{���|�Ψ��ƩI�s.
 *******************************************************************/

#include "bbs.h"
#include <varargs.h>


#ifdef SYSV
int
flock (fd, op)
     int fd, op;
{
	switch (op)
	{
	case LOCK_EX:
		return lockf (fd, F_LOCK, 0);
	case LOCK_UN:
		return lockf (fd, F_ULOCK, 0);
	default:
		return -1;
	}
}

#endif



/*******************************************************************
 * �����ɮ� - �|�N�ت����|�R�
 *******************************************************************/
mycp (from, to)
     char *from, *to;
{
	char cpbuf[8192];	/* copy buffer size: 8192 */
	int fdr, fdw, cc;

	if ((fdr = open (from, O_RDONLY)) > 0)
	{
		if ((fdw = open (to, O_WRONLY | O_CREAT | O_TRUNC, 0644)) > 0)
		{
			while ((cc = read (fdr, cpbuf, sizeof (cpbuf))) > 0)
				write (fdw, cpbuf, cc);
			close (fdw);
			close (fdr);
			return 0;
		}
		close (fdr);
	}
	return -1;
}


/*******************************************************************
 * �R���ɮשΥؿ��
 *******************************************************************/
myunlink (name)
     char name[];
{
	DIR *dirp;

#ifdef	NO_DIRENT
	struct direct *dirlist;

#else
	struct dirent *dirlist;

#endif
	char path[MAXNAMLEN], *s;
	struct stat st;

	if (!name || name[0] == '\0' || stat (name, &st) == -1)
		return -1;
	if (!S_ISDIR (st.st_mode))
	{
		unlink (name);
		return 0;
	}
	if ((dirp = opendir (name)) == NULL)
		return -1;
	sprintf (path, "%s/", name);
	s = path + strlen (path);;
	readdir (dirp);
	readdir (dirp);
	while ((dirlist = readdir (dirp)) != NULL)
	{
		if (dirlist->d_name[0])
		{
			strcpy (s, dirlist->d_name);
			if (stat (path, &st) == 0)
			{
				if (S_ISDIR (st.st_mode))
					myunlink (path);
				else
					unlink (path);
			}
		}
	}
	closedir (dirp);
	*(--s) = '\0';
	if (rmdir (path) == -1)
		return -1;
	return 0;
}


/*******************************************************************
 * ����ɮ׸��| (�i���ɮרt�ηh��)
 *******************************************************************/
myrename (from, to)
     char from[], to[];
{
	struct stat st;

	if (rename (from, to) == -1)	/* �p�G rename() ���� */
	{
		if (stat (to, &st) == 0)
			return -1;
		/* ���ܤ��P filesystem, �A�� mycp() */
		if (mycp (from, to) == -1)
			return -1;
		unlink (from);
	}
	return 0;
}


/*******************************************************************
 * �h���ɮ� (�i���ɮרt�ηh��)
 *******************************************************************/
mymv (from, to)
     char from[], to[];
{
	if (rename (from, to) == -1)	/* �p�G rename() ���� */
	{
		/* ���ܤ��P filesystem, �A�� mycp() */
		if (mycp (from, to) == -1)
			return -1;
		unlink (from);
	}
	return 0;
}


void
sethomefile (buf, userid, filename)
     char *buf, *userid, *filename;
{
	unsigned char c;

	c = userid[0];
	if (c >= 'A' && c <= 'Z')
		c |= 32;
	else if (!(c >= 'a' && c <= 'z'))
		c = '0';
	if (filename == NULL)
		sprintf (buf, "home/%c/%s", c, userid);
	else
		sprintf (buf, "home/%c/%s/%s", c, userid, filename);
}


void
setuserfile (buf, userid, filename)
     char *buf, *userid, *filename;
{
	sprintf (buf, "%s/%s", filename, userid);
}




/*******************************************************************
 * �b���w���ؿ��U���o�ߤ@�� M.xxxxxxxx.? �ɦW
 *******************************************************************/
void
get_only_name (dir, fname)
     char dir[], fname[];
{
	char *t, tmpbuf[256];
	int fd;

	sprintf (fname, "M.%d.A", time (0));
	t = strrchr (fname, 'A');
	sprintf (tmpbuf, "%-s/%-s", dir, fname);
	while ((fd = open (tmpbuf, O_RDONLY)) != -1)
	{
		close (fd);
		if (*t == 'Z')
		{
			*(++t) = 'A';
			*(t + 1) = '\0';
		}
		else
			(*t)++;
		sprintf (tmpbuf, "%-s/%-s", dir, fname);
	}
	if ((fd = open (tmpbuf, O_WRONLY | O_CREAT, 0644)) != -1)
		close (fd);
}


unsigned int
get_passwd (urcp, userid)
     USEREC *urcp;
     char *userid;
{
	int fd;
	char fn_passwd[STRLEN];
	USEREC urcbuf, *u = (urcp) ? urcp : &urcbuf;

/* �Y urcbuf �� NULL, �h�u�d�� userid �O�_�s�b */

	if (userid == NULL || userid[0] == '\0')
		return 0;
	sethomefile (fn_passwd, userid, UFNAME_PASSWDS);
	if ((fd = open (fn_passwd, O_RDONLY)) > 0)
	{
		if (read (fd, u, sizeof (USEREC)) == sizeof (USEREC))
			{
				close (fd);
				return u->uid;
			}
		close (fd);
	}
	return 0;
}


void
setboardfile (buf, bname, filename)
     char *buf, *bname, *filename;
{
	if (filename[0])
		sprintf (buf, "%s/%s/%s", BBSPATH_BOARDS, bname, filename);
	else
		sprintf (buf, "%s/%s", BBSPATH_BOARDS, bname);
}


void
setmailfile (buf, userid, filename)
     char *buf, *userid, *filename;
{
	unsigned char c;

	c = userid[0];
	if (c >= 'A' && c <= 'Z')
		c |= 32;
	else if (!(c >= 'a' && c <= 'z'))
		c = '0';
	if (filename == NULL)
		sprintf (buf, "%s/%c/%-s", UFNAME_MAIL, c, userid);
	else
		sprintf (buf, "%s/%c/%-s/%s", UFNAME_MAIL, c, userid, filename);
}


int
append_news (board, fname, option)
     char *board, *fname, option;
{
	FILE *fp;
	char nbuf[PATHLEN], bbuf[PATHLEN];

	sprintf (nbuf, "news/output/%-s", board);
	if ((fp = fopen (nbuf, "a+")) == NULL)
		return -1;
	flock (fileno (fp), LOCK_EX);
	if (option == 'D')
		fprintf (fp, "-%-s\n", fname);
	else
		fprintf (fp, "%-s\n", fname);
	flock (fileno (fp), LOCK_UN);
	fclose (fp);
	if (option == 'D')
	{
		sprintf (nbuf, "news/cancel/%-s.%-s", board, fname);
		setboardfile (bbuf, board, fname);
		mycp (bbuf, nbuf);	/* lasehu */
	}
	return 0;
}


unsigned int
update_user (ubuf)
     USEREC *ubuf;
{
	int fd;
	char fn_passwd[STRLEN];
	USEREC urcbuf;

	if (ubuf == NULL || ubuf->userid[0] == '\0')
		return 0;
	sethomefile (fn_passwd, ubuf->userid, UFNAME_PASSWDS);
	if ((fd = open (fn_passwd, O_RDWR)) > 0)
	{
		flock (fd, LOCK_EX);	/* �ѩ�@�ΨϥΪ̸��, ���T�O�g�J���T */
			if (write (fd, ubuf, sizeof (USEREC)) == sizeof (USEREC))
			{
				flock (fd, LOCK_UN);
				close (fd);
				return ubuf->uid;
			}
		flock (fd, LOCK_UN);
		close (fd);
	}
	return 0;
}


int
dashf (fname)
     char *fname;
{
	struct stat st;

	return (stat (fname, &st) == 0 && S_ISREG (st.st_mode));
}


int
dashd (fname)
     char *fname;
{
	struct stat st;

	return (!stat (fname, &st));
}


/*******************************************************************
 * �����Ҧ��w���}���]��
  *******************************************************************/
void
close_all_ftable ()
{
	int i, ndescriptors = getdtablesize ();

	for (i = 3; i < ndescriptors; i++)
		(void) close (i);
}


void
bbslog (mode, va_alist)
     char *mode;

     va_dcl
{
	va_list args;
	time_t now;
	int fd;
	char msgbuf[STRLEN], buf[128], *fmt;
	char timestr[22];

	va_start (args);
	fmt = va_arg (args, char *);

	vsprintf (msgbuf, fmt, args);
	va_end (args);

	time (&now);
	strftime (timestr, sizeof (timestr), "%x %X", localtime (&now));

	sprintf (buf, "%s %.10s: %s\n", timestr, mode, msgbuf);
	if ((fd = open (PATH_BBSLOG, O_APPEND | O_CREAT | O_WRONLY, 0600)) > 0)
	{
		write (fd, buf, strlen (buf));
		close (fd);
	}
}


int
rewind_board (bname)
     char *bname;
{
	int fd;
	BOARDHEADER sbh;

	if ((fd = open (BOARDS, O_RDWR)) > 0)
	{
		flock (fd, LOCK_EX);
		while (read (fd, &sbh, sizeof (sbh)) == sizeof (sbh))
		{
			if (strcmp (sbh.filename, bname))
				continue;
			sbh.rewind_time = time (0);
			if (lseek (fd, -((off_t) sizeof (sbh)), SEEK_CUR) != -1)
			{
				if (write (fd, &sbh, sizeof (sbh)) == sizeof (sbh))
				{
					flock (fd, LOCK_UN);
					close (fd);
					return 0;
				}
			}
			break;
		}
		flock (fd, LOCK_UN);
		close (fd);
	}
	return -1;
}


int
get_only_artno (dotdir)
     char *dotdir;
{
	int fd;
	int number = 1;

	if ((fd = open (dotdir, O_RDONLY)) > 0)
	{
		FILEHEADER lastf;
		struct stat st;

		fstat (fd, &st);
		if ((st.st_size % FH_SIZE == 0) && st.st_size > FH_SIZE)
			lseek (fd, st.st_size - FH_SIZE, SEEK_SET);
		if (read (fd, &lastf, sizeof (lastf)) == sizeof (lastf))
		{
			if (lastf.artno >= BRC_REALMAXNUM)
				number = 1;	/* reset the artno. */
			else if (lastf.artno > 0)
				number = lastf.artno + 1;
		}
		close (fd);
	}
	return number;
}


void
mymod (id, maxu, pp, qq)	/* pp: readid, qq: readbit */
     unsigned int id;
     int maxu, *pp;
     unsigned char *qq;
{
	*pp = (id - 1) % 8;
	*qq = 0x1;
	*qq = *qq << *pp;
	*pp = ((id - 1) / 8) % maxu;
}


int
append_article (fname, path, author, title, ident, stamp, artmode)
     char *fname, *path, *author, *title;
     char *stamp;
     char ident;
     int artmode;
{
	char dotdir[PATHLEN], fn_stamp[PATHLEN];
	char stamps[14];	/* M.987654321.A */
	FILEHEADER fhbuf, *fhr = &fhbuf;
	struct stat st;
	int fd;

	if (stat (path, &st) == -1)
		return -1;
	get_only_name (path, stamps);
	sprintf (fn_stamp, "%s/%s", path, stamps);
	if (mycp (fname, fn_stamp) == -1)
		return -1;
	memset (fhr, 0, FH_SIZE);
	strcpy (fhr->filename, stamps);
	strcpy (fhr->owner, author);
	strcpy (fhr->title, title);
#ifdef IDENT
	fhr->owner_ident = ident;
#endif
	sprintf (dotdir, "%s/%s", path, DIR_REC);
	if (artmode)
		fhr->artno = get_only_artno (dotdir);
	if (stamp)
		strcpy (stamp, stamps);

	if ((fd = open (dotdir, O_WRONLY | O_APPEND | O_CREAT, 0644)) < 0)
		return -1;
	flock (fd, LOCK_EX);
	if (write (fd, fhr, FH_SIZE) != FH_SIZE)
	{
		flock (fd, LOCK_UN);
		close (fd);
		return -1;
	}
	flock (fd, LOCK_UN);
	close (fd);

	return fhr->artno;
}


/*******************************************************************
 *
 * All function that used by t/s bbs server and c/s bbs server 
 *
 *******************************************************************/

unsigned int
update_user_passfile (ubuf)
     USEREC *ubuf;
{
	int fd;

	if (ubuf == NULL || ubuf->userid[0] == '\0')
		return -1;

	if ((fd = open (PASSFILE, O_WRONLY | O_CREAT, 0600)) > 0)
	{
/* �٥h lock �ʧ@, �[�ֳB�z */
		if (lseek (fd, (off_t) ((ubuf->uid - 1) * sizeof (USEREC)), SEEK_SET) != -1)
		{
			if (write (fd, ubuf, sizeof (USEREC)) == sizeof (USEREC))
			{
				close (fd);
				return 0;
			}
		}
		close (fd);
	}
	return -1;
}


char *
mycrypt (pw)
     char *pw;
{
	static char saltc[14];

	unsigned char c;
	int i;

	sprintf (saltc, "%13.13s", pw);

	for (i = 0; saltc[i]; i++)
	{
		c = saltc[i] + '.';
		if (c > '9')
			c += 7;
		if (c > 'Z')
			c += 6;
		saltc[i] = c;
	}
	return saltc;
}


#define KEYWORD_DELIMITER     " \t\r\n"
#define KEYWORD_SEPARATE      " \t\r\n"

char *
PhaseSpace (str)
     char *str;
{
	register int i, j = 0;

	if (str[0] == '\0')
		return &str[0];
	while (strchr (KEYWORD_DELIMITER, str[j]))
		j++;

	i = strlen (str) - 1;
	while (i >= 0 && strchr (KEYWORD_DELIMITER, str[i]))
		i--;
	str[i + 1] = '\0';

	return &str[j];
}


char *
GetPass (str, token, maxlen)
     char *str;
     char *token;
     int maxlen;
{
	register int i = 0, j;
	char *tmp;

	while (strchr (KEYWORD_DELIMITER, str[i]))	/* �h���e�����ť� */
	{
		if (str[i] == '\0')
		{
			token[0] = '\0';
			return &str[i];
		}
		i++;
	}
	tmp = &str[i];
	j = 1;
	while (!strchr (KEYWORD_SEPARATE, tmp[j]))	/* �Htab�����j�A��X�Ѽ� */
		j++;

	if (j >= maxlen)
	{			/* token too large */
		j = maxlen - 1;	/* lasehu */
	}
	strncpy (token, tmp, j);
	token[j] = '\0';	/* important */
	return &tmp[j];
}
