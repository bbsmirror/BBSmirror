
#define _BBS_GLOBAL_VAR_	/* for include global variables in bbs.h */

#include "bbs.h"
#include "tsbbs.h"

extern char *genpasswd();


char myfromhost[HOSTLEN];
char myuserid[IDLEN + 1], mypasswd[PASSLEN];

int newreg_number = 0;


void
abort_new_reg()
{
	struct useridx uidx;

	memset(&uidx, 0, sizeof(uidx));
	substitute_record(USERIDX, &uidx, sizeof(uidx), newreg_number);
}


/*******************************************************************
 * �T�����u
 *******************************************************************/
void
abort_bbs()
{
	if (newreg_number)
		abort_new_reg();
	else
		user_logout();
	exit(0);
}


/*******************************************************************
 * �I��a
 *******************************************************************/
void
warn_bell()
{
	register int i = 5;

	while (i--)
		bell();
}


void
talk_request()
{
#if	defined(LINUX) || defined(SOLARIS)
	signal(SIGUSR1, talk_request);
#endif
	talkrequest = YEA;
	warn_bell();
}


void
write_request()
{
#if	defined(LINUX) || defined(SOLARIS)
	signal(SIGUSR2, write_request);
#endif
	writerequest = YEA;
	warn_bell();
}




/*******************************************************************
 * �ˬd�s�襢�ѳƥ���
 *******************************************************************/
void
user_init()
{
	sprintf(bbstitle, "%s", BBSTITLE);

	if (HAS_PERM(PERM_SYSOP) || HAS_PERM(PERM_BM))
		maxkeepmail = SPEC_MAX_KEEP_MAIL;
	else
		maxkeepmail = MAX_KEEP_MAIL;
	if (HAS_FLAG(COLOR_FLAG))
		show_ansi = NA;
	else
		show_ansi = YEA;

	sprintf(tempfile, "tmp/bbs%05d", getpid());

	setmailfile(maildirect, curuser.userid, DIR_REC);

	sethomefile(ufile_overrides, curuser.userid, UFNAME_OVERRIDES);
	sethomefile(ufile_boardrc, curuser.userid, UFNAME_BOARDRC);
	setuserfile(ufile_write, curuser.userid, UFNAME_WRITE);

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
	{
		curuser.flags[1] &= ~PICTURE_FLAG;
		return;
	}
#endif

#ifdef IDENT
	if (curuser.ident > 7 || curuser.ident < 0)	/* debug */
	{
		curuser.ident = 0;
		update_user(&curuser);
	}
#endif
	if (multi == 1)
		unlink(ufile_write);	/* lasehu */
	if ((curuser.numlogins % 5) == 0)	/* lasehu */
		pack_article(maildirect);
}




void
new_register(nu)
     USEREC *nu;
{
	short attempts = 0;

	memset(nu, 0, sizeof(USEREC));

	if (dashf(NONEWUSER) || (nu->uid = new_user(NULL)) <= 0)
	{
		more(NONEWUSER, NA);
		sleep(2);
		exit(1);
		/* NOT REACHED */
	}
	newreg_number = nu->uid;	/* lasehu */
	outs("\n�w��! �s���, �п�J�z�ҧƱ檺�N��(�@�ӭ^��W�r)\n");
	while (1)
	{
		getdata(0, 0, "�ϥΪ̥N�� (user id) : ", nu->userid, IDLEN + 1, ECHONOSP, NULL);
		if (invalid_userid(nu->userid))
		{
			prints("\n�п�J�ܤ� %d �Ӧr��, ���i���S���Ÿ�, �ť�, �Ʀr, �����r��\n", LEAST_IDLEN);
			if (++attempts >= 3)
			{
				fprintf(stdout, "\n�z�٬O�S�Q�n�n�ϥΪ��N��, �U���A���o ...");
				fflush(stdout);
				sleep(2);
				abort_bbs();
				/* NOT REACHED */
			}
			continue;
		}
/* lasehu */
		if (get_passwd(NULL, nu->userid) > 0)
		{
			outs("\n���N���w�Q�ϥ�, �д��@��\n\n");
			continue;
		}
		strcpy(myuserid, nu->userid);
		break;
	}
	while (1)
	{
		getdata(0, 0, "�K�X(password, 4 - 8 �Ӧr) : ", mypasswd, CRYPTLEN + 1, NOECHO, NULL);
		if (strlen(mypasswd) < 4)
		{
			outs("\n�K�X���צܤ֭n 4 �Ӧr��\n\n");
			continue;
		}
		if (!strcmp(mypasswd, nu->userid))
		{
			outs("\n�ФŨϥλP ID �ۦP�ΤӹL��²����q���K�X\n\n");
			continue;
		}
		getdata(0, 0, "�A���@���K�X(check) : ", genbuf, CRYPTLEN + 1, NOECHO, NULL);
		if (strcmp(genbuf, mypasswd))
		{
			outs("\n�⦸��J���K�X���@��, �Э��s�]�w.\n\n");
			continue;
		}
		break;
	}
	STRNCPY(nu->passwd, genpasswd(mypasswd), PASSLEN);

	getdata(0, 0, "�L�m�j�W (Name ���^��ҥi) : ", nu->username, sizeof(nu->username), DOECHO, NULL);
	getdata(0, 0, "�q�l�l��a�} : ", nu->email, sizeof(nu->email), DOECHO, NULL);
	nu->firstlogin = time(0);	/* lasehu */
	nu->lastlogin = prev_lastlogin = time(0);
	strncpy(nu->lasthost, myfromhost, sizeof(nu->lasthost));
	strncpy(prev_from, myfromhost, sizeof(prev_from));

#ifdef SYSOP
	if (!strcmp(nu->userid, SYSOP))
		nu->userlevel |= PERM_SYSOP;
	else
#endif
		nu->userlevel = PERM_DEFAULT;

	if (new_user(nu) > 0)	/* �N�ϥΪ̵��U�Ҷ��Ƽg�J���e�b .PASSWDS ��쪺�Ŧ� */
	{
		newreg_number = 0;
	}
	else
	{
		fprintf(stdout, "\n\r�طs�b������, �����u");
		fflush(stdout);
		sleep(2);
		abort_bbs();
		/* NOT REACHED */
	}
}


int
user_login()
{
	FILE *fp;

	memset(&uinfo, 0, sizeof(USER_INFO));

	if ((uinfo.active = new_utmp()) <= 0)
		return -1;
		if (get_passwd(&curuser, myuserid) <= 0)
		{
			fprintf(stdout, _msg_err_userid);
			fflush(stdout);
			return -1;
		}
#ifdef GUEST_ACCOUNT
		if (strcmp(curuser.userid, GUEST_ACCOUNT))
		{
#endif
			if (curuser.passwd[0] == '\0')
			{
				fprintf(stdout, "\n\r���b���w�Q����.");
				fflush(stdout);
				sleep(2);
				return -1;
			}
			if (!checkpasswd(curuser.passwd, mypasswd))
				return -1;
#ifdef GUEST_ACCOUNT
		}
#endif

	strcpy(curuser.userid, myuserid);	/* ? */
	strcpy(uinfo.userid, myuserid);
	strcpy(uinfo.username, curuser.username);	/* lasehu */
	strncpy(uinfo.from, myfromhost, sizeof(uinfo.from) - 1);
	uinfo.from[sizeof(uinfo.from) - 1] = '\0';
	uinfo.pid = getpid();
	uinfo.uid = curuser.uid;
	uinfo.invisible = (HAS_FLAG(CLOAK_FLAG) && HAS_PERM(PERM_CLOAK)) ? YEA : NA;
	uinfo.c_type = CTYPE_TSBBS;
	uinfo.mode = LOGIN;
	uinfo.pager = !HAS_FLAG(PAGER_FLAG);
	update_utmp();		/* lasehu */

#ifdef GUEST_ACCOUNT
		if (!strcmp(curuser.userid, GUEST_ACCOUNT))
			curuser.userlevel = 0;
		else
#endif		
		{
			if (curuser.userlevel < NORMAL_USER_LEVEL)
				curuser.userlevel++;
		}
		prev_lastlogin = curuser.lastlogin;
		curuser.lastlogin = time(0);
		if ((curuser.lastlogin - prev_lastlogin) > 180)	/* lasehu */
			curuser.numlogins++;
		strcpy(prev_from, curuser.lasthost);
		strcpy(curuser.lasthost, myfromhost);
		curuser.lastctype = CTYPE_TSBBS;	/* lasehu */

	update_user(&curuser);	/* lasehu */

	sethomefile(genbuf, myuserid, UFNAME_RECORDS);
#ifdef GUEST_ACCOUNT
	if (strcmp(curuser.userid, GUEST_ACCOUNT))
#endif
		if ((fp = fopen(genbuf, "a")) != NULL)
		{
			fprintf(fp, "%s %s", myfromhost, ctime(&(curuser.lastlogin)));
			fclose(fp);
		}
	return 0;
}


void
login_query()
{
	int act;

	FILE *fp;

	act = ask_online_user();

	prints("\n�w����{ [1;37m%s[m, �ثe�u�W�� [%d/%d] �H\n", BBSNAME, act, MAXACTIVE);

#ifdef SHOW_UPTIME
	if ((fp = fopen(SHOW_UPTIME, "r")) != NULL)
	{
		if (fgets(genbuf, sizeof(genbuf), fp))
		{
			char *ptr;

			ptr = strrchr(genbuf, ':') + 1;
			prints("�t�� (1,10,15) �����������t�����O�� %s", ptr);
		}
		fclose(fp);
	}
#endif

	if (act > MAXACTIVE)
	{
		fprintf(stdout, "\n\r[1;32m�W�� %d �H, �еy�ԦA��", MAXACTIVE);
		fflush(stdout);
		sleep(1);
		exit(0);
	}

	for (act = 0; act <= LOGINATTEMPTS; act++)
	{
		if (act == LOGINATTEMPTS)
		{
			fprintf(stdout, "\n\r��p, �A�w���� %d ��, �U���A�ӧa!", LOGINATTEMPTS);
			fflush(stdout);
			sleep(2);
			exit(0);
		}

#ifdef LOGINASNEW
		outs("\n�Y�Q���U�s�b��, �п�J 'new'");
#ifdef GUEST_ACCOUNT
		prints(" (���[�п�J '%s')", GUEST_ACCOUNT);
#endif	/* GUEST_ACCOUNT */
#else	/* LOGINASNEW */
#ifdef GUEST_ACCOUNT
		prints("\n�Y�Q���[�п�J '%s'", GUEST_ACCOUNT);
#endif
#endif /* !LOGINASNEW */

		if (!getdata(3, 0, "\n�п�J�N��(user id) : ", myuserid, IDLEN + 1, ECHONOSP, NULL))
		{
			outs(_msg_err_userid);
		}
		else if (!strcmp(myuserid, "new"))
		{
#ifndef LOGINASNEW
			if (dashf(NONEWUSER))
			{
				more(NONEWUSER, NA);
				oflush();
			}
			else
				printf("\n\r���t�Τ������s�ϥε��U !!");
#ifdef GUEST_ACCOUNT
			printf("\n\r�ХH guest ���[�αb���i��.");
#endif
			sleep(2);
			exit(1);
			/* NOT REACHED */
#endif
			if (dashf(NONEWUSER))
			{
				printf("\n\r���t�Τ������s�ϥε��U !!");
				more(NONEWUSER, NA);
				oflush();
				sleep(2);
				exit(1);
				/* NOT REACHED */
			}
			new_register(&curuser);
			if (user_login() == 0)
				break;
		}
		else
		{
#ifdef GUEST_ACCOUNT
			if (!strcmp(myuserid, GUEST_ACCOUNT))
			{
				getdata(4, 0, "�п�J�K�X(password) : <�Ъ����� Enter �Y�i>  ", mypasswd, CRYPTLEN + 1, NOECHO, NULL);
				if (user_login() == 0)
					break;
			}
#endif
			if (getdata(4, 0, "�п�J�K�X(password) : ", mypasswd, CRYPTLEN + 1, NOECHO, NULL))
			{
				if (user_login() == 0)
					break;;
			}
			outs("�K�X���~ !!\n");
			fflush(stdout);
		}
	}

}


void
user_logout()
{
	USEREC usrbuf;

	unlink(tempfile);	/* �M���ϥΪ̩󦹦��W�����Ȧs�γ~�� */
#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
	{
		purge_ulist(&uinfo);
		return;
	}
#endif

	if (ever_del_mail)
		pack_article(maildirect);
	if (uinfo.pager)
		UNSET_FLAG(PAGER_FLAG);
	else
		SET_FLAG(PAGER_FLAG);
	if (get_passwd(&usrbuf, curuser.userid) > 0)
	{
#ifdef IDENT
			if (usrbuf.ident > curuser.ident)
				curuser.ident = usrbuf.ident;
#endif
		curuser.numposts += numposts;
	}
	update_user(&curuser);
	update_user_passfile(&curuser);
	purge_ulist(&uinfo);
}


void
RecordVisitor()
{
	struct visitor v;
	int fd;

	strcpy(v.userid, curuser.userid);
	strcpy(v.from, curuser.lasthost);
	v.when = curuser.lastlogin;
	if ((fd = open(PATH_VISITOR, O_WRONLY | O_CREAT | O_APPEND, 0644)) > 0)
	{
		write(fd, &v, sizeof(v));
		close(fd);
	}
}




int
invalid_userid(userid)
     char *userid;
{
	char buf[IDLEN + 1];
	int i;
	unsigned char ch;

	if (!userid || userid[0] == '\0')
		return 1;
	i = strlen(userid);
	if (i < LEAST_IDLEN || i > IDLEN)
		return 1;
	for (i = 0; i < sizeof(buf) && (ch = userid[i]); i++)
	{
		if (!isalpha(ch))
			return 1;
		if (ch >= 'A' && ch <= 'Z')
			buf[i] = (ch | 32);
		else
			buf[i] = ch;
	}
	buf[i] = '\0';
	if (!strcmp(buf, "new") || seek_in_file(BADUSERID, buf))
		return 1;
#ifndef SYSOP
	if (strstr(buf, "sysop"))
		return 1;
#endif
	return 0;
}


/*******************************************************************
 * Announce     
 *******************************************************************/
Announce()
{
	more(WELCOME, YEA);
	return M_FULL;
}

/*******************************************************************
 * list all registered user
 *******************************************************************/
Users()
{
	int fd, sysop, bm, total, ch, spec_total;
	unsigned int spec_ulevel;
	short i = 3, show = YEA;

#ifdef IDENT
	int idented = 0;

#endif
	USEREC all_urc;

	spec_ulevel = 0;
	total = spec_total = 0;
	sysop = bm = 0;

	if (getdata(1, 0, "�n�d�ݵ��Ŧh�֥H�W���ϥΪ� ? [0] : ", genbuf, 4, ECHONOSP, NULL))
		spec_ulevel = atoi(genbuf);

	if ((fd = open(PASSFILE, O_RDONLY)) < 0)
		return -1;

	move(1, 0);
	clrtobot();
	prints("%-12s %-20s %6s %6s %4s", "�N�W", "���W", "�W����", "�i�K��", "����");
	outs("\n------------------------------------------------------------------------------");

	while (read(fd, &all_urc, sizeof(USEREC)) == sizeof(USEREC))
	{
		if (all_urc.userid[0] == '\0' || !strcmp(all_urc.userid, "new"))
			continue;
		total++;
		if (all_urc.userlevel == 255)
			sysop++;
		else if (all_urc.userlevel >= 100)
			bm++;

		if (all_urc.userlevel < spec_ulevel)
			continue;
		spec_total++;
#ifdef IDENT
		if (all_urc.ident == 7)
			idented++;
#endif
		if (show)
		{
			move(i, 0);
			clrtoeol();
			prints("%-12s %-20.20s %6d %6d %4d\n",
			       all_urc.userid, all_urc.username, all_urc.numlogins, all_urc.numposts,
			       all_urc.userlevel);
			if (++i == b_line)
			{
				outs("[37;45m--- �٦��@ ---[44m [q] or [��]:���} , [��][n][Space]:�U�@��        [m");
				ch = igetkey();
				if (ch == KEY_LEFT || ch == 'q')
				{
					show = NA;
					continue;
				}
				i = 3;
				move(i, 0);
				clrtobot();
			}
		}
	}
	close(fd);
	clrtobot();
	move(b_line, 0);
	if (spec_ulevel == 0)
		prints("[37;44m���U�H�� %d �H, ", total);
	else
		prints("[37;44m�έp�H�� %d/%d �H, ", spec_total, total);
	prints("�޲z�� %d �H, �O�D %d �H", sysop, bm);
#ifdef IDENT
	prints(", (�q�L�{�� %d �H)[m", idented);
#endif
	getkey();
	return M_FULL;
}


/*******************************************************************
 * BBSNET, provide menu for telnet other bbs
 *******************************************************************/
#ifdef USE_BBSNET
int
BBSNet()
{
	outdoor("door", UNDEFINE, NA);
	return M_FULL;
}
#endif


/*******************************************************************
 * Main function of BBS
 *******************************************************************/
void
Formosa(host, term)
     char *host, *term;
{
	FILE *wel;

	if ((wel = fopen(BBSSRV_WELCOME, "r")))
	{
		while (fgets(genbuf, sizeof(genbuf), wel))
			outs(genbuf);
		fclose(wel);
	}

#ifdef CHROOT_BBS
		if (chroot(HOMEBBS) || chdir("/"))
			return;
#else	/* CHROOT_BBS */
	if (chdir(HOMEBBS) == -1)
	{
		printf("\ncannot change directory to [%s].\n", HOMEBBS);
		return;
	}
#endif	/* !CHROOT_BBS */
	if (getuid() != BBS_UID)
	{
		setgid(BBS_GID);
		setuid(BBS_UID);
	}

#ifndef lint
	signal(SIGHUP, abort_bbs);

	signal(SIGBUS, abort_bbs);
	signal(SIGTERM, abort_bbs);
	signal(SIGCHLD, SIG_IGN);	/* ? */
	signal(SIGINT, SIG_IGN);
	signal(SIGQUIT, SIG_IGN);
	signal(SIGPIPE, SIG_IGN);

	signal(SIGURG, SIG_IGN);
	signal(SIGTSTP, SIG_IGN);
	signal(SIGTTIN, SIG_IGN);
	signal(SIGTTOU, SIG_IGN);

	signal(SIGUSR1, talk_request);
	signal(SIGUSR2, write_request);
#endif /* ifndef lint */


	if (host)
	{
			STRNCPY(myfromhost, host, sizeof(myfromhost));
	}
	else
		strcpy(myfromhost, "local");

	init_tty();

	login_query();

#ifdef TIMEOUT
	init_alarm(IDLE_TIMEOUT);
#else
	signal(SIGALRM, SIG_IGN);
#endif

	term_init("vt100");
	initscr();
	RecordVisitor();
	multi_user_check();
	user_init();

	more(WELCOME0, YEA);
	Announce();

	domenu();
}
