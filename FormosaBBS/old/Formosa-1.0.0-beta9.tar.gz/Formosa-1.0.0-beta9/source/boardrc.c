
#include "bbs.h"
#include "tsbbs.h"




char    currboard[STRLEN] = "�|����w";		/* lasehu */

unsigned int     brc_size, brc_changed = 0;
unsigned char brc_list[BRC_MAXNUM];
time_t  brc_rtime = 0;		/* ? */

char    brc_buf[BRC_MAXSIZE];
char    brc_name[BRC_STRLEN];

unsigned char brc_readbit;
int     brc_readid;
int     new_visit = 0;


static char *
brc_getrecord(ptr, name, list, rtime)
char   *ptr, *name;
unsigned char *list;
time_t *rtime;
{
	strncpy(name, ptr, BRC_STRLEN);
	ptr += BRC_STRLEN;
	memcpy(list, ptr, BRC_MAXNUM * sizeof(unsigned char));
	ptr += BRC_MAXNUM * sizeof(unsigned char);

	memcpy(rtime, ptr, 1 * sizeof(time_t));
	ptr += 1 * sizeof(time_t);

	return ptr;
}


static char *
brc_putrecord(ptr, name, list, rtime)
char   *ptr, *name;
unsigned char *list;
time_t *rtime;
{
	strncpy(ptr, name, BRC_STRLEN);
	ptr += BRC_STRLEN;
	memcpy(ptr, list, BRC_MAXNUM * sizeof(unsigned char));
	ptr += BRC_MAXNUM * sizeof(unsigned char);

	memcpy(ptr, rtime, 1 * sizeof(time_t));
	ptr += 1 * sizeof(time_t);

	return ptr;
}


void
brc_update()
{
#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return;
#endif

	if (brc_changed)
	{
		char    dirfile[PATHLEN], *ptr;
		char    tmp_buf[BRC_MAXSIZE - BRC_ITEMSIZE], *tmp;
		char    tmp_name[BRC_STRLEN];
		int     tmp_list[BRC_MAXNUM];
		int     fd, tmp_size;
		time_t  tmp_rtime;

		ptr = brc_buf;
/*      if (brc_num > 0) */
		ptr = brc_putrecord(ptr, brc_name, brc_list, &brc_rtime);
		strcpy(dirfile, ufile_boardrc);
		if ((fd = open(dirfile, O_RDWR | O_CREAT, 0644)) > 0)
		{
			tmp_size = read(fd, tmp_buf, sizeof(tmp_buf));
			close(fd);
		}
		else
		{
			tmp_size = 0;
		}

		tmp = tmp_buf;
		while (tmp < &tmp_buf[tmp_size] && (*tmp >= ' ' && *tmp <= 'z'))
		{
			tmp = brc_getrecord(tmp, tmp_name, tmp_list, &tmp_rtime);
			if (strncmp(tmp_name, currboard, BRC_STRLEN))
				ptr = brc_putrecord(ptr, tmp_name, tmp_list, &tmp_rtime);
		}
		brc_size = (unsigned int) (ptr - brc_buf);
		if (brc_size > BRC_MAXSIZE)	/* lasehu */
			brc_size = BRC_MAXSIZE;

		if ((fd = open(dirfile, O_WRONLY | O_CREAT, 0644)) > 0)
		{
			ftruncate(fd, 0);
			write(fd, brc_buf, brc_size);
			close(fd);
		}
		brc_changed = 0;
	}
}


void
brc_initial(boardname)
char   *boardname;
{
	char    dirfile[PATHLEN], *ptr;
	int     fd;

	if (!strcmp(currboard, boardname))
		return;

	new_visit = 0;		/* lasehu */

	brc_update();
	strcpy(currboard, boardname);
	if (brc_buf[0] == '\0')	/* ? */
	{
		strcpy(dirfile, ufile_boardrc);
		if ((fd = open(dirfile, O_RDONLY)) > 0)
		{
			brc_size = read(fd, brc_buf, sizeof(brc_buf));
			close(fd);
		}
		else
		{
			brc_size = 0;
		}
	}
	ptr = brc_buf;
	while (ptr < &brc_buf[brc_size] && (*ptr >= ' ' && *ptr <= 'z'))
	{
		ptr = brc_getrecord(ptr, brc_name, brc_list, &brc_rtime);
		if (!strncmp(brc_name, currboard, BRC_STRLEN))
			return;
	}

	new_visit = 1;		/* lasehu */

	strncpy(brc_name, boardname, BRC_STRLEN);
	memset(brc_list, 0, sizeof(brc_list));
	brc_rtime = time(0);	/* ? */
}


void
brc_addlist(artno)
int     artno;
{

	if (artno <= 0 || artno > BRC_REALMAXNUM)
		return;

	if ((!in_board && !in_mail) || in_mail)	/* lasehu */
		return;

	mymod(artno, BRC_MAXNUM, &brc_readid, &brc_readbit);

	brc_list[brc_readid] |= brc_readbit;
	brc_changed = 1;
}


int
brc_unread(artno)
int     artno;
{
	if (artno <= 0 || artno > BRC_REALMAXNUM)
		return 1;

	mymod(artno, BRC_MAXNUM, &brc_readid, &brc_readbit);


	if (brc_list[brc_readid] & brc_readbit)
		return 0;
	return 1;
}


#define DIRECTION_INC	1
#define DIRECTION_DEC	0


void
brc_mod(no, max, rbyte, rbit, direction)
unsigned int no;
int     max, *rbyte;
unsigned char *rbit;
int     direction;
{
	unsigned char onebit = 0x1;
	int     shift;

	shift = (no - 1) % 8;
	onebit = onebit << shift;
	*rbit = onebit;
	if (direction == DIRECTION_INC)
		shift = 7 - shift;
	while (shift--)
	{
		if (direction == DIRECTION_INC)
			onebit = onebit << 1;
		else if (direction == DIRECTION_DEC)
			onebit = onebit >> 1;
		*rbit |= onebit;
	}
	*rbit &= ~(*rbit);
	*rbyte = ((no - 1) / 8) % max;
	return;
}


void
brc_clean(startno, endno)
int     startno, endno;
{
	int     size;
	int     startbyte, endbyte;
	unsigned char startbit, endbit;
	unsigned char oribit;

	brc_mod(startno, BRC_MAXNUM, &startbyte, &startbit, DIRECTION_INC);
	brc_mod(endno, BRC_MAXNUM, &endbyte, &endbit, DIRECTION_DEC);
	size = endbyte - startbyte;
	if (size >= 1)
	{
		memcpy(&oribit, brc_list + startbyte, 1);
		oribit &= (~startbit);
		startbit |= oribit;
		memset(brc_list + startbyte, startbit, 1);

		if (size >= 2)
			memset(brc_list + startbyte + 1, 0, size - 1);

		memcpy(&oribit, brc_list + endbyte, 1);
		oribit &= (~endbit);
		endbit |= oribit;
		memset(brc_list + endbyte, endbit, 1);

		brc_rtime = time(0);
		if (!new_visit)
			brc_changed = 1;
	}

	return;
}


void
refresh_brc()
{
	time_t  new_rtime = curb->word->rewind_time;
	int     lastno = 0, firstno = 0;
	int     total;
	char    fname[STRLEN];
	FILEHEADER gfhbuf;

	if (new_rtime < 0)
		new_rtime = 0;
	if (brc_rtime < new_rtime)
	{
		memset(brc_list, 0, BRC_MAXNUM / 2);
		brc_rtime = new_rtime;
		brc_changed = 1;
	}
	setboardfile(fname, curb->word->name, DIR_REC);
	total = get_num_records(fname, FH_SIZE);
	if (get_record(fname, &gfhbuf, FH_SIZE, 1) == 0)
	{
		firstno = gfhbuf.artno;
		if (get_record(fname, &gfhbuf, FH_SIZE, total) == 0)
			lastno = gfhbuf.artno;
	}


	if (firstno >= 1 && firstno <= BRC_REALMAXNUM
	    && lastno >= 1 && lastno <= BRC_REALMAXNUM)
	{
		if (firstno > lastno)
		{
			brc_clean(lastno + 1, firstno - 1);
		}
		else
		{
			if (firstno > 1)
				brc_clean(1, firstno - 1);
			if (lastno < BRC_REALMAXNUM)
				brc_clean(lastno + 1, BRC_REALMAXNUM);
		}
	}
}
