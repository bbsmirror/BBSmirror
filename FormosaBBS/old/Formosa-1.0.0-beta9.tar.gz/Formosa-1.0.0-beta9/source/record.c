
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>


#ifndef LOCK_EX
#define LOCK_EX        F_LOCK	/* exclusive lock */
#define LOCK_UN        F_ULOCK	/* unlock */
#endif

#ifndef MAXPATHLEN
#define MAXPATHLEN	256
#endif


/*******************************************************************
 * ����w���� write function, �����n���^�g�i�ϥΤ�.
 *******************************************************************/
safewrite(fd, buf, size)
int     fd;
char   *buf;
int     size;
{


	return write(fd, buf, size);

}


/*******************************************************************
 * �ǤJ "�ɦW" �P record length,
 * �Ǧ^���ɤ��@���X�� records.
 *******************************************************************/
long
get_num_records(filename, size)
char    filename[];
int     size;
{
	struct stat st;

	if (stat(filename, &st) == -1)
		return 0;
	return (st.st_size / size);
}


/*******************************************************************
 * �ǤJ "�ɦW" , record �P record length,
 * �N�� record ���[���ɧ�.
 *******************************************************************/
append_record(filename, record, size)
char    filename[];
char   *record;
int     size;
{
	int     fd;

	if ((fd = open(filename, O_WRONLY | O_CREAT, 0644)) > 0)
	{
		flock(fd, LOCK_EX);
		if (lseek(fd, 0, SEEK_END) != -1)
		{
			if (safewrite(fd, record, size) != -1)
			{
				flock(fd, LOCK_UN);
				close(fd);
				return 0;
			}
		}
		flock(fd, LOCK_UN);
		close(fd);
	}
	return -1;
}




/*******************************************************************
 * �ǤJ "�ɦW", buf record, record length, record number(�ĴX��)
 * Ū�X�ɤ��� id �� record �� rptr buffer
 *******************************************************************/
get_record(filename, rptr, size, id)
char   *filename;
char   *rptr;
int     size;
unsigned int id;
{
	int     fd;

	if ((fd = open(filename, O_RDONLY, 0)) > 0)
	{
		if (lseek(fd, (off_t) ((id - 1) * size), SEEK_SET) != -1)
		{
			if (read(fd, rptr, size) == size)
			{
				close(fd);
				return 0;
			}
		}
		close(fd);
	}
	return -1;
}


/*******************************************************************
 * �ǤJ "�ɦW", record length, �ĴX��.
 * �R�����ɲ� id �� record.
 *******************************************************************/
delete_record(filename, size, id)
char   *filename;
int     size;
unsigned int id;
{
	int     fdr, fdw, fd;
	unsigned int     count;
	char    fn_lock[MAXPATHLEN], fn_new[MAXPATHLEN], fn_old[MAXPATHLEN];
	char    gbuffer[16384];

	if (size > sizeof(gbuffer))
	{
		bbslog("ERROR", "delete_record(): size too big in [%s]", filename);
		return -1;
	}

	sprintf(fn_lock, "%s.lock", filename);
	sprintf(fn_new, "%s.new", filename);
	sprintf(fn_old, "%s.old", filename);
	if ((fd = open(fn_lock, O_WRONLY | O_CREAT, 0644)) == -1)
		return -1;
	if ((fdr = open(filename, O_RDONLY)) == -1)
	{
		close(fd);
		return -1;
	}
	if ((fdw = open(fn_new, O_WRONLY | O_CREAT | O_TRUNC, 0644)) == -1)
	{
		close(fd);
		close(fdr);
		return -1;
	}

	flock(fd, LOCK_EX);
	for (count = 1; read(fdr, gbuffer, size) == size; count++)
	{
		if (count == id)
			continue;
		if (safewrite(fdw, gbuffer, size) == -1)
		{
			close(fdr);
			close(fdw);
			flock(fd, LOCK_UN);
			close(fd);
			return -1;
		}
	}
	close(fdr);
	close(fdw);
	if (rename(filename, fn_old) == 0)
	{
		if (rename(fn_new, filename) == 0)
		{
			unlink(fn_old);
			flock(fd, LOCK_UN);
			close(fd);
			return 0;
		}
		rename(fn_old, filename);
	}
	unlink(fn_new);
	flock(fd, LOCK_UN);
	close(fd);
	return -1;
}


/*******************************************************************
 * �ǤJ "�ɦW", record, record length, �ĴX��.
 * �N�ǤJ�� record �g�J��� id �� record.
 *******************************************************************/
substitute_record(filename, rptr, size, id)
char   *filename;
char   *rptr;
int     size;
unsigned int id;
{
	int     fd;

		if ((fd = open(filename, O_WRONLY)) > 0)
		{
			if (lseek(fd, (off_t) ((id - 1) * size), SEEK_SET) != -1)
			{
				if (safewrite(fd, rptr, size) == size)
				{
					close(fd);
					return 0;
				}
			}
			close(fd);
		}
	return -1;
}



