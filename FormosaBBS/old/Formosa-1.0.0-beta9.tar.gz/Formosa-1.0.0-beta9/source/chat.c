
#include "bbs.h"
#include "tsbbs.h"
#include "chat.h"


#ifdef lint
#include <sys/uio.h>
#endif
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>


int     chatline;

#define ECHATWIN	(t_lines - 2)
#define PLINE		(t_lines - 1)

#define BADCIDCHARS " %*$`\"\\;:|[{]},./?=~!@#^()<>"

char    MyChanname[CHANLEN];


char   *mycrypt();


void
fixchatid(chatid)
unsigned char *chatid;
{
	char   *p;

	if ((p = strstr(chatid, "�@")))		/* lasehu */
		memcpy(p, "__", 2);
	while (*chatid)
	{
		if (*chatid == '\n')
			break;
		chatid++;
	}
}


int     ac;
char    chatid[STRLEN];


#define CHATIDLEN	(8)
#define SAYWORD_POINT	(13)

t_chat()
{
	char   *colon;
	int     currchar;
	char    inbuf[120];
	int     page_pending = NA;
	int     ch;
	char    seedstr[STRLEN];
	long    seed;


	inbuf[0] = '\0';
	currchar = 0;
	chatline = 0;		/* initialize */

	strcpy(MyChanname, DEF_CHANNAME);	/* lasehu */

	if (!getdata(1, 0, "Enter Chat id: ", chatid, CHATIDLEN, ECHONOSP, NULL))
		strncpy(chatid, curuser.userid, CHATIDLEN);
	chatid[CHATIDLEN] = '\0';
	fixchatid(chatid);
/* ? */
	strcat(chatid, ":                      ");
	chatid[SAYWORD_POINT] = '\0';
	strcpy(inbuf, chatid);
/* ... */
	if ((ac = ConnectServer(MYHOSTIP, CHATPORT, TCP)) < 0)
	{
		perror("connect failed");
		pressreturn();
		return M_FULL;
	}

/* lasehu */
	net_gets(ac, genbuf, sizeof(genbuf));	/* receive ChatServer Hello
						   Welcome VersionInfo */
	net_gets(ac, seedstr, sizeof(seedstr));		/* receive Random Number for
							   Checksum */
	seed = atol(mycrypt(seedstr));
	if (HAS_PERM(PERM_BM) || HAS_PERM(PERM_SYSOP))
		net_printf(ac, "USRID\t%s\t%d\r\n", curuser.userid, seed + CHAT_KEY);
	else
		net_printf(ac, "USRID\t%s\t%d\r\n", curuser.userid, seed);
	if (!net_gets(ac, genbuf, sizeof(genbuf)))	/* lasehu */
		return M_FULL;
	if (GetRespNo(genbuf) != OK_CMD)	/* lasehu */
	{
		outs("\n\n�i�J chatroom ����!");
		pressreturn();
		return M_FULL;
	}
/* lasehu */
	{
		char   *foo;

		strcpy(genbuf, chatid);
		genbuf[CHATIDLEN] = '\0';
		if ((foo = strchr(genbuf, ':')))
			*foo = '\0';
	}

	net_printf(ac, "NICKNAME\t%s\r\n", genbuf);
	net_gets(ac, genbuf, sizeof(genbuf));
/* lasehu */
	{
		int     total = 0;

		net_printf(ac, "WHOALL\t%s\r\n", genbuf);
		net_gets(ac, genbuf, sizeof(genbuf));
		while (1)
		{
			genbuf[0] = '\0';
			net_gets(ac, genbuf, sizeof(genbuf));
			if (genbuf[0] != '.')
			{
				total++;
				continue;
			}
			break;
		}
		clear();
		sprintf(genbuf, "*** �ثe��ѫǤ��@�� %d �H.", total);
		printchatline(genbuf);
	}
	uinfo.mode = CHATROOM;
/* ? */
	strncpy(uinfo.chatid, chatid, SAYWORD_POINT);
	if ((colon = strrchr(uinfo.chatid, ':')))
		*colon = '\0';
/* ... */
	update_utmp();


	printchatline("�� /help �i�ݨϥλ���");
	printchatline("  ");
	move(ECHATWIN, 0);
	prints("--------------------------------------------------------------------------------");
	move(PLINE, 0);
	strcpy(inbuf, chatid);
	if (!dumb_term)
		prints("%s", chatid);
	currchar = strlen(inbuf);
	add_io(ac, 0);
/* Chat Main */
	while (1)
	{
		if (writerequest)
		{
			writereply();
		      redraw:
			clear();
			move(ECHATWIN, 0);
			prints("--------------------------------------------------------------------------------");
			chatline = 0;	/* reset */
			printchatline("�� /help �i�ݻ����e��");
			printchatline("  ");	/* �L�ťզ�, �M�ᴫ�� */
			strcpy(inbuf, chatid);
			move(PLINE, 0);
			prints("%s", chatid);
			currchar = strlen(inbuf);
			continue;
		}
		ch = getkey();
		if (talkrequest)
			page_pending = YEA;
		if (page_pending)
			page_pending = servicepage(0);
		if (ch == I_OTHERDATA)
		{		/* ? */
			if (!net_gets(ac, genbuf, sizeof(genbuf)))
				break;
			printchatline(genbuf);
		}
		else if (isprint2(ch))
		{
				if (currchar == 75)
				{	/* ? */
					bell();
					continue;
				}
			inbuf[currchar++] = ch;
			inbuf[currchar] = '\0';
			move(PLINE, currchar - 1);
			prints("%c", ch);
		}
		else if (ch == '\n' || ch == '\r')
		{
			int     i, j;
			char    no_spcs[80];

			if (dumb_term)
				prints("\n");
			for (i = SAYWORD_POINT, j = 0; i < 80; i++)
			{
				if (inbuf[i] == '\0')
				{
					no_spcs[j] = '\0';
					break;
				}
				if (inbuf[i] != ' ')
					no_spcs[j++] = inbuf[i];
			}
			if (no_spcs[0] == '\0')
				continue;
			if (inbuf[SAYWORD_POINT] == '/')
			{	/* ? */
				int     action = dochatcommand(&inbuf[SAYWORD_POINT + 1]);

				if (action == 1)
				{
					strcpy(chatid, uinfo.chatid);
					chatid[CHATIDLEN] = '\0';
					strcat(chatid, ":                      ");	/* ? */
					chatid[SAYWORD_POINT] = '\0';
				}
				else if (action == -1)
					break;
			}
			else
			{
				printchatline(inbuf);	/* lasehu */
				net_printf(ac, "SPEAK\t%s\r\n", inbuf + SAYWORD_POINT);
			}

			strcpy(inbuf, chatid);
			currchar = strlen(chatid);
			if (!dumb_term)
			{
				move(PLINE, 0);
				outs(inbuf);
			}
			else
			       /* ? */
			{
				move(PLINE, 0);
				clrtoeol();
			}
			move(23, 10);
			clrtoeol();
		}
		else if (ch == CTRL('H') || ch == '\177')
		{
			if (currchar == SAYWORD_POINT)
			{
				bell();
				continue;
			}
			move(PLINE, --currchar);
			if (dumb_term)
				ochar(CTRL('H'));
			else
				prints(" ");
			inbuf[currchar] = '\0';
		}
		else if (ch == CTRL('C') || ch == CTRL('D'))
		{
			net_printf(ac, "QUIT\r\n");	/* lasehu */
			break;
		}
		else if (ch == CTRL('R'))
		{
			ReplyLastCall();
			goto redraw;
		}
		move(PLINE, currchar);
	}
	add_io(0, 0);
	close(ac);
	uinfo.chatid[0] = '\0';
	update_utmp();

	return M_FULL;
}

printchatline(str)
char   *str;
{
	move(chatline++, 0);
	clrtoeol();
	outs(str);
	if (chatline == ECHATWIN)
		chatline = 0;
	move(chatline, 0);
	clrtoeol();
	standout();
	if (!dumb_term)
		prints("-->");
	standend();
	return 0;
}



int
GetRespNo(str)
char   *str;
{
	char    keypass[PROTOLEN];

	GetPass(str, keypass, PROTOLEN);
	return atoi(keypass);
}


dowho(channame, fd)
char   *channame;
int     fd;
{
	char    buf[80];
	char    chatid[80], userid[80], fromip[80];
	int     cnt = 0;
	char    uline[80], pline[30];

	channame = PhaseSpace(channame);
	if (channame && *channame)
		net_printf(fd, "WHO\t%s\r\n", channame);
	else
		net_printf(fd, "WHO\t%s\r\n", MyChanname);	/* lasehu */

	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) != OK_CMD)
		return -1;

	printchatline(" ");
	printchatline("*** �{�b�o�̪��ȤH ***");
	sprintf(buf, "%-10s  %-12s   %-10s  %-12s   %-10s  %-12s",
		"�︹", "�N�W", "�︹", "�N�W", "�︹", "�N�W");
	printchatline(buf);
	sprintf(buf, "%-10s  %-12s   %-10s  %-12s   %-10s  %-12s",
		"------", "------", "------", "------", "------", "------");
	printchatline(buf);

	memset(uline, 0, sizeof(uline));
	do
	{
		net_gets(fd, buf, sizeof(buf));
		if (buf[0] == '.')
			break;
		sscanf(buf, "%s\t%s\t%s\r\n", userid, chatid, fromip);
		sprintf(pline, "%-10s  %-12s", chatid, userid);
		if (cnt < 2)
			strcat(pline, "   ");
		strcat(uline, pline);
		if (++cnt == 3)
		{
			cnt = 0;
			printchatline(uline);
			memset(uline, 0, sizeof(uline));
		}
	}
	while (buf[0] != '.');
	if (cnt < 3)
		printchatline(uline);
	return 0;
}


dowhoall(fd)
int     fd;
{
	char    buf[80];
	char    chatid[80], userid[80], channame[80];
	char   *NextPass;

	printchatline(" ");
	printchatline("*** �{�b�Ҧ����ȤH ***");
	sprintf(genbuf, "%-10s  %-12s   %-15s", "�︹", "�N�W", "�Ҧb�W�D");
	printchatline(genbuf);
	sprintf(genbuf, "%-10s  %-12s   %-15s", "------", "------", "------");
	printchatline(genbuf);
	net_printf(fd, "WHOALL\r\n");

	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) != OK_CMD)
		return -1;
	do
	{
		net_gets(fd, buf, sizeof(buf));
		if (buf[0] == '.')
			break;
		NextPass = GetPass(buf, userid, sizeof(userid));
		NextPass = GetPass(NextPass, chatid, sizeof(userid));
		NextPass = GetPass(NextPass, channame, sizeof(userid));
		sprintf(genbuf, "%-10s  %-12s   %-15s", chatid, userid, channame);
		printchatline(genbuf);
	}
	while (buf[0] != '.');
	return 0;
}



domsg(Token, fd)
char   *Token;
int     fd;
{
	char    user[IDLEN];

	Token = GetPass(Token, user, IDLEN);
	Token = PhaseSpace(Token);

	if (Token && *Token && *user)
	{
		net_printf(fd, "MSG\t%s\t%s\r\n", user, Token);
		net_gets(fd, genbuf, sizeof(genbuf));
		if (GetRespNo(genbuf) == OK_CMD)
			return 0;
		else if (GetRespNo(genbuf) == USR_FAIL)
			printchatline("*** �ثe�Ҧb�W�D�L���ϥΪ� �� �ʤ֭n�e�X���T�� **");
		else
			return -1;
	}
	return 0;
}


#ifdef HAVE_CHATMSGALL
domsgall(msg, fd)
char   *msg;
int     fd;
{
	net_printf(fd, "MSGALL\t%s\r\n", msg);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
		return 0;
	else
		return -1;
}

#endif





dolist(fd)
int     fd;
{
	char    buf[80];
	char    channame[80], topic[80], op[80], members[80], secret[80];

	printchatline(" ");
	printchatline("*** �ثe�Ҧ��W�D ***");
	sprintf(buf, "%-15s  %-20s  %-12s  %-6s  %-4s",
		"�W��", "�D�D", "�޲z��", "������", "��X");
	printchatline(buf);
	sprintf(buf, "%-15s  %-20s  %-12s  %-6s  %-4s",
		"------", "------", "------", "------", "------");
	printchatline(buf);
	net_printf(fd, "LISTCHAN\r\n");

	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) != OK_CMD)
		return -1;
	do
	{
		net_gets(fd, buf, sizeof(buf));
		if (buf[0] == '.')
			break;
		sscanf(buf, "%s\t%s\t%s\t%s\t%s\r\n", channame, topic, op, members, secret);
		sprintf(genbuf, "%-15s  %-20s  %-12s  %-6s  %-4s",
			channame, topic, op, members, secret);
		printchatline(genbuf);
	}
	while (buf[0] != '.');
	return 0;
}


dojoin(Token, fd)
char   *Token;
int     fd;
{
	char    channame[CHANLEN];

	Token = GetPass(Token, channame, CHANLEN);
	Token = PhaseSpace(Token);
	if (!Token || Token[0] == '\0' || *channame == '\0')
	{
		printchatline("*** ���~: �S�����w�n�[�J���W�D�W��");
		return 0;
	}
	if (!strcmp(channame, MyChanname))
	{
		printchatline("*** �z�w�g�b %s �W�D!");
		return 0;
	}
	net_printf(fd, "JOIN\t%s\t%s\r\n", channame, Token);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
	{
		strncpy(MyChanname, channame, CHANLEN - 1);
		sprintf(genbuf, "*** �[�J %s �W�D !!", channame);
		printchatline(genbuf);
	}
	else if (GetRespNo(genbuf) == PASS_FAIL)
	{
		sprintf(genbuf, "*** �[�J %s �W�D����: �v������ **", channame);
		printchatline(genbuf);
	}
	return 0;
}



dotopic(Token, fd)
char   *Token;
int     fd;
{
	char    topic[TOPICLEN];

	GetPass(Token, topic, TOPICLEN);
	if (*topic == '\0')
	{
		printchatline("*** ���~: �S�����w�D�D");
		return -1;
	}
	net_printf(fd, "TOPIC\t%s\r\n", topic);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
	{
		sprintf(genbuf, "** �󴫥��W�D�D�D��: %s **", topic);
		printchatline(genbuf);
		net_printf(fd, "SPEAK\t%s\r\n", genbuf);
	}
	else if (GetRespNo(genbuf) == PASS_FAIL)
		printchatline("*** �󴫥��W�D�D�D����: �v������ **");
	else
		return -1;
	return 0;
}

dopasswd(Token, fd)
char   *Token;
int     fd;
{
	char    pass[8];

	GetPass(Token, pass, 8);
	if (*pass == '\0')
	{
		printchatline("*** ���~: �S�����w�K�X");
		return -1;
	}
	net_printf(fd, "PASSWD\t%s\r\n", pass);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
	{
		sprintf(genbuf, "*** �󴫥��W�D�K�X��: %s", pass);
		printchatline(genbuf);
		net_printf(fd, "SPEAK\t%s\r\n", "*** �󴫥��W�D�K�X���� **");
	}
	else if (GetRespNo(genbuf) == PASS_FAIL)
		printchatline("*** �󴫥��W�D�K�X����: �v������ **");
	else
		return -1;
	return 0;
}

donopasswd(pass, fd)
char   *pass;
int     fd;
{
	net_printf(fd, "PASSWD\t%s\r\n", NOPASSWORD);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
	{
		printchatline("*** �Ѱ����W�D�K�X���� **");
		net_printf(fd, "SPEAK\t%s\r\n", "*** �Ѱ����W�D�K�X���� **");
	}
	else if (GetRespNo(genbuf) == PASS_FAIL)
		printchatline("*** �󴫥��W�D�K�X����: �v������ **");
	else
		return -1;
	return 0;
}


doignore(dest, fd)
char   *dest;
int     fd;
{
	dest = PhaseSpace(dest);
	if (dest && *dest)
	{
		dest[IDLEN - 1] = '\0';
		net_printf(fd, "IGNORE\t%s\r\n", dest);
		net_gets(fd, genbuf, sizeof(genbuf));
		if (GetRespNo(genbuf) == OK_CMD)
		{
			sprintf(genbuf, "*** ����ϥΪ� %s �o�� **", dest);
			printchatline(genbuf);
			net_printf(fd, "SPEAK\t%s\r\n", genbuf);
			log_usies("IGNORE", "%s", dest);
		}
		else if (GetRespNo(genbuf) == PASS_FAIL)
		{
			sprintf(genbuf, "*** ����ϥΪ� %s �o������: �v������ **", dest);
			printchatline(genbuf);
		}
	}
	return 0;
}


donick(newname, fd)
char   *newname;
int     fd;
{
	newname = PhaseSpace(newname);
	if (!newname || *newname == '\0')
	{
		printchatline("*** ���~: �ܤ֭n���ӦW�r");
		return -1;
	}
	newname[IDLEN - 1] = '\0';	/* ? */
	fixchatid(newname);
	net_printf(fd, "NICKNAME\t%s\r\n", newname);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
	{
		sprintf(genbuf, "*** �󴫰κ٬�: %s", newname);
		printchatline(genbuf);
		strncpy(uinfo.chatid, newname, sizeof(uinfo.chatid));
		uinfo.chatid[sizeof(uinfo.chatid) - 1] = '\0';
		update_utmp();
		return 1;	/* cause t_chat to update chatid */
	}
	else if (GetRespNo(genbuf) == NAME_FAIL)
	{
		printchatline("�κ٭���");
		return 0;
	}
	else
		return -1;
}

dochatcommand(cmd)
char   *cmd;
{
	char   *endcmd;
	int     retval = 0;

	while (*cmd == ' ')
		cmd++;
	for (endcmd = cmd; *endcmd; endcmd++)
		if (*endcmd == ' ' || *endcmd == '\n')	/* ? */
			break;

	if (*endcmd == '\0')
		*(endcmd + 1) = '\0';	/* ? */
	else
		*endcmd = '\0';
	if (!strcmp(cmd, "help") || !strcmp(cmd, "h"))
	{
		printchatline("�z�i�H�ϥγo�ǩR�O:");
		printchatline("  /help                   - �����e��              [/h]");
		printchatline("  /who                    - ���W�D����            [/w]");
		printchatline("  /who <�W�D�W��>         - �Y�W�D����            [/w]");
		printchatline("  /whoall                 - �Ҧ��W�D����          [/ws]");
		printchatline("  /join <�W�D> <��X�K�X> - �[�J�Y�W�D            [/j]");
		printchatline("  /list                   - �C�X�Ҧ��W�D          [/l]");
		printchatline("  /msg <�N�W> <������>    - �e <������> �� <�N�W> [/m]");
#ifdef HAVE_CHATMSGALL
		printchatline("  /msgall <�T��>          - ���W�D�s��            [/ma]");
#endif
		printchatline("  /pager                  - ���� Pager            [/p]");
		printchatline("  /nick <�︹>            - ��︹ <�︹>         [/n]");
		printchatline("  /me <���n����>          - �Фj�a�`�N�A����      [/me]");
		printchatline("  /clear                  - �M���e��              [/c]");
		printchatline("�H�U�R�O�ȴ��Ѻ޲z�̨ϥ�:");
		printchatline("  /passwd <�K�X>          - �]�w���W�D�K�X [/ps]");
		printchatline("  /nopasswd               - �Ѱ����W�D�K�X [/nps]");
		printchatline("  /topic <�D�D>           - ��糧�W�D�D�D [/t] ");
		printchatline("  [1;36m/ignore <�N�W>     - �ϬY�H���L�@�� [/i][m");
		printchatline("  ctrl-d                  - ���}");
	}
	else if (!strcmp(cmd, "who") || !strcmp(cmd, "w"))
	{
		retval = dowho(endcmd + 1, ac);
		if (retval == -1)
		{		/* lasehu */
			printchatline("*** ���w�W�D���s�b");
			return 0;
		}
	}
	else if (!strcmp(cmd, "whoall") || !strcmp(cmd, "ws"))
		dowhoall(ac);
	else if (!strcmp(cmd, "join") || !strcmp(cmd, "j"))
		retval = dojoin(endcmd + 1, ac);
	else if (!strcmp(cmd, "list") || !strcmp(cmd, "l"))
		retval = dolist(ac);
	else if (!strcmp(cmd, "msg") || !strcmp(cmd, "m"))
		retval = domsg(endcmd + 1, ac);
#ifdef HAVE_CHATMSGALL
	else if (!strcmp(cmd, "msgall") || !strcmp(cmd, "ma"))
		retval = domsgall(endcmd + 1, ac);
#endif
	else if (!strcmp(cmd, "topic") || !strcmp(cmd, "t"))
		retval = dotopic(endcmd + 1, ac);
	else if (!strcmp(cmd, "passwd") || !strcmp(cmd, "ps"))
		retval = dopasswd(endcmd + 1, ac);
	else if (!strcmp(cmd, "nopasswd") || !strcmp(cmd, "nps"))
		retval = donopasswd(endcmd + 1, ac);
	else if (!strcmp(cmd, "nick") || !strcmp(cmd, "n"))
		retval = donick(endcmd + 1, ac);
	else if (!strcmp(cmd, "me"))
	{
		char    actionbuf[80], *firstlet = endcmd + 1;

		while (*firstlet == ' ' || *firstlet == '\n' || *firstlet == '\t')
			firstlet++;
		if (*firstlet != '\0')
		{
			sprintf(actionbuf, "*** %s ***", endcmd + 1);
			net_printf(ac, "SPEAK\t%s\r\n", actionbuf);
			printchatline(actionbuf);
		}
		else
			printchatline("*** ���~: �᭱�n�[�@�y��");
	}
	else if (!strcmp(cmd, "pager") || !strcmp(cmd, "p"))
	{
		uinfo.pager = (uinfo.pager) ? NA : YEA;
		update_utmp();
		printchatline(" ");
		if (!uinfo.pager)
			printchatline("*** Pager turned off");
		else
			printchatline("*** Pager turned on");
	}
	else if (!strcmp(cmd, "clear") || !strcmp(cmd, "c"))
	{
		clear();
		move(ECHATWIN, 0);
		prints("--------------------------------------------------------------------------------");
		chatline = 0;	/* reset */
		printchatline("�� /help �i�ݻ����e��");
		printchatline("  ");	/* �L�ťզ�, �M�ᴫ�� */
	}
	else if (!strcmp(cmd, "ignore") || !strcmp(cmd, "i"))
		doignore(endcmd + 1, ac);
	else
		printchatline("*** ERROR: unknown special chat command");
	return retval;
}
