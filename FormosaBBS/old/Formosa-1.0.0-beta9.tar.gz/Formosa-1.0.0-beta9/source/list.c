
#include "bbs.h"
#include "tsbbs.h"


/* ��榡��Ѥ��� from MapleBBS */


typedef struct
{
	USER_INFO *ui;
	short friend;
}
pickup;


#define PICKUP_WAYS     5

int friends_number = 0;
int p_lines = 20;
short refscreen = NA;

short pickup_way = 0;

char *fcolor[] =
{"", "[1;36m", "[1;33m", "[1;37m"};

short list_friend = NA;
short friend_mode = NA;

extern struct UTMPFILE *utmpshm;


int
my_send(userid)			/* mail to someone */
     char *userid;
{
	char to[STRLEN], title[STRLEN];
	int result;

	clear();

	strcpy(to, userid);
	title[0] = '\0';

	result = PrepareMail(NULL, to, title, NA);
	move(b_line - 1, 0);
	clrtoeol();
	if (result == -1)
		outs("�H�H����.");
	else
		outs("�H�H����.");

	in_mail = 0;

	pressreturn();
	return 0;
}


int
my_write(upent)
     USER_INFO *upent;
{
	if (PrepareMesgContent() == 0)
		SendMesgToSomeone(upent->userid);
	return 0;
}


int
my_kick(upent)
USER_INFO *upent;
{
	if (!upent || upent->userid[0] == '\0')
		return -1;
	if (upent->pid > 2)
		kill(upent->pid, SIGKILL);
/* lasehu: not write back user data */
	purge_ulist(upent);
	return 0;
}


int
search_num(ch, max)
{
	int clen = 1;
	int x, y;
	extern unsigned char scr_cols;

	msg("���ܲĴX��: ");
	outc(ch);
	genbuf[0] = ch;
	getyx(&y, &x);
	x--;
	while ((ch = igetch()) != '\r')
	{
		if (ch == 'q' || ch == 'e')
			return -1;
		if (ch == '\n')
			break;
		if (ch == '\177' || ch == CTRL('H'))
		{
			if (clen == 0)
			{
				bell();
				continue;
			}
			clen--;
			move(y, x + clen);
			outc(' ');
			move(y, x + clen);
			continue;
		}
		if (!isdigit(ch))
		{
			bell();
			continue;
		}
		if (x + clen >= scr_cols || clen >= 6)
		{
			bell();
			continue;
		}
		genbuf[clen++] = ch;
		outc(ch);
	}
	genbuf[clen] = '\0';
	move(b_line, 0);
	clrtoeol();
	if (genbuf[0] == '\0')
		return -1;
	clen = atoi(genbuf);
	if (clen == 0)
		return 0;
	if (clen > max)
		return max;
	return clen - 1;
}

/* opus : cursor position */

void
cursor_show(row, column)
     int row, column;
{
	move(row, column);
	outs(STR_CURSOR);
	move(row, column + 2);
}


int
cursor_key(row, column)
     int row, column;
{
	int ch;

	cursor_show(row, column);
	ch = egetch();
	move(row, column);
	outs(STR_UNCURS);
	return ch;
}


int
egetch()
{
	int rval;

	while (1)
	{
		rval = getkey();
		if (talkrequest)
		{
			talkreply();
			refscreen = YEA;	/* lasehu */
			return rval;
		}
		if (writerequest)
		{		/* lasehu */
			writereply();
			refscreen = YEA;	/* lasehu */			
			return rval;
		}

		if (rval != CTRL('L'))
			return rval;
		redoscr();
	}
}


void
showtitle(title, mid)
     char *title, *mid;
{
	char buf[40];
	int spc, pad;

	spc = strlen(mid);
	if (title[0] == 0)
		title++;
	else if (check_newmail(curuser.userid))
	{
		mid = "[1;44m (���z���H) [0;1;44m";
		spc = 15;
	}
	spc = 60 - strlen(title) - spc;
	pad = 1 - spc & 1;
	memset(buf, ' ', spc >>= 1);
	buf[spc] = '\0';

	prints("[1;44;33m%s  %s[36m%s%s%s  �I��a: %s [0m\n",
	       title, buf, mid, buf, " " + pad, (uinfo.pager) ? "�}��" : "����");
}


void
str_lower(t, s)
     char *t, *s;
{
	register unsigned char ch;

	do
	{
		ch = *s++;
		*t++ = tolower(ch);
	}
	while (ch);
}


int
strstr_lower(str, tag)
     char *str, *tag;		/* tag : lower-case string */
{
	char buf[STRLEN];

	str_lower(buf, str);
	return (int) strstr(buf, tag);
}


#define	US_PICKUP	1234
#define	US_RESORT	1233
#define	US_ACTION	1232
#define	US_REDRAW	1231


void
t_showhelp()
{
	clear();
	outs(" ��ѿ��ϥλ���\n\
-----------------------------------------------------------------------------\n\
 �򥻥\\����\n\
   [��] [p]     ���W���@��     [CTRL+B] [PgUp]      ½�W�@��\n\
   [��] [n]     ���U���@��     [CTRL+F] [PgDn] [Sp] ½�U�@��\n\
   [��] [e]     ���}��ѿ��   [##]                 ����ĴX��\n\
   [Home]       ����Ĥ@��     [$]  [End]           ���쥽�@��\n\n\
 �S���\\����\n\
   [s]          ���s��ܦC��   [f]                  �C�X�u�W�n��/��������\n\
   [m]          �H�H������     [q]  [Enter][��]     �d�ߺ��͸��\n\
   [/]          ��M           [TAB]                �����ƧǤ覡\n\
   [x]          �\\Ū�ӤH�H��   [a/d]                �W�[/�R���n�ͦW��\n");

   if (curuser.userlevel > PERM_PAGE)
	{
		outs("\n ��ͱM����\n\
   [t]          ��L���o���\n\
   [l]          �^�U�u�W�T��\n\
   [w]          �u�W�e�T��\n\
   [CTRL+P]     �����I��a�}��\n");
	}

	if (HAS_PERM(PERM_SYSOP))
	{
		outs("\n �����M����\n\
   [k]          ���a�J��X�h");
	}
	pressreturn();;
}


int
search_pickup(num, actor, pklist)
     int num;
     int actor;
     pickup pklist[];
{

	getdata(b_line, 0, "�п�J�j�M�r��G", genbuf, 20, DOECHO, NULL);
	move(b_line, 0);
	clrtoeol();

	if (genbuf[0])
	{
		int n = (num + 1) % actor;
		str_lower(genbuf, genbuf);
		while (n != num)
		{
			if (strstr_lower(pklist[n].ui->userid, genbuf))
				return n;
			if (strstr_lower(pklist[n].ui->from, genbuf))
				return n;
			if (++n >= actor)
				n = 0;
		}
	}
	return -1;
}


int
pickup_cmp(i, j)
     pickup *i, *j;
{
	switch (pickup_way)
	{
	case 1:
		{
			register int friend;

			if (friend = j->friend - i->friend)
				return friend;
		}
	case 2:
		return strcasecmp(i->ui->userid, j->ui->userid);
	case 3:
		return (i->ui->mode - j->ui->mode);
	case 4:
		return strcasecmp(i->ui->from, j->ui->from);
	}
}


void
pickup_user()
{
	static int num = 0;

	register USER_INFO *uentp;
	register int state = US_PICKUP, ch;
	register int actor, head, foot;
	register int tmp;	/* lasehu */
	time_t diff, freshtime;
	pickup pklist[USHM_SIZE];

	char buf[20];
	char pagerchar[] = "* O ";
	char *msg_pickup_way[PICKUP_WAYS] =
	{
		"���N�ƦC",
		"�u�W�n��",
		"�^��N�W",
		"�u�W���A",
		"�W���a�I"
	};

	short save_list_friend = list_friend;
	
	if (friend_mode)
		list_friend = YEA;

	while (1)
	{
		if (state == US_PICKUP)
		{
			freshtime = 0;
		}

		if (utmpshm->uptime > freshtime)
		{
			time(&freshtime);
			friends_number = actor = ch = foot = 0;

			while (ch < USHM_SIZE)
			{
				uentp = &(utmpshm->uinfo[ch++]);
				if (uentp->pid > 3 && uentp->userid[0])
				{
					if (!HAS_PERM(PERM_CLOAK) && uentp->invisible)
							continue;	
					tmp = MyFriend(uentp->userid); 
					if (tmp)
						friends_number++;
					else if (!tmp && list_friend)
						continue;
					pklist[actor].friend = tmp;	
					pklist[actor].ui = uentp;						
					actor++;
				}
			}

			state = US_PICKUP;
			if (!actor)
			{
				if (friend_mode)
				{
					move(2, 0);
					clrtobot();
					outs("�A���B���٨S�W��");
					pressreturn();
					list_friend = save_list_friend;
				}
				else if (list_friend)				
				{
					getdata(b_line, 0, "�A���B���٨S�W���A�n�ݬݤ@����Ͷ�(y/n) ? [y]: ", genbuf, 4, ECHONOSP, NULL);
					if ((genbuf[0] | 32) != 'n')
					{
						list_friend = NA;
						continue;
					}
				}
				return;
			}
		}

		if (pickup_way > 0 && state >= US_RESORT)	/* lasehu */
			qsort(pklist, actor, sizeof(pickup), pickup_cmp);

		if (state >= US_ACTION)
		{
			clear();
			showtitle(list_friend ? "�n�ͦC��" : "�𶢲��", BBSNAME);
			prints(" �ƧǤ覡: [%s]  �X��: %s  �u�W�`�H�ơG%-6d[1;32m�u�W�n�͡G%-5d [0m\n"
			       "[7m   �s�� �^��N�W     %-20s%-16s %cP %-13s    [0m\n",
			       msg_pickup_way[pickup_way], curuser.userid,
			       actor, friends_number,
			       "����N��", "�Ӧ�",
			       HAS_PERM(PERM_CLOAK) ? 'C' : ' ',
			       "���A");
		}
		else
		{
			move(3, 0);
			clrtobot();
		}

		if (num < 0)
			num = 0;
		else if (num >= actor)
			num = actor - 1;

		head = (num / p_lines) * p_lines;
		foot = head + p_lines;
		if (foot > actor)
			foot = actor;

		for (ch = head; ch < foot; ch++)
		{
			uentp = pklist[ch].ui;

			if (!uentp->pid)
			{
				state = US_PICKUP;
				break;
			}

			state = pklist[ch].friend;	/* lasehu */
			if (uentp->userid[0])
			{
				prints("  %5d %s%-13s%-20.19s[m%-16.16s %c%c %-17.17s\n",
				       ch + 1,
				       fcolor[state], uentp->userid,
				       uentp->username,
				       uentp->from,
				       (uentp->invisible ? 'C' : ' '),
				       pagerchar[(state & 2) | (uentp->pager)],
				       modestring(uentp, 1));
			}
			else
				prints("     --- �����ͤw���u ---\n");
		}
		if (state == US_PICKUP)
			continue;

		move(b_line, 0);
		prints("[37;44m (��)���� (f)�n�� (t)��� (a/d)��� (q)�d�� (w/l)�e/�^�T�� (m)�H�H (h)����   [0m", curuser.userid);

		state = 0;
		while (!state)
		{
			ch = cursor_key(num + 3 - head, 0);
			if (ch == KEY_RIGHT || ch == '\n' || ch == '\r')
				ch = 'q';
			else if (ch >= 'A' && ch <= 'Z')
				ch |= 32;

			if (refscreen)	/* lasehu */
			{
				state = US_REDRAW;
				refscreen = NA;
				continue;
			}
			switch (ch)
			{
			case KEY_LEFT:
			case 'e':
				if (friend_mode)
					list_friend = save_list_friend;
				return;
			case TAB:
				if (++pickup_way >= PICKUP_WAYS)
					pickup_way = 0;
				state = US_RESORT;
				num = 0;
				break;
			case KEY_DOWN:
			case 'n':
				if (++num < actor)
				{
					if (num >= foot)
						state = US_REDRAW;
					break;
				}

			case '0':
			case KEY_HOME:
				num = 0;
				if (head)
					state = US_REDRAW;
				break;

			case ' ':
			case KEY_PGDN:
			case CTRL('F'):
				if (foot < actor)
				{
					num += p_lines;
					state = US_REDRAW;
				}
				else if (head)
				{
					num = 0;
					state = US_REDRAW;
				}
				break;

			case KEY_UP:
			case 'p':
				if (--num < head)
				{
					if (num < 0)
					{
						num = actor - 1;
						if (actor == foot)
							break;
					}
					state = US_REDRAW;
				}
				break;

			case KEY_PGUP:
			case CTRL('B'):
				if (head)
				{
					num -= p_lines;
					state = US_REDRAW;
					break;
				}

			case KEY_END:
			case '$':
				num = actor - 1;
				if (foot < actor)
					state = US_REDRAW;
				break;
			case CTRL('P'):
				uinfo.pager = (uinfo.pager) ? NA : YEA;
				update_utmp();
				state = US_PICKUP;
				break;
			case '/':
				{
					if ((tmp = search_pickup(num, actor, pklist)) >= 0)
						num = tmp;
					state = US_REDRAW;
				}
				break;

			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
				{
					if ((tmp = search_num(ch, actor - 1)) >= 0)
						num = tmp;
					state = US_REDRAW;
				}
				break;

			case 'k':	/* ���a�J��X�h */
/*          case 'u':        �u�W�ק� user data */
				if (!HAS_PERM(PERM_SYSOP))
					continue;

			case 't':
			case 'w':
				if (curuser.userlevel < 20)
					continue;
			case 'a':
			case 'd':
			case 'f':
			case 'm':
			case 'x':	/* Xshadow : for read mail hot key */

				if (!curuser.userlevel)		/* guest �u�� query ? */
					break;
				if (ch == 'f')
				{
					list_friend = (list_friend) ? NA : YEA;
					state = US_PICKUP;
					break;
				}


			case 'l':
			case 'q':
				uentp = pklist[num].ui;

			case 'h':
				state = US_ACTION;
				break;

			case 's':	/* refresh user state */
				state = US_PICKUP;
			}
		}

		if (state != US_ACTION)
			continue;

		if (ch == 'w')
		{
			cursor_show(num + 3 - head, 0);
			my_write(uentp);
			state = US_REDRAW;
			continue;
		}
		else if (ch == 'l')
		{		
			ReplyLastCall();
			state = US_REDRAW;
			continue;
		}
		else
		{
			move(1, 0);
			clrtobot();
			move(2, 0);

			switch (ch)
			{
			case 'x':
				m_read();
				break;

			case 'a':
				FriendAdd(uentp->userid);
				friends_number = FriendLoadCache();
				state = US_PICKUP;
				break;

			case 'd':
				FriendDelete(uentp->userid);
				friends_number = FriendLoadCache();
				state = US_PICKUP;
				break;


			case 'k':
				if (uentp->pid && kill(uentp->pid, 0) != -1)
				{
					my_kick(uentp);
					state = US_PICKUP;
				}
				break;


			case 'm':
				clear();	/* lasehu */
				prints("���H�H�G%s", uentp->userid);
				my_send(uentp->userid);
				break;

			case 'h':
				t_showhelp();
				break;

			case 'q':
				QueryUser(uentp->userid);
				break;

			case 't':
				if (strcmp(uentp->userid, curuser.userid))
				{
					talk_user(uentp);
					state = US_PICKUP;
				}
			}
		}
	}
}


int
t_list()
{
	pickup_user();

	return M_FULL;
}


int
t_friends()
{
	friend_mode = YEA;
	pickup_user();
	friend_mode = NA;

	return M_FULL;
}




