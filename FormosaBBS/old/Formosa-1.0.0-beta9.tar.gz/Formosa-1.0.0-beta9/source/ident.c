
#include "bbs.h"
#include "tsbbs.h"

#ifdef IDENT



/* �����Ҧr���ˬd */
int
id_num_check(num)
char   *num;
{
	int     x1, x2, d[9], y, l;
	struct pair
	{
		int     x1;
		int     x2;
	};
	struct pair pairs[26] =
	{
		1, 0, 1, 1, 1, 2, 1, 3, 1, 4,
		1, 5, 1, 6, 1, 7, 3, 4, 1, 8,
		1, 9, 2, 0, 2, 1, 2, 2, 3, 5,
		2, 3, 2, 4, 2, 5, 2, 6, 2, 7,
		2, 8, 2, 9, 3, 2, 3, 0, 3, 1,
		3, 3,
	};

	if (strlen(num) != 10)
		return -1;
	*num |= 32;		/* Chang all to small character */
	if (*num < 'a' || *num > 'z')
		return -1;
	x1 = pairs[(*num) - 97].x1;
	x2 = pairs[(*num) - 97].x2;
	for (l = 0; l < 9; l++)
	{
		d[l] = *(num + l + 1) - 48;
		if (d[l] > 9 || d[l] < 0)
			return -1;
	}
	y = 3 * (3 * x2 + 2 * d[2] + d[5]) + 4 * (2 * d[0] + d[4]) + 2 * d[6] + 7 * d[1] + 5 * d[3] + x1 + d[7] + d[8];
	if (y % 10 == 0)
		return 0;	/* correct */
	return -1;
}


send_checkmail(email, buf)
char    email[];
char    buf[];
{
	char   *id, *p, tmp[128];
	int     ms;
	FILE   *fp;

	if ((p = strchr(email, '.')) != NULL)
		if (strchr(p, '@') != NULL)
			return;
	if ((ms = create_mail_socket()) < 0)
	{
		msg("<< �L�k�s�� Mail Server >>");
		igetch();
		return;
	}
	if ((fp = fopen("doc/ID_Check_Doc", "r")) == NULL)
		return;
	outs("\n�t�αH�e�{�Ҩ� ...");
	id = strstr(buf, "M.");
	sprintf(tmp, "MAIL FROM: syscheck@%s\n", MYHOSTNAME);
	net_printf(ms, tmp);
	if (!net_gets(ms, genbuf, sizeof(genbuf)))
		return;
	net_printf(ms, "RCPT TO: %-s\n", email);
	if (!net_gets(ms, genbuf, sizeof(genbuf)))
		return;
	net_printf(ms, "DATA\n");
	if (!net_gets(ms, genbuf, sizeof(genbuf)))
		return;
	sprintf(tmp, "From: syscheck@%s\n", MYHOSTNAME);
	net_printf(ms, tmp);
	net_printf(ms, "To: %-s\n", email);
	net_printf(ms, "Subject: NSYSU_BBS ( %s %s )\n\n", curuser.userid, id);
	while (fgets(genbuf, sizeof(genbuf), fp))
		net_printf(ms, "%s", genbuf);
	fclose(fp);
	net_printf(ms, "\n.\n");
	if (!net_gets(ms, genbuf, sizeof(genbuf)))
		return;
	close_mail_socket(ms);
}


int
check_cname(name)
unsigned char name[];
{
	int     i = strlen(name);

	if (i == 0 || (i % 2) == 1)
		return -1;
	while ((i = i - 2) >= 0)
		if (name[i] < 128)
			return -1;
	return 0;
}


do_post_ident()
{
	char    title[STRLEN], *p, buf[STRLEN], stamp[14];
	FILE   *fp_udata, *fp_ckdoc;
	char    email[80];

	char   *check_item[] =
	{
		"1 �m�W(����)�G",
		"2 �a�̹q�ܡG",
		"3 �Ǯդ��q�q�ܡG",
		"4 �q�T�a�}�G",
		"5 �����Ҧr���G",
		"6 ���y�ӳ��a�G",
		"7 �ͤ�(yy/mm/dd)�G",
		"8 �q�l�l��H�c�G",
		"9 ²�u���СG",
		NULL
	};
	char    fn_ckdoc[] = "doc/Check_Doc0", idcard[30], loop;
	time_t  now;
	int     is_postcard = NA;
	char    identfile[PATHLEN];

	sprintf(identfile, "tmp/ident_%s", curuser.userid);

	clear();
	outs("�бz����Announce�O�h�J�ӬݲM�����������{�Ҫ��|�g�G�i,\
�A�������{��\n������{�Ҹ�Ƶ���O�K; �z�n�������{�Ҷ�[N]?");
	if (igetkey() != 'y')
		return M_FULL;
	if ((fp_udata = fopen(identfile, "w")) == NULL)
	{
		outs("\n�}�ҷs�ɮץ���");
		pressreturn();
		return M_FULL;
	}
	clear();
	outs("�ж�J�U�C���: ");

	for (loop = 0; check_item[loop] != NULL; loop++)
	{
		fn_ckdoc[13]++;
		if ((fp_ckdoc = fopen(fn_ckdoc, "r")) != NULL)
		{
			move(11, 0);
			clrtobot();
			while (fgets(buf, 80, fp_ckdoc) != NULL)
				outs(buf);
			fclose(fp_ckdoc);
		}
		switch (*check_item[loop])
		 {
		 case '1':
			 do
			 {
				 move(2 + loop, 0);
				 clrtoeol();
				 getdata(2 + loop, 0, check_item[loop] + 1, buf, STRLEN - 12, ECHONOSP, NULL);
			 }
			 while (check_cname(buf));
			 strcat(buf, "  (");
			 strcat(buf, curuser.userid);
			 strcat(buf, ")");
			 break;
		 case '2':
		 case '4':
		 case '6':
		 case '7':
		 case '9':
			 do
			 {
				 move(2 + loop, 0);
				 clrtoeol();
				 getdata(2 + loop, 0, check_item[loop] + 1, buf, STRLEN - 12, DOECHO, NULL);
			 }
			 while (buf[0] == '\0');
			 break;
		 case '3':
			 move(2 + loop, 0);
			 clrtoeol();
			 getdata(2 + loop, 0, check_item[loop] + 1, buf, STRLEN - 12, DOECHO, NULL);
			 break;
		 case '5':
			 do
			 {
				 move(2 + loop, 0);
				 clrtoeol();
				 getdata(2 + loop, 0, check_item[loop] + 1, buf, STRLEN - 12, ECHONOSP, NULL);
				 if (buf[0] != '\0' && id_num_check(buf) == -1)
				 {
					 move(3 + loop, 0);
					 outs(" �аݱz�Ҷ񪺬��@�Ӹ��X�� (Y/N) ? : [N]");
					 if (igetkey() == 'y')
						 is_postcard = YEA;
				 }
			 }
			 while (buf[0] == '\0');
			 strcpy(idcard, buf);
			 break;
		 case '8':
			 do
			 {
				 move(2 + loop, 0);
				 clrtoeol();
				 getdata(2 + loop, 0, check_item[loop] + 1, buf, STRLEN - 12, ECHONOSP, NULL);
				 if ((p = strchr(buf, '@')) != NULL)
				 {
					 for (p++; !isalpha(*p) && *p != '\0'; p++)
						/* NULL STATEMENT */ ;
					 if (*p != '\0')
						 break;
				 }
			 }
			 while (1);
			 strcpy(email, buf);
			 if (is_postcard)
			 {
				 outs("[1;36m ��g�@�Ӹ��X, ���H�@�Ӽv��, �Ь� system-report �O��ذϻ���[m");
				 pressreturn();
			 }
			 else if ((p = strchr(buf, '.')) != NULL
				  && strchr(p, '@') != NULL)
			 {
				 outs("[1;36m ��g xxx.bbs@[hostname], ���H�����Ҽv��, �Ь� system-report �O��ذϻ���[m");
				 pressreturn();
			 }
			 break;
		 }
		fprintf(fp_udata, "%s%s\n\n", check_item[loop] + 1, buf);
	}
	now = time(0);
	fprintf(fp_udata, "�ӽФ���G%s\n", ctime(&now));
	fclose(fp_udata);
	outs("�H�W��Ƴ����T�� [N] ?");
	if (igetkey() != 'y')
	{
		unlink(identfile);
		return M_FULL;
	}
	if (id_num_check(idcard) == -1 && !is_postcard)
	{
		unlink(identfile);	
		pressreturn();
		return M_FULL;
	}
	setboardfile(buf, "ID", "\0");
	sprintf(title, "�����T�{: %s", curuser.userid);
	if (append_article(identfile, buf, curuser.userid, title, 0, stamp, YEA) == -1)
	{
		unlink(identfile);	
		outs("\n�n������\n");
		pressreturn();
		return M_FULL;
	}
	if (!is_postcard)
	{
		setboardfile(buf, "ID", stamp);
		send_checkmail(email, buf);
	}
	unlink(identfile);
	pressreturn();
	return M_FULL;
}




/*******************************************************************
 *  ��g�����{�ҥӽЮ�
 *******************************************************************/
CheckID()
{
#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return M_FULL;
#endif

	return do_post_ident();
}

#endif
