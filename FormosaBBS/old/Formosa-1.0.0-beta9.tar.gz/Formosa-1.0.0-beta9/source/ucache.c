
/* FormosaBBS 1.0.0 */

/*******************************************************************
 * �u�W�ϥΪ̧Y�ɸ��:
 *	�ϥ� Shared Memory 
 *******************************************************************/

#include "bbs.h"
#include "tsbbs.h"


extern struct UTMPFILE *utmpshm;	/* �����ϥΪ� USER_INFO ���� */


void
update_utmp()
{
	update_ulist(&uinfo);
}


void
update_umode(mode)
int     mode;
{
	uinfo.mode = mode;
	update_utmp();
}


/*******************************************************************
 * �ˬd���� login
 *******************************************************************/
#ifdef MAX_GUEST_LOGINS
short   count_guest_logins = NA;
#endif

count_multi_login(upent)
USER_INFO *upent;
{
	static short i = 0;

	if (upent->pid <= 2 || uinfo.pid <= 2)	/* debug */
		return -1;
		
	if (!strcmp(upent->userid, uinfo.userid))	/* -ToDo- should compare uid */
	{
		i++;
		if (upent->pid != uinfo.pid)
		{
			multi++;
#ifdef MAX_GUEST_LOGINS
			if (count_guest_logins)
			{
				if (multi > MAX_GUEST_LOGINS)
				{
					fprintf(stdout, "\n�������[�ί���(guest)�ϥΤH�Ƥw�B��, �бz�y��A��.\n");
					fflush(stdout);
					sleep(1);
					exit(0);
				}
				return 0;
			}
#endif
			prints("\n%d. Login PID:[%d] �Ӧ� %s �O�_�R�� (y/n) ? [n] : ", i, upent->pid, upent->from);
			if (igetkey() == 'y')
			{
				if (upent->pid > 2)	/* lasehu */
				{
					kill(upent->pid, SIGKILL);
					purge_ulist(upent);
				}
				multi--;
			}
			if (multi > MULTILOGINS)
			{
				if (!HAS_PERM(PERM_SYSOP))
				{
					fprintf(stdout, "\n���୫�� Login %d �� !!", multi);
					fflush(stdout);
					sleep(1);
					exit(0);
				}
			}
		}
	}
	return 0;
}


void
multi_user_check()
{
#ifdef GUEST_ACCOUNT

	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
	{
#ifdef MAX_GUEST_LOGINS
		count_guest_logins = YEA;
#else
		return;
	       /* UNREACHED */
#endif
	}
#endif /* GUEST_ACCOUNT */

	apply_ulist(count_multi_login);
}
