/*******************************************************************
 * ���{���ҩ� functions �j�����O ������ذϪ�
 *                                          lmj@cc.nsysu.edu.tw
 *******************************************************************/

#include "bbs.h"
#include "csbbs.h"



/*******************************************************************
  ��ذϤ��ؤl�ؿ�
  Syntax: MAKEDIR boardname name [PATH level1 level2 ...]

  Respond:
 *******************************************************************/
DoMakeDirect()
{
	char   *trea_name;
	int     t_num, fd, ftemp, num;
	char   *p, temp_name[STRLEN], full_name[STRLEN];
	char    buf[FH_SIZE];
	int     i;
	struct fileheader new_dir;

	if (!SelectBoard(Get_para_string(1), 1))
		return;

	bzero(&new_dir, sizeof(new_dir));
	if (!in_board && strcmp(CurBList->owner, curuser.userid) &&
	    curuser.userlevel < 255)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

 /* get treasure count */
	t_num = get_trea_number();
	num = get_num_records(boarddirect, FH_SIZE);	/* get post count */

	trea_name = Get_para_string(2);
	if (*trea_name == '\0')
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	if ((fd = open(boarddirect, O_RDWR)) < 0)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}
	strcpy(temp_name, boarddirect);
	strcat(temp_name, ".tmp");
	if ((ftemp = open(temp_name, O_WRONLY | O_CREAT, 0644)) < 0)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}
	for (i = 0; i < t_num; i++)
	{
		read(fd, buf, FH_SIZE);
		write(ftemp, buf, FH_SIZE);
	}

	strcpy(new_dir.filename, boarddirect);
	p = strrchr(new_dir.filename, '/');
	*p = '\0';
	get_only_name2(new_dir.filename);
	strcpy(full_name, new_dir.filename);
	p = strrchr(new_dir.filename, '/');
	p++;
	strcpy(new_dir.filename, p);

	new_dir.accessed = FILE_TREA;
	strcpy(new_dir.title, trea_name);
	write(ftemp, &new_dir, FH_SIZE);
	for (i = t_num; i < num; i++)
	{
		read(fd, buf, FH_SIZE);
		write(ftemp, buf, FH_SIZE);
	}
	close(fd);
	close(ftemp);

	unlink(full_name);
	if (mkdir(full_name, 0700) == 0)
	{
		rename(temp_name, boarddirect);
		RespondProtocol(OK_CMD);
		return;
	}
	printf("%s \r\n", full_name);
	RespondProtocol(WORK_ERROR);
	return;

}
