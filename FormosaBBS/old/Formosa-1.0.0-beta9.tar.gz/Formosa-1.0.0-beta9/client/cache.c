
#include "bbs.h"
#include "csbbs.h"


void
update_utmp()
{
	update_ulist(&uinfo);
}


void
update_umode(mode)
int     mode;
{
	uinfo.mode = mode;
	update_utmp();		/* lasehu */
}


/*******************************************************************
 *
 * �ˬd���� login
 * ��Ҧ���login�q�X��	
 *******************************************************************/
int
count_multi_login(upent)
struct user_info *upent;
{

    if (upent->pid <= 2 || uinfo.pid <= 2)  /* debug */
        return -1;

    if (!strcmp(upent->userid, uinfo.userid))   /* -ToDo- should compare uid */
    {
        if (upent->pid != uinfo.pid)
        {
            multi++;
			inet_printf("%d\t%s\r\n", upent->pid, upent->from);
        }
    }
    return 0;
}


void
multi_user_check()
{
	multi = 0;
	RespondProtocol(OK_CMD);
	if (apply_ulist(count_multi_login) == -1)
	{
		inet_printf(".\r\n");
		return;
	}
	inet_printf(".\r\n");
}
