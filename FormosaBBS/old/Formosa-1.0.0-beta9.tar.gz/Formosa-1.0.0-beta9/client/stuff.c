
#include "bbs.h"

#include "csbbs.h"
#include <sys/param.h>
#include <pwd.h>


/* rrr - Snagged from pbbs 1.8 */

#define LOOKFIRST  (0)
#define LOOKLAST   (1)
#define QUOTEMODE  (2)
#define MAXCOMSZ (1024)
#define MAXARGS (40)
#define MAXENVS (20)
#define BINDIR "/bin/"

char   *bbsenv[MAXENVS];
int     numbbsenvs = 0;

/* Case Independent strncmp */

int
ci_strncmp(s1, s2, n)
register char *s1, *s2;
register int n;
{
	for (; n; s1++, s2++, n--)
	{
		if (*s1 == '\0' && *s2 == '\0')
			break;
		if ((isalpha(*s1) ? *s1 | 0x20 : *s1) != (isalpha(*s2) ? *s2 | 0x20 : *s2))
			return YEA;
	}
	return NA;
}

bbssetenv(env, val)
char   *env, *val;
{
	register int i, len;

 /* extern char *malloc() ; */

	if (numbbsenvs == 0)
		bbsenv[0] = NULL;
	len = strlen(env);
	for (i = 0; bbsenv[i]; i++)
		if (!ci_strncmp(env, bbsenv[i], len))
			break;
	if (i >= MAXENVS)
		return -1;
	if (bbsenv[i])
		free(bbsenv[i]);
	else
		bbsenv[++numbbsenvs] = NULL;
	bbsenv[i] = malloc(strlen(env) + strlen(val) + 2);
	strcpy(bbsenv[i], env);
	strcat(bbsenv[i], "=");
	strcat(bbsenv[i], val);
}

do_exec(com, wd)
char   *com, *wd;
{
	char    path[MAXPATHLEN];
	char    pcom[MAXCOMSZ];
	char   *arglist[MAXARGS];
	register int i, len;
	register int argptr;
	int     pid;
	int     pmode;
	struct passwd *passid;

	passid = getpwuid(uinfo.sysuid);
	strncpy(path, BINDIR, MAXPATHLEN);
	strncpy(pcom, com, MAXCOMSZ);
	len = MIN(strlen(com) + 1, MAXCOMSZ);
	pmode = LOOKFIRST;
	for (i = 0, argptr = 0; i < len; i++)
	{
		if (pcom[i] == '\0')
			break;
		if (pmode == QUOTEMODE)
		{
			if (pcom[i] == '\001')
			{
				pmode = LOOKFIRST;
				pcom[i] = '\0';
				continue;
			}
			continue;
		}
		if (pcom[i] == '\001')
		{
			pmode = QUOTEMODE;
			arglist[argptr++] = &pcom[i + 1];
			if (argptr + 1 == MAXARGS)
				break;
			continue;
		}
		if (pmode == LOOKFIRST)
			if (pcom[i] != ' ')
			{
				arglist[argptr++] = &pcom[i];
				if (argptr + 1 == MAXARGS)
					break;
				pmode = LOOKLAST;
			}
			else
				continue;
		if (pcom[i] == ' ')
		{
			pmode = LOOKFIRST;
			pcom[i] = '\0';
		}
	}
	arglist[argptr] = NULL;
	if (argptr == 0)
		return -1;
	if (*arglist[0] == '/')
		strncpy(path, arglist[0], MAXPATHLEN);
	else
		strncat(path, arglist[0], MAXPATHLEN);
	if ((pid = vfork()) == 0)
	{
		seteuid(uinfo.sysuid);
		setuid(uinfo.sysuid);
		if (wd)
			if (chdir(wd))
			{
				fprintf(stderr, "Unable to chdir to '%s'\n", wd);
				exit(-1);
			}
		bbssetenv("PATH", "/bin:/usr/lib:/etc:/usr/ucb:/usr/local/bin:/usr/local/lib:.");
		bbssetenv("TERM", curuser.termtype);
		bbssetenv("USER", passid->pw_name);
		bbssetenv("USERNAME", curuser.username);
		bbssetenv("HOME", passid->pw_dir);
		if (numbbsenvs == 0)
			bbsenv[0] = NULL;
	/*
	   seteuid(BBSBIN_UID); setuid(BBSBIN_UID);
	*/
		execve(path, arglist, bbsenv);
		exit(-1);
	}
	sleep(5);
	return 0;
}

int
seek_in_file(filename, seekstr)
char    filename[STRLEN], seekstr[STRLEN];
{
	FILE   *fp;
	char    buf[STRLEN];
	char   *ptr;

	if ((fp = fopen(filename, "r")) == NULL)
		return 0;
	while (fgets(buf, STRLEN, fp) != NULL)
	{
		if ((ptr = (char *) strchr(buf, '#')) != NULL)
			if (ptr != NULL)
				*ptr = '\0';
		if (buf[0] == '\0')
			continue;
		if ((ptr = (char *) strtok(buf, ": \n\r\t")) && !strcmp(ptr, seekstr))
		{
			fclose(fp);
			return 1;
		}
	}
	fclose(fp);
	return 0;
}
