
#include "bbs.h"
#include "csbbs.h"

char    SeverHello[] = "Welcome!! Formosa Client/Server BBS version 3.0 06/19";

SayHello()
{
	inet_printf("%d\t%s %s \r\n", OK_CMD, BBSNAME, SeverHello);
}

/**************************************************
*		HELLO
*			�s�u��P�t�Υ��۩I
***************************************************/
DoHello()
{
	FILE   *fp;
	char    limit[81];

	if (!ifSayHello)
	{
		if ((fp = fopen(HOSTLIMIT, "r")) != NULL)	/* check if host is
								   welcome */
		{
			while (!feof(fp))
			{
				fgets(limit, 80, fp);
				if (limit[strlen(limit) - 1] == '\n')
					limit[strlen(limit) - 1] = 0;
				if (!strncmp(from, limit, strlen(limit)))
				{
					RespondProtocol(NOT_WELCOME);	/* not welcome!! */
					fclose(fp);
					FormosaExit();	/* banned!! */
				}
			}
			fclose(fp);
		}
		ifSayHello = YEA;
	}
	RespondProtocol(OK_CMD);
}
