
#include "bbs.h"
#include "csbbs.h"


char *ModeType();


#define REFUSE 5

#define MAX_FRIEND_CACHE 50

char   *Friend_Cache[MAX_FRIEND_CACHE], *check_userid;
int     friend_cache_count = 0;
int     user_online_flag = FALSE;
int     (*override) (char *, unsigned int, char *);
struct user_info *check_user_info;


can_override(userid, uid, whoasks)
char   *userid;
unsigned int uid;
char   *whoasks;
{
	FILE   *fp;

	if (!userid || !(*userid))
		return 0;
	sethomefile(genbuf, userid, UFNAME_OVERRIDES);
	if ((fp = fopen(genbuf, "r")) == NULL)
		return 0;
	while (fscanf(fp, "%s\n", genbuf) == 1)
	{
		if (!strcmp(genbuf, whoasks))
		{
			fclose(fp);
			return 1;
		}
	}
	fclose(fp);
	return 0;
}

can_override2(userid, uid, whoasks)
char   *userid;
unsigned int uid;
char   *whoasks;
{
	int     i;

	for (i = 0; i < friend_cache_count; i++)
	{
		if (!strcmp(Friend_Cache[i], whoasks))
			return 1;
	}
	return 0;
}

char
pagerchar(me, them, pager)
char   *me, *them;
int     pager;
{
	if (can_override(them, -1, me))
		return 'O';
	else if (pager)
		return 'N';	/* �ץ��L!! gcl */
	else
		return 'P';
}

char   *
modestring(mode, towho, complete, chatid)
int     mode, complete;
unsigned int towho;
char   *chatid;
{
	static char modestr[STRLEN];
	struct useridx uidx;

	if (chatid)
	{
		if (complete)
			sprintf(modestr, "%s as '%s'", ModeType(mode), chatid);
		else
			return (ModeType(mode));
		return (modestr);
	}
	if (mode != TALK && mode != PAGE && mode != QUERY)
		return (ModeType(mode));
	if (get_record(USERIDX, &uidx, sizeof(uidx), towho) == -1)
		return (ModeType(mode));
	if (mode != QUERY && curuser.userlevel < PERM_CLOAK &&
	    ishidden(uidx.userid))
		return (ModeType(TMENU));
	if (complete)
		sprintf(modestr, "%s '%s'", ModeType(mode), uidx.userid);
	else
		return (ModeType(mode));
	return (modestr);
}


cmp_userid(userid, uentp)	/* lasehu */
register char *userid;
register struct user_info *uentp;
{
	return (!strcmp(userid, uentp->userid));
}

extern struct user_info *search_ulist();

ishidden(userid)		/* lasehu */
char   *userid;
{
	struct user_info *up;

	if (userid == NULL || userid[0] == '\0')
		return 0;
	if ((up = search_ulist(cmp_userid, userid)))
		return up->invisible;
	return 0;
}



/***********************************************************
*		QUERY userid
*			�d�ߥu�Ϊ̸��
************************************************************/
DoQuery()
{
	char   *query_userid, lasttime[50], lastfrom[50];
	struct userec lookupuser;
	char   *newline, checkmail;
	char    UserName[30];
	char    EMail[40];
	struct stat st;

	query_userid = Get_para_string(1);
	if (query_userid == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}
	if (!get_passwd(&lookupuser, query_userid))
	{			/* no such user id */
		RespondProtocol(USERID_NOT_EXIST);
		return;
	}

	strcpy(lasttime, ctime(&(lookupuser.lastlogin)));
	if (newline = index(lasttime, '\n'))
		*newline = '\0';
	if ((*lookupuser.lasthost == '\0') || (*lookupuser.lasthost == ' '))
		strcpy(lastfrom, "(unknown)");
	else
		strcpy(lastfrom, lookupuser.lasthost);

	if (chk_others_mail(lookupuser.userid))
		checkmail = '1';
	else
		checkmail = '0';

	strcpy(UserName, lookupuser.username);
	if ((UserName[0] == '\0') || (UserName[0] == ' '))
		strcpy(UserName, "#");
	strcpy(EMail, lookupuser.email);
	if ((EMail[0] == '\0') || (EMail[0] == ' '))
		strcpy(EMail, "#");

	inet_printf("800\t%s\t%s\t%d\t%d\t%d", lookupuser.userid, UserName,
	      lookupuser.userlevel, lookupuser.ident, lookupuser.numlogins);
	inet_printf("\t%d\t%s\t%s\t%s\t%c\n", lookupuser.numposts, lasttime,
		    lastfrom, EMail, checkmail);

	sethomefile(genbuf, query_userid, UFNAME_PLANS);
	if (stat(genbuf, &st) < 0)
		inet_printf("�S���W����.\r\n\r\n.\r\n");
	else
	{
		SendArticle(genbuf, NA);
	}
}

printcuent(uentp)
struct user_info *uentp;
{
	struct userec utmp;

	if (uentp->pid < 2)
		return;
	if (kill(uentp->pid, 0) == -1 || uentp->userid[0] == '\0')
		return;
	if (curuser.userlevel < PERM_CLOAK && uentp->invisible)
		return;

	if (get_passwd(&utmp, uentp->userid) > 0)
	{
		inet_printf("%s\t%s\t%c\t%s\t%s\r\n", uentp->userid, uentp->from,
		 pagerchar(curuser.userid, uentp->userid, uentp->pager),
			    modestring(uentp->mode, uentp->destuid, 1,
				   (uentp->in_chat ? uentp->chatid : NULL)),
			    utmp.username);

	}
}

/*****************************************************
 *  Syntax: LISTUSER
 *
 *  Respond:  userid  from  page  'mode'  username
 *                           |
 *                           +--> N... page off
 *                                O... old friend
 *                                P... page on
 *****************************************************/
DoListOnlineUser()
{

	RespondProtocol(OK_CMD);
	apply_ulist(printcuent);
	inet_printf(".\r\n");
}

/*****************************************************
*		PAGE
*			�}���I�s�a
******************************************************/
DoPage()
{
	curuser.flags[0] |= 1;
	curuser.flags[0] ^= 1;	/* Clean page flag */
	if (uinfo.pager == YEA)
	{
		uinfo.pager = NA;
		curuser.flags[0] |= 1;	/* can not talk */
	}
	else
		uinfo.pager = YEA;
	update_utmp(&uinfo, uinfo.active);
	RespondProtocol(OK_CMD);
}

check_user(uentp)
struct user_info *uentp;
{
	if (strcmp(uentp->userid, check_userid) == 0)
	{
		user_online_flag = TRUE;
		check_user_info = uentp;
		return QUIT_LOOP;
	}
}

user_online()
{
	user_online_flag = FALSE;
	apply_ulist(check_user);
	return user_online_flag;
}

/*****************************************************
 *  ALLMESG
 *  ���o�Ҧ����u�W�T��
 *****************************************************/
DoAllMsg()
{
	FILE   *fp;
    char    buf[PATHLEN];
	char 	buffer[100];
	char 	*p;
	
	sprintf(buf, "write/%s", curuser.userid);
	RespondProtocol(OK_CMD);
	if (fp = fopen(buf, "r"))
    {
        for (;;)
        {
            if (fgets(buffer, sizeof(buffer), fp) == NULL)
                break;
			if ((p = strchr(buffer, '\n')) != NULL)
				*p = '\0';
			inet_printf("%s\r\n", buffer);
        }
        fclose(fp);
    }
	inet_printf(".\r\n");
}

/*****************************************************
 *	SENDMESG userid message
 *	�e�T������L�H
 *****************************************************/

DoSendMsg()
{
	char   *message;
	char    buf[PATHLEN];
	struct userec lookupuser;
	FILE   *fp;
	time_t  clock;
	char   *date;

	check_userid = Get_para_string(1);
	if (check_userid == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}
	if (!get_passwd(&lookupuser, check_userid))
	{			/* no such user id */
		RespondProtocol(USERID_NOT_EXIST);
		return;
	}
	message = Get_para_string(2);
	if (message == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}
	if (!user_online())
	{
		RespondProtocol(USER_NOT_ONLINE);
		return;
	}
	if (curuser.userlevel < 255)	/* lasehu */
	{
		if (check_user_info->pager == NA &&
		    !can_override(check_userid, NULL, curuser.userid))
		{
			RespondProtocol(NOT_ALLOW_PAGE);	/* ��西�B�󤣭㥴�Z�����A
								    */
			return;
		}
	}

	sprintf(buf, "write/%s", check_userid);
	if ((fp = fopen(buf, "a+")) == NULL)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}
	clock = time(NULL);
	date = ctime(&clock);
	date[16] = '\0';
	sprintf(buf, "\r\n%s\t%-1s\t%s\t%s", curuser.userid, curuser.username,
		message, &date[11]);
	fputs(buf, fp);
	fclose(fp);

	if (check_user_info->pid > 2)	/* lasehu */
		kill(check_user_info->pid, SIGUSR2);
	else
	{
		RespondProtocol(WORK_ERROR);
		return;
	}	
	RespondProtocol(OK_CMD);
}

/*****************************************************
 *  Syntax: TALKTO userid
 *
 *  Respond:  1st Rep. OK_CMD  ( starting paging )
 *            2rd Rep. OK_CMD  ( accept talk request )
 *
 *            during 1..2 can send TALKSTOP
 *****************************************************/

DoTalk()
{
	char   *uident;
	unsigned int tuid;
	int     sock, msgsock, length;
	struct sockaddr_in server;
	struct userec lookupuser;
	char    c;
	char    buf[256];
	fd_set  readmask;
	struct timeval timeout;
	int     i, keyno;

	check_userid = Get_para_string(1);
	if (uident == NULL)	/* lasehu ? */
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	if (!get_passwd(&lookupuser, check_userid))
	{			/* no such user id */
		RespondProtocol(USERID_NOT_EXIST);
		return;
	}

	if (!user_online())
	{
		RespondProtocol(USER_NOT_ONLINE);
		return;
	}
	tuid = check_user_info->uid;

	if (curuser.userlevel < 255)
	{
		if (check_user_info->pager == NA &&
		    !can_override(check_userid, NULL, curuser.userid))
		{
			RespondProtocol(NOT_ALLOW_PAGE);	/* ��西�B�󤣭㥴�Z�����A
								    */
			return;
		}
	}

	if (check_user_info->mode == IRCCHAT ||
	    check_user_info->mode == LOCALIRC)

	{
		RespondProtocol(NOT_ALLOW_TALK);	/* ��西�B�󤣯౵���͸ܪ����A
							    */
		return;
	}

	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock < 0)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_port = 0;
	if (bind(sock, (struct sockaddr *) & server, sizeof server) < 0)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}
	length = sizeof server;
	if (getsockname(sock, (struct sockaddr *) & server, &length) < 0)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}
	uinfo.sockactive = YEA;
	uinfo.sockaddr = server.sin_port;
	uinfo.destuid = tuid;
	strncpy(uinfo.destid, check_userid, IDLEN + 2);

	update_umode(PAGE);
	update_utmp(&uinfo, uinfo.active);

	if (check_user_info->pid > 2)	/* lasehu */
		kill(check_user_info->pid, SIGUSR1);
	else
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	RespondProtocol(OK_CMD);/* Step1: Paging */

	timeout.tv_sec = 20;
	timeout.tv_usec = 0;
	listen(sock, 1);
	while (YEA)
	{
		FD_ZERO(&readmask);
		FD_SET(sock, &readmask);
		FD_SET(0, &readmask);
		if (select(sock + 1, &readmask, NULL, NULL, &timeout) < 0)
		{
			close(sock);
			RespondProtocol(WORK_ERROR);
			break;
		}

		if (FD_ISSET(sock, &readmask))
		{		/* other send respond */
			msgsock = accept(sock, (struct sockaddr *) 0, (int *) 0);
			close(sock);
			uinfo.sockactive = NA;
			if (msgsock == -1)
			{
				RespondProtocol(WORK_ERROR);
				break;
			}
			read(msgsock, &c, sizeof(c));
			if (c == 'y')
			{
			/* RespondProtocol(OK_CMD); */
				Talking(msgsock);
				close(msgsock);
				break;
			}
			else
			{
				i = 0;
				while (i < sizeof(buf) - 1)
				{
					read(msgsock, &c, sizeof(c));
					if (c != '\0')
						buf[i++] = c;
					else
						break;
				}
				buf[i] = '\0';
				close(msgsock);
				StrDelR(buf);
				inet_printf("%d\t%s\r\n", NOT_ALLOW_REQ, buf);	/* ��������ܭn�D */
				break;
			}
		}

		if (FD_ISSET(0, &readmask))
		{
			if ((i = inet_gets(buf, sizeof(buf))) < 0)
			{
				FormosaExit();
			}
			if (i > 0)
			{
				keyno = GetKeywordNo(&buf);
				if (keyno == TALKSTOP)
				{	/* stop pageing */
					close(sock);
					RespondProtocol(OK_CMD);
					break;
				}
				else if (keyno == QUIT_LOOP)
				{
					close(sock);
					FormosaExit();
					break;
				}
			}
			else
				RespondProtocol(SYNTAX_ERROR);
		}
		if (check_user_info->pid > 2)	/* lasehu */
		{
			if (kill(check_user_info->pid, SIGUSR1) == -1)
			{
				close(sock);
				RespondProtocol(USER_NOT_ONLINE);
				break;
			}
		}
		else
		{
			RespondProtocol(USER_NOT_ONLINE);
			break;
		}
	}

	uinfo.sockactive = NA;
	uinfo.destuid = 0;
	update_umode(CLIENT);
	update_utmp(&uinfo, uinfo.active);
}

Talking(fd)
int     fd;
{
	char    buf[256];
	char    tmp[256];
	char    c;
	int     i, j, datac;
	int     sock, tsock, length;
	struct sockaddr_in tserver;
	char    keyword[MAX_KEYWORD_LEN + 1];
	int     keyno;
	fd_set  readmask;
	struct timeval timeout;

	update_umode(TALK);
	update_utmp(&uinfo, uinfo.active);

 /* Add Multi-Process Talking */

	switch (fork())
	{
		case 0:

			sock = socket(AF_INET, SOCK_STREAM, 0);
			tserver.sin_family = AF_INET;
			tserver.sin_addr.s_addr = INADDR_ANY;
			tserver.sin_port = 0;

			if (bind(sock, (struct sockaddr *) & tserver, sizeof tserver) < 0)
			{
				RespondProtocol(WORK_ERROR);
				return;
			}

			length = sizeof tserver;
			if (getsockname(sock, (struct sockaddr *) & tserver, &length) < 0)
			{
				RespondProtocol(WORK_ERROR);
				close(1);
				close(0);
				close(fd);
				exit(0);
			}

			inet_printf("%d\t%d\r\n", TALK_PORT, ntohs((u_short)tserver.sin_port));

			timeout.tv_sec = 20;
			timeout.tv_usec = 0;
			listen(sock, 1);

			tsock = accept(sock, (struct sockaddr *) 0, (int *) 0);
			close(sock);
			close(0);
			close(1);
			close(2);

			if (tsock == -1)
			{
				close(0);
				close(1);
				close(fd);
				exit(0);
			}


		/* Start Talking and Transfer datas */

			while (YEA)
			{
				FD_ZERO(&readmask);
				FD_SET(fd, &readmask);
				FD_SET(tsock, &readmask);
				if (select(tsock + 1, &readmask, NULL, NULL, &timeout) < 0)
				{
					if (talkrequest)
						talkreply();
					else
					{
						close(0);
						close(1);
						close(fd);
						close(tsock);
						exit(0);
					}
				}
				if (FD_ISSET(tsock, &readmask))
				{
					if ((i = sock_gets(buf, sizeof(buf), tsock)) < 0)
					{	/* Oh.. I leave... */
						close(fd);
						FormosaExit();
					}
					if (i > 0)
					{
						NextToken = GetToken(buf, keyword, MAX_KEYWORD_LEN);
						if (keyword[0] == '\0')
							continue;
						keyno = GetKeywordNo(keyword);
						switch (keyno)
						{
							case ISAY:
							/*
							   GetString(NextToken
							   ,tmp,sizeof(tmp));
							*/
								GetToken(NextToken, tmp, sizeof(tmp));
								if (tmp[0] != '\0')
									write(fd, tmp, strlen(tmp));
								break;
							case IKEY:
								GetToken(NextToken, tmp, sizeof(tmp));
								if (!strcasecmp(tmp, "BACK"))
								{
									c = '\177';
									write(fd, &c, 1);
								}
								else if (!strcasecmp(tmp, "ENTER"))
								{
									c = '\n';
									write(fd, &c, 1);
								}
								else if (!strcmp(tmp, "SPACE"))
								{
									c = ' ';
									write(fd, &c, 1);
								}
								else if (!strcmp(tmp, "face0"))
								{
									c = 0x18;
									write(fd, &c, 1);
								}
								else if (!strcmp(tmp, "face1"))
								{
									c = 0x19;
									write(fd, &c, 1);
								}
								else if (!strcmp(tmp, "face2"))
								{
									c = 0x1a;
									write(fd, &c, 1);
								}
								else if (!strcmp(tmp, "face3"))
								{
									c = 0x1b;
									write(fd, &c, 1);
								}
								else if (!strcmp(tmp, "face4"))
								{
									c = 0x1c;
									write(fd, &c, 1);
								}
								else if (!strcmp(tmp, "face5"))
								{
									c = 0x1d;
									write(fd, &c, 1);
								}
								else if (!strcmp(tmp, "face6"))
								{
									c = 0x1e;
									write(fd, &c, 1);
								}
								break;

							/*
							   case _PAGE:
							   t_pager(); if
							   (!uinfo.pager)
							   net_printf(tsock,"%
							   d
							   OFF\r\n",PAGER_CHAN
							   GE); else
							   net_printf(tsock,"%
							   d
							   ON\r\n",PAGER_CHANG
							   E); break;
							*/


							case TALKSTOP:
							case _QUIT:
								close(0);
								close(1);
								close(fd);
								close(tsock);
								exit(0);
						}
					}
				}
				if (FD_ISSET(fd, &readmask))
				{
					if ((datac = read(fd, buf, sizeof(buf))) < 0)
					{

						close(0);
						close(1);
						close(fd);
						close(tsock);
						exit(0);
					}
					j = 0;
					for (i = 0; i < datac; i++)
					{
						c = buf[i];
						switch (c)
						{
							case CTRL('H'):
							case '\177':
								if (j > 0)
								{
									tmp[j] = '\0';
									net_printf(tsock, "%d\t%s\r\n", SHE_SAY, tmp);
									j = 0;
								}
								net_printf(tsock, "%d\tBACK\r\n", SHE_KEY);
								break;
							case CTRL('M'):
							case CTRL('J'):
								if (j > 0)
								{
									tmp[j] = '\0';
									net_printf(tsock, "%d\t%s\r\n", SHE_SAY, tmp);
									j = 0;
								}
								net_printf(tsock, "%d\tENTER\r\n", SHE_KEY);
								break;
							case CTRL('G'):
								break;
							case SP:
								if (j > 0)
								{
									tmp[j] = '\0';
									net_printf(tsock, "%d\t%s\r\n", SHE_SAY, tmp);
									j = 0;
								}
								net_printf(tsock, "%d\tSPACE\r\n", SHE_KEY);
								break;
							case FACE0:
								if (j > 0)
								{
									tmp[j] = '\0';
									net_printf(tsock, "%d\t%s\r\n", SHE_SAY, tmp);
									j = 0;
								}
								net_printf(tsock, "%d\tFACE0\r\n", SHE_KEY);
								break;
							case FACE1:
								if (j > 0)
								{
									tmp[j] = '\0';
									net_printf(tsock, "%d\t%s\r\n", SHE_SAY, tmp);
									j = 0;
								}
								net_printf(tsock, "%d\tFACE1\r\n", SHE_KEY);
								break;
							case FACE2:
								if (j > 0)
								{
									tmp[j] = '\0';
									net_printf(tsock, "%d\t%s\r\n", SHE_SAY, tmp);
									j = 0;
								}
								net_printf(tsock, "%d\tFACE2\r\n", SHE_KEY);
								break;
							case FACE3:
								if (j > 0)
								{
									tmp[j] = '\0';
									net_printf(tsock, "%d\t%s\r\n", SHE_SAY, tmp);
									j = 0;
								}
								net_printf(tsock, "%d\tFACE3\r\n", SHE_KEY);
								break;
							case FACE4:
								if (j > 0)
								{
									tmp[j] = '\0';
									net_printf(tsock, "%d\t%s\r\n", SHE_SAY, tmp);
									j = 0;
								}
								net_printf(tsock, "%d\tFACE4\r\n", SHE_KEY);
								break;
							case FACE5:
								if (j > 0)
								{
									tmp[j] = '\0';
									net_printf(tsock, "%d\t%s\r\n", SHE_SAY, tmp);
									j = 0;
								}
								net_printf(tsock, "%d\tFACE5\r\n", SHE_KEY);
								break;
							case FACE6:
								if (j > 0)
								{
									tmp[j] = '\0';
									net_printf(tsock, "%d\t%s\r\n", SHE_SAY, tmp);
									j = 0;
								}
								net_printf(tsock, "%d\tFACE6\r\n", SHE_KEY);
								break;
							default:
							/* if(Isprint3(c)) { */
								tmp[j++] = c;
							/* } */
						}
					}
					if (j > 0)
					{
						tmp[j] = '\0';
						net_printf(tsock, "%d\t%s\r\n", SHE_SAY, tmp);
					}
				}

			/*
			   if(talkrequest) talkreply();
			*/
			}
			break;
		case -1:
			inet_printf("%s\n", "This is error");
			exit(1);

		default:	/* Parent process */
			signal(SIGCHLD, SIG_IGN);
	}
}

struct user_info ui;
char    pager_id[IDLEN + 2];
struct userec au;

unsigned int u_num;

cmpunums(uentp)
struct user_info *uentp;
{
	if (u_num == uentp->destuid)
	{
		user_online_flag = TRUE;
		check_user_info = uentp;
		return QUIT_LOOP;
	}
}

int
cmp_destid(userid, up)
char   *userid;
register USER_INFO *up;
{
	if (up == NULL)
		return 0;
	return (!strcmp(userid, up->destid));
}


int
searchuserlist(userid)
char   *userid;
{

	register USER_INFO *up;

	if ((up = search_ulist(cmp_destid, userid)))
	{
		check_user_info = up;
		return 1;
	}
	return 0;
}

setpagerequest()
{

	if (!searchuserlist(curuser.userid))
		return 1;

	if (!check_user_info->sockactive)
		return 1;

	get_passwd(&au, check_user_info->userid);
	uinfo.destuid = check_user_info->uid;
	strncpy(uinfo.destid, au.userid, IDLEN + 2);
	return 0;
}

talkreply()
{
	talkrequest = NA;

	if (setpagerequest())
		return 0;	/* no person */
	strcpy(pager_id, au.userid);

	inet_printf("%d\t%s\t%s\t%s\r\n", TALK_REQUEST, au.userid,
		    check_user_info->from, au.username);
}


/*****************************************************
 *  Syntax: TALKREP [Y/N] [why]       (2.0)
 *          TALKREP [Y/N] [who] [why] (2.1)
 *****************************************************/
DoTalkReply()
{
	int     a;
	struct hostent *h;
	char   *buf, *tmp;
	char    hostname[STRLEN];
	struct sockaddr_in sin;


	tmp = Get_para_string(1);
	if (tmp == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	if (setpagerequest())
	{			/* if still call? */
		RespondProtocol(USER_NOT_ONLINE);
		return;
	}

	buf = Get_para_string(2);
	if (strcmp(buf, pager_id))
	{
		RespondProtocol(USER_NOT_ONLINE);
		return;
	}

	gethostname(hostname, STRLEN);
	if ((h = gethostbyname(hostname)) == NULL)
	{
		printf("ERROR\r\n");
		RespondProtocol(WORK_ERROR);
		return;
	}

	bzero(&sin, sizeof sin);
	sin.sin_family = h->h_addrtype;
	bcopy(h->h_addr, &sin.sin_addr, h->h_length);
	sin.sin_port = check_user_info->sockaddr;
	a = socket(sin.sin_family, SOCK_STREAM, 0);
	if ((connect(a, (struct sockaddr *) & sin, sizeof sin)))
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	if (tmp[0] != 'Y' && tmp[0] != 'y')
	{
		printf("Answer no\r\n");
		tmp[0] = 'n';
		buf = Get_para_string(3);
		write(a, tmp, 1);
		write(a, buf, strlen(buf) + 1);
		close(a);
		return;
	}

	tmp[0] = 'y';
	write(a, tmp, 1);
	RespondProtocol(OK_CMD);
	Talking(a);
	close(a);

	uinfo.destuid = 0;
	update_umode(CLIENT);
	update_utmp(&uinfo, uinfo.active);
}


printfriend(uentp)
struct user_info *uentp;
{
	struct userec utmp;

	if (uentp->pid < 2)
		return;
	if (kill(uentp->pid, 0) == -1 || uentp->userid[0] == '\0')
		return;
	if (curuser.userlevel < PERM_CLOAK && uentp->invisible)
		return;

	if ((get_passwd(&utmp, uentp->userid) > 0) &&
	    (override(curuser.userid, -1, uentp->userid)))
	{
		inet_printf("%s\t%s\t%c\t%s\t%s\r\n", uentp->userid, uentp->from,
		 pagerchar(curuser.userid, uentp->userid, uentp->pager),
			    modestring(uentp->mode, uentp->destuid, 1,
				   (uentp->in_chat ? uentp->chatid : NULL)),
			    utmp.username);

	}

}

/********************************************************
*		LISTFUSER
*			�C�X�u�W�n��
*********************************************************/
DoListOnlineFriend()
{
	make_friend_cache();
	if (friend_cache_count > 0)
		override = can_override2;
	else
		override = can_override;

	RespondProtocol(OK_CMD);
	apply_ulist(printfriend);
	inet_printf(".\r\n");
}

/***************************************************************
*		FRIENDGET
*			���o�n�ͦW��
****************************************************************/
DoGetFriend()
{
	char    temp[STRLEN];
	FILE   *fp;
	int     len;

	sethomefile(temp, curuser.userid, UFNAME_OVERRIDES);
	if ((fp = fopen(temp, "r")) == NULL)
	{
		RespondProtocol(NO_FRIEND);
		return;
	}

	RespondProtocol(OK_CMD);
	net_cache_init();
	while (fgets(temp, STRLEN, fp))
	{
		StrDelR(temp);
		len = strlen(temp);
		if (len > 0)
		{
			temp[len++] = '\r';
			temp[len++] = '\n';
			net_cache_write(temp, len);
		}
	}
	fclose(fp);

	net_cache_write(".\r\n", 3);	/* End of Friend List */
	net_cache_refresh();
}

/***********************************************************
*		FRIENDPUT
*			�e�X�n�ͦW��
************************************************************/
DoSendFriend()
{
	char    temp[STRLEN], fname[STRLEN];
	FILE   *fp;
	struct stat st;

	sethomefile(fname, curuser.userid, UFNAME_OVERRIDES);
	if (stat(fname, &st) >= 0 && unlink(fname) < 0)
	{			/* kill old */
		RespondProtocol(WORK_ERROR);
		return;
	}

	if ((fp = fopen(fname, "a")) == NULL)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	RespondProtocol(OK_CMD);
	while (1)
	{
		if (inet_gets(temp, STRLEN - 1) < 0)
		{
			fclose(fp);
			FormosaExit();
		}
		if (temp[0] == '.' && temp[1] == '\0')
			break;
		StrDelR(temp);
		if (temp[0] != '\0' && get_passwd(NULL, temp))
			fprintf(fp, "%s\n", temp);
	}
	fclose(fp);
	RespondProtocol(OK_CMD);
}

t_pager()
{
	curuser.flags[0] |= 1;
	curuser.flags[0] ^= 1;
	if (!uinfo.in_chat)
	{
		uinfo.pager = YEA;
		curuser.flags[0] |= 1;
	}
	else
	{
		uinfo.pager = NA;
	}
	update_utmp(&uinfo, uinfo.active);
}

int 
make_friend_cache()
{
	FILE   *fp;

	friend_cache_count = 0;

	sethomefile(genbuf, curuser.userid, UFNAME_OVERRIDES);
	if ((fp = fopen(genbuf, "r")) == NULL)
		return 0;
	while (fscanf(fp, "%s\n", genbuf) == 1)
	{
		if (*genbuf != '\0')
		{
			if (friend_cache_count == MAX_FRIEND_CACHE)
			{
				free_friend_cache();
				break;
			}
			else
			{
				Friend_Cache[friend_cache_count] = (char *) malloc(strlen(genbuf) + 1);
				strcpy(Friend_Cache[friend_cache_count], genbuf);
				friend_cache_count++;
			}
		}
	}
	fclose(fp);
	return friend_cache_count;
}

int 
free_friend_cache()
{
	int     i;

	for (i = 0; i < friend_cache_count; i++)
		free(Friend_Cache[i]);
	friend_cache_count = 0;
}


DoTermOut()
{
	char    buf[256];
	int     sock, tsock, length;
	struct sockaddr_in tserver;
	struct timeval timeout;

	update_utmp(&uinfo, uinfo.active);

	switch (fork())
	{
		case 0:

			sock = socket(AF_INET, SOCK_STREAM, 0);
			tserver.sin_family = AF_INET;
			tserver.sin_addr.s_addr = INADDR_ANY;
			tserver.sin_port = 0;

			if (bind(sock, (struct sockaddr *) & tserver, sizeof tserver) < 0)
			{
				RespondProtocol(WORK_ERROR);
				exit(1);
			}

			length = sizeof tserver;
			if (getsockname(sock, (struct sockaddr *) & tserver, &length) < 0)
			{
				RespondProtocol(WORK_ERROR);
				exit(1);
			}

			inet_printf("%d\t%d\r\n", TERM_PORT, ntohs((u_short)tserver.sin_port));

			timeout.tv_sec = 20;
			timeout.tv_usec = 0;
			listen(sock, 1);
			tsock = accept(sock, (struct sockaddr *) 0, (int *) 0);
			close(sock);
			if (tsock == -1)
			{
				exit(1);
			}
			dup2(tsock, 0);
			close(tsock);
			dup2(0, 1);
			dup2(0, 2);

			sprintf(buf, "/bin/tsbbs 0 %s", curuser.userid);
			do_exec(buf, NULL);
			break;

		case -1:
			inet_printf("%s\n", "This is error");
			exit(1);

		default:	/* Parent process */
			signal(SIGCHLD, SIG_IGN);
	}
}
