/*******************************************************************
 * ���{���ҩ� functions �j�����O ���� User ��
 *                                          lmj@cc.nsysu.edu.tw
 *******************************************************************/

#include "bbs.h"
#include "csbbs.h"
#include <sys/file.h>

/*******************************************************************
 * �ɤ��ܼƫŧi
 *******************************************************************/
int     net_sock = 0;

/*******************************************************************
 * user.c �禡�C��
 *******************************************************************/


/*******************************************************************
 * ���U�@��ϥΪ
 * �Ѽ�: ubuf -> if NULL, ���d�@�ӪŦ�N�n
 *               else �N�s user ��� (ubuf) �g�J�Ŧ�
 * �Ǧ^: �ϥΪ̽s��.
 *******************************************************************/
unsigned int 
new_user(ubuf)
struct userec *ubuf;
{
	int     fd;
	struct useridx uidx;
	char    homepath[PATHLEN];

	if (ubuf)
	{
		if ((fd = open(USERIDX, O_RDWR)) < 0)
		{
			RespondProtocol(NOT_ALLOW_NEW);
            return 0;
		}

		ubuf->uid = 0;
		for (;;)
		{
			ubuf->uid++;
			if (read(fd, &uidx, sizeof(uidx)) == sizeof(uidx))
        		if (!strcmp(uidx.userid, "new"))
					break;
			else
				break;
		}
		close(fd);

		if (ubuf->uid < 1)	/* debug */
		{
			RespondProtocol(NOT_ALLOW_NEW);
			return 0;
		}

		sethomefile(homepath, ubuf->userid, NULL);
		if (mkdir(homepath, 0755) == -1)
		{
			RespondProtocol(NOT_ALLOW_NEW);
            return 0;
		}

		sethomefile(passfile, ubuf->userid, UFNAME_PASSWDS);
		if ((fd = open(passfile, O_RDONLY)) > 0)
		{
			RespondProtocol(NOT_ALLOW_NEW);
			return 0;
		}
		close(fd);
		if ((fd = open(passfile, O_WRONLY | O_CREAT, 0600)) < 0)
		{
			RespondProtocol(NOT_ALLOW_NEW);
			return 0;
		}
		write(fd, ubuf, sizeof(struct userec));
		close(fd);

		if ((fd = open(USERIDX, O_RDWR | O_CREAT, 0644)) < 0)
		{
			unlink(passfile);
			RespondProtocol(NOT_ALLOW_NEW);
			return 0;
		}
		flock(fd, LOCK_EX);	/* lasehu */
		if (lseek(fd, (long)((ubuf->uid-1)*sizeof(uidx)), SEEK_SET) == -1)
		{
			RespondProtocol(NOT_ALLOW_NEW);
            return 0;
		}
		else
		{
			bzero(&uidx, sizeof(uidx));
			strcpy(uidx.userid, ubuf->userid);
			write(fd, &uidx, sizeof(uidx));
			flock(fd, LOCK_UN);	/* lasehu */
			close(fd);
			return ubuf->uid;
		}
		close(fd);
		unlink(passfile);
		RespondProtocol(NOT_ALLOW_NEW);
		return 0;
	}
	else
	{
		unsigned int cnt = 0;

		if ((fd = open(USERIDX, O_RDWR | O_CREAT, 0644)) < 0)
		{
			RespondProtocol(NOT_ALLOW_NEW);
			return 0;
		}
		flock(fd, LOCK_EX);
		while (read(fd, &uidx, sizeof(uidx)) == sizeof(uidx))
		{	
			if (uidx.userid[0] != '\0')
				continue;
			else
			{
				if (lseek(fd, (long) (-sizeof(uidx)), SEEK_CUR) != -1)
				{
					strcpy(uidx.userid, "new");
					write(fd, &uidx, sizeof(uidx));
					flock(fd, LOCK_UN);
					close(fd);
				}
				else
				{
					cnt = 0;
					break;
				}
			}
		}
		if (cnt == 0)
		{
			struct stat st;

			if (stat(USERIDX, &st) != -1 && st.st_size == 0
			    && lseek(fd, (long) 0, SEEK_SET) != -1)
			{
				strcpy(uidx.userid, "new");
				write(fd, &uidx, sizeof(uidx));
				cnt++;
			}
		}
		else if (cnt >= 0)
		{		/* debug */
			strcpy(uidx.userid, "new");
			write(fd, &uidx, sizeof(uidx));
			cnt++;
		}
		else
			cnt = 0;
		flock(fd, LOCK_UN);
		close(fd);
		return cnt;
	}
}



/*******************************************************************
 * User Login
 * �Ѽ�: name -> userid
 *       passwd -> password (���X)
 *       from -> fromhost ( char [16] )
 * �Ǧ^: �u�W�s��.
 *******************************************************************/
unsigned int 
user_login(name, passwd, from)
char   *name, *passwd, *from;
{
	FILE   *fp;

	bzero(&curuser, sizeof(curuser));
	bzero(&uinfo, sizeof(uinfo));

	if (!get_passwd(&curuser, name)
	    || !checkpasswd(curuser.passwd, passwd))
		return 0;

	if (*curuser.passwd == '\0')	/* �űK�X */
		return 0;

	if ((uinfo.active = new_utmp(NULL)) <= 0)
		return 0;

	strcpy(uinfo.userid, name);
	strcpy(uinfo.username, curuser.username);
	uinfo.pid = getpid();
	uinfo.uid = curuser.uid;
	uinfo.invisible = (curuser.userlevel >= PERM_CLOAK
		&& (curuser.flags[0] & CLOAK_FLAG)) ?
		YEA : NA;
	uinfo.sockactive = NA;
	uinfo.sockaddr = 0;
	uinfo.destuid = 0;
	update_umode(LOGIN);
	uinfo.pager = !(curuser.flags[0] & PAGER_FLAG);
	uinfo.in_chat = NA;
	uinfo.sysuid = BBS_UID;
	sethomefile(passfile, name, UFNAME_PASSWDS);
	curuser.numlogins++;
	if (curuser.userlevel < NORMAL_USER_LEVEL)
	{
		if (curuser.numlogins < NORMAL_USER_LEVEL)
			curuser.userlevel = curuser.numlogins;
		else
			curuser.userlevel = NORMAL_USER_LEVEL;
	}
	nsysu_lastlogin = curuser.lastlogin;
	strcpy(nsysu_lastfromhost, curuser.lasthost);
	strcpy(curuser.lasthost, from);
	strcpy(uinfo.from, from);
	sethomefile(genbuf, name, UFNAME_RECORDS);
	if ((fp = fopen(genbuf, "a")) != NULL)
	{
		fprintf(fp, "%s %s", from, ctime(&(curuser.lastlogin)));
		fclose(fp);
	}
	yank = (curuser.flags[0] & YANK_FLAG) ? YEA : NA;
	return curuser.uid;
}


/*******************************************************************
 * User Logout
 *******************************************************************/
void 
user_logout()
{
	struct userec tmpuser;

	if (ever_del_mail)
		pack_article(maildirect, YEA);
	if (yank)
		curuser.flags[0] |= YANK_FLAG;
	else
		curuser.flags[0] &= ~YANK_FLAG;

	if (get_passwd(&tmpuser, curuser.userid) > 0)
	{
#ifdef IDENT
			if (tmpuser.ident > curuser.ident)
				curuser.ident = tmpuser.ident;
#endif
		curuser.numposts += numposts;
	}

	curuser.lastlogin = time(NULL);

	update_user(&curuser);
	update_user_passfile(&curuser);
	purge_ulist(&uinfo);
}




