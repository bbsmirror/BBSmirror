
#include "bbs.h"
#include "csbbs.h"


char *genpasswd();
int kill_pid;

int
kill_login(upent)
struct user_info *upent;
{
	if (upent->pid == kill_pid)
	{
		if (!strcmp(upent->userid, uinfo.userid))
		{
			kill(upent->pid, SIGKILL);			
			purge_ulist(upent);
			RespondProtocol(OK_CMD);
			kill_pid = -1;
			return 0;
		}
	}
	return 0;
}

/***********************************************************
*		KILLPID pid
*				�屼�ۤv�h�l��login
************************************************************/
DoKill()
{
	kill_pid = Get_para_number(1);

	if (apply_ulist(kill_login) == -1)
    {
		RespondProtocol(PID_NOT_EXIST);
        return;
    }

	if (kill_pid != -1)
		RespondProtocol(PID_NOT_EXIST);
}

/***********************************************************
*		LOGINNUM
*				���o�{�b�ۤv�Ҧ���login
************************************************************/
DoMultiLogin()
{
	multi_user_check();
}

/***********************************************************
*		USERLOG name passwd
*			name	�ϥΪ�ID
*			passwd	�ϥΪ̱K�X
************************************************************/
DoUserLogin()
{
	char   *name, *passwd;
	int     rep = PASSWORD_ERROR;
	int     pass_err = 0;	

	if (ifPass)
		return;

	name = Get_para_string(1);

	if (name[0] != '\0' && strcmp(name, "new"))
	{
		passwd = Get_para_string(2);
		if (passwd != NULL)
		{
			if (user_login(name, passwd, from))
			{
				rep = OK_CMD;
				ifPass = YEA;
			}
			else
				rep = PASSWORD_ERROR;
		}
	}

	if (ifPass)
	{
		/* �R���ª�message�� */
		sprintf(genbuf, "write/%s", curuser.userid);   /* lasehu */
		unlink(genbuf);

		if (!maildirect)
		{
			sprintf(genbuf, "mail/%c/%-s/%-s", tolower(curuser.userid[0]), curuser.userid, DIR_REC);
			maildirect = (char *) malloc(strlen(genbuf) + 1);
			strcpy(maildirect, genbuf);
		}
	/* make sure user is SYSOP  */
		if ((curuser.userlevel >= 255) &&
		    (!seek_in_file(SYSOPLIST, curuser.userid)))
			curuser.userlevel = 50;
		strcpy(oldpass, passwd);
	/* brc_initial("test"); */
		update_umode(CLIENT);
		update_utmp(&uinfo, uinfo.active);

	}
	else
	{
		pass_err++;
	}

	if (pass_err >= LOGINATTEMPTS)
	{
		RespondProtocol(PASSWORD_3_ERROR);
		FormosaExit();
	}
	else
		RespondProtocol(rep);
}


/**********************************************************
*		CERTILOG name passwd
*			�Hcertification�覡login
***********************************************************/
int 
DoCertiLogin(name, passwd)
char   *name, *passwd;
{
	bzero(&curuser, sizeof(curuser));
	bzero(&uinfo, sizeof(uinfo));

	if (!get_passwd(&curuser, name)
	    || !checkpasswd(curuser.passwd, passwd))
		return 0;

	if (*curuser.passwd == '\0')	/* �űK�X */
		return 0;

	if ((uinfo.active = new_utmp(NULL)) <= 0)
		return 0;

	strcpy(curuser.userid, name);
	strcpy(uinfo.userid, name);
	uinfo.pid = getpid();
	uinfo.uid = curuser.uid;
	uinfo.invisible = (curuser.userlevel >= PERM_CLOAK
			   && (curuser.flags[0] & CLOAK_FLAG)) ?
		YEA : NA;
	uinfo.sockactive = NA;
	uinfo.sockaddr = 0;
	uinfo.destuid = 0;
	/* update_umode(MMENU); */
	update_umode(LOGIN);
	uinfo.pager = !(curuser.flags[0] & PAGER_FLAG);
	uinfo.in_chat = NA;
	uinfo.sysuid = BBS_UID;
	sethomefile(passfile, curuser.userid, UFNAME_PASSWDS);
	nsysu_lastlogin = curuser.lastlogin;
	strcpy(nsysu_lastfromhost, curuser.lasthost);
	strcpy(curuser.lasthost, from);
	strcpy(uinfo.from, from);
	yank = (curuser.flags[0] & YANK_FLAG) ? YEA : NA;
 /* brc_initial("test");  */

	ifPass = YEA;
	if (ifPass)
	{
		if (!maildirect)
		{
			sprintf(genbuf, "mail/%c/%-s/%-s", tolower(curuser.userid[0]), curuser.userid, DIR_REC);

			maildirect = (char *) malloc(strlen(genbuf) + 1);
			strcpy(maildirect, genbuf);
		}
	/* make sure user is SYSOP  */
		if ((curuser.userlevel >= 255) &&
		    (!seek_in_file(SYSOPLIST, curuser.userid)))
			curuser.userlevel = 50;
		strcpy(oldpass, passwd);
		update_umode(CLIENT);
		update_utmp(&uinfo, uinfo.active);
	}

	return 1;

}

/**********************************************************
*		ALLOWNEW
*			�߰ݬO�_�i���U�s�b��
***********************************************************/
DoAllowNew()
{
	int     fd;

	if ((fd = open(NONEWUSER, O_RDONLY)) > 0)
	{
		close(fd);
		RespondProtocol(NOT_ALLOW_NEW);
		return;
	}
	RespondProtocol(OK_CMD);
}


/***********************************************************
*		USERCHK name
*			name �ϥΪ�ID
************************************************************/
DoUserCheck()
{
	char   *userid;

	userid = Get_para_string(1);

	if (userid[0] == '\0')
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	if (
#ifndef        SYSOP
	    !strcasecmp(userid, "SYSOP") ||
#endif
	    get_passwd(NULL, userid))
		RespondProtocol(USERID_EXIST);	/* userid already exist */
	else
		RespondProtocol(USERID_NOT_EXIST);
}




/************************************************************
*		USERNEW name passwd e-mail [user_name]
*			name		�ϥΪ�ID
*			passwd		�K�X
*			e-mail		E-mail �b��
*			user_name	�ΦW
*************************************************************/
DoNewLogin()
{
	int     ok = 0;
	struct useridx ni;
	struct userec *nu = &curuser;
	char    name[IDLEN + 2], *passwd;
	char   *tmp;

	bzero(nu, sizeof(curuser));
	bzero(&ni, sizeof(ni));


	strcpy(nu->userid, Get_para_string(1));
	ok = chk_alpha(nu->userid);
	if (ok == 0 || nu->userid[0] == '\0')
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	if 
	(
#ifndef        SYSOP
	    !strcasecmp(nu->userid, "SYSOP") ||
#endif
	    get_passwd(NULL, nu->userid))
	{
		RespondProtocol(USERID_EXIST);	/* userid already exist */
		return;
	}

	strcpy(name, nu->userid);
	passwd = Get_para_string(2);	/* PASSWORD */

	if (passwd[0] == '\0')
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}
	passwd[8] = '\0';
	strncpy(nu->passwd, genpasswd(passwd), PASSLEN);

	tmp = Get_para_string(3);	/* E-MAIL */
	if (tmp[0] == '0')
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}
	else if (tmp[0] == '#')	/* ignore */
		tmp[0] = '\0';

	strcpy(nu->email, tmp);

	if ((tmp = Get_para_string(4)) != NULL)
	{
		strcpy(nu->username, tmp);
		chk_str2(nu->username);
	}
	else
		nu->username[0] = '\0';

	strcpy(nu->termtype, "vt100");
	nu->lastlogin = nsysu_lastlogin = time(0);
	strcpy(nu->lasthost, from);
	strcpy(nsysu_lastfromhost, from);
#ifdef SYSOP
	if (!strcmp(nu->userid, SYSOP))
		nu->userlevel = 255;
	else
#endif
		nu->userlevel = 0;

	if (new_user(nu) && user_login(name, passwd, from))	/* net_login */
	{
		ifPass = YEA;
		if (!maildirect)
		{
			sprintf(genbuf, "mail/%c/%-s/%-s", tolower(curuser.userid[0]), curuser.userid, DIR_REC);
			maildirect = (char *) malloc(strlen(genbuf) + 1);
			strcpy(maildirect, genbuf);
		}

		strcpy(oldpass, passwd);
		update_umode(CLIENT);
		update_utmp(&uinfo, uinfo.active);

		RespondProtocol(OK_CMD);
		return;
	}
	RespondProtocol(NEWUSER_FAIL);
	FormosaExit();
}

