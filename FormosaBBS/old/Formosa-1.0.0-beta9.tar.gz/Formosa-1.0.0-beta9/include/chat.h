#ifndef _BBS_CHAT_H_
#define _BBS_CHAT_H_

#define CHATPORT        5177      /* port numbers for the chat rooms */

#define PROTOLEN        12

/* Protocol Define */

#define CHAT_JOIN       0010
#define CHAT_USRID      0011
#define CHAT_TOPIC      0012
#define CHAT_PASSWD     0013
#define CHAT_QUIT       0014
#define CHAT_MSG        0020
#define CHAT_WHO        0030
#define CHAT_WHOALL     0040
#define CHAT_NICKNAME   0050
#ifdef HAVE_CHATMSGALL
#define CHAT_MSGALL     0060
#endif
#define CHAT_LISTCHAN   0070
#define CHAT_SPEAK      0075
#define CHAT_IGNORE     0076

/* Error Message Define */
#define OK_CMD      700
#define WORK_FAIL   710
#define PASS_FAIL   720
#define USR_FAIL    730
#define NAME_FAIL   740
#define CMD_ERROR   750

#define DEF_CHANNAME    "DefChannel"	/* -ToDo */

#define NOPASSWORD      "nopass"

#define CHANLEN	    (15)
#define TOPICLEN    (20)

#define CHAT_KEY    (2) /* -ToDo- */

char *GetPass(), *PhaseSpace();


#endif	/* _BBS_CHAT_H_ */
