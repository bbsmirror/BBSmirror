#ifndef _BBS_NET_H_
#define _BBS_NET_H_


#define TCP   0
#define UDP   1


#endif /* _BBS_NET_H_ */
