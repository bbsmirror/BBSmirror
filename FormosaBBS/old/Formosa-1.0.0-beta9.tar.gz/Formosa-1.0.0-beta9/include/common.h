#ifndef _BBS_COMMON_H_
#define _BBS_COMMON_H_

#include "struct.h"
#include "perm.h"
#include "net.h"
#include "modes.h"          /* The list of valid user modes */


struct  BoardList {         /* lmj@cc.nsysu.edu.tw */
	char    *name ;
	char    *owner ;
	char    *title ;
	int     num ;
	char    type ;
	char	class;	
	unsigned int bid;	
	unsigned int  level ;
	int     btop ;		
	int     bcur ;              /* �W���ݨ�ĴX�g */
	unsigned char attrib ; 	    /* �ݪO�ݩʺX�� */
	char	visit_flag ;	    /* ���X�Y�ݪO���� */
	time_t  rewind_time ;       /* �ݪO�G�iŪ���O����s�ɶ� */
#ifdef USE_VOTE
	char	vote_flag ;         /* �ݪO�O�_���i��벼�� */
#endif	
};

struct	word	{
	struct	word	*last;
	char	*word;
	struct	word	*next;
};

struct	bword	{
	struct	bword	*last;
	struct	BoardList	*word;
	struct	bword	*next;
};


#endif	/* _BBS_COMMON_H_ */
