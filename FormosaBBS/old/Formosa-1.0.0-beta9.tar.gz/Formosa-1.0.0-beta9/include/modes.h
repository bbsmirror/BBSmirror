#ifndef _BBS_MODES_H_
#define _BBS_MODES_H_

/* Lots o' modes! */	/* see mode in struct user_info in bbs.h */

#define	UNDEFINE	0

#define TALK      2
#define PAGE	  3
#define QUERY	  4
#define LUSERS    5
#define OVERRIDE  6
#define LFRIENDS  7
#define LAUSERS   8
#define SENDMSG	  9

#define SMAIL    10
#define RMAIL    11
/*---
#define READNEW  12
*/

#define READING	 20
#define POSTING  21
#define MODIFY   22

#define MMENU	 30
#define TMENU	 31
#define XMENU	 32
/*---
#define GMENU    33    
*/
#define MAIL     34
#define ADMIN	 35

#define CHATROOM 40
#define IRCCHAT	 44
#define LOCALIRC 45

#define SELECT	     50
#define BOARDS_MENU  51
#define CLASS_MENU   52

/*---
#define OKBRIDGE 60
#define GOPHER   61 
*/
#define BBSNET	 60

#define VOTING 	 70
#define DELVOTE  71
#define EDITVOTE 72
#define ADDVOTE  73

#define LOGIN	 80
#if 0
#define MONITOR  81
#endif
#define EDITSIG	 83
#define EDITPLAN 84

#define CLIENT 	 100

#if 0
#define ULDL    	              
#endif


#endif	/*_BBS_MODES_H_ */
