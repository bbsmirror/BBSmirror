
#include "bbs.h"
#include "tsbbs.h"


#define OBUFSIZE  (4096)
#define IBUFSIZE  (256)

char    outbuf[OBUFSIZE];
int     obufsize = 0;

char    inbuf[IBUFSIZE];
int     ibufsize = 0;
int     icurrchar = 0;


int     timeout_seconds;

short   i_idle;


#ifdef IO_TIMEOUT
void
io_timeout()
{
#if 0
	clear();
	outs("\n�i��ѩ�����c��, �ثe�L�k�P�������o�pô");
	outs("\n�s������, �еy��A��.");
#endif
	log_usies("IO_TIMEOUT");/* lasehu */
#ifdef IDLE_TIMEOUT
	init_alarm(IDLE_TIMEOUT);
#endif
}

#endif

#if 0
#define INPUT_ACTIVE 	0
#define INPUT_IDLE   	1

#endif


#ifdef IDLE_TIMEOUT
void
idle_timeout()
{
	if ((uinfo.mode == IRCCHAT || uinfo.mode == LOCALIRC) && child_pid > 2)
		kill(child_pid, SIGPIPE);
#if 0
	else if ((uinfo.mode == TALK || uinfo.mode == CHATROOM) && i_idle == 1)
	{
		int     fd;
		char    buf[STRLEN];

		sprintf(buf, "doc/hello.%c", time(0) % 10);
		if ((fd = open(buf, O_RDONLY)) > 0)
		{
			read(fd, buf, sizeof(buf));
			outs(buf);
			close(fd);
			refresh();
			bell();
			bell();
			bell();
		}
	}
#endif
/* else if (i_mode == IDLE_IDLE) */
#ifdef IDLE_TIMES
	else if (i_idle > IDLE_TIMES)
#else
	else if (i_idle > 2)
#endif
	{
		if (child_pid > 2)
			kill(child_pid, SIGKILL);
#ifdef BBSLOG_IDLEOUT
		log_usies("IDLEOUT", "\0");
#endif
		clear();
		refresh();
		reset_tty();
		user_logout();
		show_byebye(YEA);
		fflush(stdout);
		close_all_ftable();
		exit(0);
	}
/* i_mode = INPUT_IDLE; */
	i_idle++;
	signal(SIGALRM, idle_timeout);
	alarm(timeout_seconds);
}

#endif


#if 0
extern void monitor_timeout();

#endif


void
init_alarm(type)
int     type;
{
	timeout_seconds = 0;
	alarm(0);		/* cancel previous alarm request */
#ifdef IDLE_TIMEOUT
	if (type == IDLE_TIMEOUT)
	{
		if (HAS_PERM(PERM_SYSOP))
		{
			signal(SIGALRM, SIG_IGN);
			return;
		}
		signal(SIGALRM, idle_timeout);
		timeout_seconds = IDLE_TIMEOUT;
	}
#endif
#ifdef IO_TIMEOUT
	else if (type == IO_TIMEOUT)
	{
		signal(SIGALRM, io_timeout);
		timeout_seconds = IO_TIMEOUT;
	}
#endif
#if 0
	else if (type == M_INT)
	{
		signal(SIGALRM, monitor_timeout);
		timeout_seconds = M_INT;
	}
#endif
	alarm(timeout_seconds);
}

oflush()
{
	if (obufsize)
		write(1, outbuf, obufsize);
	obufsize = 0;
}

output(s, len)
char   *s;
int     len;
{
	if (obufsize + len > OBUFSIZE)
	{			/* doin a oflush */
		write(1, outbuf, obufsize);
		obufsize = 0;
	}
	bcopy(s, outbuf + obufsize, len);
	obufsize += len;
}

ochar(c)
{
	if (obufsize > OBUFSIZE - 1)
	{			/* doin a oflush */
		write(1, outbuf, obufsize);
		obufsize = 0;
	}
	outbuf[obufsize++] = c;
}

int     i_newfd = 0;
struct timeval i_to, *i_top = NULL;
int     (*flushf) () = NULL;

add_io(fd, timeout)
int     fd;
int     timeout;
{
	i_newfd = fd;
	if (timeout)
	{
		i_to.tv_sec = timeout;
		i_to.tv_usec = 0;
		i_top = &i_to;
	}
	else
		i_top = NULL;
}

add_flush(flushfunc)
int     (*flushfunc) ();
{
	flushf = flushfunc;
}

num_in_buf()
{
	return icurrchar - ibufsize;
}


short   init_enter, two_enter, press_enter;
unsigned char my_enter_key;

igetch()
{
igetagain:
	if (ibufsize == icurrchar)
	{
		fd_set  readfds;
		struct timeval to;
		int     sr;

		to.tv_sec = to.tv_usec = 0;
		FD_ZERO(&readfds);
		FD_SET(0, &readfds);
		if (i_newfd)
			FD_SET(i_newfd, &readfds);
		if ((sr = select(16, &readfds, NULL, NULL, &to)) <= 0)
		{
			if (flushf)
				(*flushf) ();
			if (dumb_term)
				oflush();
			else
				refresh();
			FD_ZERO(&readfds);
			FD_SET(0, &readfds);
			if (i_newfd)
				FD_SET(i_newfd, &readfds);
			while ((sr = select(16, &readfds,
					    NULL, NULL, i_top)) < 0)
			{
				if (errno == EINTR)
					continue;
				else
				{
					perror("select");
					fprintf(stderr, "abnormal select conditions\n");
					return -1;
				}
			}
			if (sr == 0)
				return I_TIMEOUT;
		}
		if (i_newfd && FD_ISSET(i_newfd, &readfds))
			return I_OTHERDATA;
		while ((ibufsize = read(0, inbuf, IBUFSIZE)) <= 0)
		{
			if (ibufsize == 0)
				longjmp(byebye, -1);
			if (ibufsize < 0 && errno != EINTR)
				longjmp(byebye, -1);
		}
		icurrchar = 0;
	}
	i_idle &= ~i_idle;
	if (inbuf[icurrchar] == CTRL('L'))
	{
		redoscr();
		icurrchar++;
		goto igetagain;
	}
	else if (inbuf[icurrchar] == 0x0d)
	{
		icurrchar++;
		if (init_enter)
		{
			if (two_enter)
				press_enter++;
			return '\n';
		}
		else
		{
			press_enter++;
			return '\n';
		}
	}
	else
	{
		if (press_enter)
		{
			if (init_enter)
			{
				press_enter &= ~press_enter;
				if (inbuf[icurrchar] == '\0' || inbuf[icurrchar] == 0x0a)
				{
					icurrchar++;
					goto igetagain;
				}
			}
			else
			{
				init_enter++;
				press_enter &= ~press_enter;
				if (inbuf[icurrchar] == '\0' || inbuf[icurrchar] == 0x0a)
				{
					two_enter++;
					icurrchar++;
					goto igetagain;
				}
				else
					two_enter &= ~two_enter;
			}
		}
	}
	return inbuf[icurrchar++];
}



/*
#ifdef	TRAP_ESC
int     KEY_ESC_arg;
#endif
*/

int
getkey(void)
{
	int     mode;
	int     ch, last;

	mode = last = 0;
	while (1)
	{
		ch = igetch();
#if 0
#ifdef TRAP_ESC
		if (mode == 0)
		{
			if (ch == ESC)
				mode = 1;
			else
				return ch;	/* Normal Key or I_OTHERDATA,
						   I_TIMEOUT, ..., etc. */
		}
#else
#endif
#endif
		if (ch == ESC)
			mode = 1;
		else if (mode == 0)	/* Normal Key */
			return ch;
/*
#endif
*/
		else if (mode == 1)
		{		/* Escape sequence */
			if (ch == '[' || ch == 'O')
				mode = 2;
			else if (ch == '1' || ch == '4')
				mode = 3;
			else
			{
/*
#ifdef TRAP_ESC
		KEY_ESC_arg = ch;
		return ESC;
#else
*/
				return ch;
/*
#endif
*/
			}
		}
		else if (mode == 2)
		{		/* Cursor key */
			if (ch >= 'A' && ch <= 'D')
				return KEY_UP + (ch - 'A');
			else if (ch >= '1' && ch <= '6')
				mode = 3;
			else
				return ch;
		}
		else if (mode == 3)
		{		/* Ins Del Home End PgUp PgDn */
			if (ch == '~')
				return KEY_HOME + (last - '1');
			else
				return ch;
		}
		last = ch;
	}
}

int
igetkey()
{
	register int ch;

	ch = getkey();
	return (ch >= 'A' && ch <= 'Z') ? (ch | 32) : ch;
}

getdata(line, col, prompt, buf, len, echo, prefix)
int     line, col;
char   *prompt, *buf;
int     len, echo;

 /* del by lasehu--  int (*complete)() ; */
char *prefix;
{
	unsigned char     ch;
	int     clen = 0;
	int     x, y;
	int     pre_len = 0;

	if (prefix)
		pre_len = strlen(prefix);
	if (prompt)
	{
		move(line, col);
		clrtoeol();	/* lasehu */
		outs(prompt);
	}

/*---
	if (!dumb_term)
*/	
	{
		clrtoeol();
		getyx(&y, &x);
	}
	while (1)
	{
		if (pre_len)
		{
			ch = prefix[clen];
			pre_len--;
		}
		else
			ch = igetch();
/*---
	if (dumb_term)
	{
*/
#if 1
		if (!init_enter)
		{
			fflush(stdout);
			if (ch == 255)
			{	/* 255 == IAC */
				while (ch == 255)
				{
					if ((ch = igetch()) == 250)
					{	/* 250 == SB */
						while ((ch = igetch()) != 240);	/* 240 == SE */
						ch = igetch();
						continue;
					}
					else if (ch == 255)	/* if really send 255
								   char */
						break;
					igetch();	/* DO, DONT, WILL, WONT
							   on */
					ch = igetch();
				}
			}
#ifdef	LMJ_AHA
			else if (!ch || ch == 0x0a)
			{	/* it's two enter key ? */
				two_enter++;	/* Ya! igetch() again. */
				init_enter++;
				ch = igetch();
			}
			else if (ch == 0x0d
#ifdef GUEST_ACCOUNT
				 && !strcmp(myuserid, GUEST_ACCOUNT)
#endif
				)
			{
				if ((ch = igetch()) == 0x0d)
					two_enter &= ~two_enter;
				else
				{
					two_enter++;
					init_enter++;
					ch = igetch();
				}
			}
			init_enter++;
#endif
/*
	    }
*/
#endif
		}
		if (ch == '\n' || ch == '\r')
			break;
		if (ch == ' ')
		{
			if (echo & UNSPACE)
				continue;	/* chang */
		}
		if (ch == ESC)
		{		/* chang 5.5 */
			igetch();
			igetch();
			continue;
		}
		if (ch == '\177' || ch == CTRL('H'))
		{
			if (clen == 0)
			{
				bell();
				continue;
			}
			clen--;
			ochar(CTRL('H'));
			ochar(' ');
			ochar(CTRL('H'));
			continue;
		}
		if (!isprint2(ch))
		{
			if (echo & DOECHO)
				bell();
			continue;
		}
		if (!dumb_term)
		{
			if ((x + clen) >= (t_columns - 1))
			{
				bell();
				continue;
			}
		}
		if (clen >= len - 1)
		{
			bell();
			continue;
		}
		buf[clen++] = ch;
		if (echo & DOECHO)
		{
			if (dumb_term)
				ochar(ch);
			else
				outc(ch);
		}
		else
		{
			if (dumb_term)
				ochar('*');
			else
				outc('*');
		}
	}
	buf[clen] = '\0';
	prints("\n");
	if (dumb_term)
	{
/*
	ochar('\r');
	ochar('\n');
*/
		oflush();
	}
	else
	{
/*
	outc('\r');
	outc('\n');
*/
		refresh();
	}
	return clen;
}
