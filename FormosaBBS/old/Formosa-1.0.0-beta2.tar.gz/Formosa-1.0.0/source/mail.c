
#include "bbs.h"
#include "tsbbs.h"


int     Mail_Send(), Mail_Help();

struct one_key mail_comms[] =
{
	CTRL('P'), Mail_Send,
	'h', Mail_Help,
	'm', mail_article,
	'd', del_article,
	'E', edit_article,
	'i', title_article,
	'T', batch_del_article,
	'g', reserve_article,
	'\0', NULL
};


/*
 * �H�H�ܯ���
 */
bbs_localmail(fname, to, title)
char   *fname, *to, *title;
{
	USEREC  urcbuf;

	if (get_passwd(&urcbuf, to) <= 0)
/* lasehu
   msg("�ϥΪ̥N�����~");
 */
		return -1;

/* lasehu: Auto-Forward */
	if ((urcbuf.flags[0] & FORWARD_FLAG) && !invalid_email(urcbuf.email))
	{
#if 0
		msg("[%s] �w�ҰʭӤH�H��N�� ... �Ы����N��.", to);
		getkey();
		msg("�N�H����e [%s], ��H�� ...", urcbuf.email);
#endif
		if (bbs_inetmail(0, fname, NULL, urcbuf.email, title, ASK_UUENCODE) == 0)
		{
#ifdef NOT_REAL_AUTOFORWARD
			bbs_save_localmail(fname, to, title);
			msg("��e����, �åB�t�����@�ʦs�b [%s] �H�c��", to);
			getkey();
#endif
			return 0;
		}
		msg("��e����. �H����s [%s] �H�c�� ... �Ы����N��", to);
		getkey();
	}

	return bbs_save_localmail(fname, to, title);
}


int
bbs_save_localmail(fname, to, title)
char   *fname, *to, *title;
{
	char    path[PATHLEN];

	setmailfile(path, to, NULL);
	if (!dashd(path))
	{
		if (mkdir(path, 0700) == -1)
			return -1;
	}
	if (append_article(fname, path, curuser.userid, title, curuser.ident, NULL, NA) == -1)
		return -1;
	return 0;
}


/*
 * �H�H�ܯ��~
 */
bbs_inetmail(ms, fname, uuname, to, title, option)
int     ms;
char   *uuname;
char   *fname, *to, *title;
int     option;
{
	int     new_ms;
	char    new_file[PATHLEN];
	int     result;

#ifdef EMAIL_LIMIT
	if (curuser.ident != 7)
	{
		prints("\n");
		outs(_msg_sorry_email);
		clrtoeol();
		getkey();
		return -1;
	}
#endif
	if (ms > 0)
		new_ms = ms;
	else
	{
		if ((new_ms = create_mail_socket()) < 0)
		{
/* lasehu
   msg("�s�� Mail Server ����");
   getkey();
 */
#ifdef MYDEBUG
			bbslog("ERROR", "Connect MailServer Failed");
#endif
			return -1;
		}
	}

	if (uuname && uuname[0])
		strcpy(new_file, uuname);
	else
	{
		strcpy(new_file, fname);
		if (option == ASK_UUENCODE)
		{
			msg("�H�쯸�~���H�n�s�X(uuencode)�� (y/n) ? [n]: ");
			if (igetkey() == 'y')
				uuencode_file(fname, new_file);
		}
	}

	if (telnet_mail(new_ms, new_file, curuser.userid, to, title) == -1)
		result = -1;
	else
		result = 0;
	if (ms <= 0)
		close_mail_socket(new_ms);
#if 0
	if (!uuname)
		unlink(new_file);
#endif
	return result;
}


PrepareMail(srcfile, to, title, option)	/* lasehu */
char   *srcfile;
char   *to, *title;
int     option;
{
	int     save_mmode = in_mail, save_umode = uinfo.mode, result;
	int     mg = 0;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return -1;
#endif

	if (!option)
	{
		if (do_article_to(to) == -1)
			return -1;

		if (is_internet_email(to))
		{
#ifdef EMAIL_LIMIT
			if (curuser.ident != 7)
			{
				prints("\n");
				outs(_msg_sorry_email);
				getkey();
				return -1;
			}
#endif
		}
		else if (get_passwd(NULL, to) <= 0)
		{
			prints("\n�ϥΪ̥N�� [%s] ���~.", to);
			return -1;
		}
	}
	else
	{
		mgatop = malloc_array(MAX_MAILGROUPS);
		mg = AskGroup();
		if (mg == 0)
			return -1;
	}

	if (do_article_title(title) == -1)
	{
		mgatop = free_array(mgatop);
		return -1;
	}

	if (srcfile)
		include_ori(srcfile, tempfile);
	include_sig(curuser.userid, tempfile);

	update_umode(SMAIL);
	in_mail = 1;		/* lasehu */

	if (vedit(tempfile, title))
	{
		in_mail = save_mmode;
		unlink(tempfile);
		update_umode(save_umode);
		if (option == YEA)
			mgatop = free_array(mgatop);
		return -1;
	}

	in_mail = save_mmode;

	if (mg)
		result = MailGroup(tempfile, title);
	else if (is_internet_email(to))
		result = bbs_inetmail(0, tempfile, NULL, to, title, ASK_UUENCODE);
	else
		result = bbs_localmail(tempfile, to, title);

	unlink(tempfile);
	update_umode(save_umode);

	if (option == YEA)
		mgatop = free_array(mgatop);

	return result;
}



/*
 * �^�H
 */
reply_mail(finfo, direct)
FILEHEADER *finfo;
char   *direct;
{
	char    to[STRLEN], title[STRLEN], srcfile[STRLEN];

	clear();

	strcpy(to, (finfo->owner[0] == '#') ? (finfo->owner + 1) : (finfo->owner));
	strcpy(title, finfo->title);

	setdotfile(srcfile, direct, finfo->filename);

	if (PrepareMail(srcfile, to, title, NA) == -1)
		outs("�H�H����.");
	else
		outs("�H�H����.");

	pressreturn();
	return R_FULL;
}


/*
 * �ˬd�ӤH�H�c Mail �ƶq
 */
check_mail_num()
{
	int     cnt;

	cnt = get_num_records(maildirect, FH_SIZE);
	if (cnt > maxkeepmail && ever_del_mail)
	{
		int     fd;

		if ((fd = open(maildirect, O_RDONLY)) > 0)
		{
			while (read(fd, &tmp_fh, sizeof(tmp_fh)) == sizeof(tmp_fh))
				if ((tmp_fh.accessed & FILE_DELE))
					cnt--;
			close(fd);
		}
	}
	if (cnt > maxkeepmail && !HAS_PERM(PERM_SYSOP))
	{
		clear();
		prints("\n�ثe�H�c���� [1m%d[m �ʫH��, �w�g�W�L����.", cnt);
		prints("\n�]���L�kŪ�s�H, �бN�H��q�R�� [1m%d[m �ʦA���}", maxkeepmail);
		prints("\n�_�h�U���z���s���H���F��, �N�L�k�s�J�H�c��.[m");
		pressreturn();
		return 1;
	}
	return 0;
}


int
m_group()			/* mail to some others */
{
	char    to[STRLEN], title[STRLEN];
	int     result;

	clear();

	to[0] = (title[0] = '\0');

	result = PrepareMail(NULL, to, title, YEA);
	move(b_line - 1, 0);
	clrtoeol();
	if (result == -1)
		outs("�H�H����.");
	else
		outs("�H�H����.");

	in_mail = 0;

	pressreturn();
	return M_FULL;
}


int
m_send()			/* mail to someone */
{
	char    to[STRLEN], title[STRLEN];
	int     result;

	clear();

	to[0] = (title[0] = '\0');

	result = PrepareMail(NULL, to, title, NA);
	move(b_line - 1, 0);
	clrtoeol();
	if (result == -1)
		outs("�H�H����.");
	else
		outs("�H�H����.");

	in_mail = 0;

	pressreturn();
	return M_FULL;
}


/*******************************************************************
 * �uŪ�s���H
 *******************************************************************/
m_new()
{
	int     fd, ent = 0;

	do
	{
		if ((fd = open(maildirect, O_RDWR)) < 0)
			return M_FULL;
		update_umode(RMAIL);
		while (read(fd, &tmp_fh, sizeof(tmp_fh)) == sizeof(tmp_fh))
		{
			if (++ent > maxkeepmail && !HAS_PERM(PERM_SYSOP))
			{
				clear();
				outs("�H�c�w��, �|���H��Ū!");
				pressreturn();
				close(fd);
				return M_FULL;
			}
			if (tmp_fh.accessed & FILE_READ)
				continue;
			clear();
			prints("�H�H�H : %s\n���D : %s\n�z�QŪ���H�󤺮e�� ? (y/n) [y] : ", (tmp_fh.owner[0] == '#') ? (tmp_fh.owner + 1) : (tmp_fh.owner), tmp_fh.title);
			if (igetkey() == 'n')
				continue;
			setdotfile(genbuf, maildirect, tmp_fh.filename);
			more(genbuf, NA);
			tmp_fh.accessed |= FILE_READ;
			if (lseek(fd, -((off_t) FH_SIZE), SEEK_CUR) != -1)
				write(fd, &tmp_fh, FH_SIZE);
			msg("<<Ū�s�H>> (r)�^�H (d)�R�� (n)�U�@�� (e)���}? [n] : ");
			switch (igetkey())
			{
				case 'r':
					reply_mail(&tmp_fh, maildirect);
					break;
				case 'd':
					tmp_fh.accessed |= FILE_DELE;
					if (lseek(fd, -((off_t) FH_SIZE), SEEK_CUR) != -1)
						write(fd, &tmp_fh, FH_SIZE);
					break;
				case 'e':
					close(fd);
					return M_FULL;
				case 'n':
				default:
					break;
			}
		}
		close(fd);
		move(2, 0);
		clrtobot();
		outs("�S���s�H�F !!");
		pressreturn();
	}
	while (check_mail_num());

	return M_FULL;
}


/*******************************************************************
 * Read Mail Menu �ӤH�H�c  �C���\Ū
 *******************************************************************/
m_read()
{
	do
	{
		in_mail = 1;	/* lasehu ? */
		i_read(maildirect, &mail_comms[0], IREAD_MAIL);
	}
	while (check_mail_num());
	in_mail = 0;

	return M_FULL;
}


int
CheckFwdEmailaddr(addr)
char   *addr;
{
	if (addr[0] == '\0')
	{
		outs("\n�Х��ק�ӤH��Ƥ� e-mail ���.\n");
		outs("\n��W�z�n��H����}, �~��Ұʦ��]�w\n");
		outs("\n�Ҧp: \n   myuserid@hostName.domain.zone");
	}
#ifdef NSYSUBBS
	else if (strstr(addr, "bbs.nsysu.edu.tw") ||
		 strstr(addr, "bbs2.nsysu.edu.tw") ||
		 strstr(addr, "bbs3.nsysu.edu.tw"))
	{
		outs("\n�Y�n�ϥΦ۰���H�A��, �ӤH��� e-mail ���ФŶ�g���sBBS��");
	}
#endif
/*
	else if (strstr(addr, MYHOSTNAME) || strstr(addr, MYHOSTIP))
*/
	else if (strstr(addr, MYHOSTNAME))
	{
		outs("\n�ӤH��� e-mail ���]�w���~, �Ŷ�g������}, �Э��s�]�w.");
	}
	else
		return 0;
	return -1;
}


/*
 * �]�w Auto-forward �ӤH�H��۰���H�A�ȿﶵ
 */
m_forward()
{
	move(2, 0);
	clrtoeol();
	if (HAS_FLAG(FORWARD_FLAG))
	{
		outs("�����۰���H.");
		UNSET_FLAG(FORWARD_FLAG);
	}
	else
	{
		if (CheckFwdEmailaddr(curuser.email) != -1)
		{
			SET_FLAG(FORWARD_FLAG);
			prints("\n�H��z���H��N�۰���H�� [%s].\n", curuser.email);
			prints("\n�Y�n�ק���H�ت��a, �Эק�ӤH��Ƥ� e-mail ���.");
			update_user(&curuser);	/* lasehu */
		}
	}
	update_user(&curuser);
	pressreturn();
	return M_FULL;
}


/*
   m_fix()
   {
   sprintf(genbuf,"gbmail -m %s",curuser.userid);
   outdoor(genbuf, UNDEFINE, YEA);

   return M_FULL;
   }
 */


/*******************************************************************
 * �ˬd�H�c���L�s�H
 *******************************************************************/
check_newmail(name)
char   *name;
{
	static long lasttime = 0;
	static  ismail = 0;
	struct stat st;
	int     fd;
	register long numfiles;
	char    fname[PATHLEN];
	int     oismail = 0, isme = 0;

	if (!strcmp(name, curuser.userid))
		isme = 1;
	setmailfile(fname, name, DIR_REC);
	if (stat(fname, &st) == -1)
		return ((isme) ? (ismail = 0) : (oismail = 0));
	if (isme)
	{
		if (lasttime >= st.st_mtime)
			return ismail;
		lasttime = st.st_mtime;
	}
	numfiles = st.st_size / FH_SIZE;
	if (numfiles <= 0)
		return ((isme) ? (ismail = 0) : (oismail = 0));
	if ((fd = open(fname, O_RDONLY)) > 0)
	{
		lseek(fd, (off_t) (st.st_size - FH_SIZE), SEEK_SET);
		while (numfiles--)
		{
			read(fd, &tmp_fh, sizeof(tmp_fh));
			if (!(tmp_fh.accessed & FILE_READ) && !(tmp_fh.accessed & FILE_DELE))
			{
				close(fd);
				return ((isme) ? (ismail = 1) : (oismail = 1));
			}
			lseek(fd, -2 * ((off_t) FH_SIZE), SEEK_CUR);
		}
		close(fd);
	}
	return ((isme) ? (ismail = 0) : (oismail = 0));
}


int
Mail_Send(ent, finfo, direct)	/* Send Mail */
int     ent;			/* unused */
FILEHEADER *finfo;		/* unused */
char   *direct;			/* unused */
{
	int     savemode = uinfo.mode;

	m_send();
	uinfo.mode = savemode;

	return R_FULL;
}


int
Mail_Help()			/* Show help of Read-Mail Menu */
{
	more(MAIL_HELP, YEA);
	return R_FULL;
}

DispGroup()
{
	short   i, num, total = 0;
	char   *s;

	move(4, 0);
	clrtobot();

	if (mgatop)
	{
		num = mgatop->number;
		for (i = 0; i < num; i++)
		{
			s = mgatop->datap[i];
			if (s)
			{
				move(total + 4, 0);			
				prints("(%d) %s", total + 1, s);
				total++;
			}
		}
	}
	if (total == 0)
		prints("�|���[�J����ϥΪ�.");
}


/*
 * �߰� Mail Groups �W�� �Ǧ^�H��
 */
int
AskGroup()
{
	char    name[STRLEN - 10];

	clear();
	prints("[�H�H���h�H] (�� %d �H)", MAX_MAILGROUPS);
	while (1)
	{
		DispGroup();
		if (MailToAllFriend)
		{
			outs("\n�w�N�Ҧ��n�ͥ[�J�H�H�W�椤.");
			getdata(2, 0, "�ﶵ: [a]�[�J [d]�R�� [f]�R���Ҧ��n�� [e]���� [q]��� : [e] ", genbuf, 2, ECHONOSP, NULL);
		}
		else
			getdata(2, 0, "�ﶵ: [a]�[�J [d]�R�� [f]�[�J�Ҧ��n�� [e]���� [q]��� : [e] ", genbuf, 2, ECHONOSP, NULL);
		switch ((genbuf[0] | 32))
		{
			case 'a':
				if (num_array(mgatop) == MAX_MAILGROUPS)
				{
					prints("�̦h�u��]�w %d �H.", MAX_GROUPS);
					getkey();
					continue;
				}
				if (!getdata(2, 0, "���H�H: ", name, sizeof(name), ECHONOSP, NULL))
					continue;
#ifdef EMAIL_LIMIT
				if (curuser.ident != 7 && strchr(name, '@'))
				{
					outs("\n");
					outs(_msg_sorry_email);
					getkey();
					continue;
				}
#endif
				if (!strchr(name, '@') && get_passwd(NULL, name) <= 0)
					continue;
				mgatop = add_array(mgatop, name, malloc_str);
				break;
			case 'f':
				MailToAllFriend = (MailToAllFriend) ? NA : YEA;
				break;
			case 'd':
				if (!getdata(2, 0, "�R��: ", genbuf, IDLEN + 1, ECHONOSP, NULL))
					continue;
				mgatop = cmpd_array(mgatop, genbuf, strcmp);
				break;
			case 'q':
				mgatop = free_array(mgatop);
				return 0;
			case 'e':
			default:
				if (num_array(mgatop) <= 0)
					return 0;
				return 1;
		}
	}
	clear();
	return 1;
}


/*
 * ��峹�H�� Mail Groups
 */
MailGroup(fname, title)
char   *fname, *title;
{
	int     i, ms, num;
	char    uuname[PATHLEN];
	char   *s;

	if (!fname || !(*fname))
		return -1;
	if ((ms = create_mail_socket()) < 0)
		return -1;

	uuname[0] = '\0';
	msg("�H�쯸�~���H�n�s�X(uuencode)�� (y/n) ? [n]: ");
	if (igetkey() == 'y')
		uuencode_file(fname, uuname);

	num = mgatop->number;
	for (i = 0; i < num; i++)
	{
		s = mgatop->datap[i];
		if (s)
		{
			if (is_internet_email(s))
				bbs_inetmail(ms, fname, uuname, s, title, NOASK_UUENCODE);
			else
				bbs_localmail(fname, s, title);
		}
	}
	if (MailToAllFriend)
	{
		FriendLoadCache();
		num = friend_cache->number;
		for (i = 0; i < num; i++)
		{
			s = friend_cache->datap[i];
			if (s)
			{
				if (is_internet_email(s))
					bbs_inetmail(ms, fname, uuname, s, title, NOASK_UUENCODE);
				else
					bbs_localmail(fname, s, title);
			}
		}
	}

	mgatop = free_array(mgatop);

	if (uuname[0])
		unlink(uuname);
#if 0
	if (fname)
		unlink(fname);
#endif
	close_mail_socket(ms);
	return 0;
}


int
invalid_email(addr)
char   *addr;
{
	unsigned char     ch;
	short mode;

	mode = -1;
	while ((mode <= 0) && (ch = *addr))
	{
		if (ch == '@')
			mode++;
		else if (!isalnum(ch) && !strchr("[].%!:-_ <>\"{}", ch))
			return 1;
		addr++;
	}
	if (mode > 0)
		return 1;
	return mode;
}

