/*******************************************************************
 * �u�W�ϥΪ̧Y�ɸ��:
 *	�ϥ� Shared Memory 
 *******************************************************************/

#include "bbs.h"
#include "tsbbs.h"


extern struct UTMPFILE *utmpshm;	/* �����ϥΪ� USER_INFO ���� */

#if 0
USER_INFO *curutmp;		/* �ثe����ϥΪ� USER_INFO ���� */

#endif


void
update_utmp()
{
	register int actent = (uinfo.active) - 1;

#ifdef MYDEBUG
	if (actent < 0 || actent >= MAXACTIVE)
	{
		bbslog("DEBUG", "update_utmp() overflow");
		exit(-1);
	}
#endif
#if 0
	memcpy(curutmp, &uinfo, sizeof(uinfo));
#endif
	memcpy((utmpshm->uinfo) + actent, &uinfo, sizeof(USER_INFO));
}


void
update_umode(mode)
int     mode;
{
	uinfo.mode = mode;
	update_utmp();
}


void
purge_utmp(upent)
USER_INFO *upent;
{
	register int actent = (upent->active) - 1;

#ifdef MYDEBUG
	if (actent < 0 || actent >= MAXACTIVE)
	{
		bbslog("DEBUG", "purge_utmp() overflow");
		exit(-1);
	}
#endif
#if 0
	memset(upent, 0, sizeof(USER_INFO));
#endif
	memset((utmpshm->uinfo) + actent, 0, sizeof(USER_INFO));
#ifndef NSYSUBBS
	if (utmpshm->number > 0)
		utmpshm->number--;
	else 
		utmpshm->number = 0;
#endif		
}


int
new_utmp()
{
	extern int errno;
	register time_t now;
	register int i, spoint;
	register pid_t pid;
	register USER_INFO *uentp;

	resolve_utmp();
	now = time(NULL);
#ifndef NSYSUBBS
	now = time(NULL) - 228;
	if (now > utmpshm->uptime)
		utmpshm->busystate = 0;

	while (utmpshm->busystate)
	{
		sleep(1);
	}
	utmpshm->busystate = 1;

/* ------------------------------- */
/* for ���F�ǻ�: �C 228 ����s�@�� */
/* ------------------------------- */
	 /* ���F�ǻ��� onlinesrv �ѨM�A�o�̤��n�� -- lmj */
	if (now > utmpshm->uptime)
	{
		uentp = utmpshm->uinfo;
		for (i = now = errno = 0; i < USHM_SIZE; i++, uentp++)
		{
			if (uentp->pid > 2)
			{
				if ((kill(uentp->pid, 0) == -1) && (errno == ESRCH))
				{
					/* don't need reset struct, just pid only -- lmj
					memset(uentp, 0, sizeof(USER_INFO));
					*/
					uentp->pid = 0;
					errno = 0;
				}
				else
					now++;
			}
		}
		utmpshm->number = now;
		time(&utmpshm->uptime);
	}
#endif
	pid = getpid();		/* lasehu */

	spoint = ((now + pid) % 10) * (MAXACTIVE/10);
	uentp = &(utmpshm->uinfo[spoint]);
#if 0	
	uentp = utmpshm->uinfo;
	for (i = 0; i < USHM_SIZE; i++, uentp++)
#endif
	for (i = spoint; i < USHM_SIZE; i++, uentp++)	
	{
		if (uentp->pid < 3)	/* lasehu ?*/ /* lmj */
		{
			uentp->pid = pid;
#ifndef NSYSUBBS
			utmpshm->number++; 
			utmpshm->busystate = 0;
			time(&utmpshm->uptime);	/* lasehu */
#endif			
			return (i + 1);	/* lasehu */
		}
	}
	
	uentp = utmpshm->uinfo;
	for (i = 0; i < spoint; i++, uentp++)
	{
		if (uentp->pid < 3)	/* lasehu ?*/ /* lmj */
		{
			uentp->pid = pid;
#ifndef NSYSUBBS
			utmpshm->number++;
			utmpshm->busystate = 0;
			time(&utmpshm->uptime);	/* lasehu */
#endif
			return (i + 1);	/* lasehu */
		}
	}
#ifndef NSYSUBBS
	utmpshm->busystate = 0;
#endif	
	sleep(1);
	exit(1);
}


/*******************************************************************
 * �ˬd���� login
 *******************************************************************/
#ifdef MAX_GUEST_LOGINS
short     count_guest_logins = NA;

#endif

count_multi_login(upent)
USER_INFO *upent;
{
	static short i = 0;

	if (upent->pid <= 2)	/* debug */
		return -1;
#if 0
	if (upent->uid == uinfo.uid)
#endif
#if 1
	if (!strcmp(upent->userid, uinfo.userid))
#endif
		{
			i++;
			if (upent->pid <= 2 || uinfo.pid <= 2)	/* lasehu */
				return -1;
			if (upent->pid != uinfo.pid)
			{
				multi++;
#ifdef MAX_GUEST_LOGINS
				if (count_guest_logins)
				{
					if (multi > MAX_GUEST_LOGINS)
					{
						fprintf(stdout, "\n��p, �������[�ί���(guest)�ϥΤH�Ƥw�B��, �бz�y��A��.\n");
						fflush(stdout);
						sleep(1);
						exit(0);
					}
					return 0;
				}
#endif
				prints("\n%d. Login PID:[%d] �Ӧ� %s �O�_�R�� (y/n) ? [n] : ", i, upent->pid, upent->from);
				if (igetkey() == 'y')
				{
					if (upent->pid > 2)	/* lasehu */
					{
						kill(upent->pid, SIGKILL);
						purge_utmp(upent);
					}
					multi--;
				}
				if (multi > MULTILOGINS)
				{
					if (!HAS_PERM(PERM_SYSOP))
					{
						fprintf(stdout, "\n���୫�� Login %d �� !!", multi);
						fflush(stdout);
						sleep(1);
						exit(0);
					}
				}
			}
		}
	return -1;
}


void
multi_user_check()
{
#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
	{
# ifdef MAX_GUEST_LOGINS
		count_guest_logins = YEA;
# else
		return;
	/* UNREACHED */
# endif
	}
#endif /* GUEST_ACCOUNT */
	apply_ulist(count_multi_login);
}
