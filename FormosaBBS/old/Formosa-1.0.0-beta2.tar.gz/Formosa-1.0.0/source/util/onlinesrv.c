/*
 * ���{���ΨӨ��N inetd ���� tcp connection request
 * ���F�t�Φw���Ӧs�b
 * �Фp�߳]�w /etc/hosts.ip
 *									-- lmj@cc.nsysu.edu.tw
 */

/*
 * �t�A�ɰ
 */
#include <sys/param.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/file.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <netdb.h>
#include <syslog.h>
#include <pwd.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#ifndef AIX
#include <sys/pathname.h>
#endif

#include <sys/ipc.h>
#include <sys/shm.h>

#include "bbs.h"
#include "shm.h"

/*
 * �Ѧ��ɸ��|�w�q
 */
#define	PATH_DEVNULL	"/dev/null"
#define	HOST_ALLOW	"/etc/hosts.ip"
#define ONLINESRV_PORT 555

/*
 * �~����ƫŧi
 */
extern int errno;


/*------------------------------------------------------------------------
 * check_host_allow  - �ˬd�ϥΪ̨ӳB
 *------------------------------------------------------------------------
 */
int 
cmp_char(c1, c2)
char    c1, c2;
{
	if (c1 == c2)
		return 0;
	else if (c1 >= 'A' && c1 <= 'Z' && c2 >= 'a' && c2 <= 'z' &&
		 (c2 - c1) == 0x20)
		return 0;
	else if (c2 >= 'A' && c2 <= 'Z' && c1 >= 'a' && c1 <= 'z' &&
		 (c1 - c2) == 0x20)
		return 0;
	else
		return -1;
}


int 
check_from(from)
char   *from;
{
	FILE   *fp;
	char   *s1, *s2, buf[80];

	if (!from || !(fp = fopen(HOST_ALLOW, "r")))
		return -1;
	while (fgets(buf, 79, fp))
	{
		if (buf[0] == '#' || buf[0] == '\n')
			continue;
		if (s1 = (char *) strrchr(buf, '\n'))
			*s1-- = '\0';
		else
			s1 = buf + strlen(buf) - 1;
		if (buf[0] == '*')
		{
			for (s2 = from + strlen(from) - 1; s2 >= from && s1 > buf; s1--, s2--)
				if (cmp_char(*s1, *s2))
					break;
			if (s1 == buf)
			{
				fclose(fp);
				return 0;
			}
		}
		else
		{
			for (s1 = buf, s2 = from; *s1 != '\0' && s2 != '\0'; s1++, s2++)
				if (cmp_char(*s1, *s2))
					break;
			if (*s1 == '\0')
			{
				fclose(fp);
				return 0;
			}
		}
	}
	fclose(fp);
	return -1;
}




/*------------------------------------------------------------------------
 * reaper - clean up zombie children
 *------------------------------------------------------------------------
 */
static void
reaper()
{
#if	defined(SOLARIS) || defined(AIX)
	int     status;

#else
	union wait status;

#endif				/* SOLARIS */

	while (wait3(&status, WNOHANG, (struct rusage *) 0) > 0)
		 /* empty */ ;
	(void) signal(SIGCHLD, reaper);
}



/*
 * Main
 *
 */

void 
main(argc, argv)
int     argc;
char   *argv[];
{
	int     aha, on = 1, maxs;
	fd_set  ibits;
	struct sockaddr_in from, sin;
	int     s, ns;
	short   check = 1;
	struct timeval wait;
	char    buf[80], *pp;

	if (fork() != 0)
		exit(0);

	for (aha = 64; aha >= 0; aha--)
		close(aha);

	if ((aha = open(PATH_DEVNULL, O_RDONLY)) < 0)
		exit(1);
	if (aha)
	{
		dup2(aha, 0);
		close(aha);
	}
	dup2(0, 1);
	dup2(0, 2);

	sprintf(buf, "/tmp/onlinesrv.pid");
	unlink(buf);
	if ((aha = open(buf, O_WRONLY | O_CREAT, 0644)) > 0)
	{
		sprintf(buf, "%-d\n", getpid());
		write(aha, buf, strlen(buf));
		close(aha);
	}

	signal(SIGHUP, SIG_IGN);
	signal(SIGCHLD, reaper);

	if ((s = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		exit(1);

	setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (char *) &on, sizeof(on));
#if defined(IP_OPTIONS) && defined(IPPROTO_IP)
	setsockopt(s, IPPROTO_IP, IP_OPTIONS, (char *) NULL, 0);
#endif

	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = INADDR_ANY;
	sin.sin_port = htons((u_short) ONLINESRV_PORT);

	if (bind(s, (struct sockaddr *) & sin, sizeof sin) < 0 ||
#if	defined(SOLARIS) || defined(AIX)
	    listen(s, 256) < 0)
#else
	    listen(s, 5) < 0)
#endif
		exit(1);

	aha = sizeof(from);
	maxs = s + 1;
	wait.tv_sec = 5;
	wait.tv_usec = 0;

	while (1)
	{
		FD_ZERO(&ibits);
		FD_SET(s, &ibits);
		if ((on = select(maxs, &ibits, 0, 0, &wait)) < 1)
		{
			if ((on < 0 && errno == EINTR) || on == 0)
				continue;
			else
			{
				shutdown(s, 2);
				close(s);
				exit(-1);
			}
		}
		if (!FD_ISSET(s, &ibits))
			continue;
		if ((ns = accept(s, (struct sockaddr *) & from, &aha)) < 0)
			continue;
		else
		{

			switch (fork())
			{

				case -1:
					close(ns);
					break;

				case 0:
					{
						char   *host, *inet_ntoa();
						char    buf[80];

#ifdef	RESOLVE_HOSTNAME
						struct hostent *hp;

#endif

						signal(SIGCHLD, SIG_IGN);
						close(s);
						dup2(ns, 0);
						close(ns);
						dup2(0, 1);
						dup2(0, 2);
						on = 1;
						setsockopt(0, SOL_SOCKET, SO_KEEPALIVE,
						  (char *) &on, sizeof(on));
#ifdef	RESOLVE_HOSTNAME
						if ((hp = gethostbyaddr((char *) &(from.sin_addr),
						     sizeof(struct in_addr),
							  from.sin_family)))
							host = hp->h_name;
						else
							host = inet_ntoa(from.sin_addr);

						if (check && check_from(host))
						{
							shutdown(0, 2);
							exit(0);
						}
#endif
						if (read(0, buf, sizeof(buf)) > 0 && !strncmp(buf, "HELLO", 5))
						{
							void   *shmptr;
							int     shmid,
							        csbbs,
							        total,
							        i;
							struct UTMPFILE *utmpshm;
							USER_INFO *u;

							total = csbbs = 0;
							shmid = shmget(UTMPSHM_KEY, sizeof(struct UTMPFILE), 0);
							if (shmid >= 0)
							{
								shmptr = (void *) shmat(shmid, NULL, 0);
								if (shmptr != (void *) -1)
								{
									utmpshm = (struct UTMPFILE *) shmptr;
									u = utmpshm->uinfo;
									for (i = 0; i < MAXACTIVE; i++, u++)
									{
										if (u->pid > 2)
										{
											if (kill(u->pid, 0))
												u->pid = 0;
											else
											{
												if (u->c_type == CTYPE_CSBBS)
													csbbs++;
												total++;
											}
										}
										else
											u->pid = 0;
									}
									utmpshm->number = total;
								}
							}
							sprintf(buf, "HELLO %d %d\n", total, csbbs);
							write(1, buf, strlen(buf));
						}
						shutdown(0, 2);
						exit(0);
					}
				default:
					close(ns);
			}
		}
	}
}
