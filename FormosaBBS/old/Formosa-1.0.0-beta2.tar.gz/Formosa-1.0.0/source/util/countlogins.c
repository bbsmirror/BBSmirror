
#include "bbs.h"

int     debug = 0;


void
main(argc, argv)
int     argc;
char   *argv[];
{
    int     fd;
    struct visitor vis;
    int     cnt;
    time_t  now;
    char   *p, timestr[40], path_vistor[256], path_visitor_log[256];
    int     hr;
    struct tm *tm;
    int     counter[24];
    int     start;
    FILE *fp;


    if (argc > 1)
    {
	if (!strcmp(argv[1], "debug"))
	    debug = 1;
    }

    sprintf(path_vistor, "%s/%s", HOMEBBS, PATH_VISITOR);

    if ((fd = open(path_vistor, O_RDONLY)) < 0)
    {
	if (debug)
	    fprintf(stderr, "\ncannot open [%s] !!! \n", path_vistor);
	exit(-1);
    }

    time(&now);

    cnt = 0;
    for (hr = 0; hr < 24; hr++)
    {
	counter[hr] = 0;
    }

    while (read(fd, &vis, sizeof(vis)) == sizeof(vis))
    {
	if (vis.userid[0] == '0')
	    continue;
	tm = localtime(&(vis.when));
	if (tm)
	{
	    hr = tm->tm_hour;
	    if (hr >= 0 && hr <= 23)
		counter[hr] += 1;
	}
	cnt++;
    }

    strncpy(timestr, ctime(&now), sizeof(timestr) - 1);

    if ((p = strchr(timestr, '\n')) != NULL)
	*p = '\0';

    sprintf(path_visitor_log, "%s/%s", HOMEBBS, PATH_VISITOR_LOG);
    if ((fp = fopen(path_visitor_log, "a")) != NULL)
    {
	    fprintf(fp, "\n\n\n   Now: %s\n", timestr);    
	    for (start = 0; start < 24; start += 12)
	    {
	        fprintf(fp, "\n\n");
		for (hr = start; hr < start + 12; hr++)
		    fprintf(fp, "   %02d ", hr);
		fprintf(fp, "\n");
		for (hr = start; hr < start + 12; hr++)
		    fprintf(fp, "  ----");
		fprintf(fp, "\n");
		for (hr = start; hr < start + 12; hr++)
		    fprintf(fp, "%6d", counter[hr]);
	    }
	    fprintf(fp, "\n\n  Total User Logins: %d\n", cnt);
	    fclose(fp);
    }	  
}
