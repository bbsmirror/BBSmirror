
#include "bbs.h"

void
main()
{

}