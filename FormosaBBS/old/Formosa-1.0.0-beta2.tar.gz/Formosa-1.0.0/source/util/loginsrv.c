/*******************************************************************
 * MULTIBBS �s�u�����q�{�� - �@�ΨϥΪ̸��
 *                                          lmj@cc.nsysu.edu.tw
 *******************************************************************/

#define _BBS_LOCAL_UTIL_


#include "bbs.h"
#include "loginsrv.h"
#include "shm.h"

#include <sys/wait.h>
#include <sys/time.h>
#include <sys/resource.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h> 


#define PATH_EXECFILE	"/bin/loginsrv"
#define	PATH_DEVNULL	"/dev/null"
#define ALLOW_CLIENT 	"140.117.11."


int     sock, s, port, rerun, idlesec;
char    genbuf[4096];
unsigned long login = 0;
unsigned long last_login = 0;
USEREC curuser, user;
struct useridx uidx;
USER_INFO uinfo, utmp;

struct UTMPFILE *utmpshm = NULL;	/* �����ϥΪ� USER_INFO ���� */


/*******************************************************************
 * �T�����u
 *******************************************************************/
void
autoexit()
{
    int     i;

    for (i = getdtablesize(); i > 2; i--)
	close(i);
    exit(0);
}


void
resolve_utmp()
{
    if (utmpshm == NULL)
    {
	utmpshm = attach_shm(UTMPSHM_KEY, sizeof(*utmpshm));
	if (utmpshm->uptime == 0)
	{
#if 0
	    utmpshm->uptime = 1;/* ? */
#endif
	    utmpshm->number = 0;	/* lasehu: reset ���W�`�H�� ? */
	}
    }
}


int
ask_online_user()
{
    extern struct UTMPFILE *utmpshm;

    resolve_utmp();
    return utmpshm->number;
}


apply_ulist(fptr)		/* ? */
register int (*fptr) ();
{
    register USER_INFO *uentp;
    register int i;

    resolve_utmp();
    uentp = utmpshm->uinfo;
    for (i = 0; i < USHM_SIZE; i++, uentp++)
    {
	if (uentp->pid < 2 || uentp->userid[0] == '\0')
	    continue;
	if (uentp->active <= 0) /* lasehu ? */
	    continue;
	if (kill(uentp->pid, 0) == -1 && errno == ESRCH)	/* pid not exist */
	    continue;
	if ((*fptr) (uentp) == QUIT_LOOP)	/* interrupt the loop */
	    return QUIT_LOOP;
    }
    return 0;
}


int
count_online_clients(uentp)
USER_INFO *uentp;
{
    static int csbbs = 0;

    if (uentp == NULL)
    {
	int     i = csbbs;

	csbbs = 0;
	return i;
    }
    if (uentp->c_type == CTYPE_CSBBS)
	csbbs++;
    return;
}


int
ask_online_clients()
{
    count_online_clients(NULL);
    apply_ulist(count_online_clients);

    return count_online_clients(NULL);
}


/*******************************************************************
 * User Login
 * �Ѽ�: name -> userid
 *       passwd -> password (���X)
 *       from -> fromhost
 * �Ǧ^: �u�W�s��.
 *******************************************************************/
unsigned int
user_login(name, passwd, from)
char   *name, *passwd, *from;
{
    if (name[0] == '\0' || passwd[0] == '\0')
	return 0;

    bzero(&curuser, sizeof(curuser));
    if (!get_passwd(&curuser, name)
	|| !checkpasswd(curuser.passwd, passwd))
	return 0;

#ifdef HAVE_BUG
#ifdef REALMAXUSERS
    if (curuser.uid > REALMAXUSERS)
	if ((curuser.uid = get_uidx(name)) > REALMAXUSERS)
	    curuser.uid = REALMAXUSERS;
	else if (curuser.uid == 0)
	    return 0;
#endif	    
#endif

    strcpy(curuser.userid, name);
    curuser.numlogins++;
    if (curuser.userlevel < NORMAL_USER_LEVEL)
    {
	if (curuser.numlogins < NORMAL_USER_LEVEL)
	    curuser.userlevel = curuser.numlogins;
	else
	    curuser.userlevel = NORMAL_USER_LEVEL;
    }
    strcpy(curuser.lasthost, from);
    curuser.lastlogin = time(0);
    return (update_user(&curuser));
}


/*******************************************************************
 * �q�@�q�r�ꤤ���X�@���l�r��:
 * �p�G buf == NULL, �Ǧ^�l�r���}
 * �_�h�Ǧ^�U�@���l�r�ꪺ�_�I
 *******************************************************************/
char   *
get_var(begin, buf, len)
char   *begin, *buf;
int     len;
{
    char   *end, *bend;

    if (!begin)
	return (char *) NULL;
    while (*begin == SP || *begin == TAB)
	begin++;
    if (*begin == NL || *begin == '\0')
	return (char *) NULL;
    end = begin;
    while (*end != SP && *end != TAB && *end != NL && *end != '\0')
	end++;
    if (begin == end)
	return (char *) NULL;
    if (!buf)
    {
	buf = (char *) malloc(end - begin + 1);
	*end = '\0';
	strcpy(buf, begin);
	return buf;
    }
    bend = buf + len - 1;
    while (begin < end && buf < bend)
	*buf++ = *begin++;
    *buf = '\0';
    return end;
}


char   *
strupr(str)
char   *str;
{
    int     i;
    char    c;

    for (i = 0; c = str[i]; i++)
	if (c >= 'a' && c <= 'z')
	    str[i] = c - 'a' + 'A';

    return str;
}


int
GetKeywordNo(keyword)
char   *keyword;
{
    int     i;

    strupr(keyword);
    for (i = 0; i < (sizeof(loginsrv_fp) / sizeof(struct PROTOCOL)); i++)
    {
	if (keyword[0] == '\0')
	    return -1;
	if (!strcmp(keyword, loginsrv_fp[i].keyword))
	    return loginsrv_fp[i].num;
    }
    return -1;
}


/*
 * bbs login server
 */
void
loginsrv()
{
    char    name[IDLEN + 2], passwd[PASSLEN], from[16];
    int     fd;
    char    keyword[LOGINSRV_PROTOCOL_LEN];
    char   *NextToken;
    char    buf[STRLEN];

    (void) signal(SIGALRM, autoexit);
    alarm(idlesec);
    while (1)
    {
	net_gets(0, genbuf);
	NextToken = get_var(genbuf, keyword, LOGINSRV_PROTOCOL_LEN);
	switch (GetKeywordNo(keyword))
	{
	  case LSRV_ONLINE:
	    net_printf(1, "%d %d\r\n", ask_online_user(), ask_online_clients());
	    break;
	  case LSRV_SENDUSER:
	    get_var(NextToken, name, sizeof(name));
	    if (get_passwd(NULL, name) <= 0)
	    {
		net_printf(1, "READY\r\n");
		if (read(1, &curuser, sizeof(curuser)) == sizeof(curuser)
		    && !strcmp(curuser.userid, name)
#ifdef HAVE_BUG
		    && !strstr(name, "..") && name[0] != '/'
		    && curuser.uid >= 1 
#ifdef REALMAXUSERS		    
		    && curuser.uid <= REALMAXUSERS
#endif		    
#endif
		    && name[0] != '\0')
		{
		    sethomefile(buf, name, UFNAME_PASSWDS);
		    if ((fd = open(buf, O_WRONLY | O_CREAT, 0644)) > 0)
		    {
			flock(fd, LOCK_EX);
			if (write(fd, &curuser, sizeof(curuser)) == sizeof(curuser))
			{
			    flock(fd, LOCK_UN);
			    close(fd);
			    net_printf(1, "OK\r\n");
			    return;
			}
		    }
		}
	    }
	    net_printf(1, "ERROR\r\n");
	    break;
	  case LSRV_LOGIN:
	    NextToken = get_var(NextToken, name, sizeof(name));
	    NextToken = get_var(NextToken, passwd, sizeof(passwd));
	    get_var(NextToken, from, sizeof(from));
	    if (user_login(name, passwd, from))
	    {
		net_printf(1, "OK\r\n");
		net_gets(0, genbuf);
		if (!strncmp(genbuf, "READY", 5))
		{
		    write(1, &curuser, sizeof(curuser));
		    return;
		}
	    }
	    net_printf(1, "ERROR\r\n");
	    break;
	  case LSRV_UPDATEUSER:
	    NextToken = get_var(NextToken, name, sizeof(name));
	    get_var(NextToken, passwd, sizeof(passwd));
	    if (get_passwd(&curuser, name) > 0 && checkpasswd(curuser.passwd, passwd))
	    {
		net_printf(1, "READY\r\n");
		if (read(0, &curuser, sizeof(curuser)) == sizeof(curuser))
		{
		    update_user(&curuser);
		    net_printf(1, "OK\r\n");
		    return;
		}
	    }
	    net_printf(1, "ERROR\r\n");
	    break;
	/*
	   del by lasehu                case FINDUSER: get_var(NextToken,
	   name, sizeof(name)); if (get_passwd(NULL, name)) net_printf(1,
	   "OK\r\n"); else net_printf(1, "ERROR\r\n"); break; case 'N': if
	   (!strncmp(genbuf, "NEWUSER", 7)) { net_printf(1, "READY\r\n"); if
	   (read(0, &curuser, sizeof(curuser)) == sizeof(curuser)) { if
	   ((curuser.uid = new_user(NULL)) && (new_user(&curuser))) {
	   net_printf(1, "NEWUSEROK\r\n"); return; } } net_printf(1,
	   "ERROR\r\n"); return; } break;
	*/
	  case -1:
	  default:
	    net_printf(1, "ERROR\r\n");
	    break;
	}
	break;
    }
}


/*------------------------------------------------------------------------
 * reaper - clean up zombie children
 *------------------------------------------------------------------------
 */
static void
reaper()
{
    union wait status;

    while (wait3(&status, WNOHANG, (struct rusage *) 0) > 0)
	 /* empty */ ;
}


void
rerunit()
{
#ifdef	DEBUG
    fprintf(stderr, "rerunit(): login = %d.\n", login);
#endif
    if (login)
    {
	login = 0;
#ifdef	DEBUG
	fprintf(stderr, "rerunit(): alarm [%d] ok, clear login count.\n", rerun);
#endif
	(void) signal(SIGALRM, rerunit);
	alarm(rerun);
	return;
    }
    else
    {
	int     i, tsize = getdtablesize();
	char    cport[8], crerun[8], cidle[8];

	for (i = 3; i <= tsize; i++)
	    close(i);
	sprintf(cport, "%d", port);
	sprintf(cidle, "%d", idlesec);
	sprintf(crerun, "%d", rerun);
#ifdef	DEBUG
	fprintf(stderr, "execl(%s,%s,%s,%s,%s,%s,NULL)\n",
	  PATH_EXECFILE, PATH_EXECFILE, cport, prog, args[0], crerun, NULL);
#endif
	(void) signal(SIGALRM, NULL);
	alarm(0);
	sleep(10);
	execl(PATH_EXECFILE, PATH_EXECFILE, cport, cidle, crerun, NULL);
	sleep(10);
	exit(0);
    }
}


void
create_server(sock, fd, server)
int    *sock, *fd;
struct sockaddr_in *server;
{

    while (1)
    {
	*fd = 1;
	if ((*sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
#ifdef	DEBUG
	    fprintf(stderr, "can\'t create new sock.\n");
#endif
	    exit(-1);
	}
	else
	{
	    if (setsockopt(*sock, SOL_SOCKET, SO_REUSEADDR, fd, sizeof(*fd)) < 0)
	    {
		close(*sock);
#ifdef	DEBUG
		fprintf(stderr, "setsockopt error.\n");
#endif
	    }
	    else
		break;
	}
    }
#ifdef	DEBUG
    fprintf(stderr, "socket [%d] ok\n", *sock);
#endif
    server->sin_family = PF_INET;
    server->sin_addr.s_addr = INADDR_ANY;
    server->sin_port = htons((u_short) port);
    if (bind(*sock, (struct sockaddr *) server, sizeof(*server)) < 0)
    {
#ifdef	DEBUG
	fprintf(stderr, "binding port [%d] error\n", port);
#endif
	exit(-1);
    }
    if (listen(*sock, 10) < 0)
    {
#ifdef	DEBUG
	fprintf(stderr, "listen sock [%d], port [%d] error\n", *sock, port);
#endif
	exit(-1);
    }
#ifdef	DEBUG
    fprintf(stderr, "starting listen on port [%d] now.\n", port);
#endif
}


int
get_client_name(cli_addr, peer_name, len)
struct sockaddr_in *cli_addr;
char   *peer_name;
int     len;
{
    int     addr_len;

    addr_len = sizeof(*cli_addr);
    getpeername(0, (struct sockaddr *) cli_addr, &addr_len);
    strncpy(peer_name, (inet_ntoa(cli_addr->sin_addr)), len);
}


void
main(argc, argv)
int     argc;
char   *argv[];
{
    int     s, i, flen, fd, tsize = getdtablesize();
    struct sockaddr_in server, client;
    int     retry_select = 0;
    fd_set  readfds;

    if (argc != 4)
    {
	fprintf(stderr, "Usage: loginsrv [port] [timeout second] [check_sec]\n");
	fprintf(stderr, "  Exp: loginsrv 26 60 1200\n");
	exit(-1);
    }
    
    if (getuid() != 0)	/* lasehu */
    {
        printf("\n!!! �ХH root ���楻�{�� !!!\n");
        exit(0);
    }
    
    if ((i = fork()) == -1)
	exit(-1);
    if (i)			/* parent, this trick is for child process
				   auto-backgroup running */
	exit(0);
#ifdef	DEBUG
    fprintf(stderr, "background fork [%d] ok\n", getpid());
#endif
#ifndef	DEBUG
    (void) setsid();
    (void) chdir("/");
    fd = open(PATH_DEVNULL, O_RDWR, 0);
    if (fd != -1)
    {
	(void) dup2(fd, STDIN_FILENO);
	(void) dup2(fd, STDOUT_FILENO);
	(void) dup2(fd, STDERR_FILENO);
	if (fd > 2)
	    (void) close(fd);
    }
#endif
    port = atoi(argv[1]);
    idlesec = atoi(argv[2]);
    rerun = atoi(argv[3]);
    for (i = 3; i < tsize; i++)
	close(i);
    (void) signal(SIGCHLD, reaper);
    (void) signal(SIGALRM, rerunit);
    flen = sizeof(client);
    sock = -1;
    while (1)
    {
	if (-1 == sock)
	    create_server(&sock, &fd, &server);
	FD_ZERO(&readfds);
	FD_SET(sock, &readfds);
#ifdef	DEBUG
	fprintf(stderr, "select(%d,%d),  retry:[%d]\n", FD_SETSIZE, sock, retry_select);
#endif
    /*
       ? if((s = select(FD_SETSIZE, &readfds, NULL, NULL, &rerun)) <= 0) {
       #ifdef       DEBUG fprintf(stderr, "select() failed: retry:[%d]\n",
       retry_select); #endif close(sock);  sock = -1; if (++retry_select >=2
       )  { login=0;  rerunit(); } sleep(10); continue; }
    */
	if (!FD_ISSET(sock, &readfds))
	    continue;
	FD_CLR(sock, &readfds);
	retry_select = 0;
#ifdef	DEBUG
	fprintf(stderr, "alarm [%d] ok\n", rerun);
#endif
	(void) signal(SIGALRM, rerunit);
	alarm(rerun);
#ifdef	DEBUG
	fprintf(stderr, "WAIT: accept server sock:[%d], port:[%u], num:[%d], last:[%d]\n",
		sock, server.sin_port, login, last_login);
#endif
	s = accept(sock, (struct sockaddr *) & client, &flen);
	alarm(0);
	if (s < 0)
	{
#ifdef	DEBUG
	    fprintf(stderr, "ERROR! socket less than 0!\n");
#endif
	    continue;
	}
	login++;
#ifdef	DEBUG
	fprintf(stderr, "accept connect sock:[%d], port:[%u:%u], num:[%d]\n",
		s, server.sin_port, client.sin_port, login);
#endif

	switch (fork())
	{
	  case 0:		/* if child */
	    (void) close(sock);
	    dup2(s, 0);
	    close(s);
	    dup2(0, 1);
	    dup2(0, 2);
	    get_client_name(&client, genbuf, 30);	/* Check from */
	    if (!strncmp(genbuf, ALLOW_CLIENT, strlen(ALLOW_CLIENT)))
		if (chroot(HOMEBBS) == 0 && chdir("/") == 0)
		{
		    setgid(BBS_GID);
		    setuid(BBS_UID);
		    seteuid(BBS_UID);
		    loginsrv();
		}
	    exit(0);
	  case -1:		/* if error */
	  default:		/* if parent */
	    (void) close(s);
	    break;
	}
    }
}
