/*-------------------------------------------------------*/
/* util/bfinger.c	( NTHU CS MapleBBS Ver 2.36 )	 */
/*-------------------------------------------------------*/
/* target : BBS finger daemon �C�X�����ϥΪ̸��	 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/
/* syntax : bfinger i n f M (ID, nick, fromhost, mode )	 */
/*-------------------------------------------------------*/


#include "bbs.h"
#include <sys/ipc.h>
#include <sys/shm.h>


#include "shm.h"
#include "modetype.c"


#ifdef NSYSUBBS
char field_idx[] = "ufmMin";
#else
char field_idx[] = "ufmMinx";
#endif

char *field_name[] = {
  "UID",
  "From",
  "mode",
  "Mode",
  "ID",
  "Nick",
#ifndef NSYSUBBS  
  "Idle",
#endif  
  NULL
};


int field_count = 0;
int field_lst_no[7];
int field_lst_size[7];
int field_default_size[7] = {12, 16, 4, 10, 12, 18, 8};


char *default_argv[] = {"bfinger", "i", "n", "f", "M"};


/*-------------------------------------------------------*/
/* .UTMP cache						 */
/*-------------------------------------------------------*/

struct UTMPFILE *utmpshm;


void
attach_err(shmkey, name)
  int shmkey;
  char *name;
{
  fprintf(stderr, "[%s error] key = %x\n", name, shmkey);
  exit(1);
}


void *
attach_shm(shmkey, shmsize)
  int shmkey, shmsize;
{
  void *shmptr;
  int shmid;

  shmid = shmget(shmkey, shmsize, 0);
  if (shmid < 0)
  {
    shmid = shmget(shmkey, shmsize, IPC_CREAT | 0600);
    if (shmid < 0)
      attach_err(shmkey, "shmget");
    shmptr = (void *) shmat(shmid, NULL, 0);
    if (shmptr == (void *) -1)
      attach_err(shmkey, "shmat");
    memset(shmptr, 0, shmsize);
  }
  else
  {
    shmptr = (void *) shmat(shmid, NULL, 0);
    if (shmptr == (void *) -1)
      attach_err(shmkey, "shmat");
  }
  return shmptr;
}


void
resolve_utmp()
{
  if (utmpshm == NULL)
  {
    utmpshm = attach_shm(UTMPSHM_KEY, sizeof(*utmpshm));
    if (utmpshm->uptime == 0)
      utmpshm->uptime = utmpshm->number = 1;
  }
}


void
set_opt(argc, argv)
  int argc;
  char *argv[];
{
  int i, flag, field, size;
  int *p;
  char *ptr, *field_ptr;

  field_count = 0;

  for (i = 1; i < argc; i++)
  {
    field_ptr = (char *) strchr(field_idx, argv[i][0]);
    if (field_ptr)
    {
      field = field_ptr - field_idx;

      size = atoi(argv[i] + 1);

      field_lst_no[field_count] = field;
      field_lst_size[field_count] = size ? size : field_default_size[field];
      field_count++;
    }
  }
}


void
print_head()
{
  int i, field, size;

  for (i = 0; i < field_count; i++)
  {
    field = field_lst_no[i];
    size = field_lst_size[i];
    printf("%-*.*s ", size, size, field_name[field]);
  }
  printf("\n");
}


void
print_line()
{
  int i, size;

  for (i = 0; i < field_count; i++)
  {
    size = field_lst_size[i];
    while (size--)
      putchar('=');
    putchar(' ');
  }
  printf("\n");
}


#ifndef NSYSUBBS
char *
idle_str(uptime)
  time_t uptime;
{
  static char hh_mm_ss[16];

  uptime = time(0) - uptime;
  sprintf(hh_mm_ss, "%d:%02d", uptime / 60, uptime % 60);
  return hh_mm_ss;
}
#endif


void
print_record(p)
#ifdef NSYSUBBS
  USER_INFO *p;
#else
  user_info *p;
#endif  
{
  int i, field, size;
  char field_str[40], *str;

  for (i = 0; i < field_count; i++)
  {
    field = field_lst_no[i];
    size = field_lst_size[i];
    str = field_str;
    switch (field)
    {
    case 0:
      sprintf(str, "%d", p->uid);
      break;
    case 1:
      str = p->from;
      break;
    case 2:
      sprintf(field_str, "%d", p->mode);
      break;
    case 3:
#ifdef NSYSUBBS
      strcpy(field_str, ModeType(p->mode)); 
#else    
      strcpy(field_str, ModeTypeTable[p->mode]);
#endif      
      break;
    case 4:
      str = p->userid;
      break;
    case 5:
      str = p->username;
      break;
#ifndef NSYSUBBS      
    case 6:
      str = idle_str(p->uptime);
#endif      
    }
      if(!str)
	str = "";
    printf("%-*.*s ", size, size, str);
  }
  printf("\n");
}


void
usage(prog_name)
  char *prog_name;
{
  int i;

  printf("Usage: %s %s\n", prog_name, "[XN] ....");
  printf("Example: %s %s\n", prog_name, "d3 i12 e30");
  printf("N is field width, X is one of the following char :\n");

  for (i = 0; field_name[i]; i++)
  {
    printf("\t%c[%2d] --> %s\n",
      field_idx[i], field_default_size[i], field_name[i]);
  }
}


main(argc, argv)
  int argc;
  char *argv[];
{
#ifdef NSYSUBBS
  register USER_INFO *uentp;
#else  
  register user_info *uentp;
#endif  
  register int i, user_num;

  if (argc < 2)
  {
    set_opt(sizeof(default_argv) / sizeof(default_argv[0]), default_argv);
  }
  else
  {
    set_opt(argc, argv);
  }

#ifdef NSYSUBBS
  chdir(HOMEBBS);
#else
  chdir(BBSHOME);
#endif  

  print_head();
  print_line();

  resolve_utmp();
  for (i = user_num = 0, uentp = utmpshm->uinfo; i < USHM_SIZE; i++, uentp++)
  {
    if (uentp->userid[0])
    {
      print_record(uentp);
      user_num++;
    }
  }

  print_line();
  printf("�i" BOARDNAME "�j Total users = %d\n", user_num);
}
