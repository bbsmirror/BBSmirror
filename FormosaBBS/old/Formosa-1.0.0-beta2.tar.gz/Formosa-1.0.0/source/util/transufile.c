

#include "bbs.h"

#if 0
#ifdef	NO_DIRENT
#include <sys/dir.h>
#else
#include <dirent.h>
#endif
#endif

#include <sys/dir.h>


void
main(argc, argv)
int argc;
char *argv[];
{
    DIR    *dirp;
#if 0    
#ifdef NO_DIRENT
    struct direct *dp;
#else        
    struct dirent *dp;
#endif    
#endif
    struct direct *dp;
    char   *s;
    unsigned char c;
    char   target[128], targetpath[128];
    char   filekind[100];
    
    if (argc < 2)
    {
        printf("\nYou should give the [filekind] !!\n");
        exit(0);
    }

/*
    strncpy(filekind, argv[1], sizeof(filekind) - 1);
*/
    strcpy(filekind, argv[1]);    

    if (getuid() != BBS_UID)
    {
        setgid(BBS_GID);
        setuid(BBS_UID);
    }
      
    if ((dirp = opendir(".")) == NULL)
    {
        printf("\ncannot open directory !!\n");
	exit(-1);
    }
    
    while ((dp = readdir(dirp)) != NULL)
    {
        s = dp->d_name;
	if (!strcmp(s, ".") || !strcmp(s, "..") || s[0] == '\0')
	{
	    continue;
	}
	c = s[0];
	if (c >= 'A' && c <= 'Z')
	    c |= 32;
	else if (!(c >= 'a' && c <= 'z'))
	    c = '0';    
	sprintf(targetpath, "%s/home/%c/%s", HOMEBBS, c, s);	    
	if (!dashd(targetpath))
	{
	    if (mkdir(targetpath, 0755) == -1)
	    {
	       printf("\nError: cannot make directory: [%s] !!", targetpath);
	       continue;
	    }
	}
	sprintf(target, "%s/%s", targetpath, filekind);
	if (myrename(s, target) == -1) 
	    printf("\nError: cannot rename: [%s] -> [%s]!!", s, target);
/*	    
	    printf("\nrename: [%s] -> [%s]!!", s, target);
*/	    
    }
    closedir(dirp);
}    
