
/*******************************************************************
 * ���{���Ψөw�ɻs�y�u�W�H����
 *                                          lmj@cc.nsysu.edu.tw
 *******************************************************************/

#define _BBS_LOCAL_UTIL_

#include "bbs.h"
#include "net.h"


#define ACTIVEPORT	555

#define ACTIVE_PID	"/tmp/active.pid"

#define	FORMOSABBS1	"140.117.11.2"
#define	FORMOSABBS2	"140.117.11.4"
#define	FORMOSABBS3	"140.117.11.6"


void
main(argc, argv)
int     argc;
char   *argv[];
{
	 FILE   *fp;
	 unsigned char bbs, timer, i;
	 char   *host[] = {FORMOSABBS1, FORMOSABBS2, FORMOSABBS3, NULL};
	 char    buf[512];
	 int     s, act[3], csbbs[3];

 /* �p�G�e�@���٬��ۡA�ߨ赲�� */
	 if (fp = fopen(ACTIVE_PID, "r"))
	 {
		  if (fgets(buf, sizeof(buf), fp))
		  {
		  	int pid;
		  	
			   buf[5] = '\0';
			   pid = atoi(buf);
			   if (pid > 2)
			   {
				   if (kill(pid, 0) == 0)
				   {
					    fclose(fp);
					    exit(0);
				   }
			   }
		  }
		  fclose(fp);
	 }

	 if (getuid())
	 {
		  printf("\n!!! �Х� root �Ӱ��楻�{�� !!!\n");
		  exit(-1);
	 }

	 if (argc != 3)
	 {
		  fprintf(stderr, "Usage: active [bbs station num] [seconds]\n");
		  exit(-1);
	 }

	 if (fork())
		  exit(0);

	 {
		  int     s, ndescriptors = getdtablesize();

		  for (s = 0; s < ndescriptors; s++);
		  (void) close(s);
	 }

	 if (fp = fopen(ACTIVE_PID, "w"))
	 {
		  fprintf(fp, "%5d\n", getpid());
		  fclose(fp);
	 }

	 if (chroot(HOMEBBS) || chdir("/"))
		  exit(-1);
	 setgid(BBS_GID);
	 setuid(BBS_UID);
	 bbs = atoi(argv[1]);
	 timer = atoi(argv[2]);

	 while (1)
	 {
		  memset(act, 0, sizeof(act));
		  memset(csbbs, 0, sizeof(csbbs));
		  for (i = 0; host[i]; i++)
		  {
			   if ((s = ConnectServer(host[i], ACTIVEPORT, TCP)) >= 0)
			   {
				    net_printf(s, "HELLO\n");
				    memset(buf, 0, sizeof(buf));
				    if (net_gets(s, buf, sizeof(buf)))
				    {
					     char   *p1, *p2;

					     if ((p1 = strchr(buf, ' ')) && (p2 = strchr(++p1, ' ')))
					     {
						      *p2++ = '\0';
						      act[i] = atoi(p1);
						      if ((p1 = strchr(p2, '\r')) || (p1 = strchr(p2, '\n')))
							       *p1 = '\0';
						      csbbs[i] = atoi(p2);
					     }
				    }
				    shutdown(s, 2);
				    close(s);
			   }
		  }
		  if ((fp = fopen(ACTFILE, "w")) == NULL)
		  {
			   sleep(timer);
			   continue;
		  }
		  switch (bbs)
		  {
		      case 1:
			   fprintf(fp, "FORMOSA BBS: [1;33m140.117.11.2[m , SOUTH BBS: [1;33m140.117.11.4[m , WEST BBS: [1;33m140.117.11.6[m\n");
			   fprintf(fp, "FORMOSA BBS �u�W�H�� [[1m%d[m] , SOUTH BBS �u�W�H�� [[1m%d[m] , WEST BBS �u�W�H�� [[1m%d[m]\n", act[0], act[1], act[2]);
			   break;
		      case 2:
			   fprintf(fp, "SOUTH BBS: [1;33m140.117.11.4[m , WEST BBS: [1;33m140.117.11.6[m , FORMOSA BBS: [1;33m140.117.11.2[m\n");
			   fprintf(fp, "SOUTH BBS �u�W�H�� [[1m%d[m] , WEST BBS �u�W�H�� [[1m%d[m] , FORMOSA BBS �u�W�H�� [[1m%d[m]\n", act[1], act[2], act[0]);
			   break;
		      case 3:
			   fprintf(fp, "WEST BBS: [1;33m140.117.11.6[m , SOUTH BBS: [1;33m140.117.11.4[m , FORMOSA BBS: [1;33m140.117.11.2[m\n");
			   fprintf(fp, "WEST BBS �u�W�H�� [[1m%d[m] , FORMOSA BBS �u�W�H�� [[1m%d[m] , SOUTH BBS �u�W�H�� [[1m%d[m]\n", act[2], act[0], act[1]);
			   break;
		  }

		  fprintf(fp, "�`�u�W�H�� : [[1;33m%d[m], FORMOSA CLIENT �ϥΤH�� [[1;33m%d[m]\n", act[0] + act[1] + act[2], csbbs[0] + csbbs[1] + csbbs[2]);
		  fclose(fp);
		  sleep(timer);
	 }
}
