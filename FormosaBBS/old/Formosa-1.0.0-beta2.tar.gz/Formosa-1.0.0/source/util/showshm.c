
#include "bbs.h"
#include "shm.h"


struct UTMPFILE *utmpshm;	/* �����ϥΪ� USER_INFO ���� */

#include <sys/ipc.h>
#include <sys/shm.h>


void
attach_err(shmkey, name)
int     shmkey;
char   *name;
{
	fprintf(stderr, "[%s error] key = %d\n", name, shmkey);
#if 0
	bbslog("ERROR", "[%s error] key = %d", name, shmkey);	/* lasehu */
#endif	
	exit(1);
}


void   *
attach_shm(shmkey, shmsize)
key_t   shmkey;
int     shmsize;
{
	void   *shmptr;
	int     shmid;

	shmid = shmget(shmkey, shmsize, 0);
	if (shmid < 0)
	{
		shmid = shmget(shmkey, shmsize, IPC_CREAT | 0600);
		if (shmid < 0)
			attach_err(shmkey, "shmget");
		shmptr = (void *) shmat(shmid, NULL, 0);
		if (shmptr == (void *) -1)
			attach_err(shmkey, "shmat");
		memset(shmptr, 0, shmsize);
	}
	else
	{
		shmptr = (void *) shmat(shmid, NULL, 0);
		if (shmptr == (void *) -1)
			attach_err(shmkey, "shmat");
	}
	return (void *) shmptr;
}


#include "shm.h"

struct UTMPFILE *utmpshm = NULL;	/* �����ϥΪ� USER_INFO ���� */

void
resolve_utmp()
{
	if (utmpshm == NULL)
	{
		utmpshm = attach_shm(UTMPSHM_KEY, sizeof(*utmpshm));
		if (utmpshm->uptime == 0)
		{
			utmpshm->uptime = 1;
			utmpshm->number = 0;
		}
	}
}




show_ulist()		/* ? */
{
    register USER_INFO *uentp;
    register int i;

    resolve_utmp();
    uentp = utmpshm->uinfo;
    
#if 1
    printf("\nkey = [%d]", UTMPSHM_KEY);
    printf("\nsize = [%d]", USHM_SIZE);
#endif        
    for (i = 0; i < USHM_SIZE; i++, uentp++)
    {
#if 0    
	if (uentp->pid < 2 || uentp->userid[0] == '\0')
	    continue;
#endif	    
#if 0
	if (uentp->active <= 0) /* lasehu ? */
	    continue;
#endif
#if 0
	if (kill(uentp->pid, 0) == -1 && errno == ESRCH)	/* pid not exist */
	    continue;
#endif	    
	if (uentp->userid[0] == '\0' || uentp->pid == 0)
	    continue;
	printf("\n%d. [%s] [%d] [%d] %d", i, uentp->userid, uentp->uid, uentp,
uentp->pid);
    }
    printf("\n\nTotal: [%d]\n", utmpshm->number);
    return 0;
}


void
main()
{
	show_ulist();
}	
