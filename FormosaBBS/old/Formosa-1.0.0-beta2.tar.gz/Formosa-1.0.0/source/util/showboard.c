/*******************************************************************
 * ��ܩҦ��ݪO�M��
 *******************************************************************/

#include "bbs.h"


#define BHSIZE	(sizeof(struct boardheader))


struct boardheader *allbrd = NULL;


int
board_cmp(a, b)
struct boardheader *a, *b;
{
    return (strcasecmp(a->filename, b->filename));
}


void
main(argc, argv)
int     argc;
char   *argv[];
{
    int     inf, i, count;
    struct stat st;

    if (argc < 2)
    {
	printf("Usage:\t%s [.BOARDS]\n", argv[0]);
	exit(1);
    }

    if ((inf = open(argv[1], O_RDONLY)) < 0)
    {
	printf("error open file\n");
	exit(1);
    }

    if (fstat(inf, &st) == -1 || st.st_size % BHSIZE != 0)
    {
	printf("error read file\n");
	exit(2);
    }

    allbrd = (struct boardheader *) malloc(st.st_size);
    if (allbrd == NULL)
    {
	printf("cannot malloc memory !!\n");
	exit(3);
    }
#if 1
    printf("here 1");
fflush(stdout);
#endif    
 /* read in all boards */

    i = 0;
    memset(allbrd, 0, st.st_size);

    while (read(inf, &allbrd[i], BHSIZE) == BHSIZE)
    {
	if (allbrd[i].filename[0])
	    i++;
    }
    close(inf);

 /* sort them by name */

    count = i;
    qsort(allbrd, count, BHSIZE, board_cmp);

 /* write out the target file */

    printf(
	   "     �ݪO�W��     �O�D                     ���O   ����ԭz\n"
	   "---------------------------------------------------------------------------\n");
    for (i = 0; i < count; i++)
    {
#if 1    
        if (strchr(allbrd[i].filename, ' '))
            printf("found bname!\n");
        if (allbrd[i].type == ' ')
            printf("found type!\n");            
        if (strchr(allbrd[i].owner, ' '))
            printf("found owner(%s)!\n", allbrd[i].owner);            
#endif            
	printf("<%d>[%-18.18s] [%-14.14s] [%1.1c] [%s]\n", allbrd[i].bid, allbrd[i].filename, allbrd[i].owner, allbrd[i].type, allbrd[i].title);
    }
}
