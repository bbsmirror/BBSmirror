

#include "bbs.h"
#include "status.h"


int     csbbs = 0, talk = 0, tmenu = 0, user = 0, 
	chat = 0, post = 0, mail = 0, other = 0;

#ifdef DEBUG
int     mode, mcount = 0;

#endif


count_umode_kind(upent)
USER_INFO *upent;
{
	int     u = upent->mode;

#ifdef DEBUG
	if (mode && upent.mode == mode)
		mcount++;
#endif
	if (upent->pid < 2)
		return;

	if (upent->mode == CLIENT || upent->c_type == CTYPE_CSBBS)
		csbbs++;
	else if (u == TALK || u == PAGE /* || u == QUERY */ )
		talk++;
	else if (u == LUSERS || u == LFRIENDS)
		user++;
	else if (u == TMENU)
		tmenu++;
	else if (u == SMAIL || u == RMAIL || u == MAIL)
		mail++;
	else if (u == READING || u == POSTING || u == MODIFY 
		 || u == SELECT || u == BOARDS_MENU || u == CLASS_MENU)
	{
		post++;
	}
	else if (u == CHATROOM || u == IRCCHAT || u == LOCALIRC)
		chat++;
	else
		other++;
	return;
}


void
main(argc, argv)
int     argc;
char   *argv[];
{
	FILE   *fp;
	char listfile[80];


#ifdef DEBUG
	if (argc > 1)
		mode = atoi(argv[1]);
	else
		mode = 0;
#endif

	resolve_utmp();
	apply_ulist(count_umode_kind);

	sprintf(listfile, "%s/%s", HOMEBBS, PATH_STATUS_LIST);
	if ((fp = fopen(listfile, "a")) != NULL)
	{
		fprintf(fp, "%d %d %d %d %d %d %d %d\n",
			talk, tmenu, user, chat, post, mail, csbbs, other);
#ifdef DEBUG
		if (mode)
			printf("\nmode<%d> [%d]\n", mode, mcount);
#endif
		fclose(fp);
	}
}
