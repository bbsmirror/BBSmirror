
#include "bbs.h"

#undef DEBUG

void
main()
{
    int fd;
    struct boardheader buf_bh;
    char odir[40];
    char ori[PATHLEN], new[PATHLEN];
    int fdr, fdw;
    char buf[4096];
    int cc, fsize = 0;
    struct stat st;
    
    getcwd(odir, sizeof(odir));    
    if (getuid() != BBS_UID)
    {
	if (chroot(HOMEBBS) || chdir("/"))
	{
	    printf("\n\n!!! �Х� root �� bbs �Ӱ��楻�{�� !!!\n");
	    exit(-1);
	}
	setgid(BBS_GID);
	setuid(BBS_UID);
    }
    else
    {
        if (chdir(HOMEBBS) == -1)
        {
            printf("\n\n!!! BBS Home Directory not exist !!!\n");
            exit(-1);
        }
    }
    
    if ((fd = open(BOARDS, O_RDONLY)) < 0)
    {
	printf("\nCannot open [%s] !\n", BOARDS);
	chdir(odir);	
	exit(-1);
    }    
    
    while (read(fd, &buf_bh, BHSIZE) == BHSIZE)
    {
	if (buf_bh.owner[0] == '\0')
	    continue;
	sprintf(ori, "%s/%s/.%s", BBSPATH_BOARDS, buf_bh.filename, buf_bh.owner);
	sprintf(new, "%s/%s/%s", BBSPATH_BOARDS, buf_bh.filename, BM_WELCOME);
#ifdef DEBUG
	printf("\nconvert [%s] to [%s]", ori, new);
#else		
	if ((fdr = open(ori, O_RDONLY)) > 0)
	{
	    if (stat(new, &st) == 0)
	        fsize = st.st_size;
	    if ((fdw = open(new, O_WRONLY | O_CREAT | O_APPEND, 0644)) > 0)
	    {
	    	if (fsize > 0)
	    	    write(fdw, "\n", 1);
		    while ((cc = read(fdr, buf, sizeof(buf))) > 0)
		    {
			if (write(fdw, buf, cc) != cc)
			{
			    printf("\nCannot write [%s] !", new);
			    break;
			}
		    }
	        close(fdw);
	    }
	    close(fdr);
	}
	unlink(ori);
#endif	    
    }	    
    close(fd);
}    
