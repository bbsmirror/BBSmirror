
#define _BBS_LOCAL_UTIL_


#include "bbs.h"


void
main(argc, argv)
int    argc;
char  *argv[];
{
    int    fd;
    char   userid[IDLEN + 2];
    struct useridx uidx;
    int    cnt;

    if (argc < 3)
    {
	fprintf(stderr, "syntax :\n %s  [userid]\n", argv[0]);
	exit(0);
    }

    strcpy(userid, argv[1]);

    if ((fd = open(HOMEBBS USERIDX, O_RDONLY)) < 0)
    {
	printf("\nError: cannot open %s \n", HOMEBBS USERIDX);
	exit(0);
    }

    cnt = 0;
    printf("Searching %s's Data ...", userid);
    while (read(fd, &uidx, sizeof(uidx)) == sizeof(uidx))
    {
	cnt++;
	if (!strcmp(uidx.userid, userid))
	{
	    printf("Found !");
	    printf("\n---[%d]---------------------------------------------\n", cnt);
	    printf(" userid : %s\n", uidx.userid);
	    printf("-----------------------------------------------------------\n");
	    close(fd);
	    return;
	}
    }
    printf("Not Found !\n");
    close(fd);
}
