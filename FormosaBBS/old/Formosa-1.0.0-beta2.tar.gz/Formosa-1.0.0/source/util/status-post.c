

#include "bbs.h"
#include "status.h"


#define PATH_STATUS_REPORT	"tmp/status.rpt"


int     debug = 0;


void
main(argc, argv)
int     argc;
char   *argv[];
{
	int     talk = 0, tmenu = 0, user = 0, chat = 0, 
		post = 0, mail = 0, csbbs = 0, other = 0;
	FILE   *fp;
	char    fname[STRLEN], title[STRLEN], postpath[STRLEN],
		bname[STRLEN], reportfile[STRLEN];
	int     count = 0;
	time_t  now = time(0);
	int     m_t = 0, m_tm = 0, m_us = 0, m_c = 0, m_p = 0, 
		m_m = 0, m_cs = 0, m_o = 0, m_total = 0;
	FILE   *fp_logins;
	char    buf[4096];
	int     t = talk / count, tm = tmenu / count, us = user / count,
	        c = chat / count, p = post / count, m = mail / count, cs = csbbs / count,
	        o = other / count;
	int     total = t + tm + us + c + p + m + cs + o;
	short   result;

	if (argc != 2)
	{
		fprintf(stderr, "\nsyntax: %s [boardname]\n", argv[0]);
		exit(-1);
	}

	strcpy(bname, argv[1]);
	if (bname[0] == '\0')
	{
		fprintf(stderr, "\nboardname error!\n");
		exit(-1);
	}

	sprintf(buf, "%s/%s", HOMEBBS, PATH_STATUS_LIST);
	if ((fp = fopen(buf, "r")) != NULL)
	{
		int     t, tm, us, c, p, m, cs, o;

		while (fscanf(fp, "%d %d %d %d %d %d %d %d\n", &t, &tm, &us, &c, &p, &m, &cs, &o) != EOF)
		{
			count++;
			printf("%d %d %d %d %d %d %d %d\n", t, tm, us, c, p, m, cs, o);
			talk += t;
			tmenu += tm;
			user += us;
			chat += c;
			post += p;
			mail += m;
			csbbs += cs;
			other += o;
			if (t > m_t)
				m_t = t;
			if (tm > m_tm)
				m_tm = tm;
			if (us > m_us)
				m_us = us;
			if (c > m_c)
				m_c = c;
			if (p > m_p)
				m_p = p;
			if (m > m_m)
				m_m = m;
			if (cs > m_cs)
				m_cs = cs;
			if (o > m_o)
				m_o = o;
			if ((t + tm + us + c + p + m + cs + o) > m_total)
				m_total = t + tm + us + c + p + m + cs + o;
		}
		fclose(fp);
	}

	sprintf(reportfile, "%s/%s", HOMEBBS, PATH_STATUS_REPORT);
	if ((fp = fopen(reportfile, "w")) == NULL)
	{
		fprintf(stderr, "\ncannot write to file: %s\n", reportfile);
		exit(-1);
	}

	t = talk / count;
	tm = tmenu / count;
	us = user / count;
	c = chat / count;
	p = post / count;
	m = mail / count;
	cs = csbbs / count;
	o = other / count;
	total = t + tm + us + c + p + m + cs + o;

	if (total == 0)
		total = 1;
	if (count == 0)
		count = 1;

	printf("\nTotal: %d\n", total);
	
	fprintf(fp, "�o�H�H�G SYSOP (�t�κ޲z��)    �ݪO�G%s", bname);
	fprintf(fp, "\n����G %s", ctime(&now));
	fprintf(fp, "���D�G %s �έp��T", BBSNAME);
	fprintf(fp, "\n\n\n--- [%s]�u�W�ϥα��βέp ---- �C�T�������ˤ@��\n\n�ɶ�: %s", BBSNAME, ctime(&now));
	fprintf(fp, "\n   �ͤ߶���    : %3d �H, %3.1f%%, Max %3d �H", t, (float) (t * 100) / total, m_t);
	fprintf(fp, "\n   �͸ܿ��    : %3d �H, %3.1f%%, Max %3d �H", tm, (float) (tm * 100) / total, m_tm);
	fprintf(fp, "\n   �d�u�W�H    : %3d �H, %3.1f%%, Max %3d �H", us, (float) (us * 100) / total, m_us);
	fprintf(fp, "\n   ��ѫ�      : %3d �H, %3.1f%%, Max %3d �H", c, (float) (c * 100) / total, m_c);
	fprintf(fp, "\n   �G�i�\\��    : %3d �H, %3.1f%%, Max %3d �H", p, (float) (p * 100) / total, m_p);
	fprintf(fp, "\n   �H��\\��    : %3d �H, %3.1f%%, Max %3d �H", m, (float) (m * 100) / total, m_m);
	fprintf(fp, "\n   �D�q���\\����: %3d �H, %3.1f%%, Max %3d �H", cs, (float) (cs * 100) / total, m_cs);
	fprintf(fp, "\n   �䥦�\\��    : %3d �H, %3.1f%%, Max %3d �H", o, (float) (o * 100) / total, m_o);
	fprintf(fp, "\n-----------------------------------------------\nonline average : %d �H, Max %3d �H", total, m_total, m_total);

	sprintf(buf, "%s/%s", HOMEBBS, PATH_VISITOR_LOG);
	if ((fp_logins = fopen(buf, "r")) != NULL)
	{
		while (fgets(buf, sizeof(buf), fp_logins))
			fprintf(fp, "%s", buf);
		fclose(fp_logins);
	}
	fclose(fp);
	
#ifdef DEBUG	
	printf("\n ok");
#endif	
	
	strncpy(fname, ctime(&now) + 4, 6);
	fname[6] = '\0';

	sprintf(title, "[�έp] %s %s �u�W�έp", BBSNAME, fname);
	sprintf(buf, "%s/%s", HOMEBBS, PATH_STATUS_REPORT);

	sprintf(postpath, "%s/%s/%s", HOMEBBS, BBSPATH_BOARDS, bname);
	result = append_article(reportfile, postpath, "SYSOP", title, 7, NULL, YEA);
#ifdef DEBUG
	if (result == -1)	
		printf("\n�i�K����.\n");
	else
		printf("\n�i�K����.\n");
#endif		
}


