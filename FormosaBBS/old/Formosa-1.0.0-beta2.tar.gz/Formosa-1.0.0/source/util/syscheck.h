#define B_RED    "[41m"
#define B_GREEN  "[42m"
#define B_BROWN  "[43m"
#define B_BLUE   "[44m"
#define B_PINK   "[45m"
#define B_CYLN   "[46m"
#define B_WHITE  "[47m"

#define H_RED    "[1;31m"
#define H_GREEN  "[1;32m"
#define H_YELLOW "[1;33m"
#define H_BLUE   "[1;34m"
#define H_PINK   "[1;35m"
#define H_CYLN   "[1;36m"
#define H_WHITE  "[1;37m"

#define RED    "[31m"
#define GREEN  "[32m"
#define BROWN  "[33m"
#define BLUE   "[34m"
#define PINK   "[35m"
#define CYLN   "[36m"
#define WHITE  "[37m"

#define NORMAL "[m"


#define CONX 48
#define LOGX 60
#define TTYX 70
