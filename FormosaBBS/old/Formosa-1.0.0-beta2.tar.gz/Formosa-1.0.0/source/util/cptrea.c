

#include "bbs.h"
#include "boardrc.h"

#define TREA_REC	".TREA"

struct big_fileheader {			/* This structure is used to hold data in */
        char filename[STRLEN-4-4];
        int  artno;			/* lasehu: �G�i�s�� */
	char owner_ident;		/* Record if Register or .... */
	char class;		/* ? */
	char type;		/* ? */
	char region;		/* unused */
	char owner[STRLEN] ;
	char title[STRLEN] ;
	unsigned int level;	/* ? */
	unsigned char accessed[10000] ;/* ? */
} ;


void
main()
{
    int fin, fout;
    char treahead[STRLEN];
    struct fileheader fh;
    struct big_fileheader bfh;
    int artno, i;
    char odir[30];

    if ((fin = open(TREA_REC, O_RDONLY)) < 0)
	exit(-1);
   
    getcwd(odir, sizeof(odir));

    i = 1;
    while (read(fin, treahead, sizeof(treahead)) == sizeof(treahead))
    {
        memset(&fh, 0, sizeof(fh));
	fh.accessed |= FILE_TREA;
	strcpy(fh.title, treahead);
	
        strcpy(fh.filename, 
	rename(i, fh.filename);
	i++;

	if (write(fout, &fh, sizeof(fh)) != sizeof(fh))
	{
	    printf("\nError: cannot write file: [%s]\n", DIR_REC);
	    break;
	}
    }

    artno = 1;
    while (read(fin, &bfh, sizeof(bfh)) == sizeof(bfh))
    {
        memset(&fh, 0, sizeof(fh));
	strcpy(fh.title, bfh.title);
        strcpy(fh.filename, bfh.filename); 
	fh.artno = artno++;
	if (artno > BRC_REALMAXNUM)
	    atrno = 1;
	if (write(fout, &fh, sizeof(fh)) != sizeof(fh))
	{
	    printf("\nError: cannot write file: [%s]\n", DIR_REC);
	    break;
	}
    }

    close(fin);
    close(fout);
}
	

    

