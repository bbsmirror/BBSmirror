/*******************************************************************
 * .DIR �M�z�B���@	 			 	 
 *******************************************************************/

#define _BBS_LOCAL_UTIL_


#include "bbs.h"
#include <stdlib.h>


#undef DEL_EMPTY_FILE


char    mode;


clear_dir(dir)
char  *dir;
{
    char   buf[128];
    DIR   *dirp;
#ifdef NO_DIRENT    
    struct direct *dp;
#else
    struct dirent *dp;
#endif        
    int    fin, fout;
    struct stat st;
    char   table[15000][20];
    int    i, total;
    int    prune_files;
    char  *hit;
    FILEHEADER fh;
    int    not_found_records, artno;

    chdir(dir);
#ifdef MYDEBUG
    printf("\nChange Directory to [%s]\n", dir);
#endif

/* build filename table & sort */

    if ((dirp = opendir(".")) == NULL)
	return -1;

    total = 0;
    while ((dp = readdir(dirp)) != NULL)
    {
	if (!strcmp(dp->d_name, ".") || !strcmp(dp->d_name, ".."))
	    continue;

	if (stat(dp->d_name, &st) == -1 || st.st_size == 0)
	{
#ifdef DEL_EMPTY_FILE
	    unlink(dp->d_name);
	    continue;
#else
	    strcpy(table[total], dp->d_name);
	    table[total][19] = 'd';
#endif
	}
	else if (S_ISDIR(st.st_mode))
	{
#ifdef MYDEBUG
	    printf("\ndirectory [%s]", dp->d_name);
#endif
	    strcpy(table[total], dp->d_name);
	    table[total][19] = 'p';
	}
	else
	{
	    strcpy(table[total], dp->d_name);
	    table[total][19] = 'a';
	}
	total++;
    }
    closedir(dirp);


    if ((fin = open("./" DIR_REC, O_RDWR | O_CREAT, 0644)) == -1)
    {
	printf("\t.DIR open error\n");
	return -1;
    }
#ifndef DEBUG
    if ((fout = open(".DIR.new", O_WRONLY | O_CREAT | O_TRUNC, 0644)) == -1)
    {
	printf("\t.DIR.new open error\n");
	return -1;
    }
#endif

    qsort(table, total, 20, strcmp);

    fstat(fin, &st);
    printf("\tTotal: %d records, %d files\n\tprune: ",
	   st.st_size / FH_SIZE, total);

/* read original .DIR */

    not_found_records = 0;

    artno = 1;	/* article no. */
    while (read(fin, (char *) &fh, FH_SIZE) == FH_SIZE)
    {
 /* binary search : check consistency */

	if ((hit = (char *) bsearch(&fh, table, total, 20, strcmp)))
	{
	    if (hit[19] == 'p')
		fh.accessed |= FILE_TREA;
	    else
	    {
	    	fh.accessed &= ~FILE_TREA;	/* lasehu */
	    	fh.accessed &= ~FILE_IN;	/* lasehu */
	    	fh.accessed &= ~FILE_OUT;	/* lasehu */
	        fh.artno = artno++;
	        if (artno >= BRC_REALMAXNUM)
	            artno = 1;
	    }
#ifndef DEBUG
	    write(fout, &fh, FH_SIZE);
#endif
	    hit[19] = 'z';
	}
	else
	    not_found_records++;
    }
    close(fin);

    printf("%d records, ", not_found_records);

/* prune dummy file */


    artno = 1;
    for (i = prune_files = 0; i < total; i++)
    {
	if (table[i][19] == 'z')
	    continue;

	if (mode == 'c' || mode == 't')
	{
	    myunlink(table[i]);
	    prune_files++;
	    continue;
	}

	if (table[i][19] == 'p')
	{
	    memset(&fh, 0, FH_SIZE);
	    strcpy(fh.filename, table[i]);
	    strcpy(fh.title, "Lost Directory");
	    fh.accessed |= FILE_TREA;
	    write(fout, &fh, FH_SIZE);
	}
	else
	{
	    FILE  *fp;
	    char  *p;

	    memset(&fh, 0, FH_SIZE);
	    strcpy(fh.filename, table[i]);
	    if ((fp = fopen(fh.filename, "r")) == NULL)
		continue;
	    while (fgets(buf, sizeof(buf), fp))
	    {
		if (((p = strstr(buf, "�o�H�H:")) && (p = p + 7))
		    || ((p = strstr(buf, "�o�H�H�G")) && (p = p + 8))
		    || ((p = strstr(buf, "By:")) && (p = p + 3))
		    || ((p = strstr(buf, "From:")) && (p = p + 5)))
		{
		    while (*p == ' ')
			p++;
		    if (*p != '\n')
		    {
			char *br;
	
			if ((br = strchr(p, '<')) != NULL && *(br + 1))	
			   p = br + 1; 	
			strtok(p, " >");
			strcpy(fh.owner, p);
#ifdef MYDEBUG
		printf("\nowner[%s]", fh.owner);
#endif
		    }
		}
		else if (((p = strstr(buf, "���D:")) && (p = p + 5))
		     || ((p = strstr(buf, "���D�G")) && (p = p + 6))
		     || ((p = strstr(buf, "Title:")) && (p = p + 6))
		  || ((p = strstr(buf, "Subject:")) && (p = p + 8)))
		{
		    while (*p == ' ')
			p++;
		    if (*p != '\n')
		    {
			strtok(p, "\n");
			strcpy(fh.title, p);
		    }
		}
		else if (buf[0] == '\n')
		    break;
	    }		
	    if (fh.owner[0] != '\0')
	    {
	    	fh.artno = artno++;
	        if (artno >= BRC_REALMAXNUM)
	            artno = 1;		    	
#ifndef DEBUG
		write(fout, &fh, FH_SIZE);
#endif
	    }
#ifdef MYDEBUG
	    else
	    {
#ifdef MYDEBUG
		printf("\nrm %s/%s", dir, fh.filename);
#endif		
#if 0
	        fh.accessed |= FILE_IN;
		write(fout, &fh, FH_SIZE);
#endif		
	    }
#endif
	    fclose(fp);
	}
    }
#ifndef DEBUG
    close(fout);
#endif

    printf("%d files\n", prune_files);

#ifndef DEBUG
    rename(".DIR.new", "./" DIR_REC);
#endif
    chown("./" DIR_REC, BBS_UID, BBS_GID);
}


main(argc, argv)
int    argc;
char  *argv[];
{
#ifdef NO_DIRENT
    struct direct *de;
#else
    struct dirent *de;
#endif        
    DIR   *dirp;
    char   pathname[256], *ptr, buf[256];
    char   t_dir[80];
    char   prog[30];
    int   c;

    extern char *optarg;

    strcpy(prog, argv[0]);
    if (argc < 3)
    {
      syntaxerr:
	printf("\nUsage:\t%s [-c pathname] [-r pathname] [-t mail/board] [-b mail/board]\n", prog);

	printf("\n\
\t -c clean trash file\n\
\t -r rebuild file\n\
\t -t clean all\n\
\t -b rebuild all\n");

	printf("\nexample:\n\
\t -t /bbs/mail \n\
\t -t /bbs/board \n\
\t -b /bbs/mail \n\
\t -b /bbs/board \n\
\t -c /bbs/boards/test\n\
\t -r /bbs/mail/sysop\n");

	exit(-1);
    }

    while ((c = getopt(argc, argv, "t:b:c:r:")) != -1)
    {
	switch (c)
	{
	    case 't':
	    case 'b':
	    case 'c':
	    case 'r':
		break;
	    case '?':
	    default:
		goto syntaxerr;
	}
	mode = c;
	strcpy(pathname, optarg);
    }

    getcwd(t_dir, sizeof(t_dir) - 1);

    switch (mode)
    {
	case 't':
	case 'b':
	    sprintf(buf, "/%s", pathname);
	    if ((dirp = opendir(buf)) == NULL)
	    {
		printf("Error: unable to open %s\n", buf);
		return;
	    }

	    ptr = buf + strlen(buf);
	    *ptr++ = '/';

	    while (de = readdir(dirp))
	    {
		if (de->d_name[0] > ' ' && de->d_name[0] != '.')
		{
		    strcpy(ptr, de->d_name);
#ifdef MYDEBUG
		    printf("\nclean directory [%s]\n", buf);
#endif
		    clear_dir(buf);
		}
	    }

	    closedir(dirp);

	    break;
	case 'c':
	case 'r':
#ifdef MYDEBUG
	    printf("\nclean one directory [%s]\n", pathname);
#endif
	    ptr = pathname + strlen(pathname);
	    *ptr++ = '/';
	    *ptr = '\0';

	    clear_dir(pathname);

	    break;
    }

    chdir(t_dir);
}
