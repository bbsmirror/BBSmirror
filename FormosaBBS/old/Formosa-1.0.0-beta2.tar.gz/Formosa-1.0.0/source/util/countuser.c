/*******************************************************************
 * �ΰO�Ҧ����U�ϥΪ̪��W�u�ӷ�
 *******************************************************************/
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/file.h>

#include "config.h"
#include "struct.h"

#define _GET_VAR_
#include "util.c"


char     genbuf[4096];
int      nodef = 0;


struct Count
{
    char     ip[16];
    char     host[80];
    unsigned int cnt;
    int      len;
    struct Count *next;
}       *cutop = NULL, *cucur;


int 
create_host_list()
{
    FILE    *fp;
    struct Count *new;
    char    *p;

    if ((fp = fopen("/apps/bbs/.hostlist", "r")) == NULL)
	return -1;
    while (fgets(genbuf, 80, fp))
    {
	new = (struct Count *) malloc(sizeof(struct Count));
	p = (char *) get_var(genbuf, new->ip, 16);
	get_var(p, new->host, 80);
	new->cnt = 0;
	new->len = strlen(new->ip);
	new->next = NULL;
	if (cutop)
	{
	    cucur->next = new;
	    cucur = new;
	}
	else
	    cutop = cucur = new;
#ifdef	DEBUG
	printf("ip:[%s] host:[%s] cnt:[%d] len:[%d]\n",
	       cucur->ip, cucur->host, cucur->cnt, cucur->len);
#endif
    }
    fclose(fp);
    return 0;
}

void 
countuser(host)
char    *host;
{
#ifdef	DEBUG
    printf("[%s] ", host);
#endif
    for (cucur = cutop; cucur != NULL; cucur = cucur->next)
	if (!strncmp(host, cucur->ip, cucur->len))
	{
	    cucur->cnt++;
#ifdef	DEBUG
	    printf(" ip[%s] h[%s] cnt[%d]\n",
		   cucur->ip, cucur->host, cucur->cnt);
#endif
	    return;
	}
    nodef++;
#ifdef	DEBUG
    printf("���w�q\n");
#endif
    return;
}

void 
main()
{
    int      fd;
    FILE    *fp;
    struct userec user;

    if (create_host_list())
	exit(-1);
    sprintf(genbuf, "%-s/%-s", HOMEBBS, PASSFILE);
    if ((fd = open(genbuf, O_RDONLY)) < 0)
	exit(-1);
    while (read(fd, &user, sizeof(user)) == sizeof(user))
    {
	if (*user.userid == '\0' || *user.lasthost == '\0')
	    continue;
	countuser(user.lasthost);
    }
    close(fd);
    sprintf(genbuf, "%-s/CountUser", HOMEBBS);
    if ((fp = fopen(genbuf, "w")) != NULL)
    {
	chmod(genbuf, 0644);
	for (cucur = cutop; cucur != NULL; cucur = cucur->next)
	    fprintf(fp, "�H��:[ %5d ]  %s  %s\n", cucur->cnt, cucur->ip, cucur->host);
	fprintf(fp, "�H��:[ %5d ]  ���w�q\n", nodef);
	fclose(fp);
    }
}
