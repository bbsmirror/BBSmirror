/*
   �D�{��
                       �i²�ݤ�   changiz@cc.nsysu.edu.tw
*/
#include "bbs.h"
#include "syscheck.h"
#include <varargs.h>


char    gbuf[2048];
struct userec IUser;
struct fileheader Ifh;
int debug = 0;

void title();
char cgetch();

void
main()
{
	char    name[20] = {"asdas"};
	char   *tmp = &(name[0]);

	s_init();
	k_init();

	s_clear();

	set_color(B_GREEN);
	set_color(H_YELLOW);
	s_box(0, 0, 79, 23);
	s_pr(5, 22, "CTRL-X: ���}   CTRL-H: �R���@�r��");
	set_color(B_CYLN);
	s_box(5, 1, 69, 3);
	set_color(B_BLUE);
	set_color(H_WHITE);
	s_pr(8, 1, " �R�O�� ");

	title();
	set_color(NORMAL);

	set_color(B_CYLN);
	set_color(H_WHITE);
	
	if (chdir(HOMEBBS) == -1)
	{
		s_pr(7, 3, "�L�k�}�� BBS �D�ؿ�!! ");		
		exit(-1);
	}
	
	s_pr(7, 3, "�d�߭���ϥΪ̪����: ");
	while (s_gets(&tmp, 29, 3, 20) != -1)
	{
		if (Get_User(tmp) == -1)
		{
			set_color(H_YELLOW);
			set_color(B_WHITE);
			s_pr(7, 7, "�d�L���H���.....   �����N���~��");
			cgetch();
		}
		title();
		set_color(B_CYLN);
		set_color(H_WHITE);
		s_pr(7, 3, "�d�߭���ϥΪ̪����: ");
	}
	set_color(NORMAL);
	exit(0);
}



void 
title()
{
	set_color(H_YELLOW);
	set_color(B_WHITE);
	s_box(5, 6, 69, 14);
	set_color(B_BLUE);
	set_color(H_WHITE);
	s_pr(8, 6, " �������� ");
}


int 
Get_User(user)
char   *user;
{
	struct fileheader rec;
	int     f;
	FILE   *f2;
	char    buf[200];
	char    file[200];
	char    flag = 0;
	char    fname[255];

	sprintf(fname, "%s/ID/%s", HOMEBBS, DIR_REC);
	f = open(fname, O_RDONLY);
	while (read(f, &rec, sizeof(rec)) == sizeof(rec))
	{
		if (!strcmp(rec.owner, user))
		{
			sprintf(file, "%s/ID/%s", HOMEBBS, rec.filename);
			if ((f2 = fopen(file, "r")) == NULL)
				continue;
			set_color(H_WHITE);
			set_color(B_WHITE);
			while (fgets(buf, 80, f2) != NULL)
			{
				if (strcmp(buf, "\n") == 0)
					continue;
				s_pr(7, 7 + flag, buf);
				flag++;
			}
			set_color(B_CYLN);
			set_color(H_WHITE);
			s_pr(7, 3, "�n�n�����H��ƶ�[N]:        ");
			if ((cgetch() | 32) == 'y')
			{
			/* pgp_.. need to change */
				s_clear();
				if (pgp_encode(rec.owner, rec.filename) != -1)
				{
					set_color(B_GREEN);
					set_color(H_YELLOW);
					s_box(0, 0, 79, 23);
					s_pr(5, 22, "CTRL-X: ���}   CTRL-H: �R���@�r��");
					set_color(B_CYLN);
					s_box(5, 1, 69, 3);
					set_color(B_BLUE);
					set_color(H_WHITE);
					s_pr(8, 1, " �R�O�� ");
					title();
					set_color(H_YELLOW);
					set_color(B_WHITE);
					s_pr(7, 7, "�n������.....   �����N���~��");
					cgetch();
				}
			}
			fclose(f2);
			break;
		}
	}
	close(f);
	if (flag != 0)
		return 0;
	return -1;
}



int 
a_encode(file1, file2, file3)
char   *file1, *file2, *file3;
{
	struct stat st;

	mycp(file1, file2);
	if (debug == 1)
		printf("file: %s\n", file2);
	sprintf(gbuf, "%s/bin/pgp -e %s \"west&south&formosa\"", HOMEBBS, file2);
	if (debug == 1)
		printf("command: %s\n", gbuf);
#if 0		
	system(gbuf);
	sprintf(gbuf, "%s.pgp", file2);
#endif
#if 1
	sprintf(gbuf, "%s", file2);	
#endif	
	if (debug == 1)
		printf("pgp: %s\n", file2);
	if (stat(gbuf, &st) == 0)
	{			/* If encode success */
		mycp(gbuf, file3);
		myunlink(gbuf);
	}
	myunlink(file2);

	return 0;
}


int 
do_article(fname, path, owner, title)
char   *fname, *path, *owner, *title;
{
	char   *p;
	int     fd;

	if (mycp(fname, path))
		return -1;
	p = rindex(path, '/') + 1;
	bzero(&Ifh, sizeof(Ifh));
	strcpy(Ifh.filename, p);
	strcpy(Ifh.owner, owner);
	strcpy(Ifh.title, title);
	strcpy(p, ".DIR");
	fd = open(path, O_WRONLY | O_CREAT | O_APPEND, 0644);
	strcpy(p, Ifh.filename);
	flock(fd, LOCK_EX);
	write(fd, &Ifh, sizeof(Ifh));
	flock(fd, LOCK_UN);
	close(fd);
	return 0;
}


int 
a_ok(name, cond)		/* write check level */
char    name[15];
char    cond;
{
	int     f;

	if ((f = get_passwd(&IUser, name)) <= 0)
		return;
	IUser.ident = cond;
#ifdef MULTIBBS	
	net_update_user(&IUser, IUser.passwd);
#endif	
	update_user(&IUser);
}


int 
pgp_encode(user, file)
char   *user;
char   *file;
{
	char    destfile[80];
	char    srcfile[80];
	char    title[80];
	char    buf[200];
	struct stat st;

	sprintf(srcfile, "%s/ID/%s", HOMEBBS, file);
	a_ok(user, 7);		/* Get IUser */
	sprintf(destfile, "%s/realuser/%s", HOMEBBS, user);
	sprintf(title, "�����T�{: %s", user);
	if (stat(destfile, &st) == -1)
		do_article(srcfile, destfile, user, title);
	sprintf(buf, "/tmp/%sPGP", IUser.userid);
	a_encode(srcfile, buf, destfile);
	return 0;
}

/* 
   �H�U�O�B�z�e�����, �ο��\��, �ϥ� curses
*/


/*
   ���Ƶ{���O�q�@��game�ۨӪ�, ���Fcgetch , kbhit���O�ڥ[�J���~
   �j�����O�O�H��; �o�̥D�n�O�ù��P��L��function.
                                           changiz@cc.nsysu.edu.tw
*/

#include <termio.h>
/*#include <term.h>*/
#include <curses.h>


static char *st_smkx;
static char *st_rmkx;
static char *st_cup;
static char *st_clear;
static char *st_enacs;
static char *st_smacs;
static char *st_rmacs;
static char *st_acsc;
static int l_acsc;
static char *st_bold;
static char *st_rmso;
static int l_bold;
static int l_rmso;
static char *st_civis;
static char *st_cnorm;
static int l_cnorm;
static int l_civis;
struct fd_set bits;

char    A_UL = '�';
char    A_LL = '�';
char    A_UR = '�';
char    A_LR = '�';
char    A_VL = '�';
char    A_HL = '�';

int     pc();

#define TPUTS(x, y, z)  (tputs(y, z, pc), pc(0), pc(0), pc(0))

set_color(color)
char   *color;
{
	s_pr(80, 24, color);
}

k_init()
{
	struct termio tinit;
	struct termio tem;

	FD_ZERO(&bits);
	FD_SET(0, &bits);

	ioctl(0, TCGETA, &tinit);
 /* Mise du tty en mode raw */
	tem = tinit;
	tem.c_oflag = 0;
	tem.c_lflag = 0;
	tem.c_iflag = 0;
	tem.c_cc[VMIN] = 1;
	tem.c_cc[VTIME] = 1;
	ioctl(0, TCSETA, &tem);
}

char 
cgetch()
{
	char    c;

	FD_ZERO(&bits);
	FD_SET(0, &bits);
	select(1, &bits, (fd_set *) 0, (fd_set *) 0, NULL);
	read(0, &c, 1);
	return c;
}

unsigned char 
kbhit()
{
	unsigned char c = 0;
	struct termio tim;

	bzero(&tim, sizeof(tim));
	FD_ZERO(&bits);
	FD_SET(0, &bits);
	if (select(1, &bits, (fd_set *) 0, (fd_set *) 0, &tim) > 0)
	{
		read(0, &c, 1);
	}
	return c;
}

int 
s_gets(s, x, y, len)
char  **s;
int     x, y;
int     len;
{
	int     l = 0;
	char    k;

	bzero(*s, len);
	while ((k = cgetch()) != 13)
	{
		if (l == len)
			return -1;
		switch (k)
		{
			case 8:
				if (l == 0)
					break;
				l--;
				s_pc(x + l, y, 32);
				*(*s + l) = 0;
				break;
			case 27:
				**s = 0;
				for (l = 0; l < len; l++)
					s_pc(x + l, y, 32);
				return 0;
				break;
			case 24:
				return -1;
				break;
			default:
				*(*s + l) = k;
				s_pc(x + l, y, k);
				l++;
		}
	}
	for (l = 0; l < len; l++)
		s_pc(x + l, y, 32);
	return 0;
}


s_init()
{
	int     result;
	char   *t;

	if (setupterm((char *) 0, 1, &result) == ERR)
	{
		switch (result)
		{
			case 0:
				fprintf(stderr, "Can't find terminal %s\n\r", getenv("TERM"));
				exit(0);
			case -1:
				fprintf(stderr, "Can't find termininfo database\n\r");
				exit(0);
			default:
				fprintf(stderr, "Bad terminfo error %d\n\r", result);
				exit(0);
		}
	}
	st_cup = tigetstr("cup");
	if (!st_cup)
	{
		fprintf(stderr, "cup not found\n\r");
		exit(1);
	}
	st_clear = tigetstr("clear");
	if (!st_clear)
	{
		fprintf(stderr, "clear not found\n\r");
		exit(0);
	}
	st_smkx = tigetstr("smkx");
	st_rmkx = tigetstr("rmkx");
	if (st_smkx)
		TPUTS(1, st_smkx, strlen(st_smkx));
	st_bold = tigetstr("bold");
	if (st_bold)
	{
		l_bold = strlen(st_bold);
		st_rmso = tigetstr("rmso");
		if (st_rmso)
		{
			l_rmso = strlen(st_rmso);
		}
		else
			st_bold = 0;
	}
	st_civis = tigetstr("civis");
	if (st_civis)
	{
		l_civis = strlen(st_civis);
		st_cnorm = tigetstr("cnorm");
		if (st_cnorm)
		{
			l_cnorm = strlen(st_cnorm);
		}
		else
			st_civis = 0;
	}
	st_enacs = tigetstr("enacs");
	st_rmacs = tigetstr("rmacs");
	st_smacs = tigetstr("smacs");
	if (t = tigetstr("kcuu1"))
	{
	}
	if (t = tigetstr("kcud1"))
	{
	}
	if (t = tigetstr("kcub1"))
	{
	}
	if (t = tigetstr("kcuf1"))
	{
	}
	if (st_smacs)
	{
		if (st_enacs)
			TPUTS(1, st_enacs, strlen(st_enacs));
		st_acsc = tigetstr("acsc");
		if (st_acsc)
		{
			l_acsc = strlen(st_acsc);
		}
	}
	fl();
}

s_term()
{
	if (st_rmkx)
		TPUTS(1, st_rmkx, strlen(st_rmkx));
	fl();
}

static unsigned char buf[1024];
int     pbuf;

/* static */
pc(c)
char    c;
{
	buf[pbuf++] = c;
}

/* static */
fl()
{
	write(1, buf, pbuf);
	pbuf = 0;
}

s_pr(x, y, s, v1, v2)
int     x;
int     y;
char   *s;
int     v1;
int     v2;
{
	char   *p = tgoto(st_cup, x, y);

	TPUTS(1, p, strlen(p));
	pbuf += sprintf(buf + pbuf, s, v1, v2);
	fl();
}

s_pc(x, y, c)
int     x;
int     y;
char    c;
{
	char   *p = tgoto(st_cup, x, y);

	TPUTS(1, p, strlen(p));
	if (c != 0)
		pc(c);
	fl();
}

s_clear()
{
	TPUTS(1, st_clear, strlen(st_clear));
	fl();
}

s_box(x, y, l, h)
int     x, y;
int     l, h;
{
	int     i;
	char    buf[81];

	s_pc(x, y, A_UL);
	s_pc(x + l, y, A_UR);
	for (i = 1; i < l; i++)
	{
		s_pc(x + i, y, A_HL);
		s_pc(x + i, y + h, A_HL);
	}
	sprintf(buf, "%c%%%ds%c", A_VL, l - 1, A_VL);
	for (i = 1; i < h; i++)
	{
		s_pr(x, y + i, buf, "");
	}
	s_pc(x, y + h, A_LL);
	s_pc(x + l, y + h, A_LR);
}

s_pause()
{
	while (cgetch() != 13);
}

s_clearb(x, y, l, h)
int     x, y;
int     l, h;
{
	int     i;
	char    tmp[8];

	set_color("[0m");
	sprintf(tmp, "%%%ds", l);
	for (i = 0; i < h; i++)
		s_pr(x, y + i, tmp, "");
}

s_bold()
{
	if (st_bold)
		TPUTS(1, st_bold, l_bold);
}

s_rmso()
{
	if (st_rmso)
		TPUTS(1, st_rmso, l_rmso);
}

s_civis()
{
	if (st_civis)
		TPUTS(1, st_civis, l_civis);
}

s_cnorm()
{
	if (st_cnorm)
		TPUTS(1, st_cnorm, l_cnorm);
}
