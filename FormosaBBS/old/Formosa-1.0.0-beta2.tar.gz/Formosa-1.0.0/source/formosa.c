

#define _BBS_GLOBAL_VAR_	/* for include global variables in bbs.h */

#include "bbs.h"
#include "tsbbs.h"


char    myfromhost[16];
char    myuserid[IDLEN + 1], mypasswd[PASSLEN];

int     newreg_number = 0;


void
abort_new_reg()
{
	struct useridx uidx;

	memset(&uidx, 0, sizeof(uidx));
	substitute_record(USERIDX, &uidx, sizeof(uidx), newreg_number);

	exit(0);
}


/*******************************************************************
 * �T�����u
 *******************************************************************/
void
abort_bbs()
{
	if (newreg_number)
	{
		abort_new_reg();
	}
	else
	{
		user_logout();
		exit(0);
	}
}


/*******************************************************************
 * �I��a
 *******************************************************************/
void
warn_bell()
{
	int     i = 5;

	while (i--)
		bell();
}


void
talk_request()
{
#if	defined(LINUX) || defined(SOLARIS)
/*
 * �s�� page ���⦸�N�i�H�����X�h�G
 *
 *     �o�O�ѩ�Y�Ǩt�� signal �i�ӴN�|�N signal handler ���]��
 * (SIG_DFL) ���w�� handler, �������O default �O�N�{�� terminate.
 * �ѨM��k�O�C�� signal �i�ӴN���] signal handler
 */
	signal(SIGUSR1, talk_request);
#endif
	talkrequest = YEA;
	warn_bell();
}


void
write_request()
{
#if	defined(LINUX) || defined(SOLARIS)
	signal(SIGUSR2, write_request);
#endif

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return;
#endif
	writerequest = YEA;
	warn_bell();
}


#ifdef NSYSUBBS
void
LoadSysopCache()
{
	FILE   *fp;
	register int i;
	char   *ptr;
	int sysop_num;

	sysop_num = GetNumFileLine(SYSOPLIST);
	sysop_cache = malloc_array(sysop_num);
	if (sysop_cache == NULL)
		return;

	if ((fp = fopen(SYSOPLIST, "r")) != NULL)
	{
		i = 0;
		while (i < sysop_num && fgets(genbuf, sizeof(genbuf), fp))
		{
			if ((ptr = strchr(genbuf, '#')))		
				continue;
			if ((ptr = strchr(genbuf, '\n')))
				*ptr = '\0';
			if ((ptr = strtok(genbuf, ": \t\r")))
			{
				if (ptr[0])
					sysop_cache = add_array(sysop_cache, ptr, malloc_str);
			}
		}
		fclose(fp);		
	}
}


int
IsRealSysop(userid)
char *userid;
{
	if (!sysop_cache|| !userid || userid[0] == '\0')
		return 0;
	return	cmp_array(sysop_cache, userid, strcmp);
}
#endif


/*******************************************************************
 * �ˬd�s�襢�ѳƥ���
 *******************************************************************/
void
user_init()
{
#ifdef NSYSUBBS
	LoadSysopCache();
#endif	
#if 0
	init_board();
#endif
	setboardfile(curbmfile, DEFAULTBOARD, BM_ASSISTANT);
	sprintf(bbstitle, "�D�R�O��� (%s)", BBSTITLE);

	setmailfile(maildirect, curuser.userid, DIR_REC);
	if (HAS_PERM(PERM_SYSOP) || HAS_PERM(PERM_BM))
		maxkeepmail = 2 * MAX_KEEP_MAIL;
	else
		maxkeepmail = MAX_KEEP_MAIL;

	if (HAS_FLAG(COLOR_FLAG))
		show_ansi = NA;
	else
		show_ansi = YEA;
	sethomefile(ufile_overrides, curuser.userid, UFNAME_OVERRIDES);
	sethomefile(ufile_boardrc, curuser.userid, UFNAME_BOARDRC);
	setuserfile(ufile_write, curuser.userid, UFNAME_WRITE);

	if (multi <= 1)
		unlink(ufile_write);	/* lasehu */

	sprintf(tempfile, "tmp/bbs%05d", getpid());

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return;
#endif

#ifdef IDENT
	if (curuser.ident > 7 || curuser.ident < 0)	/* debug */
	{
		curuser.ident = 0;
		update_user(&curuser);
		update_user_passfile(&curuser);
	}
#endif
	if (curuser.numlogins % 5 == 0)	/* lasehu */
		pack_article(maildirect);	
}


#ifdef MULTIBBS
create_net_socket()
{
	char   *s[2];

#if	defined(NSYSUBBS2) || defined(NSYSUBBS3)
	s[0] = "140.117.11.2";
#else
	s[0] = "140.117.11.4";
#endif
	return ConnectServer(*s, NETPORT, TCP);
}


close_net_socket(socket)
int     socket;
{
	DisconnectServer(socket);
/* init_alarm(IDLE_TIMEOUT); */
}

#endif


/*******************************************************************
 * login()
 *******************************************************************/
void
new_register(nu)
USEREC *nu;
{
	int     attempts = 0;

	memset(nu, 0, sizeof(USEREC));

	if (dashf(NONEWUSER) || (nu->uid = new_user(NULL)) <= 0)
	{
		more(NONEWUSER, NA);
		sleep(2);
		exit(1);
	/* NOT REACHED */
	}
	newreg_number = nu->uid;/* lasehu */
#ifdef DEBUG
	prints("\n�z�����U�s���O [%d] \n", nu->uid);
#endif

	outs("\n�w��! �s���, �п�J�z�ҧƱ檺�N��(�@�ӭ^��W�r)\n");
	while (1)
	{
		getdata(0, 0, "�ϥΪ̥N�� (user id) : ", nu->userid, IDLEN + 1, ECHONOSP, NULL);
		if (strlen(nu->userid) < LEAST_IDLEN || !chk_alpha_str(nu->userid)
		    || invalid_userid(nu->userid))
		{
			prints("\n�п�J�ܤ� %d �Ӧr��, ���i���S���Ÿ�, �ť�, �Ʀr, �����r��\n", LEAST_IDLEN);
			if (++attempts >= 3)
			{
				fprintf(stdout, "\n�z�٬O�S�Q�n�n�ϥΪ��N��, �U���A���o ...");
				fflush(stdout);
				sleep(2);
				abort_bbs();
			/* NOT REACHED */
			}
			continue;
		}
/* lasehu */
		strcpy(myuserid, nu->userid);
		if (get_passwd(NULL, nu->userid) > 0)
		{
			outs("\n���N���w�Q�ϥ�, �д��@��\n\n");
			continue;
		}
		break;
	}
	while (1)
	{
		getdata(0, 0, "�K�X(password, 4 - 8 �Ӧr) : ", mypasswd, PASSLEN, NOECHO, NULL);
		if (strlen(mypasswd) < 4)
		{
			outs("\n�K�X���צܤ֭n 4 �Ӧr��\n\n");
			continue;
		}
		if (!strcmp(mypasswd, nu->userid))
		{
			outs("\n�ФŨϥλP ID �ۦP�ΤӹL��²����q���K�X\n\n");
			continue;
		}
		getdata(0, 0, "�A���@���K�X(check) : ", genbuf, PASSLEN, NOECHO, NULL);
		if (strcmp(mypasswd, genbuf))
		{
			outs("\n�⦸��J���K�X���@��, �Э��s�]�w.\n\n");
			continue;
		}
		break;
	}
	mypasswd[CRYPTLEN] = '\0';
	strncpy(nu->passwd, genpasswd(mypasswd), PASSLEN);

	getdata(0, 0, "�L�m�j�W (Name ���^��ҥi) : ", nu->username, sizeof(nu->username), DOECHO, NULL);
	getdata(0, 0, "�q�l�l��a�} : ", nu->email, sizeof(nu->email), DOECHO, NULL);
/*---
	getdata(0, 0, "�׺ݾ����A(vt100 �� dumb, �Y�L�S�w�Ы� enter) [vt100] : ",
		nu->termtype, sizeof(nu->termtype), DOECHO, NULL);
*/
	if (nu->termtype[0] == '\0')
		strcpy(nu->termtype, "vt100");
	nu->firstlogin = time(0);	/* lasehu */
	nu->lastlogin = nsysu_lastlogin = time(0);	/* ? */
	strncpy(nu->lasthost, myfromhost, sizeof(nu->lasthost));
	strncpy(nsysu_lastfromhost, myfromhost, sizeof(nsysu_lastfromhost));
#ifdef SYSOP
	if (!strcmp(nu->userid, SYSOP))
		nu->userlevel = 255;
	else
#endif
		nu->userlevel = 0;

	if (new_user(nu))	/* �N�ϥΪ̵��U�Ҷ��Ƽg�J���e�b .PASSWDS ��쪺�Ŧ� */
	{
#ifdef MULTIBBS
		int     sock;

		if ((sock = create_net_socket()) > 0)
		{
			net_printf(sock, "SENDUSER %s\n", nu->userid);
			if (net_gets(sock, genbuf, sizeof(genbuf)))
			{
				if (!strncmp(genbuf, "READY", 5))
				{
					write(sock, nu, sizeof(USEREC));
					net_gets(sock, genbuf, sizeof(genbuf));	/* OK */
					close_net_socket(sock);
				}
			}
		}
#endif
		newreg_number = 0;
	}
	else
	{
		fprintf(stdout, "\n\r�طs�b������, �����u");
		fflush(stdout);
		sleep(2);
		abort_bbs();
	/* NOT REACHED */
	}
}


/*******************************************************************
 * User Login
 * �Ѽ�: name -> userid
 *       passwd -> password (���X)
 *       from -> fromhost (char [17])
 * �Ǧ^: �u�W�s��.
 *******************************************************************/
unsigned int
user_login(net_mode)
int     net_mode;
{
	FILE   *fp;

	memset(&uinfo, 0, sizeof(USER_INFO));
/*	memset(&curuser, 0, sizeof(curuser));	*/

	if ((uinfo.active = new_utmp()) <= 0)
		return 0;
/* ? */
	mypasswd[8] = '\0';
#ifdef MULTIBBS
	if (!net_mode)
	{
#endif
		if (get_passwd(&curuser, myuserid) <= 0)
		{
			fprintf(stdout, _msg_err_userid);
			fflush(stdout);
			return 0;
		}
#ifdef GUEST_ACCOUNT
		if (strcmp(curuser.userid, GUEST_ACCOUNT))
		{
#endif
			if (curuser.passwd[0] == '\0')
			{
				fprintf(stdout, "\n\r���b���w�Q����.");
				fflush(stdout);
				sleep(2);
				return 0;
			}
			if (!checkpasswd(curuser.passwd, mypasswd))
				return 0;
#ifdef GUEST_ACCOUNT
		}
#endif
#ifdef HAVE_BUF
		if (curuser.uid < 1)
			return 0;
#endif
#ifdef MULTIBBS
	}
	else
	{
		int     net_sock;

		if ((net_sock = create_net_socket()) < 0)
			return 0;
/* ? */
		if (get_passwd(&curuser, myuserid) > 0)
		{
			nsysu_lastlogin = curuser.lastlogin;
			strcpy(nsysu_lastfromhost, curuser.lasthost);
		}

		net_printf(net_sock, "LOGIN %s %s %s\n", myuserid, mypasswd, myfromhost);
		if (!net_gets(net_sock, genbuf, sizeof(genbuf)))
			return 0;
		if (strncmp(genbuf, "OK", 2))
			return 0;
		net_printf(net_sock, "READY\n");
		if (read(net_sock, &curuser, sizeof(USEREC)) != sizeof(USEREC))
			return 0;
		if (curuser.passwd[0] == '\0')
		{
			fprintf(stdout, "\n\r���b���w�Q����.");
			fflush(stdout);
			sleep(2);
			return 0;
		}
		net_printf(net_sock, "GOODBYE\n");
		close_net_socket(net_sock);
	}
#endif

	strcpy(curuser.userid, myuserid);	/* ? */
	strcpy(uinfo.userid, myuserid);
	strcpy(uinfo.username, curuser.username);	/* lasehu */
	strcpy(uinfo.from, myfromhost);
	uinfo.pid = getpid();
	uinfo.uid = curuser.uid;
	uinfo.invisible = (HAS_FLAG(CLOAK_FLAG) && HAS_PERM(PERM_CLOAKLOGIN)) ? YEA : NA;
/* ? */
	uinfo.c_type = CTYPE_TSBBS;
/* ? */
	uinfo.mode = LOGIN;
	uinfo.pager = !HAS_FLAG(PAGER_FLAG);

	if (!net_mode)
	{
#ifdef GUEST_ACCOUNT
		if (strcmp(curuser.userid, GUEST_ACCOUNT))
		{
#endif
			curuser.numlogins++;
			if (curuser.userlevel < NORMAL_USER_LEVEL)
				curuser.userlevel++;
#ifdef GUEST_ACCOUNT
		}
#endif

		nsysu_lastlogin = curuser.lastlogin;
		curuser.lastlogin = time(0);
		strcpy(nsysu_lastfromhost, curuser.lasthost);
		strcpy(curuser.lasthost, myfromhost);
		curuser.lastctype = CTYPE_TSBBS;	/* lasehu */
	}

	sethomefile(genbuf, myuserid, UFNAME_RECORDS);
#ifdef GUEST_ACCOUNT
	if (strcmp(curuser.userid, GUEST_ACCOUNT))
#endif
		if ((fp = fopen(genbuf, "a")) != NULL)
		{
			fprintf(fp, "%s %s", myfromhost, ctime(&(curuser.lastlogin)));
			fclose(fp);
		}
	return curuser.uid;
}


void
login_query()
{
	int     act;
	char   *p;
	FILE   *fp;

	act = ask_online_user();

#ifdef ACTFILE
	if ((fp = fopen(ACTFILE, "r")) != NULL)
	{
		while (fgets(genbuf, sizeof(genbuf), fp))
			outs(genbuf);
		fclose(fp);
	}
	prints("\n�w����{ [1;37m%s[m\n", BBSNAME);
#else
	prints("\n�w����{ [1;37m%s[m, �ثe�u�W�� [%d] �H\n", BBSNAME, act);
/*---
	prints("\n[1m%s[m\n", FORMOSA_BBS_SERVER_VERSION);
*/
#endif				/* !ACTFILE */

#ifdef SHOW_UPTIME
	if ((fp = fopen(SHOW_UPTIME, "r")) != NULL)
	{
		if (fgets(genbuf, sizeof(genbuf), fp))
		{
			p = strrchr(genbuf, ':') + 1;
			prints("�t�� (1,10,15) �����������t�����O�� %s", p);
		}
		fclose(fp);
	}
#endif

#ifndef SYSOP_BIN
	if (act > MAXACTIVE)
	{
		fprintf(stdout, "\n\r[1;32m�W�� %d �H, �еy�ԦA��", MAXACTIVE);
		fflush(stdout);
		sleep(1);
		exit(0);
	}
#endif

	for (act = 0; act <= LOGINATTEMPTS; act++)
	{
		if (act == LOGINATTEMPTS)
		{
			fprintf(stdout, "\n\r��p, �A�w���� %d ��, �U���A�ӧa!", LOGINATTEMPTS);
			fflush(stdout);
			sleep(2);
			exit(0);
		}

/* haha --lmj
   prints("�Ы� Enter ");
   {
   unsigned char ikey = 0;
   while(ikey != 'q') {
   ikey = igetch();
   prints("(%d)[%c]\n",ikey,ikey);
   }
   }
 */
#ifdef LOGINASNEW
		outs("\n�Y�Q���U�s�b��, �п�J 'new'");
#ifdef GUEST_ACCOUNT
		prints(" (���[�п�J '%s')", GUEST_ACCOUNT);
#endif
#else
#ifdef GUEST_ACCOUNT
		prints("\n�Y�Q���[�п�J '%s'", GUEST_ACCOUNT);
#endif
#endif				/* !LOGINASNEW */

		if (!getdata(3, 0, "\n�п�J�N��(user id) : ", myuserid, IDLEN + 1, ECHONOSP, NULL))
		{
			outs(_msg_err_userid);
		}
		else if (!strcmp(myuserid, "new"))
		{
#ifndef LOGINASNEW
			if (dashf(NONEWUSER))
			{
				more(NONEWUSER, NA);
				oflush();
			}
			else
				printf("\n\r���t�Τ������s�ϥε��U !!");
#ifdef GUEST_ACCOUNT
			printf("\n\r�ХH guest ���[�αb���i��.");
#endif
			sleep(2);
			exit(1);
		/* NOT REACHED */
#endif
			if (dashf(NONEWUSER))
			{
				printf("\n\r���t�Τ������s�ϥε��U !!");
				more(NONEWUSER, NA);
				oflush();
				sleep(2);
				exit(1);
			/* NOT REACHED */
			}
			new_register(&curuser);
			if (user_login(NA))
				break;
		}
		else
		{
#ifdef GUEST_ACCOUNT
			if (!strcmp(myuserid, GUEST_ACCOUNT))
			{
				getdata(4, 0, "�п�J�K�X(password) : <�Ъ����� Enter �Y�i>  ", mypasswd, PASSLEN, NOECHO, NULL);
				if (user_login(NA))
					break;
			}
#endif
			if (getdata(4, 0, "�п�J�K�X(password) : ", mypasswd, PASSLEN, NOECHO, NULL))
			{
#ifdef MULTIBBS
#if	defined(NSYSUBBS2) || defined(NSYSUBBS3)
				if (user_login(YEA))
					break;
#endif
#endif
				if (user_login(NA))
					break;;
			}
			outs("�K�X���~ !!\n");
			fflush(stdout);
		}
	}

}


user_logout()
{
	USEREC  usrbuf;

	unlink(tempfile);	/* �M���ϥΪ̩󦹦��W�����Ȧs�γ~�� */
#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
	{
		purge_utmp(&uinfo);
		return;
	}
#endif

	if (ever_del_mail)
		pack_article(maildirect);
	if (uinfo.pager)
		UNSET_FLAG(PAGER_FLAG);
	else
		SET_FLAG(PAGER_FLAG);
	if (get_passwd(&usrbuf, curuser.userid) > 0)
	{
#ifdef IDENT
#ifdef HAVE_BUG
		if (curuser.ident > 7 || curuser.ident < 0)
			curuser.ident = 0;
		if (usrbuf.ident <= 7)
#endif
			if (usrbuf.ident > curuser.ident)
				curuser.ident = usrbuf.ident;
#endif
#ifdef HAVE_BUG
		if (numposts < 0)
			numposts = 0;
		if (curuser.numposts < 0)
			curuser.numposts = 0;
		if (curuser.numlogins < 0)
			curuser.numlogins = 0;
#endif
#ifdef MULTIBBS
		if (usrbuf.numlogins > curuser.numlogins)
			curuser.numlogins = usrbuf.numlogins;
		if (usrbuf.numposts > curuser.numposts)
			curuser.numposts = usrbuf.numposts;
#endif
		curuser.numposts += numposts;
	}
#ifdef MULTIBBS
	net_update_user(&curuser, curuser.passwd);
#endif
	update_user(&curuser);
	update_user_passfile(&curuser);
	purge_utmp(&uinfo);
}


/****************
 * Announce     *
 ****************/
Announce()
{
	more(WELCOME, YEA);

	return M_FULL;
}


void
RecordVisitor()
{
	struct visitor v;
	int     fd;

	strcpy(v.userid, curuser.userid);
	strcpy(v.from, curuser.lasthost);
	v.when = curuser.lastlogin;
	if ((fd = open(PATH_VISITOR, O_WRONLY | O_CREAT | O_APPEND, 0644)) > 0)
	{
		write(fd, &v, sizeof(v));
		close(fd);
	}
}

void
record_stat()
{
	int fd;
	char buf[10];
	
	if ((fd = open("log/record_stat", O_WRONLY | O_CREAT | O_APPEND, 0644)) > 0)
	{
		sprintf(buf, "%d\n", uinfo.mode);
		write(fd, buf, strlen(buf));
		close(fd);
	}
}	

/*******************************************************************
 * Main()
 *******************************************************************/
void
Formosa(host, term)
char   *host, *term;
{
	FILE   *wel;

	if ((wel = fopen(BBSSRV_WELCOME, "r")))
	{
		while (fgets(genbuf, sizeof(genbuf), wel))
			outs(genbuf);
		fclose(wel);
	}

#ifdef CHROOT_BBS
#ifdef CSBBS
	struct stat bst;

	if (stat(BOARDS, &bst))
#endif
		if (chroot(HOMEBBS) || chdir("/"))
			return;
#else
	if (chdir(HOMEBBS) == -1)
	{
		printf("\ncannot change directory to [%s].\n", HOMEBBS);
		return;
	}
#endif
	if (getuid() != BBS_UID)
	{
#ifndef HP_UX
		seteuid(0);
#endif
		setgid(BBS_GID);
		setuid(BBS_UID);
	}

#ifndef lint
	signal(SIGHUP, abort_bbs);

	signal(SIGBUS, abort_bbs);
#if 0
	signal(SIGSYS, abort_bbs);
#endif	
	signal(SIGTERM, abort_bbs);
#if 0
	signal(SIGSYS, SIG_IGN);
	signal(SIGTERM, SIG_IGN);
#endif

/*	signal(SIGSEGV, SIG_IGN); */
	signal(SIGSEGV, record_stat);
	signal(SIGCHLD, SIG_IGN);	/* ? */
	signal(SIGINT, SIG_IGN);
	signal(SIGQUIT, SIG_IGN);
	signal(SIGPIPE, SIG_IGN);

	signal(SIGURG, SIG_IGN);
	signal(SIGTSTP, SIG_IGN);
	signal(SIGTTIN, SIG_IGN);
	signal(SIGTTOU, SIG_IGN);

	signal(SIGUSR1, talk_request);
	signal(SIGUSR2, write_request);
#endif				/* ifndef lint */

/*---
	if (setjmp(byebye))
		abort_bbs();
*/

#ifdef	CSBBS
	strcpy(myfromhost, "Call By CSBBS");
#else
	if (host)
	{
		strncpy(myfromhost, host, sizeof(myfromhost));
		myfromhost[sizeof(myfromhost) - 1] = '\0';
	}
	else
	{
		strcpy(myfromhost, "local");
	}
#endif

	init_tty();

#ifdef	CSBBS
	if (get_passwd(&curuser, host) <= 0)
		exit(1);
	strcpy(myuserid, host);
	strcpy(mypasswd, curuser.passwd);
#ifdef MULTIBBS
#if	defined(NSYSUBBS2) || defined(NSYSUBBS3)
	memset(&curuser, 0, sizeof(curuser));
	if (user_login(YEA))
		exit(-2);
#endif
#endif
	memset(&curuser, 0, sizeof(curuser));
	if (user_login(NA))
		exit(-2);
#else				/* CSBBS */
	login_query();
#endif				/* !CSBBS */

#ifdef TIMEOUT
	init_alarm(IDLE_TIMEOUT);
#else
	signal(SIGALRM, SIG_IGN);
#endif

/*
    if (!term_init(curuser.termtype))
*/
	term_init("vt100");
	initscr();
#if 0
#ifdef SYSV
	if (get_semaphore() == -1)
	{
		printf("Can't get semaphore! Exiting...\n");
		exit(0);
	}
#endif
#endif
	RecordVisitor();
	multi_user_check();
	user_init();

	more(WELCOME0, YEA);
	Announce();

#if defined(PICTURE_MENU)
	{
		int     fd;
		extern int picture_number;

		picture_number = PICTURE_MAX_NUMBER;
		if ((fd = open(PICTURE_NUMBER, O_RDONLY)) > 0)
		{
			if (read(fd, genbuf, sizeof(genbuf)) > 0)
			{
				picture_number = atoi(genbuf);
				if (picture_number < 1 || picture_number > PICTURE_MAX_NUMBER)
					picture_number = PICTURE_MAX_NUMBER;
			}
			close(fd);
		}
	}
#endif

	domenu();
}

int
invalid_userid(userid)
char   *userid;
{
	char    buf[IDLEN + 1];
	int     i;
	unsigned char ch;

	if (!userid || userid[0] == '\0')
		return 1;
	i = strlen(userid);
	if (i < LEAST_IDLEN || i > IDLEN)
		return 1;
	for (i = 0; i < sizeof(buf) && (ch = userid[i]); i++)
	{
		if (!isalpha(ch))
			return 1;
		if (ch >= 'A' && ch <= 'Z')
			buf[i] = (ch | 32);
		else
			buf[i] = ch;
	}
	buf[i] = '\0';
	if (!strcmp(buf, "new") || seek_in_file(BADUSERID, buf))
		return 1;
#ifndef SYSOP
	if (strstr(buf, "sysop"))
		return 1;
#endif
	return 0;
}

int
Users()				/* list all registered user */
{
	int     fd, sysop, bm, total, ch, spec_ulevel, spec_total;
	short   i = 3, show = YEA;

#ifdef IDENT
	int     idented;

#endif
	USEREC  all_urc;

	spec_ulevel = 0;
	total = spec_total = 0;
	sysop = bm = 0;

	if (getdata(1, 0, "�n�d�ݵ��Ŧh�֥H�W���ϥΪ� ? [0] : ", genbuf, 4, ECHONOSP, NULL))
		spec_ulevel = atoi(genbuf);

	if ((fd = open(PASSFILE, O_RDONLY)) < 0)
		return -1;

	move(1, 0);
	clrtobot();
	prints("%-12s %-20s %6s %6s %4s", "�N�W", "���W", "�W����", "�i�K��", "����");
	outs("\n------------------------------------------------------------------------------");

	while (read(fd, &all_urc, sizeof(USEREC)) == sizeof(USEREC))
	{
		if (all_urc.userid[0] == '\0' || !strcmp(all_urc.userid, "new"))
			continue;
		total++;
		if (all_urc.userlevel == 255)
			sysop++;
		else if (all_urc.userlevel >= 100)
			bm++;

		if (all_urc.userlevel < spec_ulevel)
			continue;
		spec_total++;
#ifdef IDENT
		if (all_urc.ident == 7)
			idented++;
#endif
		if (show)
		{
			move(i, 0);
			clrtoeol();
			prints("%-12s %-20.20s %6d %6d %4d\n",
			       all_urc.userid, all_urc.username, all_urc.numlogins, all_urc.numposts,
			       all_urc.userlevel);
			if (++i == b_line)
			{
				outs("[37;45m--- �٦��@ ---[44m [q] or [��]:���} , [��][n][Space]:�U�@��        [m");
				ch = igetkey();
				if (ch == KEY_LEFT || ch == 'q')
				{
					show = NA;
					continue;
				}
				i = 3;
				move(i, 0);
				clrtobot();
			}
		}
	}
	close(fd);
	clrtobot();
	if (spec_ulevel == 0)
		prints("\n[37;44m���U�H�� %d �H, ", total);
	else
		prints("\n[37;44m�έp�H�� %d/%d �H, ", spec_total, total);
	prints("�޲z�� %d �H, �O�D %d �H", sysop, bm);
#ifdef IDENT
	prints(", (�q�L�{�� %d �H)[m", idented);
#endif
	getkey();
	return M_FULL;
}

