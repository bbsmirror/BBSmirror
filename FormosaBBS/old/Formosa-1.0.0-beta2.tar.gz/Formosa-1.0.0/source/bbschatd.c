
#include "bbs.h"
#include "chat.h"
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <netdb.h>
#include <errno.h>
#include <signal.h>
#include <sys/file.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>


#define MAXPORTS	(80)
#define MAXCHANS	(20)


char *mycrypt();

#undef DEBUG

int     seat;
char    chbuf[254];
int     numports;
char     *idpassstr;
char    gbuf[80];

struct Respond
{
	int     num;
	char   *describ;
};

struct prot
{
	int     num;
	char   *keyword;
	int     (*func) ();
};

int     chat_join(), chat_msg(),
#ifdef HAVE_CHATMSGALL
        chat_msgall(),
#endif
        chat_who(), chat_who(),
        chat_whoall(), chat_nickname(), chat_listchan(), chat_user(), chat_topic(),
        chat_passwd(), chat_logout(), chat_ignore();

struct prot fp[] =
{
	{CHAT_JOIN, "JOIN", chat_join},
	{CHAT_USRID, "USRID", chat_user},
	{CHAT_QUIT, "QUIT", chat_logout},

 /* Operator Instruction */

	{CHAT_TOPIC, "TOPIC", chat_topic},
	{CHAT_PASSWD, "PASSWD", chat_passwd},
	{CHAT_IGNORE, "IGNORE", chat_ignore},

 /* Ordinary User Instruction */

	{CHAT_MSG, "MSG", chat_msg},
#ifdef HAVE_CHATMSGALL
	{CHAT_MSGALL, "MSGALL", chat_msgall},
#endif
	{CHAT_WHO, "WHO", chat_who},
	{CHAT_WHOALL, "WHOALL", chat_whoall},
	{CHAT_NICKNAME, "NICKNAME", chat_nickname},
	{CHAT_LISTCHAN, "LISTCHAN", chat_listchan},
	{CHAT_SPEAK, "SPEAK", NULL}
};

struct Respond rep_err[] =
{
	{OK_CMD, "OK !!"},
	{WORK_FAIL, "�u�@����"},
	{PASS_FAIL, "�v������"},
	{USR_FAIL, "���F�H�f"},
	{NAME_FAIL, "�κ٭���"},
	{CMD_ERROR, "�R�O���~"}
};


struct Usr
{
	int     sock;
	char    userid[IDLEN];
	char    chatid[IDLEN];
	int     ID;
	char    from[16];
	short   bmop;
	int     bad[5];
}

        Usrec[MAXPORTS];


struct Chan
{
	char    name[CHANLEN];
	char    topic[TOPICLEN];
	int     attrib;
	char    op[IDLEN];
	char    passwd[8];
	int     members;
}

        Chanrec[MAXCHANS];


#if 0				/* del by lasehu */
#include <sys/ipc.h>


#define LOCK_EX         2	/* exclusive lock */
#define LOCK_UN         8	/* unlock */


#define SEM_KEY 9237
int     semid;

get_semaphore()
{
	if ((semid = semget(SEM_KEY, 1, 600)) == -1)
	{
		if ((semid = semget(SEM_KEY, 1, 600 | IPC_CREAT)) == -1)
			return -1;
		semctl(semid, 0, SETVAL, 1);
	}
	return 0;
}

my_flock(fd, op)
int     fd, op;
{
/* one semaphore for all shared files -> fd is unused */
	struct sembuf sops;

	sops.sem_num = 0;
	sops.sem_flg = SEM_UNDO;
	switch (op)
	{
		case LOCK_EX:
			sops.sem_op = -1;
			break;
		case LOCK_UN:
			sops.sem_op = 1;
			break;
		default:
			return -1;
	}
	semop(semid, &sops, 1);
	return 0;
}

#endif


void
report(s)
char   *s;
{
	static int disable = 0;
	int     fd;
	char    buf[80];
	if (!disable)
	{
/* lasehu
   if ((fd = open("trace.chatd", O_APPEND | O_CREAT, 0644)) < 0)
 */
		sprintf(buf, "%s/log/trace.chatd", HOMEBBS);
		if ((fd = open(buf, O_APPEND | O_CREAT | O_WRONLY, 0644)) < 0)
		{
			disable = 1;
			return;
		}
		sprintf(buf, "Room %d: %s\n", Usrec[seat].ID, s);
		write(fd, buf, strlen(buf));
		close(fd);
	}
}

Answer(respno)
int     respno;
{
	int     i;
	char    buf[80];

	for (i = 0; i < (sizeof(rep_err) / sizeof(struct Respond)); i++)

	{
		if (rep_err[i].num == respno)
		{
			sprintf(buf, "%d\t%s \r\n", rep_err[i].num, rep_err[i].describ);
			send_to_user(seat, buf);
		}
	}
}

EndProt()
{
	char    buf[3];

	sprintf(buf, ".\r\n");
	send_to_user(seat, buf);
}


char   *
PhaseSpace(str)
char   *str;
{
	int     i, j = 0;

	while (strchr(KEYWORD_DELIMITER, str[j]))
		j++;

	i = strlen(str) - 1;
	while (i >= 0 && strchr(" \t\r\n", str[i]))
		i--;
	str[i + 1] = '\0';


	return &str[j];
}


int
GetPassNum(keyword)
char   *keyword;
{
	int     i;

	for (i = 0; i < (sizeof(fp) / sizeof(struct prot)); i++)

	{
		if (!strcmp(keyword, fp[i].keyword))
			return fp[i].num;
	}
	return -1;
}

char   *
GetPass(str, token, maxlen)
char   *str;
char   *token;
int     maxlen;
{
	int     i = 0, j;
	char   *tmp;

	memset(token, 0, PROTOLEN);
	while (strchr(KEYWORD_DELIMITER, str[i]))
	{			/* �h���e�����ť� */
		if (str[i] == '\0')
		{
			token[0] = '\0';
			return &str[i];
		}
		i++;
	}
	tmp = &str[i];
	j = 1;
	while (!strchr(KEYWORD_SEPARATE, tmp[j]))	/* �Htab�����j�A��X�Ѽ� */
		j++;

	if (j >= maxlen)
	{			/* token too large */
/* del by lasehu
   token[0] = '\0';
 */
		j = maxlen - 1;	/* lasehu */
	}
/* del by lasehu
   else
   {
 */
	strncpy(token, tmp, j);
	token[j] = '\0';	/* important */
/*
   }
 */
	return &tmp[j];
}


int
get_client_name(cli_addr, peer_name, len)	/* ? */
struct sockaddr_in *cli_addr;
char   *peer_name;
int     len;
{
/*
 * struct hostent host_info;
 *
 * host_info = gethostbyaddr((char *) &cli_addr.sin_addr,
 * sizeof(cli_addr.sin_addr), AF_INET); strncpy(peer_name,
 * host_info.h_name, len);
 */
	strncpy(peer_name, inet_ntoa(cli_addr->sin_addr), len);
}


int
get_chatuid(chatid)
char   *chatid;
{
	int     i;

	for (i = 0; i < MAXPORTS; i++)
	{
		if (Usrec[i].sock == -1)
			continue;
		if (!strcmp(Usrec[i].chatid, chatid))
			return i;
	}
	return -1;
}


int
chat_passwd(password)
char   *password;
{
	if (Usrec[seat].ID < 0)/* lasehu */
	{
		Answer(PASS_FAIL);
		return -1;
	}
	
	if (!strcmp(Chanrec[Usrec[seat].ID].op, Usrec[seat].userid))
	{
		if (!strcmp(Chanrec[Usrec[seat].ID].name, DEF_CHANNAME))
		{		/* lasehu */
			Answer(PASS_FAIL);
			return -1;
		}
		password = PhaseSpace(password);
		password[7] = '\0';
		if (!strcmp(password, NOPASSWORD))
		{
			Chanrec[Usrec[seat].ID].passwd[0] = '\0';
			Answer(OK_CMD);
		}
		else
		{
			strcpy(Chanrec[Usrec[seat].ID].passwd, password);
			Answer(OK_CMD);
		}

	}
	else
		Answer(PASS_FAIL);
}


int
chat_topic(topicname)
char   *topicname;
{
	if (Usrec[seat].ID < 0)/* lasehu */
	{
		Answer(PASS_FAIL);
		return -1;
	}
	if (!strcmp(Chanrec[Usrec[seat].ID].op, Usrec[seat].userid))
	{
		topicname = PhaseSpace(topicname);
		topicname[TOPICLEN - 1] = '\0';
		strcpy(Chanrec[Usrec[seat].ID].topic, topicname);
		Answer(OK_CMD);
	}
	else
		Answer(PASS_FAIL);
}


int
get_chanid(channame)
char   *channame;
{
	int     i;

	for (i = 0; i < MAXCHANS; i++)
	{
		if (Chanrec[i].members == 0)
			continue;
		if (!strcmp(Chanrec[i].name, channame))
			return i;
	}
	return -1;
}

/* �إ߷s���W�D */
int
create_chanid(channame)
char   *channame;
{
	int     i;

	for (i = 0; i < MAXCHANS; i++)
	{
		if (Chanrec[i].name[0] == '\0')
		{
			strncpy(Chanrec[i].name, channame, CHANLEN - 1);
			strncpy(Chanrec[i].topic, channame, TOPICLEN - 1);
			strcpy(Chanrec[i].op, Usrec[seat].userid);
			return i;
		}
	}
	return -1;
}


int
BAD(badnums, chanid)
int badnums[];
int chanid;
{
    int i;
    
    for (i = 0; i < 5; i++)
    {
	if (badnums[i] == chanid + '0')
		return 1;
    }
    return 0;    	
}    

int
send_to_channel(chanid, msg)
int     chanid;
char   *msg;
{
	int     i;
	fd_set  writefds;
	int     len = strlen(msg);

	if (BAD(Usrec[seat].bad, Usrec[seat].ID))
	{
		Answer(PASS_FAIL);
		return -1;
	}	

/*
   int    invis = (Usrec[seat].perm & PERM_CLOAK);
 */
	FD_ZERO(&writefds);
	for (i = 0; i < MAXPORTS; i++)
	{
/* lasehu ?
   if (i == seat)
   continue;
 */
/* lasehu */
/*
   if (invis && !(Usrec[i].perm & PERM_CLOAK))
   continue;
 */
		if (Usrec[i].userid[0] == '\0')
			continue;
		if (!strcmp(Usrec[i].userid, Usrec[seat].userid))	/* lasehu */
			continue;
		if (Usrec[i].sock == -1)
			continue;
		if (chanid == Usrec[i].ID)
			write(Usrec[i].sock, msg, len);
/*
   FD_SET(Usrec[i].sock, &writefds);
 */
	}

/* Delete by Carey
   if (select(numports, NULL, writefds, NULL, NULL) > 0)
   {
   for (i = 0; i < numports; i++)
   if (FD_ISSET(Usrec[i].sock, &writefds))
   write(Usrec[i].sock, msg, len + 1);
   }
 */
}


send_to_user(chatuid, msg)
int     chatuid;
char   *msg;
{
	struct Usr *cusr = &(Usrec[chatuid]);

	if (cusr->userid[0] != '\0')
		write(cusr->sock, msg, strlen(msg));

/* Delete By Carey

   FD_ZERO(&writefds);
   FD_SET(Usrec[chatuid].sock, &writefds);
   if (select(numports, NULL, writefds, NULL, NULL) > 0)
   {
   for (i = 0; i < numports; i++)
   if (FD_ISSET(i, &writefds))
   write(i, msg, len + 1);
   }
 */
}


void
leave_channel()
{
	int     oldchanid = Usrec[seat].ID;

	if (oldchanid != 0)
	{
		if (--Chanrec[oldchanid].members > 0)
		{
			int     i;

			if (!BAD(Usrec[seat].bad, oldchanid))
			{
				sprintf(chbuf, "�ϥΪ� %s ���}���W�D\r\n", Usrec[seat].chatid);			
				send_to_channel(oldchanid, chbuf);
			}
			Usrec[seat].ID = 0;

			for (i = 0; i < MAXPORTS; i++)
			{
				if (Usrec[i].sock == -1)
					continue;
				if (Usrec[i].ID == oldchanid)
				{	/* ���� op ���� */
					int     new_opchatuid = get_chatuid(Usrec[i].userid);

					strcpy(Chanrec[oldchanid].op, Usrec[i].userid);
					if (Chanrec[oldchanid].passwd[0])
					{
						sprintf(chbuf, "���W�D op �{�ѱz����, �K�X��: %s\r\n", Chanrec[oldchanid].passwd);
						send_to_user(new_opchatuid, chbuf);
						break;
					}
				}
			}
		}
		else
		{
		/* close channel */
			Chanrec[oldchanid].name[0] = '\0';
			Chanrec[oldchanid].topic[0] = '\0';
			Chanrec[oldchanid].op[0] = '\0';
			Chanrec[oldchanid].members = 0;
			Chanrec[oldchanid].passwd[0] = '\0';
			Usrec[seat].ID = 0;	/* lasehu */
		}
	}
	else
	{
		if (!BAD(Usrec[seat].bad, oldchanid))
		{
			sprintf(chbuf, "�ϥΪ� %s ���}���W�D\r\n", Usrec[seat].chatid);
			send_to_channel(oldchanid, chbuf);
		}
	}	
}


int
chat_logout(u)
{
	leave_channel();

	close(Usrec[u].sock);
	Usrec[u].userid[0] = '\0';
	Usrec[u].chatid[0] = '\0';
	Usrec[u].sock = -1;
	Usrec[u].ID = 0;
	Usrec[u].from[0] = '\0';
	memset(Usrec[u].bad, 0, 5); 
	
	numports--;		/* lasehu */
#ifdef DEBUG			
	sprintf(gbuf, "exit: numports is now %d", numports); 
	report(gbuf);
#endif
}


int
chat_join(NextPass)
char   *NextPass;
{
	int     chanid;
	char    channame[CHANLEN];

	if (Usrec[seat].userid[0] == '\0')
	{
		Answer(WORK_FAIL);
		return -1;
	}

	bzero(chbuf, 254);

	NextPass = GetPass(NextPass, channame, CHANLEN);
	NextPass = PhaseSpace(NextPass);
	if (!strcmp(channame, DEF_CHANNAME))	/* ? */
	{
		Answer(OK_CMD);
		leave_channel();		
		return 0;
	}

	if ((chanid = get_chanid(channame)) < 0)
	{
		if ((chanid = create_chanid(channame)) < 0)
		{
			Answer(WORK_FAIL);
			return -1;
		}
	}

	if (chanid == Usrec[seat].ID)	/* lasehu */
	{
		Answer(WORK_FAIL);
		return -1;
	}

	if (Chanrec[chanid].passwd[0] == '\0' || !strcmp(Chanrec[chanid].passwd, NextPass))
	{
		Answer(OK_CMD);
		leave_channel();		
		Usrec[seat].ID = chanid;
		Chanrec[chanid].members++;
		sprintf(chbuf, "%s �[�J����W�D %s !\r\n", Usrec[seat].chatid, Chanrec[chanid].name);
		if (!BAD(Usrec[seat].bad, chanid))
			send_to_channel(chanid, chbuf);
		return 0;
	}
	else
		Answer(PASS_FAIL);
}


int
chat_msg(Token)
char   *Token;
{
	char    user[IDLEN];
	char    buf[80];
	int     chatuid;

	if (BAD(Usrec[seat].bad, Usrec[seat].ID))
	{
		Answer(PASS_FAIL);
		return -1;
	}	
	
	Token = GetPass(Token, user, IDLEN);
	Token = PhaseSpace(Token);
	sprintf(buf, "%s ������A��: %s\r\n", Usrec[seat].chatid, Token);
	chatuid = get_chatuid(user);
	if (chatuid >= 0 && Usrec[seat].ID == Usrec[chatuid].ID)	/* lasehu */
	{
		Answer(OK_CMD);
		send_to_user(chatuid, buf);
		sprintf(buf, "�A������ %s ��: %s\r\n", user, Token);	/* lasehu */
		send_to_user(seat, buf);	/* lasehu */
	}
	else
		Answer(USR_FAIL);
}


/*
#ifdef HAVE_CHATMSGALL
chat_msgall(msg)
char   *msg;
{
	int     i;
	char    buf[80];

	msg = PhaseSpace(msg);
	sprintf(buf, "%s �j�n��: %s\r\n", Usrec[seat].chatid, msg);
	Answer(OK_CMD);

	for (i = 0; i < MAXPORTS; i++)
	{
		if (Usrec[i].sock == -1)
			continue;

		send_to_user(i, buf);
	}
}

#endif
*/

chat_who(channel)
char   *channel;
{
	int     i, j;
	char    buf[80], *s;

	channel = PhaseSpace(channel);
	if (!strcmp(channel, DEF_CHANNAME))
	{
		Answer(OK_CMD);
		for (i = 0; i < MAXPORTS; i++)
		{
			if (Usrec[seat].ID == Usrec[i].ID && Usrec[i].userid[0] != '\0')
			{
				sprintf(buf, "%s\t%s\t%s\r\n", Usrec[i].userid, Usrec[i].chatid, Usrec[i].from);
				send_to_user(seat, buf);
			}
		}
	}
	else
	{
		if ((j = get_chanid(channel)) < 0)
		{
			Answer(WORK_FAIL);
			return -1;
		}
		Answer(OK_CMD);
		for (i = 0; i < MAXPORTS; i++)
		{
			if (Usrec[i].ID == j && Usrec[i].userid[0] != '\0')
			{
				sprintf(buf, "%s\t%s\t%s\r\n", Usrec[i].userid, Usrec[i].chatid, Usrec[i].from);
				send_to_user(seat, buf);
			}
		}
	}
	EndProt();
}


int
chat_whoall()
{
	int     i;
	int     chanid;

	Answer(OK_CMD);
	for (i = 0; i < MAXPORTS; i++)
	{
		if (Usrec[i].userid[0])
		{
			chanid = Usrec[i].ID;
			
			if (chanid > 0)
				sprintf(chbuf, "%s\t%s\t%s\r\n", Usrec[i].userid, Usrec[i].chatid, Chanrec[chanid].name);
			else
				sprintf(chbuf, "%s\t%s\t \r\n", Usrec[i].userid, Usrec[i].chatid); /* lasehu */
			send_to_user(seat, chbuf);
		}
	}
	EndProt();
}


int
chat_user(userpass)
char   *userpass;
{
	char    user[IDLEN];
	int     i;
	long    password, idpass;

	if (Usrec[seat].userid[0] != '\0')
	{
		Answer(WORK_FAIL);
		return -1;
	}
	userpass = GetPass(userpass, user, IDLEN);
	userpass = PhaseSpace(userpass);

	password = atol(userpass);
	idpass = atol(idpassstr);
#ifdef DEBUG
	sprintf(gbuf, "password: %l, idpass: %l", password, idpass);
	report(gbuf);
#endif		
	if (password != idpass + CHAT_KEY && password != idpass) /* lasehu */
	{
		Answer(WORK_FAIL);
		return -1;
	}

	for (i = 0; i < MAXPORTS; i++)
	{
		if (Usrec[i].userid[0] == '\0')
			continue;
		if (!strcmp(Usrec[i].userid, user))
		{
			Answer(NAME_FAIL);
			return -1;
		}
	}
	strcpy(Usrec[seat].chatid, user);
	strcpy(Usrec[seat].userid, user);	/* lasehu */
	if (password == idpass + CHAT_KEY)
		Usrec[seat].bmop = YEA;
	else
		Usrec[seat].bmop = NA;		
	Usrec[seat].ID = 0;	/* lasehu */
	memset(Usrec[seat].bad, 0, 5); 
	Answer(OK_CMD);

	return 0;
}


int
chat_nickname(nick)
char   *nick;
{
	int     i;

	nick = PhaseSpace(nick);

	for (i = 0; i < MAXPORTS; i++)
	{
		if (!strcmp(Usrec[i].chatid, nick))
		{
			Answer(NAME_FAIL);
			return -1;
		}
	}

	strncpy(Usrec[seat].chatid, nick, IDLEN - 1);
	Answer(OK_CMD);

	sprintf(chbuf, "%s �󴫰κ٬�: %s\r\n", Usrec[seat].userid, nick);
	if (!BAD(Usrec[seat].bad, Usrec[seat].ID))
		send_to_channel(Usrec[seat].ID, chbuf);
	return 0;
}


int
chat_listchan()
{
	int     i;
	char    buf[80];
	char    c;

	Answer(OK_CMD);
	for (i = 0; i < MAXCHANS; i++)
	{
		if (Chanrec[i].members == 0)
			continue;

		if (Chanrec[i].passwd[0] == '\0')
			c = 'N';
		else
			c = 'S';

		bzero(buf, 80);
		sprintf(buf, "%s\t%s\t%s\t%d\t%c\r\n", Chanrec[i].name, Chanrec[i].topic, Chanrec[i].op, Chanrec[i].members, c);
		send_to_user(seat, buf);
	}
	EndProt();
}


int
chat_ignore(bad)
char *bad;
{
	int i;
	int chatuid, chanid;
	
     bad = PhaseSpace(bad);

    chanid = Usrec[seat].ID;
    if (chanid > 0)
    {
	    if (strcmp(Chanrec[chanid].op, Usrec[seat].userid))
	    {
	    	Answer(PASS_FAIL);
	    	return -1;
	    }
    }
    else
    {
	    if (!Usrec[seat].bmop)
	    {
	    	Answer(PASS_FAIL);
	    	return -1;
	    }
    }

      chatuid = get_chatuid(bad);
    if (chatuid >= 0 && Usrec[seat].ID == Usrec[chatuid].ID)      
    {
    	for (i = 0; i < 5; i++)
    	{
    		if (Usrec[chatuid].bad[i] == 0)
    		{
/*    			strncpy(Usrec[chatuid].bad[i], Chanrec[chanid].name, CHANLEN - 1); */
			Usrec[chatuid].bad[i] = chanid + '0';
		 	break;
		 }
	 }
	 if (i == 5)	/* lasehu */
	 {
		memset(Usrec[chatuid].bad, 0, 5); 
/*  		strncpy(Usrec[chatuid].bad[0], Chanrec[chanid].name, CHANLEN - 1);	 */
		Usrec[chatuid].bad[0] = chanid + '0';
	 }
     	Answer(OK_CMD);
     	return 0;
    }
    Answer(WORK_FAIL);
    return -1;
	
}	


main()
{
	int     sock, length, flen, i;
	struct sockaddr_in server, client;
	char    buf[80];
	long    seed;

	signal(SIGHUP, SIG_IGN);
	signal(SIGINT, SIG_IGN);
	signal(SIGQUIT, SIG_IGN);
	signal(SIGPIPE, SIG_IGN);
	signal(SIGALRM, SIG_IGN);
	signal(SIGTERM, SIG_IGN);
	signal(SIGURG, SIG_IGN);
	signal(SIGTSTP, SIG_IGN);
	signal(SIGTTIN, SIG_IGN);
	signal(SIGTTOU, SIG_IGN);
	if ((i = fork()) == -1)
		exit(-1);
#ifdef DEBUG		
	if (i == 0)
		printf("\n\nchatroom server pid:[%d]\n\n", getpid());
#endif		
	if (i)
		exit(0);
	{
		int     s, ndescriptors = getdtablesize();

		for (s = 0; s < ndescriptors; s++);
		(void) close(s);
	}
	(void) open("/", O_RDONLY);
	(void) dup2(0, 1);
	(void) dup2(0, 2);
#ifdef SYSV
	setsid();
#else
	{
		int     tt = open("/dev/tty", O_RDWR);

		if (tt > 0)
		{
			ioctl(tt, TIOCNOTTY, (char *) 0);
			(void) close(tt);
		}
	}
#endif				/* !SYSV */
	report("starting up");
	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock < 0)
	{
		report("socket");
		return -1;
	}
	i = 1;
	setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char *) &i, sizeof(i));
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_port = htons((u_short )CHATPORT);
	if (bind(sock, (struct sockaddr *) & server, sizeof server) < 0)
	{
		report("bind() failed: exiting");
		return -1;
	}
	length = sizeof server;
	if (getsockname(sock, (struct sockaddr *) & server, &length) < 0)
	{
		report("getsockname() failed: exiting");
		return -1;
	}
	listen(sock, 5);

	numports = 0;

	for (i = 0; i < MAXCHANS; i++)
	{
		Chanrec[i].name[0] = '\0';
		Chanrec[i].topic[0] = '\0';
		Chanrec[i].members = 0;
		Chanrec[i].passwd[0] = '\0';
	}

	strncpy(Chanrec[0].name, DEF_CHANNAME, CHANLEN - 1);	/* lasehu */

	for (i = 0; i < MAXPORTS; i++)
	{
		Usrec[i].userid[0] = '\0';
		Usrec[i].chatid[0] = '\0';
		Usrec[i].from[0] = '\0';
		Usrec[i].sock = -1;
		Usrec[i].ID = -1;
		Usrec[i].bmop = NA;
		memset(Usrec[i].bad, 0, 5); 
	}

	while (1)
	{
		fd_set  readfds;
		int     sr;

		FD_ZERO(&readfds);
		FD_SET(sock, &readfds);
		for (i = 0; i < MAXPORTS; i++)
			if (Usrec[i].sock != -1)
				FD_SET(Usrec[i].sock, &readfds);
		if ((sr = select(getdtablesize(), &readfds, NULL, NULL, NULL)) < 0)
		{
			if (errno == EINTR)	/* lasehu */
				continue;
			report("select() failed: exiting");
			exit(-1);
		}
		if (sr == 0)	/* ? */
			continue;
		if (FD_ISSET(sock, &readfds))
		{
			int     s;
			char seedstr[20];

			flen = sizeof(client);
			s = accept(sock, (struct sockaddr *) & client, &flen);
			if (s == -1)	/* lasehu */
				continue;
			seed = rand();
			sprintf(buf, "Formosa ��Ѩt�� Ver. 1.0.0 by NSYSU\n\r");
			write(s, buf, strlen(buf));
			sprintf(buf, "%ld\r\n", seed);
			write(s, buf, strlen(buf));
			sprintf(seedstr, "%d", seed);
			idpassstr = mycrypt(seedstr); 
			get_client_name(&client, buf, sizeof(buf));

/* �ڵ����~�ۦ�s�u */
/*
   if (strcmp(MYHOSTIP, buf) && strcmp("127.0.0.1", buf))
   {
   close(s);
   continue;
   }
 */
#ifdef DEBUG
			sprintf(gbuf, "before seek empty seat");
			report(gbuf);
#endif			 
			if (numports == MAXPORTS)
			{
				report("reach max port number");	/* lasehu */
				close(s);
			}
			else
			{
				for (i = 0; i < MAXPORTS; i++)
				{
					if (Usrec[i].sock == -1)
					{
						Usrec[i].sock = s;
						Usrec[i].ID = 0;
						strcpy(Usrec[i].from, buf);
						break;
					}
				}
				numports++;
#ifdef DEBUG
				sprintf(gbuf, "entry: numports is now %d", numports);
				report(gbuf);
#endif
				if (sr == 1)
					continue;
			}
		}

		for (seat = 0; seat < MAXPORTS; seat++)
		{
			int     keynum;
			char   *NextPass;
			char    keypass[PROTOLEN];

			if (Usrec[seat].sock == -1)
				continue;
			if (FD_ISSET(Usrec[seat].sock, &readfds))
			{
				char    rcvbuf[512];
				int     cc;

		re_read:
				bzero(rcvbuf, sizeof(rcvbuf));
				cc = read(Usrec[seat].sock, rcvbuf, sizeof(rcvbuf));
				if (cc == 0)
				{
					chat_logout(seat);
					if (numports == 0)
					{
						report("normal termination");
/*---
					   exit(0) ;
*//* last person closed connection */
						break;	/* lasehu */
					}
					continue;
				}
				NextPass = GetPass(rcvbuf, keypass, PROTOLEN);
				keynum = GetPassNum(keypass);

				if (Usrec[seat].userid[0] == '\0' && keynum != CHAT_USRID)
				{
					Answer(WORK_FAIL);
					continue;
				}

				switch (keynum)
				{
					case CHAT_JOIN:
						chat_join(NextPass);
						break;
					case CHAT_USRID:
						if (chat_user(NextPass) == -1)
							chat_logout(seat);	/* lasehu */
						else
						{
							sprintf(chbuf, "*** %s �i���o!\n", Usrec[seat].chatid);
							send_to_channel(Usrec[seat].ID, chbuf);
						}
						break;
					case CHAT_QUIT:
						sprintf(chbuf, "*** %s �^�a�o!\n", Usrec[seat].chatid);
						send_to_channel(Usrec[seat].ID, chbuf);
						chat_logout(seat);
						break;						
					case CHAT_TOPIC:
						chat_topic(NextPass);
						break;
					case CHAT_PASSWD:
						chat_passwd(NextPass);
						break;
					case CHAT_IGNORE:
						chat_ignore(NextPass);
						break;
					case CHAT_WHO:
						chat_who(NextPass);
						break;
					case CHAT_WHOALL:
						chat_whoall();
						break;
					case CHAT_MSG:
						chat_msg(NextPass);
						break;
#ifdef HAVE_CHATMSGALL
					case CHAT_MSGALL:
						chat_msgall(NextPass);
						break;
#endif
					case CHAT_NICKNAME:
						chat_nickname(NextPass);
						break;
					case CHAT_LISTCHAN:
						chat_listchan();
						break;
					case CHAT_SPEAK:	/* send all data to user */
						if (Usrec[seat].userid[0])
						{
								NextPass = PhaseSpace(NextPass);
/* lasehu
   sprintf(chbuf, "%s> %s\r\n", Usrec[seat].chatid, NextPass);
 */

/* lasehu
			sprintf(chbuf, "%s: %s\r\n", Usrec[seat].chatid, NextPass);
*/
								sprintf(gbuf, "%s", Usrec[seat].chatid);
								gbuf[IDLEN - 1] = '\0';
								strcat(gbuf, ":");
								sprintf(chbuf, "%-12.12s %s\r\n", gbuf, NextPass);
								chbuf[80] = '\0';
								if (!BAD(Usrec[seat].bad, Usrec[seat].ID))
									send_to_channel(Usrec[seat].ID, chbuf);
							}
					/*
					   all complete messages end in
					   newline
					*/
						if (rcvbuf[cc - 1] == '\0' || rcvbuf[cc - 1] == '\n')
							continue;

						goto re_read;
						break;
					case -1:
					default:
						Answer(CMD_ERROR);
				}
			}	/* if */
		}		/* for loop */
	}			/* while loop */
}
