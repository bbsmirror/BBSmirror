/*
 * About all function processing article, 
 *    including mail, post, and treasure
 */

#include "bbs.h"
#include "tsbbs.h"


char DefEmailAddr[STRLEN] = "\0";


void
include_ori(rfile, wfile)	/* include original atricle */
char   *rfile, *wfile;
{
	FILE   *fpr, *fpw;
	char   *author = NULL, *name = NULL, *foo, *hptr, *end;

	move(3, 0);
	prints("%s (y/n) ? [y]: ", _msg_include_ori);
	if (igetkey() == 'n')
		return;

	if ((fpw = fopen(wfile, "w")) == NULL)
		return;
	if ((fpr = fopen(rfile, "r")) == NULL)
	{
		fclose(fpw);
		return;
	}

	fgets(genbuf, sizeof(genbuf), fpr);	/* get header 'From' */
	if ((foo = strchr(genbuf, '\n')))
		*foo = '\0';

	if (((hptr = strstr(genbuf, "�o�H�H:")) && (hptr = hptr + 7))
	    || ((hptr = strstr(genbuf, "�o�H�H�G")) && (hptr = hptr + 8))
	    || ((hptr = strstr(genbuf, "By:")) && (hptr = hptr + 3))
	    || ((hptr = strstr(genbuf, "From:")) && (hptr = hptr + 5)))
	{
		while (*hptr == ' ')
			hptr++;
		if (*hptr)
		{
			end = hptr;
			while (*end)
				end++;
			if ((foo = strchr(hptr, '"')))
			{
				if ((name = strtok(hptr, "\"")) != NULL)
				{
					hptr = name;
					while (*hptr)
						hptr++;
					if (hptr < end)
						hptr++;
					author = strtok(hptr, "< ");
					if ((foo = strchr(author, '>')))
						*foo = '\0';
				}
			}
			else
			{
				if ((author = strtok(hptr, " ")) != NULL)
				{
					hptr = author;
					while (*hptr)
						hptr++;
					if (*hptr) 
					{
						if (hptr < end)
							hptr++;
						name = strtok(hptr, "(");
						if ((foo = strchr(name, ')')))
							*foo = '\0';
					}
				}
			}
			if (author != NULL && name != NULL)
				fprintf(fpw, "==> %s (%s) %s:\n", author, name, _msg_quote_said);
			else if (author != NULL)
				fprintf(fpw, "==> %s %s:\n", author, _msg_quote_said);
		}
	}

	while (fgets(genbuf, 256, fpr) && genbuf[0] != '\n');	/* strip Header */

	while (fgets(genbuf, sizeof(genbuf), fpr))
	{
		if (genbuf[0] == '\n')	/* ignore empty line */
			continue;
		if ((genbuf[0] == '>' && genbuf[INCLUDE_DEPTH - 1] == '>')
		    || (genbuf[0] == ':' && genbuf[INCLUDE_DEPTH - 1] == ':'))
		{
			continue;
		}
		if (!strcmp(genbuf, "--\n"))	/* strip signature */
			break;
		fprintf(fpw, ">%s", genbuf);	/* add quote */
	}
	fclose(fpw);
	fclose(fpr);
	chmod(wfile, 0600);
}


void
include_sig(userid, wfile)	/* include signature: support multiple signatures */
char   *userid, *wfile;
{
	int     sig_no = 0, avalsig = 0, i; /* default: don't include signature */
	FILE   *fpr, *fpw;
	struct stat st;
	static short shownote = YEA;

	if (HAS_FLAG(SIG_FLAG))
	{
		if (shownote)
		{
			outs(_msg_no_use_sig);
			getkey();
			shownote = NA;
		}
		return;
	}

	sethomefile(genbuf, userid, UFNAME_SIGNATURES);
	if (stat(genbuf, &st) == -1 || st.st_size == 0)
		return;
	if ((fpr = fopen(genbuf, "r")) == NULL)
		return;

	move(4, 0);
	
	for (i = 0; i < (MAX_SIG_LINES * MAX_SIG_NUM) && fgets(genbuf, sizeof(genbuf), fpr); i++)
	{
		if (i % MAX_SIG_LINES == 0)
		{
			avalsig++;
			prints("[1;36m[%s #%d][m\n", _msg_signature, avalsig);
		}
		outs(genbuf);
	}
	prints("[m\n%s [1-%d] ? [0:%s]: ", _msg_include_which_sig, MAX_SIG_NUM, _msg_no_include_sig);
	
	sig_no = (getkey() - '0');

	if (sig_no == 0)
	{
		fclose(fpr);
		return;
	} 
	else if (sig_no > avalsig | sig_no < 0)
		sig_no = 1;
		
	if ((fpw = fopen(wfile, "a")) != NULL)
	{
		fputs("\n\n\n\n--\n", fpw);

		fseek(fpr, 0, SEEK_SET);
		i = (sig_no - 1) * MAX_SIG_LINES;
		while (i-- && fgets(genbuf, sizeof(genbuf), fpr))
			 /* NULL STATEMENT */ ;
			 
		i = MAX_SIG_LINES;
		while (i-- && fgets(genbuf, sizeof(genbuf), fpr))
			fputs(genbuf, fpw);
			
		fputs("[m\n", fpw);
		fclose(fpw);
	}
	chmod(wfile, 0600);
	fclose(fpr);
}


int
pack_article(direct)	/* really remove article which were mark deleted */
char   *direct;
{
	int     fdr, fdw;
	FILEHEADER *fhr = &tmp_fh;
	char    fndirty[PATHLEN], fnnew[PATHLEN], fndel[PATHLEN];
	short result = 0;

	sprintf(fnnew, "%s.new", direct);
	sprintf(fndel, "%s.del", direct);
/* lasehu
   tempfile(fnnew);
   tempfile(fndel);
 */
	if ((fdr = open(direct, O_RDONLY)) < 0)
		return -1;
	if ((fdw = open(fnnew, O_WRONLY | O_CREAT | O_TRUNC, 0644)) < 0)
	{
		close(fdr);
		return -1;
	}
	flock(fdr, LOCK_EX);
	while (read(fdr, fhr, FH_SIZE) == FH_SIZE)
	{
		if (fhr->accessed & FILE_DELE)
		{
			setdotfile(fndirty, direct, fhr->filename);
			unlink(fndirty);
		}
		else
		{
			if (write(fdw, fhr, FH_SIZE) != FH_SIZE)
			{
				result = -1;
				break;
			}
		}
	}
	close(fdw);
	flock(fdr, LOCK_UN);
	close(fdr);
	if (result == 0)
	{
		if (mymv(direct, fndel) == 0)
		{
			if (mymv(fnnew, direct) == 0)
			{
				unlink(fndel);
				return 0;
			}
			mymv(fndel, direct);
		}
	}
	unlink(fnnew);
	return -1;
}


int
readed_article(ent, finfo, direct)	/* mark article readed */
int     ent;
FILEHEADER *finfo;
char   *direct;
{
	if (in_mail)
	{
		int     fd;

		if (finfo->accessed & FILE_READ)
			return;
		if (ent < 1)	/* debug */
			return;
		finfo->accessed |= FILE_READ;
		if ((fd = open(direct, O_RDWR)) > 0)
		{
			/* ignore file lock to speed-up processing */
			if (lseek(fd, (off_t) ((ent - 1) * FH_SIZE), SEEK_SET) != -1)
				write(fd, finfo, FH_SIZE);
			close(fd);
		}
	}
	else if (in_board)
	{
		if (brc_unread(finfo->artno))
			brc_addlist(finfo->artno);
	}
	return;
}


int
title_article(ent, finfo, direct)	/* modify the title of article */
int     ent;
FILEHEADER *finfo;
char   *direct;
{
	char    title[TTLEN + 1];
	FILEHEADER *fhr = &tmp_fh;

	if (finfo->accessed & FILE_DELE)
		return R_NO;
	if (!HAS_PERM(PERM_SYSOP))
	{
		if ((in_board && strcmp(curuser.userid, finfo->owner)) ||
		    (!in_mail && !in_board && !isBM))
		{
			return R_NO;
		}
	}

	if (!getdata(b_line, 0, _msg_ent_new_title, title, sizeof(title), DOECHO, NULL))
		return R_LINE;
	if (get_record(direct, fhr, FH_SIZE, ent) == -1)		
		return R_LINE;
	strcpy(fhr->title, title);
	if (substitute_record(direct, fhr, FH_SIZE, ent) == -1)
		return R_LINE;

	if (finfo->accessed & FILE_TREA)
		return NEWDIRECT;
	else
	{
		char    fnmodify[PATHLEN], fnnew[PATHLEN];
		FILE   *fpr, *fpw;
		short   textbegin = NA;
		char *ptr;
	
		setdotfile(fnmodify, direct, finfo->filename);
		sprintf(fnnew, "tmp/title_art_new_%s", curuser.userid);	

		if ((fpr = fopen(fnmodify, "r")) == NULL)
			return R_LINE;

		if ((fpw = fopen(fnnew, "w")) == NULL)
		{
			fclose(fpr);
			return R_LINE;
		}
		while(fgets(genbuf, sizeof(genbuf), fpr))
		{
			if ((ptr = strchr(genbuf, '\n')))
				*ptr = '\0';
			if (!textbegin)
			{
				if (genbuf[0] == '\0')
				{
					fprintf(fpw, "\n");
					textbegin = YEA;
					continue;
				}
				if (!strncmp(genbuf, _str_header_title, 7))
				{
					fprintf(fpw, "%s%s\n", _str_header_title, title); 
					continue;
				}
			}
			fprintf(fpw, "%s\n", genbuf);
		}
		fclose(fpw);
		fclose(fpr);
		if (mymv(fnnew, fnmodify) == 0)
			return NEWDIRECT;	
	}
	return R_LINE;	
}


int
edit_article(ent, finfo, direct)	/* edit the article existed */
int     ent;			/* unused */
FILEHEADER *finfo;
char   *direct;
{
	char    fnori[PATHLEN], fnedit[PATHLEN], fnnew[PATHLEN];
	time_t now = time(NULL);	      
	FILE *fpori, *fpedit, *fpnew;	      
	char *ptr;
	short textbegin = NA;

	if (finfo->accessed & FILE_DELE || finfo->accessed & FILE_TREA)
		return R_NO;

	if (!HAS_PERM(PERM_SYSOP))
	{
		if ((!in_mail && in_board && strcmp(finfo->owner, curuser.userid))
		    || (!in_mail && !in_board && !isBM))
		{
			return R_NO;
		}
	}

	update_umode(MODIFY);

	setdotfile(fnori, direct, finfo->filename);
	sprintf(fnedit, "tmp/edit_text_%s", curuser.userid);
	sprintf(fnnew, "tmp/edit_new_%s", curuser.userid);

	if ((fpori = fopen(fnori, "r")) == NULL)
		return R_NO;
	if ((fpedit = fopen(fnedit, "w")) == NULL)
	{
		fclose(fpori);
		return R_NO;
	}
	while (fgets(genbuf, sizeof(genbuf), fpori))
	{
		if ((ptr = strchr(genbuf, '\n')))
			*ptr = '\0'; 
		if (!textbegin)
		{
			if (genbuf[0] == '\0')
				textbegin = YEA;
			continue;
		}
		fprintf(fpedit, "%s\n", genbuf);
	}
	fclose(fpedit);
		
	if (vedit(fnedit, NULL))
	{
		fclose(fpori);
		unlink(fnedit);
		outs(_msg_aborted);
		pressreturn();
		return R_FULL;
	}

	if ((fpedit = fopen(fnedit, "r")) == NULL)
	{
		fclose(fpori);
		unlink(fnedit);
		return R_FULL;
	}
	if ((fpnew = fopen(fnnew, "w")) == NULL)
	{
		fclose(fpori);
		fclose(fpedit);
		unlink(fnedit);
		return R_FULL;
	}
	fseek(fpori, 0, SEEK_SET);
	while (fgets(genbuf, sizeof(genbuf), fpori))
	{
		if ((ptr = strchr(genbuf, '\n')))
			*ptr = '\0'; 
		if (genbuf[0] == '\0')
		{
			fprintf(fpnew, "\n");
			break;
		}
		fprintf(fpnew, "%s\n", genbuf);
	}
	fprintf(fpnew, "\n [%s, %s %s] \n\n", Ctime(&now), curuser.userid, _msg_has_edit_art);	
	while (fgets(genbuf, sizeof(genbuf), fpedit))
	{
		if ((ptr = strchr(genbuf, '\n')))
			*ptr = '\0'; 
		fprintf(fpnew, "%s\n", genbuf);
	}
	fclose(fpnew);
	fclose(fpedit);
	fclose(fpori);
	unlink(fnedit);
	
	if (mymv(fnnew, fnori) == 0)
		outs(_msg_finished);
	else
		outs(_msg_aborted);
	pressreturn();
	return R_FULL;
}


#ifdef HAVE_CROSSPOST
int
cross_article(ent, finfo, direct)	/* copy article to another board */
int     ent;			/* unused */
FILEHEADER *finfo;
char   *direct;
{
	char    bname[BNAME_LEN + 1];
	struct bword *bwtmp;
	char    postpath[PATHLEN], fnori[PATHLEN], title[STRLEN] = "\0";
	int     result;
/*
	static short numcrosspost = 0;

   if (curuser.userlevel < 100)
   return R_NO;
    msg("[�Ф���K�峹�󤣬������Q�װ�]");
    refresh();
    sleep(2);
    getkey();
	if (numcrosspost >= 5)
	{
		msg("�и`��ϥ���K�\��.");
		return R_LINE;
	}
*/	
	if (!getdata(b_line, 0, _msg_cross_which_board, bname, sizeof(bname), ECHONOSP, NULL))
		return R_LINE;
	if (!strcmp(curb->word->name, bname)
	    || !(bwtmp = (struct bword *) cmp_wlist(topb, bname, board_list_cmp)))
	{
		msg(_msg_err_boardname);
		getkey();
		return R_LINE;
	}
	if (check_post_perm(bwtmp->word) == -1)
		return R_FULL;

	setboardfile(postpath, bname, "\0");
	setdotfile(fnori, direct, finfo->filename);

	if (strncmp(finfo->title, _str_crosspost, 6))
		sprintf(title, "%s %s", _str_crosspost, finfo->title);
	else
		sprintf(title, "%s", finfo->title);

	clear();
	
	result = prepare_crosspost(postpath, fnori, title);
	
	move(b_line - 1, 0);
	if (result == -1)
		outs(_msg_fail);
	else
	{
/*	
		numcrosspost++;
*/		
		outs(_msg_finish);
	}
	pressreturn();

	return R_FULL;
}

#endif


int
reserve_article(ent, finfo, direct)	/* mark article reserved */
int     ent;
FILEHEADER *finfo;
char   *direct;
{
	int     ch;

	if (finfo->accessed & FILE_DELE || finfo->accessed & FILE_TREA)
		return R_NO;
	if ((!in_mail && !in_board) 
	    || (!in_mail && !HAS_PERM(PERM_SYSOP) && !isBM))
	{
		return R_NO;
	}
	
	msg(_msg_reserve_article);
	switch ((ch = igetkey()))
	{
		case 'm':
			if (!(finfo->accessed & FILE_RESRV))
				reserve_one_article(ent, finfo, direct, 'm');
			break;
		case 'u':
			if (finfo->accessed & FILE_RESRV)
				reserve_one_article(ent, finfo, direct, 'u');
			break;
		default:
			break;
	}
	return R_LINE;
}


int
batch_del_article(ent, finfo, direct)	/* mark article deleted in batch mode */
int     ent;			/* unused */
FILEHEADER *finfo;		/* unused */
char   *direct;
{
	int     n1, n2;

	if (!HAS_PERM(PERM_SYSOP) && !in_mail)
	{
		if (!in_board || !isBM)
			return R_NO;
	}

	clear();
	outs("[���R��] : �̽g�Ƹ��X�d��");
	getdata(1, 0, "�q�ĴX���}�l ? ", genbuf, 6, ECHONOSP, NULL);
	n1 = atoi(genbuf);
	getdata(2, 0, "��ĴX������ ? ", genbuf, 6, ECHONOSP, NULL);
	n2 = atoi(genbuf);
	if (n1 <= 0 || n2 <= 0 || n2 < n1)
		return R_FULL;
	prints("\n�R���� '%d' �g�ܲ� '%d' �g, �T�w�� ? (y/n) [n] : ", n1, n2);
	if (igetkey() != 'y')
		return R_FULL;
		
	outs("\n");
	outs(_msg_in_processing);
	refresh();
	if (del_articles(direct, n1, n2) == -1)
	{
		outs("\n");
		outs(_msg_failed);
	}
	else
	{
		if (in_mail)
			ever_del_mail = YEA;			
		if (!in_board && !in_mail)
			pack_article(direct);	/* treasure need deleted immediately */
		outs(_msg_finished);
	}
	pressreturn();
	return NEWDIRECT;
}


int
read_article(ent, finfo, direct)	/* prompt, when article display done */
int     ent;
FILEHEADER *finfo;
char   *direct;
{
	static int updown = CAREYDOWN;
	char    fname[PATHLEN];

	if (finfo->accessed & FILE_DELE)
		return updown;

	setdotfile(fname, direct, finfo->filename);
	more(fname, NA);
	readed_article(ent, finfo, direct);
	msg("[0;37;44m[r][y]:�^�� [��][��][Space][n]:�U�g [��][p]:�W�g [m]:�H�X [d]:�R�� [��][q]:�h�X[m");
	/*
	 * If cursor at the right side of two-bit word, 
	 * some system would send BackSpace or Del key twice.
	 * To avoid this problem, move cursor to first word.
	 */
	move(b_line, 0);
	switch (igetkey())
	{
		case KEY_RIGHT:
		case KEY_DOWN:
		case SP:
		case 'n':
			return (updown = CAREYDOWN);
		case KEY_UP:
		case 'p':
			return (updown = CAREYUP);
		case 'r':
		case 'y':
			if (in_mail)
				reply_mail(finfo, direct);
			else
				reply_post(finfo, direct);
			return NEWDIRECT;
		case 'm':
			mail_article(ent, finfo, direct);
			return updown;
		case 'd':
			del_article(ent, finfo, direct);
			return updown;
		case 'q':
		case KEY_LEFT:
		default:
			break;
	}
	return R_FULL;	
}


int
create_mail_socket()	/* open socket to mail server */
{
	char   *s[2];
	int     ms;

	s[0] = MAILSERVER1;
	ms = ConnectServer(*s, SMTPPORT, TCP);
	if (ms < 0)
	{
		s[0] = MAILSERVER2;
		ms = ConnectServer(*s, SMTPPORT, TCP);
	}
	if (ms > 0)
	{
		if (!net_gets(ms, genbuf, sizeof(genbuf)))
		{
			close_mail_socket(ms);
			return -1;
		}		
		if (strncmp(genbuf, "220 ", 4))
		{		
			close_mail_socket(ms);
			return -1;
		}
		net_printf(ms, "HELO %s\n", MYHOSTNAME);
		if (!net_gets(ms, genbuf, sizeof(genbuf)))		
		{
			close_mail_socket(ms);
			return -1;
		}		
		if (strncmp(genbuf, "250 ", 4))
		{		
			close_mail_socket(ms);
			return -1;
		}
	}
	return ms;
}


int
close_mail_socket(ms)		/* close socket to mail server */
int     ms;
{
	net_printf(ms, "\nQUIT\n");
	net_gets(ms, genbuf, sizeof(genbuf));
	DisconnectServer(ms);
	return 0;
}


#ifdef BBSLOG_MAIL
void
MailLog(string)
char   *string;
{
	time_t  now;
	int     fd;
	char    buf[128];
	char    timestr[22];

	time(&now);
	strftime(timestr, sizeof(timestr), "%x %X", localtime(&now));
	sprintf(buf, "%s %-12.12s %s\n",
		timestr, curuser.userid, string);
	if ((fd = open(PATH_MAILLOG, O_APPEND | O_CREAT | O_WRONLY, 0600)) > 0)
	{
		write(fd, buf, strlen(buf));
		close(fd);
	}
}
#endif


int
telnet_mail(ms, fname, from, to, title)	/* send mail by pure direct connect */
int     ms;
char   *fname, *from, *to, *title;
{
	FILE   *fs;

	if ((fs = fopen(fname, "r")) == NULL)
		return -1;
	sleep(1);		/* lasehu: wait for mail server response */
	net_printf(ms, "MAIL FROM:%-s.bbs@%-s\n", from, MYHOSTNAME);
	if (!net_gets(ms, genbuf, sizeof(genbuf)))
		return -1;
	if (strncmp(genbuf, "250 ", 4))
		return -1;
	net_printf(ms, "RCPT TO:%-s\n", to);
	if (!net_gets(ms, genbuf, sizeof(genbuf)))
		return -1;
	if (strncmp(genbuf, "250 ", 4))
		return -1;
	net_printf(ms, "DATA\n");
	if (!net_gets(ms, genbuf, sizeof(genbuf)))
		return -1;
	
	if (strncmp(genbuf, "354 ", 4))
		return -1;
	net_printf(ms, "From: %-s.bbs@%-s\n", from, MYHOSTNAME);
	net_printf(ms, "To: %-s\n", to);
	net_printf(ms, "Subject: %-s\n", title);
	net_printf(ms, "X-Disclaimer: [%s] �糧�H���e�����t�d\n\n", BBSTITLE);
	while (fgets(genbuf, sizeof(genbuf), fs))
		net_printf(ms, "%s", genbuf);
	fclose(fs);
	net_printf(ms, "\n.\n");
	if (!net_gets(ms, genbuf, sizeof(genbuf)))
		return -1;
	if (strncmp(genbuf, "250 ", 4))
		return -1;
	net_printf(ms, "RSET\n");
	if (!net_gets(ms, genbuf, sizeof(genbuf)))
		return -1;
#ifdef BBSLOG_MAIL
	MailLog(to);
#endif
	return 0;
}


int
del_one_article(ent, finfo, direct, option)	/* mark one article deleted */
int     ent;
FILEHEADER *finfo;
char   *direct;
char    option;
{
	int     fd;
	FILEHEADER *fhr = &tmp_fh;

	if ((fd = open(direct, O_RDWR)) < 0)
		return -1;
	/* ignore file lock to speed-up processing */
	if (lseek(fd, (off_t) ((ent - 1) * FH_SIZE), SEEK_SET) != -1 
	    && read(fd, fhr, FH_SIZE) == FH_SIZE)
	{
		if (option == 'd')
		{
			fhr->accessed |= FILE_DELE;
			finfo->accessed |= FILE_DELE;
		}
		else
		{
			fhr->accessed &= ~FILE_DELE;
			finfo->accessed &= ~FILE_DELE;
		}
		if (lseek(fd, -((off_t) FH_SIZE), SEEK_CUR) != -1)
		{
			if (write(fd, fhr, FH_SIZE) == FH_SIZE)
			{
				close(fd);
				return 0;
			}
		}
	}
	close(fd);
	return -1;
}


int
del_articles(direct, n1, n2)	/* mark articles deleted in batch mode */
char   *direct;
int     n1, n2;
{
	int     fd;
	FILEHEADER *fhr = &tmp_fh;

	if ((fd = open(direct, O_RDWR)) < 0)
		return -1;
	if (lseek(fd, (off_t) ((n1 - 1) * FH_SIZE), SEEK_SET) == -1)
	{
		close(fd);
		return -1;
	}
	flock(fd, LOCK_EX);
	while (n1++ <= n2 && read(fd, fhr, FH_SIZE) == FH_SIZE)
	{
		if (fhr->accessed & FILE_RESRV)
			continue;
		fhr->accessed |= FILE_DELE;
		lseek(fd, -((off_t) FH_SIZE), SEEK_CUR);
		if (write(fd, fhr, FH_SIZE) != FH_SIZE)
		{
			flock(fd, LOCK_UN);
			close(fd);
			return -1;
		}
	}
	flock(fd, LOCK_UN);
	close(fd);
	return 0;
}


int
del_article(ent, finfo, direct)	/* mark article deleted */
int     ent;
FILEHEADER *finfo;
char   *direct;
{
	int     ch;

	if (in_mail)
	{
		msg("<<�R���峹>>: (m)�аO���R�� (u)�����R�� (c)������ ? [c]: ");
		ch = igetkey();
		if (ch != 'm' && ch != 'u')
			ch = 'c';
	}
	else if (in_board)
	{
		if (HAS_PERM(PERM_SYSOP) || isBM)
		{
			msg("<<�R���峹>>: (m)�аO���R�� (u)�����R�� (r)�ñH�^����@�� (c)������ ? [c]: ");
			ch = igetkey();
			if (ch != 'm' && ch != 'u' && ch != 'r')
				ch = 'c';
		}
		else if (!strcmp(finfo->owner, curuser.userid))
		{
			msg("<<�R���峹>>: �R����Y�L�k�Ϧ^, �T�w�� ? [n] : ");		
			if (igetkey() == 'y')
				ch = 'm';
			else
				ch = 'c';
		}
		else
			return R_NO;
	}
	else
	{
		if (!HAS_PERM(PERM_SYSOP) && !isBM)
			return R_NO;
		if (finfo->accessed & FILE_TREA)
			return del_direct(ent, finfo, direct);
		msg("<<�R���峹>>: �R����Y�L�k�Ϧ^, �T�w�� ? [n] : ");
		ch = igetkey();
		if (ch == 'y')
			ch = 'm';
		else
			ch = 'c';
	}
	switch (ch)
	{
		case 'r':
			if (!strchr(finfo->owner, '@'))
			{
				setdotfile(genbuf, direct, finfo->filename);
				bbs_localmail(genbuf, finfo->owner, "[�H��R���q��]");
			}
		case 'm':
			if (!(finfo->accessed & FILE_DELE))
			{
				if (del_one_article(ent, finfo, direct, 'd') == 0)
				{
					if (in_mail)
						ever_del_mail = YEA;
					else if (in_board)
					{
						if (finfo->owner[0] != '#' && (curb->word->type == 'B' || curb->word->type == 'O'))
#ifdef EMAIL_LIMIT
						if (finfo->owner_ident == 7)
#endif	
							append_news(curb->word->name, finfo->filename, 'D');
					}
					else
					{
						pack_article(direct);	/* treasure need deleted immediately */
						return NEWDIRECT;
					}
				}
			}
			break;
		case 'u':
			if (finfo->accessed & FILE_DELE)
				del_one_article(ent, finfo, direct, 'u');
			break;
		default:
			break;
	}
	return R_LINE;
}


int
reserve_one_article(ent, finfo, direct, option)	/* mark one article reserved */
int     ent;
FILEHEADER *finfo;
char   *direct;
char    option;
{
	int     fd;
	FILEHEADER *fhr = &tmp_fh;

	if ((fd = open(direct, O_RDWR)) < 0)
		return -1;
	/* ignore file lock to speed-up processing */
	if (lseek(fd, (off_t) ((ent - 1) * FH_SIZE), SEEK_SET) != -1 
	    && read(fd, fhr, FH_SIZE) == FH_SIZE)
	{
		if (option == 'm')
		{
			fhr->accessed |= FILE_RESRV;
			finfo->accessed |= FILE_RESRV;
		}
		else
		{
			fhr->accessed &= ~FILE_RESRV;
			finfo->accessed &= ~FILE_RESRV;
		}
		if (lseek(fd, -((off_t) FH_SIZE), SEEK_CUR) != -1)
		{
			if (write(fd, fhr, FH_SIZE) == FH_SIZE)
			{
				close(fd);
				return 0;
			}
		}
	}
	close(fd);
	return -1;
}


int
mail_article(ent, finfo, direct)	/* mail article to someone */
int     ent;			/* unused */
FILEHEADER *finfo;
char   *direct;
{
	char    buf[STRLEN];

	if (finfo->accessed & FILE_DELE || finfo->accessed & FILE_TREA)
		return R_NO;
#ifdef EMAIL_LIMIT
	if (curuser.ident != 7)
	{
		msg(_msg_sorry_email);
		getkey();
		return R_LINE;
	}
#endif

	msg("<<�H�X�峹>> (n)�ߨ�H (m)�@�аO (u)�����аO (t)�H�X�аO (c)������? [c] : ");
	switch (igetkey())
	{
		case 'm':
			if (!cmp_wlist(artwtop, finfo->filename, strcmp))
				artwtop = add_wlist(artwtop, finfo->filename, malloc_str);
			break;
		case 'u':
			if (artwtop)
				cmpd_wlist(&artwtop, finfo->filename, strcmp, free);
			break;
		case 'n':
			setdotfile(buf, direct, finfo->filename);
			if (AskEmailTo(DefEmailAddr, sizeof(DefEmailAddr)) == 0)
			{
				int result;
				
				msg(_msg_in_processing);
				refresh();
				if (is_internet_email(DefEmailAddr))
					result = bbs_inetmail(0, buf, NULL, DefEmailAddr, finfo->title, ASK_UUENCODE);
				else
					result = bbs_localmail(buf, DefEmailAddr, finfo->title);
				if (result == -1)
					msg(_msg_fail);
				else
					msg(_msg_finish);
				getkey();
			}
			break;
		case 't':	
			if (artwtop)
			{
				msg("<<���H�H>> �N���e�аO���峹�@���H�X (y/n) ? [y]: ");
				if (igetkey() != 'n')
				{
					if (AskEmailTo(DefEmailAddr, sizeof(DefEmailAddr)) == 0)
					{
						if (mail_articles(direct, DefEmailAddr) == -1)
							msg(_msg_fail);
						else
							msg(_msg_finish);
						getkey();
					}
				}
			}
			break;
		default:
			break;
	}
	return R_LINE;
}


int
mail_articles(direct, to)	/* mail article to someone in batch mode */
char   *direct, *to;
{
	char    fname[STRLEN], uuname[STRLEN];
	int     fd, ms, uuencode;
	FILEHEADER *fhr = &tmp_fh;

	if ((fd = open(direct, O_RDONLY)) < 0)
		return -1;
	if ((ms = create_mail_socket()) < 0)
	{
		close(fd);
		return -1;
	}
	
	msg("�H�쯸�~���H�n�s�X(uuencode)�� (y/n) ? [n]: ");
	if (igetkey() == 'y')
		uuencode = YEA;
	else
		uuencode = NA;

	msg(_msg_in_processing);
	refresh();
	while (read(fd, fhr, FH_SIZE) == FH_SIZE)
	{
		if (fhr->accessed & FILE_DELE || fhr->accessed & FILE_TREA)
			continue;
		if (!cmp_wlist(artwtop, fhr->filename, strcmp))
			continue;
		uuname[0] = '\0';
		setdotfile(fname, direct, fhr->filename);
		if (is_internet_email(to))
		{
			if (uuencode)
				uuencode_file(fname, uuname);
			bbs_inetmail(ms, fname, uuname, to, fhr->title, NOASK_UUENCODE);
		}
		else
			bbs_localmail(fname, to, fhr->title);
		if (uuname[0])
			unlink(uuname);
	}
	close_mail_socket(ms);
	close(fd);
	return 0;
}


/* char srchfword[] = "a<["; */
char    srchbword[] = "A>]";
char    srchassoc[] = "[]";
char    srchauthor[] = "aA";


#define SCMP_AUTHOR	0x01
/* #define SCMP_TITLE	0x02 */
#define SCMP_ASSOC	0x04
/* #define SCMP_FORWARD	0x10 */
#define SCMP_BACKWARD	0x20


/*
 * ����r�j�M
 */
search_article(direct, ent, cmps_str, op)
register char *direct, *cmps_str, op;
register int ent;
{
	FILEHEADER *fhr = &tmp_fh;
	int     fd;
	char   *takestr, author[STRLEN];
	int     cmps_kind = 0;

	if (cmps_str == NULL || cmps_str[0] == '\0')
		return -1;

	if (strchr(srchbword, op))
		cmps_kind = SCMP_BACKWARD;
	if (strchr(srchauthor, op))
		cmps_kind |= SCMP_AUTHOR;
	if (strchr(srchassoc, op))
		cmps_kind |= SCMP_ASSOC;

	if (cmps_kind & SCMP_BACKWARD)
	{
		if (++ent > get_num_records(direct, FH_SIZE))
			return -1;
	}
	else
	{
		if (--ent < 1)
			return -1;
	}

	if (cmps_kind & SCMP_ASSOC)
	{
		if (!strncmp(cmps_str, STR_REPLY, strlen(STR_REPLY)))
		{
			strcpy(genbuf, cmps_str);
			strcpy(cmps_str, genbuf + 4);
		}
	}

	if ((fd = open(direct, O_RDONLY)) < 0)
		return -1;

	lseek(fd, (off_t) ((ent - 1) * FH_SIZE), SEEK_SET);

	while (read(fd, fhr, FH_SIZE) == FH_SIZE)
	{
		if (!(fhr->accessed & FILE_DELE))
		{
			if (cmps_kind & SCMP_AUTHOR)
			{
				strcpy(author, fhr->owner);
				strtok(author, ".@");	/* ? */
				takestr = author;
#ifdef DEBUG
				msg("ent = [%d], takestr = [%s]", ent, takestr);
				if (getkey() == 'q')
				{
					abort_bbs();
					 /* UNREACHED */ ;
				}
#endif

				if (takestr[0] == '#')
					takestr++;
				if (!strcmp(takestr, cmps_str))	/* compare */
				{
					close(fd);
					return ent;
				}
			}
			else
			{
				takestr = fhr->title;
#ifdef DEBUG
				msg("ent = [%d], takestr = [%s]", ent, takestr);
				if (getkey() == 'q')
				{
					abort_bbs();
					 /* UNREACHED */ ;
				}
#endif
				if (strstr(takestr, cmps_str))	/* compare */
				{	/* found it !! */
					close(fd);
					return ent;
				}

			}
		}

		if (cmps_kind & SCMP_BACKWARD)
			ent++;
		else
		{
			ent--;
			if (ent < 1)	/* quit search */
				break;
			lseek(fd, -2 * ((off_t) FH_SIZE), SEEK_CUR);
		}
	}
	close(fd);
	return -1;
}


int
AskEmailTo(addr, length)	/* ask email address to */
char    addr[];
int     length;
{
	if (addr[0] == '\0')	/* default e-mail */
		strncpy(addr, curuser.email, length - 1);
	if (addr[0] != '\0')
	{
		msg("���H�H [%s] ��� ? (y/n) [y] : ", addr);
		if (igetkey() == 'n')
			addr[0] = '\0';
	}
	if (addr[0] == '\0')
	{
		if (!getdata(b_line, 0, "���H�H: ", addr, STRLEN - 10, ECHONOSP, NULL))
			return -1;
	}
	return 0;
}


int 
treasure_article(ent, finfo, direct)	/* transfer article to treasure */
int     ent;			/* unused */
FILEHEADER *finfo;
char   *direct;
{
	int     ch, fd;
	char    fname[STRLEN], tpath[STRLEN];
	FILEHEADER fhbuf, *fhr = &fhbuf;	/* lasehu ? */
	extern int nowdepth;

	if (in_mail || (finfo->accessed & FILE_DELE))
		return R_NO;
	if (!HAS_PERM(PERM_SYSOP))
	{
		if ((curb->word->owner[0] != '\0' || !HAS_PERM(PERM_BM)) && !isBM)
			return R_NO;
	}

	if (in_board)
	{
		sprintf(tpath, "%s/%s", BBSPATH_TREASURE, curb->word->name);
		msg("<<��J��ذ�>>:(n)��@�g (m)�аO�_�� (u)�����аO (t)��аO (c)������ ? [c]: ");
	}
	else
	{
		setdotfile(tpath, direct, finfo->filename);
		msg("<<��J�l�ؿ�>>:(m)�аO�_�� (u)�����аO (t)��J�ؿ� (.)��^�W�h (c)������? [c]:");
	}
	switch ((ch = igetkey()))
	{
		case 'm':
			if (!(finfo->accessed & FILE_TREA))
				artwtop = add_wlist(artwtop, finfo->filename, malloc_str);
			break;
		case 'u':
			if (artwtop)
				cmpd_wlist(&artwtop, finfo->filename, strncmp, free);
			break;
		case 'n':
			if (in_board)
			{
				setdotfile(fname, direct, finfo->filename);
				if (append_article(fname, tpath, finfo->owner, finfo->title, finfo->owner_ident, NULL, YEA) == -1)
					msg(_msg_fail);
				else
					msg(_msg_finish);
				getkey();
			}
			break;
		case '.':
			if (nowdepth < 2)
				return R_LINE;
			*(strrchr(tpath, '/')) = '\0';
			*(strrchr(tpath, '/')) = '\0';	/* parent directory */
		case 't':
			if (!artwtop)
			{
				msg(" �Х��N�峹�аO!! ");
				getkey();
				return R_LINE;
			}
			else if (!in_board && !(finfo->accessed & FILE_TREA) && ch == 't')
			{
				msg("�N��в���ؿ��A��(t)�A�K�i��J�Ӥl�ؿ�");
				getkey();
				return R_LINE;
			}
			if ((fd = open(direct, O_RDWR)) < 0)
				return R_LINE;
			if (!in_board)
			{
				msg("<<��J�l�ؿ�>>: (c)opy �ƻs (m)ove �h�� ? [c]: ");
				ch = (igetkey() == 'm') ? 'T' : 't';
			}
			if (ch == 'T')
				flock(fd, LOCK_EX);
			while (read(fd, fhr, FH_SIZE) == FH_SIZE)
			{
				if (!cmp_wlist(artwtop, fhr->filename, strcmp))
					continue;
				setdotfile(fname, direct, fhr->filename);
				if (append_article(fname, tpath, fhr->owner, fhr->title, fhr->owner_ident, NULL, NA) == -1)
				{
					if (ch == 'T')
						flock(fd, LOCK_UN);
					close(fd);
					msg(_msg_fail);
					getkey();
					return R_LINE;
				}
				if (ch == 'T')
				{
					fhr->accessed |= FILE_DELE;
					lseek(fd, -((off_t) FH_SIZE), SEEK_CUR);
					write(fd, fhr, FH_SIZE);
				}
			}
			if (ch == 'T')
				flock(fd, LOCK_UN);
			close(fd);
			msg(_msg_finish);
			getkey();
			if (ch == 'T')
			{
				pack_article(direct);	/* treasure need deleted immediately */
				return NEWDIRECT;
			}
			break;
		default:
			break;
	}
	return R_LINE;
}


int 
mkdir_treasure(ent, finfo, direct)	/* make directory in treasure */
int     ent;			/* unused */
FILEHEADER *finfo;		/* unused */
char   *direct;
{
	char    title[STRLEN], path[STRLEN];
	char   *stamp;
	char    new[STRLEN], del[STRLEN];
	int     fd, fdnew, insert_ok;
	FILEHEADER *fhr = &tmp_fh, th;	/* lasehu ? */
	int     ch;		/* ? */

	extern int nowdepth;

	if (in_mail || in_board || (!HAS_PERM(PERM_SYSOP) && !isBM))
		return R_NO;
	sprintf(new, "%s.new", direct);
	sprintf(del, "%s.del", direct);
/* lasehu
   tempfile(new);
   tempfile(del);
 */
	if (nowdepth >= TREASURE_DEPTH)
	{
		msg("��ذϳ̦h�u�i�} %d �h, ���n�ӳg�߰� !", TREASURE_DEPTH);
		getkey();
		return R_LINE;
	}
	if (!getdata(b_line, 0, "�ؿ��W��: ", title, STRLEN, DOECHO, NULL))
		return R_LINE;
		
	msg("�T�w�إߥؿ� '[1;36m%s[m' �� (y/n) ? [n] : ", title);
	if (igetkey() != 'y')
		return R_LINE;

	setdotfile(path, direct, "\0");	/* ���o direct ���Ҧb�ؿ� */
	stamp = path + strlen(path);
	do
	{
		sprintf(stamp, "M.%d.A", time(0));
	}
	while (mkdir(path, 0700) == -1);

	memset(&th, 0, sizeof(th));
	strcpy(th.title, title);
	strcpy(th.filename, stamp);
	th.accessed |= FILE_TREA;

	if ((fd = open(direct, O_RDWR)) < 0)
	{
		msg(_msg_fail);
		getkey();
		myunlink(path);
		return R_LINE;
	}
	if ((fdnew = open(new, O_WRONLY | O_CREAT | O_TRUNC, 0644)) < 0)
	{
		close(fd);
		msg(_msg_fail);
		getkey();
		myunlink(path);
		return R_LINE;
	}
	ch = 0;
	insert_ok = NA;
	flock(fd, LOCK_EX);
	while (read(fd, fhr, FH_SIZE) == FH_SIZE)
	{
		if (!(fhr->accessed & FILE_TREA) && !insert_ok)
		{
			if (write(fdnew, &th, sizeof(th)) != sizeof(th))
			{
				ch = -1;
				break;
			}
			insert_ok = YEA;
		}
		if (write(fdnew, fhr, FH_SIZE) != FH_SIZE)
		{
			ch = -1;
			break;
		}
	}
	if (ch != -1 && !insert_ok)
	{
		if (write(fdnew, &th, sizeof(th)) != sizeof(th))
			ch = -1;
	}
	close(fdnew);
	flock(fd, LOCK_UN);
	close(fd);
	if (ch == 0)
	{
		if (rename(direct, del) == 0)
		{
			if (rename(new, direct) == 0)
			{
				unlink(del);
				msg("�ؿ��إߧ���");
				getkey();
				return NEWDIRECT;
			}
			rename(del, direct);
		}
	}
	unlink(new);
	myunlink(path);
	msg("�ؿ��إߥ���");
	getkey();
	return R_LINE;
}


int 
del_direct(ent, finfo, direct)	/* remove directory in treasure */
int     ent;
FILEHEADER *finfo;
char   *direct;
{
	if (in_mail || in_board || (!HAS_PERM(PERM_SYSOP) && !isBM))
		return R_NO;
		
	msg("�R���ؿ� '[1;33m%.60s[m' �U�Ҧ��峹�Τl�ؿ��� ? [n]: ", finfo->title);
	if (igetkey() != 'y')
		return R_LINE;

	if (delete_record(direct, FH_SIZE, ent) == 0)
	{
		setdotfile(genbuf, direct, finfo->filename);
		myunlink(genbuf);
		msg(_msg_finish);
		getkey();
		return NEWDIRECT;
	}
	msg(_msg_fail);
	getkey();
	return R_LINE;
}


int 
xchg_treasure(ent, finfo, direct)	/* exchange treasure */
int     ent;
FILEHEADER *finfo;		/* unused */
char   *direct;
{
	int     new_pos;
	FILEHEADER fromhr, tohr;

	if (in_mail || in_board || (!HAS_PERM(PERM_SYSOP) && !isBM))
		return R_NO;

	if (!getdata(b_line, 0, "�P�ĴX���洫 ? ", genbuf, 6, ECHONOSP, NULL))
		return R_LINE;
	new_pos = atoi(genbuf);
	
	if (get_record(direct, &fromhr, sizeof(fromhr), ent) == 0 
	    && get_record(direct, &tohr, sizeof(tohr), new_pos) == 0)
	{
		/* ignore file lock to speed-up processing */
		if (substitute_record(direct, &fromhr, sizeof(fromhr), new_pos) == 0 
		    && substitute_record(direct, &tohr, sizeof(tohr), ent) == 0)
		{
			msg(_msg_finish);
			getkey();
			return NEWDIRECT;
		}
	}
	msg(_msg_fail);
	getkey();
	return R_LINE;
}


void
setdotfile(buf, dotfile, fname)
char   *buf, *dotfile, *fname;
{
	char   *ptr;

	strcpy(buf, dotfile);
	if ((ptr = strrchr(buf, '/')) == NULL)
	{
		bbslog("ERROR", "setdotfile() dot[%s][%s]", dotfile, fname);
		return;
	}
	while (ptr > buf && *(ptr - 1) == '/')
		*ptr-- = '\0';
	strcpy(ptr + 1, (fname[0] == '/') ? fname + 1 : fname);
}


int
is_internet_email(to)
char   *to;
{
	char   *ptr;

	ptr = strchr(to, '@');
	if (!ptr)
		return 0;
	if (!strcmp(ptr + 1, MYHOSTNAME) || !strcmp(ptr + 1, MYHOSTIP))
	{
	/* userid@mymachine, consider as internet email */
		*ptr = '\0';
		if ((ptr = strchr(to, '.')))
		{
			*ptr = '\0';
			return 0;
		}
	}
	return 1;
}


int
uuencode_file(fname, uuname)
char   *fname, *uuname;
{
	char    cmd[PATHLEN + 20];

	sprintf(uuname, "tmp/%s.uu", curuser.userid);
	sprintf(cmd, "uuencode %s bbs.uu > %s", fname, uuname);
	outdoor(cmd, UNDEFINE, YEA);
}


int
do_article_title(title)
char   *title;
{
	if (*title)
	{
		printxy(2, 0, "�ϥμ��D (%s) ? (y/n) [y] : ", title);
		if (igetkey() == 'n')
			title[0] = '\0';
	}
	trim(title);
	if (*title == '\0')
	{
		if (!getdata(2, 0, "���D : ", title, TTLEN, DOECHO, NULL))
			return -1;
		return 1;
	}
	return 0;
}


do_article_to(to)
char   *to;
{
	if (*to)
	{
		printxy(1, 0, "�H(�^)�� [%s] ? (y/n) [y] : ", to);
		if (igetkey() == 'n')
			to[0] = '\0';
	}
	if (*to == '\0')
	{
		if (!getdata(1, 0, "�H(�^)�� : ", to, STRLEN, ECHONOSP, NULL))
			return -1;
	}
}
