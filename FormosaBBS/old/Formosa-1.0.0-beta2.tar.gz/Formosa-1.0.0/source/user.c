
#include "bbs.h"
#include "tsbbs.h"

#ifdef MULTIBBS
#include "./util/loginsrv.h"
#endif


#ifdef MULTIBBS
/*
 * �Ѻ�����s�������ϥΪ̸��, �ϸ�ƫO���@�P
 */
net_update_user(ubuf, pass)
USEREC *ubuf;
char   *pass;
{
	int     sd;
	char    buf[512];
	char   *s[] = {UPDATESERVER};

	if (ubuf == NULL || ubuf->userid[0] == '\0')
		return -1;
#ifdef HAVE_BUG
	if (strstr(ubuf->userid, "..") || ubuf->userid[0] == '/')
		return -1;
#endif
#ifdef HAVE_BUG
	if (ubuf->uid < 1)
		return -1;
#endif
	if ((sd = ConnectServer(*s, NETPORT, TCP)) < 0)
		return -1;

	net_printf(sd, "%s\t%s\t%s\r\n", LOGINSRV_UPDATEUSER, ubuf->userid, pass);
	net_gets(sd, buf, sizeof(buf));
	if (!strncmp(buf, LOGINSRV_READY, sizeof(LOGINSRV_READY)))
	{
		net_write(sd, ubuf, sizeof(USEREC));
		net_gets(sd, buf, sizeof(buf));
		if (!strncmp(buf, LOGINSRV_OK, sizeof(LOGINSRV_OK)))
		{
			DisconnectServer(sd);
			return 0;
		}
	}
	DisconnectServer(sd);
	return -1;
}

#endif


/*******************************************************************
 * ���U�@��ϥΪ
 * �Ѽ�: ubuf -> if NULL, ���d�@�ӪŦ�N�n
 *               else �N�s user ��� (ubuf) �g�J�Ŧ�
 * �Ǧ^: �ϥΪ̽s��.
 *******************************************************************/
unsigned int
new_user(ubuf)
USEREC *ubuf;
{
	int     fd, fdp;
	char    fname[PATHLEN];
	struct useridx uidx;
	char    homepath[PATHLEN];
	unsigned int cnt;

	if (ubuf)
	{
#ifdef HAVE_BUG
		if (strstr(ubuf->userid, "..") || ubuf->userid[0] == '/')
			return 0;
#endif
		if (ubuf->userid[0] == '\0')
			return 0;
		if (get_passwd(NULL, ubuf->userid) > 0)
			return 0;
		sethomefile(homepath, ubuf->userid, NULL);
		if (mkdir(homepath, 0755) == -1)
			return 0;
		sethomefile(fname, ubuf->userid, UFNAME_PASSWDS);
		if ((fdp = open(fname, O_WRONLY | O_CREAT, 0600)) < 0)
		{
			rmdir(homepath);
			return 0;
		}
		if (write(fdp, ubuf, sizeof(USEREC)) != sizeof(USEREC))
		{
			close(fdp);
			unlink(fname);
			rmdir(homepath);
			return 0;
		}
		close(fdp);

		if ((fd = open(USERIDX, O_RDWR)) > 0)
		{
			flock(fd, LOCK_EX);
			if (lseek(fd, (off_t) ((ubuf->uid - 1) * sizeof(uidx)), SEEK_SET) != -1
			    && read(fd, &uidx, sizeof(uidx)) == sizeof(uidx)
			    && !strcmp(uidx.userid, "new")
			    && lseek(fd, -((off_t) sizeof(uidx)), SEEK_CUR) != -1)
			{
				memset(&uidx, 0, sizeof(uidx));
				strcpy(uidx.userid, ubuf->userid);
				if (write(fd, &uidx, sizeof(uidx)) == sizeof(uidx))
				{
					flock(fd, LOCK_UN);
					close(fd);
					return ubuf->uid;
				}
			}
			flock(fd, LOCK_UN);
			close(fd);
		}
		unlink(fname);
		rmdir(homepath);
		return 0;
	}

	if ((fd = open(USERIDX, O_RDWR | O_CREAT, 0644)) < 0)
		return 0;
	flock(fd, LOCK_EX);
	cnt = 1;
	while (read(fd, &uidx, sizeof(uidx)) == sizeof(uidx))
	{
		if (uidx.userid[0] == '\0')
			break;
		cnt++;
	}
	if (lseek(fd, ((off_t) ((cnt - 1) * sizeof(uidx))), SEEK_SET) != -1)
	{
		memset(&uidx, 0, sizeof(uidx));
		strcpy(uidx.userid, "new");
		if (write(fd, &uidx, sizeof(uidx)) == sizeof(uidx))
		{
			flock(fd, LOCK_UN);
			close(fd);
			return cnt;
		}
	}
	flock(fd, LOCK_UN);
	close(fd);
	return 0;
}


#ifdef DELUSER
/*******************************************************************
 * �R���@��ϥΪ̪����
 * �Ѽ�: name -> userid
 * �Ǧ^: �ϥΪ̽s��. if failed, return 0;
 *******************************************************************/
unsigned int
delete_user(name)
char   *name;
{
	int     fd;
	unsigned int uid;
	struct useridx uidx;

	if (name == NULL || name[0] == '\0')
		return 0;
	if ((uid = get_passwd(NULL, name)) <= 0)
		return 0;
	if ((fd = open(USERIDX, O_RDWR)) < 0)
		return 0;
	flock(fd, LOCK_EX);

	prints("\n�M��ϥΪ̯��ްO�� ... ");
	log_usies("DELUSER", "name:[%s] uid:[%d]", name, uid);

	if (lseek(fd, (off_t) ((uid - 1) * sizeof(uidx)), SEEK_SET) != -1
	    && read(fd, &uidx, sizeof(uidx)) == sizeof(uidx)
	    && !strcmp(uidx.userid, name)
	    && lseek(fd, -((off_t) sizeof(uidx)), SEEK_CUR) != -1)
	{
		memset(&uidx, 0, sizeof(uidx));
		if (write(fd, &uidx, sizeof(uidx)) == sizeof(uidx))
		{
			flock(fd, LOCK_UN);
			close(fd);
#if 0
			log_usies("DELUSER", "delete [%s] user file", name);
#endif
			delete_user_file(name);
			return uid;
		}
	}
	flock(fd, LOCK_UN);
	close(fd);
	return 0;
}


delete_user_file(userid)
char   *userid;
{
	char   *d_dir[] =	/* ? */
	{
		"passwds",
		"ircrc",	/* This will not be delete cross-bbs ? */
		"mail",
		"overrides",
		"plans",
		"signatures",
		"records",	/* This will not be delete cross-bbs ? */
		"edit",
#ifdef MULTIBBS
		"var/passwds",
#endif
		NULL
	};
	char    fn_deluser[128];
	int     i;

#ifdef HAVE_BUG
	if (strstr(userid, "..") || userid[0] == '/')
		return 0;
#endif
	for (i = 0; d_dir[i]; i++)
	{
		sprintf(fn_deluser, "%s/%s", d_dir[i], userid);
		unlink(fn_deluser);
	}
}

#endif


