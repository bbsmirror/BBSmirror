
#include "bbs.h"
#include "tsbbs.h"


/*******************************************************************
 * �ɤ��ܼƫŧi
 *******************************************************************/
extern int do_post(), read_help(), bm_manager_file(),
        treasure_article(), mkdir_treasure(), xchg_treasure();

#ifdef HAVE_CROSSPOST
extern int cross_article();

#endif

#ifdef USE_VOTE
extern int voteboardhold(), v_board();

#endif

struct one_key read_comms[] =
{
	CTRL('P'), do_post,
	'd', del_article,
	'T', batch_del_article,
	'm', mail_article,
	'E', edit_article,
	'i', title_article,
	'h', read_help,
	'w', bm_manager_file,
#ifdef HAVE_CROSSPOST
	'x', cross_article,
#endif
	'g', reserve_article,
	't', treasure_article,
	CTRL('G'), mkdir_treasure,
	'c', xchg_treasure,
#ifdef USE_VOTE
	'v', v_board,
	'l', voteboardhold,
#endif
	'\0', NULL
};


int
display_assistant(option)
int     option;
{
	FILE   *fp;
	int     x = 0, y = 3, cnt = 0;
	char   *p;

	if (option == YEA)
		outs("�H�U�����O�O�D�U��s�W��, ��U�O�D�B�z�O��:\n");
	setboardfile(genbuf, curb->word->name, BM_ASSISTANT);
	if ((fp = fopen(genbuf, "r")) != NULL)
	{
		while (fgets(genbuf, sizeof(genbuf), fp))
		{
#ifdef HAVE_BUG
			if (p = strchr(genbuf, ' '))
				*p = '\0';
#endif
			move(y, x);
			outs(genbuf);
			if (++y == b_line)
			{
				y = 3;
				if ((x += 16) >= 80)
				{
					pressreturn();
					x = 0;
					move(y, x);
					clrtobot();
				}
			}
			cnt++;
		}
		fclose(fp);
	}
	if (cnt == 0)
	{
		if (option == YEA)	/* lasehu */
			return 0;
		move(y, x);
		outs("(�S�H)");
	}
	if (option == YEA)
		pressreturn();
	return cnt;
}


add_assistant(Uident)		
char   *Uident;
{
	FILE   *fp;
	char    buf[STRLEN];

	setboardfile(genbuf, curb->word->name, BM_ASSISTANT);
	if (seek_in_file(genbuf, Uident))
		return;

	if ((fp = fopen(genbuf, "a")) == NULL)
		return;
	fprintf(fp, "%s\n", Uident);
	fclose(fp);
#ifdef NSYSUBBS
	sprintf(buf, "sort -o %s %s", genbuf, genbuf);
	outdoor(buf, OVERRIDE, YEA);
#endif
	return;
}


del_assistant(Uident)
char   *Uident;
{
	FILE   *fp, *fpnew;
	char    fn[PATHLEN], fnnew[PATHLEN];
	int     deleted = NA;
	char   *p;

	setboardfile(fn, curb->word->name, BM_ASSISTANT);
	sprintf(fnnew, "tmp/-%s.bm_assistant.new", curuser.userid);	/* lasehu ? */
	if ((fp = fopen(fn, "r")) == NULL)
		return;
	if ((fpnew = fopen(fnnew, "w")) == NULL)
	{
		fclose(fp);
		return;
	}
	while (fgets(genbuf, sizeof(genbuf), fp))
	{
		if ((p = strchr(genbuf, '\n')) != NULL)
			*p = '\0';
		if (!strcmp(genbuf, Uident))
			deleted = YEA;
		else
			fprintf(fpnew, "%s\n", genbuf);
	}
	fclose(fpnew);
	fclose(fp);
	if (deleted)
	{
		if (mymv(fnnew, fn) == 0)
			return;
	}
	unlink(fnnew);
}


/*
 * �O�D�޲z�O�D�M���ɮ׽s��i�O�e��
 */
bm_manager_file()
{
	int     realbm_right;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return;
#endif

	if (!HAS_PERM(PERM_SYSOP) && !isBM)
		return R_NO;

	if (HAS_PERM(PERM_SYSOP) || !strcmp(curuser.userid, curb->word->owner))
		realbm_right = YEA;
	else
		realbm_right = NA;

	clear();

	if (realbm_right)
		getdata(1, 0, "(E)�s��i�O�e��, (D)�R���i�O�e��, �� (M)�s��O�D�U��W�� ? [E]: ", genbuf, 2, ECHONOSP, NULL);
	else
		getdata(1, 0, "(E)�s��i�O�e��, �� (D)�R���i�O�e�� ? [E]: ", genbuf, 2, ECHONOSP, NULL);

	if ((genbuf[0] | 32) == 'd')
	{
		setboardfile(genbuf, curb->word->name, BM_WELCOME);
		if (!dashf(genbuf))
		{
			outs("�z�|���s��i�O�e��, �i�O�e���R������.");
		}
		else
		{
			outs("\n==>> �T�w�R���i�O�e���� ? (y/n) [n] : ");
			if (igetkey() == 'y')
			{
				unlink(genbuf);
				outs(_msg_finished);
			}
			else
				outs(_msg_aborted);
		}
	}
	else if ((genbuf[0] | 32) == 'm' && realbm_right)
	{
		int     num_assistant;
		char    assistant[IDLEN + 1];

		while (1)
		{
			clear();
			outs("�s��O�D�U��W��, �W��W���H�N�֦����O�D�v�� (�Фp�ߨϥ�)\n");
			num_assistant = display_assistant(NA);
			if (num_assistant)
				getdata(1, 0, "(A)�W�[�@�ӦW�r, (D)�R���@�ӦW�r, �� (E)���}? [E]: ", genbuf, 2, ECHONOSP, NULL);
			else
				getdata(1, 0, "(A)�W�[�@�ӦW�r, �� (E)���}? [E]: ", genbuf, 2, ECHONOSP, NULL);
			if ((genbuf[0] | 32) == 'a')
			{
				if (getdata(2, 0, _msg_ent_userid, assistant, sizeof(assistant), ECHONOSP, NULL))
				{
					if (get_passwd(NULL, assistant) > 0)
						add_assistant(assistant);
				}
			}
			else if ((genbuf[0] | 32) == 'd' && num_assistant)
			{
				if (getdata(2, 0, _msg_ent_userid, assistant, sizeof(assistant), ECHONOSP, NULL))
					del_assistant(assistant);
			}
			else
				break;
		}
	}
	else
	{
		setboardfile(genbuf, curb->word->name, BM_WELCOME);
		if (vedit(genbuf, NULL))
			outs(_msg_aborted);
		else
			outs(_msg_finished);		
	}

	pressreturn();
	return R_FULL;
}


/*
 * �\Ū�峹 (�@��/��ذ�) �u�W�D�U
 */
int
read_help()
{
	more(READ_HELP, YEA);
	return R_FULL;
}


int
check_post_perm(blistent)
struct BoardList *blistent;
{
#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
	{
		if (strcmp(blistent->name, "sysop") && strcmp(blistent->name, "test"))
		{
			outs("��p, guest �b���u��� sysop �� test �i�K!!\n");
			pressreturn();
			return -1;
		}
	}
#endif

	if (!HAS_PERM(PERM_SYSOP))
	{
		if (blistent->level == NEWS_BOARD_LEVEL)
		{
			outs("\n��p, ���O�� news server ��H !!\n");
			pressreturn();
			return -1;
		}
		else if (curuser.userlevel < blistent->level
			 && blistent->level != 254)
		{
			prints("\n��p, �z������ [%d] ���쥻�O���� [%d], ����i�K�b���O\n",
			       curuser.userlevel, blistent->level);
/*---
	    prints("\n�s��W��, �Х����x����§�`.\n");
*/
			pressreturn();
			return -1;
		}
		if ((blistent->attrib & IDENT_ATTRIB) && curuser.ident != 7)	/* lasehu */
		{
			outs("\n��p, ���O�ثe�u�����q�L�{�Ҥ��ϥΪ̱i�K!!");
			pressreturn();
			return -1;
		}
	}

	if (!in_board)
	{
		if (!HAS_PERM(PERM_SYSOP))
		{
			if ((blistent->owner[0] != '\0' || !HAS_PERM(PERM_BM)) &&
			    !isBM)
			{
				outs("��p, �u�����O�O�D �~��b��ذϱi�K !!");
				pressreturn();
				return -1;
			}
		}
		prints("\n�i�K�b '%s' ��ذ�", blistent->name);
	}
	else
	{
		prints("\n�i�K�b '%s' �ݪO", blistent->name);
	}
}


int
prepare_post(postpath, srcfile, title)	/* lasehu */
char   *postpath, *srcfile;
char   *title;
{
	int     save_umode = uinfo.mode;
	char    stamp[14];
	int     foo;
	int     artno;

	if (check_post_perm(curb->word) == -1)
		return -1;

	foo = do_article_title(title);
	
	if (foo == -1)
		return -1;
	else if (foo == 0)
	{
		if (srcfile && strncmp(title, STR_REPLY, strlen(STR_REPLY)))
		{
			strcpy(genbuf, title);
			sprintf(title, "%s%s", STR_REPLY, genbuf);
		}
	}
	if (srcfile)
		include_ori(srcfile, tempfile);
	include_sig(curuser.userid, tempfile);

	update_umode(POSTING);
	if (vedit(tempfile, title))
	{
		unlink(tempfile);
		update_umode(save_umode);
		return -1;
	}
	update_umode(save_umode);

	if ((artno = append_article(tempfile, postpath, curuser.userid, title, curuser.ident, stamp, YEA)) == -1)
	{
		unlink(tempfile);
		return -1;
	}
	brc_addlist(artno);	/* lasehu */

	if (curb->word->type == 'B' || curb->word->type == 'O')
	{
#ifdef EMAIL_LIMIT
		if (curuser.ident != 7)
			outs("\n���q�L�{�ҨϥΪ̵L�k�N�峹�e�ܯ��~");
		else
#endif
		{
			outs("\n!!! �Ъ`�N !!!\n�e�W news server ���H��N�y�J�ǳN����,\
���Ԩ��V��, �Y���Q�e, �Ц^�� No\n�n���n�e�h News Server ? (y/n) [n] : ");
			if (igetkey() == 'y')
				append_news(curb->word->name, stamp, 'S');
		}
	}

	if (!strstr(postpath, "test"))	/* ? */
		numposts++;

	brc_addlist(artno);
	if (artno == 1)
		rewind_board(curb->word->name);
	unlink(tempfile);
	return 0;
}


int
prepare_crosspost(postpath, srcfile, title)	/* lasehu */
char   *postpath, *srcfile;
char   *title;
{
	int     artno;

	mycp(srcfile, tempfile);

	if ((artno = append_article(tempfile, postpath, curuser.userid, title, curuser.ident, NULL, YEA)) == -1)
	{
		unlink(tempfile);
		return -1;
	}

	brc_addlist(artno);	/* lasehu */
	if (artno == 1)
		rewind_board(curb->word->name);

	unlink(tempfile);
	return 0;
}



/*
 * �i�K�峹
 */
do_post(ent, finfo, direct)
int     ent;			/* unused */
FILEHEADER *finfo;		/* unused */
char   *direct;
{
	char    postpath[PATHLEN], title[STRLEN];
	int     foo;

	clear();

	if (!in_board)
	{
		setdotfile(postpath, direct, "\0");
#ifdef MYDEBUG
		if (strrchr(postpath, '/') == NULL)
			bbslog("DEBUG", "setdotfile in do_post()");
#endif
	}
	else
		setboardfile(postpath, curb->word->name, "\0");

	title[0] = '\0';

	foo = prepare_post(postpath, NULL, title);	/* srcfile: NULL */

	move(b_line - 1, 0);
	clrtoeol();
	if (foo == -1)
		outs("�i�K����.");
	else
		outs("�i�K����.");
	pressreturn();

	return NEWDIRECT;
}


/*
 * �^�� (�@���/��ذ�) �峹
 */
reply_post(finfo, direct)
FILEHEADER *finfo;
char   *direct;
{
	char    postpath[PATHLEN], srcfile[PATHLEN], title[STRLEN];
	int     foo;

	clear();
	outs("�^���� (1)�ݪO �� (2)���@�̫H�c ? [1]: ");
	if (getkey() == '2')
	{
		reply_mail(finfo, direct);
		return R_FULL;
	}

	setdotfile(postpath, direct, "\0");
	setdotfile(srcfile, direct, finfo->filename);

	title[0] = '\0';
	if (finfo->title[0])
	{
		if (!strncmp(finfo->title, STR_REPLY, strlen(STR_REPLY)))
			strcpy(title, finfo->title + strlen(STR_REPLY));
		else
			strcpy(title, finfo->title);
	}

	foo = prepare_post(postpath, srcfile, title);

	move(b_line - 1, 0);
	clrtoeol();

	if (foo == -1)
		outs("�i�K����.");
	else
		outs("�i�K����.");
	pressreturn();

	return NEWDIRECT;
}


/*******************************************************************
 * Main Menu Post()
 *******************************************************************/
Post()
{
	clear();
	if (!check_board_list())/* ? */
	{
		outs("Ū�������ݪO");
		pressreturn();
		return M_FULL;
	}
	if (!in_board)
	{
		outs("\n��ذϱi�K�Х���K�ﶵ(t)\n�Φb�\\Ū���A�U�i�K\n");
		pressreturn();
		return M_FULL;
	}

	do_post(0, NULL, NULL);

	return M_FULL;
}


/*******************************************************************
 * �\Ū�O��/��ذϫH�� �� Main Menu Read()
 *******************************************************************/
Read()
{
	char    tmp_direct[PATHLEN];

	if (!check_board_list())
	{
		outs("Ū�������ݪO");
		pressreturn();
		return M_FULL;
	}

	update_umode(READING);

#ifdef USE_VOTE
	sprintf(genbuf, "%s/%s/", BOARDVOTE, curb->word->name);
	if (check_vote(genbuf))
		more(NEWVOTEMSG, YEA);
#endif

	sprintf(tmp_direct, "%s/%s/%s", (in_board) ? BBSPATH_BOARDS : BBSPATH_TREASURE,
		curb->word->name, DIR_REC);	/* ? */
	i_read(tmp_direct, &read_comms[0], IREAD_BOARD);	/* �@��ϻP��ذϬҨϥ�  */

	brc_update();

	return M_FULL;
}
