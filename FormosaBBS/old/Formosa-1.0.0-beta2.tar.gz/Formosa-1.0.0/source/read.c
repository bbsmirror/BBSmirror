
#include "bbs.h"
#include "tsbbs.h"


#define PUTCURS   move(c+4,0);prints("=>");
#define RMVCURS   move(c+4,0);prints("  ");


FILEHEADER *fheads = NULL;
int     t_top[TREASURE_DEPTH], t_cur[TREASURE_DEPTH];
int     nowdepth = 1;

char    memtitle[STRLEN];

int     mailtop, mailcur;	/* �H�c�\Ū�����аO�� */

/*******************************************************************
 * �N DIR_REC �����Ū�J�}�C��, �Ǧ^Ū��X��
 *******************************************************************/
get_list(direct, top)
char   *direct;
int     top;
{
	int     fd;
	register int total = 0;

/* ����H�c�H����ܼ� */
	if (!HAS_PERM(PERM_SYSOP) && in_mail && top > maxkeepmail)
		return 0;

	if ((fd = open(direct, O_RDONLY)) > 0)
	{
		if (lseek(fd, (off_t) (FH_SIZE * (top - 1)), SEEK_SET) != -1)
		{
			total = read(fd, &(fheads[total]), FH_SIZE * (SCREEN_SIZE - 4));
			if (total != -1 && total % FH_SIZE == 0)
			{
				close(fd);
				return (total / FH_SIZE);
			}
		}
		close(fd);
	}
	return 0;
}



/*
 * �H�c���
 */
void
mail_title()
{
	clear();
	outs("[37;44m�ӤH�H�c�C��                                                                  [m\n");
	outs("(h)���� (Ctrl-p)�g�H (</>)(a/A)�j�M ([/])�D�D�\\Ū (U)�d�ߵo�H�H (T)���R��\n");
	outs("(d)�R�� (E)�ק�s�� (m)�H�X (T)���R�� (g)�O�d�H�� (HOME)���g ($)���g\n");
	outs("[7m  �s��    �o�H�H         ���   ���D                                          [m");
}


/*
 * �ݪO (�@���/��ذ�) ���
 */
void
post_title()
{
	clear();
	prints("%s�O�D�G%-12.12s                  %-19s �ݪO�G%-16.16s[m\n", READ_TITLE_COLOR, curb->word->owner,
	       (in_board ? "[�@���]" : "[��ذ�]"), curb->word->name);
	prints("(h)���� (Ctrl-p)�i�K (s)���ݪO (Tab)��ذϤ��� (</>)(a/A)�j�M ([/])�D�D�\\Ū\n");
	prints("(d)�R�� (m)�H�X (E)�ק�s�� (b)�i�O�e�� ($)�̫� (v)�벼 (x)��K (U)�d�ߵo�H�H\n");
	prints("[7m  �s��    �o�H�H         ���   ���D                                          [m");
}


/*******************************************************************
 * �C�LŪ Post �ɪ� Index List Lines
 *******************************************************************/
void
read_ent(ent, c, total, num)
FILEHEADER ent[];
int     c, total;
int     num;
{
	int     i, chkcolor;	/* Check If colorful */
	char    testtitle[STRLEN], chdate[6], type, sname[IDLEN + 3], buf[128];
	time_t  date;
	char    namebuf[STRLEN];

	memset(buf, 0, sizeof(buf));

	if (!strncmp(memtitle, STR_REPLY, strlen(STR_REPLY)))
	{
		strcpy(testtitle, memtitle);
		strcpy(memtitle, testtitle + 4);
	}
	else
		sprintf(testtitle, "%s%s", STR_REPLY, memtitle);

	for (i = 0; i < total; i++)
	{

		chkcolor = YEA;	/* assume have color */
		chk_str(ent[i].title);
		chk_str(ent[i].owner);
/* �Y����ذϥؿ� */

		date = atol((ent[i].filename) + 2);
		strftime(chdate, 6, "%m/%d", localtime(&date));

		if (ent[i].accessed & FILE_TREA)
		{
			sprintf(buf, "  %4d    [1;36m[�ؿ�][m         %s  %s", num++, chdate, ent[i].title);
		}
		else if (ent[i].accessed & FILE_IN)
		{
			sprintf(buf, "  %4d    [�����ɮ�]     %s  %s", num++, chdate, ent[i].title);
		}
		else if (ent[i].accessed & FILE_OUT)
		{
			sprintf(buf, "  %4d    [���~�ɮ�]     %s  %s", num++, chdate, ent[i].title);
		}
		else
		{
			if (ent[i].accessed & FILE_DELE)
				type = 'D';
			else if (cmp_wlist(artwtop, ent[i].filename, strcmp))
				type = '*';
			else if (in_mail)
			{
				if (ent[i].accessed & FILE_RESRV)
					type = (ent[i].accessed & FILE_READ) ? 'g' : 'G';
				else
					type = (ent[i].accessed & FILE_READ) ? ' ' : 'N';
			}
			else if (in_board)
			{
				if (ent[i].accessed & FILE_RESRV)
					type = (brc_unread(ent[i].artno)) ? 'G' : 'g';
				else
					type = (brc_unread(ent[i].artno)) ? 'N' : ' ';
			}
/* �Y����ذ�, �h�ҵ����wŪ�L */
			else
				type = ' ';

			if (ent[i].owner[0] == '#' || strchr(ent[i].owner, '@') || strchr(ent[i].owner, '.'))
			{
				strncpy(namebuf, ent[i].owner, sizeof(namebuf) - 1);
				strtok(namebuf, ".@ ");
				namebuf[IDLEN] = '\0';	/* lasehu */
				strcpy(sname, " #");
				if (ent[i].owner[0] == '#')
					strncpy(sname + 2, namebuf + 1, IDLEN);
				else
					strncpy(sname + 2, namebuf, IDLEN);
			}
			else
			{
				sprintf(sname, "  %s", ent[i].owner);
#ifdef IDENT
				if (curuser.ident == 7 && ent[i].owner_ident == 7)
					memcpy(sname, "��", 2);
#endif
			}
			if (!strcmp(ent[i].title, memtitle) && type != 'D')
				sprintf(buf, "  %4d %c %-14s  %s [1;32m#%s", num++, type, sname, chdate, ent[i].title);
			else if (!strcmp(ent[i].title, testtitle) && type != 'D')
				sprintf(buf, "  %4d %c %-14s  %s [1;33m#%s", num++, type, sname, chdate, ent[i].title);
			else
			{
				sprintf(buf, "  %4d %c %-14s  %s  %s", num++, type, sname, chdate, (type == 'D') ? "\0" : ent[i].title);
				chkcolor = 0;
			}
		}
		if (chkcolor)
		{		/* check string length */
			if (strlen(buf) > 86)
				sprintf(buf + 85, "%s", "[m");
			else
				strcat(buf, "[m");
		}
		else
			buf[78] = '\0';
		move(c + i, 0);
		outs(buf);
	}
}


int
select_item(direct, stop, scur, total, the_num)
char   *direct;
int    *stop, *scur;
int    *total;
int     the_num;
{
	int     i, itop = *stop;

	while (the_num - itop >= (SCREEN_SIZE - 4))
		itop += (SCREEN_SIZE - 4);
	while (the_num < itop)
		itop -= (SCREEN_SIZE - 4);
	if (itop < 1)
		itop = 1;
	if ((i = get_list(direct, itop)) > 0)
	{
		*total = i;	/* �u���s�J */
		*scur = the_num;
		if (itop != *stop)
		{
			*stop = itop;
			return R_PART;
		}
		*stop = itop;
	}
	return R_LINE;
}


quit_iread(direct)
char   *direct;
{
	artwtop = free_wlist(artwtop, free);
/* �h�ƴ�@ */
	if (!in_mail && !in_board)
	{
		if (nowdepth > 1)
		{
			*(strrchr(direct, '/')) = '\0';
			strcpy(strrchr(direct, '/') + 1, DIR_REC);
			nowdepth--;
			return -1;
		}
	}
	else if (in_board)
	{
		memset(t_top, 0, sizeof(t_top));
		memset(t_cur, 0, sizeof(t_cur));
	}
	return 0;
}


void
change_board(direct)		/* lasehu */
char  **direct;
{
	artwtop = free_wlist(artwtop, free);
	sprintf(*direct, "%s/%s/%s",
		(in_board) ? BBSPATH_BOARDS : BBSPATH_TREASURE,
		curb->word->name, DIR_REC);
}


/*******************************************************************
 * Cursor Reading Menu
 *******************************************************************/
i_read(direct, comm, option)
char   *direct;
struct one_key *comm;
char    option;
{
	void    (*ireadtitle) ();
	void    (*ireadent) ();

	int     total, c, last, mode, i, ch;
	int    *stop = NULL, *scur = NULL;
	char    nbuf[6], cmps_owner[31], cmps_title[STRLEN], *cmps_str;
	int     srchno;

	if (!fheads)
	{
		fheads = (FILEHEADER *) malloc(FH_SIZE * (SCREEN_SIZE - 4));
		if (fheads == NULL)
			return -1;
	}
	
	cmps_owner[0] = '\0';
	cmps_title[0] = '\0';

	mode = NEWDIRECT;

	while (1)
	{
		if (talkrequest)
		{
			talkreply();
/*---			pressreturn(); */
			mode = R_FULL;
		}
		else if (writerequest)	/* lasehu */
		{
			writereply();
			mode = R_FULL;
		}
		switch (mode)
		{
			case CAREYDOWN:
				if (ch != 'r')
					RMVCURS;
				*scur = *stop + c;
				if (c == total - 1)
				{
					if (*scur == last)
					{
						bell();
						mode = (ch == 'r') ? R_FULL : R_NO;
					}
					else
					{
						if ((total = get_list(direct, *scur + 1)) <= 0)
						{
/*--							bell(); */
							if (quit_iread(direct) == 0)
								return 0;
							mode = NEWDIRECT;
						}
						else
						{
							c = 0;
							(*scur)++;
							*stop = *scur;
							mode = R_PART;
							if (ch == 'r')
							{
								strcpy(memtitle, fheads[c].title);
								mode = read_article(*stop + c, &(fheads[c]), direct);
							}
						}
					}
					continue;
				}
				c++;
				(*scur)++;
				if (ch == 'r')
				{
					strcpy(memtitle, fheads[c].title);
					mode = read_article(*stop + c, &(fheads[c]), direct);
					continue;
				}
				break;
			case CAREYUP:
				if (ch != 'r')
					RMVCURS;
				*scur = *stop + c;
				if (c == 0)
				{
					if (*scur == 1)
					{
/*--						bell(); */
						mode = (ch == 'r') ? R_FULL : R_NO;
					}
					else
					{
						if (*stop > (SCREEN_SIZE - 4))
							*stop -= (SCREEN_SIZE - 4);
						else
							*stop = 1;
						if ((total = get_list(direct, (*stop))) <= 0)
						{
/*--							bell();	*/
							if (quit_iread(direct) == 0)
								return 0;
							mode = NEWDIRECT;
						}
						else
						{
							c = total - 1;
							(*scur)--;
							mode = R_PART;
							if (ch == 'r')
							{
								if (fheads[c].accessed & FILE_TREA)
									mode = R_FULL;
								else
								{
									strcpy(memtitle, fheads[c].title);
									mode = read_article(*stop + c, &(fheads[c]), direct);
								}
							}
						}
					}
					continue;
				}
				c--;
				(*scur)--;
				if (ch == 'r')
				{
					if (fheads[c].accessed & FILE_TREA)
						mode = R_FULL;
					else
					{
						strcpy(memtitle, fheads[c].title);
						mode = read_article(*stop + c, &(fheads[c]), direct);
					}
					continue;
				}
				break;
			case NEWDIRECT:
				clear();
				last = get_num_records(direct, FH_SIZE);
				if (!in_mail && !in_board)
				{
					if (last == 0)
					{
						outs("\n���h��ذϵL�G�i.\n\n�Y�n�i�K�Ĥ@�g, �Шϥ���K�ﶵ(t)");
						pressreturn();
						if (nowdepth == 1)
						{
							in_board = 1;
							setboardfile(direct, curb->word->name, DIR_REC);
						}
						else
						{
						/* �^��W�h��ذ� * */
							nowdepth--;
							*(strrchr(direct, '/')) = '\0';
							strcpy(strrchr(direct, '/') + 1, DIR_REC);
						}
						mode = NEWDIRECT;
						continue;
					}
					ireadtitle = post_title;
					ireadent = read_ent;
					stop = &(t_top[nowdepth - 1]);
					scur = &(t_cur[nowdepth - 1]);
				}
				else if (in_mail)
				{
					nowdepth = 1;
					if (last == 0)
					{
#ifdef IDENT
						if (option == IREAD_ICHECK || option == IREAD_IFIND)
							outs("�S����ưO��....\n");
						else
#endif
							outs("�z���H�c���S���H��\n");
						pressreturn();
						return 0;
					}
					stop = &mailtop;
					scur = &mailcur;
					ireadtitle = mail_title;
					ireadent = read_ent;
				}
				else
				{
					if (last == 0)
					{
						outs("\n���O�L�G�i.\n\n�z�{�b�n�i�K�Ĥ@�g�� (y/n) ? [y]: ");
						if (igetkey() == 'n')
							return 0;
						Post();	/* lasehu */
						last = get_num_records(direct, FH_SIZE);
						if (last == 0)
							return 0;
					}
					setboardfile(genbuf, curb->word->name, BM_WELCOME);
					if (curb->word->visit_flag < 2)
					{
						more(genbuf, YEA);
						clear();
						display_assistant(YEA);						
					}
					stop = &(curb->word->btop);
					scur = &(curb->word->bcur);
					ireadtitle = post_title;
					ireadent = read_ent;
				}
				if (*stop <= 0 || *scur <= 0 || *scur > last || *stop > *scur)
				{
					if (in_board || in_mail)
					{
						if (last > (SCREEN_SIZE - 4))
							*stop = last - (SCREEN_SIZE - 4) + 1;
						else
							*stop = 1;
						*scur = last;
					}
					else
					{
						*stop = *scur = 1;
					}
				}
				total = get_list(direct, *stop);	/* ? */
/* del by lasehu
   c = *scur - *stop;
 */
			case R_FULL:
				ireadtitle();
			case R_PART:
				c = *scur - *stop;	/* lasehu ? */
				move(4, 0);
				clrtobot();
#if 0
				refresh();
#endif
				ireadent(&(fheads[0]), 4, total, *stop);
				move(b_line, 0);
				prints("%s[r][��]:Ū [��][n]:�U�g [��][p]:�W�g [m]:�H�X [d]:�R�� [��][q]:�h�X           [m", READ_BTITLE_COLOR);
				break;
			case R_LINE:
				RMVCURS;	/* lasehu ? */
				c = *scur - *stop;	/* lasehu ? */
				move(4 + c, 0);
				clrtoeol();
				ireadent(&(fheads[c]), c + 4, 1, *stop + c);
				move(b_line, 0);
				prints("%s[r][��]:Ū [��][n]:�U�g [��][p]:�W�g [m]:�H�X [d]:�R�� [��][q]:�h�X           [m", READ_BTITLE_COLOR);
				break;
			default:
				break;
		}

		PUTCURS;

		mode = R_NO;	/* lasehu */
		ch = getkey();
		if (isdigit(ch))
		{
			int     nbuf_num;

			nbuf[0] = ch;	/* lasehu ? */
			nbuf[1] = '\0';

			getdata(b_line, 0, "�n����ĴX�g : ", nbuf, sizeof(nbuf), ECHONOSP, nbuf);
			nbuf_num = atoi(nbuf);
			if (nbuf_num > last || nbuf_num < 1)
			{
				bell();
				mode = R_LINE;
			}
			else
				mode = select_item(direct, stop, scur, &total, nbuf_num);
			continue;
		}
		switch (ch)
		{
			char    mybuf[STRLEN];

			case KEY_DOWN:
			case 'n':
				mode = CAREYDOWN;
				break;
			case KEY_HOME:
				mode = select_item(direct, stop, scur, &total, 1);
				break;
			case '$':
			case KEY_END:
				mode = select_item(direct, stop, scur, &total, last);
				break;
			case '\n':
			case '\r':
			case KEY_RIGHT:
				ch = 'r';
			case 'r':
				if (fheads[c].accessed & FILE_TREA)
				{
					artwtop = free_wlist(artwtop, free);
					sprintf(strrchr(direct, '/'), "/%s/%s", fheads[c].filename, DIR_REC);
					nowdepth++;
					mode = NEWDIRECT;
					continue;
				}
#if	defined(IDENT) && defined(SYSOP_BIN)
				if (option == IREAD_IFIND)
				{
					char    file1[IDLEN + 12], file2[IDLEN + 12];

					setuserfile(file1, fheads[c].filename, BBSPATH_REALUSER);
					sprintf(file2, "tmp/%sPGP", curuser.userid);
					if (a_decode(file1, file2, "\0") != -1)
					{
						more(file2, YEA);
						unlink(file2);
					}
					mode = R_FULL;
				}
				else
				{
#endif				
					strcpy(memtitle, fheads[c].title);
					mode = read_article(*stop + c, &(fheads[c]), direct);
#if	defined(IDENT) && defined(SYSOP_BIN)					
				}
#endif				
				break;
			case KEY_UP:
			case 'p':
				mode = CAREYUP;
				break;
			case KEY_LEFT:
			case 'q':
			case 'e':
				artwtop = free_wlist(artwtop, free);	/* lasehu ? */
				if (quit_iread(direct) == 0)
					return 0;
				mode = NEWDIRECT;
				break;
			case KEY_PGDN:
			case SP:
			case 'N':
				RMVCURS;	/* lasehu */
				c = total - 1;
				mode = CAREYDOWN;
				break;
			case KEY_PGUP:
			case 'P':
				RMVCURS;	/* lasehu */
				c = 0;
				mode = CAREYUP;
				break;
			case CTRL('L'):
				redoscr();
				break;
			case TAB:
				if (option == IREAD_BOARD)
				{	/* (�@��)�O�~�i������ذ� */
					in_board = (in_board) ? NA : YEA;
					change_board(&direct);
					mode = NEWDIRECT;
				}
				break;
			case 'a':
			case 'A':
				sprintf(genbuf, "�V%s�j�M�@�� [%s]: ", (ch == 'a') ? "��" : "��", cmps_owner);
				if (getdata(b_line, 0, genbuf, mybuf, 15, ECHONOSP, NULL))
					strcpy(cmps_owner, mybuf);
				cmps_str = cmps_owner;
				goto search_label;
			case '<':
			case '>':
				sprintf(genbuf, "�V%s�j�M���D [%s]: ", (ch == '<') ? "��" : "��", cmps_title);
				if (getdata(b_line, 0, genbuf, mybuf, 40, DOECHO, NULL))
					strcpy(cmps_title, mybuf);
				cmps_str = cmps_title;
				goto search_label;
			case '[':
			case ']':
				if (fheads[c].accessed & FILE_DELE)
					continue;
				if (ch == '['
				    && strncmp(fheads[c].title, STR_REPLY, strlen(STR_REPLY)))
				{
					continue;
				}
				strcpy(cmps_title, fheads[c].title);
				cmps_str = cmps_title;
		search_label:
				if (cmps_str[0] == '\0')
				{
					mode = R_LINE;
					continue;
				}
				msg("�B�z��, �еy�� ...");
				refresh();
				if ((srchno = search_article(direct, *stop + c, cmps_str, ch)) < 0)
				{
					msg("��%s�w�L�ŦX���󪺤峹.", (strchr("a<[", ch)) ? "�e" : "��");
					getkey();
					mode = R_LINE;
					continue;
				}
				*scur = srchno;
				mode = select_item(direct, stop, scur, &total, srchno);
				break;
			case 'U':
				if (fheads[c].owner[0] != '#' && !strchr(fheads[c].owner, '.') &&
				    !strchr(fheads[c].owner, '@'))
				{
					if (QueryUser(fheads[c].owner) == -1)
						mode = R_NO;
					else
						mode = R_FULL;
				}
				break;
#ifdef MYDEBUG
			case 'z':
				if (HAS_PERM(PERM_SYSOP))
				{
					msg("owner = [%s]", fheads[c].owner);
					getkey();
					msg("artno = [%d]", fheads[c].artno);
					getkey();
					mode = R_LINE;
					break;
				}
#endif
			case 'b':
				if (in_board)
				{
					setboardfile(genbuf, curb->word->name, BM_WELCOME);
					more(genbuf, YEA);
					clear();
					display_assistant(YEA);
					mode = R_FULL;
				}
				break;
			case 's':
				if (!in_mail && in_board)
				{
					if (choose_board() == 0)
					{
						change_board(&direct);
						mode = NEWDIRECT;
					}
					else
						mode = R_FULL;
				}
				break;
			case CTRL('R'):
				ReplyLastCall();
				mode = R_FULL;
				break;
			default:
				for (i = 0; comm[i].fptr; i++)
				{
					if (comm[i].key == ch)
					{
						mode = (*(comm[i].fptr)) (*stop + c, &(fheads[c]), direct);
						break;;
					}
				}
				break;
		}
	}
}
