
#include "bbs.h"


static char pwbuf[PASSLEN];


char   *
genpasswd(pw)
char   *pw;
{
	char    saltc[2];
	int     i, c;
	char   *crypt();

	if (strlen(pw) == 0)
		return "\0";
	i = 9 * getpid();
#ifndef lint
	saltc[0] = i & 077;
	saltc[1] = (i >> 6) & 077;
#endif
	for (i = 0; i < 2; i++)
	{
		c = saltc[i] + '.';
		if (c > '9')
			c += 7;
		if (c > 'Z')
			c += 6;
		saltc[i] = c;
	}
	strcpy(pwbuf, pw);
	return crypt(pwbuf, saltc);
}

int
checkpasswd(passwd, test)
char   *passwd, *test;
{
	char   *pw;
	char   *crypt();

	strncpy(pwbuf, test, PASSLEN);
	pw = crypt(pwbuf, passwd);
	return (!strncmp(pw, passwd, PASSLEN));
}
