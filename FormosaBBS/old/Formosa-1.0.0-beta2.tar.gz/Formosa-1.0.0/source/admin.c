
#include "bbs.h"
#include "tsbbs.h"


int
SearchBoard(bhent, bname)
BOARDHEADER *bhent;
char *bname;
{
	int     fd, id;

	if (!bname || bname[0] == '\0')
		return 0;
	if ((fd = open(BOARDS, O_RDONLY, 0)) > 0)
	{
		for (id = 1; read(fd, bhent, BH_SIZE) == BH_SIZE; id++)
		{
			if (bhent->filename[0])
			{
				/* lasehu: �O�W�����j�p�g */
				if (!strcasecmp(bname, bhent->filename))
				{
					close(fd);
					return id;
				}
			}
		}
		close(fd);
	}
	return 0;
}


int
a_info()
{
	USEREC  edit_userec;
	char    edit_userid[IDLEN + 1];

	if (!getdata(1, 0, _msg_ent_userid, edit_userid, sizeof(edit_userid), ECHONOSP, NULL))
		return M_FULL;
	if (get_passwd(&edit_userec, edit_userid) <= 0)
	{
		outs(_msg_err_userid);
		pressreturn();
		return M_FULL;
	}
#ifdef NSYSUBBS
	outs("\n�d�ݬO�_����O�D (Y/N) ? [N] : ", edit_userid);
	if (igetkey() == 'y')
	{
		int     fd;
		int   field_num = 0;
		BOARDHEADER srch_brdh;

		if ((fd = open(BOARDS, O_RDONLY)) > 0)
		{
			outs("\n\n");
			while (read(fd, &srch_brdh, sizeof(srch_brdh)) == sizeof(srch_brdh))
			{
				if (!strcmp(srch_brdh.owner, edit_userid))
				{
					if (++field_num > 3)
					{
						prints("\n");
						field_num = 0;
					}
					prints("[%s] ", srch_brdh.filename);
				}
			}
			close(fd);
		}
		prints("\n�Ы����N��, �~��d�� [%s] ��������.", edit_userid);
		pressreturn();
	}
#endif
	move(1,0);
	clrtobot();
	ShowUserInfo(&edit_userec);
	if (!strcmp(edit_userec.userid, curuser.userid))
		ModifyUserec(&edit_userec, ONLINEUP);	/* �������ۤv����� */
	else
	{
		if (ModifyUserec(&edit_userec, !ONLINEUP) == 1)
			log_usies("MODUSER", "'%s'", edit_userid);
	}
	return M_FULL;
}


int
a_modifybrd()
{
	char    bname[BNAME_LEN + 1];
	BOARDHEADER old_brdh, new_brdh;
	int     bid;

	if (CompleteBoardName(bname) == -1)
		return M_FULL;

	setboardfile(genbuf, bname, "\0");		
	if ((bid = SearchBoard(&old_brdh, bname)) <= 0 || !dashd(genbuf))
	{
		outs("\n");
		outs(_msg_err_boardname);
		pressreturn();
		return M_FULL;
	}

	memcpy(&new_brdh, &old_brdh, sizeof(new_brdh));

	move(2, 0);
	outs("====================================================");
	prints("\n�O    �W : %s", old_brdh.filename);
	prints("\n���廡�� : %s", old_brdh.title);
	prints("\n�ݪO���� : %d", old_brdh.level);
	prints("\n�ݪO���O : %c", old_brdh.class);
	prints("\n��H���O : %c", old_brdh.type);
	prints("\n�{�ҭ��� : %c", (old_brdh.attrib & IDENT_ATTRIB) ? 'Y' : 'N');
	prints("\n�O    �D : %s", old_brdh.owner);
	outs("\n====================================================\n");
	outs(_msg_not_sure_modify);
	if (igetkey() != 'y')
		return M_FULL;

	move(11, 0);
	outs("=== �u�� <Return> �h�Ӷ������ ===");
	while (1)
	{
		if (getdata(12, 0, "�s�O�W   : ", new_brdh.filename, BNAME_LEN + 1, ECHONOSP, NULL))
		{
			setboardfile(genbuf, new_brdh.filename, "\0");
			if (invalid_bname(new_brdh.filename) || dashd(genbuf))
			{
				outs("\n���X�k�O�W �� �ݪO�w�s�b.");
				getkey();
				continue;
			}
			break;
		}
		strcpy(new_brdh.filename, old_brdh.filename);
		break;
	}
	do 
	{
		getdata(13, 0, "���廡�� : ", genbuf, CBNAME_LEN + 1, DOECHO, old_brdh.title);
		strncpy(new_brdh.title, genbuf, CBNAME_LEN);		
	} 
	while (new_brdh.title[0] == '\0');
	if (getdata(14, 0, "�s����   : ", genbuf, 4, ECHONOSP, NULL))
		new_brdh.level = atoi(genbuf);
	if (getdata(15, 0, "�s���O   : ", genbuf, 2, ECHONOSP, NULL))
		new_brdh.class = genbuf[0];
	if (getdata(16, 0, "��H���O (B)��(I)�e(O)��(L)����H: ", genbuf, 2, ECHONOSP, NULL))
	{
		if ((genbuf[0] | 32) == 'b')
			new_brdh.type = 'B';
		else if ((genbuf[0] | 32) == 'i')
			new_brdh.type = 'I';
		else if ((genbuf[0] | 32) == 'o')
			new_brdh.type = 'O';
		else if ((genbuf[0] | 32) == 'l')
			new_brdh.type = '\0';
	}
	getdata(17, 0, "�s�O�D   : ", genbuf, IDLEN + 1, ECHONOSP, old_brdh.owner);
	if (old_brdh.owner[0] && genbuf[0] == '\0')
	{
		move(18, 40);
		outs("�N���O�]���L�O�D (y/n) ? [n]: ");
		if (igetkey() == 'y')
			new_brdh.owner[0] = '\0';		
	}
	else 
		strcpy(new_brdh.owner, genbuf);		
	if (getdata(18, 0, "�{�ҭ��� (y/n) ? (�� Enter �i���L): ", genbuf, 2, ECHONOSP, NULL))
	{
		if ((genbuf[0] | 32) == 'y')
			new_brdh.attrib |= IDENT_ATTRIB;
		else if ((genbuf[0] | 32) == 'n')
			new_brdh.attrib &= ~IDENT_ATTRIB;		
	}
	
	move(19, 0);
	outs(_msg_not_sure_modify);
	if (igetkey() != 'y')
	{
		outs(_msg_aborted);
		pressreturn();
		return M_FULL;
	}
	
	if (strcmp(new_brdh.filename, old_brdh.filename))
	{
		char    brd1[PATHLEN], trea1[PATHLEN], vote1[PATHLEN],
		        brd2[PATHLEN], trea2[PATHLEN], vote2[PATHLEN];

		setboardfile(brd1, old_brdh.filename, "\0");
		setboardfile(brd2, new_brdh.filename, "\0");
		sprintf(trea1, "%s/%s", BBSPATH_TREASURE, old_brdh.filename);
		sprintf(trea2, "%s/%s", BBSPATH_TREASURE, new_brdh.filename);
		sprintf(vote1, "%s/%s", BOARDVOTE, old_brdh.filename);
		sprintf(vote2, "%s/%s", BOARDVOTE, new_brdh.filename);
		
		if (myrename(brd1, brd2) == 0)
		{
			if (myrename(trea1, trea2) == 0)
			{
				if (!dashd(vote1))
					goto finish_modify_board;
				if (myrename(vote1, vote2) == 0)
					goto finish_modify_board;
				myrename(trea2, trea1);
			}
			myrename(brd2, brd1);
		}
		log_usies("ERROR", "cannot rename path '%s' to '%s'");
		outs("\n�L�k�h���ؿ�.");
		outs(_msg_failed);
		pressreturn();
		return M_FULL;
	}
finish_modify_board:		
	if (substitute_record(BOARDS, &new_brdh, sizeof(new_brdh), bid) == -1)
	{
		log_usies("ERROR", "cannot write board '%s'");
		outs(_msg_failed);
		pressreturn();
		return M_FULL;
	}
	if (strcmp(new_brdh.filename, old_brdh.filename))	
		log_usies("MODBOARD", "'%s' To '%s'", old_brdh.filename, new_brdh.filename);
	else
		log_usies("MODBOARD", "'%s'", old_brdh.filename);
	DelBoardList();
	outs(_msg_finished);	
	pressreturn();
	return M_FULL;
}


int
a_pack1brd()
{
	char    bname[BNAME_LEN + 1];
	BOARDHEADER pack_brdh;

	if (CompleteBoardName(bname) == -1)
		return M_FULL;
	if (invalid_bname(bname) || SearchBoard(&pack_brdh, bname) <= 0)
	{
		outs("\n�O�W���~.");
		pressreturn();
		return M_FULL;
	}
	outs(_msg_in_processing);
	refresh();
	sprintf(genbuf, "packbbs -b %s", pack_brdh.filename);
	outdoor(genbuf, ADMIN, NA);
	pressreturn();
	return M_FULL;
}


int
WriteBoardRec(bhr)
BOARDHEADER *bhr;
{
	int     fd, maxbid = 0;
	BOARDHEADER max_brdh;

	if ((fd = open(BOARDS, O_RDWR | O_CREAT, 0644)) > 0)
	{
		flock(fd, LOCK_EX);
		while (read(fd, &max_brdh, sizeof(max_brdh)) == sizeof(max_brdh))
		{
			if (max_brdh.filename[0] == '\0' || max_brdh.bid <= 0)
				continue;
			if (max_brdh.bid > maxbid)
				maxbid = max_brdh.bid;
		}
		if (maxbid <= 0)
			bhr->bid = 1;
		else
			bhr->bid = maxbid + 1;
		if (lseek(fd, 0, SEEK_END) != -1)
		{
			if (write(fd, bhr, BH_SIZE) == BH_SIZE)
			{
				flock(fd, LOCK_UN);
				close(fd);
				return bhr->bid;
			}
		}
		flock(fd, LOCK_UN);
		close(fd);
	}
	return 0;
}


int
a_newbrd()
{
	BOARDHEADER new_brdh;
	char    new_treapath[PATHLEN], new_boardpath[PATHLEN];

	memset(&new_brdh, 0, sizeof(new_brdh));

	while (1)
	{
		BOARDHEADER dup_brdh;
		
		move(2, 0);
		clrtobot();
		if (!getdata(2, 0, "�п�J�O�W (�^��): ", new_brdh.filename, BNAME_LEN + 1, ECHONOSP, NULL))
			return M_FULL;
		setboardfile(genbuf, new_brdh.filename, "\0");
		if (invalid_bname(new_brdh.filename) 
		    || dashd(genbuf)
		    || SearchBoard(&dup_brdh, new_brdh.filename) > 0)
		{
			outs("\n���X�k�O�W �� �ݪO�w�s�b.");
			pressreturn();
			continue;
		}
		break;
	}
	if (!getdata(3, 0, "���廡�� : ", new_brdh.title, CBNAME_LEN + 1, DOECHO, NULL))
		return M_FULL;
	if (getdata(4, 0, "�ݪO���� (0 ~ 255) [0] : ", genbuf, 4, ECHONOSP, NULL))
		new_brdh.level = atoi(genbuf);
	else
		new_brdh.level = 0;
	if (getdata(5, 0, "�ݪO���O: ", genbuf, 2, ECHONOSP, NULL))
		new_brdh.class = genbuf[0];
	else
		new_brdh.class = '\0';
	if (getdata(6, 0, "��H���O (B)��(I)�e(O)��(Enter)����H: ", genbuf, 2, ECHONOSP, NULL))
	{
		if ((genbuf[0] | 32) == 'b')
			new_brdh.type = 'B';
		else if ((genbuf[0] | 32) == 'i')
			new_brdh.type = 'I';
		else if ((genbuf[0] | 32) == 'o')
			new_brdh.type = 'O';
	}
	if (getdata(7, 0, "�O�D (�� Enter �i���L): ", genbuf, IDLEN + 1, ECHONOSP, NULL))
		strcpy(new_brdh.owner, genbuf);
	else
		new_brdh.owner[0] = '\0';
	if (getdata(8, 0, "�{�ҭ��� (y/n) ? [n]: ", genbuf, 2, ECHONOSP, NULL))
	{
		if ((genbuf[0] | 32) == 'y')
			new_brdh.attrib |= IDENT_ATTRIB;
		else
			new_brdh.attrib &= ~IDENT_ATTRIB;
	}

	outs("\n�T�w�إ߶� ? (y/n) [n] : ");
	if (igetkey() != 'y')
		return M_FULL;

	setboardfile(new_boardpath, new_brdh.filename, "\0");
	if (mkdir(new_boardpath, 0700) == -1)
	{
		outs("\n�إߤ@��ϥؿ�����.");
		log_usies("ERROR", "create board '%s'", new_brdh.filename);
		pressreturn();
		return M_FULL;
	}
	sprintf(new_treapath, "%s/%s", BBSPATH_TREASURE, new_brdh.filename);
	if (mkdir(new_treapath, 0700) == -1)
	{
		myunlink(new_boardpath);
		outs("\n�إߺ�ذϥ���.");
		log_usies("ERROR", "create treasure '%s'", new_brdh.filename);
		pressreturn();
		return M_FULL;
	}
	if (WriteBoardRec(&new_brdh) <= 0)
	{
		myunlink(new_boardpath);
		myunlink(new_treapath);
		log_usies("ERROR", "append record of board '%s'", new_brdh.filename);
		outs(_msg_failed);
		pressreturn();
		return M_FULL;
	}
	outs(_msg_in_processing);
	refresh();
	outdoor("sortbrd", ADMIN, NA);
	log_usies("NEWBOARD", "'%s'", new_brdh.filename);
	DelBoardList();	
	outs(_msg_finished);
	pressreturn();
	return M_FULL;
}


int
a_delbrd()
{
	char    bname[BNAME_LEN + 1];
	BOARDHEADER del_brdh;
	int     ent;

	if (CompleteBoardName(bname) == -1)
		return M_FULL;
	if ((ent = SearchBoard(&del_brdh, bname)) <= 0)
	{
		outs("\n");
		outs(_msg_err_boardname);
		pressreturn();
		return M_FULL;
	}
	prints("\n�R���ݪO '%s'. \n==> �T�w�n���� ? (y/n) [n] : ", del_brdh.filename);
	if (igetkey() != 'y')
	{
		outs(_msg_aborted);
		pressreturn();
		return M_FULL;
	}

	if (delete_record(BOARDS, sizeof(del_brdh), ent) == -1)
	{
		log_usies("ERROR", "delete record of board '%s'", del_brdh.filename);
		outs(_msg_failed);
		pressreturn();
		return M_FULL;
	}
	setboardfile(genbuf, del_brdh.filename, "\0");
	myunlink(genbuf);
	sprintf(genbuf, "%s/%s", BBSPATH_TREASURE, del_brdh.filename);
	myunlink(genbuf);
	sprintf(genbuf, "%s/%s", BOARDVOTE, del_brdh.filename);
	myunlink(genbuf);

	log_usies("DELBOARD", "'%s'", del_brdh.filename);
	DelBoardList();	
	outs(_msg_finished);
	pressreturn();
	return M_FULL;
}


#ifdef HAVE_DELUSER
int
a_deluser()
{
	char    DelUserid[IDLEN + 1];

	if (!getdata(2, 0, _msg_ent_userid, DelUserid, sizeof(DelUserid), ECHONOSP, NULL))
		return M_FULL;
#ifdef MULTIBBS
	if (dashf(NONEWUSER))
	{
		outs("\n��ƥ��s�u, �L�k�R��");
		pressreturn();
		return M_FULL;
	}
#endif
	if (delete_user(DelUserid) <= 0)
	{
		outs(_msg_failed);
		log_usies("ERROR", "delete user '%s'", DelUserid);
	}
	else
	{
		outs(_msg_finished);
		log_usies("DELUSER", "'%s'", DelUserid);
	}
	pressreturn();
	return M_FULL;
}
#endif


int
a_welcome()
{
	if (vedit(WELCOME, NULL))
		outs("\nWelcome NOT changed.");
	else
		outs("\nWelcome updated.");
	pressreturn();
	return M_FULL;
}


int
a_bbsnews()
{
	if (vedit(B_N_CONFIG_FILE, NULL))
		outs("\nBBS-NEWS.conf NOT changed.");
	else
		outs("\nBBS-NEWS.conf updated.");
	pressreturn();
	return M_FULL;
}


int
a_cloak()
{
	uinfo.invisible = (uinfo.invisible) ? NA : YEA;
	update_utmp();
	move(2, 0);
	clrtoeol();
	prints("%s���μҦ�", (uinfo.invisible) ? "�}��" : "����");
	pressreturn();
	return M_FULL;
}


char    kickuser[IDLEN + 1];
int     kick_num;

kick_user(upent)
USER_INFO *upent;
{
	if (!upent || upent->userid[0] == '\0')
		return -1;
	if (strcmp(upent->userid, kickuser))
	{
		return -1;
	}
	if (upent->pid > 2)
		kill(upent->pid, SIGKILL);
/* lasehu: not write back user data */	
	purge_utmp(upent);	
	kick_num++;
	return 0;
}


int
a_kick()
{
#if defined(KGHSBBS) || defined(EAGLEBBS)
	clear();
	prints("1. �j�����u\n2. kill process\n�п�J��ܡG");
	if (igetkey() == '2')
	{
		char buf[7];
		pid_t pid;
		
		prints("\n�п�J process id : ");
		getdata(5, 0, "\n�п�J process id : ", buf, sizeof(buf), DOECHO, NULL);
		if (*buf && (pid = atoi(buf)) > 2)
		{
			kill(pid, SIGKILL);
			prints("\nkill process %d ok!\n", pid);
		}
		pressreturn();
		return M_FULL;
	}
#endif
	if (CompleteOnlineUser(kickuser) == -1)
		return M_FULL;
	prints("\n�T�w�N�ϥΪ� '%s' �j�����u (y/n) ? [n]: ", kickuser);
	if (igetkey() != 'y')
	{
		outs(_msg_aborted);
		pressreturn();
		return M_FULL;
	}
	kick_num = 0;
	apply_ulist(kick_user);
	prints("\n�M�� �ϥΪ� '%s' �u�W logins �@ [%d] ��", kickuser, kick_num);
	log_usies("KICK", "'%s'", kick_user);	
	pressreturn();
	return M_FULL;
}


int
broadcast(upent)
USER_INFO *upent;
{
	if (!upent || upent->userid[0] == '\0')
		return -1;
#ifdef GUEST_ACCOUNT
	if (!strcmp(upent->userid, GUEST_ACCOUNT))
		return -1;
#endif
	if (!strcmp(upent->userid, curuser.userid))
		return -1;
	if (!HAS_PERM(PERM_CLOAK) && upent->invisible)
		return -1;
	if (!HAS_PERM(PERM_SYSOP) && !upent->pager
	    && !can_override(upent->userid, curuser.userid))
	{
		return -1;
	}
	if (is_in_outdoor(upent))
		return -1;
	MessageUser(upent);
	return 0;
}


int
a_broadcast()
{
	if (PrepareMesgContent() == 0)
	{
		apply_ulist(broadcast);
		msg("�T���w�e�X");
		getkey();
	}
	return M_FULL;
}


int
invalid_bname(bname)
char   *bname;
{
	unsigned char ch;
	int i;	

	if (!bname || bname[0] == '\0')
		return 1;
	if (strlen(bname) > BNAME_LEN)
		return 1;
	for (i = 0; (ch = bname[i]); i++)
	{
		if (!isalnum(ch) && ch != '-' && ch != '_')
			return 1;
	}
	return 0;
}

