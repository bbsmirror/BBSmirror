
#ifndef _BBS_STRUCT_H_
#define _BBS_STRUCT_H_


/*************************************************************************
 *	��Ƶ��c�w�q��
 *************************************************************************/
#define DIR_REC 	".DIR"
#define PASSFILE	"conf/.PASSWDS"
#define BOARDS		"conf/.BOARDS"
/* #define ULIST	".UTMP" */
#define USERIDX		"conf/.USERIDX"

#define BM_WELCOME	".bm_welcome"
#define BM_ASSISTANT	".bm_assistant"	


#define BOARDVOTE 	"vote/boards/"
#define SYSVOTE 	"vote/sys/"


#define STRLEN   80    	/* Length of most string data */
#define IDLEN	 12    	/* Length of userids */
#define CRYPTLEN 8	/* �� 8 �Ӧr���g crypt �s�X�L�Უ�� 13 �Ӧr�� */
#define PASSLEN  14    	/* Length of encrypted passwd field */
#define UNAMELEN 20	/* Length of username */

struct useridx {			/* Structure used in .USERIDX */
	char userid[IDLEN+2];
};

struct userec {			/* Structure used to hold information in */
	char userid[IDLEN+2] ;	/* PASSFILE */
	char filler[30];	/** unused **/
	time_t firstlogin; 	/* lasehu: user new register time */	
	char lasthost[16];
	unsigned int numlogins;
	unsigned int numposts;
	unsigned char flags[2];	/** flags[1] unused **/
	char passwd[PASSLEN] ;
	char username[STRLEN-52] ; 
	char unused_str1[52];
	char termtype[8];
	char lastctype ;	/* c_type: CSBBS or TSBBS */
	char unused_str2[STRLEN-10] ;	
	char ident;
	unsigned int userlevel ;
	time_t lastlogin ;
	int protocol ;		/** unused **/
	unsigned int uid;	/** ? **/
	char email[STRLEN-44]; 
	char unused[44];
} ;

typedef struct userec USEREC;

/* these are flags in userec.flags[0] */
#define PAGER_FLAG 	0x1   	/* true if pager was OFF last session */
#define CLOAK_FLAG 	0x2   	/* true : cloak ON */
#if 0
# define VOTE_FLAG  	0x4  	/* for controlling Votes */
#endif
#define FORWARD_FLAG  	0x4  	/* true if auto-forward personal's mail */
#define SIG_FLAG   	0x8 	/* true if sig was turned OFF last session */
#if 0
#define OVERRIDES_FLAG	0x10
#endif
#if 0
# define NOCLEAN_FLAG 0x10 	/* true is user is immune from User Clean */
#endif
#define	CURSOR_FLAG 	0x20 	/* the cursor menu flag, true if use cursor */
#define	YANK_FLAG  	0x40 	/* the board list yank flag, true if yank out */
#define	COLOR_FLAG 	0x80 	/* color mode or black/white mode, ture is b/w  */

#define PICTURE_FLAG	0x01	/* true if use motive picture mode */


struct user_info {		/* Structure used in UTMP file */
	int active ;		/* When allocated this field is true */
	unsigned int uid ;	/* Used to find user name entry in passwd file */
	pid_t pid ;	/* kill() is used to notify user of talk request*/
	int invisible ;		/* Used by cloaking function in Xyz menu */
	int sockactive ;	/* Used to coordinate talk requests */
	int sockaddr ;		/* ... */
	unsigned int destuid;
	char destid[IDLEN+2];   /* talk parner user's id name */
	int mode ;		/* UL/DL, Talk Mode, Chat Mode, ... */
	int pager ;		/* pager toggle, YEA, or NA          */
	int in_chat ;		/* for in_chat commands   */
	int sysuid ;	/** unused **/
	char userid[IDLEN+2];
	char username[UNAMELEN];/* user nickname */
	char from[16] ;		/* machine name the user called in from */
	char chatid[16];	/* chat id, if in chat mode */
	time_t time;    /** unused **/
	char c_type;        	/* connect type : CTYPE_CSBBS CTYPE_TSBBS */
} ;

typedef struct user_info USER_INFO;


/*------------------------------------------------------------*/
/* Shaed Memory --- For Online User Static File (ULIST) .UTMP */
/*------------------------------------------------------------*/
#define USHM_SIZE       (MAXACTIVE + 4)

struct UTMPFILE 
{
    USER_INFO uinfo[USHM_SIZE];
    time_t uptime;
    int number;
    int busystate;
};


struct fileheader {			/* This structure is used to hold data in */
        char filename[STRLEN-4-4];
        int  artno;			/* lasehu: �G�i�s�� */
	char owner_ident;		/* Record if Register or .... */
	char class;		/* ? */
	char type;		/* ? */
	char region;		/* unused */
	char owner[STRLEN] ;
	char title[STRLEN] ;
	unsigned int level;	/* ? */
	unsigned char accessed ;/* ? */
} ;


typedef struct fileheader FILEHEADER;

#define FH_SIZE		(sizeof(struct fileheader))


#define FILE_READ  0x01    /* Ownership flags used in fileheader structure */
#define FILE_DELE  0x02    /* mark article as deleted */
#define FILE_TREA  0x04	  /* ��ذϥؿ� */
#define FILE_RESRV 0x08	/* �峹�O�d */
#define FILE_IN    0x10    /* �����ɮ� */
#define FILE_OUT   0x20   /* ���~�ɮ� */


#define BNAME_LEN	16
#define CBNAME_LEN	36


struct boardheader {		/* This structure is used to hold data in */
	char filename[BNAME_LEN+4];
	time_t	rewind_time;	/* lasehu: last refresh boardrc time */
	unsigned int bid;	/* board unique number, always increasing */
	char unused[STRLEN-BNAME_LEN-15];
	char class;		/* �O������ */
	char type;		/* ��H���O  */
	unsigned char attrib;	/* �ݪO�ݩʺX�� */
	char owner[STRLEN];
	char title[CBNAME_LEN+4];	
	char unused_title[STRLEN-CBNAME_LEN-4] ; 
	unsigned int level;	/* ? */
	unsigned char accessed[10000];/* ? */
} ;

typedef struct boardheader BOARDHEADER;

#define BH_SIZE	(sizeof(struct boardheader))


/* the attrib of board */
#define IDENT_ATTRIB		0x01
#define UNZAP_ATTRIB		0x02
#define NONPOSTNUM_ATTRIB	0x04
#define SECRET_ATTRIB		0x08
#define ANONYMOUS_ATTRIB	0x10
#define VOTING_ATTRIB		0x20
#define NEWS_ATTRIB		0x40
/* #define UNUSED_ATTRIB		0x80 */

#define CTYPE_CSBBS 		0
#define CTYPE_TSBBS 		1


/*
 * �W�u�H���O��
 */
struct visitor {
    char userid[IDLEN+2];
    time_t when;
    char from[16];
};


/* each keyword of personal files */
#define UFNAME_BOARDRC		"boardrc"
#define UFNAME_EDIT			"edit"
#define UFNAME_IRCRC		"ircrc"
#define UFNAME_MAIL			"mail"
#define UFNAME_OVERRIDES	"overrides"
#define UFNAME_PASSWDS		"passwds"
#define UFNAME_PLANS		"plans"
#define UFNAME_RECORDS		"records"
#define UFNAME_SIGNATURES	"signatures"
#define UFNAME_WRITE		"write"
#define UFNAME_ZAPRC		"zaprc"


#define STR_REPLY	"Re: "



#if 0
struct readrc {
	short	bid;
    unsigned char rlist[BRC_MAXNUM]; 
    time_t	mtime;
	time_t  atime;
};
#endif
	

/*******************************************************************
 * �ݪO�G�i�\Ū�O���O�����c
 * 	Total size = BRC_ITEMSIZE = 512 Bytes 
 *******************************************************************/
 
#define BRC_MAXSIZE	(20*BRC_ITEMSIZE)
#define BRC_MAXNUM      (495)
#define BRC_STRLEN      BNAME_LEN
/*---
#define BRC_ITEMSIZE    \
  (BRC_STRLEN + 1 + BRC_MAXNUM * sizeof(unsigned char) + 1 * sizeof(time_t))
*/
#define BRC_ITEMSIZE    \
  (BRC_STRLEN + BRC_MAXNUM * sizeof(unsigned char) + 1 * sizeof(time_t))
#define BRC_REALMAXNUM	(BRC_MAXNUM*8)


#endif /* _BBS_STRUCT_H_ */

