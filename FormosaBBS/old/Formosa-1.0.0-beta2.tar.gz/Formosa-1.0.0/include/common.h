
#ifndef _BBS_COMMON_H_
#define _BBS_COMMON_H_

#ifdef _BBS_SITE_H_


#include "struct.h"
#include "perm.h"
#include "net.h"
#include "modes.h"      /* The list of valid user modes */
#include "shm.h"


struct  BoardList {             /* lmj@cc.nsysu.edu.tw */
	char    *name ;
	char    *owner ;
	char    *title ;
	int     num ;
	char    type ;
	char	class;	
	unsigned int bid;	
	unsigned int  level ;
	int     btop ;		
	int     bcur ;		/* �O���Y�O�\Ū��а��d�峹�s�g�� */
	unsigned char attrib ; 	/* lasehu: �ݪO�ݩʺX�� */
	char	visit_flag ;	/* �����W�u�O�_�w��L���ݪO */
	time_t  rewind_time ;   /* �ݪO�G�iŪ���O����s�ɶ� */
#ifdef USE_VOTE
	char	vote_flag ;	/* �ݪO�O�_���i��벼�� */
#endif	
/*
	int     ttop ;
	int     tcur ;
*/	
};

struct	word	{
	struct	word	*last;
	char	*word;
	struct	word	*next;
};

struct	bword	{
	struct	bword	*last;
	struct	BoardList	*word;
	struct	bword	*next;
};


/*******************************************************************
 *	�禡 prototype �ŧi					
 *******************************************************************/
extern char* genpasswd(); 

extern struct user_info *search_ulist(); 


#define NL		0x0a	/* new line char */
#define CR		0x0d	/* Enter */
#define ENTER		0x0d	/* Enter */
#define SP		0x20	/* space cchar */
#define ESC		0x1b	/* Esc char */
#define TAB		0x09	/* TAB char */

#define YEA (1)        	/* Booleans  (Yep, for true and false) */
#define NA  (0) 
#define YES 'Y'		/* a char Yes or No */
#define NO  'N'

#define QUIT_LOOP 0x666 /* Return value to abort apply_xxxxx functions */

#define PATHLEN  128	/* Length of directory (including path & filename) */

/*************************************************************************
 *      ���|�P�ɦW�w�q��
 *************************************************************************/
#define BOARD_HELP      "doc/BOARD_HELP"
#define READ_HELP       "doc/READ_HELP"
#define MAIL_HELP       "doc/MAIL_HELP"
#define EDIT_HELP       "doc/EDIT_HELP"
#define WELCOME0        "doc/Welcome0"
#define WELCOME         "doc/Welcome"


#endif  /* _BBS_SITE_H_ */

#endif	/* _BBS_COMMON_H_ */
