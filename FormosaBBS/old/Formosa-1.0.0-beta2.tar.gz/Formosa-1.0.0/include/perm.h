
#ifndef _BBS_PERM_H_
#define _BBS_PERM_H_


#if 0
#define CHECK_PERM(ulevelbits, x)	( (x) ? ulevelbits&(x) : 1)
#endif
#define CHECK_PERM(ulevelbits, x)	((ulevelbits == x) ? 1 : 0)

#define PERM_CHAT	40 /** 0x00000001 'C' **/
#if 0
#define PERM_POST	0x00000001 'P'
#define PERM_EMAIL	0x00000002 'E'
#define PERM_POSTNEWS	0x00000004 	/** �i�e�W News **/
#endif
#define PERM_BM		100 /** 0x00000010 'B' **/
#define PERM_CLOAK	255 /** 0x00000100 'O' **/
#define PERM_CLOAKLOGIN 256 /** ? **/

#define PERM_SYSOP	255 /** 0x00000020 'S' **/
#if 0
#define PERM_CHECKID	0x00000040 'I'
#define PERM_BBSTEAM	0x00000000

#define PERM_CHAT2	25
#define PERM_CHAT3	10
#define PERM_CHAT4	5
#define PERM_CHATIGNORE 0x00000100
#define PERM_TALK
#define PERM_BASIC

#define PERM_XEMPT		'X'		/* �b���ä[�O�d */

#define PERM_DEFAULT	(PERM_BASIC|PERM_CHAT|PERM_TALK|PERM_POST)

#define PERM_LOGINOK

#define PERM_POSTMASK				/* ���� Post */
#define PERM_READMASK				/* ���� Read */
#endif

#define PERM_NOTIMEOUT 	(PERM_SYSOP)|(PERM_BM)	/* ���Q IDLE KILL */


#endif	/* _BBS_PERM_H_ */
