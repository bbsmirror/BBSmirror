
#ifndef _BBS_SHM_H_
#define _BBS_SHM_H_


#define UTMPSHM_KEY     1219	/* shared memory key: should be unique */


extern void *  attach_shm(/* int shmkey, int shmsize */);


#endif /* _BBS_SHM_H_ */