
#ifndef _BBS_NET_H_
#define _BBS_NET_H_


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netdb.h>
#include <memory.h>

/* for connect() function call */
#include <sys/types.h>
#include <sys/socket.h>

/* for inet_addr() function call */
#include <netinet/in.h>
#include <arpa/inet.h>


#define TCP	0
#define UDP 1


#endif /* _BBS_NET_H_ */