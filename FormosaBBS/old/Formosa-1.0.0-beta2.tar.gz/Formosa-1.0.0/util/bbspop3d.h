/*************************************************************************
 * 	�t�Χt�A��
 *************************************************************************/

#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <ctype.h>
#include <errno.h>
#include <pwd.h>
#include <sys/param.h>
#include <sys/time.h>
#include <unistd.h>		/* for lockf() --lmj@cc.nsysu */
#ifdef	NO_DIRENT
# include <sys/dir.h>
#else
# include <dirent.h>
#endif

#include <string.h>
#ifdef	AIX
# include <sys/select.h>
#endif


#include <sys/time.h>
#include <sys/socket.h>
#include <sys/file.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <netdb.h>

/*************************************************************************
 *	�۩w�t�A��
 *************************************************************************/
#include "site.h"		/* BBS Site name type */
#include "config.h"		/* User-configurable stuff */
#include "struct.h"


/*************************************************************************
 *	�C���w�q
 *************************************************************************/
#ifdef  SYSV
# ifndef LOCK_EX
#  define LOCK_EX		F_LOCK
#  define LOCK_UN		F_ULOCK
# endif
# define getdtablesize()		(64)
#endif

#ifndef LOCK_EX
#	define LOCK_EX         2       /* exclusive lock */
#	define LOCK_UN         8       /* unlock */
#endif


#ifdef XINU
	extern int errno ;
#endif




/*************************************************************************
 *	�N�W���w�q��
 *************************************************************************/
#define YEA (1)        /* Booleans  (Yep, for true and false) */
#define NA  (0) 
#define YES 'Y'		/* a char Yes or No */
#define NO  'N'

#define STRLEN   80    /* Length of most string data */
#define IDLEN	 12    /* Length of userids */
#define PASSLEN  14    /* Length of encrypted passwd field */




#define POP3_SERVER_PORT       110
#define LOCKFILE                "conf/popsrv.lock"      /* daemon lock file */
#define CLIENT_READ_TIMEOUT     1800  /* 30 mins */
#define CLIENT_WRITE_TIMEOUT    300   /* 5 mins */
#define KEYWORD_DELIMITER	" \t\r\n"
#define CRACKFILE "/conf/.POPSRV-CRACK"

struct ProtocolJob {
        int     KeyNo;
        int     (* FunPtr)();
};



#define MAX_KEYWORD_LEN 12
#define KEYWORD_DELIMITER       " \t\r\n"

/********************* command protocol number list *********************/
#define USER            20              /* ñ�J�t��   */
#define PASS			24				/* ��J�K�X */
#define _QUIT           29              /* ���} */

#define STAT			40				/* ���o�`�H��ƤΤj�p */
#define LIST			41				/* ���o�H���� */
#define RETR			42				/* ���o�H�󤺮e */
#define DELE			43				/* �R���@�ʫH�� */
#define NOOP			44				/* none			*/
#define RSET			45				/* �����R���H�� */
#define UIDL			46				/* ���o�H��ߤ@�s�� */
#define TOP				47				/* ���o�H�󪺫e�X�椺�e*/


/******************** respond protocol number list ********************/
#define HAVE_NEW_MAIL		632		/* ���s�H!! */

#define NOT_SAY_HELLO           711             /* �|�����۩I!! */
#define NOT_ENTER               713             /* �ϥΪ̩|���E�J */

#define NEWUSER_FAIL            721             /* ���U���� */
#define NOT_ALLOW_NEW           722             /* �����\\�s�b�����U */
#define PASSWORD_ERROR          724             /* �K�X���~ */
#define PASSWORD_3_ERROR        725             /* �K�X���~�T��,�j�����u */

#define MAIL_NOT_EXIST          731             /* ���ʫH�󤣦s�b */

#define UNKNOW_CMD              790             /* �S���R�O */
#define SYNTAX_ERROR            791             /* �y�k���~ */
#define USER_NOT_LOGIN          792             /* �ϥΪ̩|��ñ�J */
#define WORK_ERROR              793             /* �u�@���� */

#define OK_CMD                  800             /*  OK!! */

