/*******************************************************************
 * �R���@�w���������W�����ϥΪ�
 *******************************************************************/

#include "bbs.h"


int      debug = 0;

char     buf[512];

#define LEAST_DAYS	(30)	/* �X�m�������W�����M���b�� */

#define UIDXSIZE	sizeof(struct useridx)
#define USERECSIZE	sizeof(struct userec)

#define MAX_REG_USERS	(90000)

#define K_NORMAL	0x01
#define K_INDEX		0x02
#define K_PASSWDS	0x04
#define K_EXPIRE	0x08
#define K_ERROR		0x10


void
delete_user_file(ident)		/* delete user data */
char    *ident;
{
    char     from[PATHLEN], to[PATHLEN];

    if (strstr(ident, "..") || strchr(ident, '/')) /* debug */
	return;

    sethomefile(from, ident, UFNAME_PASSWDS);
    gethomefile(to, ident, BBSPATH_DELUSER);
    myrename(from, to);
#if 0    
#ifdef MULTIBBS
    sprintf(from, "/%s/var/passwds/%s", HOMEBBS, ident);
    unlink(from);
#endif
#endif
    setmailfile(from, ident, NULL);
    myunlink(from);
    sethomefile(from, ident, NULL);
    myunlink(from);
}


void
main(argc, argv)
int      argc;
char    *argv[];
{
    struct userec user;
    struct useridx idxname;
    int      fidx, fap;
    register time_t now = time(0);
    register int k_exp;
    register unsigned int total_records, alive;
    register unsigned int myday, mylogin;

    if (argc < 3)
    {
	printf("Syntax : %s logins days [debug]\
\n\nExample : %s 60 30\nThis means delete users who had login 60 times \
and didn't login in 30 days.\n", argv[0], argv[0]);
	exit(0);
    }
    
    if (getuid() != BBS_UID)
    {
	if (chroot(HOMEBBS) == -1 || chdir("/") == -1)
	{
	    printf("\n\n!!! �Х� root �� bbs �Ӱ��楻�{�� !!!\n");
	    exit(-1);
	}
	setgid(BBS_GID);
	setuid(BBS_UID);
    }
    else
    {
        if (chdir(HOMEBBS) == -1)
        {
            printf("\n\n!!! BBS Home Directory not exist !!!\n");
            exit(-1);
        }
    }

    debug = 0;
    if (argc > 3)
    {
        if (!strcmp(argv[3], "debug"))
            debug = 1;
    }
            
#if 0
#ifdef MULTIBBS
    sprintf(buf, "var/%s", USERIDX);
    if ((fidx = open(buf, O_RDONLY)) < 0)
    {
	printf("\nNot connect with BBS2!!\n");
	exit(0);
    }
    close(fidx);
#endif
#endif

    myday = atoi(argv[2]);
    mylogin = atoi(argv[1]);

    if (myday < LEAST_DAYS)
    {
	printf("[days] Autoset to <%d> !\n", LEAST_DAYS);
	myday = LEAST_DAYS;
    }
    printf("\nDelete User [%d days] [%d logins] ...\n", myday, mylogin);

    sprintf(buf, "%s", USERIDX);
    if ((fidx = open(buf, O_RDWR)) < 0)
    {
	printf("\nCannot open [%s] !\n", buf);
	exit(0);
    }
    flock(fidx, LOCK_EX);

    if ((fap = open(PASSFILE, O_RDWR)) < 0)
    {
	printf("\nCannot open [%s] !\n", PASSFILE);
	exit(0);
    }

    total_records = 0;
    alive = 0;
    while (read(fidx, &idxname, UIDXSIZE) == UIDXSIZE)
    {
	total_records++;
	if (idxname.userid[0] == '\0')
	    continue;

	k_exp = K_NORMAL;

	if (!strcmp(idxname.userid, "new"))
	    k_exp = K_INDEX;
	else
	{
	    int      fpass;

	    memset(&user, 0, USERECSIZE);
	    sethomefile(buf, idxname.userid, UFNAME_PASSWDS);
	    if ((fpass = open(buf, O_RDONLY)) < 0)
	    {
		printf("[%-20.20s] not exist\n", idxname.userid);
		k_exp = K_ERROR;
	    }
	    else
	    {
		if (read(fpass, &user, USERECSIZE) != USERECSIZE)
		{
		    k_exp = K_ERROR;
		    printf("%s file length illegel\n", idxname.userid);
		}
		close(fpass);
	    }
	}

	if (k_exp == K_NORMAL)
	{
#ifdef NSYSUBBS
	    if ((user.userlevel < 50 && (now - user.lastlogin) > (86400 * 30))
		|| (user.userlevel == 50 && (now - user.lastlogin) > (86400 * 90)))
#else
	    if (user.numlogins < mylogin && (now - user.lastlogin) > (86400 * myday))
#endif
	    {
		k_exp = K_EXPIRE;
		printf("uid[%-5d] Name: %-20.20s level[%-3d] %s",
		    user.uid, idxname.userid, user.userlevel,
		    ctime(&user.lastlogin));		
	    }
	    else 
	        alive++;
	}

	if (debug)
	    continue;	
	if ((k_exp & K_INDEX) || (k_exp & K_EXPIRE))
	{
	    memset(&idxname, 0, UIDXSIZE);
	    lseek(fidx, -((off_t)UIDXSIZE), SEEK_CUR);
	    write(fidx, &idxname, UIDXSIZE);
	}
	if ((k_exp & K_PASSWDS) || (k_exp & K_EXPIRE))	
	{
	    delete_user_file(idxname.userid);

	    memset(&user, 0, USERECSIZE);
	    lseek(fap, (off_t) ((total_records - 1) * USERECSIZE), SEEK_SET);
	    write(fap, &user, USERECSIZE);
	}
    }
    close(fap);
    close(fidx);

    printf("\nTotal: [%d] records, [%d] Users alive\n", total_records, alive);
    
    if (alive > MAX_REG_USERS)
    {
	int      fd;

	if ((fd = open(NONEWUSER, O_CREAT | O_WRONLY, 0644)) < 0)
	{
	    printf("\nCannot create [%s] !\n", NONEWUSER);	
	    exit(2);
	}
	close(fd);

    }
}
