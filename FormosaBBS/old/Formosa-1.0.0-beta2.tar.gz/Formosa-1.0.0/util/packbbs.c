
#include "bbs.h"


/*
 * �T��M���Q�аO�� 'D' ���R�����峹
 */
pack_article(direct)
char  *direct;
{
    int    fr, fw;
    FILEHEADER fh;
    FILEHEADER *fhr = &fh;
    char   fname[PATHLEN], new[PATHLEN], del[PATHLEN];

    sprintf(new, "%s.new", direct);
    sprintf(del, "%s.del", direct);
/* lasehu 
   tempfile(new); 
   tempfile(del);
 */
    if ((fr = open(direct, O_RDONLY)) < 0)
	return -1;
    if ((fw = open(new, O_WRONLY | O_CREAT | O_TRUNC, 0644)) < 0)
    {
	close(fr);
	return -1;
    }
    flock(fr, LOCK_EX);
    while (read(fr, fhr, FH_SIZE) == FH_SIZE)
    {
	if (fhr->accessed & FILE_DELE)
	{
	    strcpy(fname, direct);
	    sprintf(strrchr(fname, '/') + 1, "%s", fhr->filename);
	    unlink(fname);
	}
	else
	{
	    if (write(fw, fhr, FH_SIZE) != FH_SIZE)
	    {
		flock(fr, LOCK_UN);
		close(fr);
		close(fw);
		unlink(new);
		return -1;
	    }
	}
    }
    close(fw);
    flock(fr, LOCK_UN);
    close(fr);
    if (rename(direct, del) == 0)
    {
	if (rename(new, direct) == 0)
	{
	    unlink(del);
	    return 0;
	}
	rename(del, direct);
    }
    unlink(new);
    return -1;
}


main(argc, argv)
int    argc;
char  *argv[];
{
    char   path[STRLEN];
    int    fd;
    char   id[STRLEN];
    struct boardheader bh;
    int   c, mode;

    extern char *optarg;

    if (getuid() != BBS_UID)
    {
	if (chroot(HOMEBBS) == -1 || chdir("/") == -1)
	{
	    printf("\n\r!!! �Х� root �� bbs �Ӱ��楻�{�� !!!\n\r");
	    exit(-1);
	}
	setgid(BBS_GID);
	setuid(BBS_UID);
    }
    else
    {
	struct stat st;

        if (stat("/boards", &st) && chdir(HOMEBBS) == -1)
        {
            printf("\n\r!!! BBS Home Directory not exist !!!\n\r");
            exit(-1);
        }
    }
    

    if (argc < 2)
    {
	fprintf(stderr, "Usage: packbbs [-a] [-b boardname] [-m userid]\n\r");
	exit(0);
    }

    while ((c = getopt(argc, argv, "ab:m:")) != -1)
    {
	switch (c)
	{
	    case 'a':
	        mode = 'a';
		break;
	    case 'b':
	        mode = 'b';
	        strcpy(id, optarg);	    	        
	        break;
	    case 'm':
	        mode = 'm';
	        strcpy(id, optarg);	    
		break;
	    case '?':
	    default:
		fprintf(stderr, "Usage: packbbs [-a] [-b boardname] [-m userid]\n\r");
		break;
	}
    }
    
    switch (mode)
    {
	case 'a':		/* pack all boards */
	    if ((fd = open(BOARDS, O_RDONLY)) > 0)
	    {
		while (read(fd, &bh, sizeof(bh)) == sizeof(bh))
		{
		    sprintf(path, "boards/%s/%s", bh.filename, DIR_REC);
		    printf(" Pack '%s' �� ...\n\r", bh.filename);
		    if (pack_article(path) == -1)
			printf("\n\r Pack '%s' �� ...����!!\n\r", bh.filename);
		    else
			printf("\n\r Pack '%s' �� ...����!!\n\r", bh.filename);
		}
		printf(" Pack�@�~����!!\n\r");
	    }
	    break;
	case 'b':
	    sprintf(path, "boards/%s/%s", id, DIR_REC);
	    printf(" Pack '%s' �� ...\n\r", id);
	    if (pack_article(path) == -1)
		printf("\n\r Pack '%s' �� ...����!!\n\r", id);
	    else
		printf("\n\r Pack '%s' �� ...����!!\n\r", id);
	    break;
	case 'm':
	    setmailfile(path, id, DIR_REC);
	    printf(" Pack '%s' �H�c ...\n\r", id);
	    if (pack_article(path) == -1)
		printf("\n\r Pack '%s' �H�c ...����!!\n\r", id);
	    else
		printf("\n\r Pack '%s' �H�c ...����!!\n\r", id);
	    break;
	default:
	    break;
    }
}
