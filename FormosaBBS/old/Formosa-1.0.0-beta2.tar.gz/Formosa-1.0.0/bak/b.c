#include "bbs.h"

main()
{
	struct boardheader bh;
	int fr, fw;
	unsigned int cnt = 0;
	char path1[80], path2[80];

	setgid(BBS_GID);
	setuid(BBS_UID);
	strcpy(path1, "/apps/bbs/.BOARDS");
	strcpy(path2, "/apps/bbs/.BOARDS.new");
	if((fr = open(path1, O_RDONLY)) > 0)
	{
		if((fw = open(path2, O_WRONLY|O_CREAT, 0644)) > 0)
		{
			while(read(fr, &bh, sizeof(bh)) == sizeof(bh))
			{
				bh.bid = ++cnt;
				write(fw, &bh, sizeof(bh));
			}
			close(fw);
		}
		close(fr);
	}
	strcpy(path2, "/apps/bbs/.BOARDS.old");
	rename(path1, path2);
	strcpy(path2, "/apps/bbs/.BOARDS.new");
	rename(path2, path1);
	printf("Total %d Boards\n", cnt);
}
