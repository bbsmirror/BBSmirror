
#include "bbs.h"
#include "global.h"


#define PUTCURS   {move(5 + c, 0);prints("=>");}
#define RMVCURS   {move(5 + c, 0);prints("  ");}


/*******************************************************************
 * �ɤ��ܼƫŧi
 *******************************************************************/
extern struct bword *topb, *curb;

struct bword *scrb;


#define ZAPRC_MAXSIZE	(512)
#define ZAPRC_MAXNUM	(ZAPRC_MAXSIZE*8)

unsigned char zapped[ZAPRC_MAXSIZE];

int     zaprc_readid;
unsigned char zaprc_readbit;


MakeZapList()
{
	char    filename[PATHLEN];
	int     fd;

	memset(zapped, 0, sizeof(zapped));

	setuserfile(filename, UFNAME_ZAPRC);
	if ((fd = open(filename, O_RDONLY)) > 0)
	{
		if (read(fd, zapped, sizeof(zapped)) == sizeof(zapped))
		{
			close(fd);
			return 0;
		}
		close(fd);
	}
	return -1;
}


UpdateZapFile()
{
	char    filename[PATHLEN];
	int     fd;

	setuserfile(filename, UFNAME_ZAPRC);
	if ((fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644)) > 0)
	{
		if (write(fd, zapped, sizeof(zapped)) == sizeof(zapped))
		{
			close(fd);
			return 0;
		}
		close(fd);
	}
	return -1;
}


IsZappedBoard(bid)
int     bid;
{
	if (bid <= 0 || bid > ZAPRC_MAXNUM)
		return 0;
	mymod(bid, ZAPRC_MAXSIZE, &zaprc_readid, &zaprc_readbit);
#ifdef DEBUG
	prints("\nbid = [%d], zaprc_readid = [%d], zaprc_readbit = [%x]",
	       bid, zaprc_readid, zaprc_readbit);
	getkey();
#endif
	if (zapped[zaprc_readid] & zaprc_readbit)
		return 1;
	return 0;
}


/*******************************************************************
 * �ϥΪ̬O�_�i�ݨ��Y�O�s�b
 *******************************************************************/
can_see_board(bhr)
BOARDHEADER *bhr;
{
#ifdef HAVE_ZAPBOARD
	if (bhr->level == ANNOUNCE_BOARD_LEVEL)	/* those boards cannot be
						   zapped */
		return 1;
/*--	if ((bhr->accessed[readid] & readbit) && HAS_FLAG(YANK_FLAG)) */
	if (IsZappedBoard(bhr->bid) && HAS_FLAG(YANK_FLAG))
		return 0;
#endif
	if (!HAS_PERM(PERM_SYSOP))
	{
		if (bhr->level == ADMIN_BOARD_LEVEL && curuser.userlevel < 100)
			return 0;
		if (bhr->level == INVISIBLE_BOARD_LEVEL)
			return 0;
/* �b�O�D�n�ͦW�椺�~�ݱo���� ���ΪO
   if (bhr->level == INVISIBLE_BOARD_LEVEL
   && !can_override(bhr->owner, curuser.userid))
   {
   return 0;
   }
 */
	}
	return 1;
}


/*******************************************************************
 * ���� BoardList ��C
 *******************************************************************/
free_board_list(blist)
struct BoardList *blist;
{
	free(blist->name);
	free(blist->owner);
	free(blist->title);
	free(blist);

	return;
}


/*******************************************************************
 * malloc �@�� board link list �Ŷ�
 *******************************************************************/
struct BoardList *
malloc_board(bhr)
BOARDHEADER *bhr;
{
	struct BoardList *new;
	static int total_board_num = 0;
	char   *p;

#ifdef USE_VOTE
	char    vpath[PATHLEN];

#endif

	new = (struct BoardList *) malloc(sizeof(struct BoardList));
	memset(new, 0, sizeof(struct BoardList));

	new->name = (char *) malloc(strlen(bhr->filename) + 1);
	strcpy(new->name, bhr->filename);
	new->owner = (char *) malloc(strlen(bhr->owner) + 1);
	strcpy(new->owner, bhr->owner);
	if ((p = strchr(new->owner, ' ')))	/* lasehu: �Y���ťզr��,
						   �h�����L�O�D */
		*p = '\0';
	new->title = (char *) malloc(strlen(bhr->title) + 1);
	strcpy(new->title, bhr->title);
	new->type = bhr->type;
	new->level = bhr->level;
	new->class = bhr->class;

#ifdef HAVE_ZAPBOARD
#if 0
	new->accessed = bhr->accessed[readid];	/* copy the byte belong to
						   current user */
#endif
	new->bid = bhr->bid;
#endif

	new->attrib = bhr->attrib;

#ifdef NEW_BRC
	new->rewind_time = bhr->rewind_time;
	new->visit_flag = 0;	/* lasehu */
#endif
	new->num = ++total_board_num;
#ifdef USE_VOTE
	{
		sprintf(vpath, "%s/%s/", BOARDVOTE, bhr->filename);
		new->vote_flag = check_vote(vpath);
	}
#endif
	return new;
}


/*******************************************************************
 * compare board name
 *******************************************************************/
board_list_cmp(bname, name)
struct BoardList *bname;
char   *name;
{
	return strcasecmp(bname->name, name);	/* lasehu: �O�W�����j�p�g */
}

board_list_ncmp(bname, name, len)
struct BoardList *bname;
char   *name;
int     len;
{
	return strncmp(bname->name, name, len);
}


/*******************************************************************
 * check board list, �p�G�S��, �N���X board link list
 *******************************************************************/
struct bword *
check_board_list()
{
	int     fd;
	struct bword *wtop = NULL;

	if (!topb)
	{
		MakeZapList();
		if ((fd = open(BOARDS, O_RDONLY)) > 0)
		{
			while (read(fd, &tmp_bh, sizeof(tmp_bh)) == sizeof(tmp_bh))
			{
				if (can_see_board(&tmp_bh))
					wtop = (struct bword *) add_wlist(wtop, &tmp_bh, malloc_board);
			}
			close(fd);
		}
		topb = scrb = curb = wtop;
	}
	return topb;
}

#ifdef HAVE_ZAPBOARD

#if 0
/*******************************************************************
 * zap current board
 *******************************************************************/
zap_cur_board()
{
	int     fd;

	if ((fd = open(BOARDS, O_RDWR)) > 0)
	{
/* �ٲ� lockf */
		while (read(fd, &tmp_bh, sizeof(tmp_bh)) == sizeof(tmp_bh))
		{
			if (!strcmp(tmp_bh.filename, curb->word->name))
			{
				if (tmp_bh.accessed[readid] & readbit)
					tmp_bh.accessed[readid] &= ~readbit;
				else
					tmp_bh.accessed[readid] |= readbit;
				curb->word->accessed = tmp_bh.accessed[readid];	/* ? */
				if (lseek(fd, -((off_t) (MAXUSERS - readid)), SEEK_CUR) != -1)
					write(fd, &(tmp_bh.accessed[readid]), 1);
				break;
			}
		}
		close(fd);
	}
	return 0;
}

#endif


zap_cur_board()
{
	if (curb->word->bid <= 0 || curb->word->bid > ZAPRC_MAXNUM)
		return;
	mymod(curb->word->bid, ZAPRC_MAXSIZE, &zaprc_readid, &zaprc_readbit);
	if (IsZappedBoard(curb->word->bid))
		zapped[zaprc_readid] &= ~zaprc_readbit;
	else
		zapped[zaprc_readid] |= zaprc_readbit;
	UpdateZapFile();
}

#endif

/*******************************************************************
 * Print Board Title
 *******************************************************************/
void
board_title()
{
	move(0, 0);
	clrtoeol();
#if 0
#if	defined( NSYSUBBS2 ) || defined( NSYSUBBS3 )
	prints("%s%s ���G�i��[33m      %-42s [m\n��ܧG�i�� : [1;33;44m%s[m",
	       BOARD_TITLE_COLOR, BBSNAME,
	       (in_board ? "[�@���]" : "[��ذ�]"), curb->word->name);
#else
	prints("[1;36;44m%s ���G�i��[33m      %-42s [m\n��ܧG�i�� : [1;33;44m%s[m",
	   BBSNAME, (in_board ? "[�@���]" : "[��ذ�]"), curb->word->name);
#endif
#endif

#if	defined( NSYSUBBS2 ) || defined( NSYSUBBS3 )
	prints("%s%s ���G�i��   [1;33m%-42s[m\n��ܧG�i�� : [1;33;44m%s[m\n",
	       BOARD_TITLE_COLOR, BBSNAME,
	       (in_board ? "[�@���]" : "[��ذ�]"), curb->word->name);
#else
	prints("[1;36;44m%s ���G�i��   [1;33m%-42s[m\n��ܧG�i�� : [1;33;44m%s[m\n",
	   BBSNAME, (in_board ? "[�@���]" : "[��ذ�]"), curb->word->name);
#endif

#ifdef HAVE_ZAPBOARD
	prints("��W�C�� (* = zapped ��) [1m(type [H]:����. [Q]:���}. [TAB]:��ذϤ���)[m\n");
#else
	prints("��W�C��                 [1m(type [H]:����. [Q]:���}. [TAB]:��ذϤ���)[m\n");
#endif
	prints("[1m    ��W            News  Lvl ���廡��                              ��D[m\n");
	prints("[36m------------------------------------------------------------------------------[m");
}

void
init_board()
{
	brc_initial(curb->word->name);	/* lasehu: brc */
	setbfile(curbmfile, curb->word->name, BM_ASSISTANT);
#ifdef NEW_BRC
	if (!curb->word->visit_flag)
		refresh_brc();
	(curb->word->visit_flag)++;
#endif
}


/*******************************************************************
 * Boards Menu �R�O
 *******************************************************************/
Boards(cls)
char    cls;			/* ������ */
{
	char    nbuf[BNAME_LEN];
	int     c, b, ch, mode = NEWDIRECT, nbuf_len = 0, i;
	struct bword *btr, *scr[SCREEN_SIZE - 5];
	char    chtype[5];

	in_board = 1;		/* lasehu ? */

	if (!check_board_list())
	{
		clear();
		outs("Ū�������ݪO !!\n");
		pressreturn();
		return M_FULL;	/* lasehu */
	}
	if (uinfo.mode >= VOTING && uinfo.mode <= ADDVOTE)
		cls = '0';
	while (1)
	{
		switch (mode)
		{
			case CAREYDOWN:
				RMVCURS;
				if (++c > b)
				{
					if (scr[b]->next)	/* ? */
						scrb = scr[b]->next;
					else
						scrb = topb;
					mode = B_PART;
					continue;
				}
				break;
			case CAREYUP:
				RMVCURS;
				if (--c < 0)
				{
					if (scrb->last == NULL)	/* topb */
						for (; scrb->next != NULL; scrb = scrb->next)
							 /* NULL STATEMENT */ ;
					else
						scrb = scrb->last;
				/* ? */
					for (i = 0; scrb->last; scrb = scrb->last)
					{
						if (cls == '0' || scrb->word->class == cls)
							if (++i == (SCREEN_SIZE - 5))
								break;
					}
					mode = B_PART;
					continue;
				}
				break;
			case NEWDIRECT:
			case B_FULL:
				clear();
				board_title();
			case B_PART:
				btr = scrb;
				for (b = 0, c = -1; btr != NULL && b < (SCREEN_SIZE - 5); btr = btr->next)
				{
					if (btr->word->class == cls || cls == '0')
					{
						if (curb == btr)
							c = b;
						scr[b++] = btr;
					}
				}
				if (!b)
				{
					for (btr = topb; btr != NULL; btr = btr->next)
						if (cls == '0' || btr->word->class == cls)
						{
							if (curb == btr)
								c = b;
							scr[b++] = btr;
							if (b == (SCREEN_SIZE - 5))
								break;
						}
					if (!b)
					{
						clear();
						outs("�S�������ݪO !!");
						pressreturn();
						return B_FULL;
					}
				}
				b--;
				curb = scrb;	/* debug */
				scrb = scr[0];	/* ? */
				if (c < 0)
				{
					if (ch == KEY_UP || ch == KEY_PGUP)
						c = b;
					else
						c = 0;
				}
				move(5, 0);
				clrtobot();
				for (i = 0; i <= b; i++)
				{
					if (scr[i]->word->type == 'B')
						strcpy(chtype, "[��]");
					else if (scr[i]->word->type == 'I')
						strcpy(chtype, "[��]");
					else if (scr[i]->word->type == 'O')
						strcpy(chtype, "[�e]");
					else
						strcpy(chtype, "    ");
					move(i + 5, 0);
					clrtoeol();
#ifdef HAVE_ZAPBOARD
/*--
					prints("  %c %-16.16s %s%c%3d %-36.36s %-12.12s",
					       (scr[i]->word->accessed & readbit) ? '*' : ' ',
*/
					prints("  %c %-16.16s %s%c%3d %-36.36s %-12.12s",
					       IsZappedBoard(scr[i]->word->bid) ? '*' : ' ',
#else
					prints("   %-16.16s %s%c %3d %-36.36s %-12.12s",
#endif
					       scr[i]->word->name,
					       chtype,
#ifdef USE_VOTE
					   (scr[i]->word->vote_flag) ? 'V' :
#endif
					       ' ',
					       scr[i]->word->level,
					       scr[i]->word->title,
					       scr[i]->word->owner);
				}
				move(b_line, 0);
#if	defined( NSYSUBBS2 ) || defined( NSYSUBBS3 )
				prints("%s(CR)��� (P)(PgUp)�W�� (N)(PgDw)(Sp)�U�� (a��z)�O�j�M (Z)ap. Yank:(I)n/(O)ut  [m",
				       BOARD_BTITLE_COLOR);
#else
				prints("[37;44m(CR)��� (P)(PgUp)�W�� (N)(PgDw)(Sp)�U�� (a��z)�O�j�M (Z)ap. Yank:(I)n/(O)ut  [m");
#endif
				break;
			default:
				break;
		}
		mode = B_NO;	/* lasehu: debug */
		move(1, 13);
		clrtoeol();
		if (nbuf_len != 0)
			prints("[7m%-17s[m", nbuf);
		else
			prints("[7m%s[m", scr[c]->word->name);
		RMVCURS;
		PUTCURS;
		if (talkrequest)
		{
			talkreply();
			pressreturn();
			mode = B_FULL;
			continue;
		}
#ifdef WRITEREPLY
		else if (writerequest)	/* lasehu */
		{
			writereply();
			mode = B_FULL;
			continue;
		}
#endif
		ch = getkey();
		switch (ch)
		{
			case KEY_PGUP:
				c = 0;
				scrb = scr[0];
			case KEY_UP:
				mode = CAREYUP;
				break;
			case KEY_PGDN:
				c = b;
				scrb = scr[b];
			case KEY_DOWN:
				mode = CAREYDOWN;
				break;
			case '\n':
			case '\r':
			case KEY_RIGHT:
				curb = scr[c];	/* ? */
#ifdef USE_VOTE
				if (uinfo.mode >= VOTING && uinfo.mode <= ADDVOTE)
					return 0;	/* ���ɦb vote admin
							   ��n�O�l */
#endif
				init_board();
			/*
			   �i�J�\Ū���
			*/
				Read();
				update_umode(BOARDS_MENU);	/* lasehu */
				mode = B_FULL;
				break;
			case 'Q':
			case KEY_LEFT:
				curb = scr[c];	/* debug *//* ? */
				return B_FULL;
			case 'P':
				c = 0;
				mode = CAREYUP;
				break;
			case ' ':
			case 'N':
				c = b;
				mode = CAREYDOWN;
				break;
			case 'H':
				more(BOARD_HELP, YEA);
				mode = B_FULL;
				break;
#ifdef HAVE_ZAPBOARD
			case 'O':
				SET_FLAG(YANK_FLAG);
				MakeBoardList();
				mode = NEWDIRECT;
				break;
			case 'I':
				UNSET_FLAG(YANK_FLAG);
				MakeBoardList();
				mode = NEWDIRECT;
				break;
			case 'Z':
				curb = scr[c];	/* ? */
				zap_cur_board();
/*
	    SET_FLAG(YANK_FLAG);
*/
				move(c + 5, 2);
/*--
				if (scr[c]->word->accessed & readbit)
*/
				if (IsZappedBoard(scr[c]->word->bid))
					prints("*");
				else
					prints(" ");
				break;
#endif
			case TAB:
				in_board = (in_board) ? NA : YEA;
				board_title();
				break;
			default:
				RMVCURS;
/* lasehu ? */
				nbuf[nbuf_len] = ch;
				nbuf[nbuf_len + 1] = '\0';

				if (!invalid_bname(nbuf + nbuf_len))
				{
					nbuf_len++;
					for (i = 0; i <= b && scr[i]; i++)
						if (!board_list_ncmp(scr[i]->word, nbuf, nbuf_len)
						    && (scr[i]->word->class == cls || cls == '0'))
						{
							break;
						}
					if (i <= b && scr[i] != NULL)
					{
						c = i;
						curb = scr[c];
					}
					else
					{
						for (curb = topb; curb; curb = curb->next)
							if (!board_list_ncmp(curb->word, nbuf, nbuf_len)
							    && (curb->word->class == cls || cls == '0'))
							{
								break;
							}
						if (curb != NULL)
						{
							mode = B_PART;
							scrb = curb;
						}
						else
						{
							nbuf[--nbuf_len] = '\0';
							curb = scr[c];
						}
					}
				}
				else
				{
/*--					bell(); */
					nbuf_len = 0;
				}
				continue;
		}
		nbuf_len = 0;
	}
	return B_FULL;
}


struct word *bwtop = NULL;


MakeBoardList()
{
	DelBoardList();
	check_board_list();
}

DelBoardList()
{
	bwtop = free_wlist(bwtop, NULL);	/* ? */
	topb = (struct bword *) free_wlist(topb, free_board_list);
}



CompleteBoardName(data)
char   *data;
{
	struct bword *tempb;

	if (!check_board_list())
		return -1;
	move(1, 0);
	clrtobot();
	move(2, 0);
	outs("�п�J�z�n�諸�^��O�W (�� [Space] �ť���i�C�X�L�o���M��)\n");
	move(1, 0);
	outs("��ܬݪO: ");
	if (!bwtop)		/* ? */
	{
		for (tempb = topb; tempb; tempb = tempb->next)
			bwtop = add_wlist(bwtop, tempb->word->name, NULL);
	}
	namecomplete(bwtop, NULL, data);
	if (data[0] == '\0')
		return -1;

	return 0;
}


/*******************************************************************
 * ��J�� Select
 *******************************************************************/
choose_board()
{
	char    bname[STRLEN];
	struct bword *tempb;

	if (!in_board && uinfo.mode != SELECT)
		return R_NO;

	if (CompleteBoardName(bname) == -1)
		return R_FULL;

	if ((tempb = (struct bword *) cmp_wlist(topb, bname, board_list_cmp)))
	{
		curb = tempb;
		init_board();
		return NEWBOARD;/* lasehu */
	}
	return R_FULL;
}


/*******************************************************************
 * Main Menu Select
 *******************************************************************/
Select()
{
	if (choose_board() == NEWBOARD)
	{
		set_menu_autokey('r');	/* lasehu ? */
		return AUTOKEY;
	}

	return M_FULL;
}
