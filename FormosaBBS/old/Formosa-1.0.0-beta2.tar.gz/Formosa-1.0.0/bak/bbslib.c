
/*******************************************************************
 * ����D�{���P���ݤu��{���|�Ψ��ƩI�s.
 *******************************************************************/

#include "bbs.h"
#include "boardrc.h"
#include <varargs.h>


void    bbslog();


#ifdef SYSV
int
flock(fd, op)
int     fd, op;
{
	switch (op)
	{
		case LOCK_EX:
			return lockf(fd, F_LOCK, 0);
		case LOCK_UN:
			return lockf(fd, F_ULOCK, 0);
		default:
			return -1;
	}
}

#endif

#if 0
#ifdef SYSV
#include <sys/ipc.h>
#include <sys/sem.h>

#define SEM_KEY	9237

int     semid;

int
get_semaphore()
{
	if ((semid = semget(SEM_KEY, 1, 600)) == -1)
	{
		if ((semid = semget(SEM_KEY, 1, 600 | IPC_CREAT)) == -1)
			return -1;

		semctl(semid, 0, SETVAL, 1);
	}

	return 0;
}

int
flock(fd, op)
int     fd, op;
{
	struct sembuf sops;

	sops.sem_num = 0;
	sops.sem_flg = SEM_UNDO;

	switch (op)
	{
		case LOCK_EX:
			sops.sem_op = -1;
			break;
		case LOCK_UN:
			sops.sem_op = 1;
			break;
		default:
			return -1;
	}
	semop(semid, &sops, 1);

	return 0;
}

#endif
#endif


/*******************************************************************
 * �����ɮ� - �|�N�ت����|�R�
 *******************************************************************/
mycp(from, to)
char   *from, *to;
{
	char    cpbuf[8192];	/* copy buffer size: 8192 */
	int     fdr, fdw, cc;

/*---
    struct stat st;
*/
/* lasehu
   myunlink(to);
   unlink(to);
 */
#if 0				/* lmj */
	if (stat(from, &st) == -1 || S_ISDIR(st.st_mode))	/* lasehu */
		return -1;
#endif
	if ((fdr = open(from, O_RDONLY)) > 0)
	{
		if ((fdw = open(to, O_WRONLY | O_CREAT | O_TRUNC, 0644)) > 0)
		{
			while ((cc = read(fdr, cpbuf, sizeof(cpbuf))) > 0)
				write(fdw, cpbuf, cc);
			close(fdw);
			close(fdr);
			return 0;
		}
		close(fdr);
	}
	return -1;
}

/*******************************************************************
 * �R���ɮשΥؿ��
 *******************************************************************/
myunlink(name)
char    name[];
{
	DIR    *dirp;

#ifdef	NO_DIRENT
	struct direct *dirlist;

#else
	struct dirent *dirlist;

#endif
	char    path[MAXNAMLEN], *s;
	struct stat st;

	if (!name || name[0] == '\0' || stat(name, &st) == -1)
		return -1;
	if (!S_ISDIR(st.st_mode))
	{
		unlink(name);
		return 0;
	}
	if ((dirp = opendir(name)) == NULL)
		return -1;
	sprintf(path, "%s/", name);
	s = path + strlen(path);;
	readdir(dirp);
	readdir(dirp);
	while ((dirlist = readdir(dirp)) != NULL)
	{
		if (dirlist->d_name[0])
		{
			strcpy(s, dirlist->d_name);
			if (stat(path, &st) == 0)
			{
				if (S_ISDIR(st.st_mode))
					myunlink(path);
				else
					unlink(path);
			}
		}
	}
	closedir(dirp);
	*(--s) = '\0';
	if (rmdir(path) == -1)
		return -1;
	return 0;
}

/*******************************************************************
 * ����ɮ׸��| (�i���ɮרt�ηh��)
 *******************************************************************/
myrename(from, to)
char    from[], to[];
{
	struct stat st;

	if (rename(from, to) == -1)	/* �p�G rename() ���� */
	{
#if 0				/* lmj */
	/* �p�G from ���s�b�� from �O�ؿ� *//* ? */
		if (stat(from, &st) == -1 || S_ISDIR(st.st_mode))
			return -1;
#endif
		if (stat(to, &st) == 0)
			return -1;
	/* ���ܤ��P filesystem, �A�� mycp() */
		if (mycp(from, to) == -1)
			return -1;
		unlink(from);
	}
	return 0;
}

void
sethomefile(buf, userid, filename)	/* INAPTITUDE ? */
char   *buf, *userid, *filename;
{
#ifdef NEW_HOMEPATH
	unsigned char c;

	c = userid[0];
	if (c >= 'A' && c <= 'Z')
		c |= 32;
	else if (!(c >= 'a' && c <= 'z'))
		c = '0';
	if (filename == NULL)
		sprintf(buf, "home/%c/%s", c, userid);
	else
		sprintf(buf, "home/%c/%s/%s", c, userid, filename);
#else
	sprintf(buf, "%s/%s", filename, userid);
#endif
}

void
gethomefile(buf, userid, filename)	/* INAPTITUDE ? */
char   *buf, *userid, *filename;
{
	sprintf(buf, "%s/%s", filename, userid);
}


#if 0
void
get_only_name(path, fn_stamp)
char   *path;
char   *fn_stamp;
{
	char   *p;
	int     fd;
	char    filename[STRLEN];

	strcpy(filename, path);
	p = filename + strlen(filename);
	do
	{
		sprintf(p, "/M.%d.A", time(0));
	}
	while ((fd = open(filename, O_WRONLY | O_CREAT | O_EXCL, 0644)) < 0);
	strcpy(fn_stamp, p + 1);
	close(fd);
}

#endif

/*******************************************************************
 * �b���w���ؿ��U���o�ߤ@�� M.xxxxxxxx.? �ɦW
 *******************************************************************/
get_only_name(dir, fname)
char    dir[], fname[];
{
	char   *t, tmpbuf[256];
	int     fd;

	sprintf(fname, "M.%d.A", time(0));
	t = strrchr(fname, 'A');
	sprintf(tmpbuf, "%-s/%-s", dir, fname);
	while ((fd = open(tmpbuf, O_RDONLY)) != -1)
	{
		close(fd);
		if (*t == 'Z')
		{
			*(++t) = 'A';
			*(t + 1) = '\0';
		}
		else
			(*t)++;
		sprintf(tmpbuf, "%-s/%-s", dir, fname);
	}
	if ((fd = open(tmpbuf, O_WRONLY | O_CREAT, 0644)) != -1)
		close(fd);
	return;
}



/*
 * ���o�ϥΪ̸��
 */
unsigned int
get_passwd(urcp, userid)
USEREC *urcp;
char   *userid;
{
	int     fd;
	char    fn_passwd[STRLEN];
	USEREC  urcbuf, *u = (urcp) ? urcp : &urcbuf;

/* �Y urcbuf �� NULL, �h�u�d�� userid �O�_�s�b */

	if (userid == NULL || userid[0] == '\0')
		return 0;
#ifdef HAVE_BUG
	if (strstr(userid, "..") || userid[0] == '/')
		return 0;
#endif
	sethomefile(fn_passwd, userid, UFNAME_PASSWDS);
	if ((fd = open(fn_passwd, O_RDONLY)) > 0)
	{
#ifdef MYDEBUG
		{
			struct stat st;

			if (fstat(fd, &st) == 0 && st.st_size != sizeof(USEREC))
				bbslog("ERROR", "user[%s] passwd file size not match", userid);
		}
#endif
		if (read(fd, u, sizeof(USEREC)) == sizeof(USEREC))
#ifdef REALMAXUSERS
			if (u->uid <= REALMAXUSERS)
#endif
#ifdef HAVE_BUG
				if (u->uid >= 1)
#endif
				{
					close(fd);
					return u->uid;
				}
		close(fd);
	}
	return 0;
}

int
append_news(board, fname, option)
char   *board, *fname, option;
{
	FILE   *fp;
	char    nbuf[PATHLEN], bbuf[PATHLEN];

	sprintf(nbuf, "news/output/%-s", board);
	if ((fp = fopen(nbuf, "a+")) == NULL)
		return -1;
	flock(fileno(fp), LOCK_EX);
	if (option == 'D')
		fprintf(fp, "-%-s\n", fname);
	else
		fprintf(fp, "%-s\n", fname);
	flock(fileno(fp), LOCK_UN);
	fclose(fp);
	if (option == 'D')
	{
		sprintf(nbuf, "news/cancel/%-s.%-s", board, fname);
		setbfile(bbuf, board, fname);
		myrename(bbuf, nbuf);
	}
	return 0;
}

setbfile(buf, bname, filename)
char   *buf, *bname, *filename;
{
	if (filename == NULL)
		sprintf(buf, "%s/%s", BBSPATH_BOARDS, bname);
	else
		sprintf(buf, "%s/%s/%s", BBSPATH_BOARDS, bname, filename);
}

setmailfile(buf, userid, filename)
char   *buf, *userid, *filename;
{
#ifdef NEW_HOMEPATH
	unsigned char c;

	c = userid[0];
	if (c >= 'A' && c <= 'Z')
		c |= 32;
	else if (!(c >= 'a' && c <= 'z'))
		c = '0';
	if (filename == NULL)
		sprintf(buf, "%s/%c/%-s", UFNAME_MAIL, c, userid);
	else
		sprintf(buf, "%s/%c/%-s/%s", UFNAME_MAIL, c, userid, filename);
#else
	sprintf(buf, "%s/%-s/%s", UFNAME_MAIL, userid, filename);
#endif
}

#ifdef HAVE_BUG
/*
 * ���o�ϥΪ̯��޸����
 */
unsigned int
get_uidx(uidx, userid)
struct useridx *uidx;
char   *userid;
{
	int     fd;
	unsigned int cnt;
	struct useridx uidxbuf, *u = (uidx) ? uidx : &uidxbuf;

/* �Y uidx �� NULL, �h�u�d�� userid �O�_�s�b */

	if (userid == NULL || userid[0] == '\0')
		return 0;
	if ((fd = open(USERIDX, O_RDONLY)) > 0)
	{
		for (cnt = 1; read(fd, u, sizeof(uidxbuf)) == sizeof(uidxbuf); cnt++)
		{
			if (!strcmp(u->userid, userid))
			{
				close(fd);
				return cnt;
			}
		}
		close(fd);
	}
	return 0;
}

#endif


/*
 * ���ϥΪ̪����
 *
 */
unsigned int
update_user(ubuf)
USEREC *ubuf;
{
	int     fd;
	char    fn_passwd[STRLEN];
	USEREC  urcbuf;

	if (ubuf == NULL || ubuf->userid[0] == '\0')
		return 0;
#ifdef HAVE_BUG
	if (strstr(ubuf->userid, "..") || ubuf->userid[0] == '/')
		return 0;
#endif
#ifdef REALMAXUSERS
	if (ubuf->uid > REALMAXUSERS)
		return 0;
#endif
#ifdef HAVE_BUG
	if (ubuf->uid < 1)
		return 0;
#endif
	sethomefile(fn_passwd, ubuf->userid, UFNAME_PASSWDS);
	if ((fd = open(fn_passwd, O_RDWR)) > 0)
	{
		flock(fd, LOCK_EX);	/* �ѩ�@�ΨϥΪ̸��, ���T�O�g�J���T */
#ifdef HAVE_BUG
		if (read(fd, &urcbuf, sizeof(USEREC)) == sizeof(USEREC)
		    && urcbuf.uid == ubuf->uid
		    && !strcmp(urcbuf.userid, ubuf->userid)
		    && lseek(fd, 0, SEEK_SET) != -1)
#endif
			if (write(fd, ubuf, sizeof(USEREC)) == sizeof(USEREC))
			{
				flock(fd, LOCK_UN);
				close(fd);
				return ubuf->uid;
			}
		flock(fd, LOCK_UN);
		close(fd);
	}
	return 0;
}

dashf(fname)
char   *fname;
{
	struct stat st;

	return (stat(fname, &st) == 0 && S_ISREG(st.st_mode));
}

dashd(fname)
char   *fname;
{
	struct stat st;

	return (!stat(fname, &st));
}

/*******************************************************************
 * �����Ҧ��w���}���]��
  *******************************************************************/
close_all_ftable()
{
	int     i, ndescriptors = getdtablesize();

	for (i = 3; i < ndescriptors; i++);
	(void) close(i);
	return;
}

void
bbslog(mode, va_alist)
char   *mode;

va_dcl
{
	va_list args;
	time_t  now;
	int     fd;
	char    msgbuf[STRLEN], buf[128], *fmt;
	char    timestr[22];

	va_start(args);
	fmt = va_arg(args, char *);
	vsprintf(msgbuf, fmt, args);
	va_end(args);

	time(&now);
	strftime(timestr, sizeof(timestr), "%x %X", localtime(&now));

	sprintf(buf, "%s %.10s: %s\n", timestr, mode, msgbuf);
	if ((fd = open(PATH_BBSLOG, O_APPEND | O_CREAT | O_WRONLY, 0600)) > 0)
	{
		write(fd, buf, strlen(buf));
		close(fd);
	}
}


int
rewind_board(bname)
char   *bname;
{
	int     fd;
	BOARDHEADER sbh;

	if ((fd = open(BOARDS, O_RDWR)) > 0)
	{
		flock(fd, LOCK_EX);
		while (read(fd, &sbh, sizeof(sbh)) == sizeof(sbh))
		{
			if (strcmp(sbh.filename, bname))
				continue;
			sbh.rewind_time = time(0);
			if (lseek(fd, -((off_t) sizeof(sbh)), SEEK_CUR) != -1)
			{
				if (write(fd, &sbh, sizeof(sbh)) == sizeof(sbh))
				{
#ifdef DEBUG
					printf("\nupdate board[%s] rtime to [%s]\n", bname, ctime(&sbh.rewind_time));
#endif
					flock(fd, LOCK_UN);
					close(fd);
					return 0;
				}
			}
			break;
		}
		flock(fd, LOCK_UN);
		close(fd);
	}
	return -1;
}


int
get_only_artno(dotdir)
char   *dotdir;
{
	int     fd;
	int     number = 1;

	if ((fd = open(dotdir, O_RDONLY)) > 0)
	{
		FILEHEADER lastf;
		struct stat st;

		fstat(fd, &st);
		if (st.st_size % FH_SIZE == 0 && st.st_size > FH_SIZE)
			lseek(fd, st.st_size - FH_SIZE, SEEK_SET);
		if (read(fd, &lastf, sizeof(lastf)) == sizeof(lastf))
		{
			if (lastf.artno >= BRC_REALMAXNUM)
				number = 1;	/* reset the artno. */
			else if (lastf.artno > 0)
				number = lastf.artno + 1;
		}
		close(fd);
	}
	return number;
}

#if 0
void
mymod(id, maxu, pp, qq)		/* pp: readbit, qq: readid */
unsigned int id;
int     maxu, *qq;
char   *pp;
{
	*qq = id / maxu;
	*pp = 0x1;
	*pp = *pp << *qq;
	*qq = (id - 1) % maxu;
}

#endif

void
mymod(id, maxu, pp, qq)		/* pp: readid, qq: readbit */
unsigned int id;
int     maxu, *pp;
unsigned char *qq;
{
	*pp = (id - 1) % 8;
	*qq = 0x1;
	*qq = *qq << *pp;
	*pp = ((id - 1) / 8) % maxu;
}

/*
 * ���ϥΪ̪�����`�� PASSFILE
 */
unsigned int
update_user_passfile(ubuf)
USEREC *ubuf;
{
	int     fd;

	if (ubuf == NULL || ubuf->userid[0] == '\0')
		return -1;

#ifdef HAVE_BUG
	if (ubuf->uid < 1)
		return -1;
#endif
#ifdef REALMAXUSERS
	if (ubuf->uid > REALMAXUSERS)
		return -1;
#endif
	if ((fd = open(PASSFILE, O_WRONLY | O_CREAT, 0600)) > 0)
	{
#if 0
		flock(fd, LOCK_EX);
#endif
		if (lseek(fd, (off_t) ((ubuf->uid - 1) * sizeof(USEREC)), SEEK_SET) != -1)
		{
			if (write(fd, ubuf, sizeof(USEREC)) == sizeof(USEREC))
			{
				close(fd);
				return 0;
			}
		}
		close(fd);
	}
	return -1;
}
