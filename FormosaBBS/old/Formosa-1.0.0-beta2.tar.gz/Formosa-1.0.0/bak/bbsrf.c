/*
   Pirate Bulletin Board System
   Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
   Eagles Bulletin Board System
   Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
   Guy Vega, gtvega@seabass.st.usm.edu
   Dominic Tynes, dbtynes@seabass.st.usm.edu

   ���إ����ߤ��s�j�ǹq�l�G�i��t�� NSYSU Bulletin Board System in R.O.C.
   Copyright (C) 1994, 1996
   cray@cc.nsysu.edu.tw    ����
   carey@cc.nsysu.edu.tw    �P����
   lmj@cc.nsysu.edu.tw    �����
   alex@cc.nsysu.edu.tw    ���~��
   annhy@cc.nsysu.edu.tw    �w����
   chang@cc.nsysu.edu.tw    �i²�ݤ
   lasehu@cc.nsysu.edu.tw    ���߼w

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


#include "bbs.h"

/* del by lasehu
   #define LOAD_LIMIT
 */

#ifdef SOLARIS			/* lasehu */
#define UTMPX
#endif

#ifdef UTMPX
#include <utmpx.h>
#else
#include <utmp.h>
#endif

#ifdef SYSV
#include <sys/utsname.h>
#endif

#include <pwd.h>

/* --- For rstat(), getting load average --- */
#if !defined(LINUX) && !defined(BSD44)	/* ? */
#include <rpcsvc/rstat.h>
#endif

#ifdef BSD44			/* ? */
#define UTMP_PATH "/var/run/utmp"	/* ? */
#else
#define UTMP_PATH "/etc/utmp"	/* ? */
#endif

char   *ttyname();		/* ? */

int     max_load = 10;		/* ? */

#ifdef UTMPX

struct utmpx *
invis()
{
    static struct utmpx data;
    FILE   *fp;
    char   *name, *tp;
    struct passwd *pp;

    tp = ttyname(0);
    if (!tp)
	return NULL;
    tp = strchr(tp, '/') + 1;
    tp = strchr(tp, '/') + 1;
    pp = getpwuid(getuid());
    if (!pp)
    {
	fprintf(stderr, "You Don't exist!\n");
	exit(0);
    }
    name = pp->pw_name;

#ifdef INVISIBLE
    if ((fp = fopen(UTMPX_FILE, "r+")) == NULL)
#else
    if ((fp = fopen(UTMPX_FILE, "r")) == NULL)
#endif
	exit(0);
    while (read(fileno(fp), &data, sizeof(struct utmpx)) > 0)
    {
	if (data.ut_type != DEAD_PROCESS && !strcmp(tp, data.ut_line))
	{
	    struct utmpx nildata;

	    bcopy(&data, &nildata, sizeof(nildata));
#ifdef INVISIBLE
	    memset(nildata.ut_name, 0, 8);
	    fseek(fp, (long) (ftell(fp) - sizeof(struct utmpx)), 0);
	    if (write(fileno(fp), &nildata, sizeof(struct utmpx)) != sizeof(struct utmpx))
		 /* NIL IF STATEMENT */ ;

#endif
	    fclose(fp);
	    return &data;
	}
    }
    fclose(fp);
    return NULL;
}

#else				/* UTMPX */

struct utmp *
invis()
{
    static struct utmp data;
    FILE   *fp;
    char   *name, *tp;
    struct passwd *pp;

    tp = ttyname(0);
    if (!tp)
	return NULL;
    tp = strrchr(tp, '/') + 1;
    pp = getpwuid(getuid());
    if (!pp)
    {
	fprintf(stderr, "You Don't exist!\n");
	exit(0);
    }
    name = pp->pw_name;

#ifdef INVISIBLE
    if ((fp = fopen("/etc/utmp", "r+")) == NULL)
#else
    if ((fp = fopen("/etc/utmp", "r")) == NULL)
#endif
	exit(0);
    while (read(fileno(fp), &data, sizeof(struct utmp)) > 0)
    {
	if (!strcmp(tp, data.ut_line))
	{
	    struct utmp nildata;

	    bcopy(&data, &nildata, sizeof(nildata));
#ifdef INVISIBLE
	    memset(nildata.ut_name, 0, 8);
	    fseek(fp, (long) (ftell(fp) - sizeof(struct utmp)), 0);
	    if (write(fileno(fp), &nildata, sizeof(struct utmp)) != sizeof(struct utmp))
		 /* NIL IF STATEMENT */ ;

#endif
	    fclose(fp);
	    return &data;
	}
    }
    fclose(fp);
    return NULL;
}

#endif				/* UTMPX */

#include <nlist.h>		/* lasehu */

/* added : lasehu */
void
get_load(load)
double  load[];
{
#if defined(LINUX)
    FILE   *fp;

    fp = fopen("/proc/loadavg", "r");
    if (!fp)
	load[0] = load[1] = load[2] = 0;
    else
    {
	float   av[3];

	fscanf(fp, "%g %g %g", av, av + 1, av + 2);
	fclose(fp);
	load[0] = av[0];
	load[1] = av[1];
	load[2] = av[2];
    }
#elif defined(BSD44)
    getloadavg(load, 3);
#else
#define VMUNIX  "/vmunix"
#define KMEM    "/dev/kmem"

    static struct nlist nlst[] =
    {
	{"_avenrun"},
	{0}
    };

    long    avenrun[3] =
    {0, 0, 0};

    register int i;
    int     kmem;

    if ((kmem = open(KMEM, O_RDONLY)) != -1)
    {
	(void) nlist(VMUNIX, nlst);
	if (nlst[0].n_type != 0)
	{

/* if (lseek(kmem, (long) nlst[0].n_value, L_SET) != -1) */
	    if (lseek(kmem, (off_t) nlst[0].n_value, L_SET) != -1)
	    {			/* lasehu */
		if (read(kmem, (char *) avenrun, sizeof(avenrun)) != -1)
		{
		    close(kmem);
#define loaddouble(la) ((double)(la) / (1 << 8))
		    for (i = 0; i < 3; i++)
			load[i] = loaddouble(avenrun[i]);
		}
	    }
	}
    }
#endif
#ifdef 0
    struct statstime rs;

    rstat("localhost", &rs);
    load[0] = ((double) (rs.avenrun[0]) / (double) (1 << 8));
    load[1] = rs.avenrun[1] / (double) (1 << 8);
    load[2] = rs.avenrun[2] / (double) (1 << 8);
#endif
}


void
set_max_load(prog_name)		/* ? */
char   *prog_name;
{
    char   *p;

    p = strrchr(prog_name, '.');

    if (p && *(p + 1) != '\0')
	max_load = atoi(p + 1);
}


char   *env[] =
{
    "TERM=xxxxxxxxxxxxxxxxxxxxxxxxxxx",
NULL};

int
main(argc, argv)
int     argc;
char   *argv[];
{

    int     uid;

    set_max_load(argv[0]);

    if ((uid = getuid()) == BBS_UID)
    {

#ifdef UTMPX
	struct utmpx *whee;

#else
	struct utmp *whee;

#endif

/* load control for BBS */
#ifdef LOAD_LIMIT
	{
	    double  cpu_load[3];
	    int     load;

	    get_load(cpu_load);
	    load = cpu_load[0];
	    printf("BBS �̪� (1,10,15) �����������t�����O�� %.2f, %.2f, %.2f (�ثe�W�� = %d)\n\n",
		   cpu_load[0], cpu_load[1], cpu_load[2], max_load);

	    if (load < 0 || load > max_load)
	    {
		printf("�ܩ�p,�ثe�t�έt���L��, �еy�ԦA��\n");
		sleep(3);
		exit(-1);
	    }
	}
#endif
	whee = invis();

	if (chdir(HOMEBBS) == -1)
	{
	    printf("Cannot chdir() to BBSHOME directory, exit!\n");
	    exit(-1);
	}
#ifdef CHROOT_BBS
	if (chroot(HOMEBBS) == -1)
	{
	    printf("Cannot chroot(), exit!\n");
	    exit(-1);
	}
#endif
	setgid(BBS_GID);
	setuid(uid);
#ifndef      HP_UX
	seteuid(BBS_UID);
#endif
	if (whee)
	{
	    char   *tty, ttybuf[16], hid[17];

	    tty = ttyname(0);
	    strcpy(ttybuf, (tty == NULL) ? "/dev/ttyp0" : tty);

	    if (whee->ut_host[0])
		strncpy(hid, whee->ut_host, 16);
	    else
#ifdef SYSV
	    {
		struct utsname name;

		if (uname(&name) >= 0)
		    strcpy(hid, name.nodename);
		else
		    strcpy(hid, "localhost");
	    }
#else
		gethostname(hid, 16);
#endif

	    hid[16] = '\0';

	    execl("bin/bbs", "bbs", "h", hid, ttybuf, NULL);
	}
	else
	{
/*
   execle("/bin/bbs", "bbs", "h", "unknown", "notty", NULL);
 */
	    execl("bin/bbs", "bbs", "h", "unknown", "notty", NULL);
	}

	printf("execl failed\n");
	exit(-1);
    }
/*
   setuid(uid);
 */
    printf("UID DOES NOT MATCH\n");
    exit(-1);
}
