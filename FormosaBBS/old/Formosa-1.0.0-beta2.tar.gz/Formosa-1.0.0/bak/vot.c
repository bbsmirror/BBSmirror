
#include "bbs.h"
#include "global.h"


#ifdef USE_VOTE

#define VOTEHELP1        "vote/VoteHelp1"
#define VOTEHELP2        "vote/VoteHelp2"
#define VOTEHELP3        "vote/VoteHelp3"


#define LIST1 		0	/* t */
#define LIST2 		1	/* e */
#define LIST3 		2	/* i */
#define LIST4 		3	/* m */
#define LIST5 		4	/* d */
#define LIST6 		5	/* n */
#define LIST7 		6	/* p */
#define LIST9 		7	/* l */
#define LIST8 		8	/* s */
#define CONTAINS 	8
#define VOTELEN 	41
#define WRITED 		"[Written]"
#define EMPTY 		"[None]"
#define MAXITEM 	18
#define VOTEMEN 	"VoteMen"
#define VOTENEW 	"VoteNew"
#define NOVOTE	 	"\n��p, �ثe�|�L�|�����벼!!"

extern int votetitle(), voteip(), votemax(), voteitem(), votedoc(), votelogin(),
        votestart(), voteend(), votesave();

struct VoteFileStruct
{				/* .DIR (First read an integer for total) */
	int     order;		/* order */
	char    dir[12];	/* Direction */
	char    contain[41];	/* Vote name */
	char    totalitem;	/* Total Item */
	char    max;		/* Max Number */
	long    startdate;
	long    enddate;
	char    hostlimit[20];	/* Host limit (0 or [None] shows none limit */
	int     levellimit;	/* Level Limit */
};

struct VoteLink
{
	struct VoteFileStruct contain;
	struct VoteLink *last;
	struct VoteLink *next;
}

       *votelink, *votetop, *scrtop;

struct votecomm
{
	int     hkey;
	int     prow;
	int     row;
	int     nrow;
	char   *item;
	char    contain[41];
	int     (*func) ();
};

char   *listcon[CONTAINS] =
{				/* �|��벼����� */
	"[None]",
	"[None]",
	"[None]",
	"1",
	"[None]",
	"[None]",
	"[None]",
	"0"
};

struct voteitemstruct
{
	char    item[31];
};

struct voteitemstruct voteitems[MAXITEM + 1] =
{
	EMPTY, EMPTY, EMPTY, EMPTY,
	EMPTY, EMPTY, EMPTY, EMPTY,
	EMPTY, EMPTY, EMPTY, EMPTY,
	EMPTY, EMPTY, EMPTY, EMPTY,
	EMPTY, EMPTY, EMPTY
};

struct votecomm holdlist[] =
{
	't', 11, 4, 5, "[[1;33mt[m] �벼���D: ", "", votetitle,
	'c', 4, 5, 6, "[[1;33mc[m] �s��벼����: ", "", votedoc,
	'i', 5, 6, 7, "[[1;33mi[m] �]�w�벼����: ", "", voteitem,
	'm', 6, 7, 8, "[[1;33mm[m] �]�w�̤j�벼��: ", "", votemax,
	'd', 7, 8, 9, "[[1;33md[m] �_�l���: ", "", votestart,
	'n', 8, 9, 10, "[[1;33mn[m] �פ���: ", "", voteend,
	'p', 9, 10, 11, "[[1;33mp[m] �]�wIP����: ", "", voteip,
	'l', 10, 11, 12, "[[1;33ml[m] �]�w���ŭ���: ", "", votelogin,
	's', 11, 12, 4, "[[1;36ms[m] �x�s�벼. ", "", votesave,
	255, 10, 10, 10, NULL, "", NULL
};

struct votecomm *votelist;
int     redraw = 0;
int     order, curpos;
long    startdate, enddate;
int     voteitemnum, totalvote;
char    choice;
char    path[40], dirtname[IDLEN];
char    VSrchUser[IDLEN + 2];
char    filename[PATHLEN];	/* general filename buffer */


int
check_mul()
{
	if (multi > 1)
	{
		clear();
		printxy(2, 0, "�z�ثe���h���W�u, �бz�H�̥����@�ӤW�u�Ӷi�ӧ벼.");
		getkey();
		return 1;
	}
	return 0;
}


int
showvotelist(kind)
int     kind;
{
	int     l = 0;

	clear();
#if	defined( NSYSUBBS2 ) || defined( NSYSUBBS3 )
	prints("%sBBS �벼��%-40s    �ݪO : %-17s[m",
	       MENU_TITLE_COLOR, "",
	((topb) ? ((struct BoardList *) (curb->word))->name : DEFAULTBOARD));
#else
	prints("[1;36;44mBBS �벼��%-40s    �ݪO : %-17s[m",
	       "", ((topb) ? ((struct BoardList *) (curb->word))->name : DEFAULTBOARD));
#endif
	switch (kind)
	{
		case 1:
#if	defined( NSYSUBBS2 ) || defined( NSYSUBBS3 )
			msg("%s (��)(��)����� (��)(Enter)��� (��)(e)�^��W�h (���G�r) ���� (Ctrl-L)��ø�ù� [m",
			    MENU_BTITLE_COLOR);
#else
			msg("[37;44m (��)(��)����� (��)(Enter)��� (��)(e)�^��W�h (���G�r) ���� (Ctrl-L)��ø�ù� [m");
#endif
			while (votelist[l].hkey != 255)
			{
				sprintf(genbuf, "%-32s%-40s", votelist[l].item, votelist[l].contain);
				printxy(votelist[l].row, 8, genbuf);
				l++;
			}
			break;
		case 2:
#if	defined( NSYSUBBS2 ) || defined( NSYSUBBS3 )
			msg("%s (��)(��)����� (��)(Enter)��� (��)(e)�^��W�h (D) �R������ (Ctrl-L)��ø�ù� [m",
			    MENU_BTITLE_COLOR);
#else
			msg("[37;44m (��)(��)����� (��)(Enter)��� (��)(e)�^��W�h (D) �R������ (Ctrl-L)��ø�ù� [m");
#endif
			for (l = 0; l <= voteitemnum; l++)
			{
				sprintf(genbuf, "����([1;36m%2d[m): %s", l + 1, voteitems[l].item);
				printxy(l + 3, 9, genbuf);
			}
			break;
	}
}


int
v_help1()
{
	more(VOTEHELP1, YEA);
	return M_FULL;
}


int
v_help2()
{
	more(VOTEHELP2, YEA);
	return M_FULL;
}


int
v_help3()
{
	more(VOTEHELP3, YEA);
}


int
inputitem(pos)
int    *pos;
{
	if (*pos != 21)
	{
		if (uinfo.mode != EDITVOTE || strcmp(voteitems[*pos - 3].item, EMPTY))
		{
			if (getdata(1, 0, "�п�J���D(30 characters): ", genbuf, 31, DOECHO, NULL))
			{
				if (!strcmp(voteitems[*pos - 3].item, EMPTY))
					voteitemnum++;
				strncpy(voteitems[*pos - 3].item, genbuf, 30);
			}
			move(1, 0);
			clrtoeol();
		}
	}
	redraw = 0;		/* Redraw */
}


IsVoted(filename)
char   *filename;
{
	int     fd;

	if ((fd = open(filename, O_RDONLY)) > 0)
	{
		while (read(fd, VSrchUser, IDLEN) == IDLEN)
		{
			if (!strcmp(VSrchUser, curuser.userid))
			{
				close(fd);
				return 1;
			}
		}
		close(fd);
		return 0;
	}
	return 1;
}


IncreaseBallot(filename)
char   *filename;
{
	int     fd;
	int     BallotCounts = 0;
	struct stat st;
	int     newfile = 0;

	if (stat(filename, &st) == 0)
	{
		if (st.st_size == 0)
			newfile = 1;
	}
	if ((fd = open(filename, O_RDWR)) > 0)
	{
		flock(fd, LOCK_EX);
		if (!newfile)
		{
			if (read(fd, &BallotCounts, sizeof(BallotCounts)) == sizeof(BallotCounts))
			{
				if (lseek(fd, 0, SEEK_SET) != -1)
				{
					BallotCounts++;
					if (write(fd, &BallotCounts, sizeof(BallotCounts)) == sizeof(BallotCounts))
					{
						flock(fd, LOCK_UN);
						close(fd);
						return 0;
					}
				}
			}
		}
		else
		{
			if (lseek(fd, 0, SEEK_SET) != -1)
			{
				BallotCounts++;
				if (write(fd, &BallotCounts, sizeof(BallotCounts)) == sizeof(BallotCounts))
				{
					flock(fd, LOCK_UN);
					close(fd);
					return 0;
				}
			}
		}
		flock(fd, LOCK_UN);
		close(fd);
	}
	return -1;
}


HasSeeVote(filename)
char   *filename;
{
	int     fd;

	if ((fd = open(filename, O_APPEND | O_CREAT | O_WRONLY, 0600)) > 0)
	{			/* Sign to show you have read */
		if (write(fd, curuser.userid, IDLEN) == IDLEN)
		{
			close(fd);
			MakeBoardList();
			return 0;
		}
		close(fd);
	}
	return -1;
}

CastBallot(filename)
char   *filename;
{
	int     fd;

	if ((fd = open(filename, O_APPEND | O_CREAT | O_WRONLY, 0600)) > 0)
	{			/* Sign to show you have read */
		if (write(fd, curuser.userid, IDLEN) == IDLEN)
		{
			close(fd);
			return 0;
		}
		close(fd);
	}
	return -1;
}


int
countvote(pos, vpath)
int     pos;
char   *vpath;
{
	char    filename[PATHLEN];

	if (votelink->contain.max <= choice)
	{
		printxy(1, 0, "�C�H�u�i�� %d ��.", votelink->contain.max);
		igetch();
	}
	else
	{
		printxy(1, 0, "�z�T�w�� ? [n]: ");
		if ((igetch() | 32) == 'y')
		{
			sprintf(filename, "%s%s/item%d", vpath, votelink->contain.dir, pos - 2);
			if (IsVoted(filename))
			{
				move(1, 0);
				clrtoeol();
				return -1;
			}
			CastBallot(filename);

			printxy(pos, 6, "��");
			choice++;

			sprintf(filename, "%s%s/itemcount%d", vpath, votelink->contain.dir, pos - 2);
			IncreaseBallot(filename);

			sprintf(filename, "%s%s/%s", vpath, votelink->contain.dir, VOTEMEN);
			if (!IsVoted(filename))
			{
				CastBallot(filename);
				sprintf(filename, "%s%s/countmen", vpath, votelink->contain.dir);
				IncreaseBallot(filename);
			}
		}
	}
	move(1, 0);
	clrtoeol();
	return -1;
}

int
checkkey2(pos, cond, vpath)	/* Use to select item */
int    *pos;
int     cond;
char   *vpath;
{
	switch (igetkey())
	{
		case KEY_UP:
		case 'p':
			printxy(*pos, 3, "  ");
			if (*pos == 3)
				*pos = voteitemnum + 3;
			else
				(*pos)--;
			printxy(*pos, 3, "=>");
			return 0;
		case KEY_DOWN:
		case 'n':
			printxy(*pos, 3, "  ");
			if (*pos == voteitemnum + 3)
				*pos = 3;
			else
				(*pos)++;
			printxy(*pos, 3, "=>");
			return 0;
		case KEY_RIGHT:
		case '\n':
		case '\r':
			if (cond == 1)
				inputitem(pos);
			if (cond == 2)
				countvote(*pos, vpath);
			return 0;
		case KEY_LEFT:
			clear();
			return -1;
		case 'd':
			if (cond == 2)
				break;
			if (uinfo.mode == EDITVOTE)
				break;

			if (strcmp(voteitems[*pos - 3].item, EMPTY) == 0)
				break;
			voteitemnum--;
			bcopy(&voteitems[*pos - 2], &voteitems[*pos - 3], sizeof(struct voteitemstruct) * (voteitemnum - *pos + 4));

			sprintf(genbuf, "%s %d", WRITED, voteitemnum);
			if (voteitemnum != 0)
				strncpy(votelist[LIST3].contain, genbuf, 12);
			else
				strcpy(votelist[LIST3].contain, "[None]");
			redraw = 0;
			break;
		case 45:
			if (cond == 1)
				inputitem(pos);
			if (cond == 2)
				countvote(*pos, vpath);
			return 0;
		case 'e':
			clear();
			return -1;
		default:
			return 0;
	}
}


int
voteexit()
{
	printxy(2, 0, "�z�T�w�n���}�s��� ? [n]: ");
	if ((igetch() | 32) == 'y')
		return -1;
	printxy(2, 0, "%-80s", "");	/* clean */
	return 0;
}


int
checkkey(pos, cond)
int    *pos;
int     cond;
{
	int     l, key;

	switch ((key = igetkey()))
	{
		case KEY_UP:
		case 'p':
			if (cond == YES)
				printxy(*pos, 3, "  ");
			*pos = votelist[*pos - 4].prow;
			if (cond == YES)
				printxy(*pos, 3, "=>");
			return 0;
		case KEY_DOWN:
		case 'n':
			if (cond == YES)
				printxy(*pos, 3, "  ");
			*pos = votelist[*pos - 4].nrow;
			if (cond == YES)
				printxy(*pos, 3, "=>");
			return 0;
		case KEY_RIGHT:
		case '\n':
		case '\r':
			votelist[*pos - 4].func();
			redraw = 0;
			return 0;
		case KEY_LEFT:
			if (voteexit() == -1)
				return -1;
		default:
			l = 0;
			while (votelist[l].hkey != 255)
			{
				if (key == votelist[l].hkey)
				{
					if (cond == YES)
						printxy(*pos, 3, "  ");
					*pos = l + 4;
					if (cond == YES)
						printxy(*pos, 3, "=>");
					return 0;
				}
				l++;
			}
			switch (key | 32)
			{
				case 45:
					votelist[*pos - 4].func();
					redraw = 0;
					return 0;
				case 'e':
					if (voteexit() == -1)
						return -1;
			}
	}
}

int
freelink()
{				/* Free vote link list */
	struct VoteLink *temp;

	if (votetop == NULL)
		return -1;

	votelink = votetop;

	do
	{
		temp = votelink;
		votelink = votelink->next;
		free(temp);
	}
	while (votelink != NULL);
}

int
select_ok(pos, vpath)		/* vote select ok , start choose items */
int     pos;
char   *vpath;
{
	int     f;
	int     l = 0;
	int     position = 3;
	struct VoteLink *temp;
	long    tmp;

	choice = 0;

	if (strncmp(votelink->contain.hostlimit, uinfo.from, strlen(votelink->contain.hostlimit)) != 0)
	{
		if (strcmp(votelink->contain.hostlimit, "[None]") != 0)
		{
			l = 1;
			sprintf(genbuf, "%s%s%s", "����IP�� ", votelink->contain.hostlimit, "��i�벼, ��p!!...");
		}
	}

	tmp = time(0);		/* check time */
	if (votelink->contain.startdate > tmp)
	{
		l = 1;
		strcpy(genbuf, "�벼�ɶ�����, ��p!!...");
	}
	if (votelink->contain.enddate < tmp)
	{
		l = 1;
		strcpy(genbuf, "�벼�ɶ��w�L, ��p!!...");
	}
	if (votelink->contain.levellimit > curuser.userlevel)
	{
		l = 1;
		sprintf(genbuf, "�벼���Ŭ�%3d, ��p!!...", votelink->contain.levellimit);
	}
	if (l == 1)
	{			/* �����~�T���~���� */
		printxy(2, 0, "[1;37;42m%s[m", genbuf);
		igetch();
		move(2, 0);
		clrtoeol();
		return 0;
	}

	voteitemnum = votelink->contain.totalitem;

	sprintf(genbuf, "%s%s/itemlist", vpath, votelink->contain.dir);
	f = open(genbuf, O_RDONLY);	/* Add check */
	read(f, voteitems, sizeof(struct voteitemstruct) * voteitemnum);
	close(f);

	redraw = 0;
	voteitemnum--;
	while (1)
	{
		if (redraw == 0)
		{
			showvotelist(2);
			redraw++;
			printxy(position, 3, "=>");
		/* Show �� */
			for (l = 0; l <= voteitemnum; l++)
			{
				sprintf(filename, "%s%s/item%d", vpath, votelink->contain.dir, l + 1);
				if (IsVoted(filename))
				{
					printxy(l + 3, 6, "��");
					choice++;
				}
			}
		}
		if (checkkey2(&position, 2, vpath) == -1)
			break;
	}

	temp = votelink;
	votelink = scrtop;
	printvote(pos);
	votelink = temp;

	return 0;
}

int
readresult(pos, vpath)
char   *vpath;
{
	int     f;
	int     l;
	int     tmp;
	long    tp;
	struct VoteLink *temp;

	tp = time(0);
	if (tp < votelink->contain.enddate)
		if (!HAS_PERM(PERM_SYSOP))
		{
			move(2, 0);
			clrtoeol();
			outs("�}���ɶ��|����, �����Ѭd��!");
			igetch();
			move(2, 0);
			clrtoeol();
			return -1;
		}

	clear();

	voteitemnum = votelink->contain.totalitem;

	sprintf(genbuf, "%s%s/itemlist", vpath, votelink->contain.dir);
	l = open(genbuf, O_RDONLY);	/* Add check */
	read(l, voteitems, sizeof(struct voteitemstruct) * voteitemnum);
	close(l);

#if	defined( NSYSUBBS2 ) || defined( NSYSUBBS3 )
	prints("%s   �벼�W�� : [1;37m%-65s[m\n", MENU_TITLE_COLOR, votelink->contain.contain);
#else
	prints("[1;36;44m   �벼�W�� : [1;37m%-65s[m\n", votelink->contain.contain);
#endif
	prints("[1;37;42m     �s��     ����      �W�� [m\n\n");

	for (l = 1; l <= voteitemnum; l++)
	{
		sprintf(genbuf, "%s%s/itemcount%d", vpath, votelink->contain.dir, l);
		tmp = 0;
		if ((f = open(genbuf, O_RDONLY)) != -1)
		{
			read(f, &tmp, sizeof(int));
			close(f);
		}
		prints("     %2d : %7d    %s\n", l, tmp, voteitems[l - 1].item);
	}

	sprintf(filename, "%s%s/countmen", vpath, votelink->contain.dir);
	if ((f = open(filename, O_RDONLY)) > 0)
	{
		read(f, &tmp, sizeof(int));
		close(f);
	}
	move(b_line - 1, 0);
	clrtoeol();
	prints("     �벼�`�H�� : %d", tmp);
	pressreturn();

	temp = votelink;
	votelink = scrtop;
	printvote(pos);
	votelink = temp;
}

int
showdata(pos)
int     pos;
{
	struct VoteLink *temp;
	long    tmp;

	clear();
	tmp = time(0);		/* Get time */

	prints("[37;44m   �벼�W�� : [1;37m%-65s[m\n\n", votelink->contain.contain);
	prints("     �벼�ҩl�ɶ� : %s", ctime(&votelink->contain.startdate));
	prints("     �벼�����ɶ� : %s", ctime(&votelink->contain.enddate));
	prints("     �벼IP���� : %s\n", votelink->contain.hostlimit);
	prints("     �벼���ŭ��� : %d\n", votelink->contain.levellimit);
	prints("     �벼���ƭ��� : %d\n\n", votelink->contain.max);
	prints("     ����ɶ� : %s", ctime(&tmp));
	pressreturn();

	temp = votelink;
	votelink = scrtop;
	printvote(pos);
	votelink = temp;
}

int
checkkey3(pos, func, vpath)	/* ��ܧ벼 */
int    *pos;
int     (*func) ();
char   *vpath;
{
	int     l;
	struct VoteLink *temp;

	switch (igetkey())
	{
		case KEY_UP:
		case 'p':
			printxy(*pos, 3, "  ");
			if ((*pos) == 3)
			{
				if (votelink->contain.order != 1)
				{
					*pos = 21;
					for (l = 0; l < 19; l++)
						votelink = votelink->last;
					printvote(*pos);
				}
			}
			else
			{
				(*pos)--;
				votelink = votelink->last;
			}
			printxy(*pos, 3, "=>");
			return 0;
		case KEY_DOWN:
		case 'n':
			printxy(*pos, 3, "  ");
			if ((*pos) == 21)
			{
				if (votelink->contain.order != totalvote)
				{
					*pos = 3;
					votelink = votelink->next;
					printvote(*pos);
					votelink = scrtop;
				}
			}
			else
			{
				if (votelink->contain.order != totalvote)
				{
					(*pos)++;
					votelink = votelink->next;
				}
			}
			printxy(*pos, 3, "=>");
			return 0;
		case KEY_RIGHT:
		case '\n':
		case '\r':
			return func(*pos, vpath);
		case KEY_LEFT:
			return -1;
		case 45:
			return func(*pos, vpath);
		case 'c':
			sprintf(genbuf, "%s%s/votedoc", vpath, votelink->contain.dir);
			more(genbuf, YEA);
			temp = votelink;
			votelink = scrtop;
			printvote(*pos);
			votelink = temp;
			return 0;
		case 'r':	/* �ݵ��G */
			readresult(*pos, vpath);
			return 0;
		case 'a':	/* ��ܳ�����T */
			showdata(*pos);
			return 0;
		case 'e':
			return -1;
		default:
			break;
	}
	return 0;
}

int
printvote(pos)
int     pos;
{
	int     l = 0;

	clear();
#if	defined( NSYSUBBS2 ) || defined( NSYSUBBS3 )
	prints("%sBBS �벼��%-40s    �ݪO : %-17s[m",
	       MENU_TITLE_COLOR, "",
	((topb) ? ((struct BoardList *) (curb->word))->name : DEFAULTBOARD));

	msg("%s (��)(��)����� (��)(Enter)��� (��)(e)�^��W�h (c)���� (a)��ܳ]�w (r)�d���G [m",
	    MENU_BTITLE_COLOR);
#else
	prints("[1;36;44mBBS �벼��%-40s    �ݪO : %-17s[m",
	       "", ((topb) ? ((struct BoardList *) (curb->word))->name : DEFAULTBOARD));

	msg("[37;44m (��)(��)����� (��)(Enter)��� (��)(e)�^��W�h (c)���� (a)��ܳ]�w (r)�d���G [m");
#endif

	printxy(3, 0, "");
	scrtop = votelink;

	do
	{
		prints("%7s%3d  %s\n", "", votelink->contain.order, votelink->contain.contain);
		if (l != 18)
			votelink = votelink->next;
		l++;
	}
	while (l < 19 && votelink != NULL);

	printxy(pos, 3, "=>");
}

int
del_vote(pos, vpath)
int     pos;
char   *vpath;
{
	int     f;
	struct VoteFileStruct tmp;

	totalvote--;
	if (totalvote == 0)
	{
		myunlink(vpath);/* lasehu */
	}
	else
	{
		sprintf(genbuf, "%s/.DIR", vpath);
		f = open(genbuf, O_RDWR);
		lseek(f, (long) (totalvote * sizeof(struct VoteFileStruct) + sizeof(int)), SEEK_SET);
		read(f, &tmp, sizeof(struct VoteFileStruct));
		tmp.order = votelink->contain.order;
		lseek(f, 0, SEEK_SET);
		write(f, &totalvote, sizeof(int));
		lseek(f, (long) ((tmp.order - 1) * sizeof(struct VoteFileStruct)), SEEK_CUR);
		write(f, &tmp, sizeof(struct VoteFileStruct));
		close(f);

		sprintf(genbuf, "%s/%s/", vpath, votelink->contain.dir);
		myunlink(genbuf);
	}
	printxy(2, 0, "�R������!");
	pressreturn();
	return -1;
}

int
edit_vote(pos, vpath)
int     pos;
char   *vpath;
{
	int     f;
	char    temp[80];

	votelist = &(holdlist[0]);

	strcpy(votelist[LIST1].contain, votelink->contain.contain);
	sprintf(votelist[LIST4].contain, "%d", votelink->contain.max);
	strcpy(votelist[LIST7].contain, votelink->contain.hostlimit);
	strcpy(votelist[LIST5].contain, ctime(&votelink->contain.startdate));
	strcpy(votelist[LIST6].contain, ctime(&votelink->contain.enddate));
	sprintf(votelist[LIST9].contain, "%d", votelink->contain.levellimit);
	sprintf(votelist[LIST3].contain, "%s %d", WRITED, votelink->contain.totalitem);
	strcpy(votelist[LIST2].contain, "[None]");

	sprintf(genbuf, "%s%s/votedoc", vpath, votelink->contain.dir);
	if ((f = open(genbuf, O_RDONLY)) != -1)
	{
		strcpy(votelist[LIST2].contain, WRITED);
		sprintf(genbuf, "%s%s/votedoc", vpath, votelink->contain.dir);
		sprintf(temp, "/tmp/%svotedoc", curuser.userid);
		mycp(genbuf, temp);
		close(f);
	}

	voteitemnum = votelink->contain.totalitem;

	sprintf(genbuf, "%s%s/itemlist", vpath, votelink->contain.dir);
	f = open(genbuf, O_RDONLY);	/* Add check */
	read(f, voteitems, sizeof(struct voteitemstruct) * voteitemnum);
	close(f);

	startdate = votelink->contain.startdate;
	enddate = votelink->contain.enddate;
	order = votelink->contain.order;
	strcpy(dirtname, votelink->contain.dir);
	return -1;
}

int
voteselect(cond, vpath)		/* cond is never used */
int     cond;
char    vpath[];
{
	int     f;
	int     pos = 3;
	struct VoteLink *temp = NULL;
	int     l;

	clear();
	order = 0;

	sprintf(genbuf, "%s.DIR", vpath);	/* /vote/sys or /vote/boards/* */
	if ((f = open(genbuf, O_RDONLY)) == -1)
	{
		outs(NOVOTE);
		pressreturn();
		redraw = 0;
		return -1;
	}
/* Create Link List */
	read(f, &totalvote, sizeof(int));
	votelink = (struct VoteLink *) malloc(sizeof(struct VoteLink));
	votetop = votelink;
	votetop->last = NULL;
	votetop->next = NULL;
	for (l = 0; l < totalvote; l++)
	{
		if (votelink == NULL)
		{
			votelink = (struct VoteLink *) malloc(sizeof(struct VoteLink));

			votelink->last = NULL;
			votelink->next = NULL;
			temp->next = votelink;
		}
		votelink->last = temp;
		read(f, &votelink->contain, sizeof(struct VoteFileStruct));

		temp = votelink;
		votelink = votelink->next;
	}
	close(f);

	sprintf(filename, "%s/%s", vpath, VOTENEW);
	if (!IsVoted(filename))
		HasSeeVote(filename);

	votelink = votetop;
	printvote(pos);
	votelink = votetop;

/* Condition check */

	switch (uinfo.mode)
	{
		case DELVOTE:
			while (1)
			{
				printxy(1, 0, "[�z�����] : %s", votelink->contain.contain);
				if (checkkey3(&pos, del_vote, vpath) == -1)
					break;
			}
			return -1;	/* �R���벼�S�� */
		case EDITVOTE:
			while (1)
			{
				printxy(1, 0, "[�z�����] : %s", votelink->contain.contain);
				if (checkkey3(&pos, edit_vote, vpath) == -1)
					break;
			}
			break;
		default:
			while (1)
			{
				printxy(1, 0, "[�z�����] : %s", votelink->contain.contain);
				if (checkkey3(&pos, select_ok, vpath) == -1)
					break;
			}
			break;
	}

	redraw = 0;
	freelink();		/* free vote tree */
	if (uinfo.mode == EDITVOTE && order == 0)
		return -1;
	return 0;
}


int
v_hold()
{
	int     f;

	redraw = 0;		/* init */

	votelist = &(holdlist[0]);
	startdate = 0;
	enddate = 0;
	strcpy(dirtname, "");

	for (curpos = 0; curpos < CONTAINS; curpos++)
		strcpy(votelist[curpos].contain, listcon[curpos]);
	for (curpos = 0; curpos < MAXITEM; curpos++)
		strcpy(voteitems[curpos].item, EMPTY);

	voteitemnum = 0;
	curpos = 4;
	sprintf(genbuf, "/tmp/%svotedoc", curuser.userid);	/* delete doc */
	myunlink(genbuf);

	if (HAS_PERM(PERM_SYSOP))
	{			/* system mananger */
		move(1, 0);
		clrtoeol();
		outs("�z�n�s�W�O�벼�� ? [n]: ");
		if ((igetch() | 32) == 'y')
		{
			Boards();
			sprintf(genbuf, "%s%s/", BOARDVOTE,
				((topb) ? ((struct BoardList *) (curb->word))->name : DEFAULTBOARD));
			strncpy(path, genbuf, 39);	/* Path */
			sprintf(votelist[LIST9].contain, "%d", ((topb) ? ((struct BoardList *) (curb->word))->level : 1));	/* This is the answer
																   above */
		}
		else
			strcpy(path, SYSVOTE);
	}
	else
	{
		if (curuser.userlevel != 100)
			return (M_FULL | R_FULL);
		if (curb == NULL || strcmp(curuser.userid, ((struct BoardList *) (curb->word))->owner) != 0)
		{
			printxy(2, 0, "�Х���ܱz�Һ޲z���O�l....");
			igetch();
			return M_FULL;
		}
		sprintf(genbuf, "%s%s/", BOARDVOTE, ((struct BoardList *) (curb->word))->name);
		strncpy(path, genbuf, 39);	/* Path */
	}

	sprintf(genbuf, "%s.DIR", path);
	if ((f = open(genbuf, O_RDONLY)) != -1)
	{
		read(f, &totalvote, sizeof(int));

		totalvote++;
		close(f);
	}
	else
		totalvote = 1;

	while (1)
	{
		if (redraw == 0)
		{
			showvotelist(1);
			redraw++;
			printxy(curpos, 3, "=>");
		}
		move(1, 0);
		clrtoeol();
		prints("[�z�����] : %s", votelist[curpos - 4].item);
		if (checkkey(&curpos, YES) == -1)
			break;
	}
	return M_FULL;
}


int
v_edit()
{
	int     f;
	int     curpos = 4;

	for (f = 0; f < MAXITEM; f++)
		strcpy(voteitems[f].item, EMPTY);

	if (HAS_PERM(PERM_SYSOP))
	{
		if (uinfo.mode < VOTING)
			return M_FULL;
		move(1, 0);
		clrtoeol();
		outs("�z�n�ק�O�벼�� ? [n]: ");
		if ((igetch() | 32) == 'y')
		{
			Boards();
			sprintf(genbuf, "%s%s/", BOARDVOTE,
				((topb) ? ((struct BoardList *) (curb->word))->name : DEFAULTBOARD));
			strncpy(path, genbuf, 39);	/* Path */
			if (voteselect(2, path) == -1)
				return M_FULL;
		}
		else
		{
			strcpy(path, SYSVOTE);
			if (voteselect(1, SYSVOTE) == -1)
				return M_FULL;
		}
	}
	else
	{			/* Board Manager */
		if (curuser.userlevel != 100)
			return M_FULL;
		if (curb == NULL || strcmp(curuser.userid, ((struct BoardList *) (curb->word))->owner) != 0)
		{
			printxy(2, 0, "�Х���ܱz�Һ޲z���O�l....");
			igetch();
			return M_FULL;
		}
		sprintf(genbuf, "%s%s/", BOARDVOTE,
			((struct BoardList *) (curb->word))->name);
		strncpy(path, genbuf, 39);	/* Path */
		if (voteselect(2, path) == -1)
			return M_FULL;
	}

	redraw = 0;		/* init */
	votelist = &(holdlist[0]);

	while (1)
	{
		if (redraw == 0)
		{
			showvotelist(1);
			redraw++;
			printxy(curpos, 3, "=>");
		}
		move(1, 0);
		clrtoeol();
		prints(1, 0, "[�z�����] : %s", votelist[curpos - 4].item);
		if (checkkey(&curpos, YES) == -1)
			break;
	}

	return M_FULL;
}


int
v_board()
{				/* �O�벼 */
	if (check_mul())
		return (M_FULL | R_FULL);

	if (uinfo.mode == VOTING)
		Boards();	/* Not Press Hot Key */
	sprintf(genbuf, "%s%s/", BOARDVOTE,
	((topb) ? ((struct BoardList *) (curb->word))->name : DEFAULTBOARD));
	strncpy(path, genbuf, 39);	/* Path */

	voteselect(2, path);

#if 0
	if (voteselect(2, path) == -1)
	{
		if (uinfo.mode < VOTING)
			return (M_FULL | R_FULL);
		else
			return (M_FULL | R_FULL);
	}
#endif
	return (M_FULL | R_FULL);
}


int
votetitle()
{
	getdata(2, 0, "�п�J���D(40 characters): ", genbuf, VOTELEN, DOECHO, NULL);
	printxy(2, 0, "%-80s", "");	/* clean */
	if (*genbuf == '\0')
		return -1;
	strncpy(votelist[LIST1].contain, genbuf, 41);
}


int
voteip()
{
	getdata(2, 0, "�п�J�\\�iIP: ", genbuf, VOTELEN, ECHONOSP, NULL);
	printxy(2, 0, "%-80s", "");
	if (*genbuf == '\0')
		strcpy(genbuf, "[None]");
	strncpy(votelist[LIST7].contain, genbuf, 41);
}


int
votemax()
{
	getdata(2, 0, "�п�J�̦h�i����`��: ", genbuf, VOTELEN, ECHONOSP, NULL);
	printxy(2, 0, "%-80s", "");
	if (*genbuf == '\0')
		return -1;
	if (atoi(genbuf) < 1)
		strcpy(genbuf, "1");
	strncpy(votelist[LIST4].contain, genbuf, 41);
}


int
save_doc(vpath)
char   *vpath;
{
	int     f;
	char    temp[80];

	sprintf(genbuf, "/tmp/%svotedoc", curuser.userid);
	if ((f = open(genbuf, O_RDONLY)) != -1)
	{
		close(f);
		sprintf(genbuf, "/tmp/%svotedoc", curuser.userid);
		sprintf(temp, "%s/votedoc", vpath);
		mycp(genbuf, temp);
	}
}


int
votesave()
{
	int     f, f2;
	int     l = 0;		/* Loop (error check) */
	char    itemdir[32];
	struct VoteFileStruct tmp;

/* check if complete */
	if (voteitemnum < 2)
	{
		l = 1;
		strcpy(genbuf, "�벼���إ�����");
	}

	if (startdate == 0 || enddate == 0)
	{
		l = 1;
		strcpy(genbuf, "�L�벼�ɶ�");
	}

	if (strcmp(votelist[LIST1].contain, "[None]") == 0)
	{
		l = 1;
		strcpy(genbuf, "�L�벼���D");
	}

	if (l == 1)
	{
		move(2, 0);
		clrtoeol();
		prints(2, 0, "%s, �L�k�s��, �Ы����@���~��.", genbuf);
		igetch();
		move(2, 0);
		clrtoeol();
		return -1;
	}

	if (!dashd(path))
	{
		if (mkdir(path, 0700) == -1)
			return -1;
	}
	sprintf(genbuf, "%s.DIR", path);
	if ((f = open(genbuf, O_CREAT | O_RDWR, 0600)) == -1)
		return -1;
	if (uinfo.mode == ADDVOTE)
	{

		write(f, &totalvote, sizeof(int));

		tmp.order = totalvote;
		tmp.startdate = startdate;
		tmp.enddate = enddate;
		strcpy(tmp.contain, votelist[LIST1].contain);
		strcpy(tmp.hostlimit, votelist[LIST7].contain);
		tmp.levellimit = atoi(votelist[LIST9].contain);
		tmp.max = atoi(votelist[LIST4].contain);
		tmp.totalitem = voteitemnum;

		if (dirtname[0] == '\0')
		{
			do
			{
				sprintf(dirtname, "M.%d", time(0));
				sprintf(itemdir, "%s%s", path, dirtname);
			}
			while (mkdir(itemdir, 0700) != 0);

			sprintf(filename, "%s/%s", itemdir, VOTEMEN);	/* Use for Count People */
			if ((f2 = open(filename, O_CREAT | O_TRUNC, 0600)) > 0)
			{
				close(f2);
			}
			sprintf(filename, "%s/%s", path, VOTENEW);	/* Use New Vote */
			if ((f2 = open(filename, O_CREAT | O_TRUNC, 0600)) > 0)
			{
				close(f2);
			}
			sprintf(filename, "%s/countmen", itemdir);
			if ((f2 = open(filename, O_CREAT | O_TRUNC, 0600)) > 0)
			{
				close(f2);
			}
		}
		else
			sprintf(itemdir, "%s%s", path, dirtname);

		for (l = 1; l <= voteitemnum; l++)
		{		/* Save Items to Disk */
			sprintf(filename, "%s/item%d", itemdir, l);
			if ((f2 = open(filename, O_CREAT | O_TRUNC, 0600)) > 0);	/* add check */
			close(f2);
			sprintf(filename, "%s/itemcount%d", itemdir, l);
			if ((f2 = open(filename, O_CREAT | O_TRUNC, 0600)) > 0);	/* add check */
			close(f2);
		}

		sprintf(genbuf, "%s/itemlist", itemdir);
		f2 = open(genbuf, O_CREAT | O_WRONLY, 0600);	/* add check */
		write(f2, voteitems, sizeof(struct voteitemstruct) * voteitemnum);
		close(f2);

		strcpy(tmp.dir, dirtname);
		lseek(f, (long) (sizeof(tmp) * (tmp.order - 1)), SEEK_CUR);	/* Write Vote Data chang */
		write(f, &tmp, sizeof(struct VoteFileStruct));
		close(f);

		save_doc(itemdir);
	}
	else
	{			/* Edit Vote Save ( Writed in this way is
				   more clear ) */

		tmp.order = order;
		tmp.startdate = startdate;
		tmp.enddate = enddate;
		strcpy(tmp.contain, votelist[LIST1].contain);
		strcpy(tmp.hostlimit, votelist[LIST7].contain);
		tmp.levellimit = atoi(votelist[LIST9].contain);
		tmp.max = atoi(votelist[LIST4].contain);
		tmp.totalitem = voteitemnum;
		strcpy(tmp.dir, dirtname);

		lseek(f, (long) (sizeof(tmp) * (order - 1) + sizeof(int)), SEEK_SET);
		write(f, &tmp, sizeof(struct VoteFileStruct));
		close(f);

		sprintf(genbuf, "%s%s/itemlist", path, dirtname);
		f2 = open(genbuf, O_WRONLY);	/* add check */
		write(f2, voteitems, sizeof(struct voteitemstruct) * voteitemnum);
		close(f2);

		sprintf(itemdir, "%s%s", path, dirtname);
		save_doc(itemdir);
	}

	move(2, 0);
	clrtoeol();
	outs("�s�ɧ���, �Ы����N�����}.");
	igetch();
	move(2, 0);
	clrtoeol();
	MakeBoardList();
}


int
voteboardhold()
{
	if (curuser.userlevel > 100)
		return R_FULL;
	uinfo.mode = ADDVOTE;
	v_hold();
	uinfo.mode = READING;
	return R_FULL;
}


int
votelogin()
{
	getdata(2, 0, "�п�J�i�벼�̵���: ", genbuf, VOTELEN, ECHONOSP, NULL);
	printxy(2, 0, "%-80s", "");
	if (*genbuf == '\0')
		return -1;
	strncpy(votelist[LIST9].contain, genbuf, 41);
}


long
inputdate(st)
char   *st;
{
	long    tmp;

	getdata(2, 0, st, genbuf, 5, DOECHO, NULL);
	if (genbuf[0] == '\0')
		return -1;
	tmp = time(NULL) + atol(genbuf) * 24 * 60 * 60;

	return tmp;
}


int
votestart()
{
	startdate = inputdate("�п�X���}�l: ");
	printxy(2, 0, "%-80s", "");	/* clean */
	if (startdate == -1)
		return;
	strncpy(votelist[LIST5].contain, ctime(&startdate), 41);
}


int
voteend()
{
	enddate = inputdate("�п�X��ᵲ��: ");
	printxy(2, 0, "%-80s", "");	/* clean */
	if (enddate == -1)
		return;
	strncpy(votelist[LIST6].contain, ctime(&enddate), 41);
}


int
votedoc()
{
	sprintf(genbuf, "/tmp/%svotedoc", curuser.userid);
	if (vedit(genbuf, NULL) != -1)
		strncpy(votelist[LIST2].contain, WRITED, 8);
}

int
v_del()
{				/* �R�� */

	if (HAS_PERM(PERM_SYSOP))
	{
		move(2, 0);
		clrtoeol();
		outs("�z�n�R���O�벼�� ? [n]: ");
		if (igetkey() == 'y')
		{
			Boards();
			sprintf(genbuf, "%s%s/", BOARDVOTE,
				((topb) ? ((struct BoardList *) (curb->word))->name : DEFAULTBOARD));
			strncpy(path, genbuf, 39);	/* Path */
			if (voteselect(2, path) == -1)
				return M_FULL;
		}
		else
		{
			if (voteselect(1, SYSVOTE) == -1)
				return M_FULL;
		}
	}
	else
	{			/* Board Manager */
		if (curb == NULL || strcmp(curuser.userid, ((struct BoardList *) (curb->word))->owner) != 0)
		{
			printxy(2, 0, "�Х���ܱz�Һ޲z���O�l....");
			igetch();
			return M_FULL;
		}
		sprintf(genbuf, "%s%s/", BOARDVOTE,
			((struct BoardList *) (curb->word))->name);
		strncpy(path, genbuf, 39);	/* Path */
		if (voteselect(2, path) == -1)
			return M_FULL;
	}
}


int
v_sys()
{				/* �t�Χ벼 */
	if (check_mul())
		return M_FULL;
	if (voteselect(1, SYSVOTE) == -1)
		return M_FULL;
}


int
voteitem()
{
	int     pos = 3;

	redraw = 0;
	while (1)
	{
		if (redraw == 0)
		{
			showvotelist(2);
			redraw++;
			printxy(pos, 3, "=>");
		}
		if (checkkey2(&pos, 1, path) == -1)
			break;
	}
	sprintf(genbuf, "%s %d", WRITED, voteitemnum);
	if (voteitemnum != 0)
		strncpy(votelist[LIST3].contain, genbuf, 12);
}


int
check_vote(vpath)
char   *vpath;
{
	int     fd;

	sprintf(genbuf, "%s/%s", vpath, VOTENEW);
	if ((fd = open(genbuf, O_RDONLY)) > 0)
	{
		while (read(fd, &VSrchUser, IDLEN) == IDLEN)
		{
			if (!strcmp(VSrchUser, curuser.userid))
			{
				close(fd);
				return 0;
			}
		}
		close(fd);
		return 1;
	}
	return 0;
}

#endif	/* USE_VOTE */