
#include <stdio.h>
#include <sys/types.h>


#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h> 

#include <varargs.h>

#define NET_IOTIMEOUUT	120
#ifndef MAXBSIZE
#define MAXBSIZE	8192
#endif

/*******************************************************************
 * create a client socket connected to PORT on HOSTNAME
 *******************************************************************/
create_client_socket(hostname, port)
char  **hostname;
int     port;
{
    struct sockaddr_in sa;
    struct hostent *hp;
    int     s;
    long    addr;

    memset(&sa, 0, sizeof(sa));
    if ((addr = inet_addr(*hostname)) != -1)
    {
/* is Internet addr in octet notation */
	memcpy((char *) &sa.sin_addr, &addr, sizeof(addr));	/* set address */
	sa.sin_family = AF_INET;
    }
    else
    {
/* do we know the host's address? */
	if ((hp = gethostbyname(*hostname)) == NULL)
	    return -2;
	*hostname = hp->h_name;
	memcpy((char *) &sa.sin_addr, hp->h_addr, hp->h_length);
	sa.sin_family = hp->h_addrtype;
    }

    sa.sin_port = htons((u_short) port);

    if ((s = socket(sa.sin_family, SOCK_STREAM, 0)) < 0)	/* get socket */
	return -1;
    if (connect(s, (struct sockaddr *) & sa, sizeof(sa)) < 0)
    {				/* connect */
	close(s);
	return -1;
    }
/* lasehu
   #ifdef IO_TIMEOUT
   init_alarm(IO_TIMEOUT);
   #endif
 */
    return s;
}

close_client_socket(socket)	/* lasehu */
{
    close(socket);
/* lasehu
   init_alarm(IO_TIMEOUT);
 */
}

/***************************************************************
 * send out messages with the customed format
 * �� printf �Ϊk�ۦP, �u�O output �� socket
 ***************************************************************/
net_write(sd, buf, nbytes)
int     sd;
char   *buf;
int     nbytes;
{
    int     bytes_written;

    if ((bytes_written = write(sd, buf, nbytes)) == -1)
	return 0;
    return (bytes_written);
}

/***************************************************************
 * send out messages with the customed format
 * �� printf �Ϊk�ۦP, �u�O output �� socket
 ***************************************************************/
net_printf(sd, format, va_alist)
int     sd;
char   *format;

va_dcl
{
    char    str[MAXBSIZE];
    va_list args;

    va_start(args);
    vsprintf(str, format, args);
    va_end(args);

    return (net_write(sd, str, strlen(str)));
}

/*****************************************************************
 * �q socket Ū�J�@��, �J��s��r������.
 * �Ѽ� newline : 1 --> ��s��r���d�b�r���.
 *                0 --> �h���s��r��.
 *****************************************************************/

static char ibuf[512];
static char *begin = ibuf, *to = ibuf, *end = ibuf + 511, *p = ibuf;

char   *
net_gets(sd, buf, buf_size)
int     sd;
char    buf[];
int     buf_size;
{
	struct timeval wait;
	static fd_set  ibits;
	int cc, maxs = sd + 1;
	char *w = buf, *we = buf + buf_size;

    wait.tv_sec = NET_IOTIMEOUT;
    wait.tv_usec = 0;
	if(to != begin)
	{
		for(; begin <= to, w < we; w++, begin++)
			*w = *begin;
		begin = to = ibuf;
	}
	while(1)
	{
		FD_ZERO(&ibits);
		FD_SET(sd, &ibits);
		if ((on = select(maxs, &ibits, 0, 0, &wait)) < 1)
		{
			if (!on || errno == EINTR)
				continue;
			else
			{
				begin = to = p = ibuf;
				*buf = '\0';
				return (char *)NULL;
			}
		}
		if (!FD_ISSET(sd, &ibits))
			continue;
		if((cc = read(sd, w, we - w)) < 1)
		{
			begin = to = p = ibuf;
			*buf = '\0';
			return (char *) NULL;
		}
		for(; cc > 0 && *w != '\n'; cc--, w++)
			/* null */ ;
		if(cc > 1)
		{
			for(p = ++w; cc > 0 && to < end; to++, p++)
				*to = *p;
			*w = '\0';
			return buf;
		}
		else
		{
			if(*w == '\n')
			{
				*(++w) = '\0';
				to = ibuf;
				return buf;
			}
			w++;
			continue;
		}
	}
}
