int
new_utmp()
{
    extern int errno;
    register time_t now;
    register int i;
    register pid_t pid;
    register USER_INFO *uentp;

    resolve_utmp();
    now = time(NULL) - 228;
    if (now > utmpshm->uptime)
	utmpshm->busystate = 0;

    while (utmpshm->busystate)
    {
	sleep(1);
    }
    utmpshm->busystate = 1;

/* ------------------------------- */
/* for ���F�ǻ�: �C 228 ����s�@�� */
/* ------------------------------- */

    if (now > utmpshm->uptime)
    {
	uentp = utmpshm->uinfo;
	for (i = now = errno = 0; i < USHM_SIZE; i++, uentp++)
	{
	    if (pid = uentp->pid)
	    {
		if ((kill(pid, 0) == -1) && (errno == ESRCH))
		{
		    memset(uentp, 0, sizeof(USER_INFO));
		    errno = 0;
		}
		else
		    now++;
	    }
	}
	utmpshm->number = now;
	time(&utmpshm->uptime);
    }

    uentp = utmpshm->uinfo;
    for (i = 0; i < USHM_SIZE; i++, uentp++)
    {
	if (!(uentp->pid))
	{
	    memcpy(uentp, &uinfo, sizeof(USER_INFO));	/* lasehu */
#if 0	    
	    curutmp = uentp;
#endif	    
	    utmpshm->number++;
	    utmpshm->busystate = 0;
	    return (i + 1);	/* lasehu */
	}
    }
    utmpshm->busystate = 0;
    sleep(1);
    exit(1);
}

#if 0
int
new_utmp()
{
    register int i, utmp_check = 0;
    register USER_INFO *uentp;
    register int new_seat, online_users;

    resolve_utmp();
#if 0
    if ((time(0) - utmpshm->uptime) > 228)
    {
	utmp_check = 1;
	utmpshm->busystate = 0;	/* ? */
    }
    while (utmpshm->busystate)	/* �N UTMP SHM lock �� */
	sleep(1);
#endif
    if ((time(0) - utmpshm->uptime) > 228)
	utmp_check = 1;
    else
    {
	while (utmpshm->busystate)	/* �N UTMP SHM lock �� */
	    sleep(1);
    }

    utmpshm->busystate = 1;

    new_seat = 0;
    online_users = 0;
    for (i = 0, uentp = utmpshm->uinfo; i < USHM_SIZE; i++, uentp++)
    {
	if (new_seat == 0 && uentp->pid == 0)
	{
	    memcpy(uentp, &uinfo, sizeof(USER_INFO));
	    curutmp = uentp;
	    online_users++;
	    new_seat = i + 1;
	    if (!utmp_check)
		break;
	}
	else if (do_check && uentp->pid > 2)	/* �w���ˬd�ç�s */
	{
	    if (kill(uentp->pid, 0) == -1 && errno == ESRCH)
		memset(uentp, 0, sizeof(USER_INFO));
	    else
		online_users++;
	}
    }
    if (do_check)
    {
	utmpshm->number = online_users;
	utmpshm->uptime = time(0);
    }
    else
    {
	utmpshm->number++;
    }
    utmpshm->busystate = 0;	/* ���� lock */
    if (new_seat == 0)
    {
	sleep(1);
	exit(1);
    }
    return new_seat;
}


int
new_utmp()
{
    register time_t now;
    register int i;
    register int online_users;
    register pid_t pid;
    register USER_INFO *uentp;

    resolve_utmp();
    now = time(NULL) - 228;
/* del by lasehu
    if (now > utmpshm->uptime)
	utmpshm->busystate = 0;

    while (utmpshm->busystate)
	sleep(1);

*/
    if (now <= utmpshm->uptime)	/* lasehu ? */
	while (utmpshm->busystate)
	    sleep(1);

    utmpshm->busystate = 1;

 /* for ���F�ǻ�: �C 228 ����s�@�� */

    if (now > utmpshm->uptime)
    {
	errno = 0;		/* ? */
	online_users = 0;
	for (i = 0, uentp = utmpshm->uinfo; i < USHM_SIZE; i++, uentp++)
	{
	    if ((pid = uentp->pid) != 0)
	    {
		if ((kill(pid, 0) == -1) && (errno == ESRCH))
		{
		    memset(uentp, 0, sizeof(USER_INFO));
		    errno = 0;	/* ? */
		}
		else
		    online_users++;
	    }
	}
	utmpshm->number = online_users;
	time(&utmpshm->uptime);
    }

    uentp = utmpshm->uinfo;
    for (i = 0; i < USHM_SIZE; i++, uentp++)
    {
	if (!(uentp->pid))
	{
	    memcpy(uentp, &uinfo, sizeof(USER_INFO));
	    curutmp = uentp;
	    utmpshm->number++;
	    utmpshm->busystate = 0;
	    return i + 1;	/* lasehu */
	}
    }
    utmpshm->busystate = 0;
    sleep(1);
    exit(1);
}

#endif
