
/*******************************************************************
 * Shared Memory function
 *******************************************************************/

#include "bbs.h"

#include <sys/ipc.h>
#include <sys/shm.h>


void
attach_err(shmkey, name)
int     shmkey;
char   *name;
{
	fprintf(stderr, "[%s error] key = %d\n", name, shmkey);
	bbslog("ERROR", "[%s error] key = %d", name, shmkey);	/* lasehu */
	exit(1);
}


void   *
attach_shm(shmkey, shmsize)
key_t   shmkey;
int     shmsize;
{
	void   *shmptr;
	int     shmid;

	shmid = shmget(shmkey, shmsize, 0);
	if (shmid < 0)
	{
		shmid = shmget(shmkey, shmsize, IPC_CREAT | 0600);
		if (shmid < 0)
			attach_err(shmkey, "shmget");
		shmptr = (void *) shmat(shmid, NULL, 0);
		if (shmptr == (void *) -1)
			attach_err(shmkey, "shmat");
		memset(shmptr, 0, shmsize);
	}
	else
	{
		shmptr = (void *) shmat(shmid, NULL, 0);
		if (shmptr == (void *) -1)
			attach_err(shmkey, "shmat");
	}
	return (void *) shmptr;
}


#include "shm.h"

struct UTMPFILE *utmpshm = NULL;/* �����ϥΪ� USER_INFO ���� */


void
resolve_utmp()
{
	if (utmpshm == NULL)
	{
		utmpshm = attach_shm(UTMPSHM_KEY, sizeof(*utmpshm));
		if (utmpshm->uptime == 0)
		{
			utmpshm->uptime = 1;
			utmpshm->number = 1;
		}
	}
}



#if 0
USER_INFO *
search_ulist(fptr, farg)
register int (*fptr) ();
register int farg;
{
	register USER_INFO *uentp;
	register int i;

	resolve_utmp();
	uentp = utmpshm->uinfo;
	for (i = 0; i < USHM_SIZE; i++, uentp++)
	{
		if (uentp->pid < 2)
			continue;
#if 0
		if (kill(uentp->pid, 0) == -1 && errno == ESRCH)	/* pid not exist */
			continue;
#endif
		if ((*fptr) (farg, uentp))
			return uentp;
	}
	return NULL;
}

#endif


USER_INFO *
search_ulist(fptr, farg)
register int (*fptr) ();
register char *farg;
{
	register USER_INFO *uentp;
	register int i;

	resolve_utmp();
	uentp = utmpshm->uinfo;
	for (i = 0; i < USHM_SIZE; i++, uentp++)
	{
		if (uentp->pid < 2)
			continue;
#if 0
		if (kill(uentp->pid, 0) == -1 && errno == ESRCH)	/* pid not exist */
			continue;
#endif
		if ((*fptr) (farg, uentp))
			return uentp;
	}
	return NULL;
}


int
apply_ulist(fptr)
register int (*fptr) ();
{
	register USER_INFO *uentp;
	register int i;

	resolve_utmp();
	uentp = utmpshm->uinfo;
	for (i = 0; i < USHM_SIZE; i++, uentp++)
	{
		if (uentp->pid < 2)
			continue;
#if 0
		if (uentp->pid < 2 || uentp->userid[0] == '\0')
			continue;
		if (uentp->active <= 0)
			continue;
#endif
		if (kill(uentp->pid, 0) == -1 && errno == ESRCH)	/* pid not exist */
			continue;
		if ((*fptr) (uentp) == QUIT_LOOP)	/* interrupt the loop */
			return QUIT_LOOP;
	}
	return 0;
}


int
ask_online_user()
{
	resolve_utmp();
	return utmpshm->number;
}
