#if 0
get_file_lines(filename)
char   *filename;
{
	FILE   *fp;
	int     file_lines = 0;
	int     ch;

	if ((fp = fopen(filename, "r")) != NULL)
	{
		while ((ch = fgetc(fp)) != EOF)
			if (ch == '\n')
				file_lines++;
	}
	return file_lines;
}

#endif
