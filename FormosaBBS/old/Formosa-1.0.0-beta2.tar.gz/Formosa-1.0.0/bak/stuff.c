
#include "bbs.h"
#include "global.h"
#include <pwd.h>
#include <varargs.h>


#ifndef MAXPATHLEN
#define MAXPATHLEN 	(256)
#endif


void 
pressreturn()
{
	move(b_line, 0);
	clrtoeol();
	outs("[1;37;40m�Ы� [Enter] ���~��[m");
	getkey();
/*
   move(b_line, 0);
   clrtoeol();
 */
}

#define LOOKFIRST  (0)
#define LOOKLAST   (1)
#define QUOTEMODE  (2)
#define MAXCOMSZ (1024)
#define MAXARGS (40)
#define MAXENVS (20)
#define BINDIR "bin/"		/* lasehu */

char   *bbsenv[MAXENVS];
int     numbbsenvs = 0;

bbssetenv(env, val)
char   *env, *val;
{
	register int i, len;

	if (numbbsenvs == 0)
		bbsenv[0] = NULL;
	len = strlen(env);
	for (i = 0; bbsenv[i]; i++)
		if (!strncasecmp(env, bbsenv[i], len))
			break;
	if (i >= MAXENVS)
		return -1;
	if (bbsenv[i])
		free(bbsenv[i]);
	else
		bbsenv[++numbbsenvs] = NULL;
	bbsenv[i] = (char *) malloc(strlen(env) + strlen(val) + 2);
	strcpy(bbsenv[i], env);
	strcat(bbsenv[i], "=");
	strcat(bbsenv[i], val);
}

pid_t   child_pid;

do_exec(com, wd)
char   *com, *wd;
{
	char    path[MAXPATHLEN];
	char    pcom[MAXCOMSZ];
	char   *arglist[MAXARGS];
	register int i, len;
	register int argptr;

	int     status, pid, w;
	int     pmode;
	void    (*isig) (), (*qsig) ();
	struct passwd *passid;

	passid = getpwuid(BBSBIN_UID);
	strncpy(path, BINDIR, MAXPATHLEN);
	strncpy(pcom, com, MAXCOMSZ);
	len = MIN(strlen(com) + 1, MAXCOMSZ);
	pmode = LOOKFIRST;
	for (i = 0, argptr = 0; i < len; i++)
	{
		if (pcom[i] == '\0')
			break;
		if (pmode == QUOTEMODE)
		{
			if (pcom[i] == '\001')
			{
				pmode = LOOKFIRST;
				pcom[i] = '\0';
				continue;
			}
			continue;
		}
		if (pcom[i] == '\001')
		{
			pmode = QUOTEMODE;
			arglist[argptr++] = &pcom[i + 1];
			if (argptr + 1 == MAXARGS)
				break;
			continue;
		}
		if (pmode == LOOKFIRST)
			if (pcom[i] != ' ')
			{
				arglist[argptr++] = &pcom[i];
				if (argptr + 1 == MAXARGS)
					break;
				pmode = LOOKLAST;
			}
			else
				continue;
		if (pcom[i] == ' ')
		{
			pmode = LOOKFIRST;
			pcom[i] = '\0';
		}
	}
	arglist[argptr] = NULL;
	if (argptr == 0)
		return -1;
	if (*arglist[0] == '/')
		strncpy(path, arglist[0], MAXPATHLEN);
	else
		strncat(path, arglist[0], MAXPATHLEN);
	reset_tty();
	if ((pid = vfork()) == 0)
	{
		seteuid(BBSBIN_UID);
		setuid(BBSBIN_UID);
		if (wd)
			if (chdir(wd))
			{
				fprintf(stderr, "Unable to chdir to '%s'\n", wd);
				exit(-1);
			}
/*
	bbssetenv("PATH", "/bin:/usr/lib:/etc:/usr/ucb:/usr/local/bin:/usr/local/lib:.");
*/
		bbssetenv("PATH", "/bin:/usr/lib:/etc:/usr/ucb:/usr/local/bin:/usr/local/lib");
		bbssetenv("TERM", curuser.termtype);
		bbssetenv("USER", passid->pw_name);
		bbssetenv("USERNAME", curuser.username);
		bbssetenv("HOME", passid->pw_dir);
		if (numbbsenvs == 0)
			bbsenv[0] = NULL;
		seteuid(BBSBIN_UID);
		setuid(BBSBIN_UID);
		execve(path, arglist, bbsenv);
		fprintf(stderr, "EXECV FAILED... path = '%s'\n", path);
		exit(-1);
	}
	isig = signal(SIGINT, SIG_IGN);
	qsig = signal(SIGQUIT, SIG_IGN);
	if (strstr(com, "bbs.chatd"))	/* --lmj */
		child_pid &= ~child_pid;
	else
		child_pid = pid;
#if defined(AIX)
	waitpid(pid, &status, 0);
#else
	while ((w = wait(&status)) != pid && w != 1)
		 /* NULL STATEMENT */ ;
#endif
	signal(SIGINT, isig);
	signal(SIGQUIT, qsig);
	child_pid &= ~child_pid;
	restore_tty();
	return ((w == -1) ? w : status);
}

/*
 * ����~���{��
 */
outdoor(cmd_file, umode, dotimeout)	/* INAPTITUDE */
char   *cmd_file;
int     umode;
int     dotimeout;
{
	int     save_pager = uinfo.pager;
	char    filename[PATHLEN], *p;
	int     save_umode = uinfo.mode;

	strncpy(filename, cmd_file, PATHLEN - 1);
	filename[PATHLEN - 1] = '\0';
	if ((p = strchr(filename, ' ')) != NULL)
		*p = '\0';
	if (!dashf(filename) || access(filename, X_OK) == -1)
	{
		char    buf[PATHLEN + 10];	/* lasehu */

		sprintf(buf, "%s%s", BINDIR, filename);
		if (!dashf(buf) || access(buf, X_OK) == -1)
		{
#ifdef DEBUG
			prints("\nThis option is disable");
			pressreturn();
#endif
			return;
		}
	}
	uinfo.pager = NA;
	update_umode(umode);
/*
   clear();
   refresh();
 */
	if (!dotimeout)
		signal(SIGALRM, SIG_IGN);	/* lasehu */
/*
   sprintf(buf, "/bin/sh %s", cmdfile);
   do_exec(buf,NULL);
 */
	do_exec(cmd_file, NULL);
	if (!dotimeout)
		init_alarm(IDLE_TIMEOUT);
	uinfo.pager = save_pager;
	uinfo.mode = save_umode;
	update_utmp();

	return;
}

/*
 * �C�X�Ҧ����U users ���
 */
Users()
{
	int     fd, sysop = 0, bm = 0, total = 0, ch, i = 3, show = 1,
	        spec_ulevel = 0, spec_total = 0;

#ifdef IDENT
	int     full_idents = 0, part_idents = 0;

#endif
	USEREC  urcbuf;

	move(1, 0);
	clrtobot();
	if (getdata(1, 0, "�n�d�ݵ��Ŧh�֥H�W���ϥΪ� ? [0] : ", genbuf, 4, ECHONOSP, NULL))
		spec_ulevel = atoi(genbuf);

	if ((fd = open(PASSFILE, O_RDONLY)) < 0)
		return -1;

	move(1, 0);
	clrtobot();
	prints("%-12s %-20s %6s %6s %4s", "�N�W", "���W", "�W����", "�i�K��", "����");
	prints("\n------------------------------------------------------------------------------");

	while (read(fd, &urcbuf, sizeof(USEREC)) == sizeof(USEREC))
	{
		if (urcbuf.userid[0] == '\0' || !strcmp(urcbuf.userid, "new"))
			continue;
		total++;
		if (urcbuf.userlevel >= 255)
			sysop++;
		else if (urcbuf.userlevel >= 100)
			bm++;
		if (urcbuf.userlevel < spec_ulevel)
			continue;

		spec_total++;
#ifdef IDENT
		if (urcbuf.ident == 7)
			full_idents++;
		else if (urcbuf.ident > 0)
			part_idents++;
#endif
		if (!show)
			continue;

		move(i++, 0);
		clrtoeol();
		prints("%-12s %-20.20s %6d %6d %4d\n",
		       urcbuf.userid, urcbuf.username, urcbuf.numlogins, urcbuf.numposts,
		       urcbuf.userlevel);
		if (i == b_line)
		{
			msg("[37;45m--- �٦��@ ---[44m [q] or [��]:���} , [��][n][Space]:�U�@��        [m");
			ch = igetkey();
			if (ch == KEY_LEFT || ch == 'q')
			{
				show = 0;
				continue;
			}
			i = 3;
			move(i, 0);
			clrtobot();
		}
	}
	close(fd);
	move(b_line - 1, 0);
	clrtobot();
	if (spec_ulevel == 0)
		prints("\n[37;44m���U�H�� %d �H, ", total);
	else
		prints("\n[37;44m�έp�H�� %d/%d �H, ", spec_total, total);
	prints("�޲z�� %d �H, �O�D %d �H", sysop, bm);
#ifdef IDENT
	prints(", (�{�� %d + %d)      [m", full_idents, part_idents);
#else
	prints("                      [m");
#endif
	igetch();

	return M_FULL;
}


void
show_byebye(idle)
int     idle;
{
	time_t  now = time(0);

	printxy(4, 15, "[31;42m------------(���i�ӤH�p�ɮסj��)-------------[m");
	printxy(5, 15, "[1;37;44m       �`�i�K�� == [33m%-6d                    [m", curuser.numposts);
	printxy(6, 15, "[1;37;44m       �W������ == [33m%-6d                    [m", curuser.numlogins);
	printxy(7, 15, "[1;37;44m   �W���Ӫ��ɨ� == [33m%-26s[m", Ctime(&nsysu_lastlogin));
	printxy(8, 15, "[1;37;44m   �W���Ӫ��a�� == [33m%-26s[m", nsysu_lastfromhost);
	printxy(9, 15, "[1;37;44m   �o���Ӫ��ɨ� == [33m%-26s[m", Ctime(&curuser.lastlogin));
	printxy(10, 15, "[1;37;44m   �o���Ӫ��a�� == [33m%-26s[m", curuser.lasthost);
	printxy(11, 15, "[31;42m (�� �{�b�ɶ��O %-24s ��) [m", Ctime(&now));
	if (idle)		/* ? */
		printxy(12, 26, "[1;33;45m �z�b�m�L�[, �w�۰����u [m");
	else
		printxy(12, 26, "[1;36;45m  �Ы� [33m<Enter>[36m �������u  [m");
}


void
log_usies(mode, va_alist)
char   *mode;

va_dcl
{
	va_list args;
	time_t  now;
	int     fd;
	char    msgbuf[STRLEN], buf[128], *fmt;
	char    timestr[22];

	va_start(args);
	fmt = va_arg(args, char *);
	vsprintf(msgbuf, fmt, args);
	va_end(args);

	time(&now);
	strftime(timestr, sizeof(timestr), "%x %X", localtime(&now));
	sprintf(buf, "%s %-12.12s %-10.10s %s\n",
		timestr, curuser.userid, mode, msgbuf);
	if ((fd = open(PATH_BBSLOG, O_APPEND | O_CREAT | O_WRONLY, 0600)) > 0)
	{
		write(fd, buf, strlen(buf));
		close(fd);
	}
}


/*
 * ���u����
 */
Goodbye()
{
	bell();
	move(b_line, 0);
	clrtoeol();
	refresh();
	printxy(b_line, 24, "[1;33;45m   �� �O�_���}���t�� (Y/N) :   [m");
	if (igetkey() != 'y')
		return M_FULL;
	clear();
	show_byebye(NA);
	refresh();
#if 0
	log_usies("EXIT", "Stay:%3ld", (time(0) - curuser.lastlogin) / 60);
#endif
	user_logout();
	igetch();
#if 0
	reset_tty();
#endif
	exit(0);
}


/*
 * �����ù��m/���Ҧ�
 */
Switch_scr()
{
	clear();
	if (HAS_FLAG(COLOR_FLAG))
	{
		show_ansi = YEA;
		outs("[1;37;40m�������m����ܼҦ�\n[m");
		UNSET_FLAG(COLOR_FLAG);
	}
	else
	{
		show_ansi = NA;
		outs("�����������ܼҦ�\n");
		SET_FLAG(COLOR_FLAG);
	}
	pressreturn();
	return M_FULL;
}


cmp_userid(userid, upent)
char   *userid;
USER_INFO *upent;
{
	if (upent == NULL)
		return 0;
	return (!strcmp(userid, upent->userid));
}


#if 0
int
cmp_uid(uid, upent)
unsigned int uid;
USER_INFO *upent;
{
#if 0
	if (!upent || !upent->active)
#endif
		if (!upent)
			return 0;
	return (uid == upent->uid);
}

#endif


cmp_bname(bname, binfo)
char   *bname;
BOARDHEADER *binfo;
{
	if (bname == NULL)
		return 0;
	return (!strcasecmp(bname, binfo->filename));	/* lasehu:
							   �O�W�����j�p�g */
}




void
setuserfile(buf, filename)
char   *buf, *filename;
{
#ifdef NEW_HOMEPATH
	unsigned char c;

	c = curuser.userid[0];
	if (c >= 'A' && c <= 'Z')
		c |= 32;
	else if (!(c >= 'a' && c <= 'z'))
		c = '0';
	sprintf(buf, "home/%c/%s/%s", c, curuser.userid, filename);
#else
	sprintf(buf, "%s/%s", filename, curuser.userid);
#endif
}


void
getuserfile(buf, filename)
char   *buf, *filename;
{
	sprintf(buf, "%s/%s", filename, curuser.userid);
}


void
setdotfile(buf, dotfile, fname)
char   *buf, *dotfile, *fname;
{
	strcpy(buf, dotfile);	/* ? */
	if ((dotfile = strrchr(buf, '/')) == NULL)
	{
		bbslog("ERROR", "setdotfile() dot[%s][%s]", dotfile, fname);
#ifdef MYDEBUG
		perror("setdotfile");
		pressreturn();
#endif
		return;
	}
	while (dotfile > buf && *(dotfile - 1) == '/')
		*dotfile-- = '\0';
	if (fname == NULL)
		*(dotfile + 1) = '\0';
	else
		strcpy(dotfile + 1, (fname[0] == '/') ? fname + 1 : fname);
}


char   *
Ctime(clock)
time_t *clock;
{

	char   *foo;
	char   *ptr = ctime(clock);

	if (foo = strrchr(ptr, '\n'))
		*foo = '\0';
	return (ptr);
}


bell()
{
	fprintf(stderr, "%c", CTRL('G'));
}

is_inetmail(to)
char   *to;
{
	char    buf[STRLEN];

	if (!strchr(to, '@'))
		return 0;
	if (strstr(to, MYHOSTNAME) || strstr(to, MYHOSTIP))
	{
		char   *p;

		strcpy(buf, to);
		p = strchr(buf, '@');
		*p = '\0';
		if ((p = strchr(buf, '.')) != NULL)
		{
			*p = '\0';
			strcpy(to, buf);	/* ���ǤJ�� to �r��}�C���e */
			return 0;
		}
/* �� to �� userid@MYHOSTNAME or userid@MYHOSTIP �ɷ��@ internt email */
	}
	return 1;
}

chk_alpha_str(str)
unsigned char *str;
{
	while (str && *str)
		if (!isalpha(*str++))	/* not alphacharacter */
			return 0;
	return 1;
}


void
chk_str(str)
char    str[];
{
	char    t[STRLEN], *p = str;
	int     j;

	for (j = 0; p && *p && j < STRLEN; j++)
	{
		if (*p == ESC && *(p + 1) == '[')
		{
			if (*(p + 2) == '\0')
				break;
			p += 3;
		}
		else if (*p == NL || *p == CR || *p == TAB)
			p += 1;
		t[j] = *p++;
	}
	t[j] = '\0';
	strcpy(str, t);
}

isprint2(ch)
char    ch;
{
	return (((ch & 0x80) || ch == 0x1B) ? 1 : isprint(ch));
}

isprint3(ch)			/* chang 5.5 */
unsigned char ch;
{
	if (ch == 27)
	{
		igetch();
		igetch();
		return 0;
	}
	return ((ch & 0x80) ? 1 : isprint(ch));
}

seek_in_file(filename, seekstr)
char    filename[], seekstr[];
{
	FILE   *fp;
	char    buf[STRLEN];
	char   *ptr;

	if ((fp = fopen(filename, "r")) == NULL)
		return 0;
	while (fgets(buf, sizeof(buf), fp) != NULL)
	{
		if ((ptr = strchr(buf, '#')) != NULL)
			*ptr = '\0';
		if (buf[0] == '\0')
			continue;
		if ((ptr = strtok(buf, ": \n\r\t")) && !strcmp(ptr, seekstr))
		{
			fclose(fp);
			return 1;
		}
	}
	fclose(fp);
	return 0;
}


#if 0
get_file_lines(filename)
char   *filename;
{
	FILE   *fp;
	int     file_lines = 0;
	int     ch;

	if ((fp = fopen(filename, "r")) != NULL)
	{
		while ((ch = fgetc(fp)) != EOF)
			if (ch == '\n')
				file_lines++;
	}
	return file_lines;
}

#endif

isINOUTDOOR(upent)
USER_INFO *upent;
{
/*
 * if (upent->mode == CHATROOM || upent->mode == GOPHER)
 */
	if (upent->mode == LOCALIRC || upent->mode == IRCCHAT
#ifdef USE_OKBRIDGE
	    || upent->mode == OKBRIDGE
#endif
		)
	{
		return 1;
	}
	return 0;
}

#if 0
int
isClient(upent)
USER_INFO *upent;
{
	if (upent->mode == CLIENT || upent->c_type == CTYPE_CSBBS)
		return YEA;
	return NA;
}

#endif


int
invalid_email(addr)
char   *addr;
{
	int     ch, mode;

	mode = -1;
	while ((mode <= 0) && (ch = *addr))
	{
		if (ch == '@')
			mode++;
		else if (!isalnum(ch) && !strchr("[].%!:-_ <>\"{}", ch))
			return 1;
		addr++;
	}
	if (mode > 0)
		return 1;
	return 0;
/* return mode; */
}


int
invalid_userid(userid)
char   *userid;
{
	char    buf[IDLEN + 1];
	int     i;

	if (strlen(userid) < 3)
		return 1;

	for (i = 0; userid[i]; i++)
	{
		if (!isalpha(userid[i]))
			return 1;
		if (userid[i] >= 'A' && userid[i] <= 'Z')
			buf[i] = (userid[i] | 32);
		else
			buf[i] = userid[i];
	}
	buf[i] = '\0';
	if (!strncmp(buf, "new", 3))
		return 1;
#ifndef SYSOP
	if (strstr(buf, "sysop"))
		return 1;
#endif
	if (seek_in_file(BADUSERID, buf))
		return 1;
	return 0;
}


int
invalid_bname(bname)
char   *bname;
{
	char    c;

	if (strlen(bname) > BNAME_LEN)
		return 1;

	if (!bname || !*bname)
		return 1;
	for (c = 0; bname[c]; c++)
		if (!isalnum(bname[c]) && bname[c] != '-')
			return 1;
	return 0;
}


void
trim(buf)			/* remove trailing space */
char   *buf;
{
	char   *p = buf;

	if (p)
	{
		while (*p)
			p++;
		p--;
		if (p >= buf && *p == '\n')	/* lasehu */
			*p = ' ';
		while (p >= buf && *p == ' ')
			*p-- = '\0';
	}
}

uuencode_file(fname, uuname)
char   *fname, *uuname;
{
	char    buf[256];

	sprintf(uuname, "tmp/%s.uu", curuser.userid);
	sprintf(buf, "uuencode %s bbs.uu > %s", fname, uuname);
	outdoor(buf, UNDEFINE, YEA);
}


do_article_title(title)
char   *title;
{
	if (*title)
	{
		printxy(2, 0, "�ϥμ��D (%s) ? (y/n) [y] : ", title);
		if (igetkey() == 'n')
			title[0] = '\0';
	}
	trim(title);
	if (*title == '\0')
	{
		if (!getdata(2, 0, "���D : ", title, STRLEN, DOECHO, NULL))
			return -1;
	}
}


do_article_to(to)
char   *to;
{
	if (*to)
	{
		printxy(1, 0, "�H(�^)�� [%s] ? (y/n) [y] : ", to);
		if (igetkey() == 'n')
			to[0] = '\0';
	}
	if (*to == '\0')
	{
		if (!getdata(1, 0, "�H(�^)�� : ", to, STRLEN, ECHONOSP, NULL))
			return -1;
	}
/*
   clear();
   outs("-�s�覬�H�W��-\n");
   outs("�[�J(U)�����ϥΪ�(E)E-mail(B)�Q�װ�,(D)�R��,(Q)���},(O)�T�w?[O]
   outs("<<�а�>> �n�H�� (1)�@�ӤH (2)�@�s�H ? (1/2) :[1] ");
   if (getkey() == '2')
   {
   if (ask_group() == 0)
   return FULLUPDATE;
   }
 */
}


char   *
mycrypt(pw)
char   *pw;
{
/*
   static char   saltc[21];
   unsigned char c;
   int i;

   sprintf(saltc, "%20.20s", pw);

   for (i = 0; saltc[i]; i++)
   {
   c = saltc[i] + '.';
   if (c > '9')
   c += 7;
   if (c > 'Z')
   c += 6;
   saltc[i] = c;
   }
 */
	static char saltc[40];

	sprintf(saltc, "%d", atol(pw) + 1);
	return saltc;
}


#if 0
char   *
get_config(keyword)
char   *keyword;
{
	FILE   *fp;

	if ((fp = fopen(CONFIG_FILE, "r")) != NULL)
	{
		char    conf[64];
		int     len;
		static char buf[256];

		sprintf(conf, "%s:", keyword);
		len = strlen(conf);
		while (fgets(buf, sizeof(buf), fp) != NULL)
		{
			char   *p;

			if ((p = strchr(buf, '#')) != NULL)
				*p = '\0';
			p = buf;
			while (*p != '\0' && (*p == ' ' || *p == '\t' || *p == '\n'))
				p++;
			if (*p == '\0')
				continue;
			if (!strncmp(p, conf, len))
			{
				p = p + len;
				while (*p != '\0' && (*p == ' ' || *p == '\t' || *p == '\n'))
					p++;
				if (*p == '\0')
					continue;
				fclose(fp);
				trim(p);
				return p;
			}
		}
		fclose(fp);
	}
	return NULL;
}

#endif


#define NUMLINES (19)


/*******************************************************************
 * ������J, �P���w�� link list ���
 *******************************************************************/
int
namecomplete(toplev, prompt, data)
struct word *toplev;
char   *prompt;
char    data[];
{
	char   *temp;
	int     ch;
	int     count = 0;
	int     clearbot = NA;
	struct word *cwlist, *morelist;
	int     x, y, origx, origy;

	if (prompt)
	{
		prints("%s", prompt);
		clrtoeol();
	}
	temp = data;

	cwlist = get_subwlist(NULL, toplev);
	morelist = NULL;
	getyx(&origy, &origx);
	y = origy;
	x = origx;
	while ((ch = igetch()) != EOF)
	{
		if (ch == '\n' || ch == '\r')
		{
			*temp = '\0';
			prints("\n");
		/* lasehu */
			if (strlen(data) >= 1 &&
			    (num_wlist(cwlist) == 1 || !strcmp(data, cwlist->word)))
				strcpy(data, cwlist->word);
			else
			{
				data[0] = '\0';
				move(b_line - 1, 0);
				outs("��ܿ��~. �S�����ŦX��.");
				pressreturn();
			}
			cwlist = free_wlist(cwlist, NULL);
			break;
		}
		else if (ch == ' ')
		{
			int     col, len;

			if (num_wlist(cwlist) == 1)
			{
				strcpy(data, cwlist->word);
				move(y, x);
				prints("%s", data + count);
				count = strlen(data);
				temp = data + count;
				getyx(&y, &x);
				continue;
			}
			clearbot = YEA;
			col = 0;
			if (!morelist)
				morelist = cwlist;
			len = maxlen_wlist(morelist, NUMLINES);
			move(3, 0);
			clrtobot();
			standout();
			prints("------------------------------- Completion List -------------------------------");
			standend();
			while (len + col < 80)
			{
				int     i;

				for (i = NUMLINES; (morelist) && (i > 0); i--, morelist = morelist->next)
				{
					move(4 + (NUMLINES - i), col);
					prints("%s", morelist->word);
				}
				col += len + 2;
				if (!morelist)
					break;
				len = maxlen_wlist(morelist, NUMLINES);
			}
			if (morelist)
			{
				move(23, 0);
				standout();
				prints("-- More --");
				standend();
			}
			move(y, x);
			continue;
		}
		else if (ch == '\177' || ch == '\010')
		{
			if (temp == data)
				continue;
			temp--;
			count--;
			*temp = '\0';
			cwlist = free_wlist(cwlist, NULL);
			cwlist = get_subwlist(data, toplev);
			morelist = NULL;
			x--;
			move(y, x);
			outc(' ');
			move(y, x);
			continue;
		}
		else if (count < STRLEN)
		{
			struct word *node;

			*temp++ = ch;
			count++;
			*temp = '\0';
			node = get_subwlist(data, cwlist);
			if (node == NULL)
			{
				bell();
				temp--;
				*temp = '\0';
				count--;
				continue;
			}
			cwlist = free_wlist(cwlist, NULL);
			cwlist = node;
			morelist = NULL;
			move(y, x);
			outc(ch);
			x++;
		}
	}
	if (ch == EOF)
		longjmp(byebye, -1);
	prints("\n");
	refresh();
	if (clearbot)
	{
		move(3, 0);
		clrtobot();
	}
	if (data[0] != '\0')
	{
		move(origy, origx);
		prints("%s\n", data);
	}
	return 0;
}
