
#include "bbs.h"
#include "global.h"
#include "screen.h"


#define MAXPAGE	(1024)

int
readln(fp, buf)
FILE   *fp;
char   *buf;
{
	register int ch, i = 0,	/* the index position of buf */
	        len = 0,	/* length of each line (exclude ansi code) */
	        bytes = 0;	/* bytes read from file */

/* ?
    while (len < t_columns && i < ANSILINELEN && (ch = getc(fp)) != EOF)
*/
	while (len < ANSILINELEN && i < ANSILINELEN && (ch = getc(fp)) != EOF)
	{
		bytes++;
		if (ch == '\n')
		{
			len++;
			buf[i++] = ch;
			break;
		}
		else if (ch == '\t')
		{
			do
			{
				buf[i++] = ' ';
			}
/* ?
	    while ((++len & 7) && len < t_columns);
*/
			while ((++len & 7) && len < ANSILINELEN);
		}
		else if (isprint2(ch))
		{
			len++;
			buf[i++] = ch;
		}
	}
	buf[i] = '\0';
	return bytes;
}

int
more(filename, promptend)
char   *filename;
int     promptend;
{
	FILE   *fp;
	int     chkey;		/* ? */
	int     i, linectr, pos;
	int     viewed, numbytes;
	int     pageno, pagebreaks[MAXPAGE];

#if 0
	int     save_sig = 0;

#endif
	int     doscroll = NA;	/* lasehu */
	long    tsize;
	struct stat st;
	char    buf[512];

	if ((fp = fopen(filename, "r")) == NULL)
		return -1;

	if (fstat(fileno(fp), &st) == -1)
		return -1;

	tsize = st.st_size;

	i = linectr = 0;
	pos = 0;
	viewed = 0;
	pageno = 0;
	pagebreaks[0] = 0;

	clear();

#if 0
	if (uinfo.mode == LOGIN && curuser.lasthost[0] != '\0')
	{
		prints("Last logged in from %s on %s",
		       curuser.lasthost, ctime(&curuser.lastlogin));
		linectr++;
	}
#endif
	numbytes = readln(fp, buf);
	do
	{
		if (!numbytes)
			break;

		viewed += numbytes;

		if ((buf[0] == '>' && buf[1] == '>') ||
		    (buf[0] == ':' && buf[1] == ':'))
		{
			prints("[0;36m");
			outs(buf);
			prints("[m");
		}
		else if (buf[0] == '>' || buf[0] == ':')
		{
			prints("[0;32m");
			outs(buf);
			prints("[m");
		}
		else
		{
			outs(buf);
		}

		i++;
/*---
	if (++pos == t_lines)
	{
	    scroll();
	    pos--;
	}
*/
		if (doscroll)	/* lasehu */
		{
			scroll();
			doscroll = NA;
		}
		linectr++;
		if (linectr == t_lines - 1)
		{
			if (pageno < MAXPAGE - 1)
				pagebreaks[pageno + 1] = viewed - numbytes;
		}
		else if (linectr == t_lines)
		{
			pageno++;
			linectr = 0;
		}
#if 0
		if (save_sig && save_sig++ < 21)
			strncat(genbuf, buf, sizeof(buf));
		if (buf[0] == '-' && buf[1] == '-' && buf[2] == '\n')
		{
			genbuf[0] = '\0';
			save_sig++;
			linectr = i;
		}
#endif
		numbytes = readln(fp, buf);
		if (!numbytes)
			break;
		if (i == b_line)
		{
			move(b_line, 0);
/*--
	    if (dumb_term)
	        bell();
	    else
*/
			prints("[1;37;45m--More--(%d%% p.%d)[0;44m [��]:�U�@��,[��]:�U�@�C,[B]:�W�@��,[��][q]:���_ more        [m", (viewed * 100) / tsize, pageno + 1);
			while ((chkey = igetkey()) != EOF)
			{
				if (chkey == ' ' || chkey == KEY_RIGHT)
				{
					clear();
/*---
		    move(b_line, 0);
		    clrtoeol();
		    refresh();
*/
					i = 0;
					break;
				}
				else if (chkey == 'q' || chkey == KEY_LEFT)
				{
					move(b_line, 0);
					clrtoeol();
					refresh();
					fclose(fp);
					return 0;
				}
				else if (chkey == '\r' || chkey == '\n' || chkey == KEY_DOWN)
				{
					doscroll = YEA;	/* lasehu */
					move(b_line, 0);
					clrtoeol();
					refresh();
					i = t_lines - 2;
					break;
				}
				else if (chkey == 'b')
				{
					if (pageno >= 1 && pageno < MAXPAGE && viewed < tsize)
					{
						pageno--;
						viewed = pagebreaks[pageno];
						fseek(fp, viewed, SEEK_SET);
/*---
						move(b_line, 0);
						clrtoeol();
*/
						clear();
						i = linectr = 0;
						numbytes = readln(fp, buf);
						break;
					}
				}
/*--		bell();	*/
			}
		}
	} while (numbytes);
	fclose(fp);
#if 0
	if ((linectr > t_lines) && (save_sig + linectr > t_lines))
	{
		clear();
		prints(genbuf);
	}
#endif
#if 0
	if (tsize == 0 && promptend == NA)	/* lasehu */
		prints("\n�ɮפw���l�ο�, �L�kŪ��.");
#endif
	if (tsize != 0)		/* lasehu */
	{
		if (promptend)
			pressreturn();
		else
			prints("[m");	/* lasehu ? */
	}
	return 0;
}
