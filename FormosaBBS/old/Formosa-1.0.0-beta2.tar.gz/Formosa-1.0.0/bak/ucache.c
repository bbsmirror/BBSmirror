/*******************************************************************
 * online user_info (ULIST) shared memory
 *	put all online user_info into shared memory to speed up
 *******************************************************************/

#include "bbs.h"
#include "global.h"
#include "shm.h"


extern struct UTMPFILE *utmpshm;/* �����ϥΪ� USER_INFO ���� */

#if 0
USER_INFO *curutmp;		/* �ثe����ϥΪ� USER_INFO ���� */

#endif


void
update_utmp()
{
	register actent = (uinfo.active) - 1;

#ifdef MYDEBUG
	if (actent < 0 || actent >= MAXACTIVE)
		bbslog("DEBUG", "update_utmp() overflow");
#endif
#if 0
	memcpy(curutmp, &uinfo, sizeof(uinfo));
#endif
	memcpy((utmpshm->uinfo) + actent, &uinfo, sizeof(USER_INFO));
}


void
update_umode(mode)
int     mode;
{
	uinfo.mode = mode;
	update_utmp();
}


#if 0
void
update_umode(mode)
int     mode;
{
	curutmp->mode = mode;
}

#endif


void
purge_utmp(upent)
USER_INFO *upent;
{
	register int actent = (upent->active) - 1;

#ifdef MYDEBUG
	if (actent < 0 || actent >= MAXACTIVE)
		bbslog("DEBUG", "purge_utmp() overflow");
#endif
#if 0
	memset(upent, 0, sizeof(USER_INFO));
#endif
	memset((utmpshm->uinfo) + actent, 0, sizeof(USER_INFO));
	if (utmpshm->number)
		utmpshm->number--;
#ifdef HAVE_BUG
	if (utmpshm->number < 0)
		utmpshm->number = 0;
#endif
}


int
new_utmp()
{
	extern int errno;
	register time_t now;
	register int i;
	register pid_t pid;
	register USER_INFO *uentp;

	resolve_utmp();
	now = time(NULL) - 228;
	if (now > utmpshm->uptime)
		utmpshm->busystate = 0;

	while (utmpshm->busystate)
	{
		sleep(1);
	}
	utmpshm->busystate = 1;

/* ------------------------------- */
/* for ���F�ǻ�: �C 228 ����s�@�� */
/* ------------------------------- */

	if (now > utmpshm->uptime)
	{
		uentp = utmpshm->uinfo;
		for (i = now = errno = 0; i < USHM_SIZE; i++, uentp++)
		{
			if (pid = uentp->pid)
			{
				if ((kill(pid, 0) == -1) && (errno == ESRCH))
				{
					memset(uentp, 0, sizeof(USER_INFO));
					errno = 0;
				}
				else
					now++;
			}
		}
		utmpshm->number = now;
		time(&utmpshm->uptime);
	}

	pid = getpid();		/* lasehu */

	uentp = utmpshm->uinfo;
	for (i = 0; i < USHM_SIZE; i++, uentp++)
	{
		if (uentp->pid <= 0 || uentp->pid == pid)	/* lasehu */
		{
#if 0
			memcpy(uentp, &uinfo, sizeof(USER_INFO));	/* lasehu */
#endif
			uentp->pid = pid;
#if 0
			curutmp = uentp;
#endif
			utmpshm->number++;
			utmpshm->busystate = 0;
			return (i + 1);	/* lasehu */
		}
	}
	utmpshm->busystate = 0;
	sleep(1);
	exit(1);
}




/*******************************************************************
 * �ˬd���� login
 *******************************************************************/
#ifdef MAX_GUEST_LOGINS
int     count_guest_logins = NA;

#endif

count_multi_login(upent)
USER_INFO *upent;
{
	static int i = 0;

#if 0
	if (upent->uid == uinfo.uid)
#endif
#if 1
	if (!strcmp(upent->userid, uinfo.userid))
#endif
		{
			i++;
			if (upent->pid <= 2 || uinfo.pid <= 2)	/* lasehu */
				return -1;
			if (upent->pid != uinfo.pid)
			{
				multi++;
#ifdef MAX_GUEST_LOGINS
				if (count_guest_logins)
				{
					if (multi > MAX_GUEST_LOGINS)
					{
						fprintf(stdout, "\n��p, �������[�ί���(guest)�ϥΤH�Ƥw�B��, �бz�y��A��.\n");
						fflush(stdout);
						sleep(1);
						exit(0);
					}
					return 0;
				}
#endif
				prints("\n%d. Login PID:[%d] �Ӧ� %s �O�_�R�� (y/n) ? [n] : ", i, upent->pid, upent->from);
				if (igetkey() == 'y')
				{
					if (upent->pid > 2)	/* lasehu */
					{
						kill(upent->pid, SIGKILL);
						purge_utmp(upent);
					}
					multi--;
				}
				if (multi > MULTILOGINS)
				{
					if (!HAS_PERM(PERM_SYSOP))
					{
						fprintf(stdout, "\n���୫�� Login %d �� !!", multi);
						fflush(stdout);
						sleep(1);
						exit(0);
					}
				}
			}
		}
	return -1;
}


void
multi_user_check()
{
#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
	{
#ifdef MAX_GUEST_LOGINS
		count_guest_logins = YEA;
#else
		return;
	/* UNREACHED */
#endif
	}
#endif
	apply_ulist(count_multi_login);
}
