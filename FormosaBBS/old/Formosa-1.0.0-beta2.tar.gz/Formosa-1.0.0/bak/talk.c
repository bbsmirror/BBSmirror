
#include "bbs.h"
#include "net.h"
#include "global.h"

#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>


#include "modetype.c"


#define P_INT	(20)		/* interval to check for page requency */


char  **frdcache;
short   frdmode = NA;
int     max_friend = 0;


get_num_file_line(filename)
char   *filename;
{
	FILE   *fp;
	char    buf[100];
	int     line = 0, lastch;;

	if ((fp = fopen(filename, "r")) == NULL)
		return 0;
	while (fgets(buf, sizeof(buf), fp))
	{
		lastch = strlen(buf) - 1;
		if (buf[lastch] == '\n')
			line++;
	}
	fclose(fp);
	return line;
}


void
FriendLoadCache()		/* -ToDo- conver string compare to uid
				   compare */
{
	FILE   *fp;
	register int frds;
	char   *p;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return;
#endif

 /* init - free frdcache cache */
	if (max_friend > 0)
	{
		for (frds = 0; frds < max_friend && frdcache[frds]; frds++)
		{
			if (frdcache[frds] != NULL)
				free(frdcache[frds]);
			frdcache[frds] = NULL;
		}
		free(frdcache);
	}

	max_friend = get_num_file_line(ufile_overrides);
	frdcache = (char **) malloc(sizeof(char *) * max_friend);
	if (frdcache == NULL)
	{
		max_friend = 0;
		return;
	}

	if ((fp = fopen(ufile_overrides, "r")) == NULL)
		return;

	frds = 0;
/*---
	while (frds < max_friend && fgets(genbuf, IDLEN+2, fp))
*/
	while (frds < max_friend && fgets(genbuf, sizeof(genbuf), fp))
	{
		if ((p = strchr(genbuf, '\n')) != NULL)
			*p = '\0';
		if ((p = strchr(genbuf, ' ')) != NULL)
			*p = '\0';	/* lasehu */
		if (genbuf[0] != '\0')
		{
			frdcache[frds] = (char *) malloc(sizeof(char) * (IDLEN + 2));
			if (frdcache[frds] == NULL)
				break;
			strncpy(frdcache[frds++], genbuf, IDLEN + 1);
		}
	}
	if (frds < max_friend)	/* lasehu */
		frdcache[frds] = NULL;
	fclose(fp);
}


int
MyFriend(whoasks)		/* -ToDo- convert string compare to uid
				   compare */
char   *whoasks;
{
	register int i;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return 0;
#endif

 /* no friend cache, load it now */
	if (max_friend == 0)
		FriendLoadCache();

	for (i = 0; i < max_friend && frdcache[i]; i++)	/* lasehu */
	{
		if (!strcmp(frdcache[i], whoasks))
			return 1;
	}
	return 0;
}


int
can_override(userid, whoasks)
char   *userid;
char   *whoasks;
{
	FILE   *fp;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return 0;
#endif

	sethomefile(genbuf, userid, UFNAME_OVERRIDES);
	if ((fp = fopen(genbuf, "r")) != NULL)
	{
		char   *p;

/*---
		while (fgets(genbuf, IDLEN + 2, fp))
*/
		while (fgets(genbuf, sizeof(genbuf), fp))
		{
			if ((p = strchr(genbuf, '\n')) != NULL)
				*p = '\0';
			if ((p = strchr(genbuf, ' ')) != NULL)	/* lasehu */
				*p = '\0';
			if (!strcmp(genbuf, whoasks))
			{
				fclose(fp);
				return 1;
			}
		}
		fclose(fp);
	}
	return 0;
}


int
FriendDisplay()
{
	FILE   *fp;
	int     x = 0, y = 3, cnt = 0;
	char   *p;

	move(2, 0);
	clrtobot();
	if ((fp = fopen(ufile_overrides, "r")) != NULL)
	{
		while (fgets(genbuf, sizeof(genbuf), fp))
		{
			if (p = strchr(genbuf, ' '))	/* lasehu */
				*p = '\0';
			move(y, x);
			outs(genbuf);
			if (++y == b_line)
			{
				y = 3;
				if ((x += 16) >= 80)
				{
					pressreturn();
					x = 0;
					move(y, x);
					clrtobot();
				}
			}
			cnt++;
		}
		fclose(fp);
	}
	if (cnt == 0)
	{
		move(y, x);
		outs("(�S�H)");
	}
	return cnt;
}


FriendAdd(usrd)			/* INAPTITUDE */
char   *usrd;
{
	FILE   *fp;
	char    buf[STRLEN];

	if (!usrd || !*usrd)
		return;
	if (get_passwd(NULL, usrd) <= 0)
		return;
	if (can_override(curuser.userid, usrd))
		return;
	if ((fp = fopen(ufile_overrides, "a")) == NULL)
		return;
	fprintf(fp, "%s\n", usrd);
	fclose(fp);
#ifdef NSYSUBBS
/*
    sprintf(buf, "sort -f -o %s %s", ufile_overrides, ufile_overrides);
*/
	sprintf(buf, "sort -o %s %s", ufile_overrides, ufile_overrides);
	outdoor(buf, OVERRIDE, YEA);
#endif
	FriendLoadCache();	/* reload friends cache */
	return;
}


FriendDelete(usrd)
char   *usrd;
{
	FILE   *fp, *fpnew;
	char    fnnew[PATHLEN];
	int     deleted = NA;
	char   *p;

	sprintf(fnnew, "/tmp/%-s.overridse.new", curuser.userid);	/* lasehu ? */
	if ((fp = fopen(ufile_overrides, "r")) == NULL)
		return;
	if ((fpnew = fopen(fnnew, "w")) == NULL)
	{
		fclose(fp);
		return;
	}
	while (fgets(genbuf, sizeof(genbuf), fp))
	{
		if ((p = strchr(genbuf, '\n')) != NULL)
			*p = '\0';
		if ((p = strchr(genbuf, ' ')) != NULL)	/* lasehu */
			*p = '\0';
		if (!strcmp(genbuf, usrd))
			deleted = YEA;
		else
			fprintf(fpnew, "%s\n", genbuf);
	}
	fclose(fpnew);
	fclose(fp);
	if (deleted)
	{
		if (myrename(fnnew, ufile_overrides) == 0)
		{
			FriendLoadCache();
			return;
		}
	}
	unlink(fnnew);
}


char   *
modestring(upent, complete)
USER_INFO *upent;
int     complete;
{
	static char modestr[40];
	register int mode = upent->mode;

	if (upent->chatid && upent->chatid[0])
	{
		if (complete)
			sprintf(modestr, "%s as '%s'", ModeType(mode), upent->chatid);
		else
			return (ModeType(mode));
		return (modestr);
	}
	if (mode != TALK && mode != PAGE && mode != QUERY)
		return (ModeType(mode));
	else if (mode != QUERY && !HAS_PERM(PERM_CLOAK) && upent->invisible)
		return (ModeType(TMENU));
	if (complete && upent->destid[0] != '\0')	/* lasehu */
		sprintf(modestr, "%s '%s'", ModeType(mode), upent->destid);
	else
		return (ModeType(mode));
	return (modestr);
}


/*
 * pager-char imply whether others accept my paging
 */
char
pagerchar(userid, them, pager)
char   *userid, *them;
int     pager;
{
	if (pager)
		return ' ';
	else if (can_override(them, userid))
		return 'O';
	else
		return '*';
}

printcuent(upent)
USER_INFO *upent;
{
	int     brighten;
	static int lino;

	if (upent == NULL)
	{
		move((lino = 2), 0);
		prints("%-12s %-20s %-15s %c %c %-20s\n",
		       "�^��N�W", "����W��", "�Ӧ�", 'P',
		       HAS_PERM(PERM_CLOAK) ? 'C' : ' ', "���A");

		lino++;
		return 0;
	}
	if (lino == b_line)
	{
		int     ch;	/* ? */

		standout();
		outs("--�٦��@-- [q] or [��] : exit , [��] : ��U��");
		standend();
		while ((ch = igetkey()) != EOF)
		{
			if (ch == SP || ch == '\n' || ch == '\r' || ch == KEY_RIGHT || ch == KEY_PGDN)
				break;
			else if (ch == 'q' || ch == KEY_LEFT)
				return QUIT_LOOP;
/*--
	    else
		bell();
*/
		}
		lino = 3;
#if 1
		move(lino, 0);
		clrtobot();
		refresh();
#endif
	}
	if (upent->userid[0] == '\0')	/* lasehu */
		return 0;
	if ((brighten = MyFriend(upent->userid)) || !frdmode)
	{
		prints("%s%-12s %-20.20s %-15.15s %c %c %-20.20s[m\n",
		       (brighten && !frdmode) ? "[1;36m" : "",
		       upent->userid, upent->username, upent->from,
		     pagerchar(curuser.userid, upent->userid, upent->pager),
		       (upent->invisible) ? '#' : ' ',
		       modestring(upent, 1));
		lino++;
	}
	return 0;
}


listcuent(upent)		/* �ϥΦb namecomplete list */
USER_INFO *upent;
{
	if (upent == NULL || upent->uid == curuser.uid)
		return -1;
	if (!HAS_PERM(PERM_CLOAK) && upent->invisible)
		return -1;
	tmp_wtop = add_wlist(tmp_wtop, upent->userid, malloc_str);
	return 0;
}


int
t_users()
{
	frdmode = NA;
	printcuent(NULL);
	apply_ulist(printcuent);
	clrtobot();
	pressreturn();

	return M_FULL;
}


int
t_friends()
{
	struct stat st;

	if (stat(ufile_overrides, &st) == -1 || st.st_size == 0)
	{
		move(2, 0);
		clrtoeol();
		outs("�|���]�w�n�ͦW��");
		pressreturn();
		return M_FULL;
	}
	frdmode = YEA;
	printcuent(NULL);
	apply_ulist(printcuent);
	clrtobot();
	pressreturn();

	return M_FULL;
}


int
t_pager()
{
	uinfo.pager = (uinfo.pager) ? NA : YEA;
	if (!uinfo.in_chat)
	{
		move(2, 0);
		clrtoeol();
		prints("�O�H%s��A�͸ܤF.\n", (uinfo.pager) ? "�i�H" : "���i");
		pressreturn();
		return M_FULL;
	}
	update_utmp();

	return;
}


int
query_user(userid)
char   *userid;
{
	FILE   *planfile;
	USEREC  lpuser;
	int     savemode = uinfo.mode;
	USER_INFO *online_up;

	if (userid == NULL || userid[0] == '\0' || strchr(userid, ' '))
		return -1;
	move(1, 0);
	clrtobot();
	if (get_passwd(&lpuser, userid) <= 0)
	{
		outs(_msg_err_userid);
		pressreturn();
		return 0;
	}
#if 0
	uinfo.destuid = lpuser.uid;
#endif
	strncpy(uinfo.destid, lpuser.userid, sizeof(uinfo.destid) - 1);	/* lasehu */

	update_umode(QUERY);

	outs("�ӤH��Ƭd�ߡG\n");
	prints("%s (%s), ���� %d", lpuser.userid, lpuser.username, lpuser.userlevel);
#ifdef IDENT
	if (HAS_PERM(PERM_SYSOP))
		prints(", %s���������{�� [1;32m(�{�� %d)[m",
		       (lpuser.ident == 7) ? "[1;36m�w" : "[1;33m��", lpuser.ident);
	else
		prints(", %s���������{�� [m",
		       (lpuser.ident == 7) ? "[1;36m�w" : "[1;33m��");
#endif
	prints("\n�W�� %d ��, �i�K�L %d �g.\n", lpuser.numlogins, lpuser.numposts);
	prints("�W���ɶ� %s �Ӧ� %s",
	       (lpuser.lastlogin) ? Ctime(&(lpuser.lastlogin)) : "����",
	       (lpuser.lasthost[0] == '\0') ? "(unknown)" : lpuser.lasthost);
	prints("\n�q�l�l��H�c: %s \n", lpuser.email);
	move(6, 0);
	if (check_newmail(lpuser.userid))
		outs("---- �H�c�����s�H���٨S��.");
	else
		outs("---- �H�c�����H�󳣬ݹL�F.");
#if 0
	if (online_up = search_ulist(cmp_uid, lpuser.uid))
#endif
		if ((online_up = search_ulist(cmp_userid, lpuser.userid)))
			prints("  �u�W���A: [1;33m%s. �I��a: %s[m", modestring(online_up, 1), online_up->pager ? "�}��" : "����");
		else
			outs("  �ثe���b�u�W. ");

	sethomefile(genbuf, lpuser.userid, UFNAME_PLANS);
	if ((planfile = fopen(genbuf, "r")) != NULL)
	{
		int     i = 0;

		outs("\n�W���ɤ��e:\n\n");
		while (++i <= MAX_QUERY_LINES && fgets(genbuf, sizeof(genbuf), planfile))
			outs(genbuf);
		fclose(planfile);
	}
	else
	{
		outs("\n�S���W����.\n");
	}
	pressreturn();
#if 0
	uinfo.destuid = 0;
#endif
	uinfo.destid[0] = '\0';	/* lasehu */
	update_umode(savemode);
	return 0;
}


int
t_query()
{
	char    usrd[IDLEN + 1];

	move(2, 0);
	clrtoeol();
	outs("<�п�J�ϥΪ̥N��>");
	move(1, 0);
	clrtoeol();
	if (!getdata(1, 0, "�n�d�߽� ? ", usrd, IDLEN + 1, ECHONOSP, NULL))
		return M_FULL;

	query_user(usrd);

	return M_FULL;
}


CompleteOnlineUser(data)
char   *data;
{
	if (ask_online_user() < 2)
		return -1;

	move(1, 0);
	clrtobot();
	move(2, 0);
	outs("<�п�J�^��N�W> (���ť���i��ܨùL�o�u�W�ϥΪ�)\n");
	move(1, 0);
	outs("��H�O: ");
	apply_ulist(listcuent);
	namecomplete(tmp_wtop, NULL, data);
	tmp_wtop = free_wlist(tmp_wtop, free);
	if (data[0] == '\0')
		return -1;
	return 0;
}


int
t_talk()
{
	char    usrd[IDLEN + 1];

	if (CompleteOnlineUser(usrd) == -1)
		return M_FULL;
	talk_user(usrd);

	return M_FULL;
}


int
talk_user(usrd)
char   *usrd;
{
	USER_INFO *up;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return 0;
#endif

	if (usrd == NULL || usrd[0] == '\0')
		return 0;
	if (!strcmp(usrd, curuser.userid))
		return 0;
	if (!(up = search_ulist(cmp_userid, usrd)))
	{
		msg("���H���b�u�W");
		getkey();
		return 0;
	}
	if (!HAS_PERM(PERM_SYSOP) && !up->pager &&
	    !can_override(up->userid, curuser.userid))
	{
		msg("��西�B�󤣭㥴�Z�����A.");
		getkey();
		return 0;
	}
	if (isINOUTDOOR(up))
	{
		msg("��西�B�󤣯౵���͸ܪ����A.");
		getkey();
		return 0;
	}
	else
	{
		int     sock, msgsock, length;
		struct sockaddr_in server;
		char    reponse;

		if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		{
			perror("opening stream socket\n");
			return -1;
		}
		server.sin_family = AF_INET;
		server.sin_addr.s_addr = INADDR_ANY;
		server.sin_port = 0;
		if (bind(sock, (struct sockaddr *) & server, sizeof server) < 0)
		{
			perror("binding stream socket");
			return -1;
		}
		length = sizeof server;
		if (getsockname(sock, (struct sockaddr *) & server, &length) < 0)
		{
			perror("getting socket name");
			return -1;
		}
		if (up->pid <= 2)	/* lasehu */
			return -1;
		uinfo.sockactive = YEA;	/* ? */
		uinfo.sockaddr = server.sin_port;
#if 0
		uinfo.destuid = up->uid;	/* up is destination user */
#endif
		strncpy(uinfo.destid, up->userid, sizeof(uinfo.destid) - 1);	/* lasehu */

		uinfo.mode = PAGE;
		update_utmp();
		if (up->pid > 2)/* lasehu */
			kill(up->pid, SIGUSR1);
		else
		{
			uinfo.sockactive = YEA;	/* ? */
			uinfo.sockaddr = server.sin_port;
			uinfo.destid[0] = '\0';
			uinfo.mode = TMENU;
			update_utmp();
			return -1;
		}
		clear();
		prints("���b�� %s �n�a�o, �еy�ݤ���..\n�� CTRL-D �i�H���_\n", usrd);
		listen(sock, 1);
		add_io(sock, 20);	/* ? */
		while (1)
		{
			int     ch;

			ch = igetch();
			if (ch == I_TIMEOUT)
			{	/* ? */
				move(0, 0);
				outs("�A�n�@���a.\n");
				bell();
				if (up->pid <= 2)	/* lasehu */
				{
					outs("�ϥΪ̤w���u");
					pressreturn();
					return 0;

				}
				if (kill(up->pid, SIGUSR1) == -1)
				{
					outs("�ϥΪ̤w���u");
					pressreturn();
					return 0;
				}
			}
			else if (ch == I_OTHERDATA)
				break;
			else if (ch == '\004')
			{	/* CTRL-D */
				add_io(0, 0);
				close(sock);
				uinfo.sockactive = NA;	/* ? */
#if 0
				uinfo.destuid = 0;
#endif
				uinfo.destid[0] = '\0';	/* lasehu */
				update_utmp();
				return 0;
			}
		}
		if ((msgsock = accept(sock, (struct sockaddr *) 0, (int *) 0)) < 0)
		{
			perror("accept");
			return -1;
		}
		add_io(0, 0);	/* ? */
		close(sock);
		uinfo.sockactive = NA;	/* ? */
		strncpy(uinfo.destid, usrd, sizeof(uinfo.destid) - 1);	/* lasehu */
		read(msgsock, &reponse, sizeof reponse);
		if (reponse == 'y')
			do_talk(msgsock);
		else
		{
			clear();
			do
			{
				read(msgsock, &reponse, sizeof(reponse));
				prints("%c", reponse);
			}
			while (reponse != '\n');
			pressreturn();
		}
		close(msgsock);
#if 0
		uinfo.destuid = 0;
#endif
		uinfo.destid[0] = '\0';	/* lasehu */
		update_utmp();
	}
	return 0;
}


#if 0
int
cmp_destuid(unum, up)
register unsigned int unum;
register USER_INFO *up;
{
	return (up->active && unum == up->destuid);
}

#endif


int
cmp_destid(userid, up)
char   *userid;
register USER_INFO *up;
{
	if (up == NULL)
		return 0;
#if 0
	if (up->active <= 0)
		return 0;
#endif
	return (!strcmp(userid, up->destid));
}



USER_INFO ui;			/* partner's online info */
char    page_requestor[STRLEN];	/* partner's personal description */

int
#if 0
searchuserlist(unum)
unsigned int unum;

#endif
searchuserlist(userid)
char   *userid;
{
	register USER_INFO *up;

#if 0
	if ((up = search_ulist(cmp_destuid, unum)))
#endif
		if ((up = search_ulist(cmp_destid, userid)))
		{
			memcpy(&ui, up, sizeof(USER_INFO));
			return 1;
		}
	return 0;
}

setpagerequest()
{
#if 0
	USEREC  au;

	if (searchuserlist(curuser.uid) == 0)
#endif
		if (searchuserlist(curuser.userid) == 0)
			return 1;
	if (!ui.sockactive)
		return 1;
	strncpy(uinfo.destid, ui.userid, sizeof(uinfo.destid) - 1);	/* lasehu */
#if 0
	uinfo.destuid = ui.uid;
	get_passwd(&au, ui.userid);
	strncpy(uinfo.destid, au.userid, sizeof(uinfo.destid));
	sprintf(page_requestor, "%s (%s)", au.userid, au.username);
#endif
	sprintf(page_requestor, "%s (%s)", ui.userid, ui.username);	/* lasehu */

	return 0;
}

int
servicepage(arg)
int     arg;
{
	static time_t last_check;
	time_t  now;
	char    buf[STRLEN];

#if 0
	if (searchuserlist(curuser.uid) == 0 || !ui.sockactive)
#endif
		if (searchuserlist(curuser.userid) == 0 || !ui.sockactive)
			talkrequest = NA;
	if (!talkrequest)
	{
		if (page_requestor[0])
		{
			switch (uinfo.mode)
			{
				case TALK:
					move(arg, 0);
					prints("-----------------------------------------------------------");	/* ?? */
					prints("");
					break;
				default:	/* a chat mode */
					sprintf(buf, "** INFO: no longer paged by %s", page_requestor);
					printchatline(buf);
			}
			memset(page_requestor, 0, sizeof(page_requestor));
			last_check = 0;
		}
		return NA;
	}
	else
	{
		now = time(0);
		if (now - last_check > P_INT)
		{
			last_check = now;
			if (!page_requestor[0] && setpagerequest())
				return NA;
			switch (uinfo.mode)
			{
				case TALK:
					move(arg, 0);
					prints("--- ** �T��: %s �Q��z���", page_requestor);
					break;
				default:	/* chat */
					sprintf(buf, "** INFO: being paged by %s", page_requestor);
					printchatline(buf);
			}
		}
	}
	return YEA;
}


int
talkreply()
{
	char    ch;
	int     a;

	talkrequest = NA;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return;
#endif

	if (setpagerequest() != 0)
		return 0;
	do
	{
		clear();
		prints("�z�Q��Ӧ� %s �� %s ���� ?\n(Yes or No or Query) [Q]: ", ui.from, page_requestor);
		ch = igetkey();
		prints("%c", ch);
		if (ch != 'y' && ch != 'n')
			query_user(ui.userid);
		else
			break;
	}
	while (YEA);

	memset(page_requestor, 0, sizeof(page_requestor));

	if ((a = ConnectServer(MYHOSTIP, ui.sockaddr, TCP)) < 0)
	{
		perror("connect failed");
		pressreturn();
		return -1;
	}
	write(a, &ch, 1);
	if (ch != 'y')
	{			/* INAPTITUDE */
		char   *talkrefuse[] =
		{
			"��p, �{�b������, ��ѦA��n�� ?",
			"��p, �ݷ|�A��z��, O.K ?",
			"��p, ���M�Y�H��Ѥ�....",
			"��p, �ڪ����r�t�פӺC, �ȧA�ε�....",
			"��p, �ڤ��ӳ��w TALK �� !!",
			"�䥦",
			NULL
		};
		char    buf[STRLEN];
		int     i, maxrefused;

		clear();
		for (i = 0; talkrefuse[i]; i++)
			prints("[%d] %s\n", i + 1, talkrefuse[i]);
		maxrefused = i;
		outs("�z�n�ڧi�D�L���z�ѬO[1]:");
		i = (igetch() - '0');
		if (i < 1 || i < maxrefused)
			i = 1;
		strcpy(buf, talkrefuse[i - 1]);
		if (i == maxrefused)
			getdata(maxrefused + 2, 0, "[�z���^��]: ", buf, sizeof(buf), DOECHO, NULL);
		strcat(buf, "\n");
		write(a, buf, strlen(buf));
	}
	else
	{
		do_talk(a);
	}
	close(a);
	return 0;
}


do_talk_string(sline, eline, curln, curcol, wordbuf, wordbuflen, s)
int     sline, eline;
int    *curln, *curcol;
char   *wordbuf;
int    *wordbuflen;
char   *s;
{
	while (*s)
	{
		do_talk_char(sline, eline, curln, curcol, wordbuf, wordbuflen, *s);
		s++;
	}
}


do_talk_char(sline, eline, curln, curcol, wordbuf, wordbuflen, ch)
int     sline, eline;
int    *curln, *curcol;
char   *wordbuf;
int    *wordbuflen;
int     ch;
{
#ifdef BIT8
	if (isprint3(ch))
#else
	if (isprint(ch))
#endif
	{
		if (*curcol != 79)
		{
			wordbuf[(*wordbuflen)++] = ch;
			if (ch == ' ')
				*wordbuflen = 0;
			move(*curln, (*curcol)++);
			prints("%c", ch);
			return;
		}
		if (ch == ' ' || *wordbuflen >= 78)
		{
			(*curln)++;
			*curcol = 0;
			if (*curln > eline)
				*curln = sline;
			if ((*curln) != eline)
			{
				move((*curln) + 1, 0);
				clrtoeol();
			}
			move(*curln, *curcol);
			clrtoeol();
			*wordbuflen = 0;
			return;
		}
		move(*curln, (*curcol) - *wordbuflen);
		clrtoeol();
		(*curln)++;
		*curcol = 0;
		if (*curln > eline)
			*curln = sline;
		if ((*curln) != eline)
		{
			move((*curln) + 1, 0);
			clrtoeol();
		}
		move(*curln, *curcol);
		clrtoeol();
		wordbuf[*wordbuflen] = '\0';
		if (dumb_term)
			prints("\n");
		prints("%s%c", wordbuf, ch);
		*curcol = (*wordbuflen) + 1;
		*wordbuflen = 0;
		return;
	}
	switch (ch)
	{
		case CTRL('H'):
		case '\177':
			if (dumb_term)
				ochar(CTRL('H'));
			if (*curcol == 0)
			{
				if (sline == 0)
					bell();
				return;
			}
			(*curcol)--;
			move(*curln, *curcol);
			if (!dumb_term)
				prints(" ");
			move(*curln, *curcol);
			if (*wordbuflen)
				(*wordbuflen)--;
			return;
		case CTRL('M'):
		case CTRL('J'):
			if (dumb_term)
				prints("\n");
			(*curln)++;
			*curcol = 0;
			if (*curln > eline)
				*curln = sline;
			if ((*curln) != eline)
			{
				move((*curln) + 1, 0);
				clrtoeol();
			}
			move(*curln, *curcol);
			clrtoeol();
			*wordbuflen = 0;
			return;
		case CTRL('G'):
			bell();
			return;
#if 0
		case CTRL('X'):/* smile */
		case CTRL('Y'):/* cry */
		case CTRL('Z'):/* angry */
#endif
		default:

			break;
	}
	return;
}


unsigned char talkobuf[80];
unsigned int talkobuflen;
int     talkflushfd;

talkflush()
{
	if (talkobuflen)
		write(talkflushfd, talkobuf, talkobuflen);
	talkobuflen = 0;
}


do_talk(fd)			/* INAPTITUDE */
int     fd;
{
	USEREC  user;
	int     myln, mycol, myfirstln, mylastln;
	int     itsln, itscol, itsfirstln, itslastln;
	char    itswordbuf[80], mywordbuf[80];
	int     itswordbuflen, mywordbuflen;
	int     page_pending = NA;

	itswordbuflen = 0;
	mywordbuflen = 0;
	talkobuflen = 0;
	talkflushfd = fd;
	update_umode(TALK);

	get_passwd(&user, uinfo.destid);

	clear();
	myfirstln = 0;
	mylastln = (b_line / 2) - 1;
	move(mylastln + 1, 0);
	prints("[7m<<< �ͤ߶��� >>> �� %s and �� %s (%-20.20s)[m",
	       curuser.userid, user.userid, user.username);
	itsfirstln = mylastln + 2;
	itslastln = (t_lines - 1);
	myln = myfirstln;
	mycol = 0;
	itsln = itsfirstln;
	itscol = 0;
	move(myln, mycol);
	add_io(fd, 0);
	add_flush(talkflush);
	while (1)
	{
		int     ch;

		if (talkrequest)
			page_pending = YEA;
		if (page_pending)
			page_pending = servicepage(mylastln + 1);
#ifdef WRITEREPLY
		if (writerequest)	/* lasehu */
		{
			int     x, y;

			getyx(&y, &x);
			writereply();
			move(mylastln + 1, 0);
			prints("[7m<<< �ͤ߶��� >>> �� %s and �� %s (%-20.20s)[m",
			       curuser.userid, user.userid, user.username);
			move(y, x);
			continue;
		}
#endif
		ch = igetch();
		if (ch == I_OTHERDATA)
		{
			char    data[80];
			int     datac;
			register int i;

			datac = read(fd, data, 80);
			if (datac <= 0)
			{
#if 0
				strcpy(data, "���w���������͸�.");
				i = strlen(data) - 1;
				for (i = 0; i < datac; i++)
					do_talk_char(itsfirstln, itslastln, &itsln, &itscol, itswordbuf,
						   &itswordbuflen, data[i]);
#endif
				break;
			}
			for (i = 0; i < datac; i++)
				do_talk_char(itsfirstln, itslastln, &itsln, &itscol, itswordbuf,
					     &itswordbuflen, data[i]);
		}
		else
		{
			if (ch == CTRL('D') || ch == CTRL('C'))
			{
				int     x, y;

				getyx(&y, &x);
				move(mylastln + 1, 0);
				outs("�z�T�w�n�����͸ܶ� (y/n) ? [N]: ");
				clrtoeol();
				if (igetkey() == 'y')
					break;
				move(mylastln + 1, 0);
				prints("[7m<<< �ͤ߶��� >>> �� %s and �� %s (%-20.20s)[m",
				curuser.userid, user.userid, user.username);
				move(y, x);
			}
			else if (isprint3(ch) || ch == CTRL('H') || ch == '\177' || ch == CTRL('G')
			     || ch == '\n' || ch == '\r' || ch == CTRL('M'))
			{
				talkobuf[talkobuflen++] = ch;
				if (talkobuflen >= 80)
					talkflush();
				do_talk_char(myfirstln, mylastln, &myln, &mycol, mywordbuf,
					     &mywordbuflen, ch);
			}
			else if (ch == CTRL('P'))
			{
				if (uinfo.pager == YEA)
				{
					do_talk_string(myfirstln, mylastln, &myln, &mycol, mywordbuf, &mywordbuflen, "*** Pager turned off ***\n");
					uinfo.pager = NA;
				}
				else
				{
					do_talk_string(myfirstln, mylastln, &myln, &mycol, mywordbuf, &mywordbuflen, "*** Pager turned on ***\n");
					uinfo.pager = YEA;
				}
				update_utmp();
			}
#if 0
			else if (ch == CTRL('X') || ch == CTRL('Y') || ch == CTRL('Z'))
			{
				switch (ch)
				{
						case
				}
				talkobuf[talkobuflen++] = ch;
				if (talkobuflen >= 80)
					talkflush();
				do_talk_char(myfirstln, mylastln, &myln, &mycol, mywordbuf,
					     &mywordbuflen, ch);
			}
#endif
			else
				bell();
		}
	}
	add_io(0, 0);
	talkflush();
	add_flush(NULL);
}


int
t_irc()
{
	sprintf(genbuf, "ircc %s %s %d",
		curuser.userid, curuser.lasthost, two_enter);
	outdoor(genbuf, IRCCHAT, YEA);	/* ? */

	return M_FULL;
}


#ifdef USE_LOCALIRC
int
t_ircl()
{
	sprintf(genbuf, "ircl %s %s %d chat5",
		curuser.userid, curuser.lasthost, two_enter);
	outdoor(genbuf, LOCALIRC, YEA);	/* ? */

	return M_FULL;
}

#endif


int
message_user(upent)
USER_INFO *upent;
{
	char    buf[80];
	FILE   *fp;
	struct stat st;
	time_t  now = time(0);
	int     lines = 0;
	char    timestr[8];

	if (upent->userid == NULL || upent->userid[0] == '\0')
		return -1;

	gethomefile(buf, upent->userid, UFNAME_WRITE);
	if (stat(buf, &st) == 0)
	{
		lines = 1;
		if (st.st_mtime < now - 86400 || st.st_size > 2048)	/* lasehu */
		{
#ifdef DEBUG
			prints("\nunlink [%s]", buf);
			getkey();
#endif
			unlink(buf);
		}
	}
	if ((fp = fopen(buf, "a+")) == NULL)
		return -1;

	strncpy(uinfo.destid, upent->userid, sizeof(uinfo.destid) - 1);	/* lasehu */
#if 0
	uinfo.destuid = upent->uid;
#endif
	update_utmp();		/* lasehu */
#if 0
	sprintf(buf, "%s(%-20.20s", curuser.userid, curuser.username);
	buf[68 - strlen(callin_smesg)] = '\0';	/* lasehu */
	space_len = 68 - strlen(buf) - strlen(callin_smesg);
	while (space_len-- > 0)
		strcat(callin_smesg, " ");
	fprintf(fp, "[1;33;45mFrom %s) :[36m %s [m", buf, callin_smesg);
#endif
	if (lines)		/* lasehu */
		fprintf(fp, "\n");
	strftime(timestr, 6, "%R", localtime(&now));
	fprintf(fp, "%s\t%-1s\t%s\t%s",
		curuser.userid, curuser.username, callin_smesg, timestr);
	fclose(fp);
	if (upent->pid > 2)	/* lasehu */
		kill(upent->pid, SIGUSR2);
	uinfo.destid[0] = '\0';	/* lasehu */
#if 0
	uinfo.destuid = 0;
#endif
	update_utmp();
	return 0;
}


char   *
parse_msgstr(s)
char   *s;
{
	char   *timestr, *id, *name, *rmsg, *p;
	char    buf[80], spaces[80];
	static char showmsg[120];
	int     space_len;

	if ((id = strtok(s, "\t")) == NULL)
		return NULL;
	if ((name = strtok(NULL, "\t")) == NULL)
		return NULL;
	if ((rmsg = strtok(NULL, "\t")) == NULL)
		return NULL;
	if ((timestr = strtok(NULL, "\t")) == NULL)
		return NULL;
	if ((p = strchr(timestr, '\n')))
		*p = '\0';
	strcpy(buf, id);
	strcat(buf, "(");
	strncat(buf, name, UNAMELEN - 1);
	strcat(buf, ")");
	space_len = 70 - strlen(buf) - strlen(rmsg);
	spaces[0] = '\0';
	while (space_len-- > 0)
		strcat(spaces, " ");
	sprintf(showmsg, "[1;37;45m%s [33m%s:[36m %s%s[m", timestr, buf, rmsg, spaces);

	return showmsg;
}


char   *
get_msgfrom(s)
char   *s;
{
	char   *id;
	static char showid[80];

	if ((id = strtok(s, "\t")) == NULL)
		return NULL;
	strcpy(showid, id);

	return showid;
}


int
prepare_message()
{
	if (ask_online_user() < 2)
		return -1;
	clear();
	if (getdata(1, 0, "�T�����e�O: ", callin_smesg, sizeof(callin_smesg), DOECHO, NULL))
	{
		outs("\n�T�w�n�e�X�T���� (y/n) ? [y]: ");
		if (igetkey() != 'n')
			return 0;
	}
	outs(_msg_abort);
	pressreturn();
	return -1;
}


int
do_message(usrd)
char   *usrd;
{
	USER_INFO *up;

	if (!(up = search_ulist(cmp_userid, usrd))
	    || (!HAS_PERM(PERM_CLOAK) && up->invisible))
	{
		outs("\n���H���b�u�W");
		pressreturn();
		return -1;
	}
	if (!HAS_PERM(PERM_SYSOP) && !up->pager &&
	    !can_override(up->userid, curuser.userid))
	{
		outs("\n��西�B�󤣭㥴�Z�����A.");
		pressreturn();
		return -1;
	}
	if (isINOUTDOOR(up))
	{
		outs("\n��西�B�󤣯౵���e�T�������A.");
		pressreturn();
		return -1;
	}

	if (message_user(up) == -1)
	{
		outs("\n�e�X�T������");
		pressreturn();
		return -1;
	}
	outs("\n�e�X�T������");
	pressreturn();
	return 0;
}


#ifdef WRITEREPLY
int
writereply()			/* lasehu */
{
	FILE   *fp;

	writerequest = NA;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return -1;
#endif

	if (fp = fopen(ufile_write, "r"))
	{
		char   *p, callin_rmesg[120], *id, ch;

		while (fgets(callin_rmesg, sizeof(callin_rmesg), fp))
			 /* NULL STATEMENT */ ;
		if (!(p = parse_msgstr(callin_rmesg)) ||
		    !(id = get_msgfrom(callin_rmesg)))
		{
			fclose(fp);
			return -1;
		}
		fclose(fp);
#if 0
		unlink(ufile_write);
#endif
/*
	msg(callin_rmesg);
*/
		msg(p);
		move(b_line - 1, 0);	/* avoid screen scroll */
		clrtoeol();
		outs("�� [Ctrl]+[R] �i�^�T��, �Ϋ� ENTER ���^.");
		warn_bell();
		while ((ch = getkey()) != EOF)
		{
			if (ch == CTRL('R'))
			{
				if (prepare_message() == -1)
					return -1;
				do_message(id);
				break;
			}
			else if (ch == '\r' || ch == '\n')
				break;
		}
	}
	return 0;
}

#endif


int
t_review()
{
	FILE   *fp;
	int     lines = 0;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return M_FULL;
#endif

	clear();
	outs("[7m  �����W�u�z�Ҧ��쪺�Ҧ��T��:  [m\n");
	if (fp = fopen(ufile_write, "r"))
	{
		char   *p, callin_rmesg[120];

		while (fgets(callin_rmesg, sizeof(callin_rmesg), fp))
		{
			if (!(p = parse_msgstr(callin_rmesg)))
				break;
			lines++;
			if ((lines % b_line) == b_line - 1)
			{
				standout();
				outs("--�٦��@-- �Ы����N����U��");
				standend();
				getkey();
				move(1, 0);
				clrtobot();
			}
			prints("%s\n", p);
		}
		fclose(fp);
	}
	if (lines == 0)
		outs("�ثe�S���u�W�T���i�^�U\n");
	pressreturn();
	return M_FULL;
}


int
t_message()
{
	char    usrd[IDLEN + 1];

	if (CompleteOnlineUser(usrd) == -1)
		return M_FULL;
	if (prepare_message() == -1)
		return M_FULL;
	do_message(usrd);
	return M_FULL;
}


#ifdef HAVE_FRIEND_BROADCAST
int
brodcast_friends(upent)
USER_INFO *upent;
{
#ifdef GUEST_ACCOUNT
	if (!strcmp(upent->userid, GUEST_ACCOUNT))
		return -1;
#endif
	if (upent->uid == curuser.uid)
		return -1;
	if (!HAS_PERM(PERM_CLOAK) && upent->invisible)
		return -1;
	if (!HAS_PERM(PERM_SYSOP) && !upent->pager
	    && !can_override(upent->userid, curuser.userid))
	{
		return -1;
	}
	if (isINOUTDOOR(upent))
		return -1;
	if (MyFriend(upent->userid))
		message_user(upent);
	return 0;
}


int
t_fsendmsg()
{
	if (prepare_message() == -1)
		return M_FULL;
	apply_ulist(brodcast_friends);
	outs("\n�T���w�e�X");
	pressreturn();
	return M_FULL;
}

#endif
