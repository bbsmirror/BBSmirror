
#include "bbs.h"
#include "global.h"


int     mailx_send(), mailx_help();

struct one_key mail_comms[] =
{
	CTRL('P'), mailx_send,
	'h', mailx_help,
	'm', mail_article,
	'd', del_article,
	'E', edit_article,
	'i', title_article,
	'T', batch_del_article,
	'g', reserve_article,
	'\0', NULL
};


/*
 * �H�H�ܯ���
 */
bbs_localmail(fname, to, title)
char   *fname, *to, *title;
{
	USEREC  urcbuf;

	if (get_passwd(&urcbuf, to) <= 0)
/* lasehu
   msg("�ϥΪ̥N�����~");
 */
		return -1;

/* lasehu: Auto-Forward */
	if ((urcbuf.flags[0] & FORWARD_FLAG) && !invalid_email(urcbuf.email))
	{
		msg("[%s] �w�ҰʭӤH�H��N�� ... �Ы����N��.", to);
		getkey();
		msg("�N�H����e [%s], ��H�� ...", urcbuf.email);
		if (bbs_inetmail(0, fname, NULL, urcbuf.email, title, YEA) == 0)
		{
#ifdef NOT_REAL_AUTOFORWARD
			bbs_save_localmail(fname, to, title);
			msg("��e����, �åB�t�����@�ʦs�b [%s] �H�c��", to);
			getkey();
#endif
			return 0;
		}
		msg("��e����. �H����s [%s] �H�c�� ... �Ы����N��", to);
		getkey();
	}

	return bbs_save_localmail(fname, to, title);
}


int
bbs_save_localmail(fname, to, title)
char   *fname, *to, *title;
{
	char    path[PATHLEN];

	setmailfile(path, to, NULL);
	if (!dashd(path))
	{
		if (mkdir(path, 0700) == -1)
			return -1;
	}
	if (append_article(fname, path, curuser.userid, title, curuser.ident, NULL, NA) == -1)
		return -1;
	return 0;
}


/*
 * �H�H�ܯ��~
 */
bbs_inetmail(ms, fname, uuname, to, title, ask)
int     ms;
char   *uuname;
char   *fname, *to, *title;
int     ask;
{
	int     new_ms;
	char    new_file[PATHLEN];
	int     foo;

#ifdef EMAIL_LIMIT
	if (curuser.ident != 7)
	{
		prints("\n");
		outs(_msg_sorry_email);
		clrtoeol();
		getkey();
		return -1;
	}
#endif
	if (ms > 0)
		new_ms = ms;
	else
	{
		if ((new_ms = create_mail_socket()) < 0)
		{
/* lasehu
   msg("�s�� Mail Server ����");
   getkey();
 */
#ifdef MYDEBUG
			bbslog("ERROR", "Connect MailServer Failed");
#endif
			return -1;
		}
	}

	if (uuname && uuname[0])
		strcpy(new_file, uuname);
	else
	{
		strcpy(new_file, fname);
		if (ask)
		{
			msg("�H�쯸�~���H�n�s�X(uuencode)�� (y/n) ? [n]: ");
			if (igetkey() == 'y')
				uuencode_file(fname, new_file);
		}
	}

	if (telnet_mail(new_ms, new_file, curuser.userid, to, title) == -1)
		foo = -1;
	else
		foo = 0;
	if (ms <= 0)
		close_mail_socket(new_ms);
#if 0
	if (!uuname)
		unlink(new_file);
#endif
	return foo;
}


prepare_mail(srcfile, to, title)/* lasehu */
char   *srcfile;
char   *to, *title;
{
	int     save_mmode = in_mail, save_umode = uinfo.mode, foo;

#ifdef GUEST_ACCOUNT
	if (!strcmp(curuser.userid, GUEST_ACCOUNT))
		return -1;
#endif

	if (do_article_to(to) == -1)
		return -1;

	if (is_inetmail(to))
	{
#ifdef EMAIL_LIMIT
		if (curuser.ident != 7)
		{
			prints("\n");
			outs(_msg_sorry_email);
			getkey();
			return -1;
		}
#endif
	}
	else if (get_passwd(NULL, to) <= 0)
	{
		prints("\n�ϥΪ̥N�� [%s] ���~.", to);
		getkey();
		return -1;
	}

	if (do_article_title(title) == -1)
		return -1;

	if (srcfile)
		include_ori(srcfile, tempfile);
	include_sig(curuser.userid, tempfile);

	update_umode(SMAIL);
	in_mail = 1;		/* lasehu */

	if (vedit(tempfile, title))
	{
		in_mail = save_mmode;
		unlink(tempfile);
		update_umode(save_umode);
		return -1;
	}

	in_mail = save_mmode;

/* lasehu
   if (mg)
   {
   foo = mail_group(tempfile, title);
   }
    else */
	if (is_inetmail(to))
		foo = bbs_inetmail(0, tempfile, NULL, to, title, YEA);
	else
		foo = bbs_localmail(tempfile, to, title);

	unlink(tempfile);
	update_umode(save_umode);
	return foo;
}


/*
 * �^�H
 */
reply_mail(finfo, direct)
FILEHEADER *finfo;
char   *direct;
{
	char    to[STRLEN], title[STRLEN], srcfile[STRLEN];

	clear();

	strcpy(to, (finfo->owner[0] == '#') ? (finfo->owner + 1) : (finfo->owner));
	strcpy(title, finfo->title);

	setdotfile(srcfile, direct, finfo->filename);

	if (prepare_mail(srcfile, to, title) == -1)
		outs("�H�H����");
	else
		outs("�H�H����");

	pressreturn();
	return R_FULL;
}


/*
 * �ˬd�ӤH�H�c Mail �ƶq
 */
check_mail_num()
{
	int     cnt;

	cnt = get_num_records(maildirect, FH_SIZE);
	if (cnt > maxkeepmail && ever_del_mail)
	{
		int     fd;

		if ((fd = open(maildirect, O_RDONLY)) > 0)
		{
			while (read(fd, &tmp_fh, sizeof(tmp_fh)) == sizeof(tmp_fh))
				if ((tmp_fh.accessed & FILE_DELE))
					cnt--;
			close(fd);
		}
	}
	if (cnt > maxkeepmail && !HAS_PERM(PERM_SYSOP))
	{
		clear();
		prints("\n�ثe�H�c���� [1m%d[m �ʫH��, �w�g�W�L����.", cnt);
		prints("\n�]���L�kŪ�s�H, �бN�H��q�R�� [1m%d[m �ʦA���}", maxkeepmail);
		prints("\n�_�h�U���z���s���H���F��, �N�L�k�s�J�H�c��.[m");
		pressreturn();
		return 1;
	}
	return 0;
}


/*
 * �H�H
 */
m_send()
{
	char    to[STRLEN], title[STRLEN];
	int     foo;

	clear();

	to[0] = (title[0] = '\0');

	foo = prepare_mail(NULL, to, title);
	move(b_line - 1, 0);
	clrtoeol();
	if (foo == -1)
		outs("�H�H����");
	else
		outs("�H�H����");

	in_mail = 0;

	pressreturn();
	return M_FULL;
}


/*******************************************************************
 * �uŪ�s���H
 *******************************************************************/
m_new()
{
	int     fd, ent = 0;

	do
	{
		if ((fd = open(maildirect, O_RDWR)) < 0)
			return M_FULL;
		update_umode(RMAIL);
		while (read(fd, &tmp_fh, sizeof(tmp_fh)) == sizeof(tmp_fh))
		{
			if (++ent > maxkeepmail && !HAS_PERM(PERM_SYSOP))
			{
				clear();
				outs("�H�c�w��, �|���H��Ū!");
				pressreturn();
				close(fd);
				return M_FULL;
			}
			if (tmp_fh.accessed & FILE_READ)
				continue;
			clear();
			prints("�H�H�H : %s\n���D : %s\n�z�QŪ���H�󤺮e�� ? (y/n) [y] : ", (tmp_fh.owner[0] == '#') ? (tmp_fh.owner + 1) : (tmp_fh.owner), tmp_fh.title);
			if (igetkey() == 'n')
				continue;
			setdotfile(genbuf, maildirect, tmp_fh.filename);
			more(genbuf, NA);
			tmp_fh.accessed |= FILE_READ;
			if (lseek(fd, -((off_t) FH_SIZE), SEEK_CUR) != -1)
				write(fd, &tmp_fh, FH_SIZE);
			msg("<<Ū�s�H>> (r)�^�H (d)�R�� (n)�U�@�� (e)���}? [n] : ");
			switch (igetkey())
			{
				case 'r':
					reply_mail(&tmp_fh, maildirect);
					break;
				case 'd':
					tmp_fh.accessed |= FILE_DELE;
					if (lseek(fd, -((off_t) FH_SIZE), SEEK_CUR) != -1)
						write(fd, &tmp_fh, FH_SIZE);
					break;
				case 'e':
					close(fd);
					return M_FULL;
				case 'n':
				default:
					break;
			}
		}
		close(fd);
		move(2, 0);
		clrtobot();
		outs("�S���s�H�F !!");
		pressreturn();
	}
	while (check_mail_num());

	return M_FULL;
}


/*******************************************************************
 * Read Mail Menu �ӤH�H�c  �C���\Ū
 *******************************************************************/
m_read()
{
	do
	{
		in_mail = 1;	/* lasehu ? */
		i_read(maildirect, &mail_comms[0], IREAD_MAIL);
	}
	while (check_mail_num());
	in_mail = 0;

	return M_FULL;
}


int
check_fwd_emailaddr(addr)
char   *addr;
{
	if (addr[0] == '\0')
	{
		outs("\n�Х��ק�ӤH��Ƥ� e-mail ���.\n");
		outs("\n��W�z�n��H����}, �~��Ұʦ��]�w\n");
		outs("\n�Ҧp: \n   myuserid@hostName.domain.zone");
	}
#ifdef NSYSUBBS
	else if (strstr(addr, "bbs.nsysu.edu.tw") ||
		 strstr(addr, "bbs2.nsysu.edu.tw") ||
		 strstr(addr, "bbs3.nsysu.edu.tw"))
	{
		outs("\n�Y�n�ϥΦ۰���H�A��, �ӤH��� e-mail ���ФŶ�g���sBBS��");
	}
#endif
/*
	else if (strstr(addr, MYHOSTNAME) || strstr(addr, MYHOSTIP))
*/
	else if (strstr(addr, MYHOSTNAME))
	{
		outs("\n�ӤH��� e-mail ���]�w���~, �Ŷ�g������}, �Э��s�]�w.");
	}
	else
		return 0;
	return -1;
}


/*
 * �]�w Auto-forward �ӤH�H��۰���H�A�ȿﶵ
 */
m_forward()
{
	move(2, 0);
	clrtoeol();
	if (HAS_FLAG(FORWARD_FLAG))
	{
		outs("�����۰���H");
		UNSET_FLAG(FORWARD_FLAG);
	}
	else
	{
		if (check_fwd_emailaddr(curuser.email) != -1)
		{
			SET_FLAG(FORWARD_FLAG);
			prints("\n�H��z���H��N�۰���H�� [%s].\n", curuser.email);
			prints("\n�Y�n�ק���H�ت��a, �Эק�ӤH��Ƥ� e-mail ���.");
			update_user(&curuser);	/* lasehu */
		}
	}
	pressreturn();
	return M_FULL;
}


/*
   m_fix()
   {
   sprintf(genbuf,"gbmail -m %s",curuser.userid);
   outdoor(genbuf, UNDEFINE, YEA);

   return M_FULL;
   }
 */


/*******************************************************************
 * �ˬd�H�c���L�s�H
 *******************************************************************/
check_newmail(name)
char   *name;
{
	static long lasttime = 0;
	static  ismail = 0;
	struct stat st;
	int     fd;
	register long numfiles;
	char    fname[PATHLEN];
	int     oismail = 0, isme = 0;

	if (!strcmp(name, curuser.userid))
		isme = 1;
	setmailfile(fname, name, DIR_REC);
	if (stat(fname, &st) == -1)
		return ((isme) ? (ismail = 0) : (oismail = 0));
	if (isme)
	{
		if (lasttime >= st.st_mtime)
			return ismail;
		lasttime = st.st_mtime;
	}
	numfiles = st.st_size / FH_SIZE;
	if (numfiles <= 0)
		return ((isme) ? (ismail = 0) : (oismail = 0));
	if ((fd = open(fname, O_RDONLY)) > 0)
	{
		lseek(fd, (off_t) (st.st_size - FH_SIZE), SEEK_SET);
		while (numfiles--)
		{
			read(fd, &tmp_fh, sizeof(tmp_fh));
			if (!(tmp_fh.accessed & FILE_READ) && !(tmp_fh.accessed & FILE_DELE))
			{
				close(fd);
				return ((isme) ? (ismail = 1) : (oismail = 1));
			}
			lseek(fd, -2 * ((off_t) FH_SIZE), SEEK_CUR);
		}
		close(fd);
	}
	return ((isme) ? (ismail = 0) : (oismail = 0));
}


/*
 *  �H�H
 */
mailx_send(ent, finfo, direct)
int     ent;			/* unused */
FILEHEADER *finfo;		/* unused */
char   *direct;			/* unused */
{
	int     savemode = uinfo.mode;

	m_send();
	uinfo.mode = savemode;

	return R_FULL;
}


/*
 * Read Mail Menu �� Help
 */
mailx_help()
{
	more(MAIL_HELP, YEA);
	return R_FULL;
}
