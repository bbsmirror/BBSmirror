
#include "net.h"

int ConnectServer(host, port, type)
char *host;
int port;
char type;
{
	struct sockaddr_in sin;
	int s;

	if(!host || !(*host))
		return -1;
	memset(&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_port = port;

	/* check host is ip address or hostname */
	if(*host < '0' || *host > '9')
	{
		struct hostent *phe;

		if(phe = gethostbyname(host))
			memcpy((char *)&sin.sin_addr, phe->h_addr, phe->h_length);
		else
			return -1;
	}
	else
		sin.sin_addr.s_addr = inet_addr(host);

	/* alloc a socket */
	if((s = socket(PF_INET, (type==TCP)?SOCK_STREAM:SOCK_DGRAM, 0)) < 0)
		return -1;

	/* connect the socket to server port */
	if(connect(s, (struct sockaddr *)&sin, sizeof(sin)) < 0)
		return -1;
	else
		return s;
}



