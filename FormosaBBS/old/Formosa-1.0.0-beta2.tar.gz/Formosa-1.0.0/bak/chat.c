
#include "bbs.h"
#include "global.h"
#include "chat.h"

#ifdef lint
#include <sys/uio.h>
#endif
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>


int     chatline;

#define ECHATWIN	(t_lines - 2)
#define PLINE		(t_lines - 1)

#define BADCIDCHARS " %*$`\"\\;:|[{]},./?=~!@#^()<>"
/*
   #define CHAT_LIMIT1 40
 */

char    MyChanname[CHANLEN];


fixchatid(chatid)
unsigned char *chatid;
{
	char   *p;

	if ((p = strstr(chatid, "�@")))	/* lasehu */
		memcpy(p, "__", 2);
	while (*chatid)
	{
/* lasehu
	if (*chatid == '\n' || *chatid <= 32)
*/
		if (*chatid == '\n')
			break;
/*
	if (strchr(BADCIDCHARS, *chatid))
	    *chatid = '_';
*/
		chatid++;
	}
}


int     ac;
char    chatid[STRLEN];


#define CHATIDLEN	(8)
#define SAYWORD_POINT	(10)

t_chat()
{
/*---
	char    hostname[STRLEN];
*/
	char   *colon;
	int     currchar;
	char    inbuf[80];
	int     page_pending = NA;
	int     ch;
	char    seed[STRLEN];

/*
   int    shutup = 0;
 */

	inbuf[0] = '\0';
	currchar = 0;
	chatline = 0;		/* initialize */

#if 0
/* lasehu */
	getuserfile(genbuf, "ignore");
	if (dashf(genbuf))
	{
		clear();
		outs("\n�z�w�O ChatRoom �ڵ����Ӥ�!!");
		pressreturn();
		return M_FULL;
	}
#endif

	strcpy(MyChanname, DEF_CHANNAME);	/* lasehu */

	if (!getdata(1, 0, "Enter Chat id: ", chatid, CHATIDLEN, ECHONOSP, NULL))
		strncpy(chatid, curuser.userid, CHATIDLEN);
	chatid[CHATIDLEN] = '\0';
	fixchatid(chatid);
/* ? */
	strcat(chatid, ":                      ");
	chatid[SAYWORD_POINT] = '\0';
	strcpy(inbuf, chatid);
/* ... */
/* lmj
	gethostname(hostname, STRLEN);
	if (!(h = gethostbyname(hostname)))
	{
		perror("gethostbyname");
		pressreturn();
		return M_FULL;
	}
	memset(&sin, 0, sizeof sin);
	sin.sin_family = h->h_addrtype;
	sin.sin_addr.s_addr = inet_addr(MYHOSTIP);
	sin.sin_port = CHATPORT;
	ac = socket(sin.sin_family, SOCK_STREAM, 0);
*/
	if ((ac = ConnectServer(MYHOSTIP, CHATPORT, TCP)) < 0)
	{
		perror("connect failed");
		pressreturn();
		return M_FULL;
	}

/* lasehu */
	net_gets(ac, genbuf, sizeof(genbuf));	/* receive ChatServer Hello
						   Welcome VersionInfo */
	net_gets(ac, seed, sizeof(seed));	/* receive Random Number for
						   Checksum */
	net_printf(ac, "USRID\t%s\t%s\r\n", curuser.userid, mycrypt(seed));
	net_gets(ac, genbuf, sizeof(genbuf));
	strncpy(genbuf, chatid, CHATIDLEN);
	genbuf[CHATIDLEN] = '\0';
/* lasehu */
	{
		char   *foo;

		strcpy(genbuf, chatid);
		genbuf[CHATIDLEN] = '\0';
		if ((foo = strchr(genbuf, ':')))
			*foo = '\0';
	}
	net_printf(ac, "NICKNAME\t%s\r\n", genbuf);
	net_gets(ac, genbuf, sizeof(genbuf));
#if 0
	net_printf(ac, "JOIN\tFormosa\r\n");	/* Join Default ChatChannel */
	net_gets(ac, genbuf, sizeof(genbuf));
#endif
	uinfo.mode = CHATROOM;
	uinfo.in_chat = YEA;
/* ? */
	strncpy(uinfo.chatid, chatid, SAYWORD_POINT);
	if (colon = strrchr(uinfo.chatid, ':'))
		*colon = '\0';
/* ... */
/* lasehu new
   strncpy(uinfo.chatid, chatid, sizeof(uinfo.chatid));
   uinfo.chatid[sizeof(uinfo.chatid) - 1] = '\0';
 */
	update_utmp();

/*
   if (uinfo.invisible)
   {
   if (curuser.userlevel == 255)
   sprintf(inbuf, "/sysopin %s", uinfo.chatid);
   else
   sprintf(inbuf, "/cloakin %s", uinfo.chatid);
   }
   else
   {
   net_printf(ac, "SPEAK\t%s\r\n", inbuf);
   }
 */
	clear();
	printchatline("�� /help �i�ݨϥλ���");
	printchatline("  ");
	move(ECHATWIN, 0);
	prints("--------------------------------------------------------------------------------");
	move(PLINE, 0);
	strcpy(inbuf, chatid);
	if (!dumb_term)
		prints("%s", chatid);
	currchar = strlen(inbuf);
	add_io(ac, 0);
/* Chat Main */
	while (1)
	{
#ifdef WRITEREPLY
		if (writerequest)
		{
			writereply();
			continue;
		}
#endif
		ch = getkey();
#if 0
		if (ch > 0x100)
		{		/* lasehu */
			bell();
			bell();
			continue;
		}
#endif
		if (talkrequest)
			page_pending = YEA;
		if (page_pending)
			page_pending = servicepage(0);
/*
   if (!shutup)
   {
   sprintf(genbuf, "ignore/%s", curuser.userid);
   if (dashf(genbuf))
   shutup = YEA;
   }
   if (shutup)
   break;
 */
		if (ch == I_OTHERDATA)
		{		/* ? */
			if (!net_gets(ac, genbuf, sizeof(genbuf)))
				break;
			printchatline(genbuf);
/*
   static char buf[512];
   static int bufstart = 0;
   int c, len;
   char *bptr;

   len = sizeof(buf) - bufstart - 1;
   if ((c = read(ac, buf + bufstart, len)) <= 0)
   break;
   c += bufstart;
   bptr = buf;
   while (c > 0)
   {
   len = strlen(bptr) + 1;
   if (len > c && len < (sizeof buf / 2))
   break;

   printchatline(bptr);

   c -= len;
   bptr += len;
   }

   if (c > 0)
   {
   strcpy(genbuf, bptr);
   strcpy(buf, genbuf);
   bufstart = len - 1;
   }
   else
   bufstart = 0;
   continue;
 */
		}
		else if (isprint2(ch))
		{
			if (currchar == 78)
			{	/* ? */
				bell();
				continue;
			}
			inbuf[currchar++] = ch;
			inbuf[currchar] = '\0';
			move(PLINE, currchar - 1);
			prints("%c", ch);
		}
		else if (ch == '\n' || ch == '\r')
		{
			int     i, j;
			char    no_spcs[80];

			if (dumb_term)
				prints("\n");
			for (i = SAYWORD_POINT, j = 0; i < STRLEN; i++)
			{
				if (inbuf[i] == '\0')
				{
					no_spcs[j] = '\0';
					break;
				}
				if (inbuf[i] != ' ')
					no_spcs[j++] = inbuf[i];
			}
			if (no_spcs[0] == '\0')
				continue;
			if (inbuf[SAYWORD_POINT] == '/')
			{	/* ? */
				int     action = dochatcommand(&inbuf[SAYWORD_POINT + 1]);

				if (action == 1)
				{
					strcpy(chatid, uinfo.chatid);
					chatid[CHATIDLEN] = '\0';
					strcat(chatid, ":                      ");	/* ? */
					chatid[SAYWORD_POINT] = '\0';
				}
				else if (action == -1)
					break;
			}
			else
			{
				net_printf(ac, "SPEAK\t%s\r\n", inbuf + SAYWORD_POINT);
			}

			strcpy(inbuf, chatid);
			currchar = strlen(chatid);
			if (!dumb_term)
			{
				move(PLINE, 0);
				outs(inbuf);
			}
			else
			/* ? */
			{
				move(PLINE, 0);
				clrtoeol();
			}
			move(23, 10);
			clrtoeol();
		}
		else if (ch == CTRL('H') || ch == '\177')
		{
			if (currchar == SAYWORD_POINT)
			{
				bell();
				continue;
			}
			move(PLINE, --currchar);
			if (dumb_term)
				ochar(CTRL('H'));
			else
				prints(" ");
			inbuf[currchar] = '\0';
		}
		else if (ch == CTRL('C') || ch == CTRL('D'))
		{
/* lasehu
   if (uinfo.invisible)
   {
   if (HAS_PERM(PERM_SYSOP))
   sprintf(inbuf, "/sysopout %s", uinfo.chatid);
   else
   sprintf(inbuf, "/cloakout %s", uinfo.chatid);
   }
   else
   net_printf(ac, "SPEAK\t%s\r\n", inbuf);
 */
			break;
		}
		move(PLINE, currchar);
	}
	add_io(0, 0);
	close(ac);
	uinfo.in_chat = NA;
	uinfo.chatid[0] = '\0';
	update_utmp();

	return M_FULL;
}

printchatline(str)
char   *str;
{
	move(chatline++, 0);
	clrtoeol();
/* lasehu
   prints("%s\n", str);
 */
	outs(str);
	if (chatline == ECHATWIN)
		chatline = 0;
	move(chatline, 0);
	clrtoeol();
	standout();
	if (!dumb_term)
		prints("-->");
	standend();
	return 0;
}

/*---
int
get_repsno(reps)
char   *reps;
{
	int     i;
	char    nos[10];

	for (i = 0; reps[i] != '\0' && reps[i] != '\t' && reps[i] != '\r'; i++)
		nos[i] = reps[i];
	return atoi(nos);
}
*/

char   *
GetPass(str, token, maxlen)
char   *str;
char   *token;
int     maxlen;
{
	int     i = 0, j;
	char   *tmp;

	memset(token, 0, PROTOLEN);
	while (strchr(KEYWORD_DELIMITER, str[i]))
	{			/* �h���e�����ť� */
		if (str[i] == '\0')
		{
			token[0] = '\0';
			return &str[i];
		}
		i++;
	}
	tmp = &str[i];
	j = 1;
	while (!strchr(KEYWORD_SEPARATE, tmp[j]))	/* �Htab�����j�A��X�Ѽ� */
		j++;

	if (j >= maxlen)
	{			/* token too large */
/* del by lasehu
   token[0] = '\0';
 */
		j = maxlen - 1;	/* lasehu */
	}
/* del by lasehu
   else
   {
 */
	strncpy(token, tmp, j);
	token[j] = '\0';	/* important */
/*
   }
 */
	return &tmp[j];
}


int
GetRespNo(str)
char   *str;
{
	char    keypass[PROTOLEN];

	GetPass(str, keypass, PROTOLEN);
	return atoi(keypass);
}

char   *
PhaseSpace(str)
char   *str;
{
	int     i, j = 0;

	if (!str[0])
		return str;
	while (strchr(KEYWORD_DELIMITER, str[j]))
		j++;

	i = strlen(str) - 1;
	while (i >= 0 && strchr(" \t\r\n", str[i]))
		i--;
	str[i + 1] = '\0';


	return &str[j];
}



dowho(channame, fd)
char   *channame;
int     fd;
{
	char    buf[80];
	char    chatid[80], userid[80], fromip[80];
	int     cnt = 0;
	char    uline[80], pline[30];

	channame = PhaseSpace(channame);
	if (*channame)
		net_printf(fd, "WHO\t%s\r\n", channame);
	else
		net_printf(fd, "WHO\t%s\r\n", MyChanname);	/* lasehu */

	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) != OK_CMD)
		return -1;

	printchatline(" ");
	printchatline("*** �{�b�o�̪��ȤH ***");
	sprintf(buf, "%-10s  %-12s   %-10s  %-12s   %-10s  %-12s",
		"�︹", "�N�W", "�︹", "�N�W", "�︹", "�N�W");
	printchatline(buf);
	sprintf(buf, "%-10s  %-12s   %-10s  %-12s   %-10s  %-12s",
		"------", "------", "------", "------", "------", "------");
	printchatline(buf);

	memset(uline, 0, sizeof(uline));
	do
	{
		net_gets(fd, buf, sizeof(buf));
		if (buf[0] == '.')
			break;
		sscanf(buf, "%s\t%s\t%s\r\n", userid, chatid, fromip);
		sprintf(pline, "%-10s  %-12s", chatid, userid);
		if (cnt < 2)
			strcat(pline, "   ");
		strcat(uline, pline);
		if (++cnt == 3)
		{
			cnt = 0;
			printchatline(uline);
			memset(uline, 0, sizeof(uline));
		}
	}
	while (buf[0] != '.');
	if (cnt < 3)
		printchatline(uline);
	return 0;
}


dowhoall(fd)
int     fd;
{
	char    buf[80];
	char    chatid[80], userid[80], channame[80];
	char   *NextPass;

	printchatline(" ");
	printchatline("*** �{�b�Ҧ����ȤH ***");
	sprintf(genbuf, "%-10s  %-12s   %-15s", "�︹", "�N�W", "�Ҧb�W�D");
	printchatline(genbuf);
	sprintf(genbuf, "%-10s  %-12s   %-15s", "------", "------", "------");
	printchatline(genbuf);
	net_printf(fd, "WHOALL\r\n");

	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) != OK_CMD)
		return -1;
	do
	{
		net_gets(fd, buf, sizeof(buf));
		if (buf[0] == '.')
			break;
		NextPass = GetPass(buf, userid, sizeof(userid));
		NextPass = GetPass(NextPass, chatid, sizeof(userid));
		NextPass = GetPass(NextPass, channame, sizeof(userid));
		sprintf(genbuf, "%-10s  %-12s   %-15s", chatid, userid, channame);
		printchatline(genbuf);
	}
	while (buf[0] != '.');
	return 0;
}


/*
   printuserent(upent)
   USER_INFO *upent;
   {
   struct useridx uinbuf;
   static char uline[80];
   char   pline[30];
   static int cnt;

   if (!upent)
   {
   if (cnt)
   printchatline(uline);
   bzero(uline, 80);
   cnt = 0;
   return 0;
   }
   if (!upent->active || !upent->pid)
   return 0;
   if (!HAS_PERM(PERM_CLOAK) && upent->invisible)
   return 0;
   if (kill(upent->pid, 0) == -1)
   return 0;
   get_record(USERIDX, &uinbuf, sizeof(USER_INFO), upent->uid);
   sprintf(pline, "%-12s %c%-10s", uinbuf.userid, upent->invisible ? '#' : ' ',
   modestring(upent->mode, upent->destuid, 0, NULL));
   if (cnt < 2)
   strcat(pline, "   ");
   strcat(uline, pline);
   if (++cnt == 3)
   {
   cnt = 0;
   printchatline(uline);
   bzero(uline, 80);
   }
   return 0;
   }
 */

domsg(Token, fd)
char   *Token;
int     fd;
{
/*
   char   user[IDLEN];
   char   buf[80];

   Token = GetPass(Token, user, IDLEN);
   Token = PhaseSpace(Token);
 */
	net_printf(fd, "MSG\t%s\r\n", Token);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
		return 0;
	else if (GetRespNo(genbuf) == USR_FAIL)
		printchatline("*** �ثe�Ҧb�W�D�L���ϥΪ� �� �ʤ֭n�e�X���T�� **");
	else
		return -1;
	return 0;
}


#ifdef HAVE_CHATMSGALL
domsgall(msg, fd)
char   *msg;
int     fd;
{
	net_printf(fd, "MSGALL\t%s\r\n", msg);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
		return 0;
	else
		return -1;
}

#endif


#if 0
char   *
advance(ptr)			/* ? */
char   *ptr;
{
	while (!strchr(" \n\t", *ptr))
	{
		if (*ptr == '\0')
			return ptr;
		else
			ptr++;
	}
	while (!strchr(" \n\t", *ptr))
		ptr++;
	*(ptr - 1) = '\0';
	return ptr;
}

char   *msgto;
char   *umsgto;

chatlookup(uin)
USER_INFO *uin;
{
	static int matchcnt;
	static char fullid[10], userid[15];

	if (!uin)
	{
		int     final = matchcnt;

		msgto = fullid;
		umsgto = userid;
		matchcnt = 0;
		return final;
	}
	if (uin->mode != uinfo.mode)
		return 0;
	if (!uin->active)
		return 0;
	if (uin->pid > 2)	/* lasehu */
	{
		if (kill(uin->pid, 0) == -1)
			return 0;
	}
	else
		return 0;
	if (uin->invisible && !HAS_PERM(PERM_CLOAK))
		return 0;
	if (!strncmp(msgto, uin->chatid, strlen(msgto)) ||
	    !strncmp(msgto, uin->userid, strlen(msgto)))
	{
		if (matchcnt > 0)
		{
			matchcnt = 0;
			return QUIT_LOOP;
		}
		matchcnt++;
		strcpy(fullid, uin->chatid);
		strcpy(userid, uin->userid);
		return 0;
	}
}

domsg(id, fd)
char   *id;
int     fd;
{
	char   *text;
	char    buf2[STRLEN], buf[STRLEN];
	int     verdict, retval;

	while (*id == ' ' || *id == '\t' || *id == '\n')
		id++;
	if (*id == '\0')
	{
		printchatline("*** ���~: ��誺�W�r����");
		return;
	}
	text = advance(id);
	msgto = id;
	if (*text == '\0')
	{
		printchatline("*** ���~: �W�r�̤��n���Ů�");
		return;
	}
	if (apply_record(ULIST, chatlookup, sizeof(USER_INFO)) == QUIT_LOOP)
		verdict = -1;

	else
		verdict = chatlookup(NULL);
	switch (verdict)
	{
		case 0:
			printchatline("*** ���~: �o�ӤH���b�o��");
			break;
		case -1:
			printchatline("*** ERROR: that name is ambiguous; try using more letters");
			break;
		default:
			sprintf(buf, "/to %s %s %s", umsgto, uinfo.chatid, text);
			retval = net_printf(fd, "MSG\t%s\r\n", buf);
			net_gets(fd, genbuf, sizeof(genbuf));
			sprintf(buf2, "%s> %s", msgto, text);
			printchatline(buf2);
	}
	msgto = NULL;
	if (retval > -1)
		retval = 0;
	return retval;
}

printprivmsg(to_ptr)		/* ? */
char   *to_ptr;
{
	char   *fromptr = advance(to_ptr);
	char   *msgptr = advance(fromptr);

	if (!strcmp(to_ptr, curuser.userid))
	{
		char    buf[STRLEN];

		sprintf(buf, "*%s* %s", fromptr, msgptr);
		printchatline(buf);
	}
}

#endif

/*
   printinfoline(cmd)
   char  *cmd;
   {
   char  *nextarg;
   char   buf[STRLEN];

   nextarg = advance(cmd);
   if (!strcmp(cmd, "sysopin") && curuser.userlevel == 255)
   {
   sprintf(buf, "*** INFO: %s is entering cloaked", nextarg);
   printchatline(buf);
   }
   else if (!strcmp(cmd, "cloakin") && HAS_PERM(PERM_CLOAK))
   {
   sprintf(buf, "*** INFO: %s is entering cloaked", nextarg);
   printchatline(buf);
   }
   else if (!strcmp(cmd, "sysopout") && curuser.userlevel == 255)
   {
   sprintf(buf, "*** INFO: %s has exited cloaked", nextarg);
   printchatline(buf);
   }
   else if (!strcmp(cmd, "cloakout") && HAS_PERM(PERM_CLOAK))
   {
   sprintf(buf, "*** INFO: %s has exited cloaked", nextarg);
   printchatline(buf);
   }
   else if (!strcmp(cmd, "to"))
   printprivmsg(nextarg);
   else if (!strcmp(cmd, "nick") || (!strcmp(cmd, "inick") && HAS_PERM(PERM_CLOAK)) ||
   (!strcmp(cmd, "snick") && curuser.userlevel == 255))
   {
   sprintf(buf, "*** INFO: %s is now known as %s", nextarg,
   advance(nextarg));
   printchatline(buf);
   }
   }
 */


dolist(fd)
int     fd;
{
	char    buf[80];
	char    channame[80], topic[80], op[80], members[80], secret[80];

	printchatline(" ");
	printchatline("*** �ثe�Ҧ��W�D ***");
	sprintf(buf, "%-15s  %-20s  %-12s  %-6s  %-4s",
		"�W��", "�D�D", "�޲z��", "������", "��X");
	printchatline(buf);
	sprintf(buf, "%-15s  %-20s  %-12s  %-6s  %-4s",
		"------", "------", "------", "------", "------");
	printchatline(buf);
	net_printf(fd, "LISTCHAN\r\n");

	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) != OK_CMD)
		return -1;
	do
	{
		net_gets(fd, buf, sizeof(buf));
		if (buf[0] == '.')
			break;
		sscanf(buf, "%s\t%s\t%s\t%s\t%s\r\n", channame, topic, op, members, secret);
		sprintf(genbuf, "%-15s  %-20s  %-12s  %-6s  %-4s",
			channame, topic, op, members, secret);
		printchatline(genbuf);
	}
	while (buf[0] != '.');
	return 0;
}

get_complete_word(string)
char   *string;
{
	char   *p;

	for (p = string; *p; p++)
		if (*p == ' ' || *p == '\t' || *p == '\n')
			break;
	*p = '\0';
}

dojoin(channame, fd)
char   *channame;
int     fd;
{
	channame = PhaseSpace(channame);
	if (*channame == '\0')
	{
		printchatline("*** ���~: �S�����w�n�[�J���W�D�W��");
		return;
	}
	net_printf(fd, "JOIN\t%s\r\n", channame);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
	{
		strncpy(MyChanname, channame, CHANLEN);
		MyChanname[CHANLEN - 1] = '\0';
		return 0;
	}
	else if (GetRespNo(genbuf) == PASS_FAIL)
	{
		sprintf(genbuf, "*** �[�J %s �W�D����: �v������ **", channame);
		printchatline(genbuf);
		return 0;
	}
	else
		return -1;
}

#if 0
doleave(fd)
int     fd;
{
	net_printf(fd, "JOIN\t%s\r\n", DEF_CHANNAME);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
	{
		strncpy(MyChanname, DEF_CHANNAME, CHANLEN);
		MyChanname[CHANLEN - 1] = '\0';
		return 0;
	}
	return -1;
}

#endif


dotopic(topic, fd)
char   *topic;
int     fd;
{
	topic = PhaseSpace(topic);
	if (*topic == '\0')
	{
		printchatline("*** ���~: �S�����w�D�D");
		return;
	}
	net_printf(fd, "TOPIC\t%s\r\n", topic);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
		net_printf(fd, "SPEAK\t** �󴫥��W�D�D�D���� **\r\n");
	else if (GetRespNo(genbuf) == PASS_FAIL)
		printchatline("*** �󴫥��W�D�D�D����: �v������ **");
	else
		return -1;
	return 0;
}

dopasswd(pass, fd)
char   *pass;
int     fd;
{
	pass = PhaseSpace(pass);
	if (*pass == '\0')
	{
		printchatline("*** ���~: �S�����w�K�X");
		return;
	}
	net_printf(fd, "PASSWD\t%s\r\n", pass);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
		net_printf(ac, "SPEAK\t%s\r\n", "*** �󴫥��W�D�K�X���� **");
	else if (GetRespNo(genbuf) == PASS_FAIL)
		printchatline("*** �󴫥��W�D�K�X����: �v������ **");
	else
		return -1;
	return 0;
}

donopasswd(pass, fd)
char   *pass;
int     fd;
{
	net_printf(fd, "PASSWD\t%s\r\n", NOPASSWORD);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
		net_printf(ac, "SPEAK\t%s\r\n", "*** �Ѱ����W�D�K�X���� **");
	else if (GetRespNo(genbuf) == PASS_FAIL)
		printchatline("*** �󴫥��W�D�K�X����: �v������ **");
	else
		return -1;
	return 0;
}

#if 0
doignore(dest)
char   *dest;
{
	int     fd;
	USEREC  user;
	USER_INFO *up;

	if (curuser.userlevel < 100)
	{
		printchatline("*** ERROR: unknown special chat command");
		return;
	}
	while (*dest == ' ' || *dest == '\t' || *dest == '\n')
		dest++;
	if (*dest == '\0')
	{
		printchatline("*** ���~: �ܤ֭n���ӦW�r");
		return;
	}
	get_complete_word(dest);
	if (!(up = search_ulist(cmp_userid, dest)))
	{
		printchatline("*** ���~: �o�ӤH���b�o��");
		return;
	}
	if (get_passwd(&user, dest) <= 0)
	{
		printchatline("*** ���~: �N�����~");
		return;
	}
	if (curuser.userlevel < user.userlevel)
	{
		printchatline("*** ERROR: Can not ignore this user!!");
		return;
	}
	gethomefile(genbuf, dest, "ignore");
	if ((fd = open(genbuf, O_WRONLY | O_CREAT, 0644)) > 0)
	{
		strcpy(genbuf, curuser.userid);
		write(fd, genbuf, strlen(genbuf));
		close(fd);
	}
	log_usies("IGNORE", "'%s'", user.userid);	/* lasehu */
}

#endif

donick(newname, fd)
char   *newname;
int     fd;
{
	newname = PhaseSpace(newname);
	if (*newname == '\0')
	{
		printchatline("*** ���~: �ܤ֭n���ӦW�r");
		return;
	}
	newname[CHATIDLEN] = '\0';	/* ? */
	fixchatid(newname);
	net_printf(fd, "NICKNAME\t%s\r\n", newname);
	net_gets(fd, genbuf, sizeof(genbuf));
	if (GetRespNo(genbuf) == OK_CMD)
	{
		strncpy(uinfo.chatid, newname, sizeof(uinfo.chatid));
		uinfo.chatid[sizeof(uinfo.chatid) - 1] = '\0';
		update_utmp();
		return 1;	/* cause t_chat to update chatid */
	}
	else if (GetRespNo(genbuf) == NAME_FAIL)
	{
		printchatline("�κ٭���");
		return 0;
	}
	else
		return -1;
}

dochatcommand(cmd)
char   *cmd;
{
	char   *endcmd;
	int     retval = 0;

	while (*cmd == ' ')
		cmd++;
	for (endcmd = cmd; *endcmd; endcmd++)
		if (*endcmd == ' ' || *endcmd == '\n')	/* ? */
			break;

	if (*endcmd == '\0')
		*(endcmd + 1) = '\0';	/* ? */
	else
		*endcmd = '\0';
	if (!strcmp(cmd, "help") || !strcmp(cmd, "h"))
	{
		printchatline("�z�i�H�ϥγo�ǩR�O:");
		printchatline("  /help                   - �����e��              [/h]");
		printchatline("  /who                    - ���W�D����            [/w]");
		printchatline("  /who <�W�D�W��>         - �Y�W�D����            [/w]");
		printchatline("  /whoall                 - �Ҧ��W�D����          [/ws]");
		printchatline("  /join <�W�D> <��X�K�X> - �[�J�Y�W�D            [/j]");
#if 0
		printchatline("  /leave                  - ���}���W�D            [/le]");
#endif
		printchatline("  /list                   - �C�X�Ҧ��W�D          [/l]");
		printchatline("  /msg <�N�W> <������>    - �e <������> �� <�N�W> [/m]");
#ifdef HAVE_CHATMSGALL
		printchatline("  /msgall <�T��>          - ���W�D�s��            [/ma]");
#endif
		printchatline("  /pager                  - ���� Pager            [/p]");
		printchatline("  /nick <�︹>            - ��︹ <�︹>         [/n]");
		printchatline("  /me <���n����>          - �Фj�a�`�N�A����      [/me]");
		printchatline("  /clear                  - �M���e��              [/c]");
/*
   if (curuser.userlevel >= CLOAK)
   printchatline("  /cloak           - ���� [/cl]");
 */
		printchatline("�H�U�R�O�ȴ��Ѻ޲z�̨ϥ�:");
		printchatline("  /passwd <�K�X>          - �]�w���W�D�K�X [/ps]");
		printchatline("  /nopasswd               - �Ѱ����W�D�K�X [/nps]");
		printchatline("  /topic <�D�D>           - ��糧�W�D�D�D [/t] ");
/*
   if (curuser.userlevel >= 100)
 */
#if 0
		printchatline("  [1;36m/ignore <�N�W>     - �ϬY�H���L�@�� [/i][m");
#endif
		printchatline("  ctrl-d                  - ���}");
	}
	else if (!strcmp(cmd, "who") || !strcmp(cmd, "w"))
	{
		retval = dowho(endcmd + 1, ac);
		if (retval == -1)
		{		/* lasehu */
			printchatline("*** ���w�W�D���s�b");
			return 0;
		}
	}
	else if (!strcmp(cmd, "whoall") || !strcmp(cmd, "ws"))
		dowhoall(ac);
	else if (!strcmp(cmd, "join") || !strcmp(cmd, "j"))
		retval = dojoin(endcmd + 1, ac);
	else if (!strcmp(cmd, "list") || !strcmp(cmd, "l"))
		retval = dolist(ac);
#if 0
	else if (!strcmp(cmd, "leave") || !strcmp(cmd, "le"))
		retval = doleave(ac);
#endif
	else if (!strcmp(cmd, "msg") || !strcmp(cmd, "m"))
		retval = domsg(endcmd + 1, ac);
#ifdef HAVE_CHATMSGALL
	else if (!strcmp(cmd, "msgall") || !strcmp(cmd, "ma"))
		retval = domsgall(endcmd + 1, ac);
#endif
	else if (!strcmp(cmd, "topic") || !strcmp(cmd, "t"))
		retval = dotopic(endcmd + 1, ac);
	else if (!strcmp(cmd, "passwd") || !strcmp(cmd, "ps"))
		retval = dopasswd(endcmd + 1, ac);
	else if (!strcmp(cmd, "nopasswd") || !strcmp(cmd, "nps"))
		retval = donopasswd(endcmd + 1, ac);
	else if (!strcmp(cmd, "nick") || !strcmp(cmd, "n"))
		retval = donick(endcmd + 1, ac);
	else if (!strcmp(cmd, "me"))
	{
		char    actionbuf[80], *firstlet = endcmd + 1;

		while (*firstlet == ' ' || *firstlet == '\n' || *firstlet == '\t')
			firstlet++;
		if (*firstlet != '\0')
		{
			sprintf(actionbuf, "*** %s ***", endcmd + 1);
			net_printf(ac, "SPEAK\t%s\r\n", actionbuf);
		}
		else
			printchatline("*** ���~: �᭱�n�[�@�y��");
	}
	else if (!strcmp(cmd, "pager") || !strcmp(cmd, "p"))
	{
		t_pager();
		printchatline(" ");
		if (!uinfo.pager)
			printchatline("*** Pager turned off");
		else
			printchatline("*** Pager turned on");
	}
/*
   else if (!strcmp(cmd, "cloak") || !strcmp(cmd, "cl"))
   {
   if (HAS_PERM(PERM_CLOAK))
   {
   a_cloak();
   if (!uinfo.invisible)
   printchatline("*** Cloak has been deactivated");
   else
   printchatline("*** Cloak has been activated");
   }
   else
   printchatline("*** ERROR: unknown special chat command");
   }
 */
	else if (!strcmp(cmd, "clear") || !strcmp(cmd, "c"))
	{
		clear();
		move(ECHATWIN, 0);
		prints("--------------------------------------------------------------------------------");
		chatline = 0;	/* reset */
		printchatline("�� /help �i�ݻ����e��");
		printchatline("  ");	/* �L�ťզ�, �M�ᴫ�� */
	}
#if 0
	else if (!strcmp(cmd, "ignore") || !strcmp(cmd, "i"))
		doignore(endcmd + 1);
#endif
	else
		printchatline("*** ERROR: unknown special chat command");
	return retval;
}
