/**************************************************************
 * NSYSU Formosa BBS Server v1.0.0
 *
 * ���{���ΨӨ��N Telnetd, �æ��� Server, �ϢТТᤣ�ݭn����
 *
 * Coder: lmj@cc.nsysu.edu.tw Liang Ming-Jang �����
 *
 *************************************************************/

/*
 * �ק�O���G
 * 85.10.03  ��������                 -- lmj
 */

#include <sys/param.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/file.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <netdb.h>
#include <syslog.h>
#include <pwd.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/pathname.h>
#include <arpa/telnet.h>

#ifdef  SUNOS5
#include <sys/types.h>
#include <fcntl.h>
#endif


#include "csbbs.h"


#define	PATH_DEVNULL	"/dev/null"
#define	HOST_ALLOW	"/etc/hosts.ip"
#define INIT_TIMEOUT	240
#define RERUN	20
#define BBSBINPATH	"/apps/bbs/bin/bbssrv"

extern int errno;

extern char *rindex();
char *telnet();


/*------------------------------------------------------------------------
 * check_host_allow  - �ˬd�ϥΪ̨ӳB
 *------------------------------------------------------------------------
 */
int cmp_char(c1, c2)
char c1, c2;
{
	if(c1 == c2)
		return 0;
	else if(c1 >= 'A' && c1 <= 'Z' && c2 >= 'a' && c2 <= 'z' &&
		(c2 - c1) == 0x20)
		return 0;
	else if(c2 >= 'A' && c2 <= 'Z' && c1 >= 'a' && c1 <= 'z' &&
		(c1 - c2) == 0x20)
		return 0;
	else
		return -1;
}


int check_from(from)
char	*from;
{
	FILE	*fp;
	char	*s1, *s2, buf[80];

	if(!from || !(fp = fopen(HOST_ALLOW,"r")))
		return -1;
	while(fgets(buf, 79, fp)) {
		if(buf[0] == '#' || buf[0] == '\n')
			continue;
		if(s1 = (char *)rindex(buf, '\n'))
			*s1-- = '\0';
		else
			s1 = buf + strlen(buf) - 1;
		if(buf[0] == '*') {
			for(s2=from+strlen(from)-1; s2>=from && s1>buf; s1--, s2--)
				if(cmp_char(*s1, *s2))
					break;
			if(s1 == buf) {
				fclose(fp);
				return 0;
			}
		} else {
			for(s1=buf, s2=from;*s1!='\0'&&s2!='\0';s1++,s2++)
				if(cmp_char(*s1, *s2))
					break;
			if(*s1 == '\0') {
				fclose(fp);
				return 0;
			}
		}
	}
	fclose(fp);
	return -1;
}




/*------------------------------------------------------------------------
 * reaper - clean up zombie children
 *------------------------------------------------------------------------
 */
static void
reaper()
{
#ifdef  SUNOS5
	int status;
#else
	union wait  status;
#endif  /* SUNOS5 */

    while (wait3(&status, WNOHANG, (struct rusage *)0) > 0)
        /* empty */;
	(void) signal(SIGCHLD, reaper);
}


/*
 * Idle Timeout
 */
void saybyebye()
{
	int fd;
	for(fd = 1; fd < 64; fd++)
		close(fd);
	shutdown(0, 2);
	close(0);
	exit(0);
}



/*
 * Main
 *
 */

void main(argc, argv)
int argc;
char *argv[];
{
	int aha, on = 1, maxs = 0;
	fd_set ibits;
    struct sockaddr_in from, sin;
    int s, ns;
    short check = 0, rerun = 0, port23 = 0;
    struct timeval wait;
    char buf[80];

    if(argc < 2) {
        printf("Usage: %s PortNumber [check]\n",argv[0]);
        exit(1);
    }

#ifdef	CSBBS
{
	if(atoi(argv[1]) == 0 && argc > 2) { /* if call by csbbs server --lmj */
		unsigned char term[8];
		setsockopt(0, SOL_SOCKET, SO_KEEPALIVE,(char *) &on, sizeof (on));
		for(aha = 3; aha < 64; aha++)
			close(aha);
		Formosa(argv[2], telnet(&term[0]));
		shutdown(0, 2);
		exit(0);
    }
#endif

	if(fork() != 0)
		exit(0);

	if(argc > 2 && !strcmp(argv[2], "check"))
		check++;

	for(aha = 64; aha >= 0; aha--)
		close(aha);

	if((aha = open(PATH_DEVNULL, O_RDONLY)) < 0)
		exit(1);
	if(aha) {
		dup2(aha, 0);
		close(aha);
	}
	dup2(0, 1);
	dup2(0, 2);

	sprintf(buf, "/tmp/formosa.%-s", argv[1]);
	unlink(buf);
	if((aha = open(buf, O_WRONLY|O_CREAT, 0644)) > 0) {
		sprintf(buf, "%-d\n", getpid());
		write(aha, buf, strlen(buf));
		close(aha);
	}

    signal(SIGHUP, SIG_IGN);
    signal(SIGCHLD,reaper);

    if((s = socket(AF_INET, SOCK_STREAM, 0)) < 0)
        exit(1);

    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on));
/*
    on = 8192;
    setsockopt(s, SOL_SOCKET, SO_RCVBUF, &on, sizeof(on));
*/
#if defined(IP_OPTIONS) && defined(IPPROTO_IP)
    setsockopt(s, IPPROTO_IP, IP_OPTIONS, (char *)NULL, 0);
#endif

    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = INADDR_ANY;
    sin.sin_port = htons((u_short)atoi(argv[1]));

	if(atoi(argv[1]) == 23)
		port23++;

    if (bind(s, (struct sockaddr *)&sin, sizeof sin) < 0 ||
#if defined(SUNOS5)
        listen(s, 256) < 0)
#else
        listen(s, 5) < 0)
#endif
        exit(1);

    aha = sizeof(from);
    wait.tv_sec = 5;
    wait.tv_usec = 0;
	maxs = s + 1;

    while(1) {
        FD_ZERO(&ibits);
        FD_SET(s, &ibits);
        if ((on = select(maxs, &ibits, 0, 0, &wait)) < 1) {
            if(port23 && ++rerun > RERUN) {
                shutdown(s, 2);
                close(s);
                if(fork())
                    exit(0);
                else
                    execv(BBSBINPATH, &(argv[0]));
			}
            if(!on || errno == EINTR)
                continue;
            else {
				sleep(5);
                shutdown(s, 2);
                close(s);
                if(fork())
                    exit(0);
                else
                    execv(BBSBINPATH, &(argv[0]));
                continue;
            }
        }
        if(!FD_ISSET(s, &ibits))
            continue;
        if((ns = accept(s, (struct sockaddr *)&from, &aha)) < 0)
            continue;
        else {

            switch(fork()) {

                case -1:
                    close(ns);
                    break;

                case 0:
                {
                    char *host, *inet_ntoa(), term[8];
                    struct hostent *hp;

                    close(s);
                    signal(SIGCHLD,SIG_IGN);
					signal(SIGALRM, saybyebye);
					alarm(INIT_TIMEOUT);
                    dup2(ns, 0);
                    close(ns);
                    dup2(0, 1);
                    dup2(0, 2);
                    on = 1;
                    setsockopt(0, SOL_SOCKET, SO_KEEPALIVE,
                                (char *) &on, sizeof (on));
#if !defined(SUNOS5)
                    if((hp = gethostbyaddr((char *) &(from.sin_addr),
                                        sizeof (struct in_addr),
                                        from.sin_family)))
                        host = hp->h_name;
                    else
#endif
                        host = inet_ntoa(from.sin_addr);

                    if(check && check_from(host)) {
                        shutdown(0, 2);
						exit(0);
					}

					Formosa(host, telnet(&term[0]));

                    shutdown(0, 2);
					exit(0);
                }
                default:
                    close(ns);
					rerun &= ~rerun;
            }
        }
    }
}

#ifdef	LMJ_AHA
unsigned char ngetch(void)
{
	fd_set rset;
	int cc;
	static unsigned char ibuf[32], *p1 = ibuf, *p2 = ibuf;

	while(1) {
		if(p1 > p2)
			return *p2++;
		p1 = p2 = ibuf;
		while(1) {
			FD_ZERO(&rset);
			FD_SET(0, &rset);
			if(select(3, &rset, (fd_set *)NULL, (fd_set *)NULL,
						(struct timeval *)NULL) < 1)
				continue;
			if(!FD_ISSET(0, &rset))
				continue;
			if((cc = read(0, ibuf, sizeof(ibuf))) > 0) {
				p1 += cc;
				break;
			}
		}
	}
}

extern unsigned char igetch();

char init_igetch(buf, size)
char buf[];
int size;
{
	unsigned char ikey;
	char *p = &(buf[0]), *endp = p + size;
	extern short init_enter, press_enter, two_enter;

	press_enter &= ~press_enter;
	init_enter &= ~init_enter;
	while(p < endp) {
		ikey = igetch();
		switch(ikey) {
			case IAC:
				if(igetch() == SB)
					while(igetch() != SE);
				else
					igetch();
				continue;
			case 0x0d:
			case 0x0a:
				if(press_enter) {
					press_enter &= ~press_enter;
					two_enter &= ~two_enter;
					init_enter++;
					*p = '\0';
					write(1, "\r\n", 2);
					press_enter &= ~press_enter;
					return *p;
				} else {
					press_enter++;
					continue;
				}
			case 8:
			case 127:
				if(p == buf) {
					write(1, "\a", 1);
					continue;
				}
				p--;
				write(1, "\b \b", 3);
				continue;
			default:
				if(press_enter) {
					press_enter &= ~press_enter;
					two_enter++;
					init_enter++;
					*p = '\0';
					write(1, "\r\n", 2);
					return *p;
				}
				*p++ = ikey;
				write(1, &ikey, 1);
		}
	}
	*(--p) = '\0';
	return *p;
}

extern int oflush();
extern int refresh();

init_igetch(buf, size)
char *buf;
int size;
{
	extern short init_enter, two_enter, press_enter;
	extern unsigned char my_enter_key;
	unsigned char genbuf[80];
	unsigned char *pi;
	char *po, *pe;
	fd_set ibit;
	int cc;
	short wait_se = 0;

	oflush();
	fflush(stdout);
	bzero(buf, size);
	init_enter &= ~init_enter;
	two_enter &= ~two_enter;
	press_enter &= ~press_enter;
	pe = po = buf;
	pe += size;
	pe--;
	while(1) {
		FD_ZERO(&ibit);
		FD_SET(0, &ibit);
		if(select(1, &ibit, (fd_set *)NULL, (fd_set *)NULL,
					(struct timeval *)NULL) < 1)
			continue;
		if(!FD_ISSET(0, &ibit))
			continue;
		if((cc = read(0, genbuf, 80)) < 1)
			saybyebye();
		pi = &(genbuf[0]);
		if(wait_se)
			goto wait_se_again;
		while(cc > 0) {
			switch(*pi)
			{
			case IAC:
				if(*(pi + 1) == SB) {
wait_se_again:
					for(;*pi != SE && cc > 0; pi++, cc--);
					if(*pi != SE && !cc)
						wait_se++;
					else
						wait_se &= ~wait_se;
				} else {
					pi += 3;
					cc -= 3;
				}
				continue;
			case 0x0d:
				if(cc >= 2 && (*pi != *(pi+1)))
					two_enter++;
				else if(cc == 1)
					two_enter &= ~two_enter;
			/*	init_enter++;*/
				write(1, "\r\n", 2);
				*po = '\0';
				my_enter_key = 0x0d;
				return;
			case 8:
			case 127:
				cc--;
				pi++;
				if(po == buf) {
					write(1, "\a", 1);
					continue;
				}
				po--;
				write(1, "\b \b", 3);
				continue;
			default:
				if((*pi >= 'A' && *pi <= 'z')||(*pi >= '0' && *pi <= '9')) {
					if(po == pe) {
						cc--;
						pi++;
						write(1, "\a", 1);
						continue;
					}
					write(1, pi, 1);
					*po++ = *pi++;
				} else
					pi++;
				cc--;
			}
		}
	}
}

#endif	/* LMJ_AHA */


char *telnet(term)
char *term;
{
	int aha;
	unsigned ibuf[80], *p;
	unsigned char o1[] = { IAC, DO, TELOPT_TTYPE };
	unsigned char o2[] = { IAC, WILL, TELOPT_ECHO };
	unsigned char o3[] = { IAC, WILL, TELOPT_SGA };
	unsigned char o4[] = { IAC, DO, TELOPT_ECHO };
	unsigned char o5[] = { IAC, DO, TELOPT_BINARY };

	aha = 1;
	*term = '\0';
#ifndef	SUNOS5
	ioctl(0, FIONBIO, &aha);
#endif
#if defined(SO_OOBINLINE)
	setsockopt(0, SOL_SOCKET, SO_OOBINLINE, (char *) &aha, sizeof aha);
#endif  /* defined(SO_OOBINLINE) */

	ibuf[0] = 0;
	sprintf(ibuf+1, "\r\n\r\n��ߤ��s�j�� (BBS)\r\n\r\r\n\r");
	write(1, ibuf, strlen(ibuf+1)+1);
	write(1, o1, sizeof(o1));
	fflush(stdout);
	for(aha = 0; aha < 3; aha++) {
		ibuf[aha] = igetch();
#ifdef	DEBUG
		fprintf(stdout, "[%d]\n", ibuf[aha]);
		fflush(stdout);
#endif
	}
	if(ibuf[0] == IAC && ibuf[1] == WILL && ibuf[2] == TELOPT_TTYPE) {
		unsigned char oo[] = {IAC,SB,TELOPT_TTYPE,TELQUAL_SEND,IAC,SE};
		write(1, oo, sizeof(oo));
		for(aha = 0; aha < 4; aha++)
			ibuf[aha] = igetch();
		if(ibuf[0] == IAC && ibuf[3] == TELQUAL_IS) {
			p = ibuf;
			while(1) {
				*p = igetch();
				if(*p == IAC) {
					*p = '\0';
					igetch();
					break;
				} else
					p++;
			}
			strncpy(term, (char *)&ibuf[0], 8);
#ifdef	DEBUG
			fprintf(stdout, "term = [%s]\n", ibuf);
			fflush(stdout);
#endif
		}
	}
	write(1, o2, sizeof(o2));
	write(1, o3, sizeof(o3));
	write(1, o4, sizeof(o4));
	write(1, o5, sizeof(o5));
	return term;
}
