
#include "bbs.h"


extern char *genpasswd();


int
main(argc, argv)
int     argc;
char   *argv[];
{
    struct userec urec;
    int     fd;
    char    buf[80], fname[80];

    if (argc < 2)
    {
	fprintf(stderr, "Usage: %s <file>\n", argv[0]);
	return 2;
    }
    
    memset(fname, 0, sizeof(fname));
    strcpy(fname, argv[1]);

    if ((fd = open(fname, O_WRONLY | O_CREAT | O_TRUNC, 0600)) < 0)
    {
	perror(argv[0]);
	return 1;
    }

    memset(&urec, 0, sizeof(urec));
#if 1
    urec.uid = 1;
#endif

#ifdef IDENG
    urec.ident = 7;
#endif            
    strcpy(urec.userid, "SYSOP");
    strcpy(buf, genpasswd("SYSOP"));
    strncpy(urec.passwd, buf, PASSLEN);
    strcpy(urec.username, "Sysop");
    strcpy(urec.termtype, "vt100");
    urec.userlevel = 255;
    urec.firstlogin = time(0);

    write(fd, &urec, sizeof(urec));
    close(fd);
    
    chown(fname, BBS_UID, BBS_GID);

    return 0;
}
