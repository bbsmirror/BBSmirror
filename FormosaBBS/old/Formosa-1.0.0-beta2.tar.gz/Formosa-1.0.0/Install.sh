#! /bin/sh

HOMEBBS=/apps/bbs
INSTALL="/usr/bin/ginstall -c"
TARGET=/apps/bbs/bin

echo "This script will install the whole BBS to ${HOMEBBS}..."
echo -n "Press <Enter> to continue ..."
read ans

if [ -d ${HOMEBBS} ] ; then
	echo -n "Warning: ${HOMEBBS} already exists, overwrite whole bbs [N]?"
	read ans
	ans=${ans:-N}
	case $ans in
	    [Yy]) echo "Installing new bbs to ${HOMEBBS}" ;;
	    *) echo "Abort ..." ; exit ;;
	esac
else
	echo "Making dir ${HOMEBBS}"
	mkdir ${HOMEBBS}
	chown -R bbs ${HOMEBBS}
	chgrp -R bbs ${HOMEBBS}
fi

echo "Setup bbs directory tree ....."
( cd bbshome ; tar cf - . ) | ( cd ${HOMEBBS} ; tar xf - )

chown -R bbs ${HOMEBBS}
chgrp -R bbs ${HOMEBBS}

${INSTALL} -m 770  -s -g bbs -o bbs    ./source/bbsd        ${TARGET}
${INSTALL} -m 770  -s -g bbs -o bbs    ./source/bbschatd  ${TARGET}
##${INSTALL} -m 4755 -s -g bin -o root   bbsrf      ${TARGET}

${INSTALL} -m 770  -g bbs -o bbs    /usr/bin/sort  ${TARGET}
${INSTALL} -m 770  -g bbs -o bbs    /usr/bin/uuencode ${TARGET}

echo "Install finished..."
