
#include "bbs.h"
#include "csbbs.h"
#ifdef COMMENT
#include "chat.h"
#endif
#if 1	/* COMMENT */
#define CHATPORT	5177
#endif


int     chatroom;
extern char page_requestor[];
extern char *modestring();


	int 	shutup = 0;

#define BADCIDCHARS " %*$`\"\\;:|[{]},./?=~!@#^()<>"
#define CHAT_LIMIT1 40
#define CHAT_LIMIT2 25
#define CHAT_LIMIT3 10
#define CHAT_LIMIT4 5

fixchatid(chatid)
unsigned char *chatid;
{
	while (*chatid != '\0' && *chatid != '\n' && *chatid > 32)
	{
		if (index(BADCIDCHARS, *chatid))
			*chatid = '_';
		chatid++;
	}
}

/**********************************************************
 *  Syntax: CHAT [roomnum] [chatid]                       *
 **********************************************************/
DoChat()
{
	char    tmp[256];
	char    mybuf[256];
	char    chatid[STRLEN];
	struct hostent *h;
	char    hostname[STRLEN];
	struct sockaddr_in sin;
	char   *colon;
	int     a, cc;
	int     currchar;
	int     chatport;
	char    chatstr[80];
	char    inbuf[90], inbuf2[90];
	fd_set  readmask;
	struct timeval timeout;
	int     i, j;
	int     keyno;
	char    keyword[MAX_KEYWORD_LEN];



	inbuf[0] = '\0';
	inbuf2[0] = '\0';

	NextToken = GetToken(NextToken, tmp, 2);
	if (tmp[0] == '\0')
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}
	chatroom = atoi(tmp);
	if (chatroom < 1 || chatroom > 4)
	{
		RespondProtocol(WORK_ERROR);
		return;
	}
	switch (chatroom)
	{
		case 4:
			if (curuser.userlevel < CHAT_LIMIT4)
			{
				RespondProtocol(LEVEL_TOO_LOW);
				return;
			}
			break;
		case 3:
			if (curuser.userlevel < CHAT_LIMIT3)
			{
				RespondProtocol(LEVEL_TOO_LOW);
				return;
			}
			break;
		case 2:
			if (curuser.userlevel < CHAT_LIMIT2)
			{
				RespondProtocol(LEVEL_TOO_LOW);
				return;
			}
			break;
		case 1:
			if (curuser.userlevel < CHAT_LIMIT1)
			{
				RespondProtocol(LEVEL_TOO_LOW);
				return;
			}
			break;
	}

	chatid[0] = '\0';
	if (chatroom == 1)
	{
		NextToken = GetToken(NextToken, chatid, 10);
	}

	if (chatid[0] == '\0')
	{
		strcpy(chatid, curuser.userid);
	}
	chatid[8] = '\0';
	fixchatid(chatid);
	strcat(chatid, ":                      ");
	chatid[10] = '\0';
	strcpy(inbuf, chatid);
	gethostname(hostname, STRLEN);
	if (!(h = gethostbyname(hostname)))
	{
		perror("gethostbyname");
		return -1;
	}
	bzero(&sin, sizeof sin);
	sin.sin_family = h->h_addrtype;
	bcopy(h->h_addr, &sin.sin_addr, h->h_length);
	switch (chatroom)
	{
#ifdef COMMENT
		case 4:
			chatport = CHATPORT4;
			break;
		case 1:
			chatport = CHATPORT1;
			break;
		case 2:
			chatport = CHATPORT2;
			break;
		case 3:
			chatport = CHATPORT3;
			break;
#endif			
		case 4:
			chatport = CHATPORT;
			break;
		case 1:
			chatport = CHATPORT;
			break;
		case 2:
			chatport = CHATPORT;
			break;
		case 3:
			chatport = CHATPORT;
			break;

	}
	sin.sin_port = chatport;
	a = socket(sin.sin_family, SOCK_STREAM, 0);
	if ((connect(a, (struct sockaddr *) & sin, sizeof sin)))
	{
		close(a);
#ifdef LOCALEXEC
		sprintf(chatstr, "/seabass/gtvega/bbs/bin/bbs.chatd %d", chatroom);
#else
		sprintf(chatstr, "/bin/bbs.chatd %d", chatroom);
#endif
		do_exec(chatstr, NULL);
		sleep(2);
		a = socket(sin.sin_family, SOCK_STREAM, 0);
		if ((connect(a, (struct sockaddr *) & sin, sizeof sin)))
		{
			RespondProtocol(WORK_ERROR);
			return;
		}
	}
	switch (chatroom)
	{
		case 4:
			update_umode(CHATROOM);
			break;
		case 1:
			update_umode(CHATROOM);
			break;
		case 2:
			update_umode(CHATROOM);
			break;
		case 3:
			update_umode(CHATROOM);
			break;
	}
	uinfo.in_chat = YEA;
	strncpy(uinfo.chatid, chatid, 10);
	if (colon = rindex(uinfo.chatid, ':'))
		*colon = '\0';
	update_utmp(&uinfo, uinfo.active);


	inet_printf("%d %s\r\n", OK_CMD, uinfo.chatid);	/* Attention!! */


	sprintf(inbuf, "%s", curuser.userid);

	if (shutup == 1)
		printchatline(inbuf);

	if (uinfo.invisible)
	{
		if (curuser.userlevel == 255)
			sprintf(inbuf, "/sysopin %s", uinfo.chatid);
		else
			sprintf(inbuf, "/cloakin %s", uinfo.chatid);
	}
	else
	{
		write(a, inbuf, strlen(inbuf) + 1);
		sprintf(inbuf, "%s�[�J�o!", chatid);
	}
	if (shutup == 1)
		printchatline(inbuf);
	else
		write(a, inbuf, strlen(inbuf) + 1);

	sprintf(inbuf, "�� /help �i�ݨϥλ���");
	printchatline(inbuf);
	strcpy(inbuf, chatid);
	currchar = strlen(inbuf);

	timeout.tv_sec = 0;
	timeout.tv_usec = 1;
	while (YEA)
	{
		FD_ZERO(&readmask);
		FD_SET(a, &readmask);
		FD_SET(0, &readmask);
		if (select(a + 1, &readmask, NULL, NULL, &timeout) < 0)
		{
			if (talkrequest)
			{
				talkreply();
				continue;
			}
			else
			{
				close(a);
				RespondProtocol(CHAT_EXIT);
				return;
			}
		}
		if (FD_ISSET(0, &readmask))
		{
			if ((i = inet_gets(mybuf, sizeof(mybuf))) < 0)
			{	/* Oh.. I leave... */
				close(a);
				FormosaExit();
			}
			if (i > 0)
			{
				NextToken = GetToken(mybuf, keyword, MAX_KEYWORD_LEN);
				if (keyword[0] == '\0')
					continue;
				keyno = GetKeywordNo(keyword);
				if (keyno == CHATSTOP)
				{
					if (uinfo.invisible)
					{
						if (curuser.userlevel == 255)
							sprintf(inbuf, "/sysopout %s", uinfo.chatid);
						else
							sprintf(inbuf, "/cloakout %s", uinfo.chatid);
					}
					else
						sprintf(inbuf, "%s ���ƥ����@�B, ��|����.", chatid);
					if (shutup == 1)
						printchatline(inbuf);
					else
						write(a, inbuf, strlen(inbuf) + 1);
					break;
				}
				switch (keyno)
				{
					case CHATSAY:
						GetString(NextToken, &inbuf[currchar], 71);
						DelIsPrint2(inbuf);
						for (i = 10, j = 0; i < STRLEN; i++)
						{
							if (inbuf[i] == '\0')
							{
								mybuf[j] = '\0';
								break;
							}
							if (inbuf[i] != ' ')
								mybuf[j++] = inbuf[i];
						}
						if (mybuf[0] == '\0')
							continue;
						if (!strcmp(mybuf, "Goodbye!"))
						{
							if (uinfo.invisible)
							{
								if (curuser.userlevel == 255)
									sprintf(inbuf, "/sysopout %s", uinfo.chatid);
								else
									sprintf(inbuf, "/cloakout %s", uinfo.chatid);
							}
							else
								sprintf(inbuf, "%sGoodbye!", chatid);
							write(a, inbuf, strlen(inbuf) + 1);
							break;
						}
						if (inbuf[10] == '/')
						{
							int     action;

							action = dochatcommand(&inbuf[11], a);
							if (action == 1)
							{	/* change nick name */
								strcpy(chatid, uinfo.chatid);
								chatid[8] = '\0';
								strcat(chatid, ":                      ");
								chatid[10] = '\0';

								inet_printf("%d %s\r\n", CHAT_CHG_NICKNAME, uinfo.chatid);

							}
							else if (action == -1)
								break;
						}
						else
						{
							bzero(inbuf2, 90);
							sprintf(inbuf2, "%-s", inbuf);
							if (shutup == 0)
							{
								if (write(a, inbuf2, strlen(inbuf2) + 1) == -1)
									break;
							}
							else
								printchatline(inbuf2);
							strcpy(inbuf, chatid);
							currchar = strlen(inbuf);
						}
						break;
					case _QUIT:
						close(a);
						FormosaExit();
						break;
				}
			}
		}
		if (FD_ISSET(a, &readmask))
		{
			static int cnt;
			static char buf[512];

			if ((cc = read(a, buf, sizeof(buf))) < 0)
			{
				close(a);
				RespondProtocol(CHAT_EXIT);
				break;
			}
			if (cc > 0)
			{
				int     processed = 0;

				while (cc > 0)
				{
					for (i = processed; buf[i] != '\0' && i != sizeof buf; i++)
						 /* NULL STATEMENT */ ;
					if (i == sizeof buf && buf[i] != '\0')
					{
						bcopy(buf + processed, buf, processed - sizeof(buf));
						cnt = processed - sizeof(buf);
						break;
					}
					cnt = 0;
					if (*(buf + processed) == '/')
						printinfoline(buf + processed + 1);
					else
						printchatline(buf + processed);
					i++;
					cc -= (i - processed);
					processed = i;
					if (i == sizeof buf)
						break;
				}
			}
		}
		if (talkrequest)
		{
			talkreply();
		}
	}

	uinfo.in_chat = NA;
	uinfo.chatid[0] = '\0';
	update_umode(CLIENT);
	update_utmp(&uinfo, uinfo.active);
}

char   *
advance(ptr)
char   *ptr;
{
	while (*ptr != ' ' && *ptr != '\n' && *ptr != '\t')
	{
		if (*ptr == '\0')
			return ptr;
		else
			ptr++;
	}
	while (*ptr == ' ' || *ptr == '\n' || *ptr == '\t')
		ptr++;
	*(ptr - 1) = '\0';
	return ptr;
}

printchatline(str)
char   *str;
{
	inet_printf("%d \"%s\"\r\n", CHAT_MSG, str);
	return 0;
}

printprivmsg(to_ptr)
char   *to_ptr;
{
	char   *fromptr = advance(to_ptr);
	char   *msgptr = advance(fromptr);

	if (!strcmp(to_ptr, curuser.userid))
	{
		char    buf[STRLEN];

		sprintf(buf, "*%s* %s", fromptr, msgptr);
		printchatline(buf);
	}
}

printinfoline(cmd)
char   *cmd;
{
	char   *nextarg;
	char    buf[STRLEN];

	nextarg = advance(cmd);
	if (!strcmp(cmd, "sysopin") && curuser.userlevel == 255)
	{
		sprintf(buf, "** INFO: %s is entering cloaked", nextarg);
		printchatline(buf);
	}
	else if (!strcmp(cmd, "cloakin") && curuser.userlevel >= PERM_CLOAK)
	{
		sprintf(buf, "** INFO: %s is entering cloaked", nextarg);
		printchatline(buf);
	}
	else if (!strcmp(cmd, "sysopout") && curuser.userlevel == 255)
	{
		sprintf(buf, "** INFO: %s has exited cloaked", nextarg);
		printchatline(buf);
	}
	else if (!strcmp(cmd, "cloakout") && curuser.userlevel >= PERM_CLOAK)
	{
		sprintf(buf, "** INFO: %s has exited cloaked", nextarg);
		printchatline(buf);
	}
	else if (!strcmp(cmd, "to"))
		printprivmsg(nextarg);
	else if (!strcmp(cmd, "nick") || (!strcmp(cmd, "inick") && curuser.userlevel >= PERM_CLOAK) ||
		 (!strcmp(cmd, "snick") && curuser.userlevel == 255))
	{
		sprintf(buf, "** INFO: %s is now known as %s", nextarg,
			advance(nextarg));
		printchatline(buf);
	}
}

printchatent(uentp)
struct user_info *uentp;
{
	static char uline[80];
	char    pline[30];
	static int cnt;
	int     mymode;

	switch (chatroom)
	{
		case 4:
			mymode = CHATROOM;
			break;
		case 1:
			mymode = CHATROOM;
			break;
		case 2:
			mymode = CHATROOM;
			break;
		case 3:
			mymode = CHATROOM;
			break;
	}
	if (!uentp)
	{
		if (cnt)
			printchatline(uline);
		bzero(uline, 80);
		cnt = 0;
		return 0;
	}
	if (!uentp->active || !uentp->pid)
		return 0;
	if (uentp->mode != mymode)
		return 0;
	if (curuser.userlevel < PERM_CLOAK && uentp->invisible)
		return 0;
	if (kill(uentp->pid, 0) == -1)
		return 0;
	sprintf(pline, "%-10s %c%-12s", uentp->chatid, uentp->invisible ? '#' : ' ',
		uentp->userid);
	if (cnt < 2)
		strcat(pline, "   ");
	strcat(uline, pline);
	if (++cnt == 3)
	{
		cnt = 0;
		printchatline(uline);
		bzero(uline, 80);
	}
	return 0;
}


#define BUFSIZE 16384


/*******************************************************************
 * �ǤJ "�ɦW" , process function,  �P record length,
 * Ū�X�ɤ��C�@�� record,
 * �åB��C�@�� record �e�� process function �B�z.
 *******************************************************************/
int 
apply_record(filename, fptr, size)
char   *filename;
int     (*fptr) ();
int     size;
{
	int     fd;
	char    gb[BUFSIZE];

	if (size > BUFSIZE)
	{
		fprintf(stderr, "size to big in apply record\n");
		return -1;
	}
	if ((fd = open(filename, O_RDONLY)) < 0)
		return -1;
	while (read(fd, gb, size) == size)
		if ((*fptr) (gb) == QUIT_LOOP)
		{
			close(fd);
			return QUIT_LOOP;
		}
	close(fd);
	return 0;
}



dowho()
{
	char    buf[80];

	printchatline(" ");
	printchatline("*** �{�b�o�̪��ȤH ***");
	sprintf(buf, "%-10s  %-12s   %-10s  %-12s   %-10s  %-12s",
		"�︹", "�N�W", "�︹", "�N�W", "�︹", "�N�W");
	printchatline(buf);
	sprintf(buf, "%-10s  %-12s   %-10s  %-12s   %-10s  %-12s",
		"------", "------", "------", "------", "------", "------");
	printchatline(buf);
	if (apply_record(ULIST, printchatent, sizeof(struct user_info)) == -1)
	{
		printchatline("(�S�H)");
		return 0;
	}
	printchatent(NULL);
	return 0;
}

printuserent(uentp)
struct user_info *uentp;
{
	struct useridx utmp;
	static char uline[80];
	char    pline[30];
	static int cnt;

	if (!uentp)
	{
		if (cnt)
			printchatline(uline);
		bzero(uline, 80);
		cnt = 0;
		return 0;
	}
	if (!uentp->active || !uentp->pid)
		return 0;
	if (curuser.userlevel < PERM_CLOAK && uentp->invisible)
		return 0;
	if (kill(uentp->pid, 0) == -1)
		return 0;
	get_record(USERIDX, &utmp, sizeof(utmp), uentp->uid);
	sprintf(pline, "%-12s %c%-10s", utmp.userid, uentp->invisible ? '#' : ' ',
		modestring(uentp->mode, uentp->destuid, 0, NULL));
	if (cnt < 2)
		strcat(pline, "   ");
	strcat(uline, pline);
	if (++cnt == 3)
	{
		cnt = 0;
		printchatline(uline);
		bzero(uline, 80);
	}
	return 0;
}

char   *msgto;
char   *umsgto;

chatlookup(uin)
struct user_info *uin;
{
	static int matchcnt;
	static char fullid[10], userid[15];

	if (!uin)
	{
		int     final = matchcnt;

		msgto = fullid;
		umsgto = userid;
		matchcnt = 0;
		return final;
	}
	if (uin->mode != uinfo.mode)
		return 0;
	if (!uin->active || kill(uin->pid, 0) == -1)
		return 0;
	if (uin->invisible && curuser.userlevel < PERM_CLOAK)
		return 0;
	if (!strncmp(msgto, uin->chatid, strlen(msgto)) ||
	    !strncmp(msgto, uin->userid, strlen(msgto)))
	{
		if (matchcnt > 0)
		{
			matchcnt = 0;
			return QUIT_LOOP;
		}
		matchcnt++;
		strcpy(fullid, uin->chatid);
		strcpy(userid, uin->userid);
		return 0;
	}
}

domsg(id, fd)
char   *id;
int     fd;
{
	char   *text;
	char    buf2[STRLEN], buf[STRLEN];
	int     verdict, retval;

	while (*id == ' ' || *id == '\t' || *id == '\n')
		id++;
	if (*id == '\0')
	{
		printchatline("** ���~: ��誺�W�r����");
		return;
	}
	text = advance(id);
	msgto = id;
	if (*text == '\0')
	{
		printchatline("** ���~: �W�r�̤��n���Ů�");
		return;
	}
	if (apply_record(ULIST, chatlookup, sizeof(struct user_info)) == QUIT_LOOP)
		verdict = -1;
	else
		verdict = chatlookup(NULL);
	switch (verdict)
	{
		case 0:
			printchatline("** ���~: �o�ӤH���b�o��");
			break;
		case -1:
			printchatline("** ERROR: that name is ambiguous; try using more letters");
			break;
		default:
			sprintf(buf, "/to %s %s %s", umsgto, uinfo.chatid, text);
			if (shutup == 0)
				retval = write(fd, buf, strlen(buf) + 1);
			sprintf(buf2, "%s> %s", msgto, text);
			printchatline(buf2);
	}
	msgto = NULL;
	if (retval > -1)
		retval = 0;
	return retval;
}

doignore(dest)
char   *dest;
{
	int     verdict;
	struct userec user;
	struct user_info inf;

	if (curuser.userlevel < 99)
	{
		printchatline("** ERROR: unknown special chat command");
		return;
	}

	if ((verdict = open(ULIST, O_RDONLY)) != -1)
	{
		while (read(verdict, &inf, sizeof(inf)) == sizeof(inf))
		{
			if (strcmp(dest, inf.userid) == 0)
			{
				sprintf(genbuf, "passwds/%s", dest);
				if ((verdict = open(genbuf, O_RDONLY)) != -1)
				{
					read(verdict, &user, sizeof(user));
					close(verdict);
					if (user.userlevel >= curuser.userlevel)
					{
						printchatline("** ERROR: Can not ignore this user!!");
						return;
					}
				}

				sprintf(genbuf, "/bin/touch /ignore/%s", dest);
				do_exec(genbuf, NULL);
				sprintf(genbuf, "/bin/touch /whoignore/%s-%s", curuser.userid, dest);
				do_exec(genbuf, NULL);
				close(verdict);
				return;
			}
		}
		close(verdict);
	}
	printchatline("** ���~: �o�ӤH���b�o��");
}

donick(newname, fd)
char   *newname;
int     fd;
{
	char   *p;
	char    buf[40];
	int     retval;

	while (*newname == ' ' || *newname == '\t' || *newname == '\n')
		newname++;
	if (*newname == '\0')
	{
		printchatline("** ���~: �ܤ֭n���ӦW�r");
		return;
	}
	for (p = newname; *p && *p != ' ' && *p != '\t' && *p != '\n'; p++);
	*p = '\0';
	if (strlen(newname) > 8)
		newname[8] = '\0';
	fixchatid(newname);
	if (!uinfo.invisible)
		sprintf(buf, "/nick %s %s", uinfo.chatid, newname);
	else
	{
		if (curuser.userlevel == 255)
			sprintf(buf, "/snick %s %s", uinfo.chatid, newname);
		else
			sprintf(buf, "/inick %s %s", uinfo.chatid, newname);
	}
	if (shutup == 1)
		printchatline(buf);
	else
		retval = write(fd, buf, strlen(buf) + 1);
	strcpy(uinfo.chatid, newname);
	update_utmp(&uinfo, uinfo.active);
	if (retval > -1)
		retval = 1;	/* cause t_chat to update chatid */
	return retval;
}

dochatcommand(cmd, fd)
char   *cmd;
int     fd;
{
	char   *endcmd;
	int     retval = 0;

	while (*cmd == ' ')
		cmd++;
	endcmd = cmd;
	while (*endcmd != ' ' && *endcmd != '\n' && *endcmd)
		endcmd++;
	if (*endcmd == '\0')
		*(endcmd + 1) = '\0';
	else
		*endcmd = '\0';
	if (!strcmp(cmd, "help") || !strcmp(cmd, "h"))
	{
		printchatline("�z�i�H�ϥγo�ǩR�O:");
		printchatline("  /help            - �����e�� [/h]");
		printchatline("  /who             - �����ǤH�b�o�� [/w]");
		printchatline("  /msg <�N�W> <������> - �e <������> �� <�N�W> [/m]");
		printchatline("  /pager           - ���� Pager [/p]");
		printchatline("  /nick <�︹>     - ���Ӻ︹ <�︹> [/n]");
		printchatline("  /me <���n����>   - �Фj�a�`�N�A����");
		printchatline("  /clear           - �M���e�� [/c]");
		if (curuser.userlevel > 99)
			printchatline("  /ignore <�N�W>     - �ϬY�H���L�@�� [/i]");
		if (curuser.userlevel >= PERM_CLOAK)
			printchatline("  /cloak           - ���� [/cl]");
		printchatline("  ctrl-d           - ���}");
	}
	else if (!strcmp(cmd, "who") || !strcmp(cmd, "w"))
		dowho();
	else if (!strcmp(cmd, "msg") || !strcmp(cmd, "m"))
		retval = domsg(endcmd + 1, fd);
	else if (!strcmp(cmd, "nick") || !strcmp(cmd, "n"))
	{
		retval = donick(endcmd + 1, fd);
	}
	else if (!strcmp(cmd, "pager") || !strcmp(cmd, "p"))
	{
		t_pager();
		printchatline(" ");
		if (!uinfo.pager)
		{
			printchatline("*** Pager turned off");
			inet_printf("%d OFF\r\n", PAGER_CHANGE);
		}
		else
		{
			printchatline("*** Pager turned on");
			inet_printf("%d ON\r\n", PAGER_CHANGE);
		}
	}
	else if (!strcmp(cmd, "cloak") || !strcmp(cmd, "cl"))
	{
		if (curuser.userlevel >= PERM_CLOAK)
		{
			a_cloak();
			if (!uinfo.invisible)
				printchatline("*** Cloak has been deactivated");
			else
				printchatline("*** Cloak has been activated");
		}
		else
			printchatline("** ERROR: unknown special chat command");
	}
	else if (!strcmp(cmd, "me"))
	{
		char    actionbuf[80], *firstlet = endcmd + 1;

		while (*firstlet == ' ' || *firstlet == '\n' || *firstlet == '\t')
			firstlet++;
		if (*firstlet != '\0')
		{
			sprintf(actionbuf, "%s %s", uinfo.chatid, endcmd + 1);
			if (shutup == 0)
				write(fd, actionbuf, strlen(actionbuf) + 1);
			else
				printchatline(actionbuf);	/* chang */
		}
		else
			printchatline("** ���~: �᭱�n�[�@�y��");
	}
	else if (!strcmp(cmd, "clear") || !strcmp(cmd, "c"))
	{
		char    bufr[80];

		RespondProtocol(CHAT_CLS);	/* changed by gcl */

		sprintf(bufr, "�� /help �i�ݻ����e��");
		printchatline(bufr);
	}
	else if (!strcmp(cmd, "ignore") || !strcmp(cmd, "i"))
		doignore(endcmd + 1);
	else
		printchatline("** ERROR: unknown special chat command");
	return retval;
}


int 
isprint2(ch)
char    ch;
{
	if (((unsigned int) ch) < 32)
		return 0;
	else
		return 1;
}

DelIsPrint2(Src)
char   *Src;
{
	int     i, j;
	char    c;

	i = j = 0;
	while ((c = Src[i]))
	{
		if (isprint2(c))
		{
			Src[j++] = Src[i];
		}
		i++;
	}
	Src[j] = '\0';
}

int 
a_cloak()
{
	uinfo.invisible = (uinfo.invisible) ? NA : YEA;
	update_utmp(&uinfo, uinfo.active);
}

