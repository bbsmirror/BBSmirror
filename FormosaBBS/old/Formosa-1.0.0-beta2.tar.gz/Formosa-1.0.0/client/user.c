/*
    ���إ����ߤ��s�j�ǹq�l�G�i��t�� NSYSU Bulletin Board System in R.O.C.
    Copyright (C) 1994,   cray@cc.nsysu.edu.tw      ����
                          carey@cc.nsysu.edu.tw     �P����
                          lmj@cc.nsysu.edu.tw       �����
                          alex@cc.nsysu.edu.tw      ���~��
*/
/*******************************************************************
 * ���{���ҩ� functions �j�����O ���� User ��
 *                                          lmj@cc.nsysu.edu.tw
 *******************************************************************/

#include "bbs.h"
#include "csbbs.h"
#include <sys/file.h>

/*******************************************************************
 * �ɤ��ܼƫŧi
 *******************************************************************/
int     net_sock = 0;

/*******************************************************************
 * user.c �禡�C��
 *******************************************************************/


/*******************************************************************
 * ���U�@��ϥΪ
 * �Ѽ�: ubuf -> if NULL, ���d�@�ӪŦ�N�n
 *               else �N�s user ��� (ubuf) �g�J�Ŧ�
 * �Ǧ^: �ϥΪ̽s��.
 *******************************************************************/
unsigned int 
new_user(ubuf)
struct userec *ubuf;
{
	int     fd;
	struct useridx uidx;
	char    homepath[PATHLEN];

	if (ubuf)
	{
		if ((fd = open(USERIDX, O_RDWR)) < 0)
		{
			RespondProtocol(NOT_ALLOW_NEW);
            return 0;
		}

		ubuf->uid = 0;
		for (;;)
		{
			ubuf->uid++;
			if (read(fd, &uidx, sizeof(uidx)) == sizeof(uidx))
        		if (!strcmp(uidx.userid, "new"))
					break;
			else
				break;
		}
		close(fd);

		if (ubuf->uid < 1)	/* debug */
		{
			RespondProtocol(NOT_ALLOW_NEW);
			return 0;
		}

		sethomefile(homepath, ubuf->userid, NULL);
		if (mkdir(homepath, 0755) == -1)
		{
			RespondProtocol(NOT_ALLOW_NEW);
            return 0;
		}

		sethomefile(passfile, ubuf->userid, UFNAME_PASSWDS);
		if ((fd = open(passfile, O_RDONLY)) > 0)
		{
			RespondProtocol(NOT_ALLOW_NEW);
			return 0;
		}
		close(fd);
		if ((fd = open(passfile, O_WRONLY | O_CREAT, 0600)) < 0)
		{
			RespondProtocol(NOT_ALLOW_NEW);
			return 0;
		}
		write(fd, ubuf, sizeof(struct userec));
		close(fd);

		if ((fd = open(USERIDX, O_RDWR | O_CREAT, 0644)) < 0)
		{
			unlink(passfile);
			RespondProtocol(NOT_ALLOW_NEW);
			return 0;
		}
		flock(fd, LOCK_EX);	/* lasehu */
/*
		if (lseek(fd, (long) ((ubuf->uid - 1) * sizeof(uidx)), SEEK_SET) != -1
		    && read(fd, &uidx, sizeof(uidx)) == sizeof(uidx)
		    && !strcmp(uidx.userid, "new")
		    && lseek(fd, (long) (-sizeof(uidx)), SEEK_CUR) != -1)
*/
		if (lseek(fd, (long)((ubuf->uid-1)*sizeof(uidx)), SEEK_SET) == -1)
		{
			RespondProtocol(NOT_ALLOW_NEW);
            return 0;
		}
		else
		{
			bzero(&uidx, sizeof(uidx));
			strcpy(uidx.userid, ubuf->userid);
			write(fd, &uidx, sizeof(uidx));
			flock(fd, LOCK_UN);	/* lasehu */
			close(fd);
#ifdef COMMENT			
			if ((fd = open(PASSFILE, O_WRONLY | O_CREAT, 0644)) > 0)
			{
				if (lseek(fd, (long) ((ubuf->uid - 1) * sizeof(USEREC)), SEEK_SET) != -1)
					write(fd, ubuf, sizeof(USEREC));
				close(fd);
			}
#endif
			return ubuf->uid;
		}
		close(fd);
		unlink(passfile);
		RespondProtocol(NOT_ALLOW_NEW);
		return 0;
	}
	else
	{
		unsigned int cnt = 0;

		if ((fd = open(USERIDX, O_RDWR | O_CREAT, 0644)) < 0)
		{
			RespondProtocol(NOT_ALLOW_NEW);
			return 0;
		}
		flock(fd, LOCK_EX);
		while (read(fd, &uidx, sizeof(uidx)) == sizeof(uidx))
		{	
#ifdef REALMAXUSERS				
			if (++cnt == REALMAXUSERS)
			{
				flock(fd, LOCK_UN);
				close(fd);
				RespondProtocol(NO_MORE_USER);
				return 0;
			}
#endif			
			if (uidx.userid[0] != '\0')
				continue;
			else
			{
				if (lseek(fd, (long) (-sizeof(uidx)), SEEK_CUR) != -1)
				{
					strcpy(uidx.userid, "new");
					write(fd, &uidx, sizeof(uidx));
					flock(fd, LOCK_UN);
					close(fd);
#if 0 
					if (cnt <= REALMAXUSERS && cnt >= 0)	/* debug */
						return cnt;
					else
						continue;
#endif
				}
				else
				{
					cnt = 0;
					break;
				}
			}
		}
		if (cnt == 0)
		{
			struct stat st;

			if (stat(USERIDX, &st) != -1 && st.st_size == 0
			    && lseek(fd, (long) 0, SEEK_SET) != -1)
			{
				strcpy(uidx.userid, "new");
				write(fd, &uidx, sizeof(uidx));
				cnt++;
			}
		}
#ifdef REALMAXUSERS		
		else if (cnt < REALMAXUSERS && cnt >= 0)
		{		/* debug */
			strcpy(uidx.userid, "new");
			write(fd, &uidx, sizeof(uidx));
			cnt++;
		}
#else
		else if (cnt >= 0)
		{		/* debug */
			strcpy(uidx.userid, "new");
			write(fd, &uidx, sizeof(uidx));
			cnt++;
		}
#endif
		else
			cnt = 0;
		flock(fd, LOCK_UN);
		close(fd);
		return cnt;
	}
}



/*******************************************************************
 * User Login
 * �Ѽ�: name -> userid
 *       passwd -> password (���X)
 *       from -> fromhost ( char [16] )
 * �Ǧ^: �u�W�s��.
 *******************************************************************/
unsigned int 
user_login(name, passwd, from)
char   *name, *passwd, *from;
{
	FILE   *fp;

	bzero(&curuser, sizeof(curuser));
	bzero(&uinfo, sizeof(uinfo));

	if (!get_passwd(&curuser, name)
	    || !checkpasswd(curuser.passwd, passwd))
		return 0;

	if (*curuser.passwd == '\0')	/* �űK�X */
		return 0;

	if ((uinfo.active = new_utmp(NULL)) <= 0)
		return 0;

	strcpy(uinfo.userid, name);
	strcpy(uinfo.username, curuser.username);
	uinfo.pid = getpid();
	uinfo.uid = curuser.uid;
	uinfo.invisible = (curuser.userlevel >= PERM_CLOAK
		&& (curuser.flags[0] & CLOAK_FLAG)) ?
		YEA : NA;
	uinfo.sockactive = NA;
	uinfo.sockaddr = 0;
	uinfo.destuid = 0;
	update_umode(LOGIN);
	uinfo.pager = !(curuser.flags[0] & PAGER_FLAG);
	uinfo.in_chat = NA;
	uinfo.sysuid = BBSBIN_UID;
	sethomefile(passfile, name, UFNAME_PASSWDS);
	curuser.numlogins++;
	if (curuser.userlevel < NORMAL_USER_LEVEL)
	{
		if (curuser.numlogins < NORMAL_USER_LEVEL)
			curuser.userlevel = curuser.numlogins;
		else
			curuser.userlevel = NORMAL_USER_LEVEL;
	}
	nsysu_lastlogin = curuser.lastlogin;
	strcpy(nsysu_lastfromhost, curuser.lasthost);
	strcpy(curuser.lasthost, from);
	strcpy(uinfo.from, from);
	sethomefile(genbuf, name, UFNAME_RECORDS);
	if ((fp = fopen(genbuf, "a")) != NULL)
	{
		fprintf(fp, "%s %s", from, ctime(&(curuser.lastlogin)));
		fclose(fp);
	}
	yank = (curuser.flags[0] & YANK_FLAG) ? YEA : NA;
	return curuser.uid;
}


/*******************************************************************
 * User Logout
 *******************************************************************/
void 
user_logout()
{
	int     ent = uinfo.active;
	struct userec tmpuser;

	if (ever_del_mail)
		pack_article(maildirect, YEA);
	if (yank)
		curuser.flags[0] |= YANK_FLAG;
	else
		curuser.flags[0] &= ~YANK_FLAG;

	if (get_passwd(&tmpuser, curuser.userid) > 0)
	{
#ifdef IDENT
#ifdef HAVE_BUG
		if (curuser.ident > 7 || curuser.ident < 0)
			curuser.ident = 0;
		if (tmpuser.ident <= 7)
#endif
			if (tmpuser.ident > curuser.ident)
				curuser.ident = tmpuser.ident;
#endif
#ifdef HAVE_BUG
		if (numposts < 0)
			numposts = 0;
		if (curuser.numposts < 0)
			curuser.numposts = 0;
		if (curuser.numlogins < 0)
			curuser.numlogins = 0;
#endif
#ifdef MULTIBBS
		if (tmpuser.numlogins > curuser.numlogins)
			curuser.numlogins = tmpuser.numlogins;
		if (tmpuser.numposts > curuser.numposts)
			curuser.numposts = tmpuser.numposts;
#endif
		curuser.numposts += numposts;
	}

	curuser.lastlogin = time(NULL);

	update_user(&curuser);
	update_user_passfile(&curuser);
	purge_utmp(&uinfo);
}



#ifdef MULTIBBS
int 
net_login(name, passwd, from)
char   *name, *passwd, *from;
{
	FILE   *fp;
	int     net_sock;

	bzero(&curuser, sizeof(curuser));
	bzero(&uinfo, sizeof(uinfo));
	if ((uinfo.active = new_utmp(NULL)) <= 0)
		return 0;
	if ((net_sock = create_net_socket()) < 0)
		return 0;
	if (get_passwd(&curuser, name))
	{
		nsysu_lastlogin = curuser.lastlogin;
		strcpy(nsysu_lastfromhost, curuser.lasthost);
	}
	net_printf(net_sock, "LOGIN %s %s %s\n", name, passwd, from);
	net_gets(net_sock, genbuf, sizeof(genbuf));
/* del by lasehu
	if(!strncmp(genbuf,"LOGINOK",7))
*/
	if (!strncmp(genbuf, "OK", 7))
	{
		net_printf(net_sock, "READY\n");
		if (read(net_sock, &curuser, sizeof(curuser)) != sizeof(curuser))
			return 0;
		if (*curuser.passwd == '\0')	/* �űK�X */
			return 0;
	}
	else
		return 0;
/* del by lasehu
	net_printf(net_sock,"GOODBYE\n");
*/
	close(net_sock);
	strcpy(uinfo.userid, name);
	uinfo.pid = getpid();
	uinfo.uid = curuser.uid;
	uinfo.invisible = (curuser.userlevel >= PERM_CLOAK
			   && (curuser.flags[0] & CLOAK_FLAG)) ?
		YEA : NA;
	uinfo.sockactive = NA;
	uinfo.sockaddr = 0;
	uinfo.destuid = 0;
/* lasehu
	update_umode(MMENU);
*/
	update_umode(LOGIN);
	uinfo.pager = !(curuser.flags[0] & PAGER_FLAG);
	uinfo.in_chat = NA;
	uinfo.sysuid = BBSBIN_UID;
	bzero(uinfo.chatid, sizeof(uinfo.chatid));
	sethomefile(passfile, name, UFNAME_PASSWDS);
	curuser.lastlogin = time(0);
	strcpy(uinfo.from, from);
	sprintf(genbuf, "records/%s", name);
	if ((fp = fopen(genbuf, "a")) != NULL)
	{
		fprintf(fp, "%s %s", from, ctime(&(curuser.lastlogin)));
		fclose(fp);
	}
	yank = (curuser.flags[0] & YANK_FLAG) ? YEA : NA;
	return curuser.uid;

}
#endif

