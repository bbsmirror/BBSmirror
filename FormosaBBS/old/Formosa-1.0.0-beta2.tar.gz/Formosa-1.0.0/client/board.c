
#include "bbs.h"
#include "csbbs.h"


#define ZAPRC_MAXSIZE   (512)
#define ZAPRC_MAXNUM    (ZAPRC_MAXSIZE*8)

unsigned char zapped[ZAPRC_MAXSIZE];

int     zaprc_readid;
unsigned char zaprc_readbit;

struct bword *topb = NULL, *lastb = NULL;

MakeZapList()
{
	char    filename[PATHLEN];
	int     fd;

	memset(zapped, 0, sizeof(zapped));

	sethomefile(filename, curuser.userid, UFNAME_ZAPRC);
	if ((fd = open(filename, O_RDONLY)) > 0)
	{
		if (read(fd, zapped, sizeof(zapped)) == sizeof(zapped))
		{
			close(fd);
			return 0;
		}
		close(fd);
	}
	return -1;
}


UpdateZapFile()
{
	char    filename[PATHLEN];
	int     fd;

	sethomefile(filename, curuser.userid, UFNAME_ZAPRC);
	if ((fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644)) > 0)
	{
		if (write(fd, zapped, sizeof(zapped)) == sizeof(zapped))
		{
			close(fd);
			return 0;
		}
		close(fd);
	}
	return -1;
}


IsZappedBoard(bid)
int     bid;
{
	if (bid <= 0 || bid > ZAPRC_MAXNUM)
		return 0;
	mymod(bid, ZAPRC_MAXSIZE, &zaprc_readid, &zaprc_readbit);
	if (zapped[zaprc_readid] & zaprc_readbit)
		return 1;
	return 0;
}

int 
check_team(name, board)
char   *name;
char   *board;
{
	FILE   *f;
	int     chk = -1;

	if (curuser.userlevel == 255)
		return 0;
	if (strcmp(board, "bbs-team") != 0)
		return -1;
	if ((f = fopen("/BBS_TEAM", "r")) == NULL)
		return -1;
	while (fgets(genbuf, 24, f) != NULL)
	{
		if (strncmp(genbuf, name, strlen(name)) != 0)
			continue;
		chk = 0;
		break;
	}
	fclose(f);

	return chk;
}

int 
can_see_board(fh)
struct boardheader *fh;
{
	if (fh->level == ANNOUNCE_BOARD_LEVEL)
		return 0;
	else if ((fh->level == ADMIN_BOARD_LEVEL && curuser.userlevel < 100))
		return -1;
	else if (fh->level == INVISIBLE_BOARD_LEVEL && check_team(curuser.userid, fh->filename) != 0)
		return -1;
/*---		
	else if (fh->level == SPECIAL_BOARD_LEVEL)
		return -1;
*/		
	else
		return 0;


}

addto_blist(fh)
struct boardheader *fh;
{
	struct BoardList *new;
	struct bword *bnew;
	char    type;

	bnew = (struct bword *) malloc(sizeof(struct bword));
	bzero(bnew, sizeof(struct bword));
	new = (struct BoardList *) malloc(sizeof(struct BoardList));
	bzero(new, sizeof(struct BoardList));

	bnew->word = new;
	bnew->next = NULL;
	if (topb == NULL)
		topb = bnew;
	bnew->last = lastb;
	if (lastb != NULL)
		lastb->next = bnew;
	lastb = bnew;

	new->name = (char *) malloc(strlen(fh->filename) + 1);
	strcpy(new->name, fh->filename);

	StrDelR(fh->owner);
	if (fh->owner[0] == '\0')
	{
		fh->owner[0] = '#';
		fh->owner[1] = 0;
	}
	new->owner = (char *) malloc(strlen(fh->owner) + 1);
	strcpy(new->owner, fh->owner);

	new->title = (char *) malloc(strlen(fh->title) + 1);
	strcpy(new->title, fh->title);

	type = fh->type;
	if (type != 'B' && type != 'I' && type != 'O')
		type = '#';
	new->type = type;
	new->bid = fh->bid;

	new->level = fh->level;
	new->class = fh->class;
}


make_blist()
{
	int     fd;
	struct boardheader bh;

	if ((fd = open(BOARDS, O_RDONLY)) < 0)
		return;

	while (read(fd, &bh, sizeof(bh)) == sizeof(bh))
	{
		if (bh.filename[0] == '\0')	/* NULL board name */
			continue;
		if (can_see_board(&bh) < 0)
			continue;
		addto_blist(&bh);
	}
	close(fd);
}


struct bword *
check_board_list()
{
	if (!topb)		/* �S���@�L!! */
		make_blist();

	return topb;
}


struct BoardList *
search_board(bname)
char   *bname;
{
	struct bword *bp;
	struct BoardList *blist;

	if (bname[0] == '\0')
		return NULL;

	bp = topb;
	while (bp)
	{
		blist = bp->word;
		if (!strcmp(blist->name, bname))
			return blist;	/* find it!! */
		bp = bp->next;
	}
	return NULL;
}

int 
can_post_board(blist)
struct BoardList *blist;
{
	int     ret = 1;

	if (blist->level == NEWS_BOARD_LEVEL && curuser.userlevel != 255)
		ret = 0;	/* �u�� News */
	else if (blist->level == ANNOUNCE_BOARD_LEVEL && curuser.userlevel != 255)
		ret = 0;	/* �u���t�κ޲z�� */
#if 0
	else if (blist->level == BM_BOARD_LEVEL && curuser.userlevel != 255
		 && strcmp(blist->owner, curuser.userid))	/* �D�������D */
		ret = 0;
#endif		
	else if (curuser.userlevel < blist->level &&
		 blist->level != INVISIBLE_BOARD_LEVEL)	/* ���Ť��� */
		ret = 0;

	return ret;
}

/*****************************************************
 *   function boardname type
 *
 *          type=0 board
 *               1 treasure
 *				��ܧG�i
 *****************************************************/
SelectBoard(bname, type)
char   *bname;
int     type;
{
	struct BoardList *blist;
	int     para_num, path_data[10], paths, i, ifpath = FALSE;
	char   *check, *p;
	int     fp;
	struct fileheader fileinfo;


	if (bname == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return FALSE;
	}

	if (type != 0 && type != 1)
	{
		RespondProtocol(SYNTAX_ERROR);
		return 0;
	}

	if (check_board_list() == NULL)
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return 0;
	}

	blist = search_board(bname);
	if (!blist)
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return 0;
	}

	if (type)
	{
		para_num = Get_paras();
		ifpath = FALSE;
		for (i = para_num; i >= 1; i--)
		{
			check = Get_para_string(i);
			if ((strcmp(check, "PATH") == 0) || (strcmp(check, "path") == 0))
			{
				ifpath = TRUE;
				break;
			}
		}
	}

	if (i == para_num-1)
		ifpath = FALSE;

	CurBList = blist;
	sprintf(boarddirect, "/%s/%s/%s",
		(type) ? "treasure" : "boards", bname, DIR_REC);
	if (ifpath)
	{
		paths = 0;
		for (i = i + 1; i < para_num; i++)
		{
			path_data[paths] = Get_para_number(i);
			if (path_data[paths] == 0)
			{
				RespondProtocol(WORK_ERROR);
				return FALSE;
			}
			paths++;
		}

		for (i = 0; i < paths; i++)
		{
			if ((fp = open(boarddirect, O_RDWR)) < 0)
			{
				RespondProtocol(WORK_ERROR);
				return FALSE;
			}
			lseek(fp, FH_SIZE * (path_data[i] - 1), SEEK_SET);
			read(fp, &fileinfo, FH_SIZE);
			close(fp);
			if (fileinfo.accessed != FILE_TREA)
			{
				RespondProtocol(WORK_ERROR);
				return FALSE;
			}
			p = strrchr(boarddirect, '/');
			sprintf(p, "/%s/%s", fileinfo.filename, DIR_REC);
		}
	}
	return TRUE;
}

/*****************************************************
 *  Syntax: LIST [type]
 *
 *          type=0 all
 *               1 none zap only
 *
 *  Respond Type:  boardname zap ifpost news level manager title
 *
 *****************************************************/

DoListBoard()
{
	int     type;
	struct bword *bp;
	struct BoardList *blist;
	int     ifzap, ifpost;

	type = Get_para_number(1);
	if (type != 0 && type != 1)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	if (check_board_list() == NULL)
	{
		RespondProtocol(NO_ANY_BOARD);
		return;
	}

	RespondProtocol(OK_CMD);
	bp = topb;
	net_cache_init();
	MakeZapList();
	while (bp)
	{
		blist = bp->word;
		ifzap = IsZappedBoard(blist->bid);
		ifpost = can_post_board(blist);
		if (!(ifzap && type))
		{
			sprintf(MyBuffer, "%s\t%d\t%d\t%c\t%d\t%s\t%s\r\n",
				blist->name, ifzap, ifpost,
				blist->type, blist->level,
			   blist->owner, blist->title /* ,blist->class */ );
			net_cache_write(MyBuffer, strlen(MyBuffer));
		}
		bp = bp->next;
	}
	net_cache_write(".\r\n", 3);
	net_cache_refresh();
}

/*****************************************************
 *  Syntax: ZAP boardname
 *
 *****************************************************/

DoZap()
{
	char   *bname;
	int     fd;
	struct BoardList *blist;

	bname = Get_para_string(1);
	if (bname == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	if (check_board_list() == NULL)
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}

	if (!(blist = search_board(bname)))
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}

	if (blist->bid <= 0 || blist->bid > ZAPRC_MAXNUM)
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}
	mymod(blist->bid, ZAPRC_MAXSIZE, &zaprc_readid, &zaprc_readbit);
	if (IsZappedBoard(blist->bid))
		zapped[zaprc_readid] &= ~zaprc_readbit;
	else
		zapped[zaprc_readid] |= zaprc_readbit;
	UpdateZapFile();
	RespondProtocol(OK_CMD);
}

/***********************************************************
*		BRDWELCHK boardname
*			�i���e���̫�����
************************************************************/
DoChkBoardWelcome()
{
	char   *bname;
	char    path[STRLEN];
	struct stat st;

	bname = Get_para_string(1);
	if (bname == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	sprintf(path, "/boards/%s/%s", bname, BM_WELCOME);
	if (stat(path, &st) < 0)
		inet_printf("%d\t0\r\n", ANN_TIME);
	else
		inet_printf("%d\t%ld\r\n", ANN_TIME, st.st_mtime);

}


/***********************************************************
*		BRDWELGET boardname
*			���o�i���e��
************************************************************/
DoGetBoardWelcome()
{
	char   *bname;
	char    path[STRLEN];
	struct BoardList *blist;
	struct stat st;

	bname = Get_para_string(1);
	if (bname == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	if (check_board_list() == NULL)
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}

	blist = search_board(bname);
	if (!blist)
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}

	sprintf(path, "/boards/%s/%s", blist->name, BM_WELCOME);
	if (stat(path, &st) || st.st_size == 0)
		RespondProtocol(NO_BOARD_WELCOME);
	else
		SendArticle(path);
}

/**************************************************************
*		BRDWELPUT boardname
*			�e�X�i���e��
***************************************************************/
DoPutBoardWelcome()
{
	char   *bname;
	struct BoardList *blist;
	char    path[STRLEN];
	char    temp[STRLEN];
	struct stat st;

	bname = Get_para_string(1);
	if (bname == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	if (check_board_list() == NULL)
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}

	blist = search_board(bname);
	if (!blist)
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}

	if (strcmp(curuser.userid, blist->owner) &&
	    (curuser.userlevel != 255))
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	sprintf(path, "/boards/%s/%s", blist->name, BM_WELCOME);

	if (stat(path, &st) >= 0 && unlink(path) < 0)
	{			/* kill old */
		RespondProtocol(WORK_ERROR);
		return;
	}

	sprintf(temp, "/tmp/%-s.%-d", curuser.userid, time(0));
	if (!RecvArticle(temp, NA, NULL, NULL) && !mycp(temp, path))
		RespondProtocol(OK_CMD);
	else
		RespondProtocol(WORK_ERROR);
}

/***********************************************************
*		BRDWELKILL boardname
*			�R���i���e��
************************************************************/
DoKillBoardWelcome()
{
	char   *bname;
	struct BoardList *blist;
	char    path[STRLEN];
	struct stat st;

	bname = Get_para_string(1);
	if (bname == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}

	if (check_board_list() == NULL)
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}

	blist = search_board(bname);
	if (!blist)
	{
		RespondProtocol(BOARD_NOT_EXIST);
		return;
	}

	if (strcmp(curuser.userid, blist->owner) &&
	    (curuser.userlevel != 255))
	{
		RespondProtocol(WORK_ERROR);
		return;
	}

	sprintf(path, "/boards/%s/%s", blist->name, BM_WELCOME);

	if (stat(path, &st) >= 0 && unlink(path) < 0)
		RespondProtocol(WORK_ERROR);
	else
		RespondProtocol(OK_CMD);
}


/* del by lasehu
void
setuserfile(buf, filename)
char   *buf, *filename;
{
	sprintf(buf, "%s/%s", filename, curuser.userid);
}
*/



