
#include "bbs.h"
#include "csbbs.h"

extern struct UTMPFILE *utmpshm;

#define DEBUG


void
update_utmp()
{
	register int actent = (uinfo.active) - 1;

#ifdef DEBUG
	if (actent < 0 || actent >= MAXACTIVE)
	{
		bbslog("CS-DEBUG", "update_utmp() overflow");
		exit(-1);
	}
#endif
	memcpy((utmpshm->uinfo) + (actent), &uinfo, sizeof(USER_INFO));
}


void
update_umode(mode)
int     mode;
{
	uinfo.mode = mode;
	update_utmp();		/* lasehu */
}


void
purge_utmp(upent)
USER_INFO *upent;
{
	register int actent = (upent->active) - 1;

#ifdef DEBUG
	if (actent < 0 || actent >= MAXACTIVE)
	{
		bbslog("CS-DEBUG", "purge_utmp() overflow");
		exit(-1);
	}
#endif
	memset((utmpshm->uinfo) + actent, 0, sizeof(USER_INFO));
#ifndef NSYSUBBS	
	if (utmpshm->number)
		utmpshm->number--;
#endif		
#ifdef HAVE_BUG
	if (utmpshm->number < 0)
		utmpshm->number = 0;
#endif
}




int
new_utmp()
{
	extern int errno;
	register time_t now;
	register int i, spoint;
	register pid_t pid;
	register USER_INFO *uentp;

	resolve_utmp();
	now = time(NULL);
#ifndef NSYSUBBS
	now = time(NULL) - 228;
	if (now > utmpshm->uptime)
		utmpshm->busystate = 0;

	while (utmpshm->busystate)
	{
		sleep(1);
	}
	utmpshm->busystate = 1;

/* ------------------------------- */
/* for ���F�ǻ�: �C 228 ����s�@�� */
/* ------------------------------- */
	 /* ���F�ǻ��� onlinesrv �ѨM�A�o�̤��n�� -- lmj */
	if (now > utmpshm->uptime)
	{
		uentp = utmpshm->uinfo;
		for (i = now = errno = 0; i < USHM_SIZE; i++, uentp++)
		{
			if (uentp->pid > 2)
			{
				if ((kill(uentp->pid, 0) == -1) && (errno == ESRCH))
				{
					/* don't need reset struct, just pid only -- lmj
					memset(uentp, 0, sizeof(USER_INFO));
					*/
					uentp->pid = 0;
					errno = 0;
				}
				else
					now++;
			}
		}
		utmpshm->number = now;
		time(&utmpshm->uptime);
	}
#endif
	pid = getpid();		/* lasehu */

	spoint = ((now + pid) % 10) * (MAXACTIVE/10);
	uentp = &(utmpshm->uinfo[spoint]);
#if 0	
	uentp = utmpshm->uinfo;
	for (i = 0; i < USHM_SIZE; i++, uentp++)
#endif
	for (i = spoint; i < USHM_SIZE; i++, uentp++)	
	{
		if (uentp->pid < 3)	/* lasehu ?*/ /* lmj */
		{
			uentp->pid = pid;
#ifndef NSYSUBBS
			utmpshm->number++; 
			utmpshm->busystate = 0;
			time(&utmpshm->uptime);	/* lasehu */
#endif			
			return (i + 1);	/* lasehu */
		}
	}
	
	uentp = utmpshm->uinfo;
	for (i = 0; i < spoint; i++, uentp++)
	{
		if (uentp->pid < 3)	/* lasehu ?*/ /* lmj */
		{
			uentp->pid = pid;
#ifndef NSYSUBBS
			utmpshm->number++;
			utmpshm->busystate = 0;
			time(&utmpshm->uptime);	/* lasehu */
#endif
			return (i + 1);	/* lasehu */
		}
	}
#ifndef NSYSUBBS
	utmpshm->busystate = 0;
#endif	
	sleep(1);
	exit(1);
}


/*******************************************************************
 *
 * �ˬd���� login
 *		�W�L����N�屼�@��
 *******************************************************************/
int
count_multi_login(uentp)
struct user_info *uentp;
{
	static int i = 0;

	if (uentp->uid != uinfo.uid)
		return;
	i++;
	if (uentp->pid != uinfo.pid && uentp->userid[0] != '\0')
	{
		multi++;
		if (multi > MULTILOGINS)
		{
			if (uentp->pid > 2)	/* lasehu */
			{
				kill(uentp->pid, SIGKILL);
				purge_utmp(uentp);	/* bug fixed */
			}
			multi--;
		}
	}
}


void
multi_user_check()
{
	if (apply_ulist(count_multi_login) == -1)
		return;
}





