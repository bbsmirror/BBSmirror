/*
 * ���{���ΨӨ��N inetd ���� tcp connection request
 * ���F�t�Φw���Ӧs�b
 * �Фp�߳]�w /etc/hosts.ip
 *									-- lmj@cc.nsysu.edu.tw
 */

/*
 * �t�A�ɰ
 */
#include <sys/param.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/file.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <netdb.h>
#include <syslog.h>
#include <pwd.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
/*--- lasehu
#ifndef AIX
#include <sys/pathname.h>
#endif
*/

#include "csbbs.h"


/*
 * �Ѧ��ɸ��|�w�q
 */
#define	PATH_DEVNULL	"/dev/null"
#define	HOST_ALLOW	"/etc/hosts.ip"
#if	defined(SOLARIS) || defined(AIX)
#define DEFAULT_TCPNETD	"/usr/sbin/tcpnetd"
#else
#define DEFAULT_TCPNETD	"/usr/etc/tcpnetd"
#endif


/*
 * �~����ƫŧi
 */
extern int errno;

struct userec curuser, user;
struct user_info uinfo;
struct fileheader tmp_fh;

char    genbuf[4096];
char    passfile[IDLEN + 20];
time_t  nsysu_lastlogin;
char    nsysu_lastfromhost[16];
time_t  timeout_seconds;
int     io_timeout_sec;
char   *maildirect = NULL, boarddirect[STRLEN] = "", treasuredirect[STRLEN] = "";
unsigned int numposts = 0;
short   in_board = 1;
short   yank = NA;
short   talkrequest = NA;
short   get_message = NA;
short   ever_del_mail = NA;
int     debug = NA;

int     socketfd;

int     client_version = 20;	/* default 2.0 */

int     ifSayHello = NA;
int     ifPass = NA;

struct BoardList *CurBList;

char    from[16];
char    oldpass[PASSLEN];

int	multi;

extern void TalkPage();
extern void write_request();

void 
TimeOut()
{
	if (ifPass)
		user_logout();
	ReleaseSocket();
	exit(1);
}

void 
AbortBBS()
{
	if (ifPass)
		user_logout();
	ReleaseSocket();
	exit(1);
}

ReleaseSocket()
{
	shutdown(0, 2);
	shutdown(1, 2);
}

/*------------------------------------------------------------------------
 * check_host_allow  - �ˬd�ϥΪ̨ӳB
 *------------------------------------------------------------------------
 */
int 
cmp_char(c1, c2)
char    c1, c2;
{
	if (c1 == c2)
		return 0;
	else if (c1 >= 'A' && c1 <= 'Z' && c2 >= 'a' && c2 <= 'z' &&
		 (c2 - c1) == 0x20)
		return 0;
	else if (c2 >= 'A' && c2 <= 'Z' && c1 >= 'a' && c1 <= 'z' &&
		 (c1 - c2) == 0x20)
		return 0;
	else
		return -1;
}


int 
check_from(from)
char   *from;
{
	FILE   *fp;
	char   *s1, *s2, buf[80];

	if (!from || !(fp = fopen(HOST_ALLOW, "r")))
		return -1;
	while (fgets(buf, 79, fp))
	{
		if (buf[0] == '#' || buf[0] == '\n')
			continue;
		if (s1 = (char *) strrchr(buf, '\n'))
			*s1-- = '\0';
		else
			s1 = buf + strlen(buf) - 1;
		if (buf[0] == '*')
		{
			for (s2 = from + strlen(from) - 1; s2 >= from && s1 > buf; s1--, s2--)
				if (cmp_char(*s1, *s2))
					break;
			if (s1 == buf)
			{
				fclose(fp);
				return 0;
			}
		}
		else
		{
			for (s1 = buf, s2 = from; *s1 != '\0' && s2 != '\0'; s1++, s2++)
				if (cmp_char(*s1, *s2))
					break;
			if (*s1 == '\0')
			{
				fclose(fp);
				return 0;
			}
		}
	}
	fclose(fp);
	return -1;
}




/*------------------------------------------------------------------------
 * reaper - clean up zombie children
 *------------------------------------------------------------------------
 */
static void
reaper()
{
#if	defined(SOLARIS) || defined(AIX)
	int     status;

#else
	union wait status;

#endif				/* SOLARIS */

#if	defined(AIX)
	while (wait3(&status, WNOHANG, (struct ResourceUsage *) 0) > 0)
#else
	while (wait3(&status, WNOHANG, (struct rusage *) 0) > 0)
#endif
		 /* empty */ ;
	(void) signal(SIGCHLD, reaper);
}



/*
 * Main
 *
 */

void 
main(argc, argv)
int     argc;
char   *argv[];
{
	int     aha, on = 1, maxs;
	fd_set  ibits;
	struct sockaddr_in ifrom, sin;
	int     s, ns;
	short   check = 1;
	struct timeval wait;
	char    buf[80], *pp;

	if ((argc > 1) && (!strcmp(argv[1], "d")))
		debug = YEA;

	if (!debug)
	{
		if (fork() != 0)
			exit(0);

		if ((pp = strrchr(argv[0], '/')))
			pp++;
		else
			pp = argv[0];
		if (!strcmp(pp, "tcpnetd.all"))
			check = 0;
		check = 0;	/* �����ˬdhost from */

		for (aha = 64; aha >= 0; aha--)
			close(aha);

		if ((aha = open(PATH_DEVNULL, O_RDONLY)) < 0)
			exit(1);
		if (aha)
		{
			dup2(aha, 0);
			close(aha);
		}
		dup2(0, 1);
		dup2(0, 2);

		sprintf(buf, "/tmp/csbbs.7716");
		unlink(buf);
		if ((aha = open(buf, O_WRONLY | O_CREAT, 0644)) > 0)
		{
			sprintf(buf, "%-d\n", getpid());
			write(aha, buf, strlen(buf));
			close(aha);
		}

		signal(SIGHUP, SIG_IGN);
		signal(SIGCHLD, reaper);

		if ((s = socket(AF_INET, SOCK_STREAM, 0)) < 0)
			exit(1);

		setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (char *) &on, sizeof(on));
#if defined(IP_OPTIONS) && defined(IPPROTO_IP)
		setsockopt(s, IPPROTO_IP, IP_OPTIONS, (char *) NULL, 0);
#endif

		sin.sin_family = AF_INET;
		sin.sin_addr.s_addr = INADDR_ANY;
		sin.sin_port = htons(CSBBS_SERVER_PORT);

		if (bind(s, (struct sockaddr *) & sin, sizeof sin) < 0 ||
#if	defined(SOLARIS) || defined(AIX)
		    listen(s, 256) < 0)
#else
		    listen(s, 5) < 0)
#endif
			exit(1);

		if (chroot(HOMEBBS) || chdir("/"))
			exit(1);

		if (getuid() != BBS_UID)
		{
#ifndef HP_UX
			seteuid(0);
#endif
			setgid(BBS_GID);
			setuid(BBS_UID);
		}

		aha = sizeof(ifrom);
		maxs = s + 1;
		wait.tv_sec = 5;
		wait.tv_usec = 0;

		while (1)
		{
			FD_ZERO(&ibits);
			FD_SET(s, &ibits);
			if ((on = select(maxs, &ibits, 0, 0, &wait)) < 1)
			{
				if ((on < 0 && errno == EINTR) || on == 0)
					continue;
				else
				{
					shutdown(s, 2);
					close(s);
					if (fork())
						exit(0);
					else
						execv((*(argv[0]) == '/') ? argv[0] : DEFAULT_TCPNETD,
						      argv);
				}
			}
			if (!FD_ISSET(s, &ibits))
				continue;
			if ((ns = accept(s, (struct sockaddr *) & ifrom, &aha)) < 0)
				continue;
			else
			{

				switch (fork())
				{

					case -1:
						close(ns);
						break;

					case 0:
						{
							char   *host, *inet_ntoa();

#ifdef	RESOLVE_HOSTNAME
							struct hostent *hp;

#endif

							signal(SIGCHLD, SIG_IGN);
							close(s);
							dup2(ns, 0);
							close(ns);
							dup2(0, 1);
							dup2(0, 2);
							on = 1;
							setsockopt(0, SOL_SOCKET, SO_KEEPALIVE,
								   (char *) &on, sizeof(on));
#ifdef	RESOLVE_HOSTNAME
							if ((hp = gethostbyaddr((char *) &(ifrom.sin_addr),
										sizeof(struct in_addr),
							 ifrom.sin_family)))
								host = hp->h_name;
							else
#endif
								host = inet_ntoa(ifrom.sin_addr);

							if (check && check_from(host))
							{
								shutdown(0, 2);
								exit(0);
							}

							strcpy(from, host);
							signal(SIGALRM, TimeOut);
							signal(SIGTERM, AbortBBS);
							signal(SIGUSR1, TalkPage);
						/* signal(SIGUSR2,SIG_IGN); */
							signal(SIGUSR2, write_request);	/* �e�T�� */
							Formosa();

							shutdown(0, 2);
							exit(0);
						}
					default:
						close(ns);
				}
			}
		}
	}
	else
	{
		printf("Process enter DEBUG mode now!!\n");
		if (chroot(HOMEBBS) || chdir("/"))
			exit(1);

		if (getuid() != BBS_UID)
		{
#ifndef HP_UX
			seteuid(0);
#endif
			setgid(BBS_GID);
			setuid(BBS_UID);
		}
		strcpy(from, "local");
		signal(SIGALRM, TimeOut);
		signal(SIGHUP, AbortBBS);
		signal(SIGURG, AbortBBS);
		signal(SIGTERM, AbortBBS);
		signal(SIGQUIT, AbortBBS);
		signal(SIGINT, AbortBBS);
		signal(SIGTSTP, AbortBBS);
		signal(SIGUSR1, TalkPage);
		signal(SIGUSR2, write_request);	/* �e�T�� */
		Formosa();
	}
}
