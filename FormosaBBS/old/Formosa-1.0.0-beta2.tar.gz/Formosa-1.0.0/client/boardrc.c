
#include "bbs.h"
#include "csbbs.h"

/*
 * �Ҧ� .c �� define BRC ������, ���O���F�H boardrc �Ө��N�¦��O��Ū�H ���A
 * �Ӯ��O�w�ЪŶ�)
 */


char    currboard[STRLEN] = "�|����w";	/* lasehu */

int     brc_size, brc_changed = 0;
unsigned char brc_list[BRC_MAXNUM];
time_t  brc_rtime = 0; /* ? */

char    brc_buf[BRC_MAXSIZE];
char    brc_name[BRC_STRLEN];

unsigned char     brc_readbit;
int               brc_readid;


static char *
brc_getrecord(ptr, name, list, rtime)
char   *ptr, *name;
unsigned char    *list;
time_t *rtime;
{
    strncpy(name, ptr, BRC_STRLEN);
    ptr +=  BRC_STRLEN;    
    memcpy(list, ptr, BRC_MAXNUM * sizeof(unsigned char));
    ptr += BRC_MAXNUM * sizeof(unsigned char);    
    memcpy(rtime, ptr, 1 * sizeof(time_t));
    ptr += 1 * sizeof(time_t);    

    return ptr;
}


static char *
brc_putrecord(ptr, name, list, rtime)
char   *ptr, *name;
unsigned char   *list;
time_t *rtime;
{
    strncpy(ptr, name, BRC_STRLEN);
    ptr +=  BRC_STRLEN;
    memcpy(ptr, list, BRC_MAXNUM * sizeof(unsigned char));
    ptr += BRC_MAXNUM * sizeof(unsigned char);
    memcpy(ptr, rtime, 1 * sizeof(time_t));
    ptr += 1 * sizeof(time_t);
    
    return ptr;
}


void
brc_update()
{
    if (brc_changed)
    {
	char    dirfile[PATHLEN], *ptr;
	char    tmp_buf[BRC_MAXSIZE - BRC_ITEMSIZE], *tmp;
	char    tmp_name[BRC_STRLEN];
	int     tmp_list[BRC_MAXNUM];
	int     fd, tmp_size;
	time_t  tmp_rtime;

	ptr = brc_buf;
    ptr = brc_putrecord(ptr, brc_name, brc_list, &brc_rtime);
	sethomefile(dirfile, curuser.userid, UFNAME_BOARDRC);
	if ((fd = open(dirfile, O_RDWR | O_CREAT, 0644)) > 0)
	{
	    tmp_size = read(fd, tmp_buf, sizeof(tmp_buf));
	    close(fd);
	}
	else
	{
	    tmp_size = 0;
	}

	tmp = tmp_buf;
	while (tmp < &tmp_buf[tmp_size] && (*tmp >= ' ' && *tmp <= 'z'))
	{
	    tmp = brc_getrecord(tmp, tmp_name, tmp_list, &tmp_rtime);
	    if (strncmp(tmp_name, currboard, BRC_STRLEN))
		ptr = brc_putrecord(ptr, tmp_name, tmp_list, &tmp_rtime);
	}
	brc_size = (int) (ptr - brc_buf);

	if ((fd = open(dirfile, O_WRONLY | O_CREAT, 0644)) > 0)
	{
	    ftruncate(fd, 0);
	    write(fd, brc_buf, brc_size);
	    close(fd);
	}
	brc_changed = 0;
    }
}


int
brc_initial(boardname)
char   *boardname;
{
    char    dirfile[PATHLEN], *ptr;
    int     fd;

    if (!strcmp(currboard, boardname))
		return;

    brc_update();
    strcpy(currboard, boardname);
    if (brc_buf[0] == '\0')	/* ? */
    	{
		sethomefile(dirfile, curuser.userid, UFNAME_BOARDRC);
		if ((fd = open(dirfile, O_RDONLY)) > 0)
			{
	    	brc_size = read(fd, brc_buf, sizeof(brc_buf));
	    	close(fd);
			}
		else
			{
	    	brc_size = 0;
			}
    	}
    ptr = brc_buf;
    while (ptr < &brc_buf[brc_size] && (*ptr >= ' ' && *ptr <= 'z'))
    	{
		ptr = brc_getrecord(ptr, brc_name, brc_list, &brc_rtime);
		if (!strncmp(brc_name, currboard, BRC_STRLEN))
	    	return;
    	}
    strncpy(brc_name, boardname, BRC_STRLEN);
    memset(brc_list, 0, sizeof(brc_list));
    brc_rtime = time(0);	/* ? */
    brc_changed = 1; 	/* ? */
    return;
}


void
brc_addlist(artno)
int artno;
{

    if (artno <= 0 || artno > BRC_REALMAXNUM)	/* ? */
		return;
    
    mymod(artno, BRC_MAXNUM, &brc_readid, &brc_readbit);

    brc_list[brc_readid] |= brc_readbit;
    brc_changed = 1;
}


int
brc_unread(artno)
int artno;
{
    if (artno <= 0 || artno > BRC_REALMAXNUM)
		return 1;

    mymod(artno, BRC_MAXNUM, &brc_readid, &brc_readbit);	
    
    if (brc_list[brc_readid] & brc_readbit)
		return 0;
    return 1;
}

int
refresh_brc()
{
	int fd;
	time_t new_rtime;
	struct boardheader sbh;

	if ((fd = open(BOARDS, O_RDONLY)) > 0)
		{ 
		while (read(fd, &sbh, sizeof(sbh)) == sizeof(sbh))
			{
			if (!strcmp(sbh.filename, CurrentBoard))
				{
				new_rtime = sbh.rewind_time;
				break;
				}
			}
		close(fd);
		}
    
    if (new_rtime < 0)
        new_rtime = 0;
    if (brc_rtime < new_rtime)
    {
	memset(brc_list, 0, BRC_MAXNUM/2);
	brc_rtime = new_rtime;	
	brc_changed = 1;
    }

    return;
}
