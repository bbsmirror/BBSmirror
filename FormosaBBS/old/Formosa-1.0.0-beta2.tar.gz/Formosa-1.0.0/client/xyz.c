
#include "bbs.h"
#include "csbbs.h"

char   *genpasswd();

/***********************************************************
*		PLANGET
*			���o�{�buser���W����
************************************************************/
DoGetPlan()
{
	char    buf[STRLEN];
	struct stat st;

	sethomefile(buf, curuser.userid, UFNAME_PLANS);
	if (stat(buf, &st) < 0)
		RespondProtocol(NO_PLAN);
	else
		SendArticle(buf);
}

/************************************************************
*		PLANKILL
*			�R��user�W����
*************************************************************/
DoKillPlan()
{
	char    buf[STRLEN];
	struct stat st;

	sethomefile(buf, curuser.userid, UFNAME_PLANS);

	if (stat(buf, &st) >= 0 && unlink(buf) < 0)
		RespondProtocol(WORK_ERROR);
	else
		RespondProtocol(OK_CMD);
}

/**************************************************************
*		PLANPUT
*			�e�XUSER���W����
***************************************************************/
DoSendPlan()
{
	char    buf[STRLEN], fname[STRLEN];
	struct stat st;


	sethomefile(buf, curuser.userid, UFNAME_PLANS);
	if (stat(buf, &st) >= 0 && unlink(buf) < 0)
	{			/* kill old */
		RespondProtocol(WORK_ERROR);
		return;
	}

	sprintf(fname, "tmp/%-s.%-d", curuser.userid, time(0));
	if (!RecvArticle(fname, NA, NULL, NULL) && !mycp(fname, buf))
		RespondProtocol(OK_CMD);
	else
		RespondProtocol(WORK_ERROR);
}


/**************************************************************
*		SIGNGET
*			���o�ϥΪ�ñ�W��
***************************************************************/
DoGetSign()
{
	char    buf[STRLEN];
	struct stat st;

	sethomefile(buf, curuser.userid, UFNAME_SIGNATURES);
	if (stat(buf, &st) < 0)
		RespondProtocol(NO_SIGN);
	else
		SendArticle(buf);
}

/*************************************************************
*		SIGNKILL
*			�R���ϥΪ�ñ�W��
**************************************************************/
DoKillSign()
{
	char    buf[STRLEN];
	struct stat st;

	sethomefile(buf, curuser.userid, UFNAME_SIGNATURES);
	if (stat(buf, &st) >= 0 && unlink(buf) < 0)
		RespondProtocol(WORK_ERROR);
	else
		RespondProtocol(OK_CMD);
}


/****************************************************************
*		SIGNPUT
*			�e�XUSERñ�W��
*****************************************************************/
DoSendSign()
{
	char    buf[STRLEN], fname[STRLEN];
	struct stat st;

	sethomefile(buf, curuser.userid, UFNAME_SIGNATURES);
	if (stat(buf, &st) >= 0 && unlink(buf) < 0)
	{			/* kill old */
		RespondProtocol(WORK_ERROR);
		return;
	}

	sprintf(fname, "tmp/%-s.%-d", curuser.userid, time(0));
	if (!RecvArticle(fname, NA, NULL, NULL) && !mycp(fname, buf))
		RespondProtocol(OK_CMD);
	else
		RespondProtocol(WORK_ERROR);
}


/*************************************************************
*		CHGPASSWD newpass
*			�ק�ϥΪ̱K�X
**************************************************************/
DoChangePassword()
{
	char   *passbuf;
	char   *pass;

	passbuf = Get_para_string(1);

	if (passbuf == NULL)
	{
		RespondProtocol(SYNTAX_ERROR);
		return;
	}
	passbuf[8] = '\0';
	pass = genpasswd(passbuf);
	strncpy(curuser.passwd, pass, PASSLEN);
	update_user(&curuser);
	update_user_passfile(&curuser);
	strcpy(oldpass, passbuf);
	RespondProtocol(OK_CMD);
}

/******************************************************************
*		USERGET
*			���o�ϥΪ̸��
*******************************************************************/
DoGetUserData()
{
	char    buffer[80];
	int     len;
	char    nickname[80], E_mail[80];
	char	term_type[80];

	strcpy(buffer, ctime(&nsysu_lastlogin));
	len = strlen(buffer);
	buffer[len - 1] = '\0';
	strcpy(nickname, curuser.username);
	if (strlen(nickname) == 0)
		strcpy(nickname, "#");

	strcpy(E_mail, curuser.email);
	if (strlen(E_mail) == 0)
		strcpy(E_mail, "#");

	strcpy(term_type, curuser.termtype);
	if (strlen(term_type) == 0)
		strcpy(term_type, "#");

	RespondProtocol(OK_CMD);
	inet_printf("%s\t%s\t", nickname, E_mail);
	inet_printf("%s\t%d\t%d\t%d\t%d\t",
	  term_type, curuser.numlogins, curuser.numposts,
		    curuser.userlevel, curuser.uid);
	inet_printf("%s\t%s\t%c\t",
		    nsysu_lastfromhost, buffer,
		    (curuser.flags[0] & 1) ? '1' : '0');	/* pager flag */
	inet_printf("%c\t%c\r\n", curuser.ident + '0',
		    (curuser.flags[0] & FORWARD_FLAG) ? '1' : '0');

}

/******************************************************************
*		CHGNAME name
*			�ק�USER�ʺ
*******************************************************************/
DoChangeUserName()
{
	char   *name;

	name = Get_para_string(1);
	if (name != NULL)
	{
		strcpy(curuser.username, name);
		chk_str2(curuser.username);
	}
	else
		curuser.username[0] = '\0';

	update_user(&curuser);
	update_user_passfile(&curuser);
#ifdef MULTIBBS
	net_update_user(&curuser, oldpass);
#endif
	RespondProtocol(OK_CMD);
}

/************************************************************
*		CHGMAIL
*			�ק�E-mail�b��
*************************************************************/
DoChangeEMail()
{
	char   *email;

	email = Get_para_string(1);
	strcpy(curuser.email, email);
	update_user(&curuser);
	update_user_passfile(&curuser);
#ifdef MULTIBBS
	net_update_user(&curuser, oldpass);
#endif
	RespondProtocol(OK_CMD);
}
