/*
 *  ���{�����U�C�\��G
 *
 *     1. ���� userid.bbs@bbs...... �� E-mail ����J BBS Users ���ӤH�H�c.
 *     2. ���� mail bbs@bbs...... < post.file �� E-mail To Post ��@���.
 *     3. ���� Board Manager �H E-mail To Post ���覡 Post ���ذ�.
 *
 *  Header Lines Rule �аѾ\���s BBS Announce.
 */

#include "bbs.h"
#include <varargs.h>


char    genbuf[1024];
time_t  now;

#ifdef BBSMAIL_LOG
char    received[4096];
#endif


struct mail_info
{
	char    type;
	char    from[STRLEN];
	char    to[IDLEN + 2];
	char    subject[STRLEN];
	char    sender[IDLEN + 2];
	char    passwd[PASSLEN];
	char    board[STRLEN];
};

struct mail_info minfo;


void
log_bbsmail(va_alist)
va_dcl
{
	va_list args;
	time_t  now;
	int     fd;
	char    msgbuf[1024], buf[1024], *fmt;
	char    timestr[22];

	va_start(args);
	fmt = va_arg(args, char *);

	vsprintf(msgbuf, fmt, args);
	va_end(args);

	time(&now);
	strftime(timestr, sizeof(timestr), "%x %X", localtime(&now));

	sprintf(buf, "%s %s\n", timestr, msgbuf);
	if ((fd = open(PATH_BBSMAIL_LOG, O_APPEND | O_CREAT | O_WRONLY, 0600)) > 0)
	{
		write(fd, buf, strlen(buf));
		close(fd);
	}
}


#define GET_NEXTONE	0
#define GET_NEXTALL	1
#define GET_HEADER	2
#define GET_PASSWD	3

char   *
mygets(buf, bsize, fp)
char   *buf;
int     bsize;
FILE   *fp;
{
	register char *p;

	if (fgets(buf, bsize, fp))
	{
		if ((p = strrchr(buf, '\n')) && p > buf && *(--p) == '\r')
		{
			*p++ = '\n';
			*p = '\0';
		}
		return buf;
	}
	return NULL;
}


/* if type == 0 �u��X�U�@��
 *    type == 1 �ĤG���H�᪺����
 *    type == 2 ���o���Y�Ʀ�᪺���
 *    type == 3 ���o password
 */
int
next_arg(from, to, len, type)
register char *from, *to;
register int len, type;
{
	register int i = 0, j = 0;
	register char ccc;

	if (type == GET_NEXTONE)
		ccc = ' ';
	else
		ccc = ':';

	while (from[i] != ccc)
		if (from[i] == '\n' || from[i] == '\0')
			return -1;
		else
			i++;
	if (type != GET_NEXTONE)
		i++;
	while (isspace(from[i]))
		i++;
	i--;
	switch (type)
	{
	case GET_NEXTONE:
		while (from[++i] != SP && from[i] != '\0' && j < len - 1)
		{
			if (from[i] == ESC || from[i] == TAB || from[i] == NL)
				to[j++] = SP;
			else
				to[j++] = from[i];
		}
		break;
	case GET_NEXTALL:
		while (from[++i] != NL && from[i] != '\0' && j < len - 1)
		{
			if (from[i] == ESC || from[i] == TAB)
				to[j++] = SP;
			else
				to[j++] = from[i];
		}
		break;
	case GET_HEADER:
		while (from[++i] != NL && from[i] != SP && from[i] != '\0' && j < len - 1)
		{
			if (from[i] == ESC || from[i] == TAB)
				to[j++] = SP;
			else
				to[j++] = from[i];
		}
		break;
	case GET_PASSWD:
		while (from[++i] != NL && from[i] != '\0' && j < len - 1)
			to[j++] = from[i];
	}
	to[j] = '\0';
	return 0;
}


int
increase_user_postnum(userid)
char    userid[];
{
	int     fd;
	USEREC  urc;

	sethomefile(genbuf, userid, UFNAME_PASSWDS);
	if ((fd = open(genbuf, O_RDWR)) > 0)
	{
		if (read(fd, &urc, sizeof(urc)) == sizeof(urc))
		{
			urc.numposts++;
			if (lseek(fd, 0, SEEK_SET) != -1)
			{
				if (write(fd, &urc, sizeof(urc)) == sizeof(urc))
				{
					close(fd);
					return 0;
				}
			}
		}
		close(fd);
	}
	return -1;
}


USEREC  user;

int
do_sign(r_file)
char    r_file[];
{
	FILE   *fpr, *fpw;
	int     line;
	char    filename[PATHLEN];

	sethomefile(filename, minfo.sender, UFNAME_SIGNATURES);
	if ((fpr = fopen(r_file, "r")) == NULL)
		return -1;
	if ((fpw = fopen(filename, "w")) == NULL)
	{
		fclose(fpr);
		return -1;
	}

	line = 0;
	while (line < (MAX_SIG_LINES * MAX_SIG_NUM)
	       && mygets(genbuf, sizeof(genbuf), fpr))
	{
		if (line == 0)
		{
			if (genbuf[0] == '\n')
				continue;
		}
		fputs(genbuf, fpw);
		line++;
	}
	fclose(fpr);
	fclose(fpw);
	chmod(filename, 0644);
	return 0;
}


int
do_plan(r_file)
char    r_file[];
{
	FILE   *fpr, *fpw;
	int     line;
	char    filename[PATHLEN];

	sethomefile(filename, minfo.sender, UFNAME_PLANS);
	if ((fpr = fopen(r_file, "r")) == NULL)
		return -1;
	if ((fpw = fopen(filename, "w")) == NULL)
	{
		fclose(fpr);
		return -1;
	}

	line = 0;
	while (line < MAX_QUERY_LINES && mygets(genbuf, sizeof(genbuf), fpr))
	{
		if (line == 0)
		{
			if (genbuf[0] == '\n')
				continue;
		}
		fputs(genbuf, fpw);
		line++;
	}
	fclose(fpr);
	fclose(fpw);
	chmod(filename, 0644);
	return 0;
}


int
do_post(r_file)
char    r_file[];
{
	char    path[PATHLEN], fname[PATHLEN];
	FILE   *fpr, *fpw;
	char   *subject, *postpath;
	int     treasure;
	char    str[STRLEN];
	BOARDHEADER bhead;
	char   *timestr;

	if (minfo.board[0] == '\0')
		return -1;

	if (minfo.board[0] == '#')
	{
		strcpy(str, minfo.board + 1);
		strcpy(minfo.board, str);
		treasure = TRUE;
	}
	else
		treasure = FALSE;

	if (get_board(&bhead, minfo.board) <= 0)
		return -1;
	if (!can_see_board(&bhead, user.userlevel)
	    || ((bhead.brdtype & BRDTYPE_IDENT) && user.ident != 7))
	{
		return -1;
	}
	if (treasure == TRUE && strcmp(minfo.sender, bhead.owner))
		return -1;

	strcpy(minfo.board, bhead.filename);

	sprintf(fname, "tmp/_bbsmail_post");
	if ((fpr = fopen(r_file, "r")) == NULL)
		return -1;
	if ((fpw = fopen(fname, "w")) == NULL)
	{
		fclose(fpr);
		return -1;
	}

	if (minfo.subject[0] != '\0')
		subject = minfo.subject;
	else
		subject = "(no subject)";

	timestr = ctime(&now);
	*(timestr + strlen(timestr) - 1) = '\0';

	write_article_header(fpw, minfo.sender, user.username, minfo.board, timestr,
	                     subject, NULL);
	fprintf(fpw, "�ӷ�: E-Mail Post\n");	/* lthuang */			    
	fputs("\n", fpw);
	while (mygets(genbuf, sizeof(genbuf), fpr))
		fputs(genbuf, fpw);
	fclose(fpr);

	sethomefile(genbuf, minfo.sender, UFNAME_SIGNATURES);
	if ((fpr = fopen(genbuf, "r")) != NULL)
	{
		int     line = 0;

		fputs("\n--\n", fpw);
		while (line++ < MAX_SIG_LINES && mygets(genbuf, sizeof(genbuf), fpr))
			fputs(genbuf, fpw);
		fclose(fpr);
	}
	fprintf(fpw, "[m\n");
	fclose(fpw);
	chmod(fname, 0644);

	if (treasure == TRUE)
	{
		settreafile(path, minfo.board, NULL);
		postpath = path;
	}
	else
		postpath = NULL;

	if (PublishPost(fname, minfo.sender, minfo.board, subject, user.ident,
		            NULL, TRUE, postpath, 0) == -1)
	{
		unlink(fname);
		return -1;
	}

	if (!(bhead.brdtype & BRDTYPE_NOPOSTNUM))
		increase_user_postnum(minfo.sender);

	unlink(fname);
	return 0;
}


int
do_mail(r_file)
char    r_file[];
{
	char    fn_new[PATHLEN];
	FILE   *fpr, *fpw;
	int     result;
	char   *timestr, *subject;

	sprintf(fn_new, "%s.new", r_file);

	if ((fpr = fopen(r_file, "r")) == NULL)
		return -1;

	if ((fpw = fopen(fn_new, "w")) == NULL)
	{
		fclose(fpr);
		return -1;
	}

	if (minfo.subject[0] != '\0')
		subject = minfo.subject;
	else
		subject = "(no subject)";

	timestr = ctime(&now);
	*(timestr + strlen(timestr) - 1) = '\0';

	write_article_header(fpw, minfo.from, "", NULL, timestr, subject, NULL);
	
	fputs("\n", fpw);
	while (mygets(genbuf, sizeof(genbuf), fpr))
		fputs(genbuf, fpw);
	fputs("[m\n", fpw);
	fclose(fpr);
	fclose(fpw);
	chmod(fn_new, 0600);

#ifdef BBSMAIL_LOG
	log_bbsmail("from=<%s>, to=<%s>, path=<%s>",
	            minfo.from, minfo.sender, received);	/* lthuang */
#endif	            
		    
	result = SendMail_Local(fn_new, minfo.from, minfo.sender,
				subject, user.ident);

	unlink(fn_new);

	return result;
}


int
access_mail(r_file)
char    r_file[];
{
	struct stat st;

	memset(&user, 0, sizeof(user));

	if (minfo.to[0] != '\0')
		strcpy(minfo.sender, minfo.to);
	if (get_passwd(&user, minfo.sender) <= 0)
		return -1;

	if (stat(r_file, &st) == 0 && st.st_size > MAX_MAIL_SIZE)
	{
		log_bbsmail("ERR: from=<%s>, to=<%s>, size too big: %d",
			    minfo.from, minfo.sender, st.st_size);
	}

	if (minfo.type == 's' && checkpasswd(user.passwd, minfo.passwd))
		do_sign(r_file);
	else if (minfo.type == 'l' && checkpasswd(user.passwd, minfo.passwd))
		do_plan(r_file);
	else if (minfo.type != 'm' && minfo.passwd[0] != '\0' 
	         && minfo.sender[0] != '\0' 
	         && checkpasswd(user.passwd, minfo.passwd))
	{
		do_post(r_file);
	}
	else
		do_mail(r_file);
	return 0;
}


int
readin_mail(filename)
char   *filename;
{
	int     i, ok_num, rec_len, save_rec_len, invalid;
	char    rbuf[1024], w_file[PATHLEN], *s, outside[512];
	FILE   *fp, *fp_sys;

	if ((fp_sys = fopen(filename, "r")) == NULL)
		return -1;

	i = 0;
	ok_num = 0;
	invalid = 0;
	fp = NULL;

	while (mygets(rbuf, sizeof(rbuf), fp_sys))
	{
		if (!strncasecmp(rbuf, "From ", 5))
			break;
	}

	for (;;)
	{
		if (i > 0)
		{
			fclose(fp);

			if (invalid)
				log_bbsmail("ERR: from=<%s>, to=<%s>, invalid bbsmail", 
				            minfo.from, outside);
			else if (ok_num == 5)
				access_mail(w_file);			
			else if (minfo.to[0] == '\0')	/* lthuang */
				log_bbsmail("ERR: from=<%s>, to=<>, null to", minfo.from);

			unlink(w_file);
		}
	
		if (strncasecmp(rbuf, "From ", 5))
			break;
	
		sprintf(w_file, "%s-%d", filename, ++i);
		if ((fp = fopen(w_file, "w")) == NULL)
		{
			fclose(fp_sys);
			return -1;
		}
		chmod(w_file, 0600);

		memset(&minfo, 0, sizeof(minfo));
#ifdef BBSMAIL_LOG		
		received[0] = '\0';
		rec_len = 0;
		save_rec_len = 0;
#endif		
		invalid = 0;		
		ok_num = 0;				
		
		next_arg(rbuf, minfo.from, sizeof(minfo.from), GET_NEXTONE);
			
		while (mygets(rbuf, sizeof(rbuf), fp_sys))
		{
			if ((!strncasecmp(rbuf, "To: ", 4)
				 || !strncasecmp(rbuf, "Apparently-To: ", 15)))

			{
				char *sb;
				
				if ((sb = strchr(rbuf, '<')) != NULL)
				{
					sb++;
					if ((s = strchr(sb, '>')) != NULL)
						*s = '\0';
				}
				else
				{
					sb = rbuf;
					while (!isspace(*sb))
						sb++;
					while (isspace(*sb))
						sb++;
				}
				
				if ((s = strchr(sb, '\n')) != NULL)
					*s = '\0';
				strcpy(outside, sb);	/* lthuang */
				
				if ((s = strstr(sb, "@")) != NULL)
					*(s--) = '\0';
				else
					s = sb + strlen(sb);
					
				strncpy(minfo.to, sb, sizeof(minfo.to));
			}
			else if (!strncasecmp(rbuf, "Subject: ", 9))
				next_arg(rbuf, minfo.subject, sizeof(minfo.subject), GET_NEXTALL);
#ifdef BBSMAIL_LOG				
			else if (!strncasecmp(rbuf, "Received: ", 10))
			{
				char   *path;

				if ((path = strstr(rbuf, "from")) != NULL)
				{
					path += 5;

					rec_len = save_rec_len;
					received[rec_len++] = '!';

					while (*path != '\0' && *path != '\n')
						received[rec_len++] = *path++;
					received[rec_len] = '\0';
					if (save_rec_len == 0)
						save_rec_len = rec_len;
				}
			}
#endif			
			if (rbuf[0] == '\n')
				break;
		}

		if ((s = strstr(minfo.to, ".bbs")) != NULL)
		{
			*s = '\0';
			if (minfo.to[0] != '\0')
				ok_num = 5;
			minfo.type = 'm';				
		}
		else if (!strcmp(minfo.to, "bbs"))
		{
			minfo.to[0] = '\0';		
			minfo.type = 'p';
		}
		else if (minfo.to[0] != '\0')
		{
			invalid = 1;
		}
			
		while (mygets(rbuf, sizeof(rbuf), fp_sys))
		{
			if (!strncasecmp(rbuf, "From ", 5))
				break;
				
			if (ok_num == 5)
			{
				fprintf(fp, "%s", rbuf);
				continue;
			}

			if (ok_num < 5 && (s = strstr(rbuf, "#type:")) != NULL)
			{
				ok_num++;
				if (strstr(s, "sign"))
					minfo.type = 's';
				else if (strstr(s, "plan"))
					minfo.type = 'l';
			}
			else if (minfo.sender[0] == '\0' && (s = strstr(rbuf, "#name:")) != NULL)
			{
				ok_num++;
				next_arg(s, minfo.sender, sizeof(minfo.sender), GET_HEADER);
			}
			else if (minfo.passwd[0] == '\0' &&
				 ((s = strstr(rbuf, "#password:")) != NULL
				  || (s = strstr(rbuf, "#passwd:")) != NULL))
			{
				ok_num++;
				next_arg(s, minfo.passwd, sizeof(minfo.passwd), GET_PASSWD);
			}
			else if (minfo.board[0] == '\0' && (s = strstr(rbuf, "#board:")) != NULL)
			{
				ok_num++;
				next_arg(s, minfo.board, sizeof(minfo.board), GET_HEADER);
			}
			else if (((s = strstr(rbuf, "#title:")) != NULL
			          || (s = strstr(rbuf, "#subject:")) != NULL))
			{
				ok_num++;
				next_arg(s, minfo.subject, sizeof(minfo.subject), GET_NEXTALL);
			}
			else
			{
				if (minfo.sender[0] != '\0' && minfo.passwd[0] != '\0'
				    && minfo.board[0] != '\0' && minfo.subject[0] != '\0')
				{
					ok_num = 5;
				}
				fprintf(fp, "%s", rbuf);
			}
		}
	}
	fclose(fp_sys);
	return 0;
}


int
main(argc, argv)
int     argc;
char   *argv[];
{
	char    spool_tmp[PATHLEN], bbsmail_box[PATHLEN];
	struct stat st;

	sprintf(bbsmail_box, "%s/bbs", SPOOL_MAIL);
	if (stat(bbsmail_box, &st) != 0 || st.st_size == 0)
	{
		/* bbs mail spool is empty */
		exit(0);
	}

	if (chdir(HOMEBBS) == -1)
	{
		/* home not exist */
		exit(0);
	}

	now = time(0);
	sprintf(spool_tmp, "tmp/_bbsmail.%d", now);
	if (myrename(bbsmail_box, spool_tmp) == -1)
	{
		printf("cannot rename: from %s to %s\n", bbsmail_box, spool_tmp);
		exit(1);
	}

	chown(spool_tmp, BBS_UID, BBS_GID);

	init_bbsenv();

	readin_mail(spool_tmp);
	unlink(spool_tmp);
}
