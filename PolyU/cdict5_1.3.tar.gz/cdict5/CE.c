/* �~�^�d�ߵ{�� */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include "cdict5.h"

struct {
  char initial;
  int  L2index;
} matchedChinese[MAX_MATCHES];

extern int query_mode;
extern FILE *pager;
unsigned char *beMarked;

int Big5toOffset(unsigned char *CChar) {

  unsigned char low, high;
  int num;

  low = CChar[1];
  high = CChar[0];

  if (low > 160) low-=34;
  num = 157*(high-0xA1) + (low-0x40);

  if (num >= 471 && num < 5872) return num-471;
  else if (num >= 6280 && num < 13973) return num-879;
  else return -1;
}

void printAllResult2(int totalMatch) {
  int L2indexFD, L3index, dictFD, i, data_len;
  char dict_path[sizeof(DICT_PATH)+10];
  char L2index_path[sizeof(DICT_PATH)+10];    
  unsigned char *buf;

#ifdef PAGER
  if ((pager = popen(PAGER, "w")) == NULL) {
    fprintf(stderr, "cannot use %s as pager\n\n", PAGER);
    pager = stdout;
  }
#else
    pager = stdout;
#endif

  if (totalMatch > 1)
    fprintf(pager, "\n�@��%d�r�ŦX�d�߱���:\n", totalMatch);

  for (i = 0; i < totalMatch; i++) {
    if (!isalpha(matchedChinese[i].initial)) {
      fprintf(stderr, "chinese level 1 index file corrupted\n");
      exit(-1);      
    }

    sprintf(L2index_path, DICT_PATH "/%c.i50", matchedChinese[i].initial);
    sprintf(dict_path, DICT_PATH "/%c.d50", matchedChinese[i].initial);

    L2indexFD = open(L2index_path, O_RDONLY);
    dictFD = open(dict_path, O_RDONLY);

    if (L2indexFD < 0 || dictFD < 0) {
      fprintf(pager, "cannot access dictionary file %s or %s\n",
  		    L2index_path, dict_path);
      exit(-1);
    }

    lseek(L2indexFD, matchedChinese[i].L2index, 0);
    if (read(L2indexFD, &L3index, 4) <= 0) {
      fprintf(pager, "dictionary file %s corrupted\n", L2index_path);
      exit(-1);
    }                    

#ifdef LITTLE_ENDIAN
    L3index &= 0x1FFFFFL;
#else
    L3index = convertEndian(L3index) & 0x1FFFFFL;
#endif

    if (read(L2indexFD, &data_len, 4) <= 0) 
      data_len = L3index + 4096;
    else
#ifdef LITTLE_ENDIAN
      data_len &= 0x1FFFFFL;
#else
      data_len = convertEndian(data_len) & 0x1FFFFFL;
#endif

    close(L2indexFD);

    lseek(dictFD, L3index, 0);
    buf = (unsigned char *)malloc(data_len - L3index + 10);
    data_len = read(dictFD, buf, data_len - L3index + 10);

    close(dictFD);

    if (*buf/0x10 != 1 || data_len <= 0) {
        fprintf(pager, "dictionary file corrupted\n");
	exit(-1);
    }                               
    
    printResult(buf, data_len);
    free(buf);
  }

  fprintf(pager, "\n");
  if (pager != stdout)  pclose(pager);   
}

int findAllChineseMatches(unsigned char *word, unsigned char *buf, int buflen) {
  register unsigned char *ptr;
  int wordlen, totalMatch, i, j, possibleMatch;
  register unsigned char lexiconLen, matchNum, *pLexicon, *pIndice;
  char initial;
  int  L2index;                  

  ptr = buf;
  wordlen = strlen(word)-2;
  beMarked = word;

  totalMatch = 0;
  while (ptr < buf+buflen) {
    lexiconLen = ptr[0];
    pLexicon = ptr+2;    
    matchNum = ptr[1];
    pIndice = ptr+(lexiconLen+2);

    if (query_mode & WILDCARD_MODE) possibleMatch = (wordlen <= lexiconLen);
    else possibleMatch = (wordlen == lexiconLen);

    if (possibleMatch) 
      if (memcmp(pLexicon, word+2, wordlen) == 0) 
        for (j = 0; j < matchNum*3 && totalMatch < MAX_MATCHES; j+=3) {
          initial = pIndice[j]-'A'+'a';  
          L2index = (pIndice[j+1] + pIndice[j+2]*0x100)*4;
          for (i = 0; i < totalMatch; i++)         
            if (matchedChinese[i].L2index == L2index &&
	        matchedChinese[i].initial == initial) break;
 
          if (i == totalMatch) {
            matchedChinese[totalMatch].initial = initial;
            matchedChinese[totalMatch++].L2index = L2index;
          }
        }
     
    if (totalMatch == MAX_MATCHES) break;
    ptr = pIndice + 3*(matchNum);
  } 

  free(buf);
  if (totalMatch)
    printAllResult2(totalMatch);
  else
    fprintf(stderr, "�L������J�ŦX�y%s�z\n", word);
}  

void queryChinese(unsigned char *word) {
  int buflen;
  int L0indexFD, L1indexFD, L0index, L1index, L1index_next;
  char L0index_path[] = DICT_PATH "/ce.i50";
  char L1index_path[] = DICT_PATH "/ce.d50";      
  unsigned char *buf;
   
  if ((L0index = Big5toOffset(word)) < 0) {
    fprintf(stderr, "�y%c%c�z�D����Big-5�X\n", word[0], word[1]);
    return;
  }

  L0indexFD = open(L0index_path, O_RDONLY);
  L1indexFD = open(L1index_path, O_RDONLY);
 
  if (L0indexFD < 0 || L1indexFD < 0) {
    fprintf(stderr, "cannot access chinese index file %s or %s\n",
		    L0index_path, L1index_path);
    exit(-1);
  }

  lseek(L0indexFD, L0index*4, 0);
  if (read(L0indexFD, &L1index, 4) <= 0) {
    fprintf(stderr, "chinese index file %s corrupted\n", L0index_path);
    exit(-1);
  }

  if (read(L0indexFD, &L1index_next, 4) <= 0 || L1index == L1index_next) {
    fprintf(stderr, "�L�y%c%c�z���������J\n", word[0], word[1]);
    return;
  }

  close(L0indexFD);

#ifndef LITTLE_ENDIAN
  L1index_next = convertEndian(L1index_next);
  L1index = convertEndian(L1index);
#endif

  buflen = L1index_next - L1index;

  buf = (unsigned char*)malloc(buflen);

  lseek(L1indexFD, L1index, 0);
  if (read(L1indexFD, buf, buflen) <= 0) {
    fprintf(stderr, "chinese index file %s corrupted\n", L1index_path);
    exit(-1);
  }

  close(L1indexFD);

  findAllChineseMatches(word, buf, buflen);

}
