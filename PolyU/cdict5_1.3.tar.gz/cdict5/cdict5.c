/* �^�~�d�ߵ{��
   �D�{��
*/

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <ctype.h>
#include <gdbm.h>
#include <signal.h>
#include "cdict5.h"
#include "getline.h"

#define isBig5CodeHi(c)	((c) >= 0x81 && (c) <=0xFE)

char *word_class[]={"�D�λy", "�W��", "�N�W��", "�ήe��", "�Ƶ�", 
"�U�ʵ�", "�ʵ�", "�Ϊ��ʵ�", "���Ϊ��ʵ�", "���t��", "�s����", 
"�P�ĵ�", "�W��", "�W��", "�r��", "�r��"};

char *freq[]={"", "[���`�Φr]", "[�`�Φr]", "[�򥻦r�J]", ""};

char *indent[]={"", "  ", "   ", "     ", "  ", "   "};
int  indentnum[]={0, 2, 3, 5, 2, 3};
FILE *pager;
GDBM_FILE indexFD;
char *match[MAX_MATCHES];
int  query_mode, dictFD, L2indexFD;
extern unsigned char *beMarked;

static void sig_handle(int signo) {

    switch (signo) {
      case SIGPIPE: signal(SIGPIPE, sig_handle);
                    return;
      case SIGSEGV: fprintf(stderr, "caught unexpected SIGSEGV\n");
	            exit(-1);
      case SIGBUS:  fprintf(stderr, "caught unexpected SIGBUS\n");
		    exit(-1);
    }
}

#ifndef LITTLE_ENDIAN
int convertEndian(int i) {
  union {
    int i;
    char c[4];
  } u, v;

  u.i = i;
  v.c[0] = u.c[3];
  v.c[1] = u.c[2];
  v.c[2] = u.c[1];
  v.c[3] = u.c[0];

  return v.i;
}                          
#endif

unsigned char *justify(unsigned char *str, int indent, int stringlen) {
  register unsigned char *ptr, *begin, *bp;  /* bp == possible breakpoint */
  int len;

  ptr = str;
  len = COLUMN-indent; 
  begin = str;
  
  while (1) {
    if (stringlen <= len) return str;

    while (*ptr) {
      if (ptr-begin > len) break;
      if (*ptr == ' ') 
        bp = ptr;
      else if (isBig5CodeHi(*ptr)) {
        bp = ptr;
        ptr++;
      } 
      ptr++;
    }

    begin = bp+1+indent;  
    if (*bp==' ') bcopy(bp+1, begin, strlen(bp)+1);
    else bcopy(bp, begin, strlen(bp)+1);

    memset(bp+1, ' ', indent);
    *bp = '\n';
    stringlen = strlen(begin);
    ptr = begin;
  } 
}

void printMarked(unsigned char *str) {
  register unsigned char *ptr, *strBegin, p;
  int beMarkedLen;
  
  if ((ptr = strstr(str, beMarked)) == NULL) {
    fprintf(pager, "%s\n", str);
    return;
  }

  beMarkedLen = strlen(beMarked);
  strBegin = str;

  while (ptr) {
    p = *ptr;
    *ptr = '\0';
    fprintf(pager, "%s" MARKED_COLOR, strBegin);
    *ptr = p;

    strBegin = ptr + beMarkedLen;
    p = *strBegin;
    *strBegin = '\0';
    fprintf(pager, "%s" ANSI_RESET, ptr);
    *strBegin = p;
    ptr = strstr(strBegin, beMarked);  
  }
  fprintf(pager, "%s\n", strBegin);

}

unsigned int printLine(unsigned char *begin) {
  unsigned char buf[1024];
  register unsigned char rawchar;
  register unsigned int  i, len, offst=2, type;

  len = begin[1];

  if (len==255) { 
    len+=begin[2];
    offst=3;
  }

  type = *begin/0x10;
  if (type==2)
    return len+offst;

  if (type==1) {
    fprintf(pager, KEYWORD_COLOR);
    for (i=offst; i<len+offst; i++) {
      rawchar = begin[i]^(unsigned char)0xa5;
      
      if (rawchar >= 225)      fprintf(pager, ".%c", rawchar-225+'a'); 
      else if (rawchar >= 193) fprintf(pager, ".%c", rawchar-193+'A');
      else if (rawchar==172)   fprintf(pager, "., "); 
      else if (rawchar==160)   fprintf(pager, ". "); 
      else if (rawchar==168)   fprintf(pager, "("); 
      else if (rawchar >=129)  fprintf(pager, ".%c", rawchar-129+'a');
      else fprintf(pager, "%c", rawchar);
    } 
    fprintf(pager, ANSI_RESET " %s\n", freq[*begin-0x10]);

  }
  else {
    for (i=0; i<len; i++) {
      buf[i] = begin[i+offst]^(char)0xa5;
      if (buf[i]=='#') {
        buf[i]=0;
        break;
      }
    }        
    buf[len]=0;

    if (*begin == 0xC4 || *begin == 0xD8) 
      fprintf(pager, INFLEXION_COLOR "(%s)" ANSI_RESET "\n" 
                   , justify(buf, 0, len));

    else if (*begin == 0x84 || type==0x5) 
      fprintf(pager, IDIOM_COLOR "%s" ANSI_RESET " \n"
		   , justify(buf, 0, len));

    else if (type == 0xD || type == 0xA || type == 0xE || type == 0x9) {
      int i=0, j;
      switch (type) {
        case 0xD: i = *begin-0xDC; break;
        case 0xA: i = *begin-0xA5; break;
        case 0x9: i = *begin-0x9D; break;
	case 0xE: i = *begin-0xE4; break;  
      }

      if (i<0 || i>=sizeof(indentnum)/sizeof(indentnum[0])) i=0;
      fprintf(pager, "%s" EXAMPLE_COLOR "%s" ANSI_RESET "\n"
		   , indent[i], justify(buf, indentnum[i], len));

    }

    else if (type == 0xC) {
      int j;

      if (*begin>=0xC8) {
        j = *begin - 0xC8;
        fprintf(pager, "%s" OTHER_INFO_COLOR "%s" ANSI_RESET "\n"
                     , indent[j], justify(buf, indentnum[j], len));
      }
      else {
        j = *begin - 0xC0;
        fprintf(pager, indent[j]);
        if (query_mode & QUERY_CHINESE) 
          printMarked(justify(buf, indentnum[j], len));
        else
          fprintf(pager, "%s\n", justify(buf, indentnum[j], len));
      }
    }   
    else if (type == 0x8){
        int j;
      
        j = *begin - 0x81;
        if (j<0 || j >= sizeof(indentnum)/sizeof(indentnum[0])) j=0;

        fprintf(pager, indent[j]);
        if (query_mode & QUERY_CHINESE) 
          printMarked(justify(buf, indentnum[j], len));
        else
          fprintf(pager, "%s\n", justify(buf, indentnum[j], len));
    }
    else
      fprintf(pager, "%s\n", justify(buf, 0, len));
  }
  
  return len+offst;
}

void processArgs(unsigned char *buf, unsigned char *word) {
  int i, j;
  char *tmp;

  if (*buf == '\0') 
    exit(0);

  if (isBig5CodeHi(buf[0]))  {
    query_mode|=QUERY_CHINESE;
    if (buf[strlen(buf)-1] == '*') query_mode|=WILDCARD_MODE;
    strcpy(word, strtok(buf, "*"));
    return;
  } 

  if (strcmp(buf, "*") == 0 || strcmp(buf, "!") == 0) 
    exit(0);

  i = 0; 
  j = 0;
  while (buf[i]) {
    if (isalpha(buf[i])) 
      word[j++] = tolower(buf[i]);
    else 
      switch (buf[i]) {
	case '[':
	case ']':
	case '-':
	case '^':
	case '*':
	case '?':
		word[j++] = buf[i];
                query_mode|=WILDCARD_MODE;
		if (buf[i] == '*')
		  while (buf[i+1] == '*') i++;
		break;
       }
     i++;
  }           
  word[j] = 0;

}

int prepareIndexList(char *pattern, char *indexList) {
  int not = 0;
  char i;

  if (isalpha(*pattern)) {
    indexList[0] = *pattern;
    indexList[1] = '\0';
    return 1;
  }

  if (*pattern == '*' || *pattern == '?') 
    return 1;
  
  if (*pattern == '[') {
    if (strchr(pattern, ']') == NULL) goto syntaxError;
    if (pattern[1] == '^') {
      not = 1;
      pattern+=2;
    }
    else if (isalpha(pattern[1])) {
      memset(indexList, ' ', strlen(indexList));
      pattern++;
    }
    else goto syntaxError;
    
    do {
      if (isalpha(*pattern)) 
        indexList[*pattern-'a'] = (not) ? ' ' : *pattern;
      else goto syntaxError;

      if (pattern[1] == '-') {
        if (pattern[2] <= *pattern || !isalpha(pattern[2])) 
          goto syntaxError;

        for (i = *pattern; i <= pattern[2]; i++)
          indexList[i-'a'] = (not) ? ' ' : i;  

        pattern+=2;
      }
      pattern++;
    } while (*pattern != ']'); 

    return 1;
  }

syntaxError:
  return 0;
}

int findAllMatches(char *word) {
  register char  *tmp, *tmp2;
  char indexfile[] = "?.idx";
  char indexList[]="abcdefghijklmnopqrstuvwxyz";
  datum key, data;  
  int   totalMatch = 0, i;

  if (!prepareIndexList(word, indexList)) {
    fprintf(stderr, "syntax error\n");
    return 0;
  }

  fprintf(stderr, "�j�M");

  for (i = 0; i < sizeof(indexList)-1 && indexList[i]; i++) {
    if (indexList[i] == ' ') continue;
    *indexfile = indexList[i];
    fprintf(stderr, " %c", *indexfile);

    key.dptr = indexfile;
    key.dsize = sizeof(indexfile);

    data = gdbm_fetch(indexFD, key);
    if (data.dptr == NULL) {
      fprintf(stderr, "\nindex file corrupted: entry \"%s\" not found\n"
                    , indexfile);
      exit(-1);
    }                      

    tmp2 = data.dptr;
    tmp = strchr(tmp2, '\n');
    
    while (totalMatch < MAX_MATCHES && tmp) {
      *tmp = '\0';
      if (wildcard_match(word, tmp2))  
        match[totalMatch++] = strdup(tmp2);

      tmp2 = tmp+1;
      tmp = strchr(tmp2, '\n');
    }   
  
    free(data.dptr);
    if (totalMatch == MAX_MATCHES)
      break;
  }

  fprintf(stderr, " ����\n");
  if (totalMatch == 0)
    fprintf(stderr, "�L�r�ŦX\"%s\"\n", word); 

  return totalMatch;
}

void printResult(unsigned char *buf, int buflen) {
  int index = 0;
  
  fprintf(pager, "\n");
  do {
    if (buf[index]/0x10 == 6) {   
      fprintf(pager, WORD_CLASS_COLOR "<<%s>>" ANSI_RESET "\n"
		   , word_class[buf[index]-0x60]);
      index++;
    }
    else if (buf[index] == 0x50) {
      printf(WORD_CLASS_COLOR "<<�P�q�r>>" ANSI_RESET "\n");
      index++;
    }
    else index += (printLine(buf+index));
  } while (buf[index]/0x10 != 1 && index <= buflen-1); 
}

void printAllResult(int totalMatch) {
  int i, j, data_len, L2index, L3index, index;
  unsigned char *tmp, *buf;
  char dict_path[sizeof(DICT_PATH)+10];
  char L2index_path[sizeof(DICT_PATH)+10];
  datum key, data;

  if (totalMatch <= 0) return;

  for (j = 0; j < totalMatch; j++) {
    key.dptr  = match[j];
    key.dsize = strlen(match[j])+1;

    data = gdbm_fetch(indexFD, key);

    if (data.dptr == NULL) {
      if (query_mode & WILDCARD_MODE) {
        fprintf(stderr, "index file corrupted: entry \"%s\" not found\n", match[j]);
	exit(-1);
      }
      else {
        fprintf(stderr, "\"%s\"�d�L���r\n", match[j]);  
	free(match[j]);
        return;
      }
    } 

/** try to popen pager if we need to print results.
 **
 **
 **/

    if (j == 0) {      
#ifdef PAGER
      if ((pager = popen(PAGER, "w")) == NULL) {
        fprintf(stderr, "cannot use %s as pager\n\n", PAGER);
        pager = stdout;
      }
#else
      pager = stdout;
#endif

      if (query_mode & WILDCARD_MODE)
        fprintf(pager, "�ܤ�%d�r�ŦX�d�߱���:\n", totalMatch); 
    }

/** open dictionary files for each word in match[]
 **
 ** if the file opened last time is the same as this time
 ** don't open it again.
 **/

    if (j == 0 || match[j][0] != match[j-1][0]) {
      sprintf(dict_path, DICT_PATH "/%c.d50", match[j][0]);
      sprintf(L2index_path, DICT_PATH "/%c.i50", match[j][0]);

      if (j != 0) {
        close(dictFD);
	close(L2indexFD);
      }

      dictFD = open(dict_path, O_RDONLY);
      L2indexFD = open(L2index_path, O_RDONLY);
    
      if (L2indexFD < 0 || dictFD < 0) {
        fprintf(pager, "cannot access dictionary file %s or %s\n",
                      L2index_path, dict_path);
        exit(-1);
      }                               
    }

/** read L2index and fetch data for printResult()
 **
 **
 **/

    tmp = data.dptr;
    for (i = 0; i < (data.dsize)/2; i++, tmp+=2) {

      L2index = (tmp[0] + tmp[1]*0x100)*4;
      
      lseek(L2indexFD, L2index, 0);
      if (read(L2indexFD, &L3index, 4) <= 0) {  
        fprintf(pager, "dictionary file %s corrupted\n", L2index_path);
        exit(-1);
      }
#ifdef LITTLE_ENDIAN
      L3index &= 0x1FFFFFL;
#else
      L3index = convertEndian(L3index) & 0x1FFFFFL;
#endif      

      if (read(L2indexFD, &data_len, 4) <= 0)
        data_len = L3index + 4096;
      else
#ifdef LITTLE_ENDIAN
      data_len &= 0x1FFFFFL;
#else
      data_len = convertEndian(data_len) & 0x1FFFFFL;
#endif
                       
      lseek(dictFD, L3index, 0);
      buf = (unsigned char *)malloc(data_len - L3index + 10);
      data_len = read(dictFD, buf, data_len - L3index + 10);

      if (*buf/0x10 != 1 || data_len <= 0) {
        fprintf(pager, "dictionary file %s corrupted: entry \"%s\"\n",
		 	dict_path, match[j]);
        exit(-1);
      }

      printResult(buf, data_len);
      free(buf);
    }

    free(data.dptr);
  }                      

  for (j = 0; j < totalMatch; j++)
    free(match[j]);

  close(dictFD);
  close(L2indexFD);
  fprintf(pager, "\n");
  if (pager != stdout)  pclose(pager); 
}

void queryEnglish(char *word) {
  int totalMatch;
  unsigned char index_path[sizeof(INDEX_PATH)+15];

  if (indexFD==NULL) {
    sprintf(index_path, INDEX_PATH "/Index.gdbm");
    indexFD = gdbm_open(index_path, 0, GDBM_READER, 0600, NULL);
    if (indexFD == NULL) {
      fprintf(stderr, "cannot access index file %s\n", index_path);
      gdbm_strerror(gdbm_errno);
      exit(-1);
    }
  }
  
  if (query_mode & WILDCARD_MODE) 
    totalMatch = findAllMatches(word);
  else {
    totalMatch = 1;
    match[0] = strdup(word);
  }

  printAllResult(totalMatch);   
}
  
void getInput(unsigned char *buf) {
  unsigned char *tmpbuf, *tmp;

  tmpbuf = getline("Word: ");

  if (*tmpbuf == '\0') exit(0);

  gl_histadd(tmpbuf);
  buf[0] = '\0';
  tmp = strtok(tmpbuf, " \t\n\r");
  while (tmp) {
    strcat(buf, tmp);
    tmp = strtok(NULL, " \t\n\r");
  } 
}

void main(int argc, char **argv) {
  int i;
  unsigned char buf[256], word[256];

  query_mode = 0;
  signal(SIGPIPE, sig_handle);
  signal(SIGSEGV, sig_handle);
  signal(SIGBUS, sig_handle);

  if (argc < 2) {
    fprintf(stderr, "\ncdict5 (version " CDICT5_VERSION ")\n");
    fprintf(stderr, "usage: %s [word]\n\n", *argv);
    fprintf(stderr, "  find all first %d words matching \"word\"\n", MAX_MATCHES);
    fprintf(stderr, "  \"word\" can be either English or Big-5 Chinese\n");
    fprintf(stderr, "  English-Chinese mode supports wildcards (globbing)\n");
    fprintf(stderr, "  Chinese-English mode supports prefix search (by add '*' at the end)\n");
    fprintf(stderr, "  'doskey'-like function supported in interactive mode\n\n");

    query_mode = INTERACTIVE_MODE;
  } 

  while (1) {
    if (query_mode & INTERACTIVE_MODE) 
      getInput(buf); 
    else {
      buf[0]='\0';
      for (i = 1; i < argc; i++) strcat(buf, argv[i]);
    }

    processArgs(buf, word);

    if (query_mode & QUERY_CHINESE) 
      queryChinese(word);
    else
      queryEnglish(word);

    if (query_mode & INTERACTIVE_MODE) 
      query_mode = INTERACTIVE_MODE;
    else 
      exit(0);
  }
}

