/* �سy�^�~�d�ߩһݪ������� */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <ctype.h>
#include <gdbm.h>
#include <time.h>
#include "cdict5.h"

GDBM_FILE f;
FILE      *FD;
char indexfile[]="?.idx";
int metaindex;

#ifndef LITTLE_ENDIAN
int convertEndian(int i) {
  union {
    int i;    
    char c[4];
  } u, v;
    
  u.i = i;
  v.c[0] = u.c[3];
  v.c[1] = u.c[2];
  v.c[2] = u.c[1];
  v.c[3] = u.c[0];
  
  return v.i; 
}
#endif   

void process(unsigned char *str) {
  int i, newdata_size;
  unsigned char buf[100], *tmp, initial, itemidx[2], *newdata;
  datum key, data;

  for (i=0; i< strlen(str); i++) str[i] = tolower(str[i]);

  buf[0]=0;
  tmp = strtok(str, "-./' ");
  while (tmp) {
    strcat(buf, tmp);
    tmp = strtok(NULL, "-./' ");
  }
  
  initial = *buf;
  tmp = strtok(buf, ",");
  
  while (tmp) {
    if (*tmp != *indexfile) return;
    key.dptr = tmp;
    key.dsize = strlen(tmp)+1;

    itemidx[0] = metaindex&0xFF;
    itemidx[1] = (metaindex>>8)&0xFF;
 
    if (gdbm_exists(f, key)) {
      data = gdbm_fetch(f, key);
      newdata_size = data.dsize+2;
      
      newdata = (unsigned char*)malloc(newdata_size);
      memcpy(newdata, data.dptr, data.dsize);
      free(data.dptr);

      if (memcmp(newdata+(newdata_size-4), itemidx, 2)) {
        memcpy(newdata+(newdata_size-2), itemidx , 2);
        data.dptr = newdata;
        data.dsize = newdata_size;
        if (gdbm_store(f, key, data, GDBM_REPLACE)) {
          gdbm_strerror(gdbm_errno);
          printf("\n");
	  exit(-1);
        }
      }
      free(newdata);       
    } 
    else {
      if (*tmp != initial) return;
      data.dptr = itemidx;
      data.dsize = 2;

      if (gdbm_store(f, key, data, GDBM_REPLACE)) {
        gdbm_strerror(gdbm_errno);
        printf("\n");
        exit(-1);
      }
      fprintf(FD, "%s\n", key.dptr);
    }
    tmp = strtok(NULL, ",");
  }
}

void tran(unsigned char *begin) {
  unsigned char buf[100], buf2[100], rawchar, *tmp, *tmp2;
  unsigned int  i, len, strlen, problem=0, offset=2;

  len = begin[1];

  buf[0]=0;
  strlen=0;

    for (i=2; i<len+2; i++) {
      rawchar = begin[i]^(unsigned char)0xa5;
      
      if (isdigit(rawchar)) problem=1;
      if (rawchar >= 225)      buf[strlen++] = rawchar-225+'a'; 
      else if (rawchar >= 193) {buf[strlen++] = '.'; buf[strlen++]=rawchar-193+'A'; }
      else if (rawchar==172)   { buf[strlen++]='.'; buf[strlen++]=','; }
      else if (rawchar==160)   {buf[strlen++]='.'; buf[strlen++]=' '; }
      else if (rawchar==168)   buf[strlen++] = '('; 
      else if (rawchar >= 129)  buf[strlen++] =  rawchar-129+'a';
      else buf[strlen++]=rawchar;
    } 

    buf[strlen]=0;
    buf2[0]=0;

    if (tmp = strchr(buf, '(')) {
      unsigned char buf3[100];

      *tmp = 0;      
      strcpy(buf2, buf);
      strcpy(buf3, buf);
      tmp2 = strchr(tmp+1, ')');
      if (tmp2==NULL) return;
        
      *tmp2 = 0;
      strcat(buf2, tmp+1);
      strcat(buf2, tmp2+1);   
      strcat(buf3, tmp2+1);
      strcpy(buf, buf3);
    }

    if (tmp = strchr(buf, '(')) *tmp=0;
    if (tmp = strchr(buf2, '(')) *tmp=0;

    if (!problem) {
      process(buf);
      if (buf2[0]) process(buf2);
    }

}

void main() {
  int i, index_len, startTime, word_count;
  int indexFD, dictFD;
  unsigned char o;
  unsigned char buf[128], index_path[128], dict_path[128];
  int *indice;

  unlink("Index.gdbm");
  f=gdbm_open("Index.gdbm", 0, GDBM_WRCREAT|GDBM_FAST, 0600, NULL);
  if (f==NULL) {
    gdbm_strerror(gdbm_errno);
    printf("\n");
    exit(-1);
  }
  
  for (o='a'; o<='z'; o++) {
    sprintf(index_path, DICT_PATH "/%c.i50", o);
    sprintf(dict_path, DICT_PATH "/%c.d50", o);
    indexfile[0]=o;
    word_count = 0;

    startTime = time(NULL);
    indexFD = open(index_path, O_RDONLY);
    dictFD  = open(dict_path, O_RDONLY);
    FD = fopen(indexfile, "w+");  
  
    if (FD == NULL) {
      fprintf(stderr, "cannot open temp file %s for writing\n", indexfile);
      exit(-1);
    }

    if (dictFD < 0 || indexFD < 0) {
      fprintf(stderr, "file %s or %s not open\n", index_path, dict_path);
      exit(-1);
    }
    else 
      fprintf(stderr, "Processing %c\n", o);

    index_len = lseek(indexFD, 0, SEEK_END);
    lseek(indexFD, 0, 0);
  
    indice = (int*)malloc(index_len);
    index_len = read(indexFD, (unsigned char*)indice, index_len);
    if (index_len <= 0) {
      fprintf(stderr, "%s corrupted\n", index_path);
      exit(-1);
    }
    close(indexFD);

    for (i = 0; i < index_len/4; i++) {
#ifndef LITTLE_ENDIAN
      lseek(dictFD, convertEndian(indice[i]) & 0x1FFFFFL, 0);
#else
      lseek(dictFD, indice[i]&0x1FFFFFL, 0);
#endif

      if (read(dictFD, buf, sizeof(buf)) <= 0) {
        fprintf(stderr, "%s corrupted\n", dict_path);
        exit(-1);
      }
      if (*buf/0x10 != 1) {
        fprintf(stderr, "error: %dth word\n", i);
        exit(-1);
      }
   
      metaindex = i;
      tran(buf);
      word_count++;
      if (word_count%0xFF == 0)
      fprintf(stderr, "%d%%\r", word_count*400/index_len);
    }

    close(dictFD);
    fclose(FD);
    free(indice);
    fprintf(stderr, "%c part completed in %d sec\n", o, time(NULL)-startTime);
  }

  fprintf(stderr, "syncing gdbm file..\n");
  startTime = time(NULL);
  gdbm_sync(f);
  gdbm_close(f);
  fprintf(stderr, "completed in %d sec\n", o, time(NULL)-startTime);
  exit(0);
}
