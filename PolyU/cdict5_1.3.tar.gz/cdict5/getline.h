#ifndef _GETLINE_H
#define _GETLINE_H

#ifdef __cplusplus
extern "C" {
#endif

char * getline(char prompt[]);
void gl_histadd(char *);

#ifdef __cplusplus
  }
#endif

#endif /* _GETLINE_H */
