/* �سy�^�~�d�ߩһݪ������� part 2 */  

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <ctype.h>
#include <gdbm.h>

GDBM_FILE f;
FILE      *FD;
char indexfile[]="?.idx";

void main() {
  int fd, fd2, i, flen;
  unsigned char *buf, o;
  datum key, data;

  fprintf(stderr, "Inserting *.idx into Index.gdbm\n");

  f=gdbm_open("Index.gdbm", 0, GDBM_WRCREAT|GDBM_FAST, 0600, NULL);
  if (f==NULL) {
    fprintf(stderr, "gdbm file not open\n");
    exit(-1);
  }
  
  for (o='a'; o<='z'; o++) {
    indexfile[0]=o;

    fd = open(indexfile, O_RDONLY);

    flen = lseek(fd, 0, SEEK_END);
    lseek(fd, 0, SEEK_SET);

    if (fd < 0) {
      fprintf(stderr, "%s not open\n", indexfile);
      exit(-1);
    }
  
    buf = (unsigned char*)malloc(flen+10);

    flen = read(fd, buf, flen+10);
    buf[flen]=0;
    key.dptr = indexfile;
    key.dsize = strlen(indexfile)+1;
    data.dptr = buf;
    data.dsize = flen+1;
    gdbm_store(f, key, data, GDBM_REPLACE);
    close(fd);
    free(buf);
  }

  gdbm_sync(f);
  gdbm_close(f);
  exit(0);
}
