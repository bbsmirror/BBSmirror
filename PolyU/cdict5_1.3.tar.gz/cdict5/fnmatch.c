/* This piece of code is "borrowed" from GNU's C library
   glibc-1.09.1. This is the function fnmatch(). I modify
   some parts and rename to wildcard_match().

   I am sorry for not attaching a GNU GENERAL PUBLIC LICENSE       
   file in this package. It only enlarge the size of this 
   package and is useless. 
*/

#define FNM_NOMATCH 0
#define FNM_MATCH 1

int wildcard_match(const char *pattern, const char *string) {
  register const char *p = pattern, *n = string;
  register char c;

  while ((c = *p++) != '\0')
    {
      switch (c)
	{
	case '?':
	  if (*n == '\0') 
	    return FNM_NOMATCH;
	  break;

	case '*':
	  for (c = *p++; c == '?' || c == '*'; c = *p++, ++n)
	    if (c == '?' && *n == '\0') 
	      return FNM_NOMATCH;

	  if (c == '\0') 
	    return FNM_MATCH;
	  {
	    char c1 = c;
	    for (--p; *n != '\0'; ++n)
	      if ((c == '[' || *n == c1) &&
		  wildcard_match(p, n) == FNM_MATCH) 
	       	    return FNM_MATCH;
	
	    return FNM_NOMATCH;
	  }

	case '[':
	  {
	    register int not;

	    if (*n == '\0')
	      return FNM_NOMATCH;
	    
	    not = (*p == '^');
	    if (not)
	      ++p;

	    c = *p++;
	    for (;;)
	      {
		register char cstart = c, cend = c;

		cstart = cend = cstart;

		if (c == '\0') 
		  return FNM_NOMATCH;
		
		c = *p++;

		if (c == '-' && *p != ']')
		  {
		    cend = *p++;
		    if (cend == '\0') 
 		      return FNM_NOMATCH;
 		    
		    c = *p++;
		  }

		if (*n >= cstart && *n <= cend)
		  goto matched;

		if (c == ']')
		  break;
	      }
	    if (!not) 
	      return FNM_NOMATCH;
	    break;

	  matched:;
	    while (c != ']')
	      {
		if (c == '\0') 
		  return FNM_NOMATCH;
		
		c = *p++;
	      }
	    if (not) 
	      return FNM_NOMATCH;
		
	  }
	  break;

	default:
	  if (c != *n) 
	    return FNM_NOMATCH;
		
	}

      ++n;
    }

  if (*n == '\0') 
    return FNM_MATCH;

  return FNM_NOMATCH;
}

