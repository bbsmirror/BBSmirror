#define INDEX_PATH	"/usr/local/lib/cdict5"
#define DICT_PATH	"/usr/local/lib/cdict5"
#define MAX_MATCHES	200
#define COLUMN		70
#define PAGER		"less -r -E"

#define NO_ANSI			""
#define ANSI_RED		"\033[31m"
#define ANSI_RED_BOLD		"\033[1;31m"
#define ANSI_GREEN		"\033[32m"
#define ANSI_GREEN_BOLD		"\033[1;32m"
#define ANSI_YELLOW		"\033[33m"
#define ANSI_YELLOW_BOLD	"\033[1;33m"
#define ANSI_BLUE		"\033[34m"
#define ANSI_BLUE_BOLD		"\033[1;34m"
#define ANSI_MAGENTA		"\033[35m"
#define ANSI_MAGENTA_BOLD	"\033[1;35m"
#define ANSI_CYAN		"\033[36m"
#define ANSI_CYAN_BOLD		"\033[1;36m"
#define ANSI_WHITE		"\033[37m"
#define ANSI_WHITE_BOLD		"\033[1;37m"
#define ANSI_RESET		"\033[0m"

#define KEYWORD_COLOR		ANSI_YELLOW_BOLD
#define WORD_CLASS_COLOR	ANSI_RED_BOLD
#define IDIOM_COLOR		ANSI_YELLOW
#define EXAMPLE_COLOR		ANSI_CYAN_BOLD
#define INFLEXION_COLOR		ANSI_GREEN_BOLD
#define OTHER_INFO_COLOR	ANSI_CYAN
#define MARKED_COLOR		"\033[1;33;44m"

/*****************************************************/
void queryChinese(unsigned char *);
void printResult(unsigned char *, int); 
int convertEndian(int);
int wildcard_match(const char *, const char *);

#define WILDCARD_MODE (1<<0)
#define QUERY_CHINESE (1<<1)
#define INTERACTIVE_MODE (1<<2)
#define CDICT5_VERSION "1.3"
#include "cdict5.conf"
