/* This program is used to determine 

   1. byte-order of your machine
   2. if /usr/include/sgtty.h exists

   and put the result in "cdict5.conf" file.
*/

#include <stdio.h>
union {
  int i;
  char c[4];
} u;

void main() {

  FILE *FD;

  if ((FD = fopen("cdict5.conf", "w+")) == NULL) {
    fprintf(stderr, "cannot open cdict5.conf for writing\n");
    exit(-1);
  }

  u.i = 1;
  if (u.c[0] == 1) 
    fprintf(FD, "#ifndef LITTLE_ENDIAN\n#define LITTLE_ENDIAN\n#endif\n");
  else 
    fprintf(FD, "#undef LITTLE_ENDIAN\n");

  if (fopen("/usr/include/sgtty.h", "r")) 
    fprintf(FD, "#ifndef TIOCSETN\n#define TIOCSETN\n#endif\n");
  else
    fprintf(FD, "#undef TIOCSETN\n");    

  fclose(FD);
  exit(0);
}
  
