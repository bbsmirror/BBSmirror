#include <stdio.h>
#include "talk.h"
#include "protocols/talkd.h"
typedef struct Protocol {
  char *name;
  int  (*func)();
  char *msg;
} Protocol;

int announce();
int look_up();
int bbs_look_up();
int leave_invite();
int delete();
int help();
int quit();

Protocol protocol[]= {
{"a",announce,"announce"},
{"l",look_up,"look_up"},
{"b",bbs_look_up,"bbs_look_up"},
{"i",leave_invite,"leave_invite"},
{"d",delete,"delete"},
{"h",help,"help"},
{"q",quit,"quit"},
{NULL,NULL,NULL} 
};

Protocol *findcmd();

main()
{
   char buffer[1024];
   Protocol *p;
   open_ctl();
   while ( gets(buffer) != NULL) {
     if (*buffer == 0) break;
     printf("%s\n",buffer);
     p = findcmd(buffer);
     if (p) {
       (*p->func)();
     }
   }
}

Protocol *findcmd (buf)
char *buf;
{
   Protocol *p = protocol;
   while (p != NULL) {
      if (p->name == NULL) continue;
      if (strcmp(p->name,buf)==0)
	return p;
      p++;
   }
   return NULL;
}

int quit()
{
  printf("quit\n");
  exit(0);
}
int announce()
{
  printf("announce\n");
}
int look_up()
{
  printf("look up\n");
}
int bbs_look_up()
{
  printf("bbs look up\n");
}
int leave_invite()
{
  printf("leave invite\n");
}
int delete()
{
  printf("delete\n");
}
int help()
{
   Protocol *p = protocol;
   while (p != NULL) {
     if (p->name == NULL) break;
     printf("%s : %s\n",p->name,p->msg);
     p++;
   }
}
p_error(s)
char *s;
{
  printf("%s",s);
}
