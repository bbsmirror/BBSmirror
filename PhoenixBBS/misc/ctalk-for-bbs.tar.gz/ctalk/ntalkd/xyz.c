/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#define EXTERN
#include "bbs.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/file.h>

#define NO_UTMP_FILE

#ifdef NO_UTMP_FILE		/* ---------- use Share Memory --------- */
#include <sys/ipc.h>
#include <sys/sem.h>
#define USEM_KEY	3784
#define USHM_KEY	3787
#define USHM_SIZE	(MAXACTIVE + 10)

/* --------- It is strange that our system SunOS need mode 600 ----- */
#if defined(AIX) || defined(HP_UX) || \
    defined(NETBSD) || defined(LINUX) || defined(SOLARIS)
#define SEM_MODE	0600
#endif

#if defined(sun)
#define SEM_MODE	600
#endif

struct UTMPFILE {
    struct user_info	uinfo[ USHM_SIZE ];
    time_t		uptime;
} *ulistshm = NULL;

int ulistsemid;

ulisterr( msg )
char	*msg;
{
    write( 1, msg, strlen( msg ) );
    exit( 1 );
}

resolve_ulistshm()
{
    int         shmid;

    if( ulistshm == NULL ) {
	if( (ulistsemid = semget( USEM_KEY, 1, SEM_MODE )) == -1 ) {
	    if( (ulistsemid = semget( USEM_KEY, 1, SEM_MODE|IPC_CREAT )) == -1 )
		ulisterr( "Error! ulistsemid get error!\n" );
	    semctl( ulistsemid, 0, SETVAL, 1 );
	}

	shmid = shmget( USHM_KEY, sizeof( *ulistshm ), 0 );
	if( shmid < 0 ) {
#ifdef BBSNTALKD
	    shmid = shmget( USHM_KEY, sizeof(*ulistshm), IPC_CREAT|0666 );
#else
	    shmid = shmget( USHM_KEY, sizeof(*ulistshm), IPC_CREAT|0600 );
#endif
	    if( shmid < 0 )
		ulisterr( "Error! ulistshm get error!\n" );
	    ulistshm = (void *)shmat( shmid, NULL, 0 );
	    memset( ulistshm, 0, sizeof( *ulistshm ) );
	} else {
	    ulistshm = (void *)shmat( shmid, NULL, 0 );
	}
	if( ulistshm == (void *)-1 )
	    ulisterr( "Error! ulistshm attach error!\n" );
    }
}

ulistlock( op )
{
    struct sembuf sops;

    sops.sem_num = 0;
    sops.sem_flg = SEM_UNDO;
    switch( op ) {
	case LOCK_EX:	sops.sem_op = -1;	break;
	case LOCK_UN:	sops.sem_op = 1;	break;
	default:	return -1;
    }
    semop( ulistsemid, &sops, 1 );
    return 0;
}

int
getnewutmpent(up)
struct user_info *up ;
{
    struct user_info	*uentp;
    time_t	now;
    int		fd, update, i;

    resolve_ulistshm();
    ulistlock( LOCK_EX );
    for( i = 0; i < USHM_SIZE; i++ ) {
	uentp = &(ulistshm->uinfo[ i ]);
	if( !uentp->active || !uentp->pid ) break ;
        if( kill( uentp->pid, 0 ) == -1 ) break ;
    }
    if( i >= USHM_SIZE ) {
	ulistlock( LOCK_UN );
	return -1;
    }
    ulistshm->uinfo[i] = *up;
    now = time(0);
    update = 0;
    if( now > ulistshm->uptime + 60 ) {
	ulistshm->uptime = now;
	update = 1;
    }
    ulistlock( LOCK_UN );

    if( update ) {
	if( (fd = open(ULIST,O_RDWR|O_CREAT,0600)) > 0 ) {
	    write( fd, ulistshm->uinfo, sizeof( ulistshm->uinfo ) );
	    close( fd );
	}
    }
    return i+1 ;
}

int
apply_ulist( fptr )
int (*fptr)();
{
    struct user_info	*uentp, utmp;
    int		i;

    resolve_ulistshm();
    for( i = 0; i < USHM_SIZE; i++ ) {
	uentp = &(ulistshm->uinfo[ i ]);
	if( uentp->active && uentp->pid && kill( uentp->pid, 0 ) == -1 )
	    memset( uentp, 0, sizeof( struct user_info ) );
	utmp = *uentp;
	if( (*fptr)( &utmp ) == QUIT )
	    return QUIT;
    }
    return 0;
}

int
search_ulist( uentp, fptr, farg )
struct user_info *uentp;
int (*fptr)();
int farg;
{
    struct user_info	utmp;
    int		i;

    resolve_ulistshm();
    for( i = 0; i < USHM_SIZE; i++ ) {
	*uentp = ulistshm->uinfo[ i ];
	if( (*fptr)( farg, uentp ) )
	    return i+1;
    }
    return 0;
}

update_ulist( uentp, uent )
struct user_info *uentp;
{
    int		i;

    resolve_ulistshm();
    ulistlock( LOCK_EX );
    if( uent > 0 && uent <= USHM_SIZE ) {
	ulistshm->uinfo[ uent - 1 ] = *uentp;
    }
    ulistlock( LOCK_UN );
}

#else				/* ----------- use .UTMP file ---------- */
int
getnewutmpent(up)
struct user_info *up ;
{
    int fd ;
    int i ;
    struct user_info utmp ;

    flush();
    if((fd = open(ULIST,O_RDWR|O_CREAT,0600)) == -1) {
	perror("open") ;
	return -1 ;
    }
    flock(fd,LOCK_EX) ;
    i = 0 ;
    while(read(fd,&utmp,sizeof(utmp)) == sizeof(utmp)) {
	if(!utmp.active || !utmp.pid) break ;
        if(kill(utmp.pid,0) == -1) break ;
	i++ ;
    }
    if(lseek(fd,sizeof(utmp)*i,L_SET) == -1) {
	flock(fd,LOCK_UN) ;
	close(fd) ;
	return -1 ;
    }
    write(fd,up,sizeof(utmp)) ;
    flock(fd,LOCK_UN) ;
    close(fd) ;
    return i+1 ;
}

int
apply_ulist( fptr )
int (*fptr)();
{
    return apply_record( ULIST, fptr, sizeof( struct user_info ) );
}

int
search_ulist( uentp, fptr, farg )
struct user_info *uentp;
int (*fptr)();
int farg;
{
    return search_record( ULIST, uentp, sizeof( struct user_info ),
		fptr, farg );
}

update_ulist( uentp, uent )
struct user_info *uentp;
{
    substitute_record( ULIST, uentp, sizeof( struct user_info ), uent );
}
#endif				/* ------------ NO_UTMP_FILE ----------- */

update_utmp()
{
    update_ulist( &uinfo, utmpent );
}

modify_user_mode( mode )
{
    uinfo.mode = mode;
    update_ulist( &uinfo, utmpent );
    return 0;
}

