#!/bin/sh
exec /bin/rejectcall $*
