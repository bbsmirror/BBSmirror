#ifndef INNBBSD_H
#define INNBBSD_H
#include "daemon.h"

#ifndef ADMINUSER
# define ADMINUSER "usenet@csie.nctu.edu.tw"
#endif

#endif
