#include <sys/file.h>
#include "his.h"

art_t article ;
char dbmfile[MAXPATHLEN];
char indexfile[MAXPATHLEN];
char savedindexfile[MAXPATHLEN];
char infofile[MAXPATHLEN];
FILE *indexfp;

#define DEBUG 1
#undef DEBUG

/* path/artno path/artno<tab>subject<tab>from<tab>date<tab>mid<tab>rid
   <tab>size<tab>lines<tab>xref
*/

char *deRe(buf)
char *buf;
{
   if (strncasecmp(buf,"Re: ",4) == 0) return buf+4;
   if (strncasecmp(buf,"Re:",3) == 0) return buf+3;
   return buf;
}

getheader(buf)
char *buf;
{
	char *ptr, *namea, *nameb, *from;
	ptr = (char*)strchr(buf, '\t'); /* subject */
	if (ptr == NULL) {
		return -1;
	}
	*ptr++ = '\0';	
	strncpy(article.subject,deRe(deRe(buf)),LEN-1);
	buf = ptr;
	ptr = (char*)strchr(buf, '\t'); /* from */
	if (ptr == NULL) {
		return -1;
	}
	*ptr++ = '\0';	
	namea = (char*)strchr(buf,'(');
	nameb = (char*)strrchr(buf,')');
	if (namea != NULL && nameb != NULL) { /* name */
	  strncpy(article.name,namea+1,nameb - namea - 1);
	  article.name[nameb - namea - 1] = '\0';
	  *namea = '\0';
	} else {
	  article.name[0] = '\0';
	}
	while (*buf && *buf == ' ')  buf++;
	from = (char*)strchr(buf,' ');
	if (from != NULL) *from = '\0';
	strncpy(article.from,buf,LEN-1);
        buf = ptr;
	ptr = (char*)strchr(buf, '\t'); /* date */
	if (ptr == NULL) {
		return -1;
	}
	*ptr++ = '\0';	
	article.date = parsedate(buf,NULL);
        buf = ptr;
	ptr = (char*)strchr(buf, '\t'); /* mid */
	if (ptr == NULL) {
		return -1;
	}
	*ptr++ = '\0';	
        buf = ptr;
	ptr = (char*)strchr(buf, '\t'); /* rid */
	if (ptr == NULL) {
		article.lines = 0;
		article.xref[0] = '\0';
		return 0;
	}
	*ptr++ = '\0';	
        buf = ptr;
	ptr = (char*)strchr(buf, '\t'); /* size */
	if (ptr == NULL) {
		article.lines = 0;
		article.xref[0] = '\0';
		return 0;
	}
	*ptr++ = '\0';	
        buf = ptr;
	ptr = (char*)strchr(buf, '\t'); /* lines */
	if (ptr == NULL) {
		article.lines = 0;
		article.xref[0] = '\0';
		return 0;
	}
	*ptr++ = '\0';	
	article.lines = atol(buf);
        buf = ptr;
	ptr = (char*)strchr(buf, ':'); /* lines */
	if (ptr == NULL) {
		article.xref[0] = '\0';
		return 0;
	}
	strncpy(article.xref,ptr+1,LEN-1);
	return 0;
}

static datum content, inputkey, inputvalue;
static char dboutput[1025];
static char dbinput[1025];
static char valueinput[100];
enum {SUBJECT, FROM, NAME};
char *DBfetch(key)
char *key;
{
   int i;
   char *tail, *ptr;
   if (key == NULL) return NULL;
   sprintf(dbinput,"%.510s",key);
   inputkey.dptr = dbinput;
   inputkey.dsize = strlen(dbinput);
   content.dptr = dboutput;
   ptr = (char*)HISfilesfor(&inputkey,&content);
   if (ptr == NULL) {
       return NULL;
   }
   return ptr;
}

DBstore(key,paths)
char *key;
char *paths;
{
   int i;
   char *tail;
   time_t now;
   time(&now);
   if (key == NULL) return -1;
   sprintf(dbinput,"%.510s",key);
   inputkey.dptr = dbinput;
   inputkey.dsize = strlen(dbinput);
   if (HISwrite(&inputkey, now, paths ) == FALSE) {
      return -1;
   } else {
      return 0;
   }
}

printarticle()
{
   printf("\nsubject:%s. from :%s.\n",article.subject,article.from);
   printf("name   :%s. date :%d.\n",article.name,article.date);
   printf("lines  :%d. xref :%s.\n",article.lines,article.xref);
   printf("artnum :%d\n",article.artnum);
}

int storeDB(mid,paths)
char *mid;
char *paths;
{
   char *key,*ptr;
   int rel;
   ptr = DBfetch(mid); 
   if (ptr != NULL) {
     return 0;
   } else {
     return DBstore(mid , paths);
   }
}

my_mkdir (idir,mode)
char *idir;
int mode;
{
	char buffer[LEN];
	char *ptr, *dir = buffer;
	struct stat st;
	strncpy(dir, idir, LEN - 1);
	for (;dir!=NULL && *dir;) {
		ptr = (char*)strchr(dir,'/');
		if (ptr != NULL) {
		    *ptr = '\0';
		}
	        if (stat(dir,&st) != 0) {
		    if (mkdir(dir,mode) != 0 ) 
			 return -1;
		}
		chdir(dir);
		if (ptr != NULL)
		  dir = ptr +1;
		else
		  dir = ptr;
	}
	return 0;
}

