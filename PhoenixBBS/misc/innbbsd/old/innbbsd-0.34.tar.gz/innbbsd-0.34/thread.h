#ifndef THREAD_H
#define THREAD_H
#include <time.h>
typedef struct NOT {
	char *filename,*from,*date;
	int offset,line;
	int artindex;
} not_t;

typedef struct NOV {
	int article;
	char *subject;
	char *from,*filename,*xthread;
	int numart,offset,line;
	int artindex;
	time_t date;
	not_t *not;
	int notsize;
} nov_t;
#endif
