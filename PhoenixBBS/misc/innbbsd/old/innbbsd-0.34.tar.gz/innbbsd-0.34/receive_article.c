/*
      BBS implementation dependendent part

      The only two interfaces you must provide
      
      #include "inntobbs.h" 
      int receive_article(); 
      0 success
      not 0 fail
       
      if (storeDB(HEADER[MID_H], hispaths) < 0) {
         .... fail
      }
	     
      int cancel_article_front( char *msgid );	     
      0 success
      not 0 fail
      
      char *ptr = (char*)DBfetch(msgid);

     ���줧�峹���e (body)�b char *BODY, 
     ���Y (header)�b char *HEADER[]
     SUBJECT_H, FROM_H, DATE_H, MID_H, NEWSGROUPS_H,
     NNTPPOSTINGHOST_H, NNTPHOST_H, CONTROL_H, PATH_H,
     ORGANIZATION_H
*/

/* 
   Sample Implementation
   
   receive_article()         --> post_article()   --> bbspost_write_post();
   cacnel_article_front(mid) --> cancel_article() --> bbspost_write_cancel();
*/


#include "innbbsconf.h"
#include "daemon.h"
#include "bbslib.h"
#include "inntobbs.h"

char *post_article ARG((char *, char *, char *, int (*)(),char *));
int cancel_article ARG(( char*, char*, char* ));

report()
{
	/* Function called from record.o */
	/* Please leave this function empty */
}

/* process post write */
bbspost_write_post(fh, board, filename)
int fh;
char *board;
char *filename;
{
       char *fptr, *ptr;
       FILE *fhfd = fdopen(fh,"w");

       if (fhfd == NULL) {
	  fprintf(stderr,"can't fdopen\n");
	  return -1;
       }

       fprintf(fhfd,"�o�H�H: %s, �H��: %s\n",FROM, board);
       fprintf(fhfd,"��  �D: %s\n", SUBJECT);
       fprintf(fhfd,"�o�H��: %s (%s)\n",SITE,DATE);
       fprintf(fhfd,"��H��: %s\n",PATH);
       fprintf(fhfd,"\n");
       for (fptr = BODY, ptr = strchr(fptr,'\r'); ptr != NULL && *ptr != '\0' ; fptr = ptr+1, ptr = strchr(fptr,'\r')) {
	  int ch = *ptr;
	  *ptr = '\0';
	  fputs(fptr, fhfd);
	  *ptr = ch;
       }
       fputs(fptr,fhfd);
       fflush(fhfd);
       fclose(fhfd);
       return 0;
}

/* process cancel write */
bbspost_write_cancel(fh, board, filename)
int fh;
char *board, *filename;
{
       char *fptr, *ptr;
       FILE *fhfd = fdopen(fh,"w"), *fp;
       char buffer[256];

       if (fhfd == NULL) {
	  fprintf(stderr,"can't fdopen\n");
	  return -1;
       }

       fprintf(fhfd,"�o�H�H: %s, �H��: %s\n",FROM, board);
       fprintf(fhfd,"��  �D: %s\n", SUBJECT);
       fprintf(fhfd,"�o�H��: %s (%s)\n",SITE,DATE);
       fprintf(fhfd,"��H��: %s\n",PATH);
       fprintf(fhfd,"\n");
       for (fptr = BODY, ptr = strchr(fptr,'\r'); ptr != NULL && *ptr != '\0' ; fptr = ptr+1, ptr = strchr(fptr,'\r')) {
	  int ch = *ptr;
	  *ptr = '\0';
	  fputs(fptr, fhfd);
	  *ptr = ch;
       }
       fputs(fptr,fhfd);
       fprintf(fhfd,"\n---------------------\n");
       fp = fopen(filename,"r");
       if (fp == NULL) {
	     fprintf(stderr, "can't open %s\n", filename);
	     return -1;
       }
       while (fgets( buffer, sizeof buffer, fp)!=NULL) {
          fputs(buffer,fhfd);
       }
       fclose(fp);
       fflush(fhfd);
       fclose(fhfd);

       {
	  fp = fopen(filename,"w");
	  if (fp == NULL) {
	     fprintf(stderr, "can't write %s\n", filename);
	     return -1;
	  }
          fprintf(fp,"�o�H�H: %s, �H��: %s\n",FROM, board);
          fprintf(fp,"��  �D: %s\n", SUBJECT);
          fprintf(fp,"�o�H��: %s (%s)\n",SITE,DATE);
          fprintf(fp,"��H��: %s\n",PATH);
          fprintf(fp,"\n");
          for (fptr = BODY, ptr = strchr(fptr,'\r'); ptr != NULL && *ptr != '\0' ; fptr = ptr+1, ptr = strchr(fptr,'\r')) {
  	     *ptr = '\0';
	     fputs(fptr, fp);
          }
          fputs(fptr,fp);
	  fclose(fp);
       }
       return 0;
}

receive_article()
{
   char *user, *userptr; 
   char *ngptr, *nngptr, *pathptr;
   static char userid[32];
   static char xdate[32];
   static char xpath[80];
   time_t datevalue;
   newsfeeds_t *nf;
   char *boardhome;
   char hispaths[4096];

   if (FROM == NULL) {
     bbslog( ":Err: article without usrid %s\n",MSGID);
     return 0;
   }
   user = (char*)strchr(FROM,'@');
   if (user != NULL) {
     *user = '\0';
     userptr = (char*)strchr(FROM,'.');
     if (userptr != NULL) {
       *userptr = '\0';
       strncpy(userid, FROM, sizeof userid);
       *userptr = '.';
     } else {
       strncpy(userid, FROM, sizeof userid);
     }
     strcat(userid,".");
     *user = '@';
   } else {
     strncpy(userid, FROM, sizeof userid);
   }
   datevalue = parsedate(DATE,NULL);
   if (datevalue > 0) {
     char *p ; 
     strncpy(xdate, ctime(&datevalue), sizeof(xdate));
     p = (char*)strchr(xdate,'\n');
     if (p != NULL) *p = '\0';
     DATE = xdate;
   } 
   if (SITE && strcasecmp("Computer Science & Information Engineering NCTU",SITE) ==0) {
      SITE = "��j��u News Server";
   } else if (SITE && strcasecmp("Dep. Computer Sci. & Information Eng., Chiao Tung Univ., Taiwan, R.O.C",SITE) ==0) {
      SITE = "��j��u News Server";
   } else if ( SITE == NULL || *SITE == '\0') {
      SITE = "(Unknown)";
   } 
   if (strlen(MYBBSID) > 70) {
      bbslog(" :Err: your bbsid %s too long\n", MYBBSID);
      return 0;
   }

   for (pathptr = PATH; pathptr != NULL && (pathptr = strstr(pathptr,".edu.tw")) != NULL; ) {
	   if (pathptr != NULL) {
	      strcpy(pathptr,pathptr+7);
	   }
   }

   sprintf(xpath,"%s!%.*s",MYBBSID, 70 - strlen(MYBBSID), PATH); 
   PATH = xpath;
   echomaillog(); 
   *hispaths = '\0';
   for ( ngptr = GROUPS, nngptr = (char*) strchr(ngptr,','); ngptr != NULL && *ngptr != '\0'; nngptr = (char*)strchr(ngptr,',')) {
	  
          if (nngptr != NULL) {
	    *nngptr = '\0';
	  }
	  nf = (newsfeeds_t*)search_group(ngptr);
	  /*printf("board %s\n",nf->board); */
	  if (nf != NULL)
	    boardhome = (char*)fileglue("%s/boards/%s",BBSHOME,nf->board);
	  if ( nf == NULL) {
	    if( strstr( ngptr, "tw.bbs" ) != NULL ) {
		    bbslog( "unknown \'%s\' in %s\n", ngptr, GROUPS );
	    }
	  } else if ( nf->path == NULL) {
	  } else if (!isdir( boardhome)) {
	      bbslog( ":Err: unable to write %s\n",boardhome);
	  } else {
	    char *fname;
	    /*if ( !isdir( boardhome )) {
	      bbslog( ":Err: unable to write %s\n",boardhome);
	      testandmkdir(boardhome);
	    }*/
	    fname = (char*)post_article(boardhome,userid, nf->board, bbspost_write_post,NULL );  
	    if (fname != NULL) {
	      fname = (char*)fileglue("%s/%s",nf->board,fname);
	      if (strlen(fname) + strlen(hispaths) + 1 < sizeof(hispaths)) { 
	       strcat(hispaths,fname);
	       strcat(hispaths," ");
              }
	    } else {
	      /*return -1;*/
	      bbslog("fname is full %s\n",boardhome);
	    }
	  }

	  if (nngptr != NULL) 
            ngptr = nngptr + 1; 
          else
	    break;
   }
   if (storeDB(HEADER[MID_H], hispaths) < 0) {
     bbslog("store DB fail\n");
     return -1;
   }
   return 0;
}

cancel_article_front(msgid)
char* msgid;
{
	char *ptr = (char*)DBfetch(msgid);
	char *filelist, filename[2048];
	if (ptr == NULL) {
		return 0;
	}
#ifdef DEBUG
	printf("**** try to cancel %s *****\n",ptr);
#endif
	filelist = strchr(ptr,'\t');
	if (filelist != NULL) {
	   filelist++;
	}
	for ( ptr =  filelist; ptr && *ptr; ) {
	  char *file;
          for (; *ptr && isspace(*ptr) ; ptr++); 
	  if (*ptr == '\0') break;
	  file = ptr;
          for (ptr++; *ptr && !isspace(*ptr) ; ptr++); 
	  if (*ptr != '\0') {
	     *ptr++ = '\0';
	  } 
	  sprintf(filename,"%s/boards/%s",BBSHOME, file);
	  if (isfile(filename)) {
	      FILE *fp = fopen(filename,"r");
	      char buffer[1024];
	      char *xfrom, *xpath, *boardhome;

	      if (fp == NULL) continue;
	      while (fgets(buffer,sizeof buffer, fp) != NULL) {
		 char *hptr;
		 if (buffer[0]=='\n') break;
		 hptr = strchr(buffer,'\n');
		 if (hptr != NULL) *hptr = '\0';
		 if (strncmp(buffer,"�o�H�H: ",8)==0) {
		    char* n;
		    n = strrchr(buffer,',');
		    if (n!=NULL) *n = '\0';
		    xfrom = buffer+8;
		 } else if (strncmp(buffer,"��H��: ",8)==0) {
		    xpath = buffer+8;
		 }
	      }
	      fclose(fp);
	      if( !strcmp(HEADER[FROM_H],xfrom)) {
		bbslog( "Invalid cancel %s, path: %s!%s\n",FROM,MYBBSID,PATH);
		return 0;
	      }
	      bbslog( "cancel post %s\n",filename );
	      boardhome = (char*)fileglue("%s/boards/deleted", BBSHOME);
	      testandmkdir(boardhome);
	      if (isdir(boardhome)) {
		 char subject[1024];
		 char *fname;
		 if (POSTHOST) {
		   sprintf(subject,"cancel by: %.1000s", POSTHOST);
                 } else {
		   char *body;
		   body = strchr(BODY,'\r');
		   if (body != NULL) *body = '\0';
		   body = strchr(BODY,'\n');
		   if (body != NULL) *body = '\0';
		   sprintf(subject,"%.1000s", BODY);
		   if (body != NULL) *body = '\n';
		 } 
		 SUBJECT = subject;
	         fname = (char*)post_article(boardhome, FROM, "deleted", bbspost_write_cancel,filename);  
		 if (fname != NULL) {
		   if (storeDB(HEADER[MID_H], (char*)fileglue("deleted/%s",fname)) < 0) {
		       /* should do something */
     		       bbslog("store DB fail\n");
		       return -1;
		   }
		 } else {
		   bbslog(" fname is null %s %s\n",boardhome, filename);
		   return -1;
                 }
	      }
	      bbslog("**** %s should be removed\n", filename);
	      /*unlink(filename);*/
	      {
		 char *fp = strrchr(file,'/');
		 if (fp != NULL) *fp = '\0';
	         cancel_article(BBSHOME, file, fp+1);
		 if (fp != NULL) *fp = '/';
	      }
	  }
	}
	return 0;
}

char *post_article( homepath, userid,  board, writebody, pathname )
char *homepath;
char *userid, *board ;
int (*writebody)();
char *pathname;
{
    struct userec	record;
    struct fileheader	header;
    char        *subject = SUBJECT;
    char	index[ MAXPATHLEN ]; 
    static char	name[ MAXPATHLEN ]; 
    char 	article[ MAXPATHLEN ];
    char	buf[ MAXPATHLEN ], *ptr;
    FILE	*fidx;
    int		fh;
    time_t	now;

    sprintf( index, "%s/.DIR", homepath );
    if( (fidx = fopen( index, "r" )) == NULL ) {
	if( (fidx = fopen( index, "w" )) == NULL ) {
	    printf( ":Err: Unable to post in %s.\n", homepath );
	    return NULL;
	}
    }
    fclose( fidx );

    now = time( NULL );
    sprintf( name, "M.%d.A", now );
    ptr = strrchr( name, 'A' );
    while( 1 ) {
	sprintf( article, "%s/%s", homepath, name );
	fh = open( article, O_CREAT | O_EXCL | O_WRONLY, 0644 );
	if( fh != -1 )  break;
/* to solve client gateway problem, add now instead of add A, */
	now += 60; 
        sprintf( name, "M.%d.A", now );
/*
	if( *ptr < 'Z' )  (*ptr)++;
	else  ptr++, *ptr = 'A', ptr[1] = '\0';
*/
    }

#ifdef DEBUG
    printf( "post to %s\n", article );
#endif

    if (writebody) {
      if ((*writebody)(fh, board, pathname) < 0)
       return NULL;
    } else {
      if (bbspost_write_post(fh, board, pathname) < 0)
       return NULL;
    }

    close( fh );

    bzero( (void *)&header, sizeof( header ) );
    strcpy( header.filename, name );
    strncpy( header.owner, userid, IDLEN );
    strncpy( header.title, subject, STRLEN );
    header.filename[ STRLEN - 1 ] = 'M';
    append_record( index, &header, sizeof( header ) );
    return name;
}

cancel_article( homepath, board, file )
char    *homepath;
char	*board, *file;
{
    struct fileheader	header;
    struct stat 	state;
    char	dirname[ MAXPATHLEN ];
    char	buf[ MAXPATHLEN ];
    long	numents, size, time, now;
    int		fd, lower, ent;

    if( file == NULL || file[0] != 'M' || file[1] != '.' ||
	(time = atoi( file+2 )) <= 0 )
	return 0;
    size = sizeof( header );
    sprintf( dirname, "%s/boards/%s/.DIR", homepath, board );
    if( (fd = open( dirname, O_RDWR )) == -1 )
	return 0;
    flock( fd, LOCK_EX );
    fstat( fd, &state );
    ent = ((long)state.st_size) / size;
    lower = 0;
    while( 1 ) {
	ent -= 8;
	if( ent <= 0 || lower >= 2 )
	    break;
	lseek( fd, size * ent, SEEK_SET );
	if( read( fd, &header, size ) != size ) {
	    ent = 0;
	    break;
	}
	now = atoi( header.filename + 2 );
	lower = (now < time) ? lower + 1 : 0;
    }
    if( ent < 0 )  ent = 0;
    while( read( fd, &header, size ) == size ) {
	if( strcmp( file, header.filename ) == 0 ) {
	    sprintf( buf, "-%s", header.owner );
	    strcpy( header.owner, buf );
	    strcpy( header.title, "<< article canceled >>" );
	    lseek( fd, -size, SEEK_CUR );
	    safewrite( fd, &header, size );
	    break;
	}
	now = atoi( header.filename + 2 );
	if( now > time )
	    break;
    }
    flock( fd, LOCK_UN );
    close( fd );
    return 0;
}
