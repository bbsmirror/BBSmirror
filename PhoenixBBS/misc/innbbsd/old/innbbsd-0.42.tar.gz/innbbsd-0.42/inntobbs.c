#include <stdio.h>
#include "daemon.h"
#include "bbslib.h"
#include <time.h>

#define INNTOBBS
#include "inntobbs.h"

typedef struct Header {
  char *name;
  int  id;
} header_t;

/*enum HeaderValue {
SUBJECT_H, FROM_H, DATE_H, MID_H, NEWSGROUPS_H,
NNTPPOSTINGHOST_H, NNTPHOST_H, CONTROL_H, PATH_H,
ORGANIZATION_H, LASTHEADER,
};
*/

char *strchr ARG((char*,int));
char *strrchr ARG((char*,int));
char *strstr ARG((char*,char*));

header_t headertable[] = {
"Subject"   ,SUBJECT_H,
"From"      ,FROM_H,
"Date"      ,DATE_H,
"Message-ID",MID_H,
"Newsgroups",NEWSGROUPS_H,
"NNTP-Posting-Host",NNTPPOSTINGHOST_H, 
"NNTP-Host", NNTPHOST_H,
"Control",   CONTROL_H,
"Path",      PATH_H,
"Organization", ORGANIZATION_H,
};

char *HEADER[LASTHEADER];
char *BODY;
char *FROM, *SUBJECT, *SITE, *DATE, *POSTHOST, 
     *NNTPHOST, *PATH, *GROUPS, *MSGID, *CONTROL;

#ifdef PalmBBS
char **XHEADER;
char *XPATH;
#endif

echomaillog() 
{
   static FILE* echomailfp = NULL;

   if (echomailfp == NULL) {
      echomailfp = fopen(ECHOMAIL,"a");
   }

   if( echomailfp != NULL ) {
	fprintf(echomailfp,"\n");
	fprintf(echomailfp,"�o�H�H: %s, �H��: %s\n", FROM, GROUPS);
	fprintf(echomailfp,"��  �D: %s\n", SUBJECT);
	fprintf(echomailfp,"�o�H��: %s (%s)\n", SITE, DATE);
	fprintf(echomailfp,"��H��: %s (%s)\n", PATH, REMOTEHOSTNAME);
	fflush(echomailfp);
   }
}

int headercmp(a,b)
header_t *a, *b;
{
   return strcasecmp(a->name, b->name);
}

int readlines(client)
ClientType *client;
{
    int fd = client->fd;
    char *buffer = client->buffer;
    buffer_t *in = &client->in;
    char *front = in->data, *ptr, *hptr;
    int i;

    for (i=0; i < LASTHEADER; i++ ) 
      HEADER[i] = NULL;
    for (ptr = (char*)strchr(in->data,'\n'); ptr != NULL && *ptr != '\0' ; front = ptr+1, ptr = (char*)strchr(front,'\n')) {
	*ptr = '\0';
        if (front[0] == '\r' || front[1] == '\n') {
	   BODY = front+2;
	   break;
        }
        hptr = (char*)strchr(front,':');
	if (hptr != NULL && hptr[1] == ' ') {
	   int value;
	   *hptr = '\0';
           value = headervalue(front); 
	   if (value != -1) {
	      char *tp;
	      HEADER[value] = hptr + 2;
	      if ((tp = (char*)strchr(HEADER[value],'\r'))!=NULL)
                 *tp = '\0';
	   }
	   *hptr = ':';
	}
	/**ptr = '\n';*/
    }
    NNTPHOST = HEADER[NNTPHOST_H];
    PATH     = HEADER[PATH_H];
    FROM     = HEADER[FROM_H];
    GROUPS   = HEADER[NEWSGROUPS_H];
    SUBJECT  = HEADER[SUBJECT_H];
    DATE     = HEADER[DATE_H];
    SITE     = HEADER[ORGANIZATION_H];
    MSGID    = HEADER[MID_H];
    CONTROL  = HEADER[CONTROL_H];
    POSTHOST = HEADER[NNTPPOSTINGHOST_H];
#ifdef PalmBBS
    XPATH    = PATH;
    XHEADER  = HEADER;
#endif
}

int headervalue(inputheader)
char *inputheader;
{
   header_t key, *findkey;
   static int hasinit=0;

   if (hasinit == 0) {
      article_init();
      hasinit = 1;
   }

   key.name = inputheader;
   findkey = ( header_t *)bsearch (
		   (char *) &key, (char *) headertable, 
		   sizeof(headertable)/ sizeof(header_t), sizeof (key), 
		   headercmp);
   if (findkey != NULL) return findkey->id;
   return -1;
}

article_init()
{
   int i;
   static int article_inited = 0;

   if (article_inited) return;
   article_inited = 1;

   qsort(headertable, sizeof(headertable)/ sizeof(header_t), sizeof(header_t),
	 headercmp);
   for (i=0; i < LASTHEADER; i++ ) 
      HEADER[i] = NULL;
}

#ifdef INNTOBBS_MAIN
main()
{
    int i,j,k,l,m,n,o,p,q;
    article_init(); 
    i = headervalue("Subject");
    j = headervalue("From");
    k = headervalue("Date");
    l = headervalue("NNTP-Posting-Host");
    m = headervalue("Newsgroups");
    n = headervalue("Message-ID");
}
#endif
