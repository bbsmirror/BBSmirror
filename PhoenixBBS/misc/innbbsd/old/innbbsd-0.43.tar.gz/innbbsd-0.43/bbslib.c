#if defined( LINUX )
# include "innbbsconf.h"
# include "bbslib.h"
# include <varargs.h>
#else
# include <varargs.h>
# include "innbbsconf.h"
# include "bbslib.h"
#endif

char INNBBSCONF[MAXPATHLEN];
char INNDHOME[MAXPATHLEN];
char HISTORY[MAXPATHLEN];
char LOGFILE[MAXPATHLEN];
char MYBBSID[MAXPATHLEN];
char ECHOMAIL[MAXPATHLEN];
char LOCALDAEMON[MAXPATHLEN];

int His_Maint_Min= HIS_MAINT_MIN;
int His_Maint_Hour= HIS_MAINT_HOUR;
int Expiredays  = EXPIREDAYS;

nodelist_t *NODELIST;
newsfeeds_t *NEWSFEEDS=NULL;
static char *NODELIST_BUF, *NEWSFEEDS_BUF;
int NFCOUNT, NLCOUNT;
int LOCALNODELIST=0, NONENEWSFEEDS=0;

#ifndef _PATH_BBSHOME
# define _PATH_BBSHOME "/u/staff/bbsroot/csie_util/bntpd/home"
#endif

char BBSHOME[]= _PATH_BBSHOME;
static FILE *bbslogfp;

static int 
verboseFlag=0;

static char*
verboseFilename=NULL;
static char verbosename[MAXPATHLEN];

verboseon(filename)
char *filename;
{
  verboseFlag = 1;
  if ( filename != NULL ) {
    if (strchr(filename,'/') == NULL) {
       sprintf(verbosename,"%s/innd/%s",BBSHOME,filename);
       filename = verbosename;
    } 
  } 
  verboseFilename = filename;
}
verboseoff()
{
  verboseFlag = 0;
}

verboselog(va_alist)
va_dcl
{
	va_list ap;
	register char* fmt;
	char datebuf[40];
	time_t now;

	if (verboseFlag == 0) return;

	va_start(ap);

	time(&now);
	strftime(datebuf, sizeof(datebuf), "%b %d %X ", localtime(&now));

	if (bbslogfp == NULL) {
	   if (verboseFilename != NULL)
	     bbslogfp = fopen(verboseFilename, "a");
	   else
	     bbslogfp = fdopen(1, "a");
	}
	if (bbslogfp == NULL) { va_end(ap); return; }
	fmt = va_arg(ap, char *) ;
	fprintf(bbslogfp,"%s[%d] ",datebuf, getpid());
	vfprintf(bbslogfp, fmt, ap);
	fflush(bbslogfp);
	va_end(ap);
}

#ifdef PalmBBS
xbbslog(va_alist)
#else
bbslog(va_alist)
#endif
va_dcl
{
	va_list ap;
	register char* fmt;
	char datebuf[40];
	time_t now;

	va_start(ap);

	time(&now);
	strftime(datebuf, sizeof(datebuf), "%b %d %X ", localtime(&now));

	if (bbslogfp == NULL) {
	   bbslogfp = fopen(LOGFILE, "a");
	}
	if (bbslogfp == NULL) { va_end(ap); return; }
	fmt = va_arg(ap, char *) ;
	fputs(datebuf,bbslogfp);
	vfprintf(bbslogfp, fmt, ap);
	fflush(bbslogfp);
	va_end(ap);
}

initial_bbs()
{
   FILE* FN;
   struct stat st;
   int fd, i;
   char *bbsnameptr=NULL; 

   LOCALNODELIST=0, NONENEWSFEEDS =0;
   sprintf(INNDHOME,"%s/innd",BBSHOME);
   sprintf(HISTORY, "%s/history",INNDHOME);
   sprintf(LOGFILE, "%s/bbslog",INNDHOME);
   sprintf(ECHOMAIL,"%s/echomail.log",BBSHOME);
   sprintf(LOCALDAEMON,"%s/.innbbsd",INNDHOME);
   sprintf(INNBBSCONF,"%s/innbbs.conf",INNDHOME);

   if (isfile(INNBBSCONF)) {
     FILE *conf;
     char buffer[MAXPATHLEN];
     conf = fopen(INNBBSCONF,"r");
     if (conf != NULL) {
       while (fgets( buffer, sizeof buffer, conf) != NULL) {
	 char *ptr, *front=NULL, *value=NULL, *value2=NULL, *value3=NULL;
	 if ( buffer[0] == '#' || buffer[0] == '\n') continue;
	 for ( front = buffer; *front && isspace(*front); front++);
	 for ( ptr = front; *ptr && !isspace(*ptr) ; ptr++) ;
	 if (*ptr == '\0') continue;
	 *ptr++ = '\0';
	 for ( ; *ptr && isspace(*ptr) ; ptr++) ;
	 if (*ptr == '\0') continue;
	 value = ptr++;
	 for ( ; *ptr && !isspace(*ptr) ; ptr++) ;
	 if (*ptr) {
	   *ptr++ = '\0';
	   for ( ; *ptr && isspace(*ptr) ; ptr++) ;
	   value2 = ptr++;
	   for ( ; *ptr && !isspace(*ptr) ; ptr++) ;
	   if (*ptr) {
	     *ptr++ = '\0';
	     for ( ; *ptr && isspace(*ptr) ; ptr++) ;
	     value3 = ptr++;
	     for ( ; *ptr && !isspace(*ptr) ; ptr++) ;
	     if (*ptr) {
	       *ptr++ = '\0';
	     }
	   }
	 }
	 if ( strcasecmp(front,"expiredays") == 0) {
		Expiredays = atoi(value);
		if (Expiredays < 0) {
		   Expiredays = EXPIREDAYS;
		}
	 } else if ( strcasecmp(front,"expiretime") == 0) {
		ptr = strchr(value,':');
		if (ptr == NULL) {
		   fprintf(stderr, "Syntax error in innbbs.conf\n");
		} else {
		   *ptr++ = '\0';
		   His_Maint_Hour = atoi(value);
		   His_Maint_Min  = atoi(ptr);
		   if (His_Maint_Hour < 0)
		      His_Maint_Hour = HIS_MAINT_HOUR;
		   if (His_Maint_Min < 0)
		      His_Maint_Min = HIS_MAINT_MIN;
		}
	 } else if ( strcasecmp(front,"newsfeeds") == 0) {
	   if (strcmp(value,"none")==0) 
	      NONENEWSFEEDS = 1;
	 } else if ( strcasecmp(front,"nodelist") == 0) {
	   if (strcmp(value,"local")==0)
	      LOCALNODELIST = 1;
	 } /*else if ( strcasecmp(front,"newsfeeds") == 0) {
	       printf("newsfeeds %s\n", value); 
	 } else if ( strcasecmp(front,"nodelist") == 0) {
	       printf("nodelist %s\n", value); 
	 } else if ( strcasecmp(front,"bbsname") == 0) {
	       printf("bbsname %s\n", value); 
	 } */
       }
       fclose(conf);
     }
   }

   bbsnameptr = (char*) fileglue("%s/bbsname.bbs",INNDHOME);
   if ((FN = fopen( bbsnameptr ,"r" ))==NULL) {
     fprintf(stderr,"can't open file %s\n", bbsnameptr);
     return 0;
   }
   while ( fscanf(FN,"%s", MYBBSID) != EOF);
   fclose(FN);

   if (NONENEWSFEEDS == 0)
     readnffile(INNDHOME);
   if (LOCALNODELIST == 0)
     readnlfile(INNDHOME);
   return 1;
}


static int 
nfcmp(a,b)
newsfeeds_t *a, *b;
{
   return strcasecmp(a->newsgroups, b->newsgroups);
}

static int 
nlcmp(a,b)
nodelist_t *a, *b;
{
   return strcasecmp(a->host, b->host);
}

/* read in newsfeeds.bbs and nodelist.bbs */
readnlfile(inndhome)
char *inndhome;
{
    FILE *fp;
    char buff[1024];
    struct stat st;
    int i, count; 
    char *ptr, *nodelistptr;

    sprintf(buff,"%s/nodelist.bbs", inndhome);
    fp = fopen(buff,"r");
    if (fp == NULL) {
       fprintf(stderr,"open fail %s",buff);
       return -1;
    }
    if (fstat(fileno(fp),&st) != 0) {
	fprintf(stderr,"stat fail %s", buff);
        return -1;
    }
    if (NODELIST_BUF == NULL) {
	NODELIST_BUF = (char*) mymalloc( st.st_size +1);
    } else {
	NODELIST_BUF = (char*) myrealloc( NODELIST_BUF, st.st_size +1);
    }
    i = 0, count =0;
    while (fgets(buff, sizeof buff, fp) != NULL) {
       if (buff[0] == '#') continue;
       if (buff[0] == '\n') continue;
       strcpy(NODELIST_BUF+i, buff);
       i += strlen(buff);
       count ++;
    }
    fclose(fp);
    if (NODELIST == NULL) {
       NODELIST = (nodelist_t*) mymalloc(sizeof(nodelist_t) * (count+1));
    } else {
       NODELIST = (nodelist_t*) myrealloc(NODELIST, sizeof(nodelist_t) * (count+1));
    }
    NLCOUNT = 0;
    for (ptr = NODELIST_BUF; (nodelistptr = (char*)strchr(ptr,'\n')) != NULL; ptr = nodelistptr +1, NLCOUNT++) {
	char *nptr , *bptr, *pptr;
	*nodelistptr = '\0';
	NODELIST[NLCOUNT].host = NULL;
	NODELIST[NLCOUNT].newsgroups = NULL;
        for (nptr= ptr ;*nptr && isspace(*nptr); ) nptr++;
	if (*nptr == '\0') continue;
        /*NODELIST[NLCOUNT].id = nptr;*/
	for (nptr++; *nptr && !isspace(*nptr); ) nptr++;
	if (*nptr == '\0') continue;
        *nptr = '\0';
        for (nptr++ ;*nptr && isspace(*nptr); ) nptr++;
	if (*nptr == '\0') continue;
        NODELIST[NLCOUNT].host = nptr;
	for (nptr++; *nptr && !isspace(*nptr); ) nptr++;
	if (*nptr == '\0') continue;
        *nptr = '\0';
        for (nptr++;*nptr && isspace(*nptr); ) nptr++;
	if (*nptr == '\0') continue;
        /*NODELIST[NLCOUNT].path = nptr;*/
	for (nptr++; *nptr && !isspace(*nptr); ) nptr++;
	if (*nptr == '\0') continue;
        *nptr = '\0';
    }
    qsort(NODELIST, NLCOUNT, sizeof(nodelist_t), nlcmp);
}

readnffile(inndhome)
char *inndhome;
{
    FILE *fp;
    char buff[1024];
    struct stat st;
    int i, count; 
    char *ptr, *newsfeedsptr;

    sprintf(buff,"%s/newsfeeds.bbs", inndhome);
    fp = fopen(buff,"r");
    if (fp == NULL) {
       fprintf(stderr,"open fail %s",buff);
       return -1;
    }
    if (fstat(fileno(fp),&st) != 0) {
	fprintf(stderr,"stat fail %s", buff);
        return -1;
    }
    if (NEWSFEEDS_BUF == NULL) {
	NEWSFEEDS_BUF = (char*) mymalloc( st.st_size +1);
    } else {
	NEWSFEEDS_BUF = (char*) myrealloc( NEWSFEEDS_BUF, st.st_size +1);
    }
    i = 0, count =0;
    while (fgets(buff, sizeof buff, fp) != NULL) {
       if (buff[0] == '#') continue;
       if (buff[0] == '\n') continue;
       strcpy(NEWSFEEDS_BUF+i, buff);
       i += strlen(buff);
       count ++;
    }
    fclose(fp);
    if (NEWSFEEDS == NULL) {
       NEWSFEEDS = (newsfeeds_t*) mymalloc(sizeof(newsfeeds_t) * (count+1));
    } else {
       NEWSFEEDS = (newsfeeds_t*) myrealloc(NEWSFEEDS, sizeof(newsfeeds_t) * (count+1));
    }
    NFCOUNT = 0; 
    for (ptr = NEWSFEEDS_BUF; (newsfeedsptr = (char*)strchr(ptr,'\n')) != NULL; ptr = newsfeedsptr +1, NFCOUNT++) {
	char *nptr , *bptr, *pptr;
	*newsfeedsptr = '\0';
	NEWSFEEDS[NFCOUNT].newsgroups = NULL;
	NEWSFEEDS[NFCOUNT].board = NULL;
	NEWSFEEDS[NFCOUNT].path = NULL;
        for (nptr= ptr ;*nptr && isspace(*nptr); ) nptr++;
	if (*nptr == '\0') continue;
        NEWSFEEDS[NFCOUNT].newsgroups = nptr;
	for (nptr++; *nptr && !isspace(*nptr); ) nptr++;
	if (*nptr == '\0') continue;
        *nptr = '\0';
        for (nptr++ ;*nptr && isspace(*nptr); ) nptr++;
	if (*nptr == '\0') continue;
        NEWSFEEDS[NFCOUNT].board = nptr;
	for (nptr++; *nptr && !isspace(*nptr); ) nptr++;
	if (*nptr == '\0') continue;
        *nptr = '\0';
        for (nptr++;*nptr && isspace(*nptr); ) nptr++;
	if (*nptr == '\0') continue;
        NEWSFEEDS[NFCOUNT].path = nptr;
	for (nptr++; *nptr && !isspace(*nptr); ) nptr++;
	if (*nptr == '\0') continue;
        *nptr = '\0';
    }
    qsort(NEWSFEEDS, NFCOUNT, sizeof(newsfeeds_t), nfcmp);
}


nodelist_t *search_nodelist(site)
char *site;
{
   nodelist_t nlt, *find;
   if (LOCALNODELIST) return NULL;
   nlt.host = site;
   find = (nodelist_t*)bsearch((char*)&nlt, NODELIST, NLCOUNT, sizeof(nodelist_t), nlcmp);
   return find;
}

newsfeeds_t *search_group(newsgroup)
char *newsgroup;
{
   newsfeeds_t nft, *find;
   if (NONENEWSFEEDS) return NULL;
   nft.newsgroups = newsgroup;
   find = (newsfeeds_t*)bsearch((char*)&nft, NEWSFEEDS, NFCOUNT, sizeof(newsfeeds_t), nfcmp);
   return find;
}

char *ascii_date()
{
   static char datebuf[40];
   time_t now;
   time(&now);
   strftime(datebuf, sizeof(datebuf), "%d %b %Y %X %Z", gmtime(&now));
   return datebuf;
}

char *
restrdup(ptr, string)
char *ptr;
char *string;
{
   int len ;
   if (string == NULL) {
      if (ptr != NULL) *ptr = '\0';
      return ptr;
   }
   len = strlen(string) + 1;
   if (ptr != NULL) {
      ptr = (char*)myrealloc(ptr, len);
   } else
   ptr = (char*)mymalloc(len);
   strcpy(ptr, string);
   return ptr;
}



void *
mymalloc(size)
int size;
{
    char *ptr = (char*)malloc(size);
    if (ptr == NULL) {
       fprintf(stderr, "cant allocate memory\n");
       syslog(LOG_ERR, "cant allocate memory %m");
       exit(1);
    }
    return ptr;
}

void *
myrealloc(optr, size)
void *optr;
int size;
{
    char *ptr = (char*)realloc(optr, size);
    if (ptr == NULL) {
       fprintf(stderr, "cant allocate memory\n");
       syslog(LOG_ERR, "cant allocate memory %m");
       exit(1);
    }
    return ptr;
}

#ifdef BBSLIB
main()
{
   initial_bbs();
   printf("%s\n",ascii_date());
}
#endif

