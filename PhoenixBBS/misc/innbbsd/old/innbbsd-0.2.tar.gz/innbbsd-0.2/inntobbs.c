#include <stdio.h>
#include "daemon.h"
#include "bbslib.h"
#include <time.h>

typedef struct Header {
  char *name;
  int  id;
} header_t;

/*enum HeaderValue {
SUBJECT_H, FROM_H, DATE_H, MID_H, NEWSGROUPS_H,
NNTPPOSTINGHOST_H, NNTPHOST_H, CONTROL_H, PATH_H,
ORGANIZATION_H, LASTHEADER,
};
*/

char *strchr ARG((char*,int));
char *strrchr ARG((char*,int));
char *strstr ARG((char*,char*));

header_t headertable[] = {
"Subject"   ,SUBJECT_H,
"From"      ,FROM_H,
"Date"      ,DATE_H,
"Message-ID",MID_H,
"Newsgroups",NEWSGROUPS_H,
"NNTP-Posting-Host",NNTPPOSTINGHOST_H, 
"NNTP-Host", NNTPHOST_H,
"Control",   CONTROL_H,
"Path",      PATH_H,
"Organization", ORGANIZATION_H,
};

char *HEADER[LASTHEADER];
char *BODY;
char *FROM, *SUBJECT, *SITE, *DATE, *POSTHOST, 
     *NNTPHOST, *PATH, *GROUPS, *MSGID, *CONTROL;


bbspost_write_1(fh, board, filename)
int fh;
char *board;
char *filename;
{
       char *fptr, *ptr;
       FILE *fhfd = fdopen(fh,"w");

       fprintf(fhfd,"�o�H�H: %s, �H��: %s\n",FROM, board);
       fprintf(fhfd,"��  �D: %s\n", SUBJECT);
       fprintf(fhfd,"�o�H��: %s (%s)\n",SITE,DATE);
       fprintf(fhfd,"��H��: %s\n",PATH);
       fprintf(fhfd,"\n");
       for (fptr = BODY, ptr = strchr(fptr,'\r'); ptr != NULL && *ptr != '\0' ; fptr = ptr+1, ptr = strchr(fptr,'\r')) {
	  int ch = *ptr;
	  *ptr = '\0';
	  fputs(fptr, fhfd);
	  *ptr = ch;
       }
       fputs(fptr,fhfd);
       fflush(fhfd);
       fclose(fhfd);
}

bbspost_write_2(fh, board, filename)
int fh;
char *board, *filename;
{
       char *fptr, *ptr;
       FILE *fhfd = fdopen(fh,"w"), *fp;
       char buffer[256];

       fprintf(fhfd,"�o�H�H: %s, �H��: %s\n",FROM, board);
       fprintf(fhfd,"��  �D: %s\n", SUBJECT);
       fprintf(fhfd,"�o�H��: %s (%s)\n",SITE,DATE);
       fprintf(fhfd,"��H��: %s\n",PATH);
       fprintf(fhfd,"\n");
       for (fptr = BODY, ptr = strchr(fptr,'\r'); ptr != NULL && *ptr != '\0' ; fptr = ptr+1, ptr = strchr(fptr,'\r')) {
	  int ch = *ptr;
	  *ptr = '\0';
	  fputs(fptr, fhfd);
	  *ptr = ch;
       }
       fputs(fptr,fhfd);
       fprintf(fhfd,"\n---------------------\n");
       fp = fopen(filename,"r");
       while (fgets( buffer, sizeof buffer, fp)!=NULL) {
          fputs(buffer,fhfd);
       }
       fclose(fp);
       fflush(fhfd);
       fclose(fhfd);

       {
	  fp = fopen(filename,"w");
          fprintf(fp,"�o�H�H: %s, �H��: %s\n",FROM, board);
          fprintf(fp,"��  �D: %s\n", SUBJECT);
          fprintf(fp,"�o�H��: %s (%s)\n",SITE,DATE);
          fprintf(fp,"��H��: %s\n",PATH);
          fprintf(fp,"\n");
          for (fptr = BODY, ptr = strchr(fptr,'\r'); ptr != NULL && *ptr != '\0' ; fptr = ptr+1, ptr = strchr(fptr,'\r')) {
  	     *ptr = '\0';
	     fputs(fptr, fp);
          }
          fputs(fptr,fp);
	  fclose(fp);
       }
}

echomaillog(client) 
ClientType *client;
{
   static FILE* echomailfp = NULL;

   if (echomailfp == NULL) {
      echomailfp = fopen(ECHOMAIL,"a");
   }

   if( echomailfp != NULL ) {
	fprintf(echomailfp,"\n");
	fprintf(echomailfp,"�o�H�H: %s, �H��: %s\n", FROM, GROUPS);
	fprintf(echomailfp,"��  �D: %s\n", SUBJECT);
	fprintf(echomailfp,"�o�H��: %s (%s)\n", SITE, DATE);
	fprintf(echomailfp,"��H��: %s (%s)\n", PATH, client->hostname);
	fflush(echomailfp);
   }
}

receive_article(client)
ClientType *client;
{
   char *user, *userptr; 
   char *ngptr, *nngptr, *pathptr;
   static userid[32];
   static char xdate[32];
   static char xpath[80];
   time_t datevalue;
   newsfeeds_t *nf;
   char *boardhome;
   char hispaths[4096];

   if (FROM == NULL) {
     bbslog( ":Err: article without usrid %s\n",MSGID);
     return;
   }
   user = (char*)strchr(FROM,'@');
   if (user != NULL) {
     *user = '\0';
     userptr = (char*)strchr(FROM,'.');
     if (userptr != NULL) {
       *userptr = '\0';
       strncpy(userid, FROM, sizeof userid);
       *userptr = '.';
     } else {
       strncpy(userid, FROM, sizeof userid);
     }
     strcat(userid,".");
     *user = '@';
   } else {
     strncpy(userid, FROM, sizeof userid);
   }
   datevalue = parsedate(DATE,NULL);
   if (datevalue > 0) {
     char *p ; 
     strncpy(xdate, ctime(&datevalue), sizeof(xdate));
     p = (char*)strchr(xdate,'\n');
     if (p != NULL) *p = '\0';
     DATE = xdate;
   } 
   if (SITE && strcasecmp("Computer Science & Information Engineering NCTU",SITE) ==0) {
      SITE = "��j��u News Server";
   } else if (SITE && strcasecmp("Dep. Computer Sci. & Information Eng., Chiao Tung Univ., Taiwan, R.O.C",SITE) ==0) {
      SITE = "��j��u News Server";
   } else if ( SITE == NULL || *SITE == '\0') {
      SITE = "(Unknown)";
   } 
   if (strlen(MYBBSID) > 70) {
      bbslog(" :Err: your bbsid %s too long\n", MYBBSID);
      return;
   }

   for (pathptr = PATH; pathptr != NULL && (pathptr = strstr(pathptr,".edu.tw")) != NULL; ) {
	   if (pathptr != NULL) {
	      strcpy(pathptr,pathptr+7);
	   }
   }

   sprintf(xpath,"%s!%.*s",MYBBSID, 70 - strlen(MYBBSID), PATH); 
   PATH = xpath;
   echomaillog(client); 
   *hispaths = '\0';
   for ( ngptr = GROUPS, nngptr = (char*) strchr(ngptr,','); ngptr != NULL && *ngptr != '\0'; nngptr = (char*)strchr(ngptr,',')) {
	  
          if (nngptr != NULL) {
	    *nngptr = '\0';
	  }
	  nf = (newsfeeds_t*)search_group(ngptr);
	  /*printf("board %s\n",nf->board); */
	  if (nf != NULL)
	    boardhome = (char*)fileglue("%s/boards/%s",BBSHOME,nf->board);
	  if ( nf == NULL) {
	    if( strstr( ngptr, "tw.bbs" ) != NULL ) {
		    bbslog( "unknown \'%s\' in %s\n", ngptr, GROUPS );
	    }
	  } else if ( nf->path == NULL) {
	  } else if (!isdir( boardhome)) {
	      bbslog( ":Err: unable to write %s\n",boardhome);
	  } else {
	    char *fname;
	    /*if ( !isdir( boardhome )) {
	      bbslog( ":Err: unable to write %s\n",boardhome);
	      testandmkdir(boardhome);
	    }*/
	    fname = (char*)post_article(boardhome,0, userid, nf->board, bbspost_write_1,NULL );  
	    if (fname != NULL) {
	      fname = (char*)fileglue("%s/%s",nf->board,fname);
	      if (strlen(fname) + strlen(hispaths) + 1 < sizeof(hispaths)) { 
	       strcat(hispaths,fname);
	       strcat(hispaths," ");
              }
	    }
	  }

	  if (nngptr != NULL) 
            ngptr = nngptr + 1; 
          else
	    break;
   }
   if (storeDB(HEADER[MID_H], hispaths) < 0) {
   }
}

read_article() 
{
}

int headercmp(a,b)
header_t *a, *b;
{
   return strcasecmp(a->name, b->name);
}

int readlines(client)
ClientType *client;
{
    int fd = client->fd;
    char *buffer = client->buffer;
    buffer_t *in = &client->in;
    char *front = in->data, *ptr, *hptr;
    int i;

    for (i=0; i < LASTHEADER; i++ ) 
      HEADER[i] = NULL;
    for (ptr = (char*)strchr(in->data,'\n'); ptr != NULL && *ptr != '\0' ; front = ptr+1, ptr = (char*)strchr(front,'\n')) {
	*ptr = '\0';
        if (front[0] == '\r' || front[1] == '\n') {
	   BODY = front+2;
	   break;
        }
        hptr = (char*)strchr(front,':');
	if (hptr != NULL && hptr[1] == ' ') {
	   int value;
	   *hptr = '\0';
           value = headervalue(front); 
	   if (value != -1) {
	      char *tp;
	      HEADER[value] = hptr + 2;
	      if ((tp = (char*)strchr(HEADER[value],'\r'))!=NULL)
                 *tp = '\0';
	   }
	   *hptr = ':';
	}
	/**ptr = '\n';*/
    }
    NNTPHOST = HEADER[NNTPHOST_H];
    PATH     = HEADER[PATH_H];
    FROM     = HEADER[FROM_H];
    GROUPS   = HEADER[NEWSGROUPS_H];
    SUBJECT  = HEADER[SUBJECT_H];
    DATE     = HEADER[DATE_H];
    SITE     = HEADER[ORGANIZATION_H];
    MSGID    = HEADER[MID_H];
    CONTROL  = HEADER[CONTROL_H];
    POSTHOST = HEADER[NNTPPOSTINGHOST_H];
}

int headervalue(inputheader)
char *inputheader;
{
   header_t key, *findkey;
   static int hasinit=0;

   if (hasinit == 0) {
      article_init();
      hasinit = 1;
   }

   key.name = inputheader;
   findkey = ( header_t *)bsearch (
		   (char *) &key, (char *) headertable, 
		   sizeof(headertable)/ sizeof(header_t), sizeof (key), 
		   headercmp);
   if (findkey != NULL) return findkey->id;
   return -1;
}

cancel_article_front(msgid)
char* msgid;
{
	char *ptr = (char*)DBfetch(msgid);
	char *filelist, filename[2048];
	if (ptr == NULL) {
		return -1;
	}
#ifdef DEBUG
	printf("**** try to cancel %s *****\n",ptr);
#endif
	filelist = strchr(ptr,'\t');
	if (filelist != NULL) {
	   filelist++;
	}
	for ( ptr =  filelist; ptr && *ptr; ) {
	  char *file;
          for (; *ptr && isspace(*ptr) ; ptr++); 
	  if (*ptr == '\0') break;
	  file = ptr;
          for (ptr++; *ptr && !isspace(*ptr) ; ptr++); 
	  if (*ptr != '\0') {
	     *ptr++ = '\0';
	  } 
	  sprintf(filename,"%s/boards/%s",BBSHOME, file);
	  if (isfile(filename)) {
	      FILE *fp = fopen(filename,"r");
	      char buffer[1024];
	      char *xfrom, *xpath, *boardhome;

	      if (fp == NULL) continue;
	      while (fgets(buffer,sizeof buffer, fp) != NULL) {
		 char *hptr;
		 if (buffer[0]=='\n') break;
		 hptr = strchr(buffer,'\n');
		 if (hptr != NULL) *hptr = '\0';
		 if (strncmp(buffer,"�o�H�H: ",8)==0) {
		    char* n;
		    n = strrchr(buffer,',');
		    if (n!=NULL) *n = '\0';
		    xfrom = buffer+8;
		 } else if (strncmp(buffer,"��H��: ",8)==0) {
		    xpath = buffer+8;
		 }
	      }
	      fclose(fp);
	      if( !strcmp(HEADER[FROM_H],xfrom)) {
		bbslog( "Invalid cancel %s, path: %s!%s\n",FROM,MYBBSID,PATH);
		return -1;
	      }
	      bbslog( "cancel post %s\n",filename );
	      boardhome = (char*)fileglue("%s/boards/deleted", BBSHOME);
	      testandmkdir(boardhome);
	      if (isdir(boardhome)) {
		 char subject[1024];
		 if (POSTHOST) {
		   sprintf(subject,"cancel by: %.1000s", POSTHOST);
                 } else {
		   char *body;
		   body = strchr(BODY,'\r');
		   if (body != NULL) *body = '\0';
		   body = strchr(BODY,'\n');
		   if (body != NULL) *body = '\0';
		   sprintf(subject,"%.1000s", BODY);
		   if (body != NULL) *body = '\n';
		 } 
		 SUBJECT = subject;
	         post_article(boardhome,0, FROM, "deleted", bbspost_write_2,filename);  
	      }
	      bbslog("**** %s should be removed\n", filename);
	      /*unlink(filename);*/
	      {
		 char *fp = strrchr(file,'/');
		 if (fp != NULL) *fp = '\0';
	         cancel_article(BBSHOME, file, fp+1);
		 if (fp != NULL) *fp = '/';
	      }
	  }
	}
	return 0;
}

article_init()
{
   int i;
   static int article_inited = 0;

   if (article_inited) return;
   article_inited = 1;

   qsort(headertable, sizeof(headertable)/ sizeof(header_t), sizeof(header_t),
	 headercmp);
   for (i=0; i < LASTHEADER; i++ ) 
      HEADER[i] = NULL;
}

#ifdef INNTOBBS
main()
{
    int i,j,k,l,m,n,o,p,q;
    article_init(); 
    i = headervalue("Subject");
    j = headervalue("From");
    k = headervalue("Date");
    l = headervalue("NNTP-Posting-Host");
    m = headervalue("Newsgroups");
    n = headervalue("Message-ID");
}
#endif
