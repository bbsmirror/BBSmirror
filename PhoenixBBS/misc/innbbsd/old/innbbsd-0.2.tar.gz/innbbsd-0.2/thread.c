#include "innbbsd.h"
#include "thread.h"


checknovsize(nov,cursize,maxsize)
nov_t **nov;
int cursize;
int *maxsize;
{
	int cnt;
	int ors=*maxsize;

	if (*maxsize > cursize ) return;
	if (*maxsize == 0) 
		*maxsize = 224;
	*maxsize += *maxsize/4;
	if ( *nov == NULL ) {
	   *nov = (nov_t *) malloc(sizeof(nov_t) * *maxsize);
	} else {
	   *nov = (nov_t *) realloc(*nov,sizeof(nov_t) * *maxsize);
	}
	if (*nov==NULL) {
		fprintf(stderr,"No more memory\n");
		return(-1);
	}
	for (cnt=ors;cnt< *maxsize ;cnt++) {
		int i=0,size;
		(*nov)[cnt].numart=0;
		(*nov)[cnt].date=0;
		(*nov)[cnt].from = NULL;
		(*nov)[cnt].filename = NULL;
		(*nov)[cnt].notsize = 0;
		(*nov)[cnt].not = NULL;
	}
}

checknotsize(not,cursize,maxsize)
not_t **not;
int cursize;
int *maxsize;
{ 
	int cnt;
	int ors=*maxsize;

	if (*maxsize > cursize) return 0;
	if (*maxsize == 0) 
		*maxsize = 3;
	*maxsize += *maxsize/2;
	if ( *not == NULL ) {
	   *not = (not_t *) malloc(sizeof(not_t) * *maxsize);
	} else {
	   *not = (not_t *) realloc(*not,sizeof(not_t) * *maxsize);
	}
	if (*not==NULL) {
		fprintf(stderr,"No more memory\n");
		return(-1);
	}
	for (cnt=ors;cnt< *maxsize ;cnt++) {
		(*not)[cnt].filename=NULL;
		(*not)[cnt].from=NULL;
		(*not)[cnt].date = NULL;
		(*not)[cnt].offset = 0;
		(*not)[cnt].line = 0;
	}
}

mystrdup(dest,src)
char *src;
char **dest;
{
	int length = strlen(src);
	if (*dest != NULL) {
		*dest = (char*)realloc(*dest, length+1);
		strncpy(*dest,src,length+1);
	} else {
		*dest = (char*)strdup(src);
	}
}

storenot(hid,splitptr,filename,from,date,offset,line,artindex)
int hid;
char **splitptr;
int from,date,filename,artindex;
int offset,line;
{
	int numart = TNRPD.nov[hid].numart;	
	checknotsize(&TNRPD.nov[hid].not,numart,&TNRPD.nov[hid].notsize);
	mystrdup(&TNRPD.nov[hid].not[numart].from , splitptr[from]); 
	mystrdup(&TNRPD.nov[hid].not[numart].date , splitptr[date]); 
	mystrdup(&TNRPD.nov[hid].not[numart].filename,splitptr[filename]); 
	TNRPD.nov[hid].not[numart].offset=atol(splitptr[offset]);
	TNRPD.nov[hid].not[numart].line=atol(splitptr[line]);
	TNRPD.nov[hid].not[numart].artindex= artindex;
}

int novinit()
{
	int i;
	for (i=0;i<TNRPD.novsize;++i) {
		TNRPD.nov[i].numart = 0;
	}
}

int dothreading (argv,start,end)
argv_t *argv;
int start,end;
{
	FILE *over,*xthf,*thf;
	int filename,subject,from,date,mid,ref,offset,line;
	int artno,count,artindex;

	sprintf(TNRPD.sprintfbuf,"%s/%s/.overview",TNRPD.overviewdir,TNRPD.groupdirname);
	over=fopen(TNRPD.sprintfbuf,"r"); if (over==NULL) return -1;
	sprintf(TNRPD.sprintfbuf,"%s/%s.thread%d",TNRPD.threadcachedir,TNRPD.groupname,getpid());
	thf=fopen(TNRPD.sprintfbuf,"w");  if (thf==NULL) return -1;
	sprintf(TNRPD.sprintfbuf,"%s/%s.xthread%d",TNRPD.xthreadcachedir,TNRPD.groupname,getpid());
	fflush(stdout);
	xthf=fopen(TNRPD.sprintfbuf,"w"); if (xthf==NULL) return -1;
	novinit();

	for (count=0,artindex=0;fgets(TNRPD.sprintfbuf,1024,over)!=NULL;) {
		char **splitptr=(char**)ssplit(TNRPD.sprintfbuf,"\t\n");
		if (TNRPD.mode==NEWS) {
			filename=0,subject=1,from=2,date=3,mid=4;
			ref=5,offset=6,line=7,artno=0;
			while (atol(splitptr[filename]) > TNRPD.allarts[artindex].artno)
				artindex++;
			if (atol(splitptr[filename]) != TNRPD.allarts[artindex].artno)
				continue;
				
		} else if (TNRPD.mode==ARCHIVE){
			artno=0,subject=1,from=2,date=3,mid=4;
			offset=5,line=6,filename=7;
		}
/*		if (splitptr[filename][0]=='\0') splitptr[filename]=splitptr[artno];*/
/*		if (splitptr[line][0]=='\0') splitptr[line]=" ";*/
		if (!strncasecmp(splitptr[subject],"Re:",3)) {
			splitptr[subject]=splitptr[subject]+4;
			if (!strncasecmp(splitptr[subject],"Re:",3)) 
				splitptr[subject]=splitptr[subject]+4;
		}
		while (strchr("\t\n\r ",*splitptr[subject]))
			splitptr[subject]++;
		checknovsize(&TNRPD.nov,count,&TNRPD.novsize);
		TNRPD.nov[count].subject = (char*)hash_str(splitptr[subject],count);
		if (in_hash()) {
			int hid=in_hashid();
			storenot(hid,splitptr,filename,from,date,offset,line,artindex);
			TNRPD.nov[hid].numart++;	
			continue;
		} else {
			mystrdup(&TNRPD.nov[count].from,splitptr[from]);
			mystrdup(&TNRPD.nov[count].filename,splitptr[filename]);
			TNRPD.nov[count].offset= atol(splitptr[offset]);
			TNRPD.nov[count].artindex= artindex;
			storenot(count,splitptr,filename,from,date,offset,line,artindex);
			TNRPD.nov[count].numart = 1;	
			count++;
		}
	}

	{
		int i;
		start--; end--;
		if (start <0) start = 0;
		fprintf(argv->out,"%d thread data list as follows:\n",argv->dc->normalcode);
		for (i=start;i<=end && i<count;i++) {
			nov_t *nov = &TNRPD.nov[i];
			unsigned long xthreadfileoffset;
			int nthread = TNRPD.nov[i].numart;
			int state=1;
			if (nthread > 1) {
				int  j;
				xthreadfileoffset = ftell(xthf);
				fprintf(xthf,"%s\n",nov->subject);
				for (j=0;j<nthread;++j) {
				   fprintf(xthf,"%s\t%s\t%s\t%ld\t%ld\t%ld\t%ld\n",nov->not[j].filename,nov->not[j].from,nov->not[j].date,nov->not[j].offset,nov->not[j].line,TNRPD.allarts[nov->not[j].artindex].artno,nov->not[j].artindex);
				   if (TNRPD.allarts[nov->not[j].artindex].state == 0) 
					state = 0;
				   
				}
				fputs("\n",xthf);

			}
			fprintf(thf,"%d\t%s\t%s\t%s\t%ld\t%ld\t%d\t%d\n",nthread,nov->subject,nov->from,nov->filename,nov->offset,xthreadfileoffset,TNRPD.allarts[nov->artindex].artno,nov->artindex);
			fprintf(argv->out,"%d\t%s\t%s\t%s\t%ld\t%ld\t%d\t%d\n",nthread,nov->subject,nov->from,nov->filename,nov->offset,xthreadfileoffset,TNRPD.allarts[nov->artindex].artno,state);
		}
	        hash_reclaim();
		fclose(thf);
		fclose(xthf);
		fclose(over);
		fputs(".\n",argv->out);
		fflush(argv->out);
		sprintf(TNRPD.sprintfbuf,"%s/%s.thread%d",TNRPD.threadcachedir,TNRPD.groupname,getpid());
		sprintf(TNRPD.sprintfbuf1,"%s/%s.thread",TNRPD.threadcachedir,TNRPD.groupname);
		rename(TNRPD.sprintfbuf,TNRPD.sprintfbuf1);
		sprintf(TNRPD.sprintfbuf,"%s/%s.xthread%d",TNRPD.xthreadcachedir,TNRPD.groupname,getpid());
		sprintf(TNRPD.sprintfbuf1,"%s/%s.xthread",TNRPD.xthreadcachedir,TNRPD.groupname);
		rename(TNRPD.sprintfbuf,TNRPD.sprintfbuf1);
	}
}
