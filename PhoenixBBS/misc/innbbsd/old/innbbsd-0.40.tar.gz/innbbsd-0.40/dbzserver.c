#include <stdio.h>

main(argc, argv)
int argc;
char *argv[];
{
   if (argc < 2) {
      fprintf(stderr, "Usage: %s well-known-path\n", argv[0]);
      exit(1);
   }
   dbzserver(argv[1]);
}

INNBBSDhalt()
{
   
}

dbzserver(path)
char *path;
{
   int dbzbind = p_unix_main(path);
   char buffer[1024];
   int ns;

   if (dbzbind < 0 ) {
      fprintf(stderr, " unit domain socket error \n");
      exit(2);
   }
   for (;;) {
     int cc;
     FILE *in, *out;
     ns=tryaccept(dbzbind);
     printf("accepted %d\n", ns);
     if (ns < 0) continue;
     in = fdopen(ns,"r");
     out= fdopen(ns,"w");
     for (;;) {
       if (fgets( buffer, sizeof buffer, in) == NULL) break;
       printf("got %s",buffer);
       fprintf(out, "got %s",buffer);
     }
     fclose(in);
     fclose(out);
     close(ns);
   }
   close(dbzbind);
   if (dbzbind >= 0)
     unlink(path);
}
