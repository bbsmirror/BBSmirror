#ifndef TNRPD_H
#define TNRPD_H
#include "daemon.h"
#include "thread.h"

#define ADMINUSER "usenet@csie.nctu.edu.tw"
#define STARTUP   "Welcome to TNRPD Version 0.0"

#define ARCHIVEACTIVE "/homeb/CNEWS_Archive.overview/active"
#define ARCHIVEACTIVENEWSGROUPS "/homeb/CNEWS_Archive.overview/activenewsgroups"
/*#define ARCHIVEACTIVENEWSGROUPS "/usr/lib/news/activenewsgroups"
#define ARCHIVEACTIVE "/usr/lib/news/active"
*/
#define ARCHIVESPOOLDIR "/net/home12/archive"
#define ARCHIVEOVERVIEWDIR "/net/home12/archive"
#define ARCHIVETHREADCACHEDIR "/usr/tmp/thread"
#define ARCHIVEXTHREADCACHEDIR "/usr/tmp/xthread"
#define ARCHIVEARTICLECACHEDIR "/tmp/cache"
#define NEWSACTIVENEWSGROUPS "/usr/lib/news/activenewsgroups"
#define NEWSACTIVE "/usr/lib/news/active"
#define NEWSSPOOLDIR "/usr/spool/news"
#define NEWSOVERVIEWDIR "/homeb/overview"
#define NEWSTHREADCACHEDIR "/usr/tmp/newsthread"
#define NEWSXTHREADCACHEDIR "/usr/tmp/newsxthread"
#define NEWSARTICLECACHEDIR "/tmp/cache"

#define GUNZIP "/usr/local/bin/gzip -d -c"

#define Tnrpdflush fflush(argv->out)
#define Tnrpdputs(x)  fputs(x,argv->out);fflush(argv->out)

enum MODE {NEWS,ARCHIVE};


typedef struct GN {
	char *name,*description;
} gn_t;

typedef struct ART {
	unsigned long artno;
	unsigned char state;
} art_t;

typedef struct Tnrpd_t {
  char groupname[1024];
  char groupdirname[1024];
  char *spooldir,*overviewdir,*threadcachedir,*xthreadcachedir,*articlecachedir;
  enum MODE mode;
  enum MODE lastmode;
  char sprintfbuf[4024];
  char sprintfbuf1[4024];
  art_t *allarts;
  int  allartslength;
  int  allartsmaxlength;
  char *active,*activenewsgroups;
  nov_t *nov;
  int novsize;
  gn_t *gn;
  int gnsize;
  char rcentry[1024];
} tnrpd_t;

#define MAXSCHEMASIZE 30
typedef struct Schema_t {
	char *name;
	char *headers[MAXSCHEMASIZE];
} schema_t;

extern tnrpd_t TNRPD;

#endif
