#ifdef OTALK
#include "talk_ctl.h"
#include <sys/time.h>
/* find_daemon() locates the talk daemon(s) on a machine and determines
 * what version(s) of the daemon are running.
 */
find_daemon()
{
    register int n, i, d;
    OCTL_MSG m1;
    CTL_MSG m2;
    char errstr[sizeof(m2)+10];
    struct sockaddr_in daemon;
    struct timeval tv;
    int sel, out;

    /* If we've already used this host, look it up instead of blitting to
     * the daemons again...
     */

    m1 = omsg;
    m2 = msg;
    m1.type = m2.type = LOOK_UP;
    m1.id_num = m2.id_num = htonl(0);
    m1.r_tty[0] = m2.r_tty[0] = '\0';
    strcpy(m1.r_name, "ctalk");
    strcpy(m2.r_name, "ctalk");
    m1.addr.sin_family =  htons(AF_INET);
    m2.addr.sa_family = htons(AF_INET);
    m1.ctl_addr = octl_addr;
    m2.ctl_addr = *(struct sockaddr*)&ctl_addr;
    daemon_addr.sin_addr = his_machine_addr;
    odaemon_addr.sin_addr = his_machine_addr;
    daemon_addr.sin_port = daemon_port;
    odaemon_addr.sin_port = odaemon_port;
    out = 0;
    for(i = 0; i < 5; i++)
    {
	int fds[3];
	int size[3];
	n = sendto(ctl_sockt, &m2, sizeof(m2),
	    0, (struct sockaddr *) &daemon_addr, sizeof(daemon_addr));
	if(n != sizeof(m2))
	    fprintf(stderr,"Warning: cannot write to new talk daemon: %d\r\n",i);
        size[2] = n;
        fds[2] = ctl_sockt;

	n = sendto(octl_sockt, &m1, sizeof(m1),
	    0, (struct sockaddr *) &odaemon_addr, sizeof(odaemon_addr));
	if(n != sizeof(m1))
	    fprintf(stderr,"Warning: cannot write to old talk daemon: %d\r\n",i);
        size[1] = n;
        fds[1] = octl_sockt;

	tv.tv_sec = 4L;
	tv.tv_usec = 0L;
	sel = (1 << fds[1]) | (1 << fds[2]);
	if((n = select(32, &sel, 0, 0, &tv)) < 0)
	{
	    fprintf(stderr,"find_daemon: first select() failed\r\n");
	    continue;
	}
	if(n == 0)
	    continue;

	do
	{
	    for(d = 1; d <= 2; d++)
		if(sel & (1 << fds[d]))
		{
		    out |= (1 << d);
		    if(recv(fds[d], errstr, size[d], 0) < 0)
			fprintf(stderr,"find_daemon: recv() failed\r\n");
		}

	    tv.tv_sec = 0L;
	    tv.tv_usec = 500000L;	/* give the other daemon a chance */
	    sel = (1 << fds[1]) | (1 << fds[2]);
	    if((n = select(32, &sel, 0, 0, &tv)) < 0)
		fprintf(stderr,"find_daemon: second select() failed\r\n");
	} while(n > 0);

	return out;
    }
    sprintf(errstr, "No talk daemon on remote machine" );
    fprintf(errstr);
    return 0;
}

#endif
