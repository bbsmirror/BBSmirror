#!/bin/sh
echo "`sdate` rejectcall $USER to $*" >> bbslog
exec /bin/rejectcall $*
