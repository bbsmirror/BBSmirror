#include "bbs.h"

static struct user_info aman;
struct userec currentuser;
static int     in_bbs, pass_fd;
char ULIST[]=BUTMP;
int utmpent = -1 ;
struct user_info uinfo;
int  usernum;
int real_user_names = 1;
int debug;

char *ModeType();

main()
{
  char *ptr,ptrstr[256];
  char buf[270];
  char *uid;
  ptr = ptrstr;
  fgets(ptr,255,stdin);
  printf("finger:%s.\n",ptr);
  if (strncmp(ptr,"/",1)==0) {
     ptr+=2;
  }
  while (*ptr == ' ') ptr++;
  if (*ptr == '\0' || *ptr == '\n' || *ptr == '\r') {
     /*system("/usr/local/bin/finger");*/
     bbsusers();
     printf("\nIf you want to get bbs on-line user, please use \n");
     printf("finger .bbs@bbs.csie.nctu.edu.tw\n\n");
     printf("To get information of individual bbs user, try\n");
     printf("finger uid.bbs@bbs.csie.nctu.edu.tw\n"); 
     printf("If you can't read these strange chars, please install GNU finger\n\n");
     /*printf("On Line information for non-BBS users:\n"); */
     return;
  }
  if (strncmp(ptr,".bbs",4)==0){
     bbsusers();
     return;
  }
  uid = (char*)strchr(ptr,'.');
  if (uid != NULL) {
     *uid = '\0';
     bbsquery(ptr);  
  } else {
    /*printf("%s",ptr);
    sprintf(buf,"/usr/ucb/finger %s",ptr);
    system(buf);*/
    uid = (char*)strrchr(ptr,'\r');
    if (uid != NULL) *uid = '\0';
    uid = (char*)strrchr(ptr,'\n');
    if (uid != NULL) *uid = '\0';
    bbsquery(ptr);  
  }
}

t_cmpuids(uid,up)
int uid ;
struct user_info *up ;
{
    return (up->active && uid == up->uid) ;
}

bbsquery(uident)
char *uident;
{
    /*char        uident[STRLEN], */
    char        genbuf[STRLEN]; 
    struct user_info uin;
    char inbuf[STRLEN*2], *newline ;
    int new;
    extern char currmaildir[4096] ;
    int         tuid, i;
    FILE        *planfile;
    if(!(tuid = getuser(uident))) {
	printf("�����T���ϥΪ̥N��\n");
        return -1 ;
    }
    uinfo.destuid = tuid ;
    printf( "%s (%s). �@�W�� %d ��, ���U���: %s",
        lookupuser.userid, lookupuser.username, lookupuser.numlogins,
        ctime( &lookupuser.firstlogin ) );

    strcpy(genbuf, ctime(&(lookupuser.lastlogin)));
    if (newline = index(genbuf, '\n')) *newline = '\0';
    printf( "�W�� login %s �q %s\n", genbuf,
        (lookupuser.lasthost[0] == '\0' ? "(����)" : lookupuser.lasthost));

#define QUERY_REALNAMES
#if defined(QUERY_REALNAMES)
    if (HAS_PERM(PERM_BASIC))  
        printf("Real Name: %s \n",lookupuser.realname);
#endif
    sprintf(genbuf, "%s/home/%s/plans", BBSHOME,lookupuser.userid);
    if ((planfile = fopen(genbuf, "r")) == NULL)
        printf("�ثe�L����p��.\n");
    else {
        printf("�p��:\n");
        for (i=1; i<=MAXQUERYLINES; i++) {
            if (fgets(inbuf, sizeof(inbuf), planfile))
                printf("%s", inbuf);
            else break;
        }
        fclose(planfile);
    }
    new = newmail(uident);
    if (new) {
      printf("�� %d �ʷs�H��Ū\n",new);
    } else {
      printf("�S����Ū�s�H\n");
    }
    uinfo.destuid = 0;
    search_ulist( &uin, t_cmpuids, tuid );
    if( uin.active && uin.pid && !uin.invisible && kill( uin.pid, 0 ) != -1 )    {
	puts("�ثe�b����:\n");
        printcuent(NULL);
        printcuent(&uin);
    } else {
	puts("�ثe���b����:\n");
    }
    return 0;
}

int totalusers=0;
bbsusers()
{
   totalusers =0;
   printcuent( NULL ) ;
   if ( apply_ulist( printcuent ) == -1 )
     puts("�S������ϥΪ̤W�u\n") ;
   else {
     puts("========================\n");
     printf("�`�@�� %d ��ϥΪ̦b�u�W\n",totalusers);
   }
   return 0;

}

report(s)
char *s;
{
}

/* Case Independent strncmp */

int
ci_strncmp(s1,s2,n)
register char *s1,*s2 ;
register int n ;
{
    for(;n;s1++,s2++,n--) {
       if(*s1=='\0' && *s2 == '\0')
           break ;
       if((isalpha(*s1)?*s1|0x20:*s1) != (isalpha(*s2)?*s2|0x20:*s2))
       return YEA ;
   }
   return NA ;
}


#ifdef SHOW_IDLE_TIME
char *
idle_str( uent )
struct user_info *uent ;
{
    char tty[ 128 ];
    static char hh_mm_ss[ 32 ];
    struct stat buf;
    time_t now, diff;
    int hh, mm, ss;

    sprintf( tty, "%s/%s",BBSHOME,uent->tty );

    if ( (stat( tty, &buf ) != 0) ||
     (strstr( tty, "tty" ) == NULL)) {
	     strcpy( hh_mm_ss, "����");
	     return hh_mm_ss;
    };

    now = time( 0 );
    diff = now - buf.st_atime;
    hh = diff / 3600;
    mm = (diff / 60) % 60;

    if ( hh > 0 )
       sprintf( hh_mm_ss, "%d:%02d", hh, mm );
    else if ( mm > 0 )
       sprintf( hh_mm_ss, "%d", mm );
    else sprintf ( hh_mm_ss, "   ");

    return hh_mm_ss;
}
#endif

char
pagerchar(me, them, pager)
char *me, *them;
int pager;
{
    if (pager) return ' ';
	else if (can_override(them, -1, me)) return 'O';
    else return '*';
 }

ishidden(user)
char *user;
{
    int tuid;
    struct userec saverec;
    struct user_info uin;

    if (!(tuid = getuser(user))) return 0;
    search_ulist( &uin, t_cmpuids, tuid );
    return( uin.invisible );
}


char *
modestring(mode, towho, complete, chatid)
int mode, towho, complete;
char *chatid;
{
    static char modestr[STRLEN];
    struct userec urec;
    if (chatid) {
       if (complete) sprintf(modestr, "%s as '%s'", ModeType(mode), chatid);
       else return (ModeType(mode));
       return (modestr);
    }
    if (mode != TALK && mode != PAGE && mode != QUERY)
       return (ModeType(mode));
    if (get_record(BPASSFILE, &urec, sizeof(urec), towho) == -1)
	return (ModeType(mode));
    if (mode != QUERY && !HAS_PERM(PERM_SEECLOAK) &&
       ishidden(urec.userid)) return (ModeType(TMENU));
    if (complete)
	sprintf(modestr, "%s '%s'", ModeType(mode), urec.userid);
    else
        return (ModeType(mode));
    return (modestr);
}


print_user_info_title()
{
    char title_str[ 512 ];
    char *field_2 ;

    field_2 = "�ϥΪ̼ʺ�";
    if (real_user_names) field_2 = "�u��m�W  ";
    sprintf( title_str,
	    "%-12.12s %-16.16s %-16.16s %-1.1s %-1.1s %-16.16s %10.10s\n",
	    "�ϥΪ̥N��", field_2, "�Ӧ�", "P",
	    (HAS_PERM(PERM_SEECLOAK) ? "C" : " "), "�ʺA",
#ifdef SHOW_IDLE_TIME
	    "���m ��:��"
#else
	    "          "
#endif
    );
    printf( "%s", title_str );
    return 0;
}

printcuent(uentp)
struct user_info *uentp ;
{
    struct userec utmp ;
    static int i ;
    char user_info_str[ 128 ];
    char *field_2;

    if( uentp == NULL ) {
       print_user_info_title();
       i = 3;
       return 0;
    }
    if( !uentp->active || !uentp->pid )
        return 0;
    if(!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
	return 0;
    if( kill( uentp->pid, 0 ) == -1 )
        return 0;
    get_record(BPASSFILE,&utmp,sizeof(utmp),uentp->uid) ;
    field_2 = utmp.username;
    if (real_user_names) field_2 = utmp.realname;
    sprintf( user_info_str,
	"%-12.12s %-16.16s %-16.16s %c %-1.1s %-16.16s %10.10s\n",
	utmp.userid, field_2,
	(uentp->pager == YEA || HAS_PERM(PERM_SYSOP) )? uentp->from : "*",
	pagerchar(currentuser.userid, utmp.userid, uentp->pager),
	(uentp->invisible ? "#" : " "),
	modestring(uentp->mode, uentp->destuid, 1,
        (uentp->in_chat ? uentp->chatid : NULL)),
#ifdef SHOW_IDLE_TIME
	idle_str( uentp ) );
#else
	"        " );
#endif
     printf( "%s", user_info_str );
     i++ ;
     totalusers ++;
     return 0 ;
}

can_override(userid, uid, whoasks)
char *userid;
int uid;
char *whoasks;
{
    struct userec utmp;
    FILE *fp;
    char buf[STRLEN];
    char *namep;

    if (userid == NULL) {
      if (get_record(BPASSFILE,&utmp,sizeof(utmp),uid) == -1)
	return 0;
      userid = utmp.userid;
    }
    sprintf(buf, "%s/home/%s/overrides", BBSHOME,userid);
    if ((fp = fopen(buf, "r")) == NULL)
	    return 0;
    while (fgets(buf, STRLEN, fp) != NULL) {
      namep = (char *)strtok( buf, " \n\r\t" );
      if (!strcasecmp(namep, whoasks)) {
        fclose(fp);
       return 1;
      }
     }
     fclose(fp);
     return 0;
}

