/*
 * Copyright (c) 1983 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the University of
 *	California, Berkeley and its contributors.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#ifndef lint
static char sccsid[] = "@(#)process.c	5.10 (Berkeley) 2/26/91";
#endif /* not lint */

/*
 * process.c handles the requests, which can be of three types:
 *	ANNOUNCE - announce to a user that a talk is wanted
 *	LEAVE_INVITE - insert the request into the table
 *	LOOK_UP - look up to see if a request is waiting in
 *		  in the table for the local user
 *	DELETE - delete invitation
 */
#include <sys/param.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <protocols/talkd.h>
#include <netdb.h>
#include <syslog.h>
#include <stdio.h>
#include <string.h>
#include <paths.h>

CTL_MSG *find_request();
CTL_MSG *find_match();

#ifdef BBSNTALKD
#include "bbs.h"

#ifndef BUTMP
#define BUTMP "/net/bbs/.UTMP.bbs"
#endif

static struct user_info aman;
struct userec currentuser;
static int     in_bbs, pass_fd;
char ULIST[]=BUTMP;
int utmpent = -1 ;
struct user_info uinfo; 
int  usernum;
int debug=1;

report(s)
char *s;
{
}

t_cmpuids(uid,up)
int uid ;
struct user_info *up ;
{
    return (up->active && uid == up->uid) ;
}


/*
 * Search bbs utmp for the local user
 */
find_bbs_user(name, tty)
	char *name, *tty;
{
	int status;
	int  i, user_num = 0;
	FILE *inf;
	struct stat statb;
	char ftty[20];
	int tuid;
	struct userec saverec;
	struct user_info uin;

	printf("getuser %s\n",name);
	if (!(tuid = getuser(name))) {
	   fprintf(stderr, "talkd: can't read %s to %s.\n", _PATH_UTMP,name);
	   return (FAILED);
        }
	printf("tuid find %d\n",tuid);
	search_ulist( &uin, t_cmpuids, tuid );
        if(!uin.active || (kill(uin.pid,0) == -1)) 
	  return (NOT_HERE);
    /*  check if pager on/off       --gtv */
    if (!HAS_PERM(PERM_SYSOP)) {
	if (uin.pager == NA ) {
/*	&& !can_override(NULL, tuid, currentuser.userid)) { */
	    return PERMISSION_DENIED;
	}
    }
    if(uin.mode == ULDL || uin.mode == IRCCHAT || 
	uin.mode == BBSNET || uin.mode == FOURM) {
	return (PERMISSION_DENIED);
    }
    return SUCCESS;
}

/* Case Independent strncmp */

int
ci_strncmp(s1,s2,n)
register char *s1,*s2 ;
register int n ;
{
    for(;n;s1++,s2++,n--) {
	   if(*s1=='\0' && *s2 == '\0')
	      break ;
	   if((isalpha(*s1)?*s1|0x20:*s1) != (isalpha(*s2)?*s2|0x20:*s2))
		return YEA ;
   }
   	    return NA ;
}

/* rrr -- stuff for providing pager override lists follows */

can_override(userid, uid, whoasks)
char *userid;
int uid;
char *whoasks;
{
    struct userec utmp;
    FILE *fp;
    char buf[STRLEN];
    char *namep;

    if (userid == NULL) {
        if (get_record(BPASSFILE,&utmp,sizeof(utmp),uid) == -1)
    	    return 0;
	userid = utmp.userid;
    }
    sprintf(buf, "home/%s/overrides", userid);
    if ((fp = fopen(buf, "r")) == NULL)
	return 0;
    while (fgets(buf, STRLEN, fp) != NULL) {
	namep = (char *)strtok( buf, " \n\r\t" );
        if (!strcasecmp(namep, whoasks)) {
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}

#endif

#include <utmp.h>

/*
 * Search utmp for the local user
 */
find_user(name, tty)
	char *name, *tty;
{
	struct utmp ubuf;
	int status;
	FILE *fd;
	struct stat statb;
	char ftty[20];

	if ((fd = fopen(_PATH_UTMP, "r")) == NULL) {
		fprintf(stderr, "talkd: can't read %s.\n", _PATH_UTMP);
		return (FAILED);
	}
#define SCMPN(a, b)	strncmp(a, b, sizeof (a))
	status = NOT_HERE;
	(void) strcpy(ftty, _PATH_DEV);
	while (fread((char *) &ubuf, sizeof ubuf, 1, fd) == 1)
		if (SCMPN(ubuf.ut_name, name) == 0) {
			if (*tty == '\0') {
				status = PERMISSION_DENIED;
				/* no particular tty was requested */
				(void) strcpy(ftty+5, ubuf.ut_line);
				if (stat(ftty,&statb) == 0) {
					if (!(statb.st_mode & 020))
						continue;
					(void) strcpy(tty, ubuf.ut_line);
					status = SUCCESS;
					break;
				}
			}
			if (strcmp(ubuf.ut_line, tty) == 0) {
				status = SUCCESS;
				break;
			}
		}
	fclose(fd);
	return (status);
}

main()
{
  int result;
  char name[1024];
  char tty[1024];
  openlog("talkd", LOG_PID, LOG_DAEMON);
  printf("usrename: ");
  gets(name);
  if ( *name ) {
    result = find_bbs_user(name, tty);
    printf("%d\n",result);
  }
}
