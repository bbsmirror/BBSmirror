/*
 * Copyright (c) 1983 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the University of
 *	California, Berkeley and its contributors.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#ifndef lint
static char sccsid[] = "@(#)process.c	5.10 (Berkeley) 2/26/91";
#endif /* not lint */

/*
 * process.c handles the requests, which can be of three types:
 *	ANNOUNCE - announce to a user that a talk is wanted
 *	LEAVE_INVITE - insert the request into the table
 *	LOOK_UP - look up to see if a request is waiting in
 *		  in the table for the local user
 *	DELETE - delete invitation
 */
#include <sys/param.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <protocols/talkd.h>
#include <netdb.h>
#include <syslog.h>
#include <stdio.h>
#include <string.h>
#include <paths.h>

CTL_MSG *find_request();
CTL_MSG *find_match();

process_request(mp, rp)
	register CTL_MSG *mp;
	register BBS_CTL_RESPONSE *rp;
{
	register CTL_MSG *ptr;
	extern int debug;

#ifndef OTALK
	rp->vers = TALK_VERSION;
#endif
	rp->type = mp->type;
	rp->id_num = htonl(0);

#ifndef OTALK
	if (mp->vers != TALK_VERSION) {
		syslog(LOG_WARNING, "Bad protocol version %d", mp->vers);
		rp->answer = BADVERSION;
		return;
	}
#endif
	mp->id_num = ntohl(mp->id_num);
	mp->addr.sa_family = ntohs(mp->addr.sa_family);
	if (mp->addr.sa_family != AF_INET) {
		syslog(LOG_WARNING, "Bad address, family %d",
		    mp->addr.sa_family);
		rp->answer = BADADDR;
		return;
	}
	mp->ctl_addr.sa_family = ntohs(mp->ctl_addr.sa_family);
	if (mp->ctl_addr.sa_family != AF_INET) {
		syslog(LOG_WARNING, "Bad control address, family %d",
		    mp->ctl_addr.sa_family);
		rp->answer = BADCTLADDR;
		return;
	}
	mp->pid = ntohl(mp->pid);
	if (debug)
		print_request("process_request", mp);
	switch (mp->type) {

	case ANNOUNCE:
		do_announce(mp, rp);
		break;

	case LEAVE_INVITE:
		ptr = find_request(mp);
		if (ptr != (CTL_MSG *)0) {
			rp->id_num = htonl(ptr->id_num);
			rp->answer = SUCCESS;
		} else
			insert_table(mp, rp);
		break;

	case LOOK_UP:
		ptr = find_match(mp);
		if (ptr != (CTL_MSG *)0) {
			rp->id_num = htonl(ptr->id_num);
			rp->addr = ptr->addr;
			rp->addr.sa_family = htons(ptr->addr.sa_family);
			rp->answer = SUCCESS;
		} else
			rp->answer = NOT_HERE;
		break;

	case BBS_LOOK_UP:
		ptr = (CTL_MSG *)find_rname_match(mp);
		if (ptr != (CTL_MSG *)0) {
			rp->id_num = htonl(ptr->id_num);
			rp->addr = ptr->addr;
			rp->addr.sa_family = htons(ptr->addr.sa_family);
			rp->answer = SUCCESS;
			strcpy(rp->r_name, ptr->l_name,NAME_SIZE);
		} else
			rp->answer = NOT_HERE;
		writeatmp(mp,rp->r_name);
		break;

	case DELETE:
		rp->answer = delete_invite(mp->id_num);
		break;

	default:
		rp->answer = UNKNOWN_REQUEST;
		break;
	}
	if (debug)
		print_response("process_request", rp);
}

do_announce(mp, rp)
	register CTL_MSG *mp;
	CTL_RESPONSE *rp;
{
	struct hostent *hp;
	CTL_MSG *ptr;
	int result;
#ifdef BBSNTALKD
	int bbsannounce=0;
	int bbspid;
#endif

	/* see if the user is logged */
	result = find_user(mp->r_name, mp->r_tty);
	if (result != SUCCESS) {
#ifdef BBSNTALKD
	        result = find_bbs_user(mp->r_name, mp->r_tty, &bbspid);
		bbsannounce = 1;
		if (result != SUCCESS) {
#endif
			rp->answer = result;
			return;
#ifdef BBSNTALKD
		}
#endif
	}
#define	satosin(sa)	((struct sockaddr_in *)(sa))
	hp = gethostbyaddr((char *)&satosin(&mp->ctl_addr)->sin_addr,
		sizeof (struct in_addr), AF_INET);
	if (hp == (struct hostent *)0) {
		rp->answer = MACHINE_UNKNOWN;
		return;
	}
	ptr = find_request(mp);
	if (ptr == (CTL_MSG *) 0) {
		insert_table(mp, rp);
#ifdef BBSNTALKD
		if (bbsannounce) 
		     rp->answer = bbs_announce(mp, hp->h_name, bbspid);
		  else
#endif
		     rp->answer = announce(mp, hp->h_name);
		return;
	}
	if (mp->id_num > ptr->id_num) {
		/*
		 * This is an explicit re-announce, so update the id_num
		 * field to avoid duplicates and re-announce the talk.
		 */
		ptr->id_num = new_id();
		rp->id_num = htonl(ptr->id_num);
#ifdef BBSNTALKD
		if (bbsannounce) 
		     rp->answer = bbs_announce(mp, hp->h_name,bbspid);
		  else
#endif
		     rp->answer = announce(mp, hp->h_name);
	} else {
		/* a duplicated request, so ignore it */
		rp->id_num = htonl(ptr->id_num);
		rp->answer = SUCCESS;
	}
}

#ifdef BBSNTALKD
#include "bbs.h"

#ifndef BUTMP
#define BUTMP "/net/bbs/.UTMP.bbs"
#endif

static struct user_info aman;
struct userec currentuser;
static int     in_bbs, pass_fd;
char ULIST[]=BUTMP;
int utmpent = -1 ;
struct user_info uinfo; 
int  usernum;

report(s)
char *s;
{
}

t_cmpuids(uid,up)
int uid ;
struct user_info *up ;
{
    return (up->active && uid == up->uid) ;
}

bbs_announce(mp, host, pid)
	register CTL_MSG *mp;
	char *host;
	int pid;
{
        if (debug) 
          syslog(LOG_DEBUG,"announce to pid %d",pid);
        if (pid == 0)
	   return FAILED;
        setuid(BBSUID);
        if (kill(pid, SIGUSR2) == 0) {
           setuid(0);
	   return SUCCESS;
	}
        setuid(0);
	return NOT_HERE;
}

/*
 * Search bbs utmp for the local user
 */
find_bbs_user(name, tty, pid)
	char *name, *tty;
	int *pid;
{
	int status;
	int  i, user_num = 0;
	FILE *inf;
	struct stat statb;
	char ftty[20];
	int tuid;
	struct userec saverec;
	struct user_info uin;

        *pid = 0;
        if (debug) 
          syslog(LOG_DEBUG,"find bbs user, name: %s tty: %s",name,tty);
	if (!(tuid = getuser(name))) {
	   fprintf(stderr, "talkd: can't get user  %s.\n", name);
	   return (FAILED);
        }
        if (debug) 
          syslog(LOG_DEBUG,"find bbs user, tuid: %d",tuid);
	search_ulist( &uin, t_cmpuids, tuid );
        if(!uin.active || (kill(uin.pid,0) == -1)) 
	  return (NOT_HERE);
    /*  check if pager on/off       --gtv */
    if (!HAS_PERM(PERM_SYSOP)) {
	if (uin.pager == NA ) {
/*	&& !can_override(NULL, tuid, currentuser.userid)) { */
	    return PERMISSION_DENIED;
	}
    }
    if(uin.mode == ULDL || uin.mode == IRCCHAT || 
	uin.mode == BBSNET || uin.mode == FOURM) {
	return (PERMISSION_DENIED);
    }
    *pid = uin.pid;
    return SUCCESS;
}

/* Case Independent strncmp */

int
ci_strncmp(s1,s2,n)
register char *s1,*s2 ;
register int n ;
{
    for(;n;s1++,s2++,n--) {
	   if(*s1=='\0' && *s2 == '\0')
	      break ;
	   if((isalpha(*s1)?*s1|0x20:*s1) != (isalpha(*s2)?*s2|0x20:*s2))
		return YEA ;
   }
   	    return NA ;
}

/* rrr -- stuff for providing pager override lists follows */

can_override(userid, uid, whoasks)
char *userid;
int uid;
char *whoasks;
{
    struct userec utmp;
    FILE *fp;
    char buf[STRLEN];
    char *namep;

    if (userid == NULL) {
        if (get_record(BPASSFILE,&utmp,sizeof(utmp),uid) == -1)
    	    return 0;
	userid = utmp.userid;
    }
    sprintf(buf, "home/%s/overrides", userid);
    if ((fp = fopen(buf, "r")) == NULL)
	return 0;
    while (fgets(buf, STRLEN, fp) != NULL) {
	namep = (char *)strtok( buf, " \n\r\t" );
        if (!strcasecmp(namep, whoasks)) {
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}

#endif

#include <utmp.h>

/*
 * Search utmp for the local user
 */
find_user(name, tty)
	char *name, *tty;
{
	struct utmp ubuf;
	int status;
	FILE *fd;
	struct stat statb;
	char ftty[20];

	if ((fd = fopen(_PATH_UTMP, "r")) == NULL) {
		fprintf(stderr, "talkd: can't read %s.\n", _PATH_UTMP);
		return (FAILED);
	}
#define SCMPN(a, b)	strncmp(a, b, sizeof (a))
	status = NOT_HERE;
	(void) strcpy(ftty, _PATH_DEV);
	while (fread((char *) &ubuf, sizeof ubuf, 1, fd) == 1)
		if (SCMPN(ubuf.ut_name, name) == 0) {
			if (*tty == '\0') {
				status = PERMISSION_DENIED;
				/* no particular tty was requested */
				(void) strcpy(ftty+5, ubuf.ut_line);
				if (stat(ftty,&statb) == 0) {
					if (!(statb.st_mode & 020))
						continue;
					(void) strcpy(tty, ubuf.ut_line);
					status = SUCCESS;
					break;
				}
			}
			if (strcmp(ubuf.ut_line, tty) == 0) {
				status = SUCCESS;
				break;
			}
		}
	fclose(fd);
	return (status);
}
