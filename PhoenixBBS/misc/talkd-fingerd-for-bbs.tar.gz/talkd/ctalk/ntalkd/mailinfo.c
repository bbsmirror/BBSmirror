#include "bbs.h"

newmail(uid)
char *uid;
{
   char maildir[STRLEN];
   int fd, new;
   struct stat st;
   struct fileheader dir;
   time_t lastread;
   sprintf(maildir,"%s/mail/%s/.DIR",BBSHOME,uid);
   fd = open(maildir,O_RDONLY);  
   if (fd < 0) return 0;
   new = 0;
   while (read(fd,(char*)&dir,sizeof(dir)) >0) {
         if (! dir.accessed[0] ) new++;
   }
   close(fd);
   /*printf("new %d uid %s fd %d size %d\n",new,uid,fd,sizeof(dir));*/
   return new;
}

