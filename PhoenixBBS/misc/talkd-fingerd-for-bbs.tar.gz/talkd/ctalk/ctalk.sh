#!/bin/sh
PATH=/bin:
stty pass8

LC_CTYPE=iso_8859_1
HOME=/home/$USER
MAILER=/bin/bbs_sendmail
NAME=$USERNAME

export EDITOR
export NNTPSERVER
export LC_CTYPE
export HOME
# NAME is the nickname for tin
export NAME
# USERNAME is env variable set by bbs -> nickname
export USERNAME
# REPLYTO is now added by bbs program -> email address
# No reply to now... (use userid.bbs@domainname instead )
unset REPLYTO
# export REPLYTO
# MAILER is used by tin to mail article to user
export MAILER 
# USER

#exec /bin/ytalk $*
echo "`sdate` ctalk $USER to $*" >> bbslog
exec /bin/ctalk $*
