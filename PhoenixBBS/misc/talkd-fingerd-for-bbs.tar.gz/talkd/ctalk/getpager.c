/*
 * Copyright (c) 1983 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms are permitted
 * provided that: (1) source distributions retain this entire copyright
 * notice and comment, and (2) distributions including binaries display
 * the following acknowledgement:  ``This product includes software
 * developed by the University of California, Berkeley and its contributors''
 * in the documentation or other materials provided with the distribution
 * and in all advertising materials mentioning features or use of this
 * software. Neither the name of the University nor the names of its
 * contributors may be used to endorse or promote products derived
 * from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */

#ifndef lint
char copyright[] =
"@(#) Copyright (c) 1983 Regents of the University of California.\n\
 All rights reserved.\n";
#endif /* not lint */

#ifndef lint
static char sccsid[] = "@(#)talk.c	5.5 (Berkeley) 6/1/90";
#endif /* not lint */

#include "talk.h"
#include "protocols/talkd.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

/*
 * talk:	A visual form of write. Using sockets, a two way 
 *		connection is set up between the two people talking. 
 *		With the aid of curses, the screen is split into two 
 *		windows, and each users text is added to the window,
 *		one character at a time...
 *
 *		Written by Kipp Hickman
 *		
 *		Modified to run under 4.1a by Clem Cole and Peter Moore
 *		Modified to run between hosts by Peter Moore, 8/19/82
 *		Modified to run under 4.1c by Peter Moore 3/17/83
 */

#define DOMAINNAME "csie.nctu.edu.tw"

char     *current_state;
BBS_CTL_RESPONSE *getpager();
#ifdef OTALK
OBBS_CTL_RESPONSE *ogetpager();
#endif

char *getpaginghostname(sock)
struct sockaddr_in *sock;
{
   struct hostent *hp;
   hp = (struct hostent *)gethostbyaddr((char *)&sock->sin_addr,
	   sizeof (struct in_addr), AF_INET);
   if (hp == (struct hostent *)0) {
     return (char*)inet_ntoa(sock->sin_addr);
   } else {
     return hp->h_name;
   }
}

main(argc, argv)
	int argc;
	char *argv[];
{
	BBS_CTL_RESPONSE *pager=NULL;
	struct sockaddr_in* addr=NULL;
	char *r_name=NULL;
#ifdef OTALK
	OBBS_CTL_RESPONSE *opager=NULL;
#endif
	get_names(argc, argv);
	open_ctl();
	pager = getpager();
	if (pager != NULL) {
		addr = (struct sockaddr_in*)&pager->addr;
		r_name = pager->r_name;
	}
#ifdef OTALK
	if (pager ==NULL ) { 
	  opager = ogetpager();
	}  
	if (opager != NULL) {
		addr = (struct sockaddr_in*)&opager->addr;
		r_name = opager->r_name;
	}
#endif
	if ( addr != NULL) {
	  char *hptr = getpaginghostname(addr);
	  if (strchr(hptr,'.') == NULL)
	    printf("%s@%s.%s\n",r_name,hptr,DOMAINNAME);
	  else 
	    printf("%s@%s\n",r_name,hptr);
	}
}

p_error(s)
char *s;
{
  printf("%s",s);
}

