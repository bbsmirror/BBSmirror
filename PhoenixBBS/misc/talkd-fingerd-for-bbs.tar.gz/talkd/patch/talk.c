/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#ifdef lint
#include <sys/uio.h>
#endif
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <errno.h>

#define M_INT 8 	/* monitor mode update interval */
#define P_INT 20        /* interval to check for page req. in talk/chat */

extern int bind(/*int,struct sockaddr *, int*/) ;
extern char *ctime();

#ifdef HAVE_TIN	
extern int post_in_tin();
#endif

int	real_user_names = 0;
char	*friends_list = NULL;
int	friends_number = 0;

#include "modetype.c"

extern int t_columns;
char	*talk_uent_buf;

/* begin - jjyang */
char save_page_requestor[STRLEN];
/* end - jjyang */

int t_cmpuids();

ishidden(user)
char *user;
{
    int tuid;
    struct userec saverec;
    struct user_info uin;

    if (!(tuid = getuser(user))) return 0;
    search_ulist( &uin, t_cmpuids, tuid );
    return( uin.invisible );
}

char *
modestring(mode, towho, complete, chatid)
int mode, towho, complete;
char *chatid;
{
    static char modestr[STRLEN];
    struct userec urec;
    if (chatid) {
	if (complete) sprintf(modestr, "%s as '%s'", ModeType(mode), chatid);
	else return (ModeType(mode));
	return (modestr);
    }			
    if (mode != TALK && mode != PAGE && mode != QUERY)
	return (ModeType(mode));
    if (get_record(PASSFILE, &urec, sizeof(urec), towho) == -1)
	return (ModeType(mode));

    if (mode != QUERY && !HAS_PERM(PERM_SEECLOAK) && 
	ishidden(urec.userid)) return (ModeType(TMENU));	
    if (complete)
	sprintf(modestr, "%s '%s'", ModeType(mode), urec.userid);
    else
	return (ModeType(mode));
    return (modestr);
}

char
pagerchar(me, them, pager)
char *me, *them;
int pager;
{
    if (pager) return ' ';
    else if (can_override(them, -1, me)) return 'O';
    else return '*';
}


#ifdef SHOW_IDLE_TIME
char *
idle_str( uent )
struct user_info *uent ;
{
    char tty[ 128 ];
    static char hh_mm_ss[ 32 ];
    struct stat buf;
    time_t now, diff;
    int hh, mm, ss;

    strcpy( tty, uent->tty );

    if ( (stat( tty, &buf ) != 0) || 
         (strstr( tty, "tty" ) == NULL)) {
	strcpy( hh_mm_ss, "����");
	return hh_mm_ss;
    };

    now = time( 0 );

    diff = now - buf.st_atime;

#ifdef DOTIMEOUT
    /* the 60 * 60 * 24 * 5 is to prevent fault /dev mount from
       kicking out all users */

    if ((diff > IDLE_TIMEOUT) && 
        (diff < 60 * 60 * 24 * 5 )) kill( uent->pid, SIGHUP );
#endif

    hh = diff / 3600;
    mm = (diff / 60) % 60;
    
    if ( hh > 0 ) 
        sprintf( hh_mm_ss, "%d:%02d", hh, mm );
    else if ( mm > 0 ) 
        sprintf( hh_mm_ss, "%d", mm );
    else sprintf ( hh_mm_ss, "   ");

    return hh_mm_ss;
}
#endif


print_user_info_title()
{
    char title_str[ 512 ];
    char *field_2 ;

    field_2 = "�ϥΪ̼ʺ�";
    if (real_user_names) field_2 = "�u��m�W  ";
    sprintf( title_str, 
	"%-12.12s %-16.16s %-16.16s %-1.1s %-1.1s %-16.16s %10.10s\n",
	"�ϥΪ̥N��", field_2, "�Ӧ�", "P", 
	(HAS_PERM(PERM_SEECLOAK) ? "C" : " "), "�ʺA", 
#ifdef SHOW_IDLE_TIME
	"���m ��:��" 
#else
	"          " 
#endif
    );
    prints( "%s", title_str );
    return 0;
}

printcuent(uentp)
struct user_info *uentp ;
{
    struct userec utmp ;
    static int i ;
    char user_info_str[ 128 ];
    char *field_2;

    if( uentp == NULL ) {
	move(3,0);
	print_user_info_title();
	i = 3;
	return 0;
    }
    if( !uentp->active || !uentp->pid )
	return 0;
    if(!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
	return 0;
    if( kill( uentp->pid, 0 ) == -1 )
	return 0;
    get_record(PASSFILE,&utmp,sizeof(utmp),uentp->uid) ;

    if( friends_list != NULL ) {
	sprintf( user_info_str, " %s ", utmp.userid );
	if( strstr( friends_list, user_info_str ) == NULL )
	    return 0;
	friends_number++;
    }

    if( i == t_lines - 2 ) {
	int ch ;

	standout() ;
	prints("-- �~�� (�� Q ����) --") ;
	standend() ;
	clrtoeol();
	while((ch = igetch()) != EOF) {
	    if(strchr ("\n\r qQ", ch)) break ;
	    bell() ;
	}
	if (strchr("Qq", ch)) return QUIT;
	move(3,0) ;
	print_user_info_title();
	i = 3 ;
	clrtobot() ;
    }

    field_2 = utmp.username;
    if (real_user_names) field_2 = utmp.realname;

    sprintf( user_info_str, 
"%-12.12s %-16.16s %-16.16s %c %-1.1s %-16.16s %10.10s\n",
	utmp.userid, field_2,
	(uentp->pager == YEA || HAS_PERM(PERM_SYSOP) )? uentp->from : "*", 
	pagerchar(currentuser.userid, utmp.userid, uentp->pager),
	(uentp->invisible ? "#" : " "), 
	modestring(uentp->mode, uentp->destuid, 1,
		(uentp->in_chat ? uentp->chatid : NULL)),
#ifdef SHOW_IDLE_TIME
	idle_str( uentp ) );
#else
	"        " );
#endif
    prints( "%s", user_info_str );
    i++ ;
    return 0 ;
}

listcuent(uentp)
struct user_info *uentp ;
{
    struct userec utmp ;

    if(uentp == NULL) {
	CreateNameList() ;
	return 0;
    }
    if(uentp->uid == usernum)
	return 0;
    if(!uentp->active || !uentp->pid)
	return 0;
    if(uentp->mode == ULDL)
	return 0;
    if(!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
	return 0;
    if(kill(uentp->pid,0) == -1)
	return 0;
    get_record(PASSFILE,&utmp,sizeof(utmp),uentp->uid) ;
    AddNameList(utmp.userid) ;
    return 0 ;
}

creat_list()
{
    listcuent(NULL) ;
    apply_ulist( listcuent );
}

t_users()
{
    modify_user_mode( LUSERS );
    printcuent( NULL ) ;
    if ( apply_ulist( printcuent ) == -1 ) 
	prints("�S������ϥΪ̤W�u\n") ;
    clrtobot() ;
    pressreturn();
    return 0;
}

t_rusers()
{
    real_user_names = 1;
    t_users();
    real_user_names = 0;
}

/*     Pager Toggle   --gtv     */
t_pager()
{
    uinfo.pager = ( ( uinfo.pager == YEA ) ? NA : YEA );
    if ( !uinfo.in_chat ) {
	move( 2, 0 );
	if ( uinfo.pager == YEA )
	    prints( "Pager turned on.\n" );
	else	
	    prints( "Pager turned off.\n" );
	clrtobot();
    }
    update_utmp();
}

t_query()
{
    char	uident[STRLEN], inbuf[STRLEN*2], *newline ;
    extern char currmaildir[4096] ;
    int		tuid, i;
    FILE	*planfile;
	
    modify_user_mode( QUERY );
    move(2,0);
    prints("<��J�ϥΪ̥N��, ���ť���i�C�X�ŦX�r��>\n");
    move(1,0);
    clrtoeol();
    prints("�d�߽�: ");
	
    usercomplete(NULL,uident);
    if(uident[0] == '\0') {
	clear() ;
	return 0 ;
    }
    if(!(tuid = getuser(uident))) {
	move(2,0) ;
	prints("�����T���ϥΪ̥N��\n") ;
	pressreturn() ;
	move(2,0) ;
	clrtoeol() ;
	return -1 ;
    }
    uinfo.destuid = tuid ;
    update_utmp();

    move(3,0);
    clrtobot();
    sprintf(genbuf, "�d�� %s", lookupuser.userid);
    report(genbuf);
    prints( "%s (%s). �@�W�� %d ��, ���U���: %s",
	lookupuser.userid, lookupuser.username, lookupuser.numlogins,
	ctime( &lookupuser.firstlogin ) );

    strcpy(genbuf, ctime(&(lookupuser.lastlogin)));
    if (newline = index(genbuf, '\n')) *newline = '\0';
    prints( "�W�� login %s �q %s\n", genbuf, 
	(lookupuser.lasthost[0] == '\0' ? "(����)" : lookupuser.lasthost));

#if defined(QUERY_REALNAMES)
    if (HAS_PERM(PERM_BASIC))	
	prints("Real Name: %s \n",lookupuser.realname);
#endif
    sprintf(genbuf, "home/%s/plans", lookupuser.userid);
    if ((planfile = fopen(genbuf, "r")) == NULL)
	prints("�ثe�L����p��.\n");
    else {
	prints("�p��:\n");
	for (i=1; i<=MAXQUERYLINES; i++) {
	    if (fgets(inbuf, sizeof(inbuf), planfile))
		prints("%s", inbuf);
	    else break;
	}
	fclose(planfile);
    }
    pressreturn();
    uinfo.destuid = 0;
    return 0;
}		

/*  begin part added from pbbs 1.8 --gtv */
count_active(uentp)
struct user_info *uentp ;
{
    struct userec utmp ;
    static int count ;
    if(uentp == NULL) {
	int c = count ;
	count = 0 ;
	return c ;
    }
    if(!uentp->active || !uentp->pid)
	return 0 ;
    if(kill(uentp->pid,0) == -1)
	return 0 ;
    count++ ;
    return 1 ;
}

int
num_active_users()
{
    count_active(NULL) ;
    apply_ulist( count_active ) ;
    return count_active(NULL) ;
}          /*  end part added from pbbs 1.8 --gtv */

#include <sys/time.h>
t_cmpuids(uid,up)
int uid ;
struct user_info *up ;
{
    return (up->active && uid == up->uid) ;
}

t_talk()
{
    char uident[STRLEN] ;
    int tuid ;
    struct user_info uin ;

    move(2,0) ;
    prints("<��J�ϥΪ̥N��>\n") ;
    move(1,0) ;
    clrtoeol() ;
    prints("��ֲ��: ") ;
    creat_list() ;
    namecomplete(NULL,uident) ;
    if(uident[0] == '\0') {
	clear() ;
	return 0 ;
    }
    if(!(tuid = getuser(uident)) || tuid == usernum) {
	move(2,0) ;
	prints("Bad User ID\n") ;
	pressreturn() ;
	move(2,0) ;
	clrtoeol() ;
	return -1 ;
    }
    search_ulist( &uin, t_cmpuids, tuid );
    /*  check if pager on/off       --gtv */
    if (!HAS_PERM(PERM_SYSOP)) {
	if (uin.pager == NA && !can_override(NULL, tuid, currentuser.userid)) {
	    move(2,0) ;
	    prints("User's pager is turned off.\n") ;
	    pressreturn() ;
	    move(2,0) ;
	    clrtoeol() ;
	    return -1 ;
	}
    }
    if(uin.mode == ULDL || uin.mode == IRCCHAT || 
	uin.mode == BBSNET || uin.mode == FOURM) {
	move(2,0) ;
	prints("User is in a non-pageable mode.\n") ;
	pressreturn() ;
	move(2,0) ;
	clrtoeol() ;
	return -1 ;
    }
    if(!uin.active || (kill(uin.pid,0) == -1)) {
	move(2,0) ;
	prints("User not logged in\n") ;
	pressreturn() ;
	move(2,0) ;
	clrtoeol() ;
	return -1 ;
    } else {
	int sock, msgsock, length ;
	struct sockaddr_in server ;
	char c ;
	char buf[512] ;
	FILE *planfile;
	int i;

	move( 3, 0 );
	clrtobot();
	sprintf( genbuf, "home/%s/plans", uident );
	if ( ( planfile = fopen( genbuf, "r" ) ) == NULL ) {
	     prints( "%s �S������p��.\n", uident );
	} else {
	     prints( "%s ���p��:\n\n", uident );
	     for ( length = 0; length < MAXQUERYLINES; length++ ) {
                 if( fgets( genbuf, sizeof(genbuf), planfile ) )
                     prints( "%s", genbuf );
                 else 
                     break;
             }
	     close( planfile );
	}
	getdata( 2, 0, "�T�w�n�M�L/�o�ͤѶ�?(Yes, or No) [N]: ", genbuf, 4, DOECHO, NULL );
	if ( *genbuf != 'y' && *genbuf != 'Y' ) {
	    clear();
	    return 0;
	}

	sprintf(buf,"Talk to '%s'",uident) ;
	report(buf) ;
	sock = socket(AF_INET, SOCK_STREAM, 0) ;
	if(sock < 0) {
	    perror("opening stream socket\n") ;
	    return -1 ;
	}

	server.sin_family = AF_INET ;
	server.sin_addr.s_addr = INADDR_ANY ;
	server.sin_port = 0 ;
	if(bind(sock, (struct sockaddr *) & server, sizeof server ) < 0) {
	    perror("binding stream socket") ;
	    return -1 ;
	}
	length = sizeof server ;
	if(getsockname(sock, (struct sockaddr *) &server, &length) < 0) {
	    perror("getting socket name") ;
	    return -1 ;
	}
	uinfo.sockactive = YEA ;
	uinfo.sockaddr = server.sin_port ;
	uinfo.destuid = tuid ;
	modify_user_mode( PAGE );
	kill(uin.pid,SIGUSR1) ;
	clear() ;
	prints("Paging %s.....\nTYPE CTRL-D to terminate\n", uident) ;

	listen(sock,1) ;
        add_io(sock,20) ;
	while(YEA) {
	    int ch ;
	    ch = igetch() ;
	    if(ch == I_TIMEOUT) {
		move(0,0) ;
		prints("Ringing Party Again.\n") ;
		bell() ;
		if(kill(uin.pid,SIGUSR1) == -1) {
		    move(0,0) ;
		    prints("Party has logged off\n\n\n") ;
		    pressreturn() ;
		    return -1 ;
		}
		continue ;
	    }
	    if(ch == I_OTHERDATA)
		break ;
	    if(ch == '\004') {
		add_io(0,0) ;
		close(sock) ;
		uinfo.sockactive = NA ;
		uinfo.destuid = 0 ;
		clear() ;
		return 0 ;
	    }
	}

	msgsock = accept(sock, (struct sockaddr *)0, (int *) 0) ;
	if(msgsock == -1) {
	    perror("accept") ;
	    return -1 ;
	}
        add_io(0,0) ;
	close(sock) ;
	uinfo.sockactive = NA ;
/*	uinfo.destuid = 0 ;*/
	read(msgsock,&c,sizeof c) ;

/* BEGIN -- by jjyang */
	if(c == 'y') {
	    struct userec au;
	    get_record(PASSFILE, &au, sizeof(au), uin.uid) ;
	    sprintf( save_page_requestor, "%s (%s)", au.userid, au.username);
	    do_talk(msgsock) ;
/* BEGIN -- by jjyang */

	} else {
	    clear() ;
	    prints("Talk request not accepted.\n") ;
	    pressreturn() ;
	}
	close(msgsock) ;
	clear() ;
	uinfo.destuid = 0;
    }
    return 0 ;
}

extern int talkrequest ;
#ifdef BBSNTALKD
extern int ntalkrequest ;
#endif
struct user_info  ui ;
char page_requestor[STRLEN];
char page_requestorid[STRLEN];

int cmpunums(unum,up)
int unum ;
struct user_info *up ;
{
    if(!up->active)
      return 0 ;
	return (unum == up->destuid) ;
}

setpagerequest()
{
    int tuid;
    struct userec au;

    tuid = search_ulist( &ui, cmpunums, usernum );
    if(tuid == 0)
	return 1;
    if(!ui.sockactive)
	return 1;
    get_record(PASSFILE,&au,sizeof(au),ui.uid) ;
    uinfo.destuid = ui.uid;
    sprintf(page_requestor, "%s (%s)", au.userid, au.username);
    strcpy( page_requestorid, au.userid );
    return 0;
}

servicepage(arg)
int arg;
{
    static time_t last_check;
    time_t now;
    char buf[STRLEN];
    int tuid = search_ulist( &ui, cmpunums, usernum );

    if(tuid == 0 || !ui.sockactive) talkrequest = NA;
    if (!talkrequest) {
	if (page_requestor[0]) {
	    switch (uinfo.mode) {
		case TALK:
		    move(arg, 0);
		    prints("-----------------------------------------------------------");
		    break;
		default: /* a chat mode */
		    sprintf(buf, "** INFO: no longer paged by %s", page_requestor);
		    printchatline(buf);
	    }
	    bzero(page_requestor, STRLEN);
	    last_check = 0;
	}
	return NA;
    } else {
	now = time(0);
	if (now - last_check > P_INT) {
	    last_check = now;
	    if (!page_requestor[0] && setpagerequest())
		return NA;
            else switch (uinfo.mode) {
		case TALK:
		    move(arg, 0);
		    prints("--- ** INFO: being paged by %s", page_requestor);
		    break;
		default: /* chat */
                    sprintf(buf, "** INFO: being paged by %s", page_requestor);
                    printchatline(buf);
	    }
	}
    }
    return YEA;
}

#ifdef BBSNTALKD

static char npage_requestor[STRLEN];
static char save_npage_requestor[STRLEN];
static char tmp_buf[STRLEN + 128];
setnpagerequest()
{
    FILE *getpager;
#ifndef GETPAGER
    return 1;
#else
    sprintf(tmp_buf,"%s %s",GETPAGER,currentuser.userid);
    getpager = popen(tmp_buf,"r"); 
    if (getpager == NULL) 
       return 1;
    fgets(npage_requestor, STRLEN, getpager);
    if ( *npage_requestor == '\0')
       return 1;
    return 0;
#endif
}

ntalkreply()
{
    int a ;
    struct hostent *h ;
    char buf[512] ;
    char hostname[STRLEN] ;
    struct sockaddr_in sin ;
    FILE *planfile;
    char inbuf[STRLEN*2];
    int i;
                
    talkrequest = NA ;
    ntalkrequest = NA ;

    if (setnpagerequest()) return 0;	
    clear() ;

    sprintf( inbuf, "�A�Q�� %s ���Ѷ�? (Yes or No) [Y]: ", npage_requestor );
    /*strcpy(save_npage_requestor, npage_requestor);
    bzero(npage_requestor, sizeof(npage_requestor));*/
    getdata(2,0, inbuf ,buf,STRLEN,DOECHO,NULL) ;

    if(buf[0] != 'n' && buf[0] != 'N') buf[0] = 'y';
    if(buf[0] != 'y') {
	report("page refused");
        ndo_talk(npage_requestor,1) ;
  	clear() ;
	return 0 ;
    }
    report("page accepted");
    ndo_talk(npage_requestor,0) ;
    clear() ;
    return 0 ;
}

ndo_talk(pager,reject)
char *pager ;
int reject;
{
#ifdef NTALK
    char tmp_buf[STRLEN + 128];
    if (reject) {
     sprintf(tmp_buf,"/bin/sh %s %s",REJECTCALL,pager);
    } else {
     sprintf(tmp_buf,"/bin/sh %s %s",NTALK,pager);
     modify_user_mode( TALK );
    }
    reset_tty() ;
    do_exec(tmp_buf,NULL) ;
    restore_tty() ;
    /*clear();*/
#endif
}


#endif


talkreply()
{
    int a ;
    struct hostent *h ;
    char buf[512] ;
    char hostname[STRLEN] ;
    struct sockaddr_in sin ;
    FILE *planfile;
    char inbuf[STRLEN*2];
    int i;
                
    talkrequest = NA ;
#ifdef BBSNTALKD
    ntalkrequest = NA ;
#endif
    if (setpagerequest()) return 0;	
    clear() ;

/* to show plan -cuteyu */

    move( 3, 0 );
    clrtobot();
    sprintf( genbuf, "home/%s/plans", page_requestorid );
    report( genbuf );
    if ( ( planfile = fopen( genbuf, "r" ) ) == NULL ) {
	prints( "%s �S������p��.\n", page_requestorid );
    } else {
	prints( "%s ���p��:\n\n", page_requestorid );
	for ( i = 1; i <= MAXQUERYLINES; i++ ) {
	    if ( fgets( inbuf, sizeof(inbuf), planfile ) )
		prints( "%s", inbuf );
	    else 
		break;
	}
	fclose( planfile );
    } 
    sprintf( inbuf, "�A�Q�� %s ���Ѷ�? (Yes or No) [Y]: ", page_requestor );
    strcpy(save_page_requestor, page_requestor);
    bzero(page_requestor, sizeof(page_requestor));
    bzero(page_requestorid, sizeof(page_requestorid));
    getdata(2,0, inbuf ,buf,STRLEN,DOECHO,NULL) ;
    gethostname(hostname,STRLEN) ;
    if(!(h = gethostbyname(hostname))) {
	perror("gethostbyname") ;
	return -1 ;
    }
    bzero(&sin, sizeof sin) ;
    sin.sin_family = h->h_addrtype ;
    bcopy(h->h_addr, &sin.sin_addr,h->h_length) ;
    sin.sin_port = ui.sockaddr ;
    a = socket(sin.sin_family,SOCK_STREAM,0) ;
    if((connect(a,&sin, sizeof sin))) {
	perror("connect failed") ;
	return -1 ;
    }
    if(buf[0] != 'n' && buf[0] != 'N') buf[0] = 'y';
    write(a,buf,1) ;
    if(buf[0] != 'y') {
	close(a) ;
	report("page refused");
  	clear() ;
	return 0 ;
    }
    report("page accepted");
    do_talk(a) ;
    close(a) ;
    clear() ;
    return 0 ;
}


dotalkent(uentp, buf)
struct user_info *uentp;
char *buf;
{
    struct userec utmp;
    char mch;
    if (!uentp->active || !uentp->pid) return -1;
    if(!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
	return -1;
    if(kill(uentp->pid,0) == -1) return -1;
    get_record(PASSFILE, &utmp, sizeof(utmp), uentp->uid);
    switch(uentp->mode) {
	case ULDL: mch = 'U'; break;
	case TALK: mch = 'T'; break;
	case CHAT1:
	case CHAT2:
	case CHAT3:
	case CHAT4: mch = 'C'; break;
	case IRCCHAT: mch = 'I'; break;
	case FOURM: mch = '4'; break;
	case BBSNET: mch = 'B'; break;
	case READNEW:
	case READING: mch = 'R'; break;
	case POSTING: mch = 'P'; break;
	case SMAIL:
	case RMAIL:
	case MAIL: mch = 'M'; break;
	default: mch = '-';
    }
    sprintf(buf, "%s%s(%c), ", uentp->invisible?"*":"", utmp.userid, mch);
    return 0;
}
 
dotalkuent(uentp)
struct user_info *uentp;
{
    char	buf[ STRLEN ];

    if( dotalkent( uentp, buf ) != -1 ) {
	strcpy( talk_uent_buf, buf );
	talk_uent_buf += strlen( buf );
    }
    return 0;
}
 
dotalkuserlist(sline,eline,curln,curcol,wordbuf,wordbuflen)
int sline, eline;
int *curln, *curcol;
char *wordbuf;
int *wordbuflen;
{
    char *s = "\n*** Users logged in ***\n";
    char bigbuf[ MAXACTIVE * 20 ];
    int savecolumns;
    struct user_info uent;

    savecolumns = (t_columns > STRLEN ? t_columns : 0);
    do_talk_string(sline,eline,curln,curcol,wordbuf,wordbuflen,s);

    talk_uent_buf = bigbuf;
    if( apply_ulist( dotalkuent ) == -1 ) {
	strcpy( bigbuf, "�S������ϥΪ̤W�u\n" );
    }
    strcpy( talk_uent_buf, "\n" );
    do_talk_string(sline,eline,curln,curcol,wordbuf,wordbuflen,bigbuf);
    if (savecolumns) t_columns = savecolumns;        
}

do_talk_string(sline,eline,curln,curcol,wordbuf,wordbuflen,s)
int sline, eline;
int *curln, *curcol;
char *wordbuf;
int *wordbuflen;
char *s;
{
    while (*s) {
	do_talk_char(sline,eline,curln,curcol,wordbuf,wordbuflen,*s);
	s++;
    }
}

 
do_talk_char(sline,eline,curln,curcol,wordbuf,wordbuflen,ch)
int sline, eline ;
int *curln, *curcol ;
char *wordbuf ;
int *wordbuflen ;
int ch ;
{
    extern int dumb_term ;
    if(isprint2(ch)) {
	if(*curcol != 79) {
	    wordbuf[(*wordbuflen)++] = ch ;
	    if(ch == ' ') *wordbuflen = 0 ;
	    move(*curln,(*curcol)++) ;
	    prints("%c",ch) ;
	    return ;
	}
	if(ch == ' ' || *wordbuflen >=78) {
	    (*curln)++ ;
	    *curcol = 0 ;
	    if(*curln > eline) *curln = sline ;
	    if((*curln) != eline) {
		move((*curln)+1,0) ;
		clrtoeol() ;
	    }
	    move(*curln,*curcol) ;
	    clrtoeol() ;
	    *wordbuflen = 0 ;
	    return ;
	}
	move(*curln,(*curcol) - *wordbuflen) ;
	clrtoeol() ;
	(*curln)++ ;
	*curcol = 0 ;
	if(*curln > eline) *curln = sline ;
        if((*curln) != eline) {
	    move((*curln)+1,0) ;
	    clrtoeol() ;
        }
	move(*curln,*curcol) ;
	clrtoeol() ;
	wordbuf[*wordbuflen] = '\0' ;
	if(dumb_term) prints("\n") ;
	prints("%s%c",wordbuf,ch) ;
	*curcol = (*wordbuflen)+1 ;
	*wordbuflen = 0 ;
	return ;
    }
    switch(ch) {
	case Ctrl('H'):
	case '\177':
	    if(dumb_term) ochar(Ctrl('H')) ;
	    if(*curcol == 0) {
		if(sline == 0) bell() ;
		return;
	    }
	    (*curcol)-- ;
	    move(*curln,*curcol) ;
	    if(!dumb_term) prints(" ") ;
	    move(*curln,*curcol) ;
	    if(*wordbuflen) (*wordbuflen)-- ;
	    return ;
	case Ctrl('M'):
	case Ctrl('J'):
	    if(dumb_term) prints("\n") ;
	    (*curln)++ ;
	    *curcol = 0 ;
	    if(*curln > eline) *curln = sline ;
	    if((*curln) != eline) {
		move((*curln)+1,0) ;
		clrtoeol() ;
	    }
	    move(*curln,*curcol) ;
	    clrtoeol() ;
	    *wordbuflen = 0 ;
	    return ;
	case Ctrl('G'):
	    bell() ;
	    return ;
	default:
	    break ;
    }
    return ;
}

char talkobuf[80] ;
int talkobuflen ;
int talkflushfd ;

talkflush()
{
    if(talkobuflen) 
      write(talkflushfd,talkobuf,talkobuflen) ;
    talkobuflen = 0 ;
}

do_talk(fd)
int fd ;
{
    int i ;
    int myln,mycol,myfirstln,mylastln  ;
    int itsln,itscol,itsfirstln,itslastln ;
    char itswordbuf[80],mywordbuf[80] ;
/* BEGIN - jjyang */
    char mid_line[ 255 ];
/* END - jjyang */

    int itswordbuflen,mywordbuflen ;
    int page_pending = NA;
    itswordbuflen = 0 ;
    mywordbuflen = 0 ;
    talkobuflen = 0 ;
    talkflushfd = fd ;
    modify_user_mode( TALK );
    clear() ;
    myfirstln = 0 ;
    mylastln = (t_lines-1)/2 - 1 ;
    move(mylastln+1,0) ;
    sprintf( genbuf, " %s (%s) v.s. %s ", 
       currentuser.userid, currentuser.username, save_page_requestor) ;

/*  BEGIN - jjyang */
    for (i=0; i<80; i++) mid_line[ i ] = '=';
    mid_line[ 80 ] = '\0';
    i = strlen( genbuf );
    memcpy( mid_line + (80 - i)/2 , genbuf, i );
    prints("%s", mid_line );
/*  END - jjyang */

    itsfirstln = mylastln+2 ;
    itslastln = (t_lines -1) ;
    myln = myfirstln ;
    mycol = 0 ;
    itsln = itsfirstln ;
    itscol = 0 ;
    move(myln,mycol) ;
    add_io(fd,0) ;
    add_flush(talkflush) ;
    while(YEA) {
	int ch ;
	if (talkrequest) page_pending = YEA;
	if (page_pending)
	    page_pending = servicepage(mylastln+1);
	ch = igetch() ;
	if ( ch == '' ) 
	{
	   igetch();
	   igetch();	
  	   continue;
	}
	if(ch == I_OTHERDATA) {
            char data[80] ;
            int datac ;
            register int i ;

            datac = read(fd,data,80) ;
            if(datac<=0) 
		break ;
	    for(i=0;i<datac;i++)
		do_talk_char(itsfirstln,itslastln,&itsln,&itscol,
			     itswordbuf,&itswordbuflen,data[i]) ;
	} else {
            if(ch == Ctrl('D') || ch == Ctrl('C'))
		break ;
	    if(isprint2(ch) || ch == Ctrl('H') || ch == '\177'
		|| ch == Ctrl('G') || ch == Ctrl('M') ) {
		talkobuf[talkobuflen++] = ch ;
		if(talkobuflen == 80) talkflush() ;
		do_talk_char(myfirstln,mylastln,&myln,&mycol,
			     mywordbuf,&mywordbuflen,ch) ;
	    }
	    else if (ch == Ctrl('U') || ch == Ctrl('W'))
		dotalkuserlist(myfirstln,mylastln,&myln,&mycol,
				mywordbuf,&mywordbuflen);
	    else if (ch == Ctrl('P') || HAS_PERM(PERM_BASIC)) {
		if (uinfo.pager == YEA){
		    do_talk_string(myfirstln,mylastln,&myln,&mycol,mywordbuf,
				   &mywordbuflen,"*** Pager turned off ***\n");
		    uinfo.pager = NA ;
		} else {
		    do_talk_string(myfirstln,mylastln,&myln,&mycol,mywordbuf,
				   &mywordbuflen,"*** Pager turned on ***\n");
		    uinfo.pager = YEA ;
		}
		update_utmp();
	    }
	    else bell() ;
	}
    }
    add_io(0,0) ;
    talkflush() ;
    add_flush(NULL) ;
}

shortulist(uentp)
struct user_info *uentp;
{
    static int fullcount = 0;
    static int lineno;
    static int cnt;
    static char *nullstring = "                        ";
    int finaltally;
    char uentry[30];
    struct userec utmp;

    if (!lineno) {
	lineno = 4;
	move(lineno, 0);
    }
    if (uentp == NULL) {
	clrtoeol();
	move(++lineno, 0);
	clrtobot();
	lineno = 0;
 	cnt = 0;
	finaltally = fullcount;
	fullcount = 0;
	return finaltally;
    }
    uentry[0]='\0';
    if (!uentp->active || !uentp->pid)
	strcpy(uentry, nullstring);
    if (!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
	strcpy(uentry, nullstring);
    if (kill(uentp->pid,0) == -1)
	strcpy(uentry, nullstring);
    get_record(PASSFILE, &utmp, sizeof(utmp), uentp->uid);
    if (!uentry[0]) {
	sprintf(uentry,"%-12s %c%-10s",utmp.userid,uentp->invisible?'#':' ',
		modestring(uentp->mode, uentp->destuid, 0, NULL));
	fullcount++;
    }

    if (++cnt < 3) strcat(uentry, " | ");
    if (lineno >= t_lines-1) return 0;
    prints(uentry);
    if (cnt == 3) {
	cnt = 0;
	clrtoeol();
	move(++lineno, 0);
	/* assuming no more than 60 logins at once */
    }
    return 0;
}

do_list( modestr )
char *modestr;
{       
    extern char BoardName[];
    int count;

    move(0,0);
    prints("%-30s%s", modestr, chkmail() ? "[�z���H��]" : BoardName );
    move(2,0);
    prints("%-12s  %-10s | %-12s  %-10s | %-12s  %-10s",
	   "User ID", "Mode", "User ID", "Mode", "User ID", "Mode");
    move(3,0);
    prints("%-12s  %-10s | %-12s  %-10s | %-12s  %-10s",
	    "-------", "----", "-------", "----", "-------", "----");
    if(apply_ulist( shortulist ) == -1) {
	prints("No Users Exist\n") ;
	return 0;
    }
    count = shortulist(NULL);
    if (uinfo.mode == MONITOR) {
	time_t thetime = time(0);		
	move(t_lines-1, 0);
	prints("�ثe�� %d �ӨϥΪ̤W�u, �{�b�ɨ�: %s",count, Ctime(&thetime));
    }
    refresh();
}

t_list()
{
    modify_user_mode( LUSERS );
    report("talk user list");
    do_list("�ϥΪ̪��A");
    pressreturn();
    clear();
    return 0;
}

int idle_monitor_time;

sig_catcher()
{
    if (uinfo.mode != MONITOR) {
#ifdef DOTIMEOUT
	init_alarm();
#else
	signal(SIGALRM, SIG_IGN);
#endif
	return;
    }		
    if (signal(SIGALRM, sig_catcher)==SIG_ERR) {
	perror("signal");
	exit(1);
    }
#ifdef DOTIMEOUT
    idle_monitor_time += M_INT;
    if (idle_monitor_time > MONITOR_TIMEOUT) {
	clear();
	fprintf(stderr, "Monitor idle timeout exceeded! Booting...\n");
	kill(getpid(), SIGHUP);
    }
#endif
    do_list("�ʬݨϥΪ�");
    alarm(M_INT);
}

t_monitor()
{
    char c;
    int i;

    alarm(0);
    signal(SIGALRM, sig_catcher);
    idle_monitor_time = 0;
    report("monitor");
    modify_user_mode( MONITOR );
    move(1,0);
    prints("�C�j %d ����s�@��, �Ы� Ctrl-C �� Ctrl-D ���}.",M_INT);
    do_list("�ʬݨϥΪ�");
    alarm(M_INT);
    while (YEA) {
	i = read(0,&c,1);
	if (!i || c == Ctrl('D') || c == Ctrl('C')) break;
	else if (i == -1) {
	    if (errno != EINTR) { perror("read"); exit(1); }
	} else idle_monitor_time = 0;
    }
    move(2,0);
    clrtoeol();
    return 0;
}

exec_cmd( umode, pager, cmdfile, mesg )
char	*cmdfile, *mesg;
{
    char buf[512] ;
    int save_pager;

    if( ! dashf( cmdfile ) ) {
        move(2,0);
	prints( "�ܩ�p, ���������� %s (%s) �\\��.", mesg, cmdfile );
	return;
    }
    save_pager = uinfo.pager;
    if( pager == NA ) {
	uinfo.pager = pager;
    }
    modify_user_mode( umode );
    sprintf( buf, "/bin/sh %s", cmdfile );
    reset_tty() ;
    do_exec(buf,NULL) ;
    restore_tty() ;
    uinfo.pager = save_pager;
    clear();
}

#ifdef IRC
t_irc() {
    exec_cmd( IRCCHAT, NA, "bin/irc.sh", "IRC" );
}
#endif /* IRC */

#ifdef HAVE_ANNOUNCE
t_announce() { exec_cmd( CSIE_ANNOUNCE, YEA, "bin/faq.sh", "ANNOUNCE" ); }
#endif

#ifdef HAVE_TIN
t_tin() { exec_cmd( CSIE_TIN, YEA, "bin/tin.sh", "TIN" ); }
#endif


#ifdef HAVE_GOPHER
t_gopher() { exec_cmd( CSIE_GOPHER, YEA, "bin/gopher.sh", "GOPHER" ); }
#endif

/* rrr -- stuff for providing pager override lists follows */

can_override(userid, uid, whoasks)
char *userid;
int uid;
char *whoasks;
{
    struct userec utmp;
    FILE *fp;
    char buf[STRLEN];
    char *namep;

    if (userid == NULL) {
        if (get_record(PASSFILE,&utmp,sizeof(utmp),uid) == -1)
    	    return 0;
	userid = utmp.userid;
    }
    sprintf(buf, "home/%s/overrides", userid);
    if ((fp = fopen(buf, "r")) == NULL)
	return 0;
    while (fgets(buf, STRLEN, fp) != NULL) {
	namep = (char *)strtok( buf, " \n\r\t" );
        if (!strcasecmp(namep, whoasks)) {
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}

listfriends()
{
    FILE *fp;
    int x = 0, y = 3, cnt = 0, max = 0, len;
    char u_buf[20], line[STRLEN], *nick;

    move(y,x);
    CreateNameList();
    sprintf(genbuf, "home/%s/overrides", currentuser.userid);
    if ((fp = fopen(genbuf, "r")) == NULL) {
	prints("(none)\n");
	return 0;
    }
    while(fgets(genbuf, STRLEN, fp) != NULL) {
	strtok( genbuf, " \n\r\t" );
	strcpy( u_buf, genbuf );
	AddNameList( u_buf );
	nick = (char *) strtok( NULL, "\n\r\t" );
	if( nick != NULL ) {
	    while( *nick == ' ' )  nick++;
	    if( *nick == '\0' )  nick = NULL;
	}
	if( nick == NULL ) {
	    strcpy( line, u_buf );
	} else {
	    sprintf( line, "%-12s%s", u_buf, nick );
	}
	if( (len = strlen( line )) > max )  max = len;
	if( x + len > 78 )  line[ 78 - x ] = '\0';
	prints( "%s", line );
	cnt++;
        if ((++y) >= t_lines-1) {
	    y = 3;
	    x += max + 2;
	    max = 0;
	    if( x > 70 )  break;
	}
	move(y,x);
    }
    fclose(fp);
    if (cnt == 0) prints("(none)\n");
    return cnt;
}

addtooverride(uident)
char *uident;
{
    FILE *fp;
    int rc;
    char buf[50];

    if (can_override(currentuser.userid, usernum, uident)) return -1;
    getdata(2,0,"Enter Description: ", buf,40,DOECHO,NULL);
    sprintf(genbuf, "home/%s/overrides", currentuser.userid);
    if ((fp = fopen(genbuf, "a")) == NULL)
	return -1;
    flock(fileno(fp), LOCK_EX);
    rc = fprintf( fp, "%-12s %s\n", uident, buf );
    flock(fileno(fp), LOCK_UN);
    fclose(fp);
    return(rc == EOF ? -1 : 0);
}		

deleteoverride(uident)
char *uident;
{
    FILE *fp, *nfp;
    int deleted = NA;
    char fn[STRLEN], fnnew[STRLEN];

    sprintf(fn, "home/%s/overrides", currentuser.userid);
    if ((fp = fopen(fn, "r")) == NULL) return -1;
    sprintf(fnnew, "home/%s/overrides.%d", currentuser.userid, getuid());
    if ((nfp = fopen(fnnew, "w")) == NULL) return -1;
    while(fgets(genbuf, STRLEN, fp) != NULL) {
	if (strncmp(genbuf, uident, strlen(uident)))
	    fputs(genbuf, nfp);
	else deleted = YEA;
    }
    fclose(fp);
    fclose(nfp);
    if (!deleted) return -1;
    return(rename(fnnew, fn));
}

t_override()
{
    char uident[STRLEN];
    char ans[8];
    int count;
/*
    uinfo.mode = 
    update_utmp();
*/
    while (1) {
	clear();
	prints("Edit Pager Override List\n");
	count = listfriends();
	if (count)
	    getdata(1,0, "(A)dd name, (D)elete name, or (E)xit? [E]: ", ans, 7, DOECHO, NULL);
	else 
	    getdata(1,0, "(A)dd name or (E)xit? [E]: ", ans, 7, DOECHO, NULL);
	if (*ans == 'A' || *ans == 'a') {
	    move(1,0);
	    usercomplete("Add userid: ", uident);
/*	    move(1,0);
	    clrtoeol();
*/	    if (uident[0] != '\0' && getuser(uident))
	        addtooverride(uident);
	} else if ((*ans == 'D' || *ans == 'd') && count) {
	    move(1,0);
	    namecomplete("Delete userid: ", uident);
	    move(1,0);
	    clrtoeol();
	    if (uident[0] != '\0')
		deleteoverride(uident);
	} else break;
    }
    clear();
    return;
}		

t_friends()
{
    FILE	*fp;
    char	friends_buffer[ 0x1000 ];

    modify_user_mode( FRIEND );
    sprintf(genbuf, "home/%s/overrides", currentuser.userid);
    if ((fp = fopen(genbuf, "r")) == NULL) {
	move( 3, 0 );
	clrtobot();
	prints("�ثe�٨S�]�w�n�ͦW��A�ЧQ��(T)alk->(O)verride �]�w\n");
	pressreturn();
	clear();
	return 0;
    }
    friends_list = friends_buffer;
    friends_number = 0;

    strcpy( friends_list, " " );
    while (fgets(genbuf, STRLEN, fp) != NULL) {
	if ( strtok( genbuf, " \n\r\t") != NULL) {
	    strcat( friends_list, genbuf );
	    strcat( friends_list, " " );
	}
    }
    fclose( fp );

    printcuent( NULL ) ;
    if ( apply_ulist( printcuent ) == -1 ) 
	prints("�S������ϥΪ̤W�u\n") ;

    if( friends_number == 0 ) {
	move( 3, 0 );
	clrtobot();
	prints( "�A���@�U�a�A�]�\\�L�̫ݷ|��N�W�u�F�C\n");
    }
    clrtobot() ;
    pressreturn();
    friends_list = NULL;
    return 0;
}

