/* Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"
#include <sys/file.h> 
#include <signal.h>
#include <string.h>

jmp_buf byebye ;

FILE *ufp ;
int talkrequest = NA ;
#ifdef BBSNTALKD
int ntalkrequest = NA ;
#endif
int bfinger = 0;
int enter_uflags;

struct user_info uinfo ;

#ifdef SHOW_IDLE_TIME
char fromhost[STRLEN - 20 ] ;
char tty_name[ 20 ] ;
#else
char fromhost[STRLEN] ;
#endif

char BoardName[STRLEN] ;
char ULIST[STRLEN] ;
int utmpent = -1 ;
time_t	login_start_time;

u_enter()
{
    enter_uflags = currentuser.flags[0];
    uinfo.active = YEA ;
    uinfo.pid    = getpid() ;
    if (HAS_PERM(PERM_LOGINCLOAK))
	uinfo.invisible = currentuser.flags[0] & CLOAK_FLAG ? YEA : NA;
    else 
    	uinfo.invisible = NA;
    uinfo.sockactive = NA ;
    uinfo.sockaddr = 0 ;
    uinfo.destuid = 0 ;
    uinfo.mode = LOGIN ;
    uinfo.pager = !(currentuser.flags[0] & PAGER_FLAG);
/*  uinfo.pager = 1; always pager on when login. now cancel by cuteyu */
    uinfo.in_chat = NA ;
    bzero(uinfo.chatid, sizeof(uinfo.chatid));
    uinfo.uid = usernum ;
    strncpy(uinfo.from,fromhost,STRLEN) ;
#ifdef SHOW_IDLE_TIME
    strcpy( uinfo.tty, tty_name);
#endif
    utmpent = getnewutmpent(&uinfo) ;
}

setflags(mask, value)
int mask, value;
{
    if (((currentuser.flags[0] & mask) && 1) != value) {
        if (value) currentuser.flags[0] |= mask;
        else currentuser.flags[0] &= ~mask;
    }
}

u_exit()
{
    setflags(PAGER_FLAG, !uinfo.pager);
    if (HAS_PERM(PERM_LOGINCLOAK))
        setflags(CLOAK_FLAG, uinfo.invisible);

    if( currentuser.flags[0] != enter_uflags ) {
        substitute_record(PASSFILE,&currentuser,sizeof(currentuser),usernum);
    }

    uinfo.active = NA ;
    uinfo.pid = 0 ;
    uinfo.invisible = YEA ;
    uinfo.sockactive = NA ;
    uinfo.sockaddr = 0 ;
    uinfo.destuid = 0 ;
#ifdef SHOW_IDLE_TIME
    strcpy(uinfo.tty, "NoTTY");
#endif
    update_utmp();
}

int
cmpuids(uid,up)
char *uid ;
struct userec *up ;
{
    return !ci_strncmp(uid,up->userid,sizeof(up->userid)) ;
}


int
dosearchuser(userid)
char *userid ;
{
    int		id;

    if( (id = getuser( userid )) != 0 ) {
	if( cmpuids( userid, &lookupuser ) ) {
	    memcpy( &currentuser, &lookupuser, sizeof(currentuser) );
	    return usernum = id;
	}
    }
    return usernum = 0;
}

int started = 0;

#ifdef BBSNTALKD
ntalk_request()
{
    ntalkrequest = YEA ;
    bell();
    bell();
    bell();
    sleep( 1 );
    bell();
    bell();
    bell();
    bell();
    bell();
    return ;
}
#endif

talk_request()
{
    talkrequest = YEA ;
    bell();
    bell();
    bell();
    sleep( 1 );
    bell();
    bell();
    bell();
    bell();
    bell();
    return ;
}

abort_bbs()
{
    time_t	now;

    now = time(0) ;
    if (started && dashf("usies") ) {
	if((ufp = fopen("usies","a")) != NULL) {
	    fprintf(ufp,"%20.20s AXXED %-12s Stay:%3d (%s)\n",
		ctime( &now ) + 4, currentuser.userid,
		(now - login_start_time) / 60, currentuser.username );
	    fclose(ufp) ;
	    u_exit() ;
	}
    }
    exit(0) ;
}

cmpuids2(unum, urec)
int unum;
struct user_info *urec;
{
    return (unum == urec->uid);
}

count_user( farg)
int farg;
{
    return 0;
}

multi_user_check()
{
    struct user_info uin;
    char buffer[40];

    if (HAS_PERM(PERM_MULTILOG)) return;  /* don't check sysops */

    /* allow multiple guest user */
    if (!strcmp("guest", currentuser.userid)) {
    	if ( count_user( usernum ) > 16 ) {
	    prints( "��p, �ثe�w���Ӧh guest, �еy��A�աC\n");
	    pressreturn();
	    oflush();
	    exit(1);
	}
     	return;
    }
    if ( !search_ulist( &uin, cmpuids2, usernum) )
        return;  /* user isn't logged in */

    if (!uin.active || (kill(uin.pid,0) == -1))
        return;  /* stale entry in utmp file */

    getdata(0, 0, "�z�Q�R�����ƪ� login �� (Y/N)? [Y]", genbuf, 4, 
            DOECHO, NULL);

    if(genbuf[0] != 'N' && genbuf[0] != 'n') {
        kill(uin.pid,9);
        sprintf(buffer, "kicked (multi-login)" );
        report(buffer);
        if ((ufp = fopen("usies", "a")) != NULL) {
	    time_t	now;

            now = time(0);
            fprintf(ufp, "%20.20s KICK  %-12s %s\n",
		ctime(&now) + 4, currentuser.userid, currentuser.username );
            fclose(ufp);
        }
    }
}

account_disabled(userid)
char *userid;
{
    FILE *fp;
    char buf[STRLEN];
    int blen;
    if ((fp = fopen(".disabled", "r")) == NULL)
        return 0;
    while (fgets(buf, STRLEN, fp) != NULL) {
        blen = strlen(buf);
        if (buf[blen-1] == '\n')
            buf[--blen] = '\0';
        if (!strncmp(buf, userid, blen)) {
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}

int bad_user_id(userid)
char *userid;
{
    FILE *fp;
    char buf[STRLEN];
    char *p, ch;

/*
    if ( strlen( userid ) < 4 ) return 1;
*/
    for( p = userid; (ch = *p) != '\0'; p++ ) {
	if( !(  (ch >= '0' && ch <= '9') ||
		(ch >= 'A' && ch <= 'Z') ||
		(ch >= 'a' && ch <= 'z') ||
		(ch == '_') 	) )
	    return 1;
    }

    if ((fp = fopen(".badname", "r")) == NULL)
        return 0;

    while (fgets(buf, STRLEN, fp) != NULL) {
        if ( (p = (char *)strtok( buf, " \n\t\r" )) == NULL) continue;
        if (p[ 0 ] == '#') continue;
        if (!strcmp(p, userid)) {
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}

int simplepasswd( str )
char *str;
{
    char	ch;

    while( (ch = *str++) != '\0' ) {
	if( ! (ch >= 'a' && ch <= 'z') )
	    return 0;
    }
    return 1;
}

system_init(argc, argv)
int	argc;
char	**argv;
{
    int getin ;

    login_start_time = time( 0 );
    gethostname( genbuf ,256 );
#ifdef SINGLE
    if( strcmp( genbuf, SINGLE ) ) {
        printf("Not on a valid machine!\n") ;
        exit(-1) ;
    }
#endif
    sprintf( ULIST, "%s.%s", ULIST_BASE, genbuf );

    getin = NA;

    if( argc >= 3 ) {
	strncpy( fromhost, argv[2], STRLEN );
    } else {
	fromhost[0] = '\0';
    }
#ifdef SHOW_IDLE_TIME
    if(argc >= 4) { 
	strncpy( tty_name, argv[3], 20 ) ;
    } else {
	tty_name[0] = '\0' ;
    }
#endif

#ifndef lint
    signal(SIGHUP,abort_bbs) ;
    signal(SIGINT,SIG_IGN) ;
    signal(SIGQUIT,SIG_IGN) ;
    signal(SIGPIPE,SIG_IGN) ;
#ifdef DOTIMEOUT
    init_alarm();
#else
    signal(SIGALRM,SIG_IGN) ;
#endif
    signal(SIGTERM,SIG_IGN) ;
    signal(SIGURG,SIG_IGN) ;
    signal(SIGTSTP,SIG_IGN) ;
    signal(SIGTTIN,SIG_IGN) ;
    signal(SIGTTOU,SIG_IGN) ;
    signal(SIGUSR1,talk_request) ;
#ifdef BBSNTALKD
    signal(SIGUSR2,ntalk_request) ;
#else
    signal(SIGUSR2,SIG_IGN) ;
#endif
#endif

    return getin;
}

system_abort()
{
    time_t	now;

    if( started && (ufp = fopen("usies","a")) != NULL ) {
	now = time(0) ;
	fprintf(ufp,"%20.20s ABORT %-12s %s\n",
		ctime(&now) + 4, currentuser.userid, currentuser.username );
	fclose(ufp) ;
	u_exit() ;
    }
    clear();
    refresh();
    printf("���¥��{, �O�o�`�ӳ� !\n");
    exit(0) ;
}

login_validate( getin )
int	getin;
{
    int		curr_login_num, kick_out;

#ifdef RESTRICT_BBS
    if ( strstr( "bbs.csie.nctu.edu.tw", fromhost) ) {
        fprintf( stderr, "Sorry, cannot login bbs from %s\n", fromhost );
	exit( -1 );
    }
#endif

    curr_login_num = num_active_users();
    kick_out = (getin || curr_login_num < MAXACTIVE) ? 0 : 1;
    if (kick_out) { 
	if( (ufp = fopen("boot.off","r")) != NULL ) {
	    while( fgets( genbuf, 256, ufp ) != NULL)
		fprintf( stderr, "%s", genbuf );
	    close( ufp );
	} else {
            fprintf( stderr, "\n\
Sorry, BBS system is full. Call again later.\n\
�ܩ�p,�ثe�w�g�� %d �H�i��,�е��@�|��A��\n\
�p�G�z�b��u�t�� account, �Х� bbstin ��Ū�峹, �O�ҧ֪����A�եؤ@�s!!\n\
�p�G�z�� unix account, �бN 0)Announce: ���i�ƶ����� nbbstin ���^,\n\
�]�w���i���� (chmod +x nbbstin), �M��N�ઽ��Ū bbs �� 1)Discuss ���峹.\n\
PS: �Цۦ�]�w�Ĥ@�� #!/bin/perl �βĤT�� $tin = '/fullpath ... /tin';\n\
", curr_login_num );
        }
        exit(-1) ;
    }
    return curr_login_num;
}

new_register()
{
    struct userec	newuser;
    char	passbuf[ STRLEN ];
    int		allocid, try;

    if( 1 ) {
	time_t  now;

	now = time( 0 );
	sprintf( genbuf, "etc/no_register_%3.3s", ctime( &now ) );
	if( dashf( genbuf ) ) {
	    ansimore( genbuf, NA );
	    pressreturn();
	    exit( 1 );
	}
    }
    bzero( &newuser, sizeof(newuser) );
    allocid = getnewuserid()  ;
    if(allocid > MAXUSERS || allocid <= 0) {
	printf("No space for new users on the system!\n\r") ;
	exit(1) ;
    }

    ansimore("etc/register", NA);
    try = 0;
    while( 1 ) {
	if( ++try >= 10 ) {
	    prints("\nBye Bye, 10 <Enter> makes you leave.\n");
	    refresh();
#ifdef TWO_LONGJMP_ARGS
	    longjmp( byebye, 1 );
#else
	    longjmp( byebye );
#endif
	}
	getdata(0,0,"�п�J�N��: ",newuser.userid,IDLEN+1,DOECHO,NULL) ;

        if ( (*newuser.userid == '\0') || bad_user_id( newuser.userid ) ) {
	    prints( "�L�k�����o�ӥN���A�Шϥέ^��r���A�åB���n�]�t�Ů�.\n" );
	} else if( dosearchuser( newuser.userid ) ) { 
            prints("���N���w�g���H�ϥ�\n") ;
        } else {
	    break;
	}
    }

    while( 1 ) {
	getdata(0,0,"�г]�w�z���K�X: ",passbuf,PASSLEN,NOECHO,NULL) ;
	if( strlen( passbuf ) < 4 || !strcmp( passbuf, newuser.userid ) ) {
            prints("�K�X�ӵu�λP�ϥΪ̥N���ۦP, �Э��s��J\n") ;
	    continue;
	}
	strncpy( newuser.passwd, passbuf, PASSLEN );
	getdata(0,0,"�ЦA��J�@���A���K�X: ",passbuf,PASSLEN,NOECHO,NULL);
	if( strncmp( passbuf, newuser.passwd, PASSLEN ) != 0 ) {
	    prints("�K�X��J���~, �Э��s��J�K�X.\n") ;
	    continue;
        }
	passbuf[8] = '\0' ;
	strncpy( newuser.passwd, genpasswd( passbuf ), PASSLEN );
	break;
    }

    getdata(0,0,"�z���ʺ�: ",newuser.username,NAMELEN,ECHO,NULL) ;
    getdata(0,0,"�u��m�W: ",newuser.realname,NAMELEN,ECHO,NULL);
    getdata(0,0,"�ثe���}: ", newuser.address,STRLEN,ECHO,NULL);
    getdata(0,0,"�q�l�l��a�}: ", newuser.email,STRLEN,ECHO,NULL);

    getdata(0,0,"�׺ݾ��κA (vt100,vt102,ansi,dumb,...): ",
		newuser.termtype, 16 ,ECHO,NULL) ;
    if( newuser.termtype[0] == '\0' ) {
	strcpy(newuser.termtype, "vt100");
    }

    newuser.userlevel = PERM_DEFAULT;
    newuser.flags[0] = CURSOR_FLAG;
    newuser.flags[1] = 0;
    newuser.firstlogin = newuser.lastlogin = time(NULL) ;

    if( substitute_record(PASSFILE,&newuser,sizeof(newuser),allocid) == -1 ) {
	fprintf(stderr,"too much, good bye!\n") ;
	exit(1) ;
    }
    touchnew() ;
    if( !dosearchuser(newuser.userid) ) {
	fprintf(stderr,"User failed to create\n") ;
	exit(1) ;
    }
    report( "new account" );
}

login_query( curr_login_num )
int	curr_login_num;
{
    char uid[STRLEN], passbuf[PASSLEN];
    char	*ptr;
    int		fd, len, attempts, baduserid;

    if( (fd = open(NAMEFILE, O_RDONLY) ) > 0) {
	len = read( fd, BoardName, STRLEN );
	BoardName[ len ] = '\0' ;
	if( ptr = index( BoardName, '\n' ) )
	    *ptr = '\0' ;
	close(fd) ;
    } else {
        strcpy( BoardName, BOARDNAME );
    }
    ansimore( "etc/issue", NA );
    prints( "�w����{ %s (�ثe�@�� %d �H�W�u)\n", BoardName, curr_login_num );

    attempts = 0;
    while( 1 ) {
	if( attempts++ >= LOGINATTEMPTS ) {
	    ansimore( "etc/goodbye", NA );
	    oflush();
	    sleep( 1 );
	    exit( 1 );
	}
	getdata( 0, 0, "\n�п�J�N��(�եνп�J `guest', ���U�п�J`new'): ",
		uid, STRLEN, DOECHO, NULL );
	if( uid[0] == '\0' ) {
	    continue;
	} else if( strcmp( uid, "new" ) == 0 ) {
#ifdef LOGINASNEW
	    new_register();
#else
	    prints( "���t�Υثe�L�k�H new ���U, �Х� guest �i�J.\n" );
	    continue;
#endif
	} else {
	    baduserid = NA;
	    if( !dosearchuser( uid ) )  baduserid = YEA;
	    if( !baduserid && strcmp( uid, "guest" ) == 0 )  break;
	    getdata( 0, 0, "�п�J�K�X: ", passbuf, PASSLEN, NOECHO, NULL );
	    passbuf[8] = '\0';
/*
	    if( simplepasswd( passbuf ) ) {
		prints("�K�X�L��²��, �п�ܤ@�ӥH�W���Ʀr�ίS���r��.\n");
		oflush();
		sleep( 1 );
	    }
*/
	    if( baduserid || !checkpasswd( currentuser.passwd, passbuf ) ) {
		logattempt( baduserid ? uid : currentuser.userid,
			    fromhost, baduserid );
		prints( "�N���αK�X��J���~...\n" );
		continue;
	    }
	    if( currentuser.passwd[0] == '\0' ) {
		strncpy( currentuser.passwd, genpasswd( passbuf ), PASSLEN );
	    }
	}
	break;
    }

    if( account_disabled(currentuser.userid) ) {
	prints( "���b���ثe�Ȯ������C�ЦV�t�ξާ@�̬d�ߡA�H��_�z���b���C\n" );
	oflush();
	sleep( 1 );
	exit(1);
    }
    multi_user_check();
    if( !term_init(currentuser.termtype) ) {
	prints("Bad terminal type.  Defaulting to 'vt100'\n") ;
	term_init("vt100") ;
    }

/* Add by mfchen, make user's home directory */
    sprintf( genbuf, "home/%s", currentuser.userid );
    mkdir( genbuf, 0755 );
/* make home end */

    currentuser.firstlogin_new_position = currentuser.firstlogin;
    if (currentuser.firstlogin == 0) {
        currentuser.firstlogin = time(NULL) - 7 * 86400;
    }
}

int
valid_ident( ident )
char *ident;
{
    static char	*invalid[] = { "unknown@", "root@", "gopher@", "bbs@",
	"guest@", NULL };
    int		i;

    for( i = 0; invalid[i] != NULL; i++ )
	if( strstr( ident, invalid[i] ) == ident )
	    return 0;
    return 1;
}

user_login()
{
    char	*getenv();
    char	ans[4], *rhost, *ruser;
    int		numbad;
    time_t	now;

    if( strcmp( currentuser.userid, "SYSOP" ) == 0 )
	currentuser.userlevel = ~0;   /* SYSOP gets all permission bits */

    now = time(0) ;
    rhost = getenv( "REMOTEHOSTNAME" );
    ruser = getenv( "REMOTEUSERNAME" );

    if((ufp = fopen("usies","a")) != NULL) {
	fprintf(ufp,"%20.20s ENTER %-12s %s (%s)\n",
		ctime(&now)+4, currentuser.userid,
		rhost ? rhost : fromhost, ruser ? ruser : "" );
	fclose(ufp) ;
    }
    if( ruser ) {
	sprintf( genbuf, "%s@%s", ruser, rhost ? rhost : fromhost );
	if( valid_ident( genbuf ) ) {
	    strncpy( currentuser.ident, genbuf, NAMELEN );
	}
	if( !valid_ident( currentuser.ident ) ) {
	    currentuser.ident[0] = '\0';
	}
    }
    u_enter() ;
    report("Enter") ;
    started = 1 ;
    initscr() ;
    scrint = 1 ;
    ansimore("Welcome", NA);
    move( t_lines - 3, 0 );
    sprintf(genbuf, " * �o�O�z�� %d �����X�����A�W���z�O�q %s �s�������C",
         currentuser.numlogins > 0 ? currentuser.numlogins : 1 , 
         currentuser.lasthost != NULL ? currentuser.lasthost : "�����W���a��");
    prints("%s\n", genbuf);
    sprintf(genbuf, " * �W���s�u����� %s", ctime(&currentuser.lastlogin));
    prints("%s\n", genbuf);
    refresh();

    if ((numbad = countattempts()) <= 0) {
  	pressreturn();
    } else {
        refresh();
        sprintf(genbuf, "NOTICE: %d new bad login attempts on this account. View (Y/N)? [Y]: ", numbad);
        getdata(t_lines-1, 0, genbuf, ans, 4, DOECHO, NULL);
        if (*ans == 'N' || *ans == 'n') showattempts(NA);
        else showattempts(YEA);
    }

    strncpy(currentuser.lasthost, fromhost, 16);
    currentuser.lasthost[15] = '\0';   /* dumb mistake on my part */
    currentuser.lastlogin = time(NULL) ;
    currentuser.numlogins++;
    substitute_record(PASSFILE,&currentuser,sizeof(currentuser),usernum) ;

    delay_non_vip();
}

main(argc, argv)
int argc ;
char **argv ;
{
    int		getin, curr_login_num, cmd;

    getin = system_init( argc, argv );
    curr_login_num = login_validate( getin );
    if( setjmp(byebye) ) {
	system_abort();
    }
    get_tty();
    init_tty();
    login_query( curr_login_num );
    user_login();

    m_init() ;
#ifdef SYSV
    if (get_semaphore() == -1) {
        printf("Can't get semaphore! Exiting...\n");
        exit(1);
    }
#endif
 
#ifdef VOTE
    closepolls();
#endif
    b_closepolls();

    cmd = 'b';
    if(chkmail()) cmd = 'm' ;
    while( 1 )
	docmd( MMENU, "�D���      ", "���O��J: ", cmd, cmdlist );
}

char *
boardmargin()
{
    static char buf[STRLEN] ;
    if(selboard)
        sprintf(buf,"�ثe�Q�װ� [%s]",currboard) ;
    else {
	brc_initial( DEFAULTBOARD );
        if (getbnum(currboard)) {
            selboard = 1 ;
            sprintf(buf,"�ثe�Q�װ� [%s]",currboard) ;
        }
        else sprintf(buf,"�ثe�èS���]�w�Q�װ�") ;
    }
    return buf ;
}

int refscreen = NA ;

int
egetch()
{
    char c ;
    int rval ;

    if (talkrequest) {
        talkreply() ;
        refscreen = YEA ;
        return -1 ;
    }
#ifdef BBSNTALKD
    if (ntalkrequest) {
        ntalkreply() ;
        refscreen = YEA ;
        return -1 ;
    }
#endif
    while( 1 ) {
	rval = igetkey();
        if(talkrequest) {
            talkreply() ;
            refscreen = YEA ;
            return -1 ;
        }
#ifdef BBSNTALKD
        if(ntalkrequest) {
            ntalkreply() ;
            refscreen = YEA ;
            return -1 ;
        }
#endif
	if( rval != Ctrl('L') )
	    break;
	redoscr();
    }
    refscreen = NA ;
    return rval ;
}

showtitle( title, mid )
char	*title, *mid;
{
    char	buf[ STRLEN ], *note;
    int		spc;

    note = boardmargin();
    spc = 78 - strlen( title ) - strlen( mid ) - strlen( note );
    if( spc < 4 )  spc = 4;
    move(0,0);
    sprintf( buf, "%*s", spc/2, "" );
    prints( "%s%s%s", title, buf, mid );
    sprintf( buf, "%*s", (spc+1)/2, "" );
    prints( "%s%s\n", buf, note );
}

docmdtitle( title, prompt )
char	*title, *prompt;
{
    static int	sysvote = -1;
    char	buf[ 128 ];
    char	*mid;
    int		spc;

    if( sysvote == -1 ) {
	sysvote = dashf( "vote/control" );
    }
    if( sysvote && (currentuser.flags[0] & VOTE_FLAG) )  sysvote = 0;
    if( chkmail() )  mid = "[�z���H��]";
    else if( sysvote )  mid = "[�t�Χ벼��]";
    else  mid = BoardName;
    showtitle( title, mid );
    prints( "%s", prompt );
    clrtoeol() ;
}

docmdhelp( cmdtable )
struct commands cmdtable[] ;
{
    int		cmd;

    for( cmd = 0; cmdtable[cmd].cmdname != NULL; cmd++ )
	if( *(cmdtable[cmd].cmdname) == 'H' )
	    (*cmdtable[cmd].cmdfunc)();
}

docmd( cmdmode, cmdtitle, cmdprompt, firstcmd, cmdtable )
char *cmdtitle,*cmdprompt ;
int cmdmode, firstcmd ;
struct commands cmdtable[] ;
{
    static int	help_menu;
    int		cmd, lastcmdptr ;
    int		cmdplen ;

    modify_user_mode( cmdmode );
    help_menu = (!dumb_term) && (currentuser.flags[0] & CURSOR_FLAG);
    cmdplen = strlen(cmdprompt) ;
grok:
    clear() ;

    if( help_menu )  docmdhelp( cmdtable );
    docmdtitle( cmdtitle, cmdprompt );

    cmd = firstcmd ;
    lastcmdptr = 0 ;
    do {
        int i=0 ;
        int err ;

        if(cmd == '\n' || cmd == '\r' || cmd == KEY_RIGHT) {
            if(dumb_term)
                prints("\n") ;
            else {
                move(1,cmdplen) ;
                clrtoeol() ;
                refresh() ;
            }
            clrstandout() ;
            if((err = (*cmdtable[lastcmdptr].cmdfunc)()) == QUIT)
                return ;
	
	    modify_user_mode( cmdmode );

	    if( !dumb_term && *cmdtable[lastcmdptr].cmdname == 'H' ) {
		help_menu = 1 - help_menu;
		help_menu ? currentuser.flags[0] |= CURSOR_FLAG 
			  : (currentuser.flags[0] &= ~CURSOR_FLAG);
	    }

	    if( help_menu )  docmdhelp( cmdtable );
	    docmdtitle( cmdtitle, cmdprompt );

            if(err)
                cmd = *(cmdtable[lastcmdptr].errorcmd) ;
            else
                cmd = *(cmdtable[lastcmdptr].nextcmd) ;
        }
            
	switch( cmd ) {
	    case KEY_LEFT:
	   /* cuteyu */ 
		cmd = 'G';
	    	while(i != 7) {
		    if(cmdtable[i].cmdname == NULL)
                    	break ;
		    if((*(cmdtable[i].cmdname) & ~0x20) == (cmd & ~0x20))
                    	break ;
		    i++ ;
		}
		if ( i == 7 || cmdtable[i].cmdname == NULL )
		{
			clear();
			return;
		}
		break;
/*		return;*/
	    case KEY_DOWN: 
		i = lastcmdptr;
		while( 1 ) {
		    i++;
		    if (cmdtable[ i ].cmdname == NULL) {
			i = 0 /* lastcmdptr*/;
			break;
		    } else if (HAS_PERM(cmdtable[i].level))
			break;
		}
		break;
	    case KEY_UP: 
		i = lastcmdptr;
		while( 1 ) {
		    i--;
		    if( i < 0 ) {
			i = 0;
			while(i != 100) 
			{
		    	if(cmdtable[i].cmdname == NULL)
                    		break ;
		    	i++ ;
			}
			i--;
			/* i = lastcmdptr; */
			break;
		    } else if (HAS_PERM(cmdtable[i].level))
			break;
		}
		break;
            default:
       		while(i != 100) {
		    if(cmdtable[i].cmdname == NULL)
                    	break ;
		    if((*(cmdtable[i].cmdname) & ~0x20) == (cmd & ~0x20))
                    	break ;
		    i++ ;
		}
	}

        if(cmdtable[i].cmdname == NULL) {
            bell() ;
            continue ;
        }
        if(!HAS_PERM(cmdtable[i].level)) {
            bell() ;
            continue ;
        }
/* BEGIN -- remove & redraw cursor */
	if( help_menu ) {
	    int		n, pos;

	    for( n = pos = 0; n <= lastcmdptr; n++ ) {
		if(HAS_PERM(cmdtable[n].level))
		    pos++;
	    }
	    move(3+pos,0); prints( "  " );
	    for( n = pos = 0; n <= i; n++ ) {
		if(HAS_PERM(cmdtable[n].level))
		    pos++;
	    }
	    move(3+pos,0); prints( "->" );
	}
/* END -- remove & redraw cursor */
	lastcmdptr = i ;
	move(1,cmdplen) ;
	standout() ;
	prints("%s",cmdtable[i].cmdname) ;
	standend() ;
	clrtoeol() ;
    } while ((cmd = egetch()) != EOF) ;

    if(refscreen)
        goto grok ;
    abort_bbs() ;
}

#define BADLOGINSTRSZ   80
#define BADLOGINFILE    "logins.bad"
extern char *Ctime();

logattempt(uid, frm, badid)
char *uid, *frm;
int badid;
{
    time_t	t;
    char	buf[BADLOGINSTRSZ+1];
    char	*timestr;
    int		fd;

    time(&t);
    timestr = Ctime(&t);
    uid[12] = '\0';
    sprintf(buf, "%-12s %-32s %-16s %c               \n", uid,timestr,frm,badid?'Y':'N');
    append_record(BADLOGINFILE, buf, BADLOGINSTRSZ);

    sprintf( genbuf, "home/%s/%s", uid, BADLOGINFILE );
    if( (fd = open( genbuf, O_WRONLY|O_CREAT|O_APPEND, 0644 )) != -1 ) {
	write( fd, buf, BADLOGINSTRSZ );
	close( fd );
    }
    return;
}

countattempts()
{
    int fd, cnt = 0;
    char buf[BADLOGINSTRSZ];

    if (!HAS_PERM(PERM_BASIC))
        return -1;    /* don't show the bad login attempts */

    sprintf( genbuf, "home/%s/%s", currentuser.userid, BADLOGINFILE );
    if( (fd = open( genbuf, O_RDONLY )) == -1 )
        return 0;
    while( read(fd, buf, BADLOGINSTRSZ) == BADLOGINSTRSZ )
	cnt++;
    close(fd);
    return cnt;
}

showattempts(really)
int really;
{
    int fd, ln = 1;
    char buf[BADLOGINSTRSZ];

    sprintf( genbuf, "home/%s/%s", currentuser.userid, BADLOGINFILE );
    if( (fd = open( genbuf, O_RDONLY )) == -1 )
        return;
    if( really ) {
	clear();
	while( read(fd, buf, BADLOGINSTRSZ) == BADLOGINSTRSZ ) {
	    buf[45] = buf[62] = '\0';
	    if (ln >= t_lines) {
	        prints("More -- press a key to continue\n");
	        igetch();
	        clear();
	        ln = 1;
	    }
	    prints("�����\\�� LOGIN �Ӧ� %s �b %s\n", &buf[46], &buf[13]);
	    ln++;
        }
    }
    close(fd);
    unlink( genbuf );
    if (really) {
        pressreturn();
        clear();
    }
    return;
}

