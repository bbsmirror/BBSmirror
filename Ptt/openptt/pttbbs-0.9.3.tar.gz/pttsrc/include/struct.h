/* $Id: struct.h,v 1.2 2000/05/11 17:14:55 davidyu Exp $ */
#ifndef INCLUDE_STRUCT_H
#define INCLUDE_STRUCT_H

/* �p������� */
typedef struct chicken_t {
    char name[20];
    char type;              /* ���� */
    unsigned char tech[16]; /* �ޯ� */
    time_t birthday;        /* �ͤ� */
    time_t lastvisit;       /* �W�����U�ɶ� */
    int oo;                 /* �ɫ~ */
    int food;               /* ���� */
    int medicine;           /* �ī~ */
    int weight;             /* �魫 */
    int clean;              /* ���b */
    int run;                /* �ӱ��� */
    int attack;             /* �����O */
    int book;               /* ���� */
    int happy;              /* �ּ� */
    int satis;              /* ���N�� */
    int temperament;        /* ��� */
    int tiredstrong;        /* �h�ҫ� */
    int sick;               /* �f����� */
    int hp;                 /* ��q */
    int hp_max;             /* ����q */
    int mm;                 /* �k�O */
    int mm_max;             /* ���k�O */
    time_t cbirth;          /* ��ڭp��Ϊ��ͤ� */
    int pad[2];             /* �d�ۥH��� */
} chicken_t;

#define IDLEN      12             /* Length of bid/uid */
#define PASSLEN    14             /* Length of encrypted passwd field */
#define REGLEN     38             /* Length of registration data */

typedef struct userec_t {
    char userid[IDLEN + 1];
    char realname[20];
    char username[24];
    char passwd[PASSLEN];
    unsigned char uflag;
    unsigned int userlevel;
    unsigned short numlogins;
    unsigned short numposts;
    time_t firstlogin;
    time_t lastlogin;
    char lasthost[16];
    signed long money;
    char remoteuser[3];           /* �O�d �ثe�S�Ψ쪺 */
    char proverb;
    char email[50];
    char address[50];
    char justify[REGLEN + 1];
    unsigned char month;
    unsigned char day;
    unsigned char year;
    unsigned char sex;
    unsigned char state;
    unsigned char pager;
    unsigned char invisible;
    unsigned int  exmailbox;
    chicken_t mychicken;
    time_t lastsong;
    unsigned int  loginview;
    unsigned char channel;        /* �ʺA�ݪO */
    unsigned short vl_count;      /* ViolateLaw counter */
    unsigned short five_win;
    unsigned short five_lose;
    unsigned short five_tie;
    unsigned short chc_win;
    unsigned short chc_lose;
    unsigned short chc_tie;
    char pad[95];
} userec_t;
/* these are flags in userec_t.uflag */
#define SIG_FLAG        0x3     /* signature number, 2 bits */
#define PAGER_FLAG      0x4     /* true if pager was OFF last session */
#define CLOAK_FLAG      0x8     /* true if cloak was ON last session */
#define FRIEND_FLAG     0x10    /* true if show friends only */
#define BRDSORT_FLAG    0x20    /* true if the boards sorted alphabetical */
#define MOVIE_FLAG      0x40    /* true if show movie */
#define COLOR_FLAG      0x80    /* true if the color mode open */
#define MIND_FLAG       0x100   /* true if mind search mode open <-Heat*/

#define BTLEN      48             /* Length of board title */

typedef struct boardheader_t {
    char brdname[IDLEN + 1];             /* bid */
    char title[BTLEN + 1];
    char BM[IDLEN * 3 + 3];              /* BMs' uid, token '/' */
    unsigned int brdattr;                /* board���ݩ� */
    char pad[3];                         /* �S�Ψ쪺 */
    time_t bupdate;                      /* note update time */
    char pad2[3];                        /* �S�Ψ쪺 */
    unsigned char bvote;                 /* Vote flags */
    time_t vtime;                        /* Vote close time */
    unsigned int level;                  /* �i�H�ݦ��O���v�� */
    int uid;                             /* �ݪO�����O ID */
    int gid;                             /* �ݪO���ݪ����O ID */
    char pad3[120];
} boardheader_t;

#define BRD_NOZAP             00001         /* ���izap  */
#define BRD_NOCOUNT           00002         /* ���C�J�έp */
#define BRD_NOTRAN            00004         /* ����H */
#define BRD_GROUPBOARD        00010         /* �s�ժO */
#define BRD_HIDE              00020         /* ���êO (�ݪO�n�ͤ~�i��) */
#define BRD_POSTMASK          00040         /* ����o���ξ\Ū */
#define BRD_ANONYMOUS         00100         /* �ΦW�O? */
#define BRD_DEFAULTANONYMOUS  00200         /* �w�]�ΦW�O */
#define BRD_BAD		      00400         /* �H�k��i���ݪO */
#define BRD_VOTEBOARD         01000	    /* �s�p���ݪO */

#define TTLEN      64             /* Length of title */
#define FNLEN      33             /* Length of filename  */

typedef struct fileheader_t {
    char filename[FNLEN];         /* M.9876543210.A */
    char savemode;                /* file save mode */
    char owner[IDLEN + 2];        /* uid[.] */
    char date[6];                 /* [02/02] or space(5) */
    char title[TTLEN + 1];
    unsigned int  money;
    unsigned char filemode;       /* must be last field @ boards.c */
} fileheader_t;

#define FILE_LOCAL      0x1     /* local saved */
#define FILE_READ       0x1     /* already read : mail only */
#define FILE_MARKED     0x2     /* opus: 0x8 */
#define FILE_DIGEST     0x4     /* digest */
#define FILE_TAGED      0x8     /* taged */
#define FILE_SOLVED	0x10	/* problem solved, sysop only */

#define STRLEN     80             /* Length of most string data */


/* uhash is a userid->uid hash table -- jochang */

#define HASH_BITS 16
typedef struct uhash_t {
    char userid[MAX_USERS][IDLEN + 1];
    int next_in_hash[MAX_USERS];
    int hash_head[1 << HASH_BITS];
    int number;				/* # of users total */
    int loaded;				/* .PASSWD has been loaded? */
} uhash_t;

union xitem_t {
    struct {                    /* bbs_item */
	char fdate[9];          /* [mm/dd/yy] */
	char editor[13];        /* user ID */
	char fname[31];
    } B;
    struct {                    /* gopher_item */
	char path[81];
	char server[48];
	int port;
    } G;
};

typedef struct {
    char title[63];
    union xitem_t X;
} item_t;

typedef struct {
    item_t *item[MAX_ITEMS];
    char mtitle[STRLEN];
    char *path;
    int num, page, now, level;
} gmenu_t;

typedef struct msgque_t {
    pid_t last_pid;
    char last_userid[IDLEN + 1];
    char last_call_in[80];
} msgque_t;

#define FAVMAX     74		  /* Max boards of Myfavorite */
#define FAVGMAX    16             /* Max groups of Myfavorite */
#define FAVGSLEN    8		  /* Max Length of Description String */

typedef struct userinfo_t {
    int uid;                      /* Used to find user name in passwd file */
    pid_t pid;                    /* kill() to notify user of talk request */
    int sockaddr;                 /* ... */
    int destuid;                  /* talk uses this to identify who called */
    struct userinfo_t *destuip;
    unsigned char active;         /* When allocated this field is true */
    unsigned char invisible;      /* Used by cloaking function in Xyz menu */
    unsigned char sockactive;     /* Used to coordinate talk requests */
    unsigned int userlevel;
    unsigned char mode;           /* UL/DL, Talk Mode, Chat Mode, ... */
    unsigned char pager;          /* pager toggle, YEA, or NA */
    unsigned char in_chat;        /* for in_chat commands   */
    unsigned char sig;            /* signal type */
    char userid[IDLEN + 1];
    char chatid[11];              /* chat id, if in chat mode */
    char realname[20];
    char username[24];
    char from[27];                /* machine name the user called in from */
    int from_alias;
    char birth;                   /* �O�_�O�ͤ� Ptt*/
    char tty[11];                 /* tty port */
    int friend[MAX_FRIEND];
    int reject[MAX_REJECT];
    unsigned char msgcount;
    msgque_t msgs[MAX_MSGS];
    time_t uptime;
    time_t lastact;               /* �W���ϥΪ̰ʪ��ɶ� */
    unsigned int  brc_id;
    unsigned char lockmode;       /* ���� multi_login �����F�� */
    char turn;                    /* for gomo */
    char mateid[IDLEN + 1];       /* for gomo */
    unsigned short int five_win;
    unsigned short int five_lose;
    unsigned short int five_tie;
    int myfavorite[FAVMAX];
    char gfavorite[FAVGMAX][FAVGSLEN+1];
    int ninGroup[FAVGMAX];
    int nGroup;
    int ninRoot;
    char pad[344];
    char color;
    int mind;
} userinfo_t;

typedef struct {
    fileheader_t *header;
    char mtitle[STRLEN];
    char *path;
    int num, page, now, level;
} menu_t;

typedef struct onekey_t {     /* Used to pass commands to the readmenu */
    int key;
    int (*fptr)();
} onekey_t;

#define ANSILINELEN (511)                /* Maximum Screen width in chars */

/* anti_crosspost */
typedef struct crosspost_t {
    int checksum[4]; /* 0 -> 'X' cross post  1-3 -> ²�d�峹�� */
    int times;       /* �ĴX�� */
} crosspost_t;

typedef struct bcache_t {
    boardheader_t bcache[MAX_BOARD];
    unsigned int total[MAX_BOARD];
    time_t lastposttime[MAX_BOARD];
    time_t uptime;
    time_t touchtime;
    int number;
    int busystate;
} bcache_t;

typedef struct keeploc_t {
    char *key;
    int top_ln;
    int crs_ln;
    struct keeploc_t *next;
} keeploc_t;

#define USHM_SIZE       (MAX_ACTIVE + 4)

struct utmpfile_t {
    userinfo_t uinfo[USHM_SIZE];
    time_t uptime;
    int number;
    int busystate;
};

struct pttcache_t {
    char notes[MAX_MOVIE][200*11];
    char today_is[20];
    int n_notes[MAX_MOVIE_SECTION];          /* �@�`�����X�� �ݪO */
    int next_refresh[MAX_MOVIE_SECTION];     /* �U�@���nrefresh�� �ݪO */
    int max_film;
    int max_history;
    time_t uptime;
    time_t touchtime;
    int busystate;
};

typedef struct fromcache_t {
    char domain[MAX_FROM][50];
    char replace[MAX_FROM][50];
    int top;
    int max_user;
    time_t max_time;
    time_t uptime;
    time_t touchtime;
    int busystate;
} fromcache_t;

typedef struct {
    unsigned char oldlen;                /* previous line length */
    unsigned char len;                   /* current length of line */
    unsigned char mode;                  /* status of line, as far as update */
    unsigned char smod;                  /* start of modified data */
    unsigned char emod;                  /* end of modified data */
    unsigned char sso;                   /* start stand out */
    unsigned char eso;                   /* end stand out */
    unsigned char data[ANSILINELEN + 1];
} screenline_t;

typedef struct {
    int r, c;
} rc_t;

#define BRD_ROW           10
#define BRD_COL           9

typedef int board_t[BRD_ROW][BRD_COL];

/* name.c ���B�Ϊ���Ƶ��c */
typedef struct word_t {
    char *word;
    struct word_t *next;
} word_t;

typedef struct commands_t {
    int (*cmdfunc)();
    int level;
    char *desc;                   /* next/key/description */
} commands_t;

typedef struct MailQueue {
    char filepath[FNLEN];
    char subject[STRLEN];
    time_t mailtime;
    char sender[IDLEN + 1];
    char username[24];
    char rcpt[50];
    int method;
    char * niamod;
} MailQueue;

enum  {MQ_TEXT, MQ_UUENCODE, MQ_JUSTIFY};

#endif
