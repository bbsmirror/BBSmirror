/*-------------------------------------------------------*/
/* global.h     ( Rex BBS 1.0 )                          */
/*-------------------------------------------------------*/
/* Target : global definitions & variables               */
/* Create : 99/11/27                                     */
/* Update : 99/11/27                                     */
/*-------------------------------------------------------*/

#define	ULONG	unsigned long
#define		BLK_SIZE	4096
#define		MAXPAGES	256
#define		F_MODE		0x01
#define		F_SIZE		0x02
#define		F_TIME		0x04
#define		FILE_OW		O_TRUNC
#define		FILE_CW		O_EXCL
#define		FILE_CAT	O_APPEND

#define		DIR_FILE	".DIR"

#define		NNTP_OUT_BATCH	"nntp.out"
#define		NNTP_OUTING	"nntp.outing"


#define		CONF_MSG_LEN	256
#define		HOSTLEN		64
#define		IDLEN		16
#define		IPLEN		32
#define		PASSLEN		16
#define		NIDLEN		20
#define		MAILLEN		64
#define		ADDRLEN		64
#define		PATHLEN		128
#define		DATELEN		40
#define		STRLEN		256
#define		TITLELEN	128
#define		STITLELEN	40
#define		ANSLEN		4
#define		BMNUM		4
#define		MSGLEN		50
#define		MSGIDLEN	128
#define		GROUPLEN	128
#define		LINELEN 	256
#define		BNLEN		64
