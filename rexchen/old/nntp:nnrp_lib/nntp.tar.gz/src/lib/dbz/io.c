#include <bbs.h>
#include "dbz.h"

int
SetNonBlocking (int fd, BOOL flag)
{
  int mode;

  mode = fcntl (fd, F_GETFL, 0);
  if (mode < 0)
    return -1;
  mode = (flag ? (mode | O_NONBLOCK) : (mode & ~O_NONBLOCK));
  return fcntl (fd, F_SETFL, mode);
}


void
CloseOnExec (int fd, int flag)
{
  int oerrno;
  int oflag;

  oerrno = errno;
  oflag = fcntl (fd, F_GETFD, 0);
  if (oflag < 0) {
    errno = oerrno;
    return;
  }
  fcntl (fd, F_SETFD, flag ? (oflag | FD_CLOEXEC) : (oflag & ~FD_CLOEXEC));
  errno = oerrno;
}
