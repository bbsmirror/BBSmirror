#include <bbs.h>

off_t
statf (fpath, mode)
char *fpath;
int mode;
{
  struct stat st;
  off_t ans = 0;

  if (stat (fpath, &st))
    return 0;
  switch (mode) {
    case F_MODE:
      ans = st.st_mode;
      break;
    case F_SIZE:
      ans = st.st_size;
      break;
    case F_TIME:
      ans = st.st_mtime;
      break;
  }
  return ans;
}
