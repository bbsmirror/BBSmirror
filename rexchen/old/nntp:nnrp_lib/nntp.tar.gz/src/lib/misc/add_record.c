#include <bbs.h>

int
add_record (fpath, record, size)
char *fpath;
void *record;
int size;
{
  int fd;

  if ((fd = open (fpath, O_WRONLY | O_CREAT | O_APPEND, 0600)) < 0)
    return -1;
  write (fd, record, size);
  close (fd);
  return (size);
}
