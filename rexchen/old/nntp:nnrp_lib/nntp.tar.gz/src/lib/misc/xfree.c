#include <bbs.h>

void *
xfree(pointer)
void *pointer;
{
  if ( pointer != NULL ) {
     free(pointer);
     pointer = NULL;
  }
  return(NULL);
}
