#include "nntp.h"

int
line_count (fpath)
char *fpath;
{
  int num = 0;
  FILE *fp;
  char buf[CONF_MSG_LEN];

  if ((fp = fopen (fpath, "r")) <= 0) {
    return (0);
  }

  while (fgets (buf, sizeof (buf), fp) > 0) {
    if (buf[0] == '#' || buf[0] == ' ' || buf[0] == '\n') {
      continue;
    }
    num++;
  }
  fclose (fp);
  return (num);
}

int
read_server_conf (fpath, ns, num)
char *fpath;
struct server *ns;
int num;
{
  FILE *fp;
  int i = 0;
  char buf[CONF_MSG_LEN];

  if ((fp = fopen (fpath, "r")) == NULL) {
    return (-1);
  }

  while (fgets (buf, sizeof (buf), fp) > 0 && i < num) {
    if (buf[0] == '#' || buf[0] == ' ' || buf[0] == '\n') {
      memset (buf, 0, CONF_MSG_LEN);
      continue;
    }
    strtok (buf, "\r\n");
    sscanf (buf, "%s\t%d\t%s\t%s\t%s", ns[i].host, &(ns[i].port),
      ns[i].userid, ns[i].passwd, ns[i].active);
    i++;
  }
  fclose (fp);
}

int
read_newsfeeds_conf (fpath, nf, num)
char *fpath;
struct newsfeeds *nf;
int num;
{
  FILE *fp;
  int i = 0;
  char buf[CONF_MSG_LEN];

  if ((fp = fopen (fpath, "r")) == NULL) {
    return (-1);
  }

  while (fgets (buf, sizeof (buf), fp) > 0 && i < num) {
    if (buf[0] == '#' || buf[0] == ' ' || buf[0] == '\n') {
      memset (buf, 0, CONF_MSG_LEN);
      continue;
    }
    strtok (buf, "\r\n");
    sscanf (buf, "%s\t%s\t%s", nf[i].group, nf[i].board, nf[i].host);
    i++;
  }
  fclose (fp);
}

int
read_batch (fpath, bf, num)
char *fpath;
struct out_batch *bf;
int num;
{
  FILE *fp;
  int i = 0;
  char buf[CONF_MSG_LEN];

  if ((fp = fopen (fpath, "r")) == NULL) {
    return (-1);
  }

  while (fgets (buf, sizeof (buf), fp) > 0 && i < num) {
    if (buf[0] == '#' || buf[0] == ' ' || buf[0] == '\n') {
      memset (buf, 0, CONF_MSG_LEN);
      continue;
    }
    strtok (buf, "\r\n");
    sscanf (buf, "%s\t%s\t%s", bf[i].board, bf[i].fpath, bf[i].msgid);
    i++;
  }
  fclose (fp);
}

int
fill_group (bf, nf, feeds_num)
struct out_batch *bf;
struct newsfeeds *nf;
int feeds_num;
{
  int i = 0;

  for (i = 0; i < feeds_num; i++) {
    if (strncmp (nf[i].board, bf->board, BNLEN) == 0) {
      strncpy (bf->group, nf[i].group, GROUPLEN);
      strncpy (bf->host, nf[i].host, HOSTLEN);
      return (1);
    }
  }
  return (-1);
}

int
fill_board (af, nf, group, feeds_num)
struct article *af;
struct newsfeeds *nf;
char *group;
int feeds_num;
{
  int i = 0;

  for (i = 0; i < feeds_num; i++) {
    if (strncmp (nf[i].group, group, GROUPLEN) == 0) {
      strncpy (af->board, nf[i].board, BNLEN);
      return (1);
    }
  }
  return (-1);
}

char *
read_active (fpath, active, num, af)
char *fpath;
char *active;
int num;
struct active *af;
{
  int size = 0;
  int fd = -1;

  size = statf (fpath, F_SIZE);

  if ((fd = open (fpath, O_RDWR)) < 0) {
    return (NULL);
  }
  active = malloc (size + 1);
  memset (active, 0, size + 1);
  if (read (fd, active, size) != size) {
    return (NULL);
  }
  close (fd);
  fill_active (active, af, num, size);
  return (active);
}

int
fill_active (active, af, num, size)
char *active;
struct active *af;
int num;
int size;
{
  int i = 0;
  char *ptr = NULL;
  char *nptr = NULL;
  char *actlistptr = NULL;
  struct active *rcptr;

  for (ptr = active; i < num && ptr < (active + size)
    && (actlistptr = strchr (ptr, '\n')) != NULL; ptr = actlistptr + 1) {
    if (*ptr == '\n')
      continue;
    if (*ptr == '#')
      continue;
    rcptr = &(af[i]);
    rcptr->nameptr = NULL;
    rcptr->namelen = 0;
    rcptr->lowptr = NULL;
    rcptr->lowlen = 0;
    rcptr->highptr = NULL;
    rcptr->highlen = 0;
    rcptr->modeptr = NULL;
    rcptr->low = 0;
    rcptr->high = 0;
    rcptr->mode = 'y';
    for (nptr = ptr; *nptr && isspace (*nptr);)
      nptr++;
    if (nptr == actlistptr)
      continue;
    rcptr->nameptr = nptr;
    for (nptr++; *nptr && !isspace (*nptr);)
      nptr++;
    rcptr->namelen = (int) (nptr - rcptr->nameptr);
    if (nptr == actlistptr)
      continue;
    for (nptr++; *nptr && isspace (*nptr);)
      nptr++;
    if (nptr == actlistptr)
      continue;
    rcptr->highptr = nptr;
    rcptr->high = atol (nptr);
    for (nptr++; *nptr && !isspace (*nptr);)
      nptr++;
    rcptr->highlen = (int) (nptr - rcptr->highptr);
    if (nptr == actlistptr)
      continue;
    for (nptr++; *nptr && isspace (*nptr);)
      nptr++;
    if (nptr == actlistptr)
      continue;
    rcptr->lowptr = nptr;
    rcptr->low = atol (nptr);
    for (nptr++; *nptr && !isspace (*nptr);)
      nptr++;
    rcptr->lowlen = (int) (nptr - rcptr->lowptr);
    i++;
    if (nptr == actlistptr) {
      continue;
    }
    for (nptr++; *nptr && isspace (*nptr);)
      nptr++;
    if (nptr == actlistptr) {
      continue;
    }
    rcptr->mode = *nptr;
    rcptr->modeptr = nptr;
  }
}

int
updateactive (actptr, len, value)
char *actptr;
int len;
ULONG value;
{
  for (actptr += len - 1; len-- > 0;) {
    *actptr-- = value % 10 + '0';
    value /= 10;
  }
}

int
write_active (fpath, active)
char *fpath;
char *active;
{
  FILE *fp;
  char backup[PATHLEN];

  sprintf (backup, "%s.old", fpath);
  rename (fpath, backup);

  fp = fopen (fpath, "w");
  if (fp != NULL) {
    fprintf (fp, "%s", active);
    fclose (fp);
  } else {
    rename (backup, fpath);
  }
}
