#include "nntp.h"

main ()
{
  char hispath[PATHLEN] = HISTORY_FILE;

  mkhistory (hispath);
}
