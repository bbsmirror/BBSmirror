#include <bbs.h>

#define BBS_HOME		"/home/rexchen/src"
#define CONF_NEWSFEEDS_FILE	"newsfeeds.conf"
#define	CONF_SERVER_FILE	"server.conf"
#define NNTP_BACKUP		"nntp.out.bak"
#define EXPIRE_LIST		"cancel.list"
#define HISTORY_FILE		"/home/rexchen/src/lib/nntp/history"
#define	CONF_DIR		"/home/rexchen/src/lib/nntp"

#define HISTOEY_EXPIRE_TIME	(3*24*60*60)
#define	HISTORY_SIZE		100000
#define NEWS_BSIZE		256
#define NNTP_RESET		255
#define NNTP_OK			0
#define NNTP_GET		1
#define NNTP_SEND		2
#define NNTP_IHAVE_OK		3
#define NNTP_IHAVE_BADMID	4
#define NNTP_POST_OK		5
#define NNTP_POST_ERR		6
#define NNTP_ERROR		7
#define NNTP_NOPOST		8
#define NNTP_MODE		9
#define NNRP_MODE		10
#define NNTP_IHAVE_NOPERM	11
#define NNTP_IHAVE_ERR		12
#define NNTP_GROUP_OK		13
#define NNTP_GROUP_ERR		14
#define NNTP_XHDR_OK		15
#define NNTP_XHDR_END		16
#define NNTP_ART_OK		17
#define NNTP_ART_ERR		18
#define DOWN            	-8
#define SHIT            	-6
#define MAX_STATS		1000
#define	MAX_ARTS		500

/* socket define */
#define SOCK_ERROR -1
#define SOCK_NOEXIST    -2
#define SOCK_NORESPOND -3


struct nntp_opt {
  char host[HOSTLEN];
  char userid[IDLEN];
  char passwd[PASSLEN];
  char conf_dir[PATHLEN];
  char active[PATHLEN];
  int port;
  int logfd;
  int flag;
  FILE *history;
};

struct article {
  int num;
  char board[BNLEN];
  char msgid[MSGIDLEN];
};

struct newsfeeds {
  char group[GROUPLEN];
  char board[BNLEN];
  char host[HOSTLEN];
  int port;
};

struct out_batch {
  FILE *fp;
  char board[BNLEN];
  char group[GROUPLEN];
  char fpath[PATHLEN];
  char msgid[MSGIDLEN];
  char host[HOSTLEN];
};

struct server {
  char host[HOSTLEN];
  char userid[IDLEN];
  char passwd[PASSLEN];
  char active[PATHLEN];
  int port;
};

struct active {
  char *nameptr, *lowptr, *highptr, *modeptr;
  int namelen, lowlen, highlen;
  ULONG low, high;
  int mode, subscribe;
};
