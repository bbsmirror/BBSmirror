#include "nntp.h"

int
news_fetch (userid, passwd, host, port, conf_dir, active, logfd, hispath,
  flag)
char *userid;
char *passwd;
char *host;
int port;
char *conf_dir;
char *active;
int logfd;
char *hispath;
int flag;
{
  struct nntp_opt options;

  strncpy (options.userid, userid, IDLEN);
  strncpy (options.passwd, passwd, PASSLEN);
  strncpy (options.host, host, HOSTLEN);
  strncpy (options.conf_dir, conf_dir, PATHLEN);
  sprintf (options.active, "%s/%s", conf_dir, active);
  options.port = port;
  options.flag = flag;
  options.logfd = logfd;
  if (!dashf (hispath)) {
    makedbz (hispath, HISTORY_SIZE);
  }
  if ((options.history = fopen (hispath, "a+")) >= 0) {
    dbminit (hispath);
    nntp (&options);
    dbmclose ();
  }
  fclose (options.history);
  mkhistory (hispath);
}

main ()
{
  int logfd;
  int server_num = 0;
  int i = 0;
  char hispath[PATHLEN] = HISTORY_FILE;
  char spath[PATHLEN] = { 0 };
  struct server *s_list = NULL;

  sprintf (spath, "%s/%s", CONF_DIR, CONF_SERVER_FILE);
  server_num = line_count (spath);
  if (server_num < 1) {
    printf ("no server define in server.conf\n");
    exit (0);
  }
  s_list = calloc (sizeof (struct server), server_num);
  read_server_conf (spath, s_list, server_num);
  logfd = log_open ("nntp.log");
  for (i = 0; i < server_num; i++) {
    news_fetch (s_list[i].userid, s_list[i].passwd, s_list[i].host,
      s_list[i].port, CONF_DIR, s_list[i].active, logfd, hispath, NNTP_GET);
  }
  log_close (logfd);
  (void *) s_list = xfree (s_list);
}
