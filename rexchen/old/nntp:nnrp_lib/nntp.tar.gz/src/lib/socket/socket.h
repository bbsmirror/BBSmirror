#include <bbs.h>

/* socket define */
#define SOCK_ERROR -1
#define SOCK_NOEXIST    -2
#define SOCK_NORESPOND -3
