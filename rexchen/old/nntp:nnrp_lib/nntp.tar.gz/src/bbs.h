#define _REENTRANT
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/telnet.h>
#include <sys/resource.h>
#include <stdarg.h>
#include <crypt.h>
#include <errno.h>
#include <signal.h>
#include <poll.h>
#include <locale.h>
#include <nl_types.h>


/*
 * Local Include File
 */

#include <global.h>
#include <struct.h>
