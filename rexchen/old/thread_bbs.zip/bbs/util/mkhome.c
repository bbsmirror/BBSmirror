#include <bbs.h>

main()
{
  char root;
  int i;
  char home[256];

  for ( i=0 ; i < 100 ; i++ ) {
      sprintf(home,"home/%02d",i);
      mkdir(home,0750);
  }
  for ( i=0 ; i < 100 ; i++ ) {
      sprintf(home,"mail/%02d",i);
      mkdir(home,0750);
  }
  for ( i=0 ; i < 100 ; i++ ) {
      sprintf(home,"boards/%02d",i);
      mkdir(home,0750);
  }
}
