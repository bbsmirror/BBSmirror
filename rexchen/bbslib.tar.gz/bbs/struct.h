
struct dirhead {
  char fname[PATHLEN];
  char owner[IDLEN];
  char mail[MAILLEN];
  char nick[NIDLEN];
  char date[DATELEN];
  char title[TITLELEN];
  char bname[BNLEN];
  char msgid[MSGIDLEN];
  time_t time;
  int level;
  int mark;
  int port;
  int mode;
};

struct account {
  char userid[IDLEN];
  char passwd[PASSLEN];
  int logins;
  int posts;
  unsigned int level;
  unsigned int define;
};

