#ifdef WIN32
#define _NL_TYPES_H_
#include <sys/cdefs.h>

#define	NL_SETD		0
#define	NL_CAT_LOCALE	1

typedef	int	nl_item;
typedef	void	*nl_catd;

extern nl_catd 	catopen __P((__const char *, int));
extern char    *catgets	__P((nl_catd, int, int,	__const	char *));
extern int	catclose __P((nl_catd));
#endif
