/*
 *  thread bbs smtp daemon by: rexchen@ug.ee.tku.edu.tw
 */

#define	MAX_SMTPD_CLIENT	64
#define SMTPD_TIMEOUT		60
#define RCVBUFSIZ		512
#define SMTPD_BYE_MSG    	"221 BBS SMTP server sign off.\r\n"
#define	SMTPD_DAEMON_OK		"220 BBS SMTP server ready.\r\n"
#define SMTPD_NOOP_OK		"250 Noop ok.\r\n"
#define SMTPD_NOUSER_ERR	"550 No such user.\r\n"
#define SMTPD_ERRCMD_MSG 	"500 Command unrecognized.\r\n"
#define SMTPD_HELO_MSG		"250 Hello, glad to meet you.\r\n"
#define SMTPD_MAIL_NULLDOMAIN	"550 Null domain.\r\n"
#define SMTPD_MAIL_HAVESENDER	"503 Sender already specified.\r\n"
#define	SMTPD_RCPT_NEEDMAIL	"503 Need MAIL command.\r\n"
#define	SMTPD_RCPT_MORERCPT	"552 Too many recipients.\r\n"
#define	SMTPD_RSET_OK		"250 Reset state.\r\n"
#define	SMTPD_DATA_NEEDRCPT	"503 Need RCPT (recipient).\r\n"
#define	SMTPD_DATA_NOTMP	"552 Cannot allocate temporory space.\r\n"
#define	SMTPD_DATA_ENTERMAIL	"354 Enter mail, end with \".\" on a line by itself.\r\n"
#define	SMTPD_DATA_ACCEPT	"250 Message accepted for delivery.\r\n"
#define	SMTPD_HELP_MSG		"\
214-Commands:\r\n\
214-    HELO    MAIL    RCPT    DATA\r\n\
214-    NOOP    QUIT    RSET    HELP\r\n\
214-See RFC-821 for more info.\r\n\
214 End of HELP info\r\n"

#define	CM_RSET		0
#define CM_MAIL         1
#define CM_RCPT		2
#define TYPE_TEXT       0
#define TYPE_HTML       1
#define TYPE_MIME       2
#define KW_FROM         1
#define KW_RECV         2
#define KW_BY           3
#define KW_MSGID        4
#define KW_TO           5
#define KW_2FROM        6
#define KW_SUBJ         7
#define KW_DATE         8
#define KW_LENG         9
#define KW_ENCODE       10
#define KW_MIME         11
#define KW_CTYPE        12

extern int smtpd_cmd_rset();
extern int smtpd_cmd_data();
extern int smtpd_cmd_helo();
extern int smtpd_cmd_mail();
extern int smtpd_cmd_rcpt();
extern int smtpd_cmd_quit();
extern int smtpd_cmd_noop();
extern int smtpd_cmd_help();
extern int smtpd_cmd_xxxx();

struct smtpdcmd {
  char *cmd;
  int (*fun) ();
};

struct smtpdcmd smtpdcmdlist[] = {
  "quit", smtpd_cmd_quit,
  "rset", smtpd_cmd_rset,
  "data", smtpd_cmd_data,
  "helo", smtpd_cmd_helo,
  "rcpt", smtpd_cmd_rcpt,
  "mail", smtpd_cmd_mail,
  "help", smtpd_cmd_help,
  "noop", smtpd_cmd_noop,
  NULL,   smtpd_cmd_xxxx
};

struct smtpdcs {
  int sid;
  int sockfd;
  int uid;
  int mode;
  char data[RCVBUFSIZ];
  char ipaddr[IPLEN];
  char sender[IDLEN];
  char sdomain[DOMAINLEN];
  char smail[MAILLEN];
  char snick[NIDLEN];
  char recver[IDLEN];
  char rdomain[DOMAINLEN];
  char rmail[MAILLEN];
  char rnick[NIDLEN];
};
