/*
 *  thread bbs pop3 daemon by: rexchen@ug.ee.tku.edu.tw
 */

#define	MAX_POP3D_CLIENT	64
#define POP3D_TIMEOUT		60
#define RCVBUFSIZ		128
#define POP3D_BYE_MSG    	"+OK POP3 server sign off\r\n"
#define	POP3D_DAEMON_OK		"+OK BBS POP3 server ready\r\n"
#define POP3D_NOOP_OK		"+OK\r\n"
#define POP3D_NOUSER_ERR	"-ERR no such user in our server\r\n"
#define POP3D_ERRCMD_MSG 	"-ERR invalid command\r\n"
#define POP3D_ERRARG_MSG 	"-ERR invalid argument\r\n"
#define POP3D_ERRNUM_MSG 	"-ERR message number out of range\r\n"
#define POP3D_DELETE_MSG 	"-ERR message has been deleted\r\n"
#define	POP3D_NEEDUSER		"-ERR need USER command\r\n"
#define	POP3D_PASSWD_ERR	"-ERR password incorrect\r\n"
#define	POP3D_DELETE_OK		"+OK message deleted\r\n"
#define	POP3D_UIDL_OK		"+OK uidl command accepted.\r\n"
#define CM_LOGIN        1
#define CM_DIRTY        2	/* ���R���H�� */

extern int pop3d_cmd_list ();
extern int pop3d_cmd_uidl ();
extern int pop3d_cmd_retrive ();
extern int pop3d_cmd_delete ();
extern int pop3d_cmd_user ();
extern int pop3d_cmd_passwd ();
extern int pop3d_cmd_stat ();
extern int pop3d_cmd_quit ();
extern int pop3d_cmd_last ();
extern int pop3d_cmd_top ();
extern int pop3d_cmd_reset ();
extern int pop3d_cmd_noop ();
extern int pop3d_cmd_xxxx ();

struct pop3dcmd {
  char *cmd;
  int (*fun) ();
};

struct pop3dcmd pop3dcmdlist[] = {
  "list", pop3d_cmd_list,
  "uidl", pop3d_cmd_uidl,
  "retr", pop3d_cmd_retrive,
  "dele", pop3d_cmd_delete,
  "user", pop3d_cmd_user,
  "pass", pop3d_cmd_passwd,
  "stat", pop3d_cmd_stat,
  "quit", pop3d_cmd_quit,
  "last", pop3d_cmd_last,
  "top", pop3d_cmd_top,
  "rset", pop3d_cmd_reset,
  "noop", pop3d_cmd_noop,
  NULL, pop3d_cmd_xxxx
};

struct pop3cs {
  int sid;
  int sockfd;
  int uid;
  int mode;
  int pcount;
  int pbytes;
  char *trail_token;
  char userid[IDLEN];
  char passwd[PASSLEN];
  char ipaddr[IPLEN];
  struct dirhead *cache;
};
