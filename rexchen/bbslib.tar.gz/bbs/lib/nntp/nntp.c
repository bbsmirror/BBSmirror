/*
 *  nntp write by rexchen@ug.ee.tku.edu.tw
 */

#include "nntp.h"

int
backup_batch (fpath, bf)
char *fpath;
struct out_batch *bf;
{
  FILE *fp;

  if ((fp = fopen (fpath, "a")) <= 0) {
    return (0);
  }
  fprintf (fp, "%s\t%s\t%s\n", bf->board, bf->fpath, bf->msgid);
  fclose (fp);
}

int
nntp_quit (sockfd)
int sockfd;
{
  if (writeln (sockfd, "QUIT\r\n"))
    return 1;
  else
    return 0;
}


int
get_reply (sockfd, buf)
int sockfd;
char *buf;
{
  int rpy;
  char num[4] = { 0 };
  int status = 0;

  if (!readsock (sockfd, buf, NEWS_BSIZE)) {
#ifdef DEBUG
    printf ("buf is %s\n", buf);
#endif

    strncpy (num, buf, 3);
    status = atoi (num);
    switch (status) {
      case 200:
	rpy = NNTP_OK;
	break;
      case 201:
	rpy = NNTP_NOPOST;
	break;
      case 211:
	rpy = NNTP_GROUP_OK;
	break;
      case 220:
	rpy = NNTP_ART_OK;
	break;
      case 221:
	rpy = NNTP_XHDR_OK;
	break;
      case 411:
	rpy = NNTP_GROUP_ERR;
	break;
      case 335:
	rpy = NNTP_IHAVE_OK;
	break;
      case 435:
	rpy = NNTP_IHAVE_BADMID;
	break;
      case 340:
	rpy = NNTP_POST_OK;
	break;
      case 423:
	rpy = NNTP_ART_ERR;
	break;
      case 441:
	rpy = NNTP_POST_ERR;
	break;
      case 480:
	rpy = NNTP_IHAVE_NOPERM;
	break;
      case 500:
	rpy = NNTP_MODE;
	break;
      case 501:
	rpy = NNRP_MODE;
	break;
      default:
	rpy = DOWN;
	break;
    }
  }
  return rpy;
}

int
post_article (sockfd, options, out)
int sockfd;
struct nntp_opt *options;
struct out_batch *out;
{
  FILE *fp;
  char buf[NEWS_BSIZE];
  char fpath[PATHLEN];

  sprintf (fpath, "%s/%s", BBS_HOME, out->fpath);
  if ((fp = fopen (fpath, "r")) == NULL) {
    sockprintf (sockfd, "\r\n.\r\n");
    return (get_reply (sockfd, buf));
  }
  while (fgets (buf, sizeof (buf), fp) != NULL) {
    strtok (buf, "\r\n");
    if (strncmp (buf, "Newsgroups: ", 12) == 0) {
      sockprintf (sockfd, "Newsgroups: %s\r\n", out->group);
      continue;
    }
    writeln (sockfd, buf);
    writeln (sockfd, "\r\n");
  }
  fclose (fp);
  add_his (options->history, out->msgid, 0, out->fpath);
  sockprintf (sockfd, "\r\n.\r\n");
  return (get_reply (sockfd, buf));
}

int
nnrp_post (sockfd, options, out)
int sockfd;
struct nntp_opt *options;
struct out_batch *out;
{
  int status;
  char buf[NEWS_BSIZE];

  sockprintf (sockfd, "POST\r\n");
  status = get_reply (sockfd, buf);

  if (status == NNTP_POST_OK) {
    return (post_article (sockfd, options, out));
  } else {
    log_text (options->logfd, "NNTP POST ERROR");
    return (-1);
  }
}

int
nntp_ihave (sockfd, options, out)
int sockfd;
struct nntp_opt *options;
struct out_batch *out;
{
  int status;
  char buf[NEWS_BSIZE];

  sockprintf (sockfd, "IHAVE %s\r\n", out->msgid);
  status = get_reply (sockfd, buf);
  if (status == NNTP_IHAVE_OK) {
    return (post_article (sockfd, options, out));
  } else {
    log_text (options->logfd, "NNTP IHAVE ERROR");
    return (-1);
  }
}

int
nntp_or_nnrp (sockfd, buf)
int sockfd;
char *buf;
{
  int rpy;

  writeln (sockfd, "MODE\r\n");
  rpy = get_reply (sockfd, buf);
  if (rpy == NNRP_MODE) {
    return (NNRP_MODE);
  }
  if (rpy == NNTP_MODE) {
    writeln (sockfd, "IHAVE\r\n");
    rpy = get_reply (sockfd, buf);
    if (rpy == NNTP_IHAVE_BADMID) {
      return (NNTP_MODE);
    }
  }
  writeln (sockfd, "MODE READER\r\n");
  get_reply (sockfd, buf);
  return (NNRP_MODE);
}

int
nnrp_mode (sockfd, buf)
int sockfd;
char *buf;
{
  writeln (sockfd, "MODE READER\r\n");
  return (get_reply (sockfd, buf));
}


int
nntp (options)
struct nntp_opt *options;
{
  int rpy = 0;
  int sockfd = -1;
  int feeds_num = 0;
  int b_num = 0;
  int a_num = 0;
  int i = 0;
  time_t now;
  struct newsfeeds *f_list = NULL;
  struct out_batch *b_list = NULL;
  struct active *a_list = NULL;
  char *active = NULL;
  char fname[PATHLEN];
  char fname2[PATHLEN];
  char buf[NEWS_BSIZE];

  if ((sockfd = get_connect (options->host, options->port)) < 0) {
    if (sockfd == SOCK_NOEXIST)
      log_text (options->logfd, "[-Error-] %s does not exist.",
	options->host);
    else
      log_text (options->logfd, "[-Error-] %s is not responding at %s",
	options->host, ctime (&now));
    return DOWN;
  }
  if ((rpy = get_reply (sockfd, buf))) {
    log_text (options->logfd,
      "[-Error-] Problem with host %s. Server closed connection.",
      options->host);
    close (sockfd);
    return rpy;
  }

  sprintf (fname, "%s/%s", options->conf_dir, CONF_NEWSFEEDS_FILE);
  feeds_num = line_count (fname);
  f_list = calloc (sizeof (struct newsfeeds), feeds_num);
  read_newsfeeds_conf (fname, f_list, feeds_num);

  //nnrp_mode(sockfd,buf);

  if (options->flag == NNTP_GET || options->flag == NNTP_RESET) {
    a_num = line_count (options->active);
    if (a_num < 1) {
      log_text (options->logfd, "No Active File");
      if ((rpy = nntp_quit (sockfd)))
	close (sockfd);
      (void *) f_list = xfree (f_list);
      return (0);
    }
    a_list = calloc (sizeof (struct active), a_num);
    active = (char *) read_active (options->active, active, a_num, a_list);
    if (active == NULL) {
      log_text (options->logfd, "Active File Load Error");
      if ((rpy = nntp_quit (sockfd)))
	close (sockfd);
      (void *) f_list = xfree (f_list);
      (void *) a_list = xfree (a_list);
      return (0);
    }
    nnrp_mode (sockfd, buf);
    for (i = 0; i < a_num; i++) {
      nnrp_get (sockfd, options, &(a_list[i]), f_list, feeds_num);
    }
    write_active (options->active, active);
    (void *) active = xfree (active);
  } else {
    if (nntp_or_nnrp (sockfd, buf) == NNTP_MODE) {
      sprintf (fname, "%s/%s", options->conf_dir, NNTP_OUTING);
      b_num = line_count (fname);
      if (b_num < 1) {
	log_text (options->logfd, "No outgoing file");
	if ((rpy = nntp_quit (sockfd)))
	  close (sockfd);
	(void *) f_list = xfree (f_list);
	return (0);
      }
      b_list = calloc (sizeof (struct out_batch), b_num);
      read_batch (fname, b_list, b_num);
      for (i = 0; i < b_num; i++) {
	if (fill_group (&(b_list[i]), f_list, feeds_num) != -1) {
	  if (strncmp (options->host, b_list[i].host, HOSTLEN) == 0) {
	    nntp_ihave (sockfd, options, &(b_list[i]));
	  } else {
	    sprintf (fname, "%s/%s", options->conf_dir, NNTP_BACKUP);
	    backup_batch (fname, &(b_list[i]));
	  }
	} else {
	  sprintf (fname, "%s/%s", options->conf_dir, NNTP_BACKUP);
	  backup_batch (fname, &(b_list[i]));
	}
	log_text (options->logfd, "nntp mode");
      }
    } else {
      for (i = 0; i < b_num; i++) {
	if (fill_group (&(b_list[i]), f_list, feeds_num) != -1) {
	  if (strncmp (options->host, b_list[i].host, HOSTLEN) == 0) {
	    nnrp_post (sockfd, options, &(b_list[i]));
	  } else {
	    sprintf (fname, "%s/%s", options->conf_dir, NNTP_BACKUP);
	    backup_batch (fname, &(b_list[i]));
	  }
	} else {
	  sprintf (fname, "%s/%s", options->conf_dir, NNTP_BACKUP);
	  backup_batch (fname, &(b_list[i]));
	}
	log_text (options->logfd, "nnrp mode");
      }
    }
  }
  (void *) b_list = xfree (b_list);
  (void *) f_list = xfree (f_list);

  if ((rpy = nntp_quit (sockfd)))
    log_text (options->logfd, "[-Error-] Disconnecting.");
  close (sockfd);
  sprintf (fname, "%s/%s", options->conf_dir, NNTP_BACKUP);
  sprintf (fname2, "%s/%s", options->conf_dir, NNTP_OUTING);
  unlink (fname2);
  rename (fname, fname2);
  return 0;
}
