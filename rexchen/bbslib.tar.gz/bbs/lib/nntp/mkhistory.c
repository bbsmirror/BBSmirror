/*
 *  mkhistory write by rexchen@ug.ee.tku.edu.tw
 */

#include "nntp.h"

main ()
{
  char hispath[PATHLEN] = HISTORY_FILE;

  mkhistory (hispath);
}
