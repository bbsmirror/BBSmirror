/*
 *  his.c write by rexchen@ug.ee.tku.edu.tw
 */

#include "nntp.h"
#include "../dbz/dbz.h"

int
query_his (fp, msgid, path)
FILE *fp;
char *msgid;
char *path;
{
  HASH key;
  long where;
  char buf[NEWS_BSIZE] = { 0 };

  MD5 (msgid, strlen (msgid), key.hash);

  where = dbzfetch (key);
  if (where == NOTFOUND) {
    return (0);
  }
  fseek (fp, where, SEEK_SET);
  fgets (buf, sizeof (buf), fp);
  strncpy (path, buf, NEWS_BSIZE);
  return (1);
}

int
add_his (fp, msgid, now, path)
FILE *fp;
char *msgid;
time_t now;
char *path;
{
  HASH key;
  long where;

  if (query_his (fp, msgid, path) == 0) {
    MD5 (msgid, strlen (msgid), key.hash);
    if (now == 0)
      now = time (NULL);
    fseek (fp, where, SEEK_END);
    fprintf (fp, "%s\t%d\t%s\n", msgid, now, path);
    if (dbzstore (key, where) < 0) {
      return (0);
    }
    return (1);
  } else {
    return (0);
  }
}

int
makedbz (hispath, entry)
char *hispath;
long entry;
{
  long size;

  size = dbzsize (entry);
  dbzfresh (hispath, size, 0);
  dbmclose ();
}

int
mkhistory (hispath)
char *hispath;
{
  FILE *fp, *fr;
  time_t date, now;
  char buf[NEWS_BSIZE];
  char msgid[MSGIDLEN];
  char path[PATHLEN];
  char fpath[PATHLEN];
  char src[PATHLEN];
  char dst[PATHLEN];

  now = time (NULL);
  fr = fopen (hispath, "r");
  if (fr == NULL)
    return (-1);
  sprintf (fpath, "%s%s", hispath, ".n");
  if (!dashf (fpath)) {
    makedbz (fpath, HISTORY_SIZE);
  }
  fp = fopen (fpath, "a");
  if (fp != NULL) {
    dbminit (fpath);
    while (fgets (buf, sizeof (buf), fr) != NULL) {
      strtok (buf, "\r\n");
      sscanf (buf, "%s %d %s", msgid, &date, path);
      if (date + HISTOEY_EXPIRE_TIME > now) {
	add_his (fp, msgid, now, path);
      }
    }
    dbmclose ();
    fclose (fp);
  }
  fclose (fr);
  rename (fpath, hispath);
  sprintf (src, "%s.dir", fpath);
  sprintf (dst, "%s.dir", hispath);
  rename (src, dst);
  sprintf (src, "%s.hash", fpath);
  sprintf (dst, "%s.hash", hispath);
  rename (src, dst);
  sprintf (src, "%s.index", fpath);
  sprintf (dst, "%s.index", hispath);
  rename (src, dst);
}
