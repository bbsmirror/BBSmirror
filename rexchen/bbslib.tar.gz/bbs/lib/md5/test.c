main ()
{
  unsigned char infile[1024] = { "�o�O�@�Ӵ���\n" };
  char outfile[1024] = { 0 };
  char decodefile[1024] = { 0 };
  unsigned char digest[16];
  int length = strlen (infile);
  int action = 1;
  int i, j;
  char encode = 'q';
  char a;
  unsigned char *p;
  int b;

  bq_code (action, encode, length, infile, outfile);
  printf ("\n%s\n", outfile);
  action = 2;
  length = strlen (outfile);
  printf ("length = %d\n", length);
  bq_code (action, encode, length, outfile, decodefile);
  printf ("\n%s\n", decodefile);
  MD5 (infile, strlen (infile), digest);
  for (i = 0; i < 16; i++)
    printf (" %02x ", digest[i]);
  printf ("\nhigh bits number = %d\n", j =
    hbit_num (infile, strlen (infile)));
  for (i = 0; i < 7; i++)
    printf (" %02x ", infile[i]);
  printf ("\n");
  lbit_filter (infile, strlen (infile), j, digest);
  for (i = 0; i < 16; i++)
    printf (" %02x ", digest[i]);
}
