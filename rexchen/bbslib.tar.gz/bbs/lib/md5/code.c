/*
 * bq_code
 */


#include <stdio.h>
#include <string.h>

struct mem_seek {
  int inseek;
  int outseek;
  int ineof;
};



#define ENCODE   1
#define DECODE   2

#define SUCCESS 0
#define ERROR -21

#define BASE64	'b'
#define QP     	'q'

#define ON  1
#define YES 1
#define OFF 0
#define NO  0

#define CR 13
#define LF 10

#define OOB -1
#define EOP -2

#define PADDING '='
#define BKLEN	71


int
Getc (stream, length, seek)
char *stream;
int length;
struct mem_seek *seek;
{
  int c;

  if (seek->inseek < length) {
    c = *(stream + seek->inseek);
    c = c & 0x00ff;
    seek->inseek++;
  } else {
    c = EOF;
  }
  return (c);
}

/*
 * lineless 'ascii' input
 */

static char base256[] = {
  OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB,
  OOB, OOB,

  OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB,
  OOB, OOB,
  /*                                                -                / */
  OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, 62, OOB, OOB, OOB,
  63,
  /*  0   1   2   3    4   5   6   7    8   9                =        */
  52, 53, 54, 55, 56, 57, 58, 59, 60, 61, OOB, OOB, OOB, OOB, OOB, OOB,
  /*      A   B   C    D   E   F   G    H   I   J   K    L   M   N   O */
  OOB, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,
  /*  P   Q   R   S    T   U   V   W    X   Y   Z                     */
  15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, OOB, OOB, OOB, OOB, OOB,
  /*      a   b   c    d   e   f   g    h   i   j   k    l   m   n   o */
  OOB, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
  /*  p   q   r   s    t   u   v   w    x   y   z                     */
  41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, OOB, OOB, OOB, OOB, OOB,
};

int
GetChar (stream, cannot_be_eof, length, seek)
char *stream;
int cannot_be_eof;
struct mem_seek *seek;
{
  int c, ret;

  if (seek->ineof == ON)
    return EOF;

  do {
    if (seek->inseek < length) {
      c = *(stream + seek->inseek);
      c = c & 0x00ff;
      seek->inseek++;
    } else {
      c = EOF;
    }
  } while (c == CR || c == LF);

  if (c == EOF) {
    if (cannot_be_eof == YES) {
      return (ERROR);
    }
    seek->ineof = ON;
    return (EOF);
  }

  if (c == PADDING)
    return (EOP);

  if ((ret = base256[c]) == OOB) {
    return (ERROR);
  }

  return (ret);
}

void
PutChar (c, stream, seek)
int c;
char *stream;
struct mem_seek *seek;
{

  if (c != EOF) {
    *(stream + seek->outseek) = c;
    seek->outseek++;
  }
  return;

}

/*
 * Base 64
 */

static char base64[] =
  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

void
base256to64 (c1, c2, c3, padding, outfile, seek)
int c1, c2, c3, padding;
char *outfile;
struct mem_seek *seek;
{
  *(outfile + seek->outseek) = base64[c1 >> 2];
  seek->outseek++;
  *(outfile + seek->outseek) = base64[((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4)];
  seek->outseek++;
  switch (padding) {
    case 0:
      *(outfile + seek->outseek) =
	base64[((c2 & 0xF) << 2) | ((c3 & 0xC0) >> 6)];
      seek->outseek++;
      *(outfile + seek->outseek) = base64[c3 & 0x3F];
      seek->outseek++;
      break;
    case 1:
      *(outfile + seek->outseek) =
	base64[((c2 & 0xF) << 2) | ((c3 & 0xC0) >> 6)];
      seek->outseek++;
      *(outfile + seek->outseek) = PADDING;
      seek->outseek++;
      break;
    case 2:
      *(outfile + seek->outseek) = PADDING;
      seek->outseek++;
      *(outfile + seek->outseek) = PADDING;
      seek->outseek++;
      break;
  }
}

void
base64_encode (infile, outfile, length, seek)
char *infile, *outfile;
int length;
struct mem_seek *seek;
{
  int c1, c2, c3, len = 0;

  while ((c1 = Getc (infile, length, seek)) != EOF) {
    if ((c2 = Getc (infile, length, seek)) == EOF)
      base256to64 (c1, 0, 0, 2, outfile, seek);
    else if ((c3 = Getc (infile, length)) == EOF)
      base256to64 (c1, c2, 0, 1, outfile, seek);
    else
      base256to64 (c1, c2, c3, 0, outfile, seek);
    len += 4;
    if (len > BKLEN) {
      *(outfile + seek->outseek) = '\n';
      seek->outseek++;
      len = 0;
    }
  }
  if (len) {
    *(outfile + seek->outseek) = '\n';
    seek->outseek++;
  }

}

void
base64_decode (infile, outfile, length, seek)
char *infile, *outfile;
int length;
struct mem_seek *seek;
{
  int c1, c2, c3, c4;

  while ((c1 = GetChar (infile, NO, length, seek)) != EOF) {
    if (c1 == EOP)
      break;
    if ((c2 = GetChar (infile, YES, length, seek)) == EOP)
      break;
    PutChar (((c1 << 2) | ((c2 & 0x30) >> 4)), outfile, seek);

    if ((c3 = GetChar (infile, YES, length, seek)) == EOP)
      break;
    PutChar ((((c2 & 0x0f) << 4) | ((c3 & 0x3c) >> 2)), outfile, seek);

    if ((c4 = GetChar (infile, YES, length, seek)) == EOP)
      break;
    PutChar ((((c3 & 0x03) << 6) | c4), outfile, seek);
  }
}

/*
 * Quoted_Printable
 */

static char base16[] = "0123456789ABCDEF";
static char From[] = "\nFrom ";

#define EQ   '='
#define TAB   9
#define SP   32
#define DOT  '.'
#define DEL 127

void
softbreak (stream, seek)
char *stream;
struct mem_seek *seek;
{
  *(stream + seek->outseek) = EQ;
  seek->outseek++;
  *(stream + seek->outseek) = LF;
  seek->outseek++;
}

void
quoted_printable_encode (infile, outfile, length, seek)
char *infile, *outfile;
int length;
struct mem_seek *seek;
{
  int c, len = 0, sp = OFF, lfdot = OFF, Fromix = 1;

  while (seek->inseek < length) {
    c = *(infile + seek->inseek);
    c = c & 0x00ff;
    seek->inseek++;
    if ((c == TAB) || (c == SP)) {
      if (From[Fromix] == c) {	/* SP */
	*(outfile + seek->outseek) = EQ;
	seek->outseek++;
	*(outfile + seek->outseek) = base16[c >> 4];
	seek->outseek++;
	*(outfile + seek->outseek) = base16[c & 0x0f];
	seek->outseek++;
	len += 3;
	Fromix = 0;
	continue;
      }
      Fromix = 0;
      sp = ON;
      *(outfile + seek->outseek) = c;
      seek->outseek++;
      if ((++len) > BKLEN) {
	sp = OFF;
	len = 0;
	lfdot = LF;
	Fromix = 1;
	softbreak (outfile, seek);
      }
      continue;
    }
    if (c == LF) {
      if (sp || (lfdot == DOT))
	softbreak (outfile, seek);
      len = 0;
      sp = OFF;
      lfdot = LF;
      Fromix = 1;
      *(outfile + seek->outseek) = LF;
      seek->outseek++;
      continue;
    }
    if ((c < SP) || (c == EQ) || (c >= DEL)) {
      /* exclusive TAB, SP */
      sp = OFF;
      *(outfile + seek->outseek) = EQ;
      seek->outseek++;
      *(outfile + seek->outseek) = base16[c >> 4];
      seek->outseek++;
      *(outfile + seek->outseek) = base16[c & 0x0f];
      seek->outseek++;
      len += 3;
      if (len > BKLEN) {
	len = 0;
	lfdot = LF;
	Fromix = 1;
	softbreak (outfile, seek);
      } else {
	Fromix = 0;
	lfdot = OFF;
      }
      continue;
    }
    sp = OFF;

    if (From[Fromix] == c)
      Fromix++;
    else
      Fromix = 0;

    if (c == DOT && lfdot == LF)
      lfdot = DOT;
    else
      lfdot = OFF;

    *(outfile + seek->outseek) = c;
    seek->outseek++;
    if ((++len) > BKLEN) {
      len = 0;
      lfdot = LF;
      Fromix = 1;
      softbreak (outfile, seek);
    }
  }
  if (len > 0)
    softbreak (outfile, seek);	/* ignored by decoder */
}

static char base128[] = {
  OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB,
  OOB, OOB,
  OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB,
  OOB, OOB,
  OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB,
  OOB, OOB,
  0, 1, 2, 3, 4, 5, 6, 7, 8, 9, OOB, OOB, OOB, OOB, OOB, OOB,
  OOB, 10, 11, 12, 13, 14, 15, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB,
  OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB,
  OOB, OOB,
  OOB, 10, 11, 12, 13, 14, 15, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB,
  OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB, OOB,
  OOB, OOB,
};

int
puthexchar (c1, c2, stream, seek)
int c1, c2;
char *stream;
struct mem_seek *seek;
{
  int a1, a2;

  if (((a1 = base128[c1]) != OOB) && ((a2 = base128[c2]) != OOB)) {
    *(stream + seek->outseek) = ((a1 << 4) | a2);
    seek->outseek++;
    return (SUCCESS);
  } else {
    return (ERROR);
  }
}

int
quoted_printable_decode (infile, outfile, length, seek)
char *infile, *outfile;
int length;
struct mem_seek *seek;
{
  int c1, c2, c3;

  /* if an error occurs, print input sequence as it is, anyway, sigh */

  while (seek->inseek < length) {
    c1 = *(infile + seek->inseek);
    c1 = c1 & 0x00ff;
    seek->inseek++;
  skipgetc:
    if (c1 == EQ) {
      if (seek->inseek >= length) {
	c2 = *(infile + seek->inseek);
	c2 = c2 & 0x00ff;
	seek->inseek++;
	*(outfile + seek->outseek) = EQ;
	seek->outseek++;
	return (ERROR);
      } else {
	c2 = *(infile + seek->inseek);
	c2 = c2 & 0x00ff;
	seek->inseek++;
      }
      if (c2 == LF)
	continue;
      if (seek->inseek >= length) {
	c3 = *(infile + seek->inseek);
	c3 = c3 & 0x00ff;
	seek->inseek++;
	*(outfile + seek->outseek) = EQ;
	seek->outseek++;
	*(outfile + seek->outseek) = c2;
	seek->outseek++;
	return (ERROR);
      } else {
	c3 = *(infile + seek->inseek);
	c3 = c3 & 0x00ff;
	seek->inseek++;
      }
      if (puthexchar (c2, c3, outfile, seek) == ERROR) {
	*(outfile + seek->outseek) = EQ;
	seek->outseek++;
	if ((c1 = c2) == EOF)
	  return (ERROR);
	seek->inseek--;
	goto skipgetc;
      } else
	continue;
    }
    *(outfile + seek->outseek) = c1;
    seek->outseek++;
  }
  return (0);
}


/*
 * bq_code()
 */

int
bq_code (action, encode, length, infile, outfile)
int action;
char encode;
int length;
char *infile;
char *outfile;
{
  struct mem_seek seek;

  seek.outseek = 0;
  seek.inseek = 0;
  seek.ineof = OFF;
  switch (action) {
    case ENCODE:
      switch (encode) {
	case BASE64:
	  base64_encode (infile, outfile, length, &seek);
	  break;
	case QP:
	  quoted_printable_encode (infile, outfile, length, &seek);
	  break;
      }
      break;
    case DECODE:
      switch (encode) {
	case BASE64:
	  base64_decode (infile, outfile, length, &seek);
	  break;
	case QP:
	  quoted_printable_decode (infile, outfile, length, &seek);
	  break;
      }
      break;
  }
  return (0);
}
