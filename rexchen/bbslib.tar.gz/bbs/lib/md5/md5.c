#ifndef MD
#define MD MD5
#endif

#include <stdio.h>
#include <time.h>
#include <string.h>
#include "global.h"
#include "md5.h"

/* Length of test block, number of test blocks.
 */
#define TEST_BLOCK_LEN 1000
#define TEST_BLOCK_COUNT 1000

void MDString PROTO_LIST ((char *));
void MDFile PROTO_LIST ((char *));
void MDFilter PROTO_LIST ((void));
void MDPrint PROTO_LIST ((unsigned char[16]));

#define MD_CTX MD5_CTX
#define MDInit MD5Init
#define MDUpdate MD5Update
#define MDFinal MD5Final

void
MD5text (string, len, digest)
char *string;
int len;
unsigned char *digest;
{
  MD5_CTX context;
  char text[32];

  MD5Init (&context);
  MD5Update (&context, string, len);
  MD5Final (digest, &context);
  sprintf(text,"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",digest[0],digest[1],digest[2],digest[3],digest[4],digest[5],digest[6],digest[7],digest[8],digest[9],digest[10],digest[11],digest[12],digest[13],digest[14],digest[15]);
  strncpy(digest,text,32);
}

void
MD5 (string, len, digest)
char *string;
int len;
unsigned char *digest;
{
  MD5_CTX context;

  MD5Init (&context);
  MD5Update (&context, string, len);
  MD5Final (digest, &context);
}


/* Digests a file and prints the result.
 */
void
MDFile (filename, digest)
char *filename;
unsigned *digest;
{
  FILE *file;
  MD_CTX context;
  int len;
  unsigned char buffer[1024];

  if ((file = fopen (filename, "rb")) == NULL)
    printf ("%s can't be opened\n", filename);

  else {
    MDInit (&context);
    while ((len = fread (buffer, 1, 1024, file)))
      MDUpdate (&context, buffer, len);
    MDFinal (digest, &context);
    fclose (file);
  }
}

/* Digests the standard input and prints the result.
 */

void
MDFilter (digest)
unsigned char *digest;
{
  MD_CTX context;
  int len;
  unsigned char buffer[16];

  MDInit (&context);
  while ((len = fread (buffer, 1, 16, stdin)))
    MDUpdate (&context, buffer, len);
  MDFinal (digest, &context);
}
