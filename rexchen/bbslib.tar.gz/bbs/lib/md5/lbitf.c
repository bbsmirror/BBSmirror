#include <stdio.h>
#include <string.h>
#include <malloc.h>

void MD5 ();

int
hbit_num (string, num)
unsigned char *string;
int num;
{
  int hb = 0, i = 0;

  for (i = 0; i < num; i++) {
    if (string[i] > 0x7f) {
      hb++;
    }
  }
  return (hb);
}

void
lbit_filter (string, num, hnum, digest)
unsigned char *string;
int num;
int hnum;
unsigned char *digest;
{
  unsigned char *p = NULL;
  int i = 0, j = 0;

  p = malloc (hnum);

  for (i = 0; i < num; i++) {
    if (string[i] > 0x7f) {
      p[j++] = string[i];
    }
  }
  MD5 (p, hnum, digest);
  free (p);
}
