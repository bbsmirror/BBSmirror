#include <bbs.h>
#include "dbz.h"


int
add_mid (fd,msgid, path)
int fd;
char *msgid;
char *path;
{
  HASH key;
  long where;
  char buf[255];

  lseek(fd,where, SEEK_CUR);
  sprintf(buf,"%s %s\n",msgid,path);
  write(fd,buf,sizeof(buf));
  strncpy (key.hash, msgid, 16);
  if (dbzstore (key, where) < 0) {
    fprintf (stderr, "cant store %s\n", msgid);
    return (0);
  }
  return (1);
}

int
query_mid (fd,msgid, path)
int fd;
char *msgid;
char *path;
{
  HASH key;
  long where;
  char buf[256];

  strncpy (key.hash, msgid, 16);
  where = dbzfetch (key);
  if (where == NOTFOUND) {
    fprintf (stderr, "line can't fetch %s\n", msgid);
    return (0);
  }
  lseek(fd, where, SEEK_SET);
  read(fd,buf,sizeof(buf));
  printf("fgets %s\n",buf);
  strncpy(path,buf,16);
  return (1);
}


main (argc, argv)
int argc;
char **argv;
{
  char test[4096];
  int ret;
  long where,val;
  int fd;
  char history[] = "history";

  long size, entry;

  if (argc > 1) {
    entry = atol (argv[1]);
  } else {
    entry = 100000;
  }
  size = dbzsize (entry);
  dbzfresh ("history", size, 0);
  dbmclose ();

  fd = open(history,O_CREAT | O_WRONLY | O_APPEND, 0600);

  if ( fd < 0 ) {
	printf("fpi error \n");
	exit(0);
  }

  dbminit (history);
  ret = add_mid (fd,"<tttt.eeee.ssss>", "THIS_IS_1ST");
  if (ret)
    printf ("add 1st mid OK\n");
  else
    printf ("add 1st mid failed\n");

  ret = add_mid (fd,"<bbbb.cccc.dddd>", "THIS_IS_2ND");
  if (ret)
    printf ("add 2st mid OK\n");
  else
    printf ("add 2st mid failed\n");

  ret = query_mid (fd,"<tttt.eeee.ssss>", test);
  if (ret)
    printf ("query 1st ok : '%s'\n", test);
  else
    printf ("query 1st failed\n");
  dbmclose ();
  close(fd);
}
