#include <bbs.h>

int
log_open(fpath)
char *fpath;
{
  return(open(fpath, O_WRONLY | O_CREAT | O_APPEND, 0600));
}

int
log_close(fd)
int fd;
{
  close(fd);
}

int
log_text(int fd, char *format, ...)
{
  va_list ap;
  char bufa[256];
  char bufb[256];
  char timestr[DATELEN];
  time_t now;

  if (fd > 0) {
    va_start(ap, format);
    vsprintf(bufa, format, ap);
    va_end(ap);
    now = time(NULL);
    snprintf(bufb, 256 ,"%s %s\n", rtime(&now, timestr), bufa);
    return write(fd, bufb, strlen(bufb));
  }
}
