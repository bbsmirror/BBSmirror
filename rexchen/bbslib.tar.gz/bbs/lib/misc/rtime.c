#include <bbs.h>

char *
rtime (now, timestr)
time_t *now;
char *timestr;
{
  struct tm *p;

  p = localtime (now);
  sprintf (timestr, "%04d/%02d/%02d %02d:%02d:%02d",
    p->tm_year + 1900, p->tm_mon + 1, p->tm_mday, p->tm_hour,
    p->tm_min, p->tm_sec);
  return timestr;
}

char *
ascii_date (now, timestr)
time_t now;
char *timestr;
{
  strftime (timestr, DATELEN, "%d %b %Y %X GMT", gmtime (&now));
  return timestr;
}
