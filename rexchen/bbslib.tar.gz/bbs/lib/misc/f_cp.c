#include <bbs.h>

int
f_cp (src, dst, mode)
char *src, *dst;
int mode;			/* O_EXCL / O_APPEND / O_TRUNC */
{
  int fsrc, fdst, ret = 0;

  if ((fsrc = open (src, O_RDONLY)) >= 0) {
    ret = -1;
    if ((fdst = open (dst, O_WRONLY | O_CREAT | mode, 0600)) >= 0) {
      char pool[BLK_SIZE];

      do {
	ret = read (fsrc, pool, BLK_SIZE);
	if (ret <= 0)
	  break;
      } while (write (fdst, pool, ret) > 0);
      close (fdst);
    }
    close (fsrc);
  }
  return ret;
}
