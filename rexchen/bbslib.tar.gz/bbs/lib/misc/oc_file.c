#include <bbs.h>

int
openfile (fpath)
char *fpath;
{
  int fd;
  struct flock lock;

  if ((fd = open (fpath, O_CREAT | O_WRONLY | O_APPEND, 0600)) >= 0) {
    lock.l_type = F_WRLCK;
    lock.l_start = 0;
    lock.l_whence = SEEK_SET;
    lock.l_len = 0;
    if (fcntl (fd, F_SETLKW, &lock) < 0) {
      close (fd);
      fd = -1;
    }
  }
  return fd;
}

int
closefile (fd)
int fd;
{
  int err = 0;

  if (fd != 1)
    err = close (fd);

  return err;
}

