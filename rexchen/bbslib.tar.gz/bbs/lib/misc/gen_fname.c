#include <bbs.h>

char *
gen_fname (fpath, fname)
char *fpath;
char *fname;
{
  time_t now;
  int try = -1;
  int rc;

  now = time (NULL);

  do {
    if (try == 0xFF) {
      return (NULL);
    } else {
      try++;
    }
    sprintf (fname, "%s/%08x.%02x", fpath, now, try);
  } while ((rc = open (fname, O_WRONLY | O_CREAT | O_EXCL, 0640)) < 0);
  close (rc);
  sprintf (fname, "%08x.%02x", now, try);
  return (fname);
}
