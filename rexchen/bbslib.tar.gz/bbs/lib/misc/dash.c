#include <bbs.h>

int
dashf (fpath)
char *fpath;
{
  struct stat st;

  return (stat (fpath, &st) == 0 && S_ISREG (st.st_mode));
}

int
dashd (fpath)
char *fpath;
{
  struct stat st;

  return (stat (fpath, &st) == 0 && S_ISDIR (st.st_mode));
}
