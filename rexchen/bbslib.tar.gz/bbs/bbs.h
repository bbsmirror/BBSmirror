/*-------------------------------------------------------*/
/* bbs.h        ( Rex BBS 1.0 )                          */
/*-------------------------------------------------------*/
/* Target : bbs include file                             */
/* Create : 99/11/27                                     */
/* Update : 99/11/27                                     */
/*-------------------------------------------------------*/


#define _REENTRANT
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/telnet.h>
#include <sys/resource.h>
#include <dirent.h>
#include <stdarg.h>
#include <crypt.h>
#include <errno.h>
#include <signal.h>
#include <poll.h>
#include <locale.h>
#ifndef WIN32
#include <nl_types.h>
#else
#include <bbs_nl_types.h>
#endif


/*
 * Local Include File
 */

#include <global.h>
#include <struct.h>
