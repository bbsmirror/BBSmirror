#include <locale.h>
//#include <nl_types.h>

#include <libintl.h>

#define MCLoadBySet 0
#define CGETS(b, c, d)        catgets(catd, b, c, d)
#define CSAVS(b, c, d)        strsave(CGETS(b, c, d))


main()
{
/* �ϥ� msgcat �ӹF�� i18n */
  nl_catd catd;
  setlocale(LC_MESSAGES, "zh_TW.Big5");
  setlocale(LC_CTYPE, "zh_TW.Big5");
  catd = catopen("bbs.cat", 0);
  printf("\n%s%s%s\n",CGETS(5, 131, ""),CGETS(6, 2, ""),CGETS(5, 10, ""));
  catclose(catd);

/*  �ϥ� gettext �ӹF�� i18n
    setlocale (LC_ALL, "");
    textdomain("bbs");
    bindtextdomain("bbs", "/usr/share/locale" );

    printf(gettext("rexchen test %s\n"),"rexchen");
    printf(gettext("aaa"));
*/
}
