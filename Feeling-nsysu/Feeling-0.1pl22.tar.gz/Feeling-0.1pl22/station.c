/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw
			   ���崼, Alen@music.nsysu.edu.tw
			   ������, Jimmy@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    sccsid[] = "@(#)station.c	2.2	12/26/95";
#endif

#include <stdio.h>
#include <memory.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/types.h>
#include <malloc.h>
#include <ctype.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <signal.h>
#include <sys/socket.h>
#include <signal.h>
#include <sys/ioctl.h>
#include "common.h"
#include "define.h"
#include "chatd.h"
#include "struct.h"

struct 	timeval	zerotv;

USER	*u_root,
	*u_end,
	*user;
CHANNEL	*root,
	*c_end;
LINK	*l_end;
fd_set	allfds;
struct	timeval	zerotv;
char	genbuf[BUF_LEN],
	readbuf[BUF_LEN];

int 	totaluser,
	sock,
	in_mail = NA;

Command	command[] =
{
/* 0*/	do_private, 		
/* 1*/	do_public, 
/* 2*/	do_who, 		
/* 3*/	do_nick, 	
/* 4*/	do_room_lst, 	
/* 5*/	do_topic, 	
/* 6*/	do_invite, 
/* 7*/	do_quit, 
/* 8*/	do_join, 	
/* 9*/	do_kick, 	
/*10*/	do_oper, 
/*11*/	do_ban, 		
/*12*/	do_new_user, 	
/*13*/	do_setroom,
/*14*/	do_ignore,
/*15*/	do_lst_inv,
/*16*/	do_lst_ban,
/*17*/	do_rm_inv,
/*18*/	do_rm_ban,
/*19*/	do_lst_ign,
/*20*/	do_rm_ign,
/*21*/  do_whos,
/*22*/  do_cloak,
/*23*/	do_rmop
};

HELP	sermsg[] = {
/*0*/	"[7m*** �䤣��z����H, �Ьd����A�ϥ� ***[m",
/*1*/	"[7m*** �z�ثe�ä��O Channel Operator ***[m",
/*2*/	"[7m*** �o�� ChatID �w�Q�ϥ�, �Хt��]�w ***[m",
/*3*/	"[7m*** �Ч󴫱z�� ChatID , �t�μȩw�� None ***[m",
/*4*/	"[7m*** �Ч󴫱z���ʺ� ***[m",
/*5*/	"[7m*** �z�������ܳQ��H�����F ***[m",
/*6*/	"[7m*** ���P�ж����i�ϥ� ***[m",
/*7*/	"[7m*** �S���o�ت��A ***[m",
/*8*/	"[7m*** �z���g���\\���i�i�J ***[m",
/*9*/	"[7m*** �o�O�p�H����ѫ� ,���g�ܽФ��i�i�J ***[m",
/*10*/	"[7m*** Not Enough Memory ***[m"	
};

int	read_message()
{
	int 	cc,
		cmd,
		i;
	char	*ptr;

	(void)memset(readbuf, 0, BUF_LEN);

	if ((cc = recv(user->ufd, readbuf, sizeof(readbuf), 0)) <= 0)
	{
		exit_room(user , EXIT_LOSTCONN);
		return -1;
	}

	for (i = 0; i < strlen(readbuf); i++)
	{
		char	tmp[STRLEN*2];

		if (readbuf[i] == '%')
		{
			(void)strncpy(tmp, readbuf, i+1);
			tmp[i+1] = '\0';
			(void)strcat(tmp, "%\0");
			(void)strcat(tmp, &readbuf[i+1]);
			(void)strcpy(readbuf, tmp);
			i++;
		}
	} 

	readbuf[2] = '\0';
	ptr = &readbuf[0];
	if (*ptr == ' ') 
		ptr++;
	cmd = atoi(ptr);
	(void)memset(genbuf, 0, sizeof(genbuf));
	if (readbuf[3])
		(void)strcpy(genbuf, &readbuf[3]);
	return (*(command[cmd].fun))();
}

void	init_chatd()
{
	u_root 	= (USER *)malloc(sizeof(USER));
	u_end	= (USER *)malloc(sizeof(USER));
	root	= (CHANNEL *)malloc(sizeof(CHANNEL));
	c_end	= (CHANNEL *)malloc(sizeof(CHANNEL));

	l_end	= (LINK *)malloc(sizeof(LINK));
	l_end->next = l_end;
	l_end->prev = l_end;

	u_root->next = u_end;
	u_root->prev = u_root;	
	u_end->next = u_end;
	u_end->prev = u_root;
	root->next = c_end;
	c_end->next = c_end;
	root->prev = root;
/* Jimmy */
	(void)strcpy(root->topic, "�o�OROOT�W�D!!");
	(void)strcpy(root->chname, "ROOT");
	root->unum = 0;
	root->mode = 0;

	root->invite = (LINK *)malloc(sizeof(LINK));
	bord_link(root->invite);
	root->banlist = (LINK *)malloc(sizeof(LINK));
	bord_link(root->banlist);
}

void	user_insert(first, second)
USER	*first;
USER	*second;
{
	first->next->prev = second;
	second->next = first->next;
	first->next = second;
	second->prev = first;
}

int	init_signal()
{
#ifndef	DEBUG
	(void)signal(SIGHUP, sig_catcher);
	(void)signal(SIGINT, sig_catcher);
	(void)signal(SIGQUIT, sig_catcher);
	(void)signal(SIGILL, sig_catcher);
	(void)signal(SIGIOT, sig_catcher);
#ifdef SIGEMT
	(void)signal(SIGEMT, sig_catcher);
#endif
	(void)signal(SIGFPE, sig_catcher);
#ifdef SIGBUS
	(void)signal(SIGBUS, sig_catcher);
#endif
	(void)signal(SIGSEGV, sig_catcher);
#ifdef SIGSYS
	(void)signal(SIGSYS, sig_catcher);
#endif
	(void)signal(SIGPIPE, SIG_IGN);
	(void)signal(SIGTERM, sig_catcher);
	(void)signal(SIGALRM, SIG_IGN);
#ifdef SIGIO
	(void)signal(SIGIO, SIG_IGN);
#endif
#ifdef SIGURG
	(void)signal(SIGURG, SIG_IGN);
#endif
#ifdef SIGPWR
	(void)signal(SIGPWR, sig_catcher);
#endif
#endif
	return;
}

int 	logout_user(user)
USER	*user;
{
	LINK	*ltmp,
		*l;

	(void)shutdown(user->ufd, 2);
	(void)close(user->ufd);
	FD_CLR(user->ufd, &allfds);
	
	for (ltmp = user->ignore; ltmp != l_end;)
	{
		l = ltmp;
		ltmp = ltmp->next;
		free(l);
	}
	user->next->prev = user->prev;
	user->prev->next = user->next;
	free(user);
	if (--totaluser <= 0)
		return 0;

	return 1;
}

void	main(argc , argv)
int	argc;
char	*argv[];
{
	struct	sockaddr_in	sin;
	int	newsock,
		sinsize,
		sr,
		s,
		port,
		ndescriptors,
		i,
		one = 1,
		alive = 1;
	fd_set	readfds;
	struct	timeval	*tvptr = NULL;
	USER	*utemp;

	chdir(BBSHOME);
	totaluser = 0;
	switch (atoi(argv[1]))
	{
		case 4:
			port = CHATPORT4;
			break;
		case 1:
			port = CHATPORT1;
			break;
		case 2:
			port = CHATPORT2;
			break;
		case 3:
			port = CHATPORT3;
			break;
		default:
			(void)printf("Usage: %s chat_room_number\n", argv[0]);
			exit(0);
	}


	init_chatd();
	init_signal();

#ifndef	DEBUG
	switch (fork())
	{
		case -1:	/* error */
			exit_chatd(-1);
		case 0:		/* child process */
			break;
		default:	/* parent process */
			exit_chatd(0);
	}
	(void)setpgid(0, getpid());
	for (i = TABLE - 1; i >= 0; --i)
		(void)close(i);

	(void)open("/dev/null", O_RDONLY);
	(void)dup2(0, 1);
	(void)dup2(0, 2);
#endif

#ifdef SYSV
        setsid();
#else
	{
		i = open("/dev/tty", O_RDWR);
		if (i >= 0)
		{
			(void)ioctl(i, TIOCNOTTY, 0);
			(void)close(i);
		}
	}
#endif
	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
	 	perror("socket");
		exit_chatd(-2);
	}

	if ((setsockopt(mainSocket,SOL_SOCKET,SO_REUSEADDR,(char *)&one,
        	sizeof(one))) == -1)
	{
		perror("setsockopt");
		exit_chatd(1);
	}           

        if ((setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, (void *)&alive,
                sizeof(alive))) == -1)
        {
               perror("setsockopt");
               exit(1);
        }

     	sin.sin_family = AF_INET;
	sin.sin_port = port;
	sin.sin_addr.s_addr = INADDR_ANY;

	if (bind(sock, (struct sockaddr *)&sin, sizeof sin) < 0)
	{
   		perror("bind");
		exit_chatd(-3);
	}

	sinsize = sizeof sin;
	if (getsockname(sock, (struct sockaddr *)&sin, &sinsize) < 0)
	{
	    	perror("getsockname");
		exit_chatd(-4);
	}

	if (listen(sock, SOMAXCONN) == -1)
	{
		perror("listen");
		exit_chatd(-5);
	}
	FD_ZERO(&allfds);
	FD_SET(sock, &allfds);

	for (;;)
	{
		(void)memcpy(&readfds, &allfds, sizeof(fd_set));

		if ((sr = select(TABLE, &readfds, NULL, NULL, tvptr)) < 0)
			exit(-6);

		if (sr == 0)
			exit_chatd(0);
		if (tvptr) 	tvptr = NULL;

		if (FD_ISSET(sock, &readfds))
		{
			sinsize = sizeof sin;
			if ((newsock = accept(sock, (struct sockaddr *)&sin,
				&sinsize))  == -1)
				continue;

			if (totaluser >= MAX_CHAT_USER)
			{
				(void)close(newsock);
				continue;
			}
			totaluser++;
			{
				int	flag = fcntl(newsock,F_GETFL,0);
				flag |= O_NDELAY;
				(void)fcntl(newsock, F_SETFL, flag);
	                	FD_SET(newsock, &allfds);
			}
			utemp = (USER *)malloc(sizeof(USER));

			if (utemp == NULL)
			{
				(void)close(newsock);
				FD_CLR(newsock,&allfds);
				continue;
			}

			utemp->ignore = (LINK *)malloc(sizeof(LINK));

                        if (utemp->ignore == NULL)
			{
                                (void)close(newsock);
                                FD_CLR(newsock,&allfds);
                                continue;
                        }

			bord_link(utemp->ignore);
			user_insert(u_root, utemp);
			utemp->ufd = newsock;
			(void)strcpy(utemp->id,"none");
			(void)strcpy(utemp->nick,"none");;
			continue;
		}

		for (user = u_root->next; user != u_end; user = user->next)
		{
			if (FD_ISSET(user->ufd, &readfds))
			{
				if (read_message() == -1)
				{
					if (!logout_user(user))
						tvptr = &zerotv;
				}
			}
			else
			{
			/*	ping() �i�H�[�b�o��, �b client �� struct
			 *	���[�W�̪�@���S����T�ߪ��ɶ� t0. �é�@��
			 *	ping() �� client, �� client �b����ᥲ���e
			 *	�^�@�� pong().
			 *	server ���_���u�@, ���즬�� client �� pong
			 * 	�K�N�̫�@������ client ��  t0 ���].
			 *	�Y�@���S���� client �� pong. �h�M�ثe�ɶ����,
			 *	�W�L�@�w����, ��p��������. �N�� client ����
			 *	�w�g���`. �M��⥦�q server logout �� */
			}
		}
		if (totaluser <= 0)
			tvptr = &zerotv;
	}
}
/* End_of_main */	

exit_chatd(flag)
int	flag;
{
	int	i;

	FD_ZERO(&allfds);
	(void)shutdown(sock, 2);
	(void)close(sock);
	free_all();

	for (i = 0; i <= MAX_CHAT_USER; i++);
		(void)close(i);
#ifdef	DEBUG
	perror("exit_chatd");
#endif
	exit(flag);
}

int	do_new_user()
{
	char 	buf[80],
		passwd[STRLEN],
		*nptr;
	userec	info;
	int	userlevel,
		userset;

	user->c_pid = atoi(strtok(genbuf, " :"));
	userlevel = atoi(strtok(NULL, " :"));
	userset = atoi(strtok(NULL, " :"));
	(void)strcpy(user->id, strtok(NULL, " :"));
	nptr = strtok(NULL, " :");
	(void)strcpy(user->nick, "NULL");
	fixchatid(nptr);

	user->mode = 0;
	user->level = 0;
	user->channel = root;

/* Jimmy �o�̦�level �����, �i��ݭn�ק� */
	if (userlevel & PERM_CHATCLOAK)
		SITE_ACLOAK(user);

	if (userlevel & PERM_SEECLOAK)
		SITE_VCLOAK(user);

	if (userlevel & PERM_SYSOP)
		SITE_MAIN(user);

	if ((userset & SET_CLOAK) && IS_ACLOAK(user))
		SITE_CLOAK(user);

	root->unum++;

	if (search_user(nptr) != u_end)
	{
		(void)strcpy(user->nick, "NONE");
		send_to_user(MESSAGE, sermsg[4].text ,user);
		send_to_user(CHG_NICK, "NONE", user);	
	}
	else
		(void)strncpy(user->nick, nptr, NL_LEN);
	send_to_user(CHG_NICK, user->nick, user);
	
	if (!IS_CLOAK(user))
	{
/* Jimmy */
		(void)sprintf(buf, "[44;33;1m[Welcome][0;33;1m %s(%s) �}�l�ѻP�U�쪺�Q��..[m",
			user->nick, user->id);
		send_to_room(MESSAGE, buf, user->channel);
	}
	else
	{
/* Jimmy */
		(void)sprintf(buf, "*** %s(%s) �����a���F�i��...", user->nick,
			user->id);
		priv_to_room(MESSAGE, buf, user->channel);
	}

	return 1;
}

void	enter_room(room)
char	*room;
{

	CHANNEL	*cptr;
	char 	buf[80];  

	if (strlen(room) > CN_LEN)
		room[CN_LEN] = '\0';
	cptr = search_room(room);

	if ((user->channel == cptr) && (cptr != c_end))
	{
		send_to_user(MESSAGE,
			"[7m*** You are already in this room ***[m", user);
		return;
	}

	if (cptr == c_end)    	/* This creat a new room ! */
	{	
		cptr = (CHANNEL *)malloc(sizeof(CHANNEL));

	        if (cptr == NULL)
		{
	                send_to_user(MESSAGE,sermsg[10].text,user);
	                return ;
	        }

		room_insert(root, cptr);
		(void)strcpy(cptr->topic, "This is a new room");
		(void)strcpy(cptr->chname, room);
		cptr->unum = 0;
		cptr->mode = 0;
		cptr->invite = (LINK *)malloc(sizeof(LINK));

	        if (cptr->invite  == NULL)
		{
	                send_to_user(MESSAGE,sermsg[10].text,user);
	                return ;
	        }

		bord_link(cptr->invite);
		cptr->banlist = (LINK *)malloc(sizeof(LINK));
	        if (cptr->banlist  == NULL)
		{
	                send_to_user(MESSAGE, sermsg[10].text, user);
	                return ;
	        }
		bord_link(cptr->banlist);
	}
	else if (!IS_MAIN(user))
	{
		if (IS_LOCK(cptr))
		{
		  	if (!open_room(cptr->invite , user))
			{
  				send_to_user(MESSAGE, sermsg[9].text, user);
  				return;
  			}
  		}
  		if (open_room(cptr->banlist , user))
		{
			send_to_user(MESSAGE, sermsg[8].text , user);
	  		return;
		}
  	}

	if (IS_CLOAK(user))
	{
		(void)sprintf(genbuf,"*** %s(%s) ��J�W�D [%s]", user->nick,
			user->id, cptr->chname);
		priv_to_room(MESSAGE, genbuf, user->channel);
	}
	else
	{
		(void)sprintf(genbuf,"*** %s(%s) �[�J�W�D [%s]", user->nick,
			user->id, cptr->chname);
		send_to_room(MESSAGE, genbuf, user->channel);
	}
	exit_room(user , EXIT_LOGOUT);
	user->channel = cptr;
	if (cptr->unum == 0 && cptr != root)
	  	SITE_OP(user);
	else
		RM_OP(user);
	cptr->unum++;
	if (IS_CLOAK(user))
	{
		(void)sprintf(buf, "*** %s(%s) ��J�o���W�D�F..", user->nick,
			user->id);
		priv_to_room(MESSAGE, buf, cptr);
	}
	else
	{
		(void)sprintf(buf, "*** ��, �j�a�n. �ڬO %s(%s) �Цh�h���� ^_^",
			user->nick, user->id);
		send_to_room(MESSAGE, buf , cptr);
	}
	send_to_user(CHG_ROOM, user->channel->chname, user);

	return;
}

int	do_join()
{
	enter_room(&genbuf[0]);
	return 0;
}

int	do_public()
{
	send_to_room(MESSAGE, genbuf , user->channel);
}

int 	do_private()
{
	USER	*uptr;
	LINK	*ltmp;
	char	buf[BUF_LEN + ID_LEN],
		*ptr;

	ptr = advance(genbuf);

	if ((uptr = search_user(genbuf)) == u_end)
	{
		send_to_user(MESSAGE, sermsg[0].text ,user);
		return 0;
	}

	if ((ltmp = search_link(uptr->ignore->next, user->nick)) != l_end)
	{
		send_to_user(MESSAGE, sermsg[5].text, user);
		return 0;
	}

	(void)sprintf(buf, "[7m*** %s-> %s[m", user->nick , ptr);
	send_to_user(MESSAGE,buf,uptr);

	return 0 ;
}

int	do_who()
{
	int	i = 0,
		delay;
	char	buf[80];
	char	pline[40];
	USER	*uptr;
/* Jimmy */
	send_to_user(MESSAGE, "*** �ثe���W�D���ϥΪ� ***", user);
 	(void)sprintf(buf, "%-10s   %-12s %-10s   %-10s   %-12s %-10s",       
        	"Chatid", "Userid", "room", "Chatid", "Userid", "room");
	send_to_user(MESSAGE, buf , user);
	(void)sprintf(buf, "%-10s   %-12s %-10s   %-10s   %-12s %-10s",
		"------", "------", "----", "------", "------", "----");
	send_to_user(MESSAGE, buf , user);
	(void)memset(buf, 0, sizeof(buf));

	for (uptr = u_root->next; uptr != u_end; uptr = uptr->next)
	{
		if ((IS_SEC(uptr->channel) && (uptr->channel != user->channel)
			&& !IS_MAIN(user)) ||
			(IS_CLOAK(uptr) && !VIEW_CLOAK(user)))
			continue;

		(void)sprintf(pline, "%-10.10s %c%c%-12.12s %-10.10s",
			uptr->nick, IS_CLOAK(uptr) ? '#' : ' ',
			IS_MAIN(uptr) ? '*' : (IS_OP(uptr) ? '@' : ' '),
			uptr->id, uptr->channel->chname);

		if (i < 1)
			(void)strcat(pline, "   ");
		(void)strcat(buf, pline);

#ifdef	DELAY
#define	DELAY_TIME	10000
		for (delay = 0; delay <= DELAY_TIME; delay++);
#endif

		if (++i == 2)
		{
			i = 0;

			send_to_user(MESSAGE , buf, user);

			(void)memset(buf, 0, 80);
		}
	}

	send_to_user(MESSAGE , buf, user);

	return 0;
}	

int	do_room_lst()
{
	CHANNEL	*rptr;
	char	buf[80];
/* Jimmy */
	send_to_user(MESSAGE, "*** �W�D�C�� ***", user);
	(void)sprintf(buf, "%-13s %c%c%c  %-4s   %s", "channel", 'P', 'T', 'S',
		"num", "topic");
	send_to_user(MESSAGE, buf, user);
	for (rptr = root; rptr != c_end; rptr = rptr->next)
	{
		if (IS_SEC(rptr) && (user->channel != rptr) && !IS_MAIN(user)) 
			continue;
		(void)memset(buf, 0, sizeof(buf));
		(void)sprintf(buf, "%-13s %c%c%c  %-4d   %.54s",rptr->chname,
			(IS_LOCK(rptr)) ? 'p' : ' ' ,
			(IS_TOPLIM(rptr)) ? 't' : ' ',
			(IS_SEC(rptr)) ? 's' : ' ',  rptr->unum, rptr->topic);

		send_to_user(MESSAGE, buf, user);
	}

	send_to_user(MESSAGE, "*** End of Room list ***", user);

	return 0;
}	

int	do_topic()
{
	CHANNEL	*rptr;

	if (!strcmp(genbuf, "NONE"))
	{
		(void)sprintf(genbuf, "*** ���W�D�D�D��: %s", user->channel->topic);
		send_to_user(MESSAGE, genbuf, user);
		return;
	}
	if (IS_OP(user) || IS_MAIN(user) || !IS_TOPLIM(user->channel))
	{
		(void)strcpy(user->channel->topic, genbuf);
		(void)sprintf(genbuf, "*** Topic is change by %s ***", user->nick);
		send_to_room(MESSAGE, genbuf, user->channel);
		(void)sprintf(genbuf, "The new topic is [%s]", user->channel->topic);
		send_to_room(MESSAGE, genbuf, user->channel);
	}
	else
	{
		send_to_user(MESSAGE, sermsg[1].text, user);
	}

	return 0;
}

int	do_nick()
{

	char	buf[80];

	genbuf[NL_LEN] = '\0';
	fixchatid(genbuf);
	if (search_user(genbuf) == u_end)
	{
		send_to_user(CHG_NICK, genbuf, user);
/* Jimmy */
		(void)sprintf(buf, "*** %s �q�{�b�_��W�� %s ***", user->nick,
			genbuf);
		send_to_room(MESSAGE, buf, user->channel);
		(void)strncpy(user->nick , genbuf, NL_LEN-1);
	}
	else
		send_to_user(MESSAGE, sermsg[2].text, user);

	return 0;
}

int	do_invite()
{
	USER	*utemp;
	LINK	*ltmp;

	if (!IS_OP(user) && !IS_MAIN(user))
	{
		send_to_user(MESSAGE, sermsg[1].text ,user);
		return 0;
	}

	if ((utemp = search_user(genbuf)) ==  u_end)
	{
		send_to_user(MESSAGE, sermsg[0].text , user);
		return 0;
	}
	ltmp = (LINK *)malloc(sizeof(LINK));
	if (ltmp == NULL)
	{
		send_to_user(MESSAGE,sermsg[10].text,user);
		return 0;
	}
	ltmp->value.uptr = utemp;
	link_insert(user->channel->invite, ltmp);
	(void)sprintf(genbuf, "[7m*** �A�ܽ� %s �[�J�A����ѫ� ***[m", utemp->nick);
	send_to_user(MESSAGE, genbuf, user);
	(void)sprintf(genbuf, "[7m*** %s �ЧA�[�J %s ����ѫ� ***[m"
				, user->nick, user->channel->chname);
	send_to_user(MESSAGE, genbuf, utemp);
}

int	do_ban()
{
	USER	*utemp;
	LINK	*ltmp;

	if (!IS_OP(user) && !IS_MAIN(user))
	{
		send_to_user(MESSAGE, sermsg[1].text , user);
		return;
	}
        
	if ((utemp = search_user(genbuf)) ==  u_end)
	{
		send_to_user(MESSAGE, sermsg[0].text , user);
		return 0;
	}

	ltmp = (LINK *)malloc(sizeof(LINK));
        if (ltmp == NULL)
	{
                send_to_user(MESSAGE,sermsg[10].text,user);
                return 0;
        }
	ltmp->value.uptr = utemp;
	link_insert(user->channel->banlist, ltmp);
/* Jimmy */
	(void)sprintf(genbuf, "[7m*** %s �w�T�� %s �[�J�A����ѫ�***[m", user->nick, utemp->nick);
	send_to_room(MESSAGE, genbuf, user->channel);
	(void)sprintf(genbuf, "[7m*** %s �T��A�[�J %s ����ѫ� ***[m", user->nick,
		user->channel->chname);

	send_to_user(MESSAGE, genbuf, utemp);	
}

int	do_oper()
{
	USER 	*utemp;

	if (!IS_OP(user) && !IS_MAIN(user))
	{
		send_to_user(MESSAGE, sermsg[1].text ,user);
		return 1;
	}

	if ((utemp = search_user(genbuf)) == u_end)
		send_to_user(MESSAGE, sermsg[0].text , user);
	else
	{
		if (utemp->channel != user->channel)
		{
			send_to_user(MESSAGE, sermsg[6].text ,user);
			return 1;
		}

 		SITE_OP(utemp);
 		(void)sprintf(genbuf, "[7m*** %s ��޲z���v���� %s[m", user->nick,
			utemp->nick);
  		send_to_room(MESSAGE, genbuf, user->channel);
	}
	return 1;
}

int	do_rmop()
{
	USER 	*utemp;

	if (!IS_OP(user) && !IS_MAIN(user))
	{
		send_to_user(MESSAGE, sermsg[1].text ,user);
		return 1;
	}

	if ((utemp = search_user(genbuf)) == u_end)
		send_to_user(MESSAGE, sermsg[0].text , user);
	else
	{
		if (utemp->channel != user->channel)
		{
			send_to_user(MESSAGE, sermsg[6].text ,user);
			return 1;
		}

 		RM_OP(utemp);
 		(void)sprintf(genbuf, "[7m*** %s �� %s �޲z���v������[m", user->nick,
			utemp->nick);
  		send_to_room(MESSAGE, genbuf, user->channel);
	}
	return 1;
}

int 	do_quit()
{
	exit_room(user, EXIT_LOGOUT);
	return -1;
}

int	do_cloak()
{
	if (!IS_ACLOAK(user))
	{
/* Jimmy */
		send_to_user(MESSAGE,"[7m*** �z���֦������v���� ***[m",user);
		return 0;
	}

	if (IS_CLOAK(user))
	{
/* Jimmy */
		send_to_user(MESSAGE, "[7m[INFO] �}�l�{��[m", user);
		RM_CLOAK(user);
	}
	else
	{
/* Jimmy */
		send_to_user(MESSAGE, "[7m[INFO] �}�l����[m", user);
		SITE_CLOAK(user);
	}	

	return 0;
}

int	do_kick()
{
	USER	*uptr;

	if (IS_OP(user) || IS_MAIN(user))
	{
		uptr = search_user(genbuf);
		if (uptr == u_end)
			send_to_user(MESSAGE, sermsg[0].text , user);
		else if (IS_MAIN(uptr))
		{
/* Jimmy */
			(void)sprintf(genbuf, "[7m[ĵ�i]�ѯ��O���i�H�_�Ǫ�[m");
			send_to_user(MESSAGE, genbuf, user);
			return 1;
		}
		else
		{
			if (uptr->channel == user->channel || IS_MAIN(user))
			{
/* Jimmy */
				(void)sprintf(genbuf,"[7m*** %s �Q %s�@�}��X���W�D ...[m",
					uptr->nick,user->nick);
				send_to_room(MESSAGE,genbuf,user->channel);
				exit_room(uptr, EXIT_KICK);		
				(void)logout_user(uptr);
			}
			else
			{
				send_to_user(MESSAGE, sermsg[6].text, user);
				return 1;
			}
		}
	} 
	else
		send_to_user(MESSAGE, sermsg[1].text , user);

	return 1;
}

int	do_setroom()
{
	if (!IS_OP(user) && !IS_MAIN(user))
	{
		send_to_user(MESSAGE, sermsg[1].text ,user);
		return 0;
	}
	
	if (genbuf[0] == '+')
	{	
		if (genbuf[1] == 'P' || genbuf[1] == 'p')
		{
			SITE_LOCK(user->channel);
			(void)sprintf(genbuf, "[7m*** [%s] �{�b�O�p�H����ѫ�[m",
					user->channel->chname);
			send_to_room(MESSAGE, genbuf, user->channel);
			return 0;
		}
		if (genbuf[1] == 'S' || genbuf[1] == 's')
		{
			SITE_SEC(user->channel);
			(void)sprintf(genbuf, "[7m*** [%s] �{�b�O���K����ѫ�[m",
					user->channel->chname);
			send_to_room(MESSAGE, genbuf, user->channel);
			return 0;
		}
		if (genbuf[1] == 'T' || genbuf[1] == 't')
		{
			SITE_TOPLIM(user->channel);
/* Jimmy */
			(void)sprintf(genbuf, "[7m*** [%s] �u�� OPER �i�󴫥D�D[m",
					user->channel->chname);
			send_to_room(MESSAGE, genbuf, user->channel);
			return 0;
		}
		send_to_user(MESSAGE, sermsg[7].text ,user);
		return 0;
	}
        if (genbuf[0] == '-')
	{
                if (genbuf[1] == 'P' || genbuf[1] == 'p')
		{
                        RM_LOCK(user->channel);
                        (void)sprintf(genbuf, "[7m*** [%s] �{�b�w�g���O�p�H��[m",
                                user->channel->chname);
                        send_to_room(MESSAGE, genbuf, user->channel);
                        return 0;
                }
                if (genbuf[1] == 'S' || genbuf[1] == 's')
		{
                        RM_SEC(user->channel);
/* Jimmy */
                        (void)sprintf(genbuf, "[7m*** [%s] �{�b�w���O���K��[m",
                                user->channel->chname);
                        send_to_room(MESSAGE, genbuf, user->channel);
                        return 0;
                }
                if (genbuf[1] == 'T' || genbuf[1] == 't')
		{
                        RM_SEC(user->channel);
                        (void)sprintf(genbuf, "[7m*** [%s] �������H���i�H���D�D[m",
                        	user->channel->chname);
                        send_to_room(MESSAGE, genbuf, user->channel);
                        return 0;
                }
                send_to_user(MESSAGE, sermsg[7].text ,user);
                return 0;
        }
}

int	do_lst_inv()
{
	LINK	*ltmp;
/* Jimmy */
	send_to_user(MESSAGE,"*** �ܽЦW�� ***",user);
	for (ltmp = user->channel->invite->next; ltmp != l_end; 
		ltmp = ltmp->next)
	{
		(void)sprintf(genbuf,"[%s] is in your invite list.",
					ltmp->value.uptr->nick);
		send_to_user(MESSAGE, genbuf, user);
	}
	send_to_user(MESSAGE,"*** End of list ***",user);
	return 0;
}

int     do_lst_ban()
{
	LINK    *ltmp;

        send_to_user(MESSAGE,"*** �T��W�� ***",user);
        for (ltmp = user->channel->banlist->next; ltmp != l_end;
		ltmp = ltmp->next)
	{
                (void)sprintf(genbuf,"[%s] is in your ban  list.",
			ltmp->value.uptr->nick);
                send_to_user(MESSAGE, genbuf, user);
        }
        send_to_user(MESSAGE,"*** End of list ***",user);

	return 0;
}


int	do_rm_inv()
{
	LINK	*ltmp;

	if (!IS_OP(user) && !IS_MAIN(user))
	{
		send_to_user(MESSAGE, sermsg[1].text ,user);
		return 0;
	}

	if ((ltmp = search_link(user->channel->invite->next, genbuf)) == l_end)
	{
		send_to_user(MESSAGE, "*** Not in your invite list ***",user);
		return 0;
	}
	(void)sprintf(genbuf, "You have remove [%s] from your invite list",
		ltmp->value.uptr->nick);
	send_to_user(MESSAGE, genbuf, user);
	rm_link(ltmp);

	return 0;
}
	
int 	do_rm_ban()
{
	LINK	*ltmp;

        if (!IS_OP(user) && !IS_MAIN(user))
	{
                send_to_user(MESSAGE, sermsg[1].text ,user);
                return 0;
        }
	
	if ((ltmp = search_link(user->channel->banlist->next, genbuf)) ==
		l_end)
	{
		send_to_user(MESSAGE,"*** Not in your ban list ***", user);
		return 0;
	}
	(void)sprintf(genbuf,"You have remove [%s] from your ban list ",
		ltmp->value.uptr->nick);
	send_to_user(MESSAGE, genbuf, user);
	rm_link(ltmp);
	return 0;
}


int	do_ignore()
{
	USER	*utmp;
	LINK	*ltmp;

	if ((utmp = search_user(genbuf)) == u_end)
	{
		send_to_user(MESSAGE, sermsg[0].text ,user);
		return 0;
	}
	ltmp = (LINK *)malloc(sizeof(LINK));

        if (ltmp == NULL)
	{
                send_to_user(MESSAGE,sermsg[10].text,user);
                return 0;
        }

	ltmp->value.uptr = utmp;
	link_insert(user->ignore, ltmp);
	(void)sprintf(genbuf,"[7m*** You have ignored %s's private message ***[m",utmp->nick);
	send_to_user(MESSAGE, genbuf, user);
        (void)sprintf(genbuf, "[7m*** %s have ignored your private message ***[m"
                                , user->nick);
	send_to_user(MESSAGE,genbuf,utmp);
	return 0;
}

int	do_lst_ign()
{
	LINK	*ltmp;
/* Jimmy */
	send_to_user(MESSAGE,"*** �����W�� ***",user);

	for (ltmp = user->ignore->next; ltmp != l_end; ltmp = ltmp->next)
	{
		(void)sprintf(genbuf,"You have ignore [%s].",ltmp->value.uptr->nick);
		send_to_user(MESSAGE, genbuf, user);
	}

	send_to_user(MESSAGE,"*** End of list ***",user);
	return 0;
}

int	do_rm_ign()
{
	LINK	*ltmp;

	if((ltmp = search_link(user->ignore->next,genbuf)) == l_end)
	{
		send_to_user(MESSAGE, sermsg[0].text ,user);
		return 0;
	}
	(void)sprintf(genbuf,"You have remove [%s] from your ingore list",
					ltmp->value.uptr->nick);
	send_to_user(MESSAGE, genbuf, user);
	(void)sprintf(genbuf,"%s accept your private now !",user->nick);
	send_to_user(MESSAGE, genbuf, ltmp->value.uptr);
	rm_link(ltmp);
	return 0;
}
		
int	do_whos()
{
        int     i = 0;
        char    buf[100],
        	pline[40];
        USER    *uptr;  
	CHANNEL	*cptr;

	if (((cptr = search_room(genbuf)) == c_end) ||
		(IS_SEC(cptr) && (cptr != user->channel) && !IS_MAIN(user)))
	{
		send_to_user(MESSAGE,"*** Ivnalid Room Name ***",user);
		return 0;
	}
/* Jimmy */
	send_to_user(MESSAGE, "*** �ثe���W�D���ϥΪ� ***", user);
 	(void)sprintf(buf, "%-10s   %-12s  %-10s   %-12s  %-10s   %-12s",       
        	"Chatid", "Userid", "Chatid", "Userid", "Chatid", "Userid");
	send_to_user(MESSAGE, buf , user);
	(void)sprintf(buf, "%-10s   %-12s  %-10s   %-12s  %-10s   %-12s",
		"------", "------", "-----", "------", "------", "------");
	send_to_user(MESSAGE, buf , user);
	(void)memset(buf, 0, sizeof(buf));

	for (uptr = u_root->next; uptr != u_end; uptr = uptr->next)
	{
		if (uptr->channel != cptr || (IS_CLOAK(uptr) &&
			!VIEW_CLOAK(user)))
		{
			continue;
		}

		(void)sprintf(pline, "%-10s %c%c%-12s  ", uptr->nick,
			IS_CLOAK(uptr) ? '#' : ' ',
			IS_MAIN(uptr) ? '*' : (IS_OP(uptr) ? '@' : ' '),
			uptr->id);

		if (i < 2)
			(void)strcat(pline, " ");

		(void)strcat(buf, pline);

		if (++i == 3)
		{
			i = 0;

			send_to_user(MESSAGE , buf, user);

			(void)memset(buf, 0, 80);
		}
	}

	send_to_user(MESSAGE , buf, user);

	return 0;
}	

void	send_to_room(type, buf , room)
int	type;	
char 	*buf;
CHANNEL *room;
{
	USER	*utemp;
	fd_set	writefds;
	char	sbuf[BUF_LEN + 3];

	FD_ZERO(&writefds);

	for (utemp = u_root->next; utemp != u_end; utemp = utemp->next)
	{
	  	if (utemp->channel == room)
		{
  			FD_SET(utemp->ufd, &writefds);
		}
	}

	(void)sprintf(sbuf, "%d:%s", type, buf);	
	do_send(&writefds, sbuf);
}

void	priv_to_room(type, buf , room)
int	type;	
char 	*buf;
CHANNEL *room;
{
	USER	*utemp;
	fd_set	writefds;
	char	sbuf[BUF_LEN + 3];

	FD_ZERO(&writefds);

	for (utemp = u_root->next; utemp != u_end; utemp = utemp->next)
	{
	  	if (utemp->channel == room && VIEW_CLOAK(utemp))
		{
  			FD_SET(utemp->ufd, &writefds);
		}
	}

	(void)sprintf(sbuf, "%d:%s", type, buf);	
	do_send(&writefds, sbuf);
}

void	do_send(writefds, buf)
fd_set 	*writefds;
char	*buf;
{
USER 	*utemp;

	for (utemp = u_root->next; utemp != u_end; utemp = utemp->next)
	{
		if (FD_ISSET(utemp->ufd, writefds))
			(void)send(utemp->ufd, buf, strlen(buf)+1, 0);
	}
}

CHANNEL *search_room(room)
char	*room;
{
	CHANNEL	*cptr;

	for (cptr = root; cptr != c_end; cptr = cptr->next)
	{
		if (!strcasecmp(cptr->chname, room))
			break;
	}

	return	cptr;
}

void 	room_insert(first, second)
CHANNEL	*first;
CHANNEL	*second;
{
	first->next->prev = second;
	second->next = first->next;
	first->next = second;
	second->prev = first;
}

void	link_insert(first, second)
LINK	*first;
LINK	*second;
{
	first->next->prev = second;
	second->next = first->next;
	first->next = second;
	second->prev = first;
}  

int	open_room(item , user)
LINK	*item;
USER	*user;
{
	for (item; item != l_end; item = item->next)
	{
		if (item->value.uptr == user)
	  		return 1;
	}
	return 0;
}

void	send_to_user(type, ptr , uptr)
int	type;
char 	*ptr;
USER 	*uptr;
{
	fd_set 	writefds;
	char	sbuf[BUF_LEN + 2];

	FD_ZERO(&writefds);
	FD_SET(uptr->ufd, &writefds);

	(void)sprintf(sbuf, "%d:%s", type, ptr);
	do_send(&writefds, sbuf);
}

void	exit_room(user , flag)
USER	*user;
int	flag;
{
	char	buf[80];
 	LINK	*ltmp,
		*l;

	if (--user->channel->unum)
	{
	  	switch(flag)
		{
	  		case	EXIT_LOGOUT:
				(void)sprintf(buf, "*** %s ���}�o���W�D", user->nick);
				break;
			case	EXIT_LOSTCONN:
				(void)sprintf(buf, "*** %s �_�u�����}.", user->nick);
				break;
			case	EXIT_KICK:
				(void)sprintf(buf, "*** %s �Q��X�W�D[%s]",
					user->nick, user->channel);
				break;
		}
		if (IS_CLOAK(user))
			priv_to_room(MESSAGE, buf , user->channel);
		else
			send_to_room(MESSAGE, buf , user->channel);
		return;
	}

	if (user->channel == root)
		return;

	kill_channel(user->channel);

return;

}	

char	*advance(ptr)
char	*ptr;
{
	while (*ptr != ' ' && *ptr != '\n' && *ptr != '\t')
	{
		if (*ptr == '\0')
			return ptr;
		else
			ptr++;
	}

	while (*ptr == ' ' || *ptr == '\n' || *ptr == '\t')
		ptr++;

	*(ptr-1) = '\0';

	return ptr;
}

USER	*search_user(user)
char	*user;
{
	USER	*uptr;

	for (uptr = u_root->next; uptr != u_end; uptr = uptr->next)
	{
		if (!strcasecmp(user, uptr->nick))
			return	uptr;
	}
	return	u_end;
} 

LINK	*search_link(chan , item)
LINK	*chan;
char 	*item;
{
	LINK	*ltmp;
 
	for (ltmp = chan ;ltmp != l_end; ltmp = ltmp->next) 
	{
		if(!strcasecmp(item, ltmp->value.uptr->nick))
			return	ltmp;
	}
	return	l_end;
}		

void	bord_link(lptr)
LINK	*lptr;
{
	lptr->prev = lptr;
	lptr->next = l_end;
}

void	fixchatid(chatid)
char    *chatid;
{
	int	count = 0;

        while (*chatid != '\0' && *chatid != '\n')
        {
                if (strchr(BADCIDCHARS, *chatid))
                        *chatid = '_';
        	if (++count > NL_LEN)
		{
			*chatid = '\0';
			break;
		}
	        chatid++;
	}
}

void	rm_link(item)
LINK	*item;
{
	item->next->prev = item->prev;
	item->prev->next = item->next;
	free(item);
}

void	sig_catcher(sig)
{
	(void)signal(sig, SIG_DFL);
	exit_chatd(1);
}  

void 	kill_channel(channel)
CHANNEL	*channel;
{
	LINK	*ltmp,
		*l;

	channel->prev->next = channel->next;
 	channel->next->prev = channel->prev;
 	for (ltmp = channel->invite; ltmp != l_end;)
	{
 		l = ltmp->next;
 	 	free(ltmp);
 	 	ltmp = l;	 						  			  
 	}
 	for (ltmp = channel->banlist; ltmp != l_end;)
	{
 		l = ltmp->next;
 	 	free(ltmp);
 	 	ltmp = l;	 						  			  
 	}  
	free(channel);
	return;
}

void	free_all()
{
	kill_channel(root);
	free(u_root);
	free(u_end);
	free(c_end);
	free(l_end);
	free(u_root);
	free(u_end);
}
