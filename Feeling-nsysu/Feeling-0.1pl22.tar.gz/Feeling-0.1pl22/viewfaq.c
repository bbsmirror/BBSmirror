/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    SccsId[] = "@(#)viewfaq.c    2.5    6/2/96";
#endif

#include "bbs.h"

static char   faqtitle[STRLEN],
              copyfile[1024];
static faqhd  copyinfo;
static ulevel clevel = CUSER;
static int    list_by_file_name = NA,
              global_mode,
              cached = 0,
              lcached = 0;

extern int     t_lines;
extern one_key faqcmd[];
extern userec  cuser;
extern usinfo  uinfo;
extern time_t  lastlogin;

extern int     cmpbname(),
               make_blist(),
               faqview();

#ifdef DOWNLOAD
extern ptcol   protos[];
#endif

static	hlpinfo	FAQ_Help[] = {
     0,  0, HIGH, 0,           "[1;36;44m                            ���i�O�κ�ذ�  �ާ@����                           [m\n\n",
    -1, -1, HIGH, 0,           "[1;36;44m                                  ��в��ʻ���                                 [m\n",
    -1, -1,  LOW, 0,           "p �� n ��           �W �U�@�����\n",
    -1, -1,  LOW, 0,           "P PgUp N PgDn       �W/�U�@��\n",
    -1, -1,  LOW, 0,           "##<cr>              ����J�@�ӼƦr�A��J Enter ��, ���##�����\n",
    -1, -1,  LOW, 0,           "$                   �̫�@�����\n",
    -1, -1,  LOW, 0,           "\n",
    -1, -1, HIGH, 0,           "[1;36;44m                                ��L�`�Ϊ��\\����                               [m\n",
    -1, -1,  LOW, 0,           "/       �j�M��M�ؿ�\n",
    -1, -1,  LOW, PERM_BMS,    "Ctrl-P  �إ߷s�����                      v        �s�g .Names ��\n",
    -1, -1,  LOW, PERM_BMS,    "c       �s�@�ƻs�аO                      s / S    �i���ɮ׽ƻs/���[\n",
    -1, -1,  LOW, PERM_BMS,    "d       �R����ƿ�                        f        ����ɮצW\n",
    -1, -1,  LOW, PERM_BMS,    "g       �إ߷s�Ӹ�ƥؿ�                  i        �N�Ȧs�Ϥ峹�ޤJ��ذϤ�\n",
    -1, -1,  LOW, PERM_SYSOP,  "V       �s�g�O�P��ذϹ�����              B        �O�D�P������������\n",
    -1, -1,  LOW, PERM_BMS,    "E       �s�����ɮ�                      G        �W�[�@�� Gopher URL\n",
    -1, -1,  LOW, PERM_BMS,    "R       �ܧ��ɦW                          T        �ܧ���D�D\n",
    -1, -1,  LOW, PERM_BMS,    "M       �E����m                          A        ���[�ɮ�\n",
    -1, -1,  LOW, PERM_BASIC,  "F       �N�ɮױH�^ E-mail �a�}\n",
#ifdef	DOWNLOAD
    -1, -1,  LOW, PERM_BASIC,  "CTRL-D  �U���ɮ�\n",
#endif
    -1, -1,  LOW, 0,           "r Ent   �����ƿ�\n",
    -1, -1,  LOW, 0,	       NULL,
};

int  is_gopher_site(path)
char *path;
{
    if (strstr(path, "gopher://") == path)
        return 1;
    return 0;
}

char *make_proxy_file(path)
char *path;
{
    static char genbuf[1024];
    char   *c;
    int    i;

    (void)sprintf(genbuf, "%s/proxy/gopher.%d", BBSHOME, GetStrCrc(path));
    return genbuf;
}

ptype check_gopher_site(buf)
char  *buf;
{
    char *p,
         c,
         server[STRLEN];
    int  num;

    p = (char *)strstr(buf, "://");
    if (p == NULL)
        return -1;
    (void)strcpy(server, p+3);
    if ((p = (char *)strtok(server, ":")) == NULL)
        return -1;
    if ((p = (char *)strtok(NULL, ":")) == NULL)
        return -1;
    p = (char *)strchr(p, '/');
    if (p == NULL || *p == '\0')
        return -1;
    c = *(p+1);
    num = atoi(&c);
    if (num == 0)
        return ISGOFILE;
    else if (num == 1)
        return ISGODIR;
    return -1;
}

int  request(fromhost, path, port, fd)
char *fromhost,
     *path;
int  port,
     *fd;
{
    struct sockaddr_in sin;
    struct hostent *host;
    int    ifd;

    (void)memset((char *)&sin, 0, sizeof(sin));
    sin.sin_port = htons(port);
    host = gethostbyname(fromhost);
    if (host == NULL)
        sin.sin_addr.s_addr = inet_addr(fromhost);
    else
        (void)memcpy(&sin.sin_addr.s_addr, host->h_addr, host->h_length);
    sin.sin_family = AF_INET;

    *fd = ifd = socket(AF_INET, SOCK_STREAM, 0);

    if (ifd < 0)
    {
        perror("get socket error");
        return 0;
    }

    if (connect(ifd, (struct sockaddr *)&sin, sizeof(sin)) < 0)
    {
        perror("connect fail");
        return 0;
    }

    if (write(ifd, path, strlen(path)) == -1)
    {
        perror("could not write");
        return 0;
    }

    if (write(ifd, "\n", 1) == -1)
        return 0;
    return 1;
}

void close_port(fd)
int  fd;
{
    (void)close(fd);
}

int  readport(fd, buf)
int  fd;
char *buf;
{
    int  i,
         l = 0;
    char *s = buf;

    while ((i = read(fd, s, 1)) > 0)
    {
        l += i;
        if (*s == '\n')
            break;
        if (*s != '\r')
            s++;
    }
    *s = 0;
    return l;
}

int  get_text(urlfile, fromhost, path, port, fd)
char *urlfile,
     *fromhost,
     *path;
int  port,
     *fd;
{
    char input[1024];
    int  line = 0,
         n,
         ch;
    FILE *fp;

    if ((fp = fopen(urlfile, "w")) == NULL)
    {
        move(t_lines-1, 0);
        prints(NA, "------ �L�k�}�� proxy, �гq������ ------\n");
        igetkey();
        return -1;
    }
    move(t_lines-1, 0);
    prints(NA, "������Ƥ�.......\n");
    clrtoeol();
    if (request(fromhost, path, port, fd) == 0)
    {
        perror("could not talk with server");
        return -1;
    }

    clear();

    while (readport(*fd, input) > 0 && strcmp(input, "."))
    {
        (void)fprintf(fp, "%s\n", input);
    }
    close_port(*fd);
    (void)fflush(fp);
    (void)fclose(fp);
    return 0;
}

int  get_file(buf, server, file, port)
char *buf,
     *server,
     *file;
int  *port;
{
    char *p;

    p = (char *)strstr(buf, "://");
    if (p == NULL)
        return 0;
    (void)strcpy(server, p+3);
    if ((p = (char *)strtok(server, ":")) == NULL)
        return 0;
    if ((p = (char *)strtok(NULL, ":")) == NULL)
        return 0;
    *port = atoi(p);
    p = (char *)strchr(p, '/');
    if (p == NULL || *p == '\0')
    {
        (void)strcpy(file, "\n");
        return 0;
    }
    (void)strcpy(file, p+2);
    return 1;
}

int  is_a_file(fname)
char *fname;
{
    struct stat st;

    return (stat(fname, &st) == 0 && S_ISREG(st.st_mode));
}

int  is_a_dir(fname)
char *fname;
{
    struct stat st;

    return (stat(fname, &st) == 0 && S_ISDIR(st.st_mode));
}

int  searchboard(path, title)
char *path,
     *title;
{
    FILE *fn;
    char board[STRLEN],
         buf[1024],
         *ptr;
    int  len;

    (void)strcpy(board, path);
    len = strlen(board);
    path[0] = title[0] = '\0';
    sprintf(buf, "%s/%s/%s", BBSHOME, WORKPATH, SEARCHFILE);
    if (len == 0 || (fn = fopen(buf, "r")) == NULL)
        return 0;
    while(fgets(buf, sizeof(buf), fn) != NULL) 
    {
        if (strncasecmp(buf, board, len) == 0 && buf[len] == ':') 
        {
            while(strchr(": \t", buf[len]) != NULL)
                len++;
            if ((ptr = strchr(buf, '\n')) != NULL)
                *ptr = '\0';
            if (is_gopher_site(&buf[len]))
                (void)strcpy(path, &buf[len]);
            else
                (void)sprintf(path, "%s/%s/%s", BBSHOME, WORKPATH, &buf[len]);
                break;
        }
    }
    (void)fclose(fn);
    len = strlen(path);
    if (len == 0 || !(is_gopher_site(path) || is_a_dir(path))) 
    {
        move(t_lines - 1, 0);
        clrtoeol();
        move(t_lines - 1, 0);
        prints(YEA,"[�j�M����] %s. �Ы����N���~�� ...\n", len ? 
            "�����ؿ�����, �гq�� SYSOP" : "�䤣�� �� ���s�b");
        igetkey();
        return 0;
    }
    (void)strcpy(buf, path);
    if ((ptr = strrchr(buf, '/')) != NULL) 
        (void)strcpy(ptr + 1, ".Names");
    if ((fn = fopen(buf, "r")) == NULL)
    {
        (void)strcpy(title, "Title not found !!");
        return len;
    }
    len = strlen(board);
    while(fgets(buf, sizeof(buf), fn) != NULL) 
    {
        if ((ptr = strchr(buf, '\n')) != NULL)
            *ptr = '\0';
        if (strncmp(buf, "Name=", 5) == 0)
            (void)strcpy(title, buf + 5);
        else if (strncmp(buf, "Path=./", 7) == 0)
        {
            if (strncmp(buf+7, board, len) == 0)
                break;
            else
                (void)strcpy(title, board);
        }
    }
    (void)fclose(fn);

    return len;
}

/* ARGSUSED */
int  faqnum(direct, size)
char *direct;
int  size;
{
    FILE   *fp;
    faqhd  curr;
    struct stat bst;
    char   genbuf[1024],
           date[STRLEN],
           now[STRLEN],
           tmpdir[1024],
           *ptr;
    static int total = 0;

    if (lcached == cached)
        return total;
    lcached = cached;
    total = 0;
    (void)sprintf(genbuf, "%s/.Names", direct);
    if ((fp = fopen(genbuf, "r")) == NULL)
        return 0;
    CreateLinkList();

    while (fgets(genbuf, sizeof(genbuf), fp) != NULL)
    {
        if ((ptr = strchr(genbuf, '\n')) != NULL)
        {
            *ptr = '\0';
        }
        if (strncmp(genbuf, "Name=", 5) == 0)
        {
            (void)strcpy(curr.title, genbuf + 5);
        }
        else if (strncmp(genbuf, "Path=./" , 7) == 0)
        {
            (void)strcpy(curr.path, genbuf + 7);
            if (is_gopher_site(curr.path))
            {
                curr.mode = check_gopher_site(curr.path);
                (void)strcpy(curr.date, "Gopher");
            }
            else
            {
                int exist;

                (void)sprintf(tmpdir, "%s/%s", direct, curr.path);
                exist = stat(tmpdir, &bst);
                if (exist != -1 && S_ISDIR(bst.st_mode))
                    curr.mode = ISDIR;
                else
                    curr.mode = ISFILE;
                (void)strcpy(date, ctime(&bst.st_mtime));
                (void)strcpy(now, ctime(&lastlogin));
                if (exist == -1)
                    strcpy(curr.date, "None ");
                else if (strncasecmp(date + 19, now + 19, 4))
                {
                    (void)strncpy(curr.date, date + 19, 5);
                    date[5] = ' ';
                    date[6] = '\0';
                }
                else
                    (void)strncpy(curr.date, date + 4 , 6);
            }
        }
        else if (strncmp(genbuf, "Owner=" , 6) == 0)
        {
            (void)strcpy(curr.owner, genbuf + 6);
            if (curr.mode != -1)
            {
                total++;
                AddLinkList(&curr, sizeof(faqhd));
            }
        }
    }
    (void)fclose(fp);

    return total;
}

int  gophernum(direct, size)
char *direct;
int  size;
{
    char   input[1024],
           buf[1024],
           server[STRLEN],
           file[STRLEN*2],
           *s1,
           *s2,
           *s3,
           *s4;
    int    port,
           fd;
    faqhd  curr;
    static int total = 0;

    if (lcached == cached)
        return total;
    total = 0;
    lcached = cached;
    (void)strcpy(buf, direct);
    (void)get_file(buf, server, file, &port);
    move(t_lines-1, 0);
    prints(NA, "�j�M��ƨëإ��p����.....\n");
    refresh();
    if (request(server, file, port, &fd) == 0)
    {
        perror("could not talk with server");
        return;
    }
    CreateLinkList();
    while (readport(fd, input) > 0 && strcmp(input, "."))
    {
        s1 = (char *)strtok(input, "\t");
        if (*s1 != '0' && *s1 != '1')
            continue;
        s2 = (char *)strtok(NULL, "\t");
        s3 = (char *)strtok(NULL, "\t");
        s4 = (char *)strtok(NULL, "\t");
        if (s4 == NULL)
        {
            (void)sprintf(curr.path, "gopher://%s:%s/%c%c/", s2, s3, *s1, *s1);
        }
        else
        {
            (void)sprintf(curr.path, "gopher://%s:%s/%c%s", s3, s4, *s1, s2);
        }
        (void)strcpy(curr.title, s1+1);
        curr.mode = (*s1 == '0') ? ISGOFILE : ISGODIR;
        (void)strcpy(curr.date, "Gopher");
        (void)strcpy(curr.owner, "SYSOP");
        AddLinkList(&curr, sizeof(faqhd));
        total++;
    }
    close_port(fd);
    move(t_lines-1, 0);
    clrtoeol();
    return total;
}

void gopherttl()
{
    int n,
        m;

/*    clear();    */
    n = (STRLEN - strlen(faqtitle)) / 2;
    m = 79 - n - strlen(faqtitle);
    prints(NA, "[1;33;44m%*s%s%*s[m\n", n, " ", faqtitle, m, " ");
    prints(NA, " [[1;36m�\\����[m]  [[1;33mH[m]%s%s%s%s",
	" ����   [[1;33mQ[m|[1;33m��[m] ���}",
	"   [[1;33mk[m|[1;33m��[m|[1;33mj[m|",
	"[1;33m��[m] ���ʴ��  [[1;33mEnter[m|",
	"[1;33m��[m] Ū����� \n");
    if (list_by_file_name && clevel >= CBM)
    {
	prints(YEA, "[1;36;44m �Ǹ� ���|                    %s[m\n",
		"                                                 ");
    }
    else
    {
	prints(YEA, "[1;36;44m �Ǹ� [�ݩ�] %s%s[m\n",
		"�D    ��                                     ",
		"                     ");
    }
}

void faqttl()
{
    int n,
        m;

/*    clear();    */
    n = (STRLEN - strlen(faqtitle)) / 2;
    m = 79 - n - strlen(faqtitle);
    prints(NA, "[1;33;44m%*s%s%*s[m\n", n, " ", faqtitle, m, " ");
    if (clevel == CSYSOP)
	prints(NA, " [[1;36m����[m]   [[1;33mH[m]%s%s%s",
		" ����  [[1;33mCTRL-P[m] �s�W�峹  [[1;33mA[m]",
		" ���[�峹  [[1;33mG[m] �[�ؿ�  [[1;33mB[m]",
		" �ܦ��O�D \n");
    else if (clevel == CUSER)
	prints(NA, " [[1;36m�\\����[m]  [[1;33mH[m]%s%s%s%s",
		" ����   [[1;33mQ[m|[1;33m��[m] ���}",
		"   [[1;33mk[m|[1;33m��[m|[1;33mj[m|",
		"[1;33m��[m] ���ʴ��  [[1;33mEnter[m|",
		"[1;33m��[m] Ū����� \n");
    else
	prints(NA, " [[1;36m�O�D[m] [[1;33mH[m]����%s%s%s",
		" [[1;33mQ[m|[1;33m��[m]���} [[1;33mCTRL-P[m]",
		"�s�W�ɮ� [[1;33mA[m]���[�ɮ�[[1;33mG[m]�s�W�ؿ�",
		" [[1;33mE[m]�s���ɮ�\n");
    if (list_by_file_name && clevel >= CBM)
    {
	prints(YEA, "[1;36;44m �Ǹ� [�ɦW         ] �D    ��  %s[m\n",
		"                                       [��  ��]");
    }
    else
    {
	prints(YEA, "[1;36;44m �Ǹ� [�ݩ�] %s%s[m\n",
		"�D    ��                                     ",
		"[��  �z]     [��  ��]");
    }
}

int   faqrec(dirbuf, ptr, size, topln, nument)
char  *dirbuf;
faqhd *ptr;
int   size,
      topln,
      nument;
{
    int ret = 0;

    ret = GetNumLinkList(topln, nument, size, ptr);

    return ret;
}

void  faqent(num, faq)
int   num;
faqhd *faq;
{
    if (list_by_file_name && clevel >= CBM)
    {
	if (faq->mode == ISDIR || faq->mode == ISFILE)
	    prints(NA," %3d. %2s%-13.13s %-48.48s [%6.6s]\n", num,
	    (faq->mode == ISDIR) ? "- " : "F:",
	    faq->path, faq->title, faq->date);
	else
	    prints(NA, " %3d. %.73s\n", num, faq->path+9);
    }
    else
    {
	if (faq->mode == ISDIR)
	    prints(NA," %3d. %s %-57.57s [%6.6s]\n", num,
		"[[1;34m�ؿ�[m]", faq->title, faq->date);
	else if (faq->mode == ISFILE)
	    prints(NA," %3d. %s %-44.44s %-12.12s [%6.6s]\n", num,
		"[[1;33m�ɮ�[m]", faq->title,
		(strcmp(faq->owner, "SYSOP") ? faq->owner : ""), faq->date);
	else
	    prints(NA," %3d. %s %-66.66s\n", num, (faq->mode == ISGODIR) ?
		"[[1;36m�ؿ�[m]" : "[[1;32m�ɮ�[m]", faq->title);
    }
}

int  is_board_manager(str1, name)
char *str1,
     *name;
{
    char tmp[STRLEN],
         *p;

    (void)strcpy(tmp, str1);
    p = strtok(tmp, " ,;:|\\.\t)");
    while (1)
    {
        if (!strcasecmp(p, name))
            return HAS_PERM(PERM_LOCALBM);

        if ((p = strtok(NULL, " ,;:|\\.\t)")) == NULL)
            break;
    }
    return NA;
}

int  valid_path(path)
char *path;
{
    char *c;

    if (path[0] == '\0')
        return 0;
    for (c = path; *c != '\0'; c++)
    {
        if (!((isalpha(*c)) || isdigit(*c) || !strchr(" ()@[]/~", *c)))
            return 0;
    }
    return 1;
}

/* ARGSUSED */
int   append_name(faqinfo, path)
faqhd *faqinfo;
char  *path;
{
    FILE   *fp;
    static int num = 0;

    if (faqinfo == NULL)
    {
        num = 0;
        if ((fp = fopen(path, "w")) == NULL)
            return DOQUIT;
        (void)fprintf(fp, "#\n");
        (void)fflush(fp);
        (void)fclose(fp);
        return 0;
    }

    if (faqinfo->path[0] == '\0')
        return 0;
    if ((fp = fopen(path, "a")) == NULL)
        return DOQUIT;

    (void)fprintf(fp, "Name=%s\n", faqinfo->title);
    (void)fprintf(fp, "Path=./%s\n", faqinfo->path);
    (void)fprintf(fp, "Numb=%d\n", ++num);
    (void)fprintf(fp, "Owner=%s\n#\n", faqinfo->owner);
    (void)fflush(fp);
    (void)fclose(fp);
    return 0;
}

int   comp_faq_path(info, key)
faqhd *info;
char  *key;
{
    return !strcmp(info->path, key);
}

int  rebuild_namefile(path)
char *path;
{
    char genbuf[1014];

    (void)sprintf(genbuf, "%s/%s", path, ".Names");
    (void)append_name(NULL, genbuf);
    ApplyToLinkList(append_name, genbuf);
}

int checklvl()
{
    char buf[STRLEN];

    if (clevel > CUSER)
        return;
    if (HAS_PERM(PERM_SYSOP))
    {
        clevel = CSYSOP;
        return;
    }
    if (HAS_PERM(PERM_ANNOUNBM))
    {
        clevel = CBM;
        return;
    }
    if (strstr(faqtitle, "BD: "))
    {
        (void)strcpy(buf, strstr(faqtitle, "BD: "));
        if (is_board_manager(buf+4 , cuser.userid))
        {
            clevel = (clevel < CBM) ? CBM : clevel;
            return;
        }
    }
    clevel = CUSER;
}

/* ARGSUSED */
int   faq_domenu(direct, faqinfo)
char  *direct;
faqhd *faqinfo;
{
    static int deep = 0;
    char   tmpttl[STRLEN];
    int    localmode,
           stack_level;

    getkeep(direct, 1, 1);
    (void)strcpy(tmpttl, faqtitle);
    (void)strcpy(faqtitle, faqinfo->title);
    localmode = global_mode;
    global_mode = faqinfo->mode;
    CreateLinkList();
    stack_level = clevel;
    checklvl();
    cached++;
    while (1)
    {
        switch (i_read(direct, (global_mode == ISDIR) ? faqttl :
            gopherttl, faqent, faqcmd, CTRL('P'), sizeof(faqhd),
            (global_mode == ISDIR) ? faqnum : gophernum, faqrec))
        {
            case REDOIREAD:
                cached = 1;
                lcached = 0;
                continue;
            default:
                cached--;
                delkeep(direct);
                (void)strcpy(faqtitle, tmpttl);
                global_mode = localmode;
                clevel = stack_level;
                return FULLUPDATE;
        }
    }
}

char *faq_get_gopher(url)
char *url;
{
    struct stat pst;
    static char proxy[1024];
    char   buf[1024],
           server[STRLEN],
           file[STRLEN*2];
    int    port,
           fd;

    (void)strcpy(buf, url);
    (void)strcpy(proxy, make_proxy_file(url));

    if (stat(proxy, &pst) == -1)
    {
        move(t_lines-1, 0);
        prints(NA, ".... �إ߸���p���� ... �еy�� ...\n");
        refresh();
        (void)get_file(buf, server, file, &port);
        if (get_text(proxy, server, file, port, &fd))
            return NULL;
    }
    return proxy;
}

int  faq_read_gopher(url)
char *url;
{
    char *proxy;

    if ((proxy = faq_get_gopher(url)) != NULL)
        more(proxy, YEA);
}

/* ARGSUSED */
int   faq_select(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    char genbuf[1024];

    if (faqinfo->mode == ISFILE || faqinfo->mode == ISDIR)
    {
        (void)sprintf(genbuf, "%s/%s", direct, faqinfo->path);
        if (faqinfo->mode == ISFILE)
            more(genbuf, YEA);
        else if (faqinfo->mode == ISDIR)
            (void)faq_domenu(genbuf, faqinfo);
    }
    else if (faqinfo->mode == ISGOFILE)
        faq_read_gopher(faqinfo->path);
    else
        (void)faq_domenu(faqinfo->path, faqinfo);
    return FULLUPDATE;
}

/* ARGSUSED */
int   faq_help(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
/*    clear();    */
    do_the_help(FAQ_Help);
    pressreturn();
/*    clear();    */
    return FULLUPDATE;
}

/* ARGSUSED */
int   faq_byname(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    if (clevel >= CBM)
    {
        list_by_file_name = !list_by_file_name;
        return FULLUPDATE;
    }
    bell(1);
    return DONOTHING;
}

/* ARGSUSED */
int   faq_forward(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    char fname[1024],
         buf[STRLEN];

    if (!HAS_PERM(PERM_BASIC))
    {
        bell(1);
        return DONOTHING;
    }
    if (faqinfo->mode == ISFILE)
        (void)sprintf(fname, "%s/%s", direct, faqinfo->path);
    else if (faqinfo->mode == ISGOFILE)
    {
        if (faq_get_gopher(faqinfo->path) == NULL)
        {
            move(t_lines-1, 0);
            prints(NA, "..�L�k���o���.. �Ы����~��..\n");
            igetkey();
            move(t_lines-1, 0);
            clrtoeol();
            return DONOTHING;
        }
        (void)strcpy(fname, make_proxy_file(faqinfo->path));
    }
    else
    {
        bell(1);
        return DONOTHING;
    }
    (void)strcpy(buf, cuser.email);
    forward_pre_fix(buf, fname, faqinfo->title);
    return FULLUPDATE;
}

/* ARGSUSED */
int   faq_edit(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    char genbuf[1024];

    if (clevel < CSBM || faqinfo->mode != ISFILE)
    {
        bell(1);
        return DONOTHING;
    }
    (void)sprintf(genbuf, "%s/%s", direct, faqinfo->path);
    vedit(genbuf, NA);
    return REDOIREAD;
}

/* ARGSUSED */
int   faq_rename(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    char  genbuf[STRLEN],
          origin[1024],
          newpath[1024];
    faqhd *curr;

    if (clevel < CBM)
    {
        bell(1);
        return DONOTHING;
    }
    (void)strcpy(genbuf, faqinfo->path);
    getdata(t_lines-1, 0, "[����ɦW] ", genbuf, STRLEN, DOECHO, NA);
    if (strcmp(genbuf, faqinfo->path) && valid_path(genbuf))
    {
        if ((curr = (faqhd *)SearchLinkList(comp_faq_path, faqinfo->path))
	    == NULL)
            return PARTUPDATE;
        (void)sprintf(origin, "%s/%s", direct, faqinfo->path);
        for (;;)
        {
            (void)sprintf(newpath, "%s/%s", direct, genbuf);
            if (is_a_file(newpath))
                break;
            getdata(t_lines-1, 0, "[�ɦW����] ", genbuf, STRLEN, DOECHO, NA);
        }
        (void)rename(origin, newpath);
        (void)strcpy(faqinfo->path, genbuf);
        (void)strcpy(curr->path, genbuf);
        rebuild_namefile(direct);
    }
    return PARTUPDATE;
}

/* ARGSUSED */
int   faq_title(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    char  genbuf[STRLEN];
    faqhd *curr;

    if (clevel < CBM)
    {
        bell(1);
        return DONOTHING;
    }
    (void)strcpy(genbuf, faqinfo->title);
    getdata(t_lines-1, 0, "[���D�D] ", genbuf, STRLEN, DOECHO, NA);
    if (strcmp(genbuf, faqinfo->title) && *genbuf)
    {
        if ((curr = (faqhd *)SearchLinkList(comp_faq_path,
            faqinfo->path)) == NULL)
            return PARTUPDATE;
        (void)strcpy(curr->title, genbuf);
        rebuild_namefile(direct);
    }
    return PARTUPDATE;
}

/* ARGSUSED */
int   faq_delete(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    char  genbuf[1024],
          todo[1048],
          ans[5];
    faqhd *curr;

    if (clevel < CBM)
    {
        bell(1);
        return DONOTHING;
    }
    if (faqinfo->mode == ISDIR || faqinfo->mode == ISFILE ||
        faqinfo->mode == ISGOFILE || faqinfo->mode == ISGODIR)
    {
        move(t_lines-1, 0);
        prints(NA, "�T�w�R�� %s �ܡH", faqinfo->title);
        Getyn(ans);
        if (ans[0] == 'n')
        {
/*            move(t_lines-1, 0);
            clrtoeol();
*/            return    PARTUPDATE;
        }
        (void)sprintf(genbuf, "%s/%s", direct, faqinfo->path);
        if (faqinfo->mode == ISDIR)
        {
            (void)sprintf(todo, "%s/bin/rm -rf %s", BBSHOME, genbuf);
            (void)system(todo);
        }
        else if (faqinfo->mode == ISFILE)
            (void)unlink(genbuf);
        if ((curr = (faqhd *)SearchLinkList(comp_faq_path,
            faqinfo->path)) == NULL)
            return PARTUPDATE;
        (void)memset(curr->path, 0, strlen(curr->path));
        rebuild_namefile(direct);
    }
    return REDOIREAD;
}

int  get_faqhd(direct, path, title, flag)
char *direct,
     *path,
     *title;
int  flag;
{
    char   genbuf[1024];
    struct stat bst;

    do
    {
        getdata(t_lines - 1, 0, (flag == ISFILE) ? "[��J�s�ɦW]: " :
            "[��J�ؿ��W]:" , path, STRLEN, DOECHO, YEA);
        if (path[0] == '\0')
            return NA;
        (void)sprintf(genbuf, "%s/%s", direct, path);
    }
    while (!valid_path(path) || stat(genbuf, &bst) != -1);
    getdata(t_lines - 1, 0, "[��J�D�D]: ", title, STRLEN, DOECHO, YEA);
    if (title[0] == '\0')
        return NA;
    return YEA;
}

/* ARGSUSED */
int   faq_import(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    char   genbuf[STRLEN],
           tmpfile[STRLEN],
           currfile[STRLEN];
    faqhd  curr;
    struct stat bst;

    if (clevel < CBM || global_mode == ISGODIR)
    {
        bell(1);
        return DONOTHING;
    }
    getdata(t_lines-1, 0, "��J�Ȧs�ɦW: ", tmpfile, STRLEN, DOECHO, YEA);
    if (*tmpfile == '\0')
    {
        move(t_lines-1, 0);
        clrtoeol();
        return DONOTHING;
    }
    (void)sprintf(genbuf, "%s/tmp/bd.%s", BBSHOME, tmpfile);
    if (stat(genbuf, &bst) == -1 || S_ISDIR(bst.st_mode) ||
        !get_faqhd(direct, curr.path, curr.title, ISFILE))
    {
        move(t_lines-1, 0);
        clrtoeol();
        return DONOTHING;
    }
    (void)sprintf(currfile, "%s/%s", direct, curr.path);
    copyto(genbuf, currfile);
    (void)unlink(genbuf);
    if (clevel == CSYSOP)
        (void)strcpy(curr.owner, "SYSOP");
    else
        (void)strcpy(curr.owner, cuser.userid);
    AddLinkList(&curr, sizeof(faqhd));
    rebuild_namefile(direct);
    return REDOIREAD;
}

/* ARGSUSED */
int   faq_append(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    char   genbuf[STRLEN],
           tmpfile[1024],
           currfile[STRLEN];
    faqhd  curr;
    struct stat bst;

    if (clevel < CBM || global_mode == ISGODIR)
    {
        bell(1);
        return DONOTHING;
    }
    getdata(t_lines-1, 0, "��J�Ȧs�ɦW: ", tmpfile, STRLEN, DOECHO, YEA);
    if (*tmpfile == '\0')
    {
        move(t_lines-1, 0);
        clrtoeol();
        return DONOTHING;
    }
    sprintf(genbuf, "%s/tmp/bd.%s.%s", BBSHOME, cuser.userid, tmpfile);
    if (stat(genbuf, &bst) == -1 || S_ISDIR(bst.st_mode) ||
        is_gopher_site(faqinfo->path))
    {
        move(t_lines-1, 0);
        clrtoeol();
        return DONOTHING;
    }
    (void)sprintf(currfile, "%s/%s", direct, faqinfo->path);
    (void)sprintf(tmpfile, "%s/bin/cat %s >> %s", BBSHOME, genbuf, currfile);
    (void)system(tmpfile);
    (void)unlink(genbuf);
    return PARTUPDATE;
}

int  get_gopher(url, title)
char *url,
     *title;
{
    int  i = 5;
    char server[STRLEN],
         port[5],
         sty[5],
         path[STRLEN];

    move(3, 0);
    clrtobot();
    move(i++, 0);
    prints(NA, "[�]�w Gopher ��m]\n");
    (void)memset(server, 0, sizeof(server));
    getdata(++i, 0, "[Server]: ", server, STRLEN, DOECHO, YEA);
    if (server[0] == '\0')
        return NA;
    (void)strcpy(port, "70");
    getdata(++i, 0, "[PORT: ]: ", port, 5, DOECHO, NA);
    if (port[0] == '\0')
        return NA;
    getdata(++i, 0, "[PATH: ]: ", path, STRLEN, DOECHO, YEA);
    if (path[0] == '\0')
        return NA;
    sty[0] = '0';
    sty[1] = '\0';
    getdata(++i, 0, "[���A: (0: �ɮ�, 1: ���|)]: ", sty, 4, DOECHO, NA);
    if (sty[0] == '\0' || (sty[0] != '0' && sty[0] != '1'))
        return NA;
    (void)sprintf(url, "gopher://%s:%s/%c%s", server, port, sty[0], path);
    getdata(++i, 0, "[��J�D�D]: ", title, STRLEN, DOECHO, YEA);
    if (title[0] == '\0')
        return NA;
    return YEA;
}

int   faq_create(faqinfo, direct, flag)
faqhd *faqinfo;
char  *direct;
ptype flag;
{
    int ret;

    if (clevel < CBM || global_mode == ISGODIR)
    {
        bell(1);
        return -1;
    }

    if (flag < ISGOFILE)
        ret = get_faqhd(direct, faqinfo->path, faqinfo->title, flag);
    else
        ret = get_gopher(faqinfo->path, faqinfo->title);
    if (!ret)
    {
        move(t_lines-1, 0);
        clrtoeol();
        return -2;
    }
    if (clevel == CSYSOP)
        (void)strcpy(faqinfo->owner, "SYSOP");
    else
        (void)strcpy(faqinfo->owner, cuser.userid);
    AddLinkList(faqinfo, sizeof(faqhd));
    rebuild_namefile(direct);
    return 0;
}

/* ARGSUSED */
int   faq_create_file(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    char  genbuf[1024];
    faqhd curr;

    if (global_mode == ISGODIR)
    {
        move(5, 20);
        prints(NA, "�ܩ�p! �ثe�����L����iŪ�����!\n");
        move(7, 20);
        prints(NA, "�Ы����N��^��W�@�h�ؿ�!!\n");
        igetkey();
        return DOQUIT;
    }
    if (faq_create(&curr, direct, ISFILE))
        return DONOTHING;
    (void)sprintf(genbuf, "%s/%s", direct, curr.path);
    vedit(genbuf, NA);
    return REDOIREAD;
}

/* ARGSUSED */
int   faq_create_group(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    char  genbuf[1024];
    faqhd curr;

    if (faq_create(&curr, direct, ISDIR))
        return DONOTHING;
    (void)sprintf(genbuf, "%s/%s", direct, curr.path);
    (void)mkdir(genbuf, 0755);
    return REDOIREAD;
}

/* ARGSUSED */
int   faq_gopher(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    faqhd curr;

    (void)faq_create(&curr, direct, ISGOFILE);
    return REDOIREAD;
}

/* ARGSUSED */
int   faq_sysopbm(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    switch (clevel)
    {
        case CSYSOP:
            clevel = CSBM;
            return FULLUPDATE;
        case CSBM:
            clevel = CSYSOP;
            return FULLUPDATE;
    }
    bell(1);
    return DONOTHING;
}

/* ARGSUSED */
int   faq_edit_name(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    char genbuf[1024];

    if (clevel <= CBM || global_mode == ISGODIR)
    {
        bell(1);
        return DONOTHING;
    }
    (void)sprintf(genbuf, "%s/%s", direct, ".Names");
    if (is_a_file(genbuf))
        vedit(genbuf, NA);
    return REDOIREAD;
}

/* ARGSUSED */
int   faq_edit_search(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    char buf[STRLEN];

    if (clevel < CSYSOP)
    {
        bell(1);
        return DONOTHING;
    }
    (void)sprintf(buf, "%s/%s/%s", BBSHOME, WORKPATH, SEARCHFILE);
    if (is_a_file(buf))
        vedit(buf, NA);
    return FULLUPDATE;
}

/* ARGSUSED */
int   faq_copy(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    char genbuf[1024];

    if (clevel < CBM || global_mode == ISGODIR)
    {
        bell(1);
        return DONOTHING;
    }
    (void)sprintf(genbuf, "%s/%s", direct, faqinfo->path);
    if (!is_a_file(genbuf) && !is_a_dir(genbuf))
    {
        move(t_lines-1, 0);
        prints(NA, "[���~] %s ���O��r�ɮ�, �L�k�ƻs. [���@���~��]", faqinfo->path);
        igetkey();
        move(t_lines-1, 0);
        clrtoeol();
        return DONOTHING;
    }
    (void)strcpy(copyfile, genbuf);
    (void)memcpy(&copyinfo, faqinfo, sizeof(faqhd));
    move(t_lines-1, 0);
    prints(NA, "[���i] �ƻs�O���w�g����, �Y�n�R��, �Х��i�K, [�����~��]");
    igetkey();
    move(t_lines-1, 0);
    clrtoeol();
    return FULLUPDATE;
}

/* ARGSUSED */
int   faq_save(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    char  genbuf[1024],
          filename[STRLEN];
    faqhd curr;

    if (clevel < CBM || global_mode == ISGODIR)
    {
        bell(1);
        return DONOTHING;
    }
    if (!is_a_file(copyfile) && !is_a_dir(copyfile))
    {
        move(t_lines-1, 0);
        prints(NA, "[���~] �Х��Хܽƻs�ӷ��ɮ�. [�����~��]");
        igetkey();
        move(t_lines-1, 0);
        clrtoeol();
        return DONOTHING;
    }
    (void)strcpy(filename, copyinfo.path);
    while (1)
    {
        (void)sprintf(genbuf, "%s/%s", direct, filename);
        if (!is_a_file(genbuf) && valid_path(filename))
            break;
        getdata(t_lines-1, 0, "�ɦW����, ��J�s�ɦW: ", filename,
            STRLEN, DOECHO, NA);
    }
    if (is_a_file(copyfile))
        copyto(copyfile, genbuf);
    else if (is_a_dir(copyfile))
    {
        char target[1024];

        sprintf(target, "/bin/cp -r %s %s", copyfile, genbuf);
        system(target);
    }
    else
        return PARTUPDATE;
    (void)strcpy(curr.path, filename);
    (void)strcpy(curr.title, copyinfo.title);
    if (clevel == CSYSOP)
        (void)strcpy(curr.owner, "SYSOP");
    else
        (void)strcpy(curr.owner, cuser.userid);
    AddLinkList(&curr, sizeof(faqhd));
    rebuild_namefile(direct);

    return REDOIREAD;
}

#ifdef DOWNLOAD

/* ARGSUSED */
int   faq_download(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    char ans[5],
         path[1024],
         genbuf[1048];
    int  proto;

    if (!HAS_PERM(PERM_BASIC))
    {
        bell(1);
        return DONOTHING;
    }
    if (faqinfo->mode == ISFILE)
        (void)sprintf(path, "%s/%s", direct, faqinfo->path);
    else if (faqinfo->mode == ISGOFILE)
    {
        if (faq_get_gopher(faqinfo->path) == NULL)
        {
            move(t_lines-1, 0);
            prints(NA, "..�L�k���o���.. �Ы����~��..\n");
            igetkey();
            move(t_lines-1, 0);
            clrtoeol();
            return DONOTHING;
        }
        (void)strcpy(path, make_proxy_file(faqinfo->path));
    }
    else
    {
        bell(1);
        return DONOTHING;
    }

    move(3, 0);
    clrtobot();
    prints(NA, "�U���ɮ�: %s\n", faqinfo->title);
    prints(NA, "�ǰe�Ҧ����:\n\n");
    prints(NA, " (1) Kermit\n (2) Xmodem\n (3) Ymodem\n (4) Zmodem\n");
    while (1)
    {
        getdata(10, 0, " ��ܼҦ� [(5) ���]: ", ans, 2, DOECHO, YEA);
        proto = atoi(ans);
        if (proto > 0 && proto < 5)
            break;
        if (proto == 5)
            return FULLUPDATE;
    }
    prints(NA, "�H %s �i����ɤ�......", protos[proto-1].pname);
    reset_tty();
    (void)sprintf(genbuf, "%s %s", protos[proto-1].sendbin, path);
    sh_exec(uinfo.mode, genbuf, NULL);
    restore_tty();
    return FULLUPDATE;
}

#endif

/* ARGSUSED */
int   faq_search(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    char bname[STRLEN];
    bhd  fh;

    clear();
    prints(NA, "[��ܰQ�װ�]\n");
    name_query("��J�Q�װ�: ", bname, make_blist);
    if (bname[0] == '\0' || !search_board(&fh, bname, cmpbname))
    {
        prints(NA, "���w�Q�װϤ��s�b, �L�k�i���ذ��p��.\n");
        pressreturn();
        return REDOIREAD;
    }
    if (faqview(bname) == PARTUPDATE)
        return REDOIREAD;
    return FULLUPDATE;
}

/* ARGSUSED */
int   faq_move(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    int  n;
    char ans[7];

    if (clevel < CBM || global_mode == ISGODIR)
    {
        bell(1);
        return DONOTHING;
    }
    
    getdata(t_lines-1, 0, "��J�s���s��: ", ans, 5, DOECHO, YEA);
    n = atoi(ans);
    if (n == *ent || n == 0)
        return PARTUPDATE;
    DelFromLinkList(comp_faq_path, faqinfo->path);
    InsertLinkList(faqinfo, n, sizeof(faqhd));
    rebuild_namefile(direct);
    return REDOIREAD;
}

int   faq_saveappend(ent, faqinfo, direct)
int   *ent;
faqhd *faqinfo;
char  *direct;
{
    char  genbuf[1024];
    faqhd curr;

    if (clevel < CBM || global_mode == ISGODIR)
    {
        bell(1);
        return DONOTHING;
    }
    if (!is_a_file(copyfile))
    {
        move(t_lines-1, 0);
        prints("NA, [���~] �����w�ӷ��Ψӷ��D�@���r�ɮ�. [�����~��]");
        igetkey();
        move(t_lines-1, 0);
        clrtoeol();
    }
    (void)sprintf(genbuf, "%s/%s", direct, faqinfo->path);
    if (is_a_file(genbuf))
    {
        copyafter(copyfile, genbuf);
        move(t_lines-1, 0);
        prints(NA, "[���i] ���[��r�ɮק���. [�����~��]");
        igetkey();
        move(t_lines-1, 0);
        clrtoeol();
        return DONOTHING;
    }
    move(t_lines-1, 0);
    prints(NA, "[���~] �z�ҭn���[�ت����O��r�ɮ�, �L�k�B�z. [�����~��]");
    igetkey();
    move(t_lines-1, 0);
    clrtoeol();
    return DONOTHING;
}

one_key faqcmd[] =
{
    '/',        faq_search,
    '\n',       faq_select,
    '\r',       faq_select,
    KEY_RIGHT,  faq_select,
#ifdef    DOWNLOAD
    CTRL('D'),  faq_download,        /* file & proxy */
#endif
    CTRL('P'),  faq_create_file,
    'c',        faq_copy,
    'd',        faq_delete,
    'f',        faq_byname,
    'g',        faq_create_group,
    'h',        faq_help,
    'i',        faq_import,
    'r',        faq_select,
    's',        faq_save,
    'v',        faq_edit_name,
    'A',        faq_append,
    'B',        faq_sysopbm,
    'E',        faq_edit,
    'F',        faq_forward,        /* file & proxy */
    'G',        faq_gopher,
    'M',        faq_move,
    'R',        faq_rename,
    'S',        faq_saveappend,
    'T',        faq_title,
    'V',        faq_edit_search,
    '\0',        NULL,
};

int  faqview(board)
char *board;
{
    char  fpath[STRLEN],
          title[STRLEN],
          saveptcb[STRLEN];
    int   savemode = uinfo.mode,
          stack_level = clevel;
    faqhd faqinfo;

    clevel = CUSER;
    cached = lcached = 0;

    BACKUP(uinfo.ptcb, saveptcb);
    if (board && *board)
        if (!check_setting(board, BHD_MYSTERY))
        (void)strncpy(uinfo.ptcb, board, 20);
    else
        (void)memset(uinfo.ptcb, 0, sizeof(uinfo.ptcb));
    changemode(READFAQ);

    if (board)
    {
        (void)strcpy(fpath, board);

        if (searchboard(fpath, title))
        {
            if (!check_setting(board, BHD_MYSTERY))
            (void)strcpy(uinfo.ptcb, board);
            (void)strcpy(faqtitle, title);
        }
        else
        {
            clevel = stack_level;
            RESTORE(uinfo.ptcb, saveptcb);
            changemode(savemode);
            return PARTUPDATE;
        }
    }
    else
    {
        (void)sprintf(fpath, "%s/%s", BBSHOME, WORKPATH);
        (void)strcpy(faqtitle, FAQTITLE);
    }

    (void)strcpy(faqinfo.title, faqtitle);
    faqinfo.mode = ISDIR;
    (void)faq_domenu(fpath, &faqinfo);

    RESTORE(uinfo.ptcb, saveptcb);
    changemode(savemode);
    move(2, 0);
    clrtoeol();
    clevel = stack_level;
    return FULLUPDATE;
}
