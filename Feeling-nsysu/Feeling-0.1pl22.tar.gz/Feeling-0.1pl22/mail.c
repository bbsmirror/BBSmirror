/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw
			   ���崼, Alen@music.nsysu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    SccsId[] = "@(#)mail.c	2.5	5/25/96";
#endif

#include <string.h>
#include <time.h>
#include <sys/file.h>

#include "bbs.h"

extern	void	update_utmp();
extern	userec	cuser,
		muser;
extern	char	save_title[];
extern	int	in_mail,
		t_lines;
extern	usinfo	uinfo;

extern	char	*boardmargin(),
		*Ctime();
extern	int	get_num_records(),
		save_backinfo(),
		get_records(),
		cmpfilename(),
		mailreadhelp(),
		cook_announce(),
		get_title(),
		igetkey();
extern	void	prints();

char	currmaildir[STRLEN];

#ifdef INTERNET_EMAIL
char	forwardto[STRLEN];
#endif

int	mrd,
	delmsgs[1024],
	delcnt;

fhd	mailfh;

void	m_init(lookupu)
userec	lookupu;
{
	(void)sprintf(currmaildir, PATH_MAIL, lookupu.userid, FHDIR);
}

int	chkmail(flag)
int	flag;
{
	static	long	lasttime = 0;
	static	ismail = 0;
	struct	stat	st;
	int	fd;
	register	int	i;
	register	long	numfiles;
	fhd	ch;

	if (flag)
	{
		lasttime = 0;
		ismail = 0;
	}

	if ((fd = open(currmaildir, O_RDONLY)) < 0)
		return (ismail = 0);
	(void)fstat(fd, &st);

	if (lasttime >= st.st_mtime)
	{
        	(void)close(fd);
        	return ismail;
 	}

 	lasttime = st.st_mtime;
 	numfiles = st.st_size;
 	numfiles = numfiles/sizeof(mailfh);

 	if (numfiles <= 0)
	{
		(void)close(fd);
		return (ismail = 0);
	}


	for(i = 0; i < numfiles; i++)
	{
        	(void)read(fd, &ch, sizeof(fhd));

        	if (!(ch.flag & FILE_READ))
		{
        		(void)close(fd);
        		return (ismail = 1);
        	}
    	}
    	(void)close(fd);

    	return (ismail = 0);
}

int     chkmails(lookupu, flag)
userec  lookupu;
int     flag;
{
	m_init(lookupu);
	return chkmail(flag);
}

int	m_exit()
{
	struct	stat	mst;
	int	keep;
	int     max_mail_num;
	static	int      over_limit = 0;
	/* �H��ƶW�L�e�\�d��(max_mail_num+ALLOWOVERMAIL), �w�]�� FALSE */

	m_init(cuser);

	if (stat(currmaildir, &mst) == -1)
		return QUIT;

	if (HAS_PERM(PERM_LOCALBM))
		max_mail_num = MAXBMKEEPMAIL;
	else if (HAS_PERM(PERM_TRUE))
		max_mail_num = MAXTRUEKEEPMAIL;
	else
		max_mail_num = MAXKEEPMAIL;

	if (HAS_PERM(PERM_BBSSYSOP))
		return QUIT;

	if ((keep = mst.st_size / sizeof(fhd)) > max_mail_num)
	{
		if ((keep<=max_mail_num+ALLOWOVERMAIL) && !over_limit)
		{
			move(2, 0);
			prints(NA, "�O�s�H��ƥ� %d �W�X�W�� %d�C�Яd�N�I\n",
			keep, max_mail_num);
			pressreturn();
			return QUIT;
		}
		else
		{
			move(2, 0);
			prints(NA, "�O�s�H��ƥ� %d �W�X�W�� %d, �вM���W�X����\n", keep, max_mail_num);
			over_limit = -1; /* �H��ƶW�L�e�\�d��F */
			return 0;
		}
	}
	else
	{
		over_limit = 0; /* �S���W�L�F */
		return QUIT;
        }
}

int	do_send(mailhd, direct)
fhd	*mailhd;
char	*direct;
{
	char	fname[STRLEN],
		buff[STRLEN],
		fromfile[STRLEN],
		saveptcb[20],
		genbuf[STRLEN];
	struct	stat	st;
	int	ans,
		savemode;

        fhd	newmsg;

	(void)strtok(mailhd->sender, " ");

	if (!getuser(mailhd->sender))
		return -1;

	if (!(muser.userlevel & PERM_READMAIL))
		return -3;

	(void)sprintf(genbuf, PATH_M, mailhd->sender);

	if (stat(genbuf, &st) == -1)
	{
		if (mkdir(genbuf, 0700) == -1) 
			return -1;
	}
	else
	{
		if (!(st.st_mode & S_IFDIR))
			return -1;
	}

	(void)memset(&newmsg, 0, sizeof(newmsg));
	(void)sprintf(fname, "%s/%s/mail/", MYHOME, mailhd->sender);
	in_mail = YEA;
	buildfile(fname);
	in_mail = NA;
	(void)strcpy(newmsg.filename, fname);
	newmsg.date = time(NULL);
	(void)sprintf(genbuf, "%s/%s/mail/%s", MYHOME, mailhd->sender, fname);

	if (!mailhd->title[0])
	{
		if (get_title(NULL, newmsg.title) == QUITPOST)
			return -2;
	}
	else
	{
		clear();
        	if (get_title(mailhd->title, newmsg.title) == QUITPOST)
        		return -2;
        	(void)sprintf(buff, "�ޥέ�l��� (Y)es, (N)o, (A)ll? [Y]: ");
		ans = getans(3, 0, buff, 'y');
		if (ans == 'y' || ans == 'a') 
		{
			(void)sprintf(fromfile, "%s/%s", direct , mailhd->filename);
			include_old(genbuf, fromfile, ans);
	    	}
        }
	(void)strcpy(save_title, newmsg.title);
	(void)strcpy(newmsg.sender, cuser.userid);
	in_mail = YEA;
#ifdef REALINFO
	if (HAS_SET(SET_REALMAIL))
		(void)sprintf(genbuf, "%s (%s)", cuser.userid,
			cuser.realname);
	else
		(void)sprintf(genbuf, "%s (%s)", cuser.userid,
			cuser.username);
#else
	(void)sprintf(genbuf, "%s (%s)", cuser.userid, cuser.username);
#endif
	(void)sprintf(genbuf, PATH_MAIL, mailhd->sender, fname);

	savemode = uinfo.mode;
	BACKUP(uinfo.ptcb, saveptcb);
	(void)memset(uinfo.ptcb, 0, sizeof(uinfo.ptcb));
	changemode(SMAIL);

	save_backinfo('M', save_title, mailhd->sender, YEA);
	if (vedit(genbuf, YEA) == -1)
	{
		if (stat(genbuf, &st) != -1)
	        	(void)unlink(genbuf);
		RESTORE(uinfo.ptcb, saveptcb);
		changemode(savemode);
		clear();
	     	return -2;
	}

	RESTORE(uinfo.ptcb, saveptcb);
	changemode(savemode);

	clear();
	(void)sprintf(genbuf, PATH_MAIL, mailhd->sender, FHDIR);
        if (append_record(genbuf, (char *)&newmsg, sizeof(newmsg)) == -1)
		return -1;
	return 0;
}

#ifdef	INTERNET_EMAIL
/*
 * �ˬd email-address �O�_���T
 * return:  0. �����~�o��; 1. ���`, �i�e�H; 2. �O IP ADDRESS
 */
int	check_host(email)
char	*email;
{
	char	tmp[STRLEN];
	int	i,
		ip = TRUE;

	if (strstr(email, "modem.bbs.user"))
		return 0;

	if (strchr(email, '@'))
		(void)strcpy(tmp, (char *)strchr(email, '@')+1);

	for (i = 0; i < strlen(tmp); i++)
	{
		if (isalpha(tmp[i]))
		{
			ip = FALSE;
			break;
		}
	}

	if (tmp[0] == '[' && tmp[strlen(tmp)-1] == ']')
		return (ip == TRUE) ? 2 : 0;

	return (gethostbyname(tmp) ? 1 : 0);
}

int	deliver_email(filename, fwardto, title)
char	*filename,
	*fwardto,
	*title;
{
	char	buf[255],
		tmpbuf[255],
		HOST[STRLEN],
		c;
	struct	sockaddr_in	sin;
	struct	hostent	*host;
	int	mfd,
		fd,
		ip;

	if ((ip = check_host(fwardto) - 1) < 0)
		return -2; /* e-mail address error */

	if ((fd = open(filename, O_RDONLY)) == -1)
		return -3; /* file not exist */

#ifdef	MAILSERVER
	(void)strcpy(HOST, MAILSERVER);
#else
	(void)strcpy(HOST, MYHOSTNAME);
#endif
	clear();
	prints(NA, "\n\n�� mail-server: %s �e�H��.....\n", HOST);
	refresh();
	(void)memset(&sin, 0, sizeof(sin));

	sin.sin_family = AF_INET;
	sin.sin_port = htons(25);

	if (ip)
	{
		sin.sin_addr.s_addr = inet_addr(HOST);
	}
	else
	{
		host = gethostbyname(HOST);
		(void)memcpy(&sin.sin_addr.s_addr, host->h_addr_list[0],
			host->h_length);
	}

	mfd = socket(AF_INET, SOCK_STREAM, 0);
	if (mfd < 0)
		return -2;	/* service unreachable */
	if (connect(mfd, (struct sockaddr *)&sin, sizeof(sin)) < 0)
		return -2;

        (void)sprintf(buf, "HELO %s\n", HOST);
        (void)write(mfd, buf, strlen(buf));
	while (1)
	{
		readport(mfd, tmpbuf);
		if (atoi(tmpbuf) ==  250)
			break;
		if (atoi(tmpbuf) > 400)
		{
			(void)close(mfd);
			return -1;
		}
	}

        (void)sprintf(buf, "MAIL From:<%s.bbs@%s>\n", cuser.userid, MYHOSTNAME);
        (void)write(mfd, buf, strlen(buf));
	readport(mfd, tmpbuf);
	if (strstr(tmpbuf, "250") != tmpbuf)
	{
		prints(NA, "[%.3s] �o�H�H�ӷ������T\n", tmpbuf);
		(void)close(mfd);
		return -1;
	}
        (void)sprintf(buf, "RCPT To:<%s>\n", fwardto);
        (void)write(mfd, buf, strlen(buf));
	readport(mfd, tmpbuf);
	if (strstr(tmpbuf, "250") != tmpbuf)
	{
		prints(NA, "[%.3s] ���H�H���w���~\n", tmpbuf);
		(void)close(mfd);
		return -1;
	}

        (void)sprintf(buf, "DATA\n");
        (void)write(mfd, buf, strlen(buf));
	readport(mfd, tmpbuf);
	if (strstr(tmpbuf, "354") != tmpbuf)
	{
		prints(NA, "[%.3s] �t�Τ������e�H����\n", tmpbuf);
		(void)close(mfd);
		return -1;
	}
	(void)sprintf(buf, "To: %s\n", fwardto);
        (void)write(mfd, buf, strlen(buf));

	(void)sprintf(buf, "Subject: %s\n\n", title);
	(void)write(mfd, buf, strlen(buf));
	while (read(fd, &c, 1) > 0)
		(void)write(mfd, &c, 1);
	(void)close(fd);

	(void)sprintf(buf, "\n.\n");
	(void)write(mfd, buf, sizeof(buf));
	readport(mfd, tmpbuf);
	if (strstr(tmpbuf, "250") != tmpbuf)
	{
		prints(NA, "[%.3s] �L�k�����e�H����\n", tmpbuf);
		(void)close(mfd);
		return -1;
	}

	(void)sprintf(buf, "QUIT\n");
	(void)write(mfd, buf, sizeof(buf));
	readport(mfd, tmpbuf);
	if (strstr(tmpbuf, "221") != tmpbuf)
	{
		prints(NA, "[%.3s] �L�k���`�����e�H����\n", tmpbuf);
		(void)close(mfd);
		return -1;
	}
	prints(NA, "[%.3s] �H�󻼰e����.\n", tmpbuf);

	refresh();
	(void)close(mfd);
	(void)unlink(filename);

	return 0;
}

int	forward_pre_fix(forwardto, filename, title)
char	*forwardto,
	*filename,
	*title;
{
	char	buff[STRLEN],
		fname[1024];
	static	char	fwardto[STRLEN] = "";
	int	ch;
	time_t	now;

	(void)sprintf(fname, PATH_FORWARD, cuser.userid);
	if (fwardto[0] == '\0')	strcpy(fwardto, forwardto);
	while (1)
	{
		clear();
		prints(NA, "\nForward article to: %s", fwardto);
		prints(NA, "\nIs this correct?(Y/N/Q) [Y] ");
		ch = igetkey();
		if (ch == 'q' || ch == 'Q')
			return -3;
		if (ch == 'N' || ch == 'n' || ch == KEY_LEFT)
		{
			getdata(4, 0, "Input E-mail: ", buff, STRLEN, DOECHO,
				YEA);
			if (buff[0])
				(void)strcpy(fwardto, buff);
			else
				continue;
		}
		break;
	}
	prints(NA, "\nWould you want to uuencode it? (Yes/No/Abort) [N] ");
	ch = igetkey();
	if (ch == 'A' || ch == 'a')
		return -3;

	if (ch == 'Y' || ch == 'y' || ch == KEY_RIGHT)
	{
		(void)time(&now);
		(void)memset(buff, 0, sizeof(buff));
		(void)sprintf(buff, "/usr/bin/uuencode %s bbs.%d > %s", filename,
			now, fname);
	  	(void)system(buff);
	}
	else
	{
		if (copyto(filename, fname) != 0)
			return -1;
	}
	(void)strcpy(filename, fname);
	return deliver_email(filename, fwardto, title);
}

int	doforward(direct, fh, fwardto)
char	*direct;
fhd	*fh;
char	*fwardto;
{
	char	filename[STRLEN],
		title[STRLEN];

	(void)sprintf(filename, "%s/%s", direct, fh->filename);
	(void)strcpy(fwardto, cuser.email);
	(void)strcpy(title, fh->title);

	return forward_pre_fix(fwardto, filename, title);
}


#endif

int	send_internet(fname, email, title)
char	*fname,
	*email,
	*title;
{
	char	errmail[STRLEN],
		inbuff[STRLEN],
		genbuf[STRLEN];
	fhd	minfo;
	FILE	*ferr,
		*source;
	time_t	now;
	int	result;

	(void)memset(errmail, 0, sizeof(errmail));
	if (vedit(fname, NA) < 0)
		return -1;
	if ((result = deliver_email(fname, email, title)) < 0)
	{
		if ((source = fopen(fname, "r")) == NULL)
			return FULLUPDATE;
		(void)sprintf(errmail, PATH_M, cuser.userid);
		buildfile(errmail);
		(void)strcpy(minfo.filename, errmail);
		minfo.date = time(NULL);
		(void)sprintf(errmail, PATH_MAIL, cuser.userid, minfo.filename);
		(void)strncpy(minfo.sender, cuser.userid, 76);
		switch (result)
		{
			case -3:
				(void)sprintf(minfo.title, "�ɮ� [%s] ��", fname);
				break;
			default:
				(void)sprintf(minfo.title, "����B���~ [%s]", email);
				break;
		}
		(void)strcpy(save_title, minfo.title);
		if ((ferr = fopen(errmail, "w")) == NULL)
		{
			(void)fclose(source);
			(void)unlink(fname);
			return FULLUPDATE;
		}
		(void)write_header(ferr);
		(void)time(&now);
		(void)fprintf(ferr, "��H�b %s �e�� %s\n", Ctime(&now), email);
		(void)fprintf(ferr, "�H��D�D�O: %s\n", title);
		(void)fprintf(ferr, "\n------ ��H�󤺮e�p�U�ҥ� ------\n\n");
	        while (fgets(inbuff, sizeof(inbuff), source) != NULL) 
			(void)fprintf(ferr, "%s", inbuff);
		(void)fclose(ferr);
		(void)fclose(source);
		(void)unlink(fname);
		(void)sprintf(genbuf, PATH_MAIL, minfo.sender, FHDIR);
		if (append_record(genbuf, (char *)&minfo, sizeof(fhd)) == -1)
			(void)unlink(errmail);
	}
	return FULLUPDATE;
}

int     reply_inter(mailhd, direct)
fhd     *mailhd;
char    *direct;
{
        fhd     minfo;
        char    buff[STRLEN],
                tfile[STRLEN],
                source[STRLEN];
        int     ans;

        if (!(cuser.userlevel & PERM_INTER))
                return -3;
        if (!check_host(mailhd->sender))
	{
		prints(NA, "E-mail Address not found: %s\n", mailhd->sender);
		pressreturn();
                return -1;
	}
        (void)memset(&minfo, 0, sizeof(minfo));
        clear();
        (void)sprintf(tfile, PATH_TMPFILE, cuser.userid);
        if (get_title(mailhd->title, minfo.title) == QUITPOST)
                return -2;
        (void)sprintf(buff, "�ޥέ�l��� (Y)es, (N)o, (A)ll? [Y]: ");
        ans = getans(3, 0, buff, 'y');
        if (ans == 'y' || ans == 'a')
        {
                (void)sprintf(source, "%s/%s", direct, mailhd->filename);
                include_old(tfile, source, ans);
        }
        return send_internet(tfile, mailhd->sender, minfo.title);
}

int	m_inter()
{
	char	tfile[STRLEN],
		sendto[STRLEN],
		title[STRLEN];

	(void)sprintf(tfile, PATH_TMPFILE, cuser.userid);
	getdata(0, 0, ASK_RECEIVER, sendto, STRLEN, DOECHO, YEA);
	if (sendto[0] == '\0' || !check_host(sendto))
		return -1;
	(void)memset(title, 0, sizeof(title));
	if (get_title(NULL, title) == QUITPOST)
		return -2;
	return send_internet(tfile, sendto, title);
}

int	mail_do_send(uident)
char	*uident;
{
	char	genbuf[STRLEN];
	fhd	mailinfo;

	(void)memset(&mailinfo, 0, sizeof(fhd));
	(void)strcpy(mailinfo.sender, uident);
	(void)sprintf(genbuf, PATH_M, cuser.userid);
	switch (do_send(&mailinfo, genbuf))
	{
		case -1:
			prints(NA, "Bad UserId\n");
			break;
	  	case -2:
			prints(NA, "Mail Aborted\n"); 
			break;
	  	case -3: 
			prints(NA, "User '%s' cannot receive mail\n", uident); 
			break;
	  	default: 
			prints(NA, "File Sent\n");
			break;
	}
	pressreturn();
	return 0;
}

int	m_send()
{
	char	uident[STRLEN];

	if (!strcmp(cuser.userid, GUEST))
	{
		clrtobot();
		note_sysop();
		return	0;
	}

	if (!init_namelist(uident))
		return 0;

	(void)mail_do_send(uident);
	return 0;
}

/* ARGSUSED */
int     mail_reply(ent, mailinfo, direct)
int     *ent;
fhd     *mailinfo;
char    *direct;
{
        if (strchr(mailinfo->sender, '@') && HAS_PERM(PERM_INTER))
		(void)reply_inter(mailinfo, direct);
        else
        {
                switch (do_send(mailinfo, direct))
                {
                        case -1:
                                prints(NA, "Could not send to: %s\n",
					mailinfo->sender);
                                break;
                        case -2:
                                prints(NA, "Reply Aborted\n");
                                break;
                        case -3:
                                prints(NA, "User '%s' cannot receive mail\n",
                                        mailinfo->sender);
                                break;
                        default:
                                prints(NA, "File Sent\n");
                }
        }
        pressreturn();

        return FULLUPDATE;
}

int     mail_reply_auth(oldfile)
fhd     *oldfile;
{
        char    genbuf[STRLEN];

        if (uinfo.mode == MSYSOP)
                (void)sprintf(genbuf, PATH_M, ADMIN);
        else
                (void)sprintf(genbuf, PATH_M, cuser.userid);
        if (!oldfile->title[0])
                (void)strcpy(oldfile->title, "Re: ");
        return mail_reply(0, oldfile, genbuf);
}

int     mail_reply_forward(oldfile, email)
fhd     *oldfile;
int     email;
{
        char    namebuf[STRLEN],
                bufdir[STRLEN];
        fhd     mailbuf;

        if (email && HAS_PERM(PERM_TRUE))
        {
                getdata(0, 0, ASK_RECEIVER, namebuf, STRLEN, DOECHO, YEA);
                if (namebuf[0] == '\0')
                        return -1;
        }
        else
        {
                if (!init_namelist(namebuf))
                        return -1;
        }
        if (uinfo.mode == MSYSOP)
                (void)sprintf(bufdir, PATH_M, ADMIN);
        else
                (void)sprintf(bufdir, PATH_M, cuser.userid);
        (void)strcpy(mailbuf.sender, namebuf);
        if (!oldfile->title[0])
                (void)strcpy(oldfile->title, "Re: ");
        (void)strcpy(mailbuf.title, oldfile->title);
        (void)strcpy(mailbuf.filename, oldfile->filename);
        return mail_reply(0, &mailbuf, bufdir);
}

int     mail_reply_direct(ent, mailinfo, direct)
int     *ent;
fhd     *mailinfo;
char    *direct;
{
	char	buf[STRLEN];

	(void)strcpy(buf, direct);
	buf[strlen(buf)-6] = '\0';

	return mail_reply(ent, mailinfo, buf);
}

int	read_mail(fptr)
fhd	*fptr;
{
	char	genbuf[STRLEN];

	(void)sprintf(genbuf, PATH_MAIL, cuser.userid, fptr->filename);
	more(genbuf, NA);
	fptr->flag |= FILE_READ;
	return 0;
}

int	read_new_mail(fptr)
fhd	*fptr;
{
	static	int	idc;
	char	delete_it,
		genbuf[4],
		cmaildir[100];

	(void)sprintf(cmaildir, PATH_MAIL, cuser.userid, FHDIR);

	if (fptr == NULL)
	{
		delcnt = 0;
		idc = 0;
		return 0;
	}

	idc++;
	if (fptr->flag & FILE_READ)
		return 0;

	(void)read_mail(fptr);
	mrd = 1;

	if (switch_record(cmaildir, (char *)fptr, sizeof(fhd), idc))
		return -1;
	delete_it = NA;

	move(t_lines-1, 0);
	clrtoeol();
        prints(NA, "\[�\\Ū�H��] %s %s %s %s",
                "[[1;33mR[m]�^�H [[1;33mD[m]�R��",
                "[[1;33mF[m]�൹���� [[1;33mE[m]��쯸�~",
                "[[1;33mG[m|[1;33mEnter[m]�U�@��",
		"[[1;33mQ[m|[1;33m��[m]���� ");
	switch(igetkey())
	{
		case 'q':
		case 'Q':
		case KEY_LEFT:
			clear();
			return QUIT;
    		case 'd':
		case 'D': 
      			delete_it = YEA;
      			break;
    		case 'r':
		case 'R':
			(void)mail_reply_auth(fptr);
			break;
    		case 'E':
		case 'e':
			(void)mail_reply_forward(fptr, YEA);
			break;
		case 'f':
		case 'F':
			(void)mail_reply_forward(fptr, NA);
			break;
  		default:
      			break;
	}
    	if (delete_it)
	{
/*		clear();
*/		move(t_lines-1, 0);
		prints(NA, "�T�w�R���H�� '%s' �ܡH", fptr->title);
        	Getyn(genbuf);
        	if (genbuf[0] == 'Y' || genbuf[0] == 'y')
		{
	  		(void)sprintf(genbuf, PATH_MAIL, cuser.userid,
				fptr->filename);
	  		(void)unlink(genbuf);
	  		delmsgs[delcnt++] = idc;
		}
    	}
/*    	clear();	*/
    	return 0;
}

int	m_new()
{
	clear();
	mrd = 0;

	changemode(RMAIL);

	(void)read_new_mail(NULL);
	m_init(cuser);
	if (apply_record(currmaildir, read_new_mail, sizeof(fhd)) == -1)
	{
		clear();
		move(0, 0);
		prints(NA, "No new messages\n\n\n");

		changemode(MAIL);

		return -1;
	}

	if (delcnt >= 0)
	{
		while (delcnt--)
			delete_record(currmaildir, sizeof(fhd),
				delmsgs[delcnt]);
	}
	clear();
	move(0, 0);
	if (mrd)
		prints(NA, "No more messages.\n\n\n");
	else
		prints(NA, "No new messages.\n\n\n");

	changemode(MAIL);

	return -1;
}

void	mailtitle()
{
/*	move(0, 0);
	clrtobot();
*/	menu_draw("[�H��B�z]", boardmargin);
	prints(NA, "%s   %s   %s   %s\n",
		"[[1;33m��[m,[1;33me[m]�^�W�@�e��",
		"[[1;33mh[m]�D�U",
		"[[1;33m��[m,[1;33mr[m,[1;33m<cr>[m]Ū����ЩҦb�峹",
		"[[1;33m��[m,[1;33m��[m]�W,�U�@�g�峹");

        prints(YEA, "[1;44;36m �s��   %-15s %-6s  %-47s\n[m","�H��H","���","����");
}

void	maildoent(num, ent)
int	num;
fhd	*ent;
{
	char	b2[512],
		status,
		*t,
		*date;

	if (ent->date > 740000000)
		date = Ctime(&ent->date) + 4;
	else
		date = Ctime(&ent->date) + 20;

	(void)strncpy(b2, ent->sender, STRLEN);

	if (t = strchr(b2, ' '))
		*t = '\0';

	if (ent->flag & FILE_READ)
	{
		if (ent->flag & FILE_MARKED)
			status = 'm';
		else
			status = ' ';
	}
	else
	{
		if (ent->flag & FILE_MARKED)
			status = 'M';
		else
			status = 'N';
	}

	if (strstr(ent->title, "Re: ") == ent->title)
		prints(NA, " %4d %c %-15.15s %6.6s  %-47.47s\n", num, status,
			b2, date, ent->title);
	else
		prints(NA, " %4d %c %-15.15s %6.6s  �� %.40s ��\n", num,
			status, b2, date, ent->title);
}

#ifdef INTERNET_EMAIL
/* ARGSUSED */
int	mail_forward(ent, fileinfo, direct)
int	*ent;
fhd	*fileinfo;
char	*direct;
{
	char	buf[STRLEN],
		*p;
	int	save_pager,
		save_mode;

	if (!HAS_PERM(PERM_FORWARD))
	{
		bell(1);
		return DONOTHING;
	}
	save_mode = uinfo.mode;
	save_pager = uinfo.pager;
	update_utmp();

	(void)strncpy(buf, direct, sizeof(buf));

	if ((p = strrchr(buf, '/')) != NULL)
		*p = '\0';
	clear();

	switch (doforward(buf, fileinfo, forwardto))
	{
		case 0:
			prints(NA, "\nForward Article to: %s\n", forwardto);
			break;
		case -1:
			prints(NA, "\nForward failed: Host cannot find\n");
			prints(NA, "Set E-mail address by: (X)yz - (I)nfo\n");
			break;
		case -2:
			prints(NA, "\nForward failed: Service unavailable\n");
			break;
		case -3:
			prints(NA, "\nForward aborted.\n");
	  		break;
		default:
	  		break;
	}
	pressreturn();
	clear();
        uinfo.pager = save_pager;
	changemode(save_mode);

	return FULLUPDATE;
}
#endif

/* ARGSUSED */
int	mail_del(ent, fileinfo, direct)
int	*ent;
fhd	*fileinfo;
char	*direct;
{
	char	buf[512],
		genbuf[STRLEN],
		*t;

	move(t_lines-1, 0);
	prints(NA, "�T�w�R���H�� '%s' �ܡH", fileinfo->title);
	Getyn(genbuf);

	if (genbuf[0] != 'y')	return FULLUPDATE;

	(void)strcpy(buf, direct);
	if (t = strrchr(buf, '/'))
		*t = '\0';

	if (!delete_file(direct, sizeof(*fileinfo), *ent, cmpfilename,
		fileinfo->filename))
	{
		(void)sprintf(genbuf, PATH_MAIL, (uinfo.mode == MSYSOP) ? "SYSOP" :
			cuser.userid, fileinfo->filename);
		(void)unlink(genbuf);
		return FULLUPDATE;
	}

	move(t_lines-1, 0);
	clrtoeol();
	prints(NA, "Delete failed");

	return FULLUPDATE;
}

/* ARGSUSED */
int	mail_read(ent, fileinfo, direct)
int	*ent;
fhd	*fileinfo;
char	*direct;
{
	char	buf[512],
		notgenbuf[128],
		cmaildir[100],
		*t,
		done = NA,
		delete_it;
	int	ans;

	clear();
	(void)strcpy(buf, direct);
	if (t = strrchr(buf, '/'))
		*t = '\0';
	(void)sprintf(cmaildir, "%s/%s", buf, FHDIR);
	(void)sprintf(notgenbuf, "%s/%s", buf, fileinfo->filename);
	delete_it = NA;

	while (!done)
	{
		more(notgenbuf, NA);
		move(t_lines-1, 0);
		clrtoeol();
                prints(NA, "\[�\\Ū�H��] %s %s %s",
                	"[[1;33mR[m]�^�H [[1;33mD[m]�R��",
                	"[[1;33mF[m]�൹���� [[1;33mE[m]��쯸�~",
                	"[[1;33mG[m|[1;33mEnter[m]�U�@�� [[1;33mQ[m|[1;33m��[m]���� ");
                
		switch (ans = igetkey())
		{
			case 'd': case 'D':
				delete_it = YEA;
				done = YEA;
				break;
			case 'r': case 'R':
				(void)mail_reply_auth(fileinfo);
				done = NA;
				break;
                	case 'f': case 'F':
				(void)mail_reply_forward(fileinfo, NA);
				done = NA;
				break;
			case 'E': case 'e':
				(void)mail_reply_forward(fileinfo, YEA);
				done = NA;
				break;
			case 'G': case 'g': case '\n':
			case KEY_RIGHT: case KEY_DOWN:
				ans = 'g';
				done = YEA;
				break;
	        	default:	
	        		done = YEA;
	        		break;
		}
	} 
	if (delete_it)
		(void)mail_del(ent, fileinfo, direct);
	else
	{
		fileinfo->flag |= FILE_READ;
#ifdef POSTBUG
		if (replied)
			bug_possible = YEA;
#endif
		switch_record(cmaildir, (char *)fileinfo,
			sizeof(*fileinfo), *ent);
#ifdef POSTBUG
		bug_possible = NA;
#endif
	}

	return (ans == 'g') ? READ_NEXT : FULLUPDATE;
}

/* ARGSUSED */
int	mail_del_range(ent, fileinfo, direct)
int	*ent;
fhd	*fileinfo;
char	*direct;
{
	return del_range(ent, (fhd *)fileinfo, direct);
}

/* ARGSUSED */
int	mail_query(ent, fileinfo, direct)
int	*ent;
fhd	*fileinfo;
char	*direct;
{
	if (strchr(fileinfo->sender, '@') || !searchuser(fileinfo->sender))
		return DONOTHING;
/*	clear();	*/
	show_plan(YEA, fileinfo->sender, prints);
	pressreturn();
	return FULLUPDATE;
}

/* ARGSUSED */
int	mail_mark(ent, fileinfo, direct)
int	*ent;
fhd	*fileinfo;
char	*direct;
{
	char	cmaildir[100],
		buf[80],
		*t;

	(void)strcpy(buf, direct);
	if (t = strrchr(buf, '/'))
		*t = '\0';
	(void)sprintf(cmaildir, "%s/%s", buf, FHDIR);

	if (fileinfo->flag & FILE_MARKED)
		fileinfo->flag &= ~FILE_MARKED;
	else
		fileinfo->flag |= FILE_MARKED;

	switch_record(cmaildir, (char *)fileinfo, sizeof(*fileinfo), *ent);

	return(PARTUPDATE);
}

one_key  mail_comms[] =
{
	CTRL('J'), 	mailreadhelp,
	'D', 		mail_del_range,
#ifdef INTERNET_EMAIL
	'F', 		mail_forward,
#endif
	'Q',		mail_query,
	'R', 		mail_reply_direct,
	'a', 		cook_announce,
	'd', 		mail_del,
	'h', 		mailreadhelp,
	'm', 		mail_mark,
	'r', 		mail_read,
	'\n', 		mail_read,
	'\r', 		mail_read,
	KEY_RIGHT, 	mail_read,
	'\0', 		NULL,
};

int	m_admin()
{
	char	mailpath[100];

	changemode(MSYSOP);

	in_mail = YEA;
	(void)sprintf(mailpath, PATH_MAIL, ADMIN, FHDIR);
	i_read(mailpath, mailtitle, maildoent, &mail_comms[0], 's',
		sizeof(fhd), get_num_records, get_records);

	in_mail = NA;
	changemode(MAIL);
	move(2, 0);
	clrtoeol();
	return 0;
}

int	m_read()
{
	changemode(RMAIL);

	in_mail = YEA;
	i_read(currmaildir, mailtitle, maildoent, &mail_comms[0], 's',
		sizeof(fhd), get_num_records, get_records);

	in_mail = NA;
	changemode(MAIL);
	move(2, 0);
	clrtoeol();
	return 0;
}

int	abort_send()
{
        clear();
        prints(NA, "���e�H!!");
        in_mail = NA;
        changemode(MAIL);
        pressreturn();
        return QUIT;
}

int	include_friend()
{
        char    buf[STRLEN];
        int     blen, 
        	ch,
        	all = 0;
        FILE    *fp;
        struct  stat    st;
        
        (void)sprintf(buf, PATH_OVERRIDE, cuser.userid, "override");

        if ((fp = fopen(buf, "r")) == NULL)
                return -1;     
        buf[0] = '\0';
        while (fgets(buf, STRLEN, fp) != NULL)
        {
                blen = strlen(buf);
                if (buf[blen-1] == '\n' && blen > 0 && ch != 'q')
                {
                        buf[--blen] = '\0';
                        if (!all)
                        {
                        	clear();
                        	move(1, 0);
                        	prints(NA, "�n�B�� %s \n", buf);
                        	ch = getans(3, 0, "(Y)�[�J�W��, (N)���L, (A)�����[�J, (Q)�������L [A]: ", 'a');
                        	if (ch == 'a' || ch == 'q')
                        		all = YEA;
                        }
                        else 
                        {
                        	move(1, 0);
                        	clrtoeol();
                        	prints(NA, "[%s] �n�B�� %s \n", (ch == 'y' ||
					ch == 'a') ? "�[�J" : "���L", buf);
				refresh();
                        }			   
                        if (ch == 'y' || ch == 'a')
	                        addtooverride(buf, "maillist");
                        buf[0] = '\0';
                }
        }
        (void)fclose(fp);
        return;
}

void	serrmsg(serrno)
int	serrno;
{
	char	*errmsgs[7] = 
	{
		"[1;33mOK !![m\n",
		"[����] �S���o�ӤH\n",
		"[����] �L�k�ثH�c�ؿ�\n",
		"[����] �s�b�۩M�H�c�ؿ��P�W���ɮ�!!\n",
		"[����] �L�k��s�O����\n",
		"[����] �L�k�����ɮ�\n",
		"[����] ������]\n",
	};

	if (serrno < 0 || serrno > 6)
		prints(NA, "%s", errmsgs[6]);
	else
		prints(NA, "%s", errmsgs[serrno-1]);
}

int	mailsend(mailinfo, sname, userid)
fhd     *mailinfo;
char    *sname,
        *userid;
{
        struct  stat    st;
        fhd	mailhd;
        char    fname2[STRLEN];
        char    genbuf[STRLEN];

        if (userid[0] != '\0' && userid[0] != ' ')
        {

                if (!getuser(userid))
                        return 2; 
                else
                {
                        (void)sprintf(fname2, "%s/%s/mail/", MYHOME, userid);
                        if (stat(fname2, &st) == -1)
                        {
                                if (mkdir(fname2, 0700) == -1)
                                return 3; 
                        }
                        else
                        {
                                if (!(st.st_mode & S_IFDIR))
                                return 4;
                        }
                        buildfile(fname2);
                        (void)sprintf(genbuf, PATH_MAIL, userid, fname2);
                        (void)strcpy(mailhd.filename, fname2);
			mailhd.date = time(NULL);
                        (void)strcpy(mailhd.sender, mailinfo->sender);
                        (void)strcpy(mailhd.title, save_title);
                        if (copyto(sname, genbuf) != 0)
                        	return 6;
                        mailhd.flag = NA;
                        (void)sprintf(genbuf, PATH_MAIL, userid, FHDIR);
                        if (append_record(genbuf, &mailhd, sizeof(fhd)) == -1)
                                return 5;
                        else
                                return 1;  
                }
        }
}

int	getinfo(mailinfo)
fhd	*mailinfo;
{
	char	genbuf[STRLEN],
		fname[STRLEN];

	if (get_title(NULL, save_title) == QUITPOST)
        {
                return abort_send();
        }
	changemode(SMAIL);
        (void)strcpy(mailinfo->title, save_title);
        (void)strncpy(mailinfo->sender, cuser.userid, STRLEN);
        (void)sprintf(genbuf, "tmp/%s", cuser.userid);
	in_mail = YEA;
        if (vedit(genbuf, YEA) == -1)
        {
                return abort_send();
        }
	in_mail = NA;
	changemode(MAIL);
	return 0;
}

int	start_sending(userid, mailfile)
char	*userid;
fhd	*mailfile;
{
    	char 	fname[STRLEN];

	(void)sprintf(fname, "tmp/%s", cuser.userid);
	prints(NA, "Sending %-15s ===> ", userid);
        serrmsg(mailsend(mailfile, fname, userid));
        return 0;
}

int	listmailtable(seed)
char	*seed;
{
	return listfriends("maillist", seed);
}

int     m_multisend()
{
        char    uident[STRLEN];
        int     ans,
                count;
        fhd	mailhd;

        while (YEA) 
        {
                clear();
                prints(NA, MAIL_EDIT_MAILLIST);
                count = listmailtable(NULL);
		query_name_list(NULL, 0);
                if (count)
                        ans = getans(1, 0, TALK_ADDMAILLIST, 'e');
                else 
                        ans = getans(1, 0, TALK_NEWMAILLIST, 'e');
                if (ans == 'a') 
                {
                        if (init_namelist(uident))
                                addtooverride(uident, "maillist");
                }
                else if (ans == 'I' || ans == 'i')
                {
			(void)include_friend();
                }
                else if (ans == 'N' || ans == 'n')
                {
                	(void)abort_send();
                	break;
                }
                else if ((ans == 'D' || ans == 'd') && count) 
                {
                        move(2, 0);
                        name_query("Enter userid: ", uident, listmailtable);
                        move(2, 0);
                        clrtoeol();
                        if (uident[0] != '\0')
                                deleteoverride(uident, "maillist");
                }
		else if ((ans == 'C' || ans == 'c') && count)
		{
			(void)sprintf(uident, PATH_MAILLIST, cuser.userid);
			(void)unlink(uident);
		}
                else 
                        break;
        }
        if (ans != 'n' && count)
        {
	        if (getinfo(&mailhd) != QUIT)
        	{
        		clear();
        		ApplyToLinkList(start_sending, (char *)&mailhd);
        		pressreturn();
		}
		(void)sprintf(uident, "tmp/%s", cuser.userid);
		(void)unlink(uident); 
	}
/*
        (void)sprintf(uident, PATH_MAILLIST, cuser.userid);
        (void)unlink(uident);
*/        
        clear();
        return 0;
}               
