/*
    PIVOT Bulletin Board System
    Copyright (C) 1995, Tseng Kuo-Feng, kftseng@ccnews.nchu.edu.tw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#ifndef LOCK_EX
#define LOCK_SH		(1)
#define	LOCK_EX         (2)
#define LOCK_NB		(4)
#define LOCK_UN         (8)
#endif


/*
 * filename: check.c
 * Usage:    1. check users' privilege and reset it
 *           2. check if users' home exist, if not build it.
 *
 * How:	     1. check bbs_home 0    # for crontab
 *	     2. check bbs_home 1    # ����ˬd 
 *
 * Writer:   kftseng@ccnews.nchu.edu.tw
 * Date:     Jan 15 1995
 */

#include	<errno.h>
#include	<stdio.h>
#include	<sys/file.h>
#include	<sys/types.h>
#include	<unistd.h>
#include	<fcntl.h>
#include	"define.h"
#include	"struct.h"

#define		LOG_ILLEGAL	"reclog/illegal.log"
#define		LOG_CDLIST	"reclog/cdlist.log"
#define		LOG_BDLIST	"reclog/bdlist.log"
#define		LOG_TULIST	"reclog/tulist.log"
#define		LOG_TUDATA	"reclog/tudata.log"
#define		LOG_CRON	"reclog/cronck.log"
#define		LEVEL		(32)

int	safewrite(fd, buf, size)
int	fd,
	size;
char	*buf;
{
	int	cc,
		sz = size,
		origsz = size;
	char	*bp = buf;

	do
	{
		cc = write(fd, bp, sz);
		if((cc < 0) && (errno != EINTR))
		{
			return -1;
		}
		if(cc > 0)
		{
			bp += cc;
			sz -= cc;
		}
	}
	while(sz > 0);

	return origsz;
}

int	write_record(filename, rptr, size, id)
char	*filename,
	*rptr;
int	size,
	id;
{
	int fd;

	if((fd = open(filename,O_WRONLY|O_CREAT,0644)) == -1)
		return -1;

/*	flock(fd,LOCK_EX);
*/
	if (lseek(fd, size*(id-1), L_SET) == -1);

	if (safewrite(fd, rptr, size) != size);
/*
	flock(fd,LOCK_UN);
*/	close(fd);

	return 0;
}

int 	read_record(filename, rptr, size, id)
char	*filename,
	*rptr;
int	size,
	id;
{
	int	fd;

	if(*filename == '\0')
		return -1;
	if((fd = open(filename, O_RDONLY, 0)) == -1)
		return -1;
	if(lseek(fd, size*(id-1), L_SET) == -1)
	{
		close(fd);
		return -1;
	}
	if(read(fd,rptr,size) != size)
	{
		close(fd);
		return -1;
	}
	close(fd);

	return 0;
}

int	check_home(uid, shift)
userec	*uid;
int	shift;
{
	char	home[STRLEN];

	sprintf(home, PATH_USER, uid->userid);
	if(access(home, R_OK))
	{
		printf("%d: %s <<<<<---- build home %s\n", shift, uid->userid,
			home);
		mkdir(home, 0755);
	}
	else
		printf("%d: %s ---->>>>> home is correct\n", shift,
			uid->userid);
}

int	check_level(uid, shift, flag)
userec	*uid;
int	shift;
char	flag;
{
	usint	pbits;
	char	switches[STRLEN], i, j, ans, c;
	char	*perminfo[] =
	{
        	"Basic permissions",        "Chat",
        	"Page",                     "Post",
        	"True Data",                "Local Board Manager",
        	"Chat Room Manager",        "Special1",
        	"Special2",                 "Special3",
        	"Special4",                 "Special5",
        	"Special6",                 "Special7",
        	"Speical8",                 "Speical9",
        	"Special10",                "Special11",
        	"Cloak",                    "See cloaked",
        	"Upload files",             "Edit Welcome",   
        	"Board Manager",            "Account Manager",
        	"Cloak in chat",            "Vote manager",   
        	"Sub SYSOP",                "Other BBS SYSOP",
        	"sysop..",                  "sysop,,",        
        	"Admin Privilege",          "TOP Level SYSOP",
		NULL,
	};

	if (uid->userlevel & PERM_CHATMNG)
		logcd(uid->userid, shift);
	if (uid->userlevel & PERM_LOCALBM)
		logbd(uid->userid, shift);
	if (uid->userlevel & PERM_TRUE)
	{
		logtu(uid->userid, shift);
		logdata(uid->userid, uid->email, uid->lasthost, shift);
	}

	pbits = uid->userlevel;
	if (uid->userlevel != PERM_DEFAULT && uid->userlevel != PERM_CHECKED)
	{
		if (flag == '0')
		{
			bzero(switches, sizeof(switches));
		        for (i = 0; i < LEVEL; i++)
        		{
                		if((pbits >> i) & 1)
					sprintf(switches, "%s%c",
						switches, 'A'+i);
		        }
			logcron(uid->userid, shift, switches);
			return 0;
		}
	}
	else
		return 0;

	printf("\n%d: user <<= %s ==> level is\n", shift, uid->userid);
        for (i = 0; i < LEVEL; i++)
        {
                printf("(%c) %-24s %3s   ", 'A' + i , perminfo[i],
                        ((pbits >> i) & 1 ? "ON" : "OFF"));
		if (i%2 == 1)
			printf("\n");
        }
	bzero(switches, sizeof(switches));
	printf("\nInput all levels you want to switch:\n");
	gets(switches);

	if (strlen(switches) == 0)
		return 0;

	for (i = 0; i < strlen(switches); i++)
	{
		c = switches[i];
		j = toupper(c) - 'A';
                if((pbits >> j) & 1)
                        pbits &= (~(1 << j));
                else
                        pbits |= (1 << j);
                printf("<%c> %-24s %3s  ", 'A' + j, perminfo[j],
                        ((pbits >> j) & 1 ? "ON" : "OFF"));
		if (i%2 == 1)
			printf("\n");
	}
	printf("\n");
	uid->userlevel = pbits;

	return 1;
}

logit(userid, usernum)
char	*userid;
int	usernum;
{
	FILE	*fp;

	if ((fp = fopen(LOG_ILLEGAL, "a+")) == NULL)
	{
		printf("file %s cannot open for record\n", LOG_ILLEGAL);
		exit(-1);
	}
	fprintf(fp, "%13s(%4d) is incorrect\n", userid, usernum);
	fclose(fp);
}

logcd(userid, usernum)
char    *userid;
int     usernum;
{
        FILE    *fp;

        if ((fp = fopen(LOG_CDLIST, "a+")) == NULL)
        {
                printf("file %s cannot open for record\n", LOG_CDLIST);
                exit(-1);
        }
        fprintf(fp, "%13s(%4d) is chat room deputy\n", userid, usernum);
        fclose(fp);
}

logbd(userid, usernum)
char    *userid;
int     usernum;
{
        FILE    *fp;

        if ((fp = fopen(LOG_BDLIST, "a+")) == NULL)
        {
                printf("file %s cannot open for record\n", LOG_BDLIST);
                exit(-1);
        }
        fprintf(fp, "%13s(%4d) is board deputy\n", userid, usernum);
        fclose(fp);
}

logtu(userid, usernum)
char    *userid;
int     usernum;
{
        FILE    *fp;

        if ((fp = fopen(LOG_TULIST, "a+")) == NULL)
        {
                printf("file %s cannot open for record\n", LOG_TULIST);
                exit(-1);
        }
        fprintf(fp, "%13s(%4d) has personal information check\n", userid, usernum);
        fclose(fp);
}

logdata(userid, email, lasthost, usernum)
char	*userid,
	*email,
	*lasthost;
int     usernum;
{
        FILE    *fp;

        if ((fp = fopen(LOG_TUDATA, "a+")) == NULL)
        {
                printf("file %s cannot open for record\n", LOG_TUDATA);
                exit(-1);
        }
        fprintf(fp, "%13s(%4d) e-mail=%s,  last=%s\n", userid, usernum, email, lasthost);
        fclose(fp);
}

logcron(userid, usernum, perms)
char    *userid,
	*perms;
int     usernum;
{
        FILE    *fp;

        if ((fp = fopen(LOG_CRON, "a+")) == NULL)
        {
                printf("file %s cannot open for record\n", LOG_CRON);
                exit(-1);
        }
        fprintf(fp, "%13s(%4d) has perm: %s\n", userid, usernum, perms);
        fclose(fp);
}

main(argc, argv)
int	argc;
char	*argv[];
{
	int	maxuser,
		now,
		shift;
	userec	checkid;
	char	flag;

	if (argc != 3)
	{
		printf("Usage: %s bbs_home flag\n", argv[0]);
		printf("       flag = '0' for crontab\n");
		printf("       flag = '1' for others\n");
		exit(-1);
	}

	if (!access(argv[1], R_OK))
		chdir(argv[1]);
	else
	{
		printf("path %s is not exist\n");
		exit(-1);
	}

	flag = *argv[2];

	for (shift = 0; shift < MAXUSERS; shift++)
	{
		printf("\n\n");
		read_record(PASSFILE, &checkid, sizeof(userec), shift+1);
		if (!strcmp(checkid.userid, "new") || checkid.userid[0] == '\0')
			continue;
		check_home(&checkid, shift);
		if (check_level(&checkid, shift, flag))
		{
			logit(checkid.userid, shift);
			write_record(PASSFILE, checkid, sizeof(userec),
				shift+1);
		}
	}
}
