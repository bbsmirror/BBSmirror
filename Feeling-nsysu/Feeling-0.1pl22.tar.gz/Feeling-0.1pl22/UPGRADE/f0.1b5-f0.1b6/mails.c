/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

/*
   ���{���O�Ψ��ഫ Feeling BBS beta 6 �e���ӤH MAIL ��Ƭ� beta 6
   �榡, �Y�����D�z�� Feeling BBS �O�X��, �b�D�ؿ��� CTRL-V �N���D�F.
 
   �Ϊk: ��O����: mails userid
         �h�O����: step1. cd /home/bbs/home
                   step2. ls -1 | awk '{ print "mails ", $1 }' | sh

   �Y�u�n���� .DIR ����, �u�n��U���� #undef REBUILD_ONLY �令
   #define REBUILD_ONLY �N�n�F.
*/

#ifndef lint
static  char    SccsId[] = "@(#)mails.c	0.1	12/24/95";
#endif

#undef	REBUILD_ONLY

#include <stdio.h>
#include <time.h>
#include <sys/types.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/file.h>
#include <sys/time.h>

#define	STRLEN	(100)
#define	MYBBSID	"Feeling"

#define	FILE_LOCAL	0x04

typedef	unsigned int	usint;
typedef	unsigned char	uschar;

typedef	struct			/* DIR of board struct */
{
	char	filename[20];		/* �ɦW				*/
	char	sender[80];		/* �o�H�H			*/
	char    title[80];		/* �H��D�D			*/
	time_t	date;			/* �s�ɮɶ�			*/
	usint   flag;			/* �O�d				*/
}
fhd;

struct	LIST
{
	struct	LIST	*prev,
			*next;
	fhd	*info;
};
typedef	struct	LIST	LIST;

LIST	*head = NULL,
	*tail = NULL;

int	total = 0;
char	currpath[80];

int	parse_writer(fp, writer)
FILE	*fp;
char	*writer;
{
	char	buffer[100],
		*p;

	if (fgets(buffer, sizeof(buffer), fp) == NULL)
		return -1;
	if ((p = (char *)strtok(buffer, ":")) == NULL)
		return -1;
	if ((p = (char *)strtok(NULL, " \n")) == NULL)
		return -1;
	if (strstr(p, MYBBSID))
		(void)strtok(p, "@");
	(void)strncpy(writer, p, 80);
	return 0;
}

int	parse_title(fp, title)
FILE	*fp;
char	*title;
{
	char	buffer[100],
		*p;

	if (fgets(buffer, sizeof(buffer), fp) == NULL)
		return -1;
	if ((p = (char *)strtok(buffer, ":")) == NULL)
		return -1;
	if ((p = (char *)strtok(NULL, "\n")) == NULL)
		return -1;
	(void)strncpy(title, p+1, 80);
	return 0;
}

int	parse_file(info, fname)
fhd	*info;
char	*fname;
{
	FILE	*fp;
	char	writer[80],
		title[80];
	struct	stat	fst;

	if ((fp = fopen(fname, "r")) == NULL)
	{
		(void)printf("1. unlink: %s\n\n", fname);
		(void)unlink(fname);
		return -1;
	}
	(void)memset(writer, 0, sizeof(writer));
	if (parse_writer(fp, writer))
	{
		(void)printf("2. unlink: %s\n\n", fname);
		(void)unlink(fname);
		return -1;
	}
	(void)memset(title, 0, sizeof(title));
	if (parse_title(fp, title))
	{
		(void)printf("3. unlink: %s\n\n", fname);
		(void)unlink(fname);
		return -1;
	}
	fstat(fileno(fp), &fst);
	(void)fclose(fp);
	(void)strncpy(info->sender, writer, 80);
	(void)strncpy(info->title, title, 80);
	info->date = fst.st_mtime;
	return 0;
}

int	COMP(left, right)
LIST	*left,
	*right;
{
	if (left == NULL)
		return 0;
	return (left->info->date - right->info->date);
}

void	SWAP(left, right)
LIST	*left,
	*right;
{
	fhd	*temp;

	temp = left->info;
	left->info = right->info;
	right->info = temp;
}

void	InsertSort(a, left, right)
LIST	**a;
int	left,
	right;
{
	int	i,
		j;
	LIST	*temp;

	temp = (LIST *)malloc(sizeof(LIST));
	for (i = left + 1; i <= right; i++)
	{
		temp = a[i];
		temp->info = a[i]->info;
		j = i;
		while (j > left && (COMP(a[j-1], temp) > 0))
		{
			a[j]->info = a[j-1]->info;
			j--;
		}
		a[j]->info = temp->info;
	}
	free(temp);
}

void	ThreeSort(a, left, right, mid)
LIST	**a;
int	left,
	right,
	mid;
{
	if (COMP(a[left], a[right]))
		SWAP(a[left], a[right]);
	if (COMP(a[left], a[mid]))
		SWAP(a[left], a[mid]);
	if (COMP(a[right], a[mid]))
		SWAP(a[right], a[mid]);
}

void	QuickSort(a, left, right)
LIST	**a;
int	left,
	right;
{
	int	i,
		j;
	LIST	*key;

	if (right > left)
	{
/*		if (right - left < 15)
		{
			InsertSort(a, left, right);
			return;
		}
*/		ThreeSort(a, left, right, (left + right) / 2);
		key = a[right];
		i = left - 1;
		j = right;
		while (1)
		{
			while (++i < right && COMP(a[i], key) < 0);
			while (--j > left && COMP(a[j], key) > 0);
			if (i >= j) break;
			SWAP(a[i], a[j]);
		}
		SWAP(a[i], a[right]);
		QuickSort(a, left, i-1);
		QuickSort(a, i+1, right);
	}
}

void	SortList()
{
	LIST	**a,
		*p;
	int	i;

	a = (LIST **)calloc(total, sizeof(LIST *));

	for (p = head, i = 0; ; p = p->next)
	{
		if (p->info->filename[0] == '\0')
			continue;
		a[i] = p;
		a[i++]->info = p->info;
		if (p == tail)
			break;
	}
	QuickSort(a, 0, total - 1);
	free(a);
}

void	FreeList()
{
	LIST	*p,
		*tmp;

	for (p = head, tmp = p->next; ; p = tmp, tmp = tmp->next)
	{
		if (p == tail)
		{
			free(p->info);
			free(p);
			break;
		}
		free(p);
	}
}

void	CreateList()
{
	if (head != NULL)
		FreeList();
	head = tail = NULL;
	total = 0;
}

int	AddList(info)
fhd	*info;
{
	LIST	*now;

	if ((now = (LIST *)malloc(sizeof(LIST))) == NULL)
		return -1;
	if ((now->info = (fhd *)malloc(sizeof(fhd))) == NULL)
		return -1;

	(void)strcpy(now->info->filename, info->filename);
	(void)strcpy(now->info->sender, info->sender);
	(void)strcpy(now->info->title, info->title);
	now->info->date = info->date;
	now->info->flag |= FILE_LOCAL;
	total++;
	if (head == NULL)
	{
		tail = head = now;
		tail->prev = head;
		head->next = tail;
		return 0;
	}
	now->prev = tail;
	tail->next = now->next = now;
	tail = now;
	return 0;
}

void	ShowList()
{
	LIST	*p;
	int	i = 0;

	if (head == NULL)
		return;
	for (p = head; ; p = p->next)
	{
		(void)printf("(%d)\tfilename: %s\n", ++i, p->info->filename);
		if (p->next == p)
			break;
	}
}

int	SaveList()
{
	LIST	*p;
	fhd	curr;
	int	i = 0,
		fd;
	char	source[80],
		target[80],
		genbuf[80];

	sprintf(genbuf, "%s/.DIR", currpath);
	unlink(genbuf);
	if ((fd = open(genbuf, O_WRONLY|O_CREAT, 0644)) == -1)
	{
		(void)perror("open fail");
		return -1;
	}
	(void)flock(fd, LOCK_EX);
	if (head == NULL)
		return;
	for (p = head, i = 1; ; p = p->next, i++)
	{
		(void)memset(&curr, 0, sizeof(fhd));
#ifndef	REBUILD_ONLY
		(void)sprintf(curr.filename, "J.%010d.Y", i);
		(void)sprintf(source, "%s/%s", currpath, p->info->filename);
		(void)sprintf(target, "%s/%s", currpath, curr.filename);
		(void)rename(source, target);
#else
		(void)strncpy(curr.filename, p->info->filename);
#endif
		(void)strncpy(curr.sender, p->info->sender, 80);
		(void)strncpy(curr.title, p->info->title, 80);
		curr.date = p->info->date;
		curr.flag |= FILE_LOCAL;
		(void)write(fd, &curr, sizeof(fhd));
		if (p->next == p)
			break;
	}
	(void)flock(fd, LOCK_UN);
	(void)close(fd);
	return 0;
}

int	get_dir(path)
char	*path;
{
	DIR	*dp;
	struct	direct	*ent;
	char	genbuf[STRLEN];
	fhd	info;
	int	i = 0,
		begin,
		final;

	if ((dp = opendir(path)) == NULL)
		return -1;
	CreateList();
	for (ent = readdir(dp); ent != NULL; ent = readdir(dp))
	{
		if (ent->d_name[0] == '.')
			continue;
		if (strlen(ent->d_name) > 15)
		{
			(void)printf("4. unlink: %s\n", ent->d_name);
			(void)unlink(ent->d_name);
			continue;
		}
		(void)sprintf(genbuf, "%s/%s", path, ent->d_name);
		(void)memset(&info, 0, sizeof(fhd));
		(void)strncpy(info.filename, ent->d_name, 20);
		if (parse_file(&info, genbuf))
			continue;
		if (AddList(&info))
			break;
	}
	(void)closedir(dp);
	SortList();
	ShowList();
	SaveList();
	FreeList();
	return 0;
}

int	main(argc, argv)
int	argc;
char	*argv[];
{
	int	fd,
		found = 0;

	if (argc < 2)
	{
		printf("size: %d\n", sizeof(fhd));
		exit(0);
	}
	sprintf(currpath, "/home/bbs/home/%s/mail", argv[1]);
	get_dir(currpath);
	exit(0);
	return 0;
}
