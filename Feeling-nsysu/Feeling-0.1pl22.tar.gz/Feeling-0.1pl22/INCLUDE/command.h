/*
 * @(#)command.h	2.1	12/24/95
 */

#define MSG_PRIV  	0
#define MSG_PUB   	1 
#define MSG_WHO   	2	 
#define MSG_NICK   	3	 
#define MSG_ROOM_LST  	4	
#define MSG_TOPIC 	5	 
#define MSG_INV    	6
#define MSG_QUIT   	7
#define MSG_JOIN	8
#define MSG_KICK	9
#define MSG_OPER	10
#define MSG_BAN		11
#define MSG_NEW_USER	12
#define	MSG_SET_ROOM	13
#define	MSG_IGNORE	14
#define	MSG_LST_INV	15
#define	MSG_LST_BAN	16
#define	MSG_RM_INV	17
#define	MSG_RM_BAN	18
#define	MSG_LST_IGN	19
#define	MSG_RM_IGN	20
#define MSG_WHOS	21
#define	MSG_DO_CLO	22
#define	MSG_DO_DEOP	23
