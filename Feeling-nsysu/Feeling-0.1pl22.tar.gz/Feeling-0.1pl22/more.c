/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    SccsId[] = "@(#)more.c	2.1	12/24/95";
#endif

#include "bbs.h"
#include <sys/types.h>
#ifndef XINU
#include <sys/stat.h>
#endif

extern	int	t_lines,
		dumb_term;
extern	userec	cuser;
int	reading = YEA;

int	readln(fp, buf)
FILE	*fp;
char	*buf;
{
	int	i = 0,
		ansi = 0,
		bytes = 0,
		ansinum = 0,
		ch;

	while ((ch = getc(fp)) != EOF)
	{
		bytes++;
		if (ch == '\n')
		{
			buf[i] = '\0';
			return bytes;
		}

		if (ch == '\t')
		{
			do
			{
				buf[i++] = ' ';
			}
			while ((i % 8) != 0);
		}
		if (ISPRINT(ch) || ch == KEY_ESC)
		{
			if (ch == KEY_ESC)
				ansi = YEA;
			if (ansi)
			{
				ansinum++;
				if (ch != '[' && ch != ';' && !isalnum(ch) &&
					ch != KEY_ESC)
					ansi = NA;
			}
			buf[i++] = ch;
		}

		if (i-ansinum > 79 || i > 254)
		{
			buf[i] = '\0';
			return bytes;
		}
	}

	if (i == 0)
		return 0;
	else
		buf[i] == '\0';

	return bytes;
}

void	more_print(buf)
char	*buf;
{
	if (reading)
	{
		if (((strstr(buf, "==>") || strstr(buf, ") ����") || 
			strstr(buf, ") wrote:")) && strchr(buf, '@')) ||
			(strstr(buf, "followed") && strstr(buf, "post")))
		{
			prints(NA, "[1;32m%s[m\n", buf);
			return;
		}
		else if (buf[0] == ':' || buf[0] == '>')
		{
			prints(NA, "[36m%s[m\n", buf);
			return;
		}
	}
	prints(NA, "%s\n", buf);
	return;
}

int	more(filename, promptend)
char	*filename;
int	promptend;
{
	FILE	*fp;
	long	viewed;
	int	ch,
		i,
		j,
		pos,
		full_screen = NA,
		numbytes,
		quit=NA;
	long	tsize;
	struct	stat	st;
	char	buf[256],
		rows[6000];

	if ((fp = fopen(filename,"r")) == NULL)
		return -1;

	if (fstat(fileno(fp), &st))
		return -1;

	tsize = st.st_size;
	clear();
	i = j = pos = viewed = 0;

	rows[j++] = numbytes = readln(fp,buf);

	do
	{
		if (!strcmp(buf, "--active"))
		{
			i = t_lines-2;
			full_screen = NA;
			rows[j++] = numbytes = readln(fp,buf);
		}

		if (!strcmp("++active", buf) && HAS_SET(SET_ACTIVE) &&
			HAS_SET(SET_ANSIMODE) && !full_screen)
		{
			full_screen = YEA;
			continue;
		}

		if (!numbytes)
			break;

		viewed += numbytes;
		more_print(buf);

		if (full_screen)
			refresh();
		pos++;
		i++;

		if (pos == t_lines)
		{
			scroll();
			pos--;
		}

		rows[j++] = numbytes = readln(fp,buf);
		if (!numbytes)
			break;

		if (i == t_lines -1 && !full_screen)
		{
			move(t_lines-1,0);
			if (!dumb_term)
			{
				prints(YEA, "--More--(%d%%)",
					(viewed*100)/tsize);
				prints(NA, "%s %s %s %s %s \n",
					"[[1;33m��[m|[1;33mq[m]����",
					"[[1;33m��[m]�W�@��",
					"[[1;33m��[m|[1;33mEnter[m]�U�@��",
					"[[1;33mb[m]�W�@��",
					"[[1;33m��[m|[1;33mSpace[m]�U�@��");
			}
			else
				bell(1);

			while ((ch = egetch()) != EOF)
			{
				if (ch == ' '||ch == KEY_RIGHT||ch == KEY_PGDN)
				{
					move(t_lines-1,0);
					clrtoeol();
					i = 1;
					break;
				}

				if (ch == 'q'||ch == KEY_LEFT)
				{
					quit = YEA;
					break;
				}
				if (ch == 'b'||ch == KEY_PGUP)
				{
					move(t_lines-1,0);
					clrtoeol();
					j-= 2*t_lines-2;
					for(i=viewed=0; i<j; viewed+=rows[i++]);
					(void)fseek(fp, viewed, 0);
					rows[j++] = numbytes = readln(fp,buf);
					i = 0;
					break;
				}
				if (ch == KEY_UP && j != t_lines)
				{
					rscroll();
					rscroll();
					for(i=viewed=0; i<j-t_lines-1; viewed+=rows[i++]);
					(void)fseek(fp, viewed, 0);
					numbytes = readln(fp,buf);
					move(1,0);
					more_print(buf);
					j-=2;
					for(; i < j; viewed+=rows[i++]);
					(void)fseek(fp, viewed, 0);
					numbytes = readln(fp,buf);
					move(t_lines-1,0);
					clrtoeol();
					i = t_lines-2;
					break;
				}
				if (ch == '\r'||ch == KEY_DOWN||ch == 'n')
				{
					move(t_lines-1,0);
					clrtoeol();
					i = t_lines-2;
					break;
				}
				bell(1);
			 }

			 if (quit)
				break;
		} 
	}
	while (numbytes);

	(void)fclose(fp);
	move(t_lines-1, 0);
	clrtoeol();

	if (promptend)
	{
		pressreturn();
	}

	return 0;
}
