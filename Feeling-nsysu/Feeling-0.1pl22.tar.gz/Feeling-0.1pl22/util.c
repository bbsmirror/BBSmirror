/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    SccsId[] = "@(#)util.c	2.5	6/1/96";
#endif

#include "bbs.h"

extern	userec	cuser;
extern	usinfo	uinfo;
extern	char	currboard[],
		currfile[],
		save_title[];
extern	int	t_lines,
		in_mail;
extern	int	u_namelist();
extern	void	init_alarm();
extern	int	getdata(),
		cmpbname();

int	numbbsenvs = 0;
char	*bbsenv[MAXENVS];

char	*message_from(from)
char	*from;
{
	static	char	string[STRLEN];
	char	*p,
		userid[40],
		nick[20];
	int     i = 0,
	        j = 0,
		flag;

	(void)memset(string, 0, sizeof(string));

	(void)strncpy(userid, from, 40);
	userid[39] = '\0';
	(void)strtok(userid, " \0");

	if ((p = strchr(from, '(')) != NULL)
	{
		(void)strncpy(nick, p + 1, 20);
		nick[19] = '\0';
		if ((p = strrchr(nick, ')')) != NULL)
			*p = '\0';
	}
	else
		nick[0] = '\0';

	(void)sprintf(string, "==> �� %s (%s) �夤�z��:", nick, userid);
	return string;
}

int	include_old(newfile, oldfile, ans)
char	*newfile,
	*oldfile,
	ans;
{
	FILE	*new,
		*old;
	char	buff[WRAPMARGIN],
		from[STRLEN];

	if (!(new = fopen(newfile,"w")))
		return 2; /* no target file */
	if (!(old = fopen(oldfile,"r")))
		return 1; /* no source file */
      
	while (fgets(buff, sizeof(buff), old) != NULL)
	{
		if (ans != 'a' && ans != 'A')
		{
			if ((char *)strstr(buff,"�o�H�H: ") == buff ||
				(char *)strstr(buff,"�H��H: ") == buff)
			{ 
				(void)strcpy(from, message_from(buff+8));
				(void)fprintf(new, "%s\n", from);
				continue;
			}
			if (((char *)strstr(buff, "��  �D: ") == buff) || 
				((char *)strstr(buff, "�o�H��: ") == buff) ||
				((char *)strstr(buff, "��H��: ") == buff) ||
				((char *)strstr(buff, "��  ��: ") == buff) ||
				(buff[0] == '\n'))
				continue;
			if (!strcmp(buff, "--\n"))
				break;
		}
		if (buff[strlen(buff)-1] != '\n')
			(void)fprintf(new, ": %s\n", buff);
		else
			(void)fprintf(new, ": %s", buff);
	}
	(void)fclose(new);
	(void)fclose(old);
	return 0;
}

int	copyto(oldfile, newfile)
char	*newfile,
	*oldfile;
{
	FILE	*new,
		*old;
	char	buff[81];
   
	if(!(new = fopen(newfile,"w")))
		return 2;

	if(!(old = fopen(oldfile,"r")))
		return 1;
      
	while(fgets(buff, sizeof(buff), old) != NULL)
	{
		(void)fprintf(new,"%s",buff);
	}

	(void)fclose(new);
	(void)fclose(old);
   
	return 0;
}

void	write_header(fp)
FILE	*fp;
{
	char	uid[20],
		uname[40];
	time_t	ti;

	(void)strncpy(uid, cuser.userid, 20);
	uid[19] = '\0';

#ifdef REALINFO
	if (HAS_SET( (in_mail) ? SET_REALMAIL : SET_REALPOST ))
		(void)strncpy(uname, cuser.realname, 40);
	else
#endif
		(void)strncpy(uname, cuser.username, 40);

	uid[39] = '\0';
	save_title[STRLEN-10] = '\0';

	if (in_mail)
		(void)fprintf(fp, "�H��H: %s@%s (%s)\n", uid, MYNICK, uname);
	else
        {
	        if(check_setting(currboard, BHD_ANONYMOUS))
		{
                (void)fprintf(fp, "�o�H�H: Anonymous@%s (�ΦW�i�K) on board '%s'\n", MYNICK, currboard);
/*		(void)fprintf(fp, "�Ъ`�N: ���g�峹���ΦW�i�K, �������t����d��\n");
*/		}
		else
                (void)fprintf(fp, "�o�H�H: %s@%s (%s) on board '%s'\n", uid, MYNICK,  uname, currboard);
	}

	(void)fprintf(fp, "��  �D: %s\n", save_title);
	(void)time(&ti);
	(void)fprintf(fp, "�o�H��: %s (%s)\n\n", BOARDNAME, Ctime(&ti));
}

int	update_file(dirname, buf, size, ent, filecheck, fileupdate)
char	*dirname,
	*buf;
int	size,
	ent,
	(*filecheck)();
void	(*fileupdate)();
{
	int	fd;
	char	tfile[80],
		*abuf;

	(void)strcpy(tfile, buf);	
	if ((fd = open(dirname, O_RDWR)) == -1)
		return -1;
	(void)flock(fd, LOCK_EX);

	abuf = malloc(size);
	if (lseek(fd, size*(ent-1), L_SET) != -1)
	{
		if (read(fd, abuf, size) == size)
		{
			if ((*filecheck)(abuf, tfile))
			{
				(void)lseek(fd, -size, SEEK_CUR);
				(*fileupdate)(abuf);
				if (safewrite(fd, abuf, size) != size)
				{
			  		(void)flock(fd, LOCK_UN);
					(void)close(fd);
					free(abuf);
					return -1;
				}
				(void)flock(fd, LOCK_UN);
				(void)close(fd);
				free(abuf);
				return 0;
			}
		}
	}

	(void)lseek(fd, 0, L_SET);
	while (read(fd, abuf, size) == size)
	{
		if ((*filecheck)(abuf, tfile))
		{
			(void)lseek(fd, -size, SEEK_CUR);
			(*fileupdate)(abuf);
			if (safewrite(fd, abuf, size) != size)
			{
				(void)flock(fd, LOCK_UN);
				(void)close(fd);
				free(abuf);
				return -1;
			}
			(void)flock(fd, LOCK_UN);
			(void)close(fd);
			free(abuf);
			return 0;
		}
	}
	(void)flock(fd, LOCK_UN);
	(void)close(fd);
	free(abuf);
	return -1;
}

int	getans(x, y, prompt, def)
int	x,
	y,
	def;
char	*prompt;
{
	int	ch;

	ch = reply(x, y, prompt, NA);

	if (ch > 0x100 || ch == ' ' || ch == '\n' || ch == '\r')
   		ch = def;
	prints(NA, "%c\n", ch);
	refresh();
	return tolower(ch);
}

int	get_title(oldttl, newt)
char	*oldttl, 
	*newt;
{
	char	ans;

	while (1)
	{
		if (oldttl && oldttl[0])
		{
			if (strstr(oldttl, "Re: ") != oldttl)
			{
				(void)strcpy(newt, "Re: ");
				(void)strcat(newt, oldttl);
			}
			else
				(void)strcpy(newt, oldttl);
		}

		move(1, 0); 
		clrtoeol();
		getdata(1, 0, "�]�w�D�D�G", newt, STRLEN, DOECHO, NA);

		if (strlen(newt) <= 0)
		{
			ans = getans(2, 0, POST_NOTITLE, 't');
			if (ans == 't')
			{
				move(2, 0);
				clrtoeol();
				continue;
			}

			if (ans == 'Y' || ans == 'y')
			{
				if (oldttl == NULL)
					(void)strncpy(newt, "[�L�D�D]", 8);
				else
					(void)strncpy(newt, oldttl, strlen(oldttl));

				return 0;
			}
			else
				move(1, 0);
			clrtoeol();

              		return QUITPOST;
		}
		else
			break;
        }

        return 0;
}

int	init_namelist(namebuf)
char	*namebuf;
{
	char	genbuf[STRLEN];

	if (!HAS_SET(SET_USERLIST))
	{
		prints(NA, "�إ߯��ͦW��, �еy��..... ");
		refresh();
		move(1,0);
		clrtoeol();
		clear();
		prints(NA, "<�п�J�W�r>\n");
		move(2,0);
		name_query("To: ", genbuf, u_namelist);
		CreateLinkList();
	}
	else
	{
		move(1,0);
      		prints(NA, "<�п�J�W�r>\n"); 
		if (i_userid(2, genbuf) <= 0)
			CLRTOP3;
        }
	(void)strcpy(namebuf, genbuf);
	if (genbuf[0] == '\0')
		return 0;
	return getuser(genbuf);
}

void	backspace(num)
int	num;
{
	int	j;

	for (j=0; j<num; j++)
	{
		ochar(CTRL('H'));
		ochar(' ');
		ochar(CTRL('H'));
	}
}

int	pressreturn()
{
	move(t_lines-1, 0);
	clrtoeol();
	prints(YEA, "[1;36;44m%s                            [m",
		"                             [<] �Ы����@���~�� [>]");
	refresh();
	egetch();
	return 0;
}

int	bbssetenv(env,val)
char	*env,
	*val;
{
	int	i,
		len;

	if (numbbsenvs == 0)
		bbsenv[0] = NULL;
	len = strlen(env);
	for (i=0; bbsenv[i]; i++)
	{
		if (!strncmpi(env, bbsenv[i], len))
			break;
	}
	if (i >= MAXENVS)
		return -1;
	if (bbsenv[i])
		free(bbsenv[i]);
	else
		bbsenv[++numbbsenvs] = NULL;
	bbsenv[i] = malloc(strlen(env) + strlen(val) + 2);
	(void)strcpy(bbsenv[i],env);
	(void)strcat(bbsenv[i],"=");
	(void)strcat(bbsenv[i],val);
	return 0;
}

int	islocalbm()
{
	bhd	fh;

	if (!search_board(&fh, currboard, cmpbname))
	{
		return 0;
	}

	if (HAS_PERM(PERM_BOARDS) || HAS_PERM(PERM_SYSOP) ||
	      ((!strcasecmp(cuser.userid, fh.mngs[0]) ||
		!strcasecmp(cuser.userid, fh.mngs[1]) ||
		!strcasecmp(cuser.userid, fh.mngs[2])) &&
		HAS_PERM(PERM_LOCALBM)))
	{
		return 1;
	}
	return 0;
}

int	do_exec(com, wd, mode)
char	*com,
	*wd;
int	mode;
{
	char	path[MAXPATHLEN],	pcom[MAXCOMSZ],
		*arglist[MAXARGS],	*tz;
	int	i,	len,	argptr,	
		status,	pid,	w,	pmode,
		smode,	spager;
	void	(*isig)(),	(*qsig)();

	(void)strcpy(path, BBSHOME);
	(void)strcat(path, "/");
	(void)strncat(path, BINDIR, MAXPATHLEN);
	(void)strncpy(pcom, com, MAXCOMSZ);
	len = MYMIN(strlen(com)+1, MAXCOMSZ);
	pmode = LOOKFIRST;
	for (i=0, argptr=0; i<len; i++)
	{
	        if (pcom[i] == '\0')
			break;
		if (pmode == QUOTEMODE)
		{
			if (pcom[i] == '\001')
			{
		                pmode = LOOKFIRST;
        		        pcom[i] = '\0';
		 		continue;
			}
			continue;
		}
		if (pcom[i] == '\001')
		{
			pmode = QUOTEMODE;
			arglist[argptr++] = &pcom[i+1];
			if (argptr+1 == MAXARGS)
				break;
			continue;
		}
		if (pmode == LOOKFIRST)
		{
			if (pcom[i] != ' ')
			{
				arglist[argptr++] = &pcom[i];
				if (argptr+1 == MAXARGS)
					break;
				pmode = LOOKLAST;
			}
			else
				continue;
		}
		if (pcom[i] == ' ')
		{
			pmode = LOOKFIRST;
			pcom[i] = '\0';
		}
	}
	arglist[argptr] = NULL;
	if (argptr == 0)
		return -1;
	if (*arglist[0] == '/')
		(void)strncpy(path, arglist[0],MAXPATHLEN);
	else
		(void)strncat(path, arglist[0],MAXPATHLEN);
	reset_tty();
	(void)alarm(0);

	smode = uinfo.mode;
	spager = uinfo.pager;
	uinfo.pager = NA;

	if ((pid = vfork()) == 0)
	{
	        if (wd)
		{
			if (chdir(wd))
			{
				(void)fprintf(stderr,"Unable to chdir to '%s'\n",wd);
				exit(-1);
			}
		}
		(void)bbssetenv("PATH", "/bin:/usr/bin:/usr/local/bin:.:/usr/ucb");
		(void)bbssetenv("EDITOR","/bin/ve");
		(void)bbssetenv("TERM", cuser.termtype);
		(void)bbssetenv("USER", cuser.userid);
		(void)bbssetenv("USERNAME", cuser.username);
		(void)bbssetenv("REPLYTO", cuser.email);
		if ((tz = (char *)getenv("TZ")) != NULL)
        		(void)bbssetenv("TZ", tz);	
		if (numbbsenvs == 0)
			bbsenv[0] = NULL;
		(void)execve(path,arglist,bbsenv);
		move(2, 0);
		prints(NA, "�����ثe������ '%s' �A��\n",path);
		(void)getchar();
		exit(-1);
	}
	uinfo.cpid = pid;
	changemode(mode);

	isig = signal(SIGINT, SIG_IGN);
	qsig = signal(SIGQUIT, SIG_IGN);
	while ((w = wait(&status)) != pid && w != 1);
	(void)signal(SIGINT, isig);
	(void)signal(SIGQUIT, qsig);
	restore_tty();
#ifdef DOTIMEOUT
	init_alarm(NA); 
#endif
	uinfo.cpid = 0;
	uinfo.pager = spager;
	changemode(smode);

	return ((w == -1)? w: status);
}

int	sh_exec(mode, com, wd)
int	mode;
char	*com,
	*wd;
{
	char	path[STRLEN],
		fpath[STRLEN];

	(void)strcpy(path, com);
	(void)sprintf(fpath, "%s/%s/%s", BBSHOME, BINDIR, com);
	(void)strtok(path, " ");
	(void)strtok(fpath, " ");
	if (access(path, R_OK) && access(fpath, R_OK))
	{
		move(2, 0);
		clrtoeol();
		prints(NA, "�L�k���榹�@�R�O, �гq�� %s �ﵽ", ADMIN);

		return 0;
	}

	reset_tty();
	(void)do_exec(com, wd, mode);
	restore_tty();
	clear();

	return 0;
}

void	Getyn(s)
char	*s;
{
	prints(NA, "(Yes/No): ");
	clrtoeol();
	while (1)
	{
		switch (*s = igetkey())
		{
			case 'Y':
				*s = 'y';
			case 'y':
				return;
			default:
/*				ochar(CTRL('H'));
				ochar(' ');
				ochar(CTRL('H'));
*/				*s = 'n';
				return;
		}
	}
}

int	copyafter(oldfile, newfile)
char	*newfile,
	*oldfile;
{
	FILE	*new,
		*old;
	char	buff[81];

	if(!(new = fopen(newfile,"a+")))
		return 2;

	if(!(old = fopen(oldfile,"r")))
		return 1;

	while(fgets(buff, sizeof(buff), old) != NULL)
	{
		(void)fprintf(new,"%s",buff);
	}
	(void)fclose(new);
	(void)fclose(old);

	return	0;
}
