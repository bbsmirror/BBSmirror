/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw
                           ������, u8121137@ccunix.ccu.edu.tw
                           ���i�g, u8121142@ccunix.ccu.edu.tw
                           ���ζ�, u8142125@ccunix.ccu.edu.tw
                           ������, glchung@chinyi.ncit.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static	char	SccsId[] = "%W%	%G%";
#endif

#include "bbs.h"
#include <sys/file.h>

extern	cmds	maintlist[],
		xyzlist[],
		talklist[],
		leverlist[],
		filelist[],
		maillist[];
extern	char	*boardmargin(),
		*filemargin(),
		*Ctime();
extern	void	faqview();
extern	int	t_lines,
		started,
		reading;
extern	usinfo	uinfo;

int	usercounter, 
	totalusers, 
	identuser, 
	usernum, 
	scrint = 0, 
	realusernum, 
	tuid, 
	tfile, 
	rfile;
userec	cuser;

char	currboard[STRLEN], 
	genbuf[4096];

int	Announce()
{
	faqview(NULL);

	return 0;
}
                                                                
int	Maintenance()
{
	changemode(MADMIN);

	docmd("[���ץؿ�]", "��J���פu�@�ﶵ: ", 'h', maintlist, boardmargin);
/*	clear();
*/
	changemode(MMENU);

	return 0;
}

int	Xyz()
{
	changemode(XMENU);

	docmd("[�ӤH�u��c]", "�ϥΤu��: ", 'h', xyzlist, boardmargin);
/*	clear();
*/
	changemode(MMENU);

	return 0;
}

int	Talk()
{
	changemode(TMENU);
	docmd("[��ܥؿ�]", "��ѫ��O: ", 'h', talklist, boardmargin);
	changemode(MMENU);
/*	clear();
*/
	return 0;
}

#ifdef	LEVER
int	Lever()
{
	changemode(LMENU);
	docmd("[�����A�ȥؿ�]", "���ε{�����O: ", 'h', leverlist, boardmargin);
	changemode(MMENU);
/*	clear();
*/
	return 0;
}
#endif

#ifdef	FILES
int	Files()
{
	changemode(FMENU);
	docmd("[�ɮפu��]", "�ǰe�ɮשR�O: ", 's', filelist, filemargin);
	changemode(MMENU);
/*	clear();
*/
	return 0;
}
#endif

int	Mail()
{
	int	cmd;

	changemode(MAIL);

	if (chkmails(cuser, NA))
		cmd = 'n';
	else
		cmd = 's';

	docmd("[�H��B�z]", "�H��B�z���O: ", cmd, maillist, boardmargin);

	changemode(MMENU);
/*
	clear();
*/
	return 0;
}

char	uleveltochar(lvl)
usint	lvl;
{
	if (!(lvl & PERM_TRUE))
		return 'n';
	if (lvl < PERM_DEFAULT)
		return '-';
	if (lvl > PERM_IDENT && (lvl & PERM_TRUE))
		return '+';
	return ' ';
}

int	printuent(uentp)
userec	*uentp;
{
	static	int	i;
	char	tmpstring[10], 
		*field2;

#if defined(REALINFO) && defined(ACTS_REALNAMES)
	field2 = "�u��m�W";
#else
	field2 = "�ʦW�ٸ�";
#endif
	if (uentp == NULL)
	{
		move(3, 0);
		clrtoeol();
		prints(YEA, "[1;36;44m%-12s %-15s %-16s %-6s %-6s %-3s %-14s[m\n", 
			"�ϥαb��", field2, "�̪�W���a�I", "#Login", "#Post", 
			HAS_PERM(PERM_SEEULEVELS) ? "Lvl" : " ", 
			"�W���W���ɶ�");
		i = 3;
		return 0;
	}

	if (uentp->userid[0] == '\0' || !strcmp(uentp->userid, "new"))
		return 0;

	if (i == 22)
	{
		int	ch;

		prints(YEA, "[1;36;44m%-79s[m", "-- �٦���� [��'q'����] --");
		clrtoeol();
		while ((ch = igetkey()) != EOF)
		{
			if (ch == 'q' || ch == CTRL('C') || ch == CTRL('D') ||
				ch == KEY_LEFT)
			{
				move(23, 0);
				clrtoeol();
				return QUIT;
			}
			break;
		}
		move(3, 0);
		clrtoeol();
		prints(YEA, "[1;36;44m%-12s %-15s %-16s %-6s %-6s %-3s %-14s[m\n", 
			"�ϥαb��", "�ʦW�ٸ�", "�W���W���a�I", "#Login", 
			"#Post", HAS_PERM(PERM_SEEULEVELS) ? "Lvl" : " ", 
			"�W���W���ɶ�");
		i = 3;
		clrtobot();
	}
	(void)sprintf(tmpstring, " %c ", uleveltochar(uentp->userlevel));
	prints(NA, "%-12.12s %-15.15s %-16.16s  %5d %5d  %-3.3s %-12.12s %c\n", uentp->userid, 
#if defined(REALINFO) && defined(ACTS_REALNAMES)
		uentp->realname, 
#else
		uentp->username, 
#endif
		uentp->lasthost, 
		uentp->numlogins, uentp->numposts, 
	        HAS_PERM(PERM_SEEULEVELS)?tmpstring:" ", 
	        Ctime(&uentp->lastlogin)+4, (HAS_PERM(PERM_UCLEAN) &&
		(uentp->userlevel & PERM_NOCLEAN) ? 'X':' '));
	i++;
/*	if (uentp->userlevel & PERM_TRUE)
		identuser++;
*/	usercounter++;
	return 0;
}

int	countusers(uentp)
userec	*uentp;
{
	if (uentp->userlevel & PERM_TRUE)
		identuser++;
	if (uentp->userid[0] != '\0' && strcmp(uentp->userid, "new"))
		totalusers++;
	if (realusernum++ > MAXUSERS)
		return QUIT;

	return 0;
}

int	Users()
{
	move(3, 0);
	clrtoeol();
	changemode(MUSERS);
	usercounter = totalusers = realusernum = identuser = 0;
	(void)printuent((userec *)NULL);
	if (apply_record(PASSFILE, printuent, sizeof(userec)) == -1)
	{
		prints(NA, "No Users Exist");
		pressreturn();

		changemode(MMENU);

		return 0;
	}
	clrtobot();
	move(2, 0);
	apply_record(PASSFILE, countusers, sizeof(userec));
        prints(NA, "���: %d, �T�{: %d, ����: %d �ϥΪ̡e���U�H�ƤW���G%d�f", 
		usercounter, identuser, totalusers, MAXUSERS);
        pressreturn();

	changemode(MMENU);

	return 0;
}

void	note_sysop()
{
	int	j = 0, 
		i;
        FILE	*fp;
        char	buf[128], 
		*p, 
		ans[2];
	admls	Sysop[MAXADMINS];

        if ((fp = fopen(ADMINLIST, "r")) == NULL)
	{
        	return;
        }   

        while (fgets(buf, 120, fp) != (char) NULL)
	{
        	if (buf[0] == '#' || buf[0] == '\n' || strlen(buf) < 10)
        		continue;
        	i = strlen(buf); buf[i-1] = '\0';
        	p = strtok(buf, " \t\n"); 
        	(void)strcpy(Sysop[j].userid, p);
        	i = strlen(Sysop[j].userid)+1;
        	while (buf[i] == ' ' || buf[i] == '\t')
        		i++;
        	(void)strcpy(Sysop[j].notes, buf+i);
        	j++;
        }

        prints(NA, "\n             ----- ===== �����C�� ===== -----\n");
        prints(NA, "         �s��   %-10s %-35s\n", "���� ID ", "²��           �j�P�t�d����");     
        prints(NA, "   --------------------------------------------------------------------\n");
        for (i = 0; i < j; i++)
	{
        	prints(NA, "   [1;%dm%10d.  %-10s %-35s[m\n" , 31+i%6, i+1, 
			Sysop[i].userid, Sysop[i].notes);
        }

        prints(NA, "   [1;%dm%10d.  ���}[37;40;0m\n", 31+j%6, j+1);
        getdata(t_lines-4, 5, "�z�n�H���֩O ? ", ans, 2, DOECHO, YEA);

        if (ans[0] - '0' > 0 && ans[0] - '0' <= j)
	{
		fhd	mailinfo;

        	i = ans[0]-'0'-1;
        	clear();
		(void)strcpy(mailinfo.sender, Sysop[i].userid);
        	do_send(&mailinfo, NULL);
        }
}

int	note_retry()
{
	int	i, 
		fd, 
		total, 
		len, 
		j = 1;
        struct	stat	st;
        FILE	*fp;
	char	ans[2], 
		buf[256], 
		buf2[256];
        notedta olditem[MAXNOTE], 
		note[MAXNOTE];

	(void)memset(note, 0, sizeof(note));
        move(6, 0);
	clrtobot();
        prints(NA, "\n�A�i�H��W�T�椧�����d��, �� Enter ����\n");

        for (i = 0; i < 3; i++)
	{
        	getdata(8+i, 0, " : ", note[0].buf[i], 78, DOECHO, YEA);
        	if (note[0].buf[i][0] == '\0')
			break;
        }
        getdata(10+i, 0, "[[1;33mS[m]���N [[1;33mE[m]���� [[1;33mA[m]���F���F ? [S] : ", ans, 2, DOECHO, 
        	YEA);
        if (ans[0] == 'E' || ans[0] == 'e')
        	return 1; /* try again */
        if (ans[0] == 'A' || ans[0] == 'a' || (note[0].buf[0][0] == '\0'))
		return 0;

        (void)strncpy(note[0].userid, cuser.userid, 12);
        (void)strncpy(note[0].username, cuser.username, 12);
        (void)time(&(note[0].date));

        if ((fd = open(NOTEDAT, O_RDONLY)) == -1)
        	total = 0;

        if (stat(NOTEDAT, &st) != -1)
        	total = st.st_size/sizeof(notedta);

        if (total > MAXNOTE)
		total = MAXNOTE;

        for (i = 0; i < total; i++)
	{
        	(void)read(fd, (char *) &olditem[i], sizeof(olditem[i]));

/* ��d���O�ɶ� */
                if (olditem[i].date > note[0].date - 3*60*60)
                {
			(void)strcpy(note[j].userid, olditem[i].userid);
                	(void)strcpy(note[j].username, olditem[i].username);
                	(void)strcpy(note[j].buf[0], olditem[i].buf[0]);
                	(void)strcpy(note[j].buf[1], olditem[i].buf[1]);
                	(void)strcpy(note[j].buf[2], olditem[i].buf[2]);
                	note[j].date = olditem[i].date;
                	j++;
                }
        }
        (void)close(fd);

        if ((fd = open(NOTEDAT, O_WRONLY|O_CREAT, 0644)) == 0)
        	return 0;
        if ((fp = fopen(NOTE, "w")) == NULL)
	{
		(void)close(fd);
        	return(0);
	}

	(void)fputs("[1;34;44m����������������������������[0;36;44m��[1;36;44m�� [1;37m�߱���~�� [1;36;44m��[0;36;44m��[1;34;44m������������������������������[m\n", fp);
        for (i = 0; i < j; i++)
	{
		len = 56 - strlen(note[i].userid) - strlen(note[i].username);
        	(void)write(fd, &(note[i]), sizeof(note[i]));
        	(void)sprintf(buf, "[1;34;40m��[1;37;40m%s%s[1;33;40m(%s) [1;34;40m",
			note[i].userid,	(len % 2 == 1) ? "  " : " ",
			note[i].username);
		for (len /= 2; len > 0; len--)
			(void)strcat(buf, "��");
		(void)sprintf(buf2, "%s [1;32;40m%12.12s [1;34;40m��[m\n", buf,
			ctime(&note[i].date) + 4);
        	(void)fputs(buf2, fp);
		for (len = 0; len < 3 && note[i].buf[len][0] != '\0'; len++)
			(void)fprintf(fp, "%s\n", note[i].buf[len]);
        }
	(void)fputs("[m\n", fp);
        (void)fclose(fp);
        (void)close(fd);
	return 0;
}

void	show_goodbye(filename)
char	*filename;
{
	FILE	*fp;
	int	frg, 
		i, 
		matchfrg, 
		strlength, 
		cnt, 
		exp, 
		dble;
	static	char	numlogins[10], 
			numposts[10], 
			exper[10],
			lasttime[30], 
			thistime[30];
	char	buf[256], 
		*ptr, 
		*ptr2;
	time_t	now;

	static	logout loglst[] =
	{
		"userid", 	cuser.userid, 
		"username", 	cuser.username, 
		"realname", 	cuser.realname, 
		"address", 	cuser.address, 
		"email", 	cuser.email, 
		"termtype", 	cuser.termtype, 
		"log", 		numlogins, 
		"pst", 		numposts, 
		"lastlogin", 	lasttime, 
		"lasthost", 	cuser.lasthost, 
		"now", 		thistime, 
		"exp", 		exper, 
		NULL, 		NULL,
	};


	(void)time(&now);
	(void)strcpy(lasttime, Ctime(&cuser.lastlogin));
	(void)strcpy(thistime, Ctime(&now));
	(void)sprintf(numlogins, "%d", cuser.numlogins);
	(void)sprintf(numposts, "%d", cuser.numposts);
	exp = count_exper(&cuser, &dble);
	(void)sprintf(exper, "%d", exp);
	if((fp = fopen(filename, "r")) == NULL)
		return;

	while(fgets(buf, 255, fp) != NULL)
	{
		frg = 1;
		ptr2 = buf;
		do
		{
			if(ptr = strchr(ptr2, '$'))
			{
				matchfrg = 0;
				*ptr = '\0';
				prints(NA, "%s", ptr2);
				ptr += 1;
				for (i = 0; loglst[i].match != NULL; i++)
				{
					if(strstr(ptr, loglst[i].match) == ptr)
					{
						strlength=strlen(loglst[i].match);
						ptr2 = ptr+strlength;
						for(cnt=0; *(ptr2+cnt) == ' '; cnt++);
						prints(NA, "%-*.*s", cnt?strlength+cnt:strlength+1, strlength+cnt, loglst[i].replace);
						ptr2 += (cnt?(cnt-1):cnt);
						matchfrg=1;
						break;
					}
				}
				if(!matchfrg)
				{
					prints(NA, "$");
					ptr2 = ptr;
				}
			}
			else	
			{
				prints(NA, "%s", ptr2);
				frg = 0;
			}
		}
		while(frg);
	}

	refresh();
	(void)fclose(fp);
	return;
}

int	goodbye()
{
	int	num;
	time_t	now;
	char	pathbuf[256];

	(void)memset(&uinfo, 0, sizeof(uinfo));
	update_utmp();

	clear();
	(void)time(&now);

	(void)sprintf(pathbuf, PATH_LOGOUT, cuser.userid);

	if (access(pathbuf, R_OK))
	{
		num = now%(long)LOGOUT_PIC;
		(void)sprintf(pathbuf, "%s%d", LOGOUT, num);
	}
	show_goodbye(pathbuf);
	reset_tty();

	if (started)
		logit(PATH_USIES, "EXIT %-10s %-20s", cuser.userid, 
			cuser.username);

	sleep(3);
	exit(0);
}

int	Goodbye()
{
	int	ans,
		ret;
	char	buf[5];

        ans = getans(2, 0, "�z�n���}�����F (Y/N)? [N]", 'n');
        if (ans != 'y' && ans != 'Y')
	{
		move(2, 0);
		clrtoeol();
		return 0;
	}
	if (!HAS_SET(SET_DISNOTE) && HAS_PERM(PERM_NOTE))
	{
		clear();
	        move(1, 0);
	        prints(NA, " (1) ��ߨƶ�~��d��\n");
	        prints(NA, " (2) �g�ʫH������\n");
	        prints(NA, " (3) ���F���F...\n");
		prints(NA, " (4) ��A�٬O�A���@�U�U�a\n");
	        getdata(6, 5, "�z����� (1, 2, 3 or 4) ? [3]: ", buf, 2,
			DOECHO, YEA);

	       	switch (buf[0])
		{
	        	case '1':
				for (ret = 1; ret != 0; ret = note_retry());
				goodbye();
				break;
	        	case '2':
				note_sysop();
				goodbye();
				break;
			case '4':
				move(2, 0);
				clrtoeol();
				return 0;
	        	default:
				goodbye();
				break;
		}
	}
	goodbye();
	return 0;	/* statment should be never reached */
}

#ifdef FLAG_MAIN_U
int	get_users(uptr)
userec	*uptr;
{
	userec	u;
	char	tbuf[STRLEN];

	(void)memcpy(&u, uptr, sizeof(u));
	tfile = 0;
	rfile = 0;

	if (*(uptr->userid) == '\0')
	{
		tuid++;
		return 0;
	}

	(void)strcpy(tbuf, ctime(&u.lastlogin));
	(void)strncpy(genbuf, tbuf+4, 7);
	genbuf[7] = '\0';
	(void)strcat(genbuf, tbuf+22);
#ifndef FILES
	printf("%-10s %-19s %-9s %-4d  %s", u.userid, u.username, 
		   u.termtype, u.userlevel, genbuf);
#else
	printf("%-10s %-19s %-9s %-4d %6s  %s", u.userid, u.username, 
		   u.termtype, u.userlevel, NameProtocol(u.protocol), genbuf);
#endif
	tuid++;
	return 0;
}

int	UserStatus(void)
{
	tuid = 1;
#ifndef FILES
	printf("%-10s %-19s %-9s %-4s  %s\n", "USER ID", "USERNAME", 
		   "TERMTYPE", "LEVL", "LAST LOGIN");
#else
	printf("%-10s %-19s %-9s %-4s %6s  %s\n", "USER ID", "USERNAME", 
		   "TERMTYPE", "LEVL", "PROTO", "LAST LOGIN");
#endif
	if (apply_record(PASSFILE, get_users, sizeof(userec)) == -1)
	{
		(void)fprintf(stderr, "Error in apply_record\n");
		exit(-1);
	}
	return 0;
}
#endif /* FLAG_MAIN_U */

int	Info()
{
	reading = NA;
	more(VERSION_INFO, YEA);
	reading = YEA;
	clear();
	return 0;
}

int show_welcome()
{
    char   welcome[256];
           time_t now = time(NULL);

    sprintf(welcome, PATH_WELCOME, ((now/60) % MAX_WELCOME_NO));
    if (access(welcome, R_OK) == -1)
    {
        sprintf(welcome, PATH_WELCOME, 0);
    }
    if (access(welcome, R_OK) == -1)
    {
        clear();
        prints(NA, "NOTICE: WELCOME %s ���s�b, ���ˬd�]�w\n", welcome);
        pressreturn();
        return -1;
    }
    more(welcome, YEA);
    return 0;
}

int	Welcome()
{
	reading = NA;
	if (!HAS_PERM(PERM_TRUE))
                more(REGINFO, YEA);
        else
		show_welcome();

	if (more(MOTD, YEA) == -1)
	{
		clear();
		prints(NA, "���ѨS�������T��\n");
		pressreturn();
    	}

	more(BBSNEWS, YEA);
	reading = YEA;
	clear();
	return 0;
}

int	Note()
{
	reading = NA;
	if (more(NOTE, YEA) == -1)
	{
		move(2, 0);
		prints(NA, "�߱���~��W�S������o�m.\n");
		pressreturn();
	}
	reading = YEA;
	clear();
	return 0;
}
