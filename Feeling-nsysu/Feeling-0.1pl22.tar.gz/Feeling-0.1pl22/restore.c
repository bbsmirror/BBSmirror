#include "bbs.h"

void	main(argc, argv)
int	argc;
char	**argv;
{
	char	buf[STRLEN], buffer[STRLEN*2];
	fhd	file;
	FILE	*fp;

	if (argc == 1)	exit(0);
	sprintf(buf, "/home/boards/%s/.DIR", argv[1]);
	fp = fopen(buf, "r");
	if (!fp)	exit(1);
	strtok(buf, ".");
	while (fread(&file, sizeof(fhd), 1, fp) > 0)
	{
		if (!(file.flag & FILE_MARKED))
		{	
			sprintf(buffer, "/bin/rm %s%s", buf, file.filename);
			system(buffer);
		}
	}
	fclose(fp);
}
