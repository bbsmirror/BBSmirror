/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    SccsId[] = "%W%	%G%";
#endif

#include "bbs.h"

extern	usinfo	uinfo;
extern	userec	cuser;
extern	int	num_new,
		t_lines;
extern	char	currboard[];
extern	bhd	*brdlist[MAXBOARD];

extern	int	cmpbname(),
		brdrec(),
		get_num_records(),
		get_records();
extern	usint	setperms();
extern	char	*boardmargin();

usint	result[32];

hlpinfo	VMenuHelp[] = {
     0,  0, HIGH, 0,           "[1;36;44m                         �ѥ[�ݨ��չ�Χ벼���M  �ާ@����                      [m\n\n",
    -1, -1, HIGH, 0,           "[1;36;44m                                  ��в��ʻ���                                 [m\n",
    -1, -1,  LOW, 0,           "p �� n ��           �W �U�@�����\n",
    -1, -1,  LOW, 0,           "P PgUp N PgDn       �W/�U�@��\n",
    -1, -1,  LOW, 0,           "##<cr>              ����J�@�ӼƦr�A��J Enter ��, ���##�����\n",
    -1, -1,  LOW, 0,           "$                   �̫�@�����\n",
    -1, -1,  LOW, 0,           "\n",
    -1, -1, HIGH, 0,           "[1;36;44m                                ��L�`�Ϊ��\\����                               [m\n",
    -1, -1,  LOW, 0,           "��ܤ@�ӧ벼�ΰݨ��չ�ոs   r v RIGHT Enter\n",
    -1, -1,  LOW, 0,	       NULL,
};

hlpinfo VoteHelp[] = {
     0,  0, HIGH, 0,           "[1;36;44m                         �ѥ[�ݨ��չ�Χ벼���M  �ާ@����                      [m\n\n",
    -1, -1, HIGH, 0,           "[1;36;44m                                  ��в��ʻ���                                 [m\n",
    -1, -1,  LOW, 0,           "p �� n ��           �W �U�@�����\n",
    -1, -1,  LOW, 0,           "P PgUp N PgDn       �W/�U�@��\n",
    -1, -1,  LOW, 0,           "##<cr>              ����J�@�ӼƦr�A��J Enter ��, ���##�����\n",
    -1, -1,  LOW, 0,           "$                   �̫�@�����\n",
    -1, -1,  LOW, 0,           "\n",
    -1, -1, HIGH, 0,           "[1;36;44m                                ��L�`�Ϊ��\\����                               [m\n",
    -1, -1,  LOW, 0,           "�ѥ[�벼�ΰݨ��չ�   r v RIGHT Enter\n",
    -1, -1,  LOW, 0,	       "�ݧ벼���G           O\n",
    -1, -1,  LOW, 0,           "�����U�e��           h\n",
    -1, -1,  LOW, PERM_BMS,    "�R���벼�ﶵ         D\n",
    -1, -1,  LOW, PERM_BMS,    "���e���������벼     K\n",
    -1, -1,  LOW, PERM_BMS,    "�W�[�@�ӧ벼�ﶵ     A\n",
    -1, -1,  LOW, 0,           NULL,
};

int	cmpvuid(userid, vinfo)
char	*userid;
votctl	*vinfo;
{
	return !strcasecmp(userid, vinfo->userid);
}

int	cmpvtname(vinfo, buf)
votctl	*vinfo;
int	buf;
{
	return (vinfo->date == buf);
}

/*
 * ���g�벼�ﶵ
 */
int	vote_get_desc(ctl)
votctl	*ctl;
{
	int	i,
		max;
	char	genbuf[STRLEN];

	clear();
	prints(NA, "�}�� %s �O�벼�c:\n", currboard);
	prints(NA, "�벼�ت�: %s\n", ctl->title);
	prints(NA, "������: %d\n", ctl->maxdays);
	for (i = 0; i < 32; i++)
	{
		(void)sprintf(genbuf, "(%c) ", 'A' + i); 
		getdata((i % 16) + 4, 40 * (i / 16), genbuf, ctl->desc[i],
			35, DOECHO, YEA);
		if (strlen(ctl->desc[i]) == 0)
		{
			if (i != 0)
				break;
			i = -1;
		}
	}
	ctl->total = i;
	while (1)
	{
		getdata(22, 0, "�̤j�e�\\�`����: ", genbuf, 4, DOECHO, YEA);
		if ((max = atoi(genbuf)) < 1 || max > i)
			continue;
		break;
	}
	return max;
}

/*
 * �}�ҧ벼
 */
int	vote_open(board)
char	*board;
{
	votctl	ctl;
	bhd	bidx;
	time_t	now;
	int	aborted,
		pos;
	struct	stat	bst;
	char	genbuf[STRLEN];

	if ((pos = search_board(&bidx, board, cmpbname)) <= 0)
		return DONOTHING;

	clear();
	prints(NA, "�}�� %s �O�벼�c:\n", board);

	getdata(2, 0, "�벼�ت�: ", ctl.title, STRLEN, DOECHO, YEA);
	if (ctl.title == '\0')
		return FULLUPDATE;
	while (1)
	{
		getdata(3, 0, "�벼�Ѽ�: ", genbuf, 3, DOECHO, YEA);
		if ((ctl.maxdays = atoi(genbuf)) > 0)
			break;
	}
	ctl.date = time(NULL);

	(void)sprintf(genbuf, PATH_VOTE, board);

	if (stat(genbuf, &bst) == -1)
		(void)mkdir(genbuf, 0755);
	else if (!S_ISDIR(bst.st_mode))
	{
		(void)unlink(genbuf);
		(void)mkdir(genbuf, 0755);
	}
		
	(void)sprintf(genbuf, PATH_VOTE_INFO, board, ctl.date);
	if (aborted = vedit(genbuf, NA))
	{
		clear();
		prints(NA, "���벼�|��\n");
		pressreturn();
		return FULLUPDATE;
	}
	while (!(ctl.maxblts = vote_get_desc(&ctl)));
	(void)strcpy(ctl.userid, cuser.userid);

	if (!(bidx.flag & BHD_VOTEING))
	{
		bidx.flag |= BHD_VOTEING;
		if (switch_record(BOARDS, (char *)&bidx, sizeof(bhd),
			pos) == -1)
			prints(NA, "Error updating BOARDS file...\n");
	}
	(void)sprintf(genbuf, PATH_VOTE_CTL, board);
	if (append_record(genbuf, (char *)&ctl, sizeof(ctl)) == -1)
	{
		if (stat(genbuf, &bst) == -1 || bst.st_size == 0)
		{
			bidx.flag &= ~BHD_VOTEING;
			if (switch_record(BOARDS, (char *)&bidx,
				sizeof(bidx), pos) == -1)
				prints(NA, "�Y�����~, �гq������\n");
		}
		prints(NA, "�ܩ�p, �L�k�}�ҧ벼, �гq������\n");
		return -1;
	}
	return 0;
}

int	vote_check(bits, max)
int	bits,
	max;
{
	int	i,
		count;

	for (i = count = 0; i < 32; i++)
	{
		if ((bits >> i) & 1)
			count++;
	}
	return (count > max);
}

int	count_result(vptr)
ballot	*vptr;
{
	int	i;

	if (vptr == NULL)
	{
		(void)memset(result, 0, sizeof(result));
		return 0;
	}

	for (i = 0; i < 32; i++)
	{
		if ((vptr->voted >> i) & 1)
			(result[i])++;
	}
	return 0;
}

int	vote_make_result(direct, vinfo, ent)
char	*direct;
votctl	*vinfo;
int	ent;
{
	char	info[STRLEN],
		outcome[STRLEN],
		origin[STRLEN],
		desc[STRLEN],
		bltbuf[STRLEN],
		genbuf[WRAPMARGIN];
	FILE	*fin,
		*fout;
	time_t	now;
	int	i,	j,
		pos;
	struct	stat	vst;
	bhd	bidx;
	ballot	blts;

	(void)sprintf(genbuf, PATH_VOTE_BALT, currboard, vinfo->date);

	if (apply_record(genbuf, count_result, sizeof(ballot)) == -1)
		(void)printf("error: %s\n\r", genbuf);

	(void)sprintf(outcome, PATH_VOTE_TEMP, currboard);
	if ((fout = fopen(outcome, "w")) == NULL)
	{
		prints(NA, "�ܩ�p, �L�k���ͧ벼���G�ɮ�, �����벼�L�k����\n");
		egetch();
		return -1;
	}

	(void)sprintf(info, PATH_VOTE_INFO, currboard, vinfo->date);
	if ((fin = fopen(info, "r")) == NULL)
	{
		prints(NA, "�벼���z�ɵL�k�}��, �гq������\n");
		(void)fclose(fout);
		return -1;
	}

	(void)fprintf(fout, "******************************************\n");
	(void)fprintf(fout, "*** �벼�}�Үɶ�: %s", ctime(&(vinfo->date)));
	(void)fprintf(fout, "%.60s �벼�ت�:\n\n", vinfo->title);
	while (fgets(genbuf, WRAPMARGIN, fin) != NULL)
		(void)fprintf(fout, "%s", genbuf);

	(void)fclose(fin);

	(void)fprintf(fout, "\n*** �벼���G��:\n\n");
	(void)fprintf(fout, "      ���� �ﶵ\n");

	for (i = 0; vinfo->desc[i][0] && i < 32; i++)
	{
		(void)fprintf(fout, "(%2d) %5d %.60s\n", i+1, result[i],
			vinfo->desc[i]);
	}

	(void)fprintf(fout, "\n*** �N���չ�:\n\n");
	(void)sprintf(bltbuf, PATH_VOTE_BALT, currboard, vinfo->date);
	for (i = 1; get_record(bltbuf, &blts, sizeof(ballot), i) != -1; i++)
	{
		if (blts.msg[0][0] != '\0')
		{
			(void)fprintf(fout, "==> ���פH: %s\n", blts.userid);
			for (j = 0; j < 3 && blts.msg[j][0] != '\0'; j++)
				(void)fprintf(fout, "%s\n", blts.msg[j]);
		}
	}

	now = time(NULL);
	(void)fprintf(fout, "\n*** %.50s �����ɶ�: %s\n", vinfo->title, ctime(&now));

	(void)sprintf(origin, PATH_VOTE_RES, currboard);
	if ((fin = fopen(origin, "r")) != NULL)
	{
		while(fgets(genbuf, WRAPMARGIN, fin) != NULL)
			(void)fprintf(fout, "%s", genbuf);
		(void)fclose(fin);
	}
	(void)fclose(fout);

	(void)unlink(origin);
	(void)rename(outcome, origin);

	if (delete_file(direct, sizeof(votctl), ent, cmpvtname, vinfo->date))
		return FULLUPDATE;

	(void)sprintf(genbuf, PATH_VOTE_BALT, currboard, vinfo->date);
	(void)unlink(genbuf);
	(void)sprintf(genbuf, PATH_VOTE_INFO, currboard, vinfo->date);
	(void)unlink(genbuf);

	if ((stat(direct, &vst) == -1) || (vst.st_size == 0))
	{
		pos = search_board(&bidx, currboard, cmpbname);
		bidx.flag &= ~BHD_VOTEING;
		switch_record(BOARDS, (char *)&bidx, sizeof(bhd), pos);
	}

	return 0;
}

int	is_vote_complete(vinfo)
votctl	*vinfo;
{
	static	time_t	now;

	if (vinfo == NULL)
		return NA;

	now = time(NULL);
	if (now >= vinfo->date + vinfo->maxdays * 86400)
	{
		return YEA;
	}
	return NA;
}

int	if_vote_runout(board)
char	*board;
{
	int	ans,
		pos,
		end,
		i;
	bhd	bidx;
	struct	stat	vst;
	votctl	vinfo;
	char	ctlbuf[STRLEN],
		direct[STRLEN];

	(void)sprintf(ctlbuf, PATH_VOTE_CTL, board);
	(void)stat(ctlbuf, &vst);
	end = vst.st_size/sizeof(votctl);
	for (i = end; i > 0; i--)
	{
		get_record(ctlbuf, &vinfo, sizeof(votctl), i);
		if (is_vote_complete(&vinfo))
			if (vote_make_result(ctlbuf, &vinfo, i) < 0)
				break;
	}
	if (stat(ctlbuf, &vst) == -1 || vst.st_size == 0)
	{
		pos = search_board(&bidx, currboard, cmpbname);
		bidx.flag &= ~BHD_VOTEING;
		switch_record(BOARDS, (char *)&bidx, sizeof(bhd), pos);
		return YEA;
	}
	return NA;
}

/* ARGSUSED */
int	v_see_result(ent, vinfo, direct)
int	*ent;
votctl	*vinfo;
char	*direct;
{
	char	genbuf[STRLEN];

	(void)sprintf(genbuf, PATH_VOTE_RES, currboard);
	more(genbuf);
	return	FULLUPDATE;
}

/* ARGSUSED */
int	v_vote(ent, vinfo, direct)
int	*ent;
votctl	*vinfo;
char	*direct;
{
	char	genbuf[STRLEN*2],
		vtpath[STRLEN*2];
	ballot	follow,
		lst;
	int	i,
		pos;

	if (is_vote_complete(vinfo))
	{
		if (vote_make_result(direct, vinfo, *ent) < 0)
			return	FULLUPDATE;
		clear();
		move(1, 0);
		prints(NA, "�벼 [%s] ����", vinfo->title);
		pressreturn();
		return FULLUPDATE;
	}

	if (!HAS_PERM(PERM_VOTE))
	{
		bell(1);
		return DONOTHING;
	}
	(void)sprintf(vtpath, PATH_VOTE_BALT, currboard, vinfo->date);
	(void)memset(&follow, 0, sizeof(follow));
	if ((pos = search_record(vtpath, &follow, sizeof(follow), cmpvuid,
		cuser.userid)) <= 0)
	{
		(void)memset(&follow, 0, sizeof(follow));
	}
	(void)strcpy(follow.userid, cuser.userid);
	clear();
	(void)sprintf(genbuf, PATH_VOTE_INFO, currboard, vinfo->date);
	more(genbuf, YEA);
	clear();
	prints(NA, "%s �}�� %s �O�벼�c:\n", vinfo->userid, currboard);
	prints(NA, "�벼�ت�: %s\n", vinfo->title);
	prints(NA, "������: %d, �i�벼��: %d\n", vinfo->maxdays,
		vinfo->maxblts);
	do
	{
		follow.voted = setperms(follow.voted, vinfo->desc);
	}
	while (vote_check(follow.voted, vinfo->maxblts));

        if (!follow.voted)
             return FULLUPDATE;    

	move(4, 0);
	clrtobot();
	prints(NA, "�ж�J�z�_�Q���N��(�T��):\n");

	for (i = 0; i < 3; i++)
	{
		getdata(6 + i, 0, ": ", follow.msg[i], STRLEN, DOECHO, NA);
		if (follow.msg[i][0] == '\0')
			break;
	}

	pos = search_record(vtpath, &lst, sizeof(lst), cmpvuid, cuser.userid);

	if (pos)
	{
		switch_record(vtpath, (char *)&follow, sizeof(follow),
			pos);
	}
	else if (append_record(vtpath, (char *)&follow, sizeof(follow)) == -1)
	{
		move(3, 0);
		clrtoeol();
		prints(NA, "�벼����! �гq�������ѥ[���@�ӿﶵ�벼\n");
		pressreturn();
	}

	return FULLUPDATE;
}

/* ARGSUSED */
int	v_del_vote(ent, vinfo, direct)
int	*ent;
votctl	*vinfo;
char	*direct;
{
	char	genbuf[STRLEN];

	if (is_vote_complete(vinfo))
	{
		vote_make_result(direct, vinfo, *ent);
		clear();
		move(1, 0);
		prints(NA, "�벼 [%s] ����", vinfo->title);
		pressreturn();
		return FULLUPDATE;
	}

	if (!islocalbm())
	{
		bell(1);
		return DONOTHING;
	}

/*	clear();	*/
	move(t_lines-1, 0);
	prints(NA, "�R���ثe�o��%.55s�벼�ܡH", vinfo->title);
	Getyn(genbuf);
	move(t_lines-1, 0);
	clrtoeol();

	if (genbuf[0] != 'y')
	{
		prints(NA, "�����쪬�����R��");
		(void)egetch();
/*		pressreturn();
		clear();	*/
		return FULLUPDATE;
	}
	if (!delete_file(direct, sizeof(votctl), *ent, cmpvtname, vinfo->date))
	{
		(void)sprintf(genbuf, PATH_VOTE_BALT, currboard, vinfo->date);
		(void)unlink(genbuf);
		(void)sprintf(genbuf, PATH_VOTE_INFO, currboard, vinfo->date);
		(void)unlink(genbuf);
		prints(NA, "�w�g�R�� %.55 �벼", vinfo->title);
		(void)egetch();
/*		pressreturn();	*/
	}
	return FULLUPDATE;
}

/* ARGSUSED */
int	v_quit_vote(ent, vinfo, direct)
int	*ent;
votctl	*vinfo;
char	*direct;
{
	char	genbuf[STRLEN];
	int	pos,
		i;

	if (is_vote_complete(vinfo))
	{
		vote_make_result(direct, vinfo, *ent);
		clear();
		move(1, 0);
		prints(NA, "�벼 [%s] ����", vinfo->title);
		pressreturn();
		return FULLUPDATE;
	}

	if (!islocalbm())
	{
		bell(1);
		return DONOTHING;
	}

	clear();
	prints(NA, "���e�����ثe�o��%.55s�벼��?", vinfo->title);
	Getyn(genbuf);

	if (genbuf[0] != 'y')
	{
		move(2, 0);
		prints(NA, "�����쪬�������\n");
		pressreturn();
		clear();
		return FULLUPDATE;
	}
/*
	(void)sprintf(genbuf, PATH_VOTE_BALT, currboard, vinfo->date);

	if (apply_record(genbuf, count_result, sizeof(ballot)) == -1)
		(void)printf("error: %s\n\r", genbuf);
*/
	if (vote_make_result(direct, vinfo, *ent) == -1)
		return FULLUPDATE;

	prints(NA, "[%.55] �벼����", vinfo->title);
	pressreturn();

	return FULLUPDATE;
}

/* ARGSUSED */
int	v_add_vote(ent, vinfo, direct)
int	*ent;
votctl	*vinfo;
char	*direct;
{
	if (!islocalbm())
	{
		bell(1);
		return DONOTHING;
	}
	(void)vote_open(currboard);
}

/* ARGSUSED */
int	v_help(ent, vinfo, direct)
int	*ent;
votctl	*vinfo;
char	*direct;
{
/*	clear();	*/
	do_the_help(VoteHelp);
	pressreturn();
/*	clear();	*/
	return FULLUPDATE;
}

one_key	vot_cmd[] =
{
	'v',		v_vote,
	'r',		v_vote,
	KEY_RIGHT,	v_vote,
	'\r',		v_vote,
	'\n',		v_vote,
	'h',		v_help,
	'D',		v_del_vote,
	'K',		v_quit_vote,
	'A',		v_add_vote,
	'O',		v_see_result,
	'\0',		NULL,
};

void	vot_ttl()
{
/*	clear();	*/
	menu_draw("[�N���չ�P�벼]", boardmargin);
	move(1, 0);
	prints(NA, "%s   %s%s\n",
		"[[1;33m��[m,[1;33me[m] �^�W�@�e��   [[1;33mh[m] �D�U",
		"[[1;33m��[m,[1;33mr <cr>[m] �i��벼  [[1;33m��[m,",
		"[1;33m��[m] �W,�U�@�ӧ벼���");
	prints(YEA, "[1;36;44m%5s  %-12s  %-6s  %4s  %5s  %-37s[m\n",
		"�s��", "�}���c�H", "���", "����", "�H��", "�벼���e²��");
}

void	vot_ent(num, ent)
int	num;
votctl	*ent;
{
	static	int	size = sizeof(ballot);
	struct	stat	pst;
	char	genbuf[STRLEN];

	(void)sprintf(genbuf, PATH_VOTE_BALT, currboard, ent->date);
	if (stat(genbuf, &pst) == -1)
		pst.st_size = 0;
	prints(NA, " %4d  %-12.12s  %6.6s  %4d  %5d  %-37.37s\n", num,
		ent->userid, ctime(&ent->date) + 4, ent->maxdays,
		pst.st_size/size, ent->title);
}

/*
 * �ѥ[/�o��/�I��벼
 */
int	vote_join(board)
char	*board;
{
	char	genbuf[STRLEN];
	bhd	fh;

	search_board(&fh, currboard, cmpbname);
	if (!(fh.flag & BHD_VOTEING))
		return FULLUPDATE;
	if (if_vote_runout(currboard))
		return FULLUPDATE;
	(void)sprintf(genbuf, PATH_VOTE_CTL, board);
	while (i_read(genbuf, vot_ttl, vot_ent, vot_cmd, '\0', sizeof(votctl),
		get_num_records, get_records) == REDOIREAD);
/*	clear();	*/
	return FULLUPDATE;
}

/*--------------------*/
/* �벼�|�椤���O�C�� */
/*--------------------*/

int	vote_board_list(ptr)
bhd	*ptr;
{
	if (ptr->flag & BHD_VOTEING)
		brdlist[num_new++] = ptr;
	return 0;
}

/* ARGSUSED */
int	vt_select(ent, vinfo, direct)
int	*ent;
newhd	*vinfo;
char	*direct;
{
	char	tmpboard[STRLEN];

/*	if (if_vote_runout(vinfo->name))
		return FULLUPDATE;
*/	(void)strcpy(tmpboard, currboard);
	(void)strcpy(currboard, vinfo->name);
	(void)vote_join(vinfo->name);
	(void)strcpy(currboard, tmpboard);
	return	FULLUPDATE;
}

/* ARGSUSED */
int	vt_help(ent, vinfo, direct)
int	*ent;
newhd	*vinfo;
char	*direct;
{
/*	clear();	*/
	do_the_help(VMenuHelp);
	pressreturn();
	return FULLUPDATE;
}

one_key	v_cmd[] =
{
	'\n',		vt_select,
	'\r',		vt_select,
	'h',		vt_help,
	'r',		vt_select,
	KEY_RIGHT,	vt_select,
	'\0',		NULL,
};

/* ARGSUSED */
int	v_num(direct, size)
char	*direct;
int	size;
{
	num_new = 0;
	(void)memset(brdlist, 0, sizeof(brdlist));
	apply_boards(vote_board_list, HAS_SET(SET_YANKIN));
	return num_new;	
};

void	v_title()
{
/*	clear();	*/
	menu_draw("[�N���չ�P�벼�ؿ�]", boardmargin);
	move(1, 0);
	prints(NA, "%s   %s   %s\n",
		"[[1;33m��[m, [1;33me[m]�^�W�@�h���   [[1;33mh[m]�D�U",
		"[[1;33m��[m, [1;33mr[m,[1;33m<cr>[m]�i�J�벼�e��",
		"[[1;33m��[m,[1;33m��[m]�W,�U�@�벼��");
	prints(YEA, "[1;36;44m %4s  %-18s  %-36s  %14s[m\n", "�s��",
		"�Q�װϦW��", "�Q�װϻ���", "�t�d�H");
}

void	v_ent(num, ent)
int	num;
newhd	*ent;
{
	prints(NA, " %4d  %-18.18s  %-36.36s  %14s\n",
		num, ent->name, ent->title, ent->mngs[0]);
}

/*
 * �벼�D�ؿ�
 */
int	vote_follow()
{
	int	savemode;
	char	savebrd[STRLEN];

	changemode(VOTED);
	savemode = uinfo.mode;
	while (i_read(BOARDS, v_title, v_ent, v_cmd, '\0', sizeof(newhd),
		v_num, brdrec) == REDOIREAD);
	changemode(savemode);
	clear();
	return FULLUPDATE;
}

/*------------------------------ END of File ------------------------------*/
