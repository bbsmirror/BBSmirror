/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    SccsId[] = "@(#)files.c	2.1	12/24/95";
#endif

#include "bbs.h"

#if	defined(FILES) || defined(DOWNLOAD)
ptcol protos[] =
{
{ "Kermit", "kermit -si", "kermit -ri"},
{ "Xmodem", "sx -be",       "rx -bpe"},
{ "Ymodem", "sb -be",       "rb -bpe"},
{ "Zmodem", "sz -be",       "rz -bpe"}
};
#endif

#ifdef FILES 

extern	userec	cuser;
extern	usinfo	uinfo;
extern	int	usernum;

static	char	currfile[STRLEN];
char	dirs[MAXDIRSIZE][STRLEN];
int	fileselect = 0,
	numdirs = 0;


#define NUMPROTOS (sizeof(protos)/sizeof(ptcol))

char	*NameProtocol(id)
{
	if (id < 0 || id >= NUMPROTOS)
		return "invalid";
	return protos[id].pname;
}

char	*CurrentProtocol()
{
	return NameProtocol(cuser.protocol);
}

char	*filemargin()
{
	static	char	buf[STRLEN];
	
	if (fileselect)
		sprintf(buf,"File Sub-board is '%s'",currfile);
	else
		sprintf(buf,"No File Sub-board Selected");
	return buf;
}

#undef DIR

int	get_dir()
{
	DIR	*dp;
	struct	direct	*ent;
	struct	stat	status;
	char	genbuf[STRLEN];

	numdirs = 0;
	if ((dp = opendir("ftp/files")) == NULL)
		return -1;
	for(ent = readdir(dp); ent != NULL; ent = readdir(dp))
	{
		if (!strcmp(ent->d_name,"."))
			continue;
		if (!strcmp(ent->d_name,".."))
			continue;
		sprintf(genbuf,"ftp/files/%s",ent->d_name);
		if (stat(genbuf,&status))
			continue;
		if (!(status.st_mode & S_IFDIR))
			continue;
		if (numdirs >= MAXDIRSIZE)
			continue;
		strcpy(dirs[numdirs],ent->d_name);
		numdirs++;
	}
	closedir(dp);
	return 0;
}

int	f_list()
{
	DIR	*dp;
	struct	direct	*ent;
	struct	stat	status;
	int	i,
		col;
	char	buf[512],
		genbuf[STRLEN];

	if (!fileselect)
	{
		move(3,0);
		clrtobot();
		prints(NA, "Use (S)elect to select a sub board first!\n");
		pressreturn();
		return -1;
	}
	move(3,0);
	clrtobot();
	prints(NA, "List of Files on bbs for download\n");
	prints(NA, "%-19s  Size","FILENAME");
	sprintf(buf,"ftp/files/%s",currfile);
	if ((dp = opendir(buf)) == NULL)
		return -1;
	i = 5;
	col = 0;
	for(ent = readdir(dp); ent != NULL; ent = readdir(dp))
	{
		if (!strcmp(ent->d_name,"."))
			continue;
		if (!strcmp(ent->d_name,".."))
			continue;
		sprintf(genbuf,"ftp/files/%s/%s",currfile,ent->d_name);
		if (stat(genbuf,&status))
			continue;
		if ((status.st_mode & S_IFDIR))
			continue;
		if (i == 23)
		{
			col++;
			if (col == 3)
			{
				int	ch;

				move(23,0);
				prints(YEA, "-- More --");
				while ((ch = igetch()) != EOF)
				{
					if (ch == 'q')
					{
						closedir(dp);
						move(23,0);
						clrtoeol();
						return 0;
					}
					if (ch == '\n' || ch == '\r' ||
						ch == ' ')
						break;
					bell(1);
				}
				col = 0;
				move(4, 0);
				clrtobot();
			}
			move(4, col*26);
			prints(NA, "%-19s  Size", "FILENAME");
			i = 5;
		}
		move(i, col*26);
		prints(NA, "%-19s %4dk", ent->d_name,
			(status.st_size + 512) >> 10);
		i++;
	}
	closedir(dp);
	pressreturn();
	return 0;
}

int	f_create_namelist(seed)
char	*seed;
{
	DIR	*dp;
	struct	direct	*ent;
	struct	stat	status;
	char	genbuf[STRLEN];

	if (!fileselect)
	{
		return -1;
	}
	sprintf(genbuf, "ftp/files/%s", currfile);
	if ((dp = opendir(genbuf)) == NULL)
		return -1;
	for(ent = readdir(dp); ent != NULL; ent = readdir(dp))
	{
		if (!strcmp(ent->d_name, "."))
			continue;
		if (!strcmp(ent->d_name, ".."))
			continue;
		if (!(seed == NULL || cmp_bhd_seed(ent->d_name, seed)))
			continue;
		sprintf(genbuf, "ftp/files/%s/%s", currfile, ent->d_name);
		if (stat(genbuf, &status))
			continue;
		if ((status.st_mode & S_IFDIR))
			continue;
		AddLinkList(ent->d_name, strlen(ent->d_name));
	}
	closedir(dp);
	return 0;
}

int	f_download()
{
	char	fname[STRLEN],
		path[512],
		genbuf[STRLEN];
	struct	stat	st;

	if (!fileselect)
	{
		move(3,0);
		clrtobot();
		prints(NA, "Use (S)elect to select a sub board first!\n");
		pressreturn();
		return -1;
	}
	if (cuser.protocol < 0 || cuser.protocol >= NUMPROTOS)
		return 0;
	move(0, 0);
	prints(NA, "%s DOWNLOAD FACILITY\n", CurrentProtocol());
	prints(NA, "Enter Filename: ");
	clrtoeol();
	name_query(NULL, fname, f_create_namelist);
	sprintf(path, "ftp/files/%s/%s", currfile, fname);
	if ((*fname == '\0') || (stat(path, &st) == -1))
	{
		move(2, 0);
		prints(NA, "Invalid File Name\n");
		pressreturn();
		move(0, 0);
		clrtoeol();
		move(1, 0);
		clrtoeol();
		move(2, 0);
		clrtoeol();
		return 1;
	}
	if ((st.st_mode & S_IFDIR))
	{
		move(1, 0);
		prints(NA, "Invalid File Name\n");
		pressreturn();
		move(0, 0);
		clrtoeol();
		move(1, 0);
		clrtoeol();
		move(2, 0);
		clrtoeol();
		return 1;
	}
	move(3, 0);
	clrtobot();
	reset_tty();
	printf("Using %s protocol\n", CurrentProtocol());
	sprintf(genbuf, "%s %s", protos[cuser.protocol].sendbin, path);
	sh_exec(uinfo.mode, genbuf, NULL);
	restore_tty();
	clear();
	pressreturn();
	return 0;
}

int	f_upload()
{
	char	buf[512];
	
	if (!fileselect)
	{
		move(3, 0);
		clrtobot();
		prints(NA, "Use (S)elect to select a sub board first!\n");
		pressreturn();
		return -1;
	}
	if (cuser.protocol < 0 || cuser.protocol >= NUMPROTOS)
		return 0;
	move(3, 0);
	clrtobot();
	reset_tty();
	printf("Using %s protocol\n", CurrentProtocol());
	sprintf(buf, "ftp/files/%s", currfile);
	sh_exec(uinfo.mode, protos[cuser.protocol].recvbin, buf);
	restore_tty();
	clear();
	pressreturn();
	return 0;
}

int	f_protocol()
{
	int	i;
	char	proto[STRLEN];

	move(3, 0);
	clrtobot();
	prints(NA, "PROTOCOL MENU\n");
	for(i = 0; i < NUMPROTOS; i++)
		prints(NA, "%d)  %s\n", i, protos[i].pname);
	move(3, 0);
	prints(NA, "Enter Protocol id (0-%d): ", NUMPROTOS - 1);
	clrtoeol();
	getdata(0, 0, NULL, proto, 3, DOECHO, YEA);
	if (proto[0] == '\0')
		return 0;
	i = atoi(proto);
	if (i < 0 || i >= NUMPROTOS)
		return 0;
	clear();
	cuser.protocol = i;
	UPDATE;
	return 0;
}

int	f_select()
{
	int	i;
	char	buf[STRLEN],
		genbuf[STRLEN];

	get_dir();
	move(3, 0);
	clrtobot();
	prints(NA, "FILE BOARDS MENU\n");
	clrtoeol();
	for(i = 0; i < numdirs; i++)
	{
		move(i % 20 + 4, (i / 20) * 20);
		prints(NA, "%2d) %s", i, dirs[i]);
	}
	sprintf(genbuf, "�����ɮץؿ��s��[0-%d]: ", numdirs - 1);
	clrtoeol();
	getdata(3, 0, genbuf, buf, 3, DOECHO, YEA);
	if (buf[0] == '\0')
		return 0;
	i = atoi(buf);
	if (i < 0 || i >= numdirs)
		return 0;
	clear();
	strcpy(currfile, dirs[i]);
	fileselect = 1;
	return 0;
}

int	f_text()
{
	char	fname[STRLEN],
		path[512];
	struct	stat	st;

	if (!fileselect)
	{
		move(3, 0);
		clrtobot();
		prints(NA, "Use (S)elect to select a sub board first!\n");
		pressreturn();
		return -1;
	}
	move(0, 0);
	prints(NA, "Text Viewing Facility\n");
	prints(NA, "Enter Filename: ");
	clrtoeol();
	name_query(NULL, fname, f_create_namelist);
	sprintf(path, "ftp/files/%s/%s", currfile, fname);
	if ((*fname == '\0') || (stat(path,&st) == -1))
	{
		move(2, 0);
		prints(NA, "Invalid File Name\n");
		pressreturn();
		move(0, 0);
		clrtoeol();
		move(1, 0);
		clrtoeol();
		move(2, 0);
		clrtoeol();
		return 1;
	}
	if ((st.st_mode & S_IFDIR))
	{
		move(1, 0);
		prints(NA, "Invalid File Name\n");
		pressreturn();
		move(0, 0);
		clrtoeol();
		move(1, 0);
		clrtoeol();
		move(2, 0);
		clrtoeol();
		return 1;
	}
	more(path, YEA);
	clear();
	return 0;
}

#endif /* FILES */
