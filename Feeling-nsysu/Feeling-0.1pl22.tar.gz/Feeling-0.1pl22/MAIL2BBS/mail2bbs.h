#define BBSGID          99
#define BBSUID          9999
#define MYNAME          "�����j�ǱI��ڤߤp��"
#define MYENAME         "Feeling BBS"
#define MYNICKNAME      "Feeling"
#define MAILSERVER      "Jei.cc.nsysu.edu.tw"
#define MYHOSTNAME      "Jei.cc.nsysu.edu.tw"
#define ADMIN           "SYSOP"
#define JUNK            "junk"
#define BBSHOME		"/home/bbs"
#define DAEMON          "�t�Ψ����T�{�۰��ˬd"
#define MYPASSFILE      "/.PASSWDS"
#define MYCRCIDX        "/.CRCIDX"
#define BUFLEN          256
#define BRDPATH         "boards/%s"
#define BRDDIR          "boards/%s/%s"
#define LOGREGFILE	"/reclog/trust.log"
