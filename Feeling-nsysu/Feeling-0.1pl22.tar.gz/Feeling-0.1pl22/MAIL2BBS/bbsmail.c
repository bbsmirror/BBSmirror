#include <stdio.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <fcntl.h>
#include <time.h>
#include <errno.h>
#include <string.h>
#include <sys/param.h>
#include <unistd.h>
#include "define.h"
#include "struct.h"

#include "mail2bbs.h"

userec	cuser;

void	eat_queue(fin)
FILE	*fin;
{
	char	genbuf[STRLEN];

	while(fgets(genbuf, sizeof(genbuf), fin) != NULL);
}

char	*Ctime(clock)
time_t	*clock;
{
        char	*foo;
        char	*ptr = ctime(clock);

        if((int)(foo = (char *)strrchr(ptr, '\n')))
                *foo = '\0';

        return (ptr);
}

int	uidcmp(uid,up)
char	*uid;
userec	*up;
{
	if (!strncasecmp(uid, up->userid, sizeof(up->userid)))
	{
		strncpy(uid, up->userid, sizeof(up->userid));
		return 1;
	}
	else
		return 0;
}

int	dosearchuser(userid)
char	*userid;
{
	userec	auser;
	char	path[100];

	sprintf(path, "%s/%s", BBSHOME, MYPASSFILE);
	if (access(path, R_OK) != 0)
	{
		printf("cannot find file: %s\n", path);
		exit(-1);
	}

	return search_record(path, &auser, sizeof(cuser),
        	uidcmp, userid);
}

save_mail(fin, userid)
FILE	*fin;
char	*userid;
{
	fhd	newmessage,
		last;
	struct	tm	*ptime;
	time_t	dtime;
	char	fname[512],
		buf[256],
		genbuf[256],
		title[256],
		sender[80],
		*ip;
	char	pathname[MAXPATHLEN];
	struct	stat	st;
	int	fp,
		curr;
	FILE	*fout;

	if(!dosearchuser(userid))
	{
		printf("cannot find user %s in this bbs\n", userid);
		eat_queue(fin);
		return -1;
	}
	
	sprintf(genbuf, "home/%s/mail", userid);
	printf("mail box is: %s\n", genbuf);
	
	getwd(pathname);
	printf("work dir: %s\n", pathname);
	if (stat(genbuf, &st) == -1)
	{
		perror("cannot find ");
		if (mkdir(genbuf, 0755) == -1) 
		{
			perror("mail box create error");
			eat_queue(fin);
			return -1;
		}
	}
	else
	{	
		if (!(st.st_mode & S_IFDIR))
		{
			printf("mail box is not a DIR\n");
			eat_queue(fin);
			return -1;
		}
	}

	memset(&newmessage, 0, sizeof(newmessage));
	newmessage.date = time(NULL);
	(void)sprintf(genbuf, "home/%s/mail/%s", userid, FHDIR);
	if (stat(genbuf, &st) == -1 || st.st_size == 0)
		curr = 1;
	else
	{
		get_record(genbuf, &last, sizeof(fhd), st.st_size/sizeof(fhd));
		curr = atoi(last.filename+2)+1;
	}	
	(void)sprintf(fname, "S.%010d.A", curr);
	(void)sprintf(genbuf, "home/%s/mail/%s", userid, fname);
	while((fp = open(genbuf, O_CREAT|O_EXCL|O_WRONLY,0644)) == -1)
	{
		(void)sprintf(fname, "S.%010d.A", ++curr);
		(void)sprintf(genbuf, "home/%s/mail/%s", userid, fname);
	}
	(void)close(fp);
	(void)strcpy(newmessage.filename, fname);

        if ((fout = fopen(genbuf, "w")) == NULL)
	{
        	printf("Cannot open %s \n", genbuf);
		eat_queue(fin);
        	return -1;
        }
	else
	{
        	time_t	tmp_time;

		while(fgets(genbuf, 255, fin) != NULL)
		{
			if((char *)strstr(genbuf, "From ") == genbuf)
			{
				strtok(genbuf, " ");
				strcpy(sender, (char *)strtok(NULL, " "));
				if(strchr(sender, '@') == NULL)
                                {
                                        strcat(sender,"@");
					strcat(sender, MYHOSTNAME);
                                }
				strncpy(newmessage.sender, sender, STRLEN);
				continue;
			}
			if((char *)strstr(genbuf, "From: ") == genbuf)
			{
				if (strchr(genbuf, '<') && strchr(genbuf, '>'))
				{
					strtok(genbuf, "<>\n\r\t");
					strcpy(sender, (char *)strtok(NULL, "<>\n\r\t"));
				}
				else
				{
					strtok(genbuf, " \n\r\t");
					strcpy(sender, (char *)strtok(NULL, " \n\r\t"));
				}
				if(strchr(sender, '@') == NULL)
                                {
                                        strcat(sender,"@");
					strcat(sender, MYHOSTNAME);
                                }
				if (strcasecmp(newmessage.sender, sender))
					strncpy(newmessage.sender, sender, STRLEN);
				continue;
			}
			if((char *)strstr(genbuf, "Subject: ") == genbuf)
			{
				int len;

				len = strlen(genbuf+9);
				strncpy(title, genbuf+9, len-1);
				strncpy(newmessage.title, title, STRLEN);
				continue;
			}
			if((char *)strstr(genbuf, "\n") == genbuf)
				break;
		}
		time(&tmp_time);
		fprintf(fout, "�H��H: %s [=InterNet E-mail=]\n", sender);
		fprintf(fout, "��  �D: %s\n", title);
		fprintf(fout, "�o�H��: ��ں����H�� (%s)\n\n", Ctime(&tmp_time));

		fputs(genbuf, fout);
		while (fgets(genbuf, 255, fin) != NULL)
		{
			fputs(genbuf, fout);
		}
		fclose(fout);
	}

/* append the record to the MAIL control file */
	sprintf(genbuf, "home/%s/mail/%s", userid, FHDIR);
	printf("append_record\n");
	return append_record(genbuf, &newmessage, sizeof(newmessage));
}


void	main(argc, argv)
int	argc;
char	*argv[];
{
	char receiver[256];
	char genbuf[256];

	/* argv[1] is userid in bbs   */

	if (argc != 2)
	{
		char *p = (char *)strrchr(argv[0], '/');

		printf("Usage: %s receiver_in_bbs\n", p ? p+1 : argv[0]);
		exit(0);
	}

/*	if (chroot(BBSHOME) == 0)
	{
		chdir("/");
		printf("Chroot ok!\n");
	}
	else
	{
		chdir("/");
		printf("Already chroot\n");
	}
*/
	chdir(BBSHOME);
	setreuid(BBSUID, BBSUID);
	setregid(BBSGID, BBSGID);

	strcpy(receiver, argv[1]);
	printf("mail received by: %s\n", receiver);
	save_mail(stdin, receiver);
	printf("work completed\n");
	exit(0);
}
