#include <stdio.h>

int
GetLoadAve(maxload)
float maxload;
{
 FILE *ProcLoadAve;
 float load;

 if ((ProcLoadAve=fopen("/proc/loadavg", "r"))==NULL)
 return -1;
 if (fscanf(ProcLoadAve,"%f", &load)!=1)
 return -1;
 fclose(ProcLoadAve);
/* if (load > maxload)
 return -1;*/
 return (int)(load+0.5);
}
