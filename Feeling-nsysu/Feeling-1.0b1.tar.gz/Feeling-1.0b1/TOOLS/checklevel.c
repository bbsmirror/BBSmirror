#include <stdio.h>
#include <time.h>
#include "/home/bbsroot/Feeling/INCLUDE/perm.h"

#define	IDLEN	(12)
#define	STRLEN	(80)
#define PASSLEN	(20)
#define	PASS	"/home/bbs/.PASSWDS"

typedef	unsigned int	usint;

typedef struct                          /* PASSFILE struct */
{
        char    userid[IDLEN+2];        /* �b��                         */
        char    filler[25];             /* �w�d                         */
        usint   checksum;               /* �����T�{�Ǹ�                 */
        usint   signum;                 /* ñ�W�ɨϥνs��               */
        char    defboard[20];           /* �w�]�Q�װ�                   */
        usint   userset;                /* �ϥΪ̳]�w                   */
        char    lasthost[16];           /* �W�������a�I                 */
        usint   numlogins;              /* LOGIN ����                   */
        usint   numposts;               /* POST �g��                    */
        char    flags[2];               /* �w�d                         */
        char    passwd[PASSLEN];        /* �K�X                         */
        char    username[STRLEN-40];    /* �ʺ�                         */
        char    mamage[20];             /* �w�d                         */
        char    termtype[STRLEN];       /* TERMINAL ���A                */
        usint   userlevel;              /* �v��                         */
        time_t  lastlogin;              /* �W���W���a�I                 */
        int     protocol;               /* UL/DL �u��(kermit/zmodem..)  */
        char    realname[STRLEN-40];    /* �u��m�W                     */
        char    address[STRLEN];        /* �q�T�a�}                     */
        char    email[STRLEN-8];        /* �����H��a�}                 */
        time_t  mod_email;              /* �̫�@����� E-mail �ɶ�     */
        time_t  reg_date;               /* �ӽбb���ɶ�                 */
}
userec;

void main(argc, argv)
int	argc;
char	**argv;
{
	userec	cuser;
	FILE	*fp;

	fp = fopen(PASS, "r");
	if (fp == NULL)
	{
		puts(".PASSWDS file not found!");
		exit(1);
	}

	while ( fread(&cuser, sizeof(userec), 1, fp) != NULL)
		if (cuser.userlevel & PERM_SPECIAL9)
			printf("%-12.12s %-20.20s %s\n", cuser.userid, cuser.realname, cuser.email);
	fclose(fp);
}