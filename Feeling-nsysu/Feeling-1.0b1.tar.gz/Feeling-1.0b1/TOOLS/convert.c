/*
 * �N gopher �� .Names �ন www �� index.html
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>

gf2www(curr)
char	*curr;
{
	FILE	*fi,
		*fo;
	char	buff[200],
		name[100],
		path[100],
		work[200],
		html[200];
	struct	stat	stbuf;

	printf("current working directory: %s\n", curr);
	sprintf(work, "%s/.Names", curr);

	if ((fi = fopen(work, "rw")) == NULL)
	{
		printf("cannot open file: %s\n", work);
		return -1;	/* gopher .Names file does not exist */
	}

	sprintf(html, "%s/index.html", curr);
	if ((fo = fopen(html, "w")) == NULL)
	{
		printf("cannot open file: %s\n", html);
		fclose(fi);
		return -2;	/* cannot open new index.html for output */
	}
	fputs("<hr><ul><h4>\n", fo);
	while (1)
	{
		if (fgets(buff, 200, fi) == NULL)
			break;	/* close fp and return */
		if (strstr(buff, "Name=") == buff)
		{
			strcpy(name, buff+5);
			name[strlen(name)-1] = '\0';
			continue;
		}
		if (strstr(buff, "Path=") == buff)
		{
			strcpy(path, buff+7);
			path[strlen(path)-1] = '\0';
			fprintf(fo, "<li><a href=%s>%s</a>\n", path, name);
			printf("<li><a href=%s>%s</a>\n", path, name);
			sprintf(name, "%s/%s", curr, path);
			if (stat(name, &stbuf) == -1)
				continue;
			if (S_ISDIR(stbuf.st_mode))
			{
				sprintf(name, "%s/%s", curr, path);
				gf2www(name);
			}
		}
	}
	fputs("</h4></ul><hr>\n", fo);
	fputs("Name=WWW �ؿ��C��\n", fi);
	fputs("Path=./index.html\n", fi);
	fputs("Numb=100\n", fi);
	fputs("#\n", fi);
	fclose(fo);
	fclose(fi);
	return 0;
}

main(argc, argv)
int	argc;
char	**argv;
{
	gf2www((argc > 1) ? argv[1] : "./");
}
