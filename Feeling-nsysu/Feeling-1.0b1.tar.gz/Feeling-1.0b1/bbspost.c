/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    SccsId[] = "@(#)bbspost.c	2.1	%G&";
#endif

char	*ProgramUsage = "\
bbspost (list|visit) bbs_home\n\
	post board_path < uid + title + Article...\n\
	mail board_path < uid + title + passwd + realfrom + Article...\n\
	cancel bbs_home board filename\n\
	expire bbs_home board days [max_posts] [min_posts]\n";

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/file.h>
#include <time.h>
#include <sys/time.h>

#include "define.h"
#include "struct.h"

#define MAXLEN		1024

/*
 * �ɮ�Ū���ݩʳ]�w (for "fhd->flag" and "bbsrc")
 * �����M ~/Feeling/INCLUDE/perm.h �����@�P
 */
#define	FILE_UNREAD	0		/* ��Ū�L */
#define FILE_READ	0x01		/* Ū�L */
#define FILE_OWNED	0x02		/* �����H */
#define	FILE_LOCAL	0x04		/* Local Save */
#define	FILE_SENDED	0x08		/* ��H�e�X */
#define FILE_MARKED	0x10		/* �j�q�R���O�d�Ÿ� */
#define	FILE_RECEIVE	0x20		/* ��H���i�� post */


char	*crypt();
char	*homepath;
int	visitflag;

void	usage()
{
	(void)printf(ProgramUsage);
	exit(0);
}

void	search_article(brdname)
char	*brdname;
{
	fhd	head;
	struct	stat	state;
	char	idxpoint[MAXLEN],	send;
	int 	fd,	num,	offset,	type;

	offset = (int) &(head.flag) - (int) &head;
	(void)sprintf(idxpoint, "%s/boards/%s/.DIR", homepath, brdname);

	if ((fd = open(idxpoint, O_RDWR)) < 0)
	{
		return;
	}

	(void)fstat(fd, &state);
	num = (state.st_size / sizeof(head)) - 1;

	while (num >= 0)
	{
		(void)lseek(fd, num * sizeof(head) + offset, 0);

		if (read(fd, &send, 1) > 0 && ((send & FILE_SENDED) ||
			(send & FILE_RECEIVE)))
		{
			break;
		}
		num -= 4;
	}
	num++;
	if (num < 0)
		num = 0;
	(void)lseek(fd, num * sizeof(head), 0);
	for(send |= FILE_SENDED; read(fd, &head, sizeof(head)) > 0; num++)
	{
		type = head.flag;
		if (!(type & FILE_LOCAL) && !(type & FILE_SENDED) &&
			!(type & FILE_RECEIVE) && visitflag)
		{
			(void)lseek(fd, num * sizeof(head) + offset, 0);
			(void)write(fd, &send, 1);
			(void)lseek(fd, (num + 1) * sizeof(head), 0);
		}
		if (type == '\0')
		{
			(void)printf("%s\t%s\t%s\t%s\n", brdname,
				head.filename, head.sender, head.title);
		}
	}
	(void)close(fd);
}

void	search_boards(visit)
{
	bhd	board;
	char	boardlist[MAXLEN];
	FILE	*fn;

	visitflag = visit;
	(void)sprintf(boardlist, "%s/.BOARDS", homepath);
	if ((fn = fopen(boardlist, "r")) == NULL)
	{
		(void)printf(":Err: unable to open %s\n", boardlist);
		return;
	}
	(void)printf("New article listed:\n");
	while (fread(&board, sizeof(board), 1, fn) > 0)
	{
		search_article(board.filename);
	}
}

int	check_password(record)
userec	*record;
{
	FILE	*fn;
	char	*pw,	passwd[MAXLEN],	realfrom[MAXLEN],
		genbuf[MAXLEN];

	(void)gets(passwd);
	pw = crypt(passwd, record->passwd);
	if (strcmp(pw, record->passwd) != 0)
	{
		(void)printf(":Err: user '%s' password incorrect!!\n",
			record->userid);
		exit(0);
	}
	(void)gets(realfrom);
	(void)sprintf(genbuf, "tmp/email_%s", record->userid);
	if ((fn = fopen(genbuf, "w")) != NULL)
	{
		(void)fprintf(fn, "%s\n", realfrom);
		(void)fclose(fn);
	}
	if (!strstr(realfrom, "bbs@"))
	{
		record->termtype[15] = '\0';
		(void)strncpy(record->termtype+16, realfrom, STRLEN-16);
	}
	if (!strstr(homepath, "test"))
	{
		record->numposts++;
	}
}

int	check_userec(record, name)
userec	*record;
char	*name;
{
	int	fh;

	if ((fh = open(".PASSWDS", O_RDWR)) == -1)
	{
		(void)printf(":Err: unable to open .PASSWDS file.\n");
		exit(0);
	}
	while (read(fh, record, sizeof *record) > 0)
	{
		if (strcasecmp(name, record->userid) == 0)
		{
			(void)strcpy(name, record->userid);
			check_password(record);
			(void)lseek(fh, -1 * sizeof *record, SEEK_CUR);
			(void)write(fh, record, sizeof *record);
			(void)close(fh);
			return;
		}
	}
	(void)close(fh);
	(void)printf(":Err: unknown userid %s\n", name);
	exit(0);
}

int	isprint2(ch)
char	ch;
{
	return(ch & 0x80 ? 1 : isprint(ch));
}

int	strip(str)
char	*str;
{
	int	i;

	for (i = 0; i < strlen(str); i++)
		if (!isprint2(str[i]) && str[i]!='\n' && str[i]!='\r')
			str[i] = '_';
}

char	*Ctime(clock)
time_t	*clock;
{
	char	*foo;
	char	*ptr = ctime(clock);

	if((int)(foo = strrchr(ptr, '\n')))
                *foo = '\0';

	return (ptr);
}

int	post_article(usermail)
{
	struct	stat	st;
	userec	record;
	fhd	header,	last;
	char	userid[MAXLEN],		subject[MAXLEN],
		idxpoint[MAXLEN],	name[MAXLEN],
		article[MAXLEN],	buf[MAXLEN],
		*ptr;
	FILE	*fidx;
	int	fp,	curr;

	(void)memset(&header, 0, sizeof(header));
	(void)sprintf(idxpoint, "%s/.DIR", homepath);
	if ((fidx = fopen(idxpoint, "r")) == NULL)
	{
		if ((fidx = fopen(idxpoint, "w")) == NULL)
		{
			(void)printf(":Err: Unable to post in %s.\n", homepath);
			return;
		}
	}
	(void)fclose(fidx);
	(void)gets(userid);
	(void)gets(subject);
	strip(subject);
	if (usermail)
	{
		check_userec(&record, userid);
	}
	if (stat(idxpoint, &st) == -1 || st.st_size == 0)
		curr = 1;
	else
	{
		get_record(idxpoint, &last, sizeof(fhd), st.st_size/sizeof(fhd));
		curr = atoi(last.filename+2)+1;
	}
	(void)memset(article, 0, sizeof(article));
	(void)sprintf(name, "S.%010d.A", curr);
	(void)sprintf(article, "%s/%s", homepath, name);
	while((fp = open(article, O_CREAT|O_EXCL|O_WRONLY, 0644)) == -1)
	{
		(void)sprintf(name, "F.%010d.G", ++curr);
		(void)sprintf(article, "%s/%s", homepath, name);
	}
	(void)strcpy(header.filename, name);
	header.date = time(NULL);
	if (usermail)
	{
		ptr = strrchr(homepath, '/');
		(ptr == NULL) ? (ptr = homepath) : (ptr++);
		(void)sprintf(buf, "�o�H�H: %s@%s (%s), �H��: %s\n",
			userid, MYNICK, record.username, ptr);
		(void)write(fp, buf, strlen(buf));
		(void)sprintf(buf, "��  �D: %s\n", subject);
		(void)write(fp, buf, strlen(buf));
		(void)sprintf(buf, "�o�H��: %s (%s)\n\n", BOARDNAME,
			Ctime(&header.date));
		(void)write(fp, buf, strlen(buf));
	}
	while (fgets(buf, MAXLEN, stdin) != NULL)
	{
		(void)write(fp, buf, strlen(buf));
	}
	(void)close(fp);
	(void)strcpy(header.filename, name);
	(void)strncpy(header.sender, userid, 76);
	(void)strtok(header.sender, " ");
	(void)strncpy(header.title, subject, STRLEN);
	if (! usermail)
	{
		header.flag |= FILE_RECEIVE;
	}
	append_record(idxpoint, &header, sizeof(header));
}

int	cancel_article(board, file)
char	*board,
	*file;
{
	fhd	header;
	struct	stat 	state;
	char	dirname[MAXLEN],	buf[MAXLEN];
	long	size,	time,	now;
	int	fd,	lower,	ent;

	if (file == NULL || file[0] != 'M' || file[1] != '.' ||
		(time = atoi(file+2)) <= 0)
		return;
	size = sizeof(header);
	(void)sprintf(dirname, "%s/boards/%s/.DIR", homepath, board);
	if ((fd = open(dirname, O_RDWR)) == -1)
		return;
	(void)flock(fd, LOCK_EX);
	(void)fstat(fd, &state);
	ent = ((long)state.st_size) / size;
	lower = 0;
	while (1)
	{
		ent -= 8;
		if (ent <= 0 || lower >= 2)
			break;
		(void)lseek(fd, size * ent, SEEK_SET);
		if (read(fd, &header, size) != size)
		{
			ent = 0;
			break;
		}
		now = atoi(header.filename + 2);
		lower = (now < time) ? lower + 1 : 0;
	}
	if (ent < 0)
		ent = 0;
	while (read(fd, &header, size) == size)
	{
		if (strcmp(file, header.filename) == 0)
		{
			(void)sprintf(buf, "-%s", header.sender);
			(void)strcpy(header.sender, buf);
			(void)lseek(fd, -size, SEEK_CUR);
			safewrite(fd, (char *)&header, sizeof(fhd));
			break;
		}
		now = atoi(header.filename + 2);
		if (now > time)
			break;
	}
	(void)flock(fd, LOCK_UN);
	(void)close(fd);
}

int	expire_article(brdname, days_str, maxpost, minpost)
char	*brdname,
	*days_str;
int	maxpost,
	minpost;
{
	fhd	head;
	struct	stat 	state;
	char	lockfile[MAXLEN],	idxpoint[MAXLEN],
		tmpfile[MAXLEN],	delfile[MAXLEN];
	int	days,	total,	fd,	fdr,	fdw,
		done,	keep,	ftime,	duetime;

	days = atoi(days_str);
	if (days < 1)
	{
		(void)printf(":Err: expire time must more than 1 day.\n");
		return;
	}
	else if (maxpost < 100)
	{
		(void)printf(":Err: maxmum posts number must more than 100.\n");
		return;
	}
	(void)sprintf(lockfile, "%s/boards/%s/.dellock", homepath, brdname);
	(void)sprintf(idxpoint, "%s/boards/%s/.DIR", homepath, brdname);
	(void)sprintf(tmpfile, "%s/boards/%s/.tmpfile", homepath, brdname);
	(void)sprintf(delfile, "%s/boards/%s/.deleted", homepath, brdname);
	if ((fd = open(lockfile, O_RDWR | O_CREAT | O_APPEND, 0644)) == -1)
		return;
	(void)flock(fd, LOCK_EX);
	(void)unlink(tmpfile);
	duetime = time(NULL) - days * 24*60*60;
	done = 0;
	if ((fdr = open(idxpoint, O_RDONLY, 0)) > 0)
	{
		(void)fstat(fdr, &state);
		total = state.st_size / sizeof(head);
		if ((fdw = open(tmpfile, O_WRONLY|O_CREAT|O_EXCL, 0644)) > 0)
		{
			while (read(fdr, &head, sizeof head) == sizeof head)
			{
				done = 1;
				ftime = head.date;
				if (head.sender[0] == '-')
					keep = 0;
				else if (head.flag & FILE_MARKED ||
					total <= minpost)
					keep = 1;
				else if (ftime < duetime || total > maxpost)
					keep = 0;
				else
					keep = 1;
				if (keep)
				{
					if (safewrite(fdw, (char *)&head,
						sizeof(head)) == -1)
					{
						done = 0;
						break;
					}
				}
				else
				{
					(void)printf("Unlink %s\n", head.filename);
					if (head.sender[0] == '-')
						(void)printf("Unlink %s.cancel\n",
							head.filename);
					total --;
				}
			}
			(void)close(fdw);
		}
		(void)close(fdr);
	}

	if (done)
	{
		(void)unlink(delfile);
		if (rename(idxpoint, delfile) != -1)
		{
			(void)rename(tmpfile, idxpoint);
		}
		else
			(void)unlink(tmpfile);
		(void)unlink(delfile);
		(void)unlink(lockfile);
	}
	(void)flock(fd, LOCK_UN);
	(void)close(fd);
}

int	main(argc, argv)
char	*argv[];
{
	char	*progmode;
	int	max,	min;

	if (argc < 3)
		usage();
	progmode = argv[1];
	homepath = argv[2];
	if (strcasecmp(progmode, "list") == 0)
	{
		search_boards(0);
	}
	else if (strcasecmp(progmode, "visit") == 0)
	{
		search_boards(1);
	}
	else if (strcasecmp(progmode, "post") == 0)
	{
		post_article(0);
	}
	else if (strcasecmp(progmode, "mail") == 0)
	{
		post_article(1);
	}
	else if (strcasecmp(progmode, "cancel") == 0)
	{
		if (argc < 5)
			usage();
		cancel_article(argv[3], argv[4]);
	}
	else if (strcasecmp(progmode, "expire") == 0)
	{
		if (argc < 5)
			usage();
		max = atoi(argc > 5 ? argv[5] : "9999");
		min = atoi(argc > 6 ? argv[6] : "10");
		expire_article(argv[3], argv[4], max, min);
	}
	exit(0);
	return 0;
}
