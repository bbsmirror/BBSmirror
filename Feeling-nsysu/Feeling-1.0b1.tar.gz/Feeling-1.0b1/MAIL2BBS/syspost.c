/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

/*
 * ���{���� �i�K�t�γ��i�ϥ�
 */

#ifndef lint
static  char    SccsId[] = "@(#)bbspost.c    0.1    10/14/95";
#endif

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <fcntl.h>
#include <time.h>
#include "define.h"
#include "struct.h"

#include "mail2bbs.h"

userec cuser;
bhd    brdhd;

int cmpbnames(n, brec)
int n;
bhd *brec;
{
    return !strncasecmp((char *)n, brec->filename, sizeof(brec->filename));
}

char   *Ctime(clock)
time_t *clock;
{
    char *foo,
         *ptr = ctime(clock);

    if ((int)(foo = (char *)strrchr(ptr, '\n')))
        *foo = '\0';
        return (ptr);
}

void    eat_queue(fin)
FILE    *fin;
{
        char    genbuf[STRLEN];

        while(fgets(genbuf, sizeof(genbuf), fin) != NULL);
}

int  save_post(fin, board, title)
FILE *fin;
char *board;
char *title;
{
    fhd    newpost,
           last;
    char   fname[512],
           file[256],
           genbuf[256],
           sender[80],
           passwd[80];
    struct stat st;
    int    fp,
           i,
           curr,
           check = NA,
           fault = NA;
    FILE   *fout;

    (void)memset(&last, 0, sizeof(fhd));
    (void)memset(&newpost, 0, sizeof(fhd));
    (void)time(&newpost.date);
    (void)strncpy(newpost.title, title, 79);
    (void)strcpy(newpost.sender, "SYSOP");
    (void)sprintf(file, BRDDIR, board, FHDIR);
    if (stat(file, &st) == -1 || st.st_size == 0)
        curr = 1;
    else
    {
        get_record(file, &last, sizeof(fhd), st.st_size/sizeof(fhd));
        curr = atoi(last.filename+2)+1;
    }
    (void)sprintf(fname, "S.%010d.A", curr);
    (void)sprintf(file, BRDDIR, board, fname);
    while ((fp = open(file, O_CREAT|O_EXCL|O_WRONLY,0644)) == -1)
    {
        (void)sprintf(fname, "S.%010d.A", ++curr);
        (void)sprintf(file, BRDDIR, board, fname);
    }
    (void)close(fp);
    (void)strcpy(newpost.filename, fname);
    (void)sprintf(file, BRDDIR, board, fname);
/*    (void)printf("Ok, the file is %s\n", file );*/
    if ((fout = fopen(file, "w")) == NULL)
    {
        (void)printf("Cannot open %s \n", genbuf );
        eat_queue(fin);
            return -1;
    }
    (void)fprintf(fout, "�o�H�H: SYSOP@%s (�t�γ��i), �H��: %s\n",
        MYNICKNAME, board);
    (void)fprintf(fout, "��  �D: %s\n", title);
    (void)fprintf(fout, "�o�H��: %s (%s)\n\n", MYNAME, Ctime(&newpost.date));
    (void)fputs("\n", fout);
    do
    {
        (void)fputs(genbuf, fout);
    }
    while (fgets(genbuf, 255, fin) != NULL);
    (void)fclose(fout);
    (void)sprintf(genbuf, BRDDIR, board, FHDIR);
    if(append_record(genbuf, &newpost, sizeof(newpost)) == -1)
        return 1;
    return 0;
}

int  main(argc, argv)
int  argc;
char *argv[];
{
    char board[256];
    char title[256];
    bhd  fh;

    if(argc != 3)
    {
        char *p = (char *)strrchr(argv[0], '/');

        (void)printf("Usage: %s [board] [title]\n", p ? p+1 : argv[0]);
        return 1;
    }
    (void)chdir(BBSHOME);
    (void)setreuid(BBSUID, BBSUID);
    (void)setregid(BBSGID, BBSGID);
    (void)strcpy(board, argv[1]);
    (void)strcpy(title, argv[2]);
    if(search_record(BOARDS, (char *)&fh, sizeof(bhd), cmpbnames, (int)board))
        (void)strcpy(board, fh.filename);
    else
        (void)strcpy(board, JUNK);
    (void)save_post(stdin, board, title);
    exit(0);
    return 0;
}
