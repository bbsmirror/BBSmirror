#define BBSGID          30  /* modify to bbs's gid */
#define BBSUID          99  /* modify to bbs's uid */
#define MYNAME          "<<fill bbs full name>>"
#define MYENAME         "TEST BBS"
#define MYNICKNAME      "TEST"
#define MAILSERVER      "<<fill email server hostname>>"
#define MYHOSTNAME      "<<fill my hostnmae>>"
#define ADMIN           "SYSOP"
#define JUNK            "junk"
#define BBSHOME		    "/home/bbs"
#define DAEMON          "�t�Ψ����T�{�۰��ˬd"
#define MYPASSFILE      "/.PASSWDS"
#define MYCRCIDX        "/.CRCIDX"
#define BUFLEN          256
#define BRDPATH         "boards/%s"
#define BRDDIR          "boards/%s/%s"
#define LOGREGFILE	    "/reclog/trust.log"
#define ADDRESS         "<<Fill Postal Address>>"
#define RECEIVER        "<<Fill Receiver>>"
