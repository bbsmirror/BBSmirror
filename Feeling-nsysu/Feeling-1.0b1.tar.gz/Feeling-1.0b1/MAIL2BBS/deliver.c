/*
    ���Ԩ� BBS �{�� (Chariot terminal BBS 0.2 beta 1)
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    SccsId[] = "@(#)deliver.c    0.2    7/19/1997";
#endif

#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>


#include "define.h"
#include "struct.h"
#include "path.h"


#include "mail2bbs.h"

static char work[STRLEN];

static  int    wild_match(mask, name)
char    *mask, *name;
{
    register unsigned char *m = (unsigned char *)mask,
                           *n = (unsigned char *)name;
    char *ma = mask, *na = name;
    int  wild = 0, q = 0;

    while (1)
    {
        if (*m == '*')
        {
            while (*m == '*')
                m++;
            wild = 1;
            ma = (char *)m;
            na = (char *)n;
        }
        if (!*m)
        {
            if (!*n)
                return(0);
            for (m--; (m > (unsigned char *)mask) && (*m == '?'); m--);
            if ((*m == '*') && (m > (unsigned char *)mask) && (m[-1] != '\\'))
                return(0);
            if (!wild)
                return(1);
            m = (unsigned char *)ma;
            n = (unsigned char *)++na;
        }
        else if (!*n)
        {
            while (*m == '*')
                m++;
            return(*m != 0);
        }
        if ((*m == '\\') && ((m[1] == '*') || (m[1] == '?')))
        {
            m++;
            q = 1;
        }
        else
            q = 0;
        if ((tolower(*m) != tolower(*n)) && ((*m != '?') || q))
        {
            if (!wild)
                return(1);
            m = (unsigned char *)ma;
            n = (unsigned char *)++na;
        }
        else
        {
            if (*m)
                m++;
            if (*n)
                n++;
        }
    }
}

int    uidcmp(uid,up)
char   *uid;
userec *up;
{
    if (!strncasecmp(uid, up->userid, sizeof(up->userid)))
    {
        strncpy(uid, up->userid, sizeof(up->userid));
        return -1;
    }
    else
        return 0;
}

int  exist(passfl, userid)
char *passfl, *userid;
{
    userec auser;

    if (access(passfl, R_OK) != 0) exit(-1);
    return (search_record(passfl, (char *)&auser, sizeof(userec), uidcmp,
        (int)userid));
}

char *buildfile(fname)
char *fname;
{
    char   path[STRLEN], idxpoint[STRLEN], genbuf[STRLEN];
    int    fp, curr;
    struct stat st;
    fhd    last;

    if (stat(fname, &st) == -1)
    {
        if (mkdir(fname, 0755) != 0)
            return NULL;
    }
    if (!(st.st_mode & S_ISDIR(st.st_mode)))
        return NULL;
    strcpy(path, fname);
    sprintf(idxpoint, "%s/%s", path, FHDIR);
    if (stat(idxpoint, &st) == -1 || st.st_size == 0)
        curr = 1;
    else
    {
        get_record(idxpoint, (char *)&last, sizeof(fhd), st.st_size/sizeof(fhd))
;
        curr = atoi(last.filename + 2) + 1;
    }
    while (1)
    {
        sprintf(fname, "S.%010d.A", curr);
        sprintf(genbuf, "%s/%s", path, fname);
        if ((fp = open(genbuf, O_CREAT|O_EXCL|O_WRONLY, 0644)) != -1) break;
        if (errno != EEXIST)
        {
            close(fp);
            return NULL;
        }
        curr++;
    }
    close(fp);
    return fname;
}


int  readport(fd, buf)
int  fd;
char *buf;
{
    int  i, l = 0;
    char *s = buf;

    while ((i = read(fd, s, 1)) > 0)
    {
        l += i;
        if (*s == '\n')
            break;
        if (*s != '\r')
            s++;
    }
    *s = 0;
    return l;
}
/*
 * �e�X�ӥ��T�{�H
 */
int  deliver(userid, email, date, checksum, modify)
char *userid, *email, *date;
int  checksum, modify;
{
    struct sockaddr_in sin;
    struct hostent *host;
    int    mfd;
    char   buf[256], tmpbuf[256];

    printf("send out identify mail to: %s in %s as %d\n", userid, email,
        checksum);
    sin.sin_family = AF_INET;
    sin.sin_port = htons(25);
    host = gethostbyname(MAILSERVER);
    memcpy(&sin.sin_addr.s_addr, host->h_addr_list[0], host->h_length);
    mfd = socket(AF_INET, SOCK_STREAM, 0);
    if (mfd < 0) return -2;
    if (connect(mfd, (struct sockaddr *)&sin, sizeof(sin)) < 0) return -2;
    sprintf(buf, "HELO %s\n", MYHOSTNAME);
    write(mfd, buf, strlen(buf));
    while (1)
    {
        readport(mfd, tmpbuf);
        if (atoi(tmpbuf) ==  250) break;
        if (atoi(tmpbuf) > 400)
        {
            close(mfd);
            return -1;
        }
    }
    sprintf(buf, "MAIL From:<%s.reg@%s>\n", userid, MYHOSTNAME);
    write(mfd, buf, strlen(buf));
    readport(mfd, tmpbuf);
    if (strstr(tmpbuf, "250") != tmpbuf)
    {
        close(mfd);
        return -1;
    }
    sprintf(buf, "RCPT To:<%s>\n", email);
    write(mfd, buf, strlen(buf));
    readport(mfd, tmpbuf);
    if (strstr(tmpbuf, "250") != tmpbuf)
    {
        close(mfd);
        return -1;
    }
    sprintf(buf, "DATA\n");
    write(mfd, buf, strlen(buf));
    readport(mfd, tmpbuf);
    if (strstr(tmpbuf, "354") != tmpbuf)
    {
        close(mfd);
        return -1;
    }
    sprintf(buf, "To: %s\n", email);
    write(mfd, buf, strlen(buf));
    sprintf(buf, "Subject: [%d] BBS account E-mail Identify\n\n", checksum);
    write(mfd, buf, strlen(buf));
    sprintf(buf, "%s(%s), �z�n:\n\n", email, userid);
    write(mfd, buf, strlen(buf));
    if (modify == 1)
    {
        sprintf(buf, "    You modified your e-mail at %s in %s BBS.\n", date,
            MYNICK);
        write(mfd, buf, strlen(buf));
        sprintf(buf, "    �z�b %s ��� E-mail Address �]�w\n\n", date);
        write(mfd, buf, strlen(buf));
    }
    else if (modify == 2)
    {
	sprintf(buf, "    You email identification is out of date at: %s.\n",
	     date);
	write(mfd, buf, strlen(buf));
	sprintf(buf, "    �z�� Email �����{�ҩ� %s ���.\n", date);
	write(mfd, buf, strlen(buf));
    }
    else
    {
        sprintf(buf, "    You registered an account at %s in %s BBS.\n", date,
            MYNICK);
        write(mfd, buf, strlen(buf));
        sprintf(buf, "    �z�b %s �ӽ� %s �b��\n\n", date, BOARDNAME);
        write(mfd, buf, strlen(buf));
    }
    sprintf(buf, "    Please Reply this E-mail to identify\n");
    write(mfd, buf, strlen(buf));
    sprintf(buf, "    �бN���H��^�Цܭ�o�H�a�I, �H�i��T�{�z������\n\n");
    write(mfd, buf, strlen(buf));
    sprintf(buf, "    PLEASE KEEP THE SUBJECT OF THIS MAIL\n");
    write(mfd, buf, strlen(buf));
    sprintf(buf, "    �аȥ��O�d���H�� \"Subject:\" ����\n\n");
    write(mfd, buf, strlen(buf));
    sprintf(buf, "    PS: please read Feeling BBS SYSOP BOARD for more\n");
    write(mfd, buf, strlen(buf));
    sprintf(buf, "    PS: �i�@�B�����T��, �Ц� %s SYSOP �O�d��\n", BOARDNAME);
    write(mfd, buf, strlen(buf));
    sprintf(buf, "\n.\n");
    write(mfd, buf, strlen(buf));
    readport(mfd, tmpbuf);
    if (strstr(tmpbuf, "250") != tmpbuf)
    {
        close(mfd);
        return -1;
    }
    sprintf(buf, "QUIT\n");
    write(mfd, buf, strlen(buf));
    readport(mfd, tmpbuf);
    if (strstr(tmpbuf, "221") != tmpbuf)
    {
        close(mfd);
        return -1;
    }
    close(mfd);
}

char   *Ctime(clock)
time_t *clock;
{
    char *foo, *ptr = ctime(clock);

    if ((foo = (char *)strrchr(ptr, '\n')) != NULL) *foo = '\0';
    return (ptr);
}

/*
 * �B�z�L�k���e email address �� modem user �q������
 */
int  host_error(userid, email)
char *userid, *email;
{
    fhd    info;
    char   fname[STRLEN], genbuf[STRLEN];
    FILE   *fp;
    time_t ti;

    printf("cannot deliver to: %s (%s)\n", email, userid);
    time(&ti);
    info.date = ti;
    strcpy(info.sender, ADMIN);
    strcpy(info.title, "E-mail Address ERROR");
    sprintf(fname, "%s/%s/%s/mail/", work, MYHOME, userid);
    if (buildfile(fname) == NULL)
        return -1;
    strcpy(info.filename,fname);
    sprintf(genbuf, "%s/%s/%s/mail/%s", work, MYHOME, userid, fname);
    if ((fp = fopen(genbuf, "w")) == NULL) return -1;
    fprintf(fp, "�H��H: %s@%s (%s)\n", ADMIN, MYNICK, DAEMON);
    fprintf(fp, "��  �D: %s\n", info.title);
    fprintf(fp, "�o�H��: %s (%s)\n\n", BOARDNAME, Ctime(&ti));
    fprintf(fp, "%s, �z�n:\n\n", userid);
    fprintf(fp, "    �g�L�t�άd��, �z�� E-mail Address �L�k���e�H��.\n");
    fprintf(fp, "    �]�w�p�U: %s\n\n", email);
    fprintf(fp, "    �Y�z�O�ϥ� IP Address, �p: 111.222.333.444 ���A,\n");
    fprintf(fp, "    �г]�w�z�� E-mail Address �p�P�H�U����.\n");
    fprintf(fp, "    ==> account@[111.222.333.444]\n\n");
    fprintf(fp, "    �Y�z�� E-mail Address ���]�w�L�� Mail Server(MX),\n");
    fprintf(fp, "    �Ҧp: xxx@OZ.nthu.edu.tw �Ч�θ� MX �� Hostname.\n");
    fprintf(fp, "    �Y��� xxx@y11.Oz.nthu.edu.tw, �N��. ����.\n\n");
    fprintf(fp, "    �Ъ`�N, �b IP-ADDRESS �e����O�[�W '[' ']'\n\n");
    fprintf(fp, "    �_�h�i��O�z�� HOSTNAME �L�k��{, �гq���z�Ҧb�t��\n");
    fprintf(fp, "    ���޲z�H��, �ШD��U. ���±z���X�@.\n\n");
    fprintf(fp, "    PS: ���H��Ѩt�Φ۰ʵo�X, �����D�Ь� SYSOP �O\n");
    fclose(fp);
    sprintf(genbuf, "%s/%s/mail/%s", MYHOME, userid, FHDIR);
    if (append_record(genbuf, (char *)&info, sizeof(info)) == -1) return -1;
    return 0;
}

int  modem_user(userid, illegal, email)
char *userid, *email;
int  illegal;
{
    fhd    info;
    char   fname[STRLEN], genbuf[STRLEN];
    FILE   *fp;
    time_t ti;

    time(&ti);
    info.date = ti;
    strcpy(info.sender, ADMIN);
    strcpy(info.title, "MODEM BBS USER");
    sprintf(fname, "%s/%s/%s/mail/", work, MYHOME, userid);
    if (buildfile(fname) == NULL)
        return -1;
    strcpy(info.filename,fname);
    sprintf(genbuf, "%s/%s/%s/mail/%s", work, MYHOME, userid, fname);
    if ((fp = fopen(genbuf, "w")) == NULL) return -1;
    fprintf(fp, "�H��H: %s@%s (%s)\n", ADMIN, MYNICK, DAEMON);
    fprintf(fp, "��  �D: %s\n", info.title);
    fprintf(fp, "�o�H��: %s (%s)\n\n", BOARDNAME, Ctime(&ti));
    fprintf(fp, "%s, �z�n:\n\n", userid);
    if (illegal)
    {
        fprintf(fp, "    �g�T�{, �z�����T�{�ҥΪ� E-mail ���C�ޱb��,\n");
        fprintf(fp, "    ****> %s <****\n", email);
    }
    else
        fprintf(fp, "    �g�T�{, �ѩ�z����Ʀ��X�k�� E-mail Address,\n");
    fprintf(fp, "    �����ȮɵL�k���ѱz���㪺�� user �Ҧ��\\��.\n\n");
    fprintf(fp, "    �Ш̷ӥH�U�覡�i���@�B�������T��:\n");
    fprintf(fp, "         �бN�z�������ҥ��ϭ��v�L��, �[���i�b�����b���j��,\n");
    fprintf(fp, "         �H��: %s\n", ADDRESS);
    fprintf(fp, "               %s��\n\n", RECEIVER);
    fprintf(fp, "    �Y���g�����짴�����T�{����, �����N���^�b���ѥL�H�ϥ�.\n");
    fprintf(fp, "    ���±z���X�@.\n\n");
    fprintf(fp, "    PS: ���H��Ѩt�Φ۰ʵo�X, ������ðݽЦ� SYSOP �O�߰�.\n");
    fclose(fp);
    sprintf(genbuf, "%s/%s/%s/mail/%s", work, MYHOME, userid, FHDIR);
    if (append_record(genbuf, (char *)&info, sizeof(info)) == -1) return -1;
    return 0;
}

int illegal_email(mail)
char *mail;
{
    FILE *fp;
    char buf[128], path[80];

    sprintf(path, "%s/etc/illegal", work);
    if ((fp = fopen(path, "r")) == NULL)
        return 0;
    memset(buf, 0, sizeof(buf));
    while (fgets(buf, sizeof(buf), fp) != NULL)
    {
        buf[strlen(buf)-1] = '\0';
        if (wild_match(buf, mail) == 0)
        {
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}

/*
 * �ˬd email-address �O�_���T
 * return: -1 �����~�o��
 * return: -2 �� email �� bbs user
 * return: -3 �� email �����ӻ{
 * return:  0 ���`, �i�e�H
 */
int  check_host(email)
char *email;
{
    char   tmp[256];
    int    i, ip = TRUE;
    struct hostent *host;

    if (strstr(email, "modem.bbs.user") || strstr(email, ".bbs@")) return -2;
    if (strchr(email, '@') == email) return -1;
    if (strchr(email, '@')) strcpy(tmp, (char *)strchr(email, '@')+1);
    for (i = 0; i < strlen(tmp); i++)
    {
        if (isalpha(tmp[i]))
        {
            ip = FALSE;
            break;
        }
    }
    if (illegal_email(email)) return -3;
    if (tmp[0] == '[' && tmp[strlen(tmp)-1] == ']')
        return ((ip == TRUE) ? 0 : -1);
    return (gethostbyname(tmp) ? 0 : -1);
}

int     cmpuids(uid,up)
char    *uid;
userec  *up;
{
        return !strncasecmp(uid, up->userid, sizeof(up->userid));
}

void clear_chksum(userid)
int  userid;
{
    userec auser;
    ucrc   acrc;
    int    uid;

    if ((uid = search_record(PASSFILE, &auser, sizeof(userec), cmpuids,
        userid)) == 0)
        return;
    if (get_record(CRCIDX, &acrc, sizeof(ucrc), uid) == 0)
        return;
    auser.checksum = acrc.checksum = 0;
    switch_record(PASSFILE, &auser, sizeof(userec), uid);
    switch_record(CRCIDX, &acrc, sizeof(ucrc), uid);
}

/*
 * �N�����T�{�H��e�X
 */
void identify(userid, email, date, checksum, modify)
char *userid, *email, *date;
int  checksum, modify;
{
    switch (check_host(email))
    {
        case -1:
            host_error(userid, email);
            clear_chksum(userid);
            break;
        case -2:
            modem_user(userid, 0, email);
            clear_chksum(userid);
            break;
        case -3:
            modem_user(userid, 1, email);
            clear_chksum(userid);
            break;
        default:
            deliver(userid, email, date, checksum, modify);
            break;
    }
}

/*
 * �N�O���q log file �����X, �ä����o�� userid, email, checksum, �ε��U�ɶ�
 * �ñN�����T�{ mail �e�X
 */
int  prase_log(passfl, file)
char *passfl, *file;
{
    FILE *fp;
    char buffer[256], userid[STRLEN], email[STRLEN], date[STRLEN], *p;
    int  checksum, modify;

    if ((fp = fopen(file, "r")) == NULL) return -1;
    while (fgets(buffer, sizeof(buffer), fp) != NULL)
    {
        if (strstr(buffer, "modify")) modify = 1;
	if (strstr(buffer, "out_date")) modify = 2;
        if ((p = (char *)strtok(buffer, "]")) == NULL) continue;
        strcpy(date, p+1);
        if (strtok(NULL, ":") == NULL) continue;
        if ((p = (char *)strtok(NULL, " ")) == NULL) continue;
        strcpy(userid, p);
        if ((p = (char *)strtok(NULL, " ")) == NULL) continue;
        strcpy(email, p);
        if ((p = (char *)strtok(NULL, " ")) == NULL) continue;
        checksum = atoi(p);
        if (exist(passfl, userid))
            identify(userid, email, date, checksum, modify);
    }
    fclose(fp);
    return 0;
}

/*
 * �N�ª� file �ন�s�� filename, ���s�ӽбb���� user �i�H
 * �N�L���s�b���g�J��Ӫ� filename, ���|�]�����b�B�z�Ӥ��_
 * �ο򥢱b���T�{�u�@.
 */
int  main(argc, argv)
int  argc;
char *argv[];
{
    FILE *fp;
    char REG_ORI[STRLEN], REG_SRC[STRLEN], PASSFLE[STRLEN];

    if (argc != 3)
    {
        printf("Usage: %s bbs_home reg_file\n", argv[0]);
        return (-1);
    }
    fclose(stderr);
    strcpy(REG_ORI, argv[2]);
    strcpy(work, argv[1]);
    sprintf(REG_SRC, "%s.%d", REG_ORI, getpid());
    sprintf(PASSFLE, "%s/%s", work, PASSFILE);
    if (access(REG_ORI, R_OK)) return (0);
    rename(REG_ORI, REG_SRC);
    if (prase_log(PASSFLE, REG_SRC)) return (-2);
    unlink(REG_SRC);
    return (0);
}
