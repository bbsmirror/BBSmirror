/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    SccsId[] = "%W%	%G%";
#endif

#include <memory.h>
#include "bbs.h"

extern	int	usernum,
		in_mail,
		t_lines,
		scrint,
		selboard,
		reading;
extern	char	save_title[],
		currboard[];
extern	userec	cuser,
		muser;
extern	cmds	cmdlist[],
		maillist[];
extern	one_key	multi_kick_cmd[];

extern	int	kickall(),
		init_access(),
		show_welcome(),
		cmpbname();
extern	void	update_utmp(),
		cmds_help(),		prints(),
		get_tty(),		init_tty(),
		initdsk(),		move(),
		clrtoeol(),		clrtobot(),
		reset_tty(),		redodsk(),
		show_message(),
		init_alarm();
extern	long	GetStrCrc();
extern	char	*Ctime();

jmp_buf	byebye;

int	talkrequest = NA,
	started = 0,
	utmpent = -1,
	refscreen = NA,
	dumb_term = YEA;
FILE	*ufp;
char	*msgrequest = NULL;
char	lasthost[STRLEN],
	BoardName[STRLEN];
usinfo	uinfo;
time_t	lastlogin;

int	keep_edit()
{
        char    bkfini[STRLEN],
                bkf[STRLEN],
                fname[STRLEN],
                path[STRLEN],
                recpath[STRLEN],
		saveptcb[STRLEN];
                
        int     fd,
        	aborted;
        backup  bkrec;
        fhd     mailfile;
        fhd     postfile;
      
        (void)memset(&bkrec, 0, sizeof(bkrec));
	(void)memset(&mailfile, 0, sizeof(mailfile));
	(void)memset(&postfile, 0, sizeof(postfile));
        clear();
        (void)sprintf(bkf, PATH_BACKUP, cuser.userid);
        (void)sprintf(bkfini, PATH_BKINFO, cuser.userid);

        if((fd = open(bkfini, O_RDONLY, 0666)) == -1)
                return -1;

        (void)read(fd, &bkrec, sizeof(bkrec));
      
	BACKUP(uinfo.ptcb, saveptcb);
        switch(bkrec.type)
        {
                case 'M':
			changemode(SMAIL);
                        (void)sprintf(path, "%s/%s/mail/", MYHOME, bkrec.sendto);
                        (void)sprintf(recpath, "%s/%s/mail/.DIR", MYHOME, bkrec.sendto);
                        break;
                case 'P':
			(void)strncpy(uinfo.ptcb, bkrec.sendto, sizeof(uinfo.ptcb));
			changemode(POSTING);
                        (void)sprintf(path, "boards/%s/", bkrec.sendto);
                        (void)sprintf(recpath, "boards/%s/.DIR", bkrec.sendto);
                        break;
		default:
			(void)strcpy(fname, bkrec.sendto);
			break;                
        }
        if(bkrec.type == 'M' || bkrec.type == 'P')
        {
        	(void)strcpy(fname, path);
        	(void)buildfile(fname);
        	(void)strcpy(currboard, bkrec.sendto);
                (void)strcpy(save_title, bkrec.subject);
        }
        switch(bkrec.type)
        {
                case 'M':
                        (void)strcpy(mailfile.title, bkrec.subject);
                        (void)strcpy(mailfile.filename, fname);
                        (void)strcpy(mailfile.sender, cuser.userid);
			mailfile.date = time(NULL);
                        in_mail = YEA;
                        break;
		case 'P':                        
		       	(void)strcpy(postfile.title, bkrec.subject);
                        (void)strcpy(postfile.filename, fname);
			postfile.date = time(NULL);
			if (check_setting(currboard, BHD_ANONYMOUS))
				(void)strcpy(postfile.sender, "Anonymous");
			else
				(void)strncpy(postfile.sender, cuser.userid, STRLEN);
                        break;
		default:
			break;                        
        }
        if(bkrec.type == 'M' || bkrec.type == 'P')
        {
	        (void)strcat(path, fname);
	        (void)strcpy(fname, path);
	}	        
        copyto(bkf, fname);
	unlink(bkf);
        
        if((aborted = vedit(fname, bkrec.writehd)) == -1)
        {
              prints(NA, "Abort !!\n");
              return;
        }
        if(bkrec.type == 'P' && aborted == LOCALSAVE)
        	postfile.flag |= FILE_LOCAL;
	RESTORE(uinfo.ptcb, saveptcb);
        if(bkrec.writehd == YEA)
	{
	        if(bkrec.type == 'M')
	        {
	                return append_record(recpath, &mailfile, sizeof(mailfile));
	                in_mail = NA;
	        }
	        else
	        {
#ifdef	BBSTONEWS
	        	if (postfile.flag & FILE_LOCAL == 0)
	        	if (append_transform(&postfile) == -1)
			{
                                prints(NA, POST_ERRTRANSFORM, ADMIN);
				pressreturn();
			}
#endif
	                return append_record(recpath, &postfile, sizeof(postfile));
	        }
	}
	return	0;
}

int     chkbackup()
{
        char    bkfile[STRLEN];
        int     ans;
        int     fd ;

        (void)sprintf(bkfile, PATH_BKINFO, cuser.userid);
        if ((fd = open(bkfile,O_RDONLY)) == -1)
                return 0;
        (void)close(fd);
        clear();
        move(0, 0);
        prints(NA, "!! �A���@�g�|���s�觹�����ɮ�, �аݧA�Q:");
        ans = getans(2, 0, BACKUP_EDIT_MSG, 'e');
        switch(ans)
        {
                case 'k':
                case 'K':
                        (void)unlink(bkfile);
                        (void)sprintf(bkfile, PATH_BACKUP, cuser.userid);
                        (void)unlink(bkfile);
                        break;
                case 'b':
                case 'B':
                	(void)unlink(bkfile);
                        break;
                case 'E':
                case 'e':
                default:
			(void)keep_edit();
                        break;
        }        
        return 0;
}

int	u_enter(from)
char	*from;
{
	char	myhome[STRLEN];
	ucrc	crcidx;
	time_t  now = time(NULL);
	
	get_record(CRCIDX, (char *)&crcidx, sizeof(ucrc), usernum);
	if (crcidx.level != cuser.userlevel)
	    cuser.reg_date = time(NULL);
	uinfo.userlevel = cuser.userlevel = crcidx.level;
	if ((now - cuser.reg_date >= 180*24*60*60) && !HAS_PERM(PERM_IDCOPY))
	{
	    uinfo.userlevel = cuser.userlevel = crcidx.level &= ~PERM_TRUE;
	    cuser.checksum = crcidx.checksum = crcidx.crcnum + now;
	    logit(LOG_NEWUSER, "out_date: %s %s %d", cuser.userid,
		cuser.email, cuser.checksum);
	}
	uinfo.active = YEA;
	uinfo.pid    = getpid();
	uinfo.cpid   = 0;

	(void)strcpy(lasthost, cuser.lasthost);
	(void)strncpy(cuser.lasthost, from, 15);
	cuser.lasthost[15] = '\0';

	(void)memcpy((char *)&lastlogin, (char *)&cuser.lastlogin,
		sizeof(lastlogin));
	(void)time(&cuser.lastlogin);

	cuser.numlogins++;

	UPDATE;

	if (HAS_PERM(PERM_LOGINCLOAK))
		uinfo.invisible = HAS_SET(SET_CLOAK);
	else
		uinfo.invisible = NA;
	uinfo.sockactive = NA;
	uinfo.sockaddr = 0;
	uinfo.destuid = 0;
	uinfo.mode = LOGIN;
	uinfo.pager = !HAS_SET(SET_PAGER);
	uinfo.allpager = !HAS_SET(SET_ALLPAGER);
	uinfo.comp = !HAS_SET(SET_ACCEPTMSG);
	(void)memset((char *)uinfo.ptcb, 0, sizeof(uinfo.ptcb));
	uinfo.uid = usernum;
	(void)strncpy(uinfo.userid, cuser.userid, IDLEN);
	(void)strncpy(uinfo.realname, cuser.realname, 39);
	(void)strncpy(uinfo.username, cuser.username, 39);
	(void)strncpy(uinfo.termtype, cuser.termtype, 71);
	(void)memcpy((char *)&uinfo.lastlogin, (char *)&cuser.lastlogin,
		sizeof(time_t));
#ifdef LIST_IDLE_TIME
	(void)strncpy(uinfo.ttyname, (char *)ttyname(0), 15);
#endif
	(void)strncpy(uinfo.from, from, 20);
	utmpent = getnewutmpent(&uinfo);

	(void)sprintf(myhome, PATH_USER, cuser.userid);
	if (access(myhome, R_OK))
		(void)mkdir(myhome, 0700);
}

int	cmpuids(uid,up)
char	*uid;
userec	*up;
{
	return !strncasecmp(uid, up->userid, sizeof(up->userid));
}

int	cmpuids2(unum, urec)
int	unum;
usinfo	*urec;
{
	return ((unum == urec->uid) && (urec->pid != uinfo.pid));
}

void	abort_bbs()
{
    if (started)
	logit(PATH_USIES, "AXXED %-10s %-20s", cuser.userid, cuser.username);

    exit(0);
}

int	new_locate()
{
	int	fd,
		ret = -1,
		size,
		locid;
	userec	info;

	if ((fd = open(PASSFILE, O_RDWR|O_CREAT, 0600)) == -1)
	{
		perror("open");
		return -1;
	}
	(void)close(fd);

	size = sizeof(userec);

        for (locid = 1; locid <= MAXUSERS; locid++)
        {
                (void)memset((char *)&info, 0, sizeof(userec));
                if (get_record(PASSFILE, (char *)&info, size, locid) ||
                        info.userid[0] == '\0')
                {
			ret = locid;
                        (void)strcpy(info.userid, "new");
                        (void)time(&info.reg_date);
                        substitute_passwd(PASSFILE, &info, YEA, locid);
                        break;
                }
        }

	return ret;
}

int	getnewuserid()
{
	int	locid;

	if ((locid = new_locate()) <= 0)
	{
		prints(NA, "%s", REGISTER_SEARCH);
		del_unused();
		locid = new_locate();
	}
	return locid;
}

#ifdef LOGINASNEW
int	register_new(from)
char	*from;
{
	char	passbuf[PASSLEN],
		account[STRLEN];
	int	allocid,
		regist,
		err = 0;
	userec	new;
	ucrc	crcidx;

	(void)memset((char *)&new, 0, sizeof(new));
	allocid = getnewuserid();

	if (allocid >= MAXUSERS || allocid <= 0)
	{
		more(NEWFULL, YEA);
		exit(1);
	}
	more(NEWUSER, NA);

	while (regist = i_userid(0, new.userid))
	{
		if (regist > 0)
		{
			prints(NA, "�b���w�Q�ӽШϥ�\n");
			continue;
		}
		if (regist < 0)
		{
			if (regist == -2)
				err = 4;
			if (regist == -1)
				prints(NA, "���ŦX�ӽбb���W�w\n");
			if (++err < 3)
				continue;
			(void)memset((char *)&new, 0, sizeof(new));
			substitute_passwd(PASSFILE, &new, YEA, allocid);
			(void)printf("Register Aborted!!\n");
			reset_tty();
			exit(1);
		}
		break;
	}
	i_passwd(0, 1, &new, (char *)from);
	i_username(0, 1, new.username);
	i_email(0, 1, new.email);
#ifdef REALINFO
	i_realname(0, 1, new.realname);
	i_address(0, 1, new.address);  
#endif
	new.userset = SET_DEFAULT;
	(void)time(&new.lastlogin);
	new.reg_date = new.mod_email = new.lastlogin;
	crcidx.level = new.userlevel = PERM_DEFAULT;
	new.protocol = 0;
	i_terminal(0, 1, &new);
	(void)strcpy(account, new.userid);
	crcidx.crcnum = GetStrCrc(account);
	crcidx.checksum = new.checksum = GetStrCrc(account) + new.reg_date;
	resolve_ucache(1);

	if (substitute_passwd(PASSFILE, &new, YEA, allocid))
	{
		(void)fprintf(stderr,"too much, good bye!\n");
		exit(1);
	}
	(void)memcpy((char *)&cuser, (char *)&new, sizeof(userec));
	
	if (allocid != getuser(new.userid))
	{
		(void)fprintf(stderr,"User failed to create\n");
		exit(1);
	}
	(void)sprintf(passbuf, PATH_USER, new.userid);

	if (mkdir(passbuf, 0700) == -1)
	{
		(void)memset((char *)&new, 0, sizeof(new));
		substitute_passwd(PASSFILE, &new, YEA, allocid);
		(void)fprintf(stderr, ERR_REG_NOSPACE, ADMIN);
		sleep(5);
		exit(0);
	}
#ifdef	IDENTIFY_EMAIL
	logit(LOG_NEWUSER, "register: %s %s %d", new.userid,
		new.email, new.checksum);
#endif
	return allocid;
}
#endif

void	talk_request(signo)
int	signo;
{
	extern	char	page_requestor[];

/*	if (signo != SIGUSR1)	return;		*/
        talkrequest = YEA;

	if (!isalpha(page_requestor[0]))
		setpagerequest();
        bell(15);
}

void	msg_request(signo)
int	signo;
{
	extern	char	page_requestor[];

/*	if (signo != SIGUSR2)	return;		*/
	if (!isalpha(page_requestor[0]))
		setpagerequest();
	bell(5);
	readmessage();
}

void	bbs_system_init(getin)
int	getin;
{
	char	genbuf[STRLEN];
	int	users;

#ifndef lint
	signal(SIGHUP, (void *)abort_bbs);
	signal(SIGINT, SIG_IGN);
	signal(SIGQUIT, SIG_IGN);
	signal(SIGPIPE, SIG_IGN);

#ifdef DOTIMEOUT
	init_alarm(NA);
#else
	signal(SIGALRM,SIG_IGN);
#endif
	signal(SIGTERM, SIG_IGN);
	signal(SIGURG, SIG_IGN);
	signal(SIGTSTP, SIG_IGN);
	signal(SIGTTIN, SIG_IGN);
	signal(SIGTTOU, SIG_IGN);
	signal(SIGUSR1, (void *)talk_request);
	signal(SIGUSR2, (void *)msg_request);
#endif
	users = num_active_users('\0', 0);
	(void)printf("�ثe���W�H�� [%d/%d]\n", users, MAXACTIVE);
	if (!getin && users >= MAXACTIVE)
	{
		if ((ufp = fopen("boot.off","r")) == NULL)
		{
			(void)fprintf(stderr,"\n%s\n%s\n",
				"Sorry, BBS system is full.(�ثe�t�κ���)",
				"Call again later.(�еy�ԦA���J)");
		}
		else
		{
			while (fgets(genbuf,256,ufp) != NULL)
				(void)fprintf(stderr,"%s",genbuf);
		}
		exit(-1);
	}
}

void	u_exit()
{
	uinfo.active = NA;
	uinfo.pid = 0;
	uinfo.invisible = YEA;
	uinfo.sockactive = NA;
	uinfo.sockaddr = 0;
	uinfo.destuid = 0;
	update_utmp();
}

int	multi_user_check()
{
	usinfo	uin;
	int	ans;
	char	genbuf[STRLEN];
	
	if (!strcasecmp(GUEST, cuser.userid))
		return 0;

	if (!search_ulist(&uin, cmpuids2, usernum))
		return 0;

	if (!uin.active || (kill(uin.pid, 0) == -1))
		return 0;

	prints(YEA, "\n%s �z�n\n", cuser.userid);
#ifndef ALLOW_MULTI_LOGINS
	if (!HAS_PERM(PERM_MULTILOG))
		prints(NA, "���������\\�P�@�ӱb���P�ɦh���n��\n");
#endif
	(void)sprintf(genbuf, "�z�w�g�P�ɵn���h��, �O�_�n�N��L�n���R��(Y/N): [N] ");
	ans = getans(2, 0, genbuf, 'n');

	if (ans == 'y')
	{
		uinfo.pid = getpid();
		page_multi_select(cuser.userid, multi_kick_cmd);
	}
#ifndef ALLOW_MULTI_LOGINS
	else
	{
		if (!HAS_PERM(PERM_MULTILOG))
			goodbye();
	}
#endif
	return 0;
}

int	kickall(unum, uin)
int	unum;
usinfo	*uin;
{
	if ((uin->uid == unum) && (uin->pid != uinfo.pid) && uin->pid &&
		(kill(uin->pid, 0) != -1))
	{
		(void)kill(uin->pid, SIGHUP);  
		logit(PATH_USIES, "KICK %-10s %-20s", uin->userid,
			uin->username);
	}
	return 0;
}

int	account_disabled(userid)
char	*userid;
{
	FILE	*fp;
	char	buf[STRLEN];
	int	blen;

	if ((fp = fopen(".disabled", "r")) == NULL)
		return 0;
	while (fgets(buf, STRLEN, fp) != NULL)
	{
		blen = strlen(buf);
		if (buf[blen-1] == '\n')
			buf[--blen] = '\0';
		if (!strncmpi(buf, userid, blen))
		{
			(void)fclose(fp);
			return 1;
		}
	}
	(void)fclose(fp);

	return 0;
}

void	myname()
{
	int	fd,
		cc;
	char	*t;

	if ((fd = open(NAMEFILE,O_RDONLY)) > 0)
	{
		cc = read(fd, BoardName, STRLEN);

		BoardName[cc] = '\0';

		if (t = strchr(BoardName,'\n'))
			*t = '\0';
		(void)close(fd);
	}
	else
		(void)strcpy(BoardName, BOARDNAME);
}

void	logattempt(uid, frm, badid)
char	*uid,
	*frm;
int	badid;
{
	char	buf[BADLOGINSTRSZ+1];
	char	genbuf[STRLEN];
	char	*timestr;
	time_t	t;

	(void)time(&t);
	timestr = (char *)Ctime(&t);
	uid[12] = '\0';
	(void)sprintf(buf, "%-12s %-32s %-16s %c	       \n", uid, timestr,
		frm, badid? 'Y' : 'N');
	(void)sprintf(genbuf, BADLOGINFILE, cuser.userid);
	append_record(genbuf, buf, BADLOGINSTRSZ);

	return;
}

int	login(from)
char	*from;
{
	int	err = 0,
		newuser = 0;
	char	uid[IDLEN+1];

	for (;;)
	{
		prints(NA, "\n�w��Y�{%s\n", BOARDNAME);
#ifdef LOGINASNEW
		prints(NA, "���[�b��: %s ,��J new �ӽбb��\n\n", GUEST);
#else
		prints(NA, "���[�b��: %s\n\n", GUEST);
#endif
		usernum = i_userid(0, uid);

		if (usernum == -2)
		{
#ifdef LOGINASNEW
			usernum = register_new(from);
			newuser = YEA;
			break;
#else
			prints(NA, "%s\n%s\n",
				"���������ѽu�W���U!",
				"�ӽбM�u: u8121142@ccunix.ccu.edu.tw");
			oflush();
			err++;
			continue;
#endif
		}
		if (usernum <= 0)
		{
			if (++err >= 3)
			{
				prints(NA, "Login Aborted!!\n");
				oflush();
				reset_tty();
				exit(0);
			}
			continue;
		}

		(void)memcpy((char *)&cuser, (char *)&muser, sizeof(userec));
		if (!strcasecmp(cuser.userid, GUEST))
		{
			logattempt(cuser.userid, from, YEA);
			break;
		}
		if (i_passwd(0, 0, &cuser, NULL))
		{
			logattempt(cuser.userid, from, NA);
			if (++err > 3)
			{
				more(PATH_LOGINERR, YEA);
				exit(1);
			}
			continue;
		}
		break;
	}
	logattempt(cuser.userid, from, YEA);
	return newuser;
}

void	showattempts(really)
int	really;
{
	int	fd,
		ln = 1;
	char	buf[BADLOGINSTRSZ];
	char	genbuf[STRLEN];

	(void)sprintf(genbuf, BADLOGINFILE, cuser.userid);
	if ((fd = open(genbuf, O_RDWR)) == -1)
		return;

	if (really)
		clear();

	while (read(fd, buf, BADLOGINSTRSZ) == BADLOGINSTRSZ)
	{
		if (!strncmp(buf, cuser.userid,
			strlen(cuser.userid)) && buf[63] == 'N')
		{
			buf[63] = 'Y';
			(void)flock(fd, LOCK_EX);
			if (lseek(fd, -BADLOGINSTRSZ, SEEK_CUR) != -1)
				(void)write(fd, buf, BADLOGINSTRSZ);
			(void)flock(fd, LOCK_UN);
			if (really)
			{
				buf[45] = buf[62] = '\0';
				if (ln >= t_lines)
				{
					prints(YEA, "-- More --\n");
					igetch();
					clear();
					ln = 1;
				}
				prints(NA, "�� %.24s �� [1;36m%s[m �������\\�W���O��\n",
					&buf[13], &buf[46]);
				ln++;
			}
		}
	}
	(void)close(fd);
	if (really)
	{
		pressreturn();
		clear();
	}
}

int	checknew(filename, readtime)
char	*filename;
time_t	readtime;
{
	struct	stat	st;

	if (stat(filename,&st) == -1)
 		return NA;
	if (readtime > st.st_ctime)
		return NA;
	return YEA;
}

int	egetch()
{
	int	rval;

	while (1)
	{
		if (talkrequest)
		{
			talkreply();
			refscreen = YEA;
			return -1;
		}
		if (msgrequest)
		{
			showmessage();
			refscreen = YEA;
			return	-2;
		}
		rval = igetkey();
		if (rval != CTRL('L'))
			break;
		redodsk();
	}
	refscreen = NA;

	return rval;
}

void	finish_login(nu, from, user)
char	*from, *user;
{
	int	numbad,
		ans;
	char	genbuf[STRLEN];

	if (account_disabled(cuser.userid))
	{
		prints(NA, "%s\n%s %s %s %s\n", "���b���w�Q�޲z������.",
			"�Х�", GUEST, "�b���q��", ADMIN);
		oflush();
		reset_tty();
		exit(1);
	}

	u_enter(from);
#ifdef SYSOP_LEVEL
	if (!strcasecmp(cuser.userid, ADMIN))
		cuser.userlevel = ~0;
#endif
#ifdef GUEST
	if (!strcasecmp(cuser.userid, GUEST))
		cuser.userlevel = PERM_GUEST;
#endif
	if ((dumb_term = term_init(cuser.termtype)) == -1)
	{
		prints(NA, "�L�k�]�w�׺ݾ�, �۰���� vt100 ��\n");
		dumb_term = term_init("vt100");
	}
	logit(PATH_USIES, "ENTER %-10s %-20s %-12s@%-16s", cuser.userid,
		cuser.username, user, from);
	if (nu)
		changemode(NEW);

       	started = 1;
       	initdsk();
       	scrint = 1;
	(void)multi_user_check();
       	clear();
       	move(0,0);

#ifdef	IDENTIFY_EMAIL
	if (!HAS_PERM(PERM_TRUE)) 
		more(REGINFO, YEA);
	else
#endif
	show_welcome();
	more(MOTD, YEA);
	if (HAS_SET(SET_DISNOTE))
	{
		if (checknew(BBSNEWS, lastlogin) == YEA)
			more(BBSNEWS, NA);
	}
	else
	{
		if (checknew(BBSNEWS, lastlogin) == YEA)
			more(BBSNEWS, YEA);
		more(NOTE, NA);
	}
	move(t_lines-1, 0);
	clrtoeol();
	prints(YEA, "[1;36;44m[�W���n���a�I] %-24.24s [�W���n���ɶ�] %-24.24s[m",
		lasthost, ctime(&lastlogin));
       	if ((numbad = countattempts()) <= 0)
	{
		if (numbad < 0)
			showattempts(NA);
		(void)egetch();
	}
	else
	{
		refresh();
		(void)sprintf(genbuf, "[�`�N] �O�_��\\ %2.2d �������\\�� %-48s",
			numbad, "Login �O�� (Y/N)? [Y]: ");
		ans = getans(t_lines-2, 0, genbuf, 'y');

		if (ans == 'n')
			showattempts(NA);
		else
			showattempts(YEA);
	}
	(void)sprintf(genbuf, BADLOGINFILE, cuser.userid);
	(void)unlink(genbuf);
	(void)chkbackup();
}

int	init_perm(argc, from, argv)
int	argc;
char    **from;
char	**argv;
{
	if (argc == 3)
	    if (*argv[1] == 'h')
	    {
		*from = argv[2];
		return 1;
	    }

	return 0;
}

char	*boardmargin()
{
	static	char	buf[STRLEN];
	int	fp;

	if (selboard)
		(void)sprintf(buf,"�ثe�Q�װ�: %s",currboard);
	else if (cuser.defboard)
		(void)strcpy(currboard, cuser.defboard);

	if (!getbnum(currboard))
	{
		if ((fp = open(DEFBOARDFILE, O_RDONLY)) > 0)
		{
			char	*t;
			int	cc = read (fp, currboard, STRLEN);

			currboard[cc] = '\0';
			if (t = strchr(currboard,'\n'))
				*t = '\0';
			(void)close(fp);
		 }
		else
			(void)strcpy(currboard, DEFAULTBOARD);
	}

	if (getbnum(currboard))
	{
		selboard = 1;
		(void)sprintf(buf,"�ثe�Q�װ�: %s",currboard);
	}
	else
		(void)sprintf(buf,"�ثe����w�Q�װ�");

	return buf;
}

void	menu_draw(cmdtitle, marginnote)
char	*cmdtitle,
	*(*marginnote)();
{
	char	buf[STRLEN];
	int	a,
		b,
		c;

	c = chkmails(cuser, NA);
	(void)strcpy(buf, c ? "[1;5;37;44m[�s�H���F][m[1;33;44m" :
		BoardName);

/* - 25 �� 25 �O����X���r���� Seiya */
	a = strlen(buf) - (c ? 25 : 0);
	b = (80 - a) / 2 - 1;
	c = 79 - a - b;
	move(0, 0);
	clrtoeol();
	prints(YEA, "[1;33;44m%-*s%*s%*s[m\n", b, cmdtitle, a, buf, c, (marginnote)());
}

int	search_cmd(total, cmdtab, cmd, currcmd)
int	total,
	cmd,
	*currcmd;
cmds	*cmdtab;
{
	int	i;

	for (i=1; i<=total; i++)
	{
		if ((*(cmdtab[i].cmdname) & ~0x20) == (cmd & ~0x20))
		{
			if ((cmdtab[i].cmdname == NULL) || ((*currcmd == i) &&
				!refscreen) || (!HAS_PERM(cmdtab[i].level)))
				bell(1);
			else
			{
				*currcmd = i;
				break;
			}
		}
	}
}

int	docmd(cmdtitle, cmdprompt, firstcmd, cmdtab, marginnote)
char	*cmdtitle,	*cmdprompt,	*(*marginnote)();
int	firstcmd;
cmds	*cmdtab;
{
	int	lastcmd,	currcmd,	total,
		promptlen,	err,		line = 4,
		cmd,		i = 0,		j,
		plus,		start,		end;

	refscreen = YEA;
	promptlen = strlen(cmdprompt);
	currcmd = cmd = firstcmd;

	if (cmdtab[0].level == 0)
		for(i=1; cmdtab[i].cmdname != NULL; i++, cmdtab[0].level++);

	total = cmdtab[0].level;
	if (!HAS_SET(SET_AUTOHELP))
	{
		move(2,0);
		clrtobot();
	}

	do
	{
		move(2,0);
		clrtoeol();
		switch(cmd)
		{
			case CTRL('T'):
			if (HAS_SET(SET_AUTOHELP))
			{
				move(2,0);
				prints(NA, "Auto Help Status Turn OFF �۰���ܨ�U����\n");
				cuser.userset &= (~(1 << 0));
				move(line, 0);
				prints(NA, "  ");
			}
			else
			{
				move(2,0);
				prints(NA, "Auto Help Status Turn ON �۰���ܨ�U�}��\n");
				cuser.userset |= (1 << 0);
				refscreen = YEA;
				line = 4;
			}
       	   		break;

			case CTRL('A'):
				SWITCH_SET(SET_ALLPAGER);
				uinfo.allpager = !HAS_SET(SET_ALLPAGER);
				refscreen = YEA;
				break;
				
			case CTRL('P'):
				SWITCH_SET(SET_PAGER);
				uinfo.pager = !HAS_SET(SET_PAGER);
				refscreen = YEA;
				break;

			case CTRL('V'):
				move(2, 0);
				clrtoeol();
				prints(NA, "�����ŧi: %s", VERSION_ID);
				break;

	   		case KEY_UP:
			case KEY_HOME:
			case KEY_PGUP:
	   		case KEY_DOWN: 
			case KEY_END: 
			case KEY_PGDN:
			switch(cmd)
			{
				case KEY_UP:
					plus = -1;
					start = currcmd + total -1;
					end = currcmd;
					break;
				case KEY_DOWN:
					plus = 1;
					start = currcmd+1;
					end = currcmd +total;
					break;
				case KEY_HOME:
				case KEY_PGUP:
					plus = 1;
					start = 1;
					end = total;
					break;
				case KEY_END:
				case KEY_PGDN:
					plus = -1;
					start = total;
					end = 1;
					break;
			}
			for(j = start; j != end; j += plus)
			{
				if (HAS_PERM(cmdtab[i = (i = j%total) == 0 ?
					total : i].level))
				{
					currcmd = i;
					break;
				}
			}
			break;

	   		case KEY_LEFT:
				if (uinfo.mode == MMENU)
					cmd = 'g';
				else
					cmd = 'e';
				search_cmd(total, cmdtab, cmd, &currcmd);
				cmd = '\n';
	   		case '\n':
	   		case '\r':
	   		case KEY_RIGHT:
	   			if ((err = (*cmdtab[currcmd].cmdfunc)()) ==
					QUIT)
					return;
				if (err)
		  			cmd = *(cmdtab[currcmd].errcmd);
				else
		  			cmd = *(cmdtab[currcmd].nextcmd);
				refscreen = YEA;

	   		default:
				search_cmd(total, cmdtab, cmd, &currcmd);
				break;
		}
		if (refscreen)
		{
			menu_draw(cmdtitle, marginnote);
			move(1, 0);
			prints(NA, "%s", cmdprompt);
		}
		if (dumb_term)
		{
			if (refscreen)
			{
				refscreen = NA;
				prints(NA, "%s", cmdtab[currcmd].cmdname);
				lastcmd = currcmd;
				continue;
			}
			if (lastcmd == currcmd)
				continue;
			backspace(strlen(cmdtab[lastcmd].cmdname));
			prints(NA, "%s", cmdtab[currcmd].cmdname);
			lastcmd = currcmd;
		}
		else
		{
			if (HAS_SET(SET_AUTOHELP))
			{
				if (refscreen)
					cmds_help(cmdtab);
				move(line, 0);
				prints(NA, "  ");
				for(i=1, line=4; i<=total; i++)
				{
					if (HAS_PERM(cmdtab[i].level))
					{
						if (i == currcmd)
							break;
						else
							line++;
					}
				}
				move(line,0);
				prints(NA, "=>");
			}
			refscreen = NA;
			move(1, promptlen);
			clrtoeol();
			prints(YEA, "%s", cmdtab[currcmd].cmdname);
		}
    	}
	while (((cmd = egetch()) != EOF) || refscreen);

	abort_bbs();
}

int	main(argc, argv)
int	argc;
char	**argv;
{
	char	fromhost[20];
        char    remotusr[20];
	char	*from;
	int	cmd,
		getin,
		nu,
		keep,
		max_mail_num;
	time_t	ti;
        struct	stat	mst;
        char	currmaildir[100];

	reading = NA;
#ifdef SINGLE
	char	c[256];

	gethostname(c,256);
	if (strcmp(c,SINGLE))
	{
		(void)printf("Not on a valid machine! (�ϥΪ̨ӷ�����)\n");
		exit(-1);
	}
#endif
        if ((from = getenv("REMOTEUSER")) != NULL)
                strncpy(remotusr, from, 20);
        else
                strcpy(remotusr, "<unknown>");
	if ((getin = init_perm(argc, &from, argv)) == 1)
		strncpy(fromhost, from, 16);
	else if ((from = getenv("REMOTEHOST")) != NULL)
		strncpy(fromhost, from, 16);
	else
		strncpy(fromhost, MYIPADDR, 16);

#ifdef	COLOR_ISSUE
	cuser.userset |= SET_ANSIMODE;
#endif
	more(ISSUE, NA);

	bbs_system_init(getin);
	if (setjmp(byebye))
	{
		if (started)
		{
			if ((ufp = fopen("usies","a")) != NULL)
			{
				(void)time(&ti);
				(void)fprintf(ufp, "ABORT %-10s %-20s %s",
					cuser.userid,
					cuser.username,
					ctime(&ti));
				(void)fflush(ufp);
				u_exit();
				(void)fclose(ufp);
		  	}
		}
		(void)printf("goodbye\n");
		exit(0);
	}
	get_tty();
	init_tty();
	myname();

	nu = login(fromhost);
	finish_login(nu, fromhost, remotusr);

	m_init(cuser);
	resolve_boards();
	init_access();

#ifdef SYSV
	if (get_semaphore() == -1)
	{
		(void)printf("Can't get semaphore! Exiting...\n");
		exit(1);
	}
#endif
        changemode(MMENU);

        if (HAS_PERM(PERM_LOCALBM))
                max_mail_num = MAXBMKEEPMAIL;
        else
                max_mail_num = MAXKEEPMAIL;

        if (HAS_PERM(PERM_BBSSYSOP))
                max_mail_num = 32000;
        
        (void)sprintf(currmaildir, PATH_MAIL, cuser.userid, FHDIR);

        if (stat(currmaildir, &mst) != -1 &&
		(keep = mst.st_size / sizeof(fhd)) > max_mail_num)
	{
		prints(NA, "keep %d, maxmail %d\n", keep, max_mail_num);
		igetkey();
                changemode(MAIL);
                cmd = 'e';
		docmd("[�H��B�z]", "�H��B�z���O: ", cmd, maillist,
			boardmargin);
        }
        cmd = (chkmails(cuser,NA)) ?  'm' :
		(nu || !HAS_PERM(PERM_BASIC)) ? 'h' : 'd';

        changemode(MMENU);
	reading = YEA;
	docmd("[�D�ؿ�]","�ާ@����: ",cmd, cmdlist, boardmargin);
	return 0;
}

int	m_adduser()
{
	int	ans,
		allocid,	
		saveunum,
		line = 1;
	userec	newuser,
		saveuser;
	char	myhome[STRLEN];
		
	clear();
	(void)memcpy((char *)&saveuser, (char *)&cuser, sizeof(saveuser));
	(void)memset((char *)&newuser, 0, sizeof(newuser));
	saveunum = usernum;
	allocid = getnewuserid();
	if (allocid >= MAXUSERS || allocid <= 0)
	{
		prints(NA, "No space for new users on the system!\n");
			sleep(1);
			return 0;
	}
	prints(YEA, "Add New User");
	clrtoeol();

	newuser.userlevel = PERM_DEFAULT;
	if (i_userid(line++, newuser.userid))
		return 0;
	i_passwd(line++, 1, &newuser, NULL);
	i_username(line++, 1, newuser.username);
	i_email(line++, 1, newuser.email);
#ifdef REALINFO
	i_realname(line++, 1, newuser.realname);
	i_address(line++, 1, newuser.address);
#endif
	i_terminal(line++, 1, &newuser);
	newuser.userlevel = PERM_DEFAULT;
	(void)memcpy((char *)&cuser, (char *)&saveuser, sizeof(cuser));
	usernum = saveunum;
	ans = getans(++line,0,"Add this account (Y/N)? [Y]: ",'y');

	if (ans == 'n')
	{
		newuser.userid[0] = '\0';
		substitute_passwd(PASSFILE, &newuser, YEA, allocid);
		prints(NA, "New account NOT created.\n");
		pressreturn();
		clear();
		return(0);
	}

	if (substitute_passwd(PASSFILE, &newuser, YEA, allocid) == -1)
	{
		prints(NA, "No space in password file!\n");
		pressreturn();
		clear();
		return 0;
	}
	prints(NA, "\nNew Account Created\n");
	(void)sprintf(myhome, PATH_USER, newuser.userid);
	(void)mkdir(myhome, 0700);
	resolve_ucache(1);
	pressreturn();
	clear();
	return 0;
}

int	countattempts()
{
	int	fd,
		cnt = 0;
	char	buf[BADLOGINSTRSZ];
	char	genbuf[STRLEN];

	if (!HAS_PERM(PERM_BASIC))
		return -1;    /* don't show the bad login attempts */
	(void)sprintf(genbuf, BADLOGINFILE, cuser.userid);
	if ((fd = open(genbuf, O_RDONLY)) == -1)
		return 0;
	while (read(fd, buf, BADLOGINSTRSZ) == BADLOGINSTRSZ)
	{
		if (!strncmp(buf, cuser.userid,
			strlen(cuser.userid)) && buf[63] == 'N')
		{
			cnt++;
		}
	}
	(void)close(fd);

	return cnt;
}

