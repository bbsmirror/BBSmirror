#! /bin/csh
#
# installation script for Pirate BBS.
# with enhancements for Eagles BBS.
#
# just in case something goes wrong, make a backup of the passwd file
#

cp /etc/passwd passwd.backup

set bbshome = `./passwdent bbs homedir`

if ( $bbshome == "" ) then
    set bbshome = /a/r/g/v
    echo ERROR: CHECK PASSWD ENTRY, is it bbs\?
    exit -1
endif

# Make all the directories required
echo making directories
mkdir ~bbs
mkdir ~bbs/bin
mkdir ~bbs/lib
mkdir ~bbs/ftp
mkdir ~bbs/ftp/files
mkdir ~bbs/ftp/files/source
mkdir ~bbs/etc
mkdir ~bbs/etc/logout
mkdir ~bbs/boards
mkdir ~bbs/dev
mkdir ~bbs/tmp
mkdir ~bbs/usr
mkdir ~bbs/usr/lib
mkdir ~bbs/vote
mkdir ~bbs/home
mkdir ~bbs/reclog
mkdir ~bbs/Announce
mkdir ~bbs/proxy

# Copy Welcome and copyright notices to home directory
echo Copying Welcome message and copyright notices

cd ./INFO
cp Welcome motd issue newuser ~bbs/etc
cd ..
chown -R bbs ~bbs/etc

# Make zero device in dev
if ( -e /dev/zero ) then
	echo Making device zero
	mknod ~bbs/dev/zero c 3 12
endif
# Make null device for IRC
if ( -e /dev/null ) then
	echo Making null device
	mknod ~bbs/dev/null c 3 2
endif

# Set Up etc directory
echo setting up etc directory
cp /etc/termcap ~bbs/etc
cp /etc/group ~bbs/etc
cp /etc/hosts ~bbs/etc
# Uncomment this only if your machine uses DNS in lieu of NIS
#cp /etc/resolv.conf ~bbs/etc
echo "root:*:0:1:Operator:/:/bin/csh" > ~bbs/etc/passwd
echo -n "bbs:*:" >> ~bbs/etc/passwd
echo -n `./passwdent bbs uid`: >> ~bbs/etc/passwd
echo -n `./passwdent bbs gid`: >> ~bbs/etc/passwd
echo "Bulletin Board Software:/:/bin/bbs" >> ~bbs/etc/passwd
chmod a-w ~bbs/etc/passwd
chmod a-w ~bbs/etc/group
chmod a-w ~bbs/etc/termcap

# set up usr directory
# this includes timezone stuff and shared library stuff
echo setting up usr directory
if ( -e /usr/share/lib/zoneinfo ) then
 echo Copying zoneinfo stuff
 mkdir ~bbs/usr/share
 mkdir ~bbs/usr/share/lib
 (cd  /usr/share/lib;tar cf - zoneinfo) | (cd ~bbs/usr/share/lib; tar xf -)
endif
# The following lines are supposed to copy the necessary files for shared
# libraries on Sun Systems
if ( -f /usr/lib/ld.so ) then
	echo installing shared libraries
	cp /usr/lib/ld.so ~bbs/usr/lib
	cp /usr/lib/libc.so.* ~bbs/usr/lib
	if( -f /usr/lib/libdl.so.1.0 ) then
		cp /usr/lib/libdl.so.1.0 ~bbs/usr/lib
	endif
endif

# set up the bin directory
echo setting up binaries
echo
echo "NOTE: These are the bare minimum utilities to run the bbs. You may want"
echo "to copy more into the bbs' restricted directory tree. "

cp bbs ~bbs/bin
cp bbsrf ~bbs/bin
cp bbs.chatd ~bbs/bin
# The chroot app runs setuid.
chmod 6755 ~bbs/bin/bbsrf
chown root ~bbs/bin/bbsrf
cp /bin/sh ~bbs/bin
cp /bin/csh ~bbs/bin
cp /bin/mv ~bbs/bin
cp /bin/ls ~bbs/bin
cp /bin/rm ~bbs/bin
cp /bin/stty ~bbs/bin
cp /bin/mkdir ~bbs/bin
cp /bin/cp ~bbs/bin
cp /bin/touch ~bbs/bin
if( -d /usr/ucb ) then
	cp /usr/ucb/vi ~bbs/bin
	cp /usr/ucb/reset ~bbs/bin
	cp /usr/ucb/more ~bbs/bin
endif

# set up home directory and ownerships
echo Setting ownerships and permissions
echo  > ~bbs/.hushlogin
cp INFO/dotcshrc ~bbs/.cshrc
cp INFO/dotlogin ~bbs/.login
chown bbs ~bbs
chown bbs ~bbs/.hushlogin
chown bbs ~bbs/.cshrc
chown bbs ~bbs/.login
chown -R bbs ~bbs/boards
chown -R bbs ~bbs/ftp
chown -R bbs ~bbs/tmp
chown -R bbs ~bbs/vote
chown -R bbs ~bbs/bin
chown -R bbs ~bbs/lib
chown -R bbs ~bbs/usr
chown -R bbs ~bbs/home
chown -R bbs ~bbs/reclog
chown -R bbs ~bbs/Announce
chown -R bbs ~bbs/etc/logout

chmod 770 ~bbs

echo "Done."

echo "If file upload/download is enabled:"
echo "-- compile protocols and install in ~bbs/bin"
