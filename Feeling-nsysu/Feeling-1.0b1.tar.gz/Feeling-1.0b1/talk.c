/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw
			   ���崼, Alen@Akira.dorm.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    SccsId[] = "%W%	%G%";
#endif

#include "bbs.h"

extern	userec	cuser,
		muser;
extern	usinfo	uinfo;
extern	int	usernum,
		talkrequest,
		t_lines,
		t_columns,
		dumb_term;
extern	char	BoardName[],
		*msgrequest;
extern	UTCACHE	*utmpshm;
extern	one_key	multi_talk_cmd[],
		multi_send_cmd[],
		multi_kick_cmd[];

extern	int	cmpuids();
extern	void	update_utmp(),
		prints(),
		printchatline(),
		init_alarm();

usinfo	ui;
char	page_requestor[STRLEN],
	talkwith[STRLEN],
	talkobuf[STRLEN];
int	talkobuflen,
	talkflushfd,
	idle_monitor_time,
	page = 1,
	maxpage;

char	*ModeType[] =
{
	"�o�b",		"���i�ƶ�",	"�����ؿ�",	"�D���",
	"�Q�װ�",	"��Ϳ��",	"�u��c",	"�ǰe�ɮ�",
	"�D�����",	"�H����",	"�W���~��",	"���ͦW��",
	"�s�ӽФ�",	"�p��G�i",	"FAQ",		"Ū�s���",
	"�g",		"Ū",		"��Q�װ�",	"�d�Q�װ�",
	"�Ь�Ū�L",	"�ӽЪ���",	"��\\�Q�׸s",	"�Q�׸s�s��",
	"�ɮצC��",	"�]�ǻ��k",	"���ɮװ�",	"�ݤ�r��",
	"�ǻ��ɮ�",	"Ū���H��",	"�g�H",		"Ū�s�H��",
	"�޲z�H��",	"BM",		"C1",		"C2",
	"�ѤW�ȩ~",	"��B��",	"²�C�W��",	"���W�W��",
	"�l�ܯ���",	"�l�ܪB��",	"�I",		"�d",
	"��",		"�ƻs�_��",	"�s������",	"�sñ�W��",
	"�i���e��",	"�벼��",	"�����",	"�s������",
	"��������",	"�إ߷s��",	"�����͸��",	"����ϩw�q",
	"��i�O��",	"�H�^���",	"�ǰe�T��",

	"�~���{��",	/* �H�U���~���{�����w�q */

	"Four M",	"Gopher",	"IRC Chat",	"�ϮѬd��",
	"Ū news",	"TRC Chat",	"�d�]�t��",	"�W���ɮ�",
	"�^���ɮ�",	"�i�J�֤�",

	"���w�q",	/* �W�L�d��F           */
};

void	show_plan(flag, whopage, output)
int	flag;
char	*whopage;
void	(*output)();
{
	FILE	*planfile;
	char	genbuf[STRLEN],
		inbuf[256],
		*newline,
		*msg;
	int	i;
	usinfo	uin;

	if (flag)
	{
		move(1, 0);
		clrtobot();
	}
	i = search_record(PASSFILE, (char *)&muser, sizeof(muser), cmpuids,
		(int)whopage);

	(*output)(NA, "%s (%.20s), %d logins, %d posts.", muser.userid,
#ifdef  REALINFO
		((muser.userset >> 3) & 1) ? muser.realname :
#endif
		muser.username, muser.numlogins,
		muser.numposts);
#ifdef QUERY_EMAIL
	(*output)(NA, "(%d) %s\n", i, chkmails(muser, YEA) ? "���s�H��Ū!" :
		"�S������s�H��.");
	chkmails(cuser, YEA);
#endif
	strcpy(genbuf, ctime(&(muser.lastlogin)));

	if (newline = (char *)strchr(genbuf, '\n'))
		*newline = '\0';

	msg = "�ثe�b���W";
	if (!search_ulist(&uin, cmpuids, (int)muser.userid) || 
		(uin.invisible && !HAS_PERM(PERM_SEECLOAK)))
			msg = "�|���W��";

	(*output)(NA, "Last login %s from %s [%s]\n", genbuf,
		(muser.lasthost[0] == '\0' ? "(unknown)" :
		muser.lasthost), msg);


	if (HAS_PERM(PERM_BASIC))
	sprintf(genbuf, PATH_PLAN, muser.userid);

	if ((planfile = fopen(genbuf, "r")) == NULL)
		(*output)(NA, "No plan.\n");
	else
	{
		(*output)(NA, "Plan:\n\n");

		for (i = 1; i <= MAXQUERYLINES; i++) 
		{
			if (fgets(inbuf, sizeof(inbuf), planfile))
		    		(*output)(NA, "%s", inbuf);
			else 
				break;
	    	}
	    	fclose(planfile);
	}
}

int	t_cmpuids(uid, up)
int	uid;
usinfo	*up;
{
	return (uid == up->uid);
}

int	ishidden(user)
char	*user;
{
	int	tuid;
	char	gb[BUFSIZE];
	userec	saverec;
	usinfo	uin;

	memcpy(&saverec, gb, sizeof(saverec));
	if (!(tuid = getuser(user)))
		return 0;
	(void)search_ulist(&uin, t_cmpuids, tuid);
        memcpy(gb, &saverec, sizeof(saverec));
	return(uin.invisible);
}	

char	*modestring(mode, chatid)
int	mode;
char	*chatid;
{
	static	char	modestr[STRLEN];

	if (chatid && *chatid)
	{
		if (mode == TALK && (!HAS_PERM(PERM_SEECLOAK) &&
			ishidden(chatid)))
		{
			return (ModeType[TMENU]);
		}
		sprintf(modestr, "%s: %s", ModeType[mode], chatid);
		return(modestr);
	}
	if (mode >= OUTSIDE)
		return (ModeType[OUTSIDE]);
	return (ModeType[mode]);
}

int	listcuent(uentp)
usinfo	*uentp;
{
	if ((uentp->uid == usernum) || (!uentp->active || !uentp->pid) ||
		(uentp->mode == ULDL) || (!HAS_PERM(PERM_SEECLOAK) &&
		uentp->invisible) || (kill(uentp->pid, 0) == -1))
		return 0;
	if (talkobuf[0] == '\0' || cmp_bhd_seed(uentp->userid, talkobuf))
		AddLinkList(uentp->userid, strlen(uentp->userid));

	return 0;
}

void	creat_list(seed)
char	*seed;
{
	if (seed == NULL)
		memset(talkobuf, 0, sizeof(talkobuf));
	else
		strcpy(talkobuf, seed);
	(void)apply_ulist(listcuent);
}

int	t_pager()
{
	int	ans;
	char	askbuf[STRLEN];

	if (uinfo.pager)
		strcpy(askbuf, uinfo.allpager ? PAG_OFF_OFF : PAG_OFF_ON);
	else
		strcpy(askbuf, uinfo.allpager ? PAG_ON_OFF : PAG_ON_ON);
	ans = getans(2, 0, askbuf, uinfo.pager ? 'c' : 'o');
	if (ans == 'e')
		return -1;
	if (ans == 'a')
	{
		SWITCH_SET(SET_ALLPAGER);
		uinfo.allpager = !HAS_SET(SET_ALLPAGER);
	}
	else
	{
		SWITCH_SET(SET_PAGER);
		uinfo.pager = !HAS_SET(SET_PAGER);
	}
	move(2, 0);
	prints(NA, "�ثe Pager ���A: %s, ���u Pager ���A: %s",
		uinfo.pager ? "ON" : "OFF", uinfo.allpager ? "ON" : "OFF");
	changemode(uinfo.mode);
	return 0;
}

int	t_query()
{
	char	uident[STRLEN];
/*
	changemode(QUERY);
*/
	if (!init_namelist(uident))
		return 0;

	strncpy(uinfo.ptcb, uident, 20);
	changemode(QUERY);
/*
	clear();
*/	move(0, 0);
	prints(NA, "[�լd���ͨ����P�������]\n");
	show_plan(YEA, uident, prints);

	pressreturn();
	move(2, 0);
	clrtoeol();

	memset(uinfo.ptcb, 0, 20);
	changemode(TMENU);

	return 0;
}

int	talkflush()
{
    	if (talkobuflen) 
      		(void)write(talkflushfd, talkobuf, talkobuflen);
    	talkobuflen = 0;
}

void	talk_info(line)
int	line;
{
	int	j;
	char	pagebuf[STRLEN],
		genbuf[STRLEN];

    	move(line, 0);

    	for (j =0; j <= 78; j++)
       		prints(NA, "=");
	move(line, 0);
	prints(NA, "%s", uinfo.invisible ? "������" : "======");

	sprintf(pagebuf, "������ PAGER: %s��", uinfo.allpager ? "ON" : "OFF");
	if (talkrequest)
		sprintf(genbuf, "�i�s�����j%s �Q�M�z����", page_requestor);
	else
		sprintf(genbuf, TALK_TALKWITH, talkwith);
	strcat(pagebuf, genbuf);
	sprintf(genbuf, "���ϰ� PAGER: %s��", uinfo.pager ? "ON" : "OFF");
	strcat(pagebuf, genbuf);
	move(line, (79 - strlen(pagebuf))/2);
    	prints(NA, "%s", pagebuf);
	refresh();
}

void	do_talk_char(sline, eline, curln, curcol, wordbuf, wordbuflen, ch)
int	sline,
	eline,
	*curln,
	*curcol,
	*wordbuflen,
	ch;
char	*wordbuf;
{
	if (ISPRINT(ch))
	{
	        if (*curcol != 79) 
		{
	        	wordbuf[(*wordbuflen)++] = ch;
            		if (ch == ' ')
              			*wordbuflen = 0;
            		move(*curln, (*curcol)++);
            		prints(NA, "%c", ch);
            		return;
        	}
        	if (ch == ' ' || *wordbuflen >=78) 
		{
            		(*curln)++;
            		*curcol = 0;
            		if (*curln > eline)
            			*curln = sline;
            		if ((*curln) != eline) 
			{
                		move((*curln)+1, 0);
                		clrtoeol();
            		}
            		move(*curln, *curcol);
            		clrtoeol();
            		*wordbuflen = 0;
            		return;
        	}
        	move(*curln, (*curcol) - *wordbuflen);
        	clrtoeol();
        	(*curln)++;
        	*curcol = 0;
        	if (*curln > eline)
        		*curln = sline;
        	if ((*curln) != eline) 
		{
            		move((*curln)+1, 0);
            		clrtoeol();
        	}
        	move(*curln, *curcol);
        	clrtoeol();
        	wordbuf[*wordbuflen] = '\0';
        	if (dumb_term)
          		prints(NA, "\n");
        	prints(NA, "%s%c", wordbuf, ch);
        	*curcol = (*wordbuflen)+1;
        	*wordbuflen = 0;
        	return;
    	}
    	switch (ch) 
	{
      		case CTRL('H'):
      		case '\177':
        		if (dumb_term)
          			ochar(CTRL('H'));
        		if (*curcol == 0) 
			{
            			if (sline == 0)
              				bell(1);
            			return;
        		}
        		(*curcol)--;
        		move(*curln, *curcol);
        		if (!dumb_term)
          			prints(NA, " ");
        		move(*curln, *curcol);
        		if (*wordbuflen)
          			(*wordbuflen)--;
        		return;
      		case '\n':
      		case '\r':
        		if (dumb_term)
          			prints(NA, "\n");
        		(*curln)++;
        		*curcol = 0;
        		if (*curln > eline)
          			*curln = sline;
        		if ((*curln) != eline) 
			{
        			move((*curln)+1, 0);
        			clrtoeol();
        		}
        		move(*curln, *curcol);
        		clrtoeol();
        		*wordbuflen = 0;
        		return;
      		case CTRL('G'):
        		bell(1);
        		return;
      		default:
        		break;
    	}
    	return;
}

int	servicepage(arg)
int	arg;
{
	static	time_t	last_check;
	time_t	now;
	char	buf[STRLEN];
        int	tuid = searchuserlist(usernum);

        if (tuid == 0 || !ui.sockactive)
		talkrequest = NA;

        if (!talkrequest)
	{
        	if (page_requestor[0])
		{
			switch (uinfo.mode)
			{
	      			case BMCHAT:
				case CHAT1:
				case CHAT2: /* a chat mode */
					sprintf(buf, TALK_PAGESTOP,
						page_requestor);
                			printchatline(NA, buf);
					break;
	      			default:
					talk_info(arg);
					break;
	    		}
            		memset(page_requestor, 0, sizeof(page_requestor));
            		last_check = 0;
          	}
	  	return NA;
        }
        else 
	{
        	(void)time(&now);
        	if (now - last_check > P_INT) 
		{
            		last_check = now;
            		if (!page_requestor[0] && setpagerequest())
	      			return NA;
            		else
	      			switch (uinfo.mode)
				{
					case BMCHAT:
					case CHAT1:
					case CHAT2: /* chat */
                  				sprintf(buf, TALK_PAGING,
							page_requestor);
                  				printchatline(NA, buf);
						break;
					default:
						talk_info(arg);
		  				break;
	      			}
          	}
        }
	return YEA;
}

void	do_talk(fd)
int	fd;
{
    	int	myln,
		mycol,
		myfirstln,
		mylastln,
		itsln,
		itscol,
		itsfirstln,
		itslastln,
    		itswordbuflen,
		mywordbuflen,
    		page_pending = NA,
		savemode,
		savecomp;
    	char	itswordbuf[STRLEN],
		mywordbuf[STRLEN];
    
    	clear();
	talkrequest = itswordbuflen = mywordbuflen = talkobuflen = 0;
    	talkflushfd = fd;

	savemode = uinfo.mode;
	changemode(TALK);
    	myfirstln = 0;
    	mylastln = (t_lines-1)/2 - 1;

	talk_info(mylastln+1);

    	itsfirstln = mylastln+2;
    	itslastln = (t_lines -1);
    	myln = myfirstln;
    	mycol = 0;
    	itsln = itsfirstln;
    	itscol = 0;
    	move(myln, mycol);
    	add_io(fd, 0);
    	add_flush(talkflush);

    	for (;;)
	{
        	int	ch,
			currx,
			curry;

		if (talkrequest) 
			page_pending = YEA;
		if (page_pending)
	  		page_pending = servicepage(mylastln+1);
        	ch = igetch();

		if (ch == I_OTHERDATA) 
		{
            		char	data[STRLEN];
            		int	datac;
			int	i;

            		datac = read(fd, data, 80);
            		if (datac<=0) 
              			break;
            		for (i=0; i<datac; i++)
			{
              			do_talk_char(itsfirstln, itslastln, &itsln,
					&itscol, itswordbuf, &itswordbuflen,
					data[i]);
			}
		}
		else
		{
            		if (ch == CTRL('D') || ch == CTRL('C'))
              			break;
			if (ch == CTRL('H') || ch == '\177' || ch == CTRL('G')
				|| ISPRINT(ch) || ch == '\n' || ch == '\r')
			{
                		talkobuf[talkobuflen++] = ch;
                		if (talkobuflen == 80)
                  			talkflush();
                		do_talk_char(myfirstln, mylastln, &myln,
					&mycol, mywordbuf, &mywordbuflen, ch);
	    		}
	    		else if (ch == CTRL('U') || ch == CTRL('W'))
			{
				dotalkuserlist(myfirstln, mylastln, &myln,
		 			&mycol, mywordbuf, &mywordbuflen);
			}
            		else if (ch == CTRL('P') && HAS_PERM(PERM_BASIC))
			{
               			SWITCH_SET(SET_PAGER);
				uinfo.pager = !HAS_SET(SET_PAGER);
				changemode(uinfo.mode);
				getyx(&curry, &currx);
				talk_info(mylastln+1);
				move(curry, currx);
            		}
			else if (ch == CTRL('A'))
			{
				SWITCH_SET(SET_ALLPAGER);
				uinfo.allpager = !HAS_SET(SET_ALLPAGER);
				changemode(uinfo.mode);
				getyx(&curry, &currx);
				talk_info(mylastln+1);
				move(curry, currx);
			}	
            		else if	(ch == CTRL('X') && HAS_PERM(PERM_CLOAK))
			{
				char	buf[20];
				SWITCH_SET(SET_CLOAK);
				uinfo.invisible = HAS_SET(SET_CLOAK);
				talk_info(mylastln+1);
				changemode(uinfo.mode);
			}
			else if (ch == CTRL('Z'))	talk_info(mylastln+1);
			else
				bell(1);
		}
    	}
    	add_io(0, 0);
    	talkflush();
    	add_flush(NULL);
/*	memset(uinfo.ptcb, 0, 20);
*/	changemode(savemode);
}

int	talk_connect(tuid, uident, uin)
int	tuid;
char	*uident;
usinfo	*uin;
{
	int	sock,
		msgsock,
		length;
	struct	sockaddr_in	server;
	char	c[STRLEN+1];

	if (!HAS_PERM(PERM_SYSOP))
	{
		if (uin->allpager == NA || (uin->pager == NA &&
			!can_override(uin->userid, cuser.userid, "override")))
		{
			move(2, 0);
			prints(NA, TALK_PAGEROFF);
			return -1;
		}
	}
        if (uin->mode >= EXTERN) 
	{
		move(2, 0);
		prints(NA, TALK_CANNOTPAGE);
		return -1;
	}
	if (uin->pid == 0) 
	{
		move(2, 0);
		prints(NA, TALK_ERRORPID);
		return -1;
	}
	if (!uin->active || (kill(uin->pid, 0) == -1)) 
	{
		move(2, 0);
		prints(NA, TALK_LOGOUT);
		return -1;
        }

	sock = socket(AF_INET, SOCK_STREAM, 0);

	if (sock < 0) 
	{
		perror("opening stream socket\n");
		return -1;
	}

	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_port = 0;

	if (bind(sock, (struct sockaddr *)&server, sizeof(server)) < 0)
	{
		perror("binding stream socket");
		return -1;
	}

	length = sizeof(server);
	if (getsockname(sock, (struct sockaddr *)&server, &length) < 0)
	{
		perror("getting socket name");
		return -1;
	}

	uinfo.sockactive = YEA;
	uinfo.sockaddr = server.sin_port;
	uinfo.destuid = tuid;

	strcpy(uinfo.ptcb, uident);
	changemode(PAGE);

	(void)kill(uin->pid, SIGUSR1);
	clear();
	show_plan(YEA, uinfo.ptcb, prints);
	move(0, 0);
	prints(NA, TALK_PAGETRYING, uident);

	listen(sock, 1);
	add_io(sock, 8);

	while (YEA) 
	{
		int	ch;

#if defined(POSIX) || defined(LINUX)
		add_io(sock, 8);
#endif
		ch = igetch();
		if (ch == I_TIMEOUT) 
		{
			move(0, 0);
			clrtoeol();
			prints(NA, TALK_PAGEAGAIN);
			bell(1);

			if (kill(uin->pid, SIGUSR1) == -1) 
			{
				move(0, 0);
				prints(NA, TALK_LOGOUT);
				pressreturn();
				memset(uinfo.ptcb, 0, sizeof(uinfo.ptcb));
				changemode(TMENU);
				return -1;
			}
			continue;
		}

		if (ch == I_OTHERDATA)
                     	break;

		if (ch == '\004') 
		{
                       	add_io(0, 0);
                       	close(sock);
                       	uinfo.sockactive = NA;
                       	uinfo.destuid = 0;
			memset(uinfo.ptcb, 0, sizeof(uinfo.ptcb));
			changemode(TMENU);

                       	clear();
                       	return 0;
		}
	}

	msgsock = accept(sock, (struct sockaddr *)0, (int *) 0);
	if (msgsock == -1) 
	{
		perror("accept");
		memset(uinfo.ptcb, 0, sizeof(uinfo.ptcb));
		changemode(TMENU);
		return -1;
	}
	add_io(0, 0);
	close(sock);

	uinfo.sockactive = NA;
	read(msgsock, &c, sizeof c);

	switch (toupper(c[0])) 
	{
		case 'Y':
			strcpy(talkwith, uin->userid);
                	do_talk(msgsock);
			break;
		case 'C':
			clear();
			prints(NA,"��軡:�u%s�v\n", c+1);
			pressreturn();
			break;
		default:
                	clear();
       	        	prints(NA, TALK_PAGE_REJECT);
               		pressreturn();
			break;
	}

	close(msgsock);
	clear();
	uinfo.destuid = 0;

	memset(uinfo.ptcb, 0, sizeof(uinfo.ptcb));
	changemode(TMENU);

        return 0;
}

int	get_talk_pid(uid, tinfo)
char	*uid;
usinfo	*tinfo;
{
	static	int	total = 0;

	if (tinfo == NULL)
	{
		total = 0;
		return 0;
	}
	if (!strcasecmp(uid, tinfo->userid) && active(tinfo))
	{
		total++;
		if (total >= 2)
			return QUIT;
		else
			return 1;
	}
	return 0;
}

int	t_talk()
{
        char	uident[STRLEN];
        int	tuid,
		tpid;
        usinfo	uin;

        move(2, 0);
        prints(NA, "<Enter Userid>\n");
        move(1, 0);
        clrtoeol();
        prints(NA, "To: ");
        name_query(NULL, uident, creat_list);

        if (uident[0] == '\0') 
	{
		move(2, 0);
		clrtoeol();
                return 0;
        }
	tuid = getuser(uident);

        if (!tuid || tuid == usernum) 
	{
                move(2, 0);
                prints(NA, "Bad User ID\n");
/*		pressreturn();
                move(2, 0);
                clrtoeol();
*/		return -1;
        }
#if	defined(ALLOW_MULTI_LOGINS) || defined(PERM_MULTILOG)
	(void)get_talk_pid(NULL, NULL);
	if (get_ulist(&uin, get_talk_pid, uident) == QUIT)
	{
		page_multi_select(uident, multi_talk_cmd);
		return 0;
	}
	else
		tuid = uin.uid;
#else
        (void)search_ulist(&uin, t_cmpuids, tuid);
#endif
	return talk_connect(tuid, uident, &uin);
}

int	cmpunums(unum, up)
int	unum;
usinfo	*up;
{
	if (!up->active)
		return 0;

	return ((unum == up->destuid) && (up->mode == PAGE));
}

int	searchuserlist(unum)
{
	return search_ulist(&ui, cmpunums, unum);
}

int	setpagerequest()
{
	int	tuid;

	tuid = searchuserlist(usernum);
	if (tuid == 0 || !ui.sockactive)
		return 1;

	uinfo.destuid = ui.uid;

	strcpy(page_requestor, ui.userid);
	return 0;
}

int	talkreply()
{
	int	a;
	struct	hostent	*h;
	char	hostname[STRLEN],
		saveptcb[20],
		buf[STRLEN+1],
		ans[2];
	struct	sockaddr_in	sin;

	talkrequest = NA;
	if (setpagerequest())
		return 0; 	
	BACKUP(uinfo.ptcb, saveptcb);
	strcpy(uinfo.ptcb, page_requestor);
	strcpy(talkwith, page_requestor);
	clear();
	show_plan(YEA, page_requestor, prints);
	move(0, 0);
	sprintf(buf, TALK_IFACCEPT, page_requestor);

	do
	{
		getdata(0, 0, buf, ans, 2, DOECHO, YEA);
	}
	while (ans[0] == '\0');

	memset(page_requestor, 0, sizeof(page_requestor));
	gethostname(hostname, STRLEN);

	if (!(h = (struct hostent *)gethostbyname(hostname))) 
	{
		perror("gethostbyname");
		RESTORE(uinfo.ptcb, saveptcb);
		changemode(uinfo.mode);
		return -1;
	}

	memset(&sin, 0, sizeof(sin));
	sin.sin_family = h->h_addrtype;
	memcpy(&sin.sin_addr, h->h_addr, h->h_length);
	sin.sin_port = ui.sockaddr;
	a = socket(sin.sin_family, SOCK_STREAM, 0);
	if ((connect(a, (struct sockaddr *)&sin, sizeof sin))) 
	{
		perror("connect failed");
		RESTORE(uinfo.ptcb, saveptcb);
		changemode(uinfo.mode);
		return -1;
	}
	switch (toupper(ans[0]))
	{
		case 'N':
			buf[0] = 'N';
			break;
		case 'C':
			buf[0] = 'C';
			getdata(1, 0, "�d��: ", buf+1, STRLEN, DOECHO, YEA);
			break;
		default:
			buf[0] = 'Y';
			break;
	}
	(void)write(a, &buf, sizeof(buf));
	if (buf[0] == 'Y')
		do_talk(a);
	close(a);
	clear();
	RESTORE(uinfo.ptcb, saveptcb);
	changemode(uinfo.mode);
	return 0;
}

int	dotalkent(uentp, buf)
usinfo	*uentp;
char	*buf;
{
	char	mch;

	if (!uentp->active || !uentp->pid || (!HAS_PERM(PERM_SEECLOAK) &&
		uentp->invisible) || (kill(uentp->pid, 0) == -1))
	{
		 return -1;
	}

    	switch (uentp->mode) 
    	{
      		case ULDL:
           		mch = 'U';
			break;
      		case TALK:
           		mch = 'T';
			break;
      		case CHAT1:
		case CHAT2:
		case CHAT3:
	   		mch = 'C';
			break;
      		case BMCHAT:
           		mch = 'c';
			break;
      		case IRCCHAT:
			mch = 'I';
			break;
      		case FOURM: 
			mch = '4';
			break;
      		case BBSNET: 
			mch = 'B';
			break;
      		case READNEW: 
			mch = 'N';
			break;
      		case READING: 
			mch = 'R';
			break;
      		case POSTING: 
			mch = 'P';
			break;
      		case SMAIL: 
			mch = 's';
			break;
      		case RMAIL: 
			mch = 'r';
			break;
      		case MAIL: 
			mch = 'M';
			break;
      		default: 
			mch = '-';
    	}
    	sprintf(buf, "%s%s(%c), ", uentp->invisible?"*":"",
		uentp->userid, mch);

    	return 0;
}

/* mark */
 
void	do_talk_string(sline, eline, curln, curcol, wordbuf, wordbuflen, s)
int	sline,
	eline,
	*curln,
	*curcol,
	*wordbuflen;
char	*wordbuf,
	*s;
{
	while (*s) 
	{
		do_talk_char(sline, eline, curln, curcol, wordbuf, wordbuflen, *s);
		s++;
    	}
}

int	dotalkuserlist(sline, eline, curln, curcol, wordbuf, wordbuflen)
int	sline,
	eline,
	*curln,
	*curcol,
	*wordbuflen;
char	*wordbuf;
{
    	char	*s = TALK_CURR_ONBBS,
    		bigbuf[STRLEN],
    		littlebuf[20];
    	int	savecolumns,
		pos = 0,
		i;
    	usinfo	uent;

    	savecolumns = (t_columns > STRLEN ? t_columns : 0);
    	bigbuf[0] = '\0';


    	do_talk_string(sline, eline, curln, curcol, wordbuf, wordbuflen, s);

	resolve_utmp();
	for (i = 0; i < UTMP_SIZE; i++)
	{
		memcpy(&uent,&(utmpshm->utc[i]),sizeof(usinfo));
		if (dotalkent(&uent, littlebuf) == -1) 
			continue;
		if (pos + strlen(littlebuf) >= t_columns)
		{
	    		do_talk_string(sline, eline, curln, curcol,
				wordbuf, wordbuflen, bigbuf);
	    		bigbuf[0] = '\0';
	    		pos = 0;
        	}
		strcat(bigbuf, littlebuf);
		pos += strlen(littlebuf);
    	}

    	if (pos > 0) 
	{
		bigbuf[pos-2] = '\n';
        	bigbuf[pos-1] = '\0';
		do_talk_string(sline, eline, curln, curcol, wordbuf,
			wordbuflen, bigbuf);
    	}

    	if (savecolumns) 
		t_columns = savecolumns;        
}

int	shortulist(uentp, f_lists, f_count)
usinfo	*uentp;			/*	userinfo	*/
char	*f_lists;		/*	�x�s friends ���r��}�C	*/
int	f_count;		/*	override �̪� friend �� */
{
	static	int	fullcount = 0,
			lineno = 0,
			cnt = 0;
	int	i,
		finaltally,
		notfriend = 1;	/*	�P�_���D�ͤH��, ��Ȭ� 1	*/
	char	uentry[30];

	if (!lineno) 
	{
		lineno = 3;
		move(lineno, 0);
	}
	if (uentp == NULL) 
	{
		clrtoeol();
		move(++lineno, 0);
		clrtobot();
		finaltally = fullcount;
		lineno = cnt = fullcount = 0;
		return finaltally;
	}
	uentry[0] = '\0';
	if (uinfo.mode == FMONITOR)
	{
		for (i=0; i<=f_count; i++)
		{
			if (!strcmp(uentp->userid, (f_lists+i*20)))
				notfriend = 0;
		}
	}
	if ((!uentp->active || !uentp->pid) || (!HAS_PERM(PERM_SEECLOAK) &&
		uentp->invisible) || (kill(uentp->pid, 0) == -1)
		|| ((uinfo.mode == FMONITOR) ? notfriend : 0))
		strcpy(uentry, " ");

	if (!uentry[0]) 
	{
		if ((uentry[0] != ' ') && (fullcount >= (page - 1) * 60) 
			&& (fullcount <= (page - 1) * 60 + 60 - 1)) 
		{
        		sprintf(uentry, "%-12.12s %c%-10.10s", uentp->userid,
				uentp->invisible ? '#' : ' ',
				modestring(uentp->mode, uentp->ptcb));
			if (++cnt < 3)
				strcat(uentry, " : ");
			prints(NA, uentry);
		}
		fullcount++;
	}
	if (cnt == 3) 
	{
		cnt = 0;
		clrtoeol();
		if (++lineno <= t_lines)
       	        	move(lineno, 0);
	}
	return 0;
}

int	do_list()
{       
	int	count,
		f_count = 0,
		i;
        time_t	thetime;
	FILE	*fp;
	char	*lists,
		f_list[MAXACTIVE][20],
		genbuf[STRLEN];

        move(2, 0);
        prints(YEA, "[1;36;44m%-12s  %-10s : %-12s  %-10s : %-12s  %-11s[m\n",
 	        "�ϥαb��", "�ثe�ʺA", "�ϥαb��", "�ثe�ʺA", "�ϥαb��",
 	        "�ثe�ʺA");
        if (uinfo.mode == FMONITOR)
        {
                sprintf(genbuf, PATH_OVERRIDE, cuser.userid, "override");
                if ((fp = fopen(genbuf, "r")) == NULL)
                {
			clrtobot();
                        prints(NA, TALK_NOFRIEND);
                        return -1;
                }
		while (fgets(genbuf, STRLEN, fp) != NULL)
		{
                	if (strtok(genbuf, " \n\r\t") != NULL)
			{
				strncpy(f_list[f_count] , genbuf, 20);
				f_count++;
				lists = f_list[0];
			}
		}
                fclose(fp);
	}
	for (i = 0;i <= UTMP_SIZE; i++)
	{
		if (shortulist(&(utmpshm->utc[i]), lists, f_count) == QUIT)
		{
			prints(NA, "No Users Exist\n");
			return 0;
		}
	}
	count = shortulist(NULL, NULL, NULL);

	if (uinfo.mode == FMONITOR && count == 0)
		prints(NA, TALK_CANT_FIND_FRIEND);

        (void)time(&thetime); 		
	if (uinfo.mode == MONITOR || uinfo.mode == FMONITOR) 
	{
		move(0, 50);
		prints(NA, "%29s", chkmails(cuser, NA) ? "(You have mail.)" :
			BoardName);
		move(1, 0);
		if (uinfo.mode == MONITOR)
			prints(NA, "%-79s", "�i�� f ��i��l�ܦn�Ϳù��j");
		else
			prints(NA, "%-79s", "�i�� m ��i�^��l�ܯ��Ϳù��j");
		move(1, 50);
		if (talkrequest)
			prints(NA, "�i�s�����j%s �Q�M�z����", page_requestor);
		else if (msgrequest)
			prints(NA, "�i�s�����j%s �e�ӤF�T��", page_requestor);
		else
			clrtoeol();
		move(t_lines-1, 0);
	} 
	else
                move(0, 0);
	prints(NA, "[1;36;44m ���� %2d/%2d ����    �@ %3d %-14s����s�ɶ� %24s�� [m",
		page, maxpage, count,
		(uinfo.mode == FMONITOR)? "��n�ͦb���W" : "�H�b���W", 
		Ctime(&thetime));
	if (dumb_term) 
		oflush();
	else 
		refresh();
	return 0;
}

int	t_list()
{
	uinfo.mode = LUSERS;
	update_utmp();
        move(0, 0);
        clrtobot();
	prints(NA, TALK_CURR_ONBBS);
	(void)do_list();
	pressreturn();
	move(2, 0);
	clrtoeol();
        uinfo.mode = TMENU;
	update_utmp();
	return 0;
}

void	sig_catcher()
{
	if (uinfo.mode != MONITOR && uinfo.mode != FMONITOR) 
	{
#ifdef DOTIMEOUT
		init_alarm(NA);
#else
		signal(SIGALRM, SIG_IGN);
#endif
		return;
        }		
	if (signal(SIGALRM, sig_catcher) == SIG_ERR) 
	{
		perror("signal");
		exit(1);
	}
#ifdef DOTIMEOUT
	if (!HAS_PERM(PERM_NOTIMEOUT))
	{
		idle_monitor_time += M_INT;
		if ((idle_monitor_time >= MONITOR_TIMEOUT - WARN_TIMEOUT) &&
		    (idle_monitor_time <= MONITOR_TIMEOUT - (WARN_TIMEOUT-M_INT)))
			bell(15);
		if (idle_monitor_time > MONITOR_TIMEOUT) 
		{
			goodbye();
		}
	}
#endif
	(void)do_list();
	alarm(M_INT);
}

int	t_monitor()
{
	int	c;
	char	maxpagech;

	alarm(0);
	signal(SIGALRM, sig_catcher);
	page = 1;
	maxpage=(MAXACTIVE + 60 - 1)/60;
	maxpagech = (char)(maxpage + 060);
	idle_monitor_time = 0;

	changemode(MONITOR);

	move(0, 0);
	clrtobot();
	prints(NA, TALK_MONITOR, M_INT);
	(void)do_list();
	alarm(M_INT);
	while (YEA) 
	{
		c = igetkey();
		if (c == CTRL('D') || c == CTRL('C') || c == KEY_LEFT ||
			c == 'q' || c == 'Q')
			break;
	    	else
		{
			idle_monitor_time = 0;
			switch (c)
			{
	                        case KEY_DOWN:
        	                case KEY_RIGHT:
                	                if ((++page) <= maxpage)
					{
                        	                (void)do_list();
                                	        alarm(M_INT);
                                	}
	                                else
						page=maxpage;
		                        break;
				case KEY_UP:
				case KEY_LEFT:
                                	if ((--page) >= 1)
					{
                                        	(void)do_list();
                                        	alarm(M_INT);
                                	}
	                                else
						page = 1;
        	                        break;
				case 'f':
				case 'F':
					changemode(FMONITOR);
					page = 1;		
					if (do_list() == -1)
					{
						changemode(MONITOR);
					}
					alarm(M_INT);
					break;
				case 'm':
				case 'M':
					changemode(MONITOR);
					page = 1;
					(void)do_list();
					alarm(M_INT);
					break;
                	        default:        break;
			}
			if (c >= '1' && c <= maxpagech)
			{
				page = c - 48;
				(void)do_list();
				alarm(M_INT);
			}
		}
	}
	move(2, 0);
	clrtoeol();
	changemode(TMENU);
	return 0;
}

int	can_override(userid, whoasks, fname)
char	*userid,
	*whoasks,
	*fname;
{
	FILE	*fp;
	char	buf[STRLEN];
	int	blen;

    	sprintf(buf, PATH_OVERRIDE, userid, fname);
    	if ((fp = fopen(buf, "r")) == NULL)
		return 0;
    	while (fgets(buf, STRLEN, fp) != NULL) 
	{
        	blen = strlen(buf);
        	if (buf[blen-1] == '\n')
	    		buf[--blen] = '\0';
        	if (!strcmp(buf, whoasks)) 
		{
            		fclose(fp);
            		return 1;
        	}
    	}
   	fclose(fp);

    	return 0;
}

int	listfriends(fname, seed)
char	*fname,
	*seed;
{
	FILE	*fp;
	int	cnt = 0;
	char	*nl,
		genbuf[STRLEN],
		other[STRLEN];

	CreateLinkList();
	sprintf(genbuf, PATH_OVERRIDE, cuser.userid, fname);
	if ((fp = fopen(genbuf, "r")) == NULL) 
		return 0;
	while (fgets(genbuf, STRLEN, fp) != NULL) 
	{
		if (!((seed == NULL) || cmp_bhd_seed(genbuf, seed)))
			continue;
		if (nl = (char *)strrchr(genbuf, '\n')) 
			*nl = '\0';
	    	AddLinkList(genbuf, strlen(genbuf));
	    	cnt++;
	}
	fclose(fp);
	return cnt;
}

int	listoverride(seed)
char	*seed;
{
	return listfriends("override", seed);
}

int	addtooverride(uident, fname)
char	*uident,
	*fname;
{
	FILE	*fp;
	int	rc;
	char	genbuf[STRLEN];

	if (can_override(cuser.userid, uident, fname)) 
		return -1;
	sprintf(genbuf, PATH_OVERRIDE, cuser.userid, fname);
	if ((fp = fopen(genbuf, "a")) == NULL)
		return -1;
	flock(fileno(fp), LOCK_EX);
	rc = fputs(uident, fp);
	(void)fputc('\n', fp);
	flock(fileno(fp), LOCK_UN);
	fclose(fp);
	return(rc == EOF ? -1 : 0);
}		

int	deleteoverride(uident, fname)
char	*uident,
	*fname;
{
	FILE	*fp,
		*nfp;
	int	deleted = NA;
	char	fn[STRLEN],
		fnnew[STRLEN],
		genbuf[STRLEN];

	sprintf(fn, PATH_OVERRIDE, cuser.userid, fname);
	if ((fp = fopen(fn, "r")) == NULL) 
		return -1;
	sprintf(fnnew, PATH_MOVERRIDE, cuser.userid, getuid());
	if ((nfp = fopen(fnnew, "w")) == NULL) 
		return -1;
	while (fgets(genbuf, STRLEN, fp) != NULL) 
	{
		if (strncasecmp(genbuf, uident, strlen(uident)))
			fputs(genbuf, nfp);
	    	else 
			deleted = YEA;
	}
	fclose(fp);
	fclose(nfp);
	if (!deleted) 
		return -1;
	return(rename(fnnew, fn));
}

int	t_override()
{
	char	uident[STRLEN];
	int	ans,
		count;

	while (YEA) 
	{
  		clear();
		prints(NA, TALK_EDIT_OVERRIDE);
        	count = listoverride(NULL);
		query_name_list(NULL, 0);
  		if (count)
	        	ans = getans(1, 0, TALK_ADDOVERRIDE, 'e');
	  	else 
	        	ans = getans(1, 0, TALK_NEWOVERRIDE, 'e');
	  	if (ans == 'a') 
		{
			if (init_namelist(uident))
	        		addtooverride(uident, "override");
	  	}
	  	else if ((ans == 'D' || ans == 'd') && count) 
		{
			move(2, 0);
			name_query("Enter userid: ", uident, listoverride);
			move(2, 0);
			clrtoeol();
			if (uident[0] != '\0')
	        		deleteoverride(uident, "override");
	  	}		
	  	else 
			break;
	}
	clear();
	return 0;
}		

int	kick_user()
{
/*	int	id,
		ind,
		ans;
        usinfo	uin;
	FILE	*ufp;
	time_t	ti;
*/	char	kickuser[40];
/*		genbuf[STRLEN];
*/
	if (init_namelist(kickuser) == 0)
		return 0;
	(void)get_talk_pid(NULL, NULL);
	page_multi_select(kickuser, multi_kick_cmd);
	return 0;
}

int	msg_connect(tuid, uident, uin, text)
int	tuid;
char	*uident;
usinfo	*uin;
char	*text;
{
	int	sock,
		msgsock,
		length,
		savemode;
	struct	sockaddr_in	server;
	char	c[STRLEN+1],
		saveptcb[20];

	if (!HAS_PERM(PERM_TRUE))	return	-9;
	if (!uin->comp && !HAS_PERM(PERM_SYSOP))
	{
		move(2, 0);
		prints(NA, "���ثe���@�N�����T��");
		return	-2;
	}
        if (uin->mode >= EXTERN)
	{
		move(2, 0);
		prints(NA, "���ثe����K�����T��");
		return -1;
	}
	if (uin->pid == 0) 
	{
		move(2, 0);
		prints(NA, TALK_ERRORPID);
		return -1;
	}
	if (!uin->active || (kill(uin->pid, 0) == -1)) 
	{
		move(2, 0);
		prints(NA, TALK_LOGOUT);
		return -1;
        }

	sock = socket(AF_INET, SOCK_STREAM, 0);

	if (sock < 0) 
	{
		perror("opening stream socket\n");
		return -1;
	}

	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_port = 0;

	if (bind(sock, (struct sockaddr *)&server, sizeof(server)) < 0)
	{
		perror("binding stream socket");
		return -1;
	}

	length = sizeof(server);
	if (getsockname(sock, (struct sockaddr *)&server, &length) < 0)
	{
		perror("getting socket name");
		return -1;
	}

	uinfo.sockactive = YEA;
	uinfo.sockaddr = server.sin_port;
	uinfo.destuid = tuid;

	savemode = uinfo.mode;
	BACKUP(uinfo.ptcb, saveptcb);
	memset(uinfo.ptcb, 0, 20);

	changemode(SENDMSG);

	if (!text)
	{
	getdata(2, 0, "�п�J�T���G", c, sizeof c, DOECHO, YEA);
	if (c[0] == '\0' || c[0] == '\r' || c[0] == '\n')	return	-13;
	}
	changemode(PAGE);
	if (kill(uin->pid, SIGUSR2) == -1)
	{
		prints(NA, TALK_LOGOUT);
		pressreturn();
	}
/*
	prints(NA, "���b�V %s �ǰe�T��......", uident);
*/
	listen(sock, 1);
	add_io(sock, 8);

	while (YEA) 
	{
		int	ch;

#if defined(POSIX) || defined(LINUX)
		add_io(sock, 8);
#endif
		ch = igetch();
		if (ch == I_TIMEOUT) 
		{
			move(2, 0);
			clrtoeol();
			prints(NA, "�A�յ۶ǰe�@���D�D�D�� ctrl-d ���");
			bell(1);

			if (kill(uin->pid, SIGUSR2) == -1) 
			{
				move(2, 0);
				clrtoeol();
				prints(NA, TALK_LOGOUT);
				pressreturn();
				memset(uinfo.ptcb, 0, sizeof(uinfo.ptcb));
				changemode(TMENU);
				return -1;
			}
			continue;
		}

		if (ch == I_OTHERDATA)
                     	break;

		if (ch == '\004') 
		{
                       	add_io(0, 0);
                       	close(sock);
                       	uinfo.sockactive = NA;
                       	uinfo.destuid = 0;
			memset(uinfo.ptcb, 0, sizeof(uinfo.ptcb));
			changemode(TMENU);

                       	clear();
                       	return 0;
		}
	}

	msgsock = accept(sock, (struct sockaddr *)0, (int *) 0);
	if (msgsock == -1) 
	{
		perror("accept");
		memset(uinfo.ptcb, 0, sizeof(uinfo.ptcb));
		changemode(TMENU);
		return -1;
	}
	add_io(0, 0);
	close(sock);

	if (!text)	text = c;
	write(msgsock, text, STRLEN+2);
	close(msgsock);
/*	move(2, 0);
	clrtoeol();
	prints(NA, "���w����z�e���T��");
*/	uinfo.destuid = 0;
	uinfo.sockactive = NA;

	RESTORE(uinfo.ptcb, saveptcb);
	changemode(savemode);

        return 0;
}

int	readmessage()
{
	int	a;
	struct	hostent	*h;
	char	hostname[STRLEN],
		saveptcb[20],
		buf[STRLEN+1];
	struct	sockaddr_in	sin;

	if (setpagerequest())	return 0;

	gethostname(hostname, STRLEN);

	if (!(h = (struct hostent *)gethostbyname(hostname))) 
	{
		perror("gethostbyname");
		RESTORE(uinfo.ptcb, saveptcb);
		changemode(uinfo.mode);
		return -1;
	}

	memset(&sin, 0, sizeof(sin));
	sin.sin_family = h->h_addrtype;
	memcpy(&sin.sin_addr, h->h_addr, h->h_length);
	sin.sin_port = ui.sockaddr;
	a = socket(sin.sin_family, SOCK_STREAM, 0);
	if ((connect(a, (struct sockaddr *)&sin, sizeof sin))) 
	{
		perror("connect failed");
		RESTORE(uinfo.ptcb, saveptcb);
		changemode(uinfo.mode);
		return -1;
	}

	read(a, buf, sizeof(buf));
	close(a);
	if (uinfo.mode == CHAT1 || uinfo.mode == CHAT2 || uinfo.mode == CHAT3
		|| uinfo.mode == BMCHAT)
	{
		printchatline(NA, "[1;36m%s[37m �ǨӰT���G[32m%s[m\n", page_requestor, buf);
	}
	else	if (uinfo.mode == SMAIL || uinfo.mode == POSTING ||
			uinfo.mode == TALK)
	{
		if (uinfo.mode == TALK)	move((t_lines-1)/2, 0);
		else	move(t_lines-1, 0);
		clrtoeol();
		prints(NA, "[1;33m%s [37m�ǨӰT���G[32m%s[m\n", page_requestor, buf);
	}
	else
	{
		if (msgrequest)	free(msgrequest);
		msgrequest = (char *)malloc(STRLEN+1);
		strcpy(msgrequest, buf);
		return	0;
	}
	memset(page_requestor, 0, sizeof(page_requestor));
	return 0;
}

void	showmessage()
{
	usinfo	uin;
	char	buf[STRLEN+1],
		sendto[IDLEN+1];
	int	a;

	clear();
	strcpy(sendto, page_requestor);
	memset(page_requestor, 0, sizeof(page_requestor));
	prints(NA, "[1;36m%s [m���G[1;37m%s[m\n", sendto, msgrequest);
	free(msgrequest);
	msgrequest = NULL;
	prints(NA, "\n����J�^�аT���A���^���ܽЫ� enter\n");
	getdata(3, 0, "�T���G", buf, sizeof buf, DOECHO, YEA);
	if (buf[0] != '\0')
	{
		a = getuser(sendto);
		(void)search_ulist(&uin, t_cmpuids, a);
		msg_connect(a, sendto, &uin, buf);
	}
	pressreturn();
	clear();
}

int	t_send()
{
        char	uident[STRLEN];
        int	tuid,
		tpid;
        usinfo	uin;

        move(2, 0);
        prints(NA, "<Enter Userid>\n");
        move(1, 0);
        clrtoeol();
        prints(NA, "To: ");
        name_query(NULL, uident, creat_list);

        if (uident[0] == '\0') 
	{
		move(2, 0);
		clrtoeol();
                return 0;
        }
	tuid = getuser(uident);

        if (!tuid || tuid == usernum) 
	{
                move(2, 0);
                prints(NA, "Bad User ID\n");
/*		pressreturn();
                move(2, 0);
                clrtoeol();
*/		return -1;
        }
#if	defined(ALLOW_MULTI_LOGINS) || defined(PERM_MULTILOG)
	(void)get_talk_pid(NULL, NULL);
	if (get_ulist(&uin, get_talk_pid, uident) == QUIT)
	{
		page_multi_select(uident, multi_send_cmd);
		return 0;
	}
	else
		tuid = uin.uid;
#else
        (void)search_ulist(&uin, t_cmpuids, tuid);
#endif
	return	msg_connect(tuid, uident, &uin, NULL);
}
