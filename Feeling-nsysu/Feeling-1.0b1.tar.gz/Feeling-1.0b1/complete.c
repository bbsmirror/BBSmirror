/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    SccsId[] = "@(#)complete.c	2.1	12/24/95";
#endif

#include "bbs.h"

extern	int	scrint;
extern	jmp_buf	byebye;

extern	int	cmp_bhd_seed();

List	*L_head = NULL,
	*L_tail = NULL;

void	FreeLinkList() 
{
	List	*p,
		*tmp;

	for (p = L_head; p != NULL; p = tmp)
	{
		tmp = p->next;
		free(p->info);
		free(p);
	}
}

void	CreateLinkList()
{
	if (L_head)
		FreeLinkList();
	L_head = NULL;
	L_tail = NULL;
}

void	AppendLinkList(curr, node)
List	*curr,
	*node;
{
	node->next = curr->next;
	node->prev = curr;
	if (curr != L_tail)
		curr->next->prev = node;
	curr->next = node;
}

void	SplitLinkList(curr, size)
List	*curr;
int	size;
{
	List	*new;

	new = (List *)malloc(sizeof(List));
	new->info = (char *)malloc(size + 1);
	(void)memset(new->info, 0, size+1);
	(void)memcpy(new->info, curr->info, size);
	AppendLinkList(curr, new);
}

void	AddLinkList(name, size)
char	*name;
int	size;
{
	List	*node;

	node = (List *)malloc(sizeof(List));
	node->next = NULL;
	node->info = (char *)malloc(size+1);
	(void)memset(node->info, 0, size+1);
	(void)memcpy(node->info, name, size);

	if (L_head)
	{
		node->prev = L_tail;
		L_tail->next = node;
		L_tail = node;
		return;
	}
	L_head = node;
	L_tail = node;
	node->prev = NULL;
	return;
}

void	DropFromLinkList(curr)
List	*curr;
{
	List	*tmp;

	tmp = curr;
	if (curr->prev)
		curr->prev->next = tmp->next;
	if (curr->next)
		curr->next->prev = tmp->prev;
	free(curr->info);
	free(curr);
}

void	ArrangeLinkList(key, keysize, plus, cmp, site)
char	*key;
int	keysize;
int	(*plus)(),
	(*cmp)(),
	(*site)();
{
	List	*p;

	if (L_head == NULL)
	{
		AddLinkList(key, keysize);
		return;
	}
	switch ((*plus)(L_tail->info, key))
	{
		case 0:
			return;
		case 1:
			AddLinkList(key, keysize);
			return;
	}
	for (p = L_head; p != NULL; p = p->next)
	{
		switch ((*cmp)(p->info, key))
		{
			case 1:
				return;
			case QUIT:
				AppendLinkList(p, key);
				if (!(*plus)(p->info, p->next->info))
					DropFromLinkList(p->next);
				else
					p = p->next;
				if (!(*plus)(p->info, p->next->info))
					DropFromLinkList(p->next);
				return;
			case -1:
				SplitLinkList(p, keysize);
				(*site)(p->info, p->next->info, key);
				AppendLinkList(p, key);
				return;
		}
	}
}

int	NumInList(list)
List	*list;
{
	int	i;
	
	for (i = 0; list != NULL; i++, list = list->next);
	return i;
}

int	InsertLinkList(info, n, size)
char	*info;
int	n,
	size;
{
	List	*node,
		*p;
	int	curr;

	if (L_head == NULL)
	{
		AddLinkList(info, size);
		return YEA;
	}
	for (curr = 1, p = L_head; p != NULL; p = p->next, curr++)
	{
		if (curr == n)
		{
			node = (List *)malloc(sizeof(List));
			node->info = (char *)malloc(size + 1);
			node->next = p;
			node->prev = p->prev;
			if (p->prev == NULL)
				L_head = node;
			else
				p->prev->next = node;
			p->prev = node;
			(void)memset(node->info, 0, size+1);
			(void)memcpy(node->info, info, size);
			return YEA;
		}
	}
	AddLinkList(info, size);
	return YEA;
}

int	DelFromLinkList(fptr, buf)
int	(*fptr)();
char	*buf;
{
	List	*p,
		*tmp;

	if (L_head == NULL)
		return 0;
	for (p = L_head; p!=NULL; p = p->next)
	{
		if (!(*fptr)(p->info, buf))
			continue;
		tmp = p;
		if (p == L_head)
			L_head = p->next;
		else
			p->prev->next = tmp->next;
		if (p->next != NULL)
			p->next->prev = tmp->prev;
		else
			L_tail = p->prev;
		free(p->info);
		free(p);
	}
}

int	ApplyToLinkList(fptr, buf)
int	((*fptr)());
char	*buf;
{
	List	*p;

	if (L_head == NULL)
		return 0;
	for (p = L_head; p!=NULL; p = p->next)
	{
		if ((*fptr)(p->info, buf) == QUIT)
			return -1;
	}
	return 0;
}

char	*SearchLinkList(fptr, key)
int	(*fptr)();
char	*key;
{
	List	*p;

	if (L_head == NULL)
		return NULL;
	for (p = L_head; p!=NULL; p = p->next)
	{
		if ((*fptr)(p->info, key))
			return p->info;
	}
	return NULL;
}

int	GetNumLinkList(ent, num, size, buf)
int	ent,
	num,
	size;
char	*buf;
{
	List	*p;
	int	i = 1;

	if (L_head == NULL)
		return 0;
	for (p = L_head; p != NULL && i < ent + num; p = p->next, i++)
	{
		if (i >= ent)
		{
			(void)memset(buf, 0, size);
			(void)memcpy(buf, p->info, size);
			buf += size;
		}
	}
	return i - ent;
}

int	chkstr(tag,name)
char	*tag,
	*name;
{
	char	*otag = tag,
		*oname = name;

	while (*tag != '\0')
	{
		if (toupper(*tag) != toupper(*name)) 
			return 0;
		tag++;
		name++;
	}

	if (*name == '\0')
		(void)strcpy(otag, oname);

	return 1;
}

List	*GetSubList(tag,list)
char	*tag;
List	*list;
{
	List	*wlist,
		*wcurr;

	wlist = NULL;
	wcurr = NULL;
	while (list != NULL)
	{
		if (chkstr(tag,list->info))
		{
			List	*node;

			node = (List *)malloc(sizeof(List));
			node->info = list->info;
			node->next = NULL;
			if (wlist)
				wcurr->next = node;
			else
				wlist = node;
			wcurr = node;
		}
		list = list->next;
	}
	return wlist;
}

void	ClearSubList(list)
List	*list;
{
	List	*tmp;
	
	while (list)
	{
		tmp = list->next;
		free(list);
		list = tmp;
	}
}

int	MaxLen(list,count)
List	*list;
int	count;
{
	int	t,
		len = strlen(list->info);
	List	*curr = list;

	while (curr != NULL && count)
	{
		t = strlen(curr->info);
		if (t > len)
			len = t;
		curr = curr->next;
		count--;
	}
	return len;
}

int	query_name_list(data, pos)
char	*data;
int	pos;
{
	int	i,
		col = 0,
		len = 0;
	List	*p;

	if (NumInList(L_head) == 1 && data != NULL)
	{
		(void)strcpy(data, L_head->info);
		return -1;
	}
	col = 0;
	move(3, 0);
	clrtobot();
	prints(YEA, "[1;36;44m%s[37m%s[36m%s[m",
		"==============================", " �����ѦҸ�ƦC�� ",
		"==============================");
	for (p = L_head, i = 0; p != NULL, i < pos; p = p->next, i++);
	while (p != NULL && p->info[0] != '\0')
	{
		len = MaxLen(p, 20) + 2;
		if (col + len > 80)
			break;
		for (i = 0; p != NULL && i < NUMLINES; p = p->next, pos++, i++)
		{
			move(i + 4, col);
			prints(NA, "%s", p->info);
		}
		col = col + len;
		if (col >= 80)
			break;
	}
	if (p != NULL)
	{
		move(23, 0);
		prints(NA, "---- �����٦���� ----");
	}
	refresh();
	return ((p == NULL) ? 0 : pos);
}

void	SearchPattern(key)
char	*key;
{
	List	*p;

	if (L_head == NULL)
		return;
	if (L_head->next == NULL)
	{
		(void)strcpy(key, L_head->info);
		return;
	}
	for (p = L_head; p != NULL; p = p->next)
	{
		if (!strcasecmp(p->info, key))
		{
			(void)strcpy(key, p->info);
			return;
		}
	}
	(void)strcpy(key, L_head->info);
	return;
}

int	name_query(prompt, data, apply_query)
char	*prompt,
	*data;
int	(*apply_query)();
{
	int	ch,
		pos = 0,
		x, y,
		now = 0;

	if (prompt != NULL)
	{
		prints(NA, "%s", prompt);
		clrtoeol();
	}
	getyx(&y, &x);
	CreateLinkList();
	(*apply_query)(NULL);
	if (L_head == NULL)
		return -1;
	data[0] = '\0';
	while (1)
	{
		move(y, x + strlen(data));
		if ((ch = igetkey()) == EOF)
			break;
		/* ��X�̱��񻲦X�� */
		if (ch > 254)
		{
			bell(1);
			continue;
		}
		if (ch == '\n' || ch == '\r')
		{
			break;
		}
		/* �C�X�W�� */
		if (ch == ' ')
		{
			if ((pos = query_name_list(data, pos)) == -1)
			{
				now = strlen(data);
				move(y, x);
				prints(NA, "%s", data);
			}
			continue;
		}
		else
			pos = 0;
		/* �R���ثe�r�� */
		if (ch == '\177' || ch == '\010')
		{
			if (--now < 0)
			{
				now = 0;
				bell(1);
			}
			else
			{
				move(y, x+now);
				clrtoeol();
				data[now] = '\0';
				CreateLinkList();
				(*apply_query)(data);
			}
			continue;
		}
		/* �P�_�ثe data buffer �P LinkList �����Y */
		data[now++] = (char)ch;
		data[now] = '\0';
		if (SearchLinkList(cmp_bhd_seed, data) == NULL)
		{
			data[--now] = '\0';
			bell(1);
			continue;
		}
		move(y, x);
		prints(NA, "%s", data);
		CreateLinkList();
		(*apply_query)(data);
	}
	if (data[0])
		SearchPattern(data);
	CreateLinkList();
	return 0;
}
