/*
    �I��ڤ߸�T���{��
    ���v�Ҧ� (C)1995 1996, ������, kftseng@bbs.ccu.edu.tw

    ���{���� shareware, �Z���ϥΥ��{����, �ȥ��b�}��e�q�����{���@
    ��. �Y���}�[�]���W�L 10 �ӤH�ϥΪ����O, �ӵL���{���@�̥������v
    �h�����I�ǥ��{���@�̪����z�]���v.
*/

#ifndef lint
static  char    SccsId[] = "@(#)stuff.c	2.1.1.1	5/28/96";
#endif

#include "bbs.h"

int	switch_bit(byte, bit)
int	*byte,
	bit;
{
	if ((*byte)& bit )
		(*byte) &= ~bit;
	else
		(*byte) |= bit;
	return (*byte)& bit;
}

void	bell(i)
int	i;
{
	int	j;

	for (j=0; j<i; j++)
	{
		usleep(100);
		(void)fprintf(stderr,"%c",CTRL('G'));
	}
}

char	*strtolow(buf1)
char	*buf1;
{
	int	i;
	static	char	buf2[STRLEN*2];

	(void)memset(buf2, 0, STRLEN);
        for (i = 0; i < strlen(buf1); i++)
                buf2[i] = (isalpha(buf1[i])?buf1[i]|0x20:buf1[i]);

	return buf2;
}

char	*Ctime(clock)
time_t	*clock;
{
	char	*foo,
		*ptr = ctime(clock);

	if ((int)(foo = strrchr(ptr, '\n')))
                *foo = '\0';

	return (ptr);
}

int	strncmpi(s1,s2,n)
char	*s1,
	*s2;
int	n;
{
	for (; n; s1++, s2++, n--)
	{
		int	ret;

		if (*s1=='\0' && *s2 == '\0')
			break;
		if ((ret = (isalpha(*s1)?*s1|0x20:*s1) -
			(isalpha(*s2)?*s2|0x20:*s2)) != 0)
			return ret;
	}

	return 0;
}

int	buildfile(fname)
char	*fname;
{
	char	path[STRLEN],
		idxpoint[STRLEN],
		genbuf[STRLEN];
	int	fp,
		curr;
	struct	stat	st;

	if (access(fname, X_OK|R_OK|W_OK))
		(void)mkdir(fname, 0755);
	(void)strcpy(path, fname);
	(void)sprintf(idxpoint, "%s/%s", path, FHDIR);
	if (stat(idxpoint, &st) == -1 || st.st_size == 0)
		curr = 1;
	else
	{
		fhd	last;
		int	size = sizeof(fhd);

		get_record(idxpoint, &last, size, st.st_size/size);
		curr = atoi(last.filename + 2) + 1;
	}

	while (1)
	{
		(void)sprintf(fname, "S.%010d.A", curr);
		(void)sprintf(genbuf, "%s/%s", path, fname);
		if ((fp = open(genbuf, O_CREAT|O_EXCL|O_WRONLY, 0644)) != -1)
			break;
		if (errno != EEXIST)
			return -1;
		curr++;
	}
	(void)close(fp);
	return 0;
}

int 	logit(file, va_alist)
char	*file;
va_dcl
{
	va_list	args;
	char	*fmt;
        time_t  ti;
        FILE    *fp;

	if ((fp = fopen(file, "a+")) == NULL)
		return -1;
	(void)time(&ti);
	va_start(args);
	fmt = va_arg(args, char *);
	(void)fprintf(fp, "[%12.12s] ", Ctime(&ti)+4);
	(void)vfprintf(fp, fmt, args);
	(void)fputs("\n", fp);
	va_end(args);
	(void)fclose(fp);
	return 0;
}
