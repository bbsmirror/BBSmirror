#ifdef MD4
#include "md4c.c"
#endif
#ifdef MD5
#include "md5c.c"
#endif
