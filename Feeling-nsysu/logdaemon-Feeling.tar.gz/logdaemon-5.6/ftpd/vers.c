char version[] = "Version 4.118 Sat Jan 4 19:36:05 EST 1997";
