#include "bbs.h"

#define  PASSWD "/home/bbs/.PASSWDS"
#define  OUTPASS "PASSWDS.NEW"
char yn[10]="",flag=1;
int coun=0;
userec cuser;

int
bad_user_id()
{
  register char ch;
  int j;

  if (strlen(cuser.userid) < 2 || !isalpha(cuser.userid[0]) )
    return 1;
/*
  if (cuser.numlogins==0 || cuser.numlogins>15000)
    return 1;

  if (cuser.numposts>15000)
    return 1;

  if (!strcasecmp(cuser.userid, "new"))
    return 1;
*/

  for(j=1;ch = cuser.userid[j];j++)
  {
    if (!isalnum(ch))
      return 1;
  }
  return 0;
}


struct new
{
  char userid[IDLEN + 1];         /* �ϥΪ̦W��  13 bytes */
//  char realname[20];              /* �u��m�W    20 bytes */
//  char pad1[20];
  char username[24];              /* �ʺ�        24 bytes */
  char passwd[PASSLEN];           /* �K�X        14 bytes */
  uschar uflag;                   /* �ϥΪ̿ﶵ   1 byte  */
  usint userlevel;                /* �ϥΪ��v��   4 bytes */
  ushort numlogins;               /* �W������     2 bytes */
  ushort numposts;                /* POST����     2 bytes */
  time_t firstlogin;              /* ���U�ɶ�     4 bytes */
  time_t lastlogin;               /* �e���W��     4 bytes */
  char lasthost[24];              /* �W���a�I    24 bytes */
  char vhost[24];                 /* �������}    24 bytes */
//  char email[50];                 /* E-MAIL      50 bytes */
//  char address[50];               /* �a�}        50 bytes */
//  char justify[REGLEN + 1];       /* ���U���    39 bytes */
// char pad2[50],pad3[50],pad4[REGLEN + 1];
  uschar month;                   /* �X�ͤ��     1 byte  */
  uschar day;                     /* �X�ͤ��     1 byte  */
  uschar year;                    /* �X�ͦ~��     1 byte  */
  uschar sex;                     /* �ʧO         1 byte  */
  uschar state;                   /* ���A??       1 byte  */
  unsigned long int money;        /* ���W�{��     8 bytes */
  unsigned long int deposit;      /* �Ȧ�s��     8 bytes */
  usint obj;                      /* �©�������   4 bytes */
  usint habit;                    /* �ߦn�]�w     4 bytes */
  uschar pager;                   /* �߱��C��     1 bytes */
  uschar invisible;               /* �����Ҧ�     1 bytes */
  usint exmailbox;                /* �H�c�ʼ�     4 bytes */
  usint exmailboxk;               /* �H�cK��      4 bytes */
  char proverb;                   /* �b�I����     1 bytes */
  usint toquery;                  /* �n�_��       4 bytes */
  usint bequery;                  /* �H���       4 bytes */
  unsigned long int totaltime;    /* �W�u�`�ɼ�   8 bytes */
  usint sendmsg;                  /* �o�T������   4 bytes */
  usint receivemsg;               /* ���T������   4 bytes */
  time_t dtime;                   /* �s�ڮɶ�     4 bytes */
  char feeling[4];                /* �߱����A     4 bytes */
  usint astro;                    /* �P�y         4 bytes */
  unsigned long int starmoney;    /* ���W�s��     8 bytes */
  usint family;                   /* �a�ڵ���     4 bytes */
  usint color;                    /* �ӤH�C��     4 bytes */
  usint idletime;                 /* idletime     4 bytes */
  unsigned long int exp;          /* RPG exp      8 bytes */
  int port;			  /* �Ψ쪺port   4 bytes */
  char pad[43];                  /* �ŵ۶񺡦�256��      */
};

typedef struct new new;

char *
Cdate(clock)
  time_t *clock;
{
  static char foo[22];
  struct tm *mytm = localtime(clock);

  strftime(foo, 22, "%D %T %a", mytm);
  return (foo);
}

int horo(int mon,int day)
{
 switch (mon)
  {
   case 1:
    if(day<=19) return 9;
    else return 10;
    break;
   case 2:
    if(day<=18) return 10;
    else return 11;
    break;
   case 3:
    if(day<=20) return 11;
    else return 0;
    break;
   case 4:
    if(day<=19) return 0;
    else return 1;
    break;
   case 5:
    if(day<=20) return 1;
    else return 2;
    break;
   case 6:
    if(day<=21) return 2;
    else return 3;
    break;
   case 7:
    if(day<=22) return 3;
    else return 4;
    break;
   case 8:
    if(day<=22) return 4;
    else return 5;
    break;
   case 9:
    if(day<=22) return 5;
    else return 6;
    break;
   case 10:
    if(day<=23) return 6;
    else return 7;
    break;
   case 11:
    if(day<=22) return 7;
    else return 8;
    break;
   case 12:
    if(day<=22) return 8;
    else return 9;
    break;
   default:
    return 13;
  }
}

main()
{
  new new;
  char buf[200];
  FILE *fp1=fopen(PASSWD,"r");
  FILE *fp2=fopen(OUTPASS,"w");
  FILE *fp;
  

  printf("size [%d] to size [%d]",sizeof(userec),sizeof(new));
//  if(sizeof(new) != sizeof(userec)) return;
     while( (fread( &cuser, sizeof(cuser), 1, fp1))>0 ) {

  memset(new.pad, 0, sizeof(new.pad));

  strcpy(new.userid,cuser.userid);

/*
//  strcpy(new.realname,cuser.realname);

  sprintf(buf,"/home/bbs/home/%s/.realname",new.userid);

  fp = fopen(buf,"w");
  fprintf(fp,"%s",cuser.realname);
  fclose(fp);
*/

  strcpy(new.username,cuser.username);
  strcpy(new.passwd,cuser.passwd);
  new.uflag=cuser.uflag;
  new.userlevel=cuser.userlevel;
  new.numlogins=cuser.numlogins;
  new.numposts=cuser.numposts;

  if(new.numlogins <= 0)  new.numlogins = 5;
  if(new.numlogins > 20000) new.numlogins = 5;
  if(new.numposts <= 0) new.numposts = 5;
  if(new.numposts > 20000) new.numposts = 5;

  new.firstlogin=cuser.firstlogin;
  new.lastlogin=cuser.lastlogin;
  strcpy(new.lasthost,cuser.lasthost);
  strcpy(new.vhost,cuser.lasthost);

/*
//  strcpy(new.email,cuser.email);
  sprintf(buf,"/home/bbs/home/%s/.email",new.userid);
  fp = fopen(buf,"w");
  fprintf(fp,"%s",cuser.email);
  fclose(fp);

//  strcpy(new.address,cuser.address);

  sprintf(buf,"/home/bbs/home/%s/.address",new.userid);
  fp = fopen(buf,"w");
  fprintf(fp,"%s",cuser.address);
  fclose(fp);

//  strcpy(new.justify,cuser.justify);
  sprintf(buf,"/home/bbs/home/%s/.justify",new.userid);
  fp = fopen(buf,"w");
  fprintf(fp,"%s",cuser.justify);
  fclose(fp);
*/
  new.month=cuser.month;
  new.day=cuser.day;
  new.year=cuser.year;
  new.sex=cuser.sex;
  new.state=cuser.state;
  new.money=cuser.money;
  new.deposit=cuser.deposit;
  new.habit=cuser.habit;
  new.pager=cuser.pager;
  new.invisible=cuser.invisible;
  new.exmailbox=cuser.exmailbox;
  new.exmailboxk=cuser.exmailboxk;

  new.toquery=cuser.toquery;
  new.bequery=cuser.bequery;
  new.totaltime=cuser.totaltime;
  new.sendmsg=cuser.sendmsg;
  new.receivemsg=cuser.receivemsg;
  if(new.toquery < 0 ) new.toquery = 0;
  if(new.toquery > 100000) new.toquery = 0;
  if(new.bequery < 0 ) new.bequery = 0;
  if(new.bequery > 100000) new.bequery = 0;

  if(new.totaltime < 0) new.totaltime = 300;

  if(new.sendmsg < 0) new.sendmsg = 0;
  if(new.sendmsg > 100000 ) new.sendmsg = 0;
  if(new.receivemsg < 0) new.receivemsg = 0;
  if(new.receivemsg > 100000 ) new.receivemsg = 0;
  new.dtime=cuser.dtime;
  strcpy(new.feeling,cuser.feeling);
  new.astro=horo(cuser.month,cuser.day);
  new.starmoney=cuser.starmoney;
  new.idletime=cuser.idletime;
  new.color=cuser.color;
  new.exp=cuser.exp - cuser.exp;

/* ���@�I���ˬd.. skybinary */
  if(new.money < 0)
   new.money = cuser.money - cuser.money + 10000;
  if(new.deposit < 0)
   new.deposit = cuser.deposit - cuser.deposit + 100;
  if(new.starmoney > 10000)
   new.starmoney = cuser.starmoney - cuser.starmoney + 10;
  if(new.money > 10000000)
   new.money = cuser.money - cuser.money + 10000;
  if(new.deposit > 10000000)
   new.deposit = cuser.deposit - cuser.deposit + 100;

/*
 sprintf(buf,"/home/bbs/home/%s/.acct",new.userid);
 fp = fopen(buf,"w");
 fprintf(fp,"%s\n%s\n%s\n%s\n%s\n%d\n",
  new.realname, new.email, new.address, new.justify, new.feeling,
   new.color);
 fclose(fp);


  sprintf(buf,"rm /home/bbs/home/%s/stock_log",new.userid);
  system(buf);
  sprintf(buf,"rm /home/bbs/home/%s/market",new.userid);
  system(buf);
*/

coun ++;


printf("******** %d******** \n",coun);
if(bad_user_id() )
  printf("\n\
userid    :%s\n\
realname  :??\n\
username  :%s\n\
passwd    :%s\n\
uflag     :%x\n\
userlevel :%x\n\
numlogins :%d\n\
numposts  :%d\n\
firstlogin:%s\n\
lastlogin :%s\n\
lasthost  :%s\n\
email     :??\n\
address   :??\n\
justify   :??\n\
birth     :%d/%d/%d\n\
sex       :%d\n\
state     :%x\n\
money     :%d\n\
deposit   :%d\n\
mailbox   :%d\n\
",
new.userid,
//new.realname,
new.username,
new.passwd,
new.uflag,
new.userlevel,
new.numlogins,
new.numposts,
Cdate(&new.firstlogin),
Cdate(&new.lastlogin),
new.lasthost,
//new.email,
//new.address,
//new.justify,
new.month,new.day,new.year,
new.sex,
new.state,
new.money,
new.deposit,
new.exmailbox
);
    if(flag && (bad_user_id() || new.exmailbox < 0))
      {
         printf("\n Accept the data?(Y:yes/n:no/a:all/q:quit all after) :");
         scanf("%1s",yn);
         switch(yn[0])
          {
           case 'n':
           case 'N':
             printf("��󦹸��\n");
             break;
          case 'a':
          case 'A':
              flag =0;
             printf("�����Ҧ����\n");
                break;
          case 'q':
          case 'Q':
              flag =0;
              printf("����������Ҧ����\n");
              goto end;
          case 'm':   /*�ץ�mailbox*/
          case 'M':
             new.exmailbox=0;
          default:
             printf("�������\n");
             fwrite( &new, sizeof(new), 1, fp2);
          }
        }
        else
        {
             fwrite( &new, sizeof(new), 1, fp2);
        }
       }
end:
 fclose(fp1);fclose(fp2);
}
