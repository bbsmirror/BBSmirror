/*        �����D�����{��          */

#include "bbs.h"

#include "../STAR/record.c"
#include "../lib/rec_apply.c"
#include "../lib/rec_get.c"
#include "../lib/rec_add.c"
#include "wildcat.c"

#define FUNCTION    (50000 - c*2500)

extern int numboards;
extern boardheader *bcache;
extern struct UCACHE *uidshm;
#define fn_passwd "/home/bbs/.PASSWDS"
int c,n;
userec xuser;

int getuser(userid)
  char *userid;
{
  int uid;
  if (uid = searchuser(userid))
   {
    rec_get(fn_passwd, &xuser, sizeof(xuser), uid);
   }
  return uid;
}

int inumoney(char *tuser,int money)
{
  int unum;

  if (unum = getuser(tuser))
    {
      xuser.money += money;
      substitute_record(fn_passwd, &xuser, sizeof(userec), unum);
      return xuser.money;
    }
  return -1;
}
void main()
{
  FILE *fp=fopen(BBSHOME "/etc/topboardman","r");
  char buf[201],bname[20],BM[30],*ch;
  boardheader *bptr;
  int money,nBM;

  resolve_boards();
  if(!fp) return ;

  c=0;
  fgets(buf,200,fp); /* �Ĥ@�殳�� */

  printf(
"              [1;44m  ���y�u�}���D �C�g���~ �̺�ذϱƦW���t  [m\n\n"
"[33m                 (�ƦW�ӫ᭱�δX�G�S����ذϪ̤��C�J)[m\n"
"  �w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w\n"
"\n\n");

  while(fgets(buf,200,fp)!=NULL)
    {
       buf[24]=0;
       sscanf(&buf[9],"%s",bname);
       for (n = 0; n < numboards; n++)
             {
                   bptr = &bcache[n];
                if(!strcmp(bptr->brdname,bname)) break;
             }
       if(n== numboards) continue;
       strcpy(BM,bptr->BM);
       printf("        (%d) %-15.15s %s \n",c+1,bptr->brdname,bptr->title);

       if(BM[0] == 0 || BM[0] == ' ') continue;

       ch = BM;
       for(nBM=1;(ch = strchr(ch,'/'))!=NULL;nBM++) {ch++;};
       ch=BM;

       if(FUNCTION <=0 ) break;

       printf("             ���� [32m%6d [m     ���� [33m%s[m \n",
          FUNCTION,bptr->BM);

       for(n=0;n<nBM;n++)
        {
         fileheader mymail;
         char *ch1;
         if(ch1 = strchr(ch,'/'))
                 *ch1 = 0;
         if(inumoney(ch, FUNCTION ) != -1)
          {
            char genbuf[200];
            sprintf(genbuf,BBSHOME"/home/%c/%s", ch[0],ch);
            stampfile(genbuf, &mymail);

            strcpy(mymail.owner, "[�~���U]");
            sprintf(mymail.title,
                        "[32m %s [m�����~�� �C[33m%d[m",bptr->brdname,FUNCTION);
            mymail.savemode = 0;
            unlink(genbuf);
            link(BBSHOME "/etc/BM_money", genbuf);
            sprintf(genbuf,BBSHOME"/home/%c/%s/.DIR", ch[0], ch);
            rec_add(genbuf, &mymail, sizeof(mymail));
          }
         ch=ch1+1;
        }
       c++;
    }
}
