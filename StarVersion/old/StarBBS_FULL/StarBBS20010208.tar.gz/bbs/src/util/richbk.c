/*-------------------------------------------------------*/
/* target : �j�I��.�ѥ����U�{��                          */
/* create : 98/03/18 by SiEpthero                        */
/* update : 98/03/21                                     */
/*-------------------------------------------------------*/
#include "bbs.h"
//#include "cache.c"
#define _BBS_UTIL_C_
#include "../lib/shm.c"
#include <math.h>
#define  PASSWD "/home/bbs/.PASSWDS"
#define fn_MARKET "/home/bbs/game/Market"
struct RCACHE *rc;
//userec cuser;

void
backup_Market()
{
  FILE *fp;
  int i;
  
  if (fp = fopen(fn_MARKET, "w")) {
         for(i=0;i<9;i++){
           fprintf(fp,"%f %f %d %d %d\n",rc->price[i][0],rc->price[i][1],
             rc->num[i][0],rc->num[i][1],rc->num[i][2]);
        }
        fclose(fp);
  } 
}

void
reset_Rcache(int x)
{
  if (rc == NULL)
  {
    rc = shm_new(RSHM_KEY, sizeof(*rc));
    if (rc->touchtime == 0)
      rc->touchtime = 1;
  }
  rc->busystate=1;
  adj_market();
  if(!x)backup_Market();
  rc->busystate=0;
  rc->uptime =0;
}

adj_market()
{
  float tmp;
  time_t now=time(NULL) - 6*60;     /* back to ancent */
  int i,numadd;
  struct tm *ptime;
  float market_number[9];
  float marketbase = 10.0;
  ptime = localtime(&now);
  rc->busystate=1;
  for (i = 0; i < 9; i ++){
    time(&now);
    srand(now+i*100000+i*i*i);
    tmp = (marketbase*rand()/(RAND_MAX+1.0));
    market_number[i]=(i+1) * tmp;
    if (((int)tmp)%2 == 1) 
      market_number[i] = 0 - market_number[i];
    printf("%d %f\n",((int)tmp)%2,
                     market_number[i]);
  }     
  for(i=0;i<9;i++){
    rc->price[i][0] =100;
    tmp = rc->price[i][0] + market_number[i];
/*    if(tmp > rc->price[i][1]/0.93)
     rc->price[i][0]=rc->price[i][1]/0.93;
    else if(tmp < rc->price[i][1]*0.93)
     rc->price[i][0]=rc->price[i][1]*0.93;
    else*/
     rc->price[i][0]=tmp;      /* SiE: ���^�ƭ���7% */

    numadd=100;
    //90*rc->num[i][2]-80*rc->num[i][0]+29*rc->num[i][1];
                                          /* SiE:�C���ջ����K���� */      
    if((rc->num[i][0]+numadd)<rc->num[i][2]*100)
         rc->num[i][0]+=numadd;
    else 
     rc->num[i][0]=(rc->num[i][2]+10)* 50 ;
    //rc->num[i][2]+=rc->num[i][2];
    if(rc->num[i][0]<0)
     rc->num[i][0]=0;
    if((ptime->tm_hour==19 || ptime->tm_hour == 9)
	&& ptime->tm_min < 30){
         rc->price[i][1]=rc->price[i][0];
         rc->num[i][1]=rc->num[i][2]=0;
    }  /* SiE: ���L�ɶ� */
  }/* skybinary:�k�s��*/
/*  for(i=0;i<9;i++){
    rc->price[i][0] =0;
    rc->price[i][1] =0;
  }*/
  rc->busystate=0;
  return 1;
}

int
main(int argc,char *argv[])
{
 int mode=0;
 if(argc>1)mode=atoi(argv[1]);
  reset_Rcache(mode);
}                                                     
