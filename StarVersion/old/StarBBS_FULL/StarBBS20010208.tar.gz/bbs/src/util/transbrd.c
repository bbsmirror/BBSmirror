/*-------------------------------------------------------*/
/* util/transbrd.c       ( FJU StarRiverBBS Ver 1.2 )    */
/*-------------------------------------------------------*/
/* target : BOARDS�ഫ(old -> new[�`��])                 */
/* create : 00/01/25                                     */
/* update : 00/01/25                                     */
/*-------------------------------------------------------*/

#include "bbs.h"

boardheader bh;

struct new
{
  char brdname[IDLEN + 1];      /* �ݪO�^��W��    13 bytes */
  char title[BTLEN + 1];        /* �ݪO����W��    49 bytes */
  char BM[IDLEN * 3 + 3];       /* �O�DID�M"/"     39 bytes */
  usint brdattr;                /* �ݪO���ݩ�       4 bytes */
  time_t bupdate;               /* note update time 4 bytes */
  uschar bvote;                 /* Vote flags       1 bytes */
  time_t vtime;                 /* Vote close time  4 bytes */
  usint level;                  /* �i�H�ݦ��O���v�� 4 bytes */
  unsigned long int totalvisit; /* �`���X�H��       8 bytes */
  unsigned long int totaltime;  /* �`���d�ɶ�       8 bytes */
  char lastvisit[IDLEN + 1];    /* �̫�ݸӪO���H  13 bytes */
  time_t opentime;              /* �}�O�ɶ�         4 bytes */
  time_t lastime;               /* �̫���X�ɶ�     4 bytes */
  char holiday[17];		/* �ݪO�`��        17 bytes */
  char descript[60];		/* �ݪO�ԭz        60 bytes */
  int port;                     /* �ݪO��port       4 bytes */
  int bid;			/* �ݪO�ۤv��id     4 bytes */
  int gid;			/* �ݪO���ݪ�group  4 bytes */
  char pad[8];
};

typedef struct new new;

main()
{
  int fdr,fdw, i = 0;
  new new;

  fdr=open(BBSHOME"/.BOARDS",O_RDONLY);
//  fdr=open(BBSHOME"/BOARDS.NEW1",O_RDONLY);
  fdw=open(BBSHOME"/BOARDS.NEW1",O_WRONLY | O_CREAT | O_TRUNC, 0644);

  while(read(fdr,&bh,sizeof(boardheader))==sizeof(boardheader))
  {
        i++;
        if(strlen(bh.brdname) == 0) continue;
        strncpy(new.brdname,bh.brdname,IDLEN+1);
        strncpy(new.title,bh.title,BTLEN + 1);
        strncpy(new.BM,bh.BM,24);
        new.brdattr = bh.brdattr;
        new.bupdate=bh.bupdate;
        new.bvote = bh.bvote;
        new.vtime=bh.vtime;
        new.level=bh.level;
        new.totalvisit=bh.totalvisit;
        new.totaltime=bh.totaltime;
        strncpy(new.lastvisit,bh.lastvisit,IDLEN+1);
        new.opentime=bh.opentime;
        new.lastime=bh.lastime;
        strncpy(new.holiday,"�ݪO�`��!",17);

        strncpy(new.descript,bh.descript,60);

        new.bid = i+1;
        new.gid = 0;
        new.port = 23;
        printf("
=====================================================
brd num   : %d
group num : %d
boardname : %s
title     : %s
totalvisit: %d
BM        : %s
holiday   : %s
descript  : %s
=====================================================\n"
,new.bid, new.gid, new.brdname, new.title, new.totalvisit, new.BM, 
new.holiday, new.descript);

        write(fdw,&new,sizeof(new));
   }
   close(fdr);
   close(fdw);
}
