/*-------------------------------------------------------*/
/* util/bbsmail.c       ( NTHU CS MapleBBS Ver 2.36 )    */
/*-------------------------------------------------------*/
/* target : �� Internet �H�H�� BBS �����ϥΪ�            */
/* create : 95/03/29                                     */
/* update : 95/12/15                                     */
/*-------------------------------------------------------*/

#include <stdio.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <fcntl.h>
#include <time.h>
#include <sysexits.h>

#include "bbs.h"
//#include "cache.c"
#include "../STAR/record.c"
#include "../lib/strip_ansi.c"
//#include "decode.ic"
#include "../lib/shm.c"
#include "../lib/rec_add.c"
#include "../lib/rec_apply.c"
#include "../lib/str_decode.c"
#define SPAM_

#ifdef SPAM_
  
/*
rexchen �s�i�H���v�{��
*/

#define SPAM_KEY     1225
#define RULE  3

struct SPAM
{
        int spam_a;
        int spam_b;
        int spam_c;
        int spam_times;
};

struct SPAM_MAIL
{
        struct SPAM mail_flag[512];
        time_t update_time;
};

struct  SPAM_MAIL     *spam;

#endif

#define LOG_FILE       "log/bbsmail.log"
#define STRCPY(dst, src) sprintf(dst, "%.*s", sizeof(dst)  - 1, src)

char userid[IDLEN + 1];

#ifdef  HAVE_MMAP
#include <sys/mman.h>
#else
int usernumber;
#endif

struct UCACHE *uidshm;

/*-------------------------------------------------------*/
/* .PASSWDS cache                                        */
/*-------------------------------------------------------*/


#ifndef HAVE_MMAP
static int
fillucache(uentp)
  userec *uentp;
{
  if (usernumber < MAXUSERS)
  {
    strncpy(uidshm->userid[usernumber], uentp->userid, IDLEN + 1);
    uidshm->userid[usernumber++][IDLEN] = '\0';
  }
  return 0;
}
#endif


/* -------------------------------------- */
/* (1) �t�αҰʫ�A�Ĥ@�� BBS user ��i�� */
/* (2) .PASSWDS ��s��                    */
/* -------------------------------------- */
reload_ucache()
{
   if (uidshm->busystate)
   {
     /* ------------------------------------------ */
     /* ��L user ���b flushing ucache ==> CSMA/CD */
     /* ------------------------------------------ */
     if (uidshm->touchtime - uidshm->uptime > 30)
     {
       uidshm->busystate = 0;  /* leave busy state */
       uidshm->uptime = uidshm->touchtime - 1;
#if !defined(_BBS_UTIL_C_)
       log_usies("CACHE", "refork token");
#endif
     }
     else
       sleep(1);
   }
   else
   {
     uidshm->busystate = 1;    /* enter busy state */
#ifdef  HAVE_MMAP
     {
       register int fd, usernumber;

       usernumber = 0;

       if ((fd = open(".PASSWDS", O_RDONLY)) > 0)
       {
         caddr_t fimage, mimage;
         struct stat stbuf;

         fstat(fd, &stbuf);
         fimage = mmap(NULL, stbuf.st_size, PROT_READ, MAP_SHARED, fd, 0);
         if (fimage == (char *) -1)
           exit(-1);
         close(fd);
         fd = stbuf.st_size / sizeof(userec);
         if (fd > MAXUSERS)
           fd = MAXUSERS;
         for (mimage = fimage; usernumber < fd; mimage += sizeof(userec))
         {
           memcpy(uidshm->userid[usernumber++], mimage, IDLEN);
         }
         munmap(fimage, stbuf.st_size);
       }
       uidshm->number = usernumber;
     }
#else
     usernumber = 0;
     rec_apply(".PASSWDS", fillucache, sizeof(userec));
     uidshm->number = usernumber;
#endif

     /* �� user ��Ƨ�s��A�]�w uptime */
     uidshm->uptime = uidshm->touchtime;

#if !defined(_BBS_UTIL_C_)
     log_usies("CACHE", "reload ucache");
#endif
     uidshm->busystate = 0;    /* leave busy state */
   }
}


void
resolve_ucache()
{
  if (uidshm == NULL)
  {
    uidshm = shm_new(UIDSHM_KEY, sizeof(*uidshm));
    if (uidshm->touchtime == 0)
      uidshm->touchtime = 1;
  }
  while (uidshm->uptime < uidshm->touchtime)
     reload_ucache();
}


int
ci_strcmp(s1, s2)
  register char *s1, *s2;
{
  register int c1, c2, diff;

  do
  {
    c1 = *s1++;
    c2 = *s2++;
    if (c1 >= 'A' && c1 <= 'Z')
      c1 |= 32;
    if (c2 >= 'A' && c2 <= 'Z')
      c2 |= 32;
    if (diff = c1 - c2)
      return (diff);
  } while (c1);
  return 0;
}


int
searchuser(userid)
  char *userid;
{
  register char *ptr;
  register int i, j;
  resolve_ucache();
  i = 0;
  j = uidshm->number;
  while (i < j)
  {
    ptr = uidshm->userid[i++];
    if (!ci_strcmp(ptr, userid))
    {
      strcpy(userid, ptr);
      return i;
    }
  }
  return 0;
}



int
belong_spam(filelist, key)
  char *filelist;
  char *key;
{
  FILE *fp;
  int rc = 0;

  if (fp = fopen(filelist, "r"))
  {
    char buf[STRLEN], *ptr;

    while (fgets(buf, STRLEN, fp))
    {
      if(buf[0] == '#') continue;
      if ((ptr = strtok(buf, " \t\n\r")) && strstr(key, ptr))
      {
        rc = 1;
        break;
      }
    }
    fclose(fp);
  }
  return rc;
}


#ifdef SPAM_
int
seek_mailflag(spam_a,spam_b,spam_c)
int spam_a;
int spam_b;
int spam_c;
{
  int i=0,j=0;
  if ( spam_a == 0 && spam_b == 0 && spam_c == 0 )
     return 0 ;
  for ( i = 0 ; i < 512 ; i++ )
  {
    if ( spam->mail_flag[i].spam_a == spam_a && spam->mail_flag[i].spam_b
 == spam_b && spam->mail_flag[i].spam_c == spam_c ) {
        if ( spam->mail_flag[i].spam_times < 3 ) {
           spam->mail_flag[i].spam_times++;
           return 0;
         } else {
           spam->mail_flag[i].spam_times++;
           return 1;
        }

    }
  }
  for ( i = 0 ; i < 512 ; i++ ) {
      if ( spam->mail_flag[i].spam_times == 0 ) {
         spam->mail_flag[i].spam_a = spam_a;
         spam->mail_flag[i].spam_b = spam_b;
         spam->mail_flag[i].spam_c = spam_c;
         spam->mail_flag[i].spam_times = 1 ;
         j = 1;
         break;
      }
  }
  if ( j != 1 ) {
    for ( i = 0 ; i < 512 ; i++ ) {
        if ( spam->mail_flag[i].spam_times <= 3 ) {
            spam->mail_flag[i].spam_times = 0 ;
            spam->mail_flag[i].spam_a = 0 ;
            spam->mail_flag[i].spam_b = 0 ;
            spam->mail_flag[i].spam_c = 0 ;
        }
    }
  }
  return 0;
}
#endif


mailog(char* mode, char* msg)
{
   FILE *fp;

   if (fp = fopen(LOG_FILE, "a")) {
      time_t now;
      struct tm *p;

      time(&now);
      p = localtime(&now);
      fprintf(fp, "%02d/%02d/%02d %02d:%02d:%02d <%s> %s\n",
         p->tm_year, p->tm_mon + 1, p->tm_mday, p->tm_hour, p->tm_min,
         p->tm_sec, mode, msg);
      fclose(fp);
   }
}

dashd(char *fname)
{
   struct stat st;

   return (stat(fname, &st) == 0 && S_ISDIR(st.st_mode));
}


junk(char* reason)
{
   FILE* fp;
   int i;
   char msgbuf[256];

   sprintf(msgbuf, "<%s> %.100s", userid, reason);
   mailog("bbsmail", msgbuf);
   if (fp = popen("bin/bbspost junk", "w")) {
      while (fgets(msgbuf, sizeof(msgbuf), stdin))
        fputs(msgbuf, fp);
      pclose(fp);
   }
   return 0;
}

int
mail2bbs()
{
   fileheader mymail;
   char genbuf[2000], title[256], sender[256], *ip, *ptr;
   char fname[200], fnamepgp[200], pgppath[200];
   char firstline[100];
   struct stat st;
   time_t tmp_time;
   FILE *fout, *fpgp;
   int pgp = 0;

#ifdef SPAM_
/*
rexchen �s�i�H���v�{��
*/
   int spam_a=0,spam_b=0,spam_c=0;
#endif
   /* check if the userid is in our bbs now */
   if (!searchuser(userid))
      return junk("not exist");

   sprintf(genbuf, "home/%c/%s", userid[0], userid);

   if (stat(genbuf, &st) == -1) {
      if (mkdir(genbuf, 0755) == -1)
         return junk("no mail box");
   }
   else if (!(st.st_mode & S_IFDIR))
      return junk("mail box error");

   /* allocate a file for the new mail */

   stampfile(genbuf, &mymail);

   /* copy the stdin to the specified file */

   if ((fout = fopen(genbuf, "w")) == NULL)
      return junk("can't open stamp file");

   sprintf(fnamepgp, "%s.pgp", strcpy(fname, genbuf));
   sprintf(pgppath, "home/%c/%s/pgp", userid[0], userid);

   /* parse header */

   title[0] = sender[0] = 0;

   if (ip = getenv("SENDER"))
      STRCPY(sender, ip);
   while (fgets(genbuf, sizeof(genbuf), stdin)) {
      if (!*sender && !strncasecmp(genbuf, "From", 4)) {
         if ((ip = strchr(genbuf, '<')) && (ptr = strrchr(ip, '>'))) {
            if (ip > genbuf && ip[-1] == ' ')
               ip[-1] = 0;
            ++ip;
            *ptr = 0;
            ptr = strchr(genbuf, ' ');
            while (*++ptr == ' ')
               ;
	    str_decode(ptr);
            sprintf(sender, "%s (%s)", ip, ptr);
         }
         else {
            strtok(genbuf, " \t\n\r");
            if (ip = strtok(0, " \t\n\r"))
               STRCPY(sender, ip);
            else
               STRCPY(sender, genbuf);
         }
         continue;
      }
      if (!memcmp(genbuf, "Subject: ", 9)) {
         strip_ansi(title, genbuf + 9,STRIP_ALL);
         str_decode(title);
         continue;
      }
      if (genbuf[0] == '\n')
         break;
   }

   time(&tmp_time);
   if (fgets(genbuf, sizeof(genbuf), stdin))
      STRCPY(firstline, genbuf);
   if (!title[0])
     sprintf(title, "�Ӧ� %.64s", sender);

   fprintf(fout, "�@��: %s\n���D: %s\n�ɶ�: %s\n",
      sender, title, ctime(&tmp_time));


#if 0
   if (strstr(genbuf, "BEGIN PGP MESSAGE")
       && dashd(pgppath)
       && (fpgp = fopen(fnamepgp, "w"))) {
      fputs(genbuf, fpgp);
      while (fgets(genbuf, sizeof(genbuf), stdin))
        fputs(genbuf, fpgp);
      fclose(fpgp);
      fclose(fout);
      sprintf(genbuf, "PGPPATH=%s;PGPPASSFD=0;export PGPPATH PGPPASSFD;\
 echo `cat home/%c/%s/pgp.phrase` | /usr/local/bin/pgp +batchmode -o- %s >> %s",
         pgppath, userid[0], userid, fnamepgp, fname);
      system(genbuf);
      unlink(fnamepgp);
      pgp = 1;
      mymail.filemode |= FILE_MARKED;
   }
   else {
#endif
      fputs(genbuf, fout);
      while (fgets(genbuf, sizeof(genbuf), stdin) != NULL)
      { 
        fputs(genbuf, fout);
#ifdef SPAM_
// rexchen �s�i�H���v�{��
        if(spam_b < 250);
        {
          spam_b++;      
          spam_a = spam_a + genbuf[strlen(genbuf)/(spam_b%RULE + 1)];
                                                /* �쥻�S�[ 1�A�|��bugs */
          spam_c = spam_c + genbuf[strlen(genbuf)/RULE];
        }
#endif
      }
      fclose(fout);
/*
   }
*/
#ifdef SPAM_
   if (seek_mailflag(spam_a,spam_b,spam_c) == 1) {
      unlink(fname);
      sprintf(genbuf,"SPAM: %x %x %x => %s => %s",
              spam_a,spam_b,spam_c,sender,userid);
      mailog("bbsmail", genbuf);
      return 0;
   }
#endif

/*==== wildcat : anti-spam from etc/spam-list =====*/
/* JoeHorn : etc/spam-list�ݩ�ݪO��, ���etc/mailspam  */

   if(belong_spam(BBSHOME"/etc/mailspam",sender))
   {
     unlink(fname);
     sprintf(genbuf,"SPAM: %s => %s",sender,userid);
     mailog("bbsmail", genbuf);
     return 0;
   }
       
   sprintf(genbuf, "%s => %s%s", sender, userid, pgp ? " [PGP]" : "");
   mailog("bbsmail", genbuf);

   /* append the record to the MAIL control file */

   strncpy(mymail.title, title, 72);

   if (strtok(sender, " .@\t\n\r"))
     strcat(sender, ".");
   sender[IDLEN] = '\0';
   strcpy(mymail.owner, sender);
   sprintf(genbuf, "home/%c/%s/.DIR", userid[0], userid);
   return rec_add(genbuf, &mymail, sizeof(mymail));
}


main(int argc, char** argv)
{
   if (argc < 2) {
      printf("Usage:\t%s <bbs_uid>\n", argv[0]);
      exit(-1);
   }
#ifdef SPAM_
/*
rexchen �s�i�H���v�{��
*/
   spam = (void *)shm_new(SPAM_KEY,  sizeof(*spam));
#endif
   setgid(BBSGID);
   setuid(BBSUID);
   chdir(BBSHOME);
   STRCPY(userid, argv[1]);

   return mail2bbs();
}
