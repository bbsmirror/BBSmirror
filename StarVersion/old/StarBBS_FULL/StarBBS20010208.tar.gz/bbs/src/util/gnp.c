#include <sys/param.h>
#include "bbs.h"


#define  PASSWD "/home/bbs/.PASSWDS"
#define  OUT "/home/bbs/m2/7"

int coun=0,count=0;
userec cuser;

char *
Cdate(clock)
  time_t *clock;
{
  static char foo[22];
  struct tm *mytm = localtime(clock);

  strftime(foo, 22, "%D %T %a", mytm);
  return (foo);
}



int
bad_user_id()
{
  register char ch;
  int j;

  if (strlen(cuser.userid) < 2 || !isalpha(cuser.userid[0]))
    return 1;

  if (cuser.numlogins==0 || cuser.numlogins>50000)
    return 1;

  if (cuser.numposts>50000)
    return 1;

  for(j=1;ch = cuser.userid[j];j++)
  {
    if (!isalnum(ch))
      return 1;
  }
  return 0;
}

main()
{
  FILE *fp1=fopen(PASSWD,"r");
  FILE *fp2=fopen(OUT,"w");
  unsigned long total=0;
  float gnp,tgnp=0;
  time_t now = time(0);
  int days=0;
  while( (fread( &cuser, sizeof(cuser), 1, fp1))>0 )
  {
   count ++;
   if(bad_user_id())
   {
    printf("<%d> userid  :%s  money  :%d\n",
            count,cuser.userid,cuser.money+cuser.deposit);
   }
   else
   {
      coun ++;
      total+=(cuser.money+cuser.deposit);
      days+=cuser.numlogins;
      gnp= (cuser.money+cuser.deposit)/cuser.numlogins;
      tgnp+=gnp;
   }
  }
 fclose(fp1);
 fprintf(fp2,"[1m---[[32m%s[37m]-----[m\n",Cdate(&now));
 fprintf(fp2,"[1;33m�����H���`�]�� : [1m%11ld [m��\n",total);
 fprintf(fp2,"[1;36m�����ثe�`�H�f : [1m%11d[m �H\n",coun);
 fprintf(fp2,"[1;32m�����H���]��   : [1m%11d[m ��\n", total/coun);
 fprintf(fp2,"[1;37m����Ͳ����B   : [1m%11f[m ��\n", tgnp/days);
 fprintf(fp2,"[1m-------------------------------[m\n");
 fclose(fp2);
}
