#include "bbs.h"

main(argc, argv)
  int argc;
  char **argv;
{
   FILE *fp,*fp1;
   int no = 0;
   char *source, *target, *key, path[256];

   if(argc != 4)
   {
    printf("Usage:\t%s <source_board> <target_board> fliter_keyword\n",
     argv[0]);
    exit(-1);
   }

   source = argv[1];
   target = argv[2];
   key = argv[3];

   sprintf(path,"/home/bbs/boards/%s/.DIR",source);

   if (fp = fopen(path, "r")) {
      fileheader fhdr;
      int n = 0;
      char type;

      while (fread(&fhdr, sizeof(fhdr), 1, fp) == 1) {
         fhdr.title[50] = 0;
         type = "+ Mm"[fhdr.filemode];
         if (fhdr.filemode & FILE_TAGED)
            type = 'D';

      if(strstr(fhdr.title ,key) != NULL)
      {
/*     sprintf(buf,"cp /home/bbs/boards/%s/%s /home/bbs/boards/%s",
        source, fhdr.filename, target);
       system(buf);*/
       fp1 = fopen("/home/bbs/tmp/out.bntp.tmp","a");
       fprintf(fp1,"%s\t%s\t%-14s\t%s\t%s\n",target, fhdr.filename,
         fhdr.owner, fhdr.owner, fhdr.title);
       fclose(fp1); 
       no++;
      }
/*
         printf("%3d %c %13s %-5s %-12s %-41.40s\n",
          ++n, type, fhdr.filename, fhdr.date, fhdr.owner, fhdr.title);
*/
      }
      fclose(fp);
/*
    sprintf(buf,"/home/bbs/src/util/buildir /home/bbs/boards/%s",target);
    system(buf);*/
printf("%d\n",no);
   }
   else
      fprintf(stderr, "`.DIR` opened error (for read)\n");

}
