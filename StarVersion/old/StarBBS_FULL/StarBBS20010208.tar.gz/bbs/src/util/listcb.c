/*-------------------------------------------------------*/
/* util/listcb.c       ( FJU StarRiver BBS Ver 2.02 )    */
/*-------------------------------------------------------*/
/* target : �P���user.c list_CB���\��                   */
/* create : 00/06/22                                     */
/* update : 00/06/22                                     */
/*-------------------------------------------------------*/

#include "bbs.h"

#define PERM_BM           000000002000
#define PERM_CLOAK        000000000100
#define PERM_SYSOP        000000040000
#define PERM_PURPLE       000040000000
#define HAS_PERM(x)     ((x)?cuser.userlevel&(x):1)
#define HAVE_PERM(x)    (cuser.userlevel&(x))

userec cuser;

char *
Cdate(clock)
  time_t *clock;
{
  static char foo[22];
  struct tm *mytm = localtime(clock);
  strftime(foo, 22, "%D %T %a", mytm);
  return (foo);
}

void
check_perm(int perm,char *filename,char *title)
{
 FILE *fp,*pass = fopen("/home/bbs/.PASSWDS","r");
 char buf[200];
 int no = 0;

 sprintf(buf,"/home/bbs/etc/userlist/%s",filename);
 fp = fopen(buf,"w");
 fprintf(fp,"�H�U�O ���� %s ���C��\n",title);
 while((fread(&cuser, sizeof(cuser), 1, pass))>0)
 {
  if(perm)
  {
   if(HAVE_PERM(perm))
   {
    no++;
    fprintf(fp,"%4d. %-13.13s %5.5d  %5.5d %-24.24s \n",
     no, cuser.userid, cuser.numlogins, cuser.numposts,
     cuser.lasthost);
   }
  }
  else
  {
    no++;
    fprintf(fp,"%4d. %-13.13s %5.5d  %5.5d %-24.24s \n",
     no, cuser.userid, cuser.numlogins, cuser.numposts,
     cuser.lasthost);
  }
 }
 fclose(pass);
 fclose(fp);
}

main(argc, argv)
   int argc;
   char **argv;
{
  if (argc < 2)
  {
    printf("Usage: %s <listfunc> <out-file>\n", argv[0]);
    printf("listfunc:\n");
    printf("  1.All Users\n");
    printf("  2.Board Managers\n");
    printf("  3.Users who can cloak\n");
    printf("  4.Users who can purple cloak\n");
    printf("  5.SYSOPs\n");
    exit(1);
  }

  switch (argv[1][0])
  {
   case '1':
    check_perm(0, "list.user","���W�ϥΪ�");
    break;
   case '2':
    check_perm(PERM_BM, "list.bm","�O�D");
    break;
   case '3':
    check_perm(PERM_CLOAK, "list.cloak","�������v");
    break;
   case '4':
    check_perm(PERM_PURPLE, "list.pr","�������v");
    break;
   case '5':
    check_perm(PERM_SYSOP, "list.admin","�������v");
    break;
  } 
}
