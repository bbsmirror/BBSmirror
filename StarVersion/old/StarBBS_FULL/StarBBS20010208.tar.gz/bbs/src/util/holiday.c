/*-------------------------------------------------------*/
/* util/camera.c        ( NTHU CS MapleBBS Ver 3.00 )    */
/*-------------------------------------------------------*/
/* target : �إ� [�Ҧ��`��] cache                        */
/* create : 95/03/29                                     */
/* update : 97/03/29                                     */
/*-------------------------------------------------------*/
// patch  : skybinary.bbs@starriver.twbbs.org
// update : 00/05/01

#include "bbs.h"

#include "../lib/shm.c"

boardheader bh;
fileheader fh;

static feast f2;
static feast f3[MAXBOARD];

main()
{
 FILE *fp,*fp1;
 int mo,da,i=0;
 char buf[20],*chr;

 feast *fshm2;

 time_t now = time(NULL);
 struct tm *ptime = localtime(&now);

  setgid(BBSGID);
  setuid(BBSUID);
  chdir(BBSHOME);

 if (fp = fopen("/home/bbs/etc/feast", "r"))
  {
    while(fscanf(fp,"%d %d %s\n",&mo,&da,buf) != EOF)
    {
      if((ptime->tm_mday == da) && (ptime->tm_mon + 1 == mo))
      {
       i=1;
       fp1 = fopen("/home/bbs/etc/today_is2","w");
       fprintf(fp1,"%-16.16s",buf);
       fclose(fp1);
      }
    }
    if(i==0)
    {
     fp1 = fopen("/home/bbs/etc/today_is2","w");
     if(fp = fopen("/home/bbs/etc/today_boring","r"))
     {
      while (fgets(buf,250,fp))
      {
       if(strlen(buf)>3)
       {
        buf[strlen(buf)-1]=0;
        fprintf(fp1,"%-16s\n",buf);
       }
      }
      fclose(fp);
     }
     else
      fprintf(fp1,"����`��x�D��");
     fclose(fp1);
    }
   fclose(fp);
 }

  fp=fopen("etc/today_is","r");
  if(fp)
  {
   fgets(f2.today_is,17,fp);
   if(chr=strchr(f2.today_is,'\n')) *chr=0;
   f2.today_is[17]=0;
  }
   fclose(fp);


  /* --------------------------------------------------- */
  /* resolve shared memory                               */
  /* --------------------------------------------------- */

  fshm2 = (feast *) shm_new(FSHM_KEY3, sizeof(feast));
  memcpy(fshm2, &f2, sizeof(f2));

// printf("%s",fshm2->today_is);
 exit(0);
}
