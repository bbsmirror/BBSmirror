#include "bbs.h"
#include "pip.h"

main()
{
userec test;
boardheader test2;
user_info test3;
chicken test4;
printf("the size of userec is : %d bytes \n",sizeof(test));
printf("the size of user_info : %d bytes \n",sizeof(test3));
printf("the size of pip    is : %d bytes \n",sizeof(test4));
printf("the size of int    is : %d bytes \n",sizeof(int));
printf("the size of char   is : %d bytes \n",sizeof(char));
printf("the size of long   is : %d bytes \n",sizeof(long));
printf("the size of usint  is : %d bytes \n",sizeof(usint));
printf("the size of ushort is : %d bytes \n",sizeof(ushort));
printf("the size of uschar is : %d bytes \n",sizeof(uschar));
printf("the size of time_t is : %d bytes \n",sizeof(time_t));

printf("the size of boardh is : %d bytes \n",sizeof(test2));

printf("the size of unsigned long int is : %d bytes \n",sizeof(unsigned long int));

}
