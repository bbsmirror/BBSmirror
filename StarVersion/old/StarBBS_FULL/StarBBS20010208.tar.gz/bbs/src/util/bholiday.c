/*-------------------------------------------------------*/
/* util/camera.c        ( NTHU CS MapleBBS Ver 3.00 )    */
/*-------------------------------------------------------*/
/* target : �إ� [�Ҧ��`��] cache                        */
/* create : 95/03/29                                     */
/* update : 97/03/29                                     */
/*-------------------------------------------------------*/
// patch  : skybinary.bbs@starriver.twbbs.org
// update : 00/05/01

#include "bbs.h"

boardheader bh,new;

main()
{
 FILE *fp;
 int mo,da,i=0,k;
 char buf[256],buf1[20];
 int fdr,fdw;
 char feast[16];

 time_t now = time(NULL);
 struct tm *ptime = localtime(&now);

 k=0;

  fdr=open("/home/bbs/.BOARDS",O_RDONLY);
  fdw=open("/home/bbs/BOARDS.NEW",O_WRONLY | O_CREAT | O_TRUNC, 0644);

  while(read(fdr,&bh,sizeof(boardheader))==sizeof(boardheader))
  {
   i=0;
   k++;
        if(strlen(bh.brdname) == 0) continue;
        memcpy(new.brdname,bh.brdname,IDLEN+1);
        memcpy(new.title,bh.title,BTLEN + 1);
        memcpy(new.BM,bh.BM,24);
        new.brdattr = bh.brdattr;
        new.bupdate=bh.bupdate;
        new.bvote = bh.bvote;
        new.vtime=bh.vtime;
        new.level=bh.level;
        new.totalvisit=bh.totalvisit;
        new.totaltime=bh.totaltime;
        memcpy(new.lastvisit,bh.lastvisit,IDLEN+1);
        new.opentime=bh.opentime;
        new.lastime=bh.lastime;
//�ݪO�`��B�z
  sprintf(buf,"/home/bbs/boards/%s/feast",bh.brdname);
  if ((fp = fopen(buf, "r")) == NULL)
  {
    i=1;
    strcpy(feast,"�O�D�нs��`����");
  }
//�ܮe������bug...
  if (fp = fopen(buf, "r"))
  {
//   printf("%s\n",bh.brdname);
    while(fscanf(fp,"%d %d %s\n",&mo,&da,buf1) != EOF)
    {
      if((ptime->tm_mday == da) && (ptime->tm_mon + 1 == mo))
      {
       i=1;
       strcpy(feast,buf1);
      }
    }
    if(i==0)
      strcpy(feast,"����`��x�D��");
   fclose(fp);
   }

        memcpy(new.holiday,feast,17);
        memcpy(new.descript, bh.descript,60);
        new.port = bh.port;
        new.bid = bh.bid;
        new.gid = bh.gid;
        write(fdw,&new,sizeof(boardheader));
   }
   close(fdr);
   close(fdw);

 sprintf(buf,"cp /home/bbs/BOARDS.NEW /home/bbs/.BOARDS");
 system(buf);


 exit(0);
}
