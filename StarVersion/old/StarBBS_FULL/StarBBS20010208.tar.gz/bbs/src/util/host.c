/*-------------------------------------------------------*/
/* util/host.c          ( FJU StarRiver BBS Ver 2.03 )   */
/*-------------------------------------------------------*/
/* target : �إ� [�G�m] cache                            */
/* create : 00/07/01                                     */
/* update : 00/07/01                                     */
/*-------------------------------------------------------*/
// author : skybinary.bbs@starriver.twbbs.org

#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <strings.h>


#include "bbs.h"
#include "../lib/shm.c"
#include "../lib/str_rle.c"
#include "../lib/rec_get.c"
#include "../lib/setpf.c"

#include "record.c"

struct FROMCACHE
{
  char domain[MAX_FROM][50];
  char replace[MAX_FROM][50];
  int top;
  int max_user;
  time_t max_time;
  time_t uptime;
  time_t touchtime;
};


main()
{
  int i, fd, size,num,id;
  char fpath[256], buf[FILM_SIZ + 1],pbuf[256],dbuf[256];

  struct FROMCACHE *fcache;
  int fcache_semid;

  /* --------------------------------------------------- */
  /* resolve shared memory                               */
  /* --------------------------------------------------- */

  fshm = (FCACHE *) shm_new(FILMSHM_KEY, sizeof(FCACHE));
  memcpy(fshm, &image, sizeof(image.shot) + tail);
                       /* Thor.980805: �A�[�W shot������ */
  image.shot[0] = fshm->shot[0] = id;   /* �`�@���X�� ? */

  if (fp = fopen("log/camera.log", "a"))
  {
    fprintf(fp, "%d/%d films, %d/%d bytes\n", i, MOVIE_MAX, tail, MOVIE_SIZE);
    fclose(fp);
  }

    exit(0);
}
