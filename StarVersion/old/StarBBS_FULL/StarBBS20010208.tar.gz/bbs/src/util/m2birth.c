/*     �جP�{��               96 10/11            */
/*     the program is designed by Ptt             */
/*     you can emailto://b3504102@csie.ntu.edu.tw */
/*     Ptt BBS telnet://ptt.m8.ntu.edu.tw         */

#include <stdio.h>
#include "bbs.h"

#define DOTPASSWDS "/home/bbs/.PASSWDS"
#define OUTFILE    "/home/bbs/m2/9"

struct userec cuser;

main(argc, argv)
int argc;
char **argv;
{
    FILE *fp1;
    char today[50][14],today_name[50][24];
    int i,day=0,mon=0,wee=0,a[50],b[50];
    time_t now;
    struct tm *ptime;

    now = time(NULL) ;     /* back to ancent */
    ptime = localtime(&now);

     fp1=fopen(DOTPASSWDS, "r");

    while( (fread( &cuser, sizeof(cuser), 1, fp1))>0 ) {
           if(cuser.month == ptime->tm_mon +1 )
             {
             if(cuser.day == ptime->tm_mday)
               {
                a[day]=cuser.numlogins;
                b[day]=cuser.numposts;
                strcpy(today[day  ],cuser.userid);
                strcpy(today_name[day++],cuser.username);
               }/*
             else if(cuser.day <= ptime->tm_mday+7 && cuser.day >=
                 ptime->tm_mday-7)
               {
                 week_day[wee] = cuser.day;
                 strcpy(week[wee++],cuser.userid);
               }
             else
               {
                 month_day[mon] = cuser.day;
                 strcpy(month[mon++],cuser.userid);
               }*/
             }
      }
    fclose(fp1);

    fp1=fopen(OUTFILE,"w");

/*    fprintf(fp1,"\n             "
"[1m[34m���w�w�w�w�w�w�w�w��[33;41m  �جP�C��  [40;34m���w�w�w�w�w�w�w�w��[m\n");
*/
    fprintf(fp1,"�U���O���Ѫ��جP\n");
    if((day>0)&&(day<16))
    {
//     fprintf(fp1,"[1m[31m�i[33m����جP[40;31m�j[m \n");
     for (i=0;i<day/2;i++)
        {
	 
         fprintf(fp1," [1m[33m %-14s [0m",today[i]);
          if(!((i+1)%2)) fprintf(fp1,"\n");
         
        }
    }
     fprintf(fp1,"\n");
/*
    if(week>0)
    {
     fprintf(fp1,"\n\n[1;33m�i[44m�e��@�g���جP[40;33m�j[m \n");
     for (i=0;i<wee;i++)
        {
          fprintf(fp1,"   [%2d/%-2d] [1;36m%-14s[m"
                  ,ptime->tm_mon+1,week_day[i],week[i]);
          if(!((i+1)%3)) fprintf(fp1,"\n");
        }
    }

    fprintf(fp1,"\n\n[1;33m�i[44m����جP[40;33m�j[m \n");
    for (i=0;i<mon;i++)
        {
          fprintf(fp1,"   [%2d/%-2d] %-14s"
                  ,ptime->tm_mon+1,month_day[i],month[i]);
          if(!((i+1)%3)) fprintf(fp1,"\n");
        }
*/
    fclose(fp1);
    return 0;
}
