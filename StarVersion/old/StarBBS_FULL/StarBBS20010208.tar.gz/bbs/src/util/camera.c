/*-------------------------------------------------------*/
/* util/camera.c	( NTHU CS MapleBBS Ver 3.00 )	 */
/*-------------------------------------------------------*/
/* target : �إ� [�ʺA�ݪO] cache			 */
/* create : 95/03/29				 	 */
/* update : 97/03/29				 	 */
/*-------------------------------------------------------*/
// patch  : skybinary.bbs@starriver.twbbs.org
// update : 00/04/26

#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <strings.h>

#include "bbs.h"
#include "../lib/shm.c"
#include "../lib/str_rle.c"
#include "../lib/rec_get.c"
#include "../lib/setpf.c"
#include "../STAR/record.c"

#define MAX_LINE    12

static FCACHE image;
static int number =0;
static int tail =0;

static void
mirror(fpath)
  char *fpath;
{
  int fd, size;
  char *ptr;

  fd = open(fpath, O_RDONLY);
  if (fd >= 0)
  {
    ptr = image.film + tail;
    size = read(fd, ptr, FILM_SIZ);
    close(fd);

    if (size <= 0)
      return;

    ptr[size] = '\0';
    size = str_rle(ptr);

    if (size > 0 && size < FILM_SIZ)
    {
      ptr[size++] = '\0';
      image.shot[++number] = (tail += size);
    }
  }
}


static int
play(data)
  char *data;
{
  int line, ch;
  char *head;

  if (++number > MOVIE_MAX)
    return 1;

  /* str_rle(data); */
  /* Thor.980804: ���⧹�̫�A�����Y, ���M���Y�X�]�Q���@����Φ�Ƥ����F */

  head = data;
  line = 0;
  while (ch = *data)		/* at most 10 lines */
  {
    data++;
    if (ch == '\n')
    {
      if (++line >= MAX_LINE)
	break;
    }
  }

  *data++ = 27;
  *data++ = '[';
  *data++ = 'm';

  while (line < MAX_LINE)	/* at lease 10 lines */
  {
    *data++ = '\n';
    line++;
  }

  *data = '\0';
  
  /* *data++ = '\0';*/      /* mark for end of movie */
    
  /* ch = data - head; */       /* length */
      
  ch = str_rle(head) + 1; /* Thor.980804: +1 �N������0�]��J */
         
  line = tail + ch;
  if (line >= MOVIE_SIZE)
    return 1;			/* overflow */

  data = image.film + tail;
  memcpy(data, head, ch);
  image.shot[number] = tail = line;
  return 0;
}


main()
{
  int i, fd, size,num,id;
  char fpath[256], buf[FILM_SIZ + 1],pbuf[256],dbuf[256];
  FCACHE *fshm;
  FILE *fp;
  fileheader hdr;

 FILE *fp1;
 int mo,da,j=0;


 time_t now = time(NULL);
 struct tm *ptime = localtime(&now);


  /* --------------------------------------------------- */
  /* mirror pictures					 */
  /* --------------------------------------------------- */

  id=0;
  setgid(BBSGID);
  setuid(BBSUID);
  chdir(BBSHOME);

  // ��mirror��U�ӦAprint
  mirror("etc/help/announce.hlp");
  mirror("etc/help/mail.hlp");
  mirror("etc/help/read.hlp");
  mirror("etc/help/board.hlp");
  mirror("etc/help/more.hlp");
  mirror("etc/help/ve.hlp");
  mirror("etc/help/talk_user.hlp");
  mirror("etc/help/talk_page.hlp");
  mirror("etc/help/talk_sysop.hlp");
  mirror("etc/Welcome");
  mirror("etc/line");
  mirror("etc/Welcome_login");
  mirror("m2/1");
  mirror("m2/2");
  mirror("m2/3");
  mirror("m2/4");
  mirror("m2/5");
  mirror("m2/6");
  mirror("m2/7");
  mirror("m2/8");
  mirror("m2/9");
  mirror("m2/10");
  mirror("etc/Welcome_birth");
  mirror("etc/register");
  mirror("etc/post.note");
  /* --------------------------------------------------- */
  /* visit all films					 */
  /* --------------------------------------------------- */

   setapath(pbuf, "Note");
   setadir(dbuf, pbuf);
   num = get_num_records(dbuf, sizeof hdr);

   for (i = 0; i <= num; i++)
    if (rec_get(dbuf, &hdr, sizeof hdr, i) != -1)
     if (hdr.title[3]=='<' && hdr.title[8]=='>')
      {
       char path[256],buf1[256];
       int num1,k;
       fileheader subitem;

       setapath(path,"Note");
       sprintf(buf1,"%s/%s",path,hdr.filename);
       setadir(path, buf1);
       num1 = get_num_records(path, sizeof hdr);

       for (k = 0; k <= num1; k++)
       {
        if (rec_get(path, &subitem, sizeof hdr, k) != -1)
         {
          sprintf(fpath,"man/boards/Note/%s/%s",
  	   hdr.filename, subitem.filename);
          id++;
          if(id >= MOVIE_MAX) break;

          if ((fd = open(fpath, O_RDONLY)) >= 0)
          { //Ū�ɥ�
           size = read(fd, buf, FILM_SIZ);
           close(fd);

           if (size >= FILM_SIZ || size <= 0)
            continue;

           buf[size] = '\0';
           if (play(buf)) //overflow
            break;
          }
         }
    }
  }


 if (fp = fopen("/home/bbs/etc/feast", "r"))
 {
    while(fscanf(fp,"%d %d %s\n",&mo,&da,buf) != EOF)
    {
      if((ptime->tm_mday == da) && (ptime->tm_mon + 1 == mo))
      {
       j=1;
       fp1 = fopen("/home/bbs/etc/today_is","w");
       fprintf(fp1,"%-16.16s",buf);
       fclose(fp1);
      }
    }
    if(j==0)
    {
     fp1 = fopen("/home/bbs/etc/today_is","w");
     if(fp = fopen("/home/bbs/etc/today_boring","r"))
     {
      while (fgets(buf,250,fp))
      {
       if(strlen(buf)>3)
       {
        buf[strlen(buf)-1]=0;
        fprintf(fp1,"%-16s\n",buf);
       }
      }
      fclose(fp);
     }
     else
      fprintf(fp1,"����`��x�D��");
     fclose(fp1);
    }
   fclose(fp);
 }


  i = number;	/* �`�@���X�� ? */
  i=id;
  /* --------------------------------------------------- */
  /* resolve shared memory				 */
  /* --------------------------------------------------- */

  fshm = (FCACHE *) shm_new(FILMSHM_KEY, sizeof(FCACHE));
  memcpy(fshm, &image, sizeof(image.shot) + tail);
                       /* Thor.980805: �A�[�W shot������ */
  image.shot[0] = fshm->shot[0] = id;	/* �`�@���X�� ? */

#if 0
  fd = open("run/camera.img", O_WRONLY | O_CREAT | O_TRUNC, 0600);
  if (fd >= 0)
  {
    write(fd, &image, tail);
    close(fd);
  }
#endif

  if (fp = fopen("log/camera.log", "a"))
  {
    fprintf(fp, "%d/%d films, %d/%d bytes\n", i, MOVIE_MAX, tail, MOVIE_SIZE);
    fclose(fp);
  }

  exit(0);
}
