/*-------------------------------------------------------*/
/* util/water.c           ( FJU StarRiverBBS Ver 1.94 )  */
/*-------------------------------------------------------*/
/* target : �ϥΪ� �᱾ �Ʀ�]                           */
/* create : 00/05/06                                     */
/* update : 00/05/28                                     */
/* author : skybinary.bbs@starriver.twbbs.org            */
/*-------------------------------------------------------*/


#include "bbs.h"

struct water{
char bewaterid[15]; //�Q��
int bewater;
char waterid[15]; //��H��
int water;
}water;

struct water log[500],log2[300];

main()
{
 FILE *fp;
 char id1[20],id2[20],id[20];
 int i,j,no=0,no2=0,no3=0,tmp;
 char buf1[50],buf2[50];

 fp = fopen("/home/bbs/log/water.log","r");
 while(fscanf(fp,"%s %s\n",&buf1,&buf2) != EOF)
 {
  for(i=0;i<14;i++)
   id1[i] = buf1[2+i];

  for(j=0;j<14;j++)
   id2[j] = buf2[2+j];

  no++;//�������Ӽ�.

  strncpy(log[no2].bewaterid,id1,14);
  log[no2].bewater=1;
  no2++;
  strncpy(log[no3].waterid,id2,14);
  log[no3].water=1;
  no3++;
 }
 fclose(fp);

 i=0; j=0;

 for(i=0;i<no;i++)
 {
  if(log[i].bewater != 0)
  {
   for(j=0;j<no;j++)
   {
    if( i != j)
    {
     if(!strcmp(log[i].bewaterid, log[j].bewaterid) )
     {
      log[i].bewater++;
      log[j].bewater = 0;
     }
    }
   }
  }
  if(log[i].water != 0)
  {
   for(j=0;j<no;j++)
   {
    if(i != j)
    {
     if(!strcmp(log[i].waterid, log[j].waterid) )
     {
      log[i].water++;
      log[j].water = 0;
     }
    }
   }
  }
 }

 i=0;j=0;no2=0;no3=0;

 for(i=0;i<no;i++)
 {
  if(log[i].water != 0)
  {
   strcpy(log2[no2].waterid, log[i].waterid);
   log2[no2].water = log[i].water;
   no2++;
  }
  if(log[i].bewater != 0)
  {
   strcpy(log2[no3].bewaterid, log[i].bewaterid);
   log2[no3].bewater = log[i].bewater;
   no3++;
  }
 }
/*
 for(i=0;i<no2;i++)
  printf("%-14s %3d | %-14s %3d\n",
   log[i].bewaterid,log[i].bewater,
    log[i].waterid,log[i].water);
*/

  for(i=0;i<no2;i++)
  {
   for(j=0;j<no2-1-i;j++)
   {
    if(log2[j].water < log2[j+1].water)
    {
     tmp = log2[j].water;
     strcpy(id,log2[j].waterid);
     log2[j].water = log2[j+1].water;
     strcpy(log2[j].waterid, log2[j+1].waterid);
     log2[j+1].water =tmp;
     strcpy(log2[j+1].waterid, id);
    }
   }
  }

  for(i=0;i<no3;i++)
  {
   for(j=0;j<no3-1-i;j++)
   {
    if(log2[j].bewater < log2[j+1].bewater)
    {
     tmp = log2[j].bewater;
     strcpy(id,log2[j].bewaterid);
     log2[j].bewater = log2[j+1].bewater;
     strcpy(log2[j].bewaterid, log2[j+1].bewaterid);
     log2[j+1].bewater =tmp;
     strcpy(log2[j+1].bewaterid, id);
    }

   }
  }

  fp = fopen("/home/bbs/log/water","w");
  fprintf(fp,"���y�Ʀ�]\n");
  fprintf(fp,"[1;33mNO.    ID         �Q�������� \
  [1;36mNO.    ID         �����O�H����[m\n");

  for(i=0;i<20;i++)
  {
   if(i == 0)
    fprintf(fp,"\033[31;1m%2d.%-14s %4d       | %2d.%14s %4d\033[m\n",
     i+1,log2[i].waterid,log2[i].water, i+1, log2[i].bewaterid, log2[i].bewater);
   else if(i == 1)
    fprintf(fp,"\033[32;1m%2d.%-14s %4d       | %2d.%14s %4d\033[m\n",
     i+1,log2[i].waterid,log2[i].water, i+1, log2[i].bewaterid, log2[i].bewater);
   else if(i == 2)
    fprintf(fp,"\033[36;1m%2d.%-14s %4d       | %2d.%14s %4d\033[m\n",
     i+1,log2[i].waterid,log2[i].water, i+1, log2[i].bewaterid, log2[i].bewater);
   else
    fprintf(fp,"\033[37;1m%2d.%-14s %4d       | %2d.%14s %4d\033[m\n",
      i+1,log2[i].waterid,log2[i].water, i+1, log2[i].bewaterid, log2[i].bewater);
  }
  fclose(fp);

}
