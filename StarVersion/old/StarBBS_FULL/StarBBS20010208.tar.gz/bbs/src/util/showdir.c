/*
Show .DIR contents
*/
#include <stdio.h>
#include "bbs.h"
main()
{
   FILE* fp;

   if (fp = fopen(".DIR", "r")) {
      fileheader fhdr;
      int n = 0;
      char type;

      while (fread(&fhdr, sizeof(fhdr), 1, fp) == 1) {
         fhdr.title[50] = 0;
         type = "+ Mm"[fhdr.filemode];
         if (fhdr.filemode & FILE_TAGED)
            type = 'D';
         printf("%3d %c %13s %-5s %-12s %-41.40s\n",
          ++n, type, fhdr.filename, fhdr.date, fhdr.owner, fhdr.title);
      }
      fclose(fp);
   }
   else
      fprintf(stderr, "`.DIR` opened error (for read)\n");
}
