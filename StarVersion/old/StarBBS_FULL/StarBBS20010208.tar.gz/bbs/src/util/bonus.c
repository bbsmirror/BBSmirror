// BBS�p���ε{���A�����W���H�o�Q��
// by stacker, 87/12/18, from �Ѵ����p��(mail.ee.ntou.edu.tw)

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include "bbs.h"

#define STR_DOTDIR ".DIR"
#define FN_PASSWD ".PASSWDS"
#define BUFSIZE 512
#define safewrite write
#define _BBS_UTIL_C

#undef HAVE_MMAP

struct UCACHE *uidshm;

struct manrec {
	char userid[IDLEN + 1];
	unsigned long int deposit;
};

typedef struct manrec manrec;
manrec current;

userec aman, xuser;

int usernumber;
char *str_home_file = "home/%c/%s/%s";
char *str_dotdir = STR_DOTDIR;
char *fn_passwd = FN_PASSWD;
char *direct;

static
void
attach_err (shmkey, name)
	int shmkey;
	char *name;
{
	fprintf (stderr, "[%s error] key = %x\n", name, shmkey);
	exit (1);
}

static
void *
attach_shm (shmkey, shmsize)
	int shmkey, shmsize;
{
	void *shmptr;
	int shmid;
	shmid = shmget (shmkey, shmsize, 0);
	if (shmid < 0) {
		shmid = shmget (shmkey, shmsize, IPC_CREAT | 0600);
		if (shmid < 0)
			attach_err (shmkey, "shmget");
		shmptr = (void *) shmat (shmid, NULL, 0);
		if (shmptr == (void *) -1)
			attach_err (shmkey, "shmat");
		memset (shmptr, 0, shmsize);
	}
	else {
		shmptr = (void *) shmat (shmid, NULL, 0);
		if (shmptr == (void *) -1)
			attach_err (shmkey, "shmat");
	}
	return shmptr;
}

// �C���g�@�I�I�A�H���w��

substitute_record(fpath, rptr, size, id)
	char *fpath;
	char *rptr;
	int size, id;
{
	int fd;
	
	if ((fd = open(fpath, O_WRONLY | O_CREAT, 0644)) == -1)
		return -1;
	
	flock(fd, LOCK_EX);
	lseek(fd, (off_t) size * (id - 1), SEEK_SET);
	safewrite(fd, rptr, size);
	flock(fd, LOCK_UN);
	fsync(fd);
	close(fd);
	return 0;
}

int
apply_record(fpath, fptr, size)
	char *fpath;
	int (*fptr) ();
int size;
{
	char abuf[BUFSIZE];
	FILE* fp;
	
	if (!(fp = fopen(fpath, "r")))
		return -1;
	
	while (fread(abuf, 1, size, fp) == size)
		if ((*fptr) (abuf) == QUIT) {
			fclose(fp);
			return QUIT;
		}
	fclose(fp);
	return 0;
}

long
get_num_records(fpath, size)
	char *fpath;
{
	struct stat st;
	
	if (stat(fpath, &st) == -1)
		return 0;
	return (st.st_size / size);
}

void
stampfile(fpath, fh)
	char *fpath;
	fileheader *fh;
{
	register char *ip = fpath;
	time_t dtime;
	struct tm *ptime;
	int fp;
	
	#if 1
	if (access(fpath, X_OK | R_OK | W_OK))
		mkdir(fpath, 0755);
	#endif
	time(&dtime);
	while (*(++ip));
		*ip++ = '/';
	do {
		sprintf(ip, "M.%d.A", ++dtime );
	} while ((fp = open(fpath, O_CREAT | O_EXCL | O_WRONLY, 0644)) == -1);
	close(fp);
	memset(fh, 0, sizeof(fileheader));
	strcpy(fh->filename, ip);
	ptime = localtime(&dtime);
	sprintf(fh->date, "%2d/%02d", ptime->tm_mon + 1, ptime->tm_mday);
}

int
get_record(fpath, rptr, size, id)
	char *fpath;
	char *rptr;
	int size, id;
{
	int fd;
	
	if ((fd = open(fpath, O_RDONLY, 0)) != -1) {
		if (lseek(fd, (off_t)(size * (id - 1)), SEEK_SET) != -1) {
			if (read(fd, rptr, size) == size) {
				close(fd);
				return 0;
			}
		}
		close(fd);
	}
	return -1;
}

int
do_append(fpath, record, size)
	char *fpath;
	fileheader *record;
	int size;
{
	int fd;
	
	if ((fd = open(fpath, O_WRONLY | O_CREAT, 0644)) == -1) {
		perror("error opening file...");
		return -1;
	}
	flock(fd, LOCK_EX);
	lseek(fd, (off_t)0, SEEK_END);
	safewrite(fd, record, size);
	flock(fd, LOCK_UN);
	close(fd);
	return 0;
}

void
resolve_ucache ()
{
	if (uidshm == NULL) {
		uidshm = (struct UCACHE *) attach_shm (UIDSHM_KEY, sizeof (*uidshm));
		if (uidshm->touchtime == 0)
			uidshm->touchtime = 1;
	}
	while (uidshm->uptime < uidshm->touchtime)
		reload_ucache ();
}

#ifndef HAVE_MMAP
static int
fillucache (uentp)
	userec *uentp;
{
	if (usernumber < MAXUSERS) {
		strncpy (uidshm->userid[usernumber], uentp->userid, IDLEN + 1);
		uidshm->userid[usernumber++][IDLEN] = '\0';
	}
	return 0;
}
#endif

reload_ucache ()
{
	if (uidshm->busystate) {
		// ��L user ���b flushing ucache ==> CSMA/CD
		if (uidshm->touchtime - uidshm->uptime > 30) {
			uidshm->busystate = 0;	// leave busy state
		}
		else
			sleep (1);
	}
	else {
		uidshm->busystate = 1;	// enter busy state
		usernumber = 0;
		apply_record (".PASSWDS", fillucache, sizeof (userec));
		uidshm->number = usernumber;
		
		// �� user ��Ƨ�s��A�]�w uptime
		
		uidshm->uptime = uidshm->touchtime;
		uidshm->busystate = 0;	// leave busy state
	}
}

void sethomepath(buf, userid)
	char *buf, *userid;
{
	sprintf(buf, "home/%s", userid);
}

int
ci_strcmp (s1, s2)
	register char *s1, *s2;
{
	register int c1, c2, diff;
	
	do {
		c1 = *s1++;
		c2 = *s2++;
		if (c1 >= 'A' && c1 <= 'Z')
			c1 |= 32;
		if (c2 >= 'A' && c2 <= 'Z')
			c2 |= 32;
		if (diff = c1 - c2)
			return (diff);
	} while (c1);
	return 0;
}

void sethomedir(buf, userid)
	char *buf, *userid;
{
	sprintf(buf, str_home_file, userid[0], userid, str_dotdir);
}

int
getuser (userid)
	char *userid;
{
	int uid;
	
	if(uid = searchuser(userid))
		get_record(fn_passwd, &xuser, sizeof (xuser), uid);
	
	return uid;
}

int
append_record(fpath, record, size)
	char *fpath;
	fileheader *record;
	int size;
{
	int fd , m,n;
	
	do_append(fpath,record,size);
	return 0;
}

int
searchuser (userid)
	char *userid;
{
	register char *ptr;
	register int i, j;
	
	resolve_ucache ();
	i = 0;
	j = uidshm->number;
	while (i < j) {
		ptr = uidshm->userid[i++];
		if (!ci_strcmp (ptr, userid)) {
			strcpy (userid, ptr);
			return i;
		}
	}
	return 0;
}
	
unsigned long int
inudeposit(tuser, money)
	char *tuser;
	unsigned long int money;
{
	int unum;
	
	if (unum = getuser(tuser)) {
		xuser.deposit += money;
		substitute_record(fn_passwd, &xuser, sizeof(userec), unum);
		return xuser.deposit;
	}
	return -1;
}

int
not_alpha(ch)
	register char ch;
{
	return (ch < 'A' || (ch > 'Z' && ch < 'a') || ch > 'z');
}

int
not_alnum(ch)
	register char ch;
{
	return (ch < '0' || (ch > '9' && ch < 'A') ||
	(ch > 'Z' && ch < 'a') || ch > 'z');
}

int
bad_user_id(userid)
	char *userid;
{
	register char ch;
	if (strlen(userid) < 2)
		return 1;
	if (not_alpha(*userid))
		return 1;
	
	while (ch = *(++userid)) {
		if (not_alnum(ch))
			return 1;
	}
	return 0;
}

// �Q���i�H�ۤv�M�w�n���h�֡A�H�U�ȨѰѦ�...

unsigned long
get_rate (money)
	unsigned long int money;
{
	unsigned long int to_give;
	
	to_give = money * 0.05;
	
	return (to_give);
}

void
main ()
{
	FILE *inf, *fp;
	fileheader mymail;
	unsigned long bonus_to_give;
	time_t now;
	int i;
	
	inf = fopen (BBSHOME "/.PASSWDS", "rb");
	if (inf == NULL) {
		printf ("sorry, the data is not ready.\n");
		exit (0);
	}

	for (i = 0; fread (&aman, sizeof (userec), 1, inf); i++) {
		if (bad_user_id (aman.userid))
			continue;
		if (ci_strcmp (aman.userid, "guest") == 0) // guest ���ব��Q��...
			continue;
		strcpy (current.userid, aman.userid);
		current.deposit = aman.deposit;
		
		bonus_to_give = get_rate(current.deposit);
	
		if((inudeposit(current.userid, bonus_to_give) != -1)) {
			char genbuf[200];
			
			if((fp = fopen("etc/bonus", "w+")) == NULL)
				return;
			now = time(NULL) - 6 * 60;
			sprintf(genbuf, "�@��: �Ѵ��Ȧ�\n");
			fputs(genbuf, fp);
			sprintf(genbuf, "���D: �Ѵ����Ȧ�Q���q���M��\n");
			fputs(genbuf, fp);
			sprintf(genbuf, "�ɶ�: %s\n", ctime(&now)); 
			fputs(genbuf, fp);
			sprintf(genbuf, "�A�`�@���s��$%lu�A�ѱo$%lu�Q���C\n", current.deposit, bonus_to_give);
			fputs(genbuf, fp);
			fclose (fp);
				
			sethomepath (genbuf, current.userid);
			stampfile(genbuf, &mymail);
			rename("etc/bonus", genbuf);
			strcpy(mymail.owner, "[�Ѵ��Ȧ�]");
			sprintf(mymail.title, "�Ѵ����Ȧ�Q���q���M��");
			mymail.savemode = 0;
			sethomedir(genbuf, current.userid);
			append_record(genbuf, &mymail, sizeof(mymail));
		}
	}
	fclose (inf);
}
