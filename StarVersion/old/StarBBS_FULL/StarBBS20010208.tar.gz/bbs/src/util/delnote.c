/*-------------------------------------------------------*/
/* delnote.c        ( FJU StarRiverBBS Ver 2.02 )        */
/*-------------------------------------------------------*/
/* target : delete note in board                         */
/* create : 00/03/01                                     */
/* update : 00/06/21                                     */
/*-------------------------------------------------------*/


#include "bbs.h"
#include "../lib/rec_add.c"

dashf(fname)
  char *fname;
{
  struct stat st;

  return (stat(fname, &st) == 0 && S_ISREG(st.st_mode));
}


/* ------------------------------------------ */
/* mail / post �ɡA�̾ڮɶ��إ��ɮסA�[�W�l�W */
/* ------------------------------------------ */
/* Input: fpath = directory; Output: fpath = full path; */

void
stampfile(fpath, fh)
  char *fpath;
  fileheader *fh;
{
  register char *ip = fpath;
  time_t dtime;
  struct tm *ptime;
  int fp;

#if 1
  if (access(fpath, X_OK | R_OK | W_OK))
    mkdir(fpath, 0755);
#endif

  time(&dtime);
  while (*(++ip));
  *ip++ = '/';
  do
  {
    sprintf(ip, "M.%d.A", ++dtime );
  } while ((fp = open(fpath, O_CREAT | O_EXCL | O_WRONLY, 0644)) == -1);
  close(fp);
  memset(fh, 0, sizeof(fileheader));
  strcpy(fh->filename, ip);
  ptime = localtime(&dtime);
  sprintf(fh->date, "%2d/%02d", ptime->tm_mon + 1, ptime->tm_mday);
}

main()
{
  FILE *fp;
  fileheader fhdr;
  boardheader bh;
  char genbuf[256],genbuf2[256];

  fp = fopen("/home/bbs/.BOARDS","r");
  if(fp == NULL) return;
  while(fread(&bh, sizeof(boardheader), 1, fp))
  {
   sprintf(genbuf2,"/home/bbs/boards/%s/board", bh.brdname);
   if(dashf(genbuf2)) //�p�G���d���O���ܤ~po,��L����...
   {
    sprintf(genbuf, "/home/bbs/boards/%s", bh.brdname);
    stampfile(genbuf, &fhdr);
    rename(genbuf2, genbuf);
    sprintf(fhdr.title," %s ���d���O", bh.brdname);
    strcpy(fhdr.owner, "[�Ȫe����]");
    fhdr.savemode = 'L';
    sprintf(genbuf, "/home/bbs/boards/%s/.DIR", bh.brdname);
    rec_add(genbuf, &fhdr, sizeof(fhdr));
   }
  }
  fclose(fp);
}

