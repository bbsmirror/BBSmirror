/*-------------------------------------------------------*/
/* star.c        ( FJU StarRiverBBS Ver 0.95 )           */
/*-------------------------------------------------------*/
/* target : some other system tools                      */
/* create : 99/11/09                                     */
/* update : 99/11/19                                     */
/*-------------------------------------------------------*/



#include "bbs.h"

int
Goodbye()
{
  extern void movie();
  char genbuf[100];

  getdata(b_lines - 1, 0, "�z�T�w�n���}�i " BOARDNAME " �j��(Y/N)�H[N] ",
    genbuf, 3, LCECHO,0);

  if (*genbuf != 'y')
    return 0;
  movie();
  if (cuser.userlevel)
  {
    getdata(b_lines - 1, 0, "(G)�H���ӳu (M)���گ��� (N)�ڭn�o�� [G] ",
      genbuf, 3, LCECHO,0);
    if (genbuf[0] == 'm')
      DL_func("SO/sysop.so:m_sysop");
    else if (genbuf[0] == 'n')
      DL_func("SO/starnote.so:notepad_main");
  }

  t_display();
  clear();
/*
  prints("[1;36m�˷R�� [31m%s([37m%s)[31m�A�O�ѤF�A�ץ��{"COLOR1
    " %s [40;33m�I\n\n�H�U�O�z�b���������U���:[m\n",
    cuser.userid, cuser.username, BoardName);
  user_display(&cuser, 0);
  pressanykey(NULL);
*/
  more(BBSHOME"/etc/Logout",NA);

  pressanykey("�O�o�n�h�h�ӳo����~~");
  if (currmode)
    u_exit("EXIT ");
//  reset_tty();
  exit(0);
}

/* ���ꪺ�o���{��..:Q... skybinary 2000 03 08 */
int ticket()
{
  FILE *fp;
  char buf[100];
  unsigned long no;
  if(currstat != READING)
  {
  fp = fopen("log/ticket.log","r");
  fscanf(fp,"%d",&no);
  fclose(fp);

  no = no + 1;
  sprintf(buf,"home/%c/%s/ticket.log",cuser.userid[0],cuser.userid);
  fp = fopen(buf,"a");
  fprintf(fp,"%d\n",no);
  fclose(fp);
  fp = fopen("log/ticket.log","w");
  fprintf(fp,"%d",no);
  fclose(fp);
  sprintf(buf,"���±z�ϥΤF�ӪA��!!!�o�����X�� :  %d ",no);
  pressanykey(buf);
  }
}

int showticket()
{
 char buf[100];

 sprintf(buf,"home/%c/%s/ticket.log",cuser.userid[0],cuser.userid);
 more(buf);
 return FULLUPDATE;
}

void generatetocheck()
{
 FILE *fp;
 char winnumber[9];
 unsigned long total,winnum;
 int i;

 fp = fopen("log/ticket.log","r");
 fscanf(fp,"%d",&total);
 fclose(fp);

 fp = fopen("log/winnumber.log","w");
 for(i=0;i<10;i++)
  {
   winnum=random()%total;
   winnumber[i]=winnum;
   fprintf(fp,"%d",winnumber[i]);
  }
 fclose(fp);
}

/*
int
test()
{
 char buf[8],ans[2],genbuf[30];
 int i=0,j=0,k=0;
 FILE *fp;
 char font[3][8];

// more("etc/word");
  clear();
  move(1,0);
 getdata(2,0,"�п�J�r��:",ans,2,DOECHO,0);
// move(1,0);clrtobot();
 getdata(3,0,"�п�J�K�ӭ^��r:",buf,8,DOECHO,0);
 sprintf(genbuf,"/home/bbs/font/%s/%c",ans,buf[0]);

 if(fp = fopen(genbuf,"r"));
 {
  while(fgets(font[j],8,fp) != NULL)
   j++;
 }
  fclose(fp);

 move(15,0);

  for(k=0;k<3;k++)
   prints("%6.6s\n",font[k]);


 pressanykey(NULL);
 return FULLUPDATE;
}
*/



/*
static char file_desc[12][12] ={
"�ӤH�W����","�ӤH�۵e��","�ӤH�Ƨѿ�","�@��ñ�W��","�G��ñ�W��",
"�T��ñ�W��","�|��ñ�W��","����ñ�W��","����ñ�W��","�C��ñ�W��",
"�K��ñ�W��","�E��ñ�W��"};
static char file_name[12][6] ={
"plans","photo","note","sig.1","sig.2",
"sig.3","sig.4","sig.5","sig.6","sig.7",
"sig.8","sig.9"};


int
display()
{
 char ANSIbuf[60],NObuf[60];
 int i,j,k;
 clear();
 stand_title("�ӤH�ɮ׳]�w");
 move(2,0);
 prints("----------------------");
 move(3,0);
 for(i=0;i<12;i++)
 {
  prints("[%2d]%10s \n",i+1,file_desc[i]);
 }
 pressanykey(NULL);
}
*/

void
showtitle2(mid,title,mid2)
char *mid, *title, *mid2;
{
 int color;
 if( chkmail(0) )
  mid = "[5;40;33m�y �P �e �� �H �� �A![m";
 else if(dashf(BBSHOME"/register.new") && HAS_PERM(PERM_ACCOUNTS))
  mid = "[5;40;33m�� �s �� �� �� �� �U![m";

 move(0,0);
 clrtobot();

 if(cuser.color == 9)
  color = time(0) % 7;
 else
  color = cuser.color;
 prints("[4%d;1m %8s �� [33m%-24.24s[m[4%d;1m �w\
[36m %-26.26s[37m�� [32m %3d[37m �H[m\n",
    color, title, mid, color, mid2, count_ulist());

}


/* ���� Multi play */

int
count_multiplay(int unmode)
{
  register int i, j;
  register user_info *uentp;
  extern struct UTMPFILE *utmpshm;

  resolve_utmp();
  for (i = j = 0; i < USHM_SIZE; i++)
  {
    uentp = &(utmpshm->uinfo[i]);
    if (uentp->uid == usernum)
     if(uentp->lockmode == unmode)
      j++;
  }
  return j;
}

/* �ϥο������ */

int
inumoney(char *tuser,int money)
{
  int unum;
  if (unum = getuser(tuser))
    {
      xuser.money += money;
      substitute_record(fn_passwd, &xuser,sizeof(userec), unum);
      return xuser.money;
    }
  else
      return -1;
}

int
inmoney(int money)
{
      update_data();
      cuser.money = xuser.money + money;
      substitute_record(fn_passwd, &cuser, sizeof(userec), usernum);
      return cuser.money;
}

int
inugold(char *tuser,int money)
{
  int unum;
  if (unum = getuser(tuser))
    {
      xuser.starmoney += money;
      substitute_record(fn_passwd, &xuser,sizeof(userec), unum);
      return xuser.starmoney;
    }
  else
      return -1;
}

int
ingold(unsigned long int money)
{
      update_data();
      cuser.starmoney = xuser.starmoney + money;
      substitute_record(fn_passwd, &cuser, sizeof(userec), usernum);
      return cuser.starmoney;
}



int
indeposit(int money)
{
      update_data();
      cuser.dtime = time(0);
      cuser.deposit = xuser.deposit + money;
      substitute_record(fn_passwd, &cuser, sizeof(userec), usernum);
      return cuser.deposit;
}

int
inmailbox(int m)
{
      update_data();
      cuser.exmailbox = xuser.exmailbox + m;
      substitute_record(fn_passwd, &cuser, sizeof(userec), usernum);
      return cuser.exmailbox;
}

int
deumoney(char *tuser, int money)
{
  int unum;
  if (unum = getuser(tuser))
    {
      if((unsigned long int)xuser.money <=
         (unsigned long int) money) xuser.money=0;
      else xuser.money -= money;
      substitute_record(fn_passwd, &xuser, sizeof(userec), unum);
      return xuser.money;
    }
  else
      return -1;
}

int
demoney(unsigned long int money)
{
  ticket();
  update_data();
  if(xuser.money <= money)
    cuser.money=0;
  else
    cuser.money = xuser.money - money;
  substitute_record(fn_passwd, &cuser, sizeof(userec), usernum);
  return cuser.money;
}

int
degold(unsigned long int money)
{
  update_data();
  if(xuser.starmoney <= money) cuser.starmoney=0;
  else
    cuser.starmoney = xuser.starmoney - money;
  substitute_record(fn_passwd, &cuser, sizeof(userec), usernum);
  return cuser.starmoney;
}
int
dedeposit(int money)
{
      update_data();
      if((unsigned long int)xuser.deposit <=
         (unsigned long int) money) cuser.deposit=0;
      else cuser.deposit = xuser.deposit - money;
      substitute_record(fn_passwd, &cuser, sizeof(userec), usernum);
      return cuser.deposit;
}


/* admin.c      ( NTHU CS MapleBBS Ver 2.36 )            */

#define NUMPERMS        32

char *permstrings[] = {
  "�򥻪��v�O",                 /* PERM_BASIC */
  "�i�J��ѫ�",                 /* PERM_CHAT */
  "��H��ѥh",                 /* PERM_PAGE */
  "�i�o���峹",                 /* PERM_POST */
  "���U��{��",                 /* PERM_LOGINOK */
  "�H��L�W��",                 /* PERM_MAILLIMIT */
  "�Ȯ������N",                 /* PERM_CLOAK */
  "�i�ݨ��Ԫ�",                 /* PERM_SEECLOAK */
  "�ä[�O�did",                 /* PERM_XEMPT */
  "���������N",                 /* PERM_DENYPOST */
  "�O�D���v��",                 /* PERM_BM */
  "�b���j�`��",                 /* PERM_ACCOUNTS */
  "��ѫ��`��",                 /* PERM_CHATCLOAK */
  "�ݪO�j�`��",                 /* PERM_BOARD */
  "�������v��",                 /* PERM_SYSOP */
  "BBSADM",                     /* PERM_BBSADM & PERM_POSTMASK */
  "���C�J�Ʀ�]",               /* PERM_NOTOP */
  "�޲z���W���",               /* PERM_XFILE */
  "��o�p��",                   /* PERM_RESEARCH */
  "�ק�G�m",                   /* PERM_FROM */
  "�ݪ���BM�O",                 /* PERM_BMBOARD */
  "�O�d..",                     /* PERM_GOOD */
  "��ذ��`��",                 /* PERM_Announce */
  "�����v�����U",               /* PERM_MG */
  "�S�Ȳժ�",                   /* PERM_SMG */
  "��Ų�",                     /* PERM_AD */
  "���I�e��",                   /* PERM_SAD */
  "���u��",                     /* PERM_PAINT */
  "���u�ժ�",                   /* PERM_SPAINT */
  "�Ȧ��`��",                   /* PERM_SECRETARY */
  "��߯���",                   /* PERM_LSYSOP */
  "�p�I�Ѥj"                    /* PERM_CAVE */
};

int
Security(x,y,sysopid,userid)
  int x,y;
  char *sysopid,*userid;
{
  FILE *fp=fopen("etc/security","w");
  fileheader fhdr;
  time_t now = time(0);
  char genbuf[200],reason[30];
  int i,flag=0;
  for (i = 4; i < NUMPERMS; i++)
    {
        if (((x >> i) & 1)!= ((y >> i) & 1)) {
            if (!flag) {
                now = time(NULL) - 6 * 60;
                sprintf (genbuf,"�@��: [�P�e�O�w��] �ݪO: Security\n");
                strcat (genbuf,"���D: [�Pĵ���i] �����ק��v�����i\n");
                fputs (genbuf,fp);
                sprintf (genbuf,"�ɶ�: %s\n",ctime(&now));
                fputs (genbuf,fp);
            }
            sprintf (genbuf,"   ����[1;32m%s%s%s%s[m���v��\n",
sysopid,(((x >> i) & 1)?"[1;33m����":"[1;33m�}��"),userid,permstrings[i]);
            fputs (genbuf,fp);
            flag++;
        }

    }
  if (flag)
  {
     clrtobot ();
     clear();
     while (!getdata(5 ,0
            ,"�п�J�z�ѥH�ܭt�d�G",reason,60,DOECHO,"���O�D: ���v��"));
     sprintf (genbuf,"\n   [1;37m����%s�ק��v���z�ѬO�G%s[m",
      cuser.userid,reason);
     fputs (genbuf,fp);
     fclose (fp);
     sprintf(genbuf, "boards/%s", "Security");
     stampfile(genbuf, &fhdr);
     rename ("etc/security",genbuf);

     sprintf(fhdr.title, "[�Pĵ���i] �����ק�%s�v�����i",userid);
     strcpy(fhdr.owner, "[�P�e�O�w��]");
     sprintf(genbuf, "boards/%s/.DIR", "Security");
     rec_add(genbuf, &fhdr, sizeof(fhdr));
  }
}

unsigned int
setperms(pbits)
  unsigned int pbits;
{
  register int i;
  char choice[4];

  move(4, 0);
  for (i = 0; i < NUMPERMS/2 ; i++)
  {
    prints("%c. %-20s %-15s %c. %-20s %s\n"
       , 'A' + i, permstrings[i],((pbits >> i) & 1 ? "��" : "  ")
       , i < 10 ? 'Q' + i : '0' + i - 10,
         permstrings[i+16],((pbits >> i+16) & 1 ? "��" : "  "));
  }
  clrtobot();
  while (getdata(b_lines - 1, 0, "�Ы� [A-5] �����]�w�A�� [Return] �����G",
      choice, 3, LCECHO,0))
  {
    i = choice[0] - 'a';
    if (i < 0) i = choice[0] - '0' + 26;
    if (i >= NUMPERMS)
      bell();
    else
    {
      pbits ^= (1 << i);
      move( i%16 + 4, i <= 15 ? 24 : 64);
      prints((pbits >> i) & 1 ? "��" : "  ");
    }
  }
  return (pbits);
}

/* register.c   ( NTHU CS MapleBBS Ver 2.36 )            */

#define VACATION
/* password encryption */

char *crypt();

static char pwbuf[14];
int
chkpasswd(passwd, test)
  char *passwd, *test;
{
  char *pw;
  strncpy(pwbuf, test, 14);
  pw = crypt(pwbuf, passwd);
  return (!strncmp(pw, passwd, 14));
}

/* �ˬd user ���U���p */

int
bad_user_id(userid)
  char *userid;
{
  register char ch;

  if (belong("etc/baduser",userid))
    return 1;
  if (strlen(userid) < 2)
    return 1;
  if (not_alpha(*userid))
    return 1;
  if (!ci_strcmp(userid, str_new))
    return 1;

  while (ch = *(++userid))
  {
    if (not_alnum(ch))
      return 1;
  }
  return 0;
}

/* -------------------------------- */
/* New policy for allocate new user */
/* (a) is the worst user currently  */
/* (b) is the object to be compared */
/* -------------------------------- */

int
compute_user_value(urec, clock)
  userec *urec;
  time_t clock;
{
  int value;

  /* if (urec) has XEMPT permission, don't kick it */
  if ((urec->userid[0] == '\0') || (urec->userlevel & PERM_XEMPT))
    return 9999;

  value = (clock - urec->lastlogin) / 60;       /* minutes */

  /* new user should register in 30 mins */
  if (strcmp(urec->userid, str_new) == 0)
    return (30 - value);

#ifdef  VACATION
  return 120 * 24 * 60 - value; /* �H�����O�s�b�� 120 �� */
#else
  if (!urec->numlogins)         /* �� login ���\�̡A���O�d */
    return -1;
  if (urec->numlogins <= 3)     /* #login �֩�T�̡A�O�d 20 �� */
    return 20 * 24 * 60 - value;

  /* ���������U�̡A�O�d 15 ��  �@�뱡�p�A�O�d 120 �� */
  return (urec->userlevel & PERM_LOGINOK ? 120 : 15) * 24 * 60 - value;
#endif
}

int
id_check()
{
 char id[11],buf[200];
 int no[10],i=0,j=0,tmp;
 FILE *fp;

 sprintf(buf,"/home/bbs/home/%c/%s/.idno", cuser.userid[0],cuser.userid);
 if(!dashf(buf))
  j=1;
 if(!strcmp(cuser.userid,STR_GUEST))
  j=0;

 if(j)
 {
 j=0;

 while(1)
 {
  if(++i >= 5)
  {
   pressanykey("�z���տ��~����J�Ӧh�F...");
   return FULLUPDATE;
  }
  move(b_lines-1,0); clrtoeol();
  getdata(b_lines-1,0,"\
��J�z�������Ҧr��(�Ĥ@�ӽХΤp�g):",id,11,DOECHO,0);
 //�U���O�p�g�P�_,�P�z�A�Ω�j�g
 if(id[0] == 'i')
  no[0] = 34;
 else if(id[0] == 'o')
  no[0] = 35;
 else
  no[0] = id[0] - 87; //�]��A: 65 ,a: 97

 if(no[0] > 17  && no[0] < 23) no[0] = no[0]-1;
 else if(no[0] > 23)  no[0] = no[0] -2;

 //�Nid[2]~id[9]���no[2]~no[9]����
 for(j=1;j<10;j++)
  no[j] = id[j] - '0';
  tmp = no[0]/10 + no[0]%10 * 9 + no[1] * 8 + no[2] * 7 + no[3] * 6 +
   no[4] * 5 + no[5] * 4 + no[6] * 3 + no[7] * 2 + no[8] + no[9];
  tmp = tmp % 10;

  if(no[1] != 1 && no[1] != 2) //�ĤG�X�u��1 and 2
   pressanykey("�����Ҧr����J�O����!!");
  else if(tmp != 0)
   pressanykey("�����Ҧr����J�O����!!");
  else
  {
   pressanykey("�z��J���O�ŦX�W�檺�����Ҧr��.");
   fp = fopen(buf,"w");
   fprintf(fp,"%s",id);
   fclose(fp);
   return FULLUPDATE;
  }

 }
}

}

