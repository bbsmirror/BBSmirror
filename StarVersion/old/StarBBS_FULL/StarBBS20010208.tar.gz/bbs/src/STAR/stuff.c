/*-------------------------------------------------------*/
/* stuff.c      ( NTHU CS MapleBBS Ver 2.36 )            */
/*-------------------------------------------------------*/
/* target : utility routines                             */
/* create : 95/03/29                                     */
/* update : 95/12/15                                     */
/*-------------------------------------------------------*/

#include <varargs.h>
#include <sys/param.h>
#include "bbs.h"

void
setuserfile(buf, fname)
  char *buf, *fname;
{
  sprintf(buf, "home/%c/%s/%s", cuser.userid[0], cuser.userid, fname);
}

void
setbdir(buf, boardname)
  char *buf, *boardname;
{
  sprintf(buf, "boards/%s/%s", boardname,
    currmode & MODE_ETC ? ".ETC" : currmode & MODE_DIGEST ? fn_mandex : ".DIR");
}

char *
subject(title)
  char *title;
{
  if (!strncasecmp(title, str_reply, 3))
  {
    title += 3;
    if (*title == ' ')
      title++;
  }
  return title;
}

int
invalid_fname(str)
  char *str;
{
  char ch;

  if (strspn(str, ".") == strlen(str))
     return 1;
  while (ch = *str++)
  {
    if (not_alnum(ch) && !strchr("@[]-._", ch))
      return 1;
  }
  return 0;
}


int
invalid_pname(str)
  char *str;
{
  char *p1, *p2, *p3;

  p1 = str;
  while (*p1) {
     if (!(p2 = strchr(p1, '/')))
        p2 = str + strlen(str);
     if (p1 + 1 > p2 || p1 + strspn(p1, ".") == p2)
        return 1;
     for (p3 = p1; p3 < p2; p3++)
        if (not_alnum(*p3) && !strchr("@[]-._", *p3))
          return 1;
     p1 = p2 + (*p2 ? 1 : 0);
  }
  return 0;
}



int
valid_ident(ident)
  char *ident;
{
  static char *invalid[] = {"unknown@", "root@", "gopher@", "bbs@",
  "@bbs", "guest@", "@ppp", "@slip", NULL};
  char buf[128];
  int i;

  str_lower(buf, ident);
  for (i = 0; invalid[i]; i++)
    if (strstr(buf, invalid[i]))
      return 0;
  return 1;
}


int
is_uBM(list,id)
  char *list,*id;                   /* �O�D�GBM list */
{
  register int len;
  if(list[0] == '[') list++;
  if (list[0] > ' ')
  {
    len = strlen(id);
    do
    {
      if (!ci_strncmp(list, id, len))
      {
        list += len;
        if ((*list == 0) || (*list == '/') || (*list == ']') || (*list == ' '))
          return 1;
      }
      if((list = strchr(list,'/')) != NULL)
        list++;
      else
        break;
    } while (1);
  }
  return 0;
}

int
is_BM(list)
  char *list;
{
 return is_uBM(list,cuser.userid);
}



/*
woju
*/
int
userid_is_BM(userid, list)
  char *userid, *list;                  /* �O�D�GBM list */
{
  register int ch, len;

  ch = list[0];
  if ((ch > ' ') && (ch < 128))
  {
    len = strlen(userid);
    do
    {
      if (!ci_strncmp(list, userid, len))
      {
        ch = list[len];
        if ((ch == 0) || (ch == '/') || (ch == ']'))
          return 1;
      }
      while (ch = *list++)
      {
        if (ch == '/')
          break;
      }
    } while (ch);
  }
  return 0;
}


int
is_watched(name)
  char *name;
{
  char buf[40];
  FILE *list;

  if (list = fopen("watching", "r"))
  {
    while (fgets(buf, 40, list))
    {
      buf[strlen(buf) - 1] = '\0';
      if (!strcmp(buf, name))
        return 1;
    }
    fclose(list);
  }
/*
woju

*/
  return 0;
}

/* ----------------------------------------------------- */
/* �ɮ��ˬd��ơG�ɮסB�ؿ��B�ݩ�                        */
/* ----------------------------------------------------- */
off_t
dashs(fname)
  char *fname;
{
  struct stat st;

  if (!stat(fname, &st))
        return (st.st_size);
  else
        return -1;
}

long
dasht(fname)
  char *fname;
{
  struct stat st;

  if (!stat(fname, &st))
        return (st.st_mtime);
  else
        return -1;
}

int
dashl(fname)
  char *fname;
{
  struct stat st;

  return (lstat(fname, &st) == 0 && S_ISLNK(st.st_mode));
}


dashf(fname)
  char *fname;
{
  struct stat st;

  return (stat(fname, &st) == 0 && S_ISREG(st.st_mode));
}


int
dashd(fname)
  char *fname;
{
  struct stat st;

  return (stat(fname, &st) == 0 && S_ISDIR(st.st_mode));
}


int
belong(filelist, key)
  char *filelist;
  char *key;
{
  FILE *fp;
  int rc = 0;

  if (fp = fopen(filelist, "r"))
  {
    char buf[80], *ptr;

    while (fgets(buf, 80, fp))
    {
      if ((ptr = strtok(buf, str_space)) && !strcasecmp(ptr, key))
      {
        rc = 1;
        break;
      }
    }
    fclose(fp);
  }
  return rc;
}

char *
Cdate(clock)
  time_t *clock;
{
  static char foo[22];
  struct tm *mytm = localtime(clock);

  strftime(foo, 22, "%D %T %a", mytm);
  return (foo);
}

char *
Cdatelite(clock)
  time_t *clock;
{
  static char foo[18];
  struct tm *mytm = localtime(clock);

  strftime(foo, 18, "%D %T", mytm);
  return (foo);
}

//void
#if 0
int
pressanykey(msg)
  char *msg[255];
{
  int ch;

  move(b_lines, 0);
  clrtoeol();

  if(msg)
  {
    prints("[1;44m �� %-54s  [41m �i�Ы����N���~��j[m", msg);
    igetkey();
  }
  if(!msg)
  {
    outmsg("[1;44m                        �� �Ы� [33m(Space/Return)[37m �~�� ��                       [m");
    do
    {
      ch = igetkey();
      if (ch == KEY_ESC && KEY_ESC_arg == 'c')
       capture_screen();
    } while ((ch != ' ') && (ch != KEY_LEFT) && (ch != '\r') && (ch != '\n'));
  }
  move(b_lines, 0);
  clrtoeol();
  refresh();
}
#endif
int
pressanykey(va_alist)
  va_dcl
{
  va_list ap;
  char msg[250], *fmt;
  int ch;

  msg[0]=0;
  va_start(ap);
  fmt = va_arg(ap, char *);
  if(fmt) vsprintf(msg, fmt, ap);
  va_end(ap);
  if (msg[0])
  {
    move(b_lines, 0); clrtoeol();
    prints("[1;44m �� [37m%-54s  [41m[�ť�]�� ESC_c�Ȧs [m",msg);
  }
  else
    outmsg("[1;44m                        �� �Ы�[33m(Space/Return)[37m [44m �~�� ��                       [m");
  do
  {
    ch = igetkey();
    if (ch == KEY_ESC && KEY_ESC_arg == 'c')
      capture_screen();
  } while ((ch != ' ') && (ch != KEY_LEFT) && (ch != '\r') && (ch !=
'\n'));

  move(b_lines, 0);
  clrtoeol();
  refresh();
}



void
bell()
{
  char sound[3], *ptr;

  ptr = sound;
  memset(ptr, Ctrl('G'), sizeof(sound));
  write(1, ptr, sizeof(sound));
}

int
search_num(ch, max)
{
  int clen = 1;
  int x, y;
  extern unsigned char scr_cols;
  char genbuf[10];

  outmsg("[7m ���ܲĴX���G[0m");
  outc(ch);
  genbuf[0] = ch;
  getyx(&y, &x);
  x--;
  while ((ch = igetch()) != '\r')
  {
    if (ch == 'q' || ch == 'e')
      return -1;
    if (ch == '\n')
      break;
    if (ch == '\177' || ch == Ctrl('H'))
    {
      if (clen == 0)
      {
        bell();
        continue;
      }
      clen--;
      move(y, x + clen);
      outc(' ');
      move(y, x + clen);
      continue;
    }
    if (!isdigit(ch))
    {
      bell();
      continue;
    }
    if (x + clen >= scr_cols || clen >= 6)
    {
      bell();
      continue;
    }
    genbuf[clen++] = ch;
    outc(ch);
  }
  genbuf[clen] = '\0';
  move(b_lines, 0);
  clrtoeol();
  if (genbuf[0] == '\0')
    return -1;
  clen = atoi(genbuf);
  if (clen == 0)
    return 0;
  if (clen > max)
    return max;
  return clen - 1;
}


void
stand_title(title)
  char *title;
{
  clear();
  prints(COLOR1"[1m�i %s �j[m\n", title);
}


/* opus : cursor position */


void
printdash(mesg)
  char *mesg;
{
  int head = 0, tail;

  if (mesg)
    head = (strlen(mesg) + 1) >> 1;

  tail = head;

  while (head++ < 38)
    outch('-');

  if (tail)
  {
    outch(' ');
    outs(mesg);
    outch(' ');
  }

  while (tail++ < 38)
    outch('-');
  outch('\n');
}
/*
void
show_help(helptext)
  char *helptext[];
{
  char *str;
  int i;

  clear();
  for (i = 0; (str = helptext[i]); i++)
  {
    if (*str == '\0')
      prints("[1m�i %s �j[0m\n", str + 1);
    else if (*str == '\01')
      prints("\n[36m�i %s �j[m\n", str + 1);
    else
      prints("        %s\n", str);
  }
  pressanykey(NULL);
}
*/
// wildcat : ��سf��
int
check_money(unsigned long int money)
{
  unsigned long int usermoney;

  usermoney = cuser.money;
  if(usermoney<money)
  {
    char buf[80];
    clear();
    move(10,10);
    sprintf(buf,"��p�I�z���W�u�� %d ���A������I",usermoney);
    pressanykey(buf);
    return 1;
  }
  return 0;
}

/* wildcat 981218 */
#define INTEREST_TIME   86400*7 // wildcat:7�ѵo��@���Q��
#define BANK_RATE       1.06    // wildcat:�Ȧ�Q�v 1.06
void
update_data()
{
  int add = (time(0) - update_time)/30;
  rec_get(fn_passwd, &xuser, sizeof(userec), usernum);
  if((time(0) - xuser.dtime) >= INTEREST_TIME && xuser.deposit)
  {
    xuser.deposit *= BANK_RATE;
    xuser.dtime = time(0);
  }
  if(add >= 1)
  {
    xuser.money += add;
    xuser.totaltime += (time(0)-update_time);
    update_time = time(0);
  }
  cuser = xuser;
  substitute_record(fn_passwd, &cuser, sizeof(userec), usernum);
}


int
show_file(char *filename, int y, int lines, int mode)
{
  FILE *fp;
  char buf[256];
  clrchyiuan(y,y+lines);
  move(y,0);
  if((fp=fopen(filename,"r")))
  {
    while(fgets(buf,256,fp) && lines--)
      outs(Ptt_prints(buf,mode));
    fclose(fp);
  }
  else return 0;
  return 1;
}


/*---------------------------------------------------------------------*/
/* int chyiuan_ansi(buf,str,max)���Ϊk:�۵e����                        */
/* buf:chyiuan_ansi�L�᪺string                                        */
/* str:chyiuan_ansi���e��string                                        */
/* count:�Ǧ^move������shift���ƭ�                                     */
/* �Ƶ�:�p�G�O�m��Ҧ�, �W�L����Ȯ�, �|�屼�r��W�L����, ���O�dcolor  */
/*---------------------------------------------------------------------*/

int
chyiuan_ansi(buf,str,max)
  char *buf,*str;
  int max;
{
  int count=0;
  int count0=0;
  int count1=0;
  char buf0[256];
  count0=strip_ansi(buf0,str,0);
  if((cuser.uflag & COLOR_FLAG) && count0 <= max)
  {
    count1=strip_ansi(NULL,str,1);
    count=count1-count0;
    strcpy(buf, str);
  }
  else if((cuser.uflag & COLOR_FLAG) && count0 > max)
  {
    count0 = cut_ansistr(buf0,str,max);
    count1 = strip_ansi(NULL,buf0,1);
    count=count1-count0;
    strcpy(buf, buf0);
  }
  else
  {
    count=0;
    strcpy(buf, buf0);
  }
  return count;
}

int
answer(char *s)
{
  char ch;
  outmsg(s);
  ch = igetch ();
  if (ch == 'Y')
    ch = 'y';
  return ch;
}

#ifdef SunOS

#include <syslog.h>

void
setenv(name, value, overwrite)
  const char *name;
  const char *value;
  int overwrite;
{
  if (overwrite || (getenv(name) == 0))
  {
    char *p;

    if ((p = malloc(strlen(name) + strlen(value) + 2)) == 0)
    {
      syslog(LOG_ERR, "out of memory\n");
      exit(1);
    }
    sprintf(p, "%s=%s", name, value);
    putenv(p);
  }
}

atexit(procp)
void (*procp)();
{
   on_exit(procp, 0);
}

#endif

capture_screen()
{
   char fname[200];
   FILE* fp;
   extern screenline *big_picture;
   extern uschar scr_lns;
   int i;

   setuserfile(fname, "buf.0");
   if (fp = fopen(fname, "w")) {
      for (i = 0; i < scr_lns; i++)
         fprintf(fp, "%.*s\n", big_picture[i].len, big_picture[i].data);
      fclose(fp);
   }
}

edit_note()
{
   char fname[200];
   int mode0 = currutmp->mode;
   int stat0 = currstat;
   char c0 = *quote_file;

   *quote_file = 0;
   setutmpmode(NOTE);
   setuserfile(fname, "note");
   vedit(fname, 0);
   currutmp->mode = mode0;
   currstat = stat0;
   *quote_file = c0;
}

char*
my_ctime(const time_t *t)
{
  struct tm *tp;
  static char ans[100];

  tp = localtime(t);
  sprintf(ans, "%04d/%02d/%02d %02d:%02d:%02d", 1900+tp->tm_year,
     tp->tm_mon + 1,tp->tm_mday, tp->tm_hour, tp->tm_min, tp->tm_sec);
  return ans;
}

/* game log */
game_log(va_alist)
va_dcl
{
 va_list ap;
 int file;
 char *fmt,msg[200],ff[40];
 time_t now;
 FILE *fs;

 va_start(ap);
  file = va_arg(ap, int);
  fmt = va_arg(ap, char *);
  vsprintf(msg, fmt, ap);
 va_end(ap);

 switch(file) /* �o�@�q�i�H�ۤv��! */
 {
  case BINGO: strcpy(ff,"log/bingo.log"); break;
  case XAXB: strcpy(ff,"log/gagb.log"); break;
  case CHICKEN: strcpy(ff,"log/pip.log"); break;
  case BLACKJACK: strcpy(ff,"log/bj.log"); break;
  case NINE: strcpy(ff,"log/nine.log"); break;
//  case STOCK: strcpy(ff,"log/stock.log"); break;
  case DICE: strcpy(ff,"log/dice.log"); break;
  case GP: strcpy(ff,"log/gp.log"); break;
  case MARIO: strcpy(ff,"log/mario2.log"); break;
  case CHESSMJ: strcpy(ff,"log/chessmj.log");break;
  case SEVENCARD: strcpy(ff,"log/seven.log");break;
  case RACE: strcpy(ff,"log/race.log");break;
  case JACK_CARD: strcpy(ff,"log/jack.log");break;
  case TENHALF: strcpy(ff,"log/ten.log");break;
 }
 fs=fopen(ff,"a+");
 now=time(0);
 fprintf(fs,"%s %s %s\n", Cdate(&now),cuser.userid,msg);
 fclose(fs);
}

/*
void scrolltxt(char *s,int line,int color)
{
    static char buf1[80],buf2[100];
    static int x,y;

    if(s!=NULL)
        {  strcpy(buf1,s);
           y=line;
           x=80-strlen(buf1);
           return; }
    else if(y>0)
        {  if(x<0)  {  sprintf(buf2,"[%d;1H[K",y);
                       x=80-strlen(buf1);
                       output(buf2,strlen(buf2));
                       oflush();
                    }
           sprintf(buf2,"[%d;%dH[1;%dm%s[m[K",y,x--,color,buf1);
           output(buf2,strlen(buf2));
           oflush();
           if(HAVE_HABIT(HABIT_BAR)) y=-1;
        }
}

int
pressanykey(char *msg)
{
    extern int showansi;
    int color;

    showansi=1;
    move(b_lines,0);
    clrtoeol();
    color=31+(random() % 7);
    if(!msg) msg="�i �����N���~�� �o�n�m�l�k";
    scrolltxt(msg,t_lines,color);
    refresh();
//   while(!ikeypress(80000))
//    {
       scrolltxt(NULL,t_lines,color);
//    }
   egetch();
    move( b_lines, 0 );
    clrtoeol();
//    refresh();
    return 0;
}

int
pressreturn()
{
    extern int showansi;
    char ch;
    int color;

    showansi=1;
    move(b_lines,0);
    clrtoeol();
    refresh();
    color=31+ (random() % 7);
    scrolltxt("�i �� (Enter/Space) �~�� �o�n�m�l�k",b_lines,color);
    while(!ikeypress(80000) || ( (ch=egetch()) !='\n' && ch!=' '))
        scrolltxt(NULL,t_lines,color);
    move(b_lines,0) ;
    clrtoeol() ;
    refresh() ;
    return 0 ;
}
*/

/* cursor bar
char currentbar[60];
char oldbar[60];

lbar(char *high, char *norm)
{
  int x,y;
  char tmp[60];

  refresh(); // flush all data

  getyx(&x, &y);
  output(oldbar, strlen(oldbar));
  output(high, strlen(high));
  strcpy(currentbar, high);
  strcpy(oldbar,norm);

  sprintf(tmp, "\x1b[%d;%dH",x+1, y+1);  // \x1b �N�O ascii code(27)
  output(tmp, strlen(tmp));
}
*/

