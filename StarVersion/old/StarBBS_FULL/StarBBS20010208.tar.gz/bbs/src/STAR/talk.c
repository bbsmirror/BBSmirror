/*-------------------------------------------------------*/
/* talk.c       ( NTHU CS MapleBBS Ver 2.36 )            */
/*-------------------------------------------------------*/
/* target : talk/quety/friend routines                   */
/* create : 95/03/29                                     */
/* update : 95/12/15                                     */
/*-------------------------------------------------------*/

#define _MODES_C_

#include "bbs.h"
#include "type.h"

#ifdef lint
#include <sys/uio.h>
#endif


#define M_INT 15                /* monitor mode update interval */
#define P_INT 20                /* interval to check for page req. in
                                 * talk/chat */


#define IRH 1
#define HRM 2



struct talk_win
{
  int curcol, curln;
  int sline, eline;
};

typedef struct
{
  user_info *ui;
  time_t idle;
  usint friend;
}      pickup;

extern int bind( /* int,struct sockaddr *, int */ );
extern bad_user(char* name);
extern char* getuserid();
extern struct UTMPFILE *utmpshm;
extern char watermode,no_oldmsg,oldmsg_count;
extern msgque oldmsg[MAX_REVIEW];
extern char *friend_file[8];

/* -------------------------- */
/* �O�� friend �� user number */
/* -------------------------- */

#define PICKUP_WAYS     4
int pickup_way = 0;
int friendcount;
int friends_number;
int override_number;
int rejected_number;
char *fcolor[7] = {"", "[1;32m", "[1;33m", "[1;37m", "[31m", "[1;35m", "[1;36m"};

char *talk_uent_buf;
char save_page_requestor[40];
char page_requestor[40];
static FILE* flog;

void friend_load();

int is_rejected(user_info *ui);

char *
modestring(uentp, simple)
  user_info *uentp;
  int simple;
{
  static char modestr[40];
  static char *notonline="���b���W";
  register int mode = uentp->mode;
  register char *word;

  word = ModeTypeTable[mode];

  if (!(HAS_PERM(PERM_SYSOP) || HAS_PERM(PERM_SEECLOAK)) &&
      (uentp->invisible || (is_rejected(uentp) & HRM)))
    return (notonline);
/*
woju
*/
  else if (mode == EDITING) {
     sprintf(modestr, "E:%s",
         ModeTypeTable[uentp->destuid < EDITING ? uentp->destuid : EDITING]);
     word = modestr;
  }
  else if (!mode && *uentp->chatid == 1)
  {
     if (!simple)
        sprintf(modestr, "�^�� %s", getuserid(uentp->destuid));
     else
        sprintf(modestr, "�^���I�s");
  }
  else if (!mode && *uentp->chatid == 2)
     if (uentp->msgcount < 10)
     {
        char *cnum[10] = {"", "�ѥ~�@�y�P", "�������y�P", "���T���C!!",
                              "�o�O�ĥ|��", "�Ĥ���??", "�����j��~~",
                              "�C�C����~~","�K�ӤF��~~", "�E��!�M�I!"};
        sprintf(modestr, "%s", cnum[uentp->msgcount]);
     }
     else
        sprintf(modestr, "�Q�����F@_@", uentp->msgcount);
  else if (!mode && *uentp->chatid == 3)
     sprintf(modestr, "�y�P�l�ꤤ");
  else if (!mode)
    return (uentp->destuid == 6) ? uentp->chatid :
      IdleTypeTable[(0 <= uentp->destuid && uentp->destuid < 6) ?
                    uentp->destuid: 0];
  else if (simple)
    return (word);

  else if (uentp->in_chat && mode == CHATING)
    sprintf(modestr, "%s (%s)", word, uentp->chatid);
  else if (mode== TALK)
   {
    if (is_hidden(getuserid(uentp->destuid)))    /* Leeym ���(����)���� */
      sprintf(modestr, "%s", "�ݨ찭�F..o_o"); /* Leeym �j�a�ۤv�o���a�I */
    else
      sprintf(modestr, "%s %s", word, getuserid(uentp->destuid));
   }
  else if (mode != PAGE && mode != QUERY)
    return (word);
  else
    sprintf(modestr, "%s %s", word, getuserid(uentp->destuid));

  return (modestr);
}


int
cmpuids(uid, urec)
  int uid;
  user_info *urec;
{
  return (uid == urec->uid);
}

int     /* Leeym �q FireBird ���ӧ�g�L�Ӫ� */
is_hidden(user)
char *user;
{
    int tuid;
    user_info *uentp;

  if ((!(tuid = getuser(user)))
  || (!(uentp = (user_info *) search_ulist(cmpuids, tuid)))
  || ((!uentp->invisible|| HAS_PERM(PERM_SYSOP)||HAS_PERM(PERM_SEECLOAK))
        && (((!PERM_HIDE(uentp) && !PERM_HIDE(currutmp)) ||
        PERM_HIDE(currutmp))
        && !(is_rejected(uentp) & HRM && !(is_friend(uentp) & 2)))))
        return 0;       /* ��� xxx */
  else
        return 1;       /* �ۨ��ۻy */
}

/*
woju
*/
int
cmppids(pid, urec)
  pid_t pid;
  user_info *urec;
{
  return (pid == urec->pid);
}


/* ------------------------------------- */
/* routines for Talk->Friend             */
/* ------------------------------------- */


static int
can_override(userid, whoasks)
  char *userid;
  char *whoasks;
{
  char buf[STRLEN];

  sethomefile(buf, userid, fn_overrides);
  return belong(buf, whoasks);
}


int
is_friend(ui)
  user_info *ui;
{
  register ushort unum, hit, *myfriends;

  /* �P�_���O�_���ڪ��B�� ? */

  unum = ui->uid;
  myfriends = currutmp->friend;
  while (hit = *myfriends++)
  {
    if (unum == hit)
    {
      hit = 1;
      friends_number++;
      break;
    }
  }

  /* �P�_�ڬO�_����誺�B�� ? */

  myfriends = ui->friend;
  while (unum = *myfriends++)
  {
    if (unum == usernum)
    {
      override_number++;
      hit |= 2;
      break;
    }
  }
  return hit;
}



static int
be_rejected(userid)
  char *userid;
{
  char buf[STRLEN];

  sethomefile(buf, userid, fn_reject);
  return belong(buf, cuser.userid);
}

  /* �Q�ڵ� */

int
is_rejected(ui)
  user_info *ui;
{
  register ushort unum, hit, *myrejects;

  if (PERM_HIDE(ui))
     return 0;
  /* �P�_���O�_���ڪ����H ? */

  unum = ui->uid;
  myrejects = currutmp->reject;
  while (hit = *myrejects++)
  {
    if (unum == hit)
    {
      hit = 1;
      rejected_number++;
      break;
    }
  }

  /* �P�_�ڬO�_����誺���H ? */

  myrejects = ui->reject;
  while (unum = *myrejects++)
  {
    if (unum == usernum)
    {
      if (hit & IRH)
         --rejected_number;
      hit |= 2;
      break;
    }
  }
  return hit;
}


/* ------------------------------------- */
/* �u��ʧ@                              */
/* ------------------------------------- */

static void
my_kick(uentp)
  user_info *uentp;
{
  char genbuf[200];

  getdata(1, 0, msg_sure_ny, genbuf, 4, LCECHO,"N");
  clrtoeol();
  if (genbuf[0] == 'y')
  {
    sprintf(genbuf, "%s (%s)", uentp->userid, uentp->username);
    log_usies("KICK ", genbuf);
    if ((kill(uentp->pid, SIGHUP) == -1) && (errno == ESRCH))
      memset(uentp, 0, sizeof(user_info));
    /* purge_utmp(uentp); */
    outs("��X�h�o");
  }
  else
  pressanykey(msg_cancel);
}

my_query(uident)
  char *uident;
{
  extern char currmaildir[];
  char genbuf[256];
  int count[11]={0};
  int tuid,i,k;
  unsigned long int j;
  user_info *uentp;
  FILE *photofile,*fp;
  userec muser;
  char ans[4]="y",realname[20];
  char *money[10] = {"�^��","���h","�M�H","���q","�p�d",
                     "�p�I��","���I��","�j�I��","�I�i�İ�","�W�r�I��"};
  char *star[13] = {"�d��","����","���l","����","��l","�B�k","�ѯ�",
                    "����","�g��","���~","���~","����","����",};
  char *sex[8] = { MSG_BIG_BOY, MSG_BIG_GIRL,
                   MSG_LITTLE_BOY, MSG_LITTLE_GIRL,
                   MSG_MAN, MSG_WOMAN, MSG_PLANT, MSG_MIME };

  sethomefile(genbuf,uident,"photo");

  if (tuid = getuser(uident))
  {
    clear();
    setutmpmode(QUERY);
    currutmp->destuid = tuid;
    /* skybinary 0123 photo */

    family_show(uident);

    if (photofile = fopen(genbuf, "r"))
    {
       k = 0;
       while (k++ < 11 && fgets(genbuf, 256, photofile))
       {
         move(k,0);
         clrtobot();
         move(k,0);

         count[k]=chyiuan_ansi(genbuf,genbuf,80);
         outs(genbuf);
        }
       fclose(photofile);
    }
    else
    {
       move(2,0);
       prints("������������������");
       move(3,0);
       prints("��      �z      ��");
       move(4,0);
       prints("��      ��      ��");
       move(5,0);
       prints("��      �e      ��");
       move(6,0);
       prints("��      �|      ��");
       move(7,0);
       prints("��      �L      ��");
       move(8,0);
       prints("��      ��      ��");
       move(9,0);
       prints("��      ��      ��");
       move(10,0);
       prints("������������������");
    }

    memcpy(&muser, &xuser, sizeof(userec));
    j = muser.money + muser.deposit;
    for(i=0;i<10 && j>10;i++) j /= 10;
move(2,18+count[2]);

 if(HAS_PERM(PERM_SYSOP))
 {
  sethomepath(genbuf, muser.userid);
  strcat(genbuf,"/.realname");
  if(fp = fopen(genbuf,"r"))
  {
    fscanf(fp,"%s",realname);
    fclose(fp);
  }
  prints("[1;33m�i�u��m�W�j [m%s\n",realname);
 }
 else
  prints("\n");

move(3,18+count[3]);
prints("[1;33m�i�^��N�١j[m%-16.16s�@[1;33m�i�ʺ١j[m%-20.20s\n",
                                        muser.userid,muser.username);
move(4,18+count[4]);
prints("[1;33m�i���šj[m%-10.10s�          [1;33m �i�ʧO�j[m%-14.14s\n",
                                        money[i],sex[muser.sex%8]);
move(5,18+count[5]);
prints("[1;33m�i�P�y�j[m");
        switch (muser.month)
            {
                  case 1:
                  if (muser.day <=19)
                       prints("%-4.4s�y",star[9]);
                   else
                       prints("%-4.4s�y",star[10]);
                   break;
                  case 2:
                  if (muser.day <=18)
                       prints("%-4.4s�y",star[10]);
                   else
                       prints("%-4.4s�y",star[11]);
                   break;
                  case 3:
                  if (muser.day <=20)
                       prints("%-4.4s�y",star[11]);
                   else
                       prints("%-4.4s�y",star[0]);
                   break;
                  case 4:
                  if (muser.day <=19)
                       prints("%-4.4s�y",star[0]);
                   else
                       prints("%-4.4s�y",star[1]);
                   break;
                  case 5:
                  if (muser.day <=20)
                       prints("%-4.4s�y",star[1]);
                   else
                       prints("%-4.4s�y",star[2]);
                   break;
                  case 6:
                  if (muser.day <=21)
                       prints("%-4.4s�y",star[2]);
                   else
                       prints("%-4.4s�y",star[3]);
                   break;
                  case 7:
                  if (muser.day <=22)
                       prints("%-4.4s�y",star[3]);
                   else
                       prints("%-4.4s�y",star[4]);
                   break;
                  case 8:
                  if (muser.day <=22)
                       prints("%-4.4s�y",star[4]);
                   else
                       prints("%-4.4s�y",star[5]);
                   break;
                  case 9:
                  if (muser.day <=22)
                       prints("%-4.4s�y",star[5]);
                   else
                       prints("%-4.4s�y",star[6]);
                   break;
                  case 10:
                  if (muser.day <=23)
                       prints("%-4.4s�y",star[6]);
                   else
                       prints("%-4.4s�y",star[7]);
                   break;
                  case 11:
                  if (muser.day <=22)
                       prints("%-4.4s�y",star[7]);
                   else
                       prints("%-4.4s�y",star[8]);
                   break;
                  case 12:
                  if (muser.day <=21)
                       prints("%-4.4s�y",star[8]);
                   else
                       prints("%-4.4s�y",star[9]);
                   break;

             }

    prints("\n");
move(6,18+count[6]);
prints("[1;33m�i�W���a�I�j[m%-20.20s\n",muser.lasthost[0] ? muser.lasthost : "(����)");
move(7,18+count[7]);
prints("[1;33m�i�ɶ��j[m%-22.22s[1;33m�i���ơj[m%d\n",Cdate(&muser.lastlogin),muser.numlogins);
move(8,18+count[8]);
prints("[1;33m�i�ثe�ʺA�j[m");
    uentp = (user_info *) search_ulist(cmpuids, tuid);
    if (uentp && !(PERM_HIDE(currutmp) ||
      is_rejected(uentp) & HRM && is_friend(uentp) & 2)
      && PERM_HIDE(uentp))
      prints("[1;30m���b���W[m");
    else
      prints("[1;36m%-16.16s[m",
         uentp ? modestring(uentp, 0) : "���b���W");
move(9,18+count[9]);
prints("[1;33m�i�峹�j[m%-7d �g",muser.numposts);
prints("[1;33m�i�s�H�j[m");
    sethomedir(currmaildir, muser.userid);
    outs(chkmail(1) ? "[1;5;33m��[m" : "[1;30m�L[m");
    sethomedir(currmaildir, cuser.userid);
    chkmail(1);
move(10,18+count[10]);
    if(HAS_PERM(PERM_SYSOP) || !strcmp(muser.userid, cuser.userid))
     prints("[1;33m�i�{���j[m%-10ld[1;33m�i�s�ڡj[m%-8ld[1;33m�i�s���j[m %ld\n"
     ,muser.money,muser.deposit,muser.starmoney);
    prints("[1;33m�i�y�P�j[m���� %5d ���A�o�X %5d ��",
     muser.receivemsg,muser.sendmsg);
    prints("[1;33m�i�H����ơj[m%d ",muser.bequery);
    prints("[1;33m�i�n�_���ơj[m%d\n",muser.toquery);
    prints("[1;33m�i�{�b�߱��j[m�{�bı�o %-4.4s �C��:%d idletime: %d\n",
    muser.feeling,muser.color,muser.idletime);
    prints("[1;33m�i�ӤH�g��ȡj[m %d",cuser.exp);
/*
//    prints("[1;33m�i�P�y�a�ڡj[m");
//    move(15,0);
//    family_show(uident);
*/
    if(strcmp(muser.userid,cuser.userid))
    {
      ++muser.bequery;
      substitute_record(fn_passwd, &muser,sizeof(userec), tuid);
      update_data();
      ++cuser.toquery;
      substitute_record(fn_passwd, &cuser, sizeof(userec), usernum);
    }
   getdata(b_lines-1,0,"(a)������ (b)�Z���w (c)����w (d)�D��w (q)���} [q]:",ans,4,LCECHO,0);
   if(*ans == 'a'){
    showplans(uident);
    pressanykey(NULL);
    return FULLUPDATE;
    }
   else
    pressanykey(NULL);
   return FULLUPDATE;
  }
  return DONOTHING;
  /* currutmp->destuid = 0; */
}


int
my_write(pid, hint)
  pid_t pid;
  char *hint;
{
  int len;
  char msg[80];
  FILE *fp;
  struct tm *ptime;
  time_t now;
  char genbuf[200];
  user_info *uin ;
  extern msgque oldmsg[MAX_REVIEW];
  int a;
/*
woju
*/
  uschar mode0 = currutmp->mode;
  char c0 = currutmp->chatid[0];
  int currstat0 = currstat;

/* guest�������y
  if(!strcmp(cuser.userid, STR_GUEST))
   return FULLUPDATE;*/
        if (!cuser.userlevel)
          return FULLUPDATE;

  if(watermode > 0)
     {
       a = (no_oldmsg - watermode + MAX_REVIEW )%MAX_REVIEW;
       uin = (user_info*)search_ulist(cmppids, oldmsg[a].last_pid);
     }
  else
       uin = (user_info*)search_ulist(cmppids, pid);

  if (( !oldmsg_count || !isprint2(*hint)) && !uin ) {
     pressanykey("�V�|! ���w���]�F(���b���W)! ~>_<~");
     watermode = -1;
     return 0;
  }

  currutmp->mode = 0;
  currutmp->chatid[0] = 3;
  currstat = XMODE;


  time(&now);
  ptime = localtime(&now);

  if (isprint2(*hint))
  {
    char inputbuf[4];
    if (!(len = getdata(0, 0, hint, msg, 65, DOECHO,0))) {
      pressanykey("��F! ��A�@��...");
      currutmp->chatid[0] = c0;
      currutmp->mode = mode0;
      currstat = currstat0;
      watermode = -1;
      return 0;
  }
/* Ptt */
    if(watermode > 0)
      {
       a = (no_oldmsg - watermode + MAX_REVIEW )%MAX_REVIEW;
       uin = (user_info*)search_ulist(cmppids, oldmsg[a].last_pid);
      }

    strip_ansi(msg,msg,0);
    if (!uin  || !*uin->userid) {
       pressanykey("�V�|! ���w���]�F(���b���W)! ~>_<~");
       currutmp->chatid[0] = c0;
       currutmp->mode = mode0;
       currstat = currstat0;
       watermode = -1;
       return 0;
    }

    sprintf(genbuf, "��%s�y�P:%.40s....?[Y] ", uin->userid, msg);

    getdata(0, 0, genbuf, inputbuf, 3, LCECHO,0);
    genbuf[0] = '\0';
    watermode = -1;
    if (inputbuf[0] == 'n') {
      currutmp->chatid[0] = c0;
      currutmp->mode = mode0;
      currstat = currstat0;
      return 0;
    }
    if (!uin || !*uin->userid) {
       pressanykey("�V�|! ���w���]�F(���b���W)! ~>_<~");
       currutmp->chatid[0] = c0;
       currutmp->mode = mode0;
       currstat = currstat0;
       return 0;
    }
  }
  else {
     strcpy(msg, hint + 1);
     strip_ansi(msg,msg,0);
     len = strlen(msg);
     watermode = -1;
  }
   now = time(0);
   if (*hint != 1) {
      sethomefile(genbuf, uin->userid, fn_writelog);
      if (fp = fopen(genbuf, "a")) {
        fprintf(fp, "[1m[33;44m�� %s %s[37;46m %s [0m[%s]\n",
          cuser.userid, (*hint == 2) ? "[33;41m�s��" : "", msg, Cdatelite(&now));
        fclose(fp);
      }
      sethomefile(genbuf, cuser.userid, fn_writelog);
      if (fp = fopen(genbuf, "a")) {
        fprintf(fp, "To %s: %s [%s]\n", uin->userid, msg, Cdatelite(&now));
      fclose(fp);
      update_data();
      ++cuser.sendmsg;
      substitute_record(fn_passwd, &cuser, sizeof(userec), usernum);
      }
   }
   if (*hint == 2 && uin->msgcount) {
      uin->destuip = currutmp;
      uin->sig = 2;
      kill(uin->pid, SIGUSR1);
   }
   else if (*hint != 1 && !HAS_PERM(PERM_SYSOP) && ( uin->pager == 3
       || uin->pager == 2 || (uin->pager == 4 && !(is_friend(uin) & 2)) ))
      pressanykey("���߱����n���A�ť��Z�I");
   else {
      if (uin->msgcount < MAXMSGS) {
         uschar pager0 = uin->pager;
         uin->pager = 2;
         uin->msgs[uin->msgcount].last_pid = currpid;
         strcpy(uin->msgs[uin->msgcount].last_userid, currutmp->userid);
         strcpy(uin->msgs[uin->msgcount++].last_call_in, msg);
         uin->pager = pager0;
      }
      else if (*hint != 1)
      {
         pressanykey("���}�`�F�I (����Ӧh�{�y�P) @_@");
         uin->msgcount++;  // wildcat: �קK�Q�����᪺�H���W����
      }
      if (uin->msgcount  == 1 && kill(uin->pid, SIGUSR2) == -1 && *hint != 1)
         pressanykey("�V�|! �S����! ~>_<~");
      else if (uin->msgcount == 1 && *hint != 1)
         outmsg("[1;44m�y�P�{�L�h�F! *^o^Y[m");
      else if (uin->msgcount > 1 && uin->msgcount < MAXMSGS && *hint != 1)
         outmsg("[1;44m�A�ɤW�@��! *^o^Y[m");
   }
 /* Gene */
   if (uin->msgcount==MAXMSGS)
   {
     time_t nows;
     char buftmp[100];
     nows=time(0);
     sprintf(buftmp,"%s [1;33m%-12s[m �� [1;36m%-12s[m �����F...*\\^o^/*",
        Ctime( &now) +4,  cuser.userid, uin->userid);
     f_cat(BBSHOME"/log/msgover",buftmp);
     sprintf(buftmp,"1.%s 2.%s",cuser.userid, uin->userid);
     f_cat(BBSHOME"/log/water.log",buftmp);
   }

   currutmp->chatid[0] = c0;
   currutmp->mode = mode0;
   currstat = currstat0;
   return 1;
}

static char t_display_new_flag =0;

void
t_display_new()
{
   int i;
   char buf[256];

   if(t_display_new_flag) return;

   else t_display_new_flag = 1;

   if(oldmsg_count && watermode > 0)
     {
         move(1,0);
         outs(
" [1m[32m�w�w�w�w�w�w�w[36m�y[32m�w[33m�P[32m�w[31m�^[32m�w[34m�U[32m�w�w�w�w�w�w�w�w�w[37;44m [Ctrl-R]���U���� [32;40m�w�w�w�w�w�w [m");
         for(i=0 ; i < oldmsg_count ;i++)
                {
                 int a = (no_oldmsg - i - 1 + MAX_REVIEW )%MAX_REVIEW;
                 move(i+2,0);
                 clrtoeol();
                 if(watermode-1 !=i)
                    sprintf(buf,"[1m %s %s[m",
                         oldmsg[a].last_userid,oldmsg[a].last_call_in);
                 else
                    sprintf(buf,"[1m[36m>%s %s[m",
                         oldmsg[a].last_userid,oldmsg[a].last_call_in);
                 outs(buf);
                }
          move(i+2,0);
          outs(
" [1m[32m�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w[44;37m [Ctrl-T]���W���� [40;32m�w�w�w�w�w�w[m ");

     }
  t_display_new_flag =0;
}

/* Thor: for ask last call-in message */

int
t_display()
{
  char genbuf[200],ans[4];

  setuserfile(genbuf, fn_writelog);
  if (more(genbuf, YEA) != -1)
    {
     getdata(b_lines - 1, 0, "�M��(C) ���ܳƧѿ�(M) �O�d(R) (C/M/R)?[R]",
             ans, 3, LCECHO,"R");
     if (*ans == 'm') {
        fileheader mymail;
        char title[128], buf[80];

        sethomeback(buf, cuser.userid);
        stampfile(buf, &mymail);

        mymail.savemode = 'H';        /* hold-mail flag */
        mymail.filemode = FILE_READ;
        strcpy(mymail.owner, "[��.��.��]");
        strcpy(mymail.title, "���u[37;41m�O��[m");
        sethomebackdir(title, cuser.userid);
        rec_add(title, &mymail, sizeof(mymail));
        f_mv(genbuf, buf);
      }
     else if (*ans == 'c') {
        unlink(genbuf);
     }
     return FULLUPDATE;
    }
  return DONOTHING;
}


/* ----------------------------------------------------- */

static void
do_talk_nextline(twin)
  struct talk_win *twin;
{
   twin->curcol = 0;
   if (twin->curln < twin->eline)
      ++(twin->curln);
   else
      region_scroll_up(twin->sline, twin->eline);
   move(twin->curln, twin->curcol);
}


static void
do_talk_char(twin, ch)
  struct talk_win *twin;
  int ch;
{
  extern int dumb_term;
  extern screenline* big_picture;
  screenline* line;
  int i;
  char ch0;
  char buf[81];

  if (isprint2(ch))
  {
    ch0 = big_picture[twin->curln].data[twin->curcol];
    if (big_picture[twin->curln].len < 79)
       move(twin->curln, twin->curcol);
    else
       do_talk_nextline(twin);
    outc(ch);
    ++(twin->curcol);
    line =  big_picture + twin->curln;
    if (twin->curcol < line->len) {      /* insert */
       ++(line->len);
       memcpy(buf, line->data + twin->curcol, 80);
       save_cursor();
       do_move(twin->curcol, twin->curln);
       ochar(line->data[twin->curcol] = ch0);
       for (i = twin->curcol + 1; i < line->len; i++)
          ochar(line->data[i] = buf[i - twin->curcol - 1]);
       restore_cursor();
    }
    line->data[line->len] = 0;
    return;
  }

  switch (ch)
  {
  case Ctrl('H'):
  case '\177':
    if (twin->curcol == 0)
    {
      return;
    }
    line =  big_picture + twin->curln;
    --(twin->curcol);
    if (twin->curcol < line->len) {
       --(line->len);
       save_cursor();
       do_move(twin->curcol, twin->curln);
       for (i = twin->curcol; i < line->len; i++)
          ochar(line->data[i] = line->data[i + 1]);
       line->data[i] = 0;
       ochar(' ');
       restore_cursor();
    }
    move(twin->curln, twin->curcol);
    return;

  case Ctrl('D'):
     line =  big_picture + twin->curln;
     if (twin->curcol < line->len) {
        --(line->len);
        save_cursor();
        do_move(twin->curcol, twin->curln);
        for (i = twin->curcol; i < line->len; i++)
           ochar(line->data[i] = line->data[i + 1]);
        line->data[i] = 0;
        ochar(' ');
        restore_cursor();
     }
     return;
  case Ctrl('G'):
    bell();
    return;
  case Ctrl('B'):
     if (twin->curcol > 0) {
        --(twin->curcol);
        move(twin->curln, twin->curcol);
     }
     return;
  case Ctrl('F'):
     if (twin->curcol < 79) {
        ++(twin->curcol);
        move(twin->curln, twin->curcol);
     }
     return;
  case Ctrl('A'):
     twin->curcol = 0;
     move(twin->curln, twin->curcol);
     return;
  case Ctrl('K'):
     clrtoeol();
     return;
  case Ctrl('Y'):
     twin->curcol = 0;
     move(twin->curln, twin->curcol);
     clrtoeol();
     return;
  case Ctrl('E'):
     twin->curcol = big_picture[twin->curln].len;
     move(twin->curln, twin->curcol);
     return;
  case Ctrl('M'):
  case Ctrl('J'):
     line =  big_picture + twin->curln;
     strncpy(buf, line->data, line->len);
     buf[line->len] = 0;
     if (dumb_term)
       outc('\n');
     do_talk_nextline(twin);
     break;
  case Ctrl('P'):
     line =  big_picture + twin->curln;
     strncpy(buf, line->data, line->len);
     buf[line->len] = 0;
     if (twin->curln > twin->sline) {
        --(twin->curln);
        move(twin->curln, twin->curcol);
     }
     break;
  case Ctrl('N'):
     line =  big_picture + twin->curln;
     strncpy(buf, line->data, line->len);
     buf[line->len] = 0;
     if (twin->curln < twin->eline) {
        ++(twin->curln);
        move(twin->curln, twin->curcol);
     }
     break;
  }
  str_trim(buf);
  if (*buf)
     fprintf(flog, "%s%s: %s%s\n",
        (twin->eline == b_lines - 1) ? "[1;35m" : "",
        (twin->eline == b_lines - 1) ?
        getuserid(currutmp->destuid) : cuser.userid, buf,
        (ch == Ctrl('P')) ? "[37;45m(Up)[m" : "[m");
}

/*
char *talk_help =
  "== On-line Help! ==\n"
  " ^O ���u�W�����e�� \n"
  " ^U �C�X�u�W�ϥΪ� \n"
  " ^P ����Pager      \n"
  " ^G ��!(�εۤF��?) \n"
  " ^C/^D �T�T�F...   \n";
*/

static
do_talk(fd)
int fd;
{
   struct talk_win mywin, itswin;
   time_t talkstart;
   usint myword = 0;

   char mid_line[128], data[200];
   int i, ch, datac;
   int im_leaving = 0;
   struct tm *ptime;
   time_t now;
   char genbuf[200], fpath[100];

   time(&now);
   ptime = localtime(&now);

   sethomepath(fpath, cuser.userid);
   strcpy(fpath, tempnam(fpath, "talk_"));
   flog = fopen(fpath, "w");

#if 0
   setuserfile(genbuf, fn_talklog); /* Kaede */
/*   if (!is_watched(cuser.userid))*/
     log = NULL;
/*   else if (log = fopen(genbuf, "a+"))*/
     fprintf(log, "[%d/%d %d:%02d] & %s\n",
             ptime->tm_mon + 1, ptime->tm_mday, ptime->tm_hour, ptime->tm_min,
             save_page_requestor);
#endif

   setutmpmode(TALK);

   ch = 58 - strlen(save_page_requestor);
   sprintf(genbuf, "%s�i%s", cuser.userid, cuser.username);
   i = ch - strlen(genbuf);
   if (i >= 0)
   {
      i = (i >> 1) + 1;
   }
   else
   {
     genbuf[ch] = '\0';
     i = 1;
   }
   memset(data, ' ', i);
   data[i] = '\0';

   sprintf(mid_line, "[1m[44;33m  �P�e�]��  [41;33m%s%s�j [37m�P  [33m%s%s[0m",
     data, genbuf, save_page_requestor,  data);

   memset(&mywin, 0, sizeof(mywin));
   memset(&itswin, 0, sizeof(itswin));

   i = b_lines >> 1;
   mywin.eline = i - 1;
   itswin.curln = itswin.sline = i + 1;
   itswin.eline = b_lines - 1;

   clear();
   move(i, 0);
   outs(mid_line);
   move(0, 0);

   add_io(fd, 0);
   talkstart = time(0);

   while (1)
   {
     ch = igetkey();

     if (ch == I_OTHERDATA)
     {
       datac = recv(fd, data, sizeof(data), 0);
       if (datac <= 0)
         break;
/*
       if(data[0] == Ctrl('A'))
       {
         if(DL_func("SO/bwboard.so:vaBWboard",fd,1)==-2)
           break;
         continue;
       }
*/
       for (i = 0; i < datac; i++)
         do_talk_char(&itswin, data[i]);
     }
     else
     {
/*
       if(ch == Ctrl('A'))
       {
         data[0] = (char) ch;
         if(send(fd, data, 1, 0) != 1)
           break;
         if(DL_func("SO/bwboard.so:vaBWboard",fd,0)==-2)
           break;
       }
*/
       if (ch == Ctrl('C'))
       {
         if (im_leaving)
           break;
         move(b_lines, 0);
         clrtoeol();
         outs("�A���@�� Ctrl-C �N��������͸��o�I");
         im_leaving = 1;
         continue;
       }
       if (im_leaving)
       {
         move(b_lines, 0);
         clrtoeol();
         im_leaving = 0;
       }
       switch(ch)
       {
        case KEY_LEFT:
          ch = Ctrl('B');
          break;
        case KEY_RIGHT:
          ch = Ctrl('F');
          break;
        case KEY_UP:
          ch = Ctrl('P');
          break;
        case KEY_DOWN:
          ch = Ctrl('N');
          break;
       }

/*
       if (ch == KEY_LEFT)
          ch = Ctrl('B');
       else if  (ch == KEY_RIGHT)
          ch = Ctrl('F');
       else if  (ch == KEY_UP)
          ch = Ctrl('P');
       else if  (ch == KEY_DOWN)
          ch = Ctrl('N');

       if (isprint2(ch) || ch == Ctrl('H') || ch == '\177'
         || ch == Ctrl('G') || ch == Ctrl('M') || ch == Ctrl('J') ||
            ch == Ctrl('F') || ch == Ctrl('B') || ch == Ctrl('D') ||
            ch == Ctrl('E') || ch == Ctrl('K') ||
            ch == Ctrl('Y') || ch == Ctrl('P') || ch == Ctrl('N'))
       }*/
         myword++;
         data[0] = (char) ch;
         if (send(fd, data, 1, 0) != 1)
           break;
         do_talk_char(&mywin, *data);

       }
}
/*
       else if (ch == KEY_ESC)
          switch (KEY_ESC_arg) {
          case 'c':
             capture_screen();
             break;
          case 'n': {
             extern screenline* big_picture;
             screenline* screen0 = calloc(t_lines, sizeof(screenline));
             int y, x;

             memcpy(screen0, big_picture, t_lines * sizeof(screenline));
             add_io(0, 0);
             getyx(&y, &x);
             edit_note();
             move(y, x);
             memcpy(big_picture, screen0, t_lines * sizeof(screenline));
             free(screen0);
             redoscr();
             add_io(fd, 0);
             }
             break;
          }
       else if (ch == Ctrl('I'))
       {
         extern screenline* big_picture;
         screenline* screen0 = calloc(t_lines, sizeof(screenline));
         int y, x;

         memcpy(screen0, big_picture, t_lines * sizeof(screenline));
         add_io(0, 0);
         getyx(&y, &x);
         t_idle();
         move(y, x);
         memcpy(big_picture, screen0, t_lines * sizeof(screenline));
         free(screen0);
         redoscr();
         add_io(fd, 0);
       }
     }
   }
*/


   add_io(0, 0);
   close(fd);

   if (flog) {
      char ans[4];
      extern screenline *big_picture;
      extern uschar scr_lns;
      int i;

      time(&now);
      fprintf(flog, "\n[33;44m���O�e�� [%s] ...     [m\n", Cdatelite(&now));
      for (i = 0; i < scr_lns; i++)
         fprintf(flog, "%.*s\n", big_picture[i].len, big_picture[i].data);
      fclose(flog);
      more(fpath, NA);
      getdata(b_lines - 1, 0, "�M��(C) ���ܳƧѿ�(M) (C/M)?[C]",
         ans, 4, LCECHO,0);
      if (*ans == 'm') {
         fileheader mymail;
         char title[128];

         sethomeback(genbuf, cuser.userid);
         stampfile(genbuf, &mymail);
         mymail.savemode = 'H';        /* hold-mail flag */
         mymail.filemode = FILE_READ;
         strcpy(mymail.owner, "[��.��.��]");
         sprintf(mymail.title, "��ܰO�� [1;36m(%s)[m", getuserid(currutmp->destuid));
         sethomebackdir(title, cuser.userid);
         rec_add(title, &mymail, sizeof(mymail));
         f_mv(fpath, genbuf);
      }
      else
         unlink(fpath);
      flog = 0;
   }
   setutmpmode(XINFO);
}


static void
my_talk(uin)
  user_info *uin;
{
  int sock, msgsock, length, ch;//pkmode = 0;     //�P�������
  struct sockaddr_in server;
  pid_t pid;
  char c;
  char genbuf[4];
  uschar mode0 = currutmp->mode;

  ch = uin->mode;
  strcpy(currauthor, uin->userid);

  if (ch == EDITING || ch == TALK || ch == CHATING
      || ch == PAGE || ch == MAILALL || ch == FIVE || ch == CHC
      || !ch && (uin->chatid[0] == 1 || uin->chatid[0] == 3))
  {
    outs("�H�a�b����");
  }
  else if (!HAS_PERM(PERM_SYSOP) && (be_rejected(uin->userid) ||
      (!uin->pager && !can_override(uin->userid, cuser.userid))))
  {
    outs("��������I�s���F");
  }
  else if (!HAS_PERM(PERM_SYSOP) &&
           be_rejected(uin->userid) || uin->pager == 2)
  {
    outs("���ޱ��I�s���F");
  }
  else if (!HAS_PERM(PERM_SYSOP) &&
           !(is_friend(uin) & 2) && uin->pager == 4)
  {
    outs("���u�����n�ͪ��I�s");
  }
  else if (!(pid = uin->pid) || (kill(pid, 0) == -1))
  {
    resetutmpent();
    outs(msg_usr_left);
  }
  else
  {
    showplans(uin->userid);
    getdata(2, 0, "��L [y]�ͤ�[f]�U���l��[d]���t��[c]���H�� ��(Y/N)?[N]",
     genbuf, 4,LCECHO,0);
    if (*genbuf == 'y')
    {
      uin->dark_turn = 0;
      uin->turn = 0;
      log_usies("TALK ", uin->userid);
    }
    else if(*genbuf == 'd')
    {
       uin->dark_turn = 1;
       currutmp->turn = 0;
       uin->turn = 1;
    }
    else if (*genbuf == 'f')
    {
      uin->dark_turn = 0;
      currutmp->turn = 0;
      uin->turn = 1;
    }

    else if (*genbuf == 'c')
    {
      uin->dark_turn = 2;
      currutmp->turn = 0;
      uin->turn = 1;
    }

/*
    else if (*genbuf == 'p')
    {
      currutmp->turn = 0;
      uin->turn = 1;
    }*/
    else
      return;

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0)
    {
      perror("sock err");
      f_cat("adm/talk_err","sock err");
      return;
    }

    server.sin_family = PF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = 0;

    if (bind(sock, (struct sockaddr *) & server, sizeof server) < 0)
    {
      close(sock);
      perror("bind err");
      f_cat("adm/talk_err","bind err");
      return;
    }
    length = sizeof server;
    if (getsockname(sock, (struct sockaddr *) & server, &length) < 0)
    {
      close(sock);
      perror("sock name err");
      f_cat("adm/talk_err","sock_name err");
      return;
    }
    currutmp->sockactive = YEA;
    currutmp->sockaddr = server.sin_port;
    currutmp->destuid = uin->uid;

    setutmpmode(PAGE);

    uin->destuip = currutmp;
    kill(pid, SIGUSR1);
    clear();
    prints("���I�s %s.....\n��J Ctrl-D ����....", uin->userid);

    listen(sock, 1);
    add_io(sock, 5);
    while (1) {
      ch = igetch();
      if (ch == I_TIMEOUT) {
         ch = uin->mode;
         if (!ch && uin->chatid[0] == 1 && uin->destuip == currutmp) {
             bell();
             outmsg("���^����...");
             refresh();
         }
         else if (ch == EDITING || ch == TALK || ch == CHATING
             || ch == PAGE || ch == MAILALL|| ch == FIVE
             || !ch && (uin->chatid[0] == 1 || uin->chatid[0] == 3)) {
             add_io(0, 0);
             close(sock);
             currutmp->sockactive = currutmp->destuid = 0;
             pressanykey("�H�a�b����");
             return;
         }
         else {
#ifdef LINUX
          add_io(sock, 20);       /* added 4 linux... achen */
#endif
           move(0, 0);
           outs("�A");
           bell();

           uin->destuip = currutmp;
           if (kill(pid, SIGUSR1) == -1)
           {
#ifdef LINUX
            add_io(sock, 20);       /* added 4 linux... achen */
#endif
             pressanykey(msg_usr_left);
             return;
           }
           continue;
         }
      }

      if (ch == I_OTHERDATA)
        break;

      if (ch == '\004')
      {
        add_io(0, 0);
        close(sock);
        currutmp->sockactive = currutmp->destuid = 0;
        return;
      }
    }

    msgsock = accept(sock, (struct sockaddr *) 0, (int *) 0);
    if (msgsock == -1)
    {
      perror("accept");
      return;
    }
    add_io(0, 0);
    close(sock);
    currutmp->sockactive = NA;
    /* currutmp->destuid = 0 ; */
    read(msgsock, &c, sizeof c);

    if (c == 'y')
    {
      sprintf(save_page_requestor, "%s (%s)", uin->userid, uin->username);
      if (uin->turn)
       {
        if((uin->dark_turn == 1) && *genbuf == 'd' )
         DL_func("SO/dark.so:va_dark",msgsock, uin, 1);
        else if(*genbuf == 'f')
         DL_func("SO/five.so:va_gomoku",msgsock);
        else if((uin->dark_turn == 2) && *genbuf == 'c')
         DL_func("SO/chc.so:va_chc",msgsock,uin);
      }
      else if(*genbuf == 'y' )
       do_talk(msgsock);
    }
    else
    {
      move(9, 9);
      outs("�i�^���j ");
      switch (c)
      {
      case 'a':
        outs("�ڲ{�b�ܦ��A�е��@�|��A call �ڡA�n�ܡH");
        break;
      case 'b':
        outs("�藍�_�A�ڦ��Ʊ������A talk....");
        break;
      case 'd':
        outs("�ڭn�����o..�U���A��a..........");
        break;
      case 'c':
        outs("�Ф��n�n�ڦn�ܡH");
        break;
      case 'e':
        outs("��ڦ��ƶܡH�Х��ӫH��....");
        break;
      case 'f':
        {
          char msgbuf[60];
          read(msgsock, msgbuf, 60);
          outs("�藍�_�A�ڲ{�b�����A talk�A�]��\n");
          move(10,18);
          outs(msgbuf);
        }
        break;
      default:
        outs("�ڲ{�b���Q talk ��.....:)");
      }
      close(msgsock);
    }
  }
  currutmp->mode = mode0;
  currutmp->destuid = 0;
  pressanykey(NULL);
}


/* ------------------------------------- */
/* ��榡��Ѥ���                        */
/* ------------------------------------- */


#define US_PICKUP       1234
#define US_RESORT       1233
#define US_ACTION       1232
#define US_REDRAW       1231

static int
search_pickup(num, actor, pklist)
  int num;
  int actor;
  pickup pklist[];
{
  char genbuf[IDLEN + 2];

  getdata(b_lines - 1, 0, "�п�J�ϥΪ̩m�W�G", genbuf, IDLEN + 1, DOECHO,0);
  move(b_lines - 1, 0);
  clrtoeol();

  if (genbuf[0])
  {
    int n = (num + 1) % actor;
    str_lower(genbuf, genbuf);
    while (n != num)
    {
      if (strstr_lower(pklist[n].ui->userid, genbuf))
        return n;
      if (++n >= actor)
        n = 0;
    }
  }
  return -1;
}


static int
pickup_cmp(i, j)
  pickup *i, *j;
{
  switch (pickup_way)
  {
  case 0:
    {
      register int friend;

      if (friend = j->friend - i->friend)
        return friend;
    }
  case 1:
    return strcasecmp(i->ui->userid, j->ui->userid);
  case 2:
    return (i->ui->mode - j->ui->mode);
  case 3:
    return (i->idle - j->idle);
  case 4:
    return strcasecmp(i->ui->from, j->ui->from);
  }
}

static char *       /* Kaede show friend description */
friend_descript(uident)
  char *uident;
{
  static char *space_buf="                    ";
  static char desc_buf[80];
  char fpath[80], name[IDLEN + 2], *desc, *ptr;
  int len, flag;
  FILE *fp;
  char genbuf[200];

  setuserfile(fpath, friend_file[0]);

  if (fp = fopen(fpath, "r"))
  {
    sprintf(name, "%s ", uident);
    len = strlen(name);
    desc = genbuf + 13;

    while ((flag = (int)fgets(genbuf, STRLEN, fp)))
    {
      if (!memcmp(genbuf, name, len))
      {
        if (ptr = strchr(desc, '\n'))
          ptr[0] = '\0';
        if (desc) break;
      }
    }

    fclose(fp);

    if(desc && flag)
      strcpy(desc_buf, desc);
    else
      return space_buf;

    return desc_buf;
  }
  else
    return space_buf;
}

static void
pickup_user()
{
  static int real_name = 0;
  static int show_friend = 0;
  static int show_uid = 0;
  static int show_pid = 0;
  static int num = 0;
  char genbuf[200];
  int idle_time;

#ifdef WHERE
  extern struct FROMCACHE *fcache;
#endif

  register user_info *uentp;
  register pid_t pid0=0;  /* Ptt �w��                */
  register int   id0;   /*     US_PICKUP�ɪ���Х� */
  register int state = US_PICKUP, hate, ch;
  register int actor, head, foot;
  int badman;
  int savemode = currstat;
  time_t diff, freshtime, diff2;
  pickup pklist[USHM_SIZE];                     /* parameter Ptt�� */
   /* num : �{�b����Ц� foot: �������}�} */
  char buf[20];                                 /* actor:�@���h��user */
  char pagerchar[4] = "* o ";
  char *msg_pickup_way[PICKUP_WAYS] =
  { "�١I�B��",
    "���ͥN��",
    "���ͰʺA",
    "�o�b�ɶ�",
  };

#ifdef WHERE
  resolve_fcache();
#endif
  while (1)
  {
    if (state == US_PICKUP)
    {
      freshtime = 0;
    }

    if (utmpshm->uptime > freshtime)
    {
      time(&freshtime);
      friends_number = override_number = rejected_number = actor = ch = 0;

      while (ch < USHM_SIZE)
      { //check bugs??
        uentp = &(utmpshm->uinfo[ch++]);
        if (uentp->pid)
        {
          if (((is_rejected(uentp) & HRM) && !HAS_PERM(PERM_SYSOP)) ||
              (uentp->invisible && !(HAS_PERM(PERM_SYSOP) || HAS_PERM(PERM_SEECLOAK))))
            continue;           /* Thor: can't see anyone who rejects you. */
          if (uentp->userid[0] == 0) continue;  /* Ptt's bug */
//skybinary:�O�o���?? I guess....
/*
          if(cuser.port != 23)
              continue;*/
          if (!PERM_HIDE(currutmp) && PERM_HIDE(uentp))
             continue;

          head = is_friend(uentp) ;

          if ( (cuser.uflag & FRIEND_FLAG)
                && (!head || is_rejected(uentp)))
            continue;

#ifdef SHOW_IDLE_TIME

          {
            if(!uentp->lastact) uentp->lastact = time(0);
            diff = freshtime - uentp->lastact;
#ifdef DOTIMEOUT
            /* prevent fault /dev mount from kicking out users */

            if ((diff > cuser.idletime) && (diff < 60 * 60 * 24 * 5))
            {
              if ((kill(uentp->pid, SIGHUP) == -1) && (errno == ESRCH))
                memset(uentp, 0, sizeof(user_info));
              continue;
            }
#endif
          }
          pklist[actor].idle = diff;
#endif

          pklist[actor].friend = head;
          pklist[actor].ui = uentp;

          actor++;
        }
      }
      badman = rejected_number;

      state = US_PICKUP;

      if (!actor)
      {
        getdata(b_lines - 1, 0, "�A���B���٨S�W���A�n�ݬݤ@����Ͷ�(Y/N)�H[Y]", genbuf, 4, LCECHO,"Y");
        if (genbuf[0] != 'n')
        {
          cuser.uflag &= ~FRIEND_FLAG;
          continue;
        }
        return;
      }
    }

    if (state >= US_RESORT)
      qsort(pklist, actor, sizeof(pickup), pickup_cmp);

    if (state >= US_ACTION)
    {
      showtitle2(BoardName,(cuser.uflag & FRIEND_FLAG)? 
       "�n�ͦC��": "�𶢲��",BBSNAME);
      if((cuser.uflag & FRIEND_FLAG))
        {
         friends_number=friends_number/2;
         override_number=override_number/2;
         badman=badman/2;
        }
      prints("  �ƧǡG[%s]  [1;32m�ڪ��B�͡G%-4d[33m�P�ڬ��͡G%-4d[31m�a�H�G%-3d[36m�O�͡G??[0m\n"
        "[1m[41m  %s [44mP%c�N��         [43m%-17s[42m%-17s[46m%-13s[45m%-10s [0m\n",
        msg_pickup_way[pickup_way], //actor,
        friends_number, override_number, badman,
#ifdef SHOWUID
        show_uid ? "UID" :
#endif
        "No.",
        (HAS_PERM(PERM_SEECLOAK) || HAS_PERM(PERM_SYSOP)) ? 'C' : ' ',

#ifdef REALINFO
        real_name ? "�m�W" :
#endif

        "�ʺ�", show_friend ? "�n�ʹy�z" : "�G�m",
/*
#ifdef SHOWTTY
        show_tty ? "TTY " :
#endif
*/
        "�ʺA",
#ifdef SHOWPID
        show_pid ? "       PID" :
#endif
#ifdef SHOW_IDLE_TIME
        "�߱�  �o�b"
#else
        "�߱�"
#endif

        );
    }
    else
    {
      move(3, 0);
      clrtobot();
    }

    if(pid0)
       for (ch = 0; ch < actor; ch++)
        {
          if(pid0 == (pklist[ch].ui)->pid &&
           id0  == 256 * pklist[ch].ui->userid[0] + pklist[ch].ui->userid[1])
            {
               num = ch;
            }
        }

    if (num < 0)
      num = 0;
    else if (num >= actor)
      num = actor - 1;

    head = (num / p_lines) * p_lines;
    foot = head + p_lines;
    if (foot > actor)
      foot = actor;


    for (ch = head; ch < foot; ch++)
    {
      uentp = pklist[ch].ui;
      if (!uentp->pid)
      {
        state = US_PICKUP;
        break;
      }
#ifdef SHOW_IDLE_TIME
      diff = pklist[ch].idle;
      diff2 = diff;
      idle_time = diff2 / 60;
      if (diff2 > 0)
      {
        if(idle_time < 3)
         sprintf(buf, "[1;33m%3d'%02d[m", diff2 / 60, diff2 % 60);
        if((idle_time>= 3)&&(idle_time <5))
         sprintf(buf, "[1;32m%3d'%02d[m", diff2 / 60, diff2 % 60);
        if((idle_time >= 5)&&(idle_time < 7))
         sprintf(buf, "[1;34m%3d'%02d[m", diff2 / 60, diff2 % 60);
        if((idle_time >= 7)&&(idle_time <= cuser.idletime/60))
         sprintf(buf, "[1;5;31m%3d'%02d[m", diff2 / 60, diff2 % 60);
      }
      else
        buf[0] = '\0';
#else
      buf[0] = '\0';
#endif
#ifdef SHOWPID
      if (show_pid)
        sprintf(buf, "%6d", uentp->pid);
#endif
      state = (currutmp == uentp) ? 6 : pklist[ch].friend;
      if (PERM_HIDE(uentp))
         state = PERM_HIDE(currutmp) ? 5 : 0;
      if (PERM_HIDE(currutmp) && state == 3)
         state = 6;
      hate = is_rejected(uentp);
      diff = uentp->pager & !(hate & HRM);
/* skybinary �ױ��C�ⱱ��X */
//      strip_ansi(uentp->username,uentp->username,0);

      prints("%5d %c%c%s%-13s%-17.16s[m%s%-17.16s%-13.12s%-4.4s%s\n",
#ifdef SHOWUID
      show_uid ? uentp->uid :
#endif
      (ch + 1),
      (hate & HRM)? 'X' :
      (uentp->pager == 4) ? 'f' : (uentp->pager == 3) ? 'W' :
      (uentp->pager == 2) ? '-' : pagerchar[(state & 2) | diff],
      (uentp->invisible ? ')' : ' '),
      (hate & IRH)? fcolor[4] : fcolor[state],

      uentp->userid,
/*
#ifdef REALINFO
      real_name ? uentp->realname :
#endif*/
      uentp->username, /*state*/ 1 ? "" : "",
      show_friend ? friend_descript(uentp->userid) :
      ((uentp->pager != 2 && uentp->pager != 3 && diff || HAS_PERM(PERM_SYSOP)) ?
#ifdef WHERE
      uentp->from_alias ? fcache->replace[uentp->from_alias] : uentp->from
#else
      uentp->from
#endif
      :"*"),
/*
#ifdef SHOWTTY
      show_tty ? uentp->tty :
#endif
*/
      modestring(uentp, 0),
      uentp->birth?"�جP":uentp->feeling[0]?uentp->feeling:"����",
      buf);
    }

    if (state == US_PICKUP)
      continue;

    move(b_lines, 0);

 sprintf(genbuf,"\
[4%d;1m��[[1;36mTAB/f[37m]�Ƨ�/�n�͢w[[36ma/d/o[37m]��͢w[[36mt[37m]��Ѣw\
[[36mq[37m]�d�ߢw[[36mw[37m]�����w[[36mm[37m]�H�H�w[[36mh[37m]����\
��[m",cuser.color);

outs(genbuf);


    state = 0;
    while (!state)
    {
       ch = cursor_key(num + 3 - head, 0);

      if (ch == KEY_RIGHT || ch == '\n' || ch == '\r')
        ch = 't';

      switch (ch)
      {
      case KEY_LEFT:
      case 'e':
      case 'E':
        return;

      case KEY_TAB:
       {
         char ans[3] = "0";
         while(!ans[0] || ans[0] > '4' || ans[0] < '1')
           getdata(b_lines-1, 0,"�ƧǤ覡 1.�n�� 2.�N�� 3.�ʺA 4.�o�b"
         , ans, 2, DOECHO,"1");
            if(!ans[0])
            {
              state = US_REDRAW;
              break;
            }
         pickup_way = atoi(ans) - 1;
          if(pickup_way > 5 || pickup_way < 0) pickup_way = 0;
         state = US_PICKUP;
         num = 0;
         break;
       }
      case KEY_DOWN:
      case 'n':
        if (++num < actor)
        {
          if (num >= foot)
            state = US_REDRAW;
          break;
        }

      case '0':
      case KEY_HOME:
        num = 0;
        if (head)
          state = US_REDRAW;
        break;
      case 'M':
         if (HAS_PERM(PERM_BASIC)) {
            char buf[64];
            sprintf(buf, "�߱� [%s]�G", currutmp->feeling);
            if (!getdata(1, 0, buf, currutmp->feeling, 5, DOECHO,currutmp->feeling))
               strcpy(currutmp->feeling, cuser.feeling);
            state = US_PICKUP;
         }
         break;



      case 'N':
         if (HAS_PERM(PERM_BASIC)) {
            char buf[100];

            sprintf(buf, "�ʺ� [%s]�G", currutmp->username);
            if (!getdata(1, 0, buf, currutmp->username, 17, DOECHO,0))
               strcpy(currutmp->username, cuser.username);

            state = US_PICKUP;
         }
         break;

      case 'H':
         if (HAS_PERM(PERM_PURPLE)) {
            currutmp->userlevel ^= PERM_DENYPOST;
            state = US_PICKUP;
         }
         break;

      case 'D':
         if (HAS_PERM(PERM_SYSOP)) {
            char buf[100];

            sprintf(buf, "�N�� [%s]�G", currutmp->userid);
            if (!getdata(1, 0, buf, currutmp->userid, IDLEN + 1, DOECHO,0))
               strcpy(currutmp->userid, cuser.userid);

            state = US_PICKUP;
         }
         break;
      case 'F':
        {
            char buf[100];
            if(!HAS_PERM(PERM_SYSOP) && !HAS_PERM(PERM_FROM))
            {
              if(check_money(500)) break;
              demoney(500);
              pressanykey("�ק�G�m��h 500 ��");
            }
            sprintf(buf, "�G�m [%s]�G", currutmp->from);
            if (getdata(1, 0, buf, currutmp->from, 17, DOECHO,currutmp->from))
            currutmp->from_alias=0;
            state = US_PICKUP;
          }
         break;
      case ' ':
      case KEY_PGDN:
      case Ctrl('F'):
        if (foot < actor)
        {
          num += p_lines;
          state = US_REDRAW;
          break;
        }
        if (head)
          num = 0;
        state = US_PICKUP;
        break;

      case KEY_UP:
        if (--num < head)
        {
          if (num < 0)
          {
            num = actor - 1;
            if (actor == foot)
              break;
          }
          state = US_REDRAW;
        }
        break;

      case KEY_PGUP:
      case Ctrl('B'):
      case 'P':
        if (head)
        {
          num -= p_lines;
          state = US_REDRAW;
          break;
        }

      case KEY_END:
      case '$':
        num = actor - 1;
        if (foot < actor)
          state = US_REDRAW;
        break;

      case '/':
        {
          int tmp;
          if ((tmp = search_pickup(num, actor, pklist)) >= 0)
            num = tmp;
          state = US_REDRAW;
        }
        break;

      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
        {                       /* Thor: �i�H���Ʀr����ӤH */
          int tmp;
          if ((tmp = search_num(ch, actor - 1)) >= 0)
            num = tmp;
          state = US_REDRAW;
        }
        break;

#ifdef  REALINFO
      case 'R':         /* ��ܯu��m�W */
        if (HAS_PERM(PERM_SYSOP))
          real_name ^= 1;
        state = US_PICKUP;
        break;
#endif
/*
#ifdef  SHOWUID
      case 'U':
        if (HAS_PERM(PERM_SYSOP))
          show_uid ^= 1;
        state = US_PICKUP;
        break;
#endif
#ifdef  SHOWTTY
      case 'Y':
        if (HAS_PERM(PERM_SYSOP))
          show_tty ^= 1;
        state = US_PICKUP;
        break;
#endif
*/
#ifdef  SHOWPID
      case 'I':
        if (HAS_PERM(PERM_SYSOP))
          show_pid ^= 1;
        state = US_PICKUP;
        break;
#endif

      case 'b':         /* broadcast */
        if(HAS_PERM(PERM_SYSOP) || cuser.uflag & FRIEND_FLAG)
        {
        int actor_pos = actor;
        char ans[4];
        state = US_PICKUP;

/*        {
          if(check_money(300))
            break;
          demoney(300);
          pressanykey("��h300���s������");
        } */
        if (!getdata(0, 0, "�s���T��:", genbuf + 1, 60, DOECHO,0))
          break;
        if (getdata(0, 0, "�T�w�s��? [Y]", ans, 4, LCECHO,0) && *ans == 'n')
          break;
        genbuf[0] = HAS_PERM(PERM_SYSOP) ? 2 : 0;

        while (actor_pos)
        {
            uentp = pklist[--actor_pos].ui;
            if (uentp->pid &&
                currpid != uentp->pid &&
                kill(uentp->pid, 0) != -1 &&
                (HAS_PERM(PERM_SYSOP) || (uentp->pager != 3 &&
                 (uentp->pager != 4 || is_friend(uentp) & 4))))
                my_write(uentp->pid, genbuf);
        }
      }
      break;

      case 's':         /* ��ܦn�ʹy�z */
        show_friend ^= 1;
        state = US_PICKUP;
        break;

      case 'u':         /* �u�W�ק��� */
        if (!HAS_PERM(PERM_ACCOUNTS))
         continue;
      case 'K':         /* ���a�J��X�h */
      case 'g':         /* �ק�RPG��� */
        if (!HAS_PERM(PERM_SYSOP))
          continue;
        state = US_ACTION;
        break;

      case 't':
      case 'w':
        if (!(cuser.userlevel & PERM_PAGE))
          continue;
        state = US_ACTION;
        break;

      case 'a':
      case 'd':
      case 'o':
      case 'f':
        if (!HAS_PERM(PERM_LOGINOK))  /* ���U�~�� Friend */
          break;
        if (ch == 'f')
        {
          cuser.uflag ^= FRIEND_FLAG;
          state = US_PICKUP;
          break;
        }
        state = US_ACTION;
        break;

      case 'q':
      case 'm':
      case 'r':
      case 'l':
      case 'h':
        state = US_ACTION;
        break;
      case 'c':

      case 'p':
         if (HAS_PERM(PERM_BASIC)) {
            t_pager();
            state = US_PICKUP;
         }
         break;
      case KEY_ESC:
         if (KEY_ESC_arg == 'c')
            capture_screen();
         else if (KEY_ESC_arg == 'n') {
            edit_note();
            state = US_PICKUP;
         }
         break;
      default:          /* refresh user state */
        state = US_PICKUP;
      }
    }

    if (state != US_ACTION)
        {
         pid0 = 0;
         continue;
        }
    uentp = pklist[num].ui;
    pid0 = uentp->pid;
    id0  = 256 * uentp->userid[0] + uentp->userid[1];

    if (ch == 'w')
    {
      if ((uentp->pid != currpid) &&
          (HAS_PERM(PERM_SYSOP) || ( uentp->pager != 3 &&
            (is_friend(uentp) & 2 || uentp->pager != 4) )))
      {
        if(HAS_HABIT(HABIT_LBAR))
         cursor_show(num + 3 - head, 0);
        my_write(uentp->pid, "���u Call-In�G");
      }
      else
        state = 0;
    }
    else if (ch == 'l')
    {                           /* Thor: �� Last call in */
      t_display();
      state = US_PICKUP;
    }
    else
    {
      switch (ch)
      {
      case 'r':
        m_read();
        break;

      case 'a':
        friend_add(uentp->userid, FRIEND_OVERRIDE);
        friend_load();
        state = US_PICKUP;
        break;

      case 'd':
        friend_delete(uentp->userid, FRIEND_OVERRIDE);
        friend_load();
        state = US_PICKUP;
        break;
      case 'o':
        t_override();
        state = US_PICKUP;
        break;

      case 'K':

        if (uentp->pid && (kill(uentp->pid, 0) != -1))
        {
          move(1, 0);
          clrtobot();
          move(2, 0);
          my_kick(uentp);
          state = US_PICKUP;
        }
        break;

      case 'm':
        stand_title("�H  �H");
        prints("���H�H�G%s", uentp->userid);
        my_send(uentp->userid);

      case 'q':
        strcpy(currauthor, uentp->userid);
        my_query(uentp->userid);
        break;

      case 'u':         /* Thor: �i�u�W�d�ݤέק�ϥΪ� */
        {
          int id;
          userec muser;
           strcpy(currauthor, uentp->userid);
          stand_title("�ϥΪ̳]�w");
          move(1, 0);
          if (id = getuser(uentp->userid))
          {
            memcpy(&muser, &xuser, sizeof(muser));
            u_data(&muser,1,id);
          }
         }
        break;

      case 'h':         /* Wildcat: �� Help */
        if(HAS_PERM(PERM_SYSOP))
          more("etc/help/talk_sysop.hlp",YEA);
        if(HAS_PERM(PERM_PAGE) && !HAS_PERM(PERM_SYSOP))
//          more("etc/help/talk_page.hlp",YEA);
          film_out(FILM_T_PAGE,-1);
        if(!HAS_PERM(PERM_PAGE))
//          more("etc/help/talk_user.hlp",YEA);
          film_out(FILM_T_USR,-1);
        break;

      case 't':
        if (uentp->pid != currpid)
        {
          move(1, 0);
          clrtobot();
          move(3, 0);
          my_talk(uentp);
          state = US_PICKUP;
        }
      }
    }
    setutmpmode(savemode);
  }
}


static int
listcuent(uentp)
  user_info *uentp;
{
  if ((uentp->uid != usernum) && (!uentp->invisible || HAS_PERM(PERM_SYSOP) || HAS_PERM(PERM_SEECLOAK)))
    AddNameList(uentp->userid);
  return 0;
}


static void
creat_list()
{
  CreateNameList();
  apply_ulist(listcuent);
}


int
t_users()
{
  int destuid0 = currutmp->destuid;
  int mode0 = currutmp->mode;
  int stat0 = currstat;

  if (chkmailbox())
     return;
  setutmpmode(LUSERS);
  pickup_user();
  currutmp->mode = mode0;
  currutmp->destuid = destuid0;
  currstat = stat0;
  return 0;
}


int
t_pager()
{
  currutmp->pager = (currutmp->pager + 1) % 5;
  return 0;
}


int
t_idle()
{
  int destuid0 = currutmp->destuid;
  int mode0 = currutmp->mode;
  int stat0 = currstat;

  int tab[11] = {0x7B6F, 0x4924, 0x73E7, 0x79E7, 0x49ED,
  0x79CF, 0x7BCF, 0x4927, 0x7BEF, 0x79EF, 0x0410};
  time_t now, end;
  char genbuf[20],buf[80];

  struct timeval tv = {1, 100};
  char passbuf[PASSLEN], *timestr;
  time(&now);

  setutmpmode(IDLE);
  getdata(b_lines - 1, 0, "�z�ѡG[0]�o�b (1)���q�� (2)�V�� (3)���O�� (4)�˦� (5)ù�� (6)��L (Q)�S�ơH", genbuf, 3, DOECHO,0);
  if (genbuf[0] == 'q' || genbuf[0] == 'Q') {
     currutmp->mode = mode0;
     currstat = stat0;
     return 0;
   }
  else if (genbuf[0] >= '1' && genbuf[0] <= '6')
    currutmp->destuid = genbuf[0] - '0';
  else
    currutmp->destuid = 0;

  if (currutmp->destuid == 6)
    if (!cuser.userlevel || !getdata(b_lines - 1, 0, "�o�b���z�ѡG", currutmp->chatid, 11, DOECHO,0))
      currutmp->destuid = 0;
  if (getdata(b_lines, 0, "�� �п�J��w����(Enter = �L��)�G",
           buf, 10, DOECHO,0))
    end = now + atoi(buf);
  else
    end = now * 2;
  clear();
  while (time(&now) <= end) {
    int rset = 1, col = 9, row = 9;
    time(&now);
    strftime(buf, 80, "%T", localtime(&now));
    move(col, row);
    for (timestr = buf; *timestr != '\0'; timestr++, row += 8)
      draw(tab[*timestr - '0'], col, row);

   move(b_lines - 2, 0);
   sprintf(buf, "(��w�ù�)�o�b��]: %s", (currutmp->destuid != 6) ?
         IdleTypeTable[currutmp->destuid] : currutmp->chatid);
   outs(buf); 
    refresh();
    if (select(1, (fd_set *) & rset, NULL, NULL, &tv) != 0) {
      igetch();
      getdata(b_lines - 1, 0, MSG_PASSWD, passbuf, PASSLEN, PASS,0);
      passbuf[8]='\0';
      if (chkpasswd(cuser.passwd, passbuf))
        break;
    }
  }

/*
  do
  {
   move(b_lines - 2, 0);
   clrtoeol();
   sprintf(buf, "(��w�ù�)�o�b��]: %s", (currutmp->destuid != 6) ?
         IdleTypeTable[currutmp->destuid] : currutmp->chatid);
   outs(buf);
   refresh();
   getdata(b_lines - 1, 0, MSG_PASSWD, passbuf, PASSLEN, PASS,0);
   passbuf[8]='\0';
  }while(!chkpasswd(cuser.passwd, passbuf) && strcmp(STR_GUEST,cuser.userid));
*/
  currutmp->mode = mode0;
  currutmp->destuid = destuid0;
  currstat = stat0;

  return 0;
}


int
t_query()
{
  char uident[STRLEN];

  stand_title("�d�ߺ���");
  usercomplete(msg_uid, uident);
  if (uident[0])
    my_query(uident);
  return 0;
}


int
t_talk()
{
  char uident[16];
  int tuid, unum, ucount;
  user_info *uentp;
  char genbuf[4];

  if (count_ulist() <= 1)
  {
    outs("�ثe�u�W�u���z�@�H�A���ܽЪB�ͨӥ��{�i" BOARDNAME "�j�a�I");
    return XEASY;
  }
  stand_title("���}�ܧX�l");
  creat_list();
  namecomplete(msg_uid, uident);
  if (uident[0] == '\0')
    return 0;

  move(3, 0);
  if (!(tuid = searchuser(uident)) || tuid == usernum)
  {
    pressanykey(err_uid);
    return 0;
  }

  /* ----------------- */
  /* multi-login check */
  /* ----------------- */

  unum = 1;
  while ((ucount = count_logins(cmpuids, tuid, 0)) > 1)
  {
    outs("(0) ���Q talk �F...\n");
    count_logins(cmpuids, tuid, 1);
    getdata(1, 33, "�п�ܤ@�Ӳ�ѹ�H [0]�G", genbuf, 4, DOECHO,0);
    unum = atoi(genbuf);
    if (unum == 0)
      return 0;
    move(3, 0);
    clrtobot();
    if (unum > 0 && unum <= ucount)
      break;
  }

  if (uentp = (user_info *) search_ulistn(cmpuids, tuid, unum))
    my_talk(uentp);

  return 0;
}


/* ------------------------------------- */
/* ���H�Ӧ���l�F�A�^���I�s��            */
/* ------------------------------------- */


user_info *uip;

void
talkreply()
{
  int a;
  struct hostent *h;
  char hostname[STRLEN];
  char buf[4];
  struct sockaddr_in sin;
  char genbuf[200];
//  int pkmode = 0;  // �P�������

  talkrequest = NA;
  uip = currutmp->destuip;
  sprintf(page_requestor, "%s (%s)", uip->userid, uip->username);
  currutmp->destuid = uip->uid;
  currstat = XMODE;             /* �קK�X�{�ʵe */

  clear();
  outs("\n\n\
       (Y) ���ڭ� talk �a�I     (A) �ڲ{�b�ܦ��A�е��@�|��A call ��\n\
       (N) �ڲ{�b���Q talk      (B) �藍�_�A�ڦ��Ʊ������A talk\n\
       (C) �Ф��n�n�ڦn�ܡH     (D) �ڭn�����o..�U���A��a.......\n\
       (E) ���ƶܡH�Х��ӫH     (F) [1;33m�ڦۤv��J�z�Ѧn�F...[m\n\n");

  getuser(uip->userid);
  currutmp->msgs[0].last_pid = uip->pid;
  strcpy(currutmp->msgs[0].last_userid, uip->userid);
  strcpy(currutmp->msgs[0].last_call_in, "�I�s�B�I�s�Ať��Ц^�� (Ctrl-R)");
  prints("���Ӧ� [%s]�A�@�W�� %d ���A�峹 %d �g\n",
    uip->from, xuser.numlogins, xuser.numposts);

  showplans(uip->userid);
  show_last_call_in();
  sprintf(genbuf, "�A�Q�� %s %s�ܡH�п��(Y/N/A/B/C/D)[Y] ",
//  page_requestor,"���");
 page_requestor, currutmp->turn? "�U��" : "���" );

  getdata(0, 0, genbuf, buf, 4, LCECHO,0);

  if (uip->mode != PAGE && uip->mode != CHICKENPAGE) {
     sprintf(genbuf, "%s�w����I�s�A��Enter�~��...", page_requestor);
     getdata(0, 0, genbuf, buf, 4, LCECHO,0);
     return;
  }

  currutmp->msgcount = 0;
  strcpy(save_page_requestor, page_requestor);
  memset(page_requestor, 0, sizeof(page_requestor));

  gethostname(hostname, STRLEN);

  if (!(h = gethostbyname(hostname)))
  {
    perror("gethostbyname");
    return;
  }
  memset(&sin, 0, sizeof sin);
  sin.sin_family = h->h_addrtype;
  memcpy(&sin.sin_addr, h->h_addr, h->h_length);
  sin.sin_port = uip->sockaddr;
  a = socket(sin.sin_family, SOCK_STREAM, 0);
  if ((connect(a, (struct sockaddr *) & sin, sizeof sin)))
  {
    perror("connect err");
    return;
  }

  if (!buf[0] || !strchr("abcdefn", buf[0]))
  {
    buf[0] = 'y';
  }
  write(a, buf, 1);
  if (buf[0] == 'f' || buf[0] == 'F')
   {
     if (!getdata(b_lines, 0, "���� talk ����]�G", genbuf, 60, DOECHO,0))
       strcpy(genbuf, "���i�D�A�� !! ^o^");
     write(a, genbuf, 60);
   }
  if (buf[0] == 'y')
  {
   if (currutmp->turn)
   {
    if(currutmp->dark_turn)
    {
     if(currutmp->dark_turn == 1)
      DL_func("SO/dark.so:va_dark",a, uip, 0);
     else if(currutmp->dark_turn == 2)
      DL_func("SO/chc.so:va_chc",a,uip);
    }
    else
      DL_func("SO/five.so:va_gomoku",a);
   }
   else
    do_talk(a);
  }
  else
     close(a);
  clear();
}


/* ------------------------------------- */
/* ���ͰʺA²��                          */
/* ------------------------------------- */


int
shortulist(uentp)
  user_info *uentp;
{
  static int lineno, fullactive, linecnt;
  static int moreactive, page, num;
  char uentry[50];
  int state;

  if (!lineno)
  {
    lineno = 3;
    page = moreactive ? (page + p_lines * 3) : 0;
    linecnt = num = moreactive = 0;
    move(1, 70);
    prints("Page: %d", page / (p_lines) / 3 + 1);
    move(lineno, 0);
  }
  if (uentp == NULL)
  {
    int finaltally;

    clrtoeol();
    move(++lineno, 0);
    clrtobot();
    finaltally = fullactive;
    lineno = fullactive = 0;
    return finaltally;
  }
  if ((!HAS_PERM(PERM_SYSOP) && !HAS_PERM(PERM_SEECLOAK) && uentp->invisible) ||
      ((is_rejected(uentp) & HRM) && !HAS_PERM(PERM_SYSOP)))
  {
    if (lineno >= b_lines)
      return 0;
    if (num++ < page)
      return 0;
    memset(uentry, ' ', 25);
    uentry[25] = '\0';
  }
  else
  {
    fullactive++;
    if (lineno >= b_lines)
    {
      moreactive = 1;
      return 0;
    }
    if (num++ < page)
      return 0;

    state = (currutmp == uentp) ? 6 : is_friend(uentp);

    if (PERM_HIDE(uentp))
       state = PERM_HIDE(currutmp) ? 5 : 0;

    if (PERM_HIDE(currutmp) && state == 3)
       state = 6;

    sprintf(uentry, "%s%-13s%c%-10s%s ", fcolor[state],
      uentp->userid, uentp->invisible ? '#' : ' ',
      modestring(uentp, 1), state ? "[0m" : "");
  }
  if (++linecnt < 3)
  {
    strcat(uentry, "�x");
    outs(uentry);
  }
  else
  {
    outs(uentry);
    linecnt = 0;
    clrtoeol();
    move(++lineno, 0);
  }
  return 0;
}


static void
do_list(modestr)
  char *modestr;
{
  int count;

  //showtitle(modestr, BoardName);
  showtitle2(BoardName,modestr,BBSNAME);
  outc('\n');
  outs(msg_shortulist);

  friends_number = override_number = 0;
  if (apply_ulist(shortulist) == -1)
  {
    outs(msg_nobody);
  }
  else
  {
    time_t thetime = time(NULL);

    count = shortulist(NULL);
    move(b_lines, 0);
    prints("[1;37;46m  �W���`�H�ơG%-7d[32m�ڪ��B�͡G%-6d"
      "[33m�P�ڬ��͡G%-8d[30m%-23s[37;40;0m",
      count, friends_number, override_number, Cdate(&thetime));
    refresh();
  }
}


int
t_list()
{
  setutmpmode(LUSERS);
  do_list("�ϥΪ̪��A");
  igetch();
  return 0;
}

/*
int
t_friends()
{
  if (friendcount)
  {
    setutmpmode(FRIEND);

    pickup_user();

    if (!(friends_number || override_number))
    {
      outs("�A���@�U�a�A�]�\\�L�̫ݷ|��N�W�u�F�C");
      return XEASY;
    }
    return 0;
  }
  else
  {
    outs("�ثe�٨S�]�w�n�ͦW��");
    return XEASY;
  }
}
*/


void
t_aloha()
{
   int i;
   user_info *uentp;
   pid_t pid;
   char buf[100];

   sprintf(buf + 1, "[1;33;44m�� %s(%s) �W���F! [0m",
      cuser.userid, cuser.username);
   *buf = 0;

    /* Thor: �S�O�`�N, �ۤv�W�����|�q���ۤv... */

   for (i = 0; i < USHM_SIZE; i++) {
      uentp = &utmpshm->uinfo[i];
      if ((pid = uentp->pid) && (kill(pid, 0) != -1) &&
          uentp->pager && (is_friend(uentp) & 2) &&
          strcmp(uentp->userid, cuser.userid))
         my_write(uentp->pid, buf);
   }
}

int
lockutmpmode(int unmode)
{
  if (count_multiplay(unmode))
  {
   char buf[80];
   sprintf(buf,"��p! �z�w����L�u�ۦP��ID���b%s",ModeTypeTable[unmode]);
   pressanykey(buf);
   return 1;
  }
  setutmpmode(unmode);
  currutmp->lockmode = unmode;
  return 0;
}

int
unlockutmpmode()
{
  currutmp->lockmode = 0;
}




