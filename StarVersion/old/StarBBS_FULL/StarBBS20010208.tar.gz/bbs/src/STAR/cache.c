/*-------------------------------------------------------*/
/* cache.c      ( NTHU CS MapleBBS Ver 2.36 )            */
/*-------------------------------------------------------*/
/* target : cache up data by shared memory               */
/* create : 95/03/29                                     */
/* update : 95/12/15                                     */
/*-------------------------------------------------------*/


#include "bbs.h"

#ifdef  HAVE_MMAP
#include <sys/mman.h>
#else
int usernumber;
#endif
struct UCACHE *uidshm;

/*-------------------------------------------------------*/
/* .PASSWDS cache                                        */
/*-------------------------------------------------------*/


#ifndef HAVE_MMAP
static int
fillucache(uentp)
  userec *uentp;
{
  if (usernumber < MAXUSERS)
  {
    strncpy(uidshm->userid[usernumber], uentp->userid, IDLEN + 1);
    uidshm->userid[usernumber++][IDLEN] = '\0';
  }
  return 0;
}
#endif


/* -------------------------------------- */
/* (1) �t�αҰʫ�A�Ĥ@�� BBS user ��i�� */
/* (2) .PASSWDS ��s��                    */
/* -------------------------------------- */
reload_ucache()
{
   if (uidshm->busystate)
   {
     /* ------------------------------------------ */
     /* ��L user ���b flushing ucache ==> CSMA/CD */
     /* ------------------------------------------ */

     if (uidshm->touchtime - uidshm->uptime > 30)
     {
       uidshm->busystate = 0;  /* leave busy state */
       uidshm->uptime = uidshm->touchtime - 1;
#if !defined(_BBS_UTIL_C_)
       log_usies("CACHE", "refork token");
#endif
     }
     else
       sleep(1);
   }
   else
   {
     uidshm->busystate = 1;    /* enter busy state */
#ifdef  HAVE_MMAP
     {
       register int fd, usernumber;

       usernumber = 0;

       if ((fd = open(".PASSWDS", O_RDONLY)) > 0)
       {
         caddr_t fimage, mimage;
         struct stat stbuf;

         fstat(fd, &stbuf);
         fimage = mmap(NULL, stbuf.st_size, PROT_READ, MAP_SHARED, fd, 0);
         if (fimage == (char *) -1)
           exit(-1);
         close(fd);
         fd = stbuf.st_size / sizeof(userec);
         if (fd > MAXUSERS)
           fd = MAXUSERS;
         for (mimage = fimage; usernumber < fd; mimage += sizeof(userec))
         {
           memcpy(uidshm->userid[usernumber++], mimage, IDLEN);
         }
         munmap(fimage, stbuf.st_size);
       }
       uidshm->number = usernumber;
     }
#else
     usernumber = 0;
     rec_apply(".PASSWDS", fillucache, sizeof(userec));
     uidshm->number = usernumber;
#endif

     /* �� user ��Ƨ�s��A�]�w uptime */
     uidshm->uptime = uidshm->touchtime;

#if !defined(_BBS_UTIL_C_)
     log_usies("CACHE", "reload ucache");
#endif
     uidshm->busystate = 0;    /* leave busy state */
   }
}


void
resolve_ucache()
{
  if (uidshm == NULL)
  {
    uidshm = shm_new(UIDSHM_KEY, sizeof(*uidshm));
    if (uidshm->touchtime == 0)
      uidshm->touchtime = 1;
  }
  while (uidshm->uptime < uidshm->touchtime)
     reload_ucache();
}

int
ci_strcmp(s1, s2)
  register char *s1, *s2;
{
  register int c1, c2, diff;

  do
  {
    c1 = *s1++;
    c2 = *s2++;
    if (c1 >= 'A' && c1 <= 'Z')
      c1 |= 32;
    if (c2 >= 'A' && c2 <= 'Z')
      c2 |= 32;
    if (diff = c1 - c2)
      return (diff);
  } while (c1);
  return 0;
}


int
searchuser(userid)
  char *userid;
{
  register char *ptr;
  register int i, j;
  resolve_ucache();
  i = 0;
  j = uidshm->number;
  while (i < j)
  {
    ptr = uidshm->userid[i++];
    if (!ci_strcmp(ptr, userid))
    {
      strcpy(userid, ptr);
      return i;
    }
  }
  return 0;
}


#if !defined(_BBS_UTIL_C_)
int
getuser(userid)
  char *userid;
{
  int uid;

  if (uid = searchuser(userid))
    rec_get(fn_passwd, &xuser, sizeof(xuser), uid);
  return uid;
}


char *
getuserid(num)
  int num;
{
  if (--num >= 0 && num < MAXUSERS)
  {
    return ((char *) uidshm->userid[num]);
  }
  return NULL;
}


void
setuserid(num, userid)
  int num;
  char *userid;
{
  if (num > 0 && num <= MAXUSERS)
  {
    if (num > uidshm->number)
      uidshm->number = num;
    strncpy(uidshm->userid[num - 1], userid, IDLEN + 1);
  }
}


int
searchnewuser(mode)
  int mode;

/* 0 ==> ��L���b�� */
/* 1 ==> �إ߷s�b�� */
{
  register int i, num;

  resolve_ucache();
  num = uidshm->number;
  i = 0;
  while (i < num)
  {
    if (!uidshm->userid[i++][0])
      return (i);
  }
  if (mode && (num < MAXUSERS))
    return (num + 1);
  return 0;
}


#if 0
int
apply_users(func)
  void (*func) ();
{
  register int i, num;

  resolve_ucache();
  num = uidshm->number;
  for (i = 0; i < num; i++)
    (*func) (uidshm->userid[i], i + 1);
  return 0;
}
#endif


char *
u_namearray(buf, pnum, tag)
  char buf[][IDLEN + 1], *tag;
  int *pnum;
{
  register struct UCACHE *reg_ushm = uidshm;
  register char *ptr, tmp;
  register int n, total;
  char tagbuf[STRLEN];
  int ch, ch2, num;

  resolve_ucache();
  if (*tag == '\0')
  {
    *pnum = reg_ushm->number;
    return reg_ushm->userid[0];
  }
  for (n = 0; tag[n]; n++)
  {
    tagbuf[n] = chartoupper(tag[n]);
  }
  tagbuf[n] = '\0';
  ch = tagbuf[0];
  ch2 = ch - 'A' + 'a';
  total = reg_ushm->number;
  for (n = num = 0; n < total; n++)
  {
    ptr = reg_ushm->userid[n];
    tmp = *ptr;
    if (tmp == ch || tmp == ch2)
    {
      if (chkstr(tag, tagbuf, ptr))
        strcpy(buf[num++], ptr);
    }
  }
  *pnum = num;
  return buf[0];
}

/*-------------------------------------------------------*/
/* .UTMP cache                                           */
/*-------------------------------------------------------*/

struct UTMPFILE *utmpshm;
user_info *currutmp = NULL;

void
resolve_utmp()
{
  if (utmpshm == NULL)
  {
    utmpshm = shm_new(UTMPSHM_KEY, sizeof(*utmpshm));
    if (utmpshm->uptime == 0)
      utmpshm->uptime = utmpshm->number = 1;
  }
}


void
setutmpmode(mode)
  int mode;
{
  if (currstat != mode)
    currutmp->mode = currstat = mode;
}


/*
woju
*/
resetutmpent()
{
  extern int errno;
  register time_t now;
  register int i;
  register pid_t pid;
  register user_info *uentp;

  resolve_utmp();
  now = time(NULL) - 79;
  if (now > utmpshm->uptime)
    utmpshm->busystate = 0;

  while (utmpshm->busystate)
  {
    sleep(1);
  }
  utmpshm->busystate = 1;
  /* ------------------------------ */
  /* for ���F�ǻ�: �C 79 ����s�@�� */
  /* ------------------------------ */

  for (i = now = 0; i < USHM_SIZE; i++)
  {
    uentp = &(utmpshm->uinfo[i]);
    if (pid = uentp->pid)
    {
       if ((kill(pid, 0) == -1) && (errno == ESRCH))
           memset(uentp, 0, sizeof(user_info));
        else
           now++;
    }
  }
  utmpshm->number = now;
  time(&utmpshm->uptime);
  utmpshm->busystate = 0;
}


void
getnewutmpent(up)
  user_info *up;
{
  extern int errno;
  register time_t now;
  register int i;
  register pid_t pid;
  register user_info *uentp;

  resolve_utmp();
  now = time(NULL) - 79;
  if (now > utmpshm->uptime)
    utmpshm->busystate = 0;

  while (utmpshm->busystate)
  {
    sleep(1);
  }
  utmpshm->busystate = 1;
  /* ------------------------------ */
  /* for ���F�ǻ�: �C 79 ����s�@�� */
  /* ------------------------------ */

  if (now > utmpshm->uptime)
  {
    for (i = now = 0; i < USHM_SIZE; i++)
    {
      uentp = &(utmpshm->uinfo[i]);
      if (pid = uentp->pid)
      {
        if ((kill(pid, 0) == -1) && (errno == ESRCH))
          memset(uentp, 0, sizeof(user_info));
        else
          now++;
      }
    }
    utmpshm->number = now;
    time(&utmpshm->uptime);
  }

  for (i = 0; i < USHM_SIZE; i++)
  {
    uentp = &(utmpshm->uinfo[i]);
    if (!(uentp->pid))
    {
      memcpy(uentp, up, sizeof(user_info));
      currutmp = uentp;
      utmpshm->number++;
      utmpshm->busystate = 0;
      return;
    }
  }
  utmpshm->busystate = 0;
  sleep(1);
  exit(1);
}


int
apply_ulist(fptr)
  int (*fptr) ();
{
  register user_info *uentp;
  register int i, state;

  resolve_utmp();
  for (i = 0; i < USHM_SIZE; i++)
  {
    uentp = &(utmpshm->uinfo[i]);
    if (uentp->pid && (PERM_HIDE(currutmp) || !PERM_HIDE(uentp)))
      if (state = (*fptr) (uentp))
        return state;
  }
  return 0;
}


user_info *
search_ulist(fptr, farg)
  int (*fptr) ();
int farg;
{
  register int i;
  register user_info *uentp;

  resolve_utmp();
  for (i = 0; i < USHM_SIZE; i++)
  {
    uentp = &(utmpshm->uinfo[i]);
    if ((*fptr) (farg, uentp))
      return uentp;
  }
  return 0;
}


int
count_multi()
{
  register int i, j;
  register user_info *uentp;

  resolve_utmp();
  for (i = j = 0; i < USHM_SIZE; i++)
  {
    uentp = &(utmpshm->uinfo[i]);
    if (uentp->uid == usernum)
      j++;
  }
  return j;
}


/* -------------------- */
/* for multi-login talk */
/* -------------------- */

user_info *
search_ulistn(fptr, farg, unum)
  int (*fptr) ();
int farg;
int unum;
{
  register int i, j;
  register user_info *uentp;

  resolve_utmp();
  for (i = j = 0; i < USHM_SIZE; i++)
  {
    uentp = &(utmpshm->uinfo[i]);
    if ((*fptr) (farg, uentp))
    {
      if (++j == unum)
        return uentp;
    }
  }
  return 0;
}


int
count_logins(fptr, farg, show)
  int (*fptr) ();
int farg;
int show;
{
  register user_info *uentp;
  register int i, j;

  resolve_utmp();
  for (i = j = 0; i < USHM_SIZE; i++)
  {
    uentp = &(utmpshm->uinfo[i]);
    if ((*fptr) (farg, uentp))
    {
      j++;
      if (show)
      {
        prints("(%d) �ثe���A��: %-17.16s(�Ӧ� %s)\n", j,
          modestring(uentp, 0), uentp->from);
      }
    }
  }
  return j;
}


void
purge_utmp(uentp)
  user_info *uentp;
{
  memset(uentp, 0, sizeof(user_info));
  if (utmpshm->number)
    utmpshm->number--;
}


int
count_ulist()
{
   int ans = utmpshm->number;
   register user_info *uentp;
   int ch = 0;

   while (ch < USHM_SIZE) {
      uentp = &(utmpshm->uinfo[ch++]);
      if (uentp->pid && (
          is_rejected(uentp) & 2 && !HAS_PERM(PERM_SYSOP) ||
          uentp->invisible && !HAS_PERM(PERM_SEECLOAK) &!HAS_PERM(PERM_SYSOP) ||
          !PERM_HIDE(currutmp) && PERM_HIDE(uentp) ||
          cuser.uflag & FRIEND_FLAG && !is_friend(uentp)
         ))
         --ans;
   }

   return ans;
}

#endif
/*-------------------------------------------------------*/
/* .BOARDS cache                                         */
/*-------------------------------------------------------*/

struct BCACHE *brdshm;
boardheader *bcache;
int numboards = -1;
int brd_semid;

/* force re-caching */

void
touch_boards()
{
  time(&(brdshm->touchtime));
  numboards = -1;
}


reload_bcache()
{
   if (brdshm->busystate)
   {
     sleep(1);
   }
#if !defined(_BBS_UTIL_C_)
   else
   {
     int fd;

     brdshm->busystate = 1;
     sem_init(BRDSEM_KEY,&brd_semid);
     sem_lock(SEM_ENTER,brd_semid);

     if ((fd = open(fn_board, O_RDONLY)) > 0)
     {
       brdshm->number = read(fd, bcache, MAXBOARD * sizeof(boardheader))
         / sizeof(boardheader);
       close(fd);
     }
/*
     memset(brdshm->total, 0, MAXBOARD * sizeof(usint));
*/
     memset(brdshm->lastposttime, 0, MAXBOARD * sizeof(time_t));
     /* ���Ҧ� boards ��Ƨ�s��A�]�w uptime */

     brdshm->uptime = brdshm->touchtime;
#if !defined(_BBS_UTIL_C_)
     log_usies("CACHE", "reload bcache");
#endif
     sem_lock(SEM_LEAVE,brd_semid);
     brdshm->busystate = 0;
   }
#endif
}

void
resolve_boards()
{
  if (brdshm == NULL)
  {
    brdshm = shm_new(BRDSHM_KEY, sizeof(*brdshm));
    if (brdshm->touchtime == 0)
      brdshm->touchtime = 1;
    bcache = brdshm->bcache;
  }
  while (brdshm->uptime < brdshm->touchtime)
     reload_bcache();
  numboards = brdshm->number;
}

#if !defined(_BBS_UTIL_C_)
int
apply_boards(func)
  int (*func) ();
{
  register int i;
  register boardheader *bhdr;

  resolve_boards();
  for (i = 0, bhdr = bcache; i < numboards; i++, bhdr++)
  {
    if (Ben_Perm(bhdr))
      if ((*func) (bhdr) == QUIT)
        return QUIT;
  }
  return 0;
}


boardheader *
getbcache(bname)
  char *bname;
{
  register int i;
  register boardheader *bhdr;

  resolve_boards();
  for (i = 0, bhdr = bcache; i < numboards; i++, bhdr++)
  if (Ben_Perm(bhdr))
    if (!ci_strcmp(bname, bhdr->brdname))
      return bhdr;
  return NULL;
}

int
touchbtotal(bname)
  char *bname;
{
  register int i;
  register boardheader *bhdr;

  resolve_boards();
  for (i = 0, bhdr = bcache; i++ < numboards; bhdr++)
    if (!strcmp(bname, bhdr->brdname))
        {
         brdshm->total[i-1] = 0;
         brdshm->lastposttime[i-1] = 0;
         return i;
        }
  return 0;
}

int
inbtotal(bname, add)
  char *bname;
  int  add;
{
  register int i;
  register boardheader *bhdr;

  resolve_boards();
  for (i = 0, bhdr = bcache; i++ < numboards; bhdr++)
    if (!strcmp(bname, bhdr->brdname))
        {
          if(brdshm->total[i-1]) brdshm->total[i-1] += add;
          brdshm->lastposttime[i-1] = 0;
         return i;
        }
  return 0;
}

int
getbnum(bname)
  char *bname;
{
  register int i;
  register boardheader *bhdr;

  resolve_boards();
  for (i = 0, bhdr = bcache; i++ < numboards; bhdr++)
  if (Ben_Perm(bhdr))
    if (!ci_strcmp(bname, bhdr->brdname))
      return i;
  return 0;
}


int
haspostperm(bname)
  char *bname;
{
  register int i;
  char buf[200];

/*
  if (currmode & MODE_DIGEST || currmode & MODE_ETC)
    return 0;
*/

  setbfile(buf, bname, fn_water);
  if (belong(buf, cuser.userid))
     return 0;

  if (!ci_strcmp(bname, DEFAULT_BOARD))
    return 1;

  if (!HAS_PERM(PERM_POST))
    return 0;

  if (!(i = getbnum(bname)))
    return 0;

  /* ���K�ݪO�S�O�B�z */

  if (bcache[i - 1].brdattr & BRD_HIDE)
    return 1;

  i = bcache[i - 1].level;
  return (HAS_PERM(i & ~PERM_POST));
}


#endif

/*-------------------------------------------------------*/
/* FROM cache                                            */
/*-------------------------------------------------------*/
/* cachefor from host �P�̦h�W�u�H�� */

//#include "../lib/sem.c"

struct FROMCACHE *fcache;
int fcache_semid;

reload_fcache()
{
   if (fcache->busystate)
   {
     /*sleep(1);*/
   }
   else
   {
     FILE *fp;
     fcache->busystate = 1;
     sem_init(FROMSEM_KEY,&fcache_semid);
     sem_lock(SEM_ENTER,fcache_semid);
     bzero(fcache->domain, sizeof fcache->domain);
     if(fp=fopen("etc/domain_name_query","r"))
        {
         char buf[101],*po;
         fcache->top=0;
         while (fgets(buf,100,fp))
           {
             if(buf[0] && buf[0] != '#' && buf[0] != ' ' && buf[0] != '\n')
                {
                  sscanf(buf,"%s",fcache->domain[fcache->top]);
                  po = buf + strlen(fcache->domain[fcache->top]);
                  while(*po == ' ') po++;
                  strncpy(fcache->replace[fcache->top],po,49);
                  fcache->replace[fcache->top][
                        strlen(fcache->replace[fcache->top])-1] = 0;
                  (fcache->top)++;
                }
           }
        }
     fcache->max_user=0;
     /* ���Ҧ���Ƨ�s��A�]�w uptime */
     fcache->uptime = fcache->touchtime;
#if !defined(_BBS_UTIL_C_)
     log_usies("CACHE", "reload fcache");
#endif
     sem_lock(SEM_LEAVE,fcache_semid);
     fcache->busystate = 0;
   }
}

void
resolve_fcache()
{
  if (fcache == NULL)
  {
    fcache = shm_new(FROMSHM_KEY, sizeof(*fcache));
    if (fcache->touchtime == 0)
      fcache->touchtime = 1;
  }
  while (fcache->uptime < fcache->touchtime) reload_fcache();
}


/*-------------------------------------------------------*/
/* etc/movie cache                                       */
/*-------------------------------------------------------*/
FCACHE *fshm;

void
fshm_init()
{
  if (fshm == NULL)
    fshm = shm_new(FILMSHM_KEY, sizeof(FCACHE));
}

char today_is[20];

void
feast_init()
{
  FILE *fp;
  char *chr;
  fp=fopen("etc/today_is","r");
  if(fp)
  {
   fgets(today_is,17,fp);
   if(chr=strchr(today_is,'\n')) *chr=0;
   today_is[17]=0;
  }
  fclose(fp);
}

/* �P�_color */

int colorowner(userid)
  char *userid;
{
    register int i,f;
    register user_info *uentp;

    resolve_utmp();
    for (i = 0; i < USHM_SIZE; i++)
    {
     uentp = &(utmpshm->uinfo[i]);
     if (!ci_strcmp(userid, uentp->userid) &&str_cmp(userid,cuser.userid))
     {
    f = is_friend(uentp);
    if (is_rejected(uentp) )
      return 31; //�a�H�A�t����
    else if ( f == 1 )
      return 32; //�ڪ��n�͡A�G���
    else if ( f == 2 )
      return 33; //�]�ڬ��n�͡A�G��
    else if ( f == 3 )
      return 36; //���]���n�͡A�G��
    else if ( PERM_HIDE(uentp) )
      return 37; //��������
    else if ( PERM_HIDE(uentp) && PERM_HIDE(currutmp) )
      return 37 ; //�ϥΪ�����
    else if ( currutmp == uentp )
      return 37; //�ۤv�A�G��
    else
      return 34; //�b���W���O�H
     }
    }
}
