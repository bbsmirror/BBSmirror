/*-------------------------------------------------------*/
/* bbs.c        ( NTHU CS MapleBBS Ver 2.36 )            */
/*-------------------------------------------------------*/
/* target : bulletin boards' routines                    */
/* create : 95/03/29                                     */
/* update : 95/12/15                                     */
/*-------------------------------------------------------*/
#define MAXPATHLEN 256
#include "bbs.h"

extern int      mail_reply();
extern char     currdirect[64];
time_t          board_note_time;
time_t          board_visit_time;

static char    *brd_title;
static int      continue_flag;
char            real_name[20];
int             local_article;
#define UPDATE_USEREC   (currmode |= MODE_DIRTY)


static int
g_board_names(fhdr)
        boardheader    *fhdr;
{
        AddNameList(fhdr->brdname);
        return 0;
}


void
make_blist()
{
        CreateNameList();
        apply_boards(g_board_names);
}


void
set_board()
{
        boardheader    *bp;
        boardheader    *getbcache();

        bp = getbcache(currboard);
        board_note_time = bp->bupdate;
        brd_title = bp->BM;
        if (brd_title[0] <= ' ')
                brd_title = "�x�D��";

        sprintf(currBM, "BM:%s", brd_title);
        brd_title = (bp->bvote == 1 ? "���ݪO�i��벼��" : bp->title + 7);

        currmode = (currmode & MODE_DIRTY) | MODE_STARTED;
        if (HAS_PERM(PERM_ALLBOARD) ||
            (HAS_PERM(PERM_BM) && is_BM(currBM + 3))) {
                currmode |= (MODE_BOARD | MODE_POST);
        } else if (haspostperm(currboard))
                currmode |= MODE_POST;
}


static void
readtitle()
{
        char            buf[250], buf1[17];
        int             bid;
        boardheader     bh;

        setutmpmode(ARTICLE);
        showtitle2(currBM, "�峹�C��", brd_title);
        bid = getbnum(currboard);
        if (rec_get(fn_board, &bh, sizeof(bh), bid) == -1)
                pressanykey(err_bid);
        /* skybinary 2000 05 01 �ݪO�`��Ĳv�[�j */
        sprintf(buf1, "%16.16s\0", bh.holiday);
        prints("\
[1;36m��[37;46m�ݪO��[34;47m�峹[46;37m����K�@��ذ�[0;36;40m��[m\
 [TAB]���� [��]���} [��]�\\Ū [^P]�o�� [^x]�ֳt���\n");

        if (cuser.color == 9) { /* if(currmode & MODE_DIGEST) sprintf(buf,"\
                                 * [1;41m  �s��   [44m�� ��  [43m�@ 5m��  ��  ��
                                 * �D [42m[%-16.16s][m", buf1); else */
                sprintf(buf, "\
[1;41m  �s��   [44m�� ��  [43m�@  ��       [45m��  ��  ��  �D                [42m[%-16s][m", buf1);
        } else {
                /*
                 * if(currmode & MODE_DIGEST) sprintf(buf," [4%d;1m  �s��   �� ��       ��  ��  ��
                 * �D [40;33m[%-16s][m",cuser.color,buf1); else
                 */
                sprintf(buf, "\
[4%d;1m  �s��   �� ��  �@  ��       ��  ��  ��  �D                [40;33m[%-16s][m", cuser.color, buf1);

        }
        prints("%s", buf);
}


void
doent(num, ent)
        int             num;
        fileheader     *ent;
{
        int             type, color2;
        char           *mark, *title, color;
        static char    *colors[7] = {"[33m", "[32m", "[31m", "[35m", "[34m", "[36m", "[37m"};

        if (currstat != RMAIL) {
                type = brc_unread(ent->filename) ? '+' : ' ';

                if ((currmode & MODE_BOARD) && (ent->filemode & FILE_DIGEST))
                        type = (type == ' ') ? '*' : '#';
                if (ent->filemode & FILE_MARKED)
                        type = (type == ' ') ? 'm' : 'M';
                if (ent->filemode & FILE_TAGED)
                        type = 'D';
                if (ent->filemode & FILE_REFUSE)
                        type = 'X';

        } else {
                type = "+ Mm"[ent->filemode];

                if (ent->filemode & FILE_REPLYOK)
                        type = (ent->filemode & FILE_MARKED) ? 'R' : 'r';
                if (ent->filemode & FILE_TAGED)
                        type = 'D';
        }

        title = subject(mark = ent->title);
        if (title == mark) {
                color = '4';
                mark = "��";
        } else {
                color = '1';
                mark = "R:";
        }
        str_decode(title);      //for decode
        if (title[45])
                strcpy(title + 42, " �K");      /* ��h�l�� string �屼 */
        color2 = 37;
        color2 = colorowner(ent->owner);
        if (currbrdattr & BRD_ANONYMOUS)
                color2 = 37;
        if(color2 > 37) color2=37;
        if(color2 < 30) color2=37;
        prints("%6d ", num);
        switch (type) {
        case 'm':
        case 'M':
                prints("[1;33m");
                break;
        case '*':
        case '#':
                prints("[1;35m");
                break;
        case 'D':
                prints("[1;36m");
                break;
        case '+':
                prints("[1;32m");
                break;
        case 'R':
        case 'r':
                prints("[1;34m");
                break;
        case 'X':
                prints("[1;31m");
                break;
        }
//skybinary 2000420:�@�̥[�C��
              prints("%c[1m %s%-7s[%d;1m%-13.13s[m", type,
                   colors[(unsigned int) (ent->date[4] + ent->date[5]) % 7],
                     ent->date, color2, ent->owner);
        if (strncmp(currtitle, title, 36))
                prints("%s %s\n", mark, title);
        else
                prints("[1;4%c;37m%s %s[0m\n", color, mark, title);

}


int
cmpbnames(bname, brec)
        char           *bname;
        boardheader    *brec;
{
        return (!ci_strncmp(bname, brec->brdname, sizeof(brec->brdname)));
}


int
cmpfilename(fhdr)
        fileheader     *fhdr;
{
        return (!strcmp(fhdr->filename, currfile));
}


/*
 * woju
 */
int
cmpfmode(fhdr)
        fileheader     *fhdr;
{
        return (fhdr->filemode & currfmode);
}


int
cmpfowner(fhdr)
        fileheader     *fhdr;
{
        return !strcasecmp(fhdr->owner, currowner);
}



int
do_select(ent, fhdr, direct)
        int             ent;
        fileheader     *fhdr;
        char           *direct;
{
        char            bname[20];
        char            bpath[60];
        struct stat     st;

        move(0, 0);
        clrtoeol();
        make_blist();
        namecomplete(MSG_SELECT_BOARD, bname);

        setbpath(bpath, bname);
        if ((*bname == '\0') || (stat(bpath, &st) == -1)) {
                move(2, 0);
                clrtoeol();
                pressanykey(err_bid);
                return FULLUPDATE;
        }
        /*
         * board_visit_time = 0x7fffffff;
         */
        brc_initial(bname);
        set_board();
        setbdir(direct, currboard);

        move(1, 0);
        clrtoeol();
        return NEWDIRECT;
}
/* ----------------------------------------------------- */
/* ��} innbbsd ��X�H��B�s�u��H���B�z�{��             */
/* ----------------------------------------------------- */


outgo_post(fh, board)
        fileheader     *fh;
        char           *board;
{
        char            buf[256];
        sprintf(buf, "%s\t%s\t%s\t%s\t%s\n", board,
                fh->filename, fh->owner, cuser.username, fh->title);
        f_cat("innd/out.bntp", buf);
}


static void
cancelpost(fh, by_BM)
        fileheader     *fh;
        int             by_BM;
{
        FILE           *fin;
        char           *ptr, *brd;
        fileheader      postfile;
        char            genbuf[200], buf[256];
        char            nick[STRLEN], fn1[STRLEN], fn2[STRLEN];

        setbfile(fn1, currboard, fh->filename);
        if (fin = fopen(fn1, "r")) {
                brd = by_BM ? "deleted" : "junk";

                setbpath(fn2, brd);
                stampfile(fn2, &postfile);
                memcpy(postfile.owner, fh->owner, IDLEN + TTLEN + 10);
                postfile.savemode = 'D';

                if (fh->savemode == 'S') {
                        nick[0] = '\0';
                        while (fgets(genbuf, sizeof(genbuf), fin)) {
                                if (!strncmp(genbuf, str_author1, LEN_AUTHOR1) ||
                                !strncmp(genbuf, str_author2, LEN_AUTHOR2)) {
                                        if (ptr = strrchr(genbuf, ')'))
                                                *ptr = '\0';
                                        if (ptr = (char *) strchr(genbuf, '('))
                                                strcpy(nick, ptr + 1);
                                        break;
                                }
                        }

                        sprintf(buf, "%s\t%s\t%s\t%s\t%s\n",
                                currboard, fh->filename, cuser.userid, nick, fh->title);
                        f_cat("innd/cancel.bntp", buf);
                }
                fclose(fin);
                f_mv(fn1, fn2);
                setbdir(genbuf, brd);
                rec_add(genbuf, &postfile, sizeof(postfile));
        }
}


/* ----------------------------------------------------- */
/* �o���B�^���B�s��B����峹                            */
/* ----------------------------------------------------- */


void
do_reply_title(row, title)
        int             row;
        char           *title;
{
        char            genbuf[200];
        char            genbuf2[4];

        if (ci_strncmp(title, str_reply, 4))
                sprintf(save_title, "Re: %s", title);
        else
                strcpy(save_title, title);
        save_title[TTLEN - 1] = '\0';
        sprintf(genbuf, "�ĥέ���D�m%.60s�n��?[Y] ", save_title);
        getdata(row, 0, genbuf, genbuf2, 4, LCECHO, 0);
        if (*genbuf2 == 'n')
                getdata(++row, 0, "���D�G", save_title, TTLEN, DOECHO, 0);
}


static int
do_reply(fhdr)
        fileheader     *fhdr;
{
        char            genbuf[200];

        if (!strcmp(currboard, VOTEBOARD))
                DL_func("SO/votebrd.so:va_do_vote", fhdr);
        else if (!strncmp(fhdr->title, "(�s�p)", 6))
                DL_func("SO/votebrd.so:va_do_vote", fhdr);

        else {
                getdata(b_lines - 1, 0, "�� �^���� (F)�ݪO (M)�@�̫H�c (B)�G�̬ҬO (Q)�����H[F] ",
                        genbuf, 3, LCECHO, "F");
                switch (genbuf[0]) {
                case 'm':
                        mail_reply(0, fhdr, 0);
                case 'q':
                        break;

                case 'b':
                        curredit = EDIT_BOTH;
                default:
                        if (!strcmp(currboard, "Vote")) {
                                DL_func("SO/votebrd.so:va_do_vote", fhdr);
                                return FULLUPDATE;
                        } else if (!strncmp(fhdr->title, "(�s�p)", 6)) {
                                DL_func("SO/votebrd.so:va_do_vote", fhdr);
                                return FULLUPDATE;
                        }
                        strcpy(currtitle, fhdr->title);
                        strcpy(quote_user, fhdr->owner);
                        quote_file[79] = fhdr->savemode;
                        do_post();
                }
                *quote_file = 0;
        }
}


/*
 * woju
 */
brdperm(char *brdname, char *userid)
{
        boardheader    *bp;
        boardheader    *getbcache();
        int             uid = searchuser(userid);

        bp = getbcache(currboard);
        if (uid && bp) {
                int             level = bp->level;
                char           *ptr = bp->BM;
                char            buf[64], manager[IDLEN + 1];
                userec          xuser;

                rec_get(fn_passwd, &xuser, sizeof(xuser), uid);
                if ((level & BRD_POSTMASK) || ((level) ? xuser.userlevel & (level) : 1))
                        return 1;

                if (ptr[0] <= ' ')
                        return 0;

                if (userid_is_BM(userid, ptr))
                        return 1;

                if ((level & 0xffff) != PERM_SYSOP)
                        return 0;

                strncpy(manager, ptr, IDLEN + 1);
                if (ptr = strchr(manager, '/'))
                        *ptr = 0;
                sethomefile(buf, manager, fn_overrides);
                return (belong(buf, userid));
        }
        return 0;
}

#ifdef POSTNOTIFY
do_postnotify(char *fpath)
{
        fileheader      mhdr;
        char            title[128], buf1[80], buf[80];
        FILE           *fp;
        char            genbuf[200];

        setuserfile(genbuf, "postnotify");
        if (fp = fopen(genbuf, "r")) {
                char            last_fname[80];
                boardheader    *bp;
                boardheader    *getbcache();

                strcpy(last_fname, fpath);
                bp = getbcache(currboard);
                while (fgets(buf, 80, fp))
                        if (brdperm(currboard, buf)) {
                                sethomepath(buf1, buf);
                                stampfile(buf1, &mhdr);
                                strcpy(mhdr.owner, cuser.userid);
                                strcpy(mhdr.title, "[�s]");
                                strncat(mhdr.title, save_title, TTLEN - 4);
                                mhdr.savemode = 0;
                                mhdr.filemode = 0;
                                sethomedir(title, buf);
                                rec_add(title, &mhdr, sizeof(mhdr));
                                unlink(buf1);
                                f_cp(last_fname, buf1, O_TRUNC);
                                strcpy(last_fname, buf1);
                        }
                fclose(fp);
        }
}
#endif

do_unanonymous_post(char *fpath)
{
        fileheader      mhdr;
        char            title[128];
        char            genbuf[200];

        setbpath(genbuf, "UnAnonymous");
        if (dashd(genbuf)) {
                stampfile(genbuf, &mhdr);
                unlink(genbuf);
                f_cp(fpath, genbuf, O_TRUNC);
                strcpy(mhdr.owner, cuser.userid);
                strcpy(mhdr.title, save_title);
                mhdr.savemode = 0;
                mhdr.filemode = 0;
                setbdir(title, "UnAnonymous");
                rec_add(title, &mhdr, sizeof(mhdr));
        }
}

/* Ptt test */
getindex(fpath, fname, size)
        char           *fpath;
        char           *fname;
        int             size;
{
        int             fd, now = 0;
        fileheader      fhdr;

        if ((fd = open(fpath, O_RDONLY, 0)) != -1) {
                while ((read(fd, &fhdr, size) == size)) {
                        now++;
                        if (!strcmp(fhdr.filename, fname)) {
                                close(fd);
                                return now;
                        }
                }
                close(fd);
        }
        return 0;
}

extern long     wordsnum;       /* �p��r�� */



int
do_post()
{
        fileheader      postfile;
        char            fpath[80], buf[80];
        int             aborted;
        char            genbuf[200], *owner;
        boardheader    *bp;
        boardheader    *getbcache();
        time_t          spendtime;
        int             num = 0, i;
        char           *postprefix[] = {
                "���i", "�s�D", "����", "���", "���D",
                "����", "��L", "�s�p",
        NULL};

        bp = getbcache(currboard);

        clear();
        if (!(currmode & MODE_POST) || brdperm(currboard, cuser.userid) == 0) {
                pressanykey("�藍�_�A�z�ثe�L�k�b���o���峹�I");
                return FULLUPDATE;
        }
        if (!strcmp(currboard, VOTEBOARD)) {
                DL_func("SO/votebrd.so:do_voteboard");
                return FULLUPDATE;
        }
        //more("etc/post.note", NA);
        film_out(POST, 1);
        prints("�o���峹��i %s �j�ݪO\n", currboard);

        if (quote_file[0])
                do_reply_title(20, currtitle);
        else {
                memset(save_title, 0, TTLEN);
                while (postprefix[num] != NULL) {
                        prints("%d.[%s] ", num + 1, postprefix[num]);
                        num++;
                }
                getdata(20, 0, "�п�ܤ峹���O�Φۦ��J���O(�Ϋ�Enter���L)�G", genbuf, 8, DOECHO, 0);
                i = atoi(genbuf);
                if (i > 0 && i <= num)  /* ��J�Ʀr�ﶵ */
                {
                        sprintf(buf,"[%s]", postprefix[i - 1]);
                        strncpy(save_title, buf, strlen(buf));
                }
                else if (strlen(genbuf) >= 3)   /* �ۦ��J */
                        strncpy(save_title, genbuf, strlen(genbuf));
                else            /* �ťո��L */
                        save_title[0] = '\0';

                if (i == 8) {
                        DL_func("SO/votebrd.so:do_voteboard");
                        return FULLUPDATE;
                }
                getdata(21, 0, "���D�G", save_title, TTLEN, DOECHO, save_title);
                strip_ansi(save_title, save_title, ONLY_COLOR);
        }
        if (save_title[0] == '\0')
                return FULLUPDATE;

        curredit &= ~EDIT_MAIL;
        curredit &= ~EDIT_ITEM;
        setutmpmode(POSTING);

        /* ����� Internet �v���̡A�u��b�����o���峹 */

        if (HAS_PERM(PERM_INTERNET))
                local_article = 0;
        else
                local_article = 1;

        buf[0] = 0;

        spendtime = time(0);
        aborted = vedit(buf, YEA);
        spendtime = time(0) - spendtime;
        if (aborted == -1) {
                unlink(buf);
                pressanykey(NULL);
                return FULLUPDATE;
        }
        /* build filename */

        setbpath(fpath, currboard);
        stampfile(fpath, &postfile);
        f_mv(buf, fpath);
        strcpy(postfile.owner, cuser.userid);

        /* set owner to Anonymous , for Anonymous board */

#ifdef HAVE_ANONYMOUS
        /* Ptt and Jaky */
        if (currbrdattr & BRD_ANONYMOUS && strcmp(real_name, "r")) {
                strcat(real_name, ".");
                owner = real_name;
        } else {
#endif
                owner = cuser.userid;
#ifdef HAVE_ANONYMOUS
        }
#endif

        strcpy(postfile.owner, owner);
        strcpy(postfile.title, save_title);
        if (aborted == 1) {     /* local save */
                postfile.savemode = 'L';
                postfile.filemode = FILE_LOCAL;
        } else
                postfile.savemode = 'S';

        setbdir(buf, currboard);
        if (rec_add(buf, &postfile, sizeof(postfile)) != -1) {
                if (currmode & MODE_SELECT)
                        rec_add(currdirect, &postfile, sizeof(postfile));
                if (aborted != 1 && !(currbrdattr & BRD_NOTRAN))
                        outgo_post(&postfile, currboard);

                brc_addlist(postfile.filename);

                if (strcmp(currboard, "Test")) {
                        if (wordsnum <= 40)
                                pressanykey("��p�A�ӵu���峹���C�J�����C");
                        else {
                                int             money = (wordsnum <= spendtime ? (wordsnum) : (spendtime));
                                if (money < 1)
                                        money = 1;
                                pressanykey("�o�O�z����%d�峹,�Z�S%d��", ++cuser.numposts, money);

                                substitute_record(fn_passwd, &cuser, sizeof(userec), usernum);
                                inmoney(money);
                                //pressanykey("�峹�o������ :)");
                                if (money >= 1000) {
                                        FILE           *fp;
                                        time_t          now = time(0);
                                        fileheader      mhdr;
                                        char            genbuf1[200], fpath1[STRLEN];

                                        setbpath(genbuf1, "Security");
                                        stampfile(genbuf1, &mhdr);
                                        strcpy(mhdr.owner, cuser.userid);
                                        strncpy(mhdr.title, "POST�ˬd", TTLEN);
                                        mhdr.savemode = '\0';
                                        setbdir(fpath1, "Security");
                                        if (rec_add(fpath1, &mhdr, sizeof(mhdr)) == -1) {
                                                outs(err_uid);
                                                return 0;
                                        }
                                        if ((fp = fopen(genbuf1, "w")) != NULL) {
                                                fprintf(fp, "�@��: %s (%s)\n", cuser.userid, cuser.username);
                                                fprintf(fp, "���D: %s\n�ɶ�: %s\n", "POST�ˬd", ctime(&now));
                                                fprintf(fp, "%s �o���@�g %d �r���峹�� %s �O\n��F %d ���A�o����� %d ��"
                                                        ,cuser.userid, wordsnum, currboard, spendtime, money);
                                                fclose(fp);
                                        }
                                }
                        }
                        UPDATE_USEREC;
                } else
                        pressanykey("���ݪO�峹���C�J�����A�q�Х]�[�C");

                /* �^�����@�̫H�c */

                if (curredit & EDIT_BOTH) {
                        char           *str, *msg = "�^���ܧ@�̫H�c";

                        if (str = strchr(quote_user, '.')) {
                                if (bbs_sendmail(fpath, save_title, str + 1) < 0)
                                        msg = "�@�̵L�k���H";
                        } else {
                                sethomepath(genbuf, quote_user);
                                stampfile(genbuf, &postfile);
                                unlink(genbuf);
                                f_cp(fpath, genbuf, O_TRUNC);

                                strcpy(postfile.owner, cuser.userid);
                                strcpy(postfile.title, save_title);
                                postfile.savemode = 'B';        /* both-reply flag */
                                sethomedir(genbuf, quote_user);
                                if (rec_add(genbuf, &postfile, sizeof(postfile)) == -1)
                                        msg = err_uid;
                        }
                        outs(msg);
                        curredit ^= EDIT_BOTH;
                }
                if (currbrdattr & BRD_ANONYMOUS)        /* �ϰΦW  */
                        do_unanonymous_post(fpath);

#ifdef POSTNOTIFY               /* �s�峹�q�� */
                if (!(currbrdattr & BRD_ANONYMOUS) && !(currbrdattr & BRD_HIDE)
                    && !(currbrdattr & BRD_POSTMASK))
                        do_postnotify(fpath);
#endif
        }
        return FULLUPDATE;
}


static int
reply_post(ent, fhdr, direct)
        int             ent;
        fileheader     *fhdr;
        char           *direct;
{
        if (!(currmode & MODE_POST))
                return DONOTHING;
//�[�K�L���峹�u���O�D�i�H�^
  if (fhdr->filemode & FILE_REFUSE && !(currmode & MODE_BOARD))
    return DONOTHING;


        setdirpath(quote_file, direct, fhdr->filename);
        if (!strcmp(currboard, VOTEBOARD)) {
                DL_func("SO/votebrd.so:va_do_vote", fhdr);
                return FULLUPDATE;
        }
        do_reply(fhdr);
        *quote_file = 0;
        return FULLUPDATE;
}


static int
edit_post(ent, fhdr, direct)
        int             ent;
        fileheader     *fhdr;
        char           *direct;
{
        char            fpath[80], fpath0[80];
        extern          bad_user(char *name);
        char            genbuf[200];
        fileheader      postfile;
        int             edit_mode;

//�[�K���峹����edit
        if (fhdr->filemode & FILE_REFUSE && !(currmode & MODE_BOARD))
            return DONOTHING;

        if (HAS_PERM(PERM_SYSOP) ||
            !strcmp(fhdr->owner, cuser.userid) && strcmp(cuser.userid, "guest") &&
            !bad_user(cuser.userid))
                edit_mode = 0;
        else
                edit_mode = 2;

        setdirpath(genbuf, direct, fhdr->filename);
        local_article = fhdr->filemode & FILE_LOCAL;
        strcpy(save_title, fhdr->title);

        if (vedit(genbuf, edit_mode) != -1) {
                setbpath(fpath, currboard);
                stampfile(fpath, &postfile);
                unlink(fpath);
                setbfile(fpath0, currboard, fhdr->filename);
                f_mv(fpath0, fpath);
                strcpy(fhdr->filename, postfile.filename);
                strcpy(fhdr->title, save_title);
                brc_addlist(postfile.filename);
                substitute_record(direct, fhdr, sizeof(*fhdr), ent);
#ifdef POSTNOTIFY
                if (currbrdattr & BRD_ANONYMOUS)
                        do_postnotify(fpath);
#endif
        }
        return FULLUPDATE;
}


static int
cross_post(ent, fhdr, direct)
        int             ent;
        fileheader     *fhdr;
        char           *direct;
{
        char            xboard[20], fname[80], xfpath[80], xtitle[80],
                        inputbuf[10];
        fileheader      xfile;
        FILE           *xptr;
        int             author = 0;
        char            genbuf[200];
        char            genbuf2[4];

  if (fhdr->filemode & FILE_REFUSE && !(currmode & MODE_BOARD))
    return DONOTHING;


        make_blist();
        move(2, 0);
        clrtoeol();
        move(3, 0);
        clrtoeol();
        move(1, 0);
        namecomplete("������峹��ݪO�G", xboard);
        if (*xboard == '\0' || !haspostperm(xboard))
                return FULLUPDATE;

        ent = 1;
        if (HAS_PERM(PERM_SYSOP) || !strcmp(fhdr->owner, cuser.userid)) {
                getdata(2, 0, "(1)������ (2)������榡�H[1] ",
                        genbuf, 3, DOECHO, "1");
                if (genbuf[0] != '2') {
                        ent = 0;
                        getdata(2, 0, "�O�d��@�̦W�ٶ�?[Y] ", inputbuf, 3, DOECHO, 0);
                        if (inputbuf[0] != 'n' && inputbuf[0] != 'N')
                                author = 1;
                }
        }
        if (ent)
                sprintf(xtitle, "[���]%.66s", fhdr->title);
        else
                strcpy(xtitle, fhdr->title);

        sprintf(genbuf, "�ĥέ���D�m%.60s�n��?[Y] ", xtitle);
        getdata(2, 0, genbuf, genbuf2, 4, LCECHO, 0);
        if (*genbuf2 == 'n') {
                if (getdata(2, 0, "���D�G", genbuf, TTLEN, DOECHO, xtitle))
                        strcpy(xtitle, genbuf);
        }
        getdata(2, 0, "(S)�s�� (L)���� (Q)�����H[S] ", genbuf, 3, LCECHO, "S");
        if (genbuf[0] == 'l' || genbuf[0] == 's') {
                int             currmode0 = currmode;

                currmode = 0;
                setbpath(xfpath, xboard);
                stampfile(xfpath, &xfile);
                if (author)
                        strcpy(xfile.owner, fhdr->owner);
                else
                        strcpy(xfile.owner, cuser.userid);
                strcpy(xfile.title, xtitle);
                if (genbuf[0] == 'l') {
                        xfile.savemode = 'L';
                        xfile.filemode = FILE_LOCAL;
                } else
                        xfile.savemode = 'S';

                setbfile(fname, currboard, fhdr->filename);
                if (ent) {
                        xptr = fopen(xfpath, "w");

                        strcpy(save_title, xfile.title);
                        strcpy(xfpath, currboard);
                        strcpy(currboard, xboard);
                        write_header(xptr);
                        strcpy(currboard, xfpath);

                        fprintf(xptr, "�� [��������� %s �ݪO]\n\n", currboard);

                        b_suckinfile(xptr, fname);
                        DL_func("SO/vote.so:va_b_suckinfile", xptr, fname);
                        addsignature(xptr);
                        //addsig(xptr);
                        fclose(xptr);
                } else {
                        unlink(xfpath);
                        f_cp(fname, xfpath, O_TRUNC);
                }

                setbdir(fname, xboard);
                rec_add(fname, (char *) &xfile, sizeof(xfile));
                if (!xfile.filemode)
                        outgo_post(&xfile, xboard);
                cuser.numposts++;
                UPDATE_USEREC;
                pressanykey("�峹�������");
                currmode = currmode0;
        }
        return FULLUPDATE;
}


static int
read_post(ent, fhdr, direct)
        int             ent;
        fileheader     *fhdr;
        char           *direct;
{
        char            genbuf[200];
        int             more_result;

  if (fhdr->filemode & FILE_REFUSE && !(currmode & MODE_BOARD) &&
      strcmp(cuser.userid, fhdr->owner))
    return FULLUPDATE;


        if (fhdr->owner[0] == '-')
                return DONOTHING;

        setdirpath(genbuf, direct, fhdr->filename);

        if ((more_result = more(genbuf, YEA)) == -1)
                return DONOTHING;

        brc_addlist(fhdr->filename);
        strncpy(currtitle, subject(fhdr->title), 40);
        strncpy(currowner, subject(fhdr->owner), IDLEN + 2);

        /*
         * woju
         */
        switch (more_result) {
        case 1:
                return READ_PREV;
        case 2:
                return RELATE_PREV;
        case 3:
                return READ_NEXT;
        case 4:
                return RELATE_NEXT;
        case 5:
                return RELATE_FIRST;
        case 6:
                return FULLUPDATE;
        case 7:
        case 8:
                if (currmode & MODE_POST) {
                        strcpy(quote_file, genbuf);
                        do_reply(fhdr);
                        *quote_file = 0;
                }
                return FULLUPDATE;
        case 9:
                return 'A';
        case 10:
                return 'a';
        case 11:
                return '/';
        case 12:
                return '?';
        }
        return FULLUPDATE;
}


/* ----------------------------------------------------- */
/* �Ķ���ذ�                                            */
/* ----------------------------------------------------- */


man()
{
        char            buf[64], buf1[64];

        if (currstat == RMAIL) {
                if (HAS_PERM(PERM_MAILLIMIT)) {
                        int             mode0 = currutmp->mode;
                        int             stat0 = currstat;

                        sethomeman(buf, cuser.userid);
                        sprintf(buf1, "%s ���H��", cuser.userid);
                        sprintf(buf1, "%s ���H��", cuser.userid);
                        a_menu(buf1, buf, belong("etc/sysop", cuser.userid) ? 2 : 1);
                        currutmp->mode = mode0;
                        currstat = stat0;
                        return FULLUPDATE;
                }
        } else {
                setapath(buf, currboard);
                a_menu(currboard, buf, HAS_PERM(PERM_ALLBOARD) ? 2 :
                       (currmode & MODE_BOARD ? 1 : 0));
        }
        return FULLUPDATE;
}



int
cite(ent, fhdr, direct)
        int             ent;
        fileheader     *fhdr;
        char           *direct;
{
        char            fpath[256];
        char            title[TTLEN + 1];

  if (currstat == RMAIL)
  {
    setuserfile(fpath, fhdr->filename);
    add_tag();
  }
  else
        setbfile(fpath, currboard, fhdr->filename);

        strcpy(title, "�� ");
        strncpy(title + 3, fhdr->title, TTLEN - 3);
        title[TTLEN] = '\0';
//        a_copyitem(fpath, title, 0);
        a_copyitem (fpath, title, cuser.userid);
  /* shakalaca.990517: ���ϥΪ̭n�D, �s�̬��O�D */
        man();
        return FULLUPDATE;
}


Cite_posts(int ent, fileheader * fhdr, char *direct)
{
        char            fpath[256];

        setbfile(fpath, currboard, fhdr->filename);
        add_tag();
        load_paste();
        if (*paste_path && paste_level && dashf(fpath)) {
                fileheader      fh;
                char            newpath[MAXPATHLEN];

                strcpy(newpath, paste_path);
                stampfile(newpath, &fh);
//                unlink(newpath);
                f_cp(fpath, newpath, O_TRUNC);
                strcpy(fh.owner, fhdr->owner);
                sprintf(fh.title, "%s%.72s",
                        (currutmp->pager > 1) ? "" : "�� ", fhdr->title);
                strcpy(strrchr(newpath, '/') + 1, ".DIR");
                rec_add(newpath, &fh, sizeof(fh));
                return POS_NEXT;
        }
        bell();
        return DONOTHING;
}

int
edit_title(ent, fhdr, direct)
        int             ent;
        fileheader     *fhdr;
        char           *direct;
{
        char            genbuf[200];

        if (HAS_PERM(PERM_SYSOP) || (currmode & MODE_BOARD)) {
                fileheader      tmpfhdr = *fhdr;
                int             dirty = 0;

                if (getdata(b_lines - 1, 0, "���D�G", genbuf, TTLEN, DOECHO, tmpfhdr.title)) {
                        strcpy(tmpfhdr.title, genbuf);
                        dirty++;
                }
                if (getdata(b_lines - 1, 0, "�@�̡G", genbuf, IDLEN + 2, DOECHO, tmpfhdr.owner)) {
                        strcpy(tmpfhdr.owner, genbuf);
                        dirty++;
                }
                if (getdata(b_lines - 1, 0, "����G", genbuf, 6, DOECHO, tmpfhdr.date)) {
                        sprintf(tmpfhdr.date, "%+5s", genbuf);
                        dirty++;
                }
                if (getdata(b_lines - 1, 0, "�T�w(Y/N)?[n] ", genbuf, 3, DOECHO, 0) &&
                    *genbuf == 'y' && dirty) {
                        *fhdr = tmpfhdr;
                        substitute_record(direct, fhdr, sizeof(*fhdr), ent);
                        if (currmode & MODE_SELECT) {
                                int             now;
                                setbdir(genbuf, currboard);
                                now = getindex(genbuf, fhdr->filename, sizeof(fileheader));
                                substitute_record(genbuf, fhdr, sizeof(*fhdr), now);
                        }
                }
                return FULLUPDATE;
        }
        return DONOTHING;
}

int
add_tag(ent, fhdr, direct)
        int             ent;
        fileheader     *fhdr;
        char           *direct;
{
  int now;
  char genbuf[100];

  if (currstat == RMAIL)
  {
  fhdr->filemode ^= FILE_TAGED;
    sethomedir (genbuf, cuser.userid);
    if (currmode & SELECT)
    {
      now = getindex (genbuf, fhdr->filename, sizeof (fileheader));
      substitute_record (genbuf, fhdr, sizeof (*fhdr), now);
      sprintf (genbuf, "home/%c/%s/SR.%s", cuser.userid[0],
	 cuser.userid, cuser.userid);
      substitute_record (genbuf, fhdr, sizeof (*fhdr), ent);
    }
    else
      substitute_record (genbuf, fhdr, sizeof (*fhdr), ent);
    return POS_NEXT;
  }

        if (currmode & MODE_BOARD) {
            fhdr->filemode ^= FILE_TAGED;
           if (currmode & MODE_SELECT)
           {
                setbdir(genbuf, currboard);
                now = getindex(genbuf, fhdr->filename, sizeof(fileheader));
                substitute_record(genbuf, fhdr, sizeof(*fhdr), now);
                sprintf(genbuf, "boards/%s/SR.%s", currboard, cuser.userid);
                substitute_record(genbuf, fhdr, sizeof(*fhdr), ent);
                return POS_NEXT;
             }
        substitute_record (direct, fhdr, sizeof (*fhdr), ent);
        return POS_NEXT;
        }
         return DONOTHING;
}


int
del_tag(ent, fhdr, direct)
        int             ent;
        fileheader     *fhdr;
        char           *direct;
{
        char            genbuf[3];

        if (currstat == RMAIL) {
                getdata(1, 0, "�T�w�R���аO�H��(Y/N)? [Y]", genbuf, 3, LCECHO, 0);
                if (genbuf[0] != 'n') {
                        currfmode = FILE_TAGED;
                        if (delete_files(direct, cmpfmode))
                                return DIRCHANGED;
                }
                 return FULLUPDATE;
        }
if ((currstat != READING) || (currmode & MODE_BOARD)) {
                getdata(1, 0, "�T�w�R���аO�峹(Y/N)? [N]", genbuf, 3, LCECHO, 0);
                if (!strcmp(currboard, "Security")) {
                        pressanykey("Security�O�����峹!!");
                        return DONOTHING;
                }
                if (genbuf[0] == 'y') {
                        currfmode = FILE_TAGED;
                        if (currmode & MODE_SELECT) {
                                unlink(direct);
                                currmode ^= MODE_SELECT;
                                setbdir(direct, currboard);
                                delete_files(direct, cmpfmode);
                        }
                        if (delete_files(direct, cmpfmode))
                                return DIRCHANGED;
                }
                return FULLUPDATE;
        }
        return DONOTHING;
}


int
gem_tag (ent, fhdr, direct)
  int ent;
  fileheader * fhdr;
  char *direct;
{
  char genbuf[3];

  load_paste(); //Ū�J paste_file �өw��
  if(!*paste_path)
  {
    pressanykey("�|���w��,�жi�J��ذϤ��A�Q�������ؿ��� [P]");
//    return RC_FOOT;
    return FULLUPDATE;
  }

  if (currstat == RMAIL)
  {
    getdata (1, 0, "�T�w�����аO�H��(Y/N)? [Y]", genbuf, 3, LCECHO, 0);
    if (genbuf[0] != 'n')
    {
      currfmode = FILE_TAGED;
      if (gem_files (direct, cmpfmode))
        return DIRCHANGED;
    }
    return FULLUPDATE;
  }
  if ((currstat != READING) || (currmode & MODE_BOARD))
  {
    getdata (1, 0, "�T�w�����аO�峹(Y/N)? [N]", genbuf, 3, LCECHO, 0);
    if (genbuf[0] == 'y')
    {
      currfmode = FILE_TAGED;
      if (currmode & MODE_SELECT)
      {
        unlink (direct);
        currmode ^= MODE_SELECT;
        setbdir (direct, currboard);
        gem_files (direct, cmpfmode);
      }
      else
        gem_files(direct, cmpfmode);
      return DIRCHANGED;
    }
    return FULLUPDATE;
  }
  return DONOTHING;
}

int
mark(ent, fhdr, direct)
        int             ent;
        fileheader     *fhdr;
        char           *direct;
{
        //if (!(currmode & MODE_BOARD))
/*
                if (currstat == READING && !(currmode & MODE_BOARD))
                        return DONOTHING;*/
        if (currstat == READING && !(currmode & MODE_BOARD))
                        return DONOTHING;
/*
        if (currmode & MODE_BOARD && currstat == READING) {
                if (fhdr->filemode & FILE_MARKED)
                        deumoney(fhdr->owner, 200);
                else
                        inumoney(fhdr->owner, 200);
        }*/
        fhdr->filemode ^= FILE_MARKED;

        if (currmode & MODE_SELECT) {
                int             now;
                char            genbuf[100];
                if (currstat != READING)
                        sethomedir(genbuf, cuser.userid);
                else
                        setbdir(genbuf, currboard);
                now = getindex(genbuf, fhdr->filename, sizeof(fileheader));
                substitute_record(genbuf, fhdr, sizeof(*fhdr), now);
        } else
                substitute_record(direct, fhdr, sizeof(*fhdr), ent);

        return PART_REDRAW;
}

int
refusemark(ent, fhdr, direct)
  int ent;
   fileheader *fhdr;
   char *direct;
{
  if (currstat != READING || !(currmode & MODE_BOARD))
    return DONOTHING;

  fhdr->filemode ^= FILE_REFUSE;

  if (currmode & MODE_SELECT)
  {
    int now;
    char genbuf[100];

    setbdir(genbuf, currboard);
    now = getindex(genbuf, fhdr->filename, sizeof(fileheader));
    substitute_record(genbuf, fhdr, sizeof(*fhdr), now);
  }
  else
    substitute_record(direct, fhdr, sizeof(*fhdr), ent);

  return PART_REDRAW;
}


int
del_range(ent, fhdr, direct)
        int             ent;
        fileheader     *fhdr;
        char           *direct;
{
        char            num1[8], num2[8];
        int             inum1, inum2;

  if (currstat != READING || !(currmode & MODE_BOARD))
    return DONOTHING;
  else {
                getdata(1, 0, "[�]�w�R���d��] �_�I�G", num1, 5, DOECHO, 0);
                inum1 = atoi(num1);
                if (inum1 <= 0) {
                        outmsg("�_�I���~");
                        refresh();
                        sleep(1);
                        return FULLUPDATE;
                }
                getdata(1, 28, "���I�G", num2, 5, DOECHO, 0);
                inum2 = atoi(num2);
                if (inum2 < inum1) {
                        outmsg("���I���~");
                        refresh();
                        sleep(1);
                        return FULLUPDATE;
                }
                getdata(1, 48, msg_sure_ny, num1, 3, LCECHO, 0);
                if (*num1 == 'y') {
                        outmsg("�B�z��,�еy��...");
                        refresh();
                        if (currmode & MODE_SELECT) {
                                int             fd, size = sizeof(fileheader);
                                char            genbuf[100];
                                fileheader      rsfh;
                                int             i = inum1, now;
                                if (currstat == RMAIL)
                                        sethomedir(genbuf, cuser.userid);
                                else
                                        setbdir(genbuf, currboard);
                                if ((fd = (open(direct, O_RDONLY, 0))) != -1) {
                                        if (lseek(fd, (off_t) (size * (inum1 - 1)), SEEK_SET) != -1) {
                                                while (read(fd, &rsfh, size) == size) {
                                                        if (i > inum2)
                                                                break;
                                                        now = getindex(genbuf, rsfh.filename, size);
                                                        strcpy(currfile, rsfh.filename);
                                                        delete_file(genbuf, sizeof(fileheader), now, cmpfilename);
                                                        i++;
                                                }
                                        }
                                        close(fd);
                                }
                        }
                        delete_range(direct, inum1, inum2, NULL);
                        fixkeep(direct, inum1);
                        return DIRCHANGED;
                }
                return FULLUPDATE;
        }
        return DONOTHING;
}

#if 0
static void
lazy_delete(fhdr)
        fileheader     *fhdr;
{
        char            buf[20];

        sprintf(buf, "-%s", fhdr->owner);
        strncpy(fhdr->owner, buf, IDLEN + 1);
        strcpy(fhdr->title, "<< article deleted >>");
        fhdr->savemode = 'L';
}


int
del_one(ent, fhdr, direct)
        int             ent;
        fileheader     *fhdr;
        char           *direct;
{
        if ((currstat != READING) || (currmode & MODE_BOARD)) {
                strcpy(currfile, fhdr->filename);

                if (!update_file(direct, sizeof(fileheader), ent, cmpfilename, lazy_delete)) {
                        cancelpost(fhdr, YEA);
                        lazy_delete(fhdr);
                        return PART_REDRAW;
                }
        }
        return DONOTHING;
}
#endif

static int
del_post(ent, fhdr, direct)
        int             ent;
        fileheader     *fhdr;
        char           *direct;
{
        int             not_owned, money;
        char            genbuf[100];

  if (fhdr->filemode & (FILE_MARKED | FILE_DIGEST | FILE_REFUSE))
    return DONOTHING;


        if ((fhdr->filemode & FILE_MARKED)
            || (fhdr->filemode & FILE_DIGEST) || (fhdr->owner[0] == '-'))
                return DONOTHING;

        not_owned = strcmp(fhdr->owner, cuser.userid);

        if (!(currmode & MODE_BOARD) && not_owned || !strcmp(cuser.userid, "guest"))
                return DONOTHING;

        getdata(1, 0, msg_del_ny, genbuf, 3, LCECHO, 0);
        if (genbuf[0] == 'y') {
                strcpy(currfile, fhdr->filename);

                /*
                 * if (!update_file(direct, sizeof(fileheader), ent,
                 * cmpfilename, lazy_delete))
                 */
                setbfile(genbuf, currboard, fhdr->filename);
                money = (int) dashs(genbuf) / 25;
                if (!delete_file(direct, sizeof(fileheader), ent, cmpfilename)) {
                        if (currmode & MODE_SELECT) {
                                int             now;
                                setbdir(genbuf, currboard);
                                now = getindex(genbuf, fhdr->filename, sizeof(fileheader));
                                delete_file(genbuf, sizeof(fileheader), now, cmpfilename);
                        }
                        cancelpost(fhdr, not_owned);
                        if (!not_owned && strcmp(currboard, "Test")) {
                                if (cuser.numposts)
                                        cuser.numposts--;
                                UPDATE_USEREC;
                                move(b_lines - 1, 0);
                                clrtoeol();
                                if (money < 0)
                                        money = 0;
                                demoney(money);
                                prints("%s�A�z���峹� %d �g�A��I�M��O %d ��", msg_del_ok,
                                       cuser.numposts, money);
                                refresh();
                                sleep(1);
                        }
                        /*
                         * lazy_delete(fhdr); return FULLUPDATE;
                         */
                        return DIRCHANGED;
                }
        }
        return FULLUPDATE;
}


/* ----------------------------------------------------- */
/* �̧�Ū�s�峹                                          */
/* ----------------------------------------------------- */

static int      sequent_ent;


static int
sequent_messages(fptr)
        fileheader     *fptr;
{
        static int      idc;
        char            genbuf[200];

        if (fptr == NULL)
                return (idc = 0);

        if (++idc < sequent_ent)
                return 0;

        if (!brc_unread(fptr->filename))
                return 0;

        if (continue_flag) {
                genbuf[0] = 'y';
        } else {
                prints("Ū���峹��G[%s] �@�̡G[%s]\n���D�G[%s]",
                       currboard, fptr->owner, fptr->title);
                getdata(3, 0, "(Y/N/Quit) [Y]: ", genbuf, 3, LCECHO, 0);
        }

        if (genbuf[0] != 'y' && genbuf[0]) {
                clear();
                return (genbuf[0] == 'q' ? QUIT : 0);
        }
        setbfile(genbuf, currboard, fptr->filename);
        brc_addlist(fptr->filename);

        if (more(genbuf, YEA) == 0)
                outmsg("[31;47m  [31m(R)[30m�^�H  [31m(��,n)[30m�U�@��  [31m(��,q)[30m���}  [0m");
        continue_flag = 0;

        switch (egetch()) {
        case KEY_LEFT:
        case 'e':
        case 'q':
        case 'Q':
                break;

        case 'y':
        case 'r':
        case 'Y':
        case 'R':
                if (currmode & MODE_POST) {
                        strcpy(quote_file, genbuf);
                        do_reply(fptr);
                        *quote_file = 0;
                }
                break;

        case ' ':
        case KEY_DOWN:
        case '\n':
        case 'n':
                continue_flag = 1;
        }

        clear();
        return 0;
}


static int
sequential_read(ent, fhdr, direct)
        int             ent;
        fileheader     *fhdr;
        char           *direct;
{
        char            buf[40];

        clear();
        sequent_messages((fileheader *) NULL);
        sequent_ent = ent;
        continue_flag = 0;
        setbdir(buf, currboard);
        rec_apply(buf, sequent_messages, sizeof(fileheader));
        return FULLUPDATE;
}


save_mail(int ent, fileheader * fh, char *direct)
{
        fileheader      mhdr;
        char            fpath[MAXPATHLEN];
        char            genbuf[MAXPATHLEN];
        char           *p;

        if (ent < 0)
                strcpy(fpath, direct);
        else {
                strcpy(genbuf, direct);
                if (p = strrchr(genbuf, '/'))
                        *p = '\0';
                sprintf(fpath, "%s/%s", genbuf, fh->filename);
        }
        if (!dashf(fpath) || !HAS_PERM(PERM_BASIC)) {
                bell();
                return DONOTHING;
        }
        sethomepath(genbuf, cuser.userid);
        stampfile(genbuf, &mhdr);
        unlink(genbuf);
        f_cp(fpath, genbuf, O_TRUNC);
        if (HAS_PERM(PERM_SYSOP))
                strcpy(mhdr.owner, fh->owner);
        else
                strcpy(mhdr.owner, cuser.userid);
        strncpy(mhdr.title, fh->title + ((currstat == ANNOUNCE) ? 3 : 0), TTLEN);
        mhdr.savemode = '\0';
        mhdr.filemode = FILE_READ;
        sethomedir(fpath, cuser.userid);
        if (rec_add(fpath, &mhdr, sizeof(mhdr)) == -1) {
                bell();
                return DONOTHING;
        }
        pressanykey("�w��H!");
        return POS_NEXT;
}



/* ----------------------------------------------------- */
/* �ݪO�Ƨѿ��B��K�B��ذ�                              */
/* ----------------------------------------------------- */


//static int
extern int
b_notes_edit()
{
        if (currmode & MODE_BOARD) {
                char            buf[64];
                int             aborted;

                setbfile(buf, currboard, fn_notes);
                aborted = vedit(buf, NA);
                if (aborted == -1) {
                        clear();
                        pressanykey(msg_cancel);
                } else {
                        boardheader     fh;
                        int             pos;

                        getdata(3, 0, "�г]�w���Ĵ���(0 - 9999)�ѡH", buf, 5, DOECHO, "9999");
                        aborted = atol(buf);
                        pos = rec_search(fn_board, &fh, sizeof(fh), cmpbnames, (int) currboard);
                        /*
                         * SiE:
                         * �o�̻Prec_search���ǤJ�ȫ��A���P..���ӬO�z�ժ���]
                         */
                        fh.bupdate = aborted ? time(0) + aborted * 86400 : 0;
                        substitute_record(fn_board, &fh, sizeof(fh), pos);
                        touch_boards();
                }
                return FULLUPDATE;
        }
        return 0;
}

static int
b_water_edit()
{
        if (currmode & MODE_BOARD) {
                friend_edit(BOARD_WATER);
                return FULLUPDATE;
        }
        return 0;
}
/* skybinary 991118 �s�ݪO�`�� */
int
b_edit_holiday()
{
        if (currmode & MODE_BOARD) {
                char            ans[3];

                move(b_lines - 4, 0);
                clrtobot();
                getdata(b_lines - 4, 0, "�п��:(a)�W�[�`��,(e)�s��{�����`��,(q)���X [q] :",
                        ans, 3, DOECHO, 0);
                if (ans[0] == 'a') {
                        char            buf[20], tmp[50];
                        char            mo[4], da[4];
                        FILE           *fp;
                        getdata(b_lines - 3, 0, "�п�J���:(ex:07)", mo, 3, DOECHO, 0);
                        getdata(b_lines - 2, 0, "�п�J���:(ex:23)", da, 3, DOECHO, 0);
                        getdata(b_lines - 1, 0, "�п�J�`��(�̦h�K�Ӧr)", buf, 17, DOECHO, 0);
                        sprintf(tmp, "/home/bbs/boards/%s/feast", currboard);
                        fp = fopen(tmp, "a");
                        fprintf(fp, "%-2.2s %-2.2s %-16.16s\n", mo, da, buf);
                        fclose(fp);
                        return FULLUPDATE;
                }
                if (ans[0] == 'e') {
                        char            buf[100];
                        setbfile(buf, currboard, "feast");
                        vedit(buf, NA);
                        return FULLUPDATE;
                }
                if (ans[0] == 'q')
                        return FULLUPDATE;
                return FULLUPDATE;
        }
}




static int
visable_list_edit()
{
        if (currmode & MODE_BOARD) {
                friend_edit(BOARD_VISABLE);
                return FULLUPDATE;
        }
        return 0;
}
/*
 * static int can_vote_edit() { if (currmode & MODE_BOARD) {
 * friend_edit(FRIEND_CANVOTE); return FULLUPDATE; } return 0; }
 */
static int
bh_title_edit()
{
        boardheader     bp;
        boardheader    *getbcache();
        int             bid;
        if (currmode & MODE_BOARD) {
                char            genbuf[BTLEN];
                bid = getbnum(currboard);
                if (rec_get(fn_board, &bp, sizeof(boardheader), bid) == -1) {
                        pressanykey(err_bid);
                        return -1;
                }
                move(1, 0);
                clrtoeol();
                getdata(1, 0, "�п�J�ݪO�s����ԭz:", genbuf, BTLEN -
                        16, DOECHO, bp.title + 7);
                if (!genbuf[0])
                        return 0;
                strip_ansi(genbuf, genbuf, 0);
                strcpy(bp.title + 7, genbuf);

                substitute_record(fn_board, &bp, sizeof(boardheader), bid);
                touch_boards();
                log_usies("SetBoard", currboard);
                return FULLUPDATE;
        }
        return 0;
}

int
b_notes()
{
        char            buf[64];

        setbfile(buf, currboard, fn_notes);
        if (more(buf, YEA) == -1) {
                clear();
                pressanykey("���ݪO�|�L�u�Ƨѿ��v�C");
        }
        return FULLUPDATE;
}

int
b_board_notes()
{
        char            buf[64];

        setbfile(buf, currboard, "board");
        if (more(buf, YEA) == -1) {
                clear();
                pressanykey("���ݪO�|�L�d���C");
        }
        return FULLUPDATE;
}


int
board_select()
{
        char            fpath[80];
        char            genbuf[100];
        currmode &= ~MODE_SELECT;
        sprintf(fpath, "SR.%s", cuser.userid);
        setbfile(genbuf, currboard, fpath);
        unlink(genbuf);
        if (currstat == RMAIL)
                sethomedir(currdirect, cuser.userid);
        else
                setbdir(currdirect, currboard);
        return NEWDIRECT;
}

int
board_digest()
{

        if (currmode & MODE_SELECT)
                board_select();

        if (!(currmode & MODE_DIGEST))
                currmode ^= MODE_DIGEST;
        else {
                man();
                if (currmode & MODE_DIGEST)
                        currmode ^= MODE_DIGEST;
        }

        if (currmode & MODE_DIGEST)
                currmode &= ~MODE_POST;
        else if (haspostperm(currboard))
                currmode |= MODE_POST;

        setbdir(currdirect, currboard);

        return NEWDIRECT;
}

int
board_etc()
{
        if (!HAS_PERM(PERM_SYSOP))
                return DONOTHING;
        currmode ^= MODE_ETC;
        if (currmode & MODE_ETC)
                currmode &= ~MODE_POST;
        else if (haspostperm(currboard))
                currmode |= MODE_POST;

        setbdir(currdirect, currboard);
        return NEWDIRECT;
}


static int
good_post(ent, fhdr, direct)
        int             ent;
        fileheader     *fhdr;
        char           *direct;
{
        char            genbuf[200];
        char            genbuf2[200];
        fileheader      digest;

        memcpy(&digest, fhdr, sizeof(digest));
        digest.filename[0] = 'G';

        if ((currmode & MODE_DIGEST) || !(currmode & MODE_BOARD))
                return DONOTHING;

        if (fhdr->filemode & FILE_DIGEST) {
                int             now;
                setbgdir(genbuf2, currboard);
                now = getindex(genbuf2, digest.filename);
                strcpy(currfile, digest.filename);
                delete_file(genbuf2, sizeof(fileheader), now, cmpfilename);
                sprintf(genbuf2, BBSHOME "/boards/%s/%s", currboard, currfile);
                unlink(genbuf2);
                fhdr->filemode = (fhdr->filemode & ~FILE_DIGEST);
                deumoney(fhdr->owner, 500);
        } else {
                char           *ptr, buf[64];
                strcpy(buf, direct);
                ptr = strrchr(buf, '/') + 1;
                ptr[0] = '\0';
                sprintf(genbuf, "%s%s", buf, digest.filename);
                if (!dashf(genbuf)) {
                        digest.savemode = digest.filemode = 0;
                        sprintf(genbuf2, "%s%s", buf, fhdr->filename);
                        f_cp(genbuf2, genbuf, O_TRUNC);
                        strcpy(ptr, fn_mandex);
                        rec_add(buf, &digest, sizeof(digest));
                }
                fhdr->filemode = (fhdr->filemode & ~FILE_MARKED) | FILE_DIGEST;
                inumoney(fhdr->owner, 500);
        }
        substitute_record(direct, fhdr, sizeof(*fhdr), ent);
        if (currmode & MODE_SELECT) {
                int             now;
                char            genbuf[100];
                setbdir(genbuf, currboard);
                now = getindex(genbuf, fhdr->filename, sizeof(fileheader));
                substitute_record(genbuf, fhdr, sizeof(*fhdr), now);
        }
        return PART_REDRAW;
}

static int
b_help()
{
        film_out(FILM_READ, -1);
        return FULLUPDATE;
}
/* skybinary 991119 �ݪO�οﶵ */
static int
bm_menu()
{
        char            ans[4], buf[100];

        move(b_lines - 3, 0);
        outs("(1)�d�� (2)�ݯd�� (3)�ݸ`�� (4)�ݤ����W�� (5)�a�� (6)����έp\n");
        if (currmode & MODE_BOARD)
                outs("(7)�s����O�W (8)�s�`�� (9)�s���� (0)�a�� (a)�ݪO����\n");
        getdata(b_lines - 1, 0, "�п�J�Q�n���F��: ", ans, 2, LCECHO, 0);

        switch (ans[0]) {
        case '1':
                DL_func("SO/starnote.so:notepad_brd");
                break;
        case '2':
                b_board_notes();
                break;
        case '3':
                sprintf(buf, BBSHOME "/boards/%s/feast", currboard);
                more(buf, NA);
                break;
        case '4':
                sprintf(buf, BBSHOME "/boards/%s/water", currboard);
                more(buf, NA);
                break;

        case '5':
                //DL_func("SO/family.so:family");
                pressanykey("�a�ھ�פ�...");
                //family();
                break;
        case '6':
                sprintf(buf, BBSHOME "/boards/%s/list", currboard);
                more(buf, NA);
                break;

                if (currmode & MODE_BOARD) {
        case '7':
                        bh_title_edit();
                        break;
        case '8':
                        b_edit_holiday();
                        break;
        case '9':
                        b_water_edit();
                        break;
                }
        case 'a':
                DL_func("SO/star.so:bh_desc_edit");
                break;
                /*
                 * case 'b':
                 *
                 * break;
                 */
        default:
                return FULLUPDATE;
        }
        pressanykey(NULL);
        return FULLUPDATE;
}

int
post_give(ent, fhdr, direct)
        int             ent;
        fileheader     *fhdr;
        char           *direct;
{
        char            genbuf[200], ans[4];
        int             money;
        fileheader      mymail;
        FILE           *fp = fopen("tmp/point", "w");
        time_t          now;
        time(&now);

        //if (HAS_PERM(PERM_SAD))
                if (currmode & MODE_BOARD) {
                        fileheader      tmpfhdr = *fhdr;
                        getdata(b_lines - 1, 0, "�нT�w�n���I�o�g�峹��? (y)�O(n)�_ [n]",
                                ans, 2, DOECHO, 0);
                        if (ans[0] == 'y') {
                                getdata(b_lines - 1, 0, "ı�o�Ӥ峹�p��?���Ӥ��Ƨa! (q)���X[q]:",
                                        ans, 3, DOECHO, 0);
                                money = atoi(ans);
                                if (ans[0] != 'q')
                                        sprintf(genbuf, "%-35.35s   ��%d��", tmpfhdr.title, money);
                                else
                                        return FULLUPDATE;
                                strcpy(tmpfhdr.title, genbuf);
                                getdata(b_lines, 0, "�T�w��?? (y)�O (n)�_ [n]", ans, 2, DOECHO, 0);
                                if (ans[0] == 'y') {
                                        *fhdr = tmpfhdr;
                                        substitute_record(direct, fhdr, sizeof(*fhdr), ent);
                                        sprintf(genbuf, "�@��: �P�e���I�e���| \n"
                                                "���D: [�q��] ���I���i�I\n"
                                                "�ɶ�: %s\n\n", ctime(&now));
                                        fputs(genbuf, fp);
                                        sprintf(genbuf, "���߱z�b %s �O���峹: %-35.35s \n",
                                                currboard, tmpfhdr.title);
                                        fputs(genbuf, fp);
                                        sprintf(genbuf, "�Q�O�D %s ���� %d ����~~\n", cuser.userid, money);
                                        fputs(genbuf, fp);
                                        /*
                                         * sprintf(genbuf,"���߱z�o�� %d
                                         * �s��!! \n",money);
                                         * fputs(genbuf,fp);
                                         */
                                        fclose(fp);
                                        //ingold(money);
                                        sprintf(genbuf, "home/%c/%s",
					 tmpfhdr.owner[0], tmpfhdr.owner);
                                        stampfile(genbuf, &mymail);
                                        strcpy(mymail.owner, "���I�e���|");
                                        rename("tmp/point", genbuf);
                                        sprintf(mymail.title, "[�q��] ���I���i�I");
                                        sprintf(genbuf, "home/%c/%s/.DIR",
					 tmpfhdr.owner[0], tmpfhdr.owner);
                                        rec_add(genbuf, &mymail, sizeof(mymail));
                                        sprintf(genbuf, "��[1;33m%s[37m ���I�e��\
[36m%s[37m ���[32m %d ��[37m, [35m%s[37m���峹[m",
                                                Cdate(&now), cuser.userid, money, tmpfhdr.owner);
                                        f_cat("log/point.log", genbuf);

                                }
                        } else
                                return FULLUPDATE;
                }
        return FULLUPDATE;
}

int
b_board_notes_edit2()
{
        DL_func("SO/starnote.so:notepad_brd");
}


/* ----------------------------------------------------- */
/* �ݪO�\���                                            */
/* ----------------------------------------------------- */


struct one_key  read_comms[] = {
        KEY_TAB, board_digest,
        'A', board_etc,
        'b', b_notes,
        'c', cite,
        'r', read_post,
        'z', man,
        'D', del_range,
        /*
         * woju
         */
        Ctrl('S'), save_mail,
        'S', sequential_read,
        'E', edit_post,
        'T', edit_title,
        's', do_select,
        'B', bh_title_edit,
        'W', b_notes_edit,
        Ctrl('w'), b_board_notes_edit2,
        Ctrl('n'), b_board_notes,
        Ctrl('h'), b_edit_holiday,
        Ctrl('x'), bm_menu,
        't', add_tag,
        'w', b_water_edit,
        'v', visable_list_edit,
        Ctrl('D'), del_tag,
        'x', cross_post,
        'h', b_help,
        'g', good_post,
        'y', reply_post,
        'd', del_post,
        'm', mark,
        'o', refusemark,
        'f', post_give,
        Ctrl('P'), do_post,
        'C',gem_tag,
        Ctrl('C'), Cite_posts,
        '\0', NULL
};

ReadSelect()
{
        int             mode0 = currutmp->mode;
        int             stat0 = currstat;
        char            genbuf[200];

        currstat = XMODE;
        if (do_select(0, 0, genbuf) == NEWDIRECT)
                Read();
        currutmp->mode = mode0;
        currstat = stat0;
}

void
log_board(board, usetime)
        char           *board;
        time_t          usetime;
{
        time_t          now;
        boardheader     bh;
        int             bid = getbnum(board);
        now = time(0);
        rec_get(fn_board, &bh, sizeof(bh), bid);
        if (usetime >= 10) {
                ++bh.totalvisit;
                bh.totaltime += usetime;
                strcpy(bh.lastvisit, cuser.userid);
                bh.lastime = now;
        }
        substitute_record(fn_board, &bh, sizeof(bh), bid);
}

int
Read()
{
        int             mode0 = currutmp->mode;
        int             stat0 = currstat;
        int             bid;
        char            buf[40], buf2[40];
        time_t          startime = time(0);
        extern struct BCACHE *brdshm;

        resolve_boards();

        setutmpmode(READING);
        set_board();

        if (board_visit_time < board_note_time) {
                setbfile(buf, currboard, fn_notes);
                sprintf(buf2, "/home/bbs/boards/%s/board", currboard);
                more(buf, YEA);
                if (!HAS_HABIT(HABIT_BOARD))
                        more(buf2, YEA);
        }
        bid = getbnum(currboard);
        currutmp->brc_id = bid;
        setbdir(buf, currboard);
        curredit &= ~EDIT_MAIL;
        i_read(READING, buf, readtitle, doent, read_comms,
               &(brdshm->total[bid - 1]));

        log_board(currboard, time(0) - startime);
        brc_update();

        currutmp->brc_id = 0;
        currutmp->mode = mode0;
        currstat = stat0;
        return 0;
}


int
Select()
{
        char            genbuf[200];

        setutmpmode(SELECT);
        do_select(0, NULL, genbuf);
        return 0;
}


int
Post()
{
        do_post();
        return 0;
}

void
cancel_post(fhdr, fpath)
        fileheader     *fhdr;
        char           *fpath;
{
        int             fd;

        if ((fhdr->savemode == 'S') &&  /* �~��H�� */
            ((fd = open(fpath, O_RDONLY)) >= 0)) {
#define NICK_LEN        80


                char           *ptr, *left, *right, nick[NICK_LEN];
                FILE           *fout;
                int             ch;

                ptr = nick;
                ch = read(fd, ptr, NICK_LEN);
                close(fd);
                ptr[ch] = '\0';
                if (!strncmp(ptr, str_author1, LEN_AUTHOR1) ||
                    !strncmp(ptr, str_author2, LEN_AUTHOR2)) {
                        if (left = (char *) strchr(ptr, '(')) {
                                right = NULL;
                                for (ptr = ++left; ch = *ptr; ptr++) {
                                        if (ch == ')')
                                                right = ptr;
                                        else if (ch == '\n')
                                                break;
                                }

                                if (right != NULL) {
                                        *right = '\0';

                                        if (fout = fopen(BBSHOME "/innd/cancel.bntp", "a")) {
                                                fprintf(fout, "%s\t%s\t%s\t%s\t%s\n",
                                                        currboard, fhdr->filename, fhdr->owner  /* cuser.userid */
                                                        ,left, fhdr->title);
                                                fclose(fout);
                                        }
                                }
                        }
                }
#undef  NICK_LEN
        }
}
