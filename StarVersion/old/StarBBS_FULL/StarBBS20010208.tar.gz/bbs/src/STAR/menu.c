/*-------------------------------------------------------*/
/* menu.c       ( NTHU CS MapleBBS Ver 2.36 )            */
/*-------------------------------------------------------*/
/* target : menu/help/movie routines                     */
/* create : 95/03/29                                     */
/* update : 95/12/15                                     */
/*-------------------------------------------------------*/


#include "bbs.h"
#include "menu.h"
#include "build.h"

/* ------------------------------------- */
/* help & menu processring               */
/* ------------------------------------- */
int refscreen = NA;
extern char *boardprefix;

int
egetch()
{
  int rval;

  while (1)
  {
    rval = igetkey();
    if (talkrequest)
    {
      talkreply();
      refscreen = YEA;
      return rval;
    }
    if (rval != Ctrl('L'))
      return rval;
    redoscr();
  }
}

void
showtitle(title,mid)
char *title,*mid;
{
 showtitle2(mid,title,BBSNAME);
}


//if(currstat != READBRD && READNEW)

/* ------------------------------------ */
/* �ʵe�B�z                              */
/* ------------------------------------ */

#define FILMROW 12
unsigned char menu_row = 13;
unsigned char menu_column = 4;
char mystatus[160];

//skybinary 20000501: ���film_out,�`��g�J�]�ܤF
movie()
{
  static char myweek[] = "��@�G�T�|����";
  char *msgs[] = {"��", "�}", "��", "��","��"};
  time_t now = time(NULL);
  struct tm *ptime = localtime(&now);
  int i,tag = FILM_MOVIE;
  extern char today_is[20];

  if (currstat == BUILDING)
  {
   move(2,0);
   prints(" [��]���}  [����]���  [��]�i�J  [h]����  [x]�ֳt���\n");
   prints("-----------------------------------------------------------\n");
   return;
  }
  if(HAVE_HABIT(HABIT_MOVIE))
    tag = film_out(tag, 1);
  i = ptime->tm_wday << 1;
  update_data();

sprintf(mystatus, "[4%d;1m��%d:%02d %c%c %02d/%02d�w[33m%-16s[37m�w\
�߱�:%4.4s�w[36m��%7ld��[37m�w[36m�s%4d��[37m�wcall:%s��[m",
    cuser.color,ptime->tm_hour, ptime->tm_min, myweek[i], myweek[i + 1],
    ptime->tm_mon + 1, ptime->tm_mday, currutmp->birth ?
    "�ͤ�n�Ыȭ�" : today_is,
    cuser.feeling, cuser.money, cuser.starmoney, msgs[currutmp->pager]);
 outmsg(mystatus);
 refresh();
}

// skybinary 2000 0612 �p�ݪO�g�JSHM

int lenth[10] = {0};

static int
show_menu(p)
 MENU2 *p;
{
  register int n = 0;
  int a = 0, tag, i, j;
  register char *s;
  char buf[80],item[50];

  movie();

  for(i=0;i<10;i++)
   lenth[i] = 0;

  move(menu_row, 0);
  while ((s = p[n].desc)!=NULL)
  {
    if ( s != NULL )
    {
     if (HAS_PERM(p[n].level))
     {
      move(menu_row+a,0);
      sprintf(buf,s+2); clrtoeol();
      sprintf(item,"%*s  ([1;33m%c[m)%s\n",menu_column,"",s[1], buf);
      lenth[a] = strlen(item);
      if(lenth[a] < 46) lenth[a] = 46;
      outs(item);
      a++;
     }
     n++;
    }
    else
     prints("%*34s"," ");
  }

  if(a < 11)
  {
   for(i=a;i<11;i++)
   {
    lenth[i] = 36;
    move(menu_row+a,0);
    for(j=0;j<80;j++)
       outc(' ');
   }
  }
  if (currstat != BUILDING)
  {
   tag = rand()%10 +12;
   film_out(tag,13);
  }
  return n - 1;
}


int
domenu(cmdmode, cmdtitle, cmd, cmdtable)
  char *cmdtitle;
  int cmdmode, cmd;
  struct MENU2 *cmdtable;
{

  int lastcmdptr;
  int n, pos, total, i, color;
  int err, a;
  int chkmailbox();
  static char cmd0[LOGIN];
  char buf[100];

  if (cmd0[cmdmode])
     cmd = cmd0[cmdmode];

  setutmpmode(cmdmode);

  showtitle2(BoardName,cmdtitle,BBSNAME);
  total = show_menu(cmdtable);
  outmsg(mystatus);

  //�ץ�����bug
  if(!HAS_HABIT(HABIT_LBAR))
  {
   if(HAS_PERM(PERM_SYSOP))
    lastcmdptr = 0;
   else //bugs??
   {
    if(currstat == MMENU)
     lastcmdptr = 1;
    else
     lastcmdptr = 0;
   }
   pos=0;
 }
 else
   lastcmdptr = pos = 0;

  do
  {
    i = -1;

    switch (cmd)
    {
    case KEY_ESC:
       if (KEY_ESC_arg == 'c')
          capture_screen();
       else if (KEY_ESC_arg == 'n') {
          edit_note();
          refscreen = YEA;
       }
       i = lastcmdptr;
       break;
    case Ctrl('N'):
       New();
       refscreen = YEA;
       i = lastcmdptr;
       break;
    case Ctrl('A'):
       if (man() == FULLUPDATE)
          refscreen = YEA;
       i = lastcmdptr;
       break;
    case 'x':
    case 'X':
       addmenu();
       refscreen = YEA;
       i = lastcmdptr;
       break;
    case Ctrl('F') :
       Favor();
       refscreen = YEA;
       i = lastcmdptr;
       break;
    case KEY_DOWN:
      i = lastcmdptr;

    case KEY_HOME:
    case KEY_PGUP:
      do
      {
        if (++i > total)
          i = 0;
      } while (!HAS_PERM(cmdtable[i].level));
      break;

    case KEY_END:
    case KEY_PGDN:
      i = total;
      break;

    case KEY_UP:
      i = lastcmdptr;
      do
      {
        if (--i < 0)
          i = total;
      } while (!HAS_PERM(cmdtable[i].level));
      break;

    case KEY_LEFT:
    case 'e':
    case 'E':
      if (cmdmode == MMENU)
        cmd = 'G';
      else if ((cmdmode == MAIL) && chkmailbox())
        cmd = 'R';
      else
        {
         if (cmdmode ==  BUILDING)
         {
          menu_row = 13;
          menu_column = 4;
         }
        return 0;
        }
    default:
       if ((cmd == Ctrl('G')  || cmd == Ctrl('S')) && (currstat == MMENU
 || currstat == TMENU || currstat == XMENU))  {
          if (cmd == Ctrl('S'))
             ReadSelect();
          else
             Read();
          refscreen = YEA;
          i = lastcmdptr;
          break;
        }
      if (cmd == '\n' || cmd == '\r' || cmd == KEY_RIGHT)
      {
          boardprefix = cmdtable[lastcmdptr].desc + 2;
        if(cmdtable[lastcmdptr].mode && DL_get(cmdtable[lastcmdptr].cmdfunc))
        {  //�ϥ�DSO
          void *p = (void *)DL_get(cmdtable[lastcmdptr].cmdfunc);
          if(p) cmdtable[lastcmdptr].cmdfunc = p;
          else break;
        }
        currstat = XMODE;
        {
          int (*func)() = 0;
          func = cmdtable[lastcmdptr].cmdfunc;
          if ((err = (*func)()) == QUIT)
            return;
        }

        currutmp->mode = currstat = cmdmode;

        if (err == XEASY)
        {
          refresh();
          sleep(1);
        }
        else if (err != XEASY + 1 || err == FULLUPDATE)
          refscreen = YEA;

        if (err != -1)
          cmd = cmdtable[lastcmdptr].desc[0];
        else
          cmd = cmdtable[lastcmdptr].desc[1];
        cmd0[cmdmode] = cmdtable[lastcmdptr].desc[0];
      }

      if (cmd >= 'a' && cmd <= 'z')
        cmd &= ~0x20;
      while (++i <= total)
      {
        if (cmdtable[i].desc[1] == cmd)
          break;
      }
    }

    if (i > total || !HAS_PERM(cmdtable[i].level))
      continue;

    if (refscreen)
    {
      showtitle2(BoardName,cmdtitle,BBSNAME);
      show_menu(cmdtable);
      outmsg(mystatus);
      refscreen = NA;
    }

  if(HAS_HABIT(HABIT_LBAR))
  {
    cursor_clear(menu_row + pos, menu_column);
    n = pos = -1;
    while (++n <= (lastcmdptr = i))
    {
      if (HAS_PERM(cmdtable[n].level))
        pos++;
    }
     cursor_show(menu_row + pos, menu_column);
  }
  else
  {
   // skybinary 20000427
   color=rand()%7;
   sprintf(buf,"[m([1;33m%c[m)%-22s",
   cmdtable[lastcmdptr].desc[0],cmdtable[lastcmdptr].desc+2);
    cursor_bar_clear(menu_row + pos, menu_column,3,
     buf,NULL);
    n = pos = -1;
    while (++n <= (lastcmdptr = i))
    {
      if (HAS_PERM(cmdtable[n].level))
        pos++;
    }
    if(!HAS_HABIT(HABIT_DES)) // ��ܻ���
    {
     if(currstat == BUILDING)
     {
      for(a=0;a<8;a++)
      {
       move(5+a,0);
       clrtoeol();
      }
       move(5,0);
     }
     else
     {
      move(b_lines-1,0);
      clrtoeol();
     }
     if(strlen(cmdtable[lastcmdptr].desc2) < 1)
      cmdtable[lastcmdptr].desc2 = "�i�h�ݬݴN���D��!!";
     prints("[1;33m����:[m%s",cmdtable[lastcmdptr].desc2);

    }
   sprintf(buf,"[4%d;1m[%c]%-22s[m",color,
    cmdtable[lastcmdptr].desc[0],cmdtable[lastcmdptr].desc+2);
     cursor_bar_show(menu_row + pos, menu_column,3,
     buf, color);

   }
  } while (((cmd = egetch()) != EOF) || refscreen);

  abort_bbs();
}
/* INDENT OFF */


Name_Menu()
{
  domenu(NMENU, "�U�ئW��", 'G', namelist);
  return 0;
}

static int
admin()
{
  domenu(ADMIN, "�����Ѥj", 'S', adminlist);
  return 0;
}

static int
Class()
{
  domenu(CLASS, "�����ݪO", 'C', classlist);
  return 0;
}

static int
Mail()
{
  domenu(MAIL, "�l����", 'R', maillist);
  return 0;
}

int
static Talk()
{
  domenu(TMENU, "��ѿ��", 'L', talklist);
  return 0;
}

static int
User()
{
  domenu(UMENU, "�ӤH�]�w", 'H', userlist);
  return 0;
}

int building();

/* Addmenu  edit by skybinary 991119*/
int addmenu()
{
 char ans[4];
 move(b_lines - 2 ,0);
 outs("(1)�d�ݫH�c (2)��d���O (3)�ӷ~���� (4)�ӤH�]�w (5)�̷R�ݪO\n");
 getdata(b_lines-1,0,"�z�Q�n���A��: ",ans,2,LCECHO,0);

  switch (ans[0])
  {
  case '1':
        Mail();
        break;
  case '2':
        DL_func("SO/starnote.so:notepad_main");
        break;
  case '3':
        building();
        break;
  case '4':
        User();
        break;
  case '5':
        Favor();
        break;
  default:
    return FULLUPDATE;
  }
}

