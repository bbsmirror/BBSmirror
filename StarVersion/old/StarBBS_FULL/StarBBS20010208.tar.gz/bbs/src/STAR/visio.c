/*-------------------------------------------------------*/
/* visio.c      ( NTHU CS MapleBBS Ver 2.39 )            */
/*-------------------------------------------------------*/
/* target : VIrtual Screen Input Output routines         */
/* create : 95/03/29                                     */
/* update : 96/10/10                                     */
/*-------------------------------------------------------*/




/*-------------------------------------------------------*/
/* io.c         ( NTHU CS MapleBBS Ver 2.36 )            */
/*-------------------------------------------------------*/
/* target : basic console/screen/keyboard I/O routines   */
/* create : 95/02/28                                     */
/* update : 95/12/15                                     */
/*-------------------------------------------------------*/

#include "bbs.h"
#include <varargs.h>

#ifdef  Linux
#define OBUFSIZE  (2048)
#define IBUFSIZE  (128)
#else
#define OBUFSIZE  (4096)
#define IBUFSIZE  (256)
#endif

#define INPUT_ACTIVE    0
#define INPUT_IDLE      1

static char outbuf[OBUFSIZE];
static int obufsize = 0;

static char inbuf[IBUFSIZE];
static int ibufsize = 0;
static int icurrchar = 0;

static int i_mode = INPUT_ACTIVE;


/* term.c       ( NTHU CS MapleBBS Ver 2.36 )            */

#ifdef LINUX
#if (__GLIBC__ != 2)

#include <linux/termios.h>
#else
#include <termios.h>
#endif
#define stty(fd, data) tcsetattr( fd, TCSETS, data )
#define gtty(fd, data) tcgetattr( fd, data )
#endif

#ifndef TANDEM
#define TANDEM  0x00000001
#endif

#ifndef CBREAK
#define CBREAK  0x00000002
#endif

#ifdef LINUX
struct termios tty_state, tty_new;
#else
struct sgttyb tty_state, tty_new;
#endif

#ifndef BSD44
/* tparm.c  By Ross Ridge  Public Domain 92/02/01 07:30:36 */

#ifdef USE_SCCS_IDS
static const char SCCSid[] =
"@(#) mytinfo tparm.c 3.2 92/02/01 public domain, By Ross Ridge";
#endif

#ifndef MAX_PUSHED
#define MAX_PUSHED      32
#endif

#define ARG     1
#define NUM     2

#define INTEGER 1
#define STRING  2
#define MAX_LINE 640

typedef void* anyptr;

typedef struct stack_str {
        int     type;
        int     argnum;
        int     value;
} stack;

static stack S[MAX_PUSHED];
static stack vars['z'-'a'+1];
static int pos = 0;

static struct arg_str {
        int type;
        int     integer;
        char    *string;
} arg_list[10];

static int argcnt;

static va_list tparm_args;

#endif

/* ----------------------------------------------------- */
/* init tty control code                                 */
/* ----------------------------------------------------- */

#define TERMCOMSIZE (40)

int dumb_term = YEA;

char clearbuf[TERMCOMSIZE];
int clearbuflen;

char cleolbuf[TERMCOMSIZE];
int cleolbuflen;

char cursorm[TERMCOMSIZE];
char *cm;

char changescroll[TERMCOMSIZE];
char *cs;
char savecursor[TERMCOMSIZE];
char *sc;

char restorecursor[TERMCOMSIZE];
char *rc;

char scrollforward[TERMCOMSIZE];
char *sf;

char scrollreverse[TERMCOMSIZE];
char *sr;

char scrollrev[TERMCOMSIZE];
int scrollrevlen;

char scrollset[TERMCOMSIZE];
int scrollsetlen;

char strtstandout[TERMCOMSIZE];
int strtstandoutlen;

char endstandout[TERMCOMSIZE];
int endstandoutlen;

int t_lines = 24;
int b_lines = 23;
int p_lines = 20;
int t_columns = 80;

int automargins;
char *outp;
int *outlp;

void
output(s, len)
  char *s;
{
  /* Invalid if len >= OBUFSIZE */

  if (obufsize + len > OBUFSIZE)
  {
    write(1, outbuf, obufsize);
    obufsize = 0;
  }
  memcpy(outbuf + obufsize, s, len);
  obufsize += len;
}


/* screen.c     ( NTHU CS MapleBBS Ver 2.36 )            */

#define o_clear()     output(clearbuf,clearbuflen)
#define o_cleol()     output(cleolbuf,cleolbuflen)
#define o_scrollrev() output(scrollrev,scrollrevlen)
#define o_standup()   output(strtstandout,strtstandoutlen)
#define o_standdown() output(endstandout,endstandoutlen)


uschar scr_lns, scr_cols;
uschar cur_ln = 0, cur_col = 0;
uschar docls, downfrom = 0;
uschar standing = NA;
char roll = 0;
int scrollcnt, tc_col, tc_line;

screenline *big_picture = NULL;

extern void ochar();
extern int i_newfd;

void
oflush()
{
  if (obufsize)
  {
    write(1, outbuf, obufsize);
    obufsize = 0;
  }
}


/*-------------------------------------------------------*/
/* screen.c     ( NTHU CS MapleBBS Ver 2.36 )            */
/*-------------------------------------------------------*/
/* target : ANSI/Chinese screen display routines         */
/* create : 95/03/29                                     */
/* update : 95/12/15                                     */
/*-------------------------------------------------------*/

void
initscr()
{
  if (!dumb_term && !big_picture)
  {
    extern char *calloc();

    scr_lns = t_lines;
    scr_cols = t_columns = ANSILINELEN;
    /* scr_cols = MIN(t_columns, ANSILINELEN); */
    big_picture = (screenline *) calloc(scr_lns, sizeof(screenline));
    docls = YEA;
  }
}

void
move(y, x)
{
  cur_col = x;
  cur_ln = y;
}


void
getyx(y, x)
  int *y, *x;
{
  *y = cur_ln;
  *x = cur_col;
}

static void
rel_move(was_col, was_ln, new_col, new_ln)
{
  extern char *BC;

  if (new_ln >= t_lines || new_col >= t_columns)
    return;

  tc_col = new_col;
  tc_line = new_ln;
  if (new_col == 0)
  {
    if (new_ln == was_ln)
    {
      if (was_col)
        ochar('\r');
      return;
    }
    else if (new_ln == was_ln + 1)
    {
      ochar('\n');
      if (was_col)
        ochar('\r');
      return;
    }
  }

  if (new_ln == was_ln)
  {
    if (was_col == new_col)
      return;

    if (new_col == was_col - 1)
    {
      if (BC)
        tputs(BC, 1, ochar);
      else
        ochar(Ctrl('H'));
      return;
    }
  }
  do_move(new_col, new_ln);
}
static void
standoutput(buf, ds, de, sso, eso)
  char *buf;
  int ds, de, sso, eso;
{
  if (eso <= ds || sso >= de)
  {
    output(buf + ds, de - ds);
  }
  else
  {
    int st_start, st_end;

    st_start = MAX(sso, ds);
    st_end = MIN(eso, de);
    if (sso > ds)
      output(buf + ds, sso - ds);
    o_standup();
    output(buf + st_start, st_end - st_start);
    o_standdown();
    if (de > eso)
      output(buf + eso, de - eso);
  }
}

void
redoscr()
{
  register screenline *bp;
  register int i, j, len;

  if (dumb_term)
    return;

  o_clear();
  for (tc_col = tc_line = i = 0, j = roll; i < scr_lns; i++, j++)
  {
    if (j >= scr_lns)
      j = 0;
    bp = &big_picture[j];
    if (len = bp->len)
    {
      rel_move(tc_col, tc_line, 0, i);

      if (bp->mode & STANDOUT)
        standoutput(bp->data, 0, len, bp->sso, bp->eso);
      else
        output(bp->data, len);
      tc_col += len;
      if (tc_col >= t_columns)
      {
        if (automargins)
          tc_col = t_columns - 1;
        else
        {
          tc_col -= t_columns;
          tc_line++;
          if (tc_line >= t_lines)
            tc_line = b_lines;
        }
      }
      bp->mode &= ~(MODIFIED);
      bp->oldlen = len;
    }
  }
  rel_move(tc_col, tc_line, cur_col, cur_ln);
  docls = scrollcnt = 0;
  oflush();
}

void
refresh()
{
  register screenline *bp = big_picture;
  register int i, j, len;
  extern int automargins;
  extern int scrollrevlen;

  if (dumb_term)
    return;
  if (num_in_buf())
    return;

  if ((docls) || (abs(scrollcnt) >= (scr_lns - 3)))
  {
    redoscr();
    return;
  }

  if (scrollcnt < 0)
  {
    if (!scrollrevlen)
    {
      redoscr();
      return;
    }
    rel_move(tc_col, tc_line, 0, 0);
    do
    {
      o_scrollrev();
    } while (++scrollcnt);
  }
  else if (scrollcnt > 0)
  {
    rel_move(tc_col, tc_line, 0, b_lines);
    do
    {
      ochar('\n');
    } while (--scrollcnt);
  }

  for (i = 0, j = roll; i < scr_lns; i++, j++)
  {
    if (j >= scr_lns)
      j = 0;
    bp = &big_picture[j];
    len = bp->len;
    if (bp->mode & MODIFIED && bp->smod < len)
    {
      bp->mode &= ~(MODIFIED);
      if (bp->emod >= len)
        bp->emod = len - 1;
      rel_move(tc_col, tc_line, bp->smod, i);

      if (bp->mode & STANDOUT)
        standoutput(bp->data, bp->smod, bp->emod + 1, bp->sso, bp->eso);
      else
        output(&bp->data[bp->smod], bp->emod - bp->smod + 1);
      tc_col = bp->emod + 1;
      if (tc_col >= t_columns)
      {
        if (automargins)
        {
          tc_col -= t_columns;
          if (++tc_line >= t_lines)
            tc_line = b_lines;
        }
        else
          tc_col = t_columns - 1;
      }
    }

    if (bp->oldlen > len)
    {
      rel_move(tc_col, tc_line, len, i);
      o_cleol();
    }
    bp->oldlen = len;
  }
  rel_move(tc_col, tc_line, cur_col, cur_ln);
  oflush();
}


void
clear()
{
  if (!dumb_term)
  {
    register int i;

    docls = YEA;
    cur_col = cur_ln = roll = downfrom = i = 0;
    do
    {

#if 0
      memset(&big_picture[i], 0, 3);
#else
      register screenline *slp;

      slp = &big_picture[i];
      slp->mode = slp->len = slp->oldlen = 0;
#endif
    } while (++i < scr_lns);
  }
}


void
clrtoeol()
{
  if (!dumb_term)
  {
    register screenline *slp;
    register int ln;

    standing = NA;
    if ((ln = cur_ln + roll) >= scr_lns)
      ln -= scr_lns;
    slp = &big_picture[ln];
    if (cur_col <= slp->sso)
      slp->mode &= ~STANDOUT;

    if (cur_col > slp->oldlen)
    {
      for (ln = slp->len; ln <= cur_col; ln++)
        slp->data[ln] = ' ';
    }

    if (cur_col < slp->oldlen)
    {
      for (ln = slp->len; ln >= cur_col; ln--)
        slp->data[ln] = ' ';
    }

    slp->len = cur_col;
  }
}



void
clrtobot()
{
  if (!dumb_term)
  {
    register screenline *slp;
    register int i, j;

    for (i = cur_ln, j = i + roll; i < scr_lns; i++, j++)
    {
      if (j >= scr_lns)
        j -= scr_lns;
      slp = &big_picture[j];
      slp->mode = slp->len = 0;
      if (slp->oldlen)
        slp->oldlen = 255;
    }
  }
}

void
clrchyiuan(int x,int y)
{
  if (!dumb_term)
  {
    register screenline *slp;
    register int i, j;

    for (i = x, j = i + roll; i < y; i++, j++)
    {
      if (j >= scr_lns)
        j -= scr_lns;
      slp = &big_picture[j];
      slp->mode = slp->len = 0;
      if (slp->oldlen)
        slp->oldlen = 255;
    }
  }
}

void
outch(c)
  register uschar c;
{
  register screenline *slp;
  register int i;

#ifndef BIT8
  c &= 0x7f;
#endif

  if (dumb_term)
  {
#ifdef BIT8
    if ((c != '') && !isprint2(c))
#else
    if (!isprint(c))
#endif
    {
      if (c == '\n')
        ochar('\r');
      else
        c = '*';
    }
    ochar(c);
    return;
  }

  if ((i = cur_ln + roll) >= scr_lns)
    i -= scr_lns;
  slp = &big_picture[i];

#ifdef BIT8
  if ((c != '') && !isprint2(c))
#else
  if (!isprint(c))
#endif

  {
    if (c == '\n' || c == '\r')
    {
      if (standing)
      {
        slp->eso = MAX(slp->eso, cur_col);
        standing = NA;
      }

#if 1
      if ((i = cur_col - slp->len) > 0)
        memset(&slp->data[slp->len], ' ', i + 1);
#else
      if (cur_col > slp->len)
      {
        for (i = slp->len; i <= cur_col; i++)
          slp->data[i] = ' ';
      }
#endif

      slp->len = cur_col;
      cur_col = 0;
      if (cur_ln < scr_lns)
        cur_ln++;
      return;
    }
    c = '*';                    /* substitute a '*' for non-printable */
  }

  if (cur_col >= slp->len)
  {
    for (i = slp->len; i < cur_col; i++)
      slp->data[i] = ' ';
    slp->data[cur_col] = '\0';
    slp->len = cur_col + 1;
  }

  if (slp->data[cur_col] != c)
  {
    slp->data[cur_col] = c;
    if ((slp->mode & MODIFIED) != MODIFIED)
      slp->smod = slp->emod = cur_col;
    slp->mode |= MODIFIED;
    if (cur_col > slp->emod)
      slp->emod = cur_col;
    if (cur_col < slp->smod)
      slp->smod = cur_col;
  }

  if (++cur_col >= scr_cols)
  {
    if (standing && (slp->mode & STANDOUT))
    {
      standing = 0;
      slp->eso = MAX(slp->eso, cur_col);
    }
    cur_col = 0;
    if (cur_ln < scr_lns)
      cur_ln++;
  }
}


static void
parsecolor(buf)
  char *buf;
{
 char *val;
  char data[24];

  data[0] = '\0';
  val = (char *) strtok(buf, ";");

  while (val)
  {
    if (atoi(val) < 30)
    {
      if (data[0])
        strcat(data, ";");
      strcat(data, val);
    }
    val = (char *) strtok(NULL, ";");
  }
  strcpy(buf, data);
}


#define NORMAL (00)
#define ESCAPE (01)
#define VTKEYS (02)


void
outc(ch)
  register unsigned char ch;
{
  if (showansi)
    outch(ch);
  else
  {
    static char buf[24];
    static int p = 0;
    static int mode = NORMAL;
    int i;

    switch (mode)
    {
    case NORMAL:
      if (ch == '\033')
        mode = ESCAPE;
      else
        outch(ch);
      return;

    case ESCAPE:
      if (ch == '[')
        mode = VTKEYS;
      else
      {
        mode = NORMAL;
        outch('');
        outch(ch);
      }
      return;

    case VTKEYS:
      if (ch == 'm')
      {
        buf[p++] = '\0';
        parsecolor(buf);
      }
      else if ((p < 24) && (not_alpha(ch)))
      {
        buf[p++] = ch;
        return;
      }

      if (buf[0])
      {
        outch('');
        outch('[');

        for (i = 0; p = buf[i]; i++)
          outch(p);
        outch(ch);
      }
      p = 0;
      mode = NORMAL;
    }
  }
}
void
outs(str)
  register char *str;
{
  while (*str)
    outc(*str++);
}


void
outmsg(msg)
  register char *msg;
{
  move(b_lines, 0);
  clrtoeol();
  while (*msg)
    outc(*msg++);
}


void
prints(va_alist)
va_dcl
{
  va_list args;
  char buff[512], *fmt;

  va_start(args);
  fmt = va_arg(args, char *);
  vsprintf(buff, fmt, args);
  va_end(args);
  outs(buff);
}
void
scroll()
{
  if (dumb_term)
  {
    outc('\n');
  }
  else
  {
    scrollcnt++;
    if (++roll >= scr_lns)
      roll = 0;
    move(b_lines, 0);
    clrtoeol();
  }
}


void
rscroll()
{
  if (dumb_term)
  {
    outs("\n\n");
  }
  else
  {
    scrollcnt--;
    if (--roll < 0)
      roll = b_lines;
    move(0, 0);
    clrtoeol();
  }
}

region_scroll_up(int top, int bottom)
{
   int i;

   if (top > bottom) {
      i = top;
      top = bottom;
      bottom = i;
   }

   if (top < 0 || bottom >= scr_lns)
     return;

   for (i = top; i < bottom; i++)
      big_picture[i] = big_picture[i + 1];
   memset(big_picture + i, 0, sizeof(*big_picture));
   memset(big_picture[i].data, ' ', scr_cols);
   save_cursor();
   change_scroll_range(top, bottom);
   do_move(0, bottom);
   scroll_forward();
   change_scroll_range(0, scr_lns - 1);
   restore_cursor();
   refresh();
}
void
standout()
{
  if (!standing && !dumb_term && strtstandoutlen)
  {
    register screenline *slp;

    slp = &big_picture[((cur_ln + roll) % scr_lns)];
    standing = YEA;
    slp->sso = slp->eso = cur_col;
    slp->mode |= STANDOUT;
  }
}


void
standend()
{
  if (standing && !dumb_term && strtstandoutlen)
  {
    register screenline *slp;

    slp = &big_picture[((cur_ln + roll) % scr_lns)];
    standing = NA;
    slp->eso = MAX(slp->eso, cur_col);
  }
}

#define VS_STACK_SIZE 5
int vs_stack_ptr = -1;          /* CityLion */
int mode0[VS_STACK_SIZE],stat0[VS_STACK_SIZE];
int old_roll[VS_STACK_SIZE];
int my_newfd[VS_STACK_SIZE],x[VS_STACK_SIZE],y[VS_STACK_SIZE];
void vs_save(screen)
  screenline* screen;
{
  vs_stack_ptr++;
  old_roll[vs_stack_ptr] = roll;
  mode0[vs_stack_ptr] = currutmp->mode;
  stat0[vs_stack_ptr] = currstat;
  getyx(&y[vs_stack_ptr],&x[vs_stack_ptr]);
  memcpy(screen, big_picture, t_lines * sizeof(screenline));
  my_newfd[vs_stack_ptr] = i_newfd;
  i_newfd = 0;
  save_cursor();
}
void vs_restore(screen)
  screenline* screen;
{
  roll = old_roll[vs_stack_ptr];
  i_newfd = my_newfd[vs_stack_ptr];
  currstat = stat0[vs_stack_ptr];
  currutmp->mode = mode0[vs_stack_ptr];
  memcpy(big_picture, screen, t_lines * sizeof(screenline));
  move(y[vs_stack_ptr],x[vs_stack_ptr]);
  vs_stack_ptr--;
  free(screen);
  redoscr();
  refresh();
  restore_cursor();
}




/* �ŧi���� */

passwd_outs(text)
  char *text;
{
  register int column = 0;
  register char ch;
  while ((ch = *text++) && (++column < 80))
  {
    outch('-');
  }
}


/* ----------------------------------------------------- */
/* �w����ܰʺA�ݪO                                      */
/* ----------------------------------------------------- */


#define STAY_TIMEOUT    (30*60)
extern void movie();

static void
hit_alarm_clock()
{
  static int stay_time = 0;
  static int idle_time = 0;

  if (currutmp->pid != currpid)
    setup_utmp(XMODE);          /* ���s�t�m shm */

  if (i_mode == INPUT_IDLE)
  {
    idle_time += MOVIE_INT;
    if (!(PERM_HIDE(currutmp) || currutmp->mode == MAILALL)
        && (idle_time > cuser.idletime))
    {
      clear();

      dup2(fileno(stderr), 0);
      dup2(fileno(stderr), 1);
      dup2(fileno(stderr), 2);
      fprintf(stderr, "�W�L���m�ɶ��I\n");

      abort_bbs();
    }
  }
  else
  {
    currutmp->uptime = time(NULL);
    idle_time = 0;
    i_mode = INPUT_IDLE;
  }

  if (HAS_HABIT(HABIT_MOVIE) && (currstat && (currstat < CLASS  || currstat == MAILALL)))
    movie();

  alarm(MOVIE_INT);

  stay_time += MOVIE_INT;
  if (chkmail(0) && stay_time > 10 * 60 || stay_time > STAY_TIMEOUT)
  {
    /* �b�o�̴��� user �𮧤@�U */
    char *msg[7] = {"�����y, �|�|��, �ܤf��....",
                    "�z�w�g���F�b�Ӥp���o! �_�Ӭ��ʤ@�U�a!",
                    "���S���H���L�A�ܦ��y�O?",
                    "�A���U�h�n�o���H�F��~~~",
                    "���S�����n���Ʊ��ѤF�B�z�O?",
                    "�ΡE�\\�E��E��",
                    "��! ����!!!"};
/*
woju
*/
    time_t now = time(0);

    int i = rand() % 7;
    sprintf(currmsg, "[1;33;41m[%s] %s[m", Cdate(&now),
      chkmail(0) ? "�H�c���٦��S�ݹL���H�@!" : msg[i]);
    kill(currpid, SIGUSR2);
    stay_time = 0;
  }

  if (idle_time > cuser.idletime - 60)
  {
    sprintf(currmsg, "[1;5;37;41mĵ�i�G�z�w���m�L�[�A"
                       "�Y�L�^���A�t�ΧY�N�����I�I[m");
    kill(currpid, SIGUSR2);
  }
}


void
init_alarm()
{
  if(HAS_HABIT(HABIT_ALARM))
  {
    alarm(0);
    signal(SIGALRM, hit_alarm_clock);
    alarm(MOVIE_INT);
  }
}


/* ----------------------------------------------------- */
/* output routines                                       */
/* ----------------------------------------------------- */

void
ochar(c)
{
  if (obufsize > OBUFSIZE - 1)
  {
    write(1, outbuf, obufsize);
    obufsize = 0;
  }
  outbuf[obufsize++] = c;
}


/* ----------------------------------------------------- */
/* input routines                                        */
/* ----------------------------------------------------- */


int i_newfd = 0;
static struct timeval i_to, *i_top = NULL;
static int (*flushf) () = NULL;


void
add_io(fd, timeout)
  int fd;
  int timeout;
{
  i_newfd = fd;
  if (timeout)
  {
    i_to.tv_sec = timeout;
    i_to.tv_usec = 0;
    i_top = &i_to;
  }
  else
    i_top = NULL;
}


void
add_flush(flushfunc)
  int (*flushfunc) ();
{
  flushf = flushfunc;
}


int
num_in_buf()
{
  return icurrchar - ibufsize;
}


char watermode = -1;  /* Ptt ���y�^�U�Ϊ��Ѽ� */
extern  char no_oldmsg,oldmsg_count;

int
dogetch()
{
  int ch;

  if(currutmp) time(&currutmp->lastact);

  for (;;)
  {
    if (ibufsize == icurrchar)
    {
      fd_set readfds;
      struct timeval to;

      to.tv_sec = to.tv_usec = 0;
      FD_ZERO(&readfds);
      FD_SET(0, &readfds);
      if (i_newfd)
        FD_SET(i_newfd, &readfds);
      if ((ch = select(FD_SETSIZE, &readfds, NULL, NULL, &to)) <= 0)
      {
        if (flushf)
          (*flushf) ();

        if (dumb_term)
          oflush();
        else
          refresh();

        FD_ZERO(&readfds);
        FD_SET(0, &readfds);
        if (i_newfd)
          FD_SET(i_newfd, &readfds);

        while ((ch = select(FD_SETSIZE, &readfds, NULL, NULL, i_top)) < 0)
        {
          if (errno == EINTR)
            continue;
          else
          {
            perror("select");
            return -1;
          }
        }
        if (ch == 0)
          return I_TIMEOUT;
      }
      if (i_newfd && FD_ISSET(i_newfd, &readfds))
        return I_OTHERDATA;

      while ((ibufsize = read(0, inbuf, IBUFSIZE)) <= 0)
      {
        if (ibufsize == 0)
          longjmp(byebye, -1);
        if (ibufsize < 0 && errno != EINTR)
          longjmp(byebye, -1);
      }
      icurrchar = 0;
    }

    i_mode = INPUT_ACTIVE;
    ch = inbuf[icurrchar++];
    return (ch);

  }
}


int
igetch()
{
    register int ch;
    while(ch = dogetch())
    {
     switch (ch)
      {
       case Ctrl('L'):
         redoscr();
         continue;
       case Ctrl('I'):
         if(currutmp != NULL && currutmp->mode == MMENU)
         {
           screenline* screen = (screenline *)calloc(t_lines, sizeof(screenline));
           vs_save(screen);
           t_idle();
           vs_restore(screen);
           continue;
         }
         else return(ch);
       case Ctrl('Q'):  // wildcat : �ֳt���� :p
         if(currutmp->mode)
         {
           if(answer("�T�w�n����?? (y/N)") != 'y')
             return(ch);
           update_data();
           u_exit("ABORT");
           pressanykey("���¥��{, �O�o�`�ӳ� !");
           exit(0);
         }
         else return (ch);
       case Ctrl('U'):
         if(currutmp != NULL &&  currutmp->mode != EDITING
           && currutmp->mode != LUSERS && currutmp->mode)
         {
           screenline* screen = (screenline *)calloc(t_lines, sizeof(screenline));
           vs_save(screen);
           t_users();
           vs_restore(screen);
           continue;
         }
         else return (ch);

        case Ctrl('R'):
          if(currutmp == NULL) return (ch);
          else if(watermode > 0)
          {
            watermode = (watermode + oldmsg_count)% oldmsg_count + 1;
            t_display_new();
            continue;
          }
          else if (!currutmp->mode && (currutmp->chatid[0] == 2 ||
               currutmp->chatid[0] == 3) && oldmsg_count && !watermode)
          {
            watermode=1;
            t_display_new();
            continue;
          }
          else if (currutmp->msgs[0].last_pid)
          {
            screenline* screen = (screenline *)calloc(t_lines, sizeof(screenline));
            vs_save(screen);
            show_last_call_in();
            watermode = 0;
            my_write(currutmp->msgs[0].last_pid, "���y��^�h�G");
            vs_restore(screen);
            continue;
          }
          else return (ch);

        case '\n':   /* Ptt�� \n���� */
           continue;
        case Ctrl('T'):
          if(watermode > 0 )
          {
            watermode = (watermode + oldmsg_count - 2 )% oldmsg_count + 1;
            t_display_new();
            continue;
          }

        default:
          return (ch);
       }
    }
}

getdata(line, col, prompt, buf, len, echo, ans)
  int line, col;
  char *prompt, *buf, *ans;
  int len, echo;
{
  register int ch;
  int clen;
  int x, y;
  extern unsigned char scr_cols;
#define MAXLASTCMD 6
  static char lastcmd[MAXLASTCMD][80];


  if (prompt)
  {
    move(line, col);
    clrtoeol();
    outs(prompt);
  }
  else
    clrtoeol();

  if (dumb_term || !echo || echo == PASS || echo == 9)
  {
    len--;
    clen = 0;
    while ((ch = igetch()) != '\r')
    {
      if (ch == '\n')
        break;
      if (ch == '\177' || ch == Ctrl('H'))
      {
        if (!clen)
        {
          bell();
          continue;
        }
        clen--;
        if (echo)
        {
          ochar(Ctrl('H'));
          ochar(' ');
          ochar(Ctrl('H'));
        }
        continue;
      }

#ifdef BIT8
      if (!isprint2(ch))
#else
      if (!isprint(ch))
#endif

      {
        if (echo)
          bell();
        continue;
      }
      if (clen >= len)
      {
        if (echo)
          bell();
        continue;
      }
      buf[clen++] = ch;
      if (echo && echo != 9)
        ochar(echo == PASS ? '-' : ch);
    }
    buf[clen] = '\0';
    outc('\n');
    oflush();
  }
  else
  {
   int cmdpos = MAXLASTCMD -1;
   int currchar = 0;
   int keydown;
   int dirty;

    getyx(&y, &x);
    standout();
    for (clen = len--; clen; clen--)
      outc(' ');
    standend();

    if (ans) {
       int i;

       strncpy(buf, ans, len);
       buf[len] = 0;
       for (i = strlen(buf) + 1; i < len; i++)
          buf[i] = 0;
       move(y, x);
       edit_outs(buf);
       clen = currchar = strlen(buf);

    }
    else
       memset(buf, 0, len);

    dirty = 0;
    while (move(y, x + currchar), (ch = igetkey()) != '\r')
    {
/*
woju
*/
       keydown = 0;
       switch (ch) {
       case Ctrl('Y'): {
          int i;

          if (clen && dirty) {
             for (i = MAXLASTCMD - 1; i; i--)
                strcpy(lastcmd[i], lastcmd[i - 1]);
             strncpy(lastcmd[0], buf, len);
          }

          move(y, x);
          for (clen = len--; clen; clen--)
            outc(' ');
          memset(buf, '\0', strlen(buf));
          clen = currchar = strlen(buf);
          continue;
          }

       case KEY_DOWN:
       case Ctrl('N'):
          keydown = 1;
       case Ctrl('P'):
       case KEY_UP: {
          int i;

          if (clen && dirty) {
             for (i = MAXLASTCMD - 1; i; i--)
                strcpy(lastcmd[i], lastcmd[i - 1]);
             strncpy(lastcmd[0], buf, len);
          }

          i = cmdpos;
          do {
             if (keydown)
                --cmdpos;
             else
                ++cmdpos;
             if (cmdpos < 0)
                cmdpos = MAXLASTCMD - 1;
             else if (cmdpos == MAXLASTCMD)
                cmdpos = 0;
          } while (cmdpos != i && (!*lastcmd[cmdpos]
                   || !strncmp(buf, lastcmd[cmdpos], len)));
          if (cmdpos == i)
             continue;

          strncpy(buf, lastcmd[cmdpos], len);
          buf[len] = 0;

          move(y, x);                   /* clrtoeof */
          for (i = 0; i <= clen; i++)
             outc(' ');
          move(y, x);

          if (echo == PASS)
            passwd_outs(buf);
          else
            edit_outs(buf);
          clen = currchar = strlen(buf);
          dirty = 0;
          continue;
       }
         case KEY_ESC:
           if (KEY_ESC_arg == 'c')
              capture_screen();
           if (KEY_ESC_arg == 'n')
              edit_note();
           if (ch == 'U' && currstat != IDLE  &&
               !(currutmp->mode == 0 &&
                 (currutmp->chatid[0] == 2 || currutmp->chatid[0] == 3)))
              t_users();
           continue;

       case KEY_LEFT:
          if (currchar)
             --currchar;
          continue;
       case KEY_RIGHT:
          if (buf[currchar])
             ++currchar;
          continue;
       }

      if (ch == '\n' || ch == '\r')
         break;

      if (ch == Ctrl('I') && currstat != IDLE &&
          !(currutmp->mode == 0 &&
            (currutmp->chatid[0] == 2 || currutmp->chatid[0] == 3))) {
         t_idle();
         continue;
      }
      if (ch == '\177' || ch == Ctrl('H'))
      {
        if (currchar) {
           int i;

           currchar--;
           clen--;
           for (i = currchar; i <= clen; i++)
              buf[i] = buf[i + 1];
           move(y, x + clen);
           outc(' ');
           move(y, x);
           edit_outs(buf);
           dirty = 1;
        }
        continue;
      }
      if (ch == Ctrl('D')) {
        if (buf[currchar]) {
           int i;

           clen--;
           for (i = currchar; i <= clen; i++)
              buf[i] = buf[i + 1];
           move(y, x + clen);
           outc(' ');
           move(y, x);
           if (echo == PASS)
             passwd_outs(buf);
           else
             edit_outs(buf);
           dirty = 1;
        }
        continue;
      }
      if (ch == Ctrl('K')) {
         int i;

         buf[currchar] = 0;
         move(y, x + currchar);
         for (i = currchar; i < clen; i++)
            outc(' ');
         clen = currchar;
         dirty = 1;
         continue;
      }
      if (ch == Ctrl('A')) {
         currchar = 0;
         continue;
      }
      if (ch == Ctrl('E')) {
         currchar = clen;
         continue;
      }


      if (!(isprint2(ch)))
      {
        continue;
      }
      if (clen >= len || x + clen >= scr_cols)
      {
        continue;
      }
/*
woju
*/
      if (buf[currchar]) {               /* insert */
         int i;

         for (i = currchar; buf[i] && i < len && i < 80; i++)
            ;
         buf[i + 1] = 0;
         for (; i > currchar; i--)
            buf[i] = buf[i - 1];
      }
      else                              /* append */
         buf[currchar + 1] = '\0';

      buf[currchar] = ch;
      move(y, x + currchar);
      edit_outs(buf + currchar);
      currchar++;
      clen++;
      dirty = 1;
    }
    buf[clen] = '\0';
    if (clen > 1) {
       for (cmdpos = MAXLASTCMD - 1; cmdpos; cmdpos--)
          strcpy(lastcmd[cmdpos], lastcmd[cmdpos - 1]);
       strncpy(lastcmd[0], buf, len);
    }
    if (echo) {
      move(y, x + clen);
      outc('\n');
    }
    refresh();
  }
  if ((echo == LCECHO) && ((ch = buf[0]) >= 'A') && (ch <= 'Z'))
    buf[0] = ch | 32;
  return clen;
}


char
getans(prompt)
  char *prompt;
{
  char ans[5];

  getdata(b_lines-1,0,prompt,ans,4,LCECHO,0);

  return ans[0];
}

/*
woju
*/
#define TRAP_ESC

#ifdef  TRAP_ESC
int KEY_ESC_arg;

int
igetkey()
{
  int mode;
  int ch, last;

  mode = last = 0;
  while (1)
  {
    ch = igetch();
    if (mode == 0)
    {
      if (ch == KEY_ESC)
        mode = 1;
      else
        return ch;              /* Normal Key */
    }
    else if (mode == 1)
    {                           /* Escape sequence */
      if (ch == '[' || ch == 'O')
        mode = 2;
      else if (ch == '1' || ch == '4')
        mode = 3;
      else
      {
        KEY_ESC_arg = ch;
        return KEY_ESC;
      }
    }
    else if (mode == 2)
    {                           /* Cursor key */
      if (ch >= 'A' && ch <= 'D')
        return KEY_UP + (ch - 'A');
      else if (ch >= '1' && ch <= '6')
        mode = 3;
      else
        return ch;
    }
    else if (mode == 3)
    {                           /* Ins Del Home End PgUp PgDn */
      if (ch == '~')
        return KEY_HOME + (last - '1');
      else
        return ch;
    }
    last = ch;
  }
}

#else                           /* TRAP_ESC */

int
igetkey(void)
{
  int mode;
  int ch, last;

  mode = last = 0;
  while (1)
  {
    ch = igetch();
    if (ch == KEY_ESC)
      mode = 1;
    else if (mode == 0)         /* Normal Key */
      return ch;
    else if (mode == 1)
    {                           /* Escape sequence */
      if (ch == '[' || ch == 'O')
        mode = 2;
      else if (ch == '1' || ch == '4')
        mode = 3;
      else
        return ch;
    }
    else if (mode == 2)
    {                           /* Cursor key */
      if (ch >= 'A' && ch <= 'D')
        return KEY_UP + (ch - 'A');
      else if (ch >= '1' && ch <= '6')
        mode = 3;
      else
        return ch;
    }
    else if (mode == 3)
    {                           /* Ins Del Home End PgUp PgDn */
      if (ch == '~')
        return KEY_HOME + (last - '1');
      else
        return ch;
    }
    last = ch;
  }
}
#endif                          /* TRAP_ESC */

FCACHE *fshm;

extern int lenth[10];

static inline void
out_rle(str,flag)
  uschar *str;
  int flag;
{
  int x,y,count=0;
  int cc, rl;

  if(flag)
   move(13, lenth[count++]);

  while (cc = *str)
  {
    str++;
    switch (cc)
    {
    case 8:     /* Thor.980804: ���Ѥ@�U, opus���Y�L�F */
      rl = *str++;
      cc = *str++;

      while (--rl >= 0)
      {
        if(cc=='\n' && flag)
        {
          getyx(&y,&x);
          outs("\033[m\0");
          clrtoeol();
          move(y + 1, lenth[count++]);
        }
        else
         outc(cc);
      }
      continue;
    }
    if(cc=='\n' && flag)
    {
      getyx(&y,&x);
      outs("\033[m\0");
      clrtoeol();
      move(y + 1, lenth[count++]);
    }
    else
     outc(cc);
  }
}


int
film_out(tag, row)
  int tag;
  int row;                      /* -1 : help */
{
  int fmax, len, *shot;
  char *film, buf[FILM_SIZ];

  if (row <= 0)
    clear();
  else
    move(row, 0);

  len = 0;
  shot = fshm->shot;
  film = fshm->film;

  while (!(fmax = *shot))       /* util/camera.c ���b���� */
  {
    sleep(5);
    if (++len > MOVIE_LINES)
      return FILM_MOVIE;
  }

  if (tag >= FILM_MOVIE)        /* random select */
  {
    if (tag >= fmax)
      tag = FILM_MOVIE + (time(0) % fshm->shot[0]);
    else {
      tag += (time(0) % fshm->shot[0]);
      if (tag >= fmax)
        tag = FILM_MOVIE + (time(0) % fshm->shot[0]);
    }
  } //FILM_MOVIE = 20;
   /* Thor.980804: �i��O�G�N���a? �Ĥ@�i random select�e10�Ө䤤�@�� */

  if (tag)
  {
    len = shot[tag];
    film += len;
    len = shot[++tag] - len;
  }
  else
    len = shot[1];


  if (len >= FILM_SIZ - MOVIE_LINES)
    return tag;

  memcpy(buf, film, len);
  buf[len] = '\0';

  if(tag > 12 && tag < 23)
   out_rle(buf,1);
  else
   out_rle(buf,0);

  if (row < 0)                  /* help screen */
    pressanykey(NULL);

  return tag;
}


/*-------------------------------------------------------*/
/* term.c       ( NTHU CS MapleBBS Ver 2.36 )            */
/*-------------------------------------------------------*/
/* target : termcap I/O control routines                 */
/* create : 95/03/29                                     */
/* update : 95/12/15                                     */
/*-------------------------------------------------------*/


/* ----------------------------------------------------- */
/* basic tty control                                     */
/* ----------------------------------------------------- */


void
init_tty()
{
  if (gtty(1, &tty_state) < 0)
  {
    fprintf(stderr, "gtty failed\n");
    exit(-1);
  }
  memcpy(&tty_new, &tty_state, sizeof(tty_new));

#ifdef  LINUX
#if (__GLIBC__ != 2)
  tty_new.c_lflag &= ~(ICANON | ECHO | RAW | ISIG);
#else
  tty_new.c_lflag &= ~(ICANON | ECHO | ISIG);
#endif
  tcsetattr(1, TCSANOW, &tty_new);
  restore_tty();

#else

  tty_new.sg_flags |= RAW;

  tty_new.sg_flags &= ~(TANDEM | CBREAK | LCASE | ECHO | CRMOD);

  stty(1, &tty_new);
#endif
}


#ifdef LINUX
reset_tty()
{
   system("stty -raw echo");
}
restore_tty()
{
   system("stty raw -echo");
}
#else

void
reset_tty()
{
  stty(1, &tty_state);
}
void
restore_tty()
{
  stty(1, &tty_new);
}

#endif

/* ----------------------------------------------------- */
/* init tty control code                                 */
/* ----------------------------------------------------- */

static
outcf(ch)
  char ch;
{
  if (*outlp < TERMCOMSIZE)
  {
    (*outlp)++;
    *outp++ = ch;
  }
}


int
term_init(term)
  char *term;
{
  extern char PC, *UP, *BC;
#ifndef LINUX
  extern short ospeed;
#endif
  static char UPbuf[TERMCOMSIZE];
  static char BCbuf[TERMCOMSIZE];
  static char buf[1024];
  char sbuf[2048];
  char *sbp, *s;
  char *tgetstr();

#ifdef LINUX
  ospeed = cfgetospeed(&tty_state);
#else
  ospeed = tty_state.sg_ospeed;
#endif

  if (tgetent(buf, term) != 1)
    return NA;

  sbp = sbuf;
  s = tgetstr("pc", &sbp);      /* get pad character */
  if (s)
    PC = *s;

  t_lines = tgetnum("li");
  t_columns = tgetnum("co");
  automargins = tgetflag("am");

  outp = clearbuf;              /* fill clearbuf with clear screen command */
  outlp = &clearbuflen;
  clearbuflen = 0;
  sbp = sbuf;
  s = tgetstr("cl", &sbp);
  if (s)
    tputs(s, t_lines, outcf);

  outp = cleolbuf;              /* fill cleolbuf with clear to eol command */
  outlp = &cleolbuflen;
  cleolbuflen = 0;
  sbp = sbuf;
  s = tgetstr("ce", &sbp);
  if (s)
    tputs(s, 1, outcf);

  outp = scrollrev;
  outlp = &scrollrevlen;
  scrollrevlen = 0;
  sbp = sbuf;
  s = tgetstr("sr", &sbp);
  if (s)
    tputs(s, 1, outcf);

  outp = strtstandout;
  outlp = &strtstandoutlen;
  strtstandoutlen = 0;
  sbp = sbuf;
  s = tgetstr("so", &sbp);
  if (s)
    tputs(s, 1, outcf);

  outp = endstandout;
  outlp = &endstandoutlen;
  endstandoutlen = 0;
  sbp = sbuf;
  s = tgetstr("se", &sbp);
  if (s)
    tputs(s, 1, outcf);

  sbp = cursorm;
  cm = tgetstr("cm", &sbp);
  if (cm)
    dumb_term = NA;
  else
  {
    dumb_term = YEA;
    t_lines = 24;
    t_columns = 80;
  }

  sbp = changescroll;
  cs = tgetstr("cs", &sbp);

  sbp = scrollforward;
  sf = tgetstr("sf", &sbp);

  sbp = scrollreverse;
  sr = tgetstr("sr", &sbp);

  sbp = savecursor;
  sc = tgetstr("sc", &sbp);

  sbp = restorecursor;
  rc = tgetstr("rc", &sbp);

  sbp = UPbuf;
  UP = tgetstr("up", &sbp);
  sbp = BCbuf;
  BC = tgetstr("bc", &sbp);

  b_lines = t_lines - 1;
  p_lines = t_lines - 4;
  return YEA;
}

do_move(destcol, destline)
  int destcol, destline;
{
  tputs(tgoto(cm, destcol, destline), 0, ochar);
}

save_cursor()
{
  tputs(sc, 0, ochar);
}

restore_cursor()
{
  tputs(rc, 0, ochar);
}

/*
woju
*/
change_scroll_range(int top, int bottom)
{
  tputs(tparm(cs, top, bottom), 0, ochar);
}

scroll_forward()
{
  tputs(sf, 0, ochar);
}

scroll_reverse()
{
  tputs(sr, 0, ochar);
}


void
draw(int in, int col, int row)
{
  int i;
  for (i = 0; i < 16; i++, in >>= 1) {
    if (!(i % 3))
      move(col + i / 3, row);
    in & 0x0001 ? outs("�i") : outs("  ");
  }
}

