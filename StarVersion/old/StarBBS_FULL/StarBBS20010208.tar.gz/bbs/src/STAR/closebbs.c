#include <bbs.h>
main()
{
 FILE *fp;
 char a[80];
 fp=fopen("/home/bbs/etc/watchout","r");
 while((fgets(a,80,fp)!='\0'))
   {
    fputs(a,stdout);
   }
 fclose(fp);
 getchar();
}

