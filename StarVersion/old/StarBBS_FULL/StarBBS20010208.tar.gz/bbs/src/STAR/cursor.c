
#define STR_UNCUR       "  "

void
cursor_show(row, column)
  int row, column;
{
  int i=rand()%4*2;

  move(row, column);
/*  outs(STR_CURSOR);*/
  prints("%c%c","�P�e�]��"[i],"�P�e�]��"[i+1]);
  move(row, column + 1);
}

void
cursor_clear(row, column)
  int row, column;
{
  move(row, column);
  outs(STR_UNCUR);
}


int
cursor_key(row, column)
  int row, column;
{
  int ch;

  cursor_show(row, column);
  ch = egetch();
  move(row, column);
  outs(STR_UNCUR);
  return ch;
}


void
GOTOXY(x,y)
int x,y;
{
  char buf[10];
  refresh();
  sprintf(buf,"\x1b[%d;%df",x,y);
  output(buf,strlen(buf));
}


void
cursor_bar_clear(row, column,offset,str,color)
int row,column,offset;
char *str,*color;
{
  char buf[80];
  move(row,column);
  GOTOXY(row+1,column+offset);
  if(color)
   sprintf(buf,"\x1b[40m%s%s\x1b[m",color,str);
  else
   sprintf(buf,"\x1b[40;37m%s\x1b[m",str);
  output(buf, strlen(buf));
  GOTOXY(row+1,column);
}

void
cursor_bar_show(row, column,offset,str,color)
int row,column,offset,color;
char *str;
{
  char buf[80];
  move(row,column);
  GOTOXY(row+1,column+offset);
  sprintf(buf,"\x1b[4%dm%s\x1b[m",color,str);
  output(buf, strlen(buf));
  GOTOXY(row+1,column+1);
}

int
cursor_bar_key(row,column,str,color)
int row, column;
char *str, *color;
{
  int ch;
  cursor_bar_show(row,0,column,str, 4);
  move(row,0);
  ch = egetch();
  if(color)
   cursor_bar_clear(row,0,column,str,color);
  else
   cursor_bar_clear(row,0,column,str,0);
  return ch;
}
