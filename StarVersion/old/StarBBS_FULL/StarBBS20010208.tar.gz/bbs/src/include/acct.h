// skybinary 20000428 : ACCT

/* ----------------------------------------------------- */
/* .ACCT struct : 256 bytes                              */
/* ----------------------------------------------------- */

typedef struct {
  char realname[20];              /* �u��m�W    20 bytes */
  char email[50];                 /* E-MAIL      50 bytes */
  char address[50];               /* �a�}        50 bytes */
  char justify[REGLEN + 1];       /* ���U���    39 bytes */
  char feeling[4];                /* �߱����A     4 bytes */
  usint color;                    /* �ӤH�C��     4 bytes */
  char pad[89];                   /* �ŵ۶񺡦� 256 �� */
} ACCT;



