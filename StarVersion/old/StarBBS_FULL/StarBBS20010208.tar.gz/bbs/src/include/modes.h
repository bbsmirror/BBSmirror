/*-------------------------------------------------------*/
/* modes.h      ( NTHU CS MapleBBS Ver 2.36 )            */
/*-------------------------------------------------------*/
/* target : user operating mode & status                 */
/* create : 95/03/29                                     */
/* update : 95/12/15                                     */
/*-------------------------------------------------------*/


#ifndef _MODES_H_
#define _MODES_H_

/* ----------------------------------------------------- */
/* strip ansi mode   Ptt                                 */
/* ----------------------------------------------------- */

enum
{STRIP_ALL, ONLY_COLOR, NO_RELOAD};

/* ----------------------------------------------------- */
/* �s�զW��Ҧ�   Ptt                                    */
/* ----------------------------------------------------- */

#define FRIEND_OVERRIDE 0
#define FRIEND_REJECT   1
#define FRIEND_ALOHA    2
#define FRIEND_POST     3         
#define FRIEND_SPECIAL  4
#define FRIEND_CANVOTE  5
#define BOARD_WATER     6
#define BOARD_VISABLE   7 
#define FRIEND_MAILLIST	8
#define FRIEND_MAILREPLYLIST	9



/* ----------------------------------------------------- */
/* user �ާ@���A�P�Ҧ�                                   */
/* ----------------------------------------------------- */

#define IDLE            0
#define MMENU           1       /* menu mode */
#define ADMIN           2
#define MAIL            3
#define TMENU           4
#define UMENU           5
#define XMENU           6
#define CLASS           7
#define PMENU           8
#define NMENU           9
#define BUILDING        10
#define POSTING         11      /* boards & class */
#define READBRD         12
#define READING         13
#define READNEW         14
#define SELECT          15
#define RMAIL           16      /* mail menu */
#define SMAIL           17
#define CHATING         18      /* talk menu */
#define XMODE           19
#define FRIEND          20
#define LAUSERS         21
#define LUSERS          22
#define MONITOR         23
#define PAGE            24
#define QUERY           25
#define TALK            26
#define EDITPLAN        27      /* user menu */
#define EDITSIG         28
#define VOTING          29
#define XINFO           30
#define MSYSOP          31
#define LOG		32
#define BIG2            33
#define REPLY           34
#define HIT             35
#define DBACK           36
#define NOTE            37
#define EDITING         38
#define MAILALL         39
/*Ptt*/
#define MJ              40
#define LOGIN           41       /* main menu */
#define DICT            42
#define BRIDGE          43
#define ARCHIE          44
#define GOPHER          45
#define NEWS            46
#define LOVE            47
#define EDITEXP         48
#define CAL             49
#define PROVERB         50
#define ANNOUNCE        51       /* announce */
#define EDNOTE          52 
#define GAME            53
#define MARIE           54
#define CHICKEN         55
#define XBOARDS         56
#define TICKET		57
#define B_MENU          58
#define RACE            59
#define BINGO           60
#define XAXB		61
#define TETRIS		62
#define CDICT		63
#define XSYSTEM		64
#define XUSER		65
#define BANK		66
#define BLACKJACK	67
#define OSONG           68

/* RPG ��� */

#define RMENU		69
#define RGUILD 		70
#define RTRAIN		71
#define RINFO		72
#define RPK		73
#define RHELP		74
/*
#define RCHANGE		75
#define RINTRO		76
#define EDITPIC		77
#define RSHOP		78
*/
#define XRPG            75
#define RPG_GUILD       76
#define RPG_TRAIN       77
#define RPG_COUNT       78


#define DICE		79
#define RICH		80
#define STOCK		81
#define MINE            82
#define CHICKENPAGE	83
#define CHICKENTALK	84
#define GP		85
#define NINE		86
#define FIVE		87
#define DRAGON		88
#define FINANCE         89
#define ASTRO		90
#define PAIR		91
#define FREE		92
#define	NumFight	93
#define CATV		94
#define WORM		95
#define CHESS		96
#define WWW		97
#define MARIO		98
#define SEVENCARD	99
#define CHESSMJ		100
#define BET             101
#define FORTUNE         102
#define MARKET          103
#define DARKCHESS       104 //�t��
#define SECHAND         105
#define TENHALF         106
#define CARD_99         107
#define JACK_CARD       108
#define CHC             109
#define ARTICLE         110

/* ----------------------------------------------------- */
/* menu.c �����Ҧ�                                       */
/* ----------------------------------------------------- */


#define QUIT    0x666           /* Return value to abort recursive functions */
#define XEASY   0x333           /* Return value to un-redraw screen */


/* ----------------------------------------------------- */
/* read.c �����Ҧ�                                       */
/* ----------------------------------------------------- */



#define RS_FORWARD      0x01    /* backward */
#define RS_TITLE        0x02    /* author/title */
#define RS_RELATED      0x04
#define RS_FIRST        0x08    /* find first article */
#define RS_CURRENT      0x10    /* match current read article */
#define RS_THREAD       0x20    /* search the first article */
#define RS_AUTHOR       0x40    /* search author's article */

#define CURSOR_FIRST    (RS_RELATED | RS_TITLE | RS_FIRST)
#define CURSOR_NEXT     (RS_RELATED | RS_TITLE | RS_FORWARD)
#define CURSOR_PREV     (RS_RELATED | RS_TITLE)
#define RELATE_FIRST    (RS_RELATED | RS_TITLE | RS_FIRST | RS_CURRENT)
#define RELATE_NEXT     (RS_RELATED | RS_TITLE | RS_FORWARD | RS_CURRENT)
#define RELATE_PREV     (RS_RELATED | RS_TITLE | RS_CURRENT)
#define THREAD_NEXT     (RS_THREAD | RS_FORWARD)
#define THREAD_PREV     (RS_THREAD)
#define AUTHOR_NEXT     (RS_AUTHOR | RS_FORWARD)
#define AUTHOR_PREV     (RS_AUTHOR)

#define DONOTHING       0       /* Read menu command return states */
#define FULLUPDATE      1       /* Entire screen was destroyed in this oper */
#define PARTUPDATE      2       /* Only the top three lines were destroyed */
#define DOQUIT          3       /* Exit read menu was executed */
#define NEWDIRECT       4       /* Directory has changed, re-read files */
#define READ_NEXT       5       /* Direct read next file */
#define READ_PREV       6       /* Direct read prev file */
#define DIRCHANGED      8       /* Index file was changed */
#define READ_REDRAW     9
#define PART_REDRAW     10
/*
woju
*/
#define POS_NEXT        101     /* cursor_pos(locmem, locmem->crs_ln + 1, 1);*/


/* for currmode */

#define MODE_STARTED    1       /* �O�_�w�g�i�J�t�� */
#define MODE_POST       2       /* �O�_�i�H�b currboard �o���峹 */
#define MODE_BOARD      4       /* �O�_�i�H�b currboard �R���Bmark�峹 */
#define MODE_MENU       8       /* �O�_�i�H�b MENU      �}�O */
#define MODE_DIGEST     0x10    /* �O�_�� digest mode */
#define MODE_ETC        0x20    /* �O�_�� etc mode */
#define MODE_SELECT     0x40 
#define MODE_DIRTY      0x80    /* �O�_��ʹL userflag */
#define MODE_FAVORITE   0x200   /* �O�_�� myfavorite mode */


/* for curredit */

#define EDIT_MAIL       1       /* �ثe�O mail/board ? */
#define EDIT_LIST       2       /* �O�_�� mail list ? */
#define EDIT_BOTH       4       /* both reply to author/board ? */
#define EDIT_ITEM       8       /* ITEM ? */
#endif                          /* _MODES_H_ */
