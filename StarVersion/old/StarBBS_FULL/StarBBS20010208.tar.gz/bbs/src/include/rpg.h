#define FN_RPG	".RPGS"

#define	MAX_LEVEL  12 /*���n�W�L15*/
#define MAX_JOB	13 /*���n�W�L15*/
#define RPGNAME 10 /*¾�~���̪���*/


#define LEVEL_1         0
#define LEVEL_2       200
#define LEVEL_3       600
#define LEVEL_4      1400
#define LEVEL_5      3000
#define LEVEL_6      6200
#define LEVEL_7     12600
#define LEVEL_8     25400
#define LEVEL_9     51000
#define LEVEL_10   102200
#define LEVEL_11   204600
#define LEVEL_12   409400

                          
/*--------------------------------------------------------*/
/*.RPGS struct 					   	  */
/*--------------------------------------------------------*/

struct rpgrec
{
  char userid[IDLEN+1];
  int role;  /*�i��¾����,���Ȥ��}�� :P*/
  unsigned long int exp;
  unsigned long int used;    /*�w�g�ᱼ��exp*/
  uschar level;
  usint hp;
  usint mp;
  usint fp;
  usint dp;
  usint skill;   /*��mask����k,�ϱo����h�ޯ�*/
  usint max_hp;
  usint max_mp;
  ushort item;
  usint head,body,rhand,lhand,foot,ring,pearl;
  usint magic;
  ushort mode;
  ushort limit;
  usint dead,kill;
};
typedef struct rpgrec rpgrec;


/* po�峹�S�� */
//#define WATER_BOARD_NUM 5


/*--------------------------------------------------------*/
/* MAGIC struct                                           */
/*--------------------------------------------------------*/

struct magic
{
 char *name;   /* magic name */
 int demagic;  /* de-magic */
 int hpmode;   /* hp magic mode (0->increase,1->decrease)*/
 int hp;       /* value of hp change */
 int fpmode;   /* fp mode (0->increase,1->decrease) */
 int fp;       /* value of fp change */
};

/*--------------------------------------------------------*/
/* badman struct                                          */
/*--------------------------------------------------------*/


struct badman
{
 char name[10];
 int hp;
 int mp;
 int fp;
 int dp;
 int lv;
 unsigned long int money;
 unsigned long int exp;
};

