/*-------------------------------------------------------*/
/* struct.h     ( NTHU CS MapleBBS Ver 2.36 )            */
/*-------------------------------------------------------*/
/* target : all definitions about data structure         */
/* create : 95/03/29                                     */
/* update : 95/12/15                                     */
/*-------------------------------------------------------*/


#ifndef _STRUCT_H_
#define _STRUCT_H_


#define STRLEN   80             /* Length of most string data */
#define BRC_STRLEN 15           /* Length of boardname */
#define BTLEN    48             /* Length of board title */
#define TTLEN    72             /* Length of title */
#define NAMELEN  40             /* Length of username/realname */
#define FNLEN    33             /* Length of filename  */
				/* Ptt ���o�̦�bug*/
#define IDLEN    12             /* Length of bid/uid */
#define PASSLEN  14             /* Length of encrypted passwd field */
#define REGLEN   38             /* Length of registration data */

#define MAX_OBJ  9              /* for OBJ */

typedef unsigned char uschar;   /* length = 1 */
typedef unsigned int usint;     /* length = 4 */

/* ----------------------------------------------------- */
/* .PASSWDS struct : 256 bytes                           */
/* ----------------------------------------------------- */

struct userec
{
  char userid[IDLEN + 1];         /* �ϥΪ̦W��  13 bytes */
  char username[24];              /* �ʺ�        24 bytes */
  char passwd[PASSLEN];           /* �K�X        14 bytes */
  uschar uflag;                   /* �ϥΪ̿ﶵ   1 byte  */
  usint userlevel;                /* �ϥΪ��v��   4 bytes */
  ushort numlogins;               /* �W������     2 bytes */
  ushort numposts;                /* POST����     2 bytes */
  time_t firstlogin;              /* ���U�ɶ�     4 bytes */
  time_t lastlogin;               /* �e���W��     4 bytes */
  char lasthost[24];              /* �W���a�I    24 bytes */
  char vhost[24];                 /* �������}    24 bytes */
  uschar month;                   /* �X�ͤ��     1 byte  */
  uschar day;                     /* �X�ͤ��     1 byte  */
  uschar year;                    /* �X�ͦ~��     1 byte  */
  uschar sex;                     /* �ʧO         1 byte  */
  uschar state;                   /* ���A??       1 byte  */
  unsigned long int money;        /* ���W�{��     8 bytes */
  unsigned long int deposit;      /* �Ȧ�s��     8 bytes */
  usint obj;                      /* �©�������   4 bytes */
  usint habit;                    /* �ߦn�]�w     4 bytes */
  uschar pager;                   /* �߱��C��     1 bytes */
  uschar invisible;               /* �����Ҧ�     1 bytes */
  usint exmailbox;                /* �H�c�ʼ�     4 bytes */
  usint exmailboxk;               /* �H�cK��      4 bytes */
  char proverb;                   /* �b�I����     1 bytes */
  usint toquery;                  /* �n�_��       4 bytes */
  usint bequery;                  /* �H���       4 bytes */
  unsigned long int totaltime;    /* �W�u�`�ɼ�   8 bytes */
  usint sendmsg;                  /* �o�T������   4 bytes */
  usint receivemsg;               /* ���T������   4 bytes */
  time_t dtime;			  /* deposit time 4 bytes */
  char feeling[4];                /* �߱����A     4 bytes */
  int astro;                      /* �P�y         1 bytes */
  unsigned long int starmoney;    /* ���W�s��     8 bytes */
  usint family;                   /* �a�ڵ���     4 bytes */
  usint color;                    /* �ӤH�C��     4 bytes */
  usint idletime;                 /* idletime     4 bytes */
  unsigned long int exp;          /* RPG exp      8 bytes */
  int port;                       /* �Ψ쪺port   4 bytes */
  char pad[43];                   /* �ŵ۶񺡦� 256��     */
};

typedef struct userec userec;

/* these are flags in userec.uflag */
#define SIG_FLAG        0x3     /* signature number, 2 bits */
#define PAGER_FLAG      0x4     /* true if pager was OFF last session */
#define CLOAK_FLAG      0x8     /* true if cloak was ON last session */
#define FRIEND_FLAG     0x10    /* true if show friends only */
#define BRDSORT_FLAG    0x20    /* true if the boards sorted alphabetical */
#define MOVIE_FLAG      0x40    /* true if show movie */
#define COLOR_FLAG      0x80    /* true if the color mode open */


/* ----------------------------------------------------- */
/* DIR of board struct : 128 bytes                       */
/* ----------------------------------------------------- */

struct fileheader
{
  char filename[FNLEN];         /* M.9876543210.A */
  char savemode;                /* file save mode */
  char owner[IDLEN + 2];        /* uid[.] */
  char date[6];                 /* [02/02] or space(5) */
  char title[TTLEN + 1];
  uschar filemode;              /* must be last field @ boards.c */
};
typedef struct fileheader fileheader;

#define FILE_LOCAL      0x1     /* local saved */
#define FILE_READ       0x1     /* already read : mail only */
#define FILE_MARKED     0x2     /* opus: 0x8 */
#define FILE_DIGEST     0x4     /* digest */
#define FILE_TAGED      0x8     /* taged */
#define FILE_REPLYOK    0x10    /* replyok*/
#define FILE_REFUSE     0x20    /* refuse */
#define FILE_DIR        0x40    /* dir */

/* ----------------------------------------------------- */
/* Structure used in UTMP file : 128 bytes               */
/* ----------------------------------------------------- */

/* woju :  Message queue */
typedef struct {
   pid_t last_pid;
   char last_userid[IDLEN + 1];
   char last_call_in[80];
} msgque;

struct user_info
{
  int uid;                      /* Used to find user name in passwd file */
  pid_t pid;                    /* kill() to notify user of talk request */
  int sockaddr;                 /* ... */
  int destuid;                  /* talk uses this to identify who called */
  struct user_info* destuip;
  uschar active;                /* When allocated this field is true */
  uschar invisible;             /* Used by cloaking function in Xyz menu */
  uschar sockactive;            /* Used to coordinate talk requests */
  usint userlevel;
  uschar mode;                  /* UL/DL, Talk Mode, Chat Mode, ... */
  uschar pager;                 /* pager toggle, YEA, or NA */
  uschar in_chat;               /* for in_chat commands   */
  uschar sig;                   /* signal type */
  char userid[IDLEN + 1];
  char chatid[11];              /* chat id, if in chat mode */
  char username[24];
  char from[27];                /* machine name the user called in from */
  int from_alias;
  char birth;                   /* �O�_�O�ͤ� Ptt*/
  ushort friend[MAX_FRIEND];
  ushort reject[MAX_REJECT];
  uschar msgcount;
  msgque msgs[MAXMSGS];
  time_t uptime;
  time_t lastact;             /* �W���ϥΪ̰ʪ��ɶ� */
  usint brc_id;
  uschar lockmode;
  char feeling[4];              /* �߱� */
  int turn; // ���l�ѹ�ԥΪ�
  int dark_turn; //�t�ѹ�ԥ�
  int port; // port
  char   pad[41];
};
typedef struct user_info user_info;


/* ----------------------------------------------------- */
/* BOARDS struct : 256 bytes                             */
/* ----------------------------------------------------- */
#define BRD_NOZAP       00001         /* ���izap  */
#define BRD_NOCOUNT     00002         /* ���C�J�έp */
#define BRD_NOTRAN      00004         /* ����H */
#define BRD_GROUPBOARD  00010         /* �s�ժO */
#define BRD_HIDE        00020         /* ���êO (�ݪO�n�ͤ~�i��) */
#define BRD_POSTMASK    00040         /* ����o���ξ\Ū */
#define BRD_ANONYMOUS   00100         /* �ΦW�O? */
#define BRD_GOOD        00200	      /* �u�}�ݪO */
#define BRD_UNNEW       00400         /* �Ӽo���O */
#define BRD_PRO         01000         /* �ӤH�ΪO */
#define BRD_ASTRO       02000         /* �a�ڥΪO */

struct boardheader
{
  char brdname[IDLEN + 1];      /* �ݪO�^��W��    13 bytes */
  char title[BTLEN + 1];        /* �ݪO����W��    49 bytes */
  char BM[IDLEN * 3 + 3];       /* �O�DID�M"/"     39 bytes */
  usint brdattr;                /* �ݪO���ݩ�       4 bytes */
  time_t bupdate;               /* note update time 4 bytes */
  uschar bvote;                 /* Vote flags       1 bytes */
  time_t vtime;                 /* Vote close time  4 bytes */
  usint level;                  /* �i�H�ݦ��O���v�� 4 bytes */
  unsigned long int totalvisit; /* �`���X�H��       8 bytes */
  unsigned long int totaltime;  /* �`���d�ɶ�       8 bytes */
  char lastvisit[IDLEN + 1];    /* �̫�ݸӪO���H  13 bytes */
  time_t opentime;              /* �}�O�ɶ�         4 bytes */
  time_t lastime;               /* �̫���X�ɶ�     4 bytes */
  char holiday[17];		/* �ݪO�`��        16 bytes */
  char descript[60];		/* �ݪO�ԭz        60 bytes */
  int port;			/* �ݪO�Ϊ�port     4 bytes */
  int bid;                      /* �ݪO�ۤv��id     4 bytes */
  int gid;                      /* �ݪO���ݪ�group  4 bytes */
  char pad[8];
};
typedef struct boardheader boardheader;


struct one_key
{                               /* Used to pass commands to the readmenu */
  int key;
  int (*fptr) ();
};


/* ----------------------------------------------------- */
/* cache.c ���B�Ϊ���Ƶ��c                              */
/* ----------------------------------------------------- */


#define USHM_SIZE       (MAXACTIVE + 4)
struct UTMPFILE
{
  user_info uinfo[USHM_SIZE];
  time_t uptime;
  int number;
  int busystate;
};

struct BCACHE
{
  boardheader bcache[MAXBOARD];
  usint total[MAXBOARD];
  time_t lastposttime[MAXBOARD];
  time_t uptime;
  time_t touchtime;
  int number;
  int busystate;
};

struct UCACHE
{
  char userid[MAXUSERS][IDLEN + 1];
  time_t uptime;
  time_t touchtime;
  int number;
  int busystate;
};

struct FROMCACHE
{
  char domain[MAX_FROM][50];
  char replace[MAX_FROM][50];
  int top;
  int max_user;
  time_t max_time;
  time_t uptime;
  time_t touchtime;
  int busystate;
};

struct BACACHE          
{                       
  char author[300][100];
  int top;              
  time_t uptime;        
  time_t touchtime;     
  int busystate;        
};                      

struct hosts
{
 char shortname[24];
 char address[40];
 char desc[24];
};

typedef struct hosts hosts;



/* ----------------------------------------------------- */
/* screen.c ���B�Ϊ���Ƶ��c                             */
/* ----------------------------------------------------- */

#define ANSILINELEN (255)       /* Maximum Screen width in chars */

/* Line buffer modes */
#define MODIFIED (1)            /* if line has been modifed, screen output */
#define STANDOUT (2)            /* if this line has a standout region */

struct screenline
{
  uschar oldlen;                /* previous line length */
  uschar len;                   /* current length of line */
  uschar mode;                  /* status of line, as far as update */
  uschar smod;                  /* start of modified data */
  uschar emod;                  /* end of modified data */
  uschar sso;                   /* start stand out */
  uschar eso;                   /* end stand out */
  unsigned char data[ANSILINELEN + 1];
};
typedef struct screenline screenline;


/* ----------------------------------------------------- */
/* name.c ���B�Ϊ���Ƶ��c                               */
/* ----------------------------------------------------- */

struct word
{
  char *word;
  struct word *next;
};


/* ----------------------------------------------------- */
/* edit.c ���B�Ϊ���Ƶ��c                               */
/* ----------------------------------------------------- */

#define WRAPMARGIN (254)

struct textline
{
  struct textline *prev;
  struct textline *next;
  int len;
  char data[WRAPMARGIN + 1];
};
typedef struct textline textline;

#endif                          /* _STRUCT_H_ */

/* ----------------------------------------------------- */
/* announce.c                                            */
/* ----------------------------------------------------- */

#define MAXITEMS        1000     /* �@�ӥؿ��̦h���X�� */

typedef struct
{
  fileheader *header;
  char mtitle[STRLEN];
  char *path;
  int num, page, now, level;
} AMENU;

union x_item
{
  struct                        /* bbs_item */
  {
    char fdate[9];              /* [mm/dd/yy] */
    char editor[13];            /* user ID */
    char fname[31];
  }      B;

  struct                        /* gopher_item */
  {
    char path[81];
    char server[48];
    int port;
  }      G;
};

typedef struct
{
  char title[63];
  union x_item X;
}      ITEM;

typedef struct
{
  ITEM *item[MAXITEMS];
  char mtitle[STRLEN];
  char *path;
  int num, page, now, level;
}      GMENU;


