/*-------------------------------------------------------*/
/* film.h        ( FJU StarRiverBBS Ver 1.65 )           */
/*-------------------------------------------------------*/
/* target : include file for camera                      */
/* create : 00/04/11                                     */
/* update : 00/04/11                                     */
/*-------------------------------------------------------*/


//#include "bbs.h"

#define MOVIE_MAX       (200)           /* �ʵe�i�� */
#define MOVIE_SIZE      (108*1024)      /* �ʵe cache size */
#define MOVIE_LINES     (10)            /* �ʵe�̦h�� 10 �C */
#define FILM_SIZ        4000    /* max size for each film */

typedef struct
{
  int shot[MOVIE_MAX];
 /* Thor.980805: �i���٭n�A�[1,�]�X�z�d��0..MOVIE_MAX */
  char film[MOVIE_SIZE];
} FCACHE;


#define FILM_MOVIE      25

#define FILM_GEM         0  //announce help
#define FILM_MAIL        1  //mail help
#define FILM_READ        2  //read help
#define FILM_BRD         3  //board help
#define FILM_MORE        4  //more help
#define FILM_EDIT        5 //ve.hlp
#define FILM_T_USR       6
#define FILM_T_PAGE      7
#define FILM_T_ADM       8
#define FILM_WEL         9
#define FILM_LINE       10
#define FILM_LOGIN      11 // etc/welcome_login
#define M2_1            12 // m2/1
#define M2_2            13 // m2/2
#define M2_3            14 // m2/3
#define M2_4            15 // m2/4
#define M2_5            16 // m2/5
#define M2_6            17 // m2/6
#define M2_7            18 // m2/7
#define M2_8            19 // m2/8
#define M2_9            20 // m2/9
#define M2_10           21 // m2/10
#define WEL_BIRTH       22 // etc/Welcome_birth
#define REGISTER        23 // etc/register
#define POST            24 // etc/post.note

#define FILM_ROW        40

