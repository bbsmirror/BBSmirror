/*-------------------------------------------------------*/
/* admin.c      ( NTHU CS MapleBBS Ver 2.36 )            */
/*-------------------------------------------------------*/
/* target : administration routines                      */
/* create : 95/03/29                                     */
/* update : 95/12/15                                     */
/*-------------------------------------------------------*/

#define _ADMIN_C_

#include "bbs.h"

void
log_file(file, mesg)
  char *file, *mesg;
{
  FILE *fp;
  time_t      now;
  char        buf[256];

  now = time(0);
  sprintf( buf, "%s %s",
      Ctime( &now )+4, mesg);

  if (fp = fopen(file, "a+"))
  {
    fprintf(fp, "%s\n",buf);
    fclose(fp);
  }
}


/* ----------------------------------------------------- */
/* �ݪO�޲z                                              */
/* ----------------------------------------------------- */

extern int cmpbnames();

static int
invalid_brdname(brd)  /* �w�q���~�ݪO�W�� */
  char *brd;
{
  register char ch;

  ch = *brd++;
  if (not_alnum(ch))
    return 1;
  while (ch = *brd++)
  {
    if (not_alnum(ch) && ch != '_' && ch != '-' && ch != '.')
      return 1;
  }
  return 0;
}


/* -------------- */
/* �۰ʳ]�ߺ�ذ� */
/* -------------- */


static void
setup_man(board)
  boardheader *board;
{
  char genbuf[200];

  setapath(genbuf, board->brdname);
  mkdir(genbuf, 0755);
}


static void
bperm_msg(board)
  boardheader *board;
{
  prints("\n�]�w [%s] �ݪO��(%s)�v���G", board->brdname,
    board->brdattr & BRD_POSTMASK ? "�o��" : "�\\Ū");
}

extern int numboards;

static char *classname[] = {
"1.����","2.�Z�O","3.�T��",
"4.��","5.��|","6.����",
"7.�ն�","8.�q��","9.����",
"[�Φۦ��J]",
NULL};

int
m_newbrd()
{
  boardheader newboard;
  char ans[4];
  int bid,classnum=0;
  char genbuf[200];
  extern char *boardprefix;

  FILE *fp;
  time_t now = time(0);
  fileheader mhdr;
  char genbuf1[200], fpath1[STRLEN];

  stand_title("�إ߷s�O");
  memset(&newboard, 0, sizeof(newboard));

  do
  {
    if (!getdata(3, 0, msg_bid, newboard.brdname, IDLEN + 1, DOECHO,0))
      return -1;
  } while (invalid_brdname(newboard.brdname));

  if(HAS_PERM(PERM_SYSOP))
      while (classname[classnum]!=NULL)  outs (classname[classnum++]);
  do
  {
   getdata(6, 0, "�ݪO���O�G", genbuf , 5 ,DOECHO,0);
   if( HAS_PERM(PERM_SYSOP) ||
      ((strstr(boardprefix,genbuf) != NULL )&& strlen(genbuf) == 4)) break;
     outs("�u��}�ҰϤ����O����");
  }while(1);

  if ( genbuf[0]>='1' && genbuf[0]<='9' )
  {
        strncpy (newboard.title,classname[*genbuf-'1']+2,4);
  }
  else if( strlen(genbuf)>=4 )
  {
        strncpy (newboard.title, genbuf ,4);
  }
  newboard.title[4]=' ';
  move(6,30);
  prints("1.��H �� 2.����H �� 3.�l��� �U");
  getdata(7, 0, "4.�u�}�ݪO(��H) �� 5.�u�}�ݪO(����H) �� �G" ,
                                      genbuf , 3 ,LCECHO,"2");
  if((genbuf[0] == '3' || genbuf[0] == '4' )&& !HAS_PERM(PERM_SYSOP))
    genbuf[0] = '2';

  newboard.brdattr = 0;
  if(genbuf[0])
   {
    strncpy (newboard.title+5,((*genbuf=='1')?"��":
    (*genbuf=='2') ? "��": (*genbuf == '3') ? "�U" :
    (*genbuf == '4') ? "��" :(*genbuf == '5') ? "��" : "��"), 2);
    switch(*genbuf)
        {
          case '5':
                 newboard.brdattr |= BRD_NOTRAN;
                 newboard.brdattr |= BRD_GOOD;
                 break;
          case '4':
                 newboard.brdattr &= ~BRD_NOTRAN;
                 newboard.brdattr |= BRD_GOOD;
                 break;
           case '3':
                 newboard.brdattr |= BRD_GROUPBOARD;
                 newboard.brdattr |= BRD_NOCOUNT;
           case '2':
                 newboard.brdattr |= BRD_NOTRAN;
                 break;
           case '1':
                 newboard.brdattr &= ~BRD_NOTRAN;
                 break;
        }
   }

  getdata(8, 0, "�ݪO�D�D�G", genbuf , BTLEN + 1, DOECHO,0);
  if(genbuf[0])
    {
     strcpy (newboard.title + 7,genbuf);
    }
  setbpath(genbuf, newboard.brdname);
  mkdir(genbuf, 0755);
  if (getbnum(newboard.brdname) > 0)
  {
    pressanykey(err_bid);
    return -1;
  }
    getdata(9, 0, "�O�D�W��G", newboard.BM, IDLEN * 3 + 3, DOECHO,0);
  if( HAS_PERM(PERM_SYSOP) )
  {
   getdata(10, 0, "�i�HZAP(Y/N)�H", ans, 4, LCECHO,"Y");
   if (*ans == 'n')
                newboard.brdattr |= BRD_NOZAP ;
   getdata(11, 0, "�i�H�ΦW(Y/N)�H", ans, 4, LCECHO,"N");
   if (*ans == 'y')
                newboard.brdattr |= BRD_ANONYMOUS ;
  }
    newboard.level = 0;
  if (!(newboard.brdattr & BRD_GROUPBOARD))
   {
    getdata(12, 0, HAS_PERM(PERM_SYSOP)?
                "�ݪO����/�p�H/���}(Y/P/N)�H":"�ݪO�p�H/���}(P/N)�H"
                , ans, 4, LCECHO,"N");
    if (*ans == 'y' && HAS_PERM(PERM_SYSOP))
         {
                newboard.brdattr |= BRD_HIDE;
                newboard.brdattr |= BRD_POSTMASK;
         }
    else if (*ans == 'p')
        {
                newboard.brdattr |= BRD_HIDE;
        }
    newboard.bid = numboards + 1;
    newboard.gid = 0;
    getdata(13, 0, "�C�J�έp/�Ʀ�(Y/N)�H", ans, 4, LCECHO,"Y");
    if (*ans == 'n')
                newboard.brdattr |= BRD_NOCOUNT;

    if(HAS_PERM(PERM_SYSOP) && !(newboard.brdattr & BRD_HIDE))
     {
      getdata(14, 0, "�]�wŪ�g�v��(Y/N)�H", ans, 4, LCECHO,"Y");
      if (*ans == 'y')
        {
            getdata(15, 0, "���� [R]�\\Ū (P)�o���H", ans, 4, LCECHO,"P");
            if (*ans == 'p')
                newboard.brdattr |= BRD_POSTMASK;
            move(1, 0);
            clrtobot();
            bperm_msg(&newboard);
            newboard.level = setperms(newboard.level);
            clear();
        }
     }
   }
  else
   {
    if(!newboard.BM[0] || newboard.BM[0]== ' ') strcpy(newboard.BM,"[�ؿ�]");
    newboard.brdattr |= BRD_POSTMASK;
    newboard.level |= (1 << 15);
   }
  if ((bid = getbnum("")) > 0)
  {
    substitute_record(fn_board, &newboard, sizeof(newboard), bid);
  }
  else if (rec_add(fn_board, &newboard, sizeof(newboard)) == -1)
  {
    pressanykey(NULL);
    return -1;
  }
  setup_man(&newboard);
  touch_boards();
  log_usies("NewBoard", newboard.title);
/* ------------------------------------------------------ */
  setbpath(genbuf1, "Security");
  stampfile(genbuf1, &mhdr);
  strcpy(mhdr.owner, cuser.userid);
  strncpy(mhdr.title, "�s�O����", TTLEN);
  mhdr.savemode = '\0';
  setbdir(fpath1, "Security");
  if (rec_add(fpath1, &mhdr, sizeof(mhdr)) == -1){
   outs(err_uid);
   return 0;
  }
  if ((fp = fopen(genbuf1, "w")) != NULL){
   fprintf(fp, "�@��: %s (%s)\n", cuser.userid, cuser.username);
   fprintf(fp, "���D: %s\n�ɶ�: %s\n", "�s�O����", ctime(&now));
   fprintf(fp, "���� %s �}�]�F %s �O", cuser.userid,newboard.brdname);
   fprintf(fp, "�O�D: %s \n",newboard.BM);
   fprintf(fp, "�ݪO����/���O/����O�W: %s \n",newboard.title);
   fprintf(fp, "�ݪOŪ�g�v��: %s�]�� \n",newboard.level ? "��" : "��");
   fprintf(fp, "�i�_zap: %s \n",newboard.brdattr & BRD_NOZAP ? "��":"��");
   fprintf(fp, "�C�J�έp: %s \n",newboard.brdattr & BRD_NOCOUNT ? "��":"��");
   fprintf(fp, "��H: %s \n",newboard.brdattr & BRD_NOTRAN  ? "��":"��");
   fprintf(fp, "�s�ժO: %s \n",newboard.brdattr & BRD_GROUPBOARD ? "��":"��");
   fprintf(fp, "����: %s \n",newboard.brdattr & BRD_HIDE  ? "��":"��");
   fprintf(fp, "�ΦW: %s \n",newboard.brdattr & BRD_ANONYMOUS ? "��":"��");
   fprintf(fp, "�u�}: %s \n",newboard.brdattr & BRD_GOOD ? "��" : "��");

   fclose(fp);
  }
/* ----------------------------------------------------------- */
  pressanykey("�s�O����");
  return 0;
}


int
m_mod_board(char *bname)
{
  boardheader bh, newbh;
  int bid,classnum=0,avg;
  char genbuf[200];
  extern char *boardprefix;

  bid = getbnum(bname);
  if (rec_get(fn_board, &bh, sizeof(bh), bid) == -1)
  {
    pressanykey(err_bid);
    return -1;
  }
  move(1,0);
  clrtobot();
  prints("�ݪO�W�١G%-15s�O�D�W��G%s\n�ݪO�����G%s\n",
    bh.brdname, bh.BM, bh.title);
  {
    int t=bh.totaltime;
    int day=t/86400,hour=(t/3600)%24,min=(t/60)%60,sec=t%60;
    avg = bh.totalvisit !=0 ? bh.totaltime/bh.totalvisit : 0;
    prints("���X�H�ơG%-15d���X�ɶ��G%d �� %d �p�� %d �� %d �� �������d�G%d ��\n",
    bh.totalvisit,day,hour,min,sec,avg);
  }
  prints("�̷s�X�ȡG%-15s�̷s�ɶ��G%s"
    ,bh.lastvisit,ctime(&bh.lastime));
  if(!HAS_PERM(PERM_BOARD))
  {
    pressanykey(NULL);
    return 0;
  }
  bperm_msg(&bh);
  prints("%s�]�� port: %d bid: %d gid: %d\n"
         "�izap:%s �C�J�έp:%s ��H:%s �s�ժO:%s ����:%s �ΦW:%s �u�}:%s",
         bh.level ? "��" : "��",bh.port,bh.bid, bh.gid,
         bh.brdattr & BRD_NOZAP ? "��":"��",
         bh.brdattr & BRD_NOCOUNT  ? "��":"��",
         bh.brdattr & BRD_NOTRAN  ? "��":"��",
         bh.brdattr & BRD_GROUPBOARD  ? "��":"��",
         bh.brdattr & BRD_HIDE  ? "��":"��",
         bh.brdattr & BRD_ANONYMOUS ? "��":"��",
         bh.brdattr & BRD_GOOD ? "��" : "��");

  getdata(9, 0, "\
�ݪO (D)�R�� (E)�]�w (B)�O�D (G)�]�w���� [Q]�����H", genbuf, 3,LCECHO,0);

  switch (*genbuf)
  {
  case 'd':
    if(!HAS_PERM(PERM_SYSOP)) break;
    getdata(10, 0, msg_sure_ny, genbuf, 3, LCECHO,"N");
    if (genbuf[0] != 'y')
    {
      outs(MSG_DEL_CANCEL);
    }
    else
    {
      strcpy(bname, bh.brdname);
      sprintf(genbuf, "/bin/rm -fr boards/%s man/boards/%s", bname, bname);
      system(genbuf);
      memset(&bh, 0, sizeof(bh));
      sprintf(bh.title, "[%s] deleted by %s", bname, cuser.userid);
      substitute_record(fn_board, &bh, sizeof(bh), bid);
      touch_boards();
      log_usies("DelBoard", bh.title);
      outs("�R�O����");
    }
    break;

  case 'e':

    move(10, 0);
    outs("������ [Return] ���ק�Ӷ��]�w");
    memcpy(&newbh, &bh, sizeof(bh));

    while (getdata(11, 0, "�s�ݪO�W�١G", genbuf, IDLEN + 1,DOECHO,0))
    {
      if (getbnum(genbuf))
        pressanykey("���~! �O�W�p�P");
      else if (!invalid_brdname(genbuf))
      {
        strcpy(newbh.brdname, genbuf);
        break;
      }
    }
   if(HAS_PERM(PERM_SYSOP))
      while (classname[classnum]!=NULL)  outs (classname[classnum++]);
   do
    {
     getdata(12, 0, "�ݪO���O�G", genbuf , 5 ,DOECHO,bh.title,0);
     if( HAS_PERM(PERM_SYSOP) ||
        ((strstr(boardprefix,genbuf) != NULL )&& strlen(genbuf) == 4)) break;
       outs("�u��}�ҰϤ����O����");
    }while(1);

   if ( genbuf[0]>='1' && genbuf[0]<='9' )
         strncpy (newbh.title,classname[*genbuf-'1']+2,4);
   else if( strlen(genbuf)>=4 )
         strncpy (newbh.title, genbuf ,4);

   newbh.title[4]=' ';
   move(12,20);
   prints("1.��H �� 2.����H �� 3.�l��� �U 4.�u�}�ݪO(��H) ��");
   getdata(13, 0, "5.�u�}�ݪO �� 6.�Ӽo���O �� 7.�ӤH�O �� 8.��H�ӤH�O  ���G" ,
    genbuf , 3 ,LCECHO,0);
    if(genbuf[0])
     {
      strncpy (newbh.title+5,((*genbuf=='1')?"��":
      (*genbuf == '2') ? "��": (*genbuf == '3') ? "�U" :
      (*genbuf == '4') ? "��": (*genbuf == '5') ? "��" :
      (*genbuf == '6') ? "��": (*genbuf == '7') ? "��" :
      (*genbuf == '8') ? "��":"��"), 2);
      switch(*genbuf)
        {
           case '8':
                 newbh.brdattr &= ~BRD_GROUPBOARD;
                 newbh.brdattr &= ~BRD_NOTRAN;
                 newbh.brdattr |= BRD_PRO;
                 break;
           case '7':
                 newbh.brdattr &= ~BRD_GROUPBOARD;
                 newbh.brdattr |= BRD_NOTRAN;
                 newbh.brdattr |= BRD_PRO;
                 break;
           case '6':
                 newbh.brdattr &= ~BRD_GROUPBOARD;
                 newbh.brdattr |= BRD_NOTRAN;
                 newbh.brdattr |= BRD_UNNEW;
                 break;
           case '5':
                 newbh.brdattr &= ~BRD_GROUPBOARD;
                 newbh.brdattr |= BRD_NOTRAN;
                 newbh.brdattr |= BRD_GOOD;
                 break;
           case '4':
                 newbh.brdattr &= ~BRD_GROUPBOARD;
                 newbh.brdattr &= ~BRD_NOTRAN;
                 newbh.brdattr |= BRD_GOOD;
                 break;
           case '3':
                 newbh.brdattr |= BRD_GROUPBOARD;
                 newbh.brdattr |= BRD_NOCOUNT;
                 newbh.brdattr |= BRD_NOTRAN;
                 break;
           case '2':
                 newbh.brdattr &= ~BRD_GROUPBOARD;
                 newbh.brdattr |= BRD_NOTRAN;
                 break;
           case '1':
                 newbh.brdattr &= ~BRD_GROUPBOARD;
                 newbh.brdattr &= ~BRD_NOTRAN;
                 break;
        }
     }
    getdata(14, 0, "�ݪO�D�D�G", genbuf , BTLEN + 1, DOECHO,bh.title+7);
    if(genbuf[0])
    {
      strcpy (newbh.title + 7,genbuf);
    }

        if (getdata(15, 0, "�s�O�D�W��G", genbuf, IDLEN * 3 + 3,
                        DOECHO,bh.BM))
        {
          str_trim(genbuf);
          strcpy(newbh.BM, genbuf);
        }
    if( HAS_PERM(PERM_SYSOP) )
    {
            getdata(16, 0, "�i�HZAP(Y/N)�H", genbuf, 4, LCECHO,
                newbh.brdattr & BRD_NOZAP ? "N" : "Y" );
            if (*genbuf == 'n')
                newbh.brdattr |= BRD_NOZAP ;
            else        newbh.brdattr &= ~BRD_NOZAP ;

            getdata(16, 30, "�i�H�ΦW(Y/N)�H", genbuf, 4, LCECHO,
                newbh.brdattr & BRD_ANONYMOUS ? "Y" : "N");
            if (*genbuf == 'y')
                newbh.brdattr |= BRD_ANONYMOUS ;
            else        newbh.brdattr &= ~BRD_ANONYMOUS ;
/* skybinary */

            getdata(17,0,"����:",genbuf,60,DOECHO,newbh.descript);
            strcpy(newbh.descript,genbuf);
            getdata(18,0,"�ϥΪ�port:",genbuf,6,DOECHO,"23");
            newbh.port = atoi(genbuf);
    }
    if (!(newbh.brdattr & BRD_GROUPBOARD))
       {
        char ans[4];
        getdata(19, 0, HAS_PERM(PERM_SYSOP)?"�ݪO����/�p�H/���}(Y/P/N)�H"
                  :"�ݪO�p�H/���}(P/N)�H", ans, 4, LCECHO,
                     !(newbh.brdattr & BRD_HIDE) ? "N":
                     (newbh.brdattr & BRD_POSTMASK) ? "Y":"P");
            if (*ans == 'y' && HAS_PERM(PERM_SYSOP))
                 {
                        newbh.brdattr |= BRD_HIDE;
                        newbh.brdattr |= BRD_POSTMASK;
                 }
            else if (*ans == 'p')
                {
                        newbh.brdattr |= BRD_HIDE;
                        newbh.brdattr &= ~BRD_POSTMASK;
                }
            else   newbh.brdattr &= ~BRD_HIDE;

        getdata(20, 0, "�C�J�έp/�Ʀ�(Y/N)�H", genbuf, 4, LCECHO,
                        newbh.brdattr & BRD_NOCOUNT ? "N":"Y");
            if (*genbuf == 'n')
                newbh.brdattr |= BRD_NOCOUNT;
            else  newbh.brdattr &= ~BRD_NOCOUNT;
        if( HAS_PERM(PERM_SYSOP) && !(newbh.brdattr & BRD_HIDE))
        {
          getdata(21, 0, "�O�_���s���v��(Y/N)�H[N] ", genbuf, 4,
                     LCECHO,0);
          if (*genbuf == 'y')
          {
            getdata(21, 0, "���� (R)�\\Ū (P)�o���H ", genbuf, 4, LCECHO,
                 (newbh.brdattr & BRD_POSTMASK ? "P" : "R"));
            if (newbh.brdattr & BRD_POSTMASK)
            {
              if (*genbuf == 'r')
                newbh.brdattr &= ~BRD_POSTMASK;
            }
            else
            {
              if (*genbuf == 'p')
                newbh.brdattr |= BRD_POSTMASK;
            }

            move(1, 0);
            clrtobot();
            bperm_msg(&newbh);
            newbh.level = setperms(newbh.level);
          }
        }
       }
    else
       {
           newbh.brdattr |= BRD_POSTMASK;
           newbh.level |= (1 << 15);
       }

    getdata(b_lines - 1, 0, msg_sure_ny, genbuf, 4, LCECHO,"Y");

    if ((*genbuf == 'y') && memcmp(&newbh, &bh, sizeof(bh)))
    {
      if (strcmp(bh.brdname, newbh.brdname))
      {
        char src[60], tar[60];

        setbpath(src, bh.brdname);
        setbpath(tar, newbh.brdname);
        f_mv(src, tar);

        setapath(src, bh.brdname);
        setapath(tar, newbh.brdname);
        f_mv(src, tar);
      }
      setup_man(&newbh);
      substitute_record(fn_board, &newbh, sizeof(newbh), bid);
      touch_boards();
      log_usies("SetBoard", newbh.brdname);
    }
     break;
    case 'g':
      memcpy(&newbh, &bh, sizeof(bh));
      getdata(11, 0, "GID�G", genbuf, 5, DOECHO, 0);
        newbh.gid = atoi(genbuf);
      substitute_record(fn_board, &newbh, sizeof(newbh), bid);
      touch_boards();
      log_usies("SetBoardGID", newbh.brdname);

      break;
    case 'b':
      memcpy(&newbh, &bh, sizeof(bh));
      if (getdata(11, 0, "�s�O�D�W��G", genbuf, IDLEN * 3 + 3,DOECHO,bh.BM))
      {
        str_trim(genbuf);
        strcpy(newbh.BM, genbuf);
      }
      substitute_record(fn_board, &newbh, sizeof(newbh), bid);
      touch_boards();
      log_usies("SetBoardBM", newbh.brdname);
  }
  return 0;
}

int
m_board()
{
  char bname[20];
  stand_title("�ݪO�]�w");
  make_blist();
  namecomplete(msg_bid, bname);
  if (!*bname)
    return 0;
  m_mod_board(bname);
}

/* ----------------------------------------------------- */
/* �ϥΪ̺޲z                                            */
/* ----------------------------------------------------- */

int
m_user()
{
  userec muser;
  int id;
  char genbuf[200];

  stand_title("�ϥΪ̳]�w");
  usercomplete(msg_uid, genbuf);
  if (*genbuf)
  {
    move(2, 0);
    if (id = getuser(genbuf))
    {
      memcpy(&muser, &xuser, sizeof(muser));
      clear();
      u_data(&muser,1,id);
    }
    else
    {
      pressanykey(err_uid);
    }
  }
  return 0;
}


#ifdef HAVE_TIN
int
post_in_tin(username)
  char *username;
{
  char buf[256];
  FILE *fh;
  int counter = 0;

  sethomefile(buf, username, ".tin/posted");
  fh = fopen(buf, "r");
  if (fh == NULL)
    return 0;
  else
  {
    while (fgets(buf, 255, fh) != NULL)
    {
      if (buf[9] != 'd' && strncmp(&buf[11], "csie.bbs.test", 13))
        counter++;
      if (buf[9] == 'd')
        counter--;
    }
    fclose(fh);
    return counter;
  }

}
#endif


/* ----------------------------------------------------- */
/* �M���ϥΪ̫H�c                                        */
/* ----------------------------------------------------- */


#ifdef  HAVE_MAILCLEAN
FILE *cleanlog;
char curruser[IDLEN + 2];
extern int delmsgs[];
extern int delcnt;

static int
domailclean(fhdrp)
  fileheader *fhdrp;
{
  static int newcnt, savecnt, deleted, idc;
  char buf[STRLEN];

  if (!fhdrp)
  {
    fprintf(cleanlog, "new = %d, saved = %d, deleted = %d\n",
      newcnt, savecnt, deleted);
    newcnt = savecnt = deleted = idc = 0;
    if (delcnt)
    {
      sethomedir(buf, curruser);
      while (delcnt--)
        delete_record(buf, sizeof(fileheader), delmsgs[delcnt]);
    }
    delcnt = 0;
    return 1;
  }
  idc++;
  if (!(fhdrp->filemode & FILE_READ))
    newcnt++;
  else if (fhdrp->filemode & FILE_MARKED)
    savecnt++;
  else
  {
    deleted++;
    sethomefile(buf, curruser, fhdrp->filename);
    unlink(buf);
    delmsgs[delcnt++] = idc;
  }
  return 0;
}


static int
cleanmail(urec)
  userec *urec;
{
  struct stat statb;
  char genbuf[200];

  if (urec->userid[0] == '\0' || !strcmp(urec->userid, str_new))
    return;
  sethomedir(genbuf, urec->userid);
  fprintf(cleanlog, "%s�G", urec->userid);
  if (stat(genbuf, &statb) == -1 || statb.st_size == 0)
    fprintf(cleanlog, "no mail\n");
  else
  {
    strcpy(curruser, urec->userid);
    delcnt = 0;
    rec_apply(genbuf, domailclean, sizeof(fileheader));
    domailclean(NULL);
  }
  return 0;
}


int
m_mclean()
{
  char ans[4];

  getdata(b_lines - 1, 0, msg_sure_ny, ans, 4, LCECHO,"N");
  if (ans[0] != 'y')
    return FULLUPDATE;

  cleanlog = fopen("mailclean.log", "w");
  outmsg("This is variable msg_working!");

  move(b_lines - 1, 0);
  if (rec_apply(fn_passwd, cleanmail, sizeof(userec)) == -1)
  {
    outs(ERR_PASSWD_OPEN);
  }
  else
  {
    fclose(cleanlog);
    outs("�M������! �O���� mailclean.log.");
  }
  return FULLUPDATE;
}
#endif  HAVE_MAILCLEAN

/* ----------------------------------------------------- */
/* �B�z Register Form                                    */
/* ----------------------------------------------------- */

int           /* Ptt */
mail_muser(userec muser)
{
          fileheader mhdr;
          char title[128], buf1[80];
          sethomepath(buf1, muser.userid);
          stampfile(buf1, &mhdr);
          strcpy(mhdr.owner, cuser.userid);
          strncpy(mhdr.title, "[���U���\\�o]", TTLEN);
          mhdr.savemode = 0;
          mhdr.filemode = 0;
          sethomedir(title, muser.userid);
          rec_add(title, &mhdr, sizeof(mhdr));
          f_cp("etc/registered", buf1,O_TRUNC);
 return 0;
}

static int cRegisterList = 0;   // �ݼf�H��
static int scan_register_form(regfile)
  char *regfile;
{
  char genbuf[200];
  static char *logfile = "register.log";
  static char *field[] = {"num", "uid", "name" ,"email",
  "addr", "phone", "career" ,NULL};
  static char *finfo[] = {"   �b���s��", "   �ӽХN��", "0. �u��m�W",
  "1. �q�l�l��H�c","2. �ثe���}", "3. �s���q��", "4. �A�ȳ��" ,NULL};
  static char *reason[] = {"��J�u��m�W", "�Զ�q�l�l��H�c",
   "��g���㪺���}���", "�Զ�s���q��", "�Զ�Ǯլ�t�P�~��",
   "�T���g���U�ӽЪ�", "�Τ����g�ӽг�", NULL};

  userec muser;
  FILE *fn, *fout, *freg;
  char fdata[8][STRLEN];
  char fname[STRLEN], buf[STRLEN];
  char ans[4], *ptr, *uid;
  int n, unum, nowRegisterList, i, ok, rej, kill;

  nowRegisterList = i = ok = rej = kill = 0;
  uid = cuser.userid;
  sprintf(fname, "%s.tmp", regfile);
  if (dashf(fname))
  {
    pressanykey("��L SYSOP �]�b�f�ֵ��U�ӽг�");
    return -1;
  }
  f_mv(regfile, fname);
  if ((fn = fopen(fname, "r")) == NULL)
  {
    pressanykey("�t�ο��~�A�L�kŪ�����U�����: %s", fname);
    return -1;
  }

  memset(fdata, 0, sizeof(fdata));
  while (fgets(genbuf, STRLEN, fn))
  {
    if (ptr = (char *) strstr(genbuf, ": "))
    {
      *ptr = '\0';
      for (n = 0; field[n]; n++)
      {
        if (strcmp(genbuf, field[n]) == 0)
        {
          strcpy(fdata[n], ptr + 2);
          if (ptr = (char *) strchr(fdata[n], '\n'))
            *ptr = '\0';
        }
      }
    }
    else if ((unum = getuser(fdata[1])) == 0)
    {
      move(2, 0);
      clrtobot();
      for (n = 0; field[n]; n++)
        prints("%s     : %s\n", finfo[n], fdata[n]);
      pressanykey("�t�ο��~�A�d�L���H");
    }
    else
    {
      nowRegisterList ++;
      memcpy(&muser, &xuser, sizeof(muser));

//      user_display(&muser, 1);
      move(1, 0);
      prints("�z���b�f�z�� %d/%d �����U��\n", nowRegisterList,cRegisterList);
      prints("[1;32m------------- �Я����Y��f�֨ϥΪ̸�� ---------------[m\n");
      for (n = 0; field[n]; n++)
        prints("%-12s�G%s\n", finfo[n], fdata[n]);
      prints("[1;33m--------- �w�]�h�^��]�p�U,�Ϋ� [5;31mN[m[1;33m �ۦ��J -----------[m\n\n");
      for (n = 0; reason[n]; n++)
        prints("%d) ��%s\n", n, reason[n]);
     clrtobot();
            if (muser.userlevel & PERM_LOGINOK)
      {
        getdata(b_lines - 1, 0, "���b���w�g�������U, ��s(Y/N/Skip)�H[N] ",
          ans, 3, LCECHO,"Y");
        if (ans[0] != 'y' && ans[0] != 's')
          ans[0] = 'd';
      }
      else
        getdata(b_lines - 3, 0, "�O�_���������(Yes/0-7/No/Quit/Del/Skip)�H[S]",
          ans, 3, LCECHO,"");

      switch (ans[0])
      {
      case 'y':

        prints("�H�U�ϥΪ̸�Ƥw�g��s:\n");
        mail_muser(muser);
        muser.userlevel |= (PERM_CHAT | PERM_PAGE |PERM_LOGINOK | PERM_POST);
        sprintf(genbuf, "%s:%s:%s", fdata[7], fdata[5], uid);
//        strncpy(muser.justify, genbuf, REGLEN);
        sethomefile(buf, muser.userid, "justify");
        if (fout = fopen(buf, "a"))
        {
          fprintf(fout, "%s\n", genbuf);
          fclose(fout);
        }
        substitute_record(fn_passwd, &muser, sizeof(muser), unum);

        if (fout = fopen(logfile, "a"))
        {
          for (n = 0; field[n]; n++)
            fprintf(fout, "%s: %s\n", field[n], fdata[n]);
          n = time(NULL);
          fprintf(fout, "Date: %s\n", Cdate(&n));
          fprintf(fout, "Approved: %s\n", uid);
          fprintf(fout, "----\n");
          fclose(fout);
        }
        move (2,0);
        clrtobot();
        break;

      case 'q':         /* �Ӳ֤F�A������ */

        if (freg = fopen(regfile, "a"))
        {
          for (n = 0; field[n]; n++)
            fprintf(freg, "%s: %s\n", field[n], fdata[n]);
          fprintf(freg, "----\n");
          while (fgets(genbuf, STRLEN, fn))
            fputs(genbuf, freg);
          fclose(freg);
        }


 /*       case 'd':
        break;


      �ڧ�wuju�j�j���q��b�����q�ۨӥΥά�....:P �ŧi���� yroj

        getdata(b_lines, 0, "�T�w�R���� user (y/n) ? [N]", buf, 4, LCECHO, 0);

        if (buf[0] == 'y')
        {
         char src[STRLEN], dst[STRLEN];

         sethomepath(src, muser.userid);
         sprintf(dst,"tmp/%s", muser.userid);

         sweep(muser.userid);
         if (Rename(src, dst))
         {
          sprintf(genbuf, "/bin/rm -fr %s", src);
          system(genbuf);
         }
         log_usies("KILL", muser.userid);
         sysop_log("�R�� user �b�� : %s",muser.userid);
         muser.userid[0] = '\0';
         setuserid(unum, muser.userid);
         substitute_record(fn_passwd, &muser, sizeof(muser), unum);
         kill++;
        }
        else
        {
         if (freg = fopen(regfile, "a"))
         {
          for (n = 0; field[n]; n++)
           fprintf(freg, "%s: %s\n", field[n], fdata[n]);
          fprintf(freg, "----\n");
          fclose(freg);
         }
        }
        break;

     �ڧ�wuju�j�j���q��b�����q�ۨӥΥά�....:P �ŧi����  */


      case 'n':

        move(b_lines - 2, 0);
        prints("�п�J�h�^�ӽЪ���]�A�� <enter> ����\n");
        if (!getdata(b_lines - 1, 0, "�h�^��]�G", buf, 60, DOECHO,0))
          buf[0] = 0;

        // �����ιw�]���z��....�ٱo�h���@��N���·�....yroj
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
        if( ans[0] && isdigit(ans[0]) ) // '0-6'
                strcpy(buf, ans);

        if (buf[0])
        {
          int i;
          fileheader mhdr;
          char title[128], buf1[80];
          FILE* fp;

          i = buf[0] - '0';
          if (i >= 0 && i < n)
            strcpy(buf, reason[i]);
          sprintf(genbuf, "[�h�^��]] ��%s", buf);

//         �H�W�������ιw�]���z��....�ٱo�h���@��N���·�....yroj

	  sethomepath(buf1, muser.userid);
          stampfile(buf1, &mhdr);
          strcpy(mhdr.owner, "����");
          strncpy(mhdr.title, "[���U����]", TTLEN);
          mhdr.savemode = 0;
          mhdr.filemode = 0;
          sethomedir(title, muser.userid);

          if (rec_add(title, &mhdr, sizeof(mhdr)) != -1)
          {
             fp = fopen(buf1, "w");
             fprintf(fp, "%s\n", genbuf);
             fclose(fp);
          }

          if (fout = fopen(logfile, "a"))
          {
            for (n = 0; field[n]; n++)
              fprintf(fout, "%s: %s\n", field[n], fdata[n]);
            n = time(NULL);
            fprintf(fout, "Date: %s\n", Cdate(&n));
            fprintf(fout, "Rejected: %s [%s]\n----\n", uid, buf);
            fclose(fout);
          }
          rej++;
          break;
        }
        move(10, 0);
        clrtobot();
        prints("�����h�^�����U�ӽЪ�");

      default:                  /* put back to regfile */

        if (freg = fopen(regfile, "a"))
        {
          for (n = 0; field[n]; n++)
            fprintf(freg, "%s: %s\n", field[n], fdata[n]);
          fprintf(freg, "----\n");
          fclose(freg);
        }
      }
    }
  }
  fclose(fn);
  unlink(fname);
  i = ok + rej + kill;
  return (0);
}

int m_register()
{
  FILE *fn;
  int x, y, wid, len;
  char ans[4];
  char genbuf[200];

  if ((fn = fopen(fn_register, "r")) == NULL)
  {
    pressanykey("�ثe�õL�s���U���");
    return 0;
  }

  stand_title("�f�֨ϥΪ̵��U���");
  y = 2;
  x = wid = 0;

  cRegisterList = 0;
  while (fgets(genbuf, STRLEN, fn) != NULL)
  {
    if (strncmp(genbuf, "uid: ", 5) == 0)
    {
      cRegisterList++;
      if(x > 64) continue;
      move(y++, x);
      outs(genbuf + 5);
      len = strlen(genbuf + 5);
      if (len > wid)
        wid = len;
      if (y >= t_lines - 3)
      {
        y = 2;
        x += wid + 2;
      }
    }
  }
  fclose(fn);
  getdata(b_lines - 1, 0, "�}�l�f�ֶ�(Y/N)�H[Y] ", ans, 3, LCECHO,"Y");
  if (ans[0] == 'y')
    scan_register_form(fn_register);

  return 0;
}

/*-------------------------------------------------------*/
/* class.c          ( FJU StarRiverBBS Ver 1.95 )        */
/*-------------------------------------------------------*/
/* target : For Class Boards                             */
/* create : 00/05/11                                     */
/* update : 00/05/11                                     */
/* author : skybinary.bbs@starriver.twbbs.org            */
/*-------------------------------------------------------*/

#include "bbs.h"

int
m_class()
{
  char bname[20];
  stand_title("�ݪO�]�w");
  make_blist();
  namecomplete(msg_bid, bname);
  if (!*bname)
    return 0;
  m_mod_class(bname);
}

int
m_mod_class(char *bname)
{
 boardheader bh;
 int bid;
 char buf[200];

  bid = getbnum(bname);
  if (rec_get(fn_board, &bh, sizeof(bh), bid) == -1)
  {
    pressanykey(err_bid);
    return -1;
  }

  sprintf(buf,"/home/bbs/boards/%s/.class",bh.brdname);
  if(!dashf(buf))
  {
   sprintf(buf,"touch /home/bbs/boards/%s/.class",bh.brdname);
   system(buf);
  }
  sprintf(buf,"/home/bbs/boards/%s/.class",bh.brdname);
//  vedit(buf,NA);
  outs(vedit(buf, NA) ? "��ʤ���" : "��s����", NA);
  return FULLUPDATE;
}

#if 0

/* Ptt */

extern int bad_user_id(char userid[]);
int
search_bad_id()
{
 userec user;
 char ch;
 int coun=0;
  FILE *fp1=fopen(".PASSWDS","r");
  char buf[100];
  clear();
  while( (fread( &user, sizeof(user), 1, fp1))>0 ) {
          coun ++;
          move(0,0);
          sprintf(buf,"�M��l��id\n�� [%d] �����\n",coun);
          outs(buf);
          refresh();
          if(bad_user_id(user.userid))
                {
                 u_data(&user, 1);
                 //uinfo_query(&user, 1, coun);
                 outs("[44m               ���@��[37m:�j�M�U�@��          [33m Q[37m: ���}                         [m");
                 ch=igetch();
                 if(ch=='q' || ch =='Q') return 0;
                 clear();
                }
    }
 fclose(fp1);
 return 0;
}


int
search_key_user()
{
 userec user;
 char ch;
 int coun=0;
  FILE *fp1=fopen("PASSWDS","r");
  char buf[100],key[22];
  if(!fp1)fp1=fopen(".PASSWDS","r");
  clear();
  getdata(0,0,"�п�J�ϥΪ�����r [�m�W|email|ID|�q��|�a�}]:",key,21, DOECHO,0);
  while( (fread( &user, sizeof(user), 1, fp1))>0 ) {
          coun ++;
          move(1,0);
          sprintf(buf,"�� [%d] �����\n",coun);
          outs(buf);
          refresh();
          if(
                strstr(user.userid,key)||
                strstr(user.realname,key)||
                strstr(user.username,key)||
                strstr(user.lasthost,key)||
                strstr(user.email,key)||
                strstr(user.address,key)||
                //strstr(user.justify,key))
                {

                 u_data(&user, 1);
                 //uinfo_query(&user, 1, coun);
                 outs(
"[44m [33m(s)�_��       ���@��[37m:�j�M�U�@��          [33m Q[37m: ���}                        [m ");
                 ch=igetch();
                 if(ch=='q' || ch =='Q') return 0;
                 if(ch == 's')
                 {
                   int xnum = dosearchuser(user.userid);
                   if(xnum)
                   {
                     substitute_record(fn_passwd, &user, sizeof(user), xnum);
                   }
                   else
                   {
                        pressanykey("���H���s�b,�L�k�_��!");
                   }
                 }
                 clear();
                 move(0,0);
                 outs("�п�J�ϥΪ�����r [�m�W|email|ID|�q��|�a�}]:");
                 outs(key);
                }
        }
 fclose(fp1);
 return 0;
}

int
va_m_mod_board(va_list pvar)
{
 char *fname;
 fname = va_arg(pvar,char *);
 return m_mod_board(fname);
}

#if 0
int
va_Security(va_list pvar)
{
  int x,y;
  char *sysopid,*userid;
  x = va_arg( pvar,int);
  y = va_arg( pvar,int);
  sysopid = va_arg( pvar,char *);
  userid = va_arg( pvar,char *);
  return Security(x,y,sysopid,userid);
}

int va_setperms(va_list pvar)
{
 unsigned int pbits;
 pbits = va_args(pvar, unsigned int);
 return setperms(pbits);
}
#endif

#endif
