#include "bbs.h"

int 
bingo()
{

 int place[5][5][3]={{{3,2,0},{3,6,0},{3,10,0},{3,14,0},{3,18,0}},
       		     {{5,2,0},{5,6,0},{5,10,0},{5,14,0},{5,18,0}},
  		     {{7,2,0},{7,6,0},{7,10,0},{7,14,0},{7,18,0}},
  		     {{9,2,0},{9,6,0},{9,10,0},{9,14,0},{9,18,0}},
  		     {{11,2,0},{11,6,0},{11,10,0},{11,14,0},{11,18,0}}};

 int account,bet,i=0,j=0,k=0,used[25]={0},ranrow,rancol,line=0,pp=0;
 char co[2];
 int save_pager;
 char m1[8];
 int money;
 int may=20;
 save_pager=currutmp->pager;
 currutmp->pager =2;
 setutmpmode(BINGO);
 
while(-1)
{
account=13;
for(i=0;i<25;i++)
used[i]=0;
for(i=0;i<5;i++)
for(j=0;j<5;j++)
place[i][j][2]=0;
i=0;j=0;k=0;
line=0;pp=0; 

 clear();
  do
    {
       getdata(1, 0,"�n�U�h�֩O(�W��5000)? �� Enter ���}>", m1, 6, 1, 0);
          money=atoi(m1);
             if(money<0) money=0;
               } while(money>5000);
                 if(!money) 
                 {
                 currutmp->pager = save_pager;
                 return 0;
                 }
                   if(money>cuser.money)
                     {
                        pressanykey("�A���{��������.. :)");
                           return 0;
                     }
 demoney(money);                            

 while(account>=0)
 {
 clear();
 prints("\n\n");
 j=0;
  for(i=0;i<=10;i++)
   {
    if(i%2==0)
    outs("   [1;34;40m����������������������[0m\n");
    else
    {
    outs("   [1;34;40m��");
    if(place[j][0][2])
    prints("[1;37;40m%2d",place[j][0][2]);
    else prints("[1;32m��");
    outs("[1;34;40m��");
    if(place[j][1][2])
    prints("[1;37;40m%2d",place[j][1][2]);
    else prints("[1;32m��");
    outs("[1;34;40m��");
    if(place[j][2][2])
    prints("[1;37;40m%2d",place[j][2][2]);
    else prints("[1;32m��");
    outs("[1;34;40m��");
    if(place[j][3][2])
    prints("[1;37;40m%2d",place[j][3][2]);
    else prints("[1;32m��");
    outs("[1;34;40m��");
    if(place[j][4][2])
    prints("[1;37;40m%2d",place[j][4][2]);
    else prints("[1;32m��");
    outs("[1;34;40m��[0m\n");
    j++;
    }
   }
prints("\n\n\n\n");   
prints("[1;37;44m�|���}�X�����X[0m\n");
   for(i=1;i<=25;i++)
   {
     pp+=3;
     if(used[i-1]==0)
     prints(" %2d",i);
   }
if(line==1 || account==1) break;

if(account>9) may=20;
else if(account==9) may=10;
else if(account==8) may=9;
else if(account==7) may=8;
else if(account==6) may=7;
else if(account==5) may=6;
else if(account==4) may=5;
else if(account==3) may=3;
else if(account==2) may=1;


 prints("\n�|��[1;33;41m %2d [0m�����|�i�q �U���q���i�o[1;37;44m %d [0m�� \n",account-1,may);
 getdata(20,0,"�п�J�z�����X : ",co,3,DOECHO,0);

 bet=atoi(co);
 if(bet<=0 || bet > 25 || used[bet-1]!=0) continue;
  used[bet-1]=1;
  ranrow=random();
  ranrow=ranrow%5;
  rancol=random();
  rancol=rancol%5;

  while(place[ranrow][rancol][2]!=0)
  {
     ranrow=random();
      ranrow=ranrow%5;
        rancol=random();
        rancol=rancol%5;
  }
  place[ranrow][rancol][2]=bet;  
  account--;
  
 for(i=0;i<5;i++)
   {
    if (place[i][0][2]!=0 && place[i][1][2]!=0 && place[i][2][2]!=0 && place[i][3][2]!=0 &&place[i][4][2]!=0 )
    {
      line=1;
    }  
   }   
 for(i=0;i<5;i++)
  {
   if(place[0][i][2]!=0 &&place[1][i][2]!=0 &&place[2][i][2]!=0 &&place[3][i][2]!=0 &&place[4][i][2]!=0 )
   {
   line=1;
   }
  }

if(place[0][0][2]!=0 && place[1][1][2]!=0 && place[3][3][2]!=0 && place[4][4][2]!=0 && place[2][2][2]!=0)
line=1;
if(place[0][4][2]!=0 && place[1][3][2]!=0 && place[2][2][2]!=0 && place[3][2][2]!=0 && place[0][4][2]!=0)
line=1;

 }
 
if(line==1)
{
prints("\n���ߧA...Ĺ�F[1;33;41m %d [0m�� ",(money*may)); 
inmoney((money*may)+money);
//game_log(BINGO," �ȤF %d �� ",(money*may));
}
else 
{
prints("\n�B�𤣨�...�A�Ӥ@�L�a!!");
//game_log(BINGO," �鱼�F  ");
}
 pressanykey(NULL);
} 
 currutmp->pager=save_pager;
 return 0;
}       
  
