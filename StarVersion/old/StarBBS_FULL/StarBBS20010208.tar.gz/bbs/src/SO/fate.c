/* ghill : ����T�� ve �ק糧�{�� */

#include "bbs.h"

#include <stdlib.h>
#include <netdb.h>
#include <sys/uio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>


#define SERVER_FATE     "www.big.com.tw"

#define CGI_FATE                "/wkluck/wkluck.asp"

#define REFER_FATE      "http://www.big.com.tw/wkluck"

#define WEBPORT         80
#define PARA                    "Connection: Keep-Alive\nUser-Agent: Mozilla/4.5b1 [en] (X11; I; FreeBSD 2.2.7-STABLE i386)\nContent-type: application/x-www-form-urlencoded\nAccept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, image/png, */*\nAccept-Encoding: gzip\nAccept-Language: en\nAccept-Charset: iso-8859-1,*,utf-8\n"

#define msg_sure_ny "\n�z�T�w��(Y/n):"
#define cuser cuser
#define vmsg(s) { pressanykey(s); }
#define outz(s) prints("%s\n",s)
#define vget(a,b,c,d,e,f) getdata(a,b,c,d,e,f,NULL)
enum
{STRIP_AL,ONLY_COLO,NO_RELOA};

int tdplay()
{
        char genbuf[200],fpath[200],ans[3],LOG_FATE[200];
        FILE *fp1,*fp2;
        int i,k=0,flagin=0;
        sprintf(LOG_FATE,"/home/bbs/home/%c/%s/fate.log",
		cuser.userid[0], cuser.userid);
        fp1=fopen(LOG_FATE,"r");
        setuserfile(fpath,"fatelog");
        fp2=fopen(fpath,"w");

        fscanf(fp1,"%s",genbuf);
        while(!strstr(genbuf,"td"))
        {
                memset(genbuf, 0, sizeof(genbuf));
                fscanf(fp1,"%s",genbuf);
        }

        while(!feof(fp1))
        {
                for(i=0;i<200;i++)
                {
                        if(flagin==1)
                        {
                                if(genbuf[i]=='<') flagin=0;
                                else fputc(genbuf[i],fp2);
                        }
                        else if(flagin==0)
                        {
if(((genbuf[i-1]=='<' || genbuf[i+2]=='>') && genbuf[i]=='l' && genbuf[i+1]=='i') || genbuf[i]=='P' ||(genbuf[i]=='8' && genbuf[i+1]=='0') || genbuf[i]=='b')
fputc('\n',fp2);
if(genbuf[i]=='r' && genbuf[i+1]=='e' && genbuf[i+2]=='d')
fputc(' ',fp2);
}
if(genbuf[i]=='u' && genbuf[i+1]=='l')
k++;
if(k==6) break;
if(genbuf[i]=='>') flagin=1;
}
memset(genbuf, 0, sizeof(genbuf));
                fscanf(fp1,"%s",genbuf);
        }
        fclose(fp1);
        fclose(fp2);
        more(fpath,YEA);
        getdata(b_lines, 0, "�H�^�H�c�H [y/N]",ans, 3, LCECHO, 0);
        unlink(LOG_FATE);
        if(ans[0]=='Y' || ans[0]=='y')
        {
                fileheader mymail;
                char title[128], buf[80];
                sethomepath(buf, cuser.userid);
                stampfile(buf, &mymail);
                mymail.savemode = '\0';        /* hold-mail flag */
                mymail.filemode = FILE_READ;
                strcpy(mymail.owner, "[�P�e�]��]");
                strcpy(mymail.title, "�P�y�B�լd�ߵ��G");
                sethomedir(title, cuser.userid);
                rec_add(title, &mymail, sizeof(mymail));
                f_mv(fpath, buf);
        }
        else
        {
                unlink(LOG_FATE);
                unlink(fpath);
        }
        return 0;
}

//void
int
fate()
{
        int sockfd;
        char Month[3],Day[2],Sex[5],name[16],LOG_FATE[200];
        char Year[6],Blood[10],ans[3],buf1[50],buf2[50];
        char trn[512], result[1024], sendform[512];
        struct sockaddr_in serv_addr;
        struct hostent *hp;

#if 0
        memset(trn, 0, 512);
        memset(sendform, 0, 512);
        memset(result, 0, 1024);
        memset(Year, 0, 4);
        memset(Month, 0, 2);
        memset(Day, 0, 2);
        memset(Blood,0,2);
        memset(Sex,0,2);
        memset(name,0,16);
#endif

        clear();
        stand_title("�P�y�B�լd�ߵ{��");
        show_file("game/fate",1,6,ONLY_COLOR);
        move(8,4);
        prints("�п�J�z���m�W:");
        move(10,4);
        prints("�п�J�z���ʧO 1)�k 2)�k:");
        move(12,4);
        prints("�п�J�z���嫬 1)�� 2)�� 3)�� 4)�Ϣ�:");
        move(14,4);
        prints("�п�J�z���褸�X�ͦ~(EX:1980):");
        move(15,22);
        prints("��(EX:11):");
        move(16,22);
        prints("��(EX:07):");
        if ((!vget(8, 19, "", name, 17, DOECHO))) return;
        while (atoi(Sex) <1 || atoi(Sex) >2)
        vget(10, 29, "", Sex, 2, DOECHO);
        while (atoi(Blood) < 1 || atoi(Blood) >4)
        vget(12, 41, "", Blood, 2, DOECHO);

        vget(14, 34, "", Year, 5, DOECHO);
        if(strlen(Year) < 4)
        {
        pressanykey("�Ѱ� �A %d �~�ͪ��ܡH�H",atoi(Year));
        return;
        }
        vget(15, 34, "", Month, 3, DOECHO);
        if(atoi(Month) < 1 || atoi(Month) > 12)
        {
        pressanykey("�� %d ��ͪ��H�� �H�H",atoi(Month));
        return;
        }
        vget(16, 34, "", Day, 3, DOECHO);
        if(atoi(Day) <1 || atoi(Day) >31)
        {
        pressanykey("�� %d ��ͪ��H�� �H�H",atoi(Day));
        return;
        }
        if(atoi(Sex) == 1)
        strcpy(buf1,"�ŭ�");
        else if(atoi(Sex) == 2)
        strcpy(buf1,"���f");
        if(atoi(Blood) == 1)
        strcpy(buf2,"�ݫ�");
        else if (atoi(Blood) == 2)
        strcpy(buf2,"�ϫ�");
        else if (atoi(Blood) == 3)
        strcpy(buf2,"�Ы�");
        else if (atoi(Blood) == 4)
        strcpy(buf2,"�ϢЫ�");

        move(7,0);
        clrtobot();
        move(8,4);prints("�z���m�W:%s",name);
        //move(10,4);prints("�z���ʧO:%s",SexWord[atoi(Sex)-1]);
        //move(12,4);prints("�z���嫬:%s",BloodWord[atoi(Blood)-1]);
        move(10,4);
        prints("�z���ʧO:%s",buf1);
        move(12,4);
        prints("�z���嫬:%s",buf2);

        move(14,4);prints("�z���ͤ�:%s�~%s��%s��\n",Year,Month,Day);
        /*if (answer(msg_sure_ny) != 'y')
        {
                vmsg("���d��");
                return;
        }*/

        getdata(b_lines - 1,0,"�z�T�w�� [y/N]�H",ans,3,LCECHO);
        if (ans[0] != 'y' && ans[0] != 'Y')
        {
        pressanykey("���d��");
        return;
        }

        sprintf(LOG_FATE,"/home/bbs/home/%c/%s/fate.log",
		cuser.userid[0], cuser.userid);
        sprintf(trn,"name=%s&sex=%s&blood=%s&year=%s&month=%s&day=%s",
                                                name,Sex,Blood,Year,Month,Day);

        sprintf(sendform, "POST %s HTTP/1.0\nReferer: %s\n%sContent-length:%d\n\n%s",
        CGI_FATE, REFER_FATE, PARA, strlen(trn), trn);

        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd < 0)
                return;

        memset((char *)&serv_addr, 0, sizeof(serv_addr));
        serv_addr.sin_family = AF_INET;

        if ((hp = gethostbyname(SERVER_FATE)) == NULL)
                return;

        memcpy(&serv_addr.sin_addr, hp->h_addr, hp->h_length);

        serv_addr.sin_port = htons(WEBPORT);

        if (connect(sockfd, (struct sockaddr *) &serv_addr, sizeof serv_addr))
        {
                sprintf(result,"�L�k�s�u�A�d�ߥ���\n");
                f_cat(LOG_FATE, result);
                vmsg("�L�k�P���A�����o�s���A�d�ߥ���");
                return;
        }
        else
        {
                outz("���A���w�g�s���W�A�еy��");
                refresh();
        }

        write(sockfd, sendform, strlen(sendform));
        shutdown(sockfd, 1);

        while (read(sockfd, result, sizeof(result)) > 0)
        {
                f_cat(LOG_FATE, result);
                memset(result, 0, sizeof(result));
        }

        close(sockfd);
        tdplay();
        return;
}



