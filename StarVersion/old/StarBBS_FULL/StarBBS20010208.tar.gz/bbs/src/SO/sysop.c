/*-------------------------------------------------------*/
/* sysop.c      (FJU StarRiver BBS Ver 0.08 )            */
/*-------------------------------------------------------*/
/* target : admin use                                    */
/* create : 99/10/11                                     */
/* update : 99/10/11                                     */
/*-------------------------------------------------------*/

#include "bbs.h"

/* -------------------------------------------- */
/* �]�w�t���ɮ�                                 */
/* -------------------------------------------- */

int
x_reg()   /* �ѨM�L�k�{�� */
{
    if (dashf("register.new.tmp"))
    {
    system("cat register.new.tmp>>register.new");
    system("rm register.new.tmp");
    pressanykey("�˦n�F�A�U���p���I�աI");
    }
    return FULLUPDATE;
}

/* ---------------------------------------------------- */
/* �s�\��:���G���                                      */
/* ---------------------------------------------------- */

int system_note()
{
  static char *fn_sys_tmp = "log/sys.tmp";
  static char *fn_sys_dat = "log/sys.dat";
  static char *fn_sys_ans;
  int total, i, collect, len, ch;
  struct stat st;
  char buf[256], buf2[80];
  int fd, fx;
  FILE *fp, *foo;
  struct systemdata
  {
    time_t date;
    char userid[IDLEN + 1];
    char username[19];
    char buf[6][40];
    char title[10];
    int color;
  };
  struct systemdata mysys;
  setutmpmode(MAILALL);
  do
  {
    mysys.buf[0][0] = mysys.buf[1][0] = mysys.buf[2][0] = '\0';
    clear();
    move(12,0);
    prints("�N�q��� 1)�t�� 2)�s�� 3)���� 4) �ۦ��J [q]");
    ch=egetch();
     switch(ch)
     {
       case '1':
         fn_sys_ans = "m2/2";
         sprintf(mysys.title,"�t�Τ��i");
         mysys.color = 2;
         break;
       case '2':
         fn_sys_ans = "m2/3";
         sprintf(mysys.title,"�s������");
         mysys.color = 3;
         break;
       case '3':
         fn_sys_ans = "m2/4";
         sprintf(mysys.title,"���ȫŧi");
         mysys.color = 6;
         break;
       case '4':
         fn_sys_ans = "m2/5";
         getdata(14, 0,":", mysys.title, 9, DOECHO,0);
         mysys.color = 5;
         break;
       default :
         pressanykey("���K�X���i");
         return 0;
     }
    move(14,0);
    move(14,0);
    outs("�Яd�� (�ܦh����)�A��[Enter]����");
    for (i = 0; (i < 6) &&
      getdata(15 + i, 0, "�G", mysys.buf[i], 33, DOECHO,0); i++);
    getdata(b_lines - 1, 0, "(S)�x�s (E)���s�ӹL (Q)�����H[S] ", buf, 3, LCECHO,"S");

    if (buf[0] == 'q' || i == 0 && *buf != 'e')
      return;
  } while (buf[0] == 'e');
  strcpy(mysys.userid, cuser.userid);
  strncpy(mysys.username, cuser.username, 18);
  mysys.username[18] = '\0';
  time(&(mysys.date));

  /* begin load file */

  if ((foo = fopen(BBSHOME"/.sys", "a")) == NULL)
    return;

  if ((fp = fopen(fn_sys_ans, "w")) == NULL)
    return;

  if ((fx = open(fn_sys_tmp, O_WRONLY | O_CREAT, 0644)) <= 0)
    return;

  if ((fd = open(fn_sys_dat, O_RDONLY)) == -1)
  {
    total = 1;
  }
  else if (fstat(fd, &st) != -1)
  {
    total = st.st_size / sizeof(struct systemdata) + 1;
    if (total > 1)
      total = 1;
  }
  collect = 1;
  while (total)
  {
    sprintf(buf, "[1;37m[44m���� [32m%-10.10s[37;44m",mysys.title);
    len = strlen(buf);
    strcat(buf," [37m" + (len&1));

    for (i = len >> 1; i < 23; i++)
      strcat(buf, "��");
    sprintf(buf2, "��[37m����[m\n");
    strcat(buf, buf2);
    fputs(buf, fp);

    if (collect)
      fputs(buf, foo);

    sprintf(buf,"[3%d;1m%-34.34s[m\n[3%d;1m%-34.34s[m\n[3%d;1m%-34.34s[m\n",
    mysys.color,mysys.buf[0],mysys.color,mysys.buf[1],mysys.color,mysys.buf[2]);
    fputs(buf, fp);
    sprintf(buf,"[3%d;1m%-40.40s[m\n[3%d;1m%-40.40s[m\n[3%d;1m%-40.40s[m\n",
    mysys.color,mysys.buf[3],mysys.color,mysys.buf[4],mysys.color,mysys.buf[5]);
    fputs(buf, fp);

    sprintf(buf, "[1;37m�P�e����[32m%s[m\n[1;33m%-14.14s [37m�Ҥ��G�����i[m\n",
      mysys.userid, Cdate(&(mysys.date)));
     fputs(buf, fp);

    if (collect)
    {
      fputs(buf, foo);
      fclose(foo);
      collect = 0;
    }

    write(fx, &mysys, sizeof(mysys));

    if (--total)
      read(fd, (char *) &mysys, sizeof(mysys));
  }
  fclose(fp);
  close(fd);
  close(fx);
  f_mv(fn_sys_tmp, fn_sys_dat);
  more(fn_sys_ans,YEA);
}


/* ICQ */
int d_icq()
{
  FILE *inftmp;
  char buftmp[100];
  char typebuf[100];

  sethomefile(buftmp, currutmp->userid, "icq");

  if (inftmp = fopen(buftmp,"r"))
  {
    if (fscanf(inftmp,"%s", typebuf));
    fclose(inftmp);
  }

  move(b_lines-2, 0);
  prints("�ثe�z��ICQ���X:  %s ", typebuf);

  if (getdata(b_lines - 1, 0, "�п�JICQ���X�G", typebuf, 11, LCECHO, 0))
  {
    if (inftmp = fopen(buftmp,"w"))
    {
      fprintf(inftmp,"%s", typebuf);
      fclose(inftmp);
    }
  }
  return 0;
}

int
m_localicq()
{
  char uident[40];

  stand_title("ICQ�e�T��");
  usercomplete(msg_uid, uident);
  if (uident[0])
    m_icq(uident);
  return 0;
}

m_icq(user)
  char *user;
{
  char receiver[100];
  FILE *inftmp;
  char save_title[100];

  sprintf(save_title, "Message from %s of %s", BBSNAME, currutmp->userid);
  sethomefile(receiver, user, "icq");

  if (inftmp = fopen(receiver,"r"))
  {
    if (fscanf(inftmp,"%s", receiver))
    {
      sprintf(receiver, "%s@pager.mirabilis.com", receiver);
      do_send(receiver, save_title);
    }
    else
    {
      move(22, 0);
      outs("���H�èS���]ICQ��UIN, �ǰe����");
      pressanykey();
    }
    fclose(inftmp);
  }
  return 0;
}

int bldir()
{
 char buf[40];
 int pid, status;

 sprintf(buf,"/home/bbs/home/%c/%s",cuser.userid[0], cuser.userid);
 if (pid = fork())
   waitpid(pid, &status, 0);
 else
   execl("bin/buildir","buildir",buf,NULL);

 pressanykey("user�H�c���ا���!");
 return FULLUPDATE;
}

int rmbrdfeast()
{
 char buf[80],topic[20];
 int i,aborted;
 if(!getdata(b_lines-1, 0, "�п�J�ݪ��^��W�١G",topic,IDLEN+1,DOECHO,0))
  return FULLUPDATE;
 else if ((i = getbnum(topic)) <= 0)
  {
   pressanykey("���W�٨ä��s�b");
   return FULLUPDATE;
  }
 else
  {
   sprintf(buf,BBSHOME"/boards/%s/feast",topic);
   aborted = vedit(buf, NA);
   if (aborted == -1)
    {
     pressanykey(NULL);
     return FULLUPDATE;
    }
   else
    return FULLUPDATE;
  }
}

int
rpg_intro()
{
   more("etc/rpg.job",YEA);
   return 0;
}


int sysmoney()
{
 int sys,money;
 char buf[30];
 FILE *fp;
 char ans[10];
 time_t now =time(NULL);
 struct tm *ptime = localtime(&now);

 move(13,0);
 clrtobot();
 sys=money=0;
 sprintf(buf,"/home/bbs/game/system");

 if ((fp = fopen(buf, "r")) == NULL)
    return;

 fscanf(fp,"%d",&sys);
 fclose(fp);
 prints("�ثe�t�Φ� %8d ���¹�\n",sys);

 getdata(b_lines-1,0,"�п�J�z�n�����a�H����:",ans,8,DOECHO,0);
 money = atoi(ans);
 if(money == 0)
  return FULLUPDATE;
 demoney(money);
 prints("\n�{�b�t�Φ� %8d ���¹�\n",sys+money);

 fp=fopen(buf,"w");
 fprintf(fp,"%d",sys+money);
 fclose(fp);

 fp=fopen(BBSHOME"/log/give.log","a");
 fprintf(fp,"%s�b%d��%d��,���F%d���a�H��~~\n",
      cuser.userid,ptime->tm_mon+1,ptime->tm_mday,money);
 fclose(fp);

 pressanykey("���¥��{!!");
 return FULLUPDATE;
}

reload_cache()
{
  reload_ucache();
  reload_bcache();
//  reload_filmcache();
  system("/home/bbs/src/util/camera");
  reload_fcache();
  log_usies("CACHE", "SYSOP Reload ALL CACHE!");
}


/* ----------------------------------------------------- */
/* �U�زέp�ά�����T�C��                                */
/* ----------------------------------------------------- */

int
show_hint_message()
{
        struct timeval  timep;
        struct timezone timezp;
        int     i, j, msgNum;
        FILE    *hintp;
        char    msg[136];

        if (!(hintp = fopen(BBSHOME"/etc/hint", "r")))
          return 0;
        fgets(msg, 135, hintp);
        msgNum = atoi(msg);
        gettimeofday(&timep, &timezp);
        i = (int) timep.tv_sec%(msgNum + 1); /* �̷s���@�g���|�[�� */
        if (i == msgNum)
          i--;
        j = 0;

        while (j < i)
        {
          fgets(msg, 135, hintp);
          msg[1] = '\0';
          if (!strcmp(msg,"#"))
            j++;
        }
        move(12, 0);
        clrtobot();
        fgets(msg, 135, hintp);
        prints("[1;36m�P�e���������G [1;33m�z���D�ܡH[40;0m\n");
        prints("                   %s[0m", msg);
        fgets(msg, 135, hintp);
        prints("                   %s[0m", msg);
        pressanykey(NULL);
        fclose(hintp);
}

int
x_showload()
{
  char genbuf[80];
  double cpu_load[3];
  int i;
  getloadavg(cpu_load, 3);
  i = cpu_load[0];
  sprintf(genbuf, "[1;33m�ثe�t�έt��:[37m %.2f  %.2f  %.2f , %s",
  cpu_load[0], cpu_load[1],  cpu_load[2],i ?
  ( i-1 ? "[31m�t���M�I" : "[33m�t������") : "[32m�t�����`");
  if (i)
    system(BBSHOME"/bin/shutdownbbs &");
  move(b_lines - 1, 0);
  pressanykey(genbuf);
  return 0;
}

#ifdef LINUX
int getloadavg( double load[], int nelem ) {
  FILE *fp;
  int i, j=0;

  fp = fopen("/proc/loadavg", "r");
  if( fp == NULL ) {
    for( i=0; i<nelem; i++ )
      load[i] = 0.0;
    return -1;
  }

  for( i=0; i<nelem; i++ ) {
    j += fscanf(fp, "%lf", &load[i]);
  }

  return j;
}
#endif

int
m_sysop()
{
  FILE *fp;
  char genbuf[200];

  setutmpmode(MSYSOP);
  if (fp = fopen(BBSHOME"/etc/sysop", "r"))
  {
    int i, j;
    char *ptr;

    struct SYSOPLIST
    {
      char userid[IDLEN + 1];
      char duty[40];
    }         sysoplist[9];

    j = 0;
    while (fgets(genbuf, 128, fp))
    {
      if (ptr = strchr(genbuf, '\n'))
      {
        *ptr = '\0';
        ptr = genbuf;
        while (isalnum(*ptr))
           ptr++;
        if (*ptr)
        {
          *ptr = '\0';
          do
          {
            i = *++ptr;
          } while (i == ' ' || i == '\t');
          if (i)
          {
            strcpy(sysoplist[j].userid, genbuf);
            strcpy(sysoplist[j++].duty, ptr);
          }
        }
      }
    }


    move(12, 0);
    clrtobot();
    prints("%16s   %-18s�v�d����\n\n", "�s��", "���� ID"/*,msg_seperator*/);

    for (i = 0; i < j; i++)
    {
      prints("%15d.   [1;%dm%-16s%s[0m\n",
        i + 1, 31 + i % 7, sysoplist[i].userid, sysoplist[i].duty);
    }
    prints("%-14s0.   [1;%dm���}[0m", "", 31 + j % 7);
    getdata(b_lines - 1, 0, "                   �п�J�N�X[0]�G", genbuf,4, DOECHO,"1");
    i = genbuf[0] - '0' - 1;
    if (i >= 0 && i < j)
    {
      clear();
      do_send(sysoplist[i].userid, NULL);
    }
  }
  return 0;
}

int p_mood()
{
 char buf[5];
 getdata(b_lines ,0,"���Ѫ��߱��p��O�H", buf, 5,DOECHO,cuser.feeling);
 strncpy(cuser.feeling, buf, 4);
 strcpy(currutmp->feeling, cuser.feeling);
 substitute_record(fn_passwd, &cuser, sizeof(userec), usernum);
}

int p_color()
{
 char buf[2];
 int color;
 move(b_lines-1,0);
 prints("(1)[1;41m  [m(2)[1;42m  [m(3)[1;43m  [m(4)[1;44m  [m(5)[1;45m  [m(6)[1;46m  [m(7)[1;47m  [m(9)��Ӫ��m��");
 getdata(b_lines ,0,"���Ѫ��߱��C��p��O�H", buf, 2,LCECHO,"9");
 if((color=atol(buf)) >= 0)
 {
  if(color == 8)
   color = 9;
  cuser.color = color;
 }
 substitute_record(fn_passwd, &cuser, sizeof(userec), usernum);
}

