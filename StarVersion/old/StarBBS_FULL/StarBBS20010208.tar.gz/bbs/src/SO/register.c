/*-------------------------------------------------------*/
/* register.c   ( NTHU CS MapleBBS Ver 2.36 )            */
/*-------------------------------------------------------*/
/* target : user register routines                       */
/* create : 95/03/29                                     */
/* update : 95/12/15                                     */
/*-------------------------------------------------------*/


#include "bbs.h"

static int
getnewuserid()
{
  static char *fn_fresh = ".fresh";
  extern struct UCACHE *uidshm;
  userec utmp, zerorec;
  time_t clock;
  struct stat st;
  int fd, val, i;
  char genbuf[200];
  char genbuf2[200];

  memset(&zerorec, 0, sizeof(zerorec));
  clock = time(NULL);

  /* -------------------------------------- */
  /* Lazy method : ����M�w�g�M�����L���b�� */
  /* -------------------------------------- */

  if ((i = searchnewuser(0)) == 0)
  {

    /* ------------------------------- */
    /* �C 1 �Ӥp�ɡA�M�z user �b���@�� */
    /* ------------------------------- */

    if ((stat(fn_fresh, &st) == -1) || (st.st_mtime < clock - 3600))
    {
      if ((fd = open(fn_fresh, O_RDWR | O_CREAT, 0600)) == -1)
        return -1;
      write(fd, ctime(&clock), 25);
      close(fd);
      log_usies("CLEAN", "dated users");

      printf("�M��s�b����, �еy�ݤ���...\n\r");
      if ((fd = open(fn_passwd, O_RDWR | O_CREAT, 0600)) == -1)
        return -1;
      i = 0;  /* Ptt�ѨM�Ĥ@�ӱb���ѬO�Q����D */
      while (i < MAXUSERS)
      {
        i++;
        if (read(fd, &utmp, sizeof(userec)) != sizeof(userec))
          break;
        if(i==1) continue;
/*
woju
*/
        if ((val = compute_user_value(&utmp, clock)) < 0) {
           sprintf(genbuf, "#%d %-12s %15.15s %d %d %d",
             i, utmp.userid, ctime(&(utmp.lastlogin)) + 4,
             utmp.numlogins, utmp.numposts, val);
           if (val > -1 * 60 * 24 * 365)
           {
             log_usies("CLEAN", genbuf);
             sprintf(genbuf, "home/%c/%s", utmp.userid[0], utmp.userid);
             sprintf(genbuf2, "tmp/%s", utmp.userid);
             if (dashd(genbuf) && f_mv(genbuf, genbuf2))
                f_mv(genbuf, genbuf2);
             lseek(fd, (off_t)((i - 1) * sizeof(userec)), SEEK_SET);
             write(fd, &zerorec, sizeof(utmp));
           }
           else
              log_usies("DATED", genbuf);
        }
      }
      close(fd);
      time(&(uidshm->touchtime));
    }
  }
  if ((fd = open(fn_passwd, O_RDWR | O_CREAT, 0600)) == -1)
    return -1;
  flock(fd, LOCK_EX);

  i = searchnewuser(1);
  if ((i <= 0) || (i > MAXUSERS))
  {
    flock(fd, LOCK_UN);
    close(fd);
    if (more("etc/user_full", NA) == -1)
      printf("��p�A�ϥΪ̱b���w�g���F�A�L�k���U�s���b��\n\r");
    val = (st.st_mtime - clock + 3660) / 60;
    printf("�е��� %d ������A�դ@���A���A�n�B\n\r", val);
    sleep(2);
    exit(1);
  }

  sprintf(genbuf, "uid %d", i);
  log_usies("APPLY", genbuf);

  strcpy(zerorec.userid, str_new);
  zerorec.lastlogin = clock;
  if (lseek(fd, (off_t)(sizeof(zerorec) * (i - 1)), SEEK_SET) == -1)
  {
    flock(fd, LOCK_UN);
    close(fd);
    return -1;
  }
  write(fd, &zerorec, sizeof(zerorec));
  setuserid(i, zerorec.userid);
  flock(fd, LOCK_UN);
  close(fd);
  return i;
}


void
new_register()
{
  userec newuser;
  char passbuf[STRLEN],ans[2];
  int allocid, try;

  memset(&newuser, 0, sizeof(newuser));

  more("doc/register.txt",YEA);
  getdata(b_lines-1,0,"�z�@�N���u�H�W���W�d��?",ans,2,DOECHO,0);
  if(ans[0] == 'n' && 'N')
  {
      pressanykey("��p,�ڷQ�������A�X�z.....");
      oflush();
      exit(1);
  }
  more("etc/register", NA);
  film_out(REGISTER, 0);
  try = 0;
  while (1)
  {
    if (++try >= 6)
    {
      refresh();

      pressanykey("�z���տ��~����J�Ӧh�A�ФU���A�ӧa");
      oflush();
      exit(1);
    }
    move(13,0);clrtoeol();
    prints("�� �N�� [ID] �ܤ֭n��Ӧr�A���y�ĥμƦr�C");
    getdata(12, 0, msg_uid, newuser.userid, IDLEN + 1, DOECHO,0);

    if (bad_user_id(newuser.userid))
      outs("�L�k�����o�ӥN���A�Шϥέ^��r���A�åB���n�]�t�Ů�\n");
    else if (searchuser(newuser.userid))
      outs("���N���w�g���H�ϥ�\n");
    else
      break;
  }

    try = 0;
  while (1)
  {
    if (++try >= 6)
    {
      refresh();

      pressanykey("�z���տ��~����J�Ӧh�A�ФU���A�ӧa");
      oflush();
      exit(1);
      /*    return;      */
      /*longjmp(byebye, -1);*/
    }
    move(15,0);clrtoeol();
    prints("�� �K�X      �ܤ֭n�|�Ӧr�A���i�P [ID] �p�P�A���y�����p�g�C");
    if ((getdata(13, 0, "�г]�w�K�X�G", passbuf, PASSLEN, PASS,0) < 4) ||
      !strcmp(passbuf, newuser.userid))
    {
      pressanykey("�K�X��²��A���D�J�I�A�ܤ֭n 4 �Ӧr�A�Э��s��J");
      continue;
    }
    strncpy(newuser.passwd, passbuf, PASSLEN);
    getdata(14, 0, "���ˬd�K�X�G", passbuf, PASSLEN, PASS,0);
    if (strncmp(passbuf, newuser.passwd, PASSLEN))
    {
      outs("�K�X��J���~, �Э��s��J�K�X.\n");
      continue;
    }
    passbuf[8] = '\0';
    strncpy(newuser.passwd, genpasswd(passbuf), PASSLEN);
    break;
  }
  newuser.userlevel = PERM_DEFAULT;
  newuser.pager = 1;
  newuser.uflag = COLOR_FLAG | BRDSORT_FLAG | MOVIE_FLAG;
  newuser.firstlogin = newuser.lastlogin = time(NULL);
  newuser.money = 1000;
  newuser.starmoney= 5;
  newuser.color= 9;
  newuser.idletime= 300;
  newuser.exp= 0;
  newuser.habit = HABIT_NEWUSER;        /* user.habit */
  allocid = getnewuserid();
  if (allocid > MAXUSERS || allocid <= 0)
  {
    fprintf(stderr, "�����H�f�w�F���M�I\n");
    exit(1);
  }

  if (substitute_record(fn_passwd, &newuser, sizeof(userec), allocid) == -1)
  {
    fprintf(stderr, "�Ⱥ��F�A�A���I\n");
    exit(1);
  }
  setuserid(allocid, newuser.userid);
  if (!dosearchuser(newuser.userid))
  {
    fprintf(stderr, "�L�k�إ߱b��\n");
    exit(1);
  }
}

/* origin: SOB & Ptt              */
/* modify: wildcat/980909         */
/* �T�{user�O�_�q�L���U�B��ƥ��T */
check_register()
{
  char *ptr;
  char genbuf[200],buf[100];
  char realname[20],email[50],address[50];
  FILE *fp;

  if(!strcmp(cuser.userid, STR_GUEST))
   return FULLUPDATE;

  stand_title("�иԲӶ�g�ӤH���");

  while (strlen(cuser.username) < 2)
    getdata(2, 0, "�︹�ʺ١G", cuser.username, 24, DOECHO,0);
  strcpy(currutmp->username, cuser.username);

  for (ptr = cuser.username; *ptr; ptr++)
  {
    if (*ptr == 9)              /* TAB convert */
      strcpy(ptr, " ");
  }

  sethomepath(buf, cuser.userid);
  strcat(buf,"/.realname");
  if(fp = fopen(buf,"r"))
  {
    fscanf(fp,"%s",realname);
    fclose(fp);
  }
  while (strlen(realname) < 4)
    getdata(4, 0, "�u��m�W�G", realname, 20, DOECHO,0);

  sethomepath(buf, cuser.userid);
  strcat(buf,"/.realname");
  if(fp = fopen(buf,"w"))
  {
    fprintf(fp,"%s",realname);
    fclose(fp);
  }

  while (!cuser.month || !cuser.day || !cuser.year)
  {
      sprintf(genbuf, "%02i/%02i/%02i",
      cuser.year,cuser.month, cuser.day);
      getdata(6, 0, "�X�ͦ~�� �褸 19", buf, 3, DOECHO,0);
      cuser.year = (buf[0] - '0') * 10 + (buf[1] - '0');
      getdata(7, 0, "�X�ͤ��", buf, 3, DOECHO,0);
      cuser.month = (buf[0] - '0') * 10 + (buf[1] - '0');
      getdata(8, 0, "�X�ͤ��", buf, 3, DOECHO,0);
      cuser.day = (buf[0] - '0') * 10 + (buf[1] - '0');
      if (cuser.month > 12 || cuser.month < 1 ||
        cuser.day > 31 || cuser.day < 1 || cuser.year > 90 || cuser.year < 40)
        continue;
      break;
    }

  sethomepath(buf, cuser.userid);
  strcat(buf,"/.address");
  if(fp = fopen(buf,"r"))
  {
    fscanf(fp,"%s",address);
    fclose(fp);
  }

  while (strlen(address) < 8)
    getdata(9, 0, "�p���a�}�G", address, 50, DOECHO,0);

  sethomepath(buf, cuser.userid);
  strcat(buf,"/.address");
  if(fp = fopen(buf,"w"))
  {
    fprintf(fp,"%s",address);
    fclose(fp);
  }


  while (cuser.sex > 7)
  {
    char buf[10];
    getdata(10, 0,
      "�ʧO (1)���� (2)�j�� (3)���} (4)���� (5)���� (6)���� (7)�Ӫ� (8)�q��",
      buf , 3, DOECHO, 0);
    if (buf[0] >= '1' && buf[0] <= '8')
      cuser.sex = buf[0] - '1';
  }

  sethomepath(buf, cuser.userid);
  strcat(buf,"/.email");
  if(fp = fopen(buf,"r"))
  {
    fscanf(fp,"%s",email);
    fclose(fp);
  }

  if (!strchr(email, '@'))
  {
    bell();
    move(t_lines - 4, 0);
    prints("\
�� ����������E-mail�{�ҡA���٬O�·бz�ж�g�u�ꪺ E-mail address�A\n\
   �榡�� [44muser@domain_name[0m �� [44muser@\\[ip_number\\][0m�C\n\n\
�� �p�G�z�u���S�� E-mail�A�Ъ����� [return] �Y�i�C");

    do
    {
      getdata(12, 0, "�q�l�H�c�G", email, 50, DOECHO,0);
      if (!email[0])
        sprintf(email, "%s%s", cuser.userid, str_mail_address);
    } while (!strchr(email, '@'));
  sethomepath(buf, cuser.userid);
  strcat(buf,"/.email");
  if(fp = fopen(buf,"w"))
  {
    fprintf(fp,"%s",email);
    fclose(fp);
  }
#ifdef  EMAIL_JUSTIFY
  mail_justify(cuser);
#endif
  }

  cuser.userlevel |= PERM_DEFAULT;
  if (!HAS_PERM(PERM_SYSOP) && !(cuser.userlevel & PERM_LOGINOK))
  {
    /* �^�йL�����{�ҫH��A�δ��g E-mail post �L */

    setuserfile(genbuf, "email");
    if (dashf(genbuf))
      cuser.userlevel |= ( PERM_POST );

#ifdef  STRICT
    else
    {
      cuser.userlevel &= ~PERM_POST;
      more("etc/justify", YEA);
    }
#endif
  substitute_record(fn_passwd, &cuser, sizeof(userec), usernum);
/* wildcat 981218 */
  clear();
  update_data();
  u_register();
  DL_func("SO/new_user.so:u_habit");
  }
  if (HAS_PERM(PERM_DENYPOST) && !HAS_PERM(PERM_PURPLE))
    cuser.userlevel &= ~PERM_POST;
  substitute_record(fn_passwd, &cuser, sizeof(userec), usernum);
}

/* --------------------------------------------- */
/* �ϥΪ̶�g���U����                            */
/* --------------------------------------------- */

static void
getfield(line, info, desc, buf, len)
  int line, len;
  char *info, *desc, *buf;
{
  char prompt[STRLEN];
  char genbuf[200];

  sprintf(genbuf, "����]�w�G%-30.30s (%s)", buf, info);
  move(line, 2);
  outs(genbuf);
  sprintf(prompt, "%s�G", desc);
  if (getdata(line + 1, 2, prompt, genbuf, len, DOECHO,0))
    strcpy(buf, genbuf);
  move(line, 2);
  prints("%s�G%s", desc, buf);
  clrtoeol();
}


int
u_register()
{
  char rname[20], addr[50],buf[100];
  char phone[20], career[40],email[50],birthday[9],sex_is[2],year,mon,day;
  char ans[3], *ptr;
  FILE *fn;
  time_t now;
  char genbuf[200];
  FILE *fp;

  if (cuser.userlevel & PERM_LOGINOK)
  {
    pressanykey("�z�������T�{�w�g�����A���ݶ�g�ӽЪ�");
    return XEASY;
  }

  if (fn = fopen(fn_register, "r"))
  {
    while (fgets(genbuf, STRLEN, fn))
    {
      if (ptr = strchr(genbuf, '\n'))
        *ptr = '\0';
      if (strncmp(genbuf, "uid: ", 5) == 0 &&
        strcmp(genbuf + 5, cuser.userid) == 0)
      {
        fclose(fn);
        pressanykey("�z�����U�ӽг�|�b�B�z���A�Э@�ߵ���");
        return XEASY;
      }
    }
    fclose(fn);
  }
/*
  getdata(b_lines - 1, 0, "�z�O�_�n��g���U���(Y/N)�H[N] ", ans, 3,LCECHO,0);
  if (ans[0] != 'y')
    return FULLUPDATE;
*/
  move(2, 0);
  clrtobot();
//  strcpy(rname, cuser.realname);
  sethomepath(buf, cuser.userid);
  strcat(buf,"/.realname");
  if(fp = fopen(buf,"r"))
  {
    fscanf(fp,"%s",rname);
    fclose(fp);
  }

//  strcpy(addr, cuser.address);
  sethomepath(buf, cuser.userid);
  strcat(buf,"/.address");
  if(fp = fopen(buf,"r"))
  {
    fscanf(fp,"%s",addr);
    fclose(fp);
  }

//  strcpy(email, cuser.email);
  sethomepath(buf, cuser.userid);
  strcat(buf,"/.email");
  if(fp = fopen(buf,"r"))
  {
    fscanf(fp,"%s",email);
    fclose(fp);
  }

  sprintf(birthday, "%02i/%02i/%02i",
        cuser.year, cuser.month, cuser.day);
  sex_is[0]=(cuser.sex >= '0' && cuser.sex <= '7') ?
    cuser.sex+'1': '8';sex_is[1]=0;
  career[0] = phone[0] = '\0';
  while (1)
  {
    clear();
    move(3, 0);
    prints("%s[1;32m�i[m%s[1;32m�j[m �z�n�A�оڹ��g�H�U�����:",
      cuser.userid, cuser.username);
    getfield(6, "�нT���g����m�W", "�u��m�W", rname, 20);
    getfield(8, "�Ǯըt�ũγ��¾��", "�A�ȳ��", career, 40);
    getfield(10, "�]�A��ǩΪ��P���X", "�ثe���}", addr, 50);
    getfield(12, "�]�A���~�����ϰ�X", "�s���q��", phone, 20);
    while (1)
    {
    int len;
    getfield(14, " 19xx/��/�� �p: 77/12/01","�ͤ�",birthday,9);
    len = strlen(birthday);
    if(!len)
       {
         sprintf(birthday, "%02i/%02i/%02i",
         cuser.year, cuser.month, cuser.day);
         year=cuser.year;
         mon=cuser.month;
         day=cuser.day;
       }
    else if (len==8)
       {
        year  = (birthday[0] - '0') * 10 + (birthday[1] - '0');
        mon = (birthday[3] - '0') * 10 + (birthday[4] - '0');
        day   = (birthday[6] - '0') * 10 + (birthday[7] - '0');
       }
    else
        continue;
    if (mon > 12 || mon < 1 || day > 31 || day < 1 || year > 90 || year < 40)
        continue;
    break;
    }
    getfield(16,"1.���� 2.�j�� 3.���} 4.����","�ʧO",sex_is,2);
    getfield(18, "�����{�ҥ�", "E-Mail Address", email, 50);

    getdata(b_lines - 1, 0, "�H�W��ƬO�_���T(Y/N)�H(Q)�������U [N] ",
      ans, 3, LCECHO,0);
    if (ans[0] == 'q')
      return 0;
    if (ans[0] == 'y')
      break;
  }
  sethomepath(buf, cuser.userid);
  strcat(buf,"/.realname");
  if(fp = fopen(buf,"w"))
  {
    fprintf(fp,"%s",rname);
    fclose(fp);
  }
  sethomepath(buf, cuser.userid);
  strcat(buf,"/.email");
  if(fp = fopen(buf,"w"))
  {
    fprintf(fp,"%s",email);
    fclose(fp);
  }

//  strcpy(cuser.address, addr);

  sethomepath(buf, cuser.userid);
  strcat(buf,"/.address");
  if(fp = fopen(buf,"w"))
  {
    fprintf(fp,"%s",addr);
    fclose(fp);
  }

  cuser.sex= sex_is[0]-'1';
  cuser.month=mon;cuser.day=day;cuser.year=year;
  if (fn = fopen(fn_register, "a"))
  {
    now = time(NULL);
    str_trim(career);
    str_trim(addr);
    str_trim(phone);
    fprintf(fn, "num: %d, %s", usernum, ctime(&now));
    fprintf(fn, "uid: %s\n", cuser.userid);
    fprintf(fn, "name: %s\n", rname);
    fprintf(fn, "career: %s\n", career);
    fprintf(fn, "addr: %s\n", addr);
    fprintf(fn, "phone: %s\n", phone);
    fprintf(fn, "email: %s\n", email);
    fprintf(fn, "----\n");
    fclose(fn);
  }
  substitute_record(fn_passwd, &cuser, sizeof(userec), usernum);
   /* �O��*/
/*    clear();
    move(9,3);
prints("�̫�Post�@�g[1;32m�ۧڤ��Ф峹[m���j�a�a�A�i�D�j�a�ڨӰաC\
\n\n\n\n");
    pressanykey(NULL);
    brc_initial("Hi_All");
    set_board();
    do_post();*/
  return 0;
}

