/* Ptt bbs �W���q�l��  */
#include "bbs.h"
#define CHICKEN_PIC "etc/chickens"
#define CHICKENLOG  "etc/chicken"
#define NUM_KINDS   9                   /* ���h�ֺذʪ� */

chicken *mychicken = &cuser.mychicken;
int age;

char *cage[17]={
"�ϥ�","�g��","���~","�֦~","�C�K","�C�~","�C�~","���O","���~","���~","���~","���~","���~","�Ѧ~","�Ѧ~","������","�j��"};

char
*chicken_type[NUM_KINDS] = {"�p��","���֤k","�i�h","�j��","���s","���N",
                    "��","�����p�s","����"};

char
*chicken_food[NUM_KINDS] = {"���}��","��i�p��","���ƫK��","������","����",
                    "�p��","�߻氮","�p���氮","�_��"};
int
food_price[NUM_KINDS]= { 4, 6, 8, 10, 12, 12, 5, 6 ,5};

char
*tech_type[16] = {"�s�����","�R�ߩG","�X���L","�۩G","�w���G","�W�j�N",
                  "�����N","�����N","�a�P","�߲���",
                  "�v���N","���y�N","�ʷP���i","�_���N","�����N","�a�ʳN"};
enum
{
  OO, FOOD, WEIGHT, CLEAN, RUN, ATTACK, BOOK, HAPPY, SATIS,
  TEMPERAMENT, TIREDSTRONG, SICK, HP_MAX, MM_MAX
};
int
time_change[NUM_KINDS][14] =
/*�ɫ~ ���� �魫 ���b �ӱ� �����O ���� �ּ� ���N ��� �h�� �f�� ���� ���k*/
{
/*��*/
  { 1,  1,  30,    3,   8,    3,    3,  40,  9,   1,   7,   3,   30,   1},
/*���֤k*/
  { 1,  1, 110,    0,   4,    7,   41,  20,  9,  25,  25,   7,  110,  15},
/*�i�h*/
  { 1,  1, 200,    5,   4,   10,   33,  20, 15,  10,  27,   1,  200,   9},
/*�j��*/
  { 1,  1,  10,    5,   8,    1,    1,   5,  3,   1,   4,   1,   10,  30},
/*���s*/
  { 1,  1,1000,    9,   1,   13,    4,  12,  3,   1, 200,   1, 1000,   3},
/*���N*/
  { 1,  1,  90,    7,  10,    7,    4,  12,  3,  30,  20,   5,   90,  20},
/*��*/
  { 1,  1,  30,    5,   5,    6,    4,   8,  3,  15,   7,   4,   30,  21},
/*�����p�s*/
  { 1,  1, 100,    9,   7,    7,   20,  50, 10,   8,  24,   4,  100,   9},
/*��*/
  { 1,  1,  45,    8,   7,    9,    3,  40, 20,   3,   9,   5,   45,   1},
};
/*
int
reload_chicken()
{
      get_record(fn_passwd, &xuser, sizeof(xuser), usernum);
      memcpy(mychicken, &xuser.mychicken, sizeof(chicken));
      if(!mychicken->name[0]) return 0;
      else return 1;
}
*/
int
new_chicken()
{
  char buf[100];
  int  egg_price[NUM_KINDS]= {5,25,30,40,80,50,15,35,17} ,price;
  time_t now;
  clear();
  move(2,0);
  outs("�w���[�{ 3m��7;44m Ptt�d������ 3;40m��m.. �ثe�J���G\n"
  "(1)�p�� $5   (2)���֤k $25   (3)�i�h    $30  (4)�j�� $40  (5)���s $80\n"
  "(6)���N $50  (7)��     $15   (8)�����p�s$35  (9)���� $17  [0]�ۤv $0\n");
  getdata_str(5, 0, "�п�ܧA�n�i���ʪ��G",buf,3, LCECHO,"0");

  buf[0] -= '1';
  if(buf[0]<0 || buf[0]>NUM_KINDS-1) return 0;

  mychicken->type = buf[0];

  reload_money();
  price = egg_price[mychicken->type];
  if(cuser.money < price)
        {
          outs("\n �������R�J�J,�J�J�n %d ��",price);
          refresh();
          return 0;
        }
  demoney(price);
  while(strlen(mychicken->name)<3)
    getdata(6, 0, "���e���Ӧn�W�r�G", mychicken->name, 18, DOECHO);

  now = time(NULL);
  sprintf(buf,"1m%s m�i�F�@���s3m %s m�� 2m%sm  �� %s",cuser.userid,
          mychicken->name,chicken_type[mychicken->type],ctime(&now));
  log_file(CHICKENLOG,buf);
  mychicken->lastvisit = mychicken->birthday = now;
  mychicken->food   =   0;
  mychicken->weight = time_change[mychicken->type][WEIGHT]/3;
  mychicken->clean  =   0;
  mychicken->run    = time_change[mychicken->type][RUN];
  mychicken->attack = time_change[mychicken->type][ATTACK];
  mychicken->book   = time_change[mychicken->type][BOOK];
  mychicken->happy  = time_change[mychicken->type][HAPPY];
  mychicken->satis  = time_change[mychicken->type][SATIS];
  mychicken->temperament = time_change[mychicken->type][TEMPERAMENT];
  mychicken->tiredstrong = 0;
  mychicken->sick   =   0;
  mychicken->hp     = time_change[mychicken->type][WEIGHT];
  mychicken->hp_max = time_change[mychicken->type][WEIGHT];
  mychicken->mm     =   0;
  mychicken->mm_max =   0;
  return 1;
}

int
show_file(char *filename, int y, int lines, int mode)
{
 FILE *fp;
 char buf[256];

 if(y>=0) move(y,0);

 if((fp=fopen(filename,"r")))
  {
    while(fgets(buf,256,fp) && lines--) outs(Ptt_prints(buf,mode));
    fclose(fp);
  }
 else return 0;
 return 1;
}

void
show_chicken_data(chicken *thechicken)
{
 char buf[1024];
 struct tm *ptime;
 ptime = localtime(&thechicken->birthday);

 age = ((time(NULL) - thechicken->birthday)/ (60*60*24));
 thechicken->type %=NUM_KINDS;
 clear();
 showtitle("��tt�i����", BoardName);
 move(1,0);
 prints(" Name :3m%sm (2m%sm)%*s�ͤ�  :1m%2dm�~1m%2dm��1m%2dm�� (2m%s %d��m)\n"
        " ��O :3m%-7dm �k�O :3m%-7dm �����O:3m%-7dm �ӱ�  :3m%-7dm ���� :3m%-7dm \n"
        " �ּ� :3m%-7dm ���N :3m%-7dm �h��  :3m%-7dm ���  :3m%-7d m�魫 :3m%-5.2fm \n"
        " �f�� :3m%-7dm ���b :3m%-7dm ����  :3m%-7dm �j�ɤY:3m%-7dm �ī~ :3m%-7dm \n",
      thechicken->name,  chicken_type[thechicken->type],
      15- strlen(thechicken->name),"",
      ptime->tm_year, ptime->tm_mon+1, ptime->tm_mday, cage[age>16 ? 16 : age],
      age,
      thechicken->hp_max, thechicken->mm_max,
      thechicken->attack, thechicken->run , thechicken->book ,
      thechicken->happy , thechicken->satis, thechicken->tiredstrong,
      thechicken->temperament ,
      ((float)(thechicken->hp_max+(thechicken->weight/50))) / 100,
      thechicken->sick, thechicken->clean,  thechicken->food,
      thechicken->oo  ,  thechicken->medicine);

 sprintf(buf ,CHICKEN_PIC"/%c%d",thechicken->type + 'a',age > 16 ? 16 : age);
 show_file(buf, 5, -1, NO_RELOAD);

 sprintf(buf,"m[HP: %dm%d7m/3m%dm  MM: %dm%d7m/3m%dm]",
      thechicken->hp < thechicken->hp_max/3 ? 31 : 33,
      thechicken->hp, thechicken->hp_max,
      thechicken->mm < thechicken->mm_max/3 ? 31 : 33,
      thechicken->mm, thechicken->mm_max);

 move(5,112-strlen(buf));
 outs(buf);

 move(18,0);

 if(thechicken->sick) outs("�ͯf�F...");
 if(thechicken->sick > thechicken->hp / 5) outs(";31m���...�f��!!m");

 if(thechicken->clean  > 150) outs("1m�S��Sż��..m");
 else if(thechicken->clean  > 80) outs("���Iż..");
 else if(thechicken->clean  < 20) outs("2m�ܰ��b..m");

 if(thechicken->weight > thechicken->hp_max*4) outs("1m�ֹ����F!.m");
 else if(thechicken->weight > thechicken->hp_max*3) outs("2m���ʹ�..m");
 else if(thechicken->weight < (thechicken->hp_max / 4)) outs("1m�־j���F!..m");
 else if(thechicken->weight < (thechicken->hp_max / 2)) outs("�j�F..");

 if(thechicken->tiredstrong > thechicken->hp*1.7 ) outs("1m�ֱo���g�F...m");
 else if(thechicken->tiredstrong > thechicken->hp ) outs("�֤F..");
 else if(thechicken->tiredstrong < thechicken->hp/4) outs("2m��O����...m");

 if(thechicken->hp    < thechicken->hp_max/4) outs("1m��O�κ�..�a�a�@��..m");
 if(thechicken->happy  > 500 ) outs("2m�ܧּ�..m");
 else if(thechicken->happy  < 100 ) outs("���ּ�..");
 if(thechicken->satis  > 500 ) outs("2m�ܺ���..m");
 else if(thechicken->satis  < 50 ) outs("������..");

}

void
ch_eat()
{
 if(mychicken->food)
 {
  mychicken->weight += time_change[mychicken->type][WEIGHT] + mychicken->hp_max/5 ;
  mychicken->tiredstrong += time_change[mychicken->type][TIREDSTRONG]/2;
  mychicken->hp_max++;
  mychicken->happy += 5;
  mychicken->satis += 7;
  mychicken->food --;
  move(10,10);

  show_file(CHICKEN_PIC "/eat", 5, -1, NO_RELOAD);
  pressanykey();
 }
}

void
ch_clean()
{
 mychicken->clean =0;
 mychicken->tiredstrong += time_change[mychicken->type][TIREDSTRONG]/3;
 show_file(CHICKEN_PIC "/clean", 5, -1, NO_RELOAD);
 pressanykey();
}

void
ch_guess()
{
 char *guess[3]={"�ŤM","���Y","��"},me,ch,win,buf[50];

 mychicken->happy += time_change[mychicken->type][HAPPY]*1.5;
 mychicken->satis += time_change[mychicken->type][SATIS];
 mychicken->tiredstrong += time_change[mychicken->type][TIREDSTRONG];
 mychicken->attack += time_change[mychicken->type][ATTACK]/4;
 move(20,0);
 clrtobot();
 outs("�A�n�X[2m1m]3m�ŤMm(2m2m)3m���Ym(2m3m)3m��m:\n");
 me = igetch();
 me -= '1';
 if (me > 2 || me < 0) me =0;
 win = (int)(3.0 * rand()/(RAND_MAX+1.0)) - 1;
 ch  = (me + win + 3)%3;
 prints("%s:%s !      %s:%s !.....%s",
                cuser.userid,guess[me],mychicken->name,guess[ch],
                win==0 ? "����" : win<0 ? "�C..Ĺ�F :D!!" : "��..�ڿ�F :~");
 pressanykey();
}

void
ch_book()
{
 mychicken->book += time_change[mychicken->type][BOOK];
 mychicken->tiredstrong += time_change[mychicken->type][TIREDSTRONG];
 show_file(CHICKEN_PIC "/read", 5, -1, NO_RELOAD);
 pressanykey();
}

void
ch_kiss()
{
 mychicken->happy += time_change[mychicken->type][HAPPY];
 mychicken->satis += time_change[mychicken->type][SATIS];
 mychicken->tiredstrong += time_change[mychicken->type][TIREDSTRONG]/2;
 show_file(CHICKEN_PIC "/kiss", 5, -1, NO_RELOAD);
 pressanykey();
}

void
ch_hit()
{
 mychicken->attack += time_change[mychicken->type][ATTACK];
 mychicken->run += time_change[mychicken->type][RUN];
 mychicken->mm_max += time_change[mychicken->type][MM_MAX]/15;
 mychicken->weight -= mychicken->hp_max / 15 ;
 mychicken->hp -= (int)((float) time_change[mychicken->type][HP_MAX] *
                   rand()/(RAND_MAX+1.0)) / 2 + 1;

 if(mychicken->book>2) mychicken->book -= 2;
 if(mychicken->happy>2) mychicken->happy -= 2;
 if(mychicken->satis>2) mychicken->satis -= 2;
 mychicken->tiredstrong += time_change[mychicken->type][TIREDSTRONG];
 show_file(CHICKEN_PIC "/hit", 5, -1, NO_RELOAD);
 pressanykey();
}

void
ch_buyitem(int money,char *picture,int *item)
{
  int num=0;
  char buf[5];
  getdata_str(b_lines-1,0,"�n�R�h�֥��O:",buf,4,DOECHO,"5");
  num = atoi(buf);
  if(num<0) num=0;
  reload_money();
  if (cuser.money > money*num)
        {
          *item += num;
          demoney(money*num);
          show_file(picture, 5, -1, NO_RELOAD);
        }
  else
        {
          move(b_lines-1,0);
          clrtoeol();
          outs("�{������ !!!");
        }
  pressanykey();
}

void
ch_eatoo()
{
  if(mychicken->oo > 0)
        {
          mychicken->oo--;
          mychicken->tiredstrong = 0;
          if(mychicken->happy>5) mychicken->happy -= 5;
          show_file(CHICKEN_PIC "/oo", 5, -1, NO_RELOAD);
          pressanykey();
        }
}

void
ch_eatmedicine()
{
  if(mychicken->medicine > 0)
        {
          mychicken->medicine--;
          mychicken->sick = 0;
          if(mychicken->hp_max > 10) mychicken->hp_max -= 3;
          mychicken->hp = mychicken->hp_max;
          if(mychicken->happy>10) mychicken->happy -= 10;
          show_file(CHICKEN_PIC "/medicine", 5, -1, NO_RELOAD);
          pressanykey();
        }
}

void
ch_kill()
{
  char buf[100],ans[4];
  sprintf(buf,"�����o��%s�n�Q�@ 100 ��, �O�_�n����?(y/N)",
         chicken_type[mychicken->type]);
  getdata_str(23,0,buf,ans,3,DOECHO,"N");
  if(ans[0]=='y')
        {
          time_t now = time(NULL);
          demoney(100);
          more(CHICKEN_PIC "/deadth",YEA);
          sprintf(buf,"1m%s m�� 3m%sm2m %s m�_�F �� %s",cuser.userid,
             mychicken->name,chicken_type[mychicken->type],ctime(&now));
          log_file(CHICKENLOG,buf);
          mychicken->name[0]=0;
        }
}


int
ch_sell()
{
  int isdeadth();
  int money = age*food_price[mychicken->type]*5            /* �̿� */
               +(mychicken->hp_max*30+mychicken->weight)
                /time_change[mychicken->type][HP_MAX]
                                                          /* �o�� */
               -mychicken->sick;                          /* �f�� */
  char buf[100],ans[4];
  time_t now = time(NULL);
  if (money<0) money =0 ;
  if(age < 5)
        {
         outs("\n �٥����~�����");
         pressanykey();
         return 0;
        }
  sprintf(buf,"�o��%d��%s�i�H�� %d ��, �O�_�n��?(y/N)",age,chicken_type[mychicken->type],money);

  getdata_str(23,0,buf,ans,3,DOECHO,"N");
  if(ans[0]=='y')
        {
          sprintf(buf,"1m%sm �� 3m%sm 2m%sm �� 6m%dm ��F �� %s",cuser.userid,
          mychicken->name,chicken_type[mychicken->type],money,ctime(&now));
          log_file(CHICKENLOG,buf);
          mychicken->name[0]=0;
          more(CHICKEN_PIC "/sell",YEA);
          inmoney(money);
          return 1;
        }
 return 0;
}
void
geting_old(int *hp, int diff)
{
  diff /= 60*6;
  while(diff--)
        *hp *= 0.9 ;
}

void
time_diff(chicken *thechicken)             /* �̮ɶ��ܰʪ���� */
{
 int diff;
 int theage = ((time(NULL) - thechicken->birthday)/ (60*60*24));

 diff = (time(NULL)-thechicken->lastvisit)/60;

 if((diff) < 1) return;

 if(theage > 13 ) /* �Ѧ� */
          geting_old(&thechicken->hp_max, diff);

 thechicken->lastvisit = time(NULL);
 thechicken->weight -= thechicken->hp_max * diff / 540;              /* �魫 */
 if(thechicken->weight<1)
        {
                thechicken->sick -= thechicken->weight / 10; /* �j�o�f��W�� */
                thechicken->weight =1;
        }
 thechicken->clean  += diff * time_change[thechicken->type][CLEAN] /30; /* �M��� */

 thechicken->happy  -= diff / 60;                                  /* �ּ֫� */
 if(thechicken->happy<0) thechicken->happy=0;
 thechicken->attack  -= time_change[thechicken->type][ATTACK]*diff/ (60*32);
 if(thechicken->attack<0) thechicken->attack=0;
                                                                  /* �����O */
 thechicken->run  -= time_change[thechicken->type][RUN]*diff/ (60*32);
 if(thechicken->run<0) thechicken->run=0;                           /* �ӱ�   */
 thechicken->book  -= time_change[thechicken->type][BOOK]*diff/ (60*32);
 if(thechicken->book<0) thechicken->book=0;                         /* ����  */
 thechicken->temperament ++;                                       /* ���  */
 thechicken->satis  -= diff / 60;
 if(thechicken->satis<0) thechicken->satis=0;                       /* ���N�� */

 if(mychicken->clean > 1000)                           /* ż�f�� */
    {
        mychicken->sick += (mychicken->clean - 1000)/10;
    }

 if(thechicken->weight>1) thechicken->sick -= diff / 60;
 if(thechicken->sick<0) thechicken->sick =0;                        /* �f����@ */
 thechicken->tiredstrong -= diff * time_change[thechicken->type][TIREDSTRONG]/4;

 if(thechicken->tiredstrong<0) thechicken->tiredstrong = 0 ;        /* �h�� */
 if(thechicken->hp >= thechicken->hp_max/2)
 thechicken->hp_max  += time_change[thechicken->type][HP_MAX]*diff/ (60*12);
                                                                  /* hp_max  */
 if(!thechicken->sick)                                            /* hp���@ */
     thechicken->hp += time_change[thechicken->type][HP_MAX]*diff/ (60*6);
 if(thechicken->hp>thechicken->hp_max) thechicken->hp = thechicken->hp_max;
 if(thechicken->mm >= thechicken->mm_max/2)
 thechicken->mm_max  += time_change[thechicken->type][MM_MAX]*diff/ (60*8);
                                                                  /* mm_max  */
 if(!thechicken->sick) thechicken->mm += diff;                      /* mm���@ */
 if(thechicken->mm>thechicken->mm_max) thechicken->mm = thechicken->mm_max;
}

void
check_sick()
{
 if(mychicken->tiredstrong > mychicken->hp*0.3 &&
       mychicken->clean > 150)                           /* ż�f�� */
    {
        mychicken->sick += (mychicken->clean - 150)/10;
    }
 if(mychicken->tiredstrong > mychicken->hp*1.3)  /* �֯f�� */
    {
        mychicken->sick += time_change[mychicken->type][SICK];
    }
 if(mychicken->sick > mychicken->hp / 5)        /* �f��ӭ��ٰ��ƴ�hp */
    {
        mychicken->hp -= (mychicken->sick - mychicken->hp / 5)/4;
        if( mychicken->hp < 0 ) mychicken->hp = 0;
    }
}
int
isdeadth()
{
 char buf[100];
 time_t now=time(NULL);

 get_record(fn_passwd, &xuser, sizeof(xuser), usernum);
 if(!xuser.mychicken.name[0]) return 1;

 if(mychicken->hp <= 0)                           /* hp�κ� */
        {
         more(CHICKEN_PIC "/nohp",YEA);
         more(CHICKEN_PIC "/deadth",YEA);
        }
 else if(mychicken->tiredstrong > mychicken->hp * 3 )  /* �޳ҹL�� */
        {
         more(CHICKEN_PIC "/tootired",YEA);
         more(CHICKEN_PIC "/deadth",YEA);
        }
 else if(mychicken->weight > mychicken->hp_max*5)      /* �έD�L�� */
        {
         more(CHICKEN_PIC "/toofat",YEA);
         more(CHICKEN_PIC "/deadth",YEA);
        }

 else if(mychicken->weight == 0)      /* �j���F */
        {
         more(CHICKEN_PIC "/nofood",YEA);
         more(CHICKEN_PIC "/deadth",YEA);
        }
 else return 0;

 sprintf(buf,"1m%sm �үk�R��3m %s2m %s m���F �� %s",cuser.userid,
          mychicken->name,chicken_type[mychicken->type],ctime(&now));
 log_file(CHICKENLOG,buf);
 mychicken->name[0]=0;
 return 1;
}
void
ch_changename()
{
 char buf[150],newname[20]="";
 time_t now=time(NULL);

 getdata_str(b_lines-1,0,"��..��Ӧn�W�r�a:", newname, 18, DOECHO,
                mychicken->name);

 if(strlen(newname) >=3 && strcmp(newname,mychicken->name))
   {
    sprintf(buf,"1m%sm ��k�R��3m %s2m %s m��W��3m %sm �� %s",
        cuser.userid, mychicken->name,chicken_type[mychicken->type],newname,
        ctime(&now));
    strcpy(mychicken->name,newname);
    log_file(CHICKENLOG,buf);
   }

}
int
select_menu()
{
  char ch;

  reload_money();
  move(19,0);
  prints(
   "4;37m �� :3m %-10d                                                         m\n"
   "3m(7m13m)�M�z (7m23m)�Y�� (7m33m)�q�� (7m43m)��� (7m53m)�˥L "
   "(7m63m)���L (7m73m)�R%s$%d (7m83m)�Y�ɤY\n"
   "(7m93m)�Y�f�� (7mo3m)�R�j�ɤY$100 (7mm3m)�R��$10 (7mk3m)�����L "
   "(7ms3m)�汼 (7mn3m)��W (7mq3m)���}:m",
   cuser.money,
   chicken_food[mychicken->type],food_price[mychicken->type]);

  do
  {
   switch(ch = igetch())
        {
         case '1':
                ch_clean(); check_sick(); break;
         case '2':
                ch_eat(); check_sick(); break;
         case '3':
                ch_guess(); check_sick(); break;
         case '4':
                ch_book(); check_sick(); break;
         case '5':
                ch_kiss(); break;
         case '6':
                ch_hit(); check_sick(); break;
         case '7':
                ch_buyitem(food_price[mychicken->type],
                          CHICKEN_PIC "/food",&mychicken->food);
                break;
         case '8':
                ch_eatoo(); break;
         case '9':
                ch_eatmedicine(); break;
         case 'O':
         case 'o':
                ch_buyitem(100,CHICKEN_PIC "/buyoo",&mychicken->oo); break;
         case 'M':
         case 'm':
                ch_buyitem(10,CHICKEN_PIC "/buymedicine",&mychicken->medicine);
                break;
         case 'N':
         case 'n':
                ch_changename();break;
         case 'K':
         case 'k':
                ch_kill();
                return 0;
         case 'S':
         case 's':
                if(!ch_sell())  break;
         case 'Q':
         case 'q':
                return 0;
        }
  }
  while(ch < ' ' || ch>'z');
  return 1;
}

int
chicken_main()
{

 if (lockutmpmode(CHICKEN))  return 0;

 age = ((time(NULL) - mychicken->birthday)/ (60*60*24));
 if(!mychicken->name[0])
        {
            if(!new_chicken())
                     {
                        unlockutmpmode();
                        return 0;
                     }
        }
 do
 {
  time_diff(mychicken);
  if(isdeadth()) break;
  show_chicken_data(mychicken);
 }
 while(select_menu());
 reload_money();
 substitute_record(fn_passwd, &cuser, sizeof(userec), usernum);
 unlockutmpmode();
 return 0;
}


