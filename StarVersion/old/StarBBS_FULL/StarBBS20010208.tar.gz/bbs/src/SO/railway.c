/*-------------------------------------------------------*/
/* railway.c          ( NTHU CS MapleBBS Ver 3.02 )      */
/*-------------------------------------------------------*/
/* author : jhf.bbs@bbs.ess.nthu.edu.tw                  */
/* target : ������T�d��                                 */
/* create : 99/01/02                                     */
/* update : anytime                                      */
/*-------------------------------------------------------*/

#include "../include/bbs.h"

#include <stdlib.h>
#include <netdb.h>
#include <sys/uio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define SERVER_RAILWAY     "www.railway.gov.tw"
#define CGI_RAILWAY        "/cgi-bin/timetk.cgi"
#define REFER_RAILWAY      "http://www.railway.gov.tw/taiwan/tai4a-1.html"
#define LOG_RAILWAY        "log/railway.log"
#define WEBPORT         80
#define PARA            "Connection: Keep-Alive\nUser-Agent: Mozilla/4.5b1[en] (X11; I; FreeBSD 3.0-STABLE i386)\nContent-type:application/x-www-form-urlencoded\nAccept: image/gif, image/x-xbitmap,image/jpeg, image/pjpeg, image/png, */*\nAccept-Encoding: gzip\nAccept-Language: en\nAccept-Charset: iso-8859-1,*,utf-8\n"

int railway2()
{
  static char pool[4096];
  int cc, sock, tlen;
  FILE *fp;
  char *xhead, *xtail, buf[1024], tag[8],trn[512],fromstation[6],tostation[6];
  char fromtime[3],totime[3],buf1[128],ans[3];
  clear();
  move(0,0);
  outs("[1;37;42m�w��ϥάP�e�����ɨ貼�� �d�ߨt�� V0.1   \
                           [1;33;41m�@��:jhf[m\n");
  more("etc/railway", YEA);
  move(16,0);   
  clrtobot(); 
  if ((!getdata(17, 0, "�п�J*����*�_�{���G", fromstation, 9, DOECHO,0) ||
     !getdata(17, 30, "�п�J*����*��F���G", tostation, 9, DOECHO,0) ||
      !getdata(19, 0, "�d�߮ɶ��Ϭq:��(00-23):", fromtime, 3, DOECHO,0) ||
      !getdata(19, 30, "��(00-23):",totime,3, DOECHO,0))
  )
  {
    pressanykey("���d��");
    return;
  }
  if (answer(msg_sure_ny) != 'y')
  {
    pressanykey("���d��");
    return;
  }
  outmsg("���b�s�����A����...");
  dns_init();
  sock = dns_open(SERVER_RAILWAY, WEBPORT);
  if (sock < 0)
    return -1;
  sprintf(trn,"from=%s&to=%s&from-time=%s&to-time=%s&tt=start&type=fast",
        fromstation,tostation,fromtime,totime);
  sprintf(buf, "POST %s HTTP/1.0\nReferer: %s\n%sContent-length:%d\n\n%s",
            CGI_RAILWAY, REFER_RAILWAY, PARA, strlen(trn), trn);

  /*sprintf(buf, "GET %s\n\n", path);*/
  cc = strlen(buf);
  if (send(sock, buf, cc, 0) != cc)
  {
    close(sock);
    return -1;
  }

    xhead = pool;
  xtail = pool;
  tlen = 0;

  sprintf(buf, BBSHOME"/tmp/railway.%s", cuser.userid);
  strcat(buf, "-");
  fp = fopen(buf, "w");

  for (;;)
  {
    if (xhead >= xtail)
    {
      xhead = pool;
      cc = recv(sock, xhead, sizeof(pool), 0);
      if (cc <= 0)
        break;
      xtail = xhead + cc;
   }

    cc = *xhead++;
    if (cc == '<')
    {
      tlen = 1;
      continue;
    }

    if (tlen)
    {
      /* support <br> and <P> */

      if (cc == '>')
      {
        if (tlen == 3 && !str_ncmp(tag, "br", 2))
        {
          fputc('\n', fp);
        }
        else if (tlen == 3 && !str_ncmp(tag, "tr", 2))
        {
          fputc('\n', fp);
        }
        else if (tlen == 3 && !str_ncmp(tag, "td", 2))
        {
          fputc(' ', fp);
        }
        else if (tlen == 6 && !str_ncmp(tag, "/font", 5))
        {
          fputc(' ', fp);
        }

        else if (tlen == 2 && !str_ncmp(tag, "P", 1))
        {
          fputc('\n', fp);
          fputc('\n', fp);
        }

        tlen = 0;
        continue;
      }

      if (tlen <= 2)
      {
        tag[tlen - 1] = cc;
      }
      tlen++;
      continue;
    }

    if (cc != '\r' && cc != '\n')
       fputc(cc, fp);
 }

  close(sock);

  fputc('\n', fp);
  fclose(fp);
  sprintf(buf1, BBSHOME"/tmp/railway.%s",cuser.userid);
  rename(buf, buf1);
  pressanykey("��ƶǰe����");
  clear();
  if (more(buf1, YEA) != -1) {
   do {
     getdata(b_lines - 1, 0, "�M��(C) ���ܳƧѿ�(M) (C/M)�H",
        ans, 3, LCECHO,"c");
     if (*ans == 'c' || *ans == 'C') {
        unlink(buf1);
        return 0;
     }
     if (*ans == 'm' || *ans == 'M') {
        fileheader mymail;
        char title[128], buf[80];
        sethomepath(buf, cuser.userid);
        stampfile(buf, &mymail);
        mymail.savemode = '\0';        /* hold-mail flag */
        mymail.filemode = FILE_READ;
        strcpy(mymail.title, "�賡�F�u�����ɨ�d�ߵ��G");
        strcpy(mymail.owner, "[�� �� ��]");
        sethomedir(title, cuser.userid);
        rec_add(title, &mymail, sizeof(mymail));
        f_mv(buf1,buf);
        return 0;
     }
   } while (1);
 }
  return;
}
