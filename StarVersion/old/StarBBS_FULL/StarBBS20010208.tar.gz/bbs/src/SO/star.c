/*-------------------------------------------------------*/
/* star.c        ( FJU StarRiverBBS Ver 0.95 )           */
/*-------------------------------------------------------*/
/* target : some other system tools                      */
/* create : 99/11/09                                     */
/* update : 99/11/19                                     */
/*-------------------------------------------------------*/


#include "bbs.h"

int
bh_desc_edit()
{
  boardheader bp;
  boardheader *getbcache();
  int bid;
  if (currmode & MODE_BOARD)
    {
     char genbuf[60];
     bid = getbnum(currboard);
     if (rec_get(fn_board, &bp, sizeof(boardheader), bid) == -1)
     {
            pressanykey(err_bid);
            return -1;
     }

     move(1,0);
     clrtoeol();
     getdata(1,0,"�ݪO����:", genbuf,60,LCECHO,0);
     if(!genbuf[0]) return 0;
     strip_ansi( genbuf,genbuf,0);
     strcpy(bp.descript,genbuf);

     substitute_record(fn_board, &bp, sizeof(boardheader), bid);
     touch_boards();
     log_usies("SetBoard", currboard);
     return FULLUPDATE;
    }
  return 0;
}

extern int
bad_user_id(char userid[]);

int
mail_all()
{
   FILE *fp;
   fileheader mymail;
   char fpath[TTLEN];
   char genbuf[200];
   extern struct UCACHE *uidshm;
   int i, unum;
   char* userid;

   stand_title("���Ҧ��ϥΪ̪��t�γq�i");
   setutmpmode(SMAIL);
   getdata(2, 0, "�D�D�G", fpath, 64, DOECHO,0);
   sprintf(save_title, "[�t�γq�i]^[[1;32m %s^[[m", fpath);

   setuserfile(fpath, fn_notes);

   if (fp = fopen(fpath, "w")) {
      fprintf(fp, "�� [�t�γq�i] �o�O�ʵ��Ҧ��ϥΪ̪��H\n");
      fprintf(fp, "---------------------------------------------------------------------------\n");
      fclose(fp);
    }

   *quote_file = 0;

   curredit |= EDIT_MAIL;
   curredit &= ~EDIT_ITEM;
   if (vedit(fpath, YEA) == -1) {
      curredit = 0;
      unlink(fpath);
      pressanykey(msg_cancel);
      return;
   }
   curredit = 0;

   setutmpmode(MAILALL);
   stand_title("�H�H��...");

   sethomepath(genbuf, cuser.userid);
   stampfile(genbuf, &mymail);
   unlink(genbuf);
   f_cp(fpath, genbuf,O_TRUNC);
   unlink(fpath);
   strcpy(fpath, genbuf);

   strcpy(mymail.owner, cuser.userid);  /*���� ID*/
   strcpy(mymail.title, save_title);
   mymail.savemode = 0;
  /* mymail.filemode |= FILE_TAGED;    Ptt ���i�令���|mark */

   sethomedir(genbuf, cuser.userid);
   if (rec_add(genbuf, &mymail, sizeof(mymail)) == -1)
      outs(err_uid);

   for (unum = uidshm->number, i = 0; i < unum; i++) {

      if(bad_user_id(uidshm->userid[i]))
        continue; /* Ptt */

      userid = uidshm->userid[i];
      if (strcmp(userid, "guest") && strcmp(userid, "new") && strcmp(userid, cuser.userid)) {
         sethomepath(genbuf, userid);
         stampfile(genbuf, &mymail);
         unlink(genbuf);
         f_cp(fpath, genbuf,O_TRUNC);

         strcpy(mymail.owner, cuser.userid);
         strcpy(mymail.title, save_title);
         mymail.savemode = 0;
       /* mymail.filemode |= FILE_MARKED; Ptt ���i�令���|mark */
         sethomedir(genbuf, userid);
         if (rec_add(genbuf, &mymail, sizeof(mymail)) == -1)
            outs(err_uid);
         sprintf(genbuf, "%*s %5d / %5d", IDLEN + 1, userid, i + 1, unum);
         outmsg(genbuf);
         refresh();
      }
   }
   return;
}

