#include <fcntl.h>
#include <stdio.h>

/* �p�ƾ� wildcat */

void
counter(filename,modes)
  char filename[32];
  char modes[64];
{
  FILE *fp;
  unsigned long visited;

  if(fopen(filename,"r")==0)
  {
    fp = fopen(filename,"w");
    fprintf(fp,"0");
    fclose(fp);
  }
  fp = fopen(filename,"r");
  fscanf(fp,"%d",&visited);
  fclose(fp);
  prints("[1m  [32m�z�O��[33m %d [32m�� %s ���ϥΪ�[m",++visited,modes);
  fp = fopen(filename,"w");
  fprintf(fp,"%d",visited);
  fclose(fp);
}
