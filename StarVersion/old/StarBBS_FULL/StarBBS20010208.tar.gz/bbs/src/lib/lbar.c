/* cursor bar */
#include "bbs.h"

char currentbar[60];
char oldbar[60];

lbar(char *high, char *norm,char *des,int flag)
{
  int x,y,a;
  char tmp[60];

  refresh(); // flush all data

  getyx(&x, &y);
  output(oldbar, strlen(oldbar));
  output(high, strlen(high));
  strcpy(currentbar, high);
  strcpy(oldbar,norm);
  if(HAS_HABIT(HABIT_DES)) // ����ܻ���
   flag =1;

  if(flag == 0)
  {
   if(currstat == BUILDING)
   {
    for(a=0;a<8;a++)
    {
     move(5+a,0);
     clrtoeol();
    }
    move(5,0);
   }
   else
   {
    move(b_lines-1,0);
    clrtoeol();
   }
   if(strlen(des) < 1)
    des = "�i�h�ݬݴN���D��!!";

   prints("^[[1;33m����:^[[m%s",des);
  }

  sprintf(tmp, "\x1b[%d;%dH",x+1, y+1);  // \x1b �N�O ascii code(27)
  output(tmp, strlen(tmp));
}

