/* Define the modules you want to compile in */
#define MOD_EXTRAS 1
#define MOD_MONITOR 1
#define MOD_STATS 1
#define MOD_QUERY 1
#define MOD_ANIM 1
#define MOD_POSTWAR 1
#define MOD_VOTE 1

