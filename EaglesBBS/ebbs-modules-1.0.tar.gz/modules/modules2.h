#ifdef MOD_EXTRAS
    "ModCloak",ModCloak,
    "DispServInfo",DispServInfo,
    "SysConfigHelp",SysConfigHelp,
    "DispModInfo",DispModInfo,
    "ModConfigHelp",ModConfigHelp,
    "UserModInfo",UserModInfo,
    "FuncTest",FuncTest,
#endif
#ifdef MOD_MONITOR
    "NewMonitor",NewMonitor,
    "MonQuery",MonQuery,
    "MonSetPager",MonSetPager,
    "MonOnlineUsers",MonOnlineUsers,
    "MonHelp",MonHelp,
    "MonToggleCloak",MonToggleCloak,
#endif
#ifdef MOD_VOTE
    "Vote",Vote,
    "NoVote",NoVote,
    "VoteResults",VoteResults,
    "OpenVote",OpenVote,
    "CloseVote",CloseVote,
    "CloseMyPolls",CloseMyPolls,
#endif
#ifdef MOD_STATS
    "LoginStat",LoginStat,
    "PostStat",PostStat,
    "PostwarStat",PostwarStat,
    "LastLoginStat",LastLoginStat,
    "ChatStat",ChatStat,
    "StatChat",StatChat,
    "UserStatDisplay",UserStatDisplay,
    "SetUserStats",SetUserStats,
#endif
#ifdef MOD_QUERY
    "AdvQuery",AdvQuery,
#endif
#ifdef MOD_POSTWAR
    "PwPost",PwPost,
#endif
